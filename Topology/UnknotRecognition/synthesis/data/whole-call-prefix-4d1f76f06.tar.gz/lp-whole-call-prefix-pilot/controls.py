"""Small tuple-safe, cap and nested-policy controls, separate from whole calls."""
import inspect
from itertools import product

from common import ARMS, SMALL_CASES, fail, new_document, pins, same, save
from lp_check import check_lp
from pivot_selectors import (installed, candidate, ORIGINAL_CONTROLLER, ORIGINAL_HELPER)
from fastunknot import exact_lp


POLICIES=('polynomial','bland')
ENTRIES=('public','prepared')
ERRORS=(None,'ValueError','KeyboardInterrupt')


def inside_tableau():
    frame=inspect.currentframe().f_back
    while frame is not None:
        if frame.f_code.co_name=='_solve_prepared_kernel':
            return True
        frame=frame.f_back
    return False


def solve_entry(entry,matrix,objective,**options):
    if entry=='public':
        return exact_lp.solve_nonnegative_kernel(matrix,objective,**options)
    assert entry=='prepared'
    prepared=exact_lp._prepare_kernel_matrix(matrix,len(objective),check=options.get('check',lambda:None))
    return exact_lp._solve_prepared_nonnegative_kernel(prepared,objective,**options)


def run_controls(path):
    document=new_document('whole-call-prefix-controls-v1')
    document.update(small=[],legacy=[],nested=[],callbacks=[],validation=[])
    document['patch_metadata']=candidate()[1]
    save(path,document)
    try:
        for name,matrix,objective,options,expected in SMALL_CASES:
            prepared=exact_lp._prepare_kernel_matrix(matrix,len(objective),reduce_rows=options.get('reduce_rows',True))
            for arm in ARMS:
                document['active']=dict(kind='small',case=name,arm=arm)
                save(path,document)
                with installed(arm):
                    fresh=exact_lp.solve_nonnegative_kernel(matrix,objective,**options)
                    reused=exact_lp._solve_prepared_nonnegative_kernel(prepared,objective,**{k:v for k,v in options.items() if k!='reduce_rows'})
                assert same(fresh,reused) and fresh['status']==expected
                replay=check_lp(matrix,objective,options,fresh)
                record=dict(case=name,arm=arm,result=fresh,prepared_result=reused,replay=replay)
                if name=='positive_degenerate':
                    limit=fresh['stats']['pivots']
                    assert limit>0
                    with installed(arm):
                        exact=exact_lp.solve_nonnegative_kernel(matrix,objective,max_pivots=limit)
                        short=exact_lp.solve_nonnegative_kernel(matrix,objective,max_pivots=limit-1)
                        zero=exact_lp.solve_nonnegative_kernel([[1]],[-1],max_pivots=0)
                        equal=exact_lp.solve_nonnegative_kernel(matrix,objective,max_pivots=0,fast_path_pivots=0)
                    assert same(exact,fresh)
                    assert short['status']==equal['status']=='INCONCLUSIVE'
                    assert equal['stats']['fallback_used']==0
                    assert zero['status']=='NONPOSITIVE' and zero['stats']['pivots']==0
                    record['boundaries']=dict(exact=exact,short=short,zero_conclusion=zero,equal_zero_caps=equal)
                document['small'].append(record)
                document['active']=None
                save(path,document)
        for name,matrix,objective,options,_ in SMALL_CASES[:5]:
            settings=dict(options,policy='bland')
            pristine=exact_lp.solve_nonnegative_kernel(matrix,objective,**settings)
            prepared=exact_lp._prepare_kernel_matrix(matrix,len(objective),reduce_rows=options.get('reduce_rows',True))
            for arm in ARMS:
                document['active']=dict(kind='legacy',case=name,arm=arm)
                save(path,document)
                dispatch=[]
                with installed(arm,dispatch_log=dispatch):
                    actual=exact_lp.solve_nonnegative_kernel(matrix,objective,**settings)
                    reused=exact_lp._solve_prepared_nonnegative_kernel(prepared,objective,**settings)
                assert same(actual,pristine) and same(reused,pristine)
                assert dispatch==[dict(policy='bland',candidate=False)]*2
                document['legacy'].append(dict(case=name,arm=arm,pristine=pristine,
                    result=actual,prepared_result=reused,dispatch=dispatch,
                    replay=check_lp(matrix,objective,settings,actual)))
                document['active']=None
                save(path,document)
        for arm,outer,inner,outer_entry,inner_entry,error_name in product(ARMS,POLICIES,POLICIES,ENTRIES,ENTRIES,ERRORS):
            document['active']=dict(kind='nested',arm=arm,outer=outer,inner=inner,outer_entry=outer_entry,inner_entry=inner_entry,error=error_name)
            save(path,document)
            dispatch=[]
            state=dict(fired=False,inner_restored=False,caught_identical=False)
            error=(ValueError('nested cancellation') if error_name=='ValueError' else
                   KeyboardInterrupt('nested cancellation') if error_name else None)
            def nested_check():
                if state['fired'] or not inside_tableau():
                    return
                state['fired']=True
                active_helper=exact_lp._solve_prepared_kernel
                def inner_check():
                    # Require the inner helper itself on the stack, not just
                    # the outer helper while inner input parsing is running.
                    caller=inspect.currentframe().f_back
                    if error is not None and caller.f_code.co_name=='_solve_prepared_kernel':
                        raise error
                try:
                    answer=solve_entry(inner_entry,[[1,-1]],[1,-2],policy=inner,check=inner_check)
                    state['inner_result']=answer
                    check_lp([[1,-1]],[1,-2],dict(policy=inner),answer)
                finally:
                    state['inner_restored']=exact_lp._solve_prepared_kernel is active_helper
                    assert state['inner_restored']
            try:
                with installed(arm,dispatch_log=dispatch):
                    answer=solve_entry(outer_entry,[[1,1,-1]],[1,1,0],policy=outer,check=nested_check)
                assert error is None
                state['outer_result']=answer
                check_lp([[1,1,-1]],[1,1,0],dict(policy=outer),answer)
            except BaseException as caught:
                assert error is not None and caught is error
                state['caught_identical']=True
            assert state['fired'] and state['inner_restored']
            assert exact_lp._solve_prepared_kernel is ORIGINAL_HELPER
            assert exact_lp._run_kernel_policy is ORIGINAL_CONTROLLER
            expected_dispatch=[dict(policy=p,candidate=arm=='prepared_dantzig_lex' and p=='polynomial') for p in (outer,inner)]
            assert dispatch==expected_dispatch
            document['nested'].append(dict(arm=arm,outer=outer,inner=inner,outer_entry=outer_entry,inner_entry=inner_entry,error=error_name,
                dispatch=dispatch,outer_restored=True,**state))
            document['active']=None
            save(path,document)
        for arm in ARMS:
            document['active']=dict(kind='callback_positions',arm=arm)
            save(path,document)
            count=[0]
            def count_check():
                count[0]+=1
            with installed(arm):
                exact_lp.solve_nonnegative_kernel([[1,1,-1]],[1,1,0],check=count_check)
            for stop in range(1,count[0]+1):
                seen=[0]
                error=ValueError('callback cancellation') if stop%2 else KeyboardInterrupt('callback cancellation')
                def cancel():
                    seen[0]+=1
                    if seen[0]==stop:
                        raise error
                try:
                    with installed(arm):
                        exact_lp.solve_nonnegative_kernel([[1,1,-1]],[1,1,0],check=cancel)
                except BaseException as caught:
                    assert caught is error
                else:
                    raise AssertionError('Missing callback exception')
                assert exact_lp._run_kernel_policy is ORIGINAL_CONTROLLER
                assert exact_lp._solve_prepared_kernel is ORIGINAL_HELPER
            document['callbacks'].append(dict(arm=arm,positions=count[0],identity_and_restoration=True))
            document['active']=None
            save(path,document)
        bad_options=(dict(policy='bland',fast_path_pivots=0),
            dict(policy='bland',max_ellipsoid_iterations=0),
            dict(policy='bland',max_feasibility_calls=0),dict(max_pivots=True))
        for arm in ARMS:
            for index,options in enumerate(bad_options):
                document['active']=dict(kind='strict_validation',arm=arm,index=index)
                save(path,document)
                dispatch=[]
                with installed(arm,dispatch_log=dispatch):
                    try:
                        exact_lp.solve_nonnegative_kernel([[1,-1]],[1,0],**options)
                    except ValueError:
                        pass
                    else:
                        raise AssertionError('Invalid controls accepted')
                assert not dispatch
                document['validation'].append(dict(arm=arm,index=index,rejected_before_controller=True))
        document['active']=None
        assert same(document['pins'],pins())
        document['passed']=True
        document['summary']=check_controls(document)
        save(path,document)
    except BaseException as error:
        fail(document,'controls',error)
        save(path,document)
        raise
    return document['summary']


def check_controls(document):
    assert document['schema']=='whole-call-prefix-controls-v1'
    assert same(document['pins'],pins()) and document['passed'] is True
    assert not document['failures'] and document['active'] is None
    assert same(document['patch_metadata'],candidate()[1])
    expected=[(case,arm) for case in SMALL_CASES for arm in ARMS]
    assert len(document['small'])==len(expected)
    for record,((name,matrix,objective,options,status),arm) in zip(document['small'],expected):
        assert record['case']==name and record['arm']==arm
        assert same(record['result'],record['prepared_result'])
        assert record['result']['status']==status
        assert record['replay']==check_lp(matrix,objective,options,record['result'])
        if name=='positive_degenerate':
            bounds=record['boundaries']
            limit=record['result']['stats']['pivots']
            assert same(bounds['exact'],record['result'])
            check_lp(matrix,objective,dict(max_pivots=limit),bounds['exact'])
            check_lp(matrix,objective,dict(max_pivots=limit-1),bounds['short'])
            check_lp([[1]],[-1],dict(max_pivots=0),bounds['zero_conclusion'])
            check_lp(matrix,objective,dict(max_pivots=0,fast_path_pivots=0),bounds['equal_zero_caps'])
            assert bounds['short']['status']==bounds['equal_zero_caps']['status']=='INCONCLUSIVE'
            assert bounds['zero_conclusion']['status']=='NONPOSITIVE'
    expected=[(case,arm) for case in SMALL_CASES[:5] for arm in ARMS]
    assert len(document['legacy'])==len(expected)
    for record,((name,matrix,objective,options,_),arm) in zip(document['legacy'],expected):
        assert record['case']==name and record['arm']==arm
        assert same(record['result'],record['pristine']) and same(record['prepared_result'],record['pristine'])
        assert record['dispatch']==[dict(policy='bland',candidate=False)]*2
        assert record['replay']==check_lp(matrix,objective,dict(options,policy='bland'),record['result'])
    expected=list(product(ARMS,POLICIES,POLICIES,ENTRIES,ENTRIES,ERRORS))
    assert len(document['nested'])==len(expected)
    for record,(arm,outer,inner,outer_entry,inner_entry,error_name) in zip(document['nested'],expected):
        assert (record['arm'],record['outer'],record['inner'],record['outer_entry'],record['inner_entry'],record['error'])==(arm,outer,inner,outer_entry,inner_entry,error_name)
        assert record['fired'] is record['inner_restored'] is record['outer_restored'] is True
        assert record['caught_identical'] is (error_name is not None)
        assert record['dispatch']==[dict(policy=p,candidate=arm=='prepared_dantzig_lex' and p=='polynomial') for p in (outer,inner)]
        if error_name is None:
            check_lp([[1,-1]],[1,-2],dict(policy=inner),record['inner_result'])
            check_lp([[1,1,-1]],[1,1,0],dict(policy=outer),record['outer_result'])
    assert [r['arm'] for r in document['callbacks']]==list(ARMS)
    assert all(type(r['positions']) is int and r['positions']>0 and r['identity_and_restoration'] is True for r in document['callbacks'])
    assert document['validation']==[dict(arm=arm,index=i,rejected_before_controller=True) for arm in ARMS for i in range(4)]
    return dict(polynomial_cases=22,legacy_cases=10,nested_cases=96,callback_arms=2,validation_cases=8)
