"""Preflight, fourteen fresh count-only whole calls, and discovery-free replay."""
import argparse
from contextlib import ExitStack
from copy import deepcopy
import json
import importlib
import sys
from pathlib import Path
from unittest.mock import patch

from common import (ARMS, OPTIONS, cases, digest, fail, file_digest, new_document,
                    pins, same, save)
from controls import run_controls,check_controls
from pivot_selectors import installed,candidate
from observer import Observer
from check_evidence import chain_replay,query_replay,check_slot,compare_case,check_audit
from fastunknot import exact_lp
from fastunknot.diagram import Diagram
from fastunknot.normal_crushing_search import recognize_by_crushing


def run_audit(control_path,path):
    document=new_document('whole-call-prefix-audit-v1')
    document.update(calls=[],comparisons=[],summary=[],controls_sha256=file_digest(control_path),
                    patch_metadata=candidate()[1])
    definitions=cases()
    for case in definitions:
        for arm in ARMS:
            document['calls'].append(dict(case_id=case['id'],arm=arm,
                input_pd=case['input_pd'],input_pd_sha256=digest(case['input_pd']),
                options=OPTIONS,completion='NOT_RUN',active_phase=None,
                source_bank={},matrix_bank={},searches=[],attempts=[],queries=[]))
    document['active']=dict(kind='controls_preflight')
    save(path,document)
    try:
        control=json.loads(Path(control_path).read_bytes())
        check_controls(control)
        for index,slot in enumerate(document['calls']):
            document['active']=dict(kind='whole_call',index=index,case_id=slot['case_id'],arm=slot['arm'])
            slot['completion']='ACTIVE'
            slot['active_phase']=dict(kind='driver')
            save(path,document)
            diagram=Diagram.from_pd(slot['input_pd'])
            observer=Observer(document,slot,path)
            with observer.installed(),installed(slot['arm'],observer=observer) as metadata:
                assert same(metadata,document['patch_metadata'])
                result=recognize_by_crushing(diagram,**OPTIONS)
            slot.update(result=result,result_sha256=digest(result),completion='RETURNED',
                        active_phase=dict(kind='independent_whole_replay'))
            save(path,document)
            ledger,summary=chain_replay(slot)
            slot['source_ledger']=ledger
            summary.update(query_replay(slot,ledger))
            slot['replay']=summary
            slot['active_phase']=None
            assert check_slot(slot,definitions[index//2])==summary
            document['summary'].append(summary)
            if index%2:
                document['comparisons'].append(dict(case_id=slot['case_id'],
                    **compare_case(*document['calls'][index-1:index+1])))
            document['active']=None
            assert same(document['pins'],pins())
            save(path,document)
            print(json.dumps(dict(case_id=slot['case_id'],arm=slot['arm'],
                status=result['status'],queries=result['stats']['lp_calls'],
                pivots=result['stats']['lp_pivots'],nodes=result['stats']['nodes_attempted'],
                final_tetrahedra=summary['endpoint']['tetrahedra']),sort_keys=True),flush=True)
        assert document['controls_sha256']==file_digest(control_path)
        document['passed']=True
        summary=check_audit(document,document['controls_sha256'])
        save(path,document)
    except BaseException as error:
        fail(document,'whole_call_audit',error)
        save(path,document)
        raise
    return summary


def replay(control_path,audit_path):
    with ExitStack() as stack:
        # Import every producer first, then replace its entry points and all
        # already-imported aliases by identity. Algebra assembly is permitted;
        # no LP, ray search, topology producer or recognition discovery is.
        targets={
            'exact_lp':('solve_nonnegative_kernel','_solve_prepared_nonnegative_kernel',
                '_run_kernel_policy','_solve_prepared_kernel','_ellipsoid_kernel'),
            'normal_crushing_search':('recognize_by_crushing','_recognize_by_crushing'),
            'normal_euler_tree':('search_euler_tree',),
            'normal_euler_transversal':('search_euler_transversal',),
            'normal_euler':('decide_sector_euler',),
            'normal_sector':('sector_rays','enumerate_sector','discover_in_sector',
                '_discover_in_kernel','sparse_disc_search'),
            'positive_ray':('extract_positive_ray',),
            'normal_vertex_reduction':('vertex_reduction_ray',),
            'diagram_exterior':('diagram_exterior',),
            'boundary_shellings':('shell_boundary',),
            'normal_crushing':('crush_normal_ray',),
            'normal_crushing_chain':('make_crushing_chain','_make_crushing_chain'),
            'boundary_unlayer':('unlayer_boundary_once',),
            'normal_pachner32':('reduce_pachner32_once','_reduce'),
            'normal_geometric_descent':('reduce_geometric_descent_once','_reduce'),
            'normal_pachner_descent':('reduce_pachner_descent_once','_reduce'),
            'pachner23':('pachner_23',),'pachner32':('pachner_32',),
        }
        originals=[]
        for module_name,names in targets.items():
            module=importlib.import_module('fastunknot.'+module_name)
            originals.extend(getattr(module,name) for name in names)
        aliases=[]
        for module_name,module in tuple(sys.modules.items()):
            if module is None or not (module_name.startswith('fastunknot.') or module_name in (__name__,'pivot_selectors')):
                continue
            for name,value in tuple(vars(module).items()):
                if any(value is original for original in originals):
                    aliases.append((module,name))
        for module,name in aliases:
            stack.enter_context(patch.object(module,name,side_effect=AssertionError('Discovery disabled')))
        tree=importlib.import_module('fastunknot.normal_euler_tree')
        kernel=importlib.import_module('fastunknot.source_kernel')
        stack.enter_context(patch.object(tree._EulerMaskOracle,'attempt',side_effect=AssertionError('Oracle discovery disabled')))
        stack.enter_context(patch.object(kernel.SourceKernel,'extreme_witness',side_effect=AssertionError('Ray discovery disabled')))
        control=json.loads(Path(control_path).read_bytes())
        summary=dict(controls=check_controls(control))
        if audit_path is not None:
            document=json.loads(Path(audit_path).read_bytes())
            summary['audit']=check_audit(document,file_digest(control_path))
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('controls');p.add_argument('--out',type=Path,required=True)
    p=sub.add_parser('audit');p.add_argument('--controls',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p=sub.add_parser('check');p.add_argument('--controls',type=Path,required=True);p.add_argument('--audit',type=Path)
    args=parser.parse_args()
    if args.command!='check' and args.out.exists():
        raise FileExistsError('Refuse to overwrite retained output: '+str(args.out))
    if args.command=='controls':
        summary=run_controls(args.out)
    elif args.command=='audit':
        summary=run_audit(args.controls,args.out)
    else:
        summary=replay(args.controls,args.audit)
    print(json.dumps(dict(passed=True,command=args.command,summary=summary),sort_keys=True),flush=True)


if __name__=='__main__':
    main()
