Implementation authorized by root; controls and discovery still await explicit review and scheduling. The following approved design is retained, with its original design-only boundary superseded for scratch implementation only.

# Design only: fresh whole-call polynomial-prefix comparison

No implementation, discovery, timing, or native edit is authorized by this
memo. It proposes the next separately scheduled scratch experiment. The
completed revision-973 fixed-query pilot and its maintained archive remain
unchanged.

## Decision and scope

Use fourteen fresh whole-diagram calls: seven fixed inputs, two arms. A
source-level continuation is useful for checking one endpoint's changed
oracle behavior, but it is insufficient evidence for changing the default
prefix. Different positive rays can change envelope success, conflicts,
transversal candidates, subsequent crushing sources and preprocessing;
different duals can change cache hits. These are precisely the effects
omitted by replaying a fixed baseline query list. The existing fixed-query
pilot already motivates the candidate, so another W34-only continuation is
optional debugging rather than a substitute for the fourteen calls.

The experiment is count-only. It measures complete recognition calls under
the same finite allowances and retains every conclusive, capped or failed
outcome. It asserts neither a runtime speedup nor universal performance
improvement. A default change would still require native integration tests,
the general capped-prefix correctness proof, explicit legacy Bland
regression, and honest reporting of any finite-corpus regressions.

## Inputs, order and controls

Fix this case order, using validated Diagram constructors and retaining the
literal generated PD and its canonical typed digest:

| ID | Input |
| --- | --- |
| circle | empty PD |
| trefoil | braid(2, [1,1,1]) |
| figure_eight | braid(3, [1,-2,1,-2]) |
| TT | braid(3, [1,1,1,2,2,2]) |
| T25 | braid(2, [1,1,1,1,1]) |
| T27 | braid(2, [1,1,1,1,1,1,1]) |
| W34 | braid(3, [1,-2,1,-2,1,-2,1,-2]) |

For each case run `prepared_bland` and then `prepared_dantzig_lex`.
There are no warmups, repeats, eligibility filters, or time measurements.
Inputs must not be removed because the candidate loses or either arm caps.
Both arms use this exact complete option dictionary:

```python
dict(max_sectors=256, max_bases=10000, max_crushes=None,
     sector_order='diversified', sector_quantum=64,
     sector_method='transversal', max_pivots=10000, max_anchors=10000,
     lp_strategy='envelope', reduce_vertices=True, unlayer_boundary=True,
     reduce_pachner32=True, reduce_pachner_descent=True,
     pachner_descent_method='geometric', max_tree_nodes=256,
     tree_model='source', max_hitting_subsets=10000,
     transversal_candidate_policy='conflicts', lp_policy='polynomial',
     lp_fast_path_pivots=None, max_ellipsoid_iterations=10000,
     max_feasibility_calls=10000)
```

`lp_fast_path_pivots=None` selects the default polynomial prefix bound; it
does not mean an unlimited prefix. Each full call receives fresh budgets.
Within a call, the actual native driver shares all allowances across its
source stages and the actual native search shares them across queries,
masks and transversal restarts. Thus the whole-call pivot total really is
at most 10,000 in each arm. No captured baseline query's allowance is reused
as an independent allowance here.

The baseline uses the prepared-matrix implementation unmodified. The
candidate uses that identical implementation, altering only the polynomial
prefix's entering/leaving selectors. Both use all geometric preprocessing.
Explicit `policy='bland'` remains the original native rule, even while the
candidate wrapper is installed. No third Dantzig-only arm is proposed: its
two capped failures are already preserved in the old fixed-query pilot.

## Freeze and the tuple-safe patch boundary

The inspected prepared source is at revision
`f67318ea0b834afd9a5e3adb9f1c359026e40bfb` (the prepared change was committed
as `4e152f0ef`). Before implementation or execution, root chooses the final
current checkpoint and snapshots its entire native package once. Both arms
import that same isolated snapshot. Pin the snapshot manifest, all scratch
code, protocol and exact input/config bytes. Never reinterpret the old
revision-973 pins as pins for this new experiment.

Current hooks in `fastunknot/exact_lp.py` are:

* `_PreparedKernelMatrix`: immutable original tuple rows and selected indices.
* `_run_kernel_policy(prepared, cost, *, ..., policy, ...)`: common public and
  prepared controller, with distinct legacy and polynomial paths.
* `_solve_prepared_kernel(source, cost, selected, *, max_pivots, check)`:
  the tableau, currently initialized using `[*row, *slack]`, which accepts
  the tuple rows introduced by preparation.

Generate the scratch candidate helper from this newly frozen current
helper, not by copying the revision-973 template. A checked AST/text patch
must match and replace exactly two assignments: the entering selector and
the leaving selector. Retain the tuple-safe initialization, all validation,
updates, callback behavior, final-before-cap ordering and result/statistics
fields. A structural source comparison must establish that nothing else in
the helper differs. Candidate selectors use the already reviewed exact
max-positive-reduced-cost rule (smallest entering index on ties) and full
original-slack lex ratio. No floating-point score, epsilon value, projection
of slack columns, tableau reuse, basis warm start or Devex state is added.

Install a scratch wrapper around `_run_kernel_policy`. It calls the saved
original controller with the real tableau helper when `policy=='bland'`,
and with the candidate tableau helper only for `policy=='polynomial'` in
the candidate arm. Nesting-safe scoped restoration is required, including
callbacks that invoke another LP. The baseline delegates without replacing
the tableau. These are single-threaded experiment processes. This leaves
the native public signatures and explicit Bland semantics unchanged while
covering both fresh-matrix and prepared entry points.

Preflight should explicitly compare full returned public and prepared
`policy='bland'` results with the wrapper installed versus absent; test a
nested Bland query from a polynomial callback as well. Forced fallback,
zero user cap versus zero internal prefix, success on the last permitted
pivot, dependent/zero rows and callback identity remain small control
obligations. Reuse the tiny independent rational checker, not an
exponential vertex enumerator. These controls are separate from the fourteen
whole-call records and are not performance observations.

## Fresh invocation and complete retention

Every record starts from the original Diagram and calls the actual
`recognize_by_crushing` with the dictionary above. Do not inject a supplied
source, reuse a previous arm's chain, or resume a historical proof. All
preprocessing, matrix preparation, actual LPs, extraction if required,
crushing, restarts and terminal proof production occur fresh.

Before the call save its case/arm/config/source-pin identity and mark it
unreturned. After it returns save the complete untouched native result,
canonical serialization/digest, and separately collected diagnostics before
starting another call. Capped INCONCLUSIVE results are valid retained
outcomes, not failures or grounds for omitting that case. Unexpected
exceptions retain their type, message, active phase/query, completed outputs
and lower bounds on unfinished work, then stop for root review. Explicitly
list the remaining planned records as NOT_RUN. No successful full-coverage
audit can contain missing, duplicated, failed or unreturned calls.

Do not add a wall cutoff. All user work allowances remain as declared.
Although `max_crushes=None`, accepted normal reductions and each accepted
preprocessing macro strictly decrease tetrahedron count. Initial diagram
sources satisfy the existing bound 20*max(1,crossings), at most 160 for this
corpus; the geometric preprocessing scans have the previously proved
polynomial finite bounds. Thus uncapped reduction count is still finite.
This gives a finite experiment, not a useful promised wall-clock deadline.

## Query diagnostics and source binding

Retain each actual LP request and answer from the new native call, not the
old eight-query stream. The current mask oracle calls its imported alias
`normal_euler_tree._solve_prepared_nonnegative_kernel`; patching only the
public `solve_nonnegative_kernel` would miss these queries. Instrument the
common `_run_kernel_policy` wrapper and annotate through an
`_EulerMaskOracle.attempt` wrapper, so all public/prepared queries are seen.
For this fixed transversal policy, reject or explicitly diagnose a query
without an expected source/mask context rather than silently dropping it.

Each request records the full original matrix, selected original row
indices, objective, actual remaining limits, source digest, mask and
envelope/anchor context, followed by its full answer and replay outcome.
Deduplicate immutable matrices and full labelled sources by their typed
canonical bytes/digest; retain each distinct body once and every referencing
query in chronological order. This avoids storing the same 54-by-93 matrix
for every anchor. Check byte equality on deduplication, not digest equality
alone. Objective lists and answers remain per query. Do not persist a
tableau at every pivot or add a warm-start cache.

Independent arithmetic replay checks every original primal equation or
dual inequality, positive normalization and primitive scaling, support
nullity one, and the claimed feasible original slack basis. Source algebra
reconstruction additionally binds the matrix/objective to its actual
source/mask/anchor. Replaying a positive envelope LP does not assert that
its canonical formal Euler is positive; retain the native oracle's actual
lifting/compatibility decision separately.

Query sums must match the whole-call native `lp_calls`, `lp_pivots`,
`lp_tableau_updates`, fallbacks, ellipsoid updates and feasibility calls.
Check literal nonnegative integer statistics and the exact remaining-cap
arithmetic throughout. Count preparation per actual attempt as a separate
diagnostic without modifying the native result. Exact byte-keyed reuse of
an independent matrix-rank calculation is permissible if disclosed; it
must not cache whole policy acceptance or skip distinct primal/dual checks.
The native reported `maximum_tableau_bits` remains an end-tableau statistic,
not a peak of all visited tableaus. Any alternate-selector counters must
state their instrumentation scope; baseline uninstrumented work is null or
explicitly unmeasured, never interpreted as zero work.

## Independent diagram and labelled-source replay

For conclusive calls, run the independent native
`verify_crushing_recognition` against a freshly reconstructed original PD.
For INCONCLUSIVE, run `verify_crushing_chain` on the complete partial chain.
Both arms must use the genuine v5 mixed-chain language and geometric
macro packets; no supplied-source premise stubs or policy-specific verifier
relaxation is allowed. Solver discovery is disabled during final replay.

Reconstruct the full labelled path from the chain's source triangulation,
authenticated shelling and each accepted successor. Compare source digests
and literal typed tables; triangle/tetrahedron counts or isomorphism alone
do not establish equality. Check source/successor binding at every packet,
strict decrease for accepted operations, D versus UDD elementary counts,
all accepted-operation totals, initial/shelled/final counts, and the terminal
None endpoint for the circle when returned. Map every logged Euler source
to the corresponding exact chain state. Retain all such source states for
both arms, even when their paths diverge.

For each diagram report the first labelled divergence if any, the common
labelled prefix length, exact typed final-source equality, and each arm's
endpoint summary. Same endpoint or same verdict must be observed, not
assumed. Do not reuse historical h values without their separate exact
source binding and archived proof replay. A proof replay establishes the
verdict/accepted chain, not every discovery counter or the actual historical
execution order; diagnostic accounting claims remain appropriately limited.

The nine work-cap categories are the existing sector, basis, accepted
reduction, simplex-pivot, anchor, tree-node, hitting-state, ellipsoid-update
and feasibility-call budgets. Preserve their native mappings exactly.
No cap is relaxed to complete a losing arm. Two opposite independently
verified conclusive verdicts are a correctness alarm; an INCONCLUSIVE arm
versus a conclusive arm is a completion difference under the fixed caps.

## Summary and adoption boundary

The complete table has fourteen rows or seven paired rows, retaining status,
reason, nodes, LP calls/pivots/tableau updates, anchors, learned conflicts,
fallback work, accepted normal crushes, each preprocessing operation count,
and final tetrahedron/source identity. Report all regressions, including
extra work on easy envelope queries, and distinguish complete from capped
comparisons. There are no wall-time ratios, paired timing medians, or
inferences from aggregate counts with unequal completion.

Exact finite coverage is seven literal PDs times two declared arms; both
must use the same freshly pinned prepared native source. The final checker
binds configs, source and script pins, all fourteen full outcomes, actual
query chronology records, source ledgers and final summaries. This is a
new experiment with its own pins; no historical package is edited or made
to accept a new policy implicitly.

If controls and all evidence replays pass, the experiment supplies evidence
for evaluating a native polynomial-prefix default change. It does not make
that change, promise it improves every instance, or improve the general
quasi-polynomial complexity theorem. Root schedules implementation and each
execution phase separately after reviewing this design.


Implementation clarification before freeze: the candidate adds cancellation polls inside its entering and lexicographic selector scans. Existing native pivot accounting is retained, but callback positions/counts are deliberately different. Controls check exception identity and nested restoration rather than equality of callback counts. The scratch selector module is named pivot_selectors.py to avoid shadowing Python's standard-library selectors module.


## Frozen implementation checklist and commands

The isolated source is revision `4d1f76f061ac961ee75c4d7d8b067b5fa0ac30f7`,
with 301 native files; no current-worktree import is permitted. The two-selector
AST edit retains tuple-safe current tableau construction and restores exactly
to the original AST after replacing those two expressions back.

Preflight retains 22 polynomial-policy records (11 cases times two arms),
10 explicit legacy Bland records, 96 nesting records (both arms, both outer
and inner policies, both public and prepared outer and inner entry points,
and normal/Exception/BaseException exits), two complete callback-position
sweeps on the small fixture, and eight invalid-control checks. Cases include
unreduced dependent/zero rows, rational inputs, 128/132-bit coefficients,
forced positive and negative fallback, and retained capped failures.

Every query allowance is derived independently from the actual answers of
all preceding queries within its source search. Query sums bind each source
search and then the complete driver sums. Unreturned work records carry
literal zero lower bounds for pivots, updates and fallback work, explicitly
marked unmeasured; this does not assert that interrupted work was zero.
The positive attempt, source-search result and accepted crushing coordinates
are compared literally as observed evidence, not inferred from a zero
extraction-descent counter. Full original rows and proofs remain retained.

Run only after the root schedules each phase, from this scratch directory:

```
python -B -S runner.py controls --out controls.json
python -B -S runner.py audit --controls controls.json --out audit.json
python -B -S runner.py check --controls controls.json --audit audit.json
```

Retain stdout/stderr in separate logs. Outputs refuse overwrite. Final replay
disables the native recognition, Euler/mask and sector/ray discovery, topology
producer and LP entry points together with loaded aliases. It permits exact
source-algebra assembly and independent proof verification. There are no
timings, elapsed ratios, repeat selection or inferred general complexity gains.
Controls should be small (seconds to a few minutes); fourteen whole calls
may take tens of minutes or longer because all original finite pivot caps,
uncapped polynomial preprocessing and independent exact replays are retained.
Expect tens of MB rather than per-pivot tableau storage; no wall cutoff or
storage truncation changes the experiment's coverage.
