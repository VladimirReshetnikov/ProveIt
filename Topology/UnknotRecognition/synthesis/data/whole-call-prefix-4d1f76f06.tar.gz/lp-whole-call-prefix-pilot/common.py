"""Fixed whole-call inputs, caps, isolated imports and byte-bound evidence."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SNAPSHOT = ROOT / 'snapshot'
sys.path.insert(0, str(SNAPSHOT / 'native'))
if not __debug__:
    raise RuntimeError('Evidence checks require assertions enabled')
from fastunknot.integer_codec import encoded_integer, json_safe

REVISION = '4d1f76f061ac961ee75c4d7d8b067b5fa0ac30f7'
MANIFEST_SHA256 = '3210a913e354fa10ca71763471477b8afc55bcfd31b0615a367b99e6d3e29f50'
ARMS = ('prepared_bland', 'prepared_dantzig_lex')
CASE_IDS = ('circle', 'trefoil', 'figure_eight', 'TT', 'T25', 'T27', 'W34')
FILES = ('common.py', 'pivot_selectors.py', 'lp_check.py', 'observer.py',
         'check_evidence.py', 'controls.py', 'runner.py', 'inputs.json', 'PROTOCOL.md')
OPTIONS = dict(max_sectors=256, max_bases=10000, max_crushes=None,
    sector_order='diversified', sector_quantum=64, sector_method='transversal',
    max_pivots=10000, max_anchors=10000, lp_strategy='envelope',
    reduce_vertices=True, unlayer_boundary=True, reduce_pachner32=True,
    reduce_pachner_descent=True, pachner_descent_method='geometric',
    max_tree_nodes=256, tree_model='source', max_hitting_subsets=10000,
    transversal_candidate_policy='conflicts', lp_policy='polynomial',
    lp_fast_path_pivots=None, max_ellipsoid_iterations=10000,
    max_feasibility_calls=10000)
CAP_STATS = {
    'max_sectors': ('sectors_attempted',), 'max_bases': ('bases_attempted',),
    'max_crushes': ('crushing_steps', 'boundary_unlayerings', 'pachner32_moves', 'pachner_descent_macros'),
    'max_pivots': ('lp_pivots',), 'max_anchors': ('anchors_tested',),
    'max_tree_nodes': ('nodes_attempted',), 'max_hitting_subsets': ('hitting_subsets_tested',),
    'max_ellipsoid_iterations': ('lp_ellipsoid_iterations',),
    'max_feasibility_calls': ('lp_feasibility_calls',),
}
SEARCH_SUM_FIELDS = ('lp_calls', 'lp_pivots', 'lp_tableau_updates', 'anchors_tested',
    'reused_anchors', 'envelope_calls', 'reused_envelopes', 'nodes_attempted',
    'branch_splits', 'negative_leaves', 'positive_relaxations',
    'incompatible_positive_points', 'nonpositive_envelope_points',
    'kernel_preparations', 'hitting_subsets_tested', 'transversal_candidates',
    'transversal_restarts', 'learned_conflicts', 'conflict_cache_evictions',
    'lp_fallbacks', 'lp_ellipsoid_iterations', 'lp_feasibility_calls', 'lp_support_descent_steps')
LP_SUM_FIELDS = {'pivots': 'lp_pivots', 'tableau_updates': 'lp_tableau_updates',
    'fallback_used': 'lp_fallbacks', 'ellipsoid_iterations': 'lp_ellipsoid_iterations',
    'feasibility_calls': 'lp_feasibility_calls', 'support_descent_steps': 'lp_support_descent_steps'}
SMALL_CASES = (
    ('positive_degenerate', [[1,1,-1]], [1,1,0], {}, 'POSITIVE'),
    ('dependent_dual', [[1,-1],[2,-2],[0,0]], [1,-2], {}, 'NONPOSITIVE'),
    ('zero_width', [[],[]], [], {}, 'NONPOSITIVE'),
    ('zero_user', [[1,-1]], [1,0], {'max_pivots':0}, 'INCONCLUSIVE'),
    ('one_user', [[1,-1]], [1,0], {'max_pivots':1}, 'INCONCLUSIVE'),
    ('forced_fallback', [[1,-1]], [1,0], {'fast_path_pivots':0}, 'POSITIVE'),
    ('dependent_unreduced', [[1,-1],[2,-2],[0,0]], [1,-2], {'reduce_rows':False}, 'NONPOSITIVE'),
    ('exact_rational', [[Fraction(1,3),Fraction(-2,5)]], [Fraction(2,7),Fraction(1,11)], {}, 'POSITIVE'),
    ('large_coefficient', [[2**127+1,-(2**131+3)]], [1,1], {}, 'POSITIVE'),
    ('forced_negative_fallback', [[1,-1]], [1,-2], {'fast_path_pivots':0}, 'NONPOSITIVE'),
    ('capped_fallback', [[1,-1]], [1,0], {'fast_path_pivots':0,'max_ellipsoid_iterations':0}, 'INCONCLUSIVE'),
)


def canonical(value):
    return json.dumps(json_safe(value), sort_keys=True, separators=(',', ':')).encode()


def digest(value):
    return sha256(canonical(value)).hexdigest()


def file_digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def same(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
    if type(a) in (list, tuple):
        return len(a) == len(b) and all(same(x,y) for x,y in zip(a,b))
    return a == b


def rational(value):
    if type(value) is Fraction:
        return value
    if type(value) in (list, tuple):
        assert len(value) == 2
        a,b = map(encoded_integer, value)
        assert b > 0
        return Fraction(a,b)
    return Fraction(encoded_integer(value))


def pairs(values):
    return [[x.numerator,x.denominator] for x in map(rational,values)]


def bank_put(bank, value):
    value = json_safe(value)
    key = digest(value)
    if key in bank:
        assert same(bank[key],value), 'Digest collision or typed-value mismatch'
    else:
        bank[key] = value
    return key


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_bytes(canonical(value)+b'\n')
    temporary.replace(path)


def pins():
    manifest_path = SNAPSHOT/'manifest.json'
    assert file_digest(manifest_path) == MANIFEST_SHA256
    manifest = json.loads(manifest_path.read_bytes())
    assert manifest['revision'] == REVISION
    actual = {str(p.relative_to(SNAPSHOT)):file_digest(p) for p in sorted(SNAPSHOT.rglob('*'))
              if p.is_file() and p != manifest_path and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    assert actual == manifest['files']
    for name,module in tuple(sys.modules.items()):
        if name == 'fastunknot' or name.startswith('fastunknot.'):
            filename = getattr(module,'__file__',None)
            if filename is not None:
                assert Path(filename).resolve().is_relative_to(SNAPSHOT/'native')
    return dict(revision=REVISION, snapshot_manifest_sha256=MANIFEST_SHA256,
        native_files=actual, experiment_files={name:file_digest(ROOT/name) for name in FILES})


def cases():
    from fastunknot.diagram import Diagram
    fixture = json.loads((ROOT/'inputs.json').read_bytes())
    records = fixture['cases']
    assert tuple(r['id'] for r in records) == CASE_IDS
    result = []
    for record in records:
        braid = record['braid']
        diagram = Diagram.from_pd([]) if braid is None else Diagram.from_braid(braid['strands'],braid['word'])
        assert same([list(row) for row in diagram.pd],record['input_pd'])
        result.append(record)
    return result


def new_document(schema):
    return dict(schema=schema, pins=pins(), passed=False, failures=[], active=None,
        wall_limit_seconds=None, timings_claimed=False, general_quasipolynomial_claimed=False)


def fail(document, phase, error):
    document['passed'] = False
    document['failures'].append(dict(phase=phase, exception_class=type(error).__name__,
        message=str(error), work_complete=False))
