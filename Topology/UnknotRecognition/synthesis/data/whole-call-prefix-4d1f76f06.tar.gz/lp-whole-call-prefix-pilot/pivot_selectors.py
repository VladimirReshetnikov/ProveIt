"""Exactly two AST substitutions in the frozen current tuple-safe tableau."""
import ast
from contextlib import contextmanager
from copy import deepcopy
from unittest.mock import patch

from common import ARMS, SNAPSHOT, digest
from fastunknot import exact_lp

ORIGINAL_HELPER = exact_lp._solve_prepared_kernel
ORIGINAL_CONTROLLER = exact_lp._run_kernel_policy


def _entering(reduced, check):
    selected = None
    for j,value in enumerate(reduced):
        check()
        if value > 0 and (selected is None or value > reduced[selected]):
            selected = j
    return selected


def _leaving(candidates, tableau, rhs, basis, column, n, check):
    chosen, best = None, None
    for i in candidates:
        check()
        a = tableau[i][column]
        key = [rhs[i]/a]
        for value in tableau[i][n:]:
            check()
            key.append(value/a)
        key = tuple(key)
        if best is None or key < best:
            chosen,best = i,key
    return chosen


def candidate():
    path = SNAPSHOT/'native/fastunknot/exact_lp.py'
    module = ast.parse(path.read_bytes(), filename=str(path))
    original = next(node for node in module.body if isinstance(node,ast.FunctionDef)
                    and node.name == '_solve_prepared_kernel')
    altered = deepcopy(original)
    expected = {
        'entering': 'next((j for j, coefficient in enumerate(reduced) if coefficient > 0), None)',
        'leaving': 'min(candidates, key=lambda i: (rhs[i]/tableau[i][entering], basis[i]))',
    }
    replacement = {
        'entering': '_scratch_entering(reduced, check)',
        'leaving': '_scratch_leaving(candidates, tableau, rhs, basis, entering, n, check)',
    }
    changed = []
    for node in ast.walk(altered):
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            name = node.targets[0].id
            if name in expected:
                assert ast.dump(node.value) == ast.dump(ast.parse(expected[name],mode='eval').body)
                node.value = ast.copy_location(ast.parse(replacement[name],mode='eval').body,node.value)
                changed.append(name)
    assert sorted(changed) == ['entering','leaving']
    restored = deepcopy(altered)
    for node in ast.walk(restored):
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            name=node.targets[0].id
            if name in expected:
                node.value=ast.parse(expected[name],mode='eval').body
    assert ast.dump(restored) == ast.dump(original), 'Change outside the two selectors'
    # Explicitly bind the current tuple-safe tableau construction.
    text=ast.unparse(original)
    assert 'tableau.append([*row,' in text
    namespace=dict(vars(exact_lp),_scratch_entering=_entering,_scratch_leaving=_leaving)
    tree=ast.fix_missing_locations(ast.Module(body=[altered],type_ignores=[]))
    exec(compile(tree,str(path)+'::two-selector-scratch','exec'),namespace)
    metadata=dict(original_ast_sha256=digest(ast.dump(original)),
        candidate_ast_sha256=digest(ast.dump(altered)), substitutions=['entering','leaving'],
        tuple_safe=True, restored_ast_equal=True)
    return namespace['_solve_prepared_kernel'],metadata


@contextmanager
def installed(arm, observer=None, dispatch_log=None):
    assert arm in ARMS
    candidate_helper,metadata=candidate()
    assert exact_lp._run_kernel_policy is ORIGINAL_CONTROLLER
    assert exact_lp._solve_prepared_kernel is ORIGINAL_HELPER

    def controller(prepared,cost,**kwargs):
        policy=kwargs['policy']
        assert policy in ('polynomial','bland')
        use_candidate=arm=='prepared_dantzig_lex' and policy=='polynomial'
        helper=candidate_helper if use_candidate else ORIGINAL_HELPER
        if dispatch_log is not None:
            dispatch_log.append(dict(policy=policy,candidate=use_candidate))
        token=observer.begin_query(prepared,cost,kwargs,use_candidate) if observer else None
        options=dict(kwargs)
        if observer:
            original_check=options['check']
            def checked():
                token['callback_calls']+=1
                original_check()
            options['check']=checked
        try:
            # patch.object remembers the CURRENT helper, so nested calls,
            # nested exceptions and explicit Bland calls restore correctly.
            with patch.object(exact_lp,'_solve_prepared_kernel',helper):
                answer=ORIGINAL_CONTROLLER(prepared,cost,**options)
            if observer:
                observer.end_query(token,answer)
            return answer
        except BaseException as error:
            if observer:
                observer.query_failure(token,error)
            raise

    try:
        with patch.object(exact_lp,'_run_kernel_policy',controller):
            yield metadata
    finally:
        assert exact_lp._run_kernel_policy is ORIGINAL_CONTROLLER
        assert exact_lp._solve_prepared_kernel is ORIGINAL_HELPER
