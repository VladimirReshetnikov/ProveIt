"""Record real native source searches, mask attempts, and prepared LP calls."""
from contextlib import contextmanager
from copy import deepcopy
import inspect
from unittest.mock import patch

from common import bank_put, digest, json_safe, pairs, save
from lp_check import check_lp


class Observer:
    def __init__(self,document,slot,path):
        self.document,self.slot,self.path=document,slot,path
        self.search_stack=[]
        self.attempt_stack=[]
        self.original_attempt=None

    def persist(self,phase):
        self.slot['active_phase']=phase
        save(self.path,self.document)

    def begin_query(self,prepared,cost,kwargs,candidate):
        assert len(self.search_stack)==len(self.attempt_stack)==1
        state=self.attempt_stack[-1]
        assert prepared is state['prepared'], 'Different matrix within an attempt'
        attempt=state['record']
        frame=inspect.currentframe().f_back
        while frame is not None and frame.f_code is not self.original_attempt.__code__:
            frame=frame.f_back
        assert frame is not None
        anchors=frame.f_locals.get('anchors')
        matrix=dict(width=prepared.width,source=[pairs(row) for row in prepared.source],
            selected=list(prepared.selected),reduce_rows=prepared.reduce_rows)
        key=bank_put(self.slot['matrix_bank'],matrix)
        options={k:v for k,v in kwargs.items() if k!='check'}
        options['reduce_rows']=prepared.reduce_rows
        record=dict(index=len(self.slot['queries']),search_index=self.search_stack[-1]['index'],
            attempt_index=attempt['index'],matrix_key=key,objective=pairs(cost),options=options,
            kind='envelope' if anchors is None else 'anchors',
            anchors=None if anchors is None else list(anchors),candidate_selector=candidate,
            callback_calls=0,returned=False,proof_replayed=False,
            unreturned_statistics_are_lower_bounds=True,unmeasured_work=True,
            work_lower_bounds=dict(pivots=0,tableau_updates=0,ellipsoid_iterations=0,feasibility_calls=0),failures=[])
        self.slot['queries'].append(record)
        attempt['query_indices'].append(record['index'])
        self.persist(dict(kind='lp_query',index=record['index']))
        return record

    def end_query(self,record,answer):
        record.update(returned=True,result=json_safe(answer),result_sha256=digest(answer),
            unreturned_statistics_are_lower_bounds=False,unmeasured_work=False,
            work_lower_bounds={name:answer['stats'][name] for name in (
                'pivots','tableau_updates','ellipsoid_iterations','feasibility_calls')})
        self.persist(dict(kind='lp_replay',index=record['index']))
        matrix=self.slot['matrix_bank'][record['matrix_key']]
        record['replay']=check_lp(matrix['source'],record['objective'],record['options'],answer)
        record['proof_replayed']=True
        self.persist(dict(kind='mask_attempt',index=record['attempt_index']))

    def query_failure(self,record,error):
        record['failures'].append(dict(exception_class=type(error).__name__,message=str(error),
            result_returned=record['returned'],work_complete=False))
        self.persist(dict(kind='failed_lp_query',index=record['index']))

    @contextmanager
    def installed(self):
        from fastunknot import normal_euler_tree as tree
        from fastunknot import normal_euler_transversal as transversal
        search_native=transversal.search_euler_transversal
        attempt_native=tree._EulerMaskOracle.attempt
        prepare_native=tree._prepare_kernel_matrix
        self.original_attempt=attempt_native

        def search(source,*args,**kwargs):
            assert not args and not self.search_stack
            record=dict(index=len(self.slot['searches']),source_key=bank_put(self.slot['source_bank'],source),
                options={k:v for k,v in kwargs.items() if k!='check'},attempt_indices=[],
                returned=False,failures=[])
            self.slot['searches'].append(record)
            self.search_stack.append(record)
            self.persist(dict(kind='source_search',index=record['index']))
            try:
                answer=search_native(source,**kwargs)
                record.update(returned=True,result=json_safe(answer),result_sha256=digest(answer))
                self.persist(dict(kind='driver_after_search',index=record['index']))
                return answer
            except BaseException as error:
                record['failures'].append(dict(exception_class=type(error).__name__,message=str(error),work_complete=False))
                self.persist(dict(kind='failed_source_search',index=record['index']))
                raise
            finally:
                self.search_stack.pop()

        def attempt(oracle,mask):
            assert len(self.search_stack)==1 and not self.attempt_stack
            search_record=self.search_stack[-1]
            source_key=bank_put(self.slot['source_bank'],oracle.triangulation)
            assert source_key==search_record['source_key']
            record=dict(index=len(self.slot['attempts']),search_index=search_record['index'],
                source_key=source_key,allowed_types=[list(pair) for pair in mask],
                query_indices=[],preparations_started=0,preparations_returned=0,
                stats_before=deepcopy(oracle.stats),returned=False,failures=[])
            self.slot['attempts'].append(record)
            search_record['attempt_indices'].append(record['index'])
            state=dict(record=record,prepared=None)
            self.attempt_stack.append(state)
            self.persist(dict(kind='mask_attempt',index=record['index']))
            try:
                answer=attempt_native(oracle,mask)
                record.update(returned=True,result=json_safe(answer),result_sha256=digest(answer),
                              stats_after=deepcopy(oracle.stats))
                self.persist(dict(kind='source_search',index=search_record['index']))
                return answer
            except BaseException as error:
                record['failures'].append(dict(exception_class=type(error).__name__,message=str(error),work_complete=False))
                self.persist(dict(kind='failed_mask_attempt',index=record['index']))
                raise
            finally:
                self.attempt_stack.pop()

        def prepare(matrix,width,**kwargs):
            assert len(self.attempt_stack)==1
            state=self.attempt_stack[-1]
            assert state['prepared'] is None
            state['record']['preparations_started']+=1
            answer=prepare_native(matrix,width,**kwargs)
            state['prepared']=answer
            state['record']['preparations_returned']+=1
            return answer

        with patch.object(transversal,'search_euler_transversal',search), \
             patch.object(tree._EulerMaskOracle,'attempt',attempt), \
             patch.object(tree,'_prepare_kernel_matrix',prepare):
            yield
