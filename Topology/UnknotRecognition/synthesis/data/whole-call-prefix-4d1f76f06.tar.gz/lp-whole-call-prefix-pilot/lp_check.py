"""Independent exact rational kernel proof replay; no discovery."""
from fractions import Fraction as Q
from math import gcd
from common import rational
from fastunknot.integer_codec import encoded_integer

def rank(matrix, width):
    """Independent reverse-column, last-row exact elimination."""
    rows = [[rational(x) for x in row] for row in matrix]
    assert all(len(row) == width for row in rows)
    count = 0
    for column in reversed(range(width)):
        candidates = [i for i in range(count, len(rows)) if rows[i][column]]
        if not candidates:
            continue
        chosen = candidates[-1]
        rows[count], rows[chosen] = rows[chosen], rows[count]
        divisor = rows[count][column]
        rows[count] = [x/divisor for x in rows[count]]
        for i in range(count + 1, len(rows)):
            factor = rows[i][column]
            if factor:
                rows[i] = [a-factor*b for a, b in zip(rows[i], rows[count])]
        count += 1
    return count


def check_lp(matrix, objective, options, answer):
    """Original-row primal/dual, extreme support and feasible slack-basis checks."""
    matrix = [[rational(x) for x in row] for row in matrix]
    cost = list(map(rational, objective))
    n = len(cost)
    assert all(len(row) == n for row in matrix)
    assert type(answer) is dict
    status, stats = answer['status'], answer['stats']
    assert status in ('POSITIVE', 'NONPOSITIVE', 'INCONCLUSIVE')
    assert type(stats) is dict
    for value in stats.values():
        assert type(value) is int and value >= 0
    rows = answer['equation_rows']
    assert type(rows) is list and all(type(i) is int for i in rows)
    assert rows == sorted(set(rows)) and all(0 <= i < len(matrix) for i in rows)
    selected = [matrix[i] for i in rows]
    full_rank = rank(matrix, n)
    assert rank(selected, n) == full_rank
    if options.get('reduce_rows', True):
        assert len(rows) == full_rank
    else:
        assert rows == list(range(len(matrix)))
    r, m = len(rows), 2*len(rows)+1
    assert stats['variables'] == n and stats['equations'] == len(matrix)
    assert stats['retained_equations'] == r and stats['tableau_rows'] == m
    assert stats['tableau_columns'] == n+m
    policy = options.get('policy', 'polynomial')
    assert policy in ('polynomial', 'bland')
    assert all(key in stats for key in ('pivots', 'tableau_updates', 'maximum_tableau_bits'))
    if policy == 'bland':
        assert all(options.get(k) is None for k in ('fast_path_pivots', 'max_ellipsoid_iterations', 'max_feasibility_calls'))
        if options.get('max_pivots') is not None:
            assert stats['pivots'] <= options['max_pivots']
        assert 'fallback_used' not in stats
    else:
        required = ('pivots', 'tableau_updates', 'maximum_tableau_bits',
            'polynomial_pivot_limit', 'fast_path_pivot_limit', 'fallback_used',
            'ellipsoid_iterations', 'feasibility_calls', 'maximum_ellipsoid_precision',
            'maximum_ellipsoid_dimension', 'maximum_planned_ellipsoid_iterations',
            'support_descent_steps')
        assert all(key in stats for key in required)
        assert options.get('policy', 'polynomial') == 'polynomial'
        limit = (n+r+1)**2
        assert stats['polynomial_pivot_limit'] == limit
        if options.get('fast_path_pivots') is not None:
            limit = min(limit, options['fast_path_pivots'])
        assert stats['fast_path_pivot_limit'] == limit
        if options.get('max_pivots') is not None:
            limit = min(limit, options['max_pivots'])
        assert stats['pivots'] <= limit
        for option, field in (('max_ellipsoid_iterations', 'ellipsoid_iterations'),
                               ('max_feasibility_calls', 'feasibility_calls')):
            if options.get(option) is not None:
                assert stats[field] <= options[option]
        assert stats['fallback_used'] in (0, 1)
        if not stats['fallback_used']:
            assert all(stats[field] == 0 for field in (
                'ellipsoid_iterations', 'feasibility_calls', 'maximum_ellipsoid_precision',
                'maximum_ellipsoid_dimension', 'maximum_planned_ellipsoid_iterations',
                'support_descent_steps'))
        else:
            assert stats['pivots'] == stats['fast_path_pivot_limit']
            assert options.get('max_pivots') is None or stats['pivots'] < options['max_pivots']
    if status == 'INCONCLUSIVE':
        assert set(answer) == {'status', 'reason', 'equation_rows', 'stats'}
        assert type(answer['reason']) is str and answer['reason']
        if not stats.get('fallback_used', 0):
            assert answer['reason'] == 'LP pivot allowance exhausted'
            assert options.get('max_pivots') is not None
            assert stats['pivots'] == options['max_pivots']
        return dict(status=status, certificate_verified=False, support_rank=None)
    if status == 'NONPOSITIVE':
        assert set(answer) == {'status', 'y', 'equation_rows', 'stats'}
        y = list(map(rational, answer['y']))
        assert len(y) == len(matrix)
        assert all(sum(row[j]*a for row, a in zip(matrix, y)) >= cost[j] for j in range(n))
        return dict(status=status, certificate_verified=True, support_rank=None)
    assert set(answer) == {'status', 'x', 'primitive_x', 'objective', 'basis', 'equation_rows', 'stats'}
    x = list(map(rational, answer['x']))
    assert len(x) == n and all(a >= 0 for a in x) and sum(x, Q(0)) == 1
    assert all(sum(a*b for a, b in zip(row, x)) == 0 for row in matrix)
    value = sum(a*b for a, b in zip(cost, x))
    assert value > 0 and value == rational(answer['objective'])
    primitive = [encoded_integer(a) for a in answer['primitive_x']]
    assert len(primitive) == n and all(a >= 0 for a in primitive)
    common = 0
    for a in primitive:
        common = gcd(common, a)
    assert common == 1
    assert x == [Q(a, sum(primitive)) for a in primitive]
    support = [j for j, a in enumerate(x) if a]
    support_rank = rank([[row[j] for j in support] for row in matrix], len(support))
    assert len(support)-support_rank == 1
    basis = answer['basis']
    assert type(basis) is list and len(basis) == m and len(set(basis)) == m
    assert all(type(j) is int and 0 <= j < n+m for j in basis)
    assert set(support) <= set(basis)
    # Independent full original-slack rank plus a feasible represented point.
    # Original matching rows and normalization give every slack value zero.
    # Thus all nonbasic entries are zero, and the nonsingular basis realizes x.
    inequalities = selected + [[-a for a in row] for row in selected] + [[Q(1)]*n]
    basic_matrix = [[row[j] if j < n else Q(j-n == i) for j in basis]
                    for i, row in enumerate(inequalities)]
    assert rank(basic_matrix, m) == m
    augmented_point = x + [Q(0)]*m
    rhs = [Q(0)]*(m-1) + [Q(1)]
    assert all(sum(a*augmented_point[j] for a, j in zip(row, basis)) == b
               for row, b in zip(basic_matrix, rhs))
    return dict(status=status, certificate_verified=True, support_rank=support_rank)

