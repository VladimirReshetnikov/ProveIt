"""Discovery-free proof, labelled-source, cap and coverage checks."""
from fractions import Fraction

from common import (ARMS, CASE_IDS, OPTIONS, CAP_STATS, SEARCH_SUM_FIELDS,
    LP_SUM_FIELDS, bank_put, cases, digest, encoded_integer, pairs, pins, same)
from lp_check import check_lp
from fastunknot.diagram import Diagram
from fastunknot.normal_crushing_chain import verify_crushing_chain
from fastunknot.normal_crushing_search import verify_crushing_recognition
from fastunknot.normal_surface_geometry import _prepare, _coordinates, _EDGES, _quad
from fastunknot.normal_euler_tree_verify import (
    verify_euler_relaxation_certificate, verify_euler_branch_tree)
from fastunknot.normal_geometric_descent_verify import verify_normal_geometric_descent


def nonnegative_ints(stats):
    assert type(stats) is dict
    assert all(type(k) is str and type(v) is int and v >= 0 for k,v in stats.items())


def endpoint(source):
    if source is None:
        return dict(terminal=True,source_sha256=None,tetrahedra=None,vertices=None,boundary_faces=None)
    prepared=_prepare(source,lambda:None)
    return dict(terminal=False,source_sha256=digest(source),tetrahedra=len(source['tetrahedra']),
                vertices=prepared['vertices'],boundary_faces=len(prepared['boundary_faces']))


def formal_point(prepared,result):
    rows=[[encoded_integer(x) for x in row] for row in result['coordinates']]
    assert len(rows)==len(prepared['tetrahedra']) and all(len(row)==7 for row in rows)
    flat=[x for row in rows for x in row]
    assert all(x>=0 for x in flat)
    assert all(sum(a*flat[j] for j,a in equation.items())==0 for equation in prepared['matching'])
    minima,edges={},{}
    for t,row in enumerate(rows):
        for v in range(4):
            vertex=prepared['vertex_roots'][4*t+v]
            minima[vertex]=min(minima.get(vertex,row[v]),row[v])
        for e,(a,b) in enumerate(_EDGES):
            edge=prepared['edge_roots'][6*t+e]
            value=row[a]+row[b]+sum(row[4:])-row[4+_quad(a,b)]
            if edge in edges:
                assert edges[edge]==value
            edges[edge]=value
    assert not any(minima.values())
    faces=prepared['boundary_faces']+[(t,f) for t,f,_,_,_ in prepared['pairs']]
    arcs=sum(sum(rows[t][v] for v in range(4) if v!=f)+sum(rows[t][4:]) for t,f in faces)
    chi=sum(edges.values())-arcs+sum(flat)
    assert type(result['euler_characteristic']) is int and result['euler_characteristic']==chi>0
    conflicts=[t for t,row in enumerate(rows) if sum(bool(x) for x in row[4:])>1]
    if 'conflicts' in result:
        assert same(result['conflicts'],conflicts)
    return rows,conflicts


def chain_replay(slot):
    result=slot['result']
    diagram=Diagram.from_pd(slot['input_pd'])
    assert result['status'] in ('UNKNOT','KNOTTED','INCONCLUSIVE')
    if result['status']=='INCONCLUSIVE':
        assert set(result)=={'status','reason','stats','partial_chain'}
        assert type(result['reason']) is str and result['reason']
        chain=result['partial_chain']
        assert verify_crushing_chain(diagram,chain)
        assert chain['status']=='REDUCED'
    else:
        assert set(result)=={'status','certificate','stats'}
        assert verify_crushing_recognition(diagram,result['certificate'])
        assert result['certificate']['status']==result['status']
        chain=result['certificate']['chain']
    assert chain['schema']=='diagram-crushing-v5'
    assert same(chain['input_pd'],slot['input_pd'])
    stats=result['stats']
    nonnegative_ints(stats)
    for cap,fields in CAP_STATS.items():
        assert all(field in stats for field in fields)
        assert OPTIONS[cap] is None or sum(stats[field] for field in fields)<=OPTIONS[cap]
    current=chain['source_triangulation']
    initial_count=len(current['tetrahedra'])
    ledger=[dict(kind='initial',source_key=bank_put(slot['source_bank'],current))]
    shell=chain['shelling']
    if shell is not None:
        current=shell['triangulation']
    ledger.append(dict(kind='shelled',source_key=bank_put(slot['source_bank'],current)))
    shelled_count=len(current['tetrahedra'])
    mapping={'normal-ray-crushing-v1':'crushing_steps',
        'normal-boundary-unlayer-v1':'boundary_unlayerings',
        'normal-pachner-32-v1':'pachner32_moves',
        'normal-geometric-descent-v1':'pachner_descent_macros'}
    counts={field:0 for field in mapping.values()}
    up=down=0
    for i,step in enumerate(chain['steps']):
        assert current is not None and step['schema'] in mapping
        source_key=bank_put(slot['source_bank'],current)
        if step['schema']!='normal-ray-crushing-v1':
            assert step['source_sha256']==source_key
        successor=step['successor']
        assert successor is None or len(successor['tetrahedra'])<len(current['tetrahedra'])
        extra={}
        if step['schema']=='normal-geometric-descent-v1':
            assert verify_normal_geometric_descent(current,step)
            moves=step['steps']
            kinds=[move['certificate']['schema'] for move in moves]
            assert kinds in (['pachner-32-v1'],['pachner-23-v1','pachner-32-v1','pachner-32-v1'])
            n=len(current['tetrahedra'])
            sizes=[len(move['triangulation']['tetrahedra']) for move in moves]
            assert sizes==([n-1] if len(moves)==1 else [n+1,n,n-1])
            assert same(successor,moves[-1]['triangulation'])
            up+=int(len(moves)==3)
            down+=1+int(len(moves)==3)
            extra=dict(word='D' if len(moves)==1 else 'UDD',intermediate_tetrahedra=sizes)
        counts[mapping[step['schema']]]+=1
        ledger.append(dict(kind='step',index=i,schema=step['schema'],source_key=source_key,
            successor_key=None if successor is None else bank_put(slot['source_bank'],successor),
            before_tetrahedra=len(current['tetrahedra']),
            after_tetrahedra=None if successor is None else len(successor['tetrahedra']),**extra))
        current=successor
    assert same(current,chain['triangulation'])
    assert stats['initial_tetrahedra']==initial_count and stats['shelled_tetrahedra']==shelled_count
    assert all(stats[field]==count for field,count in counts.items())
    assert stats['stages']==len(chain['steps'])+int(current is not None)
    assert stats['pachner_descent_upward_moves']==up and stats['pachner_descent_downward_moves']==down
    assert down==counts['pachner_descent_macros']+up
    assert stats['vertex_reduction_crushes']<=counts['crushing_steps']
    assert stats['pachner32_moves']<=stats['pachner32_calls']<=stats['stages']
    assert stats['pachner32_candidates']>=stats['pachner32_moves']
    assert stats['pachner_descent_macros']<=stats['pachner_descent_calls']<=stats['stages']
    assert len(chain['steps'])<=shelled_count
    return ledger,dict(status=result['status'],proof_verified=result['status']!='INCONCLUSIVE',
        partial_chain_verified=result['status']=='INCONCLUSIVE',accepted_counts=counts,
        elementary_macro_upward_moves=up,elementary_macro_downward_moves=down,
        endpoint=endpoint(current),source_preparations=sum(a['preparations_returned'] for a in slot['attempts']))


def query_replay(slot,ledger):
    from fastunknot.normal_sector import _assemble_sector_kernel
    from fastunknot.normal_euler import _euler_model
    source_bank,matrix_bank=slot['source_bank'],slot['matrix_bank']
    assert all(key==digest(body) for key,body in source_bank.items())
    assert all(key==digest(body) for key,body in matrix_bank.items())
    searches,attempts,queries=slot['searches'],slot['attempts'],slot['queries']
    states=[ledger[1]['source_key']]+[r['successor_key'] for r in ledger[2:] if r['successor_key'] is not None]
    assert len(states)==len(set(states)), 'Strict shrinking source states must differ'
    positions={key:i for i,key in enumerate(states)}
    assert all(s['source_key'] in positions for s in searches)
    order=[positions[s['source_key']] for s in searches]
    assert order==sorted(set(order))
    source_models={}
    search_totals={field:0 for field in SEARCH_SUM_FIELDS}
    queries_seen=[]
    attempts_seen=[]
    for si,search in enumerate(searches):
        assert search['index']==si and search['returned'] is True and not search['failures']
        source=source_bank[search['source_key']]
        expected=dict(strategy=OPTIONS['lp_strategy'],candidate_policy=OPTIONS['transversal_candidate_policy'],
            max_nodes=OPTIONS['max_tree_nodes']-search_totals['nodes_attempted'],
            max_pivots=OPTIONS['max_pivots']-search_totals['lp_pivots'],
            max_anchors=OPTIONS['max_anchors']-search_totals['anchors_tested'],
            max_hitting_subsets=OPTIONS['max_hitting_subsets']-search_totals['hitting_subsets_tested'],
            lp_policy='polynomial',lp_fast_path_pivots=None,
            max_ellipsoid_iterations=OPTIONS['max_ellipsoid_iterations']-search_totals['lp_ellipsoid_iterations'],
            max_feasibility_calls=OPTIONS['max_feasibility_calls']-search_totals['lp_feasibility_calls'])
        assert same(search['options'],expected)
        answer=search['result']
        assert search['result_sha256']==digest(answer)
        stats=answer['stats']
        nonnegative_ints(stats)
        source_lp={target:0 for target in LP_SUM_FIELDS.values()}
        source_query_count=0
        assert len(search['attempt_indices'])==stats['nodes_attempted']
        if answer['status']=='NO_POSITIVE_EULER':
            assert verify_euler_branch_tree(source,answer['certificate'])
        elif answer['status']=='POSITIVE_EULER':
            prepared=_prepare(source,lambda:None)
            assert _coordinates(prepared,answer['coordinates'],lambda:None)['euler_characteristic']==answer['euler_characteristic']>0
        else:
            assert answer['status']=='INCONCLUSIVE' and 'certificate' not in answer
        for ai in search['attempt_indices']:
            assert type(ai) is int and 0<=ai<len(attempts)
            attempt=attempts[ai]
            assert attempt['index']==ai and attempt['search_index']==si
            assert attempt['source_key']==search['source_key']
            attempts_seen.append(ai)
            assert attempt['returned'] is True and not attempt['failures']
            assert attempt['result_sha256']==digest(attempt['result'])
            assert type(attempt['preparations_started']) is int and type(attempt['preparations_returned']) is int
            assert attempt['preparations_started']==attempt['preparations_returned']==int(bool(attempt['query_indices']))
            nonnegative_ints(attempt['stats_before'])
            nonnegative_ints(attempt['stats_after'])
            assert all(attempt['stats_before'][field]==used for field,used in source_lp.items())
            assert attempt['stats_before']['lp_calls']==source_query_count
            mask=attempt['allowed_types']
            n=len(source['tetrahedra'])
            assert all(type(pair) is list and len(pair)==2 and all(type(x) is int for x in pair)
                       and 0<=pair[0]<n and 0<=pair[1]<3 for pair in mask)
            assert mask==[list(pair) for pair in sorted(set(map(tuple,mask)))]
            if search['source_key'] not in source_models:
                prepared=_prepare(source,lambda:None)
                full=tuple((t,q) for t in range(n) for q in range(3))
                kernel=_assemble_sector_kernel(source,prepared,full,lambda:None)
                linear,weights=_euler_model(kernel,lambda:None)
                source_models[search['source_key']]=(prepared,kernel,linear,weights)
            prepared,kernel,linear,weights=source_models[search['source_key']]
            active=[3*t+q for t,q in mask]
            expected_matrix=[pairs(row[j] for j in active) for row in kernel.cycle_rows]
            attempt_matrices=set()
            query_sums={target:0 for target in LP_SUM_FIELDS.values()}
            for qi in attempt['query_indices']:
                assert type(qi) is int and 0<=qi<len(queries)
                query=queries[qi]
                assert query['index']==qi and query['attempt_index']==ai and query['search_index']==si
                queries_seen.append(qi)
                assert query['returned'] is True and query['proof_replayed'] is True and not query['failures']
                assert query['unreturned_statistics_are_lower_bounds'] is False
                assert query['unmeasured_work'] is False
                nonnegative_ints(query['work_lower_bounds'])
                assert query['work_lower_bounds']=={name:query['result']['stats'][name] for name in (
                    'pivots','tableau_updates','ellipsoid_iterations','feasibility_calls')}
                assert type(query['callback_calls']) is int and query['callback_calls']>=0
                assert query['candidate_selector'] is (slot['arm']=='prepared_dantzig_lex')
                matrix=matrix_bank[query['matrix_key']]
                attempt_matrices.add(query['matrix_key'])
                assert set(matrix)=={'width','source','selected','reduce_rows'}
                assert type(matrix['selected']) is list and all(type(i) is int and i>=0 for i in matrix['selected'])
                assert matrix['width']==len(active) and type(matrix['width']) is int
                assert matrix['reduce_rows'] is True and matrix['source']==expected_matrix
                objective=list(linear)
                if query['kind']=='envelope':
                    assert query['anchors'] is None
                    for group,weight in zip(kernel.groups,weights):
                        for j in range(len(objective)):
                            objective[j]-=weight*min(kernel.potentials[c][j] for c in group)
                else:
                    assert query['kind']=='anchors'
                    anchors=query['anchors']
                    assert len(anchors)==len(kernel.groups)
                    assert all(type(a) is int and a in group for a,group in zip(anchors,kernel.groups))
                    for a,weight in zip(anchors,weights):
                        for j,value in enumerate(kernel.potentials[a]):
                            objective[j]-=weight*value
                assert query['objective']==pairs(objective[j] for j in active)
                expected_options=dict(policy='polynomial',reduce_rows=True,fast_path_pivots=None,
                    max_pivots=expected['max_pivots']-source_lp['lp_pivots'],
                    max_ellipsoid_iterations=expected['max_ellipsoid_iterations']-source_lp['lp_ellipsoid_iterations'],
                    max_feasibility_calls=expected['max_feasibility_calls']-source_lp['lp_feasibility_calls'])
                assert same(query['options'],expected_options)
                outcome=query['result']
                assert outcome['equation_rows']==matrix['selected']
                assert query['result_sha256']==digest(outcome)
                assert query['replay']==check_lp(matrix['source'],query['objective'],query['options'],outcome)
                for raw,target in LP_SUM_FIELDS.items():
                    query_sums[target]+=outcome['stats'][raw]
                    source_lp[target]+=outcome['stats'][raw]
                source_query_count+=1
            assert len(attempt_matrices)==int(bool(attempt['query_indices']))
            for target,used in query_sums.items():
                assert attempt['stats_after'][target]-attempt['stats_before'][target]==used
            assert attempt['stats_after']['lp_calls']-attempt['stats_before']['lp_calls']==len(attempt['query_indices'])
            outcome=attempt['result']
            if outcome['status']=='NEGATIVE':
                assert outcome['certificate']['allowed_types']==mask
                assert verify_euler_relaxation_certificate(source,outcome['certificate'])
            elif outcome['status']=='POSITIVE':
                rows,conflicts=formal_point(prepared,outcome)
                assert attempt['query_indices']
                last=queries[attempt['query_indices'][-1]]['result']
                assert last['status']=='POSITIVE'
                q=[0]*(3*n)
                for j,x in zip(active,last['primitive_x']):
                    q[j]=encoded_integer(x)
                assert [x for row in rows for x in row[4:]]==q
            else:
                assert outcome['status']=='INCONCLUSIVE' and 'certificate' not in outcome
        if answer['status']=='POSITIVE_EULER':
            assert search['attempt_indices']
            last_attempt=attempts[search['attempt_indices'][-1]]['result']
            assert last_attempt['status']=='POSITIVE'
            assert same(answer['coordinates'],last_attempt['coordinates'])
            assert same(answer['euler_characteristic'],last_attempt['euler_characteristic'])
            chain=(slot['result']['partial_chain'] if slot['result']['status']=='INCONCLUSIVE' else slot['result']['certificate']['chain'])
            next_steps=[r for r in ledger[2:] if r['source_key']==search['source_key']]
            assert len(next_steps)==1 and next_steps[0]['schema']=='normal-ray-crushing-v1'
            assert same(answer['coordinates'],chain['steps'][next_steps[0]['index']]['coordinates']), 'Observed native LP point differs from accepted crushing point'
        assert all(stats[field]==used for field,used in source_lp.items())
        assert stats['lp_calls']==source_query_count
        for field in SEARCH_SUM_FIELDS:
            search_totals[field]+=stats[field]
    assert attempts_seen==list(range(len(attempts)))
    assert queries_seen==list(range(len(queries)))
    native=slot['result']['stats']
    assert all(native[field]==value for field,value in search_totals.items())
    assert len(queries)==native['lp_calls'] and len(attempts)==native['nodes_attempted']
    for raw,target in LP_SUM_FIELDS.items():
        assert sum(q['result']['stats'][raw] for q in queries)==native[target]
    assert native['maximum_tableau_bits']==max((q['result']['stats']['maximum_tableau_bits'] for q in queries),default=0)
    for field in ('maximum_ellipsoid_precision','maximum_ellipsoid_dimension','maximum_planned_ellipsoid_iterations'):
        assert native[field]==max((q['result']['stats'][field] for q in queries),default=0)
    assert native['maximum_tree_depth']==max((s['result']['stats']['maximum_depth'] for s in searches),default=0)
    for field in ('maximum_transversal_size','maximum_conflict_size','peak_cached_conflicts'):
        assert native[field]==max((s['result']['stats'][field] for s in searches),default=0)
    assert set(matrix_bank)=={q['matrix_key'] for q in queries}
    return dict(source_searches=len(searches),attempts=len(attempts),queries=len(queries),
                matrix_bodies=len(matrix_bank),source_bodies=len(source_bank))


def check_slot(slot,case):
    assert slot['completion']=='RETURNED' and slot['active_phase'] is None
    assert slot['case_id']==case['id'] and slot['arm'] in ARMS
    assert same(slot['input_pd'],case['input_pd']) and same(slot['options'],OPTIONS)
    assert slot['input_pd_sha256']==digest(case['input_pd'])
    assert slot['result_sha256']==digest(slot['result'])
    before=set(slot['source_bank'])
    ledger,summary=chain_replay(slot)
    # The runner explicitly materializes the ledger's source bodies first;
    # a checker must reject omitted bodies rather than silently add them.
    assert set(slot['source_bank'])==before
    expected_sources={ledger[0]['source_key'],ledger[1]['source_key']}
    expected_sources.update(r['successor_key'] for r in ledger[2:] if r['successor_key'] is not None)
    assert set(slot['source_bank'])==expected_sources
    assert same(slot['source_ledger'],ledger)
    summary.update(query_replay(slot,ledger))
    assert slot['replay']==summary
    return summary


def compare_case(left,right):
    paths=[]
    for slot in (left,right):
        ledger=slot['source_ledger']
        keys=[ledger[0]['source_key'],ledger[1]['source_key']]+[r['successor_key'] for r in ledger[2:]]
        paths.append([None if key is None else slot['source_bank'][key] for key in keys])
    common=0
    for a,b in zip(*paths):
        if not same(a,b):
            break
        common+=1
    statuses=[s['result']['status'] for s in (left,right)]
    if all(status!='INCONCLUSIVE' for status in statuses):
        assert statuses[0]==statuses[1], 'Opposite independently verified conclusive verdicts'
    return dict(common_labelled_source_prefix=common,
        first_divergence=None if len(paths[0])==len(paths[1])==common else common,
        source_path_lengths=[len(path) for path in paths],
        exact_typed_endpoint_equality=same(paths[0][-1],paths[1][-1]),
        common_completed_verdict=statuses[0] if statuses[0]==statuses[1]!='INCONCLUSIVE' else None,
        h_transport_claimed=False)


def check_audit(document,control_sha256):
    assert document['schema']=='whole-call-prefix-audit-v1'
    assert same(document['pins'],pins())
    from pivot_selectors import candidate
    assert same(document['patch_metadata'],candidate()[1])
    assert document['controls_sha256']==control_sha256
    assert document['passed'] is True and not document['failures'] and document['active'] is None
    assert document['wall_limit_seconds'] is None and document['timings_claimed'] is False
    assert document['general_quasipolynomial_claimed'] is False
    definitions=cases()
    expected=[(case,arm) for case in definitions for arm in ARMS]
    assert len(document['calls'])==len(expected)==14
    summaries=[]
    for slot,(case,arm) in zip(document['calls'],expected):
        assert slot['arm']==arm
        summaries.append(check_slot(slot,case))
    comparisons=[]
    for i,case in enumerate(definitions):
        comparisons.append(dict(case_id=case['id'],**compare_case(*document['calls'][2*i:2*i+2])))
    assert same(document['comparisons'],comparisons)
    assert same(document['summary'],summaries)
    return dict(calls=14,diagrams=7,arm_order=list(ARMS),
        queries=sum(s['queries'] for s in summaries),
        complete=sum(s['status']!='INCONCLUSIVE' for s in summaries),
        inconclusive=sum(s['status']=='INCONCLUSIVE' for s in summaries),
        discovery_used=False,whole_call_shared_budgets=True)
