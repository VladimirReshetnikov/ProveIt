# Exact Q-coordinate component probe

The single authorized probe passed on 2026-10-13. It used exactly the seven
geometric-arm whole-call endpoints retained in
`Topology/UnknotRecognition/synthesis/data/geometric-descent-audit.json`.
No LP query, recognition discovery, new corpus, timing measurement, or
maintained edit was performed.

**Result: all six nonterminal full-Q matrices have one column-matroid
component spanning every tetrahedron. This decomposition supplies no
smaller subproblem for any of these six sources.**

| Endpoint | Q matrix rows × columns | Rank | Nullity | Components | Tetrahedra in its sole component |
|---|---:|---:|---:|---:|---:|
| trefoil | 11 × 21 | 6 | 15 | 1 | 7 |
| figure-eight | 15 × 30 | 9 | 21 | 1 | 10 |
| TT | 27 × 48 | 15 | 33 | 1 | 16 |
| T25 | 18 × 33 | 10 | 23 | 1 | 11 |
| T27 | 29 × 51 | 16 | 35 | 1 | 17 |
| W34 | 54 × 93 | 30 | 63 | 1 | 31 |

The circle's independently authenticated endpoint is terminal `None`, so
there is no matrix to factor. Every nonterminal source has one vertex and
two boundary faces. None of the six matrices has a zero column (a free
matroid loop) or a coloop (a coordinate forced to zero throughout the signed
kernel). These notions are recorded separately in the raw results.

## Authentication and exact algebra

The probe reconstructed each literal input PD from its fixed braid (or the
empty diagram), checked the retained PD digest, and replayed every chain
under the current independent native verifiers. For the six conclusive
whole-call outputs it also checked the complete recognition certificate;
W34 remains INCONCLUSIVE and only its partial chain was authenticated.
Thirty-one native solver, search, ray-extraction, construction and reduction
hooks and imported aliases were disabled throughout. Current native,
script, and input-audit pins were unchanged: 301 pinned files total. The
audit's older generation pins are retained as historical metadata and were
not incorrectly compared to current native bytes.

The full Q matrix comes from the independent Euler verifier's original
STANDARD matching-row reconstruction, not the sector producer. A fresh
scratch rational RREF gives a basis of pivot columns and one fundamental
circuit vector per free column. The probe checks every vector against every
original Q row, retains the exact row-operation transformation, checks that
transformation against the original matrix, and verifies the reverse
row-space inclusion. Uniting each fundamental circuit's support gives the
column-matroid partition. Every basis vector belongs to one part. An
additional reversed-column elimination checks each component's restricted
rank, and the ranks and nullities sum to those of the full matrix. Thus the
reported partition really splits the entire signed kernel.

Every local tetrahedral three-Q block-ones vector is explicitly checked in
the kernel. Consequently the global all-ones vector lies in the kernel;
projecting it onto each coordinate factor gives a strictly positive vector
on that factor. The probe checks these projected indicators directly. This
also rules out coloops in these full-Q systems. A separate propagation of
the original STANDARD equations constructs their canonical triangle lifts,
checks every matching equation and global edge weight, and independently
counts formal Euler against the reference potential formula.

“Nonnegative-capable” means the component has a nonzero nonnegative kernel
vector, with an explicit strictly positive indicator here. It does **not**
mean positive formal Euler. The all-ones lifts have Euler `1-t`, namely
`-6,-9,-15,-10,-16,-30`. No nonnegative fundamental-circuit sample had
positive formal Euler. Absence of such a sample is not an Euler exclusion;
the raw output explicitly leaves that classification incomplete. The
already replayed whole-diagram negative certificates remain separate.

## Interpretation of the proposed structural reduction

For a genuine coordinate decomposition `ker C = direct_sum K_i`, any
nonnegative `q` is the sum of its nonnegative component projections. Each
projection preserves quadrilateral compatibility when `q` is compatible.
Canonical formal Euler is the maximum of its anchor linear forms, hence
is positively homogeneous and subadditive:

`F(sum_i q_i) <= sum_i F(q_i)`.

Therefore a compatible point with `F>0` exists in the whole cone if and only
if one exists on a single component. The forward implication follows
because a positive left side forces a positive summand on the right; the
reverse implication embeds one component by zero extension. This statement
does not require that arbitrary compatible component points can all be
combined compatibly. Here the component reduction is vacuous because every
matrix is connected. No general connectedness theorem, runtime improvement,
bound on resolving parameters, or quasi-polynomial result follows from the
finite observations.

## Retained files and reproduction

The script never overwrites an existing result and saves active/error state
between cases. The completed result has `errors=[]`, seven authenticated
chains, one terminal endpoint, and six complete matrices. Full labelled
source tables and chains, matrices, RREF transformations, circuit vectors,
component tables, exact witness coordinates and source digests are retained.

```sh
python -B -S /tmp/euler-coordinate-factor-probe/probe.py --output /tmp/euler-coordinate-factor-probe/probe.json > /tmp/euler-coordinate-factor-probe/probe.txt 2>&1
```

That exact command has already run. For a rerun, select a new output and
log filename; do not overwrite these retained artifacts.

* `probe.py`: 21,170 bytes; SHA256
  `56e7fe97fca6c9aa47dba65021f70359032fcc19486d5791fe009eae05befeeb`.
* `probe.json`: 3,781,199 bytes; SHA256
  `4a37ef732d1b91155470b34dc527c2d9798a58bb0500e8720005d07d064d330d`.
* `probe.txt`: 3,132 bytes; SHA256
  `2ef0b13be6c7865373a5a090e88d60112d55305a271b5443528d45972bc9342e`.

The callback total is diagnostic, not a timing or independent execution
cost certificate. No further discovery or experiments are scheduled here.
