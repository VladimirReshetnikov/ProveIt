"""Fixed seven-endpoint, exact column-matroid probe; no solver discovery."""
import argparse
from contextlib import contextmanager
from fractions import Fraction as F
from hashlib import sha256
import importlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path('/home/codex/.codex/worktrees/cc5b/Proofs/Topology/UnknotRecognition')
FAST = ROOT/'fast'
AUDIT = ROOT/'synthesis/data/geometric-descent-audit.json'
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(FAST))

from fastunknot.diagram import Diagram
from fastunknot.normal_crushing_chain import verify_crushing_chain
from fastunknot.normal_crushing_search import verify_crushing_recognition
from fastunknot.normal_surface_geometry import _prepare, _EDGES, _quad
from fastunknot.normal_euler_verify import _reference_model

CASES = (('circle', None, ()), ('trefoil', 2, (1,1,1)),
    ('figure_eight', 3, (1,-2,1,-2)), ('TT', 3, (1,1,1,2,2,2)),
    ('T25', 2, (1,1,1,1,1)), ('T27', 2, (1,1,1,1,1,1,1)),
    ('W34', 3, (1,-2,1,-2,1,-2,1,-2)))


def require(ok, message):
    if not ok:
        raise ValueError(message)


def safe(value):
    if type(value) is F:
        return [value.numerator, value.denominator]
    if type(value) in (list, tuple):
        return [safe(x) for x in value]
    if type(value) is dict:
        return {k: safe(v) for k, v in value.items()}
    return value


def raw(value):
    return json.dumps(safe(value), sort_keys=True, separators=(',', ':')).encode()


def digest(value):
    return sha256(raw(value)).hexdigest()


def same(a, b):
    return type(a) is type(b) and (a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
        if type(a) is dict else len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
        if type(a) in (list, tuple) else a == b)


def pins():
    values = {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest()
              for p in sorted((FAST/'fastunknot').rglob('*.py'))}
    values[str(AUDIT.relative_to(ROOT))] = sha256(AUDIT.read_bytes()).hexdigest()
    values[str(Path(__file__).resolve())] = sha256(Path(__file__).read_bytes()).hexdigest()
    return values


def save(path, document):
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_bytes(raw(document)+b'\n')
    temporary.replace(path)


@contextmanager
def discovery_disabled():
    names = {
        'exact_lp': ('solve_nonnegative_kernel', '_solve_prepared_nonnegative_kernel',
            '_run_kernel_policy', '_solve_prepared_kernel', '_ellipsoid_kernel'),
        'bounded_lp': ('find_point', 'decide'),
        'normal_euler': ('decide_sector_euler',),
        'normal_euler_tree': ('search_euler_tree',),
        'normal_euler_transversal': ('search_euler_transversal',),
        'normal_sector': ('build_sector_kernel', '_assemble_sector_kernel', 'enumerate_sector'),
        'positive_ray': ('extract_positive_ray',),
        'normal_crushing': ('crush_normal_ray',),
        'normal_crushing_search': ('recognize_by_crushing',),
        'normal_vertex_reduction': ('vertex_reduction_ray',),
        'normal_pachner32': ('reduce_pachner32_once',),
        'normal_pachner_descent': ('reduce_pachner_descent_once',),
        'normal_geometric_descent': ('reduce_geometric_descent_once',),
        'pachner_cover_search': ('find_pachner_descent', 'search_pachner_cover'),
        'boundary_shellings': ('shell_boundary',),
    }
    originals = []
    for module, functions in names.items():
        owner = importlib.import_module('fastunknot.'+module)
        originals.extend((owner, name, getattr(owner, name)) for name in functions)
    source_kernel = importlib.import_module('fastunknot.source_kernel')
    tree = importlib.import_module('fastunknot.normal_euler_tree')
    originals.extend(((source_kernel.SourceKernel, 'extreme_witness',
                       source_kernel.SourceKernel.extreme_witness),
                      (tree._EulerMaskOracle, 'attempt', tree._EulerMaskOracle.attempt)))
    targets = {id(function) for _, _, function in originals}
    for module in list(sys.modules.values()):
        if module is not None and getattr(module, '__name__', '').startswith('fastunknot.'):
            for name, value in list(vars(module).items()):
                if id(value) in targets and not any(owner is module and key == name for owner, key, _ in originals):
                    originals.append((module, name, value))
    def forbidden(*args, **kwargs):
        raise RuntimeError('discovery disabled in coordinate-factor probe')
    for owner, name, _ in originals:
        setattr(owner, name, forbidden)
    try:
        yield sorted(set(owner.__name__+'.'+name for owner, name, _ in originals))
    finally:
        for owner, name, original in reversed(originals):
            setattr(owner, name, original)


def rref(matrix, width, check, reverse=False, transform=False):
    a = [[F(x) for x in row] for row in matrix]
    count = len(a)
    e = [[F(i == j) for j in range(count)] for i in range(count)] if transform else None
    pivots = []
    for col in (reversed(range(width)) if reverse else range(width)):
        check()
        k = len(pivots)
        chosen = next((i for i in range(k, count) if a[i][col]), None)
        if chosen is None:
            continue
        a[k], a[chosen] = a[chosen], a[k]
        if e is not None:
            e[k], e[chosen] = e[chosen], e[k]
        divisor = a[k][col]
        a[k] = [x/divisor for x in a[k]]
        if e is not None:
            e[k] = [x/divisor for x in e[k]]
        for i in range(count):
            check()
            if i != k and a[i][col]:
                coefficient = a[i][col]
                a[i] = [x-coefficient*y for x, y in zip(a[i], a[k])]
                if e is not None:
                    e[i] = [x-coefficient*y for x, y in zip(e[i], e[k])]
        pivots.append(col)
        if len(pivots) == count:
            break
    return a[:len(pivots)], pivots, None if e is None else e[:len(pivots)]


def dot(a, b):
    return sum((x*y for x, y in zip(a, b)), F(0))


def canonical_lift(prepared, q, model, check):
    """Propagate original STANDARD equations, allowing incompatible Q data."""
    tets = len(prepared['tetrahedra'])
    adjacency = [[] for _ in range(4*tets)]
    for equation in prepared['matching']:
        check()
        triangles = [(4*(i//7)+i % 7, a) for i, a in equation.items() if i % 7 < 4]
        constant = sum(a*q[3*(i//7)+i % 7-4] for i, a in equation.items() if i % 7 >= 4)
        if not triangles:
            require(constant == 0, 'pure Q matching equation')
            continue
        require(len(triangles) == 2 and sorted(a for _, a in triangles) == [-1,1], 'triangle equation shape')
        left = next(i for i, a in triangles if a == 1)
        right = next(i for i, a in triangles if a == -1)
        adjacency[left].append((right, constant))
        adjacency[right].append((left, -constant))
    heights = [None]*(4*tets)
    for root in range(4*tets):
        if heights[root] is not None:
            continue
        heights[root] = 0
        queue = [root]
        for v in queue:
            check()
            for w, increment in adjacency[v]:
                expected = heights[v]+increment
                if heights[w] is None:
                    heights[w] = expected
                    queue.append(w)
                else:
                    require(heights[w] == expected, 'triangle potential cycle')
    groups = {}
    for corner, vertex in enumerate(prepared['vertex_roots']):
        groups.setdefault(vertex, []).append(corner)
    for corners in groups.values():
        minimum = min(heights[c] for c in corners)
        for corner in corners:
            heights[corner] -= minimum
    coordinates = [heights[4*t:4*t+4]+list(q[3*t:3*t+3]) for t in range(tets)]
    flat = sum(coordinates, [])
    require(all(type(x) in (int, F) and x >= 0 for x in flat), 'nonnegative formal lift')
    for equation in prepared['matching']:
        check()
        require(sum(a*flat[i] for i, a in equation.items()) == 0, 'original STANDARD matching replay')
    edges = {}
    for t in range(tets):
        for e, (a, b) in enumerate(_EDGES):
            check()
            weight = coordinates[t][a]+coordinates[t][b]+sum(
                coordinates[t][4+k] for k in range(3) if k != _quad(a, b))
            root = prepared['edge_roots'][6*t+e]
            require(root not in edges or edges[root] == weight, 'global edge weight consistency')
            edges[root] = weight
    faces = prepared['boundary_faces']+[(t,f) for t,f,_,_,_ in prepared['pairs']]
    arcs = sum(sum(coordinates[t][v] for v in range(4) if v != f)+sum(coordinates[t][4:])
               for t, f in faces)
    euler = sum(edges.values())-arcs+sum(flat)
    _, linear, groups, potentials, weights = model
    formula = dot(linear, q)-sum(weight*min(dot(potentials[c], q) for c in group)
                                for group, weight in zip(groups, weights))
    require(euler == formula, 'independent incidence/reference Euler agreement')
    return dict(coordinates=coordinates, formal_euler=euler,
                quadrilateral_compatible=all(sum(x > 0 for x in row[4:]) <= 1 for row in coordinates),
                original_standard_matching_checked=True, canonical_minima_checked=True)


def analyse(source, check):
    prepared = _prepare(source, check)
    t = len(source['tetrahedra'])
    require(prepared['vertices'] == 1 and len(prepared['boundary_faces']) == 2, 'declared endpoint geometry')
    allowed = [(i,j) for i in range(t) for j in range(3)]
    model = _reference_model(prepared, tuple(allowed), check)
    matrix, linear, groups, potentials, weights = model
    matrix = [list(row) for row in matrix]
    n = 3*t
    reduced, pivots, transform = rref(matrix, n, check, transform=True)
    for row, coefficients in zip(reduced, transform):
        for col in range(n):
            check()
            require(sum(a*original[col] for a, original in zip(coefficients, matrix)) == row[col], 'RREF row transformation')
    for original in matrix:
        residue = list(map(F, original))
        for row, pivot in zip(reduced, pivots):
            factor = residue[pivot]
            residue = [a-factor*b for a, b in zip(residue, row)]
        require(not any(residue), 'original rows contained in RREF row space')
    parent = list(range(n))
    def find(j):
        while parent[j] != j:
            parent[j] = parent[parent[j]]
            j = parent[j]
        return j
    def union(a, b):
        a, b = find(a), find(b)
        parent[max(a,b)] = min(a,b)
    basis, free_columns = [], [j for j in range(n) if j not in pivots]
    for free in free_columns:
        vector = [F(0)]*n
        vector[free] = F(1)
        for row, pivot in zip(reduced, pivots):
            vector[pivot] = -row[free]
        support = [j for j, x in enumerate(vector) if x]
        for row in matrix:
            check()
            require(dot(row, vector) == 0, 'fundamental circuit original kernel')
        for j in support:
            union(free, j)
        basis.append(dict(free_column=free, support=support, vector=vector))
    partition = {}
    for j in range(n):
        partition.setdefault(find(j), []).append(j)
    blocks = sorted(partition.values(), key=lambda block: block[0])
    zeros = [j for j in range(n) if all(row[j] == 0 for row in matrix)]
    forced = [j for j in range(n) if all(item['vector'][j] == 0 for item in basis)]
    local_relations = []
    for tetrahedron in range(t):
        columns = list(range(3*tetrahedron, 3*tetrahedron+3))
        require(all(sum(row[j] for j in columns) == 0 for row in matrix), 'local Q block-ones relation')
        nonzero = [j for j in columns if j not in zeros]
        require(len({find(j) for j in nonzero}) <= 1, 'nonzero tetrahedron columns lie in one component')
        local_relations.append(dict(tetrahedron=tetrahedron, columns=columns,
            nonzero_columns=nonzero, block_ones_in_kernel=True))
    require(not forced, 'full Q block-ones prohibit coloops')
    components = []
    sum_rank = sum_nullity = 0
    for index, columns in enumerate(blocks):
        selected_basis = [item for item in basis if item['free_column'] in columns]
        for item in selected_basis:
            require(set(item['support']) <= set(columns), 'basis vector must belong to one coordinate factor')
        restricted = [[row[j] for j in columns] for row in matrix]
        _, reverse_pivots, _ = rref(restricted, len(columns), check, reverse=True)
        rank = len(reverse_pivots)
        nullity = len(columns)-rank
        require(nullity == len(selected_basis), 'independent component rank/nullity')
        indicator = [int(j in columns) for j in range(n)]
        require(all(dot(row, indicator) == 0 for row in matrix), 'positive component indicator witness')
        lift = canonical_lift(prepared, indicator, model, check)
        positive_samples = []
        for item in selected_basis:
            vector = item['vector']
            if all(x >= 0 for x in vector):
                observation = canonical_lift(prepared, vector, model, check)
                if observation['formal_euler'] > 0:
                    positive_samples.append(dict(free_column=item['free_column'], quadrilaterals=vector, **observation))
        component = dict(index=index, columns=columns, allowed_types=[allowed[j] for j in columns],
            tetrahedra=sorted({j//3 for j in columns}), rank=rank, nullity=nullity,
            kind='free_loop' if len(columns) == 1 and columns[0] in zeros else 'nontrivial_matroid_component',
            fundamental_free_columns=[item['free_column'] for item in selected_basis],
            strictly_positive_kernel_witness=indicator, witness_lift=lift,
            nonnegative_capable=True,
            sampled_positive_euler_witnesses=positive_samples,
            euler_positivity_classification='witness_found' if lift['formal_euler'] > 0 or positive_samples else 'undetermined_without_further_analysis')
        components.append(component)
        sum_rank += rank
        sum_nullity += nullity
    require(sum_rank == len(pivots) and sum_nullity == len(basis) == n-len(pivots), 'direct sum rank and nullity')
    return dict(tetrahedra=t, vertices=prepared['vertices'], boundary_faces=len(prepared['boundary_faces']),
        allowed_types=allowed, matrix=matrix, matrix_sha256=digest(matrix),
        original_standard_matching=[[[i,a] for i,a in sorted(row.items())] for row in prepared['matching']],
        euler_model=dict(linear=linear, groups=groups, weights=weights,
                         potentials=[dict(corner_class=c, coefficients=row) for c,row in sorted(potentials.items())]),
        rank=len(pivots), nullity=n-len(pivots), rref=reduced, pivot_columns=pivots,
        rref_row_transformation=transform, nullspace_fundamental_circuits=basis,
        zero_columns_free_loops=zeros, forced_zero_columns_coloops=forced,
        tetrahedral_block_ones_relations=local_relations, components=components,
        component_count=len(components), nonnegative_capable_component_count=len(components),
        nontrivial_component_count=sum(c['kind'] != 'free_loop' for c in components),
        component_tetrahedron_counts=[len(c['tetrahedra']) for c in components],
        signed_kernel_coordinate_direct_sum_checked=True,
        rank_additivity_checked=True, full_nonnegative_cone_coordinate_product_checked=True,
        euler_positive_component_classification_complete=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=HERE/'probe.json')
    args = parser.parse_args()
    require(not args.output.exists(), 'refuse to overwrite retained probe')
    before = pins()
    data = json.loads(AUDIT.read_bytes())
    result = dict(schema='scratch-euler-coordinate-factor-probe-v1', passed=False,
        repository_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        input_audit=str(AUDIT), input_audit_sha256=sha256(AUDIT.read_bytes()).hexdigest(),
        historical_audit_source_pins=data['source_sha256'], historical_pins_compared_to_current=False,
        source_sha256=before, fixed_case_order=[x[0] for x in CASES], records=[], errors=[],
        active=None, scope=dict(lp_queries=0, recognition_discovery=False, timings=False,
            new_corpus=False, generality_claim=False, complete_euler_positivity_classification=False))
    save(args.output, result)
    checks = 0
    def check():
        nonlocal checks
        checks += 1
    try:
        require(data['passed'] is True and data['schema'] == 'geometric-descent-audit-v1', 'retained passed audit')
        require(data['case_order'] == result['fixed_case_order'] and len(data['records']) == 7, 'fixed seven-case coverage')
        with discovery_disabled() as disabled:
            result['disabled_discovery_hooks'] = disabled
            for expected, saved in zip(CASES, data['records']):
                name, strands, word = expected
                start = checks
                result['active'] = dict(id=name, phase='authenticate_chain')
                save(args.output, result)
                diagram = Diagram.from_pd([]) if strands is None else Diagram.from_braid(strands, word)
                pd = [list(row) for row in diagram.pd]
                require(saved['id'] == name and same(saved['input_pd'], pd), 'literal original diagram input')
                require(saved['input_pd_sha256'] == digest(pd), 'input PD digest')
                whole = saved['arms']['geometric']['result']
                chain = whole['partial_chain'] if whole['status'] == 'INCONCLUSIVE' else whole['certificate']['chain']
                require(chain['schema'] == 'diagram-crushing-v5', 'geometric chain schema')
                if whole['status'] == 'INCONCLUSIVE':
                    require(verify_crushing_chain(diagram, chain, check=check), 'independent partial chain authentication')
                else:
                    require(verify_crushing_recognition(diagram, whole['certificate'], check=check), 'independent whole recognition authentication')
                source = chain['triangulation']
                record = dict(id=name, input_pd=pd, input_pd_sha256=digest(pd),
                    saved_result_sha256=digest(whole), saved_status=whole['status'],
                    chain=chain, chain_sha256=digest(chain), chain_verified=True,
                    conclusive_recognition_replayed=whole['status'] != 'INCONCLUSIVE',
                    source=source, source_sha256=None if source is None else digest(source),
                    terminal=source is None)
                expected_endpoint = saved['arms']['geometric']['replay']['endpoint']
                require(expected_endpoint['source_sha256'] == record['source_sha256'], 'retained endpoint exact source digest')
                if source is None:
                    require(name == 'circle' and whole['status'] == 'UNKNOT', 'only terminal circle')
                    record['algebra'] = None
                else:
                    result['active']['phase'] = 'exact_component_algebra'
                    save(args.output, result)
                    record['algebra'] = analyse(source, check)
                record['callback_checks'] = checks-start
                result['records'].append(record)
                result['active'] = None
                save(args.output, result)
                print(json.dumps(dict(id=name, terminal=source is None,
                    tetrahedra=None if source is None else record['algebra']['tetrahedra'],
                    components=None if source is None else record['algebra']['component_count'],
                    component_tetrahedron_counts=None if source is None else record['algebra']['component_tetrahedron_counts']), sort_keys=True), flush=True)
        require(pins() == before, 'native/script/audit pins unchanged throughout')
        result['source_pins_unchanged'] = True
        result['callback_checks'] = checks
        result['coverage'] = dict(authenticated_chains=7, terminal_sources=1, full_q_matrices=6)
        result['summary'] = [dict(id=r['id'], source_sha256=r['source_sha256'],
            terminal=r['terminal'], **({} if r['terminal'] else {key:r['algebra'][key] for key in
                ('tetrahedra','rank','nullity','component_count','nonnegative_capable_component_count',
                 'nontrivial_component_count','component_tetrahedron_counts','zero_columns_free_loops',
                 'forced_zero_columns_coloops')})) for r in result['records']]
        result['passed'] = True
        save(args.output, result)
        print(json.dumps(dict(passed=True, coverage=result['coverage'], summary=result['summary']), sort_keys=True), flush=True)
    except BaseException as error:
        result['errors'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
        result['callback_checks'] = checks
        save(args.output, result)
        raise


if __name__ == '__main__':
    main()
