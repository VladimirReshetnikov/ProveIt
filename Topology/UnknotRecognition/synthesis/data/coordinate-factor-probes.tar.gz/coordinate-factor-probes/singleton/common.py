"""Literal input/source bindings shared by two independent algebra routines."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/codex/.codex/worktrees/cc5b/Proofs/Topology/UnknotRecognition')
ORIGINAL = Path('/tmp/euler-coordinate-factor-probe/probe.json')
ORIGINAL_CODE = ORIGINAL.with_name('probe.py')
ORIGINAL_HASH = '4a37ef732d1b91155470b34dc527c2d9798a58bb0500e8720005d07d064d330d'
ORIGINAL_CODE_HASH = '56e7fe97fca6c9aa47dba65021f70359032fcc19486d5791fe009eae05befeeb'
CASES = (('trefoil', 7), ('figure_eight', 10), ('TT', 16),
         ('T25', 11), ('T27', 17), ('W34', 31))


def require(ok, message):
    if not ok:
        raise ValueError(message)


def safe(value):
    if type(value) is Fraction:
        return [value.numerator, value.denominator]
    if type(value) in (tuple, list):
        return [safe(x) for x in value]
    if type(value) is dict:
        return {k: safe(v) for k, v in value.items()}
    return value


def raw(value):
    return json.dumps(safe(value), sort_keys=True, separators=(',', ':')).encode()


def digest(value):
    return sha256(raw(value)).hexdigest()


def same(a, b):
    return type(a) is type(b) and (a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
        if type(a) is dict else len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
        if type(a) in (list, tuple) else a == b)


def save(path, document):
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_bytes(raw(document)+b'\n')
    tmp.replace(path)


def load_sources():
    require(sha256(ORIGINAL.read_bytes()).hexdigest() == ORIGINAL_HASH, 'original probe bytes')
    require(sha256(ORIGINAL_CODE.read_bytes()).hexdigest() == ORIGINAL_CODE_HASH, 'original probe code bytes')
    original = json.loads(ORIGINAL.read_bytes())
    require(original['passed'] is True and original['source_pins_unchanged'] is True and original['errors'] == [], 'original complete successful probe')
    require(same(original['coverage'], dict(authenticated_chains=7, terminal_sources=1, full_q_matrices=6)), 'original coverage')
    for name, expected in original['source_sha256'].items():
        path = Path(name) if Path(name).is_absolute() else ROOT/name
        require(sha256(path.read_bytes()).hexdigest() == expected, 'original dependency unchanged: '+name)
    retained = {record['id']:record for record in original['records']}
    sources = []
    for name, tetrahedra in CASES:
        record = retained[name]
        require(record['chain_verified'] is True and record['terminal'] is False, 'authenticated nonterminal input')
        require(digest(record['source']) == record['source_sha256'], 'labelled source body digest')
        require(len(record['source']['tetrahedra']) == tetrahedra, 'fixed source tetrahedron count')
        algebra = record['algebra']
        matrix = algebra['matrix']
        require(algebra['tetrahedra'] == tetrahedra and all(type(row) is list and len(row) == 3*tetrahedra and all(type(x) is int for x in row) for row in matrix), 'literal full matrix shape')
        require(digest(matrix) == algebra['matrix_sha256'], 'archived matrix bytes')
        require(algebra['component_count'] == 1 and algebra['forced_zero_columns_coloops'] == [], 'original connected full matrix')
        sources.append(dict(id=name, tetrahedra=tetrahedra, source_sha256=record['source_sha256'],
            matrix_sha256=algebra['matrix_sha256'], original_columns=3*tetrahedra,
            original_rank=algebra['rank'], original_nullity=algebra['nullity'],
            matrix_rows=len(matrix), matrix=matrix))
    pinmap = dict(original_probe_path=str(ORIGINAL), original_probe_sha256=ORIGINAL_HASH,
        original_probe_code_path=str(ORIGINAL_CODE), original_probe_code_sha256=ORIGINAL_CODE_HASH,
        original_source_sha256=original['source_sha256'],
        scratch_source_sha256={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.glob('*.py'))})
    return sources, pinmap


def summarize(sources):
    result = []
    for source in sources:
        n = source['original_columns']
        per_tet = []
        for tet in range(source['tetrahedra']):
            queries = source['records'][3*tet:3*tet+3]
            sizes = [query['largest_noncoloop_component_size'] for query in queries]
            per_tet.append(dict(tetrahedron=tet, assignment_largest_component_sizes=sizes,
                                worst_case_largest_component_size=max(sizes)))
        best = min(item['worst_case_largest_component_size'] for item in per_tet)
        result.append(dict(id=source['id'], source_sha256=source['source_sha256'],
            original_columns=n, original_tetrahedra=source['tetrahedra'],
            retained_columns_per_mask=n-2, per_tetrahedron=per_tet,
            best_worst_case_size=best,
            best_tetrahedra=[item['tetrahedron'] for item in per_tet if item['worst_case_largest_component_size'] == best],
            reduction_from_original_columns=n-best,
            reduction_beyond_deleted_competitors=(n-2)-best,
            best_worst_over_original=[best,n],
            masks_with_multiple_noncoloop_components=sum(query['noncoloop_component_count'] > 1 for query in source['records']),
            masks_with_forced_zero_coordinates=sum(bool(query['forced_zero_columns_coloops']) for query in source['records'])))
    return result
