"""Exactly 276 singleton-Q masks; RREF fundamental circuits, no LP/search."""
import argparse
from fractions import Fraction as F
from pathlib import Path
import traceback
import json
from common import HERE, load_sources, require, save, same, summarize


def partition(matrix, columns):
    a = [[F(row[j]) for j in columns] for row in matrix]
    width = len(columns)
    pivots = []
    for col in range(width):
        k = len(pivots)
        row = next((i for i in range(k, len(a)) if a[i][col]), None)
        if row is None:
            continue
        a[k], a[row] = a[row], a[k]
        pivot = a[k][col]
        a[k] = [x/pivot for x in a[k]]
        for i in range(len(a)):
            if i != k and a[i][col]:
                factor = a[i][col]
                a[i] = [x-factor*y for x,y in zip(a[i],a[k])]
        pivots.append(col)
        if len(pivots) == len(a):
            break
    a = a[:len(pivots)]
    free = [j for j in range(width) if j not in pivots]
    parent = list(range(width))
    def find(j):
        while parent[j] != j:
            parent[j] = parent[parent[j]]
            j = parent[j]
        return j
    def union(a,b):
        a,b = find(a),find(b)
        parent[max(a,b)] = min(a,b)
    circuits = []
    active = set()
    for j in free:
        entries = [(j,F(1))]+[(p,-row[j]) for p,row in zip(pivots,a) if row[j]]
        entries.sort()
        for k,_ in entries:
            union(j,k)
            active.add(k)
        circuits.append(dict(free_column=columns[j], coefficients=[[columns[k],v] for k,v in entries]))
    groups = {}
    for j in range(width):
        groups.setdefault(find(j),[]).append(j)
    components = []
    for block in sorted(groups.values(), key=lambda block:block[0]):
        rank = sum(j in pivots for j in block)
        nullity = len(block)-rank
        kind = 'coloop_forced_zero' if nullity == 0 else 'loop_free_coordinate' if len(block) == 1 else 'nontrivial_matroid_component'
        components.append(dict(columns=[columns[j] for j in block], rank=rank, nullity=nullity,
            tetrahedra=sorted({columns[j]//3 for j in block}), kind=kind))
    forced = [columns[j] for j in range(width) if j not in active]
    zeros = [j for j in columns if all(row[j] == 0 for row in matrix)]
    noncoloop = [c for c in components if c['nullity'] > 0]
    return dict(rank=len(pivots), nullity=len(free), pivot_columns=[columns[j] for j in pivots],
        fundamental_circuits=circuits, components=components,
        component_count=len(components), noncoloop_component_count=len(noncoloop),
        forced_zero_columns_coloops=forced, zero_columns_free_loops=zeros,
        largest_noncoloop_component_size=max((len(c['columns']) for c in noncoloop), default=0),
        largest_noncoloop_tetrahedron_support=max((len(c['tetrahedra']) for c in noncoloop), default=0))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=HERE/'probe.json')
    args=parser.parse_args()
    require(not args.output.exists(), 'do not overwrite retained probe')
    sources,pinmap=load_sources()
    output=dict(schema='scratch-euler-one-tet-separator-v1',passed=False,
        pins=pinmap, expected_masks=276, records_completed=0, sources=[], active=None,errors=[],
        scope=dict(lp_queries=0, recognition_discovery=False, new_corpus=False, timings=False,
                   signed_kernel_only=True, nonnegative_feasibility_inferred=False))
    save(args.output,output)
    try:
        for source in sources:
            record={key:value for key,value in source.items() if key != 'matrix'}
            record['records']=[]
            output['sources'].append(record)
            n=source['original_columns']
            for tet in range(source['tetrahedra']):
                for typ in range(3):
                    output['active']=dict(id=source['id'],tetrahedron=tet,quadrilateral_type=typ)
                    save(args.output,output)
                    removed=[3*tet+j for j in range(3) if j != typ]
                    columns=[j for j in range(n) if j not in removed]
                    analysis=partition(source['matrix'],columns)
                    record['records'].append(dict(tetrahedron=tet,quadrilateral_type=typ,
                        retained_columns=columns,removed_columns=removed,**analysis))
                    output['records_completed']+=1
                    output['active']=None
                    save(args.output,output)
            print(json.dumps(dict(id=source['id'],masks=len(record['records']),summary=summarize([record])[0]),sort_keys=True),flush=True)
        _,after=load_sources()
        require(same(pinmap,after),'input/code/source pins unchanged')
        require(output['records_completed']==276,'complete predeclared mask coverage')
        output['summary']=summarize(output['sources'])
        output['source_pins_unchanged']=True
        output['passed']=True
        save(args.output,output)
        print(json.dumps(dict(passed=True,records_completed=276,summary=output['summary']),sort_keys=True),flush=True)
    except BaseException as error:
        output['errors'].append(dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
        save(args.output,output)
        raise


if __name__=='__main__':
    main()
