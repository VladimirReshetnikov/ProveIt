"""Independent exact rank-additivity replay of all 276 saved partitions.

This file does not import the partition producer or any native module.
Its reverse-column, reversed-row incremental echelon rank algorithm differs
from the producer's full RREF. No LP or feasibility calculation is present.
"""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import traceback
from common import HERE, load_sources, require, save, same, summarize


def rank(matrix, columns):
    chart = {}
    for original in reversed(matrix):
        row={j:F(original[j]) for j in columns if original[j]}
        while row:
            pivot=max(row)
            coefficient=row[pivot]
            if pivot not in chart:
                chart[pivot]={j:x/coefficient for j,x in row.items()}
                break
            for j,value in chart[pivot].items():
                new=row.get(j,F(0))-coefficient*value
                if new:
                    row[j]=new
                else:
                    row.pop(j,None)
    return len(chart)


def rational(pair):
    require(type(pair) is list and len(pair)==2 and all(type(x) is int for x in pair) and pair[1]>0,'literal rational pair')
    value=F(*pair)
    require(pair==[value.numerator,value.denominator],'reduced rational encoding')
    return value


def replay_mask(source,record,tet,typ):
    matrix=source['matrix']
    n=source['original_columns']
    removed=[3*tet+j for j in range(3) if j != typ]
    columns=[j for j in range(n) if j not in removed]
    require(type(record['tetrahedron']) is int and record['tetrahedron']==tet and
            type(record['quadrilateral_type']) is int and record['quadrilateral_type']==typ,'ordered literal assignment')
    require(same(record['retained_columns'],columns) and same(record['removed_columns'],removed),'exact singleton mask')
    r=rank(matrix,columns)
    require(type(record['rank']) is int and record['rank']==r and
            type(record['nullity']) is int and record['nullity']==len(columns)-r,'independent whole masked rank')
    pivots=record['pivot_columns']
    require(type(pivots) is list and all(type(j) is int for j in pivots) and
            pivots==sorted(set(pivots)) and set(pivots)<=set(columns) and len(pivots)==r,'basis column indices')
    require(rank(matrix,pivots)==r,'independent pivot columns')
    free=[j for j in columns if j not in pivots]
    circuits=record['fundamental_circuits']
    require(type(circuits) is list and len(circuits)==len(free),'one fundamental circuit per free coordinate')
    graph={j:set() for j in columns}
    active=set()
    for circuit,nonbasic in zip(circuits,free):
        require(set(circuit)=={'free_column','coefficients'} and type(circuit['free_column']) is int and circuit['free_column']==nonbasic,'ordered circuit index')
        coefficients=circuit['coefficients']
        require(type(coefficients) is list and all(type(item) is list and len(item)==2 and type(item[0]) is int for item in coefficients),'circuit fields')
        indices=[item[0] for item in coefficients]
        require(indices==sorted(set(indices)) and set(indices)<=set(pivots+[nonbasic]),'fundamental support in basis plus one free column')
        values={j:rational(value) for j,value in coefficients}
        require(values.get(nonbasic)==1 and all(values.values()),'canonical nonzero fundamental vector')
        for row in matrix:
            require(sum(row[j]*value for j,value in values.items())==0,'original masked equation on saved circuit')
        active.update(values)
        for j in values:
            graph[nonbasic].add(j)
            graph[j].add(nonbasic)
    # Unique free-coordinate unit entries plus full rank prove this is a
    # complete nullspace basis, not only a sample of dependencies.
    partition=[]
    unseen=set(columns)
    while unseen:
        queue=[min(unseen)]
        reached=set(queue)
        for j in queue:
            for neighbor in graph[j]:
                if neighbor not in reached:
                    reached.add(neighbor)
                    queue.append(neighbor)
        unseen-=reached
        partition.append(sorted(reached))
    components=record['components']
    require(type(components) is list and same([c['columns'] for c in components],partition),'exact finest fundamental-circuit partition')
    ranks=[]
    for component,block in zip(components,partition):
        localrank=rank(matrix,block)
        nullity=len(block)-localrank
        kind='coloop_forced_zero' if nullity==0 else 'loop_free_coordinate' if len(block)==1 else 'nontrivial_matroid_component'
        expected=dict(columns=block,rank=localrank,nullity=nullity,tetrahedra=sorted({j//3 for j in block}),kind=kind)
        require(same(component,expected),'independent component rank/nullity/type')
        if not nullity:
            require(len(block)==1,'coloops are singleton matroid components')
        ranks.append(localrank)
    require(sum(ranks)==r,'independent rank additivity: whole signed kernel is coordinate direct sum')
    forced=[j for j in columns if j not in active]
    zeros=[j for j in columns if all(row[j]==0 for row in matrix)]
    require(same(record['forced_zero_columns_coloops'],forced),'forced-zero coordinate completeness from nullspace basis')
    require(same(record['zero_columns_free_loops'],zeros),'zero columns are free loops, not forced zero')
    noncoloops=[c for c in components if c['nullity']>0]
    expected_counts=dict(component_count=len(components),noncoloop_component_count=len(noncoloops),
        largest_noncoloop_component_size=max((len(c['columns']) for c in noncoloops),default=0),
        largest_noncoloop_tetrahedron_support=max((len(c['tetrahedra']) for c in noncoloops),default=0))
    for key,value in expected_counts.items():
        require(same(record[key],value),'component size/count '+key)
    require(set(record)=={'tetrahedron','quadrilateral_type','retained_columns','removed_columns',
        'rank','nullity','pivot_columns','fundamental_circuits','components',
        'forced_zero_columns_coloops','zero_columns_free_loops'}|set(expected_counts),'exact record fields')
    return dict(tetrahedron=tet,quadrilateral_type=typ,rank=r,nullity=len(columns)-r,
        component_ranks=ranks,component_sizes=[len(c['columns']) for c in components],
        forced_zero_columns=forced,rank_additivity_checked=True,fundamental_basis_checked=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',type=Path,default=HERE/'probe.json')
    parser.add_argument('--output',type=Path,default=HERE/'replay.json')
    args=parser.parse_args()
    require(not args.output.exists(),'do not overwrite retained replay')
    sources,pinmap=load_sources()
    data=json.loads(args.input.read_bytes())
    output=dict(schema='scratch-euler-one-tet-separator-replay-v1',passed=False,pins=pinmap,
        input_sha256=sha256(args.input.read_bytes()).hexdigest(),records=[],active=None,errors=[])
    save(args.output,output)
    try:
        require(data['schema']=='scratch-euler-one-tet-separator-v1' and data['passed'] is True and
                data['source_pins_unchanged'] is True and data['errors']==[] and data['active'] is None,'complete successful producer record')
        require(same(data['pins'],pinmap),'all source/script/input pins')
        require(type(data['expected_masks']) is int and data['expected_masks']==276 and
                type(data['records_completed']) is int and data['records_completed']==276,'declared coverage')
        require(len(data['sources'])==len(sources)==6,'six source records')
        for source,saved in zip(sources,data['sources']):
            expected={key:value for key,value in source.items() if key!='matrix'}
            require(same({key:value for key,value in saved.items() if key!='records'},expected),'source/matrix identity and metadata')
            require(len(saved['records'])==3*source['tetrahedra'],'all three assignments of every tetrahedron')
            for index,record in enumerate(saved['records']):
                tet,typ=divmod(index,3)
                output['active']=dict(id=source['id'],tetrahedron=tet,quadrilateral_type=typ)
                save(args.output,output)
                result=replay_mask(source,record,tet,typ)
                output['records'].append(dict(id=source['id'],**result))
                output['active']=None
                save(args.output,output)
            print(json.dumps(dict(id=source['id'],replayed_masks=len(saved['records'])),sort_keys=True),flush=True)
        expected_summary=summarize(data['sources'])
        require(same(data['summary'],expected_summary),'recomputed all-source worst-of-three summary')
        require(len(output['records'])==276,'complete independent mask replay')
        _,after=load_sources()
        require(same(pinmap,after),'unchanged sources throughout replay')
        output['summary']=expected_summary
        output['coverage']=dict(sources=6,singleton_masks=276,independent_rank_additivity_checks=276)
        output['passed']=True
        output['source_pins_unchanged']=True
        save(args.output,output)
        print(json.dumps(dict(passed=True,coverage=output['coverage'],summary=expected_summary),sort_keys=True),flush=True)
    except BaseException as error:
        output['errors'].append(dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
        save(args.output,output)
        raise


if __name__=='__main__':
    main()
