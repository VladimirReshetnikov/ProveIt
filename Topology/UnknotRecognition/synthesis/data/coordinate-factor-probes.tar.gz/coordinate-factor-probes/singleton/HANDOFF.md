# Fixed singleton-tetrahedron separator probe

The authorized algebra-only probe and its independent replay both passed.
Exactly 276 masks were retained: all three singleton Q assignments at every
tetrahedron in the six previously authenticated geometric-arm sources.
No LP, recognition search, additional corpus, timing, or maintained edit was
performed. Both raw outputs have `errors=[]` and unchanged source pins.

**Every one of the 276 restricted matrices is column-matroid connected.**
Each sole component includes all retained columns and all original
tetrahedra. No coloop (forced-zero coordinate) or zero column (free loop)
occurs. Thus there is no single-tetrahedron separator on these exact sources.

| Source | Assignments | Original columns | Largest component after every assignment | Rank | Nullity | Best worst case over three assignments |
|---|---:|---:|---:|---:|---:|---:|
| trefoil T7 | 21 | 21 | 19 | 6 | 13 | 19 |
| figure-eight F10 | 30 | 30 | 28 | 9 | 19 | 28 |
| TT16 | 48 | 48 | 46 | 15 | 31 | 46 |
| T25 endpoint11 | 33 | 33 | 31 | 10 | 21 | 31 |
| T27 endpoint17 | 51 | 51 | 49 | 16 | 33 | 49 |
| W34 endpoint31 | 93 | 93 | 91 | 30 | 61 | 91 |

Every tetrahedron ties for its source's best worst-case size. The reduction
from `3t` to `3t-2` consists only of deleting the two competing types; no
factorization or forced-zero removal gives an additional reduction. This
is a finite observation about these labelled matrices, not an impossibility
theorem for larger separators, other sources, or other reductions.

## Source binding and independent replay

The exact full matrices are referenced from
`/tmp/euler-coordinate-factor-probe/probe.json`, SHA256
`4a37ef732d1b91155470b34dc527c2d9798a58bb0500e8720005d07d064d330d`.
Its producing code hash and all 301 original input/native/code pins are
validated. Its seven chains were independently authenticated with discovery
disabled by that preceding probe. This new probe performs no additional
native import or chain reconstruction and does not reinterpret historical
generation hashes as current ones. Every source table and matrix digest is
checked against the original retained body. The new records identify exact
removed and retained original column indices; raw matrices are not copied
276 times.

`probe.py` computes full rational RREF and fundamental circuit supports to
produce the finest column-matroid components. For every mask it saves pivot
columns, exact fundamental circuit coefficients, component coordinate lists,
ranks, nullities, tetrahedron supports, loop/coloop lists and largest
non-coloop size.

`replay.py` does not import `probe.py` or any native module. Its separate
reverse-column, reversed-row incremental echelon algorithm checks the whole
masked rank and the independence of the saved pivot columns. It checks every
saved fundamental vector against every original equation, with its unique
unit free coordinate and support in the pivot basis plus that free column.
The number of such independent vectors equals the independently determined
nullity, proving completeness of this nullspace basis. Graph connectivity of
these fundamental supports independently checks the finest partition.
Recomputed component ranks add to the whole rank, verifying that each
partition splits the signed kernel as a coordinate direct sum. This also
distinguishes the two very different singleton kinds: a coloop has rank one
and nullity zero; a zero-column loop has rank zero and nullity one.

The replay covers all six sources and all 276 ordered singleton masks, then
recomputes every per-tetrahedron worst-of-three and all source summaries.
No conclusion about nonnegative feasibility or formal Euler positivity is
drawn from signed rank or circuit data.

## Retained commands and artifacts

These commands have already completed; new output/log filenames are required
for reruns. Each script refuses to overwrite its existing JSON output and
retains active/error state after a failure.

```sh
python -B -S /tmp/euler-one-tet-separator-probe/probe.py --output /tmp/euler-one-tet-separator-probe/probe.json > /tmp/euler-one-tet-separator-probe/probe.txt 2>&1
python -B -S /tmp/euler-one-tet-separator-probe/replay.py --input /tmp/euler-one-tet-separator-probe/probe.json --output /tmp/euler-one-tet-separator-probe/replay.json > /tmp/euler-one-tet-separator-probe/replay.txt 2>&1
```

| File | Bytes | SHA256 |
|---|---:|---|
| common.py | 5441 | `87def3d083d2fbdbfcac8260819dc956af757169cb2f902c32bed37b06791afd` |
| probe.py | 5331 | `36b52610d0ffe89947f0edb1d2cbd1406ca1ecf84b69b4e64ce1d3827781c39f` |
| replay.py | 9560 | `dcb7982066e426afdf5ac46ddcb3ad633903a443c97ec4ff2e9f23104114e382` |
| probe.json | 1989599 | `978ea8287c1773192ac939b6494d51d57aa255174be8d17f8838b667b032d00c` |
| replay.json | 104017 | `50e21292f32ef421df07f1b637c4fa5e359c9f9da84de8502f305e14b6dfda01` |
| probe.txt | 27334 | `85b90c9308ad0a7068ebafd830461733c6f5b44238a60c52ec13c8917f1d6932` |
| replay.txt | 13872 | `07674b760e5f8f10242b80025e1244a4f9a098fc5e5cb871bb65339dacd25cca` |

No further computation is scheduled by this handoff.
