"""Alternate exact selectors beneath the unchanged native LP controller."""
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from common import ARMS, ROOT
from fastunknot import exact_lp

ORIGINAL_HELPER = exact_lp._solve_prepared_kernel


def build_helper(rule, diagnostic):
    assert rule in ('dantzig', 'dantzig_lex')

    def entering(reduced, check):
        chosen = None
        for j, coefficient in enumerate(reduced):
            check()
            diagnostic['entering_columns_scanned'] += 1
            if coefficient > 0 and (chosen is None or coefficient > reduced[chosen]):
                chosen = j
        # Ascending traversal retains the least index on an exact tie.
        return chosen

    def leaving(candidates, tableau, rhs, basis, column, n, check):
        if rule == 'dantzig':
            return min(candidates, key=lambda i: (rhs[i]/tableau[i][column], basis[i]))
        best, best_key = None, None
        for i in candidates:
            check()
            divisor = tableau[i][column]
            key = [rhs[i]/divisor]
            for value in tableau[i][n:]:
                check()
                key.append(value/divisor)
                diagnostic['lex_slack_components_formed'] += 1
            key = tuple(key)
            diagnostic['lex_candidate_keys_formed'] += 1
            if best_key is None or key < best_key:
                best, best_key = i, key
        return best

    def progress(pivots, updates):
        diagnostic['returned_or_completed_pivots_lower_bound'] = pivots
        diagnostic['tableau_updates_lower_bound'] = updates

    namespace = dict(_entering=entering, _leaving=leaving, _progress=progress)
    path = ROOT / 'prefix_template.py'
    exec(compile(path.read_bytes(), str(path), 'exec'), namespace)
    return namespace['_solve_prepared_kernel']


@contextmanager
def prefix_rule(rule, diagnostic):
    assert rule in ARMS
    if rule == 'bland':
        assert exact_lp._solve_prepared_kernel is ORIGINAL_HELPER
        yield
    else:
        with patch.object(exact_lp, '_solve_prepared_kernel', build_helper(rule, diagnostic)):
            yield


def diagnostics():
    return dict(callback_calls=0, entering_columns_scanned=0,
        lex_slack_components_formed=0, lex_candidate_keys_formed=0,
        returned_or_completed_pivots_lower_bound=0, tableau_updates_lower_bound=0)


def solve(rule, matrix, objective, options, diagnostic):
    assert options.get('policy', 'polynomial') == 'polynomial'
    assert 'check' not in options
    def check():
        diagnostic['callback_calls'] += 1
    with prefix_rule(rule, diagnostic):
        answer = exact_lp.solve_nonnegative_kernel(matrix, objective, check=check, **options)
    diagnostic['returned_or_completed_pivots_lower_bound'] = answer['stats']['pivots']
    diagnostic['tableau_updates_lower_bound'] = answer['stats']['tableau_updates']
    return answer
