"""Independent rational witness replay; no LP/vertex enumeration or discovery."""
from fractions import Fraction as Q
from math import gcd
from fastunknot.integer_codec import encoded_integer

from common import (ARMS, CONTROL_CASES, SOURCE_OPTIONS, digest, pairs, pins,
                    rational, same, source_input)


def rank(matrix, width):
    """Independent reverse-column, last-row exact elimination."""
    rows = [[rational(x) for x in row] for row in matrix]
    assert all(len(row) == width for row in rows)
    count = 0
    for column in reversed(range(width)):
        candidates = [i for i in range(count, len(rows)) if rows[i][column]]
        if not candidates:
            continue
        chosen = candidates[-1]
        rows[count], rows[chosen] = rows[chosen], rows[count]
        divisor = rows[count][column]
        rows[count] = [x/divisor for x in rows[count]]
        for i in range(count + 1, len(rows)):
            factor = rows[i][column]
            if factor:
                rows[i] = [a-factor*b for a, b in zip(rows[i], rows[count])]
        count += 1
    return count


def check_lp(matrix, objective, options, answer):
    """Original-row primal/dual, extreme support and feasible slack-basis checks."""
    matrix = [[rational(x) for x in row] for row in matrix]
    cost = list(map(rational, objective))
    n = len(cost)
    assert all(len(row) == n for row in matrix)
    assert type(answer) is dict
    status, stats = answer['status'], answer['stats']
    assert status in ('POSITIVE', 'NONPOSITIVE', 'INCONCLUSIVE')
    assert type(stats) is dict
    for value in stats.values():
        assert type(value) is int and value >= 0
    rows = answer['equation_rows']
    assert type(rows) is list and all(type(i) is int for i in rows)
    assert rows == sorted(set(rows)) and all(0 <= i < len(matrix) for i in rows)
    selected = [matrix[i] for i in rows]
    full_rank = rank(matrix, n)
    assert rank(selected, n) == full_rank
    if options.get('reduce_rows', True):
        assert len(rows) == full_rank
    else:
        assert rows == list(range(len(matrix)))
    r, m = len(rows), 2*len(rows)+1
    assert stats['variables'] == n and stats['equations'] == len(matrix)
    assert stats['retained_equations'] == r and stats['tableau_rows'] == m
    assert stats['tableau_columns'] == n+m
    required = ('pivots', 'tableau_updates', 'maximum_tableau_bits',
        'polynomial_pivot_limit', 'fast_path_pivot_limit', 'fallback_used',
        'ellipsoid_iterations', 'feasibility_calls', 'maximum_ellipsoid_precision',
        'maximum_ellipsoid_dimension', 'maximum_planned_ellipsoid_iterations',
        'support_descent_steps')
    assert all(key in stats for key in required)
    assert options.get('policy', 'polynomial') == 'polynomial'
    limit = (n+r+1)**2
    assert stats['polynomial_pivot_limit'] == limit
    if options.get('fast_path_pivots') is not None:
        limit = min(limit, options['fast_path_pivots'])
    assert stats['fast_path_pivot_limit'] == limit
    if options.get('max_pivots') is not None:
        limit = min(limit, options['max_pivots'])
    assert stats['pivots'] <= limit
    for option, field in (('max_ellipsoid_iterations', 'ellipsoid_iterations'),
                           ('max_feasibility_calls', 'feasibility_calls')):
        if options.get(option) is not None:
            assert stats[field] <= options[option]
    assert stats['fallback_used'] in (0, 1)
    if not stats['fallback_used']:
        assert all(stats[field] == 0 for field in (
            'ellipsoid_iterations', 'feasibility_calls', 'maximum_ellipsoid_precision',
            'maximum_ellipsoid_dimension', 'maximum_planned_ellipsoid_iterations',
            'support_descent_steps'))
    else:
        assert stats['pivots'] == stats['fast_path_pivot_limit']
        assert options.get('max_pivots') is None or stats['pivots'] < options['max_pivots']
    if status == 'INCONCLUSIVE':
        assert set(answer) == {'status', 'reason', 'equation_rows', 'stats'}
        assert type(answer['reason']) is str and answer['reason']
        if not stats['fallback_used']:
            assert answer['reason'] == 'LP pivot allowance exhausted'
            assert options.get('max_pivots') is not None
            assert stats['pivots'] == options['max_pivots']
        return dict(status=status, certificate_verified=False, support_rank=None)
    if status == 'NONPOSITIVE':
        assert set(answer) == {'status', 'y', 'equation_rows', 'stats'}
        y = list(map(rational, answer['y']))
        assert len(y) == len(matrix)
        assert all(sum(row[j]*a for row, a in zip(matrix, y)) >= cost[j] for j in range(n))
        return dict(status=status, certificate_verified=True, support_rank=None)
    assert set(answer) == {'status', 'x', 'primitive_x', 'objective', 'basis', 'equation_rows', 'stats'}
    x = list(map(rational, answer['x']))
    assert len(x) == n and all(a >= 0 for a in x) and sum(x, Q(0)) == 1
    assert all(sum(a*b for a, b in zip(row, x)) == 0 for row in matrix)
    value = sum(a*b for a, b in zip(cost, x))
    assert value > 0 and value == rational(answer['objective'])
    primitive = [encoded_integer(a) for a in answer['primitive_x']]
    assert len(primitive) == n and all(a >= 0 for a in primitive)
    common = 0
    for a in primitive:
        common = gcd(common, a)
    assert common == 1
    assert x == [Q(a, sum(primitive)) for a in primitive]
    support = [j for j, a in enumerate(x) if a]
    support_rank = rank([[row[j] for j in support] for row in matrix], len(support))
    assert len(support)-support_rank == 1
    basis = answer['basis']
    assert type(basis) is list and len(basis) == m and len(set(basis)) == m
    assert all(type(j) is int and 0 <= j < n+m for j in basis)
    assert set(support) <= set(basis)
    # Independent full original-slack rank plus a feasible represented point.
    # Original matching rows and normalization give every slack value zero.
    # Thus all nonbasic entries are zero, and the nonsingular basis realizes x.
    inequalities = selected + [[-a for a in row] for row in selected] + [[Q(1)]*n]
    basic_matrix = [[row[j] if j < n else Q(j-n == i) for j in basis]
                    for i, row in enumerate(inequalities)]
    assert rank(basic_matrix, m) == m
    augmented_point = x + [Q(0)]*m
    rhs = [Q(0)]*(m-1) + [Q(1)]
    assert all(sum(a*augmented_point[j] for a, j in zip(row, basis)) == b
               for row, b in zip(basic_matrix, rhs))
    return dict(status=status, certificate_verified=True, support_rank=support_rank)


def authenticate_source():
    from fastunknot.normal_crushing_chain import verify_crushing_chain
    from fastunknot.normal_surface_geometry import _prepare
    diagram, source, chain, provenance = source_input()
    assert verify_crushing_chain(diagram, chain)
    prepared = _prepare(source, lambda: None)
    assert len(set(prepared['vertex_roots'])) == 1
    assert len(prepared['boundary_faces']) == 2
    return source, prepared, provenance


def check_diagnostic(record):
    diagnostic = record['diagnostic']
    assert type(diagnostic) is dict
    assert all(type(v) is int and v >= 0 for v in diagnostic.values())
    assert diagnostic['returned_or_completed_pivots_lower_bound'] == record['result']['stats']['pivots']
    assert diagnostic['tableau_updates_lower_bound'] == record['result']['stats']['tableau_updates']
    assert record['returned_work_complete'] is True


def check_controls(document):
    assert document['schema'] == 'lp-pivot-controls-v1'
    assert same(document['pins'], pins())
    assert document['passed'] is True and not document['failures'] and document['active'] is None
    expected = [(case, arm) for case in CONTROL_CASES for arm in ARMS]
    assert len(document['records']) == len(expected)
    for record, ((name, matrix, objective, options, status), arm) in zip(document['records'], expected):
        assert record['case'] == name and record['arm'] == arm
        assert same(record['matrix'], [pairs(row) for row in matrix])
        assert same(record['objective'], pairs(objective)) and same(record['options'], options)
        replay = check_lp(record['matrix'], record['objective'], options, record['result'])
        assert record['result']['status'] == status and record['replay'] == replay
        check_diagnostic(record)
    assert [r['arm'] for r in document['callback_controls']] == list(ARMS)
    for item in document['callback_controls']:
        assert item['exception_identity_preserved'] is True
        assert type(item['sites_checked']) is int and item['sites_checked'] > 0
    return dict(queries=len(expected), callback_arms=len(ARMS))


def check_capture(document):
    from fastunknot.normal_euler import _euler_model
    from fastunknot.normal_sector import _assemble_sector_kernel
    from fastunknot.normal_euler_tree_verify import verify_euler_branch_tree
    from fastunknot.normal_surface_geometry import _coordinates
    assert document['schema'] == 'lp-pivot-capture-v1'
    assert same(document['pins'], pins())
    assert document['passed'] is True and not document['failures'] and document['active'] is None
    source, prepared, provenance = authenticate_source()
    assert same(document['provenance'], provenance)
    assert same(document['options'], SOURCE_OPTIONS)
    full = tuple((t, q) for t in range(len(source['tetrahedra'])) for q in range(3))
    kernel = _assemble_sector_kernel(source, prepared, full, lambda: None)
    linear, weights = _euler_model(kernel, lambda: None)
    envelope = list(linear)
    for group, weight in zip(kernel.groups, weights):
        for j in range(len(full)):
            envelope[j] -= weight*min(kernel.potentials[c][j] for c in group)
    returned = document['source_result']
    stats = returned['stats']
    assert all(type(value) is int and value >= 0 for value in stats.values())
    expected_historical = dict(lp_calls=8, lp_pivots=10000, anchors_tested=10,
        reused_anchors=3, envelope_calls=1, lp_fallbacks=0,
        lp_ellipsoid_iterations=0, lp_feasibility_calls=0, nodes_attempted=1)
    assert {k: stats[k] for k in expected_historical} == expected_historical
    queries, attempts = document['records'], document['attempts']
    assert len(queries) == stats['lp_calls'] and len(attempts) == stats['nodes_attempted']
    cumulative = dict(pivots=0, ellipsoid_iterations=0, feasibility_calls=0)
    for number, record in enumerate(queries):
        assert record['sequence'] == number and record['arm'] == 'bland'
        attempt_index = record['context']['attempt_index']
        assert type(attempt_index) is int and 0 <= attempt_index < len(attempts)
        attempt = attempts[attempt_index]
        assert attempt['index'] == attempt_index
        assert attempt['source_sha256'] == provenance['source_sha256']
        mask = attempt['allowed_types']
        assert mask == [list(pair) for pair in sorted(set(map(tuple, mask)))]
        assert all(tuple(pair) in full for pair in mask)
        active = [3*t+q for t, q in mask]
        matrix = [[row[j] for j in active] for row in kernel.cycle_rows]
        assert record['matrix'] == [pairs(row) for row in matrix]
        context = record['context']
        if context['kind'] == 'envelope':
            assert context['anchors'] is None
            objective = envelope
        else:
            assert context['kind'] == 'anchors'
            anchors = context['anchors']
            assert len(anchors) == len(kernel.groups)
            assert all(type(a) is int and a in group for a, group in zip(anchors, kernel.groups))
            objective = list(linear)
            for anchor, weight in zip(anchors, weights):
                for j, value in enumerate(kernel.potentials[anchor]):
                    objective[j] -= weight*value
        assert record['objective'] == pairs(objective[j] for j in active)
        options = dict(policy='polynomial', fast_path_pivots=None,
            max_pivots=10000-cumulative['pivots'],
            max_ellipsoid_iterations=10000-cumulative['ellipsoid_iterations'],
            max_feasibility_calls=10000-cumulative['feasibility_calls'])
        assert same(record['options'], options)
        assert record['query_sha256'] == digest({key: record[key] for key in ('matrix', 'objective', 'options', 'context')})
        replay = check_lp(record['matrix'], record['objective'], options, record['result'])
        assert record['replay'] == replay
        assert record['result_sha256'] == digest(record['result'])
        check_diagnostic(record)
        for field in cumulative:
            cumulative[field] += record['result']['stats'][field]
    for field, source_field in (('pivots', 'lp_pivots'),
                                ('ellipsoid_iterations', 'lp_ellipsoid_iterations'),
                                ('feasibility_calls', 'lp_feasibility_calls')):
        assert cumulative[field] == stats[source_field]
    assert sum(r['result']['stats']['tableau_updates'] for r in queries) == stats['lp_tableau_updates']
    assert sum(r['result']['stats']['fallback_used'] for r in queries) == stats['lp_fallbacks']
    if returned['status'] == 'NO_POSITIVE_EULER':
        assert verify_euler_branch_tree(source, returned['certificate'])
    elif returned['status'] == 'POSITIVE_EULER':
        assert _coordinates(prepared, returned['coordinates'], lambda: None)['euler_characteristic'] > 0
    else:
        assert returned['status'] == 'INCONCLUSIVE' and 'certificate' not in returned
    return dict(queries=len(queries), status=returned['status'], cumulative=cumulative,
                authenticated_source=True, fresh_whole_call=False)


def check_comparison(document, capture, capture_sha256):
    assert document['schema'] == 'lp-pivot-comparison-v1'
    assert same(document['pins'], pins())
    assert document['passed'] is True and not document['failures'] and document['active'] is None
    assert document['capture_sha256'] == capture_sha256
    assert document['order'] == 'query order; bland reused, then dantzig, then dantzig_lex'
    expected = [(q, arm) for q in capture['records'] for arm in ARMS]
    assert len(document['records']) == len(expected)
    totals = {arm: dict(queries=0, POSITIVE=0, NONPOSITIVE=0, INCONCLUSIVE=0,
                      pivots=0, tableau_updates=0, fallback_used=0) for arm in ARMS}
    for record, (query, arm) in zip(document['records'], expected):
        assert record['sequence'] == query['sequence'] and record['arm'] == arm
        assert record['query_sha256'] == query['query_sha256']
        assert record['reused_capture'] is (arm == 'bland')
        if arm == 'bland':
            assert same(record['result'], query['result'])
            assert same(record['diagnostic'], query['diagnostic'])
        replay = check_lp(query['matrix'], query['objective'], query['options'], record['result'])
        assert record['replay'] == replay and record['result_sha256'] == digest(record['result'])
        check_diagnostic(record)
        if record['result']['status'] != 'INCONCLUSIVE' and query['result']['status'] != 'INCONCLUSIVE':
            assert record['result']['status'] == query['result']['status']
        total = totals[arm]
        total['queries'] += 1
        total[record['result']['status']] += 1
        for field in ('pivots', 'tableau_updates', 'fallback_used'):
            total[field] += record['result']['stats'][field]
    assert document['summary'] == totals
    assert document['whole_call_shared_budget_claimed'] is False
    return totals
