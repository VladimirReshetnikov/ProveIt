"""Pinned scratch tableau; public controller/fallback remain native.

The copied helper changes exactly entering selection, leaving selection,
and an external progress hook. Baseline always uses the original helper.
"""
from fractions import Fraction
from fastunknot.exact_lp import _pair, _primitive

def _solve_prepared_kernel(source, c, selected, *, max_pivots, check):
    """Scratch copy: only pivot selectors and external diagnostics differ."""
    n = len(c)
    retained = [source[i] for i in selected]
    r = len(retained)
    inequalities = retained + [[-value for value in row] for row in retained]
    inequalities.append([Fraction(1)] * n)
    m, width = len(inequalities), n + len(inequalities)
    tableau = []
    for i, row in enumerate(inequalities):
        check()
        tableau.append(row + [Fraction(int(i == j)) for j in range(m)])
    rhs = [Fraction(0)] * (m - 1) + [Fraction(1)]
    basis = list(range(n, width))
    reduced = c + [Fraction(0)] * m
    value = Fraction(0)
    pivots = updates = 0

    def stats():
        largest = max((max(abs(x.numerator).bit_length(), x.denominator.bit_length())
                       for row in tableau for x in row), default=0)
        return dict(pivots=pivots, tableau_updates=updates,
                    variables=n, equations=len(source), retained_equations=r, tableau_rows=m,
                    tableau_columns=width, maximum_tableau_bits=largest)

    while True:
        check()
        if value > 0:
            vector = [Fraction(0)] * n
            for i, variable in enumerate(basis):
                if variable < n:
                    vector[variable] = rhs[i]
            if (any(x < 0 for x in vector) or sum(vector) > 1
                    or any(sum(a*x for a, x in zip(row, vector)) for row in source)
                    or sum(a*x for a, x in zip(c, vector)) != value):
                raise ArithmeticError('simplex produced an invalid positive basic point')
            check()
            return dict(status='POSITIVE', x=[_pair(x) for x in vector],
                        primitive_x=_primitive(vector), objective=_pair(value),
                        basis=basis, equation_rows=selected, stats=stats())
        entering = _entering(reduced, check)
        if entering is None:
            dual = [-reduced[n+i] for i in range(m)]
            y = [Fraction(0)]*len(source)
            for i, original in enumerate(selected):
                y[original] = dual[i] - dual[r+i]
            if (value != 0 or any(x < 0 for x in dual) or dual[-1] != 0
                    or any(sum(source[i][j]*y[i] for i in range(len(source))) < c[j]
                           for j in range(n))):
                raise ArithmeticError('simplex produced an invalid homogeneous dual')
            check()
            return dict(status='NONPOSITIVE', y=[_pair(x) for x in y],
                        equation_rows=selected, stats=stats())
        if max_pivots is not None and pivots >= max_pivots:
            check()
            return dict(status='INCONCLUSIVE', reason='LP pivot allowance exhausted',
                        equation_rows=selected, stats=stats())
        candidates = [i for i in range(m) if tableau[i][entering] > 0]
        if not candidates:
            raise ArithmeticError('the normalized kernel LP cannot be unbounded')
        leaving = _leaving(candidates, tableau, rhs, basis, entering, n, check)
        pivot = tableau[leaving][entering]
        tableau[leaving] = [x/pivot for x in tableau[leaving]]
        rhs[leaving] /= pivot
        updates += width + 1
        for i in range(m):
            check()
            if i == leaving:
                continue
            factor = tableau[i][entering]
            if factor:
                tableau[i] = [x-factor*y for x, y
                              in zip(tableau[i], tableau[leaving])]
                rhs[i] -= factor*rhs[leaving]
                updates += width + 1
        factor = reduced[entering]
        reduced = [x-factor*y for x, y in zip(reduced, tableau[leaving])]
        value += factor*rhs[leaving]
        updates += width + 1
        basis[leaving] = entering
        pivots += 1
        _progress(pivots, updates)
