"""Count-only scratch pilot. Subcommands are explicitly scheduled separately."""
import argparse
from copy import deepcopy
import inspect
import json
from pathlib import Path
from unittest.mock import patch

from common import (ARMS, CONTROL_CASES, ROOT, SOURCE_OPTIONS, digest, failure,
                    file_digest, new_document, pairs, pins, save)
from checker import (authenticate_source, check_capture, check_comparison,
                     check_controls, check_lp)
from prefix import diagnostics, prefix_rule, solve
from fastunknot import exact_lp


def completed_record(rule, matrix, objective, options, diagnostic):
    result = solve(rule, matrix, objective, options, diagnostic)
    replay = check_lp(matrix, objective, options, result)
    return dict(arm=rule, result=result, result_sha256=digest(result),
                replay=replay, diagnostic=diagnostic, returned_work_complete=True)


def controls(path):
    document = new_document('lp-pivot-controls-v1')
    document['callback_controls'] = []
    save(path, document)
    try:
        for name, matrix, objective, options, expected in CONTROL_CASES:
            for arm in ARMS:
                diagnostic = diagnostics()
                document['active'] = dict(phase='small_control', case=name, arm=arm,
                    diagnostic=diagnostic, returned_work_complete=False)
                save(path, document)
                record = completed_record(arm, matrix, objective, options, diagnostic)
                record.update(case=name, matrix=[pairs(row) for row in matrix],
                              objective=pairs(objective), options=options)
                document['records'].append(record)
                assert record['result']['status'] == expected
                document['active'] = None
                save(path, document)
        # Every actual callback position on one small degenerate trajectory.
        # Exception instances include ordinary Exception and BaseException.
        for arm in ARMS:
            document['active'] = dict(phase='callback_control', arm=arm,
                returned_work_complete=False)
            save(path, document)
            count = [0]
            def count_check():
                count[0] += 1
            with prefix_rule(arm, diagnostics()):
                exact_lp.solve_nonnegative_kernel([[1, 1, -1]], [1, 1, 0], check=count_check)
            for stop in range(1, count[0]+1):
                seen = [0]
                error = ValueError('scratch cancellation') if stop % 2 else KeyboardInterrupt('scratch cancellation')
                def cancel():
                    seen[0] += 1
                    if seen[0] == stop:
                        raise error
                try:
                    with prefix_rule(arm, diagnostics()):
                        exact_lp.solve_nonnegative_kernel([[1, 1, -1]], [1, 1, 0], check=cancel)
                except BaseException as caught:
                    assert caught is error
                else:
                    raise AssertionError('Expected cancellation was not raised')
            document['callback_controls'].append(dict(arm=arm, sites_checked=count[0],
                exception_identity_preserved=True))
            document['active'] = None
            save(path, document)
        assert document['pins'] == pins()
        document['passed'] = True
        document['summary'] = check_controls(document)
        save(path, document)
    except BaseException as error:
        document['passed'] = False
        failure(document, 'controls', error, details=deepcopy(document['active']))
        save(path, document)
        raise
    return document['summary']


def capture(path):
    from fastunknot import normal_euler_tree as tree
    from fastunknot.normal_euler_transversal import search_euler_transversal
    document = new_document('lp-pivot-capture-v1')
    document.update(options=SOURCE_OPTIONS, attempts=[])
    document['active'] = dict(phase='authenticate_source', returned_work_complete=False)
    save(path, document)
    original_solve = tree.solve_nonnegative_kernel
    original_attempt = tree._EulerMaskOracle.attempt
    contexts = []
    try:
        source, _, provenance = authenticate_source()
        document['provenance'] = provenance
        document['active'] = None
        save(path, document)

        def attempt(oracle, mask):
            context = dict(index=len(document['attempts']),
                source_sha256=digest(oracle.triangulation),
                allowed_types=[list(pair) for pair in mask])
            document['attempts'].append(context)
            contexts.append(context)
            try:
                return original_attempt(oracle, mask)
            finally:
                contexts.pop()

        def native_query(matrix, objective, **kwargs):
            assert len(contexts) == 1
            # This pinned source has one nested solve() called directly from
            # attempt(). Reading anchors annotates inputs, never changes them.
            frame = inspect.currentframe().f_back
            assert frame.f_code.co_name == 'solve'
            caller = frame.f_back
            assert caller.f_code is original_attempt.__code__
            anchors = caller.f_locals.get('anchors')
            context = dict(attempt_index=contexts[-1]['index'],
                kind='envelope' if anchors is None else 'anchors',
                anchors=None if anchors is None else list(anchors))
            callback = kwargs['check']
            options = {key: value for key, value in kwargs.items() if key != 'check'}
            record = dict(sequence=len(document['records']), arm='bland', context=context,
                matrix=[pairs(row) for row in matrix], objective=pairs(objective), options=options)
            record['query_sha256'] = digest({key: record[key] for key in ('matrix', 'objective', 'options', 'context')})
            diagnostic = diagnostics()
            document['active'] = dict(phase='native_query', query=record,
                diagnostic=diagnostic, returned_work_complete=False)
            save(path, document)
            def checked():
                diagnostic['callback_calls'] += 1
                callback()
            result = original_solve(matrix, objective, **options, check=checked)
            diagnostic['returned_or_completed_pivots_lower_bound'] = result['stats']['pivots']
            diagnostic['tableau_updates_lower_bound'] = result['stats']['tableau_updates']
            record.update(result=result, result_sha256=digest(result), diagnostic=diagnostic,
                replay=check_lp(matrix, objective, options, result), returned_work_complete=True)
            document['records'].append(record)
            document['active'] = None
            save(path, document)
            print(json.dumps(dict(phase='capture', query=record['sequence'],
                status=result['status'], pivots=result['stats']['pivots'])), flush=True)
            return result

        document['active'] = dict(phase='source_search', returned_work_complete=False)
        save(path, document)
        with patch.object(tree, 'solve_nonnegative_kernel', native_query), \
             patch.object(tree._EulerMaskOracle, 'attempt', attempt):
            result = search_euler_transversal(source, **SOURCE_OPTIONS)
        document['source_result'] = result
        document['active'] = None
        assert document['pins'] == pins()
        document['passed'] = True
        document['summary'] = check_capture(document)
        save(path, document)
    except BaseException as error:
        document['passed'] = False
        failure(document, 'capture', error, details=deepcopy(document['active']))
        save(path, document)
        raise
    return document['summary']


def compare(capture_path, path):
    document = new_document('lp-pivot-comparison-v1')
    document.update(order='query order; bland reused, then dantzig, then dantzig_lex',
        whole_call_shared_budget_claimed=False)
    document['active'] = dict(phase='capture_preflight', returned_work_complete=False)
    save(path, document)
    try:
        captured = json.loads(Path(capture_path).read_bytes())
        document['capture_sha256'] = file_digest(capture_path)
        check_capture(captured)
        for query in captured['records']:
            for arm in ARMS:
                diagnostic = diagnostics()
                document['active'] = dict(phase='fixed_query_replay',
                    sequence=query['sequence'], arm=arm, diagnostic=diagnostic,
                    returned_work_complete=False)
                save(path, document)
                if arm == 'bland':
                    record = {key: deepcopy(query[key]) for key in (
                        'arm', 'result', 'result_sha256', 'replay',
                        'diagnostic', 'returned_work_complete')}
                else:
                    record = completed_record(arm, query['matrix'], query['objective'],
                                              query['options'], diagnostic)
                record.update(sequence=query['sequence'], query_sha256=query['query_sha256'],
                              reused_capture=arm == 'bland')
                document['records'].append(record)
                document['active'] = None
                save(path, document)
                print(json.dumps(dict(phase='compare', query=query['sequence'], arm=arm,
                    status=record['result']['status'], pivots=record['result']['stats']['pivots'])), flush=True)
        totals = {arm: dict(queries=0, POSITIVE=0, NONPOSITIVE=0, INCONCLUSIVE=0,
                          pivots=0, tableau_updates=0, fallback_used=0) for arm in ARMS}
        for record in document['records']:
            total = totals[record['arm']]
            total['queries'] += 1
            total[record['result']['status']] += 1
            for field in ('pivots', 'tableau_updates', 'fallback_used'):
                total[field] += record['result']['stats'][field]
        document['summary'] = totals
        assert document['pins'] == pins()
        assert document['capture_sha256'] == file_digest(capture_path)
        document['passed'] = True
        check_comparison(document, captured, document['capture_sha256'])
        save(path, document)
    except BaseException as error:
        document['passed'] = False
        failure(document, 'comparison', error, details=deepcopy(document['active']))
        save(path, document)
        raise
    return document['summary']


def replay(controls_path, capture_path, comparison_path):
    # Kernel discovery is explicitly disabled during mathematical replay.
    with patch.object(exact_lp, 'solve_nonnegative_kernel', side_effect=AssertionError('discovery disabled')), \
         patch.object(exact_lp, '_solve_prepared_kernel', side_effect=AssertionError('discovery disabled')):
        summary = {}
        if controls_path is not None:
            summary['controls'] = check_controls(json.loads(Path(controls_path).read_bytes()))
        if capture_path is not None:
            captured = json.loads(Path(capture_path).read_bytes())
            summary['capture'] = check_capture(captured)
        if comparison_path is not None:
            assert capture_path is not None
            summary['comparison'] = check_comparison(json.loads(Path(comparison_path).read_bytes()),
                captured, file_digest(capture_path))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for command in ('controls', 'capture'):
        p = sub.add_parser(command)
        p.add_argument('--out', type=Path, required=True)
    p = sub.add_parser('compare')
    p.add_argument('--capture', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p = sub.add_parser('check')
    p.add_argument('--controls', type=Path)
    p.add_argument('--capture', type=Path)
    p.add_argument('--comparison', type=Path)
    args = parser.parse_args()
    if args.command != 'check' and args.out.exists():
        raise FileExistsError('Refuse to overwrite retained pilot output: '+str(args.out))
    if args.command == 'controls':
        result = controls(args.out)
    elif args.command == 'capture':
        result = capture(args.out)
    elif args.command == 'compare':
        result = compare(args.capture, args.out)
    else:
        result = replay(args.controls, args.capture, args.comparison)
    print(json.dumps(dict(passed=True, command=args.command, summary=result), sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
