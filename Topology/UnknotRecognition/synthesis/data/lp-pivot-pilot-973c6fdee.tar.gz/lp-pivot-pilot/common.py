"""Immutable inputs and isolated imports for a scratch, count-only LP pilot."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SNAPSHOT = ROOT / 'snapshot'
NATIVE = SNAPSHOT / 'native'
sys.path.insert(0, str(NATIVE))
if not __debug__:
    raise RuntimeError('Evidence checks require assertions enabled')

from fastunknot.integer_codec import encoded_integer, json_safe

ARMS = ('bland', 'dantzig', 'dantzig_lex')
SCRIPT_NAMES = ('common.py', 'prefix_template.py', 'prefix.py', 'checker.py',
                'pilot.py', 'PROTOCOL.json', 'DESIGN.md')
SOURCE_HASH = '5f53366b61f16027b896868a66cee02dce1c7a21b0cbb513e4ef583d2fd44345'
SOURCE_OPTIONS = dict(strategy='envelope', candidate_policy='conflicts',
    max_nodes=256, max_pivots=10000, max_anchors=10000,
    max_hitting_subsets=10000, lp_policy='polynomial',
    lp_fast_path_pivots=None, max_ellipsoid_iterations=10000,
    max_feasibility_calls=10000)
CONTROL_CASES = (
    ('degenerate_positive', [[1, 1, -1]], [1, 1, 0], {}, 'POSITIVE'),
    ('dependent_original_dual', [[1, -1], [2, -2], [0, 0]], [1, -2], {}, 'NONPOSITIVE'),
    ('zero_width', [[], []], [], {}, 'NONPOSITIVE'),
    ('user_zero', [[1, -1]], [1, 0], {'max_pivots': 0}, 'INCONCLUSIVE'),
    ('user_one', [[1, -1]], [1, 0], {'max_pivots': 1}, 'INCONCLUSIVE'),
    ('forced_fallback', [[1, -1]], [1, 0], {'fast_path_pivots': 0}, 'POSITIVE'),
    ('capped_fallback', [[1, -1]], [1, 0],
        {'fast_path_pivots': 0, 'max_ellipsoid_iterations': 0}, 'INCONCLUSIVE'),
)


def canonical(value):
    return json.dumps(json_safe(value), sort_keys=True, separators=(',', ':')).encode()


def digest(value):
    return sha256(canonical(value)).hexdigest()


def file_digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_bytes(canonical(value) + b'\n')
    temporary.replace(path)


def rational(value):
    if type(value) is Fraction:
        return value
    if type(value) in (list, tuple):
        assert len(value) == 2
        a, b = (encoded_integer(x) for x in value)
        assert b > 0
        return Fraction(a, b)
    return Fraction(encoded_integer(value))


def pairs(values):
    return [[x.numerator, x.denominator] for x in map(rational, values)]


def same(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(same(left[k], right[k]) for k in left)
    if type(left) in (list, tuple):
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    return left == right


def pins():
    manifest = json.loads((SNAPSHOT / 'manifest.json').read_bytes())
    actual = {str(p.relative_to(SNAPSHOT)): file_digest(p)
              for p in sorted(SNAPSHOT.rglob('*')) if p.is_file()
              and p.name != 'manifest.json' and '__pycache__' not in p.parts
              and p.suffix != '.pyc'}
    assert actual == manifest['files'], 'Frozen old-source snapshot changed'
    for name, module in tuple(sys.modules.items()):
        if name == 'fastunknot' or name.startswith('fastunknot.'):
            filename = getattr(module, '__file__', None)
            if filename is not None:
                assert Path(filename).resolve().is_relative_to(NATIVE)
    return dict(snapshot_manifest_sha256=file_digest(SNAPSHOT / 'manifest.json'),
        snapshot_revision=manifest['revision'], snapshot_files=actual,
        scripts={name: file_digest(ROOT / name) for name in SCRIPT_NAMES})


def new_document(schema):
    return dict(schema=schema, pins=pins(), passed=False, failures=[], active=None,
                records=[], wall_limit_seconds=None, timings_claimed=False)


def failure(document, phase, error, *, details=None):
    document['failures'].append(dict(phase=phase,
        exception_class=type(error).__name__, message=str(error),
        returned_work_complete=False, details=details))


def source_input():
    from fastunknot.diagram import Diagram
    audit_path = SNAPSHOT / 'evidence/geometric-descent-audit.json'
    audit = json.loads(audit_path.read_bytes())
    cases = [r for r in audit['records'] if r['id'] == 'W34']
    assert len(cases) == 1
    record = cases[0]
    diagram = Diagram.from_braid(3, [1, -2, 1, -2, 1, -2, 1, -2])
    assert same(record['input_pd'], [list(row) for row in diagram.pd])
    result = record['arms']['geometric']['result']
    assert result['status'] == 'INCONCLUSIVE'
    chain = result['partial_chain']
    source = chain['triangulation']
    assert digest(source) == SOURCE_HASH and len(source['tetrahedra']) == 31
    return diagram, source, chain, dict(audit_sha256=file_digest(audit_path),
        case_id='W34', arm='geometric', input_pd=record['input_pd'],
        source_sha256=SOURCE_HASH, partial_chain_sha256=digest(chain))
