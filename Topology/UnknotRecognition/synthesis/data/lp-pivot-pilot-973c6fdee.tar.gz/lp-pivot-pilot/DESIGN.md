# Frozen scratch pivot pilot

This is a count-only experiment on an authenticated W34 source, scoped to
revision `973c6fdee7b9ee6239c16b8d325207b6f667e95e`. It changes no repository
files. The 302-file snapshot occupies approximately 10.2 MB and includes every
native package file plus the archived whole-call audit. `manifest.json` pins
every copied byte. Every command imports `snapshot/native/fastunknot`, checks
that loaded native modules come from that location, and pins the scratch
scripts and protocol. Later repository edits do not alter this experiment.

## Mathematical invariant

The kernel LP is `Cx=0, x>=0, sum(x)<=1`, with an objective whose positive
value suffices. Its initial feasible slack basis has paired matching rows
with RHS zero and one normalization row with RHS one. All three rules retain
the same row selection, original equations, normalization, tableau updates,
early-positive and dual tests, result fields, and hard-cap ordering.

The alternate rules change only entering/leaving selection. Dantzig chooses
the largest strictly positive reduced cost, breaking exact ties by smallest
column. With the ordinary ratio/basic-index leaving rule it can cycle; no
cycling detection or hidden restart changes its allotted trajectory.

For lexicographic leaving, let `a>0` be the entering coefficient. Compare
`(rhs/a, T[n]/a, ..., T[n+m-1]/a)` across eligible rows. The complete original
slack block is `B^-1`; it is never shortened to currently nonbasic slacks.
This tuple is precisely the ratio for the fixed symbolic RHS
`b + epsilon*e0 + epsilon^2*e1 + ...`. The initial basis is lex feasible;
ratio pivots preserve feasibility. Distinct candidate tuples cannot tie,
since distinct rows of `B^-1` cannot be proportional. A strictly positive
reduced cost gives strict symbolic progress, excluding repeated bases.
Equality pairs, zero RHS, and slack entering variables require no exception.
The unperturbed RHS still supplies the returned original-system witness.
This anti-cycling argument does not give a polynomial unrestricted pivot bound.

The native facade caps every prefix by `(n+r+1)^2`, optionally reduced by
`fast_path_pivots` and the remaining caller pivot allowance. Terminal tests
precede exhaustion checks, preserving success on the last allowed pivot.
Exhausting a caller allowance still prevents fallback. An internal prefix
limit invokes the unchanged exact bounded-feasibility fallback only when
the caller retains allowance. Callback exceptions propagate unchanged.
The public explicit `policy='bland'` code is untouched; alternate scratch
arms only accept polynomial-policy queries.

For every visited basis, Cramer's rule bounds `B^-1 A`, `B^-1 b`, and reduced
costs using minors of the same fixed input matrix. These reduced rational
bit bounds do not depend on the selection rule or lack of cycling. Dantzig
selection scans `O(n+m)` coefficients. Forming full lex keys costs at most
`O(m^2)` rational operations and storage per pivot, within the dense
tableau's polynomial scale. The cap therefore preserves the existing
polynomial bit-time proof. No Devex weight recurrence is introduced.

## Input and experiment scope

The frozen W34 whole-call audit reports eight LP calls at its final
31-tetrahedron source, one oracle node, ten tested anchors (three reused),
10,000 pivots, zero fallbacks and 45,184,980 tableau updates. The source hash
is `5f53366b61f16027b896868a66cee02dce1c7a21b0cbb513e4ef583d2fd44345`.
Capture first independently replays the diagram-bound partial chain and
validates one vertex and two boundary faces. It then runs the current frozen
native transversal/conflicts search with the exact protocol caps.

This is a fresh authenticated-source continuation, not a new whole-call
recognition run. It uses no historical private LP inputs. A wrapper around
`normal_euler_tree.solve_nonnegative_kernel` records every actual matrix,
objective, options/remaining allowances and returned native answer while
passing the answer back unchanged. An attempt wrapper and read-only frame
annotation retain mask and anchor/envelope context. All calls, including
the capped last call, are retained in their original order. The expected
eight-call historical counts are checked after capture; any discrepancy
leaves explicit failed evidence rather than selecting a favorable subset.

The captured native answers constitute the Bland arm. Both alternatives
are run on every exact captured input with that input's original remaining
allowances. No more efficient arm gets extra allowed pivots on later inputs,
and no failing arm's subsequent inputs are dropped. Consequently offline
aggregate counts are not the work of a fresh driver under a shared 10,000
pivot cap. A different ray or dual can alter later branches/cache reuse; a
separate future whole-call experiment would be required to measure that.

The independent checker uses reverse-column exact elimination, not the
producer's row selector or an enumerator. Positive outputs must satisfy
every original equation, normalization, positivity, primitive scaling,
support nullity one, and a full-rank feasible original slack basis. Negative
outputs must satisfy every original-row dual inequality. INCONCLUSIVE
results carry no certificate. Reconstruction of the captured source matrix
and objective uses the frozen source algebra only as a source-binding check;
it is separate from independent rational witness replay. Recorded counters
are diagnostics, not an independently reconstructed execution trace.
The existing `maximum_tableau_bits` statistic concerns the returned tableau,
not all visited tableaus. Extra selector/callback counters have explicit
different meanings and are not interchangeable runtime units.

## Controls and retention

The seven predeclared small controls run in all three arms: a degenerate
positive kernel, dependent original-row dual, zero-width kernel, zero/one
user caps, forced fallback, and a capped fallback. No exponential
`normalized_vertices` helper is called. Separate tiny callback controls
exercise every visited poll position with exact exception-instance checks.

Each completed query is saved atomically before the next query. An active
record survives an unreturned query; exceptions retain its identity, phase,
available lower-bound diagnostic work and `returned_work_complete=false`.
Capped returned results are retained as complete calls with INCONCLUSIVE
status. Final replay/pin/coverage failures are also retained. Existing
output files are never overwritten by a discovery command.

## Scheduled commands

Run each command only after root schedules it. Interpreter imports and
source pins are isolated, and `-B` avoids modifying the snapshot.

```sh
/tmp/unknot-regina-env/bin/python -B /tmp/lp-pivot-pilot/pilot.py controls --out /tmp/lp-pivot-pilot/results/controls.json > /tmp/lp-pivot-pilot/controls.log 2>&1
/tmp/unknot-regina-env/bin/python -B /tmp/lp-pivot-pilot/pilot.py capture --out /tmp/lp-pivot-pilot/results/capture.json > /tmp/lp-pivot-pilot/capture.log 2>&1
/tmp/unknot-regina-env/bin/python -B /tmp/lp-pivot-pilot/pilot.py compare --capture /tmp/lp-pivot-pilot/results/capture.json --out /tmp/lp-pivot-pilot/results/comparison.json > /tmp/lp-pivot-pilot/comparison.log 2>&1
/tmp/unknot-regina-env/bin/python -B -S /tmp/lp-pivot-pilot/pilot.py check --controls /tmp/lp-pivot-pilot/results/controls.json --capture /tmp/lp-pivot-pilot/results/capture.json --comparison /tmp/lp-pivot-pilot/results/comparison.json > /tmp/lp-pivot-pilot/replay.log 2>&1
```

The capture should reproduce 10,000 native pivots. Each comparison arm is
bounded by the sum of captured per-query remaining allowances, at most
80,000 pivots for eight inputs; fallback caps, if reached, remain unchanged.
The actual replay budget will be printed/inspected after capture before
comparison is scheduled. Controls should be small; capture/comparison may
take minutes or tens of minutes. These are scheduling estimates, not
performance claims. Tables and vectors have only about 100 columns at this
source; expected outputs are modest compared with the 10.2 MB snapshot, but
no unmeasured storage or runtime figure is asserted. There is no wall limit,
timing comparison, whole-call speedup claim, or general quasi-polynomial
conclusion in this pilot.
