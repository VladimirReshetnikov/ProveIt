FLEXIBLEOUTPUT: THRESHOLD SEARCHES IN THE ARITHMETIC COMPILER
Prepared for Vladimir Reshetnikov — November 9, 2026

RESULT
======

A new, compiled simplification of four supporting compiler proofs:

    a - b       = least k such that a <= b + k
    sqrt(a)     = least k such that a < (k+1)^2
    q(a,b)      = least k such that b = 0 or a < (k+1)*b
    a mod b     = a - q(a,b)*b
    a divides b iff b mod a = 0.

Natural subtraction is truncated. For b=0, q(a,b)=0, so the remainder
formula returns a and agrees with Lean's Nat.mod_zero.

The substantive patch changes only proofs in Foundation/Vorspiel/Arithmetic.lean
and moves dvd below rem. It retains all four public theorem statements.
The original graph, ValueIn, Main theorem proof text, and global functionality
theorem are preserved.

MEASURED REDUCTION
==================

Four edited declarations, statement plus proof, nonblank source lines:
    sub: 25 -> 9
    sqrt: 9 -> 7
    rem: 24 -> 22
    dvd: 34 -> 3
    total: 92 -> 41 (55.4% fewer).

Entire arithmetic file: 584 -> 532 physical lines.
Main theorem declaration closure: 16,960 -> 16,891 reachable declarations.
The arithmetic dvd and inverse-interval implicit_fun helpers leave the
main theorem's actual proof dependency closure; they remain public.

The main proof itself is unchanged. The global body-tree reduction is only
about 0.030%. The direct rem proof expression grows from 16,111 to 42,695
nodes, while its complete dependency closure shrinks. No speedup or global
minimality claim is made. See the report and proof_metrics.csv for all scopes.

NOVELTY
=======

All eleven ZIP archives in the requested proposals directory were inspected
and their bytes checked against GitHub blob hashes. The arithmetic threshold
constructions are absent from those proposals. The only earlier arithmetic-file
patch changes ArithPart bind/map, not sub/sqrt/rem/dvd/implicit_fun.

This is relative nonduplication against the specified archives, not a claim
of new mathematical threshold identities or literature-wide priority.

SNAPSHOTS AND VERIFICATION
==========================

ProveIt: 676f6273deff80458bb16315ef0262caae347170
Foundation: 32e1a0956a8622fad067328ca1959729a7634428
Mathlib: 81a5d257c8e410db227a6665ed08f64fea08e997
Lean: 4.32.0

The later observed head 57a3cb365bc88cd555b8f6f7e8b423654ebcd638
has the same FlexibleOutput Lean source subtree and proposal archive identities.

All ten affected source modules were re-elaborated in a fresh output directory;
all compiled with zero errors and zero warnings. The interface/axiom/dependency
audit passed. All twelve printed endpoints have only propext, Classical.choice,
and Quot.sound as axioms. No missing declarations or reachable sorryAx.

Unchanged pinned dependencies were reused from verified caches; this was not a
from-scratch rebuild of all libraries. The full source hashes, dependency build
plan, logs, and complete declaration graphs are included.

PREREQUISITE IMPORT REPAIR
=========================

The pinned snapshot's Main and facade import PAFlexibleOutput.Refutations,
but the implementation is named Provability.lean. The separate root patch
changes those two imports to PAFlexibleOutput.Provability. Both the baseline
and candidate comparisons use this same prerequisite repair. It contributes
no novelty credit and none of the arithmetic source reduction.

CONTENTS
========

report/flexible_output_threshold_search.tex
report/flexible_output_threshold_search.pdf
    Complete report, proofs, exact replacement declarations, measurements,
    archive comparison, qualifications, and pinned primary references.

patches/01_import_repair.patch
    Apply at the ProveIt repository root.

patches/02_threshold_compiler.patch
    Apply at the Foundation submodule root.

baseline/ and overlay/
    Exact original and replacement bytes for all three edited files.

context/
    The original six FlexibleOutput Lean modules at the pinned snapshot.

verification/Audit.lean
    Exact public type checks; axiom prints; complete declaration dependency audit.

evidence/
    Full raw baseline/candidate graphs, numerical comparison, source measurements,
    all eleven archive identities, novelty audit, mathematical review, build logs,
    dependency pins, source hashes, and environment notes.

scripts/
    Hash-checked application, portable Lean verification, report building,
    source measurement, and proof-dependency comparison.

licenses/
    Upstream licenses for included original and modified source.

USAGE
=====

From this package directory, with a suitable ProveIt checkout:

    python3 scripts/apply.py --repo /path/to/ProveIt
    python3 scripts/apply.py --repo /path/to/ProveIt --apply
    bash scripts/check_lean.sh /path/to/ProveIt

The default apply.py invocation checks only. It checks all relevant files
before writing and refuses to overwrite unrecognized bytes. Use
--compiler-only to omit the separate import repair.

For ordinary manual patch application:

    git -C /path/to/ProveIt apply /path/to/package/patches/01_import_repair.patch
    git -C /path/to/ProveIt/lib/FormalizedFormalLogic-Foundation apply /path/to/package/patches/02_threshold_compiler.patch

Reproduce source counts:

    python3 scripts/measure_source.py

Reproduce dependency comparison from the supplied complete graphs:

    python3 scripts/compare_proof_dependencies.py evidence/baseline_dependency_graph.json evidence/candidate_dependency_graph.json --output comparison.json

Build the PDF:

    bash scripts/build_report.sh

No remote repository has been changed by preparing this proposal.
