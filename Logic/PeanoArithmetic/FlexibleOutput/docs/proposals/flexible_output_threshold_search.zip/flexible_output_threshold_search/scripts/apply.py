#!/usr/bin/env python3
"""Apply the proposal after verifying every affected file's exact bytes.

Default: check only. Pass --apply to write. Files already at the candidate
version are accepted. All files are checked before any write occurs.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--compiler-only", action="store_true",
                        help="Omit the separate two-import prerequisite repair.")
    args = parser.parse_args()
    package = Path(__file__).resolve().parent.parent
    repo = args.repo.resolve()
    changes = json.loads((package / "evidence/change_manifest.json").read_text())
    if args.compiler_only:
        changes = [row for row in changes if row["kind"] == "substantive"]
    pending, errors = [], []
    for row in changes:
        target = repo / row["path"]
        replacement = package / "overlay" / row["path"]
        if not replacement.is_file() or digest(replacement) != row["candidate_sha256"]:
            errors.append(f"Package replacement hash mismatch: {row['path']}")
            continue
        if not target.is_file():
            errors.append(f"Missing target: {row['path']}")
            continue
        current = digest(target)
        if current == row["candidate_sha256"]:
            print(f"Already applied: {row['path']}")
        elif current == row["baseline_sha256"]:
            pending.append((target, replacement, row["path"]))
        else:
            errors.append(f"Unrecognized target bytes; preserving file: {row['path']}")
    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    for target, replacement, relative in pending:
        if args.apply:
            target.write_bytes(replacement.read_bytes())
            print(f"Applied: {relative}")
        else:
            print(f"Ready: {relative}")
    print("Application complete." if args.apply else "Check passed. Use --apply to write.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
