#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: bash check_lean.sh /absolute/path/to/ProveIt [audit-output-directory]" >&2
  exit 2
fi
package_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
repo_dir="$(cd "$1" && pwd)"
audit_dir="${2:-$package_dir/recheck}"
mkdir -p "$audit_dir"
audit_dir="$(cd "$audit_dir" && pwd)"
cd "$repo_dir"
export LAKE_JOBS=1
export LEAN_NUM_THREADS=0
lake build +PAFlexibleOutput.Main 2>&1 | tee "$audit_dir/main.log"
lake build +PAFlexibleOutput 2>&1 | tee "$audit_dir/facade.log"
export AUDIT_OUTPUT="$audit_dir/dependency_graph.json"
lake env lean "$package_dir/verification/Audit.lean" 2>&1 | tee "$audit_dir/audit.log"
python3 "$package_dir/scripts/compare_proof_dependencies.py" \
  "$package_dir/evidence/baseline_dependency_graph.json" \
  "$audit_dir/dependency_graph.json" --output "$audit_dir/comparison.json" \
  > "$audit_dir/comparison-summary.txt"
echo "Lean verification completed. Evidence: $audit_dir"
