#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$package_dir/report"
latexmk -pdf -interaction=nonstopmode -halt-on-error flexible_output_threshold_search.tex
