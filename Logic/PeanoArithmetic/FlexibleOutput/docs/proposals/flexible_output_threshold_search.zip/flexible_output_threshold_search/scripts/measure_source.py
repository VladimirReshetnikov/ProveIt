#!/usr/bin/env python3
"""Reproduce the source counts from the exact old/new files in the package."""
from pathlib import Path
import json
import re

package = Path(__file__).resolve().parent.parent
relative = Path("lib/FormalizedFormalLogic-Foundation/Foundation/Vorspiel/Arithmetic.lean")
old = (package / "baseline" / relative).read_text()
new = (package / "overlay" / relative).read_text()
heads = {"sqrt": "protected lemma sqrt {n}", "sub": "lemma sub {n}",
         "rem": "lemma rem (i j", "dvd": "lemma dvd (i j"}


def extract(source, head):
    start = source.index(head)
    match = re.search(r"\n(?:(?:protected |private )?(?:lemma|theorem|def)|set_option|end |namespace )",
                      source[start + 1:])
    stop = len(source) if match is None else start + 1 + match.start() + 1
    return source[start:stop].rstrip() + "\n"


rows = []
for name, head in heads.items():
    a, b = extract(old, head), extract(new, head)
    assert not any(marker in a + b for marker in ["/-", "--"]), "Unexpected comments"
    assert all(line.strip() for line in a.splitlines() + b.splitlines()), "Unexpected blank line"
    rows.append({"name": name, "before_lines": len(a.splitlines()),
                 "after_lines": len(b.splitlines()),
                 "before_bytes": len(a.encode()), "after_bytes": len(b.encode())})
result = {"declarations": rows, "whole_file": {
    "before_lines": len(old.splitlines()), "after_lines": len(new.splitlines()),
    "before_bytes": len(old.encode()), "after_bytes": len(new.encode())}}
expected = json.loads((package / "evidence/source_metrics.json").read_text())
assert result == expected, "Recorded metrics differ from the provided source files"
print(json.dumps(result, indent=2))
