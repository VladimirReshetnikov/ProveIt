#!/usr/bin/env python3
"""Compare full Lean declaration graphs exported by audit_source/Audit.lean.

No imported module count is interpreted as a proof dependency count. Traversal
uses types, proof/definition bodies (including opaque bodies), and inductive
constructors. All sizes are syntactic diagnostics, not build-time measurements.
"""
from __future__ import annotations
import argparse
from collections import deque
import json
from pathlib import Path

WATCH = [
    'Nat.Arithmetic₁.dvd', 'Nat.ArithPart₁.implicit_fun', 'Nat.ArithPart₁.inv_fun',
    'Nat.Arithmetic₁.sub', 'Nat.Arithmetic₁.sqrt', 'Nat.Arithmetic₁.rem',
    'Nat.Arithmetic₁.prec', 'Nat.ArithPart₁.of_partrec',
]
METRICS = ['type_nodes', 'value_nodes', 'type_objects', 'value_objects']
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}


def read_graph(path: Path):
    data = json.loads(path.read_text())
    records = {r['name']: r for r in data['declarations']}
    assert len(records) == data['count'], 'Duplicate declaration records'
    assert not data['missing'], f"Missing declarations: {data['missing']}"
    assert 'sorryAx' not in records, 'sorryAx found'
    assert set(data['axioms']) <= ALLOWED_AXIOMS, data['axioms']
    assert all(ref in records for r in records.values() for ref in r['references'])
    return data, records


def reachable(records, root):
    seen, pending = set(), [root]
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        pending.extend(records[name]['references'])
    return seen


def shortest_path(records, root, target):
    parents = {root: None}
    queue = deque([root])
    while queue:
        name = queue.popleft()
        if name == target:
            path = []
            while name is not None:
                path.append(name)
                name = parents[name]
            return path[::-1]
        for ref in records[name]['references']:
            if ref not in parents:
                parents[ref] = name
                queue.append(ref)
    return None


def sum_sizes(records, names):
    return {'declarations': len(names), **{
        metric: sum(records[n][metric] for n in names) for metric in METRICS
    }}


def summarize_root(records, root):
    names = reachable(records, root)
    local = {n for n in names if records[n]['module'].startswith(('Foundation.', 'PAFlexibleOutput'))}
    return {
        'all': sum_sizes(records, names),
        'repository_local': sum_sizes(records, local),
        'root_declaration': {k: records[root][k] for k in
            ['name', 'module', *METRICS, 'type_hash', 'value_hash']},
        'axioms': sorted(n for n in names if records[n]['is_axiom']),
        'watch': {n: n in names for n in WATCH},
    }, names


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('baseline', type=Path)
    p.add_argument('candidate', type=Path, nargs='?')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    bd, br = read_graph(args.baseline)
    result = {
        'method': 'Traverse declaration types, values including opaque bodies, and inductive constructors.',
        'baseline_source': str(args.baseline),
        'roots': {},
        'caveats': [
            'Expression tree nodes count repeated occurrences of shared subexpressions.',
            'Allocated Expr object counts respect sharing within each expression, but are runtime diagnostics.',
            'Sizes are summed per declaration; sharing across declarations is not deducted.',
            'Types and proof bodies are reported separately.',
            'All includes pinned Mathlib and Lean; repository_local includes vendored Foundation and PAFlexibleOutput.',
            'Declaration hashes are diagnostics, not theorem-equality certificates.',
            'The audit contains explicit type-ascription checks for all public theorem interfaces used here.',
            'No compile-time or runtime speedup is inferred from these counts.',
            'Unused public helper declarations remain exported; absence from a root closure is not deletion from the source file.',
        ],
    }
    if args.candidate:
        cd, cr = read_graph(args.candidate)
        assert bd['roots'] == cd['roots'], 'Different audit roots'
        result['candidate_source'] = str(args.candidate)
    for root in bd['roots']:
        bs, bn = summarize_root(br, root)
        row = {'baseline': bs}
        if args.candidate:
            cs, cn = summarize_root(cr, root)
            shared = bn & cn
            changed = sorted(n for n in shared if any(br[n][k] != cr[n][k]
                for k in ['type_hash', 'value_hash', 'type_nodes', 'value_nodes']))
            row.update(candidate=cs, differences={
                'added_names': sorted(cn - bn), 'removed_names': sorted(bn - cn),
                'shared_name_count': len(shared),
                'changed_hash_or_tree_size_names': changed,
                'unchanged_hash_and_tree_size_count': len(shared) - len(changed),
                'type_hashes_equal_for_shared_names': all(br[n]['type_hash'] == cr[n]['type_hash'] for n in shared),
                'root_type_hash_equal': br[root]['type_hash'] == cr[root]['type_hash'],
                'root_value_hash_equal': br[root]['value_hash'] == cr[root]['value_hash'],
                'all_metric_delta': {k: cs['all'][k] - bs['all'][k] for k in ['declarations', *METRICS]},
                'repository_local_metric_delta': {k: cs['repository_local'][k] - bs['repository_local'][k]
                    for k in ['declarations', *METRICS]},
            })
        result['roots'][root] = row
    root = 'PAFlexibleOutput.flexibleOutput'
    result['baseline_dependency_paths'] = {n: shortest_path(br, root, n) for n in WATCH}
    if args.candidate:
        result['candidate_dependency_paths'] = {n: shortest_path(cr, root, n) for n in WATCH}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({root: {side: {
        'all': row[side]['all'], 'repository_local': row[side]['repository_local'],
        'root_declaration': row[side]['root_declaration'], 'watch': row[side]['watch']
    } for side in ['baseline', 'candidate'] if side in row}
        for root, row in result['roots'].items()
        if root in ['PAFlexibleOutput.flexibleOutput', 'Nat.Arithmetic₁.sub',
            'Nat.Arithmetic₁.sqrt', 'Nat.Arithmetic₁.rem', 'Nat.Arithmetic₁.dvd']}, indent=2))


if __name__ == '__main__':
    main()
