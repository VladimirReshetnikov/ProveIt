import PAFlexibleOutput.Main
import Lean

/-!
An audit of the unchanged theorem interfaces and the complete syntactic proof
dependency graph. We inspect declaration types and values, including opaque
theorem bodies. Inductive declarations additionally point to their constructors.
No import-only count is presented as a proof dependency count.
-/

set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open PAFlexibleOutput

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧ ∀ (x : ℕ) (o : Option ℕ),
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e x o :=
  flexibleOutput

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ x n : ℕ, Satisfiable (insert (haltSentence e x n) 𝗣𝗔) :=
  flexibleOutput_satisfiable

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧ ∀ o : Option ℕ,
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e 0 o :=
  exists_partrec_flexibleOutput

example (c : Code) (x y : ℕ) :
    ℕ↓[ℒₒᵣ] ⊧ haltSentence c x y ↔ y ∈ Nat.Partrec.Code.eval c x :=
  standardCorrectness c x y

example : Hierarchy 𝚺 1 universalGraph := universalGraph_sigma_one

example {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]
    {program input y z : M}
    (hy : M ⊧/![y, program, input] universalGraph)
    (hz : M ⊧/![z, program, input] universalGraph) : y = z :=
  universalGraph_uniq hy hz

example {n : ℕ} (i j : Fin n) :
    Nat.Arithmetic₁ (fun v => v.get i - v.get j) := Nat.Arithmetic₁.sub i j

example {n : ℕ} (i : Fin n) :
    Nat.Arithmetic₁ (fun v => Nat.sqrt (v.get i)) := Nat.Arithmetic₁.sqrt i

example {n : ℕ} (i j : Fin n) :
    Nat.Arithmetic₁ (fun v => v.get i % v.get j) := Nat.Arithmetic₁.rem i j

example {n : ℕ} (i j : Fin n) :
    Nat.Arithmetic₁ (fun v => Nat.isDvdNat (v.get i) (v.get j)) := Nat.Arithmetic₁.dvd i j

#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.universalGraph_sigma_one
#print axioms PAFlexibleOutput.universalGraph_uniq
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.exists_selector
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
#print axioms Nat.Arithmetic₁.sub
#print axioms Nat.Arithmetic₁.sqrt
#print axioms Nat.Arithmetic₁.rem
#print axioms Nat.Arithmetic₁.dvd

open Lean Elab Command

run_cmd do
  let env ← getEnv
  let roots : Array Name := #[
    ``PAFlexibleOutput.flexibleOutput,
    ``PAFlexibleOutput.flexibleOutput_satisfiable,
    ``PAFlexibleOutput.exists_partrec_flexibleOutput,
    ``PAFlexibleOutput.standardCorrectness,
    ``PAFlexibleOutput.universalGraph_sigma_one,
    ``PAFlexibleOutput.universalGraph_uniq,
    ``Nat.Arithmetic₁.sub, ``Nat.Arithmetic₁.sqrt,
    ``Nat.Arithmetic₁.rem, ``Nat.Arithmetic₁.dvd,
    ``Nat.Arithmetic₁.prec, ``Nat.ArithPart₁.of_partrec]
  let mut pending : List Name := roots.toList
  let mut seen : NameSet := {}
  let mut records : Array Json := #[]
  let mut missing : Array String := #[]
  let mut axioms : Array String := #[]
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    if seen.contains name then continue
    seen := seen.insert name
    match env.checked.get.find? name with
    | none => missing := missing.push name.toString
    | some ci =>
      let value := ci.value? true
      let mut refs := ci.type.getUsedConstants
      if let some expression := value then
        refs := refs ++ expression.getUsedConstants
      if let .inductInfo info := ci then
        refs := refs ++ info.ctors.toArray
      pending := refs.toList ++ pending
      let origin := match env.getModuleIdxFor? name with
        | some index => env.header.moduleNames.getD index.toNat .anonymous
        | none => env.mainModule
      let typeObjects ← liftIO ci.type.numObjs
      let valueObjects ← match value with
        | some expression => liftIO expression.numObjs
        | none => pure 0
      if ci.isAxiom then axioms := axioms.push name.toString
      records := records.push <| Json.mkObj [
        ("name", toJson name.toString), ("module", toJson origin.toString),
        ("type_nodes", toJson ci.type.sizeWithoutSharing),
        ("value_nodes", toJson ((value.map Expr.sizeWithoutSharing).getD 0)),
        ("type_objects", toJson typeObjects), ("value_objects", toJson valueObjects),
        ("type_hash", toJson (toString (hash ci.type))),
        ("value_hash", toJson ((value.map (fun e => toString (hash e))).getD "none")),
        ("is_axiom", toJson ci.isAxiom),
        ("references", toJson (refs.map Name.toString))]
  let result := Json.mkObj [
    ("roots", toJson (roots.map Name.toString)),
    ("count", toJson records.size), ("missing", toJson missing),
    ("axioms", toJson axioms), ("declarations", Json.arr records)]
  let target ← liftIO <| IO.getEnv "AUDIT_OUTPUT"
  let filename := target.getD "dependency-audit.json"
  liftIO <| IO.FS.writeFile filename (result.pretty ++ "\n")
  if missing.size != 0 then throwError "Dependency audit has missing declarations: {missing}"
  if seen.contains ``sorryAx then throwError "Dependency audit found sorryAx"
  logInfo m!"Dependency audit completed: {records.size} declarations; no missing declarations; no sorryAx. Wrote {filename}"
