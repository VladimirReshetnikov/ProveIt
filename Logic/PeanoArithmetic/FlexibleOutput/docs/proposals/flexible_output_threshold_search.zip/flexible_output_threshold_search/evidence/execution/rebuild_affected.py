#!/usr/bin/env python3
"""Re-elaborate an edited Foundation module and every affected importing client.

Only exact pinned, unchanged dependencies are reused from the read-only cache.
Overlay roots use normal Lean module paths (Foundation/...; PAFlexibleOutput/...).
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys, time
from compile import ROOT, BASE, LEAN, make_environment

def uncomment(text):
    out, i, depth = [], 0, 0
    while i < len(text):
        pair = text[i:i+2]
        if pair == '/-':
            depth += 1; i += 2
        elif depth and pair == '-/':
            depth -= 1; i += 2
        elif not depth and pair == '--':
            end = text.find('\n', i)
            i = len(text) if end < 0 else end
        else:
            out.append(text[i] if not depth or text[i] == '\n' else ' ')
            i += 1
    return ''.join(out)

def imports(text):
    found = []
    for line in uncomment(text).splitlines():
        words = line.strip().split()
        while words and words[0] in ('public', 'private', 'meta'):
            words.pop(0)
        if words and words[0] == 'import':
            found.extend(words[1:])
    return found

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--overlay', action='append', type=Path, required=True)
    p.add_argument('--project-source', type=Path,
      default=ROOT/'source/Logic/PeanoArithmetic/FlexibleOutput/Lean')
    p.add_argument('--output', type=Path, default=ROOT/'validation/final-olean')
    p.add_argument('--label', default='final')
    p.add_argument('--changed', action='append', default=[])
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('targets', nargs='*', default=['PAFlexibleOutput.Main', 'PAFlexibleOutput'])
    args = p.parse_args()
    overlays = [x.resolve() for x in args.overlay]
    roots = overlays + [args.project_source.resolve(), BASE/'lib/FormalizedFormalLogic-Foundation']
    nodes, order, visiting = {}, [], set()
    def visit(module):
        if module in nodes:
            return
        if module in visiting:
            raise RuntimeError('Import cycle: '+module)
        rel = Path(*module.split('.')).with_suffix('.lean')
        matches = [(r/rel, r) for r in roots if (r/rel).exists()]
        if not matches:
            if module.startswith(('Foundation.', 'PAFlexibleOutput')):
                raise FileNotFoundError('No source for '+module)
            return
        source, source_root = matches[0]
        visiting.add(module)
        text = source.read_text()
        dependencies = imports(text)
        for dependency in dependencies:
            visit(dependency)
        row = {'module': module, 'source': str(source), 'source_root': str(source_root),
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'imports': dependencies}
        nodes[module] = row
        order.append(module)
        visiting.remove(module)
    for target in args.targets:
        visit(target)
    changed = set(args.changed)
    for module, row in nodes.items():
        if Path(row['source_root']) in overlays:
            changed.add(module)
    affected = set(changed)
    for module in order:
        if any(dep in affected for dep in nodes[module]['imports']):
            affected.add(module)
    # Always re-elaborate the requested endpoints and all project modules.
    affected.update(m for m in order if m.startswith('PAFlexibleOutput'))
    build = [m for m in order if m in affected]
    plan = {'targets': args.targets, 'changed_modules': sorted(changed),
      'recompiled_modules': build, 'source_module_count': len(nodes),
      'sources': [nodes[m] for m in order]}
    (ROOT/'validation'/f'{args.label}_build_plan.json').write_text(json.dumps(plan, indent=2)+'\n')
    print(json.dumps({'source_module_count': len(nodes), 'recompile_count': len(build),
      'recompiled_modules': build}), flush=True)
    if args.dry_run:
        return 0
    env = make_environment(args.output)
    logs = ROOT/'validation/logs'
    logs.mkdir(parents=True, exist_ok=True)
    records = []
    for module in build:
        row = nodes[module]
        source, source_root = Path(row['source']), Path(row['source_root'])
        output = args.output.resolve()/Path(*module.split('.')).with_suffix('.olean')
        output.parent.mkdir(parents=True, exist_ok=True)
        for suffix in ['.olean', '.olean.private', '.olean.server', '.ilean', '.ir']:
            generated = output.with_suffix(suffix)
            if generated.exists() or generated.is_symlink():
                generated.unlink()
        command = [str(LEAN), '-j', '2', '-R', str(source_root), '-o', str(output),
          '-i', str(output.with_suffix('.ilean')), str(source)]
        start = time.monotonic()
        result = subprocess.run(command, cwd=source_root, env=env, capture_output=True, text=True)
        log = logs/f'{args.label}_{module}.log'
        log.write_text(result.stdout+result.stderr)
        record = {'module': module, 'exit_code': result.returncode,
          'seconds': round(time.monotonic()-start, 3), 'source_sha256': row['source_sha256'],
          'log': str(log), 'command': command}
        records.append(record)
        (ROOT/'validation'/f'{args.label}_affected_results.json').write_text(json.dumps(records, indent=2)+'\n')
        print(json.dumps(record), flush=True)
        if result.returncode:
            print(result.stdout+result.stderr, flush=True)
            return result.returncode
    return 0

if __name__ == '__main__':
    sys.exit(main())
