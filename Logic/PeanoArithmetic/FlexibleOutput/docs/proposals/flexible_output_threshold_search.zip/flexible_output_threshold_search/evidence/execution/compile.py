#!/usr/bin/env python3
"""Compile local Lean modules against pinned, read-only dependency artifacts.

For this recorded execution environment only. Repository users should instead
apply the delivered patch and run the documented lake build commands.
"""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, time

ROOT = Path(__file__).resolve().parent.parent
BASE = Path('/workspace/scratch/a5fd2c75507a/ProveIt')
LEAN = Path('/workspace/scratch/a5fd2c75507a/toolchain/lean-4.32.0-linux/bin/lean')
SHIM = ROOT / 'validation/proc_self_exe_compat.so'
FOUNDATION = BASE / '.lake/build/lib/lean/Foundation'
PACKAGES = BASE / '.lake/packages'

def make_environment(output):
    output = output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    for artifact in FOUNDATION.rglob('*'):
        if artifact.is_file():
            target = output / 'Foundation' / artifact.relative_to(FOUNDATION)
            if not target.exists() and not target.is_symlink():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.symlink_to(artifact.resolve())
    external = sorted(PACKAGES.glob('*/.lake/build/lib/lean'))
    env = os.environ.copy()
    env.update(LEAN_PATH=':'.join(map(str, [output] + external)),
               LEAN_NUM_THREADS='2', LD_PRELOAD=str(SHIM))
    return env

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, default=ROOT/'source/Logic/PeanoArithmetic/FlexibleOutput/Lean')
    parser.add_argument('--output', type=Path, default=ROOT/'validation/baseline-olean')
    parser.add_argument('--label', default='baseline')
    parser.add_argument('modules', nargs='*', default=['PAFlexibleOutput.Halting',
      'PAFlexibleOutput.Functionality', 'PAFlexibleOutput.Provability',
      'PAFlexibleOutput.Search', 'PAFlexibleOutput.Main', 'PAFlexibleOutput'])
    args = parser.parse_args()
    source_root, output_root = args.source.resolve(), args.output.resolve()
    env = make_environment(output_root)
    logs = ROOT/'validation/logs'
    logs.mkdir(parents=True, exist_ok=True)
    records = []
    for module in args.modules:
        rel = Path(*module.split('.'))
        source, output = source_root/rel.with_suffix('.lean'), output_root/rel.with_suffix('.olean')
        output.parent.mkdir(parents=True, exist_ok=True)
        for suffix in ['.olean', '.olean.private', '.olean.server', '.ilean', '.ir']:
            generated = output.with_suffix(suffix)
            if generated.is_symlink():
                generated.unlink()
        command = [str(LEAN), '-j', '2', '-R', str(source_root),
                   '-o', str(output), '-i', str(output.with_suffix('.ilean')), str(source)]
        start = time.monotonic()
        result = subprocess.run(command, cwd=source_root, env=env, capture_output=True, text=True)
        log = logs/f'{args.label}_{module}.log'
        log.write_text(result.stdout + result.stderr)
        row = {'module': module, 'exit_code': result.returncode,
          'seconds': round(time.monotonic()-start, 3),
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'log': str(log), 'command': command}
        records.append(row)
        print(json.dumps(row), flush=True)
        if result.returncode:
            print(result.stdout + result.stderr, flush=True)
            break
    (ROOT/'validation'/f'{args.label}_results.json').write_text(json.dumps(records, indent=2)+'\n')
    return int(any(row['exit_code'] for row in records))

if __name__ == '__main__':
    sys.exit(main())
