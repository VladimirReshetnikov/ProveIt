lemma dvd (i j : Fin n) : Arithmetic₁ (fun v => isDvdNat (v.get i) (v.get j)) :=
  ((equal 0 1).comp₂ _ (rem j i) zero).of_eq <| by
    intro v; simp [isDvdNat, isEqNat, Nat.dvd_iff_mod_eq_zero]
