lemma sub {n} (i j : Fin n) : Arithmetic₁ (fun v => v.get i - v.get j) := by
  have h : @Arithmetic₁ (n + 1) (fun v => isLeNat (v.get i.succ) (v.get j.succ + v.head)) :=
    (le 0 1).comp₂ _ (proj i.succ) ((add 0 1).comp₂ _ (proj j.succ) head)
  exact (ArithPart₁.rfindPos h).of_eq <| by
    intro v
    simp [Part.eq_some_iff]
    constructor
    · omega
    · intro m hm; omega
