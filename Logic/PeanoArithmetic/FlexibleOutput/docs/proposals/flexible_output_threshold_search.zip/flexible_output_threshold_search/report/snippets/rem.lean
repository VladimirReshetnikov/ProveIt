lemma rem (i j : Fin n) : Arithmetic₁ (fun v => v.get i % v.get j) := by
  have htest : @Arithmetic₁ (n + 1) (fun v =>
      (isEqNat (v.get j.succ) 0).or
        (isLtNat (v.get i.succ) ((v.head + 1) * v.get j.succ))) :=
    (or 0 1).comp₂ _ ((equal 0 1).comp₂ _ (proj j.succ) zero)
      ((lt 0 1).comp₂ _ (proj i.succ)
        ((mul 0 1).comp₂ _ ((succ 0).comp₁ _ head) (proj j.succ)))
  have hout : @Arithmetic₁ (n + 1) (fun v => v.tail.get i - v.head * v.tail.get j) :=
    (sub 0 1).comp₂ _ (proj i).tail ((mul 0 1).comp₂ _ head (proj j).tail)
  exact (ArithPart₁.map (fun v k => v.get i - k * v.get j) hout
    (ArithPart₁.rfindPos htest)).of_eq <| by
    intro v
    simp only [head_cons, get_cons_succ, or_pos_iff, isEqNat_pos_iff, isLtNat_pos_iff,
      Bool.decide_or, PFun.coe_val, eq_some_iff, mem_map_iff, mem_rfind, mem_some_iff]
    by_cases hz : v.get j = 0
    · exact ⟨0, by simp [hz], by simp [hz]⟩
    · refine ⟨v.get i / v.get j, ⟨?_, ?_⟩, Nat.mod_eq_sub_div_mul.symm⟩
      · simpa [hz] using
          (Nat.div_lt_iff_lt_mul (Nat.pos_of_ne_zero hz)).1 (Nat.lt_succ_self (v.get i / v.get j))
      · intro k hk
        simpa [hz] using le_trans (Nat.mul_le_mul_right (v.get j) (Nat.succ_le_of_lt hk))
          (Nat.div_mul_le_self (v.get i) (v.get j))
