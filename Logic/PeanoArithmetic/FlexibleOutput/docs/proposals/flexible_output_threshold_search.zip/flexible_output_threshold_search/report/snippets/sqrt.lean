protected lemma sqrt {n} (i : Fin n) : Arithmetic₁ (fun v => sqrt (v.get i)) := by
  have h : Arithmetic₁ (fun v : List.Vector ℕ (n + 1) =>
      isLtNat (v.get i.succ) ((v.get 0 + 1) * (v.get 0 + 1))) :=
    (lt 0 1).comp₂ _ (proj i.succ) ((mul 0 1).comp₂ _ (succ 0) (succ 0))
  exact (ArithPart₁.rfindPos h).of_eq <| by
    intro v
    simp [Part.eq_some_iff, ← Nat.sqrt_lt, Nat.lt_succ_iff]
