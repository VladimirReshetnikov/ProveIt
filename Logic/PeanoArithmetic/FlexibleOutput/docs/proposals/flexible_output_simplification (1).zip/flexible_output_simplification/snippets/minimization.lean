  case rfind k c ih =>
    simp [codeAux, Semiformula.eval_rew, Function.comp_def, Matrix.empty_eq,
      Matrix.comp_vecCons']
    intro hz hmz hz' hmz'
    exact le_antisymm
      (not_lt.mp fun h => let ⟨w, hw, hwc⟩ := hmz z' h; hw (ih hwc hz'))
      (not_lt.mp fun h => let ⟨w, hw, hwc⟩ := hmz' z h; hw (ih hwc hz))
