  simpa [substNumerals, Sentence.quote_def, Semiformula.quote_def,
    Matrix.comp_vecCons', Matrix.constant_eq_singleton] using
    congrArg (neg ℒₒᵣ) (substNumerals_app_quote (V := ℕ) universalGraph ![y, c, x])
