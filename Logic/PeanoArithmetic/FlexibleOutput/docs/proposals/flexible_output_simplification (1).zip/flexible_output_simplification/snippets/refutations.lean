theorem refutationsRE :
    REPred fun p : (Code × ℕ) × ℕ => 𝗣𝗔 ⊢ ∼haltSentence p.1.1 p.1.2 p.2 := by
  have h : 𝚺₁-Predicate fun p : ℕ =>
      Bootstrapping.Provable 𝗣𝗔 (neg ℒₒᵣ <| subst ℒₒᵣ
        ?[numeral (π₂ p), numeral (π₁ (π₁ p)), numeral (π₂ (π₁ p))]
        (⌜universalGraph⌝ : ℕ)) := by definability
  refine ((re_iff_sigma1.mpr h).comp
    (Computable.encode (α := (Code × ℕ) × ℕ))).of_eq ?_
  rintro ⟨⟨c, x⟩, y⟩
  simp only [Encodable.encode_prod_val, Encodable.encode_nat, ← nat_pair_eq,
    pi₁_pair, pi₂_pair]
  rw [neg_subst_quote]
  exact provable_iff_provable
