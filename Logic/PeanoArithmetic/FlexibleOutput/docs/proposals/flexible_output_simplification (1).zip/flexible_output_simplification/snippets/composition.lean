  case comp m n c d ihc ihd =>
    simp [codeAux, Semiformula.eval_rew, Function.comp_def, Matrix.empty_eq,
      Matrix.comp_vecCons']
    intro w₁ hc₁ hd₁ w₂ hc₂ hd₂
    obtain rfl : w₁ = w₂ := funext fun i => ihd i (hd₁ i) (hd₂ i)
    exact ihc hc₁ hc₂
