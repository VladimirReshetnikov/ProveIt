#!/usr/bin/env python3
"""Measure local Lean source before and after the FlexibleOutput refactor.

Usage:
    python3 measure.py --before BASELINE_LEAN_DIR --after CANDIDATE_LEAN_DIR

Each directory contains PAFlexibleOutput.lean and the PAFlexibleOutput/
subdirectory. JSON is written to standard output. Only local .lean files
are counted; Foundation and mathlib are not included.

Code lines are nonblank lines after nested block comments and line comments
are replaced by whitespace. Quoted strings are retained, including their
contents. These are source metrics, not proof-term or Lean-token metrics.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re


METRICS = ("physical_lines", "code_lines", "code_nonspace_chars")
ROOTS = {
    "main_closure": "PAFlexibleOutput/Main.lean",
    "facade_closure": "PAFlexibleOutput.lean",
}


def strip_comments(source: str) -> str:
    """Preserve line breaks and strings while removing nested Lean comments."""
    output: list[str] = []
    index = 0
    depth = 0
    in_string = False
    while index < len(source):
        if depth:
            if source.startswith("/-", index):
                output.extend("  ")
                depth += 1
                index += 2
            elif source.startswith("-/", index):
                output.extend("  ")
                depth -= 1
                index += 2
            else:
                output.append("\n" if source[index] == "\n" else " ")
                index += 1
        elif in_string:
            char = source[index]
            output.append(char)
            index += 1
            if char == "\\" and index < len(source):
                output.append(source[index])
                index += 1
            elif char == '"':
                in_string = False
        elif source.startswith("/-", index):
            output.extend("  ")
            depth = 1
            index += 2
        elif source.startswith("--", index):
            end = source.find("\n", index)
            if end < 0:
                end = len(source)
            output.extend(" " * (end - index))
            index = end
        else:
            char = source[index]
            output.append(char)
            index += 1
            if char == '"':
                in_string = True
    if depth or in_string:
        raise ValueError("Unclosed block comment or quoted string")
    return "".join(output)


def read_tree(directory: Path) -> dict[str, dict]:
    result = {}
    for path in sorted(directory.rglob("*.lean")):
        data = path.read_bytes()
        source = data.decode("utf-8")
        code = strip_comments(source)
        name = path.relative_to(directory).as_posix()
        result[name] = {
            "source": source,
            "code": code,
            "metrics": {
                "physical_lines": len(source.splitlines()),
                "code_lines": sum(bool(line.strip()) for line in code.splitlines()),
                "code_nonspace_chars": sum(not char.isspace() for char in code),
                "sha256": hashlib.sha256(data).hexdigest(),
            },
        }
    for root in ROOTS.values():
        if root not in result:
            raise ValueError(f"{directory} does not contain required file {root}")
    return result


def local_imports(code: str, tree: dict[str, dict]) -> set[str]:
    imports = set()
    for line in code.splitlines():
        match = re.fullmatch(r"\s*(?:(?:public|private)\s+)?import\s+(.+?)\s*", line)
        if match:
            for module in match.group(1).split():
                filename = module.replace(".", "/") + ".lean"
                if filename in tree:
                    imports.add(filename)
    return imports


def closure(root: str, tree: dict[str, dict]) -> list[str]:
    visited = set()
    pending = [root]
    while pending:
        filename = pending.pop()
        if filename in visited:
            continue
        visited.add(filename)
        pending.extend(local_imports(tree[filename]["code"], tree) - visited)
    return sorted(visited)


def total(filenames: list[str], tree: dict[str, dict]) -> dict[str, int]:
    return {
        metric: sum(tree[name]["metrics"][metric] for name in filenames if name in tree)
        for metric in METRICS
    }


def compare(before: dict[str, dict], after: dict[str, dict]) -> dict:
    names = sorted(set(before) | set(after))
    files = {
        name: {
            "before": before[name]["metrics"] if name in before else None,
            "after": after[name]["metrics"] if name in after else None,
        }
        for name in names
    }
    changed = [
        name for name in names
        if name not in before or name not in after
        or before[name]["metrics"]["sha256"] != after[name]["metrics"]["sha256"]
    ]
    result = {
        "method": {
            "code_lines": "Nonblank lines after removing nested block and line comments",
            "code_nonspace_chars": "Nonwhitespace Unicode characters after removing comments",
            "physical_lines": "Number of lines from Python str.splitlines()",
            "scope": "Local .lean source only; imports outside the supplied directories excluded",
            "includes": "Imports, declarations, statements, proof bodies, commands and retained strings",
        },
        "files": files,
        "changed_files": changed,
        "changed_total": {
            "before": total(changed, before),
            "after": total(changed, after),
        },
    }
    for label, root in ROOTS.items():
        before_files = closure(root, before)
        after_files = closure(root, after)
        result[label] = {
            "before_files": before_files,
            "after_files": after_files,
            "before": total(before_files, before),
            "after": total(after_files, after),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", required=True, type=Path)
    parser.add_argument("--after", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = compare(read_tree(args.before), read_tree(args.after))
    except (OSError, UnicodeError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
