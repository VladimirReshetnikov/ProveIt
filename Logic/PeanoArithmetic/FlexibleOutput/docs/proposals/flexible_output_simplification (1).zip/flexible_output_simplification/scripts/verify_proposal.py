#!/usr/bin/env python3
"""Verify the FlexibleOutput proposal in a pinned ProveIt checkout.

Prepare once (with no other Lean/Lake process running): initialize the Foundation
submodule, install the toolchain named in lean-toolchain, restore the pinned Lake
packages, and run `lake exe cache get`. Do not run a broad `lake build`.
Apply the supplied patch, then run:

    python3 verify_proposal.py --repo /path/to/ProveIt --bootstrap-dependencies

The bootstrap option builds the Foundation import closure one module at a time.
On an already prepared checkout, omit it. All PAFlexibleOutput modules needed by
Main are rebuilt in topological order. External package dependencies must already
have their cached oleans. LAKE_JOBS=1 is retained for compatibility; it is NOT a
parallelism control. The protection is the dependency order and blocking calls.
Do not run another Lean/Lake command concurrently, including in another checkout.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile

BASE = "7142f7f52bbd36ede33f2be1a66dfdccc238e255"
FOUNDATION = "32e1a0956a8622fad067328ca1959729a7634428"
MATHLIB = "81a5d257c8e410db227a6665ed08f64fea08e997"
TOOLCHAIN = "leanprover/lean4:v4.32.0"
ENDPOINTS = ("flexibleOutput", "flexibleOutput_satisfiable", "exists_partrec_flexibleOutput")
ALLOWED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
AUDIT = r'''import PAFlexibleOutput.Main
open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic
open PAFlexibleOutput

-- Check the exact current every-input endpoint.
example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧ ∀ (x : ℕ) (o : Option ℕ),
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e x o :=
  flexibleOutput

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧ ∀ o : Option ℕ,
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e 0 o :=
  exists_partrec_flexibleOutput

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ x n : ℕ, Satisfiable (insert (haltSentence e x n) 𝗣𝗔) :=
  flexibleOutput_satisfiable

-- Check the exact graph semantics, including internal uniqueness and absence.
example (M : Type*) [ORingStructure M] (c : Code) (x n : ℕ) :
    ValueIn M c x (some n) =
      (∀ y : M, OutputIn M c x y ↔ y = ORingStructure.numeral n) := rfl
example (M : Type*) [ORingStructure M] (c : Code) (x : ℕ) :
    ValueIn M c x none = (∀ y : M, ¬ OutputIn M c x y) := rfl
'''

AUDIT += "\n" + "\n".join("#print axioms PAFlexibleOutput." + n for n in ENDPOINTS) + "\n"


def fail(message: str) -> None:
    raise SystemExit(message)


def capture(args: list[str], cwd: Path) -> str:
    p = subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT)
    if p.returncode:
        fail(f"Command failed: {shlex.join(args)}\n{p.stdout}")
    return p.stdout.strip()


def require_idle() -> None:
    if os.name == "nt":
        output = subprocess.check_output(["tasklist", "/FO", "CSV", "/NH"], text=True)
        names = [row[0] for row in csv.reader(io.StringIO(output)) if row]
    else:
        output = subprocess.check_output(["ps", "-A", "-o", "stat=", "-o", "comm="], text=True)
        rows = [line.split(maxsplit=1) for line in output.splitlines()]
        names = [row[1] for row in rows if len(row) == 2 and not row[0].startswith("Z")]
    active = [n.strip() for n in names
              if Path(n.strip()).name.lower() in {"lean", "lake", "lean.exe", "lake.exe"}]
    if active:
        fail("Another Lean/Lake process is running. Wait for it and its children to finish.")


def imports(source: Path) -> list[str]:
    # Remove nested Lean comments and strings; preserve line boundaries.
    s, out, i, depth, quoted = source.read_text(encoding="utf-8"), [], 0, 0, False
    while i < len(s):
        pair = s[i:i + 2]
        if depth:
            if pair == "/-": depth += 1; out.extend("  "); i += 2
            elif pair == "-/": depth -= 1; out.extend("  "); i += 2
            else: out.append("\n" if s[i] == "\n" else " "); i += 1
        elif quoted:
            if s[i] == "\\": out.extend("  "); i += 2
            elif s[i] == '"': quoted = False; out.append(" "); i += 1
            else: out.append("\n" if s[i] == "\n" else " "); i += 1
        elif pair == "/-": depth = 1; out.extend("  "); i += 2
        elif pair == "--":
            j = s.find("\n", i)
            if j < 0: break
            out.append("\n"); i = j + 1
        elif s[i] == '"': quoted = True; out.append(" "); i += 1
        else: out.append(s[i]); i += 1
    result = []
    for line in "".join(out).splitlines():
        m = re.match(r"^\s*(?:(?:public|meta)\s+)*import\s+(.*)$", line)
        if m:
            result.extend(n for n in m[1].split()
                          if n != "all" and re.fullmatch(r"[A-Za-z0-9_.]+", n))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--bootstrap-dependencies", action="store_true")
    parser.add_argument("--output", type=Path, default=Path("verification-output"))
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    if os.environ.get("LEAN_NUM_THREADS") == "0":
        fail("Unset LEAN_NUM_THREADS=0 before running; zero does not mean automatic threading.")
    if capture(["git", "rev-parse", "HEAD"], repo) != BASE:
        fail("The repository HEAD differs from the proposal's pinned baseline: " + BASE)
    if (repo / "lean-toolchain").read_text().strip() != TOOLCHAIN:
        fail("Unexpected lean-toolchain; expected " + TOOLCHAIN)
    foundation = repo / "lib/FormalizedFormalLogic-Foundation"
    if capture(["git", "rev-parse", "HEAD"], foundation) != FOUNDATION:
        fail("Initialize Foundation at the pinned revision: " + FOUNDATION)
    manifest = json.loads((repo / "lake-manifest.json").read_text())
    if next((p["rev"] for p in manifest["packages"] if p["name"] == "mathlib"), None) != MATHLIB:
        fail("Unexpected mathlib revision in lake-manifest.json.")
    mathlib = repo / ".lake/packages/mathlib"
    if not mathlib.is_dir():
        fail("Restore the pinned Lake packages and mathlib cache before verification.")
    if capture(["git", "rev-parse", "HEAD"], mathlib) != MATHLIB:
        fail("The installed mathlib package is not at its pinned revision.")

    roots = {"Foundation": foundation,
             "PAFlexibleOutput": repo / "Logic/PeanoArithmetic/FlexibleOutput/Lean"}
    ordered, visiting, done, external = [], set(), set(), set()

    def visit(module: str) -> None:
        root = roots.get(module.split(".")[0])
        if root is None:
            external.add(module)
            return
        if module in done: return
        if module in visiting: fail("Cyclic import involving " + module)
        visiting.add(module)
        source = root / (module.replace(".", "/") + ".lean")
        if not source.is_file(): fail("Missing source: " + str(source))
        for dep in imports(source): visit(dep)
        visiting.remove(module)
        done.add(module)
        ordered.append(module)

    visit("PAFlexibleOutput.Main")
    build_root = repo / ".lake/build/lib/lean"
    package_builds = list((repo / ".lake/packages").glob("*/.lake/build/lib/lean"))
    missing = [m for m in sorted(external)
               if m.split(".")[0] not in {"Init", "Lean", "Std"}
               and not any((p / (m.replace(".", "/") + ".olean")).is_file()
                           for p in package_builds)]
    if missing:
        fail("Missing external oleans. Prepare the pinned packages with `lake exe cache get` first.\n"
             + "\n".join(missing))
    if not args.bootstrap_dependencies:
        missing = [m for m in ordered if m.startswith("Foundation.")
                   and not (build_root / (m.replace(".", "/") + ".olean")).is_file()]
        if missing:
            fail("Foundation dependencies are not compiled; rerun with --bootstrap-dependencies.\n"
                 + "\n".join(missing))
        ordered = [m for m in ordered if m.startswith("PAFlexibleOutput")]

    output.mkdir(parents=True, exist_ok=True)
    (output / "build-order.txt").write_text("\n".join(ordered) + "\n", encoding="utf-8")
    env = dict(os.environ, LAKE_JOBS="1")
    with (output / "verification.log").open("w", encoding="utf-8") as log:
        def run(command: list[str]) -> str:
            require_idle()
            line = "$ " + shlex.join(command)
            print(line, flush=True); log.write(line + "\n"); log.flush()
            proc = subprocess.run(command, cwd=repo, env=env, text=True,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            print(proc.stdout, end="", flush=True); log.write(proc.stdout); log.flush()
            if proc.returncode: fail("Verification failed; see " + str(output / "verification.log"))
            return proc.stdout

        version = run(["lake", "env", "lean", "--version"])
        if not re.search(r"\bversion 4\.32\.0\b", version): fail("Unexpected Lean executable version.")
        # Blocking calls: never a target batch, process pool, or background loop.
        for module in ordered:
            run(["lake", "build", "+" + module])
        with tempfile.TemporaryDirectory(prefix="flexible-output-audit-") as tmp:
            audit = Path(tmp) / "Audit.lean"
            audit.write_text(AUDIT, encoding="utf-8")
            report = run(["lake", "env", "lean", str(audit)])
        (output / "axioms.txt").write_text(report, encoding="utf-8")
        found = dict(re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]", report))
        found.update((n, "") for n in re.findall(r"'([^']+)' does not depend on any axioms", report))
        for name in ENDPOINTS:
            full = "PAFlexibleOutput." + name
            if full not in found: fail("No axiom report found for " + full)
            axioms = {a.strip() for a in found[full].split(",") if a.strip()}
            if not axioms <= ALLOWED_AXIOMS:
                fail("Unexpected axioms for " + full + ": " + ", ".join(sorted(axioms)))
        print("All endpoint checks passed; axiom reports are in", output)


if __name__ == "__main__":
    main()
