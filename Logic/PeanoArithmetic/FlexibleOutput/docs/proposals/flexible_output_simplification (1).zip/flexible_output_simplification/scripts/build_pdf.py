#!/usr/bin/env python3
"""Compile the accompanying TeX report twice with pdfLaTeX.

Requires a TeX Live installation providing the packages used by the report.
If format dumps or font maps are absent, generate local temporary ones from
the installed TeX resources. No system configuration is changed.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
TEX = ROOT / "flexible_output_simplification.tex"


def locate(name):
    result = subprocess.run(["kpsewhich", name], text=True,
                            stdout=subprocess.PIPE, check=False)
    return result.stdout.strip()


def main():
    for tool in ("pdflatex", "pdftex", "kpsewhich"):
        if not shutil.which(tool):
            raise SystemExit("Required TeX executable is missing: " + tool)
    with tempfile.TemporaryDirectory(prefix="flexible-output-tex-") as temp:
        temp = Path(temp)
        env = os.environ.copy()
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error"]
        if not locate("pdflatex.fmt"):
            with (temp / "format.log").open("w") as log:
                subprocess.run(["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                                "-progname=pdflatex", "-interaction=nonstopmode",
                                "pdflatex.ini"], cwd=temp, check=True,
                               stdout=log, stderr=subprocess.STDOUT)
            command.append("-fmt=" + str(temp / "pdflatex.fmt"))
        if not locate("pdftex.map"):
            maps = [locate(n) for n in
                    ("lm.map", "cm.map", "cmextra.map", "symbols.map", "latxfont.map")]
            (temp / "pdftex.map").write_text("\n".join(
                Path(p).read_text() for p in maps if p))
            env["TEXFONTMAPS"] = str(temp) + os.pathsep + env.get("TEXFONTMAPS", "")
        command.append(TEX.name)
        for pass_number in (1, 2):
            log_path = ROOT / "validation" / ("pdf-pass-" + str(pass_number) + ".log")
            log_path.parent.mkdir(exist_ok=True)
            with log_path.open("w") as log:
                subprocess.run(command, cwd=ROOT, env=env, check=True,
                               stdout=log, stderr=subprocess.STDOUT)
        print(ROOT / TEX.with_suffix(".pdf").name)


if __name__ == "__main__":
    main()
