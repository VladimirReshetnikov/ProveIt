FLEXIBLE OUTPUT IN PA: VERIFIED PROOF SIMPLIFICATION
==================================================

Recommendation
--------------
Encode the refutation query ((c,x),y) once, prove a unary Sigma_1
predicate, and apply Foundation's re_iff_sigma1 directly. This removes
the custom ternary-to-vector RE conversion. Also simplify quotation
normalization, the functionality induction, and selector domain evidence.

This proposal is based on ProveIt commit:
  7142f7f52bbd36ede33f2be1a66dfdccc238e255

That commit landed during review and already includes the direct
standard-model soundness argument and the stronger every-input theorem.
Those upstream changes are NOT counted as new improvements here.

Verified result
---------------
Three dependency modules change. Main.lean, Halting.lean and the facade
are byte-identical to the baseline. All three current theorem endpoints
and every retained declaration signature are preserved.

Nonblank code lines, excluding comments:
  Refutations.lean       45 -> 28
  Functionality.lean     43 -> 39
  Search.lean            32 -> 28
  Edited modules       120 -> 95   (20.8% reduction)
  Main's five modules  198 -> 173  (12.6% reduction)

Nonwhitespace code characters in the edited modules:
  5,083 -> 3,871 (23.8% reduction)

These are source metrics, not claims about kernel term size or speed.
Both versions were compiled using Lean 4.32.0 with the exact dependency
revisions recorded below. All three endpoint axiom reports are exactly:
  [propext, Classical.choice, Quot.sound]
The public facade also builds. Existing dependency warnings are present
in the complete logs.

Limited auxiliary API change
----------------------------
Two previously public helper names are removed:
  PAFlexibleOutput.rePred_of_sigma1
  PAFlexibleOutput.refutation_sigma1
The staged project no longer uses them. External clients importing these
names must adapt or retain compatibility declarations. The reported
source reduction assumes their removal.

Contents
--------
  flexible_output_simplification.pdf  Readable report
  flexible_output_simplification.tex  Editable LaTeX report source
  changes.patch                      Three-file patch against the pinned commit
  baseline/Lean/                     Exact original six Lean source files
  proposed/Lean/                     Complete proposed six Lean source files
  baseline/lake-manifest.json         Pinned dependency manifest
  baseline/lean-toolchain             Pinned toolchain
  snippets/                          Exact code excerpts included by the report
  scripts/verify_proposal.py          Serial builds and exact endpoint/axiom audit
  scripts/measure.py                  Reproducible source measurements
  scripts/build_pdf.py                Rebuild the report using pdfLaTeX
  validation/baseline/                Baseline build order, full log, axiom report
  validation/proposed/                Proposed build order, full log, axiom report,
                                     and final facade build log
  validation/Audit.lean               Exact Lean endpoint and axiom checks
  validation/metrics.json            Per-file counts, totals and SHA-256 hashes
  validation/source-audit.json        Patch checks and source preservation checks
  sources.json                       Pinned revisions and source hashes
  LICENSE                            ProveIt source license

Dependency versions
-------------------
  Lean        leanprover/lean4:v4.32.0
  Foundation  32e1a0956a8622fad067328ca1959729a7634428
  mathlib     81a5d257c8e410db227a6665ed08f64fea08e997

Reproduce from a separate checkout
---------------------------------
Use a normal Git checkout with Python 3 and the pinned Lean toolchain
available. Replace /path/to/archive with this unpacked directory.

  git clone https://github.com/VladimirReshetnikov/ProveIt.git ProveIt-review
  cd ProveIt-review
  git checkout 7142f7f52bbd36ede33f2be1a66dfdccc238e255
  git submodule update --init lib/FormalizedFormalLogic-Foundation
  elan toolchain install leanprover/lean4:v4.32.0
  lake exe cache get

The last command requires network access and restores Mathlib package
artifacts. Keep the committed manifest; do not update dependency versions.
The archive deliberately excludes dependency source trees, the toolchain,
and compiled .olean artifacts.

Run builds sequentially with no other Lean or Lake process running.
If LEAN_NUM_THREADS is set to 0, unset it before building. The verifier
rejects zero. LAKE_JOBS=1 is NOT a concurrency limit; serial target order
and already-built dependencies are what keep the workflow sequential.

To check the baseline first (optional):

  python3 /path/to/archive/scripts/verify_proposal.py \
    --repo . --bootstrap-dependencies --output /path/to/baseline-check

Apply the patch and verify the proposal:

  git apply --check /path/to/archive/changes.patch
  git apply /path/to/archive/changes.patch
  python3 /path/to/archive/scripts/verify_proposal.py \
    --repo . --bootstrap-dependencies --output /path/to/proposal-check
  lake build +PAFlexibleOutput

If the pinned local Foundation modules are already compiled, omit
--bootstrap-dependencies. The script checks the repository HEAD,
Foundation revision, manifest and installed Mathlib revision, toolchain
file, and actual Lean version. It builds the local import closure in
topological order using one Lake target per blocking invocation. It then
compiles explicit endpoint-type and ValueIn equation checks and rejects
endpoint axioms outside {propext, Classical.choice, Quot.sound}.

The exact type-checking Lean source is validation/Audit.lean; the same
source is the AUDIT string in the verifier.
The three endpoint declarations audited are:
  PAFlexibleOutput.flexibleOutput
  PAFlexibleOutput.flexibleOutput_satisfiable
  PAFlexibleOutput.exists_partrec_flexibleOutput

Measure and rebuild the report
-----------------------------
From this unpacked directory:

  python3 scripts/measure.py --before baseline/Lean --after proposed/Lean
  python3 scripts/build_pdf.py

PDF generation requires pdfLaTeX and the packages used in the source
(including Latin Modern, microtype, geometry, amsmath, booktabs, listings,
xurl, hyperref and fancyhdr). The helper prepares a temporary format and
font map only when the local TeX installation lacks those generated files.
It does not modify system TeX configuration.

The report uses snippets/*.lean as listing inputs; keep that directory
next to the .tex source. Code in proposed/Lean is authoritative.

Semantics
---------
The fixed universalGraph, haltSentence, OutputIn and ValueIn are unchanged.
The stronger endpoint still has quantifier order:
  exists e, e diverges on every standard input, and
    forall x o, exists a PA model M, ValueIn M e x o.
The same program works for all x and o; the model may depend on x and o.
For a requested natural-number output, uniqueness holds for every element
of the chosen model, including nonstandard elements.
