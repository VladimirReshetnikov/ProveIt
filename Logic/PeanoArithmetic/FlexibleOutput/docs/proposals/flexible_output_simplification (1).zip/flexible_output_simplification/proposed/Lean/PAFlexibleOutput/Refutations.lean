import PAFlexibleOutput.Halting
import Foundation.FirstOrder.Incompleteness.First
import Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1

/-!
# The refuted outputs form a recursively enumerable relation

`refutationsRE`: the relation "`𝗣𝗔` proves that program `c` does not halt on input `x` with
output `y`" is recursively enumerable in `((c, x), y)`.

The argument is encoded once by `Encodable.encode`. Foundation's projections recover
its program code, input and output because Foundation's pairing agrees with `Nat.pair`
(`nat_pair_eq`). The resulting unary refutability predicate is `𝚺₁`-definable, so
`re_iff_sigma1` applies directly. No separate ternary-to-vector conversion is needed.

`neg_subst_quote` identifies the code as the negated halting sentence, and
`provable_iff_provable` recovers actual PA provability from its arithmetization.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic
open Bootstrapping Bootstrapping.Arithmetic

/-- The code of the negated halting sentence, computed by formal substitution of numerals. -/
lemma neg_subst_quote (c x y : ℕ) :
    neg ℒₒᵣ (subst ℒₒᵣ ?[numeral y, numeral c, numeral x] (⌜universalGraph⌝ : ℕ))
      = ⌜(∼(universalGraph/[↑y, ↑c, ↑x]) : ArithmeticSentence)⌝ := by
  simpa [substNumerals, Sentence.quote_def, Semiformula.quote_def,
    Matrix.comp_vecCons', Matrix.constant_eq_singleton] using
    congrArg (neg ℒₒᵣ) (substNumerals_app_quote (V := ℕ) universalGraph ![y, c, x])

/-- The refuted outputs form a recursively enumerable relation of program, input and output. -/
theorem refutationsRE :
    REPred fun p : (Code × ℕ) × ℕ => 𝗣𝗔 ⊢ ∼haltSentence p.1.1 p.1.2 p.2 := by
  have h : 𝚺₁-Predicate fun p : ℕ =>
      Bootstrapping.Provable 𝗣𝗔 (neg ℒₒᵣ <| subst ℒₒᵣ
        ?[numeral (π₂ p), numeral (π₁ (π₁ p)), numeral (π₂ (π₁ p))]
        (⌜universalGraph⌝ : ℕ)) := by definability
  refine ((re_iff_sigma1.mpr h).comp
    (Computable.encode (α := (Code × ℕ) × ℕ))).of_eq ?_
  rintro ⟨⟨c, x⟩, y⟩
  simp only [Encodable.encode_prod_val, Encodable.encode_nat, ← nat_pair_eq,
    pi₁_pair, pi₂_pair]
  rw [neg_subst_quote]
  exact provable_iff_provable

#print axioms refutationsRE

end PAFlexibleOutput
