import PAFlexibleOutput.Main
open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic
open PAFlexibleOutput

-- Check the exact current every-input endpoint.
example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧ ∀ (x : ℕ) (o : Option ℕ),
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e x o :=
  flexibleOutput

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧ ∀ o : Option ℕ,
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e 0 o :=
  exists_partrec_flexibleOutput

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ x n : ℕ, Satisfiable (insert (haltSentence e x n) 𝗣𝗔) :=
  flexibleOutput_satisfiable

-- Check the exact graph semantics, including internal uniqueness and absence.
example (M : Type*) [ORingStructure M] (c : Code) (x n : ℕ) :
    ValueIn M c x (some n) =
      (∀ y : M, OutputIn M c x y ↔ y = ORingStructure.numeral n) := rfl
example (M : Type*) [ORingStructure M] (c : Code) (x : ℕ) :
    ValueIn M c x none = (∀ y : M, ¬ OutputIn M c x y) := rfl

#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
