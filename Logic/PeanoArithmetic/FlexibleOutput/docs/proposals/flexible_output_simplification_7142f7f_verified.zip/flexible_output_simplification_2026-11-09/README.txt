FURTHER SIMPLIFYING FLEXIBLEOUTPUT IN LEAN
========================================

Repository: https://github.com/VladimirReshetnikov/ProveIt
Primary base commit: 7142f7f52bbd36ede33f2be1a66dfdccc238e255
Also compatible with: 6ff1ad8cba8584cba37cc96185fd3ef19fc56282
Date: 9 November 2026 (America/Los_Angeles)

START HERE
----------
Read report/flexible_output_simplification.pdf. Its complete LaTeX source,
code excerpts, and generated measurement tables are alongside it.
See validation/STATUS.txt for actual compiler checks and their scope.

The repository advanced from 410c820c4faa to 7142f7f52bbd during this review.
The newer version already contains the major direct-PA refactor and the
stronger theorem for every input. The supplied patches target that NEW
version and propose only additional changes. The report distinguishes
upstream changes from this package's contribution.

CHANGES
-------
01-search.patch
  Simplify the semidecision procedure's domain proof, use a membership
  proof's domain projection directly, and use Part.get_mem for a computation
  already known to be defined. The dovetailing algorithm is unchanged.

02-main.patch
  Replace the final extraction of a selector output with one domain-level
  simplification using the fixed-point equality, Part.dom_iff_mem, and hdiv.
  The self-reference argument, theorem type, and corollaries are preserved.

03-refutations.patch
  Obtain neg_subst_quote by applying formal negation to the existing quoted
  numeral-substitution identity and simplifying vector/cast representations.
  Removes a bespoke Fin 3 case analysis without changing the formula.

04-functionality.patch
  Normalize formula evaluation once at the start of the composition case.
  Keeps the same induction hypotheses, all other cases, and PA-minus model
  assumptions. Nonstandard-model uniqueness is retained.

all-simplifications.patch
  The four independent changes combined. Complete replacement Lean files
  are in replacement/. Do not apply individual patches after this one.

Every current public declaration and theorem type is preserved. Halting.lean
and all semantic definitions are unchanged. Both corollaries following
flexibleOutput are byte-identical to the current baseline.

APPLYING AND CHECKING
--------------------
Use a ProveIt checkout at the primary base commit, with the pinned Foundation
submodule and Mathlib dependencies available. Set FLEX_BUNDLE to this
extracted directory's absolute path. From the ProveIt checkout root:

  git apply --check "$FLEX_BUNDLE/patches/all-simplifications.patch"
  git apply "$FLEX_BUNDLE/patches/all-simplifications.patch"
  bash "$FLEX_BUNDLE/scripts/check_lean.sh" "$PWD"

These commands modify only local working files. The package does not commit,
push, or open a pull request. If only one change is wanted, use its individual
patch instead of all-simplifications.patch.

check_lean.sh checks the pinned commit, builds Main and the facade in separate
Lake calls, and elaborates validation/EndpointAudit.lean. The audit reasserts
all three exact current endpoint types and prints axiom dependencies. The
script uses one Lean worker by default; FLEX_LEAN_THREADS can override this
if required by the host.

MEASUREMENTS AND SOURCE CHECKS
-----------------------------
From this extracted directory:

  python3 scripts/audit_sources.py

This checks original Git blob identifiers, unchanged theorem headers and
imports, the unchanged main corollaries, and absence of admissions, new
axioms, or native_decide in the replacements. It also regenerates
validation/metrics.json and validation/source_audit.json.

Active lines exclude blank lines and nested Lean comments. Totals cover the
same five local modules imported by PAFlexibleOutput.Main before and after.
They include unchanged Halting.lean and exclude the facade, external
dependencies, and archived historical files. No proof-term-size or build-time
claim follows from these source-size measurements.

To regenerate all patches, metrics, and report excerpts:

  python3 scripts/refresh_artifacts.py

REBUILDING THE PDF
-----------------
With a standard TeX Live installation including pdfLaTeX:

  bash scripts/build_report.sh

This requires only the supplied report inputs and ordinary LaTeX packages.

CONTENTS
--------
report/        PDF, LaTeX source, measured figures, and exact code excerpts.
replacement/   Four complete replacement Lean files.
patches/       Four independent patches and their combined patch.
baseline/      Relevant exact source snapshot, README, root configuration,
               dependency pins, and license. This is not a complete checkout.
scripts/       Source audit, patch regeneration, Lean checks, PDF build.
validation/    Compiler records, endpoint audit, measurements, source checks.
notes/         Repository update and mathematical review notes.
provenance.json Exact revisions and original Git blob identifiers.
SHA256SUMS     Checksums of every other file in the archive.

THEOREM SCOPE
-------------
The same program code works for every input and every requested optional
output, but the model may depend on both. The result does not say that one
model realizes an arbitrary simultaneous assignment of outputs at all inputs.

The selected code and arithmetic graph are essential. The standard partial
function is nowhere defined, but another program computing the same standard
function need not have the same behavior in nonstandard PA models. ValueIn
continues to express uniqueness over every model element, not merely over
standard numerals. Sequential search over an r.e. predicate would not be a
valid replacement for the existing dovetailing.

LICENSE
-------
Adapted ProveIt sources retain the repository's MIT No Attribution terms;
the original LICENSE is included. The report and new accompanying scripts
are provided under the same terms.

Final observed head: 6ff1ad8cba8584cba37cc96185fd3ef19fc56282
The comparison from 7142f7f52bbd to this head contained only article moves
and proposal ZIP additions. Lean files and build pins are unchanged, so
the delivered patches remain applicable. The comparison record is included
in validation/later_head_comparison.json.
