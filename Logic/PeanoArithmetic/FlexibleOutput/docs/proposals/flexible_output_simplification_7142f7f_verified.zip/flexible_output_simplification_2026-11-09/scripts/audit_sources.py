#!/usr/bin/env python3
"""Reproduce source-size figures and verify preservation of public statements.

These are static source checks, not a substitute for Lean elaboration.
"""
from pathlib import Path
import hashlib
import json
import re

BUNDLE = Path(__file__).resolve().parents[1]
LEAN_REL = Path("Logic/PeanoArithmetic/FlexibleOutput/Lean")
BASE = BUNDLE / "baseline" / LEAN_REL


def strip_comments(text):
    """Remove nested Lean comments, retaining line breaks and string literals."""
    out = []
    i = depth = 0
    quoted = False
    while i < len(text):
        if depth:
            if text.startswith("/-", i):
                depth += 1
                i += 2
            elif text.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                if text[i] == "\n":
                    out.append("\n")
                i += 1
        elif quoted:
            out.append(text[i])
            if text[i] == "\\" and i + 1 < len(text):
                out.append(text[i + 1])
                i += 2
            else:
                if text[i] == '"':
                    quoted = False
                i += 1
        elif text.startswith("/-", i):
            depth = 1
            i += 2
        elif text.startswith("--", i):
            end = text.find("\n", i)
            i = len(text) if end < 0 else end
        else:
            out.append(text[i])
            if text[i] == '"':
                quoted = True
            i += 1
    if depth:
        raise ValueError("Unterminated block comment")
    return "".join(out)


def counts(text):
    return {
        "physical_lines": len(text.splitlines()),
        "active_lines": sum(bool(line.strip()) for line in strip_comments(text).splitlines()),
        "utf8_bytes": len(text.encode("utf-8")),
    }


def header(text, name):
    text = strip_comments(text)
    match = re.search(r"^(?:noncomputable )?(?:theorem|lemma|def) " + re.escape(name) + r"\b", text, re.M)
    if not match:
        raise ValueError(f"Missing declaration: {name}")
    end = text.index(":=", match.start())
    return " ".join(text[match.start():end].split())


def proof_body(text, name, next_marker):
    start = text.index("theorem " + name)
    start = text.index(":= by\n", start) + len(":= by\n")
    end = text.index(next_marker, start)
    return text[start:end].rstrip() + "\n"


def read_module(module, replacements):
    path = replacements.get(module, BASE / (module.replace(".", "/") + ".lean"))
    return path.read_text(encoding="utf-8")


def local_closure(root, replacements):
    visited = set()
    pending = [root]
    while pending:
        module = pending.pop()
        if module in visited:
            continue
        visited.add(module)
        text = read_module(module, replacements)
        for dep in re.findall(r"^import\s+(PAFlexibleOutput(?:\.\w+)*)\s*$", text, re.M):
            pending.append(dep)
    return sorted(visited)


def closure_metrics(replacements):
    modules = local_closure("PAFlexibleOutput.Main", replacements)
    totals = {key: 0 for key in counts("")}
    for module in modules:
        for key, value in counts(read_module(module, replacements)).items():
            totals[key] += value
    return {"modules": modules, "totals": totals}


def main():
    names = {
        "Main": ["flexibleOutput", "flexibleOutput_satisfiable", "exists_partrec_flexibleOutput"],
        "Search": ["exists_selector"],
        "Functionality": ["codeAux_uniq", "code_uniq", "universalGraph_uniq", "valueIn_of_models"],
        "Refutations": ["rePred_of_sigma1", "refutation_sigma1", "neg_subst_quote", "refutationsRE"],
    }
    replacements = {"PAFlexibleOutput." + n: BUNDLE / "replacement" / (n + ".lean") for n in names}
    checks = []
    metrics = {"files": {}, "closures": {"baseline": closure_metrics({}), "replacement": closure_metrics(replacements)}}
    for short, decls in names.items():
        module = "PAFlexibleOutput." + short
        before = read_module(module, {})
        after = read_module(module, replacements)
        metrics["files"][short + ".lean"] = {"before": counts(before), "after": counts(after)}
        for name in decls:
            checks.append({"check": "Unchanged declaration: " + name, "passed": header(before, name) == header(after, name)})
        bad = re.search(r"\b(?:sorry|admit|native_decide)\b|^\s*(?:axiom|unsafe)\b", strip_comments(after), re.M)
        checks.append({"check": short + ": no admissions, added axioms, or native_decide", "passed": bad is None})
        old_imports = re.findall(r"^import .*", before, re.M)
        new_imports = re.findall(r"^import .*", after, re.M)
        checks.append({"check": short + ": imports unchanged", "passed": old_imports == new_imports})
    old_main = read_module("PAFlexibleOutput.Main", {})
    new_main = read_module("PAFlexibleOutput.Main", replacements)
    marker = "/-- The sentence form:"
    checks.append({"check": "Main corollaries byte-identical", "passed": old_main[old_main.index(marker):] == new_main[new_main.index(marker):]})
    metrics["main_proof"] = {
        "before": counts(proof_body(old_main, "flexibleOutput", marker)),
        "after": counts(proof_body(new_main, "flexibleOutput", marker)),
    }
    provenance = json.loads((BUNDLE / "provenance.json").read_text())
    for item in provenance["baseline_files"]:
        raw = (BUNDLE / "baseline" / item["path"]).read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        checks.append({"check": "Git blob: " + item["path"], "passed": actual == item["git_blob_sha1"]})
    result = {"kind": "Static source audit, distinct from Lean compilation", "passed": all(c["passed"] for c in checks), "checks": checks}
    (BUNDLE / "validation/source_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    (BUNDLE / "validation/metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    print(json.dumps({"passed": result["passed"], "checks": len(checks), "metrics": metrics}, indent=2))
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()


