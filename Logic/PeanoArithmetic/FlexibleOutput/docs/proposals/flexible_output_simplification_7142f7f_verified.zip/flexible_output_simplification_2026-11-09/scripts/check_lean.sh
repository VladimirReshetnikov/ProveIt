#!/usr/bin/env bash
# Run from any directory after applying one of the supplied patches.
# Usage: bash scripts/check_lean.sh /absolute/path/to/ProveIt
set -euo pipefail

flex_repo=$(cd "${1:?Pass a ProveIt checkout path}" && pwd)
flex_bundle=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
flex_expected=7142f7f52bbd36ede33f2be1a66dfdccc238e255
flex_compatible=6ff1ad8cba8584cba37cc96185fd3ef19fc56282
flex_actual=$(git -C "$flex_repo" rev-parse HEAD)
if [[ "$flex_actual" != "$flex_expected" && "$flex_actual" != "$flex_compatible" ]]; then
  echo "Expected ProveIt $flex_expected or source-identical $flex_compatible; found $flex_actual" >&2
  exit 2
fi

cd "$flex_repo"
export LAKE_JOBS=1
# One worker avoids Lake's IO.Promise startup failure with zero workers on
# the Linux validation host. Set FLEX_LEAN_THREADS=0 if your host requires it.
export LEAN_NUM_THREADS="${FLEX_LEAN_THREADS:-1}"
flex_logs="$flex_bundle/validation/reproduction"
mkdir -p "$flex_logs"
lake env lean --version | tee "$flex_logs/toolchain.log"
# Each invocation names exactly one target.
lake build +PAFlexibleOutput.Main 2>&1 | tee "$flex_logs/main.log"
lake build +PAFlexibleOutput 2>&1 | tee "$flex_logs/facade.log"
lake env lean "$flex_bundle/validation/EndpointAudit.lean" 2>&1 | tee "$flex_logs/endpoint-audit.log"
