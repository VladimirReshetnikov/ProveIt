#!/usr/bin/env bash
set -euo pipefail
flex_bundle=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$flex_bundle/report"
pdflatex -interaction=nonstopmode -halt-on-error flexible_output_simplification.tex
pdflatex -interaction=nonstopmode -halt-on-error flexible_output_simplification.tex
