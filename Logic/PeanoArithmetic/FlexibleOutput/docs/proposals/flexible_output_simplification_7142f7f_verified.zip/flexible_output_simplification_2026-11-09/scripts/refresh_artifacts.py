#!/usr/bin/env python3
"""Regenerate patches, measurements, and report excerpts from bundled sources."""
from pathlib import Path
import difflib
import json
import re
import runpy
import subprocess
import sys

bundle = Path(__file__).resolve().parents[1]
subprocess.run([sys.executable, str(bundle / "scripts/audit_sources.py")], check=True)
audit = runpy.run_path(str(bundle / "scripts/audit_sources.py"))
metrics = json.loads((bundle / "validation/metrics.json").read_text())
prefix = "Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/"
patches = []
for number, name in enumerate(["Search", "Main", "Refutations", "Functionality"], 1):
    old = (bundle / "baseline" / prefix / (name + ".lean")).read_text()
    new = (bundle / "replacement" / (name + ".lean")).read_text()
    patch = "".join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
        fromfile="a/" + prefix + name + ".lean", tofile="b/" + prefix + name + ".lean"))
    (bundle / "patches" / (f"{number:02d}-" + name.lower() + ".patch")).write_text(patch)
    patches.append(patch)
(bundle / "patches/all-simplifications.patch").write_text("".join(patches))

before = metrics["closures"]["baseline"]["totals"]
after = metrics["closures"]["replacement"]["totals"]
values = {
    "PhysicalBefore": before["physical_lines"], "PhysicalAfter": after["physical_lines"],
    "PhysicalSaved": before["physical_lines"] - after["physical_lines"],
    "ActiveBefore": before["active_lines"], "ActiveAfter": after["active_lines"],
    "ActiveSaved": before["active_lines"] - after["active_lines"],
    "ActiveReduction": f'{100 * (1 - after["active_lines"] / before["active_lines"]):.1f}',
    "MainProofBefore": metrics["main_proof"]["before"]["active_lines"],
    "MainProofAfter": metrics["main_proof"]["after"]["active_lines"],
}
(bundle / "report/metrics.tex").write_text("".join("\\newcommand{\\" + k + "}{" + str(v) + "}\n" for k, v in values.items()))
rows = []
for name in ["Halting", "Functionality", "Refutations", "Search", "Main"]:
    if name == "Halting":
        b = a = audit["counts"]((bundle / "baseline" / prefix / "Halting.lean").read_text())
    else:
        b = metrics["files"][name + ".lean"]["before"]
        a = metrics["files"][name + ".lean"]["after"]
    rows.append(f'\\code{{{name}.lean}} & {b["physical_lines"]} & {a["physical_lines"]} & {b["active_lines"]} & {a["active_lines"]} \\\\\n')
table = """\\begin{center}
\\begin{tabular}{@{}lrrrr@{}}
\\toprule
& \\multicolumn{2}{c}{Physical lines} & \\multicolumn{2}{c}{Active lines}\\\\
Module & Before & After & Before & After\\\\
\\midrule
""" + "".join(rows) + f'\\midrule\nTotal & {before["physical_lines"]} & {after["physical_lines"]} & {before["active_lines"]} & {after["active_lines"]} \\\\\n' + "\\bottomrule\n\\end{tabular}\n\\end{center}\n"
(bundle / "report/metrics_table.tex").write_text(table)

old_main = (bundle / "baseline" / prefix / "Main.lean").read_text()
new_main = (bundle / "replacement/Main.lean").read_text()
old_body = audit["proof_body"](old_main, "flexibleOutput", "/-- The sentence form:")
new_body = audit["proof_body"](new_main, "flexibleOutput", "/-- The sentence form:")
(bundle / "report/main_before.lean").write_text(old_body[old_body.index("    obtain ⟨m, hm⟩"):])
(bundle / "report/main_after.lean").write_text(new_body.splitlines()[-1] + "\n")
search = (bundle / "replacement/Search.lean").read_text()
(bundle / "report/search_domain.lean").write_text(search[search.index("  have hdom :"):search.index("  have hrun :")])
witness_lines = [line for line in search.splitlines() if "(evaln_sound hz).fst" in line or "evaln_complete.mp (Part.get_mem" in line]
(bundle / "report/search_witnesses.lean").write_text("\n".join(witness_lines) + "\n")
refutations = (bundle / "replacement/Refutations.lean").read_text()
start = refutations.index("lemma neg_subst_quote")
start = refutations.index(":= by\n", start) + len(":= by\n")
end = refutations.index("/-- The refuted outputs", start)
(bundle / "report/neg_subst_quote.lean").write_text(refutations[start:end].strip("\n") + "\n")
functionality = (bundle / "replacement/Functionality.lean").read_text()
start = functionality.index("  case comp ")
end = functionality.index("  case rfind ", start)
(bundle / "report/composition_case.lean").write_text(functionality[start:end])
print("Refreshed four patches, combined patch, report metrics, and exact source excerpts.")
