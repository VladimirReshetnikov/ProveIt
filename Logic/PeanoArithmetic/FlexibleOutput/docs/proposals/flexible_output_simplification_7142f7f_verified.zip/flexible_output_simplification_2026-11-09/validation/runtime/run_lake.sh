#!/usr/bin/env bash
set -euo pipefail
export PATH=/workspace/scratch/2ad373dbb678/toolchain/lean-4.32.0-linux/bin:$PATH
export LD_PRELOAD=/workspace/scratch/2ad373dbb678/toolchain/proc_self_compat.so
export LAKE_JOBS=1
export LEAN_NUM_THREADS=1
exec /workspace/scratch/2ad373dbb678/toolchain/lean-4.32.0-linux/bin/lake "$@"
