Validation runtime records
==========================

These are the actual minimal Lake configuration and launcher sources used
for the validation run. run_lake.sh records host-specific absolute paths;
it is a provenance record, not the portable reproduction entry point.
Use ../../scripts/check_lean.sh in a normal pinned ProveIt checkout.

The official Lean compiler, elaborator, and kernel were unmodified. This
container needed a narrow readlink compatibility shim for its current-process
executable lookup. proc_self_compat.c maps only /proc/<current getpid()>/exe
to /proc/self/exe. Its compiled shared object was used through LD_PRELOAD.
The binary is not shipped. It can be rebuilt, if this same runtime issue is
encountered, with:

  cc -shared -fPIC -O2 -o proc_self_compat.so proc_self_compat.c -ldl

Normal hosts do not require this shim. One Lean worker was used because
zero workers triggered a Lake IO.Promise startup error in this environment.

The environment JSON records hashes and paths from the actual build host.
The compiled-source manifest and delivered-source verification record map
the final source bytes to this archive. Build logs include replayed upstream
Foundation linter messages; the final modified modules have no own warnings.
