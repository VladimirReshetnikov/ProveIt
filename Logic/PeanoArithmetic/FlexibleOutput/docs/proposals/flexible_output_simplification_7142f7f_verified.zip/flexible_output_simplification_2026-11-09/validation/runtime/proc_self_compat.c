#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

/* Runtime compatibility only: Lean locates its own executable with
   /proc/<getpid()>/exe. This container exposes the same executable as
   /proc/self/exe while getpid() uses an unmounted PID namespace. */
ssize_t readlink(const char *path, char *buf, size_t size) {
    static ssize_t (*system_readlink)(const char *, char *, size_t);
    if (!system_readlink)
        system_readlink = dlsym(RTLD_NEXT, "readlink");
    char own_executable[64];
    snprintf(own_executable, sizeof own_executable, "/proc/%d/exe", (int)getpid());
    if (strcmp(path, own_executable) == 0)
        path = "/proc/self/exe";
    return system_readlink(path, buf, size);
}
