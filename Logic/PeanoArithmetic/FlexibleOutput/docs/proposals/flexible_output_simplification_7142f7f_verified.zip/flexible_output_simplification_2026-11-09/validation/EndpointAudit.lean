import PAFlexibleOutput

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

-- Exact current main statement: one code, all standard inputs, all values.
-- The model may depend on the input and value.
example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧ ∀ (x : ℕ) (o : Option ℕ),
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e x o :=
  flexibleOutput

-- Exact function endpoint, including its chosen code and unique-output reading.
example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧ ∀ o : Option ℕ,
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e 0 o :=
  exists_partrec_flexibleOutput

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ x n : ℕ, Satisfiable (insert (haltSentence e x n) 𝗣𝗔) :=
  flexibleOutput_satisfiable

#print axioms flexibleOutput
#print axioms exists_partrec_flexibleOutput
#print axioms flexibleOutput_satisfiable
#print axioms codeAux_uniq
#print axioms code_uniq
#print axioms universalGraph_uniq
#print axioms valueIn_of_models
#print axioms refutationsRE
#print axioms exists_selector
#print axioms standardCorrectness

end PAFlexibleOutput
