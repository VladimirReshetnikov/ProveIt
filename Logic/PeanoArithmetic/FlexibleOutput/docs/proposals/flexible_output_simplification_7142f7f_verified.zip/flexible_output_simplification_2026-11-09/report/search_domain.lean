  have hdom : ∀ p : α × ℕ, (eval cg (Encodable.encode p)).Dom ↔ R p := fun p => by
    simp [hcg, Part.assert, Part.map]
