    simpa [← he x, Part.dom_iff_mem, hdiv x] using hfind (e, x) n hn
