    obtain ⟨m, hm⟩ := Part.dom_iff_mem.1 (hfind (e, x) n hn)
    exact hdiv x m (he x ▸ hm)
