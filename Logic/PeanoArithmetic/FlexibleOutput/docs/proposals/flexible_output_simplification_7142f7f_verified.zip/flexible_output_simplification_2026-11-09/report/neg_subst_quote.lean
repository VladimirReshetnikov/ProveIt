  simpa [substNumerals, natCast_nat, Matrix.comp_vecCons', Matrix.empty_eq,
    Matrix.constant_eq_singleton, Sentence.quote_def, Semiformula.quote_def] using
    congrArg (neg ℒₒᵣ) (substNumerals_app_quote (V := ℕ) universalGraph ![y, c, x])
