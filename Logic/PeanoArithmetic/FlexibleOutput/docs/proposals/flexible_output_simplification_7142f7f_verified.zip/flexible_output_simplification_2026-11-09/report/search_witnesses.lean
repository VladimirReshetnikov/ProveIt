    exact (hdom _).mp (evaln_sound hz).fst
  · obtain ⟨s, hs⟩ := evaln_complete.mp (Part.get_mem ((hdom (a, n)).mpr hn))
