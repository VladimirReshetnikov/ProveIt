# Twelve-archive novelty audit

Repository snapshot: `dabb61f75f93a48bf9a7010e3e628ab3b1ca9c07`.
Directory: `Logic/PeanoArithmetic/FlexibleOutput/docs/proposals`.

All twelve ZIPs were extracted into separately named directories. Archive entries were checked for absolute paths and `..` traversal before extraction. `prior-proposals.json` records archive sizes, Git blob SHA-1 values, and SHA-256 checksums. The archive Git blob hashes match the snapshot tree and the preceding `768379ed8153f13cc6f0b931203d5426f7ee50bf` directory listing. No applicable `AGENTS.md` exists in the target or its ancestors in this snapshot.

The following inventory compares the reports' proposals, optional research directions, and the actual production patch footprints. A copied original Lean file is not treated as a proposal. Earlier packages' claims of novelty were evaluated relative to their own older snapshots; they do not supersede the present twelve-archive exclusion set.

## Inventory

| ID | Exact filename | Implemented changes already proposed | Additional prior directions |
|---|---|---|---|
| A0 | `flexible_output_compositional_re.zip` | Work directly with the canonical `Part.assert` computation in `REPred`; shorten `const`, `comp`, `and`, `or`; use `Partrec.merge'` for the domain-only disjunction fact; add `REPred.forall_lt`; rewrite `sigma1_re` using primitive-recursive predicate atoms and compositional bounded-universal closure. | None material beyond generic maintenance/evidence discussion. |
| A1 | `flexible_output_dependency_simplification.zip` | Move the selector into `Foundation.Vorspiel.PartrecSelector`; derive generic and natural-number projection from that one selector; delete the duplicate finite-prefix search, monotonicity proof, and encoding lift; replace broad incompleteness imports with D1 and repair the quotation/equality instances. | Checked direct graph construction carrying Sigma1, standard correctness, and model-functionality certificates; checked padded induction semantic lemma; unimplemented external enumeration of finite proof certificates. |
| A2 | `flexible_output_dependency_simplification_2026-11-10.zip` | Replace `Nat.Partrec.projection` by direct paired branch/time search under output uniformity; rewrite `Nat.ArithPart₁.bind` and `.map` with monad laws; keep `models_codeAux` in partial-value membership form; narrow incompleteness imports. | Uniform-stage `Nat.rfindOpt` helper; isolating PA definability from restricted-induction recognition; further monad-law replacements. |
| A3 | `flexible_output_padded_induction_2026-11-09.zip` | New effective PA presentation permitting redundant closing universal quantifiers; remove exact `bv = closure depth` recognition; prove model equivalence and provability equivalence, transport refutation enumeration; retain exact-recognizer compatibility separately. | This completes A1's padded-induction direction and must not be proposed afresh. |
| A4 | `flexible_output_recognizer_simplification_2026-11-10.zip` | Factor exact PA and I-Sigma-one recognizer correctness over a side predicate on the recovered core; preserve concrete recognizers and witnessing formulas; expose/reuse `Semiformula.not_fvar?_fixitr_fvSup`; prove shift-fixed closure by strong induction; rewrite `sigma1_re` atoms through `PrimrecPred` and bounded-forall successor case using `Nat.forall_lt_succ_right`. | Explicitly excludes external proof enumeration, direct graph certificates, projection, import cuts, and padded presentations as already proposed. |
| A5 | `flexible_output_simplification (1).zip` | Use unary encoding of `((c,x),y)` and arithmetic pairing projections as arity bridge to `re_iff_sigma1`; quotation by congruence/vector normalization; functionality normalization; use existing partial-value domain API. | Upstream selector and PA-minus functionality interfaces. |
| A6 | `flexible_output_simplification (2).zip` | Direct PA soundness/completeness proof replacing custom arithmetic bridge, model/search records; one no-output contradiction serves divergence and non-refutation; normalize functionality cases; simplify statement conversion and vector quotation. | General consistent r.e. arithmetic theories; reusable selector/functionality interfaces; proof-expression/performance measurement. |
| A7 | `flexible_output_simplification.zip` | Search for a refutation of full singleton-output specification `forall y, G(y,c,x) iff y=n`; obtain uniqueness directly by completeness; remove global functionality from principal import route; generic fixed-template refutation enumeration; unary search; compatibility modules. | Semantic/intensional limits and warnings against invalid sequential partial search. |
| A8 | `flexible_output_simplification_2026-11-09.zip` | Same full/exact-value search idea; generic `templateRefutationsRE`; retain stronger functionality in optional audit; conservative direct-soundness alternative keeps original search. | Alternative accounting and local compiler/search cleanups. |
| A9 | `flexible_output_simplification_7142f7f_verified.zip` | Four post-upstream local changes: selector domain via Part API, Main contradiction at domain level, quoted negation by congruence, normalize functionality composition once. | Historical direct bridge removal is credited as upstream, not new. |
| A10 | `flexible_output_witness_search.zip` | Map a successful semidecision to its candidate witness before compilation; bounded evaluation directly returns witness, deleting post-evaluation `Option.map`; optional common functionality normalization with restricted `grind only`. | Reduce generated proof size / grind cost; find other witness-before-compilation sites; generalized output types. |
| A11 | `pa_flexible_output_simplification.zip` | Direct concrete soundness proof; shorten generic `MathlibAssembly`; normalize composition/minimization functionality; remove redundant dovetailing witnesses; vector mapping for quotation. | General selector; upstream functionality; relation-level diagonal theorem `R(c,y) -> y notin eval c 0`; proof-expression/maintenance comparison. |

## Production patch boundaries

- A0: `Foundation/Vorspiel/Computability.lean` (`REPred` closure section) and `Foundation/FirstOrder/Arithmetic/R0/Representation.lean` (`sigma1_re`), plus a separate module-rename repair.
- A1: `Foundation/Vorspiel/Computability.lean`, new `Foundation/Vorspiel/PartrecSelector.lean`, imports of `Foundation/FirstOrder/Incompleteness/InductionSchemeDelta1.lean`, local `Refutations.lean` and `Search.lean`.
- A2: `Foundation/Vorspiel/Computability.lean`, `Foundation/Vorspiel/Arithmetic.lean`, `Foundation/FirstOrder/Arithmetic/R0/Representation.lean` (`models_codeAux`), imports of `InductionSchemeDelta1.lean`, local `Refutations.lean` and `Main.lean`.
- A3: new local `PaddedInduction.lean`, `LegacyRefutations.lean`, exact-statement audit, and changes to local `Provability.lean` (older patch says `Refutations.lean`). No Foundation source edit.
- A4: `Foundation/FirstOrder/Arithmetic/R0/Representation.lean` (`sigma1_re`), one lemma's visibility in `Foundation/FirstOrder/Basic/Syntax/Rew.lean`, correctness/support portions of `InductionSchemeDelta1.lean`, plus separate import/name repair.
- A5: local `Functionality.lean`, `Refutations.lean`, and `Search.lean`.
- A6: local `Main.lean`, `Functionality.lean`, and `Refutations.lean`.
- A7: local `Main.lean`, `Refutations.lean`, `Search.lean`, facade; new `Semantics.lean`, `Compatibility.lean`, and audits.
- A8: local `Main.lean`, `Refutations.lean`, facade; new optional `FullAudit.lean`.
- A9: local `Search.lean`, `Main.lean`, `Refutations.lean`, and `Functionality.lean`.
- A10: local `Search.lean`, `Functionality.lean`, plus independent module-import repair.
- A11: local `Functionality.lean`, `MathlibAssembly.lean`, `Search.lean`, `Refutations.lean`, optional `Main.lean`/facade direct-proof change.

## Important exclusions beyond implemented patches

A1's `research/DirectRepresentation.lean` is a 168-line checked prototype constructing an arithmetic graph by induction on `Nat.ArithPart₁`, with Sigma1, standard semantics, and model-functionality certificates. Completing a direct-certificate compiler is implementation progress on a prior proposal, not an unseen idea. It changes the syntactic choice of graph and still imports the legacy compiler in the prototype.

A1's external proof-certificate enumeration is only a sketch; nevertheless the user excludes proposals, not only completed implementations. A fresh report should not present “enumerate finite derivations externally to avoid arithmetized provability” as novel. The earlier report specifically identifies missing primitive-codability/computability adapters for syntax operations and axiom certificates.

A2 explicitly proposes separating PA definability from restricted-induction recognition. A4's shared correctness proof does something different, but merely relocating the PA path out of the I-Sigma-one module is not a fresh direction.

A11 already suggests factoring the relation-level diagonal argument. Changing its theorem name or packaging is not a new proposal.

## Nearby targets not changed by any archived patch

These are places to investigate, not validated simplifications:

1. Exact-arity bookkeeping inside `InductionSchemeDelta1.lean`: `semitermVec_val_congr`, `Semiterm.quote_castLE`, `Semiterm.freeVariables_castLE`, `Semiformula.quote_castLE`, `Semiformula.freeVariables_castLE` (baseline lines 206–280). The archived exact-recognizer proposal leaves these proofs unchanged. Padded induction bypasses this portion by changing theory presentation, rather than simplifying these same proofs.
2. The main lower-bound argument in `bv_quote_fixitr` (baseline lines 296–364), beyond the already proposed reuse of its no-free-variable sublemma.
3. `closure_inversion` (baseline lines 969–1020), beyond the already proposed move to a different padded theory that avoids exact inversion.
4. `subst_fvarVec_quote'` and arity-independent quote/free-variable transport lemmas, if a concrete new reduction can count every added helper.

Any final candidate still needs a targeted search of all extracted reports, patches, and research artifacts for its particular mathematical idea. Absence from a patch footprint alone does not prove novelty.

## Targeted candidate audit: quotient-first arithmetic compiler

Candidate: prove `Nat.Arithmetic₁.div` by minimizing the total predicate
`divisor = 0 or dividend < (q + 1) * divisor`, derive remainder by
`dividend - (dividend / divisor) * divisor`, and derive divisibility from
zero remainder. This changes the construction order of the existing
arithmetic compiler primitives to `div -> rem -> dvd` while preserving the
old `dvd` and `rem` theorem statements.

Searches over every extracted `.tex`, `.md`, `.txt`, `.patch`, `.diff`, and
`.lean` file for quotient, division, divisibility, remainder, `Arithmetic₁.div`,
`Arithmetic₁.rem`, `Nat.div`, `div_mul`, `div_lt`, `mod_eq`, and corresponding
declaration names found no proposal for this route. The only meaningful
Lean occurrences are copies of the existing `dvd` and `rem` declarations
in A2's baseline and overlay `Foundation/Vorspiel/Arithmetic.lean`.
Both declarations are byte-identical between A2's baseline and overlay.
The report phrase “Division into small obligations” in A8 refers to
organizational structure, not arithmetic division; generated dependency
audits also contain quotient-type metadata unrelated to this candidate.

This differs substantively from A1/A2's uniform-output projection: that
work changes a generic branch/time dovetail search for partial computations
whose successful outputs agree. The candidate instead replaces two
separate constructions of total arithmetic primitives by one Euclidean
division construction and arithmetic identities. The mathematical and
implementation dependency ordering is new within this corpus.

No claim about successful elaboration, correctness, or quantitative savings
is established by this novelty audit; those require the candidate's own
validation. The novelty claim is relative to these twelve archives, not a
claim that Euclidean division or minimization is new mathematics.

## Report paths

All paths below are relative to this audit directory:

- A0: `00_flexible_output_compositional_re/flexible_output_compositional_re/report/flexible_output_compositional_re.tex`
- A1: `01_flexible_output_dependency_simplification/flexible_output_dependency_simplification/report.tex`
- A2: `02_flexible_output_dependency_simplification_2026-11-10/flexible_output_dependency_simplification/flexible_output_dependency_simplification.tex`
- A3: `03_flexible_output_padded_induction_2026-11-09/flexible_output_padded_induction_2026-11-09/report.tex`
- A4: `04_flexible_output_recognizer_simplification_2026-11-10/flexible_output_recognizer_simplification_2026-11-10/report.tex`
- A5: `05_flexible_output_simplification_1/flexible_output_simplification/flexible_output_simplification.tex`
- A6: `06_flexible_output_simplification_2/flexible_output_simplification/flexible_output_simplification.tex`
- A7: `07_flexible_output_simplification/flexible_output_simplification/report/flexible_output_simplification.tex`
- A8: `08_flexible_output_simplification_2026-11-09/flexible_output_simplification/report.tex`
- A9: `09_flexible_output_simplification_7142f7f_verified/flexible_output_simplification_2026-11-09/report/flexible_output_simplification.tex`
- A10: `10_flexible_output_witness_search/flexible_output_witness_search/report.tex`
- A11: `11_pa_flexible_output_simplification/pa_flexible_output_simplification/pa_flexible_output_simplification.tex`
