# Independent review of the quotient-first arithmetic construction

Status note: this source review was written before the integrated builds. Its empirical obligations were subsequently completed successfully; see `validation-summary.json`, the baseline/patched logs, and the final report.

Reviewed candidate: `code/QuotientFirst.lean` (reviewed under its original scratch filename `ArithmeticTest.lean`), containing `Nat.Arithmetic₁.div_new`, `rem_new`, and `dvd_new` as viewed during this review. This is a mathematical/source review, distinct from compiler validation.

## Quotient search

For natural inputs `a = v.get i` and `b = v.get j`, the candidate compiles the total natural-number predicate

`F(q,a,b) = isEqNat(b,0).or(isLtNat(a,(q+1)*b))`.

The library's `ArithPart₁.rfindPos` returns the least `q` for which `F` is positive. Its search predicate is total, because equality, order, addition, multiplication, and Boolean-valued disjunction are total.

- If `b = 0`, every `q` satisfies the first disjunct. The least successful `q` is `0`, which agrees with Lean's total natural-number division convention `a / 0 = 0`.
- If `b > 0`, the first disjunct is false. The exact integer division equivalence is `a < (q+1)*b` if and only if `a/b < q+1`, which is equivalent over naturals to `a/b ≤ q`. Thus the successful values are precisely the upper set starting at `a/b`, and its least member is `a/b`.

This proves both termination and the returned quotient, including the boundary case `a = 0`. The predicate is compiled using only operations already available before the old `dvd` declaration.

## Remainder and divisibility

The remainder theorem composes the earlier truncated-subtraction primitive with the quotient and multiplication:

`a - (a / b) * b = a % b`.

`Nat.mod_eq_sub_div_mul` is valid for all naturals, including `b = 0`, where both sides equal `a`. The `.symm` orientation in the candidate is appropriate for the library's `.of_eq` transport.

The divisibility theorem tests whether the remainder is zero. Its argument order is deliberate: the old API computes `isDvdNat(v.get i, v.get j)`, so `dvd_new i j` uses `rem_new j i`. This is exactly `v.get i ∣ v.get j` if and only if `v.get j % v.get i = 0`, including divisor zero and dividend zero.

## No circular appeal to compiler completeness

The candidate's quotient uses only `Arithmetic₁.or`, `equal`, `zero`, `lt`, `mul`, `succ`, `head`, `proj`, their composition combinators, and `ArithPart₁.rfindPos`. Remainder additionally uses the earlier `Arithmetic₁.sub`. Divisibility adds equality with zero. These declarations precede the old `dvd` and `rem` location.

The candidate never invokes `Arithmetic₁.of_primrec`, `ArithPart₁.of_partrec`, or a theorem derived from `beta`/`prec`. Those later theorems depend on the remainder construction, so using them here would have been circular. The proposed order is acyclic:

`earlier primitives -> div -> rem -> beta -> prec -> of_primrec -> of_partrec`.

The public divisibility theorem becomes a short consequence of `rem`; it is no longer required by the beta/primitive-recursion compiler route.

## What changes and what remains the same

The old source constructs divisibility by a bounded search for a multiple and then constructs remainder by another least-witness argument involving divisibility and truncated subtraction. The candidate supplies a single quotient search and derives both operations by arithmetic identities.

The theorem types for `dvd` and `rem` can be preserved exactly. The inductive `ArithPart₁` basis, its `Code` datatype, `Code.eval`, and all arithmetic-formula definitions can remain unchanged. In FlexibleOutput, `universalGraph` is defined using the existing choice-based `codeOfPartrec' universalEval`; the proposal need not change this definition, its interpretation, the halting sentence, functionality, or the final all-input theorem.

The code proof of `ArithPart₁.of_partrec` changes transitively because its primitive recursion support becomes shorter. This does not justify claiming that the chosen syntactic universal graph was replaced: its defining expression and the code-evaluation relation are unchanged.

## Remaining empirical obligations

The proposed production file should be rebuilt in dependency order, followed by the requested FlexibleOutput endpoint. The compiler audit should check the new quotient theorem, retained public `dvd`/`rem` theorem statements, and final theorem axioms. All newly added quotient code must be included in size comparisons. A source-line reduction by itself does not establish a faster build, smaller complete kernel proof, or runtime performance improvement.

No mathematical defect was found in the candidate viewed here.
