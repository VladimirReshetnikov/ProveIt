# Proposal-corpus refresh: thirteenth archive

This supplements `novelty-audit.md`, `prior-proposals.json`, and
`quotient-novelty-search.json`; the original twelve-archive evidence is
preserved unchanged.

## Snapshot and scope comparison

- Original audited ProveIt commit: `dabb61f75f93a48bf9a7010e3e628ab3b1ca9c07`.
- Refreshed ProveIt commit: `7f5ed7ca0a6caebb7d6d6d2bb35431c34a66ed1e`.
- Newly added archive: `flexible_output_pa_sigma1_split.zip`.
- Repository path: `Logic/PeanoArithmetic/FlexibleOutput/docs/proposals/flexible_output_pa_sigma1_split.zip`.
- Git blob SHA-1: `fc7bed4275de48e942d06b4bfed268583f809a67`.
- ZIP SHA-256: `7ca53711fb661ee49226ccb4a6f5c19381856e89ae85919653d68b984218f0dc`.
- ZIP size: 222,095 bytes.

The commit comparison contains 129 changed paths in the whole repository.
Within the following explicit review scope, its only change is the addition
of this archive:

1. `Logic/PeanoArithmetic/FlexibleOutput`.
2. `lib/FormalizedFormalLogic-Foundation` (the dependency gitlink).
3. `lean-toolchain`.
4. `lakefile.toml`.
5. `lake-manifest.json`.
6. `.gitmodules`.

Thus all FlexibleOutput source files, its existing twelve proposal archives,
the Foundation dependency revision, and the relevant build/dependency
configuration are unchanged. The original proof-validation baseline remains
applicable. This is a source comparison, not a claim that the entire repository
is unchanged or that the new head was separately rebuilt.

The complete and scoped path comparisons are recorded in
`refresh_all_changes.txt` and `refresh-scoped-changes.txt` respectively.

## A12: PA / I-Sigma-one module split

The new archive proposes splitting Foundation's
`FirstOrder/Incompleteness/InductionSchemeDelta1.lean` into:

- `InductionSchemePA.lean`: unrestricted induction and PA axiom definability.
- `InductionSchemeSigma1.lean`: syntactic Sigma-one recognition and
  I-Sigma-one axiom definability, importing the PA module.
- `InductionSchemeDelta1.lean`: a compatibility re-export of both.

It changes FlexibleOutput's `Provability.lean` to import only the PA module
and includes the pre-existing `Refutations`/`Provability` import-name repair.
The package expressly preserves mathematical proof bodies and credits the
earlier D1 import pruning. Its claimed reduction concerns the imported source
closure; it records that the moved I-Sigma-one recognizer declarations were
already absent from the endpoints' declaration dependency closure.

The two patches touch only those three Foundation induction modules and
the ProveIt facade, Main, and Provability modules. They do not touch
`Foundation/Vorspiel/Arithmetic.lean`. No research implementation of arithmetic
division, remainder, or divisibility is present.

## Novelty conclusion for quotient-first compilation

The report, README, novelty analysis, patch paths and source content were
reviewed. Targeted searches over all text artifacts with extensions `.tex`,
`.lean`, `.md`, `.txt`, `.patch`, `.diff`, and `.py` found zero occurrences of:

- quotient, division, remainder, or divisibility terminology;
- `Arithmetic₁.div`, `Arithmetic₁.rem`, or `Arithmetic₁.dvd`;
- declarations named `div`, `rem`, or `dvd`;
- the characteristic division/remainder lemmas used by the new candidate.

The new archive therefore does not duplicate or anticipate the candidate's
construction: search once for the quotient, derive remainder by subtraction,
and derive divisibility from zero remainder. The two proposals affect
independent source files and different proof obligations. The quotient-first
novelty conclusion now covers all **thirteen** archives available at the
refreshed commit.

This conclusion is specific to the inspected proposal corpus. It does not
claim that Euclidean division, minimization, or the displayed arithmetic
identities are new mathematics.

## Integrity and evidence

The Git blob identifier and byte count were recomputed from the retrieved
ZIP and match the repository metadata. The archive was extracted under
`12_flexible_output_pa_sigma1_split/` after rejecting absolute paths,
parent-directory traversal, and symlink members. All 62 supplied SHA256SUMS
entries match the extracted files.

- `refresh-manifest.json`: exact archive metadata and complete member list.
- `refresh-quotient-novelty-search.json`: patterns, results, checksum checks,
  scope paths, and comparison metadata.
- Report inspected:
  `12_flexible_output_pa_sigma1_split/flexible_output_pa_sigma1_split/report/flexible_output_pa_sigma1_split.tex`.
- Main novelty discussion inspected:
  `12_flexible_output_pa_sigma1_split/flexible_output_pa_sigma1_split/analysis/novelty_evidence.md`.

The checkout was not changed by this refresh. The additional archive was
read directly from the refreshed commit's Git object.
