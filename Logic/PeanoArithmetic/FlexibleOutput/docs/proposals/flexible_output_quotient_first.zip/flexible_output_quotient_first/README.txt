FLEXIBLEOUTPUT: QUOTIENT-FIRST ARITHMETIC COMPILATION
==================================================

The report explains a distinct simplification of a transitive Lean dependency:
compile division by least search, then obtain remainder and divisibility by
standard arithmetic identities. The affected block shrinks from 60 to 23
physical lines including the new division theorem.

Integrated result: both baseline and patched full PAFlexibleOutput builds passed.
All original checked types are preserved. Combined proof-expression nodes for
the changed block fall from 56,357 to 19,899, including the new helper. The main
theorem's dependency graph falls from 16,960 to 16,939 declarations and no longer
reaches Nat.Arithmetic1.dvd. Axioms remain propext, Classical.choice, Quot.sound.

Read report.pdf or rebuild it from report.tex. The code change is in the pinned
Foundation submodule, not the final theorem's statement. The proposal preserves
the existing universal graph and both existing public rem/dvd theorem signatures.

SOURCE PINS
-----------
ProveIt:   dabb61f75f93a48bf9a7010e3e628ab3b1ca9c07
Foundation:32e1a0956a8622fad067328ca1959729a7634428
Mathlib:   81a5d257c8e410db227a6665ed08f64fea08e997
Lean:      leanprover/lean4:v4.32.0
Novelty:   all 13 archives through 7f5ed7ca0a6caebb7d6d6d2bb35431c34a66ed1e

The newer novelty revision adds only one proposal ZIP within the relevant source
and configuration scope. All proof sources and pinned dependencies are identical
to the validation baseline. The entire newer repository head was not rebuilt.

CONTENTS
--------
report.tex / report.pdf       Mathematical argument, code, audit and limitations.
patches/01-foundation-quotient.patch
                             Mathematical patch, relative to Foundation root.
patches/00-import-repair.patch
                             Independent two-import repair, relative to ProveIt.
replacement/Foundation/Vorspiel/Arithmetic.lean
                             Complete replacement Foundation source.
code/QuotientFirst.lean       Standalone checked proof demonstration.
code/quotient-block.lean      Production snippet used by the report.
verification/ExactStatements.lean
                             Original APIs and all three endpoint statements.
verification/DependencyAudit.lean
                             Elaborated declarations, axioms and expression sizes.
scripts/check.sh              Rebuild/check an already patched ProveIt checkout.
scripts/measure.py            Reproduce source metrics from pinned Git objects.
scripts/build-report.sh       Compile the report with XeLaTeX, including a local
                             format fallback for incomplete TeX installations.
evidence/                    Logs, metrics, novelty audit and archive identities.
licenses/                    Foundation Apache-2.0 and ProveIt MIT-0 licenses.
SHA256SUMS                    Integrity manifest for all other packaged files.

APPLICATION
-----------
Use an isolated checkout of the pinned ProveIt revision with its pinned Foundation
submodule, Mathlib and Lean toolchain available. From the ProveIt root, first run
git apply --check on each patch, then apply it at its stated root.

  git apply /absolute/package/path/patches/00-import-repair.patch
  git -C lib/FormalizedFormalLogic-Foundation apply \
    /absolute/package/path/patches/01-foundation-quotient.patch
  bash /absolute/package/path/scripts/check.sh /absolute/path/to/ProveIt

The import repair only changes PAFlexibleOutput.Refutations to
PAFlexibleOutput.Provability in Main.lean and the facade. The snapshot contains
the latter filename. The same repair is included in the baseline validation and
is excluded from every simplification metric. If a newer checkout already fixes
the imports, do not apply that patch again.

The check script does not apply patches. It writes a fresh dependency audit with
the prefix evidence/recheck. Source metrics can be reproduced with:

  python3 scripts/measure.py /path/to/ProveIt/lib/FormalizedFormalLogic-Foundation

See the completed validation section of report.pdf and the recorded logs for
the exact checks performed. Historical claims in prior-proposal archives are
not treated as fresh validation of this patch.

REPORT BUILD
------------
Run `bash scripts/build-report.sh`. It requires XeLaTeX with the packages named
in report.tex and the Latin Modern Roman/Sans and DejaVu Sans Mono fonts. A normal
complete TeX installation can also compile report.tex with XeLaTeX twice.

LICENSING AND MODIFICATIONS
--------------------------
The replacement Foundation file and patch derive from Foundation at the stated
commit, distributed under Apache-2.0. Modifications add Nat.Arithmetic1.div and
replace/reorder Nat.Arithmetic1.rem and .dvd. No other Foundation declaration is
edited. The report, audit scripts and newly written demonstration are provided
for use under Apache-2.0 as well. ProveIt snippets/import repairs retain its
MIT No Attribution license. Unicode subscripts in Lean source are preserved;
the plain-text names in this README are explanatory spellings.
