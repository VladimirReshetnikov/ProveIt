#!/usr/bin/env bash
# Compile the report with XeLaTeX. A complete TeX Live installation is sufficient.
set -euo pipefail

report_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
command -v xelatex >/dev/null 2>&1 || {
  printf '%s\n' 'XeLaTeX is required. Install TeX Live with XeTeX and the report packages.' >&2
  exit 1
}

task_format_dir=''
cleanup() {
  if [[ -n "$task_format_dir" ]]; then
    rm -rf -- "$task_format_dir"
  fi
}
trap cleanup EXIT
task_format_options=()

# Some minimal TeX installations contain the sources but no prebuilt formats.
# Build a private format for this invocation; do not alter system TeX settings.
if ! kpsewhich xelatex.fmt >/dev/null 2>&1; then
  task_format_dir="$(mktemp -d "${TMPDIR:-/tmp}/flexible-output-tex.XXXXXX")"
  if ! (
    cd -- "$task_format_dir"
    xetex -ini -etex -jobname=xelatex -progname=xelatex \
      -interaction=nonstopmode -halt-on-error xelatex.ini > format-build.log 2>&1
  ); then
    cat -- "$task_format_dir/format-build.log" >&2
    exit 1
  fi
  task_format_options=("-fmt=$task_format_dir/xelatex.fmt")
fi

cd -- "$report_root"
for task_pass in 1 2; do
  xelatex "${task_format_options[@]}" -interaction=nonstopmode -halt-on-error report.tex
done
