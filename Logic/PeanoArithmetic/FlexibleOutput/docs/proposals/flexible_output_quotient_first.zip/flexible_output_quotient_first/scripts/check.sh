#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: bash scripts/check.sh /absolute/path/to/ProveIt" >&2
  exit 2
fi
package_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
repository_dir="$(cd "$1" && pwd)"
cd "$repository_dir"
export LAKE_JOBS="${LAKE_JOBS:-1}"
export LEAN_NUM_THREADS="${LEAN_NUM_THREADS:-0}"

lean --version
lake build +PAFlexibleOutput
lake env lean "$package_dir/verification/ExactStatements.lean"
lake env lean "$package_dir/verification/DivAudit.lean"
FLEXIBLE_AUDIT_PREFIX="$package_dir/evidence/recheck" \
  lake env lean "$package_dir/verification/DependencyAudit.lean"
lake env lean "$package_dir/code/QuotientFirst.lean"

echo "Build, exact statements, dependency audit, and standalone proofs passed."
