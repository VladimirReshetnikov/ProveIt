#!/usr/bin/env python3
"""Compare all source charged to the quotient-first change, including new div.

Usage: python3 scripts/measure.py /path/to/ProveIt/lib/FormalizedFormalLogic-Foundation
Reads the pinned Git object without modifying the submodule or current source.
"""
from pathlib import Path
import json
import subprocess
import sys

PIN = "32e1a0956a8622fad067328ca1959729a7634428"
REL = "Foundation/Vorspiel/Arithmetic.lean"
PACKAGE = Path(__file__).resolve().parent.parent

if len(sys.argv) != 2:
    raise SystemExit(__doc__)
old = subprocess.check_output(["git", "-C", sys.argv[1], "show", f"{PIN}:{REL}"]).decode()
new = (PACKAGE / "replacement" / REL).read_text(encoding="utf-8")
old_start = old.index("set_option backward.isDefEq.respectTransparency false in\nlemma dvd")
new_start = new.index("lemma div (i j : Fin n)")
old_region = old[old_start:old.index("\nlemma beta (i j : Fin n)", old_start)]
new_region = new[new_start:new.index("\nlemma beta (i j : Fin n)", new_start)]

def stats(s):
    return {"physical_lines": len(s.splitlines()),
            "nonblank_lines": sum(bool(x.strip()) for x in s.splitlines()),
            "utf8_bytes": len(s.encode())}

result = {"foundation_revision": PIN, "path": REL,
          "file": {"before": stats(old), "after": stats(new)},
          "affected_region": {"before": stats(old_region), "after": stats(new_region)}}
for key in ("file", "affected_region"):
    result[key]["savings"] = {k: result[key]["before"][k] - result[key]["after"][k]
                               for k in result[key]["before"]}
print(json.dumps(result, indent=2))
