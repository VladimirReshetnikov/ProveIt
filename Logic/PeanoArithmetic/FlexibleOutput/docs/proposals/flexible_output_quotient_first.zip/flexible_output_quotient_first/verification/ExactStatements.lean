import PAFlexibleOutput

/- Exact public statements checked against the integrated replacement. -/
set_option autoImplicit false

open LO LO.FirstOrder LO.FirstOrder.Arithmetic

example {n : ℕ} (i j : Fin n) :
    Nat.Arithmetic₁ (fun v => v.get i % v.get j) :=
  Nat.Arithmetic₁.rem i j

example {n : ℕ} (i j : Fin n) :
    Nat.Arithmetic₁ (fun v => Nat.isDvdNat (v.get i) (v.get j)) :=
  Nat.Arithmetic₁.dvd i j

example :
    ∃ e : PAFlexibleOutput.Code,
      (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ (x : ℕ) (o : Option ℕ),
        ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
          PAFlexibleOutput.ValueIn M e x o :=
  PAFlexibleOutput.flexibleOutput

example :
    ∃ e : PAFlexibleOutput.Code,
      (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ x n : ℕ, Satisfiable (insert (PAFlexibleOutput.haltSentence e x n) 𝗣𝗔) :=
  PAFlexibleOutput.flexibleOutput_satisfiable

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : PAFlexibleOutput.Code,
      Nat.Partrec.Code.eval e = f ∧ ∀ o : Option ℕ,
        ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
          PAFlexibleOutput.ValueIn M e 0 o :=
  PAFlexibleOutput.exists_partrec_flexibleOutput

#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
