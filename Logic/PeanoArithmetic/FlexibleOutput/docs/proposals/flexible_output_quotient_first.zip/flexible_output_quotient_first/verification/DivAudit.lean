import PAFlexibleOutput

#print axioms Nat.Arithmetic₁.div
#check Nat.Arithmetic₁.div
