import PAFlexibleOutput
import Lean.Util.FoldConsts

/-!
Audit the elaborated declaration graph, following references in both types and values.
This measures declarations actually used by a theorem, not modules imported by a file.
The type/value fingerprints are Lean expression hashes for comparison, not security hashes.
Proof-node counts count expression-tree occurrences without unfolding referenced constants.
-/

open Lean Elab Command

set_option maxRecDepth 100000
set_option maxHeartbeats 0

run_cmd do
  let env ← getEnv
  let outputPrefix := (← IO.getEnv "FLEXIBLE_AUDIT_PREFIX").getD "dependency_audit"
  let roots := #[``PAFlexibleOutput.flexibleOutput,
    ``PAFlexibleOutput.standardCorrectness, ``Nat.Arithmetic₁.rem]
  let watched : Array Name := #[`Nat.Arithmetic₁.div, `Nat.Arithmetic₁.rem,
    `Nat.Arithmetic₁.dvd, `Nat.Arithmetic₁.beta, `Nat.Arithmetic₁.prec,
    `Nat.Arithmetic₁.of_primrec, `Nat.ArithPart₁.of_partrec,
    `PAFlexibleOutput.flexibleOutput, `PAFlexibleOutput.flexibleOutput_satisfiable,
    `PAFlexibleOutput.exists_partrec_flexibleOutput,
    `PAFlexibleOutput.universalGraph, `PAFlexibleOutput.standardCorrectness]
  let mut watchRows : Array Json := #[]
  for name in watched do
    if let some ci := env.find? name then
      let val := ci.value? true
      watchRows := watchRows.push <| Json.mkObj [
        ("name", toJson name.toString),
        ("type", toJson (← liftTermElabM <| Meta.ppExpr ci.type).pretty),
        ("type_hash", toJson (toString (hash ci.type))),
        ("value_hash", toJson ((val.map (fun e => toString (hash e))).getD "none")),
        ("type_nodes", toJson ci.type.sizeWithoutSharing),
        ("value_nodes", toJson ((val.map Expr.sizeWithoutSharing).getD 0))]
  IO.FS.writeFile (outputPrefix ++ "_watched.json") ((Json.arr watchRows).pretty ++ "\n")
  for root in roots do
    let mut pending := [root]
    let mut seen : NameSet := {}
    let mut records : Array Json := #[]
    let mut axioms : Array String := #[]
    while !pending.isEmpty do
      let name := pending.head!
      pending := pending.tail!
      if seen.contains name then continue
      seen := seen.insert name
      let some ci := env.find? name | throwError "Cannot inspect {name}"
      if name == `sorryAx then throwError "Admitted proof reachable from {root}"
      if ci.isAxiom then axioms := axioms.push name.toString
      let mod := match env.getModuleIdxFor? name with
        | some i => env.header.moduleNames.getD i.toNat .anonymous
        | none => env.mainModule
      let val := ci.value? true
      records := records.push <| Json.mkObj [
        ("name", toJson name.toString), ("module", toJson mod.toString),
        ("is_axiom", toJson ci.isAxiom),
        ("type_hash", toJson (toString (hash ci.type))),
        ("value_hash", toJson ((val.map (fun e => toString (hash e))).getD "none")),
        ("type_nodes", toJson ci.type.sizeWithoutSharing),
        ("value_nodes", toJson ((val.map Expr.sizeWithoutSharing).getD 0))]
      for used in ci.getUsedConstantsAsSet do
        pending := used :: pending
    let result := Json.mkObj [
      ("root", toJson root.toString), ("count", toJson records.size),
      ("axioms", toJson (axioms.qsort (· < ·))),
      ("watched", Json.arr <| watched.map fun name => Json.mkObj [
        ("name", toJson name.toString), ("reachable", toJson (seen.contains name))]),
      ("declarations", Json.arr records)]
    IO.FS.writeFile (outputPrefix ++ "_" ++ root.toString ++ ".json") (result.pretty ++ "\n")
    logInfo m!"{root}: {records.size} declarations; axioms {axioms}"
    for name in #[`Nat.Arithmetic₁.div, `Nat.Arithmetic₁.rem, `Nat.Arithmetic₁.dvd] do
      logInfo m!"{root}: reachable {name} = {seen.contains name}"

#print axioms Nat.Arithmetic₁.dvd
#print axioms Nat.Arithmetic₁.rem
#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.universalGraph_uniq
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
