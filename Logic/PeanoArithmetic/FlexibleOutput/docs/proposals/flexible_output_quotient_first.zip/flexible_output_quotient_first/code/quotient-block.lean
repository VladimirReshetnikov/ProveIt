lemma div (i j : Fin n) : Arithmetic₁ (fun v => v.get i / v.get j) := by
  let F : List.Vector ℕ (n + 1) → ℕ := fun v =>
    (isEqNat (v.get j.succ) 0).or
      (isLtNat (v.get i.succ) ((v.head + 1) * v.get j.succ))
  have hF : Arithmetic₁ F :=
    (or 0 1).comp₂ _ ((equal 0 1).comp₂ _ (proj j.succ) zero)
      ((lt 0 1).comp₂ _ (proj i.succ)
        ((mul 0 1).comp₂ _ ((succ 0).comp₁ _ head) (proj j.succ)))
  exact (ArithPart₁.rfindPos hF).of_eq <| by
    intro v
    by_cases hj : v.get j = 0
    · simp [F, hj, Part.eq_some_iff]
    · simp [F, Part.eq_some_iff, hj, ← Nat.div_lt_iff_lt_mul (Nat.pos_of_ne_zero hj),
        Nat.succ_le_iff]

lemma rem (i j : Fin n) : Arithmetic₁ (fun v => v.get i % v.get j) :=
  ((sub 0 1).comp₂ _ (proj i)
    ((mul 0 1).comp₂ _ (div i j) (proj j))).of_eq fun _ =>
      Nat.mod_eq_sub_div_mul.symm

lemma dvd (i j : Fin n) : Arithmetic₁ (fun v => isDvdNat (v.get i) (v.get j)) :=
  ((equal 0 1).comp₂ _ (rem j i) zero).of_eq fun _ => by
    simp [isEqNat, isDvdNat, Nat.dvd_iff_mod_eq_zero]
