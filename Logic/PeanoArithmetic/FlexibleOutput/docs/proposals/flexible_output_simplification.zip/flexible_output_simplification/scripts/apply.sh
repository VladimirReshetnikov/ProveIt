#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /absolute/path/to/ProveIt" >&2
  exit 2
fi
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
git -C "$1" apply --check "$package_dir/flexible_output.patch"
git -C "$1" apply "$package_dir/flexible_output.patch"
