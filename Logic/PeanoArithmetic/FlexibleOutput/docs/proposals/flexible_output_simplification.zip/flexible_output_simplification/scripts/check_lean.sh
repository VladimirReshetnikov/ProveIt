#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /absolute/path/to/ProveIt" >&2
  exit 2
fi
cd "$1"
export LAKE_JOBS=1
export LEAN_NUM_THREADS=0
lake build +PAFlexibleOutput.Main
lake build +PAFlexibleOutput.Compatibility
lake build +PAFlexibleOutput.Audit
lake build +PAFlexibleOutput.DependencyAudit
lake build PAFlexibleOutput
