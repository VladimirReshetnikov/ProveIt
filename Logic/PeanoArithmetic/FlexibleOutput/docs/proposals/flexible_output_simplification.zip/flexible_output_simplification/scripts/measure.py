#!/usr/bin/env python3
"""Compare local main-module import closures; no external packages are counted."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEAN = Path("Logic/PeanoArithmetic/FlexibleOutput/Lean")


def strip_comments(text: str) -> str:
    """Strip nested Lean block comments and line comments, preserving strings/newlines."""
    out: list[str] = []
    i, depth = 0, 0
    in_string = False
    while i < len(text):
        pair = text[i:i + 2]
        if depth:
            if pair == "/-":
                depth += 1
                i += 2
            elif pair == "-/":
                depth -= 1
                i += 2
            else:
                if text[i] == "\n":
                    out.append("\n")
                i += 1
        elif in_string:
            out.append(text[i])
            if text[i] == "\\" and i + 1 < len(text):
                out.append(text[i + 1])
                i += 2
            else:
                if text[i] == '"':
                    in_string = False
                i += 1
        elif pair == "/-":
            depth = 1
            out.append(" ")
            i += 2
        elif pair == "--":
            i = text.find("\n", i)
            if i == -1:
                break
        else:
            out.append(text[i])
            if text[i] == '"':
                in_string = True
            i += 1
    if depth:
        raise ValueError("Unclosed block comment")
    return "".join(out)


def read_module(module: str, modified: bool) -> str:
    rel = LEAN / (module.replace(".", "/") + ".lean")
    overlay = ROOT / "overlay" / rel
    path = overlay if modified and overlay.exists() else ROOT / "baseline" / rel
    return path.read_text(encoding="utf-8")


def closure(modified: bool) -> dict:
    pending = ["PAFlexibleOutput.Main"]
    modules: dict[str, dict] = {}
    while pending:
        module = pending.pop()
        if module in modules:
            continue
        text = read_module(module, modified)
        clean = strip_comments(text)
        deps = re.findall(r"(?m)^\s*import\s+(PAFlexibleOutput(?:\.\w+)*)\s*$", clean)
        modules[module] = {
            "physical_lines": len(text.splitlines()),
            "active_lines": sum(bool(line.strip()) for line in clean.splitlines()),
            "utf8_bytes": len(text.encode("utf-8")),
            "local_imports": deps,
        }
        pending.extend(deps)
    keys = ("physical_lines", "active_lines", "utf8_bytes")
    return {
        "module_count": len(modules),
        "totals": {key: sum(v[key] for v in modules.values()) for key in keys},
        "modules": dict(sorted(modules.items())),
    }


def main() -> None:
    before, after = closure(False), closure(True)
    result = {
        "baseline_commit": "410c820c4faa7620a19ce07f55f43c13e5fbb688",
        "root_module": "PAFlexibleOutput.Main",
        "scope": "Only transitively imported PAFlexibleOutput modules; includes all new helpers.",
        "baseline": before,
        "replacement": after,
        "reductions_percent": {
            key: round(100 * (before["totals"][key] - after["totals"][key]) /
                       before["totals"][key], 2)
            for key in before["totals"]
        },
    }
    (ROOT / "evidence" / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    rows = []
    labels = {"physical_lines": "Physical lines", "active_lines": "Active lines",
              "utf8_bytes": "UTF-8 bytes"}
    for key, label in labels.items():
        rows.append(f"{label} & {before['totals'][key]:,} & {after['totals'][key]:,} & "
                    f"{result['reductions_percent'][key]:.1f}\\% \\\\")
    tex = "\n".join([
        r"\begin{center}", r"\begin{tabular}{lrrr}", r"\toprule",
        r"Main-module local import closure & Baseline & Replacement & Reduction\\",
        r"\midrule", *rows,
        f"Local modules & {before['module_count']} & {after['module_count']} & --- \\\\",
        r"\bottomrule", r"\end{tabular}", r"\end{center}",
    ]) + "\n"
    (ROOT / "report" / "metrics.tex").write_text(tex)
    print(json.dumps({"baseline": before["totals"], "replacement": after["totals"],
                      "reductions_percent": result["reductions_percent"]}, indent=2))


if __name__ == "__main__":
    main()
