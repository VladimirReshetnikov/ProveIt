# FlexibleOutput: search for the specification

This package proposes a shorter proof of the exact original theorem
`PAFlexibleOutput.exists_partrec_flexibleOutput` in ProveIt.

**Idea.** Search for PA refutations of

\[
U(c,n) := \forall y\,\bigl(\operatorname{universalGraph}(y,c,0)\leftrightarrow y=n\bigr),
\]

instead of refutations of the positive halting sentence alone. A real output
makes this full specification true in the standard model by `Part.mem_unique`.
PA soundness prevents a refutation from being returned. Completeness then
provides a model with exactly the desired `ValueIn` property directly.

The original `universalGraph`, `OutputIn`, `ValueIn`, and `outputSentence`
definitions are preserved. The chosen program still diverges on every
standard input. Both `some n` and `none` remain in the theorem. The witness
program can differ from the old construction, as permitted by the existential
statement.

## Contents

- `report/flexible_output_simplification.tex` and `.pdf`: mathematical proof,
  Lean implementation rationale, exact scope, limitations, and measurements.
  `metrics.tex` and `verification.tex` are included report inputs.
- `flexible_output.patch`: reviewable patch against the pinned baseline.
- `overlay/`: the modified and new Lean files at their repository paths.
- `baseline/`: original local Lean sources used for comparison, unchanged.
- `scripts/apply.sh`: checks that the patch applies, then applies it.
- `scripts/check_lean.sh`: serial build of the main module, compatibility
  module, exact-statement audit, dependency audit, and facade.
- `scripts/measure.py`: reproducible local import-closure measurements.
- `evidence/`: revisions, compiler logs, verification details, and measurements.

## Baseline and dependencies

| Component | Pinned revision |
| --- | --- |
| ProveIt | `410c820c4faa7620a19ce07f55f43c13e5fbb688` |
| Lean | `leanprover/lean4:v4.32.0` |
| Mathlib | `81a5d257c8e410db227a6665ed08f64fea08e997` |
| Foundation | `32e1a0956a8622fad067328ca1959729a7634428` |

No dependency source, toolchain pin, or Lake configuration is changed.
The archive does not bundle dependency repositories or compiler binaries.

## Applying and checking

Use a separate checkout of the pinned ProveIt revision. With Lean/Elan
installed and the original root package manifest present:

```bash
git checkout 410c820c4faa7620a19ce07f55f43c13e5fbb688
git submodule update --init lib/FormalizedFormalLogic-Foundation
lake exe cache get
bash /absolute/path/to/flexible_output_simplification/scripts/apply.sh "$PWD"
bash /absolute/path/to/flexible_output_simplification/scripts/check_lean.sh "$PWD"
```

The apply script runs `git apply --check` before modifying files. On a later
repository revision, inspect and rebase the patch normally rather than
overwriting changed files. The overlay contains the same proposed source
bytes as the patch.

To rebuild the report:

```bash
cd /absolute/path/to/flexible_output_simplification/report
latexmk -pdf -interaction=nonstopmode -halt-on-error flexible_output_simplification.tex
```

To reproduce the size table:

```bash
python3 /absolute/path/to/flexible_output_simplification/scripts/measure.py
```

## Main implementation changes

`Semantics.lean` contains the original value definitions, the fixed syntactic
template `uniqueOutputGraph`, its model semantics, and its standard correctness.

`Refutations.lean` generalizes the existing quotation/provability proof to
every fixed three-variable formula. Its new theorem is `refutationsREFor`.
The original `refutationsRE` remains a specialization. The formula being
searched need not itself be Sigma-one: provability of a sentence code is the
Sigma-one predicate used in the enumeration.

`Search.lean` presents the search as `Code →. Nat`, introducing the unused
ordinary input only at `fixed_point₂`. Bounded dovetailing is retained.
`exists_search` remains a compatibility wrapper for the old binary interface.

`Main.lean` proves the semantic theorem first, directly by recursion,
standard soundness, and completeness. The original endpoint wrapper and
sentence/satisfiability results follow as corollaries.

`Compatibility.lean` retains the original `PAModel`, `paBridge`,
`exists_searchImplementation`, `valueIn_of_models`, and
`fullySpecifiedMainClaim`. It imports the unchanged `Functionality` and
`MathlibAssembly` modules. The project facade imports `Compatibility`.

## API changes and limits

The main endpoint remains in `PAFlexibleOutput.Main` with its exact original
type. Definitions of its interpretation are checked by `rfl` in `Audit.lean`.
The six named main endpoints remain available from the project facade.

Clients that import only `PAFlexibleOutput.Main` and use one of the moved
legacy declarations must additionally import `PAFlexibleOutput.Compatibility`.
Four internal quotation helpers in `Refutations` now take a formula argument;
`searchWith` and its computability lemmas use the unary search interface.

The new main proof uses standard soundness of PA. It is not a replacement of
the original abstract theorem at the same consistency-only level of generality.
The original generic theorem and global functionality result are retained.

The reduction is measured for the transitive **local import closure of Main**,
including all new helper lemmas. It is not a claim that a two-line endpoint
wrapper got shorter, nor that retaining compatibility and audit files reduces
the total number of files in the repository.

The report and `evidence/verification.json` record the actual compiler results.
The dependency audit inspects proof bodies as well as types; it checks that
the main endpoint does not rely on the removed logical steps even when the
legacy modules are available in the environment.
