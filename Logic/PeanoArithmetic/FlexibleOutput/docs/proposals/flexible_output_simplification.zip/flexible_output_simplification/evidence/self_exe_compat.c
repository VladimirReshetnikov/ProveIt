#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
/* Lean's C++ executable discovery uses /proc/<getpid()>/exe. In this
   execution environment, only the equivalent /proc/self/exe alias resolves
   the current process. Redirect only that current-process path. */
ssize_t readlink(const char *restrict path, char *restrict buf, size_t bufsiz) {
    ssize_t (*orig)(const char*, char*, size_t)=dlsym(RTLD_NEXT,"readlink");
    char current[64];
    snprintf(current,sizeof current,"/proc/%ld/exe",(long)getpid());
    return orig(strcmp(path,current)==0?"/proc/self/exe":path,buf,bufsiz);
}
