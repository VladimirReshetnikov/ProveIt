# Verification environment

The baseline and replacement were checked with the official Linux Lean 4.32.0
release, compiler commit `8c9756b28d64dab099da31a4c09229a9e6a2ef35`.
Mathlib and Foundation use the exact revisions in `revisions.json`.

The dependency source files, compiler binaries, and proof checker were not
modified. Mathlib's matching cached build artifacts were obtained normally;
the required Foundation modules were built from the pinned source.

This hosted execution environment required a small operating-system path
compatibility shim. The official executable queries `/proc/<current pid>/exe`
to locate itself, but the environment exposes that same current-process path
through `/proc/self/exe`. The included `self_exe_compat.c` redirects only that
current-process `readlink` request to `/proc/self/exe`; all other calls retain
their original behavior. It does not change any Lean source, logical rule,
proof term, or kernel check. It is not needed on an ordinary Linux installation.

The environment script used during checking set the official compiler's `bin`
directory on PATH and loaded this shim. Verification used one target per Lake
invocation. The original baseline Main build completed successfully (1225 jobs),
followed by the replacement Main, Compatibility, Audit, DependencyAudit, and
facade builds. The facade build completed successfully (1230 jobs).

Build logs include pre-existing dependency and legacy-module linter warnings.
The new modules compiled without new diagnostics. All six endpoint axiom
reports are exactly `propext`, `Classical.choice`, and `Quot.sound`.

`verification.json` records successful checks and the complete list of eleven
excluded legacy declarations. `proof_dependencies.log` records the audit of
16,975 reachable constants, including their types and opaque proof bodies.
