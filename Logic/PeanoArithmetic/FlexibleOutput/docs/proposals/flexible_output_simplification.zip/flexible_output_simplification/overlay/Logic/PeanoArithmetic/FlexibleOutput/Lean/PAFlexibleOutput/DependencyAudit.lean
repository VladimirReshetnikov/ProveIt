import PAFlexibleOutput.Compatibility
import Lean.Util.FoldConsts

/-!
# Main-theorem dependency audit

Legacy declarations are deliberately imported. The check traverses the type and
value of every reachable constant, including opaque theorem bodies, starting from
`exists_partrec_flexibleOutput`. It rejects any use of the old global functionality
induction, finite-computation completeness bridge, or abstract assembly theorem.

This audits proof dependencies, not merely the import list. It adds no theorem or
axiom to the mathematical construction.
-/

open Lean in
run_cmd do
  let env ← getEnv
  let mut pending := [``PAFlexibleOutput.exists_partrec_flexibleOutput]
  let mut seen : NameSet := {}
  let mut count : Nat := 0
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    if !seen.contains name then
      seen := seen.insert name
      count := count + 1
      let some info := env.find? name
        | throwError "Dependency audit could not inspect {name}"
      for dep in info.getUsedConstantsAsSet do
        pending := dep :: pending
  let forbidden : Array Name := #[
    ``PAFlexibleOutput.finiteProofAdequacy,
    ``PAFlexibleOutput.codeAux_uniq,
    ``PAFlexibleOutput.code_uniq,
    ``PAFlexibleOutput.codeOfPartrec'_uniq,
    ``PAFlexibleOutput.universalGraph_uniq,
    ``PAFlexibleOutput.functionalityInPAModels,
    ``PAFlexibleOutput.valueIn_of_models,
    ``PAFlexibleOutput.paBridge,
    ``PAFlexibleOutput.exists_searchImplementation,
    ``FlexibleOutputMathlib.exists_program_with_arbitrary_possible_output,
    ``FlexibleOutputMathlib.exists_partial_function_with_arbitrary_possible_output]
  logInfo m!"Traversed {count} constants, including types and opaque bodies."
  for name in forbidden do
    if seen.contains name then
      throwError "Forbidden main-theorem dependency: {name}"
    logInfo m!"PASS: absent {name}"

#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
