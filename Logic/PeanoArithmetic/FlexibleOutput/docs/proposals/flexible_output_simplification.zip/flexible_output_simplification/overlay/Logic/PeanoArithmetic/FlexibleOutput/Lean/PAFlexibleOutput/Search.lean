import Mathlib.Computability.RE

/-!
# Unary search through a recursively enumerable relation

The search takes only the program code.  The unused ordinary input is introduced
at the single call to `Nat.Partrec.Code.fixed_point₂`, so constancy in that input
is definitional rather than a separate search specification.

The bounded dovetailing is retained: a semidecision procedure cannot safely be
searched sequentially, because an earlier negative candidate may diverge.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open Nat.Partrec Nat.Partrec.Code Computable

/-- Stage `k = (y, s)` tests output `y` for `s` steps. -/
def searchStage (cg c : Code) (k : ℕ) : Option ℕ :=
  (evaln k.unpair.2 cg (Encodable.encode (c, k.unpair.1))).map fun _ => k.unpair.1

/-- Return the output at the first successful dovetailing stage. -/
def searchWith (cg c : Code) : Part ℕ := Nat.rfindOpt (searchStage cg c)

theorem searchStage_computable (cg : Code) : Computable₂ (searchStage cg) := by
  have hev : Computable fun q : Code × ℕ =>
      evaln q.2.unpair.2 cg (Encodable.encode (q.1, q.2.unpair.1)) :=
    primrec_evaln.to_comp.comp
      (((snd.comp (unpair.comp snd)).pair (const cg)).pair
        (Computable.encode.comp (fst.pair (fst.comp (unpair.comp snd)))))
  exact Computable.option_map hev
    ((fst.comp (unpair.comp (snd.comp fst))).to₂)

theorem searchWith_partrec (cg : Code) : Partrec (searchWith cg) :=
  Partrec.rfindOpt (searchStage_computable cg)

/-- Effective choice of some witness of an r.e. relation, when one exists. -/
theorem exists_search_unary {R : Code × ℕ → Prop} (hR : REPred R) :
    ∃ search : Code →. ℕ, Partrec search ∧
      (∀ {c : Code} {y : ℕ}, y ∈ search c → R (c, y)) ∧
      (∀ {c : Code}, (∃ n, R (c, n)) → (search c).Dom) := by
  obtain ⟨cg, hcg⟩ := exists_code.1 hR
  have hdom : ∀ a : Code × ℕ, (eval cg (Encodable.encode a)).Dom ↔ R a := by
    intro a
    rw [hcg]
    simp only [Encodable.encodek, Part.coe_some, Part.bind_some]
    exact ⟨fun ⟨h, _⟩ => h, fun h => ⟨h, trivial⟩⟩
  refine ⟨searchWith cg, searchWith_partrec cg, ?_, ?_⟩
  · intro c y hy
    obtain ⟨k, hk⟩ := Nat.rfindOpt_spec hy
    obtain ⟨z, hz, rfl⟩ := Option.map_eq_some_iff.1 hk
    exact (hdom _).1 (Part.dom_iff_mem.2 ⟨z, evaln_sound hz⟩)
  · rintro c ⟨n, hn⟩
    obtain ⟨z, hz⟩ := Part.dom_iff_mem.1 ((hdom (c, n)).2 hn)
    obtain ⟨s, hs⟩ := evaln_complete.1 hz
    have hs' : evaln s cg (Encodable.encode (c, n)) = some z := hs
    apply Nat.rfindOpt_dom.2
    exact ⟨Nat.pair n s, n, by
      simp only [searchStage, Nat.unpair_pair, hs', Option.map_some, Option.mem_def]⟩

/-- Optional compatibility wrapper for the original binary-search interface. -/
theorem exists_search {R : Code × ℕ → Prop} (hR : REPred R) :
    ∃ search : Code → ℕ →. ℕ, Partrec₂ search ∧ (∀ c x, search c x = search c 0) ∧
      (∀ {c : Code} {x y : ℕ}, y ∈ search c x → R (c, y)) ∧
      (∀ {c : Code}, (∃ n, R (c, n)) → ∃ m, m ∈ search c 0) := by
  obtain ⟨search, hpart, hsound, hcomplete⟩ := exists_search_unary hR
  exact ⟨fun c _ => search c, hpart.comp Computable.fst, fun _ _ => rfl,
    fun h => hsound h, fun h => Part.dom_iff_mem.1 (hcomplete h)⟩

#print axioms exists_search_unary
#print axioms exists_search

end PAFlexibleOutput
