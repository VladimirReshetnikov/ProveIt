import PAFlexibleOutput.Statement
import Foundation.FirstOrder.Incompleteness.First

/-!
# Refutations of any fixed arithmetic template are recursively enumerable

`refutationsREFor φ` searches PA proofs of the negation of the instance
`φ(n, code, 0)`.  No complexity restriction is imposed on `φ`: provability
of a sentence code is a Sigma-one predicate even when the sentence is not
Sigma-one.  This permits a template expressing the full singleton-output
claim rather than only positive halting.

The four syntax helpers now take an explicit template argument `φ`.
The original public endpoint `refutationsRE` remains as a specialization.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic
open Bootstrapping Bootstrapping.Arithmetic

/-- The binary version of Foundation's Sigma-one-to-r.e. theorem. -/
lemma rePred_of_sigma1_rel {P : ℕ → ℕ → Prop} (h : 𝚺₁-Relation P) :
    REPred fun p : ℕ × ℕ => P p.1 p.2 := by
  rcases h with ⟨φ, hφ⟩
  have : REPred fun p : ℕ × ℕ ↦
      (Semiformula.Eval (p.1 ::ᵥ p.2 ::ᵥ List.Vector.nil).get id) φ.val :=
    (sigma1_re id (φ.sigma_prop)).comp
      (Primrec.to_comp <| Primrec.vector_cons.comp .fst <|
        Primrec.vector_cons.comp .snd <| .const _)
  exact this.of_eq <| by
    rintro ⟨a, b⟩
    simpa [List.Vector.cons_get, Matrix.empty_eq] using hφ ![a, b]

/-- Refutability is Sigma-one for every fixed formula, irrespective of its hierarchy. -/
lemma refutation_sigma1 (φ : ArithmeticSemisentence 3) (x : ℕ) :
    𝚺₁-Relation fun c y : ℕ ↦
      Bootstrapping.Provable 𝗣𝗔 (neg ℒₒᵣ <| subst ℒₒᵣ
        ?[numeral y, numeral c, numeral x] (⌜φ⌝ : ℕ)) := by
  definability

/-- Formal numeral substitution computes the code of the substituted sentence. -/
lemma subst_quote (φ : ArithmeticSemisentence 3) (c y x : ℕ) :
    subst ℒₒᵣ ?[numeral y, numeral c, numeral x] (⌜φ⌝ : ℕ)
      = ⌜(φ/[↑y, ↑c, ↑x] : ArithmeticSentence)⌝ := by
  have h := substNumerals_app_quote (V := ℕ) φ ![y, c, x]
  have hfun : (fun i : Fin 3 ↦ ((![y, c, x] i : ℕ) : Semiterm ℒₒᵣ Empty 0))
      = ![(↑y : Semiterm ℒₒᵣ Empty 0), ↑c, ↑x] := by
    funext i
    match i with
    | ⟨0, _⟩ => rfl
    | ⟨1, _⟩ => rfl
    | ⟨2, _⟩ => rfl
  rw [hfun] at h
  simp only [natCast_nat] at h
  exact h

lemma neg_subst_quote (φ : ArithmeticSemisentence 3) (c y x : ℕ) :
    neg ℒₒᵣ (subst ℒₒᵣ ?[numeral y, numeral c, numeral x] (⌜φ⌝ : ℕ))
      = ⌜(∼(φ/[↑y, ↑c, ↑x]) : ArithmeticSentence)⌝ := by
  rw [subst_quote]
  simp [Sentence.quote_def, Semiformula.quote_def]

/-- Arithmetized provability of this code in Nat is actual PA provability. -/
lemma provable_neg_iff (φ : ArithmeticSemisentence 3) (c : Code) (x y : ℕ) :
    Bootstrapping.Provable 𝗣𝗔 (neg ℒₒᵣ <| subst ℒₒᵣ
        ?[numeral y, numeral (Encodable.encode c), numeral x] (⌜φ⌝ : ℕ))
      ↔ 𝗣𝗔 ⊢ ∼(φ/[↑y, ↑(Encodable.encode c), ↑x] : ArithmeticSentence) := by
  rw [neg_subst_quote]
  exact provable_iff_provable

/-- Refutations of instances of any fixed three-variable template are r.e. -/
theorem refutationsREFor (φ : ArithmeticSemisentence 3) :
    REPred (fun p : Code × ℕ =>
      𝗣𝗔 ⊢ ∼(φ/[↑p.2, ↑(Encodable.encode p.1), ↑(0 : ℕ)] : ArithmeticSentence)) := by
  have h := rePred_of_sigma1_rel (refutation_sigma1 φ 0)
  have hc : Computable fun p : Code × ℕ => (Encodable.encode p.1, p.2) :=
    (Computable.encode.comp Computable.fst).pair Computable.snd
  exact (h.comp hc).of_eq fun p => provable_neg_iff φ p.1 0 p.2

/-- Compatibility specialization for the original halting template. -/
theorem refutationsRE : RefutationsRE :=
  refutationsREFor universalGraph

#print axioms refutationsREFor
#print axioms refutationsRE

end PAFlexibleOutput
