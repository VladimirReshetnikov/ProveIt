import PAFlexibleOutput.Compatibility

/-!
# Endpoint and interpretation audit

These checks repeat the original theorem types literally, rather than relying on
an alternative proposition with a similar name. The interpretation of the original
universal graph is also checked by definitional equality. No new assumptions are
introduced by this audit.
-/

set_option autoImplicit false

namespace PAFlexibleOutput.Audit

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o :=
  exists_partrec_flexibleOutput

example :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o :=
  flexibleOutputValue

example :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        M↓[ℒₒᵣ] ⊧ outputSentence e o :=
  flexibleOutput

example : StrongClaim := strongClaim
example : MainClaim := mainClaim
example : FullySpecifiedMainClaim := fullySpecifiedMainClaim

example (M : Type*) [ORingStructure M] (e : Code) (y : M) :
    OutputIn M e y =
      (M ⊧/![y, ORingStructure.numeral (Encodable.encode e),
        ORingStructure.numeral 0] universalGraph) := rfl

example (M : Type*) [ORingStructure M] (e : Code) (n : ℕ) :
    ValueIn M e (some n) =
      (∀ y : M, OutputIn M e y ↔ y = ORingStructure.numeral n) := rfl

example (M : Type*) [ORingStructure M] (e : Code) :
    ValueIn M e none = (∀ y : M, ¬ OutputIn M e y) := rfl

example (e : Code) (n : ℕ) : outputSentence e (some n) = haltSentence e 0 n := rfl
example (e : Code) : outputSentence e none = divergeSentence e 0 := rfl

#check flexibleOutput
#check flexibleOutputValue
#check exists_partrec_flexibleOutput
#check strongClaim
#check mainClaim
#check fullySpecifiedMainClaim

#print axioms flexibleOutput
#print axioms flexibleOutputValue
#print axioms exists_partrec_flexibleOutput
#print axioms strongClaim
#print axioms mainClaim
#print axioms fullySpecifiedMainClaim

end PAFlexibleOutput.Audit
