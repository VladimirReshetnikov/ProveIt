import PAFlexibleOutput.Semantics
import PAFlexibleOutput.Refutations
import PAFlexibleOutput.Search

/-!
# A divergent program whose every output is possible in a model of `𝗣𝗔`

Search for PA refutations of the *whole unique-output specification*, rather than
just the halting sentence. If the fixed-point program actually returns `n`, standard
correctness and determinism of `Part` make that specification true in `ℕ`, contrary
to soundness of its PA refutation. Thus the program diverges and no specification
is refuted. Completeness gives a model of each unique-output specification directly.

This proves the original semantic endpoint with the original `universalGraph`.
It does not require that this graph be functional in every PA model. That separate,
stronger uniform functionality theorem remains available in `Functionality`;
`Compatibility` collects the endpoints that explicitly use it.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

/-- The sentence "the value of program `e` on input `0` is `o`": the halting sentence for
`o = some n`, the divergence sentence for `o = none`. -/
noncomputable def outputSentence (e : Code) : Option ℕ → ArithmeticSentence
  | some n => haltSentence e 0 n
  | none => divergeSentence e 0

/-- **Main theorem, semantic form.** There is a program `e` that diverges on every input, such
that for every `o : Option ℕ` there is a model of `𝗣𝗔` in which the value of `e` on input `0` is
`o`. -/
theorem flexibleOutputValue :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o := by
  obtain ⟨search, hpart, hsound, hcomplete⟩ :=
    exists_search_unary (refutationsREFor uniqueOutputGraph)
  obtain ⟨e, he⟩ := Nat.Partrec.Code.fixed_point₂
    (f := fun c _ => search c) (hpart.comp Computable.fst)
  have hnone : ¬ (search e).Dom := by
    intro h
    obtain ⟨n, hn⟩ := Part.dom_iff_mem.mp h
    have hnot : ℕ↓[ℒₒᵣ] ⊧ ∼(uniqueOutputSentence e 0 n) :=
      models_of_provable (M := ℕ) inferInstance (hsound hn)
    exact Semantics.Not.models_not.mp hnot
      ((standardUniqueOutput e 0 n).mpr (by simpa only [he] using hn))
  have hdiv : ∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom :=
    fun x => by simpa only [he] using hnone
  refine ⟨e, Nat.Partrec.Code.eval_part.comp (Computable.const e) Computable.id, hdiv, ?_⟩
  rintro (_ | n)
  · exact ⟨ℕ, inferInstance, inferInstance, standardValueNone e (hdiv 0)⟩
  · by_contra hno
    have href : 𝗣𝗔 ⊢ ∼(uniqueOutputSentence e 0 n) :=
      Arithmetic.complete.{0} 𝗣𝗔 (∼(uniqueOutputSentence e 0 n)) fun M _ hM => by
        haveI : M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := models_of_subtheory (U := 𝗣𝗔) hM
        exact Semantics.Not.models_not.mpr fun hp =>
          hno ⟨M, inferInstance, hM, (models_uniqueOutputSentence e n).mp hp⟩
    exact hnone (hcomplete ⟨n, href⟩)

/-- **Main theorem.** There is a partial recursive function `f : ℕ →. ℕ` such that for every
`o`, a natural number or `none`, the statement "`f 0 = o`" holds in some model of `𝗣𝗔`. The
function is given by a program `e`, and the statement is read inside the model through the
halting formula of that program. -/
theorem exists_partrec_flexibleOutput :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o := by
  obtain ⟨e, hpart, -, hmod⟩ := flexibleOutputValue
  exact ⟨Nat.Partrec.Code.eval e, hpart, e, rfl, hmod⟩

/-- **Main theorem, sentence form.** There is a program `e` that diverges on every input, such
that for every `o : Option ℕ` some model of `𝗣𝗔` satisfies "the value of `e` on input `0` is
`o`". -/
theorem flexibleOutput :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        M↓[ℒₒᵣ] ⊧ outputSentence e o := by
  obtain ⟨e, hpart, hdiv, hmod⟩ := flexibleOutputValue
  refine ⟨e, hpart, hdiv, fun o => ?_⟩
  obtain ⟨M, inst, hM, ho⟩ := hmod o
  haveI : M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := models_of_subtheory (U := 𝗣𝗔) hM
  refine ⟨M, inst, hM, ?_⟩
  cases o with
  | none =>
    apply (models_divergeSentence e 0).mpr
    rintro ⟨y, hy⟩
    exact ho y ((outputIn_iff e y).mpr hy)
  | some n =>
    apply (models_haltSentence e 0 n).mpr
    have hn := (outputIn_iff e (ORingStructure.numeral n)).mp ((ho _).mpr rfl)
    simpa only [numeral_eq_natCast_app] using hn

/-- `Statement.StrongClaim`: the program diverges on every input, and every halting sentence
for input `0` is satisfiable together with `𝗣𝗔`. -/
theorem strongClaim : StrongClaim := by
  obtain ⟨e, -, hdiv, hmod⟩ := flexibleOutput
  refine ⟨e, hdiv, fun n => ?_⟩
  obtain ⟨M, inst, hM, hn⟩ := hmod (some n)
  exact satisfiable_intro M (Semantics.ModelsSet.insert_iff.mpr ⟨hn, hM⟩)

/-- `Statement.MainClaim`. -/
theorem mainClaim : MainClaim := by
  obtain ⟨e, hdiv, hsat⟩ := strongClaim
  exact ⟨e, hdiv 0, hsat⟩

#print axioms flexibleOutputValue
#print axioms exists_partrec_flexibleOutput
#print axioms flexibleOutput
#print axioms strongClaim
#print axioms mainClaim

end PAFlexibleOutput
