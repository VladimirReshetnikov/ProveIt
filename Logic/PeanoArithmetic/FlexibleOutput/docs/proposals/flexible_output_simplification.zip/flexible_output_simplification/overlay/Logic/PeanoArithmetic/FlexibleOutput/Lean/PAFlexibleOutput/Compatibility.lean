import PAFlexibleOutput.Main
import PAFlexibleOutput.Functionality
import PAFlexibleOutput.MathlibAssembly

/-!
# Compatibility with the original helper API

The concrete endpoint in `Main` is independent of the global functionality proof
and of the abstract arithmetic bridge. This module preserves the original helper
names for callers that need them, together with `fullySpecifiedMainClaim`, whose
statement explicitly asks for functionality in every PA model.

Only the legacy bridge below uses `finiteProofAdequacy`; it is not on the new
main theorem's proof path. The definitions and proofs below are copied from the
baseline `Main.lean` at commit 410c820c4faa7620a19ce07f55f43c13e5fbb688.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

/-! ## The arithmetic bridge -/

/-- A model of `𝗣𝗔` with a small carrier, bundled. -/
structure PAModel : Type 1 where
  /-- The carrier. -/
  carrier : Type
  [oring : ORingStructure carrier]
  [models : carrier↓[ℒₒᵣ] ⊧* 𝗣𝗔]

attribute [instance] PAModel.oring PAModel.models

/-- `𝗣𝗔` as an instance of the abstract bridge of `MathlibAssembly`. -/
noncomputable def paBridge : FlexibleOutputMathlib.ArithmeticBridge.{0, 1} where
  Sentence := ArithmeticSentence
  Model := PAModel
  halts := haltSentence
  neg := fun σ => ∼σ
  provable := fun σ => 𝗣𝗔 ⊢ σ
  isModel := fun _ => True
  realizes := fun M σ => M.carrier↓[ℒₒᵣ] ⊧ σ
  consistent := fun p hp hnp => by
    have h₁ : ℕ↓[ℒₒᵣ] ⊧ p := models_of_provable (M := ℕ) inferInstance hp
    have h₂ : ℕ↓[ℒₒᵣ] ⊧ ∼p := models_of_provable (M := ℕ) inferInstance hnp
    exact Semantics.Not.models_not.mp h₂ h₁
  finiteComputation := fun h => finiteProofAdequacy _ _ _ h
  modelOfUnrefuted := fun p h => by
    by_contra hno
    refine h (Arithmetic.complete.{0} 𝗣𝗔 (∼p) fun M _ _ => ?_)
    exact Semantics.Not.models_not.mpr fun hp => hno ⟨⟨M⟩, trivial, hp⟩

/-- The proof search: a partial recursive function that returns an output refuted by `𝗣𝗔`
whenever there is one. -/
theorem exists_searchImplementation :
    Nonempty (FlexibleOutputMathlib.SearchImplementation paBridge) := by
  have hR : REPred (fun p : Code × ℕ => 𝗣𝗔 ⊢ ∼(haltSentence p.1 0 p.2)) := refutationsRE
  obtain ⟨search, hpart, hign, hsound, hcomplete⟩ := exists_search hR
  exact ⟨{
    search := search
    partialRecursive := hpart
    ignoresInput := hign
    returnsRefutation := fun h => hsound h
    findsRefutation := fun h => hcomplete h }⟩

section

variable {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]

/-- A structure that satisfies `outputSentence e o` computes the value `o`. The uniqueness of
the output is the functionality of the halting formula. -/
theorem valueIn_of_models (e : Code) (o : Option ℕ) (h : M↓[ℒₒᵣ] ⊧ outputSentence e o) :
    ValueIn M e o := by
  cases o with
  | none =>
    show ∀ y : M, ¬ OutputIn M e y
    intro y hy
    exact (models_divergeSentence e 0).mp h ⟨y, (outputIn_iff e y).mp hy⟩
  | some n =>
    show ∀ y : M, OutputIn M e y ↔ y = ORingStructure.numeral n
    intro y
    have hn := (models_haltSentence e 0 n).mp h
    rw [numeral_eq_natCast_app]
    constructor
    · intro hy
      exact universalGraph_uniq ((outputIn_iff e y).mp hy) hn
    · rintro rfl
      exact (outputIn_iff e _).mpr hn

end

/-- `Statement.FullySpecifiedMainClaim`. -/
theorem fullySpecifiedMainClaim : FullySpecifiedMainClaim :=
  ⟨standardCorrectness, functionalityInPAModels, mainClaim⟩

#print axioms fullySpecifiedMainClaim

end PAFlexibleOutput
