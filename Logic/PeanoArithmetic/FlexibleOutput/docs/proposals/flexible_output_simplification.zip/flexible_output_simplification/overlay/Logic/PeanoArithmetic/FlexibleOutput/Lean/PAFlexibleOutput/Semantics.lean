import PAFlexibleOutput.Arithmetization

/-!
# Search for the complete output specification

`OutputIn` and `ValueIn` are the original definitions, unchanged.  The new
syntactic template `uniqueOutputGraph` expresses `ValueIn ... (some n)`.
Its standard correctness uses only uniqueness of membership in `Part`.
No functionality theorem about nonstandard models is needed here.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

/-- The original graph interpretation. -/
def OutputIn (M : Type*) [ORingStructure M] (e : Code) (y : M) : Prop :=
  M ⊧/![y, ORingStructure.numeral (Encodable.encode e), ORingStructure.numeral 0] universalGraph

/-- The original exact-value interpretation, including divergence. -/
def ValueIn (M : Type*) [ORingStructure M] (e : Code) : Option ℕ → Prop
  | some n => ∀ y : M, OutputIn M e y ↔ y = ORingStructure.numeral n
  | none => ∀ y : M, ¬ OutputIn M e y

/-- Variables are `[n, program, input]`; under `∀ y` they are `[y,n,program,input]`. -/
noncomputable def uniqueOutputGraph : ArithmeticSemisentence 3 :=
  ∀⁰ ((universalGraph/[#0, #2, #3] : ArithmeticSemisentence 4) 🡘 “#0 = #1”)

/-- The complete output specification, used as the target of proof search. -/
noncomputable def uniqueOutputSentence (c : Code) (x n : ℕ) : ArithmeticSentence :=
  uniqueOutputGraph/[↑n, ↑(Encodable.encode c), ↑x]

section

variable {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]

lemma outputIn_iff (e : Code) (y : M) :
    OutputIn M e y ↔
      (M ⊧/![y, ((Encodable.encode e : ℕ) : M), ((0 : ℕ) : M)] universalGraph) := by
  unfold OutputIn
  rw [numeral_eq_natCast_app, numeral_eq_natCast_app]

theorem models_uniqueOutputSentence_iff (c : Code) (x n : ℕ) :
    (M↓[ℒₒᵣ] ⊧ uniqueOutputSentence c x n) ↔
      ∀ y : M, (M ⊧/![y, ((Encodable.encode c : ℕ) : M), (x : M)] universalGraph) ↔
        y = (n : M) := by
  simp only [uniqueOutputSentence, models_iff, Semiformula.eval_substs]
  simp [uniqueOutputGraph, Semiformula.eval_substs, numeral_eq_natCast_app,
    Function.comp_def, Matrix.comp_vecCons', Matrix.empty_eq, Matrix.constant_eq_singleton]

theorem models_uniqueOutputSentence (c : Code) (n : ℕ) :
    (M↓[ℒₒᵣ] ⊧ uniqueOutputSentence c 0 n) ↔ ValueIn M c (some n) := by
  rw [models_uniqueOutputSentence_iff]
  simp [ValueIn, OutputIn, numeral_eq_natCast_app]

end

/-- A real computation satisfies the complete specification in the standard model. -/
theorem standardUniqueOutput (c : Code) (x n : ℕ) :
    (ℕ↓[ℒₒᵣ] ⊧ uniqueOutputSentence c x n) ↔ n ∈ Nat.Partrec.Code.eval c x := by
  simp only [models_uniqueOutputSentence_iff, natCast_nat, universalGraph_nat]
  constructor
  · intro h
    exact (h n).mpr rfl
  · intro hn y
    exact ⟨fun hy => Part.mem_unique hy hn, fun h => h.symm ▸ hn⟩

theorem standardValueNone (e : Code) (h : ¬ (Nat.Partrec.Code.eval e 0).Dom) :
    ValueIn ℕ e none := by
  intro y hy
  exact (models_divergeSentence e 0).mp ((standardDivergence e 0).mpr h)
    ⟨y, (outputIn_iff e y).mp hy⟩

end PAFlexibleOutput
