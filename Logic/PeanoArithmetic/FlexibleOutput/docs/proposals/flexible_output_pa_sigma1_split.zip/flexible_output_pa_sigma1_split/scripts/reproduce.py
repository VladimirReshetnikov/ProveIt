#!/usr/bin/env python3
"""Check or apply the PA/I-Sigma-one split in an exact pinned checkout.

Default: read-only checks. Use --apply --build in a disposable checkout to
apply both patches, build the proof and compatibility client, and run audits.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PROVEIT = "0539de6333059f62e687657a841f68713a4c3018"
FOUNDATION = "32e1a0956a8622fad067328ca1959729a7634428"


def revision(path):
    return subprocess.check_output(
        ["git", "-C", str(path), "rev-parse", "HEAD"], text=True
    ).strip()


def run(args, cwd, env=None):
    print("+", " ".join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), cwd=cwd, env=env, check=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("repo", type=Path)
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--build", action="store_true")
    args = ap.parse_args()
    repo = args.repo.resolve()
    foundation = repo / "lib/FormalizedFormalLogic-Foundation"
    if revision(repo) != PROVEIT or revision(foundation) != FOUNDATION:
        raise SystemExit("Repository revisions differ from the pinned baseline.")
    states = []
    for item in json.loads((ROOT / "validation/source_hashes.json").read_text()):
        source = item["source"]
        is_foundation = source.startswith("sources/Foundation/")
        path = (foundation if is_foundation else repo) / source.removeprefix(
            "sources/Foundation/" if is_foundation else "sources/ProveIt/"
        )
        digest = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
        if digest == item["candidate_sha256"]:
            states.append("candidate")
        elif digest == item["baseline_sha256"] and path.exists() == item["baseline_exists"]:
            states.append("baseline")
        else:
            raise SystemExit(f"Unrecognized local state at {path}; no files modified.")
    if len(set(states)) != 1:
        raise SystemExit("Expected a wholly baseline or wholly patched state.")
    patched = states[0] == "candidate"
    patches = [(foundation, ROOT / "patches/foundation.patch"),
               (repo, ROOT / "patches/proveit.patch")]
    if not patched:
        for cwd, patch in patches:
            run(["git", "apply", "--check", patch], cwd)
        if args.apply:
            for cwd, patch in patches:
                run(["git", "apply", patch], cwd)
            patched = True
    if args.build:
        if not patched:
            raise SystemExit("Use --apply --build to build from the baseline.")
        env = os.environ.copy()
        env.setdefault("LAKE_JOBS", "1")
        env.setdefault("LEAN_NUM_THREADS", "2")
        for target in ["+PAFlexibleOutput.Main", "+PAFlexibleOutput",
                       "+Foundation.FirstOrder.Incompleteness.Examples"]:
            run(["lake", "build", target], repo, env)
        for audit in ["Audit.lean", "Compatibility.lean", "DeclarationCatalog.lean"]:
            run(["lake", "env", "lean", ROOT / "validation" / audit], repo, env)
        run([sys.executable, ROOT / "scripts/audit_dependencies.py",
             "--repo", repo, "--foundation", foundation,
             "--out", ROOT / "validation/reproduced_closure.json"], repo, env)
    print("Candidate verified." if patched else "Baseline and both patches verified; no files modified.")


if __name__ == "__main__":
    main()
