#!/usr/bin/env python3
"""Audit local Lean import closures, with nested-comment-aware line counts.

External package imports (Mathlib, Lean, Batteries, Aesop, Qq, etc.) form
the boundary. Foundation is included because ProveIt pins it as a git
submodule under lib/. The script reports this boundary explicitly.
"""
from pathlib import Path
import argparse, json, re, subprocess, tomllib

def code_only(s):
    out=[]; i=0; depth=0; string=False
    while i<len(s):
        if depth:
            if s.startswith('/-',i): depth+=1;out.extend('  ');i+=2
            elif s.startswith('-/',i):depth-=1;out.extend('  ');i+=2
            else:out.append('\n' if s[i]=='\n' else ' ');i+=1
        elif string:
            out.append(s[i])
            if s[i]=='\\' and i+1<len(s):out.append(s[i+1]);i+=2
            else:
                if s[i]=='"':string=False
                i+=1
        elif s.startswith('/-',i):depth=1;out.extend('  ');i+=2
        elif s.startswith('--',i):
            j=s.find('\n',i)
            if j<0:j=len(s)
            out.extend(' '*(j-i));i=j
        else:
            string=s[i]=='"';out.append(s[i]);i+=1
    return ''.join(out)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--foundation',type=Path,required=True)
    ap.add_argument('--roots',nargs='+',default=['PAFlexibleOutput.Main'])
    ap.add_argument('--overlay',type=Path,help='Optional changed source files, by module path')
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    libs=tomllib.loads((args.repo/'lakefile.toml').read_text())['lean_lib']
    paths={l['name']:args.repo/l.get('srcDir','.') for l in libs}
    paths['Foundation']=args.foundation
    rows={};edges={};external=set()
    def visit(mod):
        if mod in rows:return
        source=paths.get(mod.split('.')[0])
        if source is None:external.add(mod);return
        p=source/(mod.replace('.','/')+'.lean')
        if args.overlay:
            overlay=args.overlay/(mod.replace('.','/')+'.lean')
            if overlay.is_file():p=overlay
        if not p.exists():raise FileNotFoundError(str(p))
        raw=p.read_bytes();txt=raw.decode();code=code_only(txt)
        imports=[]
        for match in re.finditer(r'^\s*(?:(?:public|private|meta)\s+)*import\s+([^\n]+)',code,re.M):
            imports.extend(match.group(1).split())
        row={'module':mod,'path':str(p),'group':'foundation_submodule' if mod.startswith('Foundation.') else 'main_repository','lines':len(txt.splitlines()),'nonblank_lines':sum(bool(x.strip()) for x in txt.splitlines()),'code_lines':sum(bool(x.strip()) for x in code.splitlines()),'bytes':len(raw),'imports':imports}
        rows[mod]=row;edges[mod]=imports
        for target in imports:visit(target)
    for root in args.roots:visit(root)
    groups={}
    for group in ['main_repository','foundation_submodule','combined']:
        rs=[r for r in rows.values() if group=='combined' or r['group']==group]
        groups[group]={'modules':len(rs),**{key:sum(r[key] for r in rs) for key in ['lines','nonblank_lines','code_lines','bytes']}}
    def commit(p):return subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
    result={'roots':args.roots,'overlay':str(args.overlay) if args.overlay else None,'repository_commit':commit(args.repo),'foundation_commit':commit(args.foundation),'groups':groups,'external_import_boundary':sorted(external),'modules':sorted(rows.values(),key=lambda r:r['module'])}
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'groups':groups,'external_import_count':len(external),'largest_modules':sorted(rows.values(),key=lambda r:r['lines'],reverse=True)[:20]},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
