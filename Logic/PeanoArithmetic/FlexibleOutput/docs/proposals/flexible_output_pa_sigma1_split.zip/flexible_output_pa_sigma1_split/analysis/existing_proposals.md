# Existing proposals and the novelty of the PA/IΣ₁ module split

## Scope and integrity

This audit covers every archive under
`Logic/PeanoArithmetic/FlexibleOutput/docs/proposals` at ProveIt commit
[`0539de6333059f62e687657a841f68713a4c3018`](https://github.com/VladimirReshetnikov/ProveIt/tree/0539de6333059f62e687657a841f68713a4c3018/Logic/PeanoArithmetic/FlexibleOutput/docs/proposals).
The reports, READMEs, proposed Lean changes, and relevant research descriptions
were inspected. Archive contents were checked against the pinned Git blobs;
**all 316 entries in their seven checksum manifests match**. Full archive
SHA-256 hashes, blob identifiers, baselines, and verification results are in
`proposal_archive_integrity.json`.

### The seven archived proposals

The descriptions below summarize each archive's contribution; they are not
claims that the current package independently reran its historical builds.

| ID | Archive | Its baseline | Principal existing ideas | Checksum matches |
| --- | --- | --- | --- | ---: |
| P1 | `flexible_output_simplification (2).zip` | `410c820c4f` | Direct fixed-point proof using consistency and finite-computation adequacy; remove bridge adapters; simplify functionality and quotation proofs | 34/34 |
| P2 | `flexible_output_simplification.zip` | `410c820c4f` | Search refutations of the complete unique-output specification; use standard soundness; move global functionality to compatibility support; unary selector interface | 45/45 |
| P3 | `flexible_output_simplification_2026-11-09.zip` | `410c820c4f` | Complete-value search with optional global-functionality audit; alternative direct soundness proof retaining ordinary halting search | 49/49 |
| P4 | `pa_flexible_output_simplification.zip` | `410c820c4f` | Local functionality, search, quotation, and generic-assembly cleanups; optional direct PA proof | 33/33 |
| P5 | `flexible_output_simplification (1).zip` | `7142f7f52b` | Encode the refutation query once and apply unary `re_iff_sigma1`; remove the ternary/vector adapter; additional local cleanups | 41/41 |
| P6 | `flexible_output_simplification_7142f7f_verified.zip` | `7142f7f52b` | Partial-value API simplifications in Search and Main; quotation by congruence; whole-goal normalization in composition | 62/62 |
| P7 | `flexible_output_dependency_simplification.zip` | `5ad98b5a50` | Share a selector across FlexibleOutput and Foundation projection; eliminate the separate scan/monotonicity implementation; prune incompleteness imports through D1 | 52/52 |
| **Total** | **Seven archives** | | | **316/316** |

The first four use the older bridge-based development. P5 and P6 target the
later direct proof with flexibility at every standard input. P7 begins from
the same five-module proof architecture. These different baselines must not
be conflated when interpreting their reported savings.

## Credit for ideas already present

The earlier archives collectively propose direct PA assembly, complete-value
refutation search, generic formula-template enumerability, unary or generic
selectors, optional functionality modules, and several semantic-normalization
and quotation cleanups. Their future-work sections also suggest upstream
functionality, a reusable selector, and a relation-level diagonal interface.

P7 makes a substantial additional contribution inside Foundation. It moves
the existing selector to `Foundation.Vorspiel.PartrecSelector`, uses it to
implement typed uniform-output projection, and derives natural-number
projection as a specialization. This removes the separate bounded-prefix
scan, its monotonicity proof, and the original typed encoding-transport proof.

P7 also replaces the First/Second incompleteness imports of
`InductionSchemeDelta1` with D1. Its refutation module uses direct quotation
and a proved equality-subtheory instance, allowing further modules to leave
the import closure. The present package credits that work as an existing
proposal. Its contribution is the additional split described next.

P7's research section already discusses direct certified representation,
padded induction certificates with an alternative Δ₁ recognizer, and external
finite-proof enumeration. Those directions are also outside this package's
novelty claim.

## The distinct proposal in this package

**None of the seven inspected archives proposes or implements separating
unrestricted-induction/PA axiom definability from syntactic Σ₁ recognition and
IΣ₁ axiom definability within the existing `InductionSchemeDelta1` module.**

The current package introduces this dependency boundary:

- `InductionSchemePA` contains the unrestricted induction development and
  the existing `PA_delta1Definable` instance.
- `InductionSchemeSigma1` imports that module and adds the `IsSigma1`
  recognizer and IΣ₁-specific definability development.
- `InductionSchemeDelta1` remains a compatibility entry point, re-exporting
  the combined interface through `InductionSchemeSigma1`.
- FlexibleOutput's `Provability` module imports `InductionSchemePA` directly.

This preserves the exact PA theory, its definability instance, the arithmetic
graph, and the theorem statements. It reorganizes existing declarations with
unchanged mathematical proof bodies. The retained compatibility import makes
the IΣ₁-specific results available to clients that need them.

The distinguishing observation is that **using models of IΣ₁ does not require
importing a theorem that arithmetically recognizes the axioms of IΣ₁**. The
coding arguments can retain their IΣ₁ model hypotheses while FlexibleOutput
uses only the PA axiom-definability instance.

## Direct evidence that P7 does not already make this split

P1–P6 do not edit Foundation. P7 does edit `InductionSchemeDelta1`, but its
report expressly describes compiling the entire module after changing its
imports, without changing definitions or theorem proofs.

An independent byte comparison confirms that P7's baseline and replacement
`InductionSchemeDelta1` files are identical after removing public-import lines.
The only change is two imports replaced by one; the file goes from 1,386 to
1,385 physical lines. The comparison and normalized SHA-256 are recorded in
`seventh_induction_changes.json`.

The present extraction instead separates 542 original physical lines into
the IΣ₁-specific module, with zero mathematical proof-body changes. Exact
block provenance is in `extraction_provenance.json`. This is a finer boundary
than P7's D1 import cut and can be composed with it; the composition inventories
measure the additional effect against P7's patched closure.

## What the reduction means

This is a reduction in the **source imported transitively by the requested
proof**, including Foundation's in-repository submodule. It does not erase
the moved declarations from the repository. They remain in their dedicated
module and are available through the compatibility entry point.

The baseline constant-reachability audit found `IsSigma1`, `isSigma1`, and
`ISigma1_delta1Definable` imported but absent from all three endpoint proof
closures; `PA_delta1Definable` was reachable as a positive control. See
`../validation/ExactBaselineSigma1Reachability.log`.

Consequently, this package does not claim to remove those logical inference
steps from the kernel proof, reduce its proof-term size, or improve measured
elaboration time. Its verified benefit is a smaller and more accurately
organized import dependency: readers and builds of FlexibleOutput need the
PA development without the separate IΣ₁-recognition development. The closure
inventories count every new file actually imported by the measured root and
distinguish this additional saving from the existing proposals' savings.
