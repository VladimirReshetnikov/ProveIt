# Novelty check: separate PA definability from I-Sigma-one axiom recognition

## Conclusion

The following specific proposal is absent from all seven archived reports,
READMEs, research descriptions, and Lean patches inspected at repository head
`0539de6333059f62e687657a841f68713a4c3018`:

> Split `InductionSchemeDelta1` into a module containing unrestricted
> induction/PA axiom definability and a module containing the `IsSigma1`
> syntactic recognizer and I-Sigma-one axiom definability. Keep the former
> module name as a compatibility re-export of both, but have FlexibleOutput
> import only the PA module.

This is a finer dependency boundary than the seventh archive's D1 import cut.
It preserves the exact existing arithmetic theory and definability instance;
it does not replace PA by a new padded axiom presentation, weaken the
definability class, or change the proof-search target.

## Evidence

The first six archives modify only PAFlexibleOutput sources. None edits
Foundation or proposes separating PA and I-Sigma-one schema-recognition code.

The seventh archive modifies Foundation's `InductionSchemeDelta1` only by
replacing public imports of First/Second incompleteness with a public D1
import. Its report explicitly states that the entire module was compiled and
no definitions or theorem proofs in it were modified. A byte comparison after
removing public import lines confirms the baseline and replacement are
otherwise identical; the comparison is recorded in
`seventh_induction_changes.json`.

Its research suggestions are different:

- Direct certified compilation of representing formulas.
- A padded induction-body presentation with a new Delta-one recognizer.
- External enumeration of proof certificates.

No source proposes extracting the `IsSigma1` recognizer or the
I-Sigma-one-specific definability bridges from the exact existing module.

## Claim boundary for the resulting report

Credit the seventh archive for the shared selector/projection work and D1
import pruning. Claim the additional PA-versus-I-Sigma-one module split as
new. Quantify the additional imported-source reduction against the seventh
archive's patched baseline, including every new module and compatibility
wrapper actually imported by the measured root.

The relevant semantic distinction is:

- The main proof uses arithmetic models satisfying I-Sigma-one and the
  definitions and standard-model properties of PA.
- This does not automatically mean it uses an arithmetic predicate recognizing
  the axioms of I-Sigma-one or a `Theory.Delta1` instance for that theory.

The implementation must establish the second point through its actual build
and dependency audit. If the I-Sigma-one-specific declarations were already
absent from the theorem's proof-constant closure, then their removal is an
imported-source reduction, not a deletion of logical inference steps from the
kernel proof. Preserve that distinction in the results.
