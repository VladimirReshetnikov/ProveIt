import Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1

/- Enumerate all non-private declarations owned by the old or new modules.
   Expression hashes compare public types; proof values are intentionally not hashed. -/
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let owner := (env.header.moduleNames.getD idx.toNat Name.anonymous).toString
      if owner.startsWith "Foundation.FirstOrder.Incompleteness.InductionScheme" &&
          !(name.toString.startsWith "_private.") then
        logInfo m!"DECL {name} TYPE_HASH {info.type.hash}"
