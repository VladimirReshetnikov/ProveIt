import PAFlexibleOutput.Main

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for mod in env.header.moduleNames do
    let s := mod.toString
    if s.startsWith "Foundation." || s.startsWith "PAFlexibleOutput." then
      logInfo m!"LOCAL_IMPORT {mod}"
  for name in #[`LO.FirstOrder.Arithmetic.Bootstrapping.IsSigma1,
      `LO.FirstOrder.Arithmetic.Bootstrapping.isSigma1,
      `LO.FirstOrder.Arithmetic.ISigma1_delta1Definable] do
    if env.contains name then
      throwError "Unexpected IΣ₁-axiomatization declaration: {name}"
  unless env.contains `LO.FirstOrder.Arithmetic.PA_delta1Definable do
    throwError "Required PA axiom-definability instance is absent"

#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.universalGraph_sigma_one
#print axioms PAFlexibleOutput.valueIn_of_models
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.exists_selector
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
#print axioms LO.FirstOrder.Arithmetic.PA_delta1Definable
