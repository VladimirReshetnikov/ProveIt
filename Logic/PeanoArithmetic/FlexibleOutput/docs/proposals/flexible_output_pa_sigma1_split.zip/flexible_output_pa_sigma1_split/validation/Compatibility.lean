import Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1

noncomputable section

open LO FirstOrder Arithmetic

example : Theory.Δ₁ 𝗣𝗔 := inferInstance
example : Theory.Δ₁ 𝗜𝚺₁ := inferInstance

#check Bootstrapping.IsSigma1
#check InductionScheme.delta1_univ
#check InductionScheme.delta1_sigma1
#print axioms PA_delta1Definable
#print axioms ISigma1_delta1Definable
