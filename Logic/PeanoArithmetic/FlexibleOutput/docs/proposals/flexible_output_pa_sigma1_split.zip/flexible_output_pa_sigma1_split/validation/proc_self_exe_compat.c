/* Runtime compatibility only; the official Lean binaries remain unchanged.
 * A PID namespace can expose /proc/self/exe but not /proc/<getpid()>/exe.
 * Retry only that exact failing identity lookup using its self alias.
 * No other path or operation is altered.
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

ssize_t readlink(const char *path, char *buf, size_t size) {
    ssize_t (*actual_readlink)(const char *, char *, size_t);
    *(void **)(&actual_readlink) = dlsym(RTLD_NEXT, "readlink");
    if (!actual_readlink) {
        errno = ENOSYS;
        return -1;
    }
    ssize_t result = actual_readlink(path, buf, size);
    if (result >= 0) return result;
    int saved_errno = errno;
    char current_exe[64];
    int length = snprintf(current_exe, sizeof current_exe,
                          "/proc/%ld/exe", (long)getpid());
    if (length > 0 && (size_t)length < sizeof current_exe &&
        strcmp(path, current_exe) == 0)
        return actual_readlink("/proc/self/exe", buf, size);
    errno = saved_errno;
    return result;
}
