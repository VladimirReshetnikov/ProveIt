import PAFlexibleOutput.Main
import Lean.Util.FoldConsts

/-!
Inspect the union of the full declaration type-and-value dependency closures
of the original FlexibleOutput endpoint and its two corollaries. Presence in
the imported environment is checked separately from reachability.
-/

open Lean in
run_cmd do
  let env ← getEnv
  let roots := [``PAFlexibleOutput.flexibleOutput,
    ``PAFlexibleOutput.flexibleOutput_satisfiable,
    ``PAFlexibleOutput.exists_partrec_flexibleOutput]
  let targets := [``LO.FirstOrder.Arithmetic.Bootstrapping.IsSigma1,
    ``LO.FirstOrder.Arithmetic.Bootstrapping.isSigma1,
    ``LO.FirstOrder.Arithmetic.ISigma1_delta1Definable]
  let mut pending := roots
  let mut seen : NameSet := {}
  let mut missing : Array Name := #[]
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    if !seen.contains name then
      seen := seen.insert name
      if let some info := env.find? name then
        for dep in info.getUsedConstantsAsSet do
          pending := dep :: pending
      else
        missing := missing.push name
  unless missing.isEmpty do
    throwError "Uninspectable constants: {missing}"
  logInfo m!"ROOTS {roots}"
  logInfo m!"CLOSURE_COMPLETED_WITHOUT_MISSING_CONSTANTS"
  for target in targets do
    unless env.contains target do
      throwError "Expected pre-split environment constant is absent: {target}"
    logInfo m!"TARGET {target} imported=true reachable={seen.contains target}"
    if seen.contains target then
      throwError "Target is already used by an original endpoint: {target}"
  let pa := ``LO.FirstOrder.Arithmetic.PA_delta1Definable
  unless seen.contains pa do
    throwError "Positive control PA axiomatization was not reached"
  logInfo m!"POSITIVE_CONTROL {pa} reachable=true"
  let mut related : Array Name := #[]
  for name in seen do
    let s := name.toString
    if s.startsWith "LO.FirstOrder.Arithmetic.Bootstrapping.IsSigma1" ||
      s.startsWith "LO.FirstOrder.Arithmetic.Bootstrapping.isSigma1" ||
      s.startsWith "LO.FirstOrder.Arithmetic.InductionSigma1R" ||
      s.startsWith "LO.FirstOrder.Arithmetic.chSigma1" ||
      s == "LO.FirstOrder.Arithmetic.InductionScheme.delta1_sigma1" ||
      s == "LO.FirstOrder.Arithmetic.ISigma1_delta1Definable" then
      related := related.push name
  logInfo m!"RELATED_REMOVED_RECOGNIZER_FAMILY_REACHABLE {related}"
  unless related.isEmpty do
    throwError "Some recognizer-family declaration remains reachable: {related}"
  logInfo m!"PASS: imported ISigma1 axiomatization is absent from all three endpoint closures."
