module

/- Modified 2026-11-09: compatibility imports after splitting PA and IΣ₁ definability. -/

public import Foundation.FirstOrder.Incompleteness.InductionSchemeSigma1

/-!
# Δ₁-definability of the induction schemata, PA, and IΣ₁

Compatibility entry point. All former public declarations remain available.
Clients needing only `PA_delta1Definable` can import `InductionSchemePA`.
-/
