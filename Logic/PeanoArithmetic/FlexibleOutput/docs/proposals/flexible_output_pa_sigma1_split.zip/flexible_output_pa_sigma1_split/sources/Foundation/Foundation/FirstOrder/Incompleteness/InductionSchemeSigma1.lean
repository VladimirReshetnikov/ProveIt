module

/- Modified 2026-11-09: extracted IΣ₁-specific declarations, with unchanged proof bodies. -/

public import Foundation.FirstOrder.Incompleteness.InductionSchemePA

/-!
# Σ₁-formula recognition and Δ₁-definability of the IΣ₁ axiom set

This module adds the IΣ₁-specific development to unrestricted induction and PA.
The compatibility module `InductionSchemeDelta1` publicly imports this module.
-/

@[expose] public section

namespace LO.FirstOrder.Arithmetic.Bootstrapping

variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]

/-! ## Σ₁ side condition: internal `IsSigma1` predicate (for `C = Hierarchy 𝚺 1`)

`IsSigma1 p` recognizes codes of `𝚺₁` formulas over `ℒₒᵣ`. By `Hierarchy.sigma₁_induction'`, over
`ℒₒᵣ` a formula is `𝚺₁` iff built from atoms (`=,≠,<,≮,⊤,⊥`) by `∧`, `∨`, (unbounded) `∃`, and
**bounded `∀`** `∀⁰[“#0 < !!(bShift t)”] φ`, whose body desugars to `(^#0 ^≮ u) ^⋎ φ` with
`u = termBShift t`. The recognizer is applied to a code already known to be a semiformula, so atoms
are matched purely structurally (no `IsUTermVec` guard). Positivity (`u` is a `bShift`-image) is
`Δ₁`: `termBShift` only grows codes (`le_termBShift`), so `∃ t < u+1, u = termBShift t` is a
*bounded* `∃` over the `Δ₁` graph `termBShiftGraph`. -/

section isSigma1

variable {L : Language} [L.Encodable] [L.LORDefinable]

/-- `termBShift` only grows codes: `t ≤ termBShift t` for well-formed terms. The `^#z → ^#(z+1)`
bvar shift grows, `^&x` is fixed, and functions recurse componentwise. Bounds the `∃ t` guard in
the bounded-`∀` clause. -/
lemma le_termBShift {t : V} (ht : IsUTerm L t) : t ≤ termBShift L t := by
  refine IsUTerm.induction 𝚺 (P := fun t ↦ t ≤ termBShift L t) ?_ ?_ ?_ ?_ t ht
  · definability
  · intro z
    rw [termBShift_bvar]
    simp only [qqBvar]
    exact add_le_add (pair_le_pair_right (0 : V) le_self_add) (le_refl 1)
  · intro x; simp
  · intro k f v hf hv ih
    rw [termBShift_func hf hv]
    have hvle : v ≤ termBShiftVec L k v := by
      refine le_of_nth_le_nth ?_ ?_
      · rw [len_termBShiftVec hv]; exact hv.1.symm
      · intro i hi
        rw [← hv.1] at hi
        rw [nth_termBShiftVec hv hi]
        exact ih i hi
    simp only [qqFunc]
    exact add_le_add
      (pair_le_pair_right 2 (pair_le_pair_right k (pair_le_pair_right f hvle))) (le_refl 1)

lemma IsUTerm.termBShift {t : V} (ht : IsUTerm L t) : IsUTerm L (termBShift L t) :=
  (ht.isSemiterm.termBShift).isUTerm

lemma IsUTermVec.termBShiftVec {k v : V} (hv : IsUTermVec L k v) :
    IsUTermVec L k (termBShiftVec L k v) :=
  ⟨(len_termBShiftVec hv).symm, fun i hi => by
    rw [nth_termBShiftVec hv hi]; exact (hv.nth hi).termBShift⟩

/-- `termBShift` shifts the bound-variable depth up by exactly one (on well-formed terms): so `t` is
a level-`m` term iff `termBShift t` is level-`(m+1)`. The `←`-direction recovers the lowered arity,
which is how the bounded-`∀` bound (a `termBShift`-image) is recognized as a `bShift` of a real term
of the outer arity. -/
lemma termBV_termBShift_le {t : V} (ht : IsUTerm L t) (m : V) :
    termBV L (termBShift L t) ≤ m + 1 ↔ termBV L t ≤ m := by
  refine IsUTerm.induction 𝚺 (P := fun t ↦ termBV L (termBShift L t) ≤ m + 1 ↔ termBV L t ≤ m)
    ?_ ?_ ?_ ?_ t ht
  · definability
  · intro z; simp only [termBShift_bvar, termBV_bvar]; exact add_le_add_iff_right 1
  · intro x; simp only [termBShift_fvar, termBV_fvar]; exact iff_of_true zero_le zero_le
  · intro k f v hf hv ih
    rw [termBShift_func hf hv, termBV_func hf hv.termBShiftVec, termBV_func hf hv,
      listMaxss_le_iff, listMaxss_le_iff]
    constructor
    · intro H i hi
      rw [len_termBVVec hv] at hi
      rw [nth_termBVVec hv hi, ← ih i hi]
      have := H i (by rw [len_termBVVec hv.termBShiftVec]; exact hi)
      rwa [nth_termBVVec hv.termBShiftVec hi, nth_termBShiftVec hv hi] at this
    · intro H i hi
      rw [len_termBVVec hv.termBShiftVec] at hi
      rw [nth_termBVVec hv.termBShiftVec hi, nth_termBShiftVec hv hi, ih i hi]
      have := H i (by rw [len_termBVVec hv]; exact hi)
      rwa [nth_termBVVec hv hi] at this

/-- Internal bounded-`∀` code: `qqBall u q = ^∀ ((^#0 ^≮ u) ^⋎ q)`, the code of `∀⁰[“#0 < u”] q`.
Packaged as a single `𝚺₁`-function (mirroring `qqNLT`/`qqRel`) so the `IsSigma1` fixpoint clause is
flat. -/
noncomputable def qqBall (u q : V) : V := qqAll (qqOr (Arithmetic.qqNLT (qqBvar 0) u) q)

@[simp] lemma lt_q_qqBall (u q : V) : q < qqBall u q :=
  lt_trans (lt_or_right _ _) (lt_forall _)

@[simp] lemma lt_u_qqBall (u q : V) : u < qqBall u q :=
  lt_trans (Arithmetic.lt_qqNLT_right _ _) (lt_trans (lt_or_left _ _) (lt_forall _))

def _root_.LO.FirstOrder.Arithmetic.qqBallDef : 𝚺₁.Semisentence 3 := .mkSigma
  “p u q. ∃ bv, !qqBvarDef bv 0 ∧ ∃ nlt, !qqNLTDef nlt bv u ∧ ∃ g, !qqOrDef g nlt q ∧ !qqAllDef p g”

instance qqBall_defined : 𝚺₁-Function₂ (qqBall : V → V → V) via Arithmetic.qqBallDef := .mk fun v ↦ by
  simp [Arithmetic.qqBallDef, qqBall, (Arithmetic.qqNLT_defined (V := V)).df]

instance qqBall_definable (Γ m) : Γ-[m + 1]-Function₂ (qqBall : V → V → V) :=
  .of_sigmaOne qqBall_defined.to_definable

namespace IsSigma1F

/-- Single-step operator: `p` is `𝚺₁` given that its immediate subformulas in `C` are. Atoms carry
no well-formedness guard (the recognizer is applied to a code already known to be a semiformula);
the bounded-`∀` clause requires the bound `u` to be a `termBShift`-image of a well-formed term. -/
def Phi (C : Set V) (p : V) : Prop :=
  (p = ^⊤) ∨
  (p = ^⊥) ∨
  (∃ k r v, p = ^rel k r v) ∨
  (∃ k r v, p = ^nrel k r v) ∨
  (∃ p₁ p₂, p₁ ∈ C ∧ p₂ ∈ C ∧ p = p₁ ^⋏ p₂) ∨
  (∃ p₁ p₂, p₁ ∈ C ∧ p₂ ∈ C ∧ p = p₁ ^⋎ p₂) ∨
  (∃ p₁, p₁ ∈ C ∧ p = ^∃ p₁) ∨
  (∃ u q, (∃ t, IsUTerm ℒₒᵣ t ∧ u = termBShift ℒₒᵣ t) ∧ q ∈ C ∧ p = qqBall u q)

private lemma phi_iff (C p : V) :
    Phi {x | x ∈ C} p ↔
    (p = ^⊤) ∨
    (p = ^⊥) ∨
    (∃ k < p, ∃ r < p, ∃ v < p, p = ^rel k r v) ∨
    (∃ k < p, ∃ r < p, ∃ v < p, p = ^nrel k r v) ∨
    (∃ p₁ < p, ∃ p₂ < p, p₁ ∈ C ∧ p₂ ∈ C ∧ p = p₁ ^⋏ p₂) ∨
    (∃ p₁ < p, ∃ p₂ < p, p₁ ∈ C ∧ p₂ ∈ C ∧ p = p₁ ^⋎ p₂) ∨
    (∃ p₁ < p, p₁ ∈ C ∧ p = ^∃ p₁) ∨
    (∃ u < p, ∃ q < p, (∃ t < p, IsUTerm ℒₒᵣ t ∧ u = termBShift ℒₒᵣ t) ∧ q ∈ C
        ∧ p = qqBall u q) where
  mp := by
    rintro (rfl | rfl | ⟨k, r, v, rfl⟩ | ⟨k, r, v, rfl⟩ | ⟨p₁, p₂, hp, hq, rfl⟩
      | ⟨p₁, p₂, hp, hq, rfl⟩ | ⟨p₁, hp, rfl⟩ | ⟨u, q, ⟨t, ht, rfl⟩, hq, rfl⟩)
    · tauto
    · tauto
    · exact Or.inr (Or.inr (Or.inl ⟨k, by simp, r, by simp, v, by simp, rfl⟩))
    · exact Or.inr (Or.inr (Or.inr (Or.inl ⟨k, by simp, r, by simp, v, by simp, rfl⟩)))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, by simp, p₂, by simp, hp, hq, rfl⟩))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, by simp, p₂, by simp, hp, hq, rfl⟩)))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, by simp, hp, rfl⟩))))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr
        ⟨termBShift ℒₒᵣ t, lt_u_qqBall _ _, q, lt_q_qqBall _ _,
          ⟨t, lt_of_le_of_lt (le_termBShift ht) (lt_u_qqBall _ _), ht, rfl⟩, hq, rfl⟩))))))
  mpr := by
    unfold Phi
    rintro (rfl | rfl | ⟨k, _, r, _, v, _, rfl⟩ | ⟨k, _, r, _, v, _, rfl⟩
      | ⟨p₁, _, p₂, _, hp, hq, rfl⟩ | ⟨p₁, _, p₂, _, hp, hq, rfl⟩ | ⟨p₁, _, hp, rfl⟩
      | ⟨u, _, q, _, ⟨t, _, ht, rfl⟩, hq, rfl⟩)
    · exact Or.inl rfl
    · exact Or.inr (Or.inl rfl)
    · exact Or.inr (Or.inr (Or.inl ⟨k, r, v, rfl⟩))
    · exact Or.inr (Or.inr (Or.inr (Or.inl ⟨k, r, v, rfl⟩)))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, p₂, hp, hq, rfl⟩))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, p₂, hp, hq, rfl⟩)))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, hp, rfl⟩))))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr
        ⟨termBShift ℒₒᵣ t, q, ⟨t, ht, rfl⟩, hq, rfl⟩))))))

noncomputable def blueprint : Fixpoint.Blueprint 0 := ⟨.mkDelta
  (.mkSigma “p C.
    !qqVerumDef p ∨ !qqFalsumDef p ∨
    (∃ k < p, ∃ r < p, ∃ v < p, !qqRelDef p k r v) ∨
    (∃ k < p, ∃ r < p, ∃ v < p, !qqNRelDef p k r v) ∨
    (∃ p₁ < p, ∃ p₂ < p, p₁ ∈ C ∧ p₂ ∈ C ∧ !qqAndDef p p₁ p₂) ∨
    (∃ p₁ < p, ∃ p₂ < p, p₁ ∈ C ∧ p₂ ∈ C ∧ !qqOrDef p p₁ p₂) ∨
    (∃ p₁ < p, p₁ ∈ C ∧ !qqExsDef p p₁) ∨
    (∃ u < p, ∃ q < p,
       (∃ t < p, !(isUTerm ℒₒᵣ).sigma t ∧ !(termBShiftGraph ℒₒᵣ) u t) ∧ q ∈ C
       ∧ !qqBallDef p u q)”)
  (.mkPi “p C.
    !qqVerumDef p ∨ !qqFalsumDef p ∨
    (∃ k < p, ∃ r < p, ∃ v < p, !qqRelDef p k r v) ∨
    (∃ k < p, ∃ r < p, ∃ v < p, !qqNRelDef p k r v) ∨
    (∃ p₁ < p, ∃ p₂ < p, p₁ ∈ C ∧ p₂ ∈ C ∧ !qqAndDef p p₁ p₂) ∨
    (∃ p₁ < p, ∃ p₂ < p, p₁ ∈ C ∧ p₂ ∈ C ∧ !qqOrDef p p₁ p₂) ∨
    (∃ p₁ < p, p₁ ∈ C ∧ !qqExsDef p p₁) ∨
    (∃ u < p, ∃ q < p,
       (∃ t < p, !(isUTerm ℒₒᵣ).pi t ∧ ∀ u', !(termBShiftGraph ℒₒᵣ) u' t → u = u') ∧ q ∈ C
       ∧ ∀ p', !qqBallDef p' u q → p = p')”)⟩

def construction : Fixpoint.Construction V blueprint where
  Φ := fun _ ↦ Phi
  defined := .mk <| by
    constructor
    · intro v
      simp [blueprint, HierarchySymbol.Semiformula.val_sigma, eq_comm,
        (termBShift.defined (L := ℒₒᵣ) (V := V)).df, (qqBall_defined (V := V)).df]
    · intro v
      symm
      simpa [blueprint, HierarchySymbol.Semiformula.val_sigma, eq_comm,
        (termBShift.defined (L := ℒₒᵣ) (V := V)).df, (qqBall_defined (V := V)).df]
        using phi_iff (V := V) _ _
  monotone := by
    unfold Phi
    rintro C C' hC _ x (h | h | h | h | ⟨p₁, p₂, hp, hq, rfl⟩ | ⟨p₁, p₂, hp, hq, rfl⟩
      | ⟨p₁, hp, rfl⟩ | ⟨u, q, ht, hq, rfl⟩)
    · exact Or.inl h
    · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr (Or.inl h))
    · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, p₂, hC hp, hC hq, rfl⟩))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, p₂, hC hp, hC hq, rfl⟩)))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, hC hp, rfl⟩))))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨u, q, ht, hC hq, rfl⟩))))))

instance : construction.StrongFinite V where
  strong_finite := by
    unfold construction Phi
    rintro C _ x (h | h | h | h | ⟨p₁, p₂, hp, hq, rfl⟩ | ⟨p₁, p₂, hp, hq, rfl⟩
      | ⟨p₁, hp, rfl⟩ | ⟨u, q, ht, hq, rfl⟩)
    · exact Or.inl h
    · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr (Or.inl h))
    · exact Or.inr (Or.inr (Or.inr (Or.inl h)))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl
        ⟨p₁, p₂, ⟨hp, by simp⟩, ⟨hq, by simp⟩, rfl⟩))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl
        ⟨p₁, p₂, ⟨hp, by simp⟩, ⟨hq, by simp⟩, rfl⟩)))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p₁, ⟨hp, by simp⟩, rfl⟩))))))
    · refine Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr
        ⟨u, q, ht, ⟨hq, ?_⟩, rfl⟩))))))
      exact lt_q_qqBall _ _

end IsSigma1F

/-- `IsSigma1 p`: `p` codes a `𝚺₁` formula over `ℒₒᵣ` (assuming `p` is a semiformula). -/
def IsSigma1 (p : V) : Prop := IsSigma1F.construction.Fixpoint ![] p

/-- Concrete `𝚫₁`-recognizer for `IsSigma1`. -/
noncomputable def isSigma1 : 𝚫₁.Semisentence 1 := IsSigma1F.blueprint.fixpointDefΔ₁

instance IsSigma1.defined : 𝚫₁-Predicate (IsSigma1 (V := V)) via isSigma1 :=
  IsSigma1F.construction.fixpoint_definedΔ₁

lemma IsSigma1.case_iff {p : V} :
    IsSigma1 p ↔
    (p = ^⊤) ∨
    (p = ^⊥) ∨
    (∃ k r v, p = ^rel k r v) ∨
    (∃ k r v, p = ^nrel k r v) ∨
    (∃ p₁ p₂, IsSigma1 p₁ ∧ IsSigma1 p₂ ∧ p = p₁ ^⋏ p₂) ∨
    (∃ p₁ p₂, IsSigma1 p₁ ∧ IsSigma1 p₂ ∧ p = p₁ ^⋎ p₂) ∨
    (∃ p₁, IsSigma1 p₁ ∧ p = ^∃ p₁) ∨
    (∃ u q, (∃ t, IsUTerm ℒₒᵣ t ∧ u = termBShift ℒₒᵣ t) ∧ IsSigma1 q
        ∧ p = qqBall u q) :=
  IsSigma1F.construction.case

alias ⟨IsSigma1.case, IsSigma1.mk⟩ := IsSigma1.case_iff

@[simp] lemma IsSigma1.verum : IsSigma1 (V := V) (^⊤) := IsSigma1.mk (Or.inl rfl)
@[simp] lemma IsSigma1.falsum : IsSigma1 (V := V) (^⊥) := IsSigma1.mk (Or.inr (Or.inl rfl))
@[simp] lemma IsSigma1.rel {k r v : V} : IsSigma1 (^rel k r v) :=
  IsSigma1.mk (Or.inr (Or.inr (Or.inl ⟨k, r, v, rfl⟩)))
@[simp] lemma IsSigma1.nrel {k r v : V} : IsSigma1 (^nrel k r v) :=
  IsSigma1.mk (Or.inr (Or.inr (Or.inr (Or.inl ⟨k, r, v, rfl⟩))))

@[simp] lemma IsSigma1.and_iff {p q : V} : IsSigma1 (p ^⋏ q) ↔ IsSigma1 p ∧ IsSigma1 q := by
  constructor
  · intro h
    rcases h.case with (h | h | ⟨_,_,_,h⟩ | ⟨_,_,_,h⟩ | ⟨p₁,p₂,hp,hq,h⟩ | ⟨_,_,_,_,h⟩ | ⟨_,_,h⟩ | ⟨u,q',_,_,h⟩) <;>
      simp [qqRel, qqNRel, qqVerum, qqFalsum, qqAnd, qqOr, qqExs, qqAll, qqBall] at h
    · obtain ⟨rfl, rfl⟩ := h; exact ⟨hp, hq⟩
  · rintro ⟨hp, hq⟩
    exact IsSigma1.mk (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p, q, hp, hq, rfl⟩)))))

@[simp] lemma IsSigma1.or_iff {p q : V} : IsSigma1 (p ^⋎ q) ↔ IsSigma1 p ∧ IsSigma1 q := by
  constructor
  · intro h
    rcases h.case with (h | h | ⟨_,_,_,h⟩ | ⟨_,_,_,h⟩ | ⟨_,_,_,_,h⟩ | ⟨p₁,p₂,hp,hq,h⟩ | ⟨_,_,h⟩ | ⟨u,q',_,_,h⟩) <;>
      simp [qqRel, qqNRel, qqVerum, qqFalsum, qqAnd, qqOr, qqExs, qqAll, qqBall] at h
    · obtain ⟨rfl, rfl⟩ := h; exact ⟨hp, hq⟩
  · rintro ⟨hp, hq⟩
    exact IsSigma1.mk (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p, q, hp, hq, rfl⟩))))))

@[simp] lemma IsSigma1.ex_iff {p : V} : IsSigma1 (^∃ p) ↔ IsSigma1 p := by
  constructor
  · intro h
    rcases h.case with (h | h | ⟨_,_,_,h⟩ | ⟨_,_,_,h⟩ | ⟨_,_,_,_,h⟩ | ⟨_,_,_,_,h⟩ | ⟨p₁,hp,h⟩ | ⟨u,q',_,_,h⟩) <;>
      simp [qqRel, qqNRel, qqVerum, qqFalsum, qqAnd, qqOr, qqExs, qqAll, qqBall] at h
    · obtain rfl := h; exact hp
  · rintro hp
    exact IsSigma1.mk (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨p, hp, rfl⟩)))))))

/-- Inversion of the bounded-`∀` clause: a `^∀`-headed `𝚺₁` code is a `qqBall`. -/
lemma IsSigma1.of_all {p : V} (h : IsSigma1 (^∀ p)) :
    ∃ u q, (∃ t, IsUTerm ℒₒᵣ t ∧ u = termBShift ℒₒᵣ t) ∧ IsSigma1 q
      ∧ p = qqOr (Arithmetic.qqNLT (qqBvar 0) u) q := by
  rcases h.case with (h | h | ⟨_,_,_,h⟩ | ⟨_,_,_,h⟩ | ⟨_,_,_,_,h⟩ | ⟨_,_,_,_,h⟩ | ⟨_,_,h⟩
    | ⟨u, q, hguard, hq, h⟩)
  · exact absurd h (by simp [qqAll, qqVerum])
  · exact absurd h (by simp [qqAll, qqFalsum])
  · exact absurd h (by simp [qqAll, qqRel])
  · exact absurd h (by simp [qqAll, qqNRel])
  · exact absurd h (by simp [qqAll, qqAnd])
  · exact absurd h (by simp [qqAll, qqOr])
  · exact absurd h (by simp [qqAll, qqExs])
  · rw [show qqBall u q = ^∀ (qqOr (Arithmetic.qqNLT (qqBvar 0) u) q) from rfl, qqAll_inj] at h
    exact ⟨u, q, hguard, hq, h⟩

end isSigma1


end LO.FirstOrder.Arithmetic.Bootstrapping

namespace LO.FirstOrder.Arithmetic

open LO.FirstOrder.Theory

/-! ## Correctness of `IsSigma1`: `IsSigma1 ⌜ψ⌝ ↔ Hierarchy 𝚺 1 ψ` -/

open Bootstrapping in
/-- The code of the bounded universal `∀⁰[#0 < bShift t] φ` is `qqBall (termBShift ⌜t⌝) ⌜φ⌝`. -/
lemma quote_ball {n : ℕ} (t : SyntacticSemiterm ℒₒᵣ n) (φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (n + 1)) :
    (⌜(∀⁰[“#0 < !!(Rew.bShift t)”] φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ n)⌝ : ℕ)
      = qqBall (termBShift ℒₒᵣ (⌜t⌝ : ℕ)) (⌜φ⌝ : ℕ) := by
  rw [Semiformula.ball_eq, Semiformula.imp_eq]
  simp only [Semiformula.Operator.lt_def, Semiformula.neg_rel, Semiformula.quote_all,
    Semiformula.quote_or, qqBall, qqAll_inj, qqOr_inj, and_true]
  simp [Semiformula.quote_nrel, Arithmetic.qqNLT, Arithmetic.ltIndex, Semiterm.quote_def,
    Matrix.vecHead, Matrix.vecTail, Matrix.cons_val_zero, Matrix.cons_val_one]
  rfl

open Bootstrapping in
/-- The raw code of `bShift s` is `termBShift ⌜s⌝`. -/
lemma termBShift_quote {n : ℕ} (s : SyntacticSemiterm ℒₒᵣ n) :
    (⌜Rew.bShift s⌝ : ℕ) = termBShift ℒₒᵣ (⌜s⌝ : ℕ) := by
  simp [Semiterm.quote_def, Semiterm.typed_quote_bShift]

open Bootstrapping in
/-- `(⟸)` Every `𝚺₁` formula has a `𝚺₁`-recognized code. By `sigma₁_induction'`. -/
lemma isSigma1_of_hierarchy {n : ℕ} {ψ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ n} (h : Hierarchy 𝚺 1 ψ) :
    IsSigma1 (⌜ψ⌝ : ℕ) := by
  refine sigma₁_induction' h (P := fun n φ => IsSigma1 (⌜φ⌝ : ℕ))
    ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_
  · intro n; simp
  · intro n; simp
  · intro n t₁ t₂; simp [Semiformula.quote_rel]
  · intro n t₁ t₂; simp [Semiformula.quote_nrel]
  · intro n t₁ t₂; simp [Semiformula.quote_rel]
  · intro n t₁ t₂; simp [Semiformula.quote_nrel]
  · intro n φ ψ hφ hψ ihφ ihψ; simpa [Semiformula.quote_and] using ⟨ihφ, ihψ⟩
  · intro n φ ψ hφ hψ ihφ ihψ; simpa [Semiformula.quote_or] using ⟨ihφ, ihψ⟩
  · intro n t φ hφ ihφ
    rw [quote_ball]
    refine IsSigma1.mk (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr
      ⟨termBShift ℒₒᵣ (⌜t⌝ : ℕ), (⌜φ⌝ : ℕ), ⟨(⌜t⌝ : ℕ), ?_, rfl⟩, ihφ, rfl⟩)))))))
    simp [Semiterm.quote_def]
  · intro n φ hφ ihφ; simpa [Semiformula.quote_ex] using ihφ

open Bootstrapping in
/-- `(⟹)` A `𝚺₁`-recognized code is the code of a `𝚺₁` formula. Meta-induction on the formula:
atoms are `𝚺₁` unconditionally; `∧/∨/∃` recurse; the `^∀` case is forced into the bounded shape by
the recognizer (`IsSigma1.of_all`), and the bound is a `bShift`-image (positivity via
`termBV_termBShift_le`), so `Hierarchy.ball` applies. -/
lemma hierarchy_of_isSigma1 {n : ℕ} (ψ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ n) :
    IsSigma1 (⌜ψ⌝ : ℕ) → Hierarchy 𝚺 1 ψ := by
  induction ψ using Semiformula.rec' with
  | hverum => intro _; simp
  | hfalsum => intro _; simp
  | hrel R v => intro _; exact Hierarchy.rel _ _ _ _
  | hnrel R v => intro _; exact Hierarchy.nrel _ _ _ _
  | hand φ ψ ihφ ihψ =>
      intro h; rw [Semiformula.quote_and (V := ℕ) φ ψ, IsSigma1.and_iff] at h
      exact Hierarchy.and (ihφ h.1) (ihψ h.2)
  | hor φ ψ ihφ ihψ =>
      intro h; rw [Semiformula.quote_or (V := ℕ) φ ψ, IsSigma1.or_iff] at h
      exact Hierarchy.or (ihφ h.1) (ihψ h.2)
  | hall φ ihφ =>
      intro h
      rw [Semiformula.quote_all (V := ℕ) φ] at h
      obtain ⟨u, q, ⟨t, ht, rfl⟩, hq, hφeq⟩ := IsSigma1.of_all h
      have hsf := Semiformula.quote_isSemiformula (V := ℕ) φ
      simp only [natCast_nat] at hsf
      rw [hφeq, Arithmetic.qqNLT] at hsf
      simp only [IsSemiformula.or, IsSemiformula.nrel] at hsf
      obtain ⟨⟨_, hvec⟩, hqsf⟩ := hsf
      obtain ⟨φ₂, hφ₂⟩ := Bootstrapping.IsSemiformula.sound hqsf
      have htmsf := hvec.nth (i := 1) (show (1 : ℕ) < 2 by simp)
      simp only [nth_adjoin_one, nth_adjoin_zero] at htmsf
      obtain ⟨s, hs⟩ := Bootstrapping.IsSemiterm.sound
        ((IsSemiterm.def (L := ℒₒᵣ)).mpr ⟨ht,
          (termBV_termBShift_le (L := ℒₒᵣ) ht _).mp ((IsSemiterm.def (L := ℒₒᵣ)).mp htmsf).2⟩)
      have heq : (∀⁰ φ) = ∀⁰[“#0 < !!(Rew.bShift s)”] φ₂ := by
        apply (Semiformula.quote_inj_iff (L := ℒₒᵣ) (V := ℕ)).mp
        rw [Semiformula.quote_all (V := ℕ) φ, hφeq, quote_ball, hs, hφ₂]
        rfl
      have hφ : Hierarchy 𝚺 1 φ := ihφ (by rw [hφeq]; simp [IsSigma1.or_iff, hq, Arithmetic.qqNLT])
      have hφ2 : Hierarchy 𝚺 1 φ₂ := by
        have hform : φ = (“#0 < !!(Rew.bShift s)” 🡒 φ₂) :=
          (Semiformula.all_inj _ _).mp (by rw [← Semiformula.ball_eq]; exact heq)
        rw [hform, Semiformula.imp_eq, Hierarchy.or_iff] at hφ
        exact hφ.2
      rw [heq]
      exact Hierarchy.ball (Rew.positive_iff.mpr ⟨s, rfl⟩) hφ2
  | hexs φ ihφ =>
      intro h; rw [Semiformula.quote_ex (V := ℕ) φ, IsSigma1.ex_iff] at h
      exact Hierarchy.exs (ihφ h)

/-- **Correctness of the `𝚺₁`-code recognizer**: `IsSigma1 ⌜ψ⌝ ↔ Hierarchy 𝚺 1 ψ`. -/
lemma isSigma1_iff_hierarchy {n : ℕ} (ψ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ n) :
    Bootstrapping.IsSigma1 (⌜ψ⌝ : ℕ) ↔ Hierarchy 𝚺 1 ψ :=
  ⟨hierarchy_of_isSigma1 ψ, isSigma1_of_hierarchy⟩

/-! ## The `C = Hierarchy 𝚺 1` recognizer = `chUniv` + the `IsSigma1 K` side condition -/

section chSigma1

variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]

open Bootstrapping

/-- The recognizer for `InductionScheme ℒₒᵣ (Hierarchy 𝚺 1)`: `InductionUnivR` plus the side
condition `IsSigma1 K` on the recovered core `K`. -/
def InductionSigma1R (p : V) : Prop :=
  ∃ m ≤ p, ∃ b ≤ p,
    p = qqAlls b m ∧ IsUFormula ℒₒᵣ b ∧ shift ℒₒᵣ b = b ∧ bv ℒₒᵣ b = m
    ∧ ∃ K ≤ subst ℒₒᵣ (fvarVec m) b,
        IsSemiformula ℒₒᵣ 1 K ∧ IsSigma1 K ∧ subst ℒₒᵣ (fvarVec m) b = indBodyVal K

end chSigma1

/-- Concrete `𝚫₁.Semisentence 1` recognizer for the `𝚺₁` induction scheme. -/
noncomputable def chSigma1 : 𝚫₁.Semisentence 1 := .mkDelta
  (.mkSigma “p.
    ∃ m < p + 1, ∃ b < p + 1,
      !qqAllsDef p b m ∧ !(Bootstrapping.isUFormula ℒₒᵣ).sigma b
      ∧ !(Bootstrapping.shiftGraph ℒₒᵣ) b b ∧ !(Bootstrapping.bvGraph ℒₒᵣ) m b
      ∧ ∃ fv, !fvarVecDef fv m ∧ ∃ s, !(Bootstrapping.substsGraph ℒₒᵣ) s fv b
        ∧ ∃ K < s + 1, !(Bootstrapping.isSemiformula ℒₒᵣ).sigma 1 K
          ∧ !(Bootstrapping.isSigma1).sigma K ∧ !indBodyValGraph s K”)
  (.mkPi “p.
    ∃ m < p + 1, ∃ b < p + 1,
      (∀ y, !qqAllsDef y b m → y = p) ∧ !(Bootstrapping.isUFormula ℒₒᵣ).pi b
      ∧ (∀ y, !(Bootstrapping.shiftGraph ℒₒᵣ) y b → y = b) ∧ (∀ y, !(Bootstrapping.bvGraph ℒₒᵣ) y b → y = m)
      ∧ ∀ fv, !fvarVecDef fv m → ∀ s, !(Bootstrapping.substsGraph ℒₒᵣ) s fv b
        → ∃ K < s + 1, !(Bootstrapping.isSemiformula ℒₒᵣ).pi 1 K
          ∧ !(Bootstrapping.isSigma1).pi K ∧ ∀ ib, !indBodyValGraph ib K → s = ib”)

section chSigma1Defined

variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]

open Bootstrapping

instance InductionSigma1R.defined : 𝚫₁-Predicate[V] (InductionSigma1R : V → Prop) via chSigma1 := .mk <| by
  constructor
  · intro v; simp [chSigma1, HierarchySymbol.Semiformula.val_sigma, eq_comm]
  · intro v
    simp [chSigma1, HierarchySymbol.Semiformula.val_sigma, InductionSigma1R,
      lt_succ_iff_le, eq_comm]

end chSigma1Defined

/-- RHS of `chSigma1_mem_iff` reduced to a clean `∃ψ` (with the `𝚺₁` side condition). -/
lemma mem_inductionScheme_sigma1_iff (φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 0) :
    (∃ σ ∈ InductionScheme ℒₒᵣ (Arithmetic.Hierarchy 𝚺 1), φ = (σ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 0))
      ↔ ∃ ψ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 1, Hierarchy 𝚺 1 ψ ∧ φ = (succInd ψ).univCl' := by
  simp only [InductionScheme, Set.mem_setOf_eq]
  constructor
  · rintro ⟨σ, ⟨ψ, hψ, rfl⟩, rfl⟩
    exact ⟨ψ, hψ, by simp [Semiformula.coe_univCl_eq_univCl']⟩
  · rintro ⟨ψ, hψ, rfl⟩
    exact ⟨Semiformula.univCl (succInd ψ), ⟨ψ, hψ, rfl⟩,
      by simp [Semiformula.coe_univCl_eq_univCl']⟩

open Bootstrapping in
/-- **mem_iff math (C = Hierarchy 𝚺 1).** Mirrors `chUniv_mem_iff`, threading the `IsSigma1 K`
side condition through `isSigma1_iff_hierarchy`. -/
theorem chSigma1_mem_iff (φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 0) :
    InductionSigma1R (⌜φ⌝ : ℕ)
      ↔ ∃ σ ∈ InductionScheme ℒₒᵣ (Arithmetic.Hierarchy 𝚺 1), φ = (σ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 0) := by
  rw [mem_inductionScheme_sigma1_iff]
  constructor
  · rintro ⟨m, -, b, -, hp, hU, hsh, hbv, K, -, hKsemi, hKsig, hsubst⟩
    obtain ⟨γ, rfl⟩ := Bootstrapping.IsSemiformula.sound hKsemi
    have hbsemi : Bootstrapping.IsSemiformula ℒₒᵣ m b := hbv ▸ hU.isSemiformula
    obtain ⟨β, rfl⟩ := Bootstrapping.IsSemiformula.sound hbsemi
    refine ⟨γ, hierarchy_of_isSigma1 γ hKsig, ?_⟩
    have hβγ : β ⇜ (fun i : Fin m ↦ (&↑i : SyntacticTerm ℒₒᵣ)) = succInd γ := by
      apply (Semiformula.quote_inj_iff (L := ℒₒᵣ) (V := ℕ)).mp
      have e := Bootstrapping.subst_fvarVec_quote' (V := ℕ) β
      simp only [natCast_nat] at e
      rw [← e, hsubst, indBodyVal_quote]
    have hβfree : β.freeVariables = ∅ := by
      have hsβ : Rewriting.shift β = β :=
        (Semiformula.quote_inj_iff (L := ℒₒᵣ) (V := ℕ)).mp
          (by rw [Semiformula.quote_shift (V := ℕ) β]; exact hsh)
      have step : ∀ x, β.FVar? x → 1 ≤ x ∧ β.FVar? (x - 1) := by
        intro x hx
        rw [← hsβ] at hx
        rcases Semiformula.fvar?_rew hx with (⟨i, hi⟩ | ⟨z, hz, hi⟩)
        · simp [Rew.shift_bvar, Semiterm.FVar?] at hi
        · have hxz : x = z + 1 := by
            simpa [Rew.shift_fvar, Semiterm.FVar?, Semiterm.freeVariables_fvar] using hi
          exact ⟨by omega, by rw [hxz]; simpa using hz⟩
      by_contra hne
      classical
      have hnem := Finset.nonempty_of_ne_empty hne
      obtain ⟨hge, hpred⟩ := step (β.freeVariables.min' hnem) (β.freeVariables.min'_mem hnem)
      exact absurd (β.freeVariables.min'_le _ hpred) (by omega)
    have hφ : φ = (∀⁰* β : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 0) := by
      apply (Semiformula.quote_inj_iff (L := ℒₒᵣ) (V := ℕ)).mp
      rw [hp, Bootstrapping.quote_allClosure (V := ℕ) β]; simp
    rw [hφ]
    exact closure_inversion β γ hβfree hbv hβγ
  · rintro ⟨ψ, hψ, rfl⟩
    set χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 0 := succInd ψ with hχ
    set b : ℕ := (⌜(Rew.fixitr 0 χ.fvSup ▹ χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + χ.fvSup))⌝ : ℕ) with hb
    have hcode : (⌜χ.univCl'⌝ : ℕ) = Bootstrapping.qqAlls b ((0 + χ.fvSup : ℕ)) := by
      rw [hb, Bootstrapping.quote_univCl' (V := ℕ) χ]; simp
    have hs : Bootstrapping.subst ℒₒᵣ (Bootstrapping.fvarVec (0 + χ.fvSup : ℕ)) b
        = indBodyVal (⌜ψ⌝ : ℕ) := by
      rw [hb]
      have hsub := Bootstrapping.subst_fvarVec_quote' (V := ℕ)
        (Rew.fixitr 0 χ.fvSup ▹ χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + χ.fvSup))
      simp only [natCast_nat] at hsub
      rw [hsub, Bootstrapping.quote_subst_fvar_fixitr χ,
        show (⌜ψ⌝ : ℕ) = (⌜ψ⌝ : Bootstrapping.Semiformula ℕ ℒₒᵣ 1).val from rfl,
        indBodyVal_eq, indBody_quote, hχ]
      rfl
    refine ⟨(0 + χ.fvSup : ℕ), ?_, b, ?_, ?_, ?_, ?_, ?_, (⌜ψ⌝ : ℕ), ?_, ?_, ?_, ?_⟩
    · rw [hcode]; exact Bootstrapping.index_le_qqAlls _ _
    · rw [hcode]; exact Bootstrapping.le_qqAlls _ _
    · exact hcode
    · rw [hb]
      exact (Semiformula.quote_isSemiformula (V := ℕ)
        (Rew.fixitr 0 χ.fvSup ▹ χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + χ.fvSup))).isUFormula
    · rw [hb]
      have hnf : ∀ x, ¬(Rew.fixitr 0 χ.fvSup ▹ χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + χ.fvSup)).FVar? x := by
        intro x
        rw [Rew.eq_bind (Rew.fixitr 0 χ.fvSup)]
        simp only [Function.comp_def, Rew.fixitr_bvar, Rew.fixitr_fvar, Fin.natAdd_mk, zero_add]
        intro hh
        rcases Semiformula.fvar?_rew hh with (⟨z, hz⟩ | ⟨z, hz, hx⟩)
        · simp at hz
        · have : z < χ.fvSup := Semiformula.lt_fvSup_of_fvar? hz
          simp [this] at hx
      have hshift : Rewriting.shift (Rew.fixitr 0 χ.fvSup ▹ χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + χ.fvSup))
          = (Rew.fixitr 0 χ.fvSup ▹ χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + χ.fvSup)) :=
        Semiformula.rew_eq_self_of (by simp) (fun x hx ↦ absurd hx (hnf x))
      rw [← Semiformula.quote_shift (V := ℕ)
        (Rew.fixitr 0 χ.fvSup ▹ χ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + χ.fvSup)), hshift]
    · rw [hb]; exact (Bootstrapping.bv_quote_fixitr χ).trans (zero_add _).symm
    · rw [hs]; exact le_indBodyVal _
    · simp
    · -- the new side condition: `IsSigma1 ⌜ψ⌝` from `Hierarchy 𝚺 1 ψ`
      exact isSigma1_of_hierarchy hψ
    · exact hs

/-- The induction schema `InductionScheme ℒₒᵣ (Hierarchy 𝚺 1)` is `Δ₁`, via `chSigma1`. -/
noncomputable instance InductionScheme.delta1_sigma1 :
    (InductionScheme ℒₒᵣ (Arithmetic.Hierarchy 𝚺 1)).Δ₁ where
  ch := chSigma1
  mem_iff φ := by
    have h : (ℕ ⊧/![(⌜φ⌝ : ℕ)] chSigma1.val) ↔ InductionSigma1R (⌜φ⌝ : ℕ) := by
      simp
    rw [h]; exact chSigma1_mem_iff φ
  isDelta1 := HierarchySymbol.Semiformula.ProvablyProperOn.ofProperOn.{0} _ fun V _ _ ↦ by
    haveI := InductionSigma1R.defined (V := V); simp


noncomputable instance ISigma1_delta1Definable : 𝗜𝚺₁.Δ₁ :=
  Theory.Δ₁.add PeanoMinus.delta1 InductionScheme.delta1_sigma1

end LO.FirstOrder.Arithmetic
