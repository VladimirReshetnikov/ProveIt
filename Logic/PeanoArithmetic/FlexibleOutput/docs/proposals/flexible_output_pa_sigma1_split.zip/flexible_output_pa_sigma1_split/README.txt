FlexibleOutput: separate PA and I-Sigma-one axiom definability
Prepared for Vladimir Reshetnikov

RECOMMENDATION
==============
Split Foundation's InductionSchemeDelta1 into:

  InductionSchemePA       unrestricted induction and PA.Δ1
  InductionSchemeSigma1   Sigma-one formula recognition and IΣ1.Δ1
  InductionSchemeDelta1   compatibility import exposing both developments

Change FlexibleOutput's Provability module to import InductionSchemePA.
No mathematical proof body or original theorem statement is rewritten.
The PA coding proofs continue to assume models of IΣ1; the unused development
is the separate proof that the IΣ1 AXIOM SET is Delta-one definable.

All seven proposal archives present at the pinned commit were inspected;
316/316 supplied checksum entries match. None proposes this split. The new
seventh archive already proposes the shared selector/projection refactor,
D1 import pruning, and external certificate enumeration. Those ideas are
credited as existing work and are not part of this proposal's novelty claim.

MEASURED RESULT
===============
Full Main-rooted repository import closure, INCLUDING the Foundation submodule:

                         Baseline       Split       Removed
  Local modules               139         139             0
  Physical lines           42,503      41,956           547
  Nonblank lines           32,153      31,659           494
  Noncomment code lines    30,959      30,510           449
  UTF-8 bytes           1,852,032   1,822,384        29,648

The original 1,386-line module is replaced ON THE TARGET PATH by an 839-line
PA module. The separate IΣ1 module and compatibility wrapper remain available
to their own clients. Across all three Foundation files, total physical source
grows from 1,386 to 1,423 lines because the split adds module/documentation
overhead. The saving is in the imported development required by FlexibleOutput,
not in repository-wide source volume, kernel proof size, or measured runtime.

The same additional saving (547 physical / 449 code lines) is source-measured
over the seventh proposal's already shortened implementation. That composition
was NOT compiled in this package. It must retain that proposal's D1 import in
the new PA module, rather than restoring the standalone First/Second imports.
See analysis/composition_metrics.json and the report for the exact recipe.

VERIFICATION
============
Ten modules compiled successfully: all five project modules, its facade,
the three Foundation split/wrapper modules, and the existing Foundation
Incompleteness.Examples compatibility client. Lean's actual imported-module
list matches all 139 entries in the candidate source inventory. The main
environment contains PA_delta1Definable and does not contain IsSigma1,
isSigma1, or ISigma1_delta1Definable. All nine target/support axiom reports
contain exactly propext, Classical.choice, and Quot.sound.

The exact baseline was separately rebuilt and its full type-and-value endpoint
dependency closure inspected. The moved IΣ1 recognizer family was already
unreachable from the theorem and its corollaries; PA_delta1Definable is a
reachable positive control. Thus the source/import saving is real, while
no removal of logical inference steps is claimed.

Compatibility.lean synthesizes both old theory-definability instances through
the old module path. The declaration catalogs preserve all original non-private
names; generated proof auxiliaries can differ after module movement. See the
comparison metadata for the precise filtering and type-hash results.

PINS AND CURRENT SOURCE REPAIR
==============================
ProveIt:    0539de6333059f62e687657a841f68713a4c3018
Foundation: 32e1a0956a8622fad067328ca1959729a7634428
Mathlib:    81a5d257c8e410db227a6665ed08f64fea08e997
Lean:       leanprover/lean4:v4.32.0

The pinned repository renamed Refutations.lean to Provability.lean but left
two imports at the old name. The root patch repairs Main and the facade,
updates the facade's module description, and switches Provability to the
new PA-only import. Baseline metrics use the minimal rename repair; this
repair changes neither line nor byte counts. Raw HEAD is not claimed to build.

APPLY AND REPRODUCE
===================
Use a disposable checkout at the exact ProveIt revision, with Foundation
initialized at the specified submodule revision and the pinned Lean toolchain.

  python3 /path/to/package/scripts/reproduce.py /path/to/ProveIt

The default command checks revisions, all six source states, and BOTH patches
without changing files. To apply and build:

  python3 /path/to/package/scripts/reproduce.py /path/to/ProveIt --apply --build

For manual application, check both patches first:

  git -C /path/to/ProveIt/lib/FormalizedFormalLogic-Foundation apply --check /path/to/package/patches/foundation.patch
  git -C /path/to/ProveIt apply --check /path/to/package/patches/proveit.patch

Repeat without --check, then build:

  lake build +PAFlexibleOutput.Main
  lake build +PAFlexibleOutput
  lake build +Foundation.FirstOrder.Incompleteness.Examples
  lake env lean /path/to/package/validation/Audit.lean
  lake env lean /path/to/package/validation/Compatibility.lean

The included artifacts are local patches; nothing was committed or pushed.
To integrate the change, commit Foundation modifications in an appropriate
Foundation fork and update ProveIt's gitlink. A root commit alone cannot
preserve modified files inside a Git submodule.

PACKAGE CONTENTS
================
report/      Complete LaTeX source and compiled PDF.
sources/     Six exact replacement/addition files, by repository-relative path.
patches/     Separate applicable Foundation and ProveIt patches.
analysis/    Full closure inventories, source metrics, extraction provenance,
             seven-archive originality audit, and composition measurements.
validation/  Compiler logs, source hashes, API/axiom/import checks, exact-baseline
             declaration reachability, and compatibility results.
scripts/     Reproduction driver and complete source dependency counter.
licenses/    Original Foundation Apache-2.0 and ProveIt MIT-0 licenses.
SHA256SUMS   Checksums of every other file in the package.

Unchanged pinned dependencies used cached compiled artifacts. Changed modules
and their relevant clients were re-elaborated. This is not a claim of a clean
build of every unrelated target. No caches, .olean files, or prior proposal
archives are redistributed.
