import PAFlexibleOutput.Main
import Lean.Util.FoldConsts

/-!
The traversal follows constants in both the type and the value of each declaration.
It includes opaque theorem values and uses Lean's constructor/recursor fallback.
This is a declaration audit, not a source-import or build-time measurement.
-/
open Lean in
run_cmd do
  let env ← getEnv
  let roots := #[``LO.FirstOrder.Arithmetic.sigma1_re, ``PAFlexibleOutput.flexibleOutput]
  let watched := #[``REPred.const, ``REPred.and, ``REPred.or, ``REPred.comp,
    ``REPred.iff, ``REPred.iff', ``Partrec.merge, ``Partrec.merge']
  let targetPrefix := (← IO.getEnv "FLEXIBLE_AUDIT_PREFIX").getD "dependency_audit"
  let mut summary : Array String := #["root\tconstants\tfoundation\tmathlib\tproject\tother\taxioms"]
  for root in roots do
    let mut frontier := [root]
    let mut visited : NameSet := {}
    let mut rows : Array String := #[]
    let mut axioms : Array String := #[]
    let mut foundation := 0
    let mut mathlib := 0
    let mut project := 0
    while !frontier.isEmpty do
      let name := frontier.head!
      frontier := frontier.tail!
      if visited.contains name then
        continue
      visited := visited.insert name
      let some info := env.find? name | throwError "Cannot inspect {name}"
      let mod := match env.getModuleIdxFor? name with
        | some i => env.header.moduleNames.getD i.toNat .anonymous
        | none => env.mainModule
      let modText := mod.toString
      let kind := match info with
        | .axiomInfo _ => "axiom"
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "definition"
        | .opaqueInfo _ => "opaque"
        | _ => "primitive/inductive/constructor/recursor"
      if kind == "axiom" then
        axioms := axioms.push name.toString
      if modText.startsWith "Foundation." then
        foundation := foundation + 1
      if modText.startsWith "Mathlib." then
        mathlib := mathlib + 1
      if modText.startsWith "PAFlexibleOutput" then
        project := project + 1
      if name.toString == "sorryAx" then
        throwError "Admitted proof reachable from {root}"
      rows := rows.push s!"{mod}\t{name}\t{kind}"
      for used in info.getUsedConstantsAsSet do
        frontier := used :: frontier
    let target := targetPrefix ++ "_" ++ root.toString ++ ".tsv"
    IO.FS.writeFile target ("module\tdeclaration\tkind\n" ++
      String.intercalate "\n" (rows.qsort (· < ·)).toList ++ "\n")
    let ax := String.intercalate "," (axioms.qsort (· < ·)).toList
    summary := summary.push s!"{root}\t{rows.size}\t{foundation}\t{mathlib}\t{project}\t{rows.size - foundation - mathlib - project}\t{ax}"
    logInfo m!"{root}: {rows.size} constants; Foundation {foundation}; Mathlib {mathlib}; project {project}; axioms [{ax}]"
    for name in watched do
      logInfo m!"{root}: reachable {name} = {visited.contains name}"
  IO.FS.writeFile (targetPrefix ++ "_summary.tsv") (String.intercalate "\n" summary.toList ++ "\n")

#print axioms LO.FirstOrder.Arithmetic.sigma1_re
#print axioms PAFlexibleOutput.flexibleOutput
