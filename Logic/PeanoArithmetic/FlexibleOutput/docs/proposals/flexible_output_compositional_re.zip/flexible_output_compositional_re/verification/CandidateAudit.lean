import PAFlexibleOutput

#print axioms REPred.const
#print axioms REPred.and
#print axioms REPred.or
#print axioms REPred.comp
#print axioms REPred.forall_lt
#print axioms LO.FirstOrder.Arithmetic.sigma1_re
#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.universalGraph_uniq
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.exists_selector
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
