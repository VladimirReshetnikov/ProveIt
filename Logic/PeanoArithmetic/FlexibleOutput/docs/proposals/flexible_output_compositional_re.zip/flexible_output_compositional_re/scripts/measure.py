#!/usr/bin/env python3
"""Measure the packaged sources, including every added helper and comment."""
from pathlib import Path
import argparse
import hashlib
import json

PACKAGE = Path(__file__).resolve().parents[1]
FOUNDATION = "lib/FormalizedFormalLogic-Foundation/"


def strip_comments(text):
    """Preserve lines, respect string literals, and support nested Lean comments."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        ch, pair = text[i], text[i:i + 2]
        if depth:
            if pair == "/-":
                depth += 1
                out.extend("  ")
                i += 2
            elif pair == "-/":
                depth -= 1
                out.extend("  ")
                i += 2
            else:
                out.append("\n" if ch == "\n" else " ")
                i += 1
        elif string:
            out.append(ch)
            i += 1
            if ch == "\\" and i < len(text):
                out.append(text[i])
                i += 1
            elif ch == '"':
                string = False
        elif pair == "/-":
            depth = 1
            out.extend("  ")
            i += 2
        elif pair == "--":
            while i < len(text) and text[i] != "\n":
                out.append(" ")
                i += 1
        else:
            if ch == '"':
                string = True
            out.append(ch)
            i += 1
    return "".join(out)


def count(text):
    return {
        "physical_lines": len(text.splitlines()),
        "code_lines": sum(bool(x.strip()) for x in strip_comments(text).splitlines()),
        "bytes": len(text.encode()),
    }


def sum_counts(rows):
    return {k: sum(r[k] for r in rows) for k in ("physical_lines", "code_lines", "bytes")}


def measure():
    manifest = json.loads((PACKAGE / "evidence/change_manifest.json").read_text())
    files = []
    for item in manifest["files"]:
        row = {"path": item["path"], "category": item["category"]}
        for phase, source_dir, hash_key in [("before", "baseline", "before_sha256"),
                                            ("after", "overlay", "after_sha256")]:
            data = (PACKAGE / "sources" / source_dir / item["path"]).read_bytes()
            assert hashlib.sha256(data).hexdigest() == item[hash_key], item["path"]
            row[phase] = count(data.decode())
        files.append(row)
    substantive = [r for r in files if r["category"] == "simplification"]
    totals = {phase: sum_counts([r[phase] for r in substantive]) for phase in ["before", "after"]}
    target = FOUNDATION + "Foundation/FirstOrder/Arithmetic/R0/Representation.lean"
    sigma = {}
    for phase, source_dir in [("before", "baseline"), ("after", "overlay")]:
        text = (PACKAGE / "sources" / source_dir / target).read_text()
        start = text.index("lemma sigma1_re ")
        stop = text.index("\nend\n\nopen Nat.ArithPart₁", start)
        sigma[phase] = count(text[start:stop].rstrip() + "\n")
    closure = json.loads((PACKAGE / "evidence/import_closure_before.json").read_text())
    before_rows, after_rows = [], []
    for item in closure["modules"]:
        before = {"physical_lines": item["physical_lines"],
                  "code_lines": item["nonblank_noncomment_lines"], "bytes": item["bytes"]}
        before_rows.append(before)
        path = (FOUNDATION if item["component"] == "Foundation" else "") + item["repository_path"]
        found = next((r for r in files if r["path"] == path), None)
        if found:
            assert before == found["before"], path
            after_rows.append(found["after"])
        else:
            after_rows.append(before)
    full = {"modules_before": len(before_rows), "modules_after": len(after_rows),
            "before": sum_counts(before_rows), "after": sum_counts(after_rows)}
    return {"files": files, "substantive_files": totals, "sigma1_re": sigma,
            "main_import_closure": full,
            "method": "Code lines exclude blanks and nested Lean comments; all new helper lines are included."}


def write_report(metrics):
    rows = [
        (r"\file{Computability.lean}", metrics["files"][2]),
        (r"\file{Representation.lean}", metrics["files"][3]),
        ("Two changed dependency files", metrics["substantive_files"]),
        (r"\file{sigma1_re} within representation", metrics["sigma1_re"]),
        ("Complete main import closure", metrics["main_import_closure"]),
    ]
    lines = [r"\begin{center}", r"\begin{tabularx}{\linewidth}{Xrrrr}", r"\toprule",
             r"Scope & Old code & New code & Old lines & New lines \\", r"\midrule"]
    for label, row in rows:
        b, a = row["before"], row["after"]
        lines.append(f"{label} & {b['code_lines']:,} & {a['code_lines']:,} & {b['physical_lines']:,} & {a['physical_lines']:,} " + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabularx}", r"\end{center}",
                  "Here ``code'' means nonblank, noncomment source lines, and ``lines'' means all physical lines.",
                  "The two-file byte total decreases from 21,083 to 19,216, including the new modification notices.",
                  "The main import closure still consists of 139 repository modules; the public facade adds one module."])
    (PACKAGE / "report/metrics.tex").write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-report", action="store_true")
    args = parser.parse_args()
    metrics = measure()
    print(json.dumps(metrics, indent=2))
    if args.write_report:
        (PACKAGE / "evidence/source_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
        write_report(metrics)


if __name__ == "__main__":
    main()
