#!/usr/bin/env python3
"""Apply the complete, hash-checked proposal to an initialized ProveIt checkout."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

PACKAGE = Path(__file__).resolve().parents[1]


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository", type=Path)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check", action="store_true", help="Only check prerequisites and file hashes")
    action.add_argument("--apply", action="store_true", help="Write verified replacements after every check passes")
    args = parser.parse_args()
    root = args.repository.resolve()
    manifest = json.loads((PACKAGE / "evidence/change_manifest.json").read_text())
    commit = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
    if commit != manifest["proveit_commit"]:
        sys.exit(f"Wrong repository revision: {commit}; expected {manifest['proveit_commit']}")
    foundation = root / "lib/FormalizedFormalLogic-Foundation"
    commit = subprocess.check_output(["git", "-C", str(foundation), "rev-parse", "HEAD"], text=True).strip()
    if commit != manifest["foundation_commit"]:
        sys.exit(f"Wrong Foundation revision: {commit}; expected {manifest['foundation_commit']}")
    pending = []
    for change in manifest["files"]:
        relative = Path(change["path"])
        source = PACKAGE / "sources/overlay" / relative
        target = root / relative
        new = source.read_bytes()
        if sha256(new) != change["after_sha256"]:
            sys.exit(f"Packaged replacement checksum mismatch: {relative}")
        if not target.is_file():
            sys.exit(f"Required source missing: {target}")
        current = sha256(target.read_bytes())
        if current == change["after_sha256"]:
            print(f"Already applied: {relative}")
        elif current == change["before_sha256"]:
            pending.append((target, new))
            print(f"Ready: {relative}")
        else:
            sys.exit(f"Unrecognized local content; no files written: {relative}")
    if args.apply:
        for target, data in pending:
            target.write_bytes(data)
        print(f"Applied {len(pending)} replacement(s).")
    else:
        print(f"All prerequisites passed; {len(pending)} replacement(s) would be written.")


if __name__ == "__main__":
    main()
