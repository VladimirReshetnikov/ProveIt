lemma forall_lt {R : α × ℕ → Prop} {f : α → ℕ}
    (hR : REPred R) (hf : Computable f) :
    REPred fun a => ∀ i < f a, R (a, i) := by
  refine (Partrec.nat_rec hf (Computable.const ())
    (hR.comp (Computable.fst.pair (Computable.fst.comp Computable.snd))).to₂).dom_re.of_eq fun a => ?_
  induction f a with
  | zero => simp
  | succ n ih =>
    simpa [Part.bind_dom, Part.assert, Nat.forall_lt_succ_right] using
      and_congr ih (Iff.rfl : R (a, n) ↔ R (a, n))
