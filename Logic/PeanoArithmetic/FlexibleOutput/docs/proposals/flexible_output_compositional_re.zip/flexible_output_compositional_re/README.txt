A COMPOSITIONAL SEMIDECISION PROOF FOR FLEXIBLEOUTPUT
Prepared for Vladimir Reshetnikov, November 9, 2026

PROPOSAL

Use the canonical Part.assert recognizer already built into REPred. Shorten
four closure lemmas, add generic computably bounded universal closure, and
rewrite sigma1_re compositionally. The application's mathematical argument,
fixed universal graph, all-input theorem, functionality theorem, and selector
stay intact. This specific proposal is absent from all seven existing
proposal archives at the inspected revision.

Measured changes, including every new helper:
  sigma1_re:                 67 -> 31 code lines
  two Foundation files:     333 -> 300 code lines
                            434 -> 405 physical lines
                         21,083 -> 19,216 bytes
  main repository closure: 30,959 -> 30,926 code lines
                            139 -> 139 modules

"Code lines" excludes blank lines and nested Lean comments. See the report
and evidence/source_metrics.json for complete accounting. The change is a
local simplification, not a large reduction of the entire arithmetic library.

The declaration dependency audit is deliberately reported separately:
  sigma1_re reachable constants:     6,383 -> 6,381
  flexibleOutput reachable constants:16,960 -> 16,970
The main count increases by ten; no smaller complete kernel proof or faster
build is claimed. REPred.iff' and Partrec.merge become unreachable from both
roots. The four shortened RE helpers and the new forall_lt remain reachable.

VERIFICATION

All 140 repository modules in the facade's import closure were recompiled
from source into fresh objects, using cached external-package objects only.
All succeeded. Thirteen axiom audits report exactly propext, Classical.choice,
and Quot.sound. The declaration traversal rejects reachable sorryAx.
Both changed modules and all project modules compile without warnings;
325 warnings came from 34 unmodified Foundation modules. Full evidence is
included. The complete recorded compiler time is 548.652 seconds; this is
validation, not a comparative timing benchmark.

The final report is an 11-page PDF. A later repository recheck at commit
18537dc1ea1a3b6ddd298bef8c5bd32be3917b7a found the relevant Lean subtree,
all seven proposal archives, and Foundation pin unchanged.

PINNED ENVIRONMENT

ProveIt:    ba2909149fc7187814cde87862f6118dceec6801
Foundation: 32e1a0956a8622fad067328ca1959729a7634428
Mathlib:    81a5d257c8e410db227a6665ed08f64fea08e997
Lean:       4.32.0

The pinned ProveIt snapshot has a missing-module import: Main and the facade
import PAFlexibleOutput.Refutations, but the committed file is Provability.
The separate prerequisite patch repairs those two imports. It contributes
zero lines to the measured savings.

CONTENTS

report/flexible_output_compositional_re.tex
report/flexible_output_compositional_re.pdf
  Full mathematical and engineering report, plus generated tables/snippet.

sources/baseline/ and sources/overlay/
  Complete exact original and replacement versions of the four affected
  files, using paths relative to the ProveIt checkout.

patches/01-module-imports.patch
  Apply from the ProveIt root. Repairs only the two imports.

patches/02-foundation-compositional-re.patch
  Apply from lib/FormalizedFormalLogic-Foundation. Changes only two files.

scripts/apply_proposal.py
  Checks both repository revisions and all source hashes before writing.
  Refuses unrecognized local content. Supports already-applied files.

scripts/measure.py
  Recomputes all changed-file and sigma1_re counts, and updates the complete
  import-closure totals from the recorded unchanged-source inventory.

verification/DependencyAudit.lean
  Traverses declaration types and values for sigma1_re and flexibleOutput;
  records reachable constants and axioms, and rejects reachable sorryAx.

verification/CandidateAudit.lean
  Prints axioms for the new/replaced support lemmas and public endpoints.

evidence/
  Source/checksum manifests, seven-archive novelty audit, exact dependency
  inventories, declaration closures, environment pins, and compilation logs.

licenses/ and NOTICE.txt
  Upstream license copies and modification attribution.

APPLY AND BUILD

Use an initialized ProveIt checkout at the exact revision above, with the
Foundation submodule initialized at its pinned revision. From this archive:

  python3 scripts/apply_proposal.py /path/to/ProveIt --check
  python3 scripts/apply_proposal.py /path/to/ProveIt --apply

Then, in the checkout:

  LAKE_JOBS=1 LEAN_NUM_THREADS=0 lake build +PAFlexibleOutput

The patch script performs every preflight check before its first write.
For conventional Git patch application, the equivalent commands are:

  git -C /path/to/ProveIt apply /path/to/archive/patches/01-module-imports.patch
  git -C /path/to/ProveIt/lib/FormalizedFormalLogic-Foundation apply \
      /path/to/archive/patches/02-foundation-compositional-re.patch

Run the audits from the checkout after building. Copy each audit into the
checkout root temporarily, or pass a suitable Lean --root when using an
absolute path outside the project:

  cp /path/to/archive/verification/CandidateAudit.lean CandidateAudit.lean
  lake env lean CandidateAudit.lean
  cp /path/to/archive/verification/DependencyAudit.lean DependencyAudit.lean
  FLEXIBLE_AUDIT_PREFIX=/absolute/path/to/proposed_audit \
      lake env lean DependencyAudit.lean

The resulting files use the prefix followed by a root theorem name and .tsv;
there is also a _summary.tsv file. These are declaration inventories, not
timing or kernel-expression-size measurements.

REBUILD THE REPORT AND RECOUNT

  python3 scripts/measure.py --write-report
  cd report
  pdflatex -interaction=nonstopmode -halt-on-error flexible_output_compositional_re.tex
  pdflatex -interaction=nonstopmode -halt-on-error flexible_output_compositional_re.tex

The measured replacement sources are complete. No project source was moved
to an uncounted helper or a new external dependency. No GitHub mutation was
made; this package is a tested proposal for review and application.
