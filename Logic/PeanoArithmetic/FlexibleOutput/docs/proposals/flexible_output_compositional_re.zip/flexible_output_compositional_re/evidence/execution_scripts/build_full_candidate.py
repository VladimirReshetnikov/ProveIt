#!/usr/bin/env python3
"""Re-elaborate the full repository closure with only external-package objects cached."""
from pathlib import Path
import subprocess, os, json, hashlib, time, re
from audit_closure import strip_comments

HERE=Path(__file__).resolve().parent
ROOT=HERE/'proposed'
base=json.loads((HERE/'environment.json').read_text())
cache=Path('/workspace/scratch/2ad373dbb678/toolchain/project/.lake/packages')
external=sorted(str(p) for p in cache.glob('*/.lake/build/lib/lean'))
env=os.environ.copy()
env.update({k:base[k] for k in ['LD_PRELOAD','LEAN_NUM_THREADS']})
env['LEAN_PATH']=':'.join([str(ROOT)]+external)
compiler=base['compiler']
logdir=HERE/'full-logs';logdir.mkdir(exist_ok=True)
sources={};order=[]
def visit(module):
    if module in sources:return
    p=ROOT/(module.replace('.','/')+'.lean')
    if not p.exists():return
    text=p.read_text();sources[module]=p
    for line in re.finditer(r'^\s*(?:(?:public|private|meta)\s+)*import\s+([^\n]+)',strip_comments(text),re.M):
        for imp in line.group(1).split():visit(imp)
    order.append(module)
visit('PAFlexibleOutput')
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix in ['.olean','.ilean','.ir'] or p.name.endswith(('.olean.private','.olean.server')):
        p.unlink()
(HERE/'full-environment.json').write_text(json.dumps({'compiler':compiler,'LEAN_PATH':env['LEAN_PATH'],
    'LD_PRELOAD':env['LD_PRELOAD'],'LEAN_NUM_THREADS':env['LEAN_NUM_THREADS'],
    'policy':'All 140 in-repository closure modules re-elaborated from source in this invocation. Only external-package objects reused.',
    'order':order},indent=2)+'\n')
results=[]
for i,m in enumerate(order):
    p=sources[m];start=time.monotonic()
    r=subprocess.run([compiler,'-o',str(p.with_suffix('.olean')),'-i',str(p.with_suffix('.ilean')),str(p.relative_to(ROOT))],
       cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (logdir/(m+'.log')).write_text(r.stdout)
    row={'module':m,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),
        'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'log':str((logdir/(m+'.log')).relative_to(HERE))}
    results.append(row);(HERE/'full-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(f'{i+1}/{len(order)} {m} {r.returncode} {row["seconds"]}s',flush=True)
    if r.stdout:print(r.stdout,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
print('FULL CANDIDATE BUILD PASSED',flush=True)
