# Existing proposal audit

Source: ProveIt commit `ba2909149fc7187814cde87862f6118dceec6801`, directory `Logic/PeanoArithmetic/FlexibleOutput/docs/proposals`.

All seven ZIPs were retrieved with the GitHub connector and extracted. Their Git object hashes were recomputed from the actual ZIP bytes and match the source listing. Exact hashes and extracted locations are in `existing_proposal_manifest.json`.

## Coverage matrix

| Archive | Baseline | Implemented ideas | Other ideas explicitly discussed |
| --- | --- | --- | --- |
| `flexible_output_dependency_simplification.zip` | `5ad98b5a50c2c5c4193d56d509181334d65d69e8` | Factor the existing RE selector into `Foundation.Vorspiel.PartrecSelector`; use it in `Partrec.projection` to delete a second dovetailing algorithm and encoding transport. Replace incompleteness imports by D1 in Refutations and InductionSchemeDelta1; prove quotation directly to avoid `substNumerals_app_quote`; provide the concrete equality-subtheory instance. Measures full import and proof-term closures. | Direct graph representation by induction on `Nat.ArithPart₁`, combining Sigma1 correctness and model functionality (checked research prototype); padded universal closures for induction certificates (checked partial lemma, recognizer/equivalence incomplete); external finite derivation enumeration to replace arithmetized provability (sketch, unimplemented). |
| `flexible_output_simplification (1).zip` | `7142f7f52bbd36ede33f2be1a66dfdccc238e255` | Encode `((c,x),y)` once, define a unary Sigma1 query using pairing projections, use `re_iff_sigma1` and pull back along `Computable.encode`; remove custom ternary/vector bridge. Quotation by `congrArg` and vector normalization. Normalize functionality induction goals once. Use existing partial-value domain API. | Upstream selector and PA-minus functionality APIs. |
| `flexible_output_simplification (2).zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Direct consistency-based proof using effective search and recursion theorem; remove custom ArithmeticBridge/model/search records. One no-output contradiction feeds divergence and no-refutation. Normalize composition/minimization functionality proof, use definitional equality and statement conversion, replace finite vector case proof by vector identity. | Generalize direct proof to r.e. consistent arithmetic theories; upstream functionality; uniform generic RE selector; controlled elaboration and term-size benchmarks. |
| `flexible_output_simplification.zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Search refutations of the exact-value sentence `forall y, G(y,c,x) iff y=n`; this obtains the final uniqueness specification directly from completeness, removing the global nonstandard-model functionality induction from the main dependency chain. Direct standard soundness replaces bridge/assembly. Generalize refutation template. Unary search with dummy input introduced only at fixed point. Preserve old API in optional compatibility module. | Explains intensional code semantics, soundness-vs-consistency boundary, and why sequential partial search is invalid. |
| `flexible_output_simplification_2026-11-09.zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Same exact-value singleton search principle; generalized `templateRefutationsRE`; direct standard-model soundness, no bridge. Optional FullAudit retains stronger global functionality. Separate conservative direct-soundness patch retains original search and global functionality. | Alternative source/import accounting and small compiler/search cleanups. |
| `flexible_output_simplification_7142f7f_verified.zip` | `7142f7f52bbd36ede33f2be1a66dfdccc238e255` | Rewrite selector domain by fixed-point equation, then use Part API. Simplify domain calculation in dovetailing. Quoted negation by congruence. Normalize composition case once. | Historical direct bridge elimination is explicitly recognized as already upstream. |
| `pa_flexible_output_simplification.zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Direct contradiction from search output using standard model; remove concrete bridge. Shorten generic MathlibAssembly with a single no-output contradiction. Normalize comp/minimization functionality. Remove redundant selector witnesses and use vector mapping quotation lemma. | Upstream general functionality; generic RE selector; a relation-level diagonal theorem from `R(c,y) -> y notin eval c 0`; term-size and elaboration benchmarks. |

## Relevant source locations inside extracted reports

- `dependency/flexible_output_dependency_simplification/report.tex`: implemented recommendation 61–100; old-proposal comparison 127–166; projection 168–285; D1 import cut and quotation 287–337; research alternatives 516–565.
- `one/flexible_output_simplification/flexible_output_simplification.tex`: unary encoded query 160–208; quotation 210–225; functionality/domain 226–277; useful upstream work 399–405.
- `two/flexible_output_simplification/flexible_output_simplification.tex`: direct proof 135–257; local cleanups 258–335; further questions 463–481.
- `plain/flexible_output_simplification/report/flexible_output_simplification.tex`: full-specification target 133–181; generalized refutability 183–225; theorem proof 227–278; limitations 355–396.
- `dated/flexible_output_simplification/report.tex`: full-specification target 168–235; direct-soundness alternative 439–463.
- `verified/flexible_output_simplification_2026-11-09/report/flexible_output_simplification.tex`: recommendation 82–112; Part API 214–264; quotation/functionality 266–314.
- `pa/pa_flexible_output_simplification/pa_flexible_output_simplification.tex`: direct contradiction 116–216; generic assembly 218–247; functionality 249–314; search/quotation 316–366; relation-level diagonal interface 500–505.

## Novelty restrictions for the new deliverable

Do not claim any of the matrix ideas as a new proposal merely by changing notation, packaging, or the theorem name. In particular, a generalized relation-level diagonal theorem and external proof enumeration have already been explicitly suggested. A complete implementation of a previously incomplete research route can constitute new implementation work, but the underlying proposal must be acknowledged as existing and therefore is a poor fit for the user's strict request not to repeat proposals.

Unaddressed targets appear to be substantial proofs deeper in the representation/definability machinery, different search mechanisms with a genuine dependency benefit, or a distinct syntactic/semantic theorem that removes an entire other route. Any selected target still needs comparison against the actual accompanying Lean research prototypes, not only these report summaries.

## Targeted check: compositional `sigma1_re`

The new candidate replaces the bespoke bounded-universal semidecision argument in `Foundation/FirstOrder/Arithmetic/R0/Representation.lean` (`sigma1_re`, `hBall`) by a general RE bounded-forall closure, and uses `PrimrecPred.computablePred` directly for its atomic branches. This specific candidate is absent from all seven archives, including their research prototypes.

The full extracted text search is recorded in `bounded_re_search.txt`. It searches all Lean, LaTeX, Markdown, text, patch, and Python files for bounded universal/forall/quantifier terminology, `hBall`, `sigma1_re`, `PrimrecPred`, `computablePred`, `Partrec.dom_re`, `Part.assert`, and atomic-case names. The `sigma1_re` matches are calls from existing refutation helpers or descriptions of the dependency route, not changes to its implementation. The prior `Part.assert` simplifications concern selector domains or unchanged RE/domain equivalences. The induction-certificate research discusses syntactic bounded universal formulas, but it does not address the semidecision closure or `sigma1_re` proof.

Consequently this target meets the non-repetition requirement relative to the seven archives at the pinned source commit. Reusing standard APIs is not itself a novelty claim; the new contribution must be stated as a concrete simplification of this distinct transitive proof, with measured code changes including any new helper.

## Targeted check: direct RE combinators

The associated changes to `REPred.const`, `REPred.comp`, `REPred.and`, and `REPred.or` are also absent from all seven archives. Specifically, the new `const` uses `Partrec.const'`; `comp` is direct `Partrec.comp hp hf`; `and` binds the canonical partial-unit computations and proves their equality by `Part.ext`; and `or` uses `Partrec.merge'` and its domain-only specification rather than extracting arbitrary witnesses and applying uniform-output `Partrec.merge`.

The exact relevant search results are in `combinator_novelty_search.txt`. None of the new distinguishing expressions (`merge'`, `Partrec.const'`, `Partrec.comp hp hf`) occurs in the seven archived implementations or research prototypes. More decisively, the entire `namespace REPred` section in the dependency-simplification archive's baseline and overlay copies of `Foundation/Vorspiel/Computability.lean` is byte-identical. That earlier proposal changes projection implementations outside this section and leaves these four combinators untouched.

The prior archives' isolated uses of `Part.assert` do not anticipate this systematic canonical-computation refactor. The novelty claim should nevertheless remain concrete: this is a shorter implementation of existing elementary computability facts, not a new mathematical closure theorem.

## Independent mathematical review of candidate code

Reviewed `validation/re_combinators/Combinators.lean`, `validation/new_repr/BoundedForall.lean`, and `validation/new_repr/RepresentationTest.lean` as present during this audit.

1. **Constant predicates.** `REPred p` is implemented by the canonical partial-unit computation for `p`. A fixed partial constant is partial recursive, so `Partrec.const'` applies. This does not give a uniform algorithm deciding an arbitrary input proposition; the proposition is a fixed mathematical parameter, as in the original classical proof.
2. **Computable pullback.** Composing the canonical semidecision for `p` with a total computable `f` is definitionally the canonical semidecision for `p (f x)`. No arbitrary witness extraction or new correctness transport is required.
3. **Conjunction.** Sequential monadic bind terminates exactly when both semidecisions terminate. Both computations return `Unit`, so equality with the canonical partial computation follows by equality of membership predicates. The `Part.ext` proof checks this equality rather than merely checking one implication about domains.
4. **Disjunction.** `Partrec.merge'` runs a fair merge; its domain is the union of the two input domains. The proof uses this domain guarantee only, so no output-agreement hypothesis is needed. The conclusion is still precisely `p x or q x`.
5. **Bounded universal quantification.** The helper starts at `.some ()` and, at stage `i`, sequentially binds the canonical computation for `R (a,i)`. The step argument projection is `(a,(i,unit)) -> (a,i)`, preserving the parameter and taking the current recursion index. Induction establishes that the stage-`n` domain is exactly `forall i<n, R(a,i)`; at zero both sides are true. A computable bound supplies a partial recursive finite iteration. No unbounded universal closure is asserted.
6. **Arithmetic atoms.** Primitive recursive equality and less-than predicates, composed with the primitive recursive term evaluators, yield computable predicates. Complement is taken only for these decidable predicates, yielding disequality and not-less-than. This does not assume that complements of arbitrary RE predicates are RE.
7. **Formula application.** In the bounded-quantifier branch, the computable map `(v,i) -> i :: v` passes the extended environment to the existing induction hypothesis. `List.Vector.cons_get` identifies the resulting vector semantics with the original bounded-variable semantics. All formula constructors and the theorem statement are preserved.

No mathematical defect was found in these candidate proofs. This review is independent of their compilation; the production report should cite the actual final integrated build and axiom audit separately.
