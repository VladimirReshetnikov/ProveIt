#!/usr/bin/env python3
"""Count the repaired baseline's repository-owned transitive Lean import closure."""
from pathlib import Path
import re, json, hashlib, tomllib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'ProveIt'
FOUNDATION=Path('/workspace/scratch/2ad373dbb678/toolchain/project/lib/FormalizedFormalLogic-Foundation')
LIBRARIES=tomllib.loads((ROOT/'lakefile.toml').read_text())['lean_lib']

def strip_comments(text):
    out=[];i=0;depth=0;string=False
    while i<len(text):
        c=text[i];pair=text[i:i+2]
        if depth:
            if pair=='/-': depth+=1;out.extend('  ');i+=2
            elif pair=='-/': depth-=1;out.extend('  ');i+=2
            else: out.append('\n' if c=='\n' else ' ');i+=1
        elif string:
            out.append(c);i+=1
            if c=='\\' and i<len(text):out.append(text[i]);i+=1
            elif c=='"':string=False
        elif pair=='/-':depth=1;out.extend('  ');i+=2
        elif pair=='--':
            while i<len(text) and text[i]!='\n':out.append(' ');i+=1
        else:
            if c=='"':string=True
            out.append(c);i+=1
    return ''.join(out)

def source_of(module):
    rel=Path(module.replace('.', '/')+'.lean')
    if module.startswith('Foundation.') or module=='Foundation':
        return FOUNDATION/rel
    for lib in LIBRARIES:
        name=lib['name']
        if module==name or module.startswith(name+'.'):
            return ROOT/lib.get('srcDir', '.')/rel
    return None

def audit(root_module):
    rows={};boundary=set();missing=set()
    def visit(m):
        if m in rows or m in boundary or m in missing:return
        p=source_of(m)
        if p is None:boundary.add(m);return
        if not p.exists():missing.add(m);return
        raw=p.read_text();code=strip_comments(raw)
        imports=[]
        for mm in re.finditer(r'^\s*(?:(?:public|private|meta)\s+)*import\s+([^\n]+)',code,re.M):
            imports.extend(mm.group(1).split())
        repaired=['PAFlexibleOutput.Provability' if im=='PAFlexibleOutput.Refutations' else im for im in imports]
        rows[m]={'module':m,'repository_path':str(p.relative_to(FOUNDATION)) if m.startswith('Foundation.') else str(p.relative_to(ROOT)),
                 'component':'Foundation' if m.startswith('Foundation.') else 'ProveIt',
                 'source':str(p),'bytes':len(p.read_bytes()), 'physical_lines':len(raw.splitlines()),
                 'nonblank_noncomment_lines':sum(bool(line.strip()) for line in code.splitlines()),
                 'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'imports':imports,'repaired_imports':repaired}
        for im in repaired:visit(im)
    visit(root_module)
    totals={}
    for group in ['ProveIt','Foundation','all']:
        rs=[r for r in rows.values() if group=='all' or r['component']==group]
        totals[group]={'modules':len(rs),**{k:sum(r[k] for r in rs) for k in ['bytes','physical_lines','nonblank_noncomment_lines']}}
    return {'root_module':root_module,'repair':'Only import PAFlexibleOutput.Refutations -> PAFlexibleOutput.Provability in Main and facade.',
            'totals':totals,'external_import_boundary':sorted(boundary),'missing_after_repair':sorted(missing),
            'modules':sorted(rows.values(),key=lambda r:r['module'])}

for root in ['PAFlexibleOutput.Main','PAFlexibleOutput']:
    result=audit(root)
    (HERE/(root+'.closure.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(root,json.dumps(result['totals']), 'missing',result['missing_after_repair'])
