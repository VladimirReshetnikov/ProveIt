#!/usr/bin/env python3
"""Task-local baseline validation; no writes to the reused dependency cache."""
from pathlib import Path
import subprocess, os, json, hashlib, time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CACHE = Path('/workspace/scratch/2ad373dbb678/toolchain/project')
TOOLCHAIN = CACHE.parent / 'lean-4.32.0-linux'
EXTERNAL = sorted(str(p) for p in (CACHE / '.lake/packages').glob('*/.lake/build/lib/lean'))
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join([str(HERE / 'baseline'), str(HERE / 'vendor')] + EXTERNAL)
env['LD_PRELOAD'] = str(CACHE.parent / 'proc_self_compat.so')
env['LEAN_NUM_THREADS'] = '1'
compiler = TOOLCHAIN / 'bin/lean'
(HERE / 'environment.json').write_text(json.dumps({
    'LEAN_PATH': env['LEAN_PATH'], 'LD_PRELOAD': env['LD_PRELOAD'],
    'LEAN_NUM_THREADS': env['LEAN_NUM_THREADS'], 'compiler': str(compiler),
    'version': subprocess.check_output([str(compiler), '--version'], env=env, text=True).strip(),
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'foundation_commit': '32e1a0956a8622fad067328ca1959729a7634428',
    'mathlib_commit': '81a5d257c8e410db227a6665ed08f64fea08e997',
    'proveit_commit': 'ba2909149fc7187814cde87862f6118dceec6801',
    'cache_policy': 'Only Foundation and external package objects reused. Every PAFlexibleOutput module is compiled in this request.',
}, indent=2) + '\n')
results = []
def run(module, label=None):
    src = HERE / 'baseline' / (module.replace('.', '/') + '.lean')
    start = time.monotonic()
    p = subprocess.run([str(compiler), '-o', str(src.with_suffix('.olean')),
                        '-i', str(src.with_suffix('.ilean')), str(src.relative_to(HERE / 'baseline'))],
                       cwd=HERE / 'baseline', env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = HERE / 'logs' / ((label or module) + '.log')
    log.write_text(p.stdout)
    result = {'module': module, 'label': label, 'exit_code': p.returncode,
              'seconds': round(time.monotonic()-start, 3),
              'source_sha256': hashlib.sha256(src.read_bytes()).hexdigest(),
              'log': str(log.relative_to(HERE))}
    results.append(result)
    (HERE / 'baseline_results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(result), flush=True)
    if p.stdout: print(p.stdout, flush=True)
    return p.returncode

for m in ['PAFlexibleOutput.Halting', 'PAFlexibleOutput.Functionality', 'PAFlexibleOutput.Provability', 'PAFlexibleOutput.Search']:
    if run(m): raise SystemExit(1)
run('PAFlexibleOutput.Main', 'original-main')
for name in ['PAFlexibleOutput/Main.lean', 'PAFlexibleOutput.lean']:
    p=HERE / 'baseline' / name
    txt=p.read_text()
    txt=txt.replace('import PAFlexibleOutput.Refutations', 'import PAFlexibleOutput.Provability')
    p.write_text(txt)
for m in ['PAFlexibleOutput.Main', 'PAFlexibleOutput']:
    if run(m, 'repaired-'+m): raise SystemExit(1)
