# Simplifying the Lean proof of flexible output in PA

This package proposes two separable refactorings of
`PAFlexibleOutput.exists_partrec_flexibleOutput` and its supporting proofs.
The complete explanation is in `pa_flexible_output_simplification.pdf`; its
self-contained LaTeX source is alongside it.

**Both complete profiles have been compiler-checked.** The package's checker
verified the exact source bytes, built the full facade, and compiled the
endpoint audit with exit status zero for each profile. All eight audited
theorems have exactly the axioms `propext`, `Classical.choice`, and `Quot.sound`.
See `validation/STATUS.txt` and the included logs and source-hash metadata.

## Baseline and dependency pins

| Component | Exact version |
| --- | --- |
| ProveIt | `410c820c4faa7620a19ce07f55f43c13e5fbb688` |
| Lean | `leanprover/lean4:v4.32.0` |
| Mathlib | `81a5d257c8e410db227a6665ed08f64fea08e997` |
| Foundation | `32e1a0956a8622fad067328ca1959729a7634428` |

The reviewed project is `Logic/PeanoArithmetic/FlexibleOutput/Lean` in
[VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt/tree/410c820c4faa7620a19ce07f55f43c13e5fbb688/Logic/PeanoArithmetic/FlexibleOutput).

## Choose a profile

**Local profile:** apply `patches/01-local-simplifications.patch` only.
This simplifies `Functionality`, `MathlibAssembly`, `Search`, and `Refutations`.
Every public declaration, theorem statement, and computational definition is
preserved. The whole nine-module project decreases from 568 to 509 nonblank,
noncomment source lines.

**Direct profile:** apply both patches, in order. The second patch replaces
the concrete PA assembly by a direct standard-model argument and updates the
facade's description. The whole project decreases to 486 active lines.
The six public endpoint statements and all graph/value definitions stay the
same. Three public adapters are removed: `PAModel`, `paBridge`, and
`exists_searchImplementation`. Code using those adapters must use the local
profile or be adjusted.

The direct argument uses soundness in the standard model, available for the
unconditional concrete PA theorem. The abstract consistency-only theorem is
retained, with a shorter proof, in `MathlibAssembly`. The direct proof should
not be described as a new consistency-only generalization.

The complete `Lean/` tree contains the **direct** profile. For the local
profile, apply patch 1 to the original checkout instead of copying that tree.

## What the simplifications do

1. Express the fixed-point contradiction as `noSearch`: the search cannot
   return any output. Rewriting by the fixed-point equation then handles
   divergence at every input without manually composing function equalities.
2. Normalize the semantics of composition and minimization once at the start
   of each functionality induction case, then reason directly about tuples
   and the linear order of the model.
3. Keep the existing dovetailing search algorithm and pass its witnesses
   directly to the relevant option/domain lemmas.
4. Replace three explicit `Fin` cases in `subst_quote` with the existing
   `Matrix.comp_vecCons'` lemma and the natural-number cast normalization.
5. Optionally remove bridge packaging from the concrete PA proof by using
   `standardCorrectness`, standard-model soundness, and completeness directly.

No change is made to `universalGraph`, the arithmetical coding, the actual
dovetailing algorithm, or the meaning of `ValueIn` for nonstandard elements.

## Validate in an isolated worktree

Run these commands from an existing ProveIt checkout. Substitute the actual
absolute paths for `FLEX_PACKAGE` and `FLEX_REVIEW`. Keep the review path
outside the existing worktree.

```bash
FLEX_PACKAGE=/absolute/path/to/pa_flexible_output_simplification
FLEX_REVIEW=/absolute/path/to/ProveIt-flexible-output-review
git worktree add --detach "$FLEX_REVIEW" 410c820c4faa7620a19ce07f55f43c13e5fbb688
git -C "$FLEX_REVIEW" submodule update --init lib/FormalizedFormalLogic-Foundation
git -C "$FLEX_REVIEW" apply --check "$FLEX_PACKAGE/patches/01-local-simplifications.patch"
git -C "$FLEX_REVIEW" apply "$FLEX_PACKAGE/patches/01-local-simplifications.patch"
```

For the local profile:

```bash
bash "$FLEX_PACKAGE/scripts/check.sh" "$FLEX_REVIEW" local
```

For the direct profile, apply the second patch before checking:

```bash
git -C "$FLEX_REVIEW" apply --check "$FLEX_PACKAGE/patches/02-direct-pa-proof.patch"
git -C "$FLEX_REVIEW" apply "$FLEX_PACKAGE/patches/02-direct-pa-proof.patch"
bash "$FLEX_PACKAGE/scripts/check.sh" "$FLEX_REVIEW" direct
```

The check script verifies the exact expected project source bytes, builds
`+PAFlexibleOutput`, and runs `Audit.lean`. It sets the serial settings used
for this project (`LAKE_JOBS=1`, `LEAN_NUM_THREADS=0`). It does not apply
patches. A working Lean installation and the normal pinned repository
dependencies are required. If obtaining a fresh Mathlib checkout, its normal
`lake exe cache get` command can populate compiled dependency caches.

`Audit.lean` checks the exact advertised main theorem type and prints axiom
dependencies for the endpoints and supporting results. Final build outcomes
and full logs are under `validation/`.

## Reproduce measurements and the report

```bash
cd "$FLEX_PACKAGE"
python3 scripts/measure.py
bash scripts/build_pdf.sh
```

The Python script uses only the standard library. It strips nested Lean block
comments and line comments while protecting strings. It verifies all 40
retained theorem/lemma headers, the exact unchanged `Statement.lean`, and the
absence of `sorry`, `admit`, added `axiom`, and `native_decide` tokens. It writes
`metrics.json`. These are source metrics, not kernel proof-term or speed
measurements.

The PDF requires a normal pdfLaTeX/latexmk installation with the standard
packages listed in its preamble. No external images or bibliography database
are needed.

## Files

| Path | Contents |
| --- | --- |
| `pa_flexible_output_simplification.tex` / `.pdf` | Self-contained report, mathematical argument, exact Lean excerpts, measurements, limitations, and further research questions |
| `Lean/` | All nine project modules in the direct profile |
| `original/` | All nine original project modules, preserved byte-for-byte |
| `patches/01-local-simplifications.patch` | Interface-preserving proof changes |
| `patches/02-direct-pa-proof.patch` | Optional concrete PA simplification and facade comment update |
| `Audit.lean` | Exact endpoint type checks and axiom audit |
| `scripts/check.sh` | Recheck a patched checkout |
| `scripts/measure.py` / `metrics.json` | Reproducible source measurements and theorem-header checks |
| `scripts/build_pdf.sh` | Recompile the report |
| `provenance.json` | Repository pins and source hashes |
| `validation/` | Build and axiom-audit records |
| `SHA256SUMS` | Integrity manifest for the package contents |

Some unchanged source files retain their original delivery-era comments
saying their original author lacked a Lean executable. Those comments are
historical; the current package's verification status is stated in
`validation/STATUS.txt` and its build logs.
