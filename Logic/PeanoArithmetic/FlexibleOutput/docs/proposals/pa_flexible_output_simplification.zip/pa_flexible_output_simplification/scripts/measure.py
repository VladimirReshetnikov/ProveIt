#!/usr/bin/env python3
"""Reproduce source metrics and check preserved theorem signatures.

Counts nonblank physical lines after deleting nested Lean block comments and
line comments. String literals are protected. This measures source size,
not kernel proof-term size, elaboration time, or mathematical complexity.
"""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]


def uncomment(text):
    result = []
    depth = 0
    line_comment = False
    quoted = False
    escaped = False
    i = 0
    while i < len(text):
        c, pair = text[i], text[i:i + 2]
        if line_comment:
            if c == '\n':
                result.append(c)
                line_comment = False
            i += 1
        elif depth:
            if pair == '/-':
                depth += 1
                i += 2
            elif pair == '-/':
                depth -= 1
                i += 2
            else:
                if c == '\n':
                    result.append(c)
                i += 1
        elif quoted:
            result.append(c)
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == '"':
                quoted = False
            i += 1
        elif pair == '--':
            line_comment = True
            i += 2
        elif pair == '/-':
            result.append(' ')
            depth = 1
            i += 2
        else:
            result.append(c)
            quoted = c == '"'
            i += 1
    assert depth == 0 and not quoted, 'Unclosed comment or string'
    return ''.join(result)


def count(text):
    return sum(bool(line.strip()) for line in uncomment(text).splitlines())


DECL = re.compile(r'^(?:theorem|lemma)\s+([^\s(:]+)', re.M)
BOUNDARY = re.compile(
    r'^(?:(?:noncomputable\s+)?(?:theorem|lemma|def|abbrev|structure)\s|end\b|#)',
    re.M,
)


def theorem_headers(text):
    clean = uncomment(text)
    return {
        m.group(1): ' '.join(clean[m.start():clean.index(':=', m.end())].split())
        for m in DECL.finditer(clean)
    }


def proof_lines(text, name):
    clean = uncomment(text)
    start = next(m for m in DECL.finditer(clean) if m.group(1) == name)
    body_start = clean.index(':=', start.end()) + 2
    stop = BOUNDARY.search(clean, body_start)
    body = clean[body_start:stop.start() if stop else len(clean)].strip()
    if body.startswith('by'):
        body = body[2:].lstrip()
    return sum(bool(line.strip()) for line in body.splitlines())


def main():
    rows = []
    header_count = 0
    old_sources, new_sources = {}, {}
    for old_path in sorted((ROOT / 'original').rglob('*.lean')):
        rel = old_path.relative_to(ROOT / 'original')
        new_path = ROOT / 'Lean' / rel
        old, new = old_path.read_text(), new_path.read_text()
        module = '.'.join(rel.with_suffix('').parts)
        old_sources[module], new_sources[module] = old, new
        oh, nh = theorem_headers(old), theorem_headers(new)
        removed = set(oh) - set(nh)
        expected_removed = {'exists_searchImplementation'} if rel.name == 'Main.lean' else set()
        assert removed == expected_removed, (rel, removed)
        assert not (set(nh) - set(oh)), (rel, 'Unexpected new theorem')
        for name in nh:
            assert oh[name] == nh[name], (rel, name, 'Changed theorem signature')
            header_count += 1
        assert not re.search(r'\b(?:sorry|axiom|native_decide|admit)\b', uncomment(new)), rel
        rows.append({'file': str(rel), 'before': count(old), 'after': count(new),
                     'saved': count(old) - count(new)})

    proof_rows = []
    for filename, name in [
        ('MathlibAssembly.lean', 'exists_program_with_arbitrary_possible_output'),
        ('Search.lean', 'exists_search'),
        ('Refutations.lean', 'subst_quote'),
        ('Functionality.lean', 'codeAux_uniq'),
    ]:
        rel = Path('PAFlexibleOutput') / filename
        before = proof_lines((ROOT / 'original' / rel).read_text(), name)
        after = proof_lines((ROOT / 'Lean' / rel).read_text(), name)
        proof_rows.append({'theorem': name, 'before': before, 'after': after,
                           'saved': before - after})

    before = sum(r['before'] for r in rows)
    after = sum(r['after'] for r in rows)
    main_saved = next(r['saved'] for r in rows if r['file'].endswith('/Main.lean'))

    def local_import_closure(sources):
        found, pending = set(), ['PAFlexibleOutput.Main']
        while pending:
            module = pending.pop()
            if module in found:
                continue
            found.add(module)
            imports = re.findall(r'^import\s+(\S+)', uncomment(sources[module]), re.M)
            pending.extend(dep for dep in imports if dep in sources and dep not in found)
        return {'modules': sorted(found), 'source_lines': sum(count(sources[m]) for m in found)}

    local_sources = dict(new_sources)
    local_sources['PAFlexibleOutput.Main'] = old_sources['PAFlexibleOutput.Main']
    result = {
        'metric': 'nonblank physical source lines after deleting Lean comments',
        'files': rows,
        'proof_bodies': proof_rows,
        'whole_project': {
            'before': before, 'local_patch_after': after + main_saved,
            'combined_after': after, 'local_saved': before - after - main_saved,
            'combined_saved': before - after,
        },
        'project_module_import_closure_of_Main': {
            'original': local_import_closure(old_sources),
            'local_patch': local_import_closure(local_sources),
            'combined': local_import_closure(new_sources),
        },
        'unchanged_theorem_signatures': header_count,
        'removed_adapters_in_direct_patch': ['PAModel', 'paBridge', 'exists_searchImplementation'],
        'statement_module_identical': (ROOT / 'original/PAFlexibleOutput/Statement.lean').read_bytes()
            == (ROOT / 'Lean/PAFlexibleOutput/Statement.lean').read_bytes(),
    }
    assert result['statement_module_identical']
    path = ROOT / 'metrics.json'
    path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
