#!/usr/bin/env bash
# Run after applying the desired patch(es) to a checkout at the pinned revision.
set -euo pipefail
if [[ $# -ne 2 || ( "$2" != local && "$2" != direct ) ]]; then
  echo "Usage: $0 /absolute/path/to/ProveIt local|direct" >&2
  exit 2
fi
artifact_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
repo_root="$(cd -- "$1" && pwd)"
profile="$2"
python3 - "$artifact_root" "$repo_root" "$profile" <<'PY'
from pathlib import Path
import sys
artifact, repo, profile = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
target = repo / 'Logic/PeanoArithmetic/FlexibleOutput/Lean'
for source in (artifact / 'Lean').rglob('*.lean'):
    rel = source.relative_to(artifact / 'Lean')
    if profile == 'local' and rel.as_posix() in {
        'PAFlexibleOutput/Main.lean', 'PAFlexibleOutput.lean'
    }:
        source = artifact / 'original' / rel
    destination = target / rel
    if not destination.is_file() or source.read_bytes() != destination.read_bytes():
        raise SystemExit(f'Source mismatch: {destination}; apply the selected package patches first.')
print(f'Exact delivered source profile verified: {profile}')
PY
cd -- "$repo_root"
export LAKE_JOBS=1
export LEAN_NUM_THREADS=0
lake --version
lake env lean --version
lake build +PAFlexibleOutput
lake env lean "$artifact_root/Audit.lean"
