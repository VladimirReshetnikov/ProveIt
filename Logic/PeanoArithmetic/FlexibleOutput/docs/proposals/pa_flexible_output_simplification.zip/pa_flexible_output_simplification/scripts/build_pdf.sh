#!/usr/bin/env bash
set -euo pipefail
artifact_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd -- "$artifact_root"
latexmk -pdf -interaction=nonstopmode -halt-on-error pa_flexible_output_simplification.tex
