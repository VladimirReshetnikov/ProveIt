import Mathlib.Computability.PartrecCode

/-!
# Assembly using Mathlib's Kleene recursion theorem

This generic version takes the arithmetic bridge and a partial-recursive proof search
as explicit parameters. It uses consistency and finite-computation adequacy; no
standard-model soundness hypothesis is required.

The recursion theorem is `Nat.Partrec.Code.fixed_point₂`. The contradiction is stated
directly as absence of an output from `S.search e 0`, so function-equality transport
reduces to `simpa only`.

The concrete PA theorem is in `PAFlexibleOutput.Main`. The replacement source and its
public theorem types were checked with Lean 4.32.0 and the project's pinned Mathlib.
See the accompanying validation logs for the complete endpoint audit.
-/

namespace FlexibleOutputMathlib

universe u v

abbrev Code := Nat.Partrec.Code

/-- The arithmetic/logic bridge to be instantiated for first-order PA. -/
structure ArithmeticBridge where
  Sentence : Type u
  Model : Type v
  halts : Code → ℕ → ℕ → Sentence
  neg : Sentence → Sentence
  provable : Sentence → Prop
  isModel : Model → Prop
  realizes : Model → Sentence → Prop
  consistent : ∀ p, provable p → provable (neg p) → False
  finiteComputation : ∀ {e : Code} {x y : ℕ},
    y ∈ Nat.Partrec.Code.eval e x → provable (halts e x y)
  modelOfUnrefuted : ∀ p,
    (¬ provable (neg p)) → ∃ M, isModel M ∧ realizes M p

/--
The non-self-referential search operation. For a supplied code `c`, ignore
the ordinary input and enumerate proofs until finding one of
`¬ halts c 0 y`; return that `y`.

No fixed-point assumption appears here. The search takes the code to mention
as an ordinary parameter, so its effectivity is a direct composition of
proof enumeration, syntax construction, and unbounded search.
-/
structure SearchImplementation (A : ArithmeticBridge.{u, v}) where
  search : Code → ℕ →. ℕ
  partialRecursive : Partrec₂ search
  ignoresInput : ∀ c x, search c x = search c 0
  returnsRefutation : ∀ {c : Code} {x y : ℕ},
    y ∈ search c x → A.provable (A.neg (A.halts c 0 y))
  findsRefutation : ∀ {c : Code},
    (∃ n, A.provable (A.neg (A.halts c 0 n))) →
      ∃ m, m ∈ search c 0

variable {A : ArithmeticBridge.{u, v}}

/--
Kleene self-reference plus consistency gives a standard nowhere-defined
partial recursive program with every standard output possible in a model.

The output obtained from `findsRefutation` is allowed to be different from
the number in the proof that triggered the existence argument. This is
essential: proof search returns the first accepted proof.
-/
theorem exists_program_with_arbitrary_possible_output
    (S : SearchImplementation A) :
    ∃ e : Code,
      Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x y, ¬ y ∈ Nat.Partrec.Code.eval e x) ∧
      (∀ n, ∃ M, A.isModel M ∧ A.realizes M (A.halts e 0 n)) := by
  obtain ⟨e, he⟩ := Nat.Partrec.Code.fixed_point₂ S.partialRecursive
  have noSearch : ∀ y, y ∉ S.search e 0 := by
    intro y hy
    exact A.consistent (A.halts e 0 y)
      (A.finiteComputation (by simpa only [he] using hy))
      (S.returnsRefutation hy)
  refine ⟨e, Nat.Partrec.Code.eval_part.comp (Computable.const e) Computable.id, ?_, ?_⟩
  · intro x y hy
    exact noSearch y (by simpa only [he, S.ignoresInput] using hy)
  · intro n
    apply A.modelOfUnrefuted
    intro hn
    obtain ⟨m, hm⟩ := S.findsRefutation ⟨n, hn⟩
    exact noSearch m hm

/-- The same conclusion with the external partial function explicitly named. -/
theorem exists_partial_function_with_arbitrary_possible_output
    (S : SearchImplementation A) :
    ∃ (f : ℕ →. ℕ) (e : Code),
      f = Nat.Partrec.Code.eval e ∧
      Partrec f ∧
      (∀ x y, ¬ y ∈ f x) ∧
      (∀ n, ∃ M, A.isModel M ∧ A.realizes M (A.halts e 0 n)) := by
  obtain ⟨e, hrec, hdiv, hmodels⟩ :=
    exists_program_with_arbitrary_possible_output S
  exact ⟨Nat.Partrec.Code.eval e, e, rfl, hrec, hdiv, hmodels⟩

#print axioms exists_program_with_arbitrary_possible_output
#print axioms exists_partial_function_with_arbitrary_possible_output

end FlexibleOutputMathlib
