import PAFlexibleOutput.Main
import PAFlexibleOutput.MathlibAssembly

set_option autoImplicit false

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

-- Check the exact advertised endpoint, including one fixed graph and `none`.
example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : PAFlexibleOutput.Code,
      Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        PAFlexibleOutput.ValueIn M e o :=
  PAFlexibleOutput.exists_partrec_flexibleOutput

example : PAFlexibleOutput.FullySpecifiedMainClaim :=
  PAFlexibleOutput.fullySpecifiedMainClaim

#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutputValue
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
#print axioms PAFlexibleOutput.fullySpecifiedMainClaim
#print axioms PAFlexibleOutput.functionalityInPAModels
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.exists_search
#print axioms FlexibleOutputMathlib.exists_program_with_arbitrary_possible_output
