#!/usr/bin/env python3
"""Compare direct Lean elaboration in two already-built ProveIt checkouts."""
import argparse
import json
import os
from pathlib import Path
import statistics
import subprocess
import tempfile
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('baseline_checkout', type=Path)
parser.add_argument('proposed_checkout', type=Path)
parser.add_argument('--runs', type=int, default=3)
args = parser.parse_args()
if args.runs < 1:
    parser.error('--runs must be positive')

profiles = {}
relative_source = Path('Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Functionality.lean')
for label, checkout in [('baseline', args.baseline_checkout), ('combined', args.proposed_checkout)]:
    checkout = checkout.resolve()
    def capture(*command):
        return subprocess.check_output(command, cwd=checkout, text=True).strip()
    prefix = capture('lake', 'env', 'lean', '--print-prefix')
    lean_path = capture('lake', 'env', 'printenv', 'LEAN_PATH')
    # Make relative search paths independent of the source-directory cwd.
    lean_path = os.pathsep.join(str((checkout / p).resolve()) if not Path(p).is_absolute() else p
                                for p in lean_path.split(os.pathsep) if p)
    env = os.environ.copy()
    env.update(LEAN_PATH=lean_path, LEAN_NUM_THREADS='1')
    profiles[label] = (Path(prefix) / 'bin/lean', checkout / relative_source, env)

rows = []
with tempfile.TemporaryDirectory(prefix='flexible-output-timing-') as temp:
    for iteration in range(args.runs):
        order = ['baseline', 'combined'] if iteration % 2 == 0 else ['combined', 'baseline']
        for label in order:
            lean, source, env = profiles[label]
            destination = Path(temp) / (label + '.olean')
            start = time.monotonic()
            result = subprocess.run([str(lean), '-o', str(destination), str(source)],
                                    cwd=source.parents[1], env=env, text=True, capture_output=True)
            elapsed = time.monotonic() - start
            if result.returncode:
                raise RuntimeError(result.stdout + result.stderr)
            rows.append({'iteration': iteration + 1, 'profile': label,
                         'seconds': round(elapsed, 3), 'returncode': result.returncode})
print(json.dumps({'scope': 'Direct module elaboration with prebuilt imports; not a clean build',
                  'runs': rows,
                  'median_seconds': {label: statistics.median(x['seconds'] for x in rows
                                                              if x['profile'] == label)
                                     for label in profiles}}, indent=2))
