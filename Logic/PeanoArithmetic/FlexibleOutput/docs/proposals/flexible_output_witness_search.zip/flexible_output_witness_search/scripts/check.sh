#!/usr/bin/env bash
set -euo pipefail
# Run from a prepared checkout after applying one of the supplied patch profiles.
project_root="${1:-.}"
archive_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
export LAKE_JOBS=1
export LEAN_NUM_THREADS=1
lake env lean --version
for module in PAFlexibleOutput.Halting PAFlexibleOutput.Search PAFlexibleOutput.Functionality PAFlexibleOutput.Provability PAFlexibleOutput.Main PAFlexibleOutput; do
  lake build "+$module"
done
lake env lean "$archive_root/verification/Audit.lean"
