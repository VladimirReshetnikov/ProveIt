#!/usr/bin/env python3
"""Reproduce source-size measurements; no third-party Python dependencies."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]


def strip_comments(text):
    """Remove nested Lean comments, preserving newlines and string literals."""
    out = []
    i = depth = 0
    quoted = False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                depth += 1
                i += 2
            elif text.startswith('-/', i):
                depth -= 1
                i += 2
            else:
                out.append('\n' if text[i] == '\n' else ' ')
                i += 1
        elif quoted:
            out.append(text[i])
            if text[i] == '\\' and i + 1 < len(text):
                out.append(text[i + 1])
                i += 2
            else:
                quoted = text[i] != '"'
                i += 1
        elif text.startswith('/-', i):
            depth = 1
            out.append(' ')
            i += 2
        elif text.startswith('--', i):
            end = text.find('\n', i)
            i = len(text) if end == -1 else end
        else:
            quoted = text[i] == '"'
            out.append(text[i])
            i += 1
    if depth:
        raise ValueError('Unterminated Lean block comment')
    return ''.join(out)


def count(text):
    clean = strip_comments(text)
    return {
        'physical_lines': len(text.splitlines()),
        'active_lines': sum(bool(s.strip()) for s in clean.splitlines()),
        'nonspace_characters': sum(not c.isspace() for c in clean),
        'utf8_bytes': len(text.encode()),
        'sha256': hashlib.sha256(text.encode()).hexdigest(),
    }


def body(text, theorem, next_marker):
    start = text.index(theorem)
    start = text.index(':= by', start) + len(':= by')
    return text[start:text.index(next_marker, start)]


def profile(directory):
    files = {str(p.relative_to(directory)): count(p.read_text())
             for p in sorted(directory.rglob('*.lean'))}
    totals = {key: sum(d[key] for d in files.values())
              for key in ['physical_lines', 'active_lines', 'nonspace_characters', 'utf8_bytes']}
    proofs = {}
    for file, theorem, end in [
        ('PAFlexibleOutput/Search.lean', 'theorem exists_selector', '#print axioms'),
        ('PAFlexibleOutput/Functionality.lean', 'lemma codeAux_uniq', '/-- The representing formula'),
    ]:
        proofs[theorem.split()[-1]] = count(body((directory / file).read_text(), theorem, end))
    return {'files': files, 'totals_six_modules': totals, 'proof_bodies': proofs}


def main():
    baseline = ROOT / 'baseline'
    proposed = ROOT / 'Lean'
    # Statements, imports, and unchanged modules are checked independently of metrics.
    for name, marker in [('Search', 'theorem exists_selector'), ('Functionality', 'lemma codeAux_uniq')]:
        a = (baseline / 'PAFlexibleOutput' / (name + '.lean')).read_text()
        b = (proposed / 'PAFlexibleOutput' / (name + '.lean')).read_text()
        header = lambda s: re.sub(r'\s+', '', s[s.index(marker):s.index(':= by', s.index(marker))])
        assert header(a) == header(b), name + ' changed its theorem statement'
        imports = lambda s: re.findall(r'^import .*$', s, re.M)
        assert imports(a) == imports(b), name + ' changed its imports'
    for name in ['PAFlexibleOutput/Halting.lean', 'PAFlexibleOutput/Provability.lean',
                 'PAFlexibleOutput/Main.lean', 'PAFlexibleOutput.lean']:
        a = (baseline / name).read_text().replace(
            'import PAFlexibleOutput.Refutations', 'import PAFlexibleOutput.Provability')
        assert a == (proposed / name).read_text(), name + ' has an unexpected change'
    forbidden = re.compile(r'\b(?:sorry|admit|axiom|native_decide)\b')
    for p in proposed.rglob('*.lean'):
        assert not forbidden.search(strip_comments(p.read_text())), 'Unexpected proof escape: ' + str(p)
    result = {'baseline': profile(baseline), 'combined': profile(proposed),
              'checks': {'theorem_statements_unchanged': True, 'imports_unchanged': True,
                         'other_sources_unchanged_except_import_repair': True,
                         'no_sorry_admit_axiom_native_decide': True},
              'interpretation': 'Source counts only. Baseline import repair has zero source-size credit. '
                                'External dependencies and the transitive import graph are unchanged.'}
    (ROOT / 'evidence' / 'source-metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
