import PAFlexibleOutput

open Lean Elab Command

-- This is a diagnostic of each declaration's own stored expression.
-- Repeated subtrees are counted repeatedly; referenced constants are atomic.
run_cmd do
  for n in [``PAFlexibleOutput.exists_selector,
      ``PAFlexibleOutput.codeAux_uniq,
      ``PAFlexibleOutput.flexibleOutput,
      ``PAFlexibleOutput.flexibleOutput_satisfiable,
      ``PAFlexibleOutput.exists_partrec_flexibleOutput] do
    let ci ← getConstInfo n
    logInfo m!"{n}: {(ci.value! true).sizeWithoutSharing}"

#print axioms PAFlexibleOutput.exists_selector
#print axioms PAFlexibleOutput.codeAux_uniq
#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.universalGraph_sigma_one
#print axioms PAFlexibleOutput.valueIn_of_models
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
