RETURN THE WITNESS BEFORE COMPILATION
Verified Lean simplification proposal, 9 November 2026

BASELINE
Repository: https://github.com/VladimirReshetnikov/ProveIt
Revision: 52a9bb875b6e4026a79c8f53906d71602c11afee
Lean: 4.32.0
Mathlib: 81a5d257c8e410db227a6665ed08f64fea08e997
Foundation: 32e1a0956a8622fad067328ca1959729a7634428

WHAT TO READ
report.pdf and report.tex contain the full proposal, proof explanation,
comparison with all six previous archives, measurements, verification limits,
and further research questions.

TWO INDEPENDENT CHANGES
1. Search.lean: compile a semidecider that already returns the candidate.
   The selector proof shrinks from 23 to 14 active lines. Against the best
   earlier same-interface Search proposal, it shrinks from 17 to 14.
2. Optional Functionality.lean: one shared normalization and restricted
   grind-only call replace handwritten constructor cases. The proof body
   shrinks from 21 to 4 active lines (earlier same-interface best: 17).
   Its measured elaboration time is higher; see report and timing JSON.

The same theorem statements, inputs, model assumptions, definitions, and
imports are preserved. The selector may choose a different valid witness or
program code; its existing existential contract allows this.

BASELINE REPAIR
The pinned revision has Provability.lean, but Main.lean and the facade still
import Refutations. Apply 00-import-repair.patch first. This pre-existing
import repair is not counted as a novel simplification.

CONTENTS
Lean/                     All six replacement modules, combined profile
baseline/                 Exact original six module sources from the commit
patches/00-import-repair.patch
patches/01-witness-search.patch
patches/02-functionality-grind.patch
patches/all.patch          The three disjoint patches combined
scripts/check.sh          Build project modules and run axiom/expression audit
scripts/measure.py        Reproduce baseline/proposed source counts; Python 3
scripts/time_functionality.py
                          Optional paired direct-elaboration comparison
verification/Audit.lean    Nine axiom audits and five expression-size diagnostics
verification/baseline/    Baseline compilation and audit logs
verification/combined/    Final combined compilation and audit logs
verification/functionality-timings.json
evidence/                 Provenance, prior-work inventory and independent reviews
report/                   Source snippets, timing paragraph, and PDF build log
SHA256SUMS                 Archive-member integrity manifest (excludes itself)

APPLY TO AN EXISTING CHECKOUT
First check out the exact baseline and prepare its pinned dependencies.
From the repository root, replacing /path/to/archive with this directory:

  git apply --check /path/to/archive/patches/all.patch
  git apply /path/to/archive/patches/all.patch
  bash /path/to/archive/scripts/check.sh .

The above applies both simplifications. To apply only the principal search
proposal, use 00-import-repair.patch followed by 01-witness-search.patch.
The optional functionality patch is independent of the search patch.
The original Main proof is unchanged apart from its import repair.
Avoid applying the combined patch after the component patches.

REPRODUCE METRICS
From this archive directory:

  python3 scripts/measure.py

For paired timings, prepare and build separate baseline and proposed
checkouts, with the import repair applied on both sides. Then run:

  python3 scripts/time_functionality.py /path/to/baseline /path/to/proposed

The timing script resolves the toolchain and import paths through Lake,
then invokes the Lean compiler directly three times per profile. It measures
module elaboration with prebuilt dependencies, not an entire clean build
or standalone kernel verification. Results depend on hardware and load.

REBUILD REPORT
Use XeLaTeX with P052, DejaVu Sans and DejaVu Sans Mono fonts:

  xelatex -interaction=nonstopmode -halt-on-error report.tex
  xelatex -interaction=nonstopmode -halt-on-error report.tex

VERIFICATION SCOPE
All six final project modules were freshly elaborated in a separate output
directory against prebuilt dependency artifacts at the exact repository
pins. All nine axiom reports show only propext, Classical.choice, Quot.sound.
No sorry, admit, new axiom or native_decide occurs in the replacement code.
The entire Mathlib/Foundation dependency tree was not rebuilt from scratch.
The archive contains source and evidence, not platform-specific Lean objects.

Expression-size diagnostics use Expr.sizeWithoutSharing: repeated subtrees
count repeatedly and referenced constants are atomic. The selector has
shorter source but a slightly larger own expression. The functionality
expression is smaller, although its elaboration takes longer.

NOVELTY BOUNDARY
All six archives under the specified docs/proposals directory at the pinned
revision were reviewed, including their future-work sections. Earlier
selector domain cleanup, per-case semantic normalization, full-value search,
direct soundness proofs, and unary refutation coding are not claimed anew.
The new search change is payload production before compilation. The optional
new functionality change is uniform restricted automation over all induction
cases. The report gives separate comparisons against the best prior versions.
