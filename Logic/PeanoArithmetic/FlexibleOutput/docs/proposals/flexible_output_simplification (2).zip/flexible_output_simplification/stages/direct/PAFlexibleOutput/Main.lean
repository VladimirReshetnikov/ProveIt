import PAFlexibleOutput.Arithmetization
import PAFlexibleOutput.Functionality
import PAFlexibleOutput.Refutations
import PAFlexibleOutput.Search

/-!
# A divergent program whose every output is possible in a model of `𝗣𝗔`

The main theorem of the project. There is a partial recursive function `f : ℕ →. ℕ`, given by a
program `e`, such that for every `o : Option ℕ` some model of `𝗣𝗔` satisfies "`f 0 = o`":

* for `o = some n` the model satisfies the halting sentence `haltSentence e 0 n`, and `n` is
  then the *only* output of `e` on input `0` in that model;
* for `o = none` the model satisfies `divergeSentence e 0`: no element of the model is an
  output. The standard model `ℕ` is such a model, because `e` really diverges.

## Statements

* `flexibleOutput`: the sentence form, with `outputSentence e o`.
* `flexibleOutputValue`: the semantic form, with `ValueIn M e o`, which says that the value of
  `e` on input `0` computed inside `M` is `o`.
* `exists_partrec_flexibleOutput`: the same, stated for the partial recursive function.
* `mainClaim`, `strongClaim`, `fullySpecifiedMainClaim`: the three propositions named in
  `PAFlexibleOutput.Statement`.

## Proof

Use `exists_search refutationsRE` and `Nat.Partrec.Code.fixed_point₂` directly. A search
output would give both a PA refutation and, by `finiteProofAdequacy`, a PA proof of the same
halting sentence. The existing `Consistent 𝗣𝗔` instance rules this out. Consequently the
program diverges and PA refutes none of its numerical outputs; `Arithmetic.complete` then
supplies a model for each such output.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

/-! ## The sentence form -/

/-- The sentence "the value of program `e` on input `0` is `o`": the halting sentence for
`o = some n`, the divergence sentence for `o = none`. -/
noncomputable def outputSentence (e : Code) : Option ℕ → ArithmeticSentence
  | some n => haltSentence e 0 n
  | none => divergeSentence e 0

/-- **Main theorem, sentence form.** There is a program `e` that diverges on every input, such
that for every `o : Option ℕ` some model of `𝗣𝗔` satisfies "the value of `e` on input `0` is
`o`". -/
theorem flexibleOutput :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        M↓[ℒₒᵣ] ⊧ outputSentence e o := by
  obtain ⟨search, hpart, hign, hsound, hcomplete⟩ := exists_search refutationsRE
  obtain ⟨e, he⟩ := Nat.Partrec.Code.fixed_point₂ hpart
  have noOutput (y : ℕ) : y ∉ search e 0 := by
    intro hy
    have hy' : y ∈ Nat.Partrec.Code.eval e 0 := by simpa only [he] using hy
    exact (consistent_iff_unprovable_bot.mp (inferInstance : Consistent 𝗣𝗔))
      (neg_mdp (hsound hy) (finiteProofAdequacy e 0 y hy'))
  have hdiv (x : ℕ) : ¬ (Nat.Partrec.Code.eval e x).Dom := by
    intro hx
    obtain ⟨y, hy⟩ := Part.dom_iff_mem.1 hx
    exact noOutput y (by simpa only [he, hign] using hy)
  refine ⟨e, Nat.Partrec.Code.eval_part.comp (Computable.const e) Computable.id, hdiv, ?_⟩
  rintro (_ | n)
  · exact ⟨ℕ, inferInstance, inferInstance, (standardDivergence e 0).mpr (hdiv 0)⟩
  · by_contra hno
    have href : 𝗣𝗔 ⊢ ∼(haltSentence e 0 n) :=
      Arithmetic.complete.{0} 𝗣𝗔 (∼(haltSentence e 0 n)) fun M _ _ =>
        Semantics.Not.models_not.mpr fun hn => hno ⟨M, inferInstance, inferInstance, hn⟩
    obtain ⟨y, hy⟩ := hcomplete ⟨n, href⟩
    exact noOutput y hy

/-! ## The semantic form -/

/-- `y` is an output of program `e` on input `0`, computed inside the structure `M`. -/
def OutputIn (M : Type*) [ORingStructure M] (e : Code) (y : M) : Prop :=
  M ⊧/![y, ORingStructure.numeral (Encodable.encode e), ORingStructure.numeral 0] universalGraph

/-- The value of program `e` on input `0`, computed inside `M`, is `o`: for `o = some n` the
numeral `n` is the unique output, and for `o = none` there is no output. -/
def ValueIn (M : Type*) [ORingStructure M] (e : Code) : Option ℕ → Prop
  | some n => ∀ y : M, OutputIn M e y ↔ y = ORingStructure.numeral n
  | none => ∀ y : M, ¬ OutputIn M e y

section

variable {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]

lemma outputIn_iff (e : Code) (y : M) :
    OutputIn M e y ↔
      (M ⊧/![y, ((Encodable.encode e : ℕ) : M), ((0 : ℕ) : M)] universalGraph) := by
  unfold OutputIn
  rw [numeral_eq_natCast_app, numeral_eq_natCast_app]

/-- A structure that satisfies `outputSentence e o` computes the value `o`. The uniqueness of
the output is the functionality of the halting formula. -/
theorem valueIn_of_models (e : Code) (o : Option ℕ) (h : M↓[ℒₒᵣ] ⊧ outputSentence e o) :
    ValueIn M e o := by
  cases o with
  | none =>
    show ∀ y : M, ¬ OutputIn M e y
    intro y hy
    exact (models_divergeSentence e 0).mp h ⟨y, (outputIn_iff e y).mp hy⟩
  | some n =>
    show ∀ y : M, OutputIn M e y ↔ y = ORingStructure.numeral n
    intro y
    have hn := (models_haltSentence e 0 n).mp h
    rw [numeral_eq_natCast_app]
    constructor
    · intro hy
      exact universalGraph_uniq ((outputIn_iff e y).mp hy) hn
    · rintro rfl
      exact (outputIn_iff e _).mpr hn

end

/-- **Main theorem, semantic form.** There is a program `e` that diverges on every input, such
that for every `o : Option ℕ` there is a model of `𝗣𝗔` in which the value of `e` on input `0` is
`o`. -/
theorem flexibleOutputValue :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o := by
  obtain ⟨e, hpart, hdiv, hmod⟩ := flexibleOutput
  refine ⟨e, hpart, hdiv, fun o => ?_⟩
  obtain ⟨M, inst, hM, ho⟩ := hmod o
  haveI : M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := models_of_subtheory (U := 𝗣𝗔) hM
  exact ⟨M, inst, hM, valueIn_of_models e o ho⟩

/-- **Main theorem.** There is a partial recursive function `f : ℕ →. ℕ` such that for every
`o`, a natural number or `none`, the statement "`f 0 = o`" holds in some model of `𝗣𝗔`. The
function is given by a program `e`, and the statement is read inside the model through the
halting formula of that program. -/
theorem exists_partrec_flexibleOutput :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o := by
  obtain ⟨e, hpart, -, hmod⟩ := flexibleOutputValue
  exact ⟨Nat.Partrec.Code.eval e, hpart, e, rfl, hmod⟩

/-! ## The propositions of `Statement` -/

/-- `Statement.StrongClaim`: the program diverges on every input, and every halting sentence
for input `0` is satisfiable together with `𝗣𝗔`. -/
theorem strongClaim : StrongClaim := by
  obtain ⟨e, -, hdiv, hmod⟩ := flexibleOutput
  refine ⟨e, hdiv, fun n => ?_⟩
  obtain ⟨M, inst, hM, hn⟩ := hmod (some n)
  exact satisfiable_intro M (Semantics.ModelsSet.insert_iff.mpr ⟨hn, hM⟩)

/-- `Statement.MainClaim`. -/
theorem mainClaim : MainClaim := by
  obtain ⟨e, hdiv, hsat⟩ := strongClaim
  exact ⟨e, hdiv 0, hsat⟩

/-- `Statement.FullySpecifiedMainClaim`. -/
theorem fullySpecifiedMainClaim : FullySpecifiedMainClaim :=
  ⟨standardCorrectness, functionalityInPAModels, mainClaim⟩

#print axioms flexibleOutput
#print axioms flexibleOutputValue
#print axioms exists_partrec_flexibleOutput
#print axioms strongClaim
#print axioms mainClaim
#print axioms fullySpecifiedMainClaim

end PAFlexibleOutput
