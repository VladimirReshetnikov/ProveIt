import PAFlexibleOutput.Arithmetization
import PAFlexibleOutput.Refutations
import PAFlexibleOutput.Search
import PAFlexibleOutput.MathlibAssembly

/-!
# Compatibility for the previous abstract arithmetic bridge

The direct proof in `Main.lean` does not import this module. Import it explicitly if a client
uses `PAModel`, `paBridge`, or `exists_searchImplementation` from the previous `Main.lean`.
The generic `MathlibAssembly` theorem remains available unchanged.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

/-! ## The arithmetic bridge -/

/-- A model of `𝗣𝗔` with a small carrier, bundled. -/
structure PAModel : Type 1 where
  /-- The carrier. -/
  carrier : Type
  [oring : ORingStructure carrier]
  [models : carrier↓[ℒₒᵣ] ⊧* 𝗣𝗔]

attribute [instance] PAModel.oring PAModel.models

/-- `𝗣𝗔` as an instance of the abstract bridge of `MathlibAssembly`. -/
noncomputable def paBridge : FlexibleOutputMathlib.ArithmeticBridge.{0, 1} where
  Sentence := ArithmeticSentence
  Model := PAModel
  halts := haltSentence
  neg := fun σ => ∼σ
  provable := fun σ => 𝗣𝗔 ⊢ σ
  isModel := fun _ => True
  realizes := fun M σ => M.carrier↓[ℒₒᵣ] ⊧ σ
  consistent := fun p hp hnp => by
    have h₁ : ℕ↓[ℒₒᵣ] ⊧ p := models_of_provable (M := ℕ) inferInstance hp
    have h₂ : ℕ↓[ℒₒᵣ] ⊧ ∼p := models_of_provable (M := ℕ) inferInstance hnp
    exact Semantics.Not.models_not.mp h₂ h₁
  finiteComputation := fun h => finiteProofAdequacy _ _ _ h
  modelOfUnrefuted := fun p h => by
    by_contra hno
    refine h (Arithmetic.complete.{0} 𝗣𝗔 (∼p) fun M _ _ => ?_)
    exact Semantics.Not.models_not.mpr fun hp => hno ⟨⟨M⟩, trivial, hp⟩

/-- The proof search: a partial recursive function that returns an output refuted by `𝗣𝗔`
whenever there is one. -/
theorem exists_searchImplementation :
    Nonempty (FlexibleOutputMathlib.SearchImplementation paBridge) := by
  have hR : REPred (fun p : Code × ℕ => 𝗣𝗔 ⊢ ∼(haltSentence p.1 0 p.2)) := refutationsRE
  obtain ⟨search, hpart, hign, hsound, hcomplete⟩ := exists_search hR
  exact ⟨{
    search := search
    partialRecursive := hpart
    ignoresInput := hign
    returnsRefutation := fun h => hsound h
    findsRefutation := fun h => hcomplete h }⟩

end PAFlexibleOutput
