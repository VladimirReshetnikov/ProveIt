FLEXIBLE OUTPUT: A DIRECT LEAN PROOF
Prepared for Vladimir Reshetnikov, 2026-11-09

BASELINE
ProveIt: 410c820c4faa7620a19ce07f55f43c13e5fbb688
Lean: leanprover/lean4:v4.32.0
Mathlib: 81a5d257c8e410db227a6665ed08f64fea08e997
Foundation: 32e1a0956a8622fad067328ca1959729a7634428

MAIN IDEA
Use exists_search refutationsRE and Nat.Partrec.Code.fixed_point₂ directly
in Main.lean. If the search returns y, finiteProofAdequacy proves its
halting sentence and search soundness proves the negation. The existing
Consistent PA instance contradicts this. Input independence gives divergence
on every input; arithmetic completeness supplies each numerical-output model.
The standard model supplies the divergent output.

The final exists_partrec_flexibleOutput wrapper was already two lines and
remains unchanged. The improvement is in its supporting proof chain.

CONTENTS
flexible_output_simplification.pdf: compiled explanatory report.
flexible_output_simplification.tex: complete, standalone LaTeX source.
lean/PAFlexibleOutput/: final replacement Main, Functionality, Refutations.
lean/Audit.lean: public endpoint and axiom checks.
stages/direct/PAFlexibleOutput/Main.lean: core rewrite without local cleanups.
patches/01_direct-main.patch: structural rewrite alone.
patches/02_local-cleanups.patch: optional cleanups, applied AFTER stage 1.
patches/combined.patch: alternative single patch for both stages.
compatibility/BridgeCompatibility.lean: optional preservation of removed helpers.
baseline/: exact pinned source snapshots needed for the comparison.
evidence/: provenance, source metrics, compiler logs and validation results.
scripts/: reproducible Lean checks, source audit, PDF build.
SHA256SUMS: checksums of the delivered files.

HOW TO APPLY
Start from the pinned ProveIt checkout with its Foundation submodule and
Mathlib dependencies available. From the repository root, use either:

  git apply --check /path/to/package/patches/combined.patch
  git apply /path/to/package/patches/combined.patch

or apply 01_direct-main.patch and then 02_local-cleanups.patch in that order.
Do not apply the combined patch after either individual patch.

Run:

  bash /path/to/package/scripts/check_lean.sh /path/to/ProveIt

The script does not apply patches or overwrite repository files. It builds
the main target and elaborates the endpoint/axiom audit in that workspace.
It requires lake/Lean 4.32.0 to be available on PATH.

COMPATIBILITY
All six advertised endpoint types are preserved, as are OutputIn, ValueIn,
and outputSentence. No formula or semantic definition is replaced.
PAModel, paBridge and exists_searchImplementation are removed from Main.
Clients using these helpers can copy BridgeCompatibility.lean into
Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/ and explicitly
import PAFlexibleOutput.BridgeCompatibility. MathlibAssembly and ProofCore
remain available; neither is deleted by these patches.

The repository README and facade documentation describe the older bridge
path and should be adjusted when the refactor is adopted.

REPRODUCE SOURCE METRICS
From this package directory:

  python3 scripts/audit_sources.py --original-dir baseline \
    --proposed-dir lean/PAFlexibleOutput --json evidence/source_audit.json

The main scoped comparison is 106 to 28 nonblank, noncomment lines. It counts
the removed PA adapter layer and the generic structures/assembly no longer
needed for this proof, and excludes unchanged representation/search support.
It does NOT mean the whole project shrinks by 73.6 percent. The retained
abstract module and optional compatibility code are not claimed as deletions.
No elaboration-time or kernel-proof-size improvement is claimed.

REBUILD THE REPORT
With a standard TeX Live installation providing pdflatex, listings, lmodern,
amssymb, microtype, booktabs, fancyhdr and hyperref:

  bash scripts/build_pdf.sh

The standalone .tex source contains its tables and code excerpts inline.

VALIDATION
The pinned baseline, direct proof, and combined patch all compile successfully
with Lean 4.32.0. The separate endpoint audit and compatibility module compile
successfully as well. All six advertised endpoints, functionalityInPAModels,
and refutationsRE depend exactly on propext, Classical.choice, and Quot.sound.
No sorry, admit, added axiom, or native_decide is present in delivered Lean.
Read evidence/validation.json and the build logs for the completed checks.
Compiler evidence is distinct from the lexical source-preservation audit.
The three edited modules have 261 -> 195 nonblank code lines (25.3% fewer).
