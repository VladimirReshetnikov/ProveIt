import PAFlexibleOutput.Main

/-!
Endpoint/axiom audit for the proposed proof. Run in the pinned ProveIt
workspace after applying the patch and building PAFlexibleOutput.Main.
The exact source-level statements and semantic definitions are compared
separately by scripts/audit_sources.py.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o :=
  exists_partrec_flexibleOutput

example : StrongClaim := strongClaim
example : MainClaim := mainClaim
example : FullySpecifiedMainClaim := fullySpecifiedMainClaim

#print axioms flexibleOutput
#print axioms flexibleOutputValue
#print axioms exists_partrec_flexibleOutput
#print axioms strongClaim
#print axioms mainClaim
#print axioms fullySpecifiedMainClaim
#print axioms functionalityInPAModels
#print axioms refutationsRE

end PAFlexibleOutput
