#!/usr/bin/env python3
"""Audit a FlexibleOutput source refactor without invoking Lean.

Usage:
  python3 audit_sources.py --original-dir ORIGINAL --proposed-dir PROPOSED \
      --json audit.json

Each directory directly contains .lean files (in particular Main.lean).
Original must also contain MathlibAssembly.lean, Functionality.lean and
Refutations.lean. Proposed Main.lean is required; other missing proposed files
are reported as "not supplied", never counted as deletions or zero-sized files.
All .lean files found directly in either directory are measured separately.

Metrics:
* UTF-8 bytes are the actual file bytes, without newline normalization.
* Physical lines use Python str.splitlines(), including blank/comment lines.
* Nonblank code lines count lines remaining nonblank after lexical comment
  masking. Strings and character literals are retained. Nested /- ... -/
  comments and -- line comments are recognized. Comments inside literals are
  retained; line endings inside comments are preserved.

The scoped core comparison has explicit boundaries:
* Original Main: structure PAModel through the end of theorem flexibleOutput.
* Original MathlibAssembly: structure ArithmeticBridge through the end of
  theorem exists_program_with_arbitrary_possible_output.
* Proposed Main: def outputSentence through the end of theorem flexibleOutput.

Each scope starts at the declaration's first code character, excludes its
preceding doc comment, and ends at the last noncomment character of the final
specified declaration. Intervening comments/blank lines belong to the scope.
Original scopes are summed. This is a scoped source comparison, not a claim
about total project size, kernel proof terms, or performance. Optional bridge
compatibility code is listed in file metrics but excluded from this scoped
comparison because the direct theorem does not use it.

Checks:
* The type text of six named public endpoints is byte-for-byte unchanged,
  from just after the top-level ':' through just before ':=' (including
  interior and boundary whitespace).
* The full code text of OutputIn, ValueIn and outputSentence is byte-for-byte
  unchanged, from the first declaration keyword/modifier through the final
  code character (excluding following trivia/doc comments).

This is a small lexer and a declaration-boundary audit for these ordinary,
column-zero Lean declarations, not a general Lean parser. It deliberately
fails on ambiguous/missing declarations or unterminated literals/comments.
It does not establish elaboration or mathematical correctness.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


ENDPOINTS = (
    "flexibleOutput", "flexibleOutputValue", "exists_partrec_flexibleOutput",
    "strongClaim", "mainClaim", "fullySpecifiedMainClaim",
)
DEFINITIONS = ("OutputIn", "ValueIn", "outputSentence")
REQUIRED_ORIGINAL = ("Main.lean", "MathlibAssembly.lean", "Functionality.lean", "Refutations.lean")
MODIFIER = r"(?:(?:private|protected|noncomputable|unsafe|partial|public)\s+)*"
DECLARATION_RE = re.compile(
    rf"^{MODIFIER}(?P<kind>theorem|lemma|def|abbrev|structure|inductive)\s+"
    r"(?P<name>[^\s(:{\[]+)", re.MULTILINE,
)
COMMAND_RE = re.compile(
    rf"^(?:{MODIFIER}(?:theorem|lemma|def|abbrev|structure|inductive|instance)\b|"
    r"(?:namespace|section|end|variable|universe|attribute|set_option|open|import|export|"
    r"include|omit|local|scoped|notation|infix|infixl|infixr|prefix|postfix)\b|@\[|#)",
    re.MULTILINE,
)
RAW_STRING_RE = re.compile(r'r(?P<hashes>#*)"')
CHARACTER_RE = re.compile(r"'(?:[^'\\\r\n]|\\(?:[nrt0\\'\"]|u[0-9A-Fa-f]{4}|x[0-9A-Fa-f]{2}))'")


class AuditError(Exception):
    """The audit cannot safely interpret the input or finds a changed contract."""


def blank(text: str) -> str:
    """Preserve text length and newline characters while masking other text."""
    return "".join(c if c in "\r\n" else " " for c in text)


def lexical_views(source: str) -> tuple[str, str]:
    """Return (comments masked, comments and literals masked), preserving offsets.

    The second view prevents declaration-looking text or ':=' inside a literal
    from being parsed as Lean code. Ordinary and raw strings, escaped chars,
    identifier primes and nested block comments are handled separately.
    """
    comments: list[str] = []
    code: list[str] = []
    i, n = 0, len(source)
    while i < n:
        start = i
        if source.startswith("--", i):
            end = source.find("\n", i)
            i = n if end < 0 else end
            masked = blank(source[start:i])
            comments.append(masked)
            code.append(masked)
        elif source.startswith("/-", i):
            depth = 1
            i += 2
            while i < n and depth:
                if source.startswith("/-", i):
                    depth += 1
                    i += 2
                elif source.startswith("-/", i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            if depth:
                raise AuditError(f"Unterminated block comment at character {start}")
            masked = blank(source[start:i])
            comments.append(masked)
            code.append(masked)
        else:
            raw = RAW_STRING_RE.match(source, i)
            char = CHARACTER_RE.match(source, i) if source[i] == "'" else None
            if raw and (i == 0 or not (source[i - 1].isalnum() or source[i - 1] in "_'")):
                terminator = '"' + raw.group("hashes")
                end = source.find(terminator, raw.end())
                if end < 0:
                    raise AuditError(f"Unterminated raw string at character {start}")
                i = end + len(terminator)
            elif source[i] == '"':
                i += 1
                while i < n:
                    if source[i] == "\\":
                        i += 2
                    elif source[i] == '"':
                        i += 1
                        break
                    else:
                        i += 1
                else:
                    raise AuditError(f"Unterminated string at character {start}")
            elif char:
                i = char.end()
            else:
                comments.append(source[i])
                code.append(source[i])
                i += 1
                continue
            literal = source[start:i]
            comments.append(literal)
            code.append(blank(literal))
    return "".join(comments), "".join(code)


@dataclass
class Source:
    path: Path
    data: bytes
    text: str
    uncommented: str
    code: str

    @classmethod
    def read(cls, path: Path) -> "Source":
        data = path.read_bytes()
        text = data.decode("utf-8")
        uncommented, code = lexical_views(text)
        return cls(path, data, text, uncommented, code)

    def declaration(self, name: str) -> tuple[int, int, int]:
        """Return declaration start, end of name, and end excluding trailing trivia."""
        matches = [m for m in DECLARATION_RE.finditer(self.code) if m.group("name") == name]
        if len(matches) != 1:
            raise AuditError(f"{self.path}: expected one declaration {name!r}; found {len(matches)}")
        match = matches[0]
        following = COMMAND_RE.search(self.code, match.end())
        end = len(self.text) if following is None else following.start()
        # Comments are spaces in this view. Do not trim literal contents.
        tail = self.uncommented[match.start():end].rstrip()
        return match.start(), match.end("name"), match.start() + len(tail)

    def signature_type(self, name: str) -> str:
        start, name_end, end = self.declaration(name)
        stack: list[str] = []
        pairs = {"(": ")", "[": "]", "{": "}", "⟨": "⟩"}
        colon: int | None = None
        i = name_end
        while i < end:
            c = self.code[i]
            if not stack and self.code.startswith(":=", i):
                if colon is None:
                    raise AuditError(f"{self.path}: no top-level type colon for {name}")
                return self.text[colon + 1:i]
            if c in pairs:
                stack.append(pairs[c])
            elif stack and c == stack[-1]:
                stack.pop()
            elif not stack and c == ":" and colon is None:
                colon = i
            i += 1
        raise AuditError(f"{self.path}: no top-level ':=' for theorem {name}")

    def definition_text(self, name: str) -> str:
        start, _, end = self.declaration(name)
        return self.text[start:end]

    def scope(self, first: str, last: str) -> dict[str, Any]:
        start, _, _ = self.declaration(first)
        _, _, end = self.declaration(last)
        if end <= start:
            raise AuditError(f"{self.path}: invalid scope {first} through {last}")
        return {
            "file": str(self.path),
            "starts_at_declaration": first,
            "ends_after_declaration": last,
            "start_line_1_based": self.text.count("\n", 0, start) + 1,
            "end_line_1_based": self.text.count("\n", 0, end) + 1,
            **metrics(self.text[start:end]),
        }


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def metrics(text: str) -> dict[str, int]:
    uncommented, _ = lexical_views(text)
    return {
        "utf8_bytes": len(text.encode("utf-8")),
        "physical_lines": len(text.splitlines()),
        "nonblank_code_lines": sum(bool(line.strip()) for line in uncommented.splitlines()),
    }


def file_metrics(source: Source) -> dict[str, Any]:
    return {
        "path": str(source.path),
        "sha256": hashlib.sha256(source.data).hexdigest(),
        **metrics(source.text),
    }


def check(name: str, kind: str, original: str, proposed: str) -> dict[str, Any]:
    same = original == proposed
    result: dict[str, Any] = {
        "name": name, "kind": kind, "exactly_equal": same,
        "original_sha256": sha(original), "proposed_sha256": sha(proposed),
    }
    if not same:
        result["original_text"] = original
        result["proposed_text"] = proposed
    return result


def audit(original_dir: Path, proposed_dir: Path) -> dict[str, Any]:
    for name in REQUIRED_ORIGINAL:
        if not (original_dir / name).is_file():
            raise AuditError(f"Missing original file: {original_dir / name}")
    if not (proposed_dir / "Main.lean").is_file():
        raise AuditError(f"Missing proposed file: {proposed_dir / 'Main.lean'}")
    originals = {p.name: Source.read(p) for p in sorted(original_dir.glob("*.lean"))}
    proposals = {p.name: Source.read(p) for p in sorted(proposed_dir.glob("*.lean"))}
    files = {}
    for name in sorted(originals.keys() | proposals.keys()):
        files[name] = {
            "original": file_metrics(originals[name]) if name in originals else None,
            "proposed": file_metrics(proposals[name]) if name in proposals else None,
        }
    old, new = originals["Main.lean"], proposals["Main.lean"]
    checks = [check(name, "endpoint type text", old.signature_type(name), new.signature_type(name))
              for name in ENDPOINTS]
    checks += [check(name, "semantic definition text", old.definition_text(name), new.definition_text(name))
               for name in DEFINITIONS]
    scopes = {
        "original_main": old.scope("PAModel", "flexibleOutput"),
        "original_assembly": originals["MathlibAssembly.lean"].scope(
            "ArithmeticBridge", "exists_program_with_arbitrary_possible_output"),
        "proposed_main": new.scope("outputSentence", "flexibleOutput"),
    }
    total = {
        key: scopes["original_main"][key] + scopes["original_assembly"][key]
        for key in ("utf8_bytes", "physical_lines", "nonblank_code_lines")
    }
    after = scopes["proposed_main"]["nonblank_code_lines"]
    before = total["nonblank_code_lines"]
    return {
        "audit_version": 1,
        "status": "pass" if all(c["exactly_equal"] for c in checks) else "FAIL",
        "limits": [
            "Lexical source audit; does not establish Lean elaboration or mathematical correctness.",
            "Missing proposed files mean not supplied, not deleted; no whole-project total is claimed.",
            "Scoped reduction excludes unchanged arithmetic/search support and optional compatibility code.",
            "No claim about kernel proof size, elaboration time or runtime performance.",
        ],
        "file_metrics": files,
        "contract_checks": checks,
        "core_scopes": scopes,
        "original_core_sum": total,
        "scoped_nonblank_code_line_reduction": {
            "before": before, "after": after, "removed": before - after,
            "percent": round(100 * (before - after) / before, 4),
        },
    }


def self_test() -> None:
    # These fixtures guard the concrete risks in a source-size audit: treating
    # comment-looking literals as comments, and failing to nest block comments.
    source = 'def s := "/- literal -/ -- literal"\n/- outer\n /- inner -/ end -/\ndef h\' := r#"-- raw /-"# -- actual\ndef c := \'\\"\'\n'
    uncommented, code = lexical_views(source)
    assert '"/- literal -/ -- literal"' in uncommented
    assert 'r#"-- raw /-"#' in uncommented
    assert "outer" not in uncommented and "inner" not in uncommented
    assert "actual" not in uncommented and "literal" not in code
    assert len(source) == len(uncommented) == len(code)
    assert source.count("\n") == uncommented.count("\n") == code.count("\n")
    assert metrics(source)["nonblank_code_lines"] == 3


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--original-dir", type=Path)
    parser.add_argument("--proposed-dir", type=Path)
    parser.add_argument("--json", type=Path, help="Write the complete audit JSON here; stdout still prints a summary.")
    parser.add_argument("--self-test", action="store_true", help="Run lexer risk fixtures, then audit if directories are supplied.")
    args = parser.parse_args()
    try:
        if args.self_test:
            self_test()
            print("Lexer fixtures: passed.")
        if args.original_dir is None or args.proposed_dir is None:
            if args.self_test and args.original_dir is None and args.proposed_dir is None:
                return 0
            parser.error("both --original-dir and --proposed-dir are required for an audit")
        result = audit(args.original_dir, args.proposed_dir)
        if args.json:
            args.json.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        for name, sides in result["file_metrics"].items():
            def label(item: Any) -> str:
                return "not supplied" if item is None else (
                    f"{item['physical_lines']} lines / {item['utf8_bytes']} bytes / "
                    f"{item['nonblank_code_lines']} nonblank code lines")
            print(f"{name}: {label(sides['original'])} -> {label(sides['proposed'])}")
        reduction = result["scoped_nonblank_code_line_reduction"]
        print(f"Scoped core: {reduction['before']} -> {reduction['after']} nonblank code lines "
              f"({reduction['percent']:.2f}% reduction).")
        for item in result["contract_checks"]:
            print(f"{'PASS' if item['exactly_equal'] else 'FAIL'} {item['kind']}: {item['name']}")
        print("This is source-size/contract evidence, not a compiler result or performance claim.")
        if not args.json:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result["status"] == "pass" else 1
    except (AuditError, UnicodeError, OSError, AssertionError) as error:
        print(f"Audit failed: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
