#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /absolute/path/to/ProveIt" >&2
  exit 2
fi
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
package_dir=$(CDPATH= cd -- "$script_dir/.." && pwd)
repo_dir=$(CDPATH= cd -- "$1" && pwd)
cd "$repo_dir"
echo "Toolchain: $(cat lean-toolchain)"
lake env lean --version
# The patch must already be applied; this script does not overwrite sources.
export LAKE_JOBS=1
export LEAN_NUM_THREADS=0
lake build +PAFlexibleOutput.Main
lake env lean "$package_dir/lean/Audit.lean"
