#!/usr/bin/env bash
set -euo pipefail
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$script_dir/.."
pdflatex -interaction=nonstopmode -halt-on-error flexible_output_simplification.tex
pdflatex -interaction=nonstopmode -halt-on-error flexible_output_simplification.tex
