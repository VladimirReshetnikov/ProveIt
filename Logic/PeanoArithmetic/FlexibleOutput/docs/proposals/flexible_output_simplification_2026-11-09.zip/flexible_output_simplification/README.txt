FLEXIBLEOUTPUT: A SHORTER LEAN PROOF
==================================

Prepared for Vladimir Reshetnikov, 9 November 2026.

Read report.pdf (or report.tex) for the complete argument, source comparison,
scope of the reduction, and integration tradeoffs.

BASELINE
--------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 410c820c4faa7620a19ce07f55f43c13e5fbb688
Directory: Logic/PeanoArithmetic/FlexibleOutput
Lean: 4.32.0
Mathlib: 81a5d257c8e410db227a6665ed08f64fea08e997
Foundation: 32e1a0956a8622fad067328ca1959729a7634428

RECOMMENDED MAIN-THEOREM ROUTE
----------------------------
Search for a PA proof refuting the COMPLETE value sentence

  U(c,n) := for every y, H(c,0,y) iff y = n,

where H is the unchanged universalGraph.

If the self-referential program really outputs n, standard correctness and
Part.mem_unique imply that U(c,n) holds in the standard model. Soundness
contradicts the proof found by the search. Completeness then supplies a
model satisfying the full ValueIn statement directly.

This preserves the exact principal theorem statement, the definitions of
OutputIn/ValueIn, the same computation graph, all-input standard divergence,
and the none case. The witness program can change. The main proof no longer
needs global functionality in every nonstandard model.

FILE MAP
--------
report.tex, report.pdf       Complete mathematical and implementation report.
metrics.tex, validation.tex  Small included files needed to rebuild the PDF.
lean/PAFlexibleOutput/       Proposed complete local module set for the main
                            route and the optional stronger audit.
lean/PAFlexibleOutput.lean   Broad facade retaining the global audit endpoint.
baseline/                   Exact pinned original modules, for comparison.
patches/exact_value_search.patch
                            Recommended change against the pinned repository.
alternatives/direct/        Smaller conceptual diff: keep the old search,
                            replace only Main with a direct soundness proof.
patches/direct_soundness.patch
                            Mutually exclusive alternative patch.
source_metrics.json         Reproducible project-local import-closure counts.
source_manifest.json        Source identity and dependency revision manifest.
verification_status.txt    Actual validation results and limitations.
verification/              Explicit public-type checks, build logs, audit notes.
scripts/source_metrics.py  Recompute counts and source-preservation checks.
scripts/check_lean.sh       Serial Lean builds and explicit endpoint audit.
scripts/build_report.sh    Rebuild the PDF with pdfLaTeX.

IMPORT CHOICES
--------------
For the smallest main endpoint route:

  import PAFlexibleOutput.Main

For the additional, stronger assertion of functionality for all PA models,
including nonstandard program codes and inputs:

  import PAFlexibleOutput.FullAudit

The broad PAFlexibleOutput facade imports FullAudit. The original abstract
MathlibAssembly and ProofCore files can remain separately importable in the
repository. They are not used by the new main route.

The original fullySpecifiedMainClaim and valueIn_of_models helper move to
FullAudit. The packaging helpers PAModel, paBridge and
exists_searchImplementation are no longer defined by Main. The original
refutationsRE theorem remains available as an instance of the generalized
templateRefutationsRE theorem in Refutations.lean.

APPLYING THE RECOMMENDED PATCH
-----------------------------
In a fresh checkout at the baseline revision, review the patch and then run:

  git apply --check /path/to/package/patches/exact_value_search.patch
  git apply /path/to/package/patches/exact_value_search.patch
  /path/to/package/scripts/check_lean.sh /absolute/path/to/ProveIt

The patch does not change the root Lake configuration or dependency pins.
The existing PAFlexibleOutput library already discovers the added module.
The package's lean/ tree is also a readable overlay of the proposed files.

CONSERVATIVE ALTERNATIVE
------------------------
Apply direct_soundness.patch INSTEAD of exact_value_search.patch if you want
to keep the original halting-sentence search and all original principal
theorems in Main. It removes the abstract bridge but retains Functionality.
Build +PAFlexibleOutput.Main in the usual project environment.

For a broad import including global functionality, the direct alternative
has fewer project-local code lines than exact-value Main plus FullAudit.
For the principal endpoint alone, exact-value Main has the smaller path.
These are different optimization targets; the report gives both counts.
Use a fresh checkout when switching alternatives to avoid stale interfaces.

VALIDATION
----------
See verification_status.txt and the saved logs. No claim of a global minimum
Lean proof size is made. Source-line counts are not proof-term sizes or
compile-time measurements. Already unused ProofCore is not credited as a new
reduction. All baseline files are retained for review; their presence in the
archive does not mean they are imported by the proposed main theorem.

No GitHub branch, commit, pull request, or remote source file was changed.
