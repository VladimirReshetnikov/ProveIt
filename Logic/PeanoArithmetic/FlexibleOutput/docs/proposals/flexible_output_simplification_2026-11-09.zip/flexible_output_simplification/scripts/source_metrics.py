#!/usr/bin/env python3
"""Reproduce the source comparison and identity checks in the accompanying report.

Metrics count project-local modules reachable from the named import root. They do
not measure external library size, proof-term size, build time, or deleted files.
"""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def without_comments(text):
    """Remove Lean nested block / line comments while preserving line breaks."""
    out, i, depth, quoted = [], 0, 0, False
    while i < len(text):
        pair = text[i:i + 2]
        ch = text[i]
        if depth:
            if pair == '/-':
                depth += 1
                i += 2
            elif pair == '-/':
                depth -= 1
                i += 2
            else:
                if ch == '\n':
                    out.append(ch)
                i += 1
        elif quoted:
            out.append(ch)
            i += 1
            if ch == '\\' and i < len(text):
                out.append(text[i])
                i += 1
            elif ch == '"':
                quoted = False
        elif pair == '/-':
            out.append(' ')
            depth = 1
            i += 2
        elif pair == '--':
            i = text.find('\n', i)
            if i < 0:
                break
        else:
            out.append(ch)
            quoted = ch == '"'
            i += 1
    assert depth == 0, 'Unterminated Lean block comment'
    return ''.join(out)


def metrics(path):
    raw = path.read_text()
    code = without_comments(raw)
    lines = [line for line in code.splitlines()
             if line.strip() and not line.lstrip().startswith('#print axioms')]
    return {
        'physical_lines': len(raw.splitlines()),
        'code_lines': len(lines),
        'utf8_bytes': len(raw.encode()),
        'sha256': hashlib.sha256(raw.encode()).hexdigest(),
    }


def closure(folder, entry):
    seen = {}
    def visit(name):
        if name in seen:
            return
        path = folder / (name.replace('.', '/') + '.lean')
        if not path.exists():
            raise FileNotFoundError(path)
        seen[name] = metrics(path)
        for imp in re.findall(r'^import\s+(PAFlexibleOutput(?:\.[A-Za-z0-9_]+)*)',
                              without_comments(path.read_text()), re.M):
            visit(imp)
    visit(entry)
    return {
        'modules': dict(sorted(seen.items())),
        'totals': {key: sum(v[key] for v in seen.values())
                   for key in ['physical_lines', 'code_lines', 'utf8_bytes']},
    }


def declaration(text, name, body=False):
    code = without_comments(text)
    pattern = r'\b(?:def|theorem|lemma)\s+' + re.escape(name) + r'\b'
    m = re.search(pattern, code)
    assert m, name
    start = m.start()
    if body:
        end = re.search(r'\n(?:noncomputable\s+)?(?:def|theorem|lemma|section|end)\b',
                        code[m.end():])
        stop = m.end() + end.start() if end else len(code)
    else:
        stop = code.index(':=', m.end())
    return re.sub(r'\s+', ' ', code[start:stop]).strip()


def main():
    baseline = ROOT / 'baseline'
    proposed = ROOT / 'lean'
    before = (baseline / 'PAFlexibleOutput/Main.lean').read_text()
    after = (proposed / 'PAFlexibleOutput/Main.lean').read_text()
    preserved = {}
    for name in ['outputSentence', 'OutputIn', 'ValueIn']:
        preserved[name] = declaration(before, name, True) == declaration(after, name, True)
    for name in ['flexibleOutput', 'flexibleOutputValue',
                 'exists_partrec_flexibleOutput', 'strongClaim', 'mainClaim']:
        preserved[name] = declaration(before, name) == declaration(after, name)
    full = (proposed / 'PAFlexibleOutput/FullAudit.lean').read_text()
    preserved['fullySpecifiedMainClaim'] = (
        declaration(before, 'fullySpecifiedMainClaim') ==
        declaration(full, 'fullySpecifiedMainClaim'))
    for name in ['Statement', 'Arithmetization', 'Search', 'Functionality']:
        a = (baseline / ('PAFlexibleOutput/' + name + '.lean')).read_bytes()
        b = (proposed / ('PAFlexibleOutput/' + name + '.lean')).read_bytes()
        preserved[name + '_bytes'] = a == b
    assert all(preserved.values()), preserved
    for path in proposed.rglob('*.lean'):
        code = without_comments(path.read_text())
        assert not re.search(r'\b(?:sorry|admit|native_decide)\b|^\s*(?:private\s+)?axiom\b',
                             code, re.M), path
    result = {
        'definition': 'Nonblank comment-free project-local source lines; #print axioms excluded.',
        'baseline_main': closure(baseline, 'PAFlexibleOutput.Main'),
        'exact_value_main': closure(proposed, 'PAFlexibleOutput.Main'),
        'exact_value_with_full_audit': closure(proposed, 'PAFlexibleOutput.FullAudit'),
        'preservation_checks': preserved,
    }
    # Overlay the direct alternative on the baseline without copying support files.
    direct = (ROOT / 'alternatives/direct/PAFlexibleOutput/Main.lean')
    direct_modules = dict(result['baseline_main']['modules'])
    direct_modules['PAFlexibleOutput.Main'] = metrics(direct)
    del direct_modules['PAFlexibleOutput.MathlibAssembly']
    result['direct_soundness_main'] = {
        'modules': dict(sorted(direct_modules.items())),
        'totals': {key: sum(v[key] for v in direct_modules.values())
                   for key in ['physical_lines', 'code_lines', 'utf8_bytes']},
    }
    b = result['baseline_main']['totals']['code_lines']
    for name in ['exact_value_main', 'exact_value_with_full_audit', 'direct_soundness_main']:
        n = result[name]['totals']['code_lines']
        result[name]['code_lines_saved'] = b - n
        result[name]['code_line_reduction_percent'] = round(100 * (b - n) / b, 2)
    destination = ROOT / 'source_metrics.json'
    destination.write_text(json.dumps(result, indent=2) + '\n')
    for name in ['baseline_main', 'exact_value_main', 'exact_value_with_full_audit',
                 'direct_soundness_main']:
        print(name + ': ' + json.dumps(result[name]['totals']))
    print('All preservation and no-admission source checks passed.')
    print('Full measurements: ' + str(destination))


if __name__ == '__main__':
    main()
