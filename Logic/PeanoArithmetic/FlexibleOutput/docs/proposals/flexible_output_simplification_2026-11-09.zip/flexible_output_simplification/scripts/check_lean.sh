#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /absolute/path/to/ProveIt" >&2
  echo "Apply patches/exact_value_search.patch first, after reviewing it." >&2
  exit 2
fi

package_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
repo_root=$(cd -- "$1" && pwd)
cd -- "$repo_root"

expected_toolchain='leanprover/lean4:v4.32.0'
actual_toolchain=$(tr -d '\r\n' < lean-toolchain)
if [[ "$actual_toolchain" != "$expected_toolchain" ]]; then
  echo "Expected $expected_toolchain; found $actual_toolchain" >&2
  exit 2
fi

export LAKE_JOBS=1
export LEAN_NUM_THREADS=1
lake build +PAFlexibleOutput.Main
lake build +PAFlexibleOutput.FullAudit
lake env lean "$package_root/verification/Audit.lean"
