import PAFlexibleOutput.FullAudit

set_option autoImplicit false

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic
open PAFlexibleOutput

-- The original public type, copied explicitly rather than inferred from the candidate.
example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o :=
  exists_partrec_flexibleOutput

example :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o :=
  flexibleOutputValue

example : MainClaim := mainClaim
example : StrongClaim := strongClaim
example : FullySpecifiedMainClaim := fullySpecifiedMainClaim

#print axioms PAFlexibleOutput.standardExactValue
#print axioms PAFlexibleOutput.exactValueRefutationsRE
#print axioms PAFlexibleOutput.flexibleOutputValue
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
#print axioms PAFlexibleOutput.mainClaim
#print axioms PAFlexibleOutput.strongClaim
#print axioms PAFlexibleOutput.fullySpecifiedMainClaim
