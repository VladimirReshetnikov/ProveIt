import PAFlexibleOutput.FullAudit

/-!
# Flexible output

Import `PAFlexibleOutput.Main` for the shorter main-theorem dependency path.
This facade also retains the separate global-functionality audit theorem.
The historical abstract modules remain separately importable in the repository.
-/
