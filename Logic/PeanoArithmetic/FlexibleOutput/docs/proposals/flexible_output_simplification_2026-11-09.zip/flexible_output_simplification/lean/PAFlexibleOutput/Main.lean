import PAFlexibleOutput.Arithmetization
import PAFlexibleOutput.Refutations
import PAFlexibleOutput.Search

/-!
# Flexible output by searching refutations of the complete value statement

The public computation graph and `ValueIn` are unchanged. The search now refutes the
sentence saying that the chosen numeral is the *unique* output. Thus completeness supplies
the exact semantic conclusion directly; no functionality theorem in nonstandard models is
needed for this proof. In the standard model, functionality is just `Part.mem_unique`.

The generic consistency-only assembly and the stronger assertion of global functionality
can be retained separately. This file uses the standard model of PA directly.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

/-- The original sentence interface, unchanged. -/
noncomputable def outputSentence (e : Code) : Option ℕ → ArithmeticSentence
  | some n => haltSentence e 0 n
  | none => divergeSentence e 0

/-- The original output relation, unchanged. -/
def OutputIn (M : Type*) [ORingStructure M] (e : Code) (y : M) : Prop :=
  M ⊧/![y, ORingStructure.numeral (Encodable.encode e), ORingStructure.numeral 0] universalGraph

/-- The original exact-value interpretation, unchanged. -/
def ValueIn (M : Type*) [ORingStructure M] (e : Code) : Option ℕ → Prop
  | some n => ∀ y : M, OutputIn M e y ↔ y = ORingStructure.numeral n
  | none => ∀ y : M, ¬ OutputIn M e y

/-- Free variables are value, program, input. The bound variable is a candidate output.
This strengthens the searched sentence, without altering the computation graph. -/
noncomputable def exactValueGraph : ArithmeticSemisentence 3 :=
  ∀⁰ ((universalGraph/[#0, #2, #3] : ArithmeticSemisentence 4) 🡘 “#0 = #1”)

/-- The sentence saying that `n` is exactly the value of program `c` on input zero. -/
noncomputable def exactValueSentence (c : Code) (n : ℕ) : ArithmeticSentence :=
  exactValueGraph/[↑n, ↑(Encodable.encode c), ↑(0 : ℕ)]

section

variable {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]

lemma outputIn_iff (e : Code) (y : M) :
    OutputIn M e y ↔
      (M ⊧/![y, ((Encodable.encode e : ℕ) : M), ((0 : ℕ) : M)] universalGraph) := by
  unfold OutputIn
  rw [numeral_eq_natCast_app, numeral_eq_natCast_app]

/-- Reading the complete-value sentence does not require functionality of the graph. -/
theorem models_exactValueSentence (c : Code) (n : ℕ) :
    (M↓[ℒₒᵣ] ⊧ exactValueSentence c n) ↔
      ∀ y : M,
        (M ⊧/![y, ((Encodable.encode c : ℕ) : M), ((0 : ℕ) : M)] universalGraph) ↔
          y = (n : M) := by
  unfold exactValueSentence
  rw [models_iff, Semiformula.eval_substs]
  simp [exactValueGraph, Semiformula.eval_substs, numeral_eq_natCast_app]

theorem valueIn_of_exactValue (c : Code) (n : ℕ)
    (h : M↓[ℒₒᵣ] ⊧ exactValueSentence c n) : ValueIn M c (some n) := by
  simpa [ValueIn, OutputIn, numeral_eq_natCast_app] using
    (models_exactValueSentence c n).mp h

/-- The exact semantic conclusion implies the original sentence conclusion. This direction
does not need a global functionality theorem. -/
theorem models_outputSentence_of_valueIn (e : Code) (o : Option ℕ)
    (h : ValueIn M e o) : M↓[ℒₒᵣ] ⊧ outputSentence e o := by
  cases o with
  | none =>
    apply (models_divergeSentence e 0).mpr
    rintro ⟨y, hy⟩
    exact h y ((outputIn_iff e y).mpr hy)
  | some n =>
    apply (models_haltSentence e 0 n).mpr
    have hn := (h (ORingStructure.numeral n)).mpr rfl
    simpa [OutputIn, numeral_eq_natCast_app] using hn

end

/-- In ℕ, determinism of the partial function supplies exact-value truth. -/
theorem standardExactValue (c : Code) (n : ℕ) :
    (ℕ↓[ℒₒᵣ] ⊧ exactValueSentence c n) ↔ n ∈ Nat.Partrec.Code.eval c 0 := by
  rw [models_exactValueSentence]
  simp only [natCast_nat, universalGraph_nat]
  constructor
  · exact fun h => (h n).mpr rfl
  · intro hn y
    constructor
    · exact fun hy => Part.mem_unique hy hn
    · rintro rfl
      exact hn

/-- Proof search remains recursively enumerable for this fixed formula template. The
template itself need not be Σ₁. -/
theorem exactValueRefutationsRE :
    REPred (fun p : Code × ℕ => 𝗣𝗔 ⊢ ∼(exactValueSentence p.1 p.2)) := by
  simpa [exactValueSentence] using templateRefutationsRE exactValueGraph

/-- **Main theorem, semantic form.** The statement is identical to the original theorem. -/
theorem flexibleOutputValue :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o := by
  classical
  obtain ⟨search, hpart, hign, hsound, hcomplete⟩ := exists_search exactValueRefutationsRE
  obtain ⟨e, he⟩ := Nat.Partrec.Code.fixed_point₂ hpart
  have noHalt : ∀ y, ¬ y ∈ Nat.Partrec.Code.eval e 0 := by
    intro y hy
    have hp : 𝗣𝗔 ⊢ ∼(exactValueSentence e y) :=
      hsound (by simpa only [he] using hy)
    exact Semantics.Not.models_not.mp
      (models_of_provable (M := ℕ) inferInstance hp)
      ((standardExactValue e y).mpr hy)
  have noRefutation : ∀ n, ¬ (𝗣𝗔 ⊢ ∼(exactValueSentence e n)) := by
    intro n hn
    obtain ⟨m, hm⟩ := hcomplete ⟨n, hn⟩
    exact noHalt m (by simpa only [he] using hm)
  have hdiv : ∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom := by
    intro x hx
    obtain ⟨y, hy⟩ := Part.dom_iff_mem.mp hx
    apply noHalt y
    rw [he, ← hign e x]
    simpa only [he] using hy
  refine ⟨e, Nat.Partrec.Code.eval_part.comp (Computable.const e) Computable.id, hdiv, ?_⟩
  rintro (_ | n)
  · refine ⟨ℕ, inferInstance, inferInstance, ?_⟩
    intro y hy
    apply noHalt y
    exact (universalGraph_nat e 0 y).mp (by
      simpa [OutputIn, numeral_eq_natCast_app] using hy)
  · by_contra hno
    refine noRefutation n
      (Arithmetic.complete.{0} 𝗣𝗔 (∼(exactValueSentence e n)) fun M _ _ => ?_)
    haveI : M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := models_of_subtheory (U := 𝗣𝗔) inferInstance
    exact Semantics.Not.models_not.mpr fun hn =>
      hno ⟨M, inferInstance, inferInstance, valueIn_of_exactValue e n hn⟩

/-- **Main theorem, sentence form.** The statement and sentence interface are unchanged. -/
theorem flexibleOutput :
    ∃ e : Code, Partrec (Nat.Partrec.Code.eval e) ∧
      (∀ x : ℕ, ¬ (Nat.Partrec.Code.eval e x).Dom) ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        M↓[ℒₒᵣ] ⊧ outputSentence e o := by
  obtain ⟨e, hpart, hdiv, hmod⟩ := flexibleOutputValue
  refine ⟨e, hpart, hdiv, fun o => ?_⟩
  obtain ⟨M, inst, hM, ho⟩ := hmod o
  haveI : M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := models_of_subtheory (U := 𝗣𝗔) hM
  exact ⟨M, inst, hM, models_outputSentence_of_valueIn e o ho⟩

/-- **Main theorem.** Its complete statement is unchanged. -/
theorem exists_partrec_flexibleOutput :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ, ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e o := by
  obtain ⟨e, hpart, -, hmod⟩ := flexibleOutputValue
  exact ⟨Nat.Partrec.Code.eval e, hpart, e, rfl, hmod⟩

theorem strongClaim : StrongClaim := by
  obtain ⟨e, -, hdiv, hmod⟩ := flexibleOutput
  refine ⟨e, hdiv, fun n => ?_⟩
  obtain ⟨M, inst, hM, hn⟩ := hmod (some n)
  exact satisfiable_intro M (Semantics.ModelsSet.insert_iff.mpr ⟨hn, hM⟩)

theorem mainClaim : MainClaim := by
  obtain ⟨e, hdiv, hsat⟩ := strongClaim
  exact ⟨e, hdiv 0, hsat⟩

#print axioms flexibleOutputValue
#print axioms flexibleOutput
#print axioms exists_partrec_flexibleOutput
#print axioms strongClaim
#print axioms mainClaim

end PAFlexibleOutput
