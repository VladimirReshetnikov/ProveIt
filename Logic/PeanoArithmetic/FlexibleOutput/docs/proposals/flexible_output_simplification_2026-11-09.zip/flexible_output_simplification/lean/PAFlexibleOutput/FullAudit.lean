import PAFlexibleOutput.Main
import PAFlexibleOutput.Functionality

/-!
# Optional global functionality audit and compatibility theorem

The main theorem no longer depends on this module. The additional theorem
`fullySpecifiedMainClaim` still asserts global functionality of `universalGraph`, including
nonstandard codes and inputs, and therefore retains the original compiler proof.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

section

variable {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]

/-- Retained helper: this direction genuinely uses global functionality. -/
theorem valueIn_of_models (e : Code) (o : Option ℕ) (h : M↓[ℒₒᵣ] ⊧ outputSentence e o) :
    ValueIn M e o := by
  cases o with
  | none =>
    show ∀ y : M, ¬ OutputIn M e y
    intro y hy
    exact (models_divergeSentence e 0).mp h ⟨y, (outputIn_iff e y).mp hy⟩
  | some n =>
    show ∀ y : M, OutputIn M e y ↔ y = ORingStructure.numeral n
    intro y
    have hn := (models_haltSentence e 0 n).mp h
    rw [numeral_eq_natCast_app]
    constructor
    · intro hy
      exact universalGraph_uniq ((outputIn_iff e y).mp hy) hn
    · rintro rfl
      exact (outputIn_iff e _).mpr hn

end

/-- The original strengthened audit proposition, with its global functionality obligation. -/
theorem fullySpecifiedMainClaim : FullySpecifiedMainClaim :=
  ⟨standardCorrectness, functionalityInPAModels, mainClaim⟩

#print axioms fullySpecifiedMainClaim

end PAFlexibleOutput
