import PAFlexibleOutput.Statement
import Foundation.FirstOrder.Incompleteness.First

/-!
# Refutations of instances of a fixed arithmetic template

For any fixed `φ : ArithmeticSemisentence 3`, the relation
`𝗣𝗔 ⊢ ∼(φ/[↑y, ↑(Encodable.encode c), ↑x])` is recursively enumerable in `(c, y)`.
The template itself need not be `𝚺₁`. Only the proof predicate and the syntax operations
used to construct its code need to be `𝚺₁`-definable in the standard natural numbers.

This is the existing `Refutations.lean` argument with its fixed `universalGraph`
parameter exposed. In particular it also applies to a template asserting a unique value.
-/

set_option autoImplicit false

namespace PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic
open Bootstrapping Bootstrapping.Arithmetic

private lemma template_rePred_of_sigma1_rel {P : ℕ → ℕ → Prop} (h : 𝚺₁-Relation P) :
    REPred fun p : ℕ × ℕ => P p.1 p.2 := by
  rcases h with ⟨φ, hφ⟩
  have : REPred fun p : ℕ × ℕ ↦
      (Semiformula.Eval (p.1 ::ᵥ p.2 ::ᵥ List.Vector.nil).get id) φ.val :=
    (sigma1_re id (φ.sigma_prop)).comp
      (Primrec.to_comp <| Primrec.vector_cons.comp .fst <|
        Primrec.vector_cons.comp .snd <| .const _)
  exact this.of_eq <| by
    rintro ⟨a, b⟩
    simpa [List.Vector.cons_get, Matrix.empty_eq] using hφ ![a, b]

private lemma template_refutation_sigma1 (φ : ArithmeticSemisentence 3) (x : ℕ) :
    𝚺₁-Relation fun c y : ℕ ↦
      Bootstrapping.Provable 𝗣𝗔 (neg ℒₒᵣ <| subst ℒₒᵣ
        ?[numeral y, numeral c, numeral x] (⌜φ⌝ : ℕ)) := by
  definability

private lemma template_subst_quote (φ : ArithmeticSemisentence 3) (c y x : ℕ) :
    subst ℒₒᵣ ?[numeral y, numeral c, numeral x] (⌜φ⌝ : ℕ)
      = ⌜(φ/[↑y, ↑c, ↑x] : ArithmeticSentence)⌝ := by
  have h := substNumerals_app_quote (V := ℕ) φ ![y, c, x]
  have hfun : (fun i : Fin 3 ↦ ((![y, c, x] i : ℕ) : Semiterm ℒₒᵣ Empty 0))
      = ![(↑y : Semiterm ℒₒᵣ Empty 0), ↑c, ↑x] := by
    funext i
    match i with
    | ⟨0, _⟩ => rfl
    | ⟨1, _⟩ => rfl
    | ⟨2, _⟩ => rfl
  rw [hfun] at h
  simp only [natCast_nat] at h
  exact h

private lemma template_provable_neg_iff (φ : ArithmeticSemisentence 3)
    (c : Code) (x y : ℕ) :
    Bootstrapping.Provable 𝗣𝗔 (neg ℒₒᵣ <| subst ℒₒᵣ
        ?[numeral y, numeral (Encodable.encode c), numeral x] (⌜φ⌝ : ℕ))
      ↔ 𝗣𝗔 ⊢ ∼(φ/[↑y, ↑(Encodable.encode c), ↑x] : ArithmeticSentence) := by
  have h : neg ℒₒᵣ (subst ℒₒᵣ
      ?[numeral y, numeral (Encodable.encode c), numeral x] (⌜φ⌝ : ℕ))
        = ⌜(∼(φ/[↑y, ↑(Encodable.encode c), ↑x]) : ArithmeticSentence)⌝ := by
    rw [template_subst_quote]
    simp [Sentence.quote_def, Semiformula.quote_def]
  rw [h]
  exact provable_iff_provable

/-- Refutations of a fixed template are recursively enumerable. No hierarchy assumption on
the template is needed. Its variables are value, program code, and ordinary input. -/
theorem templateRefutationsRE (φ : ArithmeticSemisentence 3) (x : ℕ := 0) :
    REPred (fun p : Code × ℕ =>
      𝗣𝗔 ⊢ ∼(φ/[↑p.2, ↑(Encodable.encode p.1), ↑x] : ArithmeticSentence)) := by
  have h := template_rePred_of_sigma1_rel (template_refutation_sigma1 φ x)
  have hc : Computable fun p : Code × ℕ => (Encodable.encode p.1, p.2) :=
    (Computable.encode.comp Computable.fst).pair Computable.snd
  exact (h.comp hc).of_eq fun p => template_provable_neg_iff φ p.1 x p.2

/-- The original halting-sentence relation is retained as a specialization. -/
theorem refutationsRE : RefutationsRE := templateRefutationsRE universalGraph 0

#print axioms templateRefutationsRE
#print axioms refutationsRE

end PAFlexibleOutput
