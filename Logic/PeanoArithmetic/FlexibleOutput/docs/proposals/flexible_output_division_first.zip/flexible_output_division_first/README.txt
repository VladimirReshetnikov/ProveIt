DIVISION FIRST
A shorter arithmetic representation dependency for FlexibleOutput
Prepared 10 November 2026

START HERE

Read report.pdf for the mathematical argument, exact Lean replacement,
comparison with earlier proposals, measurements, and validation limits.
report.tex and snippets/*.lean are the complete editable report sources.

The implementation adds Nat.Arithmetic₁.div, deriving natural division as
the first q satisfying

    a < (q + 1) * b OR b = 0.

It then derives remainder using a % b = a - b * (a / b), and divisibility
using a | b iff b % a = 0. The zero-divisor alternative makes the search
total and gives Lean's a / 0 = 0 convention.

The new theorem block has 19 active lines, including the complete new div
lemma, versus 58 theorem lines before. Removing an obsolete scoped option
gives a 40-line reduction in the complete block (59 to 19). This is a local
dependency simplification; the main FlexibleOutput proof text is unchanged.
The main theorem's reachable declaration closure decreases by 19.

SOURCE PINS

Implementation baseline:
  ProveIt     768379ed8153f13cc6f0b931203d5426f7ee50bf
  Foundation  32e1a0956a8622fad067328ca1959729a7634428
  Mathlib     81a5d257c8e410db227a6665ed08f64fea08e997
  Lean        4.32.0
  Compiler    8c9756b28d64dab099da31a4c09229a9e6a2ef35

The final main-branch review is 7f5ed7ca0a6caebb7d6d6d2bb35431c34a66ed1e.
All 13 proposal archives there were audited for duplication. The six
FlexibleOutput sources, three project configuration files, and Foundation
gitlink were unchanged at that final review.

CONTENTS

report.tex / report.pdf
  Complete proposal, exact source snippets, references, and measurements.

patches/foundation.patch
  The substantive simplification. Apply at the Foundation submodule root.

patches/proveit_import_fix.patch
  A separate baseline integration repair. Main.lean and the facade import
  Refutations although the supplied file is Provability.lean. Both baseline
  and candidate use this same two-line repair. It is not claimed as new.

baseline/ and overlay/
  Full original and replacement snapshots of Foundation/Vorspiel/Arithmetic.lean
  and the six FlexibleOutput Lean files. The root snapshot differs only by
  the two import repairs. The arithmetic overlay is the exact file compiled.

verification/
  Build logs and provenance, affected-module manifest, axiom reports,
  audit programs, application-script checks, and the source of the narrow
  host compatibility shim used during the recorded build.

verification/declarations/
  Complete baseline.json and candidate.json declaration traversals, their
  compact summaries, comparison.json, source_identity.json, an independent
  review, and the portable compare_audits.py analysis script.

evidence/
  Proposal inventory, source metrics and hashes, pinned project configuration,
  repository snapshots, final freshness checks, and independent math review.

licenses/ and NOTICE.txt
  Upstream licenses and source attribution.

SHA256SUMS
  Checksums for all distributed files except the checksum manifest itself.

APPLY AND CHECK

Use an initialized ProveIt checkout with its Foundation submodule and the
pinned Lean toolchain. The scripts need Python 3, Git, Bash, and Lake.
Provide absolute paths or paths relative to your current directory:

  python3 /path/to/package/scripts/apply.py --check-only /path/to/ProveIt
  python3 /path/to/package/scripts/apply.py /path/to/ProveIt
  bash /path/to/package/scripts/check.sh /path/to/ProveIt

The check-only step verifies the six proof-source hashes, project configuration,
Foundation HEAD and parent gitlink, both patches, and the resulting overlay
bytes without changing files. Application performs the same checks before
changing either repository. Unrelated changes are preserved; changed proof
inputs are rejected rather than automatically merged. No staging, commit,
push, pull request, or network operation is performed by apply.py.

A later parent commit is accepted when all relevant bytes and dependency
pins match. Already applied inputs should be checked with:

  python3 /path/to/package/scripts/apply.py --verify-applied /path/to/ProveIt

check.sh verifies the resulting sources, invokes Lake with --rehash for both
PAFlexibleOutput.Main and the PAFlexibleOutput facade, then runs the axiom
and declaration audits. Results go under verification/reproduction by default;
an optional second argument chooses another result directory. Lake may need
to obtain missing packages or build dependencies in a fresh checkout.

The patch changes a submodule working tree. To integrate permanently, record
the Foundation change in the intended repository or fork and update ProveIt's
submodule reference. No external repository was modified by this proposal.

REPRODUCE THE MEASUREMENTS

From this package directory:

  python3 scripts/measure.py
  python3 verification/declarations/compare_audits.py \
    verification/declarations/baseline.json \
    verification/declarations/candidate.json \
    /path/to/new-comparison-directory

measure.py writes evidence/source_metrics.json. It counts nonblank,
noncomment lines after removing Lean line comments and nested block comments.
All added theorem statements and proofs are included.

To regenerate a baseline declaration audit, use a separate clean checkout
at the implementation baseline and apply only proveit_import_fix.patch.
Build PAFlexibleOutput.Main and the facade through that checkout's pinned
Lake environment. Set AUDIT_OUTPUT to an absolute JSON filename and run:

  lake env lean -R /path/to/package/verification \
    /path/to/package/verification/DependencyAudit.lean

For the candidate, check.sh does the corresponding build and audit. Compare
the two JSON files with compare_audits.py. AxiomAudit.lean is intended for
the candidate because the added division theorem is absent from the baseline.

The declaration audit traverses types, values including opaque theorem bodies,
and constructors of referenced inductive types. Counts include generated
auxiliaries. Node counts sum Expr.sizeWithoutSharing; object counts respect
sharing within each expression but do not remove sharing between expressions.
They are not a benchmark of checker time, memory, or serialized artifact size.

VALIDATION PERFORMED

All ten affected or project modules were rebuilt successfully, with no errors
or warnings, in an isolated output tree. The full local import closure has
140 modules; unaffected dependencies reused artifacts from source checkouts
verified against the exact pins. All affected outputs were removed before
rebuilding. The recorded build includes the complete modified arithmetic file.

All twelve selected axiom checks and all three endpoint closure audits have
exactly propext, Classical.choice, and Quot.sound. No reachable sorryAx or
missing declaration was found. Fifteen existing theorem interfaces have
identical raw structural types and universe parameters. Nine semantic
definitions have identical types and values. The six project sources are
byte-identical between the repaired baseline and candidate.

apply.py was exercised on a disposable initialized fixture: check-only,
application, exact resulting bytes, verify-applied, preservation of unrelated
files, and rejection of already-applied or modified proof inputs all passed.
check.sh syntax and its Lake/Lean flags were checked. The portable check.sh
wrapper was not run end-to-end on a newly downloaded dependency tree; the
recorded isolated compiler build and audits provide the actual Lean validation.

The recorded host needed a readlink compatibility shim because its process
namespace did not expose /proc/<getpid()>/exe. The shim retries only that failed
lookup as /proc/self/exe. It does not alter Lean or its kernel. Its source is
in verification/runtime. Ordinary local reproduction does not need the shim.

BUILD THE REPORT

  bash scripts/build_report.sh

This runs XeLaTeX twice. It requires DejaVu Serif, DejaVu Sans, DejaVu Sans Mono,
and the standard TeX packages listed in report.tex. The distributed PDF is
already compiled. Hyperlinks in the bibliography identify pinned primary sources.
