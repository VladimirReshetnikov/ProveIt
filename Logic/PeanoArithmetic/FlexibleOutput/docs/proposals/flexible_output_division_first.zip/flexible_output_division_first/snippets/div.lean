lemma div (i j : Fin n) : Arithmetic₁ (fun v => v.get i / v.get j) := by
  let F : List.Vector ℕ (n + 1) → ℕ := fun v =>
    (isLtNat (v.get i.succ) ((v.head + 1) * v.get j.succ)).or (isEqNat (v.get j.succ) 0)
  have hF : Arithmetic₁ F := (or 0 1).comp₂ _
    ((lt 0 1).comp₂ _ (proj i.succ)
      ((mul 0 1).comp₂ _ ((succ 0).comp₁ _ head) (proj j.succ)))
    ((equal 0 1).comp₂ _ (proj j.succ) zero)
  exact (ArithPart₁.rfindPos hF).of_eq fun v => by
    simp only [F, head_cons, get_cons_succ, or_pos_iff, isLtNat_pos_iff, isEqNat_pos_iff,
      PFun.coe_val, Part.eq_some_iff, Nat.mem_rfind, Part.mem_some_iff]
    by_cases hb : v.get j = 0
    · simp [hb]
    · simp [hb, ← Nat.div_lt_iff_lt_mul (Nat.pos_of_ne_zero hb), Nat.lt_succ_iff]
