lemma rem (i j : Fin n) : Arithmetic₁ (fun v => v.get i % v.get j) := by
  simpa [Nat.mod_def] using
    (sub 0 1).comp₂ _ (proj i) ((mul 0 1).comp₂ _ (proj j) (div i j))
