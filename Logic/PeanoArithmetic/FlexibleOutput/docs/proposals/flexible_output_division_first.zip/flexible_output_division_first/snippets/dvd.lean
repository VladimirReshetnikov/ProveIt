lemma dvd (i j : Fin n) : Arithmetic₁ (fun v => isDvdNat (v.get i) (v.get j)) := by
  simpa [isEqNat, isDvdNat, Nat.dvd_iff_mod_eq_zero] using
    (equal 0 1).comp₂ _ (rem j i) zero
