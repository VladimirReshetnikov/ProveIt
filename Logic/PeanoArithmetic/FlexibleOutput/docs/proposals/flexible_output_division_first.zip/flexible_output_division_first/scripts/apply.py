#!/usr/bin/env python3
# SPDX-License-Identifier: MIT-0
"""Check or apply the exact division-first proposal to an initialized ProveIt checkout.

No network access, commit, staging, branch operation, or push is performed.
Unrelated working-tree changes are permitted. All relevant input bytes, the
Foundation revision, and both patches are checked before either patch is applied.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
AUDITED_REPOSITORY_COMMIT = "768379ed8153f13cc6f0b931203d5426f7ee50bf"
FOUNDATION_COMMIT = "32e1a0956a8622fad067328ca1959729a7634428"
FOUNDATION_DIRECTORY = "lib/FormalizedFormalLogic-Foundation"
FOUNDATION_FILE = "Foundation/Vorspiel/Arithmetic.lean"
PROJECT_PATCH_FILES = (
    "Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Main.lean",
    "Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput.lean",
)
# Exact input hashes, including the other four proof modules and build pins.
PINNED_PROJECT_FILES = {'Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput.lean': '97b3b62a233f90879896d3dee041d17ba31aa2600b3dbe1ea0632e5b05b5d062',
 'Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Functionality.lean': 'fcab43d0a5462e091f7b13e32d81482ece34b34567d0c242e44a0d6482f50d87',
 'Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Halting.lean': 'a77a3f75b11ee35fd2ccad71016159021597328477aee7d56a0e140def07e7f1',
 'Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Main.lean': '6c182711327867187e133d86e2607ce61fa1e1570e42d4659ac941cf9bac35ec',
 'Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Provability.lean': '025922015ea085f7682e7491e624968f69436cf74b2a44978534f961ac52b8f3',
 'Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Search.lean': '10a564473643cea594f742854dcec58a097e25b4de33ac4d8995d3fa7ff007ff',
 'lake-manifest.json': '95e215b005fe9aacc1e5490c781d57e3044d2da5ca452495cfcd0e4eff908665',
 'lakefile.toml': '0d558c995c5025caff70eeb5d98b5bf7838b3452a87bff37e0285aac46c17ebe',
 'lean-toolchain': '2773c517aa90b66ea8a2c52bddddf84393157797f8341be0df45294fff7fd32e'}
PINNED_FOUNDATION_SHA256 = "949269e2319b196951705a818ec6009cbf4f6c0a70b88e3a7aedd120528bf16c"

PINNED_OVERLAY_SHA256 = {'foundation/Foundation/Vorspiel/Arithmetic.lean': '28c9e32a6770712ef4a71700f500c31a7e6496cb3a351f2345b9531f8a548fa2',
 'proveit/Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput.lean': 'cd51f0f67afbf91b24e224bb7a9f3c661074ce9cf2c7c640507cbc3d57346c26',
 'proveit/Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput/Main.lean': '9c557acbeb789e320c408691da1e09f95292c55d570f69db546e76f2bed54b1e'}


class CheckFailure(RuntimeError):
    """An input or validation condition was not met; do not apply blindly."""


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def run_git(directory: Path, *arguments: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(directory), *arguments],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    if result.returncode:
        message = result.stderr.strip() or result.stdout.strip()
        raise CheckFailure(f"Git check failed in {directory}: {message}")
    return result.stdout.strip()


def read(path: Path) -> bytes:
    if not path.is_file():
        raise CheckFailure(f"Required file is missing: {path}")
    if path.is_symlink():
        raise CheckFailure(f"Expected a regular source file, found a symlink: {path}")
    return path.read_bytes()


def check_hash(path: Path, expected: str, description: str) -> bytes:
    data = read(path)
    actual = digest(data)
    if actual != expected:
        raise CheckFailure(
            f"{description} does not match the verified version: {path}\n"
            f"  expected SHA-256: {expected}\n  actual SHA-256:   {actual}\n"
            "No automatic merge is attempted; preserve and review your changes."
        )
    return data


def verify_checkout(repo: Path) -> tuple[Path, str]:
    top = Path(run_git(repo, "rev-parse", "--show-toplevel")).resolve()
    if top != repo:
        raise CheckFailure("Pass the root of the ProveIt checkout, not a subdirectory.")
    head = run_git(repo, "rev-parse", "HEAD")
    foundation = repo / FOUNDATION_DIRECTORY
    if not foundation.is_dir():
        raise CheckFailure(
            f"Initialize the pinned Foundation submodule first: {FOUNDATION_DIRECTORY}"
        )
    foundation_top = Path(run_git(foundation, "rev-parse", "--show-toplevel")).resolve()
    if foundation_top != foundation.resolve():
        raise CheckFailure(
            f"Foundation is not an initialized Git submodule: {FOUNDATION_DIRECTORY}"
        )
    actual_pin = run_git(foundation, "rev-parse", "HEAD")
    if actual_pin != FOUNDATION_COMMIT:
        raise CheckFailure(
            f"Foundation HEAD must be {FOUNDATION_COMMIT}; found {actual_pin}."
        )
    parent_entry = run_git(repo, "ls-tree", "HEAD", "--", FOUNDATION_DIRECTORY).split()
    if len(parent_entry) < 3 or parent_entry[2] != FOUNDATION_COMMIT:
        raise CheckFailure("The parent checkout records a different Foundation revision.")
    return foundation, head


def patch_paths(directory: Path, patch: Path) -> set[str]:
    output = run_git(directory, "apply", "--numstat", "--", str(patch))
    result = set()
    for line in output.splitlines():
        fields = line.split("\t", 2)
        if len(fields) != 3:
            raise CheckFailure(f"Cannot read the touched paths in {patch.name}.")
        result.add(fields[2])
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check-only", action="store_true", help="validate everything without writing")
    mode.add_argument("--verify-applied", action="store_true", help="verify the exact installed candidate without writing")
    parser.add_argument("repo", type=Path, help="root of an initialized ProveIt Git checkout")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    foundation, head = verify_checkout(repo)

    # The archive's overlays are the exact expected results of the two patches.
    for relative, expected in PINNED_OVERLAY_SHA256.items():
        check_hash(PACKAGE_ROOT / "overlay" / relative, expected, "Packaged overlay")
    after = {foundation / FOUNDATION_FILE:
             read(PACKAGE_ROOT / "overlay/foundation" / FOUNDATION_FILE)}
    for relative in PROJECT_PATCH_FILES:
        after[repo / relative] = read(PACKAGE_ROOT / "overlay/proveit" / relative)

    before = {}
    for relative, expected in PINNED_PROJECT_FILES.items():
        target = repo / relative
        wanted = digest(after[target]) if args.verify_applied and target in after else expected
        data = check_hash(target, wanted, "Project input")
        if target in after:
            before[target] = data
    foundation_target = foundation / FOUNDATION_FILE
    foundation_expected = (digest(after[foundation_target]) if args.verify_applied
                           else PINNED_FOUNDATION_SHA256)
    before[foundation_target] = check_hash(
        foundation_target, foundation_expected, "Foundation arithmetic source"
    )

    if args.verify_applied:
        print("PASS: exact candidate sources and all pinned input files verified.")
        print(f"Repository HEAD: {head}")
        return 0

    foundation_patch = PACKAGE_ROOT / "patches/foundation.patch"
    project_patch = PACKAGE_ROOT / "patches/proveit_import_fix.patch"
    for patch in (foundation_patch, project_patch):
        read(patch)
    expected_foundation = {FOUNDATION_FILE}
    if patch_paths(foundation, foundation_patch) != expected_foundation:
        raise CheckFailure("foundation.patch touches an unexpected set of paths.")
    if patch_paths(repo, project_patch) != set(PROJECT_PATCH_FILES):
        raise CheckFailure("proveit_import_fix.patch touches an unexpected set of paths.")

    # Check BOTH repositories before either write operation.
    plans = ((foundation, foundation_patch), (repo, project_patch))
    for directory, patch in plans:
        run_git(directory, "apply", "--check", "--whitespace=nowarn", "--", str(patch))
    # Also prove the patches produce the supplied exact overlays, without using
    # the user checkout as a trial working tree.
    with tempfile.TemporaryDirectory(prefix="flexible-output-apply-") as temporary:
        preview_root = Path(temporary)
        for number, (directory, patch) in enumerate(plans):
            preview = preview_root / str(number)
            preview.mkdir()
            targets = ([foundation_target] if directory == foundation
                       else [repo / relative for relative in PROJECT_PATCH_FILES])
            for target in targets:
                copied = preview / target.relative_to(directory)
                copied.parent.mkdir(parents=True, exist_ok=True)
                copied.write_bytes(before[target])
            run_git(preview, "apply", "--whitespace=nowarn", "--", str(patch))
            for target in targets:
                check_hash(preview / target.relative_to(directory), digest(after[target]),
                           "Patch preview")
    print("PASS: pinned inputs, both patches, and their exact resulting bytes checked.")
    print(f"Audited reference: {AUDITED_REPOSITORY_COMMIT}")
    print(f"Repository HEAD:   {head}")
    if args.check_only:
        print("Check-only mode: no files changed.")
        return 0

    # Guard against edits made between the validation and the application.
    for target, original in before.items():
        check_hash(target, digest(original), "Input changed during validation")
    try:
        for directory, patch in plans:
            run_git(directory, "apply", "--whitespace=nowarn", "--", str(patch))
        for target, expected_bytes in after.items():
            check_hash(target, digest(expected_bytes), "Applied result")
    except (CheckFailure, OSError):
        # Restore only our exact known outputs. Never overwrite an intervening edit.
        for target, original in before.items():
            if target.is_file() and not target.is_symlink():
                current = target.read_bytes()
                if current == after[target]:
                    target.write_bytes(original)
                elif current != original:
                    print(f"Left intervening changes untouched: {target}", file=sys.stderr)
        raise
    print("Applied the arithmetic simplification and the separate two-line import repair.")
    print("No files were staged, committed, or pushed. Run scripts/check.sh next.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (CheckFailure, OSError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
