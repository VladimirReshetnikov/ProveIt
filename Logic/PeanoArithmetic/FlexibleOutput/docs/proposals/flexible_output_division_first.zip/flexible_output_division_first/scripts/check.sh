#!/usr/bin/env bash
# SPDX-License-Identifier: MIT-0
# Rebuild and audit the installed proposal using the checkout's own pinned Lake environment.
set -euo pipefail

if [[ $# -lt 1 || $# -gt 2 ]]; then
  printf 'Usage: %s PROVEIT_CHECKOUT [RESULT_DIRECTORY]\n' "$0" >&2
  exit 2
fi
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
package_dir="$(cd -- "$script_dir/.." && pwd)"
repo_dir="$(cd -- "$1" && pwd)"
result_dir="${2:-$package_dir/verification/reproduction}"
mkdir -p -- "$result_dir"
result_dir="$(cd -- "$result_dir" && pwd)"

python3 "$script_dir/apply.py" --verify-applied "$repo_dir" | tee "$result_dir/source_check.log"
command -v lake >/dev/null || { printf 'lake is not on PATH; install the pinned Lean toolchain first.\n' >&2; exit 1; }
export LAKE_JOBS=1
export LEAN_NUM_THREADS=1
cd -- "$repo_dir"

# --rehash recomputes source hashes. Normal Lake dependency tracking rebuilds all
# affected imports, including Foundation (a local library in this workspace).
# Do not use Lake's --old option, which intentionally ignores transitive changes.
lake --rehash build +PAFlexibleOutput.Main 2>&1 | tee "$result_dir/build_main.log"
lake --rehash build +PAFlexibleOutput 2>&1 | tee "$result_dir/build_umbrella.log"

# The repaired source imports Provability, so an obsolete Refutations.olean
# cannot satisfy any import in this proof. Audit through the checkout's own
# Lake environment; no external cache paths or host-specific shims are supplied.
lake env lean -R "$package_dir/verification" "$package_dir/verification/AxiomAudit.lean" \
  2>&1 | tee "$result_dir/axioms.log"
export AUDIT_OUTPUT="$result_dir/dependency_audit.json"
lake env lean -R "$package_dir/verification" "$package_dir/verification/DependencyAudit.lean" \
  2>&1 | tee "$result_dir/dependencies.log"
printf 'PASS: both build targets and both audits completed. Results: %s\n' "$result_dir"
