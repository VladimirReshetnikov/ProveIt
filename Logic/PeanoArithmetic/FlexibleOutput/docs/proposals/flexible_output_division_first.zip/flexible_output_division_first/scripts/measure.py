#!/usr/bin/env python3
"""Reproduce source counts from the complete before/after snapshots.

An active line is a nonblank line after removing line comments and nested
block comments. The scanner preserves strings and line boundaries. Counts
include theorem statements and every line of the new division theorem.
"""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
REL=Path("Foundation/Vorspiel/Arithmetic.lean")

def strip_comments(s):
    out=[];i=0;depth=0;quoted=False
    while i<len(s):
        if depth:
            if s.startswith("/-",i):depth+=1;i+=2
            elif s.startswith("-/",i):depth-=1;i+=2
            else:
                if s[i]=="\n":out.append("\n")
                i+=1
        elif quoted:
            out.append(s[i])
            if s[i]=="\\" and i+1<len(s):out.append(s[i+1]);i+=2
            elif s[i]=='"':quoted=False;i+=1
            else:i+=1
        elif s.startswith("/-",i):depth=1;i+=2
        elif s.startswith("--",i):
            j=s.find("\n",i);i=len(s) if j<0 else j
        else:
            if s[i]=='"':quoted=True
            out.append(s[i]);i+=1
    if depth:raise ValueError("Unclosed block comment")
    return "".join(out)

def metrics(s):
    stripped=strip_comments(s)
    active=[line.rstrip() for line in stripped.splitlines() if line.strip()]
    return {"active_lines":len(active),"physical_lines":len(s.splitlines()),
            "raw_utf8_bytes":len(s.encode()),
            "nonspace_characters":sum(not c.isspace() for c in stripped)}

def declaration(s,name,next_name):
    a=s.index("lemma "+name+" (")
    b=s.index("\nlemma "+next_name+" (",a)
    return s[a:b].strip()+"\n"

before=(ROOT/"baseline/foundation"/REL).read_text()
after=(ROOT/"overlay/foundation"/REL).read_text()
old_dvd=declaration(before,"dvd","rem")
old_rem=declaration(before,"rem","beta")
new_div=declaration(after,"div","rem")
new_rem=declaration(after,"rem","dvd")
new_dvd=declaration(after,"dvd","beta")
old_start=before.index("set_option backward.isDefEq.respectTransparency false in\nlemma dvd (")
old_end=before.index("\nlemma beta (",old_start)
new_start=after.index("/-- Natural division is the first quotient")
new_end=after.index("\nlemma beta (",new_start)
data={
    "definition":"Nonblank lines after removing comments; statements and all added helpers included.",
    "theorems":{
        "dvd":{"before":metrics(old_dvd),"after":metrics(new_dvd)},
        "rem":{"before":metrics(old_rem),"after":metrics(new_rem)},
        "div":{"before":metrics(""),"after":metrics(new_div)}},
    "theorem_slice":{"before":metrics(old_dvd+old_rem),
                     "after":metrics(new_div+new_rem+new_dvd)},
    "complete_replaced_block":{"before":metrics(before[old_start:old_end]),
                              "after":metrics(after[new_start:new_end])},
    "whole_arithmetic_file":{"before":metrics(before),"after":metrics(after)}
}
dest=ROOT/"evidence/source_metrics.json"
dest.write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(data,indent=2))
