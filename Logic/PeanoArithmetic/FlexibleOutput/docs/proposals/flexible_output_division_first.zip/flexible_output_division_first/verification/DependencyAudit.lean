import PAFlexibleOutput.Main
import Lean

open Lean Elab Command

set_option maxRecDepth 100000
set_option maxHeartbeats 0

/- This reads the elaborated environment only.  It follows types, all available
values (including opaque theorem bodies), and constructors of referenced
inductive types.  No proof search, simplification or cache write is performed. -/
run_cmd do
  let env ← getEnv
  let roots : Array Name := #[
    ``PAFlexibleOutput.flexibleOutput,
    ``PAFlexibleOutput.flexibleOutput_satisfiable,
    ``PAFlexibleOutput.exists_partrec_flexibleOutput]
  let targets : Array Name := #[
    `Nat.Arithmetic₁.div, ``Nat.Arithmetic₁.rem, ``Nat.Arithmetic₁.dvd,
    ``Nat.Arithmetic₁.beta, ``Nat.Arithmetic₁.prec,
    ``Nat.ArithPart₁.of_partrec, ``LO.FirstOrder.Arithmetic.codeOfPartrec'_spec]
  let interfaces : Array Name := #[
    ``Nat.Arithmetic₁.rem, ``Nat.Arithmetic₁.dvd,
    ``Nat.Arithmetic₁.beta, ``Nat.Arithmetic₁.prec,
    ``Nat.ArithPart₁.of_partrec, ``LO.FirstOrder.Arithmetic.codeOfPartrec'_spec,
    ``PAFlexibleOutput.standardCorrectness,
    ``PAFlexibleOutput.valueIn_of_models,
    ``PAFlexibleOutput.refutationsRE,
    ``PAFlexibleOutput.exists_selector,
    ``PAFlexibleOutput.universalGraph_uniq,
    ``PAFlexibleOutput.universalGraph_sigma_one] ++ roots
  let definitions : Array Name := #[
    ``PAFlexibleOutput.Code, ``PAFlexibleOutput.universalEval,
    ``PAFlexibleOutput.universalGraph, ``PAFlexibleOutput.haltSentence,
    ``PAFlexibleOutput.OutputIn, ``PAFlexibleOutput.ValueIn,
    ``LO.FirstOrder.Arithmetic.codeAux, ``LO.FirstOrder.Arithmetic.code,
    ``LO.FirstOrder.Arithmetic.codeOfPartrec']
  let mut allNames : NameSet := {}
  let mut rootResults : Array Json := #[]
  let mut records : Array Json := #[]
  let mut missing : NameSet := {}
  for root in roots do
    let mut pending : List Name := [root]
    let mut seen : NameSet := {}
    let mut parent : NameMap Name := {}
    while !pending.isEmpty do
      let name := pending.head!
      pending := pending.tail!
      if seen.contains name then continue
      seen := seen.insert name
      match env.checked.get.find? name with
      | none => missing := missing.insert name
      | some ci =>
        let value := ci.value? (allowOpaque := true)
        let mut refs := ci.type.getUsedConstants
        if let some expression := value then
          refs := refs ++ expression.getUsedConstants
        if let .inductInfo iv := ci then
          refs := refs ++ iv.ctors.toArray
        for dependency in refs do
          if dependency != root && !parent.contains dependency then
            parent := parent.insert dependency name
        pending := refs.toList ++ pending
        if !allNames.contains name then
          allNames := allNames.insert name
          let origin := match env.getModuleIdxFor? name with
            | some index => env.header.moduleNames.getD index.toNat .anonymous
            | none => env.mainModule
          let typeObjects ← liftIO ci.type.numObjs
          let valueObjects ← match value with
            | some expression => liftIO expression.numObjs
            | none => pure 0
          records := records.push <| Json.mkObj [
            ("name", toJson name.toString),
            ("module", toJson origin.toString),
            ("references", toJson (refs.map Name.toString)),
            ("type_nodes_without_sharing", toJson ci.type.sizeWithoutSharing),
            ("value_nodes_without_sharing", toJson ((value.map Expr.sizeWithoutSharing).getD 0)),
            ("type_objects", toJson typeObjects),
            ("value_objects", toJson valueObjects),
            ("type_hash", toJson (toString (hash ci.type))),
            ("value_hash", toJson ((value.map (fun e => toString (hash e))).getD "none")),
            ("is_axiom", toJson ci.isAxiom)]
    let mut targetResults : Array Json := #[]
    for target in targets do
      let mut path : List Name := []
      if seen.contains target then
        let mut cursor := target
        path := [cursor]
        let mut pathSeen : NameSet := {}
        while cursor != root && !pathSeen.contains cursor do
          pathSeen := pathSeen.insert cursor
          match parent.find? cursor with
          | none => break
          | some previous =>
            path := previous :: path
            cursor := previous
      targetResults := targetResults.push <| Json.mkObj [
        ("name", toJson target.toString),
        ("reachable", toJson (seen.contains target)),
        ("example_path", toJson (path.map Name.toString))]
    rootResults := rootResults.push <| Json.mkObj [
      ("root", toJson root.toString),
      ("declaration_count", toJson seen.size),
      ("targets", Json.arr targetResults)]
  let mut sizes : Array Json := #[]
  for name in targets ++ roots do
    match env.checked.get.find? name with
    | none => pure ()
    | some ci =>
      let value := ci.value? (allowOpaque := true)
      let typeObjects ← liftIO ci.type.numObjs
      let valueObjects ← match value with
        | some expression => liftIO expression.numObjs
        | none => pure 0
      sizes := sizes.push <| Json.mkObj [
        ("name", toJson name.toString),
        ("type_nodes_without_sharing", toJson ci.type.sizeWithoutSharing),
        ("value_nodes_without_sharing", toJson ((value.map Expr.sizeWithoutSharing).getD 0)),
        ("type_objects", toJson typeObjects),
        ("value_objects", toJson valueObjects),
        ("type_hash", toJson (toString (hash ci.type))),
        ("value_hash", toJson ((value.map (fun e => toString (hash e))).getD "none"))]
  let mut interfaceSnapshot : Array Json := #[]
  for name in interfaces ++ definitions do
    match env.checked.get.find? name with
    | none => throwError "Missing audited interface {name}"
    | some ci =>
      let value := ci.value? (allowOpaque := true)
      interfaceSnapshot := interfaceSnapshot.push <| Json.mkObj [
        ("name", toJson name.toString),
        ("universe_parameters", toJson (ci.levelParams.map Name.toString)),
        ("type_repr", toJson (reprStr ci.type)),
        ("type_hash", toJson (toString (hash ci.type))),
        ("definition_value_repr", if definitions.contains name then
          toJson ((value.map reprStr).getD "none") else Json.null),
        ("value_hash", toJson ((value.map (fun e => toString (hash e))).getD "none"))]
  let result := Json.mkObj [
    ("roots", Json.arr rootResults),
    ("union_declaration_count", toJson allNames.size),
    ("missing", toJson (missing.toList.map Name.toString)),
    ("selected_expression_sizes", Json.arr sizes),
    ("interface_snapshot", Json.arr interfaceSnapshot),
    ("declarations", Json.arr records)]
  let target ← liftIO <| IO.getEnv "AUDIT_OUTPUT"
  let filename := target.getD "dependency-audit.json"
  liftIO <| IO.FS.writeFile filename (result.pretty ++ "\n")
  logInfo m!"Dependency audit: {allNames.size} declarations, {missing.size} missing; wrote {filename}"

#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
