import PAFlexibleOutput

#print axioms Nat.Arithmetic₁.div
#print axioms Nat.Arithmetic₁.rem
#print axioms Nat.Arithmetic₁.dvd
#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.valueIn_of_models
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.exists_selector
#print axioms PAFlexibleOutput.universalGraph_uniq
#print axioms PAFlexibleOutput.universalGraph_sigma_one
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
