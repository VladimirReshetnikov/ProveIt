#!/usr/bin/env python3
"""Compare two DependencyAudit JSON files, including complete reachable closures.

Usage: python3 compare_audits.py BASELINE CANDIDATE OUTPUT_DIRECTORY
Source-file identity is checked separately in source_identity.json, when supplied.
"""

import json
import sys
from pathlib import Path

baseline_path, candidate_path, output_dir = map(Path, sys.argv[1:])
output_dir.mkdir(parents=True, exist_ok=True)
b = json.loads(baseline_path.read_text())
c = json.loads(candidate_path.read_text())
bd = {x["name"]: x for x in b["declarations"]}
cd = {x["name"]: x for x in c["declarations"]}
size_keys = ("type_nodes_without_sharing", "value_nodes_without_sharing",
             "type_objects", "value_objects")


def repository_local(d):
    return d["module"].startswith(("Foundation.", "PAFlexibleOutput."))


def totals(records):
    records = list(records)
    return {"declarations": len(records),
            **{key: sum(d[key] for d in records) for key in size_keys}}


def delta(before, after):
    return {key: {"before": before[key], "after": after[key],
                  "saved": before[key] - after[key],
                  "percent_saved": (100 * (before[key] - after[key]) / before[key]
                                    if before[key] else None)} for key in before}


def closure(records, root):
    pending, seen = [root], set()
    while pending:
        n = pending.pop()
        if n in seen:
            continue
        seen.add(n)
        pending.extend(records[n]["references"])
    return [records[n] for n in seen]


comparison = {"method": {
    "closure": "Types, values including opaque proof bodies, and referenced inductive constructors.",
    "local_boundary": "Origin module begins Foundation. or PAFlexibleOutput.",
    "nodes": "Sum of Expr.sizeWithoutSharing over separately counted expressions.",
    "objects": "Sum of Expr.numObjs over separately counted expressions; internal sharing is respected but sharing between separate types/values/declarations is not subtracted.",
    "qualification": "These are syntactic expression counts, not compiled file size, heap usage, kernel time, or a size obtained by recursively inlining constants."},
    "interfaces": [], "per_root_closures": []}

bi = {x["name"]: x for x in b["interface_snapshot"]}
ci = {x["name"]: x for x in c["interface_snapshot"]}
for name, bx in bi.items():
    cx = ci[name]
    row = {"name": name,
           "universe_parameters_equal": bx["universe_parameters"] == cx["universe_parameters"],
           "type_repr_equal": bx["type_repr"] == cx["type_repr"],
           "type_hash_equal": bx["type_hash"] == cx["type_hash"],
           "value_hash_equal": bx["value_hash"] == cx["value_hash"]}
    if bx["definition_value_repr"] is not None:
        row["definition_value_repr_equal"] = bx["definition_value_repr"] == cx["definition_value_repr"]
    comparison["interfaces"].append(row)

for br in b["roots"]:
    root = br["root"]
    before, after = closure(bd, root), closure(cd, root)
    comparison["per_root_closures"].append({"root": root,
        "all": delta(totals(before), totals(after)),
        "repository_local": delta(totals(filter(repository_local, before)),
                                  totals(filter(repository_local, after)))})
comparison["union_closure"] = {
    "all": delta(totals(bd.values()), totals(cd.values())),
    "repository_local": delta(totals(filter(repository_local, bd.values())),
                              totals(filter(repository_local, cd.values())))}

affected = ["Nat.Arithmetic₁.div", "Nat.Arithmetic₁.rem", "Nat.Arithmetic₁.dvd"]
comparison["named_affected_bodies"] = []
bs = {x["name"]: x for x in b["selected_expression_sizes"]}
cs = {x["name"]: x for x in c["selected_expression_sizes"]}
for name in affected:
    before, after = bs.get(name), cs[name]
    comparison["named_affected_bodies"].append({"name": name,
        "baseline_reachable_from_endpoint_union": name in bd,
        "candidate_reachable_from_endpoint_union": name in cd,
        "before_nodes": before["value_nodes_without_sharing"] if before else 0,
        "after_nodes": after["value_nodes_without_sharing"],
        "before_objects": before["value_objects"] if before else 0,
        "after_objects": after["value_objects"]})
comparison["added_constants"] = sorted(cd.keys() - bd.keys())
comparison["removed_constants"] = sorted(bd.keys() - cd.keys())
comparison["changed_common_constants"] = [
    {"name": name, "module": cd[name]["module"],
     "type_changed": bd[name]["type_hash"] != cd[name]["type_hash"],
     "value_changed": bd[name]["value_hash"] != cd[name]["value_hash"],
     **{key: {"before": bd[name][key], "after": cd[name][key]} for key in size_keys}}
    for name in sorted(cd.keys() & bd.keys())
    if bd[name]["type_hash"] != cd[name]["type_hash"]
    or bd[name]["value_hash"] != cd[name]["value_hash"]]
comparison["baseline_axioms"] = sorted(d["name"] for d in bd.values() if d["is_axiom"])
comparison["candidate_axioms"] = sorted(d["name"] for d in cd.values() if d["is_axiom"])
comparison["missing"] = {"baseline": b["missing"], "candidate": c["missing"]}

for label, data in (("baseline", b), ("candidate", c)):
    (output_dir / f"{label}_summary.json").write_text(json.dumps(
        {k: v for k, v in data.items() if k != "declarations"}, indent=2) + "\n")
(output_dir / "comparison.json").write_text(json.dumps(comparison, indent=2) + "\n")
print(json.dumps({"union_closure": comparison["union_closure"],
                  "axioms": comparison["candidate_axioms"],
                  "changed_common_constants": len(comparison["changed_common_constants"]),
                  "public_types_equal": all(x["type_repr_equal"] and x["universe_parameters_equal"]
                                            for x in comparison["interfaces"]),
                  "semantic_definitions_equal": all(x.get("definition_value_repr_equal", True)
                                                     for x in comparison["interfaces"])}, indent=2))
