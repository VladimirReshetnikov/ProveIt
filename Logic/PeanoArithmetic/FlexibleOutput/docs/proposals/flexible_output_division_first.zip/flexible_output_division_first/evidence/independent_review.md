# Independent review: quotient-first arithmetic representation

## Mathematical result

The new construction is sound. For dividend `a` and divisor `b`, search for the
least `q` satisfying

`a < (q + 1) * b ∨ b = 0`.

If `b > 0`, `Nat.div_lt_iff_lt_mul` converts the inequality into
`a / b < q + 1`, equivalently `a / b ≤ q`. Thus the first successful candidate is
exactly `a / b`. The search predicate is total, so earlier candidates cannot
block the search by divergence.

If `b = 0`, every candidate satisfies the second disjunct. The first candidate
is zero, agreeing with Lean's natural-number convention `a / 0 = 0`. This case
is handled explicitly rather than inferred by a positive-divisor theorem.

Remainder is then represented by the existing arithmetic operations using
`Nat.mod_def`: `a % b = a - b * (a / b)`. Divisibility is represented by testing
whether `b % a = 0`, using `Nat.dvd_iff_mod_eq_zero`. These equalities remain
correct for divisor zero: `a % 0 = a`, and `0 ∣ a` holds exactly when `a = 0`.

## Dependency order

The construction does not rely on the old divisibility or remainder
representation:

* The quotient witness uses only the earlier `Arithmetic₁` lemmas for
  projections, zero, successor, multiplication, comparison, equality,
  disjunction, and composition, followed by `ArithPart₁.rfindPos`.
* `rfindPos` itself depends only on the earlier equality/comparison/inversion
  operations and the original minimization constructor.
* New remainder uses the earlier subtraction and multiplication constructions
  plus new quotient.
* New divisibility uses new remainder, equality, and zero.

The ordinary numeric lemmas `Nat.div_lt_iff_lt_mul`, `Nat.mod_def`, and
`Nat.dvd_iff_mod_eq_zero` are Mathlib/Nat arithmetic facts; they do not invoke
`Arithmetic₁.div`, `Arithmetic₁.rem`, or `Arithmetic₁.dvd`.

Accordingly, replacing the old `dvd`-then-`rem` block by `div`-then-`rem`-then-`dvd`
removes the old dependency from remainder to divisibility without introducing a
cycle. The full replacement file must be elaborated from its earlier source
prefix to confirm this structural observation; compiling the initial experiment
alone imports the original module and is insufficient by itself for that claim.

## Preservation and scope

The existing remainder and divisibility theorem types are preserved. The new
quotient theorem is an additive interface. No definition of a partial function,
program graph, semantic output, arithmetic theory, or FlexibleOutput endpoint
needs to change. Only the proofs that the corresponding ordinary numerical
functions have arithmetic representations change.

Source-size accounting must charge the entire added quotient theorem against
the removed original remainder and divisibility proofs. It should describe a
simplification of the arithmetic representation dependency layer, not a shorter
body for Main or an improvement in the constructed program's running time.

This is a different mechanism from earlier monad-law refactors, composition
witness changes, quotienting source syntax, fair-search rewrites, and the newly
added compositional RE and witness-search proposals: it changes the order of
constructing elementary arithmetic operations.

## Exact integrated source review

The exact final overlay `candidate2/overlay/Foundation/Vorspiel/Arithmetic.lean`
was compared against its baseline. Beyond a modification notice, the only change
is replacement of the old divisibility/remainder block by the new
quotient/remainder/divisibility block. All preceding definitions and lemmas are
unchanged. The following `beta` theorem and the entire primitive-recursion
construction are unchanged. The old scoped transparency option for `dvd` is no
longer needed.

This removes the integration ambiguity of the prototype: the final source prefix
contains no prior `Arithmetic₁.dvd` or `Arithmetic₁.rem` that the quotient proof
could accidentally use. The exact new proof uses only the earlier arithmetic
constructors listed above.

## Worked example

For dividend 17 and divisor 5, the threshold test is:

| Candidate q | Next multiple (q + 1) × 5 | Test 17 < next multiple |
| ---: | ---: | --- |
| 0 | 5 | false |
| 1 | 10 | false |
| 2 | 15 | false |
| 3 | 20 | true |

Thus the first successful candidate is 3, and the remainder is
`17 - 5 * 3 = 2`. For divisor zero the explicit second disjunct succeeds already
at candidate zero.

## Source accounting

Counting nonblank theorem declaration/proof lines, original `dvd` has 34 and
original `rem` has 24; the new `div` has 13, new `rem` has 3, and new `dvd` has 3.
Thus the theorem slice is 58 to 19 lines, including all of the added quotient
helper. Counting the original one-line scoped transparency option gives 59 to
19, a saving of 40 active source lines. The chosen convention should be stated
and used consistently. None of Main's unchanged source lines should be claimed
as deleted.

## Validation status

The exact prototype and exact integrated source were inspected. The mathematical
case analysis, imported arithmetic facts, and dependency order pass independent
review. Build evidence is supplied by the build agent; this review does not
claim an additional redundant compilation.
