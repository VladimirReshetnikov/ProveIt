FLEXIBLEOUTPUT: SIMPLIFYING THE FOUNDATION DEPENDENCIES
Prepared for Vladimir Reshetnikov, 10 November 2026

RESULT

This is a checked, new proposal relative to all four archives in the requested
FlexibleOutput/docs/proposals directory at the reviewed ProveIt revision.

The main change replaces Foundation's monotone finite-prefix projection search
with direct paired scheduling. The theorem's existing uniform-output hypothesis
identifies whichever answer the search finds, eliminating the prefix induction,
stage-monotonicity proof, and maximum-based synchronization.

Two supporting changes use partial-value membership throughout the arithmetic
representation correctness proof and monad laws in ArithPart_1.bind/map.
Narrow imports remove twelve repository modules from the target's source closure.
A two-line local equality-theory instance in Main supplies the one premise that
previously arrived incidentally through the removed imports.

The original main theorem, both corollaries, standard graph correctness, Sigma_1
complexity, and arbitrary-model uniqueness are preserved. Both the full library
and the identical before/after dependency audit pass Lean 4.32.0. No sorryAx is
reachable. Public FlexibleOutput results retain precisely propext,
Classical.choice, and Quot.sound. The revised bind/map helpers no longer need
Classical.choice.

MEASUREMENTS

                              Before       After
Local imported modules           139         127
Active imported source lines   30,959      29,126
Four changed helper declarations 115          55 active lines
Projection declaration            53          19 active lines
Projection expression nodes   19,294       3,698 (without sharing)

Main gains two active lines and 108 expression nodes to expose the equality
instance explicitly. The full scope includes Foundation, registered as a local
Lake library. Imported source removed from the closure is not deleted source.
Expression counts are not serialized proof sizes or timing benchmarks.

FILES

flexible_output_dependency_simplification.pdf
    Complete mathematical argument, comparison, measurements, limitations,
    validation, and further research questions.

flexible_output_dependency_simplification.tex, other *.tex, snippets/
    Complete report source and included tables/code.

patches/proveit.patch
    Root-repository changes to Refutations.lean and Main.lean.

patches/foundation.patch
    Four proof/import changes inside the Foundation submodule.

overlay/ and baseline/
    Exact replacement and original versions of all six changed source files.

verification/Audit.lean
    Seven exact-interface checks; transitive type/opaque-body dependency audit;
    private representation-proof reachability; expression counts; axiom reports;
    imported local module names; rejection of reachable sorryAx.

verification/*.log, verification/*.json, verification_status.json
    Full baseline/final build and audit evidence, source integrity, compiler pins.
    artifact_review.json records the final package and rendered-report checks.
    evidence/adversarial_review.json preserves the earlier pre-integration review;
    its pending-build remarks are superseded by the final verification records.

evidence/*import*.json, evidence/source_metrics.json
    Complete local import graphs, per-module hashes, measurements, and exact
    agreement between static traversal and Lean's imported-module sets.

evidence/novelty_inventory.json, evidence/prior_archives_manifest.json
    Review of all four prior proposal archives, including unimplemented ideas
    already mentioned in their further-research sections.

scripts/
    Patch application, Lean audit, source measurements, and report rebuilding.

SHA256SUMS
    Integrity manifest for the package contents, excluding this manifest itself.

PINNED ENVIRONMENT

ProveIt:   6b28681d36720d17c4a539b65717c93d57ee106a
Foundation:32e1a0956a8622fad067328ca1959729a7634428
Mathlib:   81a5d257c8e410db227a6665ed08f64fea08e997
Lean:      4.32.0

APPLY AND CHECK

Use a checkout at the pins above with its Foundation submodule initialized.
The Python application helper verifies both revisions and checks both patches
before applying either. It performs no commit, push, or remote operation.

  python3 /path/to/package/scripts/apply.py /path/to/ProveIt --check-only
  python3 /path/to/package/scripts/apply.py /path/to/ProveIt
  cd /path/to/ProveIt
  lake build PAFlexibleOutput
  lake env lean /path/to/package/verification/Audit.lean

To measure the current checkout's complete local source closure:

  python3 /path/to/package/scripts/measure_import_closure.py \
    --repo /path/to/ProveIt --label modified --output current_closure.json

To reproduce the included helper-declaration measurements:

  python3 /path/to/package/scripts/measure_source.py

The scripts use Python 3.11+ (tomllib) and Git. Lean checks use the repository's
normal pinned dependencies. The package does not bundle Lean or Mathlib binaries.

The Foundation patch is applied inside its submodule. For permanent repository
integration, record those changes in the intended Foundation repository/fork and
update the parent submodule reference as appropriate. The package itself creates
no such commit or public change.

REPORT BUILD

With a normal TeX installation containing pdfLaTeX, Latin Modern, AMS fonts,
listings, xurl, and the standard packages named in the preamble:

  bash scripts/build_report.sh

All report inputs are included. The successful authoring environment generated
its missing standard pdfLaTeX format and font map locally; the mathematical source
and compiler were not changed. An ordinarily configured TeX installation does not
need that environment-specific repair.

COMPATIBILITY AND SCOPE

Narrowing public imports removes incidental transitive reexports. External clients
that used incompleteness results through InductionSchemeDelta1 may need explicit
imports of First/Second or the relevant module. Existing theorem declarations and
definitions are preserved. Validation covers the target library and the supplied
audits, not every external client.

There is no controlled computation-time, elaboration-time, or serialized-proof-size
benchmark. Before/after build durations are not comparable because the final build
reused previously checked dependencies. The report makes no global minimality claim.

The evaluated comp_2 cleanup is intentionally excluded: the declaration audit
showed it was not an actual dependency of the main theorem.

LICENSES

Unmodified and modified ProveIt material follows licenses/ProveIt-MIT-0.txt.
Foundation source follows licenses/Foundation-Apache-2.0.txt. Modification notices
are embedded in the changed Foundation files. See NOTICE.txt.
