lemma projection {f : ℕ →. ℕ} (hf : Nat.Partrec f)
    (unif : ∀ {m n₁ n₂ a₁ a₂ : ℕ},
      a₁ ∈ f (m.pair n₁) → a₂ ∈ f (m.pair n₂) → a₁ = a₂) :
    ∃ g : ℕ →. ℕ, Nat.Partrec g ∧
      (∀ a m, a ∈ g m ↔ ∃ z, a ∈ f (m.pair z)) := by
  obtain ⟨cf, rfl⟩ := Code.exists_code.1 hf
  let stage (m k : ℕ) := cf.evaln k.unpair.2 (m.pair k.unpair.1)
  have hstage : Primrec₂ stage := .to₂ <|
    Code.primrec_evaln.comp (((snd.comp (Primrec.unpair.comp snd)).pair (.const cf)).pair
      (Primrec₂.natPair.comp fst (fst.comp (Primrec.unpair.comp snd))))
  have sound {m a} (ha : a ∈ Nat.rfindOpt (stage m)) :
      ∃ z, a ∈ cf.eval (m.pair z) := by
    obtain ⟨k, hk⟩ := Nat.rfindOpt_spec ha
    exact ⟨k.unpair.1, Code.evaln_sound hk⟩
  refine ⟨_, Partrec.nat_iff.mp (Partrec.rfindOpt hstage.to_comp), fun a m => ⟨sound, ?_⟩⟩
  rintro ⟨z, hz⟩
  obtain ⟨s, hs⟩ := Code.evaln_complete.mp hz
  have hd : (Nat.rfindOpt (stage m)).Dom :=
    Nat.rfindOpt_dom.mpr ⟨Nat.pair z s, a, by simpa [stage] using hs⟩
  obtain ⟨w, hw⟩ := Part.dom_iff_mem.mp hd
  obtain ⟨z', hz'⟩ := sound hw
  exact (unif hz' hz) ▸ hw
