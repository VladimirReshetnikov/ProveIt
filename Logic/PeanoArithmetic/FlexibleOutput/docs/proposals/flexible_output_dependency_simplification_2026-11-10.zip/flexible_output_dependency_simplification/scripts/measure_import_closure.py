#!/usr/bin/env python3
"""Measure all in-repository Lean modules reachable from FlexibleOutput.Main.

Foundation is a git submodule registered as a local Lake library and is counted.
Mathlib and Lean core are external package boundaries, not silently counted as zero.
"""
import argparse
import hashlib
import json
import pathlib
import re
import tomllib

def strip_comments(text):
    out = []
    depth = 0
    i = 0
    in_string = False
    while i < len(text):
        c = text[i]
        pair = text[i:i+2]
        if depth:
            if pair == '/-':
                depth += 1; i += 2
            elif pair == '-/':
                depth -= 1; i += 2
            else:
                if c == '\n': out.append('\n')
                i += 1
        elif in_string:
            out.append(c)
            if c == '\\' and i+1 < len(text):
                out.append(text[i+1]); i += 2
            else:
                if c == '"': in_string = False
                i += 1
        elif pair == '/-':
            depth = 1; i += 2
        elif pair == '--':
            j = text.find('\n', i)
            i = len(text) if j < 0 else j
        else:
            out.append(c)
            if c == '"': in_string = True
            i += 1
    return ''.join(out)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repo',type=pathlib.Path,required=True)
    ap.add_argument('--output',type=pathlib.Path,required=True)
    ap.add_argument('--label',default='observed',help='Descriptive name, for example baseline or modified')
    ap.add_argument('--entrypoint',default='PAFlexibleOutput.Main')
    args=ap.parse_args()
    repo=args.repo.resolve()
    lake_config=tomllib.loads((repo/'lakefile.toml').read_text())
    libraries=lake_config.get('lean_lib',[])
    roots=sorted({(repo/lib.get('srcDir','.')).resolve() for lib in libraries})
    def resolve(module):
        relative=pathlib.Path(*module.split('.')).with_suffix('.lean')
        found=[root/relative for root in roots if (root/relative).is_file()]
        if len(found)>1:
            raise RuntimeError(f'Ambiguous local module {module}: {found}')
        return found[0] if found else None
    records={}; boundary=set(); visited=set()
    def visit(module):
        if module in visited:return
        visited.add(module)
        path=resolve(module)
        if path is None:
            boundary.add(module);return
        text=path.read_text()
        clean=strip_comments(text)
        imports=re.findall(r'(?m)^\s*(?:(?:public|private)\s+)?(?:meta\s+)?import\s+(?:all\s+)?([A-Za-z_][\w.]*)',clean)
        records[module]={
          'path':str(path.relative_to(repo)),
          'physical_lines':len(text.splitlines()),
          'active_lines':sum(bool(x.strip()) for x in clean.splitlines()),
          'bytes':len(text.encode()),
          'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
          'imports':imports,
        }
        for item in imports:visit(item)
    visit(args.entrypoint)
    result={'label':args.label,
       'status':'observed checkout; no source transformation',
       'entrypoint':args.entrypoint,
       'lake_libraries':libraries,
       'local_source_roots':[str(p.relative_to(repo)) for p in roots],
       'local_module_count':len(records),
       'physical_lines':sum(x['physical_lines'] for x in records.values()),
       'active_lines':sum(x['active_lines'] for x in records.values()),
       'bytes':sum(x['bytes'] for x in records.values()),
       'modules':dict(sorted(records.items())),
       'external_import_boundary':sorted(boundary)}
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['modules','external_import_boundary','lake_libraries','local_source_roots']}))

if __name__=='__main__':main()
