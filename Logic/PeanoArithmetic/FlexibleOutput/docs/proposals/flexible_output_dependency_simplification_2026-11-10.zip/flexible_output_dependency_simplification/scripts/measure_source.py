#!/usr/bin/env python3
"""Reproduce declaration source measurements from the included before/after files."""
from __future__ import annotations
import argparse
import json
import pathlib
from measure_import_closure import strip_comments

SUB = 'lib/FormalizedFormalLogic-Foundation/'
DECLARATIONS = [
    ('Nat.Partrec.projection', SUB + 'Foundation/Vorspiel/Computability.lean',
     'lemma projection ', '\n\nend Nat.Partrec'),
    ('models_codeAux', SUB + 'Foundation/FirstOrder/Arithmetic/R0/Representation.lean',
     'private lemma models_codeAux ', '\n\nlemma models_code '),
    ('Nat.ArithPart₁.bind', SUB + 'Foundation/Vorspiel/Arithmetic.lean',
     'lemma bind (', '\n\nlemma map ('),
    ('Nat.ArithPart₁.map', SUB + 'Foundation/Vorspiel/Arithmetic.lean',
     'lemma map (', '\n\nlemma comp₁ ('),
]

def active(text: str) -> int:
    return sum(bool(line.strip()) for line in strip_comments(text).splitlines())

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=pathlib.Path,
                        default=pathlib.Path(__file__).resolve().parents[1])
    parser.add_argument('--output', type=pathlib.Path)
    args = parser.parse_args()
    result = []
    for name, path, start, end in DECLARATIONS:
        row = {'declaration': name, 'path': path}
        for label in ('baseline', 'overlay'):
            text = (args.package / label / path).read_text()
            begin = text.index(start)
            snippet = text[begin:text.index(end, begin)]
            body = snippet.split(':=', 1)[1]
            tactic_body = body.strip()
            if tactic_body.startswith('by\n'):
                tactic_body = tactic_body[3:]
            row[label] = {
                'active_declaration_lines': active(snippet),
                'declaration_bytes': len(snippet.encode()),
                'active_body_lines_including_by': active(body),
                'active_body_lines_excluding_standalone_by': active(tactic_body),
                'body_bytes': len(body.encode()),
            }
        result.append(row)
    output = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.output:
        args.output.write_text(output)
    else:
        print(output, end='')

if __name__ == '__main__':
    main()
