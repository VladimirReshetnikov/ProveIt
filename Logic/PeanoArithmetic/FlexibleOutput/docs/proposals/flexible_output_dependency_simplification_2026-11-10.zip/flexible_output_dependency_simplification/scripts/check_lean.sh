#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
repo_dir="${1:?Usage: check_lean.sh /absolute/path/to/ProveIt}"
cd "$repo_dir"
export LAKE_JOBS="${LAKE_JOBS:-1}"
export LEAN_NUM_THREADS="${LEAN_NUM_THREADS:-2}"
lake build PAFlexibleOutput
lake env lean "$package_dir/verification/Audit.lean"
