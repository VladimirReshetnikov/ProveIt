#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$package_dir"
pdflatex -interaction=nonstopmode -halt-on-error flexible_output_dependency_simplification.tex
pdflatex -interaction=nonstopmode -halt-on-error flexible_output_dependency_simplification.tex
