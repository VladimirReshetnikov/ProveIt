#!/usr/bin/env python3
"""Apply the reviewed ProveIt and Foundation patches to the pinned checkouts.

Both patches are checked before either source tree is changed. This script does
not create commits, change submodule pointers, push, or contact a remote.
"""
from __future__ import annotations
import argparse
import pathlib
import subprocess

PROVEIT_REV = '6b28681d36720d17c4a539b65717c93d57ee106a'
FOUNDATION_REV = '32e1a0956a8622fad067328ca1959729a7634428'

def git(repo: pathlib.Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', type=pathlib.Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    repo = args.repo.resolve()
    foundation = repo / 'lib/FormalizedFormalLogic-Foundation'
    package = pathlib.Path(__file__).resolve().parents[1]
    actions = [
        (repo, PROVEIT_REV, package / 'patches/proveit.patch'),
        (foundation, FOUNDATION_REV, package / 'patches/foundation.patch'),
    ]
    for directory, revision, patch in actions:
        actual = git(directory, 'rev-parse', 'HEAD')
        if actual != revision:
            parser.error(f'{directory}: expected revision {revision}; found {actual}')
        subprocess.run(['git', '-C', str(directory), 'apply', '--check', str(patch)],
                       check=True)
    if args.check_only:
        print('Both patches apply to the expected revisions.')
        return
    for directory, _, patch in actions:
        subprocess.run(['git', '-C', str(directory), 'apply', str(patch)], check=True)
    print('Applied both source patches. Run lake build PAFlexibleOutput, then the audit.')

if __name__ == '__main__':
    main()
