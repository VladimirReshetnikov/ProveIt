import PAFlexibleOutput.Main
import Lean.Util.FoldConsts

/-!
Exact interface and transitive proof-dependency checks for the paired-projection
proposal. Run this same file before and after applying the patches.
-/

set_option autoImplicit false

namespace PAFlexibleOutput.DependencyAudit

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ (x : ℕ) (o : Option ℕ),
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e x o := flexibleOutput

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ x n : ℕ, Satisfiable (insert (haltSentence e x n) 𝗣𝗔) :=
  flexibleOutput_satisfiable

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧
      ∀ o : Option ℕ,
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔),
        ValueIn M e 0 o := exists_partrec_flexibleOutput

example (c : Code) (x y : ℕ) :
    ℕ↓[ℒₒᵣ] ⊧ haltSentence c x y ↔ y ∈ Nat.Partrec.Code.eval c x :=
  standardCorrectness c x y

example : Hierarchy 𝚺 1 universalGraph := universalGraph_sigma_one

example {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]
    {program input y z : M}
    (hy : M ⊧/![y, program, input] universalGraph)
    (hz : M ⊧/![z, program, input] universalGraph) : y = z :=
  universalGraph_uniq hy hz

example {f : ℕ →. ℕ} (hf : Nat.Partrec f)
    (unif : ∀ {m n₁ n₂ a₁ a₂ : ℕ},
      a₁ ∈ f (m.pair n₁) → a₂ ∈ f (m.pair n₂) → a₁ = a₂) :
    ∃ g : ℕ →. ℕ, Nat.Partrec g ∧
      ∀ a m, a ∈ g m ↔ ∃ z, a ∈ f (m.pair z) :=
  Nat.Partrec.projection hf unif

end PAFlexibleOutput.DependencyAudit

open Lean in
run_cmd do
  let env ← getEnv
  let mut pending := [``PAFlexibleOutput.flexibleOutput]
  let mut seen : NameSet := {}
  let mut count : Nat := 0
  let mut representationBodySeen := false
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    if !seen.contains name then
      seen := seen.insert name
      count := count + 1
      let some info := env.find? name
        | throwError "Cannot inspect reachable constant {name}"
      if name.toString.endsWith ".models_codeAux" then
        representationBodySeen := true
        let some value := info.value? (allowOpaque := true)
          | throwError "Cannot inspect private representation proof"
        logInfo m!"PASS: actual private representation dependency {name}"
        logInfo m!"Expression nodes without sharing, models_codeAux: {value.sizeWithoutSharing}"
      for dep in info.getUsedConstantsAsSet do
        pending := dep :: pending
  logInfo m!"Reachable constants, including types and opaque bodies: {count}"
  unless representationBodySeen do
    throwError "Expected private models_codeAux dependency missing"
  for name in #[``Nat.Partrec.projection, ``Partrec.projection,
      ``REPred.projection, ``LO.FirstOrder.Arithmetic.sigma1_re,
      ``Nat.ArithPart₁.bind, ``Nat.ArithPart₁.map] do
    unless seen.contains name do
      throwError "Expected actual theorem dependency missing: {name}"
    logInfo m!"PASS: actual theorem dependency {name}"
  if seen.contains ``sorryAx then
    throwError "Reachable sorryAx"
  logInfo "PASS: no reachable sorryAx"
  for name in #[``Nat.Partrec.projection, ``Partrec.projection,
      ``REPred.projection, ``LO.FirstOrder.Arithmetic.models_code,
      ``Nat.ArithPart₁.bind, ``Nat.ArithPart₁.map,
      ``PAFlexibleOutput.flexibleOutput] do
    let some info := env.find? name | throwError "Cannot inspect {name}"
    let some value := info.value? (allowOpaque := true)
      | throwError "No inspectable body: {name}"
    logInfo m!"Expression nodes without sharing, {name}: {value.sizeWithoutSharing}"
  for name in env.allImportedModuleNames do
    if name.toString.startsWith "Foundation." ||
        name.toString.startsWith "PAFlexibleOutput." then
      logInfo m!"Imported local module: {name}"

#print axioms Nat.Partrec.projection
#print axioms Nat.ArithPart₁.bind
#print axioms Nat.ArithPart₁.map
#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.universalGraph_uniq
#print axioms PAFlexibleOutput.universalGraph_sigma_one
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
