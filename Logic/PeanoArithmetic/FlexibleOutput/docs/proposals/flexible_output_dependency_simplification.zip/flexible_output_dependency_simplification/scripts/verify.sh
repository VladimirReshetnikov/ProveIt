#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
repo_dir="$(cd -- "${1:?Pass the ProveIt checkout directory}" && pwd)"
result_dir="${2:-$package_dir/verification_results}"
mkdir -p "$result_dir"
result_dir="$(cd -- "$result_dir" && pwd)"
cd "$repo_dir"
lake build +PAFlexibleOutput > "$result_dir/build.log" 2>&1
lake env lean --root="$package_dir" "$package_dir/verification/ExactStatements.lean" > "$result_dir/exact_statements.log" 2>&1
lake env lean --root="$package_dir" "$package_dir/verification/ProjectionAudit.lean" > "$result_dir/projection_types.log" 2>&1
export FLEXIBLE_OUTPUT_AUDIT_FILE="$result_dir/declarations.tsv"
lake env lean --root="$package_dir" "$package_dir/verification/DependencyAudit.lean" > "$result_dir/dependencies.log" 2>&1
python3 "$package_dir/scripts/dependency_inventory.py" "$repo_dir" --output "$result_dir/imports.json"
printf 'Verification completed. Logs: %s\n' "$result_dir"
