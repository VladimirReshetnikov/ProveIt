#!/usr/bin/env python3
"""Apply this proposal after checking every original file against the manifest.

Usage: python3 scripts/apply_overlay.py /path/to/ProveIt [--check]
The --check flag validates applicability without modifying files.
Already-patched files are accepted. Unrelated files are never changed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository', type=Path)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    package = Path(__file__).resolve().parent.parent
    manifest = json.loads((package/'source_manifest.json').read_text())
    repo = args.repository.resolve()
    changes = []
    for entry in manifest['changed_files']:
        relative = Path(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise SystemExit(f'Invalid manifest path: {relative}')
        source = package/'overlay'/relative
        target = repo/relative
        if digest(source) != entry['after_sha256']:
            raise SystemExit(f'Damaged archive source: {relative}')
        current = digest(target)
        if current == entry['after_sha256']:
            continue
        if current != entry['before_sha256']:
            raise SystemExit(f'Baseline mismatch; no files changed: {relative}')
        changes.append((source,target))
    if args.check:
        print(f'Applicability verified; {len(changes)} files would change.')
        return
    for source,target in changes:
        target.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=target.parent,delete=False) as tmp:
            tmp.write(source.read_bytes())
            temporary = Path(tmp.name)
        temporary.chmod(0o644)
        os.replace(temporary,target)
    print(f'Applied {len(changes)} source-file changes; run scripts/verify.sh next.')


if __name__ == '__main__':
    main()
