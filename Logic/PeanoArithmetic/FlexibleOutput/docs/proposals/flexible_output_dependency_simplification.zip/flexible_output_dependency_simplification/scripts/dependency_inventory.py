#!/usr/bin/env python3
"""Measure the repository-owned import closure, with Foundation shown separately.

External Mathlib, Lean, and Std imports are boundary nodes, not included in SLOC.
The optional overrides map replaces complete source-file contents for experiments.
"""
import argparse
import hashlib
import json
import re
import tomllib
from pathlib import Path


def uncomment(text):
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        ch = text[i]
        if depth:
            if pair == '/-':
                depth += 1
                out.extend('  ')
                i += 2
            elif pair == '-/':
                depth -= 1
                out.extend('  ')
                i += 2
            else:
                out.append('\n' if ch == '\n' else ' ')
                i += 1
        elif string:
            out.append(ch)
            if ch == '\\' and i + 1 < len(text):
                out.append(text[i+1])
                i += 2
                continue
            if ch == '"':
                string = False
            i += 1
        elif pair == '/-':
            depth = 1
            out.extend('  ')
            i += 2
        elif pair == '--':
            end = text.find('\n', i)
            if end < 0:
                end = len(text)
            out.extend(' ' * (end-i))
            i = end
        else:
            out.append(ch)
            string = ch == '"'
            i += 1
    return ''.join(out)


def inventory(repo, target, overrides=None):
    overrides = overrides or {}
    config = tomllib.loads((repo/'lakefile.toml').read_text())
    roots = [(lib['name'], repo/lib.get('srcDir', '.')) for lib in config['lean_lib']]
    roots.sort(key=lambda item: len(item[0]), reverse=True)
    modules, external = {}, set()

    def visit(module):
        if module in modules or module in external:
            return
        path = next((base/(module.replace('.', '/')+'.lean')
                     for name, base in roots
                     if module == name or module.startswith(name+'.')), None)
        if path is None or not path.is_file():
            external.add(module)
            return
        relative = str(path.relative_to(repo))
        source = overrides.get(relative, path.read_text())
        clean = uncomment(source)
        imports = []
        for line in clean.splitlines():
            match = re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(?:all\s+)?(.+?)\s*$', line)
            if match:
                imports.extend(match.group(1).split())
        modules[module] = {
            'path': relative,
            'group': 'foundation' if relative.startswith('lib/FormalizedFormalLogic-Foundation/') else 'project',
            'lines': len(source.splitlines()),
            'nonblank_lines': sum(bool(line.strip()) for line in source.splitlines()),
            'code_lines': sum(bool(line.strip()) for line in clean.splitlines()),
            'bytes': len(source.encode()),
            'sha256': hashlib.sha256(source.encode()).hexdigest(),
            'imports': imports,
        }
        for imported in imports:
            visit(imported)

    visit(target)
    summaries = {}
    for group in ['project', 'foundation', 'all']:
        rows = [row for row in modules.values() if group == 'all' or row['group'] == group]
        summaries[group] = {'modules': len(rows), **{field: sum(row[field] for row in rows)
            for field in ['lines', 'nonblank_lines', 'code_lines', 'bytes']}}
    return {'target': target, 'summary': summaries, 'modules': dict(sorted(modules.items())),
            'external_boundary': sorted(external)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('repo', type=Path)
    ap.add_argument('--target', default='PAFlexibleOutput.Main')
    ap.add_argument('--overrides', type=Path)
    ap.add_argument('--output', type=Path)
    args = ap.parse_args()
    result = inventory(args.repo, args.target,
        json.loads(args.overrides.read_text()) if args.overrides else None)
    if args.output:
        args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
    print(json.dumps(result['summary'], indent=2))


if __name__ == '__main__':
    main()
