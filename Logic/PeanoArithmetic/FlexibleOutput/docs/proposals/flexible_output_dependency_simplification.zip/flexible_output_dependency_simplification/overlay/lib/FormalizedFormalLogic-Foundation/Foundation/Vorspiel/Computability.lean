module

public import Mathlib.Computability.Halting
public import Foundation.Vorspiel.Part
public import Foundation.Vorspiel.PartrecSelector

@[expose]
public section

namespace Partrec

open Computable

/-- Unique-output projection from the shared selector, without a second search algorithm. -/
lemma projection {α β γ : Type*} [Primcodable α] [Primcodable β] [Primcodable γ]
    {f : α → β →. γ} (hf : Partrec₂ f)
    (unif : ∀ {a b₁ b₂ c₁ c₂}, c₁ ∈ f a b₁ → c₂ ∈ f a b₂ → c₁ = c₂) :
    ∃ g : α →. γ, Partrec g ∧ (∀ c a, c ∈ g a ↔ ∃ b, c ∈ f a b) := by
  let F : α → ℕ →. γ := fun a n =>
    (Encodable.decode (α := β) n : Part β).bind (f a)
  have hF : Partrec₂ F :=
    (Computable.ofOption (Computable.decode.comp .snd)).bind
      (hf.comp (fst.comp fst) snd)
  obtain ⟨s, hs, hsound, hfind⟩ := REPred.exists_selector hF.dom_re
  let g : α →. γ := fun a => (s a).bind (F a)
  have sound {a c} (h : c ∈ g a) : ∃ b, c ∈ f a b := by
    obtain ⟨n, -, hn⟩ := Part.mem_bind_iff.mp h
    obtain ⟨b, -, hb⟩ := Part.mem_bind_iff.mp hn
    exact ⟨b, hb⟩
  refine ⟨g, hs.bind hF, fun c a => ⟨sound, ?_⟩⟩
  rintro ⟨b, hb⟩
  have hFb : (F a (Encodable.encode b)).Dom := by
    simpa [F] using Part.dom_iff_mem.mpr ⟨c, hb⟩
  obtain ⟨n, hn⟩ := Part.dom_iff_mem.mp (hfind a (Encodable.encode b) hFb)
  obtain ⟨c', hc'⟩ := Part.dom_iff_mem.mp (hsound a n hn)
  have hg : c' ∈ g a := Part.mem_bind_iff.mpr ⟨n, hn, hc'⟩
  obtain ⟨b', hb'⟩ := sound hg
  exact unif hb' hb ▸ hg

end Partrec

namespace Nat.Partrec

/-- The natural-number instance of unique-output projection. -/
lemma projection {f : ℕ →. ℕ} (hf : Nat.Partrec f)
    (unif : ∀ {m n₁ n₂ a₁ a₂ : ℕ}, a₁ ∈ f (m.pair n₁) → a₂ ∈ f (m.pair n₂) → a₁ = a₂) :
    ∃ g : ℕ →. ℕ, Nat.Partrec g ∧ (∀ a m, a ∈ g m ↔ ∃ z, a ∈ f (m.pair z)) := by
  have hf₂ : Partrec₂ fun a b : ℕ => f (Nat.pair a b) :=
    (Partrec.nat_iff.mpr hf).comp Primrec₂.natPair.to_comp
  obtain ⟨g, hg, h⟩ := _root_.Partrec.projection hf₂ unif
  exact ⟨g, Partrec.nat_iff.mp hg, h⟩

end Nat.Partrec

namespace REPred

variable {α β : Type*} [Primcodable α] [Primcodable β] {p q : α → Prop}

@[simp]
protected lemma const (p : Prop) : REPred fun _ : α ↦ p := by
  by_cases h : p
  · simpa [h] using Partrec.some.dom_re
  · simpa [h] using (Partrec.none (α := α) (σ := α)).dom_re

lemma iff : REPred p ↔ ∃ f : α →. Unit, Partrec f ∧ p = fun x ↦ (f x).Dom :=
  ⟨fun h ↦ ⟨_, h, by ext x; simp [Part.assert]⟩, by rintro ⟨f, hf, rfl⟩; exact hf.dom_re⟩

lemma iff' : REPred p ↔ ∃ f : α →. Unit, Partrec f ∧ ∀ x, p x ↔ (f x).Dom :=
  ⟨fun h ↦ ⟨_, h, by intro x; simp [Part.assert]⟩, by rintro ⟨f, hf, H⟩; exact hf.dom_re.of_eq (by simp [H])⟩

lemma and (hp : REPred p) (hq : REPred q) : REPred fun x ↦ p x ∧ q x := by
  rcases REPred.iff.mp hp with ⟨f, hf, rfl⟩
  rcases REPred.iff.mp hq with ⟨g, hg, rfl⟩
  let h : α →. Unit := fun x ↦ (f x).bind fun _ ↦ (g x).map fun _ ↦ ()
  have : Partrec h := Partrec.bind hf <| Partrec.to₂ <| Partrec.map (hg.comp Computable.fst) (Computable.const ()).to₂
  exact REPred.iff.mpr ⟨_, this, by funext x; simp [h]⟩

lemma or (hp : REPred p) (hq : REPred q) : REPred fun x ↦ p x ∨ q x := by
  rcases REPred.iff.mp hp with ⟨f, hf, rfl⟩
  rcases REPred.iff.mp hq with ⟨g, hg, rfl⟩
  rcases hf.merge hg (by intro a x; simp) with ⟨k, hk, h⟩
  exact REPred.iff.mpr ⟨k, hk, by funext x; simp [Part.unit_dom_iff, h]⟩

lemma projection {p : α × β → Prop} (hp : REPred p) : REPred fun x ↦ ∃ y, p (x, y) := by
  rcases REPred.iff.mp hp with ⟨f, hf, rfl⟩
  have : Partrec₂ fun a b ↦ f (a, b) := hf.comp <| Computable.pair .fst .snd
  obtain ⟨g, hg, Hg⟩ := Partrec.projection this (by simp)
  exact REPred.iff.mpr ⟨g, hg, by funext x; simp [Part.unit_dom_iff, Hg]⟩

protected lemma comp {f : α → β} (hf : Computable f) {p : β → Prop} (hp : REPred p) : REPred fun x ↦ p (f x) := by
  rcases REPred.iff.mp hp with ⟨p, pp, rfl⟩
  exact REPred.iff'.mpr ⟨_, pp.comp hf, by intro x; simp⟩

end REPred

namespace ComputablePred

variable {α β : Type*} [Primcodable α] [Primcodable β] {p q : α → Prop}

@[simp] protected lemma const (p : Prop) : ComputablePred fun _ : α ↦ p :=
  computable_iff_re_compl_re'.mpr ⟨REPred.const _, REPred.const _⟩

lemma and : ComputablePred p → ComputablePred q → ComputablePred fun x ↦ p x ∧ q x := by
  simp_rw [computable_iff_re_compl_re']
  rintro ⟨hp, hnp⟩
  rintro ⟨hq, hnq⟩
  refine ⟨hp.and hq, (hnp.or hnq).of_eq <| by grind⟩

lemma or : ComputablePred p → ComputablePred q → ComputablePred fun x ↦ p x ∨ q x := by
  simp_rw [computable_iff_re_compl_re']
  rintro ⟨hp, hnp⟩
  rintro ⟨hq, hnq⟩
  refine ⟨hp.or hq, (hnp.and hnq).of_eq <| by grind⟩

end ComputablePred

end
