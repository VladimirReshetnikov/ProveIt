import Foundation.Vorspiel.PartrecSelector

/-!
# Selection from a recursively enumerable relation

The project uses the shared selector that also implements Foundation's
unique-output projection. The public theorem name and type are preserved.
-/

namespace PAFlexibleOutput

export REPred (exists_selector)

#print axioms exists_selector

end PAFlexibleOutput
