# Existing-proposal audit

Initial repository snapshot: `6b28681d36720d17c4a539b65717c93d57ee106a`.
Final novelty recheck: `5ad98b5a50c2c5c4193d56d509181334d65d69e8`.
The latter commit adds a fifth proposal archive and changes no Lean source.
All five files listed by the GitHub contents API at
`Logic/PeanoArithmetic/FlexibleOutput/docs/proposals` were extracted and their
reports, replacement sources, and patches inspected. This is an exclusion audit,
not a claim of worldwide novelty.

## Archive identity

| Audit name | Repository filename | Git blob SHA-1 |
|---|---|---|
| A | `flexible_output_simplification.zip` | `d0e31c634a5527fd52fa4a5e4876fc8e39256e00` |
| B | `flexible_output_simplification (2).zip` | `f2a92b9d61d4d7bca06856495cdbb80bd06ad254` |
| C | `flexible_output_simplification_2026-11-09.zip` | `0cd27b71ff62e91fa727b428ac3b1d109badffec` |
| D | `pa_flexible_output_simplification.zip` | `d8c32f329446c28b3795472010dbe171ce287974` |
| E | `flexible_output_simplification_7142f7f_verified.zip` | `2d48e947a1f603c90e8cc68e0745745392e985a8` |

A and C were recovered from existing workspace artifacts and matched their
repository Git blob hashes. B and D were retrieved from the GitHub connector
at the pinned commit with Base64 encoding and the returned blob identifiers.
E was recovered from an existing local artifact, matched its exact Git blob
hash, and was additionally fetched using GitHub's connector at the final
commit. Its report and every patch were checked in the final novelty review.

## Ideas already proposed: exclude from novelty claims

1. **Bypass the custom arithmetic bridge.** Archives A-D recommend, or
   include as an alternative, a concrete proof using the standard model of PA,
   `models_of_provable`, `standardCorrectness`, Kleene's `fixed_point₂`, and
   `Arithmetic.complete`. This removes `PAModel`, `paBridge`, and
   `exists_searchImplementation` from the endpoint's proof route.
2. **Use one contradiction expressed as absence of search output.** B and D
   explicitly reuse one `noOutput`/`noSearch` argument for both divergence and
   unrefutability; D also shortens the generic `MathlibAssembly` proof in this
   way. There is no novelty in rewriting the same argument against the new
   endpoint names.
3. **Search for a refutation of the exact value specification.** A and C use
   `forall y, G(y,c,x) iff y=n` as the searched formula. This obtains uniqueness
   directly from completeness and avoids the generic nonstandard functionality
   proof on the main path. Standard-model uniqueness is `Part.mem_unique`.
4. **Generalize refutation enumerability to an arbitrary fixed template.** A
   introduces `refutationsREFor`; C proves the analogous exact-value instance.
   Both explicitly explain that the formula template need not be Sigma-one,
   because the arithmetized *provability* predicate is Sigma-one.
5. **Make the selector unary or generic.** A gives a unary `Code ->. Nat`
   selector and adds the dummy input only at `fixed_point₂`. B and D raise a
   generic r.e.-relation selector as further work. D specifies soundness plus a
   domain equal to existential membership. This is already present in the
   current repository as `exists_selector`.
6. **Normalize functionality semantics once.** B and D replace repeated
   conversions in `codeAux_uniq` with whole-goal simplification, vector
   extensionality for composition, and a direct trichotomy argument for
   minimization. They also shorten `code_uniq`, eliminate a reflexive vector
   identity in `universalGraph_uniq`, and work directly with numerals in
   `valueIn_of_models`.
7. **Replace coordinate-by-coordinate numeral quotation proofs.** B and D
   use `Matrix.comp_vecCons'`, `Matrix.empty_eq`, and `natCast_nat` with
   `substNumerals_app_quote` instead of destructing the three `Fin 3` cases.
8. **Remove redundant search witnesses and coercions.** D shortens the
   `eval` domain equivalence, feeds `Nat.rfindOpt_spec` directly to
   `Option.map_eq_some_iff`, and passes the fair-search termination witness
   directly to `Nat.rfindOpt_dom`. The bounded dovetailing itself is retained.
9. **Move retained stronger/global results into compatibility/audit modules.**
   A and C preserve the stronger global functionality claim and old generic
   APIs separately. Source counts of the endpoint's import slice, as distinct
   from the whole repository, and proof-constant dependency traversals are
   already used in A.
10. **Upstream generic functionality.** B asks to upstream `code_uniq`; D
    asks to upstream `codeOfPartrec'_uniq` for models of PA-minus. Mere movement
    of the induction into Foundation is therefore already a proposal.
11. **Extract a relation-level diagonal theorem.** D's further-work section
    proposes the general theorem: for r.e. `R(c,y)` with
    `R(c,y) -> y notin eval c 0`, obtain a nowhere-defined `e` with
    `forall y, not R(e,y)`. B also proposes generalizing direct model-theoretic
    reasoning without custom syntax/model records.
12. **Benchmark elaboration and compiled term size.** B and D identify this
    as further research. Measuring it may be useful evidence, but is not a new
    conceptual simplification.
13. **Simplify partial-value domain bookkeeping.** E replaces output-witness
    unpacking/repacking with domain proofs and `Part.get_mem`, shortens the
    selector's semidecision-domain equivalence, and rewrites the final main
    contradiction with the fixed-point equality and `Part.dom_iff_mem`.
    E also applies `congrArg (neg ...)` to `substNumerals_app_quote`, then
    simplifies vectors, and repeats composition-case semantic normalization.
    Its historical section proposes proving unrefutability first in the old
    generic bridge proof, then deriving divergence. These are excluded too.

## Baseline snapshot comparison

The current proof differs substantially from the old packages' baseline.
It has five local implementation modules: `Halting`, `Functionality`,
`Refutations`, `Search`, and `Main`. Its main theorem is stronger than the old
input-zero statement: for every standard input `x` and every `Option Nat`
value it supplies a model. The direct PA standard-model proof is already
implemented, with `exists_selector refutationsRE` and `fixed_point₂` applied
to `(c,x)`. The main proof also establishes `eval e x = Part.none` for every
input. A proposed patch must preserve this full theorem type.

`Refutations.lean` still imports
`Foundation.FirstOrder.Incompleteness.First` and
`Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1`, and its actual
proof still follows arithmetized provability -> Sigma-one definability ->
recursive enumerability. `neg_subst_quote` still contains a three-coordinate
vector conversion, so shortening that conversion would repeat B/D.

## A distinct available direction

**Replace the internal provability/definability route by an external effective
enumeration of derivations.** None of the five reports, patches, or proposed
source files recommends or implements this dependency change.

All packages retain the original internal provability machinery. A's report
section "Why the new proof search is effective" expressly uses formal numeral
substitution, quotation, arithmetized provability, and Sigma-one-to-r.e.
conversion. C's section "No claim that all Sigma-one infrastructure
disappears" (report source lines 475-480) explicitly states that the
enumerability proof still uses Foundation's arithmetized proof predicate and
definability machinery. B/D modify quotation bookkeeping only.

The generic phrase "enumerate proofs" occurs in the old baseline comments
and informal exposition. That phrase is not itself novel. The distinct
proposal would be a concrete external proof-enumeration theorem and computable
syntax operations that *replace* the current internal-arithmetic chain, with
an audited net reduction counting all newly introduced code. Merely saying
"proofs are enumerable" without implementing or budgeting its prerequisites
does not establish a shorter Lean proof.

## Report locations

- A: `proposal_A/flexible_output_simplification/report/flexible_output_simplification.tex`.
- B: `proposal_B/flexible_output_simplification/flexible_output_simplification.tex`.
- C: `proposal_C/flexible_output_simplification/report.tex`.
- D: `proposal_D/pa_flexible_output_simplification/pa_flexible_output_simplification.tex`.
- E: `proposal_E/flexible_output_simplification_2026-11-09/report/flexible_output_simplification.tex`.

The patched-file lists in all archives are restricted to the old local
FlexibleOutput implementation. No supplied patch edits the transitive
Foundation arithmetic/provability dependency implementation.

## Final fifth-archive check against the implemented proposal

E's four patches touch only the current local `Search`, `Main`, `Refutations`,
and `Functionality` modules. Its report explicitly says the imports are
unchanged; its source confirms this. It retains `Incompleteness.First` and
`InductionSchemeDelta1` in `Refutations`, and invokes
`substNumerals_app_quote` in the shortened quotation lemma. It does not propose
any edit to Foundation or to `InductionSchemeDelta1`.

Accordingly, both implemented changes remain distinct after the final recheck:

- Share the existing r.e. selector with Foundation's unique-output projection,
  deleting the latter's second bespoke dovetailing algorithm and accounting
  for the shared module in the net reduction.
- Cut imports at `D1`, replace the genuinely used FixedPoint quotation helper
  with direct lower-level quotation, and provide the equality-subtheory
  composition explicitly. This removes the unnecessary incompleteness module
  closure without merely hiding a dependency behind a renamed local wrapper.

The fifth archive does not change the novelty assessment of the optional
single-induction representation idea or the padded-induction semantic
prototype either.
