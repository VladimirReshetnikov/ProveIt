import PAFlexibleOutput.Main
import Lean.Util.FoldConsts

open Lean in
run_cmd do
  let env ← getEnv
  let mut pending := [``PAFlexibleOutput.flexibleOutput]
  let mut seen : NameSet := {}
  let mut rows : Array String := #[]
  let mut missing : Array Name := #[]
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    if !seen.contains name then
      seen := seen.insert name
      if let some info := env.find? name then
        let mod := match env.getModuleIdxFor? name with
          | some idx => env.header.moduleNames.getD idx.toNat .anonymous
          | none => env.mainModule
        let kind := match info with
          | .axiomInfo _ => "axiom"
          | .thmInfo _ => "theorem"
          | .defnInfo _ => "definition"
          | .opaqueInfo _ => "opaque"
          | _ => "inductive/constructor/recursor"
        rows := rows.push s!"{mod}\t{name}\t{kind}"
        for dep in info.getUsedConstantsAsSet do
          pending := dep :: pending
      else
        missing := missing.push name
  if !missing.isEmpty then
    throwError "Uninspectable constants: {missing}"
  let forbiddenModules := #[
    "Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.D2",
    "Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.D3",
    "Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.EquationalTheory",
    "Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.PeanoMinus",
    "Foundation.FirstOrder.Bootstrapping.FixedPoint",
    "Foundation.FirstOrder.Incompleteness.Consistency",
    "Foundation.FirstOrder.Incompleteness.First",
    "Foundation.FirstOrder.Incompleteness.ProvabilityAbstraction.Basic",
    "Foundation.FirstOrder.Incompleteness.RosserProvability",
    "Foundation.FirstOrder.Incompleteness.Second",
    "Foundation.FirstOrder.Incompleteness.StandardProvability",
    "Foundation.FirstOrder.Incompleteness.WitnessComparison",
    "Foundation.Meta.ClProver"]
  for mod in env.header.moduleNames do
    if forbiddenModules.contains mod.toString then
      throwError "Unexpected import after dependency pruning: {mod}"
  for name in seen do
    if name.toString == "sorryAx" then
      throwError "Admitted proof detected"
    if name.toString == "Nat.Partrec.projection" then
      throwError "Legacy natural-number projection still used by main theorem"
  unless seen.contains ``REPred.exists_selector do
    throwError "Shared selector missing from main proof"
  logInfo "PASS: pruned modules absent; shared selector present; legacy projection absent."
  let content := "module\tdeclaration\tkind\n" ++ String.intercalate "\n" (rows.qsort (· < ·)).toList ++ "\n"
  let target := (← IO.getEnv "FLEXIBLE_OUTPUT_AUDIT_FILE").getD "flexible_output_dependencies.tsv"
  IO.FS.writeFile target content
  logInfo m!"Recorded full type-and-value dependency closure: {rows.size} constants."

#print axioms PAFlexibleOutput.flexibleOutput
