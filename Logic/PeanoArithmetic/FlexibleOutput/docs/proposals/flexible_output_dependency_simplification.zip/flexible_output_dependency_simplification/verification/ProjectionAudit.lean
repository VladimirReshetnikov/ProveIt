import Foundation.Vorspiel.Computability
import PAFlexibleOutput.Search

example {α β γ : Type*} [Primcodable α] [Primcodable β] [Primcodable γ]
    {f : α → β →. γ} (hf : Partrec₂ f)
    (unif : ∀ {a b₁ b₂ c₁ c₂}, c₁ ∈ f a b₁ → c₂ ∈ f a b₂ → c₁ = c₂) :
    ∃ g : α →. γ, Partrec g ∧ (∀ c a, c ∈ g a ↔ ∃ b, c ∈ f a b) :=
  Partrec.projection hf unif

example {f : ℕ →. ℕ} (hf : Nat.Partrec f)
    (unif : ∀ {m n₁ n₂ a₁ a₂ : ℕ}, a₁ ∈ f (m.pair n₁) → a₂ ∈ f (m.pair n₂) → a₁ = a₂) :
    ∃ g : ℕ →. ℕ, Nat.Partrec g ∧ (∀ a m, a ∈ g m ↔ ∃ z, a ∈ f (m.pair z)) :=
  Nat.Partrec.projection hf unif

example {α : Type*} [Primcodable α] {R : α × ℕ → Prop} (hR : REPred R) :
    ∃ f : α →. ℕ, Partrec f ∧ (∀ a, ∀ y ∈ f a, R (a, y)) ∧ ∀ a n, R (a, n) → (f a).Dom :=
  PAFlexibleOutput.exists_selector hR

#print axioms Partrec.projection
#print axioms Nat.Partrec.projection
#print axioms PAFlexibleOutput.exists_selector
