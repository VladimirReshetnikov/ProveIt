# FlexibleOutput dependency simplification

This is a compiled, five-file proposal for the current all-input FlexibleOutput
theorem. Read `report.pdf` for the argument, measurements, novelty comparison,
and integration limits. The complete LaTeX source is `report.tex`.

## Result

- One shared r.e. selector now supports both FlexibleOutput and Foundation's
  unique-output projection, eliminating a separately proved search algorithm.
- Refutations and induction-schema definability import the D1 interface without
  importing the incompleteness theorem chain. Direct quotation and an explicit
  equality-subtheory instance replace the two needed helpers.
- `Main.lean`, `Halting.lean`, and `Functionality.lean` are byte-for-byte unchanged.
- Complete in-repository import closure: 139 to 127 modules; 42,503 to 39,929
  physical lines; 30,959 to 28,953 active lines, including all new shared code.
- Shared search/projection component: 174 to 126 active lines.
- Full type-and-value proof closure: 16,960 to 16,938 constants. Import counts
  and actual proof dependency counts measure different things.
- All three endpoint theorems compile with exactly `propext`, `Classical.choice`,
  and `Quot.sound`.

The source baseline is ProveIt `5ad98b5a50c2c5c4193d56d509181334d65d69e8`,
Foundation `32e1a0956a8622fad067328ca1959729a7634428`, Mathlib
`81a5d257c8e410db227a6665ed08f64fea08e997`, Lean 4.32.0. The initial
ProveIt snapshot was `6b28681d36720d17c4a539b65717c93d57ee106a`; the only
intervening change added a fifth proposal archive. All five proposals were
audited and neither primary contribution occurs in them.

## Apply and verify

With the pinned checkout and initialized Foundation submodule:

```bash
python3 scripts/apply_overlay.py /path/to/ProveIt --check
python3 scripts/apply_overlay.py /path/to/ProveIt
bash scripts/verify.sh /path/to/ProveIt
```

The application script preflights all original source hashes, accepts already
patched files, and writes only the five listed paths. It never fetches, commits,
or pushes anything. The separate ordinary patches are relative to the ProveIt
root (`patches/proveit.patch`) and Foundation root (`patches/foundation.patch`).

Validation needs the ordinary pinned Lean/Lake environment and package cache;
compiled dependencies are not bundled. The final script run is recorded under
`evidence/reproduction/`. Source inventories and complete constant inventories
are under `evidence/`. The exact endpoint and projection signatures are checked
by the Lean files under `verification/`.

## Integration scope

The full FlexibleOutput closure and facade were rebuilt. Unrelated ProveIt
targets were not all rebuilt. Callers relying on `InductionSchemeDelta1` to
re-export unrelated incompleteness theorems may need explicit imports.
Foundation changes should be committed in the maintained Foundation source or
fork and the parent submodule pointer updated during normal integration.

The two checked experiments under `research/` are not imported by the production
patch and count toward none of its savings. Their incomplete integration work
is described in `research/STATUS.txt` and the report. External proof enumeration
is discussed only as future work; it has not replaced internal provability here.

## Rebuild the PDF

```bash
bash scripts/build_report.sh
```

All archive files other than the checksum list itself are covered by `SHA256SUMS`.
