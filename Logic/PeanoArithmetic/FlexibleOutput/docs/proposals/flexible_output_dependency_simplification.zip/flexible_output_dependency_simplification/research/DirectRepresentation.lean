import Foundation.FirstOrder.Arithmetic.PeanoMinus.Basic
import Foundation.Vorspiel.Arithmetic
import Foundation.Vorspiel.Part

/-!
# A direct proof-producing representation compiler (research alternative)

This is a checked alternative compiler kernel. It is not wired into the production
`universalGraph` and does not claim a reduction of that theorem's import closure.
The import `Foundation.Vorspiel.Arithmetic` still contains the legacy code datatype.

`exists_graph` performs one induction on `Nat.ArithPart₁ f` to produce a formula,
its Sigma-1 certificate, its standard semantics, and functionality in Type-0 PA-
models. It never reifies this witness into `Nat.ArithPart₁.Code`, uses `Code.eval`,
or invokes `exists_code`. `functional_lift` transfers the functionality invariant
through completeness and soundness, preserving arbitrary-universe model semantics.

Integrating it would require choosing the graph from a certified-formula subtype,
replacing the old compiler in Foundation's Representation module, and removing the
legacy code datatype. Its chosen formula would not be definitionally identical to
the old `Classical.epsilon` choice. At this point the extra interface/choice work
leaves only a small estimated source saving; this file is a complete experiment,
not the recommended source-preserving patch.
-/

namespace PAFlexibleOutput.DirectRepresentation
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open Nat.ArithPart₁
open Mathlib List.Vector

abbrev Graph (k : ℕ) := ArithmeticFormula (Fin (k + 1))

def composeGraph {k n : ℕ} (φ : Graph n) (ψ : Fin n → Graph k) : Graph k :=
  exsClosure ((Rew.bind (L := ℒₒᵣ) (ξ₁ := Fin (n + 1)) ![] (&0 :> (#·)) ▹ φ) ⋏
    Matrix.conj fun i ↦ Rew.bind (L := ℒₒᵣ) (ξ₁ := Fin (k + 1)) ![] (#i :> (&·.succ)) ▹ ψ i)

def minGraph {k : ℕ} (φ : Graph (k + 1)) : ArithmeticFormula (Fin (k + 1)) :=
  (Rew.bind (L := ℒₒᵣ) (ξ₁ := Fin (k + 1 + 1)) ![] (‘0’ :> &0 :> (&·.succ)) ▹ φ) ⋏
  (∀⁰[“z. z < &0”] ∃⁰ “z. z ≠ 0” ⋏
    (Rew.bind (L := ℒₒᵣ) (ξ₁ := Fin (k + 1 + 1)) ![] (#0 :> #1 :> (&·.succ)) ▹ φ))

@[simp] lemma eval_composeGraph {M : Type*} [ORingStructure M] {k n : ℕ}
    (φ : Graph n) (ψ : Fin n → Graph k) (v : Fin k → M) (y : M) :
    (composeGraph φ ψ).Evalf (y :> v) ↔
      ∃ w : Fin n → M, φ.Evalf (y :> w) ∧ ∀ i, (ψ i).Evalf (w i :> v) := by
  simp [composeGraph, Semiformula.eval_rew, Function.comp_def, Matrix.empty_eq,
    Matrix.comp_vecCons']

@[simp] lemma eval_minGraph {M : Type*} [ORingStructure M] {k : ℕ}
    (φ : Graph (k + 1)) (v : Fin k → M) (y : M) :
    (minGraph φ).Evalf (y :> v) ↔
      φ.Evalf (0 :> y :> v) ∧ ∀ x < y, ∃ z, z ≠ 0 ∧ φ.Evalf (z :> x :> v) := by
  simp [minGraph, Semiformula.eval_rew, Function.comp_def, Matrix.empty_eq,
    Matrix.comp_vecCons']

def Standard {k} (f : List.Vector ℕ k →. ℕ) (φ : Graph k) : Prop :=
  ∀ y v, φ.Evalf (y :> v) ↔ f (List.Vector.ofFn v) = Part.some y

def Functional {k} (φ : Graph k) : Prop :=
  ∀ (M : Type) [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻]
    (v : Fin k → M) (y z : M), φ.Evalf (y :> v) → φ.Evalf (z :> v) → y = z

def functionalSentence {k} (φ : Graph k) : ArithmeticSentence :=
  ∀⁰* ((Rew.bind (L := ℒₒᵣ) (ξ₁ := Fin (k + 1)) ![] (#0 :> (#·.succ.succ)) ▹ φ :
    ArithmeticSemisentence (k + 2)) 🡒
      (Rew.bind (L := ℒₒᵣ) (ξ₁ := Fin (k + 1)) ![] (#1 :> (#·.succ.succ)) ▹ φ) 🡒
      “#0 = #1”)

lemma models_functionalSentence {M : Type*} [ORingStructure M] {k} (φ : Graph k) :
    M↓[ℒₒᵣ] ⊧ functionalSentence φ ↔
      ∀ (v : Fin k → M) (y z : M), φ.Evalf (y :> v) → φ.Evalf (z :> v) → y = z := by
  simp [functionalSentence, models_iff, Semiformula.eval_rew,
    Matrix.forall_iff, Function.comp_def, Matrix.empty_eq, Matrix.comp_vecCons']
  exact ⟨fun h v y z => h y z v, fun h y z v => h v y z⟩

/-- Completeness makes the Type-0 invariant available uniformly in every universe. -/
lemma functional_lift {k} {φ : Graph k} (hφ : Functional φ) {M : Type*}
    [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻] (v : Fin k → M) (y z : M) :
    φ.Evalf (y :> v) → φ.Evalf (z :> v) → y = z := by
  have hp : 𝗣𝗔⁻ ⊢ functionalSentence φ := Arithmetic.complete.{0} 𝗣𝗔⁻ _ fun N _ _ =>
    (models_functionalSentence φ).2 (hφ N)
  exact (models_functionalSentence φ).1 (models_of_provable (M := M) inferInstance hp) v y z

/-- Compilation and correctness are established by one induction on the original witness. -/
theorem exists_graph {k} {f : List.Vector ℕ k →. ℕ} (hf : Nat.ArithPart₁ f) :
    ∃ φ : Graph k, Hierarchy 𝚺 1 φ ∧ Standard f φ ∧ Functional φ := by
  induction hf with
  | zero =>
    refine ⟨“&0 = 0”, by simp, ?_, ?_⟩
    · intro y v; simp [show (0 : Part ℕ) = Part.some 0 from rfl, eq_comm]
    · intro M _ _ v y z; simp; rintro rfl rfl; rfl
  | one =>
    refine ⟨“&0 = 1”, by simp, ?_, ?_⟩
    · intro y v; simp [show (1 : Part ℕ) = Part.some 1 from rfl, eq_comm]
    · intro M _ _ v y z; simp; rintro rfl rfl; rfl
  | add i j =>
    refine ⟨“&0 = &i.succ + &j.succ”, by simp, ?_, ?_⟩
    · intro y v; simp [eq_comm]
    · intro M _ _ v y z; simp; rintro rfl rfl; rfl
  | mul i j =>
    refine ⟨“&0 = &i.succ * &j.succ”, by simp, ?_, ?_⟩
    · intro y v; simp [eq_comm]
    · intro M _ _ v y z; simp; rintro rfl rfl; rfl
  | proj i =>
    refine ⟨“&0 = !!&i.succ”, by simp, ?_, ?_⟩
    · intro y v; simp [eq_comm]
    · intro M _ _ v y z; simp; rintro rfl rfl; rfl
  | equal i j =>
    refine ⟨“(&i.succ = &j.succ ∧ &0 = 1) ∨ (&i.succ ≠ &j.succ ∧ &0 = 0)”,
      by simp [Matrix.fun_eq_vec_two], ?_, ?_⟩
    · intro y v; by_cases h : v i = v j <;> simp [Nat.isEqNat, h, eq_comm]
    · intro M _ _ v y z
      by_cases h : v i = v j <;> simp [h] <;> rintro rfl rfl <;> rfl
  | lt i j =>
    refine ⟨“(&i.succ < &j.succ ∧ &0 = 1) ∨ (&i.succ ≮ &j.succ ∧ &0 = 0)”,
      by simp [Matrix.fun_eq_vec_two], ?_, ?_⟩
    · intro y v; by_cases h : v i < v j <;> simp [Nat.isLtNat, h, eq_comm]
    · intro M _ _ v y z
      by_cases h : v i < v j <;> simp [h, -not_lt] <;> rintro rfl rfl <;> rfl
  | @comp m n f g _ _ ihf ihg =>
    rcases ihf with ⟨φ, hφ, hsφ, huφ⟩
    choose ψ hψ hsψ huψ using ihg
    refine ⟨composeGraph φ ψ, ?_, ?_, ?_⟩
    · exact Hierarchy.exsClosure (by simp [hφ, hψ])
    · intro y v
      rw [eval_composeGraph]
      constructor
      · rintro ⟨w, hwφ, hwψ⟩
        have h1 := (hsφ y w).1 hwφ
        have h2 : ∀ i, g i (List.Vector.ofFn v) = Part.some (w i) :=
          fun i => (hsψ i _ _).1 (hwψ i)
        simp [h1, h2]
      · intro h
        obtain ⟨w, hw, hy⟩ : ∃ w : List.Vector ℕ n, (∀ i, w.get i ∈ g i (List.Vector.ofFn v)) ∧ y ∈ f w :=
          by simpa using Part.eq_some_iff.mp h
        exact ⟨w.get, (hsφ y w.get).2 (by simpa [Part.eq_some_iff] using hy),
          fun i => (hsψ i (w.get i) v).2 (by simpa [Part.eq_some_iff] using hw i)⟩
    · intro M _ _ v y z h1 h2
      obtain ⟨w1, hy, hw1⟩ := eval_composeGraph φ ψ v y |>.1 h1
      obtain ⟨w2, hz, hw2⟩ := eval_composeGraph φ ψ v z |>.1 h2
      obtain rfl : w1 = w2 := funext fun i => huψ i M v (w1 i) (w2 i) (hw1 i) (hw2 i)
      exact huφ M w1 y z hy hz
  | @rfind n f _ ih =>
    rcases ih with ⟨φ, hφ, hsφ, huφ⟩
    dsimp [Standard] at hsφ
    refine ⟨minGraph φ, ?_, ?_, ?_⟩
    · simp [minGraph, Matrix.fun_eq_vec_two]; simp [hφ]
    · intro y v
      simp only [eval_minGraph]
      suffices (f (y ::ᵥ List.Vector.ofFn v) = 0 ∧ ∀ x < y, 0 < f (x ::ᵥ List.Vector.ofFn v))
          ↔ (Nat.rfind fun n ↦ Part.some (decide (f (n ::ᵥ List.Vector.ofFn v) = 0))) = Part.some y by
        simpa [hsφ, List.Vector.ofFn_vecCons, pos_iff_ne_zero] using this
      constructor
      · rintro ⟨hy, h⟩
        simpa [Part.eq_some_iff] using ⟨by simpa using hy,
          by intro z hz; exact Nat.ne_zero_of_lt (h z hz)⟩
      · intro h; simpa [pos_iff_ne_zero] using Nat.mem_rfind.mp (Part.eq_some_iff.mp h)
    · intro M _ _ v y z hy hz
      have key : ∀ {a b : M}, (minGraph φ).Evalf (a :> v) →
          (minGraph φ).Evalf (b :> v) → ¬ a < b := by
        intro a b ha hb hab
        obtain ⟨w, hw, hwa⟩ := (eval_minGraph φ v b |>.1 hb).2 a hab
        exact hw (huφ M (a :> v) w 0 hwa (eval_minGraph φ v a |>.1 ha).1)
      exact le_antisymm (not_lt.1 (key hz hy)) (not_lt.1 (key hy hz))

#print axioms exists_graph
#print axioms functional_lift
end PAFlexibleOutput.DirectRepresentation
