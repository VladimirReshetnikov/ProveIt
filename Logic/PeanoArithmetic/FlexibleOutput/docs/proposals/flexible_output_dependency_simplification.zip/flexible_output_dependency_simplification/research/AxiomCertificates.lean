import Foundation.FirstOrder.Arithmetic.Schemata

/-!
# Semantic recovery of a padded induction axiom

This auxiliary theorem is the key to replacing exact recognition of PA's
minimal universal-closure syntax by a deductively equivalent, more liberal
axiom presentation. It does not yet construct that presentation's arithmetic
recognizer or its Delta-one instance.
-/

set_option autoImplicit false

namespace PAFlexibleOutput.AxiomCertificates

open LO LO.FirstOrder LO.FirstOrder.Arithmetic

variable {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔]

/-- A free-variable-free body is a valid induction axiom whenever substituting
fresh free variables for its bound parameters recovers an induction instance.
No minimality condition on the number of parameters is required. -/
theorem padded_induction_valid {m : ℕ}
    (β : ArithmeticSemiformula ℕ m) (γ : ArithmeticSemiformula ℕ 1)
    (hfree : β.freeVariables = ∅)
    (hbody : β ⇜ (fun i : Fin m => (&(i : ℕ) : SyntacticTerm ℒₒᵣ)) = succInd γ) :
    M↓[ℒₒᵣ] ⊧ (∀⁰* β).toEmpty (by simpa using hfree) := by
  apply models_iff.mpr
  apply (Semiformula.eval_toEmpty (f := fun _ : ℕ => (0 : M))
    (by simpa using hfree)).mp
  rw [Semiformula.eval_allClosure]
  intro v
  let f : ℕ → M := fun i => if hi : i < m then v ⟨i, hi⟩ else 0
  have hind : M↓[ℒₒᵣ] ⊧ (succInd γ).univCl :=
    Theory.models M 𝗣𝗔 (Set.mem_union_right _
      (mem_InductionScheme_of_mem (φ := γ) (C := Set.univ) (by trivial)))
  have h := (models_iff_proposition.mp hind) f
  rw [← hbody, Semiformula.eval_substs] at h
  have hf : (Semiterm.val (![] : Fin 0 → M) f ∘
      (fun i : Fin m => (&(i : ℕ) : SyntacticTerm ℒₒᵣ))) = v := by
    funext i
    simp [f, i.isLt]
  rw [hf] at h
  exact (Semiformula.eval_iff_of_funEqOn β
    (fun i hi => by simp [Semiformula.FVar?, hfree] at hi)).mp h

#print axioms padded_induction_valid

end PAFlexibleOutput.AxiomCertificates
