FLEXIBLEOUTPUT: SHARE INDUCTION-RECOGNIZER CORRECTNESS

Read report.pdf for the mathematical explanation, Lean changes, measurements,
validation results, and further research questions. Its source is report.tex.

RESULT AND SCOPE

This package shortens two actual dependencies of the FlexibleOutput theorem.
The three modified Foundation files contain 107 fewer physical source lines
and 105 fewer nonblank, noncomment lines after counting all added helpers.
The complete repository-local import closure retains the same 140 modules.
These are actual retained-source savings; no module is removed from the count.

1. Share the correctness proof for the two induction recognizers.

The existing unrestricted and Sigma-one induction recognizers perform the same
syntactic reconstruction, differing in the condition on the recovered formula
code. A private recognizer parameterized by P shares that reconstruction proof.
Specializing P to True gives unrestricted induction; specializing P to
Bootstrapping.IsSigma1 gives the original Sigma-one result using the existing
hierarchy equivalence.

The original arithmetic recognizers and their Delta-one witnessing formulas
remain unchanged. P is a metalevel condition carried through the correctness
proof; arbitrary P is not asserted to be arithmetically definable. The public
theorem statements and the PA/I-Sigma-one definability instances are preserved.

The patch also makes an existing free-variable lemma available for reuse and
replaces a minimum-free-variable argument by strong induction on its index.
Together these changes remove 83 physical lines from InductionSchemeDelta1.

2. Use the existing predicate API in sigma1_re.

The proof that Sigma-one definable predicates are recursively enumerable uses
the primitive-recursive predicate interface directly for atomic formulas.
Existing conjunction/disjunction closure facts apply without redundant
conversions. The bounded-universal successor step uses the standard finite
universal-quantifier identity, and the existential case composes the existing
vector and projection results directly. This preserves the theorem's exact
statement and removes 24 physical lines from Representation.lean.

The universal computation graph, value interpretation, standard divergence,
all-input conclusion, nonstandard-model functionality, and main mathematical
argument are preserved.

SEPARATE REPAIR OF THE PINNED UPSTREAM MODULE RENAME

At the pinned ProveIt revision, Refutations.lean was renamed byte-for-byte to
Provability.lean, while Main.lean and the facade still import Refutations.
The parent-repository patch updates those imports and the corresponding README
references. The theorem proof bodies are unchanged by this repair.

The source comparison applies this same repair on both sides. It contributes
none of the reported 107-line reduction. The Foundation patch is the proof
simplification; the ProveIt patch is the separate integration repair.

PINNED VERSIONS

ProveIt:
  ba2909149fc7187814cde87862f6118dceec6801
Foundation, at lib/FormalizedFormalLogic-Foundation:
  32e1a0956a8622fad067328ca1959729a7634428
Mathlib:
  81a5d257c8e410db227a6665ed08f64fea08e997
Lean:
  leanprover/lean4:v4.32.0

NOVELTY CHECK

All ten archives present in FlexibleOutput/docs/proposals at the later
novelty snapshot d35ff841a47ba9c750475e68cec6dcea591c902b were inspected and
their exact Git blob hashes verified. Relative to the implementation pin
above, that snapshot adds only three archives within the target and relevant
dependency/configuration paths; the Lean sources and package pins are unchanged.
The final shared exact-recognizer correctness proof and sigma1_re cleanup do
not occur in the ten archives' patches or research proposals.

Previously proposed direct soundness, exact-value search, selector/projection
sharing, quotation cleanup, incompleteness import pruning, arithmetic-compiler
membership/monad-law cleanup, witness-before-compilation search, and uniform
functionality automation are excluded from this package's contribution.
The completed padded-induction proposal changes the recognition problem;
this patch preserves the exact recognizers and shares their correctness
arguments. That proposal also reuses a different public free-variable theorem,
so theorem reuse in general is not claimed as new. The detailed ten-archive
inventory and comparison are in evidence/novelty_audit.md and
evidence/prior_proposals.json.

MEASUREMENTS

The facade comparison follows every import reachable from PAFlexibleOutput
that resolves to a repository lean_lib source. It includes the checked-out
Foundation submodule and counts every reached file once. Mathlib and other
external packages in .lake, together with Lean's installed core, are outside
this source denominator. All new helper declarations are included.

Original -> proposed, with the same upstream rename repair on both sides:
  Repository-local modules:          140 -> 140
  Physical source lines:         42,524 -> 42,417
  Nonblank, noncomment lines:     30,964 -> 30,859
  UTF-8 source bytes:          1,853,049 -> 1,846,553

Net reduction: 107 physical lines, 105 active lines, and 6,496 bytes. The
physical-line reduction is approximately 0.252 percent of the full local
closure. The same 107-line reduction applies to retained repository source.
For Main alone, excluding the unchanged 21-line facade, the comparison is
139 modules on both sides and 42,503 -> 42,396 physical lines.

The sigma1_re proof body has 65 -> 41 nonblank lines. Its stored Lean proof
value has 107,860 -> 58,900 Expr nodes without sharing; its type remains
179 nodes. The expression metric counts repeated subterms per occurrence
and does not unfold named constants, including generated private helpers.
It is a measurement of that declaration's stored value. The optional
declaration audit below examines the broader local named-declaration closure.
Runtime improvement is unmeasured.

The complete syntactic local declaration audit includes all new helpers,
private and opaque values, types, and recursor rules. It counts each named
local declaration once and stops at external declarations. The local name
count is 6,916 -> 6,918; summed value-expression nodes are
142,498,206 -> 142,417,170; type nodes are 2,429,988 -> 2,430,010; and
recursor-rule nodes remain 385,746. The combined sum is
145,313,940 -> 145,232,926, a reduction of 81,014 nodes (0.055751 percent).
This is a conservative metadata-closure measure, with repeated subterms counted
inside each expression. It is not full per-use unfolding, serialized proof
size, memory usage, or compilation time. Both audits completed with the
required private metadata and values available. The recorded external
constant boundary is 1,836 -> 1,831 names.

See evidence/metrics.json, the two closure inventories, and evidence/sigma1/
for the source and single-declaration records. The broader results are in
evidence/declaration_baseline/, evidence/declaration_proposed/, and
evidence/declaration_comparison.json.

REQUIREMENTS AND SETUP

Use Git, Python 3.11 or later, and Lean 4.32.0 with the committed package pins.
The Python scripts accept ordinary Windows, macOS, and Linux paths. Where a
script offers --lock, that optional feature uses POSIX fcntl; omit it on Windows.
Use python3 instead of python if that is the name of your Python 3 executable.

Extract this package outside a separate checkout. For example:

  git -c core.autocrlf=false clone --recursive https://github.com/VladimirReshetnikov/ProveIt.git ProveIt-flexible-output
  git -c core.autocrlf=false -C ProveIt-flexible-output checkout --detach ba2909149fc7187814cde87862f6118dceec6801
  git -c core.autocrlf=false -C ProveIt-flexible-output submodule update --init --recursive
  cd ProveIt-flexible-output
  lake exe cache get

Use the committed lake-manifest.json to restore the pinned external package
caches. The Git options keep LF checkout bytes consistent with the exact
preimage hashes checked below. Replace the absolute path placeholders in the
following examples with your package, checkout, compiler, and output paths.

APPLY

  python /absolute/path/to/package/scripts/apply.py --repo /absolute/path/to/ProveIt-flexible-output --check-only
  python /absolute/path/to/package/scripts/apply.py --repo /absolute/path/to/ProveIt-flexible-output

The script checks the exact ProveIt and Foundation HEAD revisions and every
edited original file's SHA-256 against original/foundation and original/proveit.
It runs git apply --check for both patches before applying either. It then
applies the Foundation proof patch and the ProveIt rename-repair patch in order.
Unrelated working-tree modifications are allowed. Modified target files require
a manual rebase rather than automatic overwriting.

The application does not commit, push, or advance the Foundation gitlink in
the parent repository. Foundation changes remain modifications inside its
checkout. Normal adoption into repository history requires recording those
changes in the maintained Foundation source or fork and recording the resulting
revision in ProveIt.

The delivered application script passed a positive test in genuine clean
pinned worktrees. Check-only left both trees clean; actual application produced
all six changed files byte-for-byte identical to the bundled snapshots and
integrated source. See evidence/application_test.json and application_test.log.

FULL VERIFICATION FROM AN EMPTY LOCAL OUTPUT TREE

  python /absolute/path/to/package/scripts/verify.py --repo /absolute/path/to/ProveIt-flexible-output --lean /path/to/Lean-4.32.0/bin/lean --output /absolute/path/to/flexible-output-verification

Pass lean.exe on Windows. The --lean argument can be omitted when the pinned
compiler is on PATH. The --output argument can also be omitted; the script
then creates a fresh temporary output directory automatically. With an explicit
output, its olean subdirectory must be empty. Choose a new directory to make
the complete run easy to inspect.

The verifier checks repository revisions and the compiler version, inventories
the complete local closure, and builds its 140 modules serially in dependency
order. Its LEAN_PATH uses the fresh local output tree and pinned external
package caches. Cached Foundation or FlexibleOutput objects from the checkout
are not reused. Mathlib/package oleans and Lean's installed core are reused.

The final audit commands elaborate EndpointAudit.lean, RecognizerAudit.lean,
and Sigma1Audit.lean. They check the exact headline theorem, both original
recognizer-correctness statements, PA/I-Sigma-one definability instances,
the exposed syntax lemma, axiom reports, and the sigma1_re expression metric.
The allowed endpoint/recognizer axiom names are propext, Classical.choice,
and Quot.sound. The saved logs also contain the sigma1_re axiom report.

The complete final run passed: all 140 local modules were compiled from the
empty local output tree, no cached local modules were used, and the endpoint,
recognizer, and sigma1 audit checks passed. Its definitive result is in:
  evidence/full_build/summary.json
Its module/audit logs are under:
  evidence/full_build/logs/

Read the summary status, compiled_local_modules, and cached_local_modules_used
fields for the definitive result. The script records per-command outcomes and
warnings. Existing Foundation linter diagnostics are retained in the logs;
successful checking is determined by process exit status and the audits.
The archived targeted tests and baseline tests are separate evidence, not a
substitute for the fresh full-closure result.

OPTIONAL: REPRODUCE THE SIGMA1 PROOF-VALUE COMPARISON

After verify.py completes, reuse its fresh dependency output:

  python /absolute/path/to/package/scripts/compare_sigma1.py --repo /absolute/path/to/ProveIt-flexible-output --compiled /absolute/path/to/flexible-output-verification/olean --lean /path/to/Lean-4.32.0/bin/lean --output /absolute/path/to/sigma1-comparison

Choose a new or empty output directory outside both the repository and the
compiled dependency tree. The script compiles the bundled original and proposed
Representation modules into separate fresh overlays, runs the same audit on
both, and saves metrics.json and compiler logs. Unchanged local dependencies
and pinned external caches are reused. The checkout and input compilation tree
are not modified. Package revisions are checked against the committed manifest.

OPTIONAL: AUDIT THE TRANSITIVE LOCAL DECLARATION DEPENDENCIES

  python /absolute/path/to/package/scripts/declaration_audit.py --repo /absolute/path/to/ProveIt-flexible-output --compiled /absolute/path/to/flexible-output-verification/olean --lean /path/to/Lean-4.32.0/bin/lean --output /absolute/path/to/declaration-audit --source-inventory /absolute/path/to/package/evidence/proposed_closure.json

Use a new or empty output directory. The generated Lean IO program loads full
private module data with Lean.importModules, supporting both Foundation's
module declarations and the legacy PAFlexibleOutput files. It does not execute
imported initializers/extensions. For a baseline compiled tree, use
--source-inventory /absolute/path/to/package/evidence/baseline_closure.json.
Omitting that option uses the current source inventory. Source inventories
supply ownership, provenance, and file labels; declaration bodies and counts
come exclusively from the selected --compiled tree.

Starting from PAFlexibleOutput.flexibleOutput, the audit follows local types
and full values, including private helpers and opaque/theorem values. It also
includes structure-projection names, constructors, mutual inductive siblings,
and recursor reduction-rule expressions. This is a conservative syntactic
metadata closure. External declarations form a recorded stopping boundary.

Each named declaration is counted once. Expr.sizeWithoutSharing is summed
separately for types, values, and recursor-rule expressions, with repeated
subterms counted per occurrence inside an expression. Named declarations are
not inlined once per caller. These counts measure expression payloads, not
runtime, serialized bytes, or a minimal logical proof slice.

The script requires all inventoried local modules' private data and reports
missing metadata, missing expected values, and local axiom-like declarations;
any such condition fails the audit. Successful output includes declarations.json,
audit.log, the generated DeclarationAudit.lean, and source_inventory.json.
The saved baseline and proposed results are in evidence/declaration_baseline/
and evidence/declaration_proposed/; evidence/declaration_comparison.json gives
the paired totals. This scope differs from the import graph and the single
sigma1_re value metric.

OPTIONAL: REPRODUCE SOURCE COUNTS AND REBUILD THE REPORT

  python /absolute/path/to/package/scripts/closure.py --repo /absolute/path/to/ProveIt-flexible-output --target PAFlexibleOutput --output /absolute/path/to/proposed-closure.json

Use --target PAFlexibleOutput.Main for the Main-only closure. To reproduce the
original comparison, run against a pinned checkout with only proveit.patch
applied and the original Foundation sources. Both sides must include the same
upstream module-name repair.

With pdflatex, pdftex, and kpsewhich installed:

  python /absolute/path/to/package/scripts/build_pdf.py

This rebuilds report.pdf from report.tex and saves TeX logs in evidence/pdf_build.

FILE MAP

  report.tex / report.pdf
    Complete mathematical and implementation report.

  patches/foundation.patch
    The three existing-file proof/helper changes listed below.

  patches/proveit.patch
    Separate repair to the two stale imports and related README references.

  lean/foundation/Foundation/FirstOrder/Basic/Syntax/Rew.lean
    Existing free-variable theorem made public for reuse; same proof.

  lean/foundation/Foundation/FirstOrder/Incompleteness/InductionSchemeDelta1.lean
    Shared exact-recognizer correctness and shorter free-variable arguments.

  lean/foundation/Foundation/FirstOrder/Arithmetic/R0/Representation.lean
    Shorter sigma1_re proof; everything outside that proof is unchanged.

  lean/proveit/Logic/PeanoArithmetic/FlexibleOutput/
    The repaired Main module, facade, and project README at repository paths.

  original/foundation/ and original/proveit/
    Exact preimage files for patch inspection and guarded application.

  scripts/
    apply.py, verify.py, closure.py, compare_sigma1.py, declaration_audit.py,
    build_pdf.py, and the three explicit Lean audit sources.

  evidence/metrics.json
  evidence/baseline_closure.json
  evidence/proposed_closure.json
    Complete source counts, hashes, and import inventories.

  evidence/novelty_audit.md
  evidence/prior_proposals.json
    Ten-archive inventory, exact hashes, exclusions, and final novelty review.

  evidence/latest_snapshot_check.json
    Scoped comparison of the implementation pin with the later ten-archive
    snapshot: three archive additions, unchanged target sources and pins.

  evidence/recognizer/
    Recognizer preservation checks, targeted compilation and audit logs.

  evidence/sigma1/
    Both targeted proof compilations, unchanged-type/source checks, and metrics.

  evidence/baseline_project/
    Recorded repaired-baseline project checks, with their precise scope.

  evidence/declaration_baseline/
  evidence/declaration_proposed/
  evidence/declaration_comparison.json
    Complete paired syntactic declaration closures, private-body checks,
    generated IO runners, pinned source inventories, and method/limits.

  evidence/full_build/
    Definitive final fresh-build result and detailed module/audit logs.

  evidence/application_test.json / evidence/application_test.log
    Positive nested-patch application test and six-file hash comparison.

  LICENSE-Foundation.txt
    License accompanying the included Foundation source excerpts/files.

Compiler binaries, external dependency caches, and compiled proof objects are
not bundled. The original and proposed source snapshots, patches, and checking
scripts are the reproducible deliverables.
