
import Lean
open Lean
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def localModules : Array Name := #[`Foundation.Vorspiel.Nat.Basic, `Foundation.Vorspiel.Fin.Basic, `Foundation.Vorspiel.Matrix, `Foundation.Vorspiel.List.Basic, `Foundation.Vorspiel.NotationClass, `Foundation.Logic.LogicSymbol, `Foundation.Logic.Semantics, `Foundation.Vorspiel.AdjunctiveSet, `Foundation.Logic.Entailment, `Foundation.Syntax.Predicate.Language, `Foundation.Vorspiel.String, `Foundation.Syntax.Predicate.Term, `Foundation.Syntax.Predicate.Quantifier, `Foundation.FirstOrder.Basic.Syntax.Formula, `Foundation.Vorspiel.Finset.Basic, `Foundation.Vorspiel.Function, `Foundation.Syntax.Predicate.Rew, `Foundation.FirstOrder.Basic.Syntax.Rew, `Foundation.Vorspiel.IsEmpty, `Foundation.Vorspiel.Empty, `Foundation.FirstOrder.Basic.Semantics.Semantics, `Foundation.FirstOrder.Basic.Semantics.Elementary, `Foundation.FirstOrder.Basic.Operator, `Foundation.Vorspiel.Fin.Matrix, `Foundation.FirstOrder.Basic.BinderNotation, `Foundation.FirstOrder.Basic.Model, `Foundation.Propositional.Entailment.Minimal.Basic, `Foundation.Propositional.Entailment.AxiomDNE, `Foundation.Propositional.Entailment.AxiomElimContra, `Foundation.Propositional.Entailment.AxiomLEM, `Foundation.Propositional.Entailment.AxiomEFQ, `Foundation.Propositional.Entailment.Int.Basic, `Foundation.Propositional.Entailment.KC, `Foundation.Propositional.Entailment.LC, `Foundation.Propositional.Entailment.AxiomPeirce, `Foundation.Propositional.Entailment.Cl.Basic, `Foundation.Logic.Calculus, `Foundation.FirstOrder.Basic.Calculus, `Foundation.FirstOrder.Basic.CutFree, `Foundation.FirstOrder.Basic.Calculus2, `Foundation.Vorspiel.Nat.Matrix, `Foundation.FirstOrder.Basic.Coding, `Foundation.FirstOrder.Basic.Soundness, `Foundation.Vorspiel.Quotient, `Foundation.Vorspiel.Finset.Card, `Foundation.FirstOrder.Basic.Eq, `Foundation.FirstOrder.Basic.Padding, `Foundation.FirstOrder.Basic.AesopInit, `Foundation.Vorspiel.Graph, `Foundation.FirstOrder.Basic.Definability, `Foundation.FirstOrder.Basic, `Foundation.FirstOrder.Intuitionistic.Formula, `Foundation.FirstOrder.Intuitionistic.Rew, `Foundation.FirstOrder.Intuitionistic.Deduction, `Foundation.Meta.Qq, `Foundation.Meta.Lit, `Foundation.Meta.TwoSided, `Foundation.Meta.IntProver, `Foundation.FirstOrder.NegationTranslation.GoedelGentzen, `Foundation.FirstOrder.Hauptsatz, `Foundation.Logic.ForcingRelation, `Foundation.FirstOrder.Completeness.CanonicalModel, `Foundation.FirstOrder.Completeness.CountableSublanguage, `Foundation.FirstOrder.Ultraproduct, `Foundation.Vorspiel.Order.Dense, `Foundation.FirstOrder.Completeness.CounterModel, `Foundation.FirstOrder.Completeness, `Foundation.FirstOrder.Order.Le, `Foundation.FirstOrder.Arithmetic.Basic.Misc, `Foundation.FirstOrder.Arithmetic.Basic.Monotone, `Foundation.FirstOrder.Arithmetic.Basic.Model, `Foundation.FirstOrder.Arithmetic.Basic.Hierarchy, `Foundation.FirstOrder.Arithmetic.Basic, `Foundation.FirstOrder.Arithmetic.R0.Basic, `Foundation.Vorspiel.Arithmetic, `Foundation.Vorspiel.Part, `Foundation.Vorspiel.Computability, `Foundation.FirstOrder.Arithmetic.R0.Representation, `PAFlexibleOutput.Halting, `Foundation.FirstOrder.Arithmetic.Q.Basic, `Foundation.FirstOrder.Arithmetic.PeanoMinus.Basic, `PAFlexibleOutput.Functionality, `Foundation.FirstOrder.Arithmetic.Definability.Hierarchy, `Foundation.FirstOrder.Arithmetic.Definability.Definable, `Foundation.FirstOrder.Arithmetic.Definability.BoundedDefinable, `Foundation.FirstOrder.Arithmetic.Definability.Absoluteness, `Foundation.FirstOrder.Arithmetic.Definability, `Foundation.Vorspiel.ExistsUnique, `Foundation.FirstOrder.Arithmetic.PeanoMinus.Functions, `Foundation.FirstOrder.Arithmetic.TA.Basic, `Foundation.FirstOrder.Arithmetic.Schemata, `Foundation.FirstOrder.Arithmetic.IOpen.Basic, `Foundation.FirstOrder.Arithmetic.Exponential.Pow2, `Foundation.FirstOrder.Arithmetic.Exponential.PPow2, `Foundation.FirstOrder.Arithmetic.Exponential.Exp, `Foundation.FirstOrder.Arithmetic.Exponential.Log, `Foundation.FirstOrder.Arithmetic.Exponential.Bit, `Foundation.FirstOrder.Arithmetic.Exponential, `Foundation.FirstOrder.Arithmetic.HFS.Basic, `Foundation.FirstOrder.Arithmetic.HFS.Seq, `Foundation.FirstOrder.Arithmetic.HFS.PRF, `Foundation.FirstOrder.Arithmetic.HFS.Fixpoint, `Foundation.FirstOrder.Arithmetic.HFS.Vec, `Foundation.FirstOrder.Arithmetic.HFS.Coding, `Foundation.FirstOrder.Arithmetic.HFS, `Foundation.FirstOrder.Bootstrapping.Syntax.Language, `Foundation.FirstOrder.Bootstrapping.Syntax.Term.Basic, `Foundation.FirstOrder.Bootstrapping.Syntax.Term.Functions, `Foundation.FirstOrder.Bootstrapping.Syntax.Term.Typed, `Foundation.FirstOrder.Bootstrapping.Syntax.Term.Coding, `Foundation.FirstOrder.Arithmetic.Induction, `Foundation.FirstOrder.Bootstrapping.Syntax.Formula.Basic, `Foundation.FirstOrder.Bootstrapping.Syntax.Formula.Functions, `Foundation.FirstOrder.Bootstrapping.Syntax.Formula.Iteration, `Foundation.FirstOrder.Bootstrapping.Syntax.Formula.Typed, `Foundation.FirstOrder.Bootstrapping.Syntax.Formula.Coding, `Foundation.FirstOrder.Bootstrapping.Syntax.Theory, `Foundation.FirstOrder.Bootstrapping.Syntax.Proof.Basic, `Foundation.FirstOrder.Bootstrapping.Syntax.Proof.Typed, `Foundation.FirstOrder.Bootstrapping.Syntax.Proof.Coding, `Foundation.FirstOrder.Bootstrapping.Syntax, `Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.D1, `Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.D2, `Foundation.Meta.ClProver, `Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.EquationalTheory, `Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.PeanoMinus, `Foundation.FirstOrder.Bootstrapping.DerivabilityCondition.D3, `Foundation.FirstOrder.Incompleteness.ProvabilityAbstraction.Basic, `Foundation.FirstOrder.Bootstrapping.FixedPoint, `Foundation.FirstOrder.Incompleteness.StandardProvability, `Foundation.FirstOrder.Incompleteness.First, `Foundation.FirstOrder.Incompleteness.Consistency, `Foundation.FirstOrder.Incompleteness.WitnessComparison, `Foundation.FirstOrder.Incompleteness.RosserProvability, `Foundation.FirstOrder.Incompleteness.Second, `Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1, `PAFlexibleOutput.Provability, `PAFlexibleOutput.Search, `PAFlexibleOutput.Main, `PAFlexibleOutput]

/-- Unlike getUsedConstants, retain the structure name in Expr.proj as well. -/
def expressionDependencies (e : Expr) : IO NameSet := do
  let names ← IO.mkRef ({} : NameSet)
  e.forEach fun node => do
    match node with
    | .const name _ | .proj name _ _ => names.modify (·.insert name)
    | _ => pure ()
  return ← names.get

def declarationKind : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient_primitive"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def main : IO Unit := do
  let leanExe := (← IO.getEnv "FLEXIBLE_OUTPUT_LEAN_EXECUTABLE").getD "lean"
  initSearchPath (← findSysroot leanExe)
  let imports := localModules.map fun m => ({module := m, importAll := true} : Import)
  -- Private import level loads full data for both module and legacy imports.
  -- No imported initializers/extensions are executed: we only inspect constants.
  let env ← importModules imports {} (level := .private) (loadExts := false)
  let env := env.setExporting false
  let owned := localModules.foldl (fun (s : NameSet) n => s.insert n) {}
  let mut unloaded : Array String := #[]
  for name in localModules do
    match env.getModuleIdx? name with
    | none => unloaded := unloaded.push name.toString
    | some idx =>
      let imp := env.header.modules[idx]!
      unless imp.importAll && imp.hasData do
        unloaded := unloaded.push name.toString
  let root := `PAFlexibleOutput.flexibleOutput
  let mut todo := #[root]
  let mut seen : NameSet := {}
  let mut boundary : NameSet := {}
  let mut missing : Array Json := #[]
  let mut missingValues : Array String := #[]
  let mut localAxioms : Array String := #[]
  let mut rows : Array Json := #[]
  let mut valueTotal := 0
  let mut typeTotal := 0
  let mut ruleTotal := 0
  let mut privateCount := 0
  while !todo.isEmpty do
    let name := todo.back!
    todo := todo.pop
    if seen.contains name then continue
    seen := seen.insert name
    let some modIdx := env.getModuleIdxFor? name
      | missing := missing.push <| Json.mkObj [("name", toJson name.toString),
          ("reason", toJson "No imported module ownership metadata")]; continue
    let some modInfo := env.header.modules[modIdx.toNat]?
      | missing := missing.push <| Json.mkObj [("name", toJson name.toString),
          ("reason", toJson "Invalid imported module index")]; continue
    let modName := modInfo.module
    if !owned.contains modName then
      boundary := boundary.insert name
      continue
    let some ci := env.checked.get.find? name
      | missing := missing.push <| Json.mkObj [("name", toJson name.toString),
          ("reason", toJson "No full kernel ConstantInfo")]; continue
    let value := ci.value? (allowOpaque := true)
    let expectsValue := match ci with
      | .defnInfo _ | .thmInfo _ | .opaqueInfo _ => true
      | _ => false
    if expectsValue && value.isNone then
      missingValues := missingValues.push name.toString
    if ci matches .axiomInfo _ then
      -- A local axiom could also indicate a hidden body. Never silently count
      -- it as a zero-sized proof: this task expects no repository-local axioms.
      localAxioms := localAxioms.push name.toString
    let valueNodes := value.map Expr.sizeWithoutSharing |>.getD 0
    let typeNodes := ci.type.sizeWithoutSharing
    valueTotal := valueTotal + valueNodes
    typeTotal := typeTotal + typeNodes
    let mut deps ← expressionDependencies ci.type
    if let some v := value then
      deps := deps ++ (← expressionDependencies v)
    let mut ruleNodes := 0
    match ci with
    | .inductInfo iv =>
      for n in iv.all ++ iv.ctors do deps := deps.insert n
    | .ctorInfo cv => deps := deps.insert cv.induct
    | .recInfo rv =>
      for n in rv.all do deps := deps.insert n
      for rule in rv.rules do
        deps := deps.insert rule.ctor
        deps := deps ++ (← expressionDependencies rule.rhs)
        ruleNodes := ruleNodes + rule.rhs.sizeWithoutSharing
    | _ => pure ()
    ruleTotal := ruleTotal + ruleNodes
    let isPrivate := name.toString.startsWith "_private."
    if isPrivate then privateCount := privateCount + 1
    let sortedDeps := deps.toArray.qsort Name.lt
    todo := todo ++ sortedDeps
    rows := rows.push <| Json.mkObj [
      ("name", toJson name.toString), ("module", toJson modName.toString),
      ("kind", toJson (declarationKind ci)), ("private_name", toJson isPrivate),
      ("has_value", toJson value.isSome), ("expects_value", toJson expectsValue),
      ("value_expr_nodes_without_sharing", toJson valueNodes),
      ("type_expr_nodes_without_sharing", toJson typeNodes),
      ("recursor_rule_expr_nodes_without_sharing", toJson ruleNodes),
      ("dependencies", toJson (sortedDeps.map Name.toString))]
  let complete := missing.isEmpty && missingValues.isEmpty && localAxioms.isEmpty && unloaded.isEmpty
  let report := Json.mkObj [
    ("root", toJson root.toString),
    ("method", toJson "Repository-owned syntactic declaration closure; types, full values, structure projections, constructors, mutual inductive siblings, and recursor reduction rules; stop at external declarations"),
    ("import_level", toJson "private"),
    ("all_local_module_private_data_loaded", toJson unloaded.isEmpty),
    ("local_module_count", toJson localModules.size),
    ("complete", toJson complete),
    ("local_declaration_count", toJson rows.size),
    ("local_private_declaration_count", toJson privateCount),
    ("local_value_expr_nodes_without_sharing", toJson valueTotal),
    ("local_type_expr_nodes_without_sharing", toJson typeTotal),
    ("local_recursor_rule_expr_nodes_without_sharing", toJson ruleTotal),
    ("local_total_expr_nodes_without_sharing", toJson (valueTotal + typeTotal + ruleTotal)),
    ("external_constant_count", toJson boundary.toArray.size),
    ("external_constants", toJson ((boundary.toArray.qsort Name.lt).map Name.toString)),
    ("missing_constant_lookups", toJson missing),
    ("missing_expected_values", toJson missingValues),
    ("local_axiom_like_declarations", toJson localAxioms),
    ("local_modules_without_private_data", toJson unloaded),
    ("declarations", Json.arr rows)]
  let some out ← IO.getEnv "FLEXIBLE_OUTPUT_DECLARATION_AUDIT"
    | throw <| IO.userError "Set FLEXIBLE_OUTPUT_DECLARATION_AUDIT"
  IO.FS.writeFile out report.compress
  unless complete do
    throw <| IO.userError s!"Incomplete audit: {missing.size} missing lookups, {missingValues.size} missing values, {localAxioms.size} local axiom-like declarations, {unloaded.size} incomplete private imports"
  IO.println s!"Audited {rows.size} local declarations, including {privateCount} private names; {valueTotal} value nodes."
