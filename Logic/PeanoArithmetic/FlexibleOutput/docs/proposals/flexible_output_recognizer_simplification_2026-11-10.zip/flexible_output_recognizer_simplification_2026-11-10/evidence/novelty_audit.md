# Current novelty audit: all ten FlexibleOutput proposal archives

## Result

The two final proof simplifications are absent from all ten current archives: sharing the correctness proof of the exact PA/I-Sigma-one induction recognizers, and shortening `Foundation.FirstOrder.Arithmetic.R0.Representation.sigma1_re`. In particular, none replaces its explicit Boolean-witness proofs for atomic formulas with the existing primitive-recursive predicate API, and none shortens its bounded-universal induction step using the standard `Nat.forall_lt_succ` equivalence and partial-value semantics.

A separate dependency proposal was added while this review was in progress. It already covers deleting Foundation's projection accumulator and cutting the incompleteness import route. The earlier projection/import-cut candidate from this review was therefore withdrawn. It must not be presented as a new contribution or included in the new proposal's savings.

The last three archives add important exclusions: the `models_codeAux` membership proof and monad-law cleanup, a completed padded-induction theory, and witness-before-compilation search with a uniform functionality proof. These differ from the final proposal. Reusing an existing free-variable theorem is treated as a supporting implementation detail, not a generally novel idea: P9 already uses a different public free-variable theorem.

This audit establishes nonduplication relative to the ten pinned repository archives. It makes no claim that the underlying library facts or mathematical techniques are new in the literature.

## Current snapshot and exact archive inventory

Proposal-directory snapshot:
`d35ff841a47ba9c750475e68cec6dcea591c902b`.

Implementation and validation snapshot:
`ba2909149fc7187814cde87862f6118dceec6801`.
The later snapshot adds only P8–P10 within the target tree and relevant dependency/configuration paths; the Lean sources and pinned packages are identical in that scope.

Pinned directory:
[FlexibleOutput/docs/proposals](https://github.com/VladimirReshetnikov/ProveIt/tree/d35ff841a47ba9c750475e68cec6dcea591c902b/Logic/PeanoArithmetic/FlexibleOutput/docs/proposals).

All ten archives were extracted for inspection. Their reports, patches, and relevant replacement/research Lean files were read. Their Git blob hashes were checked against the repository tree. A Git blob SHA-1 hashes `blob <byte length>\0<file bytes>`; it is not the plain SHA-1 of the archive bytes. Local copies were accepted only after this content check. Remote revisions were fetched and genuine Git objects read without checking out those revisions or changing working sources. `evidence/prior_proposals.json` records byte lengths, SHA-256 hashes, verified Git blob hashes, and the scoped source comparison.

| Label | Exact archive filename | Verified Git blob SHA-1 |
| --- | --- | --- |
| P1 | `flexible_output_simplification (2).zip` | `f2a92b9d61d4d7bca06856495cdbb80bd06ad254` |
| P2 | `flexible_output_simplification.zip` | `d0e31c634a5527fd52fa4a5e4876fc8e39256e00` |
| P3 | `flexible_output_simplification_2026-11-09.zip` | `0cd27b71ff62e91fa727b428ac3b1d109badffec` |
| P4 | `pa_flexible_output_simplification.zip` | `d8c32f329446c28b3795472010dbe171ce287974` |
| P5 | `flexible_output_simplification (1).zip` | `5fb5c53ba81839ac3e23d08f9134963d705a23f9` |
| P6 | `flexible_output_simplification_7142f7f_verified.zip` | `2d48e947a1f603c90e8cc68e0745745392e985a8` |
| P7 | `flexible_output_dependency_simplification.zip` | `7730fde00de7ad0960cb7d5e331d7a2e6600bc1f` |
| P8 | `flexible_output_dependency_simplification_2026-11-10.zip` | `d52b993671c9c1a02e76c8f1d1e7a545be3f8ecf` |
| P9 | `flexible_output_padded_induction_2026-11-09.zip` | `98f2ad755b14218b819ce73061e202a3ce1ddea6` |
| P10 | `flexible_output_witness_search.zip` | `0dc1118d915ea3f257197f8663bf3a3e8df9583b` |

P1–P4 describe changes against `410c820c4faa7620a19ce07f55f43c13e5fbb688`. P5 and P6 use `7142f7f52bbd36ede33f2be1a66dfdccc238e255`. P7's final source baseline is `5ad98b5a50c2c5c4193d56d509181334d65d69e8`, after initially inspecting `6b28681d36720d17c4a539b65717c93d57ee106a`. Its report explains that the intervening change added an archive. P8 uses `6b28681d36720d17c4a539b65717c93d57ee106a`; P9 supplies patches for `5ad98b5a50c2c5c4193d56d509181334d65d69e8` and `52a9bb875b6e4026a79c8f53906d71602c11afee`; P10 uses `52a9bb875b6e4026a79c8f53906d71602c11afee`. All use the same Foundation source revision, `32e1a0956a8622fad067328ca1959729a7634428`.

## Archive-by-archive coverage

### P1: direct concrete proof and local cleanup

The report's main contribution is a direct standard-model soundness contradiction in the concrete PA proof, bypassing the custom model/bridge assembly. A common local no-output contradiction serves divergence and output-model existence. The optional local patch normalizes whole functionality goals, shortens adapters by definitional equality, keeps numerals through `valueIn_of_models`, and replaces coordinate-wise quotation calculations with vector identities.

Its patches edit only FlexibleOutput's `Main`, `Functionality`, and `Refutations`. Further questions include a reusable functionality theorem, a generic r.e. selector, generalization to other theories, and proof-term/performance measurements.

### P2: search for the complete output specification

This changes the searched sentence to `forall y, universalGraph(y,c,0) iff y=n`, derives standard correctness using `Part.mem_unique`, and obtains exact-value models directly from completeness. It generalizes refutation enumeration to any fixed formula, makes the internal search unary, and separates semantics/compatibility/audit modules.

Its patch is entirely within FlexibleOutput. It keeps the old nonstandard-functionality and abstract-assembly results available outside the shortest main import path.

### P3: exact-value search, with a direct-soundness alternative

This overlaps P2's stronger search target and generic fixed-template enumeration. It preserves the stronger global audit separately. An alternative patch retains the original search and only removes the concrete bridge using standard-model soundness.

Its patch edits FlexibleOutput's `Main`, `Refutations`, facade, and optional `FullAudit`. It does not modify the underlying formula-level `sigma1_re` theorem.

### P4: interface-preserving local changes and optional direct proof

The local patch shortens FlexibleOutput's functionality cases, generic assembly, dovetailing witnesses, and quotation proof. An optional patch uses the direct PA proof. Its further questions explicitly suggest a general selector and a relation-level diagonal interface.

Its modifications stay in FlexibleOutput's `Functionality`, `MathlibAssembly`, `Search`, `Refutations`, `Main`, and facade.

### P5: use the product encoding as an arity bridge

P5's principal new step is to encode the triple `((program,input),output)` as one natural number. Arithmetic pairing projections recover its arguments; `re_iff_sigma1.mpr` can then be applied directly to a unary predicate. This removes a local ternary/vector conversion and related helper declarations. It also simplifies quoted substitution with congruence, functionality normalization, and option/domain witness handling.

Its patch edits only FlexibleOutput's `Functionality`, `Refutations`, and `Search`. Although it changes how the application invokes the Sigma-one-to-r.e. interface, it does not change the proof of `sigma1_re` itself. Its further-work suggestions concern selectors and functionality, not the proposed atom or bounded-quantifier branch simplifications.

### P6: further partial-value and quotation cleanup at the newer baseline

P6 independently shortens four FlexibleOutput modules. It simplifies the selector's domain characterization and uses membership/domain facts directly; it simplifies Main's final contradiction at the domain level; it proves the quotation identity by congruence; and it normalizes the functionality composition case once.

The exact production footprint is `Search`, `Main`, `Refutations`, and `Functionality`. The arithmetic hierarchy induction and its atomic/bounded-universal cases remain untouched.

### P7: shared selector, projection elimination, and the import cut

This proposal materially changed the novelty boundary during the first refresh.

Its implemented changes:

1. Move the existing r.e. selector into new `Foundation.Vorspiel.PartrecSelector`, retaining the local selector name as an exported alias.
2. Derive general `Partrec.projection` from that selector and a decode/bind construction. The output-uniformity premise identifies whichever value was selected with the requested value.
3. Make `Nat.Partrec.projection` a short specialization of the generic theorem. This deletes the old nested bounded scan, membership induction, monotonicity proof, and the separate generic encoding-transport proof.
4. Replace broad incompleteness imports with D1 in `Refutations` and `InductionSchemeDelta1`.
5. Replace the quotation helper inherited through `Bootstrapping.FixedPoint` by a direct syntax proof; add a private equality-subtheory instance for PA.

Its production footprint is exactly:

- `Foundation/Vorspiel/Computability.lean`;
- new `Foundation/Vorspiel/PartrecSelector.lean`;
- imports in `Foundation/FirstOrder/Incompleteness/InductionSchemeDelta1.lean`;
- FlexibleOutput's `Refutations.lean` and `Search.lean`.

It does not edit `Foundation/FirstOrder/Arithmetic/R0/Representation.lean`. The report mentions `sigma1_re` to establish that projection is an actual dependency of refutation enumeration; it does not simplify that theorem's induction.

Its research artifacts and further directions also matter for novelty:

- `DirectRepresentation.lean` constructs an arithmetic graph with hierarchy, standard-semantics, and model-functionality certificates directly by induction on `Nat.ArithPart1`. It is an unintegrated alternative to the intermediate graph compiler, not a rewrite of the formula-level theorem that Sigma-one definable predicates are r.e.
- `AxiomCertificates.lean` validates induction bodies with redundant bound parameters. A new axiom recognizer and deductive-equivalence proof remain unimplemented.
- External enumeration of derivation certificates is discussed as future work; computable syntax adapters and the complete replacement remain unimplemented.

These are prior ideas and should not be represented as new proposals without a materially new completed advance.

### P8: uniform projection, membership correctness, and monad laws

P8 replaces `Nat.Partrec.projection`'s monotone finite-prefix construction by a paired search whose output is identified by the uniformity hypothesis. It also cuts the incompleteness imports and supplies the necessary local equality-subtheory instance. These overlap the withdrawn earlier candidate, and are excluded.

Its additional Foundation simplifications are concrete: `Nat.ArithPart₁.bind` and `.map` use monad laws; the private arithmetic compiler lemma `models_codeAux` begins by rewriting equality with `Part.some` to membership and keeps its induction in that form. Composition then uses the monadic-vector/bind interface, and minimization uses the existing `Nat.mem_rfind` specification. The patch changes `Foundation/FirstOrder/Arithmetic/R0/Representation.lean`, but its only proof-body change there is `models_codeAux`, not `sigma1_re`.

The complete Foundation footprint is `Vorspiel/Computability`, `Vorspiel/Arithmetic`, `Arithmetic/R0/Representation`, and the imports of `Incompleteness/InductionSchemeDelta1`. Its root patch edits `Refutations` and `Main`.

Its further questions propose a uniform-stage `Nat.rfindOpt` helper, isolating PA axiom definability from the extra restricted-induction recognizers, and more monad-law replacements in arithmetic compiler equalities. None proposes sharing the two exact recognizer-correctness proofs through a recovered-core side condition. Isolating PA from restricted induction is nevertheless recorded as an existing direction and is not part of the final proposal.

### P9: a completed padded-induction presentation

P9 completes a different axiom presentation in new project-local `PAFlexibleOutput.PaddedInduction`. Its recognizer permits redundant closing universal quantifiers, removing the exact `bv = closure depth` check. It proves that original PA axioms are included, the model classes agree including nonstandard models, and provability agrees. Refutation enumeration is transported across that equivalence. The original exact-membership recognizer development remains available for compatibility but leaves the principal import route.

The production patch adds the new theory and compatibility/audit modules and updates `Provability` (or `Refutations` at its older baseline). It does not modify the Foundation submodule. Its semantic equivalence and lighter recognition obligation are already proposed and implemented; they are not new here.

Two nearby details require precise wording. P9's `freeVariables_eq_empty_of_shift` still selects `Finset.min'`; it does not use the strong-induction replacement. Its `canonical_mem` reuses the public `Semiformula.fvarList_univCl'` theorem. Thus the general practice of avoiding a repeated free-variable proof is already exemplified. The final package's exposure and reuse of the specific existing `not_fvar?_fixitr_fvSup` lemma is a support change, not a broad novelty claim. P9 does not parameterize or factor the correctness proofs of the unchanged PA and I-Sigma-one recognizers.

### P10: return the search witness before compilation

P10 maps a successful semidecision result to its candidate witness before compiling the partial program. Bounded evaluation then returns the witness directly, eliminating the later `Option.map` layer. A separate optional change shares semantic normalization across all functionality constructor cases and finishes them with restricted `grind only` automation.

Its patches modify only project-local `Search` and `Functionality`, plus a separately credited module-rename repair. It modifies no Foundation source. The further questions concern selector proof-expression size, functionality elaboration cost, other witness-before-compilation sites, and more general output types. They do not concern `sigma1_re` or the exact induction recognizers.

## Consolidated exclusion list

| Already covered approach | Archives |
| --- | --- |
| Direct standard-model soundness replacing concrete bridge assembly | P1–P4 |
| A common no-search/no-output contradiction for divergence and models | P1, P4; related use in P2–P3 |
| Search for the complete singleton-output specification | P2–P3 |
| Refutation enumeration for arbitrary fixed formula templates | P2–P3 |
| Unary search interface and compatibility separation | P2; related module separation in P1/P3 |
| Whole-goal normalization and definitional-equality cleanup in functionality | P1, P4–P6; uniform restricted automation in P10 |
| Quotation by vector identities or congruence | P1, P4–P6 |
| Elimination of redundant option/domain witness plumbing | P2, P4–P6 |
| Unary product-encoding bridge to `re_iff_sigma1` | P5 |
| General reusable selector proposal | P1/P4/P5 research questions; implemented shared placement in P7 |
| Delete the projection accumulator, its induction, and monotonicity using selected-output uniformity | P7–P8 |
| Simplify the generic encode/decode projection lift through a shared selector | P7 |
| Cut D1/PA-definability's route through incompleteness, repairing quotation and equality instances | P7–P8 |
| Keep arithmetic compiler correctness in partial-value membership form | P8 (`models_codeAux`) |
| Use monad laws in arithmetic compiler bind/map proofs | P8 |
| Isolate PA axiom definability from restricted-induction recognition | P8 further question |
| Direct graph construction with semantic/functionality certificates | P7 research prototype |
| Padded induction certificates and more liberal axiom recognition | P7 research prototype/direction; completed effective theory and equivalence in P9 |
| External proof-certificate enumeration replacing internal provability | P7 future direction |
| Compile a semidecision procedure that already returns the candidate witness | P10 |

## Why the replacement target is distinct

The replacement target is the existing proof of
`LO.FirstOrder.Arithmetic.sigma1_re` in
`Foundation.FirstOrder.Arithmetic.R0.Representation`.

The candidate preserves the theorem and the hierarchy induction, and changes only how its already-known closure facts are expressed:

- For equality, disequality, less-than, and negated less-than, use the existing primitive-recursive predicate/computable predicate/RE predicate interfaces instead of explicitly defining a Boolean test and proving its correspondence from scratch.
- For the bounded-universal case, use the standard successor decomposition of a finite universal quantifier to shorten the semantic induction step, preserving the same bounded iteration.

No archive contains these specific changes in its production patch, replacement proposal, research files, report discussion, or further questions. Relevant `sigma1_re` occurrences are unchanged source, calls, or dependency explanations. P5's unary application adapter is not a replacement proof for the formula-level theorem. P7's compiler experiment operates in the opposite direction: constructing formulas from computations. P8 edits the same Representation file, but changes the separate reverse-direction compiler-correctness lemma `models_codeAux`. The final patch leaves that lemma unchanged.

The final Foundation patch's footprint was compared with these archived patches. This novelty audit does not establish successful elaboration, preservation of axiom dependencies, or numerical savings; those require the separate validation records.

### Shared correctness for the exact induction recognizers

The final patch also changes the proof bodies in `Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1`. It introduces a private metalevel recognizer parameterized by a condition `P` on the recovered one-variable formula code and proves its correctness once. The unrestricted recognizer is obtained with `P = True`; the Sigma-one recognizer uses `P = IsSigma1` and the already-existing equivalence between that code predicate and the formula hierarchy condition.

The public arithmetic recognizers, their concrete Delta-one witnessing formulas, and their theorem statements remain the same. The generic proof carries the hypothesis `P K` through quotation and formula recovery. It does not assume or assert that arbitrary predicates `P` are Delta-one definable, and does not add a new arithmetic axiom or computation oracle.

The patch also exposes the existing free-variable lemma `Semiformula.not_fvar?_fixitr_fvSup` for reuse instead of copying its proof, and proves absence of free variables in a shift-fixed formula by strong induction instead of selecting a minimum free variable.

None of P1–P6 or P10 edits this recognition development. P7 and P8 change only its imports. P7's optional padded-induction research and P9's completed implementation instead use a more liberal axiom presentation that changes the recognition problem. P8's isolation question would separate PA's dependency path from restricted induction. None shares the two existing exact correctness proofs through a side-condition parameter. The final package preserves the original recognizers and all their concrete definability witnesses, retains the module closure, and simplifies the common correctness argument. That is its distinct contribution.

### Final implemented footprint

The Foundation patch touches three existing files only:

- `Foundation/FirstOrder/Basic/Syntax/Rew.lean`: make the already-proved free-variable lemma public;
- `Foundation/FirstOrder/Incompleteness/InductionSchemeDelta1.lean`: share the two exact recognition proofs and reuse/simplify their free-variable arguments;
- `Foundation/FirstOrder/Arithmetic/R0/Representation.lean`: simplify the existing `sigma1_re` proof through its predicate and partial-value APIs.

The separate ProveIt patch fixes the stale module-name imports and README references. It is an integration repair, contributes no claimed proof saving, and is applied on both sides of the source comparison. The final proposal contains no projection rewrite, selector relocation, import cut, new PADefinability module, or changed arithmetic representation.

## Current-source changes discovered during the audit

Within the FlexibleOutput target tree, the Git diff from the initial snapshot `6b28681d36720d17c4a539b65717c93d57ee106a` to the implementation snapshot `ba2909149fc7187814cde87862f6118dceec6801` consists of:

- three added archives: P5, P6, and P7;
- a byte-identical rename of `PAFlexibleOutput/Refutations.lean` to `PAFlexibleOutput/Provability.lean`.

The Foundation gitlink remains `32e1a0956a8622fad067328ca1959729a7634428`; the target theorem's source is therefore unchanged by this update.

The subsequent comparison from `ba2909149fc7187814cde87862f6118dceec6801` to the novelty snapshot `d35ff841a47ba9c750475e68cec6dcea591c902b` contains only the three new archives P8–P10 within these reviewed paths: `Logic/PeanoArithmetic/FlexibleOutput`, `lib/FormalizedFormalLogic-Foundation`, `lakefile.lean`, `lakefile.toml`, `lake-manifest.json`, and `lean-toolchain`. The Foundation gitlink, target Lean sources, and package/toolchain configurations are unchanged. Other repository areas are outside this source-delta claim.

At the refreshed snapshot, both `PAFlexibleOutput/Main.lean` and the facade still import `PAFlexibleOutput.Refutations`. This is a separate dangling-module rename in the repository snapshot. Any correction needed to build that snapshot should be documented as an integration repair, separately from the mathematical proof simplification and its measurements. A successful build at the older complete snapshot must not be described as a build of the newer snapshot without that qualification.

## Method and limits

The audit reads the TeX reports, README/status explanations, patch footprints, and relevant replacement/research Lean sources. Exact archive-byte identity is verified; source names alone are not used as evidence. The latest repository tree and source diff were read from genuine Git objects. No root source checkout or existing modifications were overwritten during the refresh.

The scope is the ten archives in the pinned directory. It does not cover future additions, all unpublished conversations, or all prior literature. Previously archived validation claims are reported as claims of those packages rather than rerun by this audit.
