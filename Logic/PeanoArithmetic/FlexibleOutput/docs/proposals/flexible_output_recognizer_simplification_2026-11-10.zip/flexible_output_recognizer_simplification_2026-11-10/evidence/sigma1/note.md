# New contribution: use the predicate closure API in `sigma1_re`

## Exact scope

This patch changes only the proof body of
`LO.FirstOrder.Arithmetic.sigma1_re` in
`Foundation/FirstOrder/Arithmetic/R0/Representation.lean`. Its declaration
header and every byte outside that proof body are unchanged. No imports,
definitions, theorem statements, or new helper declarations are introduced.

The latest seven-archive proposal audit confirms that this source region and
the proposed atomic/bounded-universal rewrites are not covered by those
archives. In particular, the newly added dependency proposal already covers
projection and selector factoring, which this patch leaves unchanged.

## Why this is on the requested proof's path

`sigma1_re` proves that the standard-model satisfaction relation of any fixed
Sigma-one arithmetic formula is recursively enumerable. FlexibleOutput uses
this bridge in its refutation-enumerability argument. Consequently the change
shortens a theorem actually used in the main result's transitive proof
dependencies, without changing the arithmetic interpretation of the program.

## Proof changes

1. **Atomic predicates use existing computability certificates.** The old four
   cases manually construct Boolean characteristic functions and separately
   prove their agreement with equality, inequality, order, and negated order.
   `term_primrec` already supplies primitive-recursive term evaluators.
   Composing them with `Primrec.eq` or `Primrec.nat_lt` supplies a
   `PrimrecPred` certificate. Its `.computablePred.to_re` conversion discharges
   the positive cases directly; `.not.computablePred.to_re` discharges the
   negative cases. This removes redundant reconstruction of the witnesses
   already provided by the library API.

2. **The bounded-universal successor step uses its standard logical identity.**
   The existing program still sequentially runs the semidecision procedure for
   each number below the bound. Its domain invariant remains

       (all x < k satisfy phi) iff (the first k checks terminate).

   The successor case follows by unfolding the partial-function bind domain,
   applying the induction hypothesis and the semidecision specification, and
   using `Nat.forall_lt_succ_right`. One `simp` call performs these explicit
   rewrites. The program and invariant are unchanged; only their proof loses
   the manual introduction, witness splitting, order conversion, and two
   implications.

3. **Conjunction and disjunction use their definitionally matching closure
   theorems.** The intermediate `REPred.of_eq` wrappers are unnecessary.

4. **The existential case composes the vector-cons map and projection
   directly.** It does not unpack an unused semidecision witness or separately
   name the transported relation. This does not change either projection
   theorem and introduces no new selector.

## Source measurements

| Scope | Before | After |
| --- | ---: | ---: |
| Nonblank proof-body lines | 65 | 41 |
| Proof-body UTF-8 bytes | 3,150 | 1,682 |
| Full module physical lines | 265 | 241 |
| Full module UTF-8 bytes | 12,873 | 11,405 |

`source_metrics.json` records exact source hashes and the successful
byte-preservation checks for the theorem header and the remainder of the file.

## Elaboration and axiom checks

Both original and proposed full modules were freshly compiled in separate
overlays against the original unchanged Foundation dependency cache. Both
audits then imported the newly compiled module. All four Lean calls returned
exit code 0, with no warnings. `sigma1_re` reports exactly `propext`,
`Classical.choice`, and `Quot.sound` for both versions.

| Stored declaration measurement | Before | After |
| --- | ---: | ---: |
| Proof-value expression-tree nodes | 107,860 | 58,900 |
| Type expression-tree nodes | 179 | 179 |
| Distinct direct named constants | 227 | 165 |

The proof-value reduction is 48,960 expression-tree nodes, approximately
45.3922 percent. `Expr.sizeWithoutSharing` counts repeated shared subexpressions
per occurrence and does not unfold named constants, including generated
helpers. This local metric is not a claim about fully expanded dependency
proofs or execution time. The parent task's declaration-dependency audit
provides the broader helper-inclusive accounting.

## Artifacts

* `Foundation/FirstOrder/Arithmetic/R0/Representation.lean`: replacement source.
* `original/Foundation/FirstOrder/Arithmetic/R0/Representation.lean`: original.
* `representation.patch`: patch relative to the Foundation root.
* `Sigma1Audit.lean`: source of the expression and axiom audit.
* `source_metrics.json`, `term_size_metrics.json`, and `logs/`: evidence.

The final package's `scripts/compare_sigma1.py` is the portable comparison
runner. Its `--repo`, `--compiled`, `--output`, `--lean`, and optional POSIX
`--lock` arguments replace task-specific paths. It should be executed after
the new final package's fresh local build has supplied its unchanged imports.
