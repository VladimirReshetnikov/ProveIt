This directory records a successful execution of the bundled scripts/compare_sigma1.py.
Both bundled Representation.lean source versions were freshly compiled in distinct
output overlays, then inspected by the same scripts/Sigma1Audit.lean. All four
compiler invocations exited with code 0. The comparison reused unchanged local
Foundation prerequisites and pinned external package caches. Target-module
artifacts were freshly compiled and were not reused from those prerequisites.

metrics.json records exact source SHA-256 hashes, the compiler version, verified
package revisions, the complete list of reused local modules, and the precise
expression metric. runs.json records actual commands, exits, and warning counts.
logs/ preserves raw compilation and audit output. source_metrics.json separately
records source measurements and verifies that the theorem declaration header
and every byte outside sigma1_re's proof body are identical.

The measured stored proof values have 107,860 and 58,900 expression-tree nodes.
Named constants are not unfolded, and shared subterms count per occurrence.
This declaration-local metric is not a timing benchmark or a measurement of
fully unfolded proofs. The parent report's dependency audit addresses broader
reachable declarations. No compiled .olean artifacts or links are included here.
