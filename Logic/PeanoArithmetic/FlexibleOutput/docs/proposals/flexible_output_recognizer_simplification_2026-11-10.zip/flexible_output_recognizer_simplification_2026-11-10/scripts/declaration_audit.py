#!/usr/bin/env python3
"""Audit the repository-owned syntactic declaration closure of flexibleOutput.

Use Lean.importModules at private level, independent of mixed old/new module
headers, so theorem/opaque bodies and private proof helpers are available.
Each named declaration is counted once; expression trees inside its type, value,
and recursor rules are counted without sharing. Inductive blocks are closed over
constructors and mutual siblings. External declarations form a stopping boundary.
This is source-independent kernel-payload accounting, not a timing measurement.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
from closure import inventory

BODY = r'''
import Lean
open Lean
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def localModules : Array Name := __LOCAL_MODULES__

/-- Unlike getUsedConstants, retain the structure name in Expr.proj as well. -/
def expressionDependencies (e : Expr) : IO NameSet := do
  let names ← IO.mkRef ({} : NameSet)
  e.forEach fun node => do
    match node with
    | .const name _ | .proj name _ _ => names.modify (·.insert name)
    | _ => pure ()
  return ← names.get

def declarationKind : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient_primitive"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def main : IO Unit := do
  let leanExe := (← IO.getEnv "FLEXIBLE_OUTPUT_LEAN_EXECUTABLE").getD "lean"
  initSearchPath (← findSysroot leanExe)
  let imports := localModules.map fun m => ({module := m, importAll := true} : Import)
  -- Private import level loads full data for both module and legacy imports.
  -- No imported initializers/extensions are executed: we only inspect constants.
  let env ← importModules imports {} (level := .private) (loadExts := false)
  let env := env.setExporting false
  let owned := localModules.foldl (fun (s : NameSet) n => s.insert n) {}
  let mut unloaded : Array String := #[]
  for name in localModules do
    match env.getModuleIdx? name with
    | none => unloaded := unloaded.push name.toString
    | some idx =>
      let imp := env.header.modules[idx]!
      unless imp.importAll && imp.hasData do
        unloaded := unloaded.push name.toString
  let root := `PAFlexibleOutput.flexibleOutput
  let mut todo := #[root]
  let mut seen : NameSet := {}
  let mut boundary : NameSet := {}
  let mut missing : Array Json := #[]
  let mut missingValues : Array String := #[]
  let mut localAxioms : Array String := #[]
  let mut rows : Array Json := #[]
  let mut valueTotal := 0
  let mut typeTotal := 0
  let mut ruleTotal := 0
  let mut privateCount := 0
  while !todo.isEmpty do
    let name := todo.back!
    todo := todo.pop
    if seen.contains name then continue
    seen := seen.insert name
    let some modIdx := env.getModuleIdxFor? name
      | missing := missing.push <| Json.mkObj [("name", toJson name.toString),
          ("reason", toJson "No imported module ownership metadata")]; continue
    let some modInfo := env.header.modules[modIdx.toNat]?
      | missing := missing.push <| Json.mkObj [("name", toJson name.toString),
          ("reason", toJson "Invalid imported module index")]; continue
    let modName := modInfo.module
    if !owned.contains modName then
      boundary := boundary.insert name
      continue
    let some ci := env.checked.get.find? name
      | missing := missing.push <| Json.mkObj [("name", toJson name.toString),
          ("reason", toJson "No full kernel ConstantInfo")]; continue
    let value := ci.value? (allowOpaque := true)
    let expectsValue := match ci with
      | .defnInfo _ | .thmInfo _ | .opaqueInfo _ => true
      | _ => false
    if expectsValue && value.isNone then
      missingValues := missingValues.push name.toString
    if ci matches .axiomInfo _ then
      -- A local axiom could also indicate a hidden body. Never silently count
      -- it as a zero-sized proof: this task expects no repository-local axioms.
      localAxioms := localAxioms.push name.toString
    let valueNodes := value.map Expr.sizeWithoutSharing |>.getD 0
    let typeNodes := ci.type.sizeWithoutSharing
    valueTotal := valueTotal + valueNodes
    typeTotal := typeTotal + typeNodes
    let mut deps ← expressionDependencies ci.type
    if let some v := value then
      deps := deps ++ (← expressionDependencies v)
    let mut ruleNodes := 0
    match ci with
    | .inductInfo iv =>
      for n in iv.all ++ iv.ctors do deps := deps.insert n
    | .ctorInfo cv => deps := deps.insert cv.induct
    | .recInfo rv =>
      for n in rv.all do deps := deps.insert n
      for rule in rv.rules do
        deps := deps.insert rule.ctor
        deps := deps ++ (← expressionDependencies rule.rhs)
        ruleNodes := ruleNodes + rule.rhs.sizeWithoutSharing
    | _ => pure ()
    ruleTotal := ruleTotal + ruleNodes
    let isPrivate := name.toString.startsWith "_private."
    if isPrivate then privateCount := privateCount + 1
    let sortedDeps := deps.toArray.qsort Name.lt
    todo := todo ++ sortedDeps
    rows := rows.push <| Json.mkObj [
      ("name", toJson name.toString), ("module", toJson modName.toString),
      ("kind", toJson (declarationKind ci)), ("private_name", toJson isPrivate),
      ("has_value", toJson value.isSome), ("expects_value", toJson expectsValue),
      ("value_expr_nodes_without_sharing", toJson valueNodes),
      ("type_expr_nodes_without_sharing", toJson typeNodes),
      ("recursor_rule_expr_nodes_without_sharing", toJson ruleNodes),
      ("dependencies", toJson (sortedDeps.map Name.toString))]
  let complete := missing.isEmpty && missingValues.isEmpty && localAxioms.isEmpty && unloaded.isEmpty
  let report := Json.mkObj [
    ("root", toJson root.toString),
    ("method", toJson "Repository-owned syntactic declaration closure; types, full values, structure projections, constructors, mutual inductive siblings, and recursor reduction rules; stop at external declarations"),
    ("import_level", toJson "private"),
    ("all_local_module_private_data_loaded", toJson unloaded.isEmpty),
    ("local_module_count", toJson localModules.size),
    ("complete", toJson complete),
    ("local_declaration_count", toJson rows.size),
    ("local_private_declaration_count", toJson privateCount),
    ("local_value_expr_nodes_without_sharing", toJson valueTotal),
    ("local_type_expr_nodes_without_sharing", toJson typeTotal),
    ("local_recursor_rule_expr_nodes_without_sharing", toJson ruleTotal),
    ("local_total_expr_nodes_without_sharing", toJson (valueTotal + typeTotal + ruleTotal)),
    ("external_constant_count", toJson boundary.toArray.size),
    ("external_constants", toJson ((boundary.toArray.qsort Name.lt).map Name.toString)),
    ("missing_constant_lookups", toJson missing),
    ("missing_expected_values", toJson missingValues),
    ("local_axiom_like_declarations", toJson localAxioms),
    ("local_modules_without_private_data", toJson unloaded),
    ("declarations", Json.arr rows)]
  let some out ← IO.getEnv "FLEXIBLE_OUTPUT_DECLARATION_AUDIT"
    | throw <| IO.userError "Set FLEXIBLE_OUTPUT_DECLARATION_AUDIT"
  IO.FS.writeFile out report.compress
  unless complete do
    throw <| IO.userError s!"Incomplete audit: {missing.size} missing lookups, {missingValues.size} missing values, {localAxioms.size} local axiom-like declarations, {unloaded.size} incomplete private imports"
  IO.println s!"Audited {rows.size} local declarations, including {privateCount} private names; {valueTotal} value nodes."
'''


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True, type=Path)
    p.add_argument('--compiled', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--lean', type=Path)
    p.add_argument('--lock', type=Path)
    p.add_argument('--source-inventory', type=Path,
                   help='Optional pinned source inventory matching the compiled modules')
    a = p.parse_args()
    repo, compiled, out = a.repo.resolve(), a.compiled.resolve(), a.output.resolve()
    if out.exists() and any(out.iterdir()):
        raise RuntimeError('Output must be new or empty')
    out.mkdir(parents=True, exist_ok=True)
    lean = str(a.lean.resolve()) if a.lean else shutil.which('lean')
    if not lean:
        raise RuntimeError('Lean executable not found')
    current_graph = inventory(repo, ['PAFlexibleOutput'])
    graph = json.loads(a.source_inventory.read_text()) if a.source_inventory else current_graph
    if set(graph['modules']) != set(current_graph['modules']):
        raise RuntimeError('Supplied source inventory has a different local module set')
    for module in graph['modules']:
        if graph['modules'][module]['imports'] != current_graph['modules'][module]['imports']:
            raise RuntimeError('Supplied source inventory has different imports: ' + module)
    modules = '#[' + ', '.join('`' + m for m in graph['order']) + ']'
    source = out / 'DeclarationAudit.lean'
    source.write_text(BODY.replace('__LOCAL_MODULES__', modules))
    (out/'source_inventory.json').write_text(json.dumps(graph, indent=2) + '\n')
    packages = sorted((repo / '.lake/packages').glob('*/.lake/build/lib/lean'))
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, [compiled, *packages])),
               FLEXIBLE_OUTPUT_LEAN_EXECUTABLE=lean,
               FLEXIBLE_OUTPUT_DECLARATION_AUDIT=str(out / 'declarations.json'))
    lock = None
    try:
        if a.lock:
            import fcntl
            a.lock.parent.mkdir(parents=True, exist_ok=True)
            lock = a.lock.open('a')
            fcntl.flock(lock, fcntl.LOCK_EX)
        result = subprocess.run([lean, '--run', str(source)], cwd=repo, env=env,
                                text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    finally:
        if lock:
            lock.close()
    (out / 'audit.log').write_text(result.stdout)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
    data = json.loads((out/'declarations.json').read_text())
    for row in data['declarations']:
        row['source_file'] = graph['modules'][row['module']]['path']
    data['source_inventory_provenance'] = (str(a.source_inventory.resolve())
                                           if a.source_inventory else 'current source tree')
    data['compiled_directory'] = str(compiled)
    data['source_inventory_note'] = (
        'Source inventory determines module ownership and file labels only. '
        'Declaration bodies and all expression counts come exclusively from --compiled.')
    (out/'declarations.json').write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({k:v for k,v in data.items()
                     if k not in {'declarations','external_constants'}}, indent=2))


if __name__ == '__main__':
    main()
