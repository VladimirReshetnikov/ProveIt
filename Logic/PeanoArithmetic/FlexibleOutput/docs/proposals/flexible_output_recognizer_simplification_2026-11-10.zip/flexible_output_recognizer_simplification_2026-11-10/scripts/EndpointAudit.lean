import PAFlexibleOutput

open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic PAFlexibleOutput

-- Exact current every-input theorem, including divergence and both Option cases.
example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧ ∀ (x : ℕ) (o : Option ℕ),
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e x o :=
  flexibleOutput

example {ξ : Type} (ε : ξ → ℕ) {k} {φ : ArithmeticSemiformula ξ k}
    (hp : Hierarchy 𝚺 1 φ) :
    REPred fun v : List.Vector ℕ k ↦ φ.Eval v.get ε := sigma1_re ε hp

#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
#print axioms PAFlexibleOutput.standardCorrectness
#print axioms PAFlexibleOutput.outputIn_nat
#print axioms PAFlexibleOutput.universalGraph_sigma_one
#print axioms PAFlexibleOutput.code_uniq
#print axioms PAFlexibleOutput.universalGraph_uniq
#print axioms PAFlexibleOutput.valueIn_of_models
#print axioms PAFlexibleOutput.refutationsRE
#print axioms PAFlexibleOutput.exists_selector
#print axioms LO.FirstOrder.Arithmetic.sigma1_re
