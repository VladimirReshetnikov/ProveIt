module

import all Foundation.FirstOrder.Arithmetic.R0.Representation
import Lean

open Lean Elab Command

set_option maxRecDepth 100000

run_cmd do
  let ci ← getConstInfo `LO.FirstOrder.Arithmetic.sigma1_re
  let some value := ci.value? (allowOpaque := true)
    | throwError "No proof value available for sigma1_re"
  let constants := value.getUsedConstants
  let report := Json.mkObj [
    ("declaration", toJson "LO.FirstOrder.Arithmetic.sigma1_re"),
    ("proof_expr_nodes_without_sharing", toJson value.sizeWithoutSharing),
    ("type_expr_nodes_without_sharing", toJson ci.type.sizeWithoutSharing),
    ("direct_constant_count", toJson constants.size),
    ("direct_constants", toJson (constants.toList.map toString))]
  liftIO <| IO.println report.compress

#print axioms LO.FirstOrder.Arithmetic.sigma1_re
