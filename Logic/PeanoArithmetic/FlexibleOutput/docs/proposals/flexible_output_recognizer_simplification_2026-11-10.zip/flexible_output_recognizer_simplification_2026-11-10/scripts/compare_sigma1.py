#!/usr/bin/env python3
"""Compile both bundled sigma1_re proofs and compare their elaborated values.

Run verify.py first. Pass its fresh olean directory with --compiled. This script
reads that directory and the pinned package caches, compiles each bundled source
in a separate fresh overlay, and runs the same Sigma1Audit.lean on both. It
does not modify the repository, the compiled dependency tree, or bundled sources.
All compiler invocations are sequential; --lock adds an optional POSIX lock.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from closure import inventory

REPO_SHA = 'ba2909149fc7187814cde87862f6118dceec6801'
FOUNDATION_SHA = '32e1a0956a8622fad067328ca1959729a7634428'
MODULE = 'Foundation.FirstOrder.Arithmetic.R0.Representation'
DECLARATION = 'LO.FirstOrder.Arithmetic.sigma1_re'
SOURCE_RELATIVE = Path('Foundation/FirstOrder/Arithmetic/R0/Representation.lean')


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_head(path: Path) -> str:
    return subprocess.check_output(
        ['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True, encoding='utf-8').strip()


@contextmanager
def compiler_lock(path: Path | None):
    if path is None:
        yield
        return
    import fcntl
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        yield


def parse_audit(text: str) -> dict:
    records = []
    for line in text.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict) and item.get('declaration') == DECLARATION:
            records.append(item)
    if len(records) != 1:
        raise RuntimeError('Expected exactly one sigma1_re size JSON record')
    return records[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--compiled', type=Path, required=True,
                        help='Fresh verify.py output/olean directory')
    parser.add_argument('--output', type=Path, required=True,
                        help='New or empty directory outside the checkout and dependency tree')
    parser.add_argument('--lean', type=Path,
                        help='Lean 4.32.0 executable; otherwise use lean on PATH')
    parser.add_argument('--lock', type=Path,
                        help='Optional shared POSIX lock file; omit on Windows')
    args = parser.parse_args()
    repo, compiled, output = (path.resolve() for path in
                              [args.repo, args.compiled, args.output])
    lock = args.lock.resolve() if args.lock else None
    if output.is_relative_to(repo) or output.is_relative_to(compiled):
        raise RuntimeError('--output must be outside the repository and compiled dependency tree')
    if lock and (lock.is_relative_to(repo) or lock.is_relative_to(compiled)):
        raise RuntimeError('--lock must be outside the repository and compiled dependency tree')
    if lock and os.name != 'posix':
        raise RuntimeError('--lock uses POSIX fcntl; omit it on this platform')
    if not compiled.is_dir():
        raise RuntimeError('Missing compiled dependency directory: ' + str(compiled))
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise RuntimeError('--output must be a new or empty directory: ' + str(output))

    foundation = repo / 'lib/FormalizedFormalLogic-Foundation'
    for path, expected in [(repo, REPO_SHA), (foundation, FOUNDATION_SHA)]:
        if git_head(path) != expected:
            raise RuntimeError('Wrong pinned revision: ' + str(path))
    # Read the committed manifest, so a working-tree manifest edit cannot alter
    # which package revisions this audit accepts.
    manifest = json.loads(subprocess.check_output(
        ['git', '-C', str(repo), 'show', REPO_SHA + ':lake-manifest.json'],
        text=True, encoding='utf-8'))
    package_root = repo / manifest.get('packagesDir', '.lake/packages')
    packages, package_records = [], []
    for package in manifest['packages']:
        if package['type'] != 'git':
            raise RuntimeError('Unsupported pinned package type: ' + package['name'])
        path = package_root / package['name']
        if git_head(path) != package['rev']:
            raise RuntimeError('Wrong pinned package revision: ' + str(path))
        cache = path / '.lake/build/lib/lean'
        if cache.is_dir():
            packages.append(cache)
        package_records.append({'name': package['name'], 'revision': package['rev'],
                                'cache_directory_present': cache.is_dir()})

    lean = str(args.lean.resolve()) if args.lean else shutil.which('lean')
    if not lean:
        raise RuntimeError('Use --lean /path/to/Lean-4.32.0/bin/lean')
    with compiler_lock(lock):
        version = subprocess.check_output([lean, '--version'], text=True, encoding='utf-8').strip()
    if 'version 4.32.0,' not in version:
        raise RuntimeError('Unexpected compiler: ' + version)

    bundle = Path(__file__).resolve().parents[1]
    source_roots = {'baseline': bundle / 'original/foundation',
                    'proposed': bundle / 'lean/foundation'}
    audit = bundle / 'scripts/Sigma1Audit.lean'
    for source_root in source_roots.values():
        if not (source_root / SOURCE_RELATIVE).is_file():
            raise RuntimeError('Missing bundled source: ' + str(source_root / SOURCE_RELATIVE))
    if not audit.is_file():
        raise RuntimeError('Missing audit source: ' + str(audit))
    graph = inventory(repo, [MODULE])
    dependencies = [name for name in graph['order'] if name != MODULE]
    missing = [name for name in graph['external_imports']
               if name.split('.')[0] not in {'Lean', 'Init', 'Std'}
               and not any((path / (name.replace('.', '/') + '.olean')).is_file()
                           for path in packages)]
    if missing:
        raise RuntimeError('Restore required pinned package caches: ' + ', '.join(missing))

    output.mkdir(parents=True, exist_ok=True)
    logs = output / 'logs'
    logs.mkdir()
    (logs / 'compiler-version.log').write_text(version + '\n', encoding='utf-8')
    runs = []

    def invoke(label: str, overlay: Path, arguments: list[str]) -> str:
        env = dict(os.environ, LEAN_PATH=os.pathsep.join(
            str(path) for path in [overlay, compiled, *packages]), LAKE_JOBS='1')
        command = [lean, *arguments]
        with compiler_lock(lock):
            result = subprocess.run(command, cwd=output, env=env, text=True, encoding='utf-8',
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (logs / (label + '.log')).write_text(result.stdout, encoding='utf-8')
        runs.append({'label': label, 'command': command, 'exit_code': result.returncode,
                     'warning_count': result.stdout.count('warning:')})
        (output / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n', encoding='utf-8')
        print(f'{label}: exit {result.returncode}', flush=True)
        if result.returncode:
            raise RuntimeError('Lean failed; inspect ' + str(logs / (label + '.log')))
        return result.stdout

    results, sources = {}, {}
    for label, source_root in source_roots.items():
        overlay = output / label / 'olean'
        overlay.mkdir(parents=True)
        # Lean selects search roots by module prefix. Mirror the unchanged local
        # dependency artifacts so this overlay is complete for the actual import
        # closure. Hard links save space on the same filesystem; ordinary copies
        # are the portable fallback. Only the target module is compiled, and its
        # artifacts are never linked to the compiled dependency tree.
        for dependency in dependencies:
            relative = Path(dependency.replace('.', '/'))
            stem = compiled / relative
            if not stem.with_suffix('.olean').is_file():
                raise RuntimeError('Missing freshly compiled dependency: ' + dependency)
            destination = overlay / relative.parent
            destination.mkdir(parents=True, exist_ok=True)
            for artifact in stem.parent.glob(stem.name + '.*'):
                if artifact.is_file():
                    target_artifact = destination / artifact.name
                    try:
                        os.link(artifact, target_artifact)
                    except OSError:
                        shutil.copy2(artifact, target_artifact)
        source = source_root / SOURCE_RELATIVE
        target = overlay / SOURCE_RELATIVE.with_suffix('.olean')
        target.parent.mkdir(parents=True, exist_ok=True)
        invoke(label + '-compile', overlay,
               ['-R', str(source_root), '-o', str(target), str(source)])
        results[label] = parse_audit(invoke(label + '-audit', overlay, [str(audit)]))
        sources[label] = {'bundled_path': source.relative_to(bundle).as_posix(),
                          'sha256': sha256(source)}

    before = results['baseline']['proof_expr_nodes_without_sharing']
    after = results['proposed']['proof_expr_nodes_without_sharing']
    report = {
        'status': 'passed', 'lean_version': version,
        'repository_revision': REPO_SHA, 'foundation_revision': FOUNDATION_SHA,
        'pinned_packages': package_records, 'sources': sources,
        'audit_source_sha256': sha256(audit),
        'reused_local_dependency_modules': dependencies,
        'metric': 'Lean.Expr.sizeWithoutSharing applied to the elaborated theorem value: '
                  'raw expression tree nodes; shared subterms counted per occurrence; '
                  'named constants, including generated helpers, not unfolded.',
        'direct_constant_metric': 'Distinct names returned by Expr.getUsedConstants '
                                  'on the theorem value; not a transitive dependency count.',
        'scope': 'Both bundled modules compiled separately; unchanged local dependency '
                 'oleans and pinned external package oleans reused. No timing benchmark.',
        **results,
        'proof_expr_node_reduction': before - after,
        'proof_expr_node_reduction_percent': 100 * (before - after) / before,
    }
    (output / 'metrics.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(f'Proof-expression nodes: {before} -> {after}')
    print('Saved ' + str(output / 'metrics.json'))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
