#!/usr/bin/env python3
"""Rebuild the complete local dependency closure in a fresh, isolated output tree.

Pinned Mathlib package oleans must already be present. No cached Foundation or
PAFlexibleOutput oleans are admitted to LEAN_PATH. All Lean calls are serial.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time

from closure import inventory

REPO_SHA = 'ba2909149fc7187814cde87862f6118dceec6801'
FOUNDATION_SHA = '32e1a0956a8622fad067328ca1959729a7634428'
MATHLIB_SHA = '81a5d257c8e410db227a6665ed08f64fea08e997'
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}


def git_head(path: Path) -> str:
    return subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--lean', type=Path)
    parser.add_argument('--lock', type=Path,
                        help='Optional POSIX lock shared with other validation processes')
    args = parser.parse_args()
    repo = args.repo.resolve()
    foundation = repo / 'lib/FormalizedFormalLogic-Foundation'
    package_root = repo / '.lake/packages'
    for path, expected in [(repo, REPO_SHA), (foundation, FOUNDATION_SHA),
                           (package_root / 'mathlib', MATHLIB_SHA)]:
        if git_head(path) != expected: raise RuntimeError('Wrong pinned revision: ' + str(path))
    lean = str(args.lean.resolve()) if args.lean else shutil.which('lean')
    if not lean: raise RuntimeError('Use --lean /path/to/Lean-4.32.0/bin/lean')
    version = subprocess.check_output([lean, '--version'], text=True).strip()
    if 'version 4.32.0,' not in version: raise RuntimeError('Unexpected compiler: ' + version)
    output = args.output.resolve() if args.output else Path(tempfile.mkdtemp(prefix='flexible-output-check-'))
    build = output / 'olean'
    if build.exists() and any(build.iterdir()):
        raise RuntimeError('The output olean directory must be empty: ' + str(build))
    build.mkdir(parents=True, exist_ok=True)
    logs = output / 'logs'; logs.mkdir(exist_ok=True)
    graph = inventory(repo, ['PAFlexibleOutput',
        'Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1'])
    endpoint_graph = inventory(repo, ['PAFlexibleOutput'])
    (output / 'build_closure.json').write_text(json.dumps(graph, indent=2) + '\n')
    (output / 'endpoint_closure.json').write_text(json.dumps(endpoint_graph, indent=2) + '\n')
    packages = sorted(package_root.glob('*/.lake/build/lib/lean'))
    missing = [name for name in graph['external_imports']
               if name.split('.')[0] not in {'Lean', 'Init', 'Std'}
               and not any((p / (name.replace('.', '/') + '.olean')).is_file() for p in packages)]
    if missing: raise RuntimeError('Restore pinned Mathlib/package caches first: ' + ', '.join(missing))
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(str(p) for p in [build, *packages]), LAKE_JOBS='1')
    # Leave Lean's per-process thread configuration at the user's setting.
    results = []

    def run(label: str, command: list[str]):
        lock = None
        try:
            if args.lock:
                import fcntl
                args.lock.parent.mkdir(parents=True, exist_ok=True)
                lock = args.lock.open('a'); fcntl.flock(lock, fcntl.LOCK_EX)
            start = time.monotonic()
            result = subprocess.run(command, cwd=repo, env=env, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            elapsed = time.monotonic() - start
        finally:
            if lock: lock.close()
        (logs / (label + '.log')).write_text(result.stdout)
        row = {'label': label, 'command': command, 'exit_code': result.returncode,
               'elapsed_seconds': elapsed, 'warning_count': result.stdout.count('warning:')}
        results.append(row)
        (output / 'build_results.json').write_text(json.dumps(results, indent=2) + '\n')
        print(f'{label}: exit {result.returncode}, {elapsed:.2f}s', flush=True)
        if result.returncode:
            print(result.stdout, flush=True)
            raise RuntimeError('Lean failed: ' + label)
        return result.stdout

    for module in graph['order']:
        row = graph['modules'][module]
        target = build / (module.replace('.', '/') + '.olean')
        target.parent.mkdir(parents=True, exist_ok=True)
        run(module, [lean, '-R', str(repo / row['source_root']), '-o', str(target), str(repo / row['path'])])
    here = Path(__file__).resolve().parent
    for audit in ['EndpointAudit.lean', 'RecognizerAudit.lean', 'Sigma1Audit.lean']:
        report = run(audit, [lean, str(here / audit)])
        if audit != 'Sigma1Audit.lean':
            reports = re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]", report)
            if not reports: raise RuntimeError('No axiom reports in ' + audit)
            for name, listed in reports:
                actual = {a.strip() for a in listed.split(',') if a.strip()}
                if not actual <= ALLOWED_AXIOMS:
                    raise RuntimeError('Unexpected axioms for ' + name + ': ' + listed)
    summary = {'status': 'passed', 'lean_version': version,
               'repository_revision': REPO_SHA, 'foundation_revision': FOUNDATION_SHA,
               'mathlib_revision': MATHLIB_SHA,
               'compiled_local_modules': len(graph['order']),
               'endpoint_closure': endpoint_graph['totals'],
               'warning_count': sum(row['warning_count'] for row in results),
               'cached_local_modules_used': 0,
               'scope': 'Fresh full endpoint closure; external package oleans reused.'}
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    try: main()
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
