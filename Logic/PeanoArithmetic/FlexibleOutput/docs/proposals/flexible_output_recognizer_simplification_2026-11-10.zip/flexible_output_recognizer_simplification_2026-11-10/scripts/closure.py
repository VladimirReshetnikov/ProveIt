#!/usr/bin/env python3
"""Inventory the repository-local Lean import closure, including submodules."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import tomllib


def without_comments(text: str) -> str:
    """Remove nested Lean comments, preserving line breaks and string literals."""
    out, i, depth, quoted = [], 0, 0, False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                depth += 1; i += 2
            elif text.startswith('-/', i):
                depth -= 1; i += 2
                out.append(' ')
            else:
                if text[i] == '\n': out.append('\n')
                i += 1
        elif quoted:
            out.append(text[i])
            if text[i] == '\\' and i + 1 < len(text):
                i += 1; out.append(text[i])
            elif text[i] == '"': quoted = False
            i += 1
        elif text.startswith('/-', i):
            depth = 1; i += 2; out.append(' ')
        elif text.startswith('--', i):
            end = text.find('\n', i)
            i = len(text) if end < 0 else end
        else:
            if text[i] == '"': quoted = True
            out.append(text[i]); i += 1
    if depth: raise ValueError('Unterminated block comment')
    return ''.join(out)


def imports(text: str) -> list[str]:
    found = []
    for line in without_comments(text).splitlines():
        match = re.match(r'\s*(?:(?:public|private)\s+)?import\s+(.+)', line)
        if match:
            found.extend(match.group(1).split())
    return found


def inventory(repo: Path, targets: list[str]) -> dict:
    config = tomllib.loads((repo / 'lakefile.toml').read_text())
    roots = [(lib['name'], repo / lib.get('srcDir', '.')) for lib in config['lean_lib']]
    rows, ordered, active, external = {}, [], set(), set()

    def locate(module: str):
        candidates = [(name, root) for name, root in roots
                      if module == name or module.startswith(name + '.')]
        for _, root in candidates:
            source = root / (module.replace('.', '/') + '.lean')
            if source.is_file(): return source, root
        if candidates: raise FileNotFoundError('Missing repository module: ' + module)
        return None

    def visit(module: str):
        if module in rows or module in external: return
        if module in active: raise ValueError('Import cycle: ' + module)
        located = locate(module)
        if located is None:
            external.add(module); return
        source, root = located
        data = source.read_bytes(); text = data.decode('utf-8')
        deps = imports(text)
        active.add(module)
        for dep in deps: visit(dep)
        active.remove(module)
        rows[module] = {
            'path': source.relative_to(repo).as_posix(),
            'source_root': root.relative_to(repo).as_posix(),
            'lines': len(text.splitlines()),
            'nonblank_noncomment_lines': sum(bool(line.strip()) for line in without_comments(text).splitlines()),
            'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'imports': deps,
        }
        ordered.append(module)

    for target in targets: visit(target)
    return {
        'targets': targets, 'modules': rows, 'order': ordered,
        'external_imports': sorted(external),
        'totals': {'modules': len(rows),
                   **{key: sum(row[key] for row in rows.values())
                      for key in ['lines', 'nonblank_noncomment_lines', 'bytes']}},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--target', action='append', default=[])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = inventory(args.repo.resolve(), args.target or ['PAFlexibleOutput'])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['totals']))


if __name__ == '__main__': main()
