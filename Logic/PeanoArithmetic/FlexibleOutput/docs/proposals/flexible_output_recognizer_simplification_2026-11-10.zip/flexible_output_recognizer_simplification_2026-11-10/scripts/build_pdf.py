#!/usr/bin/env python3
"""Build report.pdf from report.tex with locally installed TeX resources."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def locate(name):
    return subprocess.run(["kpsewhich", name], text=True,
                          stdout=subprocess.PIPE, check=False).stdout.strip()


def main():
    for tool in ["pdflatex", "pdftex", "kpsewhich"]:
        if not shutil.which(tool): raise SystemExit("Missing executable: " + tool)
    logs = ROOT / "evidence/pdf_build"
    logs.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flexible-output-report-") as directory:
        temporary = Path(directory)
        env = os.environ.copy()
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error"]
        # Some minimal TeX installations supply resources without format dumps.
        if not locate("pdflatex.fmt"):
            with (logs / "format.log").open("w") as log:
                subprocess.run(["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                                "-progname=pdflatex", "-interaction=nonstopmode",
                                "pdflatex.ini"], cwd=temporary, stdout=log,
                               stderr=subprocess.STDOUT, check=True)
            command.append("-fmt=" + str(temporary / "pdflatex.fmt"))
        if not locate("pdftex.map"):
            maps = [locate(name) for name in
                    ["lm.map", "cm.map", "cmextra.map", "symbols.map", "latxfont.map"]]
            (temporary / "pdftex.map").write_text("\n".join(Path(p).read_text() for p in maps if p))
            env["TEXFONTMAPS"] = str(temporary) + os.pathsep + env.get("TEXFONTMAPS", "")
        command += ["-output-directory=" + str(temporary), "report.tex"]
        for number in [1, 2]:
            with (logs / f"pass-{number}.log").open("w") as log:
                subprocess.run(command, cwd=ROOT, env=env, stdout=log,
                               stderr=subprocess.STDOUT, check=True)
        shutil.copyfile(temporary / "report.pdf", ROOT / "report.pdf")
        shutil.copyfile(temporary / "report.log", logs / "report.log")
    print(ROOT / "report.pdf")


if __name__ == "__main__":
    main()
