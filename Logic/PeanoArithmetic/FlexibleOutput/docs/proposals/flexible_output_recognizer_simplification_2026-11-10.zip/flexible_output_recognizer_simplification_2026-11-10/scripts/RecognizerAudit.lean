import Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1

noncomputable section

open LO LO.FirstOrder LO.FirstOrder.Arithmetic

example (φ : ArithmeticSemiformula ℕ 0) :
    InductionUnivR (⌜φ⌝ : ℕ) ↔
      ∃ σ ∈ InductionScheme ℒₒᵣ Set.univ, φ = (σ : ArithmeticSemiformula ℕ 0) :=
  chUniv_mem_iff φ

example (φ : ArithmeticSemiformula ℕ 0) :
    InductionSigma1R (⌜φ⌝ : ℕ) ↔
      ∃ σ ∈ InductionScheme ℒₒᵣ (Hierarchy 𝚺 1), φ = (σ : ArithmeticSemiformula ℕ 0) :=
  chSigma1_mem_iff φ

example : 𝗣𝗔.Δ₁ := inferInstance
example : 𝗜𝚺₁.Δ₁ := inferInstance

#check LO.FirstOrder.Semiformula.not_fvar?_fixitr_fvSup
#print axioms LO.FirstOrder.Arithmetic.chUniv_mem_iff
#print axioms LO.FirstOrder.Arithmetic.chSigma1_mem_iff
#print axioms LO.FirstOrder.Arithmetic.PA_delta1Definable
#print axioms LO.FirstOrder.Arithmetic.ISigma1_delta1Definable
