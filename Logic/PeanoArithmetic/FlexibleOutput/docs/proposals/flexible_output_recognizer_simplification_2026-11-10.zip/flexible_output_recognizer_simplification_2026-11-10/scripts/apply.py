#!/usr/bin/env python3
"""Check pinned preimages, then apply proof changes and the separate import repair.

The Foundation patch simplifies existing proofs. The ProveIt patch repairs the
upstream Refutations-to-Provability module rename. Every changed file must match
its bundled original snapshot; unrelated working-tree modifications are allowed.
No new module is created. This script does not commit, push, or update gitlinks.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import subprocess
import sys


REPO_SHA = "ba2909149fc7187814cde87862f6118dceec6801"
FOUNDATION_SHA = "32e1a0956a8622fad067328ca1959729a7634428"


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), *args],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    if result.returncode:
        raise RuntimeError(
            f"Git failed in {repo}: {' '.join(args)}\n{result.stdout.strip()}"
        )
    return result.stdout.strip()


def check_revision(repo: Path, expected: str, label: str) -> None:
    actual = git(repo, "rev-parse", "HEAD")
    if actual != expected:
        raise RuntimeError(
            f"Wrong {label} revision.\nExpected: {expected}\nActual:   {actual}"
        )


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_preimages(original: Path, target: Path) -> int:
    files = sorted(p for p in original.rglob("*") if p.is_file())
    if not files:
        raise RuntimeError(f"Bundled original snapshots are missing: {original}")
    for expected in files:
        relative = expected.relative_to(original)
        actual = target / relative
        if actual.is_symlink() or not actual.is_file():
            raise RuntimeError(f"Expected an ordinary original source file: {actual}")
        expected_hash, actual_hash = sha256(expected), sha256(actual)
        if actual_hash != expected_hash:
            raise RuntimeError(
                f"Original source hash mismatch: {actual}\n"
                f"Expected SHA-256: {expected_hash}\n"
                f"Actual SHA-256:   {actual_hash}\n"
                "The script has not applied either patch. Keep this target at the "
                "pinned original bytes, or rebase the proposal manually."
            )
    return len(files)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True,
                        help="Pinned ProveIt checkout to modify")
    parser.add_argument("--check-only", action="store_true",
                        help="Run all preimage and patch checks without changing files")
    args = parser.parse_args()
    repo = args.repo.resolve()
    foundation = repo / "lib/FormalizedFormalLogic-Foundation"
    package = Path(__file__).resolve().parent.parent

    check_revision(repo, REPO_SHA, "ProveIt")
    check_revision(foundation, FOUNDATION_SHA, "Foundation")
    checked = check_preimages(package / "original/foundation", foundation)
    checked += check_preimages(package / "original/proveit", repo)
    patches = [
        (foundation, package / "patches/foundation.patch"),
        (repo, package / "patches/proveit.patch"),
    ]
    for target, patch in patches:
        if not patch.is_file():
            raise RuntimeError(f"Missing bundled patch: {patch}")
        git(target, "apply", "--check", str(patch))
    print(f"Checked both pinned revisions, {checked} exact original file hashes, "
          "and both patches.")
    if args.check_only:
        print("Check-only completed; no files changed.")
        return

    applied: list[str] = []
    try:
        for target, patch in patches:
            git(target, "apply", str(patch))
            applied.append(patch.name)
            print(f"Applied {patch.name}.")
    except Exception as exc:
        if applied:
            raise RuntimeError(
                f"Application stopped after {', '.join(applied)} succeeded. "
                "Inspect the working trees before retrying; no automatic rollback, "
                f"commit, or push was performed.\n{exc}"
            ) from exc
        raise
    print("Applied both patches. No commit, gitlink update, or push was performed.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
