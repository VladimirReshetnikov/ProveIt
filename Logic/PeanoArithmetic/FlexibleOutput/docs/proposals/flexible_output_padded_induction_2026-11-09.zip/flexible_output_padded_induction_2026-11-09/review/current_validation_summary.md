# Current-head validation and size comparison

The baseline and the padded-induction candidate have both been elaborated with Lean 4.32.0, using the pinned Mathlib 4.32.0 and existing compiled, unchanged Foundation dependencies. The five original proof modules and import facade were freshly compiled for the baseline. The current candidate freshly compiles the renamed `Provability` module and a one-line `Refutations` compatibility module as well as the remaining proof modules. The new project-side `PAFlexibleOutput.PaddedInduction` support module was freshly compiled. The final run also compiled the exact-statement checks and optional legacy-API compatibility module; all ten target compilations returned exit code zero. This is normal kernel checking of the new declarations against imported dependencies; it is not a claim that every imported Foundation or Mathlib module was rebuilt from source during this task.

The project-side proof sources grow from 376 to 858 lines because the replacement support lives alongside the theorem. The legacy Foundation source remains available to other clients. The exact original main theorem type is retained. The main source file is unchanged; elaboration picks up the replacement proof of the same `refutationsRE` proposition. Both declaration audits report precisely `propext`, `Classical.choice`, and `Quot.sound`, with no missing constant bodies and no additional axiom.

## Two distinct notions of reduction

For the `PAFlexibleOutput.Main` import closure, counting vendored Foundation as repository-local and excluding external Mathlib packages, the current candidate reduces 139 source modules to 128, 42,503 physical source lines to 39,291, and 1,852,032 source bytes to 1,697,676. This is a reduction of 3,212 lines (7.56%) and 154,356 bytes (8.33%). Thirteen old modules leave the closure and two module names enter: the new padded-induction support and renamed Provability module. The Refutations name now denotes the one-line compatibility import. The net reduction is eleven modules. The optional legacy compatibility module is outside this measured path.

The actual dependency closure of the theorem constant is much less affected. A Lean metaprogram follows each referenced declaration's type and value and the constructors of referenced inductive types. It finds 16,946 total declarations in the baseline and 16,924 in the candidate. The repository-local counts are 6,908 and 6,901. The sum of per-expression object counts in the repository-local closure is 2,926,490 versus 2,908,008, a decrease of 18,482 (0.63%). The corresponding sum over all dependencies is 4,437,029 versus 4,415,680 (0.48%). These counts include type expressions and proof/definition expressions. Sharing within each expression is respected; sharing between separately counted expressions is not subtracted.

Thus the source simplification is substantial enough to remove unnecessary machinery, but it would be inaccurate to report the 7.56% import-source reduction as a 7.56% shrinking of the theorem's proof term. Many imported incompleteness theorems were already absent from the theorem constant's logical dependencies. The padded construction does also remove genuine canonicalization proof dependencies, but the total closure is dominated by the remaining arithmetization infrastructure.

## Artifacts

- `validation/baseline_results.json`, `current_results.json`, and `current_audit_results.json`: compile exit codes, source hashes, elapsed times and exact local commands.
- `validation/logs/`: compiler outputs, including axiom lists.
- `validation/import_metrics.py`, `compare_imports.py`: portable source closure accounting.
- `validation/audit-sources/DependencyAudit.lean`: executable declaration-closure inspection.
- `validation/compare_declarations.py`: comparison of those audits.
- `validation/current_metrics_summary.json`: concise combined machine-readable result.
- `validation/baseline_declarations.json`, `current_declarations.json`: full per-declaration evidence.

The timing fields are single-run diagnostics, not a controlled performance benchmark. The expression hashes are diagnostic checks, not a cryptographic or kernel certificate of expression equality. A small host-specific `readlink` compatibility shim was needed to let the unmodified Lean executable locate itself in this environment; it does not change the compiler, kernel, source or proof logic, and ordinary hosts do not require it.

## Snapshot distinction

The successful baseline is commit `5ad98b5a50c2c5c4193d56d509181334d65d69e8`. During preparation, upstream advanced to `52a9bb875b6e4026a79c8f53906d71602c11afee`, renaming the original Refutations source to Provability without updating the Main/facade imports, and adding another proposal archive. The primary candidate targets that current head and supplies `Refutations.lean` with `import PAFlexibleOutput.Provability`. No successful compilation of the unpatched renamed head is claimed. The retained `final_*` measurements describe the alternative patch against the verified earlier snapshot; the `current_*` measurements include the one-line repair. The actual reachable theorem-constant counts and expression sizes are identical between these two candidate integrations.
