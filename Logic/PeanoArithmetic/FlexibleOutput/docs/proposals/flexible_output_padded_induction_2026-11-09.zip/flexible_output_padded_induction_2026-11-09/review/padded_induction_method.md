# The padded-induction method

## What was unnecessarily strong in the old effectiveness proof

The flexible-output diagonal argument needs an effective way to enumerate PA refutations. It does not need a decision procedure recognizing one privileged syntactic presentation of each induction axiom.

The existing `InductionSchemeDelta1` recognizer checks that a closed sentence is the **canonical** universal closure of a successor-induction instance. Among its checks is `bv b = m`, where `b` is the body before `m` leading universal quantifiers. This equality pins the number of closing quantifiers to the formula's canonical free-variable bound. Its correctness proof therefore reconstructs the canonical closure literally, including invariance of codes under level casts and an exact bound-depth theorem.

The new method keeps the effective induction-body check but relaxes the equality pin. A well-formed body at level `m` has `bv b ≤ m`, which permits redundant quantifiers. Instead of proving that every recognized axiom is syntactically a canonical PA axiom, prove that it is true in every PA model. This weaker obligation is all that is required to transport theorem enumeration.

## The effective predicate

Write `A(b,m)` for the code obtained by adding `m` universal quantifiers to code `b`; `F(m)` for the vector of codes of free variables `&0,...,&(m-1)`; and `I(K)` for the code of the successor-induction body associated with a one-bound-variable formula with code `K`.

The predicate is

```
R(p) := ∃ m ≤ p, ∃ b ≤ p,
          p = A(b,m)
        ∧ IsSemiformula(m,b)
        ∧ shift(b) = b
        ∧ ∃ K ≤ subst(F(m),b),
            IsSemiformula(1,K)
          ∧ subst(F(m),b) = I(K).
```

Every operation here is an internal syntactic coding operation with the existing Foundation definability API. The predicate contains no truth oracle. The explicit Sigma-one and Pi-one presentations use the total functional graphs of `A`, `F`, substitution, shift, and `I`, with bounded witnesses `m`, `b`, and `K`. Their equivalence is proved in every model of `IΣ₁`, giving a valid `Theory.Δ₁` instance.

Let `Induction` be the set of arithmetic sentences whose codes satisfy `R`, and let

```
Padded.PA := PAminus ∪ Induction.
```

The definition is deliberately direct. A separate exact syntactic characterization of `Induction` is unnecessary for the argument.

## Decoding and the sentence issue

The class `Theory.Δ₁` in this Foundation revision tests arbitrary propositions with numerical free variables, not only sentences. It is therefore necessary to show that a recognized proposition is closed before using the recognizer as a theory presentation.

From `R(quote φ)`, `IsSemiformula.sound` decodes `b` as a formula `β` at level `m` and `K` as a formula `γ` at level one. The quotation lemmas and injectivity of quotation give:

1. `φ = ∀* β`.
2. `shift β = β`.
3. `β[&0,...,&(m-1)] = succInd γ`.

Because a formula has finitely many free variables, a formula fixed by the successor shift has no free variables: a least free-variable index would have to have a smaller predecessor. Thus `β.freeVariables = ∅`, and hence `φ.freeVariables = ∅`. The existing `toEmpty`/`emb_toEmpty` interface supplies an actual sentence whose embedding is exactly `φ`. This discharges the difficult direction of `Theory.Δ₁.mem_iff` without canonical closure inversion.

## Every canonical PA axiom is accepted

For a canonical induction instance, put `χ = succInd ψ`, choose the usual canonical body

```
β := Rew.fixitr 0 χ.fvSup ▹ χ,
m := χ.fvSup,
K := quote ψ.
```

The existing quotation of universal closure proves the outer code equation. The body is well formed at level `m`. The public `fvarList_univCl'` lemma proves it has no free variables, so shift fixes it. Opening the body with the free-variable vector recovers `χ`, and the induction-body coding lemma identifies its code with `I(K)`.

The numerical bounds follow from the existing inequalities for iterated quantifier coding and the fact that the induction-body code contains `K` as a subexpression. No exact `bv=m` fact is needed. This gives literal inclusion `PA ⊆ Padded.PA` of axiom sets.

## Every added axiom holds in every PA model

Fix any ordered-ring structure `M` satisfying PA. Decode a padded induction axiom as `∀* β`, with `β` free-variable-free and `β[&i]=succInd γ`.

To prove `∀* β`, take an arbitrary bound assignment `a : Fin m → M`. Extend it to a free-variable assignment

```
g(i) := if i < m then a(i) else 0.
```

The canonical induction axiom for `γ` belongs to PA, so it holds in `M`. Its universal-closure semantics imply that `succInd γ` holds under the assignment `g`. Rewrite it as `β[&i]`; substitution semantics identify this with `β` evaluated under bound assignment `a` and free assignment `g`.

Since `β` has no free variables, its truth does not depend on the free assignment. The existing `eval_iff_of_funEqOn` lemma transports from `g` to any other assignment. Finally `eval_allClosure` gives the required truth of `∀* β`.

This argument works in arbitrary, possibly nonstandard PA models. It does not substitute standard-model correctness for nonstandard semantics, and it does not identify a padded axiom literally with a canonical axiom.

## Models, proofs, and refutations

Literal inclusion of canonical PA axioms gives

```
M ⊨ Padded.PA  →  M ⊨ PA.
```

The preceding semantic argument gives the converse. Consequently

```
Padded.models_iff : (M ⊨ Padded.PA) ↔ (M ⊨ PA).
```

Soundness and arithmetic completeness now give, for every arithmetic sentence `σ`,

```
Padded.provable_iff σ : (Padded.PA ⊢ σ) ↔ (PA ⊢ σ).
```

The new Δ₁ instance supplies an arithmetized provability predicate for `Padded.PA`. The existing Sigma-one-to-RE route enumerates its refutations. At the final external equivalence, rewrite by `Padded.provable_iff` to obtain the exact original PA-refutation relation. Therefore the public `refutationsRE` theorem, the chosen computation graph, and the main diagonal theorem need not change.

There is no circular use of PA's original axiom recognizer: the model argument uses PA's elementary syntactic induction schema and first-order semantics; the new effective recognizer is proved independently. Completeness was already part of the surrounding development and introduces no new foundational axiom.

## Verified API

All declarations below are in namespace `LO.FirstOrder.Arithmetic.Padded`:

| Declaration | Role |
| --- | --- |
| `InductionR` | Effective padded-induction code predicate. |
| `InductionR.defined` | Uniform Δ₁ definition in models of IΣ₁. |
| `decode` | Recovers the closed body and its induction opening. |
| `inductionDelta1` | Δ₁ instance for the induction axiom set. |
| `canonical_mem` | Acceptance of every canonical induction axiom. |
| `PA`, `paDelta1` | New theory and its Δ₁ presentation. |
| `pa_subset` | Literal canonical PA axiom inclusion. |
| `eval_of_induction` | Semantic core under arbitrary model assignments. |
| `models_induction`, `models_iff` | Equality of model classes. |
| `provable_iff` | Equality of theorem sets. |

The frozen module compiled with no warnings, no admitted proofs, and only `propext`, `Classical.choice`, and `Quot.sound` in the axiom dependency list of `provable_iff`. Root-level validation checks the unchanged FlexibleOutput endpoints after integration.
