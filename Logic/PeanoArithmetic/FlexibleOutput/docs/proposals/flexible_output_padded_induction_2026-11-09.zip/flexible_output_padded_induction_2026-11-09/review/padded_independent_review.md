# Independent review: padded induction presentation

Reviewed source: `padded/ProveIt/lib/FormalizedFormalLogic-Foundation/Foundation/FirstOrder/Incompleteness/PaddedInduction.lean`.
Reviewer: independent proof-analysis agent, separate from implementation author.
The review covers the complete recognizer and all equivalence proofs. The author is
subsequently removing unused helpers; the mathematical obligations below must remain.

## Finding

The construction is mathematically sound and preserves the original FlexibleOutput theorem.
Its novel step is to change the auxiliary axiom recognizer's target to a deductively
equivalent presentation. It does not claim the relaxed recognizer exactly recognizes the
original PA axiom set. That distinction removes the need to recover the canonical minimal
number of universal quantifiers.

## Obligations checked

1. **Recognizer.** `InductionR p` retains well-formedness at level m (`IsSemiformula m b`),
   absence of free variables (`shift b = b`), and equality of the opened body with an actual
   induction body. It replaces exact bound-variable-depth equality by the existing
   well-formedness bound. Its numeric witnesses remain bounded where required for the
   delta-one presentation. Total definable graph operations justify the paired sigma and
   pi formulas over every IΣ1 model.
2. **Decode.** The conclusion is exactly what is warranted: φ is an m-fold closure of β;
   β has no free variables; and replacing β's m bound slots with free variables gives
   `succInd γ`. It neither asserts minimality of m nor identifies the result with the
   original canonical `univCl` syntax.
3. **Delta-one axiom instance.** The `mem_iff` field of `Theory.Δ₁` quantifies over
   propositions, not only sentences. The implementation first uses decode to prove a
   recognized proposition has no free variables, then constructs its `toEmpty` sentence.
   This avoids a possible over-recognition bug for open formulas.
4. **Original axioms are included.** `canonical_mem` uses exactly the existing canonical
   fixitr witness. No minimal-depth lower bound is required. Together with unchanged
   PA-minus axioms this proves `pa_subset : PA_original ⊆ PA_padded`.
5. **Every padded axiom holds in each original PA model.** For any finite assignment a,
   `eval_of_induction` extends a to an ℕ-assignment g with arbitrary default value 0.
   Original PA validates the induction axiom for γ under g. Semantic substitution gives
   β under a and g. The absence of free variables allows any final free assignment.
   Universal closure then proves the desired padded sentence. Redundant bound variables
   cause no difficulty because every assignment was quantified.
6. **Equivalence.** The inclusion gives padded-model => original-model; the preceding
   semantic proof gives original-model => padded-model. Arithmetic completeness and
   soundness yield equivalence of provability for every original arithmetic sentence.
   Explicit equality-theory instances discharge completeness hypotheses; no extra
   arithmetic axiom is introduced.
7. **Target preservation.** Refutation enumerability may be proved for the padded
   presentation and transported through `provable_iff`. Main continues to use the
   original PA theory and the same definitions of `universalGraph`, `haltSentence`,
   `OutputIn`, and `ValueIn`. An existentially chosen program may differ operationally,
   which is immaterial; equality to the old chosen witness should not be claimed.

## Novelty and measurement qualifications

The five proposal archives audited separately concern direct diagonal arguments,
exact-value refutations, search/quotation rewrites, and local functionality proof
compression. None inspected changes the auxiliary induction presentation to remove
canonical closure inversion. This proposal is distinct.

A source/import-closure reduction is not a claim that every removed imported declaration
occurred in the kernel proof term. Retaining the old recognizer for unrelated clients
also means total repository source may grow while the target's required support shrinks.
Report these quantities separately.

## Verification limits

This review complements the Lean 4.32.0 elaboration/axiom checks; it is not a separate
formal metatheorem about minimal code size or implementation optimality. No such
minimality claim is warranted. Existing source-library trust and the ordinary Lean
axioms remain those of the original theorem.


## Final review addendum

The preceding review records the earlier implementation location and five-archive
audit available at that time. The final review checked the project-side module
`PAFlexibleOutput/PaddedInduction.lean`, SHA-256
`aefd4a478e9cf630b730ed0b368389d75cf39f462f5a079da8cb12b5bda6014f`,
and the current-revision integration. The semantic core remains unchanged.
All ten source hashes match the successful compile records. The final novelty
audit separately covers all six archives at commit 52a9bb875b6e4026a79c8f53906d71602c11afee.
The complete report and final measurements were reviewed. No substantive gap
or overstated reduction was found. Terminology was corrected to arithmetic
structure, audit availability to no missing declarations, and the runtime
lookup explanation to the exact PID-path-to-self-alias fallback.
