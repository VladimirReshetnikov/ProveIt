# Audit of existing FlexibleOutput simplification proposals

## Scope and provenance

The audited directory is `Logic/PeanoArithmetic/FlexibleOutput/docs/proposals`. The initial snapshot at ProveIt commit `5ad98b5a50c2c5c4193d56d509181334d65d69e8` contained five ZIP archives. A final refresh found a sixth archive at commit `52a9bb875b6e4026a79c8f53906d71602c11afee`; that archive's full report and patch were also audited. All six reports and their supplied Lean patches were inspected. `existing_proposals_manifest.json` records exact ZIP filenames, sizes, Git blob SHA-1 identifiers, SHA-256 hashes, and internal report/patch paths. Each ZIP blob identifier matches the GitHub directory inventory obtained by the parent agent. P1–P5 retain the initial alphabetical numbering; P6 denotes the late-arriving archive.

The final source snapshot also renames `Refutations.lean` to `Provability.lean` without changing that file's contents, while existing imports still name `Refutations`. The integration patch handles this naming discrepancy separately from the mathematical proposal.

This audit establishes nonduplication against these particular six artifacts. It is not a literature-wide novelty claim. Statements of successful old builds below describe the evidence and claims packaged in those archives; this audit did not independently rerun the six historical builds.

## Archive-level comparison

| ID | Archive | Baseline | Principal proposal and exact scope | Included validation evidence |
| --- | --- | --- | --- | --- |
| P1 | `flexible_output_simplification (2).zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Replace the custom `ArithmeticBridge`/`SearchImplementation` assembly with a direct PA proof using finite-computation adequacy and the existing consistency instance. Keep the original halting-search target and global functionality. Also simplify composition/minimization functionality, whole-statement semantic conversions, and substitution-vector equality. Optional bridge compatibility module preserves removed adapters. | Reports successful baseline, direct-core, combined-patch, compatibility, and endpoint builds under Lean 4.32.0. Eight audited endpoints report only `propext`, `Classical.choice`, `Quot.sound`. Exact statements, definitions, patch application, and source counts checked. Changed files: 261 to 195 active lines; explicitly restricted core: 106 to 28. |
| P2 | `flexible_output_simplification.zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Search refutations of the complete value specification `∀ y, U(y,c,x) ↔ y=n`. Standard correctness plus `Part.mem_unique` proves its standard correctness; completeness supplies uniqueness in the selected models directly. This removes global functionality and abstract assembly from the main proof path. Generalize internal refutation enumerability to any fixed three-variable template; use unary search with a compatibility wrapper. Keep global functionality and old bridge interfaces in `Compatibility`. | Successful baseline/replacement, compatibility, exact-statement, facade, and proof-constant-dependency checks are reported. Dependency audit traverses 16,975 constants. Main local import closure: 865 to 578 physical lines, 491 to 332 active lines. External Foundation/Mathlib excluded from that count. |
| P3 | `flexible_output_simplification_2026-11-09.zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Same central complete-value-search idea as P2, with `templateRefutationsRE`, `exactValueGraph`, direct standard soundness, and a separate `FullAudit` for global functionality. Keeps the original search module byte-for-byte. Includes a mutually exclusive conservative direct-soundness alternative retaining the ordinary halting-search target. | Reports successful baseline, recommended exact-value implementation, full audit, exact public types, and conservative alternative builds. Main closure: 865 to 574 physical lines, 476 to 336 code lines (its convention excludes `#print axioms`). FullAudit closure: 449 code lines; conservative alternative: 388. |
| P4 | `flexible_output_simplification_7142f7f_verified.zip` | `7142f7f52bbd36ede33f2be1a66dfdccc238e255` | Four independent local cleanups of the already shortened five-module proof: domain calculation by `simp [hcg, Part.assert, Part.map]`; partial-value projection/`Part.get_mem` in Search; Main's final contradiction via domain rewriting and `simpa`; quoted negation via `congrArg (neg ...)`; one initial simplification of composition functionality. Explicitly treats direct soundness, arbitrary-parameter selectors, and all-input flexibility as already upstream. | Reports successful baseline, all four replacements, facade, and exact-endpoint audit. 376 to 361 physical lines, 198 to 184 active lines. Current semantic definitions, all theorem headers, imports, and corollaries preserved. Only standard Lean axioms reported. Uses pinned Lean/Mathlib/Foundation and documents a host startup compatibility shim. |
| P5 | `pa_flexible_output_simplification.zip` | `410c820c4faa7620a19ce07f55f43c13e5fbb688` | Local functionality, Search, quotation, and generic assembly simplifications, plus optional direct PA proof by standard-model soundness/completeness. The generic assembly also changes to a single `noSearch` contradiction used for both divergence and nonrefutability. Keeps fixed graph and all six endpoint statements; removes three adapters only in direct mode. | Reports successful package checker runs for local-only and combined profiles, exact source hashes, facade builds, and endpoint audits. Five changed modules: 389 to 307 active lines; full nine-module project: 568 to 486. Main import closure: 491 to 349. |
| P6 | `flexible_output_simplification (1).zip` | `7142f7f52bbd36ede33f2be1a66dfdccc238e255` | Encode `((c,x),y)` once as a natural number; recover coordinates using Foundation projections and `nat_pair_eq`; apply unary `re_iff_sigma1` directly. This deletes the custom ternary-to-vector bridge, the old `refutation_sigma1`, and the local coordinate-computability proof. Additional contextual-simp atomic functionality, antisymmetry minimization, composition normalization, quotation congruence, and selector-domain cleanups. Crucially, it retains `Provable 𝗣𝗔` and the original `InductionSchemeDelta1` import. | Reports successful baseline/proposal builds, exact endpoint types and `ValueIn` equations, endpoint axiom audits, public facade, forward/reverse patches, and source hashes. Five-module closure: 376 to 343 physical lines, 198 to 173 active lines. Main, Halting, and facade are byte-identical; only two auxiliary lemma names are removed. |

All six use Lean 4.32.0, Mathlib `81a5d257c8e410db227a6665ed08f64fea08e997`, and Foundation `32e1a0956a8622fad067328ca1959729a7634428` in their final validation descriptions. Their line metrics use different scopes/conventions and should not be treated as directly comparable scores.

## Technique-level exclusion matrix

| Technique | Existing coverage | Consequence for a new proposal |
| --- | --- | --- |
| Bypass custom bridge/assembly and use recursion theorem directly | P1, P2, P3, P5; upstream by P4 | Excluded as new work. |
| Standard-model soundness instead of PA-internal finite-computation verification | P2, P3, P5; already baseline in P4 | Excluded. |
| Direct consistency + finite-computation proof | P1 | Excluded. |
| Search for a refutation of the exact singleton-output sentence | P2, P3 | Excluded even if adapted to the new all-input theorem. The mathematical device is the same. |
| Parameterize the internal arithmetized refutation proof by an arbitrary fixed formula | P2, P3 | Excluded. Both expressly retain the existing `Provable`, numeral substitution, quotation, and Sigma-one definability route. |
| Unary proof search, postponing the ignored input until `fixed_point₂` | P2 | Excluded, and current upstream no longer ignores the input. |
| General arbitrary-parameter RE selector | Future research in P1/P5; current upstream already has `exists_selector` | Excluded as a contribution. |
| One initial semantic normalization for composition/minimization functionality | P1, P5; composition repeated in P4 | Excluded. |
| Whole-statement `simpa` for `code_uniq`; direct specialization for `universalGraph_uniq` | P1, P5 | Excluded. |
| Use numerals throughout `valueIn_of_models` | P1 | Excluded. |
| Replace a three-case vector mapping proof by `Matrix.comp_vecCons'` | P1, P5; generalized in P2/P3 | Excluded. |
| Apply negation by `congrArg` to `substNumerals_app_quote` | P4 | Excluded. |
| Simplify semidecision-domain proof and avoid unpack/repack of arbitrary output witnesses | P4; antecedents in P5 | Excluded. |
| Main final contradiction directly at the selector-domain level | P4 | Excluded. |
| Use one `noSearch` invariant throughout generic assembly | P5; discussed historically in P4 | Excluded. |
| Relocate `code_uniq` to Foundation, or selector theorem to Mathlib | Explicit future directions in P1/P5/P6 | Mere relocation cannot be advertised as a fresh idea. |
| Encode the entire refutation query once and use unary Sigma-one enumerability with pairing projections | P6 | Excluded. The present padding proposal does not use or claim this arity-bridge simplification. |
| Contextual simp for atomic functionality and direct antisymmetry in minimization | P6 | Excluded as new local cleanups. |

## Candidate approaches absent from these archives

### A. PA-specific axiom definability, separate from the `IΣ₁` classifier

None of the six archives proposes splitting `Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1`, supplying a smaller PA-only axiom-membership/definability module, or removing the `IΣ₁` formula classifier and recovery machinery from the FlexibleOutput import path. None proposes replacing imports through `Incompleteness.First`/`Second` by the exact lower-level arithmetic proof and definability modules needed by PA.

This is distinctly different from the previous template-generalization proposals: those expose a formula argument but keep the heavy arithmetized proofhood backend intact. A PA-specific backend changes that dependency architecture.

Accounting should distinguish (1) source in the transitive import closure and (2) constants actually used by the proof term. Simply putting already-unused declarations in another module reduces (1) without necessarily reducing (2). A smaller PA-specific axiom-membership proof could improve both. Keep removed generic results available to their existing clients rather than claim repository-wide deletion.

### B. External proof enumeration instead of internal arithmetized provability

No inspected archive provides or proposes a direct computable enumeration of external PA proof objects to establish `refutationsRE`. P2/P3 explain informally that PA proofs can be enumerated, but their supplied implementation deliberately continues to use the existing internal `Σ₁` provability, substitution, and quotation development. A proved external proof enumerator with completeness and computability would be a distinct implementation proposal and could remove a substantial bootstrapping dependency branch.

This is only a candidate until the required computational syntax/proof APIs are implemented and compiled. An unproved `provabilityRE` lemma would merely hide the work and cannot count as a reduction.

### C. A different representation/compiler theorem with independently proved nonstandard semantics

All six archived implementations retain the chosen `universalGraph`; none replaces the arithmetic compiler or proves functionality by a new compiler invariant. A new representation route therefore is not duplicated by these archives. It has a substantial semantic obligation: standard correctness alone does not imply functionality in arbitrary nonstandard models. The complete-value-search shortcut is already covered by P2/P3 and is not a new representation theorem.

## Suggested wording for the final novelty claim

“I inspected all six proposal archives present at the final snapshot `52a9bb875b6e4026a79c8f53906d71602c11afee`. Their improvements concern the diagonal argument, exact-value search, the unary encoding of refutation queries, and local proof normalization. The present proposal instead [describe the actual verified PA-specific dependency change]. None of the six inspected proposals changes that backend. This is a nonduplication claim relative to those archives, not a claim of global originality.”

## Verified new method developed after the audit

The final candidate goes beyond a module split. It replaces the requirement to recognize **exactly the repository's canonical PA induction axioms** by recognition of a larger, deductively equivalent induction presentation. The new recognizer keeps `IsSemiformula m b` and `shift b = b`, but removes `bv b = m`. Thus the number of leading universal quantifiers may exceed the least number needed by the body. Opening that body with the free variables `&0,...,&(m-1)` must still recover the exact successor-induction shape.

The newly proved semantic argument establishes that every recognized axiom holds in **every PA model**, not only in the standard model. Conversely, every canonical PA induction axiom is recognized. Consequently the new theory and PA have the same model class; completeness establishes equality of their provability predicates. This allows the public `refutationsRE` statement to remain about PA and allows `Main.lean` to remain unchanged.

No archive proposes widening the induction axiom presentation, allowing redundant universal closure, replacing exact syntactic closure inversion by model equivalence, or transporting a simpler theory's proof enumeration back to exact PA provability. P2/P3's change to the sentence being searched is a different technique: the present method keeps the searched halting sentence and changes the effective presentation of the theory that proves its negation.

The independent module `PaddedInduction.lean` compiled successfully with Lean 4.32.0. Its theorem `LO.FirstOrder.Arithmetic.Padded.provable_iff` reports exactly `propext`, `Classical.choice`, `Quot.sound`. The final frozen source before root relocation contains 484 physical lines, SHA-256 `aefd4a478e9cf630b730ed0b368389d75cf39f462f5a079da8cb12b5bda6014f`. The downstream endpoint compilation and dependency measurements are recorded separately in the final verification artifacts.


## Final refresh: sixth archive and novelty conclusion

P6 was added after the initial five-archive audit. Its headline technique is the unary encoding bridge, supported by ordinary pairing/projection identities, while its PA-proof enumerator still depends on the same canonical axiom recognizer. The report explicitly keeps the original graph and all main endpoints unchanged and proposes no modification of the induction axiom presentation or its semantics. Its further-work discussion only suggests moving selector and functionality results upstream.

After inspecting the complete P6 report and all of `changes.patch`, the padded-induction method remains distinct from **all six** archived proposals. The new method does not use P6's unary query encoding or credit its local cleanups as new contributions.
