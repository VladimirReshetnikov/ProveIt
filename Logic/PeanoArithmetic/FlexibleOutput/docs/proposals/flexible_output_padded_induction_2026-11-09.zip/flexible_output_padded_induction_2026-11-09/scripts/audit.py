#!/usr/bin/env python3
"""Repeat the actual declaration dependency traversal after building the proposal."""
import argparse
import os
import pathlib
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repo', type=pathlib.Path)
parser.add_argument('output', type=pathlib.Path)
args = parser.parse_args()
source = pathlib.Path(__file__).resolve().parent.parent / 'evidence/audits/DependencyAudit.lean'
env = os.environ.copy()
env['AUDIT_OUTPUT'] = str(args.output.resolve())
subprocess.run(['lake', 'env', 'lean', str(source)], cwd=args.repo.resolve(), env=env, check=True)
