#!/usr/bin/env python3
"""Count repository-local Lean source in an import closure, with optional overlay.

Modules from Mathlib and other external packages are intentionally excluded.
Foundation counts because ProveIt vendors it. Counts are physical source lines,
not theorem dependency sizes or claims about the amount of trusted mathematics.
"""
import argparse, hashlib, json, pathlib, re, tomllib

parser=argparse.ArgumentParser()
parser.add_argument('--repo',type=pathlib.Path,required=True)
parser.add_argument('--overlay',type=pathlib.Path)
parser.add_argument('--root',default='PAFlexibleOutput.Main')
parser.add_argument('--output',type=pathlib.Path,required=True)
args=parser.parse_args()
config=tomllib.loads((args.repo/'lakefile.toml').read_text())
module_map={}
for library in config['lean_lib']:
    rel=pathlib.Path(library.get('srcDir','.'))
    candidates=[args.repo/rel]
    if args.overlay:
        candidates.append(args.overlay/rel)
    for directory in candidates:
        if not directory.exists(): continue
        for file in directory.rglob('*.lean'):
            if any(part in ('.lake','.git') for part in file.parts): continue
            module='.'.join(file.relative_to(directory).with_suffix('').parts)
            module_map[module]=(file,rel/file.relative_to(directory))
def imports(source):
    return re.findall(r'(?m)^\s*(?:public )?import\s+([A-Za-z0-9_.]+)',source)
todo=[args.root];seen=set();records=[];external=set()
while todo:
    module=todo.pop()
    if module in seen:continue
    seen.add(module)
    if module not in module_map:
        external.add(module);continue
    file,relative=module_map[module]
    raw=file.read_bytes();source=raw.decode()
    imp=imports(source);todo.extend(imp)
    records.append({'module':module,'file':str(relative),'physical_lines':len(source.splitlines()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'imports':imp})
records.sort(key=lambda r:r['module'])
result={'root':args.root,'module_count':len(records),'physical_lines':sum(r['physical_lines'] for r in records),'bytes':sum(r['bytes'] for r in records),'external_import_roots':sorted(external),'modules':records}
args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('modules','external_import_roots')}))
