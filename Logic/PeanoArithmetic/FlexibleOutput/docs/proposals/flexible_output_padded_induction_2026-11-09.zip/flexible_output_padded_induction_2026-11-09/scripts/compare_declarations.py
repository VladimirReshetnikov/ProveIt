#!/usr/bin/env python3
"""Summarize syntactic Lean declaration dependency audits; no theorem-size claims."""
import argparse,json,pathlib,collections
p=argparse.ArgumentParser()
p.add_argument('baseline',type=pathlib.Path)
p.add_argument('candidate',type=pathlib.Path)
p.add_argument('--output',type=pathlib.Path,required=True)
a=p.parse_args()
def summarize(data):
    records=data['declarations']
    def subset_summary(rs):
        return {'declarations':len(rs),'type_tree_nodes':sum(r['type_nodes'] for r in rs),'value_tree_nodes':sum(r['value_nodes'] for r in rs),'type_objects':sum(r['type_objects'] for r in rs),'value_objects':sum(r['value_objects'] for r in rs)}
    modules=collections.defaultdict(list)
    for r in records:modules[r['module']].append(r)
    return {'all':subset_summary(records),'repository_local':subset_summary([r for r in records if r['module'].startswith(('Foundation.','PAFlexibleOutput'))]),'root':next(r for r in records if r['name']==data['root']),'axioms':sorted(r['name'] for r in records if r['is_axiom']),'missing':data['missing'],'per_module':{m:subset_summary(rs) for m,rs in sorted(modules.items())}}
b=json.loads(a.baseline.read_text());c=json.loads(a.candidate.read_text())
bn={r['name']:r for r in b['declarations']};cn={r['name']:r for r in c['declarations']}
result={'baseline':summarize(b),'candidate':summarize(c),'added_names':sorted(cn.keys()-bn.keys()),'removed_names':sorted(bn.keys()-cn.keys()),'shared_name_count':len(bn.keys()&cn.keys()),'changed_hash_or_size_names':sorted(n for n in bn.keys()&cn.keys() if any(bn[n][k]!=cn[n][k] for k in ('type_nodes','value_nodes','type_hash','value_hash'))),'caveat':'Counts follow types, values and inductive constructors, include trusted imported proofs, and distinguish syntactic constant dependencies from module imports. Object counts sum per expression; sharing across declarations is not deducted. Expression hashes are diagnostics, not an equality certificate.'}
a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({side:{k:v for k,v in result[side].items() if k!='per_module'} for side in ('baseline','candidate')},indent=2))
