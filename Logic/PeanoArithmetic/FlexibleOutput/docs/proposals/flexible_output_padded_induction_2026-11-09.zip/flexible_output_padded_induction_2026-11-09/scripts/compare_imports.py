#!/usr/bin/env python3
import argparse,json,pathlib
p=argparse.ArgumentParser()
p.add_argument('baseline',type=pathlib.Path)
p.add_argument('candidate',type=pathlib.Path)
p.add_argument('--output',type=pathlib.Path,required=True)
a=p.parse_args()
b=json.loads(a.baseline.read_text());c=json.loads(a.candidate.read_text())
bm={m['module']:m for m in b['modules']};cm={m['module']:m for m in c['modules']}
metrics=('module_count','physical_lines','bytes')
result={'baseline':{k:b[k] for k in metrics},'candidate':{k:c[k] for k in metrics},'reduction':{k:b[k]-c[k] for k in metrics},'removed_modules':[bm[m] for m in sorted(bm.keys()-cm.keys())],'added_modules':[cm[m] for m in sorted(cm.keys()-bm.keys())],'changed_modules':[{'module':m,'baseline':bm[m],'candidate':cm[m]} for m in sorted(bm.keys()&cm.keys()) if bm[m]['sha256']!=cm[m]['sha256']]}
a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if not isinstance(v,list)},indent=2))
