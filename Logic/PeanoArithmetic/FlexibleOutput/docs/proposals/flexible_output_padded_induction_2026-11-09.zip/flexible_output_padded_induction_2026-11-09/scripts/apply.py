#!/usr/bin/env python3
"""Apply the matching reviewed patch to one of the two supported revisions."""
import argparse
import pathlib
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repo', type=pathlib.Path)
parser.add_argument('--check-only', action='store_true')
args = parser.parse_args()
repo = args.repo.resolve()
package = pathlib.Path(__file__).resolve().parent.parent
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
patches = {
    '52a9bb875b6e4026a79c8f53906d71602c11afee': 'current-52a9bb8.patch',
    '5ad98b5a50c2c5c4193d56d509181334d65d69e8': 'original-5ad98b5.patch',
}
if head not in patches:
    raise SystemExit('Unsupported revision ' + head + '. Review and adapt the patch for this revision.')
patch = package / 'patches' / patches[head]
subprocess.run(['git', 'apply', '--check', str(patch)], cwd=repo, check=True)
if args.check_only:
    print('Patch applies cleanly:', patch.name)
else:
    subprocess.run(['git', 'apply', str(patch)], cwd=repo, check=True)
    print('Applied:', patch.name)
    print('Run scripts/check.py with the same repository path.')
