#!/usr/bin/env python3
"""Build the proposal and exact public statement checks in a prepared ProveIt checkout."""
import argparse
import os
import pathlib
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repo', type=pathlib.Path)
args = parser.parse_args()
repo = args.repo.resolve()
source = repo / 'Logic/PeanoArithmetic/FlexibleOutput/Lean/PAFlexibleOutput'
modules = ['PAFlexibleOutput.PaddedInduction', 'PAFlexibleOutput.Halting',
           'PAFlexibleOutput.Functionality']
if (source / 'Provability.lean').exists():
    modules.append('PAFlexibleOutput.Provability')
modules += ['PAFlexibleOutput.Refutations', 'PAFlexibleOutput.Search',
            'PAFlexibleOutput.Main', 'PAFlexibleOutput',
            'PAFlexibleOutput.ExactStatements', 'PAFlexibleOutput.LegacyRefutations']
env = os.environ.copy()
env['LAKE_JOBS'] = '1'
env['LEAN_NUM_THREADS'] = '2'
for module in modules:
    print('Building', module, flush=True)
    subprocess.run(['lake', 'build', '+' + module], cwd=repo, env=env, check=True)
print('All targets passed. Audit axioms are printed by the Lean sources.')
