Validation used the official Lean 4.32.0 toolchain and cached Foundation/Mathlib
artifacts, with each project module rebuilt into a fresh, task-local output
directory. No stale PAFlexibleOutput modules were made available as fallback.

The host's PID namespace caused the compiler's exact /proc/<getpid()>/exe
readlink lookup to fail even though /proc/self/exe was available. The included
proc_self_exe_compat.c retries only that failed identity lookup through its
self alias. It forwards successful calls and all other paths unchanged.

The official compiler/kernel binary was not modified. This workaround concerns
startup path discovery, not elaboration, proof checking, or filesystem access
permissions. Normal Lean installations should use the supplied Lake commands
without this shim.

Compile logs and command arrays retain the actual host paths for audit. The
portable scripts/check.py uses the ordinary lake command on the user's system.
