import PAFlexibleOutput.Main
import Lean

open Lean Elab Command

set_option maxRecDepth 100000
set_option maxHeartbeats 0

/- A syntactic dependency closure, including types, values and inductive constructors.
   This is distinct from the import closure. No simplifier or proof-search tactic runs. -/
run_cmd do
  let env ← getEnv
  let root := ``PAFlexibleOutput.flexibleOutput
  let mut pending : List Name := [root]
  let mut seen : NameSet := {}
  let mut records : Array Json := #[]
  let mut unavailable : Array Name := #[]
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    if seen.contains name then continue
    seen := seen.insert name
    match env.checked.get.find? name with
    | none => unavailable := unavailable.push name
    | some ci =>
      let value := ci.value? true
      let mut refs := ci.type.getUsedConstants
      if let some expression := value then
        refs := refs ++ expression.getUsedConstants
      if let .inductInfo iv := ci then
        refs := refs ++ iv.ctors.toArray
      pending := refs.toList ++ pending
      let origin := match env.getModuleIdxFor? name with
        | some index => env.header.moduleNames.getD index.toNat .anonymous
        | none => env.mainModule
      let typeObjects ← liftIO ci.type.numObjs
      let valueObjects ← match value with
        | some expression => liftIO expression.numObjs
        | none => pure 0
      records := records.push <| Json.mkObj [
        ("name", toJson name.toString),
        ("module", toJson origin.toString),
        ("type_nodes", toJson ci.type.sizeWithoutSharing),
        ("value_nodes", toJson ((value.map Expr.sizeWithoutSharing).getD 0)),
        ("type_objects", toJson typeObjects),
        ("value_objects", toJson valueObjects),
        ("type_hash", toJson (toString (hash ci.type))),
        ("value_hash", toJson ((value.map (fun e => toString (hash e))).getD "none")),
        ("is_axiom", toJson ci.isAxiom)]
  let result := Json.mkObj [
    ("root", toJson root.toString),
    ("count", toJson records.size),
    ("missing", toJson (unavailable.map Name.toString)),
    ("declarations", Json.arr records)]
  let target ← liftIO <| IO.getEnv "AUDIT_OUTPUT"
  let filename := target.getD "dependency-audit.json"
  liftIO <| IO.FS.writeFile filename (result.pretty ++ "\n")
  logInfo m!"Dependency audit: {records.size} declarations, {unavailable.size} missing; wrote {filename}"

#print axioms PAFlexibleOutput.flexibleOutput
#print axioms PAFlexibleOutput.flexibleOutput_satisfiable
#print axioms PAFlexibleOutput.exists_partrec_flexibleOutput
