import PAFlexibleOutput.Refutations
import Foundation.FirstOrder.Incompleteness.InductionSchemeDelta1

/-! Optional compatibility for clients of the former PA-specific internal
arithmetization lemma. The main proof does not import this module. -/

set_option autoImplicit false
namespace PAFlexibleOutput
open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic
open Bootstrapping Bootstrapping.Arithmetic

/-- The original internal PA predicate, retained for explicit legacy imports. -/
lemma refutation_sigma1 : 𝚺₁-Relation₃ fun c x y : ℕ ↦
    Bootstrapping.Provable 𝗣𝗔 (neg ℒₒᵣ <| subst ℒₒᵣ
      ?[numeral y, numeral c, numeral x] (⌜universalGraph⌝ : ℕ)) := by
  definability

#print axioms refutation_sigma1
end PAFlexibleOutput
