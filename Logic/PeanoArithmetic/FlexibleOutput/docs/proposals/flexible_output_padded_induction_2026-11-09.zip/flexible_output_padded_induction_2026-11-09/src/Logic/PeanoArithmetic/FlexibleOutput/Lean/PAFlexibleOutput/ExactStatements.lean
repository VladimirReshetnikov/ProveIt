import PAFlexibleOutput.Main

/-! Exact public statement checks; these use the original definitions. -/
set_option autoImplicit false
namespace PAFlexibleOutput
open LO LO.Entailment LO.FirstOrder LO.FirstOrder.Arithmetic

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧ ∀ (x : ℕ) (o : Option ℕ),
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e x o :=
  flexibleOutput

example :
    ∃ e : Code, (∀ x, Nat.Partrec.Code.eval e x = Part.none) ∧
      ∀ x n : ℕ, Satisfiable (insert (haltSentence e x n) 𝗣𝗔) :=
  flexibleOutput_satisfiable

example :
    ∃ f : ℕ →. ℕ, Partrec f ∧ ∃ e : Code, Nat.Partrec.Code.eval e = f ∧ ∀ o : Option ℕ,
      ∃ (M : Type) (_ : ORingStructure M) (_ : M↓[ℒₒᵣ] ⊧* 𝗣𝗔), ValueIn M e 0 o :=
  exists_partrec_flexibleOutput

example : REPred fun p : (Code × ℕ) × ℕ => 𝗣𝗔 ⊢ ∼haltSentence p.1.1 p.1.2 p.2 :=
  refutationsRE

#print axioms flexibleOutput
#print axioms flexibleOutput_satisfiable
#print axioms exists_partrec_flexibleOutput
#print axioms Padded.provable_iff
#print axioms Padded.paDelta1
end PAFlexibleOutput
