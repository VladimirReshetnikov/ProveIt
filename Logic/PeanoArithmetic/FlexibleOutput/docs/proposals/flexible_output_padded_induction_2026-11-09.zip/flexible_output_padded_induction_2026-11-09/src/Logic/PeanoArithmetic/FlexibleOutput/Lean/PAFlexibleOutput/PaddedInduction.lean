module

public import Foundation.FirstOrder.Bootstrapping.Syntax.Theory
public import Foundation.FirstOrder.Arithmetic.Basic.Model

/-!
# A decidable presentation of PA with padded induction axioms

The axiom recognizer allows redundant closing universal quantifiers. It checks
that opening the body with fresh free variables gives a successor-induction
instance, but does not recover the least possible number of closing quantifiers.
The resulting theory has exactly the same models and theorems as PA.

The coding constructions below are adapted from `InductionSchemeDelta1`.
The syntactic canonical-closure inversion, exact bound-depth invariant, and
Sigma-one formula classifier are unnecessary for this presentation.
-/

@[expose] public section

namespace LO.FirstOrder.Arithmetic.Padded

open LO.FirstOrder.Theory Bootstrapping

variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]

/-! ## Iterated quantifiers and quotation -/

section qqAlls

def qqAlls.blueprint : PR.Blueprint 1 where
  zero := .mkSigma “y x. y = x”
  succ := .mkSigma “y ih n x. !qqAllDef y ih”

noncomputable def qqAlls.construction : PR.Construction V qqAlls.blueprint where
  zero := fun x ↦ x 0
  succ := fun _ _ ih ↦ ^∀ ih
  zero_defined := .mk fun v ↦ by simp [blueprint]
  succ_defined := .mk fun v ↦ by simp [blueprint, qqAll]

noncomputable def qqAlls (p k : V) : V := qqAlls.construction.result ![p] k

@[simp] lemma qqAlls_zero (p : V) : qqAlls p 0 = p := by simp [qqAlls, qqAlls.construction]

@[simp] lemma qqAlls_succ (p k : V) : qqAlls p (k + 1) = ^∀ (qqAlls p k) := by
  simp [qqAlls, qqAlls.construction]

section

def qqAllsDef : 𝚺₁.Semisentence 3 :=
  qqAlls.blueprint.resultDef |>.rew (Rew.subst ![#0, #2, #1])

instance qqAlls_defined : 𝚺₁-Function₂ (qqAlls : V → V → V) via qqAllsDef := .mk
  fun v ↦ by simp [qqAlls.construction.result_defined_iff, qqAllsDef]; rfl

instance qqAlls_definable : 𝚺₁-Function₂ (qqAlls : V → V → V) := qqAlls_defined.to_definable

instance qqAlls_definable' (Γ) : Γ-[m + 1]-Function₂ (qqAlls : V → V → V) := qqAlls_definable.of_sigmaOne

end

variable {L : Language} [L.Encodable] [L.LORDefinable]

lemma le_qqAll (p : V) : p ≤ ^∀ p := by
  simp only [qqAll]; exact le_trans (le_pair_right _ _) le_self_add

lemma qqAlls_all (p k : V) : qqAlls (^∀ p) k = ^∀ (qqAlls p k) := by
  induction k using ISigma1.sigma1_succ_induction
  · definability
  case zero => simp
  case succ k ih => rw [qqAlls_succ, ih, qqAlls_succ]

lemma qqAlls_succ' (p k : V) : qqAlls p (k + 1) = qqAlls (^∀ p) k := by
  rw [qqAlls_succ, qqAlls_all]

@[simp] lemma le_qqAlls (p k : V) : p ≤ qqAlls p k := by
  induction k using ISigma1.sigma1_succ_induction
  · definability
  case zero => simp
  case succ k ih =>
    refine le_trans ih ?_
    rw [qqAlls_succ]
    exact le_qqAll _

lemma succ_le_qqAll (p : V) : p + 1 ≤ ^∀ p := by
  simp only [qqAll]; exact add_le_add (le_pair_right _ _) (le_refl 1)

@[simp] lemma index_le_qqAlls (p k : V) : k ≤ qqAlls p k := by
  induction k using ISigma1.sigma1_succ_induction
  · definability
  case zero => simp
  case succ k ih =>
    rw [qqAlls_succ]
    exact le_trans (add_le_add ih (le_refl 1)) (succ_le_qqAll _)

lemma quote_allClosure {n : ℕ} (φ : _root_.LO.FirstOrder.Semiformula L ℕ n) :
    (⌜(∀⁰* φ : _root_.LO.FirstOrder.Semiformula L ℕ 0)⌝ : V) = qqAlls (⌜φ⌝ : V) (n : V) := by
  induction n
  case zero => simp
  case succ n ih =>
    rw [show (∀⁰* φ : _root_.LO.FirstOrder.Semiformula L ℕ 0) = ∀⁰* (∀⁰ φ) from rfl]
    have := ih (∀⁰ φ)
    rw [Semiformula.quote_all] at this
    rw [this, Nat.cast_succ, qqAlls_succ']

lemma quote_univCl (ψ : _root_.LO.FirstOrder.Semiformula L ℕ 0) :
    (⌜Semiformula.univCl ψ⌝ : V) = (⌜Semiformula.univCl' ψ⌝ : V) := by
  show (⌜(Rewriting.emb (Semiformula.univCl ψ) : _root_.LO.FirstOrder.Semiformula L ℕ 0)⌝ : V) = ⌜Semiformula.univCl' ψ⌝
  congr 1
  simp [Semiformula.univCl]

lemma quote_univCl' (ψ : _root_.LO.FirstOrder.Semiformula L ℕ 0) :
    (⌜Semiformula.univCl' ψ⌝ : V)
      = qqAlls (⌜(Rew.fixitr 0 ψ.fvSup ▹ ψ : _root_.LO.FirstOrder.Semiformula L ℕ (0 + ψ.fvSup))⌝ : V)
          ((0 + ψ.fvSup : ℕ) : V) := by
  rw [Semiformula.univCl']; exact quote_allClosure _

lemma quote_univCl_eq (ψ : _root_.LO.FirstOrder.Semiformula L ℕ 0) :
    (⌜Semiformula.univCl ψ⌝ : V)
      = qqAlls (⌜(Rew.fixitr 0 ψ.fvSup ▹ ψ : _root_.LO.FirstOrder.Semiformula L ℕ (0 + ψ.fvSup))⌝ : V)
          ((0 + ψ.fvSup : ℕ) : V) := by
  rw [quote_univCl, quote_univCl']

lemma quote_subst_fvar_fixitr (φ : _root_.LO.FirstOrder.Semiformula L ℕ 0) :
    (⌜(Rew.fixitr 0 φ.fvSup ▹ φ : _root_.LO.FirstOrder.Semiformula L ℕ (0 + φ.fvSup))
        ⇜ (fun x : Fin (0 + φ.fvSup) ↦ (&↑x : SyntacticTerm L))⌝ : V) = ⌜φ⌝ := by
  rw [show (Rew.fixitr 0 φ.fvSup ▹ φ : _root_.LO.FirstOrder.Semiformula L ℕ (0 + φ.fvSup))
        ⇜ (fun x : Fin (0 + φ.fvSup) ↦ (&↑x : SyntacticTerm L)) = φ from by
    have := Semiformula.subst_comp_fixitr (L := L) φ
    convert this using 2]

end qqAlls

/-! ## Opening a quantified body with free variables -/

section fvarVec

def fvarVec.blueprint : PR.Blueprint 0 where
  zero := .mkSigma “y. y = 0”
  succ := .mkSigma “y ih n. ∃ f, !qqFvarDef f n ∧ !concatDef y ih f”

noncomputable def fvarVec.construction : PR.Construction V fvarVec.blueprint where
  zero := fun _ ↦ 0
  succ := fun _ n ih ↦ concat ih (^&n)
  zero_defined := .mk fun v ↦ by simp [blueprint]
  succ_defined := .mk fun v ↦ by simp [blueprint]

noncomputable def fvarVec (k : V) : V := fvarVec.construction.result ![] k

@[simp] lemma fvarVec_zero : fvarVec (0 : V) = 0 := by simp [fvarVec, fvarVec.construction]

@[simp] lemma fvarVec_succ (k : V) : fvarVec (k + 1) = concat (fvarVec k) (^&k) := by
  simp [fvarVec, fvarVec.construction]

def fvarVecDef : 𝚺₁.Semisentence 2 := fvarVec.blueprint.resultDef

instance fvarVec_defined : 𝚺₁-Function₁ (fvarVec : V → V) via fvarVecDef := .mk
  fun v ↦ by simp [fvarVec.construction.result_defined_iff, fvarVecDef]; rfl

instance fvarVec_definable : 𝚺₁-Function₁ (fvarVec : V → V) := fvarVec_defined.to_definable

instance fvarVec_definable' (Γ) : Γ-[m + 1]-Function₁ (fvarVec : V → V) := fvarVec_definable.of_sigmaOne

@[simp] lemma len_fvarVec (k : V) : len (fvarVec k) = k := by
  induction k using ISigma1.sigma1_succ_induction
  · definability
  case zero => simp
  case succ k ih => simp [ih]

lemma nth_fvarVec (k : V) : ∀ i < k, (fvarVec k).[i] = ^&i := by
  induction k using ISigma1.sigma1_succ_induction
  · definability
  case zero => simp
  case succ k ih =>
    intro i hi
    rcases (lt_succ_iff_le.mp hi).lt_or_eq with hlt | rfl
    · rw [fvarVec_succ, concat_nth_lt _ _ (by simpa using hlt)]; exact ih i hlt
    · rw [fvarVec_succ, concat_nth_len' _ _ (by simp)]

lemma fvarVec_val_eq (m : ℕ) :
    fvarVec ((m : ℕ) : V)
      = SemitermVec.val (fun i : Fin m ↦ (Bootstrapping.Semiterm.fvar (↑(i : ℕ)) : Bootstrapping.Semiterm V ℒₒᵣ 0)) := by
  apply nth_ext (by simp)
  intro i hi
  rw [len_fvarVec] at hi
  obtain ⟨j, rfl⟩ := eq_nat_of_lt_nat hi
  have hj : j < m := by exact_mod_cast hi
  rw [nth_fvarVec _ _ hi, show ((j : ℕ) : V) = ((⟨j, hj⟩ : Fin m) : ℕ) from rfl]
  rw [SemitermVec.val_nth_eq (fun i : Fin m ↦ (Bootstrapping.Semiterm.fvar (↑(i : ℕ)) : Bootstrapping.Semiterm V ℒₒᵣ 0)) ⟨j, hj⟩]
  simp

lemma subst_fvarVec_quote (φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 0) :
    Bootstrapping.subst ℒₒᵣ (fvarVec ((0 + φ.fvSup : ℕ) : V))
        (⌜(Rew.fixitr 0 φ.fvSup ▹ φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + φ.fvSup))⌝ : V)
      = (⌜φ⌝ : V) := by
  set Kt : Bootstrapping.Semiformula V ℒₒᵣ (0 + φ.fvSup) :=
    ⌜(Rew.fixitr 0 φ.fvSup ▹ φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + φ.fvSup))⌝ with hKt
  set w : SemitermVec V ℒₒᵣ (0 + φ.fvSup) 0 :=
    (fun i : Fin (0 + φ.fvSup) ↦ (Bootstrapping.Semiterm.fvar (↑(i : ℕ)) : Bootstrapping.Semiterm V ℒₒᵣ 0)) with hw
  rw [fvarVec_val_eq,
    show (⌜(Rew.fixitr 0 φ.fvSup ▹ φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ (0 + φ.fvSup))⌝ : V) = Kt.val from rfl,
    show Bootstrapping.subst ℒₒᵣ w.val Kt.val = (Kt.subst w).val from rfl,
    ← quote_subst_fvar_fixitr (V := V) φ]
  congr 1
  rw [hKt]
  simp only [FirstOrder.Semiformula.typed_quote_substs, hw, Semiterm.typed_quote_fvar]

lemma subst_fvarVec_quote' {m : ℕ} (β : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ m) :
    Bootstrapping.subst ℒₒᵣ (fvarVec ((m : ℕ) : V)) (⌜β⌝ : V)
      = (⌜(β ⇜ (fun i : Fin m ↦ (&↑i : SyntacticTerm ℒₒᵣ)))⌝ : V) := by
  set Kt : Bootstrapping.Semiformula V ℒₒᵣ m := ⌜β⌝ with hKt
  set w : SemitermVec V ℒₒᵣ m 0 :=
    (fun i : Fin m ↦ (Bootstrapping.Semiterm.fvar (↑(i : ℕ)) : Bootstrapping.Semiterm V ℒₒᵣ 0)) with hw
  rw [fvarVec_val_eq,
    show (⌜β⌝ : V) = Kt.val from rfl,
    show Bootstrapping.subst ℒₒᵣ w.val Kt.val = (Kt.subst w).val from rfl]
  rw [show (⌜(β ⇜ (fun i : Fin m ↦ (&↑i : SyntacticTerm ℒₒᵣ)))⌝ : V)
      = (⌜(β ⇜ (fun i : Fin m ↦ (&↑i : SyntacticTerm ℒₒᵣ)))⌝ : Bootstrapping.Semiformula V ℒₒᵣ 0).val from rfl]
  congr 1
  rw [hKt]
  simp only [FirstOrder.Semiformula.typed_quote_substs, hw, Semiterm.typed_quote_fvar]

end fvarVec
/-! ## Recognizing the successor-induction body -/

section succInd

lemma typed_quote_succInd (φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 1) :
    (⌜succInd φ⌝ : Bootstrapping.Semiformula V ℒₒᵣ 0) =
      (⌜φ ⇜ (![‘0’] : Fin 1 → ArithmeticSemiterm ℕ 0)⌝)
        🡒 ((∀⁰ (⌜φ⌝ 🡒 ⌜φ ⇜ (![‘#0 + 1’] : Fin 1 → ArithmeticSemiterm ℕ 1)⌝)) 🡒 ∀⁰ ⌜φ⌝) := by
  unfold succInd
  rw [show φ ⇜ (![#0] : Fin 1 → ArithmeticSemiterm ℕ 1) = φ from by simp]
  simp

noncomputable def indBody (K : Bootstrapping.Semiformula V ℒₒᵣ 1) : Bootstrapping.Semiformula V ℒₒᵣ 0 :=
  (K.subst ![⌜(‘0’ : ArithmeticSemiterm ℕ 0)⌝])
    🡒 ((∀⁰ (K 🡒 K.subst ![⌜(‘#0 + 1’ : ArithmeticSemiterm ℕ 1)⌝])) 🡒 ∀⁰ K)

lemma indBody_quote (φ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 1) :
    indBody (⌜φ⌝ : Bootstrapping.Semiformula V ℒₒᵣ 1) = ⌜succInd φ⌝ := by
  rw [typed_quote_succInd]; unfold indBody; simp [Matrix.constant_eq_singleton]

noncomputable def indBodyVal (k : V) : V :=
  Bootstrapping.imp ℒₒᵣ
    (Bootstrapping.subst ℒₒᵣ
      (Bootstrapping.SemitermVec.val (![⌜(‘0’ : ArithmeticSemiterm ℕ 0)⌝] : Bootstrapping.SemitermVec V ℒₒᵣ 1 0)) k)
    (Bootstrapping.imp ℒₒᵣ
      (Bootstrapping.qqAll (Bootstrapping.imp ℒₒᵣ k
        (Bootstrapping.subst ℒₒᵣ
          (Bootstrapping.SemitermVec.val (![⌜(‘#0 + 1’ : ArithmeticSemiterm ℕ 1)⌝] : Bootstrapping.SemitermVec V ℒₒᵣ 1 1)) k)))
      (Bootstrapping.qqAll k))

lemma indBodyVal_eq (K : Bootstrapping.Semiformula V ℒₒᵣ 1) : indBodyVal K.val = (indBody K).val := by
  simp only [indBodyVal, indBody, Bootstrapping.Semiformula.val_imp, Bootstrapping.Semiformula.val_all,
    Bootstrapping.Semiformula.val_substs]

lemma le_indBodyVal (k : V) : k ≤ indBodyVal k := by
  unfold indBodyVal Bootstrapping.imp
  exact (le_qqAll _).trans
    (le_of_lt ((Bootstrapping.lt_or_right _ _).trans (Bootstrapping.lt_or_right _ _)))

lemma indBodyVal_quote (γ : _root_.LO.FirstOrder.ArithmeticSemiformula ℕ 1) : indBodyVal (⌜γ⌝ : ℕ) = (⌜succInd γ⌝ : ℕ) := by
  rw [show (⌜γ⌝ : ℕ) = (⌜γ⌝ : Bootstrapping.Semiformula ℕ ℒₒᵣ 1).val from rfl, indBodyVal_eq,
    indBody_quote]
  rfl

def indSubstConst0 : ℕ :=
  Matrix.vecToNat fun i : Fin 1 ↦ Encodable.encode ((![(‘0’ : ArithmeticSemiterm ℕ 0)]) i)

def indSubstConst1 : ℕ :=
  Matrix.vecToNat fun i : Fin 1 ↦ Encodable.encode ((![(‘#0 + 1’ : ArithmeticSemiterm ℕ 1)]) i)

lemma val_indSubstConst0 :
    (↑indSubstConst0 : V)
      = Bootstrapping.SemitermVec.val (![⌜(‘0’ : ArithmeticSemiterm ℕ 0)⌝] : Bootstrapping.SemitermVec V ℒₒᵣ 1 0) := by
  rw [indSubstConst0, ← LO.FirstOrder.Semiterm.quote_eq_encode' (V := V) (![(‘0’ : ArithmeticSemiterm ℕ 0)])]
  congr 1; funext i; simp [Matrix.cons_val_fin_one]

lemma val_indSubstConst1 :
    (↑indSubstConst1 : V)
      = Bootstrapping.SemitermVec.val (![⌜(‘#0 + 1’ : ArithmeticSemiterm ℕ 1)⌝] : Bootstrapping.SemitermVec V ℒₒᵣ 1 1) := by
  rw [indSubstConst1, ← LO.FirstOrder.Semiterm.quote_eq_encode' (V := V) (![(‘#0 + 1’ : ArithmeticSemiterm ℕ 1)])]
  congr 1; funext i; simp [Matrix.cons_val_fin_one]

noncomputable def indBodyValGraph : 𝚺₁.Semisentence 2 := .mkSigma
  “y k.
    ∃ a, !(Bootstrapping.substsGraph ℒₒᵣ) a ↑indSubstConst0 k ∧
    ∃ s1, !(Bootstrapping.substsGraph ℒₒᵣ) s1 ↑indSubstConst1 k ∧
    ∃ i1, !(Bootstrapping.impGraph ℒₒᵣ) i1 k s1 ∧
    ∃ qa1, !qqAllDef qa1 i1 ∧
    ∃ qak, !qqAllDef qak k ∧
    ∃ i2, !(Bootstrapping.impGraph ℒₒᵣ) i2 qa1 qak ∧
    !(Bootstrapping.impGraph ℒₒᵣ) y a i2”

instance indBodyVal.defined : 𝚺₁-Function₁ (indBodyVal : V → V) via indBodyValGraph := .mk fun v ↦ by
  simp [indBodyValGraph, numeral_eq_natCast, val_indSubstConst0, val_indSubstConst1, indBodyVal]

end succInd

/-- The bound depth is at most `m`; there is no equality pin to the canonical closure. -/
def InductionR (p : V) : Prop :=
  ∃ m ≤ p, ∃ b ≤ p,
    p = qqAlls b m ∧ IsSemiformula ℒₒᵣ m b ∧ shift ℒₒᵣ b = b
    ∧ ∃ K ≤ subst ℒₒᵣ (fvarVec m) b,
        IsSemiformula ℒₒᵣ 1 K ∧ subst ℒₒᵣ (fvarVec m) b = indBodyVal K

noncomputable def ch : 𝚫₁.Semisentence 1 := .mkDelta
  (.mkSigma “p.
    ∃ m < p + 1, ∃ b < p + 1,
      !qqAllsDef p b m ∧ !(Bootstrapping.isSemiformula ℒₒᵣ).sigma m b
      ∧ !(Bootstrapping.shiftGraph ℒₒᵣ) b b
      ∧ ∃ fv, !fvarVecDef fv m ∧ ∃ s, !(Bootstrapping.substsGraph ℒₒᵣ) s fv b
        ∧ ∃ K < s + 1, !(Bootstrapping.isSemiformula ℒₒᵣ).sigma 1 K ∧ !indBodyValGraph s K”)
  (.mkPi “p.
    ∃ m < p + 1, ∃ b < p + 1,
      (∀ y, !qqAllsDef y b m → y = p) ∧ !(Bootstrapping.isSemiformula ℒₒᵣ).pi m b
      ∧ (∀ y, !(Bootstrapping.shiftGraph ℒₒᵣ) y b → y = b)
      ∧ ∀ fv, !fvarVecDef fv m → ∀ s, !(Bootstrapping.substsGraph ℒₒᵣ) s fv b
        → ∃ K < s + 1, !(Bootstrapping.isSemiformula ℒₒᵣ).pi 1 K ∧ ∀ ib, !indBodyValGraph ib K → s = ib”)

instance InductionR.defined : 𝚫₁-Predicate[V] (InductionR : V → Prop) via ch := .mk <| by
  constructor
  · intro v; simp [ch, HierarchySymbol.Semiformula.val_sigma, eq_comm]
  · intro v
    simp [ch, HierarchySymbol.Semiformula.val_sigma, InductionR, lt_succ_iff_le, eq_comm]

/-- A finite formula fixed by the free-variable shift contains no free variables. -/
lemma freeVariables_eq_empty_of_shift {m : ℕ} (β : ArithmeticSemiformula ℕ m)
    (hs : Rewriting.shift β = β) : β.freeVariables = ∅ := by
  have step : ∀ x, β.FVar? x → 1 ≤ x ∧ β.FVar? (x - 1) := by
    intro x hx
    rw [← hs] at hx
    rcases Semiformula.fvar?_rew hx with (⟨i, hi⟩ | ⟨z, hz, hi⟩)
    · simp [Rew.shift_bvar, Semiterm.FVar?] at hi
    · have hxz : x = z + 1 := by
        simpa [Rew.shift_fvar, Semiterm.FVar?, Semiterm.freeVariables_fvar] using hi
      exact ⟨by omega, by rw [hxz]; simpa using hz⟩
  by_contra hne
  classical
  have hn := Finset.nonempty_of_ne_empty hne
  obtain ⟨hge, hp⟩ := step (β.freeVariables.min' hn) (β.freeVariables.min'_mem hn)
  exact absurd (β.freeVariables.min'_le _ hp) (by omega)

/-- Decode a recognized formula without reconstructing its canonical universal closure. -/
lemma decode {φ : ArithmeticSemiformula ℕ 0} (h : InductionR (⌜φ⌝ : ℕ)) :
    ∃ (m : ℕ) (β : ArithmeticSemiformula ℕ m) (γ : ArithmeticSemiformula ℕ 1),
      φ = ∀⁰* β ∧ β.freeVariables = ∅ ∧
        β ⇜ (fun i : Fin m ↦ (&↑i : SyntacticTerm ℒₒᵣ)) = succInd γ := by
  rcases h with ⟨m, -, b, -, hp, hb, hsh, K, -, hK, hsubst⟩
  obtain ⟨γ, rfl⟩ := Bootstrapping.IsSemiformula.sound hK
  obtain ⟨β, rfl⟩ := Bootstrapping.IsSemiformula.sound hb
  refine ⟨m, β, γ, ?_, ?_, ?_⟩
  · apply (Semiformula.quote_inj_iff (L := ℒₒᵣ) (V := ℕ)).mp
    rw [hp, quote_allClosure (V := ℕ) β]; simp
  · apply freeVariables_eq_empty_of_shift β
    apply (Semiformula.quote_inj_iff (L := ℒₒᵣ) (V := ℕ)).mp
    rw [Semiformula.quote_shift (V := ℕ) β]
    exact hsh
  · apply (Semiformula.quote_inj_iff (L := ℒₒᵣ) (V := ℕ)).mp
    have e := subst_fvarVec_quote' (V := ℕ) β
    simp only [natCast_nat] at e
    rw [← e, hsubst, indBodyVal_quote]

/-- Padded induction axioms, presented directly by the code recognizer. -/
def Induction : ArithmeticTheory := {σ | InductionR (⌜σ⌝ : ℕ)}

/-- The recognizer accepts only sentences, even though `mem_iff` tests open propositions. -/
noncomputable instance inductionDelta1 : Induction.Δ₁ where
  ch := ch
  mem_iff φ := by
    have e : (ℕ ⊧/![(⌜φ⌝ : ℕ)] ch.val) ↔ InductionR (⌜φ⌝ : ℕ) := by simp
    rw [e]
    constructor
    · intro h
      obtain ⟨m, β, γ, hφ, hf, -⟩ := decode h
      have hφf : φ.freeVariables = ∅ := by rw [hφ, Semiformula.freeVariables_allClosure, hf]
      refine ⟨φ.toEmpty hφf, ?_, by simp⟩
      change InductionR (⌜φ.toEmpty hφf⌝ : ℕ)
      simpa [Sentence.quote_def] using h
    · rintro ⟨σ, hσ, rfl⟩
      simpa [Induction, Sentence.quote_def] using hσ
  isDelta1 := HierarchySymbol.Semiformula.ProvablyProperOn.ofProperOn.{0} _ fun V _ _ ↦ by
    haveI := InductionR.defined (V := V); simp

/-- Every canonical PA induction axiom is accepted. -/
lemma canonical_mem (ψ : ArithmeticSemiformula ℕ 1) : (succInd ψ).univCl ∈ Induction := by
  change InductionR (⌜(succInd ψ).univCl⌝ : ℕ)
  set χ : ArithmeticSemiformula ℕ 0 := succInd ψ with hχ
  set β : ArithmeticSemiformula ℕ (0 + χ.fvSup) := Rew.fixitr 0 χ.fvSup ▹ χ with hβ
  have hcode : (⌜χ.univCl⌝ : ℕ) = qqAlls (⌜β⌝ : ℕ) (0 + χ.fvSup) := by
    simpa only [natCast_nat] using quote_univCl_eq (V := ℕ) χ
  have hs : subst ℒₒᵣ (fvarVec (0 + χ.fvSup : ℕ)) (⌜β⌝ : ℕ)
      = indBodyVal (⌜ψ⌝ : ℕ) := by
    rw [hβ, indBodyVal_quote]
    simpa only [natCast_nat] using subst_fvarVec_quote (V := ℕ) χ
  have hsemi : IsSemiformula ℒₒᵣ (0 + χ.fvSup : ℕ) (⌜β⌝ : ℕ) := by
    simpa only [natCast_nat] using Semiformula.quote_isSemiformula (V := ℕ) β
  refine ⟨0 + χ.fvSup, ?_, ⌜β⌝, ?_, hcode, hsemi, ?_, ⌜ψ⌝, ?_, by simp, hs⟩
  · rw [hcode]; exact index_le_qqAlls _ _
  · rw [hcode]; exact le_qqAlls _ _
  · have hnf : ∀ x, ¬ β.FVar? x := by
      simpa [hβ, Semiformula.univCl', Semiformula.FVar?, Finset.eq_empty_iff_forall_notMem]
        using Semiformula.fvarList_univCl' χ
    have hshift : Rewriting.shift β = β :=
      Semiformula.rew_eq_self_of (by simp) (fun x hx ↦ absurd hx (hnf x))
    rw [← Semiformula.quote_shift (V := ℕ) β, hshift]
  · rw [hs]; exact le_indBodyVal _

/-- PA with a syntactically more permissive induction presentation. -/
def PA : ArithmeticTheory := 𝗣𝗔⁻ ∪ Induction

noncomputable instance paDelta1 : PA.Δ₁ :=
  Theory.Δ₁.add (Theory.Δ₁.ofFinite _ PeanoMinus.finite) inductionDelta1

lemma pa_subset : 𝗣𝗔 ⊆ PA := by
  rintro σ (h | ⟨ψ, -, rfl⟩)
  · exact Or.inl h
  · exact Or.inr (canonical_mem ψ)

instance eqPeano : 𝗘𝗤 ℒₒᵣ ⪯ 𝗣𝗔 :=
  Entailment.WeakerThan.trans (𝓣 := 𝗣𝗔⁻) inferInstance inferInstance

instance paMinus_le : 𝗣𝗔⁻ ⪯ PA :=
  Entailment.WeakerThan.ofSubset Set.subset_union_left

instance eqPadded : 𝗘𝗤 ℒₒᵣ ⪯ PA :=
  Entailment.WeakerThan.trans (𝓣 := 𝗣𝗔⁻) inferInstance inferInstance

/-- Opening the body preserves its truth under arbitrary bound assignments. -/
lemma eval_of_induction {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔]
    {m : ℕ} {β : ArithmeticSemiformula ℕ m} {γ : ArithmeticSemiformula ℕ 1}
    (hf : β.freeVariables = ∅)
    (he : β ⇜ (fun i : Fin m ↦ (&↑i : SyntacticTerm ℒₒᵣ)) = succInd γ)
    (a : Fin m → M) (f : ℕ → M) : β.Eval a f := by
  let g : ℕ → M := fun i ↦ if h : i < m then a ⟨i, h⟩ else 0
  have hγ : M↓[ℒₒᵣ] ⊧ (succInd γ).univCl :=
    Theory.models (T := 𝗣𝗔) M (Or.inr ⟨γ, trivial, rfl⟩)
  have hs : (succInd γ).Evalf g := (models_iff_proposition.mp hγ) g
  have hb : β.Eval a g := by
    rw [← he] at hs
    simpa [Semiformula.eval_substs, Function.comp_def, g] using hs
  exact (Semiformula.eval_iff_of_funEqOn β (fun x hx ↦ by
    simp [Semiformula.FVar?, hf] at hx)).mp hb

/-- All added padded axioms already hold in every PA model. -/
lemma models_induction {M : Type*} [ORingStructure M] [M↓[ℒₒᵣ] ⊧* 𝗣𝗔] :
    M↓[ℒₒᵣ] ⊧* Induction := by
  rw [models_theory_iff]
  intro σ hσ
  have h : InductionR (⌜(Rewriting.emb σ : ArithmeticSemiformula ℕ 0)⌝ : ℕ) := by
    simpa [Induction, Sentence.quote_def] using hσ
  obtain ⟨m, β, γ, he, hf, hi⟩ := decode h
  have hs : (Rewriting.emb σ : ArithmeticSemiformula ℕ 0).Evalf (fun _ : ℕ ↦ (0 : M)) := by
    rw [he, Semiformula.eval_allClosure]
    exact fun a ↦ eval_of_induction hf hi a _
  simpa [models_iff] using hs

/-- Padding changes the axiom presentation, but preserves the exact class of PA models. -/
theorem models_iff {M : Type*} [ORingStructure M] :
    M↓[ℒₒᵣ] ⊧* PA ↔ M↓[ℒₒᵣ] ⊧* 𝗣𝗔 := by
  constructor
  · exact fun h ↦ models_of_ss h pa_subset
  · intro h
    letI := h
    have hminus : M↓[ℒₒᵣ] ⊧* 𝗣𝗔⁻ := models_of_ss h Set.subset_union_left
    have hi : M↓[ℒₒᵣ] ⊧* Induction := models_induction
    simpa [PA] using And.intro hminus hi

/-- Completeness converts model equivalence to equality of theorem sets. -/
theorem provable_iff (σ : ArithmeticSentence) : PA ⊢ σ ↔ 𝗣𝗔 ⊢ σ := by
  constructor
  · intro h
    apply Arithmetic.complete.{0} 𝗣𝗔 σ
    intro M _ hM
    exact models_of_provable (models_iff.mpr hM) h
  · intro h
    apply Arithmetic.complete.{0} PA σ
    intro M _ hM
    exact models_of_provable (models_iff.mp hM) h

#print axioms provable_iff

end LO.FirstOrder.Arithmetic.Padded
