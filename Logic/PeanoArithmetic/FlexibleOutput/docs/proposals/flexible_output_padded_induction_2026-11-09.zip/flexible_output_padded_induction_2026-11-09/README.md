# FlexibleOutput: simplify induction recognition

**Verified proposal:** enumerate proofs in a deductively equivalent presentation of PA whose induction axioms allow redundant closing universal quantifiers. This removes the need to reconstruct the original canonical universal closure. The main theorem and its computation graph keep their original meanings.

Start with `report.pdf` (12 pages). `report.tex` is its complete source. All Lean implementation files, patches, build records, and dependency measurements are included.

## Result

The new `PAFlexibleOutput.PaddedInduction` module proves:

- A Δ₁ axiom predicate for the padded presentation.
- Inclusion of all original PA axioms.
- Equality of the original and padded theories' model classes, including nonstandard models.
- `Padded.PA ⊢ σ ↔ PA ⊢ σ` for every arithmetic sentence.

The refutation-enumerability proof uses that equivalence to recover its **exact original PA statement**. `Halting.lean`, `Functionality.lean`, `Search.lean`, `Main.lean`, and the facade are byte-for-byte unchanged. The existential program witness may change; no identity of old and new witnesses is claimed.

All ten targets in the current integration compiled under Lean 4.32.0. Exact public statement checks and the declaration-dependency audit passed. Axiom reports for the three original conclusions, the presentation equivalence, and the new Δ₁ instance contain only `propext`, `Classical.choice`, and `Quot.sound`.

## Measured reduction

The baseline is the successfully compiled commit `5ad98b5a50c2c5c4193d56d509181334d65d69e8`. The primary patch targets `52a9bb875b6e4026a79c8f53906d71602c11afee`.

| Measure | Baseline | Primary patch |
| --- | ---: | ---: |
| Repository-local modules imported by Main | 139 | 128 |
| Physical source lines in that closure | 42,503 | 39,291 |
| Bytes in that closure | 1,852,032 | 1,697,676 |
| All declarations reachable from flexibleOutput | 16,946 | 16,924 |
| Repository-local reachable declarations | 6,908 | 6,901 |
| Local per-expression object sum | 2,926,490 | 2,908,008 |

The source reduction is **3,212 lines (7.56%)**. The expression-object-sum reduction is **18,482 (0.63%)**. These are different measures. Source counts include the Foundation submodule and exclude external Mathlib/package sources. Object sums count sharing within each expression but do not deduplicate across declarations. They are not memory measurements. No compilation-speed improvement is claimed.

The project-side source portion grows from 376 to 858 lines because the new support is placed locally. The original Foundation development is retained for other users. The proposal shortens the target's required supporting development; it does not claim that the whole repository becomes smaller.

## Six-archive novelty check

All six archives present at the final audited commit were read, including the sixth archive added during this work. Their existing directions include direct diagonal arguments, exact-value search, unary encoding, generic template refutations, and local Lean proof normalization. None changes the induction presentation, permits padded closures, proves model equivalence, and transports proof enumeration through that equivalence.

See `review/novelty_audit.md` and `review/existing_proposals_manifest.json` for exact filenames, hashes, baselines, and the comparison matrix. The claim is nonduplication relative to those six artifacts, not literature-wide priority.

## Apply the patch

Use an initialized checkout with the repository's pinned Foundation submodule and Lake dependencies. The supplied script accepts either supported revision:

```bash
python3 scripts/apply.py /path/to/ProveIt --check-only
python3 scripts/apply.py /path/to/ProveIt
python3 scripts/check.py /path/to/ProveIt
```

The script runs `git apply --check` before applying the selected patch. It neither commits nor pushes. For a different revision, review and adapt the patch.

The primary `patches/current-52a9bb8.patch` updates `Provability.lean` and adds the new support and audit modules. The current revision renamed `Refutations.lean` to `Provability.lean` without updating Main's and the facade's imports. The patch supplies a one-line `Refutations.lean` compatibility import, preserving those files. The unpatched renamed revision is not the successful build baseline used in the measurements.

The alternative `patches/original-5ad98b5.patch` modifies the earlier `Refutations.lean` directly and has no import shim. Both patches were checked with `git apply --check`, applied to clean source snapshots, and compared byte-for-byte with the compiled candidates.

**No Foundation submodule change or Lake configuration change is needed.**

## Public interfaces and compatibility

`refutationsRE`, `flexibleOutput`, `flexibleOutput_satisfiable`, and `exists_partrec_flexibleOutput` retain their exact original types. The existing `universalGraph`, `ValueIn`, standard correctness, and global functionality are retained.

The old implementation-specific `refutation_sigma1` lemma concerns the old internal PA-provability predicate and its original Δ₁ instance. Clients that need that declaration can explicitly import `PAFlexibleOutput.LegacyRefutations`. The main path instead uses `paddedRefutation_sigma1`. The optional legacy import reintroduces the old supporting machinery and is outside the reduced closure measured above.

## Reproduce the accounting

After building:

```bash
python3 scripts/import_metrics.py --repo /path/to/ProveIt --output imports.json
python3 scripts/audit.py /path/to/ProveIt declarations.json
```

The audit traverses types, proof/definition bodies, and inductive constructors starting at `PAFlexibleOutput.flexibleOutput`. It reports no missing declarations for the supplied runs. The baseline and candidate JSON traversals are included, together with comparison scripts.

Use `evidence/current_*` for the **primary current integration**. `evidence/final_*` and `evidence/metrics_summary.json` record the retained earlier-revision alternative; the name reflects their order in the validation workflow. Its source closure is one module and one line smaller because it has no rename shim. Do not mix those datasets.

## Environment and evidence

- Lean: `4.32.0`.
- Mathlib: `81a5d257c8e410db227a6665ed08f64fea08e997`.
- Foundation: `32e1a0956a8622fad067328ca1959729a7634428`.
- All final project targets were rebuilt from the packaged source bytes. Cached external dependency artifacts were reused; the full libraries were not rebuilt in this session.
- The execution host required a narrow executable-path lookup compatibility shim. Its source and explanation are under `evidence/environment/`. It is not needed in a normal Lean installation and does not modify the kernel or compiler binaries.

`evidence/current_results.json` records each command, exit code, duration, source hash, and log path from the actual session. The log files themselves are included under `evidence/logs/`. The original absolute workspace paths are retained as provenance, not as portable commands.

## Contents

- `report.tex`, `report.pdf`: mathematical explanation, measurements, qualifications, and implementation guide.
- `src/`: complete project-side Lean sources for the primary patch.
- `baseline/`: inspected initial sources and environment metadata, including the original Foundation recognizer.
- `patches/`: two mutually exclusive revision-specific patches.
- `scripts/`: application, build, and accounting tools.
- `evidence/`: compile logs, exact statement checks, import/declaration metrics, and patch application results.
- `review/`: novelty audit, archive manifest, independent review, and proof notes.
- `licenses/`, `NOTICE.txt`: attribution and license information for adapted source.
- `SHA256SUMS`: checksums for the packaged files.

The entire deliverable is self-contained as source and evidence. Recompiling Lean still requires the pinned repository dependencies; they are not bundled into this archive.
