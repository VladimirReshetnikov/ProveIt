import IPRADerivations.Core.Powers
import IPRADerivations.Core.Tactic

/-! The uniform amplification identity, with an object-level iteration count. -/
namespace Packet.Affine
open LeanProofs.ConciseIPRA
open LeanProofs.IPRA
open Syn
open scoped Fm
open LeanProofs.ConciseIPRA.PTm (app zero succ)

abbrev seed : PTm 3 := var 2
abbrev tick : PTm 5 := (var 1 : PTm 5) * var 2 + var 3

def carry {n} (j L b x : PTm n) : PTm n :=
  app (recDef seed tick) (Fin.cases j ![L, b, x])

variable {n : Nat} {Γ : List (Fm PTm n)}

@[simp] theorem subst_carry {m : Nat} (σ : Fin n → PTm m) (j L b x : PTm n) :
    Syn.subst σ (carry j L b x) = carry (Syn.subst σ j) (Syn.subst σ L)
      (Syn.subst σ b) (Syn.subst σ x) := by
  unfold carry
  rw [LeanProofs.ConciseIPRA.PTm.subst_app]
  congr 1
  funext i
  fin_cases i <;> rfl

theorem start (L b x : PTm n) : Γ ⊢[PRAAx] carry zero L b x ≐ x :=
  rec_zero seed tick ![L,b,x]

theorem advance (j L b x : PTm n) :
    Γ ⊢[PRAAx] carry (succ j) L b x ≐ carry j L b x * L + b := by
  have h := rec_succ (Γ := Γ) seed tick j ![L,b,x]
  change Γ ⊢[PRAAx] carry (succ j) L b x ≐ Syn.subst (Fin.cases j
    (Fin.cases (carry j L b x) ![L,b,x])) tick at h
  have ev : (Fin.cases j (Fin.cases (carry j L b x) ![L,b,x]) : Fin 5 → PTm n) =
      ![j,carry j L b x,L,b,x] := by
    funext i; fin_cases i <;> rfl
  rw [ev] at h
  simpa [tick] using h

def invariant : Fm PTm 4 :=
  carry (var 0) (var 1) (var 2) (var 3) ≐
  carry (var 0) (var 1) (var 2) zero + pw (var 1) (var 0) * var 3

theorem stepSound (j L b x : PTm n)
    (ih : Γ ⊢[PRAAx] carry j L b x ≐ carry j L b zero + pw L j * x) :
    Γ ⊢[PRAAx] carry (succ j) L b x ≐ carry (succ j) L b zero + pw L (succ j) * x := by
  refine (advance j L b x).eqTrans ?_
  refine (congrAdd (congrMul ih (.eqRefl L)) (.eqRefl b)).eqTrans ?_
  refine Prf.eqTrans ?_ (congrAdd (advance j L b zero).eqSymm
    (congrMul (pw_succ L j).eqSymm (.eqRefl x)))
  ipra_ring

theorem carry_identity : ([] : List (Fm PTm 4)) ⊢[PRAAx] invariant := by
  refine ind invariant trivial ?_ ?_
  · simp only [invariant, Fm.subst_eq, subst_carry, LeanProofs.IPRA.PTm.subst_add,
      LeanProofs.IPRA.PTm.subst_mul, pw, subst_ap2, Syn.subst_var, Syn.inst_zero,
      Syn.inst_one, inst_two, inst_three, LeanProofs.ConciseIPRA.PTm.subst_zero]
    refine (start _ _ _).eqTrans (Prf.eqSymm ?_)
    refine (congrAdd (start _ _ _) (congrMul (pw_zero _) (.eqRefl _))).eqTrans ?_
    exact (zero_add _).eqTrans (one_mul _)
  · simp only [invariant, Fm.subst_eq, subst_carry, LeanProofs.IPRA.PTm.subst_add,
      LeanProofs.IPRA.PTm.subst_mul, pw, subst_ap2, Syn.subst_var, Syn.repl_zero,
      repl_one, repl_two, repl_three, LeanProofs.ConciseIPRA.PTm.subst_zero]
    exact stepSound _ _ _ _ Prf.hyp0

theorem closedCarry : ([] : List (Fm PTm 0)) ⊢[PRAAx] univ 4 invariant :=
  closeUniv 4 carry_identity

#print axioms closedCarry
end Packet.Affine
