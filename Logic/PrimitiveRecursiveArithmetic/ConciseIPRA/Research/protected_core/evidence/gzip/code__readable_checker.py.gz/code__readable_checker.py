from json import load

def check(goal, context=([],), floor=0):

    def opening(tree, image=None, depth=0):
        if isinstance(tree, list):
            return [opening(child, image, depth + 5 - len(tree)) for child in tree]
        if floor <= tree < depth:
            return tree
        return depth % 2 and opening(image, depth=3)
    while opening(goal) not in context:
        major, source, initializer, template = instruction()
        expected = [source, initializer] if source else [template] * 3
        if major == expected and opening(template, initializer) == goal:
            goal = opening(template, source)
        check(major, context, floor)
        if major:
            local = major * 3
        elif initializer:
            counter = source and [source]
            recursive = [source, initializer, template]
            endpoint = opening(template, recursive, 3) if source else initializer
            local = [[counter, initializer, template], endpoint]
        else:
            goal = opening(*goal, template, 2)
            local = goal
        floor -= 1
        image = floor if major or len(goal) % 2 == 0 else 0
        context += (opening(local, image),)
        goal = opening(goal, [floor])
instruction = load(open(0)).pop
check(instruction())
print('ACCEPT')
