import json

def check(goal, context=(0,), floor=0):

    def opening(tree, image=0j, depth=0):
        if isinstance(tree, list):
            return [opening(child, image, depth + 5 - len(tree)) for child in tree]
        if floor <= tree < depth:
            return tree
        return depth % 2 and opening(image, depth=3)
    if opening(goal) in context:
        return
    major, source, initializer, template = instruction()
    expected_major = [source, initializer] if source else [template] * 3
    if major == expected_major and opening(template, initializer) == goal:
        replacement = opening(template, source)
        if replacement:
            goal = replacement
    check(major, context, floor)
    if major:
        hypothesis = major * 3
    elif initializer:
        counter = source and [source]
        recursive = [source, initializer, template]
        endpoint = opening(template, recursive, 3) if source else initializer
        hypothesis = [[counter, initializer, template], endpoint]
    else:
        goal = opening(*goal, template, 2)
        hypothesis = goal
    floor -= 1
    image = floor if major or len(goal) == 2 else 0
    next_goal = opening(goal, [floor])
    next_hypothesis = opening(hypothesis, image)
    check(next_goal, context + (next_hypothesis,), floor)
instruction = json.load(open(0)).pop
check(instruction())
print('ACCEPT')
