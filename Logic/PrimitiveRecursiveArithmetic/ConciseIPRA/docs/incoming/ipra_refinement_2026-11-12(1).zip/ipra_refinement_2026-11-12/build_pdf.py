"""Build the main paper, with a private-format fallback for installed TeX."""
from pathlib import Path
from pdf_build_support import build

ROOT = Path(__file__).resolve().parent

if __name__ == "__main__":
    build(ROOT / "report.tex", ROOT / "report.pdf", ROOT / "evidence/pdf_build.log")
