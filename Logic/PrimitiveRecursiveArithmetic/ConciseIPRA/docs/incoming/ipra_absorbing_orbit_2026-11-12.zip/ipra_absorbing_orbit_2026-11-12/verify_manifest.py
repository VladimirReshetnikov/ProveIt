"""Verify the delivered file bytes without importing a packaged checker."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
failures = []
entries = (root / 'MANIFEST.sha256').read_text().splitlines()
for entry in entries:
    expected, relative = entry.split('  ', 1)
    path = root / relative
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        failures.append(relative)
if failures:
    raise SystemExit('Manifest failures: ' + ', '.join(failures))
print('Verified', len(entries), 'files.')
