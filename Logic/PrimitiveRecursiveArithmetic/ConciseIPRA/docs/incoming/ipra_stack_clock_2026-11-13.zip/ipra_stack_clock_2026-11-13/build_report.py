"""Compile locally, including when installed TeX lacks a format cache.

The private-cache fallback follows the upstream retained-validation helper,
covered by reference/LICENSE-ProveIt.txt. It changes no system configuration.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
env = os.environ.copy()


def locate(name):
    result = subprocess.run(['kpsewhich', name], env=env, text=True,
                            capture_output=True)
    return result.stdout.strip()


if shutil.which('pdftex') is None or shutil.which('kpsewhich') is None:
    raise SystemExit('An installed TeX distribution with pdftex is required.')
if not locate('pdflatex.ini'):
    roots = [p for p in ('/usr/share/texmf', '/usr/share/texlive/texmf-dist')
             if Path(p).is_dir()]
    if roots:
        env['TEXMF'] = '{' + ','.join(roots) + '}'

log_path = ROOT / 'evidence/pdf_build.log'
with log_path.open('w') as log, tempfile.TemporaryDirectory(prefix='ipra-stack-clock-') as folder:
    private = Path(folder)
    fmt = locate('pdflatex.fmt')
    if not fmt:
        subprocess.run(
            ['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
             '-halt-on-error', '-jobname=pdflatex', '-progname=pdflatex',
             '-output-directory=' + str(private), 'pdflatex.ini'],
            cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        fmt = str(private / 'pdflatex.fmt')
    if not locate('pdftex.map'):
        maps = []
        for name in ('cm.map', 'cmextra.map', 'latxfont.map', 'symbols.map', 'lm.map'):
            filename = locate(name)
            if not filename:
                raise SystemExit('Installed font map missing: ' + name)
            maps.append(Path(filename).read_text())
        (private / 'pdftex.map').write_text('\n'.join(maps))
        env['TEXFONTMAPS'] = str(private) + ':' + env.get('TEXFONTMAPS', '')
    for _ in range(2):
        subprocess.run(
            ['pdftex', '-fmt=' + fmt, '-progname=pdflatex',
             '-interaction=nonstopmode', '-halt-on-error',
             '-file-line-error', 'report.tex'], cwd=ROOT, env=env,
            stdout=log, stderr=subprocess.STDOUT, check=True)
print(ROOT / 'report.pdf')
