"""Verify every member listed in the delivered SHA-256 manifest."""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parent

def main():
    entries = 0
    for line in (ROOT / "MANIFEST.sha256").read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = (ROOT / name).resolve()
        if ROOT not in path.parents:
            raise SystemExit("Invalid manifest path: " + name)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit("Hash mismatch: " + name)
        entries += 1
    print(f"Verified {entries} delivered files.")

if __name__ == "__main__":
    main()

