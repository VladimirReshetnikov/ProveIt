"""Build the report with an installed pdfLaTeX, without network access."""
from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
STEM = "ipra_reconstructed_introduction"


def main():
    compiler = shutil.which("pdftex")
    if compiler is None or not shutil.which("kpsewhich"):
        raise SystemExit("An installed pdfTeX/LaTeX distribution is required.")
    build = ROOT / ".build"
    build.mkdir(exist_ok=True)
    env = os.environ.copy()

    def locate(name):
        result = subprocess.run(["kpsewhich", name], env=env, capture_output=True,
                                text=True)
        return result.stdout.strip()

    if not locate("pdflatex.ini"):
        roots = [name for name in ("/usr/share/texmf", "/usr/share/texlive/texmf-dist")
                 if Path(name).is_dir()]
        if roots:
            env["TEXMF"] = "{" + ",".join(roots) + "}"
    fmt = locate("pdflatex.fmt")
    if not fmt:
        result = subprocess.run([compiler, "-ini", "-etex", "-interaction=nonstopmode",
                                 "-halt-on-error", "-jobname=pdflatex",
                                 "-progname=pdflatex", "-output-directory=" + str(build),
                                 "pdflatex.ini"], cwd=ROOT, env=env,
                                capture_output=True, text=True)
        (build / "format.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-7000:])
            raise SystemExit(result.returncode)
        fmt = str(build / "pdflatex.fmt")
    if not locate("pdftex.map"):
        maps = []
        for name in ("cm.map", "cmextra.map", "latxfont.map", "symbols.map", "lm.map"):
            filename = locate(name)
            if not filename:
                raise SystemExit("Installed font map missing: " + name)
            maps.append(Path(filename).read_text())
        (build / "pdftex.map").write_text("\n".join(maps))
        env["TEXFONTMAPS"] = str(build) + ":" + env.get("TEXFONTMAPS", "")
    command = [compiler, "-fmt=" + fmt, "-progname=pdflatex",
               "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory=" + str(build),
               STEM + ".tex"]
    for number in range(3):
        result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
        (build / f"pass{number + 1}.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-7000:])
            raise SystemExit(result.returncode)
    destination = ROOT / (STEM + ".pdf")
    shutil.copy2(build / destination.name, destination)
    print(destination)


if __name__ == "__main__":
    main()
