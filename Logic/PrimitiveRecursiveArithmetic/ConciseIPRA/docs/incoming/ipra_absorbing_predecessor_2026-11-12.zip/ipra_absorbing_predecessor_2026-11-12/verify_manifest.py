"""Verify exact delivered files; run before regenerating evidence."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text())
failures = []
for row in manifest["files"]:
    path = root / row["path"]
    if not path.is_file():
        failures.append({"path": row["path"], "problem": "missing"})
    elif hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
        failures.append({"path": row["path"], "problem": "hash mismatch"})
print(json.dumps({"checked_files": len(manifest["files"]), "failures": failures}, indent=2))
if failures:
    raise SystemExit(1)
