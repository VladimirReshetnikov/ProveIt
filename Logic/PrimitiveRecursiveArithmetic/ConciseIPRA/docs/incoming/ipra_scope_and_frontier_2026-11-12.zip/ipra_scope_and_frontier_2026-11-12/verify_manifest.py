"""Check the exact delivered bytes before rebuilding generated artifacts."""
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parent
failures = []
lines = (root / 'MANIFEST.sha256').read_text().splitlines()
for line in lines:
    digest, relative = line.split('  ', 1)
    path = root / relative
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        failures.append(relative)
if failures:
    print('MISMATCH:', *failures, sep='\n')
    sys.exit(1)
print('Verified', len(lines), 'files.')
