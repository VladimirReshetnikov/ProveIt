"""Context-derived scope for the inherited guarded Eq/D certificate checker.

The public-goal grammar and finite integer/list certificate convention are
inherited from the compact baseline. This module does not validate arbitrary
JSON against that public grammar. In particular, administrative scalar truth
is not a new public arithmetic formula. Run verify.py for the regression
comparison; this module is not a new smaller complexity record.
"""
import json


def check(context, goal):
    # A local proof invocation has no separate scope argument. Exactly one
    # context resource was added for each previously introduced parameter.
    floor = 1 - len(context)

    def opening(tree, image=check, depth=0):
        if tree * 0 != 0:
            return [opening(child, image, depth + 5 - len(tree))
                    for child in tree]
        if floor <= tree < depth:
            return tree
        return depth % 2 and opening(image, depth=3)

    if opening(goal) in context:
        return

    major, source, initializer, template = instruction()
    check(context, major)
    if major:
        hypothesis = major * 3
    elif initializer:
        recursive_term = [source, initializer, template]
        endpoint = (opening(template, recursive_term, 3)
                    if source else initializer)
        hypothesis = [[source and [source], initializer, template], endpoint]
    else:
        goal = opening(*goal, template, 2)
        hypothesis = goal

    # All old-scope checks above have completed. Only now is the fresh
    # parameter admitted by opening. Replacing this two-phase discipline by
    # one inclusive context-length bound is not justified by the invariant.
    floor -= 1
    image = floor if major or 3 % len(goal) else 0
    new_context = context + [opening(hypothesis, image)]

    # The compact baseline evaluates both possible endpoints before choosing.
    # Preserve that validation order, including validation of unused fields.
    source_instance = opening(template, source)
    selected_major = source and [source, initializer] or [template] * 3
    selected = ((major, goal) == (selected_major,
                                  opening(template, initializer)))
    target = (goal, source_instance)[selected]
    check(new_context, opening(target, [floor]))


instruction = json.load(open(0)).pop
check([0], instruction())
print('ACCEPT')
