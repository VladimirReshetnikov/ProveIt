"""Build the report with installed TeX, including installations without formats.

Adapted from the upstream scope_phase helper (MIT-0, retained in reference/).
No download or system configuration change is made.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
REPORT = 'ipra_exact_bindings'
env = os.environ.copy()

def locate(name):
    return subprocess.run(['kpsewhich', name], env=env, text=True,
                          capture_output=True).stdout.strip()

if not locate('pdflatex.ini'):
    roots = [p for p in ('/usr/share/texmf', '/usr/share/texlive/texmf-dist')
             if Path(p).is_dir()]
    if roots:
        env['TEXMF'] = '{' + ','.join(roots) + '}'

with tempfile.TemporaryDirectory(prefix='ipra-binding-tex-') as directory:
    private = Path(directory)
    fmt = locate('pdflatex.fmt')
    if not fmt:
        subprocess.run(['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                        '-halt-on-error', '-jobname=pdflatex', '-progname=pdflatex',
                        '-output-directory=' + str(private), 'pdflatex.ini'],
                       cwd=ROOT, env=env, check=True)
        fmt = str(private / 'pdflatex.fmt')
    if not locate('pdftex.map'):
        maps = []
        for name in ('cm.map', 'cmextra.map', 'latxfont.map', 'symbols.map', 'lm.map'):
            filename = locate(name)
            if not filename:
                raise SystemExit('Installed font map missing: ' + name)
            maps.append(Path(filename).read_text())
        (private / 'pdftex.map').write_text('\n'.join(maps))
        env['TEXFONTMAPS'] = str(private) + ':' + env.get('TEXFONTMAPS', '')
    for _ in range(3):
        subprocess.run(['pdftex', '-fmt=' + fmt, '-progname=pdflatex',
                        '-interaction=nonstopmode', '-halt-on-error',
                        '-output-directory=' + str(private), REPORT + '.tex'],
                       cwd=ROOT, env=env, check=True)
    shutil.copyfile(private / (REPORT + '.pdf'), ROOT / (REPORT + '.pdf'))
    (ROOT / 'evidence').mkdir(exist_ok=True)
    shutil.copyfile(private / (REPORT + '.log'), ROOT / 'evidence/latex.log')
