"""Assemble a self-contained TeX file and optionally compile its PDF."""
from pathlib import Path
import argparse
import re
import subprocess

ROOT = Path(__file__).resolve().parent


def expand(source):
    source = re.sub(r'\\input\{([^}]+)\}',
                    lambda m: expand((ROOT / m.group(1)).read_text()), source)
    return re.sub(r'\\lstinputlisting(?:\[([^]]*)\])?\{([^}]+)\}',
                  lambda m: ('\\begin{lstlisting}[' + (m.group(1) or '') + ']\n'
                             + (ROOT / m.group(2)).read_text()
                             + '\\end{lstlisting}'), source)


def main():
    args = argparse.ArgumentParser()
    args.add_argument('--pdf', action='store_true')
    options = args.parse_args()
    target = ROOT / 'ipra_checked_frontier.tex'
    target.write_text(expand((ROOT / 'sections/main.tex').read_text()))
    if options.pdf:
        from build_pdf import build
        build(target, ROOT / 'ipra_checked_frontier.pdf', ROOT / 'evidence/pdf_build.log')
    print(target.name)


if __name__ == '__main__':
    main()
