"""Reproduce complete-module measurements and the delivered executable checks.

This is untrusted support material. No acceptance checker imports it.
Run with Python 3.12.14 to reproduce the report's exact normalized sizes.
Only the Python standard library is required; no network access is used.
"""

import ast
import concurrent.futures
import gzip
import hashlib
import io
import json
import platform
import subprocess
import sys
import tokenize
from pathlib import Path


ROOT = Path(__file__).resolve().parent
IGNORED_TOKENS = {
    tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE, tokenize.NL,
    tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT,
}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (
            node.body
            and isinstance(node.body[0], ast.Expr)
            and isinstance(node.body[0].value, ast.Constant)
            and isinstance(node.body[0].value.value, str)
        ):
            node.body.pop(0)
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def blob_sha1(raw):
    return hashlib.sha1(
        ("blob " + str(len(raw)) + "\0").encode() + raw
    ).hexdigest()


def measure(relative_path):
    raw = (ROOT / relative_path).read_bytes()
    tree = StripDocstrings().visit(ast.parse(raw))
    normalized = (ast.unparse(tree) + "\n").encode()
    return {
        "path": relative_path,
        "raw_bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob_sha1": blob_sha1(raw),
        "significant_tokens": sum(
            token.type not in IGNORED_TOKENS
            for token in tokenize.generate_tokens(
                io.StringIO(normalized.decode()).readline
            )
        ),
        "ast_nodes": len(list(ast.walk(ast.parse(normalized)))),
        "normalized_bytes": len(normalized),
        "normalized_sha256": hashlib.sha256(normalized).hexdigest(),
        "gzip9_normalized_bytes": len(
            gzip.compress(normalized, compresslevel=9, mtime=0)
        ),
    }


def authenticate_sources():
    provenance = json.loads((ROOT / "controls/PROVENANCE.json").read_text())
    records = provenance["controls"] + provenance["fixtures"]
    for row in records:
        raw = (ROOT / row["local_path"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != row["sha256"]:
            raise ValueError("Frozen source changed: " + row["local_path"])
        if "git_blob_sha1" in row and blob_sha1(raw) != row["git_blob_sha1"]:
            raise ValueError("Git blob mismatch: " + row["local_path"])
    return {
        "checked_files": len(records),
        "exact_git_blobs": sum("git_blob_sha1" in row for row in records),
        "failures": [],
    }


def fixture_tasks():
    expectations = json.loads(
        (ROOT / "validation/expectations.json").read_text()
    )
    profiles = [
        ("code/checker_tokens.py", "global"),
        ("controls/checker_tokens.py", "global"),
        ("code/checker_ast.py", "compact"),
        ("controls/checker_ast.py", "compact"),
        ("code/checker_bytes.py", "compact"),
        ("controls/checker_bytes.py", "compact"),
        ("code/checker_native.py", "native"),
        ("controls/checker_native.py", "native"),
        ("code/checker.py", "native"),
        ("controls/checker.py", "native"),
        ("code/readable_checker.py", "native"),
    ]
    tasks = []
    for program, interface in profiles:
        cases = expectations["global" if interface == "global" else "local"]
        for row in cases:
            expected = row["expected"] if interface == "global" else row[interface]
            for optimized in (False, True):
                tasks.append({
                    "group": "pinned_fixtures",
                    "program": program,
                    "interface": interface,
                    "case": row["name"],
                    "fixture": row["file"],
                    "expected": expected,
                    "optimized": optimized,
                })
    return tasks


def typed_adversarial_tasks():
    good = json.loads(
        (ROOT / "validation/local/computation_zero_local.json").read_text()
    )
    bad_prefixes = {
        "unused_null": None,
        "unused_true": True,
        "unused_false": False,
        "unused_float_zero": 0.0,
        "unused_fraction": -1.5,
        "unused_empty_string": "",
        "unused_digit_string": "0",
        "unused_object": {},
        "unused_nested_null": [0, [None]],
        "unused_nested_boolean": [False],
        "unused_nested_float": [0, [2.0]],
        "unused_nested_object": [{"x": 0}],
    }
    bad_goals = {
        "goal_scalar_zero": 0,
        "goal_null": None,
        "goal_boolean": True,
        "goal_float": 0.0,
        "goal_string": "x",
        "goal_object": {},
        "goal_empty_array": [],
        "goal_public_Q": [0, 0, 0],
        "goal_D_scalar": [0],
        "goal_noncanonical_slot": [1, 1],
        "goal_negative_parameter": [-1, -1],
        "goal_unbound_slot": [3, 3],
        "goal_empty_numerical_array": [[], 0],
    }
    valid_prefixes = {
        "typed_unused_integer": 17,
        "typed_unused_empty_array": [],
        "typed_unused_array": [0, 1, 2],
        "typed_unused_nested_array": [-1000, [0]],
    }
    cases = []
    for name, value in bad_prefixes.items():
        cases.append((name, [value] + good, False, "malformed_prefix"))
    for name, value in bad_goals.items():
        cases.append((name, [value], False, "malformed_goal"))
    for name, value in valid_prefixes.items():
        cases.append((name, [value] + good, True, "typed_unused_prefix"))
    programs = (
        "code/checker.py", "controls/checker.py", "code/readable_checker.py"
    )
    tasks = []
    for name, payload, expected, kind in cases:
        relative = "validation/adversarial/" + name + ".json"
        (ROOT / relative).write_text(json.dumps(payload) + "\n")
        for program in programs:
            for optimized in (False, True):
                tasks.append({
                    "group": "whole_certificate_types",
                    "kind": kind,
                    "program": program,
                    "case": name,
                    "fixture": relative,
                    "expected": expected,
                    "optimized": optimized,
                })
    return tasks


def nontrace_tasks():
    return [
        {
            "group": "nontrace_example",
            "program": program,
            "case": "inert_annotation_at_new_scope",
            "fixture": "validation/nontrace.json",
            "expected": expected,
            "optimized": optimized,
        }
        for program, expected in (
            ("controls/checker_bytes.py", False),
            ("code/checker_bytes.py", True),
        )
        for optimized in (False, True)
    ]


def run_cli(task):
    command = [sys.executable]
    if task["optimized"]:
        command.append("-O")
    command.append(str(ROOT / task["program"]))
    try:
        result = subprocess.run(
            command,
            input=(ROOT / task["fixture"]).read_bytes(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=20,
        )
        accepted = result.returncode == 0 and result.stdout == b"ACCEPT\n"
        diagnostic = result.stderr.decode(errors="replace").splitlines()
        resource_error = any(
            word in result.stderr
            for word in (b"RecursionError", b"MemoryError")
        )
        structural_rejection_needed = (
            task["group"] == "whole_certificate_types"
            and not task["expected"]
        )
        passed = accepted == task["expected"] and not (
            structural_rejection_needed and resource_error
        )
        return {
            **task,
            "accepted": accepted,
            "passed": passed,
            "returncode": result.returncode,
            "diagnostic": diagnostic[-1] if diagnostic else "",
            "resource_error": resource_error,
        }
    except subprocess.TimeoutExpired:
        return {
            **task, "accepted": False, "passed": False, "timeout": True
        }


def gate_oracle():
    def typed(value):
        return type(value) is int or (
            type(value) is list and all(typed(x) for x in value)
        )

    atoms = [
        0, 1, -1, 12345678901234567890, True, False, None, 0.0, -1.5,
        "", "0", "[]", {}, {"x": 0}, [], [0], [[-1]], [True],
    ]
    values = atoms + [[x, y] for x in atoms for y in atoms]
    values += [[x, [y]] for x in atoms for y in atoms]
    allowed = set("[] ,-0123456789")
    failures = [
        index for index, value in enumerate(values)
        # The gate runs on an outer certificate list.  Python str(list)
        # quotes every nested string, whereas str(a_bare_string) would not.
        # Place each test value in that required list context.
        if (not (set(str([value])) - allowed)) != typed(value)
    ]
    return {
        "cases": len(values),
        "failures": failures,
        "purpose": (
            "Compare the lexical gate with an independent exact recursive "
            "integer/list predicate on finite JSON-shaped values, each "
            "placed in an outer certificate list."
        ),
    }


def write_metrics_table(metrics):
    labels = [
        ("controls/checker_tokens.py", "Old token profile"),
        ("code/checker_tokens.py", "Variadic context"),
        ("controls/checker_ast.py", "Old AST profile"),
        ("code/checker_ast.py", "Context first, AST profile"),
        ("controls/checker_bytes.py", "Old byte profile"),
        ("code/checker_bytes.py", "Context first, byte profile"),
        ("controls/checker_native.py", "Old native public-goal check"),
        ("code/checker_native.py", "Context first, native public-goal check"),
        ("controls/checker.py", "Old native with complete type gate"),
        ("code/checker.py", "Recommended checker with complete type gate"),
    ]
    by_path = {row["path"]: row for row in metrics}
    lines = [
        r"\begin{table}[htbp]",
        r"\centering\small",
        r"\begin{tabular}{@{}lrrr@{}}",
        r"\toprule",
        r"Complete module & Tokens & AST nodes & Bytes\\",
        r"\midrule",
    ]
    for index, (path, label) in enumerate(labels):
        if index in (6, 8):
            lines.append(r"\midrule")
        row = by_path[path]
        values = [
            str(row[key])
            for key in ("significant_tokens", "ast_nodes", "normalized_bytes")
        ]
        if path.startswith("code/"):
            values = [r"\textbf{" + value + "}" for value in values]
        lines.append(label + " & " + " & ".join(values) + r"\\")
    lines += [
        r"\bottomrule",
        r"\end{tabular}",
        (
            r"\caption{Complete-module measurements under CPython 3.12.14. "
            r"The first six rows use the guarded compact contract; the next "
            r"two validate native public goals; the last two also enforce "
            r"the integer/list grammar of every certificate field. Each "
            r"row is one actual program.}"
        ),
        r"\label{tab:metrics}",
        r"\end{table}",
        "",
    ]
    (ROOT / "evidence/metrics_table.tex").write_text("\n".join(lines))


def write_validation_summary(report):
    groups = report["groups"]
    pinned = groups["pinned_fixtures"]
    typed = groups["whole_certificate_types"]
    trace = groups["nontrace_example"]
    text = (
        "The offline reproduction executed "
        + str(report["cli_runs"])
        + " standalone checker processes, with "
        + str(report["failures"])
        + " failed expectations. Of these, "
        + str(pinned["runs"])
        + " replay the 21 local-protocol and 21 global-protocol fixtures "
        + "against their applicable candidate and frozen comparison programs; "
        + str(typed["runs"])
        + " check malformed public goals, forbidden types in unused prefixes, "
        + "and permitted integer/list prefixes through the complete type "
        + "gate; and "
        + str(trace["runs"])
        + " check the explicit change in raw trace acceptance. Every CLI "
        + "case is run with ordinary Python and with \\texttt{python -O}. "
        + "The readable expansion is included in the native-interface "
        + "and complete-type checks. An independent recursive type predicate "
        + "also agrees with the lexical gate on "
        + str(report["gate_oracle"]["cases"])
        + " generated finite JSON-shaped values. "
        + "Frozen provenance verification checks "
        + str(report["source_authentication"]["checked_files"])
        + " files, including "
        + str(report["source_authentication"]["exact_git_blobs"])
        + " exact Git blobs.\n\n"
        + "The compact and native fixtures deliberately have different "
        + "expectations for two administrative cases: the native interface "
        + "rejects the unguarded progressive alias and accepts the supplied "
        + "ordinary atomic case introduction. These differences are recorded "
        + "explicitly; the interfaces are not compared as identical raw "
        + "certificate languages.\n"
    )
    (ROOT / "evidence/validation_summary.tex").write_text(text)


def main():
    (ROOT / "evidence").mkdir(exist_ok=True)
    source_authentication = authenticate_sources()
    paths = [
        str(path.relative_to(ROOT))
        for folder in ("code", "controls")
        for path in sorted((ROOT / folder).glob("*.py"))
    ]
    measurements = [measure(path) for path in paths]
    metric_report = {
        "python": sys.version,
        "normalization": (
            "Remove genuine docstrings, ast.unparse, append one LF; "
            "charge the entire acceptance module."
        ),
        "gzip": "Level 9, timestamp zero; informational only.",
        "programs": measurements,
    }
    (ROOT / "evidence/metrics.json").write_text(
        json.dumps(metric_report, indent=2) + "\n"
    )
    write_metrics_table(measurements)

    tasks = fixture_tasks() + typed_adversarial_tasks() + nontrace_tasks()
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        receipts = list(executor.map(run_cli, tasks))
    groups = {
        group: {
            "runs": sum(row["group"] == group for row in receipts),
            "failures": sum(
                row["group"] == group and not row["passed"] for row in receipts
            ),
        }
        for group in (
            "pinned_fixtures", "whole_certificate_types", "nontrace_example"
        )
    }
    oracle = gate_oracle()
    report = {
        "python": sys.version,
        "source_authentication": source_authentication,
        "cli_runs": len(receipts),
        "failures": sum(not row["passed"] for row in receipts),
        "groups": groups,
        "gate_oracle": oracle,
        "receipts": receipts,
        "limits": (
            "Finite executable checks supplement the written metatheorems; "
            "no Lean/Rocq verification of these Python programs is claimed."
        ),
    }
    (ROOT / "evidence/validation.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    write_validation_summary(report)
    print(json.dumps({
        "python": platform.python_version(),
        "measured_modules": len(measurements),
        "cli_runs": report["cli_runs"],
        "failures": report["failures"],
        "groups": groups,
        "gate_oracle_cases": oracle["cases"],
        "gate_oracle_failures": len(oracle["failures"]),
    }, indent=2))
    if report["failures"] or oracle["failures"]:
        for row in receipts:
            if not row["passed"]:
                print(json.dumps(row))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
