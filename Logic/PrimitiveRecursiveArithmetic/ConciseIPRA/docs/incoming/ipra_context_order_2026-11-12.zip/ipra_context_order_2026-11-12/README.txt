CHECKING THE CONTEXT BEFORE THE GOAL
Smaller complete proof checkers for iPRA
Prepared for Vladimir Reshetnikov, November 12, 2026

RESULT
======
The audited compact coordinate envelope is improved from

    256 significant tokens / 276 AST nodes / 506 normalized source bytes

to

    255 significant tokens / 273 AST nodes / 499 normalized source bytes.

These are three separate complete Python modules implementing the same
inherited guarded public theory. No single program has all three numbers.
The matched native public-goal validated checker improves from
333 tokens / 379 AST nodes / 656 bytes to 331 / 376 / 650.

This is a proof-checker implementation reduction, which is the complexity
metric used by the project. The existing logical and arithmetic axioms are
not deleted or replaced. No absolute optimality theorem is claimed.

START HERE
==========
report.pdf is the mathematical report, with the complete native rule
inventory, both interpretation composites, the new preservation argument,
the comparison contracts, executable evidence, and attributed foundational
appendices. report.tex and theory/ are its complete editable LaTeX sources.

For standalone checking, use code/checker.py. It validates the integer/list
grammar of the entire input certificate and the canonical native Eq/D
grammar and scope of the public goal. Its complete size is measured in
evidence/metrics.json and in the report, including those validators.

The three compact programs reproduce the existing benchmark contract:
finite integer/list certificates, canonical closed guarded Eq/D public
goals, and a documented sorted interpretation of administrative aliases.
They do not include a separate general public-goal grammar validator.
Do not compare them to fully validated modules as though the contracts were
identical. code/checker_native.py includes the public-goal validator;
code/checker.py also validates all internal and unused certificate fields.

WHAT CHANGED
============
1. Variadic immutable contexts.
   Passing a retained context as the remaining positional arguments of the
   checking function removes one significant token. Its tuple contents,
   scope changes, instruction consumption, and successful traces are exactly
   those of the pinned predecessor.

2. Context before target.
   Constructing the extended context before the next goal removes the local
   generated-hypothesis binding. A supplied introduction witness and every
   computation-image check still finish before allocating a fresh variable.
   Optional elimination is tested afterward. The new persistence lemma shows
   that an actual matching endpoint cannot acquire a meaningful fresh
   parameter. This preserves the public consequence relation through the
   inherited sorted decoder.

The second change does not preserve the raw accepted certificate language.
One supplied regression proves I(0,1;u.0)=1 and is accepted by the new compact
checker but rejected by the old one because an irrelevant field was opened
at a different scope. This is an extra spelling of a proof of a true theorem.
It is not an additional theorem. The report explains the difference.

MATHEMATICAL STATUS
===================
The ordinary realization is full intuitionistic first-order equality logic
with finite scalar-iterator descriptions, their two computation equations,
literal-equation induction, numerical coverage, and the explicit falsity
bridge 0=S0 -> false. In the native presentation the logical connectives,
coverage, equality laws, and full quantifier-free induction are derived.
The bridge to iPRA has whole numerical domains, actual equality, and identity
graphs x=y for both composite isomorphisms. It includes internal equality
reflection, body extensionality, and primitive-recursion compilation.

These mathematical foundations are inherited and clearly attributed in the
report. The new checker preservation proof is a written metatheoretic proof
supported by executable tests. It is not a new Lean or Rocq verification.
The report also gives concrete obstructions to deleting image validation
and to making every remaining specialization argument automatic.

REPRODUCTION
============
From this directory, with Python 3.12:

    python3 verify_manifest.py
    python3 reproduce.py

Check the delivered manifest before regenerating evidence or rebuilding the
PDF: regenerated files may have different formatting or PDF metadata.

The checkers read JSON from standard input. The final stack element is the
claimed public goal; instruction packets are consumed from the right.
Acceptance means exit status zero and exactly ACCEPT followed by a newline.
Exceptions reject. The existing format allows unused certificate prefixes.

To rebuild the report with TeX Live or another pdfLaTeX installation:

    python3 build_pdf.py

The mathematical termination/correctness statements idealize sufficient
resources. A concrete Python interpreter has finite recursion and memory
limits; no running-time or certificate-length optimality is claimed.

FILE MAP
========
report.tex / report.pdf        Complete paper and its main editable source
CLAIMS.json                   Machine-readable result and limitation summary
theory/                       Mathematical appendices and obstruction proofs
code/                         New standalone checkers and readable expansion
controls/                     Exact pinned comparator source modules
validation/                   Grounded certificates and verification support
evidence/metrics.json          Actual complete-module measurements
evidence/validation.json       Executed verification receipt
evidence/corpus_metrics.json   Pinned corpus census and source hashes
evidence/census_summary.json   Audit scope and observed predecessor minima
notes/                        Detailed independent audit and codec reference
reproduce.py                  Offline checker/measurement verification
build_pdf.py                  Reproducible LaTeX build entry point
verify_manifest.py            Delivered-file integrity verification
MANIFEST.json                 SHA-256 hashes of the delivered files

The archive includes the actual minimum-attaining controls, not duplicate
copies of the entire repository. Repeating the whole historical census
requires retrieving the pinned files listed in evidence/corpus_metrics.json.
Reproducing the delivered improvements and compiling the paper is offline.

PROVENANCE
==========
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 62396b06020f794fa6dc01b4025a6a5db9d4d28a
Directory: Logic/PrimitiveRecursiveArithmetic/ConciseIPRA

All ninety Research package trees were inventoried. The census measured
493 distinct Python source blobs; 415 contain an ACCEPT verdict string and
were screened as acceptance candidates. Paths, raw Git blob identities,
normalized hashes, and measurements are retained. The minima are audited
implementation records, not theoretical lower bounds over every possible
axiomatization or program.

No repository files were modified. Inherited material retains the repository's
MIT No Attribution license, included as LICENSE.txt. New material is supplied
under the same terms.
