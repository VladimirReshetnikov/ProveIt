EXECUTABLE VALIDATION
=====================

Run from the package directory:

    python3 reproduce.py

No network access or third-party Python packages are needed. CPython 3.12.14
reproduces the exact normalization counts in the report. The command verifies
the frozen source hashes, measures all complete acceptance modules, runs each
CLI case with normal Python and python -O, and writes:

    evidence/metrics.json
    evidence/metrics_table.tex
    evidence/validation.json
    evidence/validation_summary.tex

The checker modules never import this harness or these evidence files.

Pinned fixtures
---------------

local/ contains 21 exact upstream fixture blobs for the local-scope protocol.
global/ contains 21 exact upstream blobs for the token profile's global
freshness counter. The two collections are protocol fixtures, not 42 distinct
mathematical theorems. Their full provenance is in controls/PROVENANCE.json.

expectations.json preserves the compact and native outcomes separately. The
full native public-goal validator rejects unguarded_progressive_alias_local,
which the compact arithmetic traversal accepts outside its guarded public
contract. The native interface accepts old_atomic_case_local, whose [] mode
retains ordinary atomic case introduction; the compact fixed selector rejects
that certificate spelling. Both controls and candidates are tested according
to their actual contract.

There are 462 pinned-fixture CLI runs: each applicable program receives its
21 fixtures both normally and with -O. This includes the exact old/new
variadic-context pair and the readable expansion of the native checker.

Complete-certificate types
-------------------------

reproduce.py generates 29 adversarial or positive-control JSON inputs in
adversarial/: 12 forbidden types in unused prefixes, 13 malformed public goals,
and 4 permitted integer/list prefixes. Three programs receive all of them
both normally and with -O, giving 174 CLI runs. A malformed-type rejection
that relies on RecursionError or MemoryError is counted as a test failure.
The readable program uses an independent recursive exact-type test.

The compact lexical gate is also compared with that recursive type predicate
on 666 finite JSON-shaped values, each embedded in the required outer list.
The list context matters because Python str on a bare string does not quote
it. The executable's subsequent pop protocol independently excludes non-list
top-level inputs.

Explicit raw-trace difference
----------------------------

nontrace.json asserts an already provable zero computation. The old 506-byte
compact control rejects its inert future-name annotation; the context-first
499-byte program accepts it. Both outcomes are tested normally and with -O,
giving 4 runs. This example prevents an overclaim: the new construction
preserves public consequences, not every malformed raw acceptance trace.
The native control and native candidate are not the pair used for this test.

Limits
------

The full suite has 640 CLI runs. Its finite examples support implementation
review but cannot prove soundness, completeness, or bi-interpretability.
Those arguments are stated in report.tex with the inherited foundational
sources. No Lean or Rocq verification of the new Python modules is claimed.
