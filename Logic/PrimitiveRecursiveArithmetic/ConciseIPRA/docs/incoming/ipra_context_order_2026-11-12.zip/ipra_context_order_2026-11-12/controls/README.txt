FROZEN COMPARISON PROGRAMS
==========================

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 62396b06020f794fa6dc01b4025a6a5db9d4d28a
Root: Logic/PrimitiveRecursiveArithmetic/ConciseIPRA

Four files are exact upstream blobs, with no whitespace or comment changes:

checker_tokens.py
  Research/kernel_refinement/code/checker_tokens.py
  256 significant tokens / 283 AST nodes / 594 normalized bytes

checker_ast.py
  Research/deterministic_opening/compact/code/ast.py
  263 significant tokens / 276 AST nodes / 580 normalized bytes

checker_bytes.py
  Research/deterministic_introduction/implementation/code/compact_optional.py
  267 significant tokens / 303 AST nodes / 506 normalized bytes

checker_native.py
  Research/deterministic_introduction/implementation/code/native.py
  333 significant tokens / 379 AST nodes / 656 normalized bytes

checker.py is a DERIVED comparison, not an exact upstream copy. It inserts the
same complete-certificate integer/list gate as code/checker.py into the frozen
native source, immediately before obtaining the packet-pop function. Its
complete-module measurement is 352 tokens / 402 AST nodes / 724 bytes.

PROVENANCE.json records the exact upstream paths, commit, Git blob SHA-1
identifiers, and SHA-256 hashes. It also authenticates all 42 copied fixtures.
The offline reproduction checks every recorded hash before running fixtures.
The derived checker is explicitly marked and has its own SHA-256 hash.

The upstream repository contains the underlying mathematical construction.
The new package improves its implementations; it does not claim authorship of
the original arithmetic theory. See the package's attribution and provenance
materials for the sources of the inherited proofs.
