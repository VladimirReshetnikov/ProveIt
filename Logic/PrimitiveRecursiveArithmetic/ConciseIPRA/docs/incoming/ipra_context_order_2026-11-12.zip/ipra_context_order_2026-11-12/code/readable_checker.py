"""Readable standalone checker for the full native Eq/D public interface.

This expands code/checker.py. It includes exact integer/list validation of
the entire certificate, validation of the closed public goal, scope checks,
and the context-first proof protocol. It imports no other package file.

The JSON input is a stack: [instruction, ..., instruction, public_goal].
Instructions are popped from the end and have four fields [major, source,
seed, template]. Unused prefixes are permitted, but are still type checked.
Acceptance is exit status zero and exactly "ACCEPT\n". Exceptions reject.

The full mathematical specification and semantic preservation argument are
in report.pdf. The administrative array encoding has interpreted aliases;
the readable program deliberately retains them rather than silently changing
the proof protocol into a different strictly tagged calculus.
"""

import json


MISSING = object()


def integer_list_tree(value):
    """Exact grammar T ::= integer | [T, ..., T]; booleans are excluded."""
    return type(value) is int or (
        type(value) is list and all(integer_list_tree(child) for child in value)
    )


def check(context, goal, floor=0, validate_public_goal=False):
    """Verify one goal, consuming packets from the shared instruction stack.

    Allocated numerical parameters are the integers floor, ..., -1.
    Protected coordinates for binders are nonnegative. The inherited opener
    uses array arity to track both sort and the number of protected slots.
    Context extension makes a new list, so major proofs cannot leak their
    local hypotheses into the continuation.
    """

    def opening(tree, image=MISSING, depth=0):
        """Open a numerical hole, or check scope when no image is supplied.

        At a meaningful formula position depth is even; at a meaningful
        numerical position it is odd. A numerical substitution image is
        recursively checked at depth three before insertion. This check
        must not be removed: it prevents a witness or update body from
        capturing a not-yet-allocated parameter.
        """
        if type(tree) is list:
            if validate_public_goal and len(tree) not in (1, 2 + depth % 2):
                raise ValueError("Invalid public constructor arity")
            return [
                opening(child, image, depth + 5 - len(tree)) for child in tree
            ]
        if type(tree) is not int:
            raise ValueError("Missing substitution image or invalid tree type")
        public_integer = (
            depth % 2 and (tree == 0 or (tree > 1 and tree % 2 == 1))
        )
        if floor <= tree < depth and (
            not validate_public_goal or public_integer
        ):
            return tree
        if depth % 2 or validate_public_goal:
            if image is MISSING:
                raise ValueError("A numerical coordinate is outside its scope")
            return opening(image, depth=3)
        return 0  # Administrative formula padding denotes truth.

    # Only the externally supplied public goal receives the extra grammar
    # checks. Auxiliary arrays retain the inherited sorted administrative
    # interpretation, which is needed for the compact proof protocol.
    if opening(goal) in context:
        return
    validate_public_goal = False
    major, source, seed, template = instruction()

    # These operations ALL occur at the old floor. In particular, neither
    # the recursive major proof nor an existential introduction witness can
    # use the parameter that this continuation is about to allocate.
    check(context, major, floor)
    if major:
        # A unary D major, tripled, becomes its Q resource. Other decoded
        # major arities produce administrative truth and are harmless here.
        hypothesis = major * 3
    elif seed:
        # Supply one computation equation. The falsy source selects zero
        # computation; a truthy source selects successor computation. The
        # inherited certified-zero construction recovers omitted literal
        # endpoint cases. Computation gives its zero instance as required
        # by the common continuation, not an unproved arithmetic assumption.
        counter = source and [source]
        recursive_term = [source, seed, template]
        endpoint = opening(template, recursive_term, 3) if source else seed
        hypothesis = [[counter, seed, template], endpoint]
    else:
        # In canonical syntax goal=[B]. Starting B at depth two opens its
        # existential x at the supplied witness and keeps y protected.
        # The star call deliberately retains the inherited raw-array
        # aliases and arity errors instead of introducing a new protocol.
        goal = opening(*goal, template, 2)
        hypothesis = goal

    # The two falsy seed fields are intentionally DIFFERENT mode selectors.
    # For an atomic matrix (arity two), seed=0 makes 0==seed true and selects
    # equation progress; seed=[] makes 0==seed false and selects cases.
    # Thus ordinary atomic case introduction is retained in this full native
    # interface. The guarded compact profiles use a different fixed selector.
    use_parameter = bool(major or len(goal) % 2 == seed)

    floor -= 1
    new_hypothesis = opening(hypothesis, floor if use_parameter else 0)
    extended_context = context + [new_hypothesis]

    # CONTEXT-FIRST CHANGE: this optional elimination test is evaluated only
    # after allocating the new scope. For a selected match, old-scope major
    # and target force the decoded template to have no meaningful occurrence
    # of the new parameter. Discarded annotations can change raw acceptance
    # traces; report.pdf proves preservation of public consequences instead
    # of claiming equality of every malformed certificate language.
    expected_major = [source, seed] if source else [template] * 3
    if major == expected_major and opening(template, seed) == goal:
        goal = opening(template, source)

    next_goal = opening(goal, [floor])
    check(extended_context, next_goal, floor)


certificate = json.load(open(0))
if not integer_list_tree(certificate):
    raise ValueError("The complete certificate must be an integer/list tree")
instruction = certificate.pop
check([0], instruction(), validate_public_goal=True)
print("ACCEPT")
