STANDALONE CHECKERS
===================

Run from the package directory, for example:

    python3 code/checker.py < validation/local/computation_zero_local.json

Acceptance means exit status zero and stdout exactly "ACCEPT\n". An
exception rejects the certificate. None of these acceptance programs imports
another file in this archive; their only import is the standard JSON reader.
The complete source of each program, including input and output, is measured.

Recommended interface
---------------------

checker.py checks the full canonical closed Eq/D public goal and the exact
integer/list type grammar of the entire JSON certificate, including unused
prefixes. It uses the context-first local-scope protocol. The matched control
is controls/checker.py, which adds the identical type gate to the pinned
upstream native checker. The gate therefore does not create a hidden advantage
for either implementation.

readable_checker.py expands this recommended interface with descriptive names
and comments. It uses an independent recursive exact-type validator instead
of the compact lexical gate. It is included in the same applicable fixture
and malformed-type checks. This readable expansion is supplementary: it is
not the program whose small size is claimed.

Measured profiles
-----------------

                         Tokens    AST nodes    Normalized bytes
checker_tokens.py          255          283                 592
checker_ast.py             262          273                 572
checker_bytes.py           265          301                 499
checker_native.py          331          376                 650
checker.py                 349          398                 717

These are complete-module counts under CPython 3.12.14 after removing genuine
docstrings and normalizing with ast.unparse plus one final newline. The three
compact coordinate records 255, 273, and 499 belong to DIFFERENT programs.
They are not the size vector of a single program.

The first three programs inherit the finite integer/list certificate contract
and canonical closed guarded Eq/D public-goal contract of their controls.
They do not independently validate the public-goal grammar. The token profile
uses the inherited global freshness counter and its own global fixtures.
The AST and byte profiles use local scope floors and the local fixtures.

checker_native.py validates the canonical closed public-goal grammar and
scope, and supports both native introduction modes. It retains the exact
array test a*0==[] from the upstream implementation. Its whole-certificate
integer/list contract is still an input precondition: arbitrary unused JSON
prefixes are not checked. Use checker.py when that precondition should be
verified by the executable itself.

The token change is exact trace equivalence: immutable tuple contexts become
variadic function arguments. The context-first change instead preserves the
public mathematical consequence relation. It can admit new administrative
spellings of proofs of already provable formulas. validation/nontrace.json
is a deliberately retained example of this difference; it rules out a false
claim of equality of every raw certificate language.

Complete-certificate type gate
-----------------------------

After JSON parsing, the required outer certificate is a list. Its Python
representation contains only the characters

    [] ,-0123456789

exactly when all its leaves are exact integers. Nested strings necessarily
have quotes or escapes, objects have braces, floating-point values have a
decimal point or letters, booleans have letters, and null becomes None.
The compact gate rejects those characters anywhere, including unused fields.
A non-list top-level value cannot complete the subsequent zero-argument pop
protocol and therefore cannot be accepted. This claim is about decoded JSON
values in the required list context, not str applied to a bare string.

The use of a*0!=0 in checker.py is consequently restricted to exact integers
and lists, on which it is a valid array discriminator. The ungated native
companion uses a*0==[] instead.

Run python3 reproduce.py to rebuild the detailed measurements and executable
evidence. FORMAT.txt explains the packet encoding and mode selectors. The
mathematical axioms, interpretations, preservation proof, and their precise
limitations are in report.pdf and report.tex.

As with the controls, the mathematical decision procedure is idealized as
having sufficient resources. Python recursion and memory limits can reject
very large valid certificates. Finite regression checks supplement the
written arguments; they are not a machine-checked proof of the metatheorems.
