import json

def c(g, a, k=0, v=0):
    i = lambda a, t=c, d=0: [i(b, t, d + 5 - len(a)) for b in a] if a * 0 == [] and (not v or len(a) in (1, 2 + d % 2)) else a if k <= a < d and (not v or (type(a) is int and d % 2 and (not a or a > 1 == a % 2))) else (d % 2 or v) and i(t, d=3)
    if i(a) in g:
        return
    v = 0
    m, s, u, t = q()
    c(g + [i(c(g, m, k) or m * 3 or (u and [[s and [s], u, t], i(t, [s, u, t], 3) if s else u]) or (a := i(*a, t, 2)), bool(m or len(a) % 2 == u) * (k := (k - 1)))], i(i(t, s) if m == ([s, u] if s else [t] * 3) and i(t, u) == a else a, [k]), k)
q = json.load(open(0)).pop
c([0], q(), v=1)
print('ACCEPT')
