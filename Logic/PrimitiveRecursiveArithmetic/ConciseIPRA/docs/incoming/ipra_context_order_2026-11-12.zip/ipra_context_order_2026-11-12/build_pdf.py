"""Build the report with pdfLaTeX, without shell escape."""
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    root = Path(__file__).resolve().parent
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required to build the report")
    with tempfile.TemporaryDirectory(prefix="ipra-context-pdf-") as tmp:
        cmd = [
            "pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
            "-halt-on-error", "-file-line-error", f"-output-directory={tmp}",
            "report.tex",
        ]
        logs = []
        for _ in range(3):
            run = subprocess.run(cmd, cwd=root, text=True, capture_output=True)
            logs.append(run.stdout + run.stderr)
            if run.returncode:
                (root / "evidence" / "pdf_build.log").write_text("\n".join(logs))
                raise SystemExit(run.stdout[-8000:] + run.stderr)
        shutil.copyfile(Path(tmp) / "report.pdf", root / "report.pdf")
        (root / "evidence" / "pdf_build.log").write_text("\n".join(logs))
        final_log = (Path(tmp) / "report.log").read_text(errors="replace")
        (root / "evidence" / "latex_final.log").write_text(final_log)
        print("Built report.pdf")


if __name__ == "__main__":
    main()
