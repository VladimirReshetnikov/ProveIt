"""Verify the delivered files before regenerating evidence or the PDF."""
from pathlib import Path
import hashlib
import json


root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text())
errors = []
for entry in manifest["files"]:
    path = root / entry["path"]
    if not path.is_file():
        errors.append(entry["path"] + ": missing")
        continue
    content = path.read_bytes()
    if len(content) != entry["size_bytes"] or hashlib.sha256(content).hexdigest() != entry["sha256"]:
        errors.append(entry["path"] + ": content differs")
if errors:
    raise SystemExit("\n".join(errors))
print(f"Verified {len(manifest['files'])} delivered files")
