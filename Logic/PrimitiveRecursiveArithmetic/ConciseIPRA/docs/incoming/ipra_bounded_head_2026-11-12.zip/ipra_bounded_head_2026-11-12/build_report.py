"""Rebuild the complete standalone article and its PDF."""
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    evidence = json.loads((ROOT / 'evidence/verification.json').read_text())
    generation = json.loads((ROOT / 'evidence/generation.json').read_text())
    risks = json.loads((ROOT / 'evidence/bounded_risk_results.json').read_text())
    measurements = {row['file']: row for row in evidence['metrics']}
    values = {}
    for prefix, file in [
        ('Bounded', 'code/bounded_checker.py'),
        ('Control', 'controls/head_checker.py'),
        ('Original', 'controls/head_checker_source.py')]:
        row = measurements[file]
        for suffix, key in [('Tokens','significant_tokens'),
                            ('Nodes','ast_nodes'),
                            ('Bytes','normalized_bytes')]:
            values[prefix + suffix] = row[key]
    values.update(GeneratedCases=generation['cases'],
                  CLIChecks=evidence['cli_executions'],
                  ControlChecks=len(evidence['head_translations']),
                  RiskChecks=risks['count'])
    definitions = ''.join('\\newcommand{\\' + name + '}{' + str(value) + '}\n'
                          for name, value in values.items())
    front = (ROOT / 'paper/front.tex').read_text()
    front = front.replace('\\begin{document}', definitions + '\\begin{document}')
    pieces = [front]
    for name in ['bounded_head_proof','bridge','normalization_cost','implementation','end']:
        pieces.append((ROOT / 'paper' / (name + '.tex')).read_text())
    pieces.append('\\section{Complete standalone checker}\n'
                  'The following listing is the full trusted module. The explanatory\n'
                  'docstring is excluded from code-only metrics and retained here.\n'
                  '\\lstset{basicstyle=\\ttfamily\\footnotesize}\n'
                  '\\begin{lstlisting}[language=Python]\n'
                  + (ROOT / 'code/bounded_checker.py').read_text()
                  + '\n\\end{lstlisting}\n\\end{document}\n')
    source = '\n\n'.join(pieces)
    target = ROOT / 'ipra_bounded_head.tex'
    target.write_text(source)
    directory = ROOT / 'build'
    directory.mkdir(exist_ok=True)
    command = ['pdflatex','-interaction=nonstopmode','-halt-on-error',
               '-output-directory=build',target.name]
    outputs = []
    for _ in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        outputs.append(result.stdout + result.stderr)
        if result.returncode:
            (directory / 'build_output.txt').write_text('\n'.join(outputs))
            raise SystemExit(outputs[-1][-5000:])
    (directory / 'build_output.txt').write_text('\n'.join(outputs))
    shutil.copy2(directory / 'ipra_bounded_head.pdf', ROOT / 'ipra_bounded_head.pdf')
    print('Built ipra_bounded_head.tex and ipra_bounded_head.pdf')

if __name__ == '__main__':
    main()

