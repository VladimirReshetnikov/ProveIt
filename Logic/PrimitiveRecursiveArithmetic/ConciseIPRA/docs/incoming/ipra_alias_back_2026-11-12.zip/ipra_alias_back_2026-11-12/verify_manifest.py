"""Verify the delivered files before regenerating evidence or rebuilding."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, expected in manifest['sha256'].items():
    path = root / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit('Manifest mismatch: ' + name)
print('Verified ' + str(len(manifest['sha256'])) + ' delivered file hashes.')
