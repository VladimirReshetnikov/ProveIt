"""Verify the integrity of the delivered archive before rebuilding it."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
failures = []
entries = (root / "MANIFEST.sha256").read_text().splitlines()
for entry in entries:
    expected, relative = entry.split("  ", 1)
    path = root / relative
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        failures.append(relative)
if failures:
    raise SystemExit("Integrity check failed: " + ", ".join(failures))
print(f"Verified {len(entries)} delivered files.")
