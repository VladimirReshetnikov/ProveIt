"""Assemble a standalone LaTeX source and optionally compile its PDF."""
from pathlib import Path
import argparse, json, shutil, subprocess

ROOT = Path(__file__).resolve().parent
NAME = 'ipra_abstraction_and_refinements'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', action='store_true')
    args = parser.parse_args()
    parts = ['paper/front.tex', 'mathematics/goal_abstraction.tex',
             'paper/bridge.tex', 'mathematics/predecessor45.tex',
             'paper/checkers.tex', 'paper/measurements.tex',
             'paper/evidence.tex', 'paper/bibliography.tex']
    assembled = '\n\n'.join((ROOT / part).read_text() for part in parts)
    (ROOT / (NAME + '.tex')).write_text(assembled)
    if args.pdf:
        from pdf_build_support import build
        build(ROOT / (NAME + '.tex'), ROOT / (NAME + '.pdf'),
              ROOT / 'evidence/pdf_build.log')
    print('Built', NAME + ('.tex and .pdf' if args.pdf else '.tex'))

if __name__ == '__main__':
    main()
