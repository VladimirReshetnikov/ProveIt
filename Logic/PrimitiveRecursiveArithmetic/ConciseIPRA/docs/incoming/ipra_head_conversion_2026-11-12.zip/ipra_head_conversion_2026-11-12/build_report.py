"""Assemble the standalone manuscript and optionally compile its PDF."""
import argparse
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
STEM = 'ipra_head_conversion_2026-11-12'


def assemble():
    theory = ROOT / 'theory'
    front = (theory / 'front.tex').read_text()
    positive = (theory / 'weak_head_calculus.tex').read_text()
    obstruction = (theory / 'raw_variable_substitution_obstruction.tex').read_text()
    end = (theory / 'end.tex').read_text().replace(
        '%%COMPACT_SECTION%%', (theory / 'compact477_proof.tex').read_text())
    text = '\n'.join((front, positive, obstruction, end))
    (ROOT / (STEM + '.tex')).write_text(text)
    return STEM + '.tex'


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true')
    args = parser.parse_args()
    source = assemble()
    if args.compile:
        for _ in range(2):
            subprocess.run(['pdflatex', '-interaction=nonstopmode',
                            '-halt-on-error', source], cwd=ROOT, check=True)
    print(source)
