"""Build the standalone research report with an installed pdfLaTeX."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
for _ in range(2):
    subprocess.run(
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
         "ipra_validated_leaves.tex"],
        cwd=ROOT, check=True,
    )
