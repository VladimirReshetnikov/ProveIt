"""Standalone readable expansion of the 607-byte strict checker.

Input is one JSON array. Its last item is a closed public Eq/D formula;
earlier items are four-field packets [major, source, seed_or_case, template],
consumed from right to left. Every recursive call consumes one packet,
including a hypothesis leaf. An unused prefix is permitted, but the entire
parsed input must use exact integers and lists. Each failed shape, scope,
proof, or alphabet check rejects by exception; acceptance is normal exit
with exactly ACCEPT followed by a newline. Python resource exhaustion is
rejection in this implementation, rather than a bound in the calculus.

The public grammar is the checker's arity grammar: formula nodes have arity
one (D) or two (equality); numerical nodes have arity one (successor) or
three (initialized iteration). The traversal starts at depth zero and adds
5 - arity on descent. Public leaves are odd integers 0 <= leaf < depth;
1 denotes numerical zero, and 3, 5, ... are protected-slot spellings.
Auxiliary integer/list trees retain the inherited broader sorted reading.

The seed field is also an introduction-mode field: exactly integer 2
requests cases for an atomic matrix. Otherwise a literal equation may use
progress; compound matrices always use cases. In a computation leaf it is
the ordinary initializer. These uses do not add a new arithmetic axiom.

No project imports or compact-source evaluation are used. Internal success
values are True instead of nested nonempty lists; the public acceptance
behavior and every branch's truth test are unchanged.
"""
import json

MISSING = object()


def check(context, goal, floor=0, strict=False):
    major, source, seed_or_case, template = next_packet()

    def opening(tree, image=MISSING, depth=0):
        if type(tree) is list:
            if strict and len(tree) not in (1, 2 + depth % 2):
                raise ValueError("Invalid public constructor arity")
            return [opening(child, image, depth + 5 - len(tree))
                    for child in tree]
        if type(tree) is not int:
            raise ValueError("Missing or invalid numerical substitution image")
        permitted_leaf = floor <= tree < depth
        if strict:
            permitted_leaf = permitted_leaf and bool(depth & (tree % 2))
        if permitted_leaf:
            return tree or 1
        if depth % 2 or strict:
            return opening(image, depth=3)
        return 0

    # Validate the public goal before changing the closure's validation phase.
    validated_goal = opening(goal)
    strict = False

    # This preview is eager even when the goal is a retained hypothesis.
    recursive_term = [source, seed_or_case, template]
    left = [source and [source], seed_or_case, template]
    right = (opening(template, recursive_term, 3)
             if source else seed_or_case)
    computation = opening([left, right])
    if validated_goal in context + [computation]:
        return True

    # Prove the major and open the introduction witness in the old scope.
    check(context, major, floor)
    hypothesis = major * 3
    if not hypothesis:
        goal = opening(*goal, template, 2)
        hypothesis = goal

    # Evaluate the mode test even when major is truthy, as the compact tuple does.
    atomic_progress = len(goal) == 2 and seed_or_case != 2
    use_fresh_parameter = bool(major) or atomic_progress
    floor -= 1
    new_hypothesis = opening(hypothesis, use_fresh_parameter * floor)

    # Both possible instances are opened eagerly in the newly allocated scope.
    minor = opening(template, source)
    required_major = [source, seed_or_case] if source else [template] * 3
    target = opening(template, seed_or_case)
    if (major, goal) == (required_major, target):
        goal = minor
    continuation = opening(goal, [floor])
    return check(context + [new_hypothesis], continuation, floor)


certificate = json.load(open(0))
if type(certificate) is not list or str(certificate).strip('0123456789-[], '):
    raise ValueError("The certificate alphabet consists of integers and lists")
next_packet = certificate.pop
check([0], next_packet(), strict=True)
print('ACCEPT')
