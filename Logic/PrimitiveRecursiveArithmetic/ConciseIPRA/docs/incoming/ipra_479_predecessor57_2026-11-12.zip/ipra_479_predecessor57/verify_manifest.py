"""Verify the bytes supplied in the archive, before regenerating evidence."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
failures = []
count = 0
for line in (root / "MANIFEST.sha256").read_text().splitlines():
    expected, name = line.split("  ", 1)
    path = root / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        failures.append(name)
    count += 1
if failures:
    raise SystemExit("Checksum failures: " + ", ".join(failures))
print("Verified", count, "packaged files.")
