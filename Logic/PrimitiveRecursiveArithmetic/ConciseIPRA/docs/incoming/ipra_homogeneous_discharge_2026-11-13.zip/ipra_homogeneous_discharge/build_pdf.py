"""Compile using installed TeX sources; never download dependencies."""
from pathlib import Path
import os
import subprocess

root = Path(__file__).resolve().parent
private = root / ".tex-build"
private.mkdir(exist_ok=True)
env = os.environ.copy()


def locate(name):
    found = subprocess.run(["kpsewhich", name], text=True, capture_output=True)
    return found.stdout.strip()


fmt = locate("pdflatex.fmt")
if not fmt:
    subprocess.run(["pdftex", "-ini", "-etex", "-interaction=nonstopmode",
                    "-halt-on-error", "-jobname=pdflatex", "-progname=pdflatex",
                    "-output-directory=" + str(private), "pdflatex.ini"],
                   cwd=root, env=env, check=True)
    fmt = str(private / "pdflatex.fmt")
if not locate("pdftex.map"):
    maps = []
    for name in ("cm.map", "cmextra.map", "latxfont.map", "symbols.map", "lm.map"):
        filename = locate(name)
        if not filename:
            raise SystemExit("Installed font map missing: " + name)
        maps.append(Path(filename).read_text())
    (private / "pdftex.map").write_text("\n".join(maps))
    env["TEXFONTMAPS"] = str(private) + ":" + env.get("TEXFONTMAPS", "")

for _ in range(2):
    subprocess.run(["pdftex", "-fmt=" + fmt, "-progname=pdflatex",
                    "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                   cwd=root, env=env, check=True)
