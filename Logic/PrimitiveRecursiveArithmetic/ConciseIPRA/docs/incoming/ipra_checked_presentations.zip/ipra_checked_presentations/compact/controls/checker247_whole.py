from json import load
k = 0

def i(a, t=0j, d=0):
    try:
        return [i(b, t, d + 5 - len(a)) for b in a]
    except:
        return a if k <= a < d else d % 2 and i(t, d=3)

def c(a, *g):
    global k
    s, u, t = r = q()
    if i(a) not in (*g, [[s and [s], u, t], i(t, r, 3) if s else u]):
        if i(t, u) == a:
            a = i(t, s)
            s = r[:2] if s else [t] * 3
        h = c(s, *g) or s * 3 if s else (a := i(*a, t, 2))
        k -= 1
        c(i(a, [k]), *g, i(h, (s or len(a) == 2) and k))
q = load(open(0)).pop
c(q())
print('ACCEPT')
