"""Verify the delivered bytes before rebuilding or regenerating evidence."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
failures = []
count = 0
for line in (root / "MANIFEST.sha256").read_text().splitlines():
    digest, name = line.split("  ", 1)
    path = root / name
    count += 1
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        failures.append(name)
if failures:
    raise SystemExit("Manifest mismatches: " + ", ".join(failures))
print(f"Verified {count} packaged files.")
