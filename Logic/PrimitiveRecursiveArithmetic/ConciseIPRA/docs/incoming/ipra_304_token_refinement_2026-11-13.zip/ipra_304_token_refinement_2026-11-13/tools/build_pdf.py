"""Compile the paper; also supports unpacked TeX Live trees without caches."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parent.parent
environment = os.environ.copy()
logs = []


def run(command):
    process = subprocess.run(command, cwd=root, env=environment,
                             text=True, capture_output=True, timeout=120)
    logs.append('$ ' + ' '.join(command) + '\n' + process.stdout + process.stderr)
    if process.returncode:
        (root / 'evidence/build_log.txt').write_text('\n'.join(logs))
        print(process.stdout[-5000:])
        print(process.stderr[-2000:])
        raise SystemExit(process.returncode)
    return process.stdout


def found(name):
    process = subprocess.run(['kpsewhich', name], env=environment,
                             text=True, capture_output=True)
    return process.returncode == 0 and bool(process.stdout.strip())


with tempfile.TemporaryDirectory(prefix='ipra-tex-') as temporary:
    cache = Path(temporary)
    if not found('latex.ltx'):
        trees = [Path(p) for p in ['/usr/share/texlive/texmf-dist', '/usr/share/texmf',
                                  '/var/lib/texmf', '/etc/texmf'] if Path(p).is_dir()]
        environment['TEXMF'] = '{' + ','.join(map(str, trees)) + '}'
    if not found('pdflatex.fmt'):
        run(['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
             '-halt-on-error', '-jobname=pdflatex',
             '-output-directory=' + str(cache), 'pdflatex.ini'])
        environment['TEXFORMATS'] = str(cache) + ':'
    if not found('pdftex.map'):
        maps = []
        for name in ['lm.map', 'cm.map', 'cmextra.map', 'latxfont.map', 'symbols.map']:
            process = subprocess.run(['kpsewhich', name], env=environment,
                                     text=True, capture_output=True)
            if process.returncode == 0 and process.stdout.strip():
                maps.append(Path(process.stdout.strip()).read_text())
        (cache / 'pdftex.map').write_text('\n'.join(maps))
        environment['TEXFONTMAPS'] = str(cache) + ':'
    for _ in range(2):
        run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'])

(root / 'evidence/build_log.txt').write_text('\n'.join(logs))
print('Built report.pdf (' + str((root / 'report.pdf').stat().st_size) + ' bytes)')
