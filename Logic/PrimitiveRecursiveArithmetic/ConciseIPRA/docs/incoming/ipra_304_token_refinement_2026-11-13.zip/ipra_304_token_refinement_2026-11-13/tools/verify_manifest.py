"""Check the delivered archive before rebuilding generated files."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent.parent
failures = []
count = 0
for line in (root / 'MANIFEST.sha256').read_text().splitlines():
    expected, name = line.split('  ', 1)
    path = root / name
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    count += 1
    if actual != expected:
        failures.append(name)
print(f'Checked {count} files; mismatches: {len(failures)}')
for name in failures:
    print(name)
if failures:
    raise SystemExit(1)
