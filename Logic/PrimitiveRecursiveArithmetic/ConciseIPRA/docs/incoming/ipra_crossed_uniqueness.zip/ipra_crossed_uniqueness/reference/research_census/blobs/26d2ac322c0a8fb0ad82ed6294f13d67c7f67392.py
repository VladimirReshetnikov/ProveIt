import json

def c(a, g=[0], k=0, v=False):
    i = lambda a, t=c, d=0: ([i(b, t, d + 5 - len(a)) for b in a] if a * 0 == [] else a if k <= a < d else d % 2 and i(t, d=3)) if not v or (type(a) is int and d % 2 and (a == 0 or a >= 3 and a % 2) or type(a) is list and len(a) in (1, 2 + d % 2)) else 1 / 0
    if i(a) in g:
        return
    v = False
    m, s, u, t = q()
    h = c(m, g, k) or m * 3 or (u and [[s and [s], u, t], i(t, [s, u, t], 3) if s else u]) or (a := i(*a, t, 2))
    c(i(m == ([s, u] if s else [t] * 3) and i(t, u) == a and i(t, s) or a, [(k := (k - 1))]), g + [i(h, (m or len(a) % 2 == u) and k)], k)
q = json.load(open(0)).pop
c(q(), v=True)
print('ACCEPT')
