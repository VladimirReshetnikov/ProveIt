import json
k = 0
i = lambda a, t=0j, d=0: [i(b, t, d - ~len(a)) for b in a] if a * 0 == [] else a if k <= a < d else d % 2 and i(t, d=1)

def c(a, g):
    global k
    if i(a) in g:
        return
    m, s, u, t = q()
    if m:
        c(m, g)
        a = m in ([s, u], not s and [t]) and i(t, u) == a and i(t, s) or a
        h = m[2:]
    elif m is None:
        h = [[s and [s], u, t], i(t, [s, u, t], 1) if s else u]
    else:
        h = a = i(*a[2:], t=t, d=2)
    k -= 1
    c(i(a, [k]), g + [i(h, k if m or len(a) % 2 == m else 0)])
c((q := json.load(open(0)).pop)(), [])
print('ACCEPT')
