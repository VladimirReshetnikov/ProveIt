"""Check the integrity ledger before regenerating derived artifacts."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
entries = (root / "MANIFEST.sha256").read_text().splitlines()
failures = []
for entry in entries:
    expected, name = entry.split("  ", 1)
    path = root / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        failures.append(name)
if failures:
    print("Mismatches:", *failures, sep="\n")
    raise SystemExit(1)
print("Verified", len(entries), "files")
