# Adapted from the upstream scope_phase build helper (MIT-0).
"""Compile the report using installed TeX; build a private format if necessary.

The fallback accommodates a Debian TeX source installation without ls-R caches.
It downloads nothing and changes no system configuration.
"""
from pathlib import Path
import os
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
env = os.environ.copy()


def locate(name):
    run = subprocess.run(['kpsewhich', name], env=env,
                         text=True, capture_output=True)
    return run.stdout.strip()


if not locate('pdflatex.ini'):
    roots = [p for p in ('/usr/share/texmf', '/usr/share/texlive/texmf-dist')
             if Path(p).is_dir()]
    if roots:
        env['TEXMF'] = '{' + ','.join(roots) + '}'

with tempfile.TemporaryDirectory(prefix='ipra-tex-') as directory:
    private = Path(directory)
    fmt = locate('pdflatex.fmt')
    if not fmt:
        subprocess.run(['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                        '-halt-on-error', '-jobname=pdflatex', '-progname=pdflatex',
                        '-output-directory=' + str(private), 'pdflatex.ini'],
                       cwd=ROOT, env=env, check=True)
        fmt = str(private / 'pdflatex.fmt')
    if not locate('pdftex.map'):
        maps = []
        for name in ('cm.map', 'cmextra.map', 'latxfont.map', 'symbols.map', 'lm.map'):
            filename = locate(name)
            if not filename:
                raise SystemExit('Installed font map missing: ' + name)
            maps.append(Path(filename).read_text())
        (private / 'pdftex.map').write_text('\n'.join(maps))
        env['TEXFONTMAPS'] = str(private) + ':' + env.get('TEXFONTMAPS', '')
    for _ in range(3):
        subprocess.run(['pdftex', '-fmt=' + fmt, '-progname=pdflatex',
                        '-interaction=nonstopmode', '-halt-on-error',
                        'report.tex'],
                       cwd=ROOT, env=env, check=True)
