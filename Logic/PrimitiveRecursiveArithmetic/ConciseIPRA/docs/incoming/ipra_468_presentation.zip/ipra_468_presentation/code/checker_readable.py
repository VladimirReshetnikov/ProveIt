"""Readable counterpart of compact468 on its exact-integer/list contract.

The compact source is the measured standalone checker. This expansion is
for inspection and is not an imported or trusted dependency of that source.
It deliberately preserves eager image checks and evaluation order.
"""
import json


MISSING = object()


def check(context, goal, floor):
    # Uniform terminal protocol: every check consumes an instruction.
    major, source, target, template = take_packet()

    def opening(tree, image=MISSING, depth=2):
        if type(tree) is list:
            return [opening(child, image, depth + 5 - len(tree))
                    for child in tree]
        if type(tree) is not int:
            raise TypeError('A visited scalar must be an exact integer')
        if floor <= tree < depth:
            return tree
        # Multiplication in the compact source evaluates this even when
        # depth is even. With MISSING this rejects every escaped scalar.
        checked_image = opening(image, depth=5)
        return (depth % 2) * checked_image

    checked_goal = opening(goal)
    computation_left = [source and [source], target, template]
    computation_right = (opening(template, [source, target, template], 5)
                         if source else target)
    if checked_goal in context + [[computation_left, computation_right]]:
        return True

    check(context, major, floor)
    hypothesis = major * 3
    if not hypothesis:
        goal = opening(*goal, template, 4)
        hypothesis = goal

    # Evaluate both members before any, exactly as in compact468.
    progressive = any((major, 3 % len(goal)))
    floor -= 1
    hypothesis = opening(hypothesis, progressive * floor)
    extended_context = context + [hypothesis]

    # The tuple selector in compact468 eagerly constructs both targets.
    minor = opening(template, source)
    expected_major = [source, target] if source else [template] * 3
    expected_goal = opening(template, target)
    selected = minor if (major, goal) == (expected_major, expected_goal) else goal
    continuation_goal = opening(selected, [floor])
    check(extended_context, continuation_goal, floor)
    return True


take_packet = json.load(open(0)).pop
check([0], *take_packet())
print('ACCEPT')
