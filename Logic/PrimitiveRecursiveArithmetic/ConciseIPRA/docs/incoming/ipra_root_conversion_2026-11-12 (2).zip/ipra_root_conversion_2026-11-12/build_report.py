"""Build the report with pdfLaTeX; use installed source assets if needed.

The local-format fallback is adapted from the pinned ProveIt
Artifacts/retained_premises/build.py, under the included MIT-0 license.
No network downloads or system-wide configuration writes are performed.
"""
import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NAME = 'ipra_root_conversion'


def environment(build):
    env = os.environ.copy()
    probe = subprocess.run(['kpsewhich', 'pdflatex.fmt'],
                           capture_output=True, env=env)
    if probe.returncode == 0 and probe.stdout.strip():
        return env
    trees = [Path('/usr/share/texlive/texmf-dist'), Path('/usr/share/texmf')]
    if not all(p.is_dir() for p in trees):
        raise RuntimeError('A complete pdfLaTeX installation is required.')
    runtime = build / 'texruntime'
    runtime.mkdir(exist_ok=True)
    env['TEXMF'] = '{' + ','.join(map(str, trees)) + '}'
    if not (runtime / 'pdflatex.fmt').exists():
        result = subprocess.run(
            ['pdftex', '-ini', '-interaction=nonstopmode', '-jobname=pdflatex',
             '-progname=pdflatex', '-etex', 'pdflatex.ini'],
            cwd=runtime, env=env, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        (runtime / 'format-build.log').write_bytes(result.stdout)
        if result.returncode:
            raise RuntimeError('Local format initialization failed; see build/texruntime.')
    maps = [trees[1] / 'fonts/map/dvips/lm/lm.map',
            *sorted((trees[0] / 'fonts/map/dvips/amsfonts').glob('*.map'))]
    (runtime / 'pdftex.map').write_bytes(b'\n'.join(p.read_bytes() for p in maps))
    env['TEXFORMATS'] = str(runtime) + os.pathsep
    env['TEXFONTMAPS'] = str(runtime) + os.pathsep
    return env


def main():
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    env = environment(build)
    for number in range(3):
        result = subprocess.run(
            ['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
             '-halt-on-error', '-file-line-error',
             '-output-directory=' + str(build), str(ROOT / (NAME + '.tex'))],
            cwd=ROOT, env=env, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        (build / f'pass-{number + 1}.txt').write_bytes(result.stdout)
        if result.returncode:
            print(result.stdout.decode(errors='replace')[-12000:])
            raise SystemExit(result.returncode)
    shutil.copyfile(build / (NAME + '.pdf'), ROOT / (NAME + '.pdf'))
    print(ROOT / (NAME + '.pdf'))


if __name__ == '__main__':
    main()
