"""Readable expansion of checker476.py, on its stated input contract.

Input: one JSON array, ending in [canonical_closed_guarded_goal, 0].
Earlier entries are four-field instruction packets in reverse read order.
The compact contract assumes finite exact-integer/list certificate trees.
This program deliberately adds no public-language or alphabet validator.
Normal exit with ACCEPT is success; exceptions are rejection.
"""
import json


def check(context, goal, floor):
    def opening(tree, image=check, depth=0):
        if tree * 0 != 0:
            return [opening(child, image, depth + 5 - len(tree))
                    for child in tree]
        if floor <= tree < depth:
            return tree
        # The image check is eager, including at even formula depths.
        return (depth % 2) * opening(image, depth=3)

    if opening(goal) in context:
        return True

    major, source, target, template = instruction()
    check(context, major, floor)
    raw_hypothesis = major * 3
    if not raw_hypothesis:
        if target:
            recursive_term = [source, target, template]
            endpoint = opening(template, recursive_term, 3) if source else target
            raw_hypothesis = [[source and [source], target, template], endpoint]
        else:
            goal = opening(*goal, template, 2)
            raw_hypothesis = goal

    # Both inputs to any are evaluated before allocating the new parameter.
    progressive = any((major, 3 % len(goal)))
    floor -= 1
    hypothesis = opening(raw_hypothesis, progressive * floor)
    next_context = context + [hypothesis]

    # Preserve the compact program's eager source/target evaluation order.
    source_instance = opening(template, source)
    required_major = [source, target] if source else [template] * 3
    target_instance = opening(template, target)
    if (major, goal) == (required_major, target_instance):
        goal = source_instance
    goal = opening(goal, [floor])
    return [check(next_context, goal, floor)]


instruction = json.load(open(0)).pop
check([[]], *instruction())
print('ACCEPT')
