"""Build the report; requires a TeX distribution with pdflatex."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
           "-jobname=ipra_checked_presentation", "report.tex"]
logs = []
for run in range(2):
    result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    logs.append(f"PASS {run + 1}\n{result.stdout}")
    if result.returncode:
        (root / "pdf_build_log.txt").write_text("\n".join(logs))
        print(result.stdout)
        raise SystemExit(result.returncode)
(root / "pdf_build_log.txt").write_text("\n".join(logs))
print(root / "ipra_checked_presentation.pdf")
