from pathlib import Path
import json,hashlib,argparse
if not __debug__: raise SystemExit("Run without -O: assertions must be enabled.")
parser=argparse.ArgumentParser(description="Owned read-only audit of SB215 return defect; writes one JSON receipt.")
parser.add_argument("--out",type=Path,default=Path("CHECK_RESULT.json"))
args=parser.parse_args()
D=Path(__file__).resolve().parent; P=D/'data'; H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def cfg(s):
 N=len(s);start={};end={}
 for i,(pc,op,k) in enumerate(s):
  for z in range(len(pc)+1):start.setdefault(pc[:z],i);end[pc[:z]]=i+1
 out=[]
 for i,(pc,op,k) in enumerate(s):
  bs=[end[pc[:z]]%N for z,b in enumerate(pc) if b=='0'];cs=[start[pc[:z]]for z,b in enumerate(pc) if b=='1'];stk=bs if op in('CD','CB')else cs;depth=1 if op=='CD'else k if op in('CB','CC')else 1;target=stk[-depth]if len(stk)>=depth else 0
  out.append((op,k,[]if op=='CH'else[target]if op in('CB','CC')else[target,(i+1)%N]if op=='CD'else[(i+1)%N]))
 return out
PINS={
'sb215.sites.json':'2407f815551b4aba335c9bf041e15e8ce3cfb9ad830d89539f3bcf123462371a',
'sb215.native.tm':'f08bed9e62b9f43237b65c465d2f1bfc17474637b4b02785ca7f1813827bb0ce',
'sb215.tm':'045e3630715ec3f0e8970e65e77d0e5ab72a495735f32495a60d713d2a5e48b9',
'sb215.canonicalization.json':'eb80fc9d11d42bad55013dd3d3926998c3f5f5e8b465d14657aba22d1bcc5e5c',
'sb215_ab.sites.json':'5369d888be0675221b18fd7bb0df3018213e966265604f9506a6be2c9deff5ba',
'sb215_ab.native.tm':'2155e318d049ab0c6f578012a0751bc2f445950615a7f035347888e77f7be883',
'sb215_ab.tm':'1fff0e90b586ed50dccfcf98f9ff465758ec3cd0357be788049c9d6c8c840ef4',
'sb215_ab.canonicalization.json':'2e2f02cb8ba91fa8f5473a3d61b37ed6f4f7682dc7ebb1ce3514657f73ff10fa'}
for name,pin in PINS.items(): assert H(P/name)==pin, ('Artifact hash mismatch',name)
S=[json.loads((P/f'{n}.sites.json').read_text()) for n in ('sb215','sb215_ab')];G=[cfg(s) for s in S]
diffs=[dict(ordinal=i,old=a,new=b)for i,(a,b) in enumerate(zip(*S))if a!=b]
assert [d['ordinal']for d in diffs]==[958,963,1136,1141]
assert all(d['old'][:2]==d['new'][:2] and d['old'][2]==3 and d['new'][2]==5 for d in diffs)
assert all(a[0]==b[0] and a[2]==b[2]for a,b in zip(*G))
results=[]
for name,s,g in zip(('sb215','sb215_ab'),S,G):
 assert s[4697]==['100111','CC',3] and g[4697][2]==[23] and g[4589][2]==[4696]
 assert g[4698]==('CD',1,[4700,4699])and g[4699][2]==[4698]
 traces=[]
 for t in [0,1,2,10,100,1000]:
  regs=[37,t,91,0,59,0,0,0,0];pc=4696;trace=[]
  for tick in range(2*t+20):
   op,k,edges=g[pc];trace.append([pc,op,k,regs[:]])
   if op=='CH':break
   if op=='CI':regs[k]+=1;pc=edges[0]
   elif op=='CD':b=int(regs[k]>0);regs[k]-=b;pc=edges[b]
   else:pc=edges[0]
  assert pc==4718 and tick==15+2*t and regs==[37,0,91,0,59,0,0,0,0]
  traces.append(dict(T=t,steps=tick,halt=pc,trace=trace if t==0 else None))
 results.append(dict(machine=name,pins={p.name:H(p) for p in sorted(P.glob(name+'.*'))},return_ordinal=4697,actual_target=23,claimed_target=0,probes=traces))
result=dict(status='BOTH_RETAIN_FORCED_HALT_DEFECT',zip_sha256='e1ed6e2533508d56051c22f7ffc32cda76af7f6dcc50f0fc119958950554c263',source_diffs=diffs,all_control_edges_equal=True,post_AX_suffix_equal=S[0][4696:]==S[1][4696:],results=results)
# The final receipt is written after all source and binary checks.
def table(path):
 out={}
 for line in path.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();key=int(q),int(b);assert key not in out;out[key]=(int(w),1 if d=='R'else -1,int(z))
 return out
Ts=[]
for name in ('sb215','sb215_ab'):
 n=table(P/f'{name}.native.tm');d=table(P/f'{name}.tm');m=json.loads((P/f'{name}.canonicalization.json').read_text());f={int(k):v for k,v in m['native_to_dense'].items()};f[254]=215
 assert f[74]==0 and len(n)==len(d)==430
 assert len(f)==216 and set(f.values())==set(range(216))
 assert {(f[q],b):(w,move,f[z])for (q,b),(w,move,z)in n.items()}==d
 Ts.append(n)
result['native_differences']=[dict(row=list(k),old=Ts[0][k],new=Ts[1][k])for k in sorted(Ts[0])if Ts[0][k]!=Ts[1][k]]
q=74;h=0;ones=set()
for tick in range(69744):
 key=q,int(h in ones);assert Ts[0][key]==Ts[1][key];w,move,z=Ts[0][key]
 if w:ones.add(h)
 else:ones.discard(h)
 h+=move;q=z
assert (q,h)==(84,-2) and len(ones)==105
result['dense_bijections_checked']=True;result['blank_prefix_69744_identical']=dict(state=q,head=h,one_cells=len(ones))
args.out.write_text(json.dumps(result,indent=2)+'\n')
print('Native differences',result['native_differences']);print('Dense bijections and blank prefix PASS')
