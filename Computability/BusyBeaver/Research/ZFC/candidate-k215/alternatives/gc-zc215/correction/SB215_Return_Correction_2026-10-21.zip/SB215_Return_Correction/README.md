# SB215 / SB215-AB return-target correction

This small evidence packet corrects the source-binding claims for SB215 and SB215-AB in the saved report:
https://chatgpt.com/c/6ad8e9eb-6c00-83e8-9dc3-8a7bbe52f8cf?messageId=490d115b-8450-55a1-a345-2a9c47261c01

It does not alter or invalidate the separate FT215 construction.

Read CORRECTION.md for the mathematical counterexample. The data directory contains only exact source lists, native/dense transition tables, and renumbering maps from the challenged package. No received executable code or erroneous report is redistributed here. check.py is an independently written checker using the Python standard library only.

## Reproduce

With Python 3.10 or later, from this directory:

    python3 -B check.py --out fresh-result.json

Do not use Python -O or -OO. The checker explicitly rejects disabled assertions. It reads fixed data relative to its own path and writes only the requested JSON output (default CHECK_RESULT.json in the current directory). No network access or original ZIP is required.

The checker verifies pinned hashes of all eight data files, exact source changes, both control-flow graphs, both forced post-AX suffixes, native/dense bijections, and identical 69,744-step binary blank prefixes. The checked suffix samples accompany an elementary all-natural loop proof in CORRECTION.md; finite probes alone are not asserted to establish universality. CHECK_RESULT.json records a clean run. ISOLATED_REPLAY.json records a fresh extracted run.

The original package hash is a documented provenance constant, not a runtime dependency:

    e1ed6e2533508d56051c22f7ffc32cda76af7f6dcc50f0fc119958950554c263

The checker does not rerun full arbitrary-natural symbolic runtime certificates or literally complete the huge AX arithmetic. The exact source graph directly contradicts the claimed scheduler binding. The binary halting conclusion additionally uses the inherited terminating AX contract and source-to-binary simulation, as explained in the correction note. No assertion about the abstract fairness theorem in isolation is needed.

Inherited data licenses and notices are preserved in licenses/. They are provenance materials, not new executable dependencies.
