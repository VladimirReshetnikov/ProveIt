#!/usr/bin/env python3
"""Seventeen finite-tested equality sources: exact K219 allocation only."""
from pathlib import Path
import argparse,hashlib,importlib,json,sys,time
ROOT=Path('/home/codex/.codex/worktrees/ec20/Proofs')
OWN=ROOT/'Computability/BusyBeaver/Research/ZFC/k219-source-search'
BASE=OWN.parent/'candidate-k219';LIB=OWN.parent/'k219-continuation-search/compiler-inputs'
PINS={'measure.py':'342537f773807e185ed250a18db27afe5122abf2b8bda0e8a31f073e0d1ca397','measure_ci6_hypothesis.py':'2585938f7e976392fc0f030d07d79743436cdec6d009307ba512391d39963719','source_language.py':'4b355b81373a06ce2d8d99f56ac88afee8bbbd934d21f4f2729d864d9807683f','build221.py':'3359e8b40fefb162ca4aa1d5c5a99a368a937ec61f761c3ac6f26d573766acba'}
IDS=[70,72,91,92,94,95,96,100,101,102,103,104,105,107,180,182,183]
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def freeze(t):return tuple(map(freeze,t)) if isinstance(t,list) else t
ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
need(__debug__ and not sys.flags.optimize,'Assertions required');need(not a.output.exists(),'Fresh output required')
pins={str(LIB/n):h for n,h in PINS.items()};pins.update({str(BASE/'sites219.json'):'0f6d9d991e36dda1a7449edab72a799bb2d8c3de3ff853a26178b89bd1bc8789',str(BASE/'k219.native.tm'):'b255f8ee341d394c303d67a7fca7f8288ed9d4c40f075899fa64b13085aaca26'})
need(all(sha(Path(p))==h for p,h in pins.items()),'Fixed input drift')
analysis=json.loads((a.input/'analysis.json').read_text());pins[str(a.input/'analysis.json')]=sha(a.input/'analysis.json')
selected=[r for r in analysis['results'] if r['metrics']['dag_nodes']==207 and r['finite']=='PASS']
need(sorted(r['id'] for r in selected)==IDS,'Exact selected seventeen')
for i in IDS:
 p=a.input/f'candidate-{i:03d}.sites.json';pins[str(p)]=sha(p)
sys.dont_write_bytecode=True;sys.path.insert(0,str(LIB));s=importlib.import_module('source_language');b=importlib.import_module('build221');strict=importlib.import_module('measure')
old=s.tree(json.loads((BASE/'sites219.json').read_text()));T=b.read_table((BASE/'k219.native.tm').read_bytes());accepted=freeze(json.loads((BASE/'new_equality_macro.json').read_text()))
identity,im=strict.compile_tree(s,b,T,old,old);need(identity==T and im['working_states']==219,'Exact identity219')
a.output.mkdir(parents=True);(a.output/'measure.py').write_bytes(Path(__file__).read_bytes());(a.output/'analysis.json').write_bytes((a.input/'analysis.json').read_bytes());hyp=None;controls={'strict':im};results=[];started=time.monotonic()
for r in sorted(selected,key=lambda r:r['id']):
 i=r['id'];p=a.input/f'candidate-{i:03d}.sites.json';raw=p.read_bytes();rows=json.loads(raw);new=s.tree(rows);macro=freeze(r['macro']);paths=[]
 def replace(n,path=''):
  if n==accepted:paths.append(path);return macro
  return n if s.leaf(n) else (replace(n[0],path+'0'),replace(n[1],path+'1'))
 need(replace(old)==new and len(paths)==4,'Exact four literal substitutions')
 need(s.metrics(new)==r['metrics'],'Source census');need(s.graph_arithmetic(rows)[0]==s.graph_intervals(rows),'Complete CFG agreement')
 out=a.output/f'candidate-{i:03d}';out.mkdir();(out/'sites.json').write_bytes(raw)
 row={'id':i,'source_sha256':sha(p),'source_metrics':r['metrics'],'literal_four_replacements':paths,'cfg_agreement':True,'source_contract':'UNPROVED; parent reports261finitecases only','attempts':[]}
 def attempt(mod,name):
  z={'compiler':name};t=time.monotonic();missing=False
  try:
   table,m=mod.compile_tree(s,b,T,old,new);rr=b.table_bytes(table);need(b.read_table(rr)==table,'Table roundtrip');f=out/(name+'.native.tm');f.write_bytes(rr)
   z.update(status='DECODER_PREFIX_BINDING_PASS',metrics=m,table_sha256=sha(f),table_file=f.relative_to(a.output).as_posix(),helper302_retained=any(q==302 for q,bit in table))
  except (ValueError,KeyError,AssertionError) as exc:
   z.update(status='COMPILER_REJECTED',error=repr(exc));detail=exc.args[0] if len(exc.args)==1 else None
   missing=isinstance(exc,ValueError) and isinstance(detail,tuple) and detail[:3]==('No generic leaf entry',('CI',6),1)
  z['seconds']=time.monotonic()-t;row['attempts'].append(z);return missing
 missing=attempt(strict,'strict')
 if missing:
  if hyp is None:
   hyp=importlib.import_module('measure_ci6_hypothesis');t,m=hyp.compile_tree(s,b,T,old,old);need(t==T and m['working_states']==219,'Hypothesis identity219');controls['ci6_hypothesis']=m
  attempt(hyp,'ci6_hypothesis')
 results.append(row);dump(out/'result.json',row);print(i,[(x['compiler'],x['status'],x.get('metrics',{}).get('working_states'),x.get('error')) for x in row['attempts']],flush=True)
need(all(sha(Path(p))==h for p,h in pins.items()),'Input changed')
passed=[{'id':r['id'],**x} for r in results for x in r['attempts'] if x['status']=='DECODER_PREFIX_BINDING_PASS']
result={'status':'SEVENTEEN_EXTENSION_ALLOCATIONS_COMPLETE','inputs':pins,'controls':controls,'results':results,'minimum_raw_states':min((r['metrics']['working_states'] for r in passed),default=None),'at_most218':[r for r in passed if r['metrics']['working_states']<=218],'scope':'Exact source substitution/CFG and decoder-prefix allocation only. All-natural macro contracts, primitive runtime, startup and machine calibration not proved. CI6-right entry only tried as explicitly unverified hypothesis after its exact missing-entry rejection.','seconds':time.monotonic()-started,'script_sha256':sha(Path(__file__))};dump(a.output/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','controls','results')},indent=2),flush=True)
