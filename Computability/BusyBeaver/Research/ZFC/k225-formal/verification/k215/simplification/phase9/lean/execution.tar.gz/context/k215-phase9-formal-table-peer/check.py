"""Independent inert literal correspondence and certificate-field reader; no machine execution."""
from pathlib import Path
import hashlib,json,re
P=Path('/tmp/k215-phase9-decoder-routes');C=P/'formal-table/candidate/BusyBeaver/ZFC';O=Path(__file__).resolve().parent
R=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Lean/BusyBeaver/ZFC')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sw={301:102,102:301,302:120,120:302,254:230,230:254}
sig=lambda n:sw.get(n,n)
assert len(sw)==6 and all(sig(sig(n))==n for n in sw)
old=(P/'candidate/BusyBeaver/ZFC/K215Decoder.lean').read_text();new=(C/'K215Decoder.lean').read_text();tab=(R/'KTable215.lean').read_text()
def matches_exact(pattern,body):
 ms=list(re.finditer(pattern,body));cursor=0
 for m in ms:
  assert not body[cursor:m.start()].strip(' ,\n\t\r'),body[cursor:m.start()]
  cursor=m.end()
 assert not body[cursor:].strip(' ,\n\t\r'),body[cursor:]
 return ms
nativebody=old.split(':= #[',1)[1].split('\n]',1)[0]
pat=r'none|some \(⟨(true|false), (1|\(-1\)), (\d+)⟩, ⟨(true|false), (1|\(-1\)), (\d+)⟩\)'
oldrows=[]
for m in matches_exact(pat,nativebody):
 if m[0]=='none':oldrows.append((None,None));continue
 oldrows.append(tuple((m[i]=='true',m[i+1]=='1',int(m[i+2]))for i in[1,4]))
body=tab.split(':= [',1)[1].split(']\n',1)[0]
a=r'(?:none|some \((?:true|false), (?:true|false), \d+\))'
newrows=[]
for m in matches_exact(r'\(('+a+r'), ('+a+r')\)',body):
 pair=[]
 for x in [m[1],m[2]]:
  if x=='none':pair.append(None);continue
  k=re.fullmatch(r'some \((true|false), (true|false), (\d+)\)',x);assert k
  pair.append((k[1]=='true',k[2]=='true',int(k[3])))
 newrows.append(tuple(pair))
assert len(oldrows)==303 and len(newrows)==226
get=lambda rows,q:rows[q] if q<len(rows)else(None,None)
maprow=lambda a:None if a is None else(a[0],a[1],sig(a[2]))
for q in range(303):assert tuple(maprow(x)for x in get(oldrows,q))==get(newrows,sig(q)),q
assert sum(x is not None for pair in oldrows for x in pair)==sum(x is not None for pair in newrows for x in pair)==430
# For q>=303, sigma is the identity and both definitions default to none.
assert max(sw)<303 and sig(0)==0 and sig(84)==84

def part(s,a,b):return s[s.index('def '+a+' :'):s.index('def '+b+' :')]
assert part(old,'sourceNodes','blocks')==part(new,'sourceNodes','blocks')
node_lines=[l.strip().rstrip(',')for l in part(new,'sourceNodes','blocks').splitlines()[1:]if l.lstrip().startswith('.')]
assert len(node_lines)==202
source_leaves=sum(x.startswith('.leaf')for x in node_lines)
assert all(re.fullmatch(r'\.(?:leaf|fork) \d+ \d+',x)for x in node_lines)
# Compare each literal record with only its state-bearing fields transformed.
bpat=r'^  ⟨(\d+), (\d+), (\[(?:true|false|, |)*\]), (\d+)⟩,?$'
oldblocks=[m.groups()for m in re.finditer(bpat,part(old,'blocks','roles'),re.M)];newblocks=[m.groups()for m in re.finditer(bpat,part(new,'blocks','roles'),re.M)]
assert len(oldblocks)==len(newblocks)==281
for x,y in zip(oldblocks,newblocks):assert y==(str(sig(int(x[0]))),str(sig(int(x[1]))),x[2],x[3])
oldroles=[l for l in part(old,'roles','sourceRoot').splitlines()if l.startswith('  ⟨')];newroles=[l for l in part(new,'roles','sourceRoot').splitlines()if l.startswith('  ⟨')];assert len(oldroles)==len(newroles)==234
primitive=0
for x,y in zip(oldroles,newroles):
 m=re.fullmatch(r'  ⟨(\d+), (\d+), (.*)',x);n=re.fullmatch(r'  ⟨(\d+), (\d+), (.*)',y);assert m and n
 assert m[1]==n[1] and sig(int(m[2]))==int(n[2])
 actions=re.findall(r'⟨(true|false), (1|\(-1\)), (\d+)⟩',m[3]);primitive+=len(actions)
 expected=m[3]
 for w,d,q in actions:expected=expected.replace('⟨'+w+', '+d+', '+q+'⟩','⟨'+w+', '+d+', STATE_'+str(sig(int(q)))+'⟩')
 expected=expected.replace('STATE_','');assert expected==n[3]
assert primitive==97
for name in ['DecoderCertificate.lean','DecoderPaths.lean','DecoderSourceBinding.lean']:
 before=(P/'candidate/BusyBeaver/ZFC'/name).read_text();after=(C/name).read_text()
 assert after==re.sub(r'\bnative\b','formal',before),name
assert 'def sourceRoot : Nat := 201' in new
assert 'nativeRows'not in new
assert 'def formal : Table := KZipTape.table KTableCore.tm215' in new
assert 'def fast : Table := KZipTape.table (KBoot.fastOf KBoot215.tt215)' in new
assert 'theorem fast_eq : fast = formal := by\n  funext q b\n  simp only [fast, formal, KZipTape.table, KBoot215.fast215]' in new
freeze=json.loads((P/'formal-table/freeze.json').read_text())
for m in freeze['modules']:assert sha(Path(m['source']))==m['sha256']
assert sha(Path(freeze['producer']['path']))==freeze['producer']['sha256']
inputs=[C/n for n in ['DecoderCertificate.lean','K215Decoder.lean','DecoderPaths.lean','DecoderSourceBinding.lean']]+[P/'prepare_formal.py',P/'formal-table/freeze.json',R/'KTable215.lean',R/'KFast215.lean',R/'KSource215Program.lean',R/'KTableCore.lean']
result={'status':'PASS_OWN_INERT_LITERAL_CORRESPONDENCE','native_slots':303,'formal_slots':226,'defined_rows_each':430,'finite_states_compared':303,'outside_range':'Both absent, sigma identity for all q>=303','total_state_map':sw,'fixed_states':[0,84],'blocks':281,'roles':234,'primitive_actions':97,'source_nodes':202,'source_leaf_nodes':source_leaves,'source_op_arg_and_indices_unchanged':True,'word_clocks_suffixes_internal_role_and_block_indices_unchanged':True,'generic_checker_unchanged':True,'path_binding_delta_only_native_to_formal':True,'machine_steps_executed':0,'compiler_invocations':0,'inputs':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size}for p in inputs},'own_script_sha256':sha(Path(__file__))}
(O/'literal-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='inputs'},indent=2))
