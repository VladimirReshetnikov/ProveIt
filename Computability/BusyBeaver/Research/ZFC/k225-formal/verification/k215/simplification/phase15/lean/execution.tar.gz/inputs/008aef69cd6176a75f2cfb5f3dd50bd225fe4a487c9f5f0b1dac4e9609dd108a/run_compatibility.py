"""Authorized exact compatibility invocation after primary and final-map peers."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,subprocess,time
S=Path('/tmp/k215-phase15-client-retry');R=Path('/tmp/k215-phase15-check');E=Path(__file__).resolve().parent;REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
assert sha(S/'compatibility-final-map.json')=='b883472d370963aae5cfbba0121143cc5070d7583e62389b94b7054bbb40e397'
parser=argparse.ArgumentParser();parser.add_argument('--peer',type=Path,required=True);parser.add_argument('--peer-sha256',required=True);args=parser.parse_args()
peer=args.peer;assert sha(peer)==args.peer_sha256 and str(read(peer)['status']).startswith('PASS')
def unchanged():return all(sha(root/p)==h for root in [R,S]for p,h in read(root/'freeze.json')['files'].items())
assert unchanged()and not(R/'compatibility-run1').exists()
argv=read(S/'commands.json')['compatibility'];out=E/'compatibility-run1.stdout';err=E/'compatibility-run1.stderr';record=E/'compatibility-run1-outer.json';assert all(not p.exists()for p in [out,err,record])
rec={'status':'RUNNING','argv':argv,'cwd':str(REPO),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_sha256':sha(__file__),'final_map_sha256':sha(S/'compatibility-final-map.json'),'primary_map_peer_sha256':sha(peer),'primary_result_sha256':sha(R/'primary-run3/result.json'),'stdout':str(out),'stderr':str(err)}
record.write_text(json.dumps(rec,indent=2)+'\n');start=time.monotonic();proc=None
try:
 with out.open('wb')as stdout,err.open('wb')as stderr:
  proc=subprocess.Popen(argv,cwd=REPO,stdout=stdout,stderr=stderr,start_new_session=True);rec['pid']=proc.pid;record.write_text(json.dumps(rec,indent=2)+'\n');code=proc.wait()
 rec.update(status='PASS_OUTER_EXIT_ZERO'if code==0 else'FAIL_OUTER_EXIT',exit_code=code)
except BaseException as exc:
 if proc is not None and proc.poll()is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 rec.update(status='OUTER_EXCEPTION',exception=repr(exc),exit_code=None if proc is None else proc.returncode);raise
finally:
 rec.update(seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err),frozen_files_unchanged=unchanged());record.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2),flush=True)
assert rec['exit_code']==0 and rec['frozen_files_unchanged']
