"""Small metadata gates for the phase7 incremental build; no proof execution."""
from pathlib import Path
import re

DOM = 'BusyBeaver.ZFC.DomRho8'
AFFECTED = {f'BusyBeaver.ZFC.{n}' for n in (
    'DomRho8', 'EnumPerm', 'KCodeDom', 'KEndpoint215',
    'L2AxiomsPerm', 'L2RootPerm', 'SeedPerm')}
AUDIT_PINS = {
    'EndpointAudit215': 'd13596021774c5b26937b13cf6cca58342af99f59626b9205ff10b9df1e6fc7d',
    'K215Audit': '9144acc6c597c4a53928fc62be00d5e25d9f32f519797d17a5058d03b5460986',
}
AUDIT_NAMES = {
    'EndpointAudit215': [
        'EndpointAudit215.blank_halts_exactly_when_zfc_has_a_finite_refutation',
        'EndpointAudit215.nonhalting_exactly_when_zfc_is_consistent'],
    'K215Audit': [
        'SetTheory.BusyBeaver.ZFC.KEndpoint215.blank_halts_iff_zfc_refutation',
        'SetTheory.BusyBeaver.ZFC.KEndpoint215.nonhalting_iff_zfc_consistency',
        'SetTheory.BusyBeaver.ZFC.KDense215.commutes',
        'SetTheory.BusyBeaver.ZFC.KBoot215.boot',
        'SetTheory.BusyBeaver.ZFC.KSites215.covered',
        'SetTheory.BusyBeaver.ZFC.KEndpoint215.p215_boot_iff',
        'K215Audit.blank_halts_exact', 'K215Audit.nonhalting_exact'],
}

def checkpoint(old, new):
    assert new['target'] == old['target'] == 'BusyBeaver.ZFC.KEndpoint215'
    assert new['external_imports'] == old['external_imports'] == ['Init']
    before = {e['module']: e for e in old['modules']}
    after = {e['module']: e for e in new['modules']}
    assert len(before) == len(after) == len(old['modules']) == len(new['modules']) == 187
    assert set(before) == set(after)
    assert [e['module'] for e in old['modules']] == [e['module'] for e in new['modules']]
    for m in before:
        assert before[m]['source'] == after[m]['source']
        assert before[m]['imports'] == after[m]['imports'], m
    changed = {m for m in before if before[m]['source_sha256'] != after[m]['source_sha256']}
    assert changed == {DOM}, ('Only the approved DomRho8 source may change', changed)
    affected = set(changed)
    while True:
        more = affected | {m for m,e in after.items() if set(e['imports']) & affected}
        if more == affected:
            break
        affected = more
    assert affected == AFFECTED
    return {'changed_sources': sorted(changed), 'potentially_affected_modules': sorted(affected)}

def audit_reports(name, text):
    assert not any(s in text for s in ('warning:', 'error:', 'sorryAx', "declaration uses 'sorry'"))
    reports = re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)", text)
    assert [n for n,_ in reports] == AUDIT_NAMES[name]
    for _, axioms in reports:
        assert {a.strip() for a in axioms.split(',') if a.strip()} <= {'propext', 'Classical.choice', 'Quot.sound'}
    return reports

def private_parents(obj, cache):
    """Unlinking a target must never follow a directory alias into the basis."""
    assert not cache.is_symlink()
    obj.relative_to(cache)
    for parent in obj.parents:
        assert not parent.is_symlink(), parent
        if parent == cache:
            return
    raise AssertionError('Object outside private cache')

def provider(obj, basis_obj, origin):
    if origin == 'phase6_hash_bound':
        assert obj.is_symlink() and obj.resolve(strict=True) == basis_obj.resolve(strict=True)
    else:
        assert origin == 'phase7_fresh' and obj.is_file() and not obj.is_symlink()
