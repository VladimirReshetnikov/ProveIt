"""Disposable CLI controls for the producer migration; no Lean invocation."""
from pathlib import Path
import subprocess,sys,time,json,hashlib,shutil
O=Path(__file__).resolve().parent;W=O/'workspace';ROOT=Path('/home/codex/.codex/worktrees/ec20/Proofs');F=Path('Computability/BusyBeaver/Research/ZFC/k225-formal');L=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC');R=O/'regeneration-run1';R.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
def files():return {p.name:sha(p)for p in sorted((W/L).glob('*.lean'))}
def run(name,argv,cwd):
 start=time.monotonic();r=subprocess.run([sys.executable,*map(str,argv)],cwd=cwd,capture_output=True,timeout=60)
 (R/(name+'.stdout')).write_bytes(r.stdout);(R/(name+'.stderr')).write_bytes(r.stderr)
 rec={'name':name,'argv':[sys.executable,*map(str,argv)],'cwd':str(cwd),'seconds':time.monotonic()-start,'exit_code':r.returncode,'timeout_seconds':60};records.append(rec);assert r.returncode==0,rec
initial=files()
args=[W/F/'generate_source215_lean.py',W/F/'lean215/dagperm_nodes.json',W/F/'lean215/dagperm_sites.json']
run('repeat_source',args,W);run('repeat_sites',[W/F/'generate_sites215_lean.py','full','80','12'],W);assert files()==initial
maintained=['generate_source215_lean.py','partition_source215_lean.py','generate_sites215_lean.py','prepare_k215.py']
maintained_before={n:sha(W/F/n)for n in maintained}
run('prepare',[W/F/'prepare_k215.py'],W)
assert maintained_before=={n:sha(W/F/n)for n in maintained}
assert files()==initial
for name in ['generate_boot215_lean.py','generate_dense215_lean.py','generate_tables_lean.py','lean215/k215_k230labels.tm','lean215/labels.json']:
 assert (W/F/name).read_bytes()==(ROOT/F/name).read_bytes(),name
run('post_prepare_source',args,W);run('post_prepare_sites',[W/F/'generate_sites215_lean.py','full','80','12'],W);assert files()==initial
# Baseline producer control proves the same literal input route reproduces the current files.
B=R/'baseline-workspace';(B/L).mkdir(parents=True)
for name in ['generate_source215_lean.py','partition_source215_lean.py','generate_source225_lean.py','gen_cert.py','generate_sites215_lean.py']:
 p=F/name;(B/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(O/'baseline'/p,B/p)
for p in [F/'lean215/dagperm_nodes.json',F/'lean215/dagperm_sites.json',F.parent/'candidate-k215/sites215.json']:
 (B/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/p,B/p)
run('baseline_source',[B/F/'generate_source215_lean.py',B/F/'lean215/dagperm_nodes.json',B/F/'lean215/dagperm_sites.json'],B)
run('baseline_sites',[B/F/'generate_sites215_lean.py','full','80','12'],B)
basefiles=list((B/L).glob('*.lean'));assert len(basefiles)==28
for p in basefiles:assert p.read_bytes()==(O/'baseline'/L/p.name).read_bytes(),p.name
# Preserve input/baseline bindings and exact output identities in the saved record.
result={'status':'PASS_PYTHON_REGENERATION_ONLY','jobs':records,'deterministic_30_lean_outputs':initial,'baseline_28_outputs_exact':True,'maintained_producers_preserved_by_prepare':maintained_before,'prepare_machine_boot_dense_outputs_exact_current':True,'compiler_executed':False,'canonical_mutation':False}
(R/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['deterministic_30_lean_outputs','maintained_producers_preserved_by_prepare']},indent=2))
