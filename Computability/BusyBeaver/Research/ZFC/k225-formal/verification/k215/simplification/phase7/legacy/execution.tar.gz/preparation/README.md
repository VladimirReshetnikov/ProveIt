# Prepared phase7 legacy continuity

This is a scratch driver and read-only preparation, **not a new proof run**. Canonical sources and all predecessor records/objects are untouched. Wait for root's explicit GO before invoking the driver.

The exact import union contains187 current primary modules and15 legacy-only modules,202 total. The DomRho8 source change potentially affects EnumDom, L2AxiomsDom and L2RootDom; L2Dom is independent of that import branch. The actual terminal phase7 primary rebuilt DomRho8 and KCodeDom, but KCodeDom's object is byte-identical to phase6. Consequently all15 legacy direct-dependency maps remain valid and the actual plan selects zero legacy recompilations. The driver makes this decision from actual dependency hashes, never from module counts or potential reachability alone.

The unchanged LegacyAudit has five named clients and a45-module transitive project closure. DomRho8's object changed within that closure, so the old audit is retained as history and the driver always compiles the five clients again. It rejects missing/reordered/extra reports, warnings, errors, sorryAx and nonstandard assumptions.

`actual-plan.json` records an own read-only check of every selected202 source, direct dependency, object and log. `preparation.json` also binds all202 predecessor providers and logs through phase6 continuity and the phase5 legacy packet. The historical three-potential-module preparation and unexecuted static-three driver remain under history; neither launched a compiler.

The private cache contains only symlinks to accepted primary/legacy providers until an exact dependency mismatch requires one of the three eligible legacy modules. That target symlink is removed before writing, with no directory aliases allowed. New compilation uses the already-reviewed shared-lock supervisor, one worker,12GiB and900seconds; the fresh audit uses120seconds. Timeout/SIGTERM/BaseException cleanup kills and waits for the process group before releasing the lock. A fresh output directory is mandatory; failures are never overwritten. All202 current source/import/dependency/object/log bindings and every immutable predecessor input are rehashed after the new audit.

Prepared invocation, only after root GO:

```sh
python3 -B /tmp/k215-phase7-legacy/build.py \
  --primary-run /tmp/k215-proof-phase7/lean-run1 \
  --primary-live /tmp/k215-proof-phase7/root-actual-review.json \
  --out /tmp/k215-phase7-legacy/run1 \
  --execute-after-primary-pass
```

The primary result and exact independent root review are mandatory. `freeze.json` binds the driver/gates/inventory/audit/preparation inputs. The metadata controls have6 positives and21 intentional rejections; they execute no compiler or machine. They include all15 actual reuses, hypothetical propagation through exactlythree legacy dependents, graph changes, corrupted object/log/dependency records, missing/wrong audit reports, extra assumptions, and unsafe symlink ownership.

Intended publication: `verification/k215/simplification/phase7/legacy/`, with source/log/record evidence and the old packet references. Exclude compiled objects and preserve phase5/phase6 histories. Claim only the actual incremental result and fresh five-client audit, never a new202-module fresh build.
