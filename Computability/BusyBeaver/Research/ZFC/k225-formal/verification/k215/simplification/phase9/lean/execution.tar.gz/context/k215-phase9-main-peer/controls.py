#!/usr/bin/env python3
"""Read-only metadata controls: never import or launch the candidate build driver."""
import ast,copy,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
DRIVER=Path('/tmp/k215-phase9-main/build.py')
B=Path('/tmp/k215-proof-phase8/lean-run1')
sha=lambda b:hashlib.sha256(b).hexdigest()
s=DRIVER.read_bytes();assert sha(s)=='b4a25e8294178d498be03c30e83ebd0acdd832171a35bd8673c07dcf31b85a79'
tree=ast.parse(s);fs=[x for x in ast.walk(tree)if isinstance(x,ast.FunctionDef)and x.name=='usable'];assert len(fs)==1
# Execute only the pure one-return eligibility predicate, with inert path/hash doubles.
f=fs[0];assert len(f.body)==1 and isinstance(f.body[0],ast.Return)
class File:
 def __init__(self,p):self.p=p
 def is_file(self):return self.p=='object'
values={'object':'objhash','log':'loghash'}
g={'row':{'source_sha256':'sourcehash'},'deps':{'Parent':'currentparent'},'sha':lambda p:values[p.p if isinstance(p,File)else p]}
exec(compile(ast.Module(body=[f],type_ignores=[]),'<pure extracted eligibility>','exec'),g)
usable=g['usable'];valid={'status':'PASS','source_sha256':'sourcehash','dependencies':{'Parent':'currentparent'},'object_sha256':'objhash','log':'log','log_sha256':'loghash','exit_code':0,'timed_out':False}
checks=[]
def observe(name,rec,expected):
 actual=usable(rec,File('object'));assert actual==expected,(name,actual,expected);checks.append({'name':name,'observed':actual,'expected':expected})
observe('matching source and actual direct-provider object',valid,True)
for name,key,value in [('changed source','source_sha256','different'),('stale direct-provider object','dependencies',{'Parent':'oldparent'}),('wrong object hash','object_sha256','different'),('wrong log hash','log_sha256','different'),('failed status','status','FAIL')]:
 r=copy.deepcopy(valid);r[key]=value;observe(name,r,False)
# These are demonstrated missing predicates, not desired rejection controls.
for name,key,value in [('PASS record with timeout is currently accepted','timed_out',True),('PASS record with nonzero exit is currently accepted','exit_code',1)]:
 r=copy.deepcopy(valid);r[key]=value;observe(name,r,True)
result=json.loads((B/'result.json').read_bytes());inventory=(B/'inventory.json').read_bytes();completed=(B/'completed.json').read_bytes()
assert sha((B/'result.json').read_bytes())=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
assert sha(inventory)==result['inventory_sha256'];assert sha(completed)==result['completed_sha256']
ri=json.loads(inventory);rc=json.loads(completed)
assert set(rc)=={x['module']for x in ri['modules']}and len(rc)==188
for row in ri['modules']:
 rec=rc[row['module']];assert rec['source_sha256']==row['source_sha256'];assert rec['dependencies']=={m:rc[m]['object_sha256']for m in row['imports']if m!='Init'}
mutated=json.loads(completed);mutated['BusyBeaver.ZFC.KRuntimeCore']['dependencies']['BusyBeaver.ZFC.KZip']='changed'
assert sha(json.dumps(mutated).encode())!=result['completed_sha256']
out={'status':'PASS_BOUNDED_PURE_METADATA_CONTROLS','driver':{'path':str(DRIVER),'sha256':sha(s)},'pure_eligibility_observations':checks,'actual_phase8_ledger_binding':{'modules':188,'inventory_sha256':sha(inventory),'completed_sha256':sha(completed),'all_direct_dependency_records_consistent':True},'changed_ledger_rejected_by_proposed_result_binding':True,'compiler_invocations':0,'driver_invocations':0,'actual_object_or_log_rehash_claim':False}
(HERE/'controls.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'predicate_observations':len(checks),'basis_ledger_modules':188},indent=2))
