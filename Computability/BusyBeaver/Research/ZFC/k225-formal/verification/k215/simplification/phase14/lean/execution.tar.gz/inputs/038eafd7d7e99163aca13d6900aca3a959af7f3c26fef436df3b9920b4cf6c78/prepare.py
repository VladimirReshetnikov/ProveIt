from pathlib import Path
import hashlib,json,subprocess,re
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');O=Path('/tmp/k215-phase14-profile')
P=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase13/upstream-merge/later-542391'
merge=json.loads((P/'merge.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for row in merge['files']:
 rel=row['original_path']
 if rel.endswith('/README.md'):continue
 data=(R/rel).read_bytes();assert sha(data)==row['checked_sha256']
 old=O/'before'/rel;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(data)
 rec={'path':rel,'before_sha256':sha(data),'before_bytes':len(data),'before_lines':len(data.splitlines()),'before_snapshot':str(old),'delete':row['upstream_deleted']}
 if not rec['delete']:
  p=R/row['preserved_as'];new=p.read_bytes();assert sha(new)==row['sha256'];assert new==subprocess.check_output(['git','show',merge['upstream']+':'+rel],cwd=R)
  out=O/'candidate/BusyBeaver/ZFC'/Path(rel).name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(new)
  rec.update(candidate=str(out),candidate_sha256=sha(new),candidate_bytes=len(new),candidate_lines=len(new.splitlines()),git_blob=row['git_blob'],imports=re.findall(r'(?m)^import (.*)$',new.decode()))
 rows.append(rec)
assert len(rows)==5
retire=[{'path':x['path'],'before_sha256':x['before_sha256'],'before_snapshot':x['before_snapshot'],'required_after':'absent including dangling symlink','scope':'retired copied proof module' if x['path'].endswith('.lean') else 'retired source-copy generator; distinct from the current five phase13 adopted paths'} for x in rows if x['delete']]
(O/'retirements.json').write_text(json.dumps({'status':'PROPOSED_NOT_ADOPTED','files':retire,'preconditions':'Both original canonical files remain present and pinned until authorized checked adoption.','postconditions':'Candidate graph contains no KProfileTC module/import, no live caller or producer route re-creates it; after adoption both paths are absent, archived originals remain exact. Do not delete immutable basis objects or historical receipts.'},indent=2)+'\n')
(O/'source-map.json').write_text(json.dumps({'status':'EXACT_UPSTREAM_SOURCE_OVERLAY_ONLY_UNCOMPILED','current_checkpoint':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'upstream':merge['upstream'],'preserved_map_sha256':sha((P/'merge.json').read_bytes()),'files':rows,'scope':'Three exact Lean candidates, two proposed retirements. No canonical mutation, compiler or producer execution.'},indent=2)+'\n')
print('source-map',sha((O/'source-map.json').read_bytes()))
for x in rows:print(Path(x['path']).name,'delete' if x['delete'] else x['candidate_sha256'])
