from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil

repo = Path('/home/codex/.codex/worktrees/ec20/Proofs')
formal = repo / 'Computability/BusyBeaver/Research/ZFC/k225-formal'
work = Path('/tmp/k215-sites-compact')
canonical = repo / 'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/KSites215.lean'
spec = importlib.util.spec_from_file_location('gen', formal / 'generate_sites215_lean.py')
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
leaf = gen.load(gen.SITES)
blocks, joins, count = gen.cut(leaf, 64)
# Recover the actual cut from the accepted file rather than assume its limit.
import re
batch = canonical.parent / 'KSites215Batch000.lean'
first_count = int(re.search(r'/-- (\d+) leaves', batch.read_text())[1])
for limit in range(first_count, 200):
    trial, _, _ = gen.cut(leaf, limit)
    if len(trial) == 105:
        blocks, joins, count = gen.cut(leaf, limit)
        break
else:
    raise AssertionError('No compatible cut')
actual = []
for path in sorted(canonical.parent.glob('KSites215Batch[0-9][0-9][0-9].lean')):
    for name, bits in re.findall(r'theorem block_(\d+).*?\(descend KSource215.t215 \[([^]]*)\]\)', path.read_text(), re.S):
        actual.append((int(name), tuple(x.strip() == 'true' for x in bits.split(',')) if bits else ()))
assert sorted(actual) == list(enumerate(blocks))
index = {p: n for n, p in enumerate(blocks)}
def term(path, indent=2):
    if path in index:
        return 'block_' + str(index[path])
    return '(allSites_join _ _ _ _\n' + ' ' * (indent + 2) + term(path + (False,), indent + 2) + '\n' + ' ' * (indent + 2) + term(path + (True,), indent + 2) + ')'
before = canonical.read_text()
prefix = before[:before.index('theorem join_')]
suffix = before[before.index('theorem covered :'):]
source = prefix + 'theorem all_sites : allSites (KSim.checkEdge tm215) [] KSource215.t215 = true :=\n  ' + term(()) + '\n\n' + suffix
run = work / 'run1'
run.mkdir(exist_ok=False)
workspace = run / 'workspace'
src = workspace / 'BusyBeaver/ZFC/KSites215.lean'
src.parent.mkdir(parents=True)
src.write_text(source)
shutil.copyfile(canonical, run / 'KSites215.before.lean')
cache = run / 'objects'
cache.mkdir()
basis = Path('/tmp/k215-proof-simplification/root/objects')
for path in basis.rglob('*.olean'):
    target = cache / path.relative_to(basis)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.symlink_to(path)
obj = cache / 'BusyBeaver/ZFC/KSites215.olean'
obj.unlink()
spec = importlib.util.spec_from_file_location('driver', formal / 'verification/k215/lean/build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
lean = Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
env = os.environ.copy()
env['LEAN_PATH'] = str(cache)
env['LEAN_NUM_THREADS'] = '1'
command = [str(lean), '-j1', '-M4096', '--root=' + str(workspace), '-o', str(obj), str(src)]
record = {'source_sha256': driver.sha(src), 'before_sha256': driver.sha(canonical),
          'command': command, 'compiler_sha256': driver.sha(lean), 'timeout_seconds': 120,
          'batch_modules': {p.name: driver.sha(p) for p in canonical.parent.glob('KSites215Batch[0-9][0-9][0-9].lean')},
          'dependencies': {f'BusyBeaver.ZFC.KSites215Batch{i:03}': driver.sha(cache / f'BusyBeaver/ZFC/KSites215Batch{i:03}.olean') for i in range(9)},
          'bootstrap_blocks': len(blocks), 'joins': len(joins), 'bytes_before': len(before.encode()), 'bytes_after': len(source.encode())}
print('CHECK', src, len(source.encode()), flush=True)
ok = driver.run_locked(command, repo, env, Path('/tmp/proveit-k215-proof-build.lock'),
                       run / 'compiler.log', 120, record, run / 'record.json')
log = (run / 'compiler.log').read_text()
ok = ok and 'sorryAx' not in log and "declaration uses 'sorry'" not in log
record['status'] = 'PASS' if ok else 'FAIL'
record['source_unchanged'] = driver.sha(src) == record['source_sha256']
record['canonical_unchanged'] = driver.sha(canonical) == record['before_sha256']
record['warnings'] = log.count('warning:')
if obj.exists():
    record['object_sha256'] = driver.sha(obj)
(run / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
print(log[-14000:], flush=True)
raise SystemExit(0 if ok else 1)
