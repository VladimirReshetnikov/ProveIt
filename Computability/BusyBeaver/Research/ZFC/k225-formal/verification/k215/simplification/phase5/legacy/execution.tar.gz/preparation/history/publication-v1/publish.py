"""Publish completed199-module legacy evidence to a fresh scratch packet only."""
from pathlib import Path
import argparse,gzip,io,json,shutil,tarfile
from evidence import digest,live_check,read,save,sha
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);p.add_argument('--basis',type=Path,required=True);p.add_argument('--primary-packet',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 P=Path(__file__).resolve().parent;assert not a.out.exists()
 m,live=live_check(a.run.resolve(),a.basis.resolve(),P)
 primary=a.primary_packet.resolve();pr=read(primary/'result.json');pl=read(primary/'live-review.json')
 assert all(pr[k]==v for k,v in read(a.run/'basis-result.json').items())
 assert pl==read(a.run/'basis-review.json')
 ref={'scope':'Exact separate primary184 packet; its complete proof evidence is linked, not duplicated.',
      'repository_path':'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase5/lean',
      'files':{n:sha(primary/n)for n in ('execution.tar.gz','index.json','result.json','live-review.json')},
      'original_result_sha256':sha(a.basis/'result.json')}
 m['publication/primary-reference.json']=(json.dumps(ref,indent=2)+'\n').encode()
 m['publication/live-review.json']=(json.dumps(live,indent=2)+'\n').encode()
 a.out.mkdir();idx={n:{'sha256':digest(b),'bytes':len(b)}for n,b in sorted(m.items())}
 with (a.out/'execution.tar.gz').open('xb')as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0)as zipped:
   with tarfile.open(fileobj=zipped,mode='w')as t:
    for n,b in sorted(m.items()):
     info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
 save(a.out/'index.json',idx);save(a.out/'primary-reference.json',ref);save(a.out/'live-review.json',live)
 summary={k:v for k,v in live.items()if k!='evidence_manifest'};summary.update(archive_sha256=sha(a.out/'execution.tar.gz'),archive_members=len(m),compiled_objects_in_archive=False)
 save(a.out/'review.json',summary)
 for n in ('build.py','LegacyAudit.lean','prepared-inventory.json','evidence.py','review_saved.py','README.md'):shutil.copyfile(P/n,a.out/n)
 for n in ('result.json','completed.json','inventory.json'):shutil.copyfile(a.run/n,a.out/n)
 shutil.copyfile(a.run/'audit/compiler.log',a.out/'LegacyAudit.log')
 print(json.dumps({'status':'STAGED_LEGACY_PACKET','out':str(a.out),'archive_bytes':(a.out/'execution.tar.gz').stat().st_size,'members':len(m)},indent=2))
