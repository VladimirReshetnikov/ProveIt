"""Read three frozen source packets as data and normalize only our plan metadata."""
from pathlib import Path
import hashlib,json,re
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
def save(name,data):p=S/name;assert not p.exists();p.write_text(json.dumps(data,indent=2)+'\n')
packets=[(Path('/tmp/k215-phase15-basic'),'449bb955d099f52511f32e22a7adc866fa99571dfcb588b23e88b106862a16d1'),(Path('/tmp/k215-phase15-transrec'),'94769975236f685e0632d958ae1b0b8d1f0859108b8e835a6c4484b0a9e53ca9'),(Path('/tmp/k215-phase15-quotient'),'be2c246be0cd3f98d81310e4bb774ea5ec33a9d23cf4c7420688ce500c902aad')]
inputs={}
for directory,pin in packets:
 f=directory/'freeze.json';assert sha(f)==pin;inputs[str(f)]=pin;rows=read(f)['files']
 if isinstance(rows,dict):rows=[{'path':k,'sha256':v}for k,v in rows.items()]
 for row in rows:
  p=Path(row['path']);p=p if p.is_absolute() else directory/p
  assert sha(p)==row['sha256'];inputs[str(p)]=row['sha256']
basic,trans,quot=[d for d,_ in packets];sources=read(basic/'sources.json');clients=read(basic/'clients.json')
for r in read(trans/'sources.json')['files']:
 name=Path(r['path']).stem;p=trans/'candidate/BusyBeaver/ZFC'/(name+'.lean')
 sources.append({'module':'BusyBeaver.ZFC.'+name,'source':str(p),'source_sha256':r['candidate']['sha256'],'before_sha256':r['before']['sha256'],'canonical':r['path'],'imports':r['imports']})
c=read(trans/'review.json')['new_client'];p=Path(c['path']);clients.append({'module':'TransRec15Api','source':str(p),'source_sha256':c['sha256'],'imports':re.findall(r'(?m)^import (\S+)',p.read_text()),'reports':c['reports'],'profile_policy':'Exact names and standard-only pending first checked report arrays.'})
for r in read(quot/'candidate-map.json')['files']:
 if r['path'].endswith('.lean'):
  sources.append({**r,'module':'BusyBeaver.ZFC.'+Path(r['path']).stem,'canonical':r['path']})
 else:
  assert Path(r['path']).name=='generate_kq1.py';save('producer-proposal.json',{'canonical_before':{'path':str(R/r['path']),'sha256':r['before_sha256']},'candidate':{'path':r['source'],'sha256':r['source_sha256']},'source_packet':str(quot/'freeze.json'),'state':'CANDIDATE_ONLY_NO_EXECUTION_OR_ADOPTION'})
clients.append(read(quot/'client.json'))
assert len(sources)==8 and len(clients)==3
for r in sources+clients:
 assert sha(r['source'])==r['source_sha256'];inputs[r['source']]=r['source_sha256']
save('sources.json',sources);save('clients.json',clients);save('proposal-inputs.json',[{'path':p,'sha256':h}for p,h in sorted(inputs.items())]);print('Registered8sources/3clients/1producer; inert source pins checked',len(inputs))
