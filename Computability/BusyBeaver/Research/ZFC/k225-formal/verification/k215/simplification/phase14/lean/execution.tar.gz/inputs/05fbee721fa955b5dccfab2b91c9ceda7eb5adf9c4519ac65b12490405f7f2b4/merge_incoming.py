from pathlib import Path
import subprocess, json, hashlib
R = Path('/home/codex/.codex/worktrees/ec20/Proofs')
S = Path('/tmp/k215-phase14-root')
run = lambda args: subprocess.check_output(args, cwd=R)
sha = lambda data: hashlib.sha256(data).hexdigest()
head = run(['git','rev-parse','HEAD']).decode().strip()
assert head == '1244fd482745bcd039471d90e35cfba0f9ad12ee'
arrival = 'c3caaf63a4e1b391426501b6bda21f4992d4465f'
assert run(['git','rev-parse','origin/main']).decode().strip() == arrival
assert not run(['git','status','--porcelain','--untracked-files=no'])
paths = ['Computability/BusyBeaver/Lean/BusyBeaver/ZFC/'+n+'.lean' for n in ['InternalRank','TransRec']]
before = {p:(R/p).read_bytes() for p in paths}
proposed = {p:run(['git','show',arrival+':'+p]) for p in paths}
folder = Path('Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase13/upstream-merge/later-c3caaf')
assert not (R/folder).exists()
subprocess.run(['git','merge','--no-commit','--no-ff','origin/main'],cwd=R,check=True)
records=[]; staged=[]
for p in paths:
    assert (R/p).read_bytes() == proposed[p]
    raw = folder/'inputs'/p
    (R/raw).parent.mkdir(parents=True,exist_ok=True)
    (R/raw).write_bytes(proposed[p]); staged.append(str(raw))
    (R/p).write_bytes(before[p])
    records.append({'canonical':p,'preserved_checked_sha256':sha(before[p]),
                    'upstream_source_sha256':sha(proposed[p]),'proposal':str(raw)})
archives=json.loads(Path('/tmp/k215-intake214/arrival.json').read_text())['archives']
for a in archives:
    p=a['archive_path'];assert run(['git','hash-object',p]).decode().strip()==a['archive_blob'];staged.append(p)
record={'status':'UPSTREAM_PROPOSALS_PRESERVED_AS_DATA','arrival':arrival,'checked_head':head,
        'upstream_refactor':'55f600fe7e59c7ba0b6d227b87ed728d8ebd9dee','sources':records,
        'archives':[{'path':a['archive_path'],'blob':a['archive_blob']} for a in archives],
        'scope':'Merge five immutable incoming reports; retain the two unvalidated recursion refactors as attributed data. Checked proof sources and frozen phase14 overlay unchanged.'}
map_path=folder/'merge.json';(R/map_path).write_text(json.dumps(record,indent=2)+'\n');staged.append(str(map_path))
readme=folder/'README.md'
(R/readme).write_text('# Later recursion and report proposals\n\nCommit `c3caaf63a4e1b391426501b6bda21f4992d4465f` adds five proof-simplification archives. Its predecessor `55f600fe7e59c7ba0b6d227b87ed728d8ebd9dee`, co-authored by Claude Opus 5.5, proposes sharing the cumulative and G-hierarchy recursion. The exact two proposed Lean files are retained under `inputs/`; their maintained checked predecessors remain unchanged pending ordinary review and isolated kernel validation. The five archives enter the next intake batch separately. No submitted program, producer or proof compiler was run for this merge. [Bindings](merge.json).\n')
staged.append(str(readme))
subprocess.run(['git','add','--',*paths,*staged],cwd=R,check=True)
actual=run(['git','diff','--cached','--name-only','-z']).decode().split('\0')[:-1]
assert set(actual)==set(staged),(actual,staged)
for p in staged:assert run(['git','show',':'+p])==(R/p).read_bytes(),p
for p in paths:assert (R/p).read_bytes()==before[p] and run(['git','show',':'+p])==before[p]
message=S/'merge-message.txt'
message.write_text('Merge new proof reports while preserving checked K215 sources\n\nImport the five committed c3caaf63a4 arrivals for batch 214. Preserve the exact InternalRank/TransRec proposal from 55f600fe7e as attributed data; keep both maintained checked sources unchanged pending isolated validation. The frozen phase14 seven-source candidate is unaffected. No supplied executable or proof compiler ran for this merge.\n')
subprocess.run(['git','commit','-F',str(message)],cwd=R,check=True)
commit=run(['git','rev-parse','HEAD']).decode().strip()
for p in staged:assert run(['git','show',commit+':'+p])==(R/p).read_bytes(),p
(S/'incoming-merge-actual.json').write_text(json.dumps({'status':'PASS_ACTUAL_INDEX_AND_COMMITTED_BLOBS','commit':commit,'paths':staged,'preserved_sources':records},indent=2)+'\n')
print('COMMITTED',commit,len(staged),'exact paths')
