from pathlib import Path
import hashlib,json
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');F=R/'Computability/BusyBeaver/Research/ZFC/k225-formal';I=F/'verification/k215/simplification/proposals/proof-core/generation/generation';S=Path(__file__).resolve().parent
prefix=(I/'templates/core-prefix.txt').read_text().replace('Thirteen condensed-detachment shortcuts remove 33 of 117 numbered helpers.','Thirteen condensed-detachment shortcuts prune the inherited helper hierarchy.\nThe final proof combines pointwise lifting with the generic core (e94206c09f);\nunused distribution schemas are omitted after a maintained-caller census.')
suffix='''private theorem basisK (a b : A) : T (wim a (wim b a)) := b60 h a b
private theorem basisP (a b : A) : T (wim (wim (wim a b) a) a) := b25 h a b

private theorem composition_seed (a b c : A) : T (wim (wim a b) (wim (wim b c) (wim a c))) := cd91 h a b c

private theorem compose_derived {a b c : A}
    (hab : T (wim a b)) (hbc : T (wim b c)) : T (wim a c) :=
  h.mp (h.mp (composition_seed h a b c) hab) hbc

private theorem under_antecedent (z : A) {x y : A}
    (hxy : T (wim x y)) : T (wim (wim z x) (wim z y)) :=
  h.mp (h.mp (cd103 h (wim z x) (wim x y) (wim z y))
    (composition_seed h z x y)) hxy

/-- Lift Peirce followed by K twice, then apply composition. -/
private theorem rho8_seed (a b c u : A) : T (rho8 L a b c u) := by
  have hqd := compose_derived h (basisP h c u) (basisK h c b)
  exact h.mp (under_antecedent h (wim (wim c u) a)
    (under_antecedent h (wim a c) hqd)) (composition_seed h (wim c u) a c)

end

section
variable {A : Type v} {L : Language A} {T : A → Prop}

private theorem withSeed (h : Restricted L T) (a : A) :
    WithSeed L (rho8 L a a a a) T where
  toRestricted := h
  truth := h.rho8 a a a a (L.refl a)

/-- Restricted rows and modus ponens alone derive every unrestricted row. -/
theorem rho8_all (h : Restricted L T) (a b c u : A) : T (rho8 L a b c u) :=
  rho8_seed (withSeed h a) a b c u

theorem composition (h : Restricted L T) (a b c : A) :
    T (L.imp (L.imp a b) (L.imp (L.imp b c) (L.imp a c))) :=
  composition_seed (withSeed h a) a b c

/-- A proved implication lifts under any antecedent. -/
theorem lift_right (h : Restricted L T) {a b : A} (hab : T (L.imp a b)) (x : A) :
    T (L.imp (L.imp x a) (L.imp x b)) :=
  under_antecedent (withSeed h a) x hab

end
#print axioms rho8_all
#print axioms composition
#print axioms lift_right
end SetTheory.BusyBeaver.ZFC.DominatedImplication
'''
adapter=(I/'templates/adapter.txt').read_text().replace('All original public declarations are retained. The truth field of DomImp is\nkept for API compatibility; the general theorem no longer requires it.','The phase-seven DomImp, rho8_all, composition and lift_right interfaces are\nretained. The truth field remains for compatibility; the general theorem\nrequires only modus ponens and restricted rows. Source 149 / CD230 ancestry\nand the generic-core proposal e94206c09f supply the inherited derivation.')
old='''theorem distribution (a b c : Nat) : T (wim (wim a (wim b c)) (wim (wim a b) (wim a c))) :=
  DominatedImplication.distribution (restricted h.mp h.rho8) a b c'''
new='''theorem lift_right {a b : Nat} (hab : T (wim a b)) (x : Nat) :
    T (wim (wim x a) (wim x b)) :=
  DominatedImplication.lift_right (restricted h.mp h.rho8) hab x'''
assert old in adapter;adapter=adapter.replace(old,new).replace('#print axioms distribution','#print axioms lift_right')
for n,t in [('core-prefix',prefix),('core-suffix',suffix),('adapter',adapter)]: (S/'templates'/f'{n}.txt').write_bytes(t.encode())
producer=(I/'regenerate.py').read_text()
start=producer.index('"""');end=producer.index('"""',start+3)+3
producer=producer[:start]+'''"""Produce the maintained representation-independent implication core and Nat adapter.

Adapted from the attributed proof-core proposal in e94206c09f. It verifies the
thirteen schematic MP replacements and their acyclic dependency closure; Lean
checks the generated proofs. Inputs are exact raw bytes, including line endings.
Use --out LEAN_ROOT to generate, or --check (the default) to compare maintained
sources. The historical generate_domrho8_lean.py retains its inline-proof CLI.
"""'''+producer[end:]
producer=producer.replace('HERE = pathlib.Path(__file__).resolve().parent','''HERE = pathlib.Path(__file__).resolve().parent
INPUTS = HERE / "verification/k215/simplification/proposals/proof-core/generation/generation"
TEMPLATES = HERE / "dominated_implication_templates"
DEFAULT_OUT = HERE.parents[2] / "Lean"
ROOTS = ["b25", "b60", "cd91", "cd103"]
PINS = '''+repr({n:hashlib.sha256((I/n).read_bytes()).hexdigest() for n in ['DomRho8.original.lean','shortcuts.json']})+'''
TEMPLATE_PINS = '''+repr({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((S/'templates').iterdir())})+'''

if not __debug__:
    raise RuntimeError("Producer validation requires normal Python (without -O)")

def pinned_text(path, expected):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected, "input bytes differ: " + str(path)
    return raw.decode("utf-8")''')
producer=producer.replace('    def go(i):','    assert re.sub(r"\\s", "", text) == "".join(toks), "unrecognized term token"\n    def go(i):',1)
producer=producer.replace('cfg = json.loads((HERE / "shortcuts.json").read_text())\n    source = (HERE / "DomRho8.original.lean").read_text()', 'cfg = json.loads(pinned_text(INPUTS / "shortcuts.json", PINS["shortcuts.json"]))\n    source = pinned_text(INPUTS / "DomRho8.original.lean", PINS["DomRho8.original.lean"])')
producer=producer.replace('ordered_closure(cfg["roots"], edges)','ordered_closure(ROOTS, edges)')
producer=producer.replace('core = (HERE / "templates/core-prefix.txt").read_text() + body + (HERE / "templates/core-suffix.txt").read_text()\n    adapter = (HERE / "templates/adapter.txt").read_text()','''core = pinned_text(TEMPLATES / "core-prefix.txt", TEMPLATE_PINS["core-prefix.txt"]) + body + pinned_text(TEMPLATES / "core-suffix.txt", TEMPLATE_PINS["core-suffix.txt"])
    adapter = pinned_text(TEMPLATES / "adapter.txt", TEMPLATE_PINS["adapter.txt"])''')
producer=producer.replace('"source_sha256": digest(source),','"source_sha256": digest(source),\n        "input_raw_sha256": PINS, "template_raw_sha256": TEMPLATE_PINS,\n        "roots": ROOTS,')
a=producer.index('    if args.check or args.out is None:');b=producer.index('    print(json.dumps(metrics, indent=2))',a)
producer=producer[:a]+'''    target = (args.out or DEFAULT_OUT) / "BusyBeaver/ZFC"
    outputs = {"DominatedImplication.lean": core, "DomRho8.lean": adapter}
    if args.check or args.out is None:
        for name, text in outputs.items():
            assert (target / name).read_bytes() == text.encode(), "maintained source bytes differ: " + name
    elif args.out is not None:
        target.mkdir(parents=True, exist_ok=True)
        for name, text in outputs.items():
            (target / name).write_bytes(text.encode())
        (args.out / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\\n")
'''+producer[b:]
(S/'generate_dominated_implication_lean.py').write_text(producer)
legacy=(F/'generate_domrho8_lean.py').read_bytes();needle=b'"""Generate DomRho8.lean: dominated rho8 instances derive every rho8 instance.';assert needle in legacy
(S/'generate_domrho8_lean.py').write_bytes(legacy.replace(needle,b'"""Historical inline DomRho8 proof producer.\n\nThe maintained generic core and adapter are produced by\n`generate_dominated_implication_lean.py`; this CLI retains the earlier inline\ncertificate routes for reproducibility.\n\nGenerate DomRho8.lean: dominated rho8 instances derive every rho8 instance.',1))
# Give the held producer the exact installed-relative inputs and defaults.
(S/'verification/k215/simplification/proposals/proof-core/generation/generation').mkdir(parents=True)
for n in PINS if False else ['DomRho8.original.lean','shortcuts.json']:
 (S/'verification/k215/simplification/proposals/proof-core/generation/generation'/n).write_bytes((I/n).read_bytes())
(S/'dominated_implication_templates').mkdir()
for p in (S/'templates').iterdir(): (S/'dominated_implication_templates'/p.name).write_bytes(p.read_bytes())
print('prepared',S)
