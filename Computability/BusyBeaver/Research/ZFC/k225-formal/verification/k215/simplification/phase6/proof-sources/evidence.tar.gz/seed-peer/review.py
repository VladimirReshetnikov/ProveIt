from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');P=Path('/tmp/k215-seed-semantic-simplification');S=P/'successor';D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=(P/'before.lean').read_text();a=(S/'KSeedModel222.lean').read_text()
def decls(s,kind):
 matches=list(re.finditer(r'^'+kind+r' (\w+)[\s\S]*?(?=\n(?:theorem |def |#print|end |/--|/-!)|\Z)',s,re.M))
 return {m[1]:m[0].rstrip()for m in matches}
bd,ad=decls(b,'def'),decls(a,'def');assert bd==ad
bt,at=decls(b,'theorem'),decls(a,'theorem')
for name in ['seed_of_bundle','seed_eqFree']:
 assert bt[name].split(':=',1)[0]==at[name].split(':=',1)[0]
removed=sorted(set(bt)-set(at));assert removed==['derivable_bundle','enc_dec_enc','enc_pos','eqFree_dec_enc']
result=json.loads((S/'run3/result.json').read_text());assert result['status']=='PASS' and result['exit_code']==0 and not result['timed_out']
assert sha(S/'KSeedModel222.lean')==result['candidate_sha256'];assert sha(S/'Audit.lean')==result['audit_sha256']
assert Path(result['source']).read_bytes()==(S/'KSeedModel222.lean').read_bytes()+(S/'Audit.lean').read_bytes()
assert sha(result['source'])==result['source_sha256']
assert sha(S/'run3/compiler.log')==result['log_sha256']
assert sha(S/'run3/objects/BusyBeaver/ZFC/KSeedModel222.olean')==result['object_sha256']
for p,h in result['inputs'].items():assert sha(p)==h,p
basis=Path('/tmp/k215-proof-phase5/lean-run1/objects')
for m,h in result['basis_objects'].items():assert sha(basis/(m.replace('.','/')+'.olean'))==h,m
names=['SetTheory.BusyBeaver.ZFC.KSeed222.seed_of_bundle','SetTheory.BusyBeaver.ZFC.KSeed222.seed_eqFree','SetTheory.BusyBeaver.ZFC.SeedSemanticAudit.same_endpoint','SetTheory.BusyBeaver.ZFC.KSeed222.derivable_named_bundle']
assert [x[0]for x in result['axiom_reports']]==names
assert result['warnings']==0
for _,axs in result['axiom_reports']:assert set(x.strip()for x in axs.split(','))<={'propext','Classical.choice','Quot.sound'}
# Maintained Lean-tree consumers, excluding the candidate's own baseline module.
hits=subprocess.check_output(['rg','-n',r'\b(enc_dec_enc|eqFree_dec_enc|derivable_bundle|matrix_iff|enc_pos)\b','Computability/BusyBeaver/Lean','--glob','*.lean'],cwd=R,text=True)
outside=[x for x in hits.splitlines()if '/KSeedModel222.lean:' not in x]
assert all('/Code254GIC.lean:' in x and 'enc_pos' in x for x in outside),outside
(D/'consumer-census.txt').write_text(hits)
review={'status':'CLEAN_SOURCE_API_AND_ISOLATED_ACTUAL_PEER','candidate_sha256':sha(S/'KSeedModel222.lean'),'baseline_sha256':sha(P/'before.lean'),'diff_sha256':sha(S/'source.diff'),'result_sha256':sha(S/'run3/result.json'),'log_sha256':sha(S/'run3/compiler.log'),'all_definition_blocks_exact':list(bd),'seed_endpoint_statements_exact':['seed_of_bundle','seed_eqFree'],'removed_unused_helpers':removed,'matrix_iff_change':'Drops unused section hirr premise; five local callers updated; no external maintained consumer found.','remaining_enc_pos':'Code254GIC.enc_pos is a different namespace and remains unchanged.','proof_review':'Uses the already imported sat_encode_decode under the existing irreflexivity premise; double-negation code bound follows from le_P_right and F=1. No new axiom, decoder-identity assertion, or strengthened model premise.','isolated_actual':{'seconds':result['seconds'],'warnings':0,'reports':result['axiom_reports'],'basis_objects_rehashed':len(result['basis_objects']),'input_hashes_rechecked':len(result['inputs'])},'history':'Original literal-proposal PASS with9warnings and syntax-failed cleanup run2 retained; only successor run3 accepted.','scope':'Full candidate/diff/typed-client and reported actual bindings read; no own compiler, no fresh full endpoint rebuild or new toolchain/provider trust audit.','own_script_sha256':sha(__file__)}
(D/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'status':review['status'],'review_sha256':sha(D/'review.json'),'candidate_sha256':review['candidate_sha256'],'basis_objects_rehashed':len(result['basis_objects'])},indent=2))
