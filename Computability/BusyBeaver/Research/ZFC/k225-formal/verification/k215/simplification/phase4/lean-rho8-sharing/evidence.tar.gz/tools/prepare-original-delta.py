"""Create a scratch producer successor from the pinned current producer."""
from pathlib import Path
import hashlib
p=Path('/tmp/k215-domrho8-sharing')
s=(p/'baseline/generate_domrho8_lean.py').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='60023b138276a2e28c469eae805add457443913071a143aaa88f947d187c3551'
def change(old,new):
 global s
 assert s.count(old)==1,(old,s.count(old))
 s=s.replace(old,new)
change('    forms = [expression(n["term"]) for n in nodes]\n', '''    forms = [expression(n["term"]) for n in nodes]
    # Equal schemas share their earliest proof, preserving the Source149 IDs.
    canonical = {i: next(j for j in range(i + 1) if forms[j] == f)
                 for i, f in enumerate(forms)}
''')
change('    def bootstrap_call(i,e):\n        args =', '''    def bootstrap_call(i,e):
        i = canonical[i]
        if forms[i] == truth:
            return "h.truth", truth
        args =''')
change('    bootstrap = []\n    for i,node in enumerate(nodes):\n        assert node["id"] == i\n', '''    bootstrap = {}
    for i,node in enumerate(nodes):
        assert node["id"] == i
        if canonical[i] != i or forms[i] == truth:
            continue
''')
change('        bootstrap.append("private theorem b"+str(i)+binder+" : T "+boot_lean(f)+" :=\\n  "+pf+"\\n")', '        bootstrap[i] = "private theorem b"+str(i)+binder+" : T "+boot_lean(f)+" :=\\n  "+pf+"\\n"')
change('    base={2,3,6,8,9,12,13,15,16,17,25,39,40,59}\n', '''    # A template conclusion already proved in the bootstrap needs no second
    # derivation. Equality is literal after naming its universally bound codes.
    named_boot = {i: substitute(f, {v: "v" + str(v) for v in variables(f)})
                  for i, f in enumerate(forms) if canonical[i] == i}
    reused = {}
    for n, (names, wanted, _) in rows.items():
        target = term(wanted, {v: v for v in names})
        for i, f in named_boot.items():
            if f == target:
                assert variables(forms[i]) == {int(v[1:]) for v in names}
                reused[n] = i
                break
    base={2,3,6,8,9,12,13,15,16,17,25,39,40,59}
''')
change('        if n in base:return frozenset()', '        if n in base or n in reused:return frozenset()')
change('        if n in base or n==0:return', '        if n in base or n in reused or n==0:return')
change('    assert len(used)==81 and sum(bool(guards(n)) for n in used)==8\n','    assert 91 in used and 106 in used\n')
change('        if n not in used:continue', '        if n not in used or n in reused:continue')
change('            j=int(t[0][3:]);assert j<n\n            args=', '            j=int(t[0][3:]);assert j<n\n            args=') # explicit unchanged boundary
change('            pf="(cd"+str(j)+" h "+" ".join(map(lean,args))+(" "+" ".join(bs) if bs else "")+")"', '''            if j in reused:
                i = reused[j]
                assert not bs
                assert substitute(named_boot[i], env) == term(rows[j][1], env, False)
                pf = "(b" + str(i) + " h " + " ".join(lean(env["v" + str(v)])
                       for v in sorted(variables(forms[i]))) + ")"
            else:
                pf="(cd"+str(j)+" h "+" ".join(map(lean,args))+(" "+" ".join(bs) if bs else "")+")"''')
# named_boot contains string variable names; the generic substitute helper sends
# other atoms to truth, so use the template substitution helper at this boundary.
change('assert substitute(named_boot[i], env) == term(rows[j][1], env, False)',
       'assert subst(named_boot[i], env) == term(rows[j][1], env)')
change('    return GUARDED_HEAD+"\\n".join(bootstrap)+GUARDED_MIDDLE+"\\n".join(lemmas)+"\\n"+GUARDED_TAIL', '''    # Retain only actual proof dependencies after schema reuse. Source149 node
    # labels remain stable, making each retained statement easy to cross-check.
    keep = set()
    def retain(i):
        if i in keep:
            return
        keep.add(i)
        for parent in map(int, re.findall(r"\\bb(\\d+)\\b", bootstrap[i].split(":=", 1)[1])):
            assert parent < i
            retain(parent)
    for i in map(int, re.findall(r"\\bb(\\d+)\\b", GUARDED_MIDDLE + "\\n".join(lemmas))):
        retain(i)
    header = GUARDED_HEAD.replace("A 61-lemma bootstrap", "A " + str(len(keep)) + "-lemma bootstrap")
    header = header.replace("We retain 81 of its 107\\nschemas; eight carry", "We retain " +
                            str(len(lemmas)) + " of its 107\\nschemas; " +
                            str(sum(bool(guards(n)) for n in used if n not in reused)) + " carry")
    header = header.replace("The bootstrap is Source 149's original nodes0..60;", 
                            "The bootstrap shares and prunes Source 149's original nodes0..60;")
    header = header.replace("Every emitted\\nstep is", "Duplicate template conclusions reuse bootstrap lemmas. Every emitted\\nstep is")
    print("retained bootstrap", len(keep), "CD templates", len(lemmas),
          "reused template conclusions", len(used & reused.keys()))
    return header+"\\n".join(bootstrap[i] for i in sorted(keep))+GUARDED_MIDDLE+"\\n".join(lemmas)+"\\n"+GUARDED_TAIL''')
change('    print("wrote guarded hierarchy:61 bootstrap +81 CD templates + deduction")',
       '    print("wrote shared guarded hierarchy and deduction")')
(p/'generate_shared.py').write_text(s)
