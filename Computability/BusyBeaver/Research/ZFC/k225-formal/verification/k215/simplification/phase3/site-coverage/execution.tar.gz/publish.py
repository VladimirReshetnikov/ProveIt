from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import shutil
import tarfile

repo = Path('/home/codex/.codex/worktrees/ec20/Proofs')
work = Path('/tmp/k215-sites-compact')
formal = repo / 'Computability/BusyBeaver/Research/ZFC/k225-formal'
dest = formal / 'verification/k215/simplification/phase3/site-coverage'
dest.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
record = json.loads((work / 'run1/result.json').read_text())
api = json.loads((work / 'api-result.json').read_text())
assert record['status'] == api['status'] == 'PASS'
assert record['warnings'] == 0 and record['exit_code'] == 0 and not record['timed_out']
assert record['source_unchanged'] and record['canonical_unchanged']
source = work / 'run1/workspace/BusyBeaver/ZFC/KSites215.lean'
assert sha(source) == record['source_sha256']
assert sha(work / 'run1/objects/BusyBeaver/ZFC/KSites215.olean') == record['object_sha256']
assert sha(work / 'run1/compiler.log') == record['log_sha256']
for control in ['regeneration.json', 'prepare-control.json']:
    assert json.loads((work / control).read_text())['status'] == 'PASS'
for old, new in [(source, 'KSites215.lean'), (work / 'run1/result.json', 'source-check.json'),
                 (work / 'api-result.json', 'api-check.json'), (work / 'Audit.lean', 'Audit.lean'),
                 (work / 'audit-after/compiler.log', 'api.log'),
                 (work / 'regeneration.json', 'regeneration.json'),
                 (work / 'prepare-control.json', 'prepare-control.json')]:
    shutil.copyfile(old, dest / new)
peer = Path('/tmp/k215-sites-compact-peer')
for name in ['review.json', 'review.py']:
    path = peer / name
    if path.exists():
        shutil.copyfile(path, dest / ('independent-' + name))
files = []
for path in sorted(work.rglob('*')):
    if not path.is_file() or path.is_symlink():
        continue
    if any(part in {'objects', '__pycache__', 'prepare-control', 'regenerated', 'production'}
           for part in path.relative_to(work).parts):
        continue
    if path.suffix in {'.lean', '.json', '.log', '.py', '.stdout'}:
        files.append(path)
index = {str(path.relative_to(work)): sha(path) for path in files}
with (dest / 'execution.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for path in files:
                data = path.read_bytes()
                entry = tarfile.TarInfo(str(path.relative_to(work)))
                entry.size = len(data)
                entry.mode = 0o644
                entry.mtime = 0
                archive.addfile(entry, io.BytesIO(data))
(dest / 'execution-index.json').write_text(json.dumps(index, indent=2) + '\n')
result = {
    'status': 'PASS_ISOLATED_KERNEL_TYPED_API_AND_REGENERATION',
    'source_sha256': record['source_sha256'], 'before_sha256': record['before_sha256'],
    'bytes_before': record['bytes_before'], 'bytes_after': record['bytes_after'],
    'blocks_unchanged': 105, 'all_nine_batch_files_unchanged': True,
    'composed_joins': 104, 'source_check_sha256': sha(dest / 'source-check.json'),
    'api_check_sha256': sha(dest / 'api-check.json'),
    'archive_sha256': sha(dest / 'execution.tar.gz'),
    'archive_members': len(files), 'canonical_adoption': 'Pending the frozen phase2 closure check.',
    'independent_review_sha256': sha(dest / 'independent-review.json'),
    'endpoint_scope': 'This packet checks the coverage facade and its two public theorem types. '
                      'The combined current endpoint check is recorded separately.',
}
(dest / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
generator = os.path.relpath(formal / 'generate_sites215_lean.py', dest)
(dest / 'README.md').write_text(f'''# Compose the checked site blocks directly

The coverage facade shrinks from 107,243 to 14,916 bytes. A single nested proof
composes the same 105 kernel-checked blocks with `allSites_join`, replacing 104
named intermediate joins and their repeated Boolean paths. The nine batch files,
all 4,751 leaf checks, and the public `all_sites` and `covered` statements stay
unchanged. No external Lean source uses the removed intermediate names.

The [exact candidate](KSites215.lean) passed in 1.066 seconds with zero warnings.
The [typed client](Audit.lean) checks both public theorem types; its
[axiom reports](api.log) match the original facade exactly: `propext` for
`all_sites`, and `propext`, `Quot.sound` for `covered`.

The producer change is retained in the [execution archive](execution.tar.gz).
The [regeneration control](regeneration.json) reproduces the checked bytes and
all nine unchanged batch files. A separate [preparation control](prepare-control.json)
keeps both maintained generators intact and reproduces the other five preparation
outputs exactly. The maintained [site generator]({generator}) receives this
change when the candidate is adopted after the frozen phase2 check.

An [independent review](independent-review.json) expands the original named
joins and checks that the new proof uses the identical tree, with every block
appearing exactly once. It also checks the public theorem statements, saved
kernel records, and generator/preparation changes.

The [result](result.json), [source record](source-check.json),
[client record](api-check.json), and [archive index](execution-index.json) retain
the execution boundaries. This isolated facade check does not by itself record
a rebuild of the combined current endpoint.
''')
print('PUBLISHED', len(files), 'members', sha(dest / 'result.json'))
