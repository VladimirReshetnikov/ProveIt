"""Pure metadata controls: no collector, prior reader, compiler or producer runs."""
from pathlib import Path
import argparse, copy, json, tempfile
import packet

def controls():
 checks = []
 def test(name, action, expected):
  try: action(); accepted = True
  except (AssertionError, KeyError): accepted = False
  assert accepted == expected, (name, accepted, expected)
  checks.append({'name': name, 'expected_accept': expected, 'matched': True})
 for name in ['review/record.json', 'fresh/source.lean']: test('safe '+name, lambda name=name: packet.safe(name), True)
 for name in ['', '/absolute', '../escape', 'a/../../escape', 'x.olean', 'x.olean.server', 'x.olean.private', 'x.ilean', 'x.vo', 'x.pyc', 'x.pyo', 'x.tar.gz', 'x.zip', 'x.so']:
  test('reject '+name, lambda name=name: packet.safe(name), False)
 def route(change=None):
  data = b'payload'; row = {'storage': 'packet', 'key': 'data', 'sha256': packet.digest(data), 'bytes': len(data)}
  if change: change(row)
  packet.resolve_routes({'data': data}, {'data': data}, {'/source': row})
 test('current route', route, True)
 test('phase13 route', lambda: route(lambda r: r.update(storage='phase13')), True)
 test('wrong predecessor', lambda: route(lambda r: r.update(storage='phase12')), False)
 test('wrong hash', lambda: route(lambda r: r.update(sha256='0'*64)), False)
 test('wrong length', lambda: route(lambda r: r.update(bytes=0)), False)
 def ancestry(change=None):
  old = {'A': {'source_sha256': 'a', 'imports': ['Init']}, 'B': {'source_sha256': 'b', 'imports': ['A']}, 'C': {'source_sha256': 'c', 'imports': ['B']}}
  now = copy.deepcopy(old)
  if change: change(now)
  # Direct B object bytes may remain identical: source closure still rejects C.
  packet.same_source_closure(now, old, {'A', 'B', 'C'})
 test('same recursive source boundary', ancestry, True)
 test('changed grandparent despite identical intermediate object', lambda: ancestry(lambda r: r['A'].update(source_sha256='changed')), False)
 test('changed import', lambda: ancestry(lambda r: r['B'].update(imports=['Init'])), False)
 old = {'source_sha256': 'a', 'object_sha256': 'b', 'dependencies': {'Parent': 'c'}, 'log_sha256': 'd', 'status': 'PASS', 'origin': 'old'}
 test('origin-only reuse', lambda: packet.exact_reuse({**old, 'origin': 'secondary_checked'}, old, 'secondary_checked'), True)
 test('exact successful partial resume',lambda:packet.exact_resume(old,old),True)
 test('resume origin rewritten',lambda:packet.exact_resume({**old,'origin':'candidate_fresh'},old),False)
 test('failed record cannot resume',lambda:packet.exact_resume({**old,'status':'FAIL'},{**old,'status':'FAIL'}),False)
 for key in ['source_sha256', 'object_sha256', 'dependencies', 'log_sha256', 'status']:
  test('reuse mutation '+key, lambda key=key: packet.exact_reuse({**old, 'origin': 'secondary_checked', key: 'changed'}, old, 'secondary_checked'), False)
 empty = b"'Exact.client' does not depend on any axioms\n"
 standard = b"'Exact.client' depends on axioms: [propext, Quot.sound]\n"
 test('constructive report', lambda: packet.named_reports(empty, ['Exact.client'], [[]]), True)
 test('numeric profile', lambda: packet.named_reports(standard, ['Exact.client'], [packet.PQ]), True)
 test('wrong named theorem', lambda: packet.named_reports(empty, ['Other.client'], [[]]), False)
 test('constructive profile grew', lambda: packet.named_reports(standard, ['Exact.client'], [[]]), False)
 test('compatibility models gains choice', lambda: packet.named_reports(b"'Exact.client' depends on axioms: [propext, Classical.choice, Quot.sound]\n", ['Exact.client'], [packet.PQ]), False)
 test('numeric profile missing', lambda: packet.named_reports(empty, ['Exact.client'], [packet.PQ]), False)
 for module,rows in packet.NEW_PROFILES.items():
  raw=''.join("'%s' depends on axioms: [%s]\n"%(n,', '.join(ax)) for n,ax in rows).encode()
  test('exact actual '+module,lambda raw=raw,rows=rows:packet.named_reports(raw,[n for n,_ in rows],[ax for _,ax in rows]),True)
 test('unknown axiom', lambda: packet.named_reports(b"'Exact.client' depends on axioms: [Custom]\n", ['Exact.client']), False)
 test('sorry rejected', lambda: packet.reports(b'sorryAx'), False)
 test('error rejected', lambda: packet.reports(b'error: failed'), False)
 test('audit warning', lambda: packet.named_reports(b'warning: x\n'+empty, ['Exact.client']), False)
 test('extra report', lambda: packet.named_reports(empty+empty, ['Exact.client']), False)
 def assertion(value): assert value
 test('Init-only boundary', lambda: assertion(packet.explicit_externals([{'module': 'A', 'imports': ['Init']}]) == ['Init']), True)
 test('unknown external', lambda: packet.explicit_externals([{'module': 'A', 'imports': ['Untrusted']}]), False)
 with tempfile.TemporaryDirectory(prefix='phase14-metadata-') as directory:
  p = Path(directory)/'retired'; test('absent template', lambda: packet.absent(p), True)
  p.symlink_to(Path(directory)/'missing'); test('dangling template', lambda: packet.absent(p), False)
 return {'status': 'PASS_METADATA_ONLY', 'positive': sum(c['expected_accept'] for c in checks), 'negative': sum(not c['expected_accept'] for c in checks), 'checks': checks, 'compiler_producer_collector_prior_reader_invoked': False, 'inputs': {str(p): packet.sha(p) for p in [Path(__file__), Path(packet.__file__)]}}

if __name__ == '__main__':
 parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--output', type=Path, required=True); args = parser.parse_args(); assert not args.output.exists()
 result = controls(); args.output.write_bytes(packet.dump(result)); print(json.dumps(result, indent=2))
