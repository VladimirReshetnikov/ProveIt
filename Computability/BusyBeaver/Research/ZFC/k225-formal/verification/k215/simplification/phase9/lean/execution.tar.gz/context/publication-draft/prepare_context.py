"""Freeze only small, completed scratch histories; never collect the live full run."""
from pathlib import Path
import json
from evidence import binary_name, digest, dump
HERE=Path(__file__).resolve().parent
BASE=Path('/tmp')
TREES=[
 'k215-phase9-home', 'k215-phase9-extra', 'k215-phase9-zipbridge',
 'k215-phase9-decoder-compact', 'k215-phase9-decoder-routes', 'k215-phase9-decoder-prefix',
 'k215-phase9-decoder-routes-peer', 'k215-phase9-formal-table-peer',
 'k215-phase9-decoder-prefix-peer', 'k215-phase9-decoder-compact-peer',
 'k215-phase9-home-integration-peer', 'k215-phase9-transitive-peer', 'k215-phase9-main-peer',
]
NEW_SOURCE_NAMES={'FramedWindow','KZipTape','KRuntimeCore','KHome','KHomeBoundary','KHomeReady',
 'KSim','DecoderCertificate','K215Decoder','DecoderPaths','DecoderSourceBinding','KDecoderPrefix215',
 'KHomeRuntimeAudit','RuntimeAudit','ReadyControls','KHomeReadyControls'}
EXTENSIONS={'.json','.py','.md','.diff','.log','.stdout','.stderr','.lean','.txt'}


def main():
    assert not (HERE/'context.json').exists(), 'Preserve the original context manifest; make an explicit successor'
    rows=[]
    for name in TREES:
        root=BASE/name
        assert root.is_dir(),root
        for path in sorted(root.rglob('*')):
            parts=path.relative_to(root).parts
            if any(p in {'objects','__pycache__','.lake','solver-venv'} for p in parts):continue
            assert not path.is_symlink(),path
            if not path.is_file() or binary_name(path) or path.suffix not in EXTENSIONS:continue
            if path.suffix=='.lean' and path.stem not in NEW_SOURCE_NAMES:continue
            data=path.read_bytes();rows.append({'path':str(path),'member':'context/'+name+'/'+path.relative_to(root).as_posix(),
                'sha256':digest(data),'bytes':len(data)})
    main=BASE/'k215-phase9-main'
    for path in sorted(main.glob('*.py'))+sorted(main.glob('integration-*.json')):
        data=path.read_bytes();rows.append({'path':str(path),'member':'context/k215-phase9-main/'+path.name,
            'sha256':digest(data),'bytes':len(data)})
    # Both isolated attempts are finished, including the original warning-qualified run.
    for name in ('isolated-run1','isolated-run2'):
        root=main/name
        for path in sorted(root.rglob('*')):
            parts=path.relative_to(root).parts
            if any(p in {'objects','__pycache__'} for p in parts):continue
            assert not path.is_symlink(),path
            if not path.is_file() or binary_name(path) or path.suffix not in EXTENSIONS:continue
            if path.suffix=='.lean' and path.stem not in NEW_SOURCE_NAMES:continue
            data=path.read_bytes();rows.append({'path':str(path),'member':'context/k215-phase9-main/'+name+'/'+path.relative_to(root).as_posix(),
                'sha256':digest(data),'bytes':len(data)})
    assert len({r['path']for r in rows})==len(rows) and len({r['member']for r in rows})==len(rows)
    result={'status':'FROZEN_PRETERMINAL_CONTEXT_ONLY','files':rows,
            'scope':'Original draft/failed/successful isolated sources, records and source peers. No full-run2 capture or endpoint claim. ReadyControls source history remains original; any subsequent actual check is additive.'}
    (HERE/'context.json').write_bytes(dump(result))
    print(json.dumps({'files':len(rows),'bytes':sum(r['bytes']for r in rows),'sha256':digest(dump(result))},indent=2))

if __name__=='__main__':main()
