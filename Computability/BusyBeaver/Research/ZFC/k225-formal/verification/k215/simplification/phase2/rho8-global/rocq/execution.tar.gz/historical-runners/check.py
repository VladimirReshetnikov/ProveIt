"""Small additive Rocq exact-target test; baseline objects are read-only."""
from pathlib import Path
import fcntl, hashlib, json, os, signal, subprocess, sys, time

base=Path(__file__).parent
old=Path('/tmp/k215-rocq-complete')
plan=json.loads((old/'plan.json').read_text())
toolchain=json.loads((old/'toolchain.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
compiler=Path('/home/codex/.opam/proofs-rocq91/bin/coqc')
assert sha(compiler)==toolchain['coqc_sha256']
name=sys.argv[1]
assert name in ['DomRho8','ThmDomClient']
source=base/(name+'.v');out=base/('run-'+name);out.mkdir(exist_ok=False)
dependencies=['K230L.Codes230'] if name=='DomRho8' else ['K215F.Codes222','K215F.Thm222']
inputs={str(source):sha(source),str(compiler):sha(compiler),str(old/'toolchain.json'):sha(old/'toolchain.json')}
seen=set()
def bind(m):
    if m in seen:return
    seen.add(m)
    for d in plan['modules'][m]['dependencies']:bind(d)
    p=Path(plan['modules'][m]['target']).with_suffix('.vo')
    inputs[str(p)]=sha(p)
for m in dependencies:bind(m)
if name=='ThmDomClient':inputs[str(base/'DomRho8.vo')]=sha(base/'DomRho8.vo')
argv=[str(compiler),*plan['flags'],'-Q',str(base),'','-w','-deprecated,-notation-overridden',str(source)]
env=json.loads(subprocess.check_output(['opam','exec','--switch=proofs-rocq91','--','python3','-c','import os,json;print(json.dumps(dict(os.environ)))'],text=True))
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
record={'command':argv,'inputs':inputs,'cap_seconds':120,'scope':'Isolated exact-target and caller test against unchanged baseline dependencies.'}
(out/source.name).write_bytes(source.read_bytes())
print('WAIT_SHARED_LOCK',flush=True)
with open('/tmp/proveit-k215-proof-build.lock','a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    with (out/'compiler.log').open('w') as log:
        start=time.monotonic();p=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        try:
            record['exit_code']=p.wait(timeout=120);record['timed_out']=False
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);p.wait();record.update(exit_code=p.returncode,timed_out=True)
        except BaseException:
            os.killpg(p.pid,signal.SIGKILL);p.wait();raise
        record['seconds']=time.monotonic()-start
log=(out/'compiler.log').read_text()
record['inputs_unchanged']=all(sha(Path(p))==h for p,h in inputs.items())
record['closed_reports']=log.count('Closed under the global context')
record['expected_closed_reports']=2 if name=='DomRho8' else 1
record['log_sha256']=sha(out/'compiler.log')
record['status']='PASS' if record['exit_code']==0 and record['inputs_unchanged'] and record['closed_reports']==record['expected_closed_reports'] and 'Axioms:' not in log else 'FAIL'
if record['exit_code']==0:record['object_sha256']=sha(source.with_suffix('.vo'))
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='inputs'},indent=2));print(log)
sys.exit(0 if record['status']=='PASS' else 1)
