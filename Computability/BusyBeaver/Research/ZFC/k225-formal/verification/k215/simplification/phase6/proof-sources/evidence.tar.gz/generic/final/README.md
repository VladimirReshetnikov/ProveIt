# Decoder-parametric normalized source checker

The new `RMNormalizedBisim.WithDecoder` module adapts the checker delivered as Source168/batch205A. Its normalized path relation and soundness argument are that contribution's work; the original source and notice are preserved in the parent directory. This successor factors out its fixed decoder and reuses the maintained `RMBisim.WithDecoder.getc`. It changes no maintained source or old API.

`WithDecoder.check_halts_iff` takes any function `Nat → List Bool`, any two path programs, any certificate tree, a checked initial branch and checked entries. It proves halting equivalence from the empty pointer for every register file. No decoder injectivity, size bound, certificate-tree shape or program well-formedness hypothesis is added. A certificate denotes the paths actually returned by lookup/decoding; failed segment or lookup evaluation is rejected.

`Rel` saturates those decoded paths by equality of their implicit zero-extended bits. `tsite_ipeq` transports the complete leaf observation, including the consumed path. The checker still applies `incPath` and `breakPath` to that full consumed path. Only branch endpoint comparison uses padding equivalence. This is why dropping trailing zeros from the relation is sound while blindly trimming a path before its branch update would not be justified.

The final API contains `zeros`, `zeros_ok`, `ibeq`, `ibeq_ok`, `tsite_ipeq`, and the decoder-parametric `WithDecoder` lookup/relation/checker/soundness declarations. The experimental outer fixed512 facade from run1 was removed: the two maintained Lean roots contain no prior import or reference to this new module. The inherited `RMBisim.decode`, default checker and all existing endpoints remain unchanged. K215's caller supplies `fun n => RMBisim.decodeAux 512 n []` explicitly.

The final candidate is165 lines/6,365 bytes. The submitted original is161 lines; this is an API adaptation supporting its smaller certificate, not a claim that these four extra lines shorten the inherited checker. Concrete1,426-entry certificate integration, stable program-data separation and a combined endpoint rebuild are separate next steps.

## Isolated check

`run2/result.json` records a single bounded Lean4.32.0 invocation containing the exact candidate followed by `Audit.lean`. It passed in0.816 seconds with no warnings. Ten named reports check the generic endpoint, explicit512 instance, unchanged default128 lookup/endpoint, actual176-bit decoding lengths, padding equality, a differing bit and missing lookup. The three halting clients depend only on `propext` and `Quot.sound`; the other seven reports are closed.

The compiler used one worker, a120-second wall cap and12GiB memory cap under the shared proof-build lock. Every phase5 provider was symlinked read-only into a new overlay; the new target was unlinked before writing. All184 basis object hashes and all current source/input pins were rechecked after compilation. No old object or receipt was overwritten. The first wrapper-bearing candidate also passed and remains preserved under `../run1`.

The kernel-checked source snapshot includes the appended controls. Its prefix is exactly `RMNormalizedBisim.lean`; this receipt does not claim an independent concrete K215 certificate or full endpoint rebuild. No Rocq work was performed.

## Files

- `source.diff`: complete submitted-original to final delta.
- `successor.diff`: removal of the first experimental facade.
- `prepare.py`: deterministic final adaptation from the preserved first candidate.
- `run.py`, `Audit.lean`, `run2/{before.json,result.json,compiler.log,workspace/}`: exact isolated inputs and execution evidence.
- `import-census.json`: no existing maintained import/reference, excluding submitted proposal copies.
- `freeze.json`: final source/API/evidence pins.

Original attribution and the first producer/source remain in the parent directory. All preparation-status files retain their original pre-execution wording; the actual result and freeze provide the later status.
