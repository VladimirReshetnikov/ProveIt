# Compact routed decoder successor

This scratch successor removes seven unused forgetful research declarations. The retained endpoints preserve the complete source word and `RolePath`; no theorem statement, proof body, finite certificate or primitive action is weakened. The exact symbolic `leafPort` and its uniformly quantified zipper endpoint remain byte-identical to prefix v3.

The five supplied files decrease from **72,386 to 67,528 bytes** and from **1,631 to 1,550 lines**. `DecoderCertificate`, `K215Decoder` and `KDecoderPrefix215` are unchanged. The 4,858-byte reduction is entirely in `DecoderPaths` and `DecoderSourceBinding`, including the deleted wrappers' comments; it is not a full maintained-coverage saving.

Deleted declarations: `Entry`, `RoutedEntry.forget`, `source_path_chain`, `source_path_run`, `reaches_primitive`, `upstream_leaf_reaches`, and `upstream_walk_reaches`. Their only callers in the checked research source group were one another and three axiom probes. Those probes now name the corresponding routed theorems. All retained declaration bodies and types compare exactly after removing comments and whitespace.

`prepare.py` is the executed author-owned source transformation. `freeze.json` binds all before/after files, import lists, reports and size counts; per-module diffs are adjacent. An additional source-binding control compares all four route inputs to the parent's held formal-table-v2 freeze. No compiler or maintained-source mutation was performed by this author. The parent compiled the six-module formal-table-v2 and prefix-v3 predecessors successfully; this compact successor requires its own affected-module check.

The two external providers remain the parent's unchanged `FramedWindow` and `KZipTape`. Primitive execution, register branches, overflow/spares and exact return targets remain separate. This packet supplies no replacement for the 6,176 primitive outcomes or the maintained complete coverage proof.
