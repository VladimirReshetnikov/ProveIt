from pathlib import Path
import argparse, hashlib, json, shutil, subprocess
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
repo=a.repo.resolve();out=a.out.resolve();out.mkdir();base=repo/'Computability/BusyBeaver';formal=base/'Research/ZFC/k225-formal';canonical=base/'Lean/BusyBeaver/ZFC';d=out/'BusyBeaver/ZFC';d.mkdir(parents=True)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
inputs=['L2Lib222','L2Macros222','L2Control222','L2Axioms222','L2Root222','Seed222']
for name in inputs:shutil.copyfile(canonical/(name+'.lean'),d/(name+'.lean'))
tasks=[('generate_l2dom.py',[formal/'lean219/dag222_nodes.json',formal/'lean217/dagdom_nodes.json'],['L2Dom']),('generate_l2dom.py',[formal/'lean219/dag222_nodes.json',formal/'lean215/dagperm_nodes.json','perm'],['L2Perm']),('generate_l2rootdom.py',[],['L2RootDom','SeedDom']),('generate_l2q219.py',[],['L2Root219'])]
rows=[]
for script,args,names in tasks:
 command=['python3','-B',str(formal/script),*map(str,args)]
 r=subprocess.run(command,cwd=out,text=True,capture_output=True)
 row={'command':command,'generator_sha256':sha(formal/script),'data_inputs':{str(x):sha(x)for x in args if isinstance(x,Path)},'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'outputs':{}}
 assert r.returncode==0,row
 for name in names:
  actual=d/(name+'.lean');expected=canonical/(name+'.lean');row['outputs'][name]={'sha256':sha(actual),'byte_exact':actual.read_bytes()==expected.read_bytes()}
  assert row['outputs'][name]['byte_exact'],name
 rows.append(row)
summary={'status':'PASS_BYTE_EXACT','driver_sha256':sha(__file__),'inputs':{str(canonical/(n+'.lean')):sha(canonical/(n+'.lean'))for n in inputs},'checks':rows}
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS',sum(len(r['outputs'])for r in rows),'generated files')
