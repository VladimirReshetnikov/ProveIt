"""Read-only candidate registration and virtual import census; never adopts files."""
from pathlib import Path
import hashlib,importlib.util,json,re
P=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
B=Path('/tmp/k215-proof-phase7/lean-run1');I=Path('/tmp/k215-phase8-implication');S=Path('/tmp/k215-phase8-seed-sharing/candidate')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((B/'inventory.json').read_text());by={r['module']:r for r in old['modules']}
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
spec=importlib.util.spec_from_file_location('phase8_inventory_parser',H);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
spec=importlib.util.spec_from_file_location('phase8_registration_gates',P/'gates.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
files=[];maprows=[];candidate_modules=dict(by)
for m in ['BusyBeaver.ZFC.DominatedImplication','BusyBeaver.ZFC.DomRho8','BusyBeaver.ZFC.KSeed222','BusyBeaver.ZFC.KSeedModel222']:
 name=m.split('.')[-1]+'.lean';src=I/'candidate/BusyBeaver/ZFC'/name if m.endswith(('DominatedImplication','DomRho8'))else S/name
 destination='Computability/BusyBeaver/Lean/'+m.replace('.','/')+'.lean'
 imports=[m for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',h.without_comments_strings(src.read_text()))for m in line.split()]
 row={'kind':'lean','module':m,'destination':destination,'before_sha256':by[m]['source_sha256']if m in by else None,'sha256':sha(src),'bytes':src.stat().st_size,'imports':imports}
 candidate_modules[m]={'module':m,'source':str(R/destination),'source_sha256':row['sha256'],'imports':imports}
 files.append(row);maprows.append({'source':str(src),**row})
for destination,kind in g.PRODUCTION_PATHS.items():
 relative=destination[len(g.FORMAL_PREFIX):]
 src=I/relative
 assert src.is_file() and not src.is_symlink()
 if relative.startswith('dominated_implication_templates/'):
  assert src.read_bytes()==(I/'templates'/Path(relative).name).read_bytes()
 before=R/destination
 row={'kind':kind,'destination':destination,'before_sha256':sha(before)if before.is_file()else None,'sha256':sha(src),'bytes':src.stat().st_size}
 files.append(row);maprows.append({'source':str(src),**row})
reg={'status':'REGISTERED_FOR_COMBINED_CHECK_NOT_YET_VERIFIED','basis_result_sha256':g.BASIS_RESULT_SHA256,'basis_project_modules':187,'primary_project_modules':188,'files':files}
rows=[];seen=set();active=set();external=set()
def visit(m):
 if m in seen:return
 if m=='Init':external.add(m);return
 assert m in candidate_modules and m not in active
 active.add(m)
 for d in candidate_modules[m]['imports']:visit(d)
 active.remove(m);seen.add(m);rows.append(candidate_modules[m])
visit(old['target']);new={'target':old['target'],'modules':rows,'external_imports':sorted(external)}
assert len(rows)==188 and external=={'Init'}
checked=g.checkpoint(old,new,reg,R)
# Original canonical checkpoint is still phase7; registration itself mutates none.
for e in old['modules']:assert sha(e['source'])==e['source_sha256']
for row in maprows:
 if row['kind']=='lean' and row['module']in by:assert sha(R/row['destination'])==row['before_sha256']
for name,data in [('registered-adoption.json',reg),('prospective-inventory.json',new),('candidate-copy-map.json',{'status':'REGISTERED_SCRATCH_CANDIDATES_NOT_ADOPTED','rows':maprows}),('prospective-census.json',{'status':'PASS_VIRTUAL_REGISTERED_CLOSURE_NO_COMPILER','basis_inventory_sha256':sha(B/'inventory.json'),'registered_file_count':len(files),'source_count':len(rows),'external_imports':['Init'],**checked})]:
 (P/name).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'status':'REGISTERED_NOT_ADOPTED_OR_COMPILED','registration_sha256':sha(P/'registered-adoption.json'),'files':len(files),'modules':len(rows),'potentially_affected':len(checked['potentially_affected_modules'])},indent=2))
