"""Control only the extracted provider-alias checks and unlink statement; no compiler."""
from pathlib import Path
import ast,hashlib,json,tempfile
ROOT=Path(__file__).parent;SOURCE=Path('/tmp/k215-proof-phase5/build.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tree=ast.parse(SOURCE.read_text());function=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='check_current')
loop=next(n for n in function.body if isinstance(n,ast.For) and ast.unparse(n.iter)=='done.items()')
code=compile(ast.Module(body=[loop],type_ignores=[]),str(SOURCE),'exec')
unlink=next(n for n in ast.walk(tree) if isinstance(n,ast.Expr) and ast.unparse(n)=='obj.unlink(missing_ok=True)')
unlink_code=compile(ast.Module(body=[unlink],type_ignores=[]),str(SOURCE),'exec')
checks=[]
guards=[n for n in ast.walk(tree) if isinstance(n,ast.Assert) and ast.unparse(n.test) in ["set(old) - project == {'BusyBeaver.ZFC.RMOffsetBisim'}", "project <= set(old)"]]
assert len(guards)==2
gcode=compile(ast.Module(body=guards,type_ignores=[]),str(SOURCE),'exec')
for name,project,positive in [('only offset relation removed',{'A'},True),('extra removed module',set(),False),('new external provider',{'A','B'},False),('offset module still present',{'A','BusyBeaver.ZFC.RMOffsetBisim'},False)]:
 try:exec(gcode,{'old':{'A':{},'BusyBeaver.ZFC.RMOffsetBisim':{}},'project':project})
 except AssertionError:assert not positive;checks.append({'name':name,'status':'REJECTED'})
 else:assert positive;checks.append({'name':name,'status':'PASS'})
with tempfile.TemporaryDirectory(prefix='controls-',dir=ROOT) as td:
 p=Path(td);basis=p/'basis';cache=p/'cache';(basis/'objects').mkdir(parents=True);cache.mkdir()
 b=basis/'objects/A.olean';b.write_bytes(b'immutable');other=basis/'objects/B.olean';other.write_bytes(b'immutable');obj=cache/'A.olean'
 env={'cache':cache,'BASIS':basis,'done':{'A':{'origin':'phase4_hash_bound'}}}
 def run(name,positive):
  try:exec(code,env)
  except (AssertionError,FileNotFoundError):assert not positive;checks.append({'name':name,'status':'REJECTED'})
  else:assert positive;checks.append({'name':name,'status':'PASS'})
 obj.symlink_to(b);run('exact reused symlink',True)
 obj.unlink();obj.symlink_to(other);run('wrong provider with identical bytes',False)
 obj.unlink();obj.write_bytes(b'immutable');run('reused regular file forbidden',False)
 env['done']['A']['origin']='phase5_fresh';run('fresh regular file',True)
 obj.unlink();obj.symlink_to(b);run('fresh symlink forbidden',False)
 old=sha(b);exec(unlink_code,{'obj':obj});assert b.exists() and sha(b)==old and not obj.exists()
 obj.write_bytes(b'new target');assert sha(b)==old and not obj.is_symlink();checks.append({'name':'unlink-before-write preserves predecessor bytes','status':'PASS'})
 obj.unlink();exec(unlink_code,{'obj':obj});checks.append({'name':'missing-target unlink allowed','status':'PASS'})
record={'status':'PASS_EXTRACTED_ALIAS_CONTROLS','source_sha256':sha(SOURCE),'reviewer_sha256':sha(Path(__file__)),'checks':checks,'scope':'Only extracted exact removed-module guards, alias-guard loop and target-unlink statement on tiny disposable files; no driver or compiler invocation.'}
(ROOT/'controls-v2.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
