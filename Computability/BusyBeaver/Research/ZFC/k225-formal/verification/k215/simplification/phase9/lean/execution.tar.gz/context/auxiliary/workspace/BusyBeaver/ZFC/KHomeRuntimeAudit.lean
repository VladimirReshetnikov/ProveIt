import BusyBeaver.ZFC.KRuntimeCore

namespace SetTheory.BusyBeaver.ZFC.KHomeRuntimeAudit
open KZip KRuntimeCore

/-- Literal pre-refactor definition, only for this external API/equality control. -/
def oldExec (M : TMN) (br : Branch) (tgt : SConf → Bool) : Nat → SConf → Bool → Option SConf
  | 0, _, _ => none
  | f + 1, s, moved =>
    if moved && tgt s then some s
    else match sstep M br s with
      | none => none
      | some (s', m) => oldExec M br tgt f s' (moved || m)

theorem original_executor (M : TMN) (br : Branch) (tgt : SConf → Bool)
    (f : Nat) (s : SConf) (m : Bool) : exec M br tgt f s m = oldExec M br tgt f s m := by
  induction f generalizing s m with
  | zero => rfl
  | succ f ih =>
    simp only [exec, execWith, oldExec]
    split
    · rfl
    · cases hs : sstep M br s with
      | none => rfl
      | some p => exact ih p.1 (m || p.2)

example {M : TMN} (B : BoxLemmas M) {br : Branch} {tgt : SConf → Bool}
    (n : Nat) {vs : List Nat} (hv : Valid br vs) (f : Nat) (s : SConf) (m0 : Bool) (s' : SConf)
    (h : exec M br tgt f s m0 = some s') :
    tgt s' = true ∧ Reach M (conc n vs s) (conc n vs s') ∧
      (m0 = false → Reach1 M (conc n vs s) (conc n vs s')) :=
  exec_sound B n hv f s m0 s' h

#print axioms original_executor
#print axioms KRuntimeCore.exec_sound
#print axioms KRuntimeCore.execWith_sound
end SetTheory.BusyBeaver.ZFC.KHomeRuntimeAudit
