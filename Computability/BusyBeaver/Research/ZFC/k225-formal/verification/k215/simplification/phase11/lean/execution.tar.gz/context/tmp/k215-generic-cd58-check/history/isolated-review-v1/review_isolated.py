"""Read-only terminal review; no compiler or producer calls."""
from pathlib import Path
import json,hashlib,re,fcntl
S=Path(__file__).resolve().parent;D=S/'inline-isolated-run1';B=Path('/tmp/k215-phase10-main/full-run1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
result=read(D/'result.json');inv=read(D/'inventory.json')['modules'];done=read(D/'completed.json');before=read(D/'before.json');mp=read(S/'inline-isolated-map.json');plan=read(S/'inline-isolated-plan.json');old=read(B/'completed.json')
assert result['status']=='PASS' and result['selected_project_modules']==16
assert len(done)==len(inv)==16 and set(done)=={r['module']for r in inv}
assert sha(D/'inventory.json')==result['inventory_sha256'] and sha(D/'completed.json')==result['completed_sha256']
assert result['runner_sha256']==sha(S/'build.py')=='08d6d90bdb65a641d375b9c89adae5ed4cabeea325f4d870981d80459b5b0935'
assert result['map_sha256']==sha(S/'inline-isolated-map.json') and result['producer_boundary_sha256']==sha(S/'producer-boundary.json')
assert before['rows']==inv and [r['module']for r in inv]==mp['expected']['modules']
assert before['changed_sources']==result['source_changed_modules']==mp['expected']['changed']
assert before['force_basis_rebuild']==result['force_basis_rebuild_modules']==mp['expected']['forced']
for p,h in before['inputs'].items():assert sha(p)==h,p
fresh=set(result['fresh_modules']);reused=set(result['phase10_reused_modules']);assert len(fresh)==5 and len(reused)==11 and not fresh&reused and fresh|reused==set(done)
assert sorted(fresh)==plan['expected_fresh'] and not result['isolated_reused_modules'] and not result['audits']
reports=[];warnings=[];ledger=[];over={x['module']:x for x in mp['modules']}
for row in inv:
 m=row['module'];rec=done[m];obj=D/'objects'/(m.replace('.','/')+'.olean');source=D/'workspace'/(m.replace('.','/')+'.lean');log=Path(rec['log'])
 assert rec['status']=='PASS' and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
 assert sha(row['source'])==sha(source)==rec['source_sha256']==row['source_sha256']
 assert rec['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 assert sha(obj)==rec['object_sha256'] and sha(log)==rec['log_sha256']
 txt=log.read_text();rr=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
 assert 'error:'not in txt and 'sorryAx'not in txt
 warnings.extend([m]*txt.count('warning:'))
 if m in fresh:
  assert rec['origin']=='candidate_fresh' and not obj.is_symlink()
  assert rec==read(log.parent/'record.json') and rec['source']==str(source)
  expected=[str(Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')),'-j1','-M12288','--root='+str(D/'workspace'),'-o',str(obj),str(source)]
  assert rec['command']==expected and rec['timeout_seconds']==120 and rec['memory_mebibytes']==12288
  assert rec['compiler_sha256']==sha(expected[0]);assert rec['helper_sha256']==sha('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py')
  assert [x[0]for x in rr]==over[m]['reports']
  assert [{s.strip()for s in x[1].split(',')if s.strip()}for x in rr]==[set(a)for a in over[m]['report_axioms']]
  assert txt.count('warning:')==rec['warnings']==0
 else:
  assert rec['origin']=='phase10_checked' and obj.is_symlink() and obj.resolve()==(B/'objects'/(m.replace('.','/')+'.olean')).resolve()
  assert {k:v for k,v in rec.items()if k!='origin'}=={k:v for k,v in old[m].items()if k!='origin'}
 reports.extend(rr);ledger.append({'module':m,'source_sha256':rec['source_sha256'],'object_sha256':rec['object_sha256'],'log_sha256':rec['log_sha256'],'origin':rec['origin']})
assert len(reports)==17 and len(warnings)==6 and set(warnings)=={'BusyBeaver.ZFC.TarskiComplete'}
assert sum(not a for _,a in reports)==7
assert not (S/'inline-isolated-run1.stderr.log').read_bytes()
assert (S/'inline-isolated-run1.stdout.log').read_text().endswith('COMPLETE 16 0 audits\n')
with Path('/tmp/proveit-k215-proof-build.lock').open('a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN)
review={'status':'PASS_ISOLATED_INLINE58_ACTUAL','result_sha256':sha(D/'result.json'),'source_sha256':sha(S/'candidate/DominatedImplication.inline.lean'),'modules':16,'fresh':5,'reused':11,'named_reports':reports,'empty_axiom_reports':7,'numeric_propext_Quot_sound_reports':10,'fresh_warnings':0,'inherited_warnings':6,'inherited_warning_module':'BusyBeaver.ZFC.TarskiComplete','all_before_inputs_rehashed':len(before['inputs']),'all_source_import_dependency_object_log_bindings_checked':True,'lock_observed_free':True,'basis_result_sha256':sha(B/'result.json'),'ledger':ledger,'reader_sha256':sha(__file__),'scope':'Fresh exact inline58 generic core, unchanged numeric adapter/KCodeDom and two typed clients. No full endpoint run, producer execution or canonical adoption.'}
(S/'isolated-actual-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({k:review[k]for k in ['status','result_sha256','modules','fresh','reused','empty_axiom_reports','numeric_propext_Quot_sound_reports','fresh_warnings','inherited_warnings','all_before_inputs_rehashed','lock_observed_free']},indent=2))
