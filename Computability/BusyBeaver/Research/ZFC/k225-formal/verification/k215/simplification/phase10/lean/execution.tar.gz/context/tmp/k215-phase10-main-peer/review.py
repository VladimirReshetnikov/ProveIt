"""Independent terminal phase10 live-record audit; no proof/compiler execution."""
from pathlib import Path
import argparse,fcntl,hashlib,json,re
R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
B=Path('/tmp/k215-proof-phase8/lean-run1')
P=Path('/tmp/k215-phase9-main/full-run2')
F=Path('/tmp/k215-phase10-main/full-run1')
M=Path('/tmp/k215-phase10-main/full-v1.json')
D=Path('/tmp/k215-phase9-main/build-v4.py')
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
assert sha(D)=='287ad156c55681c2c00dabc524d799df4c43f342455c64805031591a8e81e37a'
assert sha(M)=='bd43c8e58b2c4406d89e9eebbd9073aa39af707cacaf7dfa61aec053aa671044'
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
assert sha(C)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
assert sha(P/'result.json')=='e54f4f69ec6721a26a0eba53b801f198ee70227a231d38b3c66782b5ed2a8818'
assert sha(B/'result.json')=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
res=read(F/'result.json');before=read(F/'before.json');inv=read(F/'inventory.json');done=read(F/'completed.json');prior=read(P/'completed.json');old=read(B/'completed.json');plans={x['module']:x for x in read(M)['modules']}
assert res['status']=='PASS' and res['selected_project_modules']==197
assert res['runner_sha256']==before['runner_sha256']==sha(D)
assert res['map_sha256']==before['map_sha256']==sha(M)
for base in [B,P,F]:
 result=read(base/'result.json');assert result['inventory_sha256']==sha(base/'inventory.json') and result['completed_sha256']==sha(base/'completed.json')
rows={x['module']:x for x in inv['modules']};p_rows={x['module']:x for x in read(P/'inventory.json')['modules']};b_rows={x['module']:x for x in read(B/'inventory.json')['modules']}
assert len(rows)==len(inv['modules'])==len(done)==197 and set(rows)==set(done)==set(p_rows)==set(prior)
assert before['rows']==inv['modules']
targets=['BusyBeaver.ZFC.KEndpoint215','BusyBeaver.ZFC.KDecoderPrefix215']
assert before['targets']==inv['targets']==res['targets']==targets
assert before['audit_endpoint'] and inv['external_imports']==before['external_imports']==['Init']
ordered=[];active=set();closures={}
def closure(m):
 if m=='Init':return set()
 if m in closures:return closures[m]
 assert m in rows and m not in active
 active.add(m);cs={m}
 for dep in rows[m]['imports']:cs|=closure(dep)
 active.remove(m);closures[m]=cs;ordered.append(m);return cs
for m in targets:closure(m)
assert ordered==[x['module']for x in inv['modules']]
changed=lambda base:{m for m,r in rows.items()if m not in base or (r['source_sha256'],r['imports'])!=(base[m]['source_sha256'],base[m]['imports'])}
phase8_changed=changed(b_rows);phase8_forced={m for m in rows if closures[m]&phase8_changed}
phase9_changed=changed(p_rows);phase9_forced={m for m in rows if closures[m]&phase9_changed}
assert phase9_changed=={'BusyBeaver.ZFC.DominatedImplication'}
expected_fresh={'BusyBeaver.ZFC.'+m for m in ['DominatedImplication','DomRho8','KCodeDom','L2RootPerm','L2AxiomsPerm','SeedPerm','EnumPerm','KEndpoint215']}
assert phase9_forced==expected_fresh and len(phase8_changed)==12 and len(phase8_forced)==33
assert sorted(phase8_changed)==before['changed_sources']==res['source_changed_modules']
assert sorted(phase8_forced)==before['force_basis_rebuild']==res['force_basis_rebuild_modules']
assert res['basis_reuse_rejects_transitive_source_changes'] and res['isolated_reuse_requires_exact_transitive_sources_and_imports']
assert set(res['fresh_modules'])==expected_fresh and not res['phase8_reused_modules']
assert set(res['isolated_reused_modules'])==set(rows)-expected_fresh
assert read(M)['reuse_ledger']=={'directory':str(P),**{n:sha(P/n)for n in ['result.json','inventory.json','completed.json']}}
# Parse import lines after removing nested comments and quoted strings.
def imports(text):
 out=[];i=0;depth=0;quoted=False
 while i<len(text):
  if depth:
   if text.startswith('/-',i):depth+=1;i+=2
   elif text.startswith('-/',i):depth-=1;i+=2
   else:out.append('\n' if text[i]=='\n' else ' ');i+=1
  elif quoted:
   if text[i]=='\\':i+=2
   elif text[i]=='"':quoted=False;i+=1
   else:out.append('\n'if text[i]=='\n'else' ');i+=1
  elif text.startswith('/-',i):depth=1;i+=2
  elif text.startswith('--',i):
   j=text.find('\n',i);i=len(text)if j<0 else j
  elif text[i]=='"':quoted=True;i+=1
  else:out.append(text[i]);i+=1
 return [w for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',''.join(out))for w in line.split()]
standard={'propext','Classical.choice','Quot.sound'}
def reports(txt):
 rs=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
 assert 'sorryAx'not in txt and 'error:'not in txt
 assert all({x.strip()for x in ax.split(',')if x.strip()}<=standard for _,ax in rs)
 return rs
objects={m:sha(F/'objects'/(m.replace('.','/')+'.olean'))for m in rows}
ledger={}
for m,row in rows.items():
 rec=done[m];source=Path(row['source']);obj=F/'objects'/(m.replace('.','/')+'.olean');log=Path(rec['log']);txt=log.read_text()
 assert rec['status']=='PASS' and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
 assert sha(source)==row['source_sha256']==rec['source_sha256'];assert imports(source.read_text())==row['imports']
 assert sha(F/'workspace'/(m.replace('.','/')+'.lean'))==row['source_sha256']
 assert objects[m]==rec['object_sha256'] and sha(log)==rec['log_sha256']
 assert rec['dependencies']=={d:objects[d]for d in row['imports']if d!='Init'}
 found=reports(txt)
 for parent in obj.parents:
  assert not parent.is_symlink()
  if parent==F/'objects':break
 if m in expected_fresh:
  assert rec['origin']=='phase9_fresh' and not obj.is_symlink()
  assert rec['timeout_seconds']==120 and rec['memory_mebibytes']==12288
  assert rec['compiler_sha256']==sha(C) and rec['helper_sha256']==sha(H)
  assert rec['command']==[str(C),'-j1','-M12288','--root='+str(F/'workspace'),'-o',str(obj),str(F/'workspace'/(m.replace('.','/')+'.lean'))]
  assert rec['reports']==[list(x)for x in found] and rec['warnings']==txt.count('warning:')
  assert sha(rec['source'])==row['source_sha256']
  raw=read(log.parent/'record.json');assert raw==rec
 else:
  assert rec['origin']=='isolated_checked' and rec=={**prior[m],'origin':'isolated_checked'}
  assert obj.is_symlink()and obj.resolve()==(P/'objects'/(m.replace('.','/')+'.olean')).resolve()
  assert all((rows[d]['source_sha256'],rows[d]['imports'])==(p_rows[d]['source_sha256'],p_rows[d]['imports'])for d in closures[m])
 if m in plans and 'reports'in plans[m]:assert [n for n,_ in found]==plans[m]['reports'] and 'warning:'not in txt
 ledger[m]={'source':sha(source),'object':objects[m],'log':sha(log),'origin':rec['origin'],'transitive_modules':sorted(closures[m])}
sites=sorted(m for m in rows if m.startswith('BusyBeaver.ZFC.KSites215Batch'));assert len(sites)==9
assert all(done[m]=={**prior[m],'origin':'isolated_checked'}for m in sites)
# Every original input is checked, including old producer pins; no adoption exception.
for p,h in before['inputs'].items():assert sha(p)==h,p
for p in [D,M,H,C,*[B/n for n in ['result.json','inventory.json','completed.json','toolchain.json']],*[P/n for n in ['result.json','inventory.json','completed.json']]]:assert before['inputs'][str(p)]==sha(p)
assert (F/'toolchain.json').read_bytes()==(B/'toolchain.json').read_bytes()
for item in read(F/'toolchain.json').values():
 if isinstance(item,dict)and'path'in item and'sha256'in item:assert sha(item['path'])==item['sha256']
expected={
 'EndpointAudit215':['EndpointAudit215.blank_halts_exactly_when_zfc_has_a_finite_refutation','EndpointAudit215.nonhalting_exactly_when_zfc_is_consistent'],
 'K215Audit':['SetTheory.BusyBeaver.ZFC.KEndpoint215.blank_halts_iff_zfc_refutation','SetTheory.BusyBeaver.ZFC.KEndpoint215.nonhalting_iff_zfc_consistency','SetTheory.BusyBeaver.ZFC.KDense215.commutes','SetTheory.BusyBeaver.ZFC.KBoot215.boot','SetTheory.BusyBeaver.ZFC.KSites215.covered','SetTheory.BusyBeaver.ZFC.KEndpoint215.p215_boot_iff','K215Audit.blank_halts_exact','K215Audit.nonhalting_exact']}
pins={'EndpointAudit215':'d13596021774c5b26937b13cf6cca58342af99f59626b9205ff10b9df1e6fc7d','K215Audit':'9144acc6c597c4a53928fc62be00d5e25d9f32f519797d17a5058d03b5460986'}
assert [x['module']for x in res['audits']]==list(expected)
for rec in res['audits']:
 m=rec['module'];q=F/('audit-'+m);log=Path(rec['log']);txt=log.read_text();found=reports(txt)
 assert rec['status']=='PASS' and rec['exit_code']==0 and not rec['timed_out'] and'warning:'not in txt
 assert [n for n,_ in found]==expected[m] and[list(x)for x in found]==rec['named_reports']
 assert rec['dependencies']==objects and sha(rec['source'])==sha(q/(m+'.lean'))==rec['source_sha256']==pins[m]
 assert sha(q/(m+'.olean'))==rec['object_sha256']and sha(log)==rec['log_sha256']and sha(C)==rec['compiler_sha256']
 assert rec['command']==[str(C),'-j1','-M12288','--root='+str(q),'-o',str(q/(m+'.olean')),str(q/(m+'.lean'))]
 assert rec['timeout_seconds']==120 and rec['memory_mebibytes']==12288
 assert read(q/(m+'.json'))==rec
for p,h in before['inputs'].items():assert sha(p)==h,p
for m,row in rows.items():
 assert sha(row['source'])==ledger[m]['source'] and sha(F/'objects'/(m.replace('.','/')+'.olean'))==ledger[m]['object'] and sha(done[m]['log'])==ledger[m]['log']
for rec in res['audits']:
 q=F/('audit-'+rec['module']);assert sha(q/(rec['module']+'.olean'))==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256']
with (F/'output.lock').open('a')as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
result={'status':'PASS_INDEPENDENT_PHASE10_TRANSITIVE_REVIEW','run':str(F),'union_modules':197,'endpoint_modules':len(closures[targets[0]]),'prefix_only_modules':sorted(set(rows)-closures[targets[0]]),'phase9_changed_sources':sorted(phase9_changed),'required_fresh':sorted(expected_fresh),'fresh_count':8,'exact_phase9_reuse_count':189,'nine_site_objects_sources_logs_unchanged':sites,'phase8_relative_changed_sources':12,'phase8_relative_source_descendants':33,'all_before_inputs_rehashed_without_exception':True,'all197_source_import_object_log_bindings_postchecked':True,'exact_typed_clients':2,'exact_named_reports':10,'audit_warnings':0,'project_warning_occurrences':sum(Path(x['log']).read_text().count('warning:')for x in done.values()),'output_lock_released':True,'new_compiler_invocations_by_reviewer':0,'outer_exit_observation':'Root owns the separate outer-session terminal observation; this reader checks the terminal PASS result and released output lock.','scope':'Full selected197-provider closure (192 endpoint+5 prefix). Eight source-transitive descendants freshly checked;189 exact phase9 providers reused. No producer adoption exception and no new Rocq or legacy-union compilation claim.','pins':{str(p):sha(p)for p in [F/'result.json',F/'before.json',F/'inventory.json',F/'completed.json',F/'toolchain.json',M,D,Path(__file__)]},'ledger':ledger}
assert result['endpoint_modules']==192
assert not a.output.exists();a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['ledger','pins']},indent=2))
