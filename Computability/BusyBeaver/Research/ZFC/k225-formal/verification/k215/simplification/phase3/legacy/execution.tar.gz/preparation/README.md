# Legacy interface refresh (prepared only)

After Root confirms the final phase-three primary checkpoint, `build.py` will copy its exact 185-object cache and freshly compile the fourteen legacy modules named in `plan.json`. The complete private union is 199 modules. No earlier cache or ledger is changed; this is not a fresh compilation of all 199 modules.

The runner requires the phase-three terminal PASS and independent live-review receipt, exact current primary source inventory, compiler/toolchain hashes, saved logs, and dependency/object bindings. It uses the reviewed process-group supervisor and shared compiler lock, one worker, 12 GiB, and 120 seconds per invocation. It records source snapshots, commands, logs and output hashes. All inputs and all 199 private objects are checked again after the typed client.

`LegacyAudit.lean` directly instantiates the four public `iter_iff` theorems for arbitrary states of the 222, 219, dominated and permuted enumerators. Four standard-axiom reports are required. The final primary 215 endpoint remains a separate phase-three result.

Prepared command, to be run only after Root's phase-three completion notice:

```sh
python3 build.py --basis /tmp/k215-proof-phase3/run1 \
  --basis-review /tmp/k215-proof-phase3-publication/live-review.json \
  --out /tmp/k215-phase3-legacy/run1
```

The actual basis paths will be taken from Root's completion notice. The planned publication destination is `verification/k215/simplification/phase3/legacy/`. The preparation-only inventory may precede final source adoption; execution requires the live current inventory to equal the completed phase-three basis exactly.
