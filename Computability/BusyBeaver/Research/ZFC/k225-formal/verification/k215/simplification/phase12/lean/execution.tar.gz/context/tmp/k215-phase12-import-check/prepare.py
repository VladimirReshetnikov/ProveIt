"""Prepare source-only phase12 maps and a narrow successor; never invokes Lean."""
from pathlib import Path
import ast,hashlib,json,re,shutil,difflib
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
B=Path('/tmp/k215-generic-cd58-check/inline-full-run1');A=Path('/tmp/k215-proof-phase8/lean-run1')
F=R/'Computability/BusyBeaver/Research/ZFC/k225-formal'
P=Path('/tmp/k215-phase12-import-proposal/freeze.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
oldrunner=Path('/tmp/k215-generic-cd58-check/build.py');assert sha(oldrunner)=='08d6d90bdb65a641d375b9c89adae5ed4cabeea325f4d870981d80459b5b0935'
copy(oldrunner,S/'history/build-phase11.py')
assert sha(B/'result.json')=='53a7307848e6445a46b13e39b4283e335f5793660ca23f46659dc26c8f8e794d'
original=read(B/'inventory.json');basis={r['module']:r for r in original['modules']};assert len(basis)==197
# Extract only the previously reviewed lexical parser, rather than running any producer.
H=F/'verification/k215/lean/build.py';tree=ast.parse(H.read_text());env={}
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='without_comments_strings')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(H),'exec'),env)
strip=env['without_comments_strings'];roots=('Computability/BusyBeaver/Lean','Logic/FirstOrder/Lean','SetTheory/ZF/Lean','SetTheory/BoundedConsistency/Lean')
def imports(p):return [w for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',strip(Path(p).read_text()))for w in line.split()]
proposal=read(P);assert len(proposal['files'])==8
mods=[]
for row in proposal['files']:
 p=Path(row['source']);assert sha(p)==row['sha256']
 if p.suffix!='.lean':continue
 m='BusyBeaver.ZFC.'+p.stem
 assert row['before_sha256']==basis.get(m,{}).get('source_sha256')
 mods.append({'module':m,'source':str(p),'source_sha256':sha(p),'imports':imports(p),'before_sha256':row['before_sha256']})
assert len(mods)==7
priorpath=Path('/tmp/k215-generic-cd58-check/producer-boundary.json');prior=read(priorpath)
adoptpath=Path('/tmp/k215-phase11-main/adoption.json');adopt=read(adoptpath)
assert sha(adoptpath)=='164c58547a324a98294fe9def0a93496e314c36f66eedf1df9beb795881ba9ef'
tombs={str(R/x['target']):x for x in adopt['tombstones']};rows=[]
for old in prior['files']:
 row=dict(old);p=Path(row['canonical'])
 if str(p)in tombs:
  t=tombs[str(p)];assert not p.exists()and not p.is_symlink();assert sha(t['archived_before'])==t['before_sha256']==row['phase10_sha256']
  row.update(current_state='absent',retired_snapshot=t['archived_before'])
 else:
  snapshot=S/'inputs/current-producer'/p.relative_to(R);copy(p,snapshot)
  row.update(current_state='present',current_sha256=sha(p),current_snapshot=str(snapshot))
 rows.append(row)
expected_current={'generate_domrho8_lean.py':'f3fbc696ad34f507fd29d89322f7649fb8c4ad338a1bb6fe6bdd21537e54f5e2','generate_dominated_implication_lean.py':'31fdd538a6cf001d30fa26cb3d4d411306d3df52bea1ede62a54fc17608f1882','adapter.txt':'8fdbec0db9134070bee2dfa0a433aff66ab83c00007ea7b9aabd9192c506d378'}
assert {Path(r['canonical']).name:r['current_sha256']for r in rows if r['current_state']=='present'}==expected_current
proposed=proposal['files'][-1];assert Path(proposed['source']).name=='generate_l2k222.py';assert sha(R/proposed['target'])==proposed['before_sha256']
boundary={**prior,'phase11_result_sha256':sha(B/'result.json'),'files':rows,'phase11_adoption':{'path':str(adoptpath),'sha256':sha(adoptpath)},'previous_boundary':{'path':str(priorpath),'sha256':sha(priorpath)},'additional_inputs':{str(P):sha(P),proposed['source']:proposed['sha256'],str(R/proposed['target']):proposed['before_sha256']},'scope':'Historical phase8 and phase10 producer sets remain exact saved bytes. Current phase11 requires three exact files and two explicit absences. The proposed L2Lib producer is data only, unexecuted and not adopted.'}
save(S/'producer-boundary.json',boundary)
s=oldrunner.read_text().replace("B=Path('/tmp/k215-phase10-main/full-run1')","B=Path('/tmp/k215-generic-cd58-check/inline-full-run1')")
s=s.replace('6bc3039524d69a976c8c3b726ccbe9b47e884877e682bcf2d0f79555caa96a58','53a7307848e6445a46b13e39b4283e335f5793660ca23f46659dc26c8f8e794d')
s=s.replace('08a6b8621a33d8753472f980e791cb02c0835e87d9ed92eab69e9b6b3b5dd132',sha(S/'producer-boundary.json'))
s=s.replace("producer_rows=producer_boundary['files'];assert len(producer_rows)==5","assert producer_boundary['phase10_result_sha256']==baseline['basis_result_sha256']\nproducer_rows=producer_boundary['files'];assert len(producer_rows)==5")
s=s.replace("producer_boundary['phase10_result_sha256']==sha(B/'result.json')","producer_boundary['phase11_result_sha256']==sha(B/'result.json')")
a="for r in producer_rows:\n path=Path(r['canonical']);assert r['phase8_sha256']==ancestry['producer_pins'][str(path.relative_to(R))]\n for key in ['phase8_snapshot','historical_original']:\n  assert sha(r[key])==r['phase8_sha256'];inputs[r[key]]=r['phase8_sha256']\n for key in ['phase10_snapshot','canonical']:\n  assert sha(r[key])==r['phase10_sha256'];inputs[r[key]]=r['phase10_sha256']"
b="""for key in ['phase11_adoption','previous_boundary']:
 pin=producer_boundary[key];assert sha(pin['path'])==pin['sha256'];inputs[pin['path']]=pin['sha256']
for p,h in producer_boundary['additional_inputs'].items():assert sha(p)==h;inputs[p]=h
absent_inputs=[]
for r in producer_rows:
 path=Path(r['canonical']);assert r['phase8_sha256']==ancestry['producer_pins'][str(path.relative_to(R))]
 for key in ['phase8_snapshot','historical_original']:
  assert sha(r[key])==r['phase8_sha256'];inputs[r[key]]=r['phase8_sha256']
 assert sha(r['phase10_snapshot'])==r['phase10_sha256'];inputs[r['phase10_snapshot']]=r['phase10_sha256']
 if r['current_state']=='present':
  for key in ['current_snapshot','canonical']:
   assert sha(r[key])==r['current_sha256'];inputs[r[key]]=r['current_sha256']
 else:
  assert r['current_state']=='absent' and not path.exists()and not path.is_symlink()
  assert sha(r['retired_snapshot'])==r['phase10_sha256'];inputs[r['retired_snapshot']]=r['phase10_sha256'];absent_inputs.append(str(path))
assert len(absent_inputs)==2"""
assert a in s;s=s.replace(a,b)
s=s.replace("'inputs':inputs,'external_imports'","'inputs':inputs,'absent_inputs':sorted(absent_inputs),'external_imports'")
s=s.replace("def postcheck():\n for p,h in inputs.items():assert sha(p)==h,p","def postcheck():\n for p in absent_inputs:assert not Path(p).exists()and not Path(p).is_symlink(),p\n for p,h in inputs.items():assert sha(p)==h,p")
s=s.replace('phase10_checked','phase11_checked').replace('phase10_reused_modules','phase11_reused_modules')
s=s.replace('isolated_checked','secondary_checked').replace('isolated_reused_modules','secondary_reused_modules').replace('isolated_reuse_requires_exact_transitive_sources_and_imports','secondary_reuse_requires_exact_transitive_sources_and_imports')
s=s.replace("if m in done and usable(done[m],obj):\n","if m in done and usable(done[m],obj):\n  assert done[m]['origin']in {'phase11_checked','secondary_checked','candidate_fresh'}\n")
# Optional provider stays a checked candidate closure, never an assumption that identical direct objects suffice.
s=s.replace("assert read(args.reuse/'result.json')['status']=='PASS'", "reuse_result=read(args.reuse/'result.json');assert reuse_result['status']=='PASS'\n assert sha(args.reuse/'inventory.json')==reuse_result['inventory_sha256']and sha(args.reuse/'completed.json')==reuse_result['completed_sha256']")
(S/'build.py').write_text(s);ast.parse(s)
(S/'driver.diff').write_text(''.join(difflib.unified_diff(oldrunner.read_text().splitlines(True),s.splitlines(True),fromfile='phase11/build.py',tofile='phase12/build.py')))
# Every explicit client checks former exported types without any computational shortcut.
clientplans=[]
for name in ['WFModelCompat12','ZFNativeCompat12']:
 p=S/'clients'/(name+'.lean');reports=re.findall(r'^#print axioms (\S+)',p.read_text(),re.M)
 clientplans.append({'module':name,'source':str(p),'source_sha256':sha(p),'imports':imports(p),'before_sha256':None,'reports':reports})
def inventory(overrides,targets):
 result=[];seen=set();active=set()
 def visit(m):
  if m=='Init'or m in seen:return
  assert m not in active,m
  if m in overrides:r=overrides[m]
  else:
   assert m in basis,('unregistered',m)
   found=[p for root in roots if(p:=R/root/(m.replace('.','/')+'.lean')).is_file()];assert len(found)==1
   p=found[0];assert sha(p)==basis[m]['source_sha256'];r={**basis[m],'source':str(p),'imports':imports(p)};assert r['imports']==basis[m]['imports']
  active.add(m)
  for d in r['imports']:visit(d)
  active.remove(m);seen.add(m);result.append(r)
 for t in targets:visit(t)
 return result
alloverrides={r['module']:r for r in mods+clientplans}
primary_targets=['BusyBeaver.ZFC.KEndpoint215','BusyBeaver.ZFC.KDecoderPrefix215']
compat_targets=['WFModelCompat12','ZFNativeCompat12']
results={}
for name,targets,plans,audits in [('primary',primary_targets,mods,True),('compatibility',compat_targets,mods+clientplans,False)]:
 rows=inventory(alloverrides,targets);selected=[r['module']for r in rows];by={r['module']:r for r in rows}
 changed={m for m in selected if m not in basis or by[m]['source_sha256']!=basis[m]['source_sha256']}
 forced=set(changed)
 while True:
  n=forced|{m for m in selected if set(by[m]['imports'])&forced}
  if n==forced:break
  forced=n
 mp={'modules':plans,'expected':{'modules':selected,'changed':sorted(changed),'forced':sorted(forced)}}
 save(S/(name+'-map.json'),mp);save(S/(name+'-inventory.json'),{'modules':rows,'targets':targets})
 cmd=['python','-B',str(S/'build.py'),'--out',str(S/(name+'-run1')),'--map',str(S/(name+'-map.json'))]
 for t in targets:cmd+=['--target',t]
 if audits:cmd+=['--audit-endpoint']
 results[name]={'status':'PREPARED_NOT_EXECUTED','command':cmd,'selected_modules':len(rows),'expected_fresh_without_secondary_provider':sorted(forced),'expected_baseline_reuse':[m for m in selected if m not in forced],'reports':10,'basis_result_sha256':sha(B/'result.json'),'inputs':{str(p):sha(p)for p in [S/'build.py',S/'producer-boundary.json',S/(name+'-map.json')]}}
 save(S/(name+'-plan.json'),results[name])
main=read(S/'primary-inventory.json');comp=read(S/'compatibility-inventory.json');pm={r['module']for r in main['modules']};cm={r['module']for r in comp['modules']}
assert len(pm)==184;assert len(inventory(alloverrides,['BusyBeaver.ZFC.KEndpoint215']))==179
# Compatibility can reuse only exact primary transitive closures; both changed wrappers and the clients remain fresh.
compat_forced=set(results['compatibility']['expected_fresh_without_secondary_provider'])
reuse_expected=sorted(cm&pm);fresh_compat=sorted(compat_forced-pm)
assert {'BusyBeaver.ZFC.WFModel','BusyBeaver.ZFC.ZFNative','WFModelCompat12','ZFNativeCompat12'}<=set(fresh_compat)
results['compatibility']['secondary_provider_pending']={'directory':str(S/'primary-run1'),'expected_primary_provider_modules':reuse_expected,'expected_fresh_after_primary':fresh_compat,'expected_phase11_reuse_after_primary':sorted(cm-pm-compat_forced),'finalize_map_only_after_actual_primary_PASS':True}
save(S/'compatibility-plan.json',results['compatibility'])
save(S/'census.json',{'primary_project_modules':len(pm),'endpoint_project_modules':179,'additional_prefix_modules':5,'compatibility_total_including_two_clients':len(cm),'compatibility_project_modules':len(cm)-2,'combined_unique_project_modules':len(pm|cm)-2,'primary_removed_from_phase11':sorted(set(basis)-pm),'primary_new':sorted(pm-set(basis)),'primary_changed':results['primary']['expected_fresh_without_secondary_provider'],'compatibility_after_primary':results['compatibility']['secondary_provider_pending']})
print(json.dumps(read(S/'census.json'),indent=2))
