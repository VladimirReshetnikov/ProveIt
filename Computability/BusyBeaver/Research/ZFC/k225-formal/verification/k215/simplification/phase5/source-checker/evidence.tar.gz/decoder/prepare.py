from pathlib import Path
import difflib
P=Path(__file__).resolve().parent
src=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Lean/BusyBeaver/ZFC/RMBisim.lean').read_text()
(P/'RMBisim-original.lean').write_text(src)
a=src.index('def getc ');b=src.index('def lbeq ',a)
getc=src[a:b]
c=src.index('def branchOk ',b);end=src.index('end SetTheory.BusyBeaver.ZFC.RMBisim',c)
tail=src[c:end]
generic=getc+tail
for old,new in [
 ('getc T','getc decode T'),('branchOk t1','branchOk decode t1'),
 ('branchOk (ptree','branchOk decode (ptree'),('entryOk t1','entryOk decode t1'),
 ('entryOk (ptree','entryOk decode (ptree'),('Rel T','Rel decode T'),
 ('branchOk_good hj','branchOk_good decode hj'),('branchOk_good hk','branchOk_good decode hk'),
 ('branchOk_good hs','branchOk_good decode hs'),('entryOk_good (x','entryOk_good decode (x'),
 ('check_bisim hs','check_bisim decode hs')]:
 generic=generic.replace(old,new)
wrappers=[]
for name,arg in [('branchOk_good','h'),('entryOk_good','h'),('check_bisim','hs ha'),('check_halts_iff','hs ha R')]:
 start=tail.index('theorem '+name+' ')
 finish=tail.index(' :=',start)
 wrappers.append(tail[start:finish]+' :=\n  WithDecoder.'+name+' decode '+arg+'\n')
aliases='\n'.join('abbrev '+n+' := WithDecoder.'+n+' decode' for n in ['getc','branchOk','entryOk','Rel','check'])
new=src[:a]+src[b:c]+'''/-! A certificate denotes exactly the paths returned by its decoder. Soundness
requires no numeric size bound or other property of that decoder. -/
namespace WithDecoder

variable (decode : Nat → List Bool)

'''+generic+'''end WithDecoder

/-! The original API retains its exact 128-fuel decoding behavior. -/

'''+aliases+'\n\n'+'\n'.join(wrappers)+'\n'+src[end:]
(P/'source/BusyBeaver/ZFC/RMBisim.lean').write_text(new)
(P/'source.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),new.splitlines(True),fromfile='original/RMBisim.lean',tofile='candidate/RMBisim.lean')))
print(len(src.splitlines()),len(new.splitlines()))
