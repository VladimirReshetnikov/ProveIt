from pathlib import Path
import json,hashlib,difflib,shutil
O=Path(__file__).resolve().parent;W=O/'workspace';R=Path('/home/codex/.codex/worktrees/ec20/Proofs');F=Path('Computability/BusyBeaver/Research/ZFC/k225-formal');L=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((O/'comparison.json').read_text())['status']=='PASS_STRUCTURAL_FINITE_ONLY'
assert json.loads((O/'regeneration-run1/result.json').read_text())['status']=='PASS_PYTHON_REGENERATION_ONLY'
paths=[F/n for n in ['generate_source215_lean.py','partition_source215_lean.py','generate_sites215_lean.py','prepare_k215.py']]+[p.relative_to(W)for p in sorted((W/L).glob('*.lean'))]
rows=[];same=[]
for p in paths:
 q=W/p;old=R/p
 row={'source':str(q),'destination':str(p),'sha256':sha(q),'bytes':q.stat().st_size,'before_sha256':sha(old)if old.is_file()else None}
 if old.is_file()and q.read_bytes()==old.read_bytes():same.append(row)
 else:
  rows.append(row)
  (O/'diffs').mkdir(exist_ok=True)
  (O/'diffs'/(q.name+'.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True)if old.is_file()else[],q.read_text().splitlines(True),fromfile='baseline/'+str(p),tofile='candidate/'+str(p))))
assert len(rows)==19 and len(same)==16,(len(rows),len(same))
(O/'adoption-map.json').write_text(json.dumps({'status':'SCRATCH_ONLY_NOT_ADOPTED','compiler_executed':False,'rows':rows,'regenerated_unchanged':same},indent=2)+'\n')
(O/'peer').mkdir(exist_ok=True);shutil.copyfile('/tmp/k215-normalized-decoder-peer/review.json',O/'peer/generic-checker-review.json')
inputs=[F/'lean215/dagperm_nodes.json',F/'lean215/dagperm_sites.json',F.parent/'candidate-k215/sites215.json']
rec={'status':'READY_FOR_SOURCE_REVIEW_NOT_COMPILED','primary_project_modules':186,'source_comparison_sha256':sha(O/'comparison.json'),'adoption_map_sha256':sha(O/'adoption-map.json'),'inputs':{str(p):sha(W/p)for p in inputs},'held_files':{str(p.relative_to(O)):sha(p)for p in sorted(O.rglob('*'))if p.is_file()and '__pycache__'not in p.parts and p.name!='freeze.json'},'canonical_mutation':False,'compiler_executed':False}
(O/'freeze.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'adoption_files':len(rows),'unchanged_check_files':len(same),'adoption_sha256':sha(O/'adoption-map.json'),'freeze_sha256':sha(O/'freeze.json')},indent=2))
