"""Pin completed metadata/context only, without invoking validators or proof tools."""
from pathlib import Path
import json,hashlib,ast
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');P=Path('/tmp/k215-phase15-check');E=Path('/tmp/k215-phase15-execution');ROOT=Path('/tmp/k215-phase15-root')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
adopt=read(ROOT/'adoption.json');historical={str(R/r['path']):{'snapshot':str(R/r['before_snapshot']),'sha256':r['before_sha256']}for r in adopt['files']if r['before_snapshot']is not None}
sourcepaths={m:str(Path(row['path']).relative_to(R)) for m,row in read(ROOT/'root-actual-review.json')['sources'].items()}
assert len(sourcepaths)==199
files={};forbidden={'.olean','.ilean','.o','.so','.a','.vo','.vos','.vok','.glob','.pyc','.pyo','.gz','.zip','.tar'}
def add(p):
 p=Path(p);assert p.is_file()and not p.is_symlink();assert not set(p.suffixes)&forbidden
 files[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
def tree(p):
 for f in sorted(Path(p).rglob('*')):
  if f.is_file()and not f.is_symlink()and not set(f.suffixes)&forbidden and '__pycache__'not in f.parts:add(f)
for d in [E,ROOT,'/tmp/k215-phase15-runner-peer','/tmp/k215-phase15-retry-peer','/tmp/k215-phase15-client-retry-peer','/tmp/k215-phase15-actual-peer','/tmp/k215-source193-dense-peer','/tmp/k215-phase15-quotient/reproduction','/tmp/k215-phase15-quotient/client-v2']:
 tree(d)
for d in ['/tmp/k215-phase15-retry','/tmp/k215-phase15-client-retry','/tmp/k215-phase15-retry-metrics-v1','/tmp/k215-phase15-retry-import-only-pre193','/tmp/k215-phase15-client-retry-order-v1','/tmp/k215-phase15-check-pre-pin-v1']:
 tree(d)
for p in ['/tmp/k215-intake215/ordinary-01.md','/tmp/k215-intake215/ordinary-01.json','/tmp/k215-intake215/ordinary-01-data.json','/tmp/k215-intake215/ordinary-01-check.py']:add(p)
# Reviewed source freezes and every pinned source/proof/reproduction input.
for d in ['/tmp/k215-phase15-basic','/tmp/k215-phase15-quotient','/tmp/k215-phase15-transrec']:
 f=read(Path(d)/'freeze.json');add(Path(d)/'freeze.json')
 for entry in f.get('files',{}):
  n=entry['path'] if isinstance(entry,dict) else entry
  p=Path(n)if Path(n).is_absolute()else Path(d)/n
  if p.is_file():add(p)
tree(S/'history')
for r in adopt['files']:
 add(r['candidate'])
 if r['before_snapshot']is not None:add(R/r['before_snapshot'])
# The wrapper source matching each captured wrapper_sha256 is selected exactly.
wrappers={}
for name in ['primary-run1','primary-run2','primary-run3','compatibility-run1']:
 obs=read(E/(name+'-outer.json'));matches=[p for p,r in files.items()if p.endswith('.py')and r['sha256']==obs['wrapper_sha256']];assert len(matches)==1,(name,matches);wrappers[name]=matches[0]
handoff=read(E/'primary-handoff.json')
cfg={'status':'FROZEN_COMPLETED_PHASE15_INPUTS','files':files,'results':{str(P/n):sha(P/n/'result.json')for n in ['primary-run3','compatibility-run1']},'maps':{str(P/n):str(Path(d)/m)for n,d,m in [('primary-run1',P,'primary-map.json'),('primary-run2','/tmp/k215-phase15-retry','primary-map.json'),('primary-run3','/tmp/k215-phase15-client-retry','primary-map.json'),('compatibility-run1','/tmp/k215-phase15-client-retry','compatibility-final-map.json')]},'retry_freezes':{d:sha(Path(d)/'freeze.json')for d in ['/tmp/k215-phase15-retry','/tmp/k215-phase15-client-retry']},'outer_wrappers':wrappers,'historical_inputs':historical,'adoption':{'receipt':str(ROOT/'adoption.json'),'raw':adopt},'root_current_review':str(ROOT/'current-review.json'),'root_actual_review':str(ROOT/'root-actual-review.json'),'new_api_profiles':{m:[[r['name'],sorted(r['axioms'])]for r in rows]for m,rows in handoff['new_api_profiles'].items()},'project_source_paths':sourcepaths,'reproduction':'/tmp/k215-phase15-quotient/reproduction/actual.json','note':'All raw attempts/freezes retain their original status. Frozen initialize.py.diff is an earlier preview; the actual ordering-only correction is in order-successor.diff and external final-client-initializer.diff.'}
(S/'config.json').write_text(json.dumps(cfg,indent=2)+'\n');print(json.dumps({'context_files':len(files),'historical_inputs':len(historical),'current_project_sources':len(sourcepaths)}))
