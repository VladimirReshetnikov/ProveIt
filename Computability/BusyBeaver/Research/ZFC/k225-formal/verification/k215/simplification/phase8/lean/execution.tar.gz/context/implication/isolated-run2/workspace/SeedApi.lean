import BusyBeaver.ZFC.KSeedModel222

namespace SetTheory.BusyBeaver.ZFC.SeedSharingApi
open Tarski Code254 KCode222 KSeed222
universe u
variable {V : Type u}

-- Exact arbitrary-code forward API, without requiring distinct input/output names.
theorem forward (mem : V → V → Prop) (hirr : ∀ x, ¬ mem x x)
    (e : Nat → V) (a b c : Nat) (hca : c ≠ a) (hcb : c ≠ b)
    (h : SeedProp mem (matrixRel mem e a b c) (e a)) :
    Tarski.Sat mem e (dec (bundle222 a b c)) :=
  bundle_of_seed mem hirr e a b c hca hcb h

-- Exact reverse API, retaining all three freshness/distinctness hypotheses.
theorem reverse (mem : V → V → Prop) (hirr : ∀ x, ¬ mem x x)
    (e : Nat → V) (a b c : Nat) (hab : a ≠ b) (hca : c ≠ a) (hcb : c ≠ b)
    (h : Tarski.Sat mem e (dec (bundle222 a b c))) :
    SeedProp mem (matrixRel mem e a b c) (e a) :=
  seed_of_bundle mem hirr e a b c hab hca hcb h

theorem equalityFreeSeed (mem : V → V → Prop) (hirr : ∀ x, ¬ mem x x)
    (hT : ∀ f, DerivableNF f → ∀ e : Nat → V, Tarski.Sat mem e f)
    (ψ : Tarski.NF) (hψ : KThmK.EqFree ψ) (e : Nat → V) :
    SeedProp mem (fun x y => Tarski.Sat mem (update (update e 0 x) 1 y) ψ) (e 0) :=
  seed_eqFree mem hirr hT ψ hψ e

theorem namedBundle (ψ : Tarski.NF) (hψ : KThmK.EqFree ψ) (a b : Nat)
    (ha : enc ψ ≠ a) (hb : enc ψ ≠ b) :
    DerivableNF (bundleNF a b (enc ψ) ψ) :=
  derivable_named_bundle ψ hψ a b ha hb

#print axioms forward
#print axioms reverse
#print axioms equalityFreeSeed
#print axioms namedBundle
end SetTheory.BusyBeaver.ZFC.SeedSharingApi
