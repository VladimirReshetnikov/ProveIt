"""Isolated bounded upstream/current integration check; immutable accepted phase-one basis."""
from pathlib import Path
import os,json,hashlib,re,signal,shutil,importlib.util,sys
P=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
FORMAL=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal'
BASIS=Path('/tmp/k215-proof-simplification/root')
EVIDENCE=FORMAL/'verification/k215/simplification/lean/result.json'
HELPER=FORMAL/'verification/k215/lean/build.py'
COMPILER=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
out=P/sys.argv[1];out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('supervisor',HELPER);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
old=json.loads((BASIS/'completed.json').read_text());accepted=json.loads(EVIDENCE.read_text());pri={r['module']:r for r in accepted['module_evidence']}
assert len(old)==215 and set(old)==set(pri)
boundary=json.loads(Path('/tmp/k215-lean-complete/toolchain-boundary-v5.json').read_text())
for k in ['lean','lake','Init.olean','project_toolchain']:assert sha(boundary[k]['path'])==boundary[k]['sha256']
assert sha(COMPILER)==accepted['compiler_sha256']
objects=out/'objects';sources=out/'source';sources.mkdir();logs=out/'attempts';logs.mkdir()
before={}
for m,r in old.items():
 assert r['status']=='PASS' and r['exit_code']==0 and not r.get('timed_out',False)
 for k in ['source_sha256','object_sha256','dependencies','log_sha256']:assert r[k]==pri[m][k],(m,k)
 obj=BASIS/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==r['object_sha256']
 log=Path(r['log']) if 'log' in r else BASIS/pri[m]['compilation_origin'].split('execution.tar.gz/',1)[1]/'compiler.log'
 assert sha(log)==r['log_sha256']
 for dep,h in r['dependencies'].items():assert old[dep]['object_sha256']==h
 target=objects/(m.replace('.','/')+'.olean');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(obj,target)
 before[str(obj)]=sha(obj);before[str(log)]=sha(log)
for f in [HELPER,COMPILER,EVIDENCE,BASIS/'completed.json',Path(__file__)]:before[str(f)]=sha(f)
save(out/'before.json',before);save(out/'basis-completed.json',old);save(out/'toolchain.json',boundary)
shutil.copyfile(HELPER,out/'supervisor.py')
for f in (P/'candidate').rglob('*.lean'):
 target=sources/f.relative_to(P/'candidate');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
for name in ['EndpointAudit215','K215Audit']:shutil.copyfile(FORMAL/'verification/k215/lean'/(name+'.lean'),sources/(name+'.lean'))
shutil.copyfile(P/'audit/DraftAudit.lean',sources/'DraftAudit.lean')
env=os.environ.copy();env['LEAN_PATH']=str(objects);env['LEAN_NUM_THREADS']='1'
done=dict(old);results=[]
checks=[('BusyBeaver.ZFC.'+n,0) for n in ['EnumPerm','L2AxiomsPerm','L2RootPerm','SeedPerm','KEndpoint215']]+[('DraftAudit',3),('EndpointAudit215',2),('K215Audit',8)]
for i,(m,reports_expected) in enumerate(checks):
 source=sources/(m.replace('.','/')+'.lean');obj=objects/(m.replace('.','/')+'.olean')
 clean=helper.without_comments_strings(source.read_text());imports=[x for s in re.findall(r'(?m)^\s*import\s+([^\n]+)',clean) for x in s.split()]
 assert all(d in done for d in imports)
 deps={d:done[d]['object_sha256'] for d in imports}
 for d,h in deps.items():assert sha(objects/(d.replace('.','/')+'.olean'))==h
 attempt=logs/f'{i+1:02d}-{m}';attempt.mkdir();shutil.copyfile(source,attempt/source.name)
 if obj.exists():obj.unlink()
 command=[str(COMPILER),'-j1','-M12288','--root='+str(sources),'-o',str(obj),str(source)]
 row={'module':m,'source_sha256':sha(source),'imports':imports,'dependencies':deps,'command':command,'compiler_sha256':sha(COMPILER),'timeout_seconds':120,'memory_mebibytes':12288,'log':str(attempt/'compiler.log'),'expected_axiom_reports':reports_expected}
 print('CHECK',m,flush=True)
 ok=helper.run_locked(command,sources,env,LOCK,Path(row['log']),120,row,attempt/'record.json')
 text=Path(row['log']).read_text();reports=re.findall(r'depends on axioms: \[([^]]*)\]',text)
 row['source_unchanged']=sha(source)==row['source_sha256'];row['dependencies_unchanged']=all(sha(objects/(d.replace('.','/')+'.olean'))==h for d,h in deps.items())
 row['warnings']=text.count('warning:');row['reports']=reports;row['axiom_free_reports']=text.count('does not depend on any axioms')
 ok=ok and row['source_unchanged'] and row['dependencies_unchanged'] and 'error:' not in text and 'sorryAx' not in text and "declaration uses 'sorry'" not in text
 ok=ok and all(set(s.strip() for s in r.split(','))<={'propext','Classical.choice','Quot.sound'} for r in reports)
 if reports_expected:ok=ok and len(reports)+row['axiom_free_reports']==reports_expected and not row['warnings']
 row['status']='PASS' if ok else 'FAIL'
 if ok:row['object_sha256']=sha(obj)
 save(attempt/'record.json',row);results.append(row);print(row['status'],m,round(row['seconds'],3),flush=True)
 save(out/'progress.json',results)
 if not ok:print(text,flush=True);break
 done[m]=row
post=all(sha(f)==h for f,h in before.items())
objects_post=all(sha(objects/(m.replace('.','/')+'.olean'))==r['object_sha256'] for m,r in done.items())
result={'status':'PASS' if len(results)==len(checks) and all(r['status']=='PASS' for r in results) and post and objects_post else 'FAIL','basis':'Pinned accepted phase-one 215-module cache copied privately; unchanged dependencies reused, not a fresh full closure.','upstream_commit':'021d848979b670f702cd92ae7bb85ea888847742','checks':results,'input_post':post,'private_objects_post':objects_post,'no_canonical_mutations':True}
save(out/'result.json',result);print('TERMINAL',result['status'],flush=True)
