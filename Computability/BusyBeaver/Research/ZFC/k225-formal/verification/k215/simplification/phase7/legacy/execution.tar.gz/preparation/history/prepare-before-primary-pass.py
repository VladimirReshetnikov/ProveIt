"""Read-only predecessor/source census; writes only scratch preparation metadata."""
from pathlib import Path
import importlib.util,copy,sys
sys.dont_write_bytecode=True
from gates import *
HERE=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
F=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal'
HELPER=F/'verification/k215/lean/build.py'
assert sha(HELPER)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
spec=importlib.util.spec_from_file_location('supervisor',HELPER);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
P=Path('/tmp/k215-proof-phase6/lean-run1');L=Path('/tmp/k215-phase5-legacy/run1')
old=read(P/'inventory.json');legacy=read(L/'inventory.json')
current,cu=current_inventory(driver,REPO)
future=copy.deepcopy(old)
cp=read('/tmp/k215-proof-phase7/candidate-pins.json')
approved=next(r['sha256'] for r in cp['candidate_files'] if r['destination'].endswith('/DomRho8.lean'))
for r in future['modules']:
 if r['module']==DOM:r['source_sha256']=approved
u=checkpoint(old,future,legacy,approved)
assert current in [old,future]
assert cu==union(current,legacy)
cont=F/'verification/k215/simplification/phase6/legacy-continuity/result.json';c=read(cont)
assert c['status']=='PASS_LIVE_PURE_REUSE_LEGACY_CONTINUITY'and c['union_modules']==202
pd,ld=read(P/'completed.json'),read(L/'completed.json');records={**pd,**{m:ld[m]for m in EXTRA}}
prioru=union(old,legacy)
inputs={str(p):sha(p)for p in [HELPER,cont,HERE/'LegacyAudit.lean',*[P/n for n in ('inventory.json','completed.json','result.json','toolchain.json')],*[L/n for n in ('inventory.json','completed.json','result.json','toolchain.json')]]}
assert c['primary_result_sha256']==sha(P/'result.json')and c['old_legacy_result_sha256']==sha(L/'result.json')
for r in prioru['modules']:
 m=r['module'];obj=(L if m in EXTRA else P)/'objects'/(m.replace('.','/')+'.olean')
 valid_record(r,records[m],records,obj,source_current=m!=DOM)
 inputs[str(obj)]=sha(obj);inputs[records[m]['log']]=sha(records[m]['log'])
for e in c['legacy_bindings']:
 m=e['module'];r=records[m];assert all(e[k]==r[k]for k in ('source_sha256','object_sha256','log_sha256','dependencies'))
 assert e['imports']==graph(prioru)[m]['imports']
audit=read(L/'result.json')['audit'];assert sha(HERE/'LegacyAudit.lean')==audit['source_sha256']
assert sha(L/'audit/LegacyAudit.olean')==audit['object_sha256']and sha(L/'audit/compiler.log')==audit['log_sha256']
audit_reports((L/'audit/compiler.log').read_text())
inputs.update({str(L/'audit'/n):sha(L/'audit'/n)for n in ['LegacyAudit.lean','LegacyAudit.olean','compiler.log','record.json']})
references={}
for sub,names in [('phase5/legacy',['result.json','inventory.json','completed.json','LegacyAudit.lean']),('phase6/legacy-continuity',['result.json','review.py','review_saved.py','saved-review.json'])]:
 for name in names:
  p=F/'verification/k215/simplification'/sub/name;references[p.relative_to(REPO).as_posix()]=sha(p)
packet_pins(REPO,references)
for path,h in inputs.items():assert sha(path)==h
save(HERE/'prepared-inventory.json',{'primary':future,'union':u})
save(HERE/'basis-reference.json',references)
save(HERE/'preparation.json',{'status':'PREPARED_NO_COMPILER','primary_modules':187,'legacy_modules':15,'union_modules':202,'changed_source':DOM,'approved_source_sha256':approved,'potential_primary_refresh':sorted(PRIMARY_AFFECTED),'potentially_affected_legacy_modules':sorted(LEGACY_AFFECTED),'unconditionally_reusable_legacy_modules':sorted(EXTRA-LEGACY_AFFECTED),'audit_sha256':sha(HERE/'LegacyAudit.lean'),'metadata_and_provider_inputs':inputs,'all202_predecessor_objects_and_logs_rehashed':True,'canonical_writes':[],'compiler_invocations':[]})
print('PREPARED',len(u['modules']),'union;',len(LEGACY_AFFECTED),'legacy affected; unchanged audit5reports')
