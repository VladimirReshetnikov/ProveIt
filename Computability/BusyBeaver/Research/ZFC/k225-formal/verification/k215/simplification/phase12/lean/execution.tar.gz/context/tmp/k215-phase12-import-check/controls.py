"""Pure metadata tests extracted from the held driver. No proof-tool invocation."""
from pathlib import Path
import ast,copy,hashlib,json,re,tempfile
S=Path(__file__).resolve().parent;T=ast.parse((S/'build.py').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def record(name,fn,accept):
 try:fn();got=True
 except (AssertionError,FileNotFoundError,KeyError):got=False
 assert got==accept,(name,got,accept)
 checks.append({'name':name,'expected_accept':accept,'matched':True})
def compiled(node,env):exec(compile(ast.Module(body=[node],type_ignores=[]),str(S/'build.py'),'exec'),env)
def function(name):return next(n for n in ast.walk(T)if isinstance(n,ast.FunctionDef)and n.name==name)
# Exact recursive source/import predicate: equal direct object hashes never excuse a source change.
def transitive(change=None):
 rows={'A':{'source_sha256':'a','imports':['Init']},'B':{'source_sha256':'b','imports':['A']},'C':{'source_sha256':'c','imports':['B']}}
 old=copy.deepcopy(rows)
 if change:change(rows,old)
 env={'entry_by_name':rows,'reuse_rows':old,'compatible':{}};compiled(function('same_transitive_sources'),env)
 return env['same_transitive_sources']('C')
# Keep assertion exceptions explicit in extracted gate tests.
def assertion(v):assert v
record('identical transitive sources',lambda:assertion(transitive()),True)
record('changed leaf invalidates unchanged ancestors',lambda:assertion(transitive(lambda a,b:a['A'].update(source_sha256='new'))),False)
record('changed imported-edge order',lambda:assertion(transitive(lambda a,b:a['C'].update(imports=['A','B']))),False)
record('missing provider',lambda:assertion(transitive(lambda a,b:b.pop('A'))),False)
record('new module rejected as reuse',lambda:assertion(transitive(lambda a,b:b.pop('C'))),False)
# Exact boundary loop, with disposable file representations for all five rows.
loop=next(n for n in T.body if isinstance(n,ast.For)and isinstance(n.iter,ast.Name)and n.iter.id=='producer_rows')
post=function('postcheck').body[0]
def boundary(mutate=None,post_mutate=None):
 with tempfile.TemporaryDirectory(prefix='phase12-producer-control-')as d:
  root=Path(d);rows=[];pins={}
  for i in range(5):
   p=root/f'canonical{i}';r={'canonical':str(p),'phase8_sha256':hashlib.sha256(b'old8').hexdigest(),'phase10_sha256':hashlib.sha256(b'old10').hexdigest(),'current_state':'present'if i<3 else'absent'}
   for key,data in [('phase8_snapshot',b'old8'),('historical_original',b'old8'),('phase10_snapshot',b'old10'),('retired_snapshot',b'old10'),('current_snapshot',b'current')]:
    f=root/f'{i}-{key}';f.write_bytes(data);r[key]=str(f)
   r['current_sha256']=hashlib.sha256(b'current').hexdigest()
   if i<3:p.write_bytes(b'current')
   rows.append(r);pins[p.name]=r['phase8_sha256']
  if mutate:mutate(rows)
  e={'Path':Path,'sha':sha,'R':root,'producer_rows':rows,'ancestry':{'producer_pins':pins},'inputs':{},'absent_inputs':[]};compiled(loop,e);assert len(e['absent_inputs'])==2
  if post_mutate:post_mutate(rows)
  compiled(post,e)
record('three current files and two tombstones',lambda:boundary(),True)
record('current bytes changed',lambda:boundary(lambda r:Path(r[0]['canonical']).write_bytes(b'changed')),False)
record('current file missing',lambda:boundary(lambda r:Path(r[0]['canonical']).unlink()),False)
record('historical phase8 changed',lambda:boundary(lambda r:Path(r[0]['phase8_snapshot']).write_bytes(b'changed')),False)
record('historical phase10 changed',lambda:boundary(lambda r:Path(r[0]['phase10_snapshot']).write_bytes(b'changed')),False)
record('retired saved bytes changed',lambda:boundary(lambda r:Path(r[4]['retired_snapshot']).write_bytes(b'changed')),False)
record('tombstone resurrected regular file',lambda:boundary(lambda r:Path(r[3]['canonical']).write_bytes(b'x')),False)
record('tombstone resurrected dangling symlink',lambda:boundary(lambda r:Path(r[3]['canonical']).symlink_to('/missing/phase12-control')),False)
record('postcheck tombstone regular file',lambda:boundary(post_mutate=lambda r:Path(r[3]['canonical']).write_bytes(b'x')),False)
record('postcheck tombstone dangling symlink',lambda:boundary(post_mutate=lambda r:Path(r[3]['canonical']).symlink_to('/missing/phase12-control')),False)
record('unknown current-state tag',lambda:boundary(lambda r:r[3].update(current_state='ignored')),False)
# Exact compiler-log acceptance used on resume and on fresh project/client results.
def logtest(text=None,change=None):
 with tempfile.TemporaryDirectory(prefix='phase12-log-control-')as d:
  p=Path(d)/'log';p.write_text(text if text is not None else "'Exact.client' depends on axioms: [propext, Quot.sound]\n")
  e={'Path':Path,'re':re,'overrides':{'Client':{'reports':['Exact.client']}}};compiled(function('log_policy'),e)
  rec={'status':'PASS','exit_code':0,'timed_out':False,'log':str(p)}
  if change:change(rec)
  assert e['log_policy']({'module':'Client'},rec)
record('named standard client report',lambda:logtest(),True)
record('wrong client namespace',lambda:logtest("'Wrong.client' depends on axioms: [propext, Quot.sound]\n"),False)
record('custom axiom',lambda:logtest("'Exact.client' depends on axioms: [Magic]\n"),False)
record('sorry axiom',lambda:logtest("'Exact.client' depends on axioms: [sorryAx]\n"),False)
record('client warning',lambda:logtest("warning: x\n'Exact.client' depends on axioms: [propext, Quot.sound]\n"),False)
record('compiler failure',lambda:logtest(change=lambda r:r.update(exit_code=1)),False)
record('timed out PASS is rejected',lambda:logtest(change=lambda r:r.update(timed_out=True)),False)
# Source-only graph/control census and unchanged supervisor are bound, not executed.
primary=json.loads((S/'primary-map.json').read_text());compat=json.loads((S/'compatibility-map.json').read_text())
assert len(primary['expected']['modules'])==184 and len(primary['expected']['forced'])==15
assert not any('KSites215Batch'in m for m in primary['expected']['forced'])
assert len(compat['expected']['modules'])==69
for name in ['WFModel','ZFNative','WFTheory']:assert 'BusyBeaver.ZFC.'+name in compat['expected']['forced']
assert sha(Path('/tmp/k215-generic-cd58-check/build.py'))=='08d6d90bdb65a641d375b9c89adae5ed4cabeea325f4d870981d80459b5b0935'
result={'status':'PASS_METADATA_ONLY','compiler_called':False,'positive':sum(x['expected_accept']for x in checks),'negative':sum(not x['expected_accept']for x in checks),'checks':checks,'inputs':{str(p):sha(p)for p in [S/'build.py',S/'producer-boundary.json',S/'primary-map.json',S/'compatibility-map.json',Path(__file__)]},'scope':'Extracted source/import recursion, producer before/post absence gates and literal report policy only. No Lean, runner, supplied code, compiler or object load.'}
(S/'controls-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
