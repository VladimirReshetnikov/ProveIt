"""Additive current-closure compilation against an immutable phase1 object basis.

Only a fresh private copy is written. Every reused source/dependency/object/log
binding is checked; changed modules compile serially and release the shared lock.
"""
from pathlib import Path
import argparse, fcntl, hashlib, importlib.util, json, os, re, shutil, signal, sys

REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
FORMAL=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal'
BASIS=Path('/tmp/k215-proof-simplification/root')
PHASE1=FORMAL/'verification/k215/simplification/lean/result.json'
HELPER=FORMAL/'verification/k215/lean/build.py'
COMPILER=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
BOUNDARY=Path('/tmp/k215-lean-complete/toolchain-boundary-v5.json')
LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,required=True)
a=parser.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
with (out/'output.lock').open('a') as exclusive:
 fcntl.flock(exclusive,fcntl.LOCK_EX|fcntl.LOCK_NB)
 spec=importlib.util.spec_from_file_location('reviewed_driver',HELPER)
 driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
 inv=driver.inventory(REPO);assert len(inv['modules'])==185 and inv['external_imports']==['Init']
 project={e['module'] for e in inv['modules']}
 phase1=json.loads(PHASE1.read_text());prior={e['module']:e for e in phase1['module_evidence']}
 old=json.loads((BASIS/'completed.json').read_text());assert len(old)==215 and set(old)==set(prior)
 toolchain=json.loads(BOUNDARY.read_text())
 for key in ['lean','lake','Init.olean','project_toolchain']:
  assert sha(toolchain[key]['path'])==toolchain[key]['sha256'],key
 assert sha(COMPILER)==phase1['compiler_sha256']==toolchain['lean']['sha256']
 basis_objects={m:sha(BASIS/'objects'/(m.replace('.','/')+'.olean')) for m in old}
 for m,r in old.items():
  assert r['status']=='PASS' and r['exit_code']==0 and not r.get('timed_out',False),m
  assert (r['source_sha256'],r['object_sha256'],r['dependencies']) == (prior[m]['source_sha256'],prior[m]['object_sha256'],prior[m]['dependencies']),m
  assert basis_objects[m]==r['object_sha256'],m
  log=Path(r['log']) if 'log' in r else BASIS/prior[m]['compilation_origin'].split('execution.tar.gz/',1)[1]/'compiler.log'
  assert sha(log)==r['log_sha256']==prior[m]['log_sha256'],m
 owner={'repo':str(REPO),'script_sha256':sha(__file__),'helper_sha256':sha(HELPER),
        'phase1_result_sha256':sha(PHASE1),'phase1_completed_sha256':sha(BASIS/'completed.json'),
        'compiler_sha256':sha(COMPILER),'toolchain_boundary_sha256':sha(BOUNDARY)}
 if (out/'owner.json').exists():
  assert json.loads((out/'owner.json').read_text())==owner
  assert json.loads((out/'inventory.json').read_text())==inv,'Source checkpoint changed'
  done=json.loads((out/'completed.json').read_text())
 else:
  assert set(p.name for p in out.iterdir())=={'output.lock'}
  save(out/'owner.json',owner);save(out/'inventory.json',inv);save(out/'basis-objects.json',basis_objects)
  save(out/'toolchain.json',toolchain);save(out/'phase1-completed.json',old)
  shutil.copyfile(HELPER,out/'reviewed-driver.py')
  done={}
  for e in inv['modules']:
   m=e['module'];assert m in old
   obj=out/'objects'/(m.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True)
   shutil.copyfile(BASIS/'objects'/(m.replace('.','/')+'.olean'),obj)
   done[m]={'module':m,'source_sha256':prior[m]['source_sha256'],
            'dependencies':prior[m]['dependencies'],'object_sha256':prior[m]['object_sha256'],
            'log_sha256':prior[m]['log_sha256'],'status':'PASS','origin':'phase1_hash_bound',
            'phase1_compilation_origin':prior[m]['compilation_origin']}
  save(out/'completed.json',done)
 cache=out/'objects';env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
 attempts=out/'attempts';attempts.mkdir(exist_ok=True)
 for e in inv['modules']:
  m=e['module'];source=Path(e['source']);assert sha(source)==e['source_sha256'],m
  deps={d:done[d]['object_sha256'] for d in e['imports'] if d in project}
  for d,h in deps.items():assert sha(cache/(d.replace('.','/')+'.olean'))==h
  obj=cache/(m.replace('.','/')+'.olean');r=done[m]
  if r['source_sha256']==e['source_sha256'] and r['dependencies']==deps and r['object_sha256']==sha(obj):
   if r['origin']=='phase2_fresh':assert sha(r['log'])==r['log_sha256']
   continue
  attempt=attempts/f'{1+len(list(attempts.iterdir())):03d}-{m}';attempt.mkdir()
  shutil.copyfile(source,attempt/source.name)
  root=str(source)[:-len(m.replace('.','/')+'.lean')].rstrip('/')
  command=[str(COMPILER),'-j1','-M12288','--root='+root,'-o',str(obj),str(source)]
  r={'module':m,'source':str(source),'source_sha256':e['source_sha256'],'dependencies':deps,
     'command':command,'compiler_sha256':sha(COMPILER),'timeout_seconds':900,'memory_mebibytes':12288,
     'log':str(attempt/'compiler.log'),'origin':'phase2_fresh'}
  obj.unlink()
  print('CHECK',m,flush=True)
  ok=driver.run_locked(command,REPO,env,LOCK,attempt/'compiler.log',900,r,attempt/'record.json')
  r['source_unchanged']=sha(source)==e['source_sha256']
  r['dependencies_unchanged']=all(sha(cache/(d.replace('.','/')+'.olean'))==h for d,h in deps.items())
  text=(attempt/'compiler.log').read_text()
  r['warnings']=text.count('warning:')
  ok=ok and r['source_unchanged'] and r['dependencies_unchanged'] and 'sorryAx' not in text and "declaration uses 'sorry'" not in text
  r['status']='PASS' if ok else 'FAIL'
  if ok:r['object_sha256']=sha(obj)
  save(attempt/'record.json',r)
  print(r['status'],m,round(r['seconds'],3),flush=True)
  if not ok:print(text[-18000:],flush=True);raise SystemExit(1)
  done[m]=r;save(out/'completed.json',done)
 assert set(done)==project
 assert driver.inventory(REPO)==inv,'Current sources changed during closure build'
 for e in inv['modules']:
  m=e['module'];r=done[m]
  assert r['source_sha256']==sha(e['source']) and r['object_sha256']==sha(cache/(m.replace('.','/')+'.olean'))
  assert r['dependencies']=={d:done[d]['object_sha256'] for d in e['imports'] if d in project}
 audits=[];auditdir=out/f'audit-{1+len(list(out.glob("audit-*"))):03d}';auditdir.mkdir()
 for name,expected in [('EndpointAudit215',2),('K215Audit',8)]:
  source=FORMAL/'verification/k215/lean'/(name+'.lean')
  target=auditdir/source.name;shutil.copyfile(source,target)
  obj=auditdir/(name+'.olean');command=[str(COMPILER),'-j1','-M12288','--root='+str(auditdir),'-o',str(obj),str(target)]
  r={'module':name,'source_sha256':sha(target),'command':command,'project_modules':185,
     'dependencies':{m:done[m]['object_sha256'] for m in done},'timeout_seconds':120,
     'compiler_sha256':sha(COMPILER),'log':str(auditdir/(name+'.log'))}
  ok=driver.run_locked(command,REPO,env,LOCK,Path(r['log']),120,r,auditdir/(name+'.json'))
  text=Path(r['log']).read_text();reports=re.findall(r'depends on axioms: \[([^]]*)\]',text)
  ok=ok and 'warning:' not in text and 'error:' not in text
  ok=ok and len(reports)+text.count('does not depend on any axioms')==expected
  ok=ok and all(set(x.strip() for x in report.split(','))<={'propext','Classical.choice','Quot.sound'} for report in reports)
  ok=ok and sha(target)==r['source_sha256']
  r['status']='PASS' if ok else 'FAIL';r['reports']=reports;r['expected_reports']=expected
  save(auditdir/(name+'.json'),r);print('AUDIT',name,r['status'],flush=True)
  if not ok:print(text);raise SystemExit(1)
  r['object_sha256']=sha(obj);save(auditdir/(name+'.json'),r);audits.append(r)
 assert all(sha(BASIS/'objects'/(m.replace('.','/')+'.olean'))==h for m,h in basis_objects.items())
 assert sha(BASIS/'completed.json')==owner['phase1_completed_sha256']
 assert driver.inventory(REPO)==inv
 assert sha(COMPILER)==owner['compiler_sha256']
 result={'status':'PASS','primary_project_modules':185,'external_imports':['Init'],
         'fresh_modules':sum(r['origin']=='phase2_fresh' for r in done.values()),
         'reused_modules':sum(r['origin']=='phase1_hash_bound' for r in done.values()),
         'basis_objects_unchanged':True,'typed_audits':2,'axiom_reports':10,
         'inventory_sha256':sha(out/'inventory.json'),'completed_sha256':sha(out/'completed.json'),
         'audits':audits,'scope':'Current185-module closure with changed modules rebuilt in a fresh copied cache and all reused phase1 inputs hash-bound. Not a new full fresh185-module replay.'}
 save(out/'result.json',result);print('COMPLETE',json.dumps({k:v for k,v in result.items() if k!='audits'}),flush=True)
