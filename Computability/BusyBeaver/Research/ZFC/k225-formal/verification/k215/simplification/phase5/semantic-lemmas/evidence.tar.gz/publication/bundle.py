"""Preserve held isolated proof-refactor records, without objects or compiler work."""
from pathlib import Path,PurePosixPath
import argparse,difflib,gzip,hashlib,io,json,os,tarfile
HERE=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
DEST=Path('Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase5/semantic-lemmas')
ROOTS={
 'constructible':Path('/tmp/k215-constructible-transport'),
 'internal-sat':Path('/tmp/k215-internalsat-sharing'),
 'peer/constructible':Path('/tmp/k215-constructible-transport-peer'),
 'peer/internal-sat':Path('/tmp/k215-internalsat-sharing-peer'),
}
BAD={'.olean','.ilean','.o','.so','.a','.vo','.vos','.vok','.glob','.pyc','.pyo'}
def digest(b):return hashlib.sha256(b).hexdigest()
def encoded(v):return (json.dumps(v,indent=2)+'\n').encode()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--map',type=Path,required=True);a=ap.parse_args()
 assert not a.out.exists() and not a.map.exists();members={};paths={}
 for prefix,root in ROOTS.items():
  for base,dirs,files in os.walk(root):
   dirs[:]=sorted(d for d in dirs if d not in ('objects','__pycache__') and not (Path(base)/d).is_symlink())
   for name in sorted(files):
    p=Path(base)/name
    if p.is_symlink() or set(p.suffixes)&BAD:continue
    assert p.is_file()
    n=prefix+'/'+p.relative_to(root).as_posix();b=p.read_bytes();assert n not in members
    members[n]=b;paths[str(p)]={'member':n,'sha256':digest(b),'bytes':len(b)}
 for name in ['bundle.py','review_saved.py']:
  members['publication/'+name]=(HERE/name).read_bytes()
 members['paths.json']=encoded(paths)
 read=lambda n:json.loads(members[n])
 c=read('constructible/comparison.json');i=read('internal-sat/comparison-final.json')
 cr=read('constructible/run5/result.json');ir=read('internal-sat/run3/result.json')
 assert cr['status']==ir['status']=='PASS'
 features={
  'ConstructibleAbs':{'baseline_sha256':c['baseline_sha256'],'source_sha256':c['candidate_sha256'],
   'before_bytes':c['before_bytes'],'after_bytes':c['after_bytes'],'before_lines':c['before_lines'],'after_lines':c['after_lines'],
   'unchanged_declarations':73,'unchanged_definitions':7,'changed_proofs':4,'new_private_helpers':2,
   'final_run':'constructible/run5/result.json','seconds':cr['seconds'],'warnings':0,'typed_clients_per_api_run':2,'axiom_reports_per_api_run':5,
   'failed_runs':['run1','run3','run4'],'earlier_passed_runs':['run2']},
  'InternalSat':{'baseline_sha256':i['baseline_source_sha256'],'source_sha256':i['candidate_sha256'],
   'before_bytes':len(members['internal-sat/baseline/InternalSat.lean']),'after_bytes':len(members['internal-sat/InternalSat.lean']),
   'before_lines':len(members['internal-sat/baseline/InternalSat.lean'].splitlines()),'after_lines':len(members['internal-sat/InternalSat.lean'].splitlines()),
   'unchanged_declarations':79,'unchanged_definitions':30,'changed_proofs':10,'new_private_helpers':2,
   'final_run':'internal-sat/run3/result.json','seconds':ir['seconds'],'warnings':0,'axiom_reports_per_run':3,
   'failed_runs':['run1'],'earlier_passed_runs':['run2']}}
 index={n:{'sha256':digest(b),'bytes':len(b)} for n,b in sorted(members.items())}
 out=a.out.resolve();out.mkdir()
 with (out/'evidence.tar.gz').open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as zipped:
   with tarfile.open(fileobj=zipped,mode='w') as tar:
    for n,b in sorted(members.items()):
     t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
 save(out/'index.json',index)
 save(out/'result.json',{'status':'PRESERVED_ISOLATED_KERNEL_AND_API_EVIDENCE','features':features,
  'archive_sha256':digest((out/'evidence.tar.gz').read_bytes()),'archive_members':len(index),
  'compiled_objects_in_archive':False,'basis':'immutable phase4 checkpoint, hashes retained in original records',
  'scope':'Two previously completed isolated module/API checks. No new compiler execution, full-cache copy, current live-provider audit or combined phase5 endpoint claim.'})
 (out/'review_saved.py').write_bytes((HERE/'review_saved.py').read_bytes())
 # Keep the short review-facing artifacts directly accessible, exact original bytes.
 for n in ['constructible/source.diff','constructible/comparison.json','constructible/api-comparison.json',
           'internal-sat/source-final.diff','internal-sat/comparison-final.json',
           'peer/constructible/review.json','peer/internal-sat/review.json','peer/internal-sat/final-review.json']:
  target=out/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(members[n])
 csource=os.path.relpath(REPO/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/ConstructibleAbs.lean',REPO/DEST)
 isource=os.path.relpath(REPO/'SetTheory/BoundedConsistency/Lean/BoundedZFCConsistency/InternalSat.lean',REPO/DEST)
 (out/'README.md').write_text(f'''# Shared semantic lemmas

Two isolated kernel-checked refactors replace repeated reasoning while preserving every original declaration and executable definition. The combined endpoint check is recorded separately in [phase5 Lean evidence](../lean/README.md); this feature packet makes no claim about its outcome.

| Module | Shared argument | Lines | Bytes | Final isolated check |
| --- | --- | ---: | ---: | ---: |
| [ConstructibleAbs]({csource}) | Bounded quantifiers transport between a constructible subtype and ambient members by transitivity | 997 → 992 | 52,100 → 52,054 | 3.371s, no warnings |
| [InternalSat]({isource}) | Pair/numeral equality factors constructor-tag inversions; clause specifications compose existing equivalences | 1,433 → 1,321 | 66,837 → 60,730 | 2.877s, no warnings |

ConstructibleAbs adds two private transport lemmas and reuses them in four proofs. All 73 existing declarations and seven definitions remain unchanged. The quantified satisfaction argument still restricts the outer code witness before transporting the bounded object quantifier. Identical baseline/candidate clients pass, with five unchanged standard-axiom reports in each run. See the [complete diff](constructible/source.diff), [API comparison](constructible/api-comparison.json) and [independent source peer](peer/constructible/review.json).

InternalSat adds two private equality lemmas, removing 56 repeated impossible-tag branches from eight inversions. Two formula specifications then compose existing equivalences. The tag lemmas do not restrict potentially nonstandard payloads; the certificate-functionality proof is unchanged. All 79 existing headers and 30 definitions/structures remain unchanged, and the three axiom reports match the baseline. See the [complete diff](internal-sat/source-final.diff), [comparison](internal-sat/comparison-final.json), [source peer](peer/internal-sat/review.json) and [final comment-only successor acknowledgment](peer/internal-sat/final-review.json). ConstructibleReflect and NamedForm254 were inspected without changes.

`evidence.tar.gz` and [index.json](index.json) preserve all held text sources, source versions, comparison scripts, original runners, raw logs, records and peers. ConstructibleAbs failed inference attempts 1/3/4, earlier successful 2 and final 5 remain distinct. InternalSat failed 1, corrected 2 and comment-only final 3 are retained. Each final invocation used one worker, the shared proof lock, 120s and 12,288MiB caps. Historical `canonical_unchanged` fields refer to the isolated checks before integration. Original absolute scratch paths are retained; `paths.json` maps them to archive members. No object files or full predecessor cache are included.

Attribution: review_upstream_reflection authored the ConstructibleAbs refactor; drop_contract independently reviewed its proof delta. opening_encoder authored the InternalSat refactor; review_upstream_reflection reviewed its proof delta and final comment successor. The saved reader checks records and source/log bindings without running Lean or archived code:

```sh
python3 review_saved.py --output /tmp/k215-semantic-lemmas-review.json
```

It does not recreate the original kernel checks or independently verify live predecessor objects. The [result](result.json) records that bounded scope; the full current closure belongs to the separate combined evidence.
''')
 for origin,entry in paths.items():assert digest(Path(origin).read_bytes())==entry['sha256']
 files=[]
 for p in sorted(out.rglob('*')):
  if p.is_file():files.append({'source':str(p),'destination':str(DEST/p.relative_to(out)),'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size})
 save(a.map,{'status':'FROZEN_FEATURE_PACKET','files':files,'file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),'archive_members':len(index),'original_inputs_unchanged':True})
 print(json.dumps({'status':'PACKAGED_SAVED_FEATURE_EVIDENCE','files':len(files),'archive_members':len(index),'bytes':sum(x['bytes'] for x in files)},indent=2))
if __name__=='__main__':main()
