"""Bind collaborators' inert sources and make the combined source-only census inputs."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):
 assert not p.exists(),p
 p.write_text(json.dumps(x,indent=2)+'\n')
roots=[(Path('/tmp/k215-phase14-derived'),'392d3c0c7e69ddb4a743800ffa62d41635f1b6ad528a9a7bee6c7ee1a8c18341'),(Path('/tmp/k215-phase14-profile'),'39e27cda08d211a0f65edde97f1fb004ab8b6b5e1722eb3e273ae81e76a71593')]
pins={}
for root,pin in roots:
 assert sha(root/'freeze.json')==pin
 pins[str(root/'freeze.json')]=pin
 for rel,row in read(root/'freeze.json')['files'].items():
  assert sha(root/rel)==row['sha256'],rel
  pins[str(root/rel)]=row['sha256']
d=read(roots[0][0]/'freeze.json');p=read(roots[1][0]/'client-plan.json')
sources=[{'module':r['module'],'source':r['candidate'],'source_sha256':r['candidate_sha256'],'imports':r['imports']}for r in d['source_rows']]
sources += [{'module':'BusyBeaver.ZFC.'+Path(r['path']).stem,'source':r['candidate'],'source_sha256':r['candidate_sha256'],'imports':r['imports']}for r in p['candidate_sources']]
assert len(sources)==7
clients=[]
for row in read(roots[0][0]/'clients.json')['clients']:
 clients.append({'module':row['module'],'source':row['source'],'source_sha256':row['sha256'],'imports':row['imports'],'reports':row['reports']})
clients.append({k:p[k]for k in ['module','source','source_sha256','imports']}|{'reports':[r['name']for r in p['reports']],'report_axioms':[r['expected_axioms']for r in p['reports']]})
assert len(clients)==4 and sum(len(r['reports'])for r in clients)==14
save(S/'sources.json',sources);save(S/'clients.json',clients);save(S/'proposal-inputs.json',pins)
print(json.dumps({'status':'REGISTERED_INERT_INPUTS','source_modules':len(sources),'new_clients':len(clients),'new_named_reports':14,'source_or_compiler_execution':False},indent=2))
