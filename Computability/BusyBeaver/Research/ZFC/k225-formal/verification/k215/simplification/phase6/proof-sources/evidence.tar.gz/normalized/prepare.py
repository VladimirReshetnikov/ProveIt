"""Prepare an isolated, deterministic producer candidate; never writes the repository."""
from pathlib import Path
import hashlib,json,shutil,difflib
ROOT=Path('/home/codex/.codex/worktrees/ec20/Proofs')
OUT=Path('/tmp/k215-normalized-migration')
FORM=Path('Computability/BusyBeaver/Research/ZFC/k225-formal')
LEAN=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC')
WORK=OUT/'workspace'
NAMES=['generate_source215_lean.py','partition_source215_lean.py','generate_sites215_lean.py','prepare_k215.py','generate_source225_lean.py','gen_cert.py','generate_boot221_lean.py','generate_dense219_lean.py','generate_tables_lean.py']
for name in NAMES:
 p=FORM/name;(WORK/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,WORK/p)
 (OUT/'baseline'/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,OUT/'baseline'/p)
for p in [FORM/'lean215/dagperm_nodes.json',FORM/'lean215/dagperm_sites.json',FORM.parent/'candidate-k215/sites215.json',FORM.parent/'candidate-k215/k215.native.tm',FORM.parent/'candidate-k215/canonicalization.json']:
 (WORK/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,WORK/p)
(WORK/LEAN).mkdir(parents=True,exist_ok=True)
for p in sorted((ROOT/LEAN).glob('KSource215*.lean'))+sorted((ROOT/LEAN).glob('KSites215*.lean')):
 (OUT/'baseline'/LEAN).mkdir(parents=True,exist_ok=True);shutil.copyfile(p,OUT/'baseline'/LEAN/p.name)
shutil.copyfile('/tmp/k215-normalized-decoder/final/RMNormalizedBisim.lean',WORK/LEAN/'RMNormalizedBisim.lean')
# The endpoint previously obtained KSource215 transitively through site coverage.
p=LEAN/'KEndpoint215.lean';shutil.copyfile(ROOT/p,OUT/'baseline'/p)
text=(ROOT/p).read_text();assert 'import BusyBeaver.ZFC.KSource215\n' not in text
(WORK/p).write_text('import BusyBeaver.ZFC.KSource215\n'+text)


p=WORK/FORM/'generate_source215_lean.py';s=p.read_text()
s=s.replace('certificate comes from `gen_cert.py` (2,240 entries, all offsets zero). Its\nfour-field ordinary rendering uses the generic checker with 512 steps of pointer decoding.', 'literal certificate comes from `gen_cert.py` (2,240 zero-offset entries). The\nSource168 trailing-zero quotient reduces it to 1,426 entries; the decoder-parametric\nnormalized checker uses an explicit 512-step pointer decoder.')
pos=s.index('\ndef ordinary_tree(')
s=s[:pos]+'''
def trailing_false_quotient(entries):
    """Quotient both endpoint paths, preserving the root and both successors.

    The normalization and saturated checker originate in Source168 / batch205A.
    This producer checks the quotient of the maintained literal certificate;
    Lean independently checks the emitted normalized certificate. Path trimming
    is never applied before a consumed-path increment or break operation.
    """
    def trim(path):
        end = len(path)
        while end and not path[end - 1]:
            end -= 1
        return tuple(path[:end])

    index, representatives, old_to_new = {}, [], []
    for a, b, z, _j, _k in entries:
        assert z == 0, "the normalized certificate requires zero offsets"
        key = (trim(a), trim(b))
        if key not in index:
            index[key] = len(representatives)
            representatives.append(key)
        old_to_new.append(index[key])
    assert entries and old_to_new[0] == 0
    quotient = [None] * len(representatives)
    for i, (_a, _b, _z, j, k) in enumerate(entries):
        assert 0 <= j < len(entries) and 0 <= k < len(entries)
        q = old_to_new[i]
        a, b = representatives[q]
        row = (a, b, 0, old_to_new[j], old_to_new[k])
        assert quotient[q] is None or quotient[q] == row, "inconsistent quotient successors"
        quotient[q] = row
    assert all(row is not None for row in quotient)
    return quotient

''' +s[pos:]
s=s.replace('entries = generate(Tree(L1), Tree(L2))','literal_entries = generate(Tree(L1), Tree(L2))\n    entries = trailing_false_quotient(literal_entries)\n    assert len(literal_entries) == 2240 and len(entries) == 1426')
s=s.replace('WithDecoder.','RMNormalizedBisim.WithDecoder.')
s=s.replace('out = f"""import BusyBeaver.ZFC.RMBisim','out = f"""import BusyBeaver.ZFC.RMNormalizedBisim')
a='layout, so an ordinary segment bisimulation relates them: {len(entries)} pairs of register-test\nsites. Every certificate offset is zero; the four-field data omits that redundant field. The certificate is from `k225-formal/gen_cert.py` and is checked here\nonce in chunks; generic bisimulation symmetry supplies the converse. Pointer decoding uses'
b='layout. The {len(literal_entries)} literal checkpoint pairs from `gen_cert.py` are quotiented by\ntrailing-zero equivalence on both paths, leaving {len(entries)} normalized pairs. The quotient\npreserves the root and both successor classes; the kernel checks all resulting obligations\nin sixteen chunks. The normalized relation supplies an all-register bisimulation and its\nconverse. The normalization is adapted from Source168 / batch205A. Pointer decoding uses'
assert a in s;s=s.replace(a,b)
s=s.replace('f"wrote {TARGET}: {len(entries)} entries ({nz} offset)', 'f"wrote {TARGET}: {len(literal_entries)} literal / {len(entries)} normalized entries ({nz} offset)')
p.write_text(s)

p=WORK/FORM/'partition_source215_lean.py';s=p.read_text()
s=s.replace('into data, individual kernel checks, and its facade.','into stable program data, certificate data, checks, and its facade.')
a="    common=s[:fw]+end\n    files={'KSource215Data.lean':common};mapping=[];order=['KSource215Data']"
b='''    common=s[:fw]+end
    stable_names = ['p215Nodes', 'p215', 't215', 't215_eq']
    stable = []
    for name in stable_names:
        matches = list(re.finditer(r'(?m)^(?:def|theorem) ' + name + r'\\b', common))
        assert len(matches) == 1, name
        start = matches[0].start()
        stop = common.index('\\n\\n', start)
        stable.append(common[start:stop])
        common = common[:start] + common[stop + 2:]
    # These comments described the moved declarations, not the retained certificate.
    for comment in ["/-! ## The 215's source -/\\n\\n",
                    "/-- The 215's source as a 179-node DAG (root 178). -/\\n",
                    "/-- The 215's decoder tree, written out. -/\\n"]:
        assert common.count(comment) == 1
        common = common.replace(comment, '')
    stable_module = ('import BusyBeaver.ZFC.RMBisim\\n\\n'
                     '/-! Stable K215 program declarations, independent of source certificates. -/\\n\\n'
                     + header + '\\n\\n'.join(stable) + '\\n' + end)
    common = 'import BusyBeaver.ZFC.KSource215Program\\n' + common
    files={'KSource215Program.lean':stable_module, 'KSource215Data.lean':common}
    mapping=[];order=['KSource215Data']'''
assert a in s;s=s.replace(a,b)
s=s.replace('len(order)==18','len(order)==18 and len(files)==19')
p.write_text(s)

p=WORK/FORM/'generate_sites215_lean.py';s=p.read_text();s=s.replace('HEAD = ("import BusyBeaver.ZFC.KSource215\\n','HEAD = ("import BusyBeaver.ZFC.KSource215Program\\n')
s=s.replace('out = ["".join(f"import BusyBeaver.ZFC.{nm}\\n" for nm in files),','out = ["import BusyBeaver.ZFC.KSource215Program\\n" +\n           "".join(f"import BusyBeaver.ZFC.{nm}\\n" for nm in files),')
p.write_text(s)
# Documentation only: preparation already preserves these maintained producers.
p=WORK/FORM/'prepare_k215.py';s=p.read_text();s=s.replace('Ordinary bisimulation with\n512-step pointer decoding supplies both source implications; the site facade composes the checked\nblocks without repeating their paths.', 'Normalized bisimulation with\nexplicit 512-step pointer decoding supplies both source implications. The site checks\nimport stable KSource215Program data, and the facade composes their checked blocks.')
p.write_text(s)
for name in NAMES:
 a=(OUT/'baseline'/FORM/name).read_text();b=(WORK/FORM/name).read_text()
 if a!=b:(OUT/(name+'.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='baseline/'+name,tofile='candidate/'+name)))
rec={'canonical_mutation':False,'compiler_executed':False,'candidate_checker_sha256':hashlib.sha256((WORK/LEAN/'RMNormalizedBisim.lean').read_bytes()).hexdigest(),'files':{n:hashlib.sha256((WORK/FORM/n).read_bytes()).hexdigest()for n in NAMES}}
(OUT/'preparation.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec,indent=2))
