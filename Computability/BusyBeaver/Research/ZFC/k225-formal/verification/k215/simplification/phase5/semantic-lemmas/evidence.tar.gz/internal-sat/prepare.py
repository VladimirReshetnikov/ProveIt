from pathlib import Path
import re, hashlib, json, difflib
P=Path(__file__).resolve().parent
s=(P/'baseline/InternalSat.lean').read_text()
old=s
start=s.index('  unfold Justified\n  constructor',s.index('theorem fJustifiedF_spec'))
end=s.index('\n/-! ## Certificates',start)
s=s[:start]+'''  exact or_congr h0 (or_congr h1 (or_congr h2 (or_congr h3
    (or_congr h4 (or_congr h5 (or_congr h6 h7))))))
'''+s[end:]
start=s.index('theorem justified_memAtom')
helpers='''/-- Equality of coded pairs reduces to equality of their components. -/
private theorem pair_eq_iff (H : ZFAxioms mem) (a b c d : V) :
    kpair H a b = kpair H c d ↔ a = c ∧ b = d :=
  ⟨kpair_inj H a b c d, by rintro ⟨rfl, rfl⟩; rfl⟩

/-- External constructor tags are compared in Nat, not by unfolding their sets. -/
private theorem numeral_eq_iff (H : ZFAxioms mem) (m n : Nat) :
    natV H m = natV H n ↔ m = n :=
  ⟨natV_inj H m n, fun h => congrArg (natV H) h⟩

'''
s=s[:start]+helpers+s[start:]
names=['memAtom','eqAtom','bot','imp','and','or','all','ex']
for name in names:
 start=s.index('theorem justified_'+name)
 body=s.index(' := by\n',start)+len(' := by\n')
 end=s.index('\n\n',body)
 proof='  simp [Justified, pair_eq_iff, numeral_eq_iff] at h\n'
 proof+= '  exact h.2.2\n' if name in ('memAtom','eqAtom') else '  exact h\n'
 s=s[:body]+proof.rstrip()+s[end:]
(P/'Candidate.lean').write_text(s)
(P/'source.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='baseline/InternalSat.lean',tofile='Candidate.lean')))
print(json.dumps({'old_bytes':len(old.encode()),'new_bytes':len(s.encode()),'old_lines':len(old.splitlines()),'new_lines':len(s.splitlines()),'sha256':hashlib.sha256(s.encode()).hexdigest()},indent=2))
