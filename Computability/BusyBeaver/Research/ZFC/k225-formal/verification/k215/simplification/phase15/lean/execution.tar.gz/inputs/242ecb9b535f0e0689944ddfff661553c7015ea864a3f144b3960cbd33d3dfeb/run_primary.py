"""Outer record for the exact held command; execution requires a pinned peer and root GO."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,subprocess,time
S=Path('/tmp/k215-phase15-check');E=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
p=argparse.ArgumentParser();p.add_argument('--peer',type=Path,required=True);p.add_argument('--peer-sha256',required=True);a=p.parse_args()
assert sha(S/'freeze.json')=='bf7ee51d71e671876ca5b1b8c4933493cee3907c993b36b2658e2f4a6196cb06'
frozen=read(S/'freeze.json')['files']
for path,pin in frozen.items():assert sha(S/path)==pin,path
assert sha(a.peer)==a.peer_sha256 and str(read(a.peer)['status']).startswith('PASS')
argv=read(S/'commands.json')['primary'];assert not(S/'primary-run1').exists()
out=E/'primary-run1.stdout';err=E/'primary-run1.stderr';record=E/'primary-run1-outer.json';assert all(not q.exists()for q in [out,err,record])
rec={'status':'RUNNING','argv':argv,'cwd':str(R),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_sha256':sha(__file__),'freeze_sha256':sha(S/'freeze.json'),'peer':str(a.peer),'peer_sha256':sha(a.peer),'head_before':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'stdout':str(out),'stderr':str(err),'compiler_policy':'One shared lock; 12GiB,120s ordinary module/client,900s site batch; exact inner driver owns process-group cleanup.'}
record.write_text(json.dumps(rec,indent=2)+'\n');start=time.monotonic();proc=None
try:
 with out.open('wb')as stdout,err.open('wb')as stderr:
  proc=subprocess.Popen(argv,cwd=R,stdout=stdout,stderr=stderr,start_new_session=True)
  rec['pid']=proc.pid;record.write_text(json.dumps(rec,indent=2)+'\n');code=proc.wait()
 rec.update(status='PASS_OUTER_EXIT_ZERO'if code==0 else'FAIL_OUTER_EXIT',exit_code=code)
except BaseException as exc:
 if proc is not None and proc.poll()is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 rec.update(status='OUTER_EXCEPTION',exception=repr(exc),exit_code=None if proc is None else proc.returncode)
 raise
finally:
 rec.update(seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err))
 rec['frozen_files_unchanged']=all(sha(S/path)==pin for path,pin in frozen.items())
 rec['peer_unchanged']=sha(a.peer)==a.peer_sha256
 record.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2),flush=True)
assert rec['exit_code']==0 and rec['frozen_files_unchanged']and rec['peer_unchanged']
