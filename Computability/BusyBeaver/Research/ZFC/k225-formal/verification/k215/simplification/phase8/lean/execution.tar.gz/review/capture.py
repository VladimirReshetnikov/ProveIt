"""Collect a completed phase-eight run only; never invoke proof tools.

The published phase-seven packet is referenced by immutable relative pins.
"""
from pathlib import Path
import json
import basis_reference
from evidence import binary_name, digest

HERE = Path(__file__).resolve().parent
FORMAL = 'Computability/BusyBeaver/Research/ZFC/k225-formal'
HELPERS = ('evidence.py', 'basis_reference.py', 'basis-reference.json', 'capture.py',
           'review.py', 'review_saved.py', 'publish.py', 'README.template.md')


def arguments(parser):
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--basis', type=Path, default=Path('/tmp/k215-proof-phase7/lean-run1'))
    parser.add_argument('--build', type=Path, default=Path('/tmp/k215-proof-phase8/build.py'))
    parser.add_argument('--basis-repo', type=Path, help='Repository containing the exact published phase7 packet')
    parser.add_argument('--context', type=Path, default=HERE / 'context.json')
    parser.add_argument('--stdout', type=Path, help='Optional original driver console log')


def collect(args):
    run, basis = args.run.resolve(), args.basis.resolve()
    # Refuse even a capture of unfinished compiler work.
    assert json.loads((run / 'result.json').read_text())['status'] == 'PASS'
    members = {}

    def add(name, path):
        path = Path(path)
        assert path.is_file() and not path.is_symlink(), path
        assert name not in members and not binary_name(path)
        members[name] = path.read_bytes()

    for name in ('owner.json', 'inventory.json', 'completed.json', 'basis-completed.json',
                 'basis-inventory.json', 'basis-logs.json', 'toolchain.json',
                 'reviewed-driver.py', 'result.json', 'build.py', 'gates.py',
                 'registered-adoption.json', 'basis-reference.json'):
        add('execution/' + name, run / name)
    owner = json.loads(members['execution/owner.json'])
    registration=json.loads(members['execution/registered-adoption.json'])
    for row in registration['files']:
        add('execution/adopted-sources/'+row['destination'],run/'adopted-sources'/row['destination'])
    add('review/build.py', args.build)
    for name in HELPERS:
        add('review/' + name, HERE / name)
    add('review/context.json', args.context)
    context = json.loads(members['review/context.json'])
    for row in context['files']:
        assert row['member'].startswith('context/') and '..' not in Path(row['member']).parts
        add(row['member'], row['path'])
        data = members[row['member']]
        assert digest(data) == row['sha256'] and len(data) == row['bytes']
    if args.stdout is not None:
        add('review/driver.stdout', args.stdout)
    inventory = json.loads(members['execution/inventory.json'])
    done = json.loads(members['execution/completed.json'])
    old = json.loads(members['execution/basis-completed.json'])
    basis_logs = json.loads(members['execution/basis-logs.json'])
    origins = {}
    for entry in inventory['modules']:
        module = entry['module']
        add('execution/sources/' + module.replace('.', '/') + '.lean', entry['source'])
        if done[module]['origin'] == 'phase7_hash_bound':
            origins[module] = {'basis_member': 'execution/logs/' + module + '.log', 'sha256': done[module]['log_sha256']}
        else:
            add('execution/logs/' + module + '.log', done[module]['log'])
    assert set(basis_logs) == set(old)
    members['execution/reused-log-origins.json'] = (json.dumps(origins, indent=2)+'\n').encode()
    for folder in [run / 'attempts', *sorted(run.glob('audit-*'))]:
        if not folder.exists():
            continue
        assert folder.is_dir() and not folder.is_symlink()
        for path in sorted(folder.rglob('*')):
            assert not path.is_symlink(), path
            if path.is_file() and not binary_name(path):
                add('execution/' + path.relative_to(run).as_posix(), path)
    return members
