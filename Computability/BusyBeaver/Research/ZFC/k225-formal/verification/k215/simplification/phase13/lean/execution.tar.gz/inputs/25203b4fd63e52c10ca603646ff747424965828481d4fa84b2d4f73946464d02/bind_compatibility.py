from pathlib import Path
import hashlib,json,subprocess,time
S=Path('/tmp/k215-phase13-upstream-check');E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((S/'freeze.json').read_text());before={n:sha(S/n)for n in f['files']};assert before==f['files']
command=['python','-B',str(S/'finalize_compatibility.py')];t=time.monotonic()
with (E/'compatibility-finalizer.stdout.txt').open('x')as out,(E/'compatibility-finalizer.stderr.txt').open('x')as err:r=subprocess.run(command,stdout=out,stderr=err)
after={n:sha(S/n)for n in f['files']};record={'status':'PASS_METADATA_BINDING'if r.returncode==0 else'FAIL_METADATA_BINDING','command':command,'exit_code':r.returncode,'seconds':time.monotonic()-t,'freeze_sha256':sha(S/'freeze.json'),'wrapper_sha256':sha(__file__),'frozen_inputs_unchanged':before==after,'primary_result_sha256':sha(S/'primary-run1/result.json'),'stdout_sha256':sha(E/'compatibility-finalizer.stdout.txt'),'stderr_sha256':sha(E/'compatibility-finalizer.stderr.txt'),'compiler_invoked':False}
if r.returncode==0:record.update(map_sha256=sha(S/'compatibility-final-map.json'),plan_sha256=sha(S/'compatibility-final-plan.json'))
(E/'compatibility-binding.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
assert r.returncode==0 and before==after
