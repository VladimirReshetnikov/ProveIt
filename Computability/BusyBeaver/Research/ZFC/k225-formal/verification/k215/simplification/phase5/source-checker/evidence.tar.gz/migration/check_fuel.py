"""Isolated bounded checks, using read-only basis links and fresh target objects."""
from pathlib import Path
import hashlib,json,os,sys,re,signal,importlib.util,shutil
P=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
B=Path('/tmp/k215-proof-phase4/lean-run1')
H=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
save=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
spec=importlib.util.spec_from_file_location('reviewed_supervisor',H);sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
out=P/sys.argv[1];out.mkdir(exist_ok=False)
old=read(B/'completed.json');inv=read(B/'inventory.json');result=read(B/'result.json');tc=read(B/'toolchain.json')
assert result['status']=='PASS' and len(old)==185
assert sha(B/'inventory.json')==result['inventory_sha256'] and sha(B/'completed.json')==result['completed_sha256']
inputs={str(p):sha(p) for p in [Path(__file__),H,*[B/n for n in ['result.json','inventory.json','completed.json','toolchain.json']]]}
cache=out/'objects';sources=out/'source';sources.mkdir();checks=[]
for r in inv['modules']:
 m=r['module'];e=old[m];src=Path(r['source']);obj=B/'objects'/(m.replace('.','/')+'.olean')
 assert e['status']=='PASS' and sha(src)==r['source_sha256']==e['source_sha256']
 assert sha(obj)==e['object_sha256'] and sha(e['log'])==e['log_sha256']
 assert e['dependencies']=={d:old[d]['object_sha256'] for d in r['imports'] if d in old}
 for p,h in [(src,r['source_sha256']),(obj,e['object_sha256']),(Path(e['log']),e['log_sha256'])]:inputs[str(p)]=h
 dst=cache/(m.replace('.','/')+'.olean');dst.parent.mkdir(parents=True,exist_ok=True);dst.symlink_to(obj)
for key in ['lean','lake','Init.olean','project_toolchain']:
 e=tc[key];assert sha(e['path'])==e['sha256'];inputs[e['path']]=e['sha256']
# Reuse only the two fresh, already checked generic-checker providers.
provider_run=Path('/tmp/k215-rmbisim-decoder/run2')
provider_result=read(provider_run/'result.json')
assert provider_result['status']=='PASS' and provider_result['all_inputs_and_basis_objects_unchanged']
inputs[str(provider_run/'result.json')]=sha(provider_run/'result.json')
provided=dict(old); providers=[]
for e in provider_result['checks'][:2]:
 m=e['module']; assert e['status']=='PASS' and e['compiler_sha256']==tc['lean']['sha256']
 assert e['dependencies']=={d:provided[d]['object_sha256'] for d in e['dependencies']}
 obj=provider_run/'objects'/(m.replace('.','/')+'.olean')
 snap=Path(e['command'][-1]); log=Path(e['log'])
 assert sha(snap)==e['source_sha256'] and sha(obj)==e['object_sha256'] and sha(log)==e['log_sha256']
 for path in [snap,obj,log]:inputs[str(path)]=sha(path)
 dst=cache/(m.replace('.','/')+'.olean'); dst.unlink(); dst.symlink_to(obj)
 provided[m]=e;providers.append(e)
save(out/'reused-candidate-providers.json',providers)
for n in sys.argv[2:]:
 src=P/'source'/('BusyBeaver/ZFC/'+n+'.lean')
 if not src.exists():src=REPO/('Computability/BusyBeaver/Lean/BusyBeaver/ZFC/'+n+'.lean')
 dst=sources/('BusyBeaver/ZFC/'+n+'.lean');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);inputs[str(src)]=sha(src)
 checks.append(('BusyBeaver.ZFC.'+n,dst,0))
if (P/'Audit.lean').exists():
 src=P/'Audit.lean';dst=sources/'Audit.lean';shutil.copyfile(src,dst);inputs[str(src)]=sha(src);checks.append(('Audit',dst,1))
save(out/'before.json',inputs);save(out/'basis-completed.json',old);save(out/'toolchain.json',tc);shutil.copyfile(H,out/'supervisor.py')
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1';done=dict(provided);records=[]
for i,(m,src,reports_n) in enumerate(checks):
 dest=cache/(m.replace('.','/')+'.olean')
 # Essential: remove the read-only basis symlink before Lean opens its output.
 if dest.exists() or dest.is_symlink():dest.unlink()
 assert not dest.exists() and not dest.is_symlink()
 clean=sup.without_comments_strings(src.read_text());deps=[x for line in re.findall(r'(?m)^\s*import\s+([^\n]+)',clean) for x in line.split()]
 deps={d:done[d]['object_sha256'] for d in deps}
 a=out/f'check{i+1}';a.mkdir();shutil.copyfile(src,a/src.name)
 row={'module':m,'source_sha256':sha(src),'dependencies':deps,'compiler_sha256':tc['lean']['sha256'],'timeout_seconds':120,'memory_mebibytes':12288,'log':str(a/'compiler.log')}
 cmd=[tc['lean']['path'],'-j1','-M12288','--root='+str(sources),'-o',str(dest),str(src)];row['command']=cmd
 print('CHECK',m,flush=True);ok=sup.run_locked(cmd,sources,env,Path('/tmp/proveit-k215-proof-build.lock'),a/'compiler.log',120,row,a/'record.json')
 text=(a/'compiler.log').read_text();row['warnings']=text.count('warning:');row['reports']=re.findall(r'depends on axioms: \[([^]]*)\]',text)
 ok=ok and 'error:' not in text and 'sorryAx' not in text and "declaration uses 'sorry'" not in text
 ok=ok and sha(src)==row['source_sha256'] and all(sha(cache/(d.replace('.','/')+'.olean'))==h for d,h in deps.items())
 if reports_n:ok=ok and not row['warnings'] and len(row['reports'])+text.count('does not depend on any axioms')==reports_n
 ok=ok and all({x.strip() for x in r.split(',')} <= {'propext','Classical.choice','Quot.sound'} for r in row['reports'])
 row['status']='PASS' if ok else 'FAIL'
 if ok:row['object_sha256']=sha(dest);done[m]=row
 save(a/'record.json',row);records.append(row);print(row['status'],round(row['seconds'],3),flush=True)
 if not ok:print(text,flush=True);break
post=all(sha(p)==h for p,h in inputs.items());save(out/'completed.json',done)
save(out/'result.json',{'status':'PASS' if post and len(records)==len(checks) and all(r['status']=='PASS' for r in records) else 'FAIL','checks':records,'all_inputs_and_basis_objects_unchanged':post,'basis':'Immutable phase4 plus two verified run2 candidate providers, symlinked read-only; only decoder control fresh, no Data/chunk/fullclosure check.'})
print('POST',post,flush=True)
