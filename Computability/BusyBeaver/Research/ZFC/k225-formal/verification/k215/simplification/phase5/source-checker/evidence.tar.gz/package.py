"""Package source/check records only; never copy compiled providers."""
from pathlib import Path
import hashlib,io,json,tarfile,gzip,subprocess
P=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
D={}
def put(name,data):
 assert name not in D and not name.startswith('/') and '..' not in Path(name).parts
 assert not any(x in name for x in ['.olean','.ilean','.pyc'])
 D[name]=data
for label,root,names in [
 ('rmequiv',Path('/tmp/k215-rmequiv-fwd'),['README.md','prepare.py','check.py','Audit.lean','source.diff','comparison.json','RMEquiv-original.lean','source/BusyBeaver/ZFC/RMEquiv.lean']),
 ('decoder',Path('/tmp/k215-rmbisim-decoder'),['README.md','prepare.py','check.py','Audit.lean','source.diff','comparison.json','RMBisim-original.lean','source/BusyBeaver/ZFC/RMBisim.lean','history/prepare-v1.py']),
 ('migration',Path('/tmp/k215-zero-offset-peer'),['compare.py','comparison.json','comparison.stdout','check_fuel.py','Audit.lean','FuelControl.lean','FuelControl-data-draft.lean','review.json'])]:
 for name in names:put(label+'/'+name,(root/name).read_bytes())
 runs=['fuel-run1'] if label=='migration' else ['run1','run2']
 for run in runs:
  folder=root/run
  for f in sorted(folder.rglob('*')):
   rel=f.relative_to(folder)
   if f.is_file() and not f.is_symlink() and 'objects' not in rel.parts and f.suffix in {'.json','.log','.py','.lean'}:
    put(label+'/'+run+'/'+rel.as_posix(),f.read_bytes())
W=Path('/tmp/k215-zero-offset/workspace')
F='Computability/BusyBeaver/Research/ZFC/k225-formal/'
L='Computability/BusyBeaver/Lean/BusyBeaver/ZFC/'
for name in ['generate_source215_lean.py','partition_source215_lean.py','generate_source225_lean.py','gen_cert.py']:
 put('producer/new/'+name,(W/F/name).read_bytes())
 if name in ['generate_source215_lean.py','partition_source215_lean.py']:
  put('producer/original/'+name,subprocess.check_output(['git','show','05d063acef:'+F+name],cwd=R))
for f in sorted((W/L).glob('KSource215*.lean')):put('producer/new/'+f.name,f.read_bytes())
old_data=subprocess.check_output(['git','show','05d063acef:'+L+'KSource215Data.lean'],cwd=R)
assert hashlib.sha256(old_data).hexdigest()==json.loads(D['migration/comparison.json'])['old_data']['sha256']
put('producer/original/KSource215Data.lean',old_data)
put('producer/original/KSource215.lean',subprocess.check_output(['git','show','05d063acef:'+L+'KSource215.lean'],cwd=R))
put('package.py',Path(__file__).read_bytes())
index={n:{'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)} for n,b in sorted(D.items())}
(P/'index.json').write_text(json.dumps(index,indent=2)+'\n')
with (P/'evidence.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for n,b in sorted(D.items()):
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b))
with tarfile.open(P/'evidence.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(index)
 for m in members:
  assert m.isfile() and not m.issym() and m.name in index
  b=tar.extractfile(m).read();assert len(b)==index[m.name]['size'] and hashlib.sha256(b).hexdigest()==index[m.name]['sha256']
summary={'status':'PACKAGED_CHECKED_SOURCE_CHANGES_AND_MIGRATION_PEER','archive_sha256':hashlib.sha256((P/'evidence.tar.gz').read_bytes()).hexdigest(),'index_sha256':hashlib.sha256((P/'index.json').read_bytes()).hexdigest(),'members':len(D),'compressed_bytes':(P/'evidence.tar.gz').stat().st_size,'compiled_objects_in_archive':False,'kernel_scope':'Fresh RMEquiv/RMBisim isolated modules and typed API clients; one axiom-free decoder-mismatch control. No Data/chunk/fullclosure kernel replay in this packet.','full_certificate_scope':'All2240 entries independently parsed and compared; parent owns full16 fresh ordinary-certificate checks.'}
(P/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
