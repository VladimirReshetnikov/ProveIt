"""Bind a completed primary run into the separate compatibility map; no compiler."""
from pathlib import Path
import hashlib,json,re,importlib.util
S=Path(__file__).resolve().parent;P=S/'primary-run1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,v):assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n')
freeze=read(S/'freeze.json')
for name,pin in freeze['files'].items():assert sha(S/name)==pin,name
result=read(P/'result.json');inv=read(P/'inventory.json');done=read(P/'completed.json');before=read(P/'before.json')
assert result['status']=='PASS'and result['selected_project_modules']==184
assert result['runner_sha256']==sha(S/'build.py')and result['map_sha256']==sha(S/'primary-map.json')
assert result['producer_boundary_sha256']==sha(S/'producer-boundary.json')
assert result['inventory_sha256']==sha(P/'inventory.json')and result['completed_sha256']==sha(P/'completed.json')
assert [r['module']for r in inv['modules']]==read(S/'primary-map.json')['expected']['modules']
assert set(done)=={r['module']for r in inv['modules']}
assert result['force_basis_rebuild_modules']==read(S/'primary-map.json')['expected']['forced']
assert set(result['fresh_modules'])==set(result['force_basis_rebuild_modules'])and not result['secondary_reused_modules']
gates=Path('/tmp/k215-proof-phase8/gates.py');assert sha(gates)=='b2dcfb0f69372e25b14ed479382739966bad1488dc05289b3e5fc4ed7bdc1475'
spec=importlib.util.spec_from_file_location('endpoint_gates',gates);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
assert [r['module']for r in result['audits']]==list(g.AUDIT_PINS)
for p,h in before['inputs'].items():assert sha(p)==h,p
for p in before['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink(),p
for row in inv['modules']:
 m=row['module'];r=done[m];assert r['status']=='PASS'and r.get('exit_code',0)==0 and not r.get('timed_out',False)
 assert sha(row['source'])==r['source_sha256']==row['source_sha256']
 assert sha(P/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']
 assert sha(r['log'])==r['log_sha256']
 assert r['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
for r in result['audits']:
 name=r['module'];d=P/('audit-'+name)
 assert r['status']=='PASS'and r['exit_code']==0 and not r['timed_out']
 assert sha(r['log'])==r['log_sha256']and sha(r['source'])==r['source_sha256']
 assert sha(d/(name+'.lean'))==r['source_sha256']and sha(d/(name+'.olean'))==r['object_sha256']
 assert r['dependencies']=={m:x['object_sha256']for m,x in done.items()}
 txt=Path(r['log']).read_text();assert 'warning:'not in txt and 'error:'not in txt and 'sorryAx'not in txt
 assert r['source_sha256']==g.AUDIT_PINS[name]
 assert [list(x)for x in g.audit_reports(name,txt)]==r['named_reports']
mp=read(S/'compatibility-map.json')
mp['reuse_ledger']={'directory':str(P),**{n:sha(P/n)for n in ['result.json','inventory.json','completed.json']}}
save(S/'compatibility-final-map.json',mp)
plan=read(S/'compatibility-plan.json');plan['status']='READY_AFTER_PRIMARY_PASS_NOT_EXECUTED';plan['command']=['python','-B',str(S/'build.py'),'--out',str(S/'compatibility-run1'),'--map',str(S/'compatibility-final-map.json'),'--reuse',str(P),'--target','WFModelCompat12','--target','ZFNativeCompat12'];plan['inputs'][str(S/'compatibility-final-map.json')]=sha(S/'compatibility-final-map.json')
save(S/'compatibility-final-plan.json',plan)
print(json.dumps({'status':'BOUND_PRIMARY_PASS_NO_COMPILER','primary_result_sha256':sha(P/'result.json'),'map_sha256':sha(S/'compatibility-final-map.json'),'command':plan['command']},indent=2))
