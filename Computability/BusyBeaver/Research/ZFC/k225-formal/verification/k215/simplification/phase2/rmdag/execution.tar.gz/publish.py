from pathlib import Path
import gzip,hashlib,io,json,os,shutil,tarfile
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs');work=Path('/tmp/k215-concision-round2/root');dest=repo/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase2/rmdag';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canonical=repo/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/RMDag.lean';assert sha(canonical)==sha(work/'RMDag.final.lean')
files=sorted({*(p for p in work.glob('run*/**/*')if p.is_file() and 'objects'not in p.parts and p.suffix in {'.lean','.json','.log'}),*(p for p in work.glob('audit/*')if p.suffix in {'.lean','.json','.log'}),*(p for p in work.glob('final-audit/*')if p.suffix in {'.lean','.json','.log','.py'}),*(p for p in work.glob('RMDag*.lean')),work/'check.py',work/'adoption.json',Path(__file__)})
index={str(p.relative_to(work)):sha(p)for p in files}
with(dest/'execution.tar.gz').open('wb')as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for p in files:
    b=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(work)));info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
(dest/'execution-index.json').write_text(json.dumps(index,indent=2)+'\n')
for src,name in [(work/'run007/result.json','source-check.json'),(work/'final-audit/result.json','api-check.json'),(work/'final-audit/Audit.lean','Audit.lean'),(work/'final-audit/compiler.log','api.log'),(Path('/tmp/k215-rmdag-grouped-peer/review.json'),'independent-review.json'),(Path('/tmp/k215-rmdag-grouped-peer/review.py'),'independent-review.py')]:
 if src.exists():shutil.copyfile(src,dest/name)
old=(work/'RMDag.before.lean').read_bytes();new=canonical.read_bytes();summary={'status':'PASS_ISOLATED_KERNEL_AND_TYPED_API','source_sha256':sha(canonical),'before_sha256':hashlib.sha256(old).hexdigest(),'bytes_before':len(old),'bytes_after':len(new),'lines_before':len(old.splitlines()),'lines_after':len(new.splitlines()),'public_statements_unchanged':True,'all_other_code_unchanged':True,'run_det_axioms_before':['propext'],'run_det_axioms_after':['propext'],'source_check_sha256':sha(dest/'source-check.json'),'api_check_sha256':sha(dest/'api-check.json'),'independent_review_sha256':sha(dest/'independent-review.json'),'archive_sha256':sha(dest/'execution.tar.gz'),'final_endpoint_rebuild':'Recorded separately in ../lean/; this packet is the isolated source and typed-client check.'};(dest/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
link=os.path.relpath(canonical,dest)
(dest/'README.md').write_text(f'''# Group the register determinism proof by control flow

The [same `run_det` theorem]({link}) now shares its induction argument across
four car exits and four cdr exits. A non-normal car determines the node result;
otherwise its induction hypothesis fixes the intermediate register file before
the cdr is compared. The restarting case additionally aligns the next root run.
The primitive instruction cases and all other code are unchanged.

The file shrinks from 367 lines / 17,209 bytes to 302 lines / 12,989 bytes.
The exact final source passed in 2.170 seconds with zero warnings.
The [typed client](Audit.lean) passes and [reports](api.log) only `propext`,
matching the original theorem. The [independent source review](independent-review.json)
checks the case grouping and exact preservation of every public statement and
all other code.

The [result](result.json), [source record](source-check.json), and
[client record](api-check.json) bind the accepted bytes. The
[execution archive](execution.tar.gz) and [index](execution-index.json) retain
failed drafts and the rejected `grind` experiment, which compiled but used
additional classical/quotient axioms. No draft object supplies the final check.
The final endpoint rebuild is recorded [separately](../lean/README.md).
''')
print('PUBLISHED',len(files),'archive members',summary)
