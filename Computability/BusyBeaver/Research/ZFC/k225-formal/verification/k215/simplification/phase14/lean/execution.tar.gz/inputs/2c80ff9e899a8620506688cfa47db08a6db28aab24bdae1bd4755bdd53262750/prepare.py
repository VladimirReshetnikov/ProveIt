from pathlib import Path
import hashlib,json,re,subprocess,difflib
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');O=Path(__file__).resolve().parent
U=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase13/upstream-merge'
base=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC');names=['TarskiDerived','TarskiLeibniz','KThmK','KEind222']
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(Path(p).read_text())
current=read('/tmp/k215-phase13-root/current-review.json')['sources'];rows=[]
def strip_comments(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s.startswith('/-',i):depth+=1;i+=2;continue
  if depth and s.startswith('-/',i):depth-=1;i+=2;continue
  if not depth and s.startswith('--',i):
   k=s.find('\n',i);i=len(s)if k<0 else k;continue
  if not depth or s[i]=='\n':out.append(s[i])
  i+=1
 assert depth==0;return ''.join(out)
def decls(s):
 s=strip_comments(s);matches=list(re.finditer(r'(?m)^(?:private )?(theorem|def|inductive|class)\s+([^\s:(]+)',s));result={}
 for i,m in enumerate(matches):
  block=s[m.start():matches[i+1].start()if i+1<len(matches)else len(s)]
  head=re.split(r':=|\n  \||\bwhere\b',block,maxsplit=1)[0]
  result[m[2]]={'kind':m[1],'header':' '.join(head.split())}
 return result
removed=['h0','h1','h2','thm_of_der0','ded1','ded2','ded3','syl','contra_thm','contra','dne','dni','imp_cases','all_mono','ex_mono','ex_elim_of_vac','vac_neg','rel_L','rel_R','atom_subst','atom_subst_rev','all_imp_ex']
for n in names:
 rel=base/(n+'.lean');cur=(R/rel).read_bytes();raw=(U/'inputs'/rel).read_bytes();git=subprocess.check_output(['git','show','ac61181dda126bf0be9f5ccd4e2843193f9ab9e9:'+str(rel)],cwd=R)
 assert raw==git;assert sha(cur)==current['BusyBeaver.ZFC.'+n]['sha256'];assert cur==subprocess.check_output(['git','show','1244fd482745bcd039471d90e35cfba0f9ad12ee:'+str(rel)],cwd=R)
 for folder,b in [('before',cur),('upstream',raw),('candidate/BusyBeaver/ZFC',raw)]:
  p=O/folder/(n+'.lean');p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b)
 old,new=decls(cur.decode()),decls(raw.decode())
 if n=='KThmK':assert set(old)-set(new)==set(removed);assert all(old[k]['header']==new[k]['header']for k in new if k in old)
 if n=='KEind222':assert old==new
 imports=lambda b:re.findall(r'(?m)^import\s+(\S+)',b.decode())
 assert imports(cur)==imports(raw)
 rows.append({'module':'BusyBeaver.ZFC.'+n,'target':str(rel),'current_sha256':sha(cur),'upstream_sha256':sha(raw),'before_bytes':len(cur),'upstream_bytes':len(raw),'before_lines':len(cur.splitlines()),'upstream_lines':len(raw.splitlines()),'imports':imports(raw),'retained_headers_equal':n in ['KThmK','KEind222'],'removed_declarations':sorted(set(old)-set(new)),'added_declarations':sorted(set(new)-set(old))})
# Exact sole-use wrapper inlining authorized by root; no replacement of derivation arguments.
p=O/'candidate/BusyBeaver/ZFC/TarskiDerived.lean';s=p.read_text();old=s
block="/-- Derivations from hypotheses discharge into theorems. -/\ntheorem of_der {G : List NF} {a : NF} (d : Der NF.imp T G a)\n    (hG : ∀ x, x ∈ G → T x) : T a :=\n  d.sound hC hG\n\n"
assert s.count(block)==1;s=s.replace(block,'');assert s.count('  of_der hC d (fun _ hx => absurd hx List.not_mem_nil)')==1;s=s.replace('  of_der hC d (fun _ hx => absurd hx List.not_mem_nil)','  d.sound hC (fun _ hx => absurd hx List.not_mem_nil)');p.write_text(s)
assert 'of_der'not in strip_comments(s).replace('thm_of_der0','')
(O/'inlining.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='upstream/TarskiDerived.lean',tofile='candidate/TarskiDerived.lean')))
# All selected 199 current files and maintained-root callers, excluding historical research/docs.
for m,r in current.items():assert sha(Path(r['current']).read_bytes())==r['sha256'],m
tracked=subprocess.check_output(['git','ls-files','-z','*.lean'],cwd=R).decode().split('\0');maintained=[x for x in tracked if x and '/Research/'not in x and '/docs/'not in x]
hits=[];deleted_hits=[]
pat=re.compile(r'\b(?:KThmK|SetTheory\.BusyBeaver\.ZFC\.KThmK)\.('+'|'.join(removed)+r')\b')
for rel in maintained:
 t=(R/rel).read_text()
 for i,line in enumerate(t.splitlines(),1):
  if re.search(r'\bof_der\b',line):hits.append({'path':rel,'line':i,'text':line})
  if pat.search(line):deleted_hits.append({'path':rel,'line':i,'text':line})
assert len(hits)==2 and all(x['path']==str(base/'TarskiDerived.lean')for x in hits);assert not deleted_hits
# No extra equality-vacuity field or stronger calculus definition enters the candidate.
t=(O/'upstream/TarskiDerived.lean').read_text();fields=re.findall(r'^  (\w+)\b',t.split('class Rows',1)[1].split('instance ',1)[0],re.M);assert fields==['gen','rho2','rho4','rho6','rho1','rho7','rho5','rho3','vacRel']
for r in rows:
 p=O/'candidate'/Path(r['module'].replace('.','/')+'.lean');b=p.read_bytes();r.update(candidate=str(p),candidate_sha256=sha(b),candidate_bytes=len(b),candidate_lines=len(b.splitlines()))
result={'status':'SOURCE_ONLY_PREPARED_NOT_COMPILED','baseline_commit':'1244fd482745bcd039471d90e35cfba0f9ad12ee','upstream_commit':'ac61181dda126bf0be9f5ccd4e2843193f9ab9e9','rows':rows,'selected_current_sources_rehashed':len(current),'maintained_lean_files_scanned':len(maintained),'of_der_occurrences':hits,'qualified_deleted_helper_callers':deleted_hits,'removed_KThmK_names':removed,'Rows_fields':fields,'inlining_removed_public_name':'SetTheory.BusyBeaver.ZFC.Tarski.of_der','inlining_removed_block_sha256':sha(block.encode()),'inlining_diff_sha256':sha((O/'inlining.diff').read_bytes()),'metrics':{k:sum(r[k]for r in rows)for k in ['before_bytes','upstream_bytes','candidate_bytes','before_lines','upstream_lines','candidate_lines']},'scope':'Own read-only hash/API/caller/source transformation; no compiler, producer or submitted program execution. Maintained-source census excludes archived research/docs. No API claim for unknown external callers.'}
(O/'comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'metrics':result['metrics'],'comparison_sha256':sha((O/'comparison.json').read_bytes())}))
