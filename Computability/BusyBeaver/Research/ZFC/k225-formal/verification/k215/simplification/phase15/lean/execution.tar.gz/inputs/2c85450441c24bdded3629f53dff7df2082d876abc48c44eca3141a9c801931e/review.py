from pathlib import Path
import argparse,hashlib,json,re
p=argparse.ArgumentParser();p.add_argument('mode',choices=['primary','compatibility']);p.add_argument('--output',required=True,type=Path);args=p.parse_args();assert not args.output.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
S=Path('/tmp/k215-phase15-check');R=S/('primary-run3'if args.mode=='primary'else'compatibility-run1');B=Path('/tmp/k215-phase14-check/primary-run2');C=Path('/tmp/k215-phase14-check/compatibility-run1');E=Path('/tmp/k215-phase15-execution');new=read(R/'completed.json');inv=read(R/'inventory.json');result=read(R/'result.json');before=read(R/'before.json');tool=read(R/'toolchain.json');assert tool==read(B/'toolchain.json')==read(C/'toolchain.json')
for k,v in tool.items():
 if k in ['lean','lake','Init.olean']:assert sha(v['path'])==v['sha256']
old={};oldrows={};origin={}
for root,kind in [(C,'phase14_compatibility_checked'),(B,'phase14_primary_checked')]:
 d=read(root/'completed.json')
 for row in read(root/'inventory.json')['modules']:
  m=row['module']
  if m in old:assert (row['source_sha256'],row['imports'],d[m]['object_sha256'])==(oldrows[m]['source_sha256'],oldrows[m]['imports'],old[m]['object_sha256'])
  old[m]=d[m];oldrows[m]=row;origin[m]=kind
entries={r['module']:r for r in inv['modules']};assert len(new)==len(entries)==(194 if args.mode=='primary'else 71)
closures={}
for row in inv['modules']:
 m=row['module'];assert all(d in closures or d=='Init'for d in row['imports']);closures[m]={m}.union(*(closures[d]for d in row['imports']if d!='Init'))
changed={m for m,r in entries.items()if m not in oldrows or (r['source_sha256'],r['imports'])!=(oldrows[m]['source_sha256'],oldrows[m]['imports'])};forced={m for m in entries if closures[m]&changed}
assert result['status']=='PASS'and result['source_changed_modules']==sorted(changed)and result['force_basis_rebuild_modules']==sorted(forced)
assert before['rows']==inv['modules']and before['changed_sources']==sorted(changed)and before['force_basis_rebuild']==sorted(forced)
for k in ['inventory','completed']:assert result[k+'_sha256']==sha(R/(k+'.json'))
for path,pin in before['inputs'].items():assert sha(path)==pin,path
for path in before['absent_inputs']:assert not Path(path).exists()and not Path(path).is_symlink()
std={'propext','Classical.choice','Quot.sound'}
def reports(path):
 t=Path(path).read_text();assert 'error:'not in t and 'sorryAx'not in t
 r=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",t);assert all(set(a.strip()for a in ax.split(',')if a.strip())<=std for n,ax in r);return r,t
counts={};warnings={};allreports={};first=read(S/'primary-run1/completed.json');second=read(S/'primary-run2/completed.json');primary=read(S/'primary-run3/completed.json');pr={r['module']:r for r in read(S/'primary-run3/inventory.json')['modules']}
for m,row in entries.items():
 r=new[m];assert r['status']=='PASS'and r.get('exit_code',0)==0 and not r.get('timed_out',False)
 assert sha(row['source'])==row['source_sha256']==r['source_sha256'];assert re.findall(r'^import\s+([\w.]+)\s*$',Path(row['source']).read_text(),re.M)==row['imports'];assert sha(R/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256'];assert sha(r['log'])==r['log_sha256'];assert r['dependencies']=={d:new[d]['object_sha256']for d in row['imports']if d!='Init'}
 rr,t=reports(r['log']);k=r['origin'];counts[k]=counts.get(k,0)+1;warnings[k]=warnings.get(k,0)+t.count('warning:')
 if rr:allreports[m]=rr
 if k=='candidate_fresh':
  root=R if args.mode=='compatibility'else S/('primary-run1'if m in first else'primary-run2'if m in second else'primary-run3');src=root/'workspace'/(m.replace('.','/')+'.lean');obj=root/'objects'/(m.replace('.','/')+'.olean')
  assert r['command']==[tool['lean']['path'],'-j1','-M12288','--root='+str(root/'workspace'),'-o',str(obj),str(src)];assert r['compiler_sha256']==tool['lean']['sha256']and r['timeout_seconds']==120 and r['memory_mebibytes']==12288;assert sha(src)==row['source_sha256'];assert read(Path(r['log']).parent/'record.json')==r;assert r['reports']==[list(x)for x in rr]
 else:
  d,rs=(primary,pr)if k=='secondary_checked'else(old,oldrows);assert r=={**d[m],'origin':k};assert all((entries[x]['source_sha256'],entries[x]['imports'])==(rs[x]['source_sha256'],rs[x]['imports'])for x in closures[m])
  if k!='secondary_checked':assert m not in forced and origin[m]==k
 if m.endswith('Api')or m.endswith('Compat12'):assert 'warning:'not in t
if args.mode=='primary':
 assert counts=={'phase14_primary_checked':149,'candidate_fresh':45};assert all(new[m]==r for m,r in second.items());assert all(second[m]==r for m,r in first.items())
else:assert counts=={'phase14_compatibility_checked':11,'candidate_fresh':6,'secondary_checked':54}
oldaudits={r['module']:r for r in read(B/'result.json')['audits']};assert len(result['audits'])==(2 if args.mode=='primary'else 0)
for r in result['audits']:
 m=r['module'];q=R/('audit-'+m);rr,t=reports(r['log']);assert 'warning:'not in t;assert [list(x)for x in rr]==r['named_reports']==oldaudits[m]['named_reports'];assert r['status']=='PASS'and r['exit_code']==0 and not r['timed_out'];assert sha(r['source'])==sha(q/(m+'.lean'))==r['source_sha256']==oldaudits[m]['source_sha256'];assert sha(r['log'])==r['log_sha256'];assert sha(q/(m+'.olean'))==r['object_sha256'];assert r['dependencies']=={m:x['object_sha256']for m,x in new.items()};assert r['command']==[tool['lean']['path'],'-j1','-M12288','--root='+str(q),'-o',str(q/(m+'.olean')),str(q/(m+'.lean'))];assert r['timeout_seconds']==120 and r['memory_mebibytes']==12288
outer=read(E/(R.name+'-outer.json'));assert outer['exit_code']==0 and outer['status']=='PASS_OUTER_EXIT_ZERO'and outer['frozen_files_unchanged']
for k in ['stdout','stderr']:assert sha(outer[k])==outer[k+'_sha256']
if args.mode=='primary':
 mp=Path('/tmp/k215-phase15-client-retry/compatibility-final-map.json');a=read(mp);b=read(mp.with_name('compatibility-template.json'));assert a=={**b,'reuse_ledger':a['reuse_ledger']};assert a['reuse_ledger']=={'directory':str(R),**{n:sha(R/n)for n in ['result.json','inventory.json','completed.json']}}
 source_map=Path('/tmp/k215-phase15-client-retry/primary-map.json')
else:source_map=Path('/tmp/k215-phase15-client-retry/compatibility-final-map.json')
argv=['python3','-B',str(S/'build.py'),'--out',str(R),'--map',str(source_map)]
if args.mode=='compatibility':argv+=['--reuse',str(S/'primary-run3')]
for t in inv['targets']:argv+=['--target',t]
if args.mode=='primary':argv+=['--audit-endpoint']
assert outer['argv']==argv and result['map_sha256']==sha(source_map)
rr={'status':'PASS_INDEPENDENT_READ_ONLY_ACTUAL','mode':args.mode,'result_sha256':sha(R/'result.json'),'outer_sha256':sha(E/(R.name+'-outer.json')),'outer_exit_code':0,'providers':len(new),'counts':counts,'warnings':warnings,'before_inputs':len(before['inputs']),'source_transitive_reuse_checked':True,'all_sources_objects_logs_dependencies_toolchain_rehashed':True,'endpoint_reports':sum(len(r['named_reports'])for r in result['audits']),'profiles':allreports,'compatibility_final_map_sha256':sha('/tmp/k215-phase15-client-retry/compatibility-final-map.json'),'checker_sha256':sha(__file__),'compiler_or_producer_invoked':False}
args.output.write_text(json.dumps(rr,indent=2)+'\n');print(sha(args.output))
