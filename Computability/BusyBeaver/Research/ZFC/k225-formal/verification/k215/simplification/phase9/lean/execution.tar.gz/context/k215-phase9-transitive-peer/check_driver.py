from pathlib import Path
import ast,copy,json,hashlib
O=Path(__file__).resolve().parent;p=Path('/tmp/k215-phase9-main/build-v4.py');sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();read=lambda x:json.loads(Path(x).read_text())
a=ast.parse(p.read_text());fun=next(n for n in a.body if isinstance(n,ast.FunctionDef)and n.name=='same_transitive_sources')
actual=read(O/'census.json');before=read('/tmp/k215-phase9-main/full-run2/before.json');assert before['changed_sources']==actual['changed_or_new_modules'];assert before['force_basis_rebuild']==actual['transitively_affected'];assert before['runner_sha256']==sha(p)
now={r['module']:r for r in before['rows']};iso={r['module']:r for r in read('/tmp/k215-phase9-main/isolated-run2/inventory.json')['modules']}
ns={'entry_by_name':now,'reuse_rows':iso,'compatible':{}};exec(compile(ast.Module(body=[fun],type_ignores=[]),str(p),'exec'),ns)
assert sorted(m for m in now if ns['same_transitive_sources'](m))==actual['isolated_source_import_closure_exact']
def control(cur,prior,expected):
 n={'entry_by_name':cur,'reuse_rows':prior,'compatible':{}};exec(compile(ast.Module(body=[fun],type_ignores=[]),str(p),'exec'),n);assert n['same_transitive_sources']('A')==expected
base={'A':{'source_sha256':'a','imports':['B']},'B':{'source_sha256':'b','imports':['C']},'C':{'source_sha256':'c','imports':['Init']}}
control(base,copy.deepcopy(base),True)
controls=[]
for change in ['transitive_source','transitive_import','missing_transitive','own_source']:
 prior=copy.deepcopy(base)
 if change=='transitive_source':prior['C']['source_sha256']='oldc'
 if change=='transitive_import':prior['C']['imports']=[]
 if change=='missing_transitive':del prior['C']
 if change=='own_source':prior['A']['source_sha256']='olda'
 control(base,prior,False);controls.append(change)
assert sha(p)==before['runner_sha256']
r={'status':'PASS_SOURCE_ONLY_V4_TRANSITIVE_REUSE_DELTA','driver_sha256':sha(p),'independent_changed_count':11,'independent_affected_count':26,'expected_fresh_without_any_other_accepted_reuse':20,'all_nine_sites_forced':True,'actual_before_pins':{str(q):sha(q)for q in[Path('/tmp/k215-phase9-main/full-run2/before.json'),O/'census.json',p,Path(__file__)]},'actual_ast_pure_gate_controls':{'positive':1,'negative':controls},'source_findings':[],'scope':'Read full v3 driver and v4 delta. The baseline reuse ban covers every transitive source descendant; isolated reuse additionally requires exact recursive source/import equality. Existing object/log/toolchain gates remain. No compiler or full-run2 acceptance yet.'}
(O/'driver-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
