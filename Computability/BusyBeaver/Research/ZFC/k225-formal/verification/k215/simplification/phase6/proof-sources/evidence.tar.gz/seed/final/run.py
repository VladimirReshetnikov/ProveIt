"""One isolated semantic proof+typed endpoint check against the immutable phase5 provider set."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,signal,re
P=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');B=Path('/tmp/k215-proof-phase5/lean-run1')
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def interrupt(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,interrupt)
a=argparse.ArgumentParser();a.add_argument('run');args=a.parse_args();out=P/args.run;out.mkdir(exist_ok=False)
old=json.loads((B/'completed.json').read_text());inv=json.loads((B/'inventory.json').read_text());assert len(old)==len(inv['modules'])==184
pins={m:sha(B/'objects'/(m.replace('.','/')+'.olean'))for m in old};assert all(pins[m]==r['object_sha256']for m,r in old.items())
inputs={str(p):sha(p)for p in [B/'completed.json',B/'inventory.json',B/'result.json',B/'toolchain.json',P/'KSeedModel222.lean',P/'Audit.lean',P/'run.py',H,C]}
for row in inv['modules']:assert sha(row['source'])==row['source_sha256'];inputs[row['source']]=row['source_sha256']
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
cache=out/'objects'
for m in old:
 q=cache/(m.replace('.','/')+'.olean');q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(B/'objects'/(m.replace('.','/')+'.olean'))
module='BusyBeaver.ZFC.KSeedModel222';src=out/'workspace'/(module.replace('.','/')+'.lean');src.parent.mkdir(parents=True);src.write_bytes((P/'KSeedModel222.lean').read_bytes()+(P/'Audit.lean').read_bytes())
obj=cache/(module.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);obj.unlink(missing_ok=True)
spec=importlib.util.spec_from_file_location('checked_supervisor',H);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
cmd=[str(C),'-j1','-M12288','--root='+str(out/'workspace'),'-o',str(obj),str(src)]
row={'source':str(src),'source_sha256':sha(src),'candidate_sha256':sha(P/'KSeedModel222.lean'),'audit_sha256':sha(P/'Audit.lean'),'basis_objects':pins,'inputs':inputs,'compiler_sha256':sha(C),'helper_sha256':sha(H),'runner_sha256':sha(__file__),'command':cmd,'timeout_seconds':120,'memory_mebibytes':12288,'scope':'Single candidate source with appended typed controls; current seed endpoint unchanged; no full endpoint closure rebuild.'}
(out/'before.json').write_text(json.dumps(row,indent=2)+'\n')
ok=helper.run_locked(cmd,R,env,Path('/tmp/proveit-k215-proof-build.lock'),out/'compiler.log',120,row,out/'result.json')
row['basis_unchanged']=all(sha(B/'objects'/(m.replace('.','/')+'.olean'))==h for m,h in pins.items());row['inputs_unchanged']=all(sha(p)==h for p,h in inputs.items());row['source_unchanged']=sha(src)==row['source_sha256']
log=(out/'compiler.log').read_text();row['log_sha256']=sha(out/'compiler.log');row['warnings']=log.count('warning:')
reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",log);row['axiom_reports']=reports
if ok:
 row['object_sha256']=sha(obj);assert len(reports)==4
 assert all({s.strip()for s in ax.split(',')if s.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports)
assert row['basis_unchanged']and row['inputs_unchanged']and row['source_unchanged']
(out/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items()if k not in ('basis_objects','inputs')},indent=2));print(log);raise SystemExit(0 if ok else 1)
