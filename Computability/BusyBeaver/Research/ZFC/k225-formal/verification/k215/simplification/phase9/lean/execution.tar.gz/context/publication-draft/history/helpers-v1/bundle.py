"""Collect only a terminal, independently reviewed phase9 run. No proof execution.

This file writes only a fresh publication directory. It does not change the run,
proof inputs, prior archives, raw records, or any compiler object.
"""
from pathlib import Path, PurePosixPath
import argparse
import fcntl
import gzip
import io
import json
import tarfile
import basis_reference
from evidence import binary_name, digest, dump, manifest, safe_name, save, sha, validate

HERE=Path(__file__).resolve().parent
HELPERS=('basis_reference.py','basis-reference.json','evidence.py','bundle.py','review_saved.py',
         'README.md','config.json','context.json')


def regular(path):
    path=Path(path)
    assert path.is_file() and not path.is_symlink(),path
    assert not any(p.is_symlink() for p in path.parents),path
    assert not binary_name(path),path
    return path.read_bytes()


def collect(config, terminal_review, basis_repo):
    run=Path(config['run']);result=json.loads(regular(run/'result.json'))
    assert result['status']=='PASS'
    assert result['runner_sha256']==config['driver_sha256']
    assert result['map_sha256']==config['map_sha256']
    members={};paths={}
    prior,_,_=basis_reference.validate(basis_repo)
    by_hash={}
    for name,data in prior.items():by_hash.setdefault(digest(data),name)
    def add(name,path,expected=None,allow_reference=False):
        safe_name(name);path=str(path);data=regular(path);pin=digest(data)
        if expected is not None:assert pin==expected,path
        if path in paths:
            old=paths[path];assert old['sha256']==pin and old['bytes']==len(data)
            # A forced current snapshot must still be retained under its explicit name.
            if not allow_reference:
                assert name not in members or members[name]==data
                members[name]=data
            return data
        if allow_reference and pin in by_hash:
            key=by_hash[pin];assert prior[key]==data
            paths[path]={'storage':'phase8','member':key,'sha256':pin,'bytes':len(data)}
        else:
            assert name not in members or members[name]==data
            members[name]=data;paths[path]={'storage':'packet','member':name,'sha256':pin,'bytes':len(data)}
        return data
    for name in ('result.json','before.json','inventory.json','completed.json','toolchain.json'):
        add('execution/'+name,run/name)
    before=json.loads(members['execution/before.json']);inventory=json.loads(members['execution/inventory.json'])
    done=json.loads(members['execution/completed.json'])
    add('execution/build.py',config['driver'],config['driver_sha256'])
    add('execution/map.json',config['map'],config['map_sha256'])
    for name in HELPERS:add('review/'+name,HERE/name)
    context=json.loads(members['review/context.json'])
    for row in context['files']:
        assert row['member'].startswith('context/')
        data=add(row['member'],row['path'],row['sha256'])
        assert len(data)==row['bytes']
    add('review/terminal-review.json',terminal_review)
    terminal=json.loads(members['review/terminal-review.json'])
    assert terminal['status']=='PASS_INDEPENDENT_197_TRANSITIVE_SOURCE_CLOSED_REVIEW'
    for i,(path,pin) in enumerate(sorted(terminal['pins'].items())):
        add('review/terminal-pins/'+str(i).zfill(3)+'-'+Path(path).name,path,pin,True)
    add('history/full-run1-qualification.json',config['qualification'],config['qualification_sha256'])
    oldrun=Path(config['rejected_run'])
    for name in ('before.json','result.json','inventory.json','completed.json','toolchain.json'):
        add('history/full-run1/'+name,oldrun/name)
    # Preserve raw failed/qualified attempts without interpreting their errors as accepted proof results.
    for label,root in [('full-run1',oldrun),('full-run2',run)]:
        for directory in [root/'attempts',*sorted(root.glob('audit-*'))]:
            if not directory.exists():continue
            assert directory.is_dir() and not directory.is_symlink()
            for path in sorted(directory.rglob('*')):
                assert not path.is_symlink(),path
                if path.is_file() and not binary_name(path):
                    add(('execution/' if label=='full-run2' else 'history/full-run1/')+path.relative_to(root).as_posix(),path)
        stdout=Path(str(root)+'.stdout')
        if stdout.exists():add('history/'+label+'.stdout',stdout)
    for entry in inventory['modules']:
        module=entry['module'];rel=module.replace('.','/')+'.lean';rec=done[module]
        data=add('execution/sources/'+rel,run/'workspace'/rel,entry['source_sha256'])
        assert regular(entry['source'])==data
        paths[entry['source']]={'storage':'packet','member':'execution/sources/'+rel,
                               'sha256':digest(data),'bytes':len(data)}
        add('execution/logs/'+module+'.log',rec['log'],rec['log_sha256'],True)
        if rec['origin']=='isolated_checked':
            prior_done=json.loads(prior['execution/completed.json'])
            without_origin=lambda r:{k:v for k,v in r.items()if k!='origin'}
            inherited=module in prior_done and without_origin(rec)==without_origin(prior_done[module])
            if not inherited:
                log=Path(rec['log'])
                record=log.parent/'record.json' if log.name=='compiler.log' else log.with_suffix('.json')
                add('isolated/provider-records/'+module+'.json',record)
                add('isolated/provider-sources/'+module+'.lean',rec['source'],rec['source_sha256'],True)
    plan=json.loads(members['execution/map.json']);isodir=Path(plan['reuse_ledger']['directory'])
    for name in ('result.json','before.json','inventory.json','completed.json','toolchain.json'):
        add('isolated/'+name,isodir/name,plan['reuse_ledger'].get(name))
    for rec in result['audits']:
        folder=run/('audit-'+rec['module'])
        add('execution/audit-'+rec['module']+'/'+rec['module']+'.lean',folder/(rec['module']+'.lean'),rec['source_sha256'])
        src=regular(rec['source']);assert digest(src)==rec['source_sha256']
        paths[rec['source']]={'storage':'packet','member':'execution/audit-'+rec['module']+'/'+rec['module']+'.lean',
                             'sha256':digest(src),'bytes':len(src)}
    # Fingerprints of compiler objects stay in original JSON only. Every other pinned
    # input is either a local saved byte string or an immutable phase8 member.
    for i,(path,pin) in enumerate(sorted(before['inputs'].items())):
        if binary_name(path) or path in (json.loads(members['execution/toolchain.json'])[k]['path']for k in ('lean','lake')):
            continue
        add('inputs/'+str(i).zfill(4)+'-'+Path(path).name,path,pin,True)
    members['path-map.json']=dump(paths)
    return members


def live_postcheck(run):
    """Rehash all current objects, source snapshots/logs, audits and original inputs."""
    run=Path(run);before=json.loads((run/'before.json').read_text())
    result=json.loads((run/'result.json').read_text());done=json.loads((run/'completed.json').read_text())
    rows=json.loads((run/'inventory.json').read_text())['modules']
    for path,pin in before['inputs'].items():assert sha(path)==pin,path
    for row in rows:
        m=row['module'];rec=done[m];rel=m.replace('.','/')
        assert sha(row['source'])==sha(run/'workspace'/(rel+'.lean'))==rec['source_sha256']==row['source_sha256']
        assert sha(run/'objects'/(rel+'.olean'))==rec['object_sha256']
        assert sha(rec['log'])==rec['log_sha256']
        assert rec['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
    for rec in result['audits']:
        folder=run/('audit-'+rec['module'])
        assert sha(folder/(rec['module']+'.olean'))==rec['object_sha256']
        assert sha(folder/(rec['module']+'.lean'))==sha(rec['source'])==rec['source_sha256']
        assert sha(rec['log'])==rec['log_sha256']
    return {'status':'PASS_COLLECTOR_POSTCHECK','modules':len(rows),'typed_clients':len(result['audits']),
            'all_current_objects_rehashed_after_audits':True,'all_before_inputs_unchanged':True,
            'result_sha256':sha(run/'result.json'),'collector_sha256':sha(__file__)}


def write_archive(path,members):
    with Path(path).open('xb') as out:
        with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for name,data in sorted(members.items()):
                    safe_name(name);entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0
                    archive.addfile(entry,io.BytesIO(data))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--basis-repo',type=Path,required=True)
    parser.add_argument('--terminal-review',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();config=json.loads((HERE/'config.json').read_text());run=Path(config['run'])
    # Holding the run's existing lock proves its compiler driver has finished.
    with (run/'output.lock').open('rb') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        assert not args.output.exists(), 'Use a new output directory'
        live_postcheck(run)
        members=collect(config,args.terminal_review,args.basis_repo)
        checked=validate(members,args.basis_repo)
        post=live_postcheck(run);members['review/collector-postcheck.json']=dump(post)
        args.output.mkdir(parents=True)
        write_archive(args.output/'execution.tar.gz',members)
        save(args.output/'index.json',manifest(members))
        for name in ('basis_reference.py','basis-reference.json','evidence.py','review_saved.py'):
            (args.output/name).write_bytes((HERE/name).read_bytes())
        (args.output/'README.md').write_bytes((HERE/'README.md').read_bytes())
        summary={**checked,'archive_sha256':sha(args.output/'execution.tar.gz'),
                 'archive_members':len(members),'index_sha256':sha(args.output/'index.json'),
                 'collector_postcheck':post,'status':'PASS_COLLECTED_PHASE9_EVIDENCE'}
        save(args.output/'result.json',summary)
        print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
