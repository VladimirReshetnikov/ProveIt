"""Own data-only overlay inventory. Never imports or executes candidate code."""
from pathlib import Path
import hashlib,json,re
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent
B=Path('/tmp/k215-phase14-check/primary-run2');C=Path('/tmp/k215-phase14-check/compatibility-run1')
ROOTS=['Computability/BusyBeaver/Lean','Logic/FirstOrder/Lean','SetTheory/ZF/Lean','SetTheory/BoundedConsistency/Lean']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def strip(text):
 out=[];i=depth=0
 while i<len(text):
  if text[i:i+2]=='/-':depth+=1;i+=2
  elif depth and text[i:i+2]=='-/':depth-=1;i+=2
  elif depth:
   if text[i]=='\n':out.append('\n')
   i+=1
  elif text[i:i+2]=='--':
   j=text.find('\n',i);i=len(text)if j<0 else j
  elif text[i]=='"':
   i+=1
   while i<len(text):
    if text[i]=='\\':i+=2
    elif text[i]=='"':i+=1;break
    else:i+=1
  else:out.append(text[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(p):return[w for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',strip(Path(p).read_text()))for w in line.split()]
def project_path(m):
 paths=[R/root/(m.replace('.','/')+'.lean')for root in ROOTS if(R/root/(m.replace('.','/')+'.lean')).is_file()]
 assert len(paths)==1,(m,paths);return paths[0]
def census(out,sources,clients):
 assert not out.exists();out.mkdir()
 old={};records={};providers={}
 pins={B:'3454f69d71477171f20d91733093821fa3198253dece63802c59d045bf3991df',C:'008d6626c9c2b11400713bda9dff89aa5385f276d0898f13c1f0dd19cda857b1'}
 for d,count in [(C,70),(B,190)]:
  assert sha(d/'result.json')==pins[d];res=read(d/'result.json');inv=read(d/'inventory.json');done=read(d/'completed.json')
  assert res['status']=='PASS' and sha(d/'inventory.json')==res['inventory_sha256'] and sha(d/'completed.json')==res['completed_sha256'] and len(inv['modules'])==len(done)==count
  for r in inv['modules']:
   m=r['module'];rec=done[m];assert rec['source_sha256']==r['source_sha256']
   if m in old:assert(r['source_sha256'],r['imports'],rec['object_sha256'])==(old[m]['source_sha256'],old[m]['imports'],records[m]['object_sha256'])
   old[m]=r;records[m]=rec;providers[m]=str(d)
 assert len(old)==207
 old_api=['GenericShared13Api','NumericCD52Api','LukasShared13Api','DerivedRows14Api','ThmKDerived14Api','KEindDerived14Api','ProfileTC14Api'];compat=['WFModelCompat12','ZFNativeCompat12']
 assert len(set(old)-set(old_api+compat))==198
 for m,r in old.items():
  if m not in old_api+compat:
   p=project_path(m);assert sha(p)==r['source_sha256']and imports(p)==r['imports']
 overrides={}
 for r in sources:
  m=r['module'];p=Path(r['source']);assert m not in overrides and sha(p)==r['source_sha256'] and imports(p)==r['imports']
  assert r['before_sha256']==(old[m]['source_sha256'] if m in old else None)
  overrides[m]=r
 assert set(overrides)=={'BusyBeaver.ZFC.'+n for n in ['InternalRank','TransRec','QuotientModel','KQ1Model','PowerSets','PSCCalibration','WFModelCore','KDenseBridge']}
 for m in old_api+compat:
  r=old[m];rec=records[m];p=Path(r['source']);assert sha(p)==r['source_sha256']
  reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",Path(rec['log']).read_text())
  overrides[m]={**r,'before_sha256':r['source_sha256'],'reports':[n for n,_ in reports],'report_axioms':[sorted({x.strip()for x in ax.split(',')if x.strip()})for _,ax in reports]}
 assert sum(len(overrides[m]['reports'])for m in old_api)==34
 assert sum(len(overrides[m]['reports'])for m in compat)==10
 for r in clients:
  p=Path(r['source']);m=r['module'];assert m not in old and m not in overrides and sha(p)==r['source_sha256'] and imports(p)==r['imports'];overrides[m]={**r,'before_sha256':None}
 def inventory(targets):
  seen=set();active=set();rows=[];closures={}
  def visit(m):
   if m=='Init':return set()
   assert m!='BusyBeaver.ZFC.KProfileTC'
   if m in seen:return closures[m]
   assert m not in active,m
   if m in overrides:r=overrides[m]
   else:
    assert m in old;m_path=project_path(m);r={'module':m,'source':str(m_path),'source_sha256':sha(m_path),'imports':imports(m_path)}
    assert(r['source_sha256'],r['imports'])==(old[m]['source_sha256'],old[m]['imports'])
   active.add(m);sub={m}
   for d in r['imports']:sub|=visit(d)
   active.remove(m);seen.add(m);closures[m]=sub;rows.append({k:r[k]for k in ['module','source','source_sha256','imports']});return sub
  for t in targets:visit(t)
  changed={r['module']for r in rows if r['module']not in old or(r['source_sha256'],r['imports'])!=(old[r['module']]['source_sha256'],old[r['module']]['imports'])}
  return {'targets':targets,'modules':rows,'changed':sorted(changed),'forced':sorted(m for m in seen if closures[m]&changed),'external_imports':['Init']}
 prefix=['BusyBeaver.ZFC.KEndpoint215','BusyBeaver.ZFC.KDecoderPrefix215'];new=[r['module']for r in clients]
 sets={name:inventory(targets)for name,targets in [('endpoint',prefix[:1]),('project',prefix),('primary',prefix+old_api+new),('compatibility',compat)]}
 for name,data in sets.items():save(out/(name+'-inventory.json'),data)
 p={r['module']for r in sets['primary']['modules']};c={r['module']for r in sets['compatibility']['modules']};forced=set(sets['compatibility']['forced']);ep={r['module']for r in sets['endpoint']['modules']};proj={r['module']for r in sets['project']['modules']}
 summary={'status':'PROSPECTIVE_SOURCE_ONLY','endpoint_modules':len(ep),'primary_prefix_project_modules':len(proj),'primary_project_modules':len(p-set(old_api+new)),'primary_providers':len(p),'primary_fresh':len(sets['primary']['forced']),'primary_reuse':len(p)-len(sets['primary']['forced']),'old_api_clients':old_api,'new_api_clients':new,'compatibility_providers':len(c),'compatibility_project_modules':len(c)-2,'compatibility_primary_reuse':sorted(c&p),'compatibility_fresh':sorted(forced-p),'compatibility_old_reuse':sorted(c-p-forced),'combined_project_modules':len((p|c)-set(old_api+new+compat)),'all_nine_sites_unchanged':len([m for m in p if'KSites215Batch'in m])==9 and not any('KSites215Batch'in m for m in sets['primary']['forced']),'endpoint_source_bytes':sum(Path(r['source']).stat().st_size for r in sets['endpoint']['modules']),'old_endpoint_source_bytes':2093112,'baseline_union':198}
 summary['primary_reuse_by_basis']={str(d):len([m for m in p-set(sets['primary']['forced']) if providers[m]==str(d)])for d in [B,C]}
 save(out/'census.json',summary);save(out/'candidate-map.json',{'modules':list(overrides.values())});save(out/'baseline-providers.json',providers);print(json.dumps(summary,indent=2))
if __name__=='__main__':census(S/'plan1',read(S/'sources.json'),read(S/'clients.json'))
