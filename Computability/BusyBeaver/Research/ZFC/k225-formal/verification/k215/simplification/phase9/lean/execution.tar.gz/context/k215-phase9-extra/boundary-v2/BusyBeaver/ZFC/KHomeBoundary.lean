import BusyBeaver.ZFC.KZipTape
import BusyBeaver.ZFC.KFast215
import BusyBeaver.ZFC.KHome

/-! Source-only candidate. The 18-step home boundary uses the actual 215 table,
framed window restoration, and exact normalized zipper reflection. No compiler
has been invoked on this candidate. The input right-hand frame is arbitrary. -/
namespace SetTheory.BusyBeaver.ZFC.KHomeBoundary
open KZip KTableCore KBoot KBoot215

private def cells : FramedWindow.Cells :=
  [(1, true), (0, false), (-1, false), (-2, false), (-3, false),
   (-4, false), (-5, false), (-6, false), (-7, false), (-8, false)]

private theorem overlay_eq (xs : FramedWindow.Cells) (t : FramedWindow.Tape)
    (h : ∀ p ∈ xs, t p.1 = p.2) : FramedWindow.overlay xs t = t := by
  funext i
  induction xs with
  | nil => rfl
  | cons p xs ih =>
    by_cases hi : i = p.1
    · subst i
      simpa [FramedWindow.overlay, FramedWindow.lookup] using (h p (by simp)).symm
    · have ht := ih (fun p hp => h p (by simp [hp]))
      simpa only [FramedWindow.overlay, FramedWindow.lookup, if_neg hi] using ht

theorem rows : KHome.Rows tm215 := by
  constructor
  · intro i hi
    have h : i = 0 ∨ i = 1 ∨ i = 2 ∨ i = 3 ∨ i = 4 ∨ i = 5 ∨ i = 6 ∨ i = 7 := by omega
    rcases h with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> decide
  · intro i hi
    have h : i = 0 ∨ i = 1 ∨ i = 2 ∨ i = 3 ∨ i = 4 ∨ i = 5 ∨ i = 6 := by omega
    rcases h with rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> decide

private theorem check_boundary :
    FramedWindow.check (KZipTape.table tm215) 18 2 0 cells 84 2 = true := by
  have hf : fastOf tt215 = tm215 := funext fun q => funext fun b => fast215 q b
  rw [← hf]
  decide

/-- The blank-left boundary takes exactly 18 steps and restores the whole tape. -/
theorem boundary_run (R : List Bool) :
    KZip.run tm215 18 (zl 2 [] (true :: R)) = some (zc 84 [true] R) := by
  let s := zc 2 [] (false :: true :: R)
  have hm : FramedWindow.overlay cells (KZipTape.tape s) = KZipTape.tape s := by
    apply overlay_eq
    intro p hp
    simp only [cells, List.mem_cons, List.not_mem_nil, or_false] at hp
    rcases hp with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
      simp [KZipTape.tape, s, zc, trim_cons]
  have hs := FramedWindow.arbitrary_tape (KZipTape.table tm215) 18 2 0 cells 84 2
    check_boundary (KZipTape.tape s) hm
  have he : KZipTape.Rel ⟨84, 2, KZipTape.tape s⟩ (zc 84 [true] R) := by
    simpa [KZipTape.full, s, zc, trim_cons, trim_trim] using
      KZipTape.rel_right (KZipTape.rel_right (KZipTape.rel_full s) 2) 84
  have hr := KZipTape.run_reflect (KZipTape.rel_full s) he
    (by exact ⟨trim_trim _, trim_trim _⟩) ⟨trim_trim _, trim_trim _⟩ hs
  simpa [s, zl] using hr

theorem boundary (R : List Bool) :
    Reach1 tm215 (zl 2 [] (true :: R)) (zc 84 [true] R) :=
  ⟨17, boundary_run R⟩

theorem home_sound (n : Nat) (vs : List Nat) {s t : KRuntimeCore.SConf}
    (h : KHome.home s = some t) :
    Reach1 tm215 (KRuntimeCore.conc n vs s) (KRuntimeCore.conc n vs t) :=
  KHome.home_sound rows boundary n vs h

#print axioms boundary
#print axioms home_sound
end SetTheory.BusyBeaver.ZFC.KHomeBoundary
