"""Extracted prospective evidence guards only; no runner, compiler, or actual evidence."""
from pathlib import Path
import ast,hashlib,json
P=Path('/tmp/k215-phase5-legacy');O=Path(__file__).resolve().parent
src=(P/'evidence.py').read_text();tree=ast.parse(src)
def text(n):return ast.unparse(n)
checks=[]
# Exact current suffix-only report gate accepts unrelated namespaces.
gate=next(n for n in ast.walk(tree) if isinstance(n,ast.Assert) and text(n.test).startswith('len(reports) == 5 and'))
reports=[('Unrelated.'+n,'')for n in ('root222','root219','rootDom','rootPerm','offset_checker')]
exec(compile(ast.Module(body=[gate],type_ignores=[]),str(P/'evidence.py'),'exec'),{'reports':reports,'CLIENTS':('root222','root219','rootDom','rootPerm','offset_checker')})
checks.append({'control':'five wrong namespaces','observation':'ACCEPTED_BY_CURRENT_EXTRACTED_SUFFIX_GATE'})
# Deriving the cache from the claimed output permits any normalized output root.
nodes=[]
for n in ast.walk(tree):
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('cache','expected') for t in n.targets):
  if isinstance(n.targets[0],ast.Name) and n.targets[0].id=='cache' and "rec['command']" not in text(n):continue
  if isinstance(n.targets[0],ast.Name) and n.targets[0].id=='expected' and "source_root" not in text(n):continue
  nodes.append(n)
assert len(nodes)==2
nodes.append(next(n for n in ast.walk(tree) if isinstance(n,ast.Assert) and text(n.test)=="rec['command'] == expected"))
source='/repo/Lean/BusyBeaver/ZFC/Test.lean';command=['lean','-j1','-M12288','--root=/repo/Lean','-o','/tmp/unrelated/objects/BusyBeaver/ZFC/Test.olean',source]
env={'Path':Path,'mod':'BusyBeaver.ZFC.Test','rec':{'command':command},'r':{'source':source},'source_root':'/repo/Lean','tool':{'lean':{'path':'lean'}}}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(P/'evidence.py'),'exec'),env)
checks.append({'control':'unrelated output cache','observation':'ACCEPTED_BY_CURRENT_EXTRACTED_ARGV_GATE'})
record={'scope':'Two exact extracted guards on synthetic records. No actual run/driver/compiler invocation. These demonstrate prospective publication binding gaps only.','source_sha256':hashlib.sha256(src.encode()).hexdigest(),'checks':checks}
(O/'controls-v1.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
