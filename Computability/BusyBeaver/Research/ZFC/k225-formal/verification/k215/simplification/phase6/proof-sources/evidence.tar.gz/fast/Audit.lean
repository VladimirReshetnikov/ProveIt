import BusyBeaver.ZFC.KFastSites215
import BusyBeaver.ZFC.KSource215
import BusyBeaver.ZFC.KEndpoint215

namespace K215MigrationAudit
open SetTheory.BusyBeaver.ZFC

example : KBoot.fastOf KBoot215.tt215 = KTableCore.tm215 := KFastSites215.fast_eq
example (q : Nat) (b : Bool) :
    KBoot.fastOf KBoot215.tt215 q b = KTableCore.tm215 q b := KBoot215.fast215 q b
example {P : List Bool} {t : RMBisim.Tree}
    (h : SiteCoverage.allSites (KSim.checkEdge (KBoot.fastOf KBoot215.tt215)) P t = true) :
    SiteCoverage.allSites (KSim.checkEdge KTableCore.tm215) P t = true :=
  KFastSites215.allSites_of_fast h
example (R : RegisterPath.Registers) :
    RegisterPath.Halts KSource215.p215 ⟨[], R⟩ ↔
      RegisterPath.Halts KSource215.pathDagPerm ⟨[], R⟩ := KSource215.p215_halts_iff R
example (n : Nat) : KSource215.decode215 n = RMBisim.decodeAux 512 n [] := rfl
example (n : Nat) : RMBisim.decode n = RMBisim.decodeAux 128 n [] := rfl

#print axioms KFastSites215.fast_eq
#print axioms KFastSites215.allSites_of_fast
#print axioms KSource215.p215_halts_iff
#print axioms KEndpoint215.blank_halts_iff_zfc_refutation
#print axioms KEndpoint215.nonhalting_iff_zfc_consistency
end K215MigrationAudit
