"""Audit completed legacy outputs read-only; does not launch proof tools."""
from pathlib import Path
import argparse,json
from evidence import live_check,save
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);p.add_argument('--basis',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 assert not a.output.exists();_,r=live_check(a.run.resolve(),a.basis.resolve(),Path(__file__).resolve().parent);save(a.output,r);print(json.dumps({k:v for k,v in r.items()if k!='evidence_manifest'},indent=2))
