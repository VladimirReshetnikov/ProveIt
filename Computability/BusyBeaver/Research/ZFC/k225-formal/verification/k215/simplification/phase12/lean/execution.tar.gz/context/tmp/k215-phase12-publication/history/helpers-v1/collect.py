"""Collect completed phase12 evidence without compiler or producer execution."""
from pathlib import Path
from contextlib import ExitStack
import argparse,fcntl,gzip,io,json,tarfile
import basis,packet
S=Path(__file__).resolve().parent;R=Path(packet.ROOT)
read=lambda p:json.loads(Path(p).read_text())
def collect(repo,out):
 assert not out.exists()and not out.is_symlink()
 with ExitStack()as stack:
  for root in [packet.MAIN,packet.COMP]:
   lock=stack.enter_context((Path(root)/'output.lock').open('a'));fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  loaded=basis.load(repo);prior,_,_=loaded;members={};routes={};hashes={}
  for key,data in prior.items():hashes.setdefault(packet.digest(data),('phase11',key))
  def put(name,data):
   packet.safe(name)
   if name in members:assert members[name]==data
   members[name]=data;hashes.setdefault(packet.digest(data),('packet',name))
  def add(path,data=None,name=None,force=False):
   path=str(path);data=Path(path).read_bytes()if data is None else data;pin=packet.digest(data)
   if path in routes:assert routes[path]['sha256']==pin;return
   if force or pin not in hashes:
    key=name or'inputs/'+pin+'/'+Path(path).name;put(key,data);storage='packet'
   else:storage,key=hashes[pin]
   routes[path]={'storage':storage,'key':key,'sha256':pin,'bytes':len(data)}
  historical=R/packet.PRODUCER;snapshot=S/'inputs/generate_l2k222.before.py'
  assert packet.sha(snapshot)==packet.OLD_PRODUCER;add(historical,snapshot.read_bytes());add(snapshot)
  tool=read(Path(packet.MAIN)/'toolchain.json');binary={v['path']:v['sha256']for k,v in tool.items()if k in{'lean','lake','Init.olean'}}
  for root in [packet.OLD,packet.BASE,packet.MAIN,packet.COMP]:
   for m,rec in read(Path(root)/'completed.json').items():binary[root+'/objects/'+m.replace('.','/')+'.olean']=rec['object_sha256']
  for root,label in [(Path(packet.MAIN),'execution'),(Path(packet.COMP),'compatibility')]:
   result=read(root/'result.json');assert result['status']=='PASS'
   for name in ['result.json','before.json','inventory.json','completed.json','toolchain.json']:add(root/name,name=label+'/'+name,force=True)
   inv=read(root/'inventory.json');done=read(root/'completed.json');before=read(root/'before.json')
   for p,pin in before['inputs'].items():
    if p in binary:assert binary[p]==pin;continue
    if p!=str(historical):add(p)
    assert routes[p]['sha256']==pin,p
   for row in inv['modules']:
    m=row['module'];rec=done[m];add(row['source']);add(rec['log'])
    if rec['origin']=='candidate_fresh':
     add(rec['source'],name=label+'/fresh/'+m+'/source.lean',force=True)
     add(Path(rec['log']).parent/'record.json',name=label+'/fresh/'+m+'/record.json',force=True)
     add(Path(rec['log']).parent/Path(rec['source']).name)
   for audit in result['audits']:
    q=root/('audit-'+audit['module'])
    for name in [audit['module']+'.lean',audit['module']+'.log',audit['module']+'.json']:add(q/name,name=label+'/audits/'+name,force=True)
    add(audit['source'])
  context=read(S/'context.json')
  for p,row in context['files'].items():
   assert Path(p).is_file()and not Path(p).is_symlink();data=Path(p).read_bytes();assert packet.digest(data)==row['sha256']and len(data)==row['bytes'];add(p,data,name='context/'+p.lstrip('/'))
  adoption=read(Path(packet.PROPOSAL)/'adoption.json')
  for row in adoption['files']:
   data=Path(row['source']).read_bytes();assert packet.digest(data)==row['sha256']and data==(R/row['target']).read_bytes();add(row['source'],data);put('adoption/'+row['target'],data)
   if row['archived_before']is not None:add(row['archived_before'])
  for name in ['basis.py','basis-reference.json','packet.py','review_saved.py','collect.py','README.md','context.json','controls.py','controls-result.json','controls.stdout.log','controls.stderr.log','freeze.json']:put('review/'+name,(S/name).read_bytes())
  put('path-map.json',packet.dump(routes));checked=packet.validate(members,repo,loaded,current_repo=repo)
  # Recheck actual objects only in this live collection; saved reviewers claim recorded hashes only.
  for root in [Path(packet.MAIN),Path(packet.COMP)]:
   before=read(root/'before.json');done=read(root/'completed.json');inv=read(root/'inventory.json')
   for p,pin in before['inputs'].items():assert packet.sha(snapshot if p==str(historical)else p)==pin,p
   for p in before['absent_inputs']:packet.absent(p)
   for row in inv['modules']:
    rec=done[row['module']];assert packet.sha(row['source'])==row['source_sha256'];assert packet.sha(rec['log'])==rec['log_sha256'];obj=root/'objects'/(row['module'].replace('.','/')+'.olean');assert packet.sha(obj)==rec['object_sha256']
    if rec['origin']=='candidate_fresh':assert not obj.is_symlink()and packet.sha(rec['source'])==row['source_sha256']
    else:assert obj.is_symlink()
   for rec in read(root/'result.json')['audits']:
    q=root/('audit-'+rec['module']);assert packet.sha(q/(rec['module']+'.olean'))==rec['object_sha256'];assert packet.sha(q/(rec['module']+'.lean'))==rec['source_sha256'];assert packet.sha(rec['log'])==rec['log_sha256']
  assert packet.sha(historical)==packet.NEW_PRODUCER
  post={'status':'PASS_LIVE_POSTCHECK','primary_providers':184,'compatibility_providers':69,'combined_project_sources':199,'endpoint_audit_objects':2,'all_live_sources_objects_logs_rehashed':True,'all_before_inputs_rehashed_except_one_explicit_historical_producer':True,'historical_producer':str(historical),'historical_sha256':packet.OLD_PRODUCER,'current_producer_sha256':packet.NEW_PRODUCER,'current_writes':8,'current_absent_templates':2,'scope':'The one adopted L2 producer is read from exact prior bytes for raw before.inputs. All other run inputs and objects are rehashed live; current seven Lean files and new producer are checked separately.'}
  put('review/live-postcheck.json',packet.dump(post));index=packet.manifest(members);out.mkdir(parents=True)
  with(out/'execution.tar.gz').open('wb')as raw:
   with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as zipped:
    with tarfile.open(fileobj=zipped,mode='w')as archive:
     for name,data in sorted(members.items()):
      info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
  (out/'index.json').write_bytes(packet.dump(index))
  summary={**checked,'status':'PASS_COLLECTED_PHASE12','archive_sha256':packet.sha(out/'execution.tar.gz'),'archive_members':len(members),'index_sha256':packet.sha(out/'index.json'),'live_postcheck':post}
  (out/'result.json').write_bytes(packet.dump(summary))
  for name in ['basis.py','basis-reference.json','packet.py','review_saved.py','README.md']:(out/name).write_bytes((S/name).read_bytes())
  print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--basis-repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();collect(a.basis_repo,a.out)
