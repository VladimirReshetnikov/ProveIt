"""Independent read-only live review after root-observed terminal legacy success."""
from pathlib import Path
import argparse,json
from capture import args,collect
from evidence import sha,digest,read,save,validate,manifest_hash

def review(run,prep,repo,stdout):
 run,prep,repo=run.resolve(),prep.resolve(),repo.resolve();m=collect(run,prep,repo,stdout);checked=validate(m,repo,repo)
 done=read(run/'completed.json');inv=read(run/'inventory.json');providers=read(run/'providers.json');before=read(run/'before.json');cache=run/'objects'
 assert not cache.is_symlink()
 assert {p.relative_to(cache).as_posix()for p in cache.rglob('*')if p.is_file()}=={mod.replace('.','/')+'.olean'for mod in done}
 for p in cache.rglob('*'):assert not(p.is_dir()and p.is_symlink())
 objects={};logs={};sources={}
 for row in inv['modules']:
  mod=row['module'];rec=done[mod];obj=cache/(mod.replace('.','/')+'.olean');provider=Path(providers[mod])
  assert obj.is_symlink()and obj.resolve(strict=True)==provider.resolve(strict=True)
  assert sha(obj)==sha(provider)==rec['object_sha256'];objects[str(obj)]=rec['object_sha256'];objects[str(provider)]=rec['object_sha256']
  assert sha(rec['log'])==rec['log_sha256'];logs[rec['log']]=rec['log_sha256']
  assert sha(row['source'])==row['source_sha256'];sources[row['source']]=row['source_sha256']
 audit=read(run/'audit/record.json');assert sha(run/'audit/LegacyAudit.olean')==audit['object_sha256']
 tool=read(run/'toolchain.json')
 for key in ['lean','lake','Init.olean','project_toolchain']:assert sha(tool[key]['path'])==tool[key]['sha256']
 for pins in [before,objects,logs,sources]:
  for path,h in pins.items():assert sha(path)==h,path
 assert collect(run,prep,repo,stdout)==m
 return {**checked,'status':'PASS_LIVE_LEGACY_POST_AUDIT_REVIEW','result_sha256':sha(run/'result.json'),'all203_selected_objects_and_logs_rehashed_after_audit':True,'all_immutable_predecessor_inputs_unchanged':True,'fresh_audit_object_rehashed':True,'current203_sources_and_imports_checked':True,'toolchain_rehashed':True,'evidence_manifest_sha256':manifest_hash(m),'reviewer_sha256':sha(__file__),'validator_sha256':sha(Path(__file__).with_name('evidence.py')),'capture_sha256':sha(Path(__file__).with_name('capture.py'))}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);args(p);p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists();r=review(a.run,a.preparation,a.repo,a.stdout);save(a.output,r);print(json.dumps(r,indent=2))
