from pathlib import Path
import hashlib, importlib.util, json, os, sys
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs')
out=Path('/tmp/k215-proof-simplification/root')
spec=importlib.util.spec_from_file_location('driver', repo/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
sha=driver.sha
inv=driver.inventory(repo)
done=json.loads((out/'completed.json').read_text())
cache=out/'objects'
modules={e['module']:e for e in inv['modules']}
for m,e in modules.items():
 r=done[m];obj=cache/(m.replace('.','/')+'.olean')
 assert r['source_sha256']==sha(e['source']),('source',m)
 assert r['object_sha256']==sha(obj),('object',m)
 assert r['dependencies']=={d:done[d]['object_sha256']for d in e['imports']if d in modules},('dependencies',m)
assert inv['external_imports']==['Init']
run=out/f'audit-{1+len(list(out.glob("audit-*"))):03d}';run.mkdir()
(run/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
compiled=[]
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
for folder,name,expected in [('independent','EndpointAudit215',2),('axiom-components','K215Audit',8)]:
 source=repo/f'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/actual/audit/{folder}/{name}.lean'
 target=run/f'{name}.lean';target.write_bytes(source.read_bytes())
 row={'module':name,'source_sha256':sha(target),'project_modules':len(inv['modules']),'inventory_sha256':sha(run/'inventory.json'),'scope':'Incremental recompilation of changed closure against the previously checked baseline.'}
 cmd=['/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean','-j1','-M12288','--root='+str(run),'-o',str(run/(name+'.olean')),str(target)]
 row['command']=cmd
 ok=driver.run_locked(cmd,repo,env,Path('/tmp/proveit-k215-proof-build.lock'),run/f'{name}.log',120,row,run/f'{name}.json')
 text=(run/f'{name}.log').read_text()
 print(name,row['status'],text,flush=True)
 assert ok and 'warning:'not in text and 'error:'not in text
 reports=driver.re.findall(r'depends on axioms: \[([^]]*)\]',text)
 assert len(reports)+text.count('does not depend on any axioms')==expected
 for axioms in reports:assert set(x.strip()for x in axioms.split(','))<={'propext','Classical.choice','Quot.sound'}
 compiled.append(row)
summary={'status':'PASS','project_modules':len(inv['modules']),'typed_audits':2,'scope':'Incremental; unchanged baseline dependencies reused after checking current source and direct dependency object hashes.','audits':compiled}
(run/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS',run,flush=True)
