from pathlib import Path
import difflib,hashlib,json
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs')
p=repo/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/KRuntimeCore.lean'
s=p.read_text()
a=s.index('def exec (M : TMN)');b=s.index('\n/-! ## Basic facts',a)
old=s[a:b]
new=old.replace('def exec (M : TMN) (br : Branch)', 'def execWith (next : SConf → Option (SConf × Bool))').replace('sstep M br s','next s').replace('exec M br tgt','execWith next tgt')
new+='\n/-- The original symbolic executor, with exactly its original step function. -/\ndef exec (M : TMN) (br : Branch) (tgt : SConf → Bool) :\n    Nat → SConf → Bool → Option SConf := execWith (sstep M br) tgt\n'
s=s[:a]+new+s[b:]
a=s.index('theorem exec_sound {br : Branch}');b=s.index('\nend Sound',a)
oldProof=s[a:b]
newProof=oldProof.replace('theorem exec_sound {br : Branch} {tgt : SConf → Bool} (n : Nat) {vs : List Nat} (hv : Valid br vs) :', '''omit B in
theorem execWith_sound {next : SConf → Option (SConf × Bool)} {tgt : SConf → Bool}
    (n : Nat) (vs : List Nat)
    (hnext : ∀ s t m, next s = some (t, m) → StepOk M n vs s t m) :''')
newProof=newProof.replace('exec M br tgt','execWith next tgt').replace('[exec]','[execWith]').replace('exec_sound n hv f','execWith_sound n vs hnext f').replace('sstep_sound B n hs hv','hnext s s1 m hs')
newProof+='''
/-- The old theorem is an instance of the single generic executor induction. -/
theorem exec_sound {br : Branch} {tgt : SConf → Bool} (n : Nat) {vs : List Nat} (hv : Valid br vs) :
    ∀ (f : Nat) (s : SConf) (m0 : Bool) (s' : SConf), exec M br tgt f s m0 = some s' →
      tgt s' = true ∧ Reach M (conc n vs s) (conc n vs s') ∧
        (m0 = false → Reach1 M (conc n vs s) (conc n vs s')) :=
  execWith_sound n vs (fun _ _ _ h => sstep_sound B n h hv)
'''
s=s[:a]+newProof+s[b:]
out=Path('/tmp/k215-phase9-home/integration/BusyBeaver/ZFC/KRuntimeCore.lean');out.write_text(s)
(out.parents[2]/'KRuntimeCore.diff').write_text(''.join(difflib.unified_diff(p.read_text().splitlines(True),s.splitlines(True),fromfile='current/KRuntimeCore.lean',tofile='candidate/KRuntimeCore.lean')))
print(hashlib.sha256(out.read_bytes()).hexdigest())
