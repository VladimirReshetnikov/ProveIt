"""Prepare the terminal-only phase14 collector; does not invoke it."""
from pathlib import Path
import ast,difflib
S=Path(__file__).resolve().parent;OLD=S/'history/phase13'
def sub(s,a,b):
 assert s.count(a)==1,(a[:120],s.count(a));return s.replace(a,b)
s=(OLD/'collect.py').read_text().replace('phase13','PHASE_CURRENT').replace('phase12','phase13').replace('PHASE_CURRENT','phase14').replace('PHASE13','PHASE14')
s=sub(s,"for row in cfg['adoption']['files']:\n   data = Path(row['source']).read_bytes(); assert packet.digest(data) == row['sha256'] and data == (repo/row['target']).read_bytes()\n   add(row['source'], data); add(row['archived_before']); put('adoption/'+row['target'], data)","""for row in cfg['adoption']['files']:
   add(repo/row['before_snapshot'])
   if row['action'] == 'replace':
    data = Path(row['candidate']).read_bytes()
    assert packet.digest(data) == row['after_sha256'] and data == (repo/row['path']).read_bytes()
    add(row['candidate'], data); put('adoption/'+row['path'], data)
   else:
    assert row['action'] == 'retire'; packet.absent(repo/row['path'])""")
s=sub(s,"# Rehash all actual dependencies after validation. Only two explicit historical\n  # canonical inputs use their immutable before snapshots; current adoption is separate.","# Rehash every actual dependency after validation. The two retired canonical\n  # compilation inputs use their exact before snapshots; current absence is separate.")
s=sub(s,"for row in cfg['adoption']['files']:\n   assert packet.sha(repo/row['target']) == row['sha256'] and packet.sha(row['archived_before']) == row['before_sha256']", """for row in cfg['adoption']['files']:
   assert packet.sha(repo/row['before_snapshot']) == row['before_sha256']
   if row['action'] == 'replace': assert packet.sha(repo/row['path']) == row['after_sha256']
   else: packet.absent(repo/row['path'])
  for path,pin in packet.PRIOR_ADOPTIONS.items(): assert packet.sha(repo/path) == pin
  for root in [Path(packet.MAIN),Path(packet.COMP)]: packet.absent(root/'objects/BusyBeaver/ZFC/KProfileTC.olean')""")
s=s.replace("'combined_project_sources': 199","'combined_project_sources': 198").replace("'current_adoptions': packet.ADOPTIONS, 'absence_gates': 2","'current_adoptions': packet.ADOPTIONS, 'retirements': packet.RETIRED, 'unchanged_prior_adoptions': packet.PRIOR_ADOPTIONS, 'absence_gates': 4")
s=s.replace('Two changed canonical producer/data inputs are checked from explicit immutable before snapshots, separately from their current adopted bytes.','Two retired canonical inputs are checked from explicit immutable before snapshots, separately from their current absence. Seven adopted Lean files and the five unchanged phase13 adoptions are checked exactly.')
ast.parse(s);(S/'collect.py').write_text(s)
(S/'collect.py.diff').write_text(''.join(difflib.unified_diff((OLD/'collect.py').read_text().splitlines(True),s.splitlines(True),fromfile='phase13/collect.py',tofile='phase14/collect.py')))
