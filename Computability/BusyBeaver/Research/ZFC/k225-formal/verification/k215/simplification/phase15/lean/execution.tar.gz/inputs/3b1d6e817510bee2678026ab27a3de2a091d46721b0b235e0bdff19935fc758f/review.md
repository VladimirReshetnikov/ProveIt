# Phase15 basic interfaces — source-only proposal

The four candidates are exact Source192 files. `KDenseBridge` also matches the
immutable `406cb959dd6a` upstream proposal. The checked baseline is commit
`6901b164d9`; `comparison.json` records the exact before/after bytes. No submitted
program, producer, or proof compiler has run in this review.

The PowerSets change moves precisely one definition into a small module importing
`ZF.Zf`. Its full name remains
`SetTheory.BusyBeaver.ZFC.PSCCalibration.PowerSets`, with the same universe, relation
parameter and body. `PSCCalibration` imports it and otherwise stays byte-identical;
`WFModelCore` only replaces its import of the full calibration by `PowerSets`.
All model/calibration declarations and executable definitions are unchanged.
This removes a broad dependency from the selected endpoint without deleting the
calibration theorem. The new typed client imports the full calibration explicitly
so that the old named interface is still checked outside the reduced endpoint.

The dense bridge uses one induction whose disjunction records either both
halting witnesses or a same-time pair of related configurations. In the halted
dense branch, the time itself supplies `BlankHalts`, and `rel_halt` supplies the
reachable zipper halt. In a live branch, `rel_step` preserves the relation and
`run_succ` supplies the exact zipper clock. The forward implication projects the
zipper witness or applies `rel_halt` at the given dense halt. The reverse implication
projects the dense witness or identifies the related zipper state with the given
reachable state via injectivity of `Option.some`; a live dense successor would
contradict the zipper halt. Thus neither direction repeats an induction.

This proof retains the exact generic `blank_iff` statement. It adds no injectivity
assumption on the relabelling, no finiteness hypothesis beyond the existing machine
and zipper types, and no new clock premise. The existing `Commutes` and terminal-row
hypotheses remain essential. Every definition and preceding theorem body is unchanged.
The single-use `run_succ` helper is retained: its useful generic equation keeps the
inductive step readable and is already a public interface; deleting it saves no
mathematical argument here.

The selected four-file source total changes from 25,308 to 25,028 bytes, and from
581 to 578 lines. Endpoint dependency savings are a separate graph measurement,
to be established by the combined overlay census. The one new client has three
fully stated reports: original qualified PowerSets, the full calibration
consistency equivalence, and the dense bridge with all its original hypotheses.
Its exact axiom arrays remain prospective until a kernel check; inherited clients
will retain their already recorded exact arrays.
