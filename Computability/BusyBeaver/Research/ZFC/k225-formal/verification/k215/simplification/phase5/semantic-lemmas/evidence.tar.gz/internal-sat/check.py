"""One bounded isolated Lean invocation, with read-only phase4 providers."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,signal,sys
P=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
BASIS=Path('/tmp/k215-proof-phase4/lean-run1')
HELPER=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
COMPILER=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
a=ap.parse_args();a.out.mkdir(exist_ok=False);out=a.out.resolve()
base=read(BASIS/'result.json');assert base['status']=='PASS'
done=read(BASIS/'completed.json');inventory=read(BASIS/'inventory.json')
assert sha(BASIS/'completed.json')==base['completed_sha256']
assert sha(BASIS/'inventory.json')==base['inventory_sha256']
entries={r['module']:r for r in inventory['modules']};selected={}
def visit(m):
 if m in selected:return
 e=entries[m];r=done[m]
 for d in e['imports']:
  if d in entries:visit(d)
 assert sha(e['source'])==r['source_sha256']==e['source_sha256']
 obj=BASIS/'objects'/(m.replace('.','/')+'.olean')
 assert sha(obj)==r['object_sha256']
 assert r['dependencies']=={d:done[d]['object_sha256'] for d in e['imports'] if d in done}
 selected[m]={'source':e['source'],'source_sha256':e['source_sha256'],'imports':e['imports'],
              'object':str(obj),'object_sha256':r['object_sha256'],'dependencies':r['dependencies']}
src=a.source.resolve()
for m in re.findall(r'^import ([\w.]+)$',src.read_text(),re.M):visit(m)
toolchain=read(BASIS/'toolchain.json')
for key in ('lean','lake','Init.olean','project_toolchain'):
 assert sha(toolchain[key]['path'])==toolchain[key]['sha256']
assert sha(COMPILER)==toolchain['lean']['sha256']
canonical=REPO/'SetTheory/BoundedConsistency/Lean/BoundedZFCConsistency/InternalSat.lean'
canonical_before=sha(canonical)
snap=out/src.name;snap.write_bytes(src.read_bytes())
env=os.environ.copy();env['LEAN_PATH']=str(BASIS/'objects');env['LEAN_NUM_THREADS']='1'
obj=snap.with_suffix('.olean');assert not obj.exists() and not obj.is_symlink()
cmd=[str(COMPILER),'-j1','-M12288','--root='+str(out),'-o',str(obj),str(snap)]
row={'source_sha256':sha(src),'source_snapshot':str(snap),'command':cmd,
     'compiler_sha256':sha(COMPILER),'helper_sha256':sha(HELPER),'supervisor_sha256':sha(__file__),
     'basis_result_sha256':sha(BASIS/'result.json'),'basis_inventory_sha256':sha(BASIS/'inventory.json'),
     'basis_completed_sha256':sha(BASIS/'completed.json'),'toolchain':toolchain,'providers':selected,
     'timeout_seconds':120,'memory_mebibytes':12288,
     'scope':'One isolated scratch module/API audit. Phase4 providers are read directly; no whole-cache copy or mutation.'}
spec=importlib.util.spec_from_file_location('safe_driver',HELPER);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
ok=helper.run_locked(cmd,REPO,env,Path('/tmp/proveit-k215-proof-build.lock'),out/'compiler.log',120,row,out/'result.json')
text=(out/'compiler.log').read_text();reports=re.findall(r'depends on axioms: \[([^]]*)\]',text)
row['warnings']=text.count('warning:');row['axiom_reports']=reports
row['canonical_unchanged']=sha(canonical)==canonical_before
row['inputs_unchanged']=sha(src)==sha(snap)==row['source_sha256']
row['providers_unchanged']=all(sha(r['source'])==r['source_sha256'] and sha(r['object'])==r['object_sha256'] for r in selected.values())
row['basis_unchanged']=sha(BASIS/'result.json')==row['basis_result_sha256'] and sha(BASIS/'completed.json')==row['basis_completed_sha256']
ok=ok and row['inputs_unchanged'] and row['providers_unchanged'] and row['basis_unchanged'] and row['canonical_unchanged'] and row['warnings']==0 and 'sorryAx' not in text and 'error:' not in text
ok=ok and len(reports)==3 and all({v.strip() for v in r.split(',')}<={'propext','Classical.choice','Quot.sound'} for r in reports)
row['status']='PASS' if ok else 'FAIL'
if obj.exists():row['object_sha256']=sha(obj)
(out/'result.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps({k:v for k,v in row.items() if k not in ('providers','toolchain')},indent=2));print(text)
sys.exit(0 if ok else 1)
