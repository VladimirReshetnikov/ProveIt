"""Peer-owned metadata controls only: no build-driver/compiler/candidate invocation."""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,tempfile
HERE=Path(__file__).resolve().parent
P=Path('/tmp/k215-proof-phase8');R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert h(P/'gates.py')=='b2dcfb0f69372e25b14ed479382739966bad1488dc05289b3e5fc4ed7bdc1475'
spec=importlib.util.spec_from_file_location('peer_pinned_metadata_gates',P/'gates.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
old=json.loads(Path('/tmp/k215-proof-phase7/lean-run1/inventory.json').read_text())
new=json.loads((P/'prospective-inventory.json').read_text());reg=json.loads((P/'registered-adoption.json').read_text())
rows=[]
def test(name, fn, reject=False):
 try:fn()
 except AssertionError:
  assert reject,name
 else:assert not reject,name
 rows.append({'name':name,'expected':'reject'if reject else'accept','status':'PASS'})
def bad(name,change):
 n,r=copy.deepcopy(new),copy.deepcopy(reg);change(n,r)
 test(name,lambda:g.checkpoint(old,n,r,R),True)
test('exact_real_prospective_registration188',lambda:g.checkpoint(old,new,reg,R))
bad('registration_pending',lambda n,r:r.update(status='DRAFT_NOT_REGISTERED'))
bad('wrong_basis_result',lambda n,r:r.update(basis_result_sha256='0'*64))
bad('wrong_target',lambda n,r:n.update(target='BusyBeaver.ZFC.KEndpoint'))
bad('external_provider_added',lambda n,r:n['external_imports'].append('Mathlib'))
bad('duplicate_module_row',lambda n,r:n['modules'].append(copy.deepcopy(n['modules'][0])))
bad('unregistered_old_source',lambda n,r:n['modules'][0].update(source_sha256='f'*64))
bad('unregistered_old_import',lambda n,r:n['modules'][0]['imports'].append('Init'))
bad('missing_lean_registration',lambda n,r:r['files'].pop(0))
bad('missing_template_registration',lambda n,r:r['files'].pop())
bad('duplicate_registration',lambda n,r:r['files'].append(copy.deepcopy(r['files'][0])))
bad('registered_wrong_bytes',lambda n,r:r['files'][0].update(bytes=0))
bad('registered_wrong_hash_syntax',lambda n,r:r['files'][0].update(sha256='X'*64))
bad('registered_path_escape',lambda n,r:r['files'][0].update(destination='../escape.lean'))
bad('registered_absolute_path',lambda n,r:r['files'][0].update(destination='/tmp/escape.lean'))
bad('registered_wrong_before_pin',lambda n,r:r['files'][1].update(before_sha256='f'*64))
bad('registered_wrong_new_before_pin',lambda n,r:r['files'][0].update(before_sha256='f'*64))
bad('registered_source_location_changed',lambda n,r:next(x for x in n['modules']if x['module']==g.NEW_MODULE).update(source='/tmp/elsewhere.lean'))
bad('registered_import_disagreement',lambda n,r:r['files'][0]['imports'].append('Extra.Import'))
def seed_changed(n,r):
 m='BusyBeaver.ZFC.KSeed222'
 next(x for x in n['modules']if x['module']==m)['imports'].append('Init')
 next(x for x in r['files']if x.get('module')==m)['imports'].append('Init')
bad('seed_import_changed_even_when_registered',seed_changed)
bad('producer_wrong_kind',lambda n,r:r['files'][-1].update(kind='producer'))
bad('producer_rocq_path',lambda n,r:r['files'][-1].update(destination=g.FORMAL_PREFIX+'rocq/new.v'))
bad('producer_disguised_as_module',lambda n,r:r['files'][-1].update(module='Extra.Module'))
# Test the actual AST expression governing reuse, without executing the build script.
tree=ast.parse((P/'build.py').read_text())
expr=[n.test for n in ast.walk(tree)if isinstance(n,ast.If)and isinstance(n.test,ast.BoolOp)and "record['source_sha256']"in ast.unparse(n.test)and "record['dependencies']"in ast.unparse(n.test)]
assert len(expr)==1
reuse_code=compile(ast.Expression(expr[0]),'<actual-driver-reuse-condition>','eval')
logexpr=[n.test for n in ast.walk(tree)if isinstance(n,ast.Assert)and ast.unparse(n.test)=="sha(record['log']) == record['log_sha256']"]
assert len(logexpr)==2
logcode=compile(ast.Expression(logexpr[0]),'<actual-driver-log-condition>','eval')
with tempfile.TemporaryDirectory(prefix='peer-metadata-',dir=HERE)as td:
 t=Path(td);basis=t/'basis';basis.mkdir();cache=t/'objects';cache.mkdir();real=basis/'old.olean';real.write_bytes(b'synthetic old object');obj=cache/'x.olean';obj.symlink_to(real);log=t/'log';log.write_text('synthetic compiler log')
 record={'source_sha256':'a'*64,'dependencies':{'P':'b'*64},'object_sha256':h(real),'log':str(log),'log_sha256':h(log)}
 entry={'source_sha256':'a'*64};deps={'P':'b'*64}
 def reuse(rec=record,ent=entry,dep=deps,object_=obj):return eval(reuse_code,{'record':rec,'entry':ent,'deps':dep,'obj':object_,'sha':h})
 def yes(v):assert v
 def no(v):assert not v
 test('reuse_same_source_direct_objects_and_object_bytes',lambda:yes(reuse()))
 test('potentially_affected_but_byte_identical_provider_reuses',lambda:yes(reuse(dep=dict(deps))))
 test('changed_direct_object_refuses_reuse',lambda:no(reuse(dep={'P':'c'*64})))
 test('changed_source_refuses_reuse',lambda:no(reuse(ent={'source_sha256':'d'*64})))
 test('wrong_object_bytes_refuses_reuse',lambda:no(reuse(rec={**record,'object_sha256':'e'*64})))
 test('no_old_record_refuses_reuse',lambda:no(reuse(rec=None)))
 test('missing_object_refuses_reuse',lambda:no(reuse(object_=t/'missing.olean')))
 test('unchanged_saved_log_passes',lambda:yes(eval(logcode,{'record':record,'sha':h})))
 log.write_text('altered log')
 test('altered_saved_log_rejected',lambda:yes(eval(logcode,{'record':record,'sha':h})),True)
 test('exact_basis_provider',lambda:g.provider(obj,real,'phase7_hash_bound'))
 test('reused_provider_cannot_be_fresh',lambda:g.provider(obj,real,'phase8_fresh'),True)
 fresh=cache/'new.olean';fresh.write_bytes(b'synthetic new object')
 test('fresh_regular_provider',lambda:g.provider(fresh,t/'missing-basis','phase8_fresh'))
 test('fresh_regular_cannot_be_reused',lambda:g.provider(fresh,real,'phase7_hash_bound'),True)
 test('new_cache_parent_chain',lambda:g.private_parents(cache/'Module/new.olean',cache))
 alias=cache/'alias';alias.symlink_to(basis,target_is_directory=True)
 test('directory_alias_rejected_before_unlink',lambda:g.private_parents(alias/'old.olean',cache),True)
 test('cache_itself_alias_rejected',lambda:g.private_parents(alias/'old.olean',alias),True)
 other=basis/'other.olean';other.write_bytes(b'other');wrong=cache/'wrong.olean';wrong.symlink_to(other)
 test('wrong_reused_target_rejected',lambda:g.provider(wrong,real,'phase7_hash_bound'),True)
for name,names in g.AUDIT_NAMES.items():
 text='\n'.join("'%s' depends on axioms: [propext, Classical.choice, Quot.sound]"%n for n in names)
 test(name+'_exact_named_reports',lambda name=name,text=text:g.audit_reports(name,text))
 for suffix,alter in [('missing',lambda s:s.split('\n',1)[1]),('reordered',lambda s:'\n'.join(reversed(s.splitlines()))),('extra',lambda s:s+'\n'+s.splitlines()[0]),('untrusted_axiom',lambda s:s.replace('propext','untrustedAxiom')),('warning',lambda s:s+'\nwarning: unexpected'),('error',lambda s:s+'\nerror: unexpected'),('sorry',lambda s:s+'\nsorryAx')]:
  test(name+'_'+suffix,lambda name=name,text=text,alter=alter:g.audit_reports(name,alter(text)),True)
result={'status':'PASS_PEER_METADATA_CONTROLS','scope':'Own tests of reviewed pure metadata gates and AST-extracted reuse/log expressions only. No build driver/compiler/candidate or producer invocation.','pins':{n:h(P/n)for n in ['build.py','gates.py','registered-adoption.json','prospective-inventory.json']},'positive':sum(x['expected']=='accept'for x in rows),'negative':sum(x['expected']=='reject'for x in rows),'cases':rows}
(HERE/'controls-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='cases'},indent=2))
