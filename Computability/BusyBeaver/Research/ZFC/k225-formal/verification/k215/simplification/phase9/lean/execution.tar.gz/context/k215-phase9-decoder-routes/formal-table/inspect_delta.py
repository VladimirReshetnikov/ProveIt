"""Independent field-level data comparison only; no transition execution."""
from pathlib import Path
import re,json,hashlib
O=Path(__file__).resolve().parent;A=O.parent/'candidate/BusyBeaver/ZFC';B=O/'candidate/BusyBeaver/ZFC'
old=(A/'K215Decoder.lean').read_text();new=(B/'K215Decoder.lean').read_text();sw={301:102,102:301,302:120,120:302,254:230,230:254}
def sig(n):return sw.get(n,n)
def section(s,a,b):return s[s.index('def '+a+' :'):s.index('def '+b+' :')]
def blocks(s):return [(int(a),int(b),c,int(d))for a,b,c,d in re.findall(r'^  ⟨(\d+), (\d+), \[(.*?)\], (\d+)⟩,?$',section(s,'blocks','roles'),re.M)]
x,y=blocks(old),blocks(new);assert len(x)==len(y)==281
for (a,b,c,d),v in zip(x,y):assert v==(sig(a),sig(b),c,d)
def roles(s):return [(int(a),int(b),c)for a,b,c in re.findall(r'^  ⟨(\d+), (\d+), (.*)$',section(s,'roles','sourceRoot'),re.M)]
x,y=roles(old),roles(new);assert len(x)==len(y)==234
primitive_actions=0
for (n,q,tail),(nn,qq,out) in zip(x,y):
 assert nn==n and qq==sig(q)
 oldactions=re.findall(r'⟨(true|false), (1|\(-1\)), (\d+)⟩',tail);newactions=re.findall(r'⟨(true|false), (1|\(-1\)), (\d+)⟩',out)
 assert [(w,d,sig(int(t)))for w,d,t in oldactions]==[(w,d,int(t))for w,d,t in newactions]
 primitive_actions+=len(oldactions)
 # The positions and every non-action/state token must match exactly.
 scrub=lambda s:re.sub(r'(⟨(?:true|false), (?:1|\(-1\)), )\d+(⟩)',r'\1NEXT\2',s)
 assert scrub(tail)==scrub(out)
assert primitive_actions==97
assert section(old,'sourceNodes','blocks')==section(new,'sourceNodes','blocks')
assert 'nativeRows'not in new and not re.search(r'\bnative\b',new)
assert 'def formal : Table := KZipTape.table KTableCore.tm215'in new
assert 'def fast : Table := KZipTape.table (KBoot.fastOf KBoot215.tt215)'in new
for name in ['DecoderCertificate.lean','DecoderPaths.lean','DecoderSourceBinding.lean']:
 assert (B/name).read_text()==re.sub(r'\bnative\b','formal',(A/name).read_text())
files={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'lines':len(p.read_bytes().splitlines())}for p in B.glob('*.lean')}
r={'status':'PASS_FIELD_LEVEL_SOURCE_DELTA_ONLY','state_swaps':[[301,102],[302,120],[254,230]],'blocks':281,'roles':234,'primitive_actions':97,'source_nodes_exact':True,'nonstate_role_and_block_fields_exact':True,'files':files,'four_module_bytes':sum(v['bytes']for v in files.values()),'removed_bytes_from_route_v1':sum(p.stat().st_size for p in A.glob('*.lean'))-sum(v['bytes']for v in files.values()),'table_or_block_execution':False,'compiler_invocations':[]}
(O/'delta-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
