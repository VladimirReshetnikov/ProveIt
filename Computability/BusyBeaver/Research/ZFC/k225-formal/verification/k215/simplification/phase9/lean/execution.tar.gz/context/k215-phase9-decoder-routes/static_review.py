"""Own source/metadata comparison only: no Lean or machine execution."""
from pathlib import Path
import json,re,hashlib
O=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
P=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/proposals/composition-address-bounds/decoder_source_paths'
C=O/'candidate/BusyBeaver/ZFC';B=R/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'lines':len(b.splitlines())}
def clean(s):
 s=re.sub(r'/\-.*?\-/','',s,flags=re.S);s=re.sub(r'--[^\n]*','',s)
 s=re.sub(r'^#print[^\n]*|^end[^\n]*|^namespace[^\n]*|^open[^\n]*|^set_option[^\n]*','',s,flags=re.M)
 return s
pat=re.compile(r'^(?:private )?(def|theorem|inductive|structure|abbrev) ([\w.]+)\b',re.M)
def decls(p):
 s=clean(p.read_text());ms=list(pat.finditer(s));return {m[2]:(m[1],s[m.start():ms[i+1].start()if i+1<len(ms)else len(s)])for i,m in enumerate(ms)}
def norm(s):return re.sub(r'\s+','',s)
changes={'source_path_chain','reaches_primitive','upstream_leaf_reaches','upstream_walk_reaches'};checks=[]
for name in ['DecoderCertificate.lean','K215Decoder.lean','DecoderPaths.lean','DecoderSourceBinding.lean']:
 old,new=decls(P/name),decls(C/name);assert set(old)<=set(new)
 for n,(kind,s)in old.items():
  kind2,t=new[n];assert kind==kind2
  if kind=='theorem':assert norm(s.split(':=',1)[0])==norm(t.split(':=',1)[0]),(name,n,'header')
  if n not in changes:assert norm(s)==norm(t),(name,n,'body')
 assert not re.search(r'\b(sorry|axiom|admit|unsafe|native_decide)\b',clean((C/name).read_text()))
 checks.append({'file':name,'old_declarations':len(old),'retained':len(old),'new_declarations':sorted(set(new)-set(old)),'source':pin(P/name),'candidate':pin(C/name)})
old=Path('/tmp/k215-decoder-path-interface');w=old/'path-witnesses.json';f=json.loads((old/'finite-result.json').read_text());assert pin(w)['sha256']==f['path_witnesses_sha256']
data=json.loads(w.read_text());print('witness keys',list(data))
leaves=data['leaves']if'leaves'in data else data['primitive_occurrences']
assert len(leaves)==4751
branches=sum(2 if x['op']=='CD'else 1 for x in leaves);assert branches==6176
# Transfer the frozen finite traversal only across exact input equality.
for rec in f['inputs']:
 if rec['path'].endswith('/sites215.json'):target=R/rec['path']
 else:target=P/Path(rec['path']).name
 assert pin(target)['sha256']==rec['sha256'],str(target)
stat={'leaves':len(leaves),'branch_outcomes':branches,'decrement_leaves':sum(x['op']=='CD'for x in leaves),'unique_terminal_role_bits':len({(x['role'],x['final_bit'])for x in leaves}),'parametric_role_outcomes_if_proved':sum(2 if x['op']=='CD'else 1 for x in {(x['role'],x['final_bit']):x for x in leaves}.values()),'sum_decoder_prefix_steps_per_leaf':sum(x['internal_steps']for x in leaves),'sum_decoder_prefix_steps_per_branch':sum(x['internal_steps']*(2 if x['op']=='CD'else 1)for x in leaves),'prefix_steps_range':[min(x['internal_steps']for x in leaves),max(x['internal_steps']for x in leaves)],'scope':'Counts from frozen own source/role-path witness traversal, whose exact data/source pins match current. No new local block or primitive runtime check.'}
batches=[B/f'KSites215Batch{i:03d}.lean'for i in range(9)];assert sum(len(re.findall(r'^theorem block_',p.read_text(),re.M))for p in batches)==105
current=[B/n for n in ['KSim.lean','KZip.lean','KSource215Program.lean','KFastSites215.lean','KSites215.lean']]+batches
r={'status':'PASS_STATIC_API_DATA_AND_CURRENT_SOURCE_REVALIDATION','head':json.loads((O/'current-literal-review.json').read_text())['head'],'declarations':checks,'finite_scope':stat,'current_files':[pin(p)for p in current],'site_batches_bytes':sum(p.stat().st_size for p in batches),'site_facade_bytes':(B/'KSites215.lean').stat().st_size,'candidate_four_module_bytes':sum((C/n).stat().st_size for n in ['DecoderCertificate.lean','K215Decoder.lean','DecoderPaths.lean','DecoderSourceBinding.lean']),'new_project_modules_if_all_components_adopted':5,'further_bridge_and_semantic_modules_not_included':True,'compiler_invocations':[],'canonical_mutations':[]}
(O/'static-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(stat,indent=2));print('candidate',r['candidate_four_module_bytes'],'sites',r['site_batches_bytes'],r['site_facade_bytes'])
