"""Finalize source-only command maps; never invokes Lean or a producer."""
from pathlib import Path
import hashlib,json,re
S=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
plans=read(S/'candidate-map.json')['modules']
for r in plans:
 if r['module']=='LukasShared13Api':
  assert len(r['reports'])==8;r['report_axioms']=[[] for _ in range(7)]+[['propext','Classical.choice','Quot.sound']]
 if r['module']in ['WFModelCompat12','ZFNativeCompat12']:
  old=read(Path('/tmp/k215-phase12-import-check/compatibility-run1/completed.json'))[r['module']]
  txt=Path(old['log']).read_text();rep=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
  assert [n for n,_ in rep]==r['reports'];r['report_axioms']=[[s.strip()for s in ax.split(',')if s.strip()]for _,ax in rep]
for name,invname,audit in [('primary','primary-with-api',True),('compatibility','compatibility',False),('api-only','api-only',False)]:
 inv=read(S/(invname+'-inventory.json'));selected={r['module']for r in inv['modules']};mods=[r for r in plans if r['module']in selected]
 mp={'modules':mods,'expected':{'modules':[r['module']for r in inv['modules']],'changed':inv['changed'],'forced':inv['forced']}}
 save(S/(name+'-map.json'),mp)
 cmd=['python','-B',str(S/'build.py'),'--out',str(S/(name+'-run1')),'--map',str(S/(name+'-map.json'))]
 for t in inv['targets']:cmd+=['--target',t]
 if audit:cmd+=['--audit-endpoint']
 summary={'status':'PREPARED_NOT_EXECUTED','command':cmd,'targets':inv['targets'],'selected_providers':len(selected),'source_changed_modules':inv['changed'],'expected_fresh_without_secondary':inv['forced'],'expected_old_reuse':[m for m in mp['expected']['modules']if m not in inv['forced']],'endpoint_audits':2 if audit else 0,'typed_api_clients':[r['module']for r in mods if 'reports'in r and not r['module'].startswith('BusyBeaver.')],'input_pins':{str(p):sha(p)for p in [S/'build.py',S/'producer-boundary.json',S/(name+'-map.json')]},'scope':'Source-only plan; no compiler execution. API-only is an unused alternative, not an additional required run.'}
 if name=='compatibility':
  c=read(S/'census.json');summary['pending_primary_reuse']={'directory':str(S/'primary-run1'),'expected_primary_modules':c['compatibility_after_primary_reuse'],'expected_fresh':c['compatibility_fresh_after_primary'],'expected_old_reuse':c['compatibility_old_unaffected_reuse'],'map_finalizer_requires_actual_primary_PASS':True}
 save(S/(name+'-plan.json'),summary)
# Keep the frozen old client source bytes locally, with before pins unchanged.
print(json.dumps({'primary_providers':read(S/'primary-plan.json')['selected_providers'],'primary_fresh':len(read(S/'primary-plan.json')['expected_fresh_without_secondary']),'compatibility_providers':read(S/'compatibility-plan.json')['selected_providers'],'compiler_invoked':False},indent=2))
