from pathlib import Path
p=Path(__file__).parent;s=(p/'ConstructibleAbs.lean').read_text();old=(p/'ConstructibleAbs.before.lean').read_text()
s=s.replace('''  simp only [inductiveV, val_vempty H hR hP, val_vsucc H hR hP, forall_memL_iff H hR hP]
''','''  unfold inductiveV
  change (mem (vempty (L_zfAxioms H hR hP)).1 c.1 ∧
    ∀ y : {x // InL H hP x}, mem y.1 c.1 → mem (vsucc (L_zfAxioms H hR hP) y).1 c.1) ↔ _
  simp only [val_vempty H hR hP, val_vsucc H hR hP]
  exact and_congr Iff.rfl (forall_memL_iff H hR hP c fun y => mem (vsucc H y) c.1)
''')
s=s.replace('''  simp only [codeEq_iff H hR hP, natEq_iff H hR hP, hT,
    forall_memL_iff H hR hP, exists_memL_iff H hR hP]
''','''  simp only [codeEq_iff H hR hP, natEq_iff H hR hP, hT]
  have hall (c1 : {x // InL H hP x}) := forall_memL_iff H hR hP A
    (fun d => mem (satTriple H c1.1 (econs H d e.1) (natV H u)) S.1)
  have hex (c1 : {x // InL H hP x}) := exists_memL_iff H hR hP A
    (fun d => mem (satTriple H c1.1 (econs H d e.1) (natV H v)) S.1)
  simp only [hall, hex]
''')
s=s.replace('''    · exact forall_memL_iff H hR hP S _
    · exact forall_memL_iff H hR hP S _''','''    · exact forall_memL_iff H hR hP S (fun z => mem z X.1)
    · exact forall_memL_iff H hR hP S (fun _ => False)''')
a=s.index('  simp only [InternalOrd.Ord, Trans',s.index('theorem ord_iff'));b=s.index('\n/-- **`V = L`',a)
a0=old.index('  have htr :',old.index('theorem ord_iff'));b0=old.index('\n/-- **`V = L`',a0)
s=s[:a]+old[a0:b0]+s[b:]
(p/'ConstructibleAbs.lean').write_text(s)
