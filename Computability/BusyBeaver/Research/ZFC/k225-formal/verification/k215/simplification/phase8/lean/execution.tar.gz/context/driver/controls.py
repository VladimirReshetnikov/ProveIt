"""Only new phase8 registration/import/provider gates; no compiler or capture."""
from pathlib import Path
import copy,hashlib,importlib.util,json,tempfile
P=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
spec=importlib.util.spec_from_file_location('phase8_gate_controls',P/'gates.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
old=json.loads(Path('/tmp/k215-proof-phase7/lean-run1/inventory.json').read_text());new=copy.deepcopy(old)
oldrows={r['module']:r for r in old['modules']}
for r in new['modules']:
 if r['module']in g.REGISTERED_MODULES:r['source_sha256']='1'*64
core={'module':g.NEW_MODULE,'source':str(R/'Computability/BusyBeaver/Lean'/('BusyBeaver/ZFC/DominatedImplication.lean')),'source_sha256':'2'*64,'imports':[]}
index=next(i for i,r in enumerate(new['modules'])if r['module']=='BusyBeaver.ZFC.DomRho8')
new['modules'].insert(index,core);new['modules'][index+1]['imports'].insert(0,g.NEW_MODULE)
registration={'status':'REGISTERED_FOR_COMBINED_CHECK_NOT_YET_VERIFIED','basis_result_sha256':g.BASIS_RESULT_SHA256,'primary_project_modules':188,'basis_project_modules':187,'files':[]}
for row in new['modules']:
 if row['module']in g.REGISTERED_MODULES:
  registration['files'].append({'kind':'lean','module':row['module'],'destination':str(Path(row['source']).relative_to(R)),'sha256':row['source_sha256'],'bytes':1,'imports':row['imports'],'before_sha256':oldrows.get(row['module'],{}).get('source_sha256')})
for destination,kind in g.PRODUCTION_PATHS.items():
 registration['files'].append({'kind':kind,'destination':destination,'sha256':'3'*64,'bytes':1,'before_sha256':'4'*64})
rows=[]
def test(name,fn,reject=False):
 try:fn()
 except AssertionError:assert reject,name
 else:assert not reject,name
 rows.append({'name':name,'expected':'reject'if reject else'accept','status':'PASS'})
def mutated(inv=None,reg=None):g.checkpoint(old,inv or new,reg or registration,R)
scope=g.checkpoint(old,new,registration,R)
test('four_registered_sources_and_only_one_new_module',lambda:mutated())
def changed(fn):
 n=copy.deepcopy(new);r=copy.deepcopy(registration);fn(n,r);mutated(n,r)
test('reject_extra_new_module',lambda:changed(lambda n,r:n['modules'].append({**core,'module':'Extra.Core'})),True)
test('reject_unregistered_old_source_change',lambda:changed(lambda n,r:n['modules'][0].update(source_sha256='0'*64)),True)
test('reject_registered_import_mismatch',lambda:changed(lambda n,r:next(x for x in n['modules']if x['module']==g.NEW_MODULE)['imports'].append('Init')),True)
test('reject_wrong_before_pin',lambda:changed(lambda n,r:r['files'][0].update(before_sha256='0'*64)),True)
test('reject_duplicate_registration',lambda:changed(lambda n,r:r['files'].append(copy.deepcopy(r['files'][0]))),True)
test('reject_rocq_producer_path',lambda:changed(lambda n,r:r['files'][-1].update(destination=g.FORMAL_PREFIX+'rocq/generate_domrho8_lean.py')),True)
with tempfile.TemporaryDirectory(prefix='new-provider-control-',dir=P)as temp:
 p=Path(temp);obj=p/'new.olean';obj.write_bytes(b'fresh synthetic object')
 test('new_module_fresh_provider_has_no_basis_object',lambda:g.provider(obj,p/'absent-basis.olean','phase8_fresh'))
 test('new_module_cannot_claim_missing_basis_reuse',lambda:g.provider(obj,p/'absent-basis.olean','phase7_hash_bound'),True)
result={'status':'PASS_NEW_PHASE8_GATE_CONTROLS','positive':sum(r['expected']=='accept'for r in rows),'negative':sum(r['expected']=='reject'for r in rows),'cases':rows,'synthetic_affected_modules':scope['potentially_affected_modules'],'candidate_pins_final':False,'scope':'Synthetic four-source registration and prospective19-module dependency closure; no sourcebody claim, compiler, driver, canonical change or current-run capture.'}
(P/'controls-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ('cases','synthetic_affected_modules')},indent=2))
