# Phase13 compact publication plan

Preparation only. The future packet describes two exact checks and five separately adopted files. The prospective census is 187 primary providers (184 project modules and three API clients), 36 fresh/151 phase12 reuses; compatibility has70 providers (68 project modules and two retained clients), 16 fresh/53 current-primary reuses/one phase12 reuse (Dag254). The union has199 distinct project modules. These counts are expectations until the two terminal ledgers pass the source and record checks.

The endpoint itself remains179 modules; its five selected decoder-prefix modules are additional. The three new API clients belong to the primary compilation inventory, not the endpoint project count. The two unchanged endpoint clients are freshly compiled after that inventory. Their ten exact named profiles and zero audit warnings remain separate from the three API clients' twenty reports and the module reports. Compatibility retains its ten client reports plus WFTheory's five. Actual warning counts will be derived from every selected raw log, split by fresh/inherited origin; no zero-total claim is prewritten.

## Exact predecessor, referenced in place

`basis-reference.json` pins the seven published phase12 execution/validator files, including archive707caf915b0ad9c93691745cd273af9d8e24e222069d51fa90989d1dceb94ef4. `basis.py` is a source-only successor of the small phase12 loader. It verifies those pins before executing only the already-reviewed local saved reader, in historical mode (`repo=None`). It restores imported module bindings afterward. Archive members are only data; no archive script, submitted renderer, proof compiler or machine runtime is executed.

The loader flattens phase12's own path map into verified byte accessors. That preserves the old phase12 raw-source and old-producer boundary exactly. The new packet uses routes `{storage: packet|phase12, key, sha256, bytes}`. Identical historical logs, sources and input records remain phase12 references. No ancestor archive, compiled object, cache directory or whole proof tree is copied. Current adoption is checked separately, never by asking phase12's saved reader to accept phase13 sources.

## Narrow new validator

Use independent new `packet.py` validation for these two runs; reuse the predecessor's already-checked generic import parser, DAG/closure and axiom-log parser only through the pinned historical loader. Keep the predecessor scripts and records unchanged.

For each exact target inventory, recompute source/import closure, topological provider sets, changed sources and all transitive descendants. Bind the actual result to inventory/completed hashes, raw before record, explicit map and driver/freeze pins. Require exact selected origins and equality to the full prior record modulo the origin tag. Older reuse must preserve the entire transitive source/import closure and actual dependency object hashes; an identical intermediate object does not erase a changed transitive source. Current-primary reuse in compatibility must bind its actual result/inventory/completed ledger and the same complete closure. Current-only API clients are never treated as project modules.

Read every fresh/reused log and source by its recorded pin. Require successful exits, no timeouts/errors/admissions and the permitted standard reports; for mapped APIs/core require exact names and exact specified axiom sets (including no axioms for the generic core/API). Bind every fresh command, source snapshot, compiler/helper/toolchain pin, direct dependency map and record. Keep the exact two endpoint client sources and 2+8 report profiles. Both actual outer receipts, root/independent raw reviews and all retained failed/preliminary attempts are part of context, not substitutes for validation.

Current mode checks all199 canonical project sources, all five adopted files and their exact old/new pins. The raw before-input map may still name the old canonical producer/derivation/renderer: preserve those exact bytes through immutable snapshots or validated phase12 routes, and list only actual mismatches as explicit historical inputs. Do not broadly exempt arbitrary changed inputs. Check new producer/core/adapter reproduction separately. Maintain both retired prefix/suffix absence gates and unchanged machine/source-program pins.

## Capture and saved review

After terminal PASS, root adoption and clean helper peer, `collect.py` takes both nonblocking output locks. It resolves the verified predecessor once, stores only new bytes, and preserves original absolute-path routes for portability. Store fresh run records/logs, API sources, metadata/maps/freeze, selected source proposals and actual producer reproduction. Adoption copies include the upstream research renderer only as inert attributed data. A narrow context map lists explicit records; no recursive scratch-tree packing, pycache, compiled suffixes, symlinks or nested archives.

Before writing the archive, perform the independent live rehash of every current selected object/log/source/dependency, endpoint audit object/copied source, all basis/current before inputs, toolchain and absence gates. Preserve exact source binding after root's five-file adoption through an explicit historical-before map. Re-evaluate named audit profiles after the postcheck. Save live-postcheck separately; a saved reader verifies recorded object provenance, not inaccessible live object bytes.

Write a deterministic no-binary archive, exact index and summary. `review_saved.py` verifies complete member set, safe names, lengths/hashes, helper identity, predecessor pins and all new record gates; optional `--repo` checks the current199 sources and five adoptions. Historical mode must remain usable after a future checkpoint. No repeated full compiler run is part of publication.

## Controls and remaining freeze

Prospective pure metadata controls should demonstrate rejection of a missing/extra provider, changed import/source, changed transitive source hidden by an identical intermediate object, altered direct object dependency, changed basis/current-primary reference, failed/nonzero/timeout raw record, mutated inherited log, wrong exact API profile, duplicate/unsafe/compiled archive member and changed historical/current adoption pin. Positive controls retain legitimate phase12 reuse and the exact current-primary compatibility reuse. Keep control execution separate from capture.

The next freeze needs Drop's final driver/maps/producer boundary and actual primary/compatibility receipt paths, followed by root's five-file adoption/current-binding map. Do not invent terminal pins or execute this draft loader while those inputs are pending. Final README counts will come from validated actual ledgers. Root owns canonical publication and Git integration.
