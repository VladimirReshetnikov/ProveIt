from pathlib import Path
import subprocess, re, difflib, json, hashlib
P=Path(__file__).resolve().parent
rel='Computability/BusyBeaver/Lean/BusyBeaver/ZFC/EnumPerm.lean'
u=subprocess.check_output(['git','show','origin/main:'+rel])
up=P/'upstream/BusyBeaver/ZFC/EnumPerm.lean';up.parent.mkdir(parents=True,exist_ok=True);up.write_bytes(u)
script=(P/'prepare.py').read_text()
script=script[:script.index("point = source.index('theorem cexec_discard ')")]
script=script.replace("(P / 'EnumPerm-original.lean').read_text()", "(P / 'upstream/BusyBeaver/ZFC/EnumPerm.lean').read_text()")
script+='''\ntarget = P / 'preferred/BusyBeaver/ZFC/EnumPerm.lean'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(source)
(P / 'preferred.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True), fromfile='upstream/EnumPerm.lean', tofile='preferred/EnumPerm.lean')))
print({'upstream_lines': len(original.splitlines()), 'preferred_lines': len(source.splitlines())})
'''
(P/'prepare_upstream.py').write_text(script)
old=(P/'EnumPerm-original.lean').read_text();new=u.decode()
removed=sorted(set(re.findall(r'(?m)^(?:theorem|def) ([\w.]+)',old))-set(re.findall(r'(?m)^(?:theorem|def) ([\w.]+)',new)))
print('removed:',removed)
(P/'upstream.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True))))
(P/'upstream.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','origin/main']).decode().strip(),'source_sha256':hashlib.sha256(u).hexdigest(),'removed_names':removed},indent=2)+'\n')
