#!/usr/bin/env python3
"""Exact v4 transitive eligibility controls; read-only metadata, no build invocation."""
import ast,copy,hashlib,json
from pathlib import Path
P=Path('/tmp/k215-phase9-main/build-v4.py');OLD=Path('/tmp/k215-phase9-main/build-v3.py');ROOT=Path('/tmp/k215-phase9-main-peer');B=Path('/tmp/k215-proof-phase8/lean-run1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(P)=='287ad156c55681c2c00dabc524d799df4c43f342455c64805031591a8e81e37a'
t=ast.parse(P.read_bytes());o=ast.parse(OLD.read_bytes());f={n.name:n for n in ast.walk(t)if isinstance(n,ast.FunctionDef)};of={n.name:n for n in ast.walk(o)if isinstance(n,ast.FunctionDef)}
for n in ['visit','usable','log_policy','postcheck']:assert ast.dump(f[n],include_attributes=False)==ast.dump(of[n],include_attributes=False)
# Execute the exact changed/forced fixed-point fragment with synthetic in-memory metadata.
start=next(i for i,n in enumerate(t.body)if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='changed'for x in n.targets));fragment=t.body[start:start+3];assert isinstance(fragment[-1],ast.While)
def forced(rows,old):
 g={'entry_by_name':rows,'old':old};exec(compile(ast.Module(body=fragment,type_ignores=[]),'<v4 pure source propagation>','exec'),g);return g['changed'],g['forced']
def compatible(rows,reuse,m):
 g={'entry_by_name':rows,'reuse_rows':reuse,'compatible':{}};exec(compile(ast.Module(body=[f['same_transitive_sources']],type_ignores=[]),'<v4 pure source compatibility>','exec'),g);return g['same_transitive_sources'](m)
old={'A':{'source_sha256':'old-a','imports':[]},'B':{'source_sha256':'same-b','imports':['A']},'C':{'source_sha256':'same-c','imports':['B']},'D':{'source_sha256':'same-d','imports':[]}}
new=copy.deepcopy(old);new['A']['source_sha256']='new-a';changed,rebuild=forced(new,old);assert changed=={'A'}and rebuild=={'A','B','C'};assert 'C'in rebuild
assert not compatible(new,old,'C');assert compatible(new,new,'C');assert compatible(new,old,'D')
wrongimports=copy.deepcopy(new);wrongimports['B']['imports']=[];assert not compatible(new,wrongimports,'C')
# Actual exact pinned isolated origin, not the rejected full-run1 origin.
plan=json.loads(Path('/tmp/k215-phase9-main/full-v1.json').read_bytes());pins=plan['reuse_ledger'];iso=Path(pins['directory']);assert iso==Path('/tmp/k215-phase9-main/isolated-run2')
for n in ['result.json','inventory.json','completed.json']:assert sha(iso/n)==pins[n]
rows=json.loads(Path('/tmp/k215-phase9-main/full-run2/inventory.json').read_bytes())['modules'];current={r['module']:r for r in rows};basis=json.loads((B/'completed.json').read_bytes());reused_rows={r['module']:r for r in json.loads((iso/'inventory.json').read_bytes())['modules']};changed,rebuild=forced(current,basis)
iso_current={m for m in current if compatible(current,reused_rows,m)}
batches=sorted(m for m in current if 'KSites215Batch'in m);assert len(batches)==9 and set(batches)<=rebuild and not(set(batches)&iso_current)
need_fresh=rebuild-iso_current
owner=json.loads(Path('/tmp/k215-phase9-main/full-run2/before.json').read_bytes());assert sorted(rebuild)==owner['force_basis_rebuild'];assert sorted(changed)==owner['changed_sources'];assert owner['rows']==rows
result={'status':'PASS_SOURCE_AND_TRANSITIVE_REUSE_CONTROLS','driver_sha256':sha(P),'unchanged_v3_checked_function_ASTs':['visit','usable','log_policy','postcheck'],'masked_intermediate_control':{'changed':['A'],'forced':['A','B','C'],'C_baseline_reuse_rejected':True,'old_isolated_C_rejected':True,'current_isolated_C_allowed':True,'unaffected_D_allowed':True,'changed_import_C_rejected':True},'actual':{'selected_modules':len(current),'source_changed':sorted(changed),'forced_count':len(rebuild),'forced':sorted(rebuild),'exact_compatible_isolated':sorted(iso_current),'expected_fresh':sorted(need_fresh),'expected_fresh_count':len(need_fresh),'all_nine_site_batches_forced_fresh':True,'trusted_isolated_module_count':len(reused_rows),'trusted_reuse_pin':pins},'compiler_invocations':0,'actual_object_or_log_rehash_claim':False}
(ROOT/'controls-v4.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'forced':len(rebuild),'fresh_expected':len(need_fresh),'site_batches_forced':len(batches),'trusted_isolated_modules':len(reused_rows)},indent=2))
