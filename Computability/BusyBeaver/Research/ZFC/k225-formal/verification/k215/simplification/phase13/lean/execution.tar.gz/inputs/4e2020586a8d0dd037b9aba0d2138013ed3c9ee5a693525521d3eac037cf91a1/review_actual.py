"""Independent read-only phase13 actual audit. Does not run a compiler or producer."""
from pathlib import Path
import argparse,ast,fcntl,hashlib,json,re
S=Path('/tmp/k215-phase13-upstream-check');E=Path('/tmp/k215-phase13-upstream-execution');R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
B=Path('/tmp/k215-phase12-import-check/primary-run1');BC=Path('/tmp/k215-phase12-import-check/compatibility-run1')
C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def named(text):return re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
def profiles(reports):return [set(x.strip()for x in ax.split(',')if x.strip())for _,ax in reports]
def imports(path):
 text=Path(path).read_text();out=[];i=0;depth=0
 while i<len(text):
  if text[i:i+2]=='/-':depth+=1;i+=2
  elif depth and text[i:i+2]=='-/':depth-=1;i+=2
  elif depth:
   if text[i]=='\n':out.append('\n')
   i+=1
  elif text[i:i+2]=='--':
   j=text.find('\n',i);i=len(text)if j<0 else j
  elif text[i]=='"':
   i+=1
   while i<len(text):
    if text[i]=='\\':i+=2
    elif text[i]=='"':i+=1;break
    else:i+=1
  else:out.append(text[i]);i+=1
 assert depth==0
 return [w for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',''.join(out))for w in line.split()]
ap=argparse.ArgumentParser();ap.add_argument('--label',choices=['primary-run1','compatibility-run1'],required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();O=S/a.label
assert not a.output.exists();lock=(O/'output.lock').open('r');fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
assert sha(S/'freeze.json')=='01c6f3c207490dd3cab316ec849537a0cddf136679fba1717ace5f199e4421ba'
freeze=read(S/'freeze.json')
for n,h in freeze['files'].items():assert sha(S/n)==h
result=read(O/'result.json');before=read(O/'before.json');inv=read(O/'inventory.json');done=read(O/'completed.json');outer=read(E/(a.label+'-outer.json'))
assert outer['status']=='OUTER_EXIT_0'and outer['exit_code']==0 and outer['exception']is None
assert outer['helper_inputs_unchanged']and outer['plan_unchanged'];assert outer['before_helper_inputs']==outer['after_helper_inputs']=={str(S/n):h for n,h in freeze['files'].items()}
assert outer['freeze_sha256']==sha(S/'freeze.json')and outer['wrapper_sha256']==sha(E/'run.py')
assert sha(outer['source_peer'])==outer['source_peer_sha256']=='a3895b655027304974c340482d7af923b106630d099665a4ab7524f5a88c49aa'
for k in ['stdout','stderr']:assert sha(outer[k])==outer[k+'_sha256']
assert sha(outer['plan'])==outer['plan_sha256'];plan=read(outer['plan']);assert plan['command']==outer['command'];assert outer['command'][:3]==['python','-B',str(S/'build.py')]
assert outer['command'][outer['command'].index('--out')+1]==str(O)
mp_path=Path(outer['command'][outer['command'].index('--map')+1]);mp=read(mp_path)
assert result['status']=='PASS'and result['runner_sha256']==before['runner_sha256']==sha(S/'build.py')
assert result['map_sha256']==before['map_sha256']==sha(mp_path)
assert result['producer_boundary_sha256']==sha(S/'producer-boundary.json')
assert result['inventory_sha256']==sha(O/'inventory.json')and result['completed_sha256']==sha(O/'completed.json')
assert before['targets']==inv['targets']==result['targets']==plan['targets'];assert [x for i,x in enumerate(outer['command'])if i and outer['command'][i-1]=='--target']==inv['targets']
assert [r['module']for r in inv['modules']]==mp['expected']['modules'];rows={r['module']:r for r in inv['modules']};assert len(rows)==len(inv['modules'])==len(done)and set(rows)==set(done)
assert result['basis_result_sha256']==sha(B/'result.json')=='a5fce6a787751ba527cc368ff97b770d28eeb517149d5e3f99b17dd7c738df5e'
assert result['compatibility_basis_result_sha256']==sha(BC/'result.json')=='7223a5fa4f5fe56e331d2dc27efc7b2d8e50f473d081eed9e145278728e68f9c'
assert sha(C)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550';assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
old={};oldrows={};origins={};providers={}
for d,kind,n in [(BC,'phase12_compatibility_checked',69),(B,'phase12_primary_checked',184)]:
 bi=read(d/'inventory.json');bd=read(d/'completed.json');br=read(d/'result.json')
 assert sha(d/'inventory.json')==br['inventory_sha256']and sha(d/'completed.json')==br['completed_sha256'];assert len(bi['modules'])==len(bd)==n
 assert read(d/'toolchain.json')==read(O/'toolchain.json')==read(B/'toolchain.json')
 for row in bi['modules']:
  m=row['module'];r=bd[m];assert r['source_sha256']==row['source_sha256'];assert r['dependencies']=={x:bd[x]['object_sha256']for x in row['imports']if x!='Init'}
  assert sha(d/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']
  if m in old:assert row['source_sha256']==oldrows[m]['source_sha256']and row['imports']==oldrows[m]['imports']and r['object_sha256']==old[m]['object_sha256']
  old[m]=r;oldrows[m]=row;origins[m]=kind;providers[m]=d
assert len(old)==201
for m,r in old.items():assert r['dependencies']=={d:old[d]['object_sha256']for d in oldrows[m]['imports']if d!='Init'}
for p,h in before['inputs'].items():assert sha(p)==h,p
for p in before['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink()
changed={m for m,r in rows.items()if m not in oldrows or r['source_sha256']!=oldrows[m]['source_sha256']};forced=set(changed)
while True:
 more=forced|{m for m,r in rows.items()if set(r['imports'])&forced}
 if more==forced:break
 forced=more
assert sorted(changed)==mp['expected']['changed']==result['source_changed_modules']==before['changed_sources'];assert sorted(forced)==mp['expected']['forced']==result['force_basis_rebuild_modules']==before['force_basis_rebuild']
secondary={};secondaryrows={};secondarydir=None
if 'reuse_ledger'in mp:
 pins=mp['reuse_ledger'];secondarydir=Path(pins['directory']);assert secondarydir==S/'primary-run1'
 for n in ['result.json','inventory.json','completed.json']:assert sha(secondarydir/n)==pins[n]
 sr=read(secondarydir/'result.json');assert sr['status']=='PASS'and sr['inventory_sha256']==pins['inventory.json']and sr['completed_sha256']==pins['completed.json']
 secondary=read(secondarydir/'completed.json');secondaryrows={r['module']:r for r in read(secondarydir/'inventory.json')['modules']}
memo={}
def equal_closure(m,provider):
 if m=='Init':return True
 key=(m,id(provider))
 if key in memo:return memo[key]
 x=rows[m];y=provider.get(m);memo[key]=bool(y and x['source_sha256']==y['source_sha256']and x['imports']==y['imports']and all(equal_closure(d,provider)for d in x['imports']));return memo[key]
overrides={r['module']:r for r in mp['modules']};counts={};warnings={};reports={};ledger={}
assert {str(p.relative_to(O/'objects')).removesuffix('.olean').replace('/','.')for p in (O/'objects').rglob('*.olean')}==set(rows)
for m,row in rows.items():
 rec=done[m];assert rec['status']=='PASS'and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
 assert sha(row['source'])==row['source_sha256']==rec['source_sha256'];assert imports(row['source'])==row['imports']
 assert rec['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 obj=O/'objects'/(m.replace('.','/')+'.olean');source=O/'workspace'/(m.replace('.','/')+'.lean')
 assert sha(obj)==rec['object_sha256']and sha(source)==row['source_sha256']and sha(rec['log'])==rec['log_sha256']
 for p in obj.parents:
  assert not p.is_symlink()
  if p==O/'objects':break
 text=Path(rec['log']).read_text();assert not any(x in text for x in ['error:','sorryAx',"declaration uses 'sorry'"])
 rep=named(text);assert all(ax<={'propext','Classical.choice','Quot.sound'}for ax in profiles(rep))
 if 'reports'in rec:assert [list(r)for r in rep]==rec['reports']
 if 'warnings'in rec:assert rec['warnings']==text.count('warning:')
 p=overrides.get(m,{})
 if 'reports'in p:assert [n for n,_ in rep]==p['reports']and 'warning:'not in text
 if 'report_axioms'in p:assert profiles(rep)==[set(x)for x in p['report_axioms']]
 origin=rec['origin'];counts[origin]=counts.get(origin,0)+1;warnings[origin]=warnings.get(origin,0)+text.count('warning:');reports[origin]=reports.get(origin,0)+len(rep)
 if origin=='candidate_fresh':
  assert not obj.is_symlink();assert rec['command']==[str(C),'-j1','-M12288','--root='+str(O/'workspace'),'-o',str(obj),str(source)]
  assert rec['timeout_seconds']==(900 if 'KSites215Batch'in m else 120)and rec['memory_mebibytes']==12288
  assert rec['compiler_sha256']==sha(C)and rec['helper_sha256']==sha(H)
  assert read(Path(rec['log']).parent/'record.json')==rec;assert sha(Path(rec['log']).parent/source.name)==row['source_sha256']
 elif origin in ['phase12_primary_checked','phase12_compatibility_checked','secondary_checked']:
  if origin=='secondary_checked':parent=secondary;pr=secondaryrows;pd=secondarydir
  else:parent=old;pr=oldrows;pd=providers[m];assert origin==origins[m]and m not in forced
  assert {k:v for k,v in rec.items()if k!='origin'}=={k:v for k,v in parent[m].items()if k!='origin'};assert equal_closure(m,pr)
  assert obj.is_symlink()and obj.resolve()==(pd/'objects'/(m.replace('.','/')+'.olean')).resolve()
 else:raise AssertionError(origin)
 ledger[m]={'source_sha256':row['source_sha256'],'object_sha256':rec['object_sha256'],'log_sha256':rec['log_sha256'],'imports':row['imports'],'origin':origin}
for origin,field in [('candidate_fresh','fresh_modules'),('phase12_primary_checked','phase12_primary_reused_modules'),('phase12_compatibility_checked','phase12_compatibility_reused_modules'),('secondary_checked','secondary_reused_modules')]:assert result[field]==[m for m,r in done.items()if r['origin']==origin]
baselineaudits={r['module']:r for r in read(B/'result.json')['audits']}
if a.label=='primary-run1':
 assert counts=={'phase12_primary_checked':151,'candidate_fresh':36}and len(rows)==187
 assert set(result['fresh_modules'])==forced
 assert [r['module']for r in result['audits']]==['EndpointAudit215','K215Audit']
 for rec in result['audits']:
  name=rec['module'];d=O/('audit-'+name);source=d/(name+'.lean');obj=d/(name+'.olean');prior=baselineaudits[name]
  assert rec['status']=='PASS'and rec['exit_code']==0 and not rec['timed_out']
  assert sha(rec['source'])==sha(source)==rec['source_sha256']==prior['source_sha256'];assert sha(rec['log'])==rec['log_sha256']and sha(obj)==rec['object_sha256']
  assert rec['command']==[str(C),'-j1','-M12288','--root='+str(d),'-o',str(obj),str(source)]and rec['timeout_seconds']==120 and rec['memory_mebibytes']==12288
  assert rec['compiler_sha256']==sha(C)and rec['dependencies']=={m:r['object_sha256']for m,r in done.items()}
  text=Path(rec['log']).read_text();assert not any(x in text for x in ['warning:','error:','sorryAx'])
  rp=named(text);assert [list(x)for x in rp]==rec['named_reports'];assert [n for n,_ in rp]==[n for n,_ in prior['named_reports']];assert profiles(rp)==profiles(prior['named_reports'])
  assert read(d/(name+'.json'))==rec
 for m in rows:
  if 'KSites215Batch'in m:assert done[m]['object_sha256']==old[m]['object_sha256']and done[m]['log_sha256']==old[m]['log_sha256']
else:
 assert counts=={'secondary_checked':53,'phase12_compatibility_checked':1,'candidate_fresh':16}and len(rows)==70 and not result['audits']
 assert result['phase12_compatibility_reused_modules']==['BusyBeaver.ZFC.Dag254']
# Final rehash after examining all audit records; no earlier mutable check substitutes for this.
for p,h in before['inputs'].items():assert sha(p)==h,p
for m,r in done.items():assert sha(O/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']and sha(rows[m]['source'])==r['source_sha256']
for rec in result['audits']:
 d=O/('audit-'+rec['module']);assert sha(d/(rec['module']+'.olean'))==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
for p in before['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink()
receipt={'status':'PASS_INDEPENDENT_LIVE_SAVED_RECORD_AUDIT','run':str(O),'result_sha256':sha(O/'result.json'),'outer_sha256':sha(E/(a.label+'-outer.json')),'reviewer_sha256':sha(__file__),'before_sha256':sha(O/'before.json'),'inventory_sha256':sha(O/'inventory.json'),'completed_sha256':sha(O/'completed.json'),'source_freeze_sha256':sha(S/'freeze.json'),'provider_count':len(rows),'origins':counts,'warning_occurrences_by_origin':warnings,'report_occurrences_by_origin':reports,'endpoint_reports':sum(len(r['named_reports'])for r in result['audits']),'outer_exit_code':outer['exit_code'],'all_input_source_provider_log_dependency_machine_toolchain_bindings_checked':True,'reuse_requires_exact_transitive_source_imports':True,'retired_template_absences_checked':True,'ledger':ledger,'scope':'Independent read-only audit of current saved raw compiler/outer records and live source/object/log providers. No compiler or producer execution, no canonical mutation; not a fresh build of all providers.'}
a.output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='ledger'},indent=2))
