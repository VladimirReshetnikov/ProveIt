"""Make exact candidate plans from the held metadata census; no compiler imports."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):
 assert not p.exists(),p
 p.write_text(json.dumps(x,indent=2)+'\n')
allrows={r['module']:r for r in read(S/'plan1/candidate-map.json')['modules']}
old=read('/tmp/k215-phase13-upstream-check/primary-map.json')
for r in old['modules']:
 if r['module']in ['BusyBeaver.ZFC.DominatedImplication','BusyBeaver.ZFC.DomRho8','BusyBeaver.ZFC.KCodeDom']:
  p=R/'Computability/BusyBeaver/Lean'/(r['module'].replace('.','/')+'.lean')
  assert sha(p)==r['source_sha256']
  allrows[r['module']]={**r,'source':str(p),'before_sha256':r['source_sha256']}
summary=read(S/'plan1/census.json')
assert (summary['endpoint_project_modules'],summary['primary_project_modules'],summary['primary_providers'],summary['primary_fresh'],summary['primary_reuse'],summary['combined_project_modules'])==(178,183,190,66,124,198)
assert len(summary['compatibility_fresh_after_primary'])==16 and len(summary['compatibility_primary_reuse'])==53 and summary['compatibility_old_reuse']==['BusyBeaver.ZFC.Dag254']
assert summary['all_nine_site_batches_unaffected']and summary['retired_module_not_selected']
commands={}
for name in ['primary','compatibility']:
 inv=read(S/'plan1'/(name+'-inventory.json'));selected=[r['module']for r in inv['modules']]
 rows=[allrows[m]for m in selected if m in allrows]
 assert all(r.get('report_axioms',[])is not None for r in rows)
 expected={'modules':selected,'changed':inv['changed'],'forced':inv['forced']}
 result={'modules':rows,'expected':expected}
 filename=name+'-map.json' if name=='primary'else'compatibility-template.json'
 save(S/filename,result)
 command=['python3','-B',str(S/'build.py'),'--out',str(S/(name+'-run1')),'--map',str(S/(filename if name=='primary'else'compatibility-final-map.json'))]
 if name=='compatibility':command+=['--reuse',str(S/'primary-run1')]
 for t in inv['targets']:command+=['--target',t]
 if name=='primary':command+=['--audit-endpoint']
 commands[name]=command
save(S/'commands.json',{'status':'PROSPECTIVE_NOT_EXECUTED','primary':commands['primary'],'finalize_compatibility':['python3','-B',str(S/'finalize_compatibility.py'),'--primary',str(S/'primary-run1'),'--out',str(S/'compatibility-final-map.json')],'compatibility':commands['compatibility'],'must_wait':'No execution before frozen runner peer and explicit root authorization. Compatibility requires terminal primary PASS and reviewed final ledger pins.'})
save(S/'plan-summary.json',{**summary,'old_api_report_count':20,'new_api_report_count':14,'primary_endpoint_audits':2,'primary_endpoint_report_count':10,'compatibility_client_report_count':10,'unknown_initial_profiles':[r['module']for r in allrows.values()if'reports'in r and'report_axioms'not in r],'nine_site_batch_policy':'Source/import-transitive unchanged; reuse exact phase13 providers, no new site replay.'})
print(json.dumps({'status':'PLANS_PREPARED_NOT_EXECUTED','primary_map_sha256':sha(S/'primary-map.json'),'compatibility_template_sha256':sha(S/'compatibility-template.json'),'primary_count':190,'compatibility_count':70,'project_union':198},indent=2))
