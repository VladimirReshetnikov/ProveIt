"""Read-only selected source/provider/log binding; never invoke a proof compiler."""
from pathlib import Path
import hashlib,json,re
O=Path(__file__).resolve().parent;B=Path('/tmp/k215-phase9-zipbridge/routes-run2');R=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Lean')
P=Path('/tmp/k215-phase9-decoder-prefix/candidate/BusyBeaver/ZFC/KDecoderPrefix215.lean')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P)=='1decc006ee1783c39ba29269bc26bd59e85c998a94c220c0a587e0713c735a73'
result=json.loads((B/'result.json').read_text());ledger=json.loads((B/'completed.json').read_text());inv={m['module']:m for m in json.loads((B/'inventory.json').read_text())['modules']}
assert result['status']=='PASS' and result['new_component_modules']==6 and result['new_component_named_reports']==18
base='BusyBeaver.ZFC.';ns='SetTheory.BusyBeaver.ZFC.'
plans={'FramedWindow':['FramedWindow.arbitrary_tape_at'],'KZipTape':['KZipTape.'+x for x in['rel_step','rel_run','run_reflect','rel_full','check_restore','check_restore_pos']],'DecoderCertificate':['DecoderCertificate.'+x for x in['block_sound','all_blocks_sound','chain_sound']],'K215Decoder':['K215Decoder.'+x for x in['all_blocks_checked','structure_checked','restores_arbitrary_tape']],'DecoderPaths':['K215SourcePaths.'+x for x in['semantic_edges','reaches_primitive']],'DecoderSourceBinding':['DecoderSourceBinding.'+x for x in['source_tree_eq','upstream_leaf_reaches','upstream_walk_reaches']]}
selected={};providers={}
for n,names in plans.items():
 m=base+n;r=ledger[m];src=Path(r['source']);candidate=Path(r['candidate']);log=Path(r['log']);obj=B/'objects'/(m.replace('.','/')+'.olean')
 assert r['status']=='PASS' and r['exit_code']==0 and not r['timed_out']
 assert sha(src)==sha(candidate)==r['source_sha256']==inv[m]['source_sha256']
 assert sha(log)==r['log_sha256'] and sha(obj)==r['object_sha256']
 text=log.read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
 assert[n for n,a in reports]==[ns+n for n in names]
 assert all({x.strip()for x in a.split(',')if x.strip()}<={'propext','Classical.choice','Quot.sound'}for n,a in reports)
 assert 'warning:'not in text
 assert set(r['dependencies'])=={x for x in inv[m]['imports']if x.startswith('BusyBeaver.')}
 for d,h in r['dependencies'].items():
  assert h==ledger[d]['object_sha256']==sha(B/'objects'/(d.replace('.','/')+'.olean'));providers[d]=h
 selected[m]={'source':str(src),'source_sha256':sha(src),'candidate':str(candidate),'object_sha256':sha(obj),'log':str(log),'log_sha256':sha(log),'origin':r['origin'],'reports':reports,'dependencies':r['dependencies']}
old=Path('/tmp/k215-phase9-decoder-routes/formal-table/candidate/BusyBeaver/ZFC/DecoderPaths.lean').read_text();new=Path(ledger[base+'DecoderPaths']['source']).read_text()
assert new==re.sub(r'\bprefix\b','pre',old)
imports=re.findall(r'^import (\S+)',P.read_text(),re.M)
assert imports==[base+'DecoderSourceBinding',base+'KZipTape',base+'KSim',base+'KDenseBridge']
direct={}
for m in imports:
 r=ledger[m];obj=B/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==r['object_sha256']
 source=Path(inv[m]['source']);assert sha(source)==r['source_sha256']
 direct[m]={'object_sha256':sha(obj),'source':str(source),'source_sha256':sha(source)}
r={'status':'PASS_SELECTED_EXISTING_COMPONENT_BINDINGS','candidate':{'path':str(P),'sha256':sha(P),'bytes':P.stat().st_size},'candidate_compiled_by_this_review':False,'prior_six_checked_modules':selected,'direct_candidate_providers':direct,'additional_direct_dependency_objects':providers,'existing_result_sha256':sha(B/'result.json'),'completed_sha256':sha(B/'completed.json'),'inventory_sha256':sha(B/'inventory.json'),'route_successor_only_prefix_binder_rename':True,'scope':'Read-only six prior component source/candidate/object/log/status/named-report and direct-dependency checks. Seventh module is a source-only mathematical peer; no new compiler invocation or whole194-provider/toolchain audit.'}
(O/'bindings.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'modules':len(selected),'prior_named_reports':sum(len(v['reports'])for v in selected.values()),'candidate_sha256':sha(P)},indent=2))
