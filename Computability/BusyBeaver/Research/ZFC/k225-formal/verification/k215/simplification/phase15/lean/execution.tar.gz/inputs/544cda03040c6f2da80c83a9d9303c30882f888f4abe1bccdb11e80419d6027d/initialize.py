"""Resume only193 validated PASS providers; the original primary run remains failed."""
from pathlib import Path
import ast,hashlib,json,sys
R=Path('/tmp/k215-phase15-check');S=Path(__file__).resolve().parent;old=R/'primary-run2';out=R/'primary-run3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
save=lambda p,x:Path(p).write_text(json.dumps(x,indent=2)+'\n')
freeze=read(S/'freeze.json')
for p,h in freeze['files'].items():assert sha(S/p)==h,p
for p,h in freeze['external_inputs'].items():assert sha(p)==h,p
for p,h in read(R/'freeze.json')['files'].items():assert sha(R/p)==h,p
prior_retry=Path('/tmp/k215-phase15-retry')
for p,h in read(prior_retry/'freeze.json')['files'].items():assert sha(prior_retry/p)==h,p
assert not out.exists()and not(old/'result.json').exists()
before=read(old/'before.json');inv=read(old/'inventory.json');done=read(old/'completed.json')
assert len(inv['modules'])==194 and len(done)==193
assert set(done)=={r['module']for r in inv['modules'][:193]}
assert inv['modules'][193]['module']=='QuotientSharing15Api'
assert sum(r['origin']=='candidate_fresh'for r in done.values())==44
assert sum(r['origin']=='phase14_primary_checked'for r in done.values())==149
for p,h in before['inputs'].items():assert sha(p)==h,p
for p in before['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink()
failed=read(old/'attempts/026-QuotientSharing15Api/record.json')
assert failed['status']=='FAIL'and failed['exit_code']!=0 and read('/tmp/k215-phase15-execution/primary-run2-outer.json')['exit_code']==1
# Execute the already reviewed runner's metadata setup, stopping before its first
# compiler loop. This creates precisely the owner that an ordinary retry expects.
build=R/'build.py';tree=ast.parse(build.read_text())
i=next(i for i,n in enumerate(tree.body)if isinstance(n,ast.For)and isinstance(n.target,ast.Name)and n.target.id=='row'and isinstance(n.iter,ast.Name)and n.iter.id=='rows')
prefix=ast.Module(body=tree.body[:i],type_ignores=[])
assert not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='run_locked'for n in ast.walk(prefix))
argv=read(S/'commands.json')['primary'];assert argv[2]==str(build)
ns={'__name__':'__metadata_resume_only__','__file__':str(build)};saved_argv=sys.argv
try:
 sys.argv=argv[2:];exec(compile(ast.fix_missing_locations(prefix),str(build),'exec'),ns)
finally:sys.argv=saved_argv
assert ns['done']=={}and ns['out']==out
current={r['module']:r for r in ns['rows']};prior={r['module']:r for r in inv['modules']}
for m in done:
 assert current[m]==prior[m],m
 r=done[m];assert ns['log_policy'](current[m],r)
 assert r['source_sha256']==current[m]['source_sha256']and sha(current[m]['source'])==r['source_sha256']
 assert r['dependencies']=={d:done[d]['object_sha256']for d in current[m]['imports']if d!='Init'}
 assert sha(r['log'])==r['log_sha256']
 if r['origin']=='candidate_fresh':assert sha(r['source'])==r['source_sha256']
 source=old/'objects'/(m.replace('.','/')+'.olean');assert sha(source)==r['object_sha256']
 target=out/'objects'/(m.replace('.','/')+'.olean');target.parent.mkdir(parents=True,exist_ok=True)
 for parent in target.parents:
  assert not parent.is_symlink()
  if parent==out:break
 assert not target.exists()and not target.is_symlink();target.symlink_to(source)
 assert sha(target)==r['object_sha256']
save(out/'completed.json',done)
for p,h in before['inputs'].items():assert sha(p)==h,p
for p,h in ns['inputs'].items():assert sha(p)==h,p
assert not(out/'objects/QuotientSharing15Api.olean').exists()and not(out/'objects/QuotientSharing15Api.olean').is_symlink()
record={'status':'VALIDATED_PARTIAL_PROVIDER_RESUME_NOT_PRIMARY_PASS','original_primary_status':'FAILED_CLIENT_NAMESPACE_OPENINGS','original_result_absent':True,'failed_module_excluded':'QuotientSharing15Api','resumed_providers':193,'prior_successful_fresh_invocations':44,'run1_successful_fresh':19,'run2_successful_fresh':25,'prior_phase14_reused_providers':149,'new_fresh_module_calls_still_required':1,'new_endpoint_audits_still_required':2,'original_before_sha256':sha(old/'before.json'),'original_inventory_sha256':sha(old/'inventory.json'),'original_completed_sha256':sha(old/'completed.json'),'new_before_sha256':sha(out/'before.json'),'new_inventory_sha256':sha(out/'inventory.json'),'new_completed_sha256':sha(out/'completed.json'),'new_map_sha256':sha(S/'primary-map.json'),'runner_unchanged_sha256':sha(build),'initializer_sha256':sha(__file__),'compiler_invoked':False}
save(S/'initialization-result.json',record);print(json.dumps(record,indent=2))
