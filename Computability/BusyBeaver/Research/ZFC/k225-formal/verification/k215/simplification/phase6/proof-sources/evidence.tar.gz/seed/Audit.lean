
namespace SetTheory.BusyBeaver.ZFC.SeedSemanticAudit
open Tarski Code254 KCode222
open KSeed222 KThmK
universe u
theorem same_endpoint {V : Type u} (mem : V → V → Prop) (hirr : ∀ x, ¬ mem x x)
    (hT : ∀ f, DerivableNF f → ∀ e : Nat → V, Tarski.Sat mem e f)
    (ψ : NF) (hψ : EqFree ψ) (e : Nat → V) :
    SeedProp mem (fun x y => Tarski.Sat mem (update (update e 0 x) 1 y) ψ) (e 0) :=
  seed_eqFree mem hirr hT ψ hψ e
#print axioms same_endpoint
#print axioms KSeed222.derivable_named_bundle
end SetTheory.BusyBeaver.ZFC.SeedSemanticAudit
