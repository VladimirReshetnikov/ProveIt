"""Adapt Source168's preserved checker to the maintained decoder-parametric API."""
from pathlib import Path
import hashlib,json,difflib
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');P=Path(__file__).resolve().parent
up=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/proposals/k215-simplification/source_normalization'
old=(up/'RMNormalizedBisim.lean').read_text(); (P/'RMNormalizedBisim.original.lean').write_text(old)
(P/'NOTICE.original.md').write_bytes((up/'NOTICE.md').read_bytes())
prefix,rest=old.split('def decodeLong (n : Nat) : List Bool := decodeAux 512 n []\n\n',1)
body=rest[:rest.index('#print axioms')]
a=body.index('def getc');b=body.index('/-- Saturation',a)
body=body[:a]+'abbrev getc := RMBisim.WithDecoder.getc decode\n\n'+body[b:]
body=body.replace('decodeLong','decode')
for a,b in [('getc T','getc decode T'),('Rel T','Rel decode T'),('branchOk t1','branchOk decode t1'),('branchOk (ptree','branchOk decode (ptree'),('entryOk t1','entryOk decode t1'),('entryOk (ptree','entryOk decode (ptree'),('branchOk_good hs','branchOk_good decode hs'),('branchOk_good hj','branchOk_good decode hj'),('branchOk_good hk','branchOk_good decode hk'),('entryOk_good (x','entryOk_good decode (x'),('(check_bisim hs ha)','(check_bisim decode hs ha)'),('unfold getc at hj','unfold getc RMBisim.WithDecoder.getc at hj')]:body=body.replace(a,b)
prefix=prefix.replace('Long pointers use 512 decoding steps, as in RMOffsetBisim. No offset is needed\nfor the pinned K215 source certificate: all its offsets are zero.','The generic checker accepts any decoder, reusing RMBisim.WithDecoder.getc.\nIts soundness needs no numerical bound or injectivity assumption. The original\npublic facade explicitly uses 512 steps for K215; RMBisim.decode stays at128.\n\nAdapted from Source168 / batch205A RMNormalizedBisim.lean, preserved with its\nNOTICE. The normalized relation and proof originate in that contribution.\nThis adaptation only factors the decoder and reuses the maintained lookup.\nConsumed paths remain intact before incPath and breakPath are applied.')
facade='''end WithDecoder

/-- K215's explicit long-pointer instance; the inherited default is unchanged. -/
def decodeLong (n : Nat) : List Bool := decodeAux 512 n []

abbrev getc := WithDecoder.getc decodeLong
abbrev Rel := WithDecoder.Rel decodeLong
abbrev branchOk := WithDecoder.branchOk decodeLong
abbrev entryOk := WithDecoder.entryOk decodeLong

theorem branchOk_good {t1 t2 : Tree} {T : CTree} {A B : List Bool} {j : Nat}
    (h : branchOk t1 t2 T A B j = true) : BranchGood t1 t2 (Rel T) A B :=
  WithDecoder.branchOk_good decodeLong h

theorem entryOk_good {t1 t2 : Tree} {T : CTree} {x : Entry}
    (h : entryOk t1 t2 T x = true) :
    EntryGood t1 t2 (Rel T) (decodeLong x.1) (decodeLong x.2.1) :=
  WithDecoder.entryOk_good decodeLong h

theorem check_bisim {p1 p2 : Program} {T : CTree}
    (hs : branchOk (ptree p1) (ptree p2) T [] [] 0 = true)
    (ha : allC (entryOk (ptree p1) (ptree p2) T) T = true) :
    Bisim (ptree p1) (ptree p2) (Rel T) :=
  WithDecoder.check_bisim decodeLong hs ha

/-- The original all-program, all-register public theorem, using512 decoding. -/
theorem check_halts_iff {p1 p2 : Program} {T : CTree}
    (hs : branchOk (ptree p1) (ptree p2) T [] [] 0 = true)
    (ha : allC (entryOk (ptree p1) (ptree p2) T) T = true) (R : Registers) :
    Halts p1 ⟨[], R⟩ ↔ Halts p2 ⟨[], R⟩ :=
  WithDecoder.check_halts_iff decodeLong hs ha R

end SetTheory.BusyBeaver.ZFC.RMNormalizedBisim
'''
s=prefix+'/-! The decoder changes only which finite paths an entry denotes. -/\nnamespace WithDecoder\n\nvariable (decode : Nat → List Bool)\n\n'+body+facade
s=s.replace('at128','at 128').replace('using512','using 512')
(P/'RMNormalizedBisim.lean').write_text(s)
(P/'source.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='Source168/RMNormalizedBisim.lean',tofile='candidate/RMNormalizedBisim.lean')))
pins={str(x):hashlib.sha256(x.read_bytes()).hexdigest()for x in [up/'RMNormalizedBisim.lean',up/'NOTICE.md',R/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/RMBisim.lean',R/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/RMEquiv.lean']}
(P/'preparation.json').write_text(json.dumps({'status':'PREPARED_UNCOMPILED','input_pins':pins,'original_bytes':len(old.encode()),'candidate_bytes':len(s.encode()),'original_lines':len(old.splitlines()),'candidate_lines':len(s.splitlines()),'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'New module only; no canonical or inherited API edit. No concrete K215 certificate or endpoint migration.'},indent=2)+'\n')
