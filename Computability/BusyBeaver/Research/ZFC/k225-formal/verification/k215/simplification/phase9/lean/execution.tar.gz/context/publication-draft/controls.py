"""Small pure metadata controls. No compiler, full-run capture or object inspection."""
from pathlib import Path
from copy import deepcopy
import json
from evidence import check_origins, graph, imports, reports, safe_name, save, sha, source_scope
HERE=Path(__file__).resolve().parent
results=[]
def yes(name,fn):fn();results.append({'name':name,'status':'PASS'})
def no(name,fn):
    try:fn()
    except (AssertionError,KeyError):results.append({'name':name,'status':'EXPECTED_REJECTION'})
    else:raise AssertionError('Negative control accepted: '+name)
read=lambda p:json.loads(Path(p).read_text())

def main():
    # These are frozen input inventories, not evidence of completion of run2.
    inv=read('/tmp/k215-phase9-main/full-run1/inventory.json')
    old={r['module']:r for r in read('/tmp/k215-proof-phase8/lean-run1/inventory.json')['modules']}
    iso={r['module']:r for r in read('/tmp/k215-phase9-main/isolated-run2/inventory.json')['modules']}
    entries,closures=graph(inv['modules'],inv['targets'])
    changed,forced,iso_ok=source_scope(entries,closures,old,iso)
    assert len(changed)==11 and len(forced)==26 and len(forced-iso_ok)==20
    dummy={m:{'origin':'phase9_fresh'if m in forced-iso_ok else 'isolated_checked'if m in iso_ok else 'phase8_checked'}for m in entries}
    yes('valid synthetic source-transitive origin assignment',lambda:check_origins(dummy,forced,iso_ok))
    no('actual qualified full-run1 rejected despite same-object intermediaries',
       lambda:check_origins(read('/tmp/k215-phase9-main/full-run1/completed.json'),forced,iso_ok))
    site=next(m for m in entries if 'KSites215Batch'in m)
    def wrong_origin(origin):
        bad=deepcopy(dummy);bad[site]['origin']=origin;check_origins(bad,forced,iso_ok)
    no('affected site cannot reuse phase8',lambda:wrong_origin('phase8_checked'))
    no('affected site cannot invent isolated compatibility',lambda:wrong_origin('isolated_checked'))
    no('unknown provider origin',lambda:wrong_origin('trusted'))
    no('missing affected provider',lambda:check_origins({m:r for m,r in dummy.items()if m!=site},forced,iso_ok))
    yes('ordinary source member',lambda:safe_name('execution/sources/BusyBeaver/ZFC/KHome.lean'))
    for bad in ('../escape','/absolute','x.olean','x.olean.server','x.olean.private','x.pyc','x.pyo','x.vo','x.o','x.tar.gz','x.zip'):
        no('reject member '+bad,lambda bad=bad:safe_name(bad))
    yes('standard axiom report',lambda:reports(b"'Example.ok' depends on axioms: [propext, Quot.sound]\n"))
    no('custom axiom report',lambda:reports(b"'Example.bad' depends on axioms: [custom]\n"))
    no('sorry report',lambda:reports(b"'Example.bad' depends on axioms: [sorryAx]\n"))
    no('failed compiler log',lambda:reports(b'error: rejected\n'))
    yes('nested comments cannot introduce imports',lambda:assert_imports())
    bad=deepcopy(inv['modules']);bad[0]['imports']=['BusyBeaver.ZFC.KEndpoint215']
    no('forward/cyclic dependency',lambda:graph(bad,inv['targets']))
    result={'status':'PASS_METADATA_CONTROLS_ONLY','compiler_invoked':False,'full_run_capture_invoked':False,
            'positive':sum(r['status']=='PASS'for r in results),'negative':sum(r['status']=='EXPECTED_REJECTION'for r in results),
            'source_changed':11,'affected':26,'required_fresh':20,'controls':results,
            'controls_sha256':sha(__file__),'validator_sha256':sha(HERE/'evidence.py')}
    save(HERE/'controls-result.json',result);print(json.dumps(result,indent=2))

def assert_imports():
    assert imports(b'/- outer /- import False -/ -/\nimport Init\n-- import False\ndef x := "import False"\n')==['Init']

if __name__=='__main__':main()
