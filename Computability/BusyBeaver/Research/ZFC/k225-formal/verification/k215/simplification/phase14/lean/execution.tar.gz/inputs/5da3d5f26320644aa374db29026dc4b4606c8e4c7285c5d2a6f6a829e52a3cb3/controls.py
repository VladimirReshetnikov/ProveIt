"""Exercise exact runner AST fragments with pure metadata and disposable text logs."""
from pathlib import Path
import ast,copy,hashlib,json,re,tempfile
S=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
tree=ast.parse((S/'build.py').read_text());positive=[];negative=[]
def target(n,name):return isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets)
i=next(i for i,n in enumerate(tree.body)if target(n,'changed'))
forcing=tree.body[i:i+3];assert target(forcing[1],'forced')and isinstance(forcing[2],ast.While)
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
def fragment(nodes,ns):
 exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'runner-metadata-fragment','exec'),ns)
 return ns
def force(current,old):
 ns=fragment(forcing,{'entry_by_name':current,'old':old,'old_entries':old});return ns['changed'],ns['forced']
old={'A':{'source_sha256':'a','imports':['Init']},'B':{'source_sha256':'b','imports':['A']},'C':{'source_sha256':'c','imports':['B']}}
assert force(old,old)==(set(),set());positive.append('unchanged source/import graph permits basis reuse')
changed=copy.deepcopy(old);changed['A']['source_sha256']='new-a'
assert force(changed,old)==({'A'},set(old));positive.append('changed ancestor forces every descendant')
imports=copy.deepcopy(old);imports['B']['imports']=[]
assert force(imports,old)==({'B'},{'B','C'});positive.append('import-only ancestor change forces descendant')
# Identical intermediate objects are intentionally absent from the source rule.
objects={'A':'new-object','B':'identical-object','C':'identical-object'}
assert objects['B']==objects['C']and'C'in force(changed,old)[1];negative.append('byte-identical intermediate object cannot mask changed ancestor')
def compatible(current,prior,m):
 ns=fragment([functions['same_transitive_sources']],{'entry_by_name':current,'reuse_rows':prior,'compatible':{}})
 return ns['same_transitive_sources'](m)
assert compatible(old,old,'C');positive.append('exact secondary transitive source graph accepted')
for name,prior in [('ancestor source mismatch',changed),('ancestor import mismatch',imports),('missing ancestor',{k:v for k,v in old.items()if k!='A'})]:
 assert not compatible(old,prior,'C');negative.append('secondary reuse rejects '+name)
baseline=read('/tmp/k215-phase13-upstream-check/primary-run1/result.json')
ep=fragment([functions['exact_endpoint_profile']],{'baseline':baseline})['exact_endpoint_profile']
for row in baseline['audits']:assert ep(row['module'],row['named_reports'])
positive.append('both exact phase13 endpoint profiles accepted')
reports=copy.deepcopy(baseline['audits'][1]['named_reports']);reports[2][1]='propext, Quot.sound'
assert not ep('K215Audit',reports);negative.append('standard-only but changed endpoint profile rejected')
reports=copy.deepcopy(baseline['audits'][0]['named_reports']);reports[0][0]='wrong.name'
assert not ep('EndpointAudit215',reports);negative.append('changed endpoint report name rejected')
profiles={r['module']:r for r in read(S/'compatibility-template.json')['modules']}
with tempfile.TemporaryDirectory(prefix='phase14-metadata-')as directory:
 p=Path(directory)/'log.txt';record={'status':'PASS','exit_code':0,'timed_out':False,'log':str(p)}
 ns=fragment([functions['log_policy']],{'Path':Path,'re':re,'overrides':profiles})
 policy=ns['log_policy'];row={'module':'ZFNativeCompat12'};cfg=profiles[row['module']]
 def text(axioms):return '\n'.join("'%s' depends on axioms: [%s]"%(n,', '.join(ax))for n,ax in zip(cfg['reports'],axioms))+'\n'
 p.write_text(text(cfg['report_axioms']));assert policy(row,record);positive.append('ZF compatibility models PQ and six standard profiles accepted')
 for name,mutate in [('extra choice in models',lambda a:a[0].append('Classical.choice')),('missing axiom',lambda a:a[1].remove('Quot.sound')),('forbidden sorryAx',lambda a:a[0].append('sorryAx'))]:
  ax=copy.deepcopy(cfg['report_axioms']);mutate(ax);p.write_text(text(ax));assert not policy(row,record);negative.append('exact compatibility profile rejects '+name)
 p.write_text(text(cfg['report_axioms'])+'warning: unexpected\n');assert not policy(row,record);negative.append('typed client warning rejected')
 p.write_text(text(cfg['report_axioms']));assert not policy(row,{**record,'timed_out':True});negative.append('timed-out provider rejected')
 new={r['module']:r for r in read(S/'primary-map.json')['modules']};ns['overrides']=new
 c=new['DerivedRows14Api'];p.write_text('\n'.join("'%s' does not depend on any axioms"%n for n in c['reports']))
 assert policy({'module':'DerivedRows14Api'},record);positive.append('new client names accepted without inventing prospective exact profiles')
 p.write_text("'wrong' does not depend on any axioms\n");assert not policy({'module':'DerivedRows14Api'},record);negative.append('new client wrong names rejected')
# Syntax checks over exact runtime text retain the retirement and unlink gates.
text=(S/'build.py').read_text();assert "assert m not in retired_modules"in text
assert "obj.unlink(missing_ok=True)"in text and "assert not parent.is_symlink()"in text
assert "timeout=900 if 'KSites215Batch'in m else 120"in text and "'-M12288'"in text
result={'status':'PASS_OWN_PURE_METADATA_CONTROLS','runner_sha256':sha(S/'build.py'),'controls_sha256':sha(__file__),'positive':positive,'negative':negative,'positive_count':len(positive),'negative_count':len(negative),'scope':'Executed selected own runner AST functions only with dictionaries and temporary text logs. No runner import, proof compiler, producer, canonical write, or proof-result claim.'}
out=S/'controls-result.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
