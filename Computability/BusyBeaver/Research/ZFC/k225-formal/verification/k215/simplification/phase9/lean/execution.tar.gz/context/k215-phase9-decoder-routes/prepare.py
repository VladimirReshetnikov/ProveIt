"""Own source-only adaptation. Does not invoke a proof tool or delivery code."""
from pathlib import Path
import json,hashlib,difflib
R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
P=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/proposals/composition-address-bounds/decoder_source_paths'
O=Path(__file__).resolve().parent; C=O/'candidate/BusyBeaver/ZFC'
def sha(b):return hashlib.sha256(b).hexdigest()
def port(s):
 for n in ['FramedWindow','DecoderCertificate','K215Decoder','DecoderPaths']:
  s=s.replace('import '+n+'\n','import BusyBeaver.ZFC.'+n+'\n')
 for n in ['DecoderCertificate','K215Decoder','DecoderPaths','K215SourcePaths','DecoderSourceBinding']:
  s=s.replace('namespace '+n+'\n','namespace SetTheory.BusyBeaver.ZFC.'+n+'\n')
  s=s.replace('end '+n+'\n','end SetTheory.BusyBeaver.ZFC.'+n+'\n')
 return s
s=(P/'DecoderPaths.lean').read_text()
insert='''/-- Exact accepted prefix language of the role graph.  A state or two-bit
suffix alone is not a sufficient primitive/return context. -/
inductive RolePath (roles : Array Role) : Nat → List Bool → Nat → Prop
  | nil (rid : Nat) : RolePath roles rid [] rid
  | cons {rid : Nat} {r : Role} {bit : Bool} {next block : Nat}
      {prefix : List Bool} {last : Nat}
      (roleAt : roles[rid]? = some r)
      (edge : (if bit then r.one else r.zero) = .internal next block)
      (tail : RolePath roles next prefix last) :
      RolePath roles rid (bit :: prefix) last

/-- Entry retains the consumed prefix and its exact role route, so primitive
contracts may quantify the whole continuation rather than only its suffix. -/
def RoutedEntry (M : Table) (nodes : Array Node) (roles : Array Role)
    (first : Nat) (word : List Bool) (q : Nat) (bit : Bool) (op arg : Nat) : Prop :=
  ∃ (prefix : List Bool) (rid : Nat) (r : Role) (n : Nat) (action : Action),
    word = prefix ++ [bit] ∧ RolePath roles first prefix rid ∧
    roles[rid]? = some r ∧ r.state = q ∧
    (if bit then r.one else r.zero) = .primitive n action ∧
    nodes[n]? = some (.leaf op arg) ∧ M q bit = some action

theorem RoutedEntry.forget {M : Table} {nodes : Array Node} {roles : Array Role}
    {first : Nat} {word : List Bool} {q : Nat} {bit : Bool} {op arg : Nat}
    (h : RoutedEntry M nodes roles first word q bit op arg) :
    Entry M nodes roles q bit op arg := by
  obtain ⟨_, rid, r, n, action, _, _, hr, hq, he, hn, hm⟩ := h
  exact ⟨rid, r, n, action, hr, hq, he, hn, hm⟩

'''
needle='/-- Source-path traversal creates all window witnesses required by `Chain`.'
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
a=s.index('theorem source_path_chain\n');b=s.index('/-- Every certified source path',a)
original=s[a:b];strong=original.replace('theorem source_path_chain\n','theorem source_path_chain_routed\n',1)
strong=strong.replace('= bit ∧ Entry M nodes roles q bit op arg := by','= bit ∧ RoutedEntry M nodes roles rid w q bit op arg := by',1)
needle='exact ⟨rid,r,n,action,hr,rfl,hedge,heq ▸ hc,hg.2.2⟩'
assert strong.count(needle)==1;strong=strong.replace(needle,'exact ⟨[],rid,r,n,action,rfl,RolePath.nil rid,hr,rfl,hedge,heq ▸ hc,hg.2.2⟩')
needle='''              refine ⟨b.steps+steps,q,last,?_,?_,hend⟩
              · simpa only [hentry,hpos] using hmore
              · simpa only [hpos] using ht
'''
assert strong.count(needle)==1
strong=strong.replace(needle,'''              refine ⟨b.steps+steps,q,last,?_,?_,?_⟩
              · simpa only [hentry,hpos] using hmore
              · simpa only [hpos] using ht
              · obtain ⟨prefix,final,s',leaf,action,hsplit,hroute,hat,hstate,he',hleaf,hrow⟩ := hend
                refine ⟨bit::prefix,final,s',leaf,action,?_,RolePath.cons hr hedge hroute,
                  hat,hstate,he',hleaf,hrow⟩
                simp only [hsplit, List.cons_append]
''')
header=original.split(' := by\n',1)[0]
wrapper=header+''' := by
  intro rid r hr he a t hs hw
  obtain ⟨steps,q,bit,hchain,ht,hend⟩ :=
    source_path_chain_routed M nodes roles blocks good checked path rid r hr he a t hs hw
  exact ⟨steps,q,bit,hchain,ht,hend.forget⟩

'''
s=s[:a]+strong+wrapper+s[b:]
a=s.index('theorem reaches_primitive ');b=s.index('\n#print axioms semantic_edges',a)
original=s[a:b];strong=original.replace('theorem reaches_primitive ','theorem reaches_primitive_routed ',1)
strong=strong.replace('= bit ∧ Entry native sourceNodes roles q bit op arg := by','= bit ∧ RoutedEntry native sourceNodes roles 0 w q bit op arg := by',1)
strong=strong.replace('source_path_chain native','source_path_chain_routed native',1)
header=original.split(' := by\n',1)[0]
wrapper=header+''' := by
  obtain ⟨steps,q,bit,lo,hi,hr,hbit,hentry⟩ := reaches_primitive_routed path a t marker word
  exact ⟨steps,q,bit,lo,hi,hr,hbit,hentry.forget⟩
'''
s=s[:a]+strong+'\n\n'+wrapper+s[b:]
# Rebase the source binding onto the stable current program module.
t=(P/'DecoderSourceBinding.lean').read_text().replace('import BusyBeaver.ZFC.KSource215Data','import BusyBeaver.ZFC.KSource215Program')
a=t.index('theorem upstream_leaf_reaches ');b=t.index('/-- The repository walk',a)
original=t[a:b];strong=original.replace('theorem upstream_leaf_reaches ','theorem upstream_leaf_reaches_routed ',1)
strong=strong.replace('DecoderPaths.Entry native sourceNodes roles q bit op arg','DecoderPaths.RoutedEntry native sourceNodes roles 0 w q bit op arg')
strong=strong.replace('K215SourcePaths.reaches_primitive hp','K215SourcePaths.reaches_primitive_routed hp')
header=original.split(' := by\n',1)[0]
wrapper=header+''' := by
  obtain ⟨op,arg,steps,q,bit,he,lo,hi,hr,hbit,hentry⟩ :=
    upstream_leaf_reaches_routed leaf a t marker word
  exact ⟨op,arg,steps,q,bit,he,lo,hi,hr,hbit,hentry.forget⟩

'''
t=t[:a]+strong+wrapper+t[b:]
a=t.index('theorem upstream_walk_reaches ');b=t.index('\n#print axioms source_tree_eq',a)
original=t[a:b];strong=original.replace('theorem upstream_walk_reaches ','theorem upstream_walk_reaches_routed ',1)
strong=strong.replace('DecoderPaths.Entry native sourceNodes roles q bit op arg','DecoderPaths.RoutedEntry native sourceNodes roles 0 (consume P d) q bit op arg')
strong=strong.replace('upstream_leaf_reaches hleaf','upstream_leaf_reaches_routed hleaf')
header=original.split(' := by\n',1)[0]
wrapper=header+''' := by
  obtain ⟨op,arg,steps,q,bit,he,lo,hi,hr,hbit,hentry⟩ :=
    upstream_walk_reaches_routed P e d walks a t marker word
  exact ⟨op,arg,steps,q,bit,he,lo,hi,hr,hbit,hentry.forget⟩
'''
t=t[:a]+strong+'\n\n'+wrapper+t[b:]
outputs={'DecoderCertificate.lean':(P/'DecoderCertificate.lean').read_text(),'K215Decoder.lean':(P/'K215Decoder.lean').read_text(),'DecoderPaths.lean':s,'DecoderSourceBinding.lean':t}
records=[]
for n,s in outputs.items():
 raw=(P/n).read_bytes();new=port(s).encode();(C/n).write_bytes(new)
 (O/(n+'.diff')).write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True),new.decode().splitlines(True),fromfile='submitted/'+n,tofile='candidate/'+n)))
 records.append({'source':str(P/n),'source_sha256':sha(raw),'source_bytes':len(raw),'candidate':str(C/n),'candidate_sha256':sha(new),'candidate_bytes':len(new),'candidate_lines':len(new.splitlines())})
(O/'preparation.json').write_text(json.dumps({'status':'SCRATCH_UNCOMPILED_SOURCE_CANDIDATE','files':records,'shared_framed_window':'/tmp/k215-phase9-zipbridge/candidate/BusyBeaver/ZFC/FramedWindow.lean','canonical_mutations':[],'compiler_invocations':[]},indent=2)+'\n')
print(json.dumps(records,indent=2))
