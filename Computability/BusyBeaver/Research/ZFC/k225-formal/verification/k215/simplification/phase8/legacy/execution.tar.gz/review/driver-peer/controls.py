"""Peer metadata controls; no driver/compiler/candidate execution."""
from pathlib import Path
import copy,hashlib,importlib.util,json,tempfile
P=Path('/tmp/k215-phase8-legacy');O=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert h(P/'gates.py')=='acfaa7fd31e0a1858ee4479edbf15f6171ab889f4b1eb8656d29851bbc3ab859'
spec=importlib.util.spec_from_file_location('peer_phase8_legacy_gates',P/'gates.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
old=json.loads(Path('/tmp/k215-proof-phase7/lean-run1/inventory.json').read_text());new=json.loads(Path('/tmp/k215-proof-phase8/prospective-inventory.json').read_text());legacy=json.loads(Path('/tmp/k215-phase7-legacy/run1/inventory.json').read_text());approved=json.loads((P/'preparation.json').read_text())['approved_sources']
rows=[]
def test(name,fn,reject=False):
 try:fn()
 except AssertionError:assert reject,name
 else:assert not reject,name
 rows.append({'name':name,'expected':'reject'if reject else'accept','status':'PASS'})
def bad(name,mutate):
 n,l,a=copy.deepcopy(new),copy.deepcopy(legacy),copy.deepcopy(approved);mutate(n,l,a)
 test(name,lambda:g.checkpoint(old,n,l,a),True)
test('exact_prospective203_union',lambda:g.checkpoint(old,new,legacy,approved))
bad('missing_new_core',lambda n,l,a:n['modules'].pop(next(i for i,x in enumerate(n['modules'])if x['module']==g.NEW)))
bad('duplicate_primary_module',lambda n,l,a:n['modules'].append(copy.deepcopy(n['modules'][0])))
bad('wrong_target',lambda n,l,a:n.update(target='BusyBeaver.ZFC.KEndpoint'))
bad('new_external_module',lambda n,l,a:n['external_imports'].append('Mathlib'))
bad('unapproved_source_change',lambda n,l,a:n['modules'][0].update(source_sha256='f'*64))
bad('unapproved_import_change',lambda n,l,a:n['modules'][0]['imports'].append('Init'))
bad('wrong_registered_source',lambda n,l,a:a[g.NEW].update(source_sha256='e'*64))
bad('extra_approved_change',lambda n,l,a:a.update({'extra':{}}))
bad('source_location_change',lambda n,l,a:n['modules'][0].update(source='/tmp/elsewhere'))
bad('legacy_module_missing',lambda n,l,a:l['modules'].pop(next(i for i,x in enumerate(l['modules'])if x['module']in g.EXTRA)))
bad('legacy_forward_reference',lambda n,l,a:next(x for x in l['modules']if x['module']in g.EXTRA)['imports'].append('Unknown.Later'))
review={'status':'PASS_ROOT_READ_ONLY_BINDINGS','result_sha256':'a'*64,'current_modules':188,'predecessor_modules':187,'typed_audits':2,'axiom_reports':10,'exact_machine_inputs_unchanged':True}
test('primary_root_review',lambda:g.primary_review(review,'a'*64))
for field,value in [('status','PENDING'),('current_modules',187),('predecessor_modules',188),('axiom_reports',5),('typed_audits',1),('exact_machine_inputs_unchanged',False),('result_sha256','b'*64)]:
 test('primary_review_wrong_'+field,lambda f=field,v=value:g.primary_review({**review,f:v},'a'*64),True)
with tempfile.TemporaryDirectory(prefix='peer-metadata-',dir=O)as td:
 p=Path(td);source=p/'Source.lean';source.write_text('synthetic source');obj=p/'Module.olean';obj.write_bytes(b'synthetic object');log=p/'compiler.log';log.write_text('synthetic log')
 row={'module':'M','source':str(source),'source_sha256':h(source),'imports':['Parent']};rec={'status':'PASS','exit_code':0,'timed_out':False,'source_sha256':h(source),'dependencies':{'Parent':'a'*64},'object_sha256':h(obj),'log':str(log),'log_sha256':h(log)};parents={'Parent':{'object_sha256':'a'*64}}
 test('valid_current_provider',lambda:g.valid_record(row,rec,parents,obj))
 for field,value in [('status','FAIL'),('exit_code',1),('timed_out',True),('source_sha256','e'*64),('dependencies',{'Parent':'b'*64}),('object_sha256','c'*64),('log_sha256','d'*64)]:
  test('reject_provider_wrong_'+field,lambda f=field,v=value:g.valid_record(row,{**rec,f:v},parents,obj),True)
 def yes(x):assert x
 def no(x):assert not x
 test('reuse_dep_byte_identity',lambda:yes(g.reuse_record(row,rec,dict(rec['dependencies']))))
 test('changed_dep_requests_rebuild',lambda:no(g.reuse_record(row,rec,{'Parent':'b'*64})))
 test('changed_source_requests_rebuild',lambda:no(g.reuse_record({**row,'source_sha256':'f'*64},rec,rec['dependencies'])))
 cache=p/'cache';cache.mkdir();link=cache/'Module.olean';link.symlink_to(obj)
 test('reused_exact_symlink',lambda:g.provider(link,obj,False))
 test('fresh_regular',lambda:g.provider(obj,p/'missing',True))
 test('fresh_cannot_be_symlink',lambda:g.provider(link,obj,True),True)
 test('reuse_cannot_be_regular',lambda:g.provider(obj,obj,False),True)
 directory=cache/'alias';directory.symlink_to(p,target_is_directory=True)
 test('directory_alias_before_unlink',lambda:g.private_parents(directory/'Module.olean',cache),True)
 test('safe_private_parent',lambda:g.private_parents(cache/'new/Module.olean',cache))
 source.write_text('changedsource')
 test('changed_source_rejected',lambda:g.valid_record(row,rec,parents,obj),True)
text='\n'.join("'%s' depends on axioms: [propext, Classical.choice, Quot.sound]"%n for n in g.CLIENTS)
test('exact_five_audit_names',lambda:g.audit_reports(text))
for label,change in [('missing',lambda s:s.split('\n',1)[1]),('reorder',lambda s:'\n'.join(reversed(s.splitlines()))),('extra',lambda s:s+'\n'+s.splitlines()[0]),('unknown_axiom',lambda s:s.replace('propext','untrustedAxiom')),('warning',lambda s:s+'\nwarning: x'),('error',lambda s:s+'\nerror: x'),('sorry',lambda s:s+'\nsorryAx')]:
 test('reject_audit_'+label,lambda f=change:g.audit_reports(f(text)),True)
r={'status':'PASS_PEER_METADATA_CONTROLS','source_pins':{n:h(P/n)for n in ['build.py','gates.py','prepared-inventory.json']},'positive':sum(x['expected']=='accept'for x in rows),'negative':sum(x['expected']=='reject'for x in rows),'cases':rows,'scope':'Reviewed pure metadata functions only. No driver, compiler, source candidate, producer, or current-run capture.'}
(O/'controls-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='cases'},indent=2))
