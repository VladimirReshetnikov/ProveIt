This is a prepared, unexecuted phase12 import-cut check. No Lean compiler, delivered producer, or canonical edit has run in this preparation. `prepare.py` reads source text and JSON and uses only the already-reviewed import lexer. `controls.py` exercises extracted metadata gates with disposable files.

The primary target is the exact seven-file Source182/archive03 proposal frozen by root at `/tmp/k215-phase12-import-proposal/freeze.json`. Five of those files enter the primary closure, including two newly split modules. The other two changed wrappers are checked separately. The eighth proposal file is a maintained producer adjustment, pinned as unexecuted data alongside its current predecessor. This runner does not invoke a producer or adopt sources.

The immutable object basis is phase11 `/tmp/k215-generic-cd58-check/inline-full-run1`, result `53a7307848e6445a46b13e39b4283e335f5793660ca23f46659dc26c8f8e794d`. Machine/toolchain and historical producer identity still resolve to the exact phase8 records. Both historical five-file producer sets remain bound to their saved bytes. The current set requires the exact phase11 producer31fdd, unchanged legacy producer and adapter, and absence of both retired templates, including no dangling symlinks. These conditions are checked before and after compilation. The prospective L2Lib generator change remains a separately pinned input; keep its canonical predecessor unchanged until both checks finish.

The primary inventory contains179 endpoint modules and5 separately selected decoder-prefix modules,184 total. Exact source/import ancestry forces15 fresh modules and allows169 phase11 providers; all nine physical site batches stay outside the changed-source descendant set. Two unchanged endpoint clients are always compiled freshly and must emit their exact ten named reports, with only Lean's standard trusted axioms and zero audit warnings. Module source snapshots, direct imports/dependency objects, raw logs, compiler/toolchain and all before inputs are rehashed. Optional prior-candidate reuse requires equality of the entire transitive source/import closure, even if a changed descendant produces an identical object. The optional provider is labeled `secondary_checked`.

After the primary passes, a separate compatibility invocation checks67 project modules plus two typed clients. It includes the changed WFModel and ZFNative wrappers and the unchanged WFTheory facade, so the old native-calculus comparison also sees the new split imports. The two clients explicitly restate the prior model construction and all seven ZFNative exported theorem types. They require ten exact named reports. WFTheory itself supplies five additional existing reports. Expected providers after primary:52 exact primary modules,12 phase11-only modules, and5 fresh modules (three wrappers/facade and two clients). Across primary and compatibility there are199 distinct project modules, but neither invocation is described as a fresh199-module build.

The runner is a narrow successor of the preserved phase11 driver. Shared process-group supervision remains unchanged: one worker,12GiB,120seconds per module/client (900seconds only for a site batch if ever required), serialized by `/tmp/proveit-k215-proof-build.lock`. The private output tree symlinks read-only providers, checks parent directories, and unlinks targets before writing; no full cache is copied. Historical source, logs and records remain untouched. Resume additionally requires the expected origin, source, dependencies, object and saved-log hashes; malformed/failing/timeout logs and unexpected client reports are rejected.

Only after root authorizes execution, the primary command is:

```sh
python -B /tmp/k215-phase12-import-check/build.py \
  --out /tmp/k215-phase12-import-check/primary-run1 \
  --map /tmp/k215-phase12-import-check/primary-map.json \
  --target BusyBeaver.ZFC.KEndpoint215 \
  --target BusyBeaver.ZFC.KDecoderPrefix215 \
  --audit-endpoint
```

After actual primary PASS and root coordination, `python -B /tmp/k215-phase12-import-check/finalize_compatibility.py` rehashes the complete primary boundary and exact named audits, then writes new `compatibility-final-map.json` and `compatibility-final-plan.json` without invoking a compiler. It refuses to overwrite those files. The resulting compatibility command is:

```sh
python -B /tmp/k215-phase12-import-check/build.py \
  --out /tmp/k215-phase12-import-check/compatibility-run1 \
  --map /tmp/k215-phase12-import-check/compatibility-final-map.json \
  --reuse /tmp/k215-phase12-import-check/primary-run1 \
  --target WFModelCompat12 --target ZFNativeCompat12
```

The initial compatibility plan also records the valid but unnecessary no-secondary-provider scenario; it is not the selected execution route. The post-primary finalizer chooses the source-compatible primary cache instead. `census.json` gives exact module sets. Three positive and twenty negative metadata controls pass; these are not Lean typechecks. The preliminary plan omitting WFTheory is preserved under `history/compat-without-WFTheory/`; it was never executed. No proof failure or kernel result is claimed.
