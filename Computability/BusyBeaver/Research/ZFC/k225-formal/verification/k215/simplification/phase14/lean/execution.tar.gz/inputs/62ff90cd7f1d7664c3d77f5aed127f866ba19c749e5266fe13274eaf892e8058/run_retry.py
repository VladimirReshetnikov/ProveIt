"""Authorized bounded metadata initialization, then the unchanged serialized driver."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
S=Path('/tmp/k215-phase14-retry');R=Path('/tmp/k215-phase14-check');E=Path(__file__).resolve().parent;REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
assert sha(S/'freeze.json')=='cf22ecb2057efdcdf3035b932153ed399d2f278c6f19d07d18301a0f13554dee'
peer=Path('/tmp/k215-phase14-runner-peer/retry-review.json');assert sha(peer)=='3de77bfa7b2be76c1873af7fed4b9598bdbad27cb15044c67cf5776a644e47c0'
def unchanged():
 return all(sha(root/p)==h for root in [R,S]for p,h in read(root/'freeze.json')['files'].items())
assert unchanged()
for key,name in [('initialize','retry-initialize'),('primary','primary-run2')]:
 argv=read(S/'commands.json')[key];out=E/(name+'.stdout');err=E/(name+'.stderr');record=E/(name+'-outer.json');assert all(not p.exists()for p in [out,err,record])
 rec={'status':'RUNNING','argv':argv,'cwd':str(REPO),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_sha256':sha(__file__),'retry_freeze_sha256':sha(S/'freeze.json'),'retry_peer_sha256':sha(peer),'stdout':str(out),'stderr':str(err)}
 record.write_text(json.dumps(rec,indent=2)+'\n');start=time.monotonic();proc=None
 try:
  with out.open('wb')as stdout,err.open('wb')as stderr:
   proc=subprocess.Popen(argv,cwd=REPO,stdout=stdout,stderr=stderr,start_new_session=True);rec['pid']=proc.pid;record.write_text(json.dumps(rec,indent=2)+'\n');code=proc.wait()
  rec.update(status='PASS_OUTER_EXIT_ZERO'if code==0 else'FAIL_OUTER_EXIT',exit_code=code)
 except BaseException as exc:
  if proc is not None and proc.poll()is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  rec.update(status='OUTER_EXCEPTION',exception=repr(exc),exit_code=None if proc is None else proc.returncode);raise
 finally:
  rec.update(seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err),frozen_files_unchanged=unchanged());record.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2),flush=True)
 assert rec['exit_code']==0 and rec['frozen_files_unchanged']
