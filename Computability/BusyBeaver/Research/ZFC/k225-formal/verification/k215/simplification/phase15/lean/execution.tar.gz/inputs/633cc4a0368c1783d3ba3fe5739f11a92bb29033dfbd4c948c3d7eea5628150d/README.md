# Phase15 client-only retry — held, not executed

Both earlier primary attempts remain failed. Run1 passed 87 providers before the
missing explicit `FirstOrder.Completeness` import in handwritten `KQ1ZF`. Run2
passed 193 providers, including all nine production candidates, then the new
`QuotientSharing15Api` client failed to resolve namespaces. Its failed object and
`sorryAx` reports are excluded.

The sole successor change adds `SetTheory` and `ProfileCollection` to the client's
two `open` commands. All seven theorem statements, bodies, and axiom-print commands
are literal. The nine production candidates, maintained producer, original driver,
module/import graph, exact old profiles, and standard-axiom policy are unchanged.

The bounded initializer revalidates all 193 successful source/import/object/log and
direct dependency records. These comprise 44 successful fresh records (19 from
run1 and 25 from run2), plus 149 phase14 providers. It creates a separate run3 owner
using the unchanged driver's metadata prefix and private file symlinks. It excludes
the failed client. Run3 needs one corrected client call and two endpoint audits.
The finalizer then binds the actual terminal ledger into the compatibility map;
compatibility still needs its separate peer and root authorization.

The source-only preparation first rejected an exact-text assertion because its
expected `ProfileCollection` opening occurred earlier in the list than the reviewed
client. That own metadata error and partial outputs remain under
`history/preparation-order-v1`; no initializer or compiler ran during preparation.
The successor binds the exact reviewed client bytes.

New actual profiles must be retained as printed: the first three TransRec shape
clients use `Classical.choice`, the next two are axiom-free, and the remaining
thirteen use the standard three axioms. Basic's three reports are respectively
empty, the standard three, and `propext`/`Quot.sound`. This is evidence from the
successful providers in run2, not a terminal primary acceptance.
