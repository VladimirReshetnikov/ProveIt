"""Independent symbolic checker for emitted finite certificates, without a solver.

All-formula interpretation of the checked rules still belongs to Lean/Rocq.
This program checks finite syntax using only Imp(T,T)=T normalization.
"""
from pathlib import Path
import argparse,hashlib,json
ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
assert not args.output.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Research/ZFC/k225-formal/lean217/dominated_rho8_full_certificate.json')
assert sha(original)=='3cf18a5fe9f187b50b79d97b84535ce9bf776305728b0cdfe17285e94f028452'
old=json.loads(original.read_text());d=json.loads(args.certificate.read_text())
expressions=[('truth',)];interned={expressions[0]:0}
def intern(e):
 if e not in interned:interned[e]=len(expressions);expressions.append(e)
 return interned[e]
def imp(a,b):return 0 if a==b==0 else intern(('imp',a,b))
def read_terms(table):
 terms=[]
 for i,t in enumerate(table):
  if t=='T':v=0
  elif isinstance(t,dict):
   assert set(t)=={'var'} and isinstance(t['var'],int) and t['var']>=0
   v=intern(('var',t['var']))
  else:
   assert isinstance(t,list) and len(t)==2 and all(isinstance(x,int) and 0<=x<i for x in t)
   v=imp(terms[t[0]],terms[t[1]])
  terms.append(v)
 return terms
oldterms=read_terms(old['term_table']);terms=read_terms(d['term_table'])
def apply(e,mapping):
 cache={}
 def go(k):
  if k in cache:return cache[k]
  x=expressions[k]
  if x[0]=='truth':r=0
  elif x[0]=='var':r=mapping.get(x[1],0)
  else:r=imp(go(x[1]),go(x[2]))
  cache[k]=r;return r
 return go(e)
def variable_renaming(source,target,rho):
 x,y=expressions[source],expressions[target]
 if x[0]=='var':
  assert y[0]=='var' and rho.setdefault(x[1],y[1])==y[1]
 elif x[0]=='truth':assert y[0]=='truth'
 else:
  assert y[0]=='imp'
  variable_renaming(x[1],y[1],rho);variable_renaming(x[2],y[2],rho)
def split(e):
 x=expressions[e];assert x[0]=='imp',('expected implication',e,x)
 return x[1],x[2]
def is_subterm(needle,root):
 todo=[root];seen=set()
 while todo:
  k=todo.pop()
  if k==needle:return True
  if k in seen:continue
  seen.add(k);x=expressions[k]
  if x[0]=='imp':todo.extend(x[1:])
 return False
def env(rule,key):
 result={}
 for v,t in rule.get(key,{}).items():
  assert str(int(v))==v and 0<=t<len(terms)
  result[int(v)]=terms[t]
 return result
is_original=sha(args.certificate)==sha(original)
def origin_id(i):return i if is_original else d['nodes'][i]['origin']
checked=[];counts={};reordered=[]
for i,node in enumerate(d['nodes']):
 assert node['id']==i and 0<=node['term']<len(terms)
 target=terms[node['term']];rule=node['rule'];kind=rule['kind'];counts[kind]=counts.get(kind,0)+1
 for key in ('major','minor','parent'):
  if key in rule:
   j=rule[key];assert isinstance(j,int) and 0<=j<i
   if origin_id(j)>origin_id(i):reordered.append([origin_id(i),origin_id(j),kind])
 assert target==oldterms[old['nodes'][origin_id(i)]['term']]
 if kind=='truth':assert target==0
 elif kind=='dominated_rho8':
  left,right=split(target);cu,a=split(left);c,u=split(cu);ac,bc=split(right);a2,c2=split(ac);b,c3=split(bc)
  assert a==a2 and c==c2==c3 and (u==0 or is_subterm(u,a))
 elif kind=='substitution':assert apply(checked[rule['parent']],env(rule,'substitution'))==target
 elif kind=='mp':assert checked[rule['major']]==imp(checked[rule['minor']],target)
 elif kind=='mp_substitution':
  major=apply(checked[rule['major']],env(rule,'major_substitution'))
  minor=apply(checked[rule['minor']],env(rule,'minor_substitution'))
  # The delivered rule standardizes the resulting consequent by an
  # injective variable renaming, applied to both already-instantiated premises.
  # This is justified by the all-valuations theorem of each premise.
  if major==0:assert minor==target==0
  else:
   antecedent,consequent=split(major);assert antecedent==minor
   rho={};variable_renaming(consequent,target,rho)
   assert len(set(rho.values()))==len(rho)
   renamed={a:intern(('var',b)) for a,b in rho.items()}
   assert apply(consequent,renamed)==target
   assert apply(major,renamed)==imp(apply(minor,renamed),target)
 else:raise AssertionError(kind)
 checked.append(target)
assert d['roots']['rho8']==len(checked)-1
assert checked[-1]==oldterms[old['nodes'][old['roots']['rho8']]['term']]
for name,node in d['roots'].items():assert checked[node]==oldterms[old['nodes'][old['roots'][name]]['term']]
result={'status':'PASS_FINITE_SYMBOLIC_RULE_CHECK','candidate_sha256':sha(args.certificate),'original_sha256':sha(original),'validator_sha256':sha(Path(__file__)),'nodes':len(checked),'term_table':len(terms),'instruction_count':sum(3 if n['rule']['kind']=='mp_substitution' else 1 for n in d['nodes']),'rules':counts,'later_original_parent_edges':len(reordered),'later_original_parent_edge_examples':reordered[:20],'exact_original_rho8_target':True,'every_rule_checked':True,'mp_substitution_convention':'instantiate both premises, normalize, then injectively rename consequent variables; missing valuation entries default to truth','all_emitted_parent_ids_earlier':True,'kernel_invoked':False,'scope':'Finite symbolic derivation check only, using exact implication/truth normalization; no all-natural soundness theorem or compiler PASS is claimed.'}
args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
