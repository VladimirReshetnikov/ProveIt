"""Bind the actual terminal primary provider ledger into the fixed compatibility plan."""
from pathlib import Path
import argparse,hashlib,json,re
S=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
a=argparse.ArgumentParser();a.add_argument('--primary',type=Path,required=True);a.add_argument('--out',type=Path,required=True);args=a.parse_args()
freeze=read(S/'freeze.json')
for p,h in freeze['files'].items():assert sha(S/p)==h,p
assert args.primary.resolve()==(S/'primary-run1').resolve()and not args.out.exists()
result=read(args.primary/'result.json');inv=read(args.primary/'inventory.json');done=read(args.primary/'completed.json');plan=read(S/'primary-map.json')
assert result['status']=='PASS'and result['runner_sha256']==sha(S/'build.py')and result['map_sha256']==sha(S/'primary-map.json')
assert result['inventory_sha256']==sha(args.primary/'inventory.json')and result['completed_sha256']==sha(args.primary/'completed.json')
assert result['source_changed_modules']==plan['expected']['changed']and result['force_basis_rebuild_modules']==plan['expected']['forced']
assert [r['module']for r in inv['modules']]==plan['expected']['modules']and set(done)==set(plan['expected']['modules'])and len(done)==190
assert len(result['fresh_modules'])==66 and len(result['phase13_primary_reused_modules'])==124
assert sorted(result['fresh_modules'])==plan['expected']['forced']
assert not result['phase13_compatibility_reused_modules']and not result['secondary_reused_modules']
assert len(result['audits'])==2 and sum(len(r['named_reports'])for r in result['audits'])==10
assert result['retired_modules_absent_from_candidate']==['BusyBeaver.ZFC.KProfileTC']
plans={r['module']:r for r in plan['modules']};recorded_profiles={}
for row in inv['modules']:
 m=row['module'];r=done[m];assert r['status']=='PASS'and r.get('exit_code',0)==0 and not r.get('timed_out',False)
 assert sha(row['source'])==row['source_sha256']==r['source_sha256']
 assert r['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 assert sha(args.primary/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']
 text=Path(r['log']).read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
 assert 'error:'not in text and 'sorryAx'not in text
 profiles=[[x.strip()for x in ax.split(',')if x.strip()]for _,ax in reports]
 assert all(set(ax)<={'propext','Classical.choice','Quot.sound'}for ax in profiles)
 if m in plans and'reports'in plans[m]:
  assert [n for n,_ in reports]==plans[m]['reports']and 'warning:'not in text
  if'report_axioms'in plans[m]:assert [set(x)for x in profiles]==[set(x)for x in plans[m]['report_axioms']]
  recorded_profiles[m]={'names':[n for n,_ in reports],'axioms':profiles}
for p,h in read(args.primary/'before.json')['inputs'].items():assert sha(p)==h,p
for p in read(args.primary/'before.json')['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink()
baseline=read('/tmp/k215-phase13-upstream-check/primary-run1/result.json')
normalize=lambda rs:[(n,{a.strip()for a in ax.split(',')if a.strip()})for n,ax in rs]
old_audits={r['module']:r for r in baseline['audits']}
assert [r['module']for r in result['audits']]==list(old_audits)
for r in result['audits']:
 name=r['module'];directory=args.primary/('audit-'+name)
 assert r['status']=='PASS'and r['exit_code']==0 and not r['timed_out']
 assert sha(r['source'])==sha(directory/(name+'.lean'))==r['source_sha256']==old_audits[name]['source_sha256']
 assert sha(r['log'])==r['log_sha256']and sha(directory/(name+'.olean'))==r['object_sha256']
 text=Path(r['log']).read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
 assert all(t not in text for t in ['error:','warning:','sorryAx'])
 assert normalize(reports)==normalize(r['named_reports'])==normalize(old_audits[name]['named_reports'])
 assert r['dependencies']=={m:rec['object_sha256']for m,rec in done.items()}
new=read(S/'compatibility-template.json');new['reuse_ledger']={'directory':str(args.primary),**{n:sha(args.primary/n)for n in ['result.json','inventory.json','completed.json']}}
args.out.write_text(json.dumps(new,indent=2)+'\n')
receipt=args.out.with_suffix('.review.json')
assert not receipt.exists()
receipt.write_text(json.dumps({'status':'PRIMARY_ACTUAL_VALIDATED_COMPATIBILITY_MAP_BOUND','primary_result_sha256':sha(args.primary/'result.json'),'map_sha256':sha(args.out),'actual_named_profiles':recorded_profiles,'compiler_invoked':False,'requires_peer_before_compatibility_compiler':True},indent=2)+'\n')
print(json.dumps({'status':'COMPATIBILITY_MAP_READY_FOR_PEER','map':str(args.out),'sha256':sha(args.out)},indent=2))
