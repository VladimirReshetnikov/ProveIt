"""Independent pure helper controls; no collector, predecessor review or compiler."""
from pathlib import Path
import copy,hashlib,importlib,sys,json
O=Path(__file__).resolve().parent;H=Path('/tmp/k215-phase9-publication');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();freeze=json.loads((H/'source-freeze-v1.json').read_text())
for n,r in freeze['files'].items():assert sha(H/n)==r['sha256'] and (H/n).stat().st_size==r['bytes']
sys.path.insert(0,str(H));e=importlib.import_module('evidence');b=importlib.import_module('bundle');checks=[]
def check(name,f,negative=False):
 try:f()
 except (AssertionError,KeyError,FileExistsError):
  assert negative,name;checks.append({'name':name,'expected':'reject'})
 else:assert not negative,name;checks.append({'name':name,'expected':'accept'})
def equal(x,y):assert x==y
rows=[{'module':'C','source_sha256':'newC','imports':['Init']},{'module':'B','source_sha256':'B','imports':['C']},{'module':'A','source_sha256':'A','imports':['B']}]
entries,closures=e.graph(rows,['A']);old=copy.deepcopy(entries);old['C']['source_sha256']='oldC';iso=copy.deepcopy(old)
changed,forced,iso_ok=e.source_scope(entries,closures,old,iso)
check('deep changed source reaches every dependent despite any same object',lambda:equal((changed,forced,iso_ok),({'C'},{'A','B','C'},set())))
check('all-fresh synthetic origin accepted',lambda:e.check_origins({m:{'origin':'phase9_fresh'}for m in entries},forced,iso_ok))
for bad in ['phase8_checked','isolated_checked','unknown']:
 d={m:{'origin':'phase9_fresh'}for m in entries};d['A']['origin']=bad
 check('reject dependent '+bad,lambda d=d:e.check_origins(d,forced,iso_ok),True)
check('exact isolated recursive sources permit reuse',lambda:equal(e.source_scope(entries,closures,old,entries)[2],set(entries)))
for bad in ['../outside','/outside','x.olean.private','x.olean.server','x.pyo','x.vo','x.tar.gz','x.zip']:
 check('reject member '+bad,lambda bad=bad:e.safe_name(bad),True)
check('source member accepted',lambda:e.safe_name('sources/A.lean'))
check('unknown axiom rejected',lambda:e.reports(b"'T' depends on axioms: [badAx]\n"),True)
check('sorry rejected',lambda:e.reports(b"'T' depends on axioms: [sorryAx]\n"),True)
check('compiler error rejected',lambda:e.reports(b'error: failed\n'),True)
check('standard report accepted',lambda:e.reports(b"'T' depends on axioms: [propext, Quot.sound]\n"))
read=lambda p:json.loads(Path(p).read_text()); inv=read('/tmp/k215-phase9-main/full-run1/inventory.json'); en,cl=e.graph(inv['modules'],inv['targets']);old={r['module']:r for r in read('/tmp/k215-proof-phase8/lean-run1/inventory.json')['modules']};iso={r['module']:r for r in read('/tmp/k215-phase9-main/isolated-run2/inventory.json')['modules']};ch,fo,ok=e.source_scope(en,cl,old,iso)
check('independent actual source census matches 11/26/20',lambda:equal((len(ch),len(fo),len(fo-ok)),(11,26,20)))
check('original full-run1 rejected by new source ancestry gate',lambda:e.check_origins(read('/tmp/k215-phase9-main/full-run1/completed.json'),fo,ok),True)
for n,r in freeze['files'].items():assert sha(H/n)==r['sha256']
out={'status':'PASS_INDEPENDENT_PURE_METADATA_CONTROLS','positive':sum(r['expected']=='accept'for r in checks),'negative':sum(r['expected']=='reject'for r in checks),'checks':checks,'helper_freeze_sha256':sha(H/'source-freeze-v1.json'),'control_sha256':sha(__file__),'compiler_invoked':False,'collector_invoked':False,'full_saved_reader_invoked':False};(O/'controls-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
