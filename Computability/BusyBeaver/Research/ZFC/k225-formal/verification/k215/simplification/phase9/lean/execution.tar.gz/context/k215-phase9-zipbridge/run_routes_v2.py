"""Compile four decoder modules against two exact checked bridge modules and phase8."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,signal
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');B=Path('/tmp/k215-proof-phase8/lean-run1');P=S/'run5'
F=Path('/tmp/k215-phase9-decoder-routes/formal-table-v2/freeze.json')
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
a=argparse.ArgumentParser();a.add_argument('run');args=a.parse_args();out=S/args.run;out.mkdir(exist_ok=False)
assert sha(B/'result.json')=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
assert sha(F)=='011c93aafb18eb47009ab319e2a2fc85df6dfbb232a197fc20b5911a4ae44913'
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
assert sha(C)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
inv=read(B/'inventory.json');old=read(B/'completed.json');plans=read(F)['modules'];prior=read(P/'summary.json');assert len(old)==len(inv['modules'])==188 and prior['status']=='PASS'
assert len(plans)==6 and [r['module']for r in plans[:2]]==[r['module']for r in prior['rows']]
inputs={str(p):sha(p)for p in [B/n for n in ['result.json','inventory.json','completed.json','toolchain.json']]+[P/'summary.json',F,H,C,Path(__file__)]}
cache=out/'objects';done={};sources={r['module']:r for r in inv['modules']};providers={}
for row in inv['modules']:
 m=row['module'];rec=old[m];assert rec['status']=='PASS'and sha(row['source'])==row['source_sha256']==rec['source_sha256']
 assert rec['dependencies']=={d:old[d]['object_sha256']for d in row['imports']if d in old}
 path=B/'objects'/(m.replace('.','/')+'.olean');assert sha(path)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
 inputs[row['source']]=row['source_sha256'];inputs[str(path)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256'];providers[m]=path
 q=cache/(m.replace('.','/')+'.olean');q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(path)
 done[m]=rec
for row in plans:
 path=Path(row['source']);assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'];imports=[w for l in path.read_text().splitlines()if l.startswith('import ')for w in l[7:].split()];assert imports==row['imports'];sources[row['module']]={'module':row['module'],'source':str(path),'source_sha256':row['sha256'],'imports':imports};inputs[str(path)]=row['sha256']
for row,rec in zip(plans[:2],prior['rows']):
 m=row['module'];assert rec['status']=='PASS'and rec['warnings']==0 and rec['source_sha256']==row['sha256']
 path=P/'objects'/(m.replace('.','/')+'.olean');assert sha(path)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
 q=cache/(m.replace('.','/')+'.olean');q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(path)
 deps={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 done[m]={**rec,'dependencies':deps,'origin':'checked_bridge_run5'};providers[m]=path;inputs[str(path)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
for key in ['lean','lake','Init.olean','project_toolchain']:
 t=read(B/'toolchain.json')[key];assert sha(t['path'])==t['sha256'];inputs[t['path']]=t['sha256']
PREVIOUS = S/'routes-run1'
reusable = {}
for row in plans[2:]:
    m=row['module'];record=PREVIOUS/(m.rsplit('.',1)[1]+'.json')
    if record.exists():
        rec=read(record)
        if rec['status']=='PASS' and rec['source_sha256']==row['sha256']:
            obj=PREVIOUS/'objects'/(m.replace('.','/')+'.olean')
            assert sha(obj)==rec['object_sha256'] and sha(rec['log'])==rec['log_sha256']
            reusable[m]=(rec,obj);inputs[str(record)]=sha(record);inputs[str(obj)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
namespace={r['module']:r['module'].replace('BusyBeaver.','SetTheory.BusyBeaver.',1)+'.'for r in plans};namespace['BusyBeaver.ZFC.DecoderPaths']='SetTheory.BusyBeaver.ZFC.K215SourcePaths.'
save(out/'before.json',{'inputs':inputs,'all188_basis_records':old,'plans':plans,'reuse_bridge':prior['rows'],'scope':'6 new decoder/bridge modules (2 checked bridge providers reused,4 fresh) alongside immutable188 basis; no new endpoint/semanticcoverage claim.'})
spec=importlib.util.spec_from_file_location('supervisor',H);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver);env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1';fresh=[]
for row in plans[2:]:
 m=row['module'];src=out/'workspace'/(m.replace('.','/')+'.lean');src.parent.mkdir(parents=True,exist_ok=True);src.write_bytes(Path(row['source']).read_bytes());obj=cache/(m.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);assert not obj.exists()
 deps={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 if m in reusable:
  rec,previousobj=reusable[m];assert rec['dependencies']==deps;obj.symlink_to(previousobj);done[m]={**rec,'origin':'checked_routes_run1'};providers[m]=previousobj;print('REUSE CHECKED',m,flush=True);continue
 for d,h in deps.items():assert sha(cache/(d.replace('.','/')+'.olean'))==h
 log=out/(m.rsplit('.',1)[1]+'.log');record=out/(m.rsplit('.',1)[1]+'.json');cmd=[str(C),'-j1','-M12288','--root='+str(out/'workspace'),'-o',str(obj),str(src)]
 rec={'module':m,'source':str(src),'source_sha256':sha(src),'candidate':row['source'],'dependencies':deps,'command':cmd,'timeout_seconds':120,'memory_mebibytes':12288,'compiler_sha256':sha(C),'helper_sha256':sha(H),'log':str(log),'origin':'fresh_decoder_module'}
 print('CHECK',m,flush=True);ok=driver.run_locked(cmd,R,env,LOCK,log,120,rec,record);text=log.read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text);rec.update({'warnings':text.count('warning:'),'reports':reports,'object_sha256':sha(obj)if ok else None})
 save(record,rec);print(rec['status'],m,round(rec['seconds'],3),len(reports),'reports',rec['warnings'],'warnings',flush=True)
 assert ok and not rec['timed_out'],m
 assert [n for n,_ in reports]==[namespace[m]+n for n in row['printed_axioms']],reports
 assert all({s.strip()for s in ax.split(',')if s.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports)
 assert sha(src)==row['sha256'];done[m]=rec;fresh.append(m);providers[m]=obj
for p,h in inputs.items():assert sha(p)==h,p
assert len(done)==194
for m,rec in done.items():
 assert sha(cache/(m.replace('.','/')+'.olean'))==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256'];r=sources[m];assert sha(r['source'])==r['source_sha256'];assert rec['dependencies']=={d:done[d]['object_sha256']for d in r['imports']if d!='Init'}
save(out/'completed.json',done);save(out/'inventory.json',{'modules':list(sources.values()),'new_modules':[r['module']for r in plans]});result={'status':'PASS','new_component_modules':6,'fresh_modules':fresh,'reused_checked_bridge_modules':2,'reused_checked_decoder_modules':len(reusable),'immutable_primary_basis_modules':188,'selected_union_modules':194,'new_component_named_reports':7+sum(len(done[r['module']]['reports'])for r in plans[2:]),'new_component_warnings':sum(done[r['module']]['warnings']for r in plans[2:]),'all_sources_objects_logs_toolchain_checked_after_new_modules':True,'scope':'Complete six-module decoder/sourcepath+zipper bridge component checked against immutablephase8; endpoint remains unchangedphase8, primitive/return contracts andnewphysicalsitecoverage are open.','runner_sha256':sha(__file__)};save(out/'result.json',result);print(json.dumps(result,indent=2))
