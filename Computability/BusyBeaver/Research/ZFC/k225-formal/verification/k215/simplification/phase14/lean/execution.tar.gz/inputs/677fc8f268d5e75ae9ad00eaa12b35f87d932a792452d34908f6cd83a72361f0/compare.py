from pathlib import Path
import re,json,hashlib
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');O=Path('/tmp/k215-phase14-profile');M=json.loads((O/'source-map.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
NAMES=['union_edges_of_instance','composition_of_instances','eqv_trans_of_instances','join_edges_of_instances','eqv_matching_of_instances','eqv_extensionality_of_instances']
def strip_comments(s):
 out=[];i=0;depth=0
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;i+=2
   elif s.startswith('-/',i):depth-=1;i+=2
   else:i+=1
  elif s.startswith('/-',i):depth=1;i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);i=len(s) if j<0 else j
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def blocks(s):
 t=strip_comments(s);p=re.compile(r'(?m)^(?:theorem|def|inductive|structure|class)\s+(\w+)');hs=list(p.finditer(t));d={}
 for i,h in enumerate(hs):
  z=t[h.start():hs[i+1].start() if i+1<len(hs) else len(t)]
  z=re.split(r'(?m)^#print|^end ',z,1)[0].strip()
  d[h.group(1)]=z
 return d
def norm(s):return ' '.join(s.split())
def proof(s):return norm(s.split(':=',1)[1])
byname={Path(x['path']).name:x for x in M['files']}
old={n:Path(x['before_snapshot']).read_text() for n,x in byname.items() if n.endswith('.lean')}
new={n:Path(x['candidate']).read_text() for n,x in byname.items() if not x['delete']}
a,b,tc=blocks(old['ProfileComposition.lean']),blocks(new['ProfileComposition.lean']),blocks(old['KProfileTC.lean'])
checks=[]
for name in NAMES:
 expected=a[name].replace('(hContainers : Containers mem)','(hContainers : TransContainers mem)').replace('⟨domain, hFamily, hTrans, _⟩','⟨domain, hFamily, hTrans⟩')
 assert norm(expected)==norm(b[name]),name
 copied=tc[name+'TC'].replace('ProfileComposition.orderedPair_code_congr','orderedPair_code_congr')
 for n in NAMES:copied=re.sub(r'\b'+n+r'TC\b',n,copied)
 assert norm(copied)==norm(b[name]),name+'TC'
 checks.append({'name':name,'only_original_hypothesis_and_union_tuple_changed':True,'exact_old_TC_copy_after_namespace_qualification':True,'candidate_sha256':sha(b[name].encode())})
assert norm(tc['TransContainers'])==norm(b['TransContainers'])
unchanged=[n for n in a if n not in NAMES]
assert all(norm(a[n])==norm(b[n]) for n in unchanged)
header_checks={}
for n in ['CompositionModel.lean','KLowerEqv.lean']:
 x,y=blocks(old[n]),blocks(new[n]);assert set(x)==set(y)
 for k in x:assert norm(x[k].split(':=',1)[0])==norm(y[k].split(':=',1)[0]),(n,k)
 header_checks[n]={'all_headers_exact':True,'count':len(x),'definitions_bodies_exact':all(norm(x[k])==norm(y[k]) for k in x if x[k].startswith('def '))}
# All live Lean consumers of the moved namespace or six API names, with the candidate overlay.
pat=re.compile(r'\b(?:KProfileTC|TransContainers|'+ '|'.join(NAMES)+r')(?:TC)?\b')
callers=[];retired=[]
retired_path=byname['KProfileTC.lean']['path']
for p in sorted((R/'Computability/BusyBeaver/Lean').rglob('*.lean')):
 rel=str(p.relative_to(R))
 if rel==retired_path:continue
 t=new.get(p.name,p.read_text())
 found=[{'line':t.count('\n',0,m.start())+1,'token':m.group()} for m in pat.finditer(t)]
 if found:callers.append({'path':rel,'hits':found})
 if re.search(r'\bKProfileTC\b|\b(?:'+ '|'.join(NAMES)+r')TC\b',strip_comments(t)):retired.append(rel)
assert not retired
# Exact imported graphs, replacing only the three sources and dropping the retired provider.
retired_mod='BusyBeaver.ZFC.KProfileTC';graphs={}
for label in ['primary','compatibility']:
 inv=json.loads((Path('/tmp/k215-phase13-upstream-check')/(label+'-run1')/'inventory.json').read_text());entries={x['module']:x for x in inv['modules']}
 graph={n:list(e['imports']) for n,e in entries.items()}
 for name,text in new.items():
  mod='BusyBeaver.ZFC.'+name[:-5]
  if mod in graph:graph[mod]=re.findall(r'(?m)^import (.*)$',text)
 targets=inv['targets'];seen=set()
 def visit(n):
  if n in seen or n not in graph:return
  seen.add(n)
  for d in graph[n]:visit(d)
 for n in targets:visit(n)
 assert retired_mod not in seen
 graphs[label]={'previous_providers':len(entries),'overlay_providers':len(seen),'removed':sorted(set(entries)-seen),'added':sorted(seen-set(entries)),'targets':targets}
metrics={'old_four_lean_bytes':sum(len(t.encode()) for t in old.values()),'new_three_lean_bytes':sum(len(t.encode()) for t in new.values()),'old_four_lean_lines':sum(len(t.splitlines()) for t in old.values()),'new_three_lean_lines':sum(len(t.splitlines()) for t in new.values()),'retired_generator_bytes':byname['generate_profile_tc.py']['before_bytes'],'retired_generator_lines':byname['generate_profile_tc.py']['before_lines']}
obj={'status':'PASS_READ_ONLY_LITERAL_BODY_AND_CONSUMER_CHECKS','six_proofs':checks,'TransContainers_definition_exact':True,'other_ProfileComposition_declarations_exact':unchanged,'retained_consumer_headers':header_checks,'overlay_lean_callers':callers,'remaining_live_old_namespace_or_TC_suffix_callers':retired,'graph':graphs,'metrics':metrics,'scope':'Own literal source/graph reader, not imported or executed source generator and not a proof compiler. Field/body equality is a textual diagnostic; proposed clients and integration remain uncompiled.'}
(O/'comparison.json').write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps({'metrics':metrics,'graphs':graphs,'caller_files':[x['path'] for x in callers]},indent=2))
print('comparison_sha256',sha((O/'comparison.json').read_bytes()))
