# Client-only retry, preserving the failed primary attempt

The original frozen run stopped at its final `ProfileTC14Api` client. The seven production-source candidates and the other 189 providers passed; endpoint audits were not reached. The client’s structure-field equation omitted three implicit binders. Its elaboration produced `sorryAx` reports, which are failed output and never accepted as proof evidence. The original client, maps, freeze, logs, failed object and outer exit remain unchanged.

Drop’s sole correction adds `_ _ _` before `hxy hyz`, binding those three implicit arguments. No theorem or structure statement, production source, report policy, or runtime driver changes. `map.diff` changes only this client’s source path/hash.

The bounded `initialize.py` requires independent review and authorization before execution. It validates the failed run’s immutable input ledger and all 189 successful provider records. It executes only the exact reviewed runner’s metadata prefix, stopped by AST before the compiler loop; the prefix is checked to contain no `run_locked` call. This creates the same run2 ownership record as the ordinary unchanged driver. It then supplies file symlinks and the validated completed records. All directory paths are real directories. The failed client/object is excluded.

The unchanged runner’s `usable()` and post-audit gates recheck every supplied record, source, dependency, object and raw log. Origins remain explicit: 65 successful earlier fresh invocations and 124 exact phase13 providers. Only the corrected client and two endpoint audits need new compiler calls. A later result’s 66 `candidate_fresh` records therefore comprise 65 successes from run1 and one from run2; this does not turn run1 into a successful primary run.

The successor finalizer changes only the held map/run locations and verifies the retry freeze. It retains all exact named report and axiom gates. Compatibility remains prohibited until terminal retry PASS, actual-ledger binding and a separate map peer/root authorization. No canonical files or generators are changed.
