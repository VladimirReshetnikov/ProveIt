"""Prospective archive/report metadata controls only; no actual capture or compiler."""
from pathlib import Path
import gzip,io,tarfile,tempfile,json,sys
sys.dont_write_bytecode=True
from evidence import safe,members,manifest,reports,digest,save
HERE=Path(__file__).resolve().parent
rs=[]
def reject(name,f):
 try:f()
 except(AssertionError,KeyError):rs.append([name,'REJECTED']);return
 raise AssertionError('bad control accepted '+name)
for n in ['execution/result.json','preparation/history/driver.py','execution/audit/LegacyAudit.lean']:
 assert safe(n)
rs.append(['safe_names','PASS'])
for n in ['/absolute','../escape','x/../escape','a\\b','x.olean','x.olean.server','x.olean.private','x.ilean','x.pyc','x.vo']:
 reject('unsafe_'+n,lambda n=n:(_ for _ in ()).throw(AssertionError())if not safe(n)else None)
valid='\n'.join("'SetTheory.BusyBeaver.ZFC.LegacyAudit.%s' depends on axioms: [propext, Classical.choice, Quot.sound]"%n for n in ['root222','root219','rootDom','rootPerm','offset_checker'])
assert len(reports(valid))==5;rs.append(['five_named_reports','PASS'])
for n,t in [('missing',valid.split('\n',1)[1]),('reordered','\n'.join(reversed(valid.splitlines()))),('extra',valid+"\n'x' does not depend on any axioms"),('warning','warning:x\n'+valid),('error','error:x\n'+valid),('sorry',valid+' sorryAx'),('new_axiom',valid.replace('propext','AddedAxiom'))]:reject(n,lambda t=t:reports(t))
with tempfile.TemporaryDirectory(prefix='legacy-packet-control-')as d:
 d=Path(d)
 def make(name,rows):
  f=d/name
  with tarfile.open(f,'w:gz')as t:
   for n,b,kind in rows:
    ti=tarfile.TarInfo(n);ti.size=len(b)
    if kind=='link':ti.type=tarfile.SYMTYPE;ti.linkname='elsewhere';t.addfile(ti)
    else:t.addfile(ti,io.BytesIO(b))
  return f
 data={'execution/result.json':b'{}','execution/audit/compiler.log':valid.encode()};idx=manifest(data)
 f=make('ok.gz',[(n,b,'file')for n,b in data.items()]);assert members(f,idx)==data;rs.append(['indexed_archive','PASS'])
 reject('index_changed_sha',lambda:members(f,{**idx,'execution/result.json':{'bytes':2,'sha256':'0'*64}}))
 reject('index_missing_entry',lambda:members(f,{'execution/result.json':idx['execution/result.json']}))
 reject('index_unseen_entry',lambda:members(f,{**idx,'extra':{'bytes':0,'sha256':digest(b'')}}))
 for n,rows in [('link',[('execution/result.json',b'','link')]),('binary',[('x.olean.private',b'x','file')]),('duplicate',[('x',b'x','file'),('x',b'x','file')]),('traversal',[('../x',b'x','file')])]:
  f=make(n+'.gz',rows);reject(n,lambda f=f:members(f,{'x':{'bytes':1,'sha256':digest(b'x')}}))
for p in HERE.glob('*.py'):compile(p.read_text(),str(p),'exec')
save(HERE/'controls-result.json',{'status':'PASS_PROSPECTIVE_METADATA_CONTROLS','positive':sum(v=='PASS'for _,v in rs),'negative':sum(v=='REJECTED'for _,v in rs),'controls':rs,'actual_capture':False,'compiler_invocations':[]})
print(json.dumps({'positive':sum(v=='PASS'for _,v in rs),'negative':sum(v=='REJECTED'for _,v in rs)}))
