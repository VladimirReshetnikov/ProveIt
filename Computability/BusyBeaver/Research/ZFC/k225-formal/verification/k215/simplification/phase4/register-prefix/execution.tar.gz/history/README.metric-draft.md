# Cancel a successful prefix of a halting run

The proposed `RMBisim.lean` proof replaces a second induction over segment execution with a generic deterministic-prefix argument. A halted configuration has no outgoing transition. Consequently, if an `n`-step execution succeeds and the same starting configuration halts after `N` steps, then `N = n + N'` and the resulting configuration halts after exactly `N'` steps. Induction on the successful prefix proves this, including the zero-prefix case and the impossibility of stepping after an already halted state.

`seg_run` already gives a successful execution and its exact register increments. Applying the new `hn_after` lemma to it proves `seg_hn` immediately, including the bound `N' ≤ N`. This removes the entire duplicated segment recursion. The explicit instruction cases remain in the single existing `seg_run` proof.

Every existing declaration statement and executable definition is unchanged, including the entire `hn_step` wrapper. Two reusable lemmas are added, and the file shrinks from555 to544 lines and22419 to21684 bytes. There is no producer: `source.diff` is the exact handwritten change. The candidate is scratch-only; canonical files and the accepted phase3 cache are unchanged.

`run3/result.json` records the exact candidate kernel check (2.269s, zero warnings). The two typed API clients in `Audit.lean` were independently compiled against the accepted and candidate objects. All four axiom reports are identical (`propext`, `Quot.sound`). `comparison.json` also records an exact structural comparison of all untouched declarations and a post-audit rehash of all185 basis objects. This is an isolated module/API check, not a fresh endpoint-closure claim.

The first attempt's two elaboration errors are preserved in `run1`. A broader second attempt also reused prefix cancellation in `hn_step`; its now-redundant public premise produced one linter warning. That existing wrapper proof was restored for the final candidate, preserving its exact API without suppressing diagnostics. All attempts use the shared machine-wide compiler lock, one worker,120 seconds and12GiB.
