"""Static public-signature, definition and saved-run comparison; no kernel."""
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def uncomment(s):
 out=[];i=0;depth=0;string=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;out.extend('  ');i+=2
   elif s.startswith('-/',i):depth-=1;out.extend('  ');i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif string:
   out.append(s[i])
   if s[i]=='\\' and i+1<len(s):out.append(s[i+1]);i+=2;continue
   if s[i]=='"':string=False
   i+=1
  elif s.startswith('/-',i):depth=1;out.extend('  ');i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);j=len(s) if j<0 else j
   out.extend(' '*(j-i));i=j
  else:
   if s[i]=='"':string=True
   out.append(s[i]);i+=1
 assert depth==0 and not string
 return ''.join(out)
norm=lambda s:re.sub(r'\s+',' ',s).strip()
def declarations(s):
 s=uncomment(s)
 matches=list(re.finditer(r'^(private )?(theorem|noncomputable def|def|structure) ([\w.]+)\b',s,re.M))
 result={}
 for i,m in enumerate(matches):
  text=s[m.start():matches[i+1].start() if i+1<len(matches) else len(s)]
  kind=m[2];header=text.split(':=',1)[0] if kind=='theorem' else text
  result[m[3]]={'private':bool(m[1]),'kind':kind,'header':norm(header),'text':norm(text)}
 return result
old=declarations((P/'baseline/InternalSat.lean').read_text())
new=declarations((P/'InternalSat.lean').read_text())
assert set(new)-set(old)=={'pair_eq_iff','numeral_eq_iff'}
assert set(old)<=set(new)
changed=[]
for name,d in old.items():
 n=new[name]
 assert d['header']==n['header'],name
 if d['kind']!='theorem':assert d['text']==n['text'],name
 elif d['text']!=n['text']:changed.append(name)
expected={'fZeroOrSuccF_spec','fJustifiedF_spec','justified_memAtom','justified_eqAtom',
          'justified_bot','justified_imp','justified_and','justified_or','justified_all','justified_ex',
          'Certifies.envOn'}
# The two private helpers were inserted immediately after Certifies.envOn;
# its body itself remains the exact original expression.
assert changed==[n for n in old if n in expected-{'Certifies.envOn'}],changed
b=json.loads((P/'baseline-run1/result.json').read_text())
r=json.loads((P/'run3/result.json').read_text())
assert b['status']==r['status']=='PASS'
assert b['axiom_reports']==r['axiom_reports']
assert b['warnings']==r['warnings']==0
assert sha(P/'run3/FinalWithAudit.lean')==r['source_sha256']
assert (P/'InternalSat.lean').read_bytes()+(P/'Audit.lean.inc').read_bytes()==(P/'run3/FinalWithAudit.lean').read_bytes()
assert sha(P/'run3/compiler.log')==r['log_sha256']
record={'status':'PASS_STATIC_API_AND_SAVED_AXIOM_COMPARISON',
 'baseline_source_sha256':sha(P/'baseline/InternalSat.lean'),'candidate_sha256':sha(P/'InternalSat.lean'),
 'all_original_declarations':len(old),'unchanged_original_headers':len(old),
 'unchanged_definitions_and_structures':sum(d['kind']!='theorem' for d in old.values()),
 'changed_proofs':changed,'new_private_helpers':['pair_eq_iff','numeral_eq_iff'],
 'no_original_declaration_removed':True,'same_three_axiom_reports':True,
 'baseline_result_sha256':sha(P/'baseline-run1/result.json'),'candidate_result_sha256':sha(P/'run3/result.json'),
 'raw_log_rehashed':True,'exact_candidate_plus_audit_snapshot':True,
 'phase4_project_providers':len(r['providers']),'canonical_unchanged':r['canonical_unchanged'],
 'namedform254':'No change proposed; direct a=b-aware slot argument is clearer than introducing a swap adapter.',
 'scope':'Static declarations and saved actual comparison only; no new compiler invocation.'}
(P/'comparison-final.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
