"""Own metadata-only client repair; never invokes a proof compiler."""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, shutil
S = Path(__file__).resolve().parent
P = Path('/tmp/k215-phase15-retry')
R = Path('/tmp/k215-phase15-check')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
def save(name, value):
    (S / name).write_text(json.dumps(value, indent=2) + '\n')
a = argparse.ArgumentParser()
a.add_argument('--client', type=Path, required=True)
a.add_argument('--client-sha256', required=True)
args = a.parse_args()
assert sha(args.client) == args.client_sha256
assert sha(P/'freeze.json') == 'a23392c7d00a657a7e2da7caae40cf752c4f3ec02bd574ab6331b7ce9d47bf73'
assert not (S/'primary-map.json').exists()
for name in ['sources.json', 'compatibility-template.json']:
    shutil.copyfile(P/name, S/name)
old_client = Path('/tmp/k215-phase15-quotient/clients/QuotientSharing15Api.lean')
old = old_client.read_text()
expected = old.replace('open SetTheory.BusyBeaver.ZFC\n', 'open SetTheory SetTheory.BusyBeaver.ZFC\n').replace('open Form Profile ProfileComposition ProfileSyntax ProfileModel', 'open Form Profile ProfileComposition ProfileSyntax ProfileModel ProfileCollection')
assert args.client.read_text() == expected
(S/'client.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True), expected.splitlines(True), fromfile='failed-client', tofile='corrected-client')))
def update(row):
    if row.get('module') == 'QuotientSharing15Api':
        row['source'] = str(args.client)
        row['source_sha256'] = sha(args.client)
clients = read(P/'clients.json')
for row in clients: update(row)
save('clients.json', clients)
plan = read(P/'primary-map.json')
for row in plan['modules']: update(row)
save('primary-map.json', plan)
cmd = read(P/'commands.json')
cmd['status'] = 'CLIENT_NAMESPACE_REPAIR_PENDING_PEER_AND_ROOT_GO'
for k in ['initialize','primary','finalize_compatibility','compatibility']:
    cmd[k] = [x.replace(str(P), str(S)).replace('primary-run2','primary-run3') for x in cmd[k]]
save('commands.json', cmd)
fin = (P/'finalize_compatibility.py').read_text().replace("(R/'primary-run2').resolve()", "(R/'primary-run3').resolve()")
(S/'finalize_compatibility.py').write_text(fin)
ini = (P/'initialize.py').read_text()
ini = ini.replace('only87', 'only193').replace("old=R/'primary-run1';out=R/'primary-run2'", "old=R/'primary-run2';out=R/'primary-run3'")
ini = ini.replace('len(done)==87','len(done)==193').replace('[:87]','[:193]').replace("inv['modules'][87]['module']=='BusyBeaver.ZFC.KQ1ZF'", "inv['modules'][193]['module']=='QuotientSharing15Api'")
ini = ini.replace("for r in done.values())==19", "for r in done.values())==44").replace("for r in done.values())==68", "for r in done.values())==149")
ini = ini.replace('020-BusyBeaver.ZFC.KQ1ZF','026-QuotientSharing15Api').replace('primary-run1-outer.json','primary-run2-outer.json')
ini = ini.replace('objects/BusyBeaver/ZFC/KQ1ZF.olean','objects/QuotientSharing15Api.olean')
ini = ini.replace("'FAILED_MISSING_EXPLICIT_IMPORT'", "'FAILED_CLIENT_NAMESPACE_OPENINGS'").replace("'failed_module_excluded':'BusyBeaver.ZFC.KQ1ZF'", "'failed_module_excluded':'QuotientSharing15Api'")
ini = ini.replace("'resumed_providers':87", "'resumed_providers':193").replace("'prior_successful_fresh_invocations':19", "'prior_successful_fresh_invocations':44,'run1_successful_fresh':19,'run2_successful_fresh':25").replace("'prior_phase14_reused_providers':68", "'prior_phase14_reused_providers':149").replace("'new_fresh_module_calls_still_required':26", "'new_fresh_module_calls_still_required':1")
ini = ini.replace("for p,h in read(R/'freeze.json')['files'].items():assert sha(R/p)==h,p", "for p,h in read(R/'freeze.json')['files'].items():assert sha(R/p)==h,p\nprior_retry=Path('/tmp/k215-phase15-retry')\nfor p,h in read(prior_retry/'freeze.json')['files'].items():assert sha(prior_retry/p)==h,p")
ast.parse(ini)
(S/'initialize.py').write_text(ini)
for name in ['initialize.py', 'finalize_compatibility.py', 'primary-map.json']:
    (S/(name+'.diff')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True),(S/name).read_text().splitlines(True),fromfile='previous-retry/'+name,tofile='client-retry/'+name)))
save('repair.json', {'status':'HELD_SOURCE_ONLY_NOT_EXECUTED','original_client':str(old_client),'original_sha256':sha(old_client),'corrected_client':str(args.client),'corrected_sha256':sha(args.client),'only_change':'Add SetTheory and ProfileCollection namespace openings; all theorem statements and bodies literal.','previous_runs_remain_failed':True,'prefix_pass':193,'successful_fresh':44,'run1_successful_fresh':19,'run2_successful_fresh':25,'phase14_reused':149,'new_client_calls':1,'new_endpoint_audits':2,'production_sources_unchanged':True})
print(json.dumps({'status':'PREPARED_NOT_EXECUTED','map_sha256':sha(S/'primary-map.json'),'initializer_sha256':sha(S/'initialize.py')}, indent=2))
