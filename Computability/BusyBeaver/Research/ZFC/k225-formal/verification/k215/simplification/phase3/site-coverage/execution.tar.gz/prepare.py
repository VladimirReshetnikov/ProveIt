from pathlib import Path
import importlib.util
import json
import shutil
import sys

repo = Path('/home/codex/.codex/worktrees/ec20/Proofs')
formal = repo / 'Computability/BusyBeaver/Research/ZFC/k225-formal'
work = Path('/tmp/k215-sites-compact')
source = (formal / 'generate_sites215_lean.py').read_text()
start = source.index('    for p in joins:\n')
end = source.index('    out.append(f"theorem all_sites', start)
source = source[:start] + '''    def proof(p, indent=2):
        if p in idx:
            return f"block_{idx[p]}"
        pad = " " * (indent + 2)
        return ("(allSites_join _ _ _ _\\n" + pad + proof(p + (False,), indent + 2) +
                "\\n" + pad + proof(p + (True,), indent + 2) + ")")

''' + source[end:]
source = source.replace('f"theorem all_sites : allSites {TEST} [] {T} = true := join_root\\n\\n"',
                        'f"theorem all_sites : allSites {TEST} [] {T} = true :=\\n  {proof(())}\\n\\n"')
start = source.index('def name(')
end = source.index('def main():', start)
source = source[:start] + source[end:]
assert 'for p in joins:' not in source and ':= join_root' not in source
generator = work / 'production/k225-formal/generate_sites215_lean.py'
generator.parent.mkdir(parents=True, exist_ok=True)
generator.write_text(source)
shutil.copyfile(generator, work / generator.name)
# Run the exact producer with only its destinations redirected to a fresh folder.
spec = importlib.util.spec_from_file_location('compact', generator)
gen = importlib.util.module_from_spec(spec)
sys.path.insert(0, str(formal))
spec.loader.exec_module(gen)
gen.LEAN = work / 'regenerated'
gen.LEAN.mkdir(exist_ok=True)
gen.SITES = formal.parent / 'candidate-k215/sites215.json'
sys.argv = [str(generator), 'full', '80', '12']
gen.main()
checked = work / 'run1/workspace/BusyBeaver/ZFC/KSites215.lean'
assert (gen.LEAN / checked.name).read_bytes() == checked.read_bytes()
batch_equal = []
for path in sorted(gen.LEAN.glob('KSites215Batch*.lean')):
    assert path.read_bytes() == (repo / 'Computability/BusyBeaver/Lean/BusyBeaver/ZFC' / path.name).read_bytes()
    batch_equal.append(path.name)
assert len(batch_equal) == 9
prepare = (formal / 'prepare_k215.py').read_text()
prepare = prepare.replace('2. `generate_boot215_lean.py`, `generate_sites215_lean.py` and\n   `generate_dense215_lean.py`, by checked substitutions in the 221/219 generators.',
                          '2. `generate_boot215_lean.py` and `generate_dense215_lean.py`,\n   by checked substitutions in the 221/219 generators.')
prepare = prepare.replace('The forward-only `generate_source215_lean.py` is maintained directly; the generic\noffset-bisimulation symmetry theorem supplies its reverse implication.',
                          'The forward-only `generate_source215_lean.py` and compact\n`generate_sites215_lean.py` are maintained directly. Offset-bisimulation symmetry\nsupplies the reverse source implication; the site facade composes the checked\nblocks without repeating their paths.')
start = prepare.index('derive("generate_sites221_lean.py",')
end = prepare.index('derive("generate_dense219_lean.py",', start)
prepare = prepare[:start] + prepare[end:]
(work / 'prepare_k215.py').write_text(prepare)
(work / 'regeneration.json').write_text(json.dumps({
    'status': 'PASS', 'checked_source_reproduced_exactly': True,
    'all_nine_batch_sources_unchanged': batch_equal,
    'canonical_sources_untouched': True,
    'parameters': ['full', '80', '12'],
}, indent=2) + '\n')
print('REGENERATION_PASS', len(batch_equal), 'unchanged batches')
