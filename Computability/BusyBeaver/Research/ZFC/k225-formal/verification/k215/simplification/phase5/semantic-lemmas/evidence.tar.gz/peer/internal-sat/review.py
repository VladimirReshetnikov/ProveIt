from pathlib import Path
import hashlib,json,re
P=Path('/tmp/k215-internalsat-sharing');O=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=(P/'baseline/InternalSat.lean').read_text();new=(P/'Candidate2.lean').read_text()
names=['fZeroOrSuccF_spec','fJustifiedF_spec','justified_memAtom','justified_eqAtom','justified_bot','justified_imp','justified_and','justified_or','justified_all','justified_ex']
for name in names:
 a=old.index('theorem '+name+' ');b=new.index('theorem '+name+' ')
 assert old[a:old.index(':=',a)]==new[b:new.index(':=',b)],name
for name in ('Justified','fJustifiedF','fZeroOrSuccF'):
 pat=r'(?ms)^def '+name+r'\b.*?(?=^\s*(?:theorem|/--|/-!))'
 a=re.search(pat,old);b=re.search(pat,new);assert a and b and a[0]==b[0],name
for name in ('pair_eq_iff','numeral_eq_iff'):assert 'private theorem '+name in new
r=json.loads((P/'run2/result.json').read_bytes());b=json.loads((P/'baseline-run1/result.json').read_bytes())
assert r['status']==b['status']=='PASS' and r['axiom_reports']==b['axiom_reports']
assert r['warnings']==b['warnings']==0
assert sha(P/'run2/Candidate2WithAudit.lean')==r['source_sha256']
assert sha(P/'run2/compiler.log')==r['log_sha256']
assert (P/'Candidate2.lean').read_bytes()+(P/'Audit.lean.inc').read_bytes()==(P/'run2/Candidate2WithAudit.lean').read_bytes()
receipt={'status':'PASS_INDEPENDENT_BOUNDED_SOURCE_PEER','source_sha256':sha(P/'Candidate2.lean'),'diff_sha256':sha(P/'source-v2.diff'),'reviewer_sha256':sha(Path(__file__)),
 'scope':'Full changed proof bodies and ten exact public headers; exact Justified/fJustifiedF/fZeroOrSuccF definitions; new private pair/numeral iff helpers. Bounded saved kernel/log acknowledgment, no compiler or broad provider re-audit.',
 'mathematical_findings':['Pair equality uses both directions of injectivity/reflexivity with no extra hypotheses.','Numeral equality reflects external Nat equality via the existing natV_inj theorem; no set enumeration or native shortcut.','Eight inversion cases retain their exact witness/bit conclusions. Distinct tags eliminate precisely the other seven clauses; compatible pair components are substituted before reading the original bit relation.','The two formula-spec proofs compose already established iff clauses in the same disjunction/conjunction order.','Final certificate_functional proof and executable definitions are unaffected.'],
 'candidate_actual_sha256':sha(P/'run2/result.json'),'baseline_actual_sha256':sha(P/'baseline-run1/result.json'),'three_axiom_reports':r['axiom_reports'],'zero_warnings':True,'no_actionable_issue':True}
(O/'review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(sha(O/'review.json'))
