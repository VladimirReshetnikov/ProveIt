"""Small controls for the owned retirement/hash gate; no proof tool or producer."""
from pathlib import Path
import importlib.util,tempfile,json,hashlib
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_profile_gate',H/'check_bindings.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
with tempfile.TemporaryDirectory(prefix='phase14-profile-controls-') as d:
 p=Path(d);f=p/'file';f.write_bytes(b'pinned\n');h=hashlib.sha256(f.read_bytes()).hexdigest()
 def case(name,expect,fn):
  try:fn();ok=True
  except ValueError:ok=False
  assert ok==expect,name
  rows.append({'name':name,'expected_accept':expect,'passed':True})
 case('exact current/before file',True,lambda:m.check_file(f,h))
 case('retired path absent',True,lambda:m.check_file(p/'absent',None))
 case('changed before bytes',False,lambda:m.check_file(f,'0'*64))
 case('missing before file',False,lambda:m.check_file(p/'missing',h))
 case('unretired ordinary file',False,lambda:m.check_file(f,None))
 link=p/'dangling';link.symlink_to(p/'missing-target')
 case('retirement rejects dangling symlink',False,lambda:m.check_file(link,None))
 case('before regular-file gate rejects symlink',False,lambda:m.check_file(link,h))
print(json.dumps({'status':'PASS_METADATA_ONLY','positive':2,'negative':5,'cases':rows,'helper_sha256':hashlib.sha256((H/'check_bindings.py').read_bytes()).hexdigest(),'no_compiler_or_generator':True},indent=2))
