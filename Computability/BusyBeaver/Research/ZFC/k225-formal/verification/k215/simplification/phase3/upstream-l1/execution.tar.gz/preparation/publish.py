"""Prepare a compact copy map after all isolated upstream-integration checks pass."""
from pathlib import Path
import hashlib,json,gzip,tarfile,io,shutil,subprocess,difflib
P=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
run=P/'run2';result=json.loads((run/'result.json').read_text())
assert result['status']=='PASS' and result['input_post'] and result['private_objects_post']
assert len(result['checks'])==8 and all(r['status']=='PASS' and r['warnings']==0 for r in result['checks'])
assert [r['expected_axiom_reports'] for r in result['checks'][-3:]]==[3,2,8]
# Recheck the exact completed outputs, copied inputs and each raw log before packaging.
for row in result['checks']:
 m=row['module'];s=Path(row['command'][-1]);o=Path(row['command'][-2])
 assert sha(s)==row['source_sha256'] and sha(o)==row['object_sha256'] and sha(row['log'])==row['log_sha256']
for name in ['EnumPerm','L2RootPerm','SeedPerm']:
 assert (P/'candidate/BusyBeaver/ZFC'/(name+'.lean')).read_bytes()==(P/'run1/source/BusyBeaver/ZFC'/(name+'.lean')).read_bytes()
 f=P/'candidate/BusyBeaver/ZFC'/(name+'.lean')
 (P/(name+'.integration.diff')).write_text(''.join(difflib.unified_diff((P/'upstream'/f.name).read_text().splitlines(True),f.read_text().splitlines(True),fromfile='upstream/'+f.name,tofile='integrated/'+f.name)))
 (P/(name+'.current-to-integrated.diff')).write_text(''.join(difflib.unified_diff((P/'current'/f.name).read_text().splitlines(True),f.read_text().splitlines(True),fromfile='frozen185/'+f.name,tofile='integrated/'+f.name)))
packet=P/'publication';packet.mkdir(exist_ok=False);files=packet/'files'
base=Path('Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase3/upstream-l1')
evidence=files/base;evidence.mkdir(parents=True)
for name in ['EnumPerm','L2RootPerm','SeedPerm']:
 dest=files/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC'/(name+'.lean');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/'candidate/BusyBeaver/ZFC'/dest.name,dest)
source_review=json.loads((P/'source-review.json').read_text())
receipt={'status':'PASS_ISOLATED_UPSTREAM_INTEGRATION','upstream_commit':'021d848979b670f702cd92ae7bb85ea888847742','fetched_origin':'cd2c1eee7b','module_checks':5,'typed_clients':3,'own_failed_audits_preserved':1,'typed_axiom_reports':13,'warnings':0,'source_lines_before':975,'source_lines_after':888,'lines_removed':87,'result_sha256':sha(run/'result.json'),'basis_scope':'215 accepted phase-one objects copied privately;201 reachable project modules in the endpoint dependency graph. Five affected modules were recompiled. This is not the current185-module full build.','semantic_scope':'All-natural equality of the old four-branch execAt and decode/cstep implementation, general and zero-start L1, unchanged dense215 machine and both ZFC-refutation/consistency endpoint clients. No internal PA theorem claim.','canonical_adoption':'Pending root coordination after frozen185 terminal; this publisher changes only scratch.'}
(evidence/'review.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.copyfile(run/'result.json',evidence/'result.json')
shutil.copyfile(P/'source-review.json',evidence/'source-review.json')
shutil.copyfile(P/'audit-v2/DraftAudit.lean',evidence/'DraftAudit.lean')
for name in ['DraftAudit','EndpointAudit215','K215Audit']:
 row=next(r for r in result['checks'] if r['module']==name);shutil.copyfile(row['log'],evidence/(name+'.log'))
members={}
def add(label,f):
 assert label not in members;members[label]=Path(f).read_bytes()
for n in ['prepare.py','check.py','check_audits_v2.py','publish.py','source-review.json','adoption-map.pending.json'] :add('preparation/'+n,P/n)
for folder in ['current','parent','upstream','history','audit','audit-v2']:
 for f in sorted((P/folder).rglob('*')):
  if f.is_file():add('preparation/'+str(f.relative_to(P)),f)
for f in sorted(P.glob('*.diff')):add('preparation/'+f.name,f)
for number in ['run1','run2']:
 runpath=P/number
 for f in sorted(runpath.rglob('*')):
  if f.is_file() and 'objects' not in f.relative_to(runpath).parts and f.suffix not in ['.olean','.ilean','.pyc']:
   add('execution/'+number+'/'+str(f.relative_to(runpath)),f)
idx={n:{'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d)} for n,d in sorted(members.items())}
with (evidence/'execution.tar.gz').open('wb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for n,d in sorted(members.items()):
    i=tarfile.TarInfo(n);i.size=len(d);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(d))
(evidence/'index.json').write_text(json.dumps(idx,indent=2)+'\n')
(evidence/'README.md').write_text('''# General L1 theorem for the permuted enumerator

Upstream commit `021d848979` replaces the duplicated zero-start and seed 4 completeness arguments by `EnumPerm.halts_iff`: from any state between candidates with derivable current/cache/stack entries, halting is equivalent to a finite derivation of falsity. The counter may start anywhere. Decoding a numerical command is separated from its register effect; the seed theorem becomes one application of L1.

The integrated source retains the existing `Contract.continue`, `cexec_ax_pop`, and combined step-soundness helpers. Its GEN/MP/bundle contracts keep the shorter compositional proofs. The three changed files total 888 lines, down from 975 in the frozen phase-two sources. Unused zero-start and per-row wrappers are removed; the production consumer census found no external callers. Historical audit snapshots retain their original meaning and sources.

Five affected modules passed: EnumPerm, L2AxiomsPerm, L2RootPerm, SeedPerm and KEndpoint215. Three typed clients then passed with 13 axiom reports and no warnings. [DraftAudit.lean](DraftAudit.lean) proves exact equality with the original four-branch command semantics for every numerical input/state, plus the general and zero-start L1 interfaces. The two unchanged endpoint audit clients instantiate the exact 215-state dense machine and the ZFC finite-refutation predicate. Reports contain only Lean's standard axioms, or no axioms. This is no claim of an internal PA proof.

[result.json](result.json) preserves exact commands, source/object/dependency/compiler hashes, raw-log hashes, limits and postchecks. The run copied 215 accepted phase-one objects into a private cache; 201 modules are reachable from that historical endpoint. Only the five affected modules and three clients were freshly compiled, using one worker, 12 GiB and 120 seconds per invocation under the shared compiler lock. The five modules passed in run1; after the own audit-only correction, the three clients passed in run2. This is separate from the 185-module phase-two checkpoint and the later current-closure adoption check. No canonical source or old cache was modified.

[review.json](review.json) and [source-review.json](source-review.json) record the outcome and source boundary. [execution.tar.gz](execution.tar.gz), bound member-by-member by [index.json](index.json), retains exact upstream/parent/frozen sources, integration diffs, executed runner, source snapshots, logs and the accepted basis ledger; it excludes compiled objects. The historical runner uses its recorded scratch paths. After adoption the maintained fresh Lean driver is the independent complete reproduction route.

The upstream proof design is attributed to commit 021d848979 by Vladimir Reshetnikov and its recorded coauthor. The integration and fresh checks are separate. An own declaration-extractor error before candidate output is retained; the initial independent semantic audit failed because its proof split the same selector independently on both sides. Its exact source/log, including the failed sorryAx report, remain in run1 and are excluded; run2 changes only that audit proof and passes all three clients. Root coordinates canonical adoption after the frozen checkpoint closes, preserving both records.
''')
maprows=[]
for f in sorted(files.rglob('*')):
 if f.is_file():maprows.append({'source':str(f),'target':str(f.relative_to(files)),'sha256':sha(f),'bytes':f.stat().st_size})
mapdata={'status':'PASS_READY_FOR_ROOT_COORDINATED_COPY','files':maprows,'canonical_sources':source_review['files'],'scope':receipt}
(packet/'copy-map.json').write_text(json.dumps(mapdata,indent=2)+'\n')
print(json.dumps({'map':str(packet/'copy-map.json'),'map_sha256':sha(packet/'copy-map.json'),'files':len(maprows),'archive_members':len(idx),'archive_bytes':(evidence/'execution.tar.gz').stat().st_size},indent=2))
