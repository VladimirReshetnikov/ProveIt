"""Seal the legacy plan only after exact phase8 primary and root byte review PASS.
Read-only provider checks; writes scratch metadata only. Does not invoke a compiler.
"""
from pathlib import Path
import json,hashlib,sys,shutil
sys.dont_write_bytecode=True
from gates import *
H=Path(__file__).resolve().parent
P=Path('/tmp/k215-proof-phase8/lean-run1');R=Path('/tmp/k215-proof-phase8/root-actual-review.json');L=Path('/tmp/k215-phase7-legacy/run1')
assert not (H/'freeze.json').exists()
pr=read(P/'result.json');pi=read(P/'inventory.json');pd=read(P/'completed.json');review=read(R)
assert sha(P/'result.json')=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
assert pr['status']=='PASS'and pr['primary_project_modules']==188 and pr['typed_audits']==2 and pr['axiom_reports']==10
primary_review(review,sha(P/'result.json'))
assert sha(P/'inventory.json')==pr['inventory_sha256']and sha(P/'completed.json')==pr['completed_sha256']
prepared=read(H/'prepared-inventory.json');prep=read(H/'preparation.json');assert pi==prepared['primary']
for path,h in {**prep['metadata_and_provider_inputs'],**prep['registered_files']}.items():assert sha(path)==h,path
assert read(P/'toolchain.json')==read(L/'toolchain.json')
for row in pi['modules']:
 m=row['module'];valid_record(row,pd[m],pd,P/'objects'/(m.replace('.','/')+'.olean'))
ld=read(L/'completed.json');records={**pd,**{m:ld[m]for m in EXTRA}}
mismatches=[]
for row in prepared['union']['modules']:
 m=row['module']
 if m not in EXTRA:continue
 deps={d:records[d]['object_sha256']for d in row['imports']if d in records}
 if reuse_record(row,ld[m],deps):valid_record(row,ld[m],records,L/'objects'/(m.replace('.','/')+'.olean'))
 else:mismatches.append(m);records[m]={**records[m],'object_sha256':'PENDING-REFRESH-'+m}
assert set(mismatches)<=LEGACY_AFFECTED
assert sha(H/'LegacyAudit.lean')==read(L/'result.json')['audit']['source_sha256']
shutil.copyfile(H/'preparation.json',H/'history/preparation-before-primary-pass.json')
prep['primary_gate']={'run':str(P),'review':str(R),'review_sha256':sha(R),'files':{n:sha(P/n)for n in ['result.json','inventory.json','completed.json','toolchain.json']}}
prep['status']='PREPARED_PRIMARY_PASS_AND_ROOT_REVIEW_BOUND_NO_LEGACY_COMPILER'
save(H/'preparation.json',prep)
save(H/'actual-plan.json',{'status':'PASS_READ_ONLY_ACTUAL_PROVIDER_PLAN','primary_result_sha256':sha(P/'result.json'),'primary_completed_sha256':sha(P/'completed.json'),'root_primary_review_sha256':sha(R),'legacy_result_sha256':sha(L/'result.json'),'selected_modules':203,'all188_primary_sources_dependencies_objects_logs_rehashed':True,'all15_legacy_records_checked_against_selected_direct_providers':True,'required_or_downstream_refresh_candidates':mismatches,'actual_all15_reusable':not mismatches,'audit_source_sha256':sha(H/'LegacyAudit.lean'),'audit_transitive_modules':46,'fresh_audit_required':True,'compiler_invocations':[]})
print(json.dumps({'primary188':'PASS','legacy_refresh_candidates':mismatches,'audit':46,'root_review_sha256':sha(R)}))
