The formal-table successor is clean on source review. I independently parsed and compared all 430 defined actions plus all 303 finite state slots under the total three-swap state involution; outside that range both tables are absent and the map is the identity. All 202 source nodes (23 leaves) are byte-identical. The 281 blocks, 234 roles and 97 primitive actions change only their designated state-bearing fields.

The theorem now binds the actual maintained tm215 through KZipTape.table. Balanced lookup is justified by the existing all-natural/all-Boolean fast215 equality. No window, marker, consumed-prefix or route premise is weakened; source_tree_eq and primitive operands remain exact.

No compiler or transition interpreter was run. The new finite block/structure proofs remain for the parent kernel invocation. Own metadata preparation mistakes are retained under history; they did not alter candidate inputs or the successful correspondence gates.
