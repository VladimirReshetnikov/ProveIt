"""Incremental legacy refresh after independently reviewed phase7 primary PASS.

At most three legacy modules can require recompilation; actual direct-dependency
object hashes decide reuse. Always rerun the five-client audit.
No full202-module fresh-build claim. Requires explicit execution opt-in.
"""
from pathlib import Path
import argparse,fcntl,hashlib,importlib.util,json,os,shutil,signal,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
FORMAL=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal'
HELPER=FORMAL/'verification/k215/lean/build.py'
HELPER_SHA='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
LEGACY=Path('/tmp/k215-phase5-legacy/run1')
PREVIOUS=Path('/tmp/k215-proof-phase6/lean-run1')
LOCK=Path('/tmp/proveit-k215-proof-build.lock')
assert hashlib.sha256((HERE/'gates.py').read_bytes()).hexdigest() == 'b655242eb2f6ca49c040d6fa891ca02bba3ec04925744c12d7d42510d7cfbdab'
from gates import *

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--primary-run',type=Path,required=True)
 p.add_argument('--primary-live',type=Path,required=True)
 p.add_argument('--out',type=Path,required=True)
 p.add_argument('--execute-after-primary-pass',action='store_true')
 a=p.parse_args();assert a.execute_after_primary_pass,'Preparation only unless explicit execution flag supplied'
 primary,out=a.primary_run.resolve(),a.out.resolve()
 assert not out.exists(),'Use a new output directory; failures are immutable'
 freeze=read(HERE/'freeze.json')
 for name,h in freeze['driver_inputs'].items():assert sha(HERE/name)==h,name
 assert sha(HELPER)==HELPER_SHA
 spec=importlib.util.spec_from_file_location('reviewed_supervisor',HELPER)
 driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
 prepared=read(HERE/'prepared-inventory.json');prep=read(HERE/'preparation.json')
 references=read(HERE/'basis-reference.json');packet_pins(REPO,references)
 for path,h in prep['metadata_and_provider_inputs'].items():assert sha(path)==h,path
 pr,pi,pd,tool=[read(primary/n)for n in ['result.json','inventory.json','completed.json','toolchain.json']]
 live=read(a.primary_live)
 assert pr['status']=='PASS'and pr['primary_project_modules']==187 and pr['typed_audits']==2 and pr['axiom_reports']==10
 assert pr['all_private_objects_logs_and_toolchain_rechecked_after_audits']and pr['basis_unchanged']
 assert sha(a.primary_live)=='6001edc910d086af6c0921d1830165f059e90e48376d5b5900fd34549b94dd64'
 primary_review(live,sha(primary/'result.json'))
 assert sha(primary/'inventory.json')==pr['inventory_sha256']and sha(primary/'completed.json')==pr['completed_sha256']
 assert pi==prepared['primary']and set(pd)==set(graph(pi))
 li,ld,lr=[read(LEGACY/n)for n in ['inventory.json','completed.json','result.json']]
 inv=checkpoint(read(PREVIOUS/'inventory.json'),pi,li,prep['approved_source_sha256'])
 assert inv==prepared['union']and current_inventory(driver,REPO)==(pi,inv)
 assert lr['status']=='PASS'and lr['fresh_legacy_modules']==15 and lr['project_modules']==199
 for name in ['inventory.json','completed.json','result.json']:
  assert (LEGACY/name).read_bytes()==(FORMAL/'verification/k215/simplification/phase5/legacy'/name).read_bytes()
 compiler=Path(tool['lean']['path'])
 assert tool==read(PREVIOUS/'toolchain.json')==read(LEGACY/'toolchain.json')
 assert sha(compiler)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
 inputs=dict(prep['metadata_and_provider_inputs'])
 for f in [Path(__file__),HERE/'freeze.json',HERE/'gates.py',HERE/'prepared-inventory.json',HERE/'preparation.json',HERE/'basis-reference.json',HERE/'LegacyAudit.lean',a.primary_live,*[primary/n for n in ['result.json','inventory.json','completed.json','toolchain.json']]]:inputs[str(f)]=sha(f)
 for key in ['lean','lake','Init.olean','project_toolchain']:
  f=Path(tool[key]['path']);assert sha(f)==tool[key]['sha256'];inputs[str(f)]=sha(f)
 for r in inv['modules']:inputs[r['source']]=r['source_sha256']
 for r in pi['modules']:
  m=r['module'];obj=primary/'objects'/(m.replace('.','/')+'.olean')
  valid_record(r,pd[m],pd,obj);inputs[str(obj)]=sha(obj);inputs[pd[m]['log']]=pd[m]['log_sha256']
 # Every unchanged legacy source/import/selected-dependency/object/log identity must agree.
 selected={**pd,**{m:ld[m]for m in EXTRA}}
 for r in inv['modules']:
  m=r['module']
  if m in EXTRA-LEGACY_AFFECTED:valid_record(r,ld[m],selected,LEGACY/'objects'/(m.replace('.','/')+'.olean'))
 assert sha(HERE/'LegacyAudit.lean')==prep['audit_sha256']==lr['audit']['source_sha256']
 # Require all metadata still fixed before making a private overlay.
 for path,h in inputs.items():assert sha(path)==h,path
 out.mkdir(parents=True)
 with (out/'output.lock').open('a')as exclusive:
  fcntl.flock(exclusive,fcntl.LOCK_EX|fcntl.LOCK_NB)
  save(out/'before.json',inputs);save(out/'inventory.json',inv)
  save(out/'primary-completed.json',pd);save(out/'primary-result.json',pr);save(out/'primary-review.json',live)
  save(out/'legacy-completed.json',ld);save(out/'legacy-result.json',lr);save(out/'toolchain.json',tool)
  save(out/'owner.json',{'driver_sha256':sha(__file__),'gates_sha256':sha(HERE/'gates.py'),'helper_sha256':sha(HELPER),'primary':str(primary),'legacy':str(LEGACY),'primary_result_sha256':sha(primary/'result.json'),'legacy_result_sha256':sha(LEGACY/'result.json'),'affected':sorted(LEGACY_AFFECTED)})
  for f in [Path(__file__),HERE/'gates.py',HERE/'freeze.json',HERE/'LegacyAudit.lean',HERE/'preparation.json',HERE/'prepared-inventory.json',HERE/'basis-reference.json']:
   shutil.copyfile(f,out/f.name)
  shutil.copyfile(HELPER,out/'supervisor.py')
  cache=out/'objects';done={};providers={}
  for r in inv['modules']:
   m=r['module'];origin=LEGACY if m in EXTRA else primary
   obj=cache/(m.replace('.','/')+'.olean');private_parents(obj,cache);obj.parent.mkdir(parents=True,exist_ok=True)
   sourceobj=origin/'objects'/(m.replace('.','/')+'.olean');obj.symlink_to(sourceobj)
   record=ld[m]if m in EXTRA else pd[m]
   done[m]={**record,'origin':'phase5_legacy_hash_bound'if m in EXTRA else'phase7_primary_hash_bound'}
   providers[m]=str(sourceobj)
  save(out/'providers.json',providers);save(out/'completed.json',done)
  env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
  attempts=out/'attempts';attempts.mkdir();fresh=set()
  for r in inv['modules']:
   m=r['module']
   if m not in EXTRA:continue
   source=Path(r['source']);assert sha(source)==r['source_sha256']
   deps={d:done[d]['object_sha256']for d in r['imports']if d in done}
   for d,h in deps.items():assert sha(cache/(d.replace('.','/')+'.olean'))==h
   if reuse_record(r,done[m],deps):
    valid_record(r,done[m],done,cache/(m.replace('.','/')+'.olean'))
    print('REUSE',m,flush=True);continue
   assert m in LEGACY_AFFECTED,('Unexpected legacy invalidation',m)
   dest=attempts/f'{len(list(attempts.iterdir()))+1:02d}-{m}';dest.mkdir();shutil.copyfile(source,dest/source.name)
   obj=cache/(m.replace('.','/')+'.olean');private_parents(obj,cache)
   assert obj.is_symlink()and obj.resolve(strict=True)==Path(providers[m]).resolve(strict=True)
   obj.unlink() # Never write through a predecessor object symlink.
   root=str(source)[:-len(m.replace('.','/')+'.lean')].rstrip('/')
   cmd=[str(compiler),'-j1','-M12288','--root='+root,'-o',str(obj),str(source)]
   rec={'module':m,'source':str(source),'source_sha256':sha(source),'dependencies':deps,'command':cmd,'compiler_sha256':sha(compiler),'timeout_seconds':900,'memory_mebibytes':12288,'log':str(dest/'compiler.log'),'origin':'phase7_legacy_fresh'}
   print('CHECK',m,flush=True)
   ok=driver.run_locked(cmd,REPO,env,LOCK,Path(rec['log']),900,rec,dest/'record.json')
   text=Path(rec['log']).read_text();rec['warnings']=text.count('warning:')
   rec['source_unchanged']=sha(source)==rec['source_sha256'];rec['dependencies_unchanged']=all(sha(cache/(d.replace('.','/')+'.olean'))==h for d,h in deps.items())
   ok=ok and not rec['timed_out']and rec['source_unchanged']and rec['dependencies_unchanged']and not any(v in text for v in ['sorryAx',"declaration uses 'sorry'",'error:'])
   rec['status']='PASS'if ok else'FAIL'
   if ok:rec['object_sha256']=sha(obj)
   save(dest/'record.json',rec);print(rec['status'],m,round(rec['seconds'],3),flush=True)
   if not ok:raise SystemExit(1)
   done[m]=rec;fresh.add(m);save(out/'completed.json',done)
  def postcheck():
   assert current_inventory(driver,REPO)==(pi,inv)
   packet_pins(REPO,references)
   for path,h in inputs.items():assert sha(path)==h,path
   assert set(done)==set(graph(inv))
   expected={m.replace('.','/')+'.olean'for m in done}
   assert {f.relative_to(cache).as_posix()for f in cache.rglob('*')if f.is_file()}==expected
   for r in inv['modules']:
    m=r['module'];obj=cache/(m.replace('.','/')+'.olean');private_parents(obj,cache)
    provider(obj,Path(providers[m]),m in fresh)
    valid_record(r,done[m],done,obj)
  postcheck()
  auditdir=out/'audit';auditdir.mkdir();source=auditdir/'LegacyAudit.lean';shutil.copyfile(HERE/'LegacyAudit.lean',source)
  obj=auditdir/'LegacyAudit.olean';cmd=[str(compiler),'-j1','-M12288','--root='+str(auditdir),'-o',str(obj),str(source)]
  audit={'module':'LegacyAudit','source':str(source),'source_sha256':sha(source),'dependencies':{m:r['object_sha256']for m,r in done.items()},'command':cmd,'compiler_sha256':sha(compiler),'timeout_seconds':120,'memory_mebibytes':12288,'log':str(auditdir/'compiler.log'),'expected_axiom_reports':5}
  ok=driver.run_locked(cmd,REPO,env,LOCK,Path(audit['log']),120,audit,auditdir/'record.json')
  try:
   assert ok and not audit['timed_out'];audit['reports']=audit_reports(Path(audit['log']).read_text())
   assert sha(source)==audit['source_sha256']==prep['audit_sha256']
   audit['object_sha256']=sha(obj);audit['warnings']=0;audit['status']='PASS'
  except BaseException:
   audit['status']='FAIL';save(auditdir/'record.json',audit);raise
  save(auditdir/'record.json',audit)
  postcheck()
  assert sha(source)==audit['source_sha256']==prep['audit_sha256']
  assert audit_reports(Path(audit['log']).read_text())==audit['reports']
  assert sha(audit['log'])==audit['log_sha256']and sha(obj)==audit['object_sha256']
  # Record the exact transitive project-provider set of the unchanged audit imports.
  imports=[m for line in source.read_text().splitlines()if line.startswith('import ')for m in line[7:].split()];rows=graph(inv);reach=set()
  def visit(m):
   if m=='Init'or m in reach:return
   reach.add(m)
   for d in rows[m]['imports']:visit(d)
  for m in imports:visit(m)
  assert len(reach)==45
  result={'status':'PASS','primary_project_modules':187,'legacy_only_modules':15,'project_modules':202,'fresh_legacy_modules':len(fresh),'reused_legacy_modules':len(EXTRA-fresh),'fresh_modules':sorted(fresh),'reused_modules':sorted(EXTRA-fresh),'potentially_affected_legacy_modules':sorted(LEGACY_AFFECTED),'new_legacy_audit_executed':True,'audit':audit,'audit_transitive_project_providers':{m:done[m]['object_sha256']for m in sorted(reach)},'primary_result_sha256':sha(primary/'result.json'),'legacy_result_sha256':sha(LEGACY/'result.json'),'inventory_sha256':sha(out/'inventory.json'),'completed_sha256':sha(out/'completed.json'),'all202_selected_objects_sources_dependencies_logs_rechecked_after_audit':True,'immutable_basis_inputs_rechecked_after_audit':True,'scope':'187 terminal phase7 primary providers plus15 retained legacy interfaces, reused or refreshed by exact direct-dependency object identity; unchanged five-client audit freshly compiled. No full202-module fresh replay.'}
  save(out/'result.json',result);print('TERMINAL PASS',flush=True)
if __name__=='__main__':
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
 main()
