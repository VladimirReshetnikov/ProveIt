from pathlib import Path
p=Path(__file__).parent
src=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Lean/BusyBeaver/ZFC/ConstructibleAbs.lean').read_text()
(p/'ConstructibleAbs.before.lean').write_text(src)
marker='/-- Equality of a constructible set with an ambient set, by extensionality. -/'
helpers='''/-- Bounded quantifiers agree because every member of a constructible set is constructible. -/
private theorem forall_memL_iff (A : {x // InL H hP x}) (P : V → Prop) :
    (∀ x : {x // InL H hP x}, memL H hP x A → P x.1) ↔ ∀ x, mem x A.1 → P x :=
  ⟨fun h x hx => h ⟨x, inL_trans H hR hP A.2 hx⟩ hx, fun h x hx => h x.1 hx⟩

private theorem exists_memL_iff (A : {x // InL H hP x}) (P : V → Prop) :
    (∃ x : {x // InL H hP x}, memL H hP x A ∧ P x.1) ↔ ∃ x, mem x A.1 ∧ P x :=
  ⟨fun ⟨x, hx, h⟩ => ⟨x.1, hx, h⟩, fun ⟨x, hx, h⟩ => ⟨⟨x, inL_trans H hR hP A.2 hx⟩, hx, h⟩⟩

'''
src=src.replace(marker,helpers+marker)
a=src.index('  unfold inductiveV',src.index('theorem inductive_iff'));b=src.index('\ntheorem inL_omega',a)
src=src[:a]+'''  simp only [inductiveV, val_vempty H hR hP, val_vsucc H hR hP, forall_memL_iff H hR hP]
'''+src[b:]
a=src.index('  constructor\n',src.index('  have hc1 :',src.index('theorem quant_clause')));b=src.index('\n/-- **The certificate step',a)
src=src[:a]+'''  simp only [codeEq_iff H hR hP, natEq_iff H hR hP, hT,
    forall_memL_iff H hR hP, exists_memL_iff H hR hP]
  constructor
  · rintro ⟨c1, hc, h⟩; exact ⟨c1.1, hc, h⟩
  · rintro ⟨c1, hc, h⟩; exact ⟨⟨c1, hc1 c1 hc⟩, hc, h⟩
'''+src[b:]
old='''    · exact ⟨fun h z hz => h ⟨z, inL_trans H hR hP S.2 hz⟩ hz, fun h z hz => h z.1 hz⟩'''
assert src.count(old)==2
src=src.replace(old,'''    · exact forall_memL_iff H hR hP S _''')
a=src.index('  have htr :',src.index('theorem ord_iff'));b=src.index('\n/-- **`V = L`',a)
src=src[:a]+'''  simp only [InternalOrd.Ord, Trans, forall_memL_iff H hR hP]
'''+src[b:]
(p/'ConstructibleAbs.lean').write_text(src)
