from pathlib import Path
import ast,hashlib,json,re
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
# Reuse only our pure lexical comment stripper, not the preparing program.
t=ast.parse((O/'prepare.py').read_text());f=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='strip_comments');e={};exec(compile(ast.Module(body=[f],type_ignores=[]),'own-comment-stripper','exec'),e);strip=e['strip_comments']
def blocks(text):
 text=strip(text);ms=list(re.finditer(r'(?m)^(?:theorem|def|inductive|class|instance)\b(?:\s+([^\s:(]+))?',text));return {m[1]:text[m.start():ms[i+1].start()if i+1<len(ms)else len(text)].strip()for i,m in enumerate(ms)if m[1]}
checks={}
for n,decls in [('KThmK',['ThmK','EqFree','QF']),('KEind222',['wa','biff','Bin','Bout','Ev','aux','Eind','th','fresh3','irNF'])]:
 old=blocks((O/'before'/(n+'.lean')).read_text());new=blocks((O/'candidate/BusyBeaver/ZFC'/(n+'.lean')).read_text())
 for d in decls:assert old[d]==new[d],(n,d)
 checks[n]=decls
comparison=load(O/'comparison.json');rows=[]
for n,ns in [('DerivedRows14Api',['deduction','vacuity','atomic_rewrite']),('ThmKDerived14Api',['reflexivity','leibniz','specialization','alpha']),('KEindDerived14Api',['interpretation','completeness'])]:
 p=O/'clients'/(n+'.lean');s=p.read_text();assert re.findall(r'^#print axioms (\S+)',s,re.M)==ns
 assert not re.search(r'\b(sorry|admit|axiom|native_decide)\b',strip(s))
 rows.append({'module':n,'source':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'imports':re.findall(r'^import (\S+)',s,re.M),'reports':[n+'.'+x for x in ns],'report_axioms':None,'axiom_policy':'Prospective: standard subset only; derive and freeze exact arrays from first isolated Lean output. No execution in this preparation.'})
(O/'clients.json').write_text(json.dumps({'status':'PROPOSED_TYPED_CLIENTS_NOT_COMPILED','clients':rows,'named_report_count':9,'definitions_checked_exact':checks,'source_read_types':'Explicit polymorphic and concrete interfaces, no omitted required hypotheses.'},indent=2)+'\n')
files={str(p.relative_to(O)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(O.rglob('*'))if p.is_file()and p.name!='freeze.json'}
(O/'freeze.json').write_text(json.dumps({'status':'HELD_SOURCE_REVIEWED_CANDIDATE_AND_API_CLIENTS_UNCOMPILED','files':files,'source_rows':comparison['rows'],'clients':rows,'metrics':comparison['metrics'],'comparison_sha256':sha(O/'comparison.json'),'notes_sha256':sha(O/'README.md'),'source_attribution':'Four preserved ac61181dda upstream files, plus exact root-proposed sole-use of_der inlining. Current proof baseline1244fd48 unchanged.','no_compiler_or_producer_or_canonical_write':True},indent=2)+'\n')
print(json.dumps({'status':'HELD','freeze_sha256':sha(O/'freeze.json'),'files':len(files),'client_reports':9}))
