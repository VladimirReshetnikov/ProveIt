from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

repo = Path('/home/codex/.codex/worktrees/ec20/Proofs')
formal = repo / 'Computability/BusyBeaver/Research/ZFC/k225-formal'
work = Path('/tmp/k215-sites-compact')
target = work / 'prepare-control/Computability/BusyBeaver/Research/ZFC/k225-formal'
target.mkdir(parents=True, exist_ok=False)
for name in ['generate_boot221_lean.py', 'generate_dense219_lean.py', 'generate_tables_lean.py',
             'generate_source215_lean.py']:
    shutil.copyfile(formal / name, target / name)
for name in ['prepare_k215.py', 'generate_sites215_lean.py']:
    shutil.copyfile(work / name, target / name)
candidate = target.parent / 'candidate-k215'
candidate.mkdir()
for name in ['k215.native.tm', 'canonicalization.json']:
    shutil.copyfile(formal.parent / 'candidate-k215' / name, candidate / name)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
before = {name: sha(target / name) for name in ['generate_sites215_lean.py', 'generate_source215_lean.py']}
with (work / 'prepare-control.log').open('w') as log:
    result = subprocess.run([sys.executable, '-B', str(target / 'prepare_k215.py')],
                            cwd=target, stdout=log, stderr=subprocess.STDOUT, timeout=30)
assert result.returncode == 0
assert before == {name: sha(target / name) for name in before}
outputs = ['generate_boot215_lean.py', 'generate_dense215_lean.py', 'generate_tables_lean.py',
           'lean215/labels.json', 'lean215/k215_k230labels.tm']
for name in outputs:
    assert (target / name).read_bytes() == (formal / name).read_bytes(), name
(work / 'prepare-control.json').write_text(json.dumps({
    'status': 'PASS', 'maintained_generators_unchanged': before,
    'other_outputs_exactly_unchanged': {name: sha(target / name) for name in outputs},
    'canonical_sources_untouched': True,
}, indent=2) + '\n')
print('PREPARE_CONTROL_PASS')
