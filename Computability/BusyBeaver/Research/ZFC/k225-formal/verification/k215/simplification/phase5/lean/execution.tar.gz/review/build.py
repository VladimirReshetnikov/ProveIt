"""Check the next source checkpoint against the immutable phase4 closure.

This is an incremental check, with a private object overlay and immutable
reused-provider symlinks. It never
rewrites the earlier inventory, objects, compilation records, or audit logs.
"""
from pathlib import Path
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import signal

REPO = Path('/home/codex/.codex/worktrees/ec20/Proofs')
FORMAL = REPO / 'Computability/BusyBeaver/Research/ZFC/k225-formal'
BASIS = Path('/tmp/k215-proof-phase4/lean-run1')
HELPER = FORMAL / 'verification/k215/lean/build.py'
COMPILER = Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
LOCK = Path('/tmp/proveit-k215-proof-build.lock')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')

def abort(*_):
    raise KeyboardInterrupt('SIGTERM')

signal.signal(signal.SIGTERM, abort)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
with (out / 'output.lock').open('a') as exclusive:
    fcntl.flock(exclusive, fcntl.LOCK_EX | fcntl.LOCK_NB)
    baseline = read(BASIS / 'result.json')
    assert baseline['status'] == 'PASS' and baseline['primary_project_modules'] == 185
    old = read(BASIS / 'completed.json')
    old_inventory = read(BASIS / 'inventory.json')
    assert len(old) == 185
    assert sha(BASIS / 'completed.json') == baseline['completed_sha256']
    assert sha(BASIS / 'inventory.json') == baseline['inventory_sha256']
    old_sources = {e['module']: e for e in old_inventory['modules']}
    basis_logs = {}
    basis_objects = {}
    for module, record in old.items():
        assert record['status'] == 'PASS' and record.get('exit_code', 0) == 0
        assert not record.get('timed_out', False)
        assert record['source_sha256'] == old_sources[module]['source_sha256']
        assert record['dependencies'] == {
            dep: old[dep]['object_sha256']
            for dep in old_sources[module]['imports'] if dep in old
        }
        obj = BASIS / 'objects' / (module.replace('.', '/') + '.olean')
        assert sha(obj) == record['object_sha256']
        basis_objects[module] = sha(obj)
        log = Path(record['log'])
        assert sha(log) == record['log_sha256']
        basis_logs[module] = str(log)
    toolchain = read(BASIS / 'toolchain.json')

    def check_toolchain():
        for key in ('lean', 'lake', 'Init.olean', 'project_toolchain'):
            assert sha(toolchain[key]['path']) == toolchain[key]['sha256'], key
        assert sha(COMPILER) == toolchain['lean']['sha256']

    check_toolchain()
    spec = importlib.util.spec_from_file_location('reviewed_driver', HELPER)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    inventory = driver.inventory(REPO)
    assert len(inventory['modules']) == 184 and inventory['external_imports'] == ['Init']
    project = {e['module'] for e in inventory['modules']}
    assert set(old) - project == {'BusyBeaver.ZFC.RMOffsetBisim'}
    assert project <= set(old)
    owner = {
        'repo': str(REPO), 'script_sha256': sha(__file__),
        'helper_sha256': sha(HELPER), 'compiler_sha256': sha(COMPILER),
        'basis_result_sha256': sha(BASIS / 'result.json'),
        'basis_completed_sha256': sha(BASIS / 'completed.json'),
        'basis_inventory_sha256': sha(BASIS / 'inventory.json'),
        'basis_toolchain_sha256': sha(BASIS / 'toolchain.json'),
    }
    if (out / 'owner.json').exists():
        assert read(out / 'owner.json') == owner
        assert read(out / 'inventory.json') == inventory, 'Source checkpoint changed'
        done = read(out / 'completed.json')
    else:
        assert {p.name for p in out.iterdir()} == {'output.lock'}
        save(out / 'owner.json', owner)
        save(out / 'inventory.json', inventory)
        save(out / 'basis-completed.json', old)
        save(out / 'basis-inventory.json', old_inventory)
        save(out / 'basis-logs.json', basis_logs)
        save(out / 'toolchain.json', toolchain)
        shutil.copyfile(HELPER, out / 'reviewed-driver.py')
        done = {}
        for module, record in old.items():
            if module not in project:
                continue
            obj = out / 'objects' / (module.replace('.', '/') + '.olean')
            obj.parent.mkdir(parents=True, exist_ok=True)
            # Immutable reused providers stay in the pinned predecessor cache.
            # A changed target is unlinked before the compiler is invoked.
            obj.symlink_to(BASIS / 'objects' / (module.replace('.', '/') + '.olean'))
            done[module] = {
                'module': module, 'status': 'PASS', 'origin': 'phase4_hash_bound',
                'source_sha256': record['source_sha256'],
                'dependencies': record['dependencies'],
                'object_sha256': record['object_sha256'],
                'log': basis_logs[module], 'log_sha256': record['log_sha256'],
            }
        save(out / 'completed.json', done)
    cache = out / 'objects'
    env = os.environ.copy()
    env['LEAN_PATH'] = str(cache)
    env['LEAN_NUM_THREADS'] = '1'
    attempts = out / 'attempts'
    attempts.mkdir(exist_ok=True)
    for entry in inventory['modules']:
        module = entry['module']
        source = Path(entry['source'])
        assert sha(source) == entry['source_sha256'], module
        deps = {dep: done[dep]['object_sha256'] for dep in entry['imports'] if dep in project}
        for dep, expected in deps.items():
            assert sha(cache / (dep.replace('.', '/') + '.olean')) == expected
        obj = cache / (module.replace('.', '/') + '.olean')
        record = done[module]
        assert sha(record['log']) == record['log_sha256']
        if (record['source_sha256'] == entry['source_sha256']
                and record['dependencies'] == deps
                and obj.is_file()
                and record['object_sha256'] == sha(obj)):
            continue
        attempt = attempts / f'{1 + len(list(attempts.iterdir())):03d}-{module}'
        attempt.mkdir()
        shutil.copyfile(source, attempt / source.name)
        root = str(source)[:-len(module.replace('.', '/') + '.lean')].rstrip('/')
        command = [str(COMPILER), '-j1', '-M12288', '--root=' + root, '-o', str(obj), str(source)]
        record = {
            'module': module, 'source': str(source), 'source_sha256': entry['source_sha256'],
            'dependencies': deps, 'command': command, 'compiler_sha256': sha(COMPILER),
            'timeout_seconds': 900, 'memory_mebibytes': 12288,
            'log': str(attempt / 'compiler.log'), 'origin': 'phase5_fresh',
        }
        obj.unlink(missing_ok=True)
        print('CHECK', module, flush=True)
        ok = driver.run_locked(command, REPO, env, LOCK, attempt / 'compiler.log', 900,
                               record, attempt / 'record.json')
        record['source_unchanged'] = sha(source) == entry['source_sha256']
        record['dependencies_unchanged'] = all(
            sha(cache / (dep.replace('.', '/') + '.olean')) == expected
            for dep, expected in deps.items())
        log_text = Path(record['log']).read_text()
        record['warnings'] = log_text.count('warning:')
        ok = (ok and record['source_unchanged'] and record['dependencies_unchanged']
              and 'sorryAx' not in log_text and "declaration uses 'sorry'" not in log_text)
        record['status'] = 'PASS' if ok else 'FAIL'
        if ok:
            record['object_sha256'] = sha(obj)
        save(attempt / 'record.json', record)
        print(record['status'], module, round(record['seconds'], 3), flush=True)
        if not ok:
            print(log_text[-18000:], flush=True)
            raise SystemExit(1)
        done[module] = record
        save(out / 'completed.json', done)

    def check_current():
        assert driver.inventory(REPO) == inventory, 'Sources changed during check'
        assert set(done) == project
        assert {str(p.relative_to(cache)) for p in cache.rglob('*.olean')} == {
            module.replace('.', '/') + '.olean' for module in project}
        for module, record in done.items():
            obj = cache / (module.replace('.', '/') + '.olean')
            if record['origin'] == 'phase4_hash_bound':
                assert obj.is_symlink()
                assert obj.resolve(strict=True) == (BASIS / 'objects' / (module.replace('.', '/') + '.olean')).resolve(strict=True)
            else:
                assert record['origin'] == 'phase5_fresh' and not obj.is_symlink()
        check_toolchain()
        assert sha(HELPER) == owner['helper_sha256']
        for entry in inventory['modules']:
            module = entry['module']
            record = done[module]
            assert record['status'] == 'PASS'
            assert sha(entry['source']) == record['source_sha256'] == entry['source_sha256']
            assert sha(cache / (module.replace('.', '/') + '.olean')) == record['object_sha256']
            assert sha(record['log']) == record['log_sha256']
            assert record['dependencies'] == {
                dep: done[dep]['object_sha256'] for dep in entry['imports'] if dep in project}
        assert sha(BASIS / 'result.json') == owner['basis_result_sha256']
        assert sha(BASIS / 'completed.json') == owner['basis_completed_sha256']
        assert sha(BASIS / 'inventory.json') == owner['basis_inventory_sha256']
        assert sha(BASIS / 'toolchain.json') == owner['basis_toolchain_sha256']
        for module, expected in basis_objects.items():
            assert sha(BASIS / 'objects' / (module.replace('.', '/') + '.olean')) == expected
            assert sha(basis_logs[module]) == old[module]['log_sha256']

    check_current()
    auditdir = out / f'audit-{1 + len(list(out.glob("audit-*"))):03d}'
    auditdir.mkdir()
    audits = []
    for name, expected in [('EndpointAudit215', 2), ('K215Audit', 8)]:
        import re
        source = FORMAL / 'verification/k215/lean' / (name + '.lean')
        target = auditdir / source.name
        shutil.copyfile(source, target)
        obj = auditdir / (name + '.olean')
        command = [str(COMPILER), '-j1', '-M12288', '--root=' + str(auditdir),
                   '-o', str(obj), str(target)]
        record = {
            'module': name, 'source': str(source), 'source_sha256': sha(target),
            'command': command, 'dependencies': {m: done[m]['object_sha256'] for m in done},
            'project_modules': 184, 'timeout_seconds': 120,
            'compiler_sha256': sha(COMPILER), 'log': str(auditdir / (name + '.log')),
        }
        ok = driver.run_locked(command, REPO, env, LOCK, Path(record['log']), 120,
                               record, auditdir / (name + '.json'))
        log_text = Path(record['log']).read_text()
        reports = re.findall(r'depends on axioms: \[([^]]*)\]', log_text)
        ok = (ok and 'warning:' not in log_text and 'error:' not in log_text
              and 'sorryAx' not in log_text
              and len(reports) + log_text.count('does not depend on any axioms') == expected
              and all({a.strip() for a in report.split(',')} <=
                      {'propext', 'Classical.choice', 'Quot.sound'} for report in reports)
              and sha(target) == sha(source) == record['source_sha256'])
        record['status'] = 'PASS' if ok else 'FAIL'
        record['reports'] = reports
        record['expected_reports'] = expected
        if ok:
            record['object_sha256'] = sha(obj)
        save(auditdir / (name + '.json'), record)
        print('AUDIT', name, record['status'], flush=True)
        if not ok:
            print(log_text, flush=True)
            raise SystemExit(1)
        audits.append(record)
    check_current()  # Rehash every private object and its log after typed audits.
    for record in audits:
        name = record['module']
        assert sha(auditdir / (name + '.lean')) == record['source_sha256']
        assert sha(auditdir / (name + '.olean')) == record['object_sha256']
        assert sha(record['log']) == record['log_sha256']
        assert record['dependencies'] == {m: done[m]['object_sha256'] for m in done}
    result = {
        'status': 'PASS', 'primary_project_modules': 184, 'basis_project_modules': 185, 'external_imports': ['Init'],
        'fresh_modules': sum(r['origin'] == 'phase5_fresh' for r in done.values()),
        'reused_modules': sum(r['origin'] == 'phase4_hash_bound' for r in done.values()),
        'typed_audits': 2, 'axiom_reports': 10,
        'project_linter_warnings': sum(Path(r['log']).read_text().count('warning:')
                                       for r in done.values()),
        'all_private_objects_logs_and_toolchain_rechecked_after_audits': True,
        'basis_unchanged': True, 'inventory_sha256': sha(out / 'inventory.json'),
        'completed_sha256': sha(out / 'completed.json'), 'audits': audits,
        'scope': 'Incremental184-module closure against the immutable185-module phase4 checkpoint; '
                 'all reused inputs hash-bound. Not a new full fresh184-module replay.',
    }
    save(out / 'result.json', result)
    print('COMPLETE', json.dumps({k: v for k, v in result.items() if k != 'audits'}), flush=True)
