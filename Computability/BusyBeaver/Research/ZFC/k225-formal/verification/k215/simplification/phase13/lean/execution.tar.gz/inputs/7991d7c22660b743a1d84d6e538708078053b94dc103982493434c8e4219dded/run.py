"""Record the exact approved command and its real terminal status; no inference from logs."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,subprocess,time
S=Path('/tmp/k215-phase13-upstream-check');O=Path(__file__).resolve().parent
R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--plan',type=Path,required=True);a.add_argument('--label',required=True);args=a.parse_args()
assert args.label in ['primary-run1','compatibility-run1']
freeze=S/'freeze.json';assert sha(freeze)=='01c6f3c207490dd3cab316ec849537a0cddf136679fba1717ace5f199e4421ba'
f=json.loads(freeze.read_text());before={str(S/p):sha(S/p)for p in f['files']};assert before=={str(S/p):h for p,h in f['files'].items()}
peer=Path('/tmp/k215-phase13-runner-peer/review.json');assert sha(peer)=='a3895b655027304974c340482d7af923b106630d099665a4ab7524f5a88c49aa'
plan=json.loads(args.plan.read_text());command=plan['command'];assert command[:3]==['python','-B',str(S/'build.py')]
assert command[command.index('--out')+1]==str(S/args.label)
assert ('--audit-endpoint'in command)==(args.label=='primary-run1')
record=O/(args.label+'-outer.json');stdout=O/(args.label+'.stdout.log');stderr=O/(args.label+'.stderr.log');assert not record.exists()and not stdout.exists()and not stderr.exists()
row={'command':command,'cwd':str(R),'plan':str(args.plan),'plan_sha256':sha(args.plan),'freeze_sha256':sha(freeze),'wrapper_sha256':sha(__file__),'source_peer':str(peer),'source_peer_sha256':sha(peer),'before_helper_inputs':before,'stdout':str(stdout),'stderr':str(stderr),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual outer process status only; compiler/scope acceptance remains in driver raw records and separate read-only review.'}
proc=None;exception=None;start=time.monotonic()
def stop(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,stop)
try:
 with stdout.open('x')as out,stderr.open('x')as err:
  env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
  proc=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err,start_new_session=True)
  row['pid']=proc.pid;rc=proc.wait()
except BaseException as exc:
 exception=repr(exc)
 if proc is not None and proc.poll()is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 rc=proc.returncode if proc else None
finally:
 after={p:sha(p)if Path(p).is_file()else None for p in before}
 row.update(exit_code=rc,exception=exception,seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),after_helper_inputs=after,helper_inputs_unchanged=after==before,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),plan_unchanged=sha(args.plan)==row['plan_sha256'],status='OUTER_EXIT_0'if rc==0 and exception is None else'OUTER_FAILURE')
 record.write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({k:row[k]for k in ['status','exit_code','seconds','helper_inputs_unchanged','exception']},indent=2),flush=True)
assert rc==0 and exception is None and after==before and row['plan_unchanged']
