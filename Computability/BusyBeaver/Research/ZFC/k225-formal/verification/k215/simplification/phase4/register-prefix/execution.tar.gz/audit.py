from pathlib import Path
import hashlib, importlib.util,json,os,re,shutil,signal
root=Path('/tmp/k215-segment-prefix');repo=Path('/home/codex/.codex/worktrees/ec20/Proofs');basis=Path('/tmp/k215-proof-phase3/lean-run1')
helper=repo/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';compiler=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
spec=importlib.util.spec_from_file_location('driver',helper);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
rows=[]
for name,cache in [('baseline',basis/'objects'),('candidate',root/'run3/objects')]:
 out=root/('audit-'+name);out.mkdir(exist_ok=False);source=out/'Audit.lean';shutil.copyfile(root/'Audit.lean',source)
 obj=out/'Audit.olean';env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
 row={'source_sha256':sha(source),'basis_completed_sha256':sha(basis/'completed.json'),'module_object_sha256':sha(cache/'BusyBeaver/ZFC/RMBisim.olean'),'compiler_sha256':sha(compiler),'timeout_seconds':120,'memory_mebibytes':12288}
 cmd=[str(compiler),'-j1','-M12288','--root='+str(out),'-o',str(obj),str(source)];row['command']=cmd
 ok=driver.run_locked(cmd,repo,env,Path('/tmp/proveit-k215-proof-build.lock'),out/'compiler.log',120,row,out/'result.json');text=(out/'compiler.log').read_text();row['warnings']=text.count('warning:');row['reports']=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
 assert ok and row['warnings']==0 and len(row['reports'])==4,(name,text)
 row['object_sha256']=sha(obj);(out/'result.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
assert rows[0]['reports']==rows[1]['reports']
result={'status':'PASS','typed_clients_per_run':2,'axiom_reports_per_run':4,'axiom_reports_equal':True,'reports':rows[0]['reports'],'candidate_sha256':sha(root/'RMBisim.lean'),'candidate_compiled_snapshot_sha256':sha(root/'run3/workspace/BusyBeaver/ZFC/RMBisim.lean'),'baseline_sha256':sha(root/'RMBisim.before.lean'),'audits':[{'path':str(root/('audit-'+name)/'result.json'),'sha256':sha(root/('audit-'+name)/'result.json')} for name in ('baseline','candidate')]}
assert result['candidate_sha256']==result['candidate_compiled_snapshot_sha256']
(root/'api-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
