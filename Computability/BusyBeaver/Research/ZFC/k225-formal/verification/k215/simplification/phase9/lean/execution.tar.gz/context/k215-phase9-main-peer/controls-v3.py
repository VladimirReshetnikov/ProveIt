#!/usr/bin/env python3
"""Read-only v3 metadata controls; execute selected pure/read-only functions only."""
import ast,copy,hashlib,json,re,types
from pathlib import Path
HERE=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');D=Path('/tmp/k215-phase9-main/build-v3.py');MAP=Path('/tmp/k215-phase9-main/full-v1.json');B=Path('/tmp/k215-proof-phase8/lean-run1');H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(D)=='6e6a12b50c5a3ad4fe2082e39eddfdc29d64cb8955d9fd8f83d54bcffe70bc6a';assert sha(MAP)=='7ca41f1b54b63454588eba64b9c9c69c6a0fa7901d552584b5681d4f34212bec';assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
tree=ast.parse(D.read_bytes());funcs={n.name:n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)}
class FakeFile:
 def __init__(self,p):self.p=p.p if isinstance(p,FakeFile)else p
 def is_file(self):return self.p=='object'
 def read_text(self):return fake_text[self.p]
fake_text={'log':"'Target.lemma' depends on axioms: [propext, Quot.sound]\n"};fake_hash={'object':'objecthash','log':'loghash'}
g={'Path':FakeFile,'re':re,'overrides':{'Target':{'reports':['Target.lemma']}},'row':{'module':'Target','source_sha256':'sourcehash'},'deps':{'Parent':'currentparent'},'sha':lambda p:fake_hash[p.p if isinstance(p,FakeFile)else p]}
exec(compile(ast.Module(body=[funcs['log_policy'],funcs['usable']],type_ignores=[]),'<pure log and reuse predicates>','exec'),g)
valid={'status':'PASS','source_sha256':'sourcehash','dependencies':{'Parent':'currentparent'},'object_sha256':'objecthash','log':'log','log_sha256':'loghash','exit_code':0,'timed_out':False};checks=[]
def test(name,changes=None,log=None,expected=False):
 rec=copy.deepcopy(valid);rec.update(changes or {});old=fake_text['log']
 if log is not None:fake_text['log']=log
 value=g['usable'](rec,FakeFile('object'));assert value==expected,(name,value,expected)
 checks.append({'name':name,'expected':expected,'observed':value});fake_text['log']=old
test('matching source and direct providers',expected=True)
for name,key,v in [('source change','source_sha256','changed'),('dependency change','dependencies',{'Parent':'old'}),('object change','object_sha256','changed'),('log change','log_sha256','changed'),('failed status','status','FAIL'),('nonzero exit','exit_code',1),('timeout','timed_out',True)]:test(name,{key:v})
for name,log in [('missing named report',''),('wrong named report',"'Wrong.lemma' depends on axioms: [propext]\n"),('duplicate named report',fake_text['log']*2),('nonstandard axiom',"'Target.lemma' depends on axioms: [Other.axiom]\n"),('sorry axiom',"'Target.lemma' depends on axioms: [sorryAx]\n"),('mapped warning',fake_text['log']+'warning: test\n'),('compiler error',fake_text['log']+'error: test\n')]:test(name,log=log)
test('standard Classical.choice permitted',log="'Target.lemma' depends on axioms: [Classical.choice]\n",expected=True)
g['overrides']={};test('unmapped inherited warning allowed',log=fake_text['log']+'warning: inherited\n',expected=True)
# Recompute the actual source graph with the driver's isolated read-only visitor.
htree=ast.parse(H.read_bytes());fn=next(n for n in htree.body if isinstance(n,ast.FunctionDef)and n.name=='without_comments_strings');hg={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<pure comment parser>','exec'),hg)
roots=ast.literal_eval(next(n.value for n in htree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='ROOTS'for t in n.targets)))
plan=json.loads(MAP.read_bytes());old=json.loads((B/'completed.json').read_bytes())
def graph(targets,overrides=None):
 v={'R':R,'Path':Path,'re':re,'sha':sha,'driver':types.SimpleNamespace(ROOTS=roots,without_comments_strings=hg['without_comments_strings']),'overrides':overrides if overrides is not None else {x['module']:x for x in plan['modules']},'old':old,'rows':[],'seen':set(),'active':set(),'external':set(),'inputs':{}}
 exec(compile(ast.Module(body=[funcs['visit']],type_ignores=[]),'<read-only source traversal>','exec'),v)
 for target in targets:v['visit'](target)
 return v['rows']
for row in plan['modules']:assert sha(row['source'])==row['source_sha256']
union=graph(['BusyBeaver.ZFC.KEndpoint215','BusyBeaver.ZFC.KDecoderPrefix215']);primary=graph(['BusyBeaver.ZFC.KEndpoint215'])
assert len(union)==197 and len(primary)==192
saved=json.loads(Path('/tmp/k215-phase9-main/full-run1/inventory.json').read_bytes());assert union==saved['modules']
bad={x['module']:copy.deepcopy(x)for x in plan['modules']};bad['BusyBeaver.ZFC.KRuntimeCore']['imports']=[]
try:graph(['BusyBeaver.ZFC.KEndpoint215'],bad)
except AssertionError:checks.append({'name':'registered import delta rejected','expected':False,'observed':False})
else:raise AssertionError('changed registered import accepted')
basis=json.loads((B/'result.json').read_bytes());assert sha(B/'completed.json')==basis['completed_sha256'];assert sha(B/'inventory.json')==basis['inventory_sha256']
reuse=plan['reuse_ledger'];rb=Path(reuse['directory'])
for n in ['result.json','inventory.json','completed.json']:assert sha(rb/n)==reuse[n]
# Pin scope/data only: no actual output object's or compiler log's bytes are read here.
out={'status':'PASS_BOUNDED_V3_METADATA_CONTROLS','driver_sha256':sha(D),'map_sha256':sha(MAP),'observations':checks,'positive_predicate_observations':sum(x['observed']for x in checks),'negative_predicate_observations':sum(not x['observed']for x in checks),'actual_primary_source_modules':len(primary),'actual_union_source_modules':len(union),'actual_union_matches_live_inventory':True,'phase8_and_optional_reuse_ledgers_match_pinned_hashes':True,'driver_invocations':0,'compiler_invocations':0,'actual_object_or_log_rehash_claim':False}
(HERE/'controls-v3.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='observations'},indent=2))
