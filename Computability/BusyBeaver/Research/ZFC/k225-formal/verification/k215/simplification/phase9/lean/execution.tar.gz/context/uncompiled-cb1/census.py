"""Read literal source/role/table data only; no machine or supplied-script execution."""
from pathlib import Path
import hashlib, json, re, collections
ROOT=Path('/home/codex/.codex/worktrees/ec20/Proofs')
OUT=Path(__file__).resolve().parent
D=Path('/tmp/k215-phase9-decoder-compact/candidate/BusyBeaver/ZFC/K215Decoder.lean')
T=ROOT/'Computability/BusyBeaver/Research/ZFC/candidate-k215/k215.native.tm'
def pin(p):
 b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
s=D.read_text()
def arr(name):return s.split('def '+name+' : Array ',1)[1].split('#[',1)[1].split('\n]',1)[0].strip().splitlines()
nodes=[]
for line in arr('sourceNodes'):
 m=re.fullmatch(r'\s*\.(leaf|fork) (\d+) (\d+),?',line);assert m,line
 nodes.append((m[1],int(m[2]),int(m[3])))
edge=r'\(\.(?:internal \d+ \d+|primitive \d+ ⟨(?:true|false), (?:1|\(-1\)), \d+⟩)\)'
def edgeparse(x):
 m=re.fullmatch(r'\(\.internal (\d+) (\d+)\)',x)
 if m:return ('internal',int(m[1]),int(m[2]))
 m=re.fullmatch(r'\(\.primitive (\d+) ⟨(true|false), (1|\(-1\)), (\d+)⟩\)',x);assert m,x
 return ('primitive',int(m[1]),(m[2]=='true',1 if m[3]=='1' else -1,int(m[4])))
roles=[]
for line in arr('roles'):
 m=re.fullmatch(r'\s*⟨(\d+), (\d+), \[(.*?)\], ('+edge+'), ('+edge+r')⟩,?',line);assert m,line
 roles.append(dict(node=int(m[1]),q=int(m[2]),suffix=[x.strip()=='true' for x in m[3].split(',')],edges=[edgeparse(m[4]),edgeparse(m[5])]))
def rename(q):return {301:102,102:301,302:120,120:302,254:230,230:254}.get(q,q)
table={}
for line in T.read_text().splitlines():
 m=re.fullmatch(r'(\d+) ([01]) ([01]) ([LR]) (\d+)',line)
 if m:
  q,b,w,d,q1=m.groups();table[(rename(int(q)),bool(int(b)))]=(bool(int(w)),1 if d=='R' else -1,rename(int(q1)))
assert len(table)==430
leaves=[]
def visit(ri,path):
 r=roles[ri];typ,l,u=nodes[r['node']];assert typ=='fork'
 assert r['suffix']==([True]+path)[-2:]
 for bit,child in [(False,l),(True,u)]:
  e=r['edges'][int(bit)];p=path+[bit]
  if e[0]=='internal':
   assert roles[e[1]]['node']==child and child<r['node'];visit(e[1],p)
  else:
   assert e[1]==child and nodes[child][0]=='leaf'
   assert table[(r['q'],bit)]==e[2]
   _,op,arg=nodes[child]
   leaves.append(dict(path=''.join(str(int(x)) for x in p),role=ri,q=r['q'],bit=int(bit),op=op,arg=arg))
visit(0,[])
assert len(nodes)==202 and len(roles)==234 and len(leaves)==4751
assert sum(1+(x['op']==1) for x in leaves)==6176
# The finite word is a prospective LeftWord proof witness: inspect each row,
# requiring unchanged write/left move, then exact state2. It never reads a tape.
def left(q,word):
 used=[]
 for b in word:
  w,d,q1=table[(q,b)]
  if w!=b or d!=-1:return None
  used.append([q,int(b),q1]);q=q1
 return used if q==2 else None
cb=[x for x in leaves if (x['op'],x['arg'])==(2,1)]
family=[x for x in cb if x['q']==108 and x['bit']==1]
assert len(cb)==98 and len(family)==86
for x in family:
 assert x['path'].endswith('001')
 A=x['path'][:-3];assert len(A)+3<=64
 w=left(1,[c=='1' for c in reversed(A)]+[True]);assert w is not None
 x.update(A=A,left_word_rows=w)
assert left(1,[True])==[[1,1,2]]
assert left(1,[True]+[False]*8+[True]) is None
names={0:'CI',1:'CD',2:'CB',3:'CC',4:'CH'}
counts=collections.Counter((names[x['op']],x['arg'])for x in leaves)
results=dict(status='PASS_LITERAL_SOURCE_ROLE_AND_LEFT_WORD_CENSUS',inputs=[pin(D),pin(T)],
 scope='Own inert parser: all source/role paths and finite unchanged-word row witnesses. No Lean, symbolic executor, concrete tape simulation, or whole primitive runtime was invoked.',
 nodes=len(nodes),roles=len(roles),leaves=len(leaves),branches=sum(1+(x['op']==1)for x in leaves),
 counts=[dict(op=o,arg=a,leaves=n)for(o,a),n in sorted(counts.items())],
 cb1_leaves=len(cb),common_cb1_leaves=len(family),common_cb1_terminal_roles=sorted({x['role']for x in family}),
 common_cb1_path_length_range=[min(len(x['path'])for x in family),max(len(x['path'])for x in family)],
 common_cb1_literal_row_guard=[dict(q=q,read=int(b),action=list(table[(q,b)]))for q,b in [(108,True),(10,False),(16,False),(1,False),(1,True)]],
 omitted_cb1=[x for x in cb if x not in family],
 controls=dict(empty_A_includes_marker=True,eight_zero_midword_guard_rejected=True),
 witnesses=family,compiler_invocations=[],supplied_execution=[],canonical_mutations=[])
(OUT/'census.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v for k,v in results.items()if k not in ('witnesses','omitted_cb1','counts')},indent=2))
