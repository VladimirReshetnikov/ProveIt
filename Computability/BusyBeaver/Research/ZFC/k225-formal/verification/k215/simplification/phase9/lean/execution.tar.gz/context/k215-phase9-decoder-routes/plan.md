# Phase 9: retain exact decoder routes, then compose semantic site contracts

This is a scratch, uncompiled source candidate against `f7b4a86bb3c654db0fb07714beaea06b83d5ce49`. No maintained source, generator, machine table, endpoint or current coverage certificate has changed. No Lean/Rocq compiler, delivered script or machine transition ran. The own `prepare.py`, `static_review.py` and previously reviewed literal reader perform only source/data transformations and checks.

## Concrete selected theorem

The selected reusable interface is **`source_path_chain_routed`**, strengthened from the delivered `composition-address-bounds/decoder_source_paths/DecoderPaths.lean`. Its proof is the existing source-path induction with one additional witness, not a second physical simulation or a new window hypothesis.

`RolePath roles first prefix last` records the literal internal edges taken from the first role to the last role. It retains the selected role indices and each selected internal-edge target; it does not identify roles merely because they share a state, subtree or two-bit suffix. `RoutedEntry M nodes roles first word q bit op arg` records:

- `word = prefix ++ [bit]`;
- `RolePath roles first prefix lastRole`;
- the exact final role at `lastRole`, its state `q`, and its literal selected primitive edge;
- the precise source leaf opcode/argument and the first native table action.

The strengthened chain theorem reaches this entry while restoring the **entire arbitrary integer tape**. Its only tape premises remain the actual incoming role suffix and complete source word. The ordinary proof is unchanged for the local window: append the read bit to the incoming suffix, take the checked suffix window, derive the overlay equality, and propagate `tail2`. The new proof bookkeeping is small: the primitive case returns an empty role route; an internal step prepends its literal edge to the recursively returned route and prepends its bit to the returned prefix. No numerical code injectivity, unproved role quotient, finite-tape assumption, or state uniqueness is used.

The old `Entry`, `source_path_chain`, `source_path_run`, `reaches_primitive`, `upstream_leaf_reaches` and `upstream_walk_reaches` interfaces remain. The affected old theorems are wrappers forgetting the extra route witness. All original declaration headers and executable/data definition bodies compare equal after namespace qualification. The original first-action distinction remains: this chain stops **before** the primitive's first transition.

The rebased `DecoderSourceBinding.lean` imports **`KSource215Program`**, not the historical certificate-data module. Its new `upstream_leaf_reaches_routed` and `upstream_walk_reaches_routed` bind the route to the exact current tree and padded `consume P d` walk semantics. They start at role0, native state84, marker1, and return the same whole-tape execution/clock bounds as the old theorem plus the route witness. The supplied literal `source_tree_eq` body remains `rfl`; this adaptation has not been kernel-checked.

## Exact next composition

For a current source leaf `Q = A ++ [b]` with edge `e`, the routed theorem supplies a native state `q`, role route from0 through all of `A`, and a restoring full-tape run to head `|A|`. The parent owns the generic `KZip`/integer-tape bridge and total label involution; the source theorem does not assume them.

Once those bridges are proved, the intended decoder-side conclusion is:

```lean
Reach tm215
  (conc n vs (KSim.start (A ++ [b])))
  (zc (sigma q) (A.reverse ++ [true])
    (b :: List.replicate (n + (KSim.D0 - (A ++ [b]).length)) false ++
      true :: sepsR vs))
```

It retains the complete prefix, gap, header and register box. The total label involution is `(301 102)(302 120)(254 230)`, including the inverse directions and absent states. Specialize the arbitrary-tape theorem to the tape represented by the zipper; do not claim every arbitrary infinite tape has a finite zipper representation.

Drop's separate semantic-coverage draft consumes exactly this prefix result and a positive suffix contract from its `leafPort`. The suffix starts **before the terminal primitive action** and must include that action, register arithmetic, branch guard, continuation/break cleanup, carry/overflow and return to the exact old `tgtConf`; halt instead supplies `Halts`. The unchanged `Valid` hypotheses quantify arbitrary natural registers and gap. The full accepted prefix language remains a parameter of this contract. `Reach.trans_reach1` and `Halts.of_reach` are the appropriate composition rules.

This semantic route avoids the invalid inference from reachability back to `checkEdge = true` with its fixed4000 fuel. Existing `KSim.Covered`/`all_sites` remain checked and untouched. An eventual alternate semantic coverage theorem must either preserve the old interfaces as wrappers or introduce a separately proved complete simulation path; it cannot replace their Boolean conclusions by fiat.

## Current exact data and realistic cost

The fresh own literal reader revalidated all430 native/formal actions under the total swaps and all four current source declarations `p215Nodes`, `p215`, `t215`, `t215_eq`. The original frozen finite route witness is transferred only across exact matching input hashes (including accepted `sites215.json`); no new physical block check is inferred.

The preserved coverage consists of **4,751 leaves and 6,176 branch outcomes**, including1,425 decrement leaves. The original shared certificate has202 source nodes,234 context-sensitive roles and281 restoring local blocks. There are97 reached terminal role/bit bindings:38 decrement,32 increment,19 continue,7 break and1 halt. If their universally quantified accepted-prefix suffix contracts are proved, they require135 outcome contracts and cover all6,176 instances; those135 universal contracts are presently **missing**, not automatically established by97 first-action rows.

Across the frozen leaf routes there are165,876 decoder-prefix physical steps, or213,945 when repeated per branch; each prefix takes2–55 steps. These are sums of shared block durations, not current Lean reductions, measured compiler time, whole-primitive steps, or a predicted speedup.

The four adapted source modules total73,030 bytes. The parent's current `FramedWindow` port adds about6.7KB; five source-path modules therefore add about79.7KB before a zipper bridge or semantic adapter. The maintained nine site batches are55,794 bytes and the final facade14,956 bytes (105 kernel blocks). **Adopting this component alone increases source and closure size and does not remove a single existing site obligation.** It should remain a critical-path research module until a proved suffix contract/checker removes repeated work or permits a smaller maintained coverage certificate. A lower-bound module census is five new source-path modules plus at least the separate tape bridge; final sharing/splitting may change that count. Their ported dependency chain can remain within the existing `Init` boundary; no `Std` import should be introduced solely by copying the proposal.

The current decoder component is useful because it eliminates the repeated incoming-window premises and retains exactly the context needed to attack the real remaining135 suffix contracts. The complementary delivered return-scanner idea targets substantially more of the repeated execution, but its table boundary and all-natural symbolic guard remain separate obligations; this candidate does not import those assumptions.

## Validation and remaining gates

`static-review.json` records complete old/new declaration comparison, current source/table pins, frozen route-witness provenance, exact coverage and source-size counts. The four literal arrays, generic block/check definitions and original executable/source-tree definitions are unchanged except namespace/import qualification. There are no new axioms, admissions, native-evaluation shortcuts or weaker endpoint statements.

Required before maintained adoption:

1. Kernel-check the namespaced generic/data modules, strengthened route induction and literal current source equality with the root-owned `FramedWindow` port.
2. Prove the total native/formal table permutation and finite-zipper specialization/whole-run transport, preserving exact head position and full tape equality.
3. Instantiate the role/prefix entry at `conc n vs (start Q)`; this is a bridge, not a new primitive contract.
4. Prove the accepted-prefix primitive/return contracts or a complete residual symbolic checker, keeping every old branch outcome and target.
5. Compare actual source/certificate size and serial kernel cost before replacing current coverage; revalidate the final machine and both typed endpoints after any adoption.

The candidate is reviewable now; it is not a compiled proof, completed replacement coverage, source-size saving or new endpoint result.
