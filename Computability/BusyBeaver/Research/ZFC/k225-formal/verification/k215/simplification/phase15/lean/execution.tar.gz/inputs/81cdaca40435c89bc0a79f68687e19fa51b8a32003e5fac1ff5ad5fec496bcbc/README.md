# Phase15 bounded retry — held, not executed

The original primary run remains failed. It completed 87 providers (19 successful
fresh compilations and 68 phase14 reuses), then `KQ1ZF` failed because it had relied
on the removed `WFModelCore → PSCCalibration` import for `BProv` and
`soundness_BProv`. Both declarations are in `FirstOrder.Completeness`. The failed
log, including its `sorryAx` report, is retained and excluded from accepted evidence.

The sole `KQ1ZF` repair adds `import FirstOrder.Completeness`; all other bytes,
including every theorem statement and body, are identical. This file is handwritten.
The maintained `generate_kq1.py` emits Model/Separation/Basic/Replacement/Power/Collect,
not `KQ1ZF`, so this repair requires no producer change or reproduction rerun.

Root also selected exact Source193's shorter `KDenseBridge` proof, replacing the
still-uncompiled Source192 candidate. All declarations before `blank_iff` and its
generic header remain literal. For the reverse direction the same invariant at
`k+1` either supplies dense halting or contradicts the sparse successor being
`none`. This avoids identifying states and repeating the final dense-step case.
The Source193 peer is independently frozen; no proof compiler has checked this
successor yet. `KDenseBridge` is absent from all 87 completed providers.

The earlier import-only retry draft is preserved at
`/tmp/k215-phase15-retry-import-only-pre193`; the original source/runner freezes and
failed primary remain unchanged. Nine Lean source candidates are now selected.
The graph remains 176 endpoint modules, 181 with prefix, and 194 primary providers
including explicit calibration continuity and ten API clients. Endpoint source
bytes are 2,052,142. Compatibility stays 71 providers and the project union 199.

`initialize.py` uses the already reviewed phase14 bounded-prefix initializer shape.
It revalidates every old completed source/import/dependency/object/log record and
every frozen input, excludes the failed module, and creates a distinct `primary-run2`
owner by executing only the unchanged phase15 driver's metadata prefix before its
first compiler loop. The initializer explicitly rejects a prefix containing any
`run_locked` call. It creates private file symlinks for those 87 objects; no directory
symlinks or binary copies are needed. The ordinary runner then rechecks `usable`
and source-transitive freshness. Initializer, maps and finalizer require a new
frozen peer and root GO before execution.

If accepted, primary will contain 45 selected fresh proof records: 19 from the
failed first attempt and 26 newly compiled in run2, plus 149 exact phase14 providers.
Two endpoint clients still need fresh calls. No statement labels the original
run PASS. Compatibility remains held until terminal primary PASS, finalized actual
ledger pins, an independent final-map review and root authorization.
