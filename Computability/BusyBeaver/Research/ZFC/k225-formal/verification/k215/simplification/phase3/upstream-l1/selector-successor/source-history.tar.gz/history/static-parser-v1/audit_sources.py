"""Static checks for the exact upstream successor; never executes its generator."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

P = Path(__file__).resolve().parent
R = Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def declarations(text):
    starts = list(re.finditer(r'(?m)^(def|theorem) ([A-Za-z0-9_.\x27]+)', text))
    answer = {}
    for index, start in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else len(text)
        statement = text[start.start():end].split(':=', 1)[0]
        answer[start.group(2)] = ' '.join(statement.split())
    return answer


old_ax = (P / 'previous/L2AxiomsPerm.lean').read_text()
new_ax = (P / 'upstream/L2AxiomsPerm.lean').read_text()
old_root = (P / 'previous/L2RootPerm.lean').read_text()
new_root = (P / 'upstream/L2RootPerm.lean').read_text()
for name in ('f236', 'l236', 'c236', 'ax_eval', 'axWordCheck', 'axWordEval', 'axWordClean', 'axWordRun'):
    assert declarations(old_ax)[name] == declarations(new_ax)[name], name
for name, statement in declarations(old_root).items():
    assert declarations(new_root)[name] == statement, name
assert set(declarations(new_root)) - set(declarations(old_root)) == {'dec_brk', 'pass', 'fall'}
word = lambda text: text.split('def axWord :', 1)[1].split('theorem axWord_checked', 1)[0]
assert word(old_ax) == word(new_ax)
assert len(re.findall(r'\(\.[a-z0-9]+, \d+\)', word(new_ax))) == 156

# Reconstruct only the literal template substitution, using independent stdlib code.
# The candidate Python generator is parsed as data, never imported or executed.
old_gen = ast.parse((P / 'previous/generate_l2axiomsdom.py').read_text())
new_gen = ast.parse((P / 'upstream/generate_l2axiomsdom.py').read_text())
assignments = {node.targets[0].id: node.value for node in new_gen.body
               if isinstance(node, ast.Assign) and len(node.targets) == 1
               and isinstance(node.targets[0], ast.Name)}
template = ast.literal_eval(assignments['PERM_TEMPLATE'])
leaf = ast.literal_eval(assignments['LEAF'])
data_path = R / 'Computability/BusyBeaver/Research/ZFC/k225-formal/lean215/dagperm_nodes.json'
data_bytes = data_path.read_bytes()
assert data_bytes == subprocess.check_output(['git', 'show', 'c9dc793234:' + str(data_path.relative_to(R))], cwd=R)
data = json.loads(data_bytes)
nodes = {int(key): value for key, value in data['nodes'].items()}
chain, node = [], 236
while True:
    left, right = nodes[node]
    assert left[0] == 'N'
    chain.append(node)
    if right[0] == 'N' and right[1] >= 301 and right[1] not in chain:
        node = right[1]
    else:
        break
atoms = [nodes[n][0][1] for n in chain] + [nodes[chain[-1]][1][1]]
assert atoms == data['word236'] and atoms[-5:] == [192, 131, 211, 197, 131]
gate_index = len(chain) - 4
assert gate_index == 156 and chain[gate_index:] == [457, 458, 459, 460]
pairs = [(leaf[atoms[i]][1][:-1], chain[i + 1]) for i in range(gate_index)]
rows = [', '.join(f'(.{atom}, {n})' for atom, n in pairs[i:i + 6])
        for i in range(0, len(pairs), 6)]
rendered = template.replace('@WORD@', ',\n'.join('  ' + row for row in rows) + ']')
for index in range(4):
    rendered = rendered.replace(f'@G{index}@', str(chain[gate_index + index]))
assert rendered.encode() == (P / 'upstream/L2AxiomsPerm.lean').read_bytes()


def dom_ast(tree):
    body = []
    expected = ast.dump(ast.parse("VARIANT == 'perm'", mode='eval').body)
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PERM_TEMPLATE'
                                               for t in node.targets):
            continue
        if isinstance(node, ast.If) and ast.dump(node.test) == expected:
            assert not node.orelse
            continue
        body.append(node)
    return ast.dump(ast.Module(body=body, type_ignores=[]))


assert dom_ast(old_gen) == dom_ast(new_gen)
integrated = Path('/tmp/k215-upstream-l1-draft/candidate/BusyBeaver/ZFC/EnumPerm.lean')
assert sha(integrated) == 'caf5fe9e486f3807b4f6521cce6e623976719500940c4b0c45adf247f45fd7be'
upstream_enum = subprocess.check_output(['git', 'show', 'c9dc793234:Computability/BusyBeaver/Lean/BusyBeaver/ZFC/EnumPerm.lean'], cwd=R)
previous_enum = subprocess.check_output(['git', 'show', 'cd2c1eee7b:Computability/BusyBeaver/Lean/BusyBeaver/ZFC/EnumPerm.lean'], cwd=R)
assert upstream_enum == previous_enum

result = {
    'status': 'PASS_STATIC_SUCCESSOR_CHECKS', 'compiler_invoked': False,
    'supplied_generator_executed': False, 'canonical_files_modified': False,
    'exact_ax_word_atoms': 156, 'exact_ax_gate_nodes': chain[gate_index:],
    'required_ax_api_statements_unchanged': True,
    'all_old_root_declaration_statements_unchanged': True,
    'added_root_lemmas': ['dec_brk', 'pass', 'fall'],
    'literal_template_reconstruction_exact': True,
    'dom_mode_non_perm_ast_exact': True,
    'enum_between_remote_revisions_exact': True,
    'integrated_enum_sha256': sha(integrated), 'dagperm_input_sha256': sha(data_path),
    'files': {str(f.relative_to(P)): sha(f) for directory in ('previous', 'upstream')
              for f in sorted((P / directory).iterdir())},
    'line_counts': {'AX_old': len(old_ax.splitlines()), 'AX_new': len(new_ax.splitlines()),
                    'Root_old': len(old_root.splitlines()), 'Root_new': len(new_root.splitlines())},
    'scope': 'Static statement, literal word, template and conditional-Dom-AST checks. '
             'No proof validity claim for the new bytes until coordinated phase3 compilation.'}
(P / 'static-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
