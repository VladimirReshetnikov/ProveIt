from pathlib import Path
import json,hashlib,re
O=Path(__file__).resolve().parent;B=Path('/tmp/k215-phase9-main/isolated-run2');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
r=read(B/'result.json');inv=read(B/'inventory.json');done=read(B/'completed.json');rows={x['module']:x for x in inv['modules']};before=read(B/'before.json')
assert r['status']=='PASS' and len(rows)==len(done)==14
assert r['fresh_modules']==['BusyBeaver.ZFC.KRuntimeCore','BusyBeaver.ZFC.KHome','BusyBeaver.ZFC.KHomeReady','BusyBeaver.ZFC.KSim','BusyBeaver.ZFC.KHomeRuntimeAudit']
objects={m:sha(B/'objects'/(m.replace('.','/')+'.olean'))for m in rows}
reports={}
expected={'BusyBeaver.ZFC.KRuntimeCore':[],'BusyBeaver.ZFC.KHome':['KHome.scanBound_sound','KHome.flat_reverse','KHome.home_sound'],'BusyBeaver.ZFC.KHomeReady':['KHomeReady.ready_sound','KHomeReady.exec_sound'],'BusyBeaver.ZFC.KSim':[],'BusyBeaver.ZFC.KHomeRuntimeAudit':['KHomeRuntimeAudit.original_executor','KRuntimeCore.exec_sound','KRuntimeCore.execWith_sound']}
for m,row in rows.items():
 rec=done[m];source=Path(row['source']);obj=B/'objects'/(m.replace('.','/')+'.olean')
 assert sha(source)==row['source_sha256']==rec['source_sha256'];assert objects[m]==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256'];assert rec['status']=='PASS'
 imports=[w for l in source.read_text().splitlines()if l.startswith('import ')for w in l[7:].split()];assert imports==row['imports']
 assert rec['dependencies']=={d:objects[d]for d in imports if d!='Init'}
 if m in expected:
  assert rec['exit_code']==0 and not rec['timed_out'] and rec['warnings']==0
  assert sha(rec['source'])==sha(source);assert sha(rec['candidate'])==sha(source)
  text=Path(rec['log']).read_text();assert 'warning:'not in text
  found=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
  assert [n for n,a in found]==['SetTheory.BusyBeaver.ZFC.'+n for n in expected[m]]
  assert found==[tuple(x)for x in rec['reports']]
  assert all({x.strip()for x in a.split(',')if x.strip()}<={'propext','Classical.choice','Quot.sound'}for n,a in found)
  assert rec['command']==['/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean','-j1','-M12288','--root='+str(B/'workspace'),'-o',str(obj),str(B/'workspace'/(m.replace('.','/')+'.lean'))]
  assert sha(rec['command'][0])==rec['compiler_sha256'];reports[m]=found
for p,h in before['inputs'].items():assert sha(p)==h
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Lean/BusyBeaver/ZFC')
old=(repo/'KSim.lean').read_text();new=Path('/tmp/k215-phase9-main/candidate-v2/BusyBeaver/ZFC/KSim.lean').read_text()
assert old.count('exec M br ')==2 and old.count('exec M none ')==2 and old.count('exec_sound B n ')==2
expect=old.replace('import BusyBeaver.ZFC.KRuntimeCore','import BusyBeaver.ZFC.KHomeReady').replace('exec M br ','KHomeReady.exec M br ').replace('exec M none ','KHomeReady.exec M none ').replace('exec_sound B n ','KHomeReady.exec_sound B n ').replace('theorem sim_stop {','omit B in\ntheorem sim_stop {').replace('sim_stop B hcov hs','sim_stop hcov hs')
assert new==expect
oldc=(repo/'KRuntimeCore.lean').read_text();newc=Path('/tmp/k215-phase9-home/integration/BusyBeaver/ZFC/KRuntimeCore.lean').read_text()
assert oldc.split('def exec (')[0]==newc.split('def execWith (')[0]
assert oldc.split('/-! ## Basic facts -/')[1].split('theorem exec_sound ')[0]==newc.split('/-! ## Basic facts -/')[1].split('omit B in\ntheorem execWith_sound ')[0]
assert oldc.split('end Sound')[1]==newc.split('end Sound')[1]
olddef=oldc[oldc.index('def exec ('):oldc.index('/-! ## Basic facts -/')]
audit=Path('/tmp/k215-phase9-home/integration/RuntimeAudit.lean').read_text();auditdef=audit[audit.index('def oldExec ('):audit.index('theorem original_executor')].replace('oldExec','exec')
assert re.sub(r'\s+','',olddef)==re.sub(r'\s+','',auditdef)
for m,row in rows.items():assert sha(row['source'])==row['source_sha256']and sha(B/'objects'/(m.replace('.','/')+'.olean'))==objects[m]and sha(done[m]['log'])==done[m]['log_sha256']
for p,h in before['inputs'].items():assert sha(p)==h
out={'status':'PASS_READONLY_SOURCE_DELTA_AND_14_PROVIDER_RECORDS','compiler_invoked':False,'checked_modules':14,'fresh_record_count':5,'named_reports':sum(map(len,reports.values())),'fresh_warnings':0,'exact_old_executor_control':True,'KSim_only_listed_changes':True,'KRuntimeCore_outside_two_regions_unchanged':True,'reports':reports,'pins':{str(p):sha(p)for p in[B/'result.json',B/'inventory.json',B/'completed.json',B/'before.json',Path('/tmp/k215-phase9-main/integration-v2.json'),Path(__file__)]}}
(O/'bindings.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['reports','pins']},indent=2))
