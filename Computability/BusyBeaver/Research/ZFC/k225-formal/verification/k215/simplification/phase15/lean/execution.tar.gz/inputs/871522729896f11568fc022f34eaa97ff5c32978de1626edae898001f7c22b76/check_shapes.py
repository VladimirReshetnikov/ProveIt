"""Read-only literal checks of the explicit external client's legacy shapes."""
from pathlib import Path
import re, json
root = Path(__file__).resolve().parent
client = (root / 'clients/TransRec15Api.lean').read_text()
old_i = (root / 'before/InternalRank.lean').read_text()
old_t = (root / 'before/TransRec.lean').read_text()

def body(text, name):
    m = re.search(r'^(?:private )?(?:def|abbrev|theorem|structure)\s+' + re.escape(name) + r'(?=\s|\()', text, re.M)
    assert m, name
    tail = text[m.end():]
    next_decl = re.search(r'^(?:private )?(?:def|abbrev|theorem|structure)\s|^section |^end |^variable ', tail, re.M)
    if next_decl:
        tail = tail[:next_decl.start()]
    value = tail.split(':=', 1)[1]
    value = re.sub(r'/\-.*?\-/|--[^\n]*', '', value, flags=re.S)
    return re.sub(r'\s+', '', value)

checks = {}
checks['cumulative_approximation_clauses'] = body(old_i, 'Approx').replace('SubmemzT', 'RzT') == body(client, 'legacyApprox')
checks['operation_approximation_clauses'] = body(old_t, 'Approx').replace('memz(GT)', 'RzT') == body(client, 'legacyApprox')
checks['cumulative_approximation_formula'] = body(old_i, 'approxF').replace('subF(', 'rF(') == body(client, 'legacyApproxF')
checks['operation_approximation_formula'] = body(old_t, 'approxF').replace('inGFD(', 'rF(') == body(client, 'legacyApproxF')
checks['cumulative_stage_formula'] = body(old_i, 'isVF').replace('approxFn(', 'legacyApproxFrFn(') == body(client, 'legacyStageF')
checks['operation_stage_formula'] = body(old_t, 'isStageF').replace('approxFDn(', 'legacyApproxFrFn(') == body(client, 'legacyStageF')
assert all(checks.values()), checks
print(json.dumps({'status': 'LITERAL_SHAPES_PASS_NO_COMPILER', 'checks': checks}, indent=2))
