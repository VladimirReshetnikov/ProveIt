"""Own inert exact-delta checks and copies. No proposal import or execution."""
from pathlib import Path
import hashlib,json,difflib,re,subprocess
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent
L=R/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC';P=R/'SetTheory/Cardinals/docs/reports/set-theory/zfc-closure-kernels/code'
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[];diff=[]
for name in ['PowerSets','PSCCalibration','WFModelCore','KDenseBridge']:
 source=P/('192-powerset-'+name+'.lean');target=L/(name+'.lean');data=source.read_bytes();old=target.read_bytes() if target.exists() else None
 assert subprocess.check_output(['git','show','6901b164d9:'+str(source.relative_to(R))],cwd=R)==data
 (S/'candidate/BusyBeaver/ZFC'/target.name).write_bytes(data)
 if old is not None:
  assert subprocess.check_output(['git','show','6901b164d9:'+str(target.relative_to(R))],cwd=R)==old
  (S/'before'/target.name).write_bytes(old)
 rows.append({'module':'BusyBeaver.ZFC.'+name,'source':str(S/'candidate/BusyBeaver/ZFC'/target.name),'source_sha256':sha(data),'before_sha256':sha(old) if old else None,'canonical':str(target.relative_to(R)),'proposal_source':str(source),'proposal_sha256':sha(data),'imports':re.findall(r'(?m)^import (\S+)',data.decode()),'old_bytes':len(old or b''),'new_bytes':len(data),'old_lines':len((old or b'').splitlines()),'new_lines':len(data.splitlines())})
 diff+=difflib.unified_diff((old or b'').decode().splitlines(True),data.decode().splitlines(True),fromfile='before/'+name+'.lean',tofile='candidate/'+name+'.lean')
old=(S/'before/PSCCalibration.lean').read_text();new=(S/'candidate/BusyBeaver/ZFC/PSCCalibration.lean').read_text()
block='def PowerSets (mem : V → V → Prop) : Prop :=\n  ∀ a, ∃ p, ∀ y, mem y p ↔ SetTheory.Sub mem y a\n\n'
assert old.count(block)==1 and new==old.replace('import BusyBeaver.ZFC.DefinableClosure\n','import BusyBeaver.ZFC.DefinableClosure\nimport BusyBeaver.ZFC.PowerSets\n',1).replace(block,'',1)
power=(S/'candidate/BusyBeaver/ZFC/PowerSets.lean').read_text();assert block in power and 'namespace SetTheory.BusyBeaver.ZFC.PSCCalibration' in power
old=(S/'before/WFModelCore.lean').read_text();new=(S/'candidate/BusyBeaver/ZFC/WFModelCore.lean').read_text();assert new==old.replace('import BusyBeaver.ZFC.PSCCalibration\n','import BusyBeaver.ZFC.PowerSets\n',1)
old=(S/'before/KDenseBridge.lean').read_text();new=(S/'candidate/BusyBeaver/ZFC/KDenseBridge.lean').read_text();assert old.split('theorem blank_iff')[0]==new.split('theorem blank_iff')[0];assert old.split('theorem blank_iff',1)[1].split(':= by',1)[0]==new.split('theorem blank_iff',1)[1].split(':= by',1)[0]
assert new.endswith('end SetTheory.BusyBeaver.ZFC.KDenseBridge\n')
# The upstream bridge is the same raw proposal, not another adaptation.
assert subprocess.check_output(['git','show','406cb959dd6ad3bbd34af4a6d92ba8807575d60b:Computability/BusyBeaver/Lean/BusyBeaver/ZFC/KDenseBridge.lean'],cwd=R)==new.encode()
(S/'sources.json').write_text(json.dumps(rows,indent=2)+'\n');(S/'source.diff').write_text(''.join(diff))
result={'status':'PASS_OWN_INERT_EXACT_DELTA','basis_commit':'6901b164d9da3c5c09df4647e0b2d5466f1174ac','source_rows':rows,'checks':['PSCCalibration import+definition relocation exact; all other bytes fixed','PowerSets identical qualified name, universe and body','WFModelCore sole import replacement; every declaration unchanged','KDenseBridge all declarations before blank_iff and exact blank_iff header unchanged','KDenseBridge exact Source192 and upstream406c bytes'],'total_before_bytes':sum(r['old_bytes'] for r in rows),'total_after_bytes':sum(r['new_bytes']for r in rows),'total_before_lines':sum(r['old_lines']for r in rows),'total_after_lines':sum(r['new_lines']for r in rows),'compiler_or_supplied_execution':False}
(S/'comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='source_rows'},indent=2))
