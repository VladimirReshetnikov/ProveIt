"""Independent read-only compatibility record review; no supplied code execution."""
from pathlib import Path
import json,hashlib,re,copy,collections
S=Path('/tmp/k215-phase14-check');R=S/'compatibility-run1';P=S/'primary-run2';O=Path(__file__).resolve().parent;T=Path('/tmp/k215-phase14-retry')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
assert sha(R/'result.json')=='008d6626c9c2b11400713bda9dff89aa5385f276d0898f13c1f0dd19cda857b1';res=read(R/'result.json');iv=read(R/'inventory.json');done=read(R/'completed.json');primary=read(P/'completed.json');old=read('/tmp/k215-phase13-upstream-check/compatibility-run1/completed.json');plan=read(T/'compatibility-final-map.json');plans={r['module']:r for r in plan['modules']}
assert res['status']=='PASS'and res['runner_sha256']==sha(S/'build.py')and res['map_sha256']==sha(T/'compatibility-final-map.json')
assert res['inventory_sha256']==sha(R/'inventory.json')and res['completed_sha256']==sha(R/'completed.json')
rows={r['module']:r for r in iv['modules']};assert len(rows)==len(done)==70 and list(rows)==plan['expected']['modules']and set(rows)==set(done)
assert res['source_changed_modules']==plan['expected']['changed']and res['force_basis_rebuild_modules']==plan['expected']['forced']
counts=collections.Counter();warnings=collections.Counter();profiles={};pat=r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)"
for m,row in rows.items():
 r=done[m];counts[r['origin']]+=1
 assert r['status']=='PASS'and r.get('exit_code',0)==0 and not r.get('timed_out',False)
 assert sha(row['source'])==row['source_sha256']==r['source_sha256'];assert r['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 assert sha(R/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']
 imports=[w for g in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',Path(row['source']).read_text())for w in g.split()];assert imports==row['imports']
 txt=Path(r['log']).read_text();assert 'error:'not in txt and 'sorryAx'not in txt;warnings[r['origin']]+=txt.count('warning:');reps=re.findall(pat,txt)
 assert all({x.strip()for x in a.split(',')if x.strip()}<={'propext','Classical.choice','Quot.sound'}for _,a in reps)
 if m in plans and 'reports'in plans[m]:
  assert [n for n,a in reps]==plans[m]['reports']and 'warning:'not in txt
  assert [{x.strip()for x in a.split(',')if x.strip()}for _,a in reps]==[set(a)for a in plans[m]['report_axioms']];profiles[m]=reps
 if r['origin']=='candidate_fresh':
  assert m not in primary and m in plan['expected']['forced'];assert sha(r['source'])==r['source_sha256']
  assert r['command']==['/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean','-j1','-M12288','--root='+str(R/'workspace'),'-o',str(R/'objects'/(m.replace('.','/')+'.olean')),str(R/'workspace'/(m.replace('.','/')+'.lean'))]
  assert r['timeout_seconds']==120 and r['memory_mebibytes']==12288;assert sha(r['command'][0])==r['compiler_sha256'];assert r['helper_sha256']=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
 else:
  if r['origin']=='secondary_checked':b=copy.deepcopy(primary[m])
  else:assert r['origin']=='phase13_compatibility_checked'and m=='BusyBeaver.ZFC.Dag254';b=copy.deepcopy(old[m])
  b['origin']=r['origin'];assert r==b
assert counts=={'candidate_fresh':16,'secondary_checked':53,'phase13_compatibility_checked':1}
assert not res['audits'] and len(profiles['WFModelCompat12'])==3 and len(profiles['ZFNativeCompat12'])==7
for p,h in read(R/'before.json')['inputs'].items():assert sha(p)==h,p
for p in read(R/'before.json')['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink()
outer=read('/tmp/k215-phase14-execution/compatibility-run1-outer.json');assert outer['exit_code']==0
for k in ['stdout','stderr']:assert sha(outer[k])==outer[k+'_sha256']
for m,r in done.items():assert sha(R/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']
out={'status':'PASS_INDEPENDENT_COMPATIBILITY_ACTUAL_REVIEW','result_sha256':sha(R/'result.json'),'map_sha256':sha(T/'compatibility-final-map.json'),'providers':70,'origins':dict(counts),'warnings':dict(warnings),'named_profile_clients':profiles,'old_compatibility_client_reports':10,'outer_sha256':sha('/tmp/k215-phase14-execution/compatibility-run1-outer.json'),'observed_outer_exit':0,'scope':'Own read-only current source/import/object/dependency/log/command-cap/input/outer inspection, exact53 raw primary reuse and one oldDag254. No compiler, supplied helper, producer or canonical mutation.'}
(O/'compatibility-actual-review.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(O/'compatibility-actual-review.json'),dict(counts),dict(warnings))
