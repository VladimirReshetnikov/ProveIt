"""Untrusted, bounded AND/OR optimization of an already checked finite proof.

No theorem compiler is invoked. Every new rule is an exact substitution instance
of an earlier theorem. The emitter and downstream kernel remain authoritative.
"""
from pathlib import Path
import argparse, copy, hashlib, json, os, time
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import numpy as np
import scipy
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_array

ap=argparse.ArgumentParser()
ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--seconds',type=float,default=120)
args=ap.parse_args()
out=args.output;out.mkdir(parents=True,exist_ok=False)
start=time.monotonic()
rootdir=Path('/home/codex/.codex/worktrees/ec20/Proofs')
source=rootdir/'Computability/BusyBeaver/Research/ZFC/k225-formal/lean217/dominated_rho8_full_certificate.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=Path('/tmp/k215-proof-concision-search')
summary=json.loads((prior/'summary.json').read_text())
for name,h in summary['files'].items():assert sha(prior/name)==h,(name,h)
assert sha(source)=='3cf18a5fe9f187b50b79d97b84535ce9bf776305728b0cdfe17285e94f028452'
d=json.loads(source.read_text());T=d['term_table'];N=d['nodes'];n=len(N);root=d['roots']['rho8']
assert root==n-1 and all(node['id']==i for i,node in enumerate(N))
sizes=[]
for i,t in enumerate(T):
 if isinstance(t,list):assert len(t)==2 and all(0<=j<i for j in t)
 sizes.append(1+sum(sizes[c] for c in t) if isinstance(t,list) else 1)

def parents(rule):return tuple(rule[k] for k in ('major','minor','parent') if k in rule)
def match(p,t,e,seen):
 if (p,t) in seen:return True
 seen.add((p,t));x,y=T[p],T[t]
 if isinstance(x,dict):return e.setdefault(str(x['var']),t)==t
 if x=='T':return y=='T'
 return isinstance(y,list) and match(x[0],y[0],e,seen) and match(x[1],y[1],e,seen)
zero=next(i for i,t in enumerate(T) if t=='T')
keys={('T',):zero}
variable_sets=[]
for i,t in enumerate(T):
 if isinstance(t,dict):
  keys[('V',t['var'])]=i;vs={str(t['var'])}
 elif isinstance(t,list):
  assert not (t[0]==zero and t[1]==zero), 'input term table is already normalized'
  keys[('I',*t)]=i;vs=variable_sets[t[0]]|variable_sets[t[1]]
 else:vs=set()
 variable_sets.append(vs)
def match_normalized(p,t,e,seen):
 if (p,t) in seen:return True
 seen.add((p,t));x,y=T[p],T[t]
 if isinstance(x,dict):return e.setdefault(str(x['var']),t)==t
 if x=='T':return y=='T'
 if y=='T':return all(e.setdefault(v,zero)==zero for v in variable_sets[p])
 return isinstance(y,list) and match_normalized(x[0],y[0],e,seen) and match_normalized(x[1],y[1],e,seen)
def exact_normalized(p,t,e):
 cache={}
 def go(k):
  if k in cache:return cache[k]
  x=T[k]
  if isinstance(x,dict):r=e.get(str(x['var']),k)
  elif x=='T':r=zero
  else:
   a,b=go(x[0]),go(x[1]);r=zero if a==b==zero else keys.get(('I',a,b),-1)
  cache[k]=r;return r
 return go(p)==t
def closure(rules):
 used=set();todo=[root]
 while todo:
  i=todo.pop()
  if i in used:continue
  used.add(i);todo.extend(parents(rules[i]))
 return used
def metrics(rules):
 used=closure(rules)
 return {'nodes':len(used),'instructions':sum(3 if rules[i]['kind']=='mp_substitution' else 1 for i in used)}

loaded_options=Path('/tmp/k215-proof-concision-search/global/run2/options.json')
assert sha(loaded_options)=='998251182d58d15d88a5ba90eaeb950ac1ec6fa61c11b886e5874f19456cfd83'
options=json.loads(loaded_options.read_text());assert len(options)==n
baseline=[];patterns=[];matches=5766;tests=6947128
for i,node in enumerate(N):
 original=copy.deepcopy(node['rule']);first=None
 for j in patterns:
  if sizes[N[j]['term']]>sizes[node['term']]:continue
  e={}
  if match(N[j]['term'],node['term'],e,set()):
   first={'kind':'substitution','parent':j,'substitution':e};break
 if first is None:patterns.append(i)
 baseline.append(first or original)
 for rule in options[i]:
  assert all(j<i for j in parents(rule))
  if rule!=original:assert rule['kind']=='substitution' and exact_normalized(N[rule['parent']]['term'],node['term'],rule['substitution'])
assert metrics(baseline)=={'nodes':674,'instructions':780}
for i,rule in enumerate(baseline):
 assert any(set(parents(r))==set(parents(rule)) for r in options[i])
build_seconds=time.monotonic()-start

# x_i selects theorem node i. y_ir selects one valid derivation of that node.
# sum_r y_ir = x_i; y_ir <= x_j for each prerequisite j; x_root = 1.
# Strictly earlier prerequisite IDs make this an acyclic proof, not a circular
# Boolean solution. Node count is the sole solver objective.
flat=[(i,r) for i,opts in enumerate(options) for r in opts]
nv=n+len(flat);row=[];col=[];val=[];lb=[];ub=[]
def add(items,lo,hi):
 k=len(lb);lb.append(lo);ub.append(hi)
 for c,v in items:row.append(k);col.append(c);val.append(v)
offset=n
for i,opts in enumerate(options):
 add([(i,-1)]+[(offset+j,1) for j in range(len(opts))],0,0);offset+=len(opts)
for k,(i,rule) in enumerate(flat):
 for j in set(parents(rule)):
  assert j<i
  add([(n+k,1),(j,-1)],-np.inf,0)
add([(i,1) for i in range(n)],-np.inf,674)
A=coo_array((np.array(val,float),(np.array(row,np.int32),np.array(col,np.int32))),shape=(len(lb),nv)).tocsc()
lower=np.zeros(nv);upper=np.ones(nv);lower[root]=1
model={'nodes':n,'rules':len(flat),'variables':nv,'constraints':len(lb),'exact_schema_match_tests':tests,'exact_schema_matches':matches,'option_build_seconds':build_seconds,'time_limit':args.seconds,'baseline':metrics(baseline),'objective':'expanded instruction count subject to at most 674 nodes','options_reuse_sha256':sha(loaded_options),'family':'all earlier exact normalized substitution instances, including Imp(T,T)=T','root':root,'scipy':scipy.__version__,'numpy':np.__version__,'source_sha256':sha(source),'script_sha256':sha(Path(__file__))}
(out/'model.json').write_text(json.dumps(model,indent=2)+'\n')
(out/'options.json').write_text(json.dumps(options,separators=(',',':'))+'\n')
print(json.dumps(model,indent=2),flush=True)
result=milp(np.r_[np.ones(n),np.array([2 if rule['kind']=='mp_substitution' else 0 for _,rule in flat])],integrality=np.ones(nv),bounds=Bounds(lower,upper),constraints=LinearConstraint(A,np.array(lb),np.array(ub)),options={'time_limit':args.seconds,'mip_rel_gap':0.0,'disp':True,'presolve':True})
selected=copy.deepcopy(baseline);solver_used=False;solver_values={}
for key in ('status','message','success','fun','mip_node_count','mip_dual_bound','mip_gap'):
 value=getattr(result,key,None)
 solver_values[key]=value.item() if isinstance(value,np.generic) else value
if result.x is not None:
 rounded=np.rint(result.x).astype(int)
 assert np.max(np.abs(result.x-rounded))<1e-5
 assert np.all((rounded==0)|(rounded==1)) and rounded[root]==1
 assert sum(rounded[:n])<=674
 for i in range(n):
  hits=[r for k,(owner,r) in enumerate(flat) if owner==i and rounded[n+k]]
  assert len(hits)==rounded[i]
  if hits:
   assert all(rounded[j] and j<i for j in parents(hits[0]))
   selected[i]=hits[0]
 assert metrics(selected)['nodes']<=sum(rounded[:n])
 solver_used=tuple(metrics(selected)[k] for k in ('nodes','instructions'))<(674,780)
 if not solver_used:selected=copy.deepcopy(baseline)

# Revalidate selected substitutions independently with no memoized matcher.
def check_instance(p,t,e):
 x,y=T[p],T[t]
 if isinstance(x,dict):return e.get(str(x['var']),p)==t
 if x=='T':return y=='T'
 return isinstance(y,list) and check_instance(x[0],y[0],e) and check_instance(x[1],y[1],e)
used=sorted(closure(selected));nm={v:i for i,v in enumerate(used)};used_terms=set()
def visit(t):
 if t in used_terms:return
 used_terms.add(t)
 if isinstance(T[t],list):
  for j in T[t]:visit(j)
for i in used:
 rule=selected[i];assert all(j<i and j in nm for j in parents(rule))
 if rule!=N[i]['rule']:
  assert rule['kind']=='substitution' and exact_normalized(N[rule['parent']]['term'],N[i]['term'],rule['substitution'])
 visit(N[i]['term'])
 for field in ('substitution','major_substitution','minor_substitution'):
  for t in rule.get(field,{}).values():visit(t)
for i,t in enumerate(T):
 if t=='T' or isinstance(t,dict):visit(i)
tm={v:i for i,v in enumerate(sorted(used_terms))};new=[]
for i in used:
 rule=copy.deepcopy(selected[i])
 for field in ('major','minor','parent'):
  if field in rule:rule[field]=nm[rule[field]]
 for field in ('substitution','major_substitution','minor_substitution'):
  if field in rule:rule[field]={v:tm[t] for v,t in rule[field].items()}
 new.append({'id':nm[i],'term':tm[N[i]['term']],'rule':rule,'origin':i})
cert=copy.deepcopy(d);cert['nodes']=new;cert['term_table']=[[tm[c] for c in T[t]] if isinstance(T[t],list) else T[t] for t in sorted(used_terms)];cert['roots']={k:nm[v] for k,v in d['roots'].items() if v in nm};cert['sources']={'original':str(source),'sha256':sha(source),'scope':'Untrusted AND/OR proof production; no kernel invocation.'}
candidate=out/'certificate.json';candidate.write_text(json.dumps(cert,separators=(',',':'))+'\n')
record={'status':'UNTRUSTED_PROOF_CANDIDATE','best':metrics(selected),'improvement':solver_used,'solver':solver_values,'seconds':time.monotonic()-start,'candidate_sha256':sha(candidate),'candidate':str(candidate),'term_count':len(used_terms),'model_sha256':sha(out/'model.json'),'options_sha256':sha(out/'options.json'),'all_earlier_normalized_schema_options_complete':True,'selected_substitutions_and_acyclicity_rechecked':True,'kernel_invoked':False,'canonical_mutations':False}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
