"""Own bounded import-repair plans; no proof compiler or original runner execution."""
from pathlib import Path
import hashlib,json,difflib,importlib.util
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent;O=Path('/tmp/k215-phase15-check')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
def save(name,x):(S/name).write_text(json.dumps(x,indent=2)+'\n')
p=R/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/KQ1ZF.lean';old=p.read_text();new='import FirstOrder.Completeness\n'+old
candidate=S/'candidate/BusyBeaver/ZFC/KQ1ZF.lean';candidate.write_text(new);(S/'KQ1ZF.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='checked/KQ1ZF.lean',tofile='candidate/KQ1ZF.lean')))
assert candidate.read_text().split('\n',1)[1]==old
# The old source-only inventory implementation, with only the new explicit source allowed.
src=(O/'census.py').read_text();needle="'WFModelCore','KDenseBridge']";assert src.count(needle)==1
src=src.replace(needle,"'WFModelCore','KDenseBridge','KQ1ZF']")
(S/'census.py').write_text(src)
sources=read(O/'sources.json');sources.append({'module':'BusyBeaver.ZFC.KQ1ZF','source':str(candidate),'source_sha256':sha(candidate),'before_sha256':sha(p),'canonical':str(p.relative_to(R)),'imports':['FirstOrder.Completeness']+[line.split()[1]for line in old.splitlines()if line.startswith('import ')]})
dense_input=Path('/tmp/k215-intake215/K215_Proof_Simplification (2)/k215-proof-simplification/lean-bridge/minimal/BusyBeaver/ZFC/KDenseBridge.lean')
dense=S/'candidate/BusyBeaver/ZFC/KDenseBridge.lean';dense.write_bytes(dense_input.read_bytes())
prior=Path('/tmp/k215-phase15-basic/candidate/BusyBeaver/ZFC/KDenseBridge.lean')
assert dense.read_text().split('theorem blank_iff')[0]==prior.read_text().split('theorem blank_iff')[0]
assert dense.read_text().split('theorem blank_iff',1)[1].split(':= by',1)[0]==prior.read_text().split('theorem blank_iff',1)[1].split(':= by',1)[0]
for r in sources:
 if r['module']=='BusyBeaver.ZFC.KDenseBridge':r['source']=str(dense);r['source_sha256']=sha(dense);r['proposal_source']=str(dense_input);r['proposal_sha256']=sha(dense)
assert 'BusyBeaver.ZFC.KDenseBridge' not in read(O/'primary-run1/completed.json')
(S/'DenseBridge193.diff').write_text(''.join(difflib.unified_diff(prior.read_text().splitlines(True),dense.read_text().splitlines(True),fromfile='frozen192/KDenseBridge.lean',tofile='source193/KDenseBridge.lean')))
save('sources.json',sources);save('clients.json',read(O/'clients.json'))
spec=importlib.util.spec_from_file_location('own_source_census',S/'census.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mod.census(S/'plan1',sources,read(S/'clients.json'))
summary=read(S/'plan1/census.json');assert(summary['primary_providers'],summary['primary_fresh'],summary['primary_reuse'],summary['compatibility_providers'])==(194,45,149,71)
for name in ['primary','compatibility']:
 original=read(O/('primary-map.json' if name=='primary' else'compatibility-template.json'));inv=read(S/'plan1'/(name+'-inventory.json'))
 if name=='primary':original['modules'].append(sources[-1])
 for r in original['modules']:
  if r['module']=='BusyBeaver.ZFC.KDenseBridge':r.update(source=str(dense),source_sha256=sha(dense),proposal_source=str(dense_input),proposal_sha256=sha(dense))
 original['expected']={'modules':[r['module']for r in inv['modules']],'changed':inv['changed'],'forced':inv['forced']}
 save('primary-map.json' if name=='primary'else'compatibility-template.json',original)
commands=read(O/'commands.json');commands['status']='IMPORT_REPAIR_RETRY_PENDING_PEER_AND_ROOT_GO';commands['initialize']=['python3','-B',str(S/'initialize.py')]
commands['primary']=[str(S/'primary-map.json')if x==str(O/'primary-map.json')else str(O/'primary-run2')if x==str(O/'primary-run1')else x for x in commands['primary']]
commands['compatibility']=[str(S/'compatibility-final-map.json')if x==str(O/'compatibility-final-map.json')else str(O/'primary-run2')if x==str(O/'primary-run1')else x for x in commands['compatibility']]
commands['finalize_compatibility']=['python3','-B',str(S/'finalize_compatibility.py'),'--primary',str(O/'primary-run2'),'--out',str(S/'compatibility-final-map.json')]
save('commands.json',commands)
fin=(O/'finalize_compatibility.py').read_text().replace("S=Path(__file__).resolve().parent","S=Path(__file__).resolve().parent;R=Path('/tmp/k215-phase15-check')").replace("(S/'primary-run1').resolve()","(R/'primary-run2').resolve()").replace("sha(S/'build.py')","sha(R/'build.py')")
(S/'finalize_compatibility.py').write_text(fin)
# Reuse the previously peer-checked minimal initializer, with only exact prefix/failure facts.
ini=Path('/tmp/k215-phase14-retry/initialize.py').read_text().replace('phase14-check','phase15-check').replace('phase14-execution','phase15-execution')
ini=ini.replace('only189','only87').replace("len(inv['modules'])==190 and len(done)==189","len(inv['modules'])==194 and len(done)==87")
ini=ini.replace("assert set(done)=={r['module']for r in inv['modules']}-{'ProfileTC14Api'}","assert list(done)==[r['module']for r in inv['modules']][:87]\nassert inv['modules'][87]['module']=='BusyBeaver.ZFC.KQ1ZF'")
ini=ini.replace("==65","==19").replace("==124","==68").replace('phase13_primary_checked','phase14_primary_checked').replace('066-ProfileTC14Api','020-BusyBeaver.ZFC.KQ1ZF')
ini=ini.replace("'objects/ProfileTC14Api.olean'","'objects/BusyBeaver/ZFC/KQ1ZF.olean'")
ini=ini.replace("'FAILED_CLIENT_ELABORATION'","'FAILED_MISSING_EXPLICIT_IMPORT'").replace("'failed_client_excluded':'ProfileTC14Api'","'failed_module_excluded':'BusyBeaver.ZFC.KQ1ZF'")
ini=ini.replace("'resumed_providers':189","'resumed_providers':87").replace("'prior_successful_fresh_invocations':65","'prior_successful_fresh_invocations':19").replace("'prior_phase13_reused_providers':124","'prior_phase14_reused_providers':68")
ini=ini.replace("'new_calls_still_required':['ProfileTC14Api','EndpointAudit215','K215Audit']","'new_fresh_module_calls_still_required':26,'new_endpoint_audits_still_required':2")
(S/'initialize.py').write_text(ini)
save('repair.json',{'status':'SOURCE_ONLY_IMPORT_REPAIR_UNCOMPILED','before_sha256':sha(p),'candidate_sha256':sha(candidate),'KQ1ZF_only_change':'Add explicit FirstOrder.Completeness import; remaining bytes exact.','dense_source193':{'path':str(dense_input),'sha256':sha(dense),'scope':'Exact later Source193 proof bytes; generic header and all prior declarations unchanged; absent from completed prefix.'},'pre193_history':'/tmp/k215-phase15-retry-import-only-pre193','declarations_supplied':'BProv and soundness_BProv in FirstOrder.Completeness','handwritten_source':True,'generator_outputs_unchanged':True,'old_run_remains_failed':True,'old_primary_before_sha256':sha(O/'primary-run1/before.json'),'old_primary_inventory_sha256':sha(O/'primary-run1/inventory.json'),'old_completed_sha256':sha(O/'primary-run1/completed.json'),'failed_log_sha256':sha(O/'primary-run1/attempts/020-BusyBeaver.ZFC.KQ1ZF/compiler.log'),'old_outer_sha256':sha(Path('/tmp/k215-phase15-execution/primary-run1-outer.json')),'prefix_pass':87,'prior_successful_fresh':19,'prior_basis_reused':68,'new_required_fresh':26,'new_endpoint_audits':2})
print(json.dumps({'status':'PREPARED_NOT_EXECUTED','candidate':sha(candidate),'primary_map':sha(S/'primary-map.json'),'initializer':sha(S/'initialize.py')},indent=2))
