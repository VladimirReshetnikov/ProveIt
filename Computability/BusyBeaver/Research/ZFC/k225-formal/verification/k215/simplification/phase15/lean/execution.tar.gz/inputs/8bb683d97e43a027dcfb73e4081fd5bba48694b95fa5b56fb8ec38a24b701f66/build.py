"""Serial incremental candidate check with an explicit source map and immutable providers."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,signal,fcntl
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');B=Path('/tmp/k215-phase14-check/primary-run2');BC=Path('/tmp/k215-phase14-check/compatibility-run1');A=Path('/tmp/k215-proof-phase8/lean-run1');S=Path(__file__).resolve().parent
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
a=argparse.ArgumentParser();a.add_argument('--out',type=Path,required=True);a.add_argument('--map',type=Path,required=True);a.add_argument('--target',action='append',required=True);a.add_argument('--reuse',type=Path);a.add_argument('--audit-endpoint',action='store_true');args=a.parse_args();out=args.out;out.mkdir(exist_ok=True);lock=(out/'output.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert sha(B/'result.json')=='3454f69d71477171f20d91733093821fa3198253dece63802c59d045bf3991df'
assert sha(BC/'result.json')=='008d6626c9c2b11400713bda9dff89aa5385f276d0898f13c1f0dd19cda857b1'
assert sha(A/'result.json')=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd';assert sha(C)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
spec=importlib.util.spec_from_file_location('supervisor',H);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
baseline=read(B/'result.json');compatibility_baseline=read(BC/'result.json')
assert baseline['status']==compatibility_baseline['status']=='PASS'
def exact_endpoint_profile(name,reports):
 normalize=lambda rs:[(n,{a.strip()for a in ax.split(',')if a.strip()})for n,ax in rs]
 expected={r['module']:r['named_reports']for r in baseline['audits']}
 return name in expected and normalize(reports)==normalize(expected[name])
plans=read(args.map)['modules'];overrides={r['module']:r for r in plans};assert len(overrides)==len(plans)
inputs={str(p):sha(p)for p in [H,C,Path(__file__),args.map]};basis={};basis_kind={};old={};old_entries={}
for directory,kind,count in [(BC,'phase14_compatibility_checked',70),(B,'phase14_primary_checked',190)]:
 result=read(directory/'result.json');inventory=read(directory/'inventory.json');completed=read(directory/'completed.json')
 assert sha(directory/'completed.json')==result['completed_sha256']and sha(directory/'inventory.json')==result['inventory_sha256']
 assert len(completed)==len(inventory['modules'])==count and len({r['module']for r in inventory['modules']})==count
 for name in ['result.json','inventory.json','completed.json','toolchain.json']:inputs[str(directory/name)]=sha(directory/name)
 assert read(directory/'toolchain.json')==read(B/'toolchain.json')
 entries={r['module']:r for r in inventory['modules']}
 for m,rec in completed.items():
  assert rec['status']=='PASS'and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
  entry=entries[m];assert rec['source_sha256']==entry['source_sha256'];assert rec['dependencies']=={d:completed[d]['object_sha256']for d in entry['imports']if d!='Init'}
  obj=directory/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
  if m in old:assert entry['source_sha256']==old_entries[m]['source_sha256']and entry['imports']==old_entries[m]['imports']and rec['object_sha256']==old[m]['object_sha256']
  old[m]=rec;old_entries[m]=entry;basis[m]=(rec,obj);basis_kind[m]=kind
  inputs[str(obj)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
assert len(old)==207
assert all(rec['dependencies']=={d:old[d]['object_sha256']for d in old_entries[m]['imports']if d!='Init'}for m,rec in old.items())
ancestry=read(A/'result.json');assert ancestry['status']=='PASS' and baseline['status']=='PASS'
assert sha(A/'completed.json')==ancestry['completed_sha256'] and sha(A/'inventory.json')==ancestry['inventory_sha256']
assert len(read(A/'completed.json'))==len(read(A/'inventory.json')['modules'])==188
for p in [A/n for n in ['result.json','inventory.json','completed.json','toolchain.json']]:inputs[str(p)]=sha(p)
assert read(A/'toolchain.json')==read(B/'toolchain.json')
for name,pin in ancestry['exact_machine_pins'].items():
 path=R/'Computability/BusyBeaver/Research/ZFC/candidate-k215'/name;assert sha(path)==pin;inputs[str(path)]=pin
boundary_path=S/'producer-boundary.json';assert sha(boundary_path)=='8fe00c87b8771445f52c23d7b057a86e37b7b5708d55800228495cb8d08c56b0'
producer_boundary=read(boundary_path);inputs[str(boundary_path)]=sha(boundary_path)
assert producer_boundary['phase8_result_sha256']==sha(A/'result.json')
assert producer_boundary['phase14_primary_result_sha256']==sha(B/'result.json') and producer_boundary['phase14_compatibility_result_sha256']==sha(BC/'result.json')
for p,h in producer_boundary['present_inputs'].items():assert sha(p)==h;inputs[p]=h
absent_inputs=producer_boundary['absent_inputs'];assert len(absent_inputs)==5
for p in absent_inputs:assert not Path(p).exists()and not Path(p).is_symlink(),p
retirements=producer_boundary['retained_retirements'];assert len(retirements)==2
assert {Path(r['path']).name for r in retirements}=={'KProfileTC.lean','generate_profile_tc.py'}
retired_modules={'BusyBeaver.ZFC.KProfileTC'}
assert len(producer_boundary['accepted_five_files'])==5
assert all(producer_boundary['present_inputs'].get(p)==h for p,h in producer_boundary['accepted_five_files'].items())
# Revalidate all 198 current project sources, not only the newly selected closure.
old_clients={'GenericShared13Api','NumericCD52Api','LukasShared13Api','DerivedRows14Api','ThmKDerived14Api','KEindDerived14Api','ProfileTC14Api','WFModelCompat12','ZFNativeCompat12'}
assert len(set(old)-old_clients)==198
for m,row in old_entries.items():
 if m in old_clients:continue
 found=[p for root in driver.ROOTS if (p:=R/root/(m.replace('.','/')+'.lean')).is_file()]
 assert len(found)==1;path=found[0]
 imports=[w for l in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',driver.without_comments_strings(path.read_text()))for w in l.split()]
 assert sha(path)==row['source_sha256']and imports==row['imports'];inputs[str(path)]=sha(path)
for row in plans:
 assert sha(row['source'])==row['source_sha256'];inputs[row['source']]=row['source_sha256']
 if row['module']in old:assert row['before_sha256']==old[row['module']]['source_sha256']
for key in ['lean','lake','Init.olean','project_toolchain']:
 t=read(B/'toolchain.json')[key];assert sha(t['path'])==t['sha256'];inputs[t['path']]=t['sha256']
rows=[];seen=set();active=set();external=set()
def visit(m):
 assert m not in retired_modules,('Retired dependency selected',m)
 if m in seen:return
 assert m not in active,('cycle',m)
 if m in overrides:path=Path(overrides[m]['source'])
 else:
  found=[p for root in driver.ROOTS if (p:=R/root/(m.replace('.','/')+'.lean')).is_file()]
  if not found:assert m=='Init';external.add(m);return
  assert len(found)==1;assert m in old,('Unregistered module',m);path=found[0]
 clean=driver.without_comments_strings(path.read_text());imports=[w for l in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',clean)for w in l.split()]
 if m in overrides:assert imports==overrides[m]['imports']
 elif m in old:assert sha(path)==old[m]['source_sha256']
 inputs[str(path)]=sha(path);active.add(m)
 for d in imports:visit(d)
 active.remove(m);seen.add(m);rows.append({'module':m,'source':str(path),'source_sha256':sha(path),'imports':imports})
for target in args.target:visit(target)
owner={'map_sha256':sha(args.map),'runner_sha256':sha(__file__),'targets':args.target,'audit_endpoint':args.audit_endpoint,'rows':rows,'inputs':inputs,'absent_inputs':sorted(absent_inputs),'external_imports':sorted(external)}
cache=out/'objects';workspace=out/'workspace';env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
reuse={}
if args.reuse:
 pins=read(args.map)['reuse_ledger'];assert args.reuse.resolve()==Path(pins['directory']).resolve()
 for name in ['result.json','inventory.json','completed.json']:
  assert sha(args.reuse/name)==pins[name];inputs[str(args.reuse/name)]=pins[name]
 reuse_result=read(args.reuse/'result.json');assert reuse_result['status']=='PASS'
 assert sha(args.reuse/'inventory.json')==reuse_result['inventory_sha256']and sha(args.reuse/'completed.json')==reuse_result['completed_sha256']
 for m,rec in read(args.reuse/'completed.json').items():
  obj=args.reuse/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256'];reuse[m]=(rec,obj);inputs[str(obj)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
entry_by_name={r['module']:r for r in rows}
changed={m for m,r in entry_by_name.items()if m not in old or(r['source_sha256'],r['imports'])!=(old_entries[m]['source_sha256'],old_entries[m]['imports'])}
forced=set(changed)
while True:
 more=forced|{m for m,r in entry_by_name.items()if set(r['imports'])&forced}
 if more==forced:break
 forced=more
reuse_rows={r['module']:r for r in read(args.reuse/'inventory.json')['modules']}if args.reuse else {}
compatible={}
def same_transitive_sources(m):
 if m=='Init':return True
 if m in compatible:return compatible[m]
 a=entry_by_name[m];b=reuse_rows.get(m)
 compatible[m]=bool(b and a['source_sha256']==b['source_sha256']and a['imports']==b['imports']and all(same_transitive_sources(d)for d in a['imports']))
 return compatible[m]
owner['changed_sources']=sorted(changed);owner['force_basis_rebuild']=sorted(forced)
expected=read(args.map)['expected'];assert [r['module']for r in rows]==expected['modules'];assert sorted(changed)==expected['changed'];assert sorted(forced)==expected['forced']
if (out/'before.json').exists():
 assert read(out/'before.json')==owner
 done=read(out/'completed.json')
else:
 assert {p.name for p in out.iterdir()}=={'output.lock'};save(out/'before.json',owner);save(out/'inventory.json',{'modules':rows,'targets':args.target,'external_imports':sorted(external)});save(out/'toolchain.json',read(B/'toolchain.json'));done={};save(out/'completed.json',done)
def log_policy(row,rec):
 if rec['status']!='PASS' or rec.get('exit_code',0)!=0 or rec.get('timed_out',False):return False
 txt=Path(rec['log']).read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
 if 'error:'in txt or 'sorryAx'in txt:return False
 if not all({s.strip()for s in ax.split(',')if s.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports):return False
 plan=overrides.get(row['module'],{})
 if 'report_axioms'in plan and [{s.strip()for s in ax.split(',')if s.strip()}for _,ax in reports]!=[set(a)for a in plan['report_axioms']]:return False
 return 'reports'not in plan or ([n for n,_ in reports]==plan['reports']and 'warning:'not in txt)
for row in rows:
 m=row['module'];obj=cache/(m.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True)
 for parent in obj.parents:
  assert not parent.is_symlink()
  if parent==cache:break
 deps={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 for d,h in deps.items():assert sha(cache/(d.replace('.','/')+'.olean'))==h
 def usable(rec,path):return log_policy(row,rec)and rec['source_sha256']==row['source_sha256']and rec['dependencies']==deps and path.is_file()and sha(path)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
 if m in done and usable(done[m],obj):
  assert done[m]['origin']in {'phase14_primary_checked','phase14_compatibility_checked','secondary_checked','candidate_fresh'}
  assert done[m]['origin']not in {'phase14_primary_checked','phase14_compatibility_checked'}or m not in forced
  assert done[m]['origin']!='secondary_checked' or same_transitive_sources(m)
  continue
 source=workspace/(m.replace('.','/')+'.lean');source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(Path(row['source']).read_bytes())
 choices=[('secondary_checked',reuse[m])]if m in reuse and same_transitive_sources(m)else []
 if m in basis and m not in forced:choices.append((basis_kind[m],basis[m]))
 for origin,(rec,prior)in choices:
  if usable(rec,prior):
   obj.unlink(missing_ok=True);obj.symlink_to(prior);done[m]={**rec,'origin':origin};save(out/'completed.json',done);print('REUSE',m,origin,flush=True);break
 else:
  attempts=out/'attempts';attempts.mkdir(exist_ok=True);attempt=attempts/(str(len(list(attempts.iterdir()))+1).zfill(3)+'-'+m);attempt.mkdir();(attempt/source.name).write_bytes(source.read_bytes());log=attempt/'compiler.log';record=attempt/'record.json';obj.unlink(missing_ok=True)
  timeout=900 if 'KSites215Batch'in m else 120;cmd=[str(C),'-j1','-M12288','--root='+str(workspace),'-o',str(obj),str(source)]
  rec={'module':m,'source':str(source),'source_sha256':row['source_sha256'],'candidate':row['source'],'dependencies':deps,'command':cmd,'timeout_seconds':timeout,'memory_mebibytes':12288,'compiler_sha256':sha(C),'helper_sha256':sha(H),'log':str(log),'origin':'candidate_fresh'}
  print('CHECK',m,flush=True);ok=driver.run_locked(cmd,R,env,LOCK,log,timeout,rec,record);txt=log.read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt);rec.update(warnings=txt.count('warning:'),reports=reports,object_sha256=sha(obj)if ok else None);save(record,rec);print(rec['status'],m,round(rec['seconds'],3),rec['warnings'],'warnings',flush=True)
  assert ok and not rec['timed_out'],m;assert 'sorryAx'not in txt
  assert all({s.strip()for s in ax.split(',')if s.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports)
  if m in overrides and 'reports'in overrides[m]:assert [n for n,_ in reports]==overrides[m]['reports'];assert rec['warnings']==0
  assert log_policy(row,rec);assert sha(source)==row['source_sha256'];done[m]=rec;save(out/'completed.json',done)
 assert sha(obj)==done[m]['object_sha256']
def postcheck():
 for m in retired_modules:
  p=cache/(m.replace('.','/')+'.olean');assert not p.exists()and not p.is_symlink()and m not in entry_by_name
 for p in absent_inputs:assert not Path(p).exists()and not Path(p).is_symlink(),p
 for p,h in inputs.items():assert sha(p)==h,p
 for row in rows:
  rec=done[row['module']];assert sha(row['source'])==rec['source_sha256']==row['source_sha256'];assert rec['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'};assert sha(cache/(row['module'].replace('.','/')+'.olean'))==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256'];assert log_policy(row,rec)
  if rec['origin']=='candidate_fresh':assert sha(rec['source'])==row['source_sha256']
assert set(done)==set(entry_by_name)
postcheck();audits=[]
if args.audit_endpoint:
 assert 'BusyBeaver.ZFC.KEndpoint215'in seen
 gates=Path('/tmp/k215-proof-phase8/gates.py');assert sha(gates)=='b2dcfb0f69372e25b14ed479382739966bad1488dc05289b3e5fc4ed7bdc1475';spec=importlib.util.spec_from_file_location('audit_gates',gates);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 for name,pin in g.AUDIT_PINS.items():
  src=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean'/(name+'.lean');assert sha(src)==pin;adir=out/('audit-'+name);adir.mkdir();target=adir/src.name;target.write_bytes(src.read_bytes());obj=adir/(name+'.olean');log=adir/(name+'.log');record=adir/(name+'.json');cmd=[str(C),'-j1','-M12288','--root='+str(adir),'-o',str(obj),str(target)]
  rec={'module':name,'source':str(src),'source_sha256':pin,'dependencies':{m:r['object_sha256']for m,r in done.items()},'command':cmd,'timeout_seconds':120,'memory_mebibytes':12288,'compiler_sha256':sha(C),'log':str(log)};print('AUDIT',name,flush=True);ok=driver.run_locked(cmd,R,env,LOCK,log,120,rec,record);assert ok;rec.update(named_reports=g.audit_reports(name,log.read_text()),object_sha256=sha(obj));assert exact_endpoint_profile(name,rec['named_reports']);save(record,rec);audits.append(rec)
postcheck()
for rec in audits:
 assert exact_endpoint_profile(rec['module'],rec['named_reports'])
 assert sha(rec['log'])==rec['log_sha256'];assert sha(rec['source'])==rec['source_sha256'];assert sha(out/('audit-'+rec['module'])/(rec['module']+'.olean'))==rec['object_sha256'];assert sha(out/('audit-'+rec['module'])/(rec['module']+'.lean'))==rec['source_sha256'];assert [list(r)for r in g.audit_reports(rec['module'],Path(rec['log']).read_text())]==[list(r)for r in rec['named_reports']]
if args.audit_endpoint:assert sha(gates)=='b2dcfb0f69372e25b14ed479382739966bad1488dc05289b3e5fc4ed7bdc1475'
save(out/'result.json',{'status':'PASS','targets':args.target,'selected_project_modules':len(done),'source_changed_modules':sorted(changed),'force_basis_rebuild_modules':sorted(forced),'basis_reuse_rejects_transitive_source_changes':True,'secondary_reuse_requires_exact_transitive_sources_and_imports':True,'fresh_modules':[m for m,r in done.items()if r['origin']=='candidate_fresh'],'phase14_primary_reused_modules':[m for m,r in done.items()if r['origin']=='phase14_primary_checked'],'phase14_compatibility_reused_modules':[m for m,r in done.items()if r['origin']=='phase14_compatibility_checked'],'secondary_reused_modules':[m for m,r in done.items()if r['origin']=='secondary_checked'],'audits':audits,'inputs_sources_objects_dependencies_logs_toolchain_rechecked':True,'retained_retirements':retirements,'retired_modules_absent_from_candidate':sorted(retired_modules),'inventory_sha256':sha(out/'inventory.json'),'completed_sha256':sha(out/'completed.json'),'runner_sha256':sha(__file__),'map_sha256':sha(args.map),'producer_boundary_sha256':sha(boundary_path),'basis_result_sha256':sha(B/'result.json'),'compatibility_basis_result_sha256':sha(BC/'result.json'),'scope':'Candidate incremental closure only; exact targets/fresh/reused providers listed. No implicit canonical adoption or formalization claim for other targets.'});print('COMPLETE',len(done),len(audits),'audits',flush=True)
