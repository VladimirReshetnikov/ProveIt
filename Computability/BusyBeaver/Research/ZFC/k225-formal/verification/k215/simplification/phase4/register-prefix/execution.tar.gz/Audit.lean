import BusyBeaver.ZFC.RMBisim
open SetTheory.BusyBeaver.ZFC
open RegisterPath RMBisim
open RMEquiv (HN)

example (p : Program) (f : Nat) (P : List Bool) (l : List Nat) (P' : List Bool)
    (R : Registers) (N : Nat) (hs : seg (ptree p) f P = some (l, P'))
    (hN : HN p N ⟨P, R⟩) :
    ∃ N' R', N' ≤ N ∧ HN p N' ⟨P', R'⟩ ∧ ∀ i, R' i = R i + cnt l i :=
  seg_hn p f P l P' R N hs hN

example (p1 p2 : Program) (T : CTree)
    (hs : branchOk (ptree p1) (ptree p2) T [] [] 0 = true)
    (ha : allC (entryOk (ptree p1) (ptree p2) T) T = true) (R : Registers) :
    Halts p1 ⟨[], R⟩ ↔ Halts p2 ⟨[], R⟩ := check_halts_iff hs ha R

#print axioms seg_run
#print axioms seg_hn
#print axioms Bisim.halts
#print axioms check_halts_iff
