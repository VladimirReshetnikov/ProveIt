import BusyBeaver.ZFC.ConstructibleAbs
namespace SetTheory.BusyBeaver.ZFC.ConstructibleAbs
open NamedZF InternalOrd Constructible ConstructibleZF LeanProofs.BoundedZFCConsistency
universe u
variable {V : Type u} {mem : V → V → Prop}
variable (H : ZFAxioms mem) (hR : Regular mem) (hP : ∀ a, ∃ p, ∀ x, mem x p ↔ Sub mem x a)
example (a : {x // InL H hP x}) :
    (vunion (L_zfAxioms H hR hP) a).1 = vunion H a.1 := val_vunion H hR hP a
example (c : {x // InL H hP x}) :
    inductiveV (L_zfAxioms H hR hP) c ↔ inductiveV H c.1 := inductive_iff H hR hP c
#print axioms val_vunion
#print axioms inductive_iff
#print axioms quant_clause
#print axioms gdef_eq
#print axioms vEqL
end SetTheory.BusyBeaver.ZFC.ConstructibleAbs
