"""Root's read-only audit of the completed legacy provider overlay and fresh clients."""
from pathlib import Path
import hashlib,json,re
B=Path('/tmp/k215-phase8-legacy');R=B/'run1';P=Path('/tmp/k215-proof-phase8/lean-run1');L=Path('/tmp/k215-phase7-legacy/run1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
out=B/'root-actual-review.json';assert not out.exists()
r=read(R/'result.json');inv=read(R/'inventory.json');done=read(R/'completed.json');pd=read(P/'completed.json');old=read(L/'completed.json')
assert r['status']=='PASS' and(r['primary_project_modules'],r['legacy_only_modules'],r['project_modules'],r['fresh_legacy_modules'],r['reused_legacy_modules'])==(188,15,203,0,15)
assert r['new_legacy_audit_executed']and r['all203_selected_objects_sources_dependencies_logs_rechecked_after_audit']and r['immutable_basis_inputs_rechecked_after_audit']
assert sha(P/'result.json')==r['primary_result_sha256']=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
assert sha(R/'inventory.json')==r['inventory_sha256']and sha(R/'completed.json')==r['completed_sha256']
assert len(inv['modules'])==len(done)==203 and set(done)=={e['module']for e in inv['modules']}
extra=set(done)-set(pd);assert len(extra)==15 and not r['fresh_modules']
assert read(R/'primary-result.json')==read(P/'result.json') and read(R/'primary-completed.json')==pd
assert read(R/'legacy-result.json')==read(L/'result.json') and read(R/'legacy-completed.json')==old
cache=R/'objects';assert not cache.is_symlink()
assert {p.relative_to(cache).as_posix()for p in cache.rglob('*')if p.is_file()}=={m.replace('.','/')+'.olean'for m in done}
for e in inv['modules']:
 m=e['module'];rec=done[m];parent=L if m in extra else P;origin='phase7_legacy_hash_bound'if m in extra else'phase8_primary_hash_bound'
 assert rec['origin']==origin and rec['status']=='PASS'
 assert sha(e['source'])==rec['source_sha256']==e['source_sha256']
 assert rec['dependencies']=={d:done[d]['object_sha256']for d in e['imports']if d in done}
 for k in ['source_sha256','object_sha256','log_sha256','dependencies']:assert rec[k]==(old if m in extra else pd)[m][k]
 obj=cache/(m.replace('.','/')+'.olean');assert obj.is_symlink()and obj.resolve(strict=True)==(parent/'objects'/(m.replace('.','/')+'.olean')).resolve(strict=True)
 assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
for p,h in read(R/'before.json').items():assert sha(p)==h,p
a=r['audit'];assert a==read(R/'audit/record.json')and a['status']=='PASS'and a['exit_code']==0 and not a['timed_out']
assert a['source_sha256']==read(L/'result.json')['audit']['source_sha256']==sha(R/'audit/LegacyAudit.lean')
assert a['dependencies']=={m:rec['object_sha256']for m,rec in done.items()}
assert sha(a['log'])==a['log_sha256']and sha(R/'audit/LegacyAudit.olean')==a['object_sha256']
text=Path(a['log']).read_text();assert not any(s in text for s in ['warning:','error:','sorryAx',"declaration uses 'sorry'"])
reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
assert [n for n,_ in reports]==['SetTheory.BusyBeaver.ZFC.LegacyAudit.'+n for n in ['root222','root219','rootDom','rootPerm','offset_checker']]
assert [list(x)for x in reports]==a['reports']
assert all({x.strip()for x in ax.split(',')if x.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports)
reach=r['audit_transitive_project_providers'];assert len(reach)==46 and all(done[m]['object_sha256']==h for m,h in reach.items())
assert a['command'][1:3]==['-j1','-M12288']and a['timeout_seconds']==120 and a['memory_mebibytes']==12288
receipt={'status':'PASS_ROOT_LEGACY_POST_AUDIT_BINDINGS','project_modules':203,'primary_modules':188,'retained_legacy_modules':15,'fresh_legacy_modules':0,'fresh_typed_clients':1,'named_reports':5,'audit_warnings':0,'result_sha256':sha(R/'result.json'),'reviewer_sha256':sha(__file__),'scope':'Read-only current sources, exact direct dependencies, all203 provider objects/logs and origins, immutable predecessor inputs, fresh typed-client source/object/log and exact five named standard-axiom reports. No compiler execution by this checker.'}
out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
