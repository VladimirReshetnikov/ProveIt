from pathlib import Path
import re,json,hashlib,subprocess
p=Path(__file__).resolve().parent;cur=(p/'current/EnumPerm.lean').read_text();up=(p/'upstream/EnumPerm.lean').read_text()
def decl(s,name):
 m=re.search(r'(?m)^(?:theorem|def) '+re.escape(name)+r'(?!\w)',s);assert m,name
 n=re.search(r'(?m)^(?:/--|/-!|theorem|def|end )',s[m.end():]);end=m.end()+n.start() if n else len(s)
 return s[m.start():end].rstrip()+'\n\n'
def add_before(s,anchor,name):
 assert not re.search(r'(?m)^(?:theorem|def) '+re.escape(name)+r'(?!\w)',s)
 return s.replace(anchor,decl(cur,name)+anchor,1)
for anchor,name in [('def discard :','Contract.continue'),('theorem cexec_discard (','cexec_ax_pop')]:up=add_before(up,anchor,name)
for name in ['cexec_discard','bundle_contract','gen_contract','mp_contract']:up=up.replace(decl(up,name),decl(cur,name),1)
step='''/-- One decoded command either preserves the invariant or halts with derivable falsity. -/
theorem step_sound {s : St} (hs : Inv (toW s)) :
    match enumStep s with
    | some s' => Inv (toW s')
    | none => C222 F := by
  cases h : enumStep s with
  | none =>
      simp only [enumStep, execAt, Option.map_eq_none_iff] at h
      have hh := hs.2.1
      rw [cstep_none _ h] at hh
      exact hh
  | some s' =>
      simp only [enumStep, execAt, Option.map_eq_some_iff] at h
      obtain ⟨w, hw, rfl⟩ := h
      exact cstep_inv _ hs hw

'''
up=up.replace('theorem run_inv :',step+'theorem run_inv :',1)
a=up.index('theorem run_inv :');b=up.index('/-- Soundness:',a)
up=up[:a]+'''theorem run_inv : ∀ (n : Nat) {s s' : St}, Inv (toW s) → run n s = some s' → Inv (toW s')
  | 0, s, s', hs, h => by cases h; exact hs
  | n + 1, s, s', hs, h => by
      unfold run at h
      split at h
      · rename_i s1 h1
        exact run_inv n (by simpa only [h1] using step_sound hs) h
      · cases h

'''+up[b:]
a=up.index('theorem sound {');b=up.index('/-! ## Completeness',a)
up=up[:a]+'''theorem sound {s : St} (hs : Inv (toW s)) : HaltsFrom s → C222 F := by
  rintro ⟨n, s', hrun, hstep⟩
  simpa only [hstep] using step_sound (run_inv n hs hrun)

'''+up[b:]
work=p/'candidate'/'BusyBeaver/ZFC';work.mkdir(parents=True)
(work/'EnumPerm.lean').write_text(up)
for n in ['L2RootPerm','SeedPerm']:(work/(n+'.lean')).write_bytes((p/'upstream'/(n+'.lean')).read_bytes())
for n in ['L2AxiomsPerm','KEndpoint215']:(work/(n+'.lean')).write_bytes((Path.cwd()/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC'/(n+'.lean')).read_bytes())
for n in ['EnumPerm','L2RootPerm','SeedPerm']:
 r=subprocess.run(['diff','-u',str(p/'upstream'/(n+'.lean')),str(work/(n+'.lean'))],capture_output=True)
 (p/(n+'.integration.diff')).write_bytes(r.stdout)
print({x.name:len(x.read_text().splitlines()) for x in work.glob('*.lean')})
