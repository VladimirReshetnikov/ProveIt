# Shared Home shortcut: concrete integration candidate

The source draft adds one certified symbolic shortcut and reuses one executor soundness induction. It leaves the literal 215 machine, source program, primitive targets, register effects, source coverage relation and final endpoint statement unchanged. No compiler was invoked by this author; root owns the isolated checks and will decide adoption after site-batch timings.

## The retained proof structure

`KRuntimeCore.execWith` takes an abstract step function. `execWith_sound` is exactly the existing executor induction with its single step-soundness invocation replaced by a hypothesis. The original `exec` still uses `sstep M br`, and the original `exec_sound` is the corresponding corollary with its original public type. The separate `RuntimeAudit.lean` states equality to a literal copy of the old recursive definition. `KEngine224` and `KEngine225` still call these original interfaces.

`KHomeReady.ready M` checks the 15 scanner rows and a restoring 18-step window at the blank-left boundary. `ready_sound` proves `KHome.Rows M` and `KHome.Boundary M` for every transition function M. It assumes no particular machine identity. The boundary check is framed over the arbitrary right-hand list, then transported through `KZipTape`; it does not assert that every infinite tape is a finite zipper.

The new stepper selects `homeStep` when that table certificate passes and `sstep` otherwise. This selection is outside the executor recursion. `homeStep` uses the proved shortcut only when the current symbolic left word passes `KHome.home`; otherwise it falls back to `sstep`. Its soundness uses the all-natural `scanBound_sound` invariant, not a sampled gap or a source-path safety hypothesis.

`KSim` changes only one import, four executor references and two soundness references. Its `Covered`, `checkEdge` target formulas, register lemmas and complete simulation proof retain their original types and code. There is no second maintained simulation API. The six changed references deliberately accelerate the Boolean site checker; they do not assert Boolean acceptance equivalence to the old fixed-fuel checker. Successful accelerated checks still imply the same exact positive physical runs.

The table certificate is evaluated for a whole `runTo`/`runHalt`, not separately added to every recursive transition. The Home guard itself scans the current symbolic segment list, so finite dispatch-count savings do not establish identical kernel-time savings. The actual balanced-table/site-batch evaluation is the appropriate measurement.

## What Home proves and what remains

Home handles words ending in a literal marker, followed only by blank left padding. Its internal constant false runs may not reach eight zeros; an internal false run depending positively on the gap is rejected. An optional true run is treated conservatively as empty by the upper-bound calculation. Thus all natural gaps and every register list are covered. The right side is arbitrary and remains unchanged. Positivity comes from the concrete 18-step boundary even when the scanned prefix is empty.

This is the common return scanner, not a proof of every carry, strip, register update or return-port transformation. All 4,751 leaf occurrences and 6,176 branch outcomes remain in the existing site checks. Their exact primitive opcodes and arguments, both decrement branches, consumed paths, overflow/growth and final targets remain checked. In particular, a terminal role/read pair alone cannot identify a fixed return path.

The delivered `further-simplifications/runtime_contexts` evidence reports 15,673 Home applications replacing 1,532,123 old dispatches, reducing the complete owned abstract interpreter from 2,442,801 to 926,351 dispatches. These are delivered finite interpreter records, not a fresh execution here, a formal kernel-work ratio, or a timing result. Two conservative boundary-only misses remain on the original fallback. The older 27.5-minute site workload cited by root is a historical comparison, not a measurement of this candidate.

## Why the 234-role interface alone is insufficient

The framed decoder and the routed source-path proof reach the exact primitive-entry port without changing the tape. They do not describe the subsequent PC mutations. The same primitive may revisit dispatch several times during register selection. One actual Home input contains a run `true^(n+58)` before the marker; it is not merely the original source prefix. The shared guard proves such intermediate scans directly.

A later family of 135 universal terminal-role/outcome contracts could replace all 6,176 residual checks, but must quantify over every accepted prefix and preserve exact return operations. The current Home theorem can be a reusable sublemma in those proofs; it does not discharge them. The source-path and semantic-coverage drafts therefore remain separate research, while this integration has an immediate consumer in the existing site checker.

## Concrete next checks

1. Compile the three successor modules, the generic Home proof and the exact old-executor equality/API client. Compile the actual table certificate and old KEngine224/225 clients against the new core.
2. Compile unchanged small and large site batches (root selected 00 and04), with the balanced table still used by the existing fast-site adapter. Preserve actual timings and any failures; compare with the same prior batch/compiler rather than translating the delivered dispatch percentage into time.
3. If those gates are useful, compile all nine site batches, coverage, exact endpoint and its two unchanged typed clients. Recheck affected legacy endpoints separately. No proof or table should be weakened when a check fails.
