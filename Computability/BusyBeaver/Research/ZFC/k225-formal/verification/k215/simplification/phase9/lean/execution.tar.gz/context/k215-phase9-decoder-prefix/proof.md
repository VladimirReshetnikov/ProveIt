# Exact zipper entry for the shared K215 decoder

This is a new, uncompiled seventh-module draft. It does not edit the six decoder/bridge provider modules or any maintained source. No compiler, supplied script, or machine has been invoked for this packet.

`KDecoderPrefix215.leaf_prefix` and `walk_prefix` strengthen the existing full-tape decoder result to a fixed symbolic zipper port. They retain the entire consumed word `word = pre ++ [bit]`, its exact `RoutedEntry`, and its source operation/argument. The existential `pre`, `bit`, formal state `q`, operation and argument precede the universal gap `n` and register list `vs`. Only the clock is chosen afterward, with bounds `pre.length ≤ steps ≤ 7 * pre.length`.

The port is exactly the semantic-coverage draft's `leafPort`: the left half is the reverse of the complete prefix followed by the dispatcher marker; the right half is the final source bit, the original saturating-subtraction gap, header and untouched plain register box. The formal-table certificate has already applied the total state permutation; `q` must not be renamed a second time.

The proof separates four facts:

1. `rel_cons_right` and `rel_word` move the cut of a related integer tape without changing any tape cell. They normalize only the finite zipper halves. They do not assert that an arbitrary infinite tape has a finite zipper representation.
2. `reads_of_rel` and the left-marker observation establish the exact prefix hypotheses for `upstream_leaf_reaches_routed` or `upstream_walk_reaches_routed` on the tape represented by the actual symbolic start. This works for every gap size and every register list; no box validity or length premise is required for decoder traversal.
3. `entry_run` applies the existing whole-tape theorem and `KZipTape.run_reflect`. Rewriting the exact last-bit split identifies the returned zipper with `conc n vs (leafPort pre bit q)`. Both halves are normalized, as required by `run_reflect`.
4. `rolePath_unique` and `routed_control_unique` show that two valid routed entries for the same complete word have identical final bit and control state, even if distinct roles share physical states. `entry_uniform` first selects an entry with arbitrary values `n = 0`, `vs = []`, then transports every other tape's run to that same port. This uses only existential elimination, not choice or a new semantic axiom.

`FullEntry` is a transparent interface for the already established full-tape theorem. Both public source-specific wrappers discharge it from the exact source/role binding. It is not an unproved premise at those wrappers. `walk_prefix` retains the full `consume P d` with implicit zero padding; it does not use the unconsumed input suffix.

The endpoint is before the final primitive transition, so decoder duration may be zero in the generic interface. The residual primitive execution must supply positive progress, branch validity, overflow/spare behavior and the exact original `tgtConf`/halt. None of those 6,176 primitive-outcome obligations is discharged here. No existing 4,751-leaf coverage theorem is removed, and no full-closure size or kernel-time saving is claimed.

The temporary import of maintained `KDenseBridge` is used only for its proved public `getD_trim`; no dense-machine theorem or table is imported as a premise. A later library cleanup could expose that generic zipper fact directly from `KZip` without changing this argument.

The draft has complete proof terms and no admissions, but elaboration has not been tested. In particular, the constructor inversion in `rolePath_unique` and normalizing simplifications are source-reviewed mathematical arguments, not yet kernel results.
