"""No-compiler mutation tests for the phase7 source/report/provider gates."""
from pathlib import Path
import copy, hashlib, importlib.util, json, tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('phase7_gates_control', HERE/'gates.py')
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
rows=[]
def test(name, fn, rejects=False):
    try:
        fn()
    except (AssertionError, FileNotFoundError):
        assert rejects, name
    else:
        assert not rejects, name
    rows.append({'name':name,'expected':'reject' if rejects else 'accept','status':'PASS'})
old=json.loads(Path('/tmp/k215-proof-phase6/lean-run1/inventory.json').read_text())
new=copy.deepcopy(old)
next(e for e in new['modules'] if e['module']==g.DOM)['source_sha256']='candidate-not-a-proof-run'
test('only_Dom_change_and_exact_seven_dependency_closure',lambda:g.checkpoint(old,new))
def changed(mut):
    value=copy.deepcopy(new); mut(value);g.checkpoint(old,value)
test('reject_unchanged_checkpoint',lambda:g.checkpoint(old,old),True)
test('reject_second_source_change',lambda:changed(lambda v:v['modules'][0].update(source_sha256='changed')),True)
test('reject_added_import',lambda:changed(lambda v:v['modules'][-1]['imports'].append('Init.Nat')),True)
test('reject_module_removal',lambda:changed(lambda v:v['modules'].pop()),True)
test('reject_duplicate_module',lambda:changed(lambda v:v['modules'].append(v['modules'][0])),True)
test('reject_source_path_change',lambda:changed(lambda v:v['modules'][0].update(source='/different')),True)
test('reject_external_change',lambda:changed(lambda v:v['external_imports'].append('Init.Nat')),True)
test('reject_target_change',lambda:changed(lambda v:v.update(target='Wrong.Target')),True)
test('reject_order_change',lambda:changed(lambda v:v['modules'].reverse()),True)
logs={n:Path('/tmp/k215-proof-phase6/lean-run1/audit-001',n+'.log').read_text() for n in g.AUDIT_NAMES}
for n,t in logs.items():test('exact_historical_names_'+n,lambda n=n,t=t:g.audit_reports(n,t))
n='EndpointAudit215';t=logs[n]
test('reject_renamed_report',lambda:g.audit_reports(n,t.replace(g.AUDIT_NAMES[n][0],'Unrelated.good')),True)
test('reject_extra_axiom',lambda:g.audit_reports(n,t.replace('propext','extraAx')),True)
test('reject_warning',lambda:g.audit_reports(n,t+'\nwarning: control\n'),True)
test('reject_extra_named_report',lambda:g.audit_reports(n,t+t),True)
with tempfile.TemporaryDirectory(prefix='phase7-safe-provider-',dir=HERE) as tmp:
    d=Path(tmp);basis=d/'basis';basis.mkdir();oldobj=basis/'old.olean';oldobj.write_bytes(b'old immutable provider')
    alternate=basis/'same-bytes.olean';alternate.write_bytes(oldobj.read_bytes())
    cache=d/'private';cache.mkdir();obj=cache/'Module.olean';obj.symlink_to(oldobj)
    def safe_replacement():
        g.private_parents(obj,cache);g.provider(obj,oldobj,'phase6_hash_bound')
        obj.unlink(missing_ok=True);obj.write_bytes(b'fresh private provider')
        g.provider(obj,oldobj,'phase7_fresh');assert oldobj.read_bytes()==b'old immutable provider'
    test('unlink_before_private_replacement_preserves_basis',safe_replacement)
    obj.unlink();obj.symlink_to(alternate)
    test('reject_equal_bytes_wrong_provider_path',lambda:g.provider(obj,oldobj,'phase6_hash_bound'),True)
    alias=cache/'alias';alias.symlink_to(basis,target_is_directory=True)
    test('reject_parent_directory_alias',lambda:g.private_parents(alias/'old.olean',cache),True)
result={'status':'PASS_METADATA_CONTROLS_NO_COMPILER','driver_sha256':hashlib.sha256((HERE/'build.py').read_bytes()).hexdigest(),'gates_sha256':hashlib.sha256((HERE/'gates.py').read_bytes()).hexdigest(),'controls_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'positive':sum(r['expected']=='accept'for r in rows),'negative':sum(r['expected']=='reject'for r in rows),'cases':rows,'scope':'Source/import closure, literal report names/axioms, exact immutable-provider path and safe target unlink. No driver, compiler, proof evaluation, machine execution, canonical mutation or basis write.'}
(HERE/'controls-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='cases'},indent=2))
