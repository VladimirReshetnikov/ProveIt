"""Read-only post-audit current-source/object review; never runs Lean."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
assert not a.output.exists();run=a.run.resolve()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda name:json.loads((run/name).read_text())
result=read('result.json');assert result['status']=='PASS'
owner=read('owner.json');repo=Path(owner['repo'])
inv=read('inventory.json');done=read('completed.json');basis=read('basis-objects.json')
assert sha(run/'inventory.json')==result['inventory_sha256']
assert sha(run/'completed.json')==result['completed_sha256']
assert sha(run/'reviewed-driver.py')==owner['helper_sha256']
spec=importlib.util.spec_from_file_location('frozen_inventory_helper',run/'reviewed-driver.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
assert helper.inventory(repo)==inv
assert len(done)==len(inv['modules'])==185 and inv['external_imports']==['Init']
assert set(done)=={e['module'] for e in inv['modules']}
cache=run/'objects';assert {str(p.relative_to(cache)) for p in cache.rglob('*') if p.is_file()}=={m.replace('.','/')+'.olean' for m in done}
phase1=repo/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/lean/result.json'
assert sha(phase1)==owner['phase1_result_sha256']
old={r['module']:r for r in json.loads(phase1.read_text())['module_evidence']}
prior_records=read('phase1-completed.json')
warnings=0
for e in inv['modules']:
 m=e['module'];r=done[m]
 assert r['status']=='PASS' and sha(e['source'])==r['source_sha256']==e['source_sha256']
 assert sha(cache/(m.replace('.','/')+'.olean'))==r['object_sha256']
 assert r['dependencies']=={d:done[d]['object_sha256'] for d in e['imports'] if d in done}
 if r['origin']=='phase2_fresh':
  log=Path(r['log']);snapshot=log.parent/Path(e['source']).name
  assert sha(log)==r['log_sha256'] and sha(snapshot)==r['source_sha256']
  assert r['exit_code']==0 and not r['timed_out'] and r['source_unchanged'] and r['dependencies_unchanged']
  root=str(e['source'])[:-len(m.replace('.','/')+'.lean')].rstrip('/')
  assert r['command']==[r['command'][0],'-j1','-M12288','--root='+root,'-o',str(cache/(m.replace('.','/')+'.olean')),e['source']]
  assert sha(r['command'][0])==r['compiler_sha256']==owner['compiler_sha256']
  assert r['timeout_seconds']==900 and r['memory_mebibytes']==12288
  text=log.read_text();assert 'sorryAx' not in text and "declaration uses 'sorry'" not in text
  warnings+=text.count('warning:')
 else:
  assert r['origin']=='phase1_hash_bound'
  for key in ['source_sha256','object_sha256','dependencies','log_sha256']:
   assert r[key]==old[m][key],(m,key)
  prior=prior_records[m]
  log=Path(prior['log']) if 'log' in prior else Path('/tmp/k215-proof-simplification/root')/old[m]['compilation_origin'].split('execution.tar.gz/',1)[1]/'compiler.log'
  assert sha(log)==r['log_sha256']
  text=log.read_text();assert 'sorryAx' not in text and 'error:' not in text
  assert text.count('warning:')==old[m]['warnings']
  warnings+=text.count('warning:')
reports=0
for r in result['audits']:
 log=Path(r['log']);source=log.parent/(r['module']+'.lean')
 assert r['status']=='PASS' and r['exit_code']==0 and not r['timed_out']
 assert sha(log)==r['log_sha256'] and sha(source)==r['source_sha256']
 assert r['dependencies']=={m:done[m]['object_sha256'] for m in done}
 assert r['command']==[read('toolchain.json')['lean']['path'],'-j1','-M12288','--root='+str(log.parent),'-o',str(source.with_suffix('.olean')),str(source)]
 assert r['compiler_sha256']==owner['compiler_sha256'] and r['timeout_seconds']==120
 assert sha(source.with_suffix('.olean'))==r['object_sha256']
 text=log.read_text();assert 'warning:' not in text and 'error:' not in text
 found=re.findall(r'depends on axioms: \[([^]]*)\]',text)
 assert len(found)+text.count('does not depend on any axioms')==r['expected_reports']
 assert all(set(v.strip() for v in row.split(','))<={'propext','Classical.choice','Quot.sound'} for row in found)
 reports+=r['expected_reports']
assert reports==10 and len(result['audits'])==2
for m,h in basis.items():assert sha(Path('/tmp/k215-proof-simplification/root/objects')/(m.replace('.','/')+'.olean'))==h
assert sha('/tmp/k215-proof-simplification/root/completed.json')==owner['phase1_completed_sha256']
toolchain=read('toolchain.json')
assert sha(run/'toolchain.json')==owner['toolchain_boundary_sha256']
for key in ['lean','lake','Init.olean','project_toolchain']:
 assert sha(toolchain[key]['path'])==toolchain[key]['sha256']
# This second pass is deliberately after the two typed audit log/object checks.
assert all(sha(cache/(m.replace('.','/')+'.olean'))==r['object_sha256'] for m,r in done.items())
review={'status':'PASS_LIVE_POST_AUDIT_REVIEW','project_modules':185,
 'fresh_modules':sum(r['origin']=='phase2_fresh' for r in done.values()),
 'reused_modules':sum(r['origin']=='phase1_hash_bound' for r in done.values()),
 'typed_clients':2,'axiom_reports':10,'audit_warnings':0,'project_warnings':warnings,
 'all185_objects_rehashed_after_audits':True,'all215_phase1_objects_unchanged':True,
 'current_inventory_exact':True,'result_sha256':sha(run/'result.json'),
 'reviewer_sha256':sha(__file__),
 'scope':'Read-only current sources, exact project provider set, saved logs and live private objects; no compiler rerun. Later source-only changes require a separate addendum.'}
a.output.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review,indent=2))
