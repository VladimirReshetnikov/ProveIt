"""Prepare a narrow phase14 runner adaptation; metadata only, no Lean execution."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent;F=R/'Computability/BusyBeaver/Research/ZFC/k225-formal';L=R/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC'
B=Path('/tmp/k215-phase13-upstream-check/primary-run1');BC=B.parent/'compatibility-run1';OLD=B.parent/'build.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def snap(path):
 out=S/'inputs/current-before'/path.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,out);return str(out)
assert sha(OLD)=='b92ef55882a1869a40b57f3e746ba40b11a4c79dc2d8f0f5273704d373aff624'
priorpath=B.parent/'producer-boundary.json';prior=read(priorpath);assert sha(priorpath)=='b5ad74566d101c75d180195b3a1cb75c703e26d1d7421c207ef389396db2d3c9'
phase13=F/'verification/k215/simplification/phase13';adoptionpath=phase13/'integration/adoption.json';adoption=read(adoptionpath)
assert adoption['status']=='EXACT_CHECKED_PHASE13_ADOPTION'
expected={'DominatedImplication.lean':'bd07364a829e8a1535b0ecf1ee6ed0c292d5af35e01a6db8f152dd2610e247d8','Lukasiewicz.lean':'7d443a733b5c5ddd0d49728cf1ea7d855dd445f156934c13578bacc008c59874','generate_dominated_implication_lean.py':'ebcbb86642d4d389748451dc662b42f7ac62e7aa4b235bbf4e5d8e5a1ec5c1e9','derivation_core.txt':'4141248ed90a6813c07f274351336963acde1d82f6ea463a33e5f7d64bed8005','generate_domrho8_cd.py':'63da860d3a957010c53d783a2b8995acef3d8e3806823f24fc5833738dc1d56a'}
current={}
for row in adoption['files']:
 path=R/row['target'];assert sha(path)==row['sha256']==expected[path.name];current[str(path)]=row['sha256']
for name,pin in [('generate_l2k222.py','c720d5bf58d4c9119bfb6a6d206451e18c7287caf0518c8a666b38cc0b2e74f6'),('generate_domrho8_lean.py','f3fbc696ad34f507fd29d89322f7649fb8c4ad338a1bb6fe6bdd21537e54f5e2'),('dominated_implication_templates/adapter.txt','8fdbec0db9134070bee2dfa0a433aff66ab83c00007ea7b9aabd9192c506d378'),('verification/k215/simplification/phase12/upstream-merge/inputs/raw58-DominatedImplication.lean','4aefdfbdfc41c11f2dc0b236c526098bf76c55692767f554e3776b1573135005')]:
 assert sha(F/name)==pin;current[str(F/name)]=pin
rows=[]
for row in prior['files']:
 row=dict(row);path=Path(row['canonical'])
 if row['current_state']=='present':row.update(current_sha256=sha(path),current_snapshot=snap(path))
 else:assert not path.exists()and not path.is_symlink()
 rows.append(row)
retire=[]
for path,pin,module in [(L/'KProfileTC.lean','0d344c2298abf0e6d998179b61baeab9b0226cc49c365552ef94de258417c173','BusyBeaver.ZFC.KProfileTC'),(F/'generate_profile_tc.py','bf307e9a953a24f7303786e30f23c53f34b81519e794748d118e4403692b9822',None)]:
 assert sha(path)==pin;retire.append({'canonical':str(path),'before_sha256':pin,'before_snapshot':snap(path),'module':module,'current_state':'present_before_candidate_check','proposed_state':'absent_only_after_accepted_adoption'})
published={n:sha(phase13/'lean'/n)for n in ['execution.tar.gz','index.json','result.json']}
assert published['execution.tar.gz']=='ff1d474b87f46f0e440867c8b9f51744c129df914b566ba34c75989bf5f36717'
extras={**current,str(priorpath):sha(priorpath),str(adoptionpath):sha(adoptionpath),str(phase13/'lean/result.json'):sha(phase13/'lean/result.json'),str(phase13/'lean/index.json'):sha(phase13/'lean/index.json')}
for name in ['sources.json','clients.json','proposal-inputs.json']:
 extras[str(S/name)]=sha(S/name)
for path,pin in read(S/'proposal-inputs.json').items():
 assert sha(path)==pin;extras[path]=pin
boundary={**prior,'files':rows,'additional_inputs':extras,'phase13_primary_result_sha256':sha(B/'result.json'),'phase13_compatibility_result_sha256':sha(BC/'result.json'),'phase13_adoption':{'path':str(adoptionpath),'sha256':sha(adoptionpath)},'phase13_boundary':{'path':str(priorpath),'sha256':sha(priorpath)},'accepted_five_files':{str(R/r['target']):r['sha256']for r in adoption['files']},'published_basis':{'directory':str(phase13/'lean'),'files':published},'proposed_retirements':retire,'scope':'Current phase13 five adoptions and three maintained producers remain exact. Existing two template absences stay distinct from two proposed retirements: the old profile module/generator must still be present during candidate checks, absent from the selected graph/private cache, and removed only after separate accepted adoption.'}
# Superseded descriptive fields stay solely in the immutable prior boundary.
for key in ['current_before_snapshots','proposed_producer_inputs']:boundary.pop(key,None)
save(S/'producer-boundary.json',boundary)
s=OLD.read_text().replace("B=Path('/tmp/k215-phase12-import-check/primary-run1');BC=Path('/tmp/k215-phase12-import-check/compatibility-run1')","B=Path('/tmp/k215-phase13-upstream-check/primary-run1');BC=Path('/tmp/k215-phase13-upstream-check/compatibility-run1')")
s=s.replace('a5fce6a787751ba527cc368ff97b770d28eeb517149d5e3f99b17dd7c738df5e','00a44b3ce690bfcd397f53275c2dcec69d25423de8e029086b0aefe020fb397e').replace('7223a5fa4f5fe56e331d2dc27efc7b2d8e50f473d081eed9e145278728e68f9c','bd9e50bce1c8a463719d83c201f402dad3edd89c0621ae827082b75638a3c74f')
s=s.replace('phase12_primary_checked','phase13_primary_checked').replace('phase12_compatibility_checked','phase13_compatibility_checked').replace('phase12_primary_reused_modules','phase13_primary_reused_modules').replace('phase12_compatibility_reused_modules','phase13_compatibility_reused_modules')
s=s.replace("[(BC,'phase13_compatibility_checked',69),(B,'phase13_primary_checked',184)]","[(BC,'phase13_compatibility_checked',70),(B,'phase13_primary_checked',187)]").replace('assert len(old)==201','assert len(old)==204')
s=s.replace("'b5ad74566d101c75d180195b3a1cb75c703e26d1d7421c207ef389396db2d3c9'",repr(sha(S/'producer-boundary.json')))
s=s.replace("producer_boundary['phase12_primary_result_sha256']==sha(B/'result.json') and producer_boundary['phase12_compatibility_result_sha256']==sha(BC/'result.json')","producer_boundary['phase13_primary_result_sha256']==sha(B/'result.json') and producer_boundary['phase13_compatibility_result_sha256']==sha(BC/'result.json')")
s=s.replace("assert producer_boundary['phase11_result_sha256']==baseline['basis_result_sha256']==compatibility_baseline['basis_result_sha256']","assert producer_boundary['phase12_primary_result_sha256']==baseline['basis_result_sha256']==compatibility_baseline['basis_result_sha256']\nassert producer_boundary['phase12_compatibility_result_sha256']==baseline['compatibility_basis_result_sha256']==compatibility_baseline['compatibility_basis_result_sha256']")
s=s.replace("['phase11_adoption','previous_boundary','phase12_adoption','phase12_boundary']","['phase11_adoption','previous_boundary','phase12_adoption','phase12_boundary','phase13_adoption','phase13_boundary']")
s=s.replace("assert len(absent_inputs)==2", """assert len(absent_inputs)==2
retirements=producer_boundary['proposed_retirements'];assert len(retirements)==2
retired_modules={r['module']for r in retirements if r['module']is not None};assert retired_modules=={'BusyBeaver.ZFC.KProfileTC'}
for r in retirements:
 assert r['current_state']=='present_before_candidate_check'and r['proposed_state']=='absent_only_after_accepted_adoption'
 for key in ['canonical','before_snapshot']:assert sha(r[key])==r['before_sha256'];inputs[r[key]]=r['before_sha256']
assert {Path(r['canonical']).name for r in retirements}=={'KProfileTC.lean','generate_profile_tc.py'}""")
s=s.replace("def visit(m):\n if m in seen:return", "def visit(m):\n assert m not in retired_modules,('Retired dependency selected',m)\n if m in seen:return")
s=s.replace("for row in plans:\n assert sha(row['source'])", "assert len(producer_boundary['accepted_five_files'])==5\nassert all(producer_boundary['additional_inputs'].get(p)==h for p,h in producer_boundary['accepted_five_files'].items())\nfor row in plans:\n assert sha(row['source'])")
s=s.replace("changed={m for m,r in entry_by_name.items()if m not in old or r['source_sha256']!=old[m]['source_sha256']}","changed={m for m,r in entry_by_name.items()if m not in old or(r['source_sha256'],r['imports'])!=(old_entries[m]['source_sha256'],old_entries[m]['imports'])}")
s=s.replace("def postcheck():\n for p in absent_inputs:","def postcheck():\n for m in retired_modules:\n  p=cache/(m.replace('.','/')+'.olean');assert not p.exists()and not p.is_symlink()and m not in entry_by_name\n for p in absent_inputs:")
s=s.replace("'inputs_sources_objects_dependencies_logs_toolchain_rechecked':True", "'inputs_sources_objects_dependencies_logs_toolchain_rechecked':True,'proposed_retirements':retirements,'retired_modules_absent_from_candidate':sorted(retired_modules)")
s=s.replace("assert baseline['status']==compatibility_baseline['status']=='PASS'", """assert baseline['status']==compatibility_baseline['status']=='PASS'
def exact_endpoint_profile(name,reports):
 normalize=lambda rs:[(n,{a.strip()for a in ax.split(',')if a.strip()})for n,ax in rs]
 expected={r['module']:r['named_reports']for r in baseline['audits']}
 return name in expected and normalize(reports)==normalize(expected[name])""")
s=s.replace("save(record,rec);audits.append(rec)", "assert exact_endpoint_profile(name,rec['named_reports']);save(record,rec);audits.append(rec)")
s=s.replace("for rec in audits:\n assert sha(rec['log'])", "for rec in audits:\n assert exact_endpoint_profile(rec['module'],rec['named_reports'])\n assert sha(rec['log'])")
ast.parse(s);(S/'build.py').write_text(s)
(S/'driver.diff').write_text(''.join(difflib.unified_diff(OLD.read_text().splitlines(True),s.splitlines(True),fromfile='phase13/build.py',tofile='phase14/build.py')))
print(json.dumps({'status':'DRAFT_SOURCE_ONLY','driver_sha256':sha(S/'build.py'),'boundary_sha256':sha(S/'producer-boundary.json'),'compiler_or_producer_invoked':False},indent=2))
