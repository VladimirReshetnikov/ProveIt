"""Read-only preparation: predecessor provider hashes and prospective source/import union.
No compiler or current-source adoption. Final execution gate remains absent until primary PASS.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
from gates import *
HERE=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
F=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal'
P=Path('/tmp/k215-proof-phase7/lean-run1');L=Path('/tmp/k215-phase7-legacy/run1');N=Path('/tmp/k215-proof-phase8')
old=read(P/'inventory.json');legacy=read(L/'inventory.json');future=read(N/'prospective-inventory.json')
registration=read(N/'registered-adoption.json')
approved={r['module']:{'source':str(REPO/r['destination']),'source_sha256':r['sha256'],'imports':r['imports']}for r in registration['files']if r['kind']=='lean'}
u=checkpoint(old,future,legacy,approved)
ld=read(L/'completed.json');lr=read(L/'result.json');pr=read(P/'result.json');pd=read(P/'completed.json')
assert lr['status']=='PASS'and lr['primary_result_sha256']==sha(P/'result.json')and lr['project_modules']==202
assert lr['inventory_sha256']==sha(L/'inventory.json')and lr['completed_sha256']==sha(L/'completed.json')
assert pr['status']=='PASS'and pr['primary_project_modules']==187 and set(pd)==set(graph(old))
assert {r['module']for r in legacy['modules']}==set(ld) and set(graph(legacy))-set(graph(old))==EXTRA
assert [r for r in legacy['modules']if r['module']not in EXTRA]==old['modules']
for m in pd:assert all(ld[m][k]==pd[m][k]for k in ['source_sha256','object_sha256','log_sha256','dependencies']),m
inputs={str(p):sha(p)for p in [F/'verification/k215/lean/build.py',*[P/n for n in ('inventory.json','completed.json','result.json','toolchain.json')],*[L/n for n in ('inventory.json','completed.json','result.json','toolchain.json')],N/'prospective-inventory.json',N/'registered-adoption.json']}
for r in legacy['modules']:
 m=r['module'];obj=L/'objects'/(m.replace('.','/')+'.olean')
 valid_record(r,ld[m],ld,obj,source_current=m not in CHANGED)
 inputs[str(obj)]=sha(obj);inputs[ld[m]['log']]=sha(ld[m]['log'])
audit=lr['audit'];assert sha(HERE/'LegacyAudit.lean')==audit['source_sha256']
assert sha(L/'audit/LegacyAudit.olean')==audit['object_sha256']and sha(L/'audit/compiler.log')==audit['log_sha256']
audit_reports((L/'audit/compiler.log').read_text())
inputs.update({str(L/'audit'/n):sha(L/'audit'/n)for n in ['LegacyAudit.lean','LegacyAudit.olean','compiler.log','record.json']})
references={}
for sub,names in [('phase7/legacy',['result.json','live-review.json','execution.tar.gz','index.json','saved-review.json']),('phase7/lean',['result.json'])]:
 for name in names:
  p=F/'verification/k215/simplification'/sub/name
  if not p.exists():
   assert sub=='phase7/lean',p
   continue
  references[p.relative_to(REPO).as_posix()]=sha(p)
public=read(F/'verification/k215/simplification/phase7/legacy/result.json');assert all(public[k]==v for k,v in lr.items())
assert public['execution_archive_sha256']==sha(F/'verification/k215/simplification/phase7/legacy/execution.tar.gz')
packet_pins(REPO,references)
rows=graph(u);reach=set()
def visit(m):
 if m=='Init'or m in reach:return
 reach.add(m)
 for d in rows[m]['imports']:visit(d)
for line in (HERE/'LegacyAudit.lean').read_text().splitlines():
 if line.startswith('import '):
  for m in line[7:].split():visit(m)
assert len(reach)==46 and NEW in reach
for path,h in inputs.items():assert sha(path)==h
save(HERE/'prepared-inventory.json',{'primary':future,'union':u})
save(HERE/'basis-reference.json',references)
save(HERE/'preparation.json',{'status':'PREPARED_PENDING_PRIMARY_PASS_NO_COMPILER','primary_modules':188,'legacy_modules':15,'union_modules':203,'approved_sources':approved,'potential_primary_refresh':sorted(PRIMARY_AFFECTED),'potentially_affected_legacy_modules':sorted(LEGACY_AFFECTED),'audit_transitive_project_modules':sorted(reach),'audit_sha256':sha(HERE/'LegacyAudit.lean'),'metadata_and_provider_inputs':inputs,'previous_legacy_files':{n:sha(L/n)for n in ['inventory.json','completed.json','result.json','toolchain.json']},'primary_gate':None,'registered_files':{str(REPO/r['destination']):r['sha256']for r in registration['files']},'all202_predecessor_objects_and_logs_rehashed':True,'canonical_writes':[],'compiler_invocations':[]})
print('PREPARED 188+15=203;46 audit dependencies;3 possible legacy refreshes;primary gate CLOSED')
