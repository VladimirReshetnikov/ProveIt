"""Own inert source adaptation/metadata census; never imports delivery code or invokes Lean."""
from pathlib import Path
import subprocess,json,hashlib,re,difflib
ROOT=Path('/home/codex/.codex/worktrees/ec20/Proofs')
OUT=Path(__file__).resolve().parent
UP='639e34777e269af05ce380733a7f43b5fec9902b'
MODS=['KSeed222','KSeedModel222']
PREF='Computability/BusyBeaver/Lean/BusyBeaver/ZFC/'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def stripped(s):
 out=[];i=0;depth=0;string=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;i+=2
   elif s.startswith('-/',i):depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif string:
   if s[i]=='\\':out.extend('  ');i+=2
   elif s[i]=='"':string=False;out.append(' ');i+=1
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif s.startswith('/-',i):depth=1;out.extend('  ');i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);j=len(s)if j<0 else j;out.extend(' '*(j-i));i=j
  elif s[i]=='"':string=True;out.append(' ');i+=1
  else:out.append(s[i]);i+=1
 assert depth==0 and not string
 return ''.join(out)
def declarations(s):
 s=stripped(s);ms=list(re.finditer(r'^(def|theorem) (\w+)\b',s,re.M));out={}
 for k,m in enumerate(ms):
  end=ms[k+1].start()if k+1<len(ms)else len(s)
  text=s[m.start():end];head=text[:text.find(':=')]if ':='in text else text
  # Bottom-up statement spans are only a text census; section parameters checked separately.
  out[m[2]]={'kind':m[1],'header':' '.join(head.split()),'text':text}
 return out
snap={};stats={};candidates={}
for n in MODS:
 rel=PREF+n+'.lean';before=(ROOT/rel).read_bytes();up=git('show',UP+':'+rel)
 save(OUT/'baseline'/f'{n}.lean',before);save(OUT/'upstream'/f'{n}.lean',up)
 s=up.decode()
 if n=='KSeedModel222':
  start=s.index('theorem update_idem ');end=s.index('section Conv',start);s=s[:start]+s[end:]
  start=s.index('/-- The request `req b c c`');end=s.index('/-- **The bundle gives',start);s=s[:start]+s[end:]
  s=s.replace('theorem th_eqFree :','/-- Equality interpretation fixes equality-free named formulas. --/\ntheorem th_eqFree :')
  # Correct the ordinary Lean doc-comment delimiter before writing source.
  s=s.replace('formulas. --/','formulas. -/')
  s=s.replace('The semantic round trip replaces three syntactic formula inductions (proposals affine-cores and\nstructural);', 'The semantic round trip retains the phase-six adaptation of the affine-cores packet\n(aa66d0a33f), extending the structural proposal;')
 b=s.encode();save(OUT/'candidate'/f'{n}.lean',b);candidates[n]=s
 stats[n]={label:{'sha256':sha(data),'bytes':len(data),'lines':len(data.splitlines())}for label,data in [('baseline',before),('upstream639e',up),('candidate',b)]}
 for label,old in [('baseline',before),('upstream',up)]:
  diff=''.join(difflib.unified_diff(old.decode().splitlines(True),s.splitlines(True),fromfile=label+'/'+n+'.lean',tofile='candidate/'+n+'.lean'))
  save(OUT/(n+'.'+label+'.diff'),diff.encode())
 bd,cd=declarations(before.decode()),declarations(s)
 unchanged_defs={name:bd[name]['text'].split(':=',1)[1].split('theorem ')[0].strip()==cd[name]['text'].split(':=',1)[1].split('theorem ')[0].strip()for name in bd if bd[name]['kind']=='def'}
 # Compare declaration bodies with boundaries truncated at all top-level commands, not only def/theorem.
 for name in unchanged_defs:
  def body(t):return re.split(r'^(?:end|section|namespace|#print|omit|include|variable)\b',t,flags=re.M)[0].strip()
  unchanged_defs[name]=body(bd[name]['text'])==body(cd[name]['text'])
 assert all(unchanged_defs.values()),unchanged_defs
 stats[n]['definitions_byte_equal_after_comment_removal']=unchanged_defs
 stats[n]['removed_declarations']=sorted(set(bd)-set(cd))
 stats[n]['retained_header_equal']={name:bd[name]['header']==cd[name]['header']for name in set(bd)&set(cd)}
 stats[n]['imports_before']=re.findall(r'^import (.+)$',before.decode(),re.M)
 stats[n]['imports_after']=re.findall(r'^import (.+)$',s,re.M)
 assert stats[n]['imports_before']==stats[n]['imports_after']
 assert not re.search(r'\b(?:sorry|admit|axiom|native_decide|unsafe|implemented_by)\b',stripped(s))
# Census every tracked maintained Lean source. Research/proposal/document payloads are historical copies,
# explicitly separate from current modules and retained in the list of excluded paths.
files=[p.decode()for p in git('ls-files','-z','*.lean').split(b'\0')if p]
selected=[p for p in files if not any(x in Path(p).parts for x in ['Research','docs','.lake'])]
names=['update_idem','update_self','sat_req','matrix_iff']
hits={n:[]for n in names}
for rel in selected:
 s=stripped((ROOT/rel).read_text())
 for n in names:
  for m in re.finditer(r'(?<![\w])'+n+r'(?![\w])',s):
   hits[n].append({'path':rel,'line':s[:m.start()].count('\n')+1})
external={n:[r for r in rows if r['path']not in[PREF+x+'.lean'for x in MODS]]for n,rows in hits.items()}
assert all(not rows for rows in external.values()),external
inv=json.loads(Path('/tmp/k215-proof-phase7/lean-run1/inventory.json').read_text())
mods=inv['modules'];changed={'BusyBeaver.ZFC.'+n for n in MODS};affected=set(changed)
for m in mods:
 if set(m['imports'])&affected:affected.add(m['module'])
result={'status':'SOURCE_ONLY_CANDIDATE_READY_NOT_COMPILED','baseline_HEAD':git('rev-parse','HEAD').decode().strip(),'upstream_commit':UP,'files':stats,'total':{lab:{'bytes':sum(stats[n][lab]['bytes']for n in MODS),'lines':sum(stats[n][lab]['lines']for n in MODS)}for lab in ['baseline','upstream639e','candidate']},'required_endpoints':['bundle_of_seed','seed_of_bundle','seed_eqFree','derivable_named_bundle'],'section_expansion_note':'bundle_of_seed has the same explicit mem/hirr arguments formerly introduced by section Bundle; seed_of_bundle remains in the identical Conv section. Universe/V context unchanged.','maintained_source_census':{'files':len(selected),'excluded_historical_paths':len(files)-len(selected),'removed_name_occurrences':hits,'outside_pair_occurrences':external},'primary_baseline_modules':len(mods),'added_imports_or_modules':[],'potential_affected_modules':[m['module']for m in mods if m['module']in affected],'no_compiler_or_supplied_execution':True,'canonical_mutations':[]}
save(OUT/'comparison.json',(json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'status':result['status'],'total':result['total'],'census_files':len(selected),'potential_affected':len(affected),'hashes':{n:stats[n]['candidate']['sha256']for n in MODS}},indent=2))
