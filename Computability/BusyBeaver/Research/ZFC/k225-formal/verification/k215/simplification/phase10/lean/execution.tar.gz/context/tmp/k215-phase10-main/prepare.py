from pathlib import Path
import hashlib,json,sys
R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
P=Path('/tmp/k215-phase10-main');B=Path('/tmp/k215-phase9-main/full-run2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=Path(sys.argv[1]);expected=sys.argv[2]
assert sha(source)==expected
m=json.loads(Path('/tmp/k215-phase9-main/full-v1.json').read_text())
m['modules'].append({'module':'BusyBeaver.ZFC.DominatedImplication','source':str(source),'source_sha256':expected,'imports':['Init'],'before_sha256':'ce0bdaf4a1e23ccdb709d198ef80cf18401677ede3afd99f7797fe5ebe372354','reports':['SetTheory.BusyBeaver.ZFC.DominatedImplication.rho8_all','SetTheory.BusyBeaver.ZFC.DominatedImplication.composition','SetTheory.BusyBeaver.ZFC.DominatedImplication.lift_right']})
m['reuse_ledger']={'directory':str(B),**{n:sha(B/n)for n in ['result.json','inventory.json','completed.json']}}
assert m['reuse_ledger']['result.json']=='e54f4f69ec6721a26a0eba53b801f198ee70227a231d38b3c66782b5ed2a8818'
(P/'full-v1.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'map_sha256':sha(P/'full-v1.json'),'candidate_sha256':expected,'runner_sha256':sha('/tmp/k215-phase9-main/build-v4.py'),'basis_result_sha256':m['reuse_ledger']['result.json']}))
