"""Read-only profile proposal/adoption gate; never executes a source generator."""
from pathlib import Path
import argparse,hashlib,json
HERE=Path(__file__).resolve().parent

def check_file(path,expected):
    path=Path(path)
    if expected is None:
        if path.exists() or path.is_symlink():
            raise ValueError('required retired path is present: '+str(path))
        return
    if not path.is_file() or path.is_symlink():
        raise ValueError('required regular pinned file missing: '+str(path))
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise ValueError('file hash differs: '+str(path))

def review(repo,mode):
    data=json.loads((HERE/'source-map.json').read_text())
    checked=[]
    for row in data['files']:
        check_file(row['before_snapshot'],row['before_sha256'])
        if not row['delete']:
            check_file(row['candidate'],row['candidate_sha256'])
        expected=row['before_sha256'] if mode=='before' else (None if row['delete'] else row['candidate_sha256'])
        check_file(Path(repo)/row['path'],expected)
        checked.append({'path':row['path'],'expected_sha256':expected})
    return {'status':'PASS_PROFILE_BINDINGS_'+mode.upper(),'checked':checked,
            'scope':'Exact three writes and two retirement states, with archived before and candidate bytes. No compiler, generator or canonical mutation.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--mode',choices=['before','after'],required=True)
    a=p.parse_args();print(json.dumps(review(a.repo,a.mode),indent=2))
