"""Bounded isolated EnumPerm checks against the completed phase-three cache."""
from pathlib import Path
import os,json,hashlib,re,signal,shutil,importlib.util,sys
P=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
FORMAL=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal'
BASIS=Path('/tmp/k215-proof-phase3/lean-run1')
HELPER=FORMAL/'verification/k215/lean/build.py'
LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
save=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
variant,outname,mode=sys.argv[1:];out=P/outname;out.mkdir(exist_ok=False)
assert sha(HELPER)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
spec=importlib.util.spec_from_file_location('supervisor',HELPER);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
old=read(BASIS/'completed.json');accepted=read(BASIS/'result.json');inventory=read(BASIS/'inventory.json');boundary=read(BASIS/'toolchain.json')
assert accepted['status']=='PASS' and accepted['primary_project_modules']==185
assert sha(BASIS/'completed.json')==accepted['completed_sha256'] and sha(BASIS/'inventory.json')==accepted['inventory_sha256']
assert len(old)==185 and set(old)=={r['module'] for r in inventory['modules']}
COMPILER=Path(boundary['lean']['path'])
before={str(p):sha(p) for p in [Path(__file__),HELPER,BASIS/'result.json',BASIS/'completed.json',BASIS/'inventory.json',BASIS/'toolchain.json']}
for k in ['lean','lake','Init.olean','project_toolchain']:
 e=boundary[k];assert sha(e['path'])==e['sha256'];before[e['path']]=e['sha256']
objects=out/'objects';sources=out/'source';sources.mkdir();logs=out/'attempts';logs.mkdir()
for row in inventory['modules']:
 m=row['module'];r=old[m]
 assert r['status']=='PASS' and r['source_sha256']==row['source_sha256']
 assert sha(row['source'])==row['source_sha256'];before[row['source']]=row['source_sha256']
 assert r['dependencies']=={d:old[d]['object_sha256'] for d in row['imports'] if d in old}
 obj=BASIS/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==r['object_sha256']
 assert sha(r['log'])==r['log_sha256']
 target=objects/(m.replace('.','/')+'.olean');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(obj,target)
 before[str(obj)]=sha(obj);before[r['log']]=r['log_sha256']
save(out/'before.json',before);save(out/'basis-completed.json',old);save(out/'toolchain.json',boundary)
shutil.copyfile(HELPER,out/'supervisor.py')
modules=['EnumPerm'] if mode=='module' else ['EnumPerm','L2AxiomsPerm','L2RootPerm','SeedPerm','KEndpoint215']
for n in modules:
 src=P/variant/'BusyBeaver/ZFC/EnumPerm.lean' if n=='EnumPerm' else REPO/('Computability/BusyBeaver/Lean/BusyBeaver/ZFC/'+n+'.lean')
 target=sources/('BusyBeaver/ZFC/'+n+'.lean');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
 before[str(src)]=sha(src)
checks=[('BusyBeaver.ZFC.'+n,0) for n in modules]
if mode!='module':
 for n,count in [('EndpointAudit215',2),('K215Audit',8)]:
  src=FORMAL/('verification/k215/lean/'+n+'.lean');shutil.copyfile(src,sources/(n+'.lean'));before[str(src)]=sha(src);checks.append((n,count))
 src=P/'Audit.lean';shutil.copyfile(src,sources/'Audit.lean');before[str(src)]=sha(src);checks.append(('Audit',4))
save(out/'before.json',before)
env=os.environ.copy();env['LEAN_PATH']=str(objects);env['LEAN_NUM_THREADS']='1';done=dict(old);results=[]
for i,(m,reports_expected) in enumerate(checks):
 source=sources/(m.replace('.','/')+'.lean');obj=objects/(m.replace('.','/')+'.olean')
 clean=helper.without_comments_strings(source.read_text());imports=[x for s in re.findall(r'(?m)^\s*import\s+([^\n]+)',clean) for x in s.split()]
 assert all(d in done for d in imports)
 deps={d:done[d]['object_sha256'] for d in imports}
 for d,h in deps.items():assert sha(objects/(d.replace('.','/')+'.olean'))==h
 attempt=logs/f'{i+1:02d}-{m}';attempt.mkdir();shutil.copyfile(source,attempt/source.name)
 if obj.exists():obj.unlink()
 command=[str(COMPILER),'-j1','-M12288','--root='+str(sources),'-o',str(obj),str(source)]
 row={'module':m,'source_sha256':sha(source),'imports':imports,'dependencies':deps,'command':command,'compiler_sha256':sha(COMPILER),'timeout_seconds':120,'memory_mebibytes':12288,'log':str(attempt/'compiler.log'),'expected_axiom_reports':reports_expected}
 print('CHECK',m,flush=True)
 ok=helper.run_locked(command,sources,env,LOCK,Path(row['log']),120,row,attempt/'record.json')
 text=Path(row['log']).read_text();reports=re.findall(r'depends on axioms: \[([^]]*)\]',text)
 row['source_unchanged']=sha(source)==row['source_sha256'];row['dependencies_unchanged']=all(sha(objects/(d.replace('.','/')+'.olean'))==h for d,h in deps.items())
 row['warnings']=text.count('warning:');row['reports']=reports;row['axiom_free_reports']=text.count('does not depend on any axioms')
 ok=ok and row['source_unchanged'] and row['dependencies_unchanged'] and 'error:' not in text and 'sorryAx' not in text and "declaration uses 'sorry'" not in text
 ok=ok and all(set(s.strip() for s in r.split(','))<={'propext','Classical.choice','Quot.sound'} for r in reports)
 if reports_expected:ok=ok and len(reports)+row['axiom_free_reports']==reports_expected and not row['warnings']
 row['status']='PASS' if ok else 'FAIL'
 if ok:row['object_sha256']=sha(obj)
 save(attempt/'record.json',row);results.append(row);print(row['status'],m,round(row['seconds'],3),flush=True)
 save(out/'progress.json',results)
 if not ok:print(text,flush=True);break
 done[m]=row
post=all(sha(f)==h for f,h in before.items())
# Only changed/fresh objects plus unchanged imported dependency closure are accepted.
failed={r['module'] for r in results if r['status']!='PASS'}
objects_post=all(sha(objects/(m.replace('.','/')+'.olean'))==r['object_sha256'] for m,r in done.items() if m not in failed)
result={'status':'PASS' if len(results)==len(checks) and all(r['status']=='PASS' for r in results) and post and objects_post else 'FAIL','basis':'Exact completed phase3 185-module cache copied privately; unchanged dependencies reused, not a fresh full closure.','variant':variant,'checks':results,'input_post':post,'private_objects_post':objects_post,'no_canonical_mutations':True}
save(out/'completed.json',done);save(out/'result.json',result);print('TERMINAL',result['status'],flush=True)
if result['status']!='PASS':raise SystemExit(1)
