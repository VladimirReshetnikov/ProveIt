"""Read-only source/evidence correspondence; does not invoke Lean."""
from pathlib import Path
import json,hashlib,re
P=Path('/tmp/k215-normalized-decoder/final');B=Path('/tmp/k215-proof-phase5/lean-run1');O=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((P/'run2/result.json').read_text());f=json.loads((P/'freeze.json').read_text())
assert r['status']=='PASS' and r['exit_code']==0 and not r['timed_out']
assert r['warnings']==0 and r['basis_unchanged'] and r['inputs_unchanged'] and r['source_unchanged']
s=(P/'RMNormalizedBisim.lean').read_bytes();a=(P/'Audit.lean').read_bytes();compiled=Path(r['source']);assert compiled.read_bytes()==s+a
assert sha(compiled)==r['source_sha256'] and sha(P/'RMNormalizedBisim.lean')==r['candidate_sha256']==f['candidate_sha256']
assert sha(P/'Audit.lean')==r['audit_sha256'] and sha(P/'run2/compiler.log')==r['log_sha256']
assert sha(P/'run.py')==r['runner_sha256'] and sha(r['command'][0])==r['compiler_sha256']
obj=Path(r['command'][r['command'].index('-o')+1]);assert sha(obj)==r['object_sha256']
assert r['command']==[r['command'][0],'-j1','-M12288','--root='+str(P/'run2/workspace'),'-o',str(P/'run2/objects/BusyBeaver/ZFC/RMNormalizedBisim.olean'),str(compiled)]
assert r['timeout_seconds']==120 and r['memory_mebibytes']==12288
log=(P/'run2/compiler.log').read_text();pairs=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",log)
expected=['default128','default_lookup','generic_endpoint','explicit512','default_endpoint','long_decoding','old_decoding','equivalent_padding','different_bit','missing_lookup']
assert [n for n,_ in pairs]==['SetTheory.BusyBeaver.ZFC.NormalizedCheckerAudit.'+n for n in expected]
assert [list(x) for x in pairs]==r['axiom_reports']
assert all(ax==('propext, Quot.sound' if n.rsplit('.',1)[1] in expected[2:5] else '') for n,ax in pairs)
assert not any(t in log for t in ['warning:','error:','sorryAx'])
inv=json.loads((B/'inventory.json').read_text());rows={x['module']:x for x in inv['modules']};seen=set()
def visit(m):
 if m in seen:return
 seen.add(m)
 for d in rows[m]['imports']:
  if d in rows:visit(d)
visit('BusyBeaver.ZFC.RMBisim')
deps={}
for m in sorted(seen):
 x=rows[m];q=B/'objects'/(m.replace('.','/')+'.olean');link=P/'run2/objects'/(m.replace('.','/')+'.olean')
 assert sha(x['source'])==x['source_sha256']==r['inputs'][x['source']]
 assert link.is_symlink() and link.resolve()==q.resolve()
 assert sha(q)==sha(link)==r['basis_objects'][m]
 deps[m]={'source_sha256':x['source_sha256'],'object_sha256':sha(q),'imports':x['imports']}
files={n:sha(P/n) for n in ['RMNormalizedBisim.lean','source.diff','successor.diff','Audit.lean','README.md','freeze.json','import-census.json','run.py','run2/result.json','run2/compiler.log','run2/before.json']}
out={'status':'PASS_BOUNDED_MATHEMATICAL_API_AND_RECORDED_RUN_REVIEW','files':files,'scope':'Full165-line generic checker and adaptation diff, complete typed clients, supporting current ipeq/tsite/Bisim interfaces, and recorded run2 correspondence. No compiler invocation or concrete certificate validation.','findings':[],'mathematical_checks':['zeros/ibeq imply pointwise equality of zero-padded bits, including empty/trailing-zero paths.','tsite_ipeq preserves both instruction and complete consumed path via walk_ipeq and pre_ipeq.','branchOk retains existing finite seg/count equality and changes only endpoint comparison to ipeq.','entryOk applies incPath/breakPath to consumed paths; no arithmetic on normalized stored representatives.','Rel saturation is recovered through lookupC_all, without uniqueness, shape, decoder injectivity, bound or program-WF premises.','Arbitrary-decoder/program/register public halting iff composes existing Bisim soundness; old128 API and explicit512 caller clients remain separate.'],'actual_correspondence':{'owner_run':'run2','exit_code':0,'seconds':r['seconds'],'warnings':0,'named_reports':10,'closed_reports':7,'standard_axiom_reports':3,'candidate_plus_audit_exact':True,'compiler_object_log_bound':True,'imported_project_closure_checked':deps},'limits':['No independent compiler rerun.','Only the imported RMBisim project closure was rehashed here; whole184-provider before/after claim remains owner run evidence.','No fresh toolchain Init/provider audit beyond the recorded compiler pin and accepted phase5 basis.','No concrete1426-entry data migration, K215 endpoint rebuild or performance benefit established.','Original Source168 attribution and prior wrapper-bearing attempt remain preserved by owner.']}
(O/'review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'imported_modules':len(deps),'peer_sha256':sha(O/'review.json')},indent=2))
