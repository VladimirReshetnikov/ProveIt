from pathlib import Path
import ast,hashlib,json,re,tempfile
S=Path('/tmp/k215-phase13-upstream-check');O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
f=read(S/'freeze.json')
for name,pin in f['files'].items():assert sha(S/name)==pin,name
old={}
for d,n in [(Path('/tmp/k215-phase12-import-check/compatibility-run1'),69),(Path('/tmp/k215-phase12-import-check/primary-run1'),184)]:
 inv=read(d/'inventory.json');done=read(d/'completed.json');result=read(d/'result.json');assert len(inv['modules'])==len(done)==n
 assert sha(d/'inventory.json')==result['inventory_sha256']and sha(d/'completed.json')==result['completed_sha256']
 for r in inv['modules']:
  m=r['module'];rec=done[m];v=(r['source_sha256'],r['imports'],rec['object_sha256']);assert m not in old or old[m]==v;old[m]=v
assert len(old)==201
summaries={}
for name,invname,count in [('primary','primary-with-api',187),('compatibility','compatibility',70),('api-only','api-only',17)]:
 inv=read(S/(invname+'-inventory.json'));mp=read(S/(name+'-map.json'));rows=inv['modules'];by={r['module']:r for r in rows};assert len(by)==len(rows)==count
 for r in rows:assert sha(r['source'])==r['source_sha256']
 done=set();ordered=[]
 def visit(m,active=()):
  if m=='Init'or m in done:return
  assert m not in active
  for d in by[m]['imports']:visit(d,active+(m,))
  done.add(m);ordered.append(m)
 for m in inv['targets']:visit(m)
 assert ordered==mp['expected']['modules']==[r['module']for r in rows]
 changed={m for m,r in by.items()if m not in old or r['source_sha256']!=old[m][0]}
 forced=set(changed)
 while True:
  more=forced|{m for m,r in by.items()if set(r['imports'])&forced}
  if more==forced:break
  forced=more
 assert sorted(changed)==mp['expected']['changed'];assert sorted(forced)==mp['expected']['forced']
 for p in mp['modules']:
  assert p['module']in by and sha(p['source'])==p['source_sha256']
  assert p['imports']==by[p['module']]['imports']
  if 'reports'in p:assert len(p['report_axioms'])==len(p['reports'])
 summaries[name]={'modules':len(rows),'source_changes':len(changed),'forced':len(forced)}
assert summaries['primary']=={'modules':187,'source_changes':5,'forced':36}
assert not any('KSites215Batch'in m for m in read(S/'primary-map.json')['expected']['forced'])
p={r['module']for r in read(S/'primary-inventory.json')['modules']};c=read(S/'compatibility-map.json')['expected'];cm=set(c['modules']);cf=set(c['forced'])
assert len(p)==184 and len(p&cm)==53 and len(cf-p)==16 and cm-p-cf=={'BusyBeaver.ZFC.Dag254'}
assert len(p|cm)-2==199
# Execute only the extracted pure log predicate, never the driver or a proof tool.
t=ast.parse((S/'build.py').read_text());node=next(n for n in t.body if isinstance(n,ast.FunctionDef)and n.name=='log_policy');results=[]
with tempfile.TemporaryDirectory(prefix='phase13-peer-log-')as d:
 log=Path(d)/'compiler.log';env={'Path':Path,'re':re,'overrides':{'Client':{'reports':['Exact.one','Exact.two'],'report_axioms':[[],['propext','Quot.sound']]}}}
 exec(compile(ast.Module(body=[node],type_ignores=[]),str(S/'build.py'),'exec'),env)
 rec={'status':'PASS','exit_code':0,'timed_out':False,'log':str(log)}
 for name,txt,accepted in [
 ('exact profiles',"'Exact.one' does not depend on any axioms\n'Exact.two' depends on axioms: [propext, Quot.sound]\n",True),
 ('unordered profile set',"'Exact.one' does not depend on any axioms\n'Exact.two' depends on axioms: [Quot.sound, propext]\n",True),
 ('extra standard axiom in empty profile',"'Exact.one' depends on axioms: [propext]\n'Exact.two' depends on axioms: [propext, Quot.sound]\n",False),
 ('missing required axiom',"'Exact.one' does not depend on any axioms\n'Exact.two' depends on axioms: [propext]\n",False),
 ('wrong qualified name',"'Wrong.one' does not depend on any axioms\n'Exact.two' depends on axioms: [propext, Quot.sound]\n",False),
 ('extra report',"'Exact.one' does not depend on any axioms\n'Exact.two' depends on axioms: [propext, Quot.sound]\n'Extra.x' does not depend on any axioms\n",False)]:
  log.write_text(txt);assert env['log_policy']({'module':'Client'},rec)==accepted;results.append({'name':name,'accepted':accepted,'matched':True})
controls=read(S/'controls-result.json')
for p,h in controls['inputs'].items():assert sha(p)==h
assert controls['positive']==3 and controls['negative']==20 and all(r['matched']for r in controls['checks'])
result={'status':'PASS_OWN_INERT_METADATA_CHECKS','freeze_sha256':sha(S/'freeze.json'),'script_sha256':sha(__file__),'held_files_rehashed':len(f['files']),'basis_union_providers':201,'plans':summaries,'combined_project_modules':199,'compatibility_after_primary':{'primary_reuse':53,'fresh':16,'old_Dag254':1},'own_pure_log_controls':results,'owner_controls_source_and_pins_read':{'positive':3,'negative':20},'scope':'Own hash/JSON/AST-only checks; the sole extracted executable fragment is the pure log predicate on synthetic files. No driver, compiler, producer or archived code was invoked; no actual-run acceptance.'}
(O/'metadata-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'sha256':sha(O/'metadata-review.json')}))
