from pathlib import Path
import ast,hashlib,json,re
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');F=R/'Computability/BusyBeaver/Research/ZFC/k225-formal'
B=Path('/tmp/k215-phase12-import-check/primary-run1');C=Path('/tmp/k215-phase12-import-check/compatibility-run1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert sha(B/'result.json')=='a5fce6a787751ba527cc368ff97b770d28eeb517149d5e3f99b17dd7c738df5e'
assert sha(C/'result.json')=='7223a5fa4f5fe56e331d2dc27efc7b2d8e50f473d081eed9e145278728e68f9c'
old={};old_record={};providers={}
for directory,kind in [(C,'compatibility'),(B,'primary')]:
 inv=read(directory/'inventory.json');done=read(directory/'completed.json');result=read(directory/'result.json')
 assert sha(directory/'inventory.json')==result['inventory_sha256']and sha(directory/'completed.json')==result['completed_sha256']
 for row in inv['modules']:
  m=row['module'];rec=done[m];assert rec['source_sha256']==row['source_sha256']
  if m in old:assert row['source_sha256']==old[m]['source_sha256']and row['imports']==old[m]['imports']
  old[m]=row;old_record[m]=rec;providers[m]={'directory':str(directory),'kind':kind}
assert len(old)==201
H=F/'verification/k215/lean/build.py';assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
node=next(n for n in ast.parse(H.read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='without_comments_strings');env={};exec(compile(ast.Module(body=[node],type_ignores=[]),str(H),'exec'),env);strip=env['without_comments_strings']
def imports(p):return [w for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',strip(Path(p).read_text()))for w in line.split()]
roots=('Computability/BusyBeaver/Lean','Logic/FirstOrder/Lean','SetTheory/ZF/Lean','SetTheory/BoundedConsistency/Lean')
plans=[]
for name,pin in [('DominatedImplication','bd07364a829e8a1535b0ecf1ee6ed0c292d5af35e01a6db8f152dd2610e247d8'),('Lukasiewicz','7d443a733b5c5ddd0d49728cf1ea7d855dd445f156934c13578bacc008c59874')]:
 p=S/'candidate'/(name+'.lean');assert sha(p)==pin;m='BusyBeaver.ZFC.'+name
 plans.append({'module':m,'source':str(p),'source_sha256':pin,'before_sha256':old[m]['source_sha256'],'imports':imports(p)})
# Exact public named reports already present in the raw core and unchanged numeric adapter.
for name in ['DomRho8','KCodeDom']:
 m='BusyBeaver.ZFC.'+name;p=R/'Computability/BusyBeaver/Lean'/Path(*m.split('.')).with_suffix('.lean');assert sha(p)==old[m]['source_sha256']
 plans.append({'module':m,'source':str(p),'source_sha256':sha(p),'before_sha256':sha(p),'imports':imports(p)})
for name in ['GenericShared13Api','NumericCD52Api','LukasShared13Api']:
 p=S/'clients'/(name+'.lean');plans.append({'module':name,'source':str(p),'source_sha256':sha(p),'before_sha256':None,'imports':imports(p)})
for name in ['WFModelCompat12','ZFNativeCompat12']:
 p=Path('/tmp/k215-phase12-import-check/clients')/(name+'.lean');assert sha(p)==old[name]['source_sha256']
 plans.append({'module':name,'source':str(p),'source_sha256':sha(p),'before_sha256':sha(p),'imports':imports(p)})
for row in plans:
 text=Path(row['source']).read_text();reports=re.findall(r'^#print axioms (\S+)',text,re.M)
 if reports:
  if row['module'].startswith('BusyBeaver.ZFC.'):
   ns='SetTheory.'+row['module'];reports=[r if r.startswith('SetTheory.')else ns+'.'+r for r in reports]
  elif row['module']in ['GenericShared13Api','NumericCD52Api','LukasShared13Api']:
   reports=[row['module']+'.'+r for r in reports]
  row['reports']=reports
  if row['module']in ['BusyBeaver.ZFC.DominatedImplication','GenericShared13Api']:row['report_axioms']=[[]for _ in reports]
  elif row['module']in ['BusyBeaver.ZFC.DomRho8','BusyBeaver.ZFC.KCodeDom','NumericCD52Api']:row['report_axioms']=[['propext','Quot.sound']for _ in reports]
overrides={r['module']:r for r in plans}
def inventory(targets):
 rows=[];seen=set();active=set()
 def visit(m):
  if m=='Init'or m in seen:return
  assert m not in active
  if m in overrides:r=overrides[m]
  else:
   found=[p for root in roots if(p:=R/root/Path(*m.split('.')).with_suffix('.lean')).is_file()];assert len(found)==1 and m in old,m
   p=found[0];assert sha(p)==old[m]['source_sha256'];r={'module':m,'source':str(p),'source_sha256':sha(p),'imports':imports(p)};assert r['imports']==old[m]['imports']
  active.add(m)
  for d in r['imports']:visit(d)
  active.remove(m);seen.add(m);rows.append(r)
 for t in targets:visit(t)
 changed={r['module']for r in rows if r['module']not in old or r['source_sha256']!=old[r['module']]['source_sha256']}
 forced=set(changed)
 while True:
  more=forced|{r['module']for r in rows if set(r['imports'])&forced}
  if more==forced:break
  forced=more
 return {'targets':targets,'modules':rows,'changed':sorted(changed),'forced':sorted(forced)}
sets={}
for name,targets in [('primary',['BusyBeaver.ZFC.KEndpoint215','BusyBeaver.ZFC.KDecoderPrefix215']),('primary-with-api',['BusyBeaver.ZFC.KEndpoint215','BusyBeaver.ZFC.KDecoderPrefix215','GenericShared13Api','NumericCD52Api','LukasShared13Api']),('compatibility',['WFModelCompat12','ZFNativeCompat12']),('api-only',['GenericShared13Api','NumericCD52Api','LukasShared13Api'])]:
 inv=inventory(targets);save(S/(name+'-inventory.json'),inv);sets[name]=inv
pm={r['module']for r in sets['primary']['modules']};cm={r['module']for r in sets['compatibility']['modules']};api={r['module']for r in sets['api-only']['modules']};forcedcomp=set(sets['compatibility']['forced'])
summary={'status':'SOURCE_ONLY_PLAN_NOT_EXECUTED','primary_projects':len(pm),'endpoint_projects':len(inventory(['BusyBeaver.ZFC.KEndpoint215'])['modules']),'primary_forced':sets['primary']['forced'],'primary_unchanged_reuse':len(pm)-len(sets['primary']['forced']),'primary_with_three_api_clients':len(sets['primary-with-api']['modules']),'primary_with_api_forced':len(sets['primary-with-api']['forced']),'compatibility_total_with_two_existing_clients':len(cm),'compatibility_project_count':len(cm)-2,'compatibility_after_primary_reuse':sorted(cm&pm),'compatibility_fresh_after_primary':sorted(forcedcomp-pm),'compatibility_old_unaffected_reuse':sorted(cm-pm-forcedcomp),'combined_project_modules':len(pm|cm)-2,'api_only_total':len(api),'api_only_forced':sets['api-only']['forced'],'api_only_projects':len(api)-3,'all_nine_site_batches_unaffected':all('KSites215Batch'not in m for m in sets['primary']['forced']),'basis':{'primary':str(B),'primary_result_sha256':sha(B/'result.json'),'compatibility':str(C),'compatibility_result_sha256':sha(C/'result.json'),'union_providers_including_two_existing_clients':len(old)},'preferred_execution':'One primary check with three small explicit API clients in the same source inventory; two unchanged endpoint audits follow. Then the compatibility closure reuses current primary and refreshes only remaining descendants plus its existing clients. An API-only preflight is optional and not needed to satisfy the same full closure.','pending':'Runner final producer boundary awaits maintained producer source freeze; no compiler execution authorized by this plan.'}
save(S/'candidate-map.json',{'modules':plans});save(S/'census.json',summary);save(S/'baseline-providers.json',providers)
print(json.dumps(summary,indent=2))
