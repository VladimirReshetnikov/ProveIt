"""Own source-only combined-overlay census; never imports proposal code."""
from pathlib import Path
import argparse,hashlib,json,re
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent
F=R/'Computability/BusyBeaver/Research/ZFC/k225-formal';B=Path('/tmp/k215-phase13-upstream-check/primary-run1');C=Path('/tmp/k215-phase13-upstream-check/compatibility-run1')
ROOTS=['Computability/BusyBeaver/Lean','Logic/FirstOrder/Lean','SetTheory/ZF/Lean','SetTheory/BoundedConsistency/Lean']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def strip(text):
 out=[];i=depth=0
 while i<len(text):
  if text[i:i+2]=='/-':depth+=1;i+=2
  elif depth and text[i:i+2]=='-/':depth-=1;i+=2
  elif depth:
   if text[i]=='\n':out.append('\n')
   i+=1
  elif text[i:i+2]=='--':
   j=text.find('\n',i);i=len(text)if j<0 else j
  elif text[i]=='"':
   i+=1
   while i<len(text):
    if text[i]=='\\':i+=2
    elif text[i]=='"':i+=1;break
    else:i+=1
  else:out.append(text[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(path):return[w for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',strip(Path(path).read_text()))for w in line.split()]
def census(out,clients,sources):
 assert not out.exists();out.mkdir()
 pins={B:'00a44b3ce690bfcd397f53275c2dcec69d25423de8e029086b0aefe020fb397e',C:'bd9e50bce1c8a463719d83c201f402dad3edd89c0621ae827082b75638a3c74f'}
 old={};providers={};records={}
 for d,count,kind in[(C,70,'compatibility'),(B,187,'primary')]:
  assert sha(d/'result.json')==pins[d];result=read(d/'result.json');inv=read(d/'inventory.json');done=read(d/'completed.json')
  assert result['status']=='PASS'and sha(d/'inventory.json')==result['inventory_sha256']and sha(d/'completed.json')==result['completed_sha256']and len(inv['modules'])==len(done)==count
  for row in inv['modules']:
   m=row['module'];rec=done[m];assert rec['source_sha256']==row['source_sha256']
   if m in old:assert(row['source_sha256'],row['imports'],rec['object_sha256'])==(old[m]['source_sha256'],old[m]['imports'],records[m]['object_sha256'])
   old[m]=row;records[m]=rec;providers[m]={'directory':str(d),'kind':kind}
 assert len(old)==204
 for m,row in old.items():
  if not m.startswith('BusyBeaver.')and not m.startswith(('FirstOrder.','ZF.','BoundedZFCConsistency.')):continue
  paths=[R/root/(m.replace('.','/')+'.lean')for root in ROOTS if(R/root/(m.replace('.','/')+'.lean')).is_file()]
  assert len(paths)==1 and sha(paths[0])==row['source_sha256']and imports(paths[0])==row['imports']
 merge=F/'verification/k215/simplification/phase13/upstream-merge';overrides={}
 for base,names in[(merge/'inputs',['TarskiDerived','TarskiLeibniz','KThmK','KEind222']),(merge/'later-542391/inputs',['ProfileComposition','CompositionModel','KLowerEqv'])]:
  for name in names:
   m='BusyBeaver.ZFC.'+name;p=base/'Computability/BusyBeaver/Lean'/(m.replace('.','/')+'.lean')
   overrides[m]={'module':m,'source':str(p),'source_sha256':sha(p),'before_sha256':old[m]['source_sha256'],'imports':imports(p)}
 for row in sources:
  m=row['module'];assert m in overrides and m.startswith('BusyBeaver.ZFC.')
  p=Path(row['source']);assert sha(p)==row['source_sha256']and imports(p)==row['imports']
  overrides[m]={**row,'before_sha256':old[m]['source_sha256']}
 # Retain five checked old clients with their exact named report/profile constraints.
 for mapname,names in [('primary-map.json',['GenericShared13Api','NumericCD52Api','LukasShared13Api']),('compatibility-final-map.json',['WFModelCompat12','ZFNativeCompat12'])]:
  for row in read(B.parent/mapname)['modules']:
   if row['module']in names:
    p=Path(row['source']);assert sha(p)==old[row['module']]['source_sha256']
    overrides[row['module']]={**row,'before_sha256':old[row['module']]['source_sha256']}
 for row in clients:
  p=Path(row['source']);assert row['module']not in old and row['module']not in overrides
  assert sha(p)==row['source_sha256']and imports(p)==row['imports'];overrides[row['module']]={**row,'before_sha256':None}
 def inventory(targets):
  rows=[];active=set();seen=set();closures={}
  def visit(m):
   if m=='Init':return set()
   assert m!='BusyBeaver.ZFC.KProfileTC',('Retired dependency',m)
   if m in seen:return closures[m]
   assert m not in active,('cycle',m)
   if m in overrides:r=overrides[m]
   else:
    paths=[R/root/(m.replace('.','/')+'.lean')for root in ROOTS if(R/root/(m.replace('.','/')+'.lean')).is_file()]
    assert len(paths)==1 and m in old,m;p=paths[0]
    r={'module':m,'source':str(p),'source_sha256':sha(p),'imports':imports(p)}
    assert r['source_sha256']==old[m]['source_sha256']and r['imports']==old[m]['imports']
   active.add(m);closure={m}
   for d in r['imports']:closure|=visit(d)
   active.remove(m);seen.add(m);closures[m]=closure;rows.append({k:r[k]for k in ['module','source','source_sha256','imports']});return closure
  for t in targets:visit(t)
  changed={r['module']for r in rows if r['module']not in old or(r['source_sha256'],r['imports'])!=(old[r['module']]['source_sha256'],old[r['module']]['imports'])}
  forced={m for m in seen if closures[m]&changed}
  return {'targets':targets,'modules':rows,'changed':sorted(changed),'forced':sorted(forced),'external_imports':['Init']}
 new=[r['module']for r in clients];api=['GenericShared13Api','NumericCD52Api','LukasShared13Api'];compat=['WFModelCompat12','ZFNativeCompat12'];prefix=['BusyBeaver.ZFC.KEndpoint215','BusyBeaver.ZFC.KDecoderPrefix215']
 sets={}
 for name,targets in [('endpoint',prefix[:1]),('project',prefix),('primary',prefix+api+new),('compatibility',compat)]:sets[name]=inventory(targets);save(out/(name+'-inventory.json'),sets[name])
 p={r['module']for r in sets['primary']['modules']};c={r['module']for r in sets['compatibility']['modules']};forced=set(sets['compatibility']['forced']);project={r['module']for r in sets['project']['modules']}
 summary={'status':'SOURCE_ONLY_COMBINED_PLAN','primary_project_modules':len(project),'endpoint_project_modules':len(sets['endpoint']['modules']),'prefix_extra_project_modules':len(project)-len(sets['endpoint']['modules']),'primary_providers':len(p),'primary_fresh':len(sets['primary']['forced']),'primary_reuse':len(p)-len(sets['primary']['forced']),'primary_fresh_modules':sets['primary']['forced'],'old_api_clients':api,'new_api_clients':new,'compatibility_providers':len(c),'compatibility_project_modules':len(c)-2,'compatibility_primary_reuse':sorted(c&p),'compatibility_fresh_after_primary':sorted(forced-p),'compatibility_old_reuse':sorted(c-p-forced),'combined_project_modules':len((p|c)-set(api+new+compat)),'retired_module_not_selected':all('BusyBeaver.ZFC.KProfileTC'not in [r['module']for r in v['modules']]for v in sets.values()),'all_nine_site_batches_unaffected':len([m for m in p if'KSites215Batch'in m])==9 and not any('KSites215Batch'in m for m in sets['primary']['forced']),'basis_project_union':199,'canonical_mutation':False,'compiler_or_producer_execution':False}
 save(out/'census.json',summary);save(out/'candidate-map.json',{'modules':list(overrides.values())});save(out/'baseline-providers.json',providers)
 print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--clients',type=Path);p.add_argument('--sources',type=Path);a=p.parse_args();census(a.out,read(a.clients)if a.clients else[],read(a.sources)if a.sources else[])
