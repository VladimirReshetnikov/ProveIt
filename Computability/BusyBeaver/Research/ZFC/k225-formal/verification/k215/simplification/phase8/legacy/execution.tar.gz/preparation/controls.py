"""Metadata-only controls: no subprocess, machine interpreter or proof compiler."""
from pathlib import Path
import copy,json,tempfile,sys
sys.dont_write_bytecode=True
from gates import *
H=Path(__file__).resolve().parent
p=read(H/'prepared-inventory.json');old=read('/tmp/k215-proof-phase7/lean-run1/inventory.json');legacy=read('/tmp/k215-phase7-legacy/run1/inventory.json');approved=read(H/'preparation.json')['approved_sources']
results=[]
def reject(name,f):
 try:f()
 except (AssertionError,KeyError,FileNotFoundError):results.append({'name':name,'result':'REJECTED'});return
 raise AssertionError('Accepted negative '+name)
def mutation(inv,fn):
 x=copy.deepcopy(inv);fn(x);return x
assert checkpoint(old,p['primary'],legacy,approved)==p['union'];results.append({'name':'actual_prepared_graph','result':'PASS'})
reject('unapproved_candidate',lambda:checkpoint(old,p['primary'],legacy,{**approved,DOM:{**approved[DOM],'source_sha256':'0'*64}}))
reject('missing_primary',lambda:checkpoint(old,mutation(p['primary'],lambda x:x['modules'].pop()),legacy,approved))
reject('reordered_primary',lambda:checkpoint(old,mutation(p['primary'],lambda x:x['modules'].reverse()),legacy,approved))
reject('changed_import',lambda:checkpoint(old,mutation(p['primary'],lambda x:x['modules'][0]['imports'].append(DOM)),legacy,approved))
reject('changed_other_source',lambda:checkpoint(old,mutation(p['primary'],lambda x:x['modules'][0].update(source_sha256='0'*64)),legacy,approved))
reject('missing_legacy',lambda:checkpoint(old,p['primary'],mutation(legacy,lambda x:x['modules'].pop()),approved))
reject('missing_new_core',lambda:checkpoint(old,mutation(p['primary'],lambda x:x.update(modules=[r for r in x['modules']if r['module']!=NEW])),legacy,approved))
reject('new_core_wrong_import',lambda:checkpoint(old,mutation(p['primary'],lambda x:next(r for r in x['modules']if r['module']==NEW).update(imports=[DOM])),legacy,approved))
reject('unregistered_source',lambda:checkpoint(old,p['primary'],legacy,{k:v for k,v in approved.items()if k!=NEW}))
audit=Path('/tmp/k215-phase7-legacy/run1/audit/compiler.log').read_text();assert len(audit_reports(audit))==5;results.append({'name':'historical_exact_five_reports','result':'PASS'})
for name,text in [('warning','warning: x\n'+audit),('error',audit+'error: x'),('sorry',audit+'sorryAx'),('wrong_name',audit.replace('LegacyAudit.rootDom','LegacyAudit.other')),('extra_report',audit+"\n'x' does not depend on any axioms\n"),('new_axiom',audit.replace('propext','Untrusted'))]:reject('audit_'+name,lambda text=text:audit_reports(text))
review={**read('/tmp/k215-proof-phase7/root-actual-review.json'),'current_modules':188};rsha=sha('/tmp/k215-proof-phase7/lean-run1/result.json');primary_review(review,rsha);results.append({'name':'synthetic_phase8_root_review_shape','result':'PASS'})
reject('wrong_result',lambda:primary_review(review,'0'*64))
reject('wrong_primary_count',lambda:primary_review({**review,'current_modules':186},rsha))
# Synthetic prospective provider cases: retaining predecessor object hashes allows reuse; changing KCodeDom propagates to three. No actual phase8 result is claimed.
pd=read('/tmp/k215-proof-phase7/lean-run1/completed.json');ld=read('/tmp/k215-phase7-legacy/run1/completed.json')
selected={**pd,**{m:ld[m]for m in EXTRA},NEW:{'object_sha256':'synthetic-generic-core'}};reused=[]
for row in p['union']['modules']:
 m=row['module']
 if m in EXTRA:
  deps={d:selected[d]['object_sha256']for d in row['imports']if d in selected}
  assert reuse_record(row,ld[m],deps);reused.append(m)
assert set(reused)==EXTRA;results.append({'name':'synthetic_unchanged_direct_provider_reuse','result':'PASS'})
# Synthetic changed KCodeDom object invalidates only three descendants.
changed=copy.deepcopy(selected);changed['BusyBeaver.ZFC.KCodeDom']['object_sha256']='synthetic-new-object';dirty=[]
for row in p['union']['modules']:
 m=row['module']
 if m in EXTRA:
  deps={d:changed[d]['object_sha256']for d in row['imports']if d in changed}
  if not reuse_record(row,ld[m],deps):dirty.append(m);changed[m]['object_sha256']='new-'+m
assert set(dirty)==LEGACY_AFFECTED;results.append({'name':'three_transitive_invalidation_control','result':'PASS'})
with tempfile.TemporaryDirectory(prefix='legacy-metadata-')as d:
 d=Path(d);basis=d/'basis';basis.write_text('provider');cache=d/'objects';cache.mkdir();obj=cache/'x.olean';obj.symlink_to(basis)
 private_parents(obj,cache);provider(obj,basis,False)
 reject('alias_claimed_fresh',lambda:provider(obj,basis,True))
 obj.unlink();obj.write_text('own');provider(obj,basis,True)
 reject('regular_claimed_reuse',lambda:provider(obj,basis,False))
 alias=cache/'dir';alias.symlink_to(d,target_is_directory=True)
 reject('directory_alias',lambda:private_parents(alias/'x.olean',cache))
 rec={'status':'PASS','source_sha256':sha(basis),'dependencies':{},'object_sha256':sha(obj),'log':str(basis),'log_sha256':sha(basis)};row={'source':str(basis),'source_sha256':sha(basis),'imports':[]}
 valid_record(row,rec,{},obj);results.append({'name':'complete_provider_record','result':'PASS'})
 reject('changed_log',lambda:valid_record(row,{**rec,'log_sha256':'0'*64},{},obj))
 reject('changed_object',lambda:valid_record(row,{**rec,'object_sha256':'0'*64},{},obj))
 reject('changed_dependencies',lambda:valid_record(row,{**rec,'dependencies':{'unbound':'x'}},{},obj))
 reject('failed_provider',lambda:valid_record(row,{**rec,'status':'FAIL'},{},obj))
# Syntax only, without loading the driver main or invoking any child process.
for name in ['build.py','prepare.py','gates.py','controls.py']:compile((H/name).read_text(),str(H/name),'exec')
save(H/'controls-result.json',{'status':'PASS_METADATA_CONTROLS_ONLY','positive':sum(r['result']=='PASS'for r in results),'negative':sum(r['result']=='REJECTED'for r in results),'results':results,'gates_sha256':sha(H/'gates.py'),'compiler_invocations':[]})
print(json.dumps({'positive':sum(r['result']=='PASS'for r in results),'negative':sum(r['result']=='REJECTED'for r in results),'status':'PASS_METADATA_ONLY'}))
