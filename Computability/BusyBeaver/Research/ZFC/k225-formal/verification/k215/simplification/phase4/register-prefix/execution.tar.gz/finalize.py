from pathlib import Path
import difflib, hashlib,json,re
p=Path('/tmp/k215-segment-prefix');repo=Path('/home/codex/.codex/worktrees/ec20/Proofs');basis=Path('/tmp/k215-proof-phase3/lean-run1')
sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
a=(p/'RMBisim.before.lean').read_text();b=(p/'RMBisim.lean').read_text()
start=b.index('/-- A halt leaf has no outgoing transition. -/');end=b.index('theorem hn_step ',start);stripped=b[:start]+b[end:]
x=stripped.index('theorem seg_hn ');y=stripped.index('/-! ## Segment bisimulations -/',x);u=a.index('theorem seg_hn ');v=a.index('/-! ## Segment bisimulations -/',u)
assert stripped[:x]+a[u:v]+stripped[y:]==a
old_header=a[u:v].split('\n  | 0,',1)[0];new_header=stripped[x:y].split(' := by',1)[0];assert old_header==new_header
assert sha(repo/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/RMBisim.lean')==sha(p/'RMBisim.before.lean')
r=json.loads((p/'run3/result.json').read_text());api=json.loads((p/'api-comparison.json').read_text());assert r['status']=='PASS' and r['warnings']==0 and r['source_sha256']==sha(p/'RMBisim.lean');assert api['axiom_reports_equal']
for name in ('baseline','candidate'):
 ar=json.loads((p/('audit-'+name)/'result.json').read_text());assert ar['status']=='PASS' and ar['warnings']==0;assert sha(p/('audit-'+name)/'compiler.log')==ar['log_sha256']
done=json.loads((basis/'completed.json').read_text());assert all(sha(basis/'objects'/(m.replace('.','/')+'.olean'))==d['object_sha256'] for m,d in done.items())
inv=json.loads((basis/'inventory.json').read_text());entry=next(x for x in inv['modules'] if x['module']=='BusyBeaver.ZFC.RMBisim')
(p/'source.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='RMBisim.before.lean',tofile='RMBisim.lean')))
result={'status':'PASS_ISOLATED_CANDIDATE','candidate_sha256':sha(p/'RMBisim.lean'),'baseline_sha256':sha(p/'RMBisim.before.lean'),'baseline_still_canonical':True,'bytes':{'before':len(a.encode()),'after':len(b.encode())},'lines':{'before':len(a.splitlines()),'after':len(b.splitlines())},'only_existing_proof_changed':'seg_hn','all_existing_declaration_statements_and_executable_definitions_unchanged':True,'hn_step_entire_declaration_byte_identical':True,'new_helpers':['atHalt_step','hn_after'],'producer':'Handwritten proof; no source generator. source.diff is the exact proposed canonical edit.','kernel_seconds':r['seconds'],'kernel_warnings':0,'typed_clients_per_old_new_audit':2,'axiom_reports_per_old_new_audit':4,'axiom_reports_identical':True,'direct_dependencies':{d:done[d]['object_sha256'] for d in entry['imports']},'phase3_basis_completed_sha256':sha(basis/'completed.json'),'all185_basis_objects_rehashed_after_audits':True,'full_endpoint_rebuild':'Not performed; isolated module plus old/new API audits only.','history':['run1: two proof elaboration errors, preserved.','run2: broader hn_step refactor passed with one redundant-parameter linter; original wrapper restored.','run3: final seg_hn-only refactor passed with zero warnings.']}
(p/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
files=[q for q in p.rglob('*') if q.is_file() and not q.is_symlink() and q.suffix not in {'.olean','.ilean'} and q.name!='freeze.json']
(p/'freeze.json').write_text(json.dumps({'status':'FROZEN','files':{str(q.relative_to(p)):{'sha256':sha(q),'bytes':q.stat().st_size} for q in sorted(files)}},indent=2)+'\n')
print(json.dumps(result,indent=2));print('freeze',sha(p/'freeze.json'))
