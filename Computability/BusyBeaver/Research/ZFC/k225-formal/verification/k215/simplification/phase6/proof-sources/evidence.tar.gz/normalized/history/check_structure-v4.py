"""Independent structural/finite obligations; does not invoke Lean or confer kernel acceptance."""
from pathlib import Path
import sys,json,hashlib,re,collections,difflib
O=Path(__file__).resolve().parent;ROOT=Path('/home/codex/.codex/worktrees/ec20/Proofs');W=O/'workspace'
F=Path('Computability/BusyBeaver/Research/ZFC/k225-formal');L=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC')
sys.path.insert(0,str(W/F));import gen_cert as g;import generate_source215_lean as producer
sha=lambda b:hashlib.sha256(b).hexdigest()
claimpath=ROOT/F/'verification/k215/simplification/proposals/k215-simplification/source_normalization/normalized_certificate.json'
claim=json.loads(claimpath.read_text());wire=claim['entries']
def decode(s):
 n=int(s);assert n>=1;return tuple(x=='1'for x in bin(n)[3:])
claimed=[(decode(a),decode(b),0,j,k)for a,b,j,k in wire]
def trim(p):
 return p[:max((i+1 for i,b in enumerate(p)if b),default=0)]
T1=g.Tree(g.load(W/F.parent/'candidate-k215/sites215.json'));T2=g.Tree(g.load(W/F/'lean215/dagperm_sites.json'))
raw=g.generate(T1,T2);new=producer.trailing_false_quotient(raw)
assert len(raw)==2240 and len(new)==1426 and new==claimed
indices={(a,b):i for i,(a,b,z,j,k)in enumerate(new)};assert len(indices)==len(new)
oldmap=[indices[trim(a),trim(b)]for a,b,z,j,k in raw]
assert oldmap[0]==0 and set(oldmap)==set(range(len(new)))
for i,(a,b,z,j,k)in enumerate(raw):
 assert z==0 and new[oldmap[i]]==(trim(a),trim(b),0,oldmap[j],oldmap[k])
# Validate local normalized obligations independently of quotient discovery/order.
branches=0

def branch(a,b,j,cert):
 global branches
 x=g.seg(T1,a);y=g.seg(T2,b);assert x is not None and y is not None
 xs,p=x;ys,q=y
 assert collections.Counter(xs)==collections.Counter(ys)
 assert (trim(p),trim(q))==cert[j][:2]
 branches+=1
branch((),(),0,new);halt=dec=0
for a,b,z,j,k in new:
 (x,r),p=T1.tsite(a);(y,s),q=T2.tsite(b)
 # Both tree observations consume full leaf paths before arithmetic.
 assert trim(p)==a and trim(q)==b
 if x==y=='EHalt':halt+=1;assert j==k==0
 else:
  assert x==y=='EDecnz'and r==s
  branch(g.inc_path(p),g.inc_path(q),j,new);branch(g.brk(1,p),g.brk(1,q),k,new);dec+=1
assert (dec,halt,branches)==(1425,1,2851)
# Negative controls exercise the successor consistency/zero-offset obligations.
controls=[]
def rejects(name,fn):
 try:fn()
 except (AssertionError,IndexError):controls.append({'name':name,'rejected':True})
 else:raise AssertionError('accepted '+name)
bad=[list(e)for e in raw];bad[0][2]=1;rejects('nonzero_offset',lambda:producer.trailing_false_quotient(bad))
bad=[list(e)for e in raw];bad[0][3]=len(raw);rejects('out_of_range_successor',lambda:producer.trailing_false_quotient(bad))
seen={};duplicate=next(i for i,q in enumerate(oldmap)if q in seen or not seen.setdefault(q,i+1))
bad=[list(e)for e in raw];oldtarget=oldmap[bad[duplicate][3]];bad[duplicate][3]=next(i for i,q in enumerate(oldmap)if q!=oldtarget)
rejects('inconsistent_merged_successors',lambda:producer.trailing_false_quotient(bad))
rejects('wrong_root_branch_target',lambda:branch((),(),1,new))
# Parse the generated decimal leaves rather than trusting producer return data.
data=(W/L/'KSource215Data.lean').read_text()
rendered=[(a,b,int(j),int(k))for a,b,j,k in re.findall(r'\.leaf \((\d+), (\d+), (\d+), (\d+)\)',data)]
assert rendered==[(a,b,j,k)for a,b,j,k in wire]
chunks=[]
for i in range(16):
 m=re.search(r'^def fwd'+str(i)+r' : CTree :=\n(.*?)(?=\ndef |\nabbrev )',data,re.M|re.S);assert m
 n=len(re.findall(r'\.leaf \(',m[1]));assert n==(len(new)*(i+1)//16-len(new)*i//16)
 chunks.append(n)
assert sum(chunks)==1426
# Declaration comparison ignores comments only, never proof or type tokens.
def without_comments(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s.startswith('/-',i):depth+=1;i+=2
  elif depth and s.startswith('-/',i):depth-=1;i+=2
  elif depth:i+=1
  elif s.startswith('--',i):
   j=s.find('\n',i);i=len(s)if j<0 else j
  else:out.append(s[i]);i+=1
 assert not depth;return ''.join(out)
def decls(s):
 s=without_comments(s);ms=list(re.finditer(r'^(def|abbrev|theorem) ([\w\']+)(?=[\s:(])',s,re.M));out={}
 for i,m in enumerate(ms):
  stop=ms[i+1].start()if i+1<len(ms)else len(s)
  value=re.split(r'^end |^#print',s[m.start():stop],flags=re.M)[0].strip()
  assert m[2]not in out;out[m[2]]=value
 return out
old={};fresh={}
for d,base in [(old,O/'baseline'/L),(fresh,W/L)]:
 for p in sorted(base.glob('KSource215*.lean')):
  for k,v in decls(p.read_text()).items():assert k not in d;d[k]=v
assert old.keys()==fresh.keys()
changed=[k for k in old if old[k]!=fresh[k]]
expected={*(f'fwd{i}'for i in range(16)),'fwdCert','fwdF','fwd_start',"fwd_start'","fwd_all'",'p215_halts_iff'}
assert set(changed)==expected,(changed,expected)
headers={k:old[k].split(':=',1)[0].strip()==fresh[k].split(':=',1)[0].strip()for k in old}
assert {k for k,v in headers.items()if not v}=={'fwd_start',"fwd_start'","fwd_all'"}
program=decls((W/L/'KSource215Program.lean').read_text());assert list(program)==['p215Nodes','p215','t215','t215_eq']
for k,v in program.items():assert v==old[k]
assert re.findall(r'^import (\S+)',(W/L/'KSource215Program.lean').read_text(),re.M)==['BusyBeaver.ZFC.RMBisim']
stable=[{'name':k,'bytes':len(v.encode()),'sha256':sha(v.encode())}for k,v in program.items()]
# The machine-facing site theorem declarations and facade remain byte-exact.
sites=[]
for p in sorted((W/L).glob('KSites215*.lean')):
 prior=O/'baseline'/L/p.name;assert decls(p.read_text())==decls(prior.read_text())
 sites.append({'file':p.name,'declarations':len(decls(p.read_text())),'leaf_counts':list(map(int,re.findall(r'/-- (\d+) leaves\. -/',p.read_text())))})
assert len(sites)==10 and sum(sum(x['leaf_counts'])for x in sites)==4751
assert sum(x['declarations']for x in sites)==107
assert sum(1 for p in(W/L).glob('KSource215FwdCheck*.lean')if p.read_bytes()==(O/'baseline'/L/p.name).read_bytes())==16
# Dynamic import closure resolves candidate modules first; no inherited graph patching.
inv=json.loads(Path('/tmp/k215-proof-phase5/lean-run1/inventory.json').read_text())
roots=sorted({Path(r['source']).parents[len(r['module'].split('.'))-1] for r in inv['modules']})
def source(m):
 rel=Path(*m.split('.')).with_suffix('.lean')
 candidate=W/'Computability/BusyBeaver/Lean'/rel
 if candidate.is_file():return candidate
 found=[r/rel for r in roots if(r/rel).is_file()];assert len(found)==1,(m,found);return found[0]
graph={};order=[]
def visit(m):
 if m in graph:return
 p=source(m);all_imp=re.findall(r'^import (\S+)',p.read_text(),re.M)
 imp=[d for d in all_imp if d not in inv['external_imports']];graph[m]=imp
 for d in imp:visit(d)
 order.append(m)
inv=json.loads(Path('/tmp/k215-proof-phase5/lean-run1/inventory.json').read_text());target=inv['target'];visit(target)
oldset={r['module']for r in inv['modules']};assert len(order)==186 and oldset<=set(order)
assert set(order)-oldset=={'BusyBeaver.ZFC.RMNormalizedBisim','BusyBeaver.ZFC.KSource215Program'}
def closure(m):
 out=set()
 def v(k):
  if k in out:return
  out.add(k)
  for d in graph[k]:v(d)
 v(m);return out
sc=closure('BusyBeaver.ZFC.KSites215Batch000');assert len(sc)==14
assert not any(m.startswith('BusyBeaver.ZFC.KSource215')and not m.endswith('Program')for m in sc)
assert 'BusyBeaver.ZFC.RMNormalizedBisim'not in sc
ledger=[{'module':m,'source':str(source(m)),'source_sha256':sha(source(m).read_bytes()),'imports':graph[m]}for m in order]
(O/'proposed-inventory.json').write_text(json.dumps({'target':target,'modules':ledger,'external_imports':inv['external_imports']},indent=2)+'\n')
comparison={'status':'PASS_STRUCTURAL_FINITE_ONLY','old_entries':len(raw),'normalized_entries':len(new),'merged_entries':len(raw)-len(new),'root_index':oldmap[0],'both_successors_class_consistent':True,'all_class_members_checked':len(raw),'exact_supplied_entries_match':True,'supplied_certificate_sha256':sha(claimpath.read_bytes()),'local_obligations':{'decrement_entries':dec,'halt_entries':halt,'branch_checks':2851,'consumed_paths_used_before_arithmetic':True},'negative_controls':controls,'chunks':chunks,'literal_program_moved':stable,'source_declarations':len(old),'changed_declaration_bodies':changed,'changed_declaration_headers':[k for k,v in headers.items()if not v],'unchanged_public_endpoint_header':headers['p215_halts_iff'],'site_files':sites,'unchanged_check_modules':16,'primary_modules':len(order),'site_batch_closure':len(sc),'site_closure_modules':sorted(sc),'compiler_executed':False,'canonical_mutation':False}
(O/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
(O/'old-to-normalized.json').write_text(json.dumps(oldmap,separators=(',',':'))+'\n')
(O/'normalized-entries.json').write_text(json.dumps(wire,separators=(',',':'))+'\n')
for p in sorted((W/L).glob('*.lean')):
 prior=O/'baseline'/L/p.name
 if prior.is_file()and prior.read_bytes()!=p.read_bytes():
  (O/'diffs').mkdir(exist_ok=True)
  (O/'diffs'/(p.name+'.diff')).write_text(''.join(difflib.unified_diff(prior.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='baseline/'+p.name,tofile='candidate/'+p.name)))
print(json.dumps({k:v for k,v in comparison.items()if k not in ['site_files','site_closure_modules','literal_program_moved','negative_controls','changed_declaration_bodies']},indent=2))
