from pathlib import Path
import json,hashlib,ast,re
S=Path('/tmp/k215-phase15-retry');R=Path('/tmp/k215-phase15-check');P=Path.cwd();O=Path('/tmp/k215-phase15-retry-peer')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
f=read(S/'freeze.json');assert sha(S/'freeze.json')=='a23392c7d00a657a7e2da7caae40cf752c4f3ec02bd574ab6331b7ce9d47bf73'
for n,h in f['files'].items():assert sha(S/n)==h,n
for n,h in f['external_inputs'].items():assert sha(n)==h,n
old=R/'primary-run1';done=read(old/'completed.json');rows=read(old/'inventory.json')['modules'];before=read(old/'before.json');newrows=read(S/'plan1/primary-inventory.json')['modules'];nr={r['module']:r for r in newrows};orr={r['module']:r for r in rows}
assert len(rows)==len(newrows)==194 and len(done)==87 and list(done)==[r['module']for r in rows][:87]
assert rows[87]['module']=='BusyBeaver.ZFC.KQ1ZF' and 'BusyBeaver.ZFC.KDenseBridge'not in done and not(old/'result.json').exists()
for n,h in before['inputs'].items():assert sha(n)==h,n
for n in before['absent_inputs']:assert not Path(n).exists()and not Path(n).is_symlink(),n
for m,r in done.items():
 assert nr[m]==orr[m]
 assert r['status']=='PASS'and r.get('exit_code',0)==0 and not r.get('timed_out',False)
 assert r['source_sha256']==nr[m]['source_sha256']==sha(nr[m]['source'])
 assert r['dependencies']=={d:done[d]['object_sha256']for d in nr[m]['imports']if d!='Init'}
 assert sha(old/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']
 assert sha(r['log'])==r['log_sha256'];t=Path(r['log']).read_text();assert 'error:'not in t and 'sorryAx'not in t
 if r['origin']=='candidate_fresh':assert sha(r['source'])==r['source_sha256']
assert sum(r['origin']=='candidate_fresh'for r in done.values())==19
assert sum(r['origin']=='phase14_primary_checked'for r in done.values())==68
fail=read(old/'attempts/020-BusyBeaver.ZFC.KQ1ZF/record.json');assert fail['status']=='FAIL'and fail['exit_code']!=0
assert 'sorryAx'in Path(fail['log']).read_text() and sha(fail['log'])==fail['log_sha256']
assert read('/tmp/k215-phase15-execution/primary-run1-outer.json')['exit_code']==1
assert (S/'candidate/BusyBeaver/ZFC/KQ1ZF.lean').read_bytes()==b'import FirstOrder.Completeness\n'+(P/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/KQ1ZF.lean').read_bytes()
assert sha(S/'candidate/BusyBeaver/ZFC/KDenseBridge.lean')=='ce03e85f85fd726ed241e56718efa0920e00a5b6d324ce271ddede731146b16e'
assert (S/'compatibility-template.json').read_bytes()==(R/'compatibility-template.json').read_bytes()
oldmap=read(R/'primary-map.json');newmap=read(S/'primary-map.json');a={x['module']:x for x in oldmap['modules']};b={x['module']:x for x in newmap['modules']};assert set(b)-set(a)=={'BusyBeaver.ZFC.KQ1ZF'}
assert {m for m in a if a[m]!=b[m]}=={'BusyBeaver.ZFC.KDenseBridge'}
assert set(oldmap['expected']['modules'])==set(newmap['expected']['modules']) and oldmap['expected']['forced']==newmap['expected']['forced']
assert set(newmap['expected']['changed'])-set(oldmap['expected']['changed'])=={'BusyBeaver.ZFC.KQ1ZF'}
assert sorted(set(newmap['expected']['forced'])-set(done)) and len(set(newmap['expected']['forced'])-set(done))==26
assert sha(R/'build.py')=='198b075493d80cf554f5755a37ccfbc5afb90fcfa498b900d805f13312e458ec'
tree=ast.parse((R/'build.py').read_text());idx=next(i for i,n in enumerate(tree.body)if isinstance(n,ast.For)and isinstance(n.target,ast.Name)and n.target.id=='row'and isinstance(n.iter,ast.Name)and n.iter.id=='rows');prefix=ast.Module(body=tree.body[:idx],type_ignores=[])
assert not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='run_locked'for n in ast.walk(prefix))
assert any(isinstance(n,ast.FunctionDef)and n.name=='log_policy'for n in prefix.body)
# Read-only source lexical checks bind the two safe operations rather than executing initialization.
init=(S/'initialize.py').read_text();assert 'assert current[m]==prior[m]'in init and 'assert not parent.is_symlink()'in init and "target.symlink_to(source)"in init
result={'status':'PASS_INDEPENDENT_RETRY_SOURCE_AND_PARTIAL_ACTUAL_PEER','retry_freeze_sha256':sha(S/'freeze.json'),'unchanged_runner_sha256':sha(R/'build.py'),'initializer_sha256':sha(S/'initialize.py'),'primary_map_sha256':sha(S/'primary-map.json'),'finalizer_sha256':sha(S/'finalize_compatibility.py'),'own_frozen_files_checked':len(f['files']),'external_pins_checked':len(f['external_inputs']),'old_input_pins_rechecked':len(before['inputs']),'exact_validated_prefix':87,'successful_original_fresh':19,'original_phase14_reuse':68,'original_failed_module':'BusyBeaver.ZFC.KQ1ZF','original_outer_exit_code':1,'original_failed_record_excluded':True,'additional_fresh_calls_required':26,'additional_endpoint_audits_required':2,'planned_final_selected_fresh_records':45,'planned_final_phase14_reuses':149,'source_changes':['Only explicit FirstOrder.Completeness import in handwritten KQ1ZF','Exact source-reviewed Source193 KDenseBridge ce03 replacement, outside completed prefix'],'compatibility_template_literal_unchanged':True,'findings':[],'scope':'Complete initializer and finalizer read; exact source-map changes and frozen inputs checked; independently rehashed87 successful partial-run sources/snapshots/objects/logs/dependencies and all original before-inputs. AST metadata-prefix boundary inspected but not executed. No compiler/initializer/producer execution, no final primary PASS or adoption claim.','checker_sha256':sha(__file__)}
(O/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));print('RECEIPT_SHA256',sha(O/'review.json'))
