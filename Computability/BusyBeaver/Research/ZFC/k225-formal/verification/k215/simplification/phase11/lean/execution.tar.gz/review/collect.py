"""Capture terminal phase11 records without running compilers or producers."""
from pathlib import Path
import argparse,fcntl,gzip,io,json,tarfile
import basis,packet
S=Path(__file__).resolve().parent;R=Path(packet.ROOT)
read=lambda p:json.loads(Path(p).read_text())
def collect(repo,out):
 assert not out.exists() and not out.is_symlink()
 loaded=basis.load(repo);prior,_,_=loaded;members={};routes={};hashes={}
 for key,data in prior.items():hashes.setdefault(packet.digest(data),('phase10',key))
 def put(name,data):
  packet.safe(name)
  if name in members:assert members[name]==data
  members[name]=data;hashes.setdefault(packet.digest(data),('packet',name))
 def add(path,data=None,name=None,force=False):
  path=str(path);data=Path(path).read_bytes()if data is None else data;pin=packet.digest(data)
  if path in routes:
   assert routes[path]['sha256']==pin;return
  if force or pin not in hashes:
   key=name or'inputs/'+pin+'/'+Path(path).name;put(key,data);storage='packet'
  else:storage,key=hashes[pin]
  routes[path]={'storage':storage,'key':key,'sha256':pin,'bytes':len(data)}
 boundary=read(packet.BOUNDARY);historical={r['canonical']:r for r in boundary['files']};assert len(historical)==5
 for row in historical.values():
  for key in ['phase8_snapshot','historical_original','phase10_snapshot']:add(row[key])
  data=Path(row['phase10_snapshot']).read_bytes();assert packet.digest(data)==row['phase10_sha256']
  add(row['canonical'],data)
 tool=read(Path(packet.RUN)/'toolchain.json');toolbins={x['path']for x in tool.values()if isinstance(x,dict)and'path'in x and(x['path'].endswith('/bin/lean')or x['path'].endswith('/bin/lake')or x['path'].endswith('.olean'))}
 for root,label in [(Path(packet.RUN),'execution'),(Path(packet.ISO),'isolated')]:
  with(root/'output.lock').open('a')as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  result=read(root/'result.json');assert result['status']=='PASS'
  for name in ['result.json','before.json','inventory.json','completed.json','toolchain.json']:add(root/name,name=label+'/'+name,force=True)
  inv=read(root/'inventory.json');done=read(root/'completed.json');before=read(root/'before.json')
  for path,pin in before['inputs'].items():
   if path in toolbins or set(Path(path).suffixes)&packet.BINARY:continue
   if path not in historical:add(path)
   assert routes[path]['sha256']==pin
  for row in inv['modules']:
   m=row['module'];rec=done[m];add(row['source']);add(rec['log'])
   if rec['origin']=='candidate_fresh':
    add(rec['source'],name=label+'/fresh/'+m+'/source.lean',force=True)
    add(Path(rec['log']).parent/'record.json',name=label+'/fresh/'+m+'/record.json',force=True)
  for audit in result['audits']:
   q=root/('audit-'+audit['module'])
   for name in [audit['module']+'.lean',audit['module']+'.log',audit['module']+'.json']:add(q/name,name=label+'/audits/'+name,force=True)
   add(audit['source'])
 # Explicit owner handoff, original reader failure, reviewed producer provenance.
 handoff=Path('/tmp/k215-generic-cd58-check/handoff.json');context=[handoff]
 for row in read(handoff)['files']:
  p=Path(row['path']);assert packet.sha(p)==row['sha256']and p.stat().st_size==row['bytes'];context.append(p)
 context.extend(Path('/tmp/k215-generic-cd58-check/history/isolated-review-v1').iterdir())
 for directory in ['/tmp/k215-generic-cd58-driver-peer','/tmp/k215-phase11-inline-peer','/tmp/k215-phase11-adoption-peer']:
  context.extend(p for p in Path(directory).iterdir()if p.is_file())
 producer=Path('/tmp/k215-phase11-producer');freeze=read(producer/'freeze.json');context.append(producer/'freeze.json')
 for name,row in freeze['files'].items():
  p=producer/name;assert packet.sha(p)==row['sha256']and p.stat().st_size==row['bytes'];context.append(p)
 context.extend(Path('/tmp/k215-phase11-inline').glob('*'))
 for name in ['producer-execution.json','adoption.json','generate.stdout.json','generate.stderr.txt','check.stdout.json','check.stderr.txt','maintained-check.json','maintained-check.stdout.json','maintained-check.stderr.txt','canonical-review.json','canonical_review.py','canonical-review-outer.json','source-metrics.json']:
  p=Path('/tmp/k215-phase11-main')/name;assert p.is_file();context.append(p)
 context.extend(p for p in (S/'history').rglob('*')if p.is_file())
 context.append(S/'helper-correction.json')
 context.extend(S/name for name in ['controls.py','controls.json','controls.stdout.txt','controls.stderr.txt','freeze.json'])
 for p in sorted(set(context)):
  if p.is_file():add(p,name='context/'+str(p).lstrip('/'))
 adoption=read(packet.ADOPTION)
 for row in adoption['files']:
  data=Path(row['source']).read_bytes();assert packet.digest(data)==row['sha256']and data==(R/row['target']).read_bytes()
  add(row['source'],data);put('adoption/'+row['target'],data)
 for row in adoption['tombstones']:add(row['archived_before'])
 for name in ['basis.py','basis-reference.json','packet.py','review_saved.py','collect.py','README.md']:put('review/'+name,(S/name).read_bytes())
 put('path-map.json',packet.dump(routes))
 checked=packet.validate(members,repo,loaded,current_repo=repo)
 # Historical producer inputs resolve to exact saved phase10 bytes, not later writes/deletions.
 for root in [Path(packet.RUN),Path(packet.ISO)]:
  before=read(root/'before.json');done=read(root/'completed.json');inv=read(root/'inventory.json')
  for p,pin in before['inputs'].items():assert packet.sha(historical[p]['phase10_snapshot']if p in historical else p)==pin
  for row in inv['modules']:
   rec=done[row['module']];assert packet.sha(row['source'])==row['source_sha256'];assert packet.sha(rec['log'])==rec['log_sha256'];assert packet.sha(root/'objects'/(row['module'].replace('.','/')+'.olean'))==rec['object_sha256']
  for rec in read(root/'result.json')['audits']:
   assert packet.sha(root/('audit-'+rec['module'])/(rec['module']+'.olean'))==rec['object_sha256'];assert packet.sha(rec['log'])==rec['log_sha256']
 changes=[p for p,r in historical.items()if not Path(p).is_file()or packet.sha(p)!=r['phase10_sha256']]
 assert set(changes)=={str(R/r['target'])for r in adoption['tombstones']}|{str(R/packet.PRODUCER_ROOT/'generate_dominated_implication_lean.py')}
 post={'status':'PASS_LIVE_POSTCHECK','main_modules':197,'isolated_modules':16,'audit_objects':2,'all_live_sources_objects_logs_rehashed':True,'all_nonproducer_inputs_current_exact':True,'phase10_producer_snapshot_pins_exact':True,'producer_canonical_changes':changes,'current_writes':2,'current_absent_templates':2,'scope':'Original raw before inputs retained; the five historical producer inputs resolve to pinned snapshots. Two current replacements and two template retirements checked separately.'}
 put('review/live-postcheck.json',packet.dump(post));index=packet.manifest(members)
 out.mkdir(parents=True)
 with(out/'execution.tar.gz').open('wb')as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as zipped:
   with tarfile.open(fileobj=zipped,mode='w')as archive:
    for name,data in sorted(members.items()):
     info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
 (out/'index.json').write_bytes(packet.dump(index))
 summary={**checked,'status':'PASS_COLLECTED_PHASE11','archive_sha256':packet.sha(out/'execution.tar.gz'),'archive_members':len(members),'index_sha256':packet.sha(out/'index.json'),'live_postcheck':post}
 (out/'result.json').write_bytes(packet.dump(summary))
 for name in ['basis.py','basis-reference.json','packet.py','review_saved.py','README.md']:(out/name).write_bytes((S/name).read_bytes())
 print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--basis-repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();collect(a.basis_repo,a.out)
