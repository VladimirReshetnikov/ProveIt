"""Bounded proof-production search; all output remains untrusted certificate data."""
from pathlib import Path
import argparse,copy,hashlib,json,time

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=float,default=28);a=p.parse_args()
out=a.output;out.mkdir(parents=True,exist_ok=False)
source=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Research/ZFC/k225-formal/lean217/dominated_rho8_full_certificate.json')
d=json.loads(source.read_text());T=d['term_table'];N=d['nodes'];start=time.monotonic();deadline=start+a.seconds
assert all(n['id']==i for i,n in enumerate(N))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sizes=[]
for i,t in enumerate(T):
 if isinstance(t,list):assert all(0<=c<i for c in t)
 sizes.append(1+sum(sizes[c] for c in t) if isinstance(t,list) else 1)

def match(p,t,e,seen):
 if (p,t) in seen:return True
 seen.add((p,t));x,y=T[p],T[t]
 if isinstance(x,dict):return e.setdefault(str(x['var']),t)==t
 if x=='T':return y=='T'
 return isinstance(y,list) and match(x[0],y[0],e,seen) and match(x[1],y[1],e,seen)

def parents(r):return tuple(r[k] for k in ('major','minor','parent') if k in r)
def closure(rules,root=len(N)-1):
 seen=0; todo=[root]
 while todo:
  i=todo.pop()
  if seen>>i&1:continue
  seen|=1<<i;todo.extend(parents(rules[i]))
 return seen
def ids(bits):
 while bits:
  b=bits&-bits;yield b.bit_length()-1;bits-=b
def metrics(rules):
 bits=closure(rules);ns=list(ids(bits));return {'nodes':len(ns),'instructions':sum(3 if rules[i]['kind']=='mp_substitution' else 1 for i in ns)}

# Reconstruct the accepted first-match policy independently from the original.
patterns=[];baseline=[];options=[];checks=0;matches=0
for i,n in enumerate(N):
 original=copy.deepcopy(n['rule']);assert all(j<i for j in parents(original))
 opts=[original];first=None
 for j in patterns:
  if sizes[N[j]['term']]>sizes[n['term']]:continue
  e={}
  if match(N[j]['term'],n['term'],e,set()):
   r={'kind':'substitution','parent':j,'substitution':e};opts.append(r)
   if first is None:first=r
 if first is None:patterns.append(i)
 baseline.append(first or original);options.append(opts)
checks_initial=time.monotonic()-start
assert metrics(baseline)=={'nodes':674,'instructions':780}
best_rules=copy.deepcopy(baseline);best=metrics(best_rules);history=[{'policy':'accepted-first-match','seconds':time.monotonic()-start,**best}]

def keep(rules,label):
 global best,best_rules
 m=metrics(rules);history.append({'policy':label,'seconds':time.monotonic()-start,**m})
 if (m['nodes'],m['instructions'])<(best['nodes'],best['instructions']):
  best=m;best_rules=copy.deepcopy(rules)

def greedy(weighted=False,preferred=0):
 rules=[];closed=[];costmask=0
 for i,opts in enumerate(options):
  winner=None
  for rank,r in enumerate(opts):
   bits=1<<i
   for j in parents(r):bits|=closed[j]
   costly=costmask|(1<<i if r['kind']=='mp_substitution' else 0)
   score=bits.bit_count()+(2*(bits&costly).bit_count() if weighted else 0)
   # Sharing-biased passes charge existing target dependencies less.
   if preferred:score=4*score-3*(bits&preferred).bit_count()
   key=(score,bits.bit_count(),rank)
   if winner is None or key<winner[0]:winner=(key,r,bits)
  _,r,bits=winner;rules.append(r);closed.append(bits)
  if r['kind']=='mp_substitution':costmask|=1<<i
 return rules

for weighted in (False,True):keep(greedy(weighted),f'all-baseline-patterns-local-{weighted}')
for k in range(3):keep(greedy(False,closure(best_rules)),f'preferred-closure-{k}')

# Add exact instances of every earlier theorem, not only the baseline's schemas.
# The elapsed limit can interrupt this expansion without losing a valid result.
patterns_set=set(patterns);complete=True;last_i=-1
for i,n in enumerate(N):
 if time.monotonic()>deadline-5:complete=False;break
 for j in range(i):
  if j in patterns_set or sizes[N[j]['term']]>sizes[n['term']]:continue
  checks+=1;e={}
  if match(N[j]['term'],n['term'],e,set()):
   options[i].append({'kind':'substitution','parent':j,'substitution':e});matches+=1
 last_i=i
for weighted in (False,True):keep(greedy(weighted),f'all-expanded-parents-local-{weighted}')
for k in range(3):keep(greedy(False,closure(best_rules)),f'all-expanded-preferred-{k}')

# Try local rule replacements measured on the complete retained graph. The
# original rules are candidates too, even where the first-match policy rewrote.
swaps=0;passes=0
while time.monotonic()<deadline-1:
 changed=False;passes+=1
 for i in sorted(ids(closure(best_rules)),reverse=True):
  if time.monotonic()>deadline-1:break
  current=best_rules[i]
  for r in options[i]:
   if r==current:continue
   best_rules[i]=r;m=metrics(best_rules)
   if (m['nodes'],m['instructions'])<(best['nodes'],best['instructions']):
    best=m;current=r;changed=True;swaps+=1
   else:best_rules[i]=current
  best_rules[i]=current
 if not changed:break
history.append({'policy':'global-coordinate-descent','seconds':time.monotonic()-start,**best})

# Validate every selected new substitution afresh and emit a standalone term DAG.
used=list(ids(closure(best_rules)));node_map={v:i for i,v in enumerate(used)}
used_terms=set()
def visit(t):
 if t in used_terms:return
 used_terms.add(t)
 if isinstance(T[t],list):
  for c in T[t]:visit(c)
for i in used:
 r=best_rules[i];assert all(j<i and j in node_map for j in parents(r))
 if r['kind']=='substitution' and r!=N[i]['rule']:
  e={};assert match(N[r['parent']]['term'],N[i]['term'],e,set()) and e==r['substitution']
 visit(N[i]['term'])
 for key in ('substitution','major_substitution','minor_substitution'):
  for t in r.get(key,{}).values():visit(t)
for i,t in enumerate(T):
 if t=='T' or isinstance(t,dict):visit(i)
term_map={v:i for i,v in enumerate(sorted(used_terms))};new=[]
for i in used:
 r=copy.deepcopy(best_rules[i])
 for key in ('major','minor','parent'):
  if key in r:r[key]=node_map[r[key]]
 for key in ('substitution','major_substitution','minor_substitution'):
  if key in r:r[key]={v:term_map[t] for v,t in r[key].items()}
 new.append({'id':node_map[i],'term':term_map[N[i]['term']],'rule':r,'origin':i})
cert=copy.deepcopy(d);cert['nodes']=new;cert['term_table']=[[term_map[c] for c in T[t]] if isinstance(T[t],list) else T[t] for t in sorted(used_terms)];cert['roots']={k:node_map[v] for k,v in d['roots'].items() if v in node_map};cert['sources']={'original':str(source),'sha256':sha(source),'scope':'Untrusted bounded alternative-rule proof production; no kernel check.'}
path=out/'certificate.json';path.write_text(json.dumps(cert,separators=(',',':'))+'\n')
result={'status':'UNTRUSTED_PROOF_CANDIDATE','seconds':time.monotonic()-start,'limit_seconds':a.seconds,'initial_all_pattern_seconds':checks_initial,'original_sha256':sha(source),'source_sha256':sha(Path(__file__)),'candidate_sha256':sha(path),'candidate':str(path),'best':best,'input_terms':len(used_terms),'history':history,'all_earlier_expansion_complete':complete,'last_expanded_node':last_i,'additional_match_tests':checks,'additional_matches':matches,'coordinate_passes':passes,'coordinate_improvements':swaps,'acyclic_and_exact_substitution_rechecked':True,'node_map':node_map}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['node_map','history']},indent=2));print(json.dumps(history,indent=2))
