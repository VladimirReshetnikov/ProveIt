# Phase8 legacy compatibility preparation

This driver is prepared after phase8 primary PASS and the independent root byte review. It uses 188 primary providers and the same 15 legacy-only modules, for a 203-module private symlink overlay. It makes no full fresh 203-module build claim. No compiler has run in this packet.

The source registration adds only DominatedImplication and changes DomRho8, KSeed222 and KSeedModel222. The legacy graph can invalidate only EnumDom, L2AxiomsDom and L2RootDom; direct dependency-object hashes decide actual reuse. The read-only terminal plan confirms all 15 are currently reusable. The unchanged five-client LegacyAudit is always recompiled, now with 46 transitive providers because it imports the generic core through DomRho8.

The reviewed a3cf7cc3 supervisor serializes each compiler under /tmp/proveit-k215-proof-build.lock, cleans the child process group before unlocking, uses one worker and 12GiB, and caps module jobs at 900s and the audit at 120s. Existing providers are read-only symlinks. A refresh must unlink its target before writing. All selected sources, direct imports, object hashes, saved logs, compiler/toolchain files, immutable predecessors and copied audit source are rechecked after the audit. Only the five exact qualified report names and standard Lean axioms are accepted.

Source-only preparation checked both the complete previous 202-provider set and the current 188-provider set. Six positive and 24 negative metadata controls passed. A first control-script quoting error failed before any controls ran and is preserved in history/controls-syntax. The original phase7 driver/gates and pre-primary-gate preparation remain in history. No proof source was edited.

Root may execute after its final source peer using:

```sh
python3 /tmp/k215-phase8-legacy/build.py --primary-run /tmp/k215-proof-phase8/lean-run1 --primary-live /tmp/k215-proof-phase8/root-actual-review.json --out /tmp/k215-phase8-legacy/run1 --execute-after-primary-pass
```

Use a new output directory; failed attempts are immutable. The driver refuses missing or changed terminal primary/root-review pins and requires its exact frozen metadata. This packet is preparation, not an actual legacy compilation receipt.
