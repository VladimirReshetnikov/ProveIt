"""Pure metadata controls; no collector, archive code, compiler or producer runs."""
from pathlib import Path
import copy,json,re,tempfile
import packet
checks=[]
def check(name,fn,accept):
 try:fn();actual=True
 except (AssertionError,KeyError):actual=False
 assert actual==accept,(name,actual,accept);checks.append({'name':name,'expected_accept':accept,'matched':True})
for n in ['context/source.lean','review/record.json']:check('safe '+n,lambda n=n:packet.safe(n),True)
for n in ['/absolute','../escape','a/../../escape','x.olean','x.olean.server','x.olean.private','x.ilean','x.vo','x.pyc','x.pyo','x.tar.gz','x.zip','x.so']:
 check('forbidden '+n,lambda n=n:packet.safe(n),False)
def route(change=None):
 data=b'payload';r={'/absolute/source':{'storage':'packet','key':'data','sha256':packet.digest(data),'bytes':len(data)}}
 if change:change(r['/absolute/source'])
 packet.resolve_routes({'data':data},{'data':data},r)
check('packet path alias',lambda:route(),True)
check('phase11 path alias',lambda:route(lambda r:r.update(storage='phase11')),True)
check('unknown predecessor rejected',lambda:route(lambda r:r.update(storage='phase10')),False)
check('wrong alias bytes hash',lambda:route(lambda r:r.update(sha256='0'*64)),False)
check('wrong alias bytes length',lambda:route(lambda r:r.update(bytes=0)),False)
def ancestry(change=None):
 a={'A':{'source_sha256':'a','imports':['Init']},'B':{'source_sha256':'b','imports':['A']}};b=copy.deepcopy(a)
 if change:change(a,b)
 packet.same_source_closure(a,b,{'A','B'})
check('exact source import ancestry',lambda:ancestry(),True)
check('changed ancestor despite equal object',lambda:ancestry(lambda a,b:a['A'].update(source_sha256='new')),False)
check('changed import ancestry',lambda:ancestry(lambda a,b:a['B'].update(imports=['Init'])),False)
base={'source_sha256':'a','object_sha256':'b','dependencies':{'Parent':'c'},'log_sha256':'d','status':'PASS','origin':'old'}
check('exact old record except origin',lambda:packet.exact_reuse({**base,'origin':'phase11_checked'},base,'phase11_checked'),True)
for key in ['source_sha256','object_sha256','dependencies','log_sha256','status']:
 check('changed reuse '+key,lambda key=key:packet.exact_reuse({**base,'origin':'phase11_checked',key:'changed'},base,'phase11_checked'),False)
def reports(b):
 text=b.decode();assert not any(x in text for x in ['error:','sorryAx']);result=re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text)
 assert all({a.strip()for a in ax.split(',')if a.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in result);return result
check('literal standard report',lambda:packet.named_reports(b"'Exact.client' depends on axioms: [propext, Quot.sound]",['Exact.client'],reports),True)
check('wrong report namespace',lambda:packet.named_reports(b"'Wrong.client' depends on axioms: [propext]",['Exact.client'],reports),False)
check('custom report axiom',lambda:packet.named_reports(b"'Exact.client' depends on axioms: [Custom]",['Exact.client'],reports),False)
check('client warning rejected',lambda:packet.named_reports(b"warning: x\n'Exact.client' depends on axioms: [propext]",['Exact.client'],reports),False)
with tempfile.TemporaryDirectory(prefix='phase12-absence-control-')as d:
 p=Path(d)/'gone';check('absent template',lambda:packet.absent(p),True);p.symlink_to(Path(d)/'missing');check('dangling link is not absent',lambda:packet.absent(p),False)
def assertion(v):assert v
check('explicit Init boundary',lambda:assertion(packet.explicit_externals([{'module':'A','imports':['Init']}])==['Init']),True)
check('empty explicit boundary',lambda:assertion(packet.explicit_externals([{'module':'A','imports':[]}])==[]),True)
check('wrong claimed explicit Init',lambda:assertion(packet.explicit_externals([{'module':'A','imports':[]}])==['Init']),False)
check('unknown explicit external',lambda:packet.explicit_externals([{'module':'A','imports':['OtherLibrary']}]),False)
result={'status':'PASS_METADATA_ONLY','positive':sum(r['expected_accept']for r in checks),'negative':sum(not r['expected_accept']for r in checks),'checks':checks,'compiler_or_collector_invoked':False,'inputs':{str(p):packet.sha(p)for p in [Path(__file__),Path(packet.__file__)]}}
Path(__file__).with_name('controls-result.json').write_bytes(packet.dump(result));print(json.dumps(result,indent=2))
