"""Own inert preparation; reads proposal code only as text/AST and never runs it."""
from pathlib import Path
import json,hashlib,subprocess,difflib,re,ast
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent;L=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC');F=Path('Computability/BusyBeaver/Research/ZFC/k225-formal');A=F/'verification/k215/simplification/proposals/rocq-composition/calculus';sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
paths=[L/'QuotientModel.lean',L/'KQ1Model.lean',F/'generate_kq1.py'];aliases=[A/'QuotientModel.proposed.lean',A/'KQ1Model.proposed.lean',A/'generate_kq1.proposed.py'];rows=[]
for rel,alias in zip(paths,aliases):
 old=(R/rel).read_bytes();new=(R/alias).read_bytes();commit=subprocess.check_output(['git','show','7f3942117f:'+str(rel)],cwd=R);assert new==commit
 put(S/'before'/rel,old);put(S/'upstream'/rel,new)
 put(S/'candidate'/rel,new)
 diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='before/'+str(rel),tofile='candidate/'+str(rel)));put(S/'diffs'/(rel.name+'.diff'),diff.encode())
 rows.append({'path':str(rel),'before_sha256':sha(old),'candidate_sha256':sha(new),'before_bytes':len(old),'after_bytes':len(new),'before_lines':len(old.splitlines()),'after_lines':len(new.splitlines()),'candidate':str(S/'candidate'/rel),'upstream_commit':'7f3942117fb54d6316fa84c501350504ab9e6f55','immutable_existing_alias':str(alias),'imports':re.findall(r'^import (.*)$',new.decode(),re.M)if rel.suffix=='.lean'else[]})
# Reconstruct our maintained adaptation from old bytes plus the two inert insertions.
old=(R/F/'generate_kq1.py').read_text();proposal=(R/A/'generate_kq1.proposed.py').read_text();tree=ast.parse(proposal)
alias_assignment=next(n for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='MODEL_SYNTAX_ALIASES');alias_text=ast.get_source_segment(proposal,alias_assignment);assert isinstance(ast.literal_eval(alias_assignment.value),str)
start=proposal.index('    if f == "Model":');end=proposal.index('    if f == "Basic":',start);block=proposal[start:end]
ours=old.replace('for f in FORKS:\n',alias_text+'\n\nfor f in FORKS:\n',1).replace('    if f == "Basic":',block+'    if f == "Basic":',1);assert ours==proposal
put(S/'candidate'/F/'generate_kq1.py',ours.encode())
# Statement/body comparisons are declaration-local; no Lean elaboration implied.
def decls(t):
 ms=list(re.finditer(r'(?m)^(?:noncomputable )?(def|abbrev|theorem) ([A-Za-z_][A-Za-z_0-9]*)\b',t));return {m.group(2):{'kind':m.group(1),'text':t[m.start():ms[i+1].start()if i+1<len(ms)else t.index('#print axioms',m.start())].strip()}for i,m in enumerate(ms)}
comparisons={}
for rel in paths[:2]:
 old=(R/rel).read_text();new=(S/'candidate'/rel).read_text();od=decls(old);nd=decls(new);assert set(od)==set(nd)
 unchanged=[];changed=[]
 for name in od:
  ob=od[name]['text'].split('/--')[0].strip();nb=nd[name]['text'].split('/--')[0].strip()
  if ob==nb:unchanged.append(name)
  else:changed.append(name)
  if od[name]['kind']=='theorem':assert ob.split(':=')[0]==nb.split(':=')[0],(rel,name)
 expected=['relSat_congr']if rel.name=='QuotientModel.lean'else['memberForm','sat_memberForm','translate','RelSat','sat_translate','equalityFree_translate','relSat_congr']
 assert set(changed)==set(expected),(rel,changed)
 comparisons[str(rel)]={'declarations':len(od),'same_named_declarations':True,'all_theorem_headers_exact':True,'unchanged_bodies':unchanged,'changed':changed}
# All six producer input/output pairs are pinned before any execution, including the historical sources.
inputs={};outputs={}
for stem in ['Model','Separation','Basic','Replacement','Power','CPGIC']:
 rel=L/f'Quotient{stem}.lean';b=(R/rel).read_bytes();put(S/'reproduction-inputs'/rel,b);inputs[str(rel)]=sha(b)
for stem in ['Model','Separation','Basic','Replacement','Power','Collect']:
 rel=L/f'KQ1{stem}.lean';b=(R/rel).read_bytes();put(S/'reproduction-before'/rel,b);outputs[str(rel)]=sha(b)
# Actual import consumers and possible generated-equation callers, current maintained source only.
consumers={};equations=[]
for p in sorted((R/'Computability/BusyBeaver/Lean').rglob('*.lean')):
 t=p.read_text();hits=[]
 for i,line in enumerate(t.splitlines(),1):
  if re.search(r'(?:KQ1Model|QuotientModel)\.(?:memberForm|translate|RelSat|sat_memberForm|sat_translate|equalityFree_translate|relSat_congr)\b',line):hits.append({'line':i,'text':line})
  if re.search(r'(?:KQ1Model\.)?(?:memberForm|translate|RelSat)\.(?:eq_|eq_def|_sunfold|match_)',line):equations.append({'path':str(p.relative_to(R)),'line':i,'text':line})
 if hits:consumers[str(p.relative_to(R))]=hits
summary={'status':'SOURCE_ONLY_CANDIDATES_NOT_EXECUTED_OR_COMPILED','baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'files':rows,'totals':{'before_bytes':sum(r['before_bytes']for r in rows),'after_bytes':sum(r['after_bytes']for r in rows),'before_lines':sum(r['before_lines']for r in rows),'after_lines':sum(r['after_lines']for r in rows)},'comparisons':comparisons,'producer_own_baseline_plus_two_reviewed_insertions_matches_upstream':True,'producer_inputs':inputs,'producer_old_outputs':outputs,'caller_files':consumers,'generated_equation_callers':equations,'scope':'No generator/Lean/compiler executed. Full old/new producer source read. Reproduction and possible pre-existing output drift remain to be measured after root GO.'}
put(S/'review.json',(json.dumps(summary,indent=2)+'\n').encode());print(json.dumps({'files':rows,'totals':summary['totals'],'generated_equation_callers':equations},indent=2))
