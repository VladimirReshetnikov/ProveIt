"""Isolated four-module Lean check; immutable phase7 provider overlay, one worker."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,signal,argparse
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');B=Path('/tmp/k215-proof-phase8/lean-run1')
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
p=argparse.ArgumentParser();p.add_argument('run');a=p.parse_args();out=S/a.run;out.mkdir(exist_ok=False)
assert sha(B/'result.json')=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
old=json.loads((B/'completed.json').read_text());inv=json.loads((B/'inventory.json').read_text());assert len(old)==len(inv['modules'])==188
basis={m:sha(B/'objects'/(m.replace('.','/')+'.olean'))for m in old};assert all(basis[m]==r['object_sha256']for m,r in old.items())
inputs={str(p):sha(p)for p in [B/'completed.json',B/'inventory.json',B/'result.json',B/'toolchain.json',H,C,Path(__file__)]}
for row in inv['modules']:
 assert sha(row['source'])==row['source_sha256'];inputs[row['source']]=row['source_sha256']
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
assert sha(C)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
cache=out/'objects'
for m in old:
 q=cache/(m.replace('.','/')+'.olean');q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(B/'objects'/(m.replace('.','/')+'.olean'))
spec=importlib.util.spec_from_file_location('checked_supervisor',H);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
ns='SetTheory.BusyBeaver.ZFC.'
plans=[
 ('BusyBeaver.ZFC.FramedWindow',S/'candidate/BusyBeaver/ZFC/FramedWindow.lean',[ns+'FramedWindow.arbitrary_tape_at']),
 ('BusyBeaver.ZFC.KZipTape',S/'candidate/BusyBeaver/ZFC/KZipTape.lean',[ns+'KZipTape.'+n for n in ['rel_step','rel_run','run_reflect','rel_full','check_restore','check_restore_pos']]),
]
for _,p,_ in plans:inputs[str(p)]=sha(p)
rows=[];save(out/'before.json',{'inputs':inputs,'basis_objects':basis,'plans':[{'module':m,'source':str(p),'reports':n}for m,p,n in plans],'scope':'Isolated tape-transport foundation; no new complete endpoint build.'})
for module,path,names in plans:
 src=out/'workspace'/(module.replace('.','/')+'.lean');src.parent.mkdir(parents=True,exist_ok=True);src.write_bytes(path.read_bytes())
 obj=cache/(module.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);obj.unlink(missing_ok=True)
 log=out/(module.rsplit('.',1)[-1]+'.log');result=out/(module.rsplit('.',1)[-1]+'.json')
 cmd=[str(C),'-j1','-M12288','--root='+str(out/'workspace'),'-o',str(obj),str(src)]
 row={'module':module,'candidate':str(path),'candidate_sha256':sha(path),'source':str(src),'source_sha256':sha(src),'command':cmd,'timeout_seconds':120,'memory_mebibytes':12288,'compiler_sha256':sha(C),'helper_sha256':sha(H)}
 ok=helper.run_locked(cmd,R,env,LOCK,log,120,row,result)
 text=log.read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
 row.update({'log':str(log),'log_sha256':sha(log),'warnings':text.count('warning:'),'axiom_reports':reports,'object_sha256':sha(obj)if ok else None})
 save(result,row);rows.append(row);print(json.dumps({'module':module,'status':row.get('status'),'warnings':row['warnings'],'reports':len(reports),'wall_seconds':row.get('wall_seconds')}),flush=True)
 assert ok,module
 assert [n for n,_ in reports]==names,(module,reports)
 assert all({s.strip()for s in ax.split(',')if s.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports)
 assert sha(src)==row['source_sha256']
assert all(sha(p)==v for p,v in inputs.items())
assert all(sha(B/'objects'/(m.replace('.','/')+'.olean'))==v for m,v in basis.items())
summary={'status':'PASS','scope':'Isolated framed integer-tape and zipper run bridge; no complete endpoint claim.','rows':rows,'inputs_unchanged':True,'all_188_basis_objects_unchanged':True,'reports':sum(len(x['axiom_reports'])for x in rows),'warnings':sum(x['warnings']for x in rows),'runner_sha256':sha(__file__)};save(out/'summary.json',summary);print(json.dumps({k:v for k,v in summary.items()if k!='rows'},indent=2))
