"""Own publication-source adaptation only; no records captured or proof tools invoked."""
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;OLD=Path('/tmp/k215-phase7-legacy-publication')
h=lambda b:hashlib.sha256(b).hexdigest()
names=['evidence.py','capture.py','review.py','publish.py','review_saved.py','README.template.md']
(P/'predecessor-helpers.json').write_text(json.dumps({n:{'path':str(OLD/n),'sha256':h((OLD/n).read_bytes())}for n in names},indent=2)+'\n')
s=(OLD/'evidence.py').read_text().replace('phase7 legacy','phase8 legacy')
start=s.index('def validate(')
resolver='''def primary_material(packet, module, repo, depth=0):
 assert depth < 8
 row=json.loads(packet['execution/completed.json'])[module]
 source=packet['execution/sources/'+module.replace('.','/')+'.lean']
 name='execution/logs/'+module+'.log'
 if name in packet: log=packet[name]
 else:
  origin=json.loads(packet['execution/reused-log-origins.json'])[module]
  assert origin['basis_member']==name and origin['sha256']==row['log_sha256']
  parent=reference(repo,json.loads(packet['review/basis-reference.json']))
  older,log=primary_material(parent,module,repo,depth+1)
  assert digest(older)==row['source_sha256']
 assert digest(source)==row['source_sha256'] and digest(log)==row['log_sha256']
 return source,log

def legacy_material(packet,module,repo,depth=0):
 assert depth < 8
 row=json.loads(packet['execution/completed.json'])[module]
 found=[(n,json.loads(b))for n,b in packet.items()if n.startswith('execution/attempts/')and n.endswith('/record.json')and json.loads(b)['module']==module]
 if found:
  assert len(found)==1
  n,rec=found[0];assert rec==row;folder=n.rsplit('/',1)[0]
  source=packet[folder+'/'+module.split('.')[-1]+'.lean'];log=packet[folder+'/compiler.log']
 else:
  refs=json.loads(packet['publication/references.json'])
  key='phase7_legacy'if'phase7_legacy'in refs else'phase5_legacy'
  parent=reference(repo,refs[key]);older=json.loads(parent['execution/completed.json'])[module]
  for field in ['source_sha256','dependencies','object_sha256','log_sha256']:assert row[field]==older[field]
  source,log=legacy_material(parent,module,repo,depth+1)
 assert digest(source)==row['source_sha256']and digest(log)==row['log_sha256']
 return source,log

'''
s=s[:start]+resolver+s[start:]
s=s.replace("refs['phase7_primary']","refs['phase8_primary']").replace("refs['phase5_legacy']","refs['phase7_legacy']",1) # Only top-level validate occurrence follows the resolver's generic refs[key].
a=" # One referenced phase6 archive supplies raw logs reused by phase7; never copy/replay it.\n p6ref=json.loads(pm['review/basis-reference.json']);p6=reference(basis_repo,p6ref)\n"
assert a in s;s=s.replace(a,' # Follow pinned archive references for reused bytes; never execute or copy ancestor payloads.\n')
s=s.replace('==(187,2,10)','==(188,2,10)').replace('==(187,15,202,0,15)','==(188,15,203,0,15)').replace('==202 and len(prows)==187','==203 and len(prows)==188').replace('all202_selected','all203_selected')
s=s.replace(" seen=set();origins=json.loads(pm['execution/reused-log-origins.json'])"," seen=set()")
a="""   assert rec=={**pd[mod],'origin':'phase7_primary_hash_bound'}
   src=pm['execution/sources/'+mod.replace('.','/')+'.lean']
   if mod in origins:
    origin=origins[mod];log=p6[origin['basis_member']];assert digest(log)==origin['sha256']
   else:log=pm['execution/logs/'+mod+'.log']
"""
b="""   assert rec=={**pd[mod],'origin':'phase8_primary_hash_bound'}
   src,log=primary_material(pm,mod,basis_repo)
"""
assert a in s;s=s.replace(a,b)
a="""   assert row==lrows[mod]and rec=={**ld[mod],'origin':'phase5_legacy_hash_bound'}
   found=[(n,json.loads(b))for n,b in lm.items()if n.startswith('execution/attempts/')and n.endswith('/record.json')and json.loads(b)['module']==mod]
   assert len(found)==1;n,record=found[0];assert record==ld[mod];folder=n.rsplit('/',1)[0]
   src=lm[folder+'/'+Path(row['source']).name];log=lm[folder+'/compiler.log']
"""
b="""   assert row==lrows[mod]and rec=={**ld[mod],'origin':'phase7_legacy_hash_bound'}
   src,log=legacy_material(lm,mod,basis_repo)
"""
assert a in s;s=s.replace(a,b)
s=s.replace(" for n in freeze['driver_inputs']:assert before[str(run.parent/n)]==digest(m['preparation/'+n])\n for n in freeze['control_files']:assert digest(m['preparation/'+n])==freeze['control_files'][n]", """ for n in ['build.py','gates.py','prepared-inventory.json','preparation.json','basis-reference.json','LegacyAudit.lean']:
  assert before[str(run.parent/n)]==digest(m['preparation/'+n])
 for n,pin in freeze['history'].items():assert digest(m['preparation/'+n])==pin
 preparation=J('preparation/preparation.json');gate=preparation['primary_gate']
 assert digest(m['execution/primary-review.json'])==gate['review_sha256']==freeze['root_primary_review_sha256']
 assert digest(m['execution/primary-result.json'])==freeze['primary_result_sha256']
 registered=json.loads(pm['execution/registered-adoption.json'])['files']
 assert len(registered)==len(preparation['registered_files'])==9
 for entry in registered:
  rel=entry['destination'];archived=pm['execution/adopted-sources/'+rel]
  assert digest(archived)==entry['sha256']and len(archived)==entry['bytes']
  recorded=str(Path(owner['primary']).parents[2]) # No path inference is trusted below.
  found=[path for path in preparation['registered_files']if path.endswith('/'+rel)]
  assert len(found)==1 and preparation['registered_files'][found[0]]==entry['sha256']==before[found[0]]
  if current_repo is not None:assert sha(current_repo/rel)==entry['sha256']
""")
s=s.replace("  recorded=str(Path(owner['primary']).parents[2]) # No path inference is trusted below.\n",'')
s=s.replace("assert len(reach)==45","assert len(reach)==46")
s=s.replace("done[mod]['object_sha256']!=ld[mod]['object_sha256']","mod not in ld or done[mod]['object_sha256']!=ld[mod]['object_sha256']")
s=s.replace("assert changed==['BusyBeaver.ZFC.DomRho8']","assert changed==['BusyBeaver.ZFC.DomRho8','BusyBeaver.ZFC.DominatedImplication']")
s=s.replace("'primary_modules':187","'primary_modules':188").replace("'union_modules':202","'union_modules':203").replace("'audit_transitive_project_modules':45","'audit_transitive_project_modules':46")
s=s.replace('referenced primary/phase5/phase6 archives','referenced phase8 primary/phase7 legacy and their pinned ancestor archives')
(P/'evidence.py').write_text(s)
for n in ['review.py','publish.py','review_saved.py']:
 s=(OLD/n).read_text().replace('all202_','all203_').replace('current202_','current203_');(P/n).write_text(s)
s=(OLD/'capture.py').read_text()
s=s.replace("'README.template.md','controls.py'","'README.template.md','predecessor-helpers.json','controls.py'")
a="names=['build.py','gates.py','LegacyAudit.lean','prepared-inventory.json','preparation.json','basis-reference.json','freeze.json','prepare.py','README.md','actual-plan.json','controls.py','controls-result.json','controls.stdout.log','controls.stderr.log','prepare.stdout.log','prepare.stderr.log']"
b="names=['build.py','gates.py','LegacyAudit.lean','prepared-inventory.json','preparation.json','basis-reference.json','freeze.json','prepare.py','finalize.py','README.md','actual-plan.json','controls.py','controls-result.json','controls.stdout.log','controls.stderr.log','prepare.stdout.log','prepare.stderr.log','finalize.stdout.log','finalize.stderr.log']"
assert a in s;s=s.replace(a,b).replace('/tmp/k215-phase7-legacy-driver-peer','/tmp/k215-phase8-legacy-driver-peer')
s=s.replace("[('phase7_primary','phase7/lean'),('phase5_legacy','phase5/legacy')]","[('phase8_primary','phase8/lean'),('phase7_legacy','phase7/legacy')]")
(P/'capture.py').write_text(s)
