# Phase15 quotient syntax and congruence candidate

This packet is source-only. It preserves the exact three-file proposal from
`7f3942117fb54d6316fa84c501350504ab9e6f55`, recovered through the immutable existing
aliases in the accepted phase14 merge record. The two Lean files and producer
remain unadopted and uncompiled here. No producer has been executed.

The two Lean files save 2,683 bytes and 82 lines (16,753/433 → 14,070/351).
The producer grows by 1,307 bytes/12 lines; the three-file maintenance total saves
**1,376 bytes and 70 lines** (21,436/524 → 20,060/454). These are source metrics,
not proof-term, import-count or runtime claims. Upstream's generic KEndpoint
check is attributed history, not our current exact KEndpoint215 acceptance.

## Mathematical/API review

`QuotientModel.relSat_congr` moves after `sat_quotient`. Pointwise bisimilarity
makes the quotient images equal by `mk_eq_iff`; function extensionality gives
an equal quotient environment. Applying `sat_quotient` backwards on both sides
then rewriting that environment proves the original relation-congruence
statement. There is no circularity: `sat_quotient` calls `mk_eq_iff` and
`mk_scons`, and the earlier membership congruence proves well-defined quotient
membership. Neither depends on `relSat_congr`.

The weak fork uses that same short argument with its own `QHyp` setoid and
quotient. It does **not** convert QHyp into ModelsCPGIC. The strong theorem keeps
ModelsCPGIC, the weak theorem keeps QHyp, and every theorem header is exact.
The new import of QuotientModel supplies only three hypothesis-free definitions
and their three syntax/satisfaction theorems. Those use no witness, QHyp or CP/GIC
model assumption. The weak membership, modelSetoid, quotient construction,
satisfaction and extensionality bodies are otherwise unchanged. QHyp itself is
untouched. The import is acyclic: QuotientModel imports CompositionModel, whose
closure does not import either quotient lane.

All 18 explicit declaration names in each module are retained. In KQ1Model,
memberForm, translate and RelSat become reducible aliases; three theorem bodies
forward to the shared syntax, and relSat_congr changes as above. The complete
maintained Lean caller census found no generated equation/match-helper callers.
The consumers in separation, replacement and collection call the retained
qualified APIs. Equations internal to the old recursive definitions are not
asserted to be a separately preserved public API. The aliases preserve the
formula constructors and satisfaction computation definitionally; the proposed
client also checks their exact identity with no model hypothesis.

Seven small typed client reports cover shared syntax and the strong/weak
congruence, satisfaction and extensionality signatures. `shared_syntax` should
be axiom-free; the other reports are to be captured under the standard-only
axiom gate after compilation. We do not infer exact new profiles from unprinted
old congruence proofs: the shorter argument explicitly uses quotient equality
and function extensionality. No custom axiom, admission, native shortcut or
weakened formula/domain quantifier is introduced.

## Producer review and pending safe reproduction

Both complete old/new producer sources were read. They import only `re` and
`pathlib`, read six fixed Quotient sources relative to the working directory,
and write six fixed KQ1 outputs. The unchanged transforms replace the model
hypotheses/laws with QHyp fields, then specialize union, power, singleton and
collection. They do not shell out, import submitted helpers, or run Lean.

The maintained adaptation is reconstructed from the exact old producer plus the
reviewed alias constant and Model branch (and the proposal's final newline).
It is byte-identical to the attributed producer. The new Model branch executes
*after* namespace conversion, replaces precisely the hypothesis-free syntax
interval, rejects an unrelocated relSat_congr inside that interval, and imports
the shared module. Other five output branches are unchanged. The replacement
indices intentionally fail if the source layout no longer matches; no claim
of a general Lean parser is made.

Wait for root GO before either producer execution. Then use two fresh external
layouts containing only the six pinned inputs under `BusyBeaver/ZFC`:

1. Run the inspected old maintained producer once on unchanged before inputs.
   Compare **all six** outputs with the six pinned current before outputs.
   Record every pre-existing drift; never silently treat it as this proposal.
2. Run the reconstructed maintained adaptation on the same inputs except the
   reviewed new QuotientModel. Compare generated KQ1Model with the exact held
   candidate; require the other five outputs to equal the baseline-control
   outputs. Compare them with the maintained tree too, retaining any baseline
   drift separately.
3. Capture both argv/cwd, 30-second caps, exits and raw logs. Rehash original and
   copied inputs/producers before/after. No output or symlink may lead back into
   the repository. No supplied script, compiler or archived executable is part
   of these producer checks. The ordinary six existing output paths are the
   complete expected write set.

The output names are KQ1Model, KQ1Separation, KQ1Basic, KQ1Replacement, KQ1Power
and KQ1Collect. The inputs are QuotientModel, QuotientSeparation, QuotientBasic,
QuotientReplacement, QuotientPower and QuotientCPGIC. `review.json` pins them all.
No reproduction or absence of pre-existing drift is claimed before those runs.
A first own preparation equality assertion omitted the proposed producer's final
blank line; its source/failure are retained under `history/preparation-v1`.
No producer or proof tool ran during that preparation.
