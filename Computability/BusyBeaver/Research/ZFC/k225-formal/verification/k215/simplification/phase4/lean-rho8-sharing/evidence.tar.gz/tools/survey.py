from pathlib import Path
import json,re,hashlib
from functools import cache
root=Path('/home/codex/.codex/worktrees/ec20/Proofs')
cert=root/'Computability/BusyBeaver/Research/ZFC/k225-formal/lean217/dominated_rho8_full_certificate.json'
templates=root/'SetTheory/Cardinals/docs/reports/set-theory/zfc-closure-kernels/code/149-dom-theory-ev-CD230.v'
data=json.loads(cert.read_text());terms=data['term_table'];nodes=data['nodes'][:61]
@cache
def expr(i):
 t=terms[i]
 return (expr(t[0]),expr(t[1])) if isinstance(t,list) else t['var'] if isinstance(t,dict) else 'T'
def parse(text):
 tokens=re.findall(r'[()]|[^\s()]+',text);i=0
 def one():
  nonlocal i
  t=tokens[i];i+=1
  if t!='(':return t
  out=[]
  while tokens[i]!=')':out.append(one())
  i+=1;return tuple(out)
 result=one();assert i==len(tokens);return result
def tree(t):
 if isinstance(t,str):return 'T' if t=='0' else int(t.removeprefix('v'))
 assert t[0]=='wim' and len(t)==3
 return(tree(t[1]),tree(t[2]))
def shape(t):
 names={}
 def go(x):
  if isinstance(x,tuple):return tuple(go(y) for y in x)
  if isinstance(x,int):
   if x not in names:names[x]=len(names)
   return names[x]
  return x
 return go(t),names
forms=[expr(n['term']) for n in nodes]
same={i:next(j for j in range(i+1) if forms[j]==f) for i,f in enumerate(forms)}
matches={}
for m in re.finditer(r'Lemma cd_(\d+) \((.*?) : nat\) : thm230 (.*?)\.\s*Proof\. exact \((.*?)\)\. Qed\.',templates.read_text(),re.S):
 n=int(m[1]);f=tree(parse(m[3]));s,ren=shape(f)
 for j,other in enumerate(forms):
  ss,r=shape(other)
  if ss==s:
   matches[n]={'bootstrap':j,'arguments':{str(k):next(v for v,w in ren.items() if w==index) for k,index in r.items()}}
   break
result={'bootstrap_duplicates':{str(i):j for i,j in same.items() if i!=j},'cd_bootstrap_same_schema':matches,'count':len(matches)}
out=Path('/tmp/k215-domrho8-sharing/survey.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(out.read_text())
