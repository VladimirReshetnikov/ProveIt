"""Pure metadata gates for phase8 legacy continuity. No compiler launch here."""
from pathlib import Path
import hashlib,json,re
DOM='BusyBeaver.ZFC.DomRho8'
NEW='BusyBeaver.ZFC.DominatedImplication'
CHANGED={DOM,'BusyBeaver.ZFC.KSeed222','BusyBeaver.ZFC.KSeedModel222'}
NAMES=('Enum222','L2Axioms222','L2Root222','Seed222','Dag219Equiv','L2Lib219','L2Macros219','L2Control219','L2Axioms219','L2Root219','L2Dom','EnumDom','L2AxiomsDom','L2RootDom','RMOffsetBisim')
EXTRA={'BusyBeaver.ZFC.'+n for n in NAMES}
PRIMARY_AFFECTED={'BusyBeaver.ZFC.'+n for n in ('DomRho8','DominatedImplication','EnumPerm','KCodeDom','KEndpoint','KEndpoint215','KIndisc222','KLowerEqv','KLowerQHyp','KLowerRaw','KLowerRel','KLowerSeed','KLowerTag','KSeed222','KSeedModel222','KUpper222','L2AxiomsPerm','L2RootPerm','SeedPerm')}
LEGACY_AFFECTED={'BusyBeaver.ZFC.'+n for n in ('EnumDom','L2AxiomsDom','L2RootDom')}
CLIENTS=['SetTheory.BusyBeaver.ZFC.LegacyAudit.'+n for n in ('root222','root219','rootDom','rootPerm','offset_checker')]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def graph(inv):return {r['module']:r for r in inv['modules']}
def affected(rows,dirty):
 dirty=set(dirty)
 while True:
  new=dirty|{m for m,r in rows.items()if set(r['imports'])&dirty}
  if new==dirty:return dirty
  dirty=new

def union(primary,legacy):
 p,l=graph(primary),graph(legacy)
 assert len(p)==len(primary['modules'])==188
 extra=set(l)-set(p);assert extra==EXTRA
 rows=primary['modules']+[r for r in legacy['modules']if r['module']in extra]
 assert len(rows)==len({r['module']for r in rows})==203
 seen=set()
 for r in rows:
  assert set(r['imports'])<=seen|{'Init'};seen.add(r['module'])
 return {'modules':rows,'external_imports':['Init'],'primary_target':primary['target'],'legacy_targets':sorted(EXTRA)}

def checkpoint(old,new,legacy,approved):
 p,q=graph(old),graph(new)
 assert old['target']==new['target']=='BusyBeaver.ZFC.KEndpoint215'
 assert old['external_imports']==new['external_imports']==['Init']
 assert len(p)==187 and len(q)==188 and set(q)-set(p)=={NEW} and set(p)<set(q)
 assert [r['module']for r in new['modules']if r['module']!=NEW]==[r['module']for r in old['modules']]
 assert set(approved)==CHANGED|{NEW}
 for m in p:
  assert p[m]['source']==q[m]['source'],m
  if m not in CHANGED:assert p[m]==q[m],m
 for m,a in approved.items():
  assert all(q[m][k]==a[k]for k in ('source','source_sha256','imports')),m
 assert {m for m in p if p[m]['source_sha256']!=q[m]['source_sha256']}==CHANGED
 u=union(new,legacy);dirty=affected(graph(u),CHANGED|{NEW})
 assert dirty&set(q)==PRIMARY_AFFECTED and dirty&EXTRA==LEGACY_AFFECTED
 return u

def current_inventory(driver,repo):
 primary=driver.inventory(repo);rows=graph(primary);order=list(rows);target=driver.TARGET
 try:
  for name in NAMES:
   driver.TARGET='BusyBeaver.ZFC.'+name
   inv=driver.inventory(repo);assert inv['external_imports']==['Init']
   for r in inv['modules']:
    m=r['module']
    if m in rows:assert rows[m]==r
    else:rows[m]=r;order.append(m)
 finally:driver.TARGET=target
 result={'modules':[rows[m]for m in order],'external_imports':['Init'],'primary_target':target,'legacy_targets':sorted(EXTRA)}
 return primary,result

def audit_reports(text):
 assert not any(s in text for s in ('warning:','error:','sorryAx',"declaration uses 'sorry'"))
 reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
 assert [n for n,_ in reports]==CLIENTS
 for _,ax in reports:assert {v.strip()for v in ax.split(',')if v.strip()}<={'propext','Classical.choice','Quot.sound'}
 return reports

def private_parents(obj,cache):
 assert not cache.is_symlink()
 obj.relative_to(cache)
 for p in obj.parents:
  assert not p.is_symlink(),p
  if p==cache:return
 raise AssertionError('outside cache')

def provider(obj,expected,fresh):
 if fresh:assert obj.is_file()and not obj.is_symlink()
 else:assert obj.is_symlink()and obj.resolve(strict=True)==expected.resolve(strict=True)

def valid_record(row,rec,records,obj,source_current=True):
 assert rec['status']=='PASS'and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
 assert rec['source_sha256']==row['source_sha256']
 if source_current:assert sha(row['source'])==row['source_sha256']
 assert rec['dependencies']=={d:records[d]['object_sha256']for d in row['imports']if d in records}
 assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']

def packet_pins(repo,reference):
 for rel,pin in reference.items():assert sha(repo/rel)==pin,rel


def reuse_record(row,record,dependencies):
 return record['source_sha256']==row['source_sha256'] and record['dependencies']==dependencies

def primary_review(review,result_sha):
 assert review['status']=='PASS_ROOT_READ_ONLY_BINDINGS'
 assert review['result_sha256']==result_sha
 assert (review['current_modules'],review['predecessor_modules'],review['typed_audits'],review['axiom_reports'])==(188,187,2,10)
 assert review['exact_machine_inputs_unchanged']
