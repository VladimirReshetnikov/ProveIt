import BusyBeaver.ZFC.RMBisim

namespace SetTheory.BusyBeaver.ZFC.RMBisimDecoderAudit
open RegisterPath
open RMBisim

-- Literal old definitions, independently retained from the original module.
namespace Old128
def getc (T : CTree) (j : Nat) : Option (List Bool × List Bool) :=
  match lookupC T j with
  | some (a, b, _, _) => some (decode a, decode b)
  | none => none

def branchOk (t1 t2 : Tree) (T : CTree) (A B : List Bool) (j : Nat) : Bool :=
  match seg t1 segFuel A, seg t2 segFuel B, getc T j with
  | some (l1, P1), some (l2, P2), some (Q1, Q2) => cntEq l1 l2 && lbeq P1 Q1 && lbeq P2 Q2
  | _, _, _ => false

def entryOk (t1 t2 : Tree) (T : CTree) (x : Entry) : Bool :=
  match tsite t1 (decode x.1), tsite t2 (decode x.2.1) with
  | some (.halt, _), some (.halt, _) => true
  | some (.decnz r1, Q1), some (.decnz r2, Q2) =>
      Nat.beq r1 r2 && branchOk t1 t2 T (incPath Q1) (incPath Q2) x.2.2.1 &&
        branchOk t1 t2 T (breakPath 1 Q1) (breakPath 1 Q2) x.2.2.2
  | _, _ => false

def Rel (T : CTree) (P1 P2 : List Bool) : Prop := ∃ j, getc T j = some (P1, P2)

def check (t1 t2 : Tree) (T : CTree) : Bool :=
  branchOk t1 t2 T [] [] 0 && allC (entryOk t1 t2 T) T
end Old128

example : @RMBisim.getc = @Old128.getc := rfl
example : @RMBisim.branchOk = @Old128.branchOk := rfl
example : @RMBisim.entryOk = @Old128.entryOk := rfl
example : @RMBisim.Rel = @Old128.Rel := rfl
example : @RMBisim.check = @Old128.check := rfl

-- All four old public soundness types are preserved.
theorem old_branchOk_good {t1 t2 : Tree} {T : CTree} {A B : List Bool} {j : Nat}
    (h : branchOk t1 t2 T A B j = true) : BranchGood t1 t2 (Rel T) A B :=
  RMBisim.branchOk_good h

theorem old_entryOk_good {t1 t2 : Tree} {T : CTree} {x : Entry} (h : entryOk t1 t2 T x = true) :
    EntryGood t1 t2 (Rel T) (decode x.1) (decode x.2.1) :=
  RMBisim.entryOk_good h

theorem old_check_bisim {t1 t2 : Tree} {T : CTree} (hs : branchOk t1 t2 T [] [] 0 = true)
    (ha : allC (entryOk t1 t2 T) T = true) : Bisim t1 t2 (Rel T) :=
  RMBisim.check_bisim hs ha

theorem old_check_halts_iff {p1 p2 : Program} {T : CTree}
    (hs : branchOk (ptree p1) (ptree p2) T [] [] 0 = true)
    (ha : allC (entryOk (ptree p1) (ptree p2) T) T = true) (R : Registers) :
    Halts p1 ⟨[], R⟩ ↔ Halts p2 ⟨[], R⟩ :=
  RMBisim.check_halts_iff hs ha R

-- No property of the decoder is assumed, including any path-size bound.
theorem arbitrary_decoder (d : Nat → List Bool)
    {p1 p2 : Program} {T : CTree}
    (hs : WithDecoder.branchOk d (ptree p1) (ptree p2) T [] [] 0 = true)
    (ha : allC (WithDecoder.entryOk d (ptree p1) (ptree p2) T) T = true)
    (R : Registers) : Halts p1 ⟨[], R⟩ ↔ Halts p2 ⟨[], R⟩ :=
  WithDecoder.check_halts_iff d hs ha R

abbrev decode512 (n : Nat) : List Bool := decodeAux 512 n []

theorem decoder512 {p1 p2 : Program} {T : CTree}
    (hs : WithDecoder.branchOk decode512 (ptree p1) (ptree p2) T [] [] 0 = true)
    (ha : allC (WithDecoder.entryOk decode512 (ptree p1) (ptree p2) T) T = true)
    (R : Registers) : Halts p1 ⟨[], R⟩ ↔ Halts p2 ⟨[], R⟩ :=
  WithDecoder.check_halts_iff decode512 hs ha R

#print axioms old_check_halts_iff
#print axioms arbitrary_decoder
#print axioms decoder512

end SetTheory.BusyBeaver.ZFC.RMBisimDecoderAudit
