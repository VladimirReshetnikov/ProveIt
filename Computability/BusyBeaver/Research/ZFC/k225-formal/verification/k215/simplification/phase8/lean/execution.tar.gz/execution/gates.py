"""Small metadata gates for the phase8 incremental build; no proof execution."""
from pathlib import Path
import re

NEW_MODULE = 'BusyBeaver.ZFC.DominatedImplication'
REGISTERED_MODULES = {'BusyBeaver.ZFC.' + n for n in (
    'DominatedImplication', 'DomRho8', 'KSeed222', 'KSeedModel222')}
BASIS_RESULT_SHA256 = '0f66683395fe36bfa450eb2525bd2e714bb804faf51bd830cfbe7b1bf0c223e9'
FORMAL_PREFIX = 'Computability/BusyBeaver/Research/ZFC/k225-formal/'
PRODUCTION_PATHS = {FORMAL_PREFIX + name: kind for name, kind in (
    ('generate_domrho8_lean.py', 'producer'),
    ('generate_dominated_implication_lean.py', 'producer'),
    ('dominated_implication_templates/core-prefix.txt', 'producer_input'),
    ('dominated_implication_templates/core-suffix.txt', 'producer_input'),
    ('dominated_implication_templates/adapter.txt', 'producer_input'))}
AUDIT_PINS = {
    'EndpointAudit215': 'd13596021774c5b26937b13cf6cca58342af99f59626b9205ff10b9df1e6fc7d',
    'K215Audit': '9144acc6c597c4a53928fc62be00d5e25d9f32f519797d17a5058d03b5460986',
}
AUDIT_NAMES = {
    'EndpointAudit215': [
        'EndpointAudit215.blank_halts_exactly_when_zfc_has_a_finite_refutation',
        'EndpointAudit215.nonhalting_exactly_when_zfc_is_consistent'],
    'K215Audit': [
        'SetTheory.BusyBeaver.ZFC.KEndpoint215.blank_halts_iff_zfc_refutation',
        'SetTheory.BusyBeaver.ZFC.KEndpoint215.nonhalting_iff_zfc_consistency',
        'SetTheory.BusyBeaver.ZFC.KDense215.commutes',
        'SetTheory.BusyBeaver.ZFC.KBoot215.boot',
        'SetTheory.BusyBeaver.ZFC.KSites215.covered',
        'SetTheory.BusyBeaver.ZFC.KEndpoint215.p215_boot_iff',
        'K215Audit.blank_halts_exact', 'K215Audit.nonhalting_exact'],
}

def checkpoint(old, new, registration, repo):
    """Admit only the exact registered four-source checkpoint and sole new module."""
    assert registration['status'] == 'REGISTERED_FOR_COMBINED_CHECK_NOT_YET_VERIFIED'
    assert registration['basis_result_sha256'] == BASIS_RESULT_SHA256
    assert registration['primary_project_modules'] == 188 and registration['basis_project_modules'] == 187
    assert new['target'] == old['target'] == 'BusyBeaver.ZFC.KEndpoint215'
    assert new['external_imports'] == old['external_imports'] == ['Init']
    before = {e['module']:e for e in old['modules']}
    after = {e['module']:e for e in new['modules']}
    assert len(before) == len(old['modules']) == 187
    assert len(after) == len(new['modules']) == 188
    assert set(before) < set(after) and set(after)-set(before) == {NEW_MODULE}
    paths, lean, producers = set(), {}, {}
    for row in registration['files']:
        path = Path(row['destination'])
        assert not path.is_absolute() and '..' not in path.parts
        assert row['destination'] not in paths
        paths.add(row['destination'])
        assert re.fullmatch('[0-9a-f]{64}', row['sha256']) and row['bytes'] > 0
        if row['kind'] == 'lean':
            module = row['module'];assert module in REGISTERED_MODULES and module not in lean
            assert row['destination'] == 'Computability/BusyBeaver/Lean/' + module.replace('.', '/') + '.lean'
            assert Path(after[module]['source']) == repo / path
            assert after[module]['source_sha256'] == row['sha256']
            assert after[module]['imports'] == row['imports']
            assert row['before_sha256'] == (before[module]['source_sha256'] if module in before else None)
            lean[module] = row
        else:
            assert row['destination'] in PRODUCTION_PATHS
            assert row['kind'] == PRODUCTION_PATHS[row['destination']]
            assert 'module' not in row and 'imports' not in row
            producers[row['destination']] = row['sha256']
    assert set(lean) == REGISTERED_MODULES
    assert set(producers) == set(PRODUCTION_PATHS)
    for module in before:
        assert before[module]['source'] == after[module]['source']
        if module not in REGISTERED_MODULES:
            assert before[module] == after[module], module
        else:
            assert before[module]['source_sha256'] != after[module]['source_sha256']
    # Seed sharing changes proofs/definitions, without changing their imports.
    for module in ('BusyBeaver.ZFC.KSeed222','BusyBeaver.ZFC.KSeedModel222'):
        assert after[module]['imports'] == before[module]['imports']
    affected = set(REGISTERED_MODULES)
    while True:
        more = affected | {m for m,e in after.items() if set(e['imports']) & affected}
        if more == affected:break
        affected = more
    return {'changed_sources': sorted(REGISTERED_MODULES),
            'added_modules': [NEW_MODULE],
            'unchanged_source_count': 184,
            'potentially_affected_modules': sorted(affected),
            'producer_pins': producers}


def audit_reports(name, text):
    assert not any(s in text for s in ('warning:', 'error:', 'sorryAx', "declaration uses 'sorry'"))
    reports = re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)", text)
    assert [n for n,_ in reports] == AUDIT_NAMES[name]
    for _, axioms in reports:
        assert {a.strip() for a in axioms.split(',') if a.strip()} <= {'propext', 'Classical.choice', 'Quot.sound'}
    return reports

def private_parents(obj, cache):
    """Unlinking a target must never follow a directory alias into the basis."""
    assert not cache.is_symlink()
    obj.relative_to(cache)
    for parent in obj.parents:
        assert not parent.is_symlink(), parent
        if parent == cache:
            return
    raise AssertionError('Object outside private cache')

def provider(obj, basis_obj, origin):
    if origin == 'phase7_hash_bound':
        assert obj.is_symlink() and obj.resolve(strict=True) == basis_obj.resolve(strict=True)
    else:
        assert origin == 'phase8_fresh' and obj.is_file() and not obj.is_symlink()
