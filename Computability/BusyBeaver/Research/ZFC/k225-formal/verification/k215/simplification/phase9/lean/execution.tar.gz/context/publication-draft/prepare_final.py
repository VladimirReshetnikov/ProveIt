"""Prepare an additive final helper/context successor only after both runs finish.

No capture, proof invocation, canonical write, or modification of the drafts.
The successor still needs a source-delta peer before bundle.py is invoked.
"""
from contextlib import ExitStack
from pathlib import Path
import argparse
import fcntl
import json
import shutil
from evidence import binary_name, digest, dump
HERE=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-review',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists()
    mainrun=Path('/tmp/k215-phase9-main/full-run2');aux=Path('/tmp/k215-phase9-main/controls-run1')
    with ExitStack()as stack:
        for run in (mainrun,aux):
            lock=stack.enter_context((run/'output.lock').open('rb'))
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        read=lambda p:json.loads(Path(p).read_text())
        main_result=read(mainrun/'result.json');extra=read(aux/'result.json');review=read(args.terminal_review)
        assert main_result['status']==extra['status']=='PASS'
        assert main_result['selected_project_modules']==197 and extra['selected_project_modules']==18
        assert review['status']=='PASS_INDEPENDENT_197_TRANSITIVE_SOURCE_CLOSED_REVIEW'
        assert review['pins'][str(mainrun/'result.json')]==digest((mainrun/'result.json').read_bytes())
        rows=read(HERE/'context.json')['files'];by_path={r['path']:r for r in rows};by_member={r['member']:r for r in rows}
        def add(path,member):
            path=Path(path);assert path.is_file()and not path.is_symlink()and not binary_name(path)
            data=path.read_bytes();entry={'path':str(path),'member':member,'sha256':digest(data),'bytes':len(data)}
            if str(path)in by_path:
                old=by_path[str(path)];assert old['sha256']==entry['sha256'];return
            assert member not in by_member
            rows.append(entry);by_path[str(path)]=entry;by_member[member]=entry
        for path in sorted(HERE.iterdir()):
            if path.is_file()and path.name!='context.json':add(path,'context/publication-draft/'+path.name)
        for folder in (HERE/'peer',HERE/'history'):
            for path in sorted(folder.rglob('*')):
                if path.is_file()and '__pycache__'not in path.parts:
                    add(path,'context/publication-draft/'+path.relative_to(HERE).as_posix())
        add(Path('/tmp/k215-phase9-main/legacy-unchanged.json'),'context/legacy-unchanged.json')
        add(Path('/tmp/k215-phase9-main/timings.json'),'context/timings.json')
        research=Path('/tmp/k215-phase9-first-primitive')
        for name in ('CB1Suffix.lean','design.md','census.py','census.json','caller-census.json','freeze.json'):
            add(research/name,'context/uncompiled-cb1/'+name)
        for path in sorted(aux.rglob('*')):
            if any(p in {'objects','__pycache__'}for p in path.relative_to(aux).parts):continue
            assert not path.is_symlink(),path
            if path.is_file()and not binary_name(path)and path.name!='output.lock':
                add(path,'context/auxiliary/'+path.relative_to(aux).as_posix())
        for name in ('full-run2-review.json','full-run2-review.stdout','full-run2-review.stderr'):
            add(Path('/tmp/k215-phase9-transitive-peer')/name,'context/terminal-peer/'+name)
        for name in ('controls-v1.json','controls-run1.stdout'):
            add(aux.parent/name,'context/auxiliary/'+name)
        for entry in read(aux/'inventory.json')['modules']:
            add(Path(entry['source']),'context/auxiliary/selected-sources/'+entry['module'].replace('.','/')+'.lean')
        args.output.mkdir(parents=True)
        for path in HERE.iterdir():
            if path.is_file()and path.suffix in {'.py','.json','.md','.log'}:
                shutil.copyfile(path,args.output/path.name)
        for path in (HERE/'successor').glob('*.py'):
            shutil.copyfile(path,args.output/path.name)
        context={'status':'FROZEN_TERMINAL_ADDITIVE_CONTEXT','files':rows,
                 'scope':'Original drafts and failed/successful histories unchanged; completed auxiliary controls added; CB1 remains uncompiled research. No actual bundle capture performed by this preparation.'}
        (args.output/'context.json').write_bytes(dump(context))
        config=read(HERE/'config.json');config['auxiliary_run']=str(aux)
        config['auxiliary_result_sha256']=digest((aux/'result.json').read_bytes())
        config['auxiliary_map']=str(aux.parent/'controls-v1.json')
        config['auxiliary_map_sha256']=digest((aux.parent/'controls-v1.json').read_bytes())
        config['terminal_review']=str(args.terminal_review);config['terminal_review_sha256']=digest(args.terminal_review.read_bytes())
        (args.output/'config.json').write_bytes(dump(config))
        counts={k:len(main_result[k])for k in ('fresh_modules','phase8_reused_modules','isolated_reused_modules')}
        old=(HERE/'README.md').read_text()
        first='This is a prepared publication builder. It has not collected the ongoing full-run2 and makes no new endpoint completion claim. The terminal packet\'s `result.json` will report its actual fresh and reused providers; the original run records remain unchanged.'
        text=(f"The combined Lean check passed for the 197-module union: {counts['fresh_modules']} freshly compiled, "
              f"{counts['isolated_reused_modules']} reused from compatible isolated checks, and {counts['phase8_reused_modules']} directly reused from phase8. "
              'The endpoint depends on 192 modules; five additional modules establish decoder-prefix transport. '
              'Both unchanged typed clients passed with ten standard-axiom reports. The separate 18-provider controls/compatibility run also passed, including the five ReadyControls reports and the original-executor/engine interfaces. '
              'These are recorded compiler outcomes; the publication capture and saved reader have their own receipts. Original raw records and draft status files remain unchanged.')
        assert first in old;old=old.replace(first,text)
        old=old.replace('The original source-only ReadyControls freeze stays source-only; any later compiled positive/negative gate controls and legacy engine checks must be retained as an additive terminal record. Their completion is not presumed by this draft.',
            'The original source-only ReadyControls freeze stays source-only. The subsequent completed 18-provider controls run is retained additively: ReadyControls checks the real positive gate, a boundary mutation that leaves the scan rows valid but disables the shortcut, and exact fallback equalities. The unchanged RuntimeAudit, KEngine224 and KEngine225 clients are included in that separate run. A separate read-only source/import comparison confirms the earlier five-client legacy audit\'s 46-provider closure is unchanged; it does not constitute a new full legacy run.')
        old+='\nThe retained CB1 suffix proposal is uncompiled research: 86 literal leaves share a three-row entry and a q1-return argument, conditional on the full prefix, `|A|+3≤D0`, and a LeftWord guard. It supplies no accepted Boolean Covered replacement or claim that 86 primitive contracts have been formally closed. Historical source comments saying “draft” or “not compiled” are preserved byte-for-byte; the exact later actual receipts determine compilation status. This phase adds shared proof infrastructure and does not claim an overall source-line or object-size reduction.\n'
        (args.output/'README.md').write_text(old)
        receipt={'status':'FINAL_CONTEXT_AND_DOCS_PREPARED_NOT_CAPTURED','main_result_sha256':digest((mainrun/'result.json').read_bytes()),
                 'auxiliary_result_sha256':config['auxiliary_result_sha256'],'terminal_review_sha256':config['terminal_review_sha256'],
                 'actual_raw_counts':counts,'context_files':len(rows),'context_sha256':digest(dump(context)),
                 'original_drafts_unchanged':True,'compiler_or_collector_invoked':False}
        (args.output/'preparation.json').write_bytes(dump(receipt));print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
