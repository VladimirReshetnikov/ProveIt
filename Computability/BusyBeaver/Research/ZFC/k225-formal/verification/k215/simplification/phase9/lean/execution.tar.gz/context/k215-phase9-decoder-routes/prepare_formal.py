"""Own source-only successor: relabel certificate data, use the maintained table.
No supplied code, table evaluator, transition simulation or proof compiler runs.
"""
from pathlib import Path
import hashlib,json,re,difflib
O=Path(__file__).resolve().parent;S=O/'candidate/BusyBeaver/ZFC';D=O/'formal-table/candidate/BusyBeaver/ZFC'
SWAPS={301:102,102:301,302:120,120:302,254:230,230:254}
def sigma(q):return SWAPS.get(q,q)
def sha(b):return hashlib.sha256(b).hexdigest()
def part(s,a,b):return s[s.index('def '+a+' :'):s.index('def '+b+' :')]
def transformed_blocks(blocks):
 count=0
 def sub(m):
  nonlocal count;count+=1
  return '  ⟨'+str(sigma(int(m[1])))+', '+str(sigma(int(m[2])))+', ['+m[3]+'], '+m[4]+'⟩'+m[5]
 result=re.sub(r'^  ⟨(\d+), (\d+), \[(.*?)\], (\d+)⟩(,?)$',sub,blocks,flags=re.M)
 assert count==281
 return result
changes=[]
def transformed_roles(roles):
 count=0
 def sub(m):
  nonlocal count;count+=1
  rest=m[3]
  rest=re.sub(r'(⟨(?:true|false), (?:1|\(-1\)), )(\d+)(⟩)',lambda a:a[1]+str(sigma(int(a[2])))+a[3],rest)
  return '  ⟨'+m[1]+', '+str(sigma(int(m[2])))+', '+rest
 result=re.sub(r'^  ⟨(\d+), (\d+), (.*)$',sub,roles,flags=re.M)
 assert count==234
 return result
source=(S/'K215Decoder.lean').read_text()
blocks=part(source,'blocks','roles');roles=part(source,'roles','sourceRoot')
s=source.replace(blocks,transformed_blocks(blocks)).replace(roles,transformed_roles(roles))
a=s.index('def nativeRows :');b=s.index('def sourceNodes :')
replacement='''/-- The actual maintained table; no copied native table or renaming hypothesis. -/
def formal : Table := KZipTape.table KTableCore.tm215

/-- Balanced lookup is only a reduction aid for the finite certificates. -/
def fast : Table := KZipTape.table (KBoot.fastOf KBoot215.tt215)

theorem fast_eq : fast = formal := by
  funext q b
  simp only [fast, formal, KZipTape.table, KBoot215.fast215]

'''
s=s[:a]+replacement+s[b:]
s=s.replace('import BusyBeaver.ZFC.DecoderCertificate\n','import BusyBeaver.ZFC.DecoderCertificate\nimport BusyBeaver.ZFC.KFast215\nimport BusyBeaver.ZFC.KZipTape\n',1)
s=re.sub(r'^theorem working_states :[^\n]*\n','',s,flags=re.M)
s=re.sub(r'\bnative\b','formal',s)
for name in ['all_blocks_checked','structure_checked','rejects_empty_window','rejects_zero_duration','rejects_bad_exit']:
 pattern=r'(^theorem '+name+r' :[^\n]*? := )by decide \+kernel'
 s,n=re.subn(pattern,r'\1by\n  rw [← fast_eq]\n  decide +kernel',s,flags=re.M);assert n==1,name
assert part(source,'sourceNodes','blocks')==part(s,'sourceNodes','blocks')
D.mkdir(parents=True,exist_ok=False)
for name in ['DecoderCertificate.lean','K215Decoder.lean','DecoderPaths.lean','DecoderSourceBinding.lean']:
 old=(S/name).read_bytes()
 new=s.encode()if name=='K215Decoder.lean'else re.sub(r'\bnative\b','formal',old.decode()).encode()
 (D/name).write_bytes(new)
 (O/'formal-table'/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='route-native/'+name,tofile='route-formal/'+name)))
 changes.append({'file':name,'input_sha256':sha(old),'input_bytes':len(old),'output_sha256':sha(new),'output_bytes':len(new)})
r={'status':'SOURCE_ONLY_FORMAL_TABLE_SUCCESSOR','files':changes,'state_permutation':[[301,102],[302,120],[254,230]],'certificate_only_state_fields_changed':['Block.entry','Block.exit','Role.state','primitive Action.next'],'source_nodes_unchanged':True,'block_count':281,'role_count':234,'actual_block_or_structure_checks_run':False,'compiler_invocations':[],'canonical_mutations':[]}
(O/'formal-table/preparation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
