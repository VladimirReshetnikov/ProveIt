from pathlib import Path

src = Path('/tmp/k215-phase13-root/review_actual.py').read_text()
replacements = {
    "P=Path('/tmp/k215-phase13-upstream-check')": "P=Path('/tmp/k215-phase14-check')",
    "B=Path('/tmp/k215-phase12-import-check')": "B=Path('/tmp/k215-phase13-upstream-check')",
    "primary,pi,pd=check_run('primary-run1',187,{'candidate_fresh':36,'phase12_primary_checked':151},'primary-map.json')": "primary,pi,pd=check_run('primary-run1',190,{'candidate_fresh':66,'phase13_primary_checked':124},'primary-map.json')",
    "compat,ci,cd=check_run('compatibility-run1',70,{'candidate_fresh':16,'secondary_checked':53,'phase12_compatibility_checked':1},'compatibility-final-map.json')": "compat,ci,cd=check_run('compatibility-run1',70,{'candidate_fresh':16,'secondary_checked':53,'phase13_compatibility_checked':1},'compatibility-final-map.json')",
    "assert [n for n,_ in raw]==spec['reports'];assert [set(ax) for _,ax in raw]==[set(ax) for ax in spec['report_axioms']]": "assert [n for n,_ in raw]==spec['reports']\n   if 'report_axioms' in spec:assert [set(ax) for _,ax in raw]==[set(ax) for ax in spec['report_axioms']]",
    "assert len(project)==199": "assert len(project)==198\nassert 'BusyBeaver.ZFC.KProfileTC' not in project\nfor directory in [P/'primary-run1',P/'compatibility-run1']:\n retired=directory/'objects/BusyBeaver/ZFC/KProfileTC.olean'\n assert not retired.exists() and not retired.is_symlink()",
    "'PASS_ROOT_RAW_PHASE13_ACTUAL'": "'PASS_ROOT_RAW_PHASE14_ACTUAL'",
    "'distinct_project_modules':199": "'distinct_project_modules':198",
    "Path('/tmp/k215-phase13-root/root-actual-review.json')": "Path('/tmp/k215-phase14-root/root-actual-review.json')",
    "PASS raw phase13:187 primary,70 compatibility,199 project sources": "PASS raw phase14:190 primary,70 compatibility,198 project sources",
}
for old, new in replacements.items():
    assert src.count(old) == 1, old
    src = src.replace(old, new)
Path('/tmp/k215-phase14-root/review_actual.py').write_text(src)
