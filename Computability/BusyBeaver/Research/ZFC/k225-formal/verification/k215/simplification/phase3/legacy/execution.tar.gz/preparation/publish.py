"""Freeze the completed legacy refresh as a compact evidence-only copy map."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import shutil
import tarfile

P = Path(__file__).resolve().parent
RUN = P / 'run1'
BASIS = Path('/tmp/k215-proof-phase3/lean-run1')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
read = lambda path: json.loads(Path(path).read_text())
result = read(RUN / 'result.json')
done, inventory = read(RUN / 'completed.json'), read(RUN / 'inventory.json')
assert result['status'] == 'PASS' and result['project_modules'] == 199
assert result['reused_primary_modules'] == 185 and result['fresh_legacy_modules'] == 14
assert result['basis_unchanged'] and result['all_inputs_objects_logs_rechecked_after_audit']
assert sha(RUN / 'completed.json') == result['completed_sha256']
assert sha(RUN / 'inventory.json') == result['inventory_sha256']
assert len(done) == 199
for path, digest in read(RUN / 'before.json').items():
    assert sha(path) == digest, path
for row in inventory['modules']:
    module, record = row['module'], done[row['module']]
    assert record['status'] == 'PASS' and sha(row['source']) == record['source_sha256']
    assert sha(RUN / 'objects' / (module.replace('.', '/') + '.olean')) == record['object_sha256']
    assert sha(record['log']) == record['log_sha256']
    assert record['dependencies'] == {dep: done[dep]['object_sha256'] for dep in row['imports'] if dep in done}
    assert 'sorryAx' not in Path(record['log']).read_text()
audit = result['audit']
assert audit['status'] == 'PASS' and audit['warnings'] == 0
assert sha(RUN / 'audit/LegacyAudit.lean') == audit['source_sha256']
assert sha(RUN / 'audit/LegacyAudit.olean') == audit['object_sha256']
assert sha(audit['log']) == audit['log_sha256']
assert len(audit['reports']) + Path(audit['log']).read_text().count('does not depend on any axioms') == 4
fresh = [record for record in done.values() if record['origin'] == 'legacy_fresh']
assert len(fresh) == 14

packet = P / 'publication'
packet.mkdir(exist_ok=False)
files = packet / 'files'
relative = Path('Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification/phase3/legacy')
destination = files / relative
destination.mkdir(parents=True)
for name in ('build.py', 'LegacyAudit.lean'):
    shutil.copyfile(P / name, destination / name)
for name in ('result.json', 'inventory.json', 'completed.json'):
    shutil.copyfile(RUN / name, destination / name)
shutil.copyfile(RUN / 'audit/compiler.log', destination / 'LegacyAudit.log')
members = {}


def add(label, path):
    assert label not in members and not Path(path).is_symlink()
    members[label] = Path(path).read_bytes()


for name in ('build.py', 'publish.py', 'LegacyAudit.lean', 'plan.json', 'README.md'):
    add('preparation/' + name, P / name)
for path in sorted(RUN.rglob('*')):
    if path.is_file() and 'objects' not in path.relative_to(RUN).parts:
        if not any(s in {'.olean', '.ilean', '.pyc'} for s in path.suffixes):
            add('execution/' + path.relative_to(RUN).as_posix(), path)
for name in ('result.json', 'completed.json', 'inventory.json', 'toolchain.json'):
    add('basis/' + name, BASIS / name)
add('basis/live-review.json', Path('/tmp/k215-proof-phase3/live-review.json'))
for module, record in done.items():
    if record['origin'] == 'phase3_primary_hash_bound':
        add('basis/logs/' + module + '.log', record['log'])
index = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
         for name, data in sorted(members.items())}
with (destination / 'execution.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
(destination / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
summary = {
    'status': 'PASS_LEGACY_COMPATIBILITY_REFRESH',
    'project_modules': 199, 'reused_phase3_primary_modules': 185, 'fresh_legacy_modules': 14,
    'typed_clients': 1, 'axiom_reports': 4, 'audit_warnings': 0,
    'fresh_project_warnings': sum(record['warnings'] for record in fresh),
    'fresh_module_seconds_total': sum(record['seconds'] for record in fresh),
    'basis_result_sha256': sha(BASIS / 'result.json'),
    'basis_live_review_sha256': sha('/tmp/k215-proof-phase3/live-review.json'),
    'result_sha256': sha(RUN / 'result.json'),
    'archive_sha256': sha(destination / 'execution.tar.gz'), 'archive_members': len(index),
    'scope': 'Fourteen legacy modules freshly compiled against the exact primary185 phase3 basis. '
             'All199 private objects/source/import/log bindings and immutable basis rechecked after '
             'the typed audit. No fresh full199 build and no new internal PA endpoint claim.'}
(destination / 'review.json').write_text(json.dumps(summary, indent=2) + '\n')
(destination / 'README.md').write_text(f'''# Legacy interfaces after the proof refactor

All fourteen legacy modules passed against the final phase-three 215-state endpoint closure. The refresh uses a separate199-module cache:185 primary objects were copied from the exact [phase-three checkpoint](../lean/README.md), and14 additional modules were freshly compiled. It does not replace that primary receipt or claim a fresh compilation of all199 modules.

The fresh modules are `Enum222`, `L2Axioms222`, `L2Root222`, `Seed222`, `Dag219Equiv`, `L2Lib219`, `L2Macros219`, `L2Control219`, `L2Axioms219`, `L2Root219`, `L2Dom`, `EnumDom`, `L2AxiomsDom`, and `L2RootDom`. This checks that the common iteration and transfer abstractions and the smaller rho8 proof preserve the earlier facades. [LegacyAudit.lean](LegacyAudit.lean) directly instantiates the four public `iter_iff` statements for arbitrary states, with four standard-axiom reports and no audit warnings. The14 fresh modules report{summary['fresh_project_warnings']} linter warnings.

[result.json](result.json), [review.json](review.json), [completed.json](completed.json) and [inventory.json](inventory.json) bind the exact sources, imports, selected objects, compiler commands, logs and final typed client. [LegacyAudit.log](LegacyAudit.log) preserves the four reports. All199 private objects and all original inputs, including the immutable185-object basis, were checked again after the audit. No canonical source or predecessor cache was changed.

[execution.tar.gz](execution.tar.gz), bound by [index.json](index.json), preserves the executed runner/supervisor,14 fresh source snapshots and raw logs, all inherited selected logs, exact predecessor records, typed client for four interfaces and raw report, toolchain identities and before map. Compiled objects are excluded. The primary185 source snapshots are preserved in the linked phase-three packet; their exact hashes are retained here. The preparation-only plan is historical and is superseded by this execution's current inventory.

[build.py](build.py) is the executed incremental runner. It requires a completed exact primary185 basis and its independent live review, uses the shared compiler lock, one worker,12GiB and120seconds per invocation, and writes a new private output. A subsequent source change requires a matching new primary basis before this refresh can be repeated. The accepted machine and ZFC endpoint statement remain those of the primary checkpoint; this compatibility check adds no internal PA claim.
'''.replace('separate199','separate 199').replace(':185', ': 185').replace('and14', 'and 14').replace('all199', 'all 199').replace('The14', 'The 14').replace('report{', 'report {').replace('All199','All 199').replace('immutable185','immutable 185').replace('supervisor,14','supervisor, 14').replace('primary185','primary 185').replace('worker,12GiB and120seconds','worker, 12 GiB and 120 seconds').replace(f"report{summary['fresh_project_warnings']}",f"report {summary['fresh_project_warnings']}"))
rows = [{'source': str(path), 'target': path.relative_to(files).as_posix(),
         'sha256': sha(path), 'bytes': path.stat().st_size}
        for path in sorted(files.rglob('*')) if path.is_file()]
(packet / 'copy-map.json').write_text(json.dumps({'status': 'PASS_READY_FOR_ROOT_COPY', 'files': rows}, indent=2) + '\n')
print(json.dumps({'copy_map': str(packet / 'copy-map.json'), 'map_sha256': sha(packet / 'copy-map.json'),
                  'files': len(rows), 'archive_members': len(index),
                  'archive_bytes': (destination / 'execution.tar.gz').stat().st_size,
                  'review_sha256': sha(destination / 'review.json')}, indent=2))
