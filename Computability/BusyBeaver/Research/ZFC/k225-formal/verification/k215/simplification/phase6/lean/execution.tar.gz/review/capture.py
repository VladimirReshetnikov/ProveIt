"""Collect a completed phase-six run only; never invoke proof tools.

The published phase-five packet is referenced by immutable relative pins.
"""
from pathlib import Path
import json
import basis_reference
from evidence import binary_name, digest

HERE = Path(__file__).resolve().parent
FORMAL = 'Computability/BusyBeaver/Research/ZFC/k225-formal'
HELPERS = ('evidence.py', 'basis_reference.py', 'basis-reference.json', 'capture.py',
           'review.py', 'review_saved.py', 'publish.py')


def arguments(parser):
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--basis', type=Path, default=Path('/tmp/k215-proof-phase5/lean-run1'))
    parser.add_argument('--build', type=Path, default=Path('/tmp/k215-proof-phase6/build.py'))
    parser.add_argument('--basis-repo', type=Path, help='Repository containing the exact published phase5 packet')
    parser.add_argument('--context', type=Path, default=HERE / 'context.json')
    parser.add_argument('--stdout', type=Path, help='Optional original driver console log')


def collect(args):
    run, basis = args.run.resolve(), args.basis.resolve()
    # Refuse even a capture of unfinished compiler work.
    assert json.loads((run / 'result.json').read_text())['status'] == 'PASS'
    members = {}

    def add(name, path):
        path = Path(path)
        assert path.is_file() and not path.is_symlink(), path
        assert name not in members and not binary_name(path)
        members[name] = path.read_bytes()

    for name in ('owner.json', 'inventory.json', 'completed.json', 'basis-completed.json',
                 'basis-inventory.json', 'basis-logs.json', 'toolchain.json',
                 'reviewed-driver.py', 'result.json'):
        add('execution/' + name, run / name)
    owner = json.loads(members['execution/owner.json'])
    for name in ('owner.json', 'inventory.json', 'completed.json',
                 'toolchain.json', 'reviewed-driver.py', 'result.json'):
        add('basis/' + name, basis / name)
    _, pinned, _ = basis_reference.pinned_files(args.basis_repo or Path(owner['repo']))
    members['basis/live-review.json'] = pinned['live-review.json']
    add('review/build.py', args.build)
    for name in HELPERS:
        add('review/' + name, HERE / name)
    add('review/context.json', args.context)
    context = json.loads(members['review/context.json'])
    for row in context['files']:
        assert row['member'].startswith('adoption/') and '..' not in Path(row['member']).parts
        add(row['member'], row['path'])
        data = members[row['member']]
        assert digest(data) == row['sha256'] and len(data) == row['bytes']
    if args.stdout is not None:
        add('review/driver.stdout', args.stdout)
    inventory = json.loads(members['execution/inventory.json'])
    done = json.loads(members['execution/completed.json'])
    old = json.loads(members['basis/completed.json'])
    basis_logs = json.loads(members['execution/basis-logs.json'])
    for entry in inventory['modules']:
        module = entry['module']
        add('execution/sources/' + module.replace('.', '/') + '.lean', entry['source'])
        add('execution/logs/' + module + '.log', done[module]['log'])
    assert set(basis_logs) == set(old)
    for module, row in old.items():
        add('basis/logs/' + module + '.log', basis_logs[module])
        assert digest(members['basis/logs/' + module + '.log']) == row['log_sha256']
    for folder in [run / 'attempts', *sorted(run.glob('audit-*'))]:
        if not folder.exists():
            continue
        assert folder.is_dir() and not folder.is_symlink()
        for path in sorted(folder.rglob('*')):
            assert not path.is_symlink(), path
            if path.is_file() and not binary_name(path):
                add('execution/' + path.relative_to(run).as_posix(), path)
    return members
