import BusyBeaver.ZFC.KSource215Data
namespace SetTheory.BusyBeaver.ZFC.ZeroOffsetFuelAudit
open RMBisim KSource215
-- A concrete preserved certificate pointer disproves use of the old decoder.
theorem fuel128_changes_pointer : decode 1239837413068380280451026035476491402861 ≠ decode215 1239837413068380280451026035476491402861 := by decide +kernel
#print axioms fuel128_changes_pointer
end SetTheory.BusyBeaver.ZFC.ZeroOffsetFuelAudit
