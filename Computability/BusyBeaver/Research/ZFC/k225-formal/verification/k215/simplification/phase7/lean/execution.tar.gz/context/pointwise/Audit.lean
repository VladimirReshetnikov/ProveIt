
namespace DomPointwiseAudit
open SetTheory.BusyBeaver.ZFC

theorem same_row {T : Nat → Prop} (h : DomRho8.DomImp T) (a b c u : Nat) :
    T (Code254.rho8 a b c u) := DomRho8.rho8_all h a b c u

theorem same_lift {T : Nat → Prop} (h : DomRho8.DomImp T) {a b : Nat}
    (hab : T (Code254.wim a b)) (x : Nat) :
    T (Code254.wim (Code254.wim x a) (Code254.wim x b)) :=
  DomRho8.lift_right h hab x

example (T : Nat → Prop) (ht : T 0)
    (mp : ∀ {a b : Nat}, T (Code254.wim a b) → T a → T b)
    (hr : ∀ a b c u : Nat, u ≤ a → T (Code254.rho8 a b c u)) :
    DomRho8.DomImp T := ⟨ht, mp, hr⟩

#print axioms same_row
#print axioms same_lift
end DomPointwiseAudit
