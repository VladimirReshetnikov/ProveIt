from pathlib import Path
import contextlib,copy,hashlib,importlib.util,io,json,os,subprocess,sys,tempfile
sys.dont_write_bytecode=True
ROOT=Path('/tmp/k215-phase8-implication'); OUT=Path(__file__).resolve().parent
script=ROOT/'generate_dominated_implication_lean.py'
spec=importlib.util.spec_from_file_location('reviewed_producer',script); mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
def check(name, f, reject=False):
 try:
  detail=f()
 except (AssertionError,RuntimeError,KeyError) as e:
  assert reject,(name,type(e).__name__,str(e))
  results.append({'name':name,'status':'EXPECTED_REJECTION','exception':type(e).__name__,'message':str(e)})
 else:
  assert not reject,(name,'unexpected acceptance')
  results.append({'name':name,'status':'PASS','detail':detail})
def cli(args,cwd=None,expected=0):
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 p=subprocess.run([sys.executable,*args],cwd=cwd,env=env,capture_output=True,text=True,timeout=20)
 assert p.returncode==expected,(args,p.returncode,p.stderr)
 return {'argv':[sys.executable,*args],'returncode':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'stderr':p.stderr}
core,adapter,metrics=mod.generate()
check('exact_generated_pair',lambda: all_check()) if False else None
assert core.encode()==(ROOT/'candidate/BusyBeaver/ZFC/DominatedImplication.lean').read_bytes()
assert adapter.encode()==(ROOT/'candidate/BusyBeaver/ZFC/DomRho8.lean').read_bytes()
results.append({'name':'exact_generated_pair','status':'PASS','detail':{'helpers':metrics['retained_numbered_helpers'],'roots':metrics['roots'],'matches_saved_metrics':metrics==json.loads((ROOT/'generation.json').read_text())}})
check('explicit_out_check',lambda:cli([str(script),'--out',str(ROOT/'candidate'),'--check']))
work=OUT/'cli-layout';here=work/'Computability/BusyBeaver/Research/ZFC/k225-formal';here.mkdir(parents=True,exist_ok=True)
(here/script.name).write_bytes(script.read_bytes())
for rel in ['verification/k215/simplification/proposals/proof-core/generation/generation/DomRho8.original.lean','verification/k215/simplification/proposals/proof-core/generation/generation/shortcuts.json',*[f'dominated_implication_templates/{n}' for n in mod.TEMPLATE_PINS]]:
 p=here/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/rel).read_bytes())
lean=work/'Computability/BusyBeaver/Lean'
check('fresh_output_generation',lambda:cli([str(here/script.name),'--out',str(lean)]))
check('default_repo_relative_check',lambda:cli([str(here/script.name)],cwd='/'))
pair=lean/'BusyBeaver/ZFC/DomRho8.lean'; saved=pair.read_bytes();pair.write_bytes(saved+b'\n')
p=subprocess.run([sys.executable,str(here/script.name),'--check'],capture_output=True,text=True,timeout=20)
assert p.returncode!=0 and 'maintained source bytes differ' in p.stderr
results.append({'name':'altered_output_rejected','status':'EXPECTED_REJECTION','returncode':p.returncode,'stderr':p.stderr});pair.write_bytes(saved)
for name,pin in [*mod.PINS.items(),*mod.TEMPLATE_PINS.items()]:
 base=mod.INPUTS if name in mod.PINS else mod.TEMPLATES
 corrupt=OUT/('changed-'+name);corrupt.write_bytes((base/name).read_bytes()+b'\n')
 check('raw_pin_'+name,lambda p=corrupt,h=pin:mod.pinned_text(p,h),True)
source=(mod.INPUTS/'DomRho8.original.lean').read_text();nodes=mod.read_nodes(source);cfg=json.loads((mod.INPUTS/'shortcuts.json').read_text())
for s in cfg['shortcuts']: mod.shortcut(s,nodes)
results.append({'name':'all_13_exact_shortcut_equations','status':'PASS','detail':len(cfg['shortcuts'])})
s=cfg['shortcuts'][0];bad=copy.deepcopy(nodes);bad[s['target']]['term']='0'
check('invalid_shortcut_consequent',lambda:mod.shortcut(s,bad),True)
bad=copy.deepcopy(nodes);bad[s['major']]['guarded']=True
check('guarded_major_rejected',lambda:mod.shortcut(s,bad),True)
bad=copy.deepcopy(nodes);bad[s['minor']]['guarded']=True
check('guarded_minor_rejected',lambda:mod.shortcut(s,bad),True)
check('self_cycle_rejected',lambda:mod.ordered_closure(['a'],{'a':['a']}),True)
check('two_node_cycle_rejected',lambda:mod.ordered_closure(['a'],{'a':['b'],'b':['a']}),True)
assert not mod.unify('x',('x','0'),{})
results.append({'name':'occurs_check','status':'EXPECTED_REJECTION','detail':'x = (x -> 0) rejected'})
p=subprocess.run([sys.executable,'-O',str(script),'--out',str(ROOT/'candidate'),'--check'],capture_output=True,text=True,timeout=20)
assert p.returncode!=0 and 'requires normal Python' in p.stderr
results.append({'name':'optimized_python_rejected','status':'EXPECTED_REJECTION','returncode':p.returncode,'stderr':p.stderr})
record={'status':'ALL_PRODUCER_METADATA_CONTROLS_PASS','producer_sha256':sha(script),'script_sha256':sha(Path(__file__)),'kernel_or_compiler_invoked':False,'candidate_inputs_modified':False,'controls':results}
(OUT/'controls.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'positive':sum(x['status']=='PASS' for x in results),'negative':sum(x['status']=='EXPECTED_REJECTION' for x in results),'sha256':sha(OUT/'controls.json')}))
