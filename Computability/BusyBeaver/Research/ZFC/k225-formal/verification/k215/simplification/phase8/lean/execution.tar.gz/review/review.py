"""Independently inspect a completed phase-eight run after both endpoint audits.

No compiler or runner is invoked; predecessor caches and records are read-only.
"""
from pathlib import Path
import argparse
import json
import basis_reference
from capture import arguments, collect, FORMAL
from evidence import digest, manifest_hash, save, sha, validate


def check_providers(run, basis, done, old, predecessor_run):
    for directory, rows in ((run / 'objects', done), (basis / 'objects', old)):
        paths = list(directory.rglob('*'))
        assert all(not p.is_symlink() or p.is_file() for p in paths)
        assert {p.relative_to(directory).as_posix() for p in paths if p.is_file()} == {
            m.replace('.', '/') + '.olean' for m in rows}
    for directory, rows, reused, fresh, parent in (
            (run, done, 'phase7_hash_bound', 'phase8_fresh', basis),
            (basis, old, 'phase6_hash_bound', 'phase7_fresh', predecessor_run)):
        for module, row in rows.items():
            obj = directory / 'objects' / (module.replace('.', '/') + '.olean')
            if row['origin'] == reused:
                expected = parent / 'objects' / (module.replace('.', '/') + '.olean')
                assert obj.is_symlink() and obj.resolve(strict=True) == expected.resolve(strict=True)
            else:
                assert row['origin'] == fresh and obj.is_file() and not obj.is_symlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    arguments(parser)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), 'Refusing to overwrite a receipt'
    members = collect(args)
    owner = json.loads(members['execution/owner.json'])
    repo = Path(owner['repo'])
    checked = validate(members, repo, args.basis_repo or repo)
    # This exact published predecessor supplies the phase7 reuse-link origin.
    prior, _, _ = basis_reference.validate(args.basis_repo or repo)
    parent = Path(json.loads(prior['basis/result.json'])['audits'][0]['log']).parent.parent
    run, basis = args.run.resolve(), args.basis.resolve()
    def check_basis_records():
        for name in ('owner.json', 'result.json', 'completed.json', 'inventory.json', 'toolchain.json', 'reviewed-driver.py'):
            assert (basis / name).read_bytes() == prior['execution/' + name]
    check_basis_records()
    done = json.loads(members['execution/completed.json'])
    old = json.loads(prior['execution/completed.json'])
    inventory = json.loads(members['execution/inventory.json'])
    toolchain = json.loads(members['execution/toolchain.json'])
    result = json.loads(members['execution/result.json'])
    basis_logs = json.loads(members['execution/basis-logs.json'])
    check_providers(run, basis, done, old, parent)
    for key in ('lean', 'lake', 'Init.olean', 'project_toolchain'):
        assert sha(toolchain[key]['path']) == toolchain[key]['sha256']
    assert sha(repo / FORMAL / 'verification/k215/lean/build.py') == owner['helper_sha256']
    for path,pin in owner['producer_pins'].items():
        assert sha(repo/path)==pin
    for row in result['audits']:
        folder = Path(row['log']).parent
        obj = folder / (row['module'] + '.olean')
        assert obj.is_file() and not obj.is_symlink()
        assert sha(obj) == row['object_sha256']
        assert sha(folder / (row['module'] + '.lean')) == row['source_sha256']
        assert sha(row['source']) == row['source_sha256']
        assert sha(row['log']) == row['log_sha256']
    # Deliberately after both typed audit objects and their complete reports.
    for entry in inventory['modules']:
        module = entry['module']
        row = done[module]
        assert sha(entry['source']) == row['source_sha256']
        assert sha(run / 'objects' / (module.replace('.', '/') + '.olean')) == row['object_sha256']
        assert sha(row['log']) == row['log_sha256']
    for module, row in old.items():
        assert sha(basis / 'objects' / (module.replace('.', '/') + '.olean')) == row['object_sha256']
        assert sha(basis_logs[module]) == row['log_sha256']
    check_providers(run, basis, done, old, parent)
    assert collect(args) == members, 'Evidence changed during read-only review'
    check_basis_records()
    # Recheck toolchain after all object reads as well.
    for key in ('lean', 'lake', 'Init.olean', 'project_toolchain'):
        assert sha(toolchain[key]['path']) == toolchain[key]['sha256']
    receipt = {
        'status': 'PASS_LIVE_POST_AUDIT_REVIEW', **checked,
        'all188_objects_rehashed_after_audits': True,
        'all187_basis_objects_and_logs_unchanged': True,
        'current_inventory_exact': True, 'toolchain_and_compiler_rehashed': True,
        'evidence_manifest_sha256': manifest_hash(members),
        'reviewer_sha256': sha(__file__),
        'validator_sha256': sha(Path(__file__).with_name('evidence.py')),
        'capture_sha256': sha(Path(__file__).with_name('capture.py')),
        'basis_reference_sha256': basis_reference.REFERENCE_SHA256,
        'run': str(run), 'basis': str(basis),
        'scope': 'Read-only current sources/imports, 188 private providers, exact dependency and '
                 'saved-log hashes, compiler/toolchain and two audit objects. All188 current '
                 'and187 basis objects/logs rehashed after the audits. No compiler rerun; '
                 'prior phase7 evidence validated in place with immutable relative pins.'}
    save(args.output, receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
