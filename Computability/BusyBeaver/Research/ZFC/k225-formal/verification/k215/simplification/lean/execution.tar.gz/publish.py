from pathlib import Path
import gzip,hashlib,importlib.util,io,json,shutil,tarfile
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs');work=Path('/tmp/k215-proof-simplification/root');formal=repo/'Computability/BusyBeaver/Research/ZFC/k225-formal';dest=formal/'verification/k215/simplification/lean';dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('driver',formal/'verification/k215/lean/build.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
primary=driver.inventory(repo);union=json.loads((work/'inventory.json').read_text());done=json.loads((work/'completed.json').read_text());base=json.loads(Path('/tmp/k215-lean-complete/completed.json').read_text());names={e['module']for e in union};selected={e['module']for e in primary['modules']};rows=[];warnings=0
assert len(names)==215 and len(selected)==201
for e in union:
 m=e['module'];r=done[m];obj=work/'objects'/(m.replace('.','/')+'.olean')
 assert r['status']=='PASS'and sha(e['source'])==r['source_sha256']and sha(obj)==r['object_sha256'],m
 assert r['dependencies']=={d:done[d]['object_sha256']for d in e['imports']if d in names},m
 prior=base.get(m);reused=prior==r
 if reused:
  log=Path(r['log']);origin='fresh baseline at 613f9cf28ac36eaa929f7ef909b0eb7905facc5d'
 else:
  candidates=[]
  for a in work.glob('attempt-*'):
   p=a/'record.json'
   if not p.exists():continue
   t=json.loads(p.read_text())
   if all(t.get(k)==r.get(k)for k in ['module','source_sha256','dependencies','log_sha256'])and t['status']=='PASS':candidates.append(a)
  assert candidates,m
  log=sorted(candidates)[-1]/'compiler.log';origin='incremental recompilation in execution.tar.gz/'+str(log.parent.relative_to(work))
 assert sha(log)==r['log_sha256'],m
 count=log.read_text().count('warning:')
 if m in selected:warnings+=count
 rows.append({'module':m,'source':str(Path(e['source']).relative_to(repo)),'source_sha256':r['source_sha256'],'imports':e['imports'],'object_sha256':r['object_sha256'],'dependencies':r['dependencies'],'compilation_origin':origin,'log_sha256':r['log_sha256'],'warnings':count,'primary_endpoint':m in selected})
assert all(sha(work/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']for m,r in done.items()if m in names)
assert all(sha(Path('/tmp/k215-lean-complete/workspace/.lake/build/lib/lean')/(m.replace('.','/')+'.olean'))==r['object_sha256']for m,r in base.items())
# Preserve actual runs and failed candidates; no compiler objects are bundled.
files=[]
for pattern in ['attempt-*/*','audit-001/*','generators-final-v2/result.json']:
 files.extend(p for p in work.glob(pattern)if p.is_file()and p.suffix not in {'.olean','.ilean','.ir'})
files.extend(work/x for x in ['check.py','audit.py','regenerate_check.py','publish.py','result.json'])
files=sorted(set(files));index={str(p.relative_to(work)):sha(p)for p in files}
with (dest/'execution.tar.gz').open('wb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for p in files:
    data=p.read_bytes();entry=tarfile.TarInfo(str(p.relative_to(work)));entry.size=len(data);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
for name in ['EndpointAudit215','K215Audit']:
 for ext in ['lean','json','log']:shutil.copyfile(work/'audit-001'/f'{name}.{ext}',dest/f'{name}.{ext}')
shutil.copyfile(work/'generators-final-v2/result.json',dest/'generators.json')
summary={'status':'PASS_INCREMENTAL_KERNEL','baseline_commit':'613f9cf28ac36eaa929f7ef909b0eb7905facc5d','primary_project_modules':201,'additional_legacy_modules':14,'typed_audits':2,'typed_audits_warnings':0,'primary_project_warnings':warnings,'external_imports':primary['external_imports'],'new_full_replay':False,'baseline_objects_unchanged':True,'compiler_sha256':sha('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean'),'execution_archive_sha256':sha(dest/'execution.tar.gz'),'module_evidence':rows}
(dest/'result.json').write_text(json.dumps(summary,indent=2)+'\n');(dest/'execution-index.json').write_text(json.dumps(index,indent=2)+'\n');print('PASS',len(rows),'selected modules,',warnings,'primary source warnings, archive',sum(p.stat().st_size for p in dest.iterdir()if p.is_file()),'bytes')
