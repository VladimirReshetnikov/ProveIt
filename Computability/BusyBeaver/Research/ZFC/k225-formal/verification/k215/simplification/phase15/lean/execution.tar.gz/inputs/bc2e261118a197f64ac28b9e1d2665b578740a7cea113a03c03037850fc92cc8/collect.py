"""Capture phase15's terminal records after source peer and explicit authorization."""
from pathlib import Path
from contextlib import ExitStack
import argparse,fcntl,gzip,io,json,tarfile
import basis,packet
S=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
RUNS=[packet.FIRST,packet.SECOND,packet.MAIN,packet.COMP]
def collect(repo,out):
 assert not out.exists()and not out.is_symlink()
 freeze=read(S/'freeze.json');assert freeze['status']=='FROZEN_PUBLICATION_HELPERS_NOT_EXECUTED'
 for n,p in freeze['files'].items():assert packet.sha(S/n)==p
 cfg=read(S/'config.json');assert cfg['status']=='FROZEN_COMPLETED_PHASE15_INPUTS'
 with ExitStack()as stack:
  for root in RUNS:
   lock=stack.enter_context((Path(root)/'output.lock').open('a'));fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  loaded=basis.load(repo);prior,_,_=loaded;members,routes,hashes={},{},{}
  for k,b in prior.items():hashes.setdefault(packet.digest(b),('phase14',k))
  def put(n,b):
   packet.safe(n)
   if n in members:assert members[n]==b
   members[n]=b;hashes.setdefault(packet.digest(b),('packet',n))
  def add(path,data=None,name=None,force=False):
   path=str(path);b=Path(packet.historical_file(path,cfg['historical_inputs'])).read_bytes()if data is None else data;pin=packet.digest(b)
   if path in routes:assert routes[path]['sha256']==pin;return
   if force or pin not in hashes:
    k=name or 'inputs/'+pin+'/'+Path(path).name;put(k,b);storage='packet'
   else:storage,k=hashes[pin]
   routes[path]={'storage':storage,'key':k,'sha256':pin,'bytes':len(b)}
  for path,row in cfg['historical_inputs'].items():
   assert packet.sha(row['snapshot'])==row['sha256'];add(path,Path(row['snapshot']).read_bytes());add(row['snapshot'])
  tool=read(Path(packet.MAIN)/'toolchain.json')
  binary={v['path']:v['sha256']for k,v in tool.items()if k in {'lean','lake','Init.olean'}}
  ref=read(S/'basis-reference.json')
  binary.update({str(repo/ref['repository_relative_directory']/n):p['sha256']for n,p in ref['files'].items()})
  for root in [packet.OLD,packet.BASE,packet.BASE_COMP]+RUNS:
   binary.update({root+'/objects/'+m.replace('.','/')+'.olean':r['object_sha256']for m,r in read(Path(root)/'completed.json').items()})
  for rootstr,label in zip(RUNS,['failed-primary1','failed-primary2','execution','compatibility']):
   root=Path(rootstr);partial=rootstr in [packet.FIRST,packet.SECOND]
   assert (not(root/'result.json').exists())if partial else(read(root/'result.json')['status']=='PASS')
   names=['before.json','inventory.json','completed.json','toolchain.json']+([]if partial else['result.json'])
   for n in names:add(root/n,name=label+'/'+n,force=True)
   before=read(root/'before.json');inv=read(root/'inventory.json');done=read(root/'completed.json')
   for p,pin in before['inputs'].items():
    if p in binary:assert binary[p]==pin;continue
    if p not in cfg['historical_inputs']:add(p)
    assert routes[p]['sha256']==pin,p
   for row in inv['modules']:add(row['source'])
   for m,r in done.items():
    add(r['log'])
    if r['origin']=='candidate_fresh':
     add(r['source']);add(Path(r['log']).parent/'record.json');add(Path(r['log']).parent/Path(r['source']).name)
   for attempt in sorted((root/'attempts').iterdir()):
    assert attempt.is_dir()and not attempt.is_symlink()
    for p in sorted(attempt.iterdir()):
     assert p.is_file()and not p.is_symlink();packet.safe(p.name);add(p,name=label+'/attempts/'+attempt.name+'/'+p.name)
   if partial:
    module='BusyBeaver.ZFC.KQ1ZF'if rootstr==packet.FIRST else'QuotientSharing15Api';add(root/'workspace'/(module.replace('.','/')+'.lean'))
   else:
    for r in read(root/'result.json')['audits']:
     q=root/('audit-'+r['module'])
     for n in [r['module']+'.lean',r['module']+'.log',r['module']+'.json']:add(q/n,name=label+'/audits/'+n,force=True)
     add(r['source'])
  for p,row in cfg['files'].items():
   b=Path(p).read_bytes();assert packet.digest(b)==row['sha256']and len(b)==row['bytes'];add(p,b)
  for r in cfg['adoption']['raw']['files']:
   if r['before_snapshot']is not None:add(repo/r['before_snapshot'])
   b=Path(r['candidate']).read_bytes();assert packet.digest(b)==r['after_sha256']and (repo/r['path']).read_bytes()==b
   add(r['candidate'],b);put('adoption/'+r['path'],b)
  for n in packet.HELPERS+['config.json','freeze.json','controls-result.json','controls.stdout.log','controls.stderr.log']:
   put('review/'+n,(S/n).read_bytes())
  put('path-map.json',packet.dump(routes))
  checked=packet.validate(members,repo,loaded,current_repo=repo)
  # Rehash exact live providers after the complete portable validation.
  providers={};before_counts={};done_by={root:read(Path(root)/'completed.json')for root in RUNS}
  for rootstr in RUNS:
   root=Path(rootstr);inv=read(root/'inventory.json');done=done_by[rootstr];providers[rootstr]=len(done);before=read(root/'before.json');before_counts[rootstr]=len(before['inputs'])
   for p,pin in before['inputs'].items():assert packet.sha(cfg['historical_inputs'].get(p,{}).get('snapshot',p))==pin,p
   for p in before['absent_inputs']:
    if p==packet.ROOT+'/'+packet.CREATED:assert packet.sha(p)==packet.ADOPTIONS[packet.CREATED]
    else:packet.absent(p)
   for row in inv['modules']:
    assert packet.sha(packet.historical_file(row['source'],cfg['historical_inputs']))==row['source_sha256']
    if row['module']not in done:continue
    m=row['module'];r=done[m];obj=root/'objects'/(m.replace('.','/')+'.olean')
    assert packet.sha(obj)==r['object_sha256']and packet.sha(r['log'])==r['log_sha256']
    assert r['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
    for parent in obj.parents:
     assert not parent.is_symlink()
     if parent==root/'objects':break
    if r['origin']=='candidate_fresh':
     assert packet.sha(r['source'])==row['source_sha256']
     if rootstr==packet.SECOND and m in done_by[packet.FIRST]:assert obj.is_symlink()and obj.readlink()==Path(packet.FIRST)/'objects'/(m.replace('.','/')+'.olean')
     elif rootstr==packet.MAIN and m in done_by[packet.SECOND]:assert obj.is_symlink()and obj.readlink()==Path(packet.SECOND)/'objects'/(m.replace('.','/')+'.olean')
     else:assert not obj.is_symlink()
    else:assert obj.is_symlink()
   if rootstr in [packet.FIRST,packet.SECOND]:assert not(root/'result.json').exists()
   else:
    for r in read(root/'result.json')['audits']:
     q=root/('audit-'+r['module']);assert packet.sha(q/(r['module']+'.olean'))==r['object_sha256'];assert packet.sha(q/(r['module']+'.lean'))==r['source_sha256'];assert packet.sha(r['log'])==r['log_sha256'];packet.named_reports(Path(r['log']).read_bytes(),packet.AUDIT_NAMES[r['module']])
  for p,row in cfg['files'].items():assert packet.sha(p)==row['sha256']and Path(p).stat().st_size==row['bytes']
  for p,pin in packet.ADOPTIONS.items():assert packet.sha(repo/p)==pin
  for p,pin in packet.PRIOR_ADOPTIONS.items():assert packet.sha(repo/p)==pin
  for p in packet.RETAINED_ABSENCES:packet.absent(repo/p)
  for n,pin in freeze['files'].items():assert packet.sha(S/n)==pin
  post={'status':'PASS_LIVE_POSTCHECK','providers':providers,'before_input_counts':before_counts,'combined_project_sources':199,'endpoint_audit_objects':2,'both_failed_primary_attempts_preserved':True,'resumed_provider_counts':[87,193],'selected_primary_fresh_by_attempt':[19,25,1],'all_live_sources_objects_logs_dependencies_rehashed':True,'historical_inputs':cfg['historical_inputs'],'current_adoptions':packet.ADOPTIONS,'unchanged_prior_adoptions':packet.PRIOR_ADOPTIONS,'retained_absences':packet.RETAINED_ABSENCES,'created_path':packet.CREATED,'scope':'Live byte postcheck after validation; original failed attempts and before-input records unchanged, nine replaced inputs use exact historical snapshots, newly created PowerSets checked present separately from original absence.'}
  put('review/live-postcheck.json',packet.dump(post));index=packet.manifest(members);out.mkdir(parents=True)
  with (out/'execution.tar.gz').open('wb')as raw:
   with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as zipped:
    with tarfile.open(fileobj=zipped,mode='w')as archive:
     for n,b in sorted(members.items()):
      info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(b))
  (out/'index.json').write_bytes(packet.dump(index))
  summary={**checked,'status':'PASS_COLLECTED_PHASE15','archive_sha256':packet.sha(out/'execution.tar.gz'),'index_sha256':packet.sha(out/'index.json'),'archive_members':len(members),'live_postcheck':post}
  (out/'result.json').write_bytes(packet.dump(summary))
  for n in ['basis.py','basis-reference.json','packet.py','review_saved.py','README.md']:(out/n).write_bytes((S/n).read_bytes())
  print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--basis-repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();collect(a.basis_repo,a.out)
