from pathlib import Path
import json,hashlib,re
S=Path('/tmp/k215-phase15-check'); O=Path('/tmp/k215-phase15-runner-peer')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=read(S/'freeze.json');assert sha(S/'freeze.json')=='bf7ee51d71e671876ca5b1b8c4933493cee3907c993b36b2658e2f4a6196cb06'
for n,h in f['files'].items():assert sha(S/n)==h,n
for n,h in f['source_packets'].items():assert sha(n)==h,n
boundary=read(S/'producer-boundary.json')
for n,h in boundary['present_inputs'].items():assert sha(n)==h,n
for n in boundary['absent_inputs']:assert not Path(n).exists() and not Path(n).is_symlink(),n
prior=read('/tmp/k215-phase15-check-pre-pin-v1/producer-boundary.json'); added=set(boundary['present_inputs'])-set(prior['present_inputs']);assert len(added)==1
p=added.pop();assert p.endswith('/generate_l2k222.py') and boundary['present_inputs'][p]=='c720d5bf58d4c9119bfb6a6d206451e18c7287caf0518c8a666b38cc0b2e74f6'
b=dict(boundary);b['present_inputs']=dict(b['present_inputs']);del b['present_inputs'][p];assert b==prior
old={};oldrec={};origin={}
for path in ['/tmp/k215-phase14-check/compatibility-run1','/tmp/k215-phase14-check/primary-run2']:
 d=Path(path);result=read(d/'result.json');assert result['status']=='PASS'
 assert sha(d/'inventory.json')==result['inventory_sha256'] and sha(d/'completed.json')==result['completed_sha256']
 rec=read(d/'completed.json')
 for r in read(d/'inventory.json')['modules']:
  m=r['module']
  if m in old:assert (old[m]['source_sha256'],old[m]['imports'],oldrec[m]['object_sha256'])==(r['source_sha256'],r['imports'],rec[m]['object_sha256'])
  old[m]=r;oldrec[m]=rec[m];origin[m]=path
assert len(old)==207
plans={}
for name,filename in [('primary','primary-map.json'),('compatibility','compatibility-template.json')]:
 plan=read(S/filename);inventory=read(S/'plan1'/f'{name}-inventory.json');rows=inventory['modules'];by={r['module']:r for r in rows};assert len(rows)==len(by)
 assert list(by)==plan['expected']['modules'];assert all(d=='Init' or d in by for r in rows for d in r['imports'])
 seen=set()
 for r in rows:
  assert sha(r['source'])==r['source_sha256'];assert set(r['imports'])-{'Init'}<=seen;seen.add(r['module'])
 changed={m for m,r in by.items() if m not in old or (r['source_sha256'],r['imports'])!=(old[m]['source_sha256'],old[m]['imports'])};forced=set(changed)
 while True:
  q=forced|{m for m,r in by.items() if set(r['imports'])&forced}
  if q==forced:break
  forced=q
 assert sorted(changed)==plan['expected']['changed'] and sorted(forced)==plan['expected']['forced']
 for r in plan['modules']:
  assert sha(r['source'])==r['source_sha256'];assert r['imports']==by[r['module']]['imports']
  if r['module']in old:assert r['before_sha256']==old[r['module']]['source_sha256']
  if 'report_axioms'in r:
   txt=Path(oldrec[r['module']]['log']).read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
   assert r['reports']==[n for n,a in reports]
   assert [set(a)for a in r['report_axioms']]==[{s.strip()for s in a.split(',')if s.strip()}for n,a in reports]
 plans[name]=(by,forced,plan)
pb,pf,pp=plans['primary']; cb,cf,cp=plans['compatibility'];assert len(pb)==194 and len(pf)==45
assert all(origin[m].endswith('primary-run2') for m in set(pb)-pf)
def closure_equal(m):
 if m=='Init':return True
 a=cb[m];b=pb.get(m)
 return bool(b and (a['source_sha256'],a['imports'])==(b['source_sha256'],b['imports']) and all(closure_equal(d)for d in a['imports']))
secondary={m for m in cb if closure_equal(m)};oldreuse={m for m in cb if m not in secondary and m not in cf};fresh=set(cb)-secondary-oldreuse
assert (len(cb),len(fresh),len(secondary),len(oldreuse))==(71,6,54,11)
summary=read(S/'plan-summary.json');assert sorted(fresh)==summary['compatibility_fresh'] and sorted(secondary)==summary['compatibility_primary_reuse'] and sorted(oldreuse)==summary['compatibility_old_reuse']
new=read(S/'clients.json');assert sum(len(r['reports'])for r in new)==28 and all('report_axioms'not in r for r in new)
assert len(set(pb)|set(cb))==211
project=lambda s:{m for m in s if '.'in m}
assert len(project(set(pb)|set(cb)))==199
sites=[m for m in pb if '.KSites215Batch' in m];assert len(sites)==9 and not set(sites)&pf
controls=read(S/'controls-result.json');assert controls['runner_sha256']==sha(S/'build.py') and controls['controls_sha256']==sha(S/'controls.py') and (controls['positive_count'],controls['negative_count'])==(7,12)
receipt={'status':'PASS_INDEPENDENT_READ_ONLY_SOURCE_AND_METADATA_PEER','freeze_sha256':sha(S/'freeze.json'),'runner_sha256':sha(S/'build.py'),'boundary_sha256':sha(S/'producer-boundary.json'),'finalizer_sha256':sha(S/'finalize_compatibility.py'),'files_rehashed':len(f['files']),'present_inputs_rehashed':len(boundary['present_inputs']),'baseline_providers':207,'primary':{'providers':194,'forced_fresh':45,'phase14_primary_reuse':149},'compatibility':{'providers':71,'fresh':6,'new_primary_reuse':54,'old_phase14_reuse':11},'combined_project_modules':199,'new_named_reports':28,'nine_site_batches_not_forced':sites,'owner_controls_read':{'positive':7,'negative':12},'findings':[],'scope':'Full serial runner/finalizer and control source read; frozen pins, input boundary, old profile arrays, graph closure/topology/source forcing and reuse partitions independently checked as inert data. No compiler, candidate producer, runner/finalizer/control execution; no actual proof-result or canonical adoption claim.','checker_sha256':sha(__file__)}
(O/'review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
