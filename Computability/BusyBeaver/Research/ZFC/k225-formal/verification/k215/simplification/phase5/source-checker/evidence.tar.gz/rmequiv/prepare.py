from pathlib import Path
import difflib
P=Path(__file__).resolve().parent
original=Path('/home/codex/.codex/worktrees/ec20/Proofs/Computability/BusyBeaver/Lean/BusyBeaver/ZFC/RMEquiv.lean').read_text()
(P/'RMEquiv-original.lean').write_text(original)
a=original.index('theorem fwd ');b=original.index('/-! ## Path runs are simulated',a)
old=original[a:b]
new=old[:old.index('  | carBrk1 ')] + '''  -- All exits through the car use the same zero-padded child path.
  | carBrk1 n R R' h ih
  | carBrkS n k R R' h ih
  | carCont n k R R' h ih
  | carHalt n R R' h ih =>
      intro Q P F E
      simpa only [Reaches, target, brk_car1, brk_carS, cont_car] using
        ih (Q ++ [false]) P (fol_snoc false F) (E.trans (ipeq_snoc_false Q).symm)
  -- Once the car finishes normally, prepend its path run to the cdr's run.
  | cdrNormal n R R1 R' h1 h2 ih1 ih2
  | cdrBrk n k R R1 R' h1 h2 ih1 ih2
  | cdrContS n k R R1 R' h1 h2 ih1 ih2
  | cdrHalt n R R1 R' h1 h2 ih1 ih2 =>
      intro Q P F E
      obtain ⟨N1, P1, hr1, E1⟩ :=
        ih1 (Q ++ [false]) P (fol_snoc false F) (E.trans (ipeq_snoc_false Q).symm)
      simp only [target, incPath_snoc_false] at E1
      have hcdr := reaches_pre hr1 (ih2 (Q ++ [true]) P1 (fol_snoc true F) E1)
      first
      | simpa only [Reaches, target, brk_cdr, cont_cdrS] using hcdr
      | obtain ⟨N2, P2, hr2, E2⟩ := hcdr
        simp only [target, incPath_snoc_true] at E2
        exact ⟨N2, P2, hr2, E2.trans (ipeq_snoc_false _)⟩
  | cdrCont1 n R R1 R2 R' x h1 h2 h3 ih1 ih2 ih3 =>
      intro Q P F E
      obtain ⟨N1, P1, hr1, E1⟩ :=
        ih1 (Q ++ [false]) P (fol_snoc false F) (E.trans (ipeq_snoc_false Q).symm)
      simp only [target, incPath_snoc_false] at E1
      obtain ⟨N2, P2, hr2, E2⟩ := ih2 (Q ++ [true]) P1 (fol_snoc true F) E1
      simp only [target, cont_cdr1] at E2
      exact reaches_pre hr1 (reaches_pre hr2 (ih3 Q P2 F E2))

'''
s=original[:a]+new+original[b:]
(P/'source/BusyBeaver/ZFC/RMEquiv.lean').write_text(s)
(P/'source.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='current/RMEquiv.lean',tofile='candidate/RMEquiv.lean')))
print({'old':len(original.splitlines()),'new':len(s.splitlines()),'fwd_before':len(old.splitlines()),'fwd_after':len(new.splitlines())})
