from pathlib import Path
import importlib.util
import json
import os
import re
import shutil

repo = Path('/home/codex/.codex/worktrees/ec20/Proofs')
work = Path('/tmp/k215-sites-compact')
formal = repo / 'Computability/BusyBeaver/Research/ZFC/k225-formal'
spec = importlib.util.spec_from_file_location('driver', formal / 'verification/k215/lean/build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
lean = Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
records = []
for name, cache in [('before', Path('/tmp/k215-proof-simplification/root/objects')),
                    ('after', work / 'run1/objects')]:
    target = work / ('audit-' + name)
    target.mkdir(exist_ok=False)
    source = target / 'Audit.lean'
    shutil.copyfile(work / source.name, source)
    obj = target / 'Audit.olean'
    env = os.environ.copy()
    env['LEAN_PATH'] = str(cache)
    env['LEAN_NUM_THREADS'] = '1'
    command = [str(lean), '-j1', '-M4096', '--root=' + str(target), '-o', str(obj), str(source)]
    record = {'source_sha256': driver.sha(source), 'command': command,
              'compiler_sha256': driver.sha(lean),
              'site_object_sha256': driver.sha(cache / 'BusyBeaver/ZFC/KSites215.olean')}
    ok = driver.run_locked(command, repo, env, Path('/tmp/proveit-k215-proof-build.lock'),
                           target / 'compiler.log', 120, record, target / 'record.json')
    log = (target / 'compiler.log').read_text()
    reports = re.findall(r'depends on axioms: \[([^]]*)\]', log)
    ok = ok and 'warning:' not in log and 'sorryAx' not in log and len(reports) == 2
    record['status'] = 'PASS' if ok else 'FAIL'
    record['reports'] = reports
    if ok:
        record['object_sha256'] = driver.sha(obj)
    (target / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    print(name, record['status'], reports, flush=True)
    if not ok:
        print(log, flush=True)
        raise SystemExit(1)
assert records[0]['reports'] == records[1]['reports']
(work / 'api-result.json').write_text(json.dumps({
    'status': 'PASS', 'unchanged_public_theorems': ['all_sites', 'covered'],
    'identical_axiom_reports': records[1]['reports'], 'records': records,
}, indent=2) + '\n')
