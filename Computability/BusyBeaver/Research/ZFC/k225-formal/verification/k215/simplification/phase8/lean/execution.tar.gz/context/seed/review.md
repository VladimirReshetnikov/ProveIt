# Shared seed bundle semantics: source-only adaptation

This candidate adapts commit `639e34777e269af05ce380733a7f43b5fec9902b` to the currently checked phase-seven pair. It is not compiled or adopted. The unchanged current phase-six semantic round trip remains in place; this refactor does not take credit for removing its earlier three formula inductions.

## Mathematical change

The two old directions independently unpacked the same request, closure, private container and negated core. `BundleSemantics.req_iff` reads the request as an answered output; `clos_iff` reads closure as the output/subset condition. `matrix_marker` removes the private container assignment using `sat_dec_agree`, rather than treating the numeric matrix code as an arbitrary fresh variable. One `bundle_iff_seed` combines those facts for distinct input/output roles. The old public directions then use its two projections.

The original unrestricted forward endpoint still accepts coincident roles. In that case the second assignment to `a` overwrites the first, so the matrix depends only on the output. The separate `diagonal_bundle_of_seed` uses an existing closure witness only to prove that each container member is an output; the root request supplies every later request because the input assignment is immaterial. It never applies the distinct-role equivalence when `a = b`.

No syntactic encode/decode inverse is asserted. Code zero still decodes to truth; `sat_dec_agree` retains its zero case. Irreflexivity remains an explicit premise to interpret encoded negation. `neg_forall_imp` is ordinary classical quantifier duality, valid also for an empty domain. The explicit valuation and seed witness remain in the endpoint hypotheses; no inhabitance or well-foundedness premise is added.

`seedProp_congr` states extensionality of the seed property under pointwise logical equivalence. It replaces the final repeated unpack/repack in `seed_eqFree`; the double-negation code bound, named bundle derivation, and `Code254Models.sat_encode_decode` applications are unchanged.

## API and dependency boundary

All executable definitions keep the same bodies: `SeedProp`, `matrixRel`, `negNF`, `reqNF`, `closNF`, `bundleNF`, and `DerivableNF`. Existing public endpoints `bundle_of_seed`, `seed_of_bundle`, `seed_eqFree`, and `derivable_named_bundle` keep their complete assumptions and conclusions. The first endpoint writes explicit `mem`/`hirr` parameters previously supplied by its section; that changes presentation, not the elaborated parameter order/type.

The four old top-level helpers `update_idem`, `update_self`, `sat_req`, and `matrix_iff` become unused after this factoring. The maintained-source census records their callers before removing them from `KSeedModel222`; historical proposal copies remain untouched. The first two mathematical laws remain available in the new `BundleSemantics` namespace, and request semantics is `BundleSemantics.req_iff`. No compatibility aliases are added for unused old exports.

Imports are unchanged. The new shared statements live in `KSeed222`; there is no module added to the primary closure. `KSeed222` retains the upstream elaboration option `maxRecDepth 2048`; kernel/proof semantics do not depend on it. The current `KLower.seedProp_congr` has its own namespace and remains untouched; its locally resolved use is distinct from the new `KSeed222.seedProp_congr`.

## Review and next check

The exact upstream mathematical source peer is preserved separately. This author independently read both original directions, all proposed shared lemmas, `KCode222` literal request/closure/bundle definitions, the zero-aware decoder semantics, and the round-trip theorem. The adaptation changes only unused helper removal and attribution/doc comments beyond that proposal. It does not introduce new axioms, admissions, unsafe evaluation, or a compiler shortcut.

The source comparison and caller census are ordinary metadata checks, not kernel evidence. Root should compile the frozen pair in dependency order and inspect the axiom reports for `BundleSemantics.bundle_iff_seed`, `bundle_of_seed`, `seed_of_bundle`, and `seed_eqFree`, followed by the affected closure. The two direction wrappers and equality-free endpoint are the required arbitrary-code API gates.
