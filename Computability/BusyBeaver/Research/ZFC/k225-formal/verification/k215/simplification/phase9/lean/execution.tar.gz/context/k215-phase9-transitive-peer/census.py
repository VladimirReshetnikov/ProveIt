from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent;B=Path('/tmp/k215-proof-phase8/lean-run1');F=Path('/tmp/k215-phase9-main/full-run1');I=Path('/tmp/k215-phase9-main/isolated-run2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
old={r['module']:r for r in read(B/'inventory.json')['modules']};now={r['module']:r for r in read(F/'inventory.json')['modules']};prior=read(B/'completed.json');done=read(F/'completed.json');isol={r['module']:r for r in read(I/'inventory.json')['modules']}
assert len(old)==188 and len(now)==197
changed={m for m,r in now.items()if m not in old or (r['source_sha256'],r['imports'])!=(old[m]['source_sha256'],old[m]['imports'])}
closure={}
def close(m):
 if m not in closure:closure[m]={m}|set().union(*(close(d)for d in now[m]['imports']if d!='Init'))
 return closure[m]
for m in now:close(m)
affected={m for m in now if closure[m]&changed}
iso_ok={m for m in now if closure[m]<=set(isol)and all((now[d]['source_sha256'],now[d]['imports'])==(isol[d]['source_sha256'],isol[d]['imports'])for d in closure[m])}
required=affected-iso_ok
incorrect=sorted(m for m in affected if done[m]['origin']=='phase8_checked')
sites=sorted(m for m in now if m.startswith('BusyBeaver.ZFC.KSites215Batch'))
assert len(sites)==9 and set(sites)<=set(incorrect)
M='BusyBeaver.ZFC.KFastSites215';assert done[M]['object_sha256']==prior[M]['object_sha256'];assert M in affected
assert 'BusyBeaver.ZFC.KSim'in closure[M] and 'BusyBeaver.ZFC.KRuntimeCore'in closure[M]
paths={}
for m in sites:
 def walk(n):
  if n in changed:return[n]
  for d in now[n]['imports']:
   if d!='Init'and closure[d]&changed:return[n]+walk(d)
 paths[m]=walk(m)
r={'status':'REJECT_FULL_RUN1_AS_NEW_ENDPOINT_EVIDENCE','reason':'Transitive changed computational source was hidden by a byte-identical intermediate object; phase8 site proofs were reused without rechecking their changed source closure. Existing raw process PASS statuses are preserved, not accepted as updated coverage.','changed_or_new_modules':sorted(changed),'transitively_affected':sorted(affected),'affected_count':len(affected),'isolated_source_import_closure_exact':sorted(iso_ok),'must_compile_against_current_source_closure':sorted(required),'required_fresh_count':len(required),'baseline_reused_affected_modules':incorrect,'all_nine_site_batches_require_fresh':sites,'site_to_changed_source_paths':paths,'byte_identical_intermediate':{'module':M,'sha256':done[M]['object_sha256']},'pins':{str(p):sha(p)for p in[B/'inventory.json',B/'completed.json',F/'inventory.json',F/'completed.json',F/'result.json',I/'inventory.json',I/'completed.json',Path(__file__)]},'compiler_invoked':False,'limit':'Read-only source/import graph census; no repaired run accepted yet.'}
(O/'census.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items()if k not in['pins','site_to_changed_source_paths','isolated_source_import_closure_exact']},indent=2))
