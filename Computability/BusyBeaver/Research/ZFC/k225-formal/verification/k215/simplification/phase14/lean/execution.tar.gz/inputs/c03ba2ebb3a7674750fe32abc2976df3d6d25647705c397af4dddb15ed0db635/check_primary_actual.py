"""Own read-only terminal review: no supplied runner or compiler is invoked."""
from pathlib import Path
import json,hashlib,re,collections,copy
S=Path('/tmp/k215-phase14-check');T=Path('/tmp/k215-phase14-retry');R=S/'primary-run2';O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
assert sha(T/'freeze.json')=='cf22ecb2057efdcdf3035b932153ed399d2f278c6f19d07d18301a0f13554dee'
for p,h in read(T/'freeze.json')['files'].items():assert sha(T/p)==h
result=read(R/'result.json');assert sha(R/'result.json')=='3454f69d71477171f20d91733093821fa3198253dece63802c59d045bf3991df'
assert result['status']=='PASS' and result['runner_sha256']==sha(S/'build.py') and result['map_sha256']==sha(T/'primary-map.json')
for n,k in [('inventory.json','inventory_sha256'),('completed.json','completed_sha256')]:assert sha(R/n)==result[k]
iv=read(R/'inventory.json');done=read(R/'completed.json');plan=read(T/'primary-map.json');rows={r['module']:r for r in iv['modules']};plans={r['module']:r for r in plan['modules']}
assert list(rows)==plan['expected']['modules'] and len(rows)==len(done)==190 and set(rows)==set(done)
base=Path('/tmp/k215-phase13-upstream-check/primary-run1');baseRows={r['module']:r for r in read(base/'inventory.json')['modules']};baseDone=read(base/'completed.json');prior=read(S/'primary-run1/completed.json')
changed={m for m,r in rows.items()if m not in baseRows or(r['source_sha256'],r['imports'])!=(baseRows[m]['source_sha256'],baseRows[m]['imports'])};affected=set(changed)
for m,r in rows.items():
 if set(r['imports'])&affected:affected.add(m)
assert sorted(changed)==plan['expected']['changed']==result['source_changed_modules']
assert sorted(affected)==plan['expected']['forced']==sorted(result['fresh_modules'])==result['force_basis_rebuild_modules'] and len(affected)==66
counts=collections.Counter();warnings=collections.Counter();profiles={};exact_cmd=[]
pat=r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)"
norm=lambda rs:[(n,sorted(x.strip()for x in a.split(',')if x.strip()))for n,a in rs]
for m,row in rows.items():
 r=done[m];counts[r['origin']]+=1
 assert r['status']=='PASS'and r.get('exit_code',0)==0 and not r.get('timed_out',False)
 assert sha(row['source'])==row['source_sha256']==r['source_sha256']
 imports=[w for g in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',Path(row['source']).read_text())for w in g.split()];assert imports==row['imports']
 assert r['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 assert sha(R/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256'] and sha(r['log'])==r['log_sha256']
 txt=Path(r['log']).read_text();assert 'error:'not in txt and 'sorryAx'not in txt
 reps=re.findall(pat,txt);assert all(set(a)<={'propext','Classical.choice','Quot.sound'}for _,a in norm(reps))
 warnings[r['origin']]+=txt.count('warning:')
 if m in plans and'reports'in plans[m]:
  assert [n for n,a in reps]==plans[m]['reports'] and 'warning:'not in txt
  if'report_axioms'in plans[m]:assert [set(a)for _,a in norm(reps)]==[set(a)for a in plans[m]['report_axioms']]
  profiles[m]=norm(reps)
 if r['origin']=='candidate_fresh':
  assert m in affected and sha(r['source'])==r['source_sha256'];run=R if m=='ProfileTC14Api'else S/'primary-run1'
  assert r['command']==['/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean','-j1','-M12288','--root='+str(run/'workspace'),'-o',str(run/'objects'/(m.replace('.','/')+'.olean')),str(run/'workspace'/(m.replace('.','/')+'.lean'))]
  assert r['timeout_seconds']==120 and r['memory_mebibytes']==12288
  assert sha(r['command'][0])==r['compiler_sha256']=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
  assert r['helper_sha256']=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
  if m!='ProfileTC14Api':assert r==prior[m]
  exact_cmd.append(m)
 else:
  assert r['origin']=='phase13_primary_checked'and m not in affected
  b=copy.deepcopy(baseDone[m]);b['origin']='phase13_primary_checked';assert r==b
assert counts=={'candidate_fresh':66,'phase13_primary_checked':124}
assert set(prior)==set(done)-{'ProfileTC14Api'} and len([m for m in exact_cmd if m!='ProfileTC14Api'])==65
assert not(S/'primary-run1/result.json').exists();assert read(S/'primary-run1/attempts/066-ProfileTC14Api/record.json')['status']=='FAIL'
for p,h in read(R/'before.json')['inputs'].items():assert sha(p)==h,p
for p in read(R/'before.json')['absent_inputs']:assert not Path(p).exists() and not Path(p).is_symlink()
old=read(base/'result.json')['audits'];assert len(old)==len(result['audits'])==2
for r,b in zip(result['audits'],old):
 name=r['module'];dr=R/('audit-'+name)
 assert r['status']=='PASS'and r['exit_code']==0 and not r['timed_out']
 assert sha(r['source'])==sha(dr/(name+'.lean'))==r['source_sha256']==b['source_sha256']
 assert sha(r['log'])==r['log_sha256']and sha(dr/(name+'.olean'))==r['object_sha256']
 txt=Path(r['log']).read_text();assert all(x not in txt for x in ['error:','warning:','sorryAx']);assert norm(re.findall(pat,txt))==norm(r['named_reports'])==norm(b['named_reports'])
 assert r['dependencies']=={m:v['object_sha256']for m,v in done.items()}
 assert '-j1'in r['command']and'-M12288'in r['command']and r['timeout_seconds']==120 and r['memory_mebibytes']==12288
for n in ['retry-initialize-outer.json','primary-run2-outer.json','finalizer-outer.json']:
 r=read(Path('/tmp/k215-phase14-execution')/n);assert r['exit_code']==0
 for k in ['stdout','stderr']:assert sha(r[k])==r[k+'_sha256']
new=read(T/'compatibility-final-map.json');assert sha(T/'compatibility-final-map.json')=='c25f8c86ea110fa37797c354e8d213c304a5cc6c7cfb75606d6d6f843f955cad'
expected=read(S/'compatibility-template.json');expected['reuse_ledger']={'directory':str(R),**{n:sha(R/n)for n in ['result.json','inventory.json','completed.json']}};assert new==expected
compat={r['module']:r for r in read(S/'plan1/compatibility-inventory.json')['modules']};common=set(compat)&set(rows);fresh=set(compat)-common-{'BusyBeaver.ZFC.Dag254'}
assert len(compat)==70 and len(common)==53 and len(fresh)==16
for m in common:assert (compat[m]['source_sha256'],compat[m]['imports'])==(rows[m]['source_sha256'],rows[m]['imports'])
# Final rehash includes objects and logs after all audit/profile inspection.
for m,r in done.items():assert sha(R/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']
out={'status':'PASS_INDEPENDENT_PRIMARY_RETRY_ACTUAL_AND_FINAL_COMPATIBILITY_MAP_REVIEW','result_sha256':sha(R/'result.json'),'compatibility_map_sha256':sha(T/'compatibility-final-map.json'),'retry_freeze_sha256':sha(T/'freeze.json'),'providers':190,'selected_origins':dict(counts),'fresh_invocation_chronology':{'successful_run1':65,'run2_client':1,'run2_endpoint_audits':2},'warnings':dict(warnings),'new_four_client_reports':{m:profiles[m]for m in ['DerivedRows14Api','ThmKDerived14Api','KEindDerived14Api','ProfileTC14Api']},'endpoint_reports':10,'compatibility_plan':{'providers':70,'new':16,'primary_reuse':53,'phase13_reuse':['BusyBeaver.ZFC.Dag254']},'observed_outer_exit':0,'failed_run1_retained_not_accepted':True,'scope':'Independent read-only source/import graph, transitive freshness, source/object/dependency/log/report/input and outer-record inspection. No compiler, initializer, finalizer or producer invocation. Compatibility remains prospective.'}
(O/'primary-actual-and-final-map-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'warnings':out['warnings'],'receipt_sha256':sha(O/'primary-actual-and-final-map-review.json')}))
