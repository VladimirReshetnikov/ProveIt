"""Actual outer invocation of the separately reviewed, authorized phase14 primary."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
S=Path('/tmp/k215-phase14-check');E=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
assert sha(S/'freeze.json')=='b74517e2f8cab00ddf2bc4a9e8667161036a517e1569233f8a5ff8b0a7accc65'
for p,h in read(S/'freeze.json')['files'].items():assert sha(S/p)==h,p
peer=Path('/tmp/k215-phase14-runner-peer/review.json');assert sha(peer)=='b6118bc0f75544609e40a3dc3a854bf08e818a66d774ab755ec482826c762668'
baseline=Path('/tmp/k215-phase14-root/baseline-after-merge.json');assert read(baseline)['status']=='PASS_BASELINE_AFTER_INCOMING_MERGE'
argv=read(S/'commands.json')['primary'];assert not(S/'primary-run1').exists()
out=E/'primary-run1.stdout';err=E/'primary-run1.stderr';record=E/'primary-run1-outer.json';assert all(not p.exists()for p in [out,err,record])
rec={'status':'RUNNING','argv':argv,'cwd':str(R),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_sha256':sha(__file__),'freeze_sha256':sha(S/'freeze.json'),'peer_sha256':sha(peer),'baseline_after_merge_sha256':sha(baseline),'stdout':str(out),'stderr':str(err)}
record.write_text(json.dumps(rec,indent=2)+'\n');start=time.monotonic();proc=None
try:
 with out.open('wb')as stdout,err.open('wb')as stderr:
  proc=subprocess.Popen(argv,cwd=R,stdout=stdout,stderr=stderr,start_new_session=True)
  rec['pid']=proc.pid;record.write_text(json.dumps(rec,indent=2)+'\n');code=proc.wait()
 rec.update(status='PASS_OUTER_EXIT_ZERO'if code==0 else'FAIL_OUTER_EXIT',exit_code=code)
except BaseException as exc:
 if proc is not None and proc.poll()is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 rec.update(status='OUTER_EXCEPTION',exception=repr(exc),exit_code=None if proc is None else proc.returncode)
 raise
finally:
 rec.update(seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err))
 rec['frozen_files_unchanged']=all(sha(S/p)==h for p,h in read(S/'freeze.json')['files'].items())
 record.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2),flush=True)
assert rec['exit_code']==0 and rec['frozen_files_unchanged']
