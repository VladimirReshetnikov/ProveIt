"""Small metadata controls for the new retirement and archive-boundary guards."""
from pathlib import Path
import ast,json,tempfile
import packet
positive=[];negative=[]
def ok(name,f):f();positive.append(name)
def reject(name,f):
 try:f()
 except AssertionError:negative.append(name)
 else:raise AssertionError(name+' accepted')
for path in ['execution/source.lean','review/raw.json','history/template.txt']:ok(path,lambda p=path:packet.safe(p))
for path in ['/absolute','../escape','x/../escape','x//alias','x.olean','x.olean.private','x.olean.server','x.pyo','old.tar.gz']:
 reject(path,lambda p=path:packet.safe(p))
with tempfile.TemporaryDirectory()as name:
 root=Path(name);p=root/'retired';ok('absent template',lambda:packet.absent(p))
 p.write_text('old');reject('existing template',lambda:packet.absent(p));p.unlink()
 p.symlink_to(root/'missing');reject('dangling template symlink',lambda:packet.absent(p));p.unlink()
 p.mkdir();reject('directory at retired path',lambda:packet.absent(p))
for name in ['basis.py','packet.py','collect.py','review_saved.py']:
 ast.parse(Path(__file__).with_name(name).read_text())
result={'status':'PASS_METADATA_ONLY','positive':positive,'negative':negative,'positive_count':len(positive),'negative_count':len(negative),'scope':'Archive path/binary exclusion and exact absent-file guards only; no capture, predecessor validation, producer or proof compiler.'}
Path(__file__).with_name('controls.json').write_bytes(packet.dump(result));print(json.dumps(result,indent=2))
