"""Execute only the two root-authorized reviewed maintained producer variants."""
from pathlib import Path
import ast,hashlib,json,subprocess,time,difflib
S=Path('/tmp/k215-phase15-quotient');O=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');L=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC');F=Path('Computability/BusyBeaver/Research/ZFC/k225-formal/generate_kq1.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
assert sha(S/'freeze.json')=='be2c246be0cd3f98d81310e4bb774ea5ec33a9d23cf4c7420688ce500c902aad';freeze=read(S/'freeze.json');review=read(S/'review.json')
for p,h in freeze['files'].items():assert sha(S/p)==h,p
before={str(S/p):h for p,h in freeze['files'].items()};before[str(S/'freeze.json')]=sha(S/'freeze.json')
for rel,h in review['producer_inputs'].items():assert sha(R/rel)==h;before[str(R/rel)]=h
for rel,h in review['producer_old_outputs'].items():assert sha(R/rel)==h;before[str(R/rel)]=h
assert sha(R/F)=='f59ee6c64ce19cc5609cfca3cc678969450851d54d9ff0e1416fcd1e1afc8561';before[str(R/F)]=sha(R/F)
# Reconstruct the maintained adaptation from baseline + already reviewed inert insertions.
old=(S/'before'/F).read_text();proposal=(S/'candidate'/F).read_text();tree=ast.parse(proposal);n=next(n for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='MODEL_SYNTAX_ALIASES');constant=ast.get_source_segment(proposal,n);assert isinstance(ast.literal_eval(n.value),str)
a=proposal.index('    if f == "Model":');b=proposal.index('    if f == "Basic":',a);adapted=old.replace('for f in FORKS:\n',constant+'\n\nfor f in FORKS:\n',1).replace('    if f == "Basic":',proposal[a:b]+'    if f == "Basic":',1)+'\n';assert adapted==proposal and hashlib.sha256(adapted.encode()).hexdigest()=='8837ba3cbe0a82c4f166160f58d39ef35bd9d5d50adcac5078d4cf26eaaf7e42'
outputs=[f'KQ1{x}.lean'for x in ['Model','Separation','Basic','Replacement','Power','Collect']];results=[];emitted={}
for kind,script in [('baseline',old),('adapted',adapted)]:
 root=O/kind;root.mkdir(exist_ok=False);d=root/'BusyBeaver/ZFC';d.mkdir(parents=True);producer=root/'generate_kq1.py';producer.write_text(script)
 for rel in review['producer_inputs']:
  src=S/'reproduction-inputs'/rel
  if kind=='adapted'and Path(rel).name=='QuotientModel.lean':src=S/'candidate'/rel
  (d/Path(rel).name).write_bytes(src.read_bytes())
 initial={str(p.relative_to(root)):sha(p)for p in root.rglob('*')if p.is_file()};assert not any(p.is_symlink()for p in root.rglob('*'))
 argv=['python3','-B',str(producer)];started=time.monotonic();r=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 (O/(kind+'.stdout.txt')).write_bytes(r.stdout);(O/(kind+'.stderr.txt')).write_bytes(r.stderr)
 final={str(p.relative_to(root)):sha(p)for p in root.rglob('*')if p.is_file()};assert {p:final[p]for p in initial}==initial
 added=set(final)-set(initial);expected={'BusyBeaver/ZFC/'+n for n in outputs};assert added==expected,(kind,added)
 emitted[kind]={n:(d/n).read_bytes()for n in outputs}
 row={'kind':kind,'argv':argv,'cwd':str(root),'cap_seconds':30,'exit_code':r.returncode,'seconds':time.monotonic()-started,'producer_sha256':sha(producer),'input_before':initial,'input_after':{p:final[p]for p in initial},'exact_added_paths':sorted(added),'outputs':{n:sha(d/n)for n in outputs},'stdout_sha256':sha(O/(kind+'.stdout.txt')),'stderr_sha256':sha(O/(kind+'.stderr.txt'))};results.append(row)
 (O/'actual-in-progress.json').write_text(json.dumps({'status':'IN_PROGRESS','runs':results},indent=2)+'\n');assert r.returncode==0,row
baseline_drift={}
for n in outputs:
 ref=(S/'reproduction-before'/L/n).read_bytes();got=emitted['baseline'][n]
 if ref!=got:
  diff=''.join(difflib.unified_diff(ref.decode().splitlines(True),got.decode().splitlines(True),fromfile='maintained/'+n,tofile='baseline-generated/'+n));(O/('baseline-drift-'+n+'.diff')).write_text(diff);baseline_drift[n]={'before_sha256':hashlib.sha256(ref).hexdigest(),'generated_sha256':hashlib.sha256(got).hexdigest(),'diff':'baseline-drift-'+n+'.diff'}
assert emitted['adapted']['KQ1Model.lean']==(S/'candidate'/L/'KQ1Model.lean').read_bytes()
for n in outputs:
 if n!='KQ1Model.lean':assert emitted['adapted'][n]==emitted['baseline'][n],n
for p,h in before.items():assert sha(p)==h,p
result={'status':'PASS_TWO_AUTHORIZED_MAINTAINED_PRODUCER_REPRODUCTIONS','freeze_sha256':sha(S/'freeze.json'),'runs':results,'baseline_drift':baseline_drift,'candidate_model_exact':True,'other_five_outputs_exact_baseline':True,'all_original_frozen_and_canonical_inputs_unchanged':True,'before_pins':before,'scope':'Two reviewed maintained-producer variants only in fresh external layouts; no supplied renderer imports, Lean/compiler, canonical writes, or endpoint claim. Any baseline drift is separate.'};(O/'actual.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'baseline_drift':baseline_drift,'actual_sha256':sha(O/'actual.json')},indent=2))
