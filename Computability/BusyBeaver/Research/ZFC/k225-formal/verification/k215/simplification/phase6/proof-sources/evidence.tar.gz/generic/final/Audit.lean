
namespace SetTheory.BusyBeaver.ZFC.NormalizedCheckerAudit
open RegisterPath RMBisim

def decode215 (n : Nat) : List Bool := decodeAux 512 n []

-- The inherited API is deliberately still the old decoder, byte-for-byte.
theorem default128 (n : Nat) : RMBisim.decode n = decodeAux 128 n [] := rfl
theorem default_lookup (T : CTree) (j : Nat) :
    RMBisim.getc T j = RMBisim.WithDecoder.getc RMBisim.decode T j := rfl

theorem generic_endpoint (d : Nat → List Bool) {p q : Program} {T : CTree}
    (hs : RMNormalizedBisim.WithDecoder.branchOk d (ptree p) (ptree q) T [] [] 0 = true)
    (ha : allC (RMNormalizedBisim.WithDecoder.entryOk d (ptree p) (ptree q) T) T = true)
    (R : Registers) : Halts p ⟨[], R⟩ ↔ Halts q ⟨[], R⟩ :=
  RMNormalizedBisim.WithDecoder.check_halts_iff d hs ha R

theorem explicit512 {p q : Program} {T : CTree}
    (hs : RMNormalizedBisim.WithDecoder.branchOk decode215 (ptree p) (ptree q) T [] [] 0 = true)
    (ha : allC (RMNormalizedBisim.WithDecoder.entryOk decode215 (ptree p) (ptree q) T) T = true)
    (R : Registers) : Halts p ⟨[], R⟩ ↔ Halts q ⟨[], R⟩ :=
  RMNormalizedBisim.WithDecoder.check_halts_iff decode215 hs ha R

theorem default_endpoint {p q : Program} {T : CTree}
    (hs : RMBisim.branchOk (ptree p) (ptree q) T [] [] 0 = true)
    (ha : allC (RMBisim.entryOk (ptree p) (ptree q) T) T = true)
    (R : Registers) : Halts p ⟨[], R⟩ ↔ Halts q ⟨[], R⟩ :=
  RMBisim.check_halts_iff hs ha R

theorem long_decoding : (decode215 (2 ^ 176)).length = 176 := by decide +kernel
theorem old_decoding : (RMBisim.decode (2 ^ 176)).length = 128 := by decide +kernel
theorem equivalent_padding : RMNormalizedBisim.ibeq [true] [true, false, false] = true := by decide +kernel
theorem different_bit : RMNormalizedBisim.ibeq [true] [false, false] = false := by decide +kernel
theorem missing_lookup (d : Nat → List Bool) (j : Nat) :
    RMNormalizedBisim.WithDecoder.getc d .empty j = none := rfl

#print axioms default128
#print axioms default_lookup
#print axioms generic_endpoint
#print axioms explicit512
#print axioms default_endpoint
#print axioms long_decoding
#print axioms old_decoding
#print axioms equivalent_padding
#print axioms different_bit
#print axioms missing_lookup
end SetTheory.BusyBeaver.ZFC.NormalizedCheckerAudit
