#!/usr/bin/env python3
"""Own source-only prune of seven unconsumed forgetful research declarations."""
from pathlib import Path
import hashlib,json,re,difflib
ROOT=Path('/tmp/k215-phase9-decoder-compact')
OLD=Path('/tmp/k215-phase9-decoder-routes/formal-table-v2/candidate/BusyBeaver/ZFC')
PREFIX=Path('/tmp/k215-phase9-decoder-prefix/v3/candidate/BusyBeaver/ZFC/KDecoderPrefix215.lean')
EXPECTED={'DecoderCertificate':'bd14c19ccb3a3755c59d6bef210a018caf559789d91a7f5be0cedabbcf1cb50b','K215Decoder':'8663e195ec5a08d1137547eaf7332cfc32ef7c353e473437bbc3fc06cf45c373','KDecoderPrefix215':'076fbc32fc9e9c2862c636debfa4f2fbfbc8bb75d452f0ea214bb40f4388e191'}
def sha(b):return hashlib.sha256(b).hexdigest()
def cut(s,start,end):
 assert s.count(start)==s.count(end)==1,(start,end)
 a=s.index(start);b=s.index(end,a);return s[:a]+s[b:]
def strip_comments(s):
 return re.sub(r'/\-.*?\-/|--[^\n]*','',s,flags=re.S)
def declarations(s):
 s=strip_comments(s)
 pat=r'^(?:(?:private|protected)\s+)?(?:def|theorem|inductive|structure)\s+(\S+)'
 out={};matches=list(re.finditer(pat,s,re.M))
 for i,m in enumerate(matches):
  body=s[m.start():matches[i+1].start() if i+1<len(matches) else len(s)]
  # End-of-namespace and reports are not part of the declaration.
  body=re.split(r'^end\s|^namespace\s|^#print\s',body,flags=re.M)[0]
  out[m.group(1)]=re.sub(r'\s+','',body)
 return out
removed={'DecoderPaths':['Entry','RoutedEntry.forget','source_path_chain','source_path_run','reaches_primitive'],'DecoderSourceBinding':['upstream_leaf_reaches','upstream_walk_reaches']}
rows=[]
for name in ['DecoderCertificate','K215Decoder','DecoderPaths','DecoderSourceBinding','KDecoderPrefix215']:
 p=PREFIX if name=='KDecoderPrefix215' else OLD/(name+'.lean');old=p.read_bytes();s=old.decode()
 if name in EXPECTED:assert sha(old)==EXPECTED[name]
 if name=='DecoderPaths':
  s=cut(s,'/-- The final decoder control is linked','/-- Exact accepted pre language')
  s=cut(s,'theorem RoutedEntry.forget ','/-- Source-path traversal')
  s=cut(s,'theorem source_path_chain\n','/-- A chain of bounded positive blocks')
  s=cut(s,'theorem reaches_primitive {','#print axioms semantic_edges')
  s=s.replace('/-- Entry retains the consumed pre','/-- Routed entry retains the consumed pre')
  s=s.replace('#print axioms reaches_primitive\n','#print axioms reaches_primitive_routed\n')
 if name=='DecoderSourceBinding':
  s=cut(s,'theorem upstream_leaf_reaches {','/-- The repository walk semantics')
  s=cut(s,'theorem upstream_walk_reaches (','#print axioms source_tree_eq')
  s=s.replace('#print axioms upstream_leaf_reaches\n','#print axioms upstream_leaf_reaches_routed\n')
  s=s.replace('#print axioms upstream_walk_reaches\n','#print axioms upstream_walk_reaches_routed\n')
 olddecl=declarations(old.decode());newdecl=declarations(s)
 assert set(olddecl)-set(newdecl)==set(removed.get(name,[])),name
 assert set(newdecl)<=set(olddecl),name
 for d in newdecl:assert newdecl[d]==olddecl[d],(name,d)
 dest=ROOT/'candidate/BusyBeaver/ZFC'/(name+'.lean');dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_text(s)
 diff=ROOT/(name+'.diff');diff.write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),s.splitlines(True),fromfile=str(p),tofile=str(dest))))
 rows.append({'module':'BusyBeaver.ZFC.'+name,'before':{'path':str(p),'sha256':sha(old),'bytes':len(old),'lines':len(old.splitlines())},'after':{'path':str(dest),'sha256':sha(s.encode()),'bytes':len(s.encode()),'lines':len(s.splitlines())},'removed_declarations':removed.get(name,[]),'all_retained_declaration_noncomment_tokens_unchanged':True,'retained_declaration_count':len(newdecl),'imports':re.findall(r'^import (.+)$',s,re.M),'reports':re.findall(r'^#print axioms (.+)$',s,re.M)})
allnew='\n'.join(Path(x['after']['path']).read_text()for x in rows)
for names in removed.values():
 for n in names:assert not re.search(r'(?<![\w.])'+re.escape(n)+r'(?![\w.])',strip_comments(allnew)),n
rec={'status':'FROZEN_SOURCE_ONLY_UNUSED_WRAPPER_PRUNE','modules':rows,'counts':{'bytes_before':sum(x['before']['bytes']for x in rows),'bytes_after':sum(x['after']['bytes']for x in rows),'lines_before':sum(x['before']['lines']for x in rows),'lines_after':sum(x['after']['lines']for x in rows),'reports':sum(len(x['reports'])for x in rows)},'compiler_invoked':False,'canonical_changes':False,'provider_files_changed':False,'unproved_new_premises':False}
(ROOT/'freeze.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec['counts'],indent=2))
