#!/usr/bin/env python3
"""Pure counterexample to direct-object-only eligibility; no Lean execution."""
import ast,hashlib,json,re,copy
from pathlib import Path
P=Path('/tmp/k215-phase9-main/build-v3.py');s=P.read_bytes();assert hashlib.sha256(s).hexdigest()=='6e6a12b50c5a3ad4fe2082e39eddfdc29d64cb8955d9fd8f83d54bcffe70bc6a'
fs={n.name:n for n in ast.walk(ast.parse(s))if isinstance(n,ast.FunctionDef)}
old={'A':{'source_sha256':'a-old','imports':[]},'B':{'source_sha256':'b-same','imports':['A']},'C':{'source_sha256':'c-same','imports':['B']}}
new=copy.deepcopy(old);new['A']['source_sha256']='a-new'
class File:
 def __init__(self,p):self.p=p
 def is_file(self):return True
 def read_text(self):return ''
g={'Path':File,'re':re,'overrides':{},'row':{'module':'C','source_sha256':'c-same'},'deps':{'B':'b-unchanged-object'},'sha':lambda p:{'c-object':'c-old-object','c-log':'empty-log'}[p.p if isinstance(p,File)else p]}
exec(compile(ast.Module(body=[fs['log_policy'],fs['usable']],type_ignores=[]),'<pure v3 predicates>','exec'),g)
rec={'status':'PASS','exit_code':0,'timed_out':False,'source_sha256':'c-same','dependencies':{'B':'b-unchanged-object'},'object_sha256':'c-old-object','log':'c-log','log_sha256':'empty-log'}
assert g['usable'](rec,File('c-object')) is True
changed={m for m in new if m not in old or new[m]!=old[m]}
affected=set(changed)
while True:
 expanded=affected|{m for m,r in new.items()if set(r['imports'])&affected}
 if expanded==affected:break
 affected=expanded
assert changed=={'A'}and affected=={'A','B','C'}
def closure(graph,m):
 seen=set()
 def visit(n):
  if n in seen:return
  seen.add(n)
  for d in graph[n]['imports']:visit(d)
 visit(m);return {n:graph[n]for n in sorted(seen)}
assert closure(old,'C')!=closure(new,'C')
r={'status':'REPRODUCED_TRANSITIVE_STALE_PROOF_REUSE_GAP','v3_direct_predicate_accepts_C':True,'correct_baseline_reuse_C':False,'changed_sources':sorted(changed),'mandatory_rebuild_descendants':sorted(affected),'old_isolated_source_closure_matches_current':False,'interpretation':'A is a changed transparent definition; B imports A but serializes identically; C is an old proof that computes through B to A. Identical direct B object does not establish C proof validity under new A.','compiler_invocations':0,'driver_invocations':0}
Path('/tmp/k215-phase9-main-peer/transitive-control.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
