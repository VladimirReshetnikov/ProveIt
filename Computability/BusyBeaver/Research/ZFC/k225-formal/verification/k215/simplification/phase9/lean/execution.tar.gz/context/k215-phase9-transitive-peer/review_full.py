"""Independent saved/live postcheck; never launches Lean or changes proof inputs."""
from pathlib import Path
import argparse,hashlib,json,re
A=argparse.ArgumentParser();A.add_argument('--run',type=Path,required=True);A.add_argument('--output',type=Path,required=True);a=A.parse_args();F=a.run;O=a.output;assert not O.exists()
B=Path('/tmp/k215-proof-phase8/lean-run1');I=Path('/tmp/k215-phase9-main/isolated-run2');R=Path('/home/codex/.codex/worktrees/ec20/Proofs');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
oldi={r['module']:r for r in read(B/'inventory.json')['modules']};old=read(B/'completed.json');iso_i={r['module']:r for r in read(I/'inventory.json')['modules']};iso=read(I/'completed.json');before=read(F/'before.json');inv=read(F/'inventory.json');rows={r['module']:r for r in inv['modules']};done=read(F/'completed.json');res=read(F/'result.json');plans={r['module']:r for r in read('/tmp/k215-phase9-main/full-v1.json')['modules']}
assert res['status']=='PASS' and len(rows)==len(done)==197 and set(rows)==set(done)
assert len(old)==188 and len(iso)==14
assert res['inventory_sha256']==sha(F/'inventory.json')and res['completed_sha256']==sha(F/'completed.json')
assert res['runner_sha256']==before['runner_sha256']==sha('/tmp/k215-phase9-main/build-v4.py')
assert res['map_sha256']==before['map_sha256']==sha('/tmp/k215-phase9-main/full-v1.json')
changed={m for m,r in rows.items()if m not in oldi or(r['source_sha256'],r['imports'])!=(oldi[m]['source_sha256'],oldi[m]['imports'])}
closures={}
def closure(m):
 if m not in closures:closures[m]={m}|set().union(*(closure(d)for d in rows[m]['imports']if d!='Init'))
 return closures[m]
for m in rows:closure(m)
forced={m for m in rows if closures[m]&changed}
iso_ok={m for m in rows if closures[m]<=set(iso_i)and all((rows[d]['source_sha256'],rows[d]['imports'])==(iso_i[d]['source_sha256'],iso_i[d]['imports'])for d in closures[m])}
required=forced-iso_ok;assert len(changed)==11 and len(forced)==26 and len(required)==20
assert sorted(changed)==before['changed_sources']==res['source_changed_modules'];assert sorted(forced)==before['force_basis_rebuild']==res['force_basis_rebuild_modules']
def provenance(records):
 for m in forced:
  rec=records[m]
  assert rec['origin']=='phase9_fresh' or(rec['origin']=='isolated_checked'and m in iso_ok),(m,rec['origin'])
provenance(done)
try:provenance(read('/tmp/k215-phase9-main/full-run1/completed.json'))
except AssertionError:old_run_rejected=True
else:raise AssertionError('Original unaccepted run was not rejected')
sites=sorted(m for m in rows if m.startswith('BusyBeaver.ZFC.KSites215Batch'));assert len(sites)==9
assert all(done[m]['origin']=='phase9_fresh'for m in sites)
assert set(res['fresh_modules'])==required
objects={m:sha(F/'objects'/(m.replace('.','/')+'.olean'))for m in rows};compiler=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');standard={'propext','Classical.choice','Quot.sound'}
def report(txt):
 found=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
 assert all({x.strip()for x in ax.split(',')if x.strip()}<=standard for _,ax in found)
 assert 'sorryAx'not in txt and 'error:'not in txt
 return found
ledger={}
for m,row in rows.items():
 rec=done[m];source=Path(row['source']);obj=F/'objects'/(m.replace('.','/')+'.olean');log=Path(rec['log']);txt=log.read_text()
 assert sha(source)==row['source_sha256']==rec['source_sha256'];assert objects[m]==rec['object_sha256'];assert sha(log)==rec['log_sha256'];assert rec['status']=='PASS'
 imports=[w for l in source.read_text().splitlines()if l.startswith('import ')for w in l[7:].split()];assert imports==row['imports']
 assert rec['dependencies']=={d:objects[d]for d in imports if d!='Init'}
 found=report(txt)
 assert sha(F/'workspace'/(m.replace('.','/')+'.lean'))==row['source_sha256']
 if rec['origin']=='phase9_fresh':
  assert not obj.is_symlink() and obj.is_file();assert rec['exit_code']==0 and not rec['timed_out'];assert sha(rec['source'])==row['source_sha256']
  assert rec['warnings']==txt.count('warning:');assert sha(compiler)==rec['compiler_sha256']
  assert rec['command']==[str(compiler),'-j1','-M12288','--root='+str(F/'workspace'),'-o',str(obj),str(F/'workspace'/(m.replace('.','/')+'.lean'))]
  assert rec['timeout_seconds']==(900 if m in sites else 120) and rec['memory_mebibytes']==12288
  assert [list(x)for x in found]==rec['reports']
  if m in plans:assert [n for n,_ in found]==plans[m]['reports'] and rec['warnings']==0
 elif rec['origin']=='phase8_checked':
  assert m not in forced;assert rec=={**old[m],'origin':'phase8_checked'};assert obj.is_symlink()and obj.resolve()==(B/'objects'/(m.replace('.','/')+'.olean')).resolve()
 elif rec['origin']=='isolated_checked':
  assert m in iso_ok;assert rec=={**iso[m],'origin':'isolated_checked'};assert obj.is_symlink()and obj.resolve()==(I/'objects'/(m.replace('.','/')+'.olean')).resolve()
 else:raise AssertionError('unrecognized origin')
 ledger[m]={'source':sha(source),'object':objects[m],'log':sha(log),'origin':rec['origin'],'transitive_source_imports':{d:{'source':rows[d]['source_sha256'],'imports':rows[d]['imports']}for d in sorted(closures[m])}}
for p,h in before['inputs'].items():assert sha(p)==h,p
expected={
'EndpointAudit215':['EndpointAudit215.blank_halts_exactly_when_zfc_has_a_finite_refutation','EndpointAudit215.nonhalting_exactly_when_zfc_is_consistent'],
'K215Audit':['SetTheory.BusyBeaver.ZFC.KEndpoint215.blank_halts_iff_zfc_refutation','SetTheory.BusyBeaver.ZFC.KEndpoint215.nonhalting_iff_zfc_consistency','SetTheory.BusyBeaver.ZFC.KDense215.commutes','SetTheory.BusyBeaver.ZFC.KBoot215.boot','SetTheory.BusyBeaver.ZFC.KSites215.covered','SetTheory.BusyBeaver.ZFC.KEndpoint215.p215_boot_iff','K215Audit.blank_halts_exact','K215Audit.nonhalting_exact']}
pins={'EndpointAudit215':'d13596021774c5b26937b13cf6cca58342af99f59626b9205ff10b9df1e6fc7d','K215Audit':'9144acc6c597c4a53928fc62be00d5e25d9f32f519797d17a5058d03b5460986'}
assert [x['module']for x in res['audits']]==list(expected)
for rec in res['audits']:
 m=rec['module'];q=F/('audit-'+m);log=Path(rec['log']);txt=log.read_text();found=report(txt)
 assert rec['status']=='PASS' and rec['exit_code']==0 and not rec['timed_out'] and 'warning:'not in txt
 assert [n for n,_ in found]==expected[m] and [list(x)for x in found]==rec['named_reports']
 assert rec['dependencies']==objects and sha(rec['source'])==sha(q/(m+'.lean'))==rec['source_sha256']==pins[m]
 assert sha(q/(m+'.olean'))==rec['object_sha256'] and sha(log)==rec['log_sha256'];assert sha(compiler)==rec['compiler_sha256']
 assert rec['command']==[str(compiler),'-j1','-M12288','--root='+str(q),'-o',str(q/(m+'.olean')),str(q/(m+'.lean'))]
 assert rec['timeout_seconds']==120 and rec['memory_mebibytes']==12288
for p,h in before['inputs'].items():assert sha(p)==h,p
for m,row in rows.items():
 assert sha(row['source'])==ledger[m]['source'];assert sha(F/'objects'/(m.replace('.','/')+'.olean'))==ledger[m]['object'];assert sha(done[m]['log'])==ledger[m]['log']
for rec in res['audits']:
 q=F/('audit-'+rec['module']);assert sha(q/(rec['module']+'.olean'))==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256']
out={'status':'PASS_INDEPENDENT_197_TRANSITIVE_SOURCE_CLOSED_REVIEW','run':str(F),'modules':197,'source_changed_or_new':11,'source_descendants':26,'fresh_modules':sorted(required),'fresh_count':20,'all_nine_site_batches_fresh':sites,'isolated_reuse_count':sum(x['origin']=='isolated_checked'for x in done.values()),'baseline_reuse_count':sum(x['origin']=='phase8_checked'for x in done.values()),'original_full_run1_rejected':old_run_rejected,'exact_typed_clients':2,'exact_named_reports':10,'audit_warnings':0,'scope':'Fresh source-transitive affected coverage plus unchanged basis providers. Full source/object/log/toolchain/audit bindings checked after audits. No compiler by reviewer; no blanket object-hash-only reuse acceptance.','pins':{str(p):sha(p)for p in[F/'result.json',F/'before.json',F/'inventory.json',F/'completed.json',Path(__file__)]},'ledger':ledger}
O.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['ledger','pins']},indent=2))
