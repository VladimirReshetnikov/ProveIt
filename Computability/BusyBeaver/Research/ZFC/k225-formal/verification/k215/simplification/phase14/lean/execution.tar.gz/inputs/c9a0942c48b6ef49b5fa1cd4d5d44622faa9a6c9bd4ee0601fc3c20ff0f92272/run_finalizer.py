"""Record the authorized metadata-only compatibility finalizer invocation."""
from pathlib import Path
import hashlib,json,subprocess,time
S=Path('/tmp/k215-phase14-retry');E=Path(__file__).resolve().parent;R=Path('/tmp/k215-phase14-check')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
assert sha(S/'freeze.json')=='cf22ecb2057efdcdf3035b932153ed399d2f278c6f19d07d18301a0f13554dee'
assert read(R/'primary-run2/result.json')['status']=='PASS'
argv=read(S/'commands.json')['finalize_compatibility'];out=E/'finalizer.stdout';err=E/'finalizer.stderr';record=E/'finalizer-outer.json';assert all(not p.exists()for p in [out,err,record])
start=time.monotonic()
with out.open('wb')as stdout,err.open('wb')as stderr:
 result=subprocess.run(argv,cwd='/home/codex/.codex/worktrees/ec20/Proofs',stdout=stdout,stderr=stderr,timeout=60)
r={'status':'PASS_OUTER_EXIT_ZERO'if result.returncode==0 else'FAIL_OUTER_EXIT','argv':argv,'exit_code':result.returncode,'seconds':time.monotonic()-start,'wrapper_sha256':sha(__file__),'primary_result_sha256':sha(R/'primary-run2/result.json'),'retry_freeze_sha256':sha(S/'freeze.json'),'stdout':str(out),'stdout_sha256':sha(out),'stderr':str(err),'stderr_sha256':sha(err),'compiler_invoked':False,'frozen_files_unchanged':all(sha(root/p)==h for root in [R,S]for p,h in read(root/'freeze.json')['files'].items())}
record.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert result.returncode==0 and r['frozen_files_unchanged']
