"""Owned textual adaptation of the reviewed phase14 evidence reader; no execution."""
from pathlib import Path
import ast,json
S=Path(__file__).resolve().parent;O=Path('/tmp/k215-phase14-publication');R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
s=(O/'packet.py').read_text()
# Preserve the small reviewed format/profile routines; successor run logic follows separately.
a=s[s.index('BINARY ='):s.index('def validate(')]
a=a.replace("'phase13'","'phase14'")
head='''"""Validate phase15 saved records against the exact local phase14 packet.
No compiler, producer or archived Python is executed by this reader.
"""
from pathlib import Path, PurePosixPath
import hashlib, json, re
import basis
HERE = Path(__file__).resolve().parent
ROOT = '/home/codex/.codex/worktrees/ec20/Proofs'
PREP = '/tmp/k215-phase15-check'
EXEC = '/tmp/k215-phase15-execution'
FIRST, SECOND, MAIN, COMP = [PREP+'/'+s for s in ['primary-run1','primary-run2','primary-run3','compatibility-run1']]
RETRY = '/tmp/k215-phase15-retry'
CLIENT_RETRY = '/tmp/k215-phase15-client-retry'
BASE = '/tmp/k215-phase14-check/primary-run2'
BASE_COMP = '/tmp/k215-phase14-check/compatibility-run1'
OLD = '/tmp/k215-proof-phase8/lean-run1'
DRIVER = '198b075493d80cf554f5755a37ccfbc5afb90fcfa498b900d805f13312e458ec'
FREEZE = 'bf7ee51d71e671876ca5b1b8c4933493cee3907c993b36b2658e2f4a6196cb06'
BOUNDARY = '8d039df9d25e21af112e59ef52f569a62c155d8941387'
BASE_RESULTS = ['3454f69d71477171f20d91733093821fa3198253dece63802c59d045bf3991df','008d6626c9c2b11400713bda9dff89aa5385f276d0898f13c1f0dd19cda857b1']
P = 'BusyBeaver.ZFC.'
NS = 'SetTheory.'+P
OLD_API = ['GenericShared13Api','NumericCD52Api','LukasShared13Api','DerivedRows14Api','ThmKDerived14Api','KEindDerived14Api','ProfileTC14Api']
NEW_API = ['BasicInterfaces15Api','TransRec15Api','QuotientSharing15Api']
API = OLD_API+NEW_API
CLIENTS = ['WFModelCompat12','ZFNativeCompat12']
TARGETS = [P+'KEndpoint215',P+'KDecoderPrefix215']+API
STANDARD = {'propext','Classical.choice','Quot.sound'}
PQ = {'propext','Quot.sound'}
LEAN_DIR = 'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/'
FORMAL = 'Computability/BusyBeaver/Research/ZFC/k225-formal/'
'''
head=head.replace("BOUNDARY = '8d039df9d25e21af112e59ef52f569a62c155d8941387'","BOUNDARY = '8d039df9d25e21af1122727278f378b0016cdb235d3c18b3e883a144696840a0'")
tree=ast.parse(s)
for n in tree.body:
 if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id in ['AUDIT_NAMES','AUDIT_PINS','PRIOR_ADOPTIONS']:
  head+=ast.get_source_segment(s,n)+'\n'
# Retain seven checked phase14 production paths plus its five earlier adoptions.
prior=next(n for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='ADOPTIONS')
head+=ast.get_source_segment(s,prior).replace('ADOPTIONS =','PRIOR_WRITES =')+'\nPRIOR_ADOPTIONS.update(PRIOR_WRITES)\n'
rows=json.loads(Path('/tmp/k215-phase15-retry/sources.json').read_text())
writes={r['canonical']:r['source_sha256']for r in rows}
writes['Computability/BusyBeaver/Research/ZFC/k225-formal/generate_kq1.py']='8837ba3cbe0a82c4f166160f58d39ef35bd9d5d50adcac5078d4cf26eaaf7e42'
head+='ADOPTIONS = '+repr(writes)+'\n'
head+="CREATED = LEAN_DIR+'PowerSets.lean'\nRETAINED_ABSENCES = [LEAN_DIR+'KProfileTC.lean', FORMAL+'generate_profile_tc.py', FORMAL+'dominated_implication_templates/core-prefix.txt', FORMAL+'dominated_implication_templates/core-suffix.txt']\n"
(S/'packet.py').write_text(head+'\n'+a)
