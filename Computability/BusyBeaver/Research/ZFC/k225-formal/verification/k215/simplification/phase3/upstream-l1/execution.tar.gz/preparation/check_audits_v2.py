"""Recheck repaired independent clients using only previously passed module objects."""
from pathlib import Path
import hashlib,json,os,re,signal,shutil,importlib.util
P=Path(__file__).resolve().parent;previous=P/'run1';out=P/'run2';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
result=json.loads((previous/'result.json').read_text());assert result['status']=='FAIL'
passed=result['checks'][:5];assert len(result['checks'])==6 and result['checks'][-1]['module']=='DraftAudit' and result['checks'][-1]['status']=='FAIL'
assert all(r['status']=='PASS' and r['exit_code']==0 and not r['timed_out'] for r in passed)
done=json.loads((previous/'basis-completed.json').read_text());done.update({r['module']:r for r in passed});assert len(done)==215
cache=out/'objects';cache.mkdir();before={}
for m,r in done.items():
 obj=previous/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==r['object_sha256']
 dest=cache/(m.replace('.','/')+'.olean');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(obj,dest);before[str(obj)]=sha(obj)
for r in passed:
 for name,expected in [(r['command'][-1],r['source_sha256']),(r['log'],r['log_sha256'])]:assert sha(name)==expected;before[name]=expected
for name,h in json.loads((previous/'before.json').read_text()).items():assert sha(name)==h;before[name]=h
helperfile=previous/'supervisor.py';spec=importlib.util.spec_from_file_location('supervisor',helperfile);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
compiler=Path(passed[0]['command'][0]);lock=Path('/tmp/proveit-k215-proof-build.lock');sources=out/'source';sources.mkdir();attempts=out/'attempts';attempts.mkdir()
for name in ['DraftAudit','EndpointAudit215','K215Audit']:
 src=P/'audit-v2/DraftAudit.lean' if name=='DraftAudit' else previous/'source'/(name+'.lean');shutil.copyfile(src,sources/src.name)
for f in [Path(__file__),helperfile,previous/'result.json',previous/'basis-completed.json']:before[str(f)]=sha(f)
save(out/'before.json',before);save(out/'accepted-module-bindings.json',done)
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
checks=[]
for i,(name,n) in enumerate([('DraftAudit',3),('EndpointAudit215',2),('K215Audit',8)]):
 src=sources/(name+'.lean');obj=out/(name+'.olean');at=attempts/f'{i+1:02d}-{name}';at.mkdir();shutil.copyfile(src,at/src.name)
 cmd=[str(compiler),'-j1','-M12288','--root='+str(sources),'-o',str(obj),str(src)]
 row={'module':name,'source_sha256':sha(src),'command':cmd,'compiler_sha256':sha(compiler),'timeout_seconds':120,'memory_mebibytes':12288,'dependencies':{m:r['object_sha256'] for m,r in done.items()},'log':str(at/'compiler.log'),'expected_axiom_reports':n}
 print('CHECK',name,flush=True);ok=helper.run_locked(cmd,sources,env,lock,Path(row['log']),120,row,at/'record.json')
 text=Path(row['log']).read_text();reports=re.findall(r'depends on axioms: \[([^]]*)\]',text)
 row.update(source_unchanged=sha(src)==row['source_sha256'],warnings=text.count('warning:'),reports=reports,axiom_free_reports=text.count('does not depend on any axioms'))
 ok=ok and row['source_unchanged'] and not row['warnings'] and 'error:' not in text and 'sorryAx' not in text
 ok=ok and len(reports)+row['axiom_free_reports']==n and all(set(x.strip() for x in s.split(','))<={'propext','Classical.choice','Quot.sound'} for s in reports)
 row['dependencies_unchanged']=all(sha(cache/(m.replace('.','/')+'.olean'))==r['object_sha256'] for m,r in done.items());ok=ok and row['dependencies_unchanged']
 row['status']='PASS' if ok else 'FAIL'
 if ok:row['object_sha256']=sha(obj)
 save(at/'record.json',row);checks.append(row);print(row['status'],name,round(row['seconds'],3),flush=True)
 if not ok:print(text,flush=True);break
post=all(sha(f)==h for f,h in before.items());privatepost=all(sha(cache/(m.replace('.','/')+'.olean'))==r['object_sha256'] for m,r in done.items())
status='PASS' if len(checks)==3 and all(r['status']=='PASS' for r in checks) and post and privatepost else 'FAIL'
final={'status':status,'checks':passed+checks,'selected_passed_modules_from':str(previous/'result.json'),'excluded_failed_audit':str(previous/'attempts/06-DraftAudit'),'repair':'Only audit proof generalizes the common selector before splitting; candidate source unchanged.','input_post':post,'private_objects_post':privatepost,'basis':'Accepted phase-one201-module endpoint dependency graph;215 objects copied privately. Five modules freshly passed in run1, repaired3 clients freshly checked in run2. No full current185 replay.','no_canonical_mutations':True}
save(out/'result.json',final);print('TERMINAL',status,flush=True)
