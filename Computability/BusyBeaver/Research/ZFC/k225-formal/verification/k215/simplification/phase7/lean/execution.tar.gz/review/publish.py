"""Stage completed phase-seven evidence after a matching live post-audit review.

Writes a fresh scratch directory. No compiler or archived runner is invoked.
"""
from pathlib import Path
import argparse
import gzip
import io
import json
import tarfile
from capture import arguments, collect
from evidence import digest, manifest, manifest_hash, save, sha, validate
import basis_reference


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    arguments(parser)
    parser.add_argument('--live-review', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists(), 'Refusing to overwrite a packet'
    members = collect(args)
    live_bytes = args.live_review.read_bytes()
    live = json.loads(live_bytes)
    assert live['status'] == 'PASS_LIVE_POST_AUDIT_REVIEW'
    assert live['evidence_manifest_sha256'] == manifest_hash(members)
    checked = validate(members, basis_repo=args.basis_repo or Path(json.loads(members['execution/owner.json'])['repo']))
    assert all(live[k] == v for k, v in checked.items())
    assert live['all187_objects_rehashed_after_audits']
    assert live['all187_basis_objects_and_logs_unchanged']
    assert live['current_inventory_exact'] and live['toolchain_and_compiler_rehashed']
    assert live['basis_reference_sha256'] == basis_reference.REFERENCE_SHA256
    assert live['run'] == str(args.run.resolve()) and live['basis'] == str(args.basis.resolve())
    assert digest(members['review/review.py']) == live['reviewer_sha256']
    assert digest(members['review/evidence.py']) == live['validator_sha256']
    assert digest(members['review/capture.py']) == live['capture_sha256']
    members['review/live-review.json'] = live_bytes
    index = manifest(members)
    out = args.out.resolve()
    out.mkdir()
    with (out / 'execution.tar.gz').open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for name, data in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
    save(out / 'index.json', index)
    result = json.loads(members['execution/result.json'])
    summary = {**result, 'project_warnings': checked['project_warnings'], 'audit_warnings': 0,
               'archive_members': len(index), 'execution_archive_sha256': sha(out / 'execution.tar.gz'),
               'live_review_sha256': digest(live_bytes), 'compiled_objects_in_archive': False,
               'basis_reference_sha256': basis_reference.REFERENCE_SHA256,
               'source_checkpoint_scope': '187 exact source snapshots and complete referenced basis ledgers/reused log origins; '
                                          'published phase6 ancestry is referenced by immutable relative pins.'}
    save(out / 'result.json', summary)
    (out / 'live-review.json').write_bytes(live_bytes)
    for name in ('review_saved.py', 'evidence.py', 'basis_reference.py', 'basis-reference.json'):
        (out / name).write_bytes(members['review/' + name])
    template = members['review/README.template.md'].decode()
    text = template.replace('@FRESH@', str(result['fresh_modules'])).replace('@REUSED@', str(result['reused_modules'])).replace('@WARNINGS@', str(checked['project_warnings']))
    (out / 'README.md').write_text(text)
    print(json.dumps({'status': 'STAGED_SAVED_PACKET', 'path': str(out), 'members': len(index),
                      'archive_bytes': (out / 'execution.tar.gz').stat().st_size,
                      'summary_sha256': sha(out / 'result.json')}, indent=2))


if __name__ == '__main__':
    main()
