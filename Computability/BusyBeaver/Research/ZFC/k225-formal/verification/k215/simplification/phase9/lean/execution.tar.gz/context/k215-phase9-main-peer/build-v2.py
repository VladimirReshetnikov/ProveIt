"""Serial incremental candidate check with an explicit source map and immutable providers."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,signal,fcntl
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');B=Path('/tmp/k215-proof-phase8/lean-run1');S=Path(__file__).resolve().parent
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
a=argparse.ArgumentParser();a.add_argument('--out',type=Path,required=True);a.add_argument('--map',type=Path,required=True);a.add_argument('--target',action='append',required=True);a.add_argument('--reuse',type=Path);a.add_argument('--audit-endpoint',action='store_true');args=a.parse_args();out=args.out;out.mkdir(exist_ok=True);lock=(out/'output.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert sha(B/'result.json')=='6d1eed6ad824218ab297ce8bc1b573adc520bf72f645bf546dc5618928bb1c5f'
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd';assert sha(C)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
spec=importlib.util.spec_from_file_location('supervisor',H);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
baseline=read(B/'result.json')
assert sha(B/'completed.json')==baseline['completed_sha256'] and sha(B/'inventory.json')==baseline['inventory_sha256']
original=read(B/'inventory.json');old=read(B/'completed.json');assert len(old)==len(original['modules'])==188
plans=read(args.map)['modules'];overrides={r['module']:r for r in plans};assert len(overrides)==len(plans)
inputs={str(p):sha(p)for p in [B/n for n in ['result.json','inventory.json','completed.json','toolchain.json']]+[H,C,Path(__file__),args.map]};basis={}
for m,rec in old.items():
 assert rec['status']=='PASS' and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
 entry=next(r for r in original['modules']if r['module']==m);assert rec['source_sha256']==entry['source_sha256'];assert rec['dependencies']=={d:old[d]['object_sha256']for d in entry['imports']if d!='Init'}
 obj=B/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256'];basis[m]=(rec,obj)
 inputs[str(obj)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
for name,pin in baseline['exact_machine_pins'].items():
 path=R/'Computability/BusyBeaver/Research/ZFC/candidate-k215'/name;assert sha(path)==pin;inputs[str(path)]=pin
for name,pin in baseline['producer_pins'].items():
 path=R/name;assert sha(path)==pin;inputs[str(path)]=pin
for row in plans:
 assert sha(row['source'])==row['source_sha256'];inputs[row['source']]=row['source_sha256']
 if row['module']in old:assert row['before_sha256']==old[row['module']]['source_sha256']
for key in ['lean','lake','Init.olean','project_toolchain']:
 t=read(B/'toolchain.json')[key];assert sha(t['path'])==t['sha256'];inputs[t['path']]=t['sha256']
rows=[];seen=set();active=set();external=set()
def visit(m):
 if m in seen:return
 assert m not in active,('cycle',m)
 if m in overrides:path=Path(overrides[m]['source'])
 else:
  found=[p for root in driver.ROOTS if (p:=R/root/(m.replace('.','/')+'.lean')).is_file()]
  if not found:assert m=='Init';external.add(m);return
  assert len(found)==1;assert m in old,('Unregistered module',m);path=found[0]
 clean=driver.without_comments_strings(path.read_text());imports=[w for l in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',clean)for w in l.split()]
 if m in overrides:assert imports==overrides[m]['imports']
 elif m in old:assert sha(path)==old[m]['source_sha256']
 inputs[str(path)]=sha(path);active.add(m)
 for d in imports:visit(d)
 active.remove(m);seen.add(m);rows.append({'module':m,'source':str(path),'source_sha256':sha(path),'imports':imports})
for target in args.target:visit(target)
owner={'map_sha256':sha(args.map),'runner_sha256':sha(__file__),'targets':args.target,'audit_endpoint':args.audit_endpoint,'rows':rows,'inputs':inputs,'external_imports':sorted(external)}
cache=out/'objects';workspace=out/'workspace';env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
reuse={}
if args.reuse:
 assert read(args.reuse/'result.json')['status']=='PASS'
 for m,rec in read(args.reuse/'completed.json').items():
  obj=args.reuse/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256'];reuse[m]=(rec,obj);inputs[str(obj)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
if (out/'before.json').exists():
 assert read(out/'before.json')==owner
 done=read(out/'completed.json')
else:
 assert {p.name for p in out.iterdir()}=={'output.lock'};save(out/'before.json',owner);save(out/'inventory.json',{'modules':rows,'targets':args.target,'external_imports':sorted(external)});save(out/'toolchain.json',read(B/'toolchain.json'));done={};save(out/'completed.json',done)
for row in rows:
 m=row['module'];obj=cache/(m.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True)
 for parent in obj.parents:
  assert not parent.is_symlink()
  if parent==cache:break
 deps={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 for d,h in deps.items():assert sha(cache/(d.replace('.','/')+'.olean'))==h
 def usable(rec,path):return rec['status']=='PASS'and rec['source_sha256']==row['source_sha256']and rec['dependencies']==deps and path.is_file()and sha(path)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
 if m in done and usable(done[m],obj):continue
 source=workspace/(m.replace('.','/')+'.lean');source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(Path(row['source']).read_bytes())
 choices=[('isolated_checked',reuse[m])]if m in reuse else []
 if m in basis:choices.append(('phase8_checked',basis[m]))
 for origin,(rec,prior)in choices:
  if usable(rec,prior):
   obj.unlink(missing_ok=True);obj.symlink_to(prior);done[m]={**rec,'origin':origin};save(out/'completed.json',done);print('REUSE',m,origin,flush=True);break
 else:
  attempts=out/'attempts';attempts.mkdir(exist_ok=True);attempt=attempts/(str(len(list(attempts.iterdir()))+1).zfill(3)+'-'+m);attempt.mkdir();(attempt/source.name).write_bytes(source.read_bytes());log=attempt/'compiler.log';record=attempt/'record.json';obj.unlink(missing_ok=True)
  timeout=900 if 'KSites215Batch'in m else 120;cmd=[str(C),'-j1','-M12288','--root='+str(workspace),'-o',str(obj),str(source)]
  rec={'module':m,'source':str(source),'source_sha256':row['source_sha256'],'candidate':row['source'],'dependencies':deps,'command':cmd,'timeout_seconds':timeout,'memory_mebibytes':12288,'compiler_sha256':sha(C),'helper_sha256':sha(H),'log':str(log),'origin':'phase9_fresh'}
  print('CHECK',m,flush=True);ok=driver.run_locked(cmd,R,env,LOCK,log,timeout,rec,record);txt=log.read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt);rec.update(warnings=txt.count('warning:'),reports=reports,object_sha256=sha(obj)if ok else None);save(record,rec);print(rec['status'],m,round(rec['seconds'],3),rec['warnings'],'warnings',flush=True)
  assert ok and not rec['timed_out'],m;assert 'sorryAx'not in txt
  assert all({s.strip()for s in ax.split(',')if s.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports)
  if m in overrides and 'reports'in overrides[m]:assert [n for n,_ in reports]==overrides[m]['reports'];assert rec['warnings']==0
  assert sha(source)==row['source_sha256'];done[m]=rec;save(out/'completed.json',done)
 assert sha(obj)==done[m]['object_sha256']
def postcheck():
 for p,h in inputs.items():assert sha(p)==h,p
 for row in rows:
  rec=done[row['module']];assert sha(row['source'])==rec['source_sha256']==row['source_sha256'];assert rec['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'};assert sha(cache/(row['module'].replace('.','/')+'.olean'))==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256']
postcheck();audits=[]
if args.audit_endpoint:
 assert 'BusyBeaver.ZFC.KEndpoint215'in seen
 gates=Path('/tmp/k215-proof-phase8/gates.py');assert sha(gates)=='b2dcfb0f69372e25b14ed479382739966bad1488dc05289b3e5fc4ed7bdc1475';spec=importlib.util.spec_from_file_location('audit_gates',gates);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 for name,pin in g.AUDIT_PINS.items():
  src=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean'/(name+'.lean');assert sha(src)==pin;adir=out/('audit-'+name);adir.mkdir();target=adir/src.name;target.write_bytes(src.read_bytes());obj=adir/(name+'.olean');log=adir/(name+'.log');record=adir/(name+'.json');cmd=[str(C),'-j1','-M12288','--root='+str(adir),'-o',str(obj),str(target)]
  rec={'module':name,'source':str(src),'source_sha256':pin,'dependencies':{m:r['object_sha256']for m,r in done.items()},'command':cmd,'timeout_seconds':120,'memory_mebibytes':12288,'compiler_sha256':sha(C),'log':str(log)};print('AUDIT',name,flush=True);ok=driver.run_locked(cmd,R,env,LOCK,log,120,rec,record);assert ok;rec.update(named_reports=g.audit_reports(name,log.read_text()),object_sha256=sha(obj));save(record,rec);audits.append(rec)
postcheck()
for rec in audits:
 assert sha(rec['log'])==rec['log_sha256'];assert sha(rec['source'])==rec['source_sha256'];assert sha(out/('audit-'+rec['module'])/(rec['module']+'.olean'))==rec['object_sha256']
save(out/'result.json',{'status':'PASS','targets':args.target,'selected_project_modules':len(done),'fresh_modules':[m for m,r in done.items()if r['origin']=='phase9_fresh'],'phase8_reused_modules':[m for m,r in done.items()if r['origin']=='phase8_checked'],'isolated_reused_modules':[m for m,r in done.items()if r['origin']=='isolated_checked'],'audits':audits,'inputs_sources_objects_dependencies_logs_toolchain_rechecked':True,'inventory_sha256':sha(out/'inventory.json'),'completed_sha256':sha(out/'completed.json'),'runner_sha256':sha(__file__),'map_sha256':sha(args.map),'scope':'Candidate incremental closure only; exact targets/fresh/reused providers listed. No implicit canonical adoption or formalization claim for other targets.'});print('COMPLETE',len(done),len(audits),'audits',flush=True)
