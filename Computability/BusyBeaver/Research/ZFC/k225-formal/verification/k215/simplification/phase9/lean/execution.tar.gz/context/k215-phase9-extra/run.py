"""Check exact decoder entry and Home contracts against 194 immutable providers."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,signal
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');B=Path('/tmp/k215-phase9-zipbridge/routes-run2')
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';C=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
a=argparse.ArgumentParser();a.add_argument('run');a.add_argument('--freeze',default=str(S/'freeze.json'));a.add_argument('--reuse');args=a.parse_args();out=S/args.run;out.mkdir(exist_ok=False);F=Path(args.freeze)
assert read(B/'result.json')['status']=='PASS'
assert sha(H)=='a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd'
assert sha(C)=='e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
inv=read(B/'inventory.json');old=read(B/'completed.json');plans=read(F)['modules'];assert len(old)==len(inv['modules'])==194
inputs={str(p):sha(p)for p in [B/n for n in ['result.json','inventory.json','completed.json']]+[F,H,C,Path(__file__)]}
cache=out/'objects';done={};sources={r['module']:r for r in inv['modules']};providers={}
for row in inv['modules']:
 m=row['module'];rec=old[m];assert rec['status']=='PASS'and sha(row['source'])==row['source_sha256']==rec['source_sha256']
 assert rec['dependencies']=={d:old[d]['object_sha256']for d in row['imports']if d!='Init'}
 path=B/'objects'/(m.replace('.','/')+'.olean');assert sha(path)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
 inputs[row['source']]=row['source_sha256'];inputs[str(path)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256'];providers[m]=path
 q=cache/(m.replace('.','/')+'.olean');q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(path);done[m]=rec
for row in plans:
 path=Path(row['source']);assert sha(path)==row['source_sha256'];assert [w for l in path.read_text().splitlines()if l.startswith('import ')for w in l[7:].split()]==row['imports'];sources[row['module']]={k:row[k]for k in ['module','source','source_sha256','imports']};inputs[str(path)]=row['source_sha256']
T=Path('/tmp/k215-proof-phase8/lean-run1/toolchain.json');inputs[str(T)]=sha(T)
for key in ['lean','lake','Init.olean','project_toolchain']:
 t=read(T)[key];assert sha(t['path'])==t['sha256'];inputs[t['path']]=t['sha256']
reusable={}
if args.reuse:
 prior=Path(args.reuse)
 for row in plans:
  m=row['module'];record=prior/(m.rsplit('.',1)[1]+'.json')
  if record.exists():
   rec=read(record)
   if rec['status']=='PASS' and rec['source_sha256']==row['source_sha256']:
    obj=prior/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256'];reusable[m]=(rec,obj);inputs[str(record)]=sha(record);inputs[str(obj)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
save(out/'before.json',{'inputs':inputs,'all194_basis_records':old,'plans':plans,'scope':'Isolated all-gap decoder and Home component; no physical-site coverage or endpoint rebuild claimed.'})
spec=importlib.util.spec_from_file_location('supervisor',H);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver);env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1';fresh=[]
for row in plans:
 m=row['module'];src=out/'workspace'/(m.replace('.','/')+'.lean');src.parent.mkdir(parents=True,exist_ok=True);src.write_bytes(Path(row['source']).read_bytes());obj=cache/(m.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);assert not obj.exists();deps={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 if m in reusable:
  rec,previousobj=reusable[m];assert rec['dependencies']==deps;obj.symlink_to(previousobj);done[m]={**rec,'origin':'checked_previous_partial'};providers[m]=previousobj;print('REUSE CHECKED',m,flush=True);continue
 for d,h in deps.items():assert sha(cache/(d.replace('.','/')+'.olean'))==h
 log=out/(m.rsplit('.',1)[1]+'.log');record=out/(m.rsplit('.',1)[1]+'.json');cmd=[str(C),'-j1','-M12288','--root='+str(out/'workspace'),'-o',str(obj),str(src)]
 rec={'module':m,'source':str(src),'source_sha256':sha(src),'candidate':row['source'],'dependencies':deps,'command':cmd,'timeout_seconds':120,'memory_mebibytes':12288,'compiler_sha256':sha(C),'helper_sha256':sha(H),'log':str(log),'origin':'fresh_component_module'}
 print('CHECK',m,flush=True);ok=driver.run_locked(cmd,R,env,LOCK,log,120,rec,record);text=log.read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text);rec.update({'warnings':text.count('warning:'),'reports':reports,'object_sha256':sha(obj)if ok else None});save(record,rec);print(rec['status'],m,round(rec['seconds'],3),len(reports),'reports',rec['warnings'],'warnings',flush=True)
 assert ok and not rec['timed_out'],m
 assert [n for n,_ in reports]==row['reports'],reports
 assert rec['warnings']==0
 assert all({s.strip()for s in ax.split(',')if s.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in reports)
 assert sha(src)==row['source_sha256'];done[m]=rec;fresh.append(m);providers[m]=obj
for p,h in inputs.items():assert sha(p)==h,p
assert len(done)==194+len(plans)
for m,rec in done.items():
 assert sha(cache/(m.replace('.','/')+'.olean'))==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256'];r=sources[m];assert sha(r['source'])==r['source_sha256'];assert rec['dependencies']=={d:done[d]['object_sha256']for d in r['imports']if d!='Init'}
save(out/'completed.json',done);save(out/'inventory.json',{'modules':list(sources.values()),'new_modules':[r['module']for r in plans]});result={'status':'PASS','fresh_modules':fresh,'reused_checked_modules':len(reusable),'immutable_provider_basis':194,'selected_union_modules':len(done),'named_reports':sum(len(done[r['module']]['reports'])for r in plans),'warnings':sum(done[r['module']]['warnings']for r in plans),'all_sources_objects_logs_toolchain_checked_after_new_modules':True,'scope':'Isolated all-gap exact decoder entry and Home guard component; primary endpoint remains phase8.','runner_sha256':sha(__file__)};save(out/'result.json',result);print(json.dumps(result,indent=2))
