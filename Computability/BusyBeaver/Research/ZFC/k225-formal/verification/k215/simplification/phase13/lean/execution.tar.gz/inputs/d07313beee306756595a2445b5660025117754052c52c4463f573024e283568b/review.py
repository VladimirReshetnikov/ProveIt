"""Read-only actual acceptance: exact source/import ancestry and all raw providers."""
from pathlib import Path
import argparse,ast,hashlib,importlib.util,json,re
S=Path('/tmp/k215-phase13-upstream-check');E=Path(__file__).resolve().parent
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');B=Path('/tmp/k215-phase12-import-check/primary-run1');BC=Path('/tmp/k215-phase12-import-check/compatibility-run1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def load(name,p,pin):
 assert sha(p)==pin;spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
ap=argparse.ArgumentParser();ap.add_argument('--label',choices=['primary-run1','compatibility-run1'],required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();O=S/a.label
assert not a.output.exists()
result=read(O/'result.json');before=read(O/'before.json');inv=read(O/'inventory.json');done=read(O/'completed.json');outer=read(E/(a.label+'-outer.json'))
assert outer['status']=='OUTER_EXIT_0'and outer['exit_code']==0 and outer['exception']is None and outer['helper_inputs_unchanged']and outer['plan_unchanged']
for k in ['stdout','stderr']:assert sha(outer[k])==outer[k+'_sha256']
for p,h in outer['before_helper_inputs'].items():assert sha(p)==h
assert sha(outer['plan'])==outer['plan_sha256']and read(outer['plan'])['command']==outer['command']
assert result['status']=='PASS'and result['inventory_sha256']==sha(O/'inventory.json')and result['completed_sha256']==sha(O/'completed.json')
assert result['runner_sha256']==sha(S/'build.py')and result['basis_result_sha256']==sha(B/'result.json')and result['compatibility_basis_result_sha256']==sha(BC/'result.json')
mp_path=Path(outer['command'][outer['command'].index('--map')+1]);mp=read(mp_path);assert sha(mp_path)==result['map_sha256']==before['map_sha256']
assert before['runner_sha256']==result['runner_sha256']
assert before['targets']==inv['targets']==result['targets']
assert [r['module']for r in inv['modules']]==mp['expected']['modules']
rows={r['module']:r for r in inv['modules']};assert set(rows)==set(done)and len(rows)==len(inv['modules'])
old={};oldrows={};old_dirs={};old_kinds={}
for directory,kind in [(BC,'phase12_compatibility_checked'),(B,'phase12_primary_checked')]:
 parent=read(directory/'completed.json');entries={r['module']:r for r in read(directory/'inventory.json')['modules']};res=read(directory/'result.json')
 assert res['status']=='PASS'and sha(directory/'completed.json')==res['completed_sha256']and sha(directory/'inventory.json')==res['inventory_sha256']
 for m,rec in parent.items():
  if m in old:assert rec['source_sha256']==old[m]['source_sha256']and rec['object_sha256']==old[m]['object_sha256']and entries[m]['imports']==oldrows[m]['imports']
  old[m]=rec;oldrows[m]=entries[m];old_dirs[m]=directory;old_kinds[m]=kind
assert len(old)==201
C='/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean'
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
supervisor=load('supervisor',H,'a3cf7cc38004bca5e2a2df10c607fe5353896c0454069b4ff24d6b5176c32fbd')
gates=load('gates',Path('/tmp/k215-proof-phase8/gates.py'),'b2dcfb0f69372e25b14ed479382739966bad1488dc05289b3e5fc4ed7bdc1475')
for p,h in before['inputs'].items():assert sha(p)==h,p
for p in before['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink(),p
changed={m for m,r in rows.items()if m not in oldrows or r['source_sha256']!=oldrows[m]['source_sha256']};forced=set(changed)
while True:
 new=forced|{m for m,r in rows.items()if set(r['imports'])&forced}
 if new==forced:break
 forced=new
assert sorted(changed)==mp['expected']['changed']==result['source_changed_modules']==before['changed_sources']
assert sorted(forced)==mp['expected']['forced']==result['force_basis_rebuild_modules']==before['force_basis_rebuild']
secondary={};secondary_rows={};secondary_dir=None
if 'reuse_ledger'in mp:
 pins=mp['reuse_ledger'];secondary_dir=Path(pins['directory'])
 for n in ['result.json','inventory.json','completed.json']:assert sha(secondary_dir/n)==pins[n]
 secresult=read(secondary_dir/'result.json');assert secresult['status']=='PASS'and secresult['completed_sha256']==pins['completed.json']and secresult['inventory_sha256']==pins['inventory.json']
 secondary=read(secondary_dir/'completed.json');secondary_rows={r['module']:r for r in read(secondary_dir/'inventory.json')['modules']}
closure_memo={}
def equal_closure(m,provider):
 if m=='Init':return True
 key=(m,id(provider))
 if key in closure_memo:return closure_memo[key]
 a=rows[m];b=provider.get(m)
 closure_memo[key]=bool(b and a['source_sha256']==b['source_sha256']and a['imports']==b['imports']and all(equal_closure(d,provider)for d in a['imports']))
 return closure_memo[key]
overrides={r['module']:r for r in mp['modules']};counts={};warnings={};reports={};pin_rows={}
for m,row in rows.items():
 rec=done[m];assert rec['status']=='PASS'and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
 assert sha(row['source'])==row['source_sha256']==rec['source_sha256'];clean=supervisor.without_comments_strings(Path(row['source']).read_text());assert [w for line in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',clean)for w in line.split()]==row['imports']
 deps={d:done[d]['object_sha256']for d in row['imports']if d!='Init'};assert rec['dependencies']==deps
 obj=O/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256'];assert sha(O/'workspace'/(m.replace('.','/')+'.lean'))==row['source_sha256']
 text=Path(rec['log']).read_text();assert 'error:'not in text and 'sorryAx'not in text
 rep=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",text)
 assert all({x.strip()for x in ax.split(',')if x.strip()}<={'propext','Classical.choice','Quot.sound'}for _,ax in rep)
 if 'reports'in overrides.get(m,{}):assert [n for n,_ in rep]==overrides[m]['reports']and 'warning:'not in text
 if 'report_axioms'in overrides.get(m,{}):assert [{x.strip()for x in ax.split(',')if x.strip()}for _,ax in rep]==[set(x)for x in overrides[m]['report_axioms']]
 origin=rec['origin'];counts[origin]=counts.get(origin,0)+1;warnings[origin]=warnings.get(origin,0)+text.count('warning:');reports[origin]=reports.get(origin,0)+len(rep)
 if origin=='candidate_fresh':
  assert not obj.is_symlink();source=O/'workspace'/(m.replace('.','/')+'.lean')
  assert rec['command']==[C,'-j1','-M12288','--root='+str(O/'workspace'),'-o',str(obj),str(source)]
  assert rec['timeout_seconds']==(900 if 'KSites215Batch'in m else 120)and rec['memory_mebibytes']==12288
  assert rec['compiler_sha256']==sha(C)and rec['helper_sha256']==sha(H)
  assert read(Path(rec['log']).parent/'record.json')==rec
  assert sha(Path(rec['log']).parent/source.name)==row['source_sha256']
 elif origin in ['phase12_primary_checked','phase12_compatibility_checked','secondary_checked']:
  parent=secondary if origin=='secondary_checked'else old;prior_dir=secondary_dir if origin=='secondary_checked'else old_dirs[m]
  if origin!='secondary_checked':assert origin==old_kinds[m]
  assert {k:v for k,v in rec.items()if k!='origin'}=={k:v for k,v in parent[m].items()if k!='origin'}
  assert equal_closure(m,secondary_rows if origin=='secondary_checked'else oldrows)
  if origin!='secondary_checked':assert m not in forced
  assert obj.is_symlink()and obj.resolve()==(prior_dir/'objects'/(m.replace('.','/')+'.olean')).resolve()
 else:raise AssertionError(origin)
 pin_rows[m]={'source_sha256':row['source_sha256'],'object_sha256':rec['object_sha256'],'log_sha256':rec['log_sha256'],'imports':row['imports'],'origin':origin}
assert result['fresh_modules']==[m for m in done if done[m]['origin']=='candidate_fresh']
assert result['phase12_primary_reused_modules']==[m for m in done if done[m]['origin']=='phase12_primary_checked']
assert result['phase12_compatibility_reused_modules']==[m for m in done if done[m]['origin']=='phase12_compatibility_checked']
assert result['secondary_reused_modules']==[m for m in done if done[m]['origin']=='secondary_checked']
if a.label=='primary-run1':
 assert counts=={'phase12_primary_checked':151,'candidate_fresh':36}and len(rows)==187
 assert [r['module']for r in result['audits']]==list(gates.AUDIT_PINS)
 for rec in result['audits']:
  name=rec['module'];d=O/('audit-'+name);src=d/(name+'.lean');obj=d/(name+'.olean')
  assert rec['status']=='PASS'and rec['exit_code']==0 and not rec['timed_out'];assert sha(rec['log'])==rec['log_sha256'];assert sha(rec['source'])==sha(src)==rec['source_sha256']==gates.AUDIT_PINS[name]
  assert rec['command']==[C,'-j1','-M12288','--root='+str(d),'-o',str(obj),str(src)]and rec['timeout_seconds']==120 and rec['memory_mebibytes']==12288
  assert rec['compiler_sha256']==sha(C)and sha(obj)==rec['object_sha256'];assert rec['dependencies']=={m:r['object_sha256']for m,r in done.items()}
  assert [list(x)for x in gates.audit_reports(name,Path(rec['log']).read_text())]==rec['named_reports']
 for m in rows:
  if 'KSites215Batch'in m:assert done[m]['object_sha256']==old[m]['object_sha256']and done[m]['log_sha256']==old[m]['log_sha256']
else:
 assert counts=={'secondary_checked':53,'phase12_compatibility_checked':1,'candidate_fresh':16}and len(rows)==70 and not result['audits']
# Repeat every input/provider hash after the complete audit rather than relying on initial acceptance.
for p,h in before['inputs'].items():assert sha(p)==h,p
for m,r in done.items():assert sha(O/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']
for p in before['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink()
receipt={'status':'PASS_READ_ONLY_TRANSITIVE_ACTUAL','run':str(O),'result_sha256':sha(O/'result.json'),'before_sha256':sha(O/'before.json'),'inventory_sha256':sha(O/'inventory.json'),'completed_sha256':sha(O/'completed.json'),'outer_sha256':sha(E/(a.label+'-outer.json')),'reviewer_sha256':sha(__file__),'project_and_client_modules':len(rows),'origins':counts,'warning_occurrences_by_origin':warnings,'report_occurrences_by_origin':reports,'fresh_endpoint_audit_reports':sum(len(r['named_reports'])for r in result['audits']),'all_inputs_sources_objects_logs_rehashed':True,'source_transitive_reuse_checked':True,'retired_templates_still_absent':True,'pins':pin_rows,'compiler_invoked_by_review':False}
a.output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='pins'},indent=2))
