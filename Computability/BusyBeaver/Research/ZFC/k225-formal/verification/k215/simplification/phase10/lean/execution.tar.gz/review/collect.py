"""Capture immutable terminal evidence only; never run Lean or a supplied generator."""
from pathlib import Path
import argparse,fcntl,gzip,io,json,tarfile
import basis,packet
S=Path(__file__).resolve().parent;R=Path(packet.ROOT)
read=lambda p:json.loads(Path(p).read_text())
def collect(repo,out):
 assert not out.exists()
 loaded=basis.load(repo);prior,_,_=loaded;members={};routes={};hashes={}
 for key,data in prior.items():hashes.setdefault(packet.digest(data),('phase9',key))
 def put(name,data):
  packet.safe(name)
  if name in members:assert members[name]==data
  members[name]=data;hashes.setdefault(packet.digest(data),('packet',name))
 def add(path,data=None,name=None,force=False):
  path=str(path);data=Path(path).read_bytes()if data is None else data;pin=packet.digest(data)
  if path in routes:
   assert routes[path]['sha256']==pin;return
  if force or pin not in hashes:
   key=name or'inputs/'+pin+'/'+Path(path).name;put(key,data);storage='packet'
  else:storage,key=hashes[pin]
  routes[path]={'storage':storage,'key':key,'sha256':pin,'bytes':len(data)}
 producer=read('/tmp/k215-phase10-main/producer-before.json');historical={r['canonical']:r for r in producer['files']};assert len(historical)==5
 for row in historical.values():
  data=Path(row['historical_snapshot']).read_bytes();assert packet.digest(data)==row['sha256']and len(data)==row['bytes']
  add(row['canonical'],data,'producer-before/'+Path(row['canonical']).relative_to(R).as_posix(),True);add(row['historical_snapshot'],data)
 tool=read(Path(packet.RUN)/'toolchain.json');toolbins={x['path']for x in tool.values()if isinstance(x,dict)and'path'in x and(x['path'].endswith('/bin/lean')or x['path'].endswith('/bin/lake')or x['path'].endswith('.olean'))}
 for root,label in [(Path(packet.RUN),'execution'),(Path(packet.ISO),'isolated')]:
  with(root/'output.lock').open('a')as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  result=read(root/'result.json');assert result['status']=='PASS'
  for name in['result.json','before.json','inventory.json','completed.json','toolchain.json']:add(root/name,name=label+'/'+name,force=True)
  inv=read(root/'inventory.json');done=read(root/'completed.json');before=read(root/'before.json')
  for path,pin in before['inputs'].items():
   if path in toolbins or set(Path(path).suffixes)&packet.BINARY:continue
   if path not in historical:add(path)
   assert routes[path]['sha256']==pin
  for row in inv['modules']:
   m=row['module'];rec=done[m];add(row['source']);add(rec['log'])
   if rec['origin']=='phase9_fresh':
    add(rec['source'],name=label+'/fresh/'+m+'/source.lean',force=True)
    add(Path(rec['log']).parent/'record.json',name=label+'/fresh/'+m+'/record.json',force=True)
  for audit in result['audits']:
   q=root/('audit-'+audit['module'])
   for name in[audit['module']+'.lean',audit['module']+'.log',audit['module']+'.json']:add(q/name,name=label+'/audits/'+name,force=True)
   add(audit['source'])
 # Small explicit provenance; source/control histories remain raw, not executed here.
 context=[S/'helper-correction.json',S/'warning-scope-correction.json',S/'warning-scope.diff',*(S/'history').rglob('*')]
 for directory in[Path('/tmp/k215-phase10-main-peer'),Path('/tmp/k215-generic-cd52-check')]:
  context.extend(p for p in directory.iterdir()if p.is_file())
 context.extend(Path('/tmp/k215-generic-cd52-check/history').rglob('*'))
 context.extend(Path('/tmp/k215-generic-cd52-check/clients').glob('*.lean'))
 for name in['producer-before.json','adoption.json','outer-terminal.json','producer-execution.json','reproduce.py','generate.stdout.json','generate.stderr.txt','check.stdout.json','check.stderr.txt','maintained-producer-check.json','maintained-producer-check.stdout.json','maintained-producer-check.stderr.txt','canonical-review.json','canonical_review.py','prepare.py']:
  p=Path('/tmp/k215-phase10-main')/name;assert p.is_file();context.append(p)
 for p in sorted(set(context)):
  if p.is_file():add(p,name='context/'+str(p).lstrip('/'),force=True)
 adoption=read('/tmp/k215-phase10-main/adoption.json')
 for row in adoption['files']:
  data=Path(row['source']).read_bytes();assert packet.digest(data)==row['sha256']and data==(R/row['target']).read_bytes()
  put('adoption/'+row['target'],data)
 for name in['basis.py','basis-reference.json','packet.py','review_saved.py','collect.py','README.md']:
  put('review/'+name,(S/name).read_bytes())
 put('path-map.json',packet.dump(routes))
 checked=packet.validate(members,repo,loaded,current_repo=repo)
 # A collector postcheck reads live objects; the saved reader later checks only recorded fingerprints.
 for root in[Path(packet.RUN),Path(packet.ISO)]:
  before=read(root/'before.json');done=read(root/'completed.json');inv=read(root/'inventory.json')
  for p,pin in before['inputs'].items():
   actual=historical[p]['historical_snapshot']if p in historical else p
   assert packet.sha(actual)==pin
  for row in inv['modules']:
   rec=done[row['module']];assert packet.sha(row['source'])==row['source_sha256'];assert packet.sha(rec['log'])==rec['log_sha256'];assert packet.sha(root/'objects'/(row['module'].replace('.','/')+'.olean'))==rec['object_sha256']
  for rec in read(root/'result.json')['audits']:
   assert packet.sha(root/('audit-'+rec['module'])/(rec['module']+'.olean'))==rec['object_sha256'];assert packet.sha(rec['log'])==rec['log_sha256']
 post={'status':'PASS_LIVE_POSTCHECK','main_modules':197,'isolated_modules':16,'audit_objects':2,'all_live_sources_objects_logs_rehashed':True,'all_nonproducer_inputs_current_exact':True,'old5_producer_snapshot_pins_exact':True,'producer_canonical_changes':[p for p,r in historical.items()if packet.sha(p)!=r['sha256']],'scope':'Original raw before inputs retained; only the five explicitly archived old producer blobs are read from snapshots after intentional adoption.'}
 assert len(post['producer_canonical_changes'])==3
 put('review/live-postcheck.json',packet.dump(post));index=packet.manifest(members)
 out.mkdir(parents=True)
 with(out/'execution.tar.gz').open('wb')as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as zipped:
   with tarfile.open(fileobj=zipped,mode='w')as archive:
    for name,data in sorted(members.items()):
     info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
 (out/'index.json').write_bytes(packet.dump(index))
 summary={**checked,'status':'PASS_COLLECTED_PHASE10','archive_sha256':packet.sha(out/'execution.tar.gz'),'archive_members':len(members),'index_sha256':packet.sha(out/'index.json'),'live_postcheck':post}
 (out/'result.json').write_bytes(packet.dump(summary))
 for name in['basis.py','basis-reference.json','packet.py','review_saved.py','README.md']:(out/name).write_bytes((S/name).read_bytes())
 print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--basis-repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();collect(a.basis_repo,a.out)
