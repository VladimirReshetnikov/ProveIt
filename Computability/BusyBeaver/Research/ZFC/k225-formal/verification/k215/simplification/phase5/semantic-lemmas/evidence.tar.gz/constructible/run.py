from pathlib import Path
import argparse, hashlib, importlib.util, json, os, shutil, signal
ROOT=Path('/tmp/k215-constructible-transport');REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
BASIS=Path('/tmp/k215-proof-phase4/lean-run1');HELPER=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
COMPILER=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean');LOCK=Path('/tmp/proveit-k215-proof-build.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def abort(*_):raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM,abort)
a=argparse.ArgumentParser();a.add_argument('name');a.add_argument('--source',type=Path,default=ROOT/'ConstructibleAbs.lean');args=a.parse_args()
out=ROOT/args.name;out.mkdir(exist_ok=False)
old=json.loads((BASIS/'completed.json').read_text());pins={m:sha(BASIS/'objects'/(m.replace('.','/')+'.olean')) for m in old}
assert all(pins[m]==r['object_sha256'] for m,r in old.items())
cache=out/'objects'
for m in old:
 p=cache/(m.replace('.','/')+'.olean');p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(BASIS/'objects'/(m.replace('.','/')+'.olean'))
module='BusyBeaver.ZFC.ConstructibleAbs';source=out/'workspace'/(module.replace('.','/')+'.lean');source.parent.mkdir(parents=True);shutil.copyfile(args.source,source)
obj=cache/(module.replace('.','/')+'.olean');obj.unlink()
spec=importlib.util.spec_from_file_location('kernel_driver',HELPER);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
row={'source_sha256':sha(source),'source':str(source),'basis_completed_sha256':sha(BASIS/'completed.json'),'basis_objects':pins,'compiler_sha256':sha(COMPILER),'helper_sha256':sha(HELPER),'runner_sha256':sha(__file__),'timeout_seconds':120,'memory_mebibytes':12288}
cmd=[str(COMPILER),'-j1','-M12288','--root='+str(out/'workspace'),'-o',str(obj),str(source)];row['command']=cmd
ok=driver.run_locked(cmd,REPO,env,LOCK,out/'compiler.log',120,row,out/'result.json')
row['basis_unchanged']=all(sha(BASIS/'objects'/(m.replace('.','/')+'.olean'))==h for m,h in pins.items());row['source_unchanged']=sha(source)==row['source_sha256'];row['warnings']=(out/'compiler.log').read_text().count('warning:')
if ok:row['object_sha256']=sha(obj)
assert row['basis_unchanged'] and row['source_unchanged']
(out/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='basis_objects'},indent=2));print((out/'compiler.log').read_text());raise SystemExit(0 if ok else 1)
