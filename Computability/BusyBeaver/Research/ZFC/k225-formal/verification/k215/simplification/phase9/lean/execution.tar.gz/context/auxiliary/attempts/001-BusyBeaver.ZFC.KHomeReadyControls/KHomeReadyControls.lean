import BusyBeaver.ZFC.KHomeReady
import BusyBeaver.ZFC.KFast215

/-! External controls for the table gate. The three finite checks use the
balanced actual table; the fallback equalities quantify over every table. -/
namespace SetTheory.BusyBeaver.ZFC.KHomeReadyControls
open KZip KRuntimeCore KBoot KBoot215

private def machine : TMN := fastOf tt215

theorem ready215 : KHomeReady.ready machine = true := by decide

/-- Corrupt the first boundary-only scan transition, retaining every word row. -/
private def badBoundary : TMN := fun q b =>
  if q = 50 ∧ b = false then some (false, false, 50) else machine q b

theorem word_rows_still_pass : KHomeReady.rowsCheck badBoundary = true := by decide

theorem boundary_gate_rejects : KHomeReady.ready badBoundary = false := by decide

/-- A failed table gate is literally the original abstract transition function. -/
theorem fallback_stepper (M : TMN) (br : Branch) (h : KHomeReady.ready M = false) :
    KHomeReady.stepper M br = sstep M br := by
  simp [KHomeReady.stepper, h]

/-- The fallback preserves all fuel, target and progress-flag behavior. -/
theorem fallback_executor (M : TMN) (br : Branch) (tgt : SConf → Bool)
    (h : KHomeReady.ready M = false) :
    KHomeReady.exec M br tgt = KRuntimeCore.exec M br tgt := by
  simp only [KHomeReady.exec, KRuntimeCore.exec, fallback_stepper M br h]

#print axioms ready215
#print axioms word_rows_still_pass
#print axioms boundary_gate_rejects
#print axioms fallback_stepper
#print axioms fallback_executor
end SetTheory.BusyBeaver.ZFC.KHomeReadyControls
