"""Source-only API and executable-definition comparison; no Lean invocation."""
from pathlib import Path
import re,json,hashlib,importlib.util,subprocess
P=Path(__file__).resolve().parent
REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
HELPER=REPO/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py'
spec=importlib.util.spec_from_file_location('reviewed_parser',HELPER);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=P/'EnumPerm-original.lean';new=P/'upstream/BusyBeaver/ZFC/EnumPerm.lean'
def declarations(path):
 s=h.without_comments_strings(path.read_text())
 matches=list(re.finditer(r'(?m)^(def|abbrev|theorem|structure|inductive) ([\w.]+)',s))
 return {m[2]:(m[1],s[m.start():matches[i+1].start() if i+1<len(matches) else s.index('\nend ',m.start())].strip()) for i,m in enumerate(matches)}
a,b=declarations(old),declarations(new)
operational=['unP','St','axStack','gate','Cmd','W','cstep','pack','decode','encL','toW','fetch','execAt','enumStep','run','HaltsFrom','tailN','Good','Inv','cexec','nips','Contract','discard','J','leaf','bundleLeaf','genBlock','mpBlock']
normalize=lambda s:' '.join(s.split())
for n in operational:
 assert normalize(a[n][1])==normalize(b[n][1]),n
# Strip the proof at the first :=, or equation alternatives for equation-style theorems.
def statement(s):return re.split(r'\s:=|\n  \|',s,maxsplit=1)[0].strip()
common=[n for n in a.keys()&b.keys() if a[n][0]=='theorem']
changed=[n for n in sorted(common) if normalize(statement(a[n][1]))!=normalize(statement(b[n][1]))]
assert changed==['cexec_discard_ax'],changed
removed=sorted(a.keys()-b.keys())
consumers={}
root=REPO/'Computability/BusyBeaver/Lean'
for p in root.rglob('*.lean'):
 if p.name=='EnumPerm.lean':continue
 s=h.without_comments_strings(p.read_text())
 if 'EnumPerm' in s:
  matches=[n for n in removed if re.search(r'(?<![\w.])(?:EnumPerm\.)?'+re.escape(n)+r'(?![\w.])',s)]
  assert not matches,(p,matches)
  consumers[str(p.relative_to(REPO))]=sha(p)
result={'status':'PASS_SOURCE_COMPARISON','old_sha256':sha(old),'upstream_sha256':sha(new),'upstream_commit':json.loads((P/'upstream.json').read_text())['commit'],'operational_definitions_exact':operational,'common_public_theorem_statements_unchanged':len(common)-1,'definitionally_equivalent_target_change':'cexec_discard_ax replaces pushL(axList...++[0]) S by the literal axStack expansion; checked by source comparison, not a separate old-helper typed client.','removed_unused_scaffolding':removed,'EnumPerm_consumers_without_removed_references':consumers,'old_lines':len(old.read_text().splitlines()),'new_lines':len(new.read_text().splitlines()),'scope':'Source comparison only; kernel results are separate. Other Enum namespaces may define same unqualified helper names.'}
(P/'source-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
