from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shutil
p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('--timeout',type=float,default=120);a=p.parse_args()
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs');base=Path('/tmp/k215-concision-round2/root');old=Path('/tmp/k215-proof-simplification/root/objects')
run=base/f'run{1+len(list(base.glob("run*"))):03d}';run.mkdir();workspace=run/'workspace';src=workspace/'BusyBeaver/ZFC/RMDag.lean';src.parent.mkdir(parents=True);src.write_bytes(a.source.read_bytes());cache=run/'objects';cache.mkdir()
for f in old.rglob('*.olean'):
 t=cache/f.relative_to(old);t.parent.mkdir(parents=True,exist_ok=True);t.symlink_to(f)
obj=cache/'BusyBeaver/ZFC/RMDag.olean';obj.unlink();lean=Path('/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
spec=importlib.util.spec_from_file_location('driver',repo/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1';cmd=[str(lean),'-j1','-M4096','--root='+str(workspace),'-o',str(obj),str(src)];row={'source_sha256':driver.sha(src),'compiler_sha256':driver.sha(lean),'command':cmd}
print('CHECK',run,flush=True);ok=driver.run_locked(cmd,repo,env,Path('/tmp/proveit-k215-proof-build.lock'),run/'compiler.log',a.timeout,row,run/'record.json');row['source_unchanged']=driver.sha(src)==row['source_sha256'];assert row['source_unchanged'];row['object_sha256']=driver.sha(obj)if obj.exists()else None;(run/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2),flush=True);print((run/'compiler.log').read_text()[-14000:],flush=True)
raise SystemExit(0 if ok else 1)
