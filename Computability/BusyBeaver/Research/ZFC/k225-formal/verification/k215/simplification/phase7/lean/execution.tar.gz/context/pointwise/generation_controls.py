"""Run only our reviewed pointwise source producer, never Lean or delivered builders."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
O=Path('/tmp/k215-b070-domrho8-review');R=Path('/home/codex/.codex/worktrees/ec20/Proofs');W=Path('/tmp/k215-domrho8-pointwise/generation');W.mkdir(exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest()
cert=O/'delivery/inputs/dominated_rho8_full_certificate.json';lf=O/'delivery/inputs/149-dom-theory-ev-CD230.v';gen=Path('/tmp/k215-domrho8-pointwise/generate_domrho8_lean.py');want=Path('/tmp/k215-domrho8-pointwise/DomRho8.lean').read_bytes()
assert h(want)=='987a8b573a50bc72c0796e9c783595534289eae96dfbe9278107629bcc92bae9'
assert h(gen.read_bytes())=='b5421e8289a29109e80c618db61c05a7fb79c481b5cf97c0deaba5aded46e56d'
assert b'\r' not in lf.read_bytes()
crlf=W/'template-crlf.v';crlf.write_bytes(lf.read_bytes().replace(b'\n',b'\r\n'))
badtemplate=W/'template-changed.v';badtemplate.write_bytes(lf.read_bytes()+b'\n')
mixed=W/'template-mixed.v';mixed.write_bytes(lf.read_bytes().replace(b'\n',b'\r\n',1))
badcert=W/'certificate-changed.json';badcert.write_bytes(cert.read_bytes()+b'\n')
layout=W/'layout';layoutgen=layout/'Computability/BusyBeaver/Research/ZFC/k225-formal/generate_domrho8_lean.py';layoutgen.parent.mkdir(parents=True);layoutgen.write_bytes(gen.read_bytes());layouttemplate=layout/'SetTheory/Cardinals/docs/reports/set-theory/zfc-closure-kernels/code/149-dom-theory-ev-CD230.v';layouttemplate.parent.mkdir(parents=True);layouttemplate.write_bytes(lf.read_bytes())
rows=[]
inputs=[cert,lf,crlf,badtemplate,mixed,badcert,gen,layoutgen,layouttemplate]
before={str(p):h(p.read_bytes()) for p in inputs}
def run(label,producer,certificate,options,success):
 out=W/(label+'.lean');cmd=[sys.executable,'-B',str(producer),str(certificate),str(out),*map(str,options)]
 t=time.monotonic();p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30,cwd=W)
 log=W/(label+'.log');log.write_bytes(p.stdout)
 r={'label':label,'argv':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-t,'log_sha256':h(p.stdout),'expected_success':success,'output_exists':out.exists()}
 if out.exists():r.update(output_bytes=out.stat().st_size,output_sha256=h(out.read_bytes()),byte_equal_candidate=out.read_bytes()==want)
 rows.append(r)
 assert (p.returncode==0)==success,r
 if success:assert out.read_bytes()==want,r
 else:assert not out.exists(),r
run('explicit-lf',gen,cert,['--templates',lf],True)
run('explicit-crlf',gen,cert,['--templates',crlf],True)
run('default-path-lf',layoutgen,cert,[],True)
run('reject-template-byte',gen,cert,['--templates',badtemplate],False)
run('reject-template-mixed-eol',gen,cert,['--templates',mixed],False)
run('reject-certificate-byte',gen,badcert,['--templates',lf],False)
run('reject-conflicting-route',gen,cert,['--templates',lf,'--no-plan'],False)
after={str(p):h(p.read_bytes()) for p in inputs};assert before==after
baseline=O/'current/generate_domrho8_lean.py';marker='if args.plan or (not args.no_plan and hashlib.sha256(raw).hexdigest() == original149):';assert baseline.read_text().split(marker,1)[1]==gen.read_text().split(marker,1)[1]
canonical={}
for p,name in [('Computability/BusyBeaver/Lean/BusyBeaver/ZFC/DomRho8.lean','DomRho8.lean'),('Computability/BusyBeaver/Research/ZFC/k225-formal/generate_domrho8_lean.py','generate_domrho8_lean.py')]:
 assert (R/p).read_bytes()==(O/'current'/name).read_bytes();canonical[p]=h((R/p).read_bytes())
r={'status':'PASS_SOURCE_GENERATION_ONLY','scope':'Three generation positives and four rejects; no Lean/compiler, no delivered script, no source installation. Pointwise candidate remains uncompiled; unused distribution helper removed after consumer census.','producer_sha256':h(gen.read_bytes()),'candidate_sha256':h(want),'inputs_before':before,'inputs_after':after,'inputs_unchanged':before==after,'jobs':rows,'generic_plan_and_direct_suffix_byte_identical':True,'canonical_unchanged':canonical}
(W/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'positives':3,'rejects':4,'output_sha256':h(want),'output_bytes':len(want)},indent=2))
