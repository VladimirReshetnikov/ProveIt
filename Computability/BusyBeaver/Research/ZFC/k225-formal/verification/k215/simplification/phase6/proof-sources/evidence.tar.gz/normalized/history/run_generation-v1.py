"""Run only reviewed Python producers inside the disposable workspace."""
from pathlib import Path
import subprocess,time,json,hashlib,sys
O=Path(__file__).resolve().parent;W=O/'workspace';F=W/'Computability/BusyBeaver/Research/ZFC/k225-formal';L=W/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC';R=O/'generation-run1';R.mkdir(exist_ok=False)
inputs=list(F.glob('*.py'))+list((F/'lean215').glob('dagperm*.json'))+list((F.parent/'candidate-k215').iterdir())
def hashes(ps):return {str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in ps}
before=hashes(inputs);records=[]
jobs=[('source',[sys.executable,str(F/'generate_source215_lean.py'),str(F/'lean215/dagperm_nodes.json'),str(F/'lean215/dagperm_sites.json')]),('sites',[sys.executable,str(F/'generate_sites215_lean.py'),'full','80','12'])]
for name,argv in jobs:
 t=time.monotonic();p=subprocess.run(argv,cwd=W,capture_output=True,timeout=60)
 (R/(name+'.stdout')).write_bytes(p.stdout);(R/(name+'.stderr')).write_bytes(p.stderr)
 records.append({'job':name,'argv':argv,'cwd':str(W),'exit_code':p.returncode,'seconds':time.monotonic()-t,'timeout_seconds':60})
 if p.returncode:break
assert before==hashes(inputs)
result={'status':'PASS'if len(records)==2 and all(r['exit_code']==0 for r in records)else'FAIL','jobs':records,'inputs':before,'inputs_unchanged':True,'compiler_executed':False,'outputs':hashes(sorted(L.glob('*.lean')))}
(R/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['inputs','outputs']},indent=2));sys.exit(0 if result['status']=='PASS'else1)
