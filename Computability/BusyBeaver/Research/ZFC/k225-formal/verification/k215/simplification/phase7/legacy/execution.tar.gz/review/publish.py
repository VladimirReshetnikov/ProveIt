"""Stage a compact completed legacy packet after its matching live review."""
from pathlib import Path
import argparse,gzip,io,json,tarfile
from capture import args,collect
from evidence import sha,digest,read,save,validate,manifest,manifest_hash
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);args(p);p.add_argument('--live-review',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();assert not a.out.exists()
 m=collect(a.run,a.preparation,a.repo,a.stdout);check=validate(m,a.repo,a.repo);live=read(a.live_review)
 assert live['status']=='PASS_LIVE_LEGACY_POST_AUDIT_REVIEW'and live['evidence_manifest_sha256']==manifest_hash(m)
 assert all(live[k]==v for k,v in check.items()if k!='status')
 assert live['all202_selected_objects_and_logs_rehashed_after_audit']and live['all_immutable_predecessor_inputs_unchanged']and live['fresh_audit_object_rehashed']
 assert live['reviewer_sha256']==digest(m['review/review.py'])and live['validator_sha256']==digest(m['review/evidence.py'])and live['capture_sha256']==digest(m['review/capture.py'])
 m['publication/live-review.json']=a.live_review.read_bytes();index=manifest(m);a.out.mkdir()
 with(a.out/'execution.tar.gz').open('xb')as f:
  with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0)as z:
   with tarfile.open(fileobj=z,mode='w')as t:
    for n,b in sorted(m.items()):
     ti=tarfile.TarInfo(n);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
 save(a.out/'index.json',index);r=json.loads(m['execution/result.json']);save(a.out/'result.json',{**r,'execution_archive_sha256':sha(a.out/'execution.tar.gz'),'archive_members':len(index),'live_review_sha256':sha(a.live_review),'compiled_objects_in_archive':False})
 (a.out/'live-review.json').write_bytes(a.live_review.read_bytes())
 for n in ['evidence.py','review_saved.py']:(a.out/n).write_bytes(m['review/'+n])
 (a.out/'references.json').write_bytes(m['publication/references.json']);(a.out/'README.md').write_bytes(m['review/README.template.md'])
 print(json.dumps({'status':'STAGED_LEGACY_PACKET','members':len(index),'archive_sha256':sha(a.out/'execution.tar.gz'),'summary_sha256':sha(a.out/'result.json')},indent=2))
