# First shared primitive after the exact decoder prefix

Status: bounded source/math design, not compiled or adopted. No maintained file,
compiler cache, supplied executable, or running proof checkpoint was changed.
The own parser in `census.py` inspected literal finite source/role/table data;
its receipt is `census.json`.

## Concrete family and exact contract

Choose the common CB1 terminal role 16, state 108, read bit 1. It occurs at 86
of the 98 CB1 leaves. Every such complete consumed word is

    Q = A ++ [false, false, true].

The passed uniform prefix theorem reaches exactly

    leafPort (A ++ [false, false]) true 108

for every gap parameter n and every register list vs; it does not discard A.
The terminal action and next two literal rows are

    108/1 = 0 L 10
     10/0 = 0 L 16
     16/0 = 1 L 1.

They give the following three-step equation, with L = reverse A ++ [true]
and completely arbitrary right frame R:

    zc 108 (0 :: 0 :: L) (1 :: R)
      -> zc 10 (0 :: L) (0 :: 0 :: R)
      -> zc 16 L (0 :: 0 :: 0 :: R)
      -> zl 1 L (1 :: 0 :: 0 :: R).

The return is at state **1**, not state 2. The finite guard is

    KHome.LeftWord M 1 (A.reverse ++ [true]) 2.

It is a row-by-row unchanged-word property; `leftCheck_sound` gives an ordinary
inductive certificate checker for it. State 1 has false self-loop and true
transition to 2. The subsequent scan is subject to the actual Home row guards.
The last true in the checked word is the PC marker. `LeftWord.sound` stops with
that marker immediately to the right and empty left side; the existing
`KHome.Boundary M` supplies the positive final return. For A=[] the checked word
is [true], so exactly the state-1 marker transition followed by Boundary is used.
No failed `home []` shortcut is assumed.

The generic frame endpoint is

    Reach1 M
      (zc 108 (0 :: 0 :: (A.reverse ++ [true])) (1 :: R))
      (zc 84 [true] (A ++ [true,false,false] ++ R)).

This is a full zipper-frame identity, not a claim based only on opcode or the
last two path bits. The right frame is untouched. Setting
R = replicate (n + (64 - (|A|+3))) false ++ true :: sepsR vs gives, whenever
|A|+3 <= 64,

    forall n vs,
      Reach1 M
        (conc n vs (leafPort (A ++ [false,false]) true 108))
        (conc n vs (tgtConf (A ++ [true]) false (.plain .none))).

There is no register-validity/length premise or BoxLemmas premise: this suffix
never enters the register box. The generic word theorem uses only three table
rows, the exact LeftWord guard and Boundary; the concrete source family
specializes M to the formal tm215 directly, without another state renaming.

The target is the old CB1 target because

    stripPath false 1 (A ++ [false,false,true]) = A ++ [false]
    breakPath 1 (A ++ [false,false,true]) = A ++ [true]
    allOnes (A ++ [false]) = false.

The old path shortens by two, so its erased two cells extend the blank gap by
two. The stated length premise justifies natural subtraction; current family
path lengths are 9 through 44. No overflow or spare-register append occurs.
`CB1Suffix.lean` provides explicit proof bodies for the finite word checker,
return, generic three-step frame contract and exact all-n/vs target. It is an
**uncompiled draft**; elaboration and the final list/arithmetic normalization
remain to be checked in a later authorized kernel run.

## Actual census, and what it does not establish

The own literal parser traversed all 202 source nodes through 234 contextual
roles, rechecking all 4,751 leaf endpoints and their formal-table terminal rows.
There are 6,176 branch outcomes, including 1,425 double-branch decrements. It
found exactly 86 common CB1 leaves, all at role 16, and checked their finite
LeftWord guard directly against the literal table. The receipt retains every
A and row witness. No tape simulation, symbolic executor or Lean invocation
was performed. This finite census is not itself a theorem binding the 86 leaves
inside Lean; that small finite binding still needs a kernel check.

Two metadata controls cover the important guard boundary: A=[] accepts the
single marker row 1/1->2, whereas a word with eight internal zeros is rejected
by the unchanged-word checker. The latter is rejection of the sufficient
contract, not a nontermination claim for that other tape.

The 12 remaining CB1 leaves use other terminal actions. One enters state 40;
one family of 11 enters formal state 120 (native 302). They are excluded.
The increment/decrement register updates, both decrement guards, all CC paths
and halt remain on their current checks. Thus the present opportunity covers
86/6,176 branch outcomes (about 1.4%), not the entire physical-site proof.
It is small enough to test the architecture honestly before extending the
shared return lemma to other primitive families.

## Minimal integration and its present blocker

The passed `leaf_prefix`/`walk_prefix` already fixes one complete routed port
before quantifying n/vs. For this family, a finite source-role certificate gives
`RoutedEntry ... Q 108 true 2 1`; `routed_control_unique` identifies the
existential port with q108/read1, and the word split fixes its entire pre=A00.
Compose its `Reach` with `cb1_leafPort`'s positive `Reach1`. No exchange of an
all-n/vs quantifier with an existential port is needed.

There is nevertheless a real API barrier: current `KSim.Covered` stores
`checkEdge M Q e = true`, and `KSites215.all_sites` proves that exact Boolean
proposition. A mathematically proved residual does **not** imply that the old
fuel-limited checker returns true. Do not replace 86 current checks by these
lemmas while leaving those statements unchanged.

The smallest honest later integration is to factor the existing KSim simulation
proof once around the per-edge realization hypotheses it already consumes:
length <=48, register index <9 where needed, exact positive target runs for the
proper Valid branches, and halt soundness. Its old `checkEdge` path supplies
those hypotheses through `runTo_sound`/`runHalt_sound`; its old public wrappers
and generic all-M endpoints can remain. A new concrete source coverage proof
can supply the same hypotheses using this prefix+suffix theorem for the 86
members and current checker soundness elsewhere. This should replace one
proof core rather than copy `sim_step`, `sim_halt`, or `halts_iff` into a second
simulation namespace. That refactor is not implemented or assumed here.

The alternative is a genuinely generic certified-prefix hook in the executor,
with a proved all-M semantic contract, but importing concrete KDecoderPrefix215
into KSim directly would create a dependency cycle and make the generic engine
depend on a particular machine. Do not do that as a shortcut.

## Size and next check

This exploratory draft is 99 lines / 4,773 bytes before any kernel corrections,
plus a source-only finite census. The already-needed decoder library is about
67.5 KB across its five files. Covering only 86 leaves is **not** evidence of a
net source or compilation-time saving. The next useful bounded check is the
shared return + CB1 frame proof, followed by its exact 86-role binding. Only
then decide whether the single-core coverage refactor and additional primitive
families can repay the library cost. Keep the currently accepted/checking
4,751-leaf route intact in the meantime.
