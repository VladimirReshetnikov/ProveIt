"""Prospective archive/report metadata controls only; no actual capture or compiler."""
from pathlib import Path
import gzip,io,tarfile,tempfile,json,sys
sys.dont_write_bytecode=True
import evidence as E
from evidence import safe,members,manifest,reports,digest,save
from copy import deepcopy
HERE=Path(__file__).resolve().parent
rs=[]
def reject(name,f):
 try:f()
 except(AssertionError,KeyError):rs.append([name,'REJECTED']);return
 raise AssertionError('bad control accepted '+name)
for n in ['execution/result.json','preparation/history/driver.py','execution/audit/LegacyAudit.lean']:
 assert safe(n)
rs.append(['safe_names','PASS'])
for n in ['/absolute','../escape','x/../escape','a\\b','x.olean','x.olean.server','x.olean.private','x.ilean','x.pyc','x.vo']:
 reject('unsafe_'+n,lambda n=n:(_ for _ in ()).throw(AssertionError())if not safe(n)else None)
valid='\n'.join("'SetTheory.BusyBeaver.ZFC.LegacyAudit.%s' depends on axioms: [propext, Classical.choice, Quot.sound]"%n for n in ['root222','root219','rootDom','rootPerm','offset_checker'])
assert len(reports(valid))==5;rs.append(['five_named_reports','PASS'])
for n,t in [('missing',valid.split('\n',1)[1]),('reordered','\n'.join(reversed(valid.splitlines()))),('extra',valid+"\n'x' does not depend on any axioms"),('warning','warning:x\n'+valid),('error','error:x\n'+valid),('sorry',valid+' sorryAx'),('new_axiom',valid.replace('propext','AddedAxiom'))]:reject(n,lambda t=t:reports(t))
with tempfile.TemporaryDirectory(prefix='legacy-packet-control-')as d:
 d=Path(d)
 def make(name,rows):
  f=d/name
  with tarfile.open(f,'w:gz')as t:
   for n,b,kind in rows:
    ti=tarfile.TarInfo(n);ti.size=len(b)
    if kind=='link':ti.type=tarfile.SYMTYPE;ti.linkname='elsewhere';t.addfile(ti)
    else:t.addfile(ti,io.BytesIO(b))
  return f
 data={'execution/result.json':b'{}','execution/audit/compiler.log':valid.encode()};idx=manifest(data)
 f=make('ok.gz',[(n,b,'file')for n,b in data.items()]);assert members(f,idx)==data;rs.append(['indexed_archive','PASS'])
 reject('index_changed_sha',lambda:members(f,{**idx,'execution/result.json':{'bytes':2,'sha256':'0'*64}}))
 reject('index_missing_entry',lambda:members(f,{'execution/result.json':idx['execution/result.json']}))
 reject('index_unseen_entry',lambda:members(f,{**idx,'extra':{'bytes':0,'sha256':digest(b'')}}))
 for n,rows in [('link',[('execution/result.json',b'','link')]),('binary',[('x.olean.private',b'x','file')]),('duplicate',[('x',b'x','file'),('x',b'x','file')]),('traversal',[('../x',b'x','file')])]:
  f=make(n+'.gz',rows);reject(n,lambda f=f:members(f,{'x':{'bytes':1,'sha256':digest(b'x')}}))
# Tiny, wholly synthetic ancestor packets test the new reference resolvers.
def J(x):return json.dumps(x,sort_keys=True).encode()
mod='Test.Module';src=b'import Init\n';log=b'finished\n'
row={'source_sha256':digest(src),'object_sha256':'1'*64,'log_sha256':digest(log),'dependencies':{}}
base={'execution/completed.json':J({mod:row}),'execution/sources/Test/Module.lean':src,'execution/logs/Test.Module.log':log}
def inherited(parent):
 return {'execution/completed.json':J({mod:row}),'execution/sources/Test/Module.lean':src,'execution/reused-log-origins.json':J({mod:{'basis_member':'execution/logs/Test.Module.log','sha256':digest(log)}}),'review/basis-reference.json':J({'synthetic':parent})}
p1=inherited('base');p2=inherited('p1')
packets={'base':base,'p1':p1}
original_reference=E.reference
E.reference=lambda repo,ref:packets[ref['synthetic']]
try:
 assert E.primary_material(base,mod,Path('.'))==(src,log);rs.append(['primary_fresh_material','PASS'])
 assert E.primary_material(p2,mod,Path('.'))==(src,log);rs.append(['primary_two_pinned_ancestors','PASS'])
 def primary_bad(name,field,value):
  bad=deepcopy(p2);r=dict(row);r[field]=value;bad['execution/completed.json']=J({mod:r})
  reject(name,lambda:E.primary_material(bad,mod,Path('.')))
 primary_bad('primary_wrong_object','object_sha256','2'*64)
 primary_bad('primary_wrong_dependencies','dependencies',{'Unknown':'3'*64})
 primary_bad('primary_wrong_source','source_sha256','4'*64)
 bad=deepcopy(p2);bad['execution/reused-log-origins.json']=J({mod:{'basis_member':'wrong.log','sha256':digest(log)}})
 reject('primary_wrong_log_member',lambda:E.primary_material(bad,mod,Path('.')))
 bad=deepcopy(base);bad['execution/logs/Test.Module.log']=b'changed'
 reject('primary_wrong_raw_log',lambda:E.primary_material(bad,mod,Path('.')))
 cycle=inherited('cycle');packets['cycle']=cycle
 reject('primary_cycle_depth',lambda:E.primary_material(cycle,mod,Path('.')))
 folder='execution/attempts/001-Test.Module'
 legacy={'execution/completed.json':J({mod:row}),folder+'/record.json':J({'module':mod,**row}),folder+'/Module.lean':src,folder+'/compiler.log':log}
 # Actual records include the module name in both ledger and attempt.
 lrow={'module':mod,**row};legacy['execution/completed.json']=J({mod:lrow})
 l1={'execution/completed.json':J({mod:lrow}),'publication/references.json':J({'phase5_legacy':{'synthetic':'legacy'}})}
 l2={'execution/completed.json':J({mod:lrow}),'publication/references.json':J({'phase7_legacy':{'synthetic':'l1'}})}
 packets.update(legacy=legacy,l1=l1)
 assert E.legacy_material(legacy,mod,Path('.'))==(src,log);rs.append(['legacy_original_attempt','PASS'])
 assert E.legacy_material(l2,mod,Path('.'))==(src,log);rs.append(['legacy_two_pinned_ancestors','PASS'])
 bad=deepcopy(l2);bad['execution/completed.json']=J({mod:{**lrow,'dependencies':{'Bad':'5'*64}}})
 reject('legacy_wrong_dependencies',lambda:E.legacy_material(bad,mod,Path('.')))
 bad=deepcopy(legacy);bad[folder+'/Module.lean']=b'changed'
 reject('legacy_wrong_source',lambda:E.legacy_material(bad,mod,Path('.')))
 bad=deepcopy(legacy);bad['execution/attempts/002-Test.Module/record.json']=J(lrow)
 reject('legacy_duplicate_attempt',lambda:E.legacy_material(bad,mod,Path('.')))
 bad=deepcopy(legacy);bad[folder+'/record.json']=J({**lrow,'object_sha256':'6'*64})
 reject('legacy_attempt_ledger_mismatch',lambda:E.legacy_material(bad,mod,Path('.')))
 cycle={'execution/completed.json':J({mod:lrow}),'publication/references.json':J({'phase7_legacy':{'synthetic':'lcycle'}})};packets['lcycle']=cycle
 reject('legacy_cycle_depth',lambda:E.legacy_material(cycle,mod,Path('.')))
finally:E.reference=original_reference
# Cached decompression still rechecks current pinned container bytes on every read.
with tempfile.TemporaryDirectory(prefix='legacy-reference-control-')as d:
 d=Path(d);p=d/'packet';p.mkdir();a=p/'execution.tar.gz'
 data={'source.txt':b'synthetic'}
 with tarfile.open(a,'w:gz')as t:
  ti=tarfile.TarInfo('source.txt');ti.size=9;t.addfile(ti,io.BytesIO(b'synthetic'))
 save(p/'index.json',manifest(data))
 ref={'repository_relative_directory':'packet','files':{n:{'sha256':E.sha(p/n),'bytes':(p/n).stat().st_size}for n in ['execution.tar.gz','index.json']}}
 assert E.reference(d,ref)==data and E.reference(d,ref)==data;rs.append(['reference_cache_pins_every_call','PASS'])
 with a.open('ab')as f:f.write(b'changed')
 reject('cached_reference_changed_archive',lambda:E.reference(d,ref))
E._PACKETS.clear()

for p in HERE.glob('*.py'):compile(p.read_text(),str(p),'exec')
save(HERE/'controls-result.json',{'status':'PASS_PROSPECTIVE_METADATA_CONTROLS','positive':sum(v=='PASS'for _,v in rs),'negative':sum(v=='REJECTED'for _,v in rs),'controls':rs,'actual_capture':False,'compiler_invocations':[]})
print(json.dumps({'positive':sum(v=='PASS'for _,v in rs),'negative':sum(v=='REJECTED'for _,v in rs)}))
