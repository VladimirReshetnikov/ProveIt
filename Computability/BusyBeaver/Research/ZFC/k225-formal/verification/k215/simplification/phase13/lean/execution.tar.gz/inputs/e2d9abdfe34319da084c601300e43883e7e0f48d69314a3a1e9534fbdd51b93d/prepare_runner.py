"""Prepare only a serial source-closed phase13 successor; never invokes a compiler."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil
S=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs');F=R/'Computability/BusyBeaver/Research/ZFC/k225-formal'
B=Path('/tmp/k215-phase12-import-check/primary-run1');C=Path('/tmp/k215-phase12-import-check/compatibility-run1');P=Path('/tmp/k215-phase13-upstream-shared')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
oldpath=Path('/tmp/k215-phase12-import-check/build.py');assert sha(oldpath)=='4242f1dab9adcf9a5f1b89ef87d5a65568e1ef302627fb89183e2a94dd99dcb5'
copy(oldpath,S/'history/build-phase12.py')
priorpath=Path('/tmp/k215-phase12-import-check/producer-boundary.json');prior=read(priorpath)
assert sha(priorpath)=='f7d0a50ce268bafb9050d90d6d8d72c753eb5d99ba870ab07aeba1407bd54026'
assert sha(P/'freeze.json')=='1626c437e96a1958f5264e2ca0bf2803c877cbdcbe37d9c789b6c168c50290d8'
for row in read(P/'freeze.json')['files']:assert sha(P/row['path'])==row['sha256']
adopt=Path('/tmp/k215-phase12-import-proposal/adoption.json');assert sha(adopt)=='bcecc9837f0bd2a6da46454b1401e3a5f15ace38e4b53c1fbd3fefb462dc057d'
current_extra={F/'generate_l2k222.py':'c720d5bf58d4c9119bfb6a6d206451e18c7287caf0518c8a666b38cc0b2e74f6',F/'rho8cd/derivation_core.txt':'f0a2e60d3574615aefa8ce987e783b69a89dd95516dc7238caa569b4a938f116',F/'verification/k215/simplification/phase10/upstream-merge/source-review/inputs/DominatedImplication.upstream.lean':'e91f5cf8e6583ba73221362bc21438b70897a8808329886dc615c166bb16edd7',F/'verification/k215/simplification/phase12/upstream-merge/inputs/raw58-DominatedImplication.lean':'4aefdfbdfc41c11f2dc0b236c526098bf76c55692767f554e3776b1573135005'}
extras={str(priorpath):sha(priorpath),str(adopt):sha(adopt),str(P/'freeze.json'):sha(P/'freeze.json')};snapshots=[]
for path,pin in current_extra.items():
 assert sha(path)==pin;dst=S/'inputs/current-before'/path.relative_to(R);copy(path,dst);extras[str(path)]=pin;extras[str(dst)]=pin;snapshots.append({'canonical':str(path),'sha256':pin,'snapshot':str(dst),'state':'current_before_any_phase13_adoption'})
# Candidate producer/data are pinned, inert inputs. None replaces the current source before checks.
candidates=[]
for name in ['production/generate_dominated_implication_lean.py','production/rho8cd/derivation_core.txt','production/verification/k215/simplification/phase12/upstream-merge/inputs/raw58-DominatedImplication.lean','production/dominated_implication_templates/adapter.txt']:
 p=P/name;extras[str(p)]=sha(p);candidates.append({'path':str(p),'sha256':sha(p),'state':'proposed_data_only_not_adopted'})
boundary={**prior,'phase12_primary_result_sha256':sha(B/'result.json'),'phase12_compatibility_result_sha256':sha(C/'result.json'),'phase12_adoption':{'path':str(adopt),'sha256':sha(adopt)},'phase12_boundary':{'path':str(priorpath),'sha256':sha(priorpath)},'additional_inputs':extras,'current_before_snapshots':snapshots,'proposed_producer_inputs':candidates,'scope':'Current accepted producer31fdd and derivationf0a2 remain required. Candidate producerebcbb/data414 are pinned inert inputs only; source pair is compiled from its frozen map. Current L2producerc720 is distinct from historical phase12 raw-before0587. Phase8/10 snapshots and both retired-template absences retain their exact boundaries.'}
save(S/'producer-boundary.json',boundary)
s=oldpath.read_text()
s=s.replace("B=Path('/tmp/k215-generic-cd58-check/inline-full-run1')","B=Path('/tmp/k215-phase12-import-check/primary-run1');BC=Path('/tmp/k215-phase12-import-check/compatibility-run1')")
s=s.replace("assert sha(B/'result.json')=='53a7307848e6445a46b13e39b4283e335f5793660ca23f46659dc26c8f8e794d'","assert sha(B/'result.json')=='a5fce6a787751ba527cc368ff97b770d28eeb517149d5e3f99b17dd7c738df5e'\nassert sha(BC/'result.json')=='7223a5fa4f5fe56e331d2dc27efc7b2d8e50f473d081eed9e145278728e68f9c'")
start=s.index("baseline=read(B/'result.json')");end=s.index("ancestry=read(A/'result.json')")
replacement="""baseline=read(B/'result.json');compatibility_baseline=read(BC/'result.json')
assert baseline['status']==compatibility_baseline['status']=='PASS'
plans=read(args.map)['modules'];overrides={r['module']:r for r in plans};assert len(overrides)==len(plans)
inputs={str(p):sha(p)for p in [H,C,Path(__file__),args.map]};basis={};basis_kind={};old={};old_entries={}
for directory,kind,count in [(BC,'phase12_compatibility_checked',69),(B,'phase12_primary_checked',184)]:
 result=read(directory/'result.json');inventory=read(directory/'inventory.json');completed=read(directory/'completed.json')
 assert sha(directory/'completed.json')==result['completed_sha256']and sha(directory/'inventory.json')==result['inventory_sha256']
 assert len(completed)==len(inventory['modules'])==count and len({r['module']for r in inventory['modules']})==count
 for name in ['result.json','inventory.json','completed.json','toolchain.json']:inputs[str(directory/name)]=sha(directory/name)
 assert read(directory/'toolchain.json')==read(B/'toolchain.json')
 entries={r['module']:r for r in inventory['modules']}
 for m,rec in completed.items():
  assert rec['status']=='PASS'and rec.get('exit_code',0)==0 and not rec.get('timed_out',False)
  entry=entries[m];assert rec['source_sha256']==entry['source_sha256'];assert rec['dependencies']=={d:completed[d]['object_sha256']for d in entry['imports']if d!='Init'}
  obj=directory/'objects'/(m.replace('.','/')+'.olean');assert sha(obj)==rec['object_sha256']and sha(rec['log'])==rec['log_sha256']
  if m in old:assert entry['source_sha256']==old_entries[m]['source_sha256']and entry['imports']==old_entries[m]['imports']and rec['object_sha256']==old[m]['object_sha256']
  old[m]=rec;old_entries[m]=entry;basis[m]=(rec,obj);basis_kind[m]=kind
  inputs[str(obj)]=rec['object_sha256'];inputs[rec['log']]=rec['log_sha256']
assert len(old)==201
assert all(rec['dependencies']=={d:old[d]['object_sha256']for d in old_entries[m]['imports']if d!='Init'}for m,rec in old.items())
"""
s=s[:start]+replacement+s[end:]
s=s.replace("'f7d0a50ce268bafb9050d90d6d8d72c753eb5d99ba870ab07aeba1407bd54026'",repr(sha(S/'producer-boundary.json')))
s=s.replace("producer_boundary['phase8_result_sha256']==sha(A/'result.json') and producer_boundary['phase11_result_sha256']==sha(B/'result.json')","producer_boundary['phase8_result_sha256']==sha(A/'result.json') and producer_boundary['phase12_primary_result_sha256']==sha(B/'result.json') and producer_boundary['phase12_compatibility_result_sha256']==sha(BC/'result.json')")
s=s.replace("producer_boundary['phase10_result_sha256']==baseline['basis_result_sha256']","producer_boundary['phase11_result_sha256']==baseline['basis_result_sha256']==compatibility_baseline['basis_result_sha256']")
s=s.replace("['phase11_adoption','previous_boundary']","['phase11_adoption','previous_boundary','phase12_adoption','phase12_boundary']")
s=s.replace("{'phase11_checked','secondary_checked','candidate_fresh'}","{'phase12_primary_checked','phase12_compatibility_checked','secondary_checked','candidate_fresh'}")
s=s.replace("done[m]['origin']!='phase11_checked' or m not in forced","done[m]['origin']not in {'phase12_primary_checked','phase12_compatibility_checked'}or m not in forced")
s=s.replace("choices.append(('phase11_checked',basis[m]))","choices.append((basis_kind[m],basis[m]))")
s=s.replace("'phase11_reused_modules':[m for m,r in done.items()if r['origin']=='phase11_checked']","'phase12_primary_reused_modules':[m for m,r in done.items()if r['origin']=='phase12_primary_checked'],'phase12_compatibility_reused_modules':[m for m,r in done.items()if r['origin']=='phase12_compatibility_checked']")
s=s.replace("'basis_result_sha256':sha(B/'result.json')","'basis_result_sha256':sha(B/'result.json'),'compatibility_basis_result_sha256':sha(BC/'result.json')")
assert 'phase11_checked'not in s and 'original['not in s
ast.parse(s);(S/'build.py').write_text(s)
(S/'driver.diff').write_text(''.join(difflib.unified_diff(oldpath.read_text().splitlines(True),s.splitlines(True),fromfile='phase12/build.py',tofile='phase13/build.py')))
print(json.dumps({'status':'DRAFT_DRIVER_NOT_EXECUTED','build_sha256':sha(S/'build.py'),'boundary_sha256':sha(S/'producer-boundary.json'),'producer_freeze_sha256':sha(P/'freeze.json'),'scope':'No compiler or producer invocation. Existing source-transitive reuse, isolated secondary gate, serial lock/group cleanup and exact old endpoint audits retained.'},indent=2))
