# Shared forward-simulation cases

`source/BusyBeaver/ZFC/RMEquiv.lean` is a scratch replacement for the current
`RMEquiv.lean`. Only the proof body of `fwd` changes. Its public statement,
all other declarations, and all executable definitions remain byte-identical.
`comparison.json` checks that exact boundary, rather than merely comparing
selected theorem names.

The proof now uses one child-entry argument for the four car exits. The four
cdr exits share the normal-car run and the existing `reaches_pre` composition
lemma. The continue/restart case applies that lemma twice instead of rebuilding
the sum of run lengths. No new mathematical API is necessary. The proof block
shrinks from 83 to 61 lines; the file shrinks from 707 to 685 lines.

The full candidate kernel-passed in `run1`. The final `run2` additionally compiled
unchanged `RMBisim` against it and three explicit typed clients: `fwd`, the
structured/path halting equivalence, and the checked bisimulation halting
equivalence. All passed without warnings (3.421, 2.319, and 0.315 seconds).
The three axiom reports contain only `propext`, `Classical.choice`, and
`Quot.sound`; `Classical.choice` appears only in the halting-equivalence client.
These timings are observations, not a performance comparison.

The isolated checks used immutable phase4 dependencies from
`/tmp/k215-proof-phase4/lean-run1`, with read-only object symlinks. Each target
symlink was removed before Lean wrote its fresh object. Exact source, imported
object, compiler, and raw-log hashes are recorded, and all basis inputs were
rehashed afterward. Commands used the common compiler lock, one worker,
120-second caps and 12 GiB limits. No canonical file or old evidence was edited;
this is not a fresh full-closure build.

The remaining `RMBisim` simulation already shares its principal prefix argument
through the recently added `hn_after`/`seg_hn` composition. This candidate keeps
that file unchanged rather than adding another abstraction for small local
case splits.

Reproduce into a new scratch output name with:

```sh
python3 -B /tmp/k215-rmequiv-fwd/check.py NEW_OUTPUT RMEquiv RMBisim
```

`prepare.py` records the transformation, `source.diff` is the complete patch,
`Audit.lean` contains the clients, and `run2/result.json` is the actual final
bounded check receipt. The producer must not be rerun if the canonical input
has changed without first preserving the old packet.
