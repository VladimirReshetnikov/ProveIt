from pathlib import Path
import hashlib,json,re
p=Path('/tmp/k215-domrho8-sharing');out=Path('/tmp/k215-domrho8-sharing-peer');sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();old=(p/'baseline/DomRho8.lean').read_text();new=(p/'Shared.lean').read_text()
norm=lambda s:' '.join(s.split())
def decls(s):return {m[0]:(norm(m[1]),m[2]) for m in re.findall(r'private theorem ((?:b|cd)\d+)\b(.*?)\s*:=\s*(.*?)(?=\n(?:private theorem|end|theorem|section)|\Z)',s,re.S)}
a=decls(old);b=decls(new)
assert all(k in a and a[k][0]==v[0] for k,v in b.items())
assert new[new.index('theorem composition '):]==old[old.index('theorem composition '):]
assert new[new.index('namespace '):new.index('private theorem b0 ')]==old[old.index('namespace '):old.index('private theorem b0 ')]
assert a['b32'][0]==a['b19'][0] and a['b34'][0]==a['b20'][0]
assert set(k for k in a if k.startswith('b'))-set(b)=={'b11','b32','b34'}
refs={k:re.findall(r'\b((?:b|cd)\d+)\b',v[1]) for k,v in b.items()}
for k,ds in refs.items():
 for d in ds:
  assert d in b,(k,d)
  if d.startswith('cd'):assert k.startswith('cd') and int(d[2:])<int(k[2:])
  elif k.startswith('b'):assert int(d[1:])<int(k[1:])
base=next(v for k,v in b.items() if k=='b17')
counts={kind:sum(k.startswith(kind) for k in b) for kind in ['b','cd']}
assert counts=={'b':58,'cd':59}
guards=[k for k,v in b.items() if k.startswith('cd') and 'hb0' in v[0]];assert len(guards)==8
run=json.loads((p/'run1/result.json').read_text());log=(p/'run1/compiler.log').read_text();assert run['status']=='PASS' and not run['timed_out'] and run['exit_code']==0 and run['warnings']==0
assert sha(Path(run['source_snapshot']))==run['source_sha256'];assert sha(p/'run1/compiler.log')==run['log_sha256'];assert sha(p/'run1/SharedWithAudit.olean')==run['object_sha256']
assert (p/'run1/SharedWithAudit.lean').read_bytes()==(p/'Shared.lean').read_bytes()+(p/'APIAudit.lean.inc').read_bytes()
reports=re.findall(r'depends on axioms: \[([^]]*)\]',log);assert len(reports)==4 and all(set(x.strip() for x in r.split(','))=={'propext','Quot.sound'} for r in reports)
r={'status':'PASS_BOUNDED_SOURCE_AND_SAVED_RECORD_REVIEW','source':str(p/'Shared.lean'),'source_sha256':sha(p/'Shared.lean'),'baseline_sha256':sha(p/'baseline/DomRho8.lean'),'producer_sha256':sha(p/'generate_shared.py'),'prepare_sha256':sha(p/'prepare.py'),'retained_counts':counts,'retained_headers_unchanged':len(b),'explicit_guards':guards,'public_tail_exact':True,'DomImp_and_arithmetic_head_exact':True,'kernel_record_sha256':sha(p/'run1/result.json'),'kernel_seconds':run['seconds'],'typed_clients':5,'axiom_reports':4,'axioms':['propext','Quot.sound'],'scope':['Read the complete source/producer structural delta against the previously independently reviewed guarded35KB proof.','All retained lemma headers, including numeric guards, match exactly modulo whitespace. Original Source149 names remain stable.','Strict bootstrap equality permits reusing19 for32 and20 for34; truth is h.truth. Cross-layer equality reuses proved unconditional bootstrap conclusions, then removes unreachable templates.','All remaining proof references point to earlier declarations; the generic proof relation, deduction induction, and forall-natural rho8 endpoint are byte-identical.','Observed original successful source/API actual, without rerunning author producer, compiler, or proof search. This is not a new full provider or downstream endpoint review.'],'prior_full_source_peer':'/tmp/k215-domrho8-guarded-peer/review.json'}
(out/'review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print('receipt_sha256',sha(out/'review.json'))
