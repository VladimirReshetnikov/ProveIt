from pathlib import Path
import difflib
import re

P = Path(__file__).resolve().parent
original = (P / 'upstream/BusyBeaver/ZFC/EnumPerm.lean').read_text()
source = original


def replace_decl(name, replacement):
    global source
    start = re.search(r'(?m)^theorem ' + re.escape(name) + r'(?=[:\s])', source).start()
    end = source.index('\n\n', source.index('\n', start))
    source = source[:start] + replacement.rstrip() + source[end:]


start = source.index('theorem run_add :')
end = source.index('\ntheorem step_eq', start)
run_add = """theorem run_add : ∀ (n m : Nat) (s s1 : St), run n s = some s1 → run (n + m) s = run m s1
  | 0, m, s, s1, h => by cases h; rfl
  | n + 1, m, s, s1, h => by
      cases hs : enumStep s <;> simp_all only [run, Nat.succ_add]
      exact run_add n m _ _ h"""
source = source[:start] + source[end:]
point = source.index('/-- If a candidate\'s command list halts')
helpers = run_add + '''

/-- A finite prefix transports any property of the state reached afterwards. -/
private theorem reached_before {s s1 : St} {n : Nat} (hr : run n s = some s1)
    {Q : St → Prop} (hq : ∃ m s', run m s1 = some s' ∧ Q s') :
    ∃ m s', run m s = some s' ∧ Q s' := by
  obtain ⟨m, s', hm, hq⟩ := hq
  exact ⟨n + m, s', by rw [run_add n m s s1 hr]; exact hm, hq⟩

private theorem progress_before {s s1 : St} {n : Nat} (hr : run n s = some s1)
    {Q : St → Prop} :
    ((∃ m s', run m s1 = some s' ∧ Q s') ∨ HaltsFrom s1) →
      (∃ m s', run m s = some s' ∧ Q s') ∨ HaltsFrom s :=
  Or.imp (reached_before hr) (reached_before hr)

'''
source = source[:point] + helpers + source[point:]

replace_decl('exec_list', '''theorem exec_list (cs : List Cmd) : ∀ (c : Cmd) (s : St), (fetch s).1 = encL c cs →
    cexec (c :: cs) (toW s) = none → HaltsFrom s := by
  intro c s hf hx
  cases hw : cstep c (toW s) with
  | none => exact ⟨0, s, rfl, by simp [enumStep, hf, encL, execAt_pack, hw]⟩
  | some w =>
    rw [cexec_cons_some hw] at hx
    cases cs with
    | nil => cases hx
    | cons c' cs' =>
      let s1 : St := ⟨encL c' cs' + 1, (fetch s).2, w.tw, w.ws, w.d, w.h⟩
      have hstep : enumStep s = some s1 := by simp [enumStep, hf, encL, execAt_pack, hw, s1]
      exact reached_before (n := 1) (by simp only [run, hstep])
        (exec_list cs' c' s1 (by simp [fetch, s1]) hx)
termination_by cs.length''')

replace_decl('drain', '''theorem drain : ∀ (m : Nat) (s : St), s.pl ≤ m →
    (∃ n s', run n s = some s' ∧ s'.pl = 0 ∧ s'.np = s.np) ∨ HaltsFrom s
  | m, s, hm => by
      by_cases hpl : s.pl = 0
      · exact Or.inl ⟨0, s, rfl, hpl, rfl⟩
      · match hs : enumStep s with
        | none => exact Or.inr ⟨0, s, rfl, hs⟩
        | some s1 =>
          obtain ⟨h1, h2⟩ := step_eq hs
          have := decode_le (fetch s).1
          simp only [fetch, hpl, if_false] at h1 h2 this
          cases m with
          | zero => omega
          | succ m =>
            apply progress_before (n := 1) (by simp only [run, hs])
            simpa only [h2] using drain m s1 (by omega)''')

replace_decl('reach', '''theorem reach (sd : St) (hpl : sd.pl = 0) : ∀ k : Nat,
    (∃ n s, run n sd = some s ∧ s.pl = 0 ∧ s.np = sd.np + k) ∨ HaltsFrom sd
  | 0 => Or.inl ⟨0, sd, rfl, hpl, rfl⟩
  | k + 1 => by
      rcases reach sd hpl k with ⟨n, s, hr, hpl', hnp⟩ | hh
      · apply progress_before hr
        match hs : enumStep s with
        | none => exact Or.inr ⟨0, s, rfl, hs⟩
        | some s1 =>
          have hnp1 : s1.np = sd.np + (k + 1) := by
            rw [(step_eq hs).2]; simp only [fetch, hpl', if_true]; omega
          apply progress_before (n := 1) (by simp only [run, hs])
          simpa only [hnp1] using drain s1.pl s1 (Nat.le_refl _)
      · exact Or.inr hh''')

source = source.replace('''    obtain ⟨k, s', hr', hs'⟩ := exec_list cs (.ax 0 1 sd.np) s hf (program_none sd.np p hp _)
    exact ⟨n + k, s', by rw [run_add n k sd s hr]; exact hr', hs'⟩''', '''    exact reached_before hr (exec_list cs (.ax 0 1 sd.np) s hf (program_none sd.np p hp _))''')


target = P / 'preferred/BusyBeaver/ZFC/EnumPerm.lean'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(source)
(P / 'preferred.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True), fromfile='upstream/EnumPerm.lean', tofile='preferred/EnumPerm.lean')))
print({'upstream_lines': len(original.splitlines()), 'preferred_lines': len(source.splitlines())})
