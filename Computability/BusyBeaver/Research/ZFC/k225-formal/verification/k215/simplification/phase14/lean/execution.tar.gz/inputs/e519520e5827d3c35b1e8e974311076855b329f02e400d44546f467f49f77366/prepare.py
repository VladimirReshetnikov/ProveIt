"""Prepare the phase14 successor sources. No compiler, collector, or producer."""
from pathlib import Path
import ast,hashlib,json,difflib
S=Path(__file__).resolve().parent;OLD=S/'history/phase13';R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(x):return json.dumps(x,indent=2)+'\n'
def sub(s,a,b):
 assert s.count(a)==1,(a[:150],s.count(a))
 return s.replace(a,b)
def save(n,s):
 if n.endswith('.py'):ast.parse(s)
 (S/n).write_text(s)
 if (OLD/n).exists():(S/(n+'.diff')).write_text(''.join(difflib.unified_diff((OLD/n).read_text().splitlines(True),s.splitlines(True),fromfile='phase13/'+n,tofile='phase14/'+n)))
ref=json.loads((OLD/'basis-reference.json').read_text());ref['repository_relative_directory']=ref['repository_relative_directory'].replace('/phase12/','/phase13/')
for n in ref['files']:
 p=R/ref['repository_relative_directory']/n;ref['files'][n]={'sha256':sha(p),'bytes':p.stat().st_size}
(S/'basis-reference.json').write_text(dump(ref))
s=(OLD/'basis.py').read_text().replace('phase12','phase13').replace('PHASE12','PHASE13')
s=sub(s,"PIN = '66112698049384540650932c48b6780b8fe5be46a6d5f20ba375d48b8f569b67'","PIN = "+repr(sha(S/'basis-reference.json')));save('basis.py',s)
s=(OLD/'packet.py').read_text()
s=s.replace('phase13','PHASE_CURRENT').replace('phase12','phase13').replace('PHASE_CURRENT','phase14').replace('PHASE13','PHASE_CURRENT').replace('PHASE12','PHASE13').replace('PHASE_CURRENT','PHASE14')
s=s.replace("PREP = '/tmp/k215-phase14-upstream-check'","PREP = '/tmp/k215-phase14-check'")
s=s.replace("EXEC = '/tmp/k215-phase14-upstream-execution'","EXEC = '/tmp/k215-phase14-execution'")
s=s.replace("BASE = '/tmp/k215-phase13-import-check/primary-run1'","BASE = '/tmp/k215-phase13-upstream-check/primary-run1'").replace("BASE_COMP = '/tmp/k215-phase13-import-check/compatibility-run1'","BASE_COMP = '/tmp/k215-phase13-upstream-check/compatibility-run1'")
for name in ['DRIVER','FREEZE','BOUNDARY']:
 import re
 s=re.sub(r'^'+name+r" = '[^']+'$",name+" = None  # Filled only from the final frozen runner, before publication peer.",s,flags=re.M)
s=sub(s,"BASE_RESULTS = ['a5fce6a787751ba527cc368ff97b770d28eeb517149d5e3f99b17dd7c738df5e', '7223a5fa4f5fe56e331d2dc27efc7b2d8e50f473d081eed9e145278728e68f9c']","BASE_RESULTS = ['00a44b3ce690bfcd397f53275c2dcec69d25423de8e029086b0aefe020fb397e', 'bd9e50bce1c8a463719d83c201f402dad3edd89c0621ae827082b75638a3c74f']")
s=sub(s,"API = ['GenericShared13Api', 'NumericCD52Api', 'LukasShared13Api']","OLD_API = ['GenericShared13Api', 'NumericCD52Api', 'LukasShared13Api']\nNEW_API = ['DerivedRows14Api', 'ThmKDerived14Api', 'KEindDerived14Api', 'ProfileTC14Api']\nAPI = OLD_API + NEW_API")
a=s.index('ADOPTIONS = {');b=s.index('\nBINARY =',a)
oldad=s[a:b].replace('ADOPTIONS =','PRIOR_ADOPTIONS =')
sources=json.loads(Path('/tmp/k215-phase14-check/sources.json').read_text())
ad={r['module'].split('.')[-1]:r['source_sha256'] for r in sources}
s=s[:a]+oldad+'\nADOPTIONS = {LEAN_DIR + n + ".lean": p for n,p in '+repr(ad)+'.items()}\nRETIRED = {\n LEAN_DIR+"KProfileTC.lean": "0d344c2298abf0e6d998179b61baeab9b0226cc49c365552ef94de258417c173",\n FORMAL+"generate_profile_tc.py": "bf307e9a953a24f7303786e30f23c53f34b81519e794748d118e4403692b9822"}\n'+s[b:]
s=sub(s,"[(BASE_COMP, 69, 'phase13_compatibility_checked', BASE_RESULTS[1]), (BASE, 184, 'phase13_primary_checked', BASE_RESULTS[0])]","[(BASE_COMP, 70, 'phase13_compatibility_checked', BASE_RESULTS[1]), (BASE, 187, 'phase13_primary_checked', BASE_RESULTS[0])]")
s=s.replace('assert len(old) == len(oldrows) == 201','assert len(old) == len(oldrows) == 204')
s=sub(s,"allplans = {r['module']: r for r in read(PREP + '/candidate-map.json')['modules']}\n assert len(allplans) == 9", """allplans = {}
 for filename in ['primary-map.json', 'compatibility-template.json']:
  for r in read(PREP+'/'+filename)['modules']:
   if r['module'] in allplans: assert allplans[r['module']] == r
   allplans[r['module']] = r
 assert len(allplans) == 19
 assert set(cfg['new_api_profiles']) == set(NEW_API)""")
s=sub(s,"assert [len(v) for v in kinds.values()] == [36, 151, 0, 0] and forced == kinds['candidate_fresh']\n   assert changed == {P+'DominatedImplication', P+'Lukasiewicz'} | set(API)\n   assert set(entries) == {r['module'] for r in read(BASE + '/inventory.json')['modules']} | set(API)","""assert [len(v) for v in kinds.values()] == [66, 124, 0, 0] and forced == kinds['candidate_fresh']
   assert changed == {P+PurePosixPath(p).stem for p in ADOPTIONS} | set(NEW_API)
   assert set(entries) == ({r['module'] for r in read(BASE + '/inventory.json')['modules']} - {P+'KProfileTC'}) | set(NEW_API)""")
s=sub(s,"assert kinds['phase13_compatibility_checked'] == {P+'Dag254'} and len(forced) == 23\n   assert changed == {P+'DominatedImplication', P+'Lukasiewicz'}\n   assert set(entries) == {r['module'] for r in read(BASE_COMP + '/inventory.json')['modules']} | {P+'DominatedImplication'}","""assert kinds['phase13_compatibility_checked'] == {P+'Dag254'} and len(forced) == 42
   assert changed == {P+n for n in ['ProfileComposition','CompositionModel','TarskiDerived','TarskiLeibniz']}
   assert set(entries) == {r['module'] for r in read(BASE_COMP + '/inventory.json')['modules']}""")
s=sub(s,"assert r['before_sha256'] == oldrows.get(m, {}).get('source_sha256')","assert r['before_sha256'] == oldrows.get(m, {}).get('source_sha256')") if False else s
s=sub(s,"if 'reports' in r: named_reports(log, r['reports'], r.get('report_axioms'))","""if 'reports' in r:
     named_reports(log, r['reports'], r.get('report_axioms'))
     if m in NEW_API: assert profiles(found) == [(name,set(ax)) for name,ax in cfg['new_api_profiles'][m]]
     if m in OLD_API + CLIENTS:
      assert row['source_sha256'] == oldrows[m]['source_sha256']
      assert profiles(found) == profiles(reports(at(old[m]['log'])))""")
s=sub(s,"assert before['absent_inputs'] == sorted(r['canonical'] for r in boundary['files'] if r['current_state'] == 'absent')","""assert before['absent_inputs'] == sorted(r['canonical'] for r in boundary['files'] if r['current_state'] == 'absent')
  assert result['proposed_retirements'] == boundary['proposed_retirements']
  assert result['retired_modules_absent_from_candidate'] == [P+'KProfileTC'] and P+'KProfileTC' not in entries""")
# Outer metadata is finalized only after the actual wrapper is frozen.
a=s.index("  label = PurePosixPath(root).name; outer =")
b=s.index("  binary.update",a)
s=s[:a]+"  check_outer(root, maps[0], cfg, read, at, freeze)\n"+s[b:]
s=sub(s,"run_check(MAIN, TARGETS, 187)","run_check(MAIN, TARGETS, 190)")
s=sub(s,"assert len(project) == 199 and project == set(oldrows) - set(CLIENTS)","assert len(project) == 198 and project == set(oldrows) - set(OLD_API + CLIENTS) - {P+'KProfileTC'}")
s=sub(s,"assert len(endpoint) == 179 and len(prefix) == 5 and len(set(entries)-set(API)) == 184","assert len(endpoint) == 178 and len(prefix) == 5 and len(set(entries)-set(API)) == 183")
s=sub(s,"assert sum(len(mprofiles[m]) for m in API) == 20","assert sum(len(mprofiles[m]) for m in OLD_API) == 20 and sum(len(mprofiles[m]) for m in NEW_API) == 14")
s=sub(s,"['producer_before_original', 'phase11_adoption', 'previous_boundary', 'phase13_adoption', 'phase13_boundary']","['producer_before_original', 'phase11_adoption', 'previous_boundary', 'phase12_adoption', 'phase12_boundary', 'phase13_adoption', 'phase13_boundary']")
a=s.index(" adopted = cfg['adoption']['files']");b=s.index(" controls =",a)
s=s[:a]+""" # The accepted phase13 five files are unchanged; the two new retirements
 # were present compilation inputs and are saved through explicit before snapshots.
 assert {str(PurePosixPath(p).relative_to(ROOT)):v for p,v in boundary['accepted_five_files'].items()} == PRIOR_ADOPTIONS
 for p,pin in boundary['accepted_five_files'].items():
  assert digest(at(p)) == pin
  if current_repo is not None: assert sha(Path(current_repo)/PurePosixPath(p).relative_to(ROOT)) == pin
 retired = boundary['proposed_retirements']
 assert len(retired) == 2 and {str(PurePosixPath(r['canonical']).relative_to(ROOT)):r['before_sha256'] for r in retired} == RETIRED
 for r in retired:
  assert r['current_state'] == 'present_before_candidate_check' and r['proposed_state'] == 'absent_only_after_accepted_adoption'
  assert digest(at(r['canonical'])) == digest(at(r['before_snapshot'])) == r['before_sha256']
  if current_repo is not None: absent(Path(current_repo)/PurePosixPath(r['canonical']).relative_to(ROOT))
 adopted = cfg['adoption']['files']; assert len(adopted) == 9
 raw_adoption = read(cfg['adoption']['receipt'])
 assert raw_adoption['status'] == 'ADOPTED_EXACT_CHECKED_PHASE14' and raw_adoption['files'] == adopted
 assert raw_adoption['source_writes'] == 7 and raw_adoption['retirements'] == 2
 assert {r['path']:r['after_sha256'] for r in adopted if r['action']=='replace'} == ADOPTIONS
 assert {r['path']:r['before_sha256'] for r in adopted if r['action']=='retire'} == RETIRED
 root_review = read(cfg['root_review'])
 assert root_review['status'] == 'PASS_ROOT_RAW_PHASE14_ACTUAL' and root_review['distinct_project_modules'] == 198
 for key,directory in [('primary',MAIN),('compatibility',COMP)]:
  assert root_review[key]['directory'] == directory and root_review[key]['result_sha256'] == digest(at(directory+'/result.json'))
 expected_sources = {m:(entries|cent)[m]['source_sha256'] for m in project}
 assert {m:r['sha256'] for m,r in root_review['sources'].items()} == expected_sources
 for r in adopted:
  archived = ROOT+'/'+r['before_snapshot']; assert digest(at(archived)) == r['before_sha256']
  if r['action'] == 'replace':
   data = members['adoption/'+r['path']]
   assert digest(data) == r['after_sha256'] and data == at(r['candidate'])
   m = P+PurePosixPath(r['path']).stem
   assert entries[m]['source_sha256'] == r['after_sha256'] and oldrows[m]['source_sha256'] == r['before_sha256']
   if current_repo is not None: assert sha(Path(current_repo)/r['path']) == r['after_sha256']
  else:
   assert r['action'] == 'retire' and r['after_sha256'] is None and r['candidate'] is None
   if current_repo is not None: absent(Path(current_repo)/r['path'])
 assert set(cfg['historical_inputs']) == {ROOT+'/'+p for p in RETIRED}
 for path,r in cfg['historical_inputs'].items():
  target = str(PurePosixPath(path).relative_to(ROOT)); row = next(x for x in adopted if x['path']==target)
  assert r['sha256'] == row['before_sha256'] and r['snapshot'] == ROOT+'/'+row['before_snapshot'] and digest(at(path)) == r['sha256']
"""+s[b:]
s=s.replace("'primary_providers': 187, 'primary_project_modules': 184, 'endpoint_modules': 179","'primary_providers': 190, 'primary_project_modules': 183, 'endpoint_modules': 178")
s=s.replace("'primary_fresh': 36, 'primary_phase13_reuse': 151, 'api_clients': 3, 'api_reports': 20","'primary_fresh': 66, 'primary_phase13_reuse': 124, 'api_clients': 7, 'api_reports': 34, 'old_api_reports': 20, 'new_api_reports': 14")
s=s.replace("'combined_project_modules': 199","'combined_project_modules': 198")
s=s.replace("'adopted_files': ADOPTIONS,","'adopted_files': ADOPTIONS, 'retired_files': RETIRED, 'prior_five_adoptions_unchanged': PRIOR_ADOPTIONS,")
s=s.replace("The three API clients, two endpoint clients, and two compatibility clients are distinct.","The seven API clients, two endpoint clients, and two compatibility clients are distinct.")
# Temporary hard failure keeps an incomplete outer-schema adaptation unexecutable.
s+="\n\ndef check_outer(root, source_map, cfg, read, at, freeze):\n raise AssertionError('Pending actual phase14 outer record schema and pins')\n"
save('packet.py',s)
# Adapt the local saved reader; terminal-only counts are expected gates, not actual claims.
s=(OLD/'review_saved.py').read_text().replace('phase13','PHASE_CURRENT').replace('phase12','phase13').replace('PHASE_CURRENT','phase14').replace('PHASE13','PHASE14')
s=s.replace('packet.MAIN: 187','packet.MAIN: 190').replace("post['combined_project_sources'] == 199","post['combined_project_sources'] == 198")
s=s.replace("post['absence_gates'] == 2","post['absence_gates'] == 4")
s=sub(s,"assert post['historical_inputs'] == config['historical_inputs'] and post['current_adoptions'] == packet.ADOPTIONS","assert post['historical_inputs'] == config['historical_inputs'] and post['current_adoptions'] == packet.ADOPTIONS and post['retirements'] == packet.RETIRED and post['unchanged_prior_adoptions'] == packet.PRIOR_ADOPTIONS")
save('review_saved.py',s)
s=(OLD/'controls.py').read_text().replace('phase13','PHASE_CURRENT').replace('phase12','phase13').replace('PHASE_CURRENT','phase14')
s=s.replace("r.update(storage='phase11')","r.update(storage='phase12')")
save('controls.py',s)
print('Prepared unfinished validator/basis/saved/controls sources; no execution boundary is frozen.')
