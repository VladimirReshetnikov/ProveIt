"""Root read-only post-adoption check. No proof/compiler execution."""
from pathlib import Path
import hashlib,json,re,importlib.util
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');P=Path(__file__).resolve().parent;F=P/'full-run2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
assert sha(F/'result.json')=='e54f4f69ec6721a26a0eba53b801f198ee70227a231d38b3c66782b5ed2a8818'
r=read(F/'result.json');before=read(F/'before.json');done=read(F/'completed.json');rows=read(F/'inventory.json')['modules'];adopt=read(P/'canonical-adoption.json')
assert r['status']=='PASS' and set(done)=={x['module']for x in rows} and len(done)==197
H=R/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py';spec=importlib.util.spec_from_file_location('inventory_helper',H);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
inv=h.inventory(R);assert len(inv['modules'])==192
ledger={};names={x['module']for x in inv['modules']}
for e in rows:
 m=e['module'];rec=done[m];paths=[R/root/(m.replace('.','/')+'.lean')for root in h.ROOTS];paths=[p for p in paths if p.is_file()];assert len(paths)==1
 c=paths[0];assert sha(c)==e['source_sha256']==rec['source_sha256']==sha(F/'workspace'/(m.replace('.','/')+'.lean'));assert sha(F/'objects'/(m.replace('.','/')+'.olean'))==rec['object_sha256'];assert sha(rec['log'])==rec['log_sha256'];assert rec['dependencies']=={d:done[d]['object_sha256']for d in e['imports']if d!='Init'}
 ledger[m]={'source':e['source_sha256'],'object':rec['object_sha256'],'log':rec['log_sha256'],'canonical':str(c)}
for x in adopt['files']:
 assert sha(R/x['destination'])==x['source_sha256'];clean=h.without_comments_strings((R/x['destination']).read_text());assert not re.search(r'\b(?:sorry|admit|axiom|native_decide)\b',clean)
for p,pin in before['inputs'].items():assert sha(p)==pin,p
for a in r['audits']:
 q=F/('audit-'+a['module']);assert sha(q/(a['module']+'.olean'))==a['object_sha256'];assert sha(q/(a['module']+'.lean'))==sha(a['source'])==a['source_sha256'];assert sha(a['log'])==a['log_sha256']
controls=read(P/'controls-run1/result.json');assert controls['status']=='PASS' and controls['selected_project_modules']==18
out={'status':'PASS_ROOT_EXACT_CANONICAL_ADOPTION','canonical_modules':197,'endpoint_closure':192,'additional_prefix_modules':sorted(set(ledger)-names),'adopted_files':11,'new_source_admissions':False,'full_result_sha256':sha(F/'result.json'),'full_inventory_sha256':sha(F/'inventory.json'),'full_completed_sha256':sha(F/'completed.json'),'all_current_objects_sources_logs_and_inputs_rehashed':True,'both_audit_objects_rehashed':True,'controls_result_sha256':sha(P/'controls-run1/result.json'),'reviewer_sha256':sha(__file__),'ledger':ledger,'scope':'Read-only post-adoption source/object/log/input binding check, alongside the independent transitive-source proof audit. No compiler or new kernel replay by this reader.'}
(P/'canonical-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='ledger'},indent=2))
