"""Add the Source175 fast-site adapter on the held normalized/Program scratch candidate."""
from pathlib import Path
import shutil,json,hashlib,difflib
O=Path(__file__).resolve().parent;P=Path('/tmp/k215-normalized-migration');R=Path('/home/codex/.codex/worktrees/ec20/Proofs');W=O/'workspace';F=Path('Computability/BusyBeaver/Research/ZFC/k225-formal');L=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC')
assert not W.exists();shutil.copytree(P/'workspace',W,ignore=shutil.ignore_patterns('__pycache__'))
proto=R/F/'verification/k215/simplification/proposals/k215-simplification-3/runtime/KFastSites215.uncompiled.lean';(O/'original').mkdir();shutil.copyfile(proto,O/'original/KFastSites215.uncompiled.lean')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(proto)=='40e1a0389624e0decda67342a680b7bec422e6434394fb89134ae6238557a859'
s=proto.read_text();a='UNCOMPILED RESEARCH DRAFT. No new evaluator or semantic axiom is introduced.\nInstall as BusyBeaver/ZFC/KFastSites215.lean before trying the accompanying patch.\nThe existing fast215 theorem binds the balanced lookup tree to the literal table.';b='Transfer site checks through the existing all-state equality of the balanced\ntransition lookup and the literal table. No evaluator or machine definition changes.\nAdapted from Source175 (beaabc8e3b), runtime/KFastSites215.uncompiled.lean.\nThe two proof bodies are unchanged from that submitted prototype.';assert a in s;s=s.replace(a,b);(W/L/'KFastSites215.lean').write_text(s)
p=W/F/'generate_sites215_lean.py';s=p.read_text();before=s
s=s.replace('HEAD = ("import BusyBeaver.ZFC.KSource215Program\\nimport BusyBeaver.ZFC.KSim\\nimport BusyBeaver.ZFC.KTable215\\n")','HEAD = ("import BusyBeaver.ZFC.KSource215Program\\nimport BusyBeaver.ZFC.KFastSites215\\n")')
s=s.replace('  decide +kernel\\n', '  exact KFastSites215.allSites_of_fast (by decide +kernel)\\n')
assert s.count('exact KFastSites215.allSites_of_fast')==2
s=s.replace('The tree is cut into subtrees of at most LEAVES leaves; each is a kernel decision','The tree is cut into subtrees of at most LEAVES leaves. Each block uses a kernel\ndecision with the existing balanced table and transfers it through fast215 equality:')
p.write_text(s)
(O/'generator.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='normalized-program/generate_sites215_lean.py',tofile='fast-sites/generate_sites215_lean.py')))
(O/'adapter.diff').write_text(''.join(difflib.unified_diff(proto.read_text().splitlines(True),(W/L/'KFastSites215.lean').read_text().splitlines(True),fromfile='Source175/KFastSites215.uncompiled.lean',tofile='candidate/KFastSites215.lean')))
(O/'preparation.json').write_text(json.dumps({'normalized_program_map_sha256':sha(P/'adoption-map.json'),'prototype_sha256':sha(proto),'adapter_sha256':sha(W/L/'KFastSites215.lean'),'generator_sha256':sha(p),'canonical_mutation':False,'compiler_executed':False},indent=2)+'\n')
print('prepared',W)
