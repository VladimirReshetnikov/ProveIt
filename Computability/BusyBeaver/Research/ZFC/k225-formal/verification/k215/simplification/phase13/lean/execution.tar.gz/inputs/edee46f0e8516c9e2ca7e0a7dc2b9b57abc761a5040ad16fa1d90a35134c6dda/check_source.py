from pathlib import Path,PurePosixPath
import ast,hashlib,json,re,tempfile
S=Path('/tmp/k215-phase13-publication');O=Path(__file__).resolve().parent;R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
f=read(S/'freeze.json');assert sha(S/'freeze.json')=='423f5e7c59fb5e99d12e43deb050b9aad81c5e6ddb662e23dd1e568af7e12c8a'
for n,h in f['files'].items():assert sha(S/n)==h,n
cfg=read(S/'config.json')
for p,r in cfg['files'].items():assert sha(p)==r['sha256']and Path(p).stat().st_size==r['bytes'],p
b=read(S/'basis-reference.json')
for n,r in b['files'].items():
 p=R/b['repository_relative_directory']/n;assert sha(p)==r['sha256']and p.stat().st_size==r['bytes']
# Pure helper tests only: never load a predecessor validator, collector or full packet validator.
tree=ast.parse((S/'packet.py').read_text());names={'safe','same_source_closure','exact_reuse','profiles','reports','named_reports','digest','resolve_routes','absent'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in names]
env={'Path':Path,'PurePosixPath':PurePosixPath,'hashlib':hashlib,'re':re,'BINARY':{'.olean','.ilean','.o','.so','.a','.vo','.vos','.vok','.glob','.pyc','.pyo'},'STANDARD':{'propext','Classical.choice','Quot.sound'}}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(S/'packet.py'),'exec'),env)
checks=[]
def test(name,fn,want):
 try:fn();got=True
 except (AssertionError,KeyError):got=False
 assert got==want,(name,got,want);checks.append({'name':name,'accept':want,'matched':True})
test('ordinary source path',lambda:env['safe']('proofs/A.lean'),True)
for name in ['../a','/a','x.olean.private','x.olean.server','x.pyo','old.tar.gz','a//b']:
 test('unsafe '+name,lambda name=name:env['safe'](name),False)
test('empty axiom report',lambda:env['named_reports'](b"'A.x' does not depend on any axioms\n",['A.x'],[[]]),True)
test('extra standard axiom rejected',lambda:env['named_reports'](b"'A.x' depends on axioms: [propext]\n",['A.x'],[[]]),False)
test('changed namespace rejected',lambda:env['named_reports'](b"'B.x' does not depend on any axioms\n",['A.x'],[[]]),False)
old={'A':{'source_sha256':'a','imports':['Init']},'B':{'source_sha256':'b','imports':['A']}}
test('exact source closure',lambda:env['same_source_closure'](old,old,{'A','B'}),True)
test('hidden changed ancestor',lambda:env['same_source_closure']({**old,'A':{'source_sha256':'z','imports':['Init']}},old,{'A','B'}),False)
r={'source_sha256':'a','dependencies':{'X':'b'},'log_sha256':'c','status':'PASS','origin':'old'}
test('exact origin-only reuse',lambda:env['exact_reuse']({**r,'origin':'new'},r,'new'),True)
test('mutated dependency reuse',lambda:env['exact_reuse']({**r,'origin':'new','dependencies':{'X':'d'}},r,'new'),False)
v={'status':'PASS_INDEPENDENT_PURE_SOURCE_METADATA_CONTROLS','source_freeze_sha256':sha(S/'freeze.json'),'helper_pins':f['files'],'context_files_rehashed':len(cfg['files']),'phase12_reference_files_rehashed':len(b['files']),'controls':checks,'positive':sum(x['accept']for x in checks),'negative':sum(not x['accept']for x in checks),'script_sha256':sha(__file__),'scope':'Own hash/JSON/AST controls only. No producer, compiler, collector, saved reader or archive code executed. Owner controls remain prospective.'}
(O/'controls-review.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({'status':v['status'],'sha256':sha(O/'controls-review.json'),'positive':v['positive'],'negative':v['negative']}))
