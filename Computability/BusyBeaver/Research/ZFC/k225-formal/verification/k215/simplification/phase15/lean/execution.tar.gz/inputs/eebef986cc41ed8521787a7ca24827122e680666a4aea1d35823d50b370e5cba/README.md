# Phase15 combined check — prospective, not executed

This is a narrow successor of the reviewed phase14 serial driver. Its immutable
baselines are `/tmp/k215-phase14-check/primary-run2` (190 providers) and
`compatibility-run1` (70 providers), together 198 project modules and nine typed
clients. The phase14 failed first client is not selected as a provider. This
preparation invokes no Lean compiler or candidate producer and changes no
canonical source.

Eight Lean candidates combine three frozen source packets: the exact generic
ordinal recursion and hierarchy specialization; the quotient syntax/congruence
sharing; and the exact Source192 PowerSets import split plus dense bridge proof.
`sources.json` preserves each original before hash and candidate source path.
The proposed `generate_kq1.py` is separately pinned as inert data. Its reproduction
is a separate root-authorized obligation, not a side effect of this runner.

The actual endpoint graph has 176 project modules (down from 178), with 2,052,315
bytes of selected source (down from 2,093,112). Five decoder-prefix modules give
181. The typed client intentionally imports full `PSCCalibration` to check its
old calibration interface: those three extra modules remain in the audit scope.
Thus primary has 184 project modules and ten API clients, or 194 providers:
45 must be fresh and 149 reuse exact phase14 primary providers. The compatibility
plan has 69 project modules and two old clients, or 71 providers: after primary
passes, six are fresh, 54 reuse primary, and eleven retain phase14 evidence.
The full check covers 199 project modules because it adds `PowerSets` while
retaining the old calibration proof in its explicit continuity checks.

All seven old API clients retain their 34 exact named axiom profiles. The three
new clients have 28 exact named reports (3 basic interfaces, 18 recursion shapes
and interfaces, 7 quotient interfaces). Their actual arrays will be recorded
after the kernel run; the prospective gate requires the standard allowlist and
zero warnings. Both unchanged endpoint clients are compiled separately with
their exact ten phase14 named profiles. The two compatibility clients retain
their exact ten profiles, including the weaker `ZFNativeCompat12.models` array.

The source/import transitive invalidation rule is unchanged: an equal intermediate
object cannot hide a changed executable dependency. Secondary primary reuse in
the compatibility run requires the exact entire transitive source/import graph.
Every basis object and log is rehashed before and after use. All 198 canonical
basis project sources are checked even if no longer selected by the endpoint.
All nine physical-site batches remain source/import unchanged and retain their
existing evidence; no new branch execution or reduction claim is implied.

The boundary retains all nine phase14 adoption states (seven current source files
and two absent retired paths), the five phase13 adoptions, the three maintained
producer/adapter inputs, and the two earlier template absences. It also requires
the new canonical `PowerSets.lean` to remain absent before adoption. Machine and
toolchain pins are inherited exactly. Private caches contain no directory
symlinks; a target object is unlinked before each compiler write.

`commands.json` is only a plan. An independent frozen-source peer and explicit
root GO are required before primary execution. The one-worker lock and 12 GiB
cap are unchanged (120 seconds per ordinary module/client, 900 for a site batch).
After terminal primary PASS, the metadata-only finalizer rehashes all providers,
inputs and audits and produces a compatibility map with exact actual ledger pins.
That map needs its own bounded peer and root GO before compatibility execution.
No retry/partial-run initializer has been added.

`controls-result.json` records seven positive and twelve negative pure metadata
controls extracted from the own runner: transitive source/import forcing, the
identical-intermediate-object counterexample, secondary closure matching, exact
endpoint/compatibility profiles, warning/error rejection, and new-client names.
These controls do not invoke a proof compiler or candidate code. Original phase14
driver/finalizer/control sources are retained under `history/`; narrow diffs and
the exact frozen plans make the changes reviewable.
