"""Own narrow source transform of the reviewed phase14 serial runner."""
from pathlib import Path
import hashlib,json,difflib
R=Path('/home/codex/.codex/worktrees/ec20/Proofs');S=Path(__file__).resolve().parent
F=R/'Computability/BusyBeaver/Research/ZFC/k225-formal';B=Path('/tmp/k215-phase14-check/primary-run2');C=Path('/tmp/k215-phase14-check/compatibility-run1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
def save(p,x):assert not p.exists(),p;p.write_text(json.dumps(x,indent=2)+'\n')
oldboundary=Path('/tmp/k215-phase14-check/producer-boundary.json');old=read(oldboundary)
adoption=F/'verification/k215/simplification/phase14/integration/adoption.json';ad=read(adoption);assert ad['status']=='ADOPTED_EXACT_CHECKED_PHASE14'and len(ad['files'])==9
present={};absent=[]
for row in ad['files']:
 before=R/row['before_snapshot'];assert sha(before)==row['before_sha256'];present[str(before)]=row['before_sha256']
 p=R/row['path']
 if row['action']=='replace':assert sha(p)==row['after_sha256'];present[str(p)]=row['after_sha256']
 else:assert row['action']=='retire' and not p.exists() and not p.is_symlink();absent.append(str(p))
for row in old['files']:
 if row['current_state']=='present':assert sha(row['canonical'])==row['current_sha256'];present[row['canonical']]=row['current_sha256']
 else:assert not Path(row['canonical']).exists()and not Path(row['canonical']).is_symlink();absent.append(row['canonical'])
for p,h in old['accepted_five_files'].items():assert sha(p)==h;present[p]=h
p=str(F/'generate_l2k222.py');h=old['additional_inputs'][p];assert sha(p)==h;present[p]=h
for p in [adoption,oldboundary,F/'verification/k215/simplification/phase14/lean/result.json',F/'verification/k215/simplification/phase14/lean/index.json',F/'verification/k215/simplification/phase14/lean/execution.tar.gz',S/'sources.json',S/'clients.json',S/'proposal-inputs.json']:
 present[str(p)]=sha(p)
# Exact proposed/current generator boundary; no execution by this preparation.
producer=read(S/'producer-proposal.json')
for key in ['canonical_before','candidate']:
 row=producer[key];assert sha(row['path'])==row['sha256'];present[row['path']]=row['sha256']
for item in read(S/'proposal-inputs.json'):
 assert sha(item['path'])==item['sha256'];present[item['path']]=item['sha256']
new_module=R/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC/PowerSets.lean';assert not new_module.exists()and not new_module.is_symlink();absent.append(str(new_module))
boundary={'status':'PHASE15_CANDIDATE_CURRENT_BOUNDARY_NOT_ADOPTED','phase8_result_sha256':old['phase8_result_sha256'],'phase14_primary_result_sha256':sha(B/'result.json'),'phase14_compatibility_result_sha256':sha(C/'result.json'),'phase14_adoption_sha256':sha(adoption),'previous_boundary_sha256':sha(oldboundary),'present_inputs':present,'absent_inputs':sorted(absent),'retained_retirements':[r for r in ad['files']if r['action']=='retire'],'accepted_five_files':old['accepted_five_files'],'proposed_producer':producer,'scope':'All nine prior phase14 adoption states, prior five phase13 files, three maintained producer/adapter inputs and two prior template absences remain exact; new PowerSets canonical path absent until adoption. Candidate kq1 producer is data until separately reviewed reproduction.'}
save(S/'producer-boundary.json',boundary)
src=(S/'history/build-phase14.py').read_text();text=src
changes={"B=Path('/tmp/k215-phase13-upstream-check/primary-run1');BC=Path('/tmp/k215-phase13-upstream-check/compatibility-run1')":"B=Path('/tmp/k215-phase14-check/primary-run2');BC=Path('/tmp/k215-phase14-check/compatibility-run1')",'00a44b3ce690bfcd397f53275c2dcec69d25423de8e029086b0aefe020fb397e':sha(B/'result.json'),'bd9e50bce1c8a463719d83c201f402dad3edd89c0621ae827082b75638a3c74f':sha(C/'result.json'),'phase13_compatibility_checked':'phase14_compatibility_checked','phase13_primary_checked':'phase14_primary_checked','phase13_primary_reused_modules':'phase14_primary_reused_modules','phase13_compatibility_reused_modules':'phase14_compatibility_reused_modules',"(B,'phase14_primary_checked',187)":"(B,'phase14_primary_checked',190)",'assert len(old)==204':'assert len(old)==207'}
for before,after in changes.items():assert before in text,before;text=text.replace(before,after)
start=text.index("boundary_path=S/'producer-boundary.json'");end=text.index('for row in plans:',start)
text=text[:start]+'''boundary_path=S/'producer-boundary.json';assert sha(boundary_path)=='BOUNDARY_SHA'
producer_boundary=read(boundary_path);inputs[str(boundary_path)]=sha(boundary_path)
assert producer_boundary['phase8_result_sha256']==sha(A/'result.json')
assert producer_boundary['phase14_primary_result_sha256']==sha(B/'result.json') and producer_boundary['phase14_compatibility_result_sha256']==sha(BC/'result.json')
for p,h in producer_boundary['present_inputs'].items():assert sha(p)==h;inputs[p]=h
absent_inputs=producer_boundary['absent_inputs'];assert len(absent_inputs)==5
for p in absent_inputs:assert not Path(p).exists()and not Path(p).is_symlink(),p
retirements=producer_boundary['retained_retirements'];assert len(retirements)==2
assert {Path(r['path']).name for r in retirements}=={'KProfileTC.lean','generate_profile_tc.py'}
retired_modules={'BusyBeaver.ZFC.KProfileTC'}
assert len(producer_boundary['accepted_five_files'])==5
assert all(producer_boundary['present_inputs'].get(p)==h for p,h in producer_boundary['accepted_five_files'].items())
# Revalidate all 198 current project sources, not only the newly selected closure.
old_clients={'GenericShared13Api','NumericCD52Api','LukasShared13Api','DerivedRows14Api','ThmKDerived14Api','KEindDerived14Api','ProfileTC14Api','WFModelCompat12','ZFNativeCompat12'}
assert len(set(old)-old_clients)==198
for m,row in old_entries.items():
 if m in old_clients:continue
 found=[p for root in driver.ROOTS if (p:=R/root/(m.replace('.','/')+'.lean')).is_file()]
 assert len(found)==1;path=found[0]
 imports=[w for l in re.findall(r'(?m)^\\s*(?:public\\s+)?import\\s+([^\\n]+)',driver.without_comments_strings(path.read_text()))for w in l.split()]
 assert sha(path)==row['source_sha256']and imports==row['imports'];inputs[str(path)]=sha(path)
''' .replace('BOUNDARY_SHA',sha(S/'producer-boundary.json'))+text[end:]
text=text.replace("'proposed_retirements':retirements","'retained_retirements':retirements")
assert 'phase13_'not in text and 'proposed_retirements'not in text
(S/'build.py').write_text(text);(S/'driver.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),text.splitlines(True),fromfile='phase14/build.py',tofile='phase15/build.py')))
summary=read(S/'plan1/census.json');allrows={r['module']:r for r in read(S/'plan1/candidate-map.json')['modules']}
# Preserve named profiles for existing exported reports as well as the old clients.
base_inv={r['module']:r for r in read(B/'inventory.json')['modules']};base_done=read(B/'completed.json')
for m in ['BusyBeaver.ZFC.DominatedImplication','BusyBeaver.ZFC.DomRho8','BusyBeaver.ZFC.KCodeDom','BusyBeaver.ZFC.KThmK','BusyBeaver.ZFC.KEind222','BusyBeaver.ZFC.ProfileComposition','BusyBeaver.ZFC.CompositionModel']:
 r=base_inv[m];p=R/'Computability/BusyBeaver/Lean'/(m.replace('.','/')+'.lean');assert sha(p)==r['source_sha256']
 reports=base_done[m]['reports'];allrows[m]={**r,'source':str(p),'before_sha256':r['source_sha256'],'reports':[n for n,_ in reports],'report_axioms':[[x.strip()for x in ax.split(',')if x.strip()]for _,ax in reports]}
commands={}
for name in ['primary','compatibility']:
 inv=read(S/'plan1'/(name+'-inventory.json'));selected=[r['module']for r in inv['modules']]
 plan={'modules':[allrows[m]for m in selected if m in allrows],'expected':{'modules':selected,'changed':inv['changed'],'forced':inv['forced']}}
 file=name+'-map.json'if name=='primary'else'compatibility-template.json';save(S/file,plan)
 command=['python3','-B',str(S/'build.py'),'--out',str(S/(name+'-run1')),'--map',str(S/(file if name=='primary'else'compatibility-final-map.json'))]
 if name=='compatibility':command+=['--reuse',str(S/'primary-run1')]
 for target in inv['targets']:command+=['--target',target]
 if name=='primary':command+=['--audit-endpoint']
 commands[name]=command
save(S/'commands.json',{'status':'HELD_PENDING_SOURCE_PEER_AND_ROOT_GO','primary':commands['primary'],'finalize_compatibility':['python3','-B',str(S/'finalize_compatibility.py'),'--primary',str(S/'primary-run1'),'--out',str(S/'compatibility-final-map.json')],'compatibility':commands['compatibility'],'scope':'No compiler until explicit root GO; compatibility also requires terminal primary and reviewed final map.'})
final=(S/'history/finalizer-phase14.py').read_text();new=final.replace("/tmp/k215-phase13-upstream-check/primary-run1/result.json","/tmp/k215-phase14-check/primary-run2/result.json").replace('phase13_primary_reused_modules','phase14_primary_reused_modules').replace('phase13_compatibility_reused_modules','phase14_compatibility_reused_modules')
new=new.replace('and len(done)==190','and len(done)=='+str(summary['primary_providers'])).replace("len(result['fresh_modules'])==66", "len(result['fresh_modules'])=="+str(summary['primary_fresh'])).replace("len(result['phase14_primary_reused_modules'])==124","len(result['phase14_primary_reused_modules'])=="+str(summary['primary_reuse_by_basis'][str(B)]))
new=new.replace("assert not result['phase14_compatibility_reused_modules']and not result['secondary_reused_modules']","assert len(result['phase14_compatibility_reused_modules'])=="+str(summary['primary_reuse_by_basis'][str(C)])+" and not result['secondary_reused_modules']")
(S/'finalize_compatibility.py').write_text(new);(S/'finalizer.diff').write_text(''.join(difflib.unified_diff(final.splitlines(True),new.splitlines(True),fromfile='phase14/finalizer.py',tofile='phase15/finalizer.py')))
save(S/'plan-summary.json',summary)
print(json.dumps({'status':'SOURCE_ONLY_DRIVER_AND_PLANS_READY','runner_sha256':sha(S/'build.py'),'boundary_sha256':sha(S/'producer-boundary.json'),'primary':summary['primary_providers'],'fresh':summary['primary_fresh'],'reuse':summary['primary_reuse'],'compatibility':summary['compatibility_providers'],'union':summary['combined_project_modules']},indent=2))
