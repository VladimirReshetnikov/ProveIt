"""Read-only auxiliary metadata checks; no proof, capture or object invocation."""
from pathlib import Path
from copy import deepcopy
import json
from auxiliary import validate_auxiliary
from evidence import check_origins, digest, dump, graph, save, sha, source_scope
P=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
config=read(P/'config.json');b=Path(config['basis_run']);i=Path('/tmp/k215-phase9-main/isolated-run2');a=Path(config['auxiliary_run'])
old=read(b/'completed.json');iso=read(i/'completed.json')
oe={r['module']:r for r in read(b/'inventory.json')['modules']};ie={r['module']:r for r in read(i/'inventory.json')['modules']}
tool=read(a/'toolchain.json');controls=[]
def check(name,fn,negative=False):
    try:r=fn()
    except(AssertionError,KeyError):
        assert negative,name;controls.append({'name':name,'status':'EXPECTED_REJECTION'});return
    assert not negative,name;controls.append({'name':name,'status':'PASS'});return r
actual=check('completed auxiliary raw source/log/command/transitive metadata',
             lambda:validate_auxiliary(config,lambda p:Path(p).read_bytes(),old,iso,tool,oe,ie))
entries,closures=graph(read(a/'inventory.json')['modules'],read(a/'inventory.json')['targets'])
changed,forced,ok=source_scope(entries,closures,oe,ie);done=read(a/'completed.json')
check('actual exact source-closed auxiliary origins',lambda:check_origins(done,forced,ok))
for origin in ('phase8_checked','isolated_checked'):
    def bad(origin=origin):
        modified=deepcopy(done);modified['BusyBeaver.ZFC.KTape']['origin']=origin;check_origins(modified,forced,ok)
    check('reject KTape hidden behind '+origin,bad,True)
# Change only the plan's names, updating its metadata hash consistently. The
# independent literal-name check must still reject the different theorem names.
plan_path=Path(config['auxiliary_map']);plan=read(plan_path)
for row in plan['modules']:
    if row['module']=='BusyBeaver.ZFC.KHomeRuntimeAudit':row['reports']=['Wrong.'+str(x)for x in range(3)]
changed_bytes=dump(plan);pin=digest(changed_bytes);cfg=deepcopy(config);cfg['auxiliary_map_sha256']=pin
modified={str(plan_path):changed_bytes}
for name in ('before.json','result.json'):
    data=read(a/name);data['map_sha256']=pin;modified[str(a/name)]=dump(data)
cfg['auxiliary_result_sha256']=digest(modified[str(a/'result.json')])
check('wrong qualified RuntimeAudit names with matching metadata hashes',
      lambda:validate_auxiliary(cfg,lambda p:modified.get(str(p),Path(p).read_bytes()),old,iso,tool,oe,ie),True)
result={'status':'PASS_AUXILIARY_METADATA_CONTROLS','compiler_or_collector_invoked':False,
        'positive':sum(r['status']=='PASS'for r in controls),'negative':sum(r['status']=='EXPECTED_REJECTION'for r in controls),
        'controls':controls,'actual_metadata':actual,'script_sha256':sha(__file__),
        'auxiliary_validator_sha256':sha(P/'auxiliary.py'),'validator_sha256':sha(P/'evidence.py')}
save(P/'auxiliary-controls.json',result);print(json.dumps(result,indent=2))
