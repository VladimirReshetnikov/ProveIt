"""Independent inert review of the client-only retry. Does not run its initializer."""
from pathlib import Path
import json,hashlib,ast,copy,re
S=Path('/tmp/k215-phase14-retry');B=Path('/tmp/k215-phase14-check');O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
f=read(S/'freeze.json');assert sha(S/'freeze.json')=='cf22ecb2057efdcdf3035b932153ed399d2f278c6f19d07d18301a0f13554dee'
for p,h in f['files'].items():assert sha(S/p)==h,p
for p,h in f['external_inputs'].items():assert sha(p)==h,p
old=read(B/'primary-map.json');new=read(S/'primary-map.json');copyold=copy.deepcopy(old)
for r in copyold['modules']:
 if r['module']=='ProfileTC14Api':r.update(source='/tmp/k215-phase14-profile/client-v2/ProfileTC14Api.lean',source_sha256='2385bc17262454b91c11ba6f4758adddb58b005ab38cf7e5efdbc07d5c3bac6e')
assert copyold==new
p=Path('/tmp/k215-phase14-profile');before=(p/'clients/ProfileTC14Api.lean').read_text();after=(p/'client-v2/ProfileTC14Api.lean').read_text()
assert before.replace('transitivity hCodes hFibers hCompositions hUnions hxy hyz :=','transitivity hCodes hFibers hCompositions hUnions _ _ _ hxy hyz :=')==after
run=B/'primary-run1';iv=read(run/'inventory.json');done=read(run/'completed.json');rows={r['module']:r for r in iv['modules']};plans={r['module']:r for r in old['modules']}
assert len(rows)==190 and len(done)==189 and set(rows)-set(done)=={'ProfileTC14Api'}and not(run/'result.json').exists()
counts={}
for m,r in done.items():
 counts[r['origin']]=counts.get(r['origin'],0)+1
 assert r['status']=='PASS'and r.get('exit_code',0)==0 and not r.get('timed_out',False)
 assert r['source_sha256']==rows[m]['source_sha256']==sha(rows[m]['source'])
 assert r['dependencies']=={d:done[d]['object_sha256']for d in rows[m]['imports']if d!='Init'}
 assert sha(run/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256']and sha(r['log'])==r['log_sha256']
 if r['origin']=='candidate_fresh':assert sha(r['source'])==r['source_sha256']
 txt=Path(r['log']).read_text();assert 'error:'not in txt and 'sorryAx'not in txt
 reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
 assert all({x.strip()for x in a.split(',')if x.strip()}<={'propext','Classical.choice','Quot.sound'}for _,a in reports)
 if m in plans and'reports'in plans[m]:
  assert [n for n,_ in reports]==plans[m]['reports']and 'warning:'not in txt
  if'report_axioms'in plans[m]:assert [{x.strip()for x in a.split(',')if x.strip()}for _,a in reports]==[set(a)for a in plans[m]['report_axioms']]
assert counts=={'phase13_primary_checked':124,'candidate_fresh':65}
failed=read(run/'attempts/066-ProfileTC14Api/record.json');assert failed['status']=='FAIL'and failed['exit_code']!=0
assert 'sorryAx'in(run/'attempts/066-ProfileTC14Api/compiler.log').read_text()
assert read('/tmp/k215-phase14-execution/primary-run1-outer.json')['exit_code']==1
assert not any(run.glob('audit-*'))
tree=ast.parse((B/'build.py').read_text());i=next(i for i,n in enumerate(tree.body)if isinstance(n,ast.For)and isinstance(n.target,ast.Name)and n.target.id=='row'and isinstance(n.iter,ast.Name)and n.iter.id=='rows')
prefix=ast.Module(body=tree.body[:i],type_ignores=[])
assert not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='run_locked'for n in ast.walk(prefix))
assert isinstance(tree.body[i-1],ast.FunctionDef)and tree.body[i-1].name=='log_policy'
result={'status':'PASS_INDEPENDENT_CLIENT_ONLY_RETRY_SOURCE_AND_BINDINGS','freeze_sha256':sha(S/'freeze.json'),'initializer_sha256':sha(S/'initialize.py'),'map_sha256':sha(S/'primary-map.json'),'finalizer_sha256':sha(S/'finalize_compatibility.py'),'driver_unchanged_sha256':sha(B/'build.py'),'prior_successful_providers':189,'origins':counts,'failed_client_record_sha256':sha(run/'attempts/066-ProfileTC14Api/record.json'),'only_client_binders_changed':True,'no_old_terminal_PASS_or_endpoint_audits':True,'selected_AST_prefix_contains_no_compiler_call':True,'scope':'Own read-only data and AST inspection plus rehash189 successful records/objects/logs. Did not execute initializer, driver, producer or proof compiler; did not modify canonical files. This does not accept the failed primary run.'}
(O/'retry-metadata-review.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',counts)
