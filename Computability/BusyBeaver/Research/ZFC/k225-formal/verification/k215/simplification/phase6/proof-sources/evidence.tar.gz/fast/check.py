"""Finite producer/type/import controls only; no compiler or machine runtime."""
from pathlib import Path
import sys,json,re,hashlib,subprocess,time,difflib
O=Path(__file__).resolve().parent;P=Path('/tmp/k215-normalized-migration');R=Path('/home/codex/.codex/worktrees/ec20/Proofs');W=O/'workspace';F=Path('Computability/BusyBeaver/Research/ZFC/k225-formal');L=Path('Computability/BusyBeaver/Lean/BusyBeaver/ZFC');RUN=O/'run1';RUN.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
def run(name,args):
 t=time.monotonic();a=[sys.executable,*map(str,args)];p=subprocess.run(a,cwd=W,capture_output=True,timeout=60)
 (RUN/(name+'.stdout')).write_bytes(p.stdout);(RUN/(name+'.stderr')).write_bytes(p.stderr)
 records.append({'name':name,'argv':a,'cwd':str(W),'exit_code':p.returncode,'seconds':time.monotonic()-t,'timeout_seconds':60});assert p.returncode==0
held={p.name:sha(p)for p in(W/L).glob('*.lean')if not p.name.startswith('KSites215')}
inputs={str(p.relative_to(W)):sha(p)for p in[W/F/'generate_sites215_lean.py',W/F/'gen_cert.py',W/F.parent/'candidate-k215/sites215.json']}
run('sites',[W/F/'generate_sites215_lean.py','full','80','12'])
first={p.name:sha(p)for p in(W/L).glob('KSites215*.lean')}
run('repeat',[W/F/'generate_sites215_lean.py','full','80','12']);assert first=={p.name:sha(p)for p in(W/L).glob('KSites215*.lean')}
assert held=={p.name:sha(p)for p in(W/L).glob('*.lean')if not p.name.startswith('KSites215')}
assert inputs=={str(p.relative_to(W)):sha(p)for p in[W/F/'generate_sites215_lean.py',W/F/'gen_cert.py',W/F.parent/'candidate-k215/sites215.json']}
# The prototype differs only in its introductory comment.
def erase_comments(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s.startswith('/-',i):depth+=1;i+=2
  elif depth and s.startswith('-/',i):depth-=1;i+=2
  elif depth:i+=1
  elif s.startswith('--',i):
   j=s.find('\n',i);i=len(s)if j<0 else j
  else:out.append(s[i]);i+=1
 assert depth==0;return ''.join(out)
assert erase_comments((W/L/'KFastSites215.lean').read_text())==erase_comments((O/'original/KFastSites215.uncompiled.lean').read_text())
rows=[]
for p in sorted((W/L).glob('KSites215Batch*.lean')):
 old=(P/'workspace'/L/p.name).read_text();s=p.read_text()
 expected=old.replace('import BusyBeaver.ZFC.KSim\nimport BusyBeaver.ZFC.KTable215\n','import BusyBeaver.ZFC.KFastSites215\n').replace('  decide +kernel\n','  exact KFastSites215.allSites_of_fast (by decide +kernel)\n')
 assert s==expected,p.name
 heads=re.findall(r'theorem (block_\d+) :(.*?) := by',s,re.S);oldheads=re.findall(r'theorem (block_\d+) :(.*?) := by',old,re.S);assert heads==oldheads
 rows.append({'file':p.name,'blocks':[n for n,_ in heads],'leaves':sum(map(int,re.findall(r'/-- (\d+) leaves\. -/',s))),'sha256':sha(p)})
assert len(rows)==9 and [x for r in rows for x in r['blocks']]==[f'block_{i}'for i in range(105)]
assert sum(r['leaves']for r in rows)==4751
assert (W/L/'KSites215.lean').read_bytes()==(P/'workspace'/L/'KSites215.lean').read_bytes()
# The unchanged primary basis plus exactly the three new modules, resolved dynamically.
inv=json.loads(Path('/tmp/k215-proof-phase5/lean-run1/inventory.json').read_text());roots=sorted({Path(r['source']).parents[len(r['module'].split('.'))-1]for r in inv['modules']});g={};order=[];sources={}
def source(m):
 rel=Path(*m.split('.')).with_suffix('.lean');p=W/'Computability/BusyBeaver/Lean'/rel
 if p.is_file():return p
 candidates=[r/rel for r in roots if(r/rel).is_file()];assert len(candidates)==1;return candidates[0]
def visit(m):
 if m in g:return
 p=source(m);sources[m]=p;g[m]=[x for x in re.findall(r'^import (\S+)',p.read_text(),re.M)if x not in inv['external_imports']]
 for d in g[m]:visit(d)
 order.append(m)
visit(inv['target']);oldset={r['module']for r in inv['modules']};assert len(order)==187 and oldset<=set(order)
assert set(order)-oldset=={'BusyBeaver.ZFC.KSource215Program','BusyBeaver.ZFC.RMNormalizedBisim','BusyBeaver.ZFC.KFastSites215'}
def closure(m):
 c=set()
 def go(n):
  if n in c:return
  c.add(n)
  for d in g[n]:go(d)
 go(m);return c
siteclosure=closure('BusyBeaver.ZFC.KSites215Batch000');assert 'BusyBeaver.ZFC.KSource215'not in siteclosure and 'BusyBeaver.ZFC.RMNormalizedBisim'not in siteclosure
# Concrete all-state equality remains the old KFast215 theorem, not a finite selected-state claim.
fast=R/L/'KFast215.lean';assert 'theorem fast215 (q : Nat) (b : Bool) : fastOf tt215 q b = tm215 q b' in fast.read_text()
ledger=[{'module':m,'source':str(sources[m]),'source_sha256':sha(sources[m]),'imports':g[m]}for m in order]
(O/'proposed-inventory.json').write_text(json.dumps({'target':inv['target'],'modules':ledger,'external_imports':inv['external_imports']},indent=2)+'\n')
result={'status':'PASS_SOURCE_PRODUCER_ONLY','jobs':records,'input_bindings':inputs,'inputs_unchanged':True,'adapter_declarations_and_proofs_exact_prototype':True,'source175_prototype_sha256':sha(O/'original/KFastSites215.uncompiled.lean'),'blocks_105_statements_exact':True,'proof_change':'exact KFastSites215.allSites_of_fast (by decide +kernel)','batches':rows,'physical_leaf_count':4751,'facade_proof_exact':True,'normalized_and_program_outputs_unchanged':held,'primary_project_modules':187,'site_batch_project_closure':len(siteclosure),'site_batch_modules':sorted(siteclosure),'existing_fast215_provider_sha256':sha(fast),'compiler_executed':False,'canonical_mutation':False}
(RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n')
paths=[F/n for n in['generate_source215_lean.py','partition_source215_lean.py','generate_sites215_lean.py','prepare_k215.py']]+[p.relative_to(W)for p in sorted((W/L).glob('*.lean'))]
changes=[];unchanged=[]
for rel in paths:
 p=W/rel;old=R/rel;item={'source':str(p),'destination':str(rel),'sha256':sha(p),'bytes':p.stat().st_size,'before_sha256':sha(old)if old.is_file()else None}
 if old.is_file()and old.read_bytes()==p.read_bytes():unchanged.append(item)
 else:changes.append(item)
assert len(changes)==20 and len(unchanged)==16
(O/'combined-adoption-map.json').write_text(json.dumps({'status':'SCRATCH_NOT_ADOPTED_NOT_COMPILED','rows':changes,'regenerated_unchanged':unchanged,'normalized_predecessor_map_sha256':sha(P/'adoption-map.json')},indent=2)+'\n')
delta=[]
for rel in [F/'generate_sites215_lean.py',L/'KFastSites215.lean']+[L/f'KSites215Batch{i:03d}.lean'for i in range(9)]:
 p=W/rel;old=P/'workspace'/rel;delta.append({'source':str(p),'destination':str(rel),'sha256':sha(p),'before_sha256':sha(old)if old.is_file()else None})
 (O/'diffs').mkdir(exist_ok=True);(O/'diffs'/(p.name+'.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True)if old.is_file()else[],p.read_text().splitlines(True),fromfile='normalized-program/'+str(rel),tofile='fast-sites/'+str(rel))))
(O/'delta-adoption-map.json').write_text(json.dumps({'status':'ADDITIVE_ON_HELD_NORMALIZED_PROGRAM','rows':delta},indent=2)+'\n')
print(json.dumps({k:result[k]for k in['status','blocks_105_statements_exact','physical_leaf_count','primary_project_modules','site_batch_project_closure','compiler_executed','canonical_mutation']},indent=2))
