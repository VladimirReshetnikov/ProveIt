from pathlib import Path
import json,hashlib,subprocess,sys,time
O=Path(__file__).resolve().parent;W=O/'workspace';F=W/'Computability/BusyBeaver/Research/ZFC/k225-formal';L=W/'Computability/BusyBeaver/Lean/BusyBeaver/ZFC';RUN=O/'prepare-control';RUN.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[F/n for n in['generate_source215_lean.py','partition_source215_lean.py','generate_sites215_lean.py','prepare_k215.py']]+list(L.glob('*.lean'));before={str(p.relative_to(W)):sha(p)for p in paths};jobs=[]
for name,args in [('prepare',[F/'prepare_k215.py']),('sites',[F/'generate_sites215_lean.py','full','80','12'])]:
 a=[sys.executable,*map(str,args)];t=time.monotonic();p=subprocess.run(a,cwd=W,capture_output=True,timeout=60)
 (RUN/(name+'.stdout')).write_bytes(p.stdout);(RUN/(name+'.stderr')).write_bytes(p.stderr);jobs.append({'argv':a,'cwd':str(W),'exit_code':p.returncode,'seconds':time.monotonic()-t,'timeout_seconds':60});assert p.returncode==0
 assert before=={str(p.relative_to(W)):sha(p)for p in paths}
result={'status':'PASS','all_candidate_sources_and_maintained_producers_unchanged':before,'jobs':jobs,'compiler_executed':False};(RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS')
