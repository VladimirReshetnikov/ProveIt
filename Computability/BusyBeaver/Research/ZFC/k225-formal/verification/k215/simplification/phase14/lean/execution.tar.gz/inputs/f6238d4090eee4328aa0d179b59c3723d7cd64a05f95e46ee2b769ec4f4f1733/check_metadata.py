"""Independent inert metadata/graph check; does not import any candidate runner."""
from pathlib import Path
import json,hashlib,re
S=Path('/tmp/k215-phase14-check');O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
f=read(S/'freeze.json');assert sha(S/'freeze.json')=='b74517e2f8cab00ddf2bc4a9e8667161036a517e1569233f8a5ff8b0a7accc65'
for p,h in f['files'].items():assert sha(S/p)==h,p
proposal=read(S/'proposal-inputs.json')
for p,h in proposal.items():assert sha(p)==h,p
old={};oldrec={}
for directory,n in [('/tmp/k215-phase13-upstream-check/compatibility-run1',70),('/tmp/k215-phase13-upstream-check/primary-run1',187)]:
 d=Path(directory);r=read(d/'result.json');iv=read(d/'inventory.json');done=read(d/'completed.json')
 assert r['status']=='PASS' and len(iv['modules'])==len(done)==n
 assert sha(d/'completed.json')==r['completed_sha256']and sha(d/'inventory.json')==r['inventory_sha256']
 for row in iv['modules']:
  m=row['module']
  if m in old:assert (row['source_sha256'],row['imports'],done[m]['object_sha256'])==(old[m]['source_sha256'],old[m]['imports'],oldrec[m]['object_sha256'])
  old[m]=row;oldrec[m]=done[m]
assert len(old)==204
summaries={};ivs={}
for label,planfile,n in [('primary','primary-map.json',190),('compatibility','compatibility-template.json',70)]:
 iv=read(S/f'plan1/{label}-inventory.json');rows={r['module']:r for r in iv['modules']};plan=read(S/planfile);overrides={r['module']:r for r in plan['modules']}
 assert len(rows)==len(iv['modules'])==n;assert len(overrides)==len(plan['modules'])
 assert list(rows)==plan['expected']['modules'];seen=set();ext=set()
 for m,row in rows.items():
  assert sha(row['source'])==row['source_sha256'],m
  imports=[w for group in re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\n]+)',Path(row['source']).read_text())for w in group.split()]
  assert imports==row['imports'],m
  for dep in imports:
   if dep not in rows:ext.add(dep)
   else:assert dep in seen,(m,dep)
  seen.add(m)
  if m in overrides:
   q=overrides[m];assert (q['source'],q['source_sha256'],q['imports'])==(row['source'],row['source_sha256'],row['imports'])
   if m in old:assert q['before_sha256']==old[m]['source_sha256']
  else:assert (row['source_sha256'],row['imports'])==(old[m]['source_sha256'],old[m]['imports'])
 assert ext<= {'Init'}and sorted(ext)==iv['external_imports']
 changed={m for m,row in rows.items()if m not in old or(row['source_sha256'],row['imports'])!=(old[m]['source_sha256'],old[m]['imports'])}
 affected=set(changed)
 for m,row in rows.items():
  if set(row['imports'])&affected:affected.add(m)
 assert sorted(changed)==plan['expected']['changed']==iv['changed']
 assert sorted(affected)==plan['expected']['forced']==iv['forced']
 assert 'BusyBeaver.ZFC.KProfileTC'not in rows
 summaries[label]={'count':len(rows),'changed':sorted(changed),'affected':sorted(affected),'external_imports':sorted(ext)};ivs[label]=rows
assert len(summaries['primary']['affected'])==66
common=set(ivs['primary'])&set(ivs['compatibility'])
for m in common:assert (ivs['primary'][m]['source_sha256'],ivs['primary'][m]['imports'])==(ivs['compatibility'][m]['source_sha256'],ivs['compatibility'][m]['imports'])
fresh=set(summaries['compatibility']['affected'])-common
old_reuse=set(ivs['compatibility'])-common-fresh
assert len(common)==53 and len(fresh)==16 and old_reuse=={'BusyBeaver.ZFC.Dag254'}
projects={m for rows in ivs.values()for m in rows if '.'in m};assert len(projects)==198
sites=[m for m in ivs['primary']if re.search(r'KSites215Batch\d{3}$',m)]
assert len(sites)==9 and not(set(sites)&set(summaries['primary']['affected']))
source_rows=read(S/'sources.json');client_rows=read(S/'clients.json');assert len(source_rows)==7 and len(client_rows)==4
assert sum(len(r['reports'])for r in client_rows)==14
assert [r['module']for r in client_rows if 'report_axioms'not in r]==['DerivedRows14Api','ThmKDerived14Api','KEindDerived14Api']
for label,planfile in [('primary','primary-map.json'),('compatibility','compatibility-template.json')]:
 for r in read(S/planfile)['modules']:
  if r['module']not in oldrec or 'reports'not in r:continue
  txt=Path(oldrec[r['module']]['log']).read_text();reports=re.findall(r"'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)",txt)
  assert [n for n,_ in reports]==r['reports'],r['module']
  assert [{x.strip()for x in a.split(',')if x.strip()}for _,a in reports]==[set(a)for a in r['report_axioms']],r['module']
boundary=read(S/'producer-boundary.json')
for p,h in boundary['additional_inputs'].items():assert sha(p)==h,p
for r in boundary['proposed_retirements']:
 assert sha(r['canonical'])==sha(r['before_snapshot'])==r['before_sha256']
 assert r['current_state']=='present_before_candidate_check'and r['proposed_state']=='absent_only_after_accepted_adoption'
for r in boundary['files']:
 if r['current_state']=='absent':assert not Path(r['canonical']).exists()and not Path(r['canonical']).is_symlink()
 else:assert sha(r['canonical'])==sha(r['current_snapshot'])==r['current_sha256']
result={'status':'PASS_INDEPENDENT_INERT_PIN_GRAPH_PROFILE_CHECK','freeze_sha256':sha(S/'freeze.json'),'frozen_files':len(f['files']),'proposal_inputs':len(proposal),'basis_union':len(old),'summaries':summaries,'primary_fresh':66,'primary_reuse':124,'compatibility_fresh':16,'compatibility_primary_reuse':53,'compatibility_old_reuse':sorted(old_reuse),'project_union':198,'nine_sites_unaffected':sites,'source_map':source_rows,'client_map':client_rows,'scope':'Only own JSON/source/hash graph and saved-log profile inspection. No candidate helper, producer, Lean compiler, or canonical mutation.'}
(O/'metadata-review.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: 48 frozen files; 190/70 plans, 66/16 fresh sets, 198 project union, 9 sites unaffected')
