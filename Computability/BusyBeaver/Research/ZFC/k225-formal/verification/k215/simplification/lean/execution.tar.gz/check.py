from pathlib import Path
import hashlib,importlib.util,json,os,signal,subprocess,sys,time
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs');out=Path('/tmp/k215-proof-simplification/root');cache=out/'objects';old=Path('/tmp/k215-lean-complete');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('driver',repo/'Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/lean/build.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
donepath=out/'completed.json';done=json.loads(donepath.read_text())if donepath.exists()else json.loads((old/'completed.json').read_text());rows=[]
modules={}
for target in sys.argv[1:] or ['BusyBeaver.ZFC.KEndpoint215']:
 driver.TARGET=target
 for e in driver.inventory(repo)['modules']:modules[e['module']]=e
(out/'inventory.json').write_text(json.dumps(list(modules.values()),indent=2)+'\n')
env=os.environ.copy();env['LEAN_PATH']=str(cache);env['LEAN_NUM_THREADS']='1'
compiler='/home/codex/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean'
for m,e in modules.items():
 src=Path(e['source']);obj=cache/(m.replace('.','/')+'.olean');deps={d:done[d]['object_sha256']for d in e['imports']if d in modules};prior=done.get(m)
 if prior and prior['source_sha256']==sha(src)and prior['dependencies']==deps and obj.is_file()and prior['object_sha256']==sha(obj):continue
 index=1+len(list(out.glob('attempt-*')));a=out/f'attempt-{index:03d}-{m}';a.mkdir();(a/src.name).write_bytes(src.read_bytes());obj.parent.mkdir(parents=True,exist_ok=True)
 root=str(src)[:-len(m.replace('.','/')+'.lean')].rstrip('/');cmd=[compiler,'-j1','-M12288','--root='+root,'-o',str(obj),str(src)]
 row={'module':m,'source':str(src),'source_sha256':sha(src),'dependencies':deps,'command':cmd,'reuse_scope':'Incremental check against pinned prior K215 objects; not a fresh full replay.'}
 print('CHECK',m,flush=True)
 ok=driver.run_locked(cmd,repo,env,Path('/tmp/proveit-k215-proof-build.lock'),a/'compiler.log',900,row,a/'record.json');row['source_unchanged']=sha(src)==row['source_sha256'];assert row['source_unchanged']
 print(row['status'],m,round(row['seconds'],3),flush=True)
 if not ok:print((a/'compiler.log').read_text()[-14000:],flush=True);sys.exit(1)
 row['object_sha256']=sha(obj);row['companions']={str(p):sha(p)for p in obj.parent.glob(obj.stem+'.olean*')};done[m]=row;rows.append(row);donepath.write_text(json.dumps(done,indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'status':'PASS','targets':sys.argv[1:],'closure':list(modules),'changed_compilations':rows},indent=2)+'\n');print('PASS',len(modules),'closure modules',flush=True)
