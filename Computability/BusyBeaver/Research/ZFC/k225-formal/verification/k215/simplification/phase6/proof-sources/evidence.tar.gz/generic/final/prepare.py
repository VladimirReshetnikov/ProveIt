"""Keep only the new parametric API; the submitted module remains historical."""
from pathlib import Path
import json,hashlib,difflib,subprocess
P=Path(__file__).resolve().parent;old=P.parent
s=(old/'RMNormalizedBisim.lean').read_text();s=s[:s.index('/-- K215\'s explicit long-pointer instance;')]+ 'end SetTheory.BusyBeaver.ZFC.RMNormalizedBisim\n'
s=s.replace('The original\npublic facade explicitly uses 512 steps for K215; RMBisim.decode stays at 128.','K215 supplies an\nexplicit 512-step decoder at its use site; RMBisim.decode stays at 128.')
(P/'RMNormalizedBisim.lean').write_text(s)
a=(old/'Audit.lean').read_text().replace('open RegisterPath RMBisim\n','open RegisterPath RMBisim\n\ndef decode215 (n : Nat) : List Bool := decodeAux 512 n []\n')
a=a.replace('RMNormalizedBisim.branchOk','RMNormalizedBisim.WithDecoder.branchOk decode215').replace('RMNormalizedBisim.entryOk','RMNormalizedBisim.WithDecoder.entryOk decode215').replace('RMNormalizedBisim.check_halts_iff hs','RMNormalizedBisim.WithDecoder.check_halts_iff decode215 hs').replace('RMNormalizedBisim.decodeLong','decode215')
(P/'Audit.lean').write_text(a)
(P/'run.py').write_bytes((old/'run.py').read_bytes())
original=(old/'RMNormalizedBisim.original.lean').read_text()
(P/'source.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='Source168/RMNormalizedBisim.lean',tofile='candidate/RMNormalizedBisim.lean')))
(P/'successor.diff').write_text(''.join(difflib.unified_diff((old/'RMNormalizedBisim.lean').read_text().splitlines(True),s.splitlines(True),fromfile='run1/RMNormalizedBisim.lean',tofile='final/RMNormalizedBisim.lean')))
repo=Path('/home/codex/.codex/worktrees/ec20/Proofs');check=subprocess.run(['rg','-n','RMNormalizedBisim',str(repo/'Computability/BusyBeaver/Lean'),str(repo/'SetTheory/BoundedConsistency/Lean')],capture_output=True,text=True)
assert check.returncode==1 and not check.stdout and not check.stderr
(P/'import-census.json').write_text(json.dumps({'status':'NO_EXISTING_MAINTAINED_LEAN_IMPORT_OR_REFERENCE','argv':check.args,'exit_code':check.returncode,'stdout':check.stdout,'stderr':check.stderr,'scope':'Two maintained Lean roots; submitted proposal copies deliberately excluded. No old maintained module or public API removed.'},indent=2)+'\n')
r={'status':'PREPARED_FINAL_UNCOMPILED','candidate_bytes':len(s.encode()),'candidate_lines':len(s.splitlines()),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'removed_wrappers':'Only run1 experimental outer facade; no maintained callers. Generic WithDecoder API retained.'}
(P/'preparation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
