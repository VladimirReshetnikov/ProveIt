from pathlib import Path
import hashlib,json
s=Path('/tmp/k215-phase15-client-retry');out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());f=read(s/'freeze.json')
for n,p in f['files'].items():assert sha(s/n)==p
for n,p in f['external_inputs'].items():assert sha(n)==p
p=read('/tmp/k215-phase15-retry/primary-map.json');q=read(s/'primary-map.json');r=next(r for r in p['modules']if r['module']=='QuotientSharing15Api');new=next(r for r in q['modules']if r['module']=='QuotientSharing15Api');r['source']=new['source'];r['source_sha256']=new['source_sha256'];assert p==q
assert (s/'compatibility-template.json').read_bytes()==Path('/tmp/k215-phase15-retry/compatibility-template.json').read_bytes()
b=Path('/tmp/k215-phase15-check/primary-run2');inv=read(b/'inventory.json');done=read(b/'completed.json');before=read(b/'before.json');assert len(done)==193 and set(done)=={r['module']for r in inv['modules'][:193]}
for p,h in before['inputs'].items():assert sha(p)==h,p
for p in before['absent_inputs']:assert not Path(p).exists()and not Path(p).is_symlink()
for row in inv['modules'][:193]:
 m=row['module'];r=done[m];assert r['status']=='PASS'and r.get('exit_code',0)==0;assert sha(row['source'])==r['source_sha256']==row['source_sha256'];assert sha(r['log'])==r['log_sha256'];assert sha(b/'objects'/(m.replace('.','/')+'.olean'))==r['object_sha256'];assert r['dependencies']=={d:done[d]['object_sha256']for d in row['imports']if d!='Init'}
 if r['origin']=='candidate_fresh':assert sha(r['source'])==row['source_sha256']
assert sum(r['origin']=='candidate_fresh'for r in done.values())==44
first=read('/tmp/k215-phase15-check/primary-run1/completed.json');assert len(first)==87 and all(done[m]==r for m,r in first.items())
failed=read(b/'attempts/026-QuotientSharing15Api/record.json');assert failed['status']=='FAIL'and failed['exit_code']==1 and failed['object_sha256']is None;assert sha(failed['log'])==failed['log_sha256'];assert not(b/'result.json').exists()
rr={'status':'PASS_RECORD_BINDINGS_AWAITING_INITIALIZER_SUCCESSOR','freeze_sha256':sha(s/'freeze.json'),'files_checked':len(f['files']),'external_inputs_checked':len(f['external_inputs']),'before_inputs_rehashed':len(before['inputs']),'providers_rehashed':193,'successful_fresh':44,'run1_fresh':19,'run2_fresh':25,'phase14_reuses':149,'failed_client_excluded':True,'completed_insertion_order_equals_inventory_prefix':list(done)==[r['module']for r in inv['modules']][:193],'candidate':'de617903b04e5bad6e30587fdc5a490ead6fd35c271cc439e8146bb15a3df657'}
(out/'bindings.json').write_text(json.dumps(rr,indent=2)+'\n');print(json.dumps(rr))
