"""Independent literal comparison; no generator/package code is imported."""
from pathlib import Path
import re,json,hashlib
P=Path(__file__).resolve().parent
R=Path('/home/codex/.codex/worktrees/ec20/Proofs')
L='Computability/BusyBeaver/Lean/BusyBeaver/ZFC'
N=Path('/tmp/k215-zero-offset/workspace')
old=(R/L/'KSource215Data.lean').read_text();new=(N/L/'KSource215Data.lean').read_text()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def decls(s):
 ms=list(re.finditer(r'(?m)^(def|abbrev|theorem) ([\w\']+)',s));out={}
 for i,m in enumerate(ms):
  t=s[m.start():ms[i+1].start() if i+1<len(ms) else len(s)]
  t=re.split(r'(?m)^#print|^end |^/-',t)[0].rstrip()
  out[m[2]]=t
 return out
od,nd=decls(old),decls(new)
class Parse:
 def __init__(self,s):
  tokens=re.findall(r'\.branch|\.leaf|fwd\d+|Int|-?\d+|[(),:]',s)
  assert re.sub(r'\s+','',s)==''.join(tokens),'unparsed input'
  self.t=tokens;self.i=0
 def take(self,x=None):
  t=self.t[self.i];self.i+=1
  if x is not None:assert t==x,(t,x)
  return t
 def integer(self):
  if self.t[self.i]=='(':
   self.take('(');n=int(self.take());self.take(':');self.take('Int');self.take(')');return n
  return int(self.take())
 def tree(self):
  if self.t[self.i]=='(':
   self.take('(');r=self.tree();self.take(')');return r
  t=self.take()
  if t=='.branch':return ('branch',self.integer(),self.tree(),self.tree())
  if t=='.leaf':
   self.take('(');xs=[self.integer()]
   while self.t[self.i]==',':self.take(',');xs.append(self.integer())
   self.take(')');return ('leaf',tuple(xs))
  assert re.fullmatch(r'fwd\d+',t);return ('ref',t)
 def all(self):
  r=self.tree();assert self.i==len(self.t);return r
def body(d):return d.split(':=',1)[1].strip()
def project(t):
 if t[0]=='leaf':
  a,b,z,j,k=t[1];assert z==0;return ('leaf',(a,b,j,k))
 if t[0]=='branch':return ('branch',t[1],project(t[2]),project(t[3]))
 return t
def leaves(t):
 if t[0]=='leaf':return [t[1]]
 assert t[0]=='branch';return leaves(t[2])+leaves(t[3])
def cuts(t):
 if t[0]=='branch':return [t[1]]+cuts(t[2])+cuts(t[3])
 return []
entries=[];shapes=[]
for i in range(16):
 key=f'fwd{i}';a=Parse(body(od[key])).all();b=Parse(body(nd[key])).all()
 assert project(a)==b and cuts(a)==cuts(b)
 oldrows=leaves(a);rows=leaves(b);assert len(rows)==140
 entries+=oldrows;shapes.append({'part':i,'entries':len(rows),'cuts':len(cuts(b))})
assert len(entries)==2240
assert Parse(body(od['fwdCert'])).all()==Parse(body(nd['fwdCert'])).all()
shared=[k for k in od if not k.startswith('fwd')]
assert all(od[k]==nd[k] for k in shared),[k for k in shared if od[k]!=nd[k]]
assert nd['decode215']=='def decode215 (n : Nat) : List Bool := decodeAux 512 n []'
oldfac=decls((R/L/'KSource215.lean').read_text());newfac=decls((N/L/'KSource215.lean').read_text())
assert oldfac['p215_halts_iff'].split(':=')[0]==newfac['p215_halts_iff'].split(':=')[0]
assert od['path_iff_iter']==nd['path_iff_iter']
for i in range(16):
 oldchunk=(R/L/f'KSource215FwdCheck{i:02d}.lean').read_text()
 newchunk=(N/L/f'KSource215FwdCheck{i:02d}.lean').read_text()
 assert oldchunk.replace(' RMBisim RMOffsetBisim',' RMBisim').replace('allO','allC')==newchunk

def decode(n,fuel):
 acc=[]
 for _ in range(fuel):
  if n<=1:break
  acc.append(n%2==1);n//=2
 return acc[::-1]
wrong=[];maxlen=[0,0];lengths=[[],[]]
for i,(a,b,z,j,k) in enumerate(entries):
 assert z==0 and 0<=j<2240 and 0<=k<2240
 for side,n in enumerate([a,b]):
  assert n>=1
  bits=[c=='1' for c in bin(n)[3:]]
  assert decode(n,512)==bits
  assert int('1'+''.join('1' if x else '0' for x in bits),2)==n
  maxlen[side]=max(maxlen[side],len(bits));lengths[side].append(len(bits))
  if decode(n,128)!=bits:wrong.append({'entry':i,'side':side,'code':n,'length':len(bits)})
assert len(wrong)==622 and all(r['side']==1 for r in wrong) and max(maxlen)==176
p=wrong[0]
(P/'FuelControl.lean').write_text('''import BusyBeaver.ZFC.RMBisim
namespace SetTheory.BusyBeaver.ZFC.ZeroOffsetFuelAudit
open RMBisim
def decode215 (n : Nat) : List Bool := decodeAux 512 n []
-- A concrete preserved certificate pointer disproves use of the old decoder.
theorem fuel128_changes_pointer : decode '''+str(p['code'])+''' ≠ decode215 '''+str(p['code'])+''' := by decide +kernel
#print axioms fuel128_changes_pointer
end SetTheory.BusyBeaver.ZFC.ZeroOffsetFuelAudit
''')
res={'status':'PASS','old_data':{'path':str(R/L/'KSource215Data.lean'),'sha256':sha(R/L/'KSource215Data.lean')},'new_data':{'path':str(N/L/'KSource215Data.lean'),'sha256':sha(N/L/'KSource215Data.lean')},'entries':2240,'parts':shapes,'all_offsets_zero':True,'exact_tree_erasure':True,'branch_cuts_successor_indices_sentinel_codes_unchanged':True,'shared_declarations_byte_exact':shared,'public_endpoint_statement_exact':True,'path_iff_iter_exact':True,'all16_chunk_proof_bodies_only_allO_to_allC_and_namespace':True,'all512_decodes_match_full_sentinel_bits':True,'longest_paths_by_side':maxlen,'fuel128_mismatches':len(wrong),'fuel128_witness':p,'scope':'Independent literal parsing and finite arithmetic only; no generated proof or checker executed by this parser.'}
(P/'comparison.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
