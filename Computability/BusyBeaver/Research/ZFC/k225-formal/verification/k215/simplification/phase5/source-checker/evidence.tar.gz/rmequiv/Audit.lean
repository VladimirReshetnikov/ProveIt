import BusyBeaver.ZFC.RMBisim

namespace SetTheory.BusyBeaver.ZFC.RMEquivAudit

open RMDag
open RegisterPath (Halts)

theorem fwd_client {p : Prog} {nn : Nat} (W : RMEquiv.WF p nn)
    {e : Edge} {R : Regs} {x : Exit} {R' : Regs} (h : Run p e R x R') :
    ∀ Q P, RMEquiv.fol p (.node p.root) Q = some e → RMEquiv.ipeq P Q →
      RMEquiv.Reaches p nn ⟨P, R⟩ Q x R' :=
  RMEquiv.fwd W h

theorem halts_client {p : Prog} {nn : Nat} (W : RMEquiv.WF p nn) (R : Regs) :
    Halts (RMEquiv.ofDag p nn) ⟨[], R⟩ ↔ IterHalts p R :=
  RMEquiv.halts_iff_iterHalts W R

theorem checked_bisim_client {p1 p2 : RegisterPath.Program} {T : RMBisim.CTree}
    (hs : RMBisim.branchOk (RMBisim.ptree p1) (RMBisim.ptree p2) T [] [] 0 = true)
    (ha : RMBisim.allC (RMBisim.entryOk (RMBisim.ptree p1) (RMBisim.ptree p2) T) T = true)
    (R : RegisterPath.Registers) :
    Halts p1 ⟨[], R⟩ ↔ Halts p2 ⟨[], R⟩ :=
  RMBisim.check_halts_iff hs ha R

#print axioms fwd_client
#print axioms halts_client
#print axioms checked_bisim_client

end SetTheory.BusyBeaver.ZFC.RMEquivAudit
