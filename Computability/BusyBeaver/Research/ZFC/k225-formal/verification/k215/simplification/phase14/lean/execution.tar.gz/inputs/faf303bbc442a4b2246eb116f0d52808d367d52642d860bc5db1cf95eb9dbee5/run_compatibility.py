"""Authorized exact compatibility invocation after primary and final-map peers."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
S=Path('/tmp/k215-phase14-retry');R=Path('/tmp/k215-phase14-check');E=Path(__file__).resolve().parent;REPO=Path('/home/codex/.codex/worktrees/ec20/Proofs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
assert sha(S/'compatibility-final-map.json')=='c25f8c86ea110fa37797c354e8d213c304a5cc6c7cfb75606d6d6f843f955cad'
peer=Path('/tmp/k215-phase14-runner-peer/primary-actual-and-final-map-review.json');assert sha(peer)=='fc2c5d7065bbbc564a8bc77e714b3b752bdf1fca7244d6b6b4c4d93c178c8886'
def unchanged():return all(sha(root/p)==h for root in [R,S]for p,h in read(root/'freeze.json')['files'].items())
assert unchanged()and not(R/'compatibility-run1').exists()
argv=read(S/'commands.json')['compatibility'];out=E/'compatibility-run1.stdout';err=E/'compatibility-run1.stderr';record=E/'compatibility-run1-outer.json';assert all(not p.exists()for p in [out,err,record])
rec={'status':'RUNNING','argv':argv,'cwd':str(REPO),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_sha256':sha(__file__),'final_map_sha256':sha(S/'compatibility-final-map.json'),'primary_map_peer_sha256':sha(peer),'primary_result_sha256':sha(R/'primary-run2/result.json'),'stdout':str(out),'stderr':str(err)}
record.write_text(json.dumps(rec,indent=2)+'\n');start=time.monotonic();proc=None
try:
 with out.open('wb')as stdout,err.open('wb')as stderr:
  proc=subprocess.Popen(argv,cwd=REPO,stdout=stdout,stderr=stderr,start_new_session=True);rec['pid']=proc.pid;record.write_text(json.dumps(rec,indent=2)+'\n');code=proc.wait()
 rec.update(status='PASS_OUTER_EXIT_ZERO'if code==0 else'FAIL_OUTER_EXIT',exit_code=code)
except BaseException as exc:
 if proc is not None and proc.poll()is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 rec.update(status='OUTER_EXCEPTION',exception=repr(exc),exit_code=None if proc is None else proc.returncode);raise
finally:
 rec.update(seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err),frozen_files_unchanged=unchanged());record.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2),flush=True)
assert rec['exit_code']==0 and rec['frozen_files_unchanged']
