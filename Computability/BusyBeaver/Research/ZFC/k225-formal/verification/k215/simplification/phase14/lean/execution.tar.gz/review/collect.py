"""Capture completed phase14 records; no compiler, producer or archive code runs."""
from pathlib import Path
from contextlib import ExitStack
import argparse, fcntl, gzip, io, json, tarfile
import basis, packet
S = Path(__file__).resolve().parent
read = lambda p: json.loads(Path(p).read_text())

def collect(repo, out):
 assert not out.exists() and not out.is_symlink()
 freeze = read(S/'freeze.json')
 assert freeze['status'] == 'FROZEN_PUBLICATION_HELPERS_NOT_EXECUTED'
 for name, pin in freeze['files'].items(): assert packet.sha(S/name) == pin
 cfg = read(S/'config.json'); assert cfg['status'] == 'FROZEN_COMPLETED_PHASE14_INPUTS'
 with ExitStack() as stack:
  for root in [packet.FIRST, packet.MAIN, packet.COMP]:
   lock = stack.enter_context((Path(root)/'output.lock').open('a')); fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
  loaded = basis.load(repo); prior, _, _ = loaded; members, routes, hashes = {}, {}, {}
  for key, data in prior.items(): hashes.setdefault(packet.digest(data), ('phase13', key))
  def put(name, data):
   packet.safe(name)
   if name in members: assert members[name] == data
   members[name] = data; hashes.setdefault(packet.digest(data), ('packet', name))
  def add(path, data=None, name=None, force=False):
   path = str(path); data = Path(path).read_bytes() if data is None else data; pin = packet.digest(data)
   if path in routes: assert routes[path]['sha256'] == pin; return
   if force or pin not in hashes:
    key = name or 'inputs/'+pin+'/'+Path(path).name; put(key, data); storage = 'packet'
   else: storage, key = hashes[pin]
   routes[path] = {'storage': storage, 'key': key, 'sha256': pin, 'bytes': len(data)}
  for path, row in cfg['historical_inputs'].items():
   assert packet.sha(row['snapshot']) == row['sha256']; add(path, Path(row['snapshot']).read_bytes()); add(row['snapshot'])
  tool = read(Path(packet.MAIN)/'toolchain.json')
  binary = {v['path']: v['sha256'] for k, v in tool.items() if k in {'lean', 'lake', 'Init.olean'}}
  for root in [packet.OLD, packet.BASE, packet.BASE_COMP, packet.MAIN, packet.COMP]:
   binary.update({root+'/objects/'+m.replace('.', '/')+'.olean': r['object_sha256'] for m, r in read(Path(root)/'completed.json').items()})
  # Failed run1 remains raw history; only its189 successful records are resumed.
  first = Path(packet.FIRST)
  assert not (first/'result.json').exists()
  for name in ['before.json','inventory.json','completed.json','toolchain.json']:
   add(first/name, name='failed-primary/'+name, force=True)
  for path,pin in read(first/'before.json')['inputs'].items():
   if path in binary: assert binary[path]==pin; continue
   if path not in cfg['historical_inputs']: add(path)
   assert routes[path]['sha256']==pin
  for row in read(first/'inventory.json')['modules']: add(row['source'])
  for rec in read(first/'completed.json').values():
   add(rec['log'])
   if rec['origin']=='candidate_fresh': add(rec['source'])
  for attempt in sorted((first/'attempts').iterdir()):
   assert attempt.is_dir() and not attempt.is_symlink()
   for path in sorted(attempt.iterdir()):
    assert path.is_file() and not path.is_symlink(); packet.safe(path.name)
    add(path, name='failed-primary/attempts/'+attempt.name+'/'+path.name)
  add(first/'workspace/ProfileTC14Api.lean')
  for root, label in [(Path(packet.MAIN), 'execution'), (Path(packet.COMP), 'compatibility')]:
   result = read(root/'result.json'); assert result['status'] == 'PASS' and packet.sha(root/'result.json') == cfg['results'][str(root)]
   for name in ['result.json', 'before.json', 'inventory.json', 'completed.json', 'toolchain.json']: add(root/name, name=label+'/'+name, force=True)
   inv = read(root/'inventory.json'); done = read(root/'completed.json'); before = read(root/'before.json')
   for path, pin in before['inputs'].items():
    if path in binary: assert binary[path] == pin; continue
    if path not in cfg['historical_inputs']: add(path)
    assert routes[path]['sha256'] == pin, path
   for row in inv['modules']:
    m = row['module']; rec = done[m]; add(row['source']); add(rec['log'])
    if rec['origin'] == 'candidate_fresh':
     add(rec['source'], name=label+'/fresh/'+m+'/source.lean', force=True)
     add(Path(rec['log']).parent/'record.json', name=label+'/fresh/'+m+'/record.json', force=True)
     add(Path(rec['log']).parent/Path(rec['source']).name)
   # Every actual attempt is retained, including any failure preceding the selected record.
   for attempt in sorted((root/'attempts').iterdir()):
    assert attempt.is_dir() and not attempt.is_symlink()
    for path in sorted(attempt.iterdir()):
     assert path.is_file() and not path.is_symlink(); packet.safe(path.name)
     add(path, name=label+'/attempts/'+attempt.name+'/'+path.name)
   for rec in result['audits']:
    q = root/('audit-'+rec['module'])
    for name in [rec['module']+'.lean', rec['module']+'.log', rec['module']+'.json']: add(q/name, name=label+'/audits/'+name, force=True)
    add(rec['source'])
  for path, row in cfg['files'].items():
   data = Path(path).read_bytes(); assert packet.digest(data) == row['sha256'] and len(data) == row['bytes']
   add(path, data)
  for row in cfg['adoption']['files']:
   add(repo/row['before_snapshot'])
   if row['action'] == 'replace':
    data = Path(row['candidate']).read_bytes()
    assert packet.digest(data) == row['after_sha256'] and data == (repo/row['path']).read_bytes()
    add(row['candidate'], data); put('adoption/'+row['path'], data)
   else:
    assert row['action'] == 'retire'; packet.absent(repo/row['path'])
  for name in packet.HELPERS + ['config.json', 'freeze.json', 'controls-result.json', 'controls.stdout.log', 'controls.stderr.log']:
   put('review/'+name, (S/name).read_bytes())
  put('path-map.json', packet.dump(routes))
  checked = packet.validate(members, repo, loaded, current_repo=repo)
  # Rehash every actual dependency after validation. The two retired canonical
  # compilation inputs use their exact before snapshots; current absence is separate.
  before_count, providers = {}, {}
  for root in [Path(packet.MAIN), Path(packet.COMP)]:
   before = read(root/'before.json'); done = read(root/'completed.json'); inv = read(root/'inventory.json')
   for path, pin in before['inputs'].items():
    current = cfg['historical_inputs'].get(path, {}).get('snapshot', path)
    assert packet.sha(current) == pin, path
   for path in before['absent_inputs']: packet.absent(path)
   before_count[str(root)] = len(before['inputs']); providers[str(root)] = len(done)
   for row in inv['modules']:
    rec = done[row['module']]; obj = root/'objects'/(row['module'].replace('.', '/')+'.olean')
    assert packet.sha(row['source']) == row['source_sha256'] and packet.sha(rec['log']) == rec['log_sha256'] and packet.sha(obj) == rec['object_sha256']
    assert rec['dependencies'] == {d: done[d]['object_sha256'] for d in row['imports'] if d != 'Init'}
    if rec['origin'] == 'candidate_fresh':
     assert packet.sha(rec['source']) == row['source_sha256']
     if str(root)==packet.MAIN and row['module']!='ProfileTC14Api':
      assert obj.is_symlink() and obj.readlink()==Path(packet.FIRST)/'objects'/(row['module'].replace('.', '/')+'.olean')
     else: assert not obj.is_symlink()
    else: assert obj.is_symlink()
    for parent in obj.parents:
     assert not parent.is_symlink()
     if parent == root/'objects': break
   for rec in read(root/'result.json')['audits']:
    q = root/('audit-'+rec['module'])
    assert packet.sha(q/(rec['module']+'.olean')) == rec['object_sha256'] and packet.sha(q/(rec['module']+'.lean')) == rec['source_sha256']
    assert packet.sha(rec['source']) == rec['source_sha256'] and packet.sha(rec['log']) == rec['log_sha256']
    packet.named_reports(Path(rec['log']).read_bytes(), packet.AUDIT_NAMES[rec['module']])
  for path,pin in read(first/'before.json')['inputs'].items():
   assert packet.sha(cfg['historical_inputs'].get(path,{}).get('snapshot',path))==pin
  for path in read(first/'before.json')['absent_inputs']: packet.absent(path)
  assert not (first/'result.json').exists()
  before_count[packet.FIRST]=len(read(first/'before.json')['inputs'])
  for path, row in cfg['files'].items(): assert packet.sha(path) == row['sha256'] and Path(path).stat().st_size == row['bytes']
  for row in cfg['adoption']['files']:
   assert packet.sha(repo/row['before_snapshot']) == row['before_sha256']
   if row['action'] == 'replace': assert packet.sha(repo/row['path']) == row['after_sha256']
   else: packet.absent(repo/row['path'])
  for path,pin in packet.PRIOR_ADOPTIONS.items(): assert packet.sha(repo/path) == pin
  for root in [Path(packet.MAIN),Path(packet.COMP)]: packet.absent(root/'objects/BusyBeaver/ZFC/KProfileTC.olean')
  for name, pin in freeze['files'].items(): assert packet.sha(S/name) == pin
  assert members['review/config.json'] == (S/'config.json').read_bytes()
  post = {'status': 'PASS_LIVE_POSTCHECK', 'providers': providers, 'before_input_counts': before_count, 'combined_project_sources': 198, 'endpoint_audit_objects': 2, 'original_failed_primary_preserved': True, 'resumed_providers': 189, 'new_retry_compiler_calls': 3, 'all_live_sources_objects_logs_dependencies_rehashed': True, 'historical_inputs': cfg['historical_inputs'], 'current_adoptions': packet.ADOPTIONS, 'retirements': packet.RETIRED, 'unchanged_prior_adoptions': packet.PRIOR_ADOPTIONS, 'absence_gates': 4, 'scope': 'Exact live providers and complete before inputs rehashed after validation. Two retired canonical inputs are checked from explicit immutable before snapshots, separately from their current absence. Seven adopted Lean files and the five unchanged phase13 adoptions are checked exactly. No ancestor objects are packed.'}
  put('review/live-postcheck.json', packet.dump(post)); index = packet.manifest(members); out.mkdir(parents=True)
  with (out/'execution.tar.gz').open('wb') as raw:
   with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as archive:
     for name, data in sorted(members.items()):
      info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0; archive.addfile(info, io.BytesIO(data))
  (out/'index.json').write_bytes(packet.dump(index))
  summary = {**checked, 'status': 'PASS_COLLECTED_PHASE14', 'archive_sha256': packet.sha(out/'execution.tar.gz'), 'archive_members': len(members), 'index_sha256': packet.sha(out/'index.json'), 'live_postcheck': post}
  (out/'result.json').write_bytes(packet.dump(summary))
  for name in ['basis.py', 'basis-reference.json', 'packet.py', 'review_saved.py', 'README.md']: (out/name).write_bytes((S/name).read_bytes())
  print(json.dumps(summary, indent=2))

if __name__ == '__main__':
 parser = argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--basis-repo', type=Path, required=True); parser.add_argument('--out', type=Path, required=True)
 args = parser.parse_args(); collect(args.basis_repo, args.out)
