# Bounded alternative-schema selection

No smaller proof was found. The best remains **674 proof nodes / 780 Rocq interpreter instructions**, with 994 retained input terms. This is proof-production research, not a new kernel check or a minimum-size theorem. Canonical sources were not modified.

The original 3,728-node certificate is the tracked `k225-formal/lean217/dominated_rho8_full_certificate.json`, SHA-256 `3cf18a5fe9f187b50b79d97b84535ce9bf776305728b0cdfe17285e94f028452`. Each script independently reconstructs the accepted first-match baseline, permits retaining each original rule, enforces earlier parent IDs, and rechecks every selected replacement substitution before emitting the root dependency closure.

| Run | Family and completed scope | Time | Best |
| --- | --- | ---: | ---: |
| 1 | All earlier strict syntactic schema instances, including all baseline patterns; 3,244,019 additional tests and 1,904 additional matches. Expansion completed through node 3727. | 16.767 s | 674 / 780 |
| 2 | Additional normalized instances using `Imp(T,T)=T`; 4,486,510 additional tests and 1,525 additional matches. Expansion reached node 2995 before the bound. | 23.802 s | 674 / 780 |

Local ancestor-closure heuristics made sharing worse: the node-cost policy retained 1,190 nodes, while instruction-weighted local choice retained 2,807. Reweighting toward the current best root closure recovered the baseline. Strictly improving single-rule changes on the retained root graph found no reduction in either run. This does not cover interacting changes, equal-cost plateaus, or temporarily larger intermediate graphs; run 2 also has an explicitly incomplete parent expansion.

The most useful next algorithmic direction is global DAG-sharing-aware rule selection: jointly change several dependencies, or explore equal-cost alternatives before another pruning pass. Local proof length is a poor objective because a slightly longer subproof may share most of its support with the final theorem. Such an optimizer would still be untrusted and any resulting certificate must be kernel checked.

Reproduction (fresh destination required; no compiler):

```sh
python3 /tmp/k215-proof-concision-search/search.py --output /tmp/proof-concision-fresh1 --seconds 28
python3 /tmp/k215-proof-concision-search/search_zero_alias.py --output /tmp/proof-concision-fresh2 --seconds 28
```

Both emitted candidate files have the same SHA-256 `88da35008387d3592edabf17a33b8068723077a77dd48f18ceb42b164f455eaf`. They remain untrusted copies; the accepted canonical proof retains its independently checked certificate. `summary.json` pins both scripts and exact outputs. The scripts use the current workspace input path explicitly and report wall-limited completion, so timing and the incomplete run-2 expansion may vary across machines.
