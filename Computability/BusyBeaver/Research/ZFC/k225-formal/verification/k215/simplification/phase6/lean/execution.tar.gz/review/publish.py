"""Stage completed phase-six evidence after a matching live post-audit review.

Writes a fresh scratch directory. No compiler or archived runner is invoked.
"""
from pathlib import Path
import argparse
import gzip
import io
import json
import tarfile
from capture import arguments, collect
from evidence import digest, manifest, manifest_hash, save, sha, validate
import basis_reference


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    arguments(parser)
    parser.add_argument('--live-review', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists(), 'Refusing to overwrite a packet'
    members = collect(args)
    live_bytes = args.live_review.read_bytes()
    live = json.loads(live_bytes)
    assert live['status'] == 'PASS_LIVE_POST_AUDIT_REVIEW'
    assert live['evidence_manifest_sha256'] == manifest_hash(members)
    checked = validate(members, basis_repo=args.basis_repo or Path(json.loads(members['execution/owner.json'])['repo']))
    assert all(live[k] == v for k, v in checked.items())
    assert live['all187_objects_rehashed_after_audits']
    assert live['all184_basis_objects_and_logs_unchanged']
    assert live['current_inventory_exact'] and live['toolchain_and_compiler_rehashed']
    assert live['basis_reference_sha256'] == basis_reference.REFERENCE_SHA256
    assert live['run'] == str(args.run.resolve()) and live['basis'] == str(args.basis.resolve())
    assert digest(members['review/review.py']) == live['reviewer_sha256']
    assert digest(members['review/evidence.py']) == live['validator_sha256']
    assert digest(members['review/capture.py']) == live['capture_sha256']
    members['review/live-review.json'] = live_bytes
    index = manifest(members)
    out = args.out.resolve()
    out.mkdir()
    with (out / 'execution.tar.gz').open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for name, data in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
    save(out / 'index.json', index)
    result = json.loads(members['execution/result.json'])
    summary = {**result, 'project_warnings': checked['project_warnings'], 'audit_warnings': 0,
               'archive_members': len(index), 'execution_archive_sha256': sha(out / 'execution.tar.gz'),
               'live_review_sha256': digest(live_bytes), 'compiled_objects_in_archive': False,
               'basis_reference_sha256': basis_reference.REFERENCE_SHA256,
               'source_checkpoint_scope': '187 exact source snapshots and184 basis ledgers/logs; '
                                          'published phase5 ancestry is referenced by immutable relative pins.'}
    save(out / 'result.json', summary)
    (out / 'live-review.json').write_bytes(live_bytes)
    for name in ('review_saved.py', 'evidence.py', 'basis_reference.py', 'basis-reference.json'):
        (out / name).write_bytes(members['review/' + name])
    (out / 'README.md').write_text(f'''# Lean phase-six proof simplification

The exact 215-state endpoint passed the complete187-module project closure, with only Lean's shipped `Init` boundary. This checkpoint freshly compiled {result['fresh_modules']} modules and reused {result['reused_modules']} immutable phase5 objects after source, direct-dependency, object and selected-log hash checks. It is an incremental closure check, not a fresh compilation of every module.

Both unchanged typed clients passed: `EndpointAudit215` has two named reports and `K215Audit` eight. Reports use only standard Lean axioms (`propext`, `Classical.choice`, `Quot.sound`), with zero audit warnings. Selected project logs contain {checked['project_warnings']} linter warnings. The live reader rechecked all187 current providers and all184 phase5 basis objects/logs after checking both audit objects.

The three added modules are the decoder-parametric normalized checker, stable program data, and fast-table site adapter. The21 adopted files and16 regenerated unchanged chunk files are bound to the complete source inventory. Original prospective adoption status is retained without rewriting its chronology. The exact machine, program and endpoint statements are preserved. Isolated generic/seed attempts, original prototypes, producer controls, mathematical peers and full source comparisons remain in the sibling [proof-source packet](../proof-sources/README.md); their limited scopes are distinct from this completed closure check.

[result.json](result.json), [live-review.json](live-review.json) and [index.json](index.json) bind `execution.tar.gz`. It retains all187 source snapshots, source/import/dependency/object-hash ledgers, every fresh attempt's original source/record/raw log, both audit clients, original runners, all184 basis log identities,21-file adoption metadata and four producer versions before/after. Any nonselected historical attempt remains separate. Compiled objects are excluded.

The predecessor [phase5 packet](../../phase5/lean/README.md) is required locally. [basis-reference.json](basis-reference.json) pins its repository-relative location, archive/index/summary/live receipt, and three trusted validator source files. The reader verifies those exact files and uses the local pinned validators to check their unchanged nested ancestry. No archived Python is executed, and no predecessor archive is copied into this one. Historical phase5 outer-wrapper exit143 remains in its original separate observation; this packet does not rewrite that telemetry. Toolchain metadata retains its original description, while the present inventory establishes187 project modules.

From this maintained repository, run:

```sh
python3 review_saved.py --output /tmp/k215-phase6-saved-review.json
```

For a packet copied elsewhere, supply `--basis-repo /path/to/Proofs`. Optional `--repo /path/to/Proofs` additionally checks all current checkpoint sources, adoption/producers and machine pins; it can also locate the predecessor. Historical review does not require current sources to remain unchanged. Neither mode inspects live compiled objects. The archived `review/review.py` performs that separate read-only audit when the original caches remain available. No saved reader invokes Lean. The [maintained fresh build](../../../lean/README.md) is the full rebuild route; original executed scripts retain historical scratch paths.
''')
    print(json.dumps({'status': 'STAGED_SAVED_PACKET', 'path': str(out), 'members': len(index),
                      'archive_bytes': (out / 'execution.tar.gz').stat().st_size,
                      'summary_sha256': sha(out / 'result.json')}, indent=2))


if __name__ == '__main__':
    main()
