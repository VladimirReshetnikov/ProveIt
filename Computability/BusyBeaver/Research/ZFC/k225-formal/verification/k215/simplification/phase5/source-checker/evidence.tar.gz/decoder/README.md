# Decoder-parametric segment certificates

The scratch `RMBisim.lean` moves the ordinary checker and its soundness proof
into `RMBisim.WithDecoder`. Every definition/theorem there takes an explicit
first argument `d : Nat → List Bool`. A certificate denotes exactly the path
pairs returned by that function, so soundness needs no decoding-size bound,
injectivity, or other property of `d`.

The shared program semantics, segment lemmas, certificate tree, lookup, count
checks, and original `decodeAux`/128-fuel `decode` are unchanged. Existing checker
names are aliases using `decode`; all four original soundness statements remain
exact, with one-line wrappers. There is one generic checker proof, not separate
128- and 512-fuel proofs. The module grows from 544 to 578 lines for the generic
API and compatibility wrappers.

For K215, use `fun n => RMBisim.decodeAux 512 n []`, for example:

```lean
RMBisim.WithDecoder.check_halts_iff decode215 hs ha R
```

This work implements the generic-decoder recommendation in Source proposal
`proof_refactor/ZERO_OFFSET_STAGE.md`, read from
`docs/incoming/Proof_Simplification_and_GC-ZC215_2026-10-21.zip` without executing
its code. The proposal identifies why merely keeping the old128 decoder would
change long path meanings. Root owns certificate erasure, regeneration and fresh
four-field checks; none is claimed here.

`run2/result.json` records fresh kernel checks of the earlier RMEquiv forward
proof refactor, this RMBisim module, and `Audit.lean` (3.371, 2.319 and 0.465
seconds; zero warnings). The audit checks five literal old definitions by `rfl`,
all four old public soundness signatures, and arbitrary-decoder/512 endpoint
clients. All three assumption reports are exactly `[propext, Quot.sound]`.
`comparison.json` binds the sources and statement-preservation checks.

Dependencies are immutable phase4 objects linked read-only into private caches.
Targets are unlinked before fresh output is written. The reviewed supervisor
uses the common lock, one worker, 120-second caps and 12 GiB limits. All recorded
basis/source/toolchain hashes were rechecked. No canonical source changed and no
fresh full-closure check is claimed. The first run's parser failure from a
namespace documentation comment is retained; the successor changes that comment
from declaration-doc syntax to module-doc syntax.

Reproduce using a fresh output name:

```sh
python3 -B /tmp/k215-rmbisim-decoder/check.py NEW_OUTPUT RMEquiv RMBisim
```

The exact source patch is `source.diff`; producer `prepare.py`, original source,
failed run1 and final run2 remain alongside the candidate. Do not rerun the
producer against a changed canonical input without preserving this packet.
