"""Capture exact nonbinary legacy records; no compiler, no ancestor payload copy."""
from pathlib import Path
import json
from evidence import sha,digest,read,safe
HERE=Path(__file__).resolve().parent
FORMAL='Computability/BusyBeaver/Research/ZFC/k225-formal/verification/k215/simplification'
HELPERS=['evidence.py','capture.py','review.py','publish.py','review_saved.py','README.template.md','controls.py','controls-result.json','controls.stdout.log','controls.stderr.log']
def args(p):
 p.add_argument('--run',type=Path,required=True);p.add_argument('--preparation',type=Path,required=True);p.add_argument('--repo',type=Path,required=True);p.add_argument('--stdout',type=Path,required=True)
def collect(run,preparation,repo,stdout):
 run,preparation,repo=run.resolve(),preparation.resolve(),repo.resolve();assert read(run/'result.json')['status']=='PASS';m={}
 def add(name,path):
  assert safe(name)and name not in m and path.is_file()and not path.is_symlink();m[name]=path.read_bytes()
 for path in sorted(run.rglob('*')):
  rel=path.relative_to(run)
  if 'objects'in rel.parts or path.name=='output.lock':continue
  assert not path.is_symlink()
  if path.is_file()and safe(rel.as_posix()):add('execution/'+rel.as_posix(),path)
 # Preserve all prepared gates, controls and historical attempts, but never collect a future run/cache recursively.
 names=['build.py','gates.py','LegacyAudit.lean','prepared-inventory.json','preparation.json','basis-reference.json','freeze.json','prepare.py','README.md','actual-plan.json','controls.py','controls-result.json','controls.stdout.log','controls.stderr.log','prepare.stdout.log','prepare.stderr.log']
 for n in names:add('preparation/'+n,preparation/n)
 for path in sorted((preparation/'history').rglob('*')):
  if path.is_file():add('preparation/history/'+path.relative_to(preparation/'history').as_posix(),path)
 peer=Path('/tmp/k215-phase7-legacy-driver-peer')
 for path in sorted(peer.iterdir()):
  if path.is_file()and safe(path.name):add('review/driver-peer/'+path.name,path)
 for n in ['root-actual-review.json','root_review.py','outer-execution-observation.json']:
  if(preparation/n).is_file():add('review/root/'+n,preparation/n)
 for n in HELPERS:add('review/'+n,HERE/n)
 add('review/driver.stdout',stdout)
 refs={}
 for tag,sub in [('phase7_primary','phase7/lean'),('phase5_legacy','phase5/legacy')]:
  packet=repo/FORMAL/sub;names=['execution.tar.gz','index.json','result.json','live-review.json']
  refs[tag]={'repository_relative_directory':(Path(FORMAL)/sub).as_posix(),'files':{n:{'sha256':sha(packet/n),'bytes':(packet/n).stat().st_size}for n in names}}
 m['publication/references.json']=(json.dumps(refs,indent=2)+'\n').encode()
 return m
