#!/usr/bin/env python3
from pathlib import Path
import os,sys,time,subprocess
root=Path('/tmp/k215-rocq-complete'); install_pid=3739475
while True:
    try:os.kill(install_pid,0)
    except ProcessLookupError:break
    time.sleep(5)
version=subprocess.check_output(['opam','list','--switch=proofs-rocq91','--installed','--short','--columns=version','--color=never','rocq-stdlib'],text=True).strip()
if version!='9.0.0':raise SystemExit('Exact stdlib installation did not complete: '+repr(version))
os.execv(sys.executable,[sys.executable,'-B',str(root/'build_serial.py'),'--kernel'])
