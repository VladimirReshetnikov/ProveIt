#!/usr/bin/env python3
"""Replay all arbitrary-register unary/list-inductive U209 runtime contracts.

The two induction-engine modules are preserved byte-for-byte from the frozen
U211 Contextual package. This is executable mathematical verification, not a
proof-assistant kernel or an exported PA proof object.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'checks' / 'runtime'))
import symbolic_runtime as engine
import source_language as source

PINS = {
    'symbolic_runtime.py':
        '61b9c66272e8fd149829177cc384013814aea3c6b3b6b6f48e462d3913ea2022',
    'independent_runtime.py':
        'd490397a2b31be4f7f62461a3d9bcd88faf9093de904e43eea1b865561e7b7ee',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_table(path):
    table, starts = {}, []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        q, bit, write, direction, target = line.split()
        q, bit, write, target = map(int, (q, bit, write, target))
        require((q, bit) not in table, 'Duplicate transition')
        require(bit in (0, 1) and write in (0, 1), 'Binary alphabet')
        require(direction in ('L', 'R'), 'Head movement')
        table[q, bit] = write, 1 if direction == 'R' else -1, target
    states = {q for q, bit in table}
    require(starts == [0] and 0 in states and 254 not in states, 'Start/halt')
    require(len(states) == 209 and len(table) == 418, 'Working-state census')
    require(set(table) == {(q, bit) for q in states for bit in (0, 1)},
            'Total transition function')
    require({z for w, d, z in table.values()} - states == {254}, 'Target closure')
    return table


def check(output, compare_saved=True):
    require(__debug__ and not sys.flags.optimize,
            'Run without -O or PYTHONOPTIMIZE: the induction engine uses assertions')
    for name, expected in PINS.items():
        require(digest(ROOT / 'checks' / 'runtime' / name) == expected,
                'Induction engine differs: ' + name)
    table_path = ROOT / 'machine' / 'u209.native.tm'
    source_path = ROOT / 'machine' / 'sites.json'
    table = read_table(table_path)
    rows = json.loads(source_path.read_text())
    root = source.tree(rows)
    metrics = source.metrics(root)
    require(metrics['leaf_occurrences'] == 3909, 'Source occurrence census')
    require(metrics['maximum_zero_run'] <= 6, 'Origin-detector source condition')
    require(source.graph_intervals(rows) == source.graph_arithmetic(rows)[0],
            'Source successor algorithms disagree')
    mapping = {int(k): int(v) for k, v in json.loads(
        (ROOT / 'inputs' / 'legacy_mapping.json').read_text()).items()}
    states = {q for q, bit in table} | {254}
    for q in states:
        mapping.setdefault(q, q + 1000)
    require(len({mapping[q] for q in states}) == 210, 'Noninjective legacy renaming')
    literal = {(mapping[q], bit): (w, d, mapping[z])
               for (q, bit), (w, d, z) in table.items()}
    require(engine.HEADER_BASE == 56 and
            engine.r.PHY == (6, 2, 0, 4, 3, 7, 8, 5, 1), 'Canonical frame')
    began = time.monotonic()
    lemmas, blocks = engine.prove_blocks(literal)
    cases, used = [], set()
    for ordinal, site in enumerate(rows):
        for positive in ((False, True) if site[1] == 'CD' else (False,)):
            answer = engine.case(literal, lemmas, site, positive)
            used.update(answer['rows'])
            answer['rows'] = sorted(answer['rows'])
            answer.pop('trace')
            cases.append(dict(site_index=ordinal, positive=positive, **answer))
        if (ordinal + 1) % 500 == 0:
            print('Reproved', len(cases), 'guarded contracts', flush=True)
    for block in blocks:
        for event in block['trace']:
            used.add(tuple(event[1][:2]))
    require(len(cases) == 5084 and used == set(literal),
            'Incomplete source-case or literal-row coverage')
    require(all(len(case['duration']) == 13 and case['duration'][0] > 0 and
                all(value >= 0 for value in case['duration']) for case in cases),
            'Nonpositive or invalid affine duration')
    cases = json.loads(json.dumps(cases))
    if compare_saved:
        with gzip.open(ROOT / 'evidence' / 'runtime_cases.json.gz', 'rt') as stream:
            require(cases == json.load(stream), 'Fresh and saved derivations differ')
    result = dict(
        status='UNIVERSAL_MATHEMATICAL_PASS', states=209, rows=418,
        cases=len(cases), row_coverage=len(used), header_distance=56,
        symbolic_steps=sum(case['symbolic_steps'] for case in cases),
        minimum_duration_constant=min(case['duration'][0] for case in cases),
        table_sha256=digest(table_path), source_sha256=digest(source_path),
        checker_sha256=PINS, blocks=blocks, seconds=time.monotonic() - began,
        scope='All natural registers/gap and all nonempty finite spare lists; '
              'ordinary unary/list induction; not a proof-assistant kernel.')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    (output / 'runtime.json').write_text(json.dumps(result, indent=2) + '\n')
    with gzip.GzipFile(filename=str(output / 'runtime_cases.json.gz'),
                       mode='wb', mtime=0) as stream:
        stream.write((json.dumps(cases, separators=(',', ':')) + '\n').encode())
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'build' / 'runtime')
    parser.add_argument('--no-compare', action='store_true',
                        help='Recompute without comparing the retained case records')
    args = parser.parse_args()
    report = check(args.output, not args.no_compare)
    print(json.dumps({key: value for key, value in report.items() if key != 'blocks'},
                     indent=2))
