#!/usr/bin/env python3
"""Rebuild U209 from pinned U212 bytes and thirty closed tree rotations.

This is a deterministic certificate replayer, not a search program. The
universal runtime and independent local/startup checks are separate gates.
The tree utilities are inherited with their original attribution.
"""
import argparse
import hashlib
import json
from pathlib import Path

import source_language as L

ROOT = Path(__file__).resolve().parents[1]
PARENT_HASH = '386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
SOURCE_HASH = '7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'
NATIVE_HASH = '891455876f2684b2bd2a9118092715590028fbdb227aa7055030536714d8b7a4'
DENSE_HASH = '65ccb606c8e970adec22c311486e747b440171363601b8f11b56bc729cf8decb'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_table(path):
    table, starts = {}, []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        q, bit, write, direction, target = line.split()
        q, bit, write, target = map(int, (q, bit, write, target))
        need((q, bit) not in table, 'Duplicate transition')
        need(bit in (0, 1) and write in (0, 1), 'Nonbinary symbol')
        need(direction in ('L', 'R'), 'Nonmoving transition')
        table[q, bit] = write, direction, target
    need(starts == [0], 'Incorrect start convention')
    return table


def encode(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {d} {z}\n'
        for (q, b), (w, d, z) in sorted(table.items()))).encode('ascii')


def validate(table, count, halt):
    states = {q for q, bit in table}
    need(len(states) == count and len(table) == 2 * count, 'Wrong state count')
    need(set(table) == {(q, b) for q in states for b in (0, 1)}, 'Partial table')
    need(0 in states and halt not in states, 'Start/halt collision')
    need({z for w, d, z in table.values()} - states == {halt}, 'Target closure')
    seen, queue = {0}, [0]
    for q in queue:
        for bit in (0, 1):
            z = table[q, bit][2]
            if z != halt and z not in seen:
                seen.add(z)
                queue.append(z)
    need(seen == states, 'Unreachable working state in transition graph')
    return states


def occurrences(root, table, wanted):
    found = []

    def visit(node, state, path):
        if state == wanted:
            found.append((path, node))
            return
        if L.leaf(node):
            return
        for bit in (0, 1):
            w, d, z = table[state, bit]
            if (w, d) == (bit, 'R'):
                visit(node[bit], z, path + str(bit))

    visit(root, 84, '')
    return found


def leaf_count(node):
    return 1 if L.leaf(node) else leaf_count(node[0]) + leaf_count(node[1])


def rotate(table, root, record):
    p, q, side = record['outer'], record['inner'], record['side']
    places = occurrences(root, table, p)
    need(places and len({n for path, n in places}) == 1, 'Unbound outer decoder')
    need([path for path, node in places] == record['paths'], 'Rotation addresses')
    need(table[p, side] == (side, 'R', q), 'Incorrect rotation child')
    incoming = [(r, b, w, d) for (r, b), (w, d, z) in table.items() if z == q]
    need(incoming == [(p, side, side, 'R')], 'Inner decoder has another entry')
    need(all(table[s, b][:2] == (b, 'R') for s in (p, q) for b in (0, 1)),
         'Rotation touches a non-pure decoder')
    backward = [(r, b, w, d) for (r, b), (w, d, z) in table.items()
                if z == p and d == 'L']
    need(not backward or (p == 7 and backward == [(171, 0, 0, 'L')]),
         'Unrepaired arithmetic entry')
    node = places[0][1]
    if side == 0:
        A, B = node[0]
        C = node[1]
        replacement = A, (B, C)
        a, b, c = table[q, 0][2], table[q, 1][2], table[p, 1][2]
        table[p, 0], table[p, 1] = (0, 'R', a), (1, 'R', q)
        table[q, 0], table[q, 1] = (0, 'R', b), (1, 'R', c)
    else:
        A = node[0]
        B, C = node[1]
        replacement = (A, B), C
        a, b, c = table[p, 0][2], table[q, 0][2], table[q, 1][2]
        table[p, 0], table[p, 1] = (0, 'R', q), (1, 'R', c)
        table[q, 0], table[q, 1] = (0, 'R', a), (1, 'R', b)
    need([leaf_count(x) for x in (A, B, C)] == record['factor_sizes'],
         'Rotation factor sizes')
    need(all(L.boundary(x) == (0, 0, False) for x in (A, B, C)),
         'Rotation factor is not closed and nonhalting')
    for path, node in places:
        root = L.replace(root, path, replacement)
    return root, backward


def build(output):
    parent_path = ROOT / 'inputs/u212.native.tm'
    source_path = ROOT / 'inputs/u212.sites.json'
    need(sha(parent_path.read_bytes()) == PARENT_HASH, 'Parent table hash')
    need(sha(source_path.read_bytes()) == SOURCE_HASH, 'Parent source hash')
    table = read_table(parent_path)
    validate(table, 212, 254)
    parent = table.copy()
    old_rows = json.loads(source_path.read_text())
    old_word = [row[1:] for row in old_rows]
    graph = L.graph_intervals(old_rows)
    need(L.graph_arithmetic(old_rows)[0] == graph, 'Initial CFG disagreement')
    root = L.tree(old_rows)
    recipe = json.loads((ROOT / 'inputs/rotations.json').read_text())
    need(len(recipe) == 30, 'Thirty rotations required')
    stages = []
    for index, record in enumerate(recipe):
        root, backward = rotate(table, root, record)
        rows = L.sites(root)
        need([row[1:] for row in rows] == old_word, 'Primitive word changed')
        need(L.graph_intervals(rows) == graph, 'Interval CFG changed')
        need(L.graph_arithmetic(rows)[0] == graph, 'Arithmetic CFG changed')
        stages.append(dict(index=index + 1, **record, metrics=L.metrics(root),
                           backward_entries=backward))
    need(table[171, 0] == (0, 'L', 7), 'Engine entry before repair')
    table[171, 0] = 0, 'L', 205
    prefold = encode(table)
    validate(table, 212, 254)

    rho = lambda q: {180: 163, 181: 220, 218: 157}.get(q, q)
    table = {(q, b): (w, d, rho(z))
             for (q, b), (w, d, z) in table.items() if q not in (180, 181, 218)}
    table[163, 0] = 0, 'L', 211
    table[220, 0] = 0, 'L', 217
    states = validate(table, 209, 254)
    rename = {q: i for i, q in enumerate(sorted(states))}
    rename[254] = 209
    dense = {(rename[q], b): (w, d, rename[z])
             for (q, b), (w, d, z) in table.items()}
    validate(dense, 209, 209)
    native_raw, dense_raw = encode(table), encode(dense)
    need(sha(native_raw) == NATIVE_HASH, 'Final native hash')
    need(sha(dense_raw) == DENSE_HASH, 'Final dense hash')
    source_raw = L.compact(rows)
    metrics = L.metrics(root)
    need(metrics == dict(dag_nodes=197, leaf_occurrences=3909,
                         maximum_depth=42, maximum_zero_run=6), 'Final source bounds')
    need(rows[136] == old_rows[136], 'Startup continuation address changed')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    for name, raw in [('u209.native.tm', native_raw), ('u209.tm', dense_raw),
                      ('prefold212.native.tm', prefold), ('sites.json', source_raw)]:
        (output / name).write_bytes(raw)
    mapping = dict(native_to_dense=rename,
                   dense_to_native={v: k for k, v in rename.items()},
                   native_halt=254, dense_halt=209)
    (output / 'state_map.json').write_text(json.dumps(mapping, indent=2) + '\n')
    result = dict(status='EXACT_CONSTRUCTION_PASS', working_states=209, rows=418,
                  start=0, halt=209, native_halt=254, metrics=metrics,
                  rotations=stages, deleted_states=[180, 181, 218],
                  engine_repair=[171, 0, 0, 'L', 205],
                  changed_retained_rows=sum(parent[k] != v for k, v in table.items()),
                  changed_addresses=sum(a[0] != b[0] for a, b in zip(old_rows, rows)),
                  source_control_edges=sum(len(item[1]) for item in graph),
                  source_sha256=sha(source_raw), native_sha256=sha(native_raw),
                  dense_sha256=sha(dense_raw), prefold_sha256=sha(prefold),
                  parent_sha256=PARENT_HASH, parent_source_sha256=SOURCE_HASH,
                  scope='Construction and source CFG; literal runtime and local proof separate.')
    (output / 'construction.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = build(args.output)
    print(json.dumps({k: v for k, v in result.items() if k != 'rotations'}, indent=2))
