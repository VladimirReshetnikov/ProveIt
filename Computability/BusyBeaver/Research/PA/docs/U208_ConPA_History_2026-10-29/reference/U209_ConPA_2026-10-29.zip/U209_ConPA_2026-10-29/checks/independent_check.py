#!/usr/bin/env python3
"""Independent literal-table checks for the simultaneous U209 state fold.

Uses only the standard library. No builder, optimizer, source-language helper,
inductive-runtime engine, or saved PASS receipt is imported. Checks use explicit
exceptions, so running this program with Python -O does not disable them.
"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
NATIVE_HALT = 254
RHO = {180: 163, 181: 220, 218: 157}
SPECIAL = {163, 180, 181, 220, 218}
INCOMING = {
    163: [(214, 0, 0, 1)],
    180: [(132, 1, 1, 1), (199, 1, 1, 1)],
    181: [(185, 1, 1, 1)],
    220: [(204, 0, 0, 1)],
    218: [(158, 0, 0, 1), (211, 0, 0, 1), (216, 0, 0, 1), (220, 0, 0, 1)],
}
TAGS = {163: 0, 180: 1, 181: 1, 220: 0, 218: 0}
LENGTHS = {(163, 0): 5, (180, 0): 3, (181, 0): 3, (220, 0): 3,
           (218, 0): 3, (218, 1): 3}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rho(state):
    return RHO.get(state, state)


def load_table(path, count, halt):
    table, starts = {}, []
    for line in Path(path).read_text(encoding='ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        fields = line.split()
        need(len(fields) == 5, 'A transition must contain exactly five fields')
        q, b, w, direction, target = fields
        q, b, w, target = map(int, (q, b, w, target))
        need(q >= 0 and target >= 0 and b in (0, 1) and w in (0, 1), 'Invalid row')
        need(direction in ('L', 'R') and (q, b) not in table, 'Direction/duplicate row')
        table[q, b] = w, (-1 if direction == 'L' else 1), target
    states = {q for q, b in table}
    need(starts == [0] and len(states) == count and halt not in states, 'State census')
    need(set(table) == {(q, b) for q in states for b in (0, 1)}, 'Incomplete table')
    need({z for w, d, z in table.values()} - states == {halt}, 'Target closure')
    reachable, todo = {0}, [0]
    for q in todo:
        for b in (0, 1):
            z = table[q, b][2]
            if z != halt and z not in reachable:
                reachable.add(z)
                todo.append(z)
    need(reachable == states, 'A counted working state is graph-unreachable')
    return table


def local_run(table, state, cells, steps):
    tape, head, trace = dict(cells), 0, []
    for _ in range(steps):
        need(state != NATIVE_HALT, 'Internal halting transition')
        need(head in tape, 'A local certificate read unspecified exterior tape')
        bit = tape[head]
        w, d, z = table[state, bit]
        trace.append([state, head, bit, w, d, z])
        tape[head] = w
        state, head = z, head + d
    return (state, head, tape), trace


def fold_premises(old, child):
    need(set(old) - set(child) == {(q, b) for q in RHO for b in (0, 1)}, 'Deleted rows')
    need(not set(child) - set(old), 'Added working rows')
    need(all(z not in RHO for w, d, z in child.values()), 'Deleted target remains')
    for q, expected in INCOMING.items():
        actual = sorted((p, b, w, d) for (p, b), (w, d, z) in old.items() if z == q)
        need(actual == expected, 'Incoming-edge census for state ' + str(q))
        need(all(w == TAGS[q] and d == 1 for p, b, w, d in actual), 'Tag invariant')
        need(q != 0, 'The initial state cannot inherit an entering-edge invariant')
    for (q, b), (w, d, z) in old.items():
        if q not in SPECIAL:
            need(child[rho(q), b] == (w, d, rho(z)), 'Non-special row breaks quotient')
    need(child[163, 0] == (0, -1, 211), 'First selector entry')
    need(child[220, 0] == (0, -1, 217), 'Second selector entry')


def fold_paths(old, child):
    records = []
    for q in sorted(SPECIAL):
        for bit in (0, 1):
            cells = {-1: TAGS[q], 0: bit}
            endpoint, old_trace = local_run(old, q, cells, 1)
            target, head, tape = endpoint
            expected = (rho(target), head, tape)
            steps = LENGTHS.get((q, bit), 1)
            actual, new_trace = local_run(child, rho(q), cells, steps)
            need(actual == expected, 'Local fold mismatch at ' + str((q, bit)))
            need(actual[2] == cells and head == 1, 'Local tape/head changed')
            records.append({'old_state': q, 'new_state': rho(q), 'read': bit,
                            'preceding_bit': TAGS[q], 'old_steps': 1,
                            'new_steps': steps, 'old_trace': old_trace,
                            'new_trace': new_trace, 'endpoint_old_state': target,
                            'endpoint_new_state': rho(target), 'endpoint_head': head,
                            'exterior_unread': True, 'entire_tape_unchanged': True})
    return records


def repair_paths(baseline, rotated):
    need(baseline[171, 0] == (0, -1, 7), 'Original engine entry')
    need(rotated[171, 0] == (0, -1, 205), 'Repaired engine entry')
    records = []
    for left in (0, 1):
        cells, steps = {-1: left, 0: 0}, 2 + left
        a, ta = local_run(baseline, 171, cells, steps)
        b, tb = local_run(rotated, 171, cells, steps)
        need(a == b, 'Engine entry repair mismatch')
        need(a == (86 if left == 0 else 164, left, cells), 'Repair endpoint')
        records.append({'preceding_bit': left, 'steps_each': steps,
                        'baseline_trace': ta, 'rotated_trace': tb,
                        'exterior_unread': True, 'entire_tape_unchanged': True})
    return records


def blank_run(table, count):
    # A sparse map records all nonzero cells; every omitted integer is zero.
    tape, q, head, used = {}, 0, 0, set()
    fingerprint = hashlib.sha256()
    for i in range(count):
        need(q != NATIVE_HALT, 'Startup halted prematurely')
        bit = tape.get(head, 0)
        w, d, z = table[q, bit]
        fingerprint.update((json.dumps([i, q, head, bit, w, d, z],
                                       separators=(',', ':')) + '\n').encode('ascii'))
        used.add((q, bit))
        if w:
            tape[head] = 1
        else:
            tape.pop(head, None)
        q, head = z, head + d
    return (q, head, frozenset(tape)), fingerprint.hexdigest(), used


def source_prefix(rows):
    paths = {p: i for i, (p, op, arg) in enumerate(rows)}
    maximum = max(map(len, paths))
    def locate(prefix):
        padded = prefix + '0' * maximum
        for n in range(1, maximum + 1):
            if padded[:n] in paths:
                need('1' not in prefix[n:], 'Stray suffix after source leaf')
                return paths[padded[:n]]
        raise ValueError('Unresolved source address')
    def plus_one(path):
        return format((int(path, 2) + 1) % (1 << len(path)), '0' + str(len(path)) + 'b') if path else ''
    def cut(path, bit, number):
        positions = [i for i, c in enumerate(path) if c == bit]
        return path[:positions[-number]] if len(positions) >= number else ''
    ip, registers = 106, [1, 0, 4, 0, 0, 1, 0, 0, 1]
    transcript = hashlib.sha256()
    for _ in range(141):
        old = [ip, registers.copy()]
        path, opcode, argument = rows[ip]
        if opcode == 'CI':
            registers[argument] += 1
            ip = locate(plus_one(path))
        elif opcode == 'CD':
            if registers[argument] > 0:
                registers[argument] -= 1
                ip = locate(plus_one(path))
            else:
                ip = locate(plus_one(cut(path, '0', 1)))
        elif opcode == 'CB':
            ip = locate(plus_one(cut(path, '0', argument)))
        elif opcode == 'CC':
            ip = locate(cut(path, '1', argument))
        else:
            raise ValueError('Unexpected halt in source prefix')
        transcript.update((json.dumps([old, ip, registers], separators=(',', ':')) + '\n').encode())
    need((ip, registers) == (136, [1, 0, 13, 0, 0, 1, 0, 0, 1]), 'Source prefix endpoint')
    return transcript.hexdigest()


def startup(baseline, child, rows):
    a, ha, used = blank_run(baseline, 48140)
    b, hb, child_used = blank_run(child, 48140)
    need(a == b and ha == hb and used == child_used, 'Blank startup changed')
    need(a[:2] == (84, -2), 'Startup state/head')
    changed = {k for k in set(baseline) | set(child) if baseline.get(k) != child.get(k)}
    need(not used & changed, 'Startup visited an edited or removed row')
    need(rows[136][0] == '001100110101010', 'Startup source address')
    logical = [1, 0, 13, 0, 0, 1, 0, 0, 1]
    physical = [0] * 9
    for logical_index, physical_index in enumerate([6, 2, 0, 4, 3, 7, 8, 5, 1]):
        physical[physical_index] = logical[logical_index]
    expected = {-3, 54} | {-2 + i for i, b in enumerate(rows[136][0]) if b == '1'}
    separator = 55
    for value in physical + [1] * 43:
        expected.update(range(separator + 1, separator + value + 2))
        separator += value + 2
    need(a[2] == frozenset(expected), 'Canonical startup tape including zero exterior')
    return {'steps': 48140, 'state': 84, 'head': -2,
            'trace_sha256': ha, 'identical_literal_trace': True,
            'edited_row_visits': 0, 'source_ordinal': 136,
            'source_address': rows[136][0], 'logical_registers': logical,
            'header_cell': 54, 'header_distance': 56, 'spare_registers': [1] * 43,
            'whole_tape_one_cells': sorted(expected), 'zero_exterior': True,
            'source_prefix_steps': 141, 'source_prefix_sha256': source_prefix(rows)}


def dense_isomorphism(child, dense, mapping):
    states = sorted({q for q, b in child})
    want = {q: i for i, q in enumerate(states)}
    want[NATIVE_HALT] = 209
    if 'native_to_dense' in mapping:
        mapping = mapping['native_to_dense']
    actual = {int(k): v for k, v in mapping.items()}
    need(actual == want, 'Dense state map differs from sorted native labels')
    expected = {(want[q], b): (w, d, want[z]) for (q, b), (w, d, z) in child.items()}
    need(dense == expected, 'Dense table is not the claimed isomorphic machine')


def negative_controls(baseline, old, child):
    mutations = [
        ('first_selector_direction', (163, 0), (0, 1, 211)),
        ('first_selector_write', (163, 0), (1, -1, 211)),
        ('second_selector_old_helper', (220, 0), (0, -1, 215)),
        ('second_selector_direction', (220, 0), (0, 1, 217)),
        ('helper217_zero', (217, 0), (0, 1, 129)),
        ('helper217_one', (217, 1), (1, 1, 158)),
        ('helper211_zero', (211, 0), (0, 1, 184)),
        ('helper211_one', (211, 1), (1, 1, 157)),
        ('alias157_zero', (157, 0), (0, -1, 148)),
        ('alias157_one', (157, 1), (0, -1, 148)),
    ]
    rejected = []
    for name, key, action in mutations:
        damaged = dict(child)
        damaged[key] = action
        try:
            fold_paths(old, damaged)
        except (ValueError, KeyError):
            rejected.append(name)
        else:
            raise ValueError('A damaged local certificate was accepted: ' + name)
    for name, key, action in [
        ('false_218_predecessor', (216, 1), (1, 1, 218)),
        ('false_180_predecessor', (199, 0), (0, 1, 180)),
    ]:
        damaged = dict(old)
        damaged[key] = action
        try:
            fold_premises(damaged, child)
        except ValueError:
            rejected.append(name)
        else:
            raise ValueError('A false incoming-edge premise was accepted')
    damaged = dict(old)
    damaged[171, 0] = (0, -1, 7)
    try:
        repair_paths(baseline, damaged)
    except ValueError:
        rejected.append('missing_engine_entry_repair')
    else:
        raise ValueError('Missing engine repair was accepted')
    return rejected


def check(root=ROOT):
    root = Path(root)
    files = {name: root / path for name, path in {
        'baseline': 'inputs/u212.native.tm', 'prefold': 'machine/prefold212.native.tm',
        'native': 'machine/u209.native.tm', 'dense': 'machine/u209.tm',
        'source': 'machine/sites.json', 'mapping': 'machine/state_map.json'}.items()}
    baseline = load_table(files['baseline'], 212, NATIVE_HALT)
    old = load_table(files['prefold'], 212, NATIVE_HALT)
    child = load_table(files['native'], 209, NATIVE_HALT)
    dense = load_table(files['dense'], 209, 209)
    rows = json.loads(files['source'].read_text())
    dense_isomorphism(child, dense, json.loads(files['mapping'].read_text()))
    fold_premises(old, child)
    local = fold_paths(old, child)
    repair = repair_paths(baseline, old)
    return {'status': 'PASS', 'working_states': 209, 'transition_rows': 418,
            'sha256': {name: digest(path) for name, path in files.items()},
            'dense_isomorphism': True, 'state_map_native': RHO,
            'incoming_census': INCOMING, 'fold_cases': local,
            'minimum_block_steps': 1, 'maximum_block_steps': 5,
            'engine_entry_repair': repair,
            'negative_controls_rejected': negative_controls(baseline, old, child),
            'startup': startup(baseline, child, rows),
            'proof_scope': 'Universal local finite blocks and exact blank startup; source rotations, full runtime, and consistency calibration are separate.',
            'proof_assistant_certificate': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = check(args.root)
    output = args.output or args.root / 'build/independent.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'working_states': 209,
                      'transition_rows': 418, 'local_cases': len(result['fold_cases']),
                      'entry_repair_cases': len(result['engine_entry_repair']),
                      'negative_controls': len(result['negative_controls_rejected']),
                      'blank_steps': result['startup']['steps'],
                      'native_sha256': result['sha256']['native']}, indent=2))
