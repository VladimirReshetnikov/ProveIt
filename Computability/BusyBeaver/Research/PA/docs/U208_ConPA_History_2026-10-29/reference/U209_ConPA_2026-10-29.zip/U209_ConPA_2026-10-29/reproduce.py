#!/usr/bin/env python3
"""Offline reproduction of the U209 packet; default includes full runtime proof.

Use --quick to skip the unbounded symbolic replay explicitly. Generated files
are written outside the sealed packet, to a temporary directory or --output.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise ValueError(message)


def check_manifest():
    manifest = ROOT / 'MANIFEST.json'
    need(manifest.is_file(), 'MANIFEST.json is missing')
    data = json.loads(manifest.read_text())
    for relative, expected in data['files'].items():
        path = ROOT / relative
        need(path.is_file(), 'Missing sealed file: ' + relative)
        raw = path.read_bytes()
        need(len(raw) == expected['bytes'] and
             hashlib.sha256(raw).hexdigest() == expected['sha256'],
             'Changed sealed file: ' + relative)
    return len(data['files'])


def run_checks(output, quick):
    began = time.monotonic()
    output.mkdir(parents=True, exist_ok=True)
    count = check_manifest()
    sys.path.insert(0, str(ROOT / 'checks'))
    import build
    import compare_inputs
    import independent_check
    import independent_source
    import check_row_deletion

    constructed = build.build(output / 'rebuilt')
    for name in ('u209.native.tm', 'u209.tm', 'prefold212.native.tm',
                 'sites.json', 'state_map.json'):
        need((output / 'rebuilt' / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
             'Rebuilt artifact differs: ' + name)
    print('Exact construction and every source CFG: PASS', flush=True)
    comparison = compare_inputs.check(output / 'comparison.json')
    source = independent_source.check(output / 'source.json')
    process = subprocess.run([sys.executable, '-B', str(ROOT / 'checks/independent_check.py'),
                              '--output', str(output / 'independent.json')],
                             capture_output=True, text=True, check=True)
    (output / 'independent.log').write_text(process.stdout + process.stderr)
    independent = json.loads((output / 'independent.json').read_text())
    optimized = subprocess.run([sys.executable, '-O', '-B',
                                str(ROOT / 'checks/independent_check.py'), '--output',
                                str(output / 'independent_optimized.json')],
                               capture_output=True, text=True, check=True)
    need(independent == json.loads((output / 'independent_optimized.json').read_text()),
         'Independent checker changed under optimized Python')
    print('Comparison, independent source, local folds and exact startup: PASS', flush=True)
    no_go = check_row_deletion.run()
    (output / 'row_deletion.json').write_text(json.dumps(no_go, indent=2) + '\n')
    if quick:
        runtime = {'status': 'EXPLICITLY_SKIPPED', 'reason': '--quick selected'}
        print('Unbounded runtime replay: SKIPPED (--quick)', flush=True)
    else:
        import check_runtime
        runtime = check_runtime.check(output / 'runtime', compare_saved=True)
        print('All 5,084 unbounded guarded contracts and all 418 rows: PASS', flush=True)
    result = dict(status='QUICK_PASS' if quick else 'FULL_PASS',
                  manifest_files=count, constructed_states=constructed['working_states'],
                  source_rotations=source['rotations'],
                  input_proposals=len(comparison['records']),
                  independent_status=independent['status'],
                  no_go_finite_crosscheck=no_go['status'],
                  runtime={k: v for k, v in runtime.items() if k != 'blocks'},
                  elapsed_seconds=time.monotonic() - began,
                  proof_assistant_endpoint=False)
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick', action='store_true')
    parser.add_argument('--output', type=Path,
                        help='Write generated receipts outside this sealed package')
    args = parser.parse_args()
    need(__debug__ and not sys.flags.optimize, 'Run the driver without -O/PYTHONOPTIMIZE')
    if args.output:
        destination = args.output.resolve()
        need(destination != ROOT and ROOT not in destination.parents,
             'Use an output directory outside the sealed package')
        run_checks(destination, args.quick)
    else:
        with tempfile.TemporaryDirectory(prefix='u209-replay-') as temporary:
            run_checks(Path(temporary), args.quick)
