#!/usr/bin/env python3
"""Compare the three pinned incoming U211 archives directly, without extraction."""
from collections import deque
from io import BytesIO
from itertools import combinations
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

from independent_source import source_info

ROOT = Path(__file__).resolve().parents[1]
PACKETS = [
    ('Contextual', 'U211_ConPA_Contextual_2026-10-28.zip',
     'u211_contextual_2026-10-28', 'machine/sites.json', 6, 180),
    ('Research', 'U211_ConPA_Research_2026-10-28.zip',
     'U211_ConPA_Decoder_Reassociation_2026-10-28', 'machine/sites.json', 9, 181),
    ('Rotated', 'U211_ConPA_Rotated_2026-10-28.zip',
     'U211_ConPA_Rotated_2026-10-28', 'source/sites.json', 11, 218),
]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def parse(raw):
    table = {}
    for line in raw.decode('ascii').splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, t = line.split()
        q, b, w, t = map(int, (q, b, w, t))
        need((q, b) not in table and b in (0, 1) and w in (0, 1)
             and d in ('L', 'R'), 'Malformed input table')
        table[q, b] = w, d, t
    return table


def rooted_isomorphism(left, right):
    """A root-preserving isomorphism is forced by the two labeled successors."""
    forward, inverse = {0: 0, 254: 254}, {0: 0, 254: 254}
    pending, visited = deque([(0, 0, '')]), set()
    while pending:
        q, r, word = pending.popleft()
        if q in visited or q == 254:
            continue
        visited.add(q)
        for b in (0, 1):
            a, c = left[q, b], right[r, b]
            trace = word + str(b)
            if a[:2] != c[:2]:
                return dict(isomorphic=False, reason='write/move conflict', path=trace,
                            left_action=a, right_action=c)
            u, v = a[2], c[2]
            if u in forward and forward[u] != v:
                return dict(isomorphic=False, reason='forced map conflict', path=trace,
                            left_state=u, prior_right=forward[u], new_right=v)
            if v in inverse and inverse[v] != u:
                return dict(isomorphic=False, reason='forced inverse conflict', path=trace,
                            right_state=v, prior_left=inverse[v], new_left=u)
            forward[u], inverse[v] = v, u
            pending.append((u, v, trace))
    return dict(isomorphic=True, mapped_states=len(forward), visited=len(visited))


def check(output=None):
    provenance = json.loads((ROOT / 'inputs/provenance.json').read_text())
    pins = {item['name']: item for item in provenance['files']}
    for name, item in pins.items():
        if name.endswith('.zip'):
            raw = (ROOT / 'reference' / name).read_bytes()
            need(len(raw) == item['bytes'] and digest(raw) == item['sha256'],
                 'Input archive identity: ' + name)
    original = json.loads((ROOT / 'inputs/u212.sites.json').read_text())
    original_cfg = source_info(original)[2]
    parent = parse((ROOT / 'inputs/u212.native.tm').read_bytes())
    tables, records = {}, []
    for name, archive, directory, source_member, rotations, removed in PACKETS:
        with zipfile.ZipFile(ROOT / 'reference' / archive) as packet:
            native = packet.read(directory + '/machine/u211.native.tm')
            dense = packet.read(directory + '/machine/u211.tm')
            source_raw = packet.read(directory + '/' + source_member)
            if name == 'Contextual':
                baseline = packet.read(directory + '/baseline/u212.native.tm')
                baseline_source = packet.read(directory + '/baseline/sites.json')
            elif name == 'Research':
                baseline = packet.read(directory + '/inputs/u212.native.tm')
                baseline_source = packet.read(directory + '/inputs/u212.sites.json')
            else:
                nested = packet.read(directory + '/inputs/u212_combined_2026-10-29.zip')
                with zipfile.ZipFile(BytesIO(nested)) as old:
                    prefix = 'u212_combined_2026-10-29/'
                    baseline = old.read(prefix + 'machine/u212.native.tm')
                    baseline_source = old.read(prefix + 'baseline/primary_u213/machine/sites.json')
        need(baseline == (ROOT / 'inputs/u212.native.tm').read_bytes(), 'Different U212 parent')
        need(baseline_source == (ROOT / 'inputs/u212.sites.json').read_bytes(),
             'Different source parent')
        table, rows = parse(native), json.loads(source_raw)
        info = source_info(rows)
        need(len(table) == 422 and len({q for q, b in table}) == 211, 'U211 census')
        need([row[1:] for row in rows] == [row[1:] for row in original], 'Changed source word')
        need(info[2] == original_cfg, 'Different source control flow')
        need({q for q, b in parent} - {q for q, b in table} == {removed},
             'Unexpected deleted state')
        tables[name] = table
        records.append(dict(name=name, archive=archive, rotations=rotations,
                            deleted_native_state=removed, states=211, rows=422,
                            native_sha256=digest(native), dense_sha256=digest(dense),
                            source_sha256=digest(source_raw), metrics=info[3],
                            changed_retained_rows=sum(parent[k] != v for k, v in table.items()),
                            changed_addresses=sum(a[0] != b[0] for a, b in zip(original, rows)),
                            same_primitive_word=True, same_guarded_ordinal_graph=True))
    comparisons = []
    for a, b in combinations(tables, 2):
        result = rooted_isomorphism(tables[a], tables[b])
        need(not result['isomorphic'], 'Unexpected isomorphic proposal pair')
        comparisons.append(dict(left=a, right=b, **result))
    result = dict(status='PASS', repository_commit=provenance['repository_commit'],
                  records=records, pairwise_graph_isomorphism=comparisons,
                  interpretation='Distinct encodings; the same primitive word and source CFG.')
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'build/comparison.json')
    args = parser.parse_args()
    print(json.dumps(check(args.output), indent=2))
