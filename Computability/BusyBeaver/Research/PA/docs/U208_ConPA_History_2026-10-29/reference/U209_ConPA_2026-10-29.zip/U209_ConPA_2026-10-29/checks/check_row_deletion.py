#!/usr/bin/env python3
"""Finite certificate for a mathematical no-go theorem, not a theorem prover.

A PA-verifiable syntactic valuation proves that deleting the sole dominated
propositional row from native D_U leaves a PA-provably consistent calculus.
The accompanying note gives the unbounded proof by structural induction.
"""
from functools import lru_cache
from itertools import product
from math import isqrt
import json


def pair(x, y):
    return (x+y)*(x+y+1)//2+y


def unpair(n):
    s = (isqrt(8*n+1)-1)//2
    y = n-s*(s+1)//2
    return s-y, y


def impl(x, y): return 4*pair(x, y)
def mem(x, y): return 4*pair(x, y)+1
def forall(i, f): return 4*pair(i, f)+2
def equal(i, j): return 4*pair(i, j)+3
def neg(f): return impl(f, 1)
def exists(i, f): return neg(forall(i, neg(f)))


@lru_cache(maxsize=None)
def value(n):
    if n == 0:
        return True
    a, b = unpair(n//4)
    tag = n % 4
    if tag == 0:
        return value(a) == value(b)
    if tag == 1:
        return False
    if tag == 2:
        return value(b)
    return True


def seven_rows(a, b, c):
    return (
        exists(a, equal(a, b)),
        impl(forall(a, impl(b, c)), impl(forall(a, b), forall(a, c))),
        impl(equal(a, b), impl(mem(c, a), mem(c, b))),
        impl(forall(a, forall(b, c)), forall(b, forall(a, c))),
        impl(equal(c, a), impl(mem(c, b), mem(a, b))),
        impl(exists(a, forall(a, c)), c),
        impl(equal(c, a), impl(equal(c, b), forall(mem(a, b), equal(a, b)))),
    )


def bundle(a, b, c):
    if c == a or c == b:
        return 0
    e = mem(c, a)
    guard = forall(a, impl(mem(a, c), mem(a, b)))
    upper = forall(c, impl(e, a))
    lower = forall(c, impl(a, impl(guard, e)))
    shell = forall(a, impl(upper, impl(lower, 1)))
    vacuity = impl(mem(a, b), forall(c, mem(a, b)))
    return neg(impl(vacuity, shell))


def dominated_row(a, b, c, u):
    return impl(impl(impl(c, u), a), impl(impl(a, c), impl(b, c)))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def run():
    require(value(0) and not value(1), 'truth/target values')
    n = 8
    for a, b, c in product(range(n), repeat=3):
        require(all(value(row) for row in seven_rows(a,b,c)), ('row',a,b,c))
        require(value(bundle(a,b,c)), ('bundle',a,b,c))
    for x, y in product((False, True), repeat=2):
        require(not (x and x == y) or y, 'modus ponens')
    counter = dominated_row(1,1,1,1)
    require(not value(counter), 'dominated row counterexample')
    return {
        'status':'PASS',
        'native_constructor_semantics':{
            'truth_0':True,'false_target_1':False,
            'implication':'Boolean equality','membership':False,
            'equality':True,'universal':'body value'},
        'retained_seven_rows_numeric_cases':7*n**3,
        'gated_cover_bundle_numeric_cases':n**3,
        'modus_ponens_truth_cases':4,
        'rejected_dominated_instance':{
            'a':1,'b':1,'c':1,'u':1,'u_le_a':True,
            'formula_code':counter,'value':False},
        'scope':'Finite implementation cross-check of the accompanying '
                'unbounded structural/derivation induction proof; not a kernel proof.'
    }

if __name__ == '__main__':
    print(json.dumps(run(), indent=2, sort_keys=True))
