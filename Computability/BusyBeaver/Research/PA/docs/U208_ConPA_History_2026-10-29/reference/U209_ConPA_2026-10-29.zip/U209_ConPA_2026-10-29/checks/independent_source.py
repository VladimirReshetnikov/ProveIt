#!/usr/bin/env python3
"""Independently audit U209 source rotations and final literal prefix bindings.

The source-info, prefix-binding and address-transform utilities are preserved
from the supplied U211 Research packet's audit_rotation_source.py. This wrapper
checks selected rotation roots at each stage; it does not impose physical
runtime validity on intermediate layouts with seven-zero addresses. Only the
final pre-fold and final209 layouts receive exhaustive internal-prefix checks.
The final runtime proof is a separate gate.
"""
from pathlib import Path
from collections import defaultdict
import argparse, hashlib, json

def require(ok, message):
    if not ok: raise ValueError(message)

def read_table(path):
    rows={}; start=[]
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):start.append(int(line[9:]));continue
        if not line or line.startswith('#'):continue
        q,b,w,d,t=line.split();q,b,w,t=map(int,(q,b,w,t))
        require((q,b)not in rows and b in(0,1)and w in(0,1)and d in('L','R'),'bad table row')
        rows[q,b]=w,1 if d=='R'else-1,t
    require(start==[0],'start is not zero')
    return rows

def source_info(rows):
    leaves={p:(o,a)for p,o,a in rows};require(len(leaves)==len(rows),'duplicate leaf')
    branch={};interval={};boundary={};serial=[];subtree={}
    def visit(p):
        lo=len(serial)
        if p in leaves:
            op,arg=leaves[p];serial.append([p,op,arg]);subtree[p]=(op,arg)
            boundary[p]=(1 if op=='CD' else arg if op=='CB' else 0,
                         arg if op=='CC' else 0, op=='CH')
        else:
            # Finite depth prevents an incomplete tree from recursing forever.
            require(len(p)<=max_depth,'incomplete prefix tree')
            visit(p+'0');visit(p+'1');branch[p]=(p+'0',p+'1')
            x,y=boundary[p+'0'],boundary[p+'1']
            boundary[p]=(max(x[0]-1,y[0],0),max(x[1],y[1]-1,0),x[2]or y[2])
            subtree[p]=(subtree[p+'0'],subtree[p+'1'])
        interval[p]=lo,len(serial)
    max_depth=max(len(p)for p in leaves);visit('');require(serial==rows,'noncanonical source')
    size=len(rows);cfg=[]
    def target(p,edge,number):
        positions=[j for j,b in enumerate(p)if b==edge]
        require(len(positions)>=number,'unbound branch')
        ancestor=p[:positions[-number]]
        return interval[ancestor][0 if edge=='1'else 1]%size
    for i,(p,op,arg)in enumerate(rows):
        if op=='CI':out=((i+1)%size,)
        elif op=='CD':out=(target(p,'0',1),(i+1)%size)
        elif op=='CB':out=(target(p,'0',arg),)
        elif op=='CC':out=(target(p,'1',arg),)
        elif op=='CH':out=()
        else:raise ValueError('bad opcode')
        cfg.append((op,arg,out))
    metrics={'primitives':size,'dag_nodes':len(set(subtree.values())),
             'maximum_depth':max_depth,
             'maximum_zero_run':max(len(v)for p in leaves for v in p.split('1'))}
    return branch,boundary,cfg,metrics

def prefix_binding(table, prefixes):
    bound={};max_steps=0
    for word in prefixes:
        q,h=84,0;known={-1:1,**dict(enumerate(map(int,word)))}
        for steps in range(1000):
            if h==len(word):break
            require(h in known,('prefix reads opaque cell',word,q,h))
            b=known[h];w,d,q=table[q,b]
            require(w==b,('prefix overwrites a cell',word,h))
            h+=d
        else:raise ValueError(('prefix does not finish',word))
        bound[word]=q;max_steps=max(max_steps,steps)
    return bound,max_steps

def rotate_addresses(rows, roots, side):
    def transform(path):
        for pre in roots:
            if path.startswith(pre):
                s=path[len(pre):]
                # Leaves cannot equal an outer or its inner branch node.
                if side==0:
                    if s.startswith('00'):s='0'+s[2:]
                    elif s.startswith('01'):s='10'+s[2:]
                    else:require(s.startswith('1'),'bad left rotation leaf');s='11'+s[1:]
                else:
                    if s.startswith('0'):s='00'+s[1:]
                    elif s.startswith('10'):s='01'+s[2:]
                    else:require(s.startswith('11'),'bad right rotation leaf');s='1'+s[2:]
                return pre+s
        return path
    return [[transform(p),op,arg]for p,op,arg in rows]

PKG = Path(__file__).resolve().parents[1]

def check(output=None):
    table=read_table(PKG/'inputs/u212.native.tm')
    rows=json.loads((PKG/'inputs/u212.sites.json').read_text())
    recipe=json.loads((PKG/'inputs/rotations.json').read_text())
    original_cfg=source_info(rows)[2];ledger=[]
    for n,item in enumerate(recipe,1):
        p,q,side=item['outer'],item['inner'],item['side'];roots=item['paths']
        branches,bd,cfg,metrics=source_info(rows)
        require(cfg==original_cfg,'stage CFG')
        require(all(r in branches for r in roots),'invalid root')
        binding,maxsteps=prefix_binding(table,roots+[r+str(side)for r in roots])
        require(all(binding[r]==p and binding[r+str(side)]==q for r in roots),'selected literal binding')
        require(all(table[x,b][:2]==(b,1)for x in(p,q)for b in(0,1)),'nonpure decoder')
        require(table[p,side][2]==q,'bad decoder edge')
        require({k for k,v in table.items()if v[2]==q}=={(p,side)},'nonunique inner entry')
        for r in roots:
            factors=[r+'00',r+'01',r+'1']if side==0 else[r+'0',r+'10',r+'11']
            require(all(bd[x]==(0,0,False)for x in factors),'escaping control')
        if side==0:
            x,y,z=table[q,0][2],table[q,1][2],table[p,1][2]
            table.update({(p,0):(0,1,x),(p,1):(1,1,q),(q,0):(0,1,y),(q,1):(1,1,z)})
        else:
            x,y,z=table[p,0][2],table[q,0][2],table[q,1][2]
            table.update({(p,0):(0,1,q),(p,1):(1,1,z),(q,0):(0,1,x),(q,1):(1,1,y)})
        rows=rotate_addresses(rows,roots,side)
        info=source_info(rows);require(info[2]==original_cfg,'post rotation CFG')
        ledger.append(dict(step=n,outer=p,inner=q,side=side,paths=roots,metrics=info[3],selected_binding_max_steps=maxsteps))
    table[171,0]=(0,-1,205)
    require(table==read_table(PKG/'machine/prefold212.native.tm'),'prefold table bytes')
    require(rows==json.loads((PKG/'machine/sites.json').read_text()),'final source bytes')
    prefixes=source_info(rows)[0]
    pre_binding,pre_max=prefix_binding(table,prefixes)
    final=read_table(PKG/'machine/u209.native.tm')
    final_binding,final_max=prefix_binding(final,prefixes)
    rho = lambda q: {180: 163, 181: 220, 218: 157}.get(q, q)
    require(all(final_binding[p] == rho(q) for p, q in pre_binding.items()),
            'Final prefix bindings do not commute with the state quotient')
    result=dict(status='INDEPENDENT_SOURCE_ASSEMBLY_PASS',rotations=len(ledger),source_primitives=3909,
        guarded_cfg_arrows=sum(len(x[2])for x in original_cfg),final_internal_prefixes=len(final_binding),prefix_state_quotient_matches=len(final_binding),
        final_prefold_maximum_prefix_steps=pre_max,final209_maximum_prefix_steps=final_max,
        final_metrics=source_info(rows)[3],intermediate_stages_exceeding_zero_run_six=[r['step']for r in ledger if r['metrics']['maximum_zero_run']>6],
        records=ledger,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Each source CFG and selected rotation-root literal binding checked. Only final prefold and final209 receive complete internal-prefix checks; no intermediate runtime equivalence is claimed.')
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(json.dumps(result, indent=2) + '\n')
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=PKG / 'build' / 'independent_source.json')
    args = parser.parse_args()
    report = check(args.output)
    print(json.dumps({key: value for key, value in report.items() if key != 'records'}, indent=2))
