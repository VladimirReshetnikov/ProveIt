from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/dev/shm/cell-label-bound');D=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-cell-label-bound-evidence');D.mkdir(parents=True,exist_ok=True);files={}
for p in sorted(R.rglob('*')):
 if p.is_file() and not p.is_symlink() and not str(p.relative_to(R)).startswith('objects-') and p.suffix!='.olean' and p.name!='build-bundle.py':files['prototype/'+str(p.relative_to(R))]=p.read_bytes()
prior={'cell-local.json':'/tmp/high-digits-module-sharing/final-records.json','doubled-clause.json':'/tmp/cell-construction-share/common-records.json','standard-casts.json':'/tmp/binary-half-direct/final-supplement-records.json','modular-cancellation.json':'/tmp/shared-modular-cancel/records.json','cyclic-word.json':'/tmp/cyclic-rot-mod/final-records.json'}
for n,p in prior.items():files['prior/'+n]=Path(p).read_bytes()
for n in ('cell-label-bound-peer-review.txt','cell-label-bound-peer-audit.py','cell-label-bound-peer-audit.log'):files['independent/'+n]=Path('/tmp',n).read_bytes()
c=subprocess.check_output(['git','rev-parse','a31bd9dc8c'],text=True).strip();par=subprocess.check_output(['git','rev-parse',c+'^'],text=True).strip();base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for rev,label in ((par,'baseline'),(c,'final')):
 b=subprocess.check_output(['git','show',rev+':'+base+'ArithmeticCellLabels.lean']);assert b==files['prototype/'+label+'/DiophantineConsistency/ArithmeticCellLabels.lean'];files['commit/'+label+'.lean']=b
for n in ('ArithmeticCellTransfer','ArithmeticCellLocal','MFDoubledClause2011','ArithmeticStandardCasts','ArithmeticModularCancellation','ArithmeticCyclicWord'):
 files['commit/inputs/'+n+'.lean']=subprocess.check_output(['git','show',c+':'+base+n+'.lean'])
files['bundle/build-bundle.py']=Path('/dev/shm/cell-label-bound/build-bundle.py').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':c,'source_parent':par,'scope':'Replace the two selector cases with a direct magnitude bound in DC.raw_lt_radix','validation':'Paired target and sole tracked direct Lean client ArithmeticCellTransfer pass; client objects match. All five direct external source/object pairs match prior successful producer receipts. Target declaration/type/axiom probes match except for recorded generated auxiliaries; global simp and instances match.','limitations':['Generated public DC.raw_lt_radix._proof_4 and _proof_5 disappear and retained _proof_3 changes type/axiom report. A bounded tracked Lean/Python search found no references; other languages, dynamic references and external clients are not excluded.','Prior direct producer matches do not constitute a full current-source project, Foundation or Mathlib closure. No other downstream clients were replayed.','Equal reports do not establish proof-body or every persistent-extension equality. One shared-load timing pair is not a general benchmark. The warning-producing exploratory probe lacks full input pins.','Compiled objects are excluded; external objects are needed to independently verify recorded hashes.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'independent_review_sha256':sha(files['independent/cell-label-bound-peer-review.txt']),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(files['independent/cell-label-bound-peer-review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,b in files.items():assert z.read(n)==b
assert sha((D/'independent-review.txt').read_bytes())==m['independent_review_sha256'];print('PASS members',len(files),'zip sha',m['archive_sha256'],'review sha',m['independent_review_sha256'])
