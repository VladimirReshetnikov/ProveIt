from pathlib import Path
import hashlib,json,re,subprocess
p=Path('/dev/shm/cell-label-bound'); repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');n='ArithmeticCellLabels'; h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
a=(p/'baseline/DiophantineConsistency'/f'{n}.lean').read_text();b=(p/'final/DiophantineConsistency'/f'{n}.lean').read_text();st='theorem raw_lt_radix';end='theorem digit_eq_raw'
assert b== (repo/f'{n}.lean').read_text()
rel=str(repo/f'{n}.lean')
assert subprocess.check_output(['git','show','a31bd9dc8c^:'+rel]).decode()==a
assert subprocess.check_output(['git','show','a31bd9dc8c:'+rel]).decode()==b
print('Commit a31bd9dc8c and parent match final and baseline snapshots')
assert a[:a.index(st)]==b[:b.index(st)] and a[a.index(end):]==b[b.index(end):]
assert a[a.index(st):a.index(':= by',a.index(st))]==b[b.index(st):b.index(':= by',b.index(st))]
print('Only original theorem proof body differs; final workspace and statement match')
rows={}
for phase in ['baseline','final']:
 rows[phase]=json.loads((p/f'{phase}-records.json').read_text())
 assert [x['module'] for x in rows[phase]]==['ArithmeticCellLabels','ArithmeticCellTransfer']
 for x in rows[phase]:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][2]).read_text()==x['time']
  for d in x['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d.get('source_before'):assert d['source_before']==d['source_after']==h(d['source'])
   fn=d['module'].replace('.','/')+'.olean';first=next(Path(q)/fn for q in x['LEAN_PATH'].split(':') if (Path(q)/fn).exists());assert first.resolve()==Path(d['path']).resolve()
 print(phase,'target/client source, objects, direct first-input pins and logs match')
assert rows['baseline'][1]['object_sha256']==rows['final'][1]['object_sha256'];print('Client object byte-identical')
providers=[('ArithmeticCellLocal','/tmp/high-digits-module-sharing/final-records.json'),('MFDoubledClause2011','/tmp/cell-construction-share/common-records.json'),('ArithmeticStandardCasts','/tmp/binary-half-direct/final-supplement-records.json'),('ArithmeticModularCancellation','/tmp/shared-modular-cancel/records.json'),('ArithmeticCyclicWord','/tmp/cyclic-rot-mod/final-records.json')]
inputs={d['module'].split('.')[-1]:d for x in rows['baseline'] for d in x['direct_inputs']}
for name,path in providers:
 d=inputs[name]; records=json.loads(Path(path).read_text()); matches=[x for x in records if str(x.get('module',x.get('name',''))).split('.')[-1]==name and x.get('status')==0 and x.get('object_sha256')==d['before'] and x.get('source_sha256_before',x.get('source_sha256',x.get('source_before',x.get('before'))) )==d['source_before']]
 assert matches,(name,path)
 print('provider pair matches',name,path)
for phase in ['baseline','final']:
 pp=json.loads((p/f'{phase}-probes.json').read_text()); assert {x['name'] for x in pp}=={'names','interfaces','simp','instances'}
 for x in pp:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(q) for q in x['objects']] and x['objects_before']==[rows[phase][0]['object_sha256']] and h(x['log'])==x['log_sha256'] and h(x['time'])==x['time_sha256']
for x in ['simp','instances']:assert (p/f'baseline-{x}.log').read_bytes()==(p/f'final-{x}.log').read_bytes()
def decls(x):
 chunks=re.split(r'(?=^DECL )',x,flags=re.M)
 return {re.match(r'DECL (\S+) TYPE ',c).group(1):c for c in chunks if c.startswith('DECL ')}
x=decls((p/'baseline-interfaces.log').read_text()); y=decls((p/'final-interfaces.log').read_text()); base='DiophantineConsistency.ArithmeticCellLabels.DC.raw_lt_radix._proof_'
assert x.keys()-y.keys()=={base+'4',base+'5'} and y.keys()-x.keys()==set() and {k for k in x.keys()&y.keys() if x[k]!=y[k]}=={base+'3'}
print('84/82 reports: generated _proof_4/5 removed; _proof_3 changed; all other reports and global simp/instances match')
print('PASS')
