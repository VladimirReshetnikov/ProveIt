import Mathlib.Tactic
namespace CellLabelBoundProbe
def wordBase : ℕ := 2 ^ 34
def raw (n W u k t b : ℕ) : ℕ :=
  2 * n + 2048 * ((wordBase - u) * n + W) + k + t + b
example {n W u k t b : ℕ}
    (hn : n ≤ 1) (hW : W < wordBase) (hu : u < wordBase)
    (hk : k ≤ 57) (ht : t ≤ 1) (hb : b ≤ 1) :
    raw n W u k t b < 2 ^ 47 := by
  have hu' := Nat.sub_add_cancel (Nat.le_of_lt hu)
  have hm := Nat.mul_le_mul_left (wordBase-u) hn
  simp only [raw]
  norm_num [wordBase] at hm hu' hW ⊢
  omega
end CellLabelBoundProbe
