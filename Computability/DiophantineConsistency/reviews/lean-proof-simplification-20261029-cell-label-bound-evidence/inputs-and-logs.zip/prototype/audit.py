from pathlib import Path
import json,hashlib,re
r=Path('/dev/shm/cell-label-bound');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticCellLabels','ArithmeticCellTransfer'];rec[phase]={x['module']:x for x in rows}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
   if d['module'].endswith('.ArithmeticCellLabels'):assert d['before']==rec[phase]['ArithmeticCellLabels']['object_sha256']
  if x['module']=='ArithmeticCellTransfer':assert h(x['source'])==h(w/'ArithmeticCellTransfer.lean')
  print('PASS build',phase,x['module'])
 for p in json.loads((r/(phase+'-probes.json')).read_text()):
  assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[phase]['ArithmeticCellLabels']['object_sha256']] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
assert rec['baseline']['ArithmeticCellTransfer']['object_sha256']==rec['final']['ArithmeticCellTransfer']['object_sha256']
for n in ('simp','instances'):assert (r/('baseline-'+n+'.log')).read_bytes()==(r/('final-'+n+'.log')).read_bytes()
def get(phase):return {a.split(' TYPE ',1)[0]:a for a in (r/(phase+'-interfaces.log')).read_text().split('DECL ')[1:]}
a,b=get('baseline'),get('final');prefix='DiophantineConsistency.ArithmeticCellLabels.DC.raw_lt_radix._proof_';assert set(a)-set(b)=={prefix+'4',prefix+'5'} and set(b)-set(a)==set() and {n for n in a.keys()&b.keys() if a[n]!=b[n]}=={prefix+'3'};print('PASS matching client, registrations and exact generated name/type differences')
providers={'ArithmeticCellLocal':('/tmp/high-digits-module-sharing/final-records.json','ArithmeticCellLocal'),'MFDoubledClause2011':('/tmp/cell-construction-share/common-records.json','MFDoubledClause2011'),'ArithmeticStandardCasts':('/tmp/binary-half-direct/final-supplement-records.json','ArithmeticStandardCasts'),'ArithmeticModularCancellation':('/tmp/shared-modular-cancel/records.json','ArithmeticModularCancellation'),'ArithmeticCyclicWord':('/tmp/cyclic-rot-mod/final-records.json','ArithmeticCyclicWord')}
for n,(p,m) in providers.items():
 d=next(d for x in rec['final'].values() for d in x['direct_inputs'] if d['module'].endswith('.'+n));matches=[x for x in json.load(open(p)) if x['module'].split('.')[-1]==m and x['status']==0 and x['object_sha256']==d['before']];assert matches;x=matches[-1];before=x.get('source_before',x.get('before',x.get('source_sha256')));after=x.get('source_after',x.get('after',x.get('source_sha256')));assert before==after==d['source_before'];print('PASS provider',n,d['before'])
print('PASS all checks')
