import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellLabels
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticCellLabels).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCellLabels" then
   logInfo m!"DECL {n}"
