CellLabels selector magnitude bound

The candidate rewrites only DC.raw_lt_radix. Instead of splitting n=0/n=1,
it uses (wordBase-u)+u=wordBase from the original u<wordBase and multiplies
n≤1 by wordBase-u, after which the same linear numeral argument applies.
All six guards, the statement, imports and definitions remain unchanged. Five
proof lines replace ten. Baseline/final source SHA-256:
b69b1fce6b01a886a5887ab1ca74dadaa8f0c1577d6b2e6eda3c6b9b03a3aa42 /
436ead71af0c4bda26845e380136ef97f70c986b59fa56af352a07d1d6c2c347.
Baseline matches the current workspace at build time; candidate is isolated.
The original source was introduced in f79467f544 with a Claude Opus 5.5
Co-Authored-By trailer.

Paired target and the only direct tracked Lean module client,
ArithmeticCellTransfer, compile; the client object is identical in the two
phases. Their source, commands, first-resolved direct object/source hashes,
output, logs and timings are in baseline-records.json and final-records.json.
Five external direct source/object pairs match prior successful producer rows:
ArithmeticCellLocal /tmp/high-digits-module-sharing/final-records.json;
MFDoubledClause2011 /tmp/cell-construction-share/common-records.json;
ArithmeticStandardCasts /tmp/binary-half-direct/final-supplement-records.json;
ArithmeticModularCancellation /tmp/shared-modular-cancel/records.json; and
ArithmeticCyclicWord /tmp/cyclic-rot-mod/final-records.json. These are direct
producer matches, not a current-source rebuild of their transitive project,
Foundation or Mathlib closure. Other downstream clients were not replayed.

Target probe reports show 84 baseline names vs 82 final names: generated
public DC.raw_lt_radix._proof_4 and _proof_5 are removed, and retained generated
DC.raw_lt_radix._proof_3 has a changed type. All other names, types and axioms
match; the global 31,283 simp and 13,779 instance registrations also match.
A scoped git grep for raw_lt_radix._proof_[345] across tracked .lean and .py
files found no references. That search does not establish absence of references
in untracked files, other languages or downstream projects. Identical reports
do not establish proof-body or all persistent-extension equality.

Target baseline/final user CPU 4.52/4.63 seconds is one shared-load pair,
not a general benchmark. No target/client warnings occurred. The small isolated
probe passed; probe-unused-hu.lean/.log preserve a working alternative that
would produce an unused-hypothesis warning. These exploratory probes lack full
input receipts and do not replace the paired target builds. audit.py/.log verify
source/object pins, provider associations, client byte identity and exact probe
differences. The test objects are transient under /dev/shm.
