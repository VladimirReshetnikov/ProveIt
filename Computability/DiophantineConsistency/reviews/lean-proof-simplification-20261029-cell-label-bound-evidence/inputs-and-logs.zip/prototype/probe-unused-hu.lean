import Mathlib.Tactic
namespace CellLabelBoundProbe
def wordBase : ℕ := 2 ^ 34
def raw (n W u k t b : ℕ) : ℕ :=
  2 * n + 2048 * ((wordBase - u) * n + W) + k + t + b
example {n W u k t b : ℕ}
    (hn : n ≤ 1) (hW : W < wordBase) (hu : u < wordBase)
    (hk : k ≤ 57) (ht : t ≤ 1) (hb : b ≤ 1) :
    raw n W u k t b < 2 ^ 47 := by
  have hm : (wordBase - u) * n ≤ wordBase :=
    le_trans (by simpa only [mul_one] using Nat.mul_le_mul_left (wordBase-u) hn) (Nat.sub_le _ _)
  simp only [raw]
  norm_num [wordBase] at hm hW ⊢
  omega
end CellLabelBoundProbe
