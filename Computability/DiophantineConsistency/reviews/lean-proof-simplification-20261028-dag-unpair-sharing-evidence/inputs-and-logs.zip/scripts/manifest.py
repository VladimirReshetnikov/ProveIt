from pathlib import Path
import hashlib
r=Path(__file__).resolve().parent.parent;m=r/'manifest.sha256';fs=sorted(p for p in r.rglob('*') if p.is_file() and p!=m);m.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(r).as_posix()+'\n' for p in fs));print(len(fs),'manifest entries')
