import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRuntimeBoundDagMacros).isPrefixOf n then
   logInfo m!"DECL {n}"
