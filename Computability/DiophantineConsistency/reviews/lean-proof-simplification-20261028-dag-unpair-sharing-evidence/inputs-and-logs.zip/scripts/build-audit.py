from pathlib import Path
import os,subprocess,time,hashlib,json,shutil,re
R=Path('/tmp/unpair-sharing');P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');C=Path('/dev/shm/claude-ax-current/final');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();records=[]
common=R/'common';common.mkdir(exist_ok=True)
for p in C.rglob('*'):
 if p.is_file():
  q=common/p.relative_to(C);q.parent.mkdir(parents=True,exist_ok=True)
  if not q.exists():q.symlink_to(p.resolve())
if not (common/'Foundation').exists():(common/'Foundation').symlink_to((C/'Foundation').resolve())
links={
 'ArithmeticEnumBoundTower':'/tmp/cantor-bound-simplify/tower-final/DiophantineConsistency/ArithmeticEnumBoundTower.olean',
 'ArithmeticRuntimeBoundDagMacrosA':'/tmp/cantor-bound-simplify/tower-final/DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.olean',
 'ArithmeticEnumFairPerm222':'/tmp/enum-fair-sharing/final/DiophantineConsistency/ArithmeticEnumFairPerm222.olean',
 'ArithmeticProofWordEnumPerm222':'/tmp/enum-fair-sharing/final/DiophantineConsistency/ArithmeticProofWordEnumPerm222.olean',
 'ArithmeticEnumSoundnessPerm222':'/tmp/enum-fair-sharing/final/DiophantineConsistency/ArithmeticEnumSoundnessPerm222.olean',
 'ArithmeticEnumBoundSoundness':'/tmp/enum-fair-sharing/refresh-final/DiophantineConsistency/ArithmeticEnumBoundSoundness.olean'}
for n,t in links.items():
 q=common/'DiophantineConsistency'/f'{n}.olean';q.unlink(missing_ok=True);q.symlink_to(Path(t).resolve())
provider_receipts=[json.loads(Path('/tmp/cantor-bound-simplify/build-records.json').read_text()),json.loads(Path('/tmp/enum-fair-sharing/records.json').read_text()),json.loads(Path('/tmp/enum-fair-sharing/refresh-cantor-records.json').read_text())]
for n,t in links.items():
 o=Path(t);source=P/f'{n}.lean';matches=[]
 for group in provider_receipts:
  for v in group:
   if v.get('phase')!='final' or v.get('name',v.get('module'))!=n:continue
   before=v.get('before',v.get('source_sha256_before',v.get('current_source_sha256_before')));after=v.get('after',v.get('source_sha256_after',v.get('current_source_sha256_after')))
   if before==after==sha(source) and v.get('object_sha256')==sha(o):matches.append(True)
 if not matches:raise RuntimeError('No current source/provider receipt '+n)

def build(phase,n,src,out,root):
 env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base;deps=[]
 for mod in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  x=next((Path(d)/(mod.replace('.','/')+'.olean') for d in env['LEAN_PATH'].split(':') if (Path(d)/(mod.replace('.','/')+'.olean')).is_file()),None)
  if not x:raise RuntimeError('Missing '+mod)
  deps.append({'module':mod,'path':str(x),'resolved':str(x.resolve()),'before':sha(x)})
 obj=out/'DiophantineConsistency'/f'{n}.olean';obj.unlink(missing_ok=True);log=R/f'{phase}-{n}.log';tm=R/f'{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];h=sha(src);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['after']=sha(d['path'])
 z={'phase':phase,'module':n,'status':r.returncode,'git_head':head,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256_before':h,'source_sha256_after':sha(src),'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'build-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,z['time'].strip(),flush=True)
 if r.returncode or h!=z['source_sha256_after'] or any(d['before']!=d['after'] for d in deps):raise SystemExit(1)
source=P/'ArithmeticRuntimeBoundDagMacrosB.lean';build('common','ArithmeticRuntimeBoundDagMacrosB',source,common,P.parent)
names=['ArithmeticRuntimeBoundDagMacrosC','ArithmeticRuntimeBoundDagMacrosD','ArithmeticRuntimeBoundDagRootA','ArithmeticRuntimeBoundDagRootB','ArithmeticRuntimeBoundDagRootC','ArithmeticRuntimeBoundDagHalt']
for phase in ['baseline','final']:
 out=R/phase;ss=R/'sources'/phase/'DiophantineConsistency';out.mkdir(exist_ok=True);ss.mkdir(parents=True,exist_ok=True)
 for p in common.rglob('*'):
  if p.is_file():
   q=out/p.relative_to(common);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists():q.symlink_to(p.resolve())
 if not (out/'Foundation').exists():(out/'Foundation').symlink_to((common/'Foundation').resolve())
 for n in names:
  source=R/'src/DiophantineConsistency'/f'{n}.lean' if phase=='final' and n==names[0] else P/f'{n}.lean';shutil.copyfile(source,ss/f'{n}.lean')
 for n in names:build(phase,n,ss/f'{n}.lean',out,ss.parent)
