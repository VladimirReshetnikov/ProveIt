from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/unpair-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base
 for name in ['global-simp','targeted-simp']:
  src=R/(name+'.lean');dep=R/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosC.olean';log=R/f'{phase}-{name}.log';tm=R/f'{phase}-{name}.time';h=sha(src);d=sha(dep);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  z={'phase':phase,'name':name,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256_before':h,'source_sha256_after':sha(src),'direct_import':str(dep),'direct_import_sha256_before':d,'direct_import_sha256_after':sha(dep),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'global-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,r.returncode,z['time'].strip(),flush=True);assert r.returncode==0 and h==z['source_sha256_after'] and d==z['direct_import_sha256_after']
read=lambda p,n:{l for l in (R/(p+'-'+n+'.log')).read_text().splitlines() if l.startswith('SIMP ' if n=='global-simp' else 'TARGET ')}
a=read('baseline','global-simp');b=read('final','global-simp');x=read('baseline','targeted-simp');y=read('final','targeted-simp');print('global simp counts',len(a),len(b),'same',a==b,'targeted',len(x),len(y),'all unregistered',all(l.endswith(' false false false false') for l in x|y),flush=True);assert a==b and len(x)==len(y)==29 and all(l.endswith(' false false false false') for l in x|y)
