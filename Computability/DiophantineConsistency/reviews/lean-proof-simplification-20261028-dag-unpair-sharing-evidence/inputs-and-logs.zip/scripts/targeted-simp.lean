import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC
open Lean Elab Command
run_cmd do
 let t ← liftCoreM Lean.Meta.getSimpTheorems
 let ns : List Name := [(Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_1"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_10"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_11"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_12"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_2"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_3"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_4"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_5"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_6"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_7"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_8"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop115M") "_proof_9"),
   (Name.str (Name.str (Name.str (Name.str Name.anonymous "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "loop116M") "_proof_1"),
   (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_1"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_10"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_11"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_12"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_13"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_14"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_15"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_2"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_3"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_4"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_5"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_6"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_7"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_8"),
   (Name.str (Name.str (Name.str (Name.str (Name.num (Name.str (Name.str (Name.str Name.anonymous "_private") "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacrosC") 0) "DiophantineConsistency") "ArithmeticRuntimeBoundDagMacros") "unpair_loopM") "_proof_9")]
 for n in ns do
  logInfo m!"TARGET {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
