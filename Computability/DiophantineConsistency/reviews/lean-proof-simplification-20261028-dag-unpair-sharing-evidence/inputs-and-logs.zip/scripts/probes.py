from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/unpair-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();records=[]
def run(phase,name):
 src=R/(name+'.lean');dep=R/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosC.olean';log=R/f'{phase}-{name}.log';tm=R/f'{phase}-{name}.time';env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];h=sha(src);d=sha(dep);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 z={'phase':phase,'name':name,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256_before':h,'source_sha256_after':sha(src),'direct_import':str(dep),'direct_import_sha256_before':d,'direct_import_sha256_after':sha(dep),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,r.returncode,z['time'].strip(),flush=True);assert r.returncode==0 and h==z['source_sha256_after'] and d==z['direct_import_sha256_after']
for phase in ['baseline','final']:run(phase,'names')
read=lambda p:{x[5:] for x in (R/(p+'-names.log')).read_text().splitlines() if x.startswith('DECL ')}
a=read('baseline');b=read('final');(R/'names-diff.json').write_text(json.dumps({'baseline_count':len(a),'final_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)},indent=2)+'\n');print('names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),flush=True)
common=sorted(a & b);(R/'interfaces.lean').write_text('import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC\nset_option pp.universes true\n'+''.join('#check '+x+'\n#print axioms '+x+'\n' for x in common))
for phase in ['baseline','final']:
 run(phase,'interfaces');run(phase,'simp')
print('common interfaces identical:',(R/'baseline-interfaces.log').read_bytes()==(R/'final-interfaces.log').read_bytes(),'common declarations',len(common));print('simp matches:',set((R/'baseline-simp.log').read_text().splitlines())==set((R/'final-simp.log').read_text().splitlines()))
