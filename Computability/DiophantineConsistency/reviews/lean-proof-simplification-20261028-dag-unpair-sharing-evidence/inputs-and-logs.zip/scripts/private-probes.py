from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/unpair-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 src=R/'private-names.lean';dep=R/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosC.olean';log=R/f'{phase}-private-names.log';tm=R/f'{phase}-private-names.time';env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];h=sha(src);d=sha(dep);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 z={'phase':phase,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256_before':h,'source_sha256_after':sha(src),'direct_import':str(dep),'direct_import_sha256_before':d,'direct_import_sha256_after':sha(dep),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'private-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,r.returncode,z['time'].strip(),flush=True);assert r.returncode==0 and h==z['source_sha256_after'] and d==z['direct_import_sha256_after']
read=lambda p:{x[5:] for x in (R/(p+'-private-names.log')).read_text().splitlines() if x.startswith('DECL ')}
a=read('baseline');b=read('final');print('private names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),flush=True);(R/'private-names-diff.json').write_text(json.dumps({'baseline_count':len(a),'final_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)},indent=2)+'\n')
