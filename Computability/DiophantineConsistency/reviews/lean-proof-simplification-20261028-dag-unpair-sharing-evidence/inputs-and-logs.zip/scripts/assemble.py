from pathlib import Path
import hashlib,json,shutil
R=Path('/tmp/unpair-sharing');E=Path('/tmp/unpair-sharing-evidence');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();x=json.loads((R/'build-records.json').read_text())
for a in x:
 assert a['status']==0 and sha(a['source'])==a['source_sha256_before']==a['source_sha256_after'] and sha(a['object'])==a['object_sha256'] and sha(a['log'])==a['log_sha256'];assert all(d['before']==d['after']==sha(d['path']) and Path(d['path']).resolve()==Path(d['resolved']).resolve() for d in a['direct_inputs']);p=Path(a['source']);dest=E/'sources'/a['phase']/p.name
 if dest.exists():assert sha(dest)==sha(p)
 else:shutil.copy2(p,dest)
for a in json.loads((R/'provider-audit.json').read_text()):
 assert sha(a['source'])==a['source_sha256'] and sha(a['object'])==a['object_sha256'];shutil.copy2(a['source'],E/'sources/providers'/Path(a['source']).name)
for f in ['build-records.json','provider-audit.json','probe-records.json','private-probe-records.json','global-probe-records.json','global-probe-initial-failed.json','reference-search-records.json','names-diff.json','private-names-diff.json']:
 shutil.copy2(R/f,E/'records'/f)
for p in R.iterdir():
 if p.is_file() and p.suffix in ['.log','.time']:shutil.copy2(p,E/'logs'/p.name)
for f in ['build-audit.py','probes.py','private-probes.py','global-probes.py','reference-search.py','names.lean','interfaces.lean','simp.lean','private-names.lean','global-simp.lean','targeted-simp.lean','targeted-simp-failed.lean','removed-short-names.txt','generic.txt']:
 shutil.copy2(R/f,E/'scripts'/f)
for f,dest in [('/tmp/cantor-bound-simplify/build-records.json','cantor-build-records.json'),('/tmp/enum-fair-sharing/records.json','scheduler-build-records.json'),('/tmp/enum-fair-sharing/refresh-cantor-records.json','scheduler-refreshed-client-records.json')]:shutil.copy2(f,E/'provenance'/dest)
print('verified',len(x),'build records and',sum(len(a['direct_inputs']) for a in x),'direct-input occurrences')
