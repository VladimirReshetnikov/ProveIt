import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if n.toString.startsWith "_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC." then
   logInfo m!"DECL {n}"
