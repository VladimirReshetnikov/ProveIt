from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/tmp/unpair-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pattern=R/'removed-short-names.txt';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();commands=[('tracked',['git','grep','-n','-F','-f',str(pattern),'--','*.lean','*.py']),('local-diophantine',['rg','--line-number','--fixed-strings','--file',str(pattern),'--glob','*.lean','--glob','*.py','Computability/DiophantineConsistency/Lean','Computability/DiophantineConsistency/tools'])];records=[]
for name,cmd in commands:
 log=R/f'reference-search-{name}.log';h=sha(pattern);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 rec={'scope':name,'command':cmd,'status':r.returncode,'head_before':head,'head_after':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'pattern_sha256_before':h,'pattern_sha256_after':sha(pattern),'log_sha256':sha(log),'elapsed':round(time.monotonic()-t,2)};records.append(rec);(R/'reference-search-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,'lines',len(log.read_text().splitlines()),flush=True);assert r.returncode in [0,1] and head==rec['head_after'] and h==rec['pattern_sha256_after']
