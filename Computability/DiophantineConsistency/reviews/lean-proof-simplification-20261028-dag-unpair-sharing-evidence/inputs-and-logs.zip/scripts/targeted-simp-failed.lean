import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC
open Lean Elab Command
run_cmd do
 let t ← liftCoreM Lean.Meta.getSimpTheorems
 let ns : List Name := [`DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_1,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_10,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_11,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_12,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_2,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_3,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_4,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_5,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_6,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_7,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_8,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop115M._proof_9,
   `DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.loop116M._proof_1,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_1,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_10,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_11,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_12,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_13,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_14,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_15,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_2,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_3,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_4,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_5,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_6,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_7,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_8,
   `_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosC.0.DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.unpair_loopM._proof_9]
 for n in ns do
  logInfo m!"TARGET {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
