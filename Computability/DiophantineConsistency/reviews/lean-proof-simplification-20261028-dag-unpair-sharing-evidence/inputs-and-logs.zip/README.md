# Shared bounded unpair walk

28 October 2026. This isolated candidate replaces the repeated bounded proofs
for `loop115M` (unpair the `pl` register) and `loop116M` (unpair the `ws`
register) in `ArithmeticRuntimeBoundDagMacrosC.lean` with one private
Boolean-indexed unpair walk and two specializations. The original theorem
statements, source-register choices, DAG nodes and `tower j (L+13)` clock
bounds are retained; no import changes. The module changes from 244 to 207
lines. Commit `ca0c31b62d`, which introduced the module, has a Claude coauthor
trailer and is recorded in `provenance/origin-commit.txt`.

## Paired validation

After rebuilding common Macro B against the adopted tower and Macro A
providers, paired baseline/final builds passed for Macro C, its direct Macro D
client, Root A–C and `ArithmeticRuntimeBoundDagHalt`. The five unchanged-source
clients D through Halt produced byte-identical objects and logs between phases.
`records/build-records.json` records all 13 builds, source before/after hashes,
17 direct-input before/after hashes and resolved paths, object hashes, commands,
LEAN_PATH, logs and elapsed/user/system/max-RSS measurements. The copied source
snapshots match the corresponding receipts. In a single local paired run,
Macro C used 6.50 seconds baseline and 6.71 seconds final user CPU; this is not
a repeated benchmark or a universal performance claim.

The affected namespace has 129 baseline and 116 final declarations. All 116
common declarations have byte-identical type and axiom reports. The 13 removed
names are the Lean-generated `loop115M._proof_1` through `_proof_12` and
`loop116M._proof_1`; no new public namespace names were introduced. The
separate private-name census has 22 original names retained and 16 additions:
the private `unpair_loopM` helper and 15 generated auxiliaries. Exact names are
preserved in `records/names-diff.json` and `records/private-names-diff.json`.

The full-environment default-simp census produced the same set of 29,279
entries in each phase. An additional exact-name probe confirms all 13 removed
generated names and all 16 newly added private names are absent from the
default simp set in both phases. Commands, source and direct-import hashes,
logs and measurements are in `records/global-probe-records.json`. The first
attempt at this probe failed because a quoted private name contained a numeric
component. Its source, log and failing receipt are retained as
`targeted-simp-failed.lean`, `baseline-targeted-simp-failed.log`, and
`global-probe-initial-failed.json`; the final probe builds the names explicitly
and passed. The first draft of the generic unpair proof also failed to elaborate;
`logs/attempt1.log` is retained, but that draft source was overwritten and is
not represented as a successful build. `logs/attempt2.log` is the successful
prototype build; the source and auditable paired build receipts are retained.

Reference searches for the 13 short generated names returned no matches in
tracked Lean/Python files across the repository, and no matches in the local
DiophantineConsistency Lean and tools trees, including untracked files. Exact
commands, patterns, commit, statuses and empty logs are in
`records/reference-search-records.json`, `scripts/removed-short-names.txt`
and `logs/reference-search-*.log`. These scopes do not cover untracked files
outside those local trees, ignored caches, or external clients.

## Provider limits

`records/provider-audit.json` ties six refreshed upstream objects to source and
object hashes from prior tested-build receipts, including the adopted Cantor
tower/Macro A and scheduler providers. Their source snapshots and those prior
receipts are under `sources/providers/` and `provenance/`. Direct input hashes
were captured before and after each new build. Other project, Foundation and
Lean/toolchain objects are cached; this is not a clean source rebuild of the
entire transitive closure or a test of every downstream client. Scripts retain
the original absolute temporary paths and require their original overlays.
No repository files were modified by this prototype. Compiled objects are
excluded. `manifest.sha256` covers every other file in the package.
