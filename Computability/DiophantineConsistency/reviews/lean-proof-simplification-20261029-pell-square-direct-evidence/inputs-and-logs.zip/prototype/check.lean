import DiophantineConsistency.ArithmeticPellClassification
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
#check mul_self_le_mul_self_iff
#check Arithmetic.sq_le_sq
#check _root_.mul_self_le_mul_self_iff
