from pathlib import Path
import subprocess,hashlib,json
r=Path('/tmp/pell-square-direct');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');common=r/'common';common.mkdir(exist_ok=True);subprocess.run(['cp','-as','/tmp/pell-balance-sharing/objects-final/DiophantineConsistency',str(common/'DiophantineConsistency')],check=True)
q=common/'DiophantineConsistency/ArithmeticModularCancellation.olean';q.unlink(missing_ok=True);q.symlink_to('/tmp/shared-modular-cancel/probe/DiophantineConsistency/ArithmeticModularCancellation.olean')
names=['ArithmeticPellClassification','ArithmeticPellClassificationChecks','ArithmeticPellCongruences','ArithmeticPellKnownUnit','ArithmeticPellKnownUnitChecks','ArithmeticPellCommonUnit','ArithmeticPellPeriodicity','ArithmeticPellResidueClasses','ArithmeticPellIntegralSolution','ArithmeticPellIndexDivisibility','ArithmeticPellHalfIndex','ArithmeticPellFirstNorm','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex','ArithmeticPellPowerRecovery'];changed={'ArithmeticPellClassification','ArithmeticPellKnownUnit','ArithmeticPellFirstNorm'};h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();info={}
for ph in ('baseline','final'):
 s=r/ph/'DiophantineConsistency';s.mkdir(parents=True,exist_ok=True)
 for n in names:
  out=s/(n+'.lean')
  if ph=='baseline' or n not in changed:out.write_bytes((w/(n+'.lean')).read_bytes())
  info[ph+'/'+n]={'path':str(out),'sha256':h(out),'workspace':str(w/(n+'.lean')),'workspace_sha256':h(w/(n+'.lean'))}
(r/'snapshot-record.json').write_text(json.dumps(info,indent=2)+'\n')
