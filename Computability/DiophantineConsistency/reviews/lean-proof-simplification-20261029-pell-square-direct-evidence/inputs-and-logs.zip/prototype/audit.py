from pathlib import Path
import json,hashlib,re
r=Path('/tmp/pell-square-direct');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());rows={};providers={};changed={'ArithmeticPellClassification','ArithmeticPellKnownUnit','ArithmeticPellFirstNorm'};snap=get('snapshot-record.json')
refs=[('ArithmeticPellRecurrence','/tmp/pell-balance-sharing/final-targets-records.json'),('ArithmeticGcdNormalization','/tmp/pell-reflection-simp/refresh-records.json'),('ArithmeticModularCancellation','/tmp/shared-modular-cancel/records.json'),('ArithmeticPellStrongDivisibility','/tmp/pell-balance-sharing/final-combined-records.json')]
for n,f in refs:
 x=next(x for x in json.loads(Path(f).read_text()) if x['module'].endswith(n));sh=x.get('before',x.get('source_before'));ah=x.get('after',x.get('source_after'));assert x['status']==0 and sh==ah==h(w/(n+'.lean'));p=r/'common/DiophantineConsistency'/(n+'.olean');assert h(p)==x['object_sha256'];providers[n]=x['object_sha256'];print('producer',n,sh,providers[n])
for ph in ('baseline','final'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source'])==snap[ph+'/'+n]['sha256'] and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text();assert snap[ph+'/'+n]['workspace_sha256']==h(w/(n+'.lean'))
  if ph=='baseline' or n not in changed:assert x['before']==h(w/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source']);name=d['module'].split('.')[-1]
   if name in providers:assert d['before']==providers[name] and d['source_before']==h(w/(name+'.lean'))
   else:assert d['before']==rows[ph,name]['object_sha256'] and d['source_before']==rows[ph,name]['before'] and d['resolved']==rows[ph,name]['object']
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
 for x in get(ph+'-probes.json'):
  expected=[rows[ph,n]['object_sha256'] for n in ('ArithmeticPellClassification','ArithmeticPellKnownUnit','ArithmeticPellFirstNorm')];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==expected and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for ph in ('baseline','final'):assert len(get(ph+'-records.json'))==15
for n in rows.keys():pass
for n in ('ArithmeticPellClassificationChecks','ArithmeticPellCongruences','ArithmeticPellKnownUnitChecks','ArithmeticPellCommonUnit','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex','ArithmeticPellPowerRecovery'):
 a=rows['baseline',n]['object_sha256'];b=rows['final',n]['object_sha256'];print('client',n,'identical',a==b,a,b)
def decl(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(r/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decl('baseline'),decl('final');print('declarations baseline/final',len(a),len(b));print('removed',list(a.keys()-b.keys()));print('added',list(b.keys()-a.keys()));print('changed',[k for k in a.keys()&b.keys() if a[k]!=b[k]])
for n in ('simp','instances'):
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b;print(n,len(a.splitlines()),'identical')
a,b=decl('baseline'),decl('final');rm={f'_private.DiophantineConsistency.{n}.0.DiophantineConsistency.{n}.square_le' for n in ('ArithmeticPellClassification','ArithmeticPellKnownUnit','ArithmeticPellFirstNorm')};assert a.keys()-b.keys()==rm and not b.keys()-a.keys() and len(b)==32 and all(a[k]==b[k] for k in b)
for name in rm:
 for ph in ('baseline','final'):
  for kind in ('simp','instances'):assert name not in (r/f'{ph}-{kind}.log').read_text()
print('exact three private wrappers removed, no added names, unregistered')
for ph in ('baseline','final'):
 for x in get(ph+'-records.json'):
  if x['module'] not in changed:assert rows['baseline',x['module']]['object_sha256']==rows['final',x['module']]['object_sha256'];assert 'warning:' not in Path(x['log']).read_text()
print('all 12 unchanged outputs identical; 30 logs contain no warnings')
needle='''private theorem square_le (x z : V) (h : x*x≤z*z) : x≤z := by
  by_contra hn
  exact (not_lt_of_ge h) (mul_self_lt_mul_self (by simp) (lt_of_not_ge hn))

'''
for n in changed:
 a=(r/'baseline/DiophantineConsistency'/(n+'.lean')).read_text();b=(r/'final/DiophantineConsistency'/(n+'.lean')).read_text();assert a.count(needle)==1 and b==a.replace(needle,'').replace('apply square_le','apply nonneg_le_nonneg_of_sq_le_sq (Arithmetic.zero_le _)');print('exact wrapper removal and direct substitution',n)
