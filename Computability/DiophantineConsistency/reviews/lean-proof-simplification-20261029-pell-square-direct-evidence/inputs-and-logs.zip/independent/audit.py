from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/tmp/pell-square-direct');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
changed={'ArithmeticPellClassification':2,'ArithmeticPellKnownUnit':3,'ArithmeticPellFirstNorm':1}
old='''private theorem square_le (x z : V) (h : x*x≤z*z) : x≤z := by
  by_contra hn
  exact (not_lt_of_ge h) (mul_self_lt_mul_self (by simp) (lt_of_not_ge hn))

'''
for name,count in changed.items():
 b=(R/'baseline/DiophantineConsistency'/f'{name}.lean').read_text();f=(R/'final/DiophantineConsistency'/f'{name}.lean').read_text();assert b.count(old)==1 and b.count('apply square_le')==count
 assert b.replace(old,'').replace('apply square_le','apply nonneg_le_nonneg_of_sq_le_sq (Arithmetic.zero_le _)')==f
 rel=f'Computability/DiophantineConsistency/Lean/DiophantineConsistency/{name}.lean'
 assert subprocess.check_output(['git','show',f'c66364f0e2^:{rel}']).decode()==b and subprocess.check_output(['git','show',f'c66364f0e2:{rel}']).decode()==f and (W/f'{name}.lean').read_text()==f
 print('PASS exact private wrapper removal, commit/parent and',count,'direct uses',name)
paths={'ArithmeticPellRecurrence':'/tmp/pell-balance-sharing/final-targets-records.json','ArithmeticGcdNormalization':'/tmp/pell-reflection-simp/refresh-records.json','ArithmeticModularCancellation':'/tmp/shared-modular-cancel/records.json','ArithmeticPellStrongDivisibility':'/tmp/pell-balance-sharing/final-combined-records.json'};providers={}
for n,path in paths.items():
 x=next(x for x in read(path) if x['module'].split('.')[-1]==n);before=x.get('before') or x.get('source_before');after=x.get('after') or x.get('source_after');assert x['status']==0 and before==after==h(W/(n+'.lean'));providers[n]=x['object_sha256'];print('PASS prior source/object provider pair',n,before,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert len(rows)==len(rec[phase])
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module'] not in changed:assert x['before']==h(W/(x['module']+'.lean'))
  imports=re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M);assert imports==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file())
   assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d['source_before'] is not None:assert d['source_before']==d['source_after']==h(d['source'])
   mod=d['module'].split('.')[-1]
   if mod in rec[phase]:assert d['before']==rec[phase][mod]['object_sha256']
   else:assert d['before']==providers[mod]
  print('PASS build',phase,x['module'],x['time'].strip())
print('PASS build and first-provider pins; external source/object association separately verified via prior receipts')
assert len(rec['baseline'])==len(rec['final'])==15 and set(rec['baseline'])==set(rec['final'])
edges={}
for n in changed:
 clients=sorted(p.stem for p in W.glob('*.lean') if re.search(r'^import DiophantineConsistency\.'+re.escape(n)+r'$',p.read_text(),re.M));edges[n]=clients
assert edges=={'ArithmeticPellClassification':['ArithmeticPellClassificationChecks','ArithmeticPellCongruences','ArithmeticPellKnownUnit'],'ArithmeticPellKnownUnit':['ArithmeticPellCommonUnit','ArithmeticPellFirstNorm','ArithmeticPellKnownUnitChecks'],'ArithmeticPellFirstNorm':['ArithmeticPellFirstIndex','ArithmeticPellFirstNormChecks']}
assert all(c in rec['baseline'] and c in rec['final'] for clients in edges.values() for c in clients)
print('PASS direct module source clients covered',edges)
for n in set(rec['baseline'])-set(changed):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS all 12 downstream object pairs identical')
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][n]['object_sha256'] for n in changed] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
def blocks(p):
 s=Path(p).read_text();return {t.split(' TYPE ',1)[0]:'DECL '+t for t in re.split(r'(?m)^DECL ',s)[1:]}
a=blocks(R/'baseline-interfaces.log');z=blocks(R/'final-interfaces.log');removed=set(a)-set(z);assert len(removed)==3 and not(set(z)-set(a)) and all(n.endswith('.square_le') for n in removed) and all(a[n]==z[n] for n in z)
for n in ('simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes() and all(q not in (R/f'baseline-{n}.log').read_text() for q in removed)
print('PASS three-object-pinned probes;',len(z),'common type/axiom blocks, 3 removed private names, unchanged simp and instances')
