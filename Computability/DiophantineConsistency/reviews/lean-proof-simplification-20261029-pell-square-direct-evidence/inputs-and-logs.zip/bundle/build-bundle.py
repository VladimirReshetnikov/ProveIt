from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs');R=Path('/tmp/pell-square-direct')
D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-pell-square-direct-evidence';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();items={}
def add(n,p):assert n not in items;items[n]=Path(p).read_bytes()
def git(p,rev):return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=ROOT)
rev='c66364f0e253ddb8acd543985be3181bd054d435';parent='2788bd4b56368b91f54f72c4f1a703ab53523c4f';mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
changed=['ArithmeticPellClassification','ArithmeticPellKnownUnit','ArithmeticPellFirstNorm']
for n in changed:
 for phase,ref in [('baseline',parent),('final',rev)]:
  key='commit/'+phase+'/'+n+'.lean';items[key]=git(mod+n+'.lean',ref);assert items[key]==(R/phase/'DiophantineConsistency'/(n+'.lean')).read_bytes()
for n in ['ArithmeticPellRecurrence','ArithmeticGcdNormalization','ArithmeticPellStrongDivisibility','ArithmeticModularCancellation']:
 items['provider-sources/'+n+'.lean']=git(mod+n+'.lean',rev)
for f in sorted(R.rglob('*')):
 if f.is_file() and f.suffix not in ('.olean','.ilean','.c') and not any(x.startswith('objects-') or x=='common' for x in f.relative_to(R).parts):add('prototype/'+f.relative_to(R).as_posix(),f)
for n,p in {
 'prior/pell-recurrence-final-targets.json':'/tmp/pell-balance-sharing/final-targets-records.json',
 'prior/gcd-normalization-refresh.json':'/tmp/pell-reflection-simp/refresh-records.json',
 'prior/modular-cancellation-records.json':'/tmp/shared-modular-cancel/records.json',
 'prior/pell-strong-divisibility-combined.json':'/tmp/pell-balance-sharing/final-combined-records.json',
 'independent/review.txt':'/tmp/pell-square-direct-peer-review.txt',
 'independent/audit.py':'/tmp/pell-square-direct-peer-audit.py',
 'independent/audit.log':'/tmp/pell-square-direct-peer-audit.log',
 'independent/audit-preliminary.log':'/tmp/pell-square-direct-peer-audit-preliminary.log',
 'independent/audit-inflight.log':'/tmp/pell-square-direct-peer-audit-inflight.log',
 'bundle/build-bundle.py':'/tmp/build-pell-square-direct-bundle.py'}.items():add(n,p)
zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):
  info=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Replace three private square-order wrappers with the existing direct nonnegative square inequality lemma',
'validation':'Both 15-module dependency-ordered lanes pass with phase-specific direct object pins and current-source external producer mappings. All eight distinct direct source clients are covered; all 12 unchanged downstream object pairs match. Combined probes pin all three changed objects and show 32 matching surviving declaration/type/axiom reports, exactly three removed private wrappers, no additions and identical global simp and instance reports.',
'limitations':['The three private square_le declarations disappear. A tracked Lean/Python qualified-name search in the research area found no references; untracked files, other file types, dynamic names and downstream environments are outside that search.', 'Matching declaration and registration reports do not establish proof-body or all persistent-environment-extension equality. Wider project, Foundation and Mathlib dependencies remain cached; direct-source producer matches do not prove a complete fresh closure.', 'The superseded iff-based variant compiled provisionally only for Classification, without contemporaneous before/after input pins. Its sources and exploratory log/time are preserved.', 'One shared-load paired timing sample is not a general benchmark. The independent preliminary audit log terminates because final records did not yet exist; the completed postcommit independent audit supersedes it.', 'Compiled objects are omitted; receipts preserve their hashes and first-provider paths, and independent byte verification requires external objects.'],
'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(items)
 for n,b in items.items():assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes();print(n,sha(b),len(b))
