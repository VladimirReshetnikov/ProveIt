from pathlib import Path
import json,hashlib,re
r=Path('/tmp/wang-initial-sharing');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rs=[]
for name in ('records.json','client-records.json'):
 for x in json.loads((r/name).read_text()):
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']);tm=Path(x['command'][x['command'].index('-o')+1]);assert x['time']==tm.read_text()
  if x['phase']=='baseline' or x['module'] not in ('ArithmeticWangPlane','ArithmeticWangSoundness','ArithmeticRunTrace'):assert x['before']==h(repo/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
   if d['module'].split('.')[-1] in ('ArithmeticWangPlane','ArithmeticWangStrip','ArithmeticWangRowStep','ArithmeticRunTrace'):assert d['resolved']==str(r/('objects-'+x['phase'])/'DiophantineConsistency'/(d['module'].split('.')[-1]+'.olean'))
  rs.append(x);print(name,x['phase'],x['module'],len(x['direct_inputs']),'inputs verified')
for f in ('probe-records.json','client-probe-records.json'):
 for x in json.loads((r/f).read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(x['log'])
  for d in x['objects']:assert d['before']==d['after']==h(d['path'])
  print('probe',x['phase'],x['probe'],len(x['objects']),'objects verified')
prev=json.loads(Path('/tmp/fin-one-simplification/full-fresh-records.json').read_text())
for n in ('ArithmeticWangTable','ArithmeticMachineRun215'):
 x=next(x for x in prev if x['module'].endswith('.'+n));o=Path('/tmp/fin-one-simplification/trace-full-fresh/DiophantineConsistency')/(n+'.olean');assert x['status']==0 and x['source_sha256']==h(repo/(n+'.lean')) and x['object_sha256']==h(o);print('provider',n,'prior source/object match')
def parse(p):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',p.read_text(),re.M|re.S)}
a=parse(r/'baseline-interfaces.log');b=parse(r/'final-interfaces.log');assert len(a)==148 and not a.keys()-b.keys() and all(a[n]==b[n] for n in a);assert b.keys()-a.keys()=={'DiophantineConsistency.ArithmeticWangPlane.initial_action','DiophantineConsistency.ArithmeticWangPlane.initial_action._proof_1','DiophantineConsistency.ArithmeticWangPlane.initial_run_one'}
for name in ('simp','instances','client-interfaces','client-simp','client-instances'):assert (r/f'baseline-{name}.log').read_bytes()==(r/f'final-{name}.log').read_bytes();print(name,'equal')
assert len(parse(r/'baseline-client-interfaces.log'))==73
assert (r/'baseline-short-names.log').read_text()=='' and set((r/'final-short-names.log').read_text().splitlines())=={'SHORT DiophantineConsistency.ArithmeticWangPlane.initial_action','SHORT DiophantineConsistency.ArithmeticWangPlane.initial_run_one'}
print('12 builds',sum(len(x['direct_inputs']) for x in rs),'direct inputs, 15 probes verified; common declarations 148 and client 73')
