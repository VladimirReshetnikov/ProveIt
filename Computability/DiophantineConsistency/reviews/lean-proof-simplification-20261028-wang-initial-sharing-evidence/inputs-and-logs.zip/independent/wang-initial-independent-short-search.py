from pathlib import Path
import subprocess,json,hashlib
p=Path('/tmp/wang-initial-independent-short-search.log');cmd=['rg','-n',r'^\s*(?:(?:private|protected|noncomputable|unsafe|partial)\s+)*(?:theorem|lemma|def|abbrev|instance|opaque)\s+(?:\S+\.)?(initial_action|initial_run_one)\b','--glob','*.lean']
with p.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
x={'command':cmd,'status':q.returncode,'bytes':p.stat().st_size,'log':str(p),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'ripgrep default repository traversal, .lean files; excludes ignored/hidden files and dynamically generated names'};Path('/tmp/wang-initial-independent-short-search.json').write_text(json.dumps(x,indent=2)+'\n');assert q.returncode==1 and p.stat().st_size==0;print('status',q.returncode,'no matches before adoption')
