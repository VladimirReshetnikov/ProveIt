import DiophantineConsistency.ArithmeticWangSoundness
import DiophantineConsistency.ArithmeticRunTrace
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  let s := toString n
  if s == "initial_action" || s.endsWith ".initial_action" ||
     s == "initial_run_one" || s.endsWith ".initial_run_one" then
   logInfo m!"SHORT {n}"
