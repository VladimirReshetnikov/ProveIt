# Shared initial K215 action and first step

This is an isolated prototype; no repository files were changed. The final
candidate snapshots and SHA-256 hashes are:

- `final/DiophantineConsistency/ArithmeticWangPlane.lean`: `fa4d7e4c552cc4e5062dc206aa1b4cf0ab00ecd76adb02dd2f67c70da12d0106`.
- `final/DiophantineConsistency/ArithmeticWangSoundness.lean`: `ab60524c7c5ca33443db3aec90c67d9875a306e5ead1f93eedf2c95776519a2e`.
- `final/DiophantineConsistency/ArithmeticRunTrace.lean`: `34dd933850c9451ab3d8f98f2075d9f80803ffa05982ddaae0c7b3880254b4c4`.

Plane defines the shared `initial_action` and `initial_run_one`. The existing
`ArithmeticRunTrace.act_zero` and both modules' existing `run_one` statements
remain as aliases, with the original helper statements retained. Imports and
existing definitions are unchanged. The original 820 total Lean lines in
these three files become 812; the larger gain is eliminating duplicated
reasoning, at the cost of two new public theorems and a generated
`initial_action._proof_1` declaration.

`records.json` records paired successful source-pinned builds, in order, of
WangPlane, WangStrip, WangRowStep, WangSoundness and RunTrace. Each rebuilt
module's direct imports resolve to the appropriate phase object. Plane's
ArithmeticWangTable object (`38be26da…`) and ArithmeticMachineRun215 object
(`9cd4ca9d…`) match current-source, successful earlier receipts in
`/tmp/fin-one-simplification/full-fresh-records.json`. Other transitive
providers, including Foundation/Mathlib, remain cached. Shared-load baseline/
final user CPU seconds were 16.11/16.68 (Plane), 7.57/7.44 (Strip),
21.65/21.59 (RowStep), 44.12/43.71 (Soundness), and 16.90/16.19 (RunTrace).
These single samples are not a controlled benchmark.

The direct client ArithmeticTilingTable passed paired builds, as recorded in
`client-records.json` (9.10/9.07 user seconds). Its baseline and final object
hashes differ (`a6af59cc…` vs `552b8777…`). Six `client-probe-records.json`
receipts pin each phase's Plane, RunTrace and TilingTable objects. All 73
existing TilingTable public/private declaration/type/axiom reports, 29,730
simp entries and 13,383 instance entries match byte-for-byte.

The nine co-import probes in `probe-records.json` import WangSoundness and
RunTrace and pin those objects plus Plane. All 148 old public/private
declaration/type/axiom reports match; the three new names above are added.
Global simp (29,730) and instance (13,383) reports match. The short-name
census searches every declaration in that particular imported environment:
it finds only the two new Plane declarations with their respective short
names. `opens.lean` successfully resolves the two helpers and the three
qualified retained statements with all three project namespaces open. A
repository-wide declaration search found no other same-short-name definitions;
these tests do not rule out collisions in arbitrary other co-imports or
persistent environment extensions beyond simp/instances.

`v1/` is the earlier, uncompiled one-helper prototype. It moved only the
first-step proof and left act_zero duplicated, reducing the three-file total by
three lines; it was superseded by the final two-helper variant. A preliminary
final Plane build passed; its log, timing and copied object are kept as
`final-plane-preliminary.*` and `preliminary/ArithmeticWangPlane.olean`.
The subsequent paired builds are the validation above. No merged or deployed
change is implied.
