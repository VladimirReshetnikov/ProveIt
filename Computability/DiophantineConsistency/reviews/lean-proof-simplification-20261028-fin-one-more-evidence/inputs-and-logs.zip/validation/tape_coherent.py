from pathlib import Path
import os,subprocess,time,json,hashlib
b=Path('/tmp/fin-one-more');old=Path('/tmp/machine-tape215-root-bbarbz31/lib');env=os.environ.copy();rec=[];n='ArithmeticMachineTape215';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ['baseline','final']:
 d=b/n/phase;lib=d/'coherent-lib';lib.mkdir(exist_ok=True)
 for k in ['Foundation','FirstOrder','BusyBeaver']:(lib/k).symlink_to(old/k,target_is_directory=True)
 dr=lib/'DiophantineConsistency';dr.mkdir(exist_ok=True)
 for f in (old/'DiophantineConsistency').iterdir():
  if f.name!=n+'.olean':(dr/f.name).symlink_to(f.resolve())
 src=d/'source'/'DiophantineConsistency'/(n+'.lean');out=dr/(n+'.olean');log=d/'coherent-target.log';tm=d/'coherent-target.time';e=env.copy();e['LEAN_PATH']=str(lib)+':'+env['LEAN_PATH'];cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(d/'source'),str(src),'-o',str(out)];t=time.monotonic();r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm)]+cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'module':n,'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'time':tm.read_text().strip(),'source_sha256':sha(src),'object_sha256':sha(out) if out.exists() else None,'log_sha256':sha(log)});(b/'tape-coherent-build-records.json').write_text(json.dumps(rec,indent=2));print(n,phase,r.returncode,rec[-1]['time'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
