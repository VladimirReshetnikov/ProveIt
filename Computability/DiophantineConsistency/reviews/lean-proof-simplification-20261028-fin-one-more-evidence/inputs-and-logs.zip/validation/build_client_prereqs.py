from pathlib import Path
import subprocess,os,time,hashlib,json
b=Path('/tmp/fin-one-more');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');env=os.environ.copy();env['LEAN_PATH']=str(b/'shared')+':'+env['LEAN_PATH'];records=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['ArithmeticGcdNormalization','ArithmeticBinaryCarry']:
 src=root/(n+'.lean');out=b/'shared'/'DiophantineConsistency'/(n+'.olean');log=b/(n+'.log');tm=b/(n+'.time');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(out)];t=time.monotonic();r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm)]+cmd,env=env,stdout=log.open('w'),stderr=subprocess.STDOUT);records.append({'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'time':tm.read_text().strip(),'source_sha256':h(src),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log)});(b/'client-prereq-records.json').write_text(json.dumps(records,indent=2));print(n,r.returncode,records[-1]['time'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 for target in ['ArithmeticPellRecurrence','ArithmeticRepunit']:
  for phase in ['baseline','final']:
   dr=b/target/phase/'lib'/'DiophantineConsistency';q=dr/(n+'.olean')
   if dr.exists() and not q.exists():q.symlink_to(out)
