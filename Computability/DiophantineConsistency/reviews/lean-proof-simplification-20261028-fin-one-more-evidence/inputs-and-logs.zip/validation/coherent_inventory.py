from pathlib import Path
import re,json,hashlib
b=Path('/tmp/fin-one-more');ov=b/'shared';roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('/home/codex/src/Proofs/lib/FormalizedFormalLogic-Foundation'),Path('Logic/FirstOrder/Lean')];tape=json.loads(Path('/tmp/machine-tape215-root-bbarbz31/inputs.json').read_text());known={}
for m in tape['profile']['modules']:
 if isinstance(m.get('source'),dict):known.setdefault(m['module'],[]).append({'source':m['source']['sha256'],'objects':[o['sha256'] for o in m.get('objects',[]) if o['path'].endswith('.olean')],'receipt':'/tmp/machine-tape215-root-bbarbz31/inputs.json'})
for z in json.loads(Path('/tmp/fin-one-simplification/pins.json').read_text()):
 for m in z['modules']:known.setdefault(m['module'],[]).append({'source':m['expected_source_sha256'],'objects':[o['expected_sha256'] for o in m['objects'] if o['path'].endswith('.olean')],'receipt':z['manifest']})
for m,r in json.loads(Path('/tmp/fin-one-simplification/trace-full-classified.json').read_text()).items():
 if r['provenance']['category']!='pending target' and r['object_sha256']:known.setdefault(m,[]).append({'source':r['source_sha256'],'objects':[r['object_sha256']],'receipt':'/tmp/fin-one-simplification/trace-full-classified.json'})
r=json.loads((b/'binary-record.json').read_text());known.setdefault(r['module'],[]).append({'source':r['source_sha256'],'objects':[r['object_sha256']],'receipt':str(b/'binary-record.json')})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for target in ['ArithmeticPellRecurrence','ArithmeticRepunit','ArithmeticMachineTape215']:
 ov=Path('/tmp/machine-tape215-root-bbarbz31/lib') if target=='ArithmeticMachineTape215' else b/'shared'
 seen={}
 def visit(n):
  if n in seen:return
  rel=n.replace('.','/');src=next((r/(rel+'.lean') for r in roots if (r/(rel+'.lean')).exists()),None)
  if src is None:return
  deps=re.findall(r'^(?:public\s+)?(?:meta\s+)?import\s+((?:DiophantineConsistency|BusyBeaver|Foundation|FirstOrder)(?:\.\w+)+)',src.read_text(),re.M);obj=ov/(rel+'.olean');obj=obj if obj.exists() else Path('.lake/build/lib/lean')/(rel+'.olean');ss=sha(src);oo=sha(obj) if obj.exists() else None;match=[x['receipt'] for x in known.get(n,[]) if x['source']==ss and oo in x['objects']];seen[n]={'source':str(src.resolve()),'source_sha256':ss,'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':oo,'matching_receipts':match,'imports':deps}
  for d in deps:visit(d)
 visit('DiophantineConsistency.'+target);(b/(target+'-coherent-inventory.json')).write_text(json.dumps(seen,indent=2));un=[n for n,v in seen.items() if v['object'] and not v['matching_receipts']];missing=[n for n,v in seen.items() if not v['object']];print(target,'modules',len(seen),'unmatched',len(un),'missing',len(missing));print('unmatched',un[:20]);print('missing',missing[:20])
