from pathlib import Path
import re,json
b=Path('/tmp/fin-one-more');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');ov=b/'shared';old=Path('/tmp/fin-one-simplification/trace-full-fresh');ov.mkdir(exist_ok=True)
for m in ['Foundation','FirstOrder','BusyBeaver']:(ov/m).symlink_to(old/m,target_is_directory=True)
d=ov/'DiophantineConsistency';d.mkdir(exist_ok=True)
for f in (old/'DiophantineConsistency').iterdir():
 if f.is_file():(d/f.name).symlink_to(f.resolve())
for n in ['ArithmeticPellRecurrence','ArithmeticRepunit','ArithmeticMachineTape215']:
 s=(repo/(n+'.lean')).read_text();t=re.sub(r'(have he : \(fun i : Fin 1 => e i\.succ\.succ\)\s*=\s*!\[e 2\] :=) by\n    funext i\n    have hi : i\s*=\s*0 := Subsingleton\.elim _ _\n    subst i\n    rfl',r'\1 funext <| Fin.forall_fin_one.mpr rfl',s);assert s!=t,n
 for phase,text in [('baseline',s),('final',t)]:
  p=b/n/phase/'source'/'DiophantineConsistency'/(n+'.lean');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 print(n,'lines',len(s.splitlines())-len(t.splitlines()))
