from pathlib import Path
import re,os,subprocess,time,json,hashlib
b=Path('/tmp/fin-one-more');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');env=os.environ.copy();records=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
clients={'ArithmeticPellRecurrence':['ArithmeticPellRecurrenceChecks','ArithmeticPellClassification','ArithmeticPellStrongDivisibility'],'ArithmeticRepunit':['ArithmeticMaskPopulation','ArithmeticWindowDigits'],'ArithmeticMachineTape215':['ArithmeticMachineTape215Checks','ArithmeticRegisterBoxes215']}
for n in clients:
 probe=b/n/'Axioms.lean'
 for phase in ['baseline','final']:
  d=b/n/phase;lib=d/('coherent-lib' if n=='ArithmeticMachineTape215' else 'lib');e=env.copy();e['LEAN_PATH']=str(lib)+':'+env['LEAN_PATH']
  for name in ['axioms']+clients[n]:
   src=probe if name=='axioms' else root/(name+'.lean');log=d/(name+'.check.log');out=lib/'DiophantineConsistency'/(name+'.olean');cmd=['lean','-M6000','-j1','-DElab.async=false']
   if name!='axioms':
    cmd+=['-R','Computability/DiophantineConsistency/Lean']
    if out.is_symlink():out.unlink()
   cmd.append(str(src))
   if name!='axioms':cmd+=['-o',str(out)]
   t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);records.append({'target':n,'phase':phase,'name':name,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(src),'log_sha256':h(log),'object_sha256':h(out) if name!='axioms' and out.exists() else None});(b/'check-records.json').write_text(json.dumps(records,indent=2));print(n,phase,name,r.returncode,records[-1]['seconds'],flush=True)
   if r.returncode:raise SystemExit(r.returncode)
 a=(b/n/'baseline'/'axioms.check.log').read_bytes();c=(b/n/'final'/'axioms.check.log').read_bytes();print(n,'axioms identical',a==c,flush=True)
 if a!=c:raise SystemExit(1)
