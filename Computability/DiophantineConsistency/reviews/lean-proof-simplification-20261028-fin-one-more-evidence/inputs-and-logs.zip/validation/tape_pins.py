import json,hashlib
from pathlib import Path
p=Path('/tmp/machine-tape215-root-bbarbz31/inputs.json');d=json.loads(p.read_text());srcbad=[];objbad=[];src=[];obj=[];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for m in d['profile']['modules']:
 z=m.get('source')
 if not isinstance(z,dict) or not z.get('path'):continue
 x=z['path'];i=x.find('/Proofs/Computability/');j=x.find('/Proofs/Logic/');q=Path('.'+x[i+7:]) if i>=0 else Path('.'+x[j+7:]) if j>=0 else Path(x);actual=sha(q) if q.exists() else None
 if actual!=z['sha256']:srcbad.append(m['module'])
 src.append({'module':m['module'],'path':str(q.resolve()),'actual':actual,'expected':z['sha256']})
for m in d['actual_providers']:
 z=m['actual'];q=Path(z['path']);actual=sha(q) if q.exists() else None
 if actual!=z['sha256'] or actual!=m['expected']['sha256']:objbad.append(m['module'])
 obj.append({'module':m['module'],'path':str(q.resolve()),'actual':actual,'expected':z['sha256']})
r={'source_receipt':str(p),'source_receipt_sha256':sha(p),'source_records':src,'object_records':obj,'source_failures':srcbad,'object_failures':objbad};Path('/tmp/fin-one-more/tape-pins.json').write_text(json.dumps(r,indent=2));print('sources',len(src),'objects',len(obj),'failures',len(srcbad),len(objbad),flush=True)
