from pathlib import Path
import hashlib,json,subprocess
R=Path('/dev/shm/tiling-band-fixed');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text());providers={}
for n,f in [('ArithmeticTilingRows','/dev/shm/tiling-colours-direct/final-records.json'),('ArithmeticPow','/tmp/pow-perturbation/final-records.json')]:
 x=next(x for x in load(f) if x['module']==n);assert x['status']==0 and x['before']==x['after']==h(W/f'{n}.lean') and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256']
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticTilingBand','ArithmeticTilingWord']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if x['module']!='ArithmeticTilingBand':assert x['before']==h(W/f"{x['module']}.lean")
  else:
   rev='85306187dc^' if ph=='baseline' else '85306187dc'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingBand.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert h(W/'ArithmeticTilingBand.lean')==x['before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticTilingBand':assert d['before']==rr[0]['object_sha256']
   else:assert d['before']==providers[n]
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=load(R/'ArithmeticTilingWord-probe-records.json');assert len(rows)==8
for x in rows:assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[z['object_sha256'] for z in records[x['phase']]] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-ArithmeticTilingWord-{n}.log').read_bytes()==(R/f'final-ArithmeticTilingWord-{n}.log').read_bytes()
print('PASS source-matched TilingRows/Pow, paired target/client and both-object pinned namespace/registration probes')
