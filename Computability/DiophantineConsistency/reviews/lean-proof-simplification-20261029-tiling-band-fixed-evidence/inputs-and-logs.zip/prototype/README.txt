Tiling band fixed-row cases: isolated proof simplification

Baseline ArithmeticTilingBand SHA-256 756de82313f57c41242f9d9a0925b9a2dfd9c02a07db2c3db7ac07fa00ee1aec;
final SHA-256 13ae150a5d9d4055e6315383fd92663e409188e9d06b52bc38292d6f6f1d8c9a.
reset_sides now splits its existing conditionals and simplifies the known
west/east colours, like the nearby seam_vertical proof. init_east uses the
existing lt_succ_iff_le equivalence directly in place of an expanded successor
comparison. Three proof lines replace seven; all statements, guards, data,
definitions and imports are unchanged. Tested sources match 85306187dc and its parent.
Original file commit
3cd04ac37fb917e25ac64547223d25a17e115c2f includes Co-Authored-By: Claude Opus
5.5 <noreply@anthropic.com>.

baseline/final-records.json pin source, commands, first direct input objects
before/after, output hashes, logs and timings for the target and its sole
tracked Lean direct client TilingWord. Target TilingRows matches the current-
source final producer in /dev/shm/tiling-colours-direct/final-records.json;
the client's other direct Pow input matches /tmp/pow-perturbation/final-
records.json. audit.py/.log verify those prior source/object producer matches,
first-provider resolution and the selected paired builds and probes. Direct
provider source hashes were matched to prior receipts rather than sampled during
these builds. Other project, BusyBeaver, Foundation and Mathlib dependencies
remain cached; no full current-source transitive closure is claimed.

Both target and client compile in each phase. Target user CPU 26.83/26.52 s,
client 9.47/9.42 s (single baseline/final shared-load samples, not a general
benchmark). The client objects differ in bytes, without an established cause:
baseline 3b5651ebed481b30a873320a8ae075ecf356818d4500fc3dc5de753e7110f36a;
final 90a2355bbf8fec1f8f0b21c6339fd8b247b543da0ec2d5f8d8c0577cc9ce5fcc.
Target probes match all 57 namespace declaration/type/axiom reports and 29,730
default simp/13,394 instance entries. Both-object-pinned client probes match
all 18 namespace reports and 29,733 simp/13,397 instance entries. These checks
do not establish equality of proof bodies, every persistent environment
extension or untested downstream behavior. Both phases retain one existing
unused-parameter target warning and nine existing TilingWord warnings.
The final target was built first and remains stable; final-target-records.json
and final-client-records.json are separately preserved and merged into the
selected final-records.json.
