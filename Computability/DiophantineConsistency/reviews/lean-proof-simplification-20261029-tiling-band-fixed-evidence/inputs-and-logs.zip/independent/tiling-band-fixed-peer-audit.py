from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/dev/shm/tiling-band-fixed');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticTilingBand.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticTilingBand.lean').read_text();old='''  split
  · exact ⟨c930.west, c930.east⟩
  · split
    · exact ⟨c931.west, c931.east⟩
    · exact ⟨c932.west, c932.east⟩''';new='''  split_ifs <;> simp only [c930.west, c930.east, c931.west, c931.east,
    c932.west, c932.east, true_and]''';old2='''  · have hX : L ≤ X := by
      have := lt_iff_succ_le.mp h; exact le_of_add_le_add_right this''';new2='''  · have hX : L ≤ X := lt_succ_iff_le.mp h'''
assert b.count(old)==b.count(old2)==1 and b.replace(old,new).replace(old2,new2)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingBand.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('85306187dc^')==b and gitfile('85306187dc')==f and (W/'ArithmeticTilingBand.lean').read_text()==f;print('PASS exact substitutions, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticTilingBand$','--','*.lean'],text=True).splitlines();assert clients==['Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingWord.lean'];print('PASS sole tracked Lean direct client',clients)
paths={'ArithmeticTilingRows':'/dev/shm/tiling-colours-direct/final-records.json','ArithmeticPow':'/tmp/pow-perturbation/final-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module']==n);assert x['status']==0 and x['before']==x['after']==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticTilingBand','ArithmeticTilingWord'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticTilingBand':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticTilingBand':assert d['before']==rec[phase][n]['object_sha256']
   else:assert d['before']==providers[n]
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
assert rec['baseline']['ArithmeticTilingWord']['object_sha256']!=rec['final']['ArithmeticTilingWord']['object_sha256']
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticTilingBand']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=read(R/'ArithmeticTilingWord-probe-records.json');assert len(rows)==8
for x in rows:
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[x['phase']][n]['object_sha256'] for n in ('ArithmeticTilingBand','ArithmeticTilingWord')] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-ArithmeticTilingWord-{n}.log').read_bytes()==(R/f'final-ArithmeticTilingWord-{n}.log').read_bytes()
print('PASS target and differing client declaration/type/axiom and registration reports, both-object pins')
