from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/dev/shm/tiling-band-fixed');D=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-tiling-band-fixed-evidence');D.mkdir(parents=True,exist_ok=True);files={}
for p in sorted(R.rglob('*')):
 if p.is_file() and not p.is_symlink() and not str(p.relative_to(R)).startswith('objects-') and p.suffix!='.olean' and p.name!='build-bundle.py':files['prototype/'+str(p.relative_to(R))]=p.read_bytes()
prior={'tiling-rows-final-records.json':'/dev/shm/tiling-colours-direct/final-records.json','tiling-rows-final-source.lean':'/dev/shm/tiling-colours-direct/final/DiophantineConsistency/ArithmeticTilingRows.lean','pow-final-records.json':'/tmp/pow-perturbation/final-records.json','pow-final-source.lean':'/tmp/pow-perturbation/final/DiophantineConsistency/ArithmeticPow.lean'}
for n,p in prior.items():files['prior/'+n]=Path(p).read_bytes()
for x in ('tiling-band-fixed-peer-review.txt','tiling-band-fixed-peer-audit.py','tiling-band-fixed-peer-audit.log'):files['independent/'+x]=Path('/tmp',x).read_bytes()
c='85306187dc4e239c124cc6d3661a65ae39f234c9';par='2eac2de00dc0798e25cae48edfe9ff90dae467c3';rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingBand.lean'
for rev,label in ((par,'baseline'),(c,'final')):
 files['commit/'+label+'.lean']=subprocess.check_output(['git','show',rev+':'+rel]);assert files['commit/'+label+'.lean']==files['prototype/'+label+'/DiophantineConsistency/ArithmeticTilingBand.lean']
files['bundle/build-bundle.py']=Path('/dev/shm/tiling-band-fixed/build-bundle.py').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':c,'source_parent':par,'scope':'Simplify TilingBand reset-side conditional cases and successor comparison','validation':'Paired target and sole tracked Lean direct client TilingWord compile using source-matched TilingRows and Pow. Client object bytes differ, but both-object-pinned client namespace type/axiom and global simp/instance reports match; all target reports match.','limitations':['The project, BusyBeaver, Foundation and Mathlib transitive closure was not rebuilt; direct TilingRows and Pow source/object matches rely on prior producer receipts rather than fresh source samples during these builds.','Single shared-load timing pairs do not establish general performance. Matching namespace/registration reports do not establish equality of proof bodies, every persistent extension or untested downstream behavior.','Compiled objects are excluded; recorded hashes and first-provider paths require external objects for independent byte verification.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'independent_review_sha256':sha(files['independent/tiling-band-fixed-peer-review.txt']),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}}
(D/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'independent-review.txt').write_bytes(files['independent/tiling-band-fixed-peer-review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,b in files.items():assert z.read(n)==b
assert sha((D/'independent-review.txt').read_bytes())==manifest['independent_review_sha256'];print('PASS members',len(files),'zip sha',manifest['archive_sha256'],'review sha',manifest['independent_review_sha256'])
