from pathlib import Path
import os,sys,subprocess,json,time,hashlib
out=Path('/tmp/diophantine-divmod-20261028'); mode=sys.argv[1]
base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
specs=[('RegisterDivMod',base+'RegisterDivMod.lean','RegisterDivMod'),('QuadraticDivMod',base+'QuadraticDivMod.lean','QuadraticDivMod'),('ObjectDivModSyntax',base+'ObjectDivModSyntax.lean','ObjectDivModSyntax'),('focus','Computability/DiophantineConsistency/Lean/checks/QuadraticRegisterSystem.lean',None),('object-focus','Computability/DiophantineConsistency/Lean/checks/ObjectDivision.lean',None),('axioms',str(out/'public-axioms.lean'),None)]
def rec(path):
 p=Path(path);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
records=[]
for tag,source,obj in specs:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',source]
 if obj:cmd+=['-o',str(out/'overlay/DiophantineConsistency'/(obj+'.olean'))]
 full=['lake','env','bash','-c','export LEAN_PATH="/tmp/diophantine-divmod-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*cmd]
 log=out/(mode+'-'+tag+'.log');tim=out/(mode+'-'+tag+'.time');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(tim),*full],stdout=f,stderr=subprocess.STDOUT)
 data={'tag':tag,'command':full,'status':p.returncode,'source':rec(source),'log':rec(log),'timing':rec(tim),'elapsed':time.monotonic()-start}
 if obj and p.returncode==0:data['object']=rec(cmd[-1])
 records.append(data);(out/(mode+'-records.json')).write_text(json.dumps(records,indent=2)+'\n')
 print(mode,tag,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
