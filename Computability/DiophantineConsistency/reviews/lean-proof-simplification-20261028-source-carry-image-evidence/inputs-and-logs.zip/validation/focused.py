from pathlib import Path
import json,hashlib,subprocess,time,os
R=Path('/tmp/source-carry-image-simplification');root=Path('Computability/DiophantineConsistency/Lean');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/(phase+'-fresh-lib'))+':/tmp/carry-map-sharing/htp:'+env.get('LEAN_PATH','')
 for n in ['SplitSourceCarry','GapSourceCarry66']:
  src=root/'checks'/(n+'.lean');out=R/(phase+'-focused-'+n+'.olean');log=R/(phase+'-focused-'+n+'.log');tm=R/(phase+'-focused-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];before=h(src);t=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  d={'phase':phase,'name':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(out) if out.exists() else None};records.append(d);(R/'focused-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,p.returncode,round(d['seconds'],2),flush=True)
  if p.returncode or before!=d['source_after']:raise SystemExit(1)
for n in ['SplitSourceCarry','GapSourceCarry66']:
 if (R/('baseline-focused-'+n+'.log')).read_bytes()!=(R/('final-focused-'+n+'.log')).read_bytes():raise SystemExit('focused logs differ '+n)
print('all focused logs identical',flush=True)
