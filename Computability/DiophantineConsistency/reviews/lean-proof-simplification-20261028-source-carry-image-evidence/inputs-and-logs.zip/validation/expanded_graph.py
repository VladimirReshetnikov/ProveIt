from pathlib import Path
import re,json,hashlib
R=Path('/tmp/source-carry-image-simplification');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/HilbertTenthProblem/Lean')];o=Path('/tmp/carry-map-sharing/final-fresh');htp=Path('/tmp/carry-map-sharing/htp');old=Path('.lake/build/lib/lean');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();seen={};order=[]
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');p=next((a/(rel+'.lean') for a in roots if (a/(rel+'.lean')).exists()),None)
 if not p:return
 deps=[]
 for l in p.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',l)
  if m:
   for d in m.group(1).split():
    if d.startswith(('DiophantineConsistency.','Diophantine.')) and any((a/(d.replace('.','/')+'.lean')).is_file() for a in roots):deps.append(d)
 oldobj=old/(rel+'.olean') if n.startswith('Diophantine.') else Path('/tmp/encoded-degree-reuse/final')/(rel+'.olean');newobj=htp/(rel+'.olean') if n.startswith('Diophantine.') else o/(rel+'.olean');seen[n]={'source':str(p),'source_sha256':h(p),'imports':deps,'old':str(oldobj.resolve()) if oldobj.exists() else None,'new':str(newobj.resolve()) if newobj.exists() else None,'old_sha256':h(oldobj) if oldobj.exists() else None,'new_sha256':h(newobj) if newobj.exists() else None}
 for d in deps:visit(d)
 order.append(n)
for n in ['SplitSourceCarry','GapSourceCarry66','SplitSourceContract','GapSourceContract66']:visit('DiophantineConsistency.'+n)
(R/'expanded-graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n');seeds={n for n,v in seen.items() if n.startswith('Diophantine.') and v['new_sha256'] and v['old_sha256'] and v['new_sha256']!=v['old_sha256']}; print('nodes',len(seen),'nonlocal changed',len(seeds));a=set(seeds)
while True:
 b=a|{n for n,v in seen.items() if any(d in a for d in v['imports'])}
 if b==a:break
 a=b
print('project affected',len([n for n in a if n.startswith('DiophantineConsistency.')]))
for n in order:
 if n in a and n.startswith('DiophantineConsistency.'):
  v=seen[n];print(n,'changed' if v['new_sha256']!=v['old_sha256'] else 'same',str(v['new']))
