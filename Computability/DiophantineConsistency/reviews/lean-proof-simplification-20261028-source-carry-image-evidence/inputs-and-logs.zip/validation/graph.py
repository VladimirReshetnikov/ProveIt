from pathlib import Path
import re,json,hashlib
R=Path('/tmp/source-carry-image-simplification');src=Path('Computability/DiophantineConsistency/Lean');overlay=Path('/tmp/carry-map-sharing/final-fresh');names=['SplitSourceCarry','GapSourceCarry66','SplitSourceContract','GapSourceContract66'];seen={};order=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def visit(mod):
 if mod in seen:return
 p=src/(mod.replace('.','/')+'.lean')
 if not p.is_file():return
 deps=[]
 for l in p.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',l)
  if m:
   for d in m.group(1).split():
    if d.startswith('DiophantineConsistency.') and (src/(d.replace('.','/')+'.lean')).is_file():deps.append(d)
 seen[mod]={'source':str(p),'source_sha256':h(p),'imports':deps}
 for d in deps:visit(d)
 o=overlay/(mod.replace('.','/')+'.olean')
 if o.exists():seen[mod].update(object=str(o.resolve()),object_sha256=h(o.resolve()),source_newer=p.stat().st_mtime>o.stat().st_mtime)
 order.append(mod)
for n in names:visit('DiophantineConsistency.'+n)
(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n');print('nodes',len(seen),'missing objects',[n for n,v in seen.items() if 'object' not in v]);print('source newer',[n for n,v in seen.items() if v.get('source_newer')]);
