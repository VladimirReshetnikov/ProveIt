from pathlib import Path
import json,hashlib
R=Path('/tmp/source-carry-image-simplification');v=json.load(open(R/'graph.json'))['nodes'];z=Path('/tmp/encoded-degree-reuse');c=Path('/tmp/carry-map-sharing');known={};h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in list(z.glob('final-*.json'))+[z/'verified-borrowed-pins.json',z/'gap-certificate-borrow.json']+list(c.glob('*.json')):
 try:x=json.load(open(p))
 except Exception:continue
 def walk(a):
  if isinstance(a,list):
   for i in a:walk(i)
  elif isinstance(a,dict):
   n=a.get('module',a.get('tag',a.get('job')));ss=a.get('source_sha256');oh=a.get('object_sha256');status=a.get('status',0)
   if a.get('source','').endswith('/GapCertificate66.lean'):n='GapCertificate66'
   if isinstance(n,str) and ss and oh and status==0:known.setdefault('DiophantineConsistency.'+n.split('.')[-1],[]).append((ss,oh,str(p)))
   for q in a.values():
    if isinstance(q,(dict,list)):walk(q)
 walk(x)
exclude={'SplitSourceCarry','GapSourceCarry66','SplitSourceContract','GapSourceContract66'};pins=[]
for n,a in v.items():
 if n.rsplit('.',1)[-1] in exclude:continue
 z=[x for x in known.get(n,[]) if x[0]==a['source_sha256'] and x[1]==a.get('object_sha256')]
 assert z,(n,a);assert h(a['source'])==a['source_sha256'] and h(a['object'])==a['object_sha256'],n
 pins.append({'module':n,**a,'receipt':z[0][2]})
(R/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');print('authenticated local pins',len(pins))
