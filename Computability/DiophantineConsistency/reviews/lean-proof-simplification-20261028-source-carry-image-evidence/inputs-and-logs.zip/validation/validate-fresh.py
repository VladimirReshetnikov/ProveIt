from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/source-carry-image-simplification');prior=R/'fresh/DiophantineConsistency';repo=Path('Computability/DiophantineConsistency/Lean');names=['SplitSourceCarry','GapSourceCarry66'];clients=['SplitSourceContract','GapSourceContract66'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[];probe=R/'axioms.lean'
probe.write_text('import DiophantineConsistency.SplitSourceCarry\nimport DiophantineConsistency.GapSourceCarry66\n'+''.join('#print axioms DiophantineConsistency.'+m+'.'+n+'\n' for m,n in [('SplitSourceCarry','tau_product_iff'),('SplitSourceCarry','tau_targets_iff'),('GapSourceCarry66','product_natDegree_lt_2083'),('GapSourceCarry66','tau_product_iff'),('GapSourceCarry66','tau_targets_iff')]))
for phase in ['baseline','final']:
 ns=R/(phase+'-fresh-lib/DiophantineConsistency');ns.mkdir(parents=True,exist_ok=True)
 for p in prior.iterdir():
  if p.suffix!='.olean' or p.stem in names+clients:continue
  q=ns/p.name
  if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(R/(phase+'-fresh-lib'))+':/tmp/carry-map-sharing/htp:'+env.get('LEAN_PATH','')
 for n in names+clients+['axioms']:
  if n in names:src=R/('baseline' if phase=='baseline' else 'source')/'DiophantineConsistency'/(n+'.lean');root=src.parent.parent;out=ns/(n+'.olean')
  elif n in clients:src=repo/'DiophantineConsistency'/(n+'.lean');root=repo;out=ns/(n+'.olean')
  else:src=probe;root=R;out=None
  if out:out.unlink(missing_ok=True)
  log=R/(phase+'-fresh-'+n+'.log');tm=R/(phase+'-fresh-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(src)]
  if out:cmd+=['-o',str(out)]
  pre=h(src);t=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  d={'phase':phase,'name':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(out) if out and out.exists() else None};rec.append(d);(R/'records-fresh.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,n,p.returncode,round(d['seconds'],2),flush=True)
  if p.returncode or pre!=d['source_after']:raise SystemExit(1)
for n in names+clients+['axioms']:
 a=(R/('baseline-fresh-'+n+'.log')).read_bytes();b=(R/('final-fresh-'+n+'.log')).read_bytes()
 if a!=b:print('log difference',n,flush=True);raise SystemExit(2)
print('all paired logs identical',flush=True)
