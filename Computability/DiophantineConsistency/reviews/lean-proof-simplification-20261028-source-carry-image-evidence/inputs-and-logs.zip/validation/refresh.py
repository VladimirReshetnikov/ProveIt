from pathlib import Path
import json,hashlib,time,subprocess,os
R=Path('/tmp/source-carry-image-simplification');g=json.loads((R/'expanded-graph.json').read_text());nodes=g['nodes'];prior=Path('/tmp/carry-map-sharing/final-fresh/DiophantineConsistency');ns=R/'fresh/DiophantineConsistency';ns.mkdir(parents=True,exist_ok=True);hs=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in prior.iterdir():
 if p.suffix=='.olean':
  q=ns/p.name
  if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
seeds={n for n,v in nodes.items() if n.startswith('Diophantine.') and v['new_sha256'] and v['old_sha256'] and v['new_sha256']!=v['old_sha256']};a=set(seeds)
while True:
 b=a|{n for n,v in nodes.items() if any(d in a for d in v['imports'])}
 if b==a:break
 a=b
skip={'MultiTargetCarry','SparseBorrowCarry','SelectiveCarry','SplitCarry','SplitSourceCarry','GapSourceCarry66','SplitSourceContract','GapSourceContract66'}
order=[n for n in g['order'] if n in a and n.startswith('DiophantineConsistency.') and n.rsplit('.',1)[-1] not in skip]
(R/'refresh-plan.json').write_text(json.dumps({'seeds':sorted(seeds),'affected':sorted(a),'skip':sorted(skip),'order':order},indent=2)+'\n');print('rebuilding',len(order),'affected project modules',flush=True)
env=os.environ.copy();env['LEAN_PATH']=str(R/'fresh')+':/tmp/carry-map-sharing/htp:'+env.get('LEAN_PATH','');rec=[]
for mod in order:
 name=mod.rsplit('.',1)[-1];source=Path(nodes[mod]['source']);out=ns/(name+'.olean');out.unlink(missing_ok=True);log=R/('refresh-'+name+'.log');tm=R/('refresh-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(source),'-o',str(out)];pre=hs(source);t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'module':mod,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':hs(source),'log_sha256':hs(log),'timing':tm.read_text().strip(),'object_sha256':hs(out) if out.exists() else None};rec.append(d);(R/'refresh-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,q.returncode,round(d['seconds'],2),flush=True)
 if q.returncode or pre!=d['source_after'] or pre!=nodes[mod]['source_sha256']:raise SystemExit(1)
