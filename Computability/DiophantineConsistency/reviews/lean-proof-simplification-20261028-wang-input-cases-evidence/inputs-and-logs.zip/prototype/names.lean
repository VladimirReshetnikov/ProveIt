import DiophantineConsistency.WangTiles942InputLanguage
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.WangTiles942InputLanguage).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.WangTiles942InputLanguage" then
   logInfo m!"DECL {n}"
