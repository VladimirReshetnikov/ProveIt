from pathlib import Path
import json,hashlib,re
R=Path('/tmp/wang-input-cases'); W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); rows={}
for phase in ['baseline','final','baseline-repeat','final-repeat']:
 rows[phase]=json.loads((R/(phase+'-records.json')).read_text())
 for x in rows[phase]:
  assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_sha256']==H(x['object']) and x['log_sha256']==H(x['log']) and x['time']==(R/(phase+'-'+x['module']+'.time')).read_text()
  if x['module']!='WangTiles942InputLanguage' or phase.startswith('baseline'):assert x['before']==H(W/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   first=next(Path(p)/(d['module'].replace('.','/')+'.olean') for p in x['LEAN_PATH'].split(':') if (Path(p)/(d['module'].replace('.','/')+'.olean')).is_file())
   assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==H(first)
   if d['module'].endswith('.WangTiles942InputLanguage'):
    assert d['before']==rows[phase][0]['object_sha256'] and d['resolved']==rows[phase][0]['object']
 print(phase,len(rows[phase]),rows[phase][0]['time'].strip())
for x,y in zip(rows['baseline'][1:],rows['final'][1:]):assert x['module']==y['module'] and x['object_sha256']==y['object_sha256'];print('client identical',x['module'],x['object_sha256'])
for phase in ['baseline','final']:
 for name in ['names','interfaces','simp','instances']:
  x=json.loads((R/f'probe-{name}-{phase}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==H(x['source']) and x['object_before']==x['object_after']==H(x['object'])==rows[phase][0]['object_sha256'] and x['log_sha256']==H(x['log'])
for n in ['names','simp','instances']:assert (R/('baseline-'+n+'.log')).read_bytes()==(R/('final-'+n+'.log')).read_bytes()
def decls(phase):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(phase+'-interfaces.log')).read_text()) if v.strip()}
a,b=decls('baseline'),decls('final');assert a==b;print('declarations/types/axioms match:',len(a))
for n in ['simp','instances']: print(n, len((R/('baseline-'+n+'.log')).read_text().splitlines()))
p=json.loads(Path('/tmp/wang-rail-card-20261028/fresh-client-records.json').read_text());q=next(x for x in p if x['job']=='WangTiles942Boundary' and x['phase']=='final');d=rows['final'][0]['direct_inputs'][0];assert q['status']==0 and q['source_sha256']==q['source_after']==H(W/'WangTiles942Boundary.lean') and q['object_sha256']==d['before'];print('Boundary current source and prior object receipt match',q['source_sha256'],q['object_sha256'])
assert json.loads((R/'setup-failed-records.json').read_text())[0]['status']!=0
print('all checks passed')
