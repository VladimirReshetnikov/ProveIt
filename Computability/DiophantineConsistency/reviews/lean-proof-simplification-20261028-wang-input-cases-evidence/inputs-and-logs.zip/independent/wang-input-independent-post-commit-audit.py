from pathlib import Path
import json,hashlib,re
r=Path('/tmp/wang-input-cases');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
prior=json.loads(Path('/tmp/wang-rail-card-20261028/fresh-client-records.json').read_text());p=next(x for x in prior if x['job']=='WangTiles942Boundary' and x['phase']=='final');assert p['status']==0 and p['source_sha256']==p['source_after']==h(repo/'WangTiles942Boundary.lean')
for ph in ('baseline','final','baseline-repeat','final-repeat'):
 for x in json.loads((r/f'{ph}-records.json').read_text()):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if ph.startswith('baseline') or n!='WangTiles942InputLanguage':assert x['before']==h(r/'baseline-commit.lean' if n=='WangTiles942InputLanguage' else repo/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';o=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(o)==d['path'] and str(o.resolve())==d['resolved'] and d['before']==d['after']==h(o);m=d['module'].split('.')[-1]
   if m=='WangTiles942Boundary':assert d['before']==p['object_sha256'];print('prior Boundary current source/object match',ph)
   else:assert d['resolved']==rows[(ph,m)]['object'] and d['before']==rows[(ph,m)]['object_sha256'];print('same-phase client import',ph,n)
  if n=='WangTiles942InputLanguage':assert Path(x['log']).read_bytes()==b''
  rows[(ph,n)]=x;print('build',ph,n,x['time'].strip())
for ph in ('baseline','final'):
 for name in ('names','interfaces','simp','instances'):
  x=json.loads((r/f'probe-{name}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[(ph,'WangTiles942InputLanguage')]['object_sha256'] and x['log_sha256']==h(x['log']);print('probe',ph,name,'verified')
for n in ('WangTiles942Signals','WangTiles942InputLanguageChecks'):assert rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'];print('client objects identical',n)
for n in ('names','interfaces','simp','instances'):
 a=(r/f'baseline-{n}.log').read_bytes();b=(r/f'final-{n}.log').read_bytes();assert a==b;print(n,'equal',len(a.splitlines()))
def parse(f):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',f.read_text(),re.M|re.S)}
a=parse(r/'baseline-interfaces.log');b=parse(r/'final-interfaces.log');assert a==b and len(a)==37;print('37 common declaration/type/axiom blocks including generated names match')
base=(r/'baseline/DiophantineConsistency/WangTiles942InputLanguage.lean').read_text();final=(r/'final/DiophantineConsistency/WangTiles942InputLanguage.lean').read_text()
for name in ('north_operating_iff_transition','north_halt_iff_pass_or_finish','north_plain_iff'):
 def statement(s):
  p=s.index('theorem '+name+' ');return s[p:s.index(':= by',p)]
 assert statement(base)==statement(final);print('theorem header matches',name)
f=json.loads((r/'setup-failed-records.json').read_text())[0];assert f['status']!=0 and f['before']==f['after']==h(r/'superseded-v1/source.lean') and f['log_sha256']==h(r/'setup-failed.log') and f['time']==(r/'setup-failed.time').read_text();print('first overlay failure retained')

import subprocess
p='Computability/DiophantineConsistency/Lean/DiophantineConsistency/WangTiles942InputLanguage.lean'
for ph,ref in [('baseline','ffe53fb10a^'),('final','ffe53fb10a')]:
 data=subprocess.check_output(['git','show',ref+':'+p]);assert data==(r/(ph+'-commit.lean')).read_bytes()==(r/ph/'DiophantineConsistency/WangTiles942InputLanguage.lean').read_bytes()
 if ph=='final':assert data==Path(p).read_bytes()
 print('git',ph,'snapshot verified')
