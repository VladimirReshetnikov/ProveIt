import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCarrierRadix2011
import DiophantineConsistency.ArithmeticRadixAlignmentChecks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRadixAlignment).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRadixAlignment" then
   logInfo m!"DECL {n}"
