from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/radix-positivity');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticRadixAlignment.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticRadixAlignment.lean').read_text()
old='''  have hN : 0<u/d := by
    by_contra hn
    have hz : u/d=0 := le_antisymm (le_of_not_gt hn) (by simp)
    have hu0 : u=0 := by simpa [hz] using hu
    have hp : 0<(Exp.exp d-1)*J :=
      mul_pos (lt_trans (by simp) (radix_gt_one hd)) hJ
    have hgt : 1<(Exp.exp d-1)*J+1 := by simpa using hp
    rw [←he,hu0,exp_zero] at hgt
    exact (Arithmetic.lt_irrefl (1:V)) hgt''';new='''  have hgt : (1:V)<Exp.exp u := by
    rw [he]
    exact lt_add_of_pos_left 1 (mul_pos (lt_trans (by simp) (radix_gt_one hd)) hJ)
  have hup : 0<u := exp_monotone.mp (by simpa only [exp_zero] using hgt)
  have hN : 0<u/d := pos_of_mul_pos_right (by rw [←hu]; exact hup) (by simp)'''
old2='''  have hw : 0<w := by
    by_contra h
    have hz : w=0 := le_antisymm (le_of_not_gt h) (by simp)
    have hzero : Exp.exp R=0 := by simpa [hz] using he
    exact (ne_of_gt (exp_pos R)) hzero''';new2='''  have hw : 0<w := pos_of_mul_pos_left (by rw [←he]; exact exp_pos R) (by simp)'''
assert b.count(old)==b.count(old2)==1 and b.replace(old,new).replace(old2,new2)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRadixAlignment.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('3f01d661e2^')==b and gitfile('3f01d661e2')==f and (W/'ArithmeticRadixAlignment.lean').read_text()==f;print('PASS exact substitutions, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticRadixAlignment$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(p).stem for p in clients)==['ArithmeticCarrierRadix2011','ArithmeticRadixAlignmentChecks'];print('PASS two tracked direct module clients',clients)
paths={'ArithmeticCarrierSoundness2011':'/tmp/signed-pairs-factors/final-records.json','ArithmeticPellPowerRecovery':'/tmp/four-positive-wrappers/upstream-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module']==n);assert x['status']==0 and x['before']==x['after']==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticRadixAlignment','ArithmeticRadixAlignmentChecks','ArithmeticCarrierRadix2011'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticRadixAlignment':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d.get('source_before') is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n=='ArithmeticRadixAlignment':assert d['before']==rec[phase][n]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
   else:assert d['module'] in ['Foundation.FirstOrder.Arithmetic.Exponential.Log','Mathlib.Tactic.Ring']
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticRadixAlignmentChecks','ArithmeticCarrierRadix2011'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS both direct client objects byte-identical')
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][Path(p).stem]['object_sha256'] for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
print('PASS three-object-pinned target census and matching simp/instances')
up=read('/tmp/four-positive-wrappers/upstream-records.json');pr=next(x for x in up if x['module']=='ArithmeticPellPowerRecovery');fi=next(x for x in up if x['module']=='ArithmeticPellFirstIndex');old=next(x for x in read('/tmp/pell-y-add/final-records.json') if x['module']=='ArithmeticPellFirstNorm');cs=next(x for x in read('/tmp/signed-pairs-factors/final-records.json') if x['module']=='ArithmeticCarrierSoundness2011')
def inp(x,n):return next(d['before'] for d in x['direct_inputs'] if d['module'].endswith('.'+n))
assert pr['object_sha256']==providers['ArithmeticPellPowerRecovery'] and cs['object_sha256']==providers['ArithmeticCarrierSoundness2011'] and inp(pr,'ArithmeticPellFirstIndex')==inp(cs,'ArithmeticPellFirstIndex')==fi['object_sha256'] and inp(fi,'ArithmeticPellFirstNorm')==old['object_sha256'] and old['before']==old['after']!=h(W/'ArithmeticPellFirstNorm.lean')
print('PASS historical FirstIndex->old FirstNorm producer boundary; transitive load-time bytes not pinned')
