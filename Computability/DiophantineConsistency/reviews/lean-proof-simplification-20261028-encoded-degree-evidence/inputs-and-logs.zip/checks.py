import os,sys,time,json,subprocess,hashlib
from pathlib import Path
root=Path('/tmp/encoded-degree-reuse');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
lean='Computability/DiophantineConsistency/Lean';jobs=[(n,lean+'/checks/'+n+'.lean') for n in ['SelectiveCarry','SplitSourceBounds','SplitKernels59','GapKernels66']]+[('axioms',str(root/'axioms.lean'))]
records=[]
for n,p in jobs:
 log=root/(phase+'-check-'+n+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R',lean,p];t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(v.stdout+v.stderr)
 rec={'tag':n,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 records.append(rec);(root/(phase+'-checks.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,n,v.returncode,round(rec['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
