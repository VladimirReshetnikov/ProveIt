import DiophantineConsistency.SelectiveQuadraticCoding
namespace DiophantineConsistency.SelectiveQuadraticCoding
open Polynomial
open scoped BigOperators
variable {R : Type*} [CommRing R] {m : ℕ}
theorem encoded_degree_le (w : Fin (m+1) → ℕ) (u : Fin (m+1) → R) (W : ℕ)
    (hw : ∀ i, w i ≤ W) : (encoded w u).natDegree ≤ W := by
  apply natDegree_le_iff_coeff_eq_zero.mpr
  intro j hj
  simp only [encoded,finsetSum_coeff,coeff_monomial]
  apply Finset.sum_eq_zero
  intro i _
  exact if_neg (Nat.ne_of_lt (lt_of_le_of_lt (hw i) hj))
#print axioms encoded_degree_le
end DiophantineConsistency.SelectiveQuadraticCoding
