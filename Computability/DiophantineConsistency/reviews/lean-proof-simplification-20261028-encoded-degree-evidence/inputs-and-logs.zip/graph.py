import hashlib,json,re,sys
from pathlib import Path
base=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');root=Path('/tmp/encoded-degree-reuse');seen={}
def visit(n):
 if n in seen:return
 p=base/(n+'.lean')
 if not p.exists():return
 s=p.read_text();ds=[]
 for line in s.splitlines():
  if line.startswith('import '):ds+=re.findall(r'DiophantineConsistency\.([\w.]+)',line)
 seen[n]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'imports':ds}
 for x in ds:visit(x)
for n in ['SelectiveCarry','SplitSourceBounds','SplitKernels59','GapKernels66','SplitNineSource59','GapSourceWords66','SplitSourceCarry']:visit(n)
(root/('graph-'+sys.argv[1]+'.json')).write_text(json.dumps(seen,indent=2)+'\n')
print('graph',sys.argv[1],len(seen))
