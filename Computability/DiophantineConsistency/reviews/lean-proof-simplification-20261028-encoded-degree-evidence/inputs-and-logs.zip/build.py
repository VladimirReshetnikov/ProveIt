import os,sys,time,json,subprocess,hashlib
from pathlib import Path
root=Path('/tmp/encoded-degree-reuse');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
modules=['SelectiveCarry','SelectiveCoefficientBounds','SplitCoefficientBounds','PolynomialRangeBounds','SplitWordBounds','SplitKernelData59','GapKernelData66','SplitSourceBounds','SplitKernels59','GapKernels66']
lean='Computability/DiophantineConsistency/Lean';src=Path(lean)/'DiophantineConsistency';records=[]
for n in modules:
 p=src/(n+'.lean');obj=root/phase/'DiophantineConsistency'/(n+'.olean');log=root/(phase+'-'+n+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R',lean,str(p),'-o',str(obj)]
 t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(v.stdout+v.stderr)
 rec={'tag':n,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if not v.returncode:rec.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
 records.append(rec);(root/(phase+'-builds.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,n,v.returncode,round(rec['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
