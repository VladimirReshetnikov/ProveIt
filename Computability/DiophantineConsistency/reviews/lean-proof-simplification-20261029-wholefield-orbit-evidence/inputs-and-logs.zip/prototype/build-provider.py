from pathlib import Path
import hashlib,json,re,os,subprocess
r=Path('/dev/shm/wholefield-orbit-refresh');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=next(x for x in json.load(open('/dev/shm/cell-room-cancel/final-records.json')) if x['module']=='ArithmeticCellDecoding');env=os.environ.copy();env['LEAN_PATH']=str(r/'provider')+':'+base['LEAN_PATH'];src=w/'ArithmeticCellDecoding.lean';ins=[]
for n in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
 p=next(Path(q)/(n.replace('.','/')+'.olean') for q in env['LEAN_PATH'].split(':') if (Path(q)/(n.replace('.','/')+'.olean')).is_file());sp=w/(n.split('.')[-1]+'.lean');ins.append({'module':n,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp),'source_before':h(sp)})
extra=[]
for n in ['ArithmeticCellLabels','ArithmeticCellLocal','MFDoubledClause2011','ArithmeticStandardCasts','ArithmeticModularCancellation','ArithmeticCyclicWord']:
 p=next(Path(q)/'DiophantineConsistency'/(n+'.olean') for q in env['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(n+'.olean')).is_file());extra.append({'module':n,'path':str(p),'resolved':str(p.resolve()),'before':h(p)})
out=r/'provider/DiophantineConsistency/ArithmeticCellDecoding.olean';tm=r/'provider.time';log=r/'provider.log';before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(w.parent),str(src),'-o',str(out)]
with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
for d in ins:d['after']=h(d['path']);d['source_after']=h(d['source'])
for d in extra:d['after']=h(d['path'])
row={'module':'ArithmeticCellDecoding','status':p.returncode,'source':str(src),'before':before,'after':h(src),'direct_inputs':ins,'extra_inputs':extra,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};(r/'provider-record.json').write_text(json.dumps(row,indent=2)+'\n');print(p.returncode,row['time'].strip(),flush=True)
