from pathlib import Path
import json,hashlib,re
r=Path('/dev/shm/wholefield-orbit-refresh');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records={}
for ph in ['baseline','final']:
 rows=json.loads((r/(ph+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticWholeField','ArithmeticOccupation'];records[ph]={x['module']:x for x in rows}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256']
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
  for d in x['extra_inputs']:
   p=next(Path(q)/'DiophantineConsistency'/(d['module']+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(d['module']+'.olean')).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
  print('PASS build',ph,x['module'],x['time'].strip())
 assert records[ph]['ArithmeticWholeField']['before']==h(r/ph/'DiophantineConsistency/ArithmeticWholeField.lean')
 assert records[ph]['ArithmeticOccupation']['before']==h(w/'ArithmeticOccupation.lean')
 d=records[ph]['ArithmeticOccupation']['direct_inputs'];assert d[0]['before']==records[ph]['ArithmeticWholeField']['object_sha256']
 for x in json.loads((r/(ph+'-probes.json')).read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(q) for q in x['objects']]==[records[ph]['ArithmeticWholeField']['object_sha256']] and h(x['log'])==x['log_sha256'] and h(x['time'])==x['time_sha256']
for x in json.loads((r/'ArithmeticOccupation-probe-records.json').read_text()):
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(q) for q in x['objects']] and h(x['log'])==x['log_sha256'];ph=x['phase'];assert x['objects_before'][:2]==[records[ph][n]['object_sha256'] for n in ('ArithmeticWholeField','ArithmeticOccupation')]
def decls(ph):
 s=(r/(ph+'-interfaces.log')).read_text();a=re.split(r'(?m)(?=^DECL )',s);return {t.split()[1]:t.strip() for t in a if t.startswith('DECL ')}
a,b=decls('baseline'),decls('final');added=set(b)-set(a);assert len(a)==74 and len(b)==75 and not set(a)-set(b) and len(added)==1 and next(iter(added)).endswith('.orbit_isCell') and all(a[k]==b[k] for k in a)
for n in ('simp','instances'):assert (r/('baseline-'+n+'.log')).read_bytes()==(r/('final-'+n+'.log')).read_bytes()
for n in ('names','interfaces','simp','instances'):assert (r/('baseline-ArithmeticOccupation-'+n+'.log')).read_bytes()==(r/('final-ArithmeticOccupation-'+n+'.log')).read_bytes()
print('PASS 74 common target declaration reports, one added private helper and registrations; client interfaces and registrations match')
for ph in ('baseline','final'):
 dec=json.load(open('/dev/shm/wholefield-orbit-refresh/provider-record.json'));d=next(d for d in records[ph]['ArithmeticWholeField']['direct_inputs'] if d['module'].endswith('.ArithmeticCellDecoding'));assert dec['status']==0 and dec['before']==dec['after']==d['source_before']==h(w/'ArithmeticCellDecoding.lean') and dec['object_sha256']==d['before'] and h(dec['object'])==dec['object_sha256'] and h(dec['log'])==dec['log_sha256']
 for x in dec['direct_inputs']:
  p=next(Path(q)/(x['module'].replace('.','/')+'.olean') for q in dec['LEAN_PATH'].split(':') if (Path(q)/(x['module'].replace('.','/')+'.olean')).is_file());assert str(p)==x['path'] and str(p.resolve())==x['resolved'] and x['before']==x['after']==h(p) and x['source_before']==x['source_after']==h(x['source'])
 for x in dec['extra_inputs']:
  p=next(Path(q)/'DiophantineConsistency'/(x['module']+'.olean') for q in dec['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(x['module']+'.olean')).is_file());assert str(p)==x['path'] and str(p.resolve())==x['resolved'] and x['before']==x['after']==h(p)
 for name in ['ArithmeticCellLabels','ArithmeticCellTransfer']:
  x=next(x for x in json.load(open('/dev/shm/cell-sum-unique/final-records.json')) if x['module']==name and x['status']==0);d=next(d for d in records[ph]['ArithmeticWholeField']['extra_inputs'] if d['module']==name);assert x['before']==x['after']==h(w/(name+'.lean')) and x['object_sha256']==d['before'];print('PASS current source provider',ph,name)
  for q in x['direct_inputs']:
   if q['module'].endswith('.ArithmeticCellLabels'):continue
   z=next(z for z in dec['extra_inputs'] if z['module']==q['module'].split('.')[-1]);assert z['before']==z['after']==q['before']==q['after']
 plane=next(x for x in json.load(open('/dev/shm/wang-push-direct/final-target-records.json')) if x['module']=='ArithmeticWangPlane' and x['status']==0);d=next(d for d in records[ph]['ArithmeticOccupation']['direct_inputs'] if d['module'].endswith('.ArithmeticWangPlane'));assert plane['before']==plane['after']==d['source_before']==h(w/'ArithmeticWangPlane.lean') and plane['object_sha256']==d['before'];print('PASS source-current producer',ph,'ArithmeticWangPlane')
 for name in ['ArithmeticWangTable','ArithmeticMachineRun215']:
  d=next(d for d in records[ph]['ArithmeticOccupation']['extra_inputs'] if d['module']==name);q=next(q for q in plane['direct_inputs'] if q['module'].endswith('.'+name));assert d['before']==q['before']==q['after'];print('PASS WangPlane producer input',ph,name)
print('PASS source-current direct producer evidence and current CellLabels dependency; full transitive closure remains cached')
