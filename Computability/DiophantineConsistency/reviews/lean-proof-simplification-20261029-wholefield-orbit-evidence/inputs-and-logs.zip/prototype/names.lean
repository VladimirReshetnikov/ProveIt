import Lean.Elab.Command
import DiophantineConsistency.ArithmeticWholeField
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticWholeField).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticWholeField" then
   logInfo m!"DECL {n}"
