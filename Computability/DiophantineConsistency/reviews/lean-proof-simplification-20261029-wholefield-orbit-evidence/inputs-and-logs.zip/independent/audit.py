import hashlib,json,re,sys
from pathlib import Path
r=Path('/dev/shm/wholefield-orbit-refresh');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();entries={}
for phase in ('baseline','final'):
 rows=json.loads((r/f'{phase}-records.json').read_text());assert [x['module'] for x in rows]==['ArithmeticWholeField','ArithmeticOccupation'];entries[phase]=rows
 assert rows[1]['before']==H(w/'ArithmeticOccupation.lean')
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_sha256']==H(x['object']) and x['log_sha256']==H(x['log'])
  assert x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  assert re.findall(r'^import\s+(\S+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   first=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file())
   assert first==Path(d['path']) and str(first.resolve())==d['resolved'] and H(first)==d['before']==d['after'] and H(d['source'])==d['source_before']==d['source_after']
  for d in x['extra_inputs']:
   first=next(Path(q)/'DiophantineConsistency'/(d['module']+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(d['module']+'.olean')).is_file())
   assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and H(first)==d['before']==d['after']
 assert rows[1]['direct_inputs'][0]['before']==rows[0]['object_sha256']
 for p in json.loads((r/f'{phase}-probes.json').read_text()):
  assert p['status']==0 and p['source_before']==p['source_after']==H(p['source']) and p['objects_before']==p['objects_after']==[H(x) for x in p['objects']]==[rows[0]['object_sha256']] and H(p['log'])==p['log_sha256'] and H(p['time'])==p['time_sha256']
assert H(w/'ArithmeticWholeField.lean')==entries['baseline'][0]['before']
for p in json.loads((r/'ArithmeticOccupation-probe-records.json').read_text()):
 rows=entries[p['phase']];di={d['module'].split('.')[-1]:d['before'] for x in rows for d in x['direct_inputs']};ex={d['module']:d['before'] for d in rows[1]['extra_inputs']};expected=[rows[0]['object_sha256'],rows[1]['object_sha256'],di['ArithmeticWangPlane'],ex['ArithmeticWangTable'],ex['ArithmeticMachineRun215'],di['ArithmeticCellDecoding'],ex['ArithmeticCellTransfer'],ex['ArithmeticCellLabels']]
 assert p['status']==0 and p['source_before']==p['source_after']==H(p['source']) and p['objects_before']==p['objects_after']==[H(x) for x in p['objects']]==expected and H(p['log'])==p['log_sha256']
for stem in ['simp','instances']:
 assert (r/f'baseline-{stem}.log').read_bytes()==(r/f'final-{stem}.log').read_bytes()
for stem in ['names','interfaces','simp','instances']:
 assert (r/f'baseline-ArithmeticOccupation-{stem}.log').read_bytes()==(r/f'final-ArithmeticOccupation-{stem}.log').read_bytes()
def extract(phase):
 s=(r/f'{phase}-interfaces.log').read_text();return {m.group(1):m.group(0) for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',s)}
a,b=extract('baseline'),extract('final'); assert len(a)==74 and len(b)==75 and not a.keys()-b.keys() and len(b.keys()-a.keys())==1 and next(iter(b.keys()-a.keys())).endswith('.orbit_isCell') and all(a[n]==b[n] for n in a)
assert len((r/'baseline-ArithmeticOccupation-names.log').read_text().splitlines())==71
for phase in ('baseline','final'):
 rows=entries[phase]
 dec=json.load(open(r/'provider-record.json')); d=next(d for d in rows[0]['direct_inputs'] if d['module'].endswith('.ArithmeticCellDecoding'))
 assert dec['status']==0 and dec['before']==dec['after']==d['source_before']==H(w/'ArithmeticCellDecoding.lean') and dec['object_sha256']==d['before']==H(dec['object']) and H(dec['log'])==dec['log_sha256']
 for k in dec['direct_inputs']:
  first=next(Path(q)/(k['module'].replace('.','/')+'.olean') for q in dec['LEAN_PATH'].split(':') if (Path(q)/(k['module'].replace('.','/')+'.olean')).is_file()); assert str(first)==k['path'] and str(first.resolve())==k['resolved'] and H(first)==k['before']==k['after'] and H(k['source'])==k['source_before']==k['source_after']
 for k in dec['extra_inputs']:
  first=next(Path(q)/'DiophantineConsistency'/(k['module']+'.olean') for q in dec['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(k['module']+'.olean')).is_file()); assert str(first)==k['path'] and str(first.resolve())==k['resolved'] and H(first)==k['before']==k['after']
 for n in ['ArithmeticCellLabels','ArithmeticCellTransfer']:
  x=next(x for x in json.load(open('/dev/shm/cell-sum-unique/final-records.json')) if x['module']==n and x['status']==0); d=next(d for d in rows[0]['extra_inputs'] if d['module']==n); assert x['before']==x['after']==H(w/(n+'.lean')) and x['object_sha256']==d['before']==next(z['before'] for z in dec['extra_inputs']+dec['direct_inputs'] if z['module'].split('.')[-1]==n)
  for q in x['direct_inputs']:
   if q['module'].endswith('.ArithmeticCellLabels'):continue
   z=next(z for z in dec['extra_inputs'] if z['module']==q['module'].split('.')[-1]);assert z['before']==z['after']==q['before']==q['after']
 x=next(x for x in json.load(open('/dev/shm/wang-push-direct/final-target-records.json')) if x['module']=='ArithmeticWangPlane' and x['status']==0); d=next(d for d in rows[1]['direct_inputs'] if d['module'].endswith('.ArithmeticWangPlane')); assert x['before']==x['after']==d['source_before']==H(w/'ArithmeticWangPlane.lean') and x['object_sha256']==d['before']
 producer=next(x for x in json.load(open('/dev/shm/wang-push-direct/final-target-records.json')) if x['module']=='ArithmeticWangPlane')
 for n in ['ArithmeticWangTable','ArithmeticMachineRun215']:
  d=next(d for d in rows[1]['extra_inputs'] if d['module']==n);q=next(q for q in producer['direct_inputs'] if q['module'].endswith('.'+n));assert d['before']==q['before']==q['after']
print('PASS: builds, source/provider hashes, exact target/client/probe object associations, declaration and registration reports')
