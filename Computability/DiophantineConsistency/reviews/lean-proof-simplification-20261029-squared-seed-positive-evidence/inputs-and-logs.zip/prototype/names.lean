import DiophantineConsistency.ArithmeticPellSquaredSeed
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellSquaredSeed).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellSquaredSeed" then
   logInfo m!"DECL {n}"
