Squared Pell seed positive coefficient: isolated proof simplification

Baseline ArithmeticPellSquaredSeed SHA-256 c12b5f7c746ee1df1d111814b10db039049992f6b8d2cc3b8f8857cfd95510d8;
final SHA-256 9e4cc08b5992b2074d2046ef7cb4d2854b0147cc66829897b7d6ac7c5f4d8ec7.
strong_seed now derives i>0 directly from its positive ordinate y=i*c*c via
pos_of_mul_pos_left, instead of assuming i=0 and deriving a contradiction. The
existing coordinate equality is moved earlier so the very same equality serves
both positivity and the norm proof. Five lines are replaced by four; the
witnesses, original statements, guards, equations, definitions and imports are
unchanged. Tested snapshots match commit 11856f40e2 and its parent.
git blame identifies e3f8eb2ae41 as the changed proof's source;
that commit has no Co-Authored-By trailer, so no Claude attribution is claimed.

baseline/final-records.json pin source, commands, first direct input objects
before/after, outputs, logs and timings for the target and both tracked Lean
direct clients PellSquaredSeedChecks and PellAuxiliarySeed. Both phases and
both clients compile; client object bytes match. Target's Periodicity object
matches the current-source producer in /tmp/pell-y-add/final-records.json;
AuxiliarySeed's additional HalfIndex object matches the current-source producer
in /tmp/four-positive-wrappers/upstream-records.json. audit.py/.log verify those
prior source/object matches, first-provider resolution, selected builds and
target probes. Direct provider source hashes were matched to prior receipts,
not sampled at the time of these builds.

Target probes match all four namespace declaration/type/axiom reports and 28,968
default simp/13,167 instance entries. They do not establish equality of proof
bodies, every persistent extension or untested downstream behavior. Single
baseline/final shared-load user CPU samples: target 7.09/6.88 s, Checks
1.40/1.42 s, AuxiliarySeed 40.12/39.22 s; these are not general benchmarks.
Neither phase produced target or client warnings. Final target was built first
and remains stable; final-target-records.json and final-client-records.json are
separately retained and combined in final-records.json.

A post-build search-path sample of both target environments resolves older
cached IntegralSolution object 0ca27c03089cf7cfb976f4efd9580e29f6fba927e3abac1834fd246e31303e45
and older SignedPairs object 5b043450cd1f2924fcd0a51afe60fbffd1e39a1bcae221910fe8077af0c521ac;
these samples are not contemporaneous transitive input pins. Other project,
Foundation and Mathlib objects remain cached. The three explicitly tested
modules do not constitute a full current-source transitive closure rebuild or
an audit of all downstream AuxiliarySeed clients.
