import DiophantineConsistency.ArithmeticPellSquaredSeedChecks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellSquaredSeedChecks).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellSquaredSeedChecks" then
   logInfo m!"DECL {n}"
