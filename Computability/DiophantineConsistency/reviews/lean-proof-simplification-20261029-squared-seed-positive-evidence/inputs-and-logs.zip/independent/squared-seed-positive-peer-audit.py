from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/dev/shm/squared-seed-positive');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticPellSquaredSeed.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticPellSquaredSeed.lean').read_text()
old='''  have hi0 : 0<i := by
    by_contra h
    have hz : i=0 := le_antisymm (le_of_not_gt h) (by simp)
    rw [hz,zero_mul,zero_mul] at hi
    exact (ne_of_gt hy) hi''';new='''  change ycoord (R*c) a=i*c*c at hi
  have hi0 : 0<i := by
    apply pos_of_mul_pos_left (b := c*c) _ (by simp)
    rw [←mul_assoc, ←hi]
    exact hy''';after='''  change ycoord (R*c) a=i*c*c at hi
  rw [hi] at he''';assert b.count(old)==b.count(after)==1 and b.replace(old,new).replace(after,'  rw [hi] at he')==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellSquaredSeed.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('11856f40e2^')==b and gitfile('11856f40e2')==f and (W/'ArithmeticPellSquaredSeed.lean').read_text()==f;print('PASS exact substitution, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticPellSquaredSeed$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(p).stem for p in clients)==['ArithmeticPellAuxiliarySeed','ArithmeticPellSquaredSeedChecks'];print('PASS two direct module clients',clients)
paths={'ArithmeticPellPeriodicity':'/tmp/pell-y-add/final-records.json','ArithmeticPellHalfIndex':'/tmp/four-positive-wrappers/upstream-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module']==n);assert x['status']==0 and x['before']==x['after']==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticPellSquaredSeed','ArithmeticPellSquaredSeedChecks','ArithmeticPellAuxiliarySeed'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticPellSquaredSeed':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticPellSquaredSeed':assert d['before']==rec[phase][n]['object_sha256']
   else:assert d['before']==providers[n]
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticPellSquaredSeedChecks','ArithmeticPellAuxiliarySeed'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticPellSquaredSeed']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
oldpaths={'ArithmeticPellIntegralSolution':('/tmp/pell-square-direct/final-records.json','0ca27c03089cf7cfb976f4efd9580e29f6fba927e3abac1834fd246e31303e45'),'ArithmeticSignedPairs':('/tmp/signed-pairs-factors/baseline-records.json','5b043450cd1f2924fcd0a51afe60fbffd1e39a1bcae221910fe8077af0c521ac')}
for n,(path,obj) in oldpaths.items():
 x=next(x for x in read(path) if x['module']==n);assert x['status']==0 and x['before']==x['after']!=h(W/(n+'.lean')) and x['object_sha256']==obj
 for phase in ('baseline','final'):
  env=rec[phase]['ArithmeticPellSquaredSeed']['LEAN_PATH'];p=next(Path(z)/'DiophantineConsistency'/(n+'.olean') for z in env.split(':') if (Path(z)/'DiophantineConsistency'/(n+'.olean')).is_file());assert h(p)==obj;print('PASS post-build path sample',phase,n,obj,p.resolve())
print('PASS client objects and target probes; sampled old paths are not contemporaneous transitive load pins')
