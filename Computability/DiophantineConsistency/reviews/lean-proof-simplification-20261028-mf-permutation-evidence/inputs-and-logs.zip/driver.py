from pathlib import Path
import os,subprocess,sys,time,json,hashlib
r=Path('/tmp/mf-permutation-reuse-20261028');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+env.get('LEAN_PATH','')
base=Path('Computability/DiophantineConsistency/Lean'); d=base/'DiophantineConsistency'
common=['lean','-M6000','-j1','-DElab.async=false','-R',str(base)]
steps=[('target',common+[str(d/'MFWangTiles942Permutation.lean'),'-o',str(r/phase/'DiophantineConsistency/MFWangTiles942Permutation.olean')]),('client',common+[str(d/'ArithmeticCellPhysical.lean'),'-o',str(r/phase/'DiophantineConsistency/ArithmeticCellPhysical.olean')]),('axioms',common+[str(r/'axioms.lean')])]
records=[]
for n,c in steps:
 t=time.monotonic();p=subprocess.run(c,env=env,capture_output=True);log=r/f'{phase}-{n}.log';log.write_bytes(p.stdout+p.stderr)
 z={'tag':n,'command':c,'status':p.returncode,'seconds':time.monotonic()-t,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 out=r/phase/'DiophantineConsistency'/({'target':'MFWangTiles942Permutation.olean','client':'ArithmeticCellPhysical.olean'}.get(n,''))
 if n!='axioms' and out.exists():z['object_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();z['object_bytes']=out.stat().st_size
 records.append(z);print(phase,n,p.returncode,flush=True)
 if p.returncode:break
(r/f'{phase}-records.json').write_text(json.dumps(records,indent=2)+'\n')
if any(v['status'] for v in records) or len(records)!=len(steps):sys.exit(1)
