import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/pell-transport-reuse-20261028'); phase=sys.argv[1]
env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
paths=[('half-focus','Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellHalfIndexChecks.lean'),('aux-focus','Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellAuxiliarySeedChecks.lean'),('axioms',str(root/'axioms.lean'))]
records=[]
for label,path in paths:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',path]
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True,env=env);elapsed=time.monotonic()-start
 log=root/(phase+'-'+label+'.log');log.write_bytes(p.stdout+p.stderr)
 records.append({'tag':label,'cmd':cmd,'status':p.returncode,'seconds':elapsed,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(phase,label,p.returncode,flush=True)
(root/(phase+'-checks.json')).write_text(json.dumps(records,indent=2)+'\n')
if any(r['status'] for r in records):sys.exit(1)
