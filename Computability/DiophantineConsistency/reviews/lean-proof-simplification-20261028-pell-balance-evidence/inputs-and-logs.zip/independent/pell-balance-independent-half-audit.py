from pathlib import Path
import hashlib,json
r=Path('/tmp/pell-balance-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for f in sorted(r.glob('probe-half-*.json')):
 x=json.load(f.open()); bad=[]
 if x['status']!=0 or x['source_before']!=x['source_after'] or sha(x['source'])!=x['source_after']:bad.append('source/status')
 for key in ('object','second_object'):
  if x[key+'_before']!=x[key+'_after'] or sha(x[key])!=x[key+'_after']:bad.append(key)
 for p,b,a in zip(x['client_objects'],x['client_objects_before'],x['client_objects_after']):
  if b!=a or sha(p)!=a:bad.append(p)
 if len(x['client_objects'])!=4:bad.append('wrong-client-count')
 if sha(x['log'])!=x['log_sha256']:bad.append('log')
 print(f.name,'PASS' if not bad else bad)
 if bad:raise SystemExit(1)
for kind in ('interfaces','simp','instances'):
 a=r/('baseline-half-'+kind+'.log');b=r/('final-half-'+kind+'.log');
 if a.read_bytes()!=b.read_bytes():raise RuntimeError(kind+' mismatch')
 print(kind,'equal',len(a.read_text().splitlines()),'sha256',sha(a))
print('interface declarations',sum(s.startswith('DECL ') for s in (r/'baseline-half-interfaces.log').read_text().splitlines()))
