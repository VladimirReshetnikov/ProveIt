import json,hashlib
from pathlib import Path
R=Path('/tmp/pell-balance-sharing'); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
for phase in ('baseline','final'):
 recs=[]
 for suffix in ('targets-records','clients-records','combined-records'):
  p=R/f'{phase}-{suffix}.json'
  if p.exists():recs.extend(json.load(p.open()))
  else:print('MISSING',p)
 built={x['module']:x['object_sha256'] for x in recs if x['status']==0}
 for x in recs:
  bad=[]
  for key,h in [('source','after'),('object','object_sha256'),('log','log_sha256')]:
   p=x.get(key);v=x.get(h)
   if p and v and (not Path(p).is_file() or sha(p)!=v):bad.append(key)
  if x['before']!=x['after']:bad.append('source-changed')
  for d in x['direct_inputs']:
   if d['before']!=d['after'] or not Path(d['path']).is_file() or sha(d['path'])!=d['after']:bad.append('input-changed:'+d['module'])
   n=d['module'].split('.')[-1]
   if n in built and d['before']!=built[n]:bad.append('provider-mismatch:'+n)
  print(phase,x['module'],'status',x['status'],'OK' if not bad else ','.join(bad))
  if bad or x['status']:raise SystemExit(1)
for x in json.load(open(R/'combined-source-inventory.json')):
 p=Path(x['snapshot']); workspace=Path(x['workspace']);
 if sha(p)!=x['sha256']:raise RuntimeError('snapshot mismatch '+str(p))
 if sha(workspace)!=x['workspace_sha256']:print('workspace changed since inventory:',x['module'],x['phase'],sha(workspace))
 if x['phase']=='final' and x['module'] in ('ArithmeticPellPeriodicity','ArithmeticPellResidueClasses'):
  q=Path('/tmp/pell-reflection-simp/final/DiophantineConsistency')/(x['module']+'.lean')
  if sha(q)!=sha(p):raise RuntimeError('reflection mismatch')
print('source inventory and reflection hashes verified')
import subprocess
commit='4b7de916da79805087e00fcbac56bc8113dd2b6c';prefix='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for phase,ref in [('baseline',commit+'^'),('final',commit)]:
 for module in ('ArithmeticPellRecurrence','ArithmeticPellClassification'):
  p=R/phase/'DiophantineConsistency'/(module+'.lean')
  b=subprocess.check_output(['git','show',ref+':'+prefix+module+'.lean'])
  if hashlib.sha256(b).hexdigest()!=sha(p):raise RuntimeError('committed snapshot mismatch '+module+' '+phase)
  workspace=Path(prefix+module+'.lean')
  print('GIT',phase,module,ref,'snapshot=',sha(p),'workspace=',sha(workspace),'workspace_matches=',sha(workspace)==sha(p))
