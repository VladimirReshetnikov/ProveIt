import DiophantineConsistency.ArithmeticPellClassification
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticPellClassification).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellRecurrence).isPrefixOf n ||
       (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellClassification" ||
       (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellRecurrence" then
      let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let ax ← Lean.collectAxioms n
      logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
