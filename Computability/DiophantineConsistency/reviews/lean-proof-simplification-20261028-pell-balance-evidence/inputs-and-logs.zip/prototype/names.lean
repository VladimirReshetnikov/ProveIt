import DiophantineConsistency.ArithmeticPellClassification
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellClassification).isPrefixOf n ||
     (`DiophantineConsistency.ArithmeticPellRecurrence).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellClassification" ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellRecurrence" then
   logInfo m!"DECL {n}"
