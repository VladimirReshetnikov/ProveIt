from pathlib import Path
import json,hashlib,re
r=Path('/tmp/cell-weight-congruence');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());rows={};providers={}
refs=[('ArithmeticCellPhysical','/tmp/word-top-sharing/refresh-records.json'),('ListGetDCases','/tmp/carrier-set-iff-sharing/provider3-records.json'),('NativePreliminaryCount2011','/tmp/shared-padding-shift/final-targets-records.json'),('MFDoubledClause2011','/tmp/cell-construction-share/common-records.json')]
for n,f in refs:
 x=next(x for x in json.loads(Path(f).read_text()) if x.get('module',x.get('tag','')).endswith(n));sh=x.get('source_sha256',x.get('before'));assert x['status']==0 and sh==h(w/(n+'.lean'));p=r/'common/DiophantineConsistency'/(n+'.olean');assert h(p)==x['object_sha256'];providers[n]=x['object_sha256'];print('producer current source/object receipt',n,providers[n])
for ph in ('baseline','final'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n!='ArithmeticCellLocal' or ph=='baseline':assert x['before']==h(w/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);name=d['module'].split('.')[-1]
   if name in providers:assert d['before']==providers[name]
   elif name=='ArithmeticCellLocal':assert d['before']==rows[ph,name]['object_sha256'] and d['resolved']==rows[ph,name]['object']
   elif d['module']!='Mathlib.Algebra.BigOperators.ModEq':raise Exception(name)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for ph in ('baseline','final'):
 for x in get(ph+'-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticCellLocal']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
assert rows['baseline','ArithmeticCellLabels']['object_sha256']==rows['final','ArithmeticCellLabels']['object_sha256'];print('client object identical')
def decl(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(r/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decl('baseline'),decl('final');print('declaration counts',len(a),len(b));print('removed',list(a.keys()-b.keys()));print('added',list(b.keys()-a.keys()));print('changed',[k for k in a.keys()&b.keys() if a[k]!=b[k]])
for n in ('simp','instances'):
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();print(n,'identical',a==b,'counts',len(a.splitlines()),len(b.splitlines()));assert a==b
a,b=decl('baseline'),decl('final');rm={'_private.DiophantineConsistency.ArithmeticCellLocal.0.DiophantineConsistency.ArithmeticCellLocal.weight_mod_sixteen._proof_2','_private.DiophantineConsistency.ArithmeticCellLocal.0.DiophantineConsistency.ArithmeticCellLocal.weight_mod_2048._proof_1'};add={'_private.DiophantineConsistency.ArithmeticCellLocal.0.DiophantineConsistency.ArithmeticCellLocal.weight_mod_2048._proof_2'};assert a.keys()-b.keys()==rm and b.keys()-a.keys()==add and len(a.keys()&b.keys())==232 and all(a[k]==b[k] for k in a.keys()&b.keys());o=next(n for n in rm if '2048' in n);n=next(iter(add));assert a[o].replace(o,n,1)==b[n]
for name in rm|add:
 for ph in ('baseline','final'):
  for kind in ('simp','instances'):assert name not in (r/f'{ph}-{kind}.log').read_text()
print('exact generated names checked, 2048 reports identical after name normalization; all three unregistered')
