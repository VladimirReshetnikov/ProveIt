from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/cell-weight-congruence');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
a=(R/'baseline/DiophantineConsistency/ArithmeticCellLocal.lean').read_text();b=(R/'final/DiophantineConsistency/ArithmeticCellLocal.lean').read_text()
old='''private theorem weight_mod_sixteen (e : Entry) : 2 * weight e ≡ selectorUnit16 e [MOD 16] := by
  rcases e with i | j | j | j | j
  · change (2 * selectorWeight (tile i)) % 16 = 2 % 16
    simp only [selectorWeight]
    omega
  all_goals
    change (2 * 2 ^ _) % 16 = 0 % 16
    fin_cases j <;> decide

'''
new='''private theorem weight_mod_sixteen (e : Entry) : 2 * weight e ≡ selectorUnit16 e [MOD 16] := by
  change 2 * weight e ≡ selectorUnit2048 e [MOD 16]
  exact (weight_mod_2048 e).of_dvd (by norm_num)

'''
marker='section local_cell';assert a.count(old)==a.count(marker)==1 and b==a.replace(old,'').replace(marker,new+marker);rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticCellLocal.lean'
for ref,ph in [('68500896e1^','baseline'),('68500896e1','final')]:
 assert hashlib.sha256(subprocess.check_output(['git','show',ref+':'+rel])).hexdigest()==h(R/ph/'DiophantineConsistency/ArithmeticCellLocal.lean');print('git source snapshot matches',ref,ph)
assert h(W/'ArithmeticCellLocal.lean')==h(R/'final/DiophantineConsistency/ArithmeticCellLocal.lean');print('exact theorem replacement/reordering; workspace now final')
providers={}
ref=[('ArithmeticCellPhysical','/tmp/word-top-sharing/refresh-records.json'),('ListGetDCases','/tmp/carrier-set-iff-sharing/provider3-records.json'),('NativePreliminaryCount2011','/tmp/shared-padding-shift/final-targets-records.json'),('MFDoubledClause2011','/tmp/cell-construction-share/common-records.json')]
for n,p in ref:
 x=next(x for x in read(p) if x.get('module',x.get('tag','')).split('.')[-1]==n and x.get('status')==0);src=x.get('source_sha256',x.get('source_before',x.get('before')));assert src==h(W/(n+'.lean'));providers[n]=x['object_sha256'];print('prior source-built provider',n,providers[n],p)
rows={}
for ph in ['baseline','final']:
 rec=read(R/(ph+'-records.json'));assert len(rec)==2
 for x in rec:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][2]).read_text()
  if n!='ArithmeticCellLocal':assert x['before']==h(W/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n0=d['module'].split('.')[-1]
   if n0=='ArithmeticCellLocal':assert d['before']==rows[ph,n0]['object_sha256'] and d['resolved']==rows[ph,n0]['object']
   elif d['module'].startswith('DiophantineConsistency.'):assert d['before']==providers[n0],(ph,n,n0)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
print('client object hashes equal?',rows['baseline','ArithmeticCellLabels']['object_sha256']==rows['final','ArithmeticCellLabels']['object_sha256'])
for ph in ['baseline','final']:
 for x in read(R/(ph+'-probes.json')):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticCellLocal']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
def decls(ph):
 t=(R/(ph+'-interfaces.log')).read_text();return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',t) if v.strip()}
a,b=decls('baseline'),decls('final');common=a.keys()&b.keys();assert len(a)==234 and len(b)==233 and len(common)==232 and all(a[n]==b[n] for n in common)
prefix='_private.DiophantineConsistency.ArithmeticCellLocal.0.DiophantineConsistency.ArithmeticCellLocal.';old=prefix+'weight_mod_2048._proof_1';new=prefix+'weight_mod_2048._proof_2';lost=prefix+'weight_mod_sixteen._proof_2';assert a.keys()-b.keys()=={old,lost} and b.keys()-a.keys()=={new};assert a[old].replace(old,new,1)==b[new];print('232 common declaration/type/axiom reports match; removed',old,lost,'added',new,'renamed 2048 type/axioms match')
for k,c in [('simp',31283),('instances',13779)]:
 x=(R/('baseline-'+k+'.log')).read_bytes();y=(R/('final-'+k+'.log')).read_bytes();assert x==y and len(x.splitlines())==c and all(v.encode() not in x for v in [old,new,lost]);print('target',k,'identical',c)
print('PASS paired builds and probe receipts; cached closure not rebuilt')
