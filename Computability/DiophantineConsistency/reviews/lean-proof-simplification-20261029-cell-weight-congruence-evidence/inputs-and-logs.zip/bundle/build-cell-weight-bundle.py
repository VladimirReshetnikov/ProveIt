from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-cell-weight-congruence-evidence';out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/cell-weight-congruence');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','final']:
 for p in sorted((R/phase).rglob('*.lean')):add('snapshots/'+str(p.relative_to(R)),p)
for name in ['cell-weight-independent-review.txt','cell-weight-independent-audit.py','cell-weight-independent-audit.log','cell-weight-independent-preprobe-incomplete.log']:add('independent/'+name,I/name)
refs={'prior/cell-physical-refresh-records.json':'word-top-sharing/refresh-records.json','prior/list-getd-provider3-records.json':'carrier-set-iff-sharing/provider3-records.json','prior/preliminary-count-final-targets-records.json':'shared-padding-shift/final-targets-records.json','prior/mf-clause-common-records.json':'cell-construction-share/common-records.json','prior/support-cast-refresh-records.json':'support-cast/refresh-records.json','prior/support-cast-independent-refresh-mapping.json':'support-cast/independent-refresh-mapping.json'}
for n,p in refs.items():add(n,I/p)
add('bundle/build-cell-weight-bundle.py',Path(__file__))
commit='68500896e179ae0d6bdc3b260c8d0c6fb4475eaf';parent='4050e84bc693b36bfa56d40379aee4a0b81f5b7c';base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';h=lambda b:hashlib.sha256(b).hexdigest()
for phase,ref in [('baseline',parent),('final',commit)]:
 for name in ['ArithmeticCellLocal','ArithmeticCellLabels']:
  data=subprocess.check_output(['git','show',ref+':'+base+name+'.lean']);assert data==files['snapshots/'+phase+'/DiophantineConsistency/'+name+'.lean'];
  if name=='ArithmeticCellLocal':files['commit/'+phase+'.lean']=data
for n,fn in [('ArithmeticCellPhysical','prior/cell-physical-refresh-records.json'),('ListGetDCases','prior/list-getd-provider3-records.json'),('NativePreliminaryCount2011','prior/preliminary-count-final-targets-records.json'),('MFDoubledClause2011','prior/mf-clause-common-records.json')]:
 rec=next(x for x in json.loads(files[fn]) if x.get('module',x.get('tag','')).split('.')[-1]==n and x.get('status')==0);source=rec.get('source_sha256',rec.get('source_before',rec.get('before')));data=subprocess.check_output(['git','show',commit+':'+base+n+'.lean']);assert h(data)==source;files['providers/current/'+n+'.lean']=data
review=files['independent/cell-weight-independent-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Derive CellLocal modulo-16 weight congruence from modulo-2048',
 'validation':'Paired target and ArithmeticCellLabels direct-client builds pass with identical client objects. Three target and one client direct project provider source/object pairs match earlier successful producer receipts. All 232 common target declaration/type/axiom reports match; default simp (31,283 entries) and instances (13,779) match.',
 'limitations':['Two compiler-generated private names are removed: weight_mod_sixteen._proof_2 and weight_mod_2048._proof_1. One private weight_mod_2048._proof_2 is added; removed/added 2048 types and axioms match after name normalization. None is registered in the checked simp or instance census.','The completed git-grep search covered tracked Lean/Python code under Computability/DiophantineConsistency only. A wider Lean/Python/Markdown/JSON search was interrupted; the empty partial log is not an exhaustive result. Untracked sources, dynamic name construction, other file types and environments remain outside the search.','The provisional v1 moved an additional public theorem and compiled, but was superseded; its source/log/time survive without before/after input/object hash receipts. A preliminary independent audit was invoked before probes existed; its incomplete log is preserved and was superseded by the successful final audit.','Producer and broader project/Foundation/Mathlib transitive closures remain cached; no complete current-source closure build is established. One shared-load timing pair is not a general performance benchmark.','Compiled objects are not included in the ZIP; object hashes and first-provider resolution are retained in receipts, and external objects are required for independent byte checks.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
