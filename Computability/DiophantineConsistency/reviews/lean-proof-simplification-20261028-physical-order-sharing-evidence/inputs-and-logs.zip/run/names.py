from pathlib import Path
import os,subprocess,json,hashlib,time
p=Path('/tmp/physical-order-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();rs=[]
for phase in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/(phase+'-lib'))+':'+base;src=p/'names.lean';log=p/(phase+'-names.log');tm=p/(phase+'-names.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M8000','-j1','-DElab.async=false',str(src)];before=h(src);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rs.append({'phase':phase,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,2)});(p/'name-records.json').write_text(json.dumps(rs,indent=2)+'\n')
 if r.returncode or h(src)!=before:raise SystemExit(1)
a=set((p/'baseline-names.log').read_text().splitlines());b=set((p/'final-names.log').read_text().splitlines());(p/'removed-names.txt').write_text('\n'.join(sorted(a-b))+'\n');print('baseline',len(a),'final',len(b),'removed',len(a-b),'added',len(b-a));print('\n'.join(sorted(a-b)))
