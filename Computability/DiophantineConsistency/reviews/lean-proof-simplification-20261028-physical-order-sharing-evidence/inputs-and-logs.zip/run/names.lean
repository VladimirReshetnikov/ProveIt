import DiophantineConsistency.WangTiles942PhysicalOrder
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.WangTiles942PhysicalOrder).isPrefixOf n then
      logInfo m!"{n}"
