import DiophantineConsistency.WangTiles942PhysicalOrder
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    if n.toString.startsWith "_private.DiophantineConsistency.WangTiles942PhysicalOrder." then
      let axs ← collectAxioms n
      logInfo m!"NAME {n}\nTYPE {c.type}\nAXIOMS {axs}"
