import DiophantineConsistency.WangTiles942PhysicalOrder
import DiophantineConsistency.MFWangTiles942PhysicalOrder
open DiophantineConsistency
open DiophantineConsistency.WangTiles942PhysicalOrder
example (j : Fin 941) : nonStartIndex j = MF.WangTiles942PhysicalOrder.nonStartIndex j := by rfl
example (j : Fin 941) : rankMap j = MF.WangTiles942PhysicalOrder.rankMap j := by rfl
example (j : Fin 941) : (nonStartIndex j).succ = abstractIndex j := MF.WangTiles942PhysicalOrder.nonStartIndex_succ j
example (j : Fin 941) : rankMap j = j := MF.WangTiles942PhysicalOrder.rankMap_eq j
