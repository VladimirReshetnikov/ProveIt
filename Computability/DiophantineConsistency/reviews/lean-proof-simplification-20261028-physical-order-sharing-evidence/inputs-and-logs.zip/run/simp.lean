import DiophantineConsistency.WangTiles942PhysicalOrder
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n0 := `DiophantineConsistency.WangTiles942PhysicalOrder.abstractIndex_ne_zero._proof_1
  logInfo m!"DiophantineConsistency.WangTiles942PhysicalOrder.abstractIndex_ne_zero._proof_1: {t.isLemma (.decl n0 true false)} {t.isLemma (.decl n0 false false)} {t.isLemma (.decl n0 true true)} {t.isLemma (.decl n0 false true)}"
  let n1 := `DiophantineConsistency.WangTiles942PhysicalOrder.position_eq._proof_1
  logInfo m!"DiophantineConsistency.WangTiles942PhysicalOrder.position_eq._proof_1: {t.isLemma (.decl n1 true false)} {t.isLemma (.decl n1 false false)} {t.isLemma (.decl n1 true true)} {t.isLemma (.decl n1 false true)}"
  let n2 := `DiophantineConsistency.WangTiles942PhysicalOrder.value_strictAnti._proof_1
  logInfo m!"DiophantineConsistency.WangTiles942PhysicalOrder.value_strictAnti._proof_1: {t.isLemma (.decl n2 true false)} {t.isLemma (.decl n2 false false)} {t.isLemma (.decl n2 true true)} {t.isLemma (.decl n2 false true)}"
