import DiophantineConsistency.CurrentWordCopies2011
import DiophantineConsistency.MFCurrentWordCopies2011
open DiophantineConsistency
example {N : ℕ} [NeZero N] {s : ℤ} {a : ZMod N → Fin 942} :
    WangTiles942Periodic.MarkedWord N s a ↔ MF.WangTiles942Periodic.MarkedWord N s a := by
  constructor <;> intro h
  · exact ⟨h.start_at_zero, h.horizontal, h.temporal⟩
  · exact ⟨h.start_at_zero, h.horizontal, h.temporal⟩
example {n : ℕ} [NeZero n] (c k digits : ZMod n → ℕ) (W : ℕ) :
    CurrentCarryConstruction2011.Facts c W k digits ↔ MF.CurrentCarryConstruction2011.Facts c W k digits := by
  constructor <;> intro h
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
