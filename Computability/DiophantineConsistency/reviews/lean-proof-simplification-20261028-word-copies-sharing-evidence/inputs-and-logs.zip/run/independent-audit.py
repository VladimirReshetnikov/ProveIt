from pathlib import Path
import json,hashlib
p=Path('/tmp/word-copies-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();summary=[]
for fn in ('common-records.json','phase-records.json','pinned-records.json'):
 rows=json.loads((p/fn).read_text())
 for r in rows:
  cmd=r['command'];src=[x for x in cmd if x.endswith('.lean')];assert len(src)==1 and r['status']==0,(fn,r.get('tag',r.get('module')))
  assert h(src[0])==r['source_sha256']==r['source_after'] and h(cmd[4])==r['time_sha256']
  log=Path(cmd[4].removesuffix('.time')+'.log');assert h(log)==r['log_sha256'],(fn,r.get('tag',r.get('module')),'log')
  if r.get('object_sha256'):assert h(r['object'])==r['object_sha256']
  for v in r.get('direct_inputs',[]):assert h(v['path'])==v['sha256']==v['after_sha256'],v['module']
  if 'inputs_before' in r:
   assert r['inputs_before']==r['inputs_after'] and len(r['inputs_before'])==225
   for n,v in r['inputs_before'].items():
    if 'source' in v:assert h(v['source'])==v['source_sha256'],n
    assert h(v['object'])==v['object_sha256'],n
   assert r['target_before']==r['target_after']
 summary.append({'file':fn,'records':len(rows)})
for n in ('CurrentWordCopies2011','MFCurrentWordCopies2011'):
 f=p/'baseline'/'DiophantineConsistency'/(n+'.lean');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');assert f.read_bytes()==repo.read_bytes(),n
for k in ('interface','compat'):
 assert (p/('baseline-pinned-'+k+'.log')).read_bytes()==(p/('final-pinned-'+k+'.log')).read_bytes(),k
print(json.dumps(summary,indent=2));print('baseline target source snapshots match; 225 input pins per replay and interface/compat logs agree')
