from pathlib import Path
import os,json,hashlib,subprocess,time,sys
p=Path('/tmp/word-copies-sharing');probe=sys.argv[1];base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=[]
for ph in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/('phase-'+ph))+':'+base;src=p/(probe+'.lean');log=p/(ph+'-'+probe+'.log');tm=p/(ph+'-'+probe+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p),str(src)];before=h(src);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'phase':ph,'probe':probe,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'timing':tm.read_text().strip(),'elapsed':time.monotonic()-t};rs.append(rec);(p/(probe+'-records.json')).write_text(json.dumps(rs,indent=2)+'\n');print(ph,probe,r.returncode,flush=True)
 if rec["source_sha256"]!=rec["source_after"]:raise SystemExit(1)
