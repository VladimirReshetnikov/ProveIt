from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-copies-sharing');g=json.loads((p/'graph.json').read_text());nodes=g['nodes'];base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
for ph in ('baseline','final'):
 ov=p/('phase-'+ph);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def locate(n):
  for root in roots:
   f=root/(n.replace('.','/')+'.olean')
   if f.is_file():return f
  raise RuntimeError('missing object '+n)
 for name in ('MFCurrentWordCopies2011','CurrentWordCopies2011','CurrentWordCopies2011Checks','CurrentWordOrigin2011'):
  n='DiophantineConsistency.'+name;v=nodes[n];src=p/ph/(n.replace('.','/')+'.lean') if name in ('MFCurrentWordCopies2011','CurrentWordCopies2011') else Path(v['source']);root=p/ph if name in ('MFCurrentWordCopies2011','CurrentWordCopies2011') else Path.cwd()/'Computability/DiophantineConsistency/Lean';srchash=h(src);inputs=[]
  im=v['imports']
  if ph=='baseline' and name=='CurrentWordCopies2011':im=[x for x in im if x!='DiophantineConsistency.MFCurrentWordCopies2011']
  for dep in im:
   f=locate(dep);inputs.append({'module':dep,'path':str(f),'sha256':h(f),'local':dep in nodes})
  out=ov/(n.replace('.','/')+'.olean');out.unlink(missing_ok=True);log=p/(ph+'-'+name+'.log');tm=p/(ph+'-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  for x in inputs:x['after_sha256']=h(x['path'])
  rec={'phase':ph,'module':name,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':srchash,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':inputs};records.append(rec);(p/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,r.returncode,round(rec['elapsed'],1),flush=True)
  if r.returncode or rec['source_after']!=srchash or any(x['sha256']!=x['after_sha256'] for x in inputs):raise SystemExit(1)
