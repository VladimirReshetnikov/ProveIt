import pathlib,json,hashlib,re,tomllib
W=pathlib.Path.cwd();roots=[]
for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']:
 p=(W/x.get('srcDir','.')).resolve()
 if p not in roots:roots.append(p)
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(path):
 out=[]
 for line in strip(path.read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out
nodes={};ext=set();order=[]
def visit(n):
 if n in nodes or n in ext:return
 candidates=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
 if not candidates:ext.add(n);return
 assert len(candidates)==1,(n,candidates);f=(pathlib.Path('/tmp/word-copies-sharing/baseline/DiophantineConsistency')/(n.split('.')[-1]+'.lean') if n in ('DiophantineConsistency.CurrentWordCopies2011','DiophantineConsistency.MFCurrentWordCopies2011') else candidates[0]);b=f.read_bytes();im=imports(f);nodes[n]={'source':str(f),'sha256':hashlib.sha256(b).hexdigest(),'imports':im}
 for d in im:visit(d)
 order.append(n)
visit('DiophantineConsistency.CurrentWordCopies2011')
p=pathlib.Path('/tmp/word-copies-sharing/independent-baseline-target-graph.json');p.write_text(json.dumps({'nodes':nodes,'external':sorted(ext),'order':order},indent=2)+'\n');print('nodes',len(nodes),'external',len(ext))
