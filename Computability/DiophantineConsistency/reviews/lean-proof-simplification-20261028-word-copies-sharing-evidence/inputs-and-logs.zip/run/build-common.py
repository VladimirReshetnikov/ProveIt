from pathlib import Path
import json,os,hashlib,subprocess,time,shutil
p=Path('/tmp/word-copies-sharing');plan=json.loads((p/'common-plan.json').read_text());g=json.loads((p/'graph.json').read_text());nodes=g['nodes'];ov=p/'common';base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
def locate(n):
 rel=n.replace('.','/')+'.olean'
 for root in roots:
  f=root/rel
  if f.is_file():return f
 raise RuntimeError('missing object '+n)
for n in plan:
 assert shutil.disk_usage('.').free>850*1024*1024,'disk reserve'
 v=nodes[n];src=Path(v['source']);srchash=v['sha256'];root=Path.cwd()/'Computability/DiophantineConsistency/Lean';assert h(src)==srchash,n;inputs=[]
 for dep in v['imports']:
  f=locate(dep);inputs.append({'module':dep,'path':str(f),'resolved_path':str(f.resolve()),'sha256':h(f),'local':dep in nodes})
 out=ov/(n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);tag=n.split('.')[-1];log=p/('common-'+tag+'.log');tm=p/('common-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 for x in inputs:x['after_sha256']=h(x['path'])
 rec={'module':n,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':srchash,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':inputs};records.append(rec);(p/'common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,r.returncode,round(rec['elapsed'],1),flush=True)
 if r.returncode or rec['source_after']!=srchash or any(x['sha256']!=x['after_sha256'] for x in inputs):raise SystemExit(1)
print('shared refresh completed',flush=True)
