from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-copies-sharing');repo=Path.cwd()/'Computability/DiophantineConsistency/Lean';inv=json.loads((p/'inventory.json').read_text())['phases'];base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();rs=[];dynamic={'DiophantineConsistency.'+x for x in ('MFCurrentWordCopies2011','CurrentWordCopies2011','CurrentWordCopies2011Checks','CurrentWordOrigin2011')}
for n in ('CurrentWordCopies2011','MFCurrentWordCopies2011'):
 assert h(repo/'DiophantineConsistency'/(n+'.lean'))==h(p/'baseline/DiophantineConsistency'/(n+'.lean'))
for ph in ('baseline','final'):
 ov=p/('phase-'+ph);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def locate(n):
  for root in roots:
   f=root/(n.replace('.','/')+'.olean')
   if f.is_file():return f
  raise RuntimeError('missing '+n)
 def snapshot():
  d={}
  for n,v in inv[ph]['local'].items():
   if n in dynamic:continue
   src=Path(v['source']);obj=locate(n);assert h(src)==v['source_sha256'],('source',n);assert h(obj)==v['object_sha256'],('object',n)
   d[n]={'source':str(src),'source_sha256':v['source_sha256'],'object':str(obj.resolve()),'object_sha256':v['object_sha256'],'status':v['status']}
  for n,v in inv[ph]['external'].items():
   obj=locate(n);assert h(obj)==v['sha256'],('external',n);d[n]={'object':str(obj.resolve()),'object_sha256':v['sha256'],'status':'direct-external'}
  return d
 tasks=[('mf',p/ph/'DiophantineConsistency/MFCurrentWordCopies2011.lean',p/ph,'MFCurrentWordCopies2011',True),('target',p/ph/'DiophantineConsistency/CurrentWordCopies2011.lean',p/ph,'CurrentWordCopies2011',True),('checks',repo/'DiophantineConsistency/CurrentWordCopies2011Checks.lean',repo,'CurrentWordCopies2011Checks',True),('client',repo/'DiophantineConsistency/CurrentWordOrigin2011.lean',repo,'CurrentWordOrigin2011',True),('interface',p/'interface.lean',None,None,False),('compat',p/'compat.lean',None,None,False)]
 for tag,src,root,name,build in tasks:
  for n in ('CurrentWordCopies2011','MFCurrentWordCopies2011'):assert h(repo/'DiophantineConsistency'/(n+'.lean'))==h(p/'baseline/DiophantineConsistency'/(n+'.lean'))
  pre=snapshot();target=ov/'DiophantineConsistency/CurrentWordCopies2011.olean';target_before=h(target) if target.exists() else None;log=p/f'{ph}-pinned-{tag}.log';tm=p/f'{ph}-pinned-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false'];out=None
  if build:
   out=ov/'DiophantineConsistency'/(name+'.olean');out.unlink(missing_ok=True);cmd += ['-R',str(root),str(src),'-o',str(out)]
  else:cmd += ['-R',str(p),str(src)]
  before=h(src);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  after=snapshot();assert pre==after,('inputs changed',ph,tag)
  target_after=h(target) if target.exists() else None
  if tag!='target':assert target_before==target_after,(ph,tag,'target input drift')
  z={'phase':ph,'tag':tag,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(out) if out else None,'object_sha256':h(out) if out and out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'target_before':target_before,'target_after':target_after,'inputs_before':pre,'inputs_after':after};rs.append(z);(p/'pinned-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,tag,r.returncode,round(z['elapsed'],1),flush=True)
  if r.returncode or before!=h(src):raise SystemExit(1)
print('pinned replay complete',flush=True)
