from pathlib import Path
p=Path('/tmp/word-copies-sharing');base=p/'common'
for ph in ('baseline','final'):
 q=p/('phase-'+ph);q.mkdir(exist_ok=True)
 for f in base.iterdir():
  if f.name=='DiophantineConsistency':
   d=q/f.name;d.mkdir(exist_ok=True)
   for x in f.iterdir():
    if x.is_file():
     o=d/x.name
     if not o.exists():o.symlink_to(x.resolve())
  elif not (q/f.name).exists(): (q/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
print('paired overlays prepared')
