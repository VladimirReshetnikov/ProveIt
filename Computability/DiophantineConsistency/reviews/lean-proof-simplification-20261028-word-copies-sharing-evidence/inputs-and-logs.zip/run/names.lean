import DiophantineConsistency.CurrentWordCopies2011
open Lean Elab Command
run_cmd do
 for (n, _) in (← getEnv).constants.toList do
  if (`DiophantineConsistency.CurrentWordCopies2011).isPrefixOf n then logInfo m!"{n}"
#print equations DiophantineConsistency.CurrentWordCopies2011.constructedWord
