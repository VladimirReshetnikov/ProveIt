from pathlib import Path
p=Path('/tmp/word-copies-sharing');base=Path('/tmp/word-top-sharing/phase-final');q=p/'common';q.mkdir(exist_ok=True)
for n in ('Foundation','FirstOrder','PAHF','BusyBeaver','Diophantine'):
 d=q/n;s=base/n
 if not d.exists() and s.exists():d.symlink_to(s.resolve(),target_is_directory=True)
d=q/'DiophantineConsistency';d.mkdir(exist_ok=True)
for f in (base/'DiophantineConsistency').iterdir():
 if f.is_file() and (f.suffix in ('.olean','.ir') or f.name.endswith(('.olean.private','.olean.server'))):
  x=d/f.name
  if not x.exists():x.symlink_to(f.resolve())
print('overlay linked')
