import DiophantineConsistency.CurrentWordCopies2011
import DiophantineConsistency.MFCurrentWordCopies2011
open DiophantineConsistency
example (N : ℕ) (a : ZMod N → Fin 942) (dummy : ZMod N → ℕ) (s : ℕ) :
    CurrentWordCopies2011.constructedWord a dummy s =
      MF.CurrentWordCopies2011.constructedWord a dummy s := rfl
example (a : ZMod 0 → Fin 942) (dummy : ZMod 0 → ℕ)
    (hd : ∀ j, dummy j ≤ 1) (s : ℕ) (k : ZMod (0*2011)) :
    CurrentWordCopies2011.constructedWord a dummy s k ≤ 1 :=
  CurrentWordCopies2011.constructed_boolean a dummy hd s k
example (a : ZMod 0 → Fin 942) (dummy : ZMod 0 → ℕ)
    (s : ℕ) (k : ZMod (0*2011))
    (hk : k.val%2011 ∉ CurrentMasks2011.lowSupport) :
    CurrentWordCopies2011.constructedWord a dummy s k = 0 :=
  CurrentWordCopies2011.constructed_support a dummy s k hk
