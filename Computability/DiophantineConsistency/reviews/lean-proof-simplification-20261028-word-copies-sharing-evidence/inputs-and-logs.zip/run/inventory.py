from pathlib import Path
import os,json,hashlib,subprocess
p=Path('/tmp/word-copies-sharing');g=json.loads((p/'graph.json').read_text());top=json.loads(Path('/tmp/word-top-sharing/inventory.json').read_text())['local'];common={x['module']:x for x in json.loads((p/'common-records.json').read_text())};phase={(x['phase'],'DiophantineConsistency.'+x['module']):x for x in json.loads((p/'phase-records.json').read_text())};carry={x['module']:x for x in json.loads(Path('/tmp/carry-proof-sharing/phase-records.json').read_text()) if x['phase']=='final' and x['module'] in ('CurrentCarryConstruction2011','MFCurrentCarryConstruction2011')};base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();out={};issues=[]
for ph in ('baseline','final'):
 roots=[p/('phase-'+ph)]+[Path(x) for x in base.split(':') if x]
 def locate(n):
  for root in roots:
   f=root/(n.replace('.','/')+'.olean')
   if f.is_file():return f
  raise RuntimeError('missing object '+n)
 local={}
 for n,v in g['nodes'].items():
  src=Path(v['source']); sh=h(src);f=locate(n);oh=h(f)
  if sh!=v['sha256']:issues.append([ph,n,'source drift'])
  if (ph,n) in phase:
   r=phase[(ph,n)];status='phase rebuilt';assert oh==r['object_sha256']
  elif n in common:
   r=common[n];status='common rebuilt';assert oh==r['object_sha256']
  elif n.split('.')[-1] in carry and n.startswith('DiophantineConsistency.'):
   r=carry[n.split('.')[-1]];status='carry target';assert oh==r['object_sha256'] and sh==r['source_sha256']
  elif n in top:
   r=top[n];status='top '+r['status'];assert oh==r['object_sha256'] and sh==r['source_sha256'],(n,ph,status,oh,r['object_sha256'],sh,r['source_sha256'])
  else:issues.append([ph,n,'no receipt']);status='unmatched'
  local[n]={'source':str(src),'source_sha256':sh,'path':str(f),'resolved':str(f.resolve()),'object_sha256':oh,'status':status}
 external={n:{'path':str(f),'sha256':h(f)} for n in g['external'] for f in [locate(n)]}
 out[ph]={'local':local,'external':external}
(p/'inventory.json').write_text(json.dumps({'phases':out,'issues':issues},indent=2)+'\n');print('pins',len(out['baseline']['local']),'local,',len(out['baseline']['external']),'external; issues',issues)
