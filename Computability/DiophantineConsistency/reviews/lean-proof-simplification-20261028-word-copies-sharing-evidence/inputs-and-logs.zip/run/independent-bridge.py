from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-copies-sharing');src=p/'independent-bridge.lean';lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
for ph in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/('phase-'+ph))+':'+lp;log=p/(ph+'-independent-bridge.log');tm=p/(ph+'-independent-bridge.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false',str(src)];before=h(src);start=time.monotonic()
 with log.open('wb') as f:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 r={'phase':ph,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'elapsed':round(time.monotonic()-start,2)};records.append(r);(p/'independent-bridge-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,rc,flush=True)
 if rc or r['source_after']!=before:raise SystemExit(1)
