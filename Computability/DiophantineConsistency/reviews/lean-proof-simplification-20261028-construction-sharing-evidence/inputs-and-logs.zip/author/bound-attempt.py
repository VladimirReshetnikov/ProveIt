from pathlib import Path
import hashlib,subprocess,os,time,json
R=Path('/tmp/construction-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final']:
 ov=R/phase;z=ov/'DiophantineConsistency/ArithmeticConstructionZero.olean';z.unlink(missing_ok=True);z.symlink_to((R/'common/DiophantineConsistency/ArithmeticConstructionZero.olean').resolve());src=ov/'DiophantineConsistency/ArithmeticConstructionBound.lean';obj=src.with_suffix('.olean');obj.unlink(missing_ok=True);log=R/(phase+'-bound-attempt.log');env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;cmd=['lean','-M10000','-j1','-DElab.async=false','-R',str(ov),str(src),'-o',str(obj)];start=time.monotonic();pre=h(src)
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'phase':phase,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src),'source_sha256':pre,'source_after':h(src),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'log':str(log),'log_sha256':h(log)};records.append(d);(R/'bound-attempt-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,p.returncode,flush=True)
