from pathlib import Path
import os,subprocess,hashlib,json,time
R=Path('/tmp/construction-share');root=Path('Computability/DiophantineConsistency/Lean');src=root/'DiophantineConsistency/ArithmeticCurrentConstruction2011.lean';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final']:
 ov=R/('coherent-'+phase);out=ov/'DiophantineConsistency/ArithmeticCurrentConstruction2011.olean';out.unlink(missing_ok=True);log=R/(phase+'-coherent-client.log');tm=R/(phase+'-coherent-client.time');env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;deps=[]
 for n in ['ArithmeticConstructionAssembly','ArithmeticConstructionZero','ArithmeticCurrentSentence2011']:
  p=ov/'DiophantineConsistency'/(n+'.olean');assert p.is_file(),str(p);deps.append({'module':n,'object':str(p.resolve()),'sha256':h(p)})
 cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];pre=h(src);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 x={'phase':phase,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src.resolve()),'source_sha256':pre,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':deps};records.append(x);(R/'coherent-client-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,p.returncode,round(x['elapsed'],1),flush=True)
 if p.returncode or pre!=x['source_after']:raise SystemExit(1)
