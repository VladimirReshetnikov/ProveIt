from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/tmp/construction-share');A=Path('/tmp/bound-graph-independent');O=Path('/tmp/outer-seed-bound-sharing');D=Path('/tmp/dag-independent-audit');out=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261028-construction-sharing-evidence');out.mkdir(parents=True,exist_ok=False);h=lambda b:hashlib.sha256(b).hexdigest();members={}
def add(name,data):
 assert name not in members,name
 members[name]=data
for folder,prefix in [(R,'author'),(A,'independent-review')]:
 for p in sorted(folder.iterdir()):
  if p.is_file() and p.suffix in ('.json','.lean','.py','.log','.time','.txt','.md'):add(prefix+'/'+p.name,p.read_bytes())
for phase in ['baseline','final']:
 for name in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
  p=R/phase/'DiophantineConsistency'/(name+'.lean');add('snapshots/'+phase+'/'+name+'.lean',p.read_bytes())
g=json.load(open(R/'bound-graph-after-mask.json'))
for n,v in sorted(g['nodes'].items()):
 if n in ['DiophantineConsistency.ArithmeticConstructionAssembly','DiophantineConsistency.ArithmeticConstructionBound']:p=R/'baseline/DiophantineConsistency'/(n.split('.')[-1]+'.lean')
 else:p=Path(v['source'])
 data=p.read_bytes();assert h(data)==v['source_sha256'],n;add('snapshots/graph-inputs/'+n.replace('.','/')+'.lean',data)
client=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticCurrentConstruction2011.lean');cr=json.load(open(R/'coherent-client-records.json'));data=client.read_bytes();assert all(h(data)==x['source_sha256'] for x in cr);add('snapshots/client/ArithmeticCurrentConstruction2011.lean',data)
receipts={
 'assembly/assembly-final-pins.json':O/'assembly-final-pins.json',
 'assembly/assembly-plan.json':O/'assembly-plan.json',
 'assembly/assembly-busy-pins.json':O/'assembly-busy-pins.json',
 'assembly/assembly-pahf-pins.json':O/'assembly-pahf-pins.json',
 'assembly/assembly-builds2.json':O/'assembly-builds2.json',
 'assembly/prereq-records.json':O/'prereq-records.json',
 'assembly/prereq2-records.json':O/'prereq2-records.json',
 'assembly/foundation-overlap.json':O/'foundation-overlap.json',
 'bisim/prior-141-pins.json':Path('/tmp/bisim-share/prior-141-pins.json'),
 'pell/paired-records.json':Path('/tmp/pell-share/paired-records.json'),
 'pell/audit.json':Path('/tmp/pell-share/audit.json'),
 'mask/paired-records.json':Path('/tmp/mask-digits-bound/paired-records.json'),
 'fol/records.json':Path('/tmp/enumerator-firstorder-refresh/records.json'),
 'dag/fol-refresh-records.json':D/'fol-refresh-records.json'}
for name,path in receipts.items():add('predecessor-receipts/'+name,path.read_bytes())
for name in ['final-target.log','final-target.time']:
 p=Path('/tmp/mask-digits-bound')/name
 if p.exists():add('predecessor-receipts/mask/'+name,p.read_bytes())
records=json.load(open(D/'fol-refresh-records.json'));reuse=json.load(open(R/'fol-peer-reuse.json'))['accepted'];lookup={x['module']:x for x in records}
for item in reuse:
 x=lookup[item['module']]
 for key in ['log','time']:
  p=Path(x[key]);data=p.read_bytes();assert h(data)==x[key+'_sha256'],item['module'];add('predecessor-receipts/dag/logs/'+p.name,data)
fol=next(x for x in json.load(open('/tmp/enumerator-firstorder-refresh/records.json')) if x['module']=='FirstOrder.Fol')
for key in ['log_path','time_path']:
 p=Path(fol[key]);k='log_sha256' if key=='log_path' else 'time_sha256';data=p.read_bytes();assert h(data)==fol[k];add('predecessor-receipts/fol/logs/'+p.name,data)
commit='1b2d29dded26b7b7ab3d4fef20367eca6eb379ab'
for name in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
 path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+name+'.lean';assert subprocess.check_output(['git','show',commit+':'+path])==members['snapshots/final/'+name+'.lean']
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and sorted(z.namelist())==sorted(members)
 for name,data in members.items():assert z.read(name)==data,name
bundle={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'scope':'Share the explicit bounded arithmetic construction with its unbounded Assembly entry point','validation':'All 93 scoped source refreshes, the corrected rank-forcing build, and paired Assembly, Bound and direct CurrentConstruction production-client builds pass. A final eight-run replay checks 182 non-target local source/object pairs and 73 direct external objects before and after each run, and pins the rebuilt target inputs separately. All 56 existing public/generated declaration type and axiom reports and five forced bound-definition equations match; one added helper has only propext, Classical.choice and Quot.sound. Both independently probed CurrentConstruction declarations match. Independent review and packaging audit recheck 93 refresh records, 368 phase local pins, 146 phase direct-external pins and all 184 graph source snapshots.','limitations':'Assembly now imports ArithmeticConstructionBoundPell and exposes the existing bound namespace definitions earlier, plus the new construction_below_hL helper; existing 56 named interfaces and their axiom/equation reports match. Earlier Assembly builds used an outdated FirstOrder.Fol object and are preliminary; both initial Bound attempts failed before elaboration because ArithmeticCurrentSentence2011 was absent. All are retained separately from the successful current-source replay. An ArithmeticMaskConstants commit occurred mid-refresh: the original RankForcing build used its old object, its record and log are retained as superseded, and the corrected build uses the newly authenticated object and matching direct inputs. The 93 shared prerequisite logs contain 90 linter warnings, and the 12 reused peer logs contain another 11, with no paired preparation baselines. Each common-name axiom probe contains 22 matching autogenerated-auxiliary warnings; final target and client build logs are warning-free. Foundation, Mathlib and transitive external inputs remain precompiled; the 73 direct external object pins are not a full transitive package audit. The initial preliminary ConstructionZero prototype did not record timing or a structured command receipt. Binary objects, including the superseded rank object, and the external toolchain are deliberately omitted; hash receipts remain, so the archive is not a self-contained build environment.','archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{name:{'sha256':h(data),'bytes':len(data)} for name,data in sorted(members.items())}}
(out/'BUNDLE.json').write_text(json.dumps(bundle,indent=2,ensure_ascii=False)+'\n')
loaded=json.load(open(out/'BUNDLE.json'));assert loaded['archive_sha256']==h(archive.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(loaded['members'])
 for n,m in loaded['members'].items():
  data=z.read(n);assert h(data)==m['sha256'] and len(data)==m['bytes']
assert not any(n.endswith(('.olean','.ir','.olean.server','.olean.private')) for n in members)
print('members',len(members),'zip bytes',archive.stat().st_size,'sha256',loaded['archive_sha256'])
