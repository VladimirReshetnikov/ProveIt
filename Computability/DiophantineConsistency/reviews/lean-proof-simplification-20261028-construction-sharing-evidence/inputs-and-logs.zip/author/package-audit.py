from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/construction-share');A=Path('/tmp/bound-graph-independent');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();issues=[];rows=json.load(open(R/'bound-refresh-records.json'));assert len(rows)==93
for x in rows:
 n=x['module'];obj=R/'superseded-RankForcing.olean' if n=='DiophantineConsistency.ArithmeticRankForcing2011' else Path(x['object'])
 for p,k in [(x['source'],'source_sha256'),(x['log'],'log_sha256'),(x['time'],'time_sha256'),(obj,'object_sha256')]:
  if not Path(p).is_file() or h(p)!=x[k]:issues.append('refresh '+n+' '+k)
 if x['status'] or x['source_sha256']!=x['source_after'] or Path(x['time']).read_text().strip()!=x['timing']:issues.append('refresh status '+n)
 for d in x['direct_project_inputs']:
  if not Path(d['object']).is_file() or h(d['object'])!=d['sha256']:issues.append('refresh input '+n+' '+d['module'])
r=json.load(open(R/'corrected-RankForcing-record.json'))
for p,k in [(r['source'],'source_sha256'),(r['log'],'log_sha256'),(r['time'],'time_sha256'),(r['object'],'object_sha256')]:
 if not Path(p).is_file() or h(p)!=r[k]:issues.append('corrected rank '+k)
for d in r['direct_project_inputs']:
 if h(d['object'])!=d['sha256']:issues.append('corrected rank input '+d['module'])
for fn in ['coherent-phase-records.json','coherent-client-records.json','coherent-axiom-records.json','pinned-replay-records.json']:
 for x in json.load(open(R/fn)):
  tag=x.get('module',x.get('tag','client'))
  for p,k in [('source','source_sha256'),('object','object_sha256'),('log','log_sha256'),('time','time_sha256')]:
   if x.get(p) and x.get(k) and (not Path(x[p]).is_file() or h(x[p])!=x[k]):issues.append(fn+' '+x['phase']+' '+tag+' '+p)
  if x['status'] or x['source_sha256']!=x['source_after']:issues.append(fn+' status '+tag)
for p in ['audit.json','audit-final-refresh.json','audit-phases.json','audit-pinned.json','audit-client.json']:
 x=json.load(open(A/p));z=x.get('issues',x.get('summary',{}).get('issues',[]));
 if z:issues.append('independent audit issues '+p)
I=json.load(open(A/'audit-phases.json'))
for x in I['local_pins']:
 for p,k in [('source','source_sha256'),('object','object_sha256')]:
  if not Path(x[p]).is_file() or h(x[p])!=x[k]:issues.append('local pin '+x['phase']+' '+x['module']+' '+p)
for x in I['external_pins']:
 if not Path(x['object']).is_file() or h(x['object'])!=x['sha256']:issues.append('external pin '+x['phase']+' '+x['module'])
for x in json.load(open(A/'pinned-client-probe-records.json')):
 for p,k in [('source','source_sha256'),('log','log_sha256'),('time','time_sha256')]:
  if x.get(p) and x.get(k) and (not Path(x[p]).is_file() or h(x[p])!=x[k]):issues.append('independent client probe '+x['phase']+' '+p)
 if x.get('status')!=0:issues.append('independent probe status')
commit='1b2d29dded';gitcommit=subprocess.check_output(['git','rev-parse',commit],text=True).strip()
for name in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
 rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+name+'.lean';data=subprocess.check_output(['git','show',gitcommit+':'+rel]);snapshot=(R/'final/DiophantineConsistency'/(name+'.lean')).read_bytes()
 if data!=snapshot:issues.append('commit snapshot '+name)
g=json.load(open(R/'bound-graph-after-mask.json'))
for n,v in g['nodes'].items():
 if n in ['DiophantineConsistency.ArithmeticConstructionAssembly','DiophantineConsistency.ArithmeticConstructionBound']:src=R/'baseline/DiophantineConsistency'/(n.split('.')[-1]+'.lean')
 else:src=Path(v['source'])
 if h(src)!=v['source_sha256']:issues.append('graph source '+n)
if (R/'baseline-pinned-axioms.log').read_bytes()!=(R/'final-pinned-axioms.log').read_bytes():issues.append('axiom mismatch')
report={'commit':gitcommit,'refresh_records':len(rows),'local_phase_pins':len(I['local_pins']),'external_phase_pins':len(I['external_pins']),'graph_sources':len(g['nodes']),'issues':issues};(R/'package-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert not issues
