from pathlib import Path
import json,hashlib,subprocess,os,time
R=Path('/tmp/construction-share');I=json.load(open('/tmp/bound-graph-independent/audit-phases.json'));h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];targets={'DiophantineConsistency.ArithmeticConstructionAssembly','DiophantineConsistency.ArithmeticConstructionBound'}
for phase in ['baseline','final']:
 ov=R/('pinned-'+phase);previous=R/('coherent-'+phase);ov.mkdir(exist_ok=True)
 (ov/'Foundation').symlink_to((previous/'Foundation').resolve(),target_is_directory=True)
 for ns in ['FirstOrder','BusyBeaver','PAHF','Diophantine','DiophantineConsistency']:
  source=previous/ns;target=ov/ns;target.mkdir(exist_ok=True)
  for p in source.rglob('*'):
   if p.is_file():
    q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(p.resolve())
 local=[x for x in I['local_pins'] if x['phase']==phase and x['module'] not in targets];external=[x for x in I['external_pins'] if x['phase']==phase];assert len(local)==182 and len(external)==73
 env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base
 def check():
  for x in local:
   p=ov/(x['module'].replace('.','/')+'.olean')
   if not p.is_file() or h(p)!=x['object_sha256'] or h(x['source'])!=x['source_sha256']:raise RuntimeError('local pin '+x['module'])
  for x in external:
   found=next(((Path(d)/(x['module'].replace('.','/')+'.olean')).resolve() for d in env['LEAN_PATH'].split(':') if d and (Path(d)/(x['module'].replace('.','/')+'.olean')).is_file()),None)
   if not found or found!=Path(x['object']).resolve() or h(found)!=x['sha256']:raise RuntimeError('external pin '+x['module'])
 def run(tag,src,root=None,obj=None,extra=[]):
  check()
  for d in extra:
   if h(d['object'])!=d['sha256']:raise RuntimeError('target input '+d['module'])
  if obj:obj.unlink(missing_ok=True)
  log=R/(phase+'-pinned-'+tag+'.log');tm=R/(phase+'-pinned-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false']
  if root:cmd+=['-R',str(root)]
  cmd+=[str(src)]
  if obj:cmd+=['-o',str(obj)]
  pre=h(src);start=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  check()
  for d in extra:
   if h(d['object'])!=d['sha256']:raise RuntimeError('target input changed '+d['module'])
  rec={'phase':phase,'tag':tag,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src.resolve()),'source_sha256':pre,'source_after':h(src),'object':str(obj) if obj else None,'object_sha256':h(obj) if obj and obj.exists() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'checked_local_inputs':len(local),'checked_direct_external_inputs':len(external),'target_inputs':extra,'input_manifest':'/tmp/bound-graph-independent/audit-phases.json','input_manifest_sha256':h('/tmp/bound-graph-independent/audit-phases.json')};records.append(rec);(R/'pinned-replay-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,p.returncode,round(rec['elapsed'],1),flush=True)
  if p.returncode or pre!=rec['source_after']:raise SystemExit(1)
 asm=ov/'DiophantineConsistency/ArithmeticConstructionAssembly.olean';src=R/phase/'DiophantineConsistency/ArithmeticConstructionAssembly.lean';run('Assembly',src,R/phase,asm)
 dep=[{'module':'Assembly','object':str(asm),'sha256':h(asm)}]
 bnd=ov/'DiophantineConsistency/ArithmeticConstructionBound.olean';src=R/phase/'DiophantineConsistency/ArithmeticConstructionBound.lean';run('Bound',src,R/phase,bnd,dep)
 src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticCurrentConstruction2011.lean');obj=ov/'DiophantineConsistency/ArithmeticCurrentConstruction2011.olean';run('CurrentConstruction',src,Path('Computability/DiophantineConsistency/Lean'),obj,dep)
 run('axioms',R/'coherent-axioms.lean',extra=dep+[{'module':'Bound','object':str(bnd),'sha256':h(bnd)}])
print('pinned replay completed',flush=True)
