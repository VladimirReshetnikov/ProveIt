from pathlib import Path
import os,subprocess,hashlib,json,time
R=Path('/tmp/construction-share');common=R/'fol-coherent';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final']:
 ov=R/('coherent-'+phase);ov.mkdir(exist_ok=True)
 for ns in ['Foundation']:
  q=ov/ns
  if not q.exists():q.symlink_to((common/ns).resolve(),target_is_directory=True)
 for ns in ['FirstOrder','BusyBeaver','PAHF','Diophantine','DiophantineConsistency']:
  source=common/ns;target=ov/ns;target.mkdir(exist_ok=True)
  if source.exists():
   for p in source.rglob('*'):
    if not p.is_file():continue
    q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
    if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base
 for name in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
  src=R/phase/'DiophantineConsistency'/(name+'.lean');obj=ov/'DiophantineConsistency'/(name+'.olean');obj.unlink(missing_ok=True);log=R/(phase+'-coherent-'+name+'.log');tm=R/(phase+'-coherent-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(R/phase),str(src),'-o',str(obj)];before=h(src);start=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  x={'phase':phase,'module':name,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip()};records.append(x);(R/'coherent-phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,p.returncode,round(x['elapsed'],1),flush=True)
  if p.returncode or before!=x['source_after']:raise SystemExit(1)
