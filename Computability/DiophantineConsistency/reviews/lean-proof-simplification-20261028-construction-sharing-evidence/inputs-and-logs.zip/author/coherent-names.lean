import DiophantineConsistency.ArithmeticConstructionBound
open Lean Elab Command
#print equations DiophantineConsistency.ArithmeticConstructionBound.Nb
#print equations DiophantineConsistency.ArithmeticConstructionBound.Q
#print equations DiophantineConsistency.ArithmeticConstructionBound.Rq
#print equations DiophantineConsistency.ArithmeticConstructionBound.Wb
#print equations DiophantineConsistency.ArithmeticConstructionBound.zeroBound
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticConstructionAssembly).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticConstructionBound).isPrefixOf n then
      logInfo m!"DECL {n}"
