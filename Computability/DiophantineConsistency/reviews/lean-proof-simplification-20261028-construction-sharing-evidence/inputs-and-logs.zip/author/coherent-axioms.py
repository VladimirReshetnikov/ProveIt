from pathlib import Path
import hashlib,os,subprocess,json,time
R=Path('/tmp/construction-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
def run(phase,tag,source):
 env=os.environ.copy();env['LEAN_PATH']=str(R/('coherent-'+phase))+':'+base;log=R/(phase+'-coherent-'+tag+'.log');tm=R/(phase+'-coherent-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(source)];pre=h(source);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 x={'phase':phase,'tag':tag,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(source),'source_sha256':pre,'source_after':h(source),'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip()};records.append(x);(R/'coherent-axiom-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,p.returncode,round(x['elapsed'],1),flush=True)
 if p.returncode or pre!=x['source_after']:raise SystemExit(1)
for p in ['baseline','final']:run(p,'names',R/'coherent-names.lean')
parse=lambda p:sorted(set(x.removeprefix('DECL ') for x in p.read_text().splitlines() if x.startswith('DECL ')));a=parse(R/'baseline-coherent-names.log');b=parse(R/'final-coherent-names.log');removed=sorted(set(a)-set(b));added=sorted(set(b)-set(a));(R/'coherent-names-comparison.json').write_text(json.dumps({'baseline':a,'final':b,'removed':removed,'added':added},indent=2)+'\n');print('old',len(a),'removed',removed,'added',added,flush=True)
common=sorted(set(a)&set(b));defs=['Nb','Q','Rq','Wb','zeroBound'];src=R/'coherent-axioms.lean';src.write_text('import DiophantineConsistency.ArithmeticConstructionBound\nset_option pp.all true\n'+''.join('#print equations DiophantineConsistency.ArithmeticConstructionBound.'+d+'\n' for d in defs)+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in common))
for p in ['baseline','final']:run(p,'axioms',src)
if (R/'baseline-coherent-axioms.log').read_bytes()!=(R/'final-coherent-axioms.log').read_bytes():raise SystemExit('matched-name reports differ')
if removed:raise SystemExit('removed old names')
if added:
 src=R/'coherent-added-axioms.lean';src.write_text('import DiophantineConsistency.ArithmeticConstructionBound\n'+''.join('#print axioms '+n+'\n' for n in added));run('final','added-axioms',src)
