from pathlib import Path
import hashlib,os,subprocess,json,time
R=Path('/tmp/construction-share');common=R/'common';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final']:
 ov=R/phase
 for ns in ['Foundation','FirstOrder','BusyBeaver','PAHF']:
  q=ov/ns
  if not q.exists():q.symlink_to((common/ns).resolve(),target_is_directory=True)
 for p in (common/'DiophantineConsistency').iterdir():
  if p.suffix!='.olean':continue
  q=ov/'DiophantineConsistency'/p.name
  if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 src=ov/'DiophantineConsistency/ArithmeticConstructionAssembly.lean';obj=src.with_suffix('.olean');obj.unlink(missing_ok=True);log=R/(phase+'-assembly.log');tm=R/(phase+'-assembly.time');env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(ov),str(src),'-o',str(obj)];before=h(src);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'phase':phase,'name':'Assembly','status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'log':str(log),'log_sha256':h(log),'time':tm.read_text()};records.append(d);(R/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,'Assembly',p.returncode,round(d['elapsed'],1),flush=True)
 if p.returncode or before!=d['source_after']:raise SystemExit(1)
