from pathlib import Path
import hashlib,os,subprocess,time,json
R=Path('/tmp/construction-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
def run(phase,tag,src):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)];log=R/(phase+'-'+tag+'.log');before=h(src);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 r={'phase':phase,'tag':tag,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src),'source_sha256':before,'source_after':h(src),'log':str(log),'log_sha256':h(log)};records.append(r);(R/'axiom-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,p.returncode,round(r['elapsed'],1),flush=True)
 if p.returncode:raise SystemExit(1)
for p in ['baseline','final']:run(p,'names',R/'names.lean')
parse=lambda p:sorted(x.removeprefix('DECL ') for x in p.read_text().splitlines() if x.startswith('DECL '));a=parse(R/'baseline-names.log');b=parse(R/'final-names.log');(R/'names-comparison.json').write_text(json.dumps({'baseline':a,'final':b},indent=2)+'\n');print('names',len(a),'added',set(b)-set(a),'removed',set(a)-set(b),flush=True)
if a!=b:raise SystemExit(2)
src=R/'axioms.lean';src.write_text('import DiophantineConsistency.ArithmeticConstructionAssembly\nset_option pp.all true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in a))
for p in ['baseline','final']:run(p,'axioms',src)
if (R/'baseline-axioms.log').read_bytes()!=(R/'final-axioms.log').read_bytes():raise SystemExit('mismatched reports')
new=R/'new-axioms.lean';new.write_text('import DiophantineConsistency.ArithmeticConstructionAssembly\n#print axioms DiophantineConsistency.ArithmeticConstructionBound.construction_below_hL\n');run('final','new-axioms',new)
