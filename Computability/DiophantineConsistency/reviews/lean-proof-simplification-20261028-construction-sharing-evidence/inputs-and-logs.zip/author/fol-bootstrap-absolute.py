from pathlib import Path
import os,hashlib,json,subprocess,time
R=Path('/tmp/construction-share');old=R/'common';out=R/'fol-coherent';out.mkdir(exist_ok=True);h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for ns in ['FirstOrder','BusyBeaver','PAHF','DiophantineConsistency']:
 src=old/ns;dst=out/ns;dst.mkdir(exist_ok=True)
 if src.exists():
  for p in src.rglob('*'):
   if not p.is_file():continue
   q=dst/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
for ns in ['Foundation','Diophantine']:
 q=out/ns
 if not q.exists() and (old/ns).exists():q.symlink_to((old/ns).resolve(),target_is_directory=True)
fol=out/'FirstOrder/Fol.olean';fol.unlink(missing_ok=True);fol.symlink_to(Path('/tmp/enumerator-firstorder-refresh/common/FirstOrder/Fol.olean'))
root=Path('Computability/BusyBeaver/Lean');src=root/'BusyBeaver/ZFC/TarskiComplete.lean';obj=out/'BusyBeaver/ZFC/TarskiComplete.olean';obj.unlink(missing_ok=True);log=R/'fol-bootstrap-TarskiComplete.log';tm=R/'fol-bootstrap-TarskiComplete.time';env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src.resolve()),'-o',str(obj)];before=h(src);start=time.monotonic()
with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
d={'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src.resolve()),'source_sha256':before,'source_after':h(src),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'direct_inputs':{n:{'path':str((out/(n.replace('.','/')+'.olean')).resolve()),'sha256':h(out/(n.replace('.','/')+'.olean'))} for n in ['FirstOrder.Fol','BusyBeaver.ZFC.TarskiClean']}};(R/'fol-bootstrap-record.json').write_text(json.dumps(d,indent=2)+'\n');peer=next(x for x in json.load(open('/tmp/dag-independent-audit/fol-refresh-records.json')) if x['module']=='BusyBeaver.ZFC.TarskiComplete');print('status',p.returncode,'peer object equality',d['object_sha256']==peer['object_sha256'],flush=True)
if p.returncode:raise SystemExit(1)
