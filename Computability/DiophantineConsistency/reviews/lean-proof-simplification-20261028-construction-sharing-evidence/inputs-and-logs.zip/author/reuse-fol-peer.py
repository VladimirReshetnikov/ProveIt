from pathlib import Path
import json,hashlib
R=Path('/tmp/construction-share');ov=R/'fol-coherent';g=json.load(open(R/'bound-graph.json'));rows=json.load(open('/tmp/dag-independent-audit/fol-refresh-records.json'));p={x['module']:x for x in rows};h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ok=[];bad=[]
for n in g['order']:
 if n not in p:continue
 x=p[n];issues=[];src=Path(g['nodes'][n]['source']);obj=Path(x['object'])
 if x['status'] or h(src)!=x['source_sha256'] or h(obj)!=x['object_sha256'] or h(x['log'])!=x['log_sha256'] or h(x['time'])!=x['time_sha256']:issues.append('record/source/object/log/time')
 for dep,d in x['direct_project_inputs'].items():
  selected=ov/(dep.replace('.','/')+'.olean')
  if not selected.is_file() or h(selected)!=d['sha256']:issues.append(dep)
 if issues:bad.append({'module':n,'issues':issues});continue
 target=ov/(n.replace('.','/')+'.olean');target.unlink(missing_ok=True);target.symlink_to(obj.resolve());ok.append({'module':n,'source':str(src),'source_sha256':h(src),'object':str(obj),'object_sha256':h(obj),'inputs':x['direct_project_inputs']})
(R/'fol-peer-reuse.json').write_text(json.dumps({'accepted':ok,'rejected':bad},indent=2)+'\n');print('accepted',len(ok),'rejected',len(bad));print('rejected',bad)
