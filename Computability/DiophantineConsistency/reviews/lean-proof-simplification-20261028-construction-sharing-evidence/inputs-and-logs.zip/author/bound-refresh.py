from pathlib import Path
import hashlib,subprocess,os,time,json,tomllib,shutil
R=Path('/tmp/construction-share');W=Path.cwd();ov=R/'fol-coherent';g=json.load(open(R/'bound-graph.json'));plan=json.load(open(R/'bound-refresh-plan.json'));assert not plan['unmatched'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();roots=[]
for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']:
 p=(W/x.get('srcDir','.')).resolve()
 if p not in roots:roots.append(p)
for n in plan['order']:
 o=ov/(n.replace('.','/')+'.olean');o.unlink(missing_ok=True)
 for suff in ['.server','.private']:(Path(str(o)+suff)).unlink(missing_ok=True)
 o.with_suffix('.ir').unlink(missing_ok=True)
env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for n in plan['order']:
 if shutil.disk_usage('/tmp').free<768*1024**2:print('disk reserve reached',flush=True);raise SystemExit(4)
 v=g['nodes'][n];src=Path(v['source']);before=h(src);assert before==v['source_sha256'],n;rel=n.replace('.','/')+'.lean';candidates=[r for r in roots if (r/rel).is_file() and (r/rel).resolve()==src.resolve()];assert len(candidates)==1,n;root=candidates[0];obj=ov/(n.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);inputs=[]
 for dep in v['imports']:
  if dep in g['nodes']:
   p=ov/(dep.replace('.','/')+'.olean')
   if not p.is_file():raise RuntimeError('missing '+dep+' for '+n)
   inputs.append({'module':dep,'object':str(p.resolve()),'sha256':h(p)})
 tag=n.replace('.','_');log=R/('bound-refresh-'+tag+'.log');tm=R/('bound-refresh-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'module':n,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_project_inputs':inputs};records.append(rec);(R/'bound-refresh-records.json').write_text(json.dumps(records,indent=2)+'\n');print(len(records),'/',len(plan['order']),n,p.returncode,round(rec['elapsed'],1),flush=True)
 if p.returncode or before!=rec['source_after']:raise SystemExit(1)
