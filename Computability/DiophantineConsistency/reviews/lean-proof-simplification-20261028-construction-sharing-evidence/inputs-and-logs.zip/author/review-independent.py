from pathlib import Path
import hashlib,json,subprocess
P=Path('/tmp/construction-share');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
for n in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
 b=P/'baseline/DiophantineConsistency'/f'{n}.lean';f=P/'final/DiophantineConsistency'/f'{n}.lean';repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');print(n,'baseline',h(b),'final',h(f),'baseline_equals_HEAD',b.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(repo)]),'baseline_equals_worktree',b.read_bytes()==repo.read_bytes())
a=(P/'final/DiophantineConsistency/ArithmeticConstructionAssembly.lean').read_text();b=(P/'baseline/DiophantineConsistency/ArithmeticConstructionBound.lean').read_text();same=b.split('/-! ## The explicit bound -/',1)[1].split('/-! ## The construction with sizes -/',1)[0].rstrip()==a.split('/-! ## The explicit bound -/',1)[1].split('theorem construction_below_hL',1)[0].rstrip();assert same;print('moved definition and helper block byte-identical')
x=b.split('theorem construction_below ',1)[1].split(' := by\n',1)[1].split('\n/-! ## The main statement -/',1)[0].removeprefix('  have hL := ArithmeticLocalNormalization.localNormalization\n').rstrip();y=a.split('theorem construction_below_hL ',1)[1].split(' := by\n',1)[1].split('\nend DiophantineConsistency.ArithmeticConstructionBound',1)[0].rstrip();assert x==y;print('shared proof body byte-identical after localNormalization binding removed')
for f in ['names','axioms']:
 assert (P/('baseline-'+f+'.log')).read_bytes()==(P/('final-'+f+'.log')).read_bytes();print('Assembly old '+f+' logs identical')
for n in ['paired assembly attempts','bound attempts']:
 rec=json.loads((P/('phase-records.json' if n.startswith('paired') else 'bound-attempt-records.json')).read_text());print(n,[(q.get('phase'),q.get('status')) for q in rec])
