from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/construction-share');base=Path('/tmp/outer-seed-bound-sharing/assembly-common');root=Path('Computability/DiophantineConsistency/Lean');out=R/'common';out.mkdir(exist_ok=True);h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for ns in ['Foundation','FirstOrder','BusyBeaver','PAHF']:
 p=out/ns
 if not p.exists():p.symlink_to((base/ns).resolve(),target_is_directory=True)
ns=out/'DiophantineConsistency';ns.mkdir(exist_ok=True)
for p in (base/'DiophantineConsistency').iterdir():
 if p.suffix!='.olean':continue
 q=ns/p.name
 if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
old=Path('/tmp/outer-seed-bound-sharing/final-lib/DiophantineConsistency/ArithmeticOuterSeed.olean');q=ns/old.name;q.unlink(missing_ok=True);q.symlink_to(old.resolve())
for n in ['ArithmeticPellFirstNorm','ArithmeticPellFirstIndex','ArithmeticPellPowerRecovery']:
 p=Path('/tmp/pell-share/final/DiophantineConsistency')/(n+'.olean');q=ns/p.name;q.unlink(missing_ok=True);q.symlink_to(p.resolve())
for n in ['ArithmeticCarrierSoundness2011','ArithmeticCarrierRadix2011','ArithmeticRankForcing2011','ArithmeticHalfBinomialSandwich','ArithmeticHalfBinomial','ArithmeticOuterSeed','ArithmeticConstructionBoundPell','ArithmeticConstructionAssembly']:
 (ns/(n+'.olean')).unlink(missing_ok=True)
plan=json.load(open('/tmp/outer-seed-bound-sharing/assembly-plan.json'));pins=[x for x in json.load(open('/tmp/outer-seed-bound-sharing/assembly-final-pins.json')) if x['phase']=='final'];bad=[];borrowed=[]
for x in pins:
 n=x['module'];p=out/(n.replace('.','/')+'.olean');src=root/(n.replace('.','/')+'.lean')
 if not p.exists():continue
 if n in ['DiophantineConsistency.ArithmeticPellFirstNorm','DiophantineConsistency.ArithmeticPellFirstIndex','DiophantineConsistency.ArithmeticPellPowerRecovery']:
  z=next(z for z in json.load(open('/tmp/pell-share/paired-records.json')) if z['phase']=='final' and 'DiophantineConsistency.'+z['module']==n)
  expectedsource=z['source_sha256'];expectedobj=z['object_sha256']
 else:expectedsource=x['source_sha256'];expectedobj=x['object_sha256']
 if h(src)!=expectedsource or h(p)!=expectedobj:bad.append(n)
 borrowed.append({'module':n,'source':str(src.resolve()),'source_sha256':h(src),'object':str(p.resolve()),'object_sha256':h(p),'expected_source':expectedsource,'expected_object':expectedobj})
(R/'borrowed.json').write_text(json.dumps({'pins':borrowed,'issues':bad},indent=2)+'\n');assert not bad,bad
order=['ArithmeticCarrierSoundness2011','ArithmeticCarrierRadix2011','ArithmeticRankForcing2011','ArithmeticHalfBinomialSandwich','ArithmeticHalfBinomial','ArithmeticOuterSeed','ArithmeticConstructionBoundPell'];records=[];env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip()
for n in order:
 src=root/'DiophantineConsistency'/(n+'.lean');obj=ns/(n+'.olean');log=R/(n+'.log');tm=R/(n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];pre=h(src);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'module':n,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src.resolve()),'source_sha256':pre,'source_after':h(src),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'log':str(log),'log_sha256':h(log),'time':tm.read_text()};records.append(rec);(R/'refresh-records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,p.returncode,round(rec['elapsed'],1),flush=True)
 if p.returncode or pre!=rec['source_after']:raise SystemExit(1)
