from pathlib import Path
import json,re,hashlib,tomllib
R=Path('/tmp/construction-share');W=Path.cwd();roots=[]
for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']:
 p=(W/x.get('srcDir','.')).resolve()
 if p not in roots:roots.append(p)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();nodes={};external=[];order=[]
def visit(n):
 if n in nodes or n in external:return
 hits=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).exists()))
 if not hits:external.append(n);return
 if len(hits)!=1:raise RuntimeError('ambiguous '+n)
 p=hits[0];im=[]
 for line in p.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:im.extend(m.group(1).split())
 o=R/'common'/(n.replace('.','/')+'.olean');nodes[n]={'source':str(p),'source_sha256':h(p),'imports':im,'common_object':str(o.resolve()) if o.exists() else None,'common_hash':h(o) if o.exists() else None}
 for d in im:visit(d)
 order.append(n)
visit('DiophantineConsistency.ArithmeticConstructionBound');missing=[n for n in order if not nodes[n]['common_object']];(R/'bound-graph.json').write_text(json.dumps({'nodes':nodes,'order':order,'external':external,'missing':missing},indent=2)+'\n');print('local',len(nodes),'external',len(external),'common missing',len(missing));print('\n'.join(missing))
