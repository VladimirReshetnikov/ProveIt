from pathlib import Path
import json,hashlib
R=Path('/tmp/construction-share');g=json.load(open(R/'bound-graph.json'));plan=json.load(open(R/'bound-refresh-plan.json'));ov=R/'fol-coherent';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pins={}
def put(n,x,receipt):pins[n]={'source_sha256':x['source_sha256'],'object_sha256':x['object_sha256'],'receipt':receipt}
p='/tmp/outer-seed-bound-sharing/assembly-final-pins.json'
for x in json.load(open(p)):
 if x['phase']=='final':put(x['module'],x,p)
p='/tmp/outer-seed-bound-sharing/assembly-busy-pins.json'
for n,x in json.load(open(p))['nodes'].items():put(n,x,p)
p='/tmp/bisim-share/prior-141-pins.json'
for x in json.load(open(p)):
 if x['module'] not in pins:put(x['module'],x,p)
p='/tmp/construction-share/refresh-records.json'
for x in json.load(open(p)):put('DiophantineConsistency.'+x['module'],x,p)
p='/tmp/pell-share/paired-records.json'
for x in json.load(open(p)):
 if x['phase']=='final':put('DiophantineConsistency.'+x['module'],x,p)
p='/tmp/construction-share/selected-fol-roots.json'
for x in json.load(open(p)):put(x['module'],x,p)
output=[];fail=[]
for n in plan['borrowed']:
 v=g['nodes'][n];q=pins[n];o=ov/(n.replace('.','/')+'.olean');src=Path(v['source']);a={'module':n,'source':str(src),'source_sha256':h(src),'object':str(o.resolve()),'object_sha256':h(o),'receipt':q['receipt'],'receipt_sha256':h(q['receipt']),'expected_source_sha256':q['source_sha256'],'expected_object_sha256':q['object_sha256']};output.append(a)
 if a['source_sha256']!=q['source_sha256'] or a['object_sha256']!=q['object_sha256']:fail.append(n)
(R/'bound-borrowed-pins.json').write_text(json.dumps({'pins':output,'issues':fail},indent=2)+'\n');print('borrowed',len(output),'issues',fail);assert not fail
