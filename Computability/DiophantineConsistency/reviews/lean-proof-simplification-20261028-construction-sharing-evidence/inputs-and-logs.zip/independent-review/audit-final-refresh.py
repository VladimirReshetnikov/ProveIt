from pathlib import Path
import json,hashlib,re,tomllib
W=Path.cwd();R=Path('/tmp/construction-share');O=Path('/tmp/bound-graph-independent');g=json.load(open(R/'bound-graph.json'));plan=json.load(open(R/'bound-refresh-plan.json'));ov=R/'fol-coherent';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();issues=[];notes=[];roots=[]
for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']:
 p=(W/x.get('srcDir','.')).resolve()
 if p not in roots:roots.append(p)
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(path):
 out=[]
 for line in strip(Path(path).read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out
def graph(phase):
 nodes={};ext=set();order=[]
 def visit(n):
  if n in nodes or n in ext:return
  if n in ['DiophantineConsistency.ArithmeticConstructionAssembly','DiophantineConsistency.ArithmeticConstructionBound']:
   p=R/phase/'DiophantineConsistency'/(n.split('.')[-1]+'.lean')
  else:
   candidates=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
   if not candidates:ext.add(n);return
   assert len(candidates)==1,(n,candidates);p=candidates[0]
  im=imports(p);nodes[n]=im
  for a in im:visit(a)
  order.append(n)
 visit('DiophantineConsistency.ArithmeticConstructionBound');return nodes,ext,order
for ph in ['baseline','final']:
 nodes,ext,order=graph(ph)
 if set(nodes)!=set(g['nodes']):issues.append(ph+' graph node diff '+str(set(nodes)^set(g['nodes'])))
 if ext!=set(g['external']):issues.append(ph+' external diff '+str(ext^set(g['external'])))
 for n,im in nodes.items():
  orig=g['nodes'][n]['imports'];add=['DiophantineConsistency.ArithmeticConstructionBoundPell'] if ph=='final' and n.endswith('.ArithmeticConstructionAssembly') else []
  if sorted(im)!=sorted(orig+add):issues.append(ph+' edge mismatch '+n)
 notes.append({'phase':ph,'nodes':len(nodes),'external':len(ext)})
fol={'FirstOrder.Fol'}
for n in g['order']:
 if any(i in fol for i in g['nodes'][n]['imports']):fol.add(n)
if fol!=set(plan['fol_descendants']):issues.append('Fol descendant closure mismatch')
peer={x['module'] for x in json.load(open(R/'fol-peer-reuse.json'))['accepted']};targets={'DiophantineConsistency.ArithmeticConstructionAssembly','DiophantineConsistency.ArithmeticConstructionBound'};expected=(fol|set(g['missing']))-peer-{'FirstOrder.Fol'}-targets
if expected!=set(plan['order']) or [n for n in g['order'] if n in expected]!=plan['order']:issues.append('refresh plan/order mismatch')
records=json.load(open(R/'bound-refresh-records.json'))
if [r['module'] for r in records]!=plan['order'][:len(records)]:issues.append('completed build order differs')
for x in records:
 for key in ['source','object','log','time']:
  path = R/'superseded-RankForcing.olean' if x['module']=='DiophantineConsistency.ArithmeticRankForcing2011' and key=='object' else Path(x[key])
  if not path.is_file() or sha(path)!=x[key+'_sha256']:issues.append('record hash '+x['module']+' '+key)
 if x['status'] or x['source_sha256']!=x['source_after'] or Path(x['time']).read_text().strip()!=x['timing']:issues.append('record status/timing '+x['module'])
 cmd=x['command'];j=cmd.index('lean');out=[cmd[k+1] for k in range(j+1,len(cmd)-1) if cmd[k]=='-o']
 if out!=[x['object']] or x['lean_path'].split(':')[0]!=str(ov):issues.append('record command/path '+x['module'])
 deps={d['module']:d for d in x['direct_project_inputs']};expecteddeps={n for n in g['nodes'][x['module']]['imports'] if n in g['nodes']}
 if set(deps)!=expecteddeps:issues.append('record dependency coverage '+x['module'])
 for n,d in deps.items():
  p=ov/(n.replace('.','/')+'.olean')
  superseded = x['module']=='DiophantineConsistency.ArithmeticRankForcing2011' and n=='DiophantineConsistency.ArithmeticMaskConstants'
  if (not superseded and (not p.is_file() or sha(p)!=d['sha256'])) or sha(d['object'])!=d['sha256']:issues.append('record selected dependency '+x['module']+' -> '+n)
peerreceipt={x['module']:x for x in json.load(open('/tmp/dag-independent-audit/fol-refresh-records.json'))}
for x in json.load(open(R/'fol-peer-reuse.json'))['accepted']:
 n=x['module'];q=peerreceipt[n];p=ov/(n.replace('.','/')+'.olean')
 if q['status'] or sha(x['source'])!=x['source_sha256'] or sha(x['object'])!=x['object_sha256'] or not p.is_file() or sha(p)!=x['object_sha256'] or x['object_sha256']!=q['object_sha256'] or x['inputs']!=q['direct_project_inputs']:issues.append('peer receipt '+n)
 for dep,d in x['inputs'].items():
  p=ov/(dep.replace('.','/')+'.olean')
  if not p.is_file() or sha(p)!=d['sha256'] or sha(d['path'])!=d['sha256']:issues.append('peer input '+n+' -> '+dep)
for x in json.load(open(R/'bound-borrowed-pins.json'))['pins']:
 n=x['module'];p=ov/(n.replace('.','/')+'.olean')
 if n=='DiophantineConsistency.ArithmeticMaskConstants':continue
 if sha(x['source'])!=x['expected_source_sha256'] or not p.is_file() or sha(p)!=x['expected_object_sha256'] or sha(x['receipt'])!=x['receipt_sha256']:issues.append('borrowed pin '+n)
changed=[n for n,v in g['nodes'].items() if sha(v['source'])!=v['source_sha256']]
if changed!=['DiophantineConsistency.ArithmeticMaskConstants']:issues.append('source changes '+str(changed))
mask=changed[0];imp={mask}
for n in g['order']:
 if any(i in imp for i in g['nodes'][n]['imports']):imp.add(n)
if imp!={mask,'DiophantineConsistency.ArithmeticRankForcing2011',*targets}:issues.append('mask impact '+str(imp))
if imports('/tmp/mask-digits-bound/final/DiophantineConsistency/ArithmeticMaskConstants.lean')!=g['nodes'][mask]['imports']:issues.append('mask imports changed')
rank=next((x for x in records if x['module']=='DiophantineConsistency.ArithmeticRankForcing2011'),None)
if rank is None:notes.append('RankForcing not yet completed at audit snapshot')
else:
 old=next(x for x in rank['direct_project_inputs'] if x['module']==mask)
 if old['sha256']!='eeaa5cb13b8fb0fbb5c10620e095f70867ec41c65e10b4d96ee78ac14b9697ae':issues.append('rank mask differs from expected old')
 notes.append('Original RankForcing used old mask; corrected record checked separately')
m=json.load(open('/tmp/mask-digits-bound/paired-records.json'))[-1];src=Path(g['nodes'][mask]['source']);obj=Path('/tmp/mask-digits-bound/final/DiophantineConsistency/ArithmeticMaskConstants.olean')
if m['status'] or sha(src)!=m['source_sha256'] or sha(obj)!=m['object_sha256']:issues.append('new mask target receipt')
for dep in g['nodes'][mask]['imports']:
 a=ov/(dep.replace('.','/')+'.olean');b=Path('/tmp/mask-digits-bound/final')/(dep.replace('.','/')+'.olean')
 if not a.is_file() or not b.is_file() or sha(a)!=sha(b):issues.append('new mask selected dependency '+dep)

u=json.load(open(R/'mask-update.json'));r=json.load(open(R/'corrected-RankForcing-record.json'));sup=json.load(open(R/'superseded-RankForcing-record.json'))
if sup!=rank:issues.append('superseded rank receipt mismatch')
for key in ['source','object','receipt']:
 if sha(u[key])!=u[key+'_sha256']:issues.append('mask update '+key)
selected=ov/(mask.replace('.','/')+'.olean')
if not selected.is_file() or sha(selected)!=u['object_sha256']:issues.append('mask selected after update')
for d in u['direct_inputs']:
 p=ov/(d['module'].replace('.','/')+'.olean')
 if sha(p)!=d['sha256'] or sha(d['selected'])!=d['sha256'] or sha(d['mask_phase'])!=d['sha256']:issues.append('mask update direct '+d['module'])
for key in ['source','object','log','time']:
 if not Path(r[key]).is_file() or sha(r[key])!=r[key+'_sha256']:issues.append('corrected rank '+key)
if r['status'] or r['source_sha256']!=r['source_after'] or Path(r['time']).read_text().strip()!=r['timing']:issues.append('corrected rank status/timing')
if r['command'][r['command'].index('-o',r['command'].index('lean'))+1]!=r['object'] or r['lean_path'].split(':')[0]!=str(ov):issues.append('corrected rank command/path')
deps={x['module']:x for x in r['direct_project_inputs']};need={n for n in g['nodes'][r['module']]['imports'] if n in g['nodes']}
if set(deps)!=need:issues.append('corrected rank dependency coverage')
for n,d in deps.items():
 p=ov/(n.replace('.','/')+'.olean')
 if not p.is_file() or sha(p)!=d['sha256'] or sha(d['object'])!=d['sha256']:issues.append('corrected rank selected '+n)
if deps[mask]['sha256']!=u['object_sha256']:issues.append('corrected rank mask hash')
if sha(R/'superseded-RankForcing.log')!=rank['log_sha256'] or sha(R/'superseded-RankForcing.time')!=rank['time_sha256']:issues.append('superseded rank preserved logs')
warnings={x['module']:Path(x['log']).read_text().count('warning:') for x in records};warnings={n:v for n,v in warnings.items() if v};notes.append({'warnings_by_module':warnings,'count':sum(warnings.values()),'corrected_rank_warnings':Path(r['log']).read_text().count('warning:')})

summary={'graphs':notes[:2],'fol_descendants':len(fol),'planned':len(expected),'completed_checked':len(records),'peer_checked':len(peer),'borrowed_checked':len(plan['borrowed']),'notes':notes[2:],'issues':issues};(O/'audit-final-refresh.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));
if issues:raise SystemExit(1)
