from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/construction-share');O=Path('/tmp/bound-graph-independent');I=json.load(open(O/'audit-phases.json'));records=json.load(open(R/'pinned-replay-records.json'));h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();issues=[];manifest=O/'audit-phases.json';targets={'DiophantineConsistency.ArithmeticConstructionAssembly','DiophantineConsistency.ArithmeticConstructionBound'};source_module={'Assembly':'ArithmeticConstructionAssembly','Bound':'ArithmeticConstructionBound','CurrentConstruction':'ArithmeticCurrentConstruction2011'}
expected=[(ph,tag,0) for ph in ['baseline','final'] for tag in ['Assembly','Bound','CurrentConstruction','axioms']]
if [(x['phase'],x['tag'],x['status']) for x in records]!=expected:issues.append('record coverage/order')
for x in records:
 for k in ['source','log','time']:
  if not Path(x[k]).is_file() or h(x[k])!=x[k+'_sha256']:issues.append('record '+x['phase']+' '+x['tag']+' '+k)
 if x.get('object') and (not Path(x['object']).is_file() or h(x['object'])!=x['object_sha256']):issues.append('record object '+x['phase']+' '+x['tag'])
 if x['source_sha256']!=x['source_after'] or Path(x['time']).read_text().strip()!=x['timing']:issues.append('record source/timing '+x['phase']+' '+x['tag'])
 ov=R/('pinned-'+x['phase']);cmd=x['command'];j=cmd.index('lean');outs=[cmd[i+1] for i in range(j+1,len(cmd)-1) if cmd[i]=='-o'];expectedout=[x['object']] if x.get('object') else []
 if outs!=expectedout or x['lean_path'].split(':')[0]!=str(ov) or x['checked_local_inputs']!=182 or x['checked_direct_external_inputs']!=73 or h(x['input_manifest'])!=x['input_manifest_sha256']:issues.append('record command/manifest '+x['phase']+' '+x['tag'])
 for d in x['target_inputs']:
  if not Path(d['object']).is_file() or h(d['object'])!=d['sha256']:issues.append('record target input '+x['phase']+' '+x['tag']+' '+d['module'])
 if Path(x['log']).read_text().count('warning:') and x['tag']!='axioms':issues.append('build warning '+x['phase']+' '+x['tag'])
for tag in ['Assembly','Bound','CurrentConstruction','axioms']:
 a=(R/('baseline-pinned-'+tag+'.log')).read_bytes();b=(R/('final-pinned-'+tag+'.log')).read_bytes()
 if a!=b:issues.append('pinned phase log differ '+tag)
 if tag=='axioms' and a!=(R/'baseline-coherent-axioms.log').read_bytes():issues.append('pinned axiom output differs coherent')
commands=[]
def check(ph,env):
 ov=R/('pinned-'+ph);local=[x for x in I['local_pins'] if x['phase']==ph and x['module'] not in targets];external=[x for x in I['external_pins'] if x['phase']==ph]
 assert len(local)==182 and len(external)==73
 for d in local:
  p=ov/(d['module'].replace('.','/')+'.olean')
  if not p.is_file() or h(p)!=d['object_sha256'] or h(d['source'])!=d['source_sha256']:raise RuntimeError('local pin '+d['module'])
 for d in external:
  p=next(((Path(q)/(d['module'].replace('.','/')+'.olean')).resolve() for q in env['LEAN_PATH'].split(':') if q and (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file()),None)
  if p is None or p!=Path(d['object']).resolve() or h(p)!=d['sha256']:raise RuntimeError('external pin '+d['module'])
 for tag,n in source_module.items():
  x=next(x for x in records if x['phase']==ph and x['tag']==tag);p=ov/'DiophantineConsistency'/(n+'.olean')
  if not p.is_file() or h(p)!=x['object_sha256']:raise RuntimeError('target pin '+tag)
 if h(manifest)!=next(x['input_manifest_sha256'] for x in records if x['phase']==ph):raise RuntimeError('manifest changed')
def run(ph,tag,src):
 rec=next(x for x in records if x['phase']==ph and x['tag']=='axioms');env=os.environ.copy();env['LEAN_PATH']=rec['lean_path'];check(ph,env);log=O/(ph+'-pinned-client-'+tag+'.log');tm=O/(ph+'-pinned-client-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];pre=h(src);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 check(ph,env);x={'phase':ph,'tag':tag,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src),'source_sha256':pre,'source_after':h(src),'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'checked_local_inputs':182,'checked_external_inputs':73,'checked_target_objects':3,'manifest_sha256':h(manifest)};commands.append(x);(O/'pinned-client-probe-records.json').write_text(json.dumps(commands,indent=2)+'\n');print(ph,tag,p.returncode,flush=True)
 if p.returncode or pre!=x['source_after']:raise RuntimeError(str(x))
for ph in ['baseline','final']:run(ph,'names',O/'client-names.lean')
parse=lambda p:sorted(set(s.removeprefix('DECL ') for s in p.read_text().splitlines() if s.startswith('DECL ')));a=parse(O/'baseline-pinned-client-names.log');b=parse(O/'final-pinned-client-names.log')
if a!=b or len(a)!=2:issues.append('pinned client name census')
probe=O/'pinned-client-axioms.lean';probe.write_text('import DiophantineConsistency.ArithmeticCurrentConstruction2011\nset_option pp.all true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in a))
for ph in ['baseline','final']:run(ph,'axioms',probe)
a=(O/'baseline-pinned-client-axioms.log').read_bytes();b=(O/'final-pinned-client-axioms.log').read_bytes()
if a!=b:issues.append('pinned client types/axioms differ')
summary={'pinned_replay_records':len(records),'pinned_axiom_warnings_each':(R/'baseline-pinned-axioms.log').read_text().count('warning:'),'client_names':len(parse(O/'baseline-pinned-client-names.log')),'client_axiom_warnings_each':a.decode().count('warning:'),'independent_pinned_client_probes':len(commands),'issues':issues};(O/'audit-pinned.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if issues:raise SystemExit(1)
