from pathlib import Path
import json,hashlib,re
R=Path('/tmp/construction-share');O=Path('/tmp/bound-graph-independent');g=json.load(open(R/'bound-graph-after-mask.json'));records=json.load(open(R/'coherent-phase-records.json'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();issues=[];pins=[];externalpins=[]
if [(x['phase'],x['module'],x['status']) for x in records]!=[(p,n,0) for p in ['baseline','final'] for n in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']]:issues.append('phase order/status')
for x in records:
 for key in ['source','object','log','time']:
  if not Path(x[key]).is_file() or sha(x[key])!=x[key+'_sha256']:issues.append('phase record '+x['phase']+' '+x['module']+' '+key)
 if x['source_sha256']!=x['source_after'] or Path(x['time']).read_text().strip()!=x['timing']:issues.append('phase source/timing '+x['phase']+' '+x['module'])
 ov=R/('coherent-'+x['phase']);cmd=x['command'];j=cmd.index('lean');out=[cmd[i+1] for i in range(j+1,len(cmd)-1) if cmd[i]=='-o']
 if out!=[x['object']] or x['lean_path'].split(':')[0]!=str(ov):issues.append('phase command/path '+x['phase']+' '+x['module'])
 if Path(x['log']).read_text().count('warning:'):issues.append('phase warning '+x['phase']+' '+x['module'])
for ph in ['baseline','final']:
 ov=R/('coherent-'+ph);target={x['module']:x for x in records if x['phase']==ph}
 for n,v in g['nodes'].items():
  short=n.split('.')[-1];istarget=n in ['DiophantineConsistency.ArithmeticConstructionAssembly','DiophantineConsistency.ArithmeticConstructionBound'];src=R/ph/'DiophantineConsistency'/(short+'.lean') if istarget else Path(v['source']);obj=ov/(n.replace('.','/')+'.olean')
  if not obj.is_file():issues.append('missing phase object '+ph+' '+n);continue
  if istarget:
   expected=target[short]
   if sha(src)!=expected['source_sha256'] or sha(obj)!=expected['object_sha256']:issues.append('target phase pin '+ph+' '+n)
  else:
   common=R/'fol-coherent'/(n.replace('.','/')+'.olean')
   if sha(src)!=v['source_sha256'] or not common.is_file() or sha(obj)!=sha(common):issues.append('phase source/object pin '+ph+' '+n)
  pins.append({'phase':ph,'module':n,'source':str(src.resolve()),'source_sha256':sha(src),'object':str(obj.resolve()),'object_sha256':sha(obj),'target':istarget})
 env=next(x['lean_path'] for x in records if x['phase']==ph)
 for n in g['external']:
  candidates=[Path(p)/(n.replace('.','/')+'.olean') for p in env.split(':') if p];chosen=next((p.resolve() for p in candidates if p.is_file()),None)
  if chosen is None:issues.append('external object not resolved '+ph+' '+n)
  else:externalpins.append({'phase':ph,'module':n,'object':str(chosen),'sha256':sha(chosen)})
a={x['module']:(x['object'],x['sha256']) for x in externalpins if x['phase']=='baseline'};b={x['module']:(x['object'],x['sha256']) for x in externalpins if x['phase']=='final'}
if a!=b:issues.append('external phase object pins differ')
for ph in ['baseline','final']:
 for n in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
  x=next(x for x in records if x['phase']==ph and x['module']==n);src=Path(x['source']);expected=R/ph/'DiophantineConsistency'/(n+'.lean')
  if src.resolve()!=expected.resolve() or sha(src)!=sha(expected):issues.append('snapshot mismatch '+ph+' '+n)
for n in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
 src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');old=R/'baseline/DiophantineConsistency'/(n+'.lean')
 if sha(src)!=sha(old):issues.append('worktree changed from baseline '+n)
x=json.load(open(R/'coherent-names-comparison.json'));old=x['baseline'];new=x['final'];added=x['added'];removed=x['removed'];wanted=['DiophantineConsistency.ArithmeticConstructionBound.construction_below_hL']
if len(old)!=56 or removed or added!=wanted or sorted(set(new)-set(old))!=wanted:issues.append('name census')
s=(R/'coherent-axioms.lean').read_text();checks=re.findall(r'^#check (\S+)$',s,re.M);axioms=re.findall(r'^#print axioms (\S+)$',s,re.M);defs=re.findall(r'^#print equations (\S+)$',s,re.M)
if checks!=old or axioms!=old:issues.append('probe declaration coverage')
if defs!=['DiophantineConsistency.ArithmeticConstructionBound.'+v for v in ['Nb','Q','Rq','Wb','zeroBound']]:issues.append('equation forcing')
A=(R/'baseline-coherent-axioms.log').read_bytes();B=(R/'final-coherent-axioms.log').read_bytes()
if A!=B:issues.append('axiom/type/equations reports differ')
newlog=(R/'final-coherent-added-axioms.log').read_text()
if not all(v in newlog for v in ['propext','Classical.choice','Quot.sound']):issues.append('new helper axioms')
for x in json.load(open(R/'coherent-axiom-records.json')):
 if x['status'] or sha(x['source'])!=x['source_sha256'] or sha(x['log'])!=x['log_sha256'] or sha(x['time'])!=x['time_sha256'] or Path(x['time']).read_text().strip()!=x['timing']:issues.append('axiom record '+x['phase']+' '+x['tag'])
summary={'phase_records':len(records),'phase_local_pins':len(pins),'phase_external_pins':len(externalpins),'old_declarations':len(old),'new_declarations':added,'equations_forced':len(defs),'axiom_probe_warnings_each':A.decode().count('warning:'),'issues':issues,'limitations':'Phase local/external pin checks are retrospective; the phase build receipts did not snapshot all dependency hashes immediately before and after each build. External transitive packages and unaffected inputs are precompiled.'};(O/'audit-phases.json').write_text(json.dumps({'summary':summary,'local_pins':pins,'external_pins':externalpins},indent=2)+'\n');print(json.dumps(summary,indent=2))
if issues:raise SystemExit(1)
