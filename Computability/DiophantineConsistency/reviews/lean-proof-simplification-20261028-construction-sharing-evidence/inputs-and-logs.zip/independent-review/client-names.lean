import DiophantineConsistency.ArithmeticCurrentConstruction2011
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticCurrentConstruction2011).isPrefixOf n then
      logInfo m!"DECL {n}"
