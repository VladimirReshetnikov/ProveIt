from pathlib import Path
import hashlib,os,subprocess,time,json,re
R=Path('/tmp/construction-share');O=Path('/tmp/bound-graph-independent');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=json.load(open(R/'coherent-client-records.json'));issues=[]
if [(x['phase'],x['status']) for x in records]!=[('baseline',0),('final',0)]:issues.append('client phases/status')
for x in records:
 for k in ['source','object','log','time']:
  if not Path(x[k]).is_file() or h(x[k])!=x[k+'_sha256']:issues.append('client '+x['phase']+' '+k)
 if x['source_sha256']!=x['source_after'] or Path(x['time']).read_text().strip()!=x['timing']:issues.append('client source/timing '+x['phase'])
 ov=R/('coherent-'+x['phase']);cmd=x['command'];j=cmd.index('lean');out=[cmd[i+1] for i in range(j+1,len(cmd)-1) if cmd[i]=='-o']
 if out!=[x['object']] or x['lean_path'].split(':')[0]!=str(ov):issues.append('client command/overlay '+x['phase'])
 imports=re.findall(r'^import DiophantineConsistency\.(\S+)',Path(x['source']).read_text(),re.M)
 if set(imports)!={d['module'] for d in x['direct_inputs']}:issues.append('client direct import coverage '+x['phase'])
 for d in x['direct_inputs']:
  p=ov/'DiophantineConsistency'/(d['module']+'.olean')
  if not p.is_file() or h(p)!=d['sha256'] or h(d['object'])!=d['sha256']:issues.append('client input '+x['phase']+' '+d['module'])
if (R/'baseline-coherent-client.log').read_bytes()!=(R/'final-coherent-client.log').read_bytes():issues.append('client build logs differ')
commands=[]
def run(ph,tag,src):
 x=next(x for x in records if x['phase']==ph);env=os.environ.copy();env['LEAN_PATH']=x['lean_path'];log=O/(ph+'-'+tag+'.log');tm=O/(ph+'-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];pre=h(src);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 y={'phase':ph,'tag':tag,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(src),'source_sha256':pre,'source_after':h(src),'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip()};commands.append(y)
 if p.returncode or pre!=y['source_after']:raise RuntimeError(str(y))
for ph in ['baseline','final']:run(ph,'client-names',O/'client-names.lean')
parse=lambda p:sorted(set(s.removeprefix('DECL ') for s in p.read_text().splitlines() if s.startswith('DECL ')));a=parse(O/'baseline-client-names.log');b=parse(O/'final-client-names.log')
if a!=b:issues.append('client names differ')
probe=O/'client-axioms.lean';probe.write_text('import DiophantineConsistency.ArithmeticCurrentConstruction2011\nset_option pp.all true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in a))
for ph in ['baseline','final']:run(ph,'client-axioms',probe)
A=(O/'baseline-client-axioms.log').read_bytes();B=(O/'final-client-axioms.log').read_bytes()
if A!=B:issues.append('client type/axiom reports differ')
summary={'client_builds_checked':len(records),'names':a,'warnings_each':A.decode().count('warning:'),'issues':issues,'commands':commands};(O/'audit-client.json').write_text(json.dumps(summary,indent=2)+'\n');print('names',len(a),'warnings_each',summary['warnings_each'],'issues',issues)
if issues:raise SystemExit(1)
