from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-occupation-selector-sharing-evidence';out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/occupation-selector-sharing');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','final']:
 for p in sorted((R/phase).rglob('*.lean')):add('snapshots/'+str(p.relative_to(R)),p)
for name in ['occupation-selector-independent-review.txt','occupation-selector-independent-audit.py','occupation-selector-independent-audit.log','occupation-cache-boundary-sample.py','occupation-cache-boundary-sample.log']:
 add('independent/'+name,I/name)
refs={'prior/shared-modular-cancel-records.json':'shared-modular-cancel/records.json','prior/wang-initial-sharing-records.json':'wang-initial-sharing/records.json','prior/window-rem-bound-final-records.json':'window-rem-bound/final-records.json','prior/window-rem-bound-README.txt':'window-rem-bound/README.txt','prior/window-rem-bound-audit.py':'window-rem-bound/audit.py','prior/window-rem-bound-audit.log':'window-rem-bound/audit.log','prior/old-assembly-builds2.json':'outer-seed-bound-sharing/assembly-builds2.json','prior/current-binary-carry-final-records.json':'binary-carry-simplify/final-records.json','prior/pell-balance-final-targets-records.json':'pell-balance-sharing/final-targets-records.json','prior/historical-rank-mask-cached-boundaries.json':'rank-mask-residue/cached-boundaries.json'}
for n,p in refs.items():add(n,I/p)
add('bundle/build-occupation-selector-bundle.py',Path(__file__))
commit='f46e22674aebbdb3210bfc9777d5e83ee031c640';parent='d29422d0ff6b02382f71ae5b5bd7eb33daee3e1e';base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for phase,ref in [('baseline',parent),('final',commit)]:
 data=subprocess.check_output(['git','show',ref+':'+base+'ArithmeticOccupation.lean']);assert data==files['snapshots/'+phase+'/DiophantineConsistency/ArithmeticOccupation.lean'];files['commit/'+phase+'.lean']=data
 data=subprocess.check_output(['git','show',ref+':'+base+'ArithmeticCellWindow.lean']);assert data==files['snapshots/'+phase+'/DiophantineConsistency/ArithmeticCellWindow.lean']
h=lambda b:hashlib.sha256(b).hexdigest()
refs2=[('ArithmeticCellDecoding','prior/shared-modular-cancel-records.json'),('ArithmeticWangPlane','prior/wang-initial-sharing-records.json'),('ArithmeticWangSoundness','prior/wang-initial-sharing-records.json'),('ArithmeticWindowInterface','prior/window-rem-bound-final-records.json')]
for mod,fn in refs2:
 rec=next(x for x in json.loads(files[fn]) if x['module']==mod and x['phase']=='final');data=subprocess.check_output(['git','show',commit+':'+base+mod+'.lean']);assert rec['status']==0 and h(data)==rec.get('before',rec.get('source_before'));files['providers/current/'+mod+'.lean']=data
whole=json.loads(files['prototype/provider-records.json'])[0];data=subprocess.check_output(['git','show',commit+':'+base+'ArithmeticWholeField.lean']);assert whole['status']==0 and h(data)==whole['before'];files['providers/current/ArithmeticWholeField.lean']=data
old=next(x for x in json.loads(files['prior/old-assembly-builds2.json']) if x['module']=='DiophantineConsistency.ArithmeticBinaryCarry');new=next(x for x in json.loads(files['prior/current-binary-carry-final-records.json']) if x['module']=='ArithmeticBinaryCarry');olddata=subprocess.check_output(['git','show','a3af2f89c7^:'+base+'ArithmeticBinaryCarry.lean']);newdata=subprocess.check_output(['git','show',commit+':'+base+'ArithmeticBinaryCarry.lean']);assert h(olddata)==old['source_sha256'] and h(newdata)==new['before'];files['cache/binary-carry-old.lean']=olddata;files['cache/binary-carry-current.lean']=newdata
review=files['independent/occupation-selector-independent-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Share occupation selector-to-held-tile argument',
 'validation':'Paired target and ArithmeticCellWindow client builds pass with byte-identical client objects. A fresh WholeField provider and four prior direct project providers have source/object receipts. All 70 existing target declaration/type/axiom reports match; one private helper is added. 33,463 default simp and 14,822 instance entries match.',
 'limitations':['Initial WholeField setup failed with a missing Foundation overlay; its log/time survive without a structured receipt. A later baseline client attempt failed because WangStrip was absent; its structured receipt/log/time are preserved. Both issues were corrected before paired builds.','Post-build samples of provider/target search paths resolve a pre-adoption BinaryCarry object, and the historical WindowInterface environment used older HalfBinomial, BinomLegendre and PellRecurrence objects. These are distinct observations; later samples of the Occupation search paths resolve the newer source-matched PellRecurrence. Transitive inputs were not pinned at Occupation build time, so the later sample cannot certify historical bytes or whether every sampled object was loaded.','Other transitive project/Foundation/package objects are cached; no full current-source closure rebuild is established. The client search was limited to tracked exact-import Lean sources, and other clients or environment extensions remain outside the tested scope.','Single paired shared-load timing samples are not a general performance benchmark. Compiled objects are not archived; object hashes and resolution are recorded in receipts, and live external objects are needed for independent byte checks.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
