from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/tmp/occupation-selector-sharing');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());rows={}
refs=[('ArithmeticCellDecoding','/tmp/shared-modular-cancel/records.json','final'),('ArithmeticWangPlane','/tmp/wang-initial-sharing/records.json','final'),('ArithmeticWangSoundness','/tmp/wang-initial-sharing/records.json','final'),('ArithmeticWindowInterface','/tmp/window-rem-bound/final-records.json','final')];providers={}
for n,f,ph in refs:
 x=next(x for x in json.loads(Path(f).read_text()) if x['module']==n and x['phase']==ph);sh=x.get('before',x.get('source_before'));assert x['status']==0 and sh==h(w/(n+'.lean'));p=r/'common/DiophantineConsistency'/(n+'.olean');assert h(p)==x['object_sha256'];providers[n]=x['object_sha256'];print('prior current source/object receipt',n,providers[n])
for ph in ('provider','baseline','final'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n=='ArithmeticOccupation':
   ref='f46e22674a^' if ph=='baseline' else 'f46e22674a'; assert x['before']==hashlib.sha256(subprocess.check_output(['git','show',f'{ref}:{w}/{n}.lean'])).hexdigest()
  else:assert x['before']==h(w/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);name=d['module'].split('.')[-1]
   if name in providers:assert d['before']==providers[name]
   elif name=='ArithmeticWholeField':assert d['before']==rows['provider',name]['object_sha256'] and d['resolved']==rows['provider',name]['object']
   elif name=='ArithmeticOccupation':assert d['before']==rows[ph,name]['object_sha256'] and d['resolved']==rows[ph,name]['object']
   else:raise Exception(name)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for ph in ('baseline','final'):
 for x in get(ph+'-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticOccupation']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
assert rows['baseline','ArithmeticCellWindow']['object_sha256']==rows['final','ArithmeticCellWindow']['object_sha256'];print('client object identical')
def decl(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(r/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decl('baseline'),decl('final');assert len(a)==70 and len(b)==71 and all(b[k]==v for k,v in a.items()) and len(b.keys()-a.keys())==1 and 'holds_of_selector' in next(iter(b.keys()-a.keys()));print('70 existing declaration reports match; one private helper added')
for n,c in [('simp',33463),('instances',14822)]:
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==c and b'holds_of_selector' not in b;print(n,c,'identical')
f=get('attempt1-baseline-records.json');assert len(f)==2 and f[0]['status']==0 and f[1]['status']!=0 and f[1]['log_sha256']==h(r/'attempt1-baseline-ArithmeticCellWindow.log');assert 'ArithmeticWangStrip.olean' in (r/'attempt1-baseline-ArithmeticCellWindow.log').read_text();print('failed omitted-strip client log/receipt retained')
assert 'unknown module prefix' in (r/'wholefield-failed.log').read_text();print('failed initial missing Foundation overlay log/time retained, no structured receipt')
import subprocess
name='DiophantineConsistency.ArithmeticBinaryCarry';rel=name.replace('.','/')+'.olean';old=next(x for x in json.loads(Path('/tmp/outer-seed-bound-sharing/assembly-builds2.json').read_text()) if x['module']==name);new=next(x for x in json.loads(Path('/tmp/binary-carry-simplify/final-records.json').read_text()) if x['module']=='ArithmeticBinaryCarry');current=h(w/'ArithmeticBinaryCarry.lean')
for ph in ('provider','baseline','final'):
 x=rows[ph,'ArithmeticWholeField' if ph=='provider' else 'ArithmeticOccupation'];p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert h(p)==old['object_sha256']=='a338938c8e26e9003abceff91a004a12c82e46fe7660c4d6e7a8625c056073e0';print('old cached BinaryCarry resolution',ph,str(p.resolve()),h(p))
oldgit=hashlib.sha256(subprocess.check_output(['git','show','a3af2f89c7^:Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticBinaryCarry.lean'])).hexdigest();assert old['status']==0 and old['source_sha256']==oldgit=='edecfe3a141fef0d90664ec754b99773dfbfbb7dc584d2e2c6c6f86ae4f1564f' and new['status']==0 and new['before']==new['after']==current=='a7ec88c7107cffb0cc485ec03043517fde1a17ff1b0318f1efb44ab376a8a56b' and h(new['object'])==new['object_sha256'];print('old source/object receipt and current source-matched object receipt verified; no input substituted')
for name in ('ArithmeticPellRecurrence','ArithmeticHalfBinomial','ArithmeticBinomLegendre'):
 rel='DiophantineConsistency/'+name+'.olean'
 for ph in ('provider','baseline','final'):
  x=rows[ph,'ArithmeticWholeField' if ph=='provider' else 'ArithmeticOccupation'];p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());print('post-build closure sample',ph,name,str(p.resolve()),h(p))
 if name=='ArithmeticPellRecurrence':
  q=next(z for z in json.loads(Path('/tmp/pell-balance-sharing/final-targets-records.json').read_text()) if z['module']==name);assert q['status']==0 and q['before']==q['after']==h(w/(name+'.lean')) and q['object_sha256']==h(p)
print('closure paths were not pinned at build time; post-build observations cannot certify historical resolution')
