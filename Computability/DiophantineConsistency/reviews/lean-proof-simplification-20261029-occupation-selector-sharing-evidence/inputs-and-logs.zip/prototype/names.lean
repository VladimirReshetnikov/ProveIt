import Lean.Elab.Command
import DiophantineConsistency.ArithmeticOccupation
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticOccupation).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticOccupation" then
   logInfo m!"DECL {n}"
