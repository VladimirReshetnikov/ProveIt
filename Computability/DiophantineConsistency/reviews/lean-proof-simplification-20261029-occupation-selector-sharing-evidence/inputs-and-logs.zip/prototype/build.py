from pathlib import Path
import os,json,hashlib,subprocess,sys
r=Path('/tmp/occupation-selector-sharing');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');common=r/'common';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();phase=sys.argv[1];env=os.environ.copy()
def setlink(n,p):
 q=common/'DiophantineConsistency'/(n+'.olean');q.unlink(missing_ok=True);q.symlink_to(p)
if phase=='provider':
 setlink('ArithmeticWangSoundness','/tmp/wang-initial-sharing/objects-final/DiophantineConsistency/ArithmeticWangSoundness.olean');setlink('ArithmeticWindowInterface','/tmp/window-rem-bound/objects-final/DiophantineConsistency/ArithmeticWindowInterface.olean'); jobs=[('ArithmeticWholeField',w/'ArithmeticWholeField.lean',common,['ArithmeticCellDecoding'])]
else:
 lib=r/('objects-'+phase);lib.mkdir(exist_ok=True)
 if not (lib/'DiophantineConsistency').exists():subprocess.run(['cp','-as',str(common/'DiophantineConsistency'),str(lib/'DiophantineConsistency')],check=True)
 for n in ('ArithmeticOccupation','ArithmeticCellWindow'):(lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True)
 s=r/phase/'DiophantineConsistency';s.mkdir(parents=True,exist_ok=True)
 if phase=='baseline':(s/'ArithmeticOccupation.lean').write_bytes((w/'ArithmeticOccupation.lean').read_bytes())
 (s/'ArithmeticCellWindow.lean').write_bytes((w/'ArithmeticCellWindow.lean').read_bytes())
 jobs=[('ArithmeticOccupation',s/'ArithmeticOccupation.lean',lib,['ArithmeticWholeField','ArithmeticWangPlane']),('ArithmeticCellWindow',s/'ArithmeticCellWindow.lean',lib,['ArithmeticWindowInterface','ArithmeticOccupation','ArithmeticWangSoundness'])]
lib=common if phase=='provider' else r/('objects-'+phase);env['LEAN_PATH']=str(lib)+':/tmp/support-cast/fresh-final:/tmp/mask-ins-simplify/final:'+env['LEAN_PATH'];rows=[]
for n,source,outroot,imports in jobs:
 inputs=[]
 for name in imports:
  rel='DiophantineConsistency/'+name+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());inputs.append({'module':'DiophantineConsistency.'+name,'path':str(p),'resolved':str(p.resolve()),'before':h(p)})
 obj=outroot/'DiophantineConsistency'/(n+'.olean');tm=r/(phase+'-'+n+'.time');log=r/(phase+'-'+n+'.log');before=h(source);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(w.parent if phase=='provider' else r/phase),str(source),'-o',str(obj)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path'])
 row={'phase':phase,'module':n,'source':str(source),'before':before,'after':h(source),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None};rows.append(row);(r/(phase+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,p.returncode,row['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
