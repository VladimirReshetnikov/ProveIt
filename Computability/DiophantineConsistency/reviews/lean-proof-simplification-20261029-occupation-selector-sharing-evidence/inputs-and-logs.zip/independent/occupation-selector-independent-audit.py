from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/tmp/occupation-selector-sharing');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={};providers={}
path=str(W/'ArithmeticOccupation.lean')
assert subprocess.check_output(['git','show','f46e22674a^:'+path])==(R/'baseline/DiophantineConsistency/ArithmeticOccupation.lean').read_bytes()
assert subprocess.check_output(['git','show','f46e22674a:'+path])==(R/'final/DiophantineConsistency/ArithmeticOccupation.lean').read_bytes()==Path(path).read_bytes()
print('parent, commit and current source verified')
for n,f,ph in [('ArithmeticCellDecoding','/tmp/shared-modular-cancel/records.json','final'),('ArithmeticWangPlane','/tmp/wang-initial-sharing/records.json','final'),('ArithmeticWangSoundness','/tmp/wang-initial-sharing/records.json','final'),('ArithmeticWindowInterface','/tmp/window-rem-bound/final-records.json','final')]:
 x=next(q for q in json.loads(Path(f).read_text()) if q['module']==n and q['phase']==ph and q['status']==0);src=x.get('before',x.get('source_before'));p=R/'common/DiophantineConsistency'/(n+'.olean');assert src==h(W/(n+'.lean')) and x['object_sha256']==h(p);providers[n]=x['object_sha256'];print('prior current source/object',n,providers[n])
for ph in ['provider','baseline','final']:
 for x in json.loads((R/(ph+'-records.json')).read_text()):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-'+n+'.time')).read_text()
  if n!='ArithmeticOccupation' or ph=='baseline':assert x['before']==h(R/'baseline/DiophantineConsistency/ArithmeticOccupation.lean' if n=='ArithmeticOccupation' else W/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1]
   if m in providers:assert d['before']==providers[m]
   elif m=='ArithmeticWholeField':assert d['before']==rows['provider',m]['object_sha256'] and d['resolved']==rows['provider',m]['object']
   elif m=='ArithmeticOccupation':assert d['before']==rows[ph,m]['object_sha256'] and d['resolved']==rows[ph,m]['object']
   else:raise AssertionError(m)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for ph in ['baseline','final']:
 for x in json.loads((R/(ph+'-probes.json')).read_text()):assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticOccupation']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
assert rows['baseline','ArithmeticCellWindow']['object_sha256']==rows['final','ArithmeticCellWindow']['object_sha256'];print('client object identical')
def ds(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=ds('baseline'),ds('final');assert len(a)==70 and len(b)==71 and all(a[k]==b[k] for k in a) and 'holds_of_selector' in next(iter(b.keys()-a.keys()));print('existing declarations preserved; added',list(b.keys()-a.keys()))
for n,num in [('simp',33463),('instances',14822)]:
 a=(R/('baseline-'+n+'.log')).read_bytes();b=(R/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==num and b'holds_of_selector' not in b;print(n,num)
f=json.loads((R/'attempt1-baseline-records.json').read_text());assert len(f)==2 and f[0]['status']==0 and f[1]['status']!=0 and f[1]['log_sha256']==h(R/'attempt1-baseline-ArithmeticCellWindow.log') and 'ArithmeticWangStrip.olean' in (R/'attempt1-baseline-ArithmeticCellWindow.log').read_text();assert 'unknown module prefix' in (R/'wholefield-failed.log').read_text();print('two setup failures retained; first has no structured receipt')
p=R/'objects-baseline/DiophantineConsistency/ArithmeticBinaryCarry.olean';q=next(x for x in json.loads(Path('/tmp/outer-seed-bound-sharing/assembly-builds2.json').read_text()) if x['module']=='DiophantineConsistency.ArithmeticBinaryCarry');src='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticBinaryCarry.lean';old=hashlib.sha256(subprocess.check_output(['git','show','a3af2f89c7^:'+src])).hexdigest();assert q['status']==0 and q['source_sha256']==old!=h(src) and q['object_sha256']==h(p);print('cached pre-adoption BinaryCarry source/object',old,q['object_sha256'],'current source',h(src))
pell=next(x for x in json.loads(Path('/tmp/pell-balance-sharing/final-targets-records.json').read_text()) if x['module']=='ArithmeticPellRecurrence');assert pell['status']==0 and pell['before']==pell['after']==h(W/'ArithmeticPellRecurrence.lean')
for ph in ['provider','baseline','final']:
 lp=rows[ph,'ArithmeticWholeField' if ph=='provider' else 'ArithmeticOccupation']['LEAN_PATH'];rel='DiophantineConsistency/ArithmeticPellRecurrence.olean';p=next(Path(q)/rel for q in lp.split(':') if (Path(q)/rel).is_file());assert h(p)==pell['object_sha256'];print('PellRecurrence current first resolution',ph,p.resolve(),pell['object_sha256'])
print('all checks passed')
