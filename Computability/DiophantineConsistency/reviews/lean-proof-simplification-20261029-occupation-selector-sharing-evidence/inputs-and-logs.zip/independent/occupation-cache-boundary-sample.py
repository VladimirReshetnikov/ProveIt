from pathlib import Path
import hashlib,json
R=Path('/tmp/occupation-selector-sharing');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();out=[]
for phase in ['provider','baseline','final']:
 x=json.loads((R/(phase+'-records.json')).read_text())[0]
 for n in ['ArithmeticHalfBinomial','ArithmeticBinomLegendre','ArithmeticPellRecurrence','ArithmeticBinaryCarry']:
  rel='DiophantineConsistency/'+n+'.olean';p=next((Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file()),None);s=W/(n+'.lean')
  assert p and s.is_file();out.append({'phase':phase,'module':n,'path':str(p),'resolved':str(p.resolve()),'object_sha256':sha(p),'sampled_workspace_source':str(s),'sampled_workspace_source_sha256':sha(s)})
(R/'cache-boundary-sample.json').write_text(json.dumps(out,indent=2)+'\n')
for v in out:print(v['phase'],v['module'],v['resolved'],v['object_sha256'],v['sampled_workspace_source_sha256'])
print('Post-build sample of current first-path resolution; it is not a pinned build-time transitive import or evidence that Lean loaded every named object.')
