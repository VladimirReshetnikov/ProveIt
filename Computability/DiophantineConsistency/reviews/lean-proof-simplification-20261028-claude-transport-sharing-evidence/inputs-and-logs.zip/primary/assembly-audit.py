from pathlib import Path
import json,hashlib,re
p=Path('/dev/shm/claude-transport-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();g=json.loads((p/'ArithmeticConstructionAssembly-graph.json').read_text());plan=json.loads((p/'assembly-plan.json').read_text());pins=json.loads((p/'assembly-input-pins.json').read_text());common=json.loads((p/'assembly-common-records.json').read_text());phase=json.loads((p/'assembly-phase-records.json').read_text());probes=json.loads((p/'assembly-probe-records.json').read_text())+json.loads((p/'assembly-all-interface-records.json').read_text());assert len(g['nodes'])==115 and len(g['external'])==43 and len(plan['shared_affected'])==26 and len(plan['phase_specific'])==4
for n,v in g['nodes'].items():assert h(v['source'])==v['source_sha256'],n
assert len(common)==26 and len(phase)==8 and len(probes)==6 and len(pins['local'])==111 and len(pins['external'])==43
for x in pins['local']:assert h(x['source'])==x['source_sha256'] and h(x['object'])==x['object_sha256'],x['module']
for x in pins['external']:assert h(x['object'])==x['object_sha256'],x['module']
for r in common:
 n=r['module'];assert r['status']==0 and r['source_sha256']==r['source_after']==h(r['source']) and h(r['object'])==r['object_sha256']
 assert r['direct_inputs']==r['direct_inputs_after']
 for x in r['direct_inputs']:assert h(x['object'])==x['sha256']
 for x in r['external_inputs']:
  assert x['object'] and h(x['object'])==x['sha256'],(n,x)
 if r['kind']=='rebuilt':
  cmd=r['command'];assert cmd[-2]=='-o' and cmd[-1]==r['object'];log=p/('assembly-common-'+n.split('.')[-1]+'.log');tm=p/('assembly-common-'+n.split('.')[-1]+'.time');assert h(log)==r['log_sha256'] and h(tm)==r['time_sha256']
 else:
  d=json.loads(Path(r['provider']).read_text());providers=[x for x in d if x.get('module')==n and x.get('status')==0 and x.get('phase','final')=='final' and x.get('object_sha256')==r['object_sha256']];assert providers,n
  x=providers[0];assert h(x['source'])==x['source_sha256']==r['source_sha256'] and h(x['object'])==x['object_sha256']
  ins=x.get('local_inputs',x.get('direct_inputs',x.get('direct_project_inputs',None)));assert ins is not None
  expected={a['module']:a['sha256'] for a in ins if a.get('local',True)};actual={a['module']:a['sha256'] for a in r['direct_inputs']};assert expected==actual,(n,expected,actual)
for r in phase:
 assert r['status']==0 and r['source_sha256']==r['source_after']==h(r['source']) and h(r['object'])==r['object_sha256'];assert r['direct_inputs']==r['direct_inputs_after'] and r['pin_digest_before']==r['pin_digest_after'];assert r['pin_count_local']==111 and r['pin_count_external']==43
 for x in r['direct_inputs']:assert h(x['path'])==x['sha256'],x['module']
 tag=r['module'].split('.')[-1];assert h(p/f'assembly-{r["phase"]}-{tag}.log')==r['log_sha256'];assert h(p/f'assembly-{r["phase"]}-{tag}.time')==r['time_sha256'];assert r['command'][-2:]==['-o',r['object']]
for r in probes:
 assert r['status']==0 and h(r['source'])==r['source_sha256']==r['source_after'] and h(r['assembly_object'])==r['assembly_object_sha256']==r['assembly_object_after'] and r['pin_digest_before']==r['pin_digest_after']
 assert h(p/f'{r["phase"]}-{r["name"]}.log')==r['log_sha256'] and h(p/f'{r["phase"]}-{r["name"]}.time')==r['time_sha256']
for n in ('assembly-names','assembly-interface','assembly-all-interface'):
 assert (p/f'baseline-{n}.log').read_bytes()==(p/f'final-{n}.log').read_bytes(),n
for n in ('ArithmeticPackingCells','ArithmeticConstructionAssembly'):
 assert (p/f'assembly-baseline-{n}.log').read_bytes()==(p/f'assembly-final-{n}.log').read_bytes(),n
normal=lambda ph:re.sub(r'\.lean:\d+:\d+:','.lean:LINE:COL:',(p/f'assembly-{ph}-ArithmeticPacking.log').read_text().replace('/baseline/','/PHASE/').replace('/final/','/PHASE/'))
assert normal('baseline')==normal('final')
print('115-node graph source pins, 26 common nodes including 20 exact-input reuses, 111 local/43 external pins, 8 builds and 6 probes rechecked')
print('Assembly endpoint and 39 public/generated name/type/axiom outputs and five forced equations match; Assembly logs empty; Packing five and PackingCells four paired warnings match')
