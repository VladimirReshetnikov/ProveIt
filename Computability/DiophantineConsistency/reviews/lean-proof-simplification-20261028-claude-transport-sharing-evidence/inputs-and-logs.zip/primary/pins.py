from pathlib import Path
import hashlib,json,subprocess
P=Path('/dev/shm/claude-transport-sharing');root=Path.cwd();g=json.loads((P/'union-graph.json').read_text());paths=[str(P/'baseline')]+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip().split(':');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();skip={'DiophantineConsistency.ArithmeticPacking','DiophantineConsistency.ArithmeticConstructionVariation','DiophantineConsistency.ArithmeticPackingCells'}
def resolve(n):
 for q in paths:
  q=Path(q)
  if (q/n.split('.')[0]).exists():
   f=q/(n.replace('.','/')+'.olean')
   if f.exists():return f
   return None
for ph in ('baseline','final'):
 dst=P/ph/'DiophantineConsistency'/'CurrentKernelData2011.olean';dst.unlink(missing_ok=True);dst.symlink_to((P/'common/DiophantineConsistency/CurrentKernelData2011.olean'))
missing=[];local={}
for n,v in g['nodes'].items():
 if n in skip:continue
 f=resolve(n)
 if not f:missing.append(n);continue
 local[n]={'source':v['source'],'source_sha256':h(v['source']),'object':str(f.resolve()),'object_sha256':h(f)}
ext={}
for n in g['external']:
 f=resolve(n)
 if not f:missing.append(n);continue
 ext[n]={'object':str(f.resolve()),'object_sha256':h(f)}
print('local',len(local),'external',len(ext),'missing',missing)
(P/'selected-pins.json').write_text(json.dumps({'local':local,'external':ext,'missing':missing},indent=2)+'\n')
