from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/dev/shm/claude-transport-sharing');common=p/'assembly-common';g=json.loads((p/'ArithmeticConstructionAssembly-graph.json').read_text());plan=json.loads((p/'assembly-plan.json').read_text());nodes=g['nodes'];phase=set(plan['phase_specific']);h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();reserve=512*1024**2;diskreserve=850*1024**2;envbase=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();checks=[];external=[]
for n,v in nodes.items():
 if n in phase:continue
 src=Path(v['source']);obj=common/(n.replace('.','/')+'.olean');assert src.exists() and obj.exists(),n;assert h(src)==v['source_sha256'],('source drift',n);checks.append({'module':n,'source':str(src),'source_sha256':h(src),'object':str(obj.resolve()),'object_sha256':h(obj)})
for n in g['external']:
 found=None
 for d in (str(common)+':'+envbase).split(':'):
  f=Path(d)/(n.replace('.','/')+'.olean')
  if f.exists():found=f.resolve();break
 assert found,('missing external',n);external.append({'module':n,'object':str(found),'object_sha256':h(found)})
(p/'assembly-input-pins.json').write_text(json.dumps({'local':checks,'external':external},indent=2)+'\n')
def audit():
 for x in checks:assert h(x['source'])==x['source_sha256'] and h(x['object'])==x['object_sha256'],x['module']
 for x in external:assert h(x['object'])==x['object_sha256'],x['module']
 return hashlib.sha256(json.dumps({'local':checks,'external':external},sort_keys=True).encode()).hexdigest()
records=[]
for ph in ('baseline','final'):
 root=p/('assembly-'+ph);root.mkdir(exist_ok=True)
 for d in common.iterdir():
  if d.name=='DiophantineConsistency' or not d.is_dir():continue
  dst=root/d.name
  if not dst.exists():dst.symlink_to(d.resolve(),target_is_directory=True)
 dc=root/'DiophantineConsistency';dc.mkdir(exist_ok=True)
 for f in (common/'DiophantineConsistency').iterdir():
  if f.is_file():
   dst=dc/f.name
   if not dst.exists():dst.symlink_to(f.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+envbase
 for name in ('ArithmeticPacking','ArithmeticConstructionVariation','ArithmeticPackingCells','ArithmeticConstructionAssembly'):
  free=shutil.disk_usage(p).free;diskfree=shutil.disk_usage(Path.cwd()).free
  if free<reserve+16*1024**2 or diskfree<diskreserve:raise RuntimeError(f'storage reserve: shm={free}, disk={diskfree}')
  n='DiophantineConsistency.'+name;candidate=name in ('ArithmeticPacking','ArithmeticConstructionVariation');source=(p/ph/'DiophantineConsistency'/f'{name}.lean') if candidate else Path(nodes[n]['source']);out=dc/f'{name}.olean';out.unlink(missing_ok=True)
  inputs=[]
  for dep in nodes[n]['imports']:
   if dep not in nodes:continue
   q=root/(dep.replace('.','/')+'.olean');assert q.exists(),(n,dep);inputs.append({'module':dep,'path':str(q.resolve()),'sha256':h(q)})
  sh=h(source);before=audit();tm=p/f'assembly-{ph}-{name}.time';log=p/f'assembly-{ph}-{name}.log';srcroot=str(p/ph) if candidate else 'Computability/DiophantineConsistency/Lean';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',srcroot,str(source),'-o',str(out)];start=time.monotonic()
  with log.open('wb') as z:rc=subprocess.run(cmd,env=env,stdout=z,stderr=subprocess.STDOUT).returncode
  after=audit();inputs_after=[{'module':x['module'],'path':x['path'],'sha256':h(x['path'])} for x in inputs];rec={'phase':ph,'module':n,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(source.resolve()),'source_sha256':sh,'source_after':h(source),'direct_inputs':inputs,'direct_inputs_after':inputs_after,'pin_count_local':len(checks),'pin_count_external':len(external),'pin_digest_before':before,'pin_digest_after':after,'object':str(out),'object_sha256':h(out) if out.exists() else None,'object_bytes':out.stat().st_size if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-start,3),'shm_free_before':free,'disk_free_before':diskfree};records.append(rec);(p/'assembly-phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True)
  assert rc==0 and sh==rec['source_after'] and inputs==inputs_after and before==after
