from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/dev/shm/claude-transport-sharing');pins=json.loads((p/'assembly-input-pins.json').read_text());base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
def audit():
 for x in pins['local']:assert h(x['source'])==x['source_sha256'] and h(x['object'])==x['object_sha256'],x['module']
 for x in pins['external']:assert h(x['object'])==x['object_sha256'],x['module']
 return hashlib.sha256(json.dumps(pins,sort_keys=True).encode()).hexdigest()
for ph in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/('assembly-'+ph))+':'+base
 for name in ('assembly-all-interface',):
  source=p/(name+'.lean');log=p/(ph+'-'+name+'.log');tm=p/(ph+'-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p),str(source)];s=h(source);before=audit();assembly=p/('assembly-'+ph)/'DiophantineConsistency/ArithmeticConstructionAssembly.olean';ah=h(assembly);start=time.monotonic()
  with log.open('wb') as f:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  after=audit();r={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(source),'source_sha256':s,'source_after':h(source),'assembly_object':str(assembly),'assembly_object_sha256':ah,'assembly_object_after':h(assembly),'pin_digest_before':before,'pin_digest_after':after,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-start,2)};records.append(r);(p/'assembly-all-interface-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True)
  assert rc==0 and s==r['source_after'] and ah==r['assembly_object_after'] and before==after
