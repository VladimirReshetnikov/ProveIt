import DiophantineConsistency.ArithmeticConstructionAssembly
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.ArithmeticConstructionAssembly).isPrefixOf n ||
        (`DiophantineConsistency.ArithmeticConstructionBound).isPrefixOf n then
      logInfo m!"{n}"
#print equations DiophantineConsistency.ArithmeticConstructionBound.Nb
#print equations DiophantineConsistency.ArithmeticConstructionBound.Q
#print equations DiophantineConsistency.ArithmeticConstructionBound.Rq
#print equations DiophantineConsistency.ArithmeticConstructionBound.Wb
#print equations DiophantineConsistency.ArithmeticConstructionBound.zeroBound
