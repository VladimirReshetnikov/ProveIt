import DiophantineConsistency.ArithmeticConstructionVariation
import DiophantineConsistency.ArithmeticPackingCells
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.ArithmeticPacking).isPrefixOf n || (`DiophantineConsistency.ArithmeticConstructionVariation).isPrefixOf n then
      logInfo m!"{n}"
