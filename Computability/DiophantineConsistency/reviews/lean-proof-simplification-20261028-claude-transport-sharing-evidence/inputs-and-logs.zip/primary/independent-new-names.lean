import DiophantineConsistency.ArithmeticPacking
#print axioms DiophantineConsistency.ArithmeticPacking.rot_identity
#print axioms DiophantineConsistency.ArithmeticPacking.transport_formula
#print axioms DiophantineConsistency.ArithmeticPacking.Fw.congr_simp
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n := `DiophantineConsistency.ArithmeticPacking.Fw.congr_simp
  logInfo m!"Fw.congr_simp default simp: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
