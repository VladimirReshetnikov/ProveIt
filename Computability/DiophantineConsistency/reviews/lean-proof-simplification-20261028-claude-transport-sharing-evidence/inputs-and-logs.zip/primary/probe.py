from pathlib import Path
import os,subprocess,time,json,hashlib,sys
P=Path('/dev/shm/claude-transport-sharing');kind=sys.argv[1];base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();src=P/(kind+'.lean');records=[]
for ph in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(P/ph)+':'+base;log=P/(ph+'-'+kind+'.log');tm=P/(ph+'-'+kind+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(P),str(src)];before=h(src)
 with log.open('wb') as dest:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=dest,stderr=subprocess.STDOUT).returncode
 r={'phase':ph,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,2)};records.append(r);(P/(kind+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(ph,kind,rc,flush=True)
 if rc or before!=r['source_after']:raise SystemExit(1)
