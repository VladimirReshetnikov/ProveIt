from pathlib import Path
import os,subprocess,time,json,hashlib
P=Path('/dev/shm/claude-transport-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();pins=json.loads((P/'selected-pins.json').read_text());records=[]
def checkpins():
 for name,x in pins['local'].items():assert h(x['source'])==x['source_sha256'] and h(x['object'])==x['object_sha256'],name
 for name,x in pins['external'].items():assert h(x['object'])==x['object_sha256'],name
for ph in ('baseline','final'):
 root=P/ph;env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+base
 for name in ('ArithmeticPacking','ArithmeticConstructionVariation','ArithmeticPackingCells'):
  f=root/'DiophantineConsistency'/(name+'.lean') if name!='ArithmeticPackingCells' else Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPackingCells.lean')
  srcroot=root if name!='ArithmeticPackingCells' else Path('Computability/DiophantineConsistency/Lean');out=root/'DiophantineConsistency'/(name+'.olean');out.unlink(missing_ok=True)
  log=P/(ph+'-'+name+'.log');tm=P/(ph+'-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(f),'-o',str(out)];before=h(f);checkpins()
  with log.open('wb') as dest:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=dest,stderr=subprocess.STDOUT).returncode
  checkpins();r={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source_sha256':before,'source_after':h(f),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,2),'pinned_local':len(pins['local']),'pinned_external':len(pins['external'])};records.append(r);(P/'replay-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True)
  if rc or before!=r['source_after']:raise SystemExit(1)
