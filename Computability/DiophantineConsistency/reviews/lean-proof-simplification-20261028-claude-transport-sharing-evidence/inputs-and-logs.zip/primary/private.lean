import DiophantineConsistency.ArithmeticConstructionVariation
import DiophantineConsistency.ArithmeticPackingCells
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    let s := n.toString
    if s.startsWith "_private.DiophantineConsistency.ArithmeticPacking." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticConstructionVariation." then
      let axs ← collectAxioms n
      logInfo m!"NAME {n}\nTYPE {c.type}\nAXIOMS {axs}"
