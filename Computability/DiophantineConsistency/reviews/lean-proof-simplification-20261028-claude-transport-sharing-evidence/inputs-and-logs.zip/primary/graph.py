from pathlib import Path
import hashlib,json,tomllib,subprocess
P=Path('/dev/shm/claude-transport-sharing');root=Path.cwd();cfg=tomllib.loads((root/'lakefile.toml').read_text());roots=list(dict.fromkeys((root/x.get('srcDir','.')).resolve() for x in cfg['lean_lib']));h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for target in ('ArithmeticPacking','ArithmeticConstructionVariation','ArithmeticPackingCells','ArithmeticConstructionAssembly'):
 seen={};ext=set();todo=['DiophantineConsistency.'+target]
 while todo:
  n=todo.pop()
  if n in seen or n in ext:continue
  special=n.split('.')[-1] in ('ArithmeticPacking','ArithmeticConstructionVariation') and n.startswith('DiophantineConsistency.')
  matches=[P/'final/DiophantineConsistency'/(n.split('.')[-1]+'.lean')] if special else list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).exists()))
  if not matches:ext.add(n);continue
  assert len(matches)==1,(n,matches);f=matches[0];im=[]
  for line in f.read_text().splitlines():
   if line.startswith('import '):im+=line.split('--')[0].split()[1:]
  seen[n]={'source':str(f),'source_sha256':h(f),'imports':im};todo.extend(im)
 previous=json.loads(Path('/tmp/construction-share/bound-graph-after-mask.json').read_text())['nodes'];changed=[n for n,v in seen.items() if n in previous and n not in ('DiophantineConsistency.ArithmeticPacking','DiophantineConsistency.ArithmeticConstructionVariation') and v['source_sha256']!=previous[n]['source_sha256']]
 print(target,'local',len(seen),'external',len(ext),'changed-since-predecessor',len(changed));print(' ', ', '.join(x.split('.')[-1] for x in changed))
 (P/(target+'-graph.json')).write_text(json.dumps({'nodes':seen,'external':sorted(ext),'changed_sources':changed},indent=2)+'\n')
