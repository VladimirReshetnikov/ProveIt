from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/dev/shm/claude-transport-sharing');root=p/'assembly-common';graph=json.loads((p/'ArithmeticConstructionAssembly-graph.json').read_text());g=graph['nodes'];plan=json.loads((p/'assembly-plan.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();reserve=512*1024**2;diskreserve=850*1024**2;envbase=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+envbase
sources=['/tmp/pell-construction-refresh/resumed-records.json','/tmp/kernel-residues-sharing/coherent-refresh-records.json','/tmp/construction-share/bound-refresh-records.json'];producers={}
for path in sources:
 for r in json.loads(Path(path).read_text()):
  if r.get('status')!=0 or r.get('phase','final')!='final' or not r.get('module'):continue
  producers.setdefault(r['module'],[]).append((path,r))
def local_inputs(n):
 out=[]
 for dep in g[n]['imports']:
  if dep not in g:continue
  f=root/(dep.replace('.','/')+'.olean');assert f.exists(),(n,dep);out.append({'module':dep,'object':str(f.resolve()),'sha256':h(f)})
 return out
def external_inputs(n):
 out=[]
 for dep in g[n]['imports']:
  if dep in g:continue
  f=None
  for base in env['LEAN_PATH'].split(':'):
   q=Path(base)/(dep.replace('.','/')+'.olean')
   if q.exists():f=q.resolve();break
  out.append({'module':dep,'object':str(f) if f else None,'sha256':h(f) if f else None})
 return out
def can_reuse(n,r,current):
 f=Path(r.get('source','/nonexistent'));o=Path(r.get('object','/nonexistent'))
 if not f.exists() or not o.exists() or h(f)!=g[n]['source_sha256'] or h(f)!=r.get('source_sha256') or h(o)!=r.get('object_sha256'):return False
 if 'local_inputs' in r:xs=r['local_inputs']
 elif 'direct_inputs' in r:xs=[x for x in r['direct_inputs'] if x.get('local',True)]
 elif 'direct_project_inputs' in r:xs=r['direct_project_inputs']
 else:return False
 old={x['module']:x['sha256'] for x in xs};now={x['module']:x['sha256'] for x in current}
 if old!=now:return False
 for x in r.get('direct_external_inputs',[]):
  if x.get('object') and x.get('sha256') and (not Path(x['object']).exists() or h(x['object'])!=x['sha256']):return False
 return True
records=[]
for n in plan['shared_affected']:
 if shutil.disk_usage(p).free<reserve+16*1024**2 or shutil.disk_usage(Path.cwd()).free<diskreserve:raise RuntimeError('storage reserve reached before '+n)
 source=Path(g[n]['source']);before=h(source);assert before==g[n]['source_sha256'];inputs=local_inputs(n);ext=external_inputs(n);obj=root/(n.replace('.','/')+'.olean')
 hit=None
 for path,r in producers.get(n,[]):
  if can_reuse(n,r,inputs):hit=(path,r);break
 start=time.monotonic()
 if hit:
  obj.unlink(missing_ok=True);obj.symlink_to(Path(hit[1]['object']).resolve());status=0;command=None;logsha=None;timesha=None;kind='reused';provider=hit[0]
 else:
  obj.unlink(missing_ok=True);name=n.split('.')[-1];log=p/('assembly-common-'+name+'.log');tm=p/('assembly-common-'+name+'.time');srcroot=Path.cwd()/'Computability/DiophantineConsistency/Lean';assert n.startswith('DiophantineConsistency.'),n
  command=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(source),'-o',str(obj)]
  with log.open('wb') as z:status=subprocess.run(command,env=env,stdout=z,stderr=subprocess.STDOUT).returncode
  logsha=h(log);timesha=h(tm);kind='rebuilt';provider=None
 rec={'module':n,'kind':kind,'status':status,'source':str(source),'source_sha256':before,'source_after':h(source),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'direct_inputs':inputs,'direct_inputs_after':local_inputs(n),'external_inputs':ext,'provider':provider,'command':command,'lean_path':env['LEAN_PATH'],'log_sha256':logsha,'time_sha256':timesha,'elapsed':round(time.monotonic()-start,3),'shm_free':shutil.disk_usage(p).free,'disk_free':shutil.disk_usage(Path.cwd()).free};records.append(rec);(p/'assembly-common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(kind,n,status,flush=True)
 assert status==0 and rec['source_sha256']==rec['source_after'] and rec['direct_inputs']==rec['direct_inputs_after']
