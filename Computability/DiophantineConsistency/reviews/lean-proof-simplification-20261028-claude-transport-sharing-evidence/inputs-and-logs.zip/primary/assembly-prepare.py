from pathlib import Path
import os,json,hashlib,shutil
p=Path('/dev/shm/claude-transport-sharing');base=Path('/tmp/construction-share/pinned-final');raw=json.loads((p/'ArithmeticConstructionAssembly-graph.json').read_text());g=raw['nodes'];root=p/'assembly-common';root.mkdir(exist_ok=True);reserve=512*1024**2;assert shutil.disk_usage(p).free>reserve+64*1024**2
h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for f in base.iterdir():
 if f.name=='DiophantineConsistency' or not f.is_dir():continue
 dst=root/f.name
 if not dst.exists():dst.symlink_to(f.resolve(),target_is_directory=True)
d=root/'DiophantineConsistency';d.mkdir(exist_ok=True)
for n,v in g.items():
 if not n.startswith('DiophantineConsistency.'):continue
 src=base/(n.replace('.','/')+'.olean');assert src.exists(),n;dst=root/(n.replace('.','/')+'.olean');dst.symlink_to(src.resolve())
seeds=set(raw['changed_sources']);seeds.update('DiophantineConsistency.'+n for n in ('ArithmeticPacking','ArithmeticConstructionVariation'));affected=set(seeds)
while True:
 size=len(affected)
 for n,v in g.items():
  if set(v['imports'])&affected:affected.add(n)
 if size==len(affected):break
phase=set('DiophantineConsistency.'+n for n in ('ArithmeticPacking','ArithmeticConstructionVariation','ArithmeticPackingCells','ArithmeticConstructionAssembly'));assert phase<=affected
order=[];state={}
def visit(n):
 if n not in g or state.get(n)==2:return
 assert state.get(n)!=1,('cycle',n);state[n]=1
 for dep in g[n]['imports']:visit(dep)
 state[n]=2;order.append(n)
for n in g:visit(n)
assert len(order)==len(g)
old=json.loads(Path('/tmp/construction-share/bound-graph-after-mask.json').read_text())['nodes'];pins=[]
for n,v in g.items():
 src=Path(v['source']);assert h(src)==v['source_sha256'],('source drift',n)
 obj=root/(n.replace('.','/')+'.olean');assert obj.exists(),('missing object',n)
 if n not in affected:
  assert n in old and old[n]['source_sha256']==v['source_sha256'],('unchanged source lacks provenance',n)
 pins.append({'module':n,'source':str(src),'source_sha256':h(src),'initial_object':str(obj.resolve()),'initial_object_sha256':h(obj),'affected':n in affected,'phase_specific':n in phase})
plan={'order':order,'affected':[n for n in order if n in affected],'phase_specific':[n for n in order if n in phase],'shared_affected':[n for n in order if n in affected and n not in phase],'pins':pins}
(p/'assembly-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('planned',len(g),'nodes;',len(affected),'affected;',len(plan['shared_affected']),'shared;',len(phase),'phase-specific; /dev/shm free',shutil.disk_usage(p).free)
