from pathlib import Path
import hashlib,json,subprocess,zipfile,shutil
repo=Path('/home/codex/.codex/worktrees/62ff/Proofs')
p=Path('/dev/shm/claude-transport-sharing')
out=repo/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261028-claude-transport-sharing-evidence'
assert shutil.disk_usage(repo).free>850*1024**2
assert not out.exists(), 'refusing to overwrite existing evidence'
out.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
commit=git('rev-parse','9aee4917b7').decode().strip(); parent=git('rev-parse',commit+'^').decode().strip()
nodes=json.loads((p/'ArithmeticConstructionAssembly-graph.json').read_text())['nodes']; assert len(nodes)==115
members={}
def add(name,data):
 assert name not in members,name
 members[name]=data
for f in sorted(p.iterdir()):
 if f.is_file() and f.suffix in {'.json','.py','.lean','.md','.txt','.log','.time'}:add('primary/'+f.name,f.read_bytes())
for f in sorted(Path('/dev/shm').glob('claude-transport-independent-*')):
 if f.is_file() and f.suffix in {'.json','.py','.lean','.md','.txt','.log','.time'}:add('independent/'+f.name,f.read_bytes())
for module,record in sorted(nodes.items()):
 data=Path(record['source']).read_bytes();assert sha(data)==record['source_sha256'],module
 add('graph-sources/'+module.replace('.','/')+'.lean',data)
for target in ('ArithmeticPacking','ArithmeticConstructionVariation'):
 path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+target+'.lean'
 for phase,revision in [('baseline',parent),('final',commit)]:
  data=(p/phase/'DiophantineConsistency'/f'{target}.lean').read_bytes();assert data==git('show',revision+':'+path),(phase,target)
  add(f'target-snapshots/{phase}/{target}.lean',data)
for x in ('/tmp/construction-share/bound-refresh-records.json','/tmp/kernel-residues-sharing/coherent-refresh-records.json','/tmp/pell-construction-refresh/resumed-records.json'):
 f=Path(x);add('prior-receipts/'+f.parent.name+'/'+f.name,f.read_bytes())
for rev in ('16bbf5027062f5082a385ee347e063c5082fa177','5fcd5632b3b753237437f22904b899653f69916b'):
 data=git('show','--format=full','--stat','--no-renames',rev,'--','Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPacking.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticConstructionVariation.lean')
 assert b'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>' in data
 add('provenance/'+rev+'.txt',data)
add('packaging/package.py',Path('/tmp/package-claude-transport.py').read_bytes())
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(members)
 for name,data in members.items():assert sha(z.read(name))==sha(data),name
assert all(Path(name).suffix not in {'.olean','.ilean','.ir','.o','.server','.private'} for name in members)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Claude-coauthored arithmetic transport proof sharing; paired targets and ArithmeticPackingCells plus the current-source ArithmeticConstructionAssembly production client','coauthor_provenance':{'commits':['16bbf5027062f5082a385ee347e063c5082fa177','5fcd5632b3b753237437f22904b899653f69916b'],'trailer':'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>','qualification':'Git commit coauthor trailer for source work; not a claim that Claude is the Git author.'},'validation':'115 local source graph; 26 common affected nodes (6 rebuilt, 20 exact-source/object/direct-input receipt matches); paired source builds for Packing, Variation, PackingCells, Assembly (8 total); source/object input pins for 111 local and 43 direct external inputs; paired Assembly endpoint and 39 old public/generated declarations and 5 forced equation listings match; independent rechecks and provider audit included.','limitations':['This is not a clean full repository build: unaffected historical local objects, dependency package objects, and transitive package inputs remained precompiled.','Assembly logs are empty and matched. Packing shows five matching warnings after normalizing locations; PackingCells shows four matching warnings in paired Assembly refresh builds. One shared rebuilt ArithmeticMaskData warning has no paired preparation baseline. Metadata probes produce 22 matching generated-auxiliary warnings per phase.','The initial independent assembly-records audit failed due to a schema assumption; its corrected audit passes. Failed prototype and initial interface logs are retained.','Receipt paths and object hashes document selected cached objects; compiled binaries are excluded. The zip is an evidence snapshot, not a self-contained Lean toolchain.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(archive.read_bytes()),'members':{name:{'sha256':sha(data),'bytes':len(data)} for name,data in sorted(members.items())}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
check=json.loads((out/'BUNDLE.json').read_text());assert check['archive_sha256']==sha(archive.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,r in check['members'].items():assert sha(z.read(n))==r['sha256'] and len(z.read(n))==r['bytes']
print('directory',out,'\nmembers',len(members),'\narchive bytes',archive.stat().st_size,'\narchive SHA256',manifest['archive_sha256'],'\nmanifest SHA256',sha((out/'BUNDLE.json').read_bytes()))
