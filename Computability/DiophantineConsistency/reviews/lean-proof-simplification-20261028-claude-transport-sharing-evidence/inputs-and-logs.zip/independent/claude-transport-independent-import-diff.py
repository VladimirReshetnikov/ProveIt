from pathlib import Path
import re,json,hashlib,tomllib
p=Path('/dev/shm/claude-transport-sharing');W=Path.cwd();saved=json.loads((p/'union-graph.json').read_text());roots=list(dict.fromkeys((W/x.get('srcDir','.')).resolve() for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']));h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[]
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(f):
 out=[]
 for line in strip(Path(f).read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out

def closure(phase):
 G={};E=set()
 def visit(n):
  if n in G or n in E:return
  if n in ('DiophantineConsistency.ArithmeticPacking','DiophantineConsistency.ArithmeticConstructionVariation'):
   f=p/phase/'DiophantineConsistency'/(n.split('.')[-1]+'.lean')
  else:
   loc=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
   if not loc:E.add(n);return
   assert len(loc)==1;(f,)=loc
  G[n]=imports(f)
  for x in G[n]:visit(x)
 for z in ('ArithmeticPacking','ArithmeticConstructionVariation','ArithmeticPackingCells'):visit('DiophantineConsistency.'+z)
 return G,E
a,ea=closure('baseline');b,eb=closure('final');diff=[x for x in set(a)&set(b) if a[x]!=b[x]];out={'baseline_local':len(a),'final_local':len(b),'edge_differences':diff,'added_local':sorted(set(b)-set(a)),'removed_local':sorted(set(a)-set(b)),'added_external':sorted(eb-ea),'removed_external':sorted(ea-eb)};print(json.dumps(out,indent=2));Path('/dev/shm/claude-transport-independent-import-diff.json').write_text(json.dumps(out,indent=2)+'\n')
