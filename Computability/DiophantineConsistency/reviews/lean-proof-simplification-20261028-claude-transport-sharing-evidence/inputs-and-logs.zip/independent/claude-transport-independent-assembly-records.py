from pathlib import Path
import json,hashlib
P=Path('/dev/shm/claude-transport-sharing');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();g=json.loads((P/'ArithmeticConstructionAssembly-graph.json').read_text()); nodes=g['nodes'];pins=json.loads((P/'assembly-input-pins.json').read_text());assert (len(pins['local']),len(pins['external']))==(111,43)
for x in pins['local']:assert H(x['source'])==x['source_sha256'] and H(x['object'])==x['object_sha256'],x['module']
for x in pins['external']:assert H(x['object'])==x['object_sha256'],x['module']
digest=hashlib.sha256(json.dumps(pins,sort_keys=True).encode()).hexdigest();print('111 local, 43 direct external hashes and pin digest',digest)
common=json.loads((P/'assembly-common-records.json').read_text());assert len(common)==26
for x in common:
 assert x['status']==0 and H(x['source'])==x['source_sha256']==x['source_after'] and H(x['object'])==x['object_sha256'],x['module']
 assert x['direct_inputs']==x['direct_inputs_after']
 for i in x['direct_inputs']+x['external_inputs']:assert H(i['object'])==i['sha256'],(x['module'],i['module'])
 assert set(i['module'] for i in x['direct_inputs'])==set(nodes[x['module']]['imports']) & set(nodes),(x['module'],'direct coverage')
 if x['kind']=='rebuilt':
  n=x['module'].split('.')[-1];assert H(P/('assembly-common-'+n+'.log'))==x['log_sha256'] and H(P/('assembly-common-'+n+'.time'))==x['time_sha256']
print('26 common inputs rehashed, including 6 rebuilt logs and timings')
rs=json.loads((P/'assembly-phase-records.json').read_text());assert len(rs)==8,len(rs)
for x in rs:
 n=x['module'].split('.')[-1];ph=x['phase'];assert x['status']==0 and H(x['source'])==x['source_sha256']==x['source_after'] and H(x['object'])==x['object_sha256'];assert (x['pin_count_local'],x['pin_count_external'])==(111,43) and x['pin_digest_before']==x['pin_digest_after']==digest
 assert x['direct_inputs']==x['direct_inputs_after']
 for i in x['direct_inputs']:assert H(i['path'])==i['sha256'],(x['module'],i['module'])
 assert set(i['module'] for i in x['direct_inputs'])==set(nodes[x['module']]['imports']) & set(nodes),(x['module'],'direct coverage')
 assert H(P/('assembly-'+ph+'-'+n+'.log'))==x['log_sha256'] and H(P/('assembly-'+ph+'-'+n+'.time'))==x['time_sha256']
 print(ph,n,'passed with',len(x['direct_inputs']),'direct local inputs')
print('all eight Assembly graph builds and direct-input pins pass')
