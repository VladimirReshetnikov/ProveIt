from pathlib import Path
import hashlib,json
p=Path('/dev/shm/claude-transport-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();pins=json.loads((p/'selected-pins.json').read_text());g=json.loads((p/'union-graph.json').read_text());assert len(pins['local'])==51 and len(pins['external'])==15 and not pins['missing'];assert len(g['nodes'])==54 and set(g['external'])==set(pins['external']);skip={'DiophantineConsistency.'+x for x in ('ArithmeticPacking','ArithmeticConstructionVariation','ArithmeticPackingCells')};assert set(pins['local'])==set(g['nodes'])-skip
for n,x in pins['local'].items():assert h(x['source'])==x['source_sha256']==g['nodes'][n]['source_sha256'] and h(x['object'])==x['object_sha256'],n
for n,x in pins['external'].items():assert h(x['object'])==x['object_sha256'],n
print('51 local source/object and 15 direct external pins verified')
records=json.loads((p/'replay-records.json').read_text());assert len(records)==6
for r in records:
 c=r['command'];ph=r['phase'];name=r['name'];src=[x for x in c if x.endswith('.lean')];assert len(src)==1 and r['status']==0 and h(src[0])==r['source_sha256']==r['source_after'];assert c[-2]=='-o' and h(c[-1])==r['object_sha256'];assert h(p/(ph+'-'+name+'.log'))==r['log_sha256'] and h(c[4])==r['time_sha256'];assert r['lean_path'].split(':')[0]==str(p/ph) and r['pinned_local']==51 and r['pinned_external']==15
print('six paired target/client source/object/log/timing records verified')
for fn in ('names','interface','private','equations'):
 rows=json.loads((p/(fn+'-records.json')).read_text());assert len(rows)==2
 for r in rows:
  ph=r['phase'];c=r['command'];src=[x for x in c if x.endswith('.lean')];assert len(src)==1 and r['status']==0 and h(src[0])==r['source_sha256']==r['source_after'];assert h(p/(ph+'-'+fn+'.log'))==r['log_sha256'] and h(c[4])==r['time_sha256'] and r['lean_path'].split(':')[0]==str(p/ph)
 print(fn,'two probe records verified')
for n in ('interface','private','equations'):
 a=(p/('baseline-'+n+'.log')).read_bytes();b=(p/('final-'+n+'.log')).read_bytes();print(n,'byte-identical',a==b)
