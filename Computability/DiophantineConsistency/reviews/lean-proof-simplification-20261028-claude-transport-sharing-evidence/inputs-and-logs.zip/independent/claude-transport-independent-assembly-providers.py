from pathlib import Path
import hashlib,json
p=Path('/dev/shm/claude-transport-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=json.loads((p/'assembly-common-records.json').read_text());count=0
for x in rs:
 if x['kind']!='reused':continue
 prev=json.loads(Path(x['provider']).read_text());hits=[]
 for r in prev:
  if r.get('module')!=x['module'] or r.get('status')!=0 or r.get('phase','final')!='final' or r.get('source_sha256')!=x['source_sha256'] or r.get('object_sha256')!=x['object_sha256']:continue
  xs=r.get('local_inputs',r.get('direct_inputs',r.get('direct_project_inputs',[])));xs=[z for z in xs if z.get('local',True)]
  if {z['module']:z['sha256'] for z in xs}!={z['module']:z['sha256'] for z in x['direct_inputs']}:continue
  if h(r['source'])!=r['source_sha256'] or h(r['object'])!=r['object_sha256']:continue
  hits.append(r)
 assert hits,x['module'];count+=1
print(count,'reused common modules match prior successful source/object and complete selected local direct-input records')
assert count==20
