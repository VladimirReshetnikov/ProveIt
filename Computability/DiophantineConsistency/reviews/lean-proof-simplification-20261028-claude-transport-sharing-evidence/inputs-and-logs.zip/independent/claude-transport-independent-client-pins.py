from pathlib import Path
import json,hashlib
P=Path('/dev/shm/claude-transport-sharing'); h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
R=json.loads((P/'client-pinned-records.json').read_text());old=json.loads((P/'replay-records.json').read_text()); assert len(R)==4
for r in R:
 ph,n=r['phase'],r['name']; src=next(Path(x) for x in r['command'] if x.endswith('.lean')); out=Path(r['command'][-1]); log=P/(ph+'-pinned-'+n+'.log'); tm=P/(ph+'-pinned-'+n+'.time')
 assert r['status']==0 and h(src)==r['source_sha256']==r['source_after'] and h(out)==r['object_sha256'] and h(log)==r['log_sha256'] and h(tm)==r['time_sha256']
 assert (r['pinned_local'],r['pinned_external'])==(51,15)
 for mod,x in r['direct_inputs'].items(): assert h(x['object'])==x['sha256'],mod
 packing=r['direct_inputs']['DiophantineConsistency.ArithmeticPacking']; assert packing['sha256']==h(P/ph/'DiophantineConsistency/ArithmeticPacking.olean')
 oldrec=next(x for x in old if x['phase']==ph and x['name']==n); assert r['object_sha256']==oldrec['object_sha256'],(ph,n)
 print(ph,n,'OK, matching original object; direct pins',len(r['direct_inputs']))
print('all four direct-client pinned replays pass')
