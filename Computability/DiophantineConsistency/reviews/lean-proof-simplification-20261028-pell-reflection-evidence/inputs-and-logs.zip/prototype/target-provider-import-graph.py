from pathlib import Path
import re,json,hashlib
r=Path('/tmp/pell-reflection-simp'); src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');roots=['ArithmeticPellCongruences']; nodes={}; external=set();todo=list(roots)
while todo:
 n=todo.pop()
 if n in nodes:continue
 p=src/(n+'.lean');text=p.read_text(); im=re.findall(r'^import\s+(\S+)',text,re.M);nodes[n]={'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'imports':im}
 for m in im:
  if m.startswith('DiophantineConsistency.') and (src/(m.split('.')[-1]+'.lean')).exists():todo.append(m.split('.')[-1])
  else:external.add(m)
targets=['ArithmeticPellPeriodicity','ArithmeticPellResidueClasses']; out={'roots':roots,'targets':targets,'targets_in_project_closure':[n for n in targets if n in nodes],'project_nodes':nodes,'external_direct_imports':sorted(external),'scope':'Static transitive source import graph for project modules; external imports are boundary leaves, not recursively inspected.'}
(r/'target-provider-import-graph.json').write_text(json.dumps(out,indent=2)+'\n');print('project modules',len(nodes),'target hits',out['targets_in_project_closure']);print('modules',', '.join(sorted(nodes)));print('external boundary',len(external))
