# Internal Pell reflection proof simplification

Candidate files:
- `final/DiophantineConsistency/ArithmeticPellPeriodicity.lean`: SHA-256 `27f0089eef0b1da679d0a79b24eafc0d18be047c2bcc69b240f78b321f040cdd`.
- `final/DiophantineConsistency/ArithmeticPellResidueClasses.lean`: SHA-256 `5c70f7f78028f1ae5cb3a897fe1817ecec0b6cbdb96f00cd9fc469bf567158eb`.

Each existing reflection theorem is derived from its existing additive
reflection theorem with `simpa only [two_mul, ← add_assoc,
tsub_add_cancel_of_le hm]`. The statements, data and imports are unchanged;
each source is four lines shorter. `proof-probe.lean` passed separately over
cached original providers; that preliminary probe does not replace the target
or client builds.

Paired baseline/final target and initial HalfIndex builds are recorded in
`records.json`. The first target sample used 7.59/7.92 seconds user CPU
(Periodicity) and 8.22/8.89 seconds (ResidueClasses). A second sequential
sample, `repeat-records.json`, used 8.10/7.70 and 9.14/8.50 seconds. These are
small shared-load samples and do not show a consistent direction or establish
a general performance result.

The initial HalfIndex pair used a stale `ArithmeticPellIndexDivisibility`
object and is superseded. Its old source receipt was `c2d78a3f…`; current
source is `fc0e2fc5…`. The underlying `ArithmeticGcdNormalization`,
`ArithmeticPellCommonUnit` and `ArithmeticPellIntegralSolution` sources had
also changed. Five modules were compiled from current sources in dependency
order: GcdNormalization, PellStrongDivisibility, PellCommonUnit,
PellIntegralSolution and PellIndexDivisibility. Their source hashes, direct
inputs, object hashes, logs and commands are in `refresh-records.json`.
The two actual `ArithmeticPellHalfIndex` client replays then passed against the
refreshed `ArithmeticPellIndexDivisibility` object and their respective
Periodicity/ResidueClasses objects; `client-records.json` pins all direct
inputs. Their object files are byte-identical, SHA-256
`caa03048026a27a94e06a90cffe54f752bfc8e98e4b7fcd0b4face9a441c53f0`.

The Periodicity target's direct provider `ArithmeticPellCongruences` object is
`76bd24801e2bff1779a26f9e93e6c3cf67029b9608f06083a832c2ae052151ad`,
matching the current source hash `43a4e20045fbf7b65c4720ce7abcfabdbf09bd46c471effd4f11e0c52a7cb1ec`
and an earlier successful receipt in
`/tmp/outer-seed-bound-sharing/prereq2-records.json`. Its project source
closure consists of Congruences, Classification and Recurrence, as recorded
in `target-provider-import-graph.json`; the latter two source hashes also
match prior receipts. The independent refreshed client-provider graph has
neither changed reflection module in its project source closure, as recorded
in `refresh-import-graph.json`. Searches of accessible Foundation and Mathlib
source trees found no references to either target name. Foundation/Mathlib and
other upstream dependencies remain cached; these checks do not constitute a
complete fresh build of the transitive closure.

Eight successful probe runs, with exact paths, source/object and log hashes in
`probe-records.json`, found the 26 existing target declarations and their
type/axiom reports unchanged. There are two added generated declarations:
`ArithmeticPellPeriodicity.reflection._simp_1` and
`ArithmeticPellResidueClasses.x_reflection._simp_1`. The complete reports for
28,968 global simp entries and 13,167 instances are byte-identical; this does
not assert equality of every possible persistent environment extension.

The first full-target attempt failed immediately because the isolated module
namespace lacked symlinks to its dependency objects. Its failed log, timing,
record and driver output are in `historical/`; after adding explicit links to
the pinned common provider, all reported builds succeeded. The stale initial
HalfIndex pair is retained as historical, not current-provider validation.
