from pathlib import Path
import os,subprocess,hashlib,json,sys
R=Path('/tmp/pell-reflection-simp'); base=os.environ['LEAN_PATH']; sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); records=[]
def probe(phase,kind):
 obj=R/('objects-'+phase)/'DiophantineConsistency';env=os.environ.copy();env['LEAN_PATH']=str(obj.parent)+':/tmp/outer-seed-bound-sharing/common:'+base
 src=R/(kind+'.lean'); log=R/(phase+'-'+kind+'.log'); before=sha(src); mods=['ArithmeticPellPeriodicity','ArithmeticPellResidueClasses']; objs=[{'path':str(obj/(m+'.olean')),'before':sha(obj/(m+'.olean'))} for m in mods]
 cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for x in objs:x['after']=sha(x['path'])
 records.append({'phase':phase,'probe':kind,'status':r.returncode,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'source':str(src),'source_before':before,'source_after':sha(src),'objects':objs,'log':str(log),'log_sha256':sha(log)})
 (R/'probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,kind,r.returncode,flush=True)
 if r.returncode or before!=sha(src) or any(x['before']!=x['after'] for x in objs):sys.exit(1)
for phase in ['baseline','final']:probe(phase,'names')
a={s[5:] for s in (R/'baseline-names.log').read_text().splitlines() if s.startswith('DECL ')};b={s[5:] for s in (R/'final-names.log').read_text().splitlines() if s.startswith('DECL ')}
(R/'name-diff.json').write_text(json.dumps({'removed':sorted(a-b),'added':sorted(b-a),'common':len(a&b)},indent=2)+'\n')
common=sorted(a&b)
(R/'interfaces.lean').write_text('import DiophantineConsistency.ArithmeticPellResidueClasses\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in common))
for kind in ['interfaces','simp','instances']:
 for phase in ['baseline','final']:probe(phase,kind)
