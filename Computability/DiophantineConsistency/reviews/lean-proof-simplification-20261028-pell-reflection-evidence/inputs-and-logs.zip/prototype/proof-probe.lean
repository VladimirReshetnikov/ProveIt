import DiophantineConsistency.ArithmeticPellResidueClasses
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticPellRecurrence
open DiophantineConsistency.ArithmeticPellPeriodicity
open DiophantineConsistency.ArithmeticPellResidueClasses
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (n m b : V) (hm : m ≤ n) :
    ycoord (n+m) b = ycoord (n-m) b + 2*xcoord n b*ycoord m b := by
  simpa only [two_mul, ← add_assoc, tsub_add_cancel_of_le hm] using reflection_add (n-m) m b
example (n m b : V) (hm : m ≤ n) :
    xcoord (n+m) b + xcoord (n-m) b = 2*xcoord n b*xcoord m b := by
  simpa only [two_mul, ← add_assoc, tsub_add_cancel_of_le hm] using x_reflection_add (n-m) m b
