import DiophantineConsistency.ArithmeticPellResidueClasses
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellPeriodicity).isPrefixOf n ||
     (`DiophantineConsistency.ArithmeticPellResidueClasses).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellPeriodicity" ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellResidueClasses" then
   logInfo m!"DECL {n}"
