from pathlib import Path
r=Path('/tmp/pell-reflection-simp');fresh=r/'refresh/DiophantineConsistency'
for phase in ['baseline','final']:
 out=r/('objects-client-'+phase)/'DiophantineConsistency';out.mkdir(parents=True,exist_ok=True)
 for p in fresh.glob('*.olean'):
  if p.stem not in ('ArithmeticPellPeriodicity','ArithmeticPellResidueClasses','ArithmeticPellHalfIndex'):(out/p.name).symlink_to(p)
 for mod in ['ArithmeticPellPeriodicity','ArithmeticPellResidueClasses']:(out/(mod+'.olean')).symlink_to(r/('objects-'+phase)/'DiophantineConsistency'/(mod+'.olean'))
s=(r/'build.py').read_text().replace("out=root/('objects-'+phase)","out=root/('objects-client-'+phase)").replace("['ArithmeticPellPeriodicity','ArithmeticPellResidueClasses','ArithmeticPellHalfIndex']","['ArithmeticPellHalfIndex']").replace("root/f'{phase}-{mod}.log'","root/f'client-{phase}-{mod}.log'").replace("root/f'{phase}-{mod}.time'","root/f'client-{phase}-{mod}.time'").replace("root/'records.json'","root/'client-records.json'")
(r/'client-replay.py').write_text(s)
