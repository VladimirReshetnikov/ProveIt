from pathlib import Path
import json,hashlib
r=Path('/tmp/pell-reflection-simp');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');all=[]
for f in ('records.json','repeat-records.json','refresh-records.json'):
 rows=json.loads((r/f).read_text())
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_sha256']==H(x['object']) and x['log_sha256']==H(x['log']);time=Path(x['command'][x['command'].index('-o')+1]);assert x['time']==time.read_text()
  if x['module'] in ('ArithmeticPellPeriodicity','ArithmeticPellResidueClasses'):
   assert x['before']==H(Path('/tmp/pell-reflection-commit-audit')/x['phase']/(x['module']+'.lean'))
  else:assert x['before']==H(repo/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';first=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==H(first)
  all.append(x);print(f,x['phase'],x['module'],len(x['direct_inputs']),'inputs verified')
for x in json.loads((r/'probe-records.json').read_text()):
 assert x['status']==0 and x['source_before']==x['source_after']==H(x['source']) and x['log_sha256']==H(x['log'])
 for d in x['objects']:assert d['before']==d['after']==H(d['path'])
 print('probe',x['phase'],x['probe'],'verified')
for n in ['interfaces','simp','instances']:
 assert (r/f'baseline-{n}.log').read_bytes()==(r/f'final-{n}.log').read_bytes();print(n,'identical')
print('builds',len(all),'input occurrences',sum(len(x['direct_inputs']) for x in all))
