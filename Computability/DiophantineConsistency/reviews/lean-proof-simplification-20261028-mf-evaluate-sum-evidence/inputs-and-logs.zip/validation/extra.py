import os,pathlib,re,subprocess,json,hashlib,time,sys
P=pathlib.Path;root=P('/tmp/kernel-eval-rewrite');overlay=root/'shared';base=P('Computability/DiophantineConsistency/Lean');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prior=json.loads((root/'graph-before.json').read_text());seen={};order=[]
def visit(m):
 if m in seen or m in prior:return
 p=base/(m.replace('.','/')+'.lean')
 if not p.exists():return
 ds=re.findall(r'^import\s+([\w.]+)',p.read_text(),re.M);seen[m]={'path':str(p),'sha256':sha(p),'imports':ds}
 for d in ds:visit(d)
 order.append((m,p))
visit('DiophantineConsistency.ArithmeticConstructionUnit');(root/'client-graph-before.json').write_text(json.dumps(seen,indent=2)+'\n');env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':/home/codex/src/Proofs/.lake/build/lib/lean:'+env.get('LEAN_PATH','');records=[]
for n,p in order[:-1]:
 out=overlay/(n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);log=root/(n+'.log');tm=root/(n+'.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(base),str(p),'-o',str(out)];t=time.monotonic()
 with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'module':n,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_before':seen[n]['sha256'],'source_after':sha(p),'log_sha256':sha(log),'time_sha256':sha(tm)}
 if out.exists():rec.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
 records.append(rec);(root/'extra-builds.json').write_text(json.dumps(records,indent=2)+'\n');print(n,v.returncode,round(rec['seconds'],2),flush=True)
 if v.returncode or rec['source_before']!=rec['source_after']:sys.exit(1)
