import os,pathlib,subprocess,json,hashlib,time,sys
P=pathlib.Path;root=P('/tmp/kernel-eval-rewrite');shared=root/'shared';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[]
for phase in ('baseline','final'):
 overlay=root/phase
 for ns in ('BusyBeaver','DiophantineConsistency'):
  for p in (shared/ns).rglob('*.olean'):
   q=overlay/p.relative_to(shared);q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(p.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':/home/codex/src/Proofs/.lake/build/lib/lean:'+env.get('LEAN_PATH','');n='ArithmeticConstructionKernel';srcroot=root/(phase+'-src');src=srcroot/'DiophantineConsistency'/(n+'.lean');obj=overlay/'DiophantineConsistency'/(n+'.olean');obj.unlink(missing_ok=True);log=root/(phase+'-target.log');tm=root/(phase+'-target.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(obj)];t=time.monotonic()
 with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 d={'phase':phase,'tag':'target','cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':sha(src),'log_sha256':sha(log),'time_sha256':sha(tm)}
 if obj.exists():d.update(object_sha256=sha(obj),object_bytes=obj.stat().st_size)
 rec.append(d);(root/'phases.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,'target',v.returncode,round(d['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
 clientroot=P('Computability/DiophantineConsistency/Lean');client=clientroot/'DiophantineConsistency/ArithmeticConstructionUnit.lean';clientobj=overlay/'DiophantineConsistency/ArithmeticConstructionUnit.olean';clientobj.unlink(missing_ok=True);log=root/(phase+'-client.log');tm=root/(phase+'-client.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(clientroot),str(client),'-o',str(clientobj)];t=time.monotonic()
 with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 d={'phase':phase,'tag':'client','cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':sha(client),'log_sha256':sha(log),'time_sha256':sha(tm)}
 if clientobj.exists():d.update(object_sha256=sha(clientobj),object_bytes=clientobj.stat().st_size)
 rec.append(d);(root/'phases.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,'client',v.returncode,round(d['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
 probe=root/(n+'-axioms.lean');log=root/(phase+'-axioms.log');cmd=['lean','-M6000','-j1','-DElab.async=false',str(probe)];t=time.monotonic()
 with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec.append({'phase':phase,'tag':'axioms','cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':sha(probe),'log_sha256':sha(log),'target_object_sha256':sha(obj)});(root/'phases.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,'axioms',v.returncode,flush=True)
 if v.returncode:sys.exit(v.returncode)
if (root/'baseline-axioms.log').read_bytes()!=(root/'final-axioms.log').read_bytes():sys.exit('axiom reports differ')
print('all 17 axiom reports match',flush=True)
