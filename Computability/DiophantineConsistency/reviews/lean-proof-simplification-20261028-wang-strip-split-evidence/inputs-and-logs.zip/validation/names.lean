import DiophantineConsistency.WangTiles942StripGeometry
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.WangTiles942StripGeometry.PersistentStrip).isPrefixOf n then
      logInfo m!"{n}"
