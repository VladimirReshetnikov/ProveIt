from pathlib import Path
import json,hashlib,os,subprocess,time,re
R=Path('/tmp/wang-strip-split-20261028');S=Path('Computability/DiophantineConsistency/Lean');old=(R/'baseline-source/DiophantineConsistency/WangTiles942StripGeometry.lean').read_text();names=re.findall(r'^(?:noncomputable\s+)?(?:theorem|def|abbrev|lemma|inductive|structure)\s+(\w+)',old,re.M);prefix='DiophantineConsistency.WangTiles942StripGeometry.';generated=(R/'names.log').read_text().splitlines();allnames=list(dict.fromkeys([prefix+n for n in names]+generated));probe=R/'axioms.lean';probe.write_text('import DiophantineConsistency.WangTiles942StripGeometry\n'+''.join('#print axioms '+n+'\n' for n in allnames));print('probing',len(allnames),'declarations',flush=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+env.get('LEAN_PATH','')
 for n in ['WangTiles942StripGeometryChecks','WangTiles942RowEncoding','WangTiles942ResetRowsChecks','axioms']:
  src=probe if n=='axioms' else S/'DiophantineConsistency'/(n+'.lean');out=None;log=R/(phase+'-'+n+'.log');tm=R/(phase+'-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(S),str(src)]
  if n!='axioms':out=R/phase/'DiophantineConsistency'/(n+'.olean');out.unlink(missing_ok=True);cmd+=['-o',str(out)]
  before=sha(src);t=time.monotonic()
  with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  v={'phase':phase,'job':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':sha(src),'log_sha256':sha(log),'timing':tm.read_text().strip()}
  if out and out.exists():v.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
  rows.append(v);(R/'check-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,q.returncode,round(v['seconds'],1),flush=True)
  if q.returncode:print(log.read_text()[:1500],flush=True);raise SystemExit(q.returncode)
assert (R/'baseline-axioms.log').read_bytes()==(R/'final-axioms.log').read_bytes(),'axioms differ'
print('public axioms identical',flush=True)
