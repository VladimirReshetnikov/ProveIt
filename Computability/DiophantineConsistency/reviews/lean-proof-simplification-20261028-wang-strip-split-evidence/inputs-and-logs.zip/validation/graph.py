from pathlib import Path
import json,hashlib,re
R=Path('/tmp/wang-strip-split-20261028');P=Path('/tmp/wang-rail-card-20261028');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean')];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();seen={};order=[]
def walk(n):
 if n in seen:return
 rel=n.replace('.','/')+'.lean';src=next((r/rel for r in roots if (r/rel).exists()),None)
 if not src:return
 if n=='DiophantineConsistency.WangTiles942StripGeometry':src=R/'baseline-source/DiophantineConsistency/WangTiles942StripGeometry.lean'
 imports=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:imports.extend(m.group(1).split())
 obj=R/'baseline'/(n.replace('.','/')+'.olean');z={'source':str(src),'source_sha256':sha(src),'imports':imports}
 if obj.exists():z.update(object=str(obj.resolve()),object_sha256=sha(obj))
 seen[n]=z
 for x in imports:walk(x)
 order.append(n)
for n in ['WangTiles942StripGeometry','WangTiles942StripGeometryChecks','WangTiles942RowEncoding','WangTiles942ResetRowsChecks']:walk('DiophantineConsistency.'+n)
candidates={}
def add(n,s,o,origin):candidates.setdefault(n,[]).append((s,o,origin))
for x in json.loads((P/'fresh-pins.json').read_text()):add(x['module'],x['source_sha256'],x['object_sha256'],'kernel receipt')
for x in json.loads((P/'fresh-prep-records.json').read_text()):add('DiophantineConsistency.'+x['module'],x['source_sha256'],x['object_sha256'],'Wang rail prerequisite build')
for x in json.loads((P/'fresh-target-records.json').read_text()):
 if x['phase']=='final':add('DiophantineConsistency.WangTiles942Language',x['source_sha256'],x['object_sha256'],'Wang rail final target')
for x in json.loads((P/'fresh-client-records.json').read_text()):
 if x['phase']=='final' and 'object_sha256' in x:add('DiophantineConsistency.'+x['job'],x['source_sha256'],x['object_sha256'],'Wang rail final client')
for x in json.loads((R/'prep-records.json').read_text()):add('DiophantineConsistency.'+x['module'],x['source_sha256'],x['object_sha256'],'new prerequisite build')
for fn in ['target-records.json','check-records.json']:
 for x in json.loads((R/fn).read_text()):
  if x['phase']=='baseline' and 'object_sha256' in x:
   n='WangTiles942StripGeometry' if x['job']=='target' else x['job'];add('DiophantineConsistency.'+n,x['source_sha256'],x['object_sha256'],'new baseline target/client')
missing=[]
for n,v in seen.items():
 matches=[o for s,h,o in candidates.get(n,[]) if s==v['source_sha256'] and h==v.get('object_sha256')];v['matching_receipts']=matches
 if not matches:missing.append(n)
(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n');print('local graph',len(seen),'unmatched',missing,flush=True)
