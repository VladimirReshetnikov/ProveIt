from pathlib import Path
import json,hashlib,os,subprocess,time
R=Path('/tmp/wang-strip-split-20261028');source=R/'common/DiophantineConsistency';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for phase in ['baseline','final']:
 d=R/phase/'DiophantineConsistency';d.mkdir(parents=True,exist_ok=True)
 for p in source.iterdir():
  if p.suffix=='.olean':
   q=d/p.name
   if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 (R/phase/'BusyBeaver').symlink_to((R/'common/BusyBeaver').resolve(),target_is_directory=True)
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+env.get('LEAN_PATH','');src=R/('baseline-source' if phase=='baseline' else 'source')/'DiophantineConsistency/WangTiles942StripGeometry.lean';out=d/'WangTiles942StripGeometry.olean';log=R/(phase+'-target.log');tm=R/(phase+'-target.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(src.parent.parent),str(src),'-o',str(out)];before=sha(src);t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 v={'phase':phase,'job':'target','command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':sha(src),'log_sha256':sha(log),'timing':tm.read_text().strip()}
 if out.exists():v.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
 rows.append(v);(R/'target-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(phase,q.returncode,round(v['seconds'],1),flush=True)
 if q.returncode or before!=sha(src):raise SystemExit(1)
