from pathlib import Path
import json,hashlib,os,subprocess,time
R=Path('/tmp/wang-strip-split-20261028');P=Path('/tmp/wang-rail-card-20261028');src=P/'final-fresh/DiophantineConsistency';D=R/'common/DiophantineConsistency';D.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in src.iterdir():
 if p.suffix=='.olean' and p.exists() and p.stem not in ['WangTiles942InitialStrip','WangTiles942SeamColumns','WangTiles942ResetRows','WangTiles942StripGeometry']:
  q=D/p.name
  if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
(R/'common/BusyBeaver').symlink_to((P/'final-fresh/BusyBeaver').resolve(),target_is_directory=True)
env=os.environ.copy();env['LEAN_PATH']=str(R/'common')+':'+env.get('LEAN_PATH','');base=Path('Computability/DiophantineConsistency/Lean');rows=[]
for n in ['WangTiles942InitialStrip','WangTiles942SeamColumns','WangTiles942ResetRows']:
 s=base/'DiophantineConsistency'/(n+'.lean');o=D/(n+'.olean');l=R/('prep-'+n+'.log');tm=R/('prep-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(base),str(s),'-o',str(o)];before=sha(s);t=time.monotonic()
 with l.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 v={'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':sha(s),'log_sha256':sha(l),'timing':tm.read_text().strip()}
 if o.exists():v.update(object_sha256=sha(o),object_bytes=o.stat().st_size)
 rows.append(v);(R/'prep-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(n,q.returncode,round(v['seconds'],1),flush=True)
 if q.returncode or before!=sha(s):raise SystemExit(1)
