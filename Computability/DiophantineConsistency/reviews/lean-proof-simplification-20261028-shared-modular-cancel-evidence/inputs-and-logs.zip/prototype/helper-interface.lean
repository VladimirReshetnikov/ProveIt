import DiophantineConsistency.ArithmeticControllerData
import DiophantineConsistency.ArithmeticCellDecoding
import DiophantineConsistency.ArithmeticPellHalfIndex
set_option pp.universes true
#check DiophantineConsistency.ArithmeticModularCancellation.add_cancel
#print axioms DiophantineConsistency.ArithmeticModularCancellation.add_cancel
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticModularCancellation).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticModularCancellation).isPrefixOf n then
      logInfo m!"HELPER {n} SIMP {t.isLemma (.decl n true false) || t.isLemma (.decl n false false) || t.isLemma (.decl n true true) || t.isLemma (.decl n false true)} INSTANCE {Lean.Meta.isInstanceCore env n}"
