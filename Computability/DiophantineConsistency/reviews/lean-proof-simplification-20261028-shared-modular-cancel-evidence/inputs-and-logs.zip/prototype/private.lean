import DiophantineConsistency.ArithmeticControllerData
import DiophantineConsistency.ArithmeticCellDecoding
import DiophantineConsistency.ArithmeticPellHalfIndex
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`_private.DiophantineConsistency.ArithmeticControllerLift).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticControllerData).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticCellDecoding).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticPellResidueClasses).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticPellHalfIndex).isPrefixOf n then
      let typ ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let axioms ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {typ} AXIOMS {axioms}"
