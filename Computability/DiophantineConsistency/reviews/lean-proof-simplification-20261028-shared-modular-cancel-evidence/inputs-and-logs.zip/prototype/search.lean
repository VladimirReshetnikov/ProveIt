import Foundation.FirstOrder.Arithmetic.HFS.PRF
import Mathlib.Tactic.Ring
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    let s := n.toString.toLower
    if ((s.splitOn "mod").length > 1 || (s.splitOn "rem").length > 1) && ((s.splitOn "cancel").length > 1 || (s.splitOn "inject").length > 1) then
      logInfo m!"{n}"
