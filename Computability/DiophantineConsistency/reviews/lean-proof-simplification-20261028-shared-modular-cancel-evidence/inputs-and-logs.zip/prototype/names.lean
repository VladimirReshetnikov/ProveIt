import DiophantineConsistency.ArithmeticControllerData
import DiophantineConsistency.ArithmeticCellDecoding
import DiophantineConsistency.ArithmeticPellHalfIndex
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticControllerLift).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticControllerLift).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticControllerData).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticControllerData).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticCellDecoding).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticCellDecoding).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellResidueClasses).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticPellResidueClasses).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellHalfIndex).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticPellHalfIndex).isPrefixOf n then
      logInfo m!"DECL {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) || t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
    if Lean.Meta.isInstanceCore env n then
      let p ← liftCoreM <| Lean.Meta.getInstancePriority? n
      logInfo m!"INSTANCE {n} {p}"
