from pathlib import Path
import json,hashlib
r=Path('/tmp/shared-modular-cancel');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior=[]
for f in ['/tmp/outer-seed-bound-sharing/prereq2-records.json','/tmp/outer-seed-bound-sharing/assembly-reused.json','/tmp/outer-seed-bound-sharing/assembly-builds2.json','/tmp/origin-block-sharing/records.json','/tmp/support-cast/refresh-records.json','/tmp/pell-balance-sharing/final-records.json']:
 for x in json.loads(Path(f).read_text()):
  if x.get('status',0)==0:
   n=x.get('module','').split('.')[-1];src=x.get('source_sha256',x.get('source_before',x.get('before')));prior.append((n,src,x.get('object_sha256'),f))
rows={};seen=set()
for x in json.loads((r/'records.json').read_text()):
 ph=x['phase'];n=x['module'];obj=r/ph/'DiophantineConsistency'/(n+'.olean');log=r/f'{ph}-{n}.log';tm=r/f'{ph}-{n}.time';assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_sha256']==h(obj) and x['log_sha256']==h(log) and x['time']==tm.read_text()
 if ph=='base' or (ph=='final' and n in ('ArithmeticControllerData','ArithmeticCellDecoding','ArithmeticPellHalfIndex')):assert x['source_before']==h(repo/(n+'.lean'))
 for name,d in x['inputs'].items():
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p.resolve())==d['object'] and d['object_before']==d['object_after']==h(p)
  if not d['source']:continue
  assert d['source_before']==d['source_after']==h(d['source']);m=name.split('.')[-1]
  if m=='ArithmeticModularCancellation':assert ph=='final' and d['object_before']==rows['probe',m]['object_sha256'] and d['source_before']==rows['probe',m]['source_before']
  elif (ph,m) in rows:assert d['object_before']==rows[ph,m]['object_sha256'];print('same-phase input',ph,n,m)
  else:
   matches=[f for mod,s,o,f in prior if (mod,s,o)==(m,d['source_before'],d['object_before'])];assert matches,(n,m,d['source_before'],d['object_before']);seen.add((m,matches[0]));print('prior exact pair',ph,n,m,matches[0])
 rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for n in ('ArithmeticControllerData','ArithmeticCellDecoding','ArithmeticPellHalfIndex'):print('client object identical?',n,rows['base',n]['object_sha256']==rows['final',n]['object_sha256'])
print('unique matched prior providers',len(seen))
for x in json.loads((r/'census-records.json').read_text()):
 ph=x['phase'];n=x['name'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['log_sha256']==h(r/f'{ph}-{n}.log') and x['time']==(r/f'{ph}-{n}.time').read_text()
 for m,v in x['inputs_before'].items():assert v==x['inputs_after'][m]==rows[(ph,m)]['object_sha256']==h(r/ph/'DiophantineConsistency'/(m+'.olean'))
 print('census',ph,n,'verified')
for n in ('interfaces','private'):assert (r/f'base-{n}.log').read_bytes()==(r/f'final-{n}.log').read_bytes();print(n,'identical')
for kind,num in [('DECL',241),('SIMP',38882),('INSTANCE',16587)]:
 def coll(p):return {line for line in p.read_text().splitlines() if line.startswith(kind+' ')}
 a=coll(r/'base-names.log');b=coll(r/'final-names.log');assert a==b and len(a)==num;print(kind,'identical entries',len(a))
s=(r/'base-interfaces.log').read_text();assert s.count('depends on axioms:')+s.count('does not depend on any axioms')==231;print('231 public/generated type/axiom reports match')
x=json.loads((r/'helper-interface-record.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(r/'helper-interface.lean') and x['log_sha256']==h(r/'helper-interface.log') and x['time']==(r/'helper-interface.time').read_text()
for m,v in x['inputs_before'].items():
 q=rows['probe' if m=='ArithmeticModularCancellation' else 'final',m];assert v==x['inputs_after'][m]==q['object_sha256']
t=(r/'helper-interface.log').read_text();assert 'HELPER DiophantineConsistency.ArithmeticModularCancellation.add_cancel SIMP false INSTANCE false' in t and 'Classical.choice' in t and 'Quot.sound' in t and 'propext' in t;print('helper type, axioms, simp/instance absence checked')
