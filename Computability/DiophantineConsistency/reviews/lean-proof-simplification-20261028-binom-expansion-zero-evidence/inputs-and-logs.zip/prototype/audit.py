from pathlib import Path
import json,hashlib,re
R=Path('/tmp/binom-expansion-zero');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
prior=[]
for f in ['/tmp/outer-seed-bound-sharing/prereq2-records.json','/tmp/pell-construction-refresh/resumed-records.json','/tmp/binom-odd-sharing/final-records.json']:
 for x in json.loads(Path(f).read_text()):
  if x.get('status')==0:prior.append((x.get('module','').split('.')[-1],x.get('source_sha256',x.get('before')),x.get('object_sha256'),f))
for ph in ['baseline','final']:
 rows[ph]=json.loads((R/(ph+'-records.json')).read_text())
 for x in rows[ph]:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-'+x['module']+'.time')).read_text()
  if ph=='baseline' or x['module']!='ArithmeticBinomExpansion':assert x['before']==h(W/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticBinomExpansion':assert d['before']==rows[ph][0]['object_sha256'] and d['resolved']==rows[ph][0]['object']
   else:
    source=h(W/(n+'.lean'));matches=[f for m,s,o,f in prior if (m,s,o)==(n,source,d['before'])];assert matches,(n,source,d['before']);print('provider',ph,n,source,d['before'],matches[0])
  print('build',ph,x['module'],x['time'].strip())
 for n in ['names','interfaces','simp','instances']:
  x=json.loads((R/f'probe-{n}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
assert rows['baseline'][1]['object_sha256']==rows['final'][1]['object_sha256'];print('client object matches',rows['baseline'][1]['object_sha256'])
def decls(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decls('baseline'),decls('final');assert len(a)==40 and len(b)==41 and all(a[k]==b[k] for k in a);print('existing declaration reports match; added',list(b.keys()-a.keys()))
for n in ['simp','instances']:
 a=(R/('baseline-'+n+'.log')).read_bytes();b=(R/('final-'+n+'.log')).read_bytes();assert a==b;print(n,len(a.splitlines()))
print('all checks passed')
