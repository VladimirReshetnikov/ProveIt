from pathlib import Path
import hashlib,json,re,difflib,subprocess
R=Path('/tmp/binom-expansion-zero');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
a=(R/'baseline/DiophantineConsistency/ArithmeticBinomExpansion.lean').read_text();b=(R/'final/DiophantineConsistency/ArithmeticBinomExpansion.lean').read_text()
old='''  case zero =>
    have h1 := bsum_succ X (n+1) 0
    have h2 := bsum_succ X n 0
    simp only [zero_add,bsum_zero,binom_zero_right,power_zero,mul_one] at h1 h2
    simp only [zero_add,bsum_zero,mul_zero,add_zero]
    rw [h1,h2]
''';old2='''  case zero =>
    have h := bsum_succ X 0 0
    simp only [zero_add,bsum_zero,binom_zero_right,power_zero,mul_one] at h
    simp [h]
'''
marker='''/-- Pascal's rule summed. -/''';helper='''private theorem bsum_one (X n : V) : bsum X n 1 = 1 := by
  simpa using bsum_succ X n 0

'''
assert a.count(old)==a.count(old2)==a.count(marker)==1
assert b==a.replace(marker,helper+marker).replace(old,'  case zero => simp [bsum_one]\n').replace(old2,'  case zero => simp [bsum_one]\n')
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticBinomExpansion.lean'
for ref,phase in [('a5beca5e0f^','baseline'),('a5beca5e0f','final')]:
 data=subprocess.check_output(['git','show',ref+':'+rel]);assert hashlib.sha256(data).hexdigest()==sha(R/phase/'DiophantineConsistency/ArithmeticBinomExpansion.lean');print('git snapshot matches',ref,phase)
assert sha(W/'ArithmeticBinomExpansion.lean')==sha(R/'final/DiophantineConsistency/ArithmeticBinomExpansion.lean')
print('exact proof-only transformation, current workspace final')
prior=[]
for name in ['/tmp/outer-seed-bound-sharing/prereq2-records.json','/tmp/pell-construction-refresh/resumed-records.json','/tmp/binom-odd-sharing/final-records.json']:
 for x in read(name):
  if x.get('status')==0:prior.append((x['module'].split('.')[-1],x.get('source_sha256',x.get('before')),x.get('object_sha256'),name))
rows={ph:read(R/(ph+'-records.json')) for ph in ['baseline','final']}
for ph in rows:
 for x in rows[ph]:
  assert x['status']==0 and x['before']==x['after']==sha(x['source']) and x['object_sha256']==sha(x['object']) and x['log_sha256']==sha(x['log'])
  assert x['time']==(R/(ph+'-'+x['module']+'.time')).read_text()
  if x['module']!='ArithmeticBinomExpansion': assert x['before']==sha(W/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   path=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file())
   assert str(path)==d['path'] and str(path.resolve())==d['resolved'] and d['before']==d['after']==sha(path)
   name=d['module'].split('.')[-1]
   if name=='ArithmeticBinomExpansion': assert d['before']==rows[ph][0]['object_sha256']
   else:
    matches=[z for z in prior if z[:3]==(name,sha(W/(name+'.lean')),d['before'])];assert matches,(ph,name);print('matched source/object prior provider',ph,name,matches[0][-1])
  print('build',ph,x['module'],x['time'].strip())
 for kind in ['names','interfaces','simp','instances']:
  x=read(R/f'probe-{kind}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==sha(x['source']) and x['object_before']==x['object_after']==sha(x['object'])==rows[ph][0]['object_sha256'] and x['log_sha256']==sha(x['log'])
assert rows['baseline'][1]['object_sha256']==rows['final'][1]['object_sha256'];print('client object equal',rows['baseline'][1]['object_sha256'])
def declarations(path):return {s.split(' TYPE ',1)[0]:s for s in re.split(r'(?m)^DECL ',Path(path).read_text()) if s.strip()}
a=declarations(R/'baseline-interfaces.log');b=declarations(R/'final-interfaces.log');added=b.keys()-a.keys();assert len(a)==40 and len(b)==41 and not (a.keys()-b.keys()) and all(a[k]==b[k] for k in a)
assert added=={'_private.DiophantineConsistency.ArithmeticBinomExpansion.0.DiophantineConsistency.ArithmeticBinomExpansion.bsum_one'};print('existing types/axioms identical, only new declaration',*added)
for kind in ['simp','instances']:
 aa=(R/('baseline-'+kind+'.log')).read_bytes();bb=(R/('final-'+kind+'.log')).read_bytes();assert aa==bb;print(kind,'identical',len(aa.splitlines()))
f=read(R/'failed-simp/final-records.json')[0];assert f['status']!=0 and f['before']==f['after']==sha(R/'failed-simp/source.lean') and f['log_sha256']==sha(R/'failed-simp/final-ArithmeticBinomExpansion.log') and f['time']==(R/'failed-simp/final-ArithmeticBinomExpansion.time').read_text();print('failed first source and log match receipt; historical recorded paths reused')
print('PASS')
