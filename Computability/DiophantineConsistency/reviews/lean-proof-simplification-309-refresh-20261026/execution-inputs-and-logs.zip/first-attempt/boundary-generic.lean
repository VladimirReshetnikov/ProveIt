import DiophantineConsistency.WangTiles942Boundary

namespace DiophantineConsistency.BoundaryFibersChecks
open WangTiles942 WangTiles942Language WangTiles942Boundary

example {t : Tile} (ht : Allowed t) (c : ℕ) (hc : 439 ≤ c) : t.north ≠ c := by
  intro hn
  have h := (high_north_fiber ht c (by omega)).mp hn
  rcases h with ⟨he,_⟩ | ⟨he,_⟩ | ⟨he,_⟩ | ⟨he,_⟩ | ⟨he,_⟩ <;> omega

example {t : Tile} (ht : Allowed t) (c : ℕ) (hc : 439 ≤ c) : t.south ≠ c := by
  intro hs
  have h := (high_south_fiber ht c (by omega)).mp hs
  rcases h with ⟨he,_⟩ | ⟨he,_⟩ | ⟨he,_⟩
  · omega
  · simp only [List.mem_cons, List.not_mem_nil, or_false] at he
    omega
  · omega

-- A real low-colour copy tile shows why the high-colour guard is necessary.
example : Allowed (⟨0,0,0,0⟩ : Tile) ∧
    (⟨0,0,0,0⟩ : Tile).north = 0 ∧ ¬ (434 ≤ (0 : ℕ)) :=
  ⟨.pass 0 0,rfl,by decide⟩

#print axioms high_north_fiber
#print axioms high_south_fiber
end DiophantineConsistency.BoundaryFibersChecks
