from pathlib import Path
import hashlib,json,os,re,subprocess,time
E=Path(__file__).resolve().parent.parent;P=Path('/tmp/positive-shift-sharing/source-pinned');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();version=subprocess.check_output(['lake','env','lean','--version'],text=True).strip();records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(P/phase)+':'+base
 for probe in ['object-names','object-interfaces','combined-names']:
  src=E/'scripts'/(probe+'.lean');log=E/'logs'/(phase+'-'+probe+'-rerun.log');tm=E/'logs'/(phase+'-'+probe+'-rerun.time');imports=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M);deps=[]
  for n in imports:
   paths=[Path(d)/(n.replace('.','/')+'.olean') for d in env['LEAN_PATH'].split(':')];p=next((x for x in paths if x.is_file()),None)
   if not p:raise RuntimeError('missing direct import '+n)
   deps.append({'module':n,'visible_path':str(p),'resolved_path':str(p.resolve()),'sha256_before':sha(p)})
  cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=sha(src);t=time.monotonic()
  with log.open('wb') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for dep in deps:dep['sha256_after']=sha(dep['visible_path'])
  rec={'phase':phase,'probe':probe,'status':proc.returncode,'command':cmd,'lean_version':version,'lean_path':env['LEAN_PATH'],'source_path':str(src),'source_sha256_before':before,'source_sha256_after':sha(src),'direct_inputs':deps,'log_path':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,3)};records.append(rec);(E/'records/rerun-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,probe,rec['status'],rec['time'].strip(),flush=True)
  assert proc.returncode==(1 if probe=='combined-names' else 0);assert before==rec['source_sha256_after'];assert all(x['sha256_before']==x['sha256_after'] for x in deps)
  if probe=='combined-names':assert 'environment already contains' in log.read_text() and 'Matrix.map' in log.read_text()
a=lambda phase:{l for l in (E/'logs'/(phase+'-object-names-rerun.log')).read_text().splitlines() if l.startswith('DECL ')}
assert a('baseline')==a('final') and len(a('baseline'))==29
assert (E/'logs/baseline-object-interfaces-rerun.log').read_bytes()==(E/'logs/final-object-interfaces-rerun.log').read_bytes()
print('29 object names and all corresponding type/axiom reports agree; both combined imports reproduce the error')
