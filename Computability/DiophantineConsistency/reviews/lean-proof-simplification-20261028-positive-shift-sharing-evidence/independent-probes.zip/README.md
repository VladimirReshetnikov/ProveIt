# Independent positive-shift review and import probes

28 October 2026. `review.txt` is the independent review of the four-source
positive-shift proof-sharing candidate. `sources/baseline` and `sources/final`
contain the reviewed source snapshots; all eight match the source hashes in
the earlier pinned build receipts. No repository files were changed for this
review or evidence package.

## Fresh probe receipts

`scripts/rerun.py` reruns the original object-only namespace census and the
`#check`/`#print axioms` probe against both pinned phase overlays. Both
object-only probes completed successfully. Each phase exposes the same 29
ObjectCurrentEquation2011 namespace declarations, and the two complete
interface/axiom reports are byte-identical.

The combined-import probe intentionally imports the full arithmetic soundness,
arithmetic sentence, object equation and arithmetic equation modules. In both
phases it failed before elaboration with the same error: importing
`Mathlib.LinearAlgebra.Matrix.Defs` encountered `Matrix.map` already supplied
by `Foundation.Vorspiel.Matrix`. The matching baseline and final failures show
that this conflict is present in the particular recorded pinned overlays; they
are not successful validation, and they do not establish that every possible
provider environment has the same conflict. Object-only and arithmetic checks
must be understood separately in this evidence.

`records/rerun-records.json` records the exact command, Lean version,
`LEAN_PATH`, return status, probe source hashes before/after, the first visible
object path and before/after object hashes for each syntactic direct import,
log hashes, elapsed time and memory. In the failed combined probe, these
objects are resolved import candidates; because Lean aborts early, the record
does not assert that every listed import was actually loaded. Fresh raw logs
and time files are under `logs/`. Original earlier logs are preserved there
with their original names, but the original interactive invocations did not
record complete commands/statuses/input hashes; the fresh reruns provide those
receipts. `scripts/empty-interfaces-after-combined-failure.lean` records the
empty probe generated after the original failed namespace census. It did not
check any declaration and is not validation.

## Earlier replay and limits

`records/prior/` and `logs/prior/` retain the relevant pinned and source-clean
receipts and logs described in the review. The first source-clean object build
failed in both phases due to a missing transitive `PellHalf90.olean`; after a
provider setup change the separately recorded object/check/client retries
succeeded. Window and HA stability receipts also report paired successes.
The direct-input pin audit records three cached object prerequisites without
matching source/object receipts: `CurrentPolynomialWindow2011`,
`ObjectNaturalDiscrete`, and `WeightedExpressionDegree`. Their matching
before/after object hashes do not prove they were freshly built from the saved
source. Neither the prior replay nor these probes establish a fresh build of
the whole transitive dependency closure. Probe and replay scripts retain the
original absolute paths and require those overlays and Lean environment.
Compiled objects are not included.

`manifest.sha256` covers every other file in this package.
