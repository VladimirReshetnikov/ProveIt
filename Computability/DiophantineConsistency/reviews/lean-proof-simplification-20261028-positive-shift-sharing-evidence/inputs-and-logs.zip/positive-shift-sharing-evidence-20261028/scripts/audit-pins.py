from pathlib import Path
import json,hashlib
P=Path('/tmp/positive-shift-sharing/source-pinned'); sourcefiles=['/tmp/pell-construction-refresh/local-pins.json','/tmp/pell-construction-refresh/records.json','/tmp/pell-construction-refresh/resumed-records.json','/tmp/pell-construction-refresh/rotation-records.json','/tmp/construction-share/bound-refresh-records.json','/tmp/construction-share/bound-borrowed-pins.json','/tmp/construction-share/refresh-records.json','/tmp/construction-share/corrected-RankForcing-record.json','/tmp/pell-share/paired-records.json'];known={}
def put(n,s,o,p):
 if n and s and o:
  if '.' not in n:n='DiophantineConsistency.'+n
  known.setdefault((n,s,o),[]).append(p)
for f in sourcefiles:
 try:x=json.loads(Path(f).read_text())
 except (FileNotFoundError,ValueError):continue
 if isinstance(x,dict):x=x.get('pins',[x])
 for y in x:
  n=y.get('module');s=y.get('source_sha256');put(n,s,y.get('object_sha256'),f);put(n,s,y.get('baseline_sha256'),f);put(n,s,y.get('final_sha256'),f)
rs=[]
for f in ['records.json','records2.json','records-object.json']:
 if (P/f).exists():rs+=json.loads((P/f).read_text())
for z in rs:put('DiophantineConsistency.'+z['module'],z['source_sha256_before'],z['object_sha256'],'current:'+z['phase']+':'+z['module'])
rows=[]
for z in rs:
 for d in z['direct_inputs']:
  if d.get('missing'):continue
  matches=known.get((d['module'],d.get('source_sha256'),d['sha256_before']),[])
  own=[v for (n,s,o),v in known.items() if n==d['module'] and o==d['sha256_before'] and any(x.startswith('current:'+z['phase']+':') for x in v)]
  rows.append({'phase':z['phase'],'client':z['module'],'module':d['module'],'source_sha256':d.get('source_sha256'),'object_sha256':d['sha256_before'],'matches':matches,'fresh_same_phase':bool(own),'source_still_matches':bool(d.get('source_path')) and Path(d['source_path']).is_file() and hashlib.sha256(Path(d['source_path']).read_bytes()).hexdigest()==d['source_sha256']})
P.joinpath('input-pin-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
print('inputs',len(rows),'fresh same phase',sum(x['fresh_same_phase'] for x in rows),'source/object prior receipt',sum(bool(x['matches']) for x in rows));print('unmatched external inputs:')
for x in rows:
 if not x['fresh_same_phase'] and not x['matches']:print(x['phase'],x['client'],x['module'],str(x['source_sha256'])[:12],x['object_sha256'][:12])
