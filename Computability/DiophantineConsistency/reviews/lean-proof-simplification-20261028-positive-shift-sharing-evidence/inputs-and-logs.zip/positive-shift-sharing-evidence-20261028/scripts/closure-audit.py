import json,hashlib
from pathlib import Path
root=Path('Computability/DiophantineConsistency/Lean');overlay=Path('/tmp/positive-shift-sharing/source-pinned/baseline');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();todo=['DiophantineConsistency.ArithmeticConstructionAssembly'];seen={}
while todo:
 n=todo.pop()
 if n in seen:continue
 s=root/(n.replace('.','/')+'.lean');o=overlay/(n.replace('.','/')+'.olean')
 if not s.is_file():continue
 seen[n]={'source':h(s),'object':h(o) if o.exists() else None,'path':str(o.resolve()) if o.exists() else None,'matches':[]}
 for l in s.read_text().splitlines():
  if l.startswith('import '):todo.extend(m for m in l.split()[1:] if m.startswith('DiophantineConsistency.'))
files=[]
for d in Path('/tmp').iterdir():
 if not d.is_dir() or not any(x in d.name for x in ('share','refresh','construction','pell','mask','physical')):continue
 try:files.extend(d.glob('*.json'))
 except PermissionError:pass

def walk(x,p):
 if isinstance(x,list):
  for v in x:walk(v,p)
 elif isinstance(x,dict):
  n=x.get('module');s=x.get('source_sha256') or x.get('source_sha256_before');objs=[x.get(k) for k in ('object_sha256','baseline_sha256','final_sha256')]
  if isinstance(n,str):
   if '.' not in n:n='DiophantineConsistency.'+n
   if n in seen and s==seen[n]['source'] and seen[n]['object'] in objs:seen[n]['matches'].append(str(p))
  for v in x.values():
   if isinstance(v,(list,dict)):walk(v,p)
for p in files:
 try:walk(json.loads(p.read_text()),p)
 except (ValueError,PermissionError,OSError,UnicodeDecodeError):continue
out=Path('/tmp/positive-shift-sharing/source-pinned/assembly-closure-audit.json');out.write_text(json.dumps(seen,indent=2)+'\n');no=[(n,x['source'][:12],str(x['object'])[:12],x['path']) for n,x in seen.items() if not x['matches']];print('nodes',len(seen),'matching prior receipts',len(seen)-len(no),'unmatched',len(no));print('\n'.join(map(str,no)))
