import os,json,hashlib,subprocess,time
from pathlib import Path
p=Path('/tmp/positive-shift-sharing/source-pinned');root=p/'common-sources';root.mkdir(exist_ok=True);s=root/'DiophantineConsistency';s.mkdir(exist_ok=True);src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticConstructionVariation.lean');target=s/src.name;target.write_bytes(src.read_bytes());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip(); env=os.environ.copy();env['LEAN_PATH']=str(p/'baseline')+':'+base
inputs=[]
for line in target.read_text().splitlines():
 if line.startswith('import '):
  for m in line.split()[1:]:
   f=next(Path(x)/(m.replace('.','/')+'.olean') for x in env['LEAN_PATH'].split(':') if (Path(x)/(m.replace('.','/')+'.olean')).is_file()); source=Path('Computability/DiophantineConsistency/Lean')/(m.replace('.','/')+'.lean'); inputs.append({'module':m,'path':str(f),'resolved':str(f.resolve()),'object_sha256_before':h(f),'source_path':str(source),'source_sha256_before':h(source) if source.exists() else None})
out=p/'common/DiophantineConsistency/ArithmeticConstructionVariation.olean';out.parent.mkdir(parents=True,exist_ok=True);tm=p/'common-variation.time';log=p/'common-variation.log'; cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(target),'-o',str(out)]; before=h(target);t=time.monotonic()
with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
for x in inputs:x['object_sha256_after']=h(x['path']);x['source_sha256_after']=h(x['source_path']) if Path(x['source_path']).exists() else None
rec={'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(target),'source_sha256_before':before,'source_sha256_after':h(target),'workspace_source_sha256_before':before,'workspace_source_sha256_after':h(src),'inputs':inputs,'object':str(out),'object_sha256':h(out) if out.exists() else None,'log':str(log),'log_sha256':h(log),'time':tm.read_text()};(p/'common-variation-record.json').write_text(json.dumps(rec,indent=2)+'\n');print('variation',r.returncode,round(rec['elapsed'],1),flush=True)
