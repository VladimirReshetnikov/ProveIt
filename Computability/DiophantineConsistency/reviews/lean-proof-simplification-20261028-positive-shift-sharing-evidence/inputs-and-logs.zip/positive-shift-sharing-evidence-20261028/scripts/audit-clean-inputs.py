import json,hashlib
from pathlib import Path
p=Path('/tmp/positive-shift-sharing/source-clean');prov=json.load(open('/tmp/positive-shift-sharing/transport-receipts/provider-audit.json'));rs=[]
for f in ['records.json','window-baseline-records.json','window-final-records.json','object-retry-baseline.json','object-retry-final.json','stability-records.json']:
 if (p/f).exists():rs+=json.load(open(p/f))
known={}
for x in prov:
 if x['source_recorded']==x['source_current'] and x['object_recorded']==x['object_current'] and all(d['recorded']==d['actual'] for d in x['direct']):known.setdefault((x['module'],x['source_current'],x['object_current']),[]).append(x['receipt'])
for f in ['/tmp/construction-share/bound-refresh-records.json','/tmp/pell-construction-refresh/rotation-records.json','/tmp/pell-construction-refresh/records.json','/tmp/pell-construction-refresh/resumed-records.json']:
 try: data=json.load(open(f))
 except (FileNotFoundError,ValueError):continue
 for x in data:
  n=x.get('module'); source=x.get('source_sha256'); obj=x.get('object_sha256')
  if n and source and obj and x.get('status',0)==0:
   if '.' not in n:n='DiophantineConsistency.'+n
   known.setdefault((n,source,obj),[]).append(f)
for x in rs:
 if x['status']==0:known.setdefault(('DiophantineConsistency.'+x['module'],x['source_sha256_before'],x['object_sha256']),[]).append('fresh:'+x['phase'])
rows=[]
for x in rs:
 if x['status']!=0:continue
 for d in x['direct_inputs']:
  if d.get('missing'):continue
  n=d['module'];obj=d['sha256_before'];source=d.get('source_sha256');match=known.get((n,source,obj),[]);fresh=[zz for (nn,ss,oo),zz in known.items() if n==nn and obj==oo and ('fresh:'+x['phase']) in zz];rows.append({'phase':x['phase'],'client':x['module'],'module':n,'source_sha256':source,'object_sha256_before':obj,'object_sha256_after':d['sha256_after'],'provider_match':match,'fresh_same_phase':bool(fresh),'path':d['resolved']})
p.joinpath('direct-input-pin-audit.json').write_text(json.dumps(rows,indent=2)+'\n');un=[r for r in rows if not r['provider_match'] and not r['fresh_same_phase']];print('direct inputs',len(rows),'fresh',sum(r['fresh_same_phase'] for r in rows),'provider matched',sum(bool(r['provider_match']) for r in rows),'unmatched',len(un));print('\n'.join(f"{r['phase']} {r['client']} {r['module']} {r['object_sha256_before'][:12]}" for r in un))
