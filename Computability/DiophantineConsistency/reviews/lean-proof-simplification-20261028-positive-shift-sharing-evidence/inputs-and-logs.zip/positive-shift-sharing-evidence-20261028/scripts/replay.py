from pathlib import Path
import os, subprocess,hashlib,json,time,shutil
P=Path('/tmp/positive-shift-sharing'); repo=Path.cwd()/'Computability/DiophantineConsistency/Lean'; src=repo/'DiophantineConsistency';root=P/'source-pinned';root.mkdir(exist_ok=True); sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip()
names=['CurrentEquationSyntax2011','FoundationHACurrentNoZero2011','ArithmeticCurrentSentence2011','ArithmeticCarrierSoundness2011','ArithmeticCarrierSoundness2011Checks','ArithmeticCarrierRadix2011','ArithmeticConstructionZero','ArithmeticCurrentConstruction2011','ArithmeticConstructionBound']
modified={'CurrentEquationSyntax2011','ArithmeticCurrentSentence2011','ArithmeticCarrierSoundness2011'}; records=[]
for phase in ['baseline','final']:
 ov=root/phase;ss=root/(phase+'-sources')/'DiophantineConsistency';ss.mkdir(parents=True,exist_ok=True)
 if not ov.exists():subprocess.run(['cp','-as',str(P/phase),str(ov)],check=True)
 for n in names:
  f=(P/'src/DiophantineConsistency'/f'{n}.lean') if phase=='final' and n in modified else src/f'{n}.lean'
  shutil.copyfile(f,ss/f'{n}.lean')
 env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base; paths=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 for n in names:
  source=ss/f'{n}.lean'; imports=[i for l in source.read_text().splitlines() if l.startswith('import ') for i in l.split()[1:]]; inputs=[]
  for i in imports:
   x=next((r/(i.replace('.','/')+'.olean') for r in paths if (r/(i.replace('.','/')+'.olean')).is_file()),None)
   if x is None: inputs.append({'module':i,'missing':True});continue
   local=src/(i.removeprefix('DiophantineConsistency.')+'.lean') if i.startswith('DiophantineConsistency.') else None
   inputs.append({'module':i,'path':str(x),'resolved':str(x.resolve()),'sha256_before':sha(x),'source_path':str(local) if local and local.exists() else None,'source_sha256':sha(local) if local and local.exists() else None})
  out=ov/'DiophantineConsistency'/f'{n}.olean';out.unlink(missing_ok=True);log=root/f'{phase}-{n}.log';tm=root/f'{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(ss.parent),str(source),'-o',str(out)];source_before=sha(source);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for i in inputs:
   if not i.get('missing'):i['sha256_after']=sha(i['path'])
  z={'phase':phase,'module':n,'status':r.returncode,'elapsed':time.monotonic()-t,'source':str(source),'source_sha256_before':source_before,'source_sha256_after':sha(source),'lean_path':env['LEAN_PATH'],'command':cmd,'direct_inputs':inputs,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'object':str(out),'object_sha256':sha(out) if out.exists() else None};records.append(z);(root/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,round(z['elapsed'],1),flush=True)
  if r.returncode or source_before!=sha(source) or any(i.get('missing') or i['sha256_before']!=i['sha256_after'] for i in inputs):print('STOP',flush=True);break
