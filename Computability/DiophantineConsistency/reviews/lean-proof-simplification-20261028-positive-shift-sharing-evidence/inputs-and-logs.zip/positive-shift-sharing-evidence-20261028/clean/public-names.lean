import DiophantineConsistency.ArithmeticCarrierSoundness2011
import DiophantineConsistency.ArithmeticCurrentSentence2011
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticCarrierSoundness2011).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticCurrentSentence2011).isPrefixOf n then
      logInfo m!"DECL {n}"
