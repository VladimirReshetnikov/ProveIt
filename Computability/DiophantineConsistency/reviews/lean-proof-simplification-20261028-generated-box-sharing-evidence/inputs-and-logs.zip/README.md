# Shared generated-kernel box proof: isolated evidence

28 October 2026. The candidate keeps the existing private SplitKernelData59
box_facts proof, exports the same proposition through the explicitly typed
port_box_facts theorem, and has the three GapKernelData66 coefficient bounds
call that theorem. Gap already imported Split. No imports, coefficient data,
positions, numerical bounds or existing theorem statements change. Two
candidate generators are included: the Split generator emits the public alias;
the Gap generator no longer copies a private proof by string slicing. The two
Lean modules shrink by 11 net lines. Generated wrappers remain byte-identical.
This archive preserves an isolated candidate, not a repository commit.

## Regeneration and proof checks

`records/generator-records.json`, the logs and generator-check.py document a
successful Split regeneration and Gap --check, including before/after hashes
for the 14 recorded generator scripts, JSON inputs and Lean outputs. The Gap
check covers both GapKernelData66 and GapKernels66. Both SplitKernels59 and
GapKernels66 wrapper sources were unchanged. The proof source, the generators,
support scripts, six JSON inputs and the candidate patch are included.

`records/common-records.json` describes successful current-source builds of
SelectiveCarry, SelectiveCoefficientBounds, PolynomialRangeBounds and
SplitWordBounds, in that order. `records/coherent-build-records.json` records
four successful baseline/final SplitKernelData59 and GapKernelData66 builds;
`records/coherent-client-{early,gap,final-split,final-gap}-records.json` records
both paired wrapper replays. All report status zero. The two pairs of wrapper
logs are byte-identical. These receipts include exact commands, LEAN_PATH,
source hashes, direct-input hashes before/after, and object/log hashes.
`records/archive-preaudit.json` summarizes a fresh check of all 12 successful
build/replay receipts, 24 direct-input occurrences, eight coherent probes and
two generator runs. Object files are not included.

An earlier baseline SplitKernels59 client failed because its inherited cached
SelectiveCarry object lacked encoded_degree_le. This is retained in
`records/client-records.json` and `logs/baseline-client-SplitKernels59.log`;
it is not counted among successful clients. The coherent chain rebuilt that
prerequisite and its dependents before the successful paired wrapper replays.
The earlier non-coherent target builds and probe logs are also retained as
historical results, not as the refreshed-provider comparison.

## Interfaces and limits

The coherent forced-equation census contains 93 baseline versus 88 final
names: one new public SplitKernelData59.port_box_facts, and removal of the
private Gap box_facts and its five generated proof auxiliaries. All 81 common
public declarations have byte-identical type/axiom reports, and the forced
sparseKernel and D0/D1/D2 definition equations match. Global simp declaration
membership/flags (55,118) and instance/priority entries (23,324) match as sets.
The independent review and separate private-name/type/axiom probes are in
`independent/`. The added public visibility and removed private names are real
environment changes. The global probes do not enumerate every persistent
Lean environment extension.

The coherent chain and target/client builds still reuse cached upstream
objects and installed libraries. In particular GapGeometry66 has no matching
current-source/object receipt established by this experiment; SelectiveCarry's
upstream imports and other transitive objects are also inherited. The
SplitGeometry59 source/object pair matches the earlier fresh receipt included
in `provenance/`. This is not a clean full source-closure build or a replay of
all downstream clients. Scripts and recorded paths reference the original
machine and temporary overlays, and this package is not standalone replay.

`manifest.sha256` covers all files except itself.
