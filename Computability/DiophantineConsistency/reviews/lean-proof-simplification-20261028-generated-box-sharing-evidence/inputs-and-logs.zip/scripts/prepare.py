from pathlib import Path
import shutil
R=Path('/dev/shm/shared-box-prototype');orig=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=Path('/tmp/word-origin-sharing/final')
for phase in ['baseline','final']:
 out=R/phase;out.mkdir(exist_ok=True)
 for f in base.iterdir():
  if f.name=='DiophantineConsistency':
   d=out/f.name;d.mkdir(exist_ok=True)
   for g in f.iterdir():
    p=d/g.name
    if not p.exists():p.symlink_to(g)
  elif not (out/f.name).exists():(out/f.name).symlink_to(f)
 for n in ['SplitKernelData59','GapKernelData66']:
  p=out/'DiophantineConsistency'/f'{n}.olean';p.unlink(missing_ok=True)
source=R/'baseline-source/DiophantineConsistency';source.mkdir(parents=True,exist_ok=True)
for n in ['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66']:(source/f'{n}.lean').write_bytes((orig/f'{n}.lean').read_bytes())
