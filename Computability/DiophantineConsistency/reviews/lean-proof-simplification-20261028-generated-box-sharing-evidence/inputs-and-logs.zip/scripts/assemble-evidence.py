from pathlib import Path
import tempfile,shutil,hashlib,json,difflib,zipfile
R=Path('/dev/shm/shared-box-prototype');W=Path.cwd()/'Computability/DiophantineConsistency';zpath=Path('/tmp/shared-box-generated-kernel-evidence-20261028.zip')
if zpath.exists():raise SystemExit('archive already exists')
stage=Path(tempfile.mkdtemp(prefix='shared-box-evidence-'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(src,dst):
 src=Path(src);p=stage/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
def text(dst,s):
 p=stage/dst;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
for glob,sub in [('*.log','logs'),('*.time','logs'),('*.json','records'),('*.py','scripts'),('*.lean','scripts')]:
 for p in R.glob(glob):put(p,f'{sub}/{p.name}')
for phase,src in [('baseline',R/'baseline-source/DiophantineConsistency'),('final',R/'Lean/DiophantineConsistency')]:
 for n in ['SplitKernelData59','GapKernelData66']:put(src/f'{n}.lean',f'sources/{phase}/{n}.lean')
for name in ['SelectiveCarry','SelectiveCoefficientBounds','PolynomialRangeBounds','SplitWordBounds','SplitKernels59','GapKernels66','SplitGeometry59','GapGeometry66']:
 put(W/f'Lean/DiophantineConsistency/{name}.lean',f'sources/clients/{name}.lean')
for name in ['generate_split_kernels59.py','generate_gap_kernels66.py']:
 put(W/'tools'/name,f'generators/baseline/{name}');put(R/'tools'/name,f'generators/final/{name}')
for name in ['generate_split_certificate59.py','generate_gap_certificate66.py']:
 put(R/'tools'/name,f'generators/support/{name}')
for p in (R/'data/split59').glob('*.json'):put(p,'data/split59/'+p.name)
for p in (R/'candidates/gap2082-compact54/data/H2082').glob('*.json'):put(p,'data/H2082/'+p.name)
for p in ['shared-box-independent-review.txt','shared-box-private-audit.lean','shared-box-private-baseline.log','shared-box-private-final.log','shared-box-private-audit-records.json','shared-box-helper.log']:
 put('/tmp/'+p,'independent/'+p)
put('/tmp/list-getd-sharing-20261028/fresh-records.json','provenance/list-getd-fresh-records.json')
put('/tmp/list-getd-sharing-20261028/fresh-SplitGeometry59.log','provenance/fresh-SplitGeometry59.log')
patch=[]
for section,n in [('sources','SplitKernelData59.lean'),('sources','GapKernelData66.lean'),('generators','generate_split_kernels59.py'),('generators','generate_gap_kernels66.py')]:
 a=(stage/section/'baseline'/n).read_text().splitlines(keepends=True);b=(stage/section/'final'/n).read_text().splitlines(keepends=True);patch.extend(difflib.unified_diff(a,b,fromfile=f'{section}/baseline/{n}',tofile=f'{section}/final/{n}'))
text('candidate.patch',''.join(patch))
text('README.md','''# Shared generated-kernel box proof: isolated evidence

28 October 2026. The candidate keeps the existing private SplitKernelData59
box_facts proof, exports the same proposition through the explicitly typed
port_box_facts theorem, and has the three GapKernelData66 coefficient bounds
call that theorem. Gap already imported Split. No imports, coefficient data,
positions, numerical bounds or existing theorem statements change. Two
candidate generators are included: the Split generator emits the public alias;
the Gap generator no longer copies a private proof by string slicing. The two
Lean modules shrink by 11 net lines. Generated wrappers remain byte-identical.
This archive preserves an isolated candidate, not a repository commit.

## Regeneration and proof checks

`records/generator-records.json`, the logs and generator-check.py document a
successful Split regeneration and Gap --check, including before/after hashes
for the 14 recorded generator scripts, JSON inputs and Lean outputs. The Gap
check covers both GapKernelData66 and GapKernels66. Both SplitKernels59 and
GapKernels66 wrapper sources were unchanged. The proof source, the generators,
support scripts, six JSON inputs and the candidate patch are included.

`records/common-records.json` describes successful current-source builds of
SelectiveCarry, SelectiveCoefficientBounds, PolynomialRangeBounds and
SplitWordBounds, in that order. `records/coherent-build-records.json` records
four successful baseline/final SplitKernelData59 and GapKernelData66 builds;
`records/coherent-client-{early,gap,final-split,final-gap}-records.json` records
both paired wrapper replays. All report status zero. The two pairs of wrapper
logs are byte-identical. These receipts include exact commands, LEAN_PATH,
source hashes, direct-input hashes before/after, and object/log hashes.
`records/archive-preaudit.json` summarizes a fresh check of all 12 successful
build/replay receipts, 24 direct-input occurrences, eight coherent probes and
two generator runs. Object files are not included.

An earlier baseline SplitKernels59 client failed because its inherited cached
SelectiveCarry object lacked encoded_degree_le. This is retained in
`records/client-records.json` and `logs/baseline-client-SplitKernels59.log`;
it is not counted among successful clients. The coherent chain rebuilt that
prerequisite and its dependents before the successful paired wrapper replays.
The earlier non-coherent target builds and probe logs are also retained as
historical results, not as the refreshed-provider comparison.

## Interfaces and limits

The coherent forced-equation census contains 93 baseline versus 88 final
names: one new public SplitKernelData59.port_box_facts, and removal of the
private Gap box_facts and its five generated proof auxiliaries. All 81 common
public declarations have byte-identical type/axiom reports, and the forced
sparseKernel and D0/D1/D2 definition equations match. Global simp declaration
membership/flags (55,118) and instance/priority entries (23,324) match as sets.
The independent review and separate private-name/type/axiom probes are in
`independent/`. The added public visibility and removed private names are real
environment changes. The global probes do not enumerate every persistent
Lean environment extension.

The coherent chain and target/client builds still reuse cached upstream
objects and installed libraries. In particular GapGeometry66 has no matching
current-source/object receipt established by this experiment; SelectiveCarry's
upstream imports and other transitive objects are also inherited. The
SplitGeometry59 source/object pair matches the earlier fresh receipt included
in `provenance/`. This is not a clean full source-closure build or a replay of
all downstream clients. Scripts and recorded paths reference the original
machine and temporary overlays, and this package is not standalone replay.

`manifest.sha256` covers all files except itself.
''')
manifest=''.join(f'{sha(p)}  {p.relative_to(stage).as_posix()}\n' for p in sorted(stage.rglob('*')) if p.is_file());text('manifest.sha256',manifest)
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(stage).as_posix())
print('stage',stage,'archive',zpath,'files',sum(1 for p in stage.rglob('*') if p.is_file()),'sha256',sha(zpath))
