theorem foo (n : Nat) : n = n := rfl
def bar := foo
abbrev baz := foo
#check bar
#check baz
