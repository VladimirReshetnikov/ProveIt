from pathlib import Path
import os,subprocess,hashlib,json,time,re
R=Path('/dev/shm/shared-box-prototype');root=Path('Computability/DiophantineConsistency/Lean');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/('coherent-'+phase))+':'+base
 for name in ['SplitKernels59','GapKernels66']:
  src=root/'DiophantineConsistency'/f'{name}.lean';log=R/f'coherent-{phase}-client-{name}.log';tm=R/f'coherent-{phase}-client-{name}.time';deps=[]
  for n in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
   rel=n.replace('.','/')+'.olean';d=next((Path(q,rel) for q in env['LEAN_PATH'].split(':') if Path(q,rel).is_file()),None)
   if not d:raise RuntimeError('missing import '+n)
   deps.append({'module':n,'path':str(d),'resolved':str(d.resolve()),'before':sha(d)})
  before=sha(src);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src)];t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in deps:x['after']=sha(x['path'])
  rec={'phase':phase,'module':name,'status':r.returncode,'source':str(src),'before':before,'after':sha(src),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(rec);(R/'coherent-client-final-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,r.returncode,rec['time'].strip(),flush=True)
  if r.returncode or before!=rec['after'] or any(x['before']!=x['after'] for x in deps):raise SystemExit(1)
