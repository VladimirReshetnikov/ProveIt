from pathlib import Path
R=Path('/dev/shm/shared-box-prototype');src=R/'baseline';dst=R/'coherent-common';dst.mkdir(exist_ok=True)
for f in src.iterdir():
 if f.name=='DiophantineConsistency':
  d=dst/f.name;d.mkdir(exist_ok=True)
  for g in f.iterdir():
   p=d/g.name
   if not p.exists():p.symlink_to(g)
 elif not (dst/f.name).exists():(dst/f.name).symlink_to(f)
for n in ['SelectiveCarry','SelectiveCoefficientBounds','PolynomialRangeBounds','SplitWordBounds']:(dst/'DiophantineConsistency'/f'{n}.olean').unlink(missing_ok=True)
