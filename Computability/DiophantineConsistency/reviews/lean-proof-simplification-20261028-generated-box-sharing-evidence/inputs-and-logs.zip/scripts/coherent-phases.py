from pathlib import Path
R=Path('/dev/shm/shared-box-prototype');src=R/'coherent-common'
for phase in ['baseline','final']:
 out=R/('coherent-'+phase);out.mkdir(exist_ok=True)
 for f in src.iterdir():
  if f.name=='DiophantineConsistency':
   d=out/f.name;d.mkdir(exist_ok=True)
   for g in f.iterdir():
    p=d/g.name
    if not p.exists():p.symlink_to(g)
  elif not (out/f.name).exists():(out/f.name).symlink_to(f)
 for n in ['SplitKernelData59','GapKernelData66']:(out/'DiophantineConsistency'/f'{n}.olean').unlink(missing_ok=True)
