from pathlib import Path
import hashlib,json,re
R=Path('/dev/shm/shared-box-prototype');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();fs=['common-records.json','coherent-build-records.json']+[f'coherent-client-{n}-records.json' for n in ['early','gap','final-split','final-gap']];bad=[];count=0;deps=0
for file in fs:
 for x in json.loads((R/file).read_text()):
  count+=1;src=Path(x['source']);obj=Path(x['object']) if x.get('object') else None;log=Path(x['log'])
  if x['status']!=0 or not src.exists() or sha(src)!=x['after'] or x['before']!=x['after']:bad.append((file,x['module'],'source/status'))
  if obj and (not obj.exists() or sha(obj)!=x['object_sha256']):bad.append((file,x['module'],'object'))
  if not log.exists() or sha(log)!=x['log_sha256']:bad.append((file,x['module'],'log'))
  imports=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M)
  if sorted(imports)!=sorted(d['module'] for d in x['direct_inputs']):bad.append((file,x['module'],'imports'))
  for d in x['direct_inputs']:
   deps+=1;p=Path(d['path']);hits=[Path(q,d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if Path(q,d['module'].replace('.','/')+'.olean').is_file()]
   if not p.exists() or d['before']!=d['after'] or sha(p)!=d['after'] or p.resolve()!=Path(d['resolved']) or not hits or hits[0].resolve()!=p.resolve():bad.append((file,x['module'],d['module']))
pr=json.loads((R/'coherent-probe-records.json').read_text())
for x in pr:
 if x['status'] or sha(x['source'])!=x['source_after'] or x['source_before']!=x['source_after'] or x['objects_before']!=x['objects_after'] or sha(x['log'])!=x['log_sha256']:bad.append(('probe',x['phase'],x['probe']))
g=json.loads((R/'generator-records.json').read_text())
if g['before']!=g['after'] or any(sha(p)!=h for p,h in g['after'].items()):bad.append(('generator','source/data'))
if any(x['status'] or sha(x['log'])!=x['log_sha256'] for x in g['records']):bad.append(('generator','log/status'))
print('builds',count,'direct input occurrences',deps,'probes',len(pr),'generator runs',len(g['records']),'bad',bad)
(R/'archive-preaudit.json').write_text(json.dumps({'builds':count,'direct_input_occurrences':deps,'probes':len(pr),'generator_runs':len(g['records']),'bad':bad},indent=2)+'\n')
if bad:raise SystemExit(1)
