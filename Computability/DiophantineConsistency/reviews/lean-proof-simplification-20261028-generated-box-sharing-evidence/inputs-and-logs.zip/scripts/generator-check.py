from pathlib import Path
import subprocess,hashlib,json,sys
R=Path('/dev/shm/shared-box-prototype');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[R/'tools'/x for x in ['generate_split_kernels59.py','generate_split_certificate59.py','generate_gap_kernels66.py','generate_gap_certificate66.py']];files+=list((R/'data/split59').glob('*.json'));files+=list((R/'candidates/gap2082-compact54/data/H2082').glob('*.json'));files += [R/'Lean/DiophantineConsistency'/x for x in ['SplitKernelData59.lean','GapKernelData66.lean','GapKernels66.lean','SplitKernels59.lean']]
before={str(p):sha(p) for p in files};records=[]
for name,args in [('split',[]),('gap',['--check'])]:
 script=R/'tools'/('generate_split_kernels59.py' if name=='split' else 'generate_gap_kernels66.py');cmd=[sys.executable,str(script),*args];r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=R/f'generator-{name}.log';log.write_bytes(r.stdout);records.append({'cmd':cmd,'status':r.returncode,'log':str(log),'log_sha256':sha(log)});print(name,r.returncode,r.stdout.decode().strip(),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
after={str(p):sha(p) for p in files};result={'before':before,'after':after,'records':records};(R/'generator-records.json').write_text(json.dumps(result,indent=2)+'\n');print('all source/data/generated hashes unchanged:',before==after)
if before!=after:raise SystemExit(1)
