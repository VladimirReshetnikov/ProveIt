from pathlib import Path
import hashlib,json,re,subprocess,sys,time
OUT=Path('/tmp/south-shift-20261028')
MODE=sys.argv[1]
ROOT='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
plan=json.loads(Path('/tmp/south-shift-refresh-plan.json').read_text())
protected=json.loads(Path('/tmp/south-shift-bootstrap-updated-closure.json').read_text())
source=ROOT+'CurrentSouthShift2011.lean'

def rec(p):
    p=Path(p);b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def guard(expected_source):
    for p,h in protected['files'].items():
        if p==source:h=expected_source
        assert rec(p)['sha256']==h,('changed checked source',p)
    assert subprocess.check_output(['git','-C','.lake/packages/mathlib','rev-parse','HEAD'],text=True).strip()==protected['mathlib_head']
    assert not subprocess.check_output(['git','-C','.lake/packages/mathlib','status','--porcelain','--untracked-files=no'],text=True).strip()
    for p,h in json.loads((OUT/'reused-fresh-object-pins.json').read_text()).items():
        assert rec(p)['sha256']==h,('changed validated object',p)
old=json.loads((OUT/'baseline-source.json').read_text())['sha256']
now=rec(source)['sha256']
if MODE in ['prereq-r1','baseline']:assert now==old
if MODE=='final':assert now!=old
guard(now)
if MODE=='prereq-r1':
    exclude={'CurrentSouthShift2011','CurrentSouthShift2011Checks','CurrentWholeField2011','CurrentMaskData2011','CurrentKernelData2011'}
    names=[Path(p).stem for p in plan['remaining_after_B'] if Path(p).stem not in exclude]
    assert len(names)==22
    steps=[(n,ROOT+n+'.lean',n) for n in names]
elif MODE=='baseline':
    steps=[('original-target',source,'CurrentSouthShift2011'),('baseline-axioms',str(OUT/'old-public-axioms.lean'),None)]
elif MODE=='final':
    steps=[('final-target',source,'CurrentSouthShift2011'),('client-CurrentWholeField2011',ROOT+'CurrentWholeField2011.lean','CurrentWholeField2011'),('focus-CurrentSouthShift2011Checks',ROOT+'CurrentSouthShift2011Checks.lean',None),('final-axioms',str(OUT/'old-public-axioms.lean'),None)]
else:raise SystemExit('invalid mode')
state={'mode':MODE,'records':[],'complete':False,'checked_source_sha256':now,'source_pins_guarded':len(protected['files'])}
statepath=OUT/(MODE+'-commands.json');assert not statepath.exists();statepath.write_text(json.dumps(state,indent=2)+'\n')
for name,p,output in steps:
    expected=rec(p)
    cmd=['lake','env','lean','-M6000','-j1','-DElab.async=false',p]
    if output:cmd+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+output+'.olean']
    log=OUT/(MODE+'-'+name+'.log');timing=OUT/(MODE+'-'+name+'.time')
    started=time.monotonic()
    with log.open('wb') as stream:
        proc=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(timing),*cmd],stdout=stream,stderr=subprocess.STDOUT)
    assert rec(p)==expected
    row={'tag':name,'argv':cmd,'source':expected,'actual_exit_status':proc.returncode,'elapsed_monotonic_seconds':time.monotonic()-started,'log':rec(log),'timing':rec(timing)}
    if output and proc.returncode==0:row['object']=rec(cmd[-1])
    state['records'].append(row);statepath.write_text(json.dumps(state,indent=2)+'\n')
    print(MODE,name,'actualexit',proc.returncode,flush=True)
    if proc.returncode:raise SystemExit(proc.returncode)
guard(now)
state['complete']=True
if MODE=='final':
    a=(OUT/'baseline-baseline-axioms.log').read_bytes()
    b=(OUT/'final-final-axioms.log').read_bytes()
    state['old_public_report_stdout_identical']=a==b
statepath.write_text(json.dumps(state,indent=2)+'\n')
print(MODE,'PASS',len(steps),'source pins and mathlib unchanged',flush=True)
