import os,subprocess,time,hashlib,json
from pathlib import Path
root=Path('/tmp/generated-live-shared');proj=Path('Computability/DiophantineConsistency/Lean');source=proj/'DiophantineConsistency/SplitJointPower59.lean';records=[]
for phase in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
 cmd=['lean','-M9000','-j1','-DElab.async=false','-R',str(proj),str(source)]
 log=root/f'{phase}-client-SplitJointPower59-replay.log';timing=root/f'{phase}-client-SplitJointPower59-replay.time';start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(timing)]+cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'cmd':cmd,'status':r.returncode,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'time':timing.read_text()}
 records.append(rec);(root/'joint-replay-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,'joint replay',r.returncode,flush=True)
 if r.returncode:break
