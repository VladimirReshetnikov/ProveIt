import os,subprocess,time,hashlib,json,sys
from pathlib import Path
root=Path('/tmp/generated-live-shared');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','');proj=Path('Computability/DiophantineConsistency/Lean');out=root/phase/'DiophantineConsistency'
modules=[]
clients=[]
for n in modules:
 p=out/(n+'.olean')
 if p.is_symlink():p.unlink()
calls=[]
for n in modules: calls.append(('module-'+n,proj/'DiophantineConsistency'/(n+'.lean'),out/(n+'.olean')))
for n in clients: calls.append(('client-'+n,proj/'DiophantineConsistency'/(n+'.lean'),None))
for n in ('ArithmeticDAG','ArithmeticDAGSemantics','ArithmeticDAGPowers','GapCircuit66','SplitCircuit59','SplitJointCircuit59'):
 calls.append(('focus-'+n,proj/'checks'/(n+'.lean'),None))
calls.append(('axioms',root/'axioms.lean',None))
if phase=='final':calls.append(('new-helper',root/'new-helper.lean',None))
records=[]
for label,path,obj in calls:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(proj),str(path)]
 if obj is not None:cmd+=['-o',str(obj)]
 log=root/f'{phase}-{label}.log';timing=root/f'{phase}-{label}.time';start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(timing)]+cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'label':label,'cmd':cmd,'status':r.returncode,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'time':timing.read_text()}
 if obj is not None and obj.exists():rec.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
 records.append(rec);(root/f'{phase}-focus-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
