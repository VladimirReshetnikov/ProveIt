import os,subprocess,time,hashlib,json,sys
from pathlib import Path
root=Path('/tmp/generated-live-shared');phase=sys.argv[1]
env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
source=root/('baseline-source' if phase=='baseline' else 'source')
mods=['ArithmeticDAG','GapCircuit66','SplitCircuit59','SplitJointCircuit59']
records=[]
for n in mods:
 path=source/'DiophantineConsistency'/f'{n}.lean';out=root/phase/'DiophantineConsistency'/f'{n}.olean';log=root/f'{phase}-{n}.log';timing=root/f'{phase}-{n}.time'
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(source),str(path),'-o',str(out)]
 start=time.monotonic()
 with log.open('wb') as f: p=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(timing)]+cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 r={'module':n,'cmd':cmd,'status':p.returncode,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'time':timing.read_text()}
 if out.exists():r.update(object_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),object_bytes=out.stat().st_size)
 records.append(r);(root/f'{phase}-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
