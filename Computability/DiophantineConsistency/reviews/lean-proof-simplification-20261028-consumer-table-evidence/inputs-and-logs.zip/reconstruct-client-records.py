import hashlib,json,re
from pathlib import Path
root=Path('/tmp/generated-live-shared'); proj=Path('Computability/DiophantineConsistency/Lean')
for phase in ('baseline','final'):
 out=root/phase/'DiophantineConsistency';records=[]
 for kind,n in [('module','ArithmeticDAGSemantics'),('module','ArithmeticDAGPowers'),('client','GapCircuitSteps66'),('client','SplitCircuitSteps59'),('client','SplitJointPower59')]:
  label=kind+'-'+n; source=proj/'DiophantineConsistency'/(n+'.lean');log=root/f'{phase}-{label}.log';timing=root/f'{phase}-{label}.time';t=timing.read_text();m=re.search(r'Command exited with non-zero status (\d+)',t)
  cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(proj),str(source)]
  if kind=='module':cmd+=['-o',str(out/(n+'.olean'))]
  rec={'label':label,'cmd_reconstructed':cmd,'status_inferred_from_gnu_time':int(m.group(1)) if m else 0,'source_sha256_current':hashlib.sha256(source.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'timing':t}
  if kind=='module':
   obj=out/(n+'.olean');rec['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest();rec['object_bytes']=obj.stat().st_size
  records.append(rec)
 (root/f'{phase}-client-records-reconstructed.json').write_text(json.dumps({'limitation':'Original per-call status records were overwritten by the focus driver. Commands were reconstructed from the retained driver; statuses are inferred from GNU time files, not contemporaneous JSON. Source hashes are current, not captured at original run.', 'records':records},indent=2)+'\n')
