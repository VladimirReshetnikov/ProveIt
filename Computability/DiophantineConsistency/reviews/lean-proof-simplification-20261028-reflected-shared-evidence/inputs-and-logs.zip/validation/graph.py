from pathlib import Path
import re,hashlib,json
R=Path('/tmp/reflected-shared-20261028'); root=Path('Computability/DiophantineConsistency/Lean');overlay=R/'overlay';names=['ArithmeticCellPhysical','ArithmeticCellLocal','CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011']; seen={};order=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def go(name):
 if name in seen:return
 src=root/(name.replace('.','/')+'.lean')
 if not src.is_file():return
 s=src.read_text();im=[]
 for line in s.splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:im.extend(m.group(1).split())
 local=[v for v in im if v.startswith('DiophantineConsistency.') and (root/(v.replace('.','/')+'.lean')).is_file()]
 seen[name]={'source':str(src),'source_sha256':sha(src),'imports':im,'local_imports':local}
 for v in local:go(v)
 obj=overlay/(name.replace('.','/')+'.olean')
 if obj.exists():seen[name].update(object=str(obj.resolve()),object_sha256=sha(obj.resolve()),object_mtime=obj.stat().st_mtime,source_mtime=src.stat().st_mtime)
 order.append(name)
for n in names:go('DiophantineConsistency.'+n)
(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n')
print('local nodes',len(seen),'with object',sum('object' in x for x in seen.values()),'source newer',sum(x.get('source_mtime',0)>x.get('object_mtime',0) for x in seen.values() if 'object' in x))
for n,x in seen.items():
 if 'object' not in x: print('missing:',n)
