from pathlib import Path
import shutil,re
R=Path('/tmp/reflected-shared-20261028'); root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');out=R/'source/DiophantineConsistency';base=R/'baseline/DiophantineConsistency';out.mkdir(parents=True,exist_ok=True);base.mkdir(parents=True,exist_ok=True)
names=['ArithmeticCellPhysical','ArithmeticCellLocal','CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011']
for n in names:
 s=(root/(n+'.lean')).read_text(); (base/(n+'.lean')).write_text(s)
 if n=='ArithmeticCellPhysical':
  probe=(R/'probe.lean').read_text(); helper=probe[probe.index('theorem reflected_split'):probe.index('\nend Test')]; pos=s.index('\ntheorem selector_source_injective'); s=s[:pos]+'\n\n'+helper+'\n'+s[pos:]
 else:
  old='private def controlCoefficient : Entry → ℕ\n  | .inl _ => 0\n  | .inr e => 2 * weight (.inr e)\n\n'; assert s.count(old)==1,n;s=s.replace(old,'')
  start=s.index('theorem control_reflection_le'); body=s.index(':= by\n',start)+len(':= by\n'); end=s.index('\ntheorem refl_lt',body) if n=='ArithmeticCellLocal' else s.index('\n/-- The selector premise',body) if n.startswith('MF') else s.index('\n/-- The selector premise',body)
  new=('  apply ArithmeticCellPhysical.reflected_control_le hh\n  intro e\n  exact H.bool _ (by have := source_le hh e; omega)\n') if n=='ArithmeticCellLocal' else '  exact ArithmeticCellPhysical.reflected_control_le hh _ (fun e => hc _)\n'
  s=s[:body]+new+s[end:]
  start=s.index('  have he :\n',s.index('theorem refl_lt') if n=='ArithmeticCellLocal' else s.index('theorem reflected_lt')); end=s.index('  rw [he]\n',start)+len('  rw [he]\n'); s=s[:start]+'  rw [ArithmeticCellPhysical.reflected_split h]\n'+s[end:]
 (out/(n+'.lean')).write_text(s)
overlay=R/'overlay/DiophantineConsistency';overlay.mkdir(parents=True,exist_ok=True)
for p in (Path('/tmp/list-getd-sharing-20261028/cell-fresh/DiophantineConsistency')).iterdir():
 d=overlay/p.name
 if not d.exists() and not d.is_symlink():d.symlink_to(p.resolve())
for n in names:
 (overlay/(n+'.olean')).unlink(missing_ok=True)
print('candidate sources created')
