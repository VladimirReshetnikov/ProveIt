from pathlib import Path
import json,hashlib,subprocess,os,time
R=Path('/tmp/reflected-shared-20261028');dst=R/'common/DiophantineConsistency';dst.mkdir(parents=True,exist_ok=True);src=R/'overlay/DiophantineConsistency';hs=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in src.iterdir():
 if p.suffix=='.olean':
  d=dst/p.name
  if not d.exists() and not d.is_symlink():d.symlink_to(p.resolve())
records=json.loads(Path('/tmp/list-getd-sharing-20261028/fresh-records.json').read_text());nodes=json.loads((R/'graph.json').read_text())['nodes'];borrow=[]
for x in records:
 n=x['module'];
 if n not in nodes:continue
 name=n.rsplit('.',1)[1];obj=Path('/tmp/list-getd-sharing-20261028/normal-fresh/DiophantineConsistency')/(name+'.olean');source=Path(nodes[n]['source']);assert hs(obj)==x['object_sha256'] and hs(source)==x['source_sha256'],n
 p=dst/(name+'.olean');p.unlink(missing_ok=True);p.symlink_to(obj.resolve());borrow.append({'module':n,'source_sha256':hs(source),'object_sha256':hs(obj),'object':str(obj.resolve())})
(R/'borrowed-refresh.json').write_text(json.dumps(borrow,indent=2)+'\n');print('borrowed authenticated fresh objects:',len(borrow),flush=True)
env=os.environ.copy();env['LEAN_PATH']=str(R/'common')+':'+env.get('LEAN_PATH','');recs=[];root=Path('Computability/DiophantineConsistency/Lean')
for n in ['NativeWindowCarry','CurrentKernel2011','MFCurrentKernel2011']:
 p=dst/(n+'.olean');p.unlink(missing_ok=True);source=root/'DiophantineConsistency'/(n+'.lean');log=R/('fresh-'+n+'.log');tm=R/('fresh-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(root),str(source),'-o',str(p)];before=hs(source);start=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'source_after':hs(source),'log_sha256':hs(log),'timing':tm.read_text().strip(),'object_sha256':hs(p) if p.exists() else None};recs.append(rec);(R/'fresh-records.json').write_text(json.dumps(recs,indent=2)+'\n');print(n,q.returncode,round(rec['seconds'],1),flush=True)
 if q.returncode or rec['source_after']!=before:raise SystemExit(1)
