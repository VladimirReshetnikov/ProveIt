from pathlib import Path
import subprocess,time,json,hashlib
p=Path('/tmp/rephase-rotation-20261028');source=p/'oldsrc/DiophantineConsistency/CurrentWordRephase2011.lean';items=[('target',str(source),True),('axioms',str(p/'axioms.lean'),False)];records=[]
for name,file,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',file]
 if obj:argv+=['-R',str(p/'oldsrc'),'-o',str(p/'overlay/DiophantineConsistency/CurrentWordRephase2011.olean')]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/rephase-rotation-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv];start=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-start;log=p/('borrowed-baseline-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 record={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'source':file,'source_sha256':hashlib.sha256(Path(file).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:record['object']=argv[-1];record['object_sha256']=hashlib.sha256(Path(argv[-1]).read_bytes()).hexdigest()
 records.append(record);(p/'borrowed-baseline-results.json').write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
