from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/pell-first-positive');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticPellFirstNorm.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticPellFirstNorm.lean').read_text()
start=b.index('  rcases le_one_iff_eq_zero_or_one.mp hle with hz|ho\n');end=b.index('\ntheorem norm_advance_iff',start)
old=b[start:end]; assert old.startswith('''  rcases le_one_iff_eq_zero_or_one.mp hle with hz|ho
  · rw [hz] at hk
    exact (_root_.lt_irrefl (0:V)) hk
  · subst k
''')
remaining=old.split('  · subst k\n',1)[1]; remaining='\n'.join(line[2:] if line.startswith('  ') else line for line in remaining.split('\n'))
new='  have ho : k=1 := le_antisymm hle (pos_iff_one_le.mp hk)\n  subst k\n'+remaining
assert b[:start]+new+b[end:]==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellFirstNorm.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('541e94df32^')==b and gitfile('541e94df32')==f and (W/'ArithmeticPellFirstNorm.lean').read_text()==f
print('PASS exact zero-branch removal and commit/parent snapshots, workspace matches final')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticPellFirstNorm$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(s).stem for s in clients)==['ArithmeticPellFirstIndex','ArithmeticPellFirstNormChecks'],clients
print('PASS two scoped direct Lean clients',clients)
prior={}
for path in ['/tmp/pell-balance-sharing/final-clients-records.json','/tmp/pell-balance-sharing/final-combined-records.json']:
 for x in read(path):
  if x['module'] in ('ArithmeticPellCongruences','ArithmeticPellKnownUnit','ArithmeticPellHalfIndex'):
   assert x['status']==0 and x['before']==x['after']==h(W/(x['module']+'.lean')) and x['object_sha256']==h(x['object']);prior[x['module']]=x
assert len(prior)==3
chain=read('/tmp/pell-balance-sharing/final-combined-records.json')
half=next(x for x in chain if x['module']=='ArithmeticPellHalfIndex');res=next(x for x in chain if x['module']=='ArithmeticPellResidueClasses');d=next(x for x in half['direct_inputs'] if x['module'].endswith('.ArithmeticPellResidueClasses'))
assert d['before']==d['after']==res['object_sha256']=='110e85d1f8b280b9f6a52735e46ebf7450c12d7e7f270052d413cdefd57bc002' and res['before']==res['after']=='5c70f7f78028f1ae5cb3a897fe1817ecec0b6cbdb96f00cd9fc469bf567158eb' and h(W/'ArithmeticPellResidueClasses.lean')=='a0a54a63e7f7614a0bd08b43c65c49258f25e9f88accec379ee25eef86fba597'
assert h(W/'ArithmeticPellPowerRecovery.lean')==h('/tmp/pell-recovery-order/final/DiophantineConsistency/ArithmeticPellPowerRecovery.lean')
print('PASS historical HalfIndex old ResidueClasses source/object boundary; combined source matches adopted workspace')
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticPellFirstNorm','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex'}
 for x in rows+[read(R/f'{phase}-combined-record.json')]:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']);assert Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  mod=x['module']
  if mod=='ArithmeticPellPowerRecovery':assert x['before']==h('/tmp/pell-recovery-order/final/DiophantineConsistency/ArithmeticPellPowerRecovery.lean')
  elif mod!='ArithmeticPellFirstNorm':assert x['before']==h(W/(mod+'.lean'))
  for d in x['direct_inputs']:
   first=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file())
   assert first==Path(d['path']) and first.resolve()==Path(d['resolved']) and d['before']==d['after']==h(first)
   dm=d['module'].split('.')[-1]
   if dm in rec[phase]:assert d['before']==rec[phase][dm]['object_sha256']
   else:assert d['before']==prior[dm]['object_sha256']
  print('PASS',phase,mod,x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
assert read(R/'baseline-combined-record.json')['object_sha256']==read(R/'final-combined-record.json')['object_sha256']
for phase in ('baseline','final'):
 for x in read(R/f'{phase}-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticPellFirstNorm']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for name in ('names','interfaces','simp','instances'):assert (R/f'baseline-{name}.log').read_bytes()==(R/f'final-{name}.log').read_bytes()
print('PASS two clients and combined PowerRecovery are byte-identical across phases; target census logs match')
print('LIMIT cached transitive project/Foundation/Mathlib closure and no replay of downstream PowerRecovery clients with combined FirstNorm change')
