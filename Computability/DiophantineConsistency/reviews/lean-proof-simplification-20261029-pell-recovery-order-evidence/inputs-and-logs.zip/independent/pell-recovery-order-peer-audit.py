from pathlib import Path
import re,hashlib,json,subprocess
R=Path('/tmp/pell-recovery-order');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticPellPowerRecovery.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticPellPowerRecovery.lean').read_text()
old='''private theorem one_le_of_pos {x : V} (h : 0<x) : 1≤x := by
  simpa using lt_iff_succ_le.mp h

private theorem add_le_right {x y : V} (h : x≤y) (z : V) : x+z≤y+z :=
  _root_.add_le_add h (le_refl z)

'''
assert b.count(old)==1
x=b.replace(old,'').replace('one_le_of_pos ht','pos_iff_one_le.mp ht').replace('one_le_of_pos hJ','pos_iff_one_le.mp hJ').replace('one_le_of_pos hw','pos_iff_one_le.mp hw').replace('one_le_of_pos hs','pos_iff_one_le.mp hs').replace('add_le_right','add_le_add_left')
assert x==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellPowerRecovery.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('dab24627b9^')==b and gitfile('dab24627b9')==f and (W/'ArithmeticPellPowerRecovery.lean').read_text()==f
print('PASS exact substitutions and commit/parent snapshots; workspace matches final')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticPellPowerRecovery$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines()
expected=['ArithmeticCarrierRadix2011','ArithmeticHalfBinomialSandwich','ArithmeticPellPowerRecoveryChecks']
assert sorted(Path(s).stem for s in clients)==expected,clients
print('PASS three module-directory direct clients',clients)
prior=read('/tmp/pell-construction-refresh/resumed-records.json');fi=next(x for x in prior if x['phase']=='final' and x['module'].endswith('.ArithmeticPellFirstIndex'))
assert fi['status']==0 and fi['source_sha256']==fi['source_after']==h(W/'ArithmeticPellFirstIndex.lean') and fi['object_sha256']==h(fi['object']) and fi['log_sha256']==h(fi['log']) and fi['time_sha256']==h(fi['time'])
records=read('/tmp/positive-shift-sharing/source-clean/records.json');cs=next(x for x in records if x['phase']=='final' and x['module']=='ArithmeticCarrierSoundness2011');assert cs['status']==0 and cs['source_sha256_before']==cs['source_sha256_after']==h(W/'ArithmeticCarrierSoundness2011.lean') and cs['object_sha256']==h(cs['object'])
cr=next(x for x in records if x['phase']=='final' and x['module']=='ArithmeticCarrierRadix2011');ra=next(d for d in cr['direct_inputs'] if d['module'].endswith('.ArithmeticRadixAlignment'))
print('RA KEYS',list(ra))
po=next(x for x in read('/tmp/outer-seed-bound-sharing/prereq-records.json') if x['module'].endswith('.ArithmeticPow'));assert po['status']==0 and po['source_sha256']==po['source_after']==h(W/'ArithmeticPow.lean')
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');refresh=read(R/f'{phase}-refreshed-carrier-records.json');assert len(refresh)==1
 rows=[x for x in rows if x['module']!='ArithmeticCarrierRadix2011']+refresh;rec[phase]={x['module']:x for x in rows};assert set(rec[phase])==set(expected+['ArithmeticPellPowerRecovery'])
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log'])
  assert Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticPellPowerRecovery':assert x['before']==h(W/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   first=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file())
   assert first==Path(d['path']) and first.resolve()==Path(d['resolved']) and d['before']==d['after']==h(first)
   mod=d['module'].split('.')[-1]
   if mod=='ArithmeticPellPowerRecovery':assert d['before']==rec[phase]['ArithmeticPellPowerRecovery']['object_sha256']
   elif mod=='ArithmeticPellFirstIndex':assert d['before']==fi['object_sha256']
   elif mod=='ArithmeticCarrierSoundness2011':assert d['before']==cs['object_sha256']
   elif mod=='ArithmeticRadixAlignment':assert d['before']==ra['sha256_before']==ra['sha256_after'] and ra['source_sha256']==h(W/'ArithmeticRadixAlignment.lean')
   elif mod=='ArithmeticPow':assert d['before']==po['object_sha256']
   else:raise AssertionError(mod)
  print('PASS',phase,x['module'],x['time'].strip())
for name in expected:assert rec['baseline'][name]['object_sha256']==rec['final'][name]['object_sha256']
print('PASS direct provider receipt hashes and all three identical client objects')
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticPellPowerRecovery']['object_sha256'] and x['log_sha256']==h(x['log'])
 if n in ('simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
def blocks(p):
 s=Path(p).read_text();return {t.split(' TYPE ',1)[0]:'DECL '+t for t in re.split(r'(?m)^DECL ',s)[1:]}
a=blocks(R/'baseline-interfaces.log');z=blocks(R/'final-interfaces.log');removed=set(a)-set(z);assert len(removed)==2 and {x.rsplit('.',1)[-1] for x in removed}=={'one_le_of_pos','add_le_right'} and not(set(z)-set(a))
assert all(a[n]==z[n] for n in z)
print('PASS',len(z),'common declaration/type/axiom blocks; removed',sorted(removed))
for n in ('simp','instances'):assert all(removed_name not in (R/f'baseline-{n}.log').read_text() for removed_name in removed)
print('PASS removed private names are absent in default simp and instances')
print('LIMIT transitive project/Foundation/Mathlib closure cached; separate FirstNorm candidate not part of this replay')
