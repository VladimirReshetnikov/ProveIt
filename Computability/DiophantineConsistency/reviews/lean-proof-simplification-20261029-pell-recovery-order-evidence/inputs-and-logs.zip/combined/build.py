from pathlib import Path
import os,json,hashlib,subprocess,sys
r=Path('/tmp/pell-first-positive');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');common=r/'common';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ph=sys.argv[1];env=os.environ.copy();lib=r/('objects-'+ph);lib.mkdir(exist_ok=True)
if not (lib/'DiophantineConsistency').exists():subprocess.run(['cp','-as',str(common/'DiophantineConsistency'),str(lib/'DiophantineConsistency')],check=True)
for n in ('ArithmeticPellFirstNorm','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex'):(lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True)
s=r/ph/'DiophantineConsistency';s.mkdir(parents=True,exist_ok=True)
if ph=='baseline':(s/'ArithmeticPellFirstNorm.lean').write_bytes((w/'ArithmeticPellFirstNorm.lean').read_bytes())
for n in ('ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex'):(s/(n+'.lean')).write_bytes((w/(n+'.lean')).read_bytes())
jobs=[('ArithmeticPellFirstNorm',['ArithmeticPellCongruences','ArithmeticPellKnownUnit']),('ArithmeticPellFirstNormChecks',['ArithmeticPellFirstNorm']),('ArithmeticPellFirstIndex',['ArithmeticPellHalfIndex','ArithmeticPellFirstNorm'])];env['LEAN_PATH']=str(lib)+':/tmp/mask-ins-simplify/final:'+env['LEAN_PATH'];rows=[]
for n,imports in jobs:
 src=s/(n+'.lean');inputs=[]
 for name in imports:
  rel='DiophantineConsistency/'+name+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());inputs.append({'module':'DiophantineConsistency.'+name,'path':str(p),'resolved':str(p.resolve()),'before':h(p)})
 obj=lib/'DiophantineConsistency'/(n+'.olean');tm=r/(ph+'-'+n+'.time');log=r/(ph+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/ph),str(src),'-o',str(obj)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path'])
 rec={'phase':ph,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None};rows.append(rec);(r/(ph+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(ph,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
