import Lean.Elab.Command
import DiophantineConsistency.ArithmeticPellFirstNorm
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellFirstNorm).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNorm" then
   logInfo m!"DECL {n}"
