from pathlib import Path
import json,hashlib
r=Path('/tmp/pell-first-positive');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());rows={};providers={}
for name,file in [('ArithmeticPellCongruences','/tmp/pell-balance-sharing/final-clients-records.json'),('ArithmeticPellKnownUnit','/tmp/pell-balance-sharing/final-clients-records.json'),('ArithmeticPellHalfIndex','/tmp/pell-balance-sharing/final-combined-records.json')]:
 x=next(x for x in json.loads(Path(file).read_text()) if x['module']==name);p=r/'common/DiophantineConsistency'/(name+'.olean');assert x['status']==0 and x['before']==x['after']==h(w/(name+'.lean')) and x['object_sha256']==h(p);providers[name]=x['object_sha256'];print('prior current source/object producer',name,providers[name])
for ph in ('baseline','final'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n!='ArithmeticPellFirstNorm' or ph=='baseline':assert x['before']==h(w/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);name=d['module'].split('.')[-1]
   if name in providers:assert d['before']==providers[name]
   elif name=='ArithmeticPellFirstNorm':assert d['before']==rows[ph,name]['object_sha256'] and d['resolved']==rows[ph,name]['object']
   else:raise Exception(name)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
 for x in get(ph+'-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticPellFirstNorm']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
 x=get(ph+'-combined-record.json');assert x['status']==0 and x['before']==x['after']==h(x['source'])==h('/tmp/pell-recovery-order/final/DiophantineConsistency/ArithmeticPellPowerRecovery.lean') and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-combined-PowerRecovery.time').read_text();d=x['direct_inputs'][0];p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)==rows[ph,'ArithmeticPellFirstIndex']['object_sha256'] and d['resolved']==rows[ph,'ArithmeticPellFirstIndex']['object'];rows[ph,'ArithmeticPellPowerRecovery']=x;print('combined',ph,x['time'].strip())
for n in ('ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex','ArithmeticPellPowerRecovery'):assert rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'];print('client object identical',n)
for n in ('names','interfaces','simp','instances'):
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b;print(n,len(a.splitlines()),'identical')
assert (r/'baseline-names.log').read_text().count('DECL ')==18
old=next(x for x in json.loads(Path('/tmp/pell-balance-sharing/final-combined-records.json').read_text()) if x['module']=='ArithmeticPellResidueClasses');half=next(x for x in json.loads(Path('/tmp/pell-balance-sharing/final-combined-records.json').read_text()) if x['module']=='ArithmeticPellHalfIndex');d=next(x for x in half['direct_inputs'] if x['module'].endswith('.ArithmeticPellResidueClasses'));assert old['before']==old['after']=='5c70f7f78028f1ae5cb3a897fe1817ecec0b6cbdb96f00cd9fc469bf567158eb' and old['object_sha256']==d['before']==d['after']=='110e85d1f8b280b9f6a52735e46ebf7450c12d7e7f270052d413cdefd57bc002' and old['before']!=h(w/'ArithmeticPellResidueClasses.lean');print('prior HalfIndex producer used pre-modular PellResidueClasses; closure cached')
import subprocess
p=hashlib.sha256(subprocess.check_output(['git','show','dab24627b9:Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellPowerRecovery.lean'])).hexdigest();assert p==h(w/'ArithmeticPellPowerRecovery.lean')==rows['baseline','ArithmeticPellPowerRecovery']['before']==rows['final','ArithmeticPellPowerRecovery']['before'];print('combined PowerRecovery source matches adopted dab24627b9 and workspace')
