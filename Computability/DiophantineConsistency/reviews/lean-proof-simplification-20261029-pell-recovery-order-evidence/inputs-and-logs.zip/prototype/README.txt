Pell power-recovery order wrappers: isolated prototype

Baseline ArithmeticPellPowerRecovery SHA-256 a1df92e4dc70697747d4b8e5355b141aa9d544ac9df873cafc7a757de641f562;
final SHA-256 dd9a12a8ff1811d974e0df2e5a98d78d702041a6a0e779bdfd2425375f818a7b.
The proof substitutes the existing pos_iff_one_le.mp and add_le_add_left for
two private wrappers at their call sites, removing the wrappers. The statements,
guards, imports, definitions and data remain unchanged. Original module commit
2340b0c06b does not contain a Co-Authored-By trailer; no Claude authorship is
claimed for this source. Net deletion is six lines, with call-site substitutions.

baseline/final-records.json document paired target and all three direct source
clients (PellPowerRecoveryChecks, CarrierRadix2011 and HalfBinomialSandwich),
including source, direct input and output object hashes, logs and timings.
The target's FirstIndex provider matches the current-source final build in
/tmp/pell-construction-refresh/resumed-records.json (63a4634a…); Pow matches
/tmp/outer-seed-bound-sharing/prereq-records.json; CarrierSoundness matches
its current-source final build in /tmp/positive-shift-sharing/source-clean/
records.json (573197…); RadixAlignment matches a source/object input sample in
the CarrierRadix final row of that same record. These direct-provider matches
and the paired outputs are verified by audit.py/.log; direct source hashes were
matched against these prior receipts, rather than freshly sampled at build time.
This is not a full current-source transitive closure rebuild.

The first paired CarrierRadix replays used an old CarrierSoundness e0f98a…
(source b529… instead of current 06dd…); those otherwise successful runs are
superseded and retained under superseded/ with their old client objects, logs,
timings, and full original phase receipts. Only the client was replayed after
switching to the current-source provider; baseline/final-records.json combine
the original target/other clients with each new CarrierRadix receipt. The
separate refreshed-carrier-records.json files preserve the one-client replays.
An initial isolated final target compiled before the final paired lane; its
preliminary-final-records.json was retained but its output and log paths were
reused, so it is not independent validation evidence.

Target baseline/final CPU 12.48/12.67 s; Checks 1.94/2.09 s; refreshed
CarrierRadix 3.56/3.47 s; HalfBinomialSandwich 10.45/11.26 s. These are single
shared-load pairs, not broad performance measurements. All three client object
bytes match. The target and clients emit no warnings; Checks emits axiom reports.
The target census removes exactly the two private wrapper names, retains all
18 other namespace declaration/type/axiom reports unchanged, adds no names,
and has identical default simp (28,977 entries) and instance (13,172 entries)
lists. A qualified-name search over tracked Lean/Python under this research
area found no references, but does not cover untracked files, dynamic names,
other file types or downstream consumers. The census does not establish equality
of proof bodies or of every persistent Lean environment extension.

B is separately prototyping PellFirstNorm, a direct input of FirstIndex, so the
current experiment uses the pre-proposal provider and does not claim coherence
with the proposed upstream change. B reports a later combined replay of each
FirstNorm variant through FirstIndex and this final PowerRecovery source; its
separate records are /tmp/pell-first-positive/{baseline,final}-combined-record.json.
