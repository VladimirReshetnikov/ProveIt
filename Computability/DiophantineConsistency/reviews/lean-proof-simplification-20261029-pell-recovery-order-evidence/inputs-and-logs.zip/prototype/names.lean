import DiophantineConsistency.ArithmeticPellPowerRecovery
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellPowerRecovery).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellPowerRecovery" then
   logInfo m!"DECL {n}"
