from pathlib import Path
import hashlib,json,re
R=Path('/tmp/pell-recovery-order');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
fi=next(x for x in load('/tmp/pell-construction-refresh/resumed-records.json') if x['module'].endswith('.ArithmeticPellFirstIndex'));assert fi['status']==0 and fi['source_sha256']==fi['source_after']==h(W/'ArithmeticPellFirstIndex.lean') and fi['object_sha256']==h(fi['object'])
pow=next(x for x in load('/tmp/outer-seed-bound-sharing/prereq-records.json') if x['module'].endswith('.ArithmeticPow'));assert pow['status']==0 and pow['source_sha256']==pow['source_after']==h(W/'ArithmeticPow.lean')
prior=load('/tmp/positive-shift-sharing/source-clean/records.json');cs=next(x for x in prior if x['phase']=='final' and x['module']=='ArithmeticCarrierSoundness2011');assert cs['status']==0 and cs['source_sha256_before']==cs['source_sha256_after']==h(W/'ArithmeticCarrierSoundness2011.lean') and cs['object_sha256']==h(cs['object'])
rad=next(x for x in prior if x['phase']=='final' and x['module']=='ArithmeticCarrierRadix2011');d=next(x for x in rad['direct_inputs'] if x['module'].endswith('.ArithmeticRadixAlignment'));assert d['sha256_before']==d['sha256_after'] and d['source_sha256']==h(W/'ArithmeticRadixAlignment.lean')
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticPellPowerRecovery','ArithmeticPellPowerRecoveryChecks','ArithmeticCarrierRadix2011','ArithmeticHalfBinomialSandwich']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if ph=='baseline' or x['module']!='ArithmeticPellPowerRecovery':assert x['before']==h(W/f"{x['module']}.lean")
  for q in x['direct_inputs']:
   rel=q['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==q['path'] and str(p.resolve())==q['resolved'] and q['before']==q['after']==h(p)
   name=q['module'].split('.')[-1]; expected={'ArithmeticPellFirstIndex':fi['object_sha256'],'ArithmeticPellPowerRecovery':rr[0]['object_sha256'],'ArithmeticCarrierSoundness2011':cs['object_sha256'],'ArithmeticRadixAlignment':d['sha256_before'],'ArithmeticPow':pow['object_sha256']}[name];assert q['before']==expected
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
for n in ('simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
def decl(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/f'{ph}-interfaces.log').read_text()) if v.strip()}
a,b=decl('baseline'),decl('final');assert len(b)==18 and {n.split('.')[-1] for n in a.keys()-b.keys()}=={'one_le_of_pos','add_le_right'} and not b.keys()-a.keys() and all(a[k]==b[k] for k in b)
for n in ('ArithmeticPellPowerRecoveryChecks','ArithmeticCarrierRadix2011','ArithmeticHalfBinomialSandwich'):assert next(x for x in records['baseline'] if x['module']==n)['object_sha256']==next(x for x in records['final'] if x['module']==n)['object_sha256']
print('PASS target/client pairs, current-source first providers, old-private declaration removal and registration census')
