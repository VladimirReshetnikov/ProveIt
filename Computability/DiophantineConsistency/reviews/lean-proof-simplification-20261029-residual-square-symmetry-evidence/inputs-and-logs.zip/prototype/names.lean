import Lean.Elab.Command
import DiophantineConsistency.ObjectResidualSquares
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ObjectResidualSquares).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ObjectResidualSquares" then
   logInfo m!"DECL {n}"
