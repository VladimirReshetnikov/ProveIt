Object residual-square symmetry: isolated proof simplification

Baseline ObjectResidualSquares SHA-256 f5fd68df01c0fdb9d5ef583896009e9cf61afafe4b0a797654bd566e6da39333;
final SHA-256 2fa278a306b820acfe46947dffb5cec7cd5077d118e28403914a5548bb118729.
In square_gap's reversed-order branch, the existing oriented equality is used
by commutativity directly, replacing its explicit three-step calculation. Two
lines replace five; the witness, zero characterization, statements, guards,
imports, definitions and data are unchanged. Source commit e108614ae3 has no
Co-Authored-By trailer; no Claude provenance is claimed.

baseline/final-records.json pin source, first direct input object hashes before/
after, outputs, logs and timings for the target and all three tracked direct
module clients ObjectNaturalDiscrete, ObjectQuadraticSystem and
ObjectQuarticCompiler. All pass both phases and each client's object matches.
The independent focused checks/ObjectResidualSquares source was run both phases;
checks-records.json pins source and target object before/after and its paired
output logs match. The umbrella DiophantineConsistency.lean is a direct importer
and was not rebuilt. Target direct providers ObjectNaturalOrder,
ObjectNaturalZero and QuarticSyntax have current-source producer receipts in
/tmp/object-semiring-sharing/provider-records.json, while ObjectNaturalSemiring
is the current-source final producer in /tmp/object-semiring-sharing/final-
records.json; audit.py/.log verify those matches and target/client/check pins.
Provider source hashes are prior recorded matches, not contemporaneous samples.

ObjectQuadraticSystem's additional direct project objects QuadraticRegister-
Composition (91ce83bee4501c7384847d8c6fff97fb2bea8565bf5dd1a544f0c258dcb9ca04)
and GatesSemiring (df89e88da18b9200f7619b468f5d9627009f3d1a8b633224566ddccd9e32b970),
and ObjectQuarticCompiler's QuarticSemiring object
2a1a9af022d9d06643b98ad2cd2f07a83da4d34bc6f968bafc77dddd3cc9c9d6 were cached
and object-pinned, but this experiment has no matching current-source producer
receipt for those objects. ObjectNaturalDiscrete's other direct BoundedZFC-
Consistency imports are cached external dependencies. Further project and
package dependencies remain cached; no full current-source closure is claimed.

Target probes match all 45 namespace declaration/type/axiom reports, 55,212
default simp entries and 23,353 instance entries. These do not establish equality
of proof bodies or every persistent environment extension. Target and clients
have no warnings. Single shared-load baseline/final user CPU samples: target
3.63/3.64 s, NaturalDiscrete 2.88/2.98, QuadraticSystem 2.42/2.31 and
QuarticCompiler 28.59/27.81; they are not general benchmarks. The final target
was compiled first and suffered cold import paging (39.65 s elapsed versus 4.77
for the warm baseline). final-target-records.json preserves that target and
final-client-records.json the NaturalDiscrete client; baseline/final core and
extra receipts are preserved separately before the merged phase records.

The first standalone probe imported the full object model and was interrupted
while paging in imports; probe-interrupted.lean/.log are retained, without a
full timing/input receipt. The successful lightweight generic CommSemiring probe
imports Mathlib only and also lacks full input pins. The paired full builds,
not exploratory probes, are the validation evidence.
