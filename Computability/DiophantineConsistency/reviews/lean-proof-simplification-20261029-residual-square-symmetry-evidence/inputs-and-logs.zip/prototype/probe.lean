import Mathlib.Tactic.Ring
example {R : Type*} [CommSemiring R] (a b d : R)
    (h : b^2+a^2=2*b*a+d^2) : a^2+b^2=2*a*b+d^2 := by
  simpa only [add_comm, mul_comm, mul_left_comm, mul_assoc] using h
