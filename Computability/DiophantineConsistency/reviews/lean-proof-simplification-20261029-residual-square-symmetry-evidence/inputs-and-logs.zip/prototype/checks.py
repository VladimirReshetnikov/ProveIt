from pathlib import Path
import json,subprocess,hashlib,os
R=Path('/tmp/residual-square-symmetry');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rr=[]
for ph in ('baseline','final'):
 x=json.load(open(R/f'{ph}-records.json'))[0];src=R/ph/'checks/ObjectResidualSquares.lean';obj=R/f'objects-{ph}/DiophantineConsistency/ObjectResidualSquares.olean';log=R/f'{ph}-focused-check.log';tm=R/f'{ph}-focused-check.time';src.parent.mkdir(parents=True,exist_ok=True);src.write_bytes(Path('Computability/DiophantineConsistency/Lean/checks/ObjectResidualSquares.lean').read_bytes());env=os.environ.copy();env['LEAN_PATH']=x['LEAN_PATH'];sb=h(src);ob=h(obj);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(R/ph),str(src)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 z={'phase':ph,'status':p.returncode,'source':str(src),'source_before':sb,'source_after':h(src),'target':str(obj),'target_before':ob,'target_after':h(obj),'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'log':str(log),'log_sha256':h(log),'time':tm.read_text()};rr.append(z);(R/'checks-records.json').write_text(json.dumps(rr,indent=2)+'\n');print(ph,p.returncode,z['time'].strip(),flush=True)
 if p.returncode or z['target_before']!=z['target_after'] or z['source_before']!=z['source_after']:raise SystemExit(1)
