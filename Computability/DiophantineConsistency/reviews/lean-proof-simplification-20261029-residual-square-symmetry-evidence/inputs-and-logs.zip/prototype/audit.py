from pathlib import Path
import hashlib,json
R=Path('/tmp/residual-square-symmetry');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text());providers={}
prior=load('/tmp/object-semiring-sharing/provider-records.json')+load('/tmp/object-semiring-sharing/final-records.json')
for n in ('ObjectNaturalOrder','ObjectNaturalZero','ObjectNaturalSemiring','QuarticSyntax'):
 x=next(x for x in prior if x['module']==n and x['status']==0);assert x['before']==x['after']==h(W/f'{n}.lean') and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256']
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ObjectResidualSquares','ObjectNaturalDiscrete','ObjectQuadraticSystem','ObjectQuarticCompiler']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if ph=='baseline' or x['module']!='ObjectResidualSquares':assert x['before']==h(W/f"{x['module']}.lean")
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ObjectResidualSquares':assert d['before']==rr[0]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
for x,y in zip(records['baseline'][1:],records['final'][1:]):assert x['object_sha256']==y['object_sha256']
for x in load(R/'checks-records.json'):
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==h('Computability/DiophantineConsistency/Lean/checks/ObjectResidualSquares.lean') and x['target_before']==x['target_after']==records[x['phase']][0]['object_sha256'] and x['log_sha256']==h(x['log'])
print('PASS source-matched target providers, paired target/module clients/checks, target census; extra client project providers are cached')
