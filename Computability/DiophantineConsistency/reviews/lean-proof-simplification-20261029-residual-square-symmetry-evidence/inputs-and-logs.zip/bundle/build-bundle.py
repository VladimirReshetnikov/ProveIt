from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs');R=Path('/tmp/residual-square-symmetry');D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-residual-square-symmetry-evidence';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();items={}
def add(n,p):assert n not in items;items[n]=Path(p).read_bytes()
def git(p,rev):return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=ROOT)
rev='227a58c7835bf5c896d083d227cbc84bb13aa3a3';parent='2cdde09b464c21b4cf9e28efa8fe60cf2392b711';mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for ph,ref in [('baseline',parent),('final',rev)]:
 key=f'commit/{ph}.lean';items[key]=git(mod+'ObjectResidualSquares.lean',ref);assert items[key]==(R/ph/'DiophantineConsistency/ObjectResidualSquares.lean').read_bytes()
for n in ['ObjectNaturalDiscrete','ObjectQuadraticSystem','ObjectQuarticCompiler','ObjectNaturalOrder','ObjectNaturalZero','ObjectNaturalSemiring','QuarticSyntax','QuadraticRegisterComposition','GatesSemiring','QuarticSemiring']:
 items['provider-sources/'+n+'.lean']=git(mod+n+'.lean',rev)
items['provider-sources/umbrella.lean']=git('Computability/DiophantineConsistency/Lean/DiophantineConsistency.lean',rev)
for f in sorted(R.rglob('*')):
 parts=f.relative_to(R).parts
 if f.is_file() and f.suffix not in ('.olean','.ilean','.c') and not any(x=='common' or x.startswith('objects-') for x in parts):add('prototype/'+f.relative_to(R).as_posix(),f)
for n,p in {'prior/object-semiring-providers.json':'/tmp/object-semiring-sharing/provider-records.json','prior/object-semiring-final.json':'/tmp/object-semiring-sharing/final-records.json','independent/review.txt':'/tmp/residual-square-symmetry-peer-review.txt','independent/audit.py':'/tmp/residual-square-symmetry-peer-audit.py','independent/audit.log':'/tmp/residual-square-symmetry-peer-audit.log','bundle/build-bundle.py':'/tmp/build-residual-square-symmetry-bundle.py'}.items():add(n,p)
zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):
  i=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Simplify reversed-order proof in ObjectResidualSquares.square_gap',
'validation':'Paired target and three tracked direct module clients pass; all three client object pairs match. The focused ObjectResidualSquares check passes with source and target pins. Four target direct project providers match current-source producer receipts. Target namespace/type/axiom and global simp/instance reports match.',
'limitations':['The umbrella DiophantineConsistency.lean directly imports this module but was not rebuilt.', 'QuadraticRegisterComposition 91ce83…, GatesSemiring df89e8… and QuarticSemiring 2a1a9a… are client direct cached object inputs without matched current-source producer receipts. ObjectNaturalDiscrete also uses cached BoundedZFCConsistency InternalSat and CodedDerivation objects.', 'Wider project and package transitive closure remains cached; no full current-source closure is claimed. Matching census and client object reports do not establish every persistent environment extension or umbrella behavior.', 'The cold object-model exploratory probe was interrupted without a full timing/input receipt, and the later generic probe also lacks full pins; paired builds supply validation. A single shared-load timing pair is not a general benchmark.', 'Author records are historical; the independent review/audit verify commit and parent. Compiled objects and cached overlays are omitted; external objects are needed to independently verify recorded object hashes.'],
'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(items)
 for n,b in items.items():assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes();print(n,sha(b),len(b))
