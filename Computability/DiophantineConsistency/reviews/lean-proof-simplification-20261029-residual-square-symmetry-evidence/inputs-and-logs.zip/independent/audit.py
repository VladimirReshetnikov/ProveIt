from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/residual-square-symmetry');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean');M=W/'DiophantineConsistency'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ObjectResidualSquares.lean').read_text();f=(R/'final/DiophantineConsistency/ObjectResidualSquares.lean').read_text()
old='''    refine ⟨d,?_,hzero.trans eq_comm⟩
    calc
      a^2+b^2=b^2+a^2 := add_comm _ _
      _ = 2*b*a+d^2 := hd
      _ = 2*a*b+d^2 := by ring''';new='''    exact ⟨d, by simpa only [add_comm, mul_comm, mul_left_comm, mul_assoc] using hd,
      hzero.trans eq_comm⟩''';assert b.count(old)==1 and b.replace(old,new)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ObjectResidualSquares.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('227a58c783^')==b and gitfile('227a58c783')==f and (M/'ObjectResidualSquares.lean').read_text()==f
print('PASS exact proof substitution, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ObjectResidualSquares$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines(); expected=['Computability/DiophantineConsistency/Lean/DiophantineConsistency.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/ObjectNaturalDiscrete.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/ObjectQuadraticSystem.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/ObjectQuarticCompiler.lean','Computability/DiophantineConsistency/Lean/checks/ObjectResidualSquares.lean'];assert sorted(clients)==sorted(expected),clients
print('PASS three module clients, focused check and umbrella direct importer identified')
prior={}
for path in ['/tmp/object-semiring-sharing/provider-records.json','/tmp/object-semiring-sharing/final-records.json']:
 for x in read(path):
  n=x['module']
  if n in ('ObjectNaturalOrder','ObjectNaturalZero','ObjectNaturalSemiring','QuarticSyntax'):
   assert x['status']==0 and x['before']==x['after']==h(M/(n+'.lean')) and x['object_sha256']==h(x['object']);prior[n]=x['object_sha256']
assert len(prior)==4;print('PASS four target direct producer source/object pairs',prior)
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ObjectResidualSquares','ObjectNaturalDiscrete','ObjectQuadraticSystem','ObjectQuarticCompiler'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ObjectResidualSquares':assert x['before']==h(M/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ObjectResidualSquares':assert d['before']==rec[phase][n]['object_sha256']
   elif n in prior:assert d['before']==prior[n]
   else:assert n in ['InternalSat','CodedDerivation','QuadraticRegisterComposition','GatesSemiring','QuarticSemiring'];print('cached unmatched direct input',x['module'],n,d['before'],d['resolved'])
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ObjectNaturalDiscrete','ObjectQuadraticSystem','ObjectQuarticCompiler'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
for x in read(R/'checks-records.json'):
 phase=x['phase'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==h(W/'checks/ObjectResidualSquares.lean') and x['target_before']==x['target_after']==h(x['target'])==rec[phase]['ObjectResidualSquares']['object_sha256'] and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
print('PASS three identical client object pairs and paired focused check')
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ObjectResidualSquares']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
print('PASS target declaration/type/axiom and simp/instance probes')
assert (R/'baseline-focused-check.log').read_bytes()==(R/'final-focused-check.log').read_bytes()
print('PASS paired focused-check logs match; umbrella importer remains untested')
