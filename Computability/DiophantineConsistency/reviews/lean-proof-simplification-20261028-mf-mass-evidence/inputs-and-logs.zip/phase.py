import os,sys,subprocess,time,hashlib,json
from pathlib import Path
r=Path('/tmp/mf-mass-20261028'); phase=sys.argv[1]; ov=r/phase; env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env.get('LEAN_PATH','')
repo=Path('Computability/DiophantineConsistency/Lean'); target=repo/'DiophantineConsistency/MFCurrentKernel2011.lean' if phase=='final' else r/'source/DiophantineConsistency/MFCurrentKernel2011.lean'; modroot=repo if phase=='final' else r/'source'
items=[('target',target,modroot,ov/'DiophantineConsistency/MFCurrentKernel2011.olean'),('client',repo/'DiophantineConsistency/MFCurrentReflectedGeometry2011.lean',repo,ov/'DiophantineConsistency/MFCurrentReflectedGeometry2011.olean'),('focus',r/'focus.lean',repo,None),('axioms',r/'axioms.lean',repo,None)]
records=[]
for label,src,rt,obj in items:
 if len(sys.argv)>2 and label not in sys.argv[2:]:continue
 log=r/'logs'/f'{phase}-{label}.log';timefile=r/'logs'/f'{phase}-{label}.time'; cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(timefile),'lean','-M6000','-j1','-DElab.async=false','-R',str(rt),str(src)];
 if obj is not None:cmd+=['-o',str(obj)]
 st=time.monotonic(); p=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(p.stdout+p.stderr)
 h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest(); rec={'label':label,'cmd':cmd,'status':p.returncode,'seconds':time.monotonic()-st,'source_sha256':h(src),'log_sha256':h(log),'object_sha256':h(obj) if p.returncode==0 and obj else None,'object_bytes':obj.stat().st_size if p.returncode==0 and obj else None};records.append(rec);(r/f'{phase}-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,label,p.returncode,round(rec['seconds'],1),flush=True)
 if p.returncode:sys.exit(p.returncode)
