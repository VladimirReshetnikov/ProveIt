import Foundation.FirstOrder.Arithmetic.IOpen.Basic
import DiophantineConsistency.MFCurrentKernel2011
open scoped BigOperators
open DiophantineConsistency.WangTiles942 DiophantineConsistency.CurrentKernel2011
example : (∑ i : Fin 942, selectorWeight (tile i)) = 3812322332357550 :=
  DiophantineConsistency.MF.CurrentKernel2011.selector_mass
example : (∑ e : Entry, weight e) = 3829914518400942 :=
  DiophantineConsistency.MF.CurrentKernel2011.entry_mass
