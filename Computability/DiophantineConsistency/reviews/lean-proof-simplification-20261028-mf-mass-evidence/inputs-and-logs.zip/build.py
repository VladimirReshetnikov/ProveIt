import os,sys,subprocess,time,hashlib,json
from pathlib import Path
root=Path('/tmp/mf-mass-20261028'); base=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); out=root/'overlay/DiophantineConsistency'
names=['CurrentKernelData2011','ArithmeticMaskKernel','MFPaper1984Identities','MFPaper1982Carries','MFPaper1982Coding','MFPaper1982Digits','MFPaper1982Master2','MFNativeCyclicConvolution','MFNativeCyclicRotation','MFNativeCyclicCarryWord','MFWangTiles942Core']
env=os.environ.copy();env['LEAN_PATH']=str(root/'overlay')+':'+env.get('LEAN_PATH',''); records=[]
for n in names:
 src=base/(n+'.lean');obj=out/(n+'.olean');log=root/'logs'/(n+'.log');timefile=root/'logs'/(n+'.time')
 cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(timefile),'lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(obj)]
 st=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(p.stdout+p.stderr)
 h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
 rec={'module':n,'cmd':cmd,'status':p.returncode,'seconds':time.monotonic()-st,'source_sha256':h(src),'log_sha256':h(log),'object_sha256':h(obj) if p.returncode==0 and obj.exists() else None}
 records.append(rec);(root/'prereqs.json').write_text(json.dumps(records,indent=2)+'\n');print(n,p.returncode,round(rec['seconds'],1),flush=True)
 if p.returncode:sys.exit(p.returncode)
