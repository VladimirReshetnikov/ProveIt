from pathlib import Path
import os,subprocess,json,hashlib
r=Path('/tmp/word-bound-simplify-20261028'); env=os.environ.copy();env['LEAN_PATH']=str(r/'lib')+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip()
p=r/'alt/DiophantineConsistency/ArithmeticProofWordBound.lean';out=r/'alt/DiophantineConsistency/ArithmeticProofWordBound.olean';log=r/'logs/alt.log';tm=r/'logs/alt.time';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(r/'alt'),str(p),'-o',str(out)]
before=sha(p)
with log.open('wb') as f: q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
a={'source':str(p),'before':before,'after':sha(p),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};(r/'alt-record.json').write_text(json.dumps(a,indent=2));print(json.dumps(a,indent=2));raise SystemExit(q.returncode)
