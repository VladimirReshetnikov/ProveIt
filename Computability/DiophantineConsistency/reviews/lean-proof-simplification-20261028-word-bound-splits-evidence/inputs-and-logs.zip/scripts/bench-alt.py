from pathlib import Path
import os,subprocess,hashlib,json
r=Path('/tmp/word-bound-simplify-20261028');source=Path('Computability/DiophantineConsistency/Lean');env=os.environ.copy();env['LEAN_PATH']=str(r/'lib')+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[]
for phase in ['baseline-alt1','alt1','baseline-alt2','alt2']:
 baseline=phase.startswith('baseline');p=source/'DiophantineConsistency/ArithmeticProofWordBound.lean' if baseline else r/'alt/DiophantineConsistency/ArithmeticProofWordBound.lean';root=source if baseline else r/'alt';out=r/f'bench-{phase}.olean';log=r/'logs'/f'bench-{phase}.log';tm=r/'logs'/f'bench-{phase}.time';before=sha(p);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(p),'-o',str(out)]
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'phase':phase,'source':str(p),'before':before,'after':sha(p),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};rec.append(row);(r/'bench-alt-records.json').write_text(json.dumps(rec,indent=2));print(phase,q.returncode,row['time'].strip(),flush=True)
 if q.returncode or before!=row['after']:raise SystemExit(1)
