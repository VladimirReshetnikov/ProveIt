from pathlib import Path
import os,subprocess,json,hashlib,time
root=Path('/tmp/word-bound-simplify-20261028')
source=Path('Computability/DiophantineConsistency/Lean')
env=os.environ.copy();env['LEAN_PATH']=str(root/'lib')+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for n in ['ArithmeticProofWordBoundLevel','ArithmeticEnumBoundFair','ArithmeticProofWordBound']:
 p=source/'DiophantineConsistency'/f'{n}.lean'; out=root/'lib/DiophantineConsistency'/f'{n}.olean'; log=root/'logs'/f'{n}.log'; tm=root/'logs'/f'{n}.time'
 if out.is_symlink():out.unlink()
 cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(source),str(p),'-o',str(out)]
 before=sha(p)
 with log.open('wb') as f: q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':n,'source':str(p),'before':before,'after':sha(p),'status':q.returncode,'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'log_sha256':sha(log),'time':tm.read_text(),'object_sha256':sha(out) if out.exists() else None}
 records.append(row);(root/'build-records.json').write_text(json.dumps(records,indent=2));print(n,q.returncode,row['time'],flush=True)
 if q.returncode or row['before']!=row['after']:break
