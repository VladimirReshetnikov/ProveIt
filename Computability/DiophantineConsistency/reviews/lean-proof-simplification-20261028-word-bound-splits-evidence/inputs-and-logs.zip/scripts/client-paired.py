from pathlib import Path
import re,os,subprocess,json,hashlib
r=Path('/tmp/word-bound-simplify-20261028');base=Path('Computability/DiophantineConsistency/Lean');p=base/'DiophantineConsistency/ArithmeticRefutationHaltBound.lean';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();deps=re.findall(r'^import (\S+)',p.read_text(),re.M);rec=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(r/f'client-{phase}')+':'+str(r/'client-common')+':'+lp;search=[Path(x) for x in env['LEAN_PATH'].split(':')];inputs={}
 for d in deps:
  o=next((x/(d.replace('.','/')+'.olean') for x in search if (x/(d.replace('.','/')+'.olean')).is_file()),None)
  if o is None:raise Exception('missing '+d)
  inputs[d]={'path':str(o.resolve()),'before':sha(o)}
 out=r/f'client-{phase}/DiophantineConsistency/ArithmeticRefutationHaltBound.olean';log=r/'logs'/f'client-{phase}.log';tm=r/'logs'/f'client-{phase}.time';before=sha(p);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(base),str(p),'-o',str(out)]
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for x in inputs.values():x['after']=sha(Path(x['path']))
 row={'phase':phase,'source':str(p),'before':before,'after':sha(p),'inputs':inputs,'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};rec.append(row);(r/'client-records.json').write_text(json.dumps(rec,indent=2));print(phase,q.returncode,row['time'].strip(),flush=True)
 if q.returncode or before!=row['after'] or any(x['before']!=x['after'] for x in inputs.values()):raise SystemExit(1)
