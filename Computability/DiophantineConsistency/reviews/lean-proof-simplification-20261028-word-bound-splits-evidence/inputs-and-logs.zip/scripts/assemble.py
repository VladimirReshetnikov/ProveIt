from pathlib import Path
import json,hashlib,shutil
R=Path('/tmp/word-bound-simplify-20261028');E=Path(__file__).resolve().parent.parent;P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=json.loads((R/'bench-records.json').read_text());altr=json.loads((R/'bench-alt-records.json').read_text());byname={'baseline':(P/'ArithmeticProofWordBound.lean',records[0]['before']),'split_ifs':(R/'src/DiophantineConsistency/ArithmeticProofWordBound.lean',records[1]['before']),'single_split':(R/'alt/DiophantineConsistency/ArithmeticProofWordBound.lean',altr[1]['before'])}
for n,(src,expected) in byname.items():
 assert sha(src)==expected;shutil.copy2(src,E/'sources'/n/src.name)
for fname in ['build-records.json','client-prep-records.json','client-records.json']:
 for rec in json.loads((R/fname).read_text()):
  src=Path(rec['source']);expected=rec.get('source_sha256',rec.get('before'))
  if src.name=='ArithmeticRuntimeBoundDagMacrosA.lean' and sha(src)!=expected:src=Path('/tmp/dag-macro-sharing/sources/baseline/DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.lean')
  assert sha(src)==expected,(fname,src,expected)
  if src.name=='ArithmeticProofWordBound.lean':continue
  dest=E/'sources/clients'/src.name
  if dest.exists():assert sha(dest)==expected
  else:shutil.copy2(src,dest)
for p in R.iterdir():
 if p.is_file() and p.suffix in ['.py','.lean']:shutil.copy2(p,E/'scripts'/p.name)
 if p.is_file() and p.suffix=='.json':shutil.copy2(p,E/'records'/p.name)
for p in (R/'logs').iterdir():
 if p.is_file():shutil.copy2(p,E/'logs'/p.name)
shutil.copy2('/tmp/word-bound-independent-review.txt',E/'review/independent-review.txt')
for n in ['graph.json','coherent-common-records.json','phase-records.json']:
 p=Path('/tmp/claude-ax-sharing')/n
 if p.is_file():shutil.copy2(p,E/'provenance'/n)
print('snapshots verified',len(byname),'client snapshots',len(list((E/'sources/clients').iterdir())),'records',len(list((E/'records').iterdir())),'logs',len(list((E/'logs').iterdir())))
