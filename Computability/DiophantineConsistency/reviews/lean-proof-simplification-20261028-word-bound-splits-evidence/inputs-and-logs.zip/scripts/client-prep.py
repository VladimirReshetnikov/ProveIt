from pathlib import Path
import re,os,subprocess,json,hashlib
r=Path('/tmp/word-bound-simplify-20261028');base=Path('Computability/DiophantineConsistency/Lean');common=r/'client-common';env=os.environ.copy();env['LEAN_PATH']=str(common)+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();search=[Path(x) for x in env['LEAN_PATH'].split(':')];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();seen=set();plan=[]
def visit(n):
 if n in seen:return
 seen.add(n);p=base/(n.replace('.','/')+'.lean')
 if not p.is_file():return
 deps=[]
 for line in p.read_text().splitlines():
  m=re.match(r'\s*import\s+(\S+)',line)
  if m:deps.append(m[1]);visit(m[1])
 if n != 'DiophantineConsistency.ArithmeticRefutationHaltBound' and not (common/(n.replace('.','/')+'.olean')).exists():plan.append((n,p,deps))
visit('DiophantineConsistency.ArithmeticRefutationHaltBound')
(r/'client-plan.json').write_text(json.dumps([n for n,p,d in plan],indent=2));print('build plan',len(plan),flush=True);rec=[]
for n,p,deps in plan:
 inputs={}
 for d in deps:
  path=next((x/(d.replace('.','/')+'.olean') for x in search if (x/(d.replace('.','/')+'.olean')).is_file()),None)
  if path is None: raise Exception('missing import '+d+' for '+n)
  inputs[d]={'path':str(path.resolve()),'before':sha(path)}
 out=common/(n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True); log=r/'logs'/f'prep-{p.stem}.log';tm=r/'logs'/f'prep-{p.stem}.time';before=sha(p)
 cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(base),str(p),'-o',str(out)]
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d,x in inputs.items():x['after']=sha(Path(x['path']))
 entry={'name':n,'source':str(p),'before':before,'after':sha(p),'inputs':inputs,'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};rec.append(entry);(r/'client-prep-records.json').write_text(json.dumps(rec,indent=2));print(n,q.returncode,entry['time'].strip(),flush=True)
 if q.returncode or before!=entry['after'] or any(i['before']!=i['after'] for i in inputs.values()):raise SystemExit(1)
