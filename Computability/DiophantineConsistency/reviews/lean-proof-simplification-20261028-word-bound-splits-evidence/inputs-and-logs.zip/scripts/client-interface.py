from pathlib import Path
import os,subprocess,hashlib,json
r=Path('/tmp/word-bound-simplify-20261028');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();rec=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(phase,name):
 source=r/f'{name}.lean';log=r/'logs'/f'{phase}-{name}.log';tm=r/'logs'/f'{phase}-{name}.time';env=os.environ.copy();env['LEAN_PATH']=str(r/('client-baseline' if phase=='baseline' else 'client-final'))+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(source)];before=sha(source)
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'phase':phase,'name':name,'source':str(source),'before':before,'after':sha(source),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'log_sha256':sha(log),'time':tm.read_text()};rec.append(row);(r/'client-interface-records.json').write_text(json.dumps(rec,indent=2));print(phase,name,q.returncode,flush=True)
 if q.returncode or before!=row['after']:raise SystemExit(1)
for phase in ['baseline','final']:run(phase,'client-interface')
