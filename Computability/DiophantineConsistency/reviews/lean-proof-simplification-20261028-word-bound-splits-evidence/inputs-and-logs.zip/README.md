# Word-bound case split experiment: not adopted

28 October 2026. This archive preserves two isolated simplification attempts
for `ArithmeticProofWordBound.row_le`. Neither is being adopted because both
were materially slower to compile in the recorded local measurements.

The `split_ifs` alternative removes 26 net lines (11 insertions, 37 deletions)
and used 23.35 and 21.47 seconds of user CPU in two paired runs. The
single-`split` alternative removes 18 net lines (19 insertions, 37 deletions)
and used 17.72 and 18.16 seconds. The four paired baseline measurements used
6.60–7.05 seconds of user CPU, roughly 7 seconds. Times and peak memory are
in `records/bench-records.json`, `records/bench-alt-records.json`, and the
corresponding raw logs and time files. These are local measurements using
cached dependencies, not a universal performance claim.

## Contents and validation

- `sources/baseline/`, `sources/split_ifs/`, and `sources/single_split/`
  contain all three target sources. Their hashes were checked against the
  benchmark receipts when copied. Patch files show the two deltas.
- Both alternative target files compiled and were benchmarked successfully.
  For the `split_ifs` alternative, baseline and final public-name,
  private-name, all-interface/type-and-axiom, and default-simp reports were
  byte-identical. Both representative `ArithmeticRefutationHaltBound` client
  builds succeeded; their client-interface reports, including the `Bmach`
  and `Bref` defining equations, are byte-identical. The full records, raw
  logs, scripts, and 15 relevant dependency/client source snapshots are
  included. The single-`split` alternative was compiled and benchmarked;
  this archive does not claim that it received the same client and census
  comparison.
- `review/independent-review.txt` records an independent review of the
  `split_ifs` alternative and the saved target/client validation. It found no
  correctness issue and independently checked receipt hashes, but did not
  audit every persistent Lean environment extension or all downstream clients.
- The failed first root attempt is retained in `failed-root-record.json` and
  `logs/failed-root.*`: the source file was outside the supplied Lean root.
  That record's original `logs/alt.time` path was later overwritten by the
  successful alternative build; `logs/failed-root.time` preserves the failure
  timing printed in the receipt, and `logs/failed-root.log` matches its
  recorded log hash. The failed client overlay attempt and its log/record are
  also retained; it lacked `ArithmeticProofWordBoundLevel.olean`. These
  failures are not counted as successful builds.

## Cached inputs and reproducibility

The target and client builds reused cached Lean, Foundation and other project
objects. Client preparation and paired client receipts identify direct-import
object paths and before/after hashes; the independent review checked those
paths and hashes at review time. They do not establish that every transitive
cached object was freshly built from its current source. The benchmark receipts
record the source hashes, command, `LEAN_PATH`, output hashes and timing, but
are not complete independent receipts for all transitive imports. The original
scripts and additional cached-overlay receipts are provided under `scripts/`
and `provenance/`; they use the original absolute temporary paths and require
that environment to replay. Compiled objects and cached overlays are excluded.

One client preparation source (`ArithmeticRuntimeBoundDagMacrosA.lean`) has
since changed in the workspace. Its snapshot here was recovered from the
previously saved baseline and verified against the original preparation source
hash, so it accurately describes that recorded build. The origin commit
`d9775aa0f5`, including its Claude coauthor trailer, is recorded in
`provenance/origin-commit.txt`. The manifest covers every other file here.
