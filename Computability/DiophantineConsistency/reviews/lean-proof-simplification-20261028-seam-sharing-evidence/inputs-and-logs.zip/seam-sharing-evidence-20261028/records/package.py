from pathlib import Path
import shutil,hashlib,json,difflib,zipfile,subprocess
P=Path('/tmp/seam-sharing');D=Path('/tmp/seam-sharing-evidence-20261028');D.mkdir(exist_ok=True)
def copy(src,rel):
 dst=D/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for x in P.iterdir():
 if x.is_file() and not x.is_symlink() and x.suffix in {'.lean','.log','.time','.json','.py'}:copy(x,Path('records')/x.name)
for ph in ['baseline','final']:
 for x in (P/'sources'/ph).rglob('*.lean'):copy(x,Path('sources')/ph/x.relative_to(P/'sources'/ph))
for n in ['provider-audit.json','assembly-phase-records.json','assembly-common-records.json','assembly-input-pins.json']:copy(Path('/tmp/positive-shift-sharing/transport-receipts')/n,Path('provenance/transport')/n)
copy(Path('/tmp/pell-construction-refresh/local-pins.json'),Path('provenance/pell-local-pins.json'));copy(Path('/tmp/positive-shift-sharing/source-clean/records.json'),Path('provenance/positive-shift-clean-records.json'));copy(Path('/tmp/controller-dmap-sharing/final-records.json'),Path('provenance/controller-dmap-final-records.json'))
(D/'provenance/claude-source-commit.txt').write_text(subprocess.check_output(['git','show','--format=fuller','--no-patch','3cd04ac37f'],text=True));(D/'provenance/toolchain.txt').write_text(subprocess.check_output(['lean','--version'],text=True));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
a=(P/'sources/baseline/DiophantineConsistency/ArithmeticTilingBand.lean').read_text().splitlines(keepends=True);b=(P/'sources/final/DiophantineConsistency/ArithmeticTilingBand.lean').read_text().splitlines(keepends=True);(D/'prototype.patch').write_text(''.join(difflib.unified_diff(a,b,fromfile='baseline/ArithmeticTilingBand.lean',tofile='final/ArithmeticTilingBand.lean')))
(D/'README.md').write_text('''# Tiling seam proof simplification: isolated evidence

The candidate replaces duplicated four-way south/north case splits in ArithmeticTilingBand.seam_vertical by a single local fact proving both colors equal 437, then applies it at the two indices. It removes 14 net lines without changing imports, definitions, hypotheses, theorem statements or color facts. The baseline target matches the source in Claude Opus 5.5 coauthored commit 3cd04ac37f; commit metadata and exact frozen baseline/final sources are included. Observed HEAD at packaging: `'''+head+'''`. No repository files were edited by the prototyping agent.

## Paired runs and timing

Three full target builds per phase passed under `-j1 -DElab.async=false`. Baseline user-CPU samples are 29.71, 29.13, 30.26 seconds (median 29.71); candidate samples are 30.82, 31.10, 33.20 seconds (median 31.10, ratio 1.047). Max RSS is approximately 1.88 GB in each sample. These paired incremental runs use the same ArithmeticTilingRows object and record elapsed, user and system time; they rule out a 3x whole-target regression in this environment, but are not a formal benchmark. The target's one warning matches after normalizing the phase and line location.

After the positive-shift and controller-dmap changes were adopted during the first client run, fresh coherent baseline/final overlays were composed from the adopted positive-shift providers and the adopted controller-dmap target/clients. All paired ArithmeticTilingWord, ArithmeticConstructionAssembly and ArithmeticCurrentConstruction2011 client builds pass; all 28 coherent direct input occurrences match a same-phase object or prior source/object receipt. TilingWord's nine warnings match after normalizing source paths, and the other client logs are byte-identical. The earlier old-provider client/endpoint builds in `baseline-records.json` and `final-records.json` are retained as supplemental attempts but excluded from current-source endpoint claims: their ArithmeticCurrentSentence2011 object corresponded to the pre-adoption source. The source dependency scan shows that ArithmeticTilingRows' 11-module local closure contains none of the changed positive-shift/dmap modules, so the six timed target builds themselves are not affected by that mismatch.

## Interfaces and failed experiments

The target declaration/forced-equation census has exactly 61 names in each phase, with no additions or removals. The 61 common #check/#print axioms reports and private environment reports are byte-identical. Global simp membership/flag logs contain the same 29,730 entries. These comparisons do not claim a clean rebuild of the entire transitive source or package closure.

`first-failed.lean` and `first.log` retain the initial simplifier attempt, which failed due to looping apply_ite rewriting. `second-split-cross.lean` and `second.log` retain a passing but discarded version that split both indices separately. The small `mini.lean` and `mini2` experiments are exploratory and are not part of the accepted target/client evidence; the first mini2 source was modified before its hash was recorded. Corrected final sources, commands, direct input hashes, logs, timings, output hashes, probe records and provider composition audits are in this archive.

## Limits

All evidence is incremental. The adopted positive-shift and dmap receipt records and the transport provider audit are included; external package libraries and other historical transitive inputs remain cached, binaries are excluded, and the scripts refer to original temporary paths and the installed toolchain. Not every downstream source client was rebuilt. The prototype is not itself a completed repository change.
''')
h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();files=sorted(x for x in D.rglob('*') if x.is_file() and x.name!='manifest.sha256');(D/'manifest.sha256').write_text(''.join(h(x)+'  '+x.relative_to(D).as_posix()+'\n' for x in files));a=Path(str(D)+'.zip')
with zipfile.ZipFile(a,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(x for x in D.rglob('*') if x.is_file()):z.write(f,f.relative_to(D.parent))
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None
 for i in z.infolist():assert hashlib.sha256(z.read(i)).hexdigest()==h(D.parent/i.filename)
print('files',len(files)+1,'size',a.stat().st_size,'sha256',h(a))
