import DiophantineConsistency.ArithmeticTilingBand
#print equations DiophantineConsistency.ArithmeticTilingBand.seamIdx
#print equations DiophantineConsistency.ArithmeticTilingBand.initIdx
#print equations DiophantineConsistency.ArithmeticTilingBand.resetIdx
#print equations DiophantineConsistency.ArithmeticTilingBand.bandIdx
#print equations DiophantineConsistency.ArithmeticTilingBand.cellOf
#print equations DiophantineConsistency.ArithmeticTilingBand.word
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticTilingBand).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticTilingBand).isPrefixOf n then
      logInfo m!"DECL {n}"
      if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
         t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
        logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
