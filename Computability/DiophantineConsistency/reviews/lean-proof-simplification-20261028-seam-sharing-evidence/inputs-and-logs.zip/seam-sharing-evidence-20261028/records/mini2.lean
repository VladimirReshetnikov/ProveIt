import DiophantineConsistency.ArithmeticTilingBand
open SetTheory.BusyBeaver SetTheory.BusyBeaver.ZFC
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticWangTable DiophantineConsistency.ArithmeticTilingBand DiophantineConsistency.ArithmeticTilingTable
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (H k k' : V) : southC (seamIdx H k) = northC (seamIdx H k') := by
  have hc (t : V) : southC (seamIdx H t) = 437 ∧ northC (seamIdx H t) = 437 := by
    unfold seamIdx
    split_ifs <;> simp only [c938.south, c939.south, c934.south, c933.south,
      c938.north, c939.north, c934.north, c933.north, true_and]
  exact (hc k).1.trans (hc k').2.symm
