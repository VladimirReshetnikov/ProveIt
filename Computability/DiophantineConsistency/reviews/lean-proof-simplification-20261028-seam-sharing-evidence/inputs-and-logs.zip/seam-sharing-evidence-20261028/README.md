# Tiling seam proof simplification: isolated evidence

The candidate replaces duplicated four-way south/north case splits in ArithmeticTilingBand.seam_vertical by a single local fact proving both colors equal 437, then applies it at the two indices. It removes 14 net lines without changing imports, definitions, hypotheses, theorem statements or color facts. The baseline target matches the source in Claude Opus 5.5 coauthored commit 3cd04ac37f; commit metadata and exact frozen baseline/final sources are included. Observed HEAD at packaging: `f3faf5c4b358ba1a38817903c9b16474863d0be6`. No repository files were edited by the prototyping agent.

## Paired runs and timing

Three full target builds per phase passed under `-j1 -DElab.async=false`. Baseline user-CPU samples are 29.71, 29.13, 30.26 seconds (median 29.71); candidate samples are 30.82, 31.10, 33.20 seconds (median 31.10, ratio 1.047). Max RSS is approximately 1.88 GB in each sample. These paired incremental runs use the same ArithmeticTilingRows object and record elapsed, user and system time; they rule out a 3x whole-target regression in this environment, but are not a formal benchmark. The target's one warning matches after normalizing the phase and line location.

After the positive-shift and controller-dmap changes were adopted during the first client run, fresh coherent baseline/final overlays were composed from the adopted positive-shift providers and the adopted controller-dmap target/clients. All paired ArithmeticTilingWord, ArithmeticConstructionAssembly and ArithmeticCurrentConstruction2011 client builds pass; all 28 coherent direct input occurrences match a same-phase object or prior source/object receipt. TilingWord's nine warnings match after normalizing source paths, and the other client logs are byte-identical. The earlier old-provider client/endpoint builds in `baseline-records.json` and `final-records.json` are retained as supplemental attempts but excluded from current-source endpoint claims: their ArithmeticCurrentSentence2011 object corresponded to the pre-adoption source. The source dependency scan shows that ArithmeticTilingRows' 11-module local closure contains none of the changed positive-shift/dmap modules, so the six timed target builds themselves are not affected by that mismatch.

## Interfaces and failed experiments

The target declaration/forced-equation census has exactly 61 names in each phase, with no additions or removals. The 61 common #check/#print axioms reports and private environment reports are byte-identical. Global simp membership/flag logs contain the same 29,730 entries. These comparisons do not claim a clean rebuild of the entire transitive source or package closure.

`first-failed.lean` and `first.log` retain the initial simplifier attempt, which failed due to looping apply_ite rewriting. `second-split-cross.lean` and `second.log` retain a passing but discarded version that split both indices separately. The small `mini.lean` and `mini2` experiments are exploratory and are not part of the accepted target/client evidence; the first mini2 source was modified before its hash was recorded. Corrected final sources, commands, direct input hashes, logs, timings, output hashes, probe records and provider composition audits are in this archive.

## Limits

All evidence is incremental. The adopted positive-shift and dmap receipt records and the transport provider audit are included; external package libraries and other historical transitive inputs remain cached, binaries are excluded, and the scripts refer to original temporary paths and the installed toolchain. Not every downstream source client was rebuilt. The prototype is not itself a completed repository change.
