from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/seam-independent-review');P=Path('/tmp/seam-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rs=[]
def run(ph,n):
 src=R/(n+'.lean');dep=P/('coherent-'+ph)/'DiophantineConsistency/ArithmeticTilingWord.olean';log=R/(ph+'-'+n+'.log');tm=R/(ph+'-'+n+'.time');env=os.environ.copy();env['LEAN_PATH']=str(P/('coherent-'+ph))+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];h=sha(src);d=sha(dep);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 z={'phase':ph,'name':n,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_before':h,'source_after':sha(src),'input_object':str(dep),'input_before':d,'input_after':sha(dep),'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};rs.append(z);(R/'records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,n,r.returncode,z['time'].strip(),flush=True);assert r.returncode==0 and h==z['source_after'] and d==z['input_after']
for ph in ['baseline','final']:run(ph,'client-names')
read=lambda ph:{x[5:] for x in (R/(ph+'-client-names.log')).read_text().splitlines() if x.startswith('DECL ')}
a=read('baseline');b=read('final');(R/'name-diff.json').write_text(json.dumps({'baseline_count':len(a),'final_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)},indent=2)+'\n');print('client names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),flush=True)
common=sorted(a&b);(R/'client-interfaces.lean').write_text('import DiophantineConsistency.ArithmeticTilingWord\nset_option pp.universes true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in common))
for ph in ['baseline','final']:run(ph,'client-interfaces')
print('client interface reports identical:',(R/'baseline-client-interfaces.log').read_bytes()==(R/'final-client-interfaces.log').read_bytes(),'common names',len(common),flush=True)
