import DiophantineConsistency.ArithmeticTilingWord
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticTilingWord).isPrefixOf n then
   logInfo m!"DECL {n}"
