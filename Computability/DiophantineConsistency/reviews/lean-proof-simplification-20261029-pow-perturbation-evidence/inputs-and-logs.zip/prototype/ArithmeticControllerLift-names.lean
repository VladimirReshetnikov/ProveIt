import DiophantineConsistency.ArithmeticControllerLift
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticControllerLift).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticControllerLift" then
   logInfo m!"DECL {n}"
