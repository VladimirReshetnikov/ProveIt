Represented power perturbation coefficient: isolated proof simplification

Baseline ArithmeticPow SHA-256 3b36e96bf986cae6bd3d9061d2619de563b866889e5d3fbcc92e48748ea98695;
final SHA-256 d7f033c291d70c5078eacd33c5ce25334f0d64b1bcc8be66e449e88a5b1d7e00.
In perturbation_coefficient, replace the displayed three-step polynomial
calculation by rewriting the existing subtraction decomposition, simplifying
the cancellation and applying ring. The identity, its 2*r*e≤a guard, all
other statements, definitions, imports and data are unchanged. This eliminates
one net line and two lengthy repeated expressions. Tested snapshots match commit a37047cc30 and its parent. Source commit
90f67cbdd9ed84e6100d74662cabfe12402c5d2a has the trailer Co-Authored-By:
Claude Opus 5.5 <noreply@anthropic.com>.

baseline/final-records.json record paired target and all four direct source
clients: HalfBinomialSandwich, ControllerLift, TilingWord and BinomExpansion.
Each records source snapshot, first direct provider object hashes before/after,
commands, output objects, logs and timings. Direct project provider matches:
PowerRecovery from /tmp/four-positive-wrappers/upstream-records.json, freshly
rebuilt through the adopted current PellCongruences; ModularCancellation from
/tmp/shared-modular-cancel/records.json; TilingBand from /tmp/tiling-band-
dispatch/final-records.json; and BinomPascal from /tmp/outer-seed-bound-sharing/
prereq2-records.json. Their prior current-source producer records are verified
by audit.py/.log; those source hashes were not resampled during these builds.
Foundation and Mathlib direct inputs are object-pinned. Other project,
Foundation and Mathlib transitive dependencies remain cached; no full current-
source closure is claimed. B separately uses this exact final Pow object and
its source-matched BinomExpansion client in a combined Sandwich-wrapper replay.

Target and all four clients pass in both phases. Sandwich and ControllerLift
object bytes match. TilingWord and BinomExpansion objects differ, without an
established cause. Target probes match 46 declaration/type/axiom reports and
28,967 default simp/13,163 instance entries. Paired client probes pin both the
Pow and client object before/after and match all TilingWord 18 declaration/type/
axiom reports and 29,733 simp/13,397 instances; BinomExpansion's 41 reports
and 29,034 simp/13,227 instances likewise match. These checks do not establish
equality of proof bodies, all persistent environment extensions, or untested
downstream behavior. Single shared-load baseline/final user CPU samples: Pow
12.68/12.46 s, Sandwich 11.20/11.14, ControllerLift 22.47/22.47, TilingWord
9.48/9.56, BinomExpansion 14.95/15.01. These are not general benchmarks. TilingWord
and BinomExpansion retain the same nine and two existing warnings in each phase;
other paired target/client builds have none.

The initial baseline Sandwich compiled against source-current but older
PowerRecovery 5f4cdf45…, before B's latest-Congruences refresh; its log, timing,
object and the original partial phase receipt are preserved in superseded/.
The initial TilingWord build failed because the overlay lacked TilingRows;
its error log, timing and receipt are preserved there too. After filling the
missing overlay and switching both phase PowerRecovery symlinks to the newer
source-current beaf71cc… provider, baseline Sandwich and remaining clients were
replayed and the selected baseline-records.json combines those retries with the
original Pow and ControllerLift builds. The superseded Sandwich's recorded
first-provider symlink was subsequently repointed; its resolved old provider,
not that current symlink, records the historical input. Final target was built
once, remains stable for B, and final-records.json combines its separately saved
final-target-records.json with final-client-records.json.

The first standalone nth_rw probe failed to close the algebraic goal and the
second linear_combination probe failed because that tactic was not imported;
exact sources and logs survive in probe-failed-{nth,linear}.{lean,log}. The
successful standalone probe has no before/after input receipt, so paired full
builds are the validation evidence.
