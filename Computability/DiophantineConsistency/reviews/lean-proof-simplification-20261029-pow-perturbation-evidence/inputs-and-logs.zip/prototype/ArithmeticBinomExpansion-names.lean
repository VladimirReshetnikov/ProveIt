import DiophantineConsistency.ArithmeticBinomExpansion
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticBinomExpansion).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticBinomExpansion" then
   logInfo m!"DECL {n}"
