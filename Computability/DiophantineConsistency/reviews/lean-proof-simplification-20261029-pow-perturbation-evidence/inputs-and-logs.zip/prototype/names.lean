import DiophantineConsistency.ArithmeticPow
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPow).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPow" then
   logInfo m!"DECL {n}"
