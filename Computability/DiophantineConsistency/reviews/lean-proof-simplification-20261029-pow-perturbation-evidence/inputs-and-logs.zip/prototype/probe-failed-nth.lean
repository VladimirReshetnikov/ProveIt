import DiophantineConsistency.ArithmeticPow
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (a e r : V) (h : 2*r*e≤a) :
    a*(a+2*(r+1)*e)=(a+2*r*e)*(a+e)+e*(a-2*r*e) := by
  have hd : 2*r*e+(a-2*r*e)=a := add_tsub_cancel_of_le h
  nth_rw 1 [← hd]
  ring
