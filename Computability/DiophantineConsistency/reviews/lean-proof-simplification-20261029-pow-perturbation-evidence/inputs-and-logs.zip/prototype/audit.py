from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/pow-perturbation');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
items=[('ArithmeticPellPowerRecovery','/tmp/four-positive-wrappers/upstream-records.json'),('ArithmeticModularCancellation','/tmp/shared-modular-cancel/records.json'),('ArithmeticTilingBand','/tmp/tiling-band-dispatch/final-records.json'),('ArithmeticBinomPascal','/tmp/outer-seed-bound-sharing/prereq2-records.json')];providers={}
for n,f in items:
 x=next(x for x in load(f) if x['module'].split('.')[-1]==n and x['status']==0 and x.get('object_sha256'));b=x.get('before') or x.get('source_before') or x.get('source_sha256');a=x.get('after') or x.get('source_after');assert b==a==h(W/f'{n}.lean');providers[n]=x['object_sha256']
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticPow','ArithmeticHalfBinomialSandwich','ArithmeticControllerLift','ArithmeticTilingWord','ArithmeticBinomExpansion']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if x['module']!='ArithmeticPow':assert x['before']==h(W/f"{x['module']}.lean")
  else:
   rev='a37047cc30^' if ph=='baseline' else 'a37047cc30'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPow.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert h(W/'ArithmeticPow.lean')==x['before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticPow':assert d['before']==rr[0]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
for client in ('ArithmeticTilingWord','ArithmeticBinomExpansion'):
 rows=load(R/f'{client}-probe-records.json');assert len(rows)==8
 for x in rows:
  rr=records[x['phase']];c=next(z for z in rr if z['module']==client)
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[rr[0]['object_sha256'],c['object_sha256']] and x['log_sha256']==h(x['log'])
 for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{client}-{n}.log').read_bytes()==(R/f'final-{client}-{n}.log').read_bytes()
for n in ('ArithmeticHalfBinomialSandwich','ArithmeticControllerLift'):assert next(x for x in records['baseline'] if x['module']==n)['object_sha256']==next(x for x in records['final'] if x['module']==n)['object_sha256']
old=load(R/'superseded/baseline-records.json');assert [x['status'] for x in old]==[0,0,0,1]
assert old[1]['object_sha256']==h(R/'superseded/baseline-ArithmeticHalfBinomialSandwich.olean') and old[1]['log_sha256']==h(R/'superseded/baseline-ArithmeticHalfBinomialSandwich.log')
assert old[3]['log_sha256']==h(R/'superseded/baseline-ArithmeticTilingWord.log') and 'ArithmeticTilingRows.olean' in (R/'superseded/baseline-ArithmeticTilingWord.log').read_text()
print('PASS paired target/four clients, direct-provider producer matches, target/differing-client probes')
