import DiophantineConsistency.ArithmeticHalfBinomialSandwich
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticHalfBinomialSandwich).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticHalfBinomialSandwich" then
   logInfo m!"DECL {n}"
