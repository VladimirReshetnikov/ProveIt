import DiophantineConsistency.ArithmeticHalfBinomialSandwich
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticHalfBinomialSandwich).isPrefixOf n ||
       (toString n).startsWith "_private.DiophantineConsistency.ArithmeticHalfBinomialSandwich" then
      let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let ax ← Lean.collectAxioms n
      logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
