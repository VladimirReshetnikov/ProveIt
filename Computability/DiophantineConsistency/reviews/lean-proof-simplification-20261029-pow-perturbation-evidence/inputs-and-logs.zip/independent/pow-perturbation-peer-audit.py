from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/pow-perturbation');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticPow.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticPow.lean').read_text()
old='''    calc
      a*(a+2*(r+1)*e)=(2*r*e+(a-2*r*e))*((2*r*e+(a-2*r*e))+2*(r+1)*e) := by rw [hd]
      _=((2*r*e+(a-2*r*e))+2*r*e)*((2*r*e+(a-2*r*e))+e)+e*(a-2*r*e) := by ring
      _=(a+2*r*e)*(a+e)+e*(a-2*r*e) := by rw [hd]'''
new='''    rw [← hd]
    simp only [add_tsub_cancel_left]
    ring'''
assert b.count(old)==1 and b.replace(old,new)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPow.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('a37047cc30^')==b and gitfile('a37047cc30')==f and (W/'ArithmeticPow.lean').read_text()==f
print('PASS exact proof replacement; commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticPow$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(s).stem for s in clients)==['ArithmeticBinomExpansion','ArithmeticControllerLift','ArithmeticHalfBinomialSandwich','ArithmeticTilingWord']
print('PASS scoped direct clients',clients)
paths={'ArithmeticPellPowerRecovery':('/tmp/four-positive-wrappers/upstream-records.json','ArithmeticPellPowerRecovery'),'ArithmeticModularCancellation':('/tmp/shared-modular-cancel/records.json','ArithmeticModularCancellation'),'ArithmeticTilingBand':('/tmp/tiling-band-dispatch/final-records.json','ArithmeticTilingBand'),'ArithmeticBinomPascal':('/tmp/outer-seed-bound-sharing/prereq2-records.json','ArithmeticBinomPascal')};providers={}
for n,(path,key) in paths.items():
 x=next(x for x in read(path) if x['module'].split('.')[-1]==key);a=x.get('before') or x.get('source_before') or x.get('source_sha256');z=x.get('after') or x.get('source_after');assert x['status']==0 and a==z==h(W/(n+'.lean'));providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,a,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticPow','ArithmeticHalfBinomialSandwich','ArithmeticControllerLift','ArithmeticTilingWord','ArithmeticBinomExpansion'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticPow':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticPow':assert d['before']==rec[phase][n]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
   else:assert d['module'] in ['Foundation.FirstOrder.Arithmetic.HFS.PRF','Mathlib.Tactic.Ring']
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticHalfBinomialSandwich','ArithmeticControllerLift'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS direct producer mappings; two unchanged client object pairs, two differing clients require probes')
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticPow']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
for client in ('ArithmeticTilingWord','ArithmeticBinomExpansion'):
 rows=read(R/f'{client}-probe-records.json');assert len(rows)==8
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[x['phase']][n]['object_sha256'] for n in ('ArithmeticPow',client)] and x['log_sha256']==h(x['log'])
 for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{client}-{n}.log').read_bytes()==(R/f'final-{client}-{n}.log').read_bytes()
print('PASS target and both differing client namespace/type/axiom and registry reports, both-object pins')
s=read(R/'superseded/baseline-records.json');t=next(x for x in s if x['module']=='ArithmeticTilingWord');c=next(x for x in s if x['module']=='ArithmeticHalfBinomialSandwich');assert t['status']!=0 and t['log_sha256']==h(R/'superseded/baseline-ArithmeticTilingWord.log') and 'ArithmeticTilingRows.olean' in (R/'superseded/baseline-ArithmeticTilingWord.log').read_text()
assert c['status']==0 and c['object_sha256']==h(R/'superseded/baseline-ArithmeticHalfBinomialSandwich.olean') and c['log_sha256']==h(R/'superseded/baseline-ArithmeticHalfBinomialSandwich.log')
assert next(d for d in c['direct_inputs'] if d['module'].endswith('ArithmeticPellPowerRecovery'))['before'].startswith('5f4cdf45')
print('PASS preserved missing-TilingRows failure and superseded older-Pell Sandwich object')
