import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/divmod-proof-reuse-20261028');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','');lean='Computability/DiophantineConsistency/Lean';src=Path(lean)/'DiophantineConsistency'
jobs=[('QuadraticDivMod',str(src/'QuadraticDivMod.lean'),True),('ObjectDivModSyntax',str(src/'ObjectDivModSyntax.lean'),True),('QuadraticRegisterSystemCheck',lean+'/checks/QuadraticRegisterSystem.lean',False),('ObjectDivisionCheck',lean+'/checks/ObjectDivision.lean',False),('axioms',str(root/'axioms.lean'),False)]
out=[]
for tag,path,object_ in jobs:
 p=Path(path);cmd=['lean','-M6000','-j1','-DElab.async=false','-R',lean,str(p)];obj=root/phase/'DiophantineConsistency'/(tag+'.olean')
 if object_:cmd+=['-o',str(obj)]
 t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log=root/(phase+'-'+tag+'.log');log.write_bytes(v.stdout+v.stderr);q={'tag':tag,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if object_ and not v.returncode:q.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
 out.append(q);(root/(phase+'-records.json')).write_text(json.dumps(out,indent=2)+'\n');print(phase,tag,v.returncode,round(q['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
