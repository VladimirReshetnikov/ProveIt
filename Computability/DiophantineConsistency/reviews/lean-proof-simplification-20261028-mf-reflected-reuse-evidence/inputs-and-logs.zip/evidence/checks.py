import os,sys,subprocess,time,json,hashlib
from pathlib import Path
r=Path('/tmp/mf-reflected-geometry-reuse');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+env.get('LEAN_PATH','');jobs=[('axioms',str(r/'axioms.lean')),('foundation',str(r/'foundation.lean'))];out=[]
for tag,path in jobs:
 p=Path(path);cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p)];t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log=r/(phase+'-'+tag+'.log');log.write_bytes(v.stdout+v.stderr);x={'tag':tag,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};out.append(x);(r/(phase+'-checks.json')).write_text(json.dumps(out,indent=2)+'\n');print(phase,tag,v.returncode,flush=True)
