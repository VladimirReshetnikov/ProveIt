import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/mf-reflected-geometry-reuse');env=os.environ.copy();env['LEAN_PATH']=str(root/'overlay')+':'+env.get('LEAN_PATH','');src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');order=['MFCurrentMasks2011','MFNativeMaskPopulation','MFNativeRadixDigits','MFPaper1982Section4','MFNativeSourceMask','MFNativeVariableMask','MFCurrentHighDigits2011','MFCurrentClause2011'];records=[]
for n in order:
 p=src/(n+'.lean');o=root/'overlay/DiophantineConsistency'/(n+'.olean');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p),'-o',str(o)]
 t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log=root/('pre-'+n+'.log');log.write_bytes(v.stdout+v.stderr);q={'tag':n,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if not v.returncode:q.update(object_sha256=hashlib.sha256(o.read_bytes()).hexdigest(),object_bytes=o.stat().st_size)
 records.append(q);(root/'pre-records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,v.returncode,round(q['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
