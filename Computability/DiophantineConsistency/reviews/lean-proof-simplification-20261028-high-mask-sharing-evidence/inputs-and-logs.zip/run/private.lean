import DiophantineConsistency.CurrentWordHighMask2011
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    if n.toString.startsWith "_private.DiophantineConsistency.CurrentWordHighMask2011." then
      let axs ← collectAxioms n
      logInfo m!"PRIVATE {n}\nTYPE {c.type}\nAXIOMS {axs}"
