import DiophantineConsistency.CurrentWordHighMask2011
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n0 := `DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_1: {t.isLemma (.decl n0 true false)} {t.isLemma (.decl n0 false false)} {t.isLemma (.decl n0 true true)} {t.isLemma (.decl n0 false true)}"
  let n1 := `DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_2
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_2: {t.isLemma (.decl n1 true false)} {t.isLemma (.decl n1 false false)} {t.isLemma (.decl n1 true true)} {t.isLemma (.decl n1 false true)}"
  let n2 := `DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_3
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_3: {t.isLemma (.decl n2 true false)} {t.isLemma (.decl n2 false false)} {t.isLemma (.decl n2 true true)} {t.isLemma (.decl n2 false true)}"
  let n3 := `DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_4
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_4: {t.isLemma (.decl n3 true false)} {t.isLemma (.decl n3 false false)} {t.isLemma (.decl n3 true true)} {t.isLemma (.decl n3 false true)}"
  let n4 := `DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_5
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_5: {t.isLemma (.decl n4 true false)} {t.isLemma (.decl n4 false false)} {t.isLemma (.decl n4 true true)} {t.isLemma (.decl n4 false true)}"
  let n5 := `DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_6
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.cell_mask_pass._proof_6: {t.isLemma (.decl n5 true false)} {t.isLemma (.decl n5 false false)} {t.isLemma (.decl n5 true true)} {t.isLemma (.decl n5 false true)}"
  let n6 := `DiophantineConsistency.CurrentWordHighMask2011.cell_representation._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.cell_representation._proof_1: {t.isLemma (.decl n6 true false)} {t.isLemma (.decl n6 false false)} {t.isLemma (.decl n6 true true)} {t.isLemma (.decl n6 false true)}"
  let n7 := `DiophantineConsistency.CurrentWordHighMask2011.gap_mask_zero._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordHighMask2011.gap_mask_zero._proof_1: {t.isLemma (.decl n7 true false)} {t.isLemma (.decl n7 false false)} {t.isLemma (.decl n7 true true)} {t.isLemma (.decl n7 false true)}"
