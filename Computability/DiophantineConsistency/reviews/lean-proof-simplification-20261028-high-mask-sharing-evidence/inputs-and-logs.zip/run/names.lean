import DiophantineConsistency.CurrentWordHighMask2011
open Lean Elab Command
run_cmd do
 for (n, _) in (← getEnv).constants.toList do
  if (`DiophantineConsistency.CurrentWordHighMask2011).isPrefixOf n then logInfo m!"{n}"
