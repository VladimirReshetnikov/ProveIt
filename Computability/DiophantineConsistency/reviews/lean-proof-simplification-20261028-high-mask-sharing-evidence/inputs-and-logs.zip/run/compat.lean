import DiophantineConsistency.CurrentWordHighMask2011
import DiophantineConsistency.MFCurrentWordHighMask2011
open DiophantineConsistency
example {N : ℕ} [NeZero N] {s : ℤ} {a : ZMod N → Fin 942}
    (h : WangTiles942Periodic.MarkedWord N s a) :
    MF.WangTiles942Periodic.MarkedWord N s a :=
  ⟨h.start_at_zero, h.horizontal, h.temporal⟩
example {N : ℕ} [NeZero N] {s : ℤ} {a : ZMod N → Fin 942}
    (h : MF.WangTiles942Periodic.MarkedWord N s a) :
    WangTiles942Periodic.MarkedWord N s a :=
  ⟨h.start_at_zero, h.horizontal, h.temporal⟩
example {n : ℕ} [NeZero n] (c : ZMod n → ℕ) (W : ℕ) (k digits : ZMod n → ℕ)
    (h : CurrentCarryConstruction2011.Facts c W k digits) :
    MF.CurrentCarryConstruction2011.Facts c W k digits :=
  ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
example {n : ℕ} [NeZero n] (c : ZMod n → ℕ) (W : ℕ) (k digits : ZMod n → ℕ)
    (h : MF.CurrentCarryConstruction2011.Facts c W k digits) :
    CurrentCarryConstruction2011.Facts c W k digits :=
  ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
