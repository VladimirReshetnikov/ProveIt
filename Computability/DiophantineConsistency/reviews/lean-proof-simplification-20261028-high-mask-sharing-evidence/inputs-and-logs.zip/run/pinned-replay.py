from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/tmp/highmask-sharing');inv=json.loads((p/'coherent-inventory.json').read_text());g=json.loads((p/'graph-dummy.json').read_text());h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();envbase=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();reserve=850*1024**2;records=[]
exclude={'DiophantineConsistency.'+n for n in ('MFCurrentWordHighMask2011','CurrentWordHighMask2011','CurrentWordHighMask2011Checks','CurrentDummyMutation2011')}
for ph in ('baseline','final'):
 srcroot=p/('coherent-'+ph);root=p/('pinned-'+ph);root.mkdir(exist_ok=True)
 for d in srcroot.iterdir():
  if d.name=='DiophantineConsistency' or not d.is_dir():continue
  dst=root/d.name
  if not dst.exists():dst.symlink_to(d.resolve(),target_is_directory=True)
 dc=root/'DiophantineConsistency';dc.mkdir(exist_ok=True)
 for rec in inv['local']:
  n=rec['module']
  if not n.startswith('DiophantineConsistency.'):continue
  src=srcroot/(n.replace('.','/')+'.olean');dst=root/(n.replace('.','/')+'.olean');dst.unlink(missing_ok=True);dst.symlink_to(src.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+envbase
 checks=[]
 for rec in inv['local']:
  if rec['module'] in exclude:continue
  v=rec['phase'][ph];checks.append({'kind':'local','module':rec['module'],'source':v['source'],'source_sha256':v['source_sha256'],'object':v['object'],'object_sha256':v['object_sha256']})
 for x in inv['external']:checks.append({'kind':'external','module':x['module'],'object':x['object'],'object_sha256':x['object_sha256']})
 def audit():
  for x in checks:
   if 'source' in x:assert h(x['source'])==x['source_sha256'],('source drift',x['module'])
   assert h(x['object'])==x['object_sha256'],('object drift',x['module'])
  return hashlib.sha256(json.dumps(checks,sort_keys=True).encode()).hexdigest()
 for name in ('MFCurrentWordHighMask2011','CurrentWordHighMask2011','CurrentWordHighMask2011Checks','CurrentDummyMutation2011','interface','compat'):
  free=shutil.disk_usage(p).free
  if free<reserve+4*1024**2:raise RuntimeError(f'reserve before {ph} {name}: {free}')
  before=audit();prod=name not in ('interface','compat');target=name in ('MFCurrentWordHighMask2011','CurrentWordHighMask2011');src=(p/ph/'DiophantineConsistency'/f'{name}.lean') if target else (Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/f'{name}.lean' if prod else p/f'{name}.lean');out=root/'DiophantineConsistency'/f'{name}.olean' if prod else None
  if out:out.unlink(missing_ok=True)
  tm=p/f'{ph}-pinned-{name}.time';log=p/f'{ph}-pinned-{name}.log';srcdir=str(p/ph) if target else ('Computability/DiophantineConsistency/Lean' if prod else str(p));cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',srcdir,str(src)]+(['-o',str(out)] if out else []);sh=h(src);start=time.monotonic()
  with log.open('wb') as z:rc=subprocess.run(cmd,env=env,stdout=z,stderr=subprocess.STDOUT).returncode
  after=audit();rec={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src.resolve()),'source_sha256':sh,'source_after':h(src),'input_count':len(checks),'input_digest_before':before,'input_digest_after':after,'object':str(out) if out else None,'object_sha256':h(out) if out and out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-start,3),'free_before':free,'free_after':shutil.disk_usage(p).free};records.append(rec);(p/'pinned-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True)
  assert rc==0 and sh==rec['source_after'] and before==after
  if out:assert h(out)==h(srcroot/'DiophantineConsistency'/f'{name}.olean'),('object mismatch',name,ph)
