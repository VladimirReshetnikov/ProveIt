from pathlib import Path
import os,subprocess,time,hashlib,json
p=Path('/tmp/highmask-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for ph in ('baseline',):
 env=os.environ.copy();env['LEAN_PATH']=str(p/('coherent-'+ph))+':'+base
 for name in ('simp',):
  f=p/f'{name}.lean';tm=p/f'{ph}-coherent-{name}.time';log=p/f'{ph}-coherent-{name}.log';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p),str(f)];before=h(f);start=time.monotonic()
  with log.open('wb') as out:rc=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
  rec={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(f),'source_sha256':before,'source_after':h(f),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-start,3)};records.append(rec);(p/'simp-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True)
  assert before==rec['source_after']
  if name not in ('foundation-normal-first','foundation-foundation-first') and rc:raise SystemExit(1)
