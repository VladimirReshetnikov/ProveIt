from pathlib import Path
import hashlib,json,subprocess
p=Path('/tmp/highmask-sharing');g=json.loads((p/'graph-dummy.json').read_text());base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip().split(':');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();rows=[];external=[];issues=[];targets={'DiophantineConsistency.CurrentWordHighMask2011','DiophantineConsistency.MFCurrentWordHighMask2011'}
for m,v in g['nodes'].items():
 entry={'module':m,'imports':v['imports'],'phase':{}}
 for ph in ('baseline','final'):
  root=p/('coherent-'+ph);src=(p/ph/(m.replace('.','/')+'.lean')) if m in targets else Path(v['source']);obj=root/(m.replace('.','/')+'.olean')
  if not src.exists() or not obj.exists():issues.append([m,ph,'missing',str(src),str(obj)]);continue
  entry['phase'][ph]={'source':str(src.resolve()),'source_sha256':h(src),'object':str(obj.resolve()),'object_sha256':h(obj)}
 rows.append(entry)
for m in g['external']:
 found=None
 for d in base:
  x=Path(d)/(m.replace('.','/')+'.olean')
  if x.exists():found=x.resolve();break
 if found is None:issues.append([m,'external missing']);continue
 external.append({'module':m,'object':str(found),'object_sha256':h(found)})
for e in rows:
 if len(e['phase'])==2 and e['module'] not in targets and e['phase']['baseline']['object_sha256']!=e['phase']['final']['object_sha256']:print('phase-object-difference',e['module'])
d={'local':rows,'external':external,'issues':issues};(p/'coherent-inventory.json').write_text(json.dumps(d,indent=2)+'\n');print('local',len(rows),'external',len(external),'issues',len(issues));
if issues: print(issues[:10]);raise SystemExit(1)
