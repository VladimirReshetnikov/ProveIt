from pathlib import Path
import re,json,tomllib,hashlib
p=Path('/tmp/highmask-sharing');W=Path.cwd();roots=list(dict.fromkeys((W/x.get('srcDir','.')).resolve() for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']));h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(f):
 out=[]
 for line in strip(Path(f).read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out
G={};E=set();issues=[]
def visit(n):
 if n in G or n in E:return
 if n in ('DiophantineConsistency.CurrentWordHighMask2011','DiophantineConsistency.MFCurrentWordHighMask2011'):f=p/'final'/(n.replace('.','/')+'.lean')
 else:
  loc=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
  if not loc:E.add(n);return
  if len(loc)!=1:issues.append(['ambiguous',n]);return
  f=loc[0]
 im=imports(f);G[n]={'source':str(f),'sha256':h(f),'imports':im}
 for d in im:visit(d)
for n in ('CurrentWordHighMask2011','MFCurrentWordHighMask2011','CurrentDummyMutation2011','CurrentWordHighMask2011Checks'):visit('DiophantineConsistency.'+n)
order=[];visiting=set();visited=set()
def dfs(n):
 if n in visited or n not in G:return
 if n in visiting:issues.append(['cycle',n]);return
 visiting.add(n)
 for m in G[n]['imports']:dfs(m)
 visiting.remove(n);visited.add(n);order.append(n)
for n in G:dfs(n)
(p/'graph-dummy.json').write_text(json.dumps({'nodes':G,'external':sorted(E),'order':order,'issues':issues},indent=2)+'\n')
print(len(G),'local,',len(E),'external;',len(order),'sorted;',len(issues),'issues')
