from pathlib import Path
import os,subprocess,time,json,hashlib,shutil
p=Path('/tmp/highmask-sharing');g=json.loads((p/'graph-dummy.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];reserve=850*1024**2
for phase in ('baseline','final'):
 root=p/('coherent-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+base
 for name in ('MFCurrentWordHighMask2011','CurrentWordHighMask2011','CurrentWordHighMask2011Checks','CurrentDummyMutation2011'):
  free=shutil.disk_usage(p).free
  if free<reserve+4*1024**2:raise RuntimeError(f'disk reserve: {free} bytes free before {phase} {name}')
  module='DiophantineConsistency.'+name;source=(p/phase/'DiophantineConsistency'/f'{name}.lean') if name in ('MFCurrentWordHighMask2011','CurrentWordHighMask2011') else Path(g['nodes'][module]['source']);out=root/'DiophantineConsistency'/f'{name}.olean';out.unlink(missing_ok=True)
  direct=[]
  for dep in g['nodes'][module]['imports']:
   if dep not in g['nodes']:continue
   path=root/(dep.replace('.','/')+'.olean');assert path.exists(),(module,dep,path)
   direct.append({'module':dep,'path':str(path.resolve()),'sha256':h(path)})
  envpath=env['LEAN_PATH'];tm=p/f'{phase}-coherent-{name}.time';log=p/f'{phase}-coherent-{name}.log';srcroot=str(p/phase) if name in ('MFCurrentWordHighMask2011','CurrentWordHighMask2011') else 'Computability/DiophantineConsistency/Lean'
  cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',srcroot,str(source),'-o',str(out)];before=h(source);start=time.monotonic()
  with log.open('wb') as z:rc=subprocess.run(cmd,env=env,stdout=z,stderr=subprocess.STDOUT).returncode
  after=[{'module':x['module'],'path':x['path'],'sha256':h(x['path'])} for x in direct];rec={'phase':phase,'module':module,'status':rc,'command':cmd,'lean_path':envpath,'source':str(source.resolve()),'source_sha256':before,'source_after':h(source),'direct_inputs':direct,'direct_inputs_after':after,'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-start,3),'free_before':free,'free_after':shutil.disk_usage(p).free};records.append(rec);(p/'coherent-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,rc,flush=True)
  assert rc==0 and before==rec['source_after'] and direct==after
