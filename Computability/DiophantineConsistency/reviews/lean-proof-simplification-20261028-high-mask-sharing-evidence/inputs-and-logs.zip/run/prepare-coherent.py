from pathlib import Path
import json,hashlib,shutil
p=Path('/tmp/highmask-sharing');g=json.loads((p/'graph-dummy.json').read_text());base=Path('/tmp/word-origin-sharing/pinned-final');inv=json.loads(Path('/tmp/word-origin-sharing/inventory.json').read_text());prev={x['module']:x for x in inv['local']};h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();reserve=850*1024**2
assert shutil.disk_usage(p).free>reserve+8*1024**2
n='DiophantineConsistency.NativeRankVariation';r=next(x for x in json.loads(Path('/tmp/kernel-residues-sharing/coherent-refresh-records.json').read_text()) if x['module']==n);carrier=base/'DiophantineConsistency/Carrier65.olean';assert h(carrier)==r['direct_inputs'][0]['sha256'] and h(r['source'])==r['source_sha256'] and h(r['object'])==r['object_sha256']
roots=('CurrentWordHighMask2011','MFCurrentWordHighMask2011','CurrentWordHighMask2011Checks','CurrentDummyMutation2011');pins=[]
for ph in ('baseline','final'):
 root=p/('coherent-'+ph);root.mkdir(exist_ok=True)
 for d in base.iterdir():
  if d.name=='DiophantineConsistency' or not d.is_dir():continue
  dst=root/d.name
  if not dst.exists():dst.symlink_to(d.resolve(),target_is_directory=True)
 dc=root/'DiophantineConsistency';dc.mkdir(exist_ok=True)
 for m,v in g['nodes'].items():
  if not m.startswith('DiophantineConsistency.'):continue
  name=m.split('.')[-1];src=base/'DiophantineConsistency'/(name+'.olean')
  if m==n:src=Path(r['object'])
  if name in roots:continue
  assert src.exists(),m
  if m in prev:
   rec=prev[m]['phase']['final'];assert h(v['source'])==rec['source_sha256']==h(rec['source']),(m,'source');assert h(src)==rec['object_sha256'],(m,'object')
  dst=dc/(name+'.olean');dst.unlink(missing_ok=True);dst.symlink_to(src.resolve())
  pins.append({'phase':ph,'module':m,'source':v['source'],'source_sha256':h(v['source']),'object':str(dst.resolve()),'object_sha256':h(dst),'source_type':'origin-inventory' if m in prev else 'kernel-refresh'})
(p/'coherent-preparation-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('prepared',len(pins),'project object links; free',shutil.disk_usage(p).free)
