from pathlib import Path
import os,subprocess,json,hashlib,time
p=Path('/tmp/highmask-sharing');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();r=[]
for ph in ('baseline','final'):
 root=p/ph
 for name in ('interface',):
  src=p/f'{name}.lean';out=root/'DiophantineConsistency'/f'{name}.olean';out.unlink(missing_ok=True)
  env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+base;log=p/f'{ph}-preliminary-{name}.log';tm=p/f'{ph}-preliminary-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p),str(src),'-o',str(out)]
  before=h(src);t=time.monotonic()
  with log.open('wb') as z:rc=subprocess.run(cmd,env=env,stdout=z,stderr=subprocess.STDOUT).returncode
  rec={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source_sha256':before,'source_after':h(src),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,3)};r.append(rec);(p/'preliminary-interface-records.json').write_text(json.dumps(r,indent=2)+'\n');print(ph,name,rc,flush=True)
  if rc or rec['source_after']!=before:raise SystemExit(1)
