from pathlib import Path
import json,hashlib
p=Path('/tmp/highmask-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();ct=0
for fn in ('coherent-records.json','probe-records.json','simp-records.json'):
 for r in json.loads((p/fn).read_text()):
  ph=r['phase'];name=r.get('name',r.get('module','').split('.')[-1]);cmd=r['command'];exp=1 if name in ('foundation-normal-first','foundation-foundation-first') else 0
  assert r['status']==exp,(ph,name,r['status']);assert h(r['source'])==r['source_sha256']==r['source_after'];assert h(cmd[4])==r['time_sha256'];assert h(p/(ph+'-coherent-'+name+'.log'))==r['log_sha256'];assert r['lean_path'].split(':')[0]==str(p/('coherent-'+ph))
  if r.get('object'):
   assert cmd[-2]=='-o' and h(r['object'])==r['object_sha256'];assert r['direct_inputs']==r['direct_inputs_after']
   for d in r['direct_inputs']:assert h(d['path'])==d['sha256'],(name,d['module'])
  ct+=1
 print(fn,'checked')
print('total records',ct)
