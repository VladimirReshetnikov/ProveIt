from pathlib import Path
import json,hashlib
p=Path('/tmp/highmask-sharing');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();i=json.loads((p/'coherent-inventory.json').read_text());rs=json.loads((p/'pinned-records.json').read_text());assert len(i['local'])==171 and len(i['external'])==65 and not i['issues'] and len(rs)==12
exclude={'DiophantineConsistency.'+n for n in ('MFCurrentWordHighMask2011','CurrentWordHighMask2011','CurrentWordHighMask2011Checks','CurrentDummyMutation2011')}
for ph in ('baseline','final'):
 checks=[]
 for x in i['local']:
  v=x['phase'][ph];assert h(v['source'])==v['source_sha256'],(ph,x['module'],'source');assert h(v['object'])==v['object_sha256'],(ph,x['module'],'object')
  if x['module'] not in exclude:checks.append({'kind':'local','module':x['module'],'source':v['source'],'source_sha256':v['source_sha256'],'object':v['object'],'object_sha256':v['object_sha256']})
 for x in i['external']:
  assert h(x['object'])==x['object_sha256'],x['module'];checks.append({'kind':'external','module':x['module'],'object':x['object'],'object_sha256':x['object_sha256']})
 digest=hashlib.sha256(json.dumps(checks,sort_keys=True).encode()).hexdigest()
 for r in (z for z in rs if z['phase']==ph):
  c=r['command'];name=r['name'];assert r['status']==0 and h(r['source'])==r['source_sha256']==r['source_after'] and h(c[4])==r['time_sha256'] and h(p/(ph+'-pinned-'+name+'.log'))==r['log_sha256'];assert r['lean_path'].split(':')[0]==str(p/('pinned-'+ph));assert r['input_count']==len(checks) and r['input_digest_before']==r['input_digest_after']==digest
  if r['object'] is not None:assert c[-2]=='-o' and h(r['object'])==r['object_sha256']==h(p/('coherent-'+ph)/'DiophantineConsistency'/(name+'.olean'))
 print(ph,'checks',len(checks),'six pinned build/probe records validated')
print('all source/object hashes and phase digests revalidated')
