from pathlib import Path
import json,hashlib
p=Path('/tmp/highmask-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();r=json.loads((p/'coherent-preparation-pins.json').read_text());assert len(r)==262
for x in r:
 assert h(x['source'])==x['source_sha256'],(x['phase'],x['module'],'source');assert h(x['object'])==x['object_sha256'],(x['phase'],x['module'],'object')
print('262 prior origin/kernel preparation source/object pins verified')
