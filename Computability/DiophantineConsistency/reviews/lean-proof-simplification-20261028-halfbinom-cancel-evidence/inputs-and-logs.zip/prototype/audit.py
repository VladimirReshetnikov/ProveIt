from pathlib import Path
import json,hashlib
r=Path('/tmp/halfbinom-cancel');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
for ph in ('baseline','final'):
 xs=json.loads((r/f'{ph}-records.json').read_text());assert len(xs)==3
 for x in xs:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
  if ph=='baseline' or x['module']!='ArithmeticHalfBinomial':assert x['before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
   if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
   if d['module'].endswith('ArithmeticHalfBinomial'):assert d['resolved']==str(r/ph/'DiophantineConsistency/ArithmeticHalfBinomial.olean')
  rows.append(x);print('build',ph,x['module'],len(x['direct_inputs']),'inputs verified')
 for n in ('names','interfaces','private','global-simp'):
  x=json.loads((r/f'{ph}-{n}-record.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log']);print('probe',ph,n,'verified')
for n in ('names','interfaces','private','global-simp'):assert (r/f'baseline-{n}.log').read_bytes()==(r/f'final-{n}.log').read_bytes();print(n,'identical')
for mod in ('ArithmeticHalfBinomial2011','ArithmeticOuterSeed'):assert next(x['object_sha256'] for x in rows if x['phase']=='baseline' and x['module']==mod)==next(x['object_sha256'] for x in rows if x['phase']=='final' and x['module']==mod);print('client',mod,'output identical')
f=json.loads((r/'initial-failed-records.json').read_text())[0];assert f['status']!=0 and h(r/'initial-failed.log')==f['log_sha256'] and h(r/'initial-failed.time')==f['time_sha256'];print('initial missing Foundation setup failure preserved')
print(len(rows),'builds',sum(len(x['direct_inputs']) for x in rows),'direct input occurrences')
