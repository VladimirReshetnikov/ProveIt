from pathlib import Path
import hashlib,json,subprocess,os,sys,re,time
r=Path('/tmp/halfbinom-cancel');phase=sys.argv[1];src=r/'snapshots'/phase;out=r/phase;env=os.environ.copy();env['LEAN_PATH']=str(out)+':/tmp/mask-ins-simplify/final:'+env['LEAN_PATH'];H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rs=[]
for n in ['ArithmeticHalfBinomial','ArithmeticHalfBinomial2011','ArithmeticOuterSeed']:
 p=src/'DiophantineConsistency'/f'{n}.lean';ws=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');o=out/'DiophantineConsistency'/f'{n}.olean';log=r/f'{phase}-{n}.log';tm=r/f'{phase}-{n}.time';deps=[]
 for m in re.findall(r'^import\s+([^\s]+)',p.read_text(),re.M):
  rel=m.replace('.','/')+'.olean';obj=next(Path(d)/rel for d in env['LEAN_PATH'].split(':') if (Path(d)/rel).is_file());root='Computability/DiophantineConsistency/Lean' if m.startswith('DiophantineConsistency.') else 'Computability/BusyBeaver/Lean';sp=Path(root)/(m.replace('.','/')+'.lean');deps.append({'module':m,'path':str(obj),'resolved':str(obj.resolve()),'before':H(obj),'source':str(sp) if sp.is_file() else None,'source_before':H(sp) if sp.is_file() else None})
 before=H(p);wsbefore=H(ws);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(src),str(p),'-o',str(o)];t=time.monotonic()
 with log.open('wb') as f:x=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['after']=H(d['path']);d['source_after']=H(d['source']) if d['source'] else None
 rec={'phase':phase,'module':n,'status':x.returncode,'source':str(p),'before':before,'after':H(p),'workspace':str(ws),'workspace_before':wsbefore,'workspace_after':H(ws),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'object':str(o),'object_sha256':H(o) if o.exists() else None,'log':str(log),'log_sha256':H(log),'time':str(tm),'time_sha256':H(tm),'timing':tm.read_text().strip(),'elapsed':round(time.monotonic()-t,2)};rs.append(rec);(r/f'{phase}-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,n,x.returncode,rec['timing'],flush=True)
 if x.returncode or rec['before']!=rec['after'] or rec['workspace_before']!=rec['workspace_after'] or any(d['before']!=d['after'] or d['source_before']!=d['source_after'] for d in deps):sys.exit(1)
