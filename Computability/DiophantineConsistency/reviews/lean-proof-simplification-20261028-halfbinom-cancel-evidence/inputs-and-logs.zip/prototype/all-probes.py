import subprocess,sys
for ph in ('baseline','final'):
 for name in ('interfaces','private','global-simp'):
  subprocess.run([sys.executable,'/tmp/halfbinom-cancel/probe.py',ph,name],check=True)
