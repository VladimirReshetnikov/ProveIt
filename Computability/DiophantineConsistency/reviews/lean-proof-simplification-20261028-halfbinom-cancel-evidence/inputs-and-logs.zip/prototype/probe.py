from pathlib import Path
import os,subprocess,hashlib,json,sys
r=Path('/tmp/halfbinom-cancel');phase=sys.argv[1];typ=sys.argv[2];env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':/tmp/mask-ins-simplify/final:'+env['LEAN_PATH'];s=r/(typ+'.lean');o=r/phase/'DiophantineConsistency/ArithmeticHalfBinomial.olean';log=r/f'{phase}-{typ}.log';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();b=h(s);ob=h(o);cmd=['lean','-M10000','-j1','-DElab.async=false',str(s)]
with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
x={'phase':phase,'probe':typ,'status':q.returncode,'source':str(s),'source_before':b,'source_after':h(s),'object':str(o),'object_before':ob,'object_after':h(o),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'log':str(log),'log_sha256':h(log)};(r/f'{phase}-{typ}-record.json').write_text(json.dumps(x,indent=2)+'\n');print(phase,typ,q.returncode,flush=True)
if q.returncode:sys.exit(1)
