import DiophantineConsistency.ArithmeticHalfBinomial
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticHalfBinomial).isPrefixOf n ||
     (`_private.DiophantineConsistency.ArithmeticHalfBinomial).isPrefixOf n then
   logInfo m!"DECL {n}"
