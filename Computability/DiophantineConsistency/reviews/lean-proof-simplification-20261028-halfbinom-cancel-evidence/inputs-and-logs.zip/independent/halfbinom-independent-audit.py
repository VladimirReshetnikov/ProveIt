from pathlib import Path
import json,hashlib
R=Path('/tmp/halfbinom-cancel');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
import subprocess
commit='00971db6869bb48f1ca665b7206f7cd8c076ccbd'; target='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticHalfBinomial.lean'
def recorded_source_matches(path, recorded):
 if sha(path)==recorded:return True
 if str(path)==target:
  before=subprocess.check_output(['git','show',commit+'^:'+target]);final=subprocess.check_output(['git','show',commit+':'+target]);
  if hashlib.sha256(before).hexdigest()==recorded and sha(path)==hashlib.sha256(final).hexdigest():
   print('HISTORICAL WORKSPACE SOURCE',path,recorded,'CURRENT',sha(path));return True
 return False
old=json.load(open('/tmp/outer-seed-bound-sharing/prereq2-records.json'))
old+=json.load(open('/tmp/pell-construction-refresh/resumed-records.json'))
providers={}
for x in old:
 if x.get('status')==0:
  key=(x.get('module','').split('.')[-1],x.get('object_sha256'));providers.setdefault(key,[]).append(x)
for phase in ('baseline','final'):
 records=json.load(open(R/(phase+'-records.json')));built={x['module']:x['object_sha256'] for x in records}
 for x in records:
  assert x['status']==0 and x['before']==x['after']==sha(x['source'])
  assert x['workspace_before']==x['workspace_after'] and recorded_source_matches(x['workspace'],x['workspace_after'])
  assert x['object_sha256']==sha(x['object']) and x['log_sha256']==sha(x['log']) and x['time_sha256']==sha(x['time'])
  for d in x['direct_inputs']:
   assert d['before']==d['after']==sha(d['path']) and d['source_before']==d['source_after'] and recorded_source_matches(d['source'],d['source_after'])
   name=d['module'].split('.')[-1]
   if name in built:assert d['before']==built[name]
   else:
    receipts=providers.get((name,d['before']),[]);assert receipts,('missing receipt',name,d['before'])
    assert any((z.get('before') or z.get('source_sha256'))==d['source_before'] for z in receipts),('source mismatch',name)
    print('PROVIDER',phase,name,d['before'],d['source_before'])
  print('BUILD',phase,x['module'],x['status'],x['object_sha256'],x['timing'])
for p in sorted(R.glob('*-record.json')):
 x=json.load(p.open());assert x['status']==0 and x['source_before']==x['source_after']==sha(x['source'])
 assert x['object_before']==x['object_after']==sha(x['object']) and x['log_sha256']==sha(x['log'])
 print('PROBE',p.name,'OK')
for k in ('names','interfaces','private','global-simp'):
 a=R/('baseline-'+k+'.log');b=R/('final-'+k+'.log');assert a.read_bytes()==b.read_bytes(); print('MATCH',k,'lines',len(a.read_text().splitlines()),'sha',sha(a))
for m in ('ArithmeticHalfBinomial2011','ArithmeticOuterSeed'):
 a=R/'baseline/DiophantineConsistency'/(m+'.olean');b=R/'final/DiophantineConsistency'/(m+'.olean');assert sha(a)==sha(b);print('MATCH CLIENT',m,sha(a))
f=json.load(open(R/'initial-failed-records.json'))[0];assert f['status']!=0 and f['before']==sha(f['source']);assert f['log_sha256']==sha(R/'initial-failed.log') and f['time_sha256']==sha(R/'initial-failed.time')
print('INITIAL FAILURE preserved; log/time paths subsequently overwritten, copies match receipt')

for phase,ref in [('baseline',commit+'^'),('final',commit)]:
 p=R/'snapshots'/phase/'DiophantineConsistency/ArithmeticHalfBinomial.lean'
 b=subprocess.check_output(['git','show',ref+':'+target]); assert hashlib.sha256(b).hexdigest()==sha(p)
 print('GIT',phase,ref,'snapshot',sha(p),'workspace',sha(target),'matches',sha(p)==sha(target))
