from pathlib import Path
import hashlib,json,re,subprocess
r=Path('/dev/shm/legendre-parity');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec={}
for ph,names in [('common',['ArithmeticBinomFactorial']),('baseline',['ArithmeticBinomLegendre','ArithmeticHalfBinomial']),('final',['ArithmeticBinomLegendre','ArithmeticHalfBinomial'])]:
 rows=json.loads((r/(ph+'-records.json')).read_text());assert [x['module'] for x in rows]==names;rec[ph]={}
 for x in rows:
  rec[ph][x['module']]=x;assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'];assert x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n=='ArithmeticBinomFactorial':assert d['before']==rec['common'][n]['object_sha256']
   if n=='ArithmeticBinomLegendre':assert d['before']==rec[ph][n]['object_sha256']
  if ph!='final' or x['module']!='ArithmeticBinomLegendre':assert x['before']==h(w/(x['module']+'.lean'))
assert rec['baseline']['ArithmeticHalfBinomial']['object_sha256']==rec['final']['ArithmeticHalfBinomial']['object_sha256']
for p in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=json.loads((r/f'probe-{p}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[ph]['ArithmeticBinomLegendre']['object_sha256'] and x['log_sha256']==h(x['log']); assert Path(x['object'])==next(Path(q)/'DiophantineConsistency/ArithmeticBinomLegendre.olean' for q in x['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency/ArithmeticBinomLegendre.olean').is_file())
 assert (r/(f'baseline-{p}.log')).read_bytes()==(r/(f'final-{p}.log')).read_bytes()
for p,count in [('names',12),('interfaces',52),('simp',29039),('instances',13232)]:assert len((r/(f'baseline-{p}.log')).read_text().splitlines())==count
x=next(x for x in json.loads(Path('/tmp/binary-half-direct/final-records.json').read_text()) if x['module']=='ArithmeticBinaryPopulation'); d=next(x for x in rec['baseline']['ArithmeticBinomLegendre']['direct_inputs'] if x['module'].endswith('ArithmeticBinaryPopulation')); assert x['status']==0 and x['before']==x['after']==d['source_before'] and x['object_sha256']==d['before']
bl=(r/'baseline-ArithmeticBinomLegendre.log').read_text();fl=(r/'final-ArithmeticBinomLegendre.log').read_text();assert bl.count('warning:')==3 and fl.count('warning:')==1 and "try 'simp' instead of 'simpa'" in fl
print('PASS baseline/current source, phase objects and first paths, factorial current-source build, identical client, 8 target probes, two removed linter warnings, Population producer')
