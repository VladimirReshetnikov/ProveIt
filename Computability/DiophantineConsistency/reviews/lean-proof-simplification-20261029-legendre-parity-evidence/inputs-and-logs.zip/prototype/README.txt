ArithmeticBinomLegendre two_mul_ne_odd modulo simplification

The original proof in Claude-coauthored commit 90f67cbdd9 splits the order of
the two parameters and compares products. The final candidate compares both
sides modulo two; existing mod_mul_self_right and mod_mul_add_of_lt reduce the
remainders to 0 and 1. The final diff is 4 insertions and 10 deletions (six net
lines). Imports, theorem statement, hypotheses and definitions are unchanged.
Source snapshots are baseline/ and final/; baseline and final SHA-256 are
59003ec50ccd581989444a1510119865e9f7409ef0f3e9adc547c3bdb6767c55 and
5bda3c5c4cd8d4907dd59bd31238e5cbbacdc92af56a11ee268be8d62794009d.

Both paired target and sole tracked direct Lean client ArithmeticHalfBinomial
build successfully from these snapshots. Their client objects are byte-identical
(5213cd5dbfaefcab5f47a14d1e0fe4cb40ec522be4e37e1f05af92f043ea507d). Probes
pin the exact target objects from the final paired rows and find identical 12
target namespace declaration names, 52 type/axiom report lines, 29,039 global
default simp registration lines and 13,232 instance registration lines. These
checks are not equality of proof bodies or every persistent Lean extension. The
baseline emits three unnecessarySimpa linter warnings, two in the removed proof;
the final emits the remaining third warning. The first baseline/final target
user CPU times are 10.35/10.69 seconds, individual shared-load observations.

The common ArithmeticBinomFactorial direct provider was separately rebuilt
from current source. Its Pascal import matches a successful producer in
/tmp/outer-seed-bound-sharing/prereq2-records.json with current source pinned
before and after the build. BinaryPopulation matches its successful current-source
producer in /tmp/binary-half-direct/final-records.json. The client's other two
direct providers ArithmeticHalfBinomialSandwich and ArithmeticBinomExpansion
remain cached with no source/object producer found by the documented local
records search. Other transitive project/Foundation/Mathlib objects are cached;
no clean source-current closure or downstream compilation is claimed. All
source inputs, first object paths and hashes, outputs, logs and timing records
are in common/baseline/final-records.json. audit.py verifies unchanged source,
first object and probe pins, outputs, log hashes, client identity, Population's
producer association and exact probe comparisons. time files are recorded in
records, though not separately hashed. Build commands, Lean paths and probe
records are stored alongside them.

Exploratory proof attempts preceded the final version. An intermediate longer
variant was successfully built, then replaced in final/ with the shorter inline
variant. Its former final phase records, logs, probe reports and objects were
overwritten; long-variant.lean is preserved only as an exploratory snapshot,
not as independent validation. The current final files and probes all refer to
the shorter variant. Temporary files under /dev/shm are not permanent.
