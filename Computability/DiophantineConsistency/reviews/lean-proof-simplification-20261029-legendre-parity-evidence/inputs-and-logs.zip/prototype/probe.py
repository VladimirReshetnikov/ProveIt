from pathlib import Path
import json,subprocess,hashlib,os,sys
R=Path('/dev/shm/legendre-parity'); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for probe in sys.argv[1:]:
 for phase in ['baseline','final']:
  row=json.load(open(R/f'{phase}-records.json'))[0];obj=Path(row['object']);source=R/f'{probe}.lean';log=R/f'{phase}-{probe}.log';env=os.environ.copy();env['LEAN_PATH']=row['LEAN_PATH'];before=sha(source);ob=sha(obj);cmd=['lean','-M10000','-j1','-DElab.async=false',str(source)]
  with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  x=dict(probe=probe,phase=phase,status=p.returncode,command=cmd,LEAN_PATH=env['LEAN_PATH'],source=str(source),source_before=before,source_after=sha(source),object=str(obj),object_before=ob,object_after=sha(obj),log=str(log),log_sha256=sha(log));records.append(x);(R/f'probe-{probe}-{phase}.json').write_text(json.dumps(x,indent=2)+'\n');print(probe,phase,p.returncode,flush=True)
  if p.returncode:raise SystemExit(1)
