from pathlib import Path
import json,hashlib
r=Path('/dev/shm/legendre-parity');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); records={}
for phase in ['common','baseline','final']:
 records[phase]=json.loads((r/(phase+'-records.json')).read_text())
 for row in records[phase]:
  assert row['status']==0 and row['before']==row['after']==h(row['source']) and h(row['object'])==row['object_sha256'] and h(row['log'])==row['log_sha256']
  for d in row['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
for mod in ['ArithmeticBinomLegendre','ArithmeticHalfBinomial','ArithmeticBinomFactorial']:
 assert h(w/(mod+'.lean'))==h(r/'baseline/DiophantineConsistency'/(mod+'.lean'))
for mod in ['ArithmeticHalfBinomial','ArithmeticBinomFactorial']:
 assert h(w/(mod+'.lean'))==h(r/'final/DiophantineConsistency'/(mod+'.lean'))
assert records['baseline'][1]['object_sha256']==records['final'][1]['object_sha256']
for probe in ['names','interfaces','simp','instances']:
 for phase in ['baseline','final']:
  row=json.loads((r/f'probe-{probe}-{phase}.json').read_text()); assert row['status']==0 and row['source_before']==row['source_after']==h(row['source']) and row['object_before']==row['object_after']==h(row['object']) and h(row['log'])==row['log_sha256']; assert row['object_before']==records[phase][0]['object_sha256']
 assert (r/f'baseline-{probe}.log').read_bytes()==(r/f'final-{probe}.log').read_bytes()
matched=next(x for x in json.load(open('/tmp/binary-half-direct/final-records.json')) if x['module']=='ArithmeticBinaryPopulation')
d=next(x for x in records['baseline'][0]['direct_inputs'] if x['module'].endswith('ArithmeticBinaryPopulation'))
assert matched['status']==0 and matched['before']==matched['after']==d['source_before'] and matched['object_sha256']==d['before']
print('PASS paired sources, direct-object/log pins, client identity, target interfaces and Population producer')
