from pathlib import Path
import os,sys,json,hashlib,subprocess,re
r=Path('/dev/shm/legendre-parity');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');phase=sys.argv[1]; mods=sys.argv[2:];lib=r/('objects-'+phase);(lib/'DiophantineConsistency').mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=os.environ.copy();base=json.load(open('/dev/shm/cell-room-cancel/baseline-records.json'))[0]['LEAN_PATH'];env['LEAN_PATH']=str(lib)+(':'+str(r/'objects-common') if phase!='common' else '')+':'+base;records=[]
for n in mods:
 src=r/phase/'DiophantineConsistency'/(n+'.lean');inputs=[]
 for name in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());leaf=name.split('.')[-1];sp=r/phase/'DiophantineConsistency'/(leaf+'.lean') if leaf in mods else r/'common/DiophantineConsistency'/(leaf+'.lean') if leaf=='ArithmeticBinomFactorial' and phase!='common' else w/(leaf+'.lean');inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 out=lib/'DiophantineConsistency'/(n+'.olean');tm=r/(phase+'-'+n+'.time');log=r/(phase+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/phase),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'phase':phase,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};records.append(rec);(r/(phase+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
