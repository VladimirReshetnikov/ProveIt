from pathlib import Path
import os,json,time,hashlib,subprocess
R=Path('/tmp/outer-seed-bound-sharing');out=R/'common';ns=out/'DiophantineConsistency';g=json.load(open(R/'graph.json'));nodes=g['nodes'];previous={x['module']:x for x in json.load(open(R/'first-pass/records.json')) if x['status']==0};seed={'DiophantineConsistency.ArithmeticGcdNormalization'};affected=set(seed)
while True:
 b=affected|{n for n,v in nodes.items() if any(d in affected for d in v['imports'])}
 if b==affected:break
 affected=b
(R/'affected-plan.json').write_text(json.dumps({'seed':sorted(seed),'affected':sorted(affected),'order':g['order']},indent=2)+'\n');env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env.get('LEAN_PATH','');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[]
for mod in g['order']:
 name=mod.split('.')[-1]
 if name in ['ArithmeticOuterSeed','ArithmeticConstructionBoundPell']:continue
 src=Path(nodes[mod]['source']);obj=ns/(name+'.olean');old=previous.get(mod)
 if mod not in affected and old and obj.exists() and h(src)==old['source_sha256'] and h(obj)==old['object_sha256']:
  d={'module':mod,'status':0,'provenance':'first-pass','source_sha256':h(src),'object_sha256':h(obj)};rec.append(d);(R/'prereq2-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,'reused',flush=True);continue
 obj.unlink(missing_ok=True);log=R/('prereq2-'+name+'.log');tm=R/('prereq2-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(obj)];pre=h(src);t=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'module':mod,'provenance':'rebuilt','command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(obj) if obj.exists() else None};rec.append(d);(R/'prereq2-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,p.returncode,round(d['seconds'],2),flush=True)
 if p.returncode or pre!=d['source_after'] or pre!=nodes[mod]['source_sha256']:raise SystemExit(1)
