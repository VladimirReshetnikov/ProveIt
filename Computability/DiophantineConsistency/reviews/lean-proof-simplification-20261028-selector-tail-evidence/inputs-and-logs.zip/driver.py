import hashlib, json, os, subprocess, sys, time
from pathlib import Path
root=Path('/tmp/tail-reuse-20261028'); phase=sys.argv[1]; env=os.environ.copy(); env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
base=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean']
basepath='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
cmds=[('focus',base+[basepath+'CurrentSelectorTail2011Checks.lean']),('client',base+[basepath+'CurrentEarlyPadding2011.lean','-o',str(root/phase/'DiophantineConsistency/CurrentEarlyPadding2011.olean')]),('axioms',base+[str(root/'axioms.lean')])]
records=[]
for label,cmd in cmds:
 start=time.monotonic(); proc=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(root/f'{phase}-{label}.time')]+cmd,env=env,capture_output=True); elapsed=time.monotonic()-start
 log=root/f'{phase}-{label}.log';log.write_bytes(proc.stdout+proc.stderr)
 records.append({'label':label,'cmd':cmd,'status':proc.returncode,'seconds':elapsed,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(phase,label,'exit',proc.returncode,flush=True)
 if proc.returncode:break
(root/f'{phase}-records.json').write_text(json.dumps(records,indent=2)+'\n')
if len(records)!=len(cmds) or any(r['status'] for r in records):sys.exit(1)
