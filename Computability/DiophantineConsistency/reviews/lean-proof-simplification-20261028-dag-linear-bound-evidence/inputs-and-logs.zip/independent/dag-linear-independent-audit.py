import hashlib,json,re,subprocess
from pathlib import Path
R=Path('/tmp/dag-linear-bound-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
changed=['ArithmeticRuntimeBoundDagMacrosA','ArithmeticRuntimeBoundDagMacrosB']
for mod in changed:
 path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+mod+'.lean'
 for ref,phase in [('934bd5397f^','baseline'),('934bd5397f','final')]:
  contents=subprocess.check_output(['git','show',ref+':'+path]); assert contents==(R/'sources'/phase/'DiophantineConsistency'/(mod+'.lean')).read_bytes()
 assert Path(path).read_bytes()==(R/'sources'/'final'/'DiophantineConsistency'/(mod+'.lean')).read_bytes()
 print('verified commit, parent, and current workspace',mod)
def historic_source(path):
 name=Path(path).stem
 return R/'sources'/'baseline'/'DiophantineConsistency'/(name+'.lean') if name in changed else Path(path)
for phase in ['baseline','final']:
 rows[phase]=[]
 for suffix in ['records','client-records']:
  for x in json.loads((R/f'{phase}-{suffix}.json').read_text()):
   assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(historic_source(x['workspace']))
   if phase=='baseline' or x['module'] not in ['ArithmeticRuntimeBoundDagMacrosA','ArithmeticRuntimeBoundDagMacrosB']: assert x['source_before']==x['workspace_before']
   for k in ['object','log','time']: assert h(x[k])==x[k+'_sha256']
   for d in x['direct_inputs']:
    rel=d['module'].replace('.','/')+'.olean'; first=next(Path(p)/rel for p in x['LEAN_PATH'].split(':') if (Path(p)/rel).is_file()); assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(first) and d['source_before']==d['source_after']==h(historic_source(d['source']))
    local=next((z for z in rows[phase] if z['module']==d['module'].split('.')[-1]),None)
    if local: assert local['object_sha256']==d['object_before'] and local['object']==d['resolved']
   rows[phase].append(x);print(phase,x['module'],x['timing'])
 for suffix in ['probes','short-probes']:
  for x in json.loads((R/f'{phase}-{suffix}.json').read_text()):
   assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and h(x['log'])==x['log_sha256'] and h(x['time'])==x['time_sha256']
for i in [2,3,4]:assert rows['baseline'][i]['object_sha256']==rows['final'][i]['object_sha256']
for t in ['A','B']:
 def read(phase):
  s=(R/f'{phase}-{t}-interfaces.log').read_text(); blocks=re.split(r'(?m)(?=^DECL )',s);return {x.split(' TYPE ',1)[0]:x for x in blocks if x.strip()}
 a,b=read('baseline'),read('final');assert all(b[k]==v for k,v in a.items());assert len(b)-len(a)==(1 if t=='A' else 0)
 print(t,'declarations',len(a),len(b),'new',list(b.keys()-a.keys()))
 for p in ['simp','instances']:
  x=(R/f'baseline-{t}-{p}.log').read_bytes();y=(R/f'final-{t}-{p}.log').read_bytes();assert x==y;print(t,p,len(x.splitlines()))
assert not (R/'baseline-A-short.log').read_text() and (R/'final-A-short.log').read_text().strip()=="SHORT DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.lin_le'"
for file,module,phase,key in [('/tmp/dag-independent-audit/fol-refresh-records.json','BusyBeaver.ZFC.ArithmeticDagRootPerm222','shared','source_sha256'),('/tmp/dag-run-sharing/final-records.json','ArithmeticRuntimeBoundDagRun','final','before'),('/tmp/cantor-bound-simplify/build-records.json','ArithmeticEnumBoundTower','final','before')]:
 prior=next(x for x in json.loads(Path(file).read_text()) if x.get('module',x.get('name'))==module and x.get('phase')==phase and x.get('status')==0)
 for ph in ['baseline','final']:
  d=next(d for d in rows[ph][0]['direct_inputs'] if d['module'].split('.')[-1]==module.split('.')[-1]);assert (prior[key],prior['object_sha256'])==(d['source_before'],d['object_before'])
 print('matched prior',module,file)
print('all checks passed')
