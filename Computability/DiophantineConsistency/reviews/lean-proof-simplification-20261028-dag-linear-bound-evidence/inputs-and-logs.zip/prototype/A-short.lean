import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  let s := toString n
  if s == "lin_le'" || s.endsWith ".lin_le'" then
   logInfo m!"SHORT {n}"
