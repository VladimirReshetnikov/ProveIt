import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRuntimeBoundDagMacros).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA" ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosB" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
