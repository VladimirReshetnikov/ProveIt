from pathlib import Path
import json,hashlib,re
r=Path('/tmp/dag-linear-bound-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
prior={}
for file,n,phase,src in [('/tmp/dag-independent-audit/fol-refresh-records.json','BusyBeaver.ZFC.ArithmeticDagRootPerm222','shared','source_sha256'),('/tmp/dag-run-sharing/final-records.json','ArithmeticRuntimeBoundDagRun','final','before'),('/tmp/cantor-bound-simplify/build-records.json','ArithmeticEnumBoundTower','final','before')]:
 x=next(x for x in json.loads(Path(file).read_text()) if x.get('module',x.get('name'))==n and x.get('phase')==phase and x.get('status')==0);prior[n.split('.')[-1]]=(x[src],x['object_sha256'],file)
for ph in ('baseline','final'):
 for f in (f'{ph}-records.json',f'{ph}-client-records.json'):
  for x in json.loads((r/f).read_text()):
   assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
   if ph=='baseline' or x['module'] not in ('ArithmeticRuntimeBoundDagMacrosA','ArithmeticRuntimeBoundDagMacrosB'):assert x['source_before']==x['workspace_before']
   for d in x['direct_inputs']:
    rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(p) and d['source_before']==d['source_after']==h(d['source']);n=d['module'].split('.')[-1]
    if n in prior: assert (d['source_before'],d['object_before'])==prior[n][:2];print('provider',ph,n,prior[n][2])
    else:
     y=next(z for z in rows if z['phase']==ph and z['module']==n);assert d['resolved']==y['object'] and d['object_before']==y['object_sha256'];print('same-phase',ph,x['module'],n)
   rows.append(x);print('build',ph,x['module'],x['timing'])
 for f in (f'{ph}-probes.json',f'{ph}-short-probes.json'):
  for x in json.loads((r/f).read_text()):assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);print('probe',ph,x['name'])
for n in ('ArithmeticRuntimeBoundDagMacrosC','ArithmeticRuntimeBoundDagMacrosD','ArithmeticRuntimeBoundDagRootA'):
 a=next(x['object_sha256'] for x in rows if x['phase']=='baseline' and x['module']==n);b=next(x['object_sha256'] for x in rows if x['phase']=='final' and x['module']==n);assert a==b;print('identical client object',n,a)
def parse(p):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',p.read_text(),re.M|re.S)}
name="DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.lin_le'"
for t in ('A','B'):
 a=parse(r/f'baseline-{t}-interfaces.log');b=parse(r/f'final-{t}-interfaces.log');assert not a.keys()-b.keys() and all(a[n]==b[n] for n in a);assert b.keys()-a.keys()==({name} if t=='A' else set());print(t,'declarations',len(a),len(b),'new',sorted(b.keys()-a.keys()))
 for n in ('simp','instances'):a=(r/f'baseline-{t}-{n}.log').read_bytes();b=(r/f'final-{t}-{n}.log').read_bytes();assert a==b;print(t,n,'equal',len(a.splitlines()))
assert (r/'baseline-A-short.log').read_text()=='' and (r/'final-A-short.log').read_text().strip()=='SHORT '+name;print('A short-name census contains only moved theorem after change')
assert 'signal 2' in (r/'interrupted-baseline.time').read_text();print('interrupted preliminary baseline preserved')
