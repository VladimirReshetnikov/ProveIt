from pathlib import Path
import json,hashlib,subprocess,os,sys
r=Path('/tmp/dag-linear-bound-sharing');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=json.loads((r/(phase+'-records.json')).read_text())[0]['LEAN_PATH'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();results=[]
for n in ('A-interfaces','A-simp','A-instances','B-interfaces','B-simp','B-instances'):
 src=r/(n+'.lean'); obj=r/('objects-'+phase)/'DiophantineConsistency'/('ArithmeticRuntimeBoundDagMacros'+n[0]+'.olean'); log=r/(phase+'-'+n+'.log');tm=r/(phase+'-'+n+'.time');before=h(src);ob=h(obj)
 cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'name':n,'status':q.returncode,'source':str(src),'source_before':before,'source_after':h(src),'object':str(obj),'object_before':ob,'object_after':h(obj),'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm)};results.append(rec);(r/(phase+'-probes.json')).write_text(json.dumps(results,indent=2)+'\n');print(phase,n,q.returncode,tm.read_text().strip(),flush=True)
 if q.returncode or before!=h(src) or ob!=h(obj):sys.exit(1)
