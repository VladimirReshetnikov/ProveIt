from pathlib import Path
import hashlib,json
p=Path('/tmp/cell-construction-share'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[];counts={}
for fn,num in [('common-records.json',24),('client-common-records.json',5),('phase-records.json',8),('names-records.json',2),('probe-records.json',7)]:
 rs=json.loads((p/fn).read_text());counts[fn]=len(rs)
 if len(rs)!=num:issues.append([fn,'count',len(rs)])
 for r in rs:
  label=r.get('phase','')+':'+r.get('module',r.get('tag','names'));cmd=r['command'];phase=r.get('phase');
  if h(r['source'])!=r['source_sha256'] or r['source_sha256']!=r['source_after']:issues.append([fn,label,'source'])
  for field in ('log','time'):
   if h(r[field])!=r[field+'_sha256']:issues.append([fn,label,field])
  if Path(r['time']).read_text().strip()!=r['timing']:issues.append([fn,label,'timing'])
  if 'object' in r and (h(r['object'])!=r['object_sha256'] or cmd[-2:]!=['-o',r['object']] or not Path(r['object']).is_relative_to(Path(r['lean_path'].split(':')[0]))):issues.append([fn,label,'object/path'])
  fail=r.get('tag','').startswith('foundation-')
  if (r['status']!=0)!=fail:issues.append([fn,label,'status'])
  for d in r.get('direct_inputs',[]):
   if h(d['path'])!=d['sha256'] or d['sha256']!=d['after_sha256']:issues.append([fn,label,'input',d['module']])
for n in ('CurrentCellConstruction2011','MFCurrentCellConstruction2011'):
 a=p/'baseline/DiophantineConsistency'/(n+'.lean'); b=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean')
 if h(a)!=h(b):issues.append([n,'baseline/source mismatch'])
for n in ('CurrentCellConstruction2011','MFCurrentCellConstruction2011','CurrentCellConstruction2011Checks','CurrentWordConstruction2011','interface','foundation-normal-first','foundation-foundation-first'):
 if (p/('baseline-'+n+'.log')).read_bytes()!=(p/('final-'+n+'.log')).read_bytes():issues.append([n,'log differs'])
a={x[5:] for x in (p/'baseline-names.log').read_text().splitlines() if x.startswith('DECL ')};b={x[5:] for x in (p/'final-names.log').read_text().splitlines() if x.startswith('DECL ')};removed=json.loads((p/'removed-names.json').read_text());
if a-b!=set(removed):issues.append(['removed names mismatch'])
print('records',counts,'census',len(a),len(b),'removed',len(a-b),'added',len(b-a),'issues',len(issues));print(json.dumps(issues[:30],indent=2));(p/'independent-audit-initial.json').write_text(json.dumps({'counts':counts,'old_count':len(a),'new_count':len(b),'removed_count':len(a-b),'added':sorted(b-a),'issues':issues},indent=2)+'\n')
