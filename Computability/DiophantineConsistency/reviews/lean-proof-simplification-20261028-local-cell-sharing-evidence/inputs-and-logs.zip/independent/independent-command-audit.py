from pathlib import Path
import json,hashlib
p=Path('/tmp/cell-construction-share');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[];counts={}
for fn in ('common-records.json','client-common-records.json','phase-records.json','names-records.json','probe-records.json'):
 rs=json.loads((p/fn).read_text());counts[fn]=len(rs)
 for r in rs:
  c=r['command'];label=r.get('module',r.get('tag','names'));src=[x for x in c if x.endswith('.lean')]
  if len(src)!=1 or Path(src[0]).resolve()!=Path(r['source']).resolve():issues.append([fn,label,'source command'])
  if c[:4]!=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o'] or Path(c[4]).resolve()!=Path(r['time']).resolve():issues.append([fn,label,'time command'])
  if r['source_after']!=r['source_sha256'] or h(r['source'])!=r['source_sha256']:issues.append([fn,label,'source hash'])
  for k in ('log','time'):
   if h(r[k])!=r[k+'_sha256']:issues.append([fn,label,k])
  if 'object' in r and (c[-2:]!=['-o',r['object']] or h(r['object'])!=r['object_sha256'] or not Path(r['object']).is_relative_to(Path(r['lean_path'].split(':')[0]))):issues.append([fn,label,'object path/hash'])
  for x in r.get('direct_inputs',[]):
   if x['sha256']!=x['after_sha256'] or h(x['path'])!=x['sha256']:issues.append([fn,label,'direct input',x['module']])
  if (r['status']!=0)!=r.get('tag','').startswith('foundation-'):issues.append([fn,label,'status'])
for n in ('CurrentCellConstruction2011','MFCurrentCellConstruction2011'):
 src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');f=p/'final/DiophantineConsistency'/(n+'.lean')
 if h(src)!=h(f):issues.append([n,'committed source/final snapshot mismatch'])
print('checked',sum(counts.values()),'records; issues',len(issues));print(json.dumps(issues[:20],indent=2));(p/'independent-command-audit.json').write_text(json.dumps({'counts':counts,'issues':issues},indent=2)+'\n');assert not issues
