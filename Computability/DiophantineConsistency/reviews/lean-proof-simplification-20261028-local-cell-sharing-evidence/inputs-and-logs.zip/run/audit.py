from pathlib import Path
import json,hashlib
R=Path('/tmp/cell-construction-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();g=json.loads((R/'client-graph.json').read_text());nodes=g['nodes'];problems=[];counts=[]
for fn in ('common-records.json','client-common-records.json','phase-records.json','names-records.json','probe-records.json'):
 rows=json.loads((R/fn).read_text());counts.append((fn,len(rows)))
 for r in rows:
  label=r.get('module',r.get('tag','names'));cmd=r['command']
  for k in ('source','log','time'):
   if h(r[k])!=r[k+'_sha256']:problems.append((fn,label,k))
  if r['source_after']!=r['source_sha256'] or Path(r['time']).read_text().strip()!=r['timing']:problems.append((fn,label,'time/source'))
  if 'object' in r and (h(r['object'])!=r['object_sha256'] or cmd[-2:]!=['-o',r['object']] or not str(Path(r['object']).parent).startswith(r['lean_path'].split(':')[0])):problems.append((fn,label,'object/path'))
  expected_failure=r.get('tag','').startswith('foundation-')
  if (r['status']!=0)!=expected_failure:problems.append((fn,label,'status'))
  for d in r.get('direct_inputs',[]):
   if h(d['path'])!=d['sha256'] or d['sha256']!=d['after_sha256']:problems.append((fn,label,'input',d['module']))
for n,v in nodes.items():
 if h(v['source'])!=v['sha256']:problems.append((n,'source-drift'))
A={x['module']:x for x in json.loads(Path('/tmp/doubled-mask-reuse-20261028/selected-pins.json').read_text())};B={x['module']:x for x in json.loads(Path('/tmp/pell-construction-refresh/local-pins.json').read_text())};rebuilt={x['module'] for fn in ('common-records.json','client-common-records.json','phase-records.json') for x in json.loads((R/fn).read_text())};pins=[];categories={}
for n,v in nodes.items():
 rel=n.replace('.','/')+'.olean';a=R/'phase-baseline'/rel;b=R/'phase-final'/rel
 if not a.is_file() or not b.is_file():problems.append((n,'missing object'));continue
 ha=h(a);hb=h(b)
 if n not in rebuilt and ha!=hb:problems.append((n,'unexpected phase difference'))
 category='rebuilt' if n in rebuilt else 'unmatched-previous-receipt'
 if category!='rebuilt':
  for prior, key in ((A,'object_sha256'),(B,'final_sha256')):
   x=prior.get(n)
   if x and x['source_sha256']==v['sha256'] and x[key]==ha:
    category='matched-prior-pin';break
 categories[category]=categories.get(category,0)+1;pins.append({'module':n,'source':v['source'],'source_sha256':v['sha256'],'baseline_object':str(a),'baseline_sha256':ha,'final_object':str(b),'final_sha256':hb,'status':category})
if (R/'baseline-interface.log').read_bytes()!=(R/'final-interface.log').read_bytes():problems.append('interface differs')
for x in (R/'baseline-simp-audit.log').read_text().splitlines():
 if x.rsplit(':',1)[-1].strip()!='false false false false':problems.append(('registered simp',x))
for n in ('foundation-normal-first','foundation-foundation-first'):
 if (R/('baseline-'+n+'.log')).read_bytes()!=(R/('final-'+n+'.log')).read_bytes():problems.append((n,'failure changed'))
summary={'records':counts,'source_objects_per_phase':len(pins),'selection_categories':categories,'unmatched_previous_receipt':[x['module'] for x in pins if x['status']=='unmatched-previous-receipt'],'removed_names':json.loads((R/'removed-names.json').read_text()),'removed_name_count':len(json.loads((R/'removed-names.json').read_text())),'issues':problems,'limits':['Prior pins certify selected source/object pairs, not every transitive input.','Foundation/Mathlib and unmatched historical objects remain precompiled.','Both Foundation Matrix co-imports fail in both phases with pre-existing collisions.']};(R/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');(R/'local-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print(json.dumps(summary,indent=2));assert not problems
