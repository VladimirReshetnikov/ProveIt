import Lean.Elab.Command
import DiophantineConsistency.CurrentCellConstruction2011
#print equations DiophantineConsistency.CurrentCellConstruction2011.bitDigit
#print equations DiophantineConsistency.CurrentCellConstruction2011.localDigit
#print equations DiophantineConsistency.CurrentCellConstruction2011.cell
#print equations DiophantineConsistency.CurrentCellConstruction2011.localSelectorPayload
#print equations DiophantineConsistency.CurrentCellConstruction2011.localCopiedWord
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.CurrentCellConstruction2011).isPrefixOf n ||
       (n.toString.startsWith "_private.DiophantineConsistency.CurrentCellConstruction2011.") then
      logInfo m!"DECL {n}"
