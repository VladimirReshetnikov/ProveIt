from pathlib import Path
import json,os,hashlib,subprocess,time
P=Path('/tmp/cell-construction-share');plan=json.loads((P/'client-plan.json').read_text());nodes=plan['nodes'];ov=P/'overlay';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env['LEAN_PATH'];roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x];records=[]
def object_for(n):
 rel=n.replace('.','/')+'.olean'
 for root in roots:
  p=root/rel
  if p.is_file():return p
 raise RuntimeError('missing object '+n)
for n in plan['common_order']:
 v=nodes[n];src=Path(v['source']);assert h(src)==v['sha256'],n;inputs=[]
 for dep in v['imports']:
  o=object_for(dep);inputs.append({'module':dep,'path':str(o),'resolved_path':str(o.resolve()),'sha256':h(o),'local':dep in nodes})
 out=ov/(n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);name=n.split('.')[-1];log=P/('client-common-'+name+'.log');tm=P/('client-common-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(Path.cwd()/'Computability/DiophantineConsistency/Lean'),str(src),'-o',str(out)];t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for i in inputs:i['after_sha256']=h(i['path'])
 z={'module':n,'status':q.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':v['sha256'],'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.is_file() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':inputs};records.append(z);(P/'client-common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,q.returncode,round(z['elapsed'],1),flush=True)
 assert q.returncode==0 and z['source_after']==v['sha256'] and all(x['sha256']==x['after_sha256'] for x in inputs),n
for n,v in nodes.items():assert h(v['source'])==v['sha256'],n
print('Client common refresh completed',flush=True)
