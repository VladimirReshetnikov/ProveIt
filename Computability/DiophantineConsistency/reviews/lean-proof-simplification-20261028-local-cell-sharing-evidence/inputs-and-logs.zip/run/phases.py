from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/cell-construction-share');W=Path.cwd();h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();g=json.loads((R/'client-graph.json').read_text());nodes=g['nodes'];rec=[];repo=W/'Computability/DiophantineConsistency/Lean';base=os.environ['LEAN_PATH']
for ph in ('baseline','final'):
 ov=R/('phase-'+ph);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def obj(n):
  rel=n.replace('.','/')+'.olean'
  for r in roots:
   p=r/rel
   if p.is_file():return p
  raise RuntimeError('missing '+n)
 for name in ('MFCurrentCellConstruction2011','CurrentCellConstruction2011','CurrentWordConstruction2011','CurrentCellConstruction2011Checks'):
  n='DiophantineConsistency.'+name;src=(R/ph/'DiophantineConsistency'/(name+'.lean')) if name in ('MFCurrentCellConstruction2011','CurrentCellConstruction2011') else repo/'DiophantineConsistency'/(name+'.lean');root=R/ph if src.is_relative_to(R/ph) else repo
  imports=[l.split()[1] for l in src.read_text().splitlines() if l.startswith('import ')];inputs=[]
  for d in imports:
   p=obj(d);inputs.append({'module':d,'path':str(p),'resolved_path':str(p.resolve()),'sha256':h(p),'local':d in nodes})
  out=ov/(n.replace('.','/')+'.olean');out.unlink(missing_ok=True);log=R/(ph+'-'+name+'.log');tm=R/(ph+'-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];sh=h(src);t=time.monotonic()
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in inputs:x['after_sha256']=h(x['path'])
  z={'phase':ph,'module':n,'status':q.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':sh,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.is_file() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':inputs};rec.append(z);(R/'phase-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(ph,name,q.returncode,round(z['elapsed'],1),flush=True);assert q.returncode==0 and sh==h(src) and all(x['sha256']==x['after_sha256'] for x in inputs)
 for n,v in nodes.items():assert h(v['source'])==v['sha256'],n
print('Paired target and clients completed',flush=True)
