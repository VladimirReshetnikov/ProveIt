from pathlib import Path
import json,hashlib,os
p=Path('/tmp/cell-construction-share');G=json.loads((p/'graph.json').read_text());nodes=G['nodes'];A=Path('/tmp/doubled-mask-reuse-20261028/phase-final');B=Path('/tmp/pell-construction-refresh/final');PA=json.loads(Path('/tmp/doubled-mask-reuse-20261028/graph.json').read_text())['nodes'];PB=json.loads(Path('/tmp/pell-construction-refresh/updated-plan.json').read_text())['nodes'];h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();seeds={};selection={};overlay=p/'overlay'
for n,v in nodes.items():
 rel=n.replace('.','/')+'.olean';a=A/rel;b=B/rel;obj=overlay/rel
 assert obj.is_file(),n
 sel='A' if a.is_file() else 'B' if b.is_file() else 'worktree';selection[n]={'selection':sel,'object':str(obj.resolve()),'object_sha256':h(obj),'source_sha256':v['sha256']};prev=PA if sel=='A' else PB
 if n in prev and prev[n].get('source_sha256')!=v['sha256']:seeds.setdefault(n,[]).append('selected-source-changed')
 if sel=='B':
  for d in v['imports']:
   rel=d.replace('.','/')+'.olean';old=B/rel;new=A/rel
   if d in nodes and old.is_file() and new.is_file() and h(old)!=h(new):seeds.setdefault(n,[]).append('selected-input-differs:'+d)
aff=set(seeds)
while 1:
 nxt=aff|{n for n,v in nodes.items() if any(i in aff for i in v['imports'])}
 if nxt==aff:break
 aff=nxt
targets={'DiophantineConsistency.CurrentCellConstruction2011','DiophantineConsistency.MFCurrentCellConstruction2011'};assert targets<=aff
order=[n for n in G['order'] if n in aff-targets];assert len(order)==24
G.update({'selection':selection,'seeds':seeds,'affected':sorted(aff),'common_order':order,'target_order':['DiophantineConsistency.MFCurrentCellConstruction2011','DiophantineConsistency.CurrentCellConstruction2011']});(p/'plan.json').write_text(json.dumps(G,indent=2)+'\n')
print('selected',len(nodes),'local modules; seeds',len(seeds),'common rebuilds',len(order),'plus paired targets')
