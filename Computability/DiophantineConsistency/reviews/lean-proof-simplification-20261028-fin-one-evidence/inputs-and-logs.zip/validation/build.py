from pathlib import Path
import subprocess,os,time,json,hashlib
base=Path('/tmp/fin-one-simplification');env=os.environ.copy(); records=[]
for n in ['ArithmeticEnumRunPerm222','ArithmeticCommandRunPerm222','ArithmeticCommandAppendPerm222']:
 for phase in ['baseline','final']:
  d=base/n/phase;src=d/'source'/'DiophantineConsistency'/(n+'.lean');out=d/'lib'/'DiophantineConsistency'/(n+'.olean');log=d/'target.log';tim=d/'target.time'; e=env.copy();e['LEAN_PATH']=str(d/'lib')+':'+env['LEAN_PATH'];cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(d/'source'),str(src),'-o',str(out)];start=time.monotonic();r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tim)]+cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();rec={'target':n,'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-start,3),'time':tim.read_text().strip(),'source_sha256':sha(src),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};records.append(rec);(base/'build-records.json').write_text(json.dumps(records,indent=2));print(n,phase,r.returncode,rec['time'],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
