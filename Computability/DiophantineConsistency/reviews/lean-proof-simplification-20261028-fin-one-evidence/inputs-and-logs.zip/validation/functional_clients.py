from pathlib import Path
import os,subprocess,time,json,hashlib
b=Path('/tmp/fin-one-simplification');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');env=os.environ.copy();records=[]
def run(target,phase,n):
 p=root/(n+'.lean');d=b/target/phase;e=env.copy();e['LEAN_PATH']=str(d/'lib')+':'+env['LEAN_PATH'];out=d/'lib'/'DiophantineConsistency'/(n+'.olean');
 if out.is_symlink():out.unlink()
 log=d/(n+'.client.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p),'-o',str(out)];t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();records.append({'module':n,'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(p),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log)});(b/'functional-client-records.json').write_text(json.dumps(records,indent=2));print(n,phase,r.returncode,records[-1]['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
def merge(target,phase):
 dst=b/target/phase/'lib'/'DiophantineConsistency';src=b/'ArithmeticCommandRunPerm222'/phase/'lib'/'DiophantineConsistency';conflicts=[]
 for f in src.iterdir():
  if not f.is_file():continue
  p=dst/f.name
  if not p.exists() and not p.is_symlink():p.symlink_to(f)
  elif p.exists() and hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(f.read_bytes()).digest():conflicts.append(f.name)
 if conflicts:raise RuntimeError('conflicting deps '+str(conflicts))
for phase in ['baseline','final']:
 run('ArithmeticCommandRunPerm222',phase,'ArithmeticCommandEvaluationPerm222')
 for target in ['ArithmeticCommandAppendPerm222','ArithmeticEnumRunPerm222']:merge(target,phase)
 run('ArithmeticCommandAppendPerm222',phase,'ArithmeticCommandCompositionPerm222')
 run('ArithmeticEnumRunPerm222',phase,'ArithmeticEnumFairPerm222')
