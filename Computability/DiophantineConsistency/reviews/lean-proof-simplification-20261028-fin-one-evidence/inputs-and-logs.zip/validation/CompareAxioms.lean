import Foundation.FirstOrder.Arithmetic.HFS.PRF

theorem original {α : Type*} (e : Fin 3 → α) :
    (fun i : Fin 1 => e i.succ.succ) = ![e 2] := by
  funext i
  have hi : i = 0 := Subsingleton.elim _ _
  subst i
  rfl

theorem shortened {α : Type*} (e : Fin 3 → α) :
    (fun i : Fin 1 => e i.succ.succ) = ![e 2] :=
  funext <| Fin.forall_fin_one.mpr rfl
#print axioms original
#print axioms shortened
#print axioms Fin.forall_fin_one
