from pathlib import Path
import json,hashlib
base=Path('/tmp/fin-one-simplification');out=[]
for n in ['arithmetic-enum-runperm222-root-author-90402mpi','arithmetic-command-runperm222-root-author-gf9iylxf','arithmetic-command-appendperm222-root-author-du2j9e84']:
 root=Path('/tmp')/n;manifest=root/'inputs.json';d=json.loads(manifest.read_text());mods=[];bad=[]
 for m in d['modules']:
  s=m['source'];i=s.find('/Computability/');src=Path('.'+s[i:]) if i>=0 else Path(s); srcsha=hashlib.sha256(src.read_bytes()).hexdigest() if src.exists() else None;obs=[]
  if srcsha!=m['source_sha256']:bad.append('source '+m['module'])
  for o in m['objects']:
   orig=Path(o['path']);dst=root/'lib'/m['module'].replace('.','/');ext=orig.name[len(m['module'].split('.')[-1]):];dst=dst.parent/(dst.name+ext);h=hashlib.sha256(dst.read_bytes()).hexdigest() if dst.exists() else None
   if h!=o['sha256']:bad.append('object '+str(dst))
   obs.append({'path':str(dst),'expected_sha256':o['sha256'],'actual_sha256':h})
  mods.append({'module':m['module'],'source_path':str(src.resolve()),'expected_source_sha256':m['source_sha256'],'actual_source_sha256':srcsha,'objects':obs})
 out.append({'manifest':str(manifest),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'failures':bad,'modules':mods});print(n,'modules',len(mods),'objects',sum(len(m['objects']) for m in mods),'failures',len(bad),flush=True)
(base/'pins.json').write_text(json.dumps(out,indent=2)+'\n')
if any(r['failures'] for r in out):raise SystemExit(1)
