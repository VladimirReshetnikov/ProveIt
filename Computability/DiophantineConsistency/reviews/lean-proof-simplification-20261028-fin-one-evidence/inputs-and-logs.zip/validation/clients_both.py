from pathlib import Path
import os,subprocess,time,json,hashlib
b=Path('/tmp/fin-one-simplification');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');env=os.environ.copy();records=[]
for target in ['ArithmeticEnumRunPerm222','ArithmeticCommandRunPerm222','ArithmeticCommandAppendPerm222']:
 for phase in ['baseline','final']:
  n=target+'Checks';p=root/(n+'.lean');d=b/target/phase;out=d/'lib'/'DiophantineConsistency'/(n+'.olean');log=d/'client-checks.log';e=env.copy();e['LEAN_PATH']=str(d/'lib')+':'+env['LEAN_PATH'];cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p),'-o',str(out)];t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();records.append({'module':n,'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(p),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log)});(b/'paired-client-records.json').write_text(json.dumps(records,indent=2));print(n,phase,r.returncode,records[-1]['seconds'],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
