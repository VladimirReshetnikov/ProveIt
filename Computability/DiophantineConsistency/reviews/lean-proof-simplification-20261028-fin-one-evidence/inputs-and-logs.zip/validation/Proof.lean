import Foundation.FirstOrder.Arithmetic.HFS.PRF

#check Fin.forall_fin_one
example {α : Type*} (e : Fin 3 → α) :
    (fun i : Fin 1 => e i.succ.succ) = ![e 2] :=
  funext <| Fin.forall_fin_one.mpr rfl
