from pathlib import Path
import re,os,subprocess,json,hashlib,time
base=Path('/tmp/fin-one-simplification');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');env=os.environ.copy();records=[]
for n in ['ArithmeticEnumRunPerm222','ArithmeticCommandRunPerm222','ArithmeticCommandAppendPerm222']:
 txt=(repo/(n+'.lean')).read_text();names=re.findall(r'^(?:@\[[^\n]*\]\s*)?(?:protected\s+|noncomputable\s+)?(?:theorem|lemma|def|instance|abbrev)\s+([\w\']+)',txt,re.M);probe=base/n/'Axioms.lean';probe.write_text('import DiophantineConsistency.'+n+'\n'+''.join('#print axioms DiophantineConsistency.'+n+'.'+a+'\n' for a in names));print(n,'declarations',len(names),flush=True)
 for phase in ['baseline','final']:
  d=base/n/phase;e=env.copy();e['LEAN_PATH']=str(d/'lib')+':'+env['LEAN_PATH'];cmd=['lean','-M6000','-j1','-DElab.async=false',str(probe)];log=d/'axioms.log';t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records.append({'target':n,'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'probe_sha256':sha(probe),'log_sha256':sha(log),'declaration_count':len(names)});(base/'axiom-records.json').write_text(json.dumps(records,indent=2));print(phase,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
 a=(base/n/'baseline'/'axioms.log').read_bytes();b=(base/n/'final'/'axioms.log').read_bytes();print('identical',a==b,flush=True)
 if a!=b:raise SystemExit(1)
