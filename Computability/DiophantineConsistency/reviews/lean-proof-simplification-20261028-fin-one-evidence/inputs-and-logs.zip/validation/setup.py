from pathlib import Path
import json,hashlib,re
base=Path('/tmp/fin-one-simplification');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');sources={
'ArithmeticEnumRunPerm222':Path('/tmp/arithmetic-enum-runperm222-root-author-90402mpi/lib'),
'ArithmeticCommandRunPerm222':Path('/tmp/arithmetic-command-runperm222-root-author-gf9iylxf/lib'),
'ArithmeticCommandAppendPerm222':Path('/tmp/arithmetic-command-appendperm222-root-author-du2j9e84/lib')}
for name,library in sources.items():
 original=(repo/(name+'.lean')).read_text(); old=('have he : (fun i : Fin 1 => e i.succ.succ) = ![e 2] := by\n'+' '*4+'  funext i\n'+' '*4+'  have hi : i = 0 := Subsingleton.elim _ _\n'+' '*4+'  subst i\n'+' '*4+'  rfl') if name=='ArithmeticCommandAppendPerm222' else ('have he : (fun i : Fin 1 => e i.succ.succ) = ![e 2] := by\n    funext i\n    have hi : i = 0 := Subsingleton.elim _ _\n    subst i\n    rfl')
 assert old in original,name
 new=original.replace(old,'have he : (fun i : Fin 1 => e i.succ.succ) = ![e 2] :=\n' + (' '*6 if name=='ArithmeticCommandAppendPerm222' else ' '*4) + 'funext <| Fin.forall_fin_one.mpr rfl');assert original!=new
 for phase,text in [('baseline',original),('final',new)]:
  src=base/name/phase/'source'/'DiophantineConsistency'/(name+'.lean');src.parent.mkdir(parents=True,exist_ok=True);src.write_text(text);lib=base/name/phase/'lib';lib.mkdir(parents=True,exist_ok=True)
  for root in library.iterdir():
   if root.name=='DiophantineConsistency':
    dest=lib/root.name;dest.mkdir(exist_ok=True)
    for f in root.iterdir():
     if f.name!=name+'.olean':(dest/f.name).symlink_to(f)
   else:(lib/root.name).symlink_to(root)
 print(name,'line reduction',len(original.splitlines())-len(new.splitlines()))
