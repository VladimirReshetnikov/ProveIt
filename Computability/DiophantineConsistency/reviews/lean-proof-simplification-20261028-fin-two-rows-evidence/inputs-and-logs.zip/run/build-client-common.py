from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/finite-two-rows');p=json.loads((R/'client-plan.json').read_text());nodes=p['nodes'];ov=R/'common';h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env['LEAN_PATH'];roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x];records=[]
def object_for(n):
 rel=n.replace('.','/')+'.olean'
 for root in roots:
  q=root/rel
  if q.is_file():return q
 raise RuntimeError('missing object '+n)
for n in p['common_order']:
 v=nodes[n];src=Path(v['source']);assert h(src)==v['sha256'],n;ins=[]
 for dep in v['imports']:
  q=object_for(dep);ins.append({'module':dep,'path':str(q),'resolved_path':str(q.resolve()),'sha256':h(q),'local':dep in nodes})
 rel=n.replace('.','/')+'.lean';assert str(src).endswith(rel);srcroot=Path(str(src)[:-len(rel)]);out=ov/(n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);name=n.replace('.','_');log=R/('client-common-'+name+'.log');tm=R/('client-common-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(out)];t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for i in ins:i['after_sha256']=h(i['path'])
 r={'module':n,'status':q.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':v['sha256'],'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.is_file() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':ins};records.append(r);(R/'client-common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,q.returncode,round(r['elapsed'],1),flush=True);assert q.returncode==0 and r['source_after']==v['sha256'] and all(x['sha256']==x['after_sha256'] for x in ins),n
for n,v in nodes.items():assert h(v['source'])==v['sha256'],n
print('Client shared refresh complete',flush=True)
