import Lean.Elab.Command
import DiophantineConsistency.ObjectDivModSyntax
#print equations DiophantineConsistency.ObjectListHead.GuardCertificate
#print equations DiophantineConsistency.ObjectListHead.expression
#print equations DiophantineConsistency.ObjectPredecessorSyntax.expression
#print equations DiophantineConsistency.ObjectDivModSyntax.expression
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    let s := n.toString
    if (`DiophantineConsistency.ObjectListHead).isPrefixOf n ||
       (`DiophantineConsistency.ObjectPredecessorSyntax).isPrefixOf n ||
       (`DiophantineConsistency.ObjectDivModSyntax).isPrefixOf n ||
       s.startsWith "_private.DiophantineConsistency.ObjectListHead." ||
       s.startsWith "_private.DiophantineConsistency.ObjectPredecessorSyntax." ||
       s.startsWith "_private.DiophantineConsistency.ObjectDivModSyntax." then
      logInfo m!"DECL {n}"
