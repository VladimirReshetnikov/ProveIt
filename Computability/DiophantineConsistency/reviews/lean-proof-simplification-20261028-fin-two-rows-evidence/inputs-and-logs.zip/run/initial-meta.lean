import Lean.Util.CollectAxioms
import DiophantineConsistency.ObjectDivModSyntax
set_option pp.all true
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let all := env.constants.toList
  let names : List String := [
    "DiophantineConsistency.ObjectDivModSyntax.N",
    "DiophantineConsistency.ObjectDivModSyntax.N.congr_simp",
    "DiophantineConsistency.ObjectDivModSyntax.exists_expression_zero_iff",
    "DiophantineConsistency.ObjectDivModSyntax.exists_expression_zero_iff._simp_1",
    "DiophantineConsistency.ObjectDivModSyntax.expression",
    "DiophantineConsistency.ObjectDivModSyntax.expression.eq_1",
    "DiophantineConsistency.ObjectDivModSyntax.expression_degree",
    "DiophantineConsistency.ObjectDivModSyntax.expression_zero_iff",
    "DiophantineConsistency.ObjectDivModSyntax.rows_zero_iff",
    "DiophantineConsistency.ObjectListHead.GuardCertificate",
    "DiophantineConsistency.ObjectListHead.GuardCertificate.eq_1",
    "DiophantineConsistency.ObjectListHead.N",
    "DiophantineConsistency.ObjectListHead.exists_expression_zero_iff",
    "DiophantineConsistency.ObjectListHead.expression",
    "DiophantineConsistency.ObjectListHead.expression.eq_1",
    "DiophantineConsistency.ObjectListHead.expression_degree",
    "DiophantineConsistency.ObjectListHead.expression_zero_iff",
    "DiophantineConsistency.ObjectListHead.guard_complete",
    "DiophantineConsistency.ObjectListHead.guard_sound",
    "DiophantineConsistency.ObjectListHead.left_le_pair",
    "DiophantineConsistency.ObjectListHead.listHead_le",
    "DiophantineConsistency.ObjectListHead.rows_zero_iff",
    "DiophantineConsistency.ObjectPredecessorSyntax.N",
    "DiophantineConsistency.ObjectPredecessorSyntax.expression",
    "DiophantineConsistency.ObjectPredecessorSyntax.expression.eq_1",
    "DiophantineConsistency.ObjectPredecessorSyntax.expression_degree",
    "DiophantineConsistency.ObjectPredecessorSyntax.expression_zero_iff",
    "DiophantineConsistency.ObjectPredecessorSyntax.graphForm",
    "DiophantineConsistency.ObjectPredecessorSyntax.graphForm_spec",
    "DiophantineConsistency.ObjectPredecessorSyntax.rows_zero_iff",
    "DiophantineConsistency.ObjectPredecessorSyntax.sentence_totalForm",
    "DiophantineConsistency.ObjectPredecessorSyntax.totalForm",
    "DiophantineConsistency.ObjectPredecessorSyntax.zfc_proves_total",
    "_private.DiophantineConsistency.ObjectDivModSyntax.0.DiophantineConsistency.ObjectDivModSyntax.literal_row0",
    "_private.DiophantineConsistency.ObjectDivModSyntax.0.DiophantineConsistency.ObjectDivModSyntax.literal_row1",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.guardPort",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.guard_rows",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.literal_guard0",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.literal_guard1",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.literal_system",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.projectionPort",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.projectionPort._proof_1",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.self_le_square",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.self_le_square._simp_1",
    "_private.DiophantineConsistency.ObjectPredecessorSyntax.0.DiophantineConsistency.ObjectPredecessorSyntax.literal_row0",
    "_private.DiophantineConsistency.ObjectPredecessorSyntax.0.DiophantineConsistency.ObjectPredecessorSyntax.literal_row1"
  ]
  for s in names do
    match all.find? (fun (n, _) => n.toString == s) with
    | none => throwError "missing declaration {s}"
    | some (n, c) =>
      let axs ← collectAxioms n
      logInfo m!"DECL {n}\nTYPE {c.type}\nAXIOMS {axs}"
