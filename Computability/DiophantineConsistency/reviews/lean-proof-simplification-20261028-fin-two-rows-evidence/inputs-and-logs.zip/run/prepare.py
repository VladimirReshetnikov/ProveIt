from pathlib import Path
import json,os,hashlib
R=Path('/tmp/finite-two-rows');ov=R/'common';ov.mkdir(exist_ok=False);A=Path('/tmp/object-expression-sharing/final');fallback=Path('.lake/build/lib/lean').resolve();h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for base in (A,fallback):
 for dp,dirs,files in os.walk(base,followlinks=False):
  s=Path(dp);d=ov/s.relative_to(base);d.mkdir(parents=True,exist_ok=True)
  for n in dirs[:]:
   q=s/n
   if q.is_symlink():
    z=d/n
    if not z.exists() and not z.is_symlink():os.symlink(str(q.resolve()),z)
    dirs.remove(n)
  for n in files:
   z=d/n
   if not z.exists() and not z.is_symlink():os.symlink(str((s/n).resolve()),z)
g=json.loads((R/'graph.json').read_text());nodes=g['nodes'];initial={};newer=[]
for n,v in nodes.items():
 obj=ov/(n.replace('.','/')+'.olean');assert obj.is_file(),n;src=Path(v['source']);assert h(src)==v['sha256'];initial[n]={'source':str(src),'source_sha256':v['sha256'],'object':str(obj.resolve()),'object_sha256':h(obj),'source_newer':src.stat().st_mtime_ns>obj.stat().st_mtime_ns}
 if initial[n]['source_newer']:newer.append(n)
prev=json.loads(Path('/tmp/pell-construction-refresh/local-pins.json').read_text());pin={x['module']:x for x in prev};records=json.loads(Path('/tmp/construction-share/bound-refresh-records.json').read_text());rr={x['module']:x for x in records};fresh=Path('/tmp/pell-construction-refresh/final');reuse={}
for n in ('FirstOrder.Fol','FirstOrder.Calculus','FirstOrder.Completeness'):
 x=pin[n];src=Path(nodes[n]['source']);obj=fresh/(n.replace('.','/')+'.olean');assert h(src)==x['source_sha256']==nodes[n]['sha256'];assert h(obj)==x['final_sha256'];
 if n!='FirstOrder.Fol':
  a=rr[n];assert a['status']==0 and h(obj)==a['object_sha256'];
  for dep in a['direct_project_inputs']:
   q=fresh/(dep['module'].replace('.','/')+'.olean');assert h(q)==dep['sha256'],(n,dep)
 q=ov/(n.replace('.','/')+'.olean');q.unlink(missing_ok=True);q.parent.mkdir(parents=True,exist_ok=True);os.symlink(str(obj.resolve()),q);reuse[n]={'source_sha256':h(src),'object_sha256':h(obj),'object':str(obj.resolve()),'direct_inputs':rr[n]['direct_project_inputs'] if n in rr else []}
def descendants(s):
 while 1:
  t=s|{n for n,v in nodes.items() if any(x in s for x in v['imports'])}
  if t==s:return s
  s=t
changed={'DiophantineConsistency.'+n for n in ('ObjectPredecessorSyntax','ObjectListHead','ObjectDivModSyntax')};phase=descendants(changed);aff=descendants(set(newer)|{'FirstOrder.Fol'});common=[n for n in g['order'] if n in aff-phase-set(reuse)];phaseorder=[n for n in g['order'] if n in phase];assert len(common)==58 and len(phaseorder)==6
plan={'nodes':nodes,'external':g['external'],'common_order':common,'phase_order':phaseorder,'candidate':sorted(changed),'source_newer':sorted(newer),'initial':initial,'reuse_firstorder':reuse};(R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('prepared',len(nodes),'nodes;',len(common),'shared,',len(phaseorder),'per phase;',len(newer),'source-newer seeds')
