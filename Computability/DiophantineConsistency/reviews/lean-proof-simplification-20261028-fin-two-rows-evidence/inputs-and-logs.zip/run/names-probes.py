from pathlib import Path
import json,os,hashlib,subprocess,time
R=Path('/tmp/finite-two-rows');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rs=json.loads((R/'phase-records.json').read_text());rec=[];src=R/'names.lean'
for ph in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=next(x['lean_path'] for x in rs if x['phase']==ph);log=R/(ph+'-names.log');tm=R/(ph+'-names.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=h(src);t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 z={'phase':ph,'status':q.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'elapsed':time.monotonic()-t};rec.append(z);(R/'names-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(ph,q.returncode,flush=True);assert q.returncode==0 and before==h(src)
