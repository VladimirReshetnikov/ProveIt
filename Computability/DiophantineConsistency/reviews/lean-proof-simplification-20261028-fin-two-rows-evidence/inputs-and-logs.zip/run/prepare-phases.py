from pathlib import Path
import os
R=Path('/tmp/finite-two-rows');base=R/'common'
for ph in ('baseline','final'):
 ov=R/('phase-'+ph);ov.mkdir()
 for dp,dirs,files in os.walk(base,followlinks=False):
  s=Path(dp);d=ov/s.relative_to(base);d.mkdir(exist_ok=True)
  for n in dirs[:]:
   q=s/n
   if q.is_symlink():os.symlink(str(q.resolve()),d/n);dirs.remove(n)
  for n in files:os.symlink(str((s/n).resolve()),d/n)
print('paired overlays prepared')
