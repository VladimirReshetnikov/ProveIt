from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/finite-two-rows');W=Path.cwd();p=json.loads((R/'plan.json').read_text());g=json.loads((R/'client-graph.json').read_text());nodes=g['nodes'];h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();repo=W/'Computability/DiophantineConsistency/Lean';base=os.environ['LEAN_PATH'];rec=[];targets={n.split('.')[-1] for n in p['candidate']}
for phase in ('baseline','final'):
 ov=R/('phase-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def obj(n):
  rel=n.replace('.','/')+'.olean'
  for root in roots:
   q=root/rel
   if q.is_file():return q
  raise RuntimeError('missing '+n)
 tasks=[(n,nodes[n]['source'],False) for n in p['phase_order']]+[(n,str(repo/'checks'/(n+'.lean')),True) for n in ('ObjectGuardedWire','ObjectDivision')]
 for n,source,ischeck in tasks:
  label=('check-' if ischeck else '')+n.split('.')[-1];name=n.split('.')[-1];src=Path(source)
  if name in targets and not ischeck:src=R/phase/'DiophantineConsistency'/(name+'.lean')
  root=R/phase if src.is_relative_to(R/phase) else repo;imports=[l.split()[1] for l in src.read_text().splitlines() if l.startswith('import ')];inputs=[]
  for dep in imports:
   q=obj(dep);inputs.append({'module':dep,'path':str(q),'resolved_path':str(q.resolve()),'sha256':h(q),'local':dep in nodes})
  out=ov/('checks/'+name+'.olean' if ischeck else n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);log=R/(phase+'-'+label+'.log');tm=R/(phase+'-'+label+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];sh=h(src);t=time.monotonic()
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in inputs:x['after_sha256']=h(x['path'])
  z={'phase':phase,'tag':label,'module':n,'status':q.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':sh,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.is_file() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':inputs};rec.append(z);(R/'phase-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,label,q.returncode,round(z['elapsed'],1),flush=True);assert q.returncode==0 and sh==h(src) and all(x['sha256']==x['after_sha256'] for x in inputs)
 for n,v in nodes.items():assert h(v['source'])==v['sha256'],n
print('Paired targets and checks passed',flush=True)
