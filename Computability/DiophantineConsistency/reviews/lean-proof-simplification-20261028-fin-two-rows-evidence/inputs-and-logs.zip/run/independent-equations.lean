import Lean.Util.CollectAxioms
import DiophantineConsistency.ObjectDivModSyntax
open Lean Elab Command
set_option pp.all true
run_cmd do
  let initial ← getEnv
  let all := initial.constants.toList
  let names : List String := [
    "DiophantineConsistency.ObjectListHead.N",
    "DiophantineConsistency.ObjectListHead.GuardCertificate",
    "DiophantineConsistency.ObjectListHead.expression",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.projectionPort",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.guardPort",
    "DiophantineConsistency.ObjectPredecessorSyntax.N",
    "DiophantineConsistency.ObjectPredecessorSyntax.expression",
    "DiophantineConsistency.ObjectPredecessorSyntax.graphForm",
    "DiophantineConsistency.ObjectPredecessorSyntax.totalForm",
    "DiophantineConsistency.ObjectDivModSyntax.N",
    "DiophantineConsistency.ObjectDivModSyntax.expression"
  ]
  for s in names do
    match all.find? (fun (n, _) => n.toString == s) with
    | none => throwError "missing definition {s}"
    | some (n, _) =>
      let eqns ← liftTermElabM <| Lean.Meta.getEqnsFor? n
      match eqns with
      | none => logInfo m!"DEFINITION {n} EQUATIONS none"
      | some es =>
        for e in es do
          let info ← getConstInfo e
          let axs ← collectAxioms e
          logInfo m!"DEFINITION {n}\nEQUATION {e}\nTYPE {info.type}\nAXIOMS {axs}"
