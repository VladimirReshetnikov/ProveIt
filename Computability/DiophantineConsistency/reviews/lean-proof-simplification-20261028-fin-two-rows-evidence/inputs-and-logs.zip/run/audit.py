from pathlib import Path
import json,hashlib
R=Path('/tmp/finite-two-rows');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();p=json.loads((R/'plan.json').read_text());g=json.loads((R/'client-graph.json').read_text());nodes=g['nodes'];issues=[];counts=[]
for fname in ('common-records.json','client-common-records.json','phase-records.json','names-records.json','meta-records.json'):
 rows=json.loads((R/fname).read_text());counts.append((fname,len(rows)))
 for r in rows:
  label=r.get('module',r.get('tag','probe'));cmd=r['command']
  for k in ('source','log','time'):
   if h(r[k])!=r[k+'_sha256']:issues.append((fname,label,k))
  if r['status']!=0 or r['source_after']!=r['source_sha256'] or Path(r['time']).read_text().strip()!=r['timing']:issues.append((fname,label,'status/time/source'))
  if 'object' in r and (h(r['object'])!=r['object_sha256'] or cmd[-2:]!=['-o',r['object']] or not str(Path(r['object']).parent).startswith(r['lean_path'].split(':')[0])):issues.append((fname,label,'object/path'))
  for d in r.get('direct_inputs',[]):
   if d['sha256']!=d['after_sha256'] or h(d['path'])!=d['sha256']:issues.append((fname,label,'input',d['module']))
for n,v in nodes.items():
 if h(v['source'])!=v['sha256']:issues.append((n,'source-drift'))
for n,v in p['reuse_firstorder'].items():
 for ph in ('baseline','final'):
  q=R/('phase-'+ph)/(n.replace('.','/')+'.olean')
  if h(q)!=v['object_sha256']:issues.append((n,ph,'firstorder-pin'))
rebuilt={x['module'] for fn in ('common-records.json','client-common-records.json','phase-records.json') for x in json.loads((R/fn).read_text()) if '.' in x['module']};pins=[];stats={}
for n,v in nodes.items():
 rel=n.replace('.','/')+'.olean';a=R/'phase-baseline'/rel;b=R/'phase-final'/rel
 if not a.is_file() or not b.is_file():issues.append((n,'missing object'));continue
 ha=h(a);hb=h(b);cat='rebuilt' if n in rebuilt else 'verified-firstorder' if n in p['reuse_firstorder'] else 'precompiled-unaffected';stats[cat]=stats.get(cat,0)+1
 if cat!='rebuilt' and ha!=hb:issues.append((n,'unexpected phase difference'))
 pins.append({'module':n,'source':v['source'],'source_sha256':v['sha256'],'baseline_object':str(a),'baseline_sha256':ha,'final_object':str(b),'final_sha256':hb,'status':cat})
if (R/'baseline-meta.log').read_bytes()!=(R/'final-meta.log').read_bytes():issues.append('old declaration reports differ')
a=json.loads((R/'names-difference.json').read_text());
if a['removed'] or len(a['added'])!=3:issues.append('namespace changes')
for row in (R/'new-names.log').read_text().splitlines():
 if not ('AXIOMS [propext]' in row and row.endswith('SIMP false false false false')):issues.append(('new generated name',row))
for n in ('check-ObjectDivision','check-ObjectGuardedWire'):
 if (R/('baseline-'+n+'.log')).read_bytes()!=(R/('final-'+n+'.log')).read_bytes():issues.append((n,'client logs differ'))
summary={'records':counts,'source_objects_per_phase':len(pins),'selection_categories':stats,'precompiled_unaffected':[x['module'] for x in pins if x['status']=='precompiled-unaffected'],'old_names':len(a['old']),'added_generated_names':a['added'],'removed_names':a['removed'],'issues':issues,'limitations':['Unaffected local objects and transitive external packages remain precompiled; source/object pins do not certify every previous compiler input.','Original uncorrected simp prototype emitted three matching unnecessary-simpa warnings.','Initial metadata probe failed to force lazy equation theorems; its failure was preserved, and the corrected paired probe passed.']};(R/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');(R/'local-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print(json.dumps(summary,indent=2));assert not issues
