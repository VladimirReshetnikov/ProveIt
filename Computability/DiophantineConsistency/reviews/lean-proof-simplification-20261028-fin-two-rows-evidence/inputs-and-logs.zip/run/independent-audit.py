from pathlib import Path
import json,hashlib
p=Path('/tmp/finite-two-rows'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[];counts={}
for fn,num in [('common-records.json',58),('client-common-records.json',3),('phase-records.json',16),('names-records.json',2),('meta-records.json',2)]:
 rs=json.loads((p/fn).read_text());counts[fn]=len(rs)
 if len(rs)!=num:issues.append([fn,'count',len(rs)])
 for r in rs:
  label=r.get('phase','')+':'+r.get('module',r.get('tag','names'));cmd=r['command'];src=[Path(x) for x in cmd if x.endswith('.lean')]
  if len(src)!=1 or src[0].resolve()!=Path(r['source']).resolve():issues.append([fn,label,'source command'])
  if cmd[:4]!=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o'] or Path(cmd[4]).resolve()!=Path(r['time']).resolve():issues.append([fn,label,'time command'])
  if h(r['source'])!=r['source_sha256'] or r['source_sha256']!=r['source_after']:issues.append([fn,label,'source'])
  for k in ('log','time'):
   if h(r[k])!=r[k+'_sha256']:issues.append([fn,label,k])
  if Path(r['time']).read_text().strip()!=r['timing']:issues.append([fn,label,'timing'])
  if 'object' in r and (h(r['object'])!=r['object_sha256'] or cmd[-2:]!=['-o',r['object']] or not Path(r['object']).is_relative_to(Path(r['lean_path'].split(':')[0]))):issues.append([fn,label,'object/path'])
  if r['status']!=0:issues.append([fn,label,'status'])
  for d in r.get('direct_inputs',[]):
   if h(d['path'])!=d['sha256'] or d['sha256']!=d['after_sha256']:issues.append([fn,label,'input',d['module']])
r=json.loads((p/'new-names-record.json').read_text());cmd=r['command'];counts['new-names-record.json']=1
for k in ('source','log','time'):
 if h(r[k])!=r[k+'_sha256']:issues.append(['new names',k])
if r['status'] or r['source_sha256']!=r['source_after'] or Path(r['time']).read_text().strip()!=r['timing']:issues.append(['new names','status/time'])
for n in ('ObjectListHead','ObjectDivModSyntax','ObjectPredecessorSyntax'):
 a=p/'baseline/DiophantineConsistency'/(n+'.lean');b=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean')
 if h(a)!=h(b):issues.append([n,'baseline/source mismatch'])
for n in ('ObjectListHead','ObjectDivModSyntax','ObjectPredecessorSyntax','ObjectTreeCodeSyntax','ObjectNumericWire','ObjectDivision','check-ObjectDivision','check-ObjectGuardedWire','meta'):
 if (p/('baseline-'+n+'.log')).read_bytes()!=(p/('final-'+n+'.log')).read_bytes():issues.append([n,'log differs'])
print('records',counts,'issues',len(issues));print(json.dumps(issues[:30],indent=2));(p/'independent-audit.json').write_text(json.dumps({'counts':counts,'issues':issues},indent=2)+'\n')
