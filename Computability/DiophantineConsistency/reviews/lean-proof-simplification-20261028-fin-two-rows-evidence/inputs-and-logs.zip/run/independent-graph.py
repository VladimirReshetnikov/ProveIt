from pathlib import Path
import re,json,tomllib,hashlib
p=Path('/tmp/finite-two-rows');W=Path.cwd();saved=json.loads((p/'client-graph.json').read_text());roots=list(dict.fromkeys((W/x.get('srcDir','.')).resolve() for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']));h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[]
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(f):
 out=[]
 for line in strip(Path(f).read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out
for phase in ('baseline','final'):
 G={};E=set()
 def visit(n):
  if n in G or n in E:return
  if n in ('DiophantineConsistency.ObjectListHead','DiophantineConsistency.ObjectPredecessorSyntax','DiophantineConsistency.ObjectDivModSyntax'):f=p/phase/(n.replace('.','/')+'.lean')
  else:
   loc=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
   if not loc:E.add(n);return
   if len(loc)!=1:issues.append([phase,'ambiguous',n]);return
   f=loc[0]
  im=imports(f);G[n]=im
  for a in im:visit(a)
 for n in ('DiophantineConsistency.ObjectDivModSyntax','DiophantineConsistency.ObjectConditional'):visit(n)
 if set(G)!=set(saved['nodes']):issues.append([phase,'node diff',sorted(set(G)^set(saved['nodes']))])
 if E!=set(saved['external']):issues.append([phase,'external diff',sorted(E^set(saved['external']))])
 for n,im in G.items():
  if n in saved['nodes'] and sorted(im)!=sorted(saved['nodes'][n]['imports']):issues.append([phase,'edge mismatch',n])
 print(phase,'local nodes',len(G),'external',len(E))
for n,v in saved['nodes'].items():
 if h(v['source'])!=v['sha256']:issues.append(['source drift',n])
for x in json.loads((p/'local-pins.json').read_text()):
 for ph in ('baseline','final'):
  if h(x[ph+'_object'])!=x[ph+'_sha256']:issues.append([ph,'object drift',x['module']])
print('issues',issues);(p/'independent-graph-result.json').write_text(json.dumps({'issues':issues,'nodes':len(saved['nodes']),'external':len(saved['external'])},indent=2)+'\n')
