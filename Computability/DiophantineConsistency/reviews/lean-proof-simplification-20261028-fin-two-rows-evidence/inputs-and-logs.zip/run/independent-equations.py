from pathlib import Path
import json,hashlib,os,subprocess,time
p=Path('/tmp/finite-two-rows'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();out=[]
for phase in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/('phase-'+phase))+':'+base;src=p/'independent-equations.lean';log=p/(phase+'-independent-equations.log');tm=p/(phase+'-independent-equations.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=h(src);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 out.append({'phase':phase,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,2)});(p/'independent-equations-records.json').write_text(json.dumps(out,indent=2)+'\n');print(phase,r.returncode,flush=True)
 if r.returncode or before!=h(src):raise SystemExit(1)
