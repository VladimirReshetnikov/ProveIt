import Lean.Util.CollectAxioms
import DiophantineConsistency.ObjectDivModSyntax
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let all := env.constants.toList
  let names : List String := [
    "DiophantineConsistency.ObjectDivModSyntax.rows_zero_iff._simp_1",
    "DiophantineConsistency.ObjectPredecessorSyntax.rows_zero_iff._simp_1",
    "_private.DiophantineConsistency.ObjectListHead.0.DiophantineConsistency.ObjectListHead.guard_rows._simp_1"
  ]
  for s in names do
    match all.find? (fun (n, _) => n.toString == s) with
    | none => throwError "missing declaration {s}"
    | some (n, _) =>
      let axs ← collectAxioms n
      logInfo m!"NEW {n} AXIOMS {axs} SIMP {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
