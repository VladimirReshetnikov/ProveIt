from pathlib import Path
import hashlib,json
r=Path('/tmp/four-positive-wrappers');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');names=['ArithmeticHalfBinomialSandwich','ArithmeticNegativeNorms','ArithmeticNegativeNormsChecks','ArithmeticCarrierSoundness2011','ArithmeticCarrierRadix2011','ArithmeticHalfBinomial','ArithmeticHalfBinomial2011','ArithmeticRankForcing2011','ArithmeticWindowZero','ArithmeticConstructionAssembly'];changed={'ArithmeticHalfBinomialSandwich','ArithmeticNegativeNorms','ArithmeticHalfBinomial2011','ArithmeticRankForcing2011'};h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();info={}
for ph in ('baseline','final'):
 s=r/ph/'DiophantineConsistency';s.mkdir(parents=True,exist_ok=True)
 for n in names:
  out=s/(n+'.lean')
  if ph=='baseline' or n not in changed:out.write_bytes((w/(n+'.lean')).read_bytes())
  info[ph+'/'+n]={'path':str(out),'sha256':h(out),'workspace':str(w/(n+'.lean')),'workspace_sha256':h(w/(n+'.lean'))}
(r/'snapshot-record.json').write_text(json.dumps(info,indent=2)+'\n')
