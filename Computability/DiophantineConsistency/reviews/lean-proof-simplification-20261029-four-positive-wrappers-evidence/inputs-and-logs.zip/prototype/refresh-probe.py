from pathlib import Path
import json,hashlib,subprocess,os,sys
r=Path('/tmp/four-positive-wrappers');ph=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=json.loads((r/(ph+'-records.json')).read_text())[0]['LEAN_PATH'];h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();out=[];lib=r/('objects-'+ph)/'DiophantineConsistency';objects=[lib/(n+'.olean') for n in ('ArithmeticHalfBinomialSandwich','ArithmeticNegativeNorms','ArithmeticHalfBinomial2011','ArithmeticRankForcing2011','ArithmeticConstructionAssembly','ArithmeticWindowZero')]
for n in ('names','interfaces','simp','instances'):
 src=r/(n+'.lean');log=r/(ph+'-'+n+'.log');tm=r/(ph+'-'+n+'.time');before=h(src);obs=[h(x) for x in objects];cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':ph,'name':n,'status':q.returncode,'source':str(src),'source_before':before,'source_after':h(src),'objects':[str(x) for x in objects],'objects_before':obs,'objects_after':[h(x) for x in objects],'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm)};out.append(rec);(r/(ph+'-probes.json')).write_text(json.dumps(out,indent=2)+'\n');print(ph,n,q.returncode,tm.read_text().strip(),flush=True)
 if q.returncode or before!=h(src) or obs!=[h(x) for x in objects]:sys.exit(1)
