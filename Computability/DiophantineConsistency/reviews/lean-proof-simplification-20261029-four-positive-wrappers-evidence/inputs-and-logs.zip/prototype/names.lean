import Lean.Elab.Command
import DiophantineConsistency.ArithmeticConstructionAssembly
import DiophantineConsistency.ArithmeticWindowZero
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticHalfBinomialSandwich).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticHalfBinomialSandwich" ||
     (`DiophantineConsistency.ArithmeticNegativeNorms).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticNegativeNorms" ||
     (`DiophantineConsistency.ArithmeticHalfBinomial2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticHalfBinomial2011" ||
     (`DiophantineConsistency.ArithmeticRankForcing2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRankForcing2011" then
   logInfo m!"DECL {n}"
