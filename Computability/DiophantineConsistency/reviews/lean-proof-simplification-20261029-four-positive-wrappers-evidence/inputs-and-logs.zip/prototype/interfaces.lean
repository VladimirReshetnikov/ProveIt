import Lean.Elab.Command
import DiophantineConsistency.ArithmeticConstructionAssembly
import DiophantineConsistency.ArithmeticWindowZero
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticHalfBinomialSandwich).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticHalfBinomialSandwich" ||
     (`DiophantineConsistency.ArithmeticNegativeNorms).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticNegativeNorms" ||
     (`DiophantineConsistency.ArithmeticHalfBinomial2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticHalfBinomial2011" ||
     (`DiophantineConsistency.ArithmeticRankForcing2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRankForcing2011" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
