from pathlib import Path
import os,json,hashlib,subprocess,sys,re,shutil
r=Path('/tmp/four-positive-wrappers'); w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();mode=sys.argv[1]
up=['ArithmeticPellResidueClasses','ArithmeticPellHalfIndex','ArithmeticPellFirstIndex','ArithmeticPellPowerRecovery','ArithmeticPellSquaredSeed','ArithmeticPellAuxiliarySeed']
chain=['ArithmeticHalfBinomialSandwich','ArithmeticNegativeNorms','ArithmeticNegativeNormsChecks','ArithmeticCarrierSoundness2011','ArithmeticCarrierRadix2011','ArithmeticHalfBinomial','ArithmeticHalfBinomial2011','ArithmeticRankForcing2011','ArithmeticWindowInterface','ArithmeticWindowZero','ArithmeticOuterSeed','ArithmeticConstructionBoundPell','ArithmeticConstructionAssembly']
mods='DiophantineConsistency'
if mode=='prepare':
 c=r/'refreshed-common';c.mkdir(exist_ok=True);subprocess.run(['cp','-as',str(r/'common'/mods),str(c/mods)],check=True)
 overrides={}
 for n in ['ArithmeticPellCongruences','ArithmeticPellFirstNorm','ArithmeticPellPeriodicity']: overrides[n]=Path('/tmp/pell-y-add/objects-final')/mods/(n+'.olean')
 for n in ['ArithmeticPacking','ArithmeticPackingCells','ArithmeticConstructionVariation']: overrides[n]=Path('/tmp/packing-rotation-simplify/objects-final')/mods/(n+'.olean')
 overrides['ArithmeticTilingWord']=Path('/tmp/tiling-band-dispatch/objects-final')/mods/'ArithmeticTilingWord.olean'
 overrides['ArithmeticWindowCarry']=Path('/tmp/cyclic-rot-mod/objects-final')/mods/'ArithmeticWindowCarry.olean'
 overrides['ArithmeticWindowBits']=Path('/tmp/window-digit-replace/objects-final')/mods/'ArithmeticWindowBits.olean'
 overrides['ArithmeticStandardCasts']=Path('/tmp/binary-half-direct/supplement-objects-final')/mods/'ArithmeticStandardCasts.olean'
 rows=[]
 for n,p in overrides.items():
  assert p.is_file(),p; d=c/mods/(n+'.olean');d.unlink(missing_ok=True);d.symlink_to(p);rows.append({'module':n,'object':str(p),'object_sha256':h(p),'workspace_source':str(w/(n+'.lean')),'source_sha256':h(w/(n+'.lean'))})
 for phase,names in [('upstream',up),('refreshed-baseline',chain),('refreshed-final',chain)]:
  dest=r/phase/mods;dest.mkdir(parents=True,exist_ok=True)
  for n in names:
   p=(r/('final' if phase=='refreshed-final' else 'baseline')/mods/(n+'.lean')) if n in ['ArithmeticHalfBinomialSandwich','ArithmeticNegativeNorms','ArithmeticHalfBinomial2011','ArithmeticRankForcing2011'] and phase!='upstream' else w/(n+'.lean')
   shutil.copyfile(p,dest/(n+'.lean'))
   rows.append({'phase':phase,'module':n,'source':str(dest/(n+'.lean')),'source_sha256':h(dest/(n+'.lean')),'workspace_sha256':h(w/(n+'.lean'))})
 (r/'refresh-setup.json').write_text(json.dumps(rows,indent=2)+'\n');print('setup ready',len(rows));sys.exit()
assert mode in ['upstream','refreshed-baseline','refreshed-final'];names=up if mode=='upstream' else chain
lib=r/'refreshed-common' if mode=='upstream' else r/('objects-'+mode)
if mode!='upstream':
 lib.mkdir(exist_ok=True)
 if not (lib/mods).exists():subprocess.run(['cp','-as',str(r/'refreshed-common'/mods),str(lib/mods)],check=True)
for n in names:(lib/mods/(n+'.olean')).unlink(missing_ok=True)
env=os.environ.copy();env['LEAN_PATH']=str(lib)+':/tmp/mask-ins-construction/final:'+env['LEAN_PATH'];rows=[]
for n in names:
 src=r/mode/mods/(n+'.lean'); imports=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M);inputs=[]
 for name in imports:
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file()); leaf=name.split('.')[-1];sp=r/mode/mods/(leaf+'.lean') if leaf in names else (r/'upstream'/mods/(leaf+'.lean') if leaf in up else (Path('/tmp/pow-perturbation/final/DiophantineConsistency/ArithmeticPow.lean') if leaf=='ArithmeticPow' else w/(leaf+'.lean')));inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 obj=lib/mods/(n+'.olean');tm=r/(mode+'-'+n+'.time');log=r/(mode+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/mode),str(src),'-o',str(obj)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'phase':mode,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None};rows.append(rec);(r/(mode+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(mode,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
