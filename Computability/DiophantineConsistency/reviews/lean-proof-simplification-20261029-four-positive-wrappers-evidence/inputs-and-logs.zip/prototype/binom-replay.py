from pathlib import Path
import os,json,hashlib,subprocess,sys,re
r=Path('/tmp/four-positive-wrappers');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();phase=sys.argv[1];assert phase in ('baseline','final');names=['ArithmeticHalfBinomial','ArithmeticHalfBinomial2011','ArithmeticWindowZero','ArithmeticOuterSeed','ArithmeticConstructionBoundPell','ArithmeticConstructionAssembly'];prefix='refreshed-'+phase;lib=r/('objects-binom-'+phase);lib.mkdir(exist_ok=True);subprocess.run(['cp','-as',str(r/('objects-'+prefix)/'DiophantineConsistency'),str(lib/'DiophantineConsistency')],check=True)
obj=Path('/tmp/pow-perturbation/objects-final/DiophantineConsistency/ArithmeticBinomExpansion.olean');assert obj.is_file();dst=lib/'DiophantineConsistency/ArithmeticBinomExpansion.olean';dst.unlink();dst.symlink_to(obj)
for n in names:(lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True)
env=os.environ.copy();env['LEAN_PATH']=str(lib)+':/tmp/mask-ins-construction/final:'+env['LEAN_PATH'];rows=[]
for n in names:
 src=r/prefix/'DiophantineConsistency'/(n+'.lean');imports=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M);inputs=[]
 for name in imports:
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());leaf=name.split('.')[-1]; sp=r/prefix/'DiophantineConsistency'/(leaf+'.lean');sp=sp if sp.exists() else (r/'upstream/DiophantineConsistency'/(leaf+'.lean') if (r/'upstream/DiophantineConsistency'/(leaf+'.lean')).exists() else w/(leaf+'.lean'));inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 out=lib/'DiophantineConsistency'/(n+'.olean');tm=r/('binom-'+phase+'-'+n+'.time');log=r/('binom-'+phase+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/prefix),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'phase':phase,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};rows.append(rec);(r/('binom-'+phase+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print('binom',phase,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
