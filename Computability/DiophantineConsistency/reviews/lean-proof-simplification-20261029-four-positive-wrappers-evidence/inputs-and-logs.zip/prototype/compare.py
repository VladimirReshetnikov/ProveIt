from pathlib import Path
import re,json
r=Path('/tmp/four-positive-wrappers');data={}
for kind in ('names','interfaces','simp','instances'):
 logs=[(r/('binom-'+phase+'-'+kind+'.log')).read_text() for phase in ('baseline','final')]
 if kind=='interfaces':
  def blocks(s):
   lines=re.split(r'(?m)^DECL ',s); return {x.split(' TYPE ',1)[0]:x for x in lines if x}
  a,b=map(blocks,logs);data[kind]={'baseline_count':len(a),'final_count':len(b),'removed':sorted(a.keys()-b.keys()),'added':sorted(b.keys()-a.keys()),'changed_common':sorted(k for k in a.keys()&b.keys() if a[k]!=b[k])}
 else:
  a,b=map(lambda s:set(s.splitlines()),logs);data[kind]={'baseline_count':len(a),'final_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)}
a=json.loads((r/'binom-baseline-records.json').read_text());b=json.loads((r/'binom-final-records.json').read_text());data['binom_replay_objects']={x['module']:{'identical':x['object_sha256']==y['object_sha256'],'baseline':x['object_sha256'],'final':y['object_sha256'],'baseline_time':x['time'],'final_time':y['time']} for x,y in zip(a,b)}
a=json.loads((r/'refreshed-baseline-records.json').read_text());b=json.loads((r/'refreshed-final-records.json').read_text());data['first_phase_objects']={x['module']:{'identical':x['object_sha256']==y['object_sha256'],'baseline':x['object_sha256'],'final':y['object_sha256'],'baseline_time':x['time'],'final_time':y['time']} for x,y in zip(a,b)}
(r/'comparison.json').write_text(json.dumps(data,indent=2)+'\n')
for k in ('names','interfaces','simp','instances'):print(k, data[k]['baseline_count'],data[k]['final_count'],len(data[k]['removed']),len(data[k]['added']),len(data[k].get('changed_common',[])))
print('removed:',*data['names']['removed'],sep='\n')
print('binom object matches:',{k:v['identical'] for k,v in data['binom_replay_objects'].items()})
