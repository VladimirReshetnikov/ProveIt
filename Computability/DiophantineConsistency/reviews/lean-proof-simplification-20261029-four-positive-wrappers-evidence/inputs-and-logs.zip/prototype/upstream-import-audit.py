from pathlib import Path
import re,json
w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); graph={}
def walk(n):
 if n in graph:return
 p=w/(n+'.lean'); graph[n]=re.findall(r'^import DiophantineConsistency\.([^\s]+)',p.read_text(),re.M) if p.exists() else []
 for child in graph[n]:walk(child)
for name in ['ArithmeticPellResidueClasses','ArithmeticPellHalfIndex','ArithmeticPellFirstIndex','ArithmeticPellPowerRecovery','ArithmeticPellSquaredSeed','ArithmeticPellAuxiliarySeed']:walk(name)
print(json.dumps({'sources':len(graph),'overridden_paths_reachable':{n:n in graph for n in ['ArithmeticPow','ArithmeticCyclicWord','ArithmeticTilingBand']},'graph':graph},indent=2))
