from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/four-positive-wrappers');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
changed={'ArithmeticHalfBinomialSandwich':0,'ArithmeticNegativeNorms':1,'ArithmeticHalfBinomial2011':3,'ArithmeticRankForcing2011':3};old='''private theorem one_le_of_pos {x : V} (h : 0<x) : 1≤x := by
  simpa using lt_iff_succ_le.mp h

'''
for n,c in changed.items():
 b=(R/'baseline/DiophantineConsistency'/f'{n}.lean').read_text();f=(R/'final/DiophantineConsistency'/f'{n}.lean').read_text();assert b.count(old)==1 and b.count('one_le_of_pos')==c+1 and b.replace(old,'').replace('one_le_of_pos','pos_iff_one_le.mp')==f
 rel=f'Computability/DiophantineConsistency/Lean/DiophantineConsistency/{n}.lean';assert subprocess.check_output(['git','show',f'75c50fe733^:{rel}']).decode()==b and subprocess.check_output(['git','show',f'75c50fe733:{rel}']).decode()==f and (W/(n+'.lean')).read_text()==f;print('PASS source diff, commit/parent',n,c,'calls')
paths={'ArithmeticPow':'/tmp/pow-perturbation/final-target-records.json','ArithmeticBinomExpansion':'/tmp/pow-perturbation/final-client-records.json','ArithmeticSignedPairs':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','CurrentEquationSyntax2011':'/tmp/positive-shift-sharing/source-clean/records.json','ArithmeticRadixAlignment':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','ArithmeticBinomLegendre':'/tmp/binary-half-direct/final-supplement-records.json','ArithmeticRankForcing':'/tmp/rank-order-cleanup/final-records.json','ArithmeticMaskPopulation':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','ArithmeticMaskConstants':'/tmp/mask-ins-simplify/records.json','ArithmeticSaturation':'/tmp/binary-half-direct/final-supplement-records.json','ArithmeticWindowBits':'/tmp/window-digit-replace/final-records.json','ArithmeticWindowCarry':'/tmp/cyclic-rot-mod/final-records.json','ArithmeticCurrentSentence2011':'/tmp/positive-shift-sharing/source-clean/records.json','ArithmeticTilingWord':'/tmp/tiling-band-dispatch/final-records.json','ArithmeticPackingCells':'/tmp/packing-rotation-simplify/final-records.json','ArithmeticController':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','ArithmeticConstructionUnit':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','ArithmeticConstructionVariation':'/tmp/packing-rotation-simplify/final-records.json'};providers={}
for n,path in paths.items():
 matches=[x for x in read(path) if (x.get('module') or x.get('name','')).split('.')[-1]==n and x.get('status')==0]; assert matches
 for x in matches:
  a=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');z=x.get('after') or x.get('source_after') or x.get('source_sha256_after') or x.get('source_sha256');
  if a==z==h(W/(n+'.lean')):providers[n]=x['object_sha256'];break
 assert n in providers,(n,path);print('PASS prior external producer source/object',n,providers[n])
up={x['module']:x for x in read(R/'upstream-records.json')};assert len(up)==6
selected={}
for phase in ('baseline','final'):
 raw=read(R/f'refreshed-{phase}-records.json');rr=read(R/f'binom-{phase}-records.json');assert len(raw)==13 and len(rr)==6
 m={x['module']:x for x in raw};m.update({x['module']:x for x in rr});assert len(m)==13;selected[phase]=m
 for x in m.values():
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module'] not in changed:assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d['source_before'] is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n in m:assert d['before']==m[n]['object_sha256']
   elif n in up:assert d['before']==up[n]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
   else:assert d['module'] in ['Foundation.FirstOrder.Arithmetic.IOpen.Basic','Mathlib.Tactic.Ring']
  print('PASS selected',phase,x['module'],x['time'].strip())
print('PASS 26 selected builds and direct provider associations; see separate upstream peer audit')
edges={n:sorted(p.stem for p in W.glob('*.lean') if re.search(r'^import DiophantineConsistency\.'+re.escape(n)+r'$',p.read_text(),re.M)) for n in changed}
assert edges=={'ArithmeticHalfBinomialSandwich':['ArithmeticHalfBinomial'],'ArithmeticNegativeNorms':['ArithmeticCarrierSoundness2011','ArithmeticNegativeNormsChecks'],'ArithmeticHalfBinomial2011':['ArithmeticWindowZero'],'ArithmeticRankForcing2011':['ArithmeticConstructionAssembly']}
for clients in edges.values():assert all(n in selected['baseline'] and n in selected['final'] for n in clients)
for n in set(selected['baseline'])-set(changed):assert selected['baseline'][n]['object_sha256']==selected['final'][n]['object_sha256']
print('PASS all five direct module clients and nine unchanged object pairs')
for phase in ('baseline','final'):
 rows=read(R/f'binom-{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
  for p,v in zip(x['objects'],x['objects_before']):assert v==selected[phase][Path(p).stem]['object_sha256']
def blocks(p):
 s=Path(p).read_text();return {t.split(' TYPE ',1)[0]:'DECL '+t for t in re.split(r'(?m)^DECL ',s)[1:]}
a=blocks(R/'binom-baseline-interfaces.log');z=blocks(R/'binom-final-interfaces.log');removed=set(a)-set(z);assert len(removed)==4 and not(set(z)-set(a)) and all(n.endswith('.one_le_of_pos') for n in removed) and all(a[n]==z[n] for n in z)
for n in ('simp','instances'):assert (R/f'binom-baseline-{n}.log').read_bytes()==(R/f'binom-final-{n}.log').read_bytes() and all(q not in (R/f'binom-baseline-{n}.log').read_text() for q in removed)
print('PASS 46 common declaration blocks, exactly four private removals, equal simp/instances')
from collections import deque
q=deque(up);seen=set()
while q:
 n=q.popleft()
 if n in seen:continue
 seen.add(n);p=W/(n+'.lean')
 if p.exists():q.extend(re.findall(r'^import\s+DiophantineConsistency\.(\w+)',p.read_text(),re.M))
assert not seen.intersection({'ArithmeticPow','ArithmeticCyclicWord','ArithmeticTilingBand'})
old=next(x for x in read('/tmp/outer-seed-bound-sharing/prereq2-records.json') if x['module'].endswith('.ArithmeticBinomExpansion'))
assert old['status']==0 and old['source_sha256']==old['source_after']=='256acd2a842797ab88aa1220da5c1b3adff786c45ccbc6af798537936f11a1be' and old['object_sha256']=='c939d24e1c9323a17b7ff35526a4d89f6e52b31fc8edbdf08d7120daab5f3810'
for phase in ('baseline','final'):
 x=next(x for x in read(R/f'refreshed-{phase}-records.json') if x['module']=='ArithmeticHalfBinomial');d=next(d for d in x['direct_inputs'] if d['module'].endswith('.ArithmeticBinomExpansion'));assert d['before']==old['object_sha256'] and d['source_before']==h(W/'ArithmeticBinomExpansion.lean')!=old['source_sha256']
 x=selected[phase]['ArithmeticHalfBinomial'];d=next(d for d in x['direct_inputs'] if d['module'].endswith('.ArithmeticBinomExpansion'));assert d['before']==providers['ArithmeticBinomExpansion']
print('PASS upstream source-graph exclusion of three overridden modules; historical old BinomExpansion boundary and selected current producer replay')
