from pathlib import Path
import hashlib,json,re
R=Path('/tmp/four-positive-wrappers');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
rows=read(R/'upstream-records.json');rec={x['module']:x for x in rows};assert len(rows)==6 and len(rec)==6
prior={}
for p in ['/tmp/pell-y-add/final-records.json','/tmp/pell-square-direct/final-records.json','/tmp/shared-modular-cancel/records.json']:
 for x in read(p):
  n=x['module'].split('.')[-1]
  if n in ['ArithmeticPellPeriodicity','ArithmeticPellFirstNorm','ArithmeticPellIndexDivisibility','ArithmeticModularCancellation']:
   before=x.get('before') or x.get('source_before');after=x.get('after') or x.get('source_after');assert x['status']==0 and before==after==h(W/(n+'.lean'));prior[n]=x['object_sha256']
assert len(prior)==4
for x in rows:
 assert x['status']==0 and x['before']==x['after']==h(x['source'])==h(W/(x['module']+'.lean')) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
 assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
 for d in x['direct_inputs']:
  p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source']);n=d['module'].split('.')[-1];assert d['before']==(rec[n]['object_sha256'] if n in rec else prior[n])
 print('PASS upstream',x['module'],x['object_sha256'])
print('PASS four adopted external direct source/object producer matches; remaining transitive closure cached')
