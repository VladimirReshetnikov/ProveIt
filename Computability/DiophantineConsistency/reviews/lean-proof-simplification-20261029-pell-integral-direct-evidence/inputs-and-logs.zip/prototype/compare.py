from pathlib import Path
import re,json
r=Path('/tmp/pell-integral-direct');data={}
for kind in ('names','interfaces','simp','instances'):
 logs=[(r/(phase+'-'+kind+'.log')).read_text() for phase in ('baseline','final')]
 if kind=='interfaces':
  def blocks(s):
   return {x.split(' TYPE ',1)[0]:x for x in re.split(r'(?m)^DECL ',s) if x}
  a,b=map(blocks,logs);data[kind]={'baseline_count':len(a),'final_count':len(b),'removed':sorted(a.keys()-b.keys()),'added':sorted(b.keys()-a.keys()),'changed_common':sorted(k for k in a.keys()&b.keys() if a[k]!=b[k])}
 else:
  a,b=map(lambda s:set(s.splitlines()),logs);data[kind]={'baseline_count':len(a),'final_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)}
a=json.loads((r/'baseline-records.json').read_text());b=json.loads((r/'final-records.json').read_text());data['objects']={x['module']:{'identical':x['object_sha256']==y['object_sha256'],'baseline':x['object_sha256'],'final':y['object_sha256'],'baseline_time':x['time'],'final_time':y['time']} for x,y in zip(a,b)};(r/'comparison.json').write_text(json.dumps(data,indent=2)+'\n')
for k in ('names','interfaces','simp','instances'):print(k,data[k]['baseline_count'],data[k]['final_count'],'removed',len(data[k]['removed']),'added',len(data[k]['added']),'changed_common',len(data[k].get('changed_common',[])))
print('removed',*data['names']['removed'],sep='\n');print('added',*data['names']['added'],sep='\n');print('objects', {k:v['identical'] for k,v in data['objects'].items()})
