from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/pell-integral-direct');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticPellIntegralSolution.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticPellIntegralSolution.lean').read_text()
old='''private theorem le_of_positive_multiple {c v : V} (hv : 0<v) (h : c∣v) : c≤v := by
  obtain ⟨k,hk⟩ := h
  have hkp : 0<k := by
    by_contra hn
    have hz : k=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le k)
    simp [hz] at hk
    simp [hk] at hv
  rw [hk]
  exact Arithmetic.le_mul_of_pos_right hkp

'''
assert b.count(old)==1 and b.count('le_of_positive_multiple')==2 and b.replace(old,'').replace('le_of_positive_multiple (mul_pos hT hygp) hcg','le_of_dvd (mul_pos hT hygp) hcg')==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellIntegralSolution.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('1a0b5f209e^')==b and gitfile('1a0b5f209e')==f and (W/'ArithmeticPellIntegralSolution.lean').read_text()==f
print('PASS exact helper deletion, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticPellIntegralSolution$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(p).stem for p in clients)==['ArithmeticPellIndexDivisibility','ArithmeticPellIntegralSolutionChecks'];print('PASS two tracked direct module clients',clients)
paths={'ArithmeticPellCommonUnit':'/tmp/pell-square-direct/final-records.json','ArithmeticPellStrongDivisibility':'/tmp/pell-reflection-simp/refresh-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module'].split('.')[-1]==n);assert x['status']==0 and x['before']==x['after']==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticPellIntegralSolution','ArithmeticPellIntegralSolutionChecks','ArithmeticPellIndexDivisibility'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticPellIntegralSolution':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d.get('source_before') is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n=='ArithmeticPellIntegralSolution':assert d['before']==rec[phase][n]['object_sha256']
   else:assert d['before']==providers[n]
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticPellIntegralSolutionChecks','ArithmeticPellIndexDivisibility'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS both direct client object pairs byte-identical')
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][Path(p).stem]['object_sha256'] for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
def blocks(p):return {t.split(' TYPE ',1)[0]:'DECL '+t for t in re.split(r'(?m)^DECL ',Path(p).read_text())[1:]}
a=blocks(R/'baseline-interfaces.log');z=blocks(R/'final-interfaces.log');removed=set(a)-set(z);assert len(removed)==1 and next(iter(removed)).endswith('.le_of_positive_multiple') and not(set(z)-set(a)) and all(a[n]==z[n] for n in z)
for n in ('simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes() and all(q not in (R/f'baseline-{n}.log').read_text() for q in removed)
print('PASS 3-object-pinned target probes; 5 common type/axiom blocks and one removed unregistered private name')
