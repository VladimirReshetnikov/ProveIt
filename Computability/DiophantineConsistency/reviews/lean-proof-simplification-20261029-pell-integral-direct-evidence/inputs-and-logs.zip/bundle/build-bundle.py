from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs');R=Path('/tmp/pell-integral-direct');D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-pell-integral-direct-evidence';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();items={}
def add(n,p):assert n not in items;items[n]=Path(p).read_bytes()
def git(p,rev):return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=ROOT)
rev='1a0b5f209e3f1e5b610ef65a3d00563f2606b014';parent='17d4eedfbd1adc887644c8c2caffec83e150238d';mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for ph,ref in [('baseline',parent),('final',rev)]:
 key=f'commit/{ph}.lean';items[key]=git(mod+'ArithmeticPellIntegralSolution.lean',ref);assert items[key]==(R/ph/'DiophantineConsistency/ArithmeticPellIntegralSolution.lean').read_bytes()
for n in ['ArithmeticPellIntegralSolutionChecks','ArithmeticPellIndexDivisibility','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility']:
 items['provider-sources/'+n+'.lean']=git(mod+n+'.lean',rev)
for f in sorted(R.rglob('*')):
 parts=f.relative_to(R).parts
 if f.is_file() and f.suffix not in ('.olean','.ilean','.c') and not any(x=='common' or x.startswith('objects-') for x in parts):add('prototype/'+f.relative_to(R).as_posix(),f)
for n,p in {'prior/pell-square-final.json':'/tmp/pell-square-direct/final-records.json','prior/pell-reflection-refresh.json':'/tmp/pell-reflection-simp/refresh-records.json','independent/review.txt':'/tmp/pell-integral-direct-peer-review.txt','independent/audit.py':'/tmp/pell-integral-direct-peer-audit.py','independent/audit.log':'/tmp/pell-integral-direct-peer-audit.log','bundle/build-bundle.py':'/tmp/build-pell-integral-direct-bundle.py'}.items():add(n,p)
zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):
  i=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Replace private positive-divisibility wrapper with existing le_of_dvd',
'validation':'Paired target and both tracked direct module clients pass, with current-source CommonUnit and StrongDivisibility provider pairs mapped to earlier receipts. Both client object pairs match. Three-object-pinned probes show five identical surviving target declaration/type/axiom blocks, one private removal and matching global simp/instances.',
'limitations':['The private le_of_positive_multiple declaration disappears. The qualified-name search covers tracked Lean/Python only, not external or dynamic references.', 'Downstream HalfIndex, FirstIndex, AuxiliarySeed, OuterSeed and construction clients were not rebuilt in this lane; equal direct IndexDivisibility objects do not establish a full downstream replay.', 'Project and package transitive dependencies remain cached. Matching direct producer pairs do not establish a fully current-source closure; census reports do not prove equality of every persistent environment extension or proof body.', 'Single shared-load timing samples are not a general performance benchmark. Author source/build records are historical; included independent review/audit verify the commit and parent.', 'Compiled objects and cached overlays are omitted; receipt hashes and paths require external objects for independent byte verification.'],
'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(items)
 for n,b in items.items():assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes();print(n,sha(b),len(b))
