# Shared bounded scheduler proofs

28 October 2026. This isolated candidate makes the lower-level
`ArithmeticEnumFairPerm222` module prove the existing bounded reach and halting
results once. Its original unbounded theorems project the resulting witnesses;
`ArithmeticEnumBoundFair` retains its original public bounded theorem names as
wrappers. The existing `offset * (initialCandidate + offset)` and `word * word`
clock bounds, assumptions and all original theorem statements remain intact.
No import lines change. The earlier lower module gains two public names:
`reach_offset_bounded` and `halts_of_word_bounded`. The change removes a
second induction and a second scheduling argument, but adds two net source
lines rather than reducing line count.
The changed bounded module was introduced by Claude-coauthored commit
`9168659697`; its commit text is in `provenance/origin-commit.txt`.

## Builds and comparisons

Paired baseline/final builds succeeded for the two changed modules; the fair
scheduler checks, proof-word enum and checks, enum soundness, and the production
`ArithmeticProofWordBound` client. A further paired build of
`ArithmeticEnumBoundSoundness` succeeded. Each build has source and output
hashes, command, LEAN_PATH, timing, and direct-import before/after hashes in
`records/records.json` or `records/forward-client-records.json`. Source
snapshots and raw logs are included. The checks source for enum soundness is in
`sources/checks/`.

All 37 pre-existing names across the affected namespaces remain, including
Lean-generated auxiliaries. The two names above are added. Complete paired
`#check` and `#print axioms` reports for those 37 names are byte-identical;
the two default simp entries in those namespaces match. Both new helper axioms
and both old bounded wrapper axioms are `propext`, `Classical.choice`, and
`Quot.sound`. Probe commands and hashes are in `records/probe-records-all.json`
and `records/helper-probe-record.json`; the earlier 28-name probe was
superseded by the 37-name probe and is not relied upon.

The unchanged-source clients `ArithmeticEnumSoundnessPerm222` and
`ArithmeticEnumBoundSoundness` produced different object bytes between phases.
The former has the same 36 declaration names and identical type/axiom reports
and check output; the latter has the same 127 names and identical type/axiom
reports. These comparisons do not assert identical proof terms or every Lean
environment extension. Their probe receipts are in
`records/client-probe-records.json` and `records/forward-probe-records.json`.
The `ArithmeticProofWordBound` object bytes matched across phases.

A single local paired timing measured baseline lower/bounded modules at 9.42
and 7.48 seconds user CPU, and final at 12.15 and 2.39 seconds respectively.
Thus the stronger proof shifts work to the lower module; the two-module total
was lower in this one run. These are not a repeated benchmark or a general
performance guarantee.

## Dependency limits

After Cantor provider commit `34bb4f5483` was adopted, both production clients
were rebuilt in both phases against its tested final tower and level objects.
All four passed. `records/refresh-cantor-records.json` pins the adopted commit,
current provider source and object hashes, compiled client snapshot and live
source hashes, and each direct import before/after. The provider source copies
and their original tested-build receipts are included. The refreshed
`ArithmeticProofWordBound` objects are byte-identical across phases; the
bounded-soundness objects differ, but paired names and all 127 type/axiom
reports match (`records/refresh-forward-probe-records.json`). Earlier
pre-Cantor receipts remain in this package as historical evidence.

An independent review identified a misleading module comment in the initial
candidate. The current candidate is `candidate-doc2.patch` and
`sources/final-doc2/`: its comment states the boundary-or-earlier-halt
alternative and the existing `4 ≤ word - 1` guard. The original candidate and
an intermediate comment revision remain under `sources/final/` and
`sources/final-doc/`. After the final comment correction, the bounded target
and `ArithmeticProofWordBound` were rebuilt against the adopted providers; all
37 old name/type/axiom reports and the namespace simp entries still match,
and the baseline/final proof-word objects are byte-identical. See
`records/final-doc2-records.json` and `records/final-doc2-probe-records.json`.
The original archive's hash is preserved in `history/`.

The phase overlays reuse cached project, Foundation and Lean/toolchain objects.
Direct imports were hashed before and after each recorded build, but this is
not a clean source rebuild of the transitive closure. Previous cached provider
and build records are retained in `provenance/`. Scripts record original
absolute temporary paths and require their original overlays; compiled objects
are intentionally excluded. `manifest.sha256` covers every other package file.
