from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/enum-fair-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(phase,probe):
 src=R/(probe+'.lean');out=R/(phase+'-'+probe+'.log');tm=R/(phase+'-'+probe+'.time');env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=sha(src);dep=R/phase/'DiophantineConsistency/ArithmeticEnumBoundFair.olean';dh=sha(dep);t=time.monotonic()
 with out.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'probe':probe,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'input_sha256_before':before,'input_sha256_after':sha(src),'direct_import':str(dep),'direct_import_sha256_before':dh,'direct_import_sha256_after':sha(dep),'log_sha256':sha(out),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(rec);(R/'probe-records-all.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,probe,r.returncode,rec['time'].strip(),flush=True);assert r.returncode==0 and before==rec['input_sha256_after'] and dh==rec['direct_import_sha256_after']
for phase in ['baseline','final']:run(phase,'names')
read=lambda phase:{x[5:] for x in (R/(phase+'-names.log')).read_text().splitlines() if x.startswith('DECL ')}
a=read('baseline');b=read('final');(R/'name-diff.json').write_text(json.dumps({'baseline_count':len(a),'final_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)},indent=2)+'\n');print('names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),flush=True)
stable=sorted(n for n in a if n in b)
(R/'interfaces.lean').write_text('import DiophantineConsistency.ArithmeticEnumBoundFair\nset_option pp.universes true\n'+''.join('#check '+x+'\n#print axioms '+x+'\n' for x in stable))
for phase in ['baseline','final']:
 run(phase,'interfaces');run(phase,'simp')
print('stable interfaces identical:',(R/'baseline-interfaces.log').read_bytes()==(R/'final-interfaces.log').read_bytes(),'stable count',len(stable),flush=True)
print('simp matches:',set((R/'baseline-simp.log').read_text().splitlines())==set((R/'final-simp.log').read_text().splitlines()),flush=True)
