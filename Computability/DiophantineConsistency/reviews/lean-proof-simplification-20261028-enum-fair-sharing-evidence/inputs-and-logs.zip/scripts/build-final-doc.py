from pathlib import Path
import hashlib,json,os,re,subprocess,time,shutil
R=Path('/tmp/enum-fair-sharing');P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');old=R/'refresh-final';out=R/'refresh-final-doc';out.mkdir(exist_ok=True);base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for p in old.rglob('*'):
 if p.is_file():
  q=out/p.relative_to(old);q.parent.mkdir(parents=True,exist_ok=True)
  if not q.exists():q.symlink_to(p.resolve())
if not (out/'Foundation').exists():(out/'Foundation').symlink_to((old/'Foundation').resolve())
root=R/'sources/final-doc';srcdir=root/'DiophantineConsistency';name='ArithmeticProofWordBound';shutil.copyfile(P/f'{name}.lean',srcdir/f'{name}.lean');env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base
for n in ['ArithmeticEnumBoundFair','ArithmeticProofWordBound']:
 src=srcdir/f'{n}.lean';live=P/f'{n}.lean' if n=='ArithmeticProofWordBound' else None;live_before=sha(live) if live else None
 if live:assert live_before==sha(src)
 deps=[]
 for mod in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  p=next((Path(d)/(mod.replace('.','/')+'.olean') for d in env['LEAN_PATH'].split(':') if (Path(d)/(mod.replace('.','/')+'.olean')).is_file()),None)
  if not p:raise RuntimeError('missing '+mod)
  deps.append({'module':mod,'path':str(p),'resolved':str(p.resolve()),'before':sha(p)})
 obj=out/'DiophantineConsistency'/f'{n}.olean';obj.unlink(missing_ok=True);log=R/f'final-doc-{n}.log';tm=R/f'final-doc-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];h=sha(src);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['after']=sha(d['path'])
 z={'phase':'final-doc','module':n,'status':r.returncode,'git_head':head,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256_before':h,'source_sha256_after':sha(src),'current_source':str(live) if live else None,'current_source_sha256_before':live_before,'current_source_sha256_after':sha(live) if live else None,'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'final-doc-records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,r.returncode,z['time'].strip(),flush=True)
 assert r.returncode==0 and h==z['source_sha256_after'] and all(d['before']==d['after'] for d in deps) and (not live or live_before==z['current_source_sha256_after'])
