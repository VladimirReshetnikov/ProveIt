from pathlib import Path
import hashlib,json,os,re,subprocess,time,shutil
R=Path('/tmp/enum-fair-sharing');P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');C=Path('/tmp/cantor-bound-simplify');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='34bb4f548343304698a6222682fc799c903afe9b';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior=json.loads((C/'build-records.json').read_text());providers={}
for n,lane in [('ArithmeticEnumBoundTower','tower'),('ArithmeticProofWordBoundLevel','level')]:
 rec=next(x for x in prior if x['phase']=='final' and x['name']==n);src=P/f'{n}.lean';obj=C/(lane+'-final')/'DiophantineConsistency'/f'{n}.olean';assert rec['status']==0 and sha(src)==rec['before']==rec['after'] and sha(obj)==rec['object_sha256'];providers[n]={'source':str(src),'source_sha256':sha(src),'object':str(obj),'object_sha256':sha(obj),'receipt':str(C/'build-records.json'),'receipt_lane':lane,'receipt_inputs':rec['inputs']}
records=[]
for phase in ['baseline','final']:
 old=R/phase;out=R/('refresh-'+phase);out.mkdir(exist_ok=True)
 for p in old.rglob('*'):
  if p.is_file():
   q=out/p.relative_to(old);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists():q.symlink_to(p.resolve())
 if not (out/'Foundation').exists():(out/'Foundation').symlink_to((old/'Foundation').resolve())
 for name,prov in providers.items():
  q=out/'DiophantineConsistency'/f'{name}.olean';q.unlink(missing_ok=True);q.symlink_to(Path(prov['object']).resolve())
  for mod,v in prov['receipt_inputs'].items():
   q=out/(mod.replace('.','/')+'.olean');assert q.is_file() and sha(q)==v['before']==v['after'],(phase,name,mod)
 env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base
 for n in ['ArithmeticProofWordBound','ArithmeticEnumBoundSoundness']:
  current=P/f'{n}.lean';src=R/'refresh-sources'/phase/'DiophantineConsistency'/f'{n}.lean';src.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(current,src);current_before=sha(current);assert sha(src)==current_before
  deps=[]
  for mod in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
   paths=[Path(d)/(mod.replace('.','/')+'.olean') for d in env['LEAN_PATH'].split(':')];p=next((x for x in paths if x.is_file()),None)
   if not p:raise RuntimeError('Missing '+mod)
   deps.append({'module':mod,'path':str(p),'resolved':str(p.resolve()),'before':sha(p)})
  obj=out/'DiophantineConsistency'/f'{n}.olean';obj.unlink(missing_ok=True);log=R/f'refresh-{phase}-{n}.log';tm=R/f'refresh-{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(src.parent.parent),str(src),'-o',str(obj)];before=sha(src);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in deps:x['after']=sha(x['path'])
  z={'phase':phase,'module':n,'status':r.returncode,'git_head':head,'command':cmd,'lean_path':env['LEAN_PATH'],'current_source':str(current.resolve()),'current_source_sha256_before':current_before,'current_source_sha256_after':sha(current),'compiled_snapshot':str(src),'snapshot_sha256_before':before,'snapshot_sha256_after':sha(src),'direct_inputs':deps,'providers':{k:{**v,'source_sha256_after':sha(v['source']),'object_sha256_after':sha(v['object'])} for k,v in providers.items()},'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,3)};records.append(z);(R/'refresh-cantor-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,z['time'].strip(),flush=True)
  if r.returncode or current_before!=z['current_source_sha256_after'] or before!=z['snapshot_sha256_after'] or any(d['before']!=d['after'] for d in deps) or any(v['source_sha256']!=v['source_sha256_after'] or v['object_sha256']!=v['object_sha256_after'] for v in z['providers'].values()):raise SystemExit(1)
