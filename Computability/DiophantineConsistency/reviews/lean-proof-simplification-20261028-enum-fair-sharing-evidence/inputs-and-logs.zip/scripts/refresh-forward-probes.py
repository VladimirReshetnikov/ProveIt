from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/enum-fair-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 out=R/('refresh-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base
 for name in ['forward-names','forward-interfaces']:
  src=R/(name+'.lean');dep=out/'DiophantineConsistency/ArithmeticEnumBoundSoundness.olean';log=R/f'refresh-{phase}-{name}.log';tm=R/f'refresh-{phase}-{name}.time';h=sha(src);d=sha(dep);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  z={'phase':phase,'name':name,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256_before':h,'source_sha256_after':sha(src),'direct_import':str(dep),'direct_import_sha256_before':d,'direct_import_sha256_after':sha(dep),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'refresh-forward-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,r.returncode,z['time'].strip(),flush=True);assert r.returncode==0 and h==z['source_sha256_after'] and d==z['direct_import_sha256_after']
read=lambda p:{x for x in (R/('refresh-'+p+'-forward-names.log')).read_text().splitlines() if x.startswith('DECL ')}
a=read('baseline');b=read('final');print('names',len(a),len(b),'same',a==b,'type/axiom reports identical',(R/'refresh-baseline-forward-interfaces.log').read_bytes()==(R/'refresh-final-forward-interfaces.log').read_bytes(),flush=True)
assert a==b and len(a)==127;assert (R/'refresh-baseline-forward-interfaces.log').read_bytes()==(R/'refresh-final-forward-interfaces.log').read_bytes()
