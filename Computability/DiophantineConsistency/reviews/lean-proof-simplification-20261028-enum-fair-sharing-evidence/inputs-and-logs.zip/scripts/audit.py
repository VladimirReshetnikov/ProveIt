from pathlib import Path
import os,subprocess,time,hashlib,json,shutil,re
R=Path('/tmp/enum-fair-sharing');C=Path('/dev/shm/claude-ax-current/final');P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();records=[]
names=['ArithmeticEnumFairPerm222','ArithmeticEnumFairPerm222Checks','ArithmeticProofWordEnumPerm222','ArithmeticProofWordEnumPerm222Checks','ArithmeticEnumSoundnessPerm222','ArithmeticEnumBoundFair','ArithmeticProofWordBound'];changed={'ArithmeticEnumFairPerm222','ArithmeticEnumBoundFair'}
for phase in ['baseline','final']:
 out=R/phase;srcroot=R/'sources'/phase/'DiophantineConsistency';out.mkdir(exist_ok=True);srcroot.mkdir(parents=True,exist_ok=True)
 for p in C.rglob('*'):
  if p.is_file():
   q=out/p.relative_to(C);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists():q.symlink_to(p.resolve())
 if not (out/'Foundation').exists():(out/'Foundation').symlink_to((C/'Foundation').resolve())
 level=out/'DiophantineConsistency/ArithmeticProofWordBoundLevel.olean'
 if not level.exists():level.symlink_to(Path('/tmp/word-bound-simplify-20261028/lib/DiophantineConsistency/ArithmeticProofWordBoundLevel.olean').resolve())
 for n in names:
  source=(R/'src/DiophantineConsistency'/f'{n}.lean') if phase=='final' and n in changed else P/f'{n}.lean'
  shutil.copyfile(source,srcroot/f'{n}.lean')
 env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base
 for n in names:
  source=srcroot/f'{n}.lean';imports=re.findall(r'^import\s+([^\s]+)',source.read_text(),re.M);deps=[]
  for i in imports:
   paths=[Path(d)/(i.replace('.','/')+'.olean') for d in env['LEAN_PATH'].split(':')];p=next((x for x in paths if x.is_file()),None)
   if not p:raise RuntimeError('Missing '+i)
   deps.append({'module':i,'path':str(p),'resolved':str(p.resolve()),'before':sha(p)})
  obj=out/'DiophantineConsistency'/f'{n}.olean';obj.unlink(missing_ok=True);log=R/f'{phase}-{n}.log';tm=R/f'{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot.parent),str(source),'-o',str(obj)];h=sha(source);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in deps:x['after']=sha(x['path'])
  z={'phase':phase,'module':n,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(source),'source_sha256_before':h,'source_sha256_after':sha(source),'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,z['time'].strip(),flush=True)
  if r.returncode or z['source_sha256_before']!=z['source_sha256_after'] or any(d['before']!=d['after'] for d in deps):raise SystemExit(1)
