import DiophantineConsistency.ArithmeticEnumSoundnessPerm222
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticEnumSoundnessPerm222).isPrefixOf n then
      logInfo m!"DECL {n}"
