from pathlib import Path
P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');S=Path('/tmp/enum-fair-sharing/src/DiophantineConsistency')
fa=(P/'ArithmeticEnumFairPerm222.lean').read_text();fb=(P/'ArithmeticEnumBoundFair.lean').read_text()
start=fb.index('/-- `reach_offset` with the summed drain costs');end=fb.index('\nend Model',start);block=fb[start:end]
block=block.replace('reach_offset_le','reach_offset_bounded').replace('halts_of_word_le','halts_of_word_bounded')
start_fa=fa.index('/-- Every offset boundary is reached unless');end_fa=fa.index('/-- Candidate indices below',start_fa);old=fa[start_fa:end_fa];head=old[:old.index(' := by\n')+len(' := by\n')]
fa=fa[:start_fa]+block+'\n\n'+head+'''  obtain ⟨time, _, h⟩ := reach_offset_bounded offset initialCandidate initialWork
  exact ⟨time, h⟩

'''+fa[end_fa:]
start_fa=fa.index('/-- A universally halting word is scheduled');end_fa=fa.index('\nend DiophantineConsistency',start_fa);old=fa[start_fa:end_fa];head=old[:old.index(' := by\n')+len(' := by\n')]
fa=fa[:start_fa]+head+'''  obtain ⟨time, _, h⟩ := halts_of_word_bounded word initialCandidate initialWork hp hindex hall
  exact ⟨time, h⟩
'''+fa[end_fa:]
start=fb.index('/-- `reach_offset` with the summed drain costs');end=fb.index('\nend Model',start);old=fb[start:end];sep=old.index('/-- `halts_of_word` with the explicit bound');one=old[:sep];two=old[sep:];onehead=one[:one.index(' := by\n')+len(' := by\n')];twohead=two[:two.index(' := by\n')+len(' := by\n')]
new=onehead+'''  exact ArithmeticEnumFairPerm222.reach_offset_bounded offset initialCandidate initialWork

'''+twohead+'''  exact ArithmeticEnumFairPerm222.halts_of_word_bounded word initialCandidate initialWork hp hindex hall
''';fb=fb[:start]+new+fb[end:]
(S/'ArithmeticEnumFairPerm222.lean').write_text(fa);(S/'ArithmeticEnumBoundFair.lean').write_text(fb)
