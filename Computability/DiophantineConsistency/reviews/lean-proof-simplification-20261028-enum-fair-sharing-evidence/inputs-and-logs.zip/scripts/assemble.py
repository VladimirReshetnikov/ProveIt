from pathlib import Path
import json,hashlib,shutil
E=Path(__file__).resolve().parent.parent;R=Path('/tmp/enum-fair-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for f in ['records.json','forward-client-records.json']:
 for x in json.loads((R/f).read_text()):
  assert x['status']==0 and x['source_sha256_before']==x['source_sha256_after'];p=Path(x['source']);assert p.exists() and sha(p)==x['source_sha256_before'];obj=Path(x['object']);assert obj.exists() and sha(obj)==x['object_sha256'];assert all(i['before']==i['after'] and sha(i['path'])==i['before'] for i in x['direct_inputs']);dest=E/'sources'/x['phase']/p.name
  if dest.exists():assert sha(dest)==sha(p)
  else:shutil.copy2(p,dest)
for n in ['records.json','forward-client-records.json','probe-records-all.json','client-probe-records.json','forward-probe-records.json','helper-probe-record.json','name-diff.json','client-name-diff.json','forward-name-diff.json']:
 shutil.copy2(R/n,E/'records'/n)
for n in ['audit.py','make.py','probes-all.py','client-probes.py','forward-client.py','forward-probes.py','helper-probe.py','names.lean','interfaces.lean','simp.lean','client-names.lean','client-interfaces.lean','forward-names.lean','forward-interfaces.lean','new-helper-report.lean']:
 shutil.copy2(R/n,E/'scripts'/n)
for p in R.iterdir():
 if p.is_file() and p.suffix in ['.log','.time']:shutil.copy2(p,E/'logs'/p.name)
shutil.copy2(R/'candidate.patch',E/'candidate.patch')
for n in ['graph.json','coherent-common-records.json','phase-records.json']:
 p=Path('/tmp/claude-ax-sharing')/n
 if p.exists():shutil.copy2(p,E/'provenance'/('claude-ax-'+n))
shutil.copy2('/tmp/word-bound-simplify-20261028/build-records.json',E/'provenance/word-bound-build-records.json')
print('sources verified',len(list((E/'sources').rglob('*.lean'))))
