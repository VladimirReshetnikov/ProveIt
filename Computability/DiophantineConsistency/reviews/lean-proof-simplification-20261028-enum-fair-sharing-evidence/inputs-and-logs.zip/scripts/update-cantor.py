from pathlib import Path
import json,hashlib,shutil,subprocess
R=Path('/tmp/enum-fair-sharing');E=Path('/tmp/enum-fair-sharing-evidence');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();recs=json.loads((R/'refresh-cantor-records.json').read_text());assert len(recs)==4
for x in recs:
 assert x['status']==0 and x['git_head']=='34bb4f548343304698a6222682fc799c903afe9b';assert x['current_source_sha256_before']==x['current_source_sha256_after']==x['snapshot_sha256_before']==x['snapshot_sha256_after'];p=Path(x['compiled_snapshot']);assert sha(p)==x['snapshot_sha256_before'];dest=E/'sources'/('refresh-'+x['phase'])/p.name;shutil.copy2(p,dest)
 assert all(d['before']==d['after']==sha(d['path']) for d in x['direct_inputs'])
 for v in x['providers'].values():
  assert sha(v['source'])==v['source_sha256']==v['source_sha256_after'];assert sha(v['object'])==v['object_sha256']==v['object_sha256_after'];shutil.copy2(v['source'],E/'sources/providers'/Path(v['source']).name)
for folder in ['final-doc','final-doc2']:
 for p in (R/'sources'/folder/'DiophantineConsistency').glob('*.lean'):shutil.copy2(p,E/'sources'/folder/p.name)
for n in ['refresh-cantor-records.json','refresh-forward-probe-records.json','final-doc-records.json','final-doc-probe-records.json','final-doc2-records.json','final-doc2-probe-records.json']:
 shutil.copy2(R/n,E/'records'/n)
for n in ['refresh-cantor.py','refresh-forward-probes.py','build-final-doc.py','probe-final-doc.py','build-final-doc2.py','probe-final-doc2.py']:
 shutil.copy2(R/n,E/'scripts'/n)
for p in R.iterdir():
 if p.is_file() and p.name.startswith(('refresh-','final-doc-','final-doc2-')) and p.suffix in ['.log','.time']:shutil.copy2(p,E/'logs'/p.name)
shutil.copy2(R/'candidate-doc2.patch',E/'candidate-doc2.patch')
shutil.copy2('/tmp/cantor-bound-simplify/build-records.json',E/'provenance/cantor-build-records.json')
(E/'provenance/cantor-adopted-commit.txt').write_text(subprocess.check_output(['git','show','-s','--format=full','34bb4f548343304698a6222682fc799c903afe9b'],text=True))
(E/'history/prior-archive.sha256').write_text(sha('/tmp/enum-fair-sharing-evidence-before-cantor.zip')+'  enum-fair-sharing-evidence-before-cantor.zip\n')
print('updated evidence: 4 refreshed client builds, 2 doc revisions, pinned current providers')
