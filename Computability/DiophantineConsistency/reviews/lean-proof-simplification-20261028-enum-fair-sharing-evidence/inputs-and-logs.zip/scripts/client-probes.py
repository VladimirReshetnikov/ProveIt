from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/enum-fair-sharing');P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(phase,name,src):
 out=R/(phase+'-'+name+'.log');tm=R/(phase+'-'+name+'.time');env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=sha(src);dep=R/phase/'DiophantineConsistency/ArithmeticEnumSoundnessPerm222.olean';dh=sha(dep);t=time.monotonic()
 with out.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'name':name,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'input':str(src),'input_sha256_before':before,'input_sha256_after':sha(src),'direct_import':str(dep),'direct_import_sha256_before':dh,'direct_import_sha256_after':sha(dep),'log_sha256':sha(out),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(rec);(R/'client-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,r.returncode,rec['time'].strip(),flush=True);assert r.returncode==0 and before==rec['input_sha256_after'] and dh==rec['direct_import_sha256_after']
for phase in ['baseline','final']:
 run(phase,'client-names',R/'client-names.lean');run(phase,'client-checks',P/'ArithmeticEnumSoundnessPerm222Checks.lean')
read=lambda p:{x[5:] for x in (R/(p+'-client-names.log')).read_text().splitlines() if x.startswith('DECL ')}
a=read('baseline');b=read('final');print('names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),flush=True)
(R/'client-name-diff.json').write_text(json.dumps({'baseline_count':len(a),'final_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)},indent=2)+'\n')
common=sorted(a & b);(R/'client-interfaces.lean').write_text('import DiophantineConsistency.ArithmeticEnumSoundnessPerm222\nset_option pp.universes true\n'+''.join('#check '+x+'\n#print axioms '+x+'\n' for x in common))
for phase in ['baseline','final']:run(phase,'client-interfaces',R/'client-interfaces.lean')
print('client checks identical:',(R/'baseline-client-checks.log').read_bytes()==(R/'final-client-checks.log').read_bytes());print('client interface identical:',(R/'baseline-client-interfaces.log').read_bytes()==(R/'final-client-interfaces.log').read_bytes())
