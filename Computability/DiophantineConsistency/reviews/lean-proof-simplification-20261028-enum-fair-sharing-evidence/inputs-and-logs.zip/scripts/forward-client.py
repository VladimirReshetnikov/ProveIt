from pathlib import Path
import os,subprocess,time,hashlib,json,re,shutil
R=Path('/tmp/enum-fair-sharing');P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 n='ArithmeticEnumBoundSoundness';root=R/'sources'/phase;src=root/'DiophantineConsistency'/f'{n}.lean';shutil.copyfile(P/f'{n}.lean',src);env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;deps=[]
 for i in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  path=next((Path(d)/(i.replace('.','/')+'.olean') for d in env['LEAN_PATH'].split(':') if (Path(d)/(i.replace('.','/')+'.olean')).is_file()),None)
  if not path:raise RuntimeError(i)
  deps.append({'module':i,'path':str(path),'resolved':str(path.resolve()),'before':sha(path)})
 obj=R/phase/'DiophantineConsistency'/f'{n}.olean';obj.unlink(missing_ok=True);log=R/f'{phase}-{n}.log';tm=R/f'{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];h=sha(src);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['after']=sha(d['path'])
 z={'phase':phase,'module':n,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256_before':h,'source_sha256_after':sha(src),'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(z);(R/'forward-client-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,z['time'].strip(),flush=True)
 assert r.returncode==0 and h==z['source_sha256_after'] and all(d['before']==d['after'] for d in deps)
