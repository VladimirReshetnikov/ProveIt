import DiophantineConsistency.ArithmeticMaskConstants
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticMaskConstants).isPrefixOf n then
      logInfo m!"{n}"
