import pathlib,subprocess,json,os,hashlib,time
P=pathlib.Path('/tmp/mask-digits-bound');old=pathlib.Path('/tmp/shared-standard-casts-validation');lp=json.loads((old/'baseline-replay-environment-and-object-receipt.json').read_text())['lake_inherited_LEAN_PATH'];H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 root=P/phase;out=root/'DiophantineConsistency'
 for x in (old/'final').iterdir():
  if x.name!='DiophantineConsistency':
   q=root/x.name
   if not q.exists():q.symlink_to(x.resolve(),target_is_directory=x.is_dir())
 for x in (old/'final/DiophantineConsistency').iterdir():
  q=out/x.name
  if not q.exists() and not q.is_symlink():q.symlink_to(x.resolve())
 src=out/'ArithmeticMaskConstants.lean';obj=out/'ArithmeticMaskConstants.olean';obj.unlink(missing_ok=True);env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp;log=P/f'{phase}-target.log';tm=P/f'{phase}-target.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];before=H(src);t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 r={'phase':phase,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'source_sha256':before,'source_after':H(src),'log_sha256':H(log),'time_sha256':H(tm),'object_sha256':H(obj) if obj.exists() else None};records.append(r);(P/'paired-records.json').write_text(json.dumps(records,indent=2));print(phase,q.returncode,flush=True)
