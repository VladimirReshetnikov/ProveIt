import pathlib,json,hashlib,os,subprocess
P=pathlib.Path('/tmp/mask-digits-bound');prior=pathlib.Path('/tmp/construction-share/final');lp=json.loads((pathlib.Path('/tmp/shared-standard-casts-validation')/'baseline-replay-environment-and-object-receipt.json').read_text())['lake_inherited_LEAN_PATH'];H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 root=P/('client-'+phase);root.mkdir(exist_ok=True);out=root/'DiophantineConsistency';out.mkdir(exist_ok=True)
 for f in (prior/'DiophantineConsistency').iterdir():
  if f.name.startswith(('ArithmeticMaskConstants.','ArithmeticRankForcing2011.')):continue
  q=out/f.name
  if not q.exists():q.symlink_to(f.resolve(),target_is_directory=f.is_dir())
 for f in prior.iterdir():
  if f.name=='DiophantineConsistency':continue
  q=root/f.name
  if not q.exists():q.symlink_to(f.resolve(),target_is_directory=f.is_dir())
 (out/'ArithmeticMaskConstants.olean').symlink_to((P/phase/'DiophantineConsistency/ArithmeticMaskConstants.olean').resolve())
 src=pathlib.Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRankForcing2011.lean');obj=out/'ArithmeticRankForcing2011.olean';env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp;tm=P/f'client-{phase}.time';log=P/f'client-{phase}.log';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(obj)];before=H(src)
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':H(src),'log_sha256':H(log),'time_sha256':H(tm),'object_sha256':H(obj) if obj.exists() else None};records.append(rec);(P/'client-records.json').write_text(json.dumps(records,indent=2));print(phase,r.returncode,flush=True)
