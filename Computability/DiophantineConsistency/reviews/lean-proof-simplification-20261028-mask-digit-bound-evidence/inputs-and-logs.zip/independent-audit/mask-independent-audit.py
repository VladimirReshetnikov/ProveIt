import hashlib,json
from pathlib import Path
p=Path('/tmp/mask-digits-bound'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for name in ('paired-records.json','client-records.json'):
 for r in json.loads((p/name).read_text()):
  cmd=r['command'];src=[x for x in cmd if x.endswith('.lean')];assert len(src)==1
  assert r['status']==0 and r['source_sha256']==r['source_after']==h(src[0]); assert r['lean_path'].split(':')[0].endswith(('baseline','final'))
  assert h(cmd[4])==r['time_sha256'] and h(cmd[-1])==r['object_sha256']
  log=p/((r['phase']+'-target.log') if name.startswith('paired') else ('client-'+r['phase']+'.log'));assert h(log)==r['log_sha256']
 print(name,'two records validated')
for suffix in ('interface.log','names.log'):
 assert (p/('baseline-'+suffix)).read_bytes()==(p/('final-'+suffix)).read_bytes(); print(suffix,'identical')
print('Scope: paired targets/clients and namespace probes; package and transitive inputs precompiled.')
