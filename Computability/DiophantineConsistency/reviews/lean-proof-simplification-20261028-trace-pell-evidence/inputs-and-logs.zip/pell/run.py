from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/bootstrap-fixed-six-20261028');pre='Computability/DiophantineConsistency/Lean/';mode=sys.argv[1]
items=[('target',pre+'DiophantineConsistency/NativePellBootstrap.lean',True),('axioms',str(p/'axioms.lean'),False)]
if mode=='final':items += [('first-index',pre+'DiophantineConsistency/NativePellFirstIndex.lean',False),('first-carrier',pre+'DiophantineConsistency/FirstPellCarrier.lean',False),('focus',pre+'checks/NativePellBootstrap.lean',False)]
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free<65*1024*1024:print('stopped before',name,'free_bytes',free,flush=True);raise SystemExit(2)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency/NativePellBootstrap.olean')]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/bootstrap-fixed-six-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-t;log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 rec={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'free_before':free}
 if obj and r.returncode==0:
  f=p/'overlay/DiophantineConsistency/NativePellBootstrap.olean';rec['object']=str(f);rec['object_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n');print(mode,name,r.returncode,'seconds',round(elapsed,2),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
