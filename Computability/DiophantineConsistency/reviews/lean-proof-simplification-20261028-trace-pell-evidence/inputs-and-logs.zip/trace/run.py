from pathlib import Path
import subprocess,time,json,hashlib,sys
p=Path('/tmp/trace-cycle-proof-20261028');pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; mode=sys.argv[1]
items=[('target',pre+'WangTiles942TraceCycle.lean',True),('axioms',str(p/'axioms.lean'),False)]
if mode=='final':items += [('focus',pre+'WangTiles942TraceCycleChecks.lean',False),('marker',pre+'WangTiles942CycleMarker.lean',False),('boundary',pre+'WangTiles942CycleBoundary.lean',False)]
records=[]
for name,source,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency/WangTiles942TraceCycle.olean')]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/trace-cycle-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-start;log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 record={'name':name,'argv':cmd,'status':r.returncode,'seconds':elapsed,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  op=p/'overlay/DiophantineConsistency/WangTiles942TraceCycle.olean';record.update(object=str(op),object_sha256=hashlib.sha256(op.read_bytes()).hexdigest())
 records.append(record);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
