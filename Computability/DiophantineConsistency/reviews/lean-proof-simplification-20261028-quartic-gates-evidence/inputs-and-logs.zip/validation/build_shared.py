import os, pathlib, re, subprocess, json, hashlib, time, sys
P=pathlib.Path; root=P('/tmp/quartic-gates'); overlay=root/'shared'; base=P('.lake/build/lib/lean').resolve()
for ns in ('Diophantine','DiophantineConsistency'):
 for p in (base/ns).rglob('*.olean'):
  dest=overlay/p.relative_to(base);dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(p)
roots=[P('Computability/DiophantineConsistency/Lean'),P('Computability/HilbertTenthProblem/Lean')]; seen={}; order=[]
def source(m):
 return next(((r,r/(m.replace('.','/')+'.lean')) for r in roots if (r/(m.replace('.','/')+'.lean')).exists()),None)
def walk(m):
 if m in seen:return
 pair=source(m)
 if not pair:return
 r,p=pair; ds=re.findall(r'^import\s+([\w.]+)',p.read_text(),re.M);seen[m]={'source':str(p),'imports':ds,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 for d in ds:walk(d)
 order.append((m,r,p))
walk('DiophantineConsistency.QuarticCompiler'); (root/'graph-before.json').write_text(json.dumps(seen,indent=2))
env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','');records=[]
for m,r,p in order[:-1]:
 out=overlay/(m.replace('.','/')+'.olean');out.unlink(missing_ok=True); log=root/(m+'.log'); timing=root/(m+'.time');cmd=['/usr/bin/time','-v','-o',str(timing),'lean','-M6000','-j1','-DElab.async=false','-R',str(r),str(p),'-o',str(out)];start=time.monotonic()
 with log.open('wb') as f: proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'module':m,'status':proc.returncode,'elapsed':time.monotonic()-start,'source_sha256_after':hashlib.sha256(p.read_bytes()).hexdigest(),'log':str(log),'time':str(timing)}
 if out.exists():rec.update(object_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),object_bytes=out.stat().st_size)
 records.append(rec);(root/'shared-builds.json').write_text(json.dumps(records,indent=2));print(m,proc.returncode,round(rec['elapsed'],2),flush=True)
 if proc.returncode or rec['source_sha256_after']!=seen[m]['sha256']:sys.exit(1)
