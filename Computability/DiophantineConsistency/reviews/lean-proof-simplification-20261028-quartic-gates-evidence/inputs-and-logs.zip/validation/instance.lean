import DiophantineConsistency.QuarticCompiler
open DiophantineConsistency
variable {σ : Type*} (e : NatExpr σ)
#synth Fintype (QuarticCompiler.Gates.Wire e)
