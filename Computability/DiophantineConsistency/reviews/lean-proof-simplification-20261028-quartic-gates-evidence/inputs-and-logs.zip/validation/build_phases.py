import os,pathlib,re,subprocess,json,hashlib,time,sys
P=pathlib.Path;root=P('/tmp/quartic-gates');shared=root/'shared'; repo=P('Computability/DiophantineConsistency/Lean'); records=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def build(name,src,srcroot,out,phase,env):
 out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);pre=sha(src);log=root/(phase+'-'+name+'.log');tm=root/(phase+'-'+name+'.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(out)];start=time.monotonic()
 with log.open('wb') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'module':name,'status':proc.returncode,'seconds':time.monotonic()-start,'source_sha256':pre,'source_sha256_after':sha(src),'log':str(log),'time':str(tm)}
 if out.exists():rec.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
 records.append(rec);(root/'phase-builds.json').write_text(json.dumps(records,indent=2));print(phase,name,proc.returncode,round(rec['seconds'],2),flush=True)
 if proc.returncode or pre!=sha(src):sys.exit(1)
env=os.environ.copy();env['LEAN_PATH']=str(shared)+':'+env.get('LEAN_PATH','')
for n in ['NaturalExpressionSemiring','SyntaxCoefficients']:
 src=repo/'DiophantineConsistency'/(n+'.lean');build(n,src,repo,shared/'DiophantineConsistency'/(n+'.olean'),'shared-extra',env)
for phase in ['baseline','final']:
 overlay=root/phase
 for ns in ('Diophantine','DiophantineConsistency'):
  for p in (shared/ns).rglob('*.olean'):
   d=overlay/p.relative_to(shared);d.parent.mkdir(parents=True,exist_ok=True);d.symlink_to(p.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','');srcroot=root/(phase+'-src');src=srcroot/'DiophantineConsistency/QuarticCompiler.lean'
 build('QuarticCompiler',src,srcroot,overlay/'DiophantineConsistency/QuarticCompiler.olean',phase,env)
 for n in ['NaturalSimplifier','GatesSemiring','QuarticSyntax','ExpressionSize']:
  build(n,repo/'DiophantineConsistency'/(n+'.lean'),repo,overlay/'DiophantineConsistency'/(n+'.olean'),phase,env)
 cmd=['lean','-M6000','-j1','-DElab.async=false',str(root/'axioms.lean')];log=root/(phase+'-axioms.log');start=time.monotonic()
 with log.open('wb') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(phase,'axioms',proc.returncode,round(time.monotonic()-start,2),flush=True)
 if proc.returncode:sys.exit(1)
if (root/'baseline-axioms.log').read_bytes()!=(root/'final-axioms.log').read_bytes():print('axioms differ',flush=True);sys.exit(1)
