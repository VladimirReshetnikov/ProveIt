import json,pathlib,hashlib,os
P=pathlib.Path;d=P('/tmp/quartic-gates');sha=lambda p:hashlib.sha256(P(p).read_bytes()).hexdigest()
full=json.loads((d/'axioms-full-receipt.json').read_text()); lakepath=full[0]['lean_path'].split(':',1)[1];graph=json.loads((d/'graph-before.json').read_text());out=[]
for r in json.loads((d/'shared-builds.json').read_text()):
 n=r['module'];src=graph[n]['source'];srcroot='Computability/DiophantineConsistency/Lean' if n.startswith('DiophantineConsistency.') else 'Computability/HilbertTenthProblem/Lean';obj=str(d/'shared'/(n.replace('.','/')+'.olean'));tm=str(d/(n+'.time'));log=r['log'];cmd=['/usr/bin/time','-v','-o',tm,'lean','-M6000','-j1','-DElab.async=false','-R',srcroot,src,'-o',obj]
 out.append(dict(r,command=cmd,lean_path=str(d/'shared')+':'+lakepath,log_sha256=sha(log),time_sha256=sha(tm),source_sha256=graph[n]['sha256']))
for r in json.loads((d/'phase-builds.json').read_text()):
 phase=r['phase'];n=r['module'];overlay=d/('shared' if phase=='shared-extra' else phase);srcroot=d/(phase+'-src') if n=='QuarticCompiler' else P('Computability/DiophantineConsistency/Lean');src=srcroot/'DiophantineConsistency'/(n+'.lean');obj=overlay/'DiophantineConsistency'/(n+'.olean');tm=d/(phase+'-'+n+'.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(obj)]
 out.append(dict(r,command=cmd,lean_path=str(overlay)+':'+lakepath,log_sha256=sha(r['log']),time_sha256=sha(tm)))
(d/'reconstructed-build-receipt.json').write_text(json.dumps({'note':'Commands reconstructed verbatim from the recorded execution scripts; the Lake environment suffix is from the subsequent full-axiom run, not separately captured at build execution. Source/object/status/log data were recorded during execution.','cwd':os.getcwd(),'build_script_sha256':sha(d/'build_shared.py'),'phase_script_sha256':sha(d/'build_phases.py'),'runs':out},indent=2)+'\n')
print('Recorded',len(out),'build runs and hashes.')
