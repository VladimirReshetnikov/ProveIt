import os,pathlib,subprocess,json,hashlib,time,sys
P=pathlib.Path;root=P('/tmp/quartic-gates');rec=[];src=root/'axioms-full.lean'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','');cmd=['lean','-M6000','-j1','-DElab.async=false',str(src)];log=root/(phase+'-axioms-full.log');start=time.monotonic()
 with log.open('wb') as f: v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec.append({'phase':phase,'command':cmd,'cwd':os.getcwd(),'lean_path':env['LEAN_PATH'],'source_sha256':sha(src),'target_object_sha256':sha(root/phase/'DiophantineConsistency/QuarticCompiler.olean'),'log_sha256':sha(log),'status':v.returncode,'elapsed':time.monotonic()-start});print(phase,v.returncode,flush=True)
 (root/'axioms-full-receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
 if v.returncode:sys.exit(v.returncode)
if (root/'baseline-axioms-full.log').read_bytes()!=(root/'final-axioms-full.log').read_bytes():sys.exit('axioms differ')
print('matches',flush=True)
