from pathlib import Path
import os,subprocess,time,hashlib,json
b=Path('/tmp/fin-one-simplification');ov=b/'trace-deps';src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env['LEAN_PATH'];rec=[r for r in json.loads((b/'trace-dep-records-m6000.json').read_text()) if r['exit']==0]
for n in ['ArithmeticMachineGraph215','ArithmeticMachineStep215','ArithmeticMachineRun215','ArithmeticWangTable','ArithmeticWangPlane']:
 p=src/(n+'.lean');out=ov/'DiophantineConsistency'/(n+'.olean');
 if any(r['name']==n and r['exit']==0 for r in rec):continue
 log=b/('trace-dep-'+n+'.log');start=time.monotonic();cmd=['lean','-M10000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p),'-o',str(out)];r=subprocess.run(cmd,env=env,stdout=log.open('w'),stderr=subprocess.STDOUT);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec.append({'name':n,'command':cmd,'lean_path':env['LEAN_PATH'],'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'source_sha256':h(p),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log)});(b/'trace-dep-records.json').write_text(json.dumps(rec,indent=2));print(n,r.returncode,rec[-1]['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
