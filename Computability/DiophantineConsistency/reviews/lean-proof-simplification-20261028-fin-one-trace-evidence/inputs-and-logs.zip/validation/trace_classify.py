from pathlib import Path
import json
b=Path('/tmp/fin-one-simplification');d=json.loads((b/'trace-inventory.json').read_text());machine=Path('/tmp/zfc-arithmetic-machine-maintained-replay/verification.json');machine_txt=machine.read_text();kernel=Path('/tmp/kernel-eval-rewrite/shared-builds.json');k=json.loads(kernel.read_text());build=json.loads((b/'trace-dep-records.json').read_text());counts={}
for m,v in d.items():
 if v['matching_authenticated_receipts']:z={'category':'command-run manifest match','receipts':v['matching_authenticated_receipts']}
 elif not v['object']:z={'category':'pending target','receipts':[]}
 elif any(x['name']==m.split('.')[-1] and x['exit']==0 and x['source_sha256']==v['source_sha256'] and x['object_sha256']==v['object_sha256'] for x in build):z={'category':'fresh local build','receipts':[str(b/'trace-dep-records.json')]}
 elif any(x['module']==m and x['status']==0 and x['source_before']==v['source_sha256']==x['source_after'] and x['object_sha256']==v['object_sha256'] for x in k):z={'category':'kernel build receipt match','receipts':[str(kernel)]}
 elif v['source_sha256'] in machine_txt and v['object_sha256'] in machine_txt:z={'category':'machine receipt source and object match','receipts':[str(machine)]}
 else:z={'category':'unverified historical object','receipts':[]}
 v['provenance']=z;counts[z['category']]=counts.get(z['category'],0)+1
(b/'trace-classified.json').write_text(json.dumps(d,indent=2));print(counts);print('unverified:');print('\n'.join(k for k,v in d.items() if v['provenance']['category']=='unverified historical object'))
