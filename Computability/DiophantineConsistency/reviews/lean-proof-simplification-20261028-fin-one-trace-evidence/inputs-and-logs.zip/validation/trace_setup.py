from pathlib import Path
b=Path('/tmp/fin-one-simplification');dest=b/'trace-deps';src=Path('/tmp/arithmetic-command-runperm222-root-author-gf9iylxf/lib');dest.mkdir(exist_ok=True)
for n in ['Foundation','FirstOrder']:(dest/n).symlink_to(src/n,target_is_directory=True)
for ns in ['DiophantineConsistency','BusyBeaver/ZFC']:
 (dest/ns).mkdir(parents=True,exist_ok=True)
def add(src,dest):
 for f in src.iterdir():
  if f.is_file():
   p=dest/f.name
   if not p.exists() and not p.is_symlink():p.symlink_to(f.resolve())
add(Path('/tmp/shared-padding-shift/final/DiophantineConsistency'),dest/'DiophantineConsistency');add(src/'DiophantineConsistency',dest/'DiophantineConsistency')
add(Path('/tmp/zfc-arithmetic-machine-maintained-replay/history/row/templates/constructors/cantor/cache/BusyBeaver/ZFC'),dest/'BusyBeaver/ZFC');add(src/'BusyBeaver/ZFC',dest/'BusyBeaver/ZFC');add(Path('.lake/build/lib/lean/BusyBeaver/ZFC'),dest/'BusyBeaver/ZFC')
for f in ['ArithmeticMachineGraph215','ArithmeticMachineStep215','ArithmeticMachineRun215','ArithmeticWangTable','ArithmeticWangPlane']:
 p=dest/'DiophantineConsistency'/(f+'.olean')
 if p.is_symlink():p.unlink()
