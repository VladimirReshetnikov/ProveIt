from pathlib import Path
import os,subprocess,time,json,hashlib
b=Path('/tmp/fin-one-simplification');env=os.environ.copy();rec=[];n='ArithmeticRunTrace'
for phase in ['baseline','final']:
 d=b/n/phase;p=d/'source'/'DiophantineConsistency'/(n+'.lean');out=d/'lib'/'DiophantineConsistency'/(n+'.olean');log=d/'target.log';tm=d/'target.time';e=env.copy();e['LEAN_PATH']=str(d/'lib')+':'+env['LEAN_PATH'];cmd=['lean','-M10000','-j1','-DElab.async=false','-R',str(d/'source'),str(p),'-o',str(out)];t=time.monotonic();r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm)]+cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();rec.append({'target':n,'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'time':tm.read_text().strip(),'seconds':round(time.monotonic()-t,3),'source_sha256':h(p),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log)});(b/'trace-build-records.json').write_text(json.dumps(rec,indent=2));print(n,phase,r.returncode,rec[-1]['time'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
