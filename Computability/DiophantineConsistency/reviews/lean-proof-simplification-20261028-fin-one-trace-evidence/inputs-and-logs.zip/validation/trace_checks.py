from pathlib import Path
import os,subprocess,time,json,hashlib
b=Path('/tmp/fin-one-simplification');env=os.environ.copy();rec=[]
for phase in ['baseline','final']:
 d=b/'ArithmeticRunTrace'/phase;e=env.copy();e['LEAN_PATH']=str(d/'lib')+':'+env['LEAN_PATH']
 for name in ['axioms','client']:
  out=d/'lib'/'DiophantineConsistency'/'ArithmeticTilingTable.olean';src=(b/'ArithmeticRunTrace'/'Axioms.lean') if name=='axioms' else Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingTable.lean');log=d/('trace-'+name+'.log');cmd=['lean','-M10000','-j1','-DElab.async=false'];
  if name=='client':cmd+=['-R','Computability/DiophantineConsistency/Lean']
  cmd.append(str(src))
  if name=='client':cmd+=['-o',str(out)]
  t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();rec.append({'phase':phase,'name':name,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(src),'log_sha256':h(log),'object_sha256':h(out) if name=='client' and out.exists() else None});(b/'trace-check-records.json').write_text(json.dumps(rec,indent=2));print(phase,name,r.returncode,rec[-1]['seconds'],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
a=(b/'ArithmeticRunTrace'/'baseline'/'trace-axioms.log').read_bytes();c=(b/'ArithmeticRunTrace'/'final'/'trace-axioms.log').read_bytes();print('axioms identical',a==c,flush=True)
if a!=c:raise SystemExit(1)
