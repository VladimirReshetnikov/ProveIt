from pathlib import Path
import re,json,hashlib,os
b=Path('/tmp/fin-one-simplification');ov=b/os.environ.get('TRACE_OVERLAY','trace-deps'); roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('/home/codex/src/Proofs/lib/FormalizedFormalLogic-Foundation'),Path('Logic/FirstOrder/Lean')];known={}
for report in json.load(open(b/'pins.json')):
 for r in report['modules']:
  known.setdefault(r['module'],[]).append({'source':r['expected_source_sha256'],'objects':[o['expected_sha256'] for o in r['objects'] if o['path'].endswith('.olean')],'receipt':report['manifest']})
seen={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');src=next((r/(rel+'.lean') for r in roots if (r/(rel+'.lean')).exists()),None)
 if src is None:return
 raw=src.read_text();deps=re.findall(r'^(?:public\s+)?(?:meta\s+)?import\s+((?:DiophantineConsistency|BusyBeaver|Foundation|FirstOrder)(?:\.\w+)+)',raw,re.M);obj=ov/(rel+'.olean');obj= obj if obj.exists() else Path('.lake/build/lib/lean')/(rel+'.olean');ss=sha(src);oo=sha(obj) if obj.exists() else None;match=[x['receipt'] for x in known.get(n,[]) if x['source']==ss and oo in x['objects']];seen[n]={'source':str(src.resolve()),'source_sha256':ss,'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':oo,'matching_authenticated_receipts':match,'imports':deps}
 for d in deps:visit(d)
visit('DiophantineConsistency.ArithmeticRunTrace');(b/('trace-inventory-'+ov.name+'.json')).write_text(json.dumps(seen,indent=2)+'\n');un=[n for n,v in seen.items() if v['object'] and not v['matching_authenticated_receipts']];missing=[n for n,v in seen.items() if not v['object']];print('local modules',len(seen),'manifest-matched',len(seen)-len(un)-len(missing),'unmatched',len(un),'missing',len(missing));print('unmatched',un);print('missing',missing)
