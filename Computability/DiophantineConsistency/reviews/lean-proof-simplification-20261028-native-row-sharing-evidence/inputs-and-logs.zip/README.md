# Generated native row-proof sharing: v3 evidence

28 October 2026. The isolated v3 candidate keeps all 22 rowIdentity theorem
statements and generated support, coefficient, source and rewrite lines. A
private padding formula replaces generated per-coordinate padding facts; the
original finite-sum rewrites remain, followed by targeted norm_num, finite-cast
simp and ring. The generator drops its unused coordinate-list computation. No
imports, source data or named existing statements change. The generated Lean
file shrinks from 661 to 585 lines. A recorded generator replay and independent
regeneration both reproduce the candidate exactly from the two SHA-pinned JSON
inputs. Source, generator, inputs, patches and independent reviews are included. The baseline Lean and generator snapshots match parent
c7b00395db92ac26e8ef9b15309eb164515d7d60, and the final v3 snapshots match
commit 2f04c5dcb37ec176f9c141e0ee412baae5e0cfd9. `records/git-pin-records.json`
records the corresponding Git blob IDs and SHA-256 comparisons. That commit
was merged after the builds; workspace paths in historical reviews and receipts
may now refer to v3, so use these pinned baseline snapshots for comparison.

## Builds, checks and timings

A fresh SelectiveCertificate52 provider was built against a SelectiveQuadraticCoding
object with a matching prior source/object receipt. Baseline and v3 target builds
passed, and both NativeQuadraticPositions and NativeCoefficientBounds clients
passed against same-phase current-source target objects. The baseline client
receipts use the first baseline object, which is byte-identical to the repeated
baseline object. Both v3 client objects and paired logs are byte-identical to
their baseline counterparts. Build records contain commands, source and input
hashes before/after, output/log hashes, LEAN_PATH, timing and memory.
`records/v3-audit.json` summarizes nine checked provider, target, repeat and
client build records and 16 direct-input occurrences with no mismatch.

In the paired target repeat, baseline used 35.28 seconds and v3 36.94 seconds
of user CPU. A separate v3 run used 35.45 seconds; these few local measurements
are not a general performance guarantee. V1's shorter 453-line version used
45.33 and 45.17 seconds versus paired baseline 36.49 and 35.32; its additional
simp cost is why it was not selected. V2's 580-line target passed once in 29.99
seconds but explicitly unfolds Lean's internal Fin.induction.go and was not
selected. V1/v2 sources, generators, target logs and receipts remain historical.

The v3 target census has 122 baseline and 125 final names, no removals, and
three new private names: padded_formula, its proof auxiliary and
rowIdentity_0._simp_1. All 100 existing public type/axiom reports and all 22
original private row theorem type/axiom reports match. Four forced definition
equations match; global simp membership/flags (31,715) and instance/priority
entries (13,981) match as sets. The new private names are observable to tools
that inspect Lean environments. `independent/` contains the independent v1/v3
reviews and the separate v3 generator reproduction receipt/log.

## Failed and superseded probes

Exploratory three-row simp variants that failed retain their sources/logs and
must not be interpreted as validation. An initial private textual-name probe
failed because Lean's parser treated the numeric private-name segment as field
syntax; its failed source, log and receipt are retained with `-failed` names.
The original receipt source/log paths were subsequently reused for the corrected
metaprogram probe; the copies preserve the failed content. V2 and the slower
v1 are historical and not the selected v3.

## Provenance limits

The recorded provider, target and two direct client boundaries use the saved
source/object hashes, including a previously rebuilt SelectiveCoefficientBounds
provider. Some upstream objects, installed Mathlib and Lean are cached; no full
transitive source closure or all-downstream-client replay is claimed. Compiled
objects are omitted. Absolute temporary paths in the receipts and scripts require
the original environment, so this archive is not a standalone replay. The timing
samples are small, and the global probes do not enumerate every persistent Lean
environment extension. No repository files were modified by the prototype builds; the v3 refactor was subsequently committed and merged.

`manifest.sha256` covers all files except itself.
