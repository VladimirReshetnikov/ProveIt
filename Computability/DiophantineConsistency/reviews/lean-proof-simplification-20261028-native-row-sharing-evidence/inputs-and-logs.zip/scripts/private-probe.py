from pathlib import Path
import os,subprocess,hashlib,json
R=Path('/dev/shm/native-row-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();src=R/'private-interfaces.lean';records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;obj=R/phase/'DiophantineConsistency/NativeQuadraticParent.olean';bs=sha(src);bo=sha(obj);log=R/f'{phase}-private-interfaces.log';cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':r.returncode,'source':str(src),'source_before':bs,'source_after':sha(src),'object':str(obj),'object_before':bo,'object_after':sha(obj),'log':str(log),'log_sha256':sha(log)};records.append(rec);(R/'private-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,r.returncode,flush=True)
 if r.returncode or bs!=rec['source_after'] or bo!=rec['object_after']:raise SystemExit(1)
