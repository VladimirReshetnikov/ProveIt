from pathlib import Path
R=Path('/dev/shm/native-row-sharing');base=R/'common';up=Path('/dev/shm/shared-box-prototype/coherent-common/DiophantineConsistency');mods=['NativeQuadraticParent','NativeQuadraticPositions','NativeCoefficientBounds']
for phase in ['baseline','final']:
 out=R/phase;out.mkdir(exist_ok=True)
 for f in base.iterdir():
  if f.name=='DiophantineConsistency':
   d=out/f.name;d.mkdir(exist_ok=True)
   for g in f.iterdir():
    p=d/g.name
    if not p.exists():p.symlink_to(g)
  elif not (out/f.name).exists():(out/f.name).symlink_to(f)
 for n in ['SelectiveCarry','SelectiveCoefficientBounds']:
  p=out/'DiophantineConsistency'/f'{n}.olean';p.unlink(missing_ok=True);p.symlink_to(up/f'{n}.olean')
 for n in mods:(out/'DiophantineConsistency'/f'{n}.olean').unlink(missing_ok=True)
for root in ['baseline-source','Lean']:
 for n in ['NativeQuadraticPositions','NativeCoefficientBounds']:
  p=R/root/'DiophantineConsistency'/f'{n}.lean';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(Path(f'Computability/DiophantineConsistency/Lean/DiophantineConsistency/{n}.lean').read_bytes())
