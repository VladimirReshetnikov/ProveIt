import DiophantineConsistency.NativeQuadraticParent
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`_private.DiophantineConsistency.NativeQuadraticParent).isPrefixOf n &&
        (toString n).contains "rowIdentity_" then
      let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let ax ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {ty} AXIOMS {ax}"
