from pathlib import Path
import hashlib,json,re
R=Path('/dev/shm/native-row-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bad=[];count=0;depcount=0
for f in ['common-records.json','baseline-records.json','v3-records.json','v3-repeat-baseline-records.json','v3-repeat-final-records.json','v3-final-records.json']:
 for x in json.loads((R/f).read_text()):
  count+=1;src=Path(x['source']);obj=Path(x['object']);log=Path(x['log']);phase=x.get('phase','provider')
  if x['status']!=0 or not src.exists() or sha(src)!=x['after'] or x['before']!=x['after']:bad.append((f,phase,x['module'],'source/status'))
  if not obj.exists() or sha(obj)!=x['object_sha256']:bad.append((f,phase,x['module'],'object'))
  if not log.exists() or sha(log)!=x['log_sha256']:bad.append((f,phase,x['module'],'log'))
  imports=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M)
  if sorted(imports)!=sorted(d['module'] for d in x['direct_inputs']):bad.append((f,phase,x['module'],'imports'))
  for d in x['direct_inputs']:
   depcount+=1;p=Path(d['resolved']);q=Path(d['path'])
   if not p.exists() or not q.exists() or d['before']!=d['after'] or sha(p)!=d['after'] or q.resolve()!=p:bad.append((f,phase,x['module'],d['module']))
for f in ['v3-probe-records.json','v3-private-probe-records.json']:
 for x in json.loads((R/f).read_text()):
  if x['status'] or sha(x['source'])!=x['source_after'] or x['source_before']!=x['source_after'] or sha(x['log'])!=x['log_sha256']:bad.append((f,x['phase'],'probe'))
g=json.loads((R/'v3/generator-record.json').read_text())
if g['status'] or g['before']!=g['after'] or any(sha(p)!=h for p,h in g['after'].items()) or sha(g['log'])!=g['log_sha256']:bad.append(('generator','source/data'))
d=json.loads((R/'v3/data-audit.json').read_text())
if not d['statement_and_data_exact'] or not d['outside_ignoring_whitespace']:bad.append(('data','differences'))
print('build records',count,'direct input occurrences',depcount,'bad',bad)
(R/'v3-audit.json').write_text(json.dumps({'build_records':count,'direct_input_occurrences':depcount,'bad':bad},indent=2)+'\n')
if bad:raise SystemExit(1)
