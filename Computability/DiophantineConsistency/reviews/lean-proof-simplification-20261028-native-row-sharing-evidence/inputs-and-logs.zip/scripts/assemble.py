from pathlib import Path
import tempfile,shutil,hashlib,difflib,zipfile
R=Path('/dev/shm/native-row-sharing');W=Path.cwd()/'Computability/DiophantineConsistency';Z=Path('/tmp/native-row-sharing-evidence-20261028-v2.zip')
if Z.exists():raise SystemExit('archive exists')
stage=Path(tempfile.mkdtemp(prefix='native-row-evidence-'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(src,dst):
 src=Path(src);p=stage/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
def txt(dst,s):
 p=stage/dst;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
for pat,sub in [('*.log','logs'),('*.time','logs'),('*.json','records'),('*.py','scripts'),('*.lean','scripts')]:
 for p in R.glob(pat):put(p,f'{sub}/{p.name}')
for phase,root in [('baseline',R/'baseline-source'),('v1',R/'Lean'),('v2',R/'v2/Lean'),('v3',R/'v3/Lean')]:put(root/'DiophantineConsistency/NativeQuadraticParent.lean',f'sources/{phase}/NativeQuadraticParent.lean')
for n in ['NativeQuadraticPositions','NativeCoefficientBounds']:
 put(R/'baseline-source/DiophantineConsistency'/f'{n}.lean',f'sources/clients/{n}.lean')
for phase,p in [('baseline',R/'git-baseline-generator.py'),('v1',R/'scripts/generate_native_quadratic_parent.py'),('v2',R/'v2/scripts/generate_native_quadratic_parent.py'),('v3',R/'v3/scripts/generate_native_quadratic_parent.py')]:put(p,f'generators/{phase}/generate_native_quadratic_parent.py')
for n in ['generator-record.json','data-audit.json','generator-replay.log','generator-check.py']:put(R/'v3'/n,('logs/' if n.endswith('.log') else 'scripts/' if n.endswith('.py') else 'records/')+'v3-'+n)
put(W/'data/native-quadratic52/source_system60.json','data/source_system60.json');put(W/'con-zfc-diophantine-forms/52-sparse-pell/packing/CERTIFICATE_174_interior_regular.json','data/CERTIFICATE_174_interior_regular.json')
put(W/'Lean/DiophantineConsistency/SelectiveCertificate52.lean','sources/provider/SelectiveCertificate52.lean');put(W/'Lean/DiophantineConsistency/SelectiveQuadraticCoding.lean','sources/provider/SelectiveQuadraticCoding.lean');put('/tmp/list-getd-sharing-20261028/fresh-records.json','provenance/fresh-records.json');put('/tmp/list-getd-sharing-20261028/fresh-SelectiveQuadraticCoding.log','provenance/fresh-SelectiveQuadraticCoding.log')
B=Path('/dev/shm/shared-box-prototype');put(B/'common-records.json','provenance/shared-box-common-records.json')
for n in ['SelectiveCarry','SelectiveCoefficientBounds']:
 put(W/'Lean/DiophantineConsistency'/f'{n}.lean',f'sources/provider/{n}.lean')
 for ext in ['log','time']:put(B/f'common-{n}.{ext}',f'provenance/common-{n}.{ext}')
for n in ['native-row-independent-review.txt','native-row-v3-independent-review.txt']:put('/tmp/'+n,'independent/'+n)
put('/tmp/native-row-v3-review/generator-record.json','independent/generator-record.json');put('/tmp/native-row-v3-review/generator.log','independent/generator.log')
patch=[]
for folder,n in [('sources','NativeQuadraticParent.lean'),('generators','generate_native_quadratic_parent.py')]:
 a=(stage/folder/'baseline'/n).read_text().splitlines(keepends=True);b=(stage/folder/'v3'/n).read_text().splitlines(keepends=True);patch.extend(difflib.unified_diff(a,b,fromfile=f'{folder}/baseline/{n}',tofile=f'{folder}/v3/{n}'))
txt('v3.patch',''.join(patch))
txt('README.md','''# Generated native row-proof sharing: v3 evidence

28 October 2026. The isolated v3 candidate keeps all 22 rowIdentity theorem
statements and generated support, coefficient, source and rewrite lines. A
private padding formula replaces generated per-coordinate padding facts; the
original finite-sum rewrites remain, followed by targeted norm_num, finite-cast
simp and ring. The generator drops its unused coordinate-list computation. No
imports, source data or named existing statements change. The generated Lean
file shrinks from 661 to 585 lines. A recorded generator replay and independent
regeneration both reproduce the candidate exactly from the two SHA-pinned JSON
inputs. Source, generator, inputs, patches and independent reviews are included. The baseline Lean and generator snapshots match parent
c7b00395db92ac26e8ef9b15309eb164515d7d60, and the final v3 snapshots match
commit 2f04c5dcb37ec176f9c141e0ee412baae5e0cfd9. `records/git-pin-records.json`
records the corresponding Git blob IDs and SHA-256 comparisons. That commit
was merged after the builds; workspace paths in historical reviews and receipts
may now refer to v3, so use these pinned baseline snapshots for comparison.

## Builds, checks and timings

A fresh SelectiveCertificate52 provider was built against a SelectiveQuadraticCoding
object with a matching prior source/object receipt. Baseline and v3 target builds
passed, and both NativeQuadraticPositions and NativeCoefficientBounds clients
passed against same-phase current-source target objects. The baseline client
receipts use the first baseline object, which is byte-identical to the repeated
baseline object. Both v3 client objects and paired logs are byte-identical to
their baseline counterparts. Build records contain commands, source and input
hashes before/after, output/log hashes, LEAN_PATH, timing and memory.
`records/v3-audit.json` summarizes nine checked provider, target, repeat and
client build records and 16 direct-input occurrences with no mismatch.

In the paired target repeat, baseline used 35.28 seconds and v3 36.94 seconds
of user CPU. A separate v3 run used 35.45 seconds; these few local measurements
are not a general performance guarantee. V1's shorter 453-line version used
45.33 and 45.17 seconds versus paired baseline 36.49 and 35.32; its additional
simp cost is why it was not selected. V2's 580-line target passed once in 29.99
seconds but explicitly unfolds Lean's internal Fin.induction.go and was not
selected. V1/v2 sources, generators, target logs and receipts remain historical.

The v3 target census has 122 baseline and 125 final names, no removals, and
three new private names: padded_formula, its proof auxiliary and
rowIdentity_0._simp_1. All 100 existing public type/axiom reports and all 22
original private row theorem type/axiom reports match. Four forced definition
equations match; global simp membership/flags (31,715) and instance/priority
entries (13,981) match as sets. The new private names are observable to tools
that inspect Lean environments. `independent/` contains the independent v1/v3
reviews and the separate v3 generator reproduction receipt/log.

## Failed and superseded probes

Exploratory three-row simp variants that failed retain their sources/logs and
must not be interpreted as validation. An initial private textual-name probe
failed because Lean's parser treated the numeric private-name segment as field
syntax; its failed source, log and receipt are retained with `-failed` names.
The original receipt source/log paths were subsequently reused for the corrected
metaprogram probe; the copies preserve the failed content. V2 and the slower
v1 are historical and not the selected v3.

## Provenance limits

The recorded provider, target and two direct client boundaries use the saved
source/object hashes, including a previously rebuilt SelectiveCoefficientBounds
provider. Some upstream objects, installed Mathlib and Lean are cached; no full
transitive source closure or all-downstream-client replay is claimed. Compiled
objects are omitted. Absolute temporary paths in the receipts and scripts require
the original environment, so this archive is not a standalone replay. The timing
samples are small, and the global probes do not enumerate every persistent Lean
environment extension. No repository files were modified by the prototype builds; the v3 refactor was subsequently committed and merged.

`manifest.sha256` covers all files except itself.
''')
txt('manifest.sha256',''.join(f'{sha(p)}  {p.relative_to(stage).as_posix()}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(stage).as_posix())
print('stage',stage,'archive',Z,'files',sum(1 for p in stage.rglob('*') if p.is_file()),'sha256',sha(Z))
