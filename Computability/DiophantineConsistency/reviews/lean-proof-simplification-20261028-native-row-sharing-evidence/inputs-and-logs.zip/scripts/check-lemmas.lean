import Mathlib.Tactic
#check Nat.cast_ofNat
#check Nat.cast_ofNat
#check Nat.cast_ofNat
