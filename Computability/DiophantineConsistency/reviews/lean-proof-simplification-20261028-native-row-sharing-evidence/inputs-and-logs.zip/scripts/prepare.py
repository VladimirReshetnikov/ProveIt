from pathlib import Path
R=Path('/dev/shm/native-row-sharing');base=Path('/tmp/word-origin-sharing/final');out=R/'common';out.mkdir(exist_ok=True)
for f in base.iterdir():
 if f.name=='DiophantineConsistency':
  d=out/f.name;d.mkdir(exist_ok=True)
  for g in f.iterdir():
   p=d/g.name
   if not p.exists():p.symlink_to(g)
 elif not (out/f.name).exists():(out/f.name).symlink_to(f)
(out/'DiophantineConsistency/SelectiveCertificate52.olean').unlink(missing_ok=True)
q=R/'baseline-source/DiophantineConsistency';q.mkdir(parents=True,exist_ok=True);(q/'NativeQuadraticParent.lean').write_bytes(Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/NativeQuadraticParent.lean').read_bytes())
