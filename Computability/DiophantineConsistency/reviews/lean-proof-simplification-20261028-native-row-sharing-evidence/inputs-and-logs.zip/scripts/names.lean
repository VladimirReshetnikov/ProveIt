import DiophantineConsistency.NativeQuadraticParent
#print equations DiophantineConsistency.NativeQuadraticParent.rowOrder
#print equations DiophantineConsistency.NativeQuadraticParent.padded
#print equations DiophantineConsistency.NativeQuadraticParent.rowSupport
#print equations DiophantineConsistency.NativeQuadraticParent.rowCoefficient
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.NativeQuadraticParent).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.NativeQuadraticParent" then
   logInfo m!"DECL {n}"
