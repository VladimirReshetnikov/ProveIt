from pathlib import Path
import os,hashlib,json,subprocess
p=Path('/dev/shm/native-row-sharing/v3-repeat-final');s=Path('/tmp/native-row-helper-probe.lean');o=p/'DiophantineConsistency/NativeQuadraticParent.olean';log=Path('/tmp/native-row-helper-probe.log');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=os.environ.copy();env['LEAN_PATH']=str(p)+':'+env['LEAN_PATH'];b=h(s);ob=h(o);cmd=['lean','-M10000','-j1','-DElab.async=false',str(s)]
with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
x={'status':r.returncode,'source':str(s),'source_before':b,'source_after':h(s),'object':str(o),'object_before':ob,'object_after':h(o),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'log':str(log),'log_sha256':h(log)};Path('/tmp/native-row-helper-probe.json').write_text(json.dumps(x,indent=2)+'\n');print(r.returncode)
