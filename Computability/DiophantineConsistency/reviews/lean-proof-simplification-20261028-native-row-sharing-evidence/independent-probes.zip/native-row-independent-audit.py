from pathlib import Path
import json,hashlib
R=Path('/dev/shm/native-row-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();filenames=['common-records.json','baseline-records.json','v3-records.json','v3-repeat-baseline-records.json','v3-repeat-final-records.json','v3-final-records.json'];allrows=[]
for f in filenames:
 for x in json.loads((R/f).read_text()):
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']);tm=Path(x['command'][x['command'].index('-o')+1]);assert x['time']==tm.read_text()
  for d in x['direct_inputs']:
   first=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==h(first)
  allrows.append(x);print(f,x['module'],len(x['direct_inputs']),'inputs verified')
for x in json.loads((R/'v3-probe-records.json').read_text()):
 obj=R/('v3-repeat-'+x['phase'])/'DiophantineConsistency/NativeQuadraticParent.olean';assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(obj)] and x['log_sha256']==h(x['log']);print('probe',x['phase'],x['probe'],'verified')
for x in json.loads((R/'v3-private-probe-records.json').read_text()):
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log']);print('private probe',x['phase'],'verified')
for f in ['v3-interfaces','simp','instances']:assert (R/f'v3-baseline-{f}.log').read_bytes()==(R/f'v3-final-{f}.log').read_bytes();print(f,'equal')
print('build count',len(allrows))
