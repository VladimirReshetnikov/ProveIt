from pathlib import Path
import re,hashlib,json
old=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/NativeQuadraticParent.lean').read_text();new=Path('/dev/shm/native-row-sharing/v3/Lean/DiophantineConsistency/NativeQuadraticParent.lean').read_text()
new,n=re.subn(r'/-- Resolve a padded coordinate uniformly, including the constant coordinate\. -/\nprivate theorem padded_formula .*?\n  fin_cases i <;> rfl\n\n','',new,flags=re.S);assert n==1
old,n1=re.subn(r'(?:  have hp\d+ : padded x \d+ = .*? := rfl\n)+  norm_num \[hp[^\n]*\]\n','  REPLACED_PADDED_PROOF\n',old)
new,n2=re.subn(r'  norm_num \[padded_formula\]\n  all_goals simp only \[← Fin\.natCast_eq_mk, Nat\.cast_ofNat\]\n','  REPLACED_PADDED_PROOF\n',new)
assert n1==n2==22;assert old==new
print('All 22 row bodies differ only by the padded proof replacement, plus one private helper; all remaining source bytes identical.')
