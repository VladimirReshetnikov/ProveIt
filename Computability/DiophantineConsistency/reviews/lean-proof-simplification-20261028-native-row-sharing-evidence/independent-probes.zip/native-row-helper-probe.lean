import DiophantineConsistency.NativeQuadraticParent
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`_private.DiophantineConsistency.NativeQuadraticParent).isPrefixOf n &&
       ((toString n).contains "padded_formula" || (toString n).contains "rowIdentity_0._simp_1") then
      let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let ax ← Lean.collectAxioms n
      logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
