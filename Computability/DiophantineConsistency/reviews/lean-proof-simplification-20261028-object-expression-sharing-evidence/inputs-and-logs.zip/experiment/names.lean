import Lean.Elab.Command
import DiophantineConsistency.ObjectNaturalExpression
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ObjectNaturalExpression).isPrefixOf n then
      logInfo m!"{n}"
