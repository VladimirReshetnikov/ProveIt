import pathlib,json,os,hashlib,subprocess
P=pathlib.Path('/tmp/object-expression-sharing');W=pathlib.Path('.lake/build/lib/lean/DiophantineConsistency');r=json.loads(pathlib.Path('/tmp/shared-standard-casts-validation/baseline-replay-environment-and-object-receipt.json').read_text());lp=r['lake_inherited_LEAN_PATH'];h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();rec=[]
for phase in ['baseline','final']:
 root=P/phase;d=root/'DiophantineConsistency'
 for f in W.iterdir():
  if f.name.startswith(('ObjectNaturalExpression.','ObjectPolynomial.')):continue
  q=d/f.name
  if not q.exists() and not q.is_symlink():q.symlink_to(f.resolve(),target_is_directory=f.is_dir())
 env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp
 for tag,src,srcroot,out in [('target',d/'ObjectNaturalExpression.lean',root,d/'ObjectNaturalExpression.olean'),('client',pathlib.Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ObjectPolynomial.lean'),'Computability/DiophantineConsistency/Lean',d/'ObjectPolynomial.olean')]:
  out.unlink(missing_ok=True);log=P/f'{phase}-{tag}.log';tm=P/f'{phase}-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(out)];before=h(src)
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  z={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'object_sha256':h(out) if out.exists() else None};rec.append(z);(P/'records.json').write_text(json.dumps(rec,indent=2));print(phase,tag,q.returncode,flush=True)
  if q.returncode:raise SystemExit(q.returncode)
