from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/head-bounds-proof-20261028');pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';mode=sys.argv[1]
if mode=='prep': items=[(n,pre+n+'.lean',n) for n in ['WangMachineEncoding','WangMachineAction','WangMachineStep','WangTiles942RowEncoding','WangTiles942OperatingRow']]
elif mode=='baseline': items=[('target',pre+'WangTiles942HeadBounds.lean','WangTiles942HeadBounds'),('axioms',str(p/'axioms.lean'),None)]
elif mode=='final': items=[('target',pre+'WangTiles942HeadBounds.lean','WangTiles942HeadBounds'),('axioms',str(p/'axioms.lean'),None),('focus',pre+'WangTiles942HeadBoundsChecks.lean',None),('client',pre+'WangTiles942RowStep.lean',None)]
else:raise ValueError(mode)
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free < 65*1024*1024: raise SystemExit('disk cutoff: '+str(free))
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency'/(obj+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/head-bounds-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-start
 log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr); h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
 row={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'free_before':free,'source':source,'source_sha256':h(source),'log':str(log),'log_sha256':h(log)}
 if obj and r.returncode==0:
  o=p/'overlay/DiophantineConsistency'/(obj+'.olean');row['object']=str(o);row['object_sha256']=h(o)
 records.append(row);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
