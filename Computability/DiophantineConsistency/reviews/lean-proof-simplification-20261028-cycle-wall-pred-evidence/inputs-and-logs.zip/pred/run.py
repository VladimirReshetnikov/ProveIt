from pathlib import Path
import hashlib,json,subprocess,sys,time,shutil
p=Path('/tmp/physical-fin-pred-20261028');pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';mode=sys.argv[1]
if mode=='baseline': tasks=[('prep-Permutation',pre+'WangTiles942Permutation.lean','WangTiles942Permutation'),('prep-PhysicalData',pre+'WangTiles942PhysicalData.lean','WangTiles942PhysicalData'),('target',pre+'WangTiles942PhysicalOrder.lean','WangTiles942PhysicalOrder'),('axioms',str(p/'axioms.lean'),None),('compat',str(p/'compatibility.lean'),None)]
else: tasks=[('target',pre+'WangTiles942PhysicalOrder.lean','WangTiles942PhysicalOrder'),('axioms',str(p/'axioms.lean'),None),('compat',str(p/'compatibility.lean'),None),('focus',pre+'WangTiles942PhysicalOrderChecks.lean',None),('client',pre+'CurrentKernelResidues2011.lean',None)]
records=[]
for name,source,obj in tasks:
 free=shutil.disk_usage('.').free
 if free<65*1024*1024: print('DISK GUARD',name,free,flush=True);sys.exit(75)
 args=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj: args+=['-o',str(p/'overlay/DiophantineConsistency'/(obj+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/physical-fin-pred-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*args];t=time.monotonic();r=subprocess.run(cmd,capture_output=True);duration=time.monotonic()-t
 log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr);record={'name':name,'argv':cmd,'status':r.returncode,'elapsed':duration,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  o=p/'overlay/DiophantineConsistency'/(obj+'.olean');record.update({'object':str(o),'object_sha256':hashlib.sha256(o.read_bytes()).hexdigest(),'object_bytes':o.stat().st_size})
 records.append(record);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n');print(mode,name,'status',r.returncode,'seconds',round(duration,1),flush=True)
 if r.returncode:sys.exit(r.returncode)
