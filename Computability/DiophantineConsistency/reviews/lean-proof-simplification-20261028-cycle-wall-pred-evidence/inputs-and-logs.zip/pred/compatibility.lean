import DiophantineConsistency.WangTiles942PhysicalOrder
namespace DiophantineConsistency.WangTiles942PhysicalOrder
open WangTiles942 WangTiles942PhysicalData
def oldNonStartIndex (j : Fin 941) : Fin 941 :=
  ⟨(abstractIndex j).val-1, by
    have := (abstractIndex j).isLt
    have := abstractIndex_ne_zero j
    have hp : 0 < (abstractIndex j).val := Fin.pos_iff_ne_zero.mpr this
    omega⟩

example (j : Fin 941) : oldNonStartIndex j = nonStartIndex j := rfl
end DiophantineConsistency.WangTiles942PhysicalOrder
