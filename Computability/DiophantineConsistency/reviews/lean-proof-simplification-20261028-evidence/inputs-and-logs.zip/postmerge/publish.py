from pathlib import Path
import hashlib,json,zipfile,shutil,re
ROOT=Path('/tmp/diophantine-oct28-refresh')
state=json.loads((ROOT/'execution.json').read_text())
manifest=json.loads((ROOT/'manifest.json').read_text())
setup=json.loads((ROOT/'setup.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def validate_record(r):
    p=Path(r['path']);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],str(p)
assert state['complete'] and len(state['records'])==11
assert state['old_public_reports']==91 and state['old_public_report_sets_identical']
assert state['source_and_reuse_guards_before'] and state['source_and_reuse_guards_after']
validate_record(manifest['driver'])
for p,h in manifest['protected'].items():assert sha(p)==h,p
for r in manifest['reused_objects']:assert sha(r['object'])==r['sha256']
for plan,r in zip(manifest['steps'],state['records'],strict=True):
    assert r['actual_exit_status']==0 and plan['tag']==r['tag']
    for key in ['source','object','log','timing']:
        if key in r:validate_record(r[key])
    assert re.search(r'exit_status=0\b',Path(r['timing']['path']).read_text())
validate_record(manifest['expected_public_report'])
out=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261028-evidence')
out.mkdir(exist_ok=False)
for name in ['manifest.json','execution.json','premerge-axiom-comparison.json']:
    shutil.copyfile(ROOT/name,out/name)
shutil.copyfile(ROOT/'refresh.py',out/'driver.txt')
shutil.copyfile(ROOT/'driver.log',out/'driver-output.txt')
shutil.copyfile('/tmp/diophantine-oct28-source-integrity.json',out/'source-integrity.json')
records={}
def add(p,name):
    p=Path(p);assert p.is_file() and name not in records
    records[name]=p
for base,label in [(Path('/tmp/free-ratio-cleanup-20261028'),'ratio'),(Path('/tmp/expression-size-cleanup-20261028'),'size'),(Path('/tmp/pell-norm-cleanup-20261028'),'Pell'),(ROOT,'postmerge')]:
    for p in sorted(base.iterdir()):
        if p.is_file() and p.suffix in {'.lean','.log','.time','.json','.py'}:
            add(p,label+'/'+p.name)
for name in ['diophantine-oct28-validated-protected.json','diophantine-oct28-merged-protected.json','diophantine-oct28-source-integrity.json','diophantine-oct28-integrity.py','diophantine-oct28-evicted-lake-setup-metadata.json']:
    add(Path('/tmp')/name,'integrity/'+name)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(records.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(records)
    for name,p in records.items():assert z.read(name)==p.read_bytes()
summary={'base_commit':'8e13da9d92cf9f4f4aa004d80f34c98fd26ba093','checked_source_commits':['52cd979b04205648798cef4f7e1d47eabef76e38','4f571a7890','c87e01807b2f11dd4afb1bc07d9272f7697adb8f'],'merged_commit':manifest['merged_HEAD'],'merged_upstream':manifest['upstream'],'source_modules':4,'old_lines':910,'new_lines':880,'net_lines_removed':30,'bytes_removed':1152,'reviewed_series_lines_removed':4155,'premerge_accepted_calls':19,'postmerge_refresh_calls':11,'postmerge_fresh_project_sources':10,'old_public_reports_identical':91,'new_axioms_or_assumptions':0,'unchanged_old_theorem_headers':37,'unchanged_whole_definitions':20,'protected_source_configuration_equation_pins':len(manifest['protected']),'project_sources':len(manifest['project_edges']),'selected_roots':len(manifest['roots']),'reused_primary_project_objects':len(manifest['reused_objects']),'earlier_focus_only_roots':len(manifest['focus_only_roots']),'postmerge_stdout_byte_identical':state['old_public_report_stdout_byte_identical'],'postmerge_elapsed_observation_seconds':state['elapsed_monotonic_seconds'],'warnings':[line for r in state['records'] for line in Path(r['log']['path']).read_text().splitlines() if 'warning:' in line]}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir()) if p.is_file()}
members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(records.items())}
bundle={'summary':summary,'files':files,'archive_members':members,'validation_limits':'Nineteen accepted-source calls and eleven separately counted postmerge refresh calls. Original preparation/baselines and every rejected/failed size candidate are preserved separately, not promoted to accepted final checks. 201 project primary objects and installed packages/toolchain are precompiled reuse; four focus-only roots retain earlier successful checks. New upstream proofs outside the selected closure are not replayed or independently endorsed by this bundle.','provenance':'Only ROOT/assigned-author validation drivers were executed after source inspection; archived proposal/diagnostic files are inert evidence. All archived bytes checked against retained files. Cleanup evicted only regenerable Lake setup metadata, not source or primary objects.'}
(out/'BUNDLE.json').write_text(json.dumps(bundle,indent=2)+'\n')
print(json.dumps({'destination':str(out),'archive_members':len(records),'summary':summary,'files':files},indent=2))
