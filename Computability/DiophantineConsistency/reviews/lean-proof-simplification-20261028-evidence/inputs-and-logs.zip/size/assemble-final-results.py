from pathlib import Path
import hashlib,json,re,subprocess
OUT=Path('/tmp/expression-size-cleanup-20261028')
TARGET=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ExpressionSize.lean')
PRODUCTION='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
baseline=json.loads((OUT/'baseline.json').read_text())
old=(OUT/'original.lean').read_text()
new=TARGET.read_text()
def record(path):
    path=Path(path)
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
marker='    QuarticCompiler.Gates.count e.splitNatural.2 = (splitSize e).negative := by\n'
end='\n@[simp] theorem splitSize_rename'
a,b=old.split(marker)
c,d=new.split(marker)
oldproof,oldsuffix=b.split(end,1)
newproof,newsuffix=d.split(end,1)
assert a==c and oldsuffix==newsuffix
assert newproof=='  induction e <;>\n    simp_all only [Expr.splitNatural, QuarticCompiler.Gates.count, splitSize, SplitSize.leaf,\n      SplitSize.add, SplitSize.sub, SplitSize.mul, and_self] <;> constructor <;> omega\n'
assert old.encode()==subprocess.check_output(['git','show',baseline['base']+':'+str(TARGET)])
# Historical inputs at the same production path are bound to preserved snapshots.
specs=[
('original-target','original-source-build',TARGET,OUT/'original.lean',True,0),
('baseline-axioms','fresh-original-axiom-audit',OUT/'public-axioms.lean',OUT/'public-axioms.lean',False,0),
('final-target','first-axiom-rejected-candidate',TARGET,OUT/'first-candidate.lean',True,0),
('client-BoundedForallSize','first-axiom-rejected-candidate',Path(PRODUCTION+'BoundedForallSize.lean'),Path(PRODUCTION+'BoundedForallSize.lean'),True,0),
('client-GraphSizeBounds','first-axiom-rejected-candidate',Path(PRODUCTION+'GraphSizeBounds.lean'),Path(PRODUCTION+'GraphSizeBounds.lean'),True,0),
('client-BoundedForallDepth','first-axiom-rejected-candidate',Path(PRODUCTION+'BoundedForallDepth.lean'),Path(PRODUCTION+'BoundedForallDepth.lean'),True,0),
('focus-BoundedForallDepth','first-axiom-rejected-candidate',Path('Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean'),Path('Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean'),False,0),
('final-axioms','first-axiom-rejected-candidate',OUT/'public-axioms.lean',OUT/'public-axioms.lean',False,0),
('only-target','failed-production-candidate',TARGET,OUT/'only-candidate.lean',True,1),
('only-constructor-target','failed-production-candidate',TARGET,OUT/'only-constructor-candidate.lean',True,1),
('repaired-target','failed-production-candidate',TARGET,OUT/'repaired-candidate.lean',True,1),
('trace-goals','failed-diagnostic-copy',OUT/'trace-goals.lean',OUT/'trace-goals.lean',False,1),
('accepted-target','second-axiom-rejected-candidate',TARGET,OUT/'restricted-and-self-candidate.lean',True,0),
('accepted-axioms','second-axiom-rejected-candidate',OUT/'public-axioms.lean',OUT/'public-axioms.lean',False,0),
('split-conjunction-target','accepted-final',TARGET,TARGET,True,0),
('split-conjunction-axioms','accepted-final',OUT/'public-axioms.lean',OUT/'public-axioms.lean',False,0),
('accepted-BoundedForallSize','accepted-final',Path(PRODUCTION+'BoundedForallSize.lean'),Path(PRODUCTION+'BoundedForallSize.lean'),True,0),
('accepted-GraphSizeBounds','accepted-final',Path(PRODUCTION+'GraphSizeBounds.lean'),Path(PRODUCTION+'GraphSizeBounds.lean'),True,0),
('accepted-BoundedForallDepth','accepted-final',Path(PRODUCTION+'BoundedForallDepth.lean'),Path(PRODUCTION+'BoundedForallDepth.lean'),True,0),
('accepted-focus-BoundedForallDepth','accepted-final',Path('Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean'),Path('Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean'),False,0)]
records=[]
for tag,scope,source,snapshot,has_output,expected_code in specs:
    log=OUT/(tag+'.log')
    timing=OUT/(tag+'.time')
    parsed=re.findall(r'elapsed_seconds=([0-9.]+) max_rss_kib=(\d+) exit_status=(\d+)',timing.read_text())
    assert len(parsed)==1,tag
    elapsed,rss,code=parsed[0]
    assert int(code)==expected_code,(tag,code)
    argv=['lake','env','lean','-M6000','-j1','-DElab.async=false',str(source)]
    if has_output:argv+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+source.stem+'.olean']
    records.append({'tag':tag,'classification':scope,'argv':argv,'cwd':str(Path.cwd()),'actual_exit_status':int(code),'observation_basis':'Actual author tool completion and retained GNU time record. Assembly reauthenticates existing observations without rerunning any Lean command.','source_snapshot':record(snapshot),'log':record(log),'timing':record(timing),'elapsed_seconds':elapsed,'max_rss_kib':int(rss),'warnings':[line for line in log.read_text().splitlines() if 'warning:' in line],'errors':[line for line in log.read_text().splitlines() if ': error:' in line]})
assert len(records)==20 and sum(r['actual_exit_status']==0 for r in records)==16
assert len([r for r in records if r['classification']=='accepted-final'])==6
client_state=json.loads((OUT/'final-clients-state.json').read_text())
assert client_state['complete'] and len(client_state['records'])==4 and client_state['source_sha256']==record(TARGET)['sha256']
assert all(r['actual_exit_status']==0 for r in client_state['records'])
pattern=re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)",re.S)
oldlog=(OUT/'baseline-axioms.log').read_bytes()
newlog=(OUT/'split-conjunction-axioms.log').read_bytes()
a=pattern.findall(oldlog.decode())
b=pattern.findall(newlog.decode())
assert len(a)==len(b)==17 and oldlog==newlog
reports=[]
for (oldname,oldset),(newname,newset) in zip(a,b,strict=True):
    assert oldname==newname
    x={v.strip() for v in oldset.split(',') if v.strip()}
    y={v.strip() for v in newset.split(',') if v.strip()}
    assert x==y
    reports.append({'declaration':oldname,'axioms':sorted(y)})
assert next(r for r in reports if r['declaration'].endswith('.splitSize_correct'))['axioms']==['Quot.sound','propext']
for path in ['final-axioms.log','accepted-axioms.log']:
    candidate=dict(pattern.findall((OUT/path).read_text()))
    assert set(v.strip() for v in candidate['DiophantineConsistency.ExpressionSize.splitSize_correct'].split(','))=={'propext','Classical.choice','Quot.sound'}
contracts=[Path(PRODUCTION+n+'.lean') for n in ['NaturalExpression','QuarticCompiler','BoundedForallSize','GraphSizeBounds','BoundedForallDepth']]+[Path('Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean')]
for source in contracts:assert source.read_bytes()==subprocess.check_output(['git','show',baseline['base']+':'+str(source)]),source
assert not any(r['warnings'] for r in records)
result={'baseline':baseline,'final_source':record(TARGET),'source_counts':{'old_lines':len(old.splitlines()),'new_lines':len(new.splitlines()),'lines_removed':len(old.splitlines())-len(new.splitlines()),'old_bytes':len(old.encode()),'new_bytes':len(new.encode()),'bytes_removed':len(old.encode())-len(new.encode()),'added_helpers':0,'added_imports':0,'added_public_declarations':0},'integrity':{'all_bytes_outside_one_proof_body_identical':True,'old_complete_public_theorem_headers_literal':5,'old_whole_executable_definitions_literal':6,'entire_SplitSize_structure_and_derived_instances_literal':True,'imports_options_and_attributes_literal':True,'arbitrary_variable_types_and_integer_coefficients_unchanged':True},'accepted_final_calls':6,'separate_original_target_calls':1,'separate_fresh_baseline_calls':1,'superseded_axiom_rejected_successful_calls':8,'failed_production_candidate_calls':3,'failed_diagnostic_copy_calls':1,'total_Lean_calls':20,'records':records,'axioms':{'report_count':17,'old_final_stdout_byte_identical':True,'stdout_sha256':hashlib.sha256(newlog).hexdigest(),'axiom_free_count':sum(not r['axioms'] for r in reports),'reports':reports,'no_additions':True},'candidate_findings':[{'candidate':'first compact simp_all body','Lean_calls':6,'all_exit_zero':True,'finding':'All production/client/focus/audit calls pass, but the changed theorem gains Classical.choice; rejected.','snapshot':record(OUT/'first-candidate.lean')},{'candidate':'simp_all only without explicit and_self','Lean_exit_status':1,'finding':'Leaf goals reduce to True conjunction True; omega cannot close these.','snapshot':record(OUT/'only-candidate.lean')},{'candidate':'restricted simplification then constructor, without and_self','Lean_exit_status':1,'finding':'Leaf True goals remain after constructor; omega cannot close them.','snapshot':record(OUT/'only-constructor-candidate.lean')},{'candidate':'reflexive-pair fallback','Lean_exit_status':1,'finding':'Simplification changed reflexive equalities to True, so the pair-of-rfl fallback does not fit.','snapshot':record(OUT/'repaired-candidate.lean')},{'candidate':'temporary trace-goals copy','Lean_exit_status':1,'finding':'Preserves failure and exposes exact remaining goals; diagnostic only.','snapshot':record(OUT/'trace-goals.lean')},{'candidate':'restricted simplification with and_self, before explicit constructor','Lean_calls':2,'all_exit_zero':True,'finding':'Target passes but changed theorem still gains Classical.choice; rejected.','snapshot':record(OUT/'restricted-and-self-candidate.lean')}],'accepted_proof':'Induct over all five Expr constructors; simplify only the existing natural split/count and paired metadata definitions plus and_self; explicitly construct each remaining conjunction before omega proves its linear equalities.','validation_scope':'Full target and direct symbolic BoundedForallSize consumer; freshly refreshed GraphSizeBounds and BoundedForallDepth client; existing checks/BoundedForallDepth has one example and eight axiom queries. No standalone ExpressionSize focus file exists.','validation_limits':'Unchanged project/package imports are precompiled reuse; no whole-library replay or performance benchmark is claimed. All accepted-final calls use -M6000 -j1 -DElab.async=false. Failed and axiom-rejected development candidates remain separate. The original target had transient futex waiting before actual success; it was not restarted.','unchanged_contracts_and_clients':[record(p) for p in contracts],'independent_static_peer':{'agent':'free_ratio_cleanup','scope':'Full80line source, original90line diff, NaturalExpression, actualGates.count/Wire and fullBoundedForallSize consumer; exact17 old/final reports. No reviewer compiler or source/cache edits.','result':'PASS on de05f649a219de066bedee13bc8f2967ae32cb10afb7ba6e9eae70f3154700be'},'pinned_toolchain':{'lean_toolchain':record('lean-toolchain'),'lake_manifest':record('lake-manifest.json'),'lake_configuration':record('lakefile.toml'),'mathlib_head':subprocess.check_output(['git','-C','.lake/packages/mathlib','rev-parse','HEAD'],text=True).strip()}}
path=OUT/'results.json'
assert not path.exists()
path.write_text(json.dumps(result,indent=2)+'\n')
path.chmod(0o444)
print(json.dumps({'receipt':record(path),'source':result['final_source'],'counts':result['source_counts'],'accepted_final_calls':6,'total_Lean_calls':20,'actual_successes':16,'actual_failures':4,'all_accepted_footprints_identical':True,'report_count':17,'axiom_free_count':result['axioms']['axiom_free_count']},indent=2))
