from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path.cwd()
OUT=Path('/tmp/expression-size-cleanup-20261028')
p=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ExpressionSize.lean')
baseline=json.loads((OUT/'baseline.json').read_text())
old=(OUT/'original.lean').read_text()
new=p.read_text()
marker='    QuarticCompiler.Gates.count e.splitNatural.2 = (splitSize e).negative := by\n'
finish='\n@[simp] theorem splitSize_rename'
assert old.count(marker)==new.count(marker)==1
oldprefix,oldtail=old.split(marker)
newprefix,newtail=new.split(marker)
oldproof,oldsuffix=oldtail.split(finish,1)
newproof,newsuffix=newtail.split(finish,1)
assert oldprefix==newprefix and oldsuffix==newsuffix
assert newproof=='  induction e <;> simp_all [Expr.splitNatural, QuarticCompiler.Gates.count, splitSize,\n    SplitSize.leaf, SplitSize.add, SplitSize.sub, SplitSize.mul] <;> omega\n'
assert old.encode()==subprocess.check_output(['git','show',baseline['base']+':'+str(p)])

def file_record(path):
    path=Path(path)
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

specs=[('original-target','original-source-build',str(p),True),('baseline-axioms','fresh-original-axiom-audit',str(OUT/'public-axioms.lean'),False),('final-target','final',str(p),True),('client-BoundedForallSize','final','Computability/DiophantineConsistency/Lean/DiophantineConsistency/BoundedForallSize.lean',True),('client-GraphSizeBounds','final','Computability/DiophantineConsistency/Lean/DiophantineConsistency/GraphSizeBounds.lean',True),('client-BoundedForallDepth','final','Computability/DiophantineConsistency/Lean/DiophantineConsistency/BoundedForallDepth.lean',True),('focus-BoundedForallDepth','final','Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean',False),('final-axioms','final',str(OUT/'public-axioms.lean'),False)]
records=[]
for tag,classification,source,output in specs:
    log=OUT/(tag+'.log')
    timing=OUT/(tag+'.time')
    matched=re.findall(r'elapsed_seconds=([0-9.]+) max_rss_kib=(\d+) exit_status=(\d+)',timing.read_text())
    assert len(matched)==1,tag
    elapsed,rss,code=matched[0]
    assert int(code)==0,(tag,code)
    argv=['lake','env','lean','-M6000','-j1','-DElab.async=false',source]
    if output:
        argv+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+Path(source).stem+'.olean']
    records.append({'tag':tag,'classification':classification,'argv':argv,'cwd':str(ROOT),'actual_exit_status':int(code),'observation_basis':'Direct author tool completion observed; retained GNU time record corroborates. No command is rerun during assembly.','log':file_record(log),'timing':file_record(timing),'elapsed_seconds':elapsed,'max_rss_kib':int(rss),'warnings':[line for line in log.read_text().splitlines() if 'warning:' in line]})
pattern=re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)",re.S)
oldlog=(OUT/'baseline-axioms.log').read_bytes()
newlog=(OUT/'final-axioms.log').read_bytes()
oldreports=pattern.findall(oldlog.decode())
newreports=pattern.findall(newlog.decode())
assert len(oldreports)==len(newreports)==17
axioms=[]
for (oldname,oldset),(newname,newset) in zip(oldreports,newreports,strict=True):
    assert oldname==newname
    a={value.strip() for value in oldset.split(',') if value.strip()}
    b={value.strip() for value in newset.split(',') if value.strip()}
    assert b<=a,(oldname,a,b)
    axioms.append({'declaration':oldname,'old_axioms':sorted(a),'new_axioms':sorted(b),'unchanged':a==b,'strict_subset':b<a})
assert oldlog==newlog
assert all(not r['warnings'] for r in records)
contracts=['Computability/DiophantineConsistency/Lean/DiophantineConsistency/NaturalExpression.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/QuarticCompiler.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/BoundedForallSize.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/GraphSizeBounds.lean','Computability/DiophantineConsistency/Lean/DiophantineConsistency/BoundedForallDepth.lean','Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean']
for source in contracts:
    assert Path(source).read_bytes()==subprocess.check_output(['git','show',baseline['base']+':'+source]),source
result={'baseline':baseline,'final_source':file_record(p),'whole_source_count':{'old_lines':len(old.splitlines()),'new_lines':len(new.splitlines()),'net_lines_removed':len(old.splitlines())-len(new.splitlines()),'old_bytes':len(old.encode()),'new_bytes':len(new.encode()),'net_bytes_removed':len(old.encode())-len(new.encode()),'new_helpers':0,'new_imports':0},'source_integrity':{'all_bytes_outside_one_splitSize_correct_proof_body_identical':True,'all_five_old_public_theorem_headers_literal':True,'all_six_whole_executable_definitions_literal':True,'whole_SplitSize_structure_and_derived_instances_literal':True,'same_imports_and_options':True,'same_arbitrary_variable_type_and_integer_constants':True,'new_public_declarations':[]},'final_Lean_call_count':6,'original_source_build_count':1,'fresh_baseline_call_count':1,'records':records,'axioms':{'old_final_stdout_byte_identical':True,'report_count':17,'report_sha256':hashlib.sha256(newlog).hexdigest(),'axiom_free_declaration_count':sum(not r['new_axioms'] for r in axioms),'reports':axioms,'no_additions':True},'focused_validation':{'existing_file':'Computability/DiophantineConsistency/Lean/checks/BoundedForallDepth.lean','examples':1,'public_axiom_queries':8,'limits':'No standalone ExpressionSize focused file exists; the existing downstream metadata focus and full direct/downstream production clients are run. No new implementation-mirroring test.'},'unchanged_contracts_and_clients':[file_record(source) for source in contracts],'failures':[],'repairs':[],'warnings':[],'interpretation':'Same structural induction over all five Expr constructors. simp_all rewrites both conjunction hypotheses into the unchanged natural syntax/count fold, then omega resolves reassociation of natural sums. No scalar replacement for the executable paired size metadata is adopted.','validation_limits':'All six exact-final calls pass first try with existing source imports/options and -M6000 -j1 -DElab.async=false. Unchanged imported project/package objects remain reused, not a whole-project rebuild. Original target had transient waiting before success; no restart or timeout was counted as failure. Timing is observation only, not a speedup claim.','pinned_toolchain':{'lean_toolchain':file_record('lean-toolchain'),'lake_manifest':file_record('lake-manifest.json'),'lake_configuration':file_record('lakefile.toml'),'mathlib_head':subprocess.check_output(['git','-C','.lake/packages/mathlib','rev-parse','HEAD'],text=True).strip()}}
dest=OUT/'results.json'
assert not dest.exists()
dest.write_text(json.dumps(result,indent=2)+'\n')
dest.chmod(0o444)
print(json.dumps({'result':file_record(dest),'whole_source_count':result['whole_source_count'],'final_Lean_calls':6,'all_actual_exit_zero':all(r['actual_exit_status']==0 for r in records),'old_public_reports':17,'stdout_byte_identical':True,'axiom_free_reports':result['axioms']['axiom_free_declaration_count']},indent=2))
