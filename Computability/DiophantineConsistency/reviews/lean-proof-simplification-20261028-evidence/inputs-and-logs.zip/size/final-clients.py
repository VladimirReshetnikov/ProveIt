from pathlib import Path
import hashlib,json,subprocess
OUT=Path('/tmp/expression-size-cleanup-20261028')
ROOT='Computability/DiophantineConsistency/Lean/'
source=Path(ROOT+'DiophantineConsistency/ExpressionSize.lean')
sha=hashlib.sha256(source.read_bytes()).hexdigest()
state={'source_sha256':sha,'complete':False,'records':[]}
for tag,path,output in [('BoundedForallSize','DiophantineConsistency/BoundedForallSize.lean',True),('GraphSizeBounds','DiophantineConsistency/GraphSizeBounds.lean',True),('BoundedForallDepth','DiophantineConsistency/BoundedForallDepth.lean',True),('focus-BoundedForallDepth','checks/BoundedForallDepth.lean',False)]:
    assert hashlib.sha256(source.read_bytes()).hexdigest()==sha
    log=OUT/('accepted-'+tag+'.log')
    timing=OUT/('accepted-'+tag+'.time')
    argv=['lake','env','lean','-M6000','-j1','-DElab.async=false',ROOT+path]
    if output:argv+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+tag+'.olean']
    with log.open('wb') as stream:
        result=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(timing),*argv],stdout=stream,stderr=subprocess.STDOUT)
    state['records'].append({'tag':tag,'argv':argv,'actual_exit_status':result.returncode,'log':str(log),'timing':str(timing)})
    (OUT/'final-clients-state.json').write_text(json.dumps(state,indent=2)+'\n')
    print(tag,'actual_exit_status',result.returncode,flush=True)
    if result.returncode!=0:raise SystemExit(result.returncode)
assert hashlib.sha256(source.read_bytes()).hexdigest()==sha
state['complete']=True
(OUT/'final-clients-state.json').write_text(json.dumps(state,indent=2)+'\n')
print('All4 accepted-body clients/focus pass',flush=True)
