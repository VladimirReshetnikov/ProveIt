from pathlib import Path
import re,json,subprocess,hashlib
base='8e13da9d92cf9f4f4aa004d80f34c98fd26ba093'
root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
names=['FreeCarrierRatio','ExpressionSize','SignedPellResidue','ThirteenFreshSeed']
pat=re.compile(r'^(?:@\[[^\n]*\]\s*)?(?P<mods>(?:(?:private|noncomputable|protected)\s+)*)(?P<kind>theorem|lemma|def|abbrev)\s+(?P<name>[\w\u0080-\uffff\x27]+)',re.M)
stop=re.compile(r'^/--|^/-!|^#print|^end(?: |$)',re.M)
def header_boundary(block):
 depth=[];i=0;comment=0;string=False
 while i<len(block):
  if comment:
   if block.startswith('/-',i):comment+=1;i+=2
   elif block.startswith('-/',i):comment-=1;i+=2
   else:i+=1
   continue
  if string:
   if block[i]=='\\':i+=2
   elif block[i]=='"':string=False;i+=1
   else:i+=1
   continue
  if block.startswith('/-',i):comment=1;i+=2;continue
  if block.startswith('--',i):
   end=block.find('\n',i);i=len(block) if end<0 else end;continue
  if block[i]=='"':string=True;i+=1;continue
  if not depth and block.startswith(':=',i):return i
  if not depth and block[i]=='|' and not block[block.rfind('\n',0,i)+1:i].strip():return i
  if not depth and re.match(r'where\b',block[i:]):return i
  if block[i] in '([{':depth.append(block[i])
  elif block[i] in ')]}':
   assert depth and '([{'.index(depth[-1])==')]}'.index(block[i]),(i,block[i],depth)
   depth.pop()
  i+=1
 raise AssertionError(('no top-level definition delimiter',block[:100]))
def parse(text):
 matches=list(pat.finditer(text));out={}
 for index,m in enumerate(matches):
  end=matches[index+1].start() if index+1<len(matches) else len(text)
  bound=stop.search(text,m.end(),end)
  if bound:end=bound.start()
  block=text[m.start():end].strip()
  header=block[:header_boundary(block)]
  key=(m['kind'],m['name']);assert key not in out,key
  out[key]=(m['mods'],header,block)
 return out
reports={};public=definitions=0
for name in names:
 p=root/(name+'.lean');old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);new=p.read_text();a,b=parse(old),parse(new)
 pub={k:v for k,v in a.items() if k[0] in ['theorem','lemma'] and 'private' not in v[0]}
 for k,v in pub.items():assert k in b and v[1]==b[k][1],(name,'public header',k)
 defs={k:v for k,v in a.items() if k[0] in ['def','abbrev']}
 for k,v in defs.items():assert k in b and v[2]==b[k][2],(name,'definition',k)
 public+=len(pub);definitions+=len(defs)
 reports[name]={'old_public_theorems':len(pub),'unchanged_definition_blocks':len(defs),'old_lines':len(old.splitlines()),'new_lines':len(new.splitlines()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
result={'header_boundary_method':'Exact original text up to first top-level :=, where, or equation-pattern bar, skipping nested brackets, comments and strings; preserves full nested have := in theorem types. No whitespace normalization or nested-definition truncation is used.','base':base,'unchanged_old_public_theorem_headers':public,'unchanged_whole_definitions':definitions,'modules':reports}
Path('/tmp/diophantine-oct28-source-integrity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
