from pathlib import Path
import json,subprocess,time,hashlib,sys
OUT=Path('/tmp/pell-norm-cleanup-20261028')
mode=sys.argv[1]
prefix='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
if mode=='baseline':
    specs=[('original-SignedPellResidue',prefix+'SignedPellResidue.lean','SignedPellResidue'),('original-ThirteenFreshSeed',prefix+'ThirteenFreshSeed.lean','ThirteenFreshSeed'),('baseline-axioms',str(OUT/'old-public-axioms.lean'),None)]
elif mode=='final':
    specs=[('final-SignedPellResidue',prefix+'SignedPellResidue.lean','SignedPellResidue'),('final-NativePellStepDown',prefix+'NativePellStepDown.lean','NativePellStepDown'),('final-ThirteenCarrierSoundness',prefix+'ThirteenCarrierSoundness.lean','ThirteenCarrierSoundness'),('final-ThirteenFreshSeed',prefix+'ThirteenFreshSeed.lean','ThirteenFreshSeed'),('final-NativePositiveSourceConstruction',prefix+'NativePositiveSourceConstruction.lean','NativePositiveSourceConstruction'),('final-ThirteenCarrierComplete',prefix+'ThirteenCarrierComplete.lean','ThirteenCarrierComplete'),('final-SignedPellResidueChecks',prefix+'SignedPellResidueChecks.lean',None),('final-ThirteenFreshSeedChecks',prefix+'ThirteenFreshSeedChecks.lean',None),('final-axioms',str(OUT/'old-public-axioms.lean'),None)]
else:raise SystemExit('expected baseline or final')
state={'mode':mode,'records':[],'complete':False}
recordpath=OUT/(mode+'-commands.json')
assert not recordpath.exists()
def rec(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for tag,source,output in specs:
    cmd=['lake','env','lean','-M6000','-j1','-DElab.async=false',source]
    if output:cmd+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+output+'.olean']
    before=rec(source);log=OUT/(tag+'.log');timing=OUT/(tag+'.time')
    began=time.monotonic()
    with log.open('wb') as stream:
        result=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(timing),*cmd],stdout=stream,stderr=subprocess.STDOUT)
    assert rec(source)==before
    row={'tag':tag,'argv':cmd,'source':before,'actual_exit_status':result.returncode,'elapsed_monotonic_seconds':time.monotonic()-began,'log':rec(log),'timing':rec(timing)}
    if output and result.returncode==0:row['object']=rec(cmd[-1])
    state['records'].append(row);recordpath.write_text(json.dumps(state,indent=2)+'\n');print(tag,'actualexit',result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
state['complete']=True
if mode=='final':
    state['old_public_report_stdout_byte_identical']=(OUT/'baseline-axioms.log').read_bytes()==(OUT/'final-axioms.log').read_bytes()
recordpath.write_text(json.dumps(state,indent=2)+'\n')
