from pathlib import Path
import json,hashlib,os,subprocess,sys,time
P=Path('/tmp/controller-dmap-sharing');phase=sys.argv[1];src=P/'sources'/phase;root=P/phase;base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+base; paths=[Path(s) for s in env['LEAN_PATH'].split(':') if s];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
names=['ArithmeticControllerChoice','ArithmeticController','ArithmeticConstructionVariation','ArithmeticConstructionAssembly']
for n in names:
 source=src/'DiophantineConsistency'/(n+'.lean');workspace=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');modules=[x for line in source.read_text().splitlines() if line.startswith('import ') for x in line.split()[1:]];inputs=[]
 for m in modules:
  o=next((x/(m.replace('.','/')+'.olean') for x in paths if (x/(m.replace('.','/')+'.olean')).is_file()),None)
  q=Path('Computability/DiophantineConsistency/Lean')/(m.replace('.','/')+'.lean') if m.startswith('DiophantineConsistency.') else Path('Computability/BusyBeaver/Lean')/(m.replace('.','/')+'.lean')
  inputs.append({'module':m,'path':str(o) if o else None,'resolved':str(o.resolve()) if o else None,'object_before':h(o) if o else None,'source':str(q) if q.is_file() else None,'source_before':h(q) if q.is_file() else None})
 out=root/'DiophantineConsistency'/(n+'.olean');out.unlink(missing_ok=True);log=P/(phase+'-'+n+'.log');tm=P/(phase+'-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(src),str(source),'-o',str(out)];before=h(source);wsbefore=h(workspace);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for x in inputs:
  x['object_after']=h(x['path']) if x['path'] else None;x['source_after']=h(x['source']) if x['source'] else None
 row={'phase':phase,'module':n,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':round(time.monotonic()-t,2),'source':str(source),'source_before':before,'source_after':h(source),'workspace':str(workspace),'workspace_before':wsbefore,'workspace_after':h(workspace),'direct_inputs':inputs,'object':str(out),'object_sha256':h(out) if out.exists() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip()};records.append(row);(P/(phase+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,row['timing'],flush=True)
 if r.returncode or before!=h(source) or wsbefore!=h(workspace) or any(x['object_before'] is None or x['object_before']!=x['object_after'] or x['source_before']!=x['source_after'] for x in inputs):raise SystemExit(1)
