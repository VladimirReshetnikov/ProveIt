from pathlib import Path
import json,hashlib,os,subprocess,time
p=Path('/tmp/controller-dmap-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();r=[]
for ph in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(p/ph)+':'+base;src=p/'clients-interface.lean'; log=p/(ph+'-clients-interface.log');obj=p/ph/'DiophantineConsistency/ArithmeticConstructionAssembly.olean';before=h(obj);t=time.monotonic()
 with log.open('wb') as f:res=subprocess.run(['lean','-M10000','-j1','-DElab.async=false',str(src)],env=env,stdout=f,stderr=subprocess.STDOUT)
 r.append({'phase':ph,'status':res.returncode,'source_sha256':h(src),'target_sha256_before':before,'target_sha256_after':h(obj),'log_sha256':h(log),'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t});print(ph,res.returncode,flush=True)
(p/'clients-interface-records.json').write_text(json.dumps(r,indent=2)+'\n')
