from pathlib import Path
import shutil,hashlib,json,difflib,zipfile,subprocess
P=Path('/tmp/controller-dmap-sharing');D=Path('/tmp/controller-dmap-sharing-evidence-20261028');D.mkdir(exist_ok=True)
def copy(s,r):
 t=D/r;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,t)
for x in P.iterdir():
 if x.is_file() and not x.is_symlink() and x.suffix in {'.lean','.log','.time','.json','.py'}:copy(x,Path('records')/x.name)
for ph in ['baseline','final']:
 for x in (P/'sources'/ph).rglob('*.lean'):copy(x,Path('sources')/ph/x.relative_to(P/'sources'/ph))
for x in ['provider-audit.json','assembly-phase-records.json','assembly-common-records.json','assembly-input-pins.json']:copy(Path('/tmp/positive-shift-sharing/transport-receipts')/x,Path('provenance')/x)
copy(Path('/tmp/pell-construction-refresh/local-pins.json'),Path('provenance/pell-local-pins.json'))
copy(Path('/tmp/positive-shift-sharing/source-clean/records.json'),Path('provenance/positive-shift-clean-records.json'))
co=subprocess.check_output(['git','show','--format=fuller','--no-patch','172621966a'],text=True);(D/'provenance/claude-coauthor-commit.txt').write_text(co)
(D/'provenance/toolchain.txt').write_text(subprocess.check_output(['lean','--version'],text=True));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
a=(P/'sources/baseline/DiophantineConsistency/ArithmeticControllerChoice.lean').read_text().splitlines(keepends=True);b=(P/'sources/final/DiophantineConsistency/ArithmeticControllerChoice.lean').read_text().splitlines(keepends=True);(D/'prototype.patch').write_text(''.join(difflib.unified_diff(a,b,fromfile='baseline/ArithmeticControllerChoice.lean',tofile='final/ArithmeticControllerChoice.lean')))
(D/'README.md').write_text('''# Controller dmap proof sharing: isolated validation evidence

The prototype replaces the `dmap_add` proof in ArithmeticControllerChoice.lean with a shorter proof using the exact coordinate/position equivalence. It retains every original hypothesis, theorem statement, definition, import and guard, and removes 26 net lines. The baseline target source is byte-identical to the source in Claude Opus 5.5 coauthored commit 172621966a; the commit metadata is in `provenance/`. HEAD at packaging: `'''+head+'''`. No repository file was edited by this agent.

## Paired checks

The frozen target and direct clients ArithmeticController, ArithmeticConstructionVariation, and ArithmeticConstructionAssembly were rebuilt from source in each phase. All eight builds passed. `records/{baseline,final}-records.json` contain commands, LEAN_PATH, exact source and workspace before/after hashes, each direct input object and current source hash before/after, output/log/time hashes, timings and resource usage. `records/input-pin-audit.json` cross-checks all 30 direct input occurrences against same-phase outputs or current-source/object prior receipts; all matched. Baseline source snapshots match the current workspace and the two target direct inputs match the same pinned objects in both phases. The paired assembly logs are byte-identical and empty. The target's two warnings match after normalizing source path and line number; no new warning was introduced.

`records/{baseline,final}-names.log` show exactly the same 41 target namespace names, including generated declarations; zero names have namespace simp entries. `records/{baseline,final}-interfaces.log` are byte-identical for #check and #print axioms of all 41 names. `records/{baseline,final}-global-simp.log` have equal sets of 38,804 default simp declaration entries and flags. The corrected downstream interface probes for controller, controller_tiling, F_formula, construction_below_hL and construction pass and match byte-for-byte. Probe sources and hash receipts are included. #check and #print axioms show matching types and axiom dependencies, not byte identity of definitions.

## Providers and limits

Provider and inherited pin records are preserved in `provenance/`. The reused compiled inputs are incrementally authenticated by current source/object hashes and prior direct-input receipts; the original transport-sharing evidence archive is repository file `Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261028-claude-transport-sharing-evidence/inputs-and-logs.zip`, SHA-256 2540222cbfd655eb0403cb1563f159ddab0d816e1a0cc07ac733368342fa0a4e. This is not a clean full repository or Foundation closure rebuild. Existing transitive cached objects and dependency packages remain precompiled; compiled binaries are not packaged, and replay scripts refer to original absolute paths and environment.

## Failed attempts retained

`records/first.log` records the first proof attempt's unsolved positive case. Its source file was overwritten before a hash was captured; `records/first-attempt-reconstructed.lean` reproduces the entered text but cannot be independently authenticated as the exact original bytes. It is excluded from validation. `records/*-clients-interface-invalid.log` and `records/clients-interface-invalid-records.json` preserve the failed namespace probe, whose exact source is `records/clients-interface-invalid.lean`; it used the wrong namespace for construction_below_hL. Corrected probes were rerun and are the evidence counted above.
''')
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();files=sorted(x for x in D.rglob('*') if x.is_file() and x.name!='manifest.sha256');(D/'manifest.sha256').write_text(''.join(h(f)+'  '+f.relative_to(D).as_posix()+'\n' for f in files));a=Path(str(D)+'.zip')
with zipfile.ZipFile(a,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(x for x in D.rglob('*') if x.is_file()):z.write(f,f.relative_to(D.parent))
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None
 for x in z.infolist():assert hashlib.sha256(z.read(x)).hexdigest()==h(D.parent/x.filename)
print('files',len(files)+1,'size',a.stat().st_size,'sha256',h(a))
