from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/window-carry-tail');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
common=load(R/'common-records.json')[0];assert common['status']==0 and common['before']==common['after']==h(common['source'])==h(W/'ArithmeticCyclicWord.lean') and common['object_sha256']==h(common['object']) and common['log_sha256']==h(common['log'])
for d in common['direct_inputs']:assert d['before']==d['after']==h(d['path'])
wd=load('/tmp/window-digit-replace/final-records.json')
for mod in ('ArithmeticWindowDigits','ArithmeticWindowBits'):
 x=next(x for x in wd if x['module']==mod);assert x['status']==0 and x['before']==x['after']==h(W/f'{mod}.lean') and x['object_sha256']==h(x['object'])
 if mod=='ArithmeticWindowDigits':assert common['direct_inputs'][0]['before']==x['object_sha256']
prior=load('/tmp/window-rem-bound/final-records.json')[0];assert prior['module']=='ArithmeticWindowInterface' and prior['status']==0
records={p:load(R/f'{p}-records.json') for p in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticWindowCarry','ArithmeticWindowInterface']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log'])
  if x['module']!='ArithmeticWindowCarry':assert x['before']==h(W/f"{x['module']}.lean")
  else:
   rev='6416d3a8d7^' if ph=='baseline' else '6416d3a8d7'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWindowCarry.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert h(W/'ArithmeticWindowCarry.lean')==x['before']
  for d in x['direct_inputs']:
   assert d['before']==d['after']==h(d['path']);name=d['module'].split('.')[-1]
   if name=='ArithmeticCyclicWord':assert d['before']==common['object_sha256']
   elif name=='ArithmeticWindowCarry':assert d['before']==rr[0]['object_sha256']
   elif name=='ArithmeticWindowBits':assert d['before']==next(q['object_sha256'] for q in wd if q['module']==name)
   else:
    q=next(q for q in prior['direct_inputs'] if q['module']==d['module']);assert d['before']==q['object_before']==q['object_after'] and q['source_before']==q['source_after']==h(W/f'{name}.lean')
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=load(R/'client-probe2-records.json');assert len(rows)==8
for x in rows:assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[q['object_sha256'] for q in records[x['phase']]] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-client2-{n}.log').read_bytes()==(R/f'final-client2-{n}.log').read_bytes()
print('PASS current-source CyclicWord provider and adopted WindowDigits/Bits receipts, paired target/client and censuses')
