WindowCarry suffix digit decomposition simplification

Baseline ArithmeticWindowCarry SHA-256 8a8a0521e1b109ea380453a391b7c9f18f9b82302cfb8b07debad60bb596459d;
final SHA-256 7663b45a6877e8636e49a1b499a91b6ea9c54f8dff7732dd0d9df584c287ae3f.
The prefix_tail local identity now rewrites only the left side with the
existing mod_eq_mod_add theorem and closes by ring. The original applies
congrArg to that exact identity then calculates the ring rearrangement. The tested baseline and final snapshots match the parent and commit 6416d3a8d7, respectively. This
removes three net lines, retaining the exact private theorem statement, k < n
guard, witness, definitions, imports and data. The original proof was added in
5fcd5632b3b753237437f22904b899653f69916b, whose trailer is Co-Authored-By:
Claude Opus 5.5 <noreply@anthropic.com>.

common-records.json documents a fresh current-source ArithmeticCyclicWord build
against the current-source WindowDigits object in /tmp/window-digit-replace/
final-records.json; the other direct dependency is cached Mathlib. The target
and its sole direct source client ArithmeticWindowInterface were compiled in
both phases, with source snapshots and direct object hashes pinned before/after
in baseline-records.json and final-records.json. The client's other direct
provider source/object pairs match prior /tmp/window-rem-bound/final-records.json,
except WindowBits, which is matched to the fresh current-source provider in
/tmp/window-digit-replace/final-records.json. audit.py and audit.log verify
these pairs, fresh CyclicWord input and output, paired builds and probes.
This is not a full current-source transitive closure rebuild: other Lean project,
BusyBeaver, Foundation and Mathlib dependencies remain cached.

Single paired baseline/final user CPU timings (shared load, not benchmark
results): target 5.39/5.26 seconds, client 6.53/6.55 seconds. The client object
bytes match (eadcc1cf8adcd2e4f8ef6624dacc61b7936334c4bc31218ff57f7284c44c3084).
The 37 target namespace names and declaration/type/axiom reports match; default
simp and instance lists match at 29,063 and 13,173 entries. Client probes pin
both target and client objects and match all 43 names/type/axiom reports and
35,447 simp/15,617 instance entries. These do not establish identity of proof
bodies or of every persistent environment extension. Both target build logs have
the same preexisting warning; neither client build warns.

The first standalone exploratory probe (probe-failed.lean/.log) using plain rw
failed because it also rewrote a matching occurrence inside the quotient on the
right. probe.lean/.log show the corrected conv_lhs proof. These preliminary
probes have no complete before/after input receipt; the full paired target and
client builds are the validated result.
