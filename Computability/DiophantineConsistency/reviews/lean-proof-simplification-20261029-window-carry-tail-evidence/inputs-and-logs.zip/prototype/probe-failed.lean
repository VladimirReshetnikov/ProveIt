import DiophantineConsistency.ArithmeticWindowCarry
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticWindowDigits
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (w X a k n : V) (hk : k+1 ≤ n) :
    a * (X % Exp.exp (w*n)) = a * (X % Exp.exp (w*(k+1))) +
        a * (X % Exp.exp (w*n) / Exp.exp (w*(k+1))) * Exp.exp (w*(k+1)) := by
  rw [mod_eq_mod_add w X (k+1) n hk]
  ring
