import DiophantineConsistency.ArithmeticWindowCarry
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticWindowCarry).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticWindowCarry" then
   logInfo m!"DECL {n}"
