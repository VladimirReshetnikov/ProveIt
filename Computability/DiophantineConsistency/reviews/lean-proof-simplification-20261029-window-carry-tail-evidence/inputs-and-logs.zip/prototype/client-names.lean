import DiophantineConsistency.ArithmeticWindowInterface
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticWindowInterface).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticWindowInterface" then
   logInfo m!"DECL {n}"
