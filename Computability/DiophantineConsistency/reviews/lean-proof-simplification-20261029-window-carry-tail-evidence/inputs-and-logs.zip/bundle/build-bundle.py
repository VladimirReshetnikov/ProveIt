from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs')
R=Path('/tmp/window-carry-tail')
D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-window-carry-tail-evidence'
D.mkdir(parents=True,exist_ok=True)
sha=lambda b: hashlib.sha256(b).hexdigest()
items={}
def add(name, p):
 assert name not in items; items[name]=Path(p).read_bytes()
def git(path,rev): return subprocess.check_output(['git','show',f'{rev}:{path}'],cwd=ROOT)
rev='6416d3a8d70bc71626c9feb7dde80ea2eac3bb0d'; parent='126ad1b58a337493fc7227249fbf7e7ac24cd43c'
mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
items['commit/baseline.lean']=git(mod+'ArithmeticWindowCarry.lean',parent)
items['commit/final.lean']=git(mod+'ArithmeticWindowCarry.lean',rev)
assert items['commit/baseline.lean']==(R/'baseline/DiophantineConsistency/ArithmeticWindowCarry.lean').read_bytes()
assert items['commit/final.lean']==(R/'final/DiophantineConsistency/ArithmeticWindowCarry.lean').read_bytes()
for n in ['ArithmeticCyclicWord','ArithmeticWindowDigits','ArithmeticWindowBits','ArithmeticWindowInterface','ArithmeticCarrierRadix2011','ArithmeticMaskConstants','ArithmeticMaskPopulation','ArithmeticSaturation']:
 items['provider-sources/'+n+'.lean']=git(mod+n+'.lean',rev)
for f in sorted(R.rglob('*')):
 if f.is_file() and not any(x.startswith('objects-') for x in f.relative_to(R).parts):
  add('prototype/'+f.relative_to(R).as_posix(),f)
for name,p in {
 'prior/window-rem-bound-final-records.json':'/tmp/window-rem-bound/final-records.json',
 'prior/window-digit-final-records.json':'/tmp/window-digit-replace/final-records.json',
 'prior/positive-shift-source-clean-records.json':'/tmp/positive-shift-sharing/source-clean/records.json',
 'prior/mask-constants-records.json':'/tmp/mask-ins-simplify/records.json',
 'prior/mask-population-assembly-records.json':'/tmp/outer-seed-bound-sharing/assembly-builds2.json',
 'independent/review.txt':'/tmp/window-carry-tail-peer-review.txt',
 'independent/audit.py':'/tmp/window-carry-tail-peer-audit.py',
 'independent/audit.log':'/tmp/window-carry-tail-peer-audit.log',
 'bundle/build-bundle.py':'/tmp/build-window-carry-tail-bundle.py',
 }.items(): add(name,p)
zipfile_path=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zipfile_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(items.items()):
  info=zipfile.ZipInfo(name,date_time=(2026,10,29,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Simplify ArithmeticWindowCarry prefix_tail local identity using a targeted left-side rewrite',
'validation':'Fresh source-matched CyclicWord provider built against the adopted source-matched WindowDigits object. Paired WindowCarry and sole tracked Lean direct client WindowInterface builds pass; client objects match. Target and client declaration/type/axiom reports and default simp/instance lists match; both client probe inputs are pinned. Other client direct-provider source/object pairs are mapped to prior receipts.',
'limitations':['The whole project and Mathlib transitive closure were not rebuilt; the prior direct-provider receipt mappings and current pins do not prove a fully current-source closure.', 'Single paired shared-load timing samples do not establish a general performance result. Declaration and registration comparisons do not establish equality of proof bodies or of every persistent environment extension.', 'The unrestricted rewrite exploratory failure and corrected standalone probe are included, but lack complete contemporaneous source/input/output hash receipts; validation relies on the subsequent full paired builds.', 'Compiled objects are not included; receipts preserve object hashes and first-provider paths, and independent object byte checks require external objects.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(zipfile_path.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zipfile_path) as z:
 assert z.testzip() is None and set(z.namelist())==set(items)
 for n,b in items.items(): assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes(); print(n,sha(b),len(b))
