from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/window-carry-tail'); W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def load_recs(p):
 x=read(p);return x if isinstance(x,list) else [x]
b=(R/'baseline/DiophantineConsistency/ArithmeticWindowCarry.lean').read_text(); f=(R/'final/DiophantineConsistency/ArithmeticWindowCarry.lean').read_text()
old='''    have hx := mod_eq_mod_add w (X i) (k+1) n hk1
    calc a i * (X i % Exp.exp (w*n)) = a i * (X i % Exp.exp (w*(k+1)) +
          Exp.exp (w*(k+1)) * (X i % Exp.exp (w*n) / Exp.exp (w*(k+1)))) :=
          congrArg (fun t => a i * t) hx
      _ = _ := by ring'''
new='''    conv_lhs => rw [mod_eq_mod_add w (X i) (k+1) n hk1]
    ring'''
assert b.count(old)==1 and b.replace(old,new)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWindowCarry.lean'
def gitfile(rev): return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('6416d3a8d7^')==b and gitfile('6416d3a8d7')==f and (W/'ArithmeticWindowCarry.lean').read_text()==f
print('PASS exact single-block diff, commit and parent snapshots; workspace equals final')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticWindowCarry$', '--','*.lean'], text=True).splitlines()
assert clients==['Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWindowInterface.lean'],clients
print('PASS tracked Lean direct import search',clients)
rec={p:load_recs(R/f'{p}-records.json') for p in ('common','baseline','final')}
for p,rr in rec.items():
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==sha(x['source'])
  assert x['object_sha256']==sha(x['object']) and x['log_sha256']==sha(x['log'])
  assert Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  for d in x['direct_inputs']:
   first=next((Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file()),None)
   assert first==Path(d['path']) and first.resolve()==Path(d['resolved']) and d['before']==d['after']==sha(first)
  if x['module']!='ArithmeticWindowCarry': assert x['before']==sha(W/(x['module']+'.lean'))
  print('PASS build',p,x['module'],x['time'].strip(),'object',x['object_sha256'])
co=rec['common'][0]; assert co['module']=='ArithmeticCyclicWord'
wd=load_recs('/tmp/window-digit-replace/final-records.json'); prior=load_recs('/tmp/window-rem-bound/final-records.json')[0]
for mod in ('ArithmeticWindowDigits','ArithmeticWindowBits'):
 x=next(x for x in wd if x['module']==mod); assert x['status']==0 and x['before']==x['after']==sha(W/(mod+'.lean')) and x['object_sha256']==sha(x['object'])
print('PASS previous WindowDigits and WindowBits source/object pairs')
assert co['direct_inputs'][0]['before']==next(x['object_sha256'] for x in wd if x['module']=='ArithmeticWindowDigits')
for phase in ('baseline','final'):
 target,client=rec[phase]; assert [target['module'],client['module']]==['ArithmeticWindowCarry','ArithmeticWindowInterface']
 assert target['direct_inputs'][0]['before']==co['object_sha256']
 for d in client['direct_inputs']:
  mod=d['module'].split('.')[-1]
  if mod=='ArithmeticWindowCarry': assert d['before']==target['object_sha256']
  elif mod=='ArithmeticWindowBits': assert d['before']==next(x['object_sha256'] for x in wd if x['module']==mod)
  else:
   q=next(q for q in prior['direct_inputs'] if q['module']==d['module'])
   assert d['before']==q['object_before']==q['object_after'] and q['source_before']==q['source_after']==sha(W/(mod+'.lean'))
 print('PASS direct project provider source/object pairs',phase)
assert rec['baseline'][1]['object_sha256']==rec['final'][1]['object_sha256']
for name in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{name}-{phase}.json'); assert x['status']==0 and x['source_before']==x['source_after']==sha(x['source']) and x['object_before']==x['object_after']==sha(x['object'])==rec[phase][0]['object_sha256'] and x['log_sha256']==sha(x['log'])
 assert (R/f'baseline-{name}.log').read_bytes()==(R/f'final-{name}.log').read_bytes()
rows=read(R/'client-probe2-records.json');assert len(rows)==8
for x in rows:
 assert x['status']==0 and x['source_before']==x['source_after']==sha(x['source']) and x['objects_before']==x['objects_after']==[sha(q) for q in x['objects']]==[q['object_sha256'] for q in rec[x['phase']]] and x['log_sha256']==sha(x['log'])
for name in ('names','interfaces','simp','instances'):assert (R/f'baseline-client2-{name}.log').read_bytes()==(R/f'final-client2-{name}.log').read_bytes()
print('PASS paired target and both-object-pinned client reports; client objects byte-identical')
print('PASS limited to recorded direct inputs; transitive cached closure not rebuilt or independently pinned')
