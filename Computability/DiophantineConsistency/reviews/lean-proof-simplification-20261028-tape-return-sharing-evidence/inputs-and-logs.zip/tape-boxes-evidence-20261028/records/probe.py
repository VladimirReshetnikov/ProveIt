from pathlib import Path
import hashlib,json,subprocess,os,sys
root=Path('/tmp/tape-boxes-simplify'); phase=sys.argv[1]; env=os.environ.copy();out=root/phase/'objects';env['LEAN_PATH']=str(out)+':/tmp/oracle-share/final:/tmp/oracle-share/lib:'+env['LEAN_PATH'];H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); obj=out/'DiophantineConsistency/ArithmeticRuntimeBoundTapeBoxes.olean'; records=[]
for k in ['interfaces','names','global-simp']:
 p=root/f'{k}.lean'; log=root/f'{phase}-{k}.log'; before=H(p); ob=H(obj); cmd=['lean','-M10000','-j1','-DElab.async=false',str(p)]
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'phase':phase,'status':r.returncode,'source':str(p),'before':before,'after':H(p),'object':str(obj),'object_before':ob,'object_after':H(obj),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'log':str(log),'log_sha256':H(log)});(root/f'{phase}-probes.json').write_text(json.dumps(records,indent=2)+'\n'); print(phase,k,r.returncode,flush=True)
 if r.returncode:sys.exit(1)
