from pathlib import Path
import hashlib,json,subprocess,os,sys
r=Path('/tmp/tape-boxes-simplify');phase=sys.argv[1];env=os.environ.copy();out=r/f'downstream-{phase}';env['LEAN_PATH']=str(out)+':'+env['LEAN_PATH'];H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();p=r/'endpoint.lean';obj=out/'DiophantineConsistency/ArithmeticRuntimeBoundTapeRun.olean';log=r/f'downstream-{phase}-endpoint.log';before=H(p);ob=H(obj);cmd=['lean','-M10000','-j1','-DElab.async=false',str(p)]
with log.open('wb') as f:x=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
record={'phase':phase,'status':x.returncode,'source':str(p),'before':before,'after':H(p),'object':str(obj),'object_before':ob,'object_after':H(obj),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'log':str(log),'log_sha256':H(log)};(r/f'downstream-{phase}-endpoint.json').write_text(json.dumps(record,indent=2)+'\n');print(phase,x.returncode)
if x.returncode:sys.exit(1)
