from pathlib import Path
import json,hashlib
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');record=json.loads(Path('/tmp/site-check-sharing/records.json').read_text());report=[]
for n in ('ArithmeticSite215','ArithmeticControlFrame215'):
 x=next(x for x in record if x['phase']=='final' and x['name']==n);obj=Path('/tmp/site-check-sharing/final/DiophantineConsistency')/(n+'.olean');log=Path('/tmp/site-check-sharing')/f'final-{n}.log'
 assert x['status']==0 and x['before']==x['after']==H(x['source'])==H(repo/(n+'.lean')) and x['object_sha256']==H(obj) and x['log_sha256']==H(log)
 for dep,d in x['inputs'].items():assert d['before']==d['after']==H(d['path'])
 report.append({'module':n,'source':str(repo/(n+'.lean')),'source_sha256':H(repo/(n+'.lean')),'object':str(obj),'object_sha256':H(obj),'log_sha256':H(log),'provider_record':'/tmp/site-check-sharing/records.json','direct_inputs':x['inputs']})
print(json.dumps(report,indent=2))
