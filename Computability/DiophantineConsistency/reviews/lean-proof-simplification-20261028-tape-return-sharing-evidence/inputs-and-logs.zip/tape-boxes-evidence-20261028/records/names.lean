import DiophantineConsistency.ArithmeticRuntimeBoundTapeBoxes
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticRuntimeBoundTapeBoxes).isPrefixOf n then
      logInfo m!"DECL {n}"
