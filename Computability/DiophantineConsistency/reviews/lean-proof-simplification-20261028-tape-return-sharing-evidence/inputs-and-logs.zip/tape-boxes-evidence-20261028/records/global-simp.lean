import DiophantineConsistency.ArithmeticRuntimeBoundTapeBoxes
open Lean Elab Command
run_cmd do
 let env ← getEnv
 let t ← liftCoreM Lean.Meta.getSimpTheorems
 for (n, _) in env.constants.toList do
  if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) || t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
   logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
