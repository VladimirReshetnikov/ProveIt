from pathlib import Path
import json,hashlib
r=Path('/tmp/tape-boxes-simplify'); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for phase in ('baseline','final'):
 for x in json.loads((r/f'{phase}-records.json').read_text()):
  assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_sha256']==H(x['object']) and x['log_sha256']==H(x['log'])
  for d in x['direct_inputs']:
   first=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file())
   assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==H(first)
  print(phase,x['module'],len(x['direct_inputs']),'inputs ok')
 for x in json.loads((r/f'{phase}-probes.json').read_text()):
  assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_before']==x['object_after']==H(x['object']) and x['log_sha256']==H(x['log'])
  print(phase,Path(x['source']).name,'probe ok')
for x in ['interfaces','names','global-simp']:
 assert (r/f'baseline-{x}.log').read_bytes()==(r/f'final-{x}.log').read_bytes();print(x,'identical')
repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
for x in ['ArithmeticRuntimeBoundTapeBoxes','ArithmeticRuntimeBoundTapeSymbolic']:
 assert H(repo/f'{x}.lean')==H(r/'baseline/DiophantineConsistency'/f'{x}.lean');print(x,'baseline matches current repo')
