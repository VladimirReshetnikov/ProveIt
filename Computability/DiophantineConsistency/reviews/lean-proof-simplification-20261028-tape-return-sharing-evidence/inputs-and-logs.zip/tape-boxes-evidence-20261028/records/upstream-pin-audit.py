from pathlib import Path
import json,hashlib
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins=json.loads(Path('/tmp/site-check-sharing/input-pin-audit.json').read_text())
for x in pins:
 if x['phase']=='final' and not x['module'].endswith('ArithmeticRuntimeBoundTapeSymbolic'):
  assert h(x['current_source'])==x['source_sha256'] and h(x['object_path'])==x['object_sha256']; print(x['module'],'source and object match pin',x['prior_record'])
