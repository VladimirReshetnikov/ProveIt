from pathlib import Path
import hashlib,json,subprocess,os,sys,re
root=Path('/tmp/tape-boxes-simplify');phase=sys.argv[1];source=root/('baseline' if phase=='baseline' else 'sources');out=root/f'downstream-{phase}';env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env['LEAN_PATH'];H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for m in ['ArithmeticRuntimeBoundTapeControl','ArithmeticRuntimeBoundTapeRun']:
 p=source/'DiophantineConsistency'/f'{m}.lean';o=out/'DiophantineConsistency'/f'{m}.olean';log=root/f'downstream-{phase}-{m}.log';tm=root/f'downstream-{phase}-{m}.time';deps=[]
 for n in re.findall(r'^import\s+([^\s]+)',p.read_text(),re.M):
  rel=n.replace('.','/')+'.olean';dep=next(Path(d)/rel for d in env['LEAN_PATH'].split(':') if (Path(d)/rel).is_file());deps.append({'module':n,'path':str(dep),'resolved':str(dep.resolve()),'before':H(dep)})
 before=H(p);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(source),str(p),'-o',str(o)]
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['after']=H(d['path'])
 records.append({'phase':phase,'module':m,'status':r.returncode,'source':str(p),'before':before,'after':H(p),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'object':str(o),'object_sha256':H(o) if o.exists() else None,'log':str(log),'log_sha256':H(log),'time':tm.read_text()});(root/f'downstream-{phase}-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,m,r.returncode,records[-1]['time'].strip(),flush=True)
 if r.returncode or before!=H(p) or any(d['before']!=d['after'] for d in deps):sys.exit(1)
