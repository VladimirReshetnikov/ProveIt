from pathlib import Path
import json,hashlib
r=Path('/tmp/tape-boxes-simplify'); repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for phase in ('baseline','final'):
 for x in json.loads((r/f'downstream-{phase}-records.json').read_text()):
  assert x['status']==0 and x['before']==x['after']==H(x['source'])==H(repo/(x['module']+'.lean')) and x['object_sha256']==H(x['object']) and x['log_sha256']==H(x['log'])
  for d in x['direct_inputs']:
   first=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file())
   assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==H(first)
   if d['module'].endswith('ArithmeticControlFrame215'):assert str(first.resolve())=='/tmp/site-check-sharing/final/DiophantineConsistency/ArithmeticControlFrame215.olean'
   if d['module'].endswith('ArithmeticRuntimeBoundTapeSymbolic'):assert str(first.resolve())==str(r/phase/'objects/DiophantineConsistency/ArithmeticRuntimeBoundTapeSymbolic.olean')
   if d['module'].endswith('ArithmeticRuntimeBoundTapeControl'):assert str(first.resolve())==str(r/f'downstream-{phase}/DiophantineConsistency/ArithmeticRuntimeBoundTapeControl.olean')
  print(phase,x['module'],len(x['direct_inputs']),'inputs ok')
 x=json.loads((r/f'downstream-{phase}-endpoint.json').read_text());assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_before']==x['object_after']==H(x['object']) and x['log_sha256']==H(x['log']);print(phase,'endpoint probe ok')
assert (r/'downstream-baseline-endpoint.log').read_bytes()==(r/'downstream-final-endpoint.log').read_bytes(); print('endpoint type, axioms, Btape equation identical')
