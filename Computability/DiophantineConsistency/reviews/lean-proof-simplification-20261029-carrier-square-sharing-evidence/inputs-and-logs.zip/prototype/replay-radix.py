from pathlib import Path
import json,hashlib,os,subprocess,shutil
r=Path('/dev/shm/carrier-square-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior=Path('/dev/shm/radix-positivity/objects-final/DiophantineConsistency/ArithmeticRadixAlignment.olean');assert h(prior)=='212a7ec4ccb23469e596e66cb08690a3395486c6a4562ca5c2488b6424d1c8fa'
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text());x=next(x for x in rows if x['module']=='ArithmeticCarrierRadix2011');old=r/('initial-'+phase+'-records.json');shutil.copyfile(r/(phase+'-records.json'),old)
 for suffix in ('.log','.time'):shutil.copyfile(r/(phase+'-ArithmeticCarrierRadix2011'+suffix),r/('initial-'+phase+'-ArithmeticCarrierRadix2011'+suffix))
 target=r/('objects-'+phase)/'DiophantineConsistency/ArithmeticRadixAlignment.olean';target.unlink(missing_ok=True);target.symlink_to(prior)
 d=next(d for d in x['direct_inputs'] if d['module'].endswith('.ArithmeticRadixAlignment'));d['path']=str(target);d['resolved']=str(target.resolve());d['before']=h(target);src=Path(x['source']);x['before']=h(src);out=Path(x['object']);out.unlink();env=os.environ.copy();env['LEAN_PATH']=x['LEAN_PATH'];log=Path(x['log']);tm=Path(x['command'][x['command'].index('-o')+1])
 with log.open('wb') as f:p=subprocess.run(x['command'],env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in x['direct_inputs']:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 x.update(status=p.returncode,after=h(src),object_sha256=h(out) if out.exists() else None,log_sha256=h(log),time=tm.read_text());(r/(phase+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,p.returncode,x['time'].strip(),x['object_sha256'],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
