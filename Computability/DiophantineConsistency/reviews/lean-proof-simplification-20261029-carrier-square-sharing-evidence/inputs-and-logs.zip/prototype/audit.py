from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/dev/shm/carrier-square-sharing');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=['ArithmeticCarrierSoundness2011','ArithmeticCarrierSoundness2011Checks','ArithmeticCarrierRadix2011','ArithmeticConstructionZero']; rec={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text());assert [x['module'] for x in rows]==names;rec[phase]={x['module']:x for x in rows}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256']
  assert x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);assert d['source_before']==d['source_after']==h(d['source'])
   leaf=d['module'].split('.')[-1]
   if leaf in names:assert d['before']==rec[phase][leaf]['object_sha256']
  if x['module']!='ArithmeticCarrierSoundness2011':assert h(x['source'])==h(w/(x['module']+'.lean'))
  print('PASS build',phase,x['module'])
 for p in json.loads((r/(phase+'-probes.json')).read_text()):
  assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[phase][names[0]]['object_sha256']] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
for n in names[1:]:assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
for n in ('names','interfaces','simp','instances'):assert (r/('baseline-'+n+'.log')).read_bytes()==(r/('final-'+n+'.log')).read_bytes()
print('PASS target names/types/axioms and global registrations, and matching client objects')
providers={'ArithmeticNegativeNorms':('/tmp/four-positive-wrappers/refreshed-final-records.json','ArithmeticNegativeNorms'),'ArithmeticSignedPairs':('/tmp/signed-pairs-factors/final-records.json','ArithmeticSignedPairs'),'ArithmeticPellFirstIndex':('/tmp/four-positive-wrappers/upstream-records.json','ArithmeticPellFirstIndex'),'ArithmeticPellPowerRecovery':('/tmp/four-positive-wrappers/upstream-records.json','ArithmeticPellPowerRecovery'),'ArithmeticRadixAlignment':('/tmp/radix-positivity/final-records.json','ArithmeticRadixAlignment')}
for n,(p,m) in providers.items():
 q=next(x for x in json.load(open(p)) if x['module']==m);d=next(d for x in rec['final'].values() for d in x['direct_inputs'] if d['module'].endswith('.'+n));assert q['status']==0 and q['before']==q['after']==d['source_before'] and q['object_sha256']==d['before'];print('PASS provider',n,d['before'])
prior=next(x for x in json.load(open('/tmp/signed-pairs-factors/final-records.json')) if x['module']=='ArithmeticCarrierSoundness2011');d=next(d for d in prior['direct_inputs'] if d['module'].endswith('.CurrentEquationSyntax2011'));cur=next(d for d in rec['final'][names[0]]['direct_inputs'] if d['module'].endswith('.CurrentEquationSyntax2011'));assert d['before']==d['after']==cur['before'] and d['source_before']==d['source_after']==cur['source_before'];print('PASS CurrentEquationSyntax2011 prior input sample')
q=next(x for x in json.load(open('/tmp/positive-shift-sharing/source-clean/records.json')) if x['module']=='CurrentEquationSyntax2011' and x['phase']=='final');assert q['status']==0 and q['source_sha256_before']==q['source_sha256_after']==cur['source_before'] and q['object_sha256']==cur['before'];print('PASS CurrentEquationSyntax2011 prior producer')
for phase in ('baseline','final'):
 orig=next(x for x in json.load(open(r/('initial-'+phase+'-records.json'))) if x['module']=='ArithmeticCarrierRadix2011');old=next(d for d in orig['direct_inputs'] if d['module'].endswith('.ArithmeticRadixAlignment'));assert old['before']!=next(d for d in rec[phase]['ArithmeticCarrierRadix2011']['direct_inputs'] if d['module'].endswith('.ArithmeticRadixAlignment'))['before'] and h(r/('initial-'+phase+'-ArithmeticCarrierRadix2011.log'))==orig['log_sha256'];print('PASS retained older-RadixAlignment initial attempt',phase,old['before'])
print('PASS all checks')
