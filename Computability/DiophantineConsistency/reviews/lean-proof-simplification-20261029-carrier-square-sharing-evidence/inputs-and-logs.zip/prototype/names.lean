import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCarrierSoundness2011
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticCarrierSoundness2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCarrierSoundness2011" then
   logInfo m!"DECL {n}"
