CarrierSoundness square magnitude: share the symmetry case

The isolated candidate replaces a two-case signed-pair square proof with a
`wlog` reduction to the existing positive-order ring proof. In the reversed
case swap both inputs; multiply_swap_left/right and magnitude_swap recover the
original square and magnitude. The guard and all definitions, statements,
imports and data remain unchanged. The proof is four net lines shorter. The
complete source candidate SHA-256 is
60a28e45d4f0c1776bd7f72cd24197c1c35e1f45abfc9f71f2fefd610cc72c66;
baseline SHA-256 is
06ddbbc947211b55847d2b5c067680c5b7cc030a3bdd4e727c8885a7335d8733.
The baseline matches current workspace source. Candidate is not adopted here.

baseline-records.json and final-records.json contain paired target and all
three tracked direct Lean module clients: ArithmeticCarrierSoundness2011Checks,
ArithmeticCarrierRadix2011 and ArithmeticConstructionZero. Source, imports,
first-resolved direct provider paths and before/after object hashes, commands,
logs and timings are recorded. All builds pass; the three client objects match
between phases. Both target probes cover 65 target-namespace public/private
names and their types and axioms; their logs are byte-identical, as are global
simp (35,388 entries) and instance (15,592 entries) logs. No additional wlog
helper is observed. These comparisons do not establish proof-body equality or
equality of every persistent environment extension.

All six external provider objects match current-source prior successful producer receipts:
NegativeNorms /tmp/four-positive-wrappers/refreshed-final-records.json;
SignedPairs /tmp/signed-pairs-factors/final-records.json; PellFirstIndex and
PellPowerRecovery /tmp/four-positive-wrappers/upstream-records.json; and
RadixAlignment /tmp/radix-positivity/final-records.json; and
CurrentEquationSyntax2011 /tmp/positive-shift-sharing/source-clean/records.json.
The last is also sampled in /tmp/signed-pairs-factors/final-records.json.
The earlier Pell chain, other transitive project inputs, Foundation and Mathlib
remain cached, so this is not a full current-source closure rebuild.

General identified that initial CarrierRadix builds used RadixAlignment object
07883a2aea3a53396bbc3c6f44796eb97bef79486b78edd2588df48e5fd032fa,
whose sampled current source was not a matching producer. Both client phases
were replayed against adopted source-matched 212a7ec4ccb23469e596e66cb08690a3395486c6a4562ca5c2488b6424d1c8fa;
initial-*-records.json and initial-*-ArithmeticCarrierRadix2011.log/.time
preserve the original observations. The replay results replaced only the
CarrierRadix rows and outputs; target and other clients are unchanged.

The small preliminary probe passes; the first two failed probe source/logs are
retained (probe-failed{,2}.lean/.log). These preliminary probes have no full
input receipts and do not substitute for the paired target builds. Target user
CPU baseline/final 12.80/13.17 s is a single shared-load timing pair, not a
general benchmark. No target/client build emitted warnings. audit.py/.log check
all paired outputs, direct input first paths, prior associations and probes.
The audit's initial missing-prior-path invocation was corrected; its failed
traceback was not separately retained. No downstream closure beyond the three
tracked direct clients was replayed.
