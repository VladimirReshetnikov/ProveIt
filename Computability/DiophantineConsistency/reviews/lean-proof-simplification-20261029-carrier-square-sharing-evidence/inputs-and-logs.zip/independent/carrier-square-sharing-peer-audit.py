from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/dev/shm/carrier-square-sharing')
repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
h=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
mod='ArithmeticCarrierSoundness2011'
b=root/'baseline/DiophantineConsistency'/f'{mod}.lean'; f=root/'final/DiophantineConsistency'/f'{mod}.lean'
old=b.read_text(); new=f.read_text(); marker='private theorem square_magnitude'; end='private theorem rep_nat'
assert old[:old.index(marker)]==new[:new.index(marker)]
assert old[old.index(end):]==new[new.index(end):]
assert old[old.index(marker):old.index(end)].split(':= by')[0]==new[new.index(marker):new.index(end)].split(':= by')[0]
assert (repo/f'{mod}.lean').read_text()==new
rel=str(repo/f'{mod}.lean')
assert subprocess.check_output(['git','show','c110faf349^:'+rel])==b.read_bytes()
assert subprocess.check_output(['git','show','c110faf349:'+rel])==f.read_bytes()
print('Commit c110faf349 and parent match tested final and baseline')
print('Exact proof-only diff and final workspace match',h(b),h(f))
rs={}
for phase in ['baseline','final']:
 rows=json.loads((root/f'{phase}-records.json').read_text()); rs[phase]=rows
 assert [x['module'] for x in rows]==[mod,mod+'Checks','ArithmeticCarrierRadix2011','ArithmeticConstructionZero']
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source'])
  assert h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256']
  assert Path(x['command'][2]).read_text()==x['time']
  for d in x['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d.get('source_before'): assert d['source_before']==d['source_after']==h(d['source'])
   target=d['module'].replace('.','/')+'.olean'
   found=next(Path(q)/target for q in x['LEAN_PATH'].split(':') if (Path(q)/target).exists())
   assert found.resolve()==Path(d['path']).resolve()
 print(phase,'target and three clients: source, logs, objects and direct inputs match')
for x,y in zip(rs['baseline'][1:],rs['final'][1:]): assert x['object_sha256']==y['object_sha256']
print('All three client object hashes match')
for phase in ['baseline','final']:
 probes=json.loads((root/f'{phase}-probes.json').read_text())
 assert {p['name'] for p in probes}=={'names','interfaces','simp','instances'}
 for p in probes:
  assert p['status']==0 and p['source_before']==p['source_after']==h(p['source'])
  assert p['objects_before']==p['objects_after']==[h(o) for o in p['objects']]
  assert p['objects_before']==[rs[phase][0]['object_sha256']]
  assert h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
for name in ['names','interfaces','simp','instances']:
 assert (root/f'baseline-{name}.log').read_bytes()==(root/f'final-{name}.log').read_bytes()
 print(name,'paired logs identical',len((root/f'final-{name}.log').read_text().splitlines()),'lines')
print('Historical displaced RadixAlignment direct object:',json.loads((root/'initial-baseline-records.json').read_text())[2]['direct_inputs'][-1]['before'])
print('Current RadixAlignment direct object:',rs['baseline'][2]['direct_inputs'][-1]['before'])
providers=[('ArithmeticNegativeNorms','/tmp/four-positive-wrappers/refreshed-final-records.json'),('ArithmeticSignedPairs','/tmp/signed-pairs-factors/final-records.json'),('ArithmeticPellFirstIndex','/tmp/four-positive-wrappers/upstream-records.json'),('CurrentEquationSyntax2011','/tmp/positive-shift-sharing/source-clean/records.json'),('ArithmeticPellPowerRecovery','/tmp/four-positive-wrappers/upstream-records.json'),('ArithmeticRadixAlignment','/tmp/radix-positivity/final-records.json')]
inputs={d['module'].split('.')[-1]:d for r in rs['baseline'] for d in r['direct_inputs']}
for name,path in providers:
 d=inputs[name]; rows=json.loads(Path(path).read_text()); matches=[r for r in rows if r.get('module')==name and r.get('status')==0 and r.get('object_sha256')==d['before'] and r.get('source_sha256_before',r.get('before',r.get('source_sha256')))==d['source_before']]
 assert matches,(name,path)
 r=matches[-1]; assert r.get('source_sha256_after',r.get('after',r.get('source_after',d['source_after'])))==d['source_after']
 print('provider',name,'source/object pair matches',path)
print('PASS')
