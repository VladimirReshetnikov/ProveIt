import DiophantineConsistency.ThirteenFreshSeed
#print axioms DiophantineConsistency.ThirteenCarrierSoundness.affine_carrier_pos
example : (0 : ℤ) < 3 := by
  apply DiophantineConsistency.ThirteenCarrierSoundness.affine_carrier_pos
    (b := 1) (G := 1) (V := -1) (y := 5) (by norm_num) (by norm_num) (by norm_num)
  norm_num
