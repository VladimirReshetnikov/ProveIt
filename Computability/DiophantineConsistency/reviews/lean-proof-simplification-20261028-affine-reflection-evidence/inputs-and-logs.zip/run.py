from pathlib import Path
import os,subprocess,json,time,hashlib,sys
base=Path('/tmp/diophantine-affine-20261028'); mode=sys.argv[1]
src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
env=os.environ.copy(); env['LEAN_PATH']=str(base/mode)+':'+env.get('LEAN_PATH','')
steps=[]
for n in ['ThirteenCarrierSoundness','ThirteenFreshSeed']:
 steps.append((n,src/(n+'.lean'),['-o',str(base/mode/'DiophantineConsistency'/(n+'.olean'))]))
steps.append(('axioms',base/'axioms.lean',[]))
for n in ['ThirteenCarrierSoundnessChecks','ThirteenFreshSeedChecks','ThirteenCarrierComplete','ThirteenCorrectedStrong','NativePositiveSourceConstruction']:
 steps.append((n,src/(n+'.lean'),[]))
results=[]
for name,path,args in steps:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean/',str(path)]+args
 now=time.monotonic()
 with open(base/(mode+'-'+name+'.log'),'w') as out:
  p=subprocess.run(['/usr/bin/time','-v','-o',str(base/(mode+'-'+name+'.time'))]+cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
 results.append(dict(name=name,argv=cmd,exit_code=p.returncode,seconds=round(time.monotonic()-now,2),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 (base/(mode+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(name,p.returncode,results[-1]['seconds'],flush=True)
 if p.returncode: break
