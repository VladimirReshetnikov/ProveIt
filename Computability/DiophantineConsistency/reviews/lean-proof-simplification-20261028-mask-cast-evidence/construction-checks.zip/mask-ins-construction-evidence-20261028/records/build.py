from pathlib import Path
import hashlib,json,subprocess,os,sys,re,time
r=Path('/tmp/mask-ins-construction');phase=sys.argv[1];source=r/'sources'/phase;out=r/phase;env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env['LEAN_PATH'];H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for n in ['ArithmeticMaskConstants','ArithmeticRankForcing2011','ArithmeticConstructionAssembly','ArithmeticCurrentConstruction2011']:
 p=source/'DiophantineConsistency'/f'{n}.lean';ws=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');o=out/'DiophantineConsistency'/f'{n}.olean';log=r/f'{phase}-{n}.log';tm=r/f'{phase}-{n}.time';deps=[]
 for m in re.findall(r'^import\s+([^\s]+)',p.read_text(),re.M):
  rel=m.replace('.','/')+'.olean';obj=next(Path(d)/rel for d in env['LEAN_PATH'].split(':') if (Path(d)/rel).is_file());src=Path('Computability/DiophantineConsistency/Lean')/(m.replace('.','/')+'.lean');deps.append({'module':m,'path':str(obj),'resolved':str(obj.resolve()),'object_before':H(obj),'source':str(src) if src.is_file() else None,'source_before':H(src) if src.is_file() else None})
 before=H(p);wb=H(ws);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(source),str(p),'-o',str(o)];t=time.monotonic()
 with log.open('wb') as f:x=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['object_after']=H(d['path']);d['source_after']=H(d['source']) if d['source'] else None
 rec={'phase':phase,'module':n,'status':x.returncode,'source':str(p),'source_before':before,'source_after':H(p),'workspace':str(ws),'workspace_before':wb,'workspace_after':H(ws),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'object':str(o),'object_sha256':H(o) if o.exists() else None,'log':str(log),'log_sha256':H(log),'time':str(tm),'time_sha256':H(tm),'elapsed':round(time.monotonic()-t,2),'timing':tm.read_text().strip()};records.append(rec);(r/f'{phase}-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,x.returncode,rec['timing'],flush=True)
 if x.returncode or before!=rec['source_after'] or wb!=rec['workspace_after'] or any(d['object_before']!=d['object_after'] or d['source_before']!=d['source_after'] for d in deps):sys.exit(1)
