from pathlib import Path
import json,hashlib,subprocess,os,sys
r=Path('/tmp/mask-ins-construction');phase=sys.argv[1];p=r/'endpoint.lean';out=r/phase;obj=out/'DiophantineConsistency/ArithmeticCurrentConstruction2011.olean';log=r/f'{phase}-endpoint.log';tm=r/f'{phase}-endpoint.time';H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env['LEAN_PATH'];before=H(p);ob=H(obj);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(p)]
with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
x={'phase':phase,'status':q.returncode,'source':str(p),'source_before':before,'source_after':H(p),'object':str(obj),'object_before':ob,'object_after':H(obj),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'log':str(log),'log_sha256':H(log),'time':str(tm),'time_sha256':H(tm),'timing':tm.read_text().strip()};(r/f'{phase}-endpoint.json').write_text(json.dumps(x,indent=2)+'\n');print(phase,q.returncode,x['timing'])
if q.returncode:sys.exit(1)
