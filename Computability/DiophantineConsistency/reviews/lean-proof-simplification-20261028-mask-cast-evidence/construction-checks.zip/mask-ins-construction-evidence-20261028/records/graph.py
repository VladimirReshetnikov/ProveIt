from pathlib import Path
import re,json,hashlib
p=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();mods={f.stem:f for f in p.glob('*.lean')};D={n:re.findall(r'^import DiophantineConsistency\.([^\s]+)',f.read_text(),re.M) for n,f in mods.items()}
def reach(n,t,seen=None):
 seen=seen or set()
 if n==t:return True
 if n in seen:return False
 seen.add(n)
 return any(reach(x,t,seen.copy()) for x in D.get(n,[]))
def walk(n,seen=None):
 if seen is None:seen=set()
 if n not in seen:
  seen.add(n)
  for x in D.get(n,[]):walk(x,seen)
 return seen
out={'scope':'source imports in DiophantineConsistency namespace only; excludes dependencies that leave and re-enter via other namespaces','targets':{},'modules':{}}
for target in ['ArithmeticConstructionAssembly','ArithmeticCurrentConstruction2011']:
 closure=walk(target);out['targets'][target]={'closure_count':len(closure),'mask_affected':sorted(n for n in closure if reach(n,'ArithmeticMaskConstants')),'tiling_affected':sorted(n for n in closure if reach(n,'ArithmeticTilingRows'))}
 for n in closure:
  if n in mods:out['modules'][n]={'source':str(mods[n]),'sha256':h(mods[n]),'diophantine_imports':D[n]}
Path('/tmp/mask-ins-construction/graph.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print('source nodes',len(out['modules']));print(json.dumps(out['targets'],indent=2))
