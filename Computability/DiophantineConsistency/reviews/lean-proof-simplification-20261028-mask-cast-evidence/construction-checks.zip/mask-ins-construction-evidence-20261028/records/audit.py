from pathlib import Path
import json,hashlib
r=Path('/tmp/mask-ins-construction');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prev=json.loads(Path('/tmp/rowrel-independent-pins.json').read_text());mask=json.loads(Path('/tmp/mask-ins-simplify/independent-direct-provider-audit.json').read_text());tiling=json.loads(Path('/tmp/rowrel-sharing/alternate-records.json').read_text());mapping=[]
for phase in ('baseline','final'):
 rows=json.loads((r/f'{phase}-records.json').read_text());assert len(rows)==4;fresh={x['module']:x for x in rows}
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after'] and (x['workspace_before']==h(x['workspace']) or (x['module']=='ArithmeticMaskConstants' and x['workspace_before']==h(r/'sources/baseline/DiophantineConsistency/ArithmeticMaskConstants.lean') and h(x['workspace'])==h(r/'sources/final/DiophantineConsistency/ArithmeticMaskConstants.lean'))) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and h(x['time'])==x['time_sha256']
  if not(phase=='final' and x['module']=='ArithmeticMaskConstants'):assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   first=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(first) and d['source_before']==d['source_after'] and (d['source_before']==h(d['source']) or (d['module'].endswith('.ArithmeticMaskConstants') and d['source_before']==h(r/'sources/baseline/DiophantineConsistency/ArithmeticMaskConstants.lean') and h(d['source'])==h(r/'sources/final/DiophantineConsistency/ArithmeticMaskConstants.lean')));n=d['module'].split('.')[-1]
   if n in fresh:
    f=fresh[n];assert d['resolved']==f['object'] and d['object_before']==f['object_sha256'];expected=(phase=='final' and n=='ArithmeticMaskConstants');assert (d['source_before']!=f['source_before'])==expected
    match=['fresh '+phase+' '+n];note='workspace source differs from isolated candidate by design' if expected else None
   else:
    match=[];note=None
    if d['module'] in mask:
     m=mask[d['module']]
     if d['source_before']==m['source_sha256'] and d['object_before']==m['object_sha256']:match.append('mask independent-direct-provider-audit.json')
    for q in prev:
     if q['module']==d['module'] and q['source_sha256']==d['source_before'] and q['object_sha256']==d['object_before'] and (q['matches'] or q['fresh_same_phase']):match.append('rowrel-independent-pins.json '+q['phase']+' '+q['client'])
    for q in tiling:
     if q['module']==n and q['source_before']==d['source_before'] and q['object_sha256']==d['object_before']:match.append('rowrel-sharing/alternate-records.json iteration '+str(q['iteration']))
    assert match,(phase,x['module'],d['module'],d['source_before'],d['object_before'])
   mapping.append({'phase':phase,'client':x['module'],'module':d['module'],'source_sha256':d['source_before'],'object_sha256':d['object_before'],'path':d['resolved'],'matches':sorted(set(match)),'note':note})
  print('build',phase,x['module'],'direct',len(x['direct_inputs']),'verified')
 x=json.loads((r/f'{phase}-endpoint.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);assert x['object']==fresh['ArithmeticCurrentConstruction2011']['object'];print('endpoint',phase,'verified')
assert (r/'baseline-endpoint.log').read_bytes()==(r/'final-endpoint.log').read_bytes()
for n in ('ArithmeticTilingRows','ArithmeticTilingBand','ArithmeticTilingWord'):
 x=next(q for q in tiling if q['module']==n and (n!='ArithmeticTilingRows' or q['iteration']==2));ws=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==h(ws) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
 for d in x['direct_inputs']:
  assert d['object_before']==d['object_after']==h(d['path'])
  if d['source_before']!=h(d['source']):assert n=='ArithmeticTilingBand' and d['module'].endswith('ArithmeticTilingRows') and d['object_before']==next(q['object_sha256'] for q in tiling if q['module']=='ArithmeticTilingRows' and q['iteration']==2)
 print('adopted',n,'source/object and direct inputs verified')
(r/'provider-mapping.json').write_text(json.dumps(mapping,indent=2)+'\n');print('endpoint logs identical; mapped',len(mapping),'input occurrences')
