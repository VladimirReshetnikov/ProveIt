from pathlib import Path
import shutil,hashlib,json
r=Path('/tmp/mask-ins-construction');ref=Path('/tmp/rowrel-sharing/alternate');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); mods=['ArithmeticMaskConstants','ArithmeticRankForcing2011','ArithmeticConstructionAssembly','ArithmeticCurrentConstruction2011'];prep=[]
for phase in ('baseline','final'):
 out=r/phase;out.mkdir(exist_ok=True)
 for p in ref.iterdir():
  if p.name!='DiophantineConsistency':
   d=out/p.name
   if not d.exists():d.symlink_to(p)
 d=out/'DiophantineConsistency';d.mkdir(exist_ok=True)
 for p in (ref/'DiophantineConsistency').iterdir():
  q=d/p.name
  if not q.exists():q.symlink_to(p)
 for n in mods:
  (d/(n+'.olean')).unlink(missing_ok=True)
  p=Path('/tmp/mask-ins-simplify/src/DiophantineConsistency/ArithmeticMaskConstants.lean') if phase=='final' and n=='ArithmeticMaskConstants' else repo/(n+'.lean');q=r/'sources'/phase/'DiophantineConsistency'/(n+'.lean');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);prep.append({'phase':phase,'module':n,'source':str(p),'sha256':h(p),'snapshot':str(q),'snapshot_sha256':h(q)})
(r/'prepare-records.json').write_text(json.dumps(prep,indent=2)+'\n')
