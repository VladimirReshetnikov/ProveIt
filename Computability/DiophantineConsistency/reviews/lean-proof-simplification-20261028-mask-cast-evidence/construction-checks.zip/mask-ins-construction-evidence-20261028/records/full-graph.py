from pathlib import Path
import subprocess,collections,re,hashlib,json
r=Path('/tmp/mask-ins-construction');files=subprocess.check_output(['rg','--files','-g','*.lean'],text=True).splitlines();paths=collections.defaultdict(list)
for f in files:
 if '/Lean/' in f:paths[f.split('/Lean/',1)[1][:-5].replace('/','.')].append(f)
imports={};hashes={};missing=set();ambiguous={};
def walk(n,seen):
 if n in seen:return
 seen.add(n)
 if n not in paths:missing.add(n);return
 if len(paths[n])>1:
  canonical='Computability/BusyBeaver/Lean/'+n.replace('.','/')+'.lean'
  if canonical not in paths[n]:ambiguous[n]=paths[n];return
  p=Path(canonical)
 else:p=Path(paths[n][0])
 raw=p.read_bytes();hashes[n]={'source':str(p),'sha256':hashlib.sha256(raw).hexdigest()};imports[n]=re.findall(r'^import\s+([^\s]+)',raw.decode(),re.M)
 for m in imports[n]:walk(m,seen)
def reach(n,t,seen=None):
 if seen is None:seen=set()
 if n==t:return True
 if n in seen:return False
 seen.add(n)
 return any(reach(x,t,seen.copy()) for x in imports.get(n,[]))
results={}
for x in ['ArithmeticConstructionAssembly','ArithmeticCurrentConstruction2011']:
 target='DiophantineConsistency.'+x;cl=set();walk(target,cl);results[x]={'closure_count':len(cl),'mask_affected':sorted(n for n in cl if reach(n,'DiophantineConsistency.ArithmeticMaskConstants')),'tiling_affected':sorted(n for n in cl if reach(n,'DiophantineConsistency.ArithmeticTilingRows'))}
(r/'full-graph.json').write_text(json.dumps({'results':results,'source_hashes':hashes,'imports':imports,'missing_modules':sorted(missing),'ambiguous_modules':ambiguous},indent=2)+'\n');print('known',len(imports),'missing/external',len(missing),'ambiguous',len(ambiguous));print(json.dumps(results,indent=2));print('ambiguous names',list(ambiguous))
