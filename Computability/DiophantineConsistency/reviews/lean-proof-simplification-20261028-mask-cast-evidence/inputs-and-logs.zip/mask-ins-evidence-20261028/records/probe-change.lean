import DiophantineConsistency.ArithmeticMaskConstants
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticMaskConstants
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (j : ℕ) : inS (j:V) ↔ (j < 951 ∨ (960 ≤ j ∧ j < 986) ∨ j = 1004) := by
  change ((j:V) < ((951:ℕ):V) ∨ (((960:ℕ):V) ≤ (j:V) ∧
    (j:V) < ((986:ℕ):V)) ∨ (j:V) = ((1004:ℕ):V)) ↔ _
  simp only [Nat.cast_lt, Nat.cast_le, Nat.cast_inj]
