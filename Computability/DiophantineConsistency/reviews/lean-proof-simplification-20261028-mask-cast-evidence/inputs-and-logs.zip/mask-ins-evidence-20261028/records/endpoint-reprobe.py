from pathlib import Path
import os,re,subprocess,json,hashlib
r=Path('/tmp/mask-ins-simplify');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 src=r/'endpoints.lean';env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':')];inputs={}
 for n in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
  p=next((x/(n.replace('.','/')+'.olean') for x in roots if (x/(n.replace('.','/')+'.olean')).is_file()),None)
  if p is None:raise Exception(n)
  inputs[n]={'path':str(p.resolve()),'before':sha(p)}
 before=sha(src);log=r/f'{phase}-endpoint-reprobe.log';tm=r/f'{phase}-endpoint-reprobe.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for x in inputs.values():x['after']=sha(Path(x['path']))
 row={'phase':phase,'source':str(src),'before':before,'after':sha(src),'inputs':inputs,'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log)};records.append(row);(r/'endpoint-reprobe-records.json').write_text(json.dumps(records,indent=2));print(phase,q.returncode,flush=True)
 if q.returncode or before!=row['after'] or any(i['before']!=i['after'] for i in inputs.values()):raise SystemExit(1)
