from pathlib import Path
import os,re,subprocess,json,hashlib
r=Path('/tmp/mask-ins-simplify');base=Path('Computability/DiophantineConsistency/Lean');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[]
for phase in ['baseline','final']:
 overlay=r/phase;env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+lp;roots=[Path(x) for x in env['LEAN_PATH'].split(':')]
 for n in ['ArithmeticMaskConstants','ArithmeticRankForcing2011','ArithmeticWindowInterface']:
  src=(r/'src/DiophantineConsistency'/f'{n}.lean') if phase=='final' and n=='ArithmeticMaskConstants' else base/'DiophantineConsistency'/f'{n}.lean';root=r/'src' if str(src).startswith(str(r/'src')) else base;before=sha(src);inputs={}
  for name in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
   obj=next((x/(name.replace('.','/')+'.olean') for x in roots if (x/(name.replace('.','/')+'.olean')).is_file()),None)
   if obj is None:raise Exception('missing '+name+' for '+n)
   inputs[name]={'path':str(obj.resolve()),'before':sha(obj)}
  out=overlay/'DiophantineConsistency'/f'{n}.olean';out.unlink(missing_ok=True);log=r/f'{phase}-{n}.log';tm=r/f'{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)]
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for i in inputs.values():i['after']=sha(Path(i['path']))
  row={'phase':phase,'name':n,'source':str(src),'before':before,'after':sha(src),'inputs':inputs,'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};rec.append(row);(r/'records.json').write_text(json.dumps(rec,indent=2));print(phase,n,q.returncode,row['time'].strip(),flush=True)
  if q.returncode or before!=row['after'] or any(i['before']!=i['after'] for i in inputs.values()):raise SystemExit(1)
