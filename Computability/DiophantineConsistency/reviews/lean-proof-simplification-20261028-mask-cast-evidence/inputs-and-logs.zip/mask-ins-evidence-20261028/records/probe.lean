import DiophantineConsistency.ArithmeticMaskConstants
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticMaskConstants
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (j : ℕ) : inS (j:V) ↔ (j < 951 ∨ (960 ≤ j ∧ j < 986) ∨ j = 1004) := by
  unfold inS
  norm_cast
