from pathlib import Path
import json,hashlib
R=Path('/tmp/mask-ins-simplify'); repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=json.loads((R/'records.json').read_text());deps={}
for row in rows:
 for n,i in row['inputs'].items():
  if '/tmp/mask-ins-simplify/' in i['path']:continue
  p=Path(i['path']);src=repo/(n.split('.')[-1]+'.lean');assert i['before']==i['after']==h(p);deps[n]={'object':str(p),'object_sha256':h(p),'source':str(src),'source_sha256':h(src),'matching_prior_rows':[]}
files=[]
for d in ['/tmp/seam-sharing','/tmp/outer-seed-bound-sharing','/dev/shm/claude-transport-sharing','/tmp/positive-shift-sharing/source-clean']:
 files.extend(Path(d).glob('*.json'))
def walk(v):
 if isinstance(v,dict):
  yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
for p in files:
 try:data=json.loads(p.read_text())
 except Exception:continue
 for row in walk(data):
  sv={str(x) for x in row.values() if isinstance(x,(str,int))}
  for n,d in deps.items():
   if d['object_sha256'] in sv and d['source_sha256'] in sv:
    d['matching_prior_rows'].append({'file':str(p),'row_module':row.get('module',row.get('name')),'status':row.get('status'),'kind':row.get('kind',row.get('provenance',row.get('matches'))),'phase':row.get('phase')})
for n,d in deps.items():
 print(n,d['object_sha256'],d['source_sha256'],len(d['matching_prior_rows']))
 for m in d['matching_prior_rows'][:8]:print(' ',m)
(R/'independent-direct-provider-audit.json').write_text(json.dumps(deps,indent=2)+'\n')
