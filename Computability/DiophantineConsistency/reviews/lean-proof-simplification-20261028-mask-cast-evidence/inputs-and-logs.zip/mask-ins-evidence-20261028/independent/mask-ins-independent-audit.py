from pathlib import Path
import json,hashlib,re
r=Path('/tmp/mask-ins-simplify');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
for x in json.loads((r/'records.json').read_text()):
 assert x['status']==0 and x['before']==x['after']==H(x['source']); o=Path(x['cmd'][-1]);log=r/f"{x['phase']}-{x['name']}.log";assert x['object_sha256']==H(o) and x['log_sha256']==H(log)
 if x['phase']=='baseline' or x['name']!='ArithmeticMaskConstants':assert x['before']==H(repo/(x['name']+'.lean'))
 for name,d in x['inputs'].items():
  rel=name.replace('.','/')+'.olean'; first=next(Path(y)/rel for y in x['LEAN_PATH'].split(':') if (Path(y)/rel).is_file());assert str(first.resolve())==d['path'] and d['before']==d['after']==H(first)
 print('build',x['phase'],x['name'],len(x['inputs']),'inputs ok')
for x in json.loads((r/'census-records.json').read_text()):
 assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['direct_before']==x['direct_after']==H(x['direct_object']) and x['log_sha256']==H(r/f"{x['phase']}-{x['name']}.log")
 print('probe',x['phase'],x['name'],'pinned WindowInterface ok')
for x in json.loads((r/'endpoint-reprobe-records.json').read_text()):
 assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['log_sha256']==H(r/f"{x['phase']}-endpoint-reprobe.log")
 for name,d in x['inputs'].items():
  rel=name.replace('.','/')+'.olean';first=next(Path(y)/rel for y in x['LEAN_PATH'].split(':') if (Path(y)/rel).is_file());assert str(first.resolve())==d['path'] and d['before']==d['after']==H(first)
 assert len(x['inputs'])==2
 print('reprobe',x['phase'],'2 direct inputs ok')
for n in ['names','interfaces','private','endpoint-reprobe']:
 assert (r/f'baseline-{n}.log').read_bytes()==(r/f'final-{n}.log').read_bytes();print(n,'equal')
