import DiophantineConsistency.ArithmeticSaturation
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticSaturation).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticSaturation" then
   logInfo m!"DECL {n}"
