from pathlib import Path
import hashlib,json
R=Path('/tmp/saturation-order-simplify');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
bc=next(x for x in load('/tmp/binary-carry-simplify/final-records.json') if x['module']=='ArithmeticBinaryCarry');assert bc['status']==0 and bc['before']==bc['after']==h(W/'ArithmeticBinaryCarry.lean') and bc['object_sha256']==h(bc['object'])
wc=load('/tmp/window-carry-tail/final-records.json'); prior=wc[1]; assert wc[0]['status']==0 and wc[0]['before']==wc[0]['after']==h(W/'ArithmeticWindowCarry.lean') and wc[0]['object_sha256']==h(wc[0]['object'])
prior2=load('/tmp/window-rem-bound/final-records.json')[0];wd=load('/tmp/window-digit-replace/final-records.json');refs=prior2['direct_inputs'];records={p:load(R/f'{p}-records.json') for p in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticSaturation','ArithmeticWindowInterface']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log'])
  if ph=='baseline' or x['module']!='ArithmeticSaturation':assert x['before']==h(W/f"{x['module']}.lean")
  for d in x['direct_inputs']:
   assert d['before']==d['after']==h(d['path']);name=d['module'].split('.')[-1]
   if name=='ArithmeticBinaryCarry':assert d['before']==bc['object_sha256']
   elif name=='ArithmeticSaturation':assert d['before']==rr[0]['object_sha256']
   elif name=='ArithmeticWindowCarry':assert d['before']==wc[0]['object_sha256']
   elif name=='ArithmeticWindowBits':
    q=next(q for q in wd if q['module']==name);assert q['status']==0 and q['before']==q['after']==h(W/f'{name}.lean') and d['before']==q['object_sha256']
   else:
    q=next(q for q in refs if q['module']==d['module']);assert d['before']==q['object_before']==q['object_after'] and q['source_before']==q['source_after']==h(W/f'{name}.lean')
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=load(R/'client-probe2-records.json');assert len(rows)==8
for x in rows:assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[q['object_sha256'] for q in records[x['phase']]] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-client2-{n}.log').read_bytes()==(R/f'final-client2-{n}.log').read_bytes()
print('PASS current-source BinaryCarry, WindowCarry and WindowBits providers, paired target/client and probes')
