ArithmeticSaturation order proofs: isolated simplification

Baseline source SHA-256 7266d2c22e3ff0ec760207fd1e3b90af86220239338c6b98a174cf7906037451;
final source SHA-256 7a1a5cd8ff6b2bac9f2dc7fb98211ab0958143eb9dd67318a90a221949f6c964.
The private eq_of_sum_le proof replaces a contradiction with monotonicity and
additive cancellation; four_block derives F+alpha<q directly from hgap via
positive subtraction after the same tsub_tsub rewrite. All original statements,
guards, imports, definitions and data are unchanged; the diff is 3 additions,
7 deletions. The module's original commit 5fcd5632b3b753237437f22904b899653f69916b
includes Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>.

baseline/final-records.json contain successful source and direct object-pinned
builds of the target and sole direct source client ArithmeticWindowInterface.
The target imports BinaryCarry built from current source in
/tmp/binary-carry-simplify/final-records.json. The client's direct WindowCarry
object is from the freshly checked final build in /tmp/window-carry-tail/
final-records.json and its WindowBits object from /tmp/window-digit-replace/
final-records.json; the other three client provider source/object pairs match
/tmp/window-rem-bound/final-records.json. audit.py/.log verify source and object
matches, paired target/client builds and probe pins. Sources of imported modules
are matched via prior receipts rather than captured before/after by these builds.
This does not establish a rebuilt transitive closure: Mathlib and other project,
BusyBeaver, and Foundation dependencies are cached.

Single baseline/final user CPU samples under shared load: target 3.52/3.33s,
client 6.81/6.58s. Client output objects are byte-identical
(eadcc1cf8adcd2e4f8ef6624dacc61b7936334c4bc31218ff57f7284c44c3084).
The four target namespace names (including private/generated declarations) and
type/axiom reports, 28,971 default simp entries, and 13,167 instance entries
match. The 43 client names and type/axiom reports, and 35,447 simp and 15,617
instance entries match; client probes pin both target and client objects before
and after. These censuses do not check every persistent extension or proof body.
Neither phase produced target or client warnings.

The first standalone probe failed due to add_le_add_left's orientation; its
exact source and diagnostic are retained in probe-failed.lean/.log. The fixed
probe.lean/.log passes. These exploratory runs lack before/after input receipts;
the paired builds are the validated result.

ArithmeticBinaryPopulation is a cached transitive dependency currently being
separately prototyped. A post-build sample of both recorded search paths resolves
its object to cde612c937717935b708e09e94533a94e4484b094b2d8f13f687489df45a3dab,
WindowDigits to 0f3f34a4d89aaa435f9b16cd53d4f77528f8fa0d825004242c24a83740d131c2,
and PellRecurrence to 7f88b2f434d384e7d6e32e10e242f11a1146f460896aabddbc238e077311a5cc.
These are path samples, not before/after pins proving what transitive bytes were
loaded; a coherent combined replay is needed if BinaryPopulation changes.
The cde612… BinaryPopulation object has an earlier current-source build receipt
in /tmp/binary-half-reuse-20261028/final-targets.json; it is also pinned as a
direct input of the earlier BinaryCarry build. That historical chain and this
experiment's post-build path sample still do not make it a contemporaneous
transitive input pin for these Saturation or client builds.
