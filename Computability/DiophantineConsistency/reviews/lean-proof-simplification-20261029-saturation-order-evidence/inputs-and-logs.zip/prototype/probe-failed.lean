import DiophantineConsistency.ArithmeticSaturation
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example {a b c d : V} (hab : a ≤ b) (hcd : c ≤ d) (h : b + d ≤ a + c) : a = b := by
  exact le_antisymm hab (le_of_add_le_add_right (le_trans (add_le_add_left hcd b) h))
example (q F alpha : V) (hgap : 0 < q - F - alpha) : F + alpha < q := by
  rw [tsub_tsub] at hgap
  exact tsub_pos_iff_lt.mp hgap
