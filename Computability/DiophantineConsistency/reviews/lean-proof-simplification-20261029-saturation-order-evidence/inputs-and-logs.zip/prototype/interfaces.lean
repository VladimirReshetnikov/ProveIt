import DiophantineConsistency.ArithmeticSaturation
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticSaturation).isPrefixOf n ||
       (toString n).startsWith "_private.DiophantineConsistency.ArithmeticSaturation" then
      let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let ax ← Lean.collectAxioms n
      logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
