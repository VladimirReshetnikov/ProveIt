from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs'); R=Path('/tmp/saturation-order-simplify')
D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-saturation-order-evidence'; D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest(); items={}
def add(n,p): assert n not in items; items[n]=Path(p).read_bytes()
def git(p,rev): return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=ROOT)
rev='e9b2cb4040d7b203ab1643ec45408225c47757d0';parent='f3d25aabb92f28b07e9e33356007f37cc8ec4610';mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
items['commit/baseline.lean']=git(mod+'ArithmeticSaturation.lean',parent);items['commit/final.lean']=git(mod+'ArithmeticSaturation.lean',rev)
for phase,name in [('baseline','baseline'),('final','final')]:assert items['commit/'+name+'.lean']==(R/phase/'DiophantineConsistency/ArithmeticSaturation.lean').read_bytes()
for n in ['ArithmeticBinaryPopulation','ArithmeticBinaryCarry','ArithmeticWindowCarry','ArithmeticWindowBits','ArithmeticWindowInterface','ArithmeticCarrierRadix2011','ArithmeticMaskConstants','ArithmeticMaskPopulation']:
 items['provider-sources/'+n+'.lean']=git(mod+n+'.lean',rev)
for f in sorted(R.rglob('*')):
 if f.is_file() and not any(x.startswith('objects-') for x in f.relative_to(R).parts):add('prototype/'+f.relative_to(R).as_posix(),f)
for n,p in {
 'prior/binary-population-final-targets.json':'/tmp/binary-half-reuse-20261028/final-targets.json',
 'prior/binary-carry-final-records.json':'/tmp/binary-carry-simplify/final-records.json',
 'prior/window-carry-final-records.json':'/tmp/window-carry-tail/final-records.json',
 'prior/window-digit-final-records.json':'/tmp/window-digit-replace/final-records.json',
 'prior/window-rem-final-records.json':'/tmp/window-rem-bound/final-records.json',
 'prior/positive-shift-source-clean-records.json':'/tmp/positive-shift-sharing/source-clean/records.json',
 'prior/mask-constants-records.json':'/tmp/mask-ins-simplify/records.json',
 'prior/mask-population-assembly-records.json':'/tmp/outer-seed-bound-sharing/assembly-builds2.json',
 'independent/review.txt':'/tmp/saturation-order-peer-review.txt',
 'independent/audit.py':'/tmp/saturation-order-peer-audit.py',
 'independent/audit.log':'/tmp/saturation-order-peer-audit.log',
 'bundle/build-bundle.py':'/tmp/build-saturation-order-bundle.py'}.items():add(n,p)
zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):
  info=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Simplify two ArithmeticSaturation order arguments using cancellation and positive subtraction',
'validation':'Paired target and sole tracked Lean direct client WindowInterface builds pass with pinned direct inputs; client output bytes match. Both target and client declaration/type/axiom and default simp/instance reports match; client probes pin both target and client. Direct project provider source/object pairs map to prior receipts.',
'limitations':['The wider project, BusyBeaver, Foundation and Mathlib transitive closure remains cached and was not rebuilt from current source.', 'The previous BinaryCarry build directly pinned BinaryPopulation cde612… from a source-matched prior build; in this experiment that object was sampled from the current search path only after builds, not pinned contemporaneously. An independently proposed BinaryPopulation change requires a coherent combined replay if adopted.', 'One shared-load paired timing sample does not establish general performance. Declaration and registration reports do not establish proof-body or all persistent-extension equality.', 'The initial failed standalone ordering probe and fixed probe are retained but lack complete contemporaneous before/after input and output pin receipts; subsequent paired builds establish the validated result.', 'Compiled objects are omitted; receipts preserve hashes and first-provider paths, and independent object byte checks require external objects.'],
'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(items)
 for n,b in items.items():assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes();print(n,sha(b),len(b))
