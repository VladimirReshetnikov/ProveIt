from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/saturation-order-simplify'); W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticSaturation.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticSaturation.lean').read_text()
a='''  apply le_antisymm hab
  by_contra hn
  have := add_lt_add_of_lt_of_le (lt_of_not_ge hn) hcd
  exact absurd h (not_le.mpr this)''';aa='''  exact le_antisymm hab (le_of_add_le_add_right (le_trans ((add_le_add_iff_left b).mpr hcd) h))'''
c='''    by_contra hn
    rw [tsub_tsub, tsub_eq_zero_of_le (le_of_not_gt hn)] at hgap
    exact _root_.lt_irrefl _ hgap''';cc='''    rw [tsub_tsub] at hgap
    exact tsub_pos_iff_lt.mp hgap'''
assert b.count(a)==b.count(c)==1 and b.replace(a,aa).replace(c,cc)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticSaturation.lean'
def gitfile(rev): return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('e9b2cb4040^')==b and gitfile('e9b2cb4040')==f and (W/'ArithmeticSaturation.lean').read_text()==f
print('PASS exact two-block diff, commit and parent snapshots; workspace equals final')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticSaturation$', '--','*.lean'],text=True).splitlines()
assert clients==['Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWindowInterface.lean'],clients
print('PASS sole tracked Lean direct client',clients)
rec={p:read(R/f'{p}-records.json') for p in ('baseline','final')}
prior=read('/tmp/window-rem-bound/final-records.json')[0]; wd=read('/tmp/window-digit-replace/final-records.json'); wc=read('/tmp/window-carry-tail/final-records.json')[0]; bc=next(x for x in read('/tmp/binary-carry-simplify/final-records.json') if x['module']=='ArithmeticBinaryCarry')
assert bc['status']==0 and bc['before']==bc['after']==sha(W/'ArithmeticBinaryCarry.lean') and bc['object_sha256']==sha(bc['object'])
assert wc['status']==0 and wc['before']==wc['after']==sha(W/'ArithmeticWindowCarry.lean') and wc['object_sha256']==sha(wc['object'])
wb=next(x for x in wd if x['module']=='ArithmeticWindowBits');assert wb['status']==0 and wb['before']==wb['after']==sha(W/'ArithmeticWindowBits.lean') and wb['object_sha256']==sha(wb['object'])
for phase,rr in rec.items():
 assert [x['module'] for x in rr]==['ArithmeticSaturation','ArithmeticWindowInterface']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==sha(x['source']) and x['object_sha256']==sha(x['object']) and x['log_sha256']==sha(x['log'])
  assert Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticSaturation':assert x['before']==sha(W/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   first=next((Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file()),None)
   assert first==Path(d['path']) and first.resolve()==Path(d['resolved']) and d['before']==d['after']==sha(first)
   mod=d['module'].split('.')[-1]
   if mod=='ArithmeticBinaryCarry':assert d['before']==bc['object_sha256']
   elif mod=='ArithmeticSaturation':assert d['before']==rr[0]['object_sha256']
   elif mod=='ArithmeticWindowCarry':assert d['before']==wc['object_sha256']
   elif mod=='ArithmeticWindowBits':assert d['before']==wb['object_sha256']
   else:
    q=next(q for q in prior['direct_inputs'] if q['module']==d['module']);assert d['before']==q['object_before']==q['object_after'] and q['source_before']==q['source_after']==sha(W/(mod+'.lean'))
  print('PASS build',phase,x['module'],x['time'].strip(),'object',x['object_sha256'])
assert rec['baseline'][1]['object_sha256']==rec['final'][1]['object_sha256']
print('PASS direct source/object pairs and identical client objects')
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json'); assert x['status']==0 and x['source_before']==x['source_after']==sha(x['source']) and x['object_before']==x['object_after']==sha(x['object'])==rec[phase][0]['object_sha256'] and x['log_sha256']==sha(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=read(R/'client-probe2-records.json');assert len(rows)==8
for x in rows:
 assert x['status']==0 and x['source_before']==x['source_after']==sha(x['source']) and x['objects_before']==x['objects_after']==[sha(q) for q in x['objects']]==[q['object_sha256'] for q in rec[x['phase']]] and x['log_sha256']==sha(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-client2-{n}.log').read_bytes()==(R/f'final-client2-{n}.log').read_bytes()
print('PASS paired target and both-object-pinned client reports')
pop=next(x for x in read('/tmp/binary-half-reuse-20261028/final-targets.json') if x.get('tag')=='ArithmeticBinaryPopulation')
assert pop['status']==0 and pop['source_sha256']==sha(W/'ArithmeticBinaryPopulation.lean')
assert bc['direct_inputs'][0]['before']==bc['direct_inputs'][0]['after']==pop['object_sha256']
for phase in ('baseline','final'):
 x=rec[phase][0]; first=next(Path(z)/'DiophantineConsistency/ArithmeticBinaryPopulation.olean' for z in x['LEAN_PATH'].split(':') if (Path(z)/'DiophantineConsistency/ArithmeticBinaryPopulation.olean').is_file())
 assert sha(first)==pop['object_sha256']; print('PASS post-build search-path sample',phase,first.resolve(),pop['object_sha256'])
print('PASS prior BinaryCarry receipt Population input and current-source prior Population object')
print('LIMIT cached transitive closure, BinaryPopulation was not pinned during these builds; no combined isolated BinaryPopulation candidate replay')
