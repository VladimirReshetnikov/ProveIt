from pathlib import Path
import hashlib,json,re,gzip,subprocess
P=Path('/dev/shm/beta-int-sharing'); repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
scope=json.loads((P/'scope.json').read_text()); total=0
for name,count in scope['files']:
 old=(P/'baseline/DiophantineConsistency'/f'{name}.lean').read_text(); new=(P/'final/DiophantineConsistency'/f'{name}.lean').read_text(); assert new==(repo/f'{name}.lean').read_text()
 rel=str(repo/f'{name}.lean')
 assert subprocess.check_output(['git','show','ca3ebb3033^:'+rel]).decode()==old
 assert subprocess.check_output(['git','show','ca3ebb3033:'+rel]).decode()==new
 if name=='CurrentMasks2011':
  added='theorem beta_pos_int : (0 : ℤ) < (beta : ℤ) := by\n  exact_mod_cast beta_pos\n\n';assert new.replace(added,'',1)==old;continue
 pattern=r'(^\s*have hb : [^\n]+ :=) by\n\s*change [^\n]+\n\s*exact_mod_cast (?:CurrentMasks2011\.)?beta_pos'
 expected,c=re.subn(pattern,r'\1 CurrentMasks2011.beta_pos_int',old,flags=re.M)
 expected,c2=re.subn(r'(^\s*have hb : [^\n]+ :=) by exact_mod_cast beta_pos',r'\1 CurrentMasks2011.beta_pos_int',expected,flags=re.M)
 expected,c3=re.subn(r'(^\s*)exact_mod_cast CurrentMasks2011.beta_pos',r'\1exact CurrentMasks2011.beta_pos_int',expected,flags=re.M)
 assert c+c2+c3==count,(name,c,c2,c3,count)
 assert expected==new,name
 total+=count
assert total==19
print('16 changed sources: only beta positivity helper and 19 exact cast-proof substitutions')
sets={}
for phase in ['baseline','final']:
 for suffix in ['-records.json','-client-records.json','-production-records.json']:
  rows=json.loads((P/(phase+suffix)).read_text()); valid=[r for r in rows if r['status']==0]; sets[phase+suffix]=valid
  for r in valid:
   assert r['before']==r['after']==h(r['source']) and r['object_sha256']==h(r['object']) and r['log_sha256']==h(r['log']) and Path(r['command'][2]).read_text()==r['time']
   for d in r['direct_inputs']:
    assert d['before']==d['after']==h(d['path'])
    if d.get('source_before'):assert d['source_before']==d['source_after']==h(d['source'])
    first=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in r['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).exists()); assert first.resolve()==Path(d['path']).resolve()
  print(phase+suffix,len(valid),'successful source, output, first direct input, log/time records verified')
for phase in ['baseline','final']:
 for suffix in ['-records.json','-client-records.json','-production-records.json']:
  names=[r['module'] for r in sets[phase+suffix]];assert len(names)==len(set(names))
for suffix in ['-client-records.json','-production-records.json']:
 a={r['module']:r for r in sets['baseline'+suffix]};b={r['module']:r for r in sets['final'+suffix]}; assert a.keys()==b.keys()
 print(suffix,'identical byte objects',sum(a[n]['object_sha256']==b[n]['object_sha256'] for n in a),'of',len(a))
for suffix in ['census','client-census']:
 records=json.loads((P/(suffix+'-records.json')).read_text()); assert len(records)==2
 for r in records:
  assert r['status']==0 and r['source_sha256']==h(r['source']) and r['objects_before']==r['objects_after']==[h(q) for q in r['objects']] and r['log_sha256']==h(r['log'])
  assert r['raw_log_sha256']==hashlib.sha256(gzip.open(r['log'],'rb').read()).hexdigest()
 print(suffix,'source, object pins, logs and raw logs match')
print('PASS')
def census_blocks(path):
 s=gzip.open(path,'rt').read(); out={k:{} for k in ['DECL','SIMP','INSTANCE']}
 for chunk in re.split(r'(?=^(?:DECL|SIMP|INSTANCE) )',s,flags=re.M):
  chunk=chunk.strip()
  if not chunk:continue
  typ=chunk.split(' ',1)[0];assert typ in out
  key=re.match(r'^DECL (\S+) (\S+) TYPE ',chunk).group(2) if typ=='DECL' else chunk.split(' ',2)[1]
  assert key not in out[typ];out[typ][key]=chunk
 return out
for kind in ['census','client-census']:
 a=census_blocks(P/f'baseline-{kind}.log.gz');b=census_blocks(P/f'final-{kind}.log.gz'); expected=json.loads((P/f'{kind}-diff.json').read_text())
 for k in a:
  x,y=set(a[k]),set(b[k]);v={'baseline_count':len(x),'final_count':len(y),'removed':sorted(x-y),'added':sorted(y-x),'changed_common':sorted(n for n in x&y if a[k][n]!=b[k][n]),'common_count':len(x&y)};assert v==expected[k]
  if k in ['SIMP','INSTANCE']: assert not v['removed'] and not v['added'] and not v['changed_common']
 if kind=='census':assert expected['DECL']['added']==['DiophantineConsistency.CurrentMasks2011.beta_pos_int'] and not expected['DECL']['removed'] and not expected['DECL']['changed_common']
 else:assert not expected['DECL']['added'] and not expected['DECL']['removed'] and not expected['DECL']['changed_common']
 print(kind,'independent set/type/axiom comparison matches recorded diff')
for r in json.loads((P/'client-census-records.json').read_text()):assert len(r['objects'])==22
print('Differing-client census pins all 16 changed targets and six clients per phase')
producers=json.loads((P/'producer-search.json').read_text());assert len(producers)==26
unmatched=[]
for item in producers:
 assert item['before']==item['after']==h(item['path']) and item['source_before']==item['source_after']==h(item['source'])
 name=item['module'].split('.')[-1]
 if not item['matching_producers']:unmatched.append(name);continue
 ok=[]
 for candidate in item['matching_producers']:
  path=Path(candidate['file']); data=json.loads(path.read_text());matches=[]
  def walk(x):
   if isinstance(x,list):
    for v in x:walk(v)
   elif isinstance(x,dict):
    mod=str(x.get('module',x.get('name',''))).split('.')[-1]
    src=x.get('source_sha256_before',x.get('source_sha256',x.get('source_before',x.get('before'))))
    if mod==name and x.get('status')==0 and x.get('object_sha256')==item['before'] and src==item['source_before']:matches.append(x)
    for v in x.values():walk(v)
  walk(data)
  if matches:ok.append(str(path))
 assert ok,(name,candidate)
print('14 external source/object producer matches independently reproduced; 12 unmatched:',', '.join(unmatched))
changed={n for n,c in scope['files']}
for suffix in ['-records.json','-client-records.json','-production-records.json']:
 a={r['module']:r for r in sets['baseline'+suffix]};b={r['module']:r for r in sets['final'+suffix]};assert a.keys()==b.keys()
 for n in a:
  x={d['module']:d for d in a[n]['direct_inputs']};y={d['module']:d for d in b[n]['direct_inputs']};assert x.keys()==y.keys()
  for m in x:
   if x[m]['before']!=y[m]['before']:assert m.split('.')[-1] in changed,(n,m)
print('All differing paired direct inputs belong to changed modules')
for r in json.loads((P/'initial-baseline-records.json').read_text()):
 if r['status']!=0:
  assert h(P/('initial-baseline-'+r['module']+'.log'))==r['log_sha256']
print('Three initial baseline missing-object failure logs preserved at distinct paths')
replay={}
for phase in ['baseline','final']:
 rows=json.loads((P/f'replay-{phase}-records.json').read_text()); assert len(rows)==27;replay[phase]=rows
 for r in rows:
  assert r['status']==0 and r['before']==r['after']==h(r['source']) and r['object_sha256']==h(r['object']) and r['log_sha256']==h(r['log']) and Path(r['command'][2]).read_text()==r['time']
  for d in r['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d.get('source_before'):assert d['source_before']==d['source_after']==h(d['source'])
   fn=d['module'].replace('.','/')+'.olean';first=next(Path(q)/fn for q in r['LEAN_PATH'].split(':') if (Path(q)/fn).exists());assert first.resolve()==Path(d['path']).resolve()
 old={r['module']:r for suffix in ['-records.json','-client-records.json','-production-records.json'] for r in sets[phase+suffix]}
 diffs=[r['module'] for r in rows if r['module'] in old and r['object_sha256']!=old[r['module']]['object_sha256']];assert len(diffs)==12
 provider=next(d for r in rows for d in r['direct_inputs'] if d['module'].endswith('.NativePositiveSourceConstruction'))
 prior=next(r for r in json.loads(Path('/tmp/current-packing-positive-sharing/refresh3-records.json').read_text()) if r['module'].endswith('NativePositiveSourceConstruction'))
 assert prior['status']==0 and prior['object_sha256']==provider['before'] and prior.get('source_sha256',prior.get('before'))==provider['source_before']
 print('replay',phase,'27 builds pinned; 12 object hashes differ from original phase; NativePositive producer matched')
print('REPLAY PASS')
for kind,count in [('replay-census',18),('replay-client-census',24)]:
 records=json.loads((P/f'{kind}-records.json').read_text());assert len(records)==2
 for r in records:
  assert r['status']==0 and len(r['objects'])==count and r['source_sha256']==h(r['source']) and r['objects_before']==r['objects_after']==[h(q) for q in r['objects']] and r['log_sha256']==h(r['log'])
  assert r['raw_log_sha256']==hashlib.sha256(gzip.open(r['log'],'rb').read()).hexdigest()
  objects={Path(q).stem for q in r['objects']};assert changed<=objects and {'NativePositiveSourceConstruction','Carrier66Source'}<=objects
  if count==24:assert {'ThirteenFirstNormCorrection92Checks','ThirteenLVCarrierChecks','ThirteenScaledNormSyzygy86Checks','ThirteenSecondFirstNormCorrectionsChecks','ThirteenUnitSphere96Checks','CurrentMaskRecipes2011'}<=objects
 marker='-census' if kind=='replay-census' else '-client-census'
 a=census_blocks(P/f'replay-baseline{marker}.log.gz');b=census_blocks(P/f'replay-final{marker}.log.gz');expected=json.loads((P/f'{kind}-diff.json').read_text())
 for k in a:
  x,y=set(a[k]),set(b[k]);v={'baseline_count':len(x),'final_count':len(y),'removed':sorted(x-y),'added':sorted(y-x),'changed_common':sorted(n for n in x&y if a[k][n]!=b[k][n]),'common_count':len(x&y)};assert v==expected[k]
  if k in ['SIMP','INSTANCE']:assert not v['removed'] and not v['added'] and not v['changed_common']
 if count==18:assert expected['DECL']['added']==['DiophantineConsistency.CurrentMasks2011.beta_pos_int'] and not expected['DECL']['removed'] and not expected['DECL']['changed_common']
 else: assert not expected['DECL']['added'] and not expected['DECL']['removed'] and not expected['DECL']['changed_common']
 print(kind,count,'object pins, raw logs and independently reconstructed comparisons pass')
print('ALL REPLAY CENSUS PASS')

print('Commit ca3ebb3033 and parent match all 16 final and baseline source snapshots')
