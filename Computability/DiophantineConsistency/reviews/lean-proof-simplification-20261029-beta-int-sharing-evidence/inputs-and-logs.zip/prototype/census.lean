import Lean.Elab.Command
import Lean.Util.CollectAxioms
import DiophantineConsistency.CarrierNonzeroSpheres
import DiophantineConsistency.CarrierNormalizedProduct106
import DiophantineConsistency.CarrierScaledAuxiliary118
import DiophantineConsistency.CurrentCarrierArithmetic2011
import DiophantineConsistency.CurrentCarrierArithmetic2011Checks
import DiophantineConsistency.CurrentMasks2011
import DiophantineConsistency.CurrentPositiveZero2011
import DiophantineConsistency.NativeOrdinarySourceConstruction
import DiophantineConsistency.ThirteenCorrectedStrong
import DiophantineConsistency.ThirteenFirstNormCorrection92
import DiophantineConsistency.ThirteenGroupedSquares96
import DiophantineConsistency.ThirteenGroupedSquares96Checks
import DiophantineConsistency.ThirteenLVCarrier
import DiophantineConsistency.ThirteenScaledNormSyzygy86
import DiophantineConsistency.ThirteenSecondFirstNormCorrections
import DiophantineConsistency.ThirteenUnitSphere96
open Lean Elab Command
run_cmd do
 let env ← getEnv
 let st ← liftCoreM Lean.Meta.getSimpTheorems
 let targets : List Name := [`DiophantineConsistency.CarrierNonzeroSpheres, `DiophantineConsistency.CarrierNormalizedProduct106, `DiophantineConsistency.CarrierScaledAuxiliary118, `DiophantineConsistency.CurrentCarrierArithmetic2011, `DiophantineConsistency.CurrentCarrierArithmetic2011Checks, `DiophantineConsistency.CurrentMasks2011, `DiophantineConsistency.CurrentPositiveZero2011, `DiophantineConsistency.NativeOrdinarySourceConstruction, `DiophantineConsistency.ThirteenCorrectedStrong, `DiophantineConsistency.ThirteenFirstNormCorrection92, `DiophantineConsistency.ThirteenGroupedSquares96, `DiophantineConsistency.ThirteenGroupedSquares96Checks, `DiophantineConsistency.ThirteenLVCarrier, `DiophantineConsistency.ThirteenScaledNormSyzygy86, `DiophantineConsistency.ThirteenSecondFirstNormCorrections, `DiophantineConsistency.ThirteenUnitSphere96]
 for (n, info) in env.constants.toList do
  if let some i := env.getModuleIdxFor? n then
   let mod := (env.header.modules[i.toNat]!).module
   if targets.contains mod then
    let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
    let ax ← Lean.collectAxioms n
    logInfo m!"DECL {mod} {n} TYPE {ty} AXIOMS {ax}"
  if st.isLemma (.decl n true false) || st.isLemma (.decl n false false) || st.isLemma (.decl n true true) || st.isLemma (.decl n false true) then
   logInfo m!"SIMP {n} {st.isLemma (.decl n true false)} {st.isLemma (.decl n false false)} {st.isLemma (.decl n true true)} {st.isLemma (.decl n false true)}"
  if Lean.Meta.isInstanceCore env n then
   let p ← liftCoreM <| Lean.Meta.getInstancePriority? n
   logInfo m!"INSTANCE {n} {p}"
