import Lean.Elab.Command
import Lean.Util.CollectAxioms
import DiophantineConsistency.ThirteenFirstNormCorrection92Checks
import DiophantineConsistency.ThirteenLVCarrierChecks
import DiophantineConsistency.ThirteenScaledNormSyzygy86Checks
import DiophantineConsistency.ThirteenSecondFirstNormCorrectionsChecks
import DiophantineConsistency.ThirteenUnitSphere96Checks
import DiophantineConsistency.CurrentMaskRecipes2011
open Lean Elab Command
run_cmd do
 let env ← getEnv
 let st ← liftCoreM Lean.Meta.getSimpTheorems
 let targets : List Name := [`DiophantineConsistency.ThirteenFirstNormCorrection92Checks, `DiophantineConsistency.ThirteenLVCarrierChecks, `DiophantineConsistency.ThirteenScaledNormSyzygy86Checks, `DiophantineConsistency.ThirteenSecondFirstNormCorrectionsChecks, `DiophantineConsistency.ThirteenUnitSphere96Checks, `DiophantineConsistency.CurrentMaskRecipes2011]
 for (n, info) in env.constants.toList do
  if let some i := env.getModuleIdxFor? n then
   let mod := (env.header.modules[i.toNat]!).module
   if targets.contains mod then
    let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
    let ax ← Lean.collectAxioms n
    logInfo m!"DECL {mod} {n} TYPE {ty} AXIOMS {ax}"
  if st.isLemma (.decl n true false) || st.isLemma (.decl n false false) || st.isLemma (.decl n true true) || st.isLemma (.decl n false true) then
   logInfo m!"SIMP {n} {st.isLemma (.decl n true false)} {st.isLemma (.decl n false false)} {st.isLemma (.decl n true true)} {st.isLemma (.decl n false true)}"
  if Lean.Meta.isInstanceCore env n then
   let p ← liftCoreM <| Lean.Meta.getInstancePriority? n
   logInfo m!"INSTANCE {n} {p}"
