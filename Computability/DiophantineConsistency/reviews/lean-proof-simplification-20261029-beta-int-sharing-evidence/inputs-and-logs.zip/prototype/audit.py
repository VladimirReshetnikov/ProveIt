from pathlib import Path
import hashlib,json
r=Path('/dev/shm/beta-int-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); J=lambda p:json.loads((r/p).read_text()); categories=['records','client-records','production-records']; data={}
for ph in ['baseline','final']:
 data[ph]={}
 for cat in categories:
  rows=J(f'{ph}-{cat}.json');ok={x['module']:x for x in rows if x['status']==0};data[ph].update(ok)
  for n,x in ok.items():
   assert x['before']==x['after']==h(x['source']),(ph,n,'source')
   assert h(x['object'])==x['object_sha256'],(ph,n,'object')
   assert h(x['log'])==x['log_sha256'],(ph,n,'log')
   for d in x['direct_inputs']:
    assert d['before']==d['after']==h(d['path']),(ph,n,d['module'],'object')
    if d['source']: assert d['source_before']==d['source_after']==h(d['source']),(ph,n,d['module'],'source')
  print(ph,cat,'successful',len(ok))
for n in data['baseline']:
 b=data['baseline'][n]; f=data['final'][n]
 assert [d['module'] for d in b['direct_inputs']]==[d['module'] for d in f['direct_inputs']]
 for x,y in zip(b['direct_inputs'],f['direct_inputs']):
  leaf=x['module'].split('.')[-1]
  if leaf not in data['baseline']: assert x['before']==y['before'] and x['source_before']==y['source_before'],(n,leaf)
for x in J('initial-baseline-records.json'):
 if x['status']!=0:
  n=x['module'];assert h(r/f'initial-baseline-{n}.log')==x['log_sha256']
for n in ['census','client-census']:
 for x in J(f'{n}-records.json'):
  assert x['status']==0 and x['objects_before']==x['objects_after']
  assert h(x['source'])==x['source_sha256'] and h(x['log'])==x['log_sha256']
  for p,sha in zip(x['objects'],x['objects_before']):assert h(p)==sha
 print(n,J(f'{n}-diff.json'))
print('all checks passed')
for ph in ['baseline','final']:
 rows=J(f'replay-{ph}-records.json');assert len(rows)==27
 for x in rows:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'],(ph,n)
  for d in x['direct_inputs']:
   assert d['before']==d['after']==h(d['path']),(ph,n,d['module'])
   if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
  if n=='CurrentPositiveZero2011':
   p=next(d for d in x['direct_inputs'] if d['module']=='DiophantineConsistency.NativePositiveSourceConstruction')
   assert p['before']=='8f764c39d545f79988b1c74961ce194aaeb201f04b5cfb269f3962c94cab97ef'
 print(ph,'fresh-provider replay',len(rows),'passed')
for n in ['replay-census','replay-client-census']:
 for x in J(f'{n}-records.json'):
  assert x['status']==0 and x['objects_before']==x['objects_after'] and h(x['source'])==x['source_sha256'] and h(x['log'])==x['log_sha256']
  for p,sha in zip(x['objects'],x['objects_before']):assert h(p)==sha
 print(n,J(f'{n}-diff.json'))
print('refreshed audit passed')
