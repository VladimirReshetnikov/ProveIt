from pathlib import Path
import re, shutil, json, subprocess
root=Path('Computability/DiophantineConsistency/Lean')
base=Path('/dev/shm/beta-int-sharing')
pat=re.compile(r'(?m)^([ \t]*)have hb : ([^\n]+) := by\n\1  change[^\n]*\n\1  exact_mod_cast (?:CurrentMasks2011\.)?beta_pos\b')
files=[]
for p in sorted((root/'DiophantineConsistency').glob('*.lean')):
 s=p.read_text(); n=len(re.findall(r'exact_mod_cast (?:CurrentMasks2011\.)?beta_pos\b',s))
 if not n and p.name!='CurrentMasks2011.lean': continue
 t=s
 if p.name=='CurrentMasks2011.lean':
  needle='theorem lowPort_lt : lowPort < beta := by'
  assert t.count(needle)==1
  t=t.replace(needle,'theorem beta_pos_int : (0 : ℤ) < (beta : ℤ) := by\n  exact_mod_cast beta_pos\n\n'+needle)
 else:
  t,c=pat.subn(lambda m: f'{m[1]}have hb : {m[2]} := CurrentMasks2011.beta_pos_int',t)
  x='have hb : 0 < (beta : ℤ) := by exact_mod_cast beta_pos'
  if x in t: t=t.replace(x,'have hb : 0 < (beta : ℤ) := CurrentMasks2011.beta_pos_int'); c+=1
  if p.name=='ThirteenGroupedSquares96Checks.lean':
   x='exact_mod_cast CurrentMasks2011.beta_pos'; assert t.count(x)==1
   t=t.replace(x,'exact CurrentMasks2011.beta_pos_int'); c+=1
  assert c==n,(p,c,n)
 for phase,content in [('baseline',s),('final',t)]:
  q=base/phase/p.relative_to(root); q.parent.mkdir(parents=True,exist_ok=True); q.write_text(content)
 files.append((p.stem,n))
allfiles=list(root.rglob('*.lean')); graph={}
for p in allfiles:
 module='.'.join(p.relative_to(root).with_suffix('').parts)
 graph[module]=re.findall(r'^import\s+([^\s]+)',p.read_text(),re.M)
changed={f'DiophantineConsistency.{n}' for n,_ in files}
clients={x:sorted(k for k,v in graph.items() if x in v) for x in sorted(changed)}
external=sorted({k for x,vs in clients.items() for k in vs if k not in changed})
(base/'scope.json').write_text(json.dumps({'files':files,'direct_clients':clients,'external_direct_clients':external},indent=2)+'\n')
print('files',len(files),'casts',sum(n for _,n in files),'direct client external',len(external))
for p,n in files: print(p,n)
print('external direct clients:')
print('\n'.join(external))
