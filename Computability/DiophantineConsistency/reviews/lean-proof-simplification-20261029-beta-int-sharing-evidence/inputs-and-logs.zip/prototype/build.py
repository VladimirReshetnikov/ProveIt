from pathlib import Path
import os,json,hashlib,subprocess,sys,re,shutil
r=Path('/dev/shm/beta-int-sharing');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();phase=sys.argv[1];assert phase in ('baseline','final')
scope=json.loads((r/'scope.json').read_text()); names=[n for n,c in scope['files']]+json.loads((r/'extra-names.json').read_text())
graph={n:re.findall(r'^import\s+DiophantineConsistency\.([^\s]+)',(r/phase/'DiophantineConsistency'/f'{n}.lean').read_text(),re.M) for n in names}
allgraph={p.stem:re.findall(r'^import\s+DiophantineConsistency\.([^\s]+)',p.read_text(),re.M) for p in w.glob('*.lean')}
def closure(n):
 seen=set();todo=list(allgraph.get(n,[]))
 while todo:
  x=todo.pop()
  if x not in seen:seen.add(x);todo.extend(allgraph.get(x,[]))
 return seen
graph={n:sorted(set(names)&closure(n)) for n in names}
order=[]
while len(order)<len(names):
 nxt=sorted(n for n in names if n not in order and all(d not in names or d in order for d in graph[n]));assert nxt,graph
 order.extend(nxt)
lib=r/('objects-'+phase);lib.mkdir(exist_ok=True); (subprocess.run(['cp','-as','/tmp/mask-ins-construction/final/DiophantineConsistency',str(lib/'DiophantineConsistency')],check=True) if not (lib/'DiophantineConsistency').exists() else None)
for n in names:
 p=lib/'DiophantineConsistency'/f'{n}.olean'
 if p.is_symlink():p.unlink()
env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+json.load(open('/tmp/four-positive-wrappers/upstream-records.json'))[0]['LEAN_PATH']; recordfile=r/f'{phase}-records.json'; rows=json.loads(recordfile.read_text()) if recordfile.exists() else []; succeeded={a['module'] for a in rows if a['status']==0}; skipped=[]
for n in order:
 if n in succeeded:continue
 blocked=[d for d in graph[n] if d in names and d not in succeeded]
 if blocked:
  skipped.append({'module':n,'blocked_by':blocked});print('BLOCKED',n,blocked,flush=True);continue
 src=r/phase/'DiophantineConsistency'/f'{n}.lean'; inputs=[]
 for name in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=name.replace('.','/')+'.olean';p=next((Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file()),None)
  if p is None: print('MISSING',n,name,flush=True);skipped.append({'module':n,'missing':name});break
  leaf=name.split('.')[-1];sp=r/phase/'DiophantineConsistency'/f'{leaf}.lean' if leaf in names else w/f'{leaf}.lean';inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 if len(inputs)!=len(re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M)):continue
 out=lib/'DiophantineConsistency'/f'{n}.olean';tm=r/f'{phase}-{n}.time';log=r/f'{phase}-{n}.log';before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/phase),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'phase':phase,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};rows.append(rec);(r/f'{phase}-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode: skipped.append({'module':n,'failed':p.returncode});continue
 succeeded.add(n)
(r/f'{phase}-skipped.json').write_text(json.dumps(skipped,indent=2)+'\n')
