import gzip,re,json
from pathlib import Path
r=Path('/dev/shm/beta-int-sharing')
def parse(ph):
 s=gzip.decompress((r/f'replay-{ph}-census.log.gz').read_bytes()).decode();pieces=re.split(r'(?=^(?:DECL|SIMP|INSTANCE) )',s,flags=re.M);out={'DECL':{},'SIMP':{},'INSTANCE':{}}
 for p in pieces:
  p=p.strip()
  if not p:continue
  typ=p.split(' ',1)[0]
  if typ not in out:raise ValueError(p[:100])
  if typ=='DECL':
   m=re.match(r'^DECL (\S+) (\S+) TYPE ',p);assert m,p[:100];key=m[2]
  else:key=p.split(' ',2)[1]
  assert key not in out[typ],key
  out[typ][key]=p
 return out
b=parse('baseline');f=parse('final');z={}
for k in b:
 old=set(b[k]);new=set(f[k]);z[k]={'baseline_count':len(old),'final_count':len(new),'removed':sorted(old-new),'added':sorted(new-old),'changed_common':sorted(x for x in old&new if b[k][x]!=f[k][x]),'common_count':len(old&new)}
(r/'replay-census-diff.json').write_text(json.dumps(z,indent=2)+'\n')
for k,v in z.items():
 print(k,'baseline',v['baseline_count'],'final',v['final_count'],'removed',len(v['removed']),'added',len(v['added']),'common changed',len(v['changed_common']))
 for key in ['removed','added','changed_common']:
  if v[key]:print(key,*v[key],sep='\n')
