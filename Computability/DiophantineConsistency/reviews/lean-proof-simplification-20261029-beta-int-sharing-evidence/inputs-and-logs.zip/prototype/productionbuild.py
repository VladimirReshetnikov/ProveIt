from pathlib import Path
import os,json,hashlib,subprocess,sys,re,shutil
r=Path('/dev/shm/beta-int-sharing'); w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); phase=sys.argv[1];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();scope=json.load(open(r/'scope.json'));names=['CurrentHighDigits2011','CurrentKernel2011','CurrentMaskRecipes2011','CurrentSparseDigits2011','CurrentWitnessEquivalence2011','NativeShiftedSourceAdapter']; graph={p.stem:re.findall(r'^import\s+DiophantineConsistency\.([^\s]+)',p.read_text(),re.M) for p in w.glob('*.lean')};
def closure(n):
 seen=set();todo=list(graph.get(n,[]))
 while todo:
  x=todo.pop()
  if x not in seen:seen.add(x);todo.extend(graph.get(x,[]))
 return seen
order=[]
while len(order)<len(names):
 nxt=sorted(n for n in names if n not in order and all(d in order for d in (set(names)&closure(n))));assert nxt
 order.extend(nxt)
names=order;lib=r/('objects-'+phase); env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+json.load(open('/tmp/four-positive-wrappers/upstream-records.json'))[0]['LEAN_PATH'];rows=[]
for n in names:
 src=r/phase/'DiophantineConsistency'/f'{n}.lean';shutil.copyfile(w/f'{n}.lean',src);out=lib/'DiophantineConsistency'/f'{n}.olean';out.unlink(missing_ok=True);inputs=[]
 for name in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=name.replace('.','/')+'.olean';p=next((Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file()),None)
  if p is None:raise RuntimeError(f'{n}: missing {name}')
  leaf=name.split('.')[-1];sp=(r/phase/'DiophantineConsistency'/f'{leaf}.lean') if (r/phase/'DiophantineConsistency'/f'{leaf}.lean').exists() else w/f'{leaf}.lean';inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 log=r/f'{phase}-production-{n}.log';tm=r/f'{phase}-production-{n}.time';before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/phase),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'phase':phase,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};rows.append(rec);(r/f'{phase}-production-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
