from pathlib import Path
import json,hashlib
p=Path('/tmp/carry-proof-sharing');d=json.loads(Path('/tmp/word-top-sharing/inventory.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();skips=[];out=[]
for name,v in d['local'].items():
 if name.split('.')[-1] in ('CurrentCarryConstruction2011','MFCurrentCarryConstruction2011','MFCurrentWordClause2011','CurrentWordClause2011','MFCurrentWordCopies2011','MFCurrentWordPadding2011','CurrentCarryConstruction2011Checks'):
  skips.append(name);continue
 src=Path(v['source']);assert src.exists() and h(src)==v['source_sha256'],name
 objs=[]
 for ph in ('baseline','final'):
  obj=p/('phase-'+ph)/(name.replace('.','/')+'.olean');assert obj.is_file() and h(obj)==v['object_sha256'],(name,ph);objs.append(str(obj.resolve()))
 out.append({'module':name,'source_sha256':v['source_sha256'],'object_sha256':v['object_sha256'],'selected':objs,'receipt_status':v['status']})
(p/'independent-pins.json').write_text(json.dumps({'matched':out,'skipped_phase_rebuilt':skips},indent=2)+'\n');print('matched',len(out),'skipped rebuilt',len(skips))
