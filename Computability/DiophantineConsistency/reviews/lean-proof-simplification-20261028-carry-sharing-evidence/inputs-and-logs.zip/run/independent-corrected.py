from pathlib import Path
import json,hashlib
p=Path('/tmp/carry-proof-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();res=[]
for r in json.loads((p/'copy-prereq-records.json').read_text()):
 assert r['status']==0 and h(r['source'])==r['source_sha256']==r['source_after'] and h(r['object'])==r['object_sha256'];assert h(r['command'][4])==r['time_sha256']
 log=Path(r['command'][4].replace('.time','.log'));assert h(log)==r['log_sha256']
 for x in r['direct_inputs']:
  assert h(x['path'])==x['sha256']==x['after_sha256']
  if x['local']:
   for ph in ('baseline','final'):
    obj=p/('phase-'+ph)/(x['module'].replace('.','/')+'.olean');assert obj.is_file() and h(obj)==x['sha256'],(r['module'],ph,x['module'])
 for ph in ('baseline','final'):
  obj=p/('phase-'+ph)/(r['module'].replace('.','/')+'.olean');assert h(obj)==r['object_sha256']
 res.append(r['module'])
print('three corrected prerequisites match source/object, timings, logs and all selected direct local inputs:',res)
for fn in ('copies-recheck-records.json','compat-records.json','private-import-records.json','foundation-records.json'):
 rows=json.loads((p/fn).read_text())
 for r in rows:
  cmd=r['command'];ph=r['phase'];tag=r.get('module',r.get('tag'));assert h(r['source'])==r['source_sha256']==r['source_after'] and h(cmd[4])==r['time_sha256'];assert h(p/(ph+'-'+tag+'.log'))==r['log_sha256'];assert r['status']==(1 if fn.startswith('foundation') else 0)
  if 'object_sha256' in r:assert h(r['object'])==r['object_sha256']
  for x in r.get('direct_inputs',[]):assert h(x['path'])==x['sha256']==x['after_sha256']
 print(fn,len(rows),'checked')
assert (p/'baseline-compat.log').read_bytes()==(p/'final-compat.log').read_bytes()
assert (p/'baseline-private.log').read_bytes()==(p/'final-private.log').read_bytes()
for tag in ('foundation-normal-first','foundation-first'):
 assert (p/('baseline-'+tag+'.log')).read_bytes()==(p/('final-'+tag+'.log')).read_bytes(),tag
print('compat/private and both Foundation error outputs match')
