from pathlib import Path
import json,hashlib,os,subprocess,time
p=Path('/tmp/carry-proof-sharing');h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest(); lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();rs=[]
for phase in ('baseline','final'):
 for tag in ('foundation-normal-first','foundation-first'):
  env=os.environ.copy();env['LEAN_PATH']=str(p/('phase-'+phase))+':'+lp;src=p/(tag+'.lean');log=p/f'{phase}-{tag}.log';tm=p/f'{phase}-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=h(src);t=time.monotonic()
  with log.open('wb') as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env).returncode
  rs.append({'phase':phase,'tag':tag,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,2)});(p/'foundation-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,tag,rc,flush=True)
  
