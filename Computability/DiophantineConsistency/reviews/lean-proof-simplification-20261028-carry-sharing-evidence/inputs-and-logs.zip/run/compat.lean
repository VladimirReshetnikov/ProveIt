import DiophantineConsistency.CurrentCarryConstruction2011
import DiophantineConsistency.MFCurrentCarryConstruction2011
namespace DiophantineConsistency.CurrentCarryConstruction2011
open scoped BigOperators
example {n : ℕ} [NeZero n] (c : ZMod n → ℕ) (W : ℕ) :
    raw c W = MF.CurrentCarryConstruction2011.raw c W := rfl
example {n : ℕ} [NeZero n] (c k d : ZMod n → ℕ) (W : ℕ) :
    Facts c W k d ↔ MF.CurrentCarryConstruction2011.Facts c W k d := by
  constructor <;> intro h
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
end DiophantineConsistency.CurrentCarryConstruction2011
