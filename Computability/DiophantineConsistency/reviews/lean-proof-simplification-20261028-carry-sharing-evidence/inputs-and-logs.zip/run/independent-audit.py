from pathlib import Path
import hashlib,json
p=Path('/tmp/carry-proof-sharing'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();out=[]
for fn in ('phase-records.json','probe-records.json','interface-records.json'):
 rows=json.loads((p/fn).read_text())
 for r in rows:
  ph=r['phase'];cmd=r['command'];src=[x for x in cmd if x.endswith('.lean')];assert len(src)==1 and r['status']==0,(fn,ph)
  assert r['lean_path'].split(':')[0]==str(p/('phase-'+ph));assert h(src[0])==r['source_sha256']==r['source_after'];assert h(cmd[4])==r['time_sha256']
  tag=r.get('module',r.get('tag')); assert h(p/(ph+'-'+tag+'.log'))==r['log_sha256']
  if 'object_sha256' in r:
   assert cmd[-2]=='-o' and h(cmd[-1])==r['object_sha256']
  for a in r.get('direct_inputs',[]):assert h(a['path'])==a['sha256']==a['after_sha256'],(ph,tag,a['module'])
 out.append({'file':fn,'count':len(rows)})
for n in ('CurrentCarryConstruction2011','MFCurrentCarryConstruction2011'):
 a=p/'baseline'/'DiophantineConsistency'/(n+'.lean');b=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');assert a.read_bytes()==b.read_bytes(),n
assert (p/'baseline-interface.log').read_bytes()==(p/'final-interface.log').read_bytes()
a=set((p/'baseline-names.log').read_text().splitlines());b=set((p/'final-names.log').read_text().splitlines());out.append({'baseline_names':len(a),'final_names':len(b),'removed':sorted(a-b),'added':sorted(b-a)})
(p/'independent-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
