import DiophantineConsistency.CurrentCarryConstruction2011
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n := `DiophantineConsistency.CurrentCarryConstruction2011.Facts.word_lt._proof_1
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
