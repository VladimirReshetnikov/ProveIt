from pathlib import Path
import json,hashlib,os,subprocess,time,shutil
p=Path('/tmp/carry-proof-sharing');repo=Path.cwd()/'Computability/DiophantineConsistency/Lean';inventory=json.loads(Path('/tmp/word-top-sharing/inventory.json').read_text());h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest(); lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for n,v in inventory['local'].items():assert h(v['source'])==v['source_sha256'],('source drift',n)
for phase in ('baseline','final'):
 ov=p/('phase-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+lp;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def locate(n):
  rel=n.replace('.','/')+'.olean'
  for root in roots:
   z=root/rel
   if z.is_file():return z
  raise RuntimeError('missing '+n)
 for name in ('MFCurrentWordCopies2011',):
  assert shutil.disk_usage('.').free>850*1024*1024
  src=(p/phase/'DiophantineConsistency'/f'{name}.lean') if 'CarryConstruction2011' in name and not name.endswith('Checks') else repo/'DiophantineConsistency'/f'{name}.lean';root=p/phase if src.is_relative_to(p) else repo
  im=[m for l in src.read_text().splitlines() if l.startswith('import ') for m in l.split()[1:]];inputs=[]
  for n in im:
   f=locate(n);inputs.append({'module':n,'path':str(f),'resolved':str(f.resolve()),'sha256':h(f)})
  before=h(src);out=ov/'DiophantineConsistency'/f'{name}.olean';out.unlink(missing_ok=True);log=p/f'{phase}-{name}.log';tm=p/f'{phase}-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];start=time.monotonic()
  with log.open('wb') as f:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  for v in inputs:v['after_sha256']=h(v['path'])
  r={'phase':phase,'module':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':inputs,'elapsed':round(time.monotonic()-start,2)};records.append(r);(p/'copies-recheck-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,rc,r['elapsed'],flush=True)
  if rc or before!=r['source_after'] or any(v['sha256']!=v['after_sha256'] for v in inputs):raise SystemExit(1)
for n,v in inventory['local'].items():assert h(v['source'])==v['source_sha256'],('source drift',n)
