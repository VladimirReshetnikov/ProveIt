import DiophantineConsistency.ObjectPairingInjective
open DiophantineConsistency.MaxSquarePairing

example (a b : ℕ) : pair a b < max a b * max a b + max a b ↔ a < b :=
  pair_lt_shell_cut a b

#print axioms DiophantineConsistency.MaxSquarePairing.pair_lt_shell_cut
