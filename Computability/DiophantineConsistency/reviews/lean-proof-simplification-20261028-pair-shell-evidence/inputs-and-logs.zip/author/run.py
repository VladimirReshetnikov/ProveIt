from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/object-pair-shell-20261028');pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';mode=sys.argv[1]
if mode=='prep':items=[(Path(s).stem,s,True) for s in json.loads((p/'prep-order.json').read_text())]
elif mode=='baseline':items=[('target',pre+'ObjectPairingInjective.lean',True),('axioms',str(p/'axioms.lean'),False)]
elif mode=='final':items=[('target',pre+'ObjectPairingInjective.lean',True),('axioms',str(p/'axioms.lean'),False),('new-lemma',str(p/'new-lemma.lean'),False),('client',pre+'ObjectUnpair.lean',True),('predecessor',pre+'ObjectPredecessor.lean',False),('focus','Computability/DiophantineConsistency/Lean/checks/ObjectSharpPairing.lean',False)]
else:raise SystemExit('bad mode')
records=[]
for tag,source,obj in items:
 if shutil.disk_usage('.').free<150*1024*1024:raise SystemExit('disk cutoff')
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency'/(Path(source).stem+'.olean'))]
 command=['lake','env','bash','-c','export LEAN_PATH="/tmp/object-pair-shell-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv];t=time.monotonic();r=subprocess.run(command,capture_output=True);elapsed=time.monotonic()-t
 log=p/(mode+'-'+tag+'.log');log.write_bytes(r.stdout+r.stderr);src=Path(source);rec={'name':tag,'argv':command,'status':r.returncode,'seconds':elapsed,'source':source,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  out=p/'overlay/DiophantineConsistency'/(src.stem+'.olean');rec['object']=str(out);rec['object_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
