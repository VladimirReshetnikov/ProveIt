from pathlib import Path
import os,subprocess,json,hashlib
b=Path('/tmp/bounded-exit-reuse');old=b/'merged';env=os.environ.copy();n='ArithmeticRuntimeBoundDagRun';rec=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();current=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');original=current.read_bytes();candidate=(b/'source/DiophantineConsistency'/(n+'.lean')).read_bytes()
for phase,content in [('baseline',original),('final',candidate)]:
 d=b/phase;src=d/'source/DiophantineConsistency'/(n+'.lean');src.parent.mkdir(parents=True,exist_ok=True);src.write_bytes(content);lib=d/'lib';lib.mkdir(exist_ok=True)
 for k in ['Foundation','FirstOrder','BusyBeaver']:(lib/k).symlink_to(old/k,target_is_directory=True)
 dr=lib/'DiophantineConsistency';dr.mkdir(exist_ok=True)
 for f in (old/'DiophantineConsistency').iterdir():
  if f.is_file() and f.name!=n+'.olean':(dr/f.name).symlink_to(f.resolve())
 out=dr/(n+'.olean');log=d/'target.log';tm=d/'target.time';e=env.copy();e['LEAN_PATH']=str(lib)+':'+env['LEAN_PATH'];cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(d/'source'),str(src),'-o',str(out)];r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm)]+cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'time':tm.read_text().strip(),'source_sha256':h(src),'object_sha256':h(out) if out.exists() else None,'object_bytes':out.stat().st_size if out.exists() else None,'log_sha256':h(log)});(b/'build-records.json').write_text(json.dumps(rec,indent=2));print(phase,r.returncode,rec[-1]['time'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
