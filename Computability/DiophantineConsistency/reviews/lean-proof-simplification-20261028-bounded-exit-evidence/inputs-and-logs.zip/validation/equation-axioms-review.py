from pathlib import Path
import os,subprocess,json,hashlib,time
R=Path('/tmp/bounded-exit-reuse');source=R/'equation-axioms-review.lean';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();recs=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase/'lib')+':'+env.get('LEAN_PATH','');cmd=['lean','-M6000','-j1','-DElab.async=false',str(source)];log=R/phase/'equation-axioms-review.log';t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 obj=R/phase/'lib/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.olean';recs.append({'phase':phase,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-t,'source_sha256':h(source),'object_sha256':h(obj),'log_sha256':h(log)})
 (R/'equation-axioms-review.json').write_text(json.dumps(recs,indent=2)+'\n');print(phase,r.returncode,flush=True)
 if r.returncode:raise SystemExit(1)
assert (R/'baseline/equation-axioms-review.log').read_bytes()==(R/'final/equation-axioms-review.log').read_bytes()
print('logs match',flush=True)
