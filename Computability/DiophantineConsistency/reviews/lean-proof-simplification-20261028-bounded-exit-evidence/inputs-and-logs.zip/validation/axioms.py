from pathlib import Path
import subprocess,os,json,hashlib,time
b=Path('/tmp/bounded-exit-reuse');env=os.environ.copy();rec=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ['baseline','final']:
 d=b/phase;e=env.copy();e['LEAN_PATH']=str(d/'lib')+':'+env['LEAN_PATH'];src=b/'AxiomsAll.lean';log=d/'axioms-all.log';cmd=['lean','-M6000','-j1','-DElab.async=false',str(src)];t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(src),'log_sha256':h(log)});(b/'axiom-records.json').write_text(json.dumps(rec,indent=2));print(phase,'axioms',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
a=(b/'baseline/axioms-all.log').read_bytes();c=(b/'final/axioms-all.log').read_bytes();print('identical',a==c,flush=True)
if a!=c:raise SystemExit(1)
