from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/tmp/bounded-exit-reuse');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bad=[]
def ensure(x,m):
 if not x:bad.append(m)
for kind,filename in [('target','build-records.json'),('client','check-records.json'),('axioms','axiom-records.json'),('equations','equation-axioms-review.json')]:
 for r in json.load(open(R/filename)):
  phase=r['phase'];cmd=r.get('command',r.get('cmd'));ensure(r['status']==0,f'{kind} {phase} status');ensure(r['lean_path'].split(':')[0]==str(R/phase/'lib'),f'{kind} {phase} path')
  sources=[Path(s) for s in cmd if s.endswith('.lean') and Path(s).is_file()];ensure(len(sources)==1,f'{kind} {phase} source count')
  if len(sources)==1:ensure(h(sources[0])==r['source_sha256'],f'{kind} {phase} source hash')
  if kind=='target':log=R/phase/'target.log'
  elif kind=='client':log=R/phase/(r['name']+'.log')
  elif kind=='axioms':log=R/phase/'axioms-all.log'
  else:log=R/phase/'equation-axioms-review.log'
  ensure(log.exists() and h(log)==r['log_sha256'],f'{kind} {phase} log hash')
  if '-o' in cmd:
   p=Path(cmd[cmd.index('-o')+1]);ensure(p.exists() and h(p)==r['object_sha256'],f'{kind} {phase} object hash')
  if kind=='equations':ensure(h(R/phase/'lib/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.olean')==r['object_sha256'],f'{kind} {phase} target hash')
old=(R/'baseline/Names.log').read_text().splitlines();new=(R/'final/Names.log').read_text().splitlines();printed=re.findall(r'^#print axioms\s+(\S+)',(R/'AxiomsAll.lean').read_text(),re.M);ensure(set(old)==set(new)==set(printed),'enumerated names mismatch');ensure(len(printed)==35 and len(set(printed))==35,'name count')
for file in ['target.log','ArithmeticRuntimeBoundDagMacrosA.log','Names.log','axioms-all.log','equation-axioms-review.log']:
 ensure((R/'baseline'/file).read_bytes()==(R/'final'/file).read_bytes(),'paired '+file)
a=(R/'baseline/axioms-all.log').read_text();ensure(a.count('warning:')==5,'five aux warnings')
A=json.load(open(R/'build-records.json'));ensure(A[0]['object_bytes']==739232 and A[1]['object_bytes']==739808,'object sizes')
source=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean');baseline=R/'baseline/source/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean';final=R/'final/source/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean';ensure(baseline.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(source)]),'baseline HEAD');ensure(final.read_bytes()==source.read_bytes(),'final workspace')
print('validated 8 paired records, 35 census names, 3 generated equation axiom reports, warnings and source snapshots; failures:',bad)
if bad:raise SystemExit(1)
