from pathlib import Path
import re,json,hashlib
b=Path('/tmp/bounded-exit-reuse');ov=b/'merged';roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('/home/codex/src/Proofs/lib/FormalizedFormalLogic-Foundation'),Path('Logic/FirstOrder/Lean')];known={};h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def add(n,src,objs,receipt):
 if n and src:known.setdefault(n,[]).append({'source':src,'objects':[x for x in objs if x],'receipt':receipt})
for m in json.load(open(b/'pins.json'))['records']:
 add(m['module'],m['source_expected'],[o['expected'] for o in m['objects'] if o['path'].endswith('.olean')],'/tmp/bounded-exit-reuse/pins.json')
p=Path('Computability/DiophantineConsistency/research/c222-dag-rootperm222-cache-plan-20261027.json');plan=json.load(open(p))
for m in plan['modules']:
 add(m['module'],m.get('source',{}).get('sha256'),[o['sha256'] for o in m.get('objects',[]) if o['path'].endswith('.olean')],str(p))
peer=Path('/tmp/arithmetic-dag-rootperm222-peer-p41b9lmc/PEER.json');d=json.load(open(peer))
for m in d['records']:
 if m.get('exit_code')==0:add(m['module'],m['source']['sha256'],[m['object']['sha256']],str(peer))
packet=Path('/tmp/arithmetic-proof-constructors222-root-peer-wjp4y2vy/packet.json');d=json.load(open(packet))
for m in d['inputs']['modules']:
 add(m['module'],m.get('source_sha256'),[o['sha256'] for o in m.get('objects',[]) if o['path'].endswith('.olean')],str(packet))
state=Path('/tmp/arithmetic-proof-constructors222-root-peer-wjp4y2vy/state.json');d=json.load(open(state))
for m in d['completed']:
 if m.get('exit_code')==0:add(m['module'],m['source_sha256'],[m['object_sha256']],str(state))
n='DiophantineConsistency.ArithmeticEnumBoundTower';src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticEnumBoundTower.lean');obj=ov/'DiophantineConsistency/ArithmeticEnumBoundTower.olean';add(n,h(src),[h(obj)],str(b/'enum-bound.log'))
seen={}
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');src=next((r/(rel+'.lean') for r in roots if (r/(rel+'.lean')).exists()),None)
 if src is None:return
 deps=re.findall(r'^(?:public\s+)?(?:meta\s+)?import\s+((?:DiophantineConsistency|BusyBeaver|Foundation|FirstOrder)(?:\.\w+)+)',src.read_text(),re.M);obj=ov/(rel+'.olean');obj=obj if obj.exists() else Path('.lake/build/lib/lean')/(rel+'.olean');ss=h(src);oo=h(obj) if obj.exists() else None;match=[x['receipt'] for x in known.get(n,[]) if x['source']==ss and oo in x['objects']];seen[n]={'source':str(src.resolve()),'source_sha256':ss,'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':oo,'matching_receipts':match,'imports':deps}
 for d in deps:visit(d)
for n in ['DiophantineConsistency.ArithmeticRuntimeBoundDagRun','DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA']:visit(n)
(b/'inventory.json').write_text(json.dumps(seen,indent=2));un=[n for n,v in seen.items() if v['object'] and not v['matching_receipts']];missing=[n for n,v in seen.items() if not v['object']];print('modules',len(seen),'matched',sum(bool(v['matching_receipts']) for v in seen.values()));print('unmatched',un);print('missing',missing)
