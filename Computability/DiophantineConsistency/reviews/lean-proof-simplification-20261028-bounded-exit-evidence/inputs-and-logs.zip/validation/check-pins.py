from pathlib import Path
import json,hashlib
b=Path('/tmp/bounded-exit-reuse');root=Path('/tmp/arithmetic-dag-loops-peer-v9mmg0s_');d=json.load(open(root/'inputs.json'));p=json.load(open(root/'PEER.json'));results=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bad=[]
def resolve(x):
 s=x; i=s.find('/Proofs/Computability/');j=s.find('/Proofs/Logic/')
 return Path('.'+s[i+7:]) if i>=0 else Path('.'+s[j+7:]) if j>=0 else Path(s)
for m in d['modules']:
 src=m.get('source');
 if not isinstance(src,dict) or not src.get('path'):continue
 q=resolve(src['path']);actual=h(q) if q.exists() else None
 if actual!=src['sha256']:bad.append(('source',m['module']))
 objects=[]
 for z in m.get('objects',[]):
  n=m['module'];dest=root/'lib'/n.replace('.','/');ext=Path(z['path']).name[len(n.split('.')[-1]):];dest=dest.parent/(dest.name+ext);ha=h(dest) if dest.exists() else None
  if ha!=z['sha256']:bad.append(('object',n,ext))
  objects.append({'path':str(dest.resolve()) if dest.exists() else str(dest),'expected':z['sha256'],'actual':ha})
 results.append({'module':m['module'],'source_path':str(q.resolve()),'source_expected':src['sha256'],'source_actual':actual,'objects':objects,'receipt':'inputs.json'})
for m in p['records']:
 z=m['source'];q=resolve(z['path']);actual=h(q) if q.exists() else None;obj=m['object'];path=Path(obj['path']);ha=h(path) if path.exists() else None
 if actual!=z['sha256']:bad.append(('fresh source',m['module']))
 if ha!=obj['sha256']:bad.append(('fresh object',m['module']))
 results.append({'module':m['module'],'source_path':str(q.resolve()),'source_expected':z['sha256'],'source_actual':actual,'objects':[{'path':str(path.resolve()),'expected':obj['sha256'],'actual':ha}],'receipt':'PEER.json + VERIFIED.json'})
(b/'pins.json').write_text(json.dumps({'inputs_sha256':h(root/'inputs.json'),'peer_sha256':h(root/'PEER.json'),'verified_sha256':h(root/'VERIFIED.json'),'records':results,'mismatches':bad},indent=2));print('sources',len(results),'objects',sum(len(x['objects']) for x in results),'mismatches',len(bad));print(bad[:25])
