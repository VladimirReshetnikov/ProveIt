import DiophantineConsistency.ArithmeticRuntimeBoundDagRun
#print equations DiophantineConsistency.ArithmeticRuntimeBoundDagRun.ReachB
#print equations DiophantineConsistency.ArithmeticRuntimeBoundDagRun.IRunB
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.ArithmeticRuntimeBoundDagRun).isPrefixOf n then
      logInfo m!"{n}"
