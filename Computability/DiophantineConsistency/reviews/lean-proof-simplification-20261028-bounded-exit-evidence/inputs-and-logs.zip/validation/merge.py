from pathlib import Path
import json,hashlib
b=Path('/tmp/bounded-exit-reuse');out=b/'merged';roots=[Path('/tmp/arithmetic-dag-loops-peer-v9mmg0s_/lib'),Path('/tmp/arithmetic-dag-rootperm222-peer-p41b9lmc/lib'),Path('/tmp/arithmetic-proof-constructors222-root-peer-wjp4y2vy/lib')];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();reports=[];out.mkdir(exist_ok=True)
for root in roots:
 added=overlap=0;bad=[]
 for ns in ['BusyBeaver','DiophantineConsistency','FirstOrder','Foundation']:
  dr=root/ns
  if not dr.exists():continue
  for f in dr.rglob('*'):
   if not f.is_file():continue
   p=out/ns/f.relative_to(dr);p.parent.mkdir(parents=True,exist_ok=True)
   if p.exists():
    overlap+=1
    if sha(p)!=sha(f):bad.append(str(f.relative_to(root)))
   else:p.symlink_to(f.resolve());added+=1
 reports.append({'source':str(root),'added':added,'overlap':overlap,'conflicts':bad});print(root,added,overlap,'conflicts',len(bad),flush=True)
 if bad:raise SystemExit(1)
(b/'merge-records.json').write_text(json.dumps(reports,indent=2))
