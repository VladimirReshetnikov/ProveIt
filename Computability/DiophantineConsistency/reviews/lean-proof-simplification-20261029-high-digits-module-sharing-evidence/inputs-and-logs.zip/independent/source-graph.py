from pathlib import Path
import re,json,subprocess
root=Path('Computability/DiophantineConsistency/Lean')
files=subprocess.check_output(['git','ls-tree','-r','--name-only','8e51af07d2^','--',str(root)]).decode().splitlines()
graph={}
for name in files:
 f=Path(name)
 if f.suffix!='.lean': continue
 mod='.'.join(f.relative_to(root).with_suffix('').parts)
 source=subprocess.check_output(['git','show','8e51af07d2^:'+str(f)]).decode()
 graph[mod]=[x for line in source.splitlines() for x in re.findall(r'^\s*import\s+([\w.]+)',line)]
owner='DiophantineConsistency.CurrentMaskData2011'; target='DiophantineConsistency.ListGetDCases'
def reaches(a,b):
 todo=[a]; seen=set()
 while todo:
  n=todo.pop()
  if n==b:return True
  if n in seen:continue
  seen.add(n); todo.extend(graph.get(n,[]))
 return False
clients={n:reaches(n,target) for n in graph if n!=owner and reaches(n,owner)}
direct={n:clients[n] for n in clients if owner in graph[n]}
print('tracked Lean project graph nodes',len(graph))
print('transitive owner clients',len(clients),'new reach',sum(not x for x in clients.values()))
print('direct owner clients',len(direct),'new reach',sum(not x for x in direct.values()))
print('new direct:',', '.join(sorted(n for n in direct if not direct[n])))
print('new transitive:',', '.join(sorted(n for n in clients if not clients[n])))
