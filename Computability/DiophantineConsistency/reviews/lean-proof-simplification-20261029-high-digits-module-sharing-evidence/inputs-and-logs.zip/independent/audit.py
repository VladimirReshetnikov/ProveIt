from pathlib import Path
import hashlib,json,re,subprocess,gzip
repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
broot=Path('/tmp/high-digits-full-sharing'); froot=Path('/tmp/high-digits-module-sharing')
h=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=json.loads((broot/'baseline-records.json').read_text()); f=json.loads((froot/'final-records.json').read_text()); bm={r['module']:r for r in b}; fm={r['module']:r for r in f}
target={'MFCurrentHighDigits2011','CurrentHighDigits2011','ArithmeticCellLocal'}
clients={'CurrentHighDigits2011Checks','ArithmeticCellLabels','CurrentClause2011','CurrentPolynomialWindow2011','MFCurrentClause2011','MFCurrentCopyParity2011','MFCurrentPhaseParity2011'}
assert set(fm)==target|clients|{'CurrentHighDigitFacts2011'}
for name in target:
 old=(broot/'baseline/DiophantineConsistency'/f'{name}.lean').read_text(); new=(froot/'final/DiophantineConsistency'/f'{name}.lean').read_text()
 assert new==(repo/f'{name}.lean').read_text()
 assert subprocess.check_output(['git','show','8e51af07d2^:'+str(repo/f'{name}.lean')]).decode()==old
 assert subprocess.check_output(['git','show','8e51af07d2:'+str(repo/f'{name}.lean')]).decode()==new
 private_start=old.index('private theorem highDigits_blocks')
 private_end=old.index('\n\n',private_start)+2
 st='theorem maskDigit_formula' if name=='ArithmeticCellLocal' else 'theorem cellDigit_formula'
 end='theorem maskDigit_padding' if name=='ArithmeticCellLocal' else 'theorem cellDigit_zero'
 proof_start=old.index(':= by',old.index(st))
 proof_end=old.index('\n\n'+end,proof_start)
 original_proof=old[proof_start:proof_end]
 expected=old[:proof_start]+':= by\n  exact DiophantineConsistency.CurrentHighDigitFacts2011.highDigits_getD j'+old[proof_end:]
 expected=expected[:private_start]+expected[private_end:]
 expected=expected.replace('import DiophantineConsistency.ListGetDCases','import DiophantineConsistency.CurrentHighDigitFacts2011',1)
 assert expected==new
 semantic=(froot/'final/DiophantineConsistency/CurrentHighDigitFacts2011.lean').read_text()
 body=original_proof.split('\n',2)[2]
 assert body in semantic
 assert old[private_start:private_end].replace('private theorem','theorem',1).strip() in semantic
 # Original formula statements are literally unchanged; all content after proof has no changes.
 st='theorem maskDigit_formula' if name=='ArithmeticCellLocal' else 'theorem cellDigit_formula'
 end='theorem maskDigit_padding' if name=='ArithmeticCellLocal' else 'theorem cellDigit_zero'
 assert old[old.index(st):old.index(':= by',old.index(st))]==new[new.index(st):new.index(':= by',new.index(st))]
 assert old[old.index(end):]==new[new.index(end):]
 assert 'exact DiophantineConsistency.CurrentHighDigitFacts2011.highDigits_getD j' in new
print('Three target statements, exact proof substitutions, parent and committed source snapshots match')
for label,rows in [('baseline',b),('final',f)]:
 for r in rows:
  assert r['status']==0 and r['before']==r['after']==h(r['source'])
  assert r['object_sha256']==h(r['object']) and r['log_sha256']==h(r['log'])
  assert Path(r['command'][2]).read_text()==r['time']
  for d in r['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d.get('source_before'): assert d['source_before']==d['source_after']==h(d['source'])
   fn=d['module'].replace('.','/')+'.olean'
   first=next(Path(z)/fn for z in r['LEAN_PATH'].split(':') if (Path(z)/fn).exists())
   assert first.resolve()==Path(d['path']).resolve()
 print(label,len(rows),'build source/input/log/object pins pass')
for n in target|clients:
 a={d['module']:d for d in bm[n]['direct_inputs']};z={d['module']:d for d in fm[n]['direct_inputs']}
 for m in a.keys()&z.keys():
  if m not in {'DiophantineConsistency.'+x for x in target}: assert a[m]['before']==z[m]['before'],(n,m)
for n in clients: assert bm[n]['object_sha256']==fm[n]['object_sha256']
print(len(clients),'replayed direct client objects equal; shared external direct inputs equal')
for n in target:
 records=json.loads((froot/f'env-{n}-records.json').read_text())
 print(n,'probe rows',len(records))
print('PASS')
sups=[]
for phase in ['baseline','final']:
 rows=json.loads((froot/f'supplement-{phase}-records.json').read_text()); sups.append(rows)
 for r in rows:
  assert r['status']==0 and r['before']==r['after']==h(r['source'])
  assert r['object_sha256']==h(r['object']) and r['log_sha256']==h(r['log'])
  assert Path(r['command'][2]).read_text()==r['time']
  for d in r['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d.get('source_before'): assert d['source_before']==d['source_after']==h(d['source'])
   fn=d['module'].replace('.','/')+'.olean'
   first=next(Path(z)/fn for z in r['LEAN_PATH'].split(':') if (Path(z)/fn).exists())
   assert first.resolve()==Path(d['path']).resolve()
for a,z in zip(*sups): assert a['module']==z['module'] and a['object_sha256']==z['object_sha256']
print('Supplemental',len(sups[0]),'direct clients: pinned inputs, source/output/logs and identical objects')
for name in sorted(target):
 records=json.loads((froot/f'v2-env-{name}-records.json').read_text())
 sets=[]
 for r in records:
  assert r['status']==0 and h(r['source'])==r['source_sha256']
  assert r['objects_before']==r['objects_after']==[h(p) for p in r['objects']]
  assert h(r['log'])==r['log_sha256']
  raw=gzip.open(r['log'],'rb').read(); assert hashlib.sha256(raw).hexdigest()==r['raw_log_sha256']
  lines=raw.decode().splitlines(); sets.append({k:{l for l in lines if l.startswith(k+' ')} for k in ['NAME','SIMP','INSTANCE']})
 assert sets[0]['SIMP']==sets[1]['SIMP'] and sets[0]['INSTANCE']==sets[1]['INSTANCE']
 diff=json.loads((froot/f'env-{name}-diff.json').read_text())
 assert set(diff['removed'])==sets[0]['NAME']-sets[1]['NAME'] and set(diff['added'])==sets[1]['NAME']-sets[0]['NAME']
 print(name,'census removed/added',len(diff['removed']),len(diff['added']),'simp/instance',len(sets[0]['SIMP']),len(sets[0]['INSTANCE']))
for r in json.loads((froot/'interfaces-probe-records.json').read_text()):
 assert r['status']==0 and h(r['source'])==r['source_sha256'] and h(r['log'])==r['log_sha256']
 assert r['objects_before']==r['objects_after']==[h(p) for p in r['objects']]
def blocks(p):
 s=Path(p).read_text(); chunks=re.split(r'(?=^DECL )',s,flags=re.M)
 return {re.match(r'DECL (\S+) TYPE ',chunk).group(1):chunk for chunk in chunks if chunk.startswith('DECL ')}
a=blocks(froot/'baseline-interfaces.log');z=blocks(froot/'final-interfaces.log'); comp=json.loads((froot/'interfaces-comparison.json').read_text())
assert set(comp['removed'])==a.keys()-z.keys() and set(comp['added'])==z.keys()-a.keys()
assert set(comp['changed_common'])=={k for k in a.keys()&z.keys() if a[k]!=z[k]}
assert all('._proof_' in k for k in comp['changed_common'])
print('Combined interface comparison independently reproduced:',len(comp['removed']),'removed,',len(comp['added']),'added,',len(comp['changed_common']),'changed common')
print('ALL PASS')
producer=json.loads((froot/'direct-producer-audit.json').read_text())
assert len(producer)==36
unmatched=[]
for p in producer:
 assert all(h(path)==p['object'] for path in p['paths'])
 assert h(repo/(p['module']+'.lean'))==p['source']
 if not p['matches']: unmatched.append(p['module']); continue
 for m in p['matches']:
  data=json.loads(Path(m['receipt']).read_text()); candidates=[]
  def walk(x):
   if isinstance(x,list):
    for item in x:walk(item)
   elif isinstance(x,dict):
    if str(x.get('module',x.get('name',''))).split('.')[-1]==p['module'] and x.get('status')==0 and x.get('object_sha256')==p['object'] and x.get('source_sha256_before',x.get('source_sha256',x.get('before')))==p['source']:candidates.append(x)
    for item in x.values():walk(item)
  walk(data); assert candidates,(p['module'],m)
  if m['source_after'] is not None: assert m['source_after']==p['source']
assert unmatched==['NativeCyclicCarry']
print('35/36 prior source/object producer mappings independently reproduced; NativeCyclicCarry unmatched')
for name in sorted(target):
 rec=json.loads((froot/f'v2-env-{name}-records.json').read_text()); opts=[]
 for r in rec:
  lines=gzip.open(r['log'],'rt').read().splitlines(); opts.append([x for x in lines if x.startswith('HEARTBEATS ')])
 assert opts[0]==opts[1]==['HEARTBEATS 200000000']
print('Three paired importing probes report the same default heartbeat budget')
for name in ['changed-common-name-tracked-source-search','generated-name-short-tracked-source-search','removed-name-lean-search','removed-name-tracked-source-search']:
 assert (froot/(name+'.status')).read_text().strip()=='1' and not (froot/(name+'.log')).read_bytes()
print('Retained scoped tracked-source reference searches report no matches')

newmodule=repo/'CurrentHighDigitFacts2011.lean'
assert subprocess.check_output(['git','show','8e51af07d2:'+str(newmodule)])==(froot/'final/DiophantineConsistency/CurrentHighDigitFacts2011.lean').read_bytes()==newmodule.read_bytes()
assert subprocess.run(['git','cat-file','-e','8e51af07d2^:'+str(newmodule)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
print('Commit 8e51af07d2: three parent/baseline and all four final/committed/workspace sources match; new module absent from parent')
