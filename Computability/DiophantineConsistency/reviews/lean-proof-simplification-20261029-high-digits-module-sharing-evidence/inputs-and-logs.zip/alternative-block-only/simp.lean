import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellLabels
import DiophantineConsistency.CurrentClause2011
import DiophantineConsistency.CurrentPolynomialWindow2011
import DiophantineConsistency.CurrentHighDigits2011Checks
import DiophantineConsistency.MFCurrentClause2011
import DiophantineConsistency.MFCurrentCopyParity2011
import DiophantineConsistency.MFCurrentPhaseParity2011
open Lean Elab Command
run_cmd do
 let env ← getEnv
 let t ← liftCoreM Lean.Meta.getSimpTheorems
 for (n, _) in env.constants.toList do
  if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) || t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
   logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
