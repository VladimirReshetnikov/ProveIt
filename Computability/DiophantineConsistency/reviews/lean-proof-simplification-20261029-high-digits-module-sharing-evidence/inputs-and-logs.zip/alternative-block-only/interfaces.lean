import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellLabels
import DiophantineConsistency.CurrentClause2011
import DiophantineConsistency.CurrentPolynomialWindow2011
import DiophantineConsistency.CurrentHighDigits2011Checks
import DiophantineConsistency.MFCurrentClause2011
import DiophantineConsistency.MFCurrentCopyParity2011
import DiophantineConsistency.MFCurrentPhaseParity2011
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.CurrentMasks2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentMaskData2011" ||
     (`DiophantineConsistency.ArithmeticCellLocal).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCellLocal" ||
     (`DiophantineConsistency.CurrentHighDigits2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentHighDigits2011" ||
     (`DiophantineConsistency.MF.CurrentHighDigits2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.MFCurrentHighDigits2011" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
