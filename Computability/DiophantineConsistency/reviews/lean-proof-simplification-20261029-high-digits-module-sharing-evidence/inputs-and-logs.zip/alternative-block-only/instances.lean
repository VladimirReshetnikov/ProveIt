import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellLabels
import DiophantineConsistency.CurrentClause2011
import DiophantineConsistency.CurrentPolynomialWindow2011
import DiophantineConsistency.CurrentHighDigits2011Checks
import DiophantineConsistency.MFCurrentClause2011
import DiophantineConsistency.MFCurrentCopyParity2011
import DiophantineConsistency.MFCurrentPhaseParity2011
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if Lean.Meta.isInstanceCore env n then
   let p ← liftCoreM <| Lean.Meta.getInstancePriority? n
   logInfo m!"INSTANCE {n} {p}"
