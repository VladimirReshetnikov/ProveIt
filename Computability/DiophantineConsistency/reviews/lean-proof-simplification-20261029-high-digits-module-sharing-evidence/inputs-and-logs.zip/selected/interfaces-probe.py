from pathlib import Path
import os,json,hashlib,subprocess
r=Path('/tmp/high-digits-module-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();src=r/'interfaces.lean';records=[]
for ph in ('baseline','final'):
 base=Path('/tmp/high-digits-full-sharing') if ph=='baseline' else r;rows=json.loads((base/(ph+'-records.json')).read_text());keep=['MFCurrentHighDigits2011','CurrentHighDigits2011','CurrentHighDigits2011Checks','ArithmeticCellLocal','ArithmeticCellLabels','CurrentClause2011','CurrentPolynomialWindow2011','MFCurrentClause2011','MFCurrentCopyParity2011','MFCurrentPhaseParity2011'];keep+=['CurrentMaskData2011'] if ph=='baseline' else ['CurrentHighDigitFacts2011'];objects=[next(x['object'] for x in rows if x['module']==n) for n in keep];before=[h(p) for p in objects];env=os.environ.copy();env['LEAN_PATH']=rows[0]['LEAN_PATH'];log=r/(ph+'-interfaces.log');cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':ph,'status':p.returncode,'source':str(src),'source_sha256':h(src),'objects':objects,'objects_before':before,'objects_after':[h(p) for p in objects],'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'log':str(log),'log_sha256':h(log)};records.append(rec);(r/'interfaces-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,p.returncode,flush=True)
 if p.returncode or before!=rec['objects_after']:raise SystemExit(1)
