from pathlib import Path
import os,json,hashlib,subprocess,sys,re,shutil
r=Path('/tmp/high-digits-module-sharing');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');ph=sys.argv[1];assert ph in ('baseline','final');prior=Path('/tmp/high-digits-full-sharing') if ph=='baseline' else r;original=json.loads((prior/(ph+'-records.json')).read_text());srcroot=r/('supplement-'+ph);s=srcroot/'DiophantineConsistency';s.mkdir(parents=True,exist_ok=True);lib=Path('/dev/shm/high-digits-module-sharing')/('supplement-'+ph);lib.mkdir(parents=True,exist_ok=True);priorroot=Path(original[0]['LEAN_PATH'].split(':')[0]);subprocess.run(['cp','-as',str(priorroot/'DiophantineConsistency'),str(lib/'DiophantineConsistency')],check=True)
inputs={'MFCurrentCarryConstruction2011':'/tmp/carry-proof-sharing/phase-final/DiophantineConsistency/MFCurrentCarryConstruction2011.olean','MFCurrentWordTopBounds2011':'/tmp/word-clause-sharing/pinned-final/DiophantineConsistency/MFCurrentWordTopBounds2011.olean'}
for n,p in inputs.items():
 d=lib/'DiophantineConsistency'/(n+'.olean');d.unlink(missing_ok=True);d.symlink_to(p)
names=['MFCurrentAdjacency2011','MFCurrentWordClause2011','MFCurrentWordCopies2011','MFCurrentWordPadding2011','MFCurrentWordOrigin2011','MFCurrentWordHighMask2011']
for n in names:
 (lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True);shutil.copyfile(w/(n+'.lean'),s/(n+'.lean'))
env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+original[0]['LEAN_PATH'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
for n in names:
 src=s/(n+'.lean');deps=[]
 for mod in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=mod.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());leaf=mod.split('.')[-1];sp=s/(leaf+'.lean') if leaf in names else (Path(original[0]['source']).parent/(leaf+'.lean') if leaf in [x['module'] for x in original] else w/(leaf+'.lean'));deps.append({'module':mod,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 out=lib/'DiophantineConsistency'/(n+'.olean');tm=r/('supplement-'+ph+'-'+n+'.time');log=r/('supplement-'+ph+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'phase':ph,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':deps,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};rows.append(rec);(r/('supplement-'+ph+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print('supplement',ph,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
