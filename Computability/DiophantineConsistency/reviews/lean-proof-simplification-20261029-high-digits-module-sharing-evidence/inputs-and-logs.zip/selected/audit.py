from pathlib import Path
import json,hashlib,gzip,re
r=Path('/tmp/high-digits-module-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());counts={}
for f in [Path('/tmp/high-digits-full-sharing/baseline-records.json'),r/'final-records.json',r/'supplement-baseline-records.json',r/'supplement-final-records.json']:
 rows=read(f);counts[str(f)]=len(rows)
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
   if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
print('PASS source/direct-input/output/log/time pins',counts)
c=read(r/'interfaces-comparison.json');assert c['baseline_count']==409 and c['final_count']==322 and len(c['removed'])==144 and len(c['added'])==57 and len(c['changed_common'])==14 and all('._proof_' in x for x in c['changed_common']);assert all(x.endswith('.highDigits_blocks') or '._proof_' in x for x in c['removed'])
a=read(r/'object-comparison.json');assert len(a)==10 and all(not a[n]['identical'] for n in ['ArithmeticCellLocal','CurrentHighDigits2011','MFCurrentHighDigits2011']) and all(v['identical'] for n,v in a.items() if n not in ['ArithmeticCellLocal','CurrentHighDigits2011','MFCurrentHighDigits2011']);assert all(x['identical'] for x in read(r/'supplement-comparison.json').values());print('PASS 13 paired direct client objects and 3 changed targets')
for x in read(r/'interfaces-probe-records.json'):
 assert x['status']==0 and h(x['source'])==x['source_sha256'] and h(x['log'])==x['log_sha256'] and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]
for n in ['ArithmeticCellLocal','CurrentHighDigits2011','MFCurrentHighDigits2011']:
 rows=read(r/('v2-env-'+n+'-records.json'));assert len(rows)==2
 for x in rows:
  raw=gzip.decompress(Path(x['log']).read_bytes());assert x['status']==0 and h(x['source'])==x['source_sha256'] and h(x['log'])==x['log_sha256'] and hashlib.sha256(raw).hexdigest()==x['raw_log_sha256'] and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]
 a,b=[set(gzip.decompress(Path(x['log']).read_bytes()).decode().splitlines()) for x in rows];assert not {x for x in a^b if x.startswith(('SIMP ','INSTANCE ','HEARTBEATS '))};assert 'HEARTBEATS 200000000' in a and 'HEARTBEATS 200000000' in b
print('PASS changed-target interface probes, three global registrations and scoped heartbeat')
for name in ['removed-name-tracked-source-search','changed-common-name-tracked-source-search','generated-name-short-tracked-source-search']:
 assert (r/(name+'.status')).read_text().strip()=='1' and not (r/(name+'.log')).read_bytes()
reg=read(r/'generated-name-registrations.json');assert all(not hits for hits in reg.values());print('PASS exact and suffix tracked-source searches and tested registration absence')
