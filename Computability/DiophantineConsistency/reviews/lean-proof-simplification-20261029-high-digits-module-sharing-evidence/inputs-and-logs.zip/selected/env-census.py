from pathlib import Path
import hashlib,json,os,subprocess,sys,gzip
r=Path('/tmp/high-digits-module-sharing');n=sys.argv[1];mods=['ArithmeticCellLocal','CurrentHighDigits2011','MFCurrentHighDigits2011'];assert n in mods;src=r/('env-'+n+'.lean');src.write_text('''import Lean.Elab.Command
import DiophantineConsistency.%s
open Lean Elab Command
run_cmd do
 let env ← getEnv
 let st ← liftCoreM Lean.Meta.getSimpTheorems
 let opts ← getOptions
 logInfo m!"HEARTBEATS {Lean.Core.getMaxHeartbeats opts}"
 for (name, _) in env.constants.toList do
  logInfo m!"NAME {name}"
  if st.isLemma (.decl name true false) || st.isLemma (.decl name false false) || st.isLemma (.decl name true true) || st.isLemma (.decl name false true) then
   logInfo m!"SIMP {name} {st.isLemma (.decl name true false)} {st.isLemma (.decl name false false)} {st.isLemma (.decl name true true)} {st.isLemma (.decl name false true)}"
  if Lean.Meta.isInstanceCore env name then
   let p ← liftCoreM <| Lean.Meta.getInstancePriority? name
   logInfo m!"INSTANCE {name} {p}"
'''%n);h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for ph in ('baseline','final'):
 rows=json.loads(((Path('/tmp/high-digits-full-sharing') if ph=='baseline' else r)/(ph+'-records.json')).read_text());row=next(x for x in rows if x['module']==n);objs=[row['object']];objs += [next(x['object'] for x in rows if x['module']=='CurrentHighDigitFacts2011')] if ph=='final' else [];env=os.environ.copy();env['LEAN_PATH']=row['LEAN_PATH'];before=[h(p) for p in objs];log=r/(ph+'-env-'+n+'.log.gz');cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)];p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log.write_bytes(gzip.compress(p.stdout,mtime=0));record={'phase':ph,'module':n,'status':p.returncode,'source':str(src),'source_sha256':h(src),'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'objects':objs,'objects_before':before,'objects_after':[h(p) for p in objs],'raw_log_sha256':hashlib.sha256(p.stdout).hexdigest(),'log':str(log),'log_sha256':h(log)};records.append(record);(r/('env-'+n+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(n,ph,p.returncode,'raw bytes',len(p.stdout),flush=True)
 if p.returncode or before!=record['objects_after']:sys.exit(1)
