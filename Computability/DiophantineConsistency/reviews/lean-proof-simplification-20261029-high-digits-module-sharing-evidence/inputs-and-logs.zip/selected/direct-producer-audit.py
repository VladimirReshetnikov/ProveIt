from pathlib import Path
import json
r=Path('/tmp/high-digits-module-sharing');files=[Path('/tmp/high-digits-full-sharing/baseline-records.json'),r/'final-records.json',r/'supplement-baseline-records.json',r/'supplement-final-records.json'];lanes=[json.loads(p.read_text()) for p in files];built={x['module'] for rows in lanes for x in rows};external={}
for rows in lanes:
 for x in rows:
  for d in x['direct_inputs']:
   n=d['module'].split('.')[-1]
   if n in built or not d['module'].startswith('DiophantineConsistency.'):continue
   key=(n,d['source_before'],d['before']);external.setdefault(key,{'module':n,'source':d['source_before'],'object':d['before'],'paths':[],'matches':[]})['paths'].append(d['resolved'])
dirs=['carry-proof-sharing','carry-map-sharing','word-clause-sharing','word-copies-sharing','word-padding-sharing','word-origin-sharing','word-top-sharing','highmask-sharing','cell-construction-share','positive-shift-sharing/source-clean','construction-share','pell-construction-refresh','current-packing-positive-sharing','carrier-set-iff-sharing','shared-padding-shift','list-getd-sharing-20261028','outer-seed-bound-sharing','native-zero-sharing','tiling-band-dispatch','rowrel-sharing','mask-ins-simplify','shared-box-prototype','pell-square-direct','shared-padding-shift']
paths=[]
for d in dirs:
 folder=Path('/tmp',d);paths+=list(folder.glob('*records*.json'))+list(folder.glob('*record.json'))
paths+=[Path('/dev/shm/claude-transport-sharing/assembly-common-records.json'),Path('/tmp/outer-seed-bound-sharing/assembly-builds2.json')]
for p in paths:
 try:rr=json.loads(p.read_text())
 except (ValueError,OSError):continue
 if isinstance(rr,dict):rr=[rr]
 if not isinstance(rr,list):continue
 for x in rr:
  if not isinstance(x,dict) or x.get('status')!=0:continue
  n=str(x.get('module') or x.get('name','')).split('.')[-1];a=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');b=x.get('after') or x.get('source_after') or x.get('source_sha256_after') or x.get('source_sha256');o=x.get('object_sha256') or x.get('output_sha256');key=(n,a,o)
  if key in external and (b==a or b is None):external[key]['matches'].append({'receipt':str(p),'source_after':b,'object':x.get('object') or x.get('output')})
result=[]
for x in external.values():
 x['paths']=sorted(set(x['paths']));result.append(x)
result.sort(key=lambda x:(x['module'],x['object']));(r/'direct-producer-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for x in result:print(x['module'],'matches',len(x['matches']),'SRC',str(x['source'])[:12],'OBJ',x['object'][:12],x['matches'][0]['receipt'] if x['matches'] else 'UNMATCHED')
print('total',len(result),'matched',sum(bool(x['matches']) for x in result))
