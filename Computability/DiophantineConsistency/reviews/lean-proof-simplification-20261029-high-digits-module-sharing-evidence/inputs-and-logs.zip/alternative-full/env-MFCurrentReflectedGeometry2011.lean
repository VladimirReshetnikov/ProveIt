import Lean.Elab.Command
import DiophantineConsistency.MFCurrentReflectedGeometry2011
open Lean Elab Command
run_cmd do
 let env ← getEnv
 let st ← liftCoreM Lean.Meta.getSimpTheorems
 let opts ← getOptions
 logInfo m!"HEARTBEATS {Lean.Core.getMaxHeartbeats opts}"
 for (name, _) in env.constants.toList do
  logInfo m!"NAME {name}"
  if st.isLemma (.decl name true false) || st.isLemma (.decl name false false) || st.isLemma (.decl name true true) || st.isLemma (.decl name false true) then
   logInfo m!"SIMP {name} {st.isLemma (.decl name true false)} {st.isLemma (.decl name false false)} {st.isLemma (.decl name true true)} {st.isLemma (.decl name false true)}"
  if Lean.Meta.isInstanceCore env name then
   let p ← liftCoreM <| Lean.Meta.getInstancePriority? name
   logInfo m!"INSTANCE {name} {p}"
