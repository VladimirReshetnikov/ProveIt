import DiophantineConsistency.LowMaskData
import DiophantineConsistency.ListGetDCases
import Mathlib.Data.Nat.Digits.Defs
import Mathlib.Data.Fin.VecNotation
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Tactic.IrreducibleDef

/-! Exact current mask data; no source-window, population or machine premise. -/
namespace DiophantineConsistency.CurrentMasks2011
open LowMaskCoding
set_option Elab.async false

def radix : ℕ := 2 ^ 47

def width : ℕ := 47 * 2011

def beta : ℕ := radix ^ 2011 - 1

irreducible_def lowSupport : Finset ℕ := Finset.range 951 ∪ Finset.Ico 960 986 ∪ {1004}

/-- The two nontrivial components of the low-mask support are disjoint. -/
theorem lowSupport_range_Ico_disjoint :
    Disjoint (Finset.range 951) (Finset.Ico 960 986) := by
  apply Finset.disjoint_left.mpr
  intro j hj hk
  simp only [Finset.mem_range, Finset.mem_Ico] at hj hk
  omega

/-- The marker is outside both preceding support intervals. -/
theorem lowSupport_marker_disjoint :
    Disjoint (Finset.range 951 ∪ Finset.Ico 960 986) ({1004} : Finset ℕ) := by
  apply Finset.disjoint_left.mpr
  intro j hj hk
  simp only [Finset.mem_union, Finset.mem_range, Finset.mem_Ico,
    Finset.mem_singleton] at hj hk
  omega

def lowPort : ℕ := mask radix 2 2011 lowSupport

/-- All nonzero high-mask digits occur in this1006-digit prefix. -/
def highPrefix : List ℕ :=
  4 :: (List.replicate 916 8 ++ List.replicate 43 0 ++ List.replicate 9 1 ++
    List.replicate 18 0 ++ List.replicate 8 1 ++ List.replicate 9 0 ++ [1, 2 ^ 45 - 4])

def highDigits : List ℕ := highPrefix ++ List.replicate 1005 0

/-- The high-mask list as consecutive constant blocks. -/
theorem highDigits_blocks : highDigits =
    List.replicate 1 4 ++ List.replicate 916 8 ++ List.replicate 43 0 ++
      List.replicate 9 1 ++ List.replicate 18 0 ++ List.replicate 8 1 ++
      List.replicate 9 0 ++ List.replicate 1 1 ++
      List.replicate 1 (2^45-4) ++ List.replicate 1005 0 := by
  simp only [highDigits, highPrefix, List.replicate_one,
    List.append_assoc, List.cons_append, List.nil_append]

/-- The concrete digit at each position of the high-mask list. -/
set_option maxHeartbeats 2000000 in
theorem highDigits_getD (j : ℕ) : highDigits.getD j 0 =
    if j = 0 then 4 else if j < 917 then 8 else if j < 960 then 0 else
      if j < 969 then 1 else if j < 987 then 0 else if j < 995 then 1 else
      if j < 1004 then 0 else if j = 1004 then 1 else if j = 1005 then 2^45-4 else 0 := by
  rw [highDigits_blocks]
  simp only [List.append_assoc, ListGetDCases.append, List.length_replicate,
    ListGetDCases.replicate]
  repeat' first | omega | split

def highPort : ℕ := Nat.ofDigits radix highDigits

def ports (K : ℤ) : Fin 4 → ℤ := ![beta, K, lowPort, highPort + beta]

end DiophantineConsistency.CurrentMasks2011
