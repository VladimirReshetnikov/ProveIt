import DiophantineConsistency.CurrentKernelData2011
import DiophantineConsistency.ArithmeticMaskKernel
import DiophantineConsistency.WangTiles942Core
import DiophantineConsistency.CurrentMasks2011
import DiophantineConsistency.NativeWindowCarry

/-!
# The literal positive kernel on the maintained length2011 page

The finite stencil is indexed by abstract tiles and the34 true packed
color bits. Folding accounts for all collisions; no physical-rank
injectivity or tableau interpretation is assumed. The rational printed
recipe equals a natural-number sum by finite exponent cancellation.
-/

namespace DiophantineConsistency.CurrentKernel2011

open WangTiles942 NativeCyclicConvolution
open scoped BigOperators

set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

/-- A coarse bound sufficient for cancellation, without a permutation premise. -/
theorem physicalPosition_le (i : Fin 942) : physicalPosition i ≤ 942 := by
  rw [physicalPosition_eq_printed]
  split_ifs
  · omega
  · have hb (j : Fin 941) :
        (2 ^ 44 - 1 + selectorWeight (tile ⟨j.val + 1, by omega⟩) -
          selectorWeight (tile i)) / 2 ^ 44 ≤ 1 := by
      have hj := weight_small (⟨j.val + 1, by omega⟩ : Fin 942)
      have hn : 2 ^ 44 - 1 + selectorWeight (tile ⟨j.val + 1, by omega⟩) -
          selectorWeight (tile i) < 2 * 2 ^ 44 := by omega
      have hd := (Nat.div_lt_iff_lt_mul (by decide : 0 < (2 : ℕ) ^ 44)).mpr hn
      omega
    have hs := Finset.sum_le_sum (fun j (_ : j ∈ (Finset.univ : Finset (Fin 941))) => hb j)
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul, mul_one] at hs
    omega

theorem position_le (e : Entry) : position e ≤ 985 := by
  rcases e with i | j | j | j | j
  · have := physicalPosition_le i
    simpa only [position] using (show physicalPosition i ≤ 985 by omega)
  all_goals simp only [position]; omega

theorem entry_count : Fintype.card Entry = 976 := by simp [Entry]

def geometric {R : Type*} [Semiring R] (x : R) (n : ℕ) : R :=
  ∑ j ∈ Finset.range n, x ^ j

/-- The coefficient expansion, with no integer division or truncated exponent. -/
def phi {R : Type*} [Semiring R] (x : R) : R :=
  ∑ e : Entry, (weight e : R) * x ^ position e

private theorem bit_sum {R : Type*} [CommSemiring R] (x : R) (a b n : ℕ) :
    (∑ j : Fin n, ((2 ^ (a + j.val) : ℕ) : R) * x ^ (b + j.val)) =
      (2 : R) ^ a * x ^ b * geometric (2 * x) n := by
  rw [Fin.sum_univ_eq_sum_range
    (fun j => ((2 ^ (a + j) : ℕ) : R) * x ^ (b + j)) n]
  simp only [geometric, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  push_cast
  simp only [pow_add, mul_pow]
  ring

/-- Exactly the complete compact Phi expression printed on the page. -/
theorem phi_printed {R : Type*} [CommSemiring R] (x : R) :
    phi x = (∑ i : Fin 942, (selectorWeight (tile i) : R) * x ^ physicalPosition i) +
      2 ^ 10 * x ^ 969 * (x ^ 9 + 2 ^ 17) * geometric (2 * x) 8 +
      2 ^ 18 * x ^ 942 * (x ^ 18 + 2 ^ 17) * geometric (2 * x) 9 := by
  simp only [phi, Fintype.sum_sum_type, position, weight]
  rw [bit_sum, bit_sum, bit_sum, bit_sum]
  ring

theorem term_count : Fintype.card Term = 979 := by simp [Term, Entry]

theorem reflected_even (e : Entry) : Even (coefficient (.inr e)) := by
  exact ⟨weight e, by simp only [coefficient, two_mul]⟩

theorem rawWord_eq (r : ℕ) : rawWord r = r ^ 18 + r ^ 1004 + r ^ 2020 +
    ∑ e : Entry, 2 * weight e * r ^ (1005 - position e) := by
  simp only [rawWord, Fintype.sum_sum_type, coefficient, exponent]
  rw [Fin.sum_univ_three]
  simp only [one_mul]
  rfl

theorem K_pos : 0 < K := by
  rw [K, rawWord_eq]
  have : 0 < radix ^ 18 := pow_pos (by decide) _
  omega

private theorem cancel_exponent (r : ℚ) (hr : r ≠ 0) (e : ℕ) (he : e ≤ 1005) :
    r ^ 1005 * (r⁻¹) ^ e = r ^ (1005 - e) := by
  rw [inv_pow]
  exact (pow_sub₀ r hr he).symm

/-- All Laurent denominators cancel before the port is used as an integer. -/
theorem rawWord_printed (r : ℕ) (hr : 0 < r) : (rawWord r : ℚ) =
    (r : ℚ) ^ 18 + (r : ℚ) ^ 1004 + (r : ℚ) ^ 2020 +
      2 * (r : ℚ) ^ 1005 * phi ((r : ℚ)⁻¹) := by
  rw [rawWord_eq]
  push_cast
  unfold phi
  rw [Finset.mul_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro e _
  have hb : position e ≤ 1005 := le_trans (position_le e) (by decide)
  have hc := cancel_exponent (r : ℚ) (by exact_mod_cast (ne_of_gt hr)) (position e) hb
  calc
    2 * (weight e : ℚ) * (r : ℚ) ^ (1005 - position e) =
        2 * (weight e : ℚ) * ((r : ℚ) ^ 1005 * ((r : ℚ)⁻¹) ^ position e) := by rw [hc]
    _ = _ := by ring

theorem K_printed : (K : ℚ) =
    (radix : ℚ) ^ 18 + (radix : ℚ) ^ 1004 + (radix : ℚ) ^ 2020 +
      2 * (radix : ℚ) ^ 1005 * phi ((radix : ℚ)⁻¹) :=
  rawWord_printed radix (by decide)

/-- The complete transition-family mass, available without another closed evaluation. -/
theorem transition_mass :
    ((List.ofFn transitionRow).map (fun row => selectorWeight row.2)).sum = 11139798681006 :=
  ArithmeticMaskKernel.transition_mass

theorem selector_mass : (∑ i : Fin 942, selectorWeight (tile i)) = 3812322332357550 :=
  ArithmeticMaskKernel.selector_mass

theorem entry_mass : (∑ e : Entry, weight e) = 3829914518400942 :=
  ArithmeticMaskKernel.entry_mass

theorem coefficient_mass : (∑ t : Term, coefficient t) = 7659829036801887 :=
  ArithmeticMaskKernel.coefficient_mass

variable {n : ℕ} [NeZero n]

def folded : ZMod n → ℕ := foldStencil exponent coefficient

theorem folded_mass : mass (folded (n := n)) = 7659829036801887 := by
  rw [folded, mass_foldStencil, coefficient_mass]

theorem folded_word : word radix (folded (n := n)) ≡ K [MOD radix ^ n - 1] := by
  exact word_foldStencil (by decide : 1 ≤ radix) exponent coefficient

/-- Every original monomial acts once, including reflected/bare collisions. -/
theorem convolution_terms (c : ZMod n → ℕ) (k : ZMod n) :
    convolution folded c k = ∑ t : Term, coefficient t * c (k - (exponent t : ZMod n)) :=
  convolution_foldStencil exponent coefficient c k

/-- The two bare current copies and the spatial copy occur exactly once. -/
theorem convolution_eq (c : ZMod n → ℕ) (k : ZMod n) :
    convolution folded c k = c (k - 18) + c (k - 1004) + c (k - 2020) +
      ∑ e : Entry, 2 * weight e * c (k - ((1005 - position e : ℕ) : ZMod n)) := by
  rw [convolution_terms]
  simp only [Fintype.sum_sum_type, coefficient, exponent]
  rw [Fin.sum_univ_three]
  simp only [one_mul]
  rfl

/-- A mass bound before count recovery, alignment, or any label semantics. -/
theorem raw_bound (c r : ZMod n → ℕ) (hc : ∀ i, c i ≤ 1)
    (hr : ∀ i, r i ≤ 2 ^ 46) (k : ZMod n) :
    convolution folded c k + r k ≤ 7730197780979551 := by
  have hh := convolution_le_mass (folded (n := n)) c hc k
  rw [folded_mass, mul_one] at hh
  have ht := hr k
  omega

theorem carry_budget (c r : ZMod n → ℕ) (hc : ∀ i, c i ≤ 1)
    (hr : ∀ i, r i ≤ 2 ^ 46) (k : ZMod n) :
    convolution folded c k + r k + 57 < 58 * radix := by
  have hh := raw_bound c r hc hr k
  exact lt_of_le_of_lt (Nat.add_le_add_right hh 57) (by decide)

/-- Normalize the actual K product, preserving arbitrary temporal digits
within the Boolean rotation bound and the positive strict transport residue. -/
theorem exists_normalization {F : ℕ} (c r : ZMod n → ℕ)
    (hc : ∀ i, c i ≤ 1) (hr : ∀ i, r i ≤ 2 ^ 46)
    (htransport : K * word radix c + word radix r ≡ F [MOD radix ^ n - 1])
    (hFpos : 0 < F) (hF : F < radix ^ n - 1) :
    ∃ k digits : ZMod n → ℕ, (∀ i, k i ≤ 57) ∧ (∀ i, digits i < radix) ∧
      (∀ i, k i = (convolution folded c i + r i + k (i - 1)) / radix) ∧
      (∀ i, convolution folded c i + r i + k (i - 1) = digits i + radix * k i) ∧
      word radix digits = F := by
  apply NativeCyclicCarryWord.exists_convolution_normalization
    (by decide : 1 < radix) folded c r (carry_budget c r hc hr) _ hFpos hF
  exact (((folded_word (n := n)).mul_right (word radix c)).add_right (word radix r)).trans htransport

end DiophantineConsistency.CurrentKernel2011
