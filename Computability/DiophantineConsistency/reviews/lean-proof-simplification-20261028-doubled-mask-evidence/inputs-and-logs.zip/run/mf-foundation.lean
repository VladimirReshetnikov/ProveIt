import Foundation.Vorspiel.Matrix
import DiophantineConsistency.MFDoubledClause2011
#check Matrix.vecCons_zero
#print axioms DiophantineConsistency.MF.DoubledClause2011.mask_iff
