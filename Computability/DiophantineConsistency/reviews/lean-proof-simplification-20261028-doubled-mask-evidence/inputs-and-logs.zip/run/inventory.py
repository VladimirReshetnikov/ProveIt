from pathlib import Path
import json,re,hashlib
R=Path('/tmp/doubled-mask-reuse-20261028');root=Path('Computability/DiophantineConsistency/Lean');cache=Path('/tmp/list-getd-sharing-20261028/normal-fresh');names=['DoubledClause2011','MFDoubledClause2011','CurrentCellLabels2011','CurrentCellLabels2011Checks','CurrentCellConstruction2011','DoubledClause2011Checks'];seen={};order=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def go(n):
 if n in seen:return
 src=root/(n.replace('.','/')+'.lean')
 if not src.exists():return
 im=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:im.extend(m.group(1).split())
 local=[x for x in im if x.startswith('DiophantineConsistency.') and (root/(x.replace('.','/')+'.lean')).exists()]
 v={'source':str(src),'source_sha256':h(src),'imports':im,'local_imports':local};seen[n]=v
 for d in local:go(d)
 short=n.rsplit('.',1)[-1];obj=Path('/tmp/list-getd-sharing-20261028/fresh-client-CurrentClause2011.olean') if short=='CurrentClause2011' else cache/(n.replace('.','/')+'.olean')
 if obj.exists():v.update(object=str(obj.resolve()),object_sha256=h(obj),source_newer=src.stat().st_mtime>obj.stat().st_mtime)
 order.append(n)
for n in names:go('DiophantineConsistency.'+n)
(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n');print('nodes',len(seen),'source newer',[n for n,v in seen.items() if v.get('source_newer')],'missing',[n for n,v in seen.items() if 'object' not in v])
