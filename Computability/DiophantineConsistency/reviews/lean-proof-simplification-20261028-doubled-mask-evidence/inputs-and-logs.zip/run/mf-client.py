from pathlib import Path
import json,hashlib,os,subprocess,time
R=Path('/tmp/doubled-mask-reuse-20261028');prev=Path('/tmp/selector-shared-20261028');repo=Path('Computability/DiophantineConsistency/Lean');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
prior=json.loads((prev/'phase-records.json').read_text())
for n in ['ArithmeticCellPhysical','ArithmeticCellLocal']:
 v=next(q for q in prior if q['phase']=='final' and q['tag']==n);s=repo/'DiophantineConsistency'/(n+'.lean');o=prev/'final/DiophantineConsistency'/(n+'.olean');assert sha(s)==v['source_sha256'] and sha(o)==v['object_sha256'],n
(R/'mf-foundation.lean').write_text('import Foundation.Vorspiel.Matrix\nimport DiophantineConsistency.MFDoubledClause2011\n#check Matrix.vecCons_zero\n#print axioms DiophantineConsistency.MF.DoubledClause2011.mask_iff\n')
for phase in ['baseline','final']:
 out=R/('mf-client-'+phase);d=out/'DiophantineConsistency';d.mkdir(parents=True,exist_ok=True)
 for p in (prev/'final/DiophantineConsistency').iterdir():
  if p.suffix=='.olean' and p.stem not in ['MFDoubledClause2011','ArithmeticCellLabels']:
   q=d/p.name
   if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 q=d/'MFDoubledClause2011.olean'
 if not q.exists() and not q.is_symlink():q.symlink_to((R/('phase-'+phase)/'DiophantineConsistency/MFDoubledClause2011.olean').resolve())
 q=out/'Foundation'
 if not q.exists() and not q.is_symlink():q.symlink_to('/home/codex/src/Proofs/.lake/build/lib/lean/Foundation',target_is_directory=True)
 env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env.get('LEAN_PATH','')
 for tag,source,srcroot,output in [('labels',repo/'DiophantineConsistency/ArithmeticCellLabels.lean',repo,d/'ArithmeticCellLabels.olean'),('foundation',R/'mf-foundation.lean',R,None)]:
  log=R/(phase+'-mf-client-'+tag+'.log');tm=R/(phase+'-mf-client-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcroot),str(source)]
  if output:output.unlink(missing_ok=True);cmd+=['-o',str(output)]
  before=sha(source);t=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  v={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':sha(source),'log_sha256':sha(log),'timing':tm.read_text().strip()}
  if output and output.exists():v.update(object_sha256=sha(output),object_bytes=output.stat().st_size)
  records.append(v);(R/'mf-client-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,p.returncode,flush=True)
  if p.returncode or v['source_after']!=before:raise SystemExit(1)
for tag in ['labels','foundation']:
 if (R/('baseline-mf-client-'+tag+'.log')).read_bytes()!=(R/('final-mf-client-'+tag+'.log')).read_bytes():raise SystemExit('logs differ '+tag)
print('MF client and actual Foundation co-import match',flush=True)
