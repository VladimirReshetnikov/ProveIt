import json,pathlib,re
R=pathlib.Path('/tmp/doubled-mask-reuse-20261028');G=json.loads((R/'graph.json').read_text())['nodes']; pins=json.loads((R/'selected-pins.json').read_text());known={}
def add(n,s,o,r):
 if n and s and o: known.setdefault(n,[]).append((s,o,r))
def read(p):return json.loads(pathlib.Path(p).read_text())
for x in read('/tmp/selector-shared-20261028/selected-objects.json'):add(x['module'],x['source_sha256'],x['object_sha256'],'prior-selector')
for p in ['/tmp/list-getd-sharing-20261028/fresh-records.json','/tmp/list-getd-sharing-20261028/client-prereq-records.json']:
 for x in read(p):add(x['module'] if '.' in x['module'] else 'DiophantineConsistency.'+x['module'],x['source_sha256'],x['object_sha256'],p)
x=next(q for q in read('/tmp/list-getd-sharing-20261028/target-fresh-records.json') if q['name']=='normal-final-fresh');add('DiophantineConsistency.CurrentHighDigits2011',x['source_sha256'],x['object_sha256'],'prior-high-digits')
x=read('/tmp/reflected-shared-20261028/helper-check.json');add('DiophantineConsistency.ListGetDCases',x['source_sha256'],x['object_sha256'],'prior-helper-check')
x=next(q for q in read('/tmp/list-getd-sharing-20261028/fresh-check-records.json') if q['label']=='fresh-client-CurrentClause2011');add('DiophantineConsistency.CurrentClause2011',x['source_sha256'],x['output_sha256'],'prior-clause-client')
for pin in pins:
 expected=[r for s,o,r in known.get(pin['module'],[]) if s==pin['source_sha256'] and o==pin['object_sha256']];assert expected==pin['matching_receipts'],pin['module']
print('receipt matches verified:',sum(bool(x['matching_receipts']) for x in pins),'historical:',sum(not x['matching_receipts'] for x in pins))
root=pathlib.Path('Computability/DiophantineConsistency/Lean')
for name,v in G.items():
 imports=[]
 for line in pathlib.Path(v['source']).read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m: imports.extend(m.group(1).split())
 assert imports==v['imports'],name
 local=[x for x in imports if x.startswith('DiophantineConsistency.') and (root/(x.replace('.','/')+'.lean')).exists()]; assert local==v['local_imports'],name
print('all 70 source import lists and local edge lists reproduced')
