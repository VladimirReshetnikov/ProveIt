from pathlib import Path
import os,re,json,time,hashlib,subprocess
R=Path('/tmp/doubled-mask-reuse-20261028');repo=Path('Computability/DiophantineConsistency/Lean');cache=Path('/tmp/list-getd-sharing-20261028/normal-fresh/DiophantineConsistency');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
targets={'DoubledClause2011','MFDoubledClause2011','CurrentCellLabels2011','CurrentCellLabels2011Checks','CurrentCellConstruction2011','DoubledClause2011Checks'}
clause=Path('/tmp/list-getd-sharing-20261028/fresh-client-CurrentClause2011.olean');rec=next(x for x in json.loads(Path('/tmp/list-getd-sharing-20261028/fresh-check-records.json').read_text()) if x['label']=='fresh-client-CurrentClause2011');clause_src=repo/'DiophantineConsistency/CurrentClause2011.lean';assert sha(clause)==rec['output_sha256'] and sha(clause_src)==rec['source_sha256']
for phase in ['baseline','final']:
 d=R/('phase-'+phase)/'DiophantineConsistency';d.mkdir(parents=True,exist_ok=True)
 for p in cache.iterdir():
  if p.suffix=='.olean' and p.stem not in targets and p.stem!='CurrentClause2011':
   q=d/p.name
   if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 q=d/'CurrentClause2011.olean'
 if not q.exists() and not q.is_symlink():q.symlink_to(clause.resolve())
base=(R/'baseline/DiophantineConsistency/DoubledClause2011.lean').read_text();names=re.findall(r'^(?:noncomputable\s+)?(?:def|abbrev|theorem|lemma|structure|inductive)\s+(\w+)',base,re.M);defs=['wordBase','radix','mask','raw','digit'];nsp='DiophantineConsistency.DoubledClause2011.'
axi='import DiophantineConsistency.DoubledClause2011\nimport DiophantineConsistency.MFDoubledClause2011\n'
for n in defs:axi+='#print equations '+nsp+n+'\n'
axi+='#print equations DiophantineConsistency.MF.DoubledClause2011.mask\n'
for n in names:axi+='#print axioms '+nsp+n+'\n'
for n in defs:axi+='#print axioms '+nsp+n+'.eq_1\n'
for n in ['mask','mask.eq_1','mask_iff']:axi+='#print axioms DiophantineConsistency.MF.DoubledClause2011.'+n+'\n'
(R/'axioms.lean').write_text(axi)
(R/'names.lean').write_text('import DiophantineConsistency.DoubledClause2011\nopen Lean Elab Command\nrun_cmd do\n  for (n, _) in (← getEnv).constants.toList do\n    if (`DiophantineConsistency.DoubledClause2011).isPrefixOf n then\n      logInfo m!"{n}"\n')
(R/'imports.lean').write_text('import DiophantineConsistency.DoubledClause2011\nopen Lean Elab Command\nrun_cmd do\n  for n in (← getEnv).allImportedModuleNames do\n    logInfo m!"{n}"\n')
def run(phase,tag,source,srcroot,output=None):
 env=os.environ.copy();env['LEAN_PATH']=str(R/('phase-'+phase))+':'+env.get('LEAN_PATH','');tm=R/(phase+'-'+tag+'.time');log=R/(phase+'-'+tag+'.log');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcroot),str(source)]
 if output is not None:output.unlink(missing_ok=True);cmd+=['-o',str(output)]
 before=sha(source);start=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 row={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'source_after':sha(source),'log_sha256':sha(log),'timing':tm.read_text().strip()}
 if output and output.exists():row.update(object_sha256=sha(output),object_bytes=output.stat().st_size)
 records.append(row);(R/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,q.returncode,round(row['seconds'],1),flush=True)
 if q.returncode or row['source_after']!=before:raise SystemExit(1)
for phase in ['baseline','final']:
 srcroot=R/('baseline' if phase=='baseline' else 'source');out=R/('phase-'+phase)/'DiophantineConsistency'
 for n in ['MFDoubledClause2011','DoubledClause2011']:run(phase,n,srcroot/'DiophantineConsistency'/(n+'.lean'),srcroot,out/(n+'.olean'))
 for tag in ['axioms','names','imports']:run(phase,tag,R/(tag+'.lean'),R)
 for n in ['DoubledClause2011Checks','CurrentCellLabels2011','CurrentCellLabels2011Checks','CurrentCellConstruction2011']:
  run(phase,'client-'+n,repo/'DiophantineConsistency'/(n+'.lean'),repo,out/(n+'.olean'))
for tag in ['axioms','client-DoubledClause2011Checks','client-CurrentCellLabels2011','client-CurrentCellLabels2011Checks','client-CurrentCellConstruction2011']:
 a=(R/('baseline-'+tag+'.log')).read_bytes();b=(R/('final-'+tag+'.log')).read_bytes()
 if a!=b:print('LOG DIFFERENCE',tag,flush=True);raise SystemExit(2)
a=set((R/'baseline-imports.log').read_text().splitlines());b=set((R/'final-imports.log').read_text().splitlines());print('imports added',sorted(b-a),'removed',sorted(a-b),flush=True)
print('paired targets, clients and axioms match',flush=True)
