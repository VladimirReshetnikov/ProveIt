from pathlib import Path
import json,hashlib
R=Path('/tmp/doubled-mask-reuse-20261028');G=json.loads((R/'graph.json').read_text())['nodes'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();known={}
def add(n,s,o,r):
 if n and s and o:known.setdefault(n,[]).append((s,o,r))
for x in json.loads(Path('/tmp/selector-shared-20261028/selected-objects.json').read_text()):add(x['module'],x['source_sha256'],x['object_sha256'],'prior-selector')
for p in ['/tmp/list-getd-sharing-20261028/fresh-records.json','/tmp/list-getd-sharing-20261028/client-prereq-records.json']:
 for x in json.loads(Path(p).read_text()):
  n=x['module'];n=n if '.' in n else 'DiophantineConsistency.'+n;add(n,x['source_sha256'],x['object_sha256'],p)
x=next(q for q in json.loads(Path('/tmp/list-getd-sharing-20261028/target-fresh-records.json').read_text()) if q['name']=='normal-final-fresh');add('DiophantineConsistency.CurrentHighDigits2011',x['source_sha256'],x['object_sha256'],'prior-high-digits')
x=json.loads(Path('/tmp/reflected-shared-20261028/helper-check.json').read_text());add('DiophantineConsistency.ListGetDCases',x['source_sha256'],x['object_sha256'],'prior-helper-check')
x=next(q for q in json.loads(Path('/tmp/list-getd-sharing-20261028/fresh-check-records.json').read_text()) if q['label']=='fresh-client-CurrentClause2011');add('DiophantineConsistency.CurrentClause2011',x['source_sha256'],x['output_sha256'],'prior-clause-client')
changed={'DoubledClause2011','MFDoubledClause2011','CurrentCellLabels2011','CurrentCellLabels2011Checks','CurrentCellConstruction2011','DoubledClause2011Checks'};out=[]
for n,v in G.items():
 short=n.rsplit('.',1)[-1]
 if short in changed:continue
 src=Path(v['source']);phases=[R/('phase-'+phase)/'DiophantineConsistency'/(short+'.olean') for phase in ['baseline','final']];assert all(p.exists() for p in phases),n;actual=[h(p) for p in phases];assert actual[0]==actual[1]==v['object_sha256'] and h(src)==v['source_sha256'],n
 matches=[r for s,o,r in known.get(n,[]) if s==v['source_sha256'] and o==v['object_sha256']];out.append({'module':n,'source':str(src),'source_sha256':h(src),'object_sha256':actual[0],'baseline_object':str(phases[0].resolve()),'final_object':str(phases[1].resolve()),'matching_receipts':matches,'source_newer':v.get('source_newer',False),'imports':v['local_imports']})
(R/'selected-pins.json').write_text(json.dumps(out,indent=2)+'\n');print('selected',len(out),'matched',sum(bool(x['matching_receipts']) for x in out),'historical boundary', [x['module'] for x in out if not x['matching_receipts']])
