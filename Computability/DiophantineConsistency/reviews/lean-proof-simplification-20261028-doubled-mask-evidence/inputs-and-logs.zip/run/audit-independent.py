import pathlib,json,hashlib,re
P=pathlib.Path('/tmp/doubled-mask-reuse-20261028'); root=pathlib.Path.cwd()
def h(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for fn in ['phase-records.json','mf-client-records.json']:
 rs=json.loads((P/fn).read_text()); assert len(rs)==(18 if fn.startswith('phase') else 4)
 for r in rs:
  phase,tag=r['phase'],r['tag']; cmd=r['command']; prefix='' if fn.startswith('phase') else 'mf-client-'; overlay=P/(('phase-' if not prefix else 'mf-client-')+phase)
  assert r['status']==0 and r['lean_path'].split(':')[0]==str(overlay),(phase,tag,'status/path')
  assert cmd[:4]==['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o']
  assert pathlib.Path(cmd[4]).read_text().strip()==r['timing'],(phase,tag,'timing')
  src=[pathlib.Path(x) for x in cmd if x.endswith('.lean')]; assert len(src)==1
  assert h(src[0])==r['source_sha256']==r['source_after'],(phase,tag,'source')
  log=P/f'{phase}-{prefix}{tag}.log'; assert h(log)==r['log_sha256'],(phase,tag,'log')
  if 'object_sha256' in r:
   obj=pathlib.Path(cmd[-1]); assert cmd[-2]=='-o' and obj.is_relative_to(overlay)
   assert h(obj)==r['object_sha256'] and obj.stat().st_size==r['object_bytes'],(phase,tag,'object')
 print(fn,'checked',len(rs),'records, source/object/log hashes, path and timing text')
graph=json.loads((P/'graph.json').read_text()); pins=json.loads((P/'selected-pins.json').read_text()); nodes=graph['nodes']; assert len(nodes)==70 and len(pins)==64
for name,node in nodes.items():
 src=root/node['source']; assert h(src)==node['source_sha256'],name
 for dep in node['local_imports']: assert dep in nodes,(name,dep)
for p in pins:
 name=p['module']; assert name in nodes
 assert h(root/p['source'])==p['source_sha256']==nodes[name]['source_sha256'],name
 for phase in ('baseline','final'):
  selected=P/('phase-'+phase)/(name.replace('.','/')+'.olean')
  assert selected.resolve()==pathlib.Path(p[phase+'_object']).resolve(),(name,phase,selected.resolve(),p[phase+'_object'])
  assert h(selected)==p['object_sha256'],(name,phase)
print('graph/pins:',len(nodes),'node sources and edges;',len(pins),'pinned object paths, source hashes and paired object hashes')
a=(P/'baseline-axioms.log').read_bytes();b=(P/'final-axioms.log').read_bytes();assert a==b
for n in ['mask.eq_1','mask_iff']: assert n.encode() in a
print('axiom logs identical, mask equation materialized')
a=set((P/'baseline-imports.log').read_text().splitlines());b=set((P/'final-imports.log').read_text().splitlines());print('import addition',sorted(b-a),'import removal',sorted(a-b))
