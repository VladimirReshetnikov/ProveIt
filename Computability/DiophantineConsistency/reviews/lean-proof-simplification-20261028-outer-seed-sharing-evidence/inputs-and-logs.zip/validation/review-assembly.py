from pathlib import Path
import hashlib,json
R=Path('/tmp/outer-seed-bound-sharing');plan=json.loads((R/'assembly-plan.json').read_text());rows=json.loads((R/'assembly-builds.json').read_text());h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bad=[]
if [x['module'] for x in rows]!=plan['rebuild'][:len(rows)]:bad.append('rebuild order')
for x in rows:
 n=x['module'];name=n.split('.')[-1];src=Path(plan['nodes'][n]['source']);obj=R/'assembly-common/DiophantineConsistency'/(name+'.olean');log=R/('assembly-'+name+'.log');tm=R/('assembly-'+name+'.time');cmd=x['command']
 if x['status']!=0:bad.append((n,'status'))
 if h(src)!=x['source_sha256'] or h(src)!=x['source_after'] or h(src)!=plan['nodes'][n]['source_sha256']:bad.append((n,'source'))
 if not obj.exists() or h(obj)!=x['object_sha256']:bad.append((n,'object'))
 if not log.exists() or h(log)!=x['log_sha256'] or tm.read_text().strip()!=x['timing']:bad.append((n,'log/time'))
 if x['lean_path'].split(':')[0]!=str(R/'assembly-common') or str(src) not in cmd or str(obj) not in cmd:bad.append((n,'command/path'))
print('verified',len(rows),'of',len(plan['rebuild']),'bad',bad)
if bad:raise SystemExit(1)
