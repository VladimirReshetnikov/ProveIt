import DiophantineConsistency.ArithmeticConstructionBoundPell
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency
open ArithmeticBinaryPopulation ArithmeticOuterSeed ArithmeticConstructionBoundPell
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]

example (u R : V) (hu : 0 < u) (hodd : ∃ r, R = 2*r+1)
    (hpop : population R = 3*u+2) :
    ∃ s n eta zeta gamma : V, 0<s ∧ 0<n ∧ 0<eta ∧ 0<zeta ∧ 0<gamma ∧
      SeedRelations u R s n eta zeta gamma :=
  ArithmeticOuterSeed.outer_seed u R hu hodd hpop

example (u R : V) (hu : 0 < u) (hodd : ∃ r, R = 2*r+1)
    (hpop : population R = 3*u+2) :
    ∃ s n eta zeta gamma : V, 0<s ∧ 0<n ∧ 0<eta ∧ 0<zeta ∧ 0<gamma ∧
      SeedRelations u R s n eta zeta gamma ∧ s*Exp.exp u^3 ≤ Ys R :=
  ArithmeticConstructionBoundPell.outer_seed_bound u R hu hodd hpop
