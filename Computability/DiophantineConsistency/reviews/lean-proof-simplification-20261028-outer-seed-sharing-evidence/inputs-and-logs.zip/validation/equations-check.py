from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path('/tmp/outer-seed-bound-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=os.environ.copy();records=[]
def run(phase,tag,src):
 e=env.copy();e['LEAN_PATH']=str(R/(phase+'-lib'))+':'+env.get('LEAN_PATH','');log=R/(phase+'-'+tag+'.log');tm=R/(phase+'-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false',str(src)];pre=h(src);t=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=e)
 d={'phase':phase,'tag':tag,'command':cmd,'lean_path':e['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip()};records.append(d);(R/'equations-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,p.returncode,round(d['seconds'],2),flush=True)
 if p.returncode or pre!=d['source_after']:raise SystemExit(1)
for p in ['baseline','final']:run(p,'names-equations',R/'names-equations.lean')
parse=lambda p:sorted(set(x.removeprefix('DECL ') for x in p.read_text().splitlines() if x.startswith('DECL ')))
a=parse(R/'baseline-names-equations.log');b=parse(R/'final-names-equations.log');removed=sorted(set(a)-set(b));added=sorted(set(b)-set(a));(R/'equations-names-comparison.json').write_text(json.dumps({'baseline':a,'final':b,'removed':removed,'added':added},indent=2)+'\n');print('equation-enumerated declarations',len(a),'removed',removed,'added',added,flush=True)
if removed:raise SystemExit(2)
defs=['DiophantineConsistency.ArithmeticOuterSeed.SeedRelations']+['DiophantineConsistency.ArithmeticConstructionBoundPell.'+x for x in ['Ys','As','Bs','Ps','Gs','Fs','Is','Us']];probe=R/'axioms-equations.lean';probe.write_text('import DiophantineConsistency.ArithmeticConstructionBoundPell\n'+''.join('#print equations '+n+'\n' for n in defs)+''.join('#print axioms '+n+'\n' for n in a))
for p in ['baseline','final']:run(p,'axioms-equations',probe)
if (R/'baseline-axioms-equations.log').read_bytes()!=(R/'final-axioms-equations.log').read_bytes():print('materialized equation reports differ',flush=True);raise SystemExit(3)
print('materialized equations and all old declaration axioms match',flush=True)
