import DiophantineConsistency.ArithmeticConstructionBoundPell
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticOuterSeed).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticConstructionBoundPell).isPrefixOf n then
      logInfo m!"DECL {n}"
