from pathlib import Path
import hashlib,json
R=Path('/tmp/outer-seed-bound-sharing');base=Path('/tmp/arithmetic-shared-literal/fresh/lib');old=R/'assembly-common/FirstOrder';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();packet=Path('/tmp/foundation-ha-current-transfer-root-peer-gx4g2m1q/packet.json');data=json.load(open(packet));records=[]
for x in data['modules']:
 n=x['module']
 if not n.startswith(('FirstOrder.','PAHF.')):continue
 src=Path(x['source']);obj=base/(n.replace('.','/')+'.olean');assert src.is_file() and obj.is_file() and h(src)==x['source_sha256'] and h(obj)==x['object_sha256'],n
 records.append({'module':n,'source':str(src),'source_sha256':h(src),'object':str(obj.resolve()),'object_sha256':h(obj),'receipt':str(packet)})
x=json.load(open('/tmp/arithmetic-shared-literal/summary.json'))['refresh']['PACore'];assert h(x['source'])==x['source_sha256'] and h(x['object'])==x['object_sha256'];records.append({'module':'PAHF.PACore','source':x['source'],'source_sha256':x['source_sha256'],'object':x['object'],'object_sha256':x['object_sha256'],'receipt':'/tmp/arithmetic-shared-literal/summary.json'});overlap=old/'Fol.olean';other=base/'FirstOrder/Fol.olean';assert h(overlap)==h(other);(R/'assembly-pahf-pins.json').write_text(json.dumps({'objects':records,'firstorder_overlap':{'module':'FirstOrder.Fol','previous_sha256':h(overlap),'selected_sha256':h(other)},'earlier_failure':'assembly-first/assembly-HAProofs.log'},indent=2)+'\n');print('pinned PAHF/FirstOrder objects',len(records))
