from pathlib import Path
import hashlib,json,re
R=Path('/tmp/outer-seed-bound-sharing');g=json.load(open(R/'assembly-plan.json'));old={x['module']:x for x in json.load(open(R/'assembly-reused.json'))};built={x['module']:x for x in json.load(open(R/'assembly-builds2.json'))};phase=json.load(open(R/'assembly-phase-records.json'));targets={(x['phase'],x['tag']):x for x in phase};seed={(x['phase'],x['tag']):x for x in json.load(open(R/'phase-records.json'))};h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for p in ['baseline','final']:
 for n,v in g['nodes'].items():
  obj=R/(p+'-assembly')/(n.replace('.','/')+'.olean');src=(R/('baseline' if p=='baseline' else 'source')/'DiophantineConsistency/ArithmeticOuterSeed.lean') if n=='DiophantineConsistency.ArithmeticOuterSeed' else Path(v['source']);assert src.is_file() and obj.is_file(),n
  sh=h(src);oh=h(obj);expected=seed[(p,'ArithmeticOuterSeed')]['source_sha256'] if n=='DiophantineConsistency.ArithmeticOuterSeed' else v['source_sha256'];assert sh==expected,n
  if n=='DiophantineConsistency.ArithmeticOuterSeed':r=seed[(p,'ArithmeticOuterSeed')]; provenance='phase-records.json (target)';assert oh==r['object_sha256'] and r['status']==0
  elif n=='DiophantineConsistency.ArithmeticConstructionAssembly':r=targets[(p,'target')];provenance='assembly-phase-records.json (client)';assert oh==r['object_sha256'] and r['status']==0
  elif n in built:r=built[n];provenance='assembly-builds2.json';assert sh==r['source_sha256'] and oh==r['object_sha256'] and r['status']==0
  else:r=old[n];provenance='assembly-reused.json';assert sh==r['source_sha256'] and oh==r['object_sha256']
  imports=[]
  for line in src.read_text().splitlines():
   m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
   if m:imports.extend(x for x in m.group(1).split() if x.startswith('DiophantineConsistency.') and x in g['nodes'])
  assert imports==v['imports'],n
  records.append({'phase':p,'module':n,'source':str(src),'source_sha256':sh,'object':str(obj.resolve()),'object_sha256':oh,'imports':imports,'provenance':provenance})
(R/'assembly-final-pins.json').write_text(json.dumps(records,indent=2)+'\n');print('verified',len(records),'phase/local source-object pins')
