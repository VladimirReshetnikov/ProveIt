from pathlib import Path
import os,json,time,hashlib,subprocess
R=Path('/tmp/outer-seed-bound-sharing');root=Path('Computability/DiophantineConsistency/Lean');common=R/'common';base=R/'assembly-common';ns=base/'DiophantineConsistency';ns.mkdir(parents=True,exist_ok=True);plan=json.load(open(R/'assembly-plan.json'));nodes=plan['nodes'];old={x['module']:x for x in json.load(open(R/'prereq2-records.json'))};h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in ['Foundation','FirstOrder','BusyBeaver']:
 p=base/n
 if not p.exists():p.symlink_to((common/n).resolve(),target_is_directory=True)
reuse=[]
for mod in plan['prior_prereqs']:
 name=mod.rsplit('.',1)[-1];p=Path(nodes[mod]['source']);o=common/'DiophantineConsistency'/(name+'.olean');r=old[mod];assert r['status']==0 and h(p)==r['source_sha256']==nodes[mod]['source_sha256'] and h(o)==r['object_sha256'],mod;q=ns/o.name
 if not q.exists() and not q.is_symlink():q.symlink_to(o.resolve())
 reuse.append({'module':mod,'source_sha256':h(p),'object_sha256':h(o),'object':str(o.resolve()),'provenance':'prereq2-records.json'})
(R/'assembly-reused.json').write_text(json.dumps(reuse,indent=2)+'\n');env=os.environ.copy();env['LEAN_PATH']=str(base)+':'+env.get('LEAN_PATH','');previous={x['module']:x for x in json.load(open(R/'assembly-first/records.json')) if x['status']==0};records=[];print('reusing',len(reuse),'project prerequisites; building',len(plan['rebuild']),flush=True)
for mod in plan['rebuild']:
 name=mod.rsplit('.',1)[-1];src=Path(nodes[mod]['source']);out=ns/(name+'.olean');old=previous.get(mod)
 if old and h(src)==old['source_sha256'] and out.exists() and h(out)==old['object_sha256']:
  d={'module':mod,'status':0,'provenance':'assembly-first','source_sha256':h(src),'object_sha256':h(out)};records.append(d);(R/'assembly-builds2.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'reused',flush=True);continue
 log=R/('assembly-'+name+'.log');tm=R/('assembly-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];pre=h(src);t=time.monotonic()
 if pre!=nodes[mod]['source_sha256']:print('source changed',mod,flush=True);raise SystemExit(2)
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'module':mod,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(out) if out.exists() else None};records.append(d);(R/'assembly-builds2.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,round(d['seconds'],2),flush=True)
 if p.returncode or pre!=d['source_after']:raise SystemExit(1)
