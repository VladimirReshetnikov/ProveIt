from pathlib import Path
import json,re,hashlib
R=Path('/tmp/outer-seed-bound-sharing');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean')];seen={};order=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');p=next((x/(rel+'.lean') for x in roots if (x/(rel+'.lean')).is_file()),None)
 if not p:return
 im=[]
 for line in p.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:im.extend([d for d in m.group(1).split() if d.startswith(('DiophantineConsistency.','BusyBeaver.'))])
 seen[n]={'source':str(p),'source_sha256':sha(p),'imports':im}
 for d in im:visit(d)
 order.append(n)
for n in ['ArithmeticOuterSeed','ArithmeticConstructionBoundPell']:visit('DiophantineConsistency.'+n)
(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n');print('nodes',len(seen),'dc',sum(x.startswith('DiophantineConsistency.') for x in seen),'busy',sum(x.startswith('BusyBeaver.') for x in seen))
for n in order:
 if n.startswith('DiophantineConsistency.'):print(n)
