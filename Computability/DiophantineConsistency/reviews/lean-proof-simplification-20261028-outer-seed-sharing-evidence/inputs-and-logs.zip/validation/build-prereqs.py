from pathlib import Path
import os,json,time,hashlib,subprocess
R=Path('/tmp/outer-seed-bound-sharing');out=R/'common';ns=out/'DiophantineConsistency';ns.mkdir(parents=True,exist_ok=True);base=Path('/tmp/fin-one-more/ArithmeticPellRecurrence/final/lib')
for n in ['Foundation','FirstOrder','BusyBeaver']:
 p=out/n
 if not p.exists():p.symlink_to((base/n).resolve(),target_is_directory=True)
g=json.load(open(R/'graph.json'));env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env.get('LEAN_PATH','');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[]
for mod in g['order']:
 name=mod.split('.')[-1]
 if name in ['ArithmeticOuterSeed','ArithmeticConstructionBoundPell']:continue
 src=Path(g['nodes'][mod]['source']);obj=ns/(name+'.olean');log=R/('prereq-'+name+'.log');tm=R/('prereq-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(obj)];pre=h(src);t=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 x={'module':mod,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(obj) if obj.exists() else None};rec.append(x);(R/'prereq-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,p.returncode,round(x['seconds'],2),flush=True)
 if p.returncode or pre!=x['source_after'] or pre!=g['nodes'][mod]['source_sha256']:raise SystemExit(1)
