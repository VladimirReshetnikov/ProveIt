from pathlib import Path
R=Path('/tmp/outer-seed-bound-sharing');src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
for n in ['ArithmeticOuterSeed','ArithmeticConstructionBoundPell']:(R/'baseline/DiophantineConsistency'/(n+'.lean')).write_bytes((src/(n+'.lean')).read_bytes())
b=(src/'ArithmeticConstructionBoundPell.lean').read_text();outer=(src/'ArithmeticOuterSeed.lean').read_text();start=b.index('theorem outer_seed_bound ');end=b.index('\n/-! ### Sizes of the outer-seed coordinates',start);body=b[start:end];body=body.replace('theorem outer_seed_bound ','theorem outer_seed_with_size ',1).replace('s*Exp.exp u^3 ≤ Ys R := by','s*Exp.exp u^3 ≤ power (Exp.exp R + 1) R := by',1).replace('have hYbound : s*Exp.exp u^3 ≤ Ys (2*r+1) := by\n    rw [hY\', Ys, ← hX]','have hYbound : s*Exp.exp u^3 ≤ power (Exp.exp (2*r+1) + 1) (2*r+1) := by\n    rw [hY\', ← hX]',1).replace('calc Y ≤ Y*(2*power X r) := le_self_mul h2p','calc Y ≤ Y*(2*power X r) := le_mul_of_one_le_right (by simp) h2p',1)
assert '≤ Ys ' not in body and 'le_self_mul' not in body
starto=outer.index('theorem outer_seed ');endo=outer.index('\nend DiophantineConsistency.ArithmeticOuterSeed',starto);orig=outer[starto:endo];pos=orig.index(' := by');header=orig[:pos];wrapper=header+''' := by
  obtain ⟨s,n,eta,zeta,gamma,hs,hn,he,hz,hg,hseed,_⟩ :=
    outer_seed_with_size u R hu hodd hpop
  exact ⟨s,n,eta,zeta,gamma,hs,hn,he,hz,hg,hseed⟩
''';outer=outer[:starto]+body+'\n\n/-- The outer Pell seed without its optional size bound. -/\n'+wrapper+outer[endo:]
old=b[start:end];idx=old.index(' := by');head=old[:idx];b=b[:start]+head+''' := by
  simpa only [Ys] using ArithmeticOuterSeed.outer_seed_with_size u R hu hodd hpop
'''+b[end:];(R/'source/DiophantineConsistency/ArithmeticOuterSeed.lean').write_text(outer);(R/'source/DiophantineConsistency/ArithmeticConstructionBoundPell.lean').write_text(b)
print('line count',len((src/'ArithmeticOuterSeed.lean').read_text().splitlines())+len((src/'ArithmeticConstructionBoundPell.lean').read_text().splitlines()),'->',len(outer.splitlines())+len(b.splitlines()))
