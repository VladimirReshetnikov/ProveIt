from pathlib import Path
import os,json,hashlib,time,subprocess
R=Path('/tmp/outer-seed-bound-sharing');source=R/'axioms-added.lean';log=R/'final-axioms-added2.log';tm=R/'final-axioms-added2.time';env=os.environ.copy();env['LEAN_PATH']=str(R/'final-lib')+':'+env.get('LEAN_PATH','');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false',str(source)];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();t=time.monotonic()
with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
d={'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':h(source),'log_sha256':h(log),'timing':tm.read_text().strip(),'target_object_sha256':h(R/'final-lib/DiophantineConsistency/ArithmeticOuterSeed.olean')};(R/'added-record.json').write_text(json.dumps(d,indent=2)+'\n');print('added declarations',p.returncode,flush=True)
if p.returncode:raise SystemExit(p.returncode)
