from pathlib import Path
import re,json,hashlib
R=Path('/tmp/outer-seed-bound-sharing');p=json.load(open(R/'assembly-plan.json'));nodes=p['nodes'];prior=json.load(open('/tmp/fin-one-simplification/trace-full-classified.json'));root=Path('Computability/BusyBeaver/Lean');base=R/'assembly-common';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();seen={};missing=[]
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');src=root/(rel+'.lean');obj=base/(rel+'.olean')
 if not src.is_file():missing.append((n,'source'));return
 if not obj.is_file():missing.append((n,'object'));return
 d=prior.get(n);source_sha=h(src);object_sha=h(obj);match=bool(d and d['source_sha256']==source_sha and d['object_sha256']==object_sha)
 if not match:missing.append((n,'no exact prior source/object pin'))
 imports=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:imports.extend(x for x in m.group(1).split() if x.startswith('BusyBeaver.'))
 seen[n]={'source':str(src),'source_sha256':source_sha,'object':str(obj.resolve()),'object_sha256':object_sha,'imports':imports,'receipt_match':match}
 for x in imports:visit(x)
seeds=set()
for n,v in nodes.items():
 for line in Path(v['source']).read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:seeds.update(x for x in m.group(1).split() if x.startswith('BusyBeaver.'))
for n in sorted(seeds):visit(n)
(R/'assembly-busy-pins.json').write_text(json.dumps({'seeds':sorted(seeds),'nodes':seen,'missing_or_unmatched':missing},indent=2)+'\n');print('BusyBeaver dependencies',len(seen),'unmatched',len(missing));print(missing[:10])
