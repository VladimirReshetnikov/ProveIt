from pathlib import Path
import re,json,hashlib
R=Path('/tmp/outer-seed-bound-sharing');root=Path('Computability/DiophantineConsistency/Lean');bases=[R/'common',Path('/tmp/fin-one-simplification/trace-full-fresh'),Path('/tmp/fin-one-more/shared'),Path('/tmp/kernel-eval-rewrite/shared'),Path('/tmp/list-getd-sharing-20261028/cell-fresh'),Path('/tmp/ha-implication-reuse-20261028/base'),Path('.lake/build/lib/lean')];seen={};order=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def visit(n):
 if n in seen:return
 p=root/(n.replace('.','/')+'.lean')
 if not p.is_file():return
 deps=[]
 for line in p.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:
   for d in m.group(1).split():
    if d.startswith('DiophantineConsistency.') and (root/(d.replace('.','/')+'.lean')).is_file():deps.append(d)
 candidates=[]
 for b in bases:
  o=b/(n.replace('.','/')+'.olean')
  if o.is_file():candidates.append({'path':str(o.resolve()),'sha256':h(o.resolve())})
 seen[n]={'source':str(p),'source_sha256':h(p),'imports':deps,'candidate_objects':candidates}
 for d in deps:visit(d)
 order.append(n)
for n in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:visit('DiophantineConsistency.'+n)
missing=[n for n,v in seen.items() if not v['candidate_objects']];(R/'client-inventory.json').write_text(json.dumps({'roots':['ArithmeticConstructionAssembly','ArithmeticConstructionBound'],'scanned_overlays':[str(x) for x in bases],'nodes':seen,'order':order,'missing_from_scanned_overlays':missing,'note':'Candidate presence is not a provenance or freshness claim.'},indent=2)+'\n');print('local modules',len(seen),'missing from scanned overlays',len(missing))
