import os,pathlib,json
R=pathlib.Path('/tmp/outer-seed-bound-sharing');targets=['ArithmeticTilingWord','ArithmeticPackingCells','ArithmeticRankForcing2011','ArithmeticController','ArithmeticConstructionUnit','ArithmeticConstructionVariation','ArithmeticConstructionAssembly','ArithmeticConstructionZero','ArithmeticCurrentSentence2011','ArithmeticLocalNormalization'];res={n:[] for n in targets};dirs=[];errors=[]
with os.scandir('/tmp') as it:
 for e in it:
  try:
   if e.is_dir(follow_symlinks=False) and not e.name.startswith(('gowers','Pip','tmp','lean-','snap-')):dirs.append(pathlib.Path(e.path))
  except OSError as ex:errors.append(str(ex))
for d in dirs:
 for branch in ['lib/DiophantineConsistency','overlay/DiophantineConsistency','final/DiophantineConsistency','final/overlay/DiophantineConsistency','final-fresh/DiophantineConsistency','shared/DiophantineConsistency']:
  base=d/branch
  try:
   if not base.is_dir():continue
   for n in targets:
    p=base/(n+'.olean')
    if p.is_file():res[n].append(str(p.resolve()))
  except OSError as ex:errors.append(str(ex))
(R/'targeted-client-cache-search.json').write_text(json.dumps({'roots_scanned':len(dirs),'results':res,'access_errors':errors,'initial_failure':'PermissionError probing /tmp/snap-private-tmp; excluded snap dirs on retry'},indent=2)+'\n');print('roots scanned',len(dirs),'access errors',len(errors));print('\n'.join(f'{n}: {len(v)} '+str(v[:3]) for n,v in res.items()))
