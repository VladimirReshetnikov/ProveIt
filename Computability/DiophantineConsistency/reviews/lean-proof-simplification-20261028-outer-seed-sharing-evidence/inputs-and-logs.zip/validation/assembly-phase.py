from pathlib import Path
import os,json,hashlib,time,subprocess,re
R=Path('/tmp/outer-seed-bound-sharing');base=R/'assembly-common';root=Path('Computability/DiophantineConsistency/Lean');src=root/'DiophantineConsistency/ArithmeticConstructionAssembly.lean';env=os.environ.copy();h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[];plan=json.load(open(R/'assembly-plan.json'));assert h(src)==plan['nodes']['DiophantineConsistency.ArithmeticConstructionAssembly']['source_sha256']
for phase in ['baseline','final']:
 outroot=R/(phase+'-assembly');ns=outroot/'DiophantineConsistency';ns.mkdir(parents=True,exist_ok=True)
 for name in ['Foundation','FirstOrder','BusyBeaver','PAHF']:
  p=outroot/name
  if not p.exists():p.symlink_to((base/name).resolve(),target_is_directory=True)
 for p in (base/'DiophantineConsistency').iterdir():
  q=ns/p.name
  if p.suffix=='.olean' and not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 p=ns/'ArithmeticOuterSeed.olean';p.unlink(missing_ok=True);p.symlink_to((R/(phase+'-lib/DiophantineConsistency/ArithmeticOuterSeed.olean')).resolve())
def run(phase,tag,source,output=None,allow_failure=False):
 e=env.copy();e['LEAN_PATH']=str(R/(phase+'-assembly'))+':'+env.get('LEAN_PATH','');log=R/(phase+'-assembly-'+tag+'.log');tm=R/(phase+'-assembly-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root if output else R),str(source)]
 if output:output.unlink(missing_ok=True);cmd+=['-o',str(output)]
 pre=h(source);t=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=e)
 d={'phase':phase,'tag':tag,'command':cmd,'lean_path':e['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(source),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(output) if output and output.exists() else None};records.append(d);(R/'assembly-phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,p.returncode,round(d['seconds'],2),flush=True)
 if (p.returncode and not allow_failure) or pre!=d['source_after']:raise SystemExit(1)
for p in ['baseline','final']:run(p,'target',src,R/(p+'-assembly/DiophantineConsistency/ArithmeticConstructionAssembly.olean'))
s=src.read_text();decl=re.findall(r'^(?:@\[[^\n]*\]\s*)?(?:noncomputable\s+)?(?:theorem|lemma|def|abbrev|instance|structure|inductive)\s+([\w\']+)',s,re.M);probe=R/'assembly-axioms.lean';probe.write_text('import DiophantineConsistency.ArithmeticConstructionAssembly\n'+''.join('#print axioms DiophantineConsistency.ArithmeticConstructionAssembly.'+n+'\n' for n in decl))
for p in ['baseline','final']:run(p,'axioms',probe)
if (R/'baseline-assembly-axioms.log').read_bytes()!=(R/'final-assembly-axioms.log').read_bytes():raise SystemExit('assembly axiom reports differ')
for p in ['baseline','final']:run(p,'broader-bound-attempt',root/'DiophantineConsistency/ArithmeticConstructionBound.lean',R/(p+'-assembly/DiophantineConsistency/ArithmeticConstructionBound.olean'),allow_failure=True)
print('assembly client builds and axioms passed',flush=True)
