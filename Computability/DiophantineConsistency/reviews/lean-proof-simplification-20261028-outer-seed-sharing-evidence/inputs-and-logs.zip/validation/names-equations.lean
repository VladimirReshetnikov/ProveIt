import DiophantineConsistency.ArithmeticConstructionBoundPell
open Lean Elab Command
#print equations DiophantineConsistency.ArithmeticOuterSeed.SeedRelations
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.Ys
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.As
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.Bs
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.Ps
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.Gs
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.Fs
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.Is
#print equations DiophantineConsistency.ArithmeticConstructionBoundPell.Us
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticOuterSeed).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticConstructionBoundPell).isPrefixOf n then
      logInfo m!"DECL {n}"
