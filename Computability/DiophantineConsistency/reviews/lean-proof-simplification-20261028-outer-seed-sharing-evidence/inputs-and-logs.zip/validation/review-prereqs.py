from pathlib import Path
import hashlib,json
R=Path('/tmp/outer-seed-bound-sharing');g=json.loads((R/'graph.json').read_text());nodes=g['nodes'];rs=json.loads((R/'prereq2-records.json').read_text());old={x['module']:x for x in json.loads((R/'first-pass/records.json').read_text())};plan=json.loads((R/'affected-plan.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bad=[]
expected=set(nodes)-{'DiophantineConsistency.ArithmeticOuterSeed','DiophantineConsistency.ArithmeticConstructionBoundPell'}
if {r['module'] for r in rs}!=expected:bad.append('prerequisite set mismatch')
for x in rs:
 n=x['module'];name=n.split('.')[-1];p=Path(nodes[n]['source']);o=R/'common/DiophantineConsistency'/(name+'.olean')
 if not p.exists() or sha(p)!=x['source_sha256'] or sha(p)!=nodes[n]['source_sha256']:bad.append((n,'source'))
 if not o.exists() or sha(o)!=x['object_sha256']:bad.append((n,'object'))
 if x['status']!=0:bad.append((n,'status'))
 if x['provenance']=='first-pass':
  z=old.get(n);l=R/'first-pass'/('prereq-'+name+'.log');tm=R/'first-pass'/('prereq-'+name+'.time')
  if n in plan['affected'] or not z or z['status'] or z['source_sha256']!=x['source_sha256'] or z['object_sha256']!=x['object_sha256']:bad.append((n,'prior reuse'))
  if not l.exists() or sha(l)!=z['log_sha256'] or not tm.exists() or tm.read_text().strip()!=z['timing']:bad.append((n,'prior log/time'))
 else:
  l=R/('prereq2-'+name+'.log');tm=R/('prereq2-'+name+'.time');cmd=x['command'];src=[Path(a) for a in cmd if a.endswith('.lean')];out=Path(cmd[-1]);
  if len(src)!=1 or sha(src[0])!=x['source_sha256'] or x['source_after']!=x['source_sha256'] or not out.exists() or sha(out)!=x['object_sha256']:bad.append((n,'command source/output'))
  if x['lean_path'].split(':')[0]!=str(R/'common'):bad.append((n,'leanpath'))
  if not l.exists() or sha(l)!=x['log_sha256'] or not tm.exists() or tm.read_text().strip()!=x['timing']:bad.append((n,'log/time'))
print('total',len(rs),'rebuilt',sum(x['provenance']=='rebuilt' for x in rs),'reused',sum(x['provenance']=='first-pass' for x in rs),'failures',bad)
if bad:raise SystemExit(1)
