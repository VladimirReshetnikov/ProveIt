from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/outer-seed-bound-sharing');T=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bad=[]
def ck(b,m):
 if not b:bad.append(m)
for n in ['ArithmeticOuterSeed','ArithmeticConstructionBoundPell']:
 b=R/'baseline/DiophantineConsistency'/(n+'.lean');src=T/(n+'.lean');old=subprocess.check_output(['git','show','HEAD:'+str(src)]);ck(b.read_bytes()==old==src.read_bytes(),n+' baseline matches HEAD/worktree')
for fn in ['phase-records.json','equations-records.json']:
 records=json.loads((R/fn).read_text());print(fn,'count',len(records))
 for x in records:
  phase,tag,cmd=x['phase'],x['tag'],x['command'];log=R/(phase+'-'+tag+'.log');tm=R/(phase+'-'+tag+'.time');src=[Path(y) for y in cmd if y.endswith('.lean') and Path(y).is_file()];expected=1 if tag.startswith('client-') else 0;ck(x['status']==expected,phase+' '+tag+' expected status');ck(x['lean_path'].split(':')[0]==str(R/(phase+'-lib')),phase+' '+tag+' path');ck(len(src)==1 and H(src[0])==x['source_sha256']==x['source_after'],phase+' '+tag+' source');ck(log.exists() and H(log)==x['log_sha256'],phase+' '+tag+' log');ck(tm.exists() and tm.read_text().strip()==x['timing'],phase+' '+tag+' time');
  if x.get('object_sha256'):
   i=len(cmd)-1-cmd[::-1].index('-o');out=Path(cmd[i+1]);ck(out.exists() and H(out)==x['object_sha256'],phase+' '+tag+' object')
for t in ['ArithmeticOuterSeed','ArithmeticConstructionBoundPell','axioms','axioms-equations']:
 a=R/('baseline-'+t+'.log');b=R/('final-'+t+'.log');ck(a.read_bytes()==b.read_bytes(),t+' matching logs');print(t,'paired warning count',a.read_text().count('warning:'))
# Verify expected pre-elaboration direct-client failures instead of claiming passes.
for p in ['baseline','final']:
 a=(R/(p+'-client-ArithmeticConstructionAssembly.log')).read_text();b=(R/(p+'-client-ArithmeticConstructionBound.log')).read_text();ck('ArithmeticTilingWord.olean' in a,p+' Assembly blocker');ck('ArithmeticConstructionAssembly.olean' in b,p+' Bound blocker')
compare=json.loads((R/'equations-names-comparison.json').read_text());parse=lambda phase:{x.removeprefix('DECL ') for x in (R/(phase+'-names-equations.log')).read_text().splitlines() if x.startswith('DECL ')};a=parse('baseline');b=parse('final');ck(a==set(compare['baseline']) and b==set(compare['final']) and len(a)==48,'equations enumeration');ck(b-a=={'DiophantineConsistency.ArithmeticOuterSeed.outer_seed_with_size','DiophantineConsistency.ArithmeticOuterSeed.SeedRelations.congr_simp'} and not a-b,'new names');probe=R/'axioms-equations.lean';reported=set(re.findall(r'^#print axioms\s+(\S+)',probe.read_text(),re.M));ck(reported==a,'all old probed');print('old materialized name count',len(a))
# Actual added probe separately records both new names and standard three axioms.
v=json.loads((R/'added-record.json').read_text());cmd=v['command'];src=[Path(x) for x in cmd if x.endswith('.lean') and Path(x).exists()];lg=R/'final-axioms-added2.log';tm=R/'final-axioms-added2.time';ck(v['status']==0 and v['lean_path'].split(':')[0]==str(R/'final-lib'),'added probe status/path');ck(len(src)==1 and H(src[0])==v['source_sha256'] and H(lg)==v['log_sha256'] and tm.read_text().strip()==v['timing'],'added probe inputs');text=lg.read_text();
for n in b-a:ck("'"+n+"' depends on axioms: [propext,\n Classical.choice,\n Quot.sound]" in text,'added axiom '+n)
# Both phase overlays use precisely the checked 25 prerequisite objects.
prereqs=json.loads((R/'prereq2-records.json').read_text());ck(len(prereqs)==25,'25 prereqs');
for x in prereqs:
 n=x['module'].split('.')[-1]
 for phase in ['baseline','final']:
  obj=R/(phase+'-lib')/'DiophantineConsistency'/(n+'.olean');ck(obj.exists() and H(obj)==x['object_sha256'],phase+' selected prereq '+n)
print('failures:',bad)
if bad:raise SystemExit(1)
