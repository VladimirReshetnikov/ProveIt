from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path('/tmp/outer-seed-bound-sharing');common=R/'common';repo=Path('Computability/DiophantineConsistency/Lean');env=os.environ.copy();h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[]
names=['ArithmeticOuterSeed','ArithmeticConstructionBoundPell']
for phase in ['baseline','final']:
 lib=R/(phase+'-lib');ns=lib/'DiophantineConsistency';ns.mkdir(parents=True,exist_ok=True)
 for dep in ['Foundation','FirstOrder','BusyBeaver']:
  q=lib/dep
  if not q.exists():q.symlink_to((common/dep).resolve(),target_is_directory=True)
 for p in (common/'DiophantineConsistency').iterdir():
  q=ns/p.name
  if p.suffix=='.olean' and not q.exists():q.symlink_to(p.resolve())
def run(phase,tag,src,root,out=None,allow_failure=False):
 envp=env.copy();envp['LEAN_PATH']=str(R/(phase+'-lib'))+':'+env.get('LEAN_PATH','');log=R/(phase+'-'+tag+'.log');tm=R/(phase+'-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(src)]
 if out:out.unlink(missing_ok=True);cmd+=['-o',str(out)]
 pre=h(src);t=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=envp)
 x={'phase':phase,'tag':tag,'command':cmd,'lean_path':envp['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(out) if out and out.exists() else None};rec.append(x);(R/'phase-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,tag,p.returncode,round(x['seconds'],2),flush=True)
 if (p.returncode and not allow_failure) or pre!=x['source_after']:raise SystemExit(1)
for phase in ['baseline','final']:
 root=R/('baseline' if phase=='baseline' else 'source')
 for n in names:run(phase,n,root/'DiophantineConsistency'/(n+'.lean'),root,R/(phase+'-lib/DiophantineConsistency')/(n+'.olean'))
 run(phase,'names',R/'names.lean',R)
parse=lambda p:sorted(set(x.removeprefix('DECL ') for x in p.read_text().splitlines() if x.startswith('DECL ')))
old=parse(R/'baseline-names.log');new=parse(R/'final-names.log');removed=sorted(set(old)-set(new));added=sorted(set(new)-set(old));(R/'names-comparison.json').write_text(json.dumps({'baseline':old,'final':new,'removed':removed,'added':added},indent=2)+'\n');print('declarations',len(old),'removed',removed,'added',added,flush=True)
if removed:raise SystemExit(2)
probe=R/'axioms.lean';probe.write_text('import DiophantineConsistency.ArithmeticConstructionBoundPell\n'+''.join('#print axioms '+n+'\n' for n in old));newprobe=R/'axioms-new.lean';newprobe.write_text('import DiophantineConsistency.ArithmeticConstructionBoundPell\n#print axioms DiophantineConsistency.ArithmeticOuterSeed.outer_seed_with_size\n')
for phase in ['baseline','final']:run(phase,'axioms',probe,R)
if (R/'baseline-axioms.log').read_bytes()!=(R/'final-axioms.log').read_bytes():print('axioms differ',flush=True);raise SystemExit(3)
run('final','axioms-new',newprobe,R)
for phase in ['baseline','final']:
 for n in ['ArithmeticConstructionAssembly','ArithmeticConstructionBound']:
  run(phase,'client-'+n,repo/'DiophantineConsistency'/(n+'.lean'),repo,R/(phase+'-lib/DiophantineConsistency')/(n+'.olean'),allow_failure=True)
print('completed, old axioms identical',flush=True)
