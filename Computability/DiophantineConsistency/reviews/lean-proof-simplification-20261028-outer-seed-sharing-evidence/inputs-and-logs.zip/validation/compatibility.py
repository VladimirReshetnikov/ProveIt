from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path('/tmp/outer-seed-bound-sharing');env=os.environ.copy();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[];src=R/'compatibility.lean'
for phase in ['baseline','final']:
 e=env.copy();e['LEAN_PATH']=str(R/(phase+'-lib'))+':'+env.get('LEAN_PATH','');log=R/(phase+'-compatibility.log');tm=R/(phase+'-compatibility.time');out=R/(phase+'-compatibility.olean');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(R),str(src),'-o',str(out)];pre=h(src);t=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=e)
 d={'phase':phase,'command':cmd,'lean_path':e['LEAN_PATH'],'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':h(src),'log_sha256':h(log),'timing':tm.read_text().strip(),'object_sha256':h(out) if out.exists() else None};records.append(d);(R/'compatibility-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,p.returncode,flush=True)
 if p.returncode or pre!=d['source_after']:print(log.read_text(),flush=True);raise SystemExit(1)
