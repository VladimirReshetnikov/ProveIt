from pathlib import Path
import re,json
base=Path('/tmp/list-getd-sharing-20261028'); root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); ov=base/'mf'/'DiophantineConsistency'; clients=['MFCurrentAdjacency2011','MFCurrentClause2011','MFCurrentCopyParity2011','MFCurrentPhaseParity2011','MFCurrentWordClause2011','MFCurrentWordCopies2011','MFCurrentWordHighMask2011','MFCurrentWordOrigin2011','MFCurrentWordPadding2011']; graph={}
def visit(n):
 if n in graph or not (root/(n+'.lean')).exists():return
 src=root/(n+'.lean');obj=ov/(n+'.olean');deps=re.findall(r'^import DiophantineConsistency\.(\w+)',src.read_text(),re.M); graph[n]={'deps':deps,'exists':obj.exists(),'source_newer':obj.exists() and src.stat().st_mtime_ns>obj.stat().st_mtime_ns}
 for d in deps:visit(d)
for n in clients:visit(n)
(base/'mf-client-graph.json').write_text(json.dumps(graph,indent=2));print('total',len(graph));print('missing', [n for n,v in graph.items() if not v['exists']]);print('source_newer', [n for n,v in graph.items() if v['source_newer']])
