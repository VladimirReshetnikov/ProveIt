from pathlib import Path
import json,re,subprocess,os,time,hashlib
base=Path('/tmp/list-getd-sharing-20261028');graph=json.loads((base/'cell-graph.json').read_text()); deps={k:re.findall(r'^import\s+(DiophantineConsistency(?:\.\w+)+)',Path(v['source']).read_text(),re.M) for k,v in graph.items()};dirty={'DiophantineConsistency.ArithmeticCellPhysical','DiophantineConsistency.CurrentKernelData2011'}
while True:
 nxt={k for k,ds in deps.items() if any(d in dirty for d in ds)}-dirty
 if not nxt:break
 dirty|=nxt
dirty.remove('DiophantineConsistency.ArithmeticCellLocal');ordered=[]
def visit(k):
 if k in ordered:return
 for x in deps[k]:
  if x in dirty:visit(x)
 ordered.append(k)
for k in sorted(dirty):visit(k)
dest=base/'cell-fresh'/'DiophantineConsistency';dest.mkdir(parents=True,exist_ok=True)
for f in (base/'cell'/'DiophantineConsistency').iterdir():
 d=dest/f.name
 if not d.exists() and not d.is_symlink():d.symlink_to(f)
env=os.environ.copy();env['LEAN_PATH']=str(base/'cell-fresh')+':'+env.get('LEAN_PATH','');records=[]
for k in ordered:
 src=Path(graph[k]['source']);out=dest/(k.split('.')[-1]+'.olean');log=base/('fresh-'+k.split('.')[-1]+'.log');
 if out.is_symlink():out.unlink()
 start=time.monotonic();r=subprocess.run(['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(out)],env=env,stdout=log.open('w'),stderr=subprocess.STDOUT);records.append({'module':k,'status':r.returncode,'seconds':round(time.monotonic()-start,3),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'object_sha256':hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None,'log':str(log)});(base/'cell-fresh-records.json').write_text(json.dumps(records,indent=2));print(k,r.returncode,records[-1]['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
