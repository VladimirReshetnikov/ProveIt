from pathlib import Path
import os,subprocess,time,json,hashlib
base=Path('/tmp/list-getd-sharing-20261028'); env=os.environ.copy(); inherited=env['LEAN_PATH']; rec=[]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(label,ov,src,output=None):
 e=env.copy();e['LEAN_PATH']=str(base/ov)+':'+inherited;cmd=['lean','-M6000','-j1','-DElab.async=false'];
 if output is not None:cmd+=['-R','Computability/DiophantineConsistency/Lean']
 cmd+=[str(src)]
 if output is not None:cmd+=['-o',str(output)]
 log=base/(label+'.log');t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);x={'label':label,'command':cmd,'lean_path':e['LEAN_PATH'],'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':digest(src),'log':str(log),'log_sha256':digest(log),'output_sha256':digest(output) if output is not None and output.exists() else None};rec.append(x);(base/'fresh-check-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(label,r.returncode,x['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for name,ov,module in [('normal-baseline-fresh','normal-baseline-fresh','CurrentHighDigits2011'),('normal-final-fresh','normal-fresh','CurrentHighDigits2011'),('cell-baseline-fresh','cell-baseline-fresh','ArithmeticCellLocal'),('cell-final-fresh','cell-fresh','ArithmeticCellLocal')]:
 run(name+'-axioms',ov,base/'source'/('Axioms'+module+'.lean'))
 if module=='ArithmeticCellLocal':run(name+'-generated-axioms',ov,base/'source'/'AxiomsLocalGenerated.lean')
for ov,mods in [('normal-fresh',['CurrentHighDigits2011Checks','CurrentClause2011','CurrentPolynomialWindow2011']),('cell-fresh',['ArithmeticCellLabels'])]:
 for m in mods:
  src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(m+'.lean');run('fresh-client-'+m,ov,src,base/('fresh-client-'+m+'.olean'))
for pair in [('normal-baseline-fresh-axioms.log','normal-final-fresh-axioms.log'),('cell-baseline-fresh-axioms.log','cell-final-fresh-axioms.log'),('cell-baseline-fresh-generated-axioms.log','cell-final-fresh-generated-axioms.log')]:
 a,b=(base/x for x in pair);print('identical',pair,a.read_bytes()==b.read_bytes(),flush=True)
 if a.read_bytes()!=b.read_bytes():raise SystemExit(1)
