from pathlib import Path
import os,re,subprocess,time,json,hashlib
base=Path('/tmp/list-getd-sharing-20261028');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); ov=base/'mf'/'DiophantineConsistency'
clients=['MFCurrentClause2011','MFCurrentCopyParity2011','MFCurrentPhaseParity2011']; deps={n:re.findall(r'^import DiophantineConsistency\.(\w+)',(root/(n+'.lean')).read_text(),re.M) for n in clients};order=[]
def visit(k):
 if k in order:return
 for dep in deps[k]:
  if dep in clients:visit(dep)
 order.append(k)
for n in clients:visit(n)
for n in clients:
 p=ov/(n+'.olean')
 if p.is_symlink():p.unlink()
env=os.environ.copy();env['LEAN_PATH']=str(base/'mf')+':'+env.get('LEAN_PATH','');rec=[]
for n in order:
 src=root/(n+'.lean');dst=ov/(n+'.olean');log=base/(n+'.final.log');start=time.monotonic();r=subprocess.run(['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(dst)],env=env,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'module':n,'status':r.returncode,'seconds':round(time.monotonic()-start,2),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'log':str(log)});(base/'mf-client-records.json').write_text(json.dumps(rec,indent=2));print(n,r.returncode,rec[-1]['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
