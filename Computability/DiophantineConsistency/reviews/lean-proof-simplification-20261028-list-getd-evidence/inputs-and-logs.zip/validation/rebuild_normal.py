from pathlib import Path
import json,re,subprocess,os,time,hashlib
base=Path('/tmp/list-getd-sharing-20261028'); graph=json.loads((base/'normal-graph.json').read_text()); deps={k:re.findall(r'^import\s+(DiophantineConsistency(?:\.\w+)+)',Path(v['source']).read_text(),re.M) for k,v in graph.items()}; dirty={k for k,v in graph.items() if v['source_newer']} | {'DiophantineConsistency.NativeRadixDigits'}
while True:
 nxt={k for k,ds in deps.items() if any(d in dirty for d in ds)}-dirty
 if not nxt:break
 dirty|=nxt
dirty.remove('DiophantineConsistency.CurrentHighDigits2011'); ordered=[]
def visit(k):
 if k in ordered:return
 for x in deps[k]:
  if x in dirty:visit(x)
 ordered.append(k)
for k in sorted(dirty):visit(k)
print('rebuild count',len(ordered),flush=True); env=os.environ.copy();env['LEAN_PATH']=str(base/'normal-fresh')+':'+str(base/'normal')+':'+env.get('LEAN_PATH',''); records=[]
previous={r['module']:r for r in json.loads((base/'fresh-records.json').read_text()) if r['status']==0}
for k in ordered:
 src=Path(graph[k]['source']); output=base/'normal-fresh'/(k.replace('.','/')+'.olean');output.parent.mkdir(parents=True,exist_ok=True);
 if k in previous and output.exists() and not output.is_symlink():
  records.append(previous[k]); continue
 if output.is_symlink():output.unlink()
 start=time.monotonic();log=base/('fresh-'+k.split('.')[-1]+'.log'); cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(output)];r=subprocess.run(cmd,env=env,stdout=log.open('w'),stderr=subprocess.STDOUT); record={'module':k,'status':r.returncode,'seconds':round(time.monotonic()-start,3),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'object_sha256':hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None,'log':str(log)};records.append(record);(base/'fresh-records.json').write_text(json.dumps(records,indent=2));print(k,r.returncode,record['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
