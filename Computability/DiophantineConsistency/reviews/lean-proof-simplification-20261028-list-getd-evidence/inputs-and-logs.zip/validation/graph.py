from pathlib import Path
import re,hashlib,json
root=Path('Computability/DiophantineConsistency/Lean'); out=Path('/tmp/list-getd-sharing-20261028')
def dig(m,seen,overlay):
 if m in seen:return
 src=root/(m.replace('.','/')+'.lean')
 if not src.exists():return
 b=src.read_bytes(); obj=overlay/(m.replace('.','/')+'.olean')
 if not obj.exists():obj=Path('.lake/build/lib/lean')/(m.replace('.','/')+'.olean')
 seen[m]={'source_sha256':hashlib.sha256(b).hexdigest(),'source':str(src),'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest() if obj.exists() else None,'source_newer':src.stat().st_mtime_ns>obj.stat().st_mtime_ns if obj.exists() else None}
 for n in re.findall(r'^import\s+(DiophantineConsistency(?:\.\w+)+)',b.decode(),re.M):dig(n,seen,overlay)
for target,ov in [('CurrentHighDigits2011','normal'),('MFCurrentHighDigits2011','mf'),('ArithmeticCellLocal','cell')]:
 seen={};dig('DiophantineConsistency.'+target,seen,out/ov); (out/(ov+'-graph.json')).write_text(json.dumps(seen,indent=2)+'\n'); stale=[(k,v['object']) for k,v in seen.items() if v['source_newer'] or v['object'] is None];print(target,len(seen),'newer/missing',len(stale),stale[:15])
