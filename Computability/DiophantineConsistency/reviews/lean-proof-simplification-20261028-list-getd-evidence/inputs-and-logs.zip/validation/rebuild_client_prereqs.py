from pathlib import Path
import re,os,subprocess,time,json,hashlib
base=Path('/tmp/list-getd-sharing-20261028');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');ov=base/'normal-fresh'/'DiophantineConsistency';clients=['CurrentHighDigits2011Checks','CurrentClause2011','CurrentPolynomialWindow2011'];graph={}
def visit(n):
 if n in graph:return
 src=root/(n+'.lean')
 if not src.exists():return
 deps=re.findall(r'^import DiophantineConsistency\.(\w+)',src.read_text(),re.M);graph[n]=deps
 for dep in deps:visit(dep)
for n in clients:visit(n)
def obj(n):return ov/(n+'.olean')
dirty={n for n,ds in graph.items() if obj(n).exists() and any(d in graph and obj(d).exists() and obj(d).stat().st_mtime_ns>obj(n).stat().st_mtime_ns for d in ds)}
while True:
 nxt={n for n,ds in graph.items() if any(d in dirty for d in ds)}-dirty
 if not nxt:break
 dirty|=nxt
dirty-=set(clients);dirty.discard('CurrentHighDigits2011');order=[]
def walk(n):
 if n in order:return
 for d in graph[n]:
  if d in dirty:walk(d)
 order.append(n)
for n in sorted(dirty):walk(n)
print('prerequisites',order,flush=True);env=os.environ.copy();env['LEAN_PATH']=str(base/'normal-fresh')+':'+env.get('LEAN_PATH','');rec=[]
for n in order:
 src=root/(n+'.lean');out=obj(n);log=base/('client-prereq-'+n+'.log');
 if out.is_symlink():out.unlink()
 t=time.monotonic();r=subprocess.run(['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(out)],env=env,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'module':n,'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'object_sha256':hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});(base/'client-prereq-records.json').write_text(json.dumps(rec,indent=2));print(n,r.returncode,rec[-1]['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
