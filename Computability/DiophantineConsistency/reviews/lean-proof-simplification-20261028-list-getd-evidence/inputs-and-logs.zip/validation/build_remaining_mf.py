from pathlib import Path
import json,subprocess,os,time,hashlib
base=Path('/tmp/list-getd-sharing-20261028');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');ov=base/'mf'/'DiophantineConsistency';graph=json.loads((base/'mf-client-graph.json').read_text());order=[]
def visit(k):
 if k in order or k not in graph:return
 for d in graph[k]['deps']:visit(d)
 order.append(k)
for k in graph:visit(k)
env=os.environ.copy();env['LEAN_PATH']=str(base/'mf')+':'+env.get('LEAN_PATH','');rec=[]
for n in order:
 out=ov/(n+'.olean')
 if out.exists():continue
 if out.is_symlink():out.unlink()
 src=root/(n+'.lean');log=base/(n+'.closure.log');start=time.monotonic();r=subprocess.run(['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(out)],env=env,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'module':n,'status':r.returncode,'seconds':round(time.monotonic()-start,2),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'log':str(log)});(base/'mf-closure-records.json').write_text(json.dumps(rec,indent=2));print(n,r.returncode,rec[-1]['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
