from pathlib import Path
import json,hashlib
r=Path('/tmp/origin-block-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();xs=json.loads((r/'records.json').read_text());good=[x for x in xs if x['status']==0];failed=[x for x in xs if x['status']!=0];assert len(good)==6 and len(failed)==1
for x in good:
 assert x['source_before']==x['source_after']==h(x['source']);o=Path(x['command'][-1]);log=r/f"{x['phase']}-{x['module']}.log";tm=Path(x['command'][x['command'].index('-o')+1]);assert not o.is_symlink() and x['object_sha256']==h(o) and x['log_sha256']==h(log) and x['time']==tm.read_text()
 for m,d in x['inputs'].items():
  rel=m.replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p.resolve())==d['object'] and d['object_before']==d['object_after']==h(p)
  if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
  if m.endswith('ArithmeticPackingBlocks'):assert d['object']==str(r/x['phase']/'DiophantineConsistency/ArithmeticPackingBlocks.olean')
 print(x['phase'],x['module'],'inputs',len(x['inputs']),'verified')
f=failed[0];assert h(r/'failed-rewrite-reconstructed.lean')==f['source_before']==f['source_after'];print('failed source reconstructed hash matches; original log overwritten')
probes=json.loads((r/'census-records.json').read_text());
for x in probes:
 log=r/f"{x['phase']}-{x['name']}.log";assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['direct_before']==x['direct_after']==h(x['direct_object']) and x['log_sha256']==h(log);print('probe',x['phase'],x['name'],'verified')
for n in ['interfaces','private']:assert (r/f'base-{n}.log').read_bytes()==(r/f'final-{n}.log').read_bytes();print(n,'identical')
print('total',len(good),'success',sum(len(x['inputs']) for x in good),'direct input occurrences')
