from pathlib import Path
import hashlib,json,os,re,subprocess
r=Path('/tmp/origin-block-sharing');root=Path('Computability/DiophantineConsistency/Lean');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for phase in ['base','final']:
 for n in ['ArithmeticPackingBlocks','ArithmeticPacking','ArithmeticControllerData']:
  src=r/'src/DiophantineConsistency'/f'{n}.lean' if phase=='final' and n=='ArithmeticPackingBlocks' else root/'DiophantineConsistency'/f'{n}.lean';srcroot=r/'src' if src.is_relative_to(r/'src') else root;env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':/tmp/mask-ins-simplify/final:'+lp;roots=[Path(x) for x in env['LEAN_PATH'].split(':')];inputs={};before=sha(src)
  for name in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
   obj=next((x/(name.replace('.','/')+'.olean') for x in roots if (x/(name.replace('.','/')+'.olean')).is_file()),None)
   if obj is None:raise RuntimeError('missing '+name)
   s=root/(name.replace('.','/')+'.lean');inputs[name]={'object':str(obj.resolve()),'object_before':sha(obj),'source':str(s) if s.is_file() else None,'source_before':sha(s) if s.is_file() else None}
  out=r/phase/'DiophantineConsistency'/f'{n}.olean';out.unlink(missing_ok=True);log=r/f'{phase}-{n}.log';tm=r/f'{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(out)]
  with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in inputs.values():
   x['object_after']=sha(Path(x['object']));x['source_after']=sha(Path(x['source'])) if x['source'] else None
  row={'phase':phase,'module':n,'source':str(src),'source_before':before,'source_after':sha(src),'inputs':inputs,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':p.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.is_file() else None};records.append(row);(r/'records.json').write_text(json.dumps(records,indent=2));print(phase,n,p.returncode,row['time'].strip(),flush=True)
  if p.returncode or before!=row['source_after'] or any(x['object_before']!=x['object_after'] or x['source_before']!=x['source_after'] for x in inputs.values()):raise SystemExit(1)
