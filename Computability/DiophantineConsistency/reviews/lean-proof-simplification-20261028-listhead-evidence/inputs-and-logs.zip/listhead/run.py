from pathlib import Path
import subprocess,time,json,hashlib,sys
p=Path('/tmp/object-listhead-proof-20261028'); pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; mode=sys.argv[1]
if mode=='prep':
 items=[(Path(s).stem,s,True) for s in json.loads((p/'preparation-order.json').read_text())]
elif mode=='baseline': items=[('target',pre+'ObjectListHead.lean',True),('axioms',str(p/'axioms.lean'),False)]
elif mode=='final': items=[('target',pre+'ObjectListHead.lean',True),('axioms',str(p/'axioms.lean'),False),('client',pre+'ObjectDivision.lean',False),('focus','Computability/DiophantineConsistency/Lean/checks/ObjectGuardedWire.lean',False)]
else: raise SystemExit('bad mode')
records=[]
for name,source,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj: argv+=['-o',str(p/'overlay/DiophantineConsistency'/((name if mode=='prep' else 'ObjectListHead')+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/object-listhead-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic(); r=subprocess.run(cmd,capture_output=True); elapsed=time.monotonic()-start
 log=p/(mode+'-'+name+'.log'); log.write_bytes(r.stdout+r.stderr)
 records.append({'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode: raise SystemExit(r.returncode)
