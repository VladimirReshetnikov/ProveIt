from pathlib import Path
import subprocess,time,json,hashlib
root=Path.cwd(); out=Path('/tmp/composition-cleanup-20261028'); pref='Computability/DiophantineConsistency/Lean/'
items=[('compose',pref+'DiophantineConsistency/ComposeRepresentation.lean','ComposeRepresentation'),('direct',pref+'DiophantineConsistency/DirectComposition.lean','DirectComposition'),('compatibility',str(out/'Compatibility.lean'),None),('focus',pref+'checks/DirectComposition.lean',None)]+[(n,pref+'DiophantineConsistency/'+n+'.lean',None) for n in ['RepresentationSize','CantorRepresentation','GraphBranching','ArithmeticNonzero','BoundedForallSize']]
records=[]
for name,source,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj: argv+=['-o',str(out/'overlay/DiophantineConsistency'/(obj+'.olean'))]
 command=['lake','env','bash','-c','export LEAN_PATH="/tmp/composition-cleanup-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 started=time.monotonic(); proc=subprocess.run(command,capture_output=True); elapsed=time.monotonic()-started
 log=out/('replay-'+name+'.log'); log.write_bytes(proc.stdout+proc.stderr)
 records.append({'name':name,'argv':command,'exit_status':proc.returncode,'elapsed_seconds':elapsed,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (out/'replay-results.json').write_text(json.dumps({'records':records},indent=2)+'\n')
 if proc.returncode: raise SystemExit(proc.returncode)
