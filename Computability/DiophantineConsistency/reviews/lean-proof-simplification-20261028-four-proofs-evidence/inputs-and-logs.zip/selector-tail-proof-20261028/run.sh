#!/usr/bin/env bash
set -u
work=/tmp/selector-tail-proof-20261028
stage="$1"
module="$2"
source="Computability/DiophantineConsistency/Lean/DiophantineConsistency/$module.lean"
if [ "$module" = axioms ]; then source="$work/axioms.lean"; fi
out="$work/overlay/DiophantineConsistency/$module.olean"
if [ "$module" = axioms ]; then
  /usr/bin/time -o "$work/$stage-$module.time" -f '%e %x' env LEAN_PATH="$work/overlay:$LEAN_PATH" lean "$source" > "$work/$stage-$module.log" 2>&1
else
  /usr/bin/time -o "$work/$stage-$module.time" -f '%e %x' env LEAN_PATH="$work/overlay:$LEAN_PATH" lean -o "$out" "$source" > "$work/$stage-$module.log" 2>&1
fi
code=$?
printf '%s %s %s\n' "$stage" "$module" "$code"
exit "$code"
