from pathlib import Path
import os,subprocess,json,time,sys,hashlib
root=Path('/home/codex/.codex/worktrees/62ff/Proofs')
rundir=Path('/tmp/helical-simplification-20261028')
lean=subprocess.check_output(['lake','env','which','lean'],cwd=root,text=True).strip()
path=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=root,text=True).strip()
env=os.environ.copy();env['LEAN_PATH']=str(rundir/'overlay')+':'+path
name=sys.argv[1]
source=root/'Computability/DiophantineConsistency/Lean/DiophantineConsistency'/f'{name}.lean'
if name=='audit': source=rundir/'audit.lean'
cmd=[lean,str(source)]
if len(sys.argv)>2 and sys.argv[2]=='object': cmd += ['-o',str(rundir/'overlay/DiophantineConsistency'/f'{name}.olean')]
start=time.time()
p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
end=time.time(); label=sys.argv[3] if len(sys.argv)>3 else name
(rundir/f'{label}.log').write_bytes(p.stdout)
(rundir/f'{label}.json').write_text(json.dumps({'command':cmd,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'lean_path':env['LEAN_PATH'],'exit':p.returncode,'duration_seconds':end-start,'output_sha256':hashlib.sha256(p.stdout).hexdigest()},indent=2)+'\n')
print(label,'exit',p.returncode,'seconds',round(end-start,2), flush=True)
sys.exit(p.returncode)
