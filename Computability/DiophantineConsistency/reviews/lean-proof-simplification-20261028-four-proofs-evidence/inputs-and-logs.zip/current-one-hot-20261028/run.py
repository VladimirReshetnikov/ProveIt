from pathlib import Path
import hashlib,json,subprocess,sys,time
D=Path('/tmp/current-one-hot-20261028'); R='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; T=R+'CurrentCellLabels2011.lean'
mode=sys.argv[1]
graph=json.load(open('/tmp/diophantine-oct28-combined-protected.json')); seen=set(); todo=[T]
while todo:
 p=todo.pop()
 if p in seen: continue
 seen.add(p); todo.extend(graph['project_import_edges'][p])
protected={p:graph['files'][p] for p in seen}; protected.update({p:graph['files'][p] for p in ['lakefile.toml','lake-manifest.json','lean-toolchain','Computability/DiophantineConsistency/equation.tex','Computability/DiophantineConsistency/equation.pdf']})
def rec(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
expected=rec(T)['sha256']
assert expected==(rec(D/'original.lean')['sha256'] if mode=='baseline' else '1778957260679b540f7468f88e34c754e98dfcd7be11effc7eb4787e23e6ed22')
protected[T]=expected
def guard():
 for p,h in protected.items(): assert rec(p)['sha256']==h,('changed source',p)
 assert subprocess.check_output(['git','-C','.lake/packages/mathlib','rev-parse','HEAD'],text=True).strip()==graph['mathlib_head']
 assert not subprocess.check_output(['git','-C','.lake/packages/mathlib','status','--porcelain','--untracked-files=no'],text=True).strip()
guard()
if mode=='baseline': steps=[('target',T,'CurrentCellLabels2011'),('axioms',str(D/'axioms.lean'),None)]
elif mode=='final':
 steps=[('target',T,'CurrentCellLabels2011')]+[(n,R+n+'.lean',n) for n in ['CurrentSouthShift2011','CurrentDecodedWindow2011','CurrentCellConstruction2011']]+[('focus',R+'CurrentCellLabels2011Checks.lean',None),('axioms',str(D/'axioms.lean'),None)]
else: raise SystemExit('invalid mode')
state={'mode':mode,'source_pins':protected,'mathlib_head':graph['mathlib_head'],'records':[],'complete':False}; statepath=D/(mode+'-commands.json');assert not statepath.exists(); statepath.write_text(json.dumps(state,indent=2)+'\n')
for name,p,output in steps:
 expected_source=rec(p); cmd=['lake','env','lean','-M6000','-j1','-DElab.async=false',p]
 if output: cmd+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+output+'.olean']
 log=D/(mode+'-'+name+'.log'); timing=D/(mode+'-'+name+'.time'); started=time.monotonic()
 with log.open('wb') as stream: result=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(timing),*cmd],stdout=stream,stderr=subprocess.STDOUT)
 assert rec(p)==expected_source
 row={'tag':name,'argv':cmd,'source':expected_source,'actual_exit_status':result.returncode,'elapsed_monotonic_seconds':time.monotonic()-started,'log':rec(log),'timing':rec(timing)}
 if output and result.returncode==0:row['object']=rec(cmd[-1])
 state['records'].append(row); statepath.write_text(json.dumps(state,indent=2)+'\n');print(mode,name,'exit',result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
guard();state['complete']=True
if mode=='final': state['axioms_byte_identical']=(D/'baseline-axioms.log').read_bytes()==(D/'final-axioms.log').read_bytes()
statepath.write_text(json.dumps(state,indent=2)+'\n');print(mode,'PASS',len(steps),'pins',len(protected),flush=True)
