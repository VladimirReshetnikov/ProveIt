from pathlib import Path
import hashlib,json,re,subprocess
p=Path('/dev/shm/cell-no-carry'); repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');n='ArithmeticCellTransfer';h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
a=(p/'baseline/DiophantineConsistency'/f'{n}.lean').read_text(); b=(p/'final/DiophantineConsistency'/f'{n}.lean').read_text(); st='theorem noCarry_cast'; end='theorem std_of_le'
assert b==(repo/f'{n}.lean').read_text()
rel=str(repo/f'{n}.lean')
assert subprocess.check_output(['git','show','798054eafe^:'+rel]).decode()==a
assert subprocess.check_output(['git','show','798054eafe:'+rel]).decode()==b
print('Commit 798054eafe and parent match final and baseline snapshots')
assert a[:a.index(st)]==b[:b.index(st)] and a[a.index(end):]==b[b.index(end):]
assert a[a.index(st):a.index(':= by',a.index(st))]==b[b.index(st):b.index(':= by',b.index(st))]
print('Only noCarry_cast proof differs; statement and final workspace match')
allrows={}
for phase in ['baseline','final','refreshed-baseline','refreshed-final','pinned-baseline','pinned-final','refresh']:
 rows=json.loads((p/f'{phase}-records.json').read_text()); allrows[phase]=rows
 for r in rows:
  assert r['status']==0 and r['before']==r['after']==h(r['source']) and r['object_sha256']==h(r['object']) and r['log_sha256']==h(r['log']) and Path(r['command'][2]).read_text()==r['time']
  for d in r['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d.get('source_before'):assert d['source_before']==d['source_after']==h(d['source'])
   fn=d['module'].replace('.','/')+'.olean';first=next(Path(q)/fn for q in r['LEAN_PATH'].split(':') if (Path(q)/fn).exists());assert first.resolve()==Path(d['path']).resolve()
  for d in r.get('extra_inputs',[]):
   assert d['before']==d['after']==h(d['path'])
   fn='DiophantineConsistency/'+d['module']+'.olean';first=next(Path(q)/fn for q in r['LEAN_PATH'].split(':') if (Path(q)/fn).exists());assert first.resolve()==Path(d['path']).resolve()
 print(phase,len(rows),'source, first direct inputs, output/log/time hashes pass')
for phase in ['baseline','final']:
 assert [(x['module'],x['object_sha256']) for x in allrows[phase]]==[(x['module'],x['object_sha256']) for x in allrows['refreshed-'+phase]]==[(x['module'],x['object_sha256']) for x in allrows['pinned-'+phase]]
print('Refreshed and extra-transitive-pinned outputs match each respective original-lane output; paired client bytes differ')
for phase in ['baseline','final','refreshed-baseline','refreshed-final']:
 rows=json.loads((p/f'{phase}-probes.json').read_text()); assert len(rows)==4
 for r in rows:
  assert r['status']==0 and r['source_before']==r['source_after']==h(r['source']) and r['objects_before']==r['objects_after']==[h(x) for x in r['objects']] and r['log_sha256']==h(r['log']) and r['time_sha256']==h(r['time'])
for phase in ['','refreshed-']:
 rows=json.loads((p/f'{phase}ArithmeticCellDecoding-probe-records.json').read_text()); assert len(rows)==8
 for r in rows:
  assert r['status']==0 and len(r['objects'])==2 and r['source_before']==r['source_after']==h(r['source']) and r['objects_before']==r['objects_after']==[h(x) for x in r['objects']] and r['log_sha256']==h(r['log'])
 for k in ['names','interfaces','simp','instances']:
  assert (p/f'{phase}baseline-ArithmeticCellDecoding-{k}.log').read_bytes()==(p/f'{phase}final-ArithmeticCellDecoding-{k}.log').read_bytes()
for k in ['simp','instances']:
 assert (p/f'refreshed-baseline-{k}.log').read_bytes()==(p/f'refreshed-final-{k}.log').read_bytes()
def blocks(s):
 return {re.match(r'DECL (\S+) TYPE ',c).group(1):c for c in re.split(r'(?=^DECL )',s,flags=re.M) if c.startswith('DECL ')}
x=blocks((p/'refreshed-baseline-interfaces.log').read_text()); y=blocks((p/'refreshed-final-interfaces.log').read_text()); gone='DiophantineConsistency.ArithmeticCellTransfer.noCarry_cast._proof_2'
assert x.keys()-y.keys()=={gone} and not y.keys()-x.keys() and all(x[k]==y[k] for k in x.keys()&y.keys())
print('Target removes only generated _proof_2; other reports and registrations match')
print('Client both-object-pinned names/type/axioms/simp/instances match in both lanes')
print('PASS')
providers=[('ArithmeticBinaryCarry','/tmp/binary-half-direct/final-records.json'),('ArithmeticBinaryPopulation','/tmp/binary-half-direct/final-records.json'),('ArithmeticRepunit','/tmp/binary-half-direct/final-records.json'),('ArithmeticStandardCasts','/tmp/binary-half-direct/final-supplement-records.json'),('ArithmeticModularCancellation','/tmp/shared-modular-cancel/records.json'),('ArithmeticCellLocal','/tmp/high-digits-module-sharing/final-records.json'),('MFDoubledClause2011','/tmp/cell-construction-share/common-records.json')]
items={d['module'].split('.')[-1]:d for phase in ['refresh','pinned-baseline'] for row in allrows[phase] for d in row['direct_inputs'] if d.get('source_before')}
items.update({d['module']:d for row in allrows['pinned-baseline'] for d in row.get('extra_inputs',[]) if d['module']=='ArithmeticBinaryPopulation'})
for name,path in providers:
 d=items[name];source=d.get('source_before',h(repo/(name+'.lean')));records=json.loads(Path(path).read_text()); matches=[r for r in records if str(r.get('module',r.get('name',''))).split('.')[-1]==name and r.get('status')==0 and r.get('object_sha256')==d['before'] and r.get('source_sha256_before',r.get('source_sha256',r.get('source_before',r.get('before'))))==source]
 assert matches,(name,path)
 print('producer pair matches',name,path)
print('PROVIDER PASS')
