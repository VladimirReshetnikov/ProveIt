from pathlib import Path
import os,json,hashlib,subprocess,re,shutil,sys
r=Path('/dev/shm/cell-no-carry');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();lib=r/'objects-refreshed';lib.mkdir(exist_ok=True);subprocess.run(['cp','-as',str(r/'objects-final/DiophantineConsistency'),str(lib/'DiophantineConsistency')],check=True)
for n in ('ArithmeticBinaryCarry','ArithmeticBinaryPopulation'):
 p=lib/'DiophantineConsistency'/(n+'.olean');p.unlink(missing_ok=True);p.symlink_to(Path('/tmp/binary-half-direct/objects-final/DiophantineConsistency')/(n+'.olean'))
names=['ArithmeticWindowDigits','ArithmeticCyclicWord','ArithmeticCellLabels']
for n in names:(lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True)
base=json.load(open(r/'final-records.json'))[0]['LEAN_PATH'];env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+base;rows=[]
for n in names:
 src=w/(n+'.lean');inputs=[]
 for name in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());sp=w/(name.split('.')[-1]+'.lean');inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 out=lib/'DiophantineConsistency'/(n+'.olean');tm=r/('refresh-'+n+'.time');log=r/('refresh-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(w.parent),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};rows.append(rec);(r/'refresh-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
