from pathlib import Path
import json,hashlib,re
r=Path('/dev/shm/cell-no-carry');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();allrec={}
for lane in ('','refreshed-','pinned-'):
 allrec[lane]={}
 for phase in ('baseline','final'):
  rows=json.loads((r/(lane+phase+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticCellTransfer','ArithmeticCellDecoding'];rec={};allrec[lane][phase]=rec
  for x in rows:
   rec[x['module']]=x;assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
   assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
   for d in x['direct_inputs']:
    p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
    if d['module'].endswith('.ArithmeticCellTransfer'):assert d['before']==rec['ArithmeticCellTransfer']['object_sha256']
   for d in x.get('extra_inputs',[]):
    p=next(Path(q)/'DiophantineConsistency'/(d['module']+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(d['module']+'.olean')).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
   if x['module']=='ArithmeticCellDecoding':assert h(x['source'])==h(w/'ArithmeticCellDecoding.lean')
   print('PASS build',lane or 'original',phase,x['module'])
 for phase in ('baseline','final'):
  for n in ('ArithmeticCellTransfer','ArithmeticCellDecoding'):assert allrec[lane][phase][n]['object_sha256']==allrec[''][phase][n]['object_sha256']
for lane in ('','refreshed-'):
 for phase in ('baseline','final'):
  for p in json.loads((r/(lane+phase+'-probes.json')).read_text()):
   assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[allrec[lane][phase]['ArithmeticCellTransfer']['object_sha256']] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
 for p in json.loads((r/(lane+'ArithmeticCellDecoding-probe-records.json')).read_text()):
  phase=p['phase'];assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[allrec[lane][phase][n]['object_sha256'] for n in ('ArithmeticCellTransfer','ArithmeticCellDecoding')] and h(p['log'])==p['log_sha256']
 for n in ('names','interfaces','simp','instances'):assert (r/(lane+'baseline-ArithmeticCellDecoding-'+n+'.log')).read_bytes()==(r/(lane+'final-ArithmeticCellDecoding-'+n+'.log')).read_bytes()
 for n in ('simp','instances'):assert (r/(lane+'baseline-'+n+'.log')).read_bytes()==(r/(lane+'final-'+n+'.log')).read_bytes()
 def get(phase):return {a.split(' TYPE ',1)[0]:a for a in (r/(lane+phase+'-interfaces.log')).read_text().split('DECL ')[1:]}
 a,b=get('baseline'),get('final');assert set(a)-set(b)=={'DiophantineConsistency.ArithmeticCellTransfer.noCarry_cast._proof_2'} and set(b)-set(a)==set() and all(a[k]==b[k] for k in a.keys()&b.keys());print('PASS',lane or 'original','target/client probes')
refresh=json.load(open(r/'refresh-records.json'));assert [x['module'] for x in refresh]==['ArithmeticWindowDigits','ArithmeticCyclicWord','ArithmeticCellLabels']
for x in refresh:
 assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256']
 for d in x['direct_inputs']:
  assert d['before']==d['after']==h(d['path']) and (d['source'] is None or d['source_before']==d['source_after']==h(d['source']))
 print('PASS refreshed',x['module'])
providers={'ArithmeticStandardCasts':('/tmp/binary-half-direct/final-supplement-records.json','ArithmeticStandardCasts'),'ArithmeticModularCancellation':('/tmp/shared-modular-cancel/records.json','ArithmeticModularCancellation'),'ArithmeticBinaryCarry':('/tmp/binary-half-direct/final-records.json','ArithmeticBinaryCarry'),'ArithmeticBinaryPopulation':('/tmp/binary-half-direct/final-records.json','ArithmeticBinaryPopulation'),'ArithmeticRepunit':('/tmp/binary-half-direct/final-records.json','ArithmeticRepunit'),'ArithmeticCellLocal':('/tmp/high-digits-module-sharing/final-records.json','ArithmeticCellLocal'),'MFDoubledClause2011':('/tmp/cell-construction-share/common-records.json','MFDoubledClause2011')}
inputs={d['module'].split('.')[-1]:d for x in refresh for d in x['direct_inputs']};inputs.update({d['module'].split('.')[-1]:d for x in allrec['pinned-']['final'].values() for d in x['direct_inputs']});extra={d['module']:d for x in allrec['pinned-']['final'].values() for d in x['extra_inputs']}
for n,(p,m) in providers.items():
 xs=[x for x in json.load(open(p)) if x['module'].split('.')[-1]==m and x['status']==0];d=inputs.get(n) or extra[n];xs=[x for x in xs if x['object_sha256']==d['before']];assert xs;x=xs[-1];before=x.get('source_before',x.get('before',x.get('source_sha256')));after=x.get('source_after',x.get('after',x.get('source_sha256')));assert before==after==h(w/(n+'.lean'));print('PASS source-current prior provider',n,d['before'])
for n in ('ArithmeticWindowDigits','ArithmeticCyclicWord','ArithmeticCellLabels'):
 x=next(x for x in refresh if x['module']==n);d=inputs.get(n) or extra[n];assert x['object_sha256']==d['before'];print('PASS refreshed provider link',n)
print('PASS all checks; cached transitive closure not audited')
