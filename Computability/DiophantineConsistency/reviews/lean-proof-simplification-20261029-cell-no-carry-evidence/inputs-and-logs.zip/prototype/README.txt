CellTransfer no-carry cast

The candidate changes only noCarry_cast: it uses the existing equivalence
noCarry_iff to apply the bounded NoCarry hypothesis at every bit, eliminating
the artificial cutoff and separate high-bit proof. The original theorem,
NoCarry hypothesis, imports and data remain unchanged. Baseline/final source
SHA-256 4534b12453a22958d807c100c2f65cae68ee2e817f40aee3b144834395e8c21b /
40d89a21d612e26efd3316ab34a60fbbf4a4d970de9cb7a505745c68a5635026.
Baseline was current when built; the candidate is isolated. The original module
was introduced by Claude-coauthored commit f79467f544.

Three paired build lanes pass the target and its only tracked direct Lean
client, ArithmeticCellDecoding: the initial lane, refreshed lane and a replay
that additionally pins BinaryCarry, BinaryPopulation and WindowDigits first
provider paths and object hashes before and after each build. Records are
{baseline,final}-records.json, refreshed-{baseline,final}-records.json and
pinned-{baseline,final}-records.json. Each phase's target and client object
hashes match across all three lanes; the baseline and final client object bytes
differ. Paired target probes and both-object-pinned client probes were run in
both the initial and refreshed environments. The 71 client name/type/axiom
reports and global registrations match between phases. Target census reports
60 baseline and 59 final names; the generated public name
noCarry_cast._proof_2 disappears; every retained target name/type/axiom and the
33,296 global simp / 14,696 instance registrations match. A bounded git grep
of tracked Lean/Python files under Computability/DiophantineConsistency found
no references to that generated name; other languages, untracked files,
external and dynamic references remain untested. Identical reports do not show
proof-body or all persistent-extension equality.

The initial environment's post-build path sample resolves older BinaryCarry
object a338938c… with historical source edecfe3a…; this is not a contemporaneous
transitive input pin. The refreshed chain instead pins current-source
BinaryCarry 60c63e7b… and Population 05d52191…, whose producers are in
/tmp/binary-half-direct/final-records.json, and rebuilds source-current
WindowDigits, CyclicWord and the adopted CellLabels; refresh-records.json pins
their direct inputs. The later pinned lane records these three first-provider
objects around every build. These steps do not rebuild the full project,
Foundation or Mathlib closure; other downstream clients are untested.

Current-source direct StandardCasts and ModularCancellation match successful
producer records in /tmp/binary-half-direct/final-supplement-records.json and
/tmp/shared-modular-cancel/records.json. Refreshed WindowDigits imports the
current-source Repunit object from /tmp/binary-half-direct/final-records.json;
refreshed CellLabels inputs CellLocal and MFDoubledClause2011 match producer
records /tmp/high-digits-module-sharing/final-records.json and
/tmp/cell-construction-share/common-records.json. audit.py/.log verify those
associations, source/input/output hashes, probe comparisons and all three lanes.
Original target CPU pair 8.02/7.99 seconds and later timings are shared-load
samples rather than general benchmarks. Selected builds produce no warnings.
An exploratory broad git grep was interrupted without a retained log; the
bounded search described above completed. Outputs remain temporary in /dev/shm.
