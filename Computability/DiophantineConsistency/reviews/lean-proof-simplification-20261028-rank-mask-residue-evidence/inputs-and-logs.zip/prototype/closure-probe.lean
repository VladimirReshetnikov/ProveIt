import DiophantineConsistency.ArithmeticConstructionAssembly
open Lean Elab Command
run_cmd do
 let e ← getEnv
 for p in [`DiophantineConsistency.ArithmeticModularCancellation, `DiophantineConsistency.SplitKernelData59, `DiophantineConsistency.GapKernelData66] do
  let names := e.constants.toList.filter (fun (n, _) => p.isPrefixOf n)
  logInfo m!"NAMESPACE {p} COUNT {names.length}"
