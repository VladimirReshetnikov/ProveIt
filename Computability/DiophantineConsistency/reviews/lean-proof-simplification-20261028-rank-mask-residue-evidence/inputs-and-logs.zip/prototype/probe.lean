import DiophantineConsistency.ArithmeticRankForcing2011
set_option autoImplicit false
namespace DiophantineConsistency.ArithmeticRankForcing2011
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
attribute [local irreducible] CurrentMasks2011.lowPort
example (J j : V) (hJ : J = 8*j+1) : ((CurrentMasks2011.lowPort:V)*J+1)%4=3 := by
  have hv4 : J % 4 = 1 := by
    rw [hJ, show (8:V)*j+1 = 1+4*(2*j) by ring,
      mod_add_mul' _ _ (by norm_num), mod_eq_self_of_lt (by norm_num : (1:V)<4)]
  rw [mod_add (by norm_num : (0:V)<4), mod_mul (by norm_num : (0:V)<4), lowPort_mod_four, hv4]
  norm_num
end DiophantineConsistency.ArithmeticRankForcing2011
