from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/rank-mask-residue');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={};
path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRankForcing2011.lean'
for ref,phase in [('92cfb70d2d^','paired-baseline'),('92cfb70d2d','paired-final')]:
 data=subprocess.check_output(['git','show',ref+':'+path]);assert data==(R/'sources'/phase/'DiophantineConsistency/ArithmeticRankForcing2011.lean').read_bytes()
assert Path(path).read_bytes()==(R/'sources/paired-final/DiophantineConsistency/ArithmeticRankForcing2011.lean').read_bytes()
print('commit, parent and workspace verified')
def historic(p):return R/'sources/paired-baseline/DiophantineConsistency/ArithmeticRankForcing2011.lean' if Path(p).name=='ArithmeticRankForcing2011.lean' and not str(p).startswith(str(R/'sources')) else Path(p)
pri=json.loads(Path('/tmp/mask-ins-simplify/independent-direct-provider-audit.json').read_text());mask=next(x for x in json.loads(Path('/tmp/mask-ins-simplify/records.json').read_text()) if x['name']=='ArithmeticMaskConstants' and x['phase']=='final' and x['status']==0);mapping=json.loads(Path('/tmp/variation-tail-sharing/post-commit-provider-matches.json').read_text());variation=next(x for x in json.loads(Path('/tmp/variation-tail-sharing/refreshed2-final-records.json').read_text()) if x['module']=='ArithmeticConstructionVariation')
for ph in ['paired-baseline','paired-final']:
 for x in json.loads((R/f'{ph}-records.json').read_text()):
  n=x['module'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(historic(x['workspace']));
  for k in ['object','log','time']:assert x[k+'_sha256']==h(x[k])
  if ph=='paired-baseline' or n=='ArithmeticConstructionAssembly':assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';o=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(o)==d['path'] and str(o.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(o) and d['source_before']==d['source_after']==h(historic(d['source']));m=d['module'].split('.')[-1]
   if m=='ArithmeticRankForcing2011':assert d['resolved']==rows[ph,m]['object'] and d['object_before']==rows[ph,m]['object_sha256']
   elif n=='ArithmeticRankForcing2011':
    if m=='ArithmeticMaskConstants':assert (d['source_before'],d['object_before'])==(mask['before'],mask['object_sha256'])
    else:q=pri[d['module']];assert (d['source_before'],d['object_before'])==(q['source_sha256'],q['object_sha256']) and q['matching_prior_rows']
   elif m=='ArithmeticConstructionVariation':assert (d['source_before'],d['object_before'])==(variation['source_before'],variation['object_sha256'])
   else:assert any(v['module']==m and v['source']==d['source_before'] and v['object']==d['object_before'] and v['matches'] for v in mapping)
  rows[ph,n]=x;print('build',ph,n,x['timing'])
 for x in json.loads((R/f'{ph}-probes.json').read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticRankForcing2011']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
 x=json.loads((R/f'repeat-{ph}-records.json').read_text())[0];y=rows[ph,'ArithmeticRankForcing2011'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==y['source_before'] and x['object_sha256']==h(x['object'])==y['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']) and x['LEAN_PATH']==y['LEAN_PATH']
 for d,e in zip(x['direct_inputs'],y['direct_inputs']):assert d['module']==e['module'] and d['resolved']==e['resolved'] and d['object_before']==d['object_after']==h(d['path'])==e['object_before'] and d['source_before']==d['source_after']==h(historic(d['source']))==e['source_before']
 print('repeat',ph,x['timing'])
assert rows['paired-baseline','ArithmeticConstructionAssembly']['object_sha256']==rows['paired-final','ArithmeticConstructionAssembly']['object_sha256']
def decls(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decls('paired-baseline'),decls('paired-final');assert a==b and len(a)==5
for n in ['simp','instances']:
 a=(R/f'paired-baseline-{n}.log').read_bytes();b=(R/f'paired-final-{n}.log').read_bytes();assert a==b;print(n,len(a.splitlines()))
for x in json.loads((R/'cached-boundaries.json').read_text()):assert x['object_sha256']==h(x['object_path']) and x['current_source_sha256']==h(x['current_source']);print('cached boundary',x['module'],x['object_sha256'])
x=json.loads((R/'closure-probe-record.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(R/'closure-probe.log')
for d in x['objects']:assert d['before']==d['after']==h(d['path'])
assert (R/'closure-probe.log').read_text().splitlines()==['NAMESPACE DiophantineConsistency.ArithmeticModularCancellation COUNT 0','NAMESPACE DiophantineConsistency.SplitKernelData59 COUNT 0','NAMESPACE DiophantineConsistency.GapKernelData66 COUNT 0']
g=json.loads((R/'full-graph.json').read_text());assert not g['ambiguous_modules'] and all(h(historic(x['source']))==x['sha256'] for x in g['source_hashes'].values());im=g['imports'];assert all(re.findall(r'^import\s+([^\s]+)',historic(g['source_hashes'][n]['source']).read_text(),re.M)==v for n,v in im.items());root='DiophantineConsistency.ArithmeticConstructionAssembly'
def reach(n,t,seen):
 if n==t:return True
 if n in seen:return False
 seen.add(n);return any(reach(v,t,seen) for v in im.get(n,[]))
assert reach(root,'DiophantineConsistency.ArithmeticModularCancellation',set()) and not any(reach(root,'DiophantineConsistency.'+n,set()) for n in ['SplitKernelData59','GapKernelData66']);print('current local source graph nodes',len(im),'missing external',len(g['missing_modules']),'closure probe absence verified')
print('all checks passed')
