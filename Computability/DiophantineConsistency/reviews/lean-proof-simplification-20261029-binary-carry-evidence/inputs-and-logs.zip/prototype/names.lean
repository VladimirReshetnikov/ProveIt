import Lean.Elab.Command
import DiophantineConsistency.ArithmeticBinaryCarry
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticBinaryCarry).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticBinaryCarry" then
   logInfo m!"DECL {n}"
