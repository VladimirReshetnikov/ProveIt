from pathlib import Path
import os,json,hashlib,subprocess,sys
R=Path('/tmp/binary-carry-simplify');S=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); base=Path('/tmp/binary-half-reuse-20261028/final');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();phase=sys.argv[1]; src=R/phase/'DiophantineConsistency';lib=R/('objects-'+phase);src.mkdir(parents=True,exist_ok=True);lib.mkdir(exist_ok=True)
for q in base.iterdir():
 if not (lib/q.name).exists(): subprocess.run(['cp','-as',str(q),str(lib/q.name)],check=True)
for n in ('ArithmeticBinaryCarry','ArithmeticRankForcing','ArithmeticSaturation'):
 dest=src/(n+'.lean'); dest.write_bytes(((R/'src/DiophantineConsistency'/(n+'.lean')) if phase=='final' and n=='ArithmeticBinaryCarry' else S/(n+'.lean')).read_bytes());out=lib/'DiophantineConsistency'/(n+'.olean');out.unlink(missing_ok=True)
env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+str(base)+':'+env['LEAN_PATH'];rows=[]
for n in ('ArithmeticBinaryCarry','ArithmeticRankForcing','ArithmeticSaturation'):
 source=src/(n+'.lean'); imports=['DiophantineConsistency.ArithmeticBinaryPopulation'] if n=='ArithmeticBinaryCarry' else ['DiophantineConsistency.ArithmeticBinaryCarry'];inputs=[]
 for d in imports:
  p=next(Path(x)/(d.replace('.','/')+'.olean') for x in env['LEAN_PATH'].split(':') if (Path(x)/(d.replace('.','/')+'.olean')).is_file());inputs.append(dict(module=d,path=str(p),resolved=str(p.resolve()),before=h(p)))
 out=lib/'DiophantineConsistency'/(n+'.olean');log=R/(phase+'-'+n+'.log');tm=R/(phase+'-'+n+'.time');before=h(source);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M6000','-j1','-DElab.async=false','-R',str(R/phase),str(source),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 for d in inputs:d['after']=h(d['path'])
 row=dict(phase=phase,module=n,source=str(source),before=before,after=h(source),direct_inputs=inputs,LEAN_PATH=env['LEAN_PATH'],command=cmd,status=p.returncode,log=str(log),log_sha256=h(log),time=tm.read_text(),object=str(out),object_sha256=h(out) if out.exists() else None);rows.append(row);(R/(phase+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,p.returncode,row['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
