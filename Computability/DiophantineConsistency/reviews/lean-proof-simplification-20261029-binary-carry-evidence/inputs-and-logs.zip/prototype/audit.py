from pathlib import Path
import json,hashlib
r=Path('/tmp/binary-carry-simplify');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());provider=next(x for x in json.loads(Path('/tmp/binary-half-reuse-20261028/final-targets.json').read_text()) if x['tag']=='ArithmeticBinaryPopulation');assert provider['status']==0 and provider['source_sha256']==h(w/'ArithmeticBinaryPopulation.lean') and provider['object_sha256']==h('/tmp/binary-half-reuse-20261028/final/DiophantineConsistency/ArithmeticBinaryPopulation.olean') and provider['log_sha256']==h('/tmp/binary-half-reuse-20261028/final-ArithmeticBinaryPopulation.log');print('current-source Population provider and prior output receipt verified')
rows={}
for ph in ('baseline','final'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n!='ArithmeticBinaryCarry' or ph=='baseline':assert x['before']==h(w/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);y=provider if n=='ArithmeticBinaryCarry' else rows[ph,'ArithmeticBinaryCarry'];assert d['before']==y['object_sha256']
  rows[ph,n]=x; print(ph,n,x['time'].strip())
 for x in get(ph+'-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticBinaryCarry']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ('ArithmeticRankForcing','ArithmeticSaturation'):assert rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'];print(n,'client object identical')
for n in ('names','interfaces','simp','instances'):
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b;print(n,'identical',len(a.splitlines()),'lines')
assert (r/'baseline-names.log').read_text().count('DECL ')==14
print('success; Population build direct dependency input hashes and cached closure not established by old receipt')
