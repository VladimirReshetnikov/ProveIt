from pathlib import Path
import json,hashlib,subprocess
R=Path('/tmp/binary-carry-simplify');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticBinaryCarry.lean'
assert subprocess.check_output(['git','show','a3af2f89c7^:'+path])==(R/'baseline/DiophantineConsistency/ArithmeticBinaryCarry.lean').read_bytes()
assert subprocess.check_output(['git','show','a3af2f89c7:'+path])==(R/'src/DiophantineConsistency/ArithmeticBinaryCarry.lean').read_bytes()==Path(path).read_bytes()
print('parent, commit and current source verified')
p=next(x for x in json.loads(Path('/tmp/binary-half-reuse-20261028/final-targets.json').read_text()) if x['tag']=='ArithmeticBinaryPopulation');assert p['status']==0 and p['source_sha256']==h(W/'ArithmeticBinaryPopulation.lean') and p['object_sha256']==h('/tmp/binary-half-reuse-20261028/final/DiophantineConsistency/ArithmeticBinaryPopulation.olean') and p['log_sha256']==h('/tmp/binary-half-reuse-20261028/final-ArithmeticBinaryPopulation.log');print('Population current source, prior object and log match')
for ph in ['baseline','final']:
 for x in json.loads((R/(ph+'-records.json')).read_text()):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-'+n+'.time')).read_text()
  if ph=='baseline' or n!='ArithmeticBinaryCarry':assert x['before']==h(R/'baseline/DiophantineConsistency/ArithmeticBinaryCarry.lean' if n=='ArithmeticBinaryCarry' else W/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';first=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==h(first)
   if n=='ArithmeticBinaryCarry':assert d['before']==p['object_sha256']
   else:assert d['before']==rows[ph,'ArithmeticBinaryCarry']['object_sha256'] and d['resolved']==rows[ph,'ArithmeticBinaryCarry']['object']
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
 for x in json.loads((R/(ph+'-probes.json')).read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticBinaryCarry']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ['ArithmeticRankForcing','ArithmeticSaturation']:assert rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'];print('identical client',n)
for n,count in [('names',14),('simp',28971),('instances',13167)]:
 a=(R/('baseline-'+n+'.log')).read_bytes();b=(R/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==count;print(n,count)
assert (R/'baseline-interfaces.log').read_bytes()==(R/'final-interfaces.log').read_bytes();print('type/axiom reports match')
print('all checks passed')
