from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-binary-carry-evidence'; out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/binary-carry-simplify');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','final','src']:
 for p in sorted((R/phase).rglob('*.lean')):add('snapshots/'+str(p.relative_to(R)),p)
for name in ['binary-carry-independent-review.txt','binary-carry-independent-audit.py','binary-carry-independent-audit.log']:
 add('independent/'+name,I/name)
add('provider/final-targets.json',I/'binary-half-reuse-20261028/final-targets.json')
add('provider/final-ArithmeticBinaryPopulation.log',I/'binary-half-reuse-20261028/final-ArithmeticBinaryPopulation.log')
add('bundle/build-binary-carry-bundle.py',Path(__file__))
commit='a3af2f89c7c99436a415920dfe75c4e302c4ac39';parent='2fabba02e8c339bc3de45e1ace075be6cf0db686';rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticBinaryCarry.lean'
for phase,ref in [('baseline',parent),('final',commit)]:
 data=subprocess.check_output(['git','show',ref+':'+rel]);assert data==files['snapshots/'+phase+'/DiophantineConsistency/ArithmeticBinaryCarry.lean'];files['commit/'+phase+'.lean']=data
rel2='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticBinaryPopulation.lean';pop=subprocess.check_output(['git','show',commit+':'+rel2]);r=json.loads(files['provider/final-targets.json']);population=next(x for x in r if x['tag']=='ArithmeticBinaryPopulation');assert hashlib.sha256(pop).hexdigest()==population['source_sha256'];files['provider/ArithmeticBinaryPopulation.lean']=pop
review=files['independent/binary-carry-independent-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
h=lambda b:hashlib.sha256(b).hexdigest()
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Simplify binary carry boundary arguments',
 'validation':'Paired target, ArithmeticRankForcing and ArithmeticSaturation builds pass with identical client objects. All 14 target declaration/type/axiom reports, 28,971 default simp entries and 13,167 instances match. The direct BinaryPopulation source/object pair matches a prior successful receipt.',
 'limitations':['ArithmeticWindowDigits is another direct source client and was not rebuilt. Existing target linter warnings occur in both phases.','The prior BinaryPopulation receipt does not pin its direct Foundation/Mathlib dependencies. Other project and package inputs remain cached; no complete current-source closure rebuild is established.','An initial provisional setup failed because an empty overlay hid the Population provider; its log was overwritten by the later successful provisional run. That failure is described but its lost output cannot be independently checked.','One paired shared-load timing sample does not establish a general performance effect. Probes cover the target object and the explicitly enumerated environment entries, not every persistent extension.','The archive omits compiled objects; recorded object hashes are receipt claims and need the original external objects for independent byte checking.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
