import DiophantineConsistency.NativeBooleanRotation
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.NativeBooleanRotation).isPrefixOf n then
      logInfo m!"{n}"
