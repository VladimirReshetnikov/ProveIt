import DiophantineConsistency.NativeBooleanRotation
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n := `DiophantineConsistency.NativeBooleanRotation.rotation_le_half._proof_1
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
