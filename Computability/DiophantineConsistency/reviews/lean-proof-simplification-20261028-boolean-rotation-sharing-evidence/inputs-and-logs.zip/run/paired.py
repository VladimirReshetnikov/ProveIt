from pathlib import Path
import os,subprocess,hashlib,json
P=Path('/tmp/native-boolean-sharing');root=Path('Computability/DiophantineConsistency/Lean'); base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); rec=[]
for phase in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(P/phase)+':'+base
 for name in ('MFNativeBooleanRotation','NativeBooleanRotation','CurrentPhaseParity2011','CurrentOneHot2011'):
  overlay=P/phase;src=(overlay/'DiophantineConsistency'/f'{name}.lean') if name in ('MFNativeBooleanRotation','NativeBooleanRotation') else root/'DiophantineConsistency'/f'{name}.lean'; obj=overlay/'DiophantineConsistency'/f'{name}.olean';obj.unlink(missing_ok=True);log=P/f'{phase}-{name}.log'; t=P/f'{phase}-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(t),'lean','-M9000','-j1','-DElab.async=false','-R',str(overlay if src.is_relative_to(overlay) else root),str(src),'-o',str(obj)]; before=h(src)
  with log.open('wb') as o:r=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT)
  rec.append({'phase':phase,'module':name,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time':t.read_text(),'object_sha256':h(obj) if obj.exists() else None});(P/'records.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,name,r.returncode,flush=True)
  if r.returncode or before!=h(src):raise SystemExit(1)
