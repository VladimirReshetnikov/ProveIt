from pathlib import Path
import json,hashlib
p=Path('/tmp/native-boolean-sharing');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
for r in json.loads((p/'records.json').read_text()):
 cmd=r['command'];src=[x for x in cmd if x.endswith('.lean')];assert len(src)==1
 assert r['status']==0 and r['source_sha256']==r['source_after']==h(src[0]); assert r['lean_path'].split(':')[0].endswith(r['phase']);assert h(cmd[-1])==r['object_sha256'] and Path(cmd[4]).read_text()==r['time']
 log=p/(r['phase']+'-'+r['module'].split('.')[-1]+'.log');assert h(log)==r['log_sha256']
print('eight paired target/client records match source, object, log, timing and overlay')
a=(p/'baseline-interface.log').read_bytes();b=(p/'final-interface.log').read_bytes();assert a==b
print('interface logs identical')
for r in json.loads((p/'target-pins.json').read_text()):
 assert h(Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(r['module']+'.lean'))==r['source_sha256'] and h(r['object'])==r['object_sha256']
print('nine selected prerequisite source/object hashes match pins')
