from pathlib import Path
import hashlib,json,shutil,subprocess,time
p=Path('/tmp/sidon-reduction-20261028'); guard=65*1024*1024
items=[('old-target','old-overlay',str(p/'oldsrc/DiophantineConsistency/SidonPositions.lean'),str(p/'old-overlay/DiophantineConsistency/SidonPositions.olean')),('old-attributes','old-overlay',str(p/'axioms-attributed.lean'),None),('new-attributes','overlay',str(p/'axioms-attributed.lean'),None)]; records=[]
for name,overlay,source,out in items:
 free=shutil.disk_usage('.').free
 if free<guard:
  (p/'attributes-stopped.json').write_text(json.dumps({'next':name,'free':free,'threshold':guard}));raise SystemExit(75)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if out:argv+=['-R',str(p/'oldsrc'),'-o',out]
 cmd=['lake','env','bash','-c',f'export LEAN_PATH="/tmp/sidon-reduction-20261028/{overlay}:$LEAN_PATH"; exec "$@"','bash',*argv]
 print(name,'free',free,flush=True); t=time.monotonic(); r=subprocess.run(cmd,capture_output=True); elapsed=time.monotonic()-t; log=p/(name+'.log');log.write_bytes(r.stdout+r.stderr)
 records.append({'name':name,'argv':cmd,'exit_status':r.returncode,'seconds':elapsed,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (p/'attributes-results.json').write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
