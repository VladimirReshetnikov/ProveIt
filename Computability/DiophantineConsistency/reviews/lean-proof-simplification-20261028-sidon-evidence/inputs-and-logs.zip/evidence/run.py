from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
p=Path('/tmp/sidon-reduction-20261028'); prefix='Computability/DiophantineConsistency/Lean/'; mode=sys.argv[1]; guard=65*1024*1024
names=['SidonPositions','QuadraticCoding','SelectiveQuadraticCoding','DegreeSeparatedCoding','SplitGeometry59','SplitCertificate59','NativePellBootstrap','FirstPellCarrier','NativePellFirstIndex']
if mode=='baseline':
 items=[('target',prefix+'DiophantineConsistency/SidonPositions.lean','SidonPositions'),('sidon-axioms',str(p/'axioms-sidon.lean'),None),('bootstrap-axioms',str(p/'axioms-bootstrap.lean'),None),('sidon-focus',prefix+'checks/SidonPositions.lean',None)]
elif mode=='final':
 items=[(n,prefix+'DiophantineConsistency/'+n+'.lean',n) for n in names]+[('sidon-axioms',str(p/'axioms-sidon.lean'),None),('bootstrap-axioms',str(p/'axioms-bootstrap.lean'),None),('sidon-focus',prefix+'checks/SidonPositions.lean',None),('bootstrap-focus',prefix+'checks/NativePellBootstrap.lean',None)]
else: raise SystemExit('bad mode')
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free<guard:
  (p/(mode+'-stopped.json')).write_text(json.dumps({'next':name,'free_bytes':free,'threshold_bytes':guard},indent=2)+'\n'); raise SystemExit(75)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:
  out=p/'overlay/DiophantineConsistency'/(obj+'.olean')
  if out.is_symlink(): out.unlink()
  argv+=['-o',str(out)]
 command=['lake','env','bash','-c','export LEAN_PATH="/tmp/sidon-reduction-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 print(mode,name,'free',free,flush=True); t=time.monotonic(); r=subprocess.run(command,capture_output=True); elapsed=time.monotonic()-t
 log=p/(mode+'-'+name+'.log'); log.write_bytes(r.stdout+r.stderr)
 sourcep=Path(source); row={'name':name,'argv':command,'exit_status':r.returncode,'elapsed_seconds':elapsed,'free_before':free,'free_after':shutil.disk_usage('.').free,'source':str(sourcep),'source_sha256':hashlib.sha256(sourcep.read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and out.is_file(): row['object']={'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
 records.append(row); (p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode: raise SystemExit(r.returncode)
