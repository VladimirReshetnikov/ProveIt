import json,hashlib,re,subprocess
from pathlib import Path
r=Path('/dev/shm/cell-sum-unique');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
for phase in ('baseline','final'):
 entries=json.loads((r/f'{phase}-records.json').read_text());assert [e['module'] for e in entries]==['ArithmeticCellLabels','ArithmeticCellTransfer'];rows[phase]=entries
 for e in entries:
  assert e['status']==0 and e['before']==e['after']==H(e['source']) and H(e['object'])==e['object_sha256'] and H(e['log'])==e['log_sha256'] and Path(e['log']).read_bytes()==b''
  assert e['time']==Path(e['command'][e['command'].index('-o')+1]).read_text()
  assert re.findall(r'^import\s+(\S+)',Path(e['source']).read_text(),re.M)==[x['module'] for x in e['direct_inputs']]
  for x in e['direct_inputs']:
   first=next(Path(p)/(x['module'].replace('.','/')+'.olean') for p in e['LEAN_PATH'].split(':') if (Path(p)/(x['module'].replace('.','/')+'.olean')).is_file())
   assert first==Path(x['path']) and str(first.resolve())==x['resolved'] and H(first)==x['before']==x['after'] and H(x['source'])==x['source_before']==x['source_after']
   if x['module'].endswith('ArithmeticCellLabels'):assert H(first)==entries[0]['object_sha256']
 assert entries[1]['before']==H(w/'ArithmeticCellTransfer.lean')
assert H(w/'ArithmeticCellLabels.lean')==rows['baseline'][0]['before']
assert rows['baseline'][1]['object_sha256']==rows['final'][1]['object_sha256']
probes=json.loads((r/'probe-records.json').read_text());assert len(probes)==16
for p in probes:
 expected=[rows[p['phase']][0]['object_sha256']]+([rows[p['phase']][1]['object_sha256']] if p['client'] else [])
 assert p['status']==0 and H(p['source'])==p['source_before']==p['source_after'] and [H(x) for x in p['objects']]==p['objects_before']==p['objects_after']==expected and H(p['log'])==p['log_sha256']
for stem in ['simp','instances','client-names','client-interfaces','client-simp','client-instances']:
 assert (r/f'baseline-{stem}.log').read_bytes()==(r/f'final-{stem}.log').read_bytes()
def parse(p):
 s=(r/f'{p}-interfaces.log').read_text();return {m.group(1):m.group(0) for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',s)}
a,b=parse('baseline'),parse('final');deleted={f'DiophantineConsistency.ArithmeticCellLabels.sum_le_one_cases._proof_{i}' for i in range(1,7)}
assert a.keys()-b.keys()==deleted and not b.keys()-a.keys() and len(b)==76 and all(a[n]==b[n] for n in b)
assert len((r/'baseline-client-names.log').read_text().splitlines())==59
p=subprocess.run(['git','grep','-n','-E',r'sum_le_one_cases\._proof_[1-6]([^0-9]|$)','--','*.lean','*.py'],capture_output=True,text=True);assert p.returncode==1 and p.stdout==''
providers={'ArithmeticCellLocal':'/tmp/high-digits-module-sharing/final-records.json','MFDoubledClause2011':'/tmp/construction-share/bound-refresh-records.json','ArithmeticStandardCasts':'/tmp/binary-half-direct/final-supplement-records.json','ArithmeticModularCancellation':'/tmp/shared-modular-cancel/records.json','ArithmeticCyclicWord':'/dev/shm/cell-no-carry/refresh-records.json'}
for e in rows['final']:
 for d in e['direct_inputs']:
  n=d['module'].split('.')[-1]
  if n not in providers:continue
  candidates=[x for x in json.loads(Path(providers[n]).read_text()) if x['module'].split('.')[-1]==n and x['status']==0 and x['object_sha256']==d['before']]
  assert candidates
  assert any(x.get('source_before',x.get('before',x.get('source_sha256')))==x.get('source_after',x.get('after',x.get('source_sha256')))==d['source_before']==H(w/(n+'.lean')) for x in candidates)
print('PASS: both-phase builds, source/client pins, first-provider associations, 16 probes, unchanged reports, six removed unreferenced generated names')
