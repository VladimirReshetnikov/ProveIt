from pathlib import Path
import json,hashlib,re
r=Path('/dev/shm/cell-sum-unique');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); rec={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text()); assert [x['module'] for x in rows]==['ArithmeticCellLabels','ArithmeticCellTransfer'];rec[phase]={}
 for x in rows:
  rec[phase][x['module']]=x;assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  assert not Path(x['log']).read_bytes()
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
   if d['module'].endswith('.ArithmeticCellLabels'):assert d['before']==rec[phase]['ArithmeticCellLabels']['object_sha256']
  if x['module']=='ArithmeticCellTransfer':assert h(x['source'])==h(w/'ArithmeticCellTransfer.lean')
  print('PASS build',phase,x['module'])
assert rec['baseline']['ArithmeticCellTransfer']['object_sha256']==rec['final']['ArithmeticCellTransfer']['object_sha256']
probes=json.loads((r/'probe-records.json').read_text());assert len(probes)==16
for p in probes:
 phase=p['phase']; names=['ArithmeticCellLabels']+(['ArithmeticCellTransfer'] if p['client'] else []);assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[phase][n]['object_sha256'] for n in names] and h(p['log'])==p['log_sha256']
for stem in ('simp','instances','client-names','client-interfaces','client-simp','client-instances'):
 assert (r/('baseline-'+stem+'.log')).read_bytes()==(r/('final-'+stem+'.log')).read_bytes()
def interfaces(phase):
 s=(r/(phase+'-interfaces.log')).read_text();return {m.group(1):m.group(0) for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',s)}
a=interfaces('baseline');b=interfaces('final');removed=sorted(a.keys()-b.keys());assert removed==[f'DiophantineConsistency.ArithmeticCellLabels.sum_le_one_cases._proof_{i}' for i in range(1,7)] and not (b.keys()-a.keys()) and all(a[n]==b[n] for n in a.keys()&b.keys());print('PASS target 76 common reports and six removed generated names; client 59 and registrations match')
for n,p in [('ArithmeticCellLocal','/tmp/high-digits-module-sharing/final-records.json'),('MFDoubledClause2011','/tmp/construction-share/bound-refresh-records.json')]:
 d=next(d for d in rec['final']['ArithmeticCellLabels']['direct_inputs'] if d['module'].split('.')[-1]==n);xs=[x for x in json.load(open(p)) if x['module'].split('.')[-1]==n and x['status']==0 and x['object_sha256']==d['before']];assert xs;x=xs[-1];before=x.get('source_before',x.get('before',x.get('source_sha256')));after=x.get('source_after',x.get('after',x.get('source_sha256')));assert before==after==d['source_before'];print('PASS source-current direct producer',n,d['before'])
print('PASS all checks; cached transitive closure not audited')
