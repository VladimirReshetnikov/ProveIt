from pathlib import Path
import json,sys,time,hashlib,subprocess
OUT=Path('/tmp/proof-b-cleanup-20261028')
setup=json.loads((OUT/'baseline-order.json').read_text())
mode=sys.argv[1]
def rec(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def guard():
 for p,h in setup['protected'].items():assert rec(p)['sha256']==h,('source changed',p)
if mode=='baseline':
 guard();steps=[('wang-original-'+Path(p).stem,p,True) for p in setup['ordered_wang_sources']]+[('original-'+Path(p).stem,p,True) for p in setup['baseline_extra_sources']]+[('baseline-axioms',str(OUT/'old-axioms.lean'),False)]
elif mode=='final':
 pref='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
 checks='Computability/DiophantineConsistency/Lean/checks/'
 steps=[('final-'+n,pref+n+'.lean',True) for n in ['NativePellBootstrap','MarginSeparation','WangTiles942ResetRows','NativePellFirstIndex','RatioMarginFinalizer','WangTiles942OperatingRow']]+[('focus-'+n,checks+n+'.lean',False) for n in ['NativePellBootstrap','MarginSeparation']]+[('focus-Wang',pref+'WangTiles942ResetRowsChecks.lean',False),('final-axioms',str(OUT/'old-axioms.lean'),False)]
else:raise ValueError(mode)
state={'mode':mode,'complete':False,'records':[]};statepath=OUT/(mode+'-commands.json');assert not statepath.exists()
for tag,source,output in steps:
 source_pin=rec(source);argv=['lake','env','lean','-M6000','-j1','-DElab.async=false',source]
 if output:argv+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+Path(source).stem+'.olean']
 log=OUT/(tag+'.log');timing=OUT/(tag+'.time');start=time.monotonic()
 with log.open('wb') as f:proc=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(timing),*argv],stdout=f,stderr=subprocess.STDOUT)
 assert rec(source)==source_pin
 row={'tag':tag,'argv':argv,'source':source_pin,'actual_exit_status':proc.returncode,'elapsed_seconds_observed':time.monotonic()-start,'log':rec(log),'timing':rec(timing)}
 if output and proc.returncode==0:row['object']=rec(argv[-1])
 state['records'].append(row);statepath.write_text(json.dumps(state,indent=2)+'\n');print(tag,'exit',proc.returncode,flush=True)
 if proc.returncode:raise SystemExit(proc.returncode)
if mode=='baseline':guard()
state['complete']=True
if mode=='final':state['old_axiom_logs_identical']=(OUT/'final-axioms.log').read_bytes()==(OUT/'baseline-axioms.log').read_bytes()
statepath.write_text(json.dumps(state,indent=2)+'\n')
