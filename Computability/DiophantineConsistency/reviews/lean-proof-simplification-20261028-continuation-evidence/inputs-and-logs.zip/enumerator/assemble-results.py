from pathlib import Path
import json,hashlib,re
p=Path('/tmp/diophantine-realizer-inversion-20261028')
base=json.loads((p/'baseline-commands.json').read_text())
final=json.loads((p/'final-commands.json').read_text())
decimal=json.loads((p/'decimal-results.json').read_text())
assert base['complete'] and final['complete'] and decimal['complete']
assert (len(base['records']),len(final['records']),len(decimal['records']))==(6,12,2)
def check(rec,path=None):
 b=Path(path or rec['path']).read_bytes()
 assert len(b)==rec['bytes'] and hashlib.sha256(b).hexdigest()==rec['sha256'],rec['path']
for run in [base,final]:
 for r in run['records']:
  assert r['actual_exit_status']==0
  for key in ['log','timing']:check(r[key])
  source=r['source']['path']
  historical=p/(r['tag']+'-original.lean')
  check(r['source'],historical if run is base and historical.exists() else source)
  assert re.search(r'exit_status=0\b',Path(r['timing']['path']).read_text())
for r in decimal['records']:
 assert r['exit']==0
 for key in ['source','log','time','object']:
  if key in r:check(r[key])
 assert re.search(r'exit_status=0\b',Path(r['time']['path']).read_text())
assert re.search(r'exit_status=0\b',(p/'final-repository-focus.time').read_text())
assert not (p/'final-repository-focus.log').read_bytes()
old=(p/'baseline-axioms.log').read_bytes();new=(p/'final-axioms.log').read_bytes();assert old==new
pattern=re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)",re.S)
reports=pattern.findall(new.decode());assert len(reports)==62
for _,ax in reports:assert {x.strip() for x in ax.split(',') if x.strip()}<={'propext','Classical.choice','Quot.sound'}
result={'base_commit':'b3f47632abf3554a12b17bd8a1d39f08239e0f77','baseline_calls':6,'final_calls':15,'baseline_and_final_exit_codes_all_zero':True,'old_public_reports':62,'old_public_stdout_byte_identical':True,'axiom_report_sha256':hashlib.sha256(new).hexdigest(),'axiom_free_reports':sum(not ax for _,ax in reports),'source_comparison':json.loads((p/'source-comparison.json').read_text()),'targeted_scope':'The nine-node affected cone for seven direct/nearby roots is rebuilt; the separately checked decimal-machine endpoint and focus extend that scope. The permanent compatibility check tests the old source definition against the current value by rfl for every input, tests the current program property, and imports only the original public wrapper. Package objects and unrelated project imports remain precompiled reuse; no whole-project rebuild is claimed.','final_commands':final,'baseline_commands':base,'decimal_commands':decimal,'repository_focus':{'source':'Computability/DiophantineConsistency/Lean/checks/EnumeratorCompatibility.lean','log':str(p/'final-repository-focus.log'),'time':str(p/'final-repository-focus.time'),'observed_exit_status':0},'peer_review':'sync_audit independently read all changed modules, old/new semantic contracts and source identities, reviewed the wrapper compatibility, authenticated logs/axiom results and reconstructed the nine-node selected reverse cone without executing Lean.'}
q=p/'results.json';assert not q.exists();q.write_text(json.dumps(result,indent=2)+'\n');q.chmod(0o444)
print('receipt',len(q.read_bytes()),hashlib.sha256(q.read_bytes()).hexdigest())
print('62 old reports byte equal; axiom free',result['axiom_free_reports'])
print('final calls',result['final_calls'])
