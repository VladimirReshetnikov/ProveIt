from pathlib import Path
import subprocess,json,hashlib,time
p=Path('/tmp/diophantine-realizer-inversion-20261028');base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
steps=[('DecimalMachineZFC',base+'DecimalMachineZFC.lean','DecimalMachineZFC'),('DecimalMachineZFCChecks',base+'DecimalMachineZFCChecks.lean',None)]
records=[]
def f(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for name,source,obj in steps:
 cmd=['lake','env','lean','-M6000','-j1','-DElab.async=false',source]
 if obj:cmd+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+obj+'.olean']
 log=p/('decimal-'+name+'.log');tim=p/('decimal-'+name+'.time');start=time.monotonic()
 with log.open('wb') as stream:
  proc=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(tim),*cmd],stdout=stream,stderr=subprocess.STDOUT)
 rec={'name':name,'argv':cmd,'exit':proc.returncode,'source':f(source),'log':f(log),'time':f(tim),'elapsed':time.monotonic()-start}
 if obj and proc.returncode==0:rec['object']=f(cmd[-1])
 records.append(rec);(p/'decimal-results.json').write_text(json.dumps({'complete':False,'records':records},indent=2)+'\n');print(name,'exit',proc.returncode,flush=True)
 if proc.returncode:raise SystemExit(proc.returncode)
(p/'decimal-results.json').write_text(json.dumps({'complete':True,'records':records},indent=2)+'\n')
