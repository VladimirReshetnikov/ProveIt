from pathlib import Path
import subprocess,sys,json,hashlib,time
out=Path('/tmp/diophantine-realizer-inversion-20261028');mode=sys.argv[1]
prefix='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
if mode=='baseline':
    specs=[('Computability',prefix+'Computability.lean','Computability'),('DirectScalarEnumerator',prefix+'DirectScalarEnumerator.lean','DirectScalarEnumerator'),('Bridge',prefix+'Bridge.lean','Bridge'),('semantic-probe',str(out/'semantic-probe.lean'),None),('import-probe',str(out/'import-probe.lean'),None),('axioms',str(out/'old-public-axioms.lean'),None)]
elif mode=='final':
    specs=[('EnumeratorSemantics',prefix+'EnumeratorSemantics.lean','EnumeratorSemantics'),('DirectScalarEnumeratorCore',prefix+'DirectScalarEnumeratorCore.lean','DirectScalarEnumeratorCore'),('Computability',prefix+'Computability.lean','Computability'),('DirectScalarEnumerator',prefix+'DirectScalarEnumerator.lean','DirectScalarEnumerator'),('Bridge',prefix+'Bridge.lean','Bridge'),('ZFCFromProgram',prefix+'ZFCFromProgram.lean','ZFCFromProgram'),('ExplicitZFC',prefix+'ExplicitZFC.lean','ExplicitZFC'),('DirectGraphEnumerator',prefix+'DirectGraphEnumerator.lean','DirectGraphEnumerator'),('NativeGraphEnumerator',prefix+'NativeGraphEnumerator.lean','NativeGraphEnumerator'),('semantic-probe',str(out/'semantic-probe.lean'),None),('import-probe',str(out/'import-probe.lean'),None),('axioms',str(out/'old-public-axioms.lean'),None)]
else:raise SystemExit('bad mode')
state={'mode':mode,'complete':False,'records':[]};file=out/(mode+'-commands.json');assert not file.exists()
def rec(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for tag,source,obj in specs:
    cmd=['lake','env','lean','-M6000','-j1','-DElab.async=false',source]
    if obj:cmd+=['-o','.lake/build/lib/lean/DiophantineConsistency/'+obj+'.olean']
    log=out/(mode+'-'+tag+'.log');tim=out/(mode+'-'+tag+'.time');snapshot=rec(source);start=time.monotonic()
    with log.open('wb') as f:
        p=subprocess.run(['/usr/bin/time','-f','elapsed_seconds=%e max_rss_kib=%M exit_status=%x','-o',str(tim),*cmd],stdout=f,stderr=subprocess.STDOUT)
    r={'tag':tag,'argv':cmd,'actual_exit_status':p.returncode,'source':snapshot,'log':rec(log),'timing':rec(tim),'elapsed_observed':time.monotonic()-start}
    if obj and p.returncode==0:r['object']=rec(cmd[-1])
    state['records'].append(r);file.write_text(json.dumps(state,indent=2)+'\n');print(mode,tag,'exit',p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
state['complete']=True
if mode=='final':state['axioms_stdout_equal']=(out/'baseline-axioms.log').read_bytes()==(out/'final-axioms.log').read_bytes()
file.write_text(json.dumps(state,indent=2)+'\n')
