from pathlib import Path
import subprocess,json,time,hashlib
base=Path('/tmp/nine-coefficient-consolidation');d=base/'refreshed';overlay=d/'overlay';root='Computability/DiophantineConsistency/Lean';mod=root+'/DiophantineConsistency';check=root+'/checks';names='GapCertificate66 GapKernels66 GapSourceWords66 GapSourceContract66 GapSourceExistence66 GapNineSource66 GapNinePolynomial66'.split();tasks=[(n,mod+'/'+n+'.lean',True) for n in names]+[('gap-client',mod+'/GapCircuitRegisters66.lean',False),('gap-check',check+'/GapNinePolynomial66.lean',False),('axioms',str(base/'axioms.lean'),False)]
res=[]
for name,source,out in tasks:
 cmd=['lake','env','bash','-c','export LEAN_PATH="$1:$LEAN_PATH"; shift; exec "$@"','bash',str(overlay),'lean','-M6000','-j1','-DElab.async=false','-R',root,source]
 if out:cmd+=['-o',str(overlay/'DiophantineConsistency'/(Path(source).stem+'.olean'))]
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-start;log=d/'logs'/(name+'.log');log.write_bytes(p.stdout+p.stderr)
 data={'name':name,'source':source,'command':cmd,'exit':p.returncode,'elapsed':elapsed,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if out and p.returncode==0:
  obj=overlay/'DiophantineConsistency'/(Path(source).stem+'.olean');data.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
 res.append(data);(d/'statuses.json').write_text(json.dumps(res,indent=2)+'\n');print(name,p.returncode,round(elapsed,2),flush=True)
 if p.returncode:break
