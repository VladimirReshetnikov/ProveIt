from pathlib import Path
import subprocess,sys,json,time,hashlib
base=Path('/tmp/nine-coefficient-consolidation')
phase=sys.argv[1]; d=base/phase; overlay=d/'overlay'; (d/'logs').mkdir(parents=True,exist_ok=True)
root='Computability/DiophantineConsistency/Lean';mod=root+'/DiophantineConsistency'; check=root+'/checks'
tasks=[('split',mod+'/SplitNinePolynomial59.lean',True),('gap',mod+'/GapNinePolynomial66.lean',True),('split-client',mod+'/SplitCircuitRegisters59.lean',False),('gap-client',mod+'/GapCircuitRegisters66.lean',False),('split-check',check+'/SplitNinePolynomial59.lean',False),('gap-check',check+'/GapNinePolynomial66.lean',False),('axioms',str(base/'axioms.lean'),False)]
res=json.loads((d/'statuses.json').read_text()) if len(sys.argv)>2 else []
for name,source,out in tasks:
 if len(sys.argv)>2 and name != sys.argv[2]: continue
 cmd=['lake','env','bash','-c','export LEAN_PATH="$1:$LEAN_PATH"; shift; exec "$@"','bash',str(overlay),'lean','-M6000','-j1','-DElab.async=false','-R',root,source]
 if out:cmd+=['-o',str(overlay/'DiophantineConsistency'/(Path(source).stem+'.olean'))]
 t=time.monotonic();p=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-t
 log=d/'logs'/(name+'.log'); log.write_bytes(p.stdout+p.stderr)
 data={'name':name,'source':source,'command':cmd,'exit':p.returncode,'elapsed':elapsed,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if out and p.returncode==0:
  obj=overlay/'DiophantineConsistency'/(Path(source).stem+'.olean');data['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest();data['object_bytes']=obj.stat().st_size
 res.append(data);(d/'statuses.json').write_text(json.dumps(res,indent=2)+'\n');print(phase,name,p.returncode,round(elapsed,2),flush=True)
 if p.returncode:break
