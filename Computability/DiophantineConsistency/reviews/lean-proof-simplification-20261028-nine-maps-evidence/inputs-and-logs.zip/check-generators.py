from pathlib import Path
import importlib.util,hashlib
root=Path('Computability/DiophantineConsistency');tools=root/'tools'
def load(name):
 p=tools/(name+'.py');spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
split=load('generate_split_nine_polynomial59_maps');content=split.OUTPUT.read_text();before,rest=content.split(split.START,1);block,after=rest.split(split.END,1);assert block==split.generate()
gap=load('generate_gap_nine_polynomial66'); path=root/'Lean/DiophantineConsistency/GapNinePolynomial66.lean';assert path.read_text()==gap.render()
for p in [split.DATA,split.OUTPUT,root/'Lean/DiophantineConsistency/GapKernelData66.lean',path]:print(str(p),hashlib.sha256(p.read_bytes()).hexdigest())
print('Both generated map outputs match their generators.')
