from pathlib import Path
import re,hashlib,json,sys
root=Path('Computability/DiophantineConsistency/Lean');overlay=Path('/tmp/nine-coefficient-consolidation/baseline/overlay');base=Path('/tmp/nine-coefficient-consolidation');seen=set();result=[]
def hash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def go(name):
 if name in seen:return
 seen.add(name);src=root/Path(*name.split('.')).with_suffix('.lean')
 if not src.exists():return
 text=src.read_text();deps=re.findall(r'(?m)^import\s+([\w.]+)',text)
 for d in deps:go(d)
 obj=overlay/Path(*name.split('.')).with_suffix('.olean')
 row={'name':name,'source':str(src),'source_sha256':hash(src),'imports':deps,'source_mtime_ns':src.stat().st_mtime_ns}
 if obj.exists():row.update(object=str(obj.resolve()),object_sha256=hash(obj),object_mtime_ns=obj.stat().st_mtime_ns)
 else:row['object']=None
 result.append(row)
for name in ['DiophantineConsistency.SplitNinePolynomial59','DiophantineConsistency.GapNinePolynomial66','DiophantineConsistency.SplitCircuitRegisters59','DiophantineConsistency.GapCircuitRegisters66']:go(name)
Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
