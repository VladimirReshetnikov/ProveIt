from pathlib import Path
import hashlib, json, os, subprocess, sys, time
phase=sys.argv[1]
root=Path('Computability/DiophantineConsistency/Lean')
work=Path('/tmp/gap-cert-validation')
overlay=work/phase/'overlay'
ns=overlay/'DiophantineConsistency'; ns.mkdir(parents=True,exist_ok=True)
prev=Path('/tmp/record-bounds-validation/fresh/overlay/DiophantineConsistency')
for p in prev.glob('*.olean'):
 if p.stem not in ('GapCertificate66','GapKernels66'):
  q=ns/p.name
  if not q.exists():q.symlink_to(p.resolve())
env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','')
mod=root/'DiophantineConsistency'
checks=[('target',mod/'GapCertificate66.lean',ns/'GapCertificate66.olean'),('client',mod/'GapKernels66.lean',ns/'GapKernels66.olean'),('focus',root/'checks/GapCertificate66.lean',None),('axioms',work/'axioms.lean',None)]
def hash_file(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
results=[]
for name,src,out in checks:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(src)]
 if out:cmd+=['-o',str(out)]
 log=work/phase/(name+'.log');tim=work/phase/(name+'.time')
 with log.open('wb') as f:
  t=time.monotonic();r=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tim),*cmd],stdout=f,stderr=subprocess.STDOUT,env=env);dt=time.monotonic()-t
 rec={'name':name,'command':cmd,'status':r.returncode,'elapsed':dt,'source':str(src),'source_sha256':hash_file(src),'log_sha256':hash_file(log),'time_sha256':hash_file(tim)}
 if out and out.exists():rec.update(object_sha256=hash_file(out),object_bytes=out.stat().st_size)
 results.append(rec); (work/phase/'records.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,r.returncode,round(dt,2),flush=True)
 if r.returncode:sys.exit(r.returncode)
