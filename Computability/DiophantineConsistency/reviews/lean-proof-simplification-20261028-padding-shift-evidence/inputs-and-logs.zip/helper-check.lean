import DiophantineConsistency.PaddingStaircase
open scoped BigOperators
open DiophantineConsistency.PaddingStaircase
#print axioms shifted_suffix_sum_general
example (f : ℕ → ℕ) :
    (∑ p ∈ Finset.range 0, if 0 ≤ 0 + p then f (0 + p - 0) else 0) = prefixSum f 0 :=
  shifted_suffix_sum_general f (N := 0) (j := 0) (by omega)
example (f : ℕ → ℕ) (N : ℕ) :
    (∑ p ∈ Finset.range N, if N ≤ N + p then f (N + p - N) else 0) = prefixSum f N :=
  shifted_suffix_sum_general f (N := N) (j := N) (by omega)
