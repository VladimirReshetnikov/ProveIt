import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/shared-padding-shift');phase=sys.argv[1];task=sys.argv[2]
env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
lean='Computability/DiophantineConsistency/Lean';src=Path(lean)/'DiophantineConsistency'
if task=='targets':jobs=[(n,str(src/(n+'.lean')),True) for n in ['PaddingStaircase','NativePreliminaryCount2011','CurrentClause2011','CurrentEarlyPadding2011','ArithmeticCellLocal']]
else:jobs=[(n,str(src/(n+'.lean')),False) for n in ['PaddingStaircaseChecks','CurrentEarlyPadding2011Checks','CurrentOneHot2011','ArithmeticCellLabels']]+[('axioms',str(root/'axioms.lean'),False)]
records=[]
for tag,path,obj in jobs:
 
 if phase=='final' and tag=='ArithmeticCellLabels':
  path=str(root/'check-source/DiophantineConsistency/ArithmeticCellLabels.lean');module_root=str(root/'check-source')
 else:module_root=lean
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',module_root,path]
 if obj:cmd+=['-o',str(root/phase/'DiophantineConsistency'/(tag+'.olean'))]
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True,env=env);sec=time.monotonic()-start
 log=root/(phase+'-'+tag+'.log');log.write_bytes(p.stdout+p.stderr)
 rec={'tag':tag,'cmd':cmd,'status':p.returncode,'seconds':sec,'source_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and p.returncode==0:
  data=(root/phase/'DiophantineConsistency'/(tag+'.olean')).read_bytes();rec.update(object_sha256=hashlib.sha256(data).hexdigest(),object_bytes=len(data))
 records.append(rec);(root/(phase+'-'+task+'-records.json')).write_text(json.dumps(records,indent=2)+'\n')
 print(phase,tag,p.returncode,round(sec,2),flush=True)
 if p.returncode:sys.exit(p.returncode)
