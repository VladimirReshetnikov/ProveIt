from pathlib import Path
import subprocess,json,os,hashlib,time,sys,re
base=Path('/tmp/diophantine-convolution-factorization'); root=Path.cwd(); phase=sys.argv[1]
j=json.loads((base/'baseline-graph.json').read_text()); edges=j['project_import_edges']; prefix='Computability/DiophantineConsistency/Lean/'; targets=['SelectiveCoefficientBounds','SplitCoefficientBounds']
out=base/phase; ov=out/'overlay/DiophantineConsistency'; ov.mkdir(parents=True,exist_ok=True)
for f in Path('.lake/build/lib/lean/DiophantineConsistency').glob('*.olean'):
 d=ov/f.name
 if not d.exists(): d.symlink_to(f.resolve())
# Populate all graph-local project modules in topological order, isolating complete local cone.
seen=set(); order=[]
def visit(p):
 if p in seen: return
 seen.add(p)
 for dep in edges.get(p,[]):
  if dep.startswith(prefix+'DiophantineConsistency/'): visit(dep)
 if p.startswith(prefix+'DiophantineConsistency/'): order.append(p)
for p in j['roots']: visit(p)
probe=out/'axioms.lean'; decl=[]
for target in targets:
 src=(root/prefix/'DiophantineConsistency'/f'{target}.lean').read_text()
 for m in re.finditer(r'^(?:noncomputable\s+)?(?:theorem|lemma|def|abbrev)\s+([\w\']+)',src,re.M):
  if phase=='final' and m.group(1)=='abs_coeff_encoded_mul_le': continue
  decl.append(f'DiophantineConsistency.{target}.{m.group(1)}')
probe.write_text('import DiophantineConsistency.SplitCoefficientBounds\n'+''.join(f'#print axioms {n}\n' for n in decl))
(out/'declarations.json').write_text(json.dumps(decl,indent=2))
env=os.environ.copy(); logs=out/'logs'; logs.mkdir(exist_ok=True)
status=[]
def run(label,cmd):
 cmd=['lake','env','bash','-c',f'export LEAN_PATH="{out}/overlay:$LEAN_PATH"; exec "$@"','bash','lean','-M6000','-j1','-DElab.async=false','-R',str(root/prefix)]+cmd
 start=time.time(); r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); path=logs/(label+'.log'); path.write_bytes(r.stdout)
 entry={'label':label,'status':r.returncode,'seconds':round(time.time()-start,2),'sha256':hashlib.sha256(r.stdout).hexdigest()}; status.append(entry); (out/'statuses.json').write_text(json.dumps(status,indent=2)); print(entry,flush=True)
 if r.returncode: sys.exit(r.returncode)
affected=set()
for p in order:
 if Path(p).stem in targets or any(x in affected for x in edges[p]): affected.add(p)
for p in order:
 name=Path(p).stem; dest=ov/(name+'.olean'); dest.unlink(missing_ok=True)
 if phase=='final' and p not in affected:
  dest.symlink_to((base/'baseline/overlay/DiophantineConsistency'/dest.name).resolve())
 else:
  run(name,[p,'-o',str(dest)])
for p in j['roots']:
 if '/checks/' in p: run('check-'+Path(p).stem,[p])
run('axioms',[str(probe)])
