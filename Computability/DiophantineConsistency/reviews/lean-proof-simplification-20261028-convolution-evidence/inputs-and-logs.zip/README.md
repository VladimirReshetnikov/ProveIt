# Convolution proof consolidation: validation evidence

This bundle records the baseline and final validation of the proof changes to
`SelectiveCoefficientBounds.lean` and `SplitCoefficientBounds.lean`. The two
`*.original.lean` and `*.final.lean` pairs are exact snapshots; `hashes.json`
records their SHA-256 values and the hashes of the compiled objects, which are
not included here. The final snapshots were copied only after verifying their
hashes against that record.

`baseline/statuses.json` records 25 successful commands; `final/statuses.json`
records 11 successful commands. Each entry names the corresponding output in
its phase's `logs/` directory and records its SHA-256. `build.py` preserves the
command-construction logic, order, flags, output paths, environment setup, and
status collection for the baseline and final builds. The helper axiom probe was
run separately; its output and status were recorded, but its exact invocation
was not retained by that script. The scripts preserve original `/tmp` paths and
are evidence of the executed process, not a standalone replay setup.

All 15 original public axiom reports in `baseline/logs/axioms.log` and
`final/logs/axioms.log` are byte-identical. The new helper's separate report is
in `final/logs/helper-axioms.log`. The two checked modules under `checks/` also
passed in both phases. Each status and log hash was checked during packaging.

`baseline-graph.json` and `final-graph.json` contain the protected source hashes,
project import edges, roots, toolchain pins, and mathlib revision. Their import
edges agree; their file hashes differ only for the two edited targets. Both
record mathlib revision `81a5d257c8e410db227a6665ed08f64fea08e997` with a
clean tracked tree. Their checked repository commits differ; the individual
source pins make the scope of the comparison explicit.

The baseline rebuilt the graph-local `DiophantineConsistency` modules listed in
its status file. The final build rebuilt the target-affected modules listed in
its status file and reused the freshly built baseline objects for other modules
in that graph. Other precompiled dependencies, including mathlib, were reused;
this is not a clean whole-repository build. Timings are single observations and
are not a controlled performance comparison. Compiled objects and overlay
symlinks are intentionally excluded. `SHA256SUMS` covers every other file in
this bundle.
