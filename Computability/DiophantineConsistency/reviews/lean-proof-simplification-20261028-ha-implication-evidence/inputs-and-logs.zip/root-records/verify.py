import os, pathlib, subprocess, json, hashlib, time
R=pathlib.Path('/tmp/ha-implication-reuse-20261028'); D=R/'root-records'; repo=pathlib.Path.cwd(); src=repo/'Computability/DiophantineConsistency/Lean'; base=R/'base'; digest=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest(); results=[]
for phase in ('baseline','final'):
    overlay=D/phase/'overlay'; snap=D/phase/'source/DiophantineConsistency'; snap.mkdir(parents=True,exist_ok=True)
    for namespace in base.iterdir():
        if namespace.is_dir():
            dst=overlay/namespace.name; dst.mkdir(parents=True,exist_ok=True)
            for item in namespace.iterdir():
                dest=dst/item.name
                if not dest.exists() and not dest.is_symlink(): dest.symlink_to(item.resolve(),target_is_directory=item.is_dir())
    source=snap/'FoundationHACurrentTransfer.lean'; source.write_bytes((D/(phase+'.lean')).read_bytes())
    output=overlay/'DiophantineConsistency/FoundationHACurrentTransfer.olean'; output.unlink(missing_ok=True)
    env=os.environ.copy(); env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','')
    jobs=[('target',source,D/phase/'source',output),('focused',src/'DiophantineConsistency/FoundationHACurrentTransferChecks.lean',src,D/phase/'focused.olean')]
    for name,inp,root,out in jobs:
        cmd=['/usr/bin/time','-f','elapsed=%e maxrss_kb=%M','-o',str(D/phase/(name+'.time')),'lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(inp),'-o',str(out)]
        start=time.monotonic(); run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env); log=D/phase/(name+'.log'); log.write_bytes(run.stdout)
        rec={'phase':phase,'job':name,'exit':run.returncode,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'source_sha256':digest(inp),'log_sha256':digest(log),'output_sha256':digest(out) if out.exists() else None,'elapsed':time.monotonic()-start,'timing':(D/phase/(name+'.time')).read_text().strip()};results.append(rec);(D/'records.json').write_text(json.dumps(results,indent=2)+'\n'); print(phase,name,run.returncode,flush=True)
        if run.returncode: raise SystemExit(run.returncode)
assert (D/'baseline/focused.log').read_bytes()==(D/'final/focused.log').read_bytes()
print('focused reports identical',flush=True)
