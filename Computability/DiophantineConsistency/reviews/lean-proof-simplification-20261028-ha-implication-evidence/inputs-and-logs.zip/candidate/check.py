import hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path('/tmp/ha-implication-reuse-20261028');phase=sys.argv[1];src=Path('Computability/DiophantineConsistency/Lean');S=src/'DiophantineConsistency';out=R/'base';env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env.get('LEAN_PATH','');records=[]
for n in ['FoundationHACurrentTransferChecks','FoundationHAConsistencyNormalization','FoundationHAZFCValidator']:
 p=S/(n+'.lean'); q=R/(phase+'-'+n+'.olean'); log=R/(phase+'-'+n+'.log'); timing=R/(phase+'-'+n+'.time')
 cmd=['/usr/bin/time','-f','elapsed=%e maxrss_kb=%M','-o',str(timing),'lean','-M6000','-j1','-DElab.async=false','-R',str(src),str(p),'-o',str(q)]
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True,env=env);log.write_bytes(r.stdout+r.stderr);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 rec={'module':n,'status':r.returncode,'command':cmd,'seconds':time.monotonic()-t,'source_sha256':h(p),'log_sha256':h(log),'timing':timing.read_text().strip()};records.append(rec);(R/(phase+'-checks.json')).write_text(json.dumps(records,indent=2));print(phase,n,r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode: print(log.read_text(),flush=True)
