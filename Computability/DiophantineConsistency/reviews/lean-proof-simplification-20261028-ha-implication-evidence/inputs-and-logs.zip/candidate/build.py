import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
R=Path('/tmp/ha-implication-reuse-20261028'); S=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); root=S.parent
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=Path('/tmp/foundation-ha-current-transfer-root-peer-gx4g2m1q/lib'); out=R/'base'; out.mkdir(exist_ok=True)
# Keep the underlying objects immutable; only replace links in this private overlay.
for d in old.iterdir():
 if d.name!='DiophantineConsistency': (out/d.name).symlink_to(d,target_is_directory=True)
(out/'DiophantineConsistency').mkdir(exist_ok=True)
for p in (old/'DiophantineConsistency').iterdir(): (out/'DiophantineConsistency'/p.name).symlink_to(p)
# PAHF.PACore is refreshed in the prior authenticated run.
(out/'PAHF').unlink(); (out/'PAHF').mkdir();
for p in (old/'PAHF').iterdir(): (out/'PAHF'/p.name).symlink_to(p)
q=out/'PAHF/PACore.olean';q.unlink(missing_ok=True);q.symlink_to('/tmp/arithmetic-shared-literal/fresh/lib/PAHF/PACore.olean')
summary=json.load(open('/tmp/arithmetic-shared-literal/summary.json')); receipts={}
for name,v in summary['refresh'].items():
 if name!='PACore': receipts[name]=(v['source_sha256'],v['object_sha256'],Path(v['object']))
for name,v in summary['borrowed'].items(): receipts[name]=(v['source_sha256'],v['object_sha256'],Path(v['object']))
for v in json.load(open('/tmp/ha-decision-reuse-20261028/baseline-all-records.json')):
 receipts[v['module']]=(v['source_sha256'],v['object_sha256'],Path('/tmp/ha-decision-reuse-20261028/baseline/DiophantineConsistency')/(v['module']+'.olean'))
for name,(src,obj,p) in receipts.items():
 if (S/(name+'.lean')).exists() and H(S/(name+'.lean'))==src and p.exists() and H(p)==obj:
  q=out/'DiophantineConsistency'/(name+'.olean');q.unlink(missing_ok=True);q.symlink_to(p)
order=[]; seen=set(); edges={}
def dfs(name):
 if name in seen:return
 seen.add(name);p=S/(name+'.lean')
 if not p.exists():return
 im=re.findall(r'^import DiophantineConsistency\.([\w]+)',p.read_text(),re.M);edges[name]=im
 for dep in im: dfs(dep)
 order.append(name)
dfs('FoundationHACurrentTransfer')
affected={'HAProofs','WangTiles942Data','WangTiles942TableData','ArithmeticExpression','CurrentKernelData2011','CurrentEquationSyntax2011'}
for n in order:
 if any(x in affected for x in edges[n]):affected.add(n)
missing=[n for n in order if n in affected and not (n in receipts and (S/(n+'.lean')).exists() and H(S/(n+'.lean'))==receipts[n][0] and receipts[n][2].exists() and H(receipts[n][2])==receipts[n][1])]
print('Graph',len(order),'affected',len(affected),'to rebuild',missing,flush=True)
(R/'graph.json').write_text(json.dumps({'order':order,'edges':edges,'affected':sorted(affected),'rebuild':missing},indent=2))
env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+env.get('LEAN_PATH',''); records=[]
for n in missing:
 p=S/(n+'.lean');q=out/'DiophantineConsistency'/(n+'.olean');q.unlink(missing_ok=True)
 cmd=['/usr/bin/time','-f','elapsed=%e maxrss_kb=%M','-o',str(R/(n+'.time')),'lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(p),'-o',str(q)]
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True,env=env); log=R/(n+'.log');log.write_bytes(r.stdout+r.stderr)
 rec={'module':n,'status':r.returncode,'command':cmd,'seconds':time.monotonic()-t,'source_sha256':H(p),'log_sha256':H(log),'timing':(R/(n+'.time')).read_text().strip()}
 if r.returncode==0:rec['object_sha256']=H(q)
 records.append(rec);(R/'build-records.json').write_text(json.dumps(records,indent=2));print(n,r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode:print(log.read_text(),flush=True);sys.exit(r.returncode)
