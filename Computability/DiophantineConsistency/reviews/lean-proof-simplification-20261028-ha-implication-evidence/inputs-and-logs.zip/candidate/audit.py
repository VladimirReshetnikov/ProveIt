import json,hashlib
from pathlib import Path
R=Path('/tmp/ha-implication-reuse-20261028');S=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');B=R/'base/DiophantineConsistency';H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();graph=json.loads((R/'graph.json').read_text());packet=json.load(open('/tmp/foundation-ha-current-transfer-root-peer-gx4g2m1q/packet.json'));old={m['module'].split('.',1)[1]:m for m in packet['modules'] if m['module'].startswith('DiophantineConsistency.')}; prior=json.load(open('/tmp/arithmetic-shared-literal/summary.json')); receipts={}
for n,v in prior['refresh'].items():
 if n!='PACore':receipts[n]=(v['source_sha256'],v['object_sha256'])
for n,v in prior['borrowed'].items():receipts[n]=(v['source_sha256'],v['object_sha256'])
for r in json.load(open('/tmp/ha-decision-reuse-20261028/baseline-all-records.json'))+json.load(open(R/'build-records.json')):
 receipts[r['module']]=(r['source_sha256'],r['object_sha256'])
report=[]
for n in graph['order']:
 if n=='FoundationHACurrentTransfer':continue
 source=S/(n+'.lean');obj=B/(n+'.olean');assert source.exists() and obj.exists(),n
 if n in graph['affected'] or n=='FoundationPAHFSyntax':
  assert n in receipts and receipts[n]==(H(source),H(obj)), n; provenance='refreshed recorded receipt'
 else:
  rec=old[n];assert H(source)==rec['source_sha256'], n; expected=rec['object_sha256'] if 'object_sha256' in rec else next(x['sha256'] for x in rec['objects'] if x['path'].endswith('.olean')); assert H(obj)==expected,n;provenance='historical pinned receipt'
 report.append({'module':n,'source_sha256':H(source),'object_sha256':H(obj),'provenance':provenance})
p=prior['refresh']['PACore'];assert H(p['source'])==p['source_sha256'] and H(p['object'])==p['object_sha256']
(R/'recheck-freshness.json').write_text(json.dumps({'modules':report,'PACore':p,'boundary':'Foundation, FirstOrder, PAHF except PACore and external packages reused from historical authenticated cache; no full external fresh closure.'},indent=2)+'\n');print('dependency audit ok:',len(report),'local modules; fresh:',sum(m['provenance'].startswith('refreshed') for m in report),'historical:',sum(m['provenance'].startswith('historical') for m in report))
