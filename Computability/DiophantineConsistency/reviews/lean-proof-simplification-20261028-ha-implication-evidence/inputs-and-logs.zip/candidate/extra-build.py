import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/tmp/ha-implication-reuse-20261028');S=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');out=R/'base/DiophantineConsistency'; H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for r in json.load(open('/tmp/ha-decision-reuse-20261028/final-targets-records.json')):
 n=r['module'];q=Path('/tmp/ha-decision-reuse-20261028/final/DiophantineConsistency')/(n+'.olean');assert H(S/(n+'.lean'))==r['source_sha256'] and H(q)==r['object_sha256'];z=out/(n+'.olean');z.unlink(missing_ok=True);z.symlink_to(q)
env=os.environ.copy();env['LEAN_PATH']=str(R/'base')+':'+env.get('LEAN_PATH',''); records=[]
for n in ['FoundationHADeltaZeroGG','HABoundedDoubleNegation','FoundationHASigmaOneGG','FoundationPAHFNatSemantics','FoundationZFCConsistencyNat']:
 p=S/(n+'.lean');q=out/(n+'.olean');q.unlink(missing_ok=True);log=R/('extra-'+n+'.log');timing=R/('extra-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss_kb=%M','-o',str(timing),'lean','-M6000','-j1','-DElab.async=false','-R',str(S.parent),str(p),'-o',str(q)];t=time.monotonic();r=subprocess.run(cmd,capture_output=True,env=env);log.write_bytes(r.stdout+r.stderr);rec={'module':n,'status':r.returncode,'cmd':cmd,'seconds':time.monotonic()-t,'source_sha256':H(p),'log_sha256':H(log),'timing':timing.read_text().strip()};
 if r.returncode==0:rec['object_sha256']=H(q)
 records.append(rec);(R/'extra-records.json').write_text(json.dumps(records,indent=2));print(n,r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode:print(log.read_text(),flush=True)
