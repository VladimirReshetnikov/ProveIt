from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/object-semiring-sharing');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
a=(R/'baseline/DiophantineConsistency/ObjectNaturalSemiring.lean').read_text();b=(R/'final/DiophantineConsistency/ObjectNaturalSemiring.lean').read_text();start='  | add p q hp hq';end='\ntheorem equationRel_iff';assert a.split(start,1)[0]==b.split(start,1)[0] and a.split(end,1)[1]==b.split(end,1)[1];print('only add/mul induction branches changed')
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ObjectNaturalSemiring.lean'
for ref,ph in [('483be9ee15^','baseline'),('483be9ee15','final')]:
 assert hashlib.sha256(subprocess.check_output(['git','show',ref+':'+rel])).hexdigest()==h(R/ph/'DiophantineConsistency/ObjectNaturalSemiring.lean');print('git snapshot matches',ref,ph)
assert h(W/'ObjectNaturalSemiring.lean')==h(R/'final/DiophantineConsistency/ObjectNaturalSemiring.lean')
def check(x):
 assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log'])
 assert x['time']==Path(x['command'][4]).read_text()
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
providers={}
for x in read(R/'provider-records.json'):
 check(x);n=x['module'];assert x['before']==h(W/(n+'.lean'));providers[n]=x;print('fresh provider',n,x['object_sha256'],x['time'].strip())
assert len(providers)==6
rows={}
for ph in ['baseline','final']:
 for x in read(R/(ph+'-records.json')):
  check(x);n=x['module'];assert n in ['ObjectNaturalSemiring','ObjectResidualSquares']
  if n!='ObjectNaturalSemiring':assert x['before']==h(W/(n+'.lean'))
  for d in x['direct_inputs']:
   n0=d['module'].split('.')[-1]
   if n0=='ObjectNaturalSemiring':assert d['before']==rows[ph,n0]['object_sha256'] and d['resolved']==rows[ph,n0]['object']
   else:assert n0 in providers and d['before']==providers[n0]['object_sha256'],(ph,n,n0)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
assert rows['baseline','ObjectResidualSquares']['object_sha256']==rows['final','ObjectResidualSquares']['object_sha256'];print('ObjectResidualSquares client objects match')
checks=read(R/'checks-records.json')
for x in checks:
 ph=x['phase'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==h('Computability/DiophantineConsistency/Lean/checks/ObjectOmegaSemiring.lean');assert x['input_before']==x['input_after']==h(x['input'])==rows[ph,'ObjectNaturalSemiring']['object_sha256'];assert x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][4]).read_text();print('focused check',ph,x['time'].strip())
assert checks[0]['object_sha256']==checks[1]['object_sha256'];print('focused check objects match')
for kind in ['names','interfaces','simp','instances']:
 for ph in ['baseline','final']:
  x=read(R/f'probe-{kind}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ObjectNaturalSemiring']['object_sha256'] and x['log_sha256']==h(x['log'])
 a=(R/('baseline-'+kind+'.log')).read_bytes();b=(R/('final-'+kind+'.log')).read_bytes();assert a==b;print('probe',kind,'identical',len(a.splitlines()),'lines')
assert sum(s.startswith('DECL ') for s in (R/'baseline-names.log').read_text().splitlines())==4
pre=read(R/'preliminary-final-records.json')[0]
assert pre['status']==0 and pre['before']==pre['after']==h(pre['source']) and pre['log_sha256']==h(R/'preliminary-final.log') and pre['time']==(R/'preliminary-final.time').read_text()
print('preliminary candidate record, copied log/time match; original object path overwritten by paired replay')
for ph in ['baseline','final']:
 x=read(R/(ph+'-repeat-records.json'))[0];check(x);orig=rows[ph,'ObjectNaturalSemiring'];assert x['before']==orig['before'] and x['object_sha256']==orig['object_sha256'];assert [(d['module'],d['before'],d['resolved']) for d in x['direct_inputs']]==[(d['module'],d['before'],d['resolved']) for d in orig['direct_inputs']];print('repeat',ph,x['time'].strip())
print('PASS builds, checks, probes and repeats; cached provider closure not rebuilt')
