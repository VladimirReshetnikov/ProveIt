from pathlib import Path
import json,hashlib,subprocess,os,time
R=Path('/tmp/object-semiring-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rr=[]
for ph in ['baseline','final']:
 src=R/ph/'checks/ObjectOmegaSemiring.lean';inp=R/('objects-'+ph)/'DiophantineConsistency/ObjectNaturalSemiring.olean';out=R/('objects-'+ph)/'checks/ObjectOmegaSemiring.olean';log=R/(ph+'-ObjectOmegaSemiringChecks.log');tm=R/(ph+'-ObjectOmegaSemiringChecks.time');x=json.loads((R/(ph+'-records.json')).read_text())[0];env=os.environ.copy();env['LEAN_PATH']=x['LEAN_PATH'];before=h(src);ib=h(inp);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(R/ph),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 q={'phase':ph,'status':p.returncode,'source':str(src),'source_before':before,'source_after':h(src),'input':str(inp),'input_before':ib,'input_after':h(inp),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'object':str(out),'object_sha256':h(out) if out.exists() else None,'log':str(log),'log_sha256':h(log),'time':tm.read_text()};rr.append(q);(R/'checks-records.json').write_text(json.dumps(rr,indent=2)+'\n');print(ph,p.returncode,q['time'].strip(),flush=True)
 if p.returncode:raise SystemExit(1)
