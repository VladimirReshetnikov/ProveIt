import Lean.Elab.Command
import DiophantineConsistency.ObjectNaturalSemiring
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ObjectNaturalSemiring).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ObjectNaturalSemiring" then
   logInfo m!"DECL {n}"
