from pathlib import Path
import json,hashlib,re
R=Path('/tmp/object-semiring-sharing');W=Path('Computability/DiophantineConsistency/Lean');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={};providers={}
for ph in ['provider','baseline','final','baseline-repeat','final-repeat']:
 rows[ph]=json.loads((R/(ph+'-records.json')).read_text())
 for x in rows[ph]:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-'+x['module']+'.time')).read_text()
  n=x['module']
  if ph!='final' and ph!='final-repeat' or n!='ObjectNaturalSemiring':assert x['before']==h(W/'DiophantineConsistency'/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1]
   if m in providers:assert d['resolved']==providers[m]['object'] and d['before']==providers[m]['object_sha256']
   elif m=='ObjectNaturalSemiring':assert d['resolved']==rows[ph][0]['object'] and d['before']==rows[ph][0]['object_sha256']
  if ph=='provider':providers[n]=x
  print('build',ph,n,x['time'].strip())
for x in json.loads((R/'checks-records.json').read_text()):
 ph=x['phase'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==h(W/'checks/ObjectOmegaSemiring.lean') and x['input_before']==x['input_after']==h(x['input'])==rows[ph][0]['object_sha256'] and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-ObjectOmegaSemiringChecks.time')).read_text()
 rel='DiophantineConsistency/ObjectNaturalSemiring.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==x['input'];print('focused check',ph,x['time'].strip())
checks=json.loads((R/'checks-records.json').read_text());assert checks[0]['object_sha256']==checks[1]['object_sha256'];assert rows['baseline'][1]['object_sha256']==rows['final'][1]['object_sha256'];print('both client objects match')
for ph in ['baseline','final']:
 for n in ['names','interfaces','simp','instances']:
  x=json.loads((R/f'probe-{n}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
def decls(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decls('baseline'),decls('final');assert a==b and len(a)==4;print('all four declaration/type/axiom reports match')
for n,count in [('simp',32692),('instances',14590)]:
 a=(R/('baseline-'+n+'.log')).read_bytes();b=(R/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==count;print(n,count)
print('all checks passed; providers transitive object inputs are pinned but source provenance is not established')
