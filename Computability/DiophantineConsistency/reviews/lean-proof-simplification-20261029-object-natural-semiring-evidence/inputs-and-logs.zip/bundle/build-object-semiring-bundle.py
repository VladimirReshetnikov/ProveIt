from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-object-natural-semiring-evidence';out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/object-semiring-sharing');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','final','baseline-repeat','final-repeat','provider']:
 for p in sorted((R/phase).rglob('*.lean')):add('snapshots/'+str(p.relative_to(R)),p)
for name in ['object-semiring-independent-review.txt','object-semiring-independent-audit.py','object-semiring-independent-audit.log','object-semiring-independent-audit-setup-failure.log']:
 add('independent/'+name,I/name)
add('bundle/build-object-semiring-bundle.py',Path(__file__))
commit='483be9ee159841d5f5bc08c37885e6f8a6bd6be7';parent='53bd5c544a03dd1c012d9e3243a1d064f55c341e';rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ObjectNaturalSemiring.lean'
for phase,ref in [('baseline',parent),('final',commit)]:
 data=subprocess.check_output(['git','show',ref+':'+rel]);assert data==files['snapshots/'+phase+'/DiophantineConsistency/ObjectNaturalSemiring.lean'];files['commit/'+phase+'.lean']=data
for n in ['ObjectOmegaSemiring','NaturalExpressionSemiring','ObjectPolynomial','ObjectNaturalOrder','ObjectNaturalZero','QuarticSyntax']:
 data=subprocess.check_output(['git','show',commit+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+n+'.lean']);assert data==files['snapshots/provider/DiophantineConsistency/'+n+'.lean']
for phase in ['baseline','final']:
 for sub in ['DiophantineConsistency/ObjectResidualSquares.lean','checks/ObjectOmegaSemiring.lean']:
  data=subprocess.check_output(['git','show',commit+':Computability/DiophantineConsistency/Lean/'+sub]);assert data==files['snapshots/'+phase+'/'+sub]
review=files['independent/object-semiring-independent-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
h=lambda b:hashlib.sha256(b).hexdigest()
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Share add/mul proof in internal natural semiring interpretation',
 'validation':'Paired target, ObjectResidualSquares and focused checks/ObjectOmegaSemiring builds pass with identical client objects; six target/client providers were rebuilt from current source. Four target declaration/type/axiom reports, 32,692 default simp and 14,590 instance entries match; paired repeat target builds pass.',
 'limitations':['The top-level DiophantineConsistency.lean umbrella directly imports the target and was not rebuilt. Probes cover only the target and enumerated registration entries, not every environment extension or downstream client.','Freshly rebuilt providers consume cached ObjectDistributivity, NaturalExpression, ObjectNaturalExpression, QuarticCompiler and SyntaxCoefficients objects without matched current-source build receipts in this experiment. Other transitive project/package inputs remain cached; no full current-source closure build is established.','The successful exploratory candidate build used old cached direct providers; its log/time are preserved, but its original target object path was overwritten by the paired replay.','The independent audit initially indexed the timing argument incorrectly; its setup-error log is preserved. The error did not affect Lean builds.','Two short paired timing samples under shared load are not a general performance benchmark.','Compiled objects are not included in the ZIP; object hashes and input resolution are preserved in receipts, and external objects are needed for independent byte checks.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
