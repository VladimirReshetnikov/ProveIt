import DiophantineConsistency.ArithmeticPacking
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticCyclicWord DiophantineConsistency.ArithmeticWindowDigits DiophantineConsistency.ArithmeticBinaryCarry DiophantineConsistency.ArithmeticRepunit
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (w n X e : V) (he : e ≤ n) :
    rot w n X e + (Exp.exp (w * n) - 1) * (X / Exp.exp (w * (n - e))) =
      Exp.exp (w * e) * X := by
  unfold rot
  have hX := div_add_mod X (Exp.exp (w * (n - e)))
  have hn : Exp.exp (w * n) = Exp.exp (w * (n - e)) * Exp.exp (w * e) := by
    rw [← exp_mul_add, tsub_add_cancel_of_le he]
  have h1 : Exp.exp (w * n) - 1 + 1 = Exp.exp (w * n) := tsub_add_cancel_of_le (one_le_exp _)
  calc
    _ = X % Exp.exp (w * (n - e)) * Exp.exp (w * e) +
        (Exp.exp (w * n) - 1 + 1) * (X / Exp.exp (w * (n - e))) := by ring
    _ = Exp.exp (w * e) * (Exp.exp (w * (n - e)) * (X / Exp.exp (w * (n - e))) +
        X % Exp.exp (w * (n - e))) := by rw [h1, hn]; ring
    _ = _ := by rw [hX]
