import DiophantineConsistency.ArithmeticConstructionVariation
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticConstructionVariation).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticConstructionVariation" then
   logInfo m!"DECL {n}"
