from pathlib import Path
import hashlib,json
R=Path('/tmp/packing-rotation-simplify');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records={p:json.loads((R/f'{p}-records.json').read_text()) for p in ('baseline','final')}
for phase,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticPacking','ArithmeticPackingCells','ArithmeticConstructionVariation']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log'])
  if phase=='baseline' or x['module']!='ArithmeticPacking': assert x['before']==h(W/f"{x['module']}.lean")
  for dep in x['direct_inputs']:
   assert dep['before']==dep['after']==h(dep['path'])
   if dep['module'].endswith('.ArithmeticPacking'):assert dep['before']==rr[0]['object_sha256']
 assert rr[0]['direct_inputs'][0]['before']=='511443f5b5ad420e48edba68f4d9790630d4f377dc758f6743b98e2e84ab02af'
p=next(x for x in json.loads(Path('/tmp/origin-block-sharing/records.json').read_text()) if x['module']=='ArithmeticPackingBlocks' and x['phase']=='final' and x.get('status')==0)
assert p['source_before']==p['source_after']==h(W/'ArithmeticPackingBlocks.lean') and p['object_sha256']==records['baseline'][0]['direct_inputs'][0]['before']
refs=[]
for fn in ('refreshed2-common-records.json','refreshed2-final-records.json'):
 for r in json.loads((Path('/tmp/variation-tail-sharing')/fn).read_text()):refs+=r.get('direct_inputs',[])
for mod in ('ArithmeticPackingCells','ArithmeticConstructionVariation'):
 for d in next(x for x in records['baseline'] if x['module']==mod)['direct_inputs']:
  if d['module'].endswith('.ArithmeticPacking'):continue
  p=next(x for x in refs if x['module']==d['module'] and x['object_before']==d['before'] and x['source_before']==h(W/(d['module'].split('.')[-1]+'.lean')))
  assert p['object_before']==p['object_after'] and p['source_before']==p['source_after']
for probe in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=json.loads((R/f'probe-{probe}-{phase}.json').read_text())
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[phase][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{probe}.log').read_bytes()==(R/f'final-{probe}.log').read_bytes()
for client in ('ArithmeticPackingCells','ArithmeticConstructionVariation'):
 rows=json.loads((R/f'{client}-probe-records.json').read_text());assert len(rows)==8
 for x in rows:
  rr=records[x['phase']]; c=next(z for z in rr if z['module']==client)
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[rr[0]['object_sha256'],c['object_sha256']] and x['log_sha256']==h(x['log'])
 for probe in ('names','interfaces','simp','instances'):assert (R/f'baseline-{client}-{probe}.log').read_bytes()==(R/f'final-{client}-{probe}.log').read_bytes()
print('PASS: paired targets/clients, prior direct-provider matches, target/client namespace and registrations')
