ArithmeticPacking.rot_identity: isolated proof simplification

Baseline ArithmeticPacking SHA-256 eb92dd7e3396a8b82b1f44c82bf0c8b2d28e23cde8baae58f69db1b64055ffd9;
final SHA-256 2737ce5e57ce62bb771775812d5b6ec5201db03c8b4d209224d2ddaf57b0a9dc.
Only the rot_identity proof changes (5 added/11 removed lines): combine the
subtraction and quotient term algebraically before applying the existing bound,
exponent identity and div/mod equation. The theorem statement, he guard,
imports and all definitions remain unchanged. The module was introduced by
Claude-coauthored 5fcd5632b3b753237437f22904b899653f69916b; rot_identity was
moved into it by 9aee4917b7f, which attributes the original variation proof to
Claude. We do not claim the latter commit itself has a Co-Authored-By trailer.

baseline-records.json and final-records.json record successful paired target,
ArithmeticPackingCells and ArithmeticConstructionVariation builds; these are
the two direct source importers in the Lean tree. Source, direct imported object,
output and log hashes are recorded before/after, except source hashes of the
direct imports are cross-checked against prior source/object build receipts
rather than sampled during these builds. Source/object matches for the direct
ArithmeticPackingBlocks provider are in /tmp/origin-block-sharing/records.json;
PackingCells' three other inputs and Variation's ControllerChoice input match
/tmp/variation-tail-sharing/refreshed2-common-records.json and
refreshed2-final-records.json. Those are prior records with before/after input
hashes, and the direct provider objects were pinned in the present builds. A
full current-source transitive closure was not rebuilt, including the cached
Pell, HalfBinomial, tiling and WindowDigits boundaries.

Single paired user CPU samples (shared-load, not benchmark-quality): target
19.06/19.85s; PackingCells 40.43/40.42s; Variation 33.50/33.35s (baseline/final).
PackingCells output bytes differ (baseline 64b4afbf8f01756073df4cf82beffb3f4e5e83d71be0388d7c4d4704da38dee6,
final 463c6d28cd093ae86ca51b9806a01172d3e6fede16d3ab80358f48caaa207b5b);
Variation bytes match. The reason for differing PackingCells bytes is unknown.

A preliminary standalone proof lacked namespace opens and failed on unknown
exp_mul_add: probe-failed.log preserves the error, but its exact pre-fix source
was overwritten. Corrected probe.lean succeeds. A separate initial baseline
build failed because an overlay namespace shadowed PackingBlocks; the failed
receipt, log and time are preserved in setup-failed/. After symlinks were
populated, an attempted population of a not-yet-created final directory threw
FileNotFoundError; that terminal output was not separately saved. The directory
was populated before the paired final build, and all final receipts are complete.

All 63 target namespace declaration/type/axiom reports, including generated and
private names, match; its default simp (29,064) and instance (13,177) lists also
match. PackingCells' 88 and Variation's 6 declaration/type/axiom reports match;
their respective simp/instance lists also match (29,791/13,431 and
38,804/16,567). The paired client probes pin both target and client objects
before/after each invocation. Logs and probe JSONs are preserved at the root.
These checks do not assert identity of proof bodies or every persistent Lean
environment extension. Both target build logs have the same preexisting
warnings at shifted line numbers; PackingCells has the same existing warnings,
and Variation has none. audit.py and audit.log verify successful receipts,
prior direct provider matches, probe source/object pins and all paired outputs.
