import DiophantineConsistency.ArithmeticPacking
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPacking).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPacking" then
   logInfo m!"DECL {n}"
