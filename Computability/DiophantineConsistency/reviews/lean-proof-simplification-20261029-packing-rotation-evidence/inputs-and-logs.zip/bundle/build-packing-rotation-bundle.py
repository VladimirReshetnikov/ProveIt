from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-packing-rotation-evidence';out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/packing-rotation-simplify');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','final','setup-failed']:
 for p in sorted((R/phase).rglob('*')):
  if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('snapshots/'+str(p.relative_to(R)),p)
for name in ['packing-rotation-peer-review.txt','packing-rotation-peer-audit.py','packing-rotation-peer-audit.log','packing-rotation-peer-audit-preliminary-failure.log','packing-rotation-peer-audit-preliminary-schema-failure.log']:add('independent/'+name,I/name)
refs={'prior/packing-block-records.json':'origin-block-sharing/records.json','prior/variation-refreshed2-common-records.json':'variation-tail-sharing/refreshed2-common-records.json','prior/variation-refreshed2-final-records.json':'variation-tail-sharing/refreshed2-final-records.json','prior/variation-refreshed2-provider-matches.json':'variation-tail-sharing/refreshed2-provider-matches.json','prior/standard-casts-provider-audit.json':'mask-ins-simplify/independent-direct-provider-audit.json','prior/standard-casts-provider-mapping.json':'mask-ins-construction/provider-mapping.json','prior/wang-initial-records.json':'wang-initial-sharing/records.json','prior/controller-choice-common-records.json':'controller-stride-period/common-records.json'}
for n,p in refs.items():add(n,I/p)
add('prior/kernel-assembly-common-records.json','/dev/shm/claude-transport-sharing/assembly-common-records.json');add('bundle/build-packing-rotation-bundle.py',Path(__file__))
commit='2fd68625e5cf6db4466c4f5b6322f35d6df8bd40';parent='062d55baa10cee9a598b228452c6636ce9a7c57c';base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';h=lambda b:hashlib.sha256(b).hexdigest()
for phase,ref in [('baseline',parent),('final',commit)]:
 for name in ['ArithmeticPacking','ArithmeticPackingCells','ArithmeticConstructionVariation']:
  data=subprocess.check_output(['git','show',ref+':'+base+name+'.lean']);assert data==files['snapshots/'+phase+'/DiophantineConsistency/'+name+'.lean']
  if name=='ArithmeticPacking':files['commit/'+phase+'.lean']=data
block=next(x for x in json.loads(files['prior/packing-block-records.json']) if x['phase']=='final' and x['module']=='ArithmeticPackingBlocks' and x['status']==0);mapping=json.loads(files['prior/variation-refreshed2-provider-matches.json'])
for n in ['ArithmeticPackingBlocks','ArithmeticStandardCasts','CurrentKernelData2011','ArithmeticWangPlane','ArithmeticControllerChoice']:
 data=subprocess.check_output(['git','show',commit+':'+base+n+'.lean']);expected=block['source_before'] if n=='ArithmeticPackingBlocks' else next(x['source'] for x in mapping if x['module']==n and x['matches']);assert h(data)==expected;files['providers/current/'+n+'.lean']=data
failed=json.loads(files['snapshots/setup-failed/baseline-records.json'])[0];assert failed['status']!=0 and failed['before']==h(files['commit/baseline.lean']) and failed['log_sha256']==h(files['snapshots/setup-failed/baseline-ArithmeticPacking.log'])
review=files['independent/packing-rotation-peer-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Simplify Packing rotation identity arithmetic proof',
 'validation':'Paired target and both ArithmeticPackingCells and ArithmeticConstructionVariation direct-client builds pass. Current-source direct provider pairs match earlier source-built and mapping receipts. All 63 target, 88 PackingCells and six Variation namespace declaration/type/axiom reports and their global simp/instance reports match; each client probe pins target and client objects.',
 'limitations':['ArithmeticConstructionVariation client object hashes match; ArithmeticPackingCells object hashes differ for an undetermined reason. Interface and registration reports do not establish equality of client proof bodies, serialized objects or every environment extension.','An initial baseline build failed when an incomplete overlay shadowed the PackingBlocks provider; its structured receipt, log and time are retained. An earlier standalone probe error log survives but its exact pre-fix source was overwritten.','Two independent-audit setup attempts misread the prior PackingBlocks receipt schema; their logs are preserved and the corrected post-commit audit passes. These script-only errors did not affect Lean builds.','Direct provider pairs trace to prior producer and mapping receipts; broader project and package transitive closures remain cached. Single paired shared-load timings do not establish a general performance effect.','Compiled objects are not included in the ZIP; object hashes and first-provider resolution are recorded in receipts, and external objects are needed for independent byte checks.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
