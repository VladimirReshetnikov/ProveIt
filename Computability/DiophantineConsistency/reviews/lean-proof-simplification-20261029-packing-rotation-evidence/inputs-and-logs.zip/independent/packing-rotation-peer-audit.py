from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/packing-rotation-simplify');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
a=(R/'baseline/DiophantineConsistency/ArithmeticPacking.lean').read_text();b=(R/'final/DiophantineConsistency/ArithmeticPacking.lean').read_text();start='  have h1 :';end='\nsection main';assert a.split(start,1)[0]==b.split(start,1)[0] and a.split(end,1)[1]==b.split(end,1)[1];rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPacking.lean'
for ref,ph in [('2fd68625e5^','baseline'),('2fd68625e5','final')]:
 assert hashlib.sha256(subprocess.check_output(['git','show',ref+':'+rel])).hexdigest()==h(R/ph/'DiophantineConsistency/ArithmeticPacking.lean');print('git source snapshot matches',ref,ph)
assert h(W/'ArithmeticPacking.lean')==h(R/'final/DiophantineConsistency/ArithmeticPacking.lean');print('edit confined to rotation identity arithmetic proof; workspace now final')
block=next(x for x in read('/tmp/origin-block-sharing/records.json') if x['phase']=='final' and x['module']=='ArithmeticPackingBlocks' and x['status']==0);assert block['status']==0 and block['source_before']==block['source_after']==h(W/'ArithmeticPackingBlocks.lean') and block['object_sha256']==h(block['command'][-1]);print('source-built PackingBlocks prior provider matched',block['object_sha256'])
prior=read('/tmp/variation-tail-sharing/refreshed2-provider-matches.json');providers={'ArithmeticPackingBlocks':block['object_sha256']}
for n in ['ArithmeticStandardCasts','CurrentKernelData2011','ArithmeticWangPlane','ArithmeticControllerChoice']:
 choices=[x for x in prior if x['module']==n and x['source']==h(W/(n+'.lean')) and x['matches']];assert choices,n;providers[n]=choices[0]['object'];print('prior current source/object provider mapping',n,providers[n])
directrefs=[('ArithmeticStandardCasts','/tmp/mask-ins-simplify/independent-direct-provider-audit.json'),('CurrentKernelData2011','/dev/shm/claude-transport-sharing/assembly-common-records.json'),('ArithmeticWangPlane','/tmp/wang-initial-sharing/records.json'),('ArithmeticControllerChoice','/tmp/controller-stride-period/common-records.json')]
for n,path in directrefs:
 data=read(path)
 if isinstance(data,dict):
  x=data['DiophantineConsistency.'+n];assert x['source_sha256']==h(W/(n+'.lean')) and x['object_sha256']==providers[n] and x['matching_prior_rows']
 else:
  matches=[x for x in data if x.get('module','').split('.')[-1]==n and x.get('status')==0 and x.get('object_sha256')==providers[n] and x.get('source_sha256',x.get('source_before',x.get('before')))==h(W/(n+'.lean'))];assert matches,(n,path)
 print('underlying producer/mapping receipt',n,path)
rows={}
for ph in ['baseline','final']:
 rec=read(R/(ph+'-records.json'));assert len(rec)==3
 for x in rec:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][4]).read_text()
  if n!='ArithmeticPacking':assert x['before']==h(W/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n0=d['module'].split('.')[-1]
   if n0=='ArithmeticPacking':assert d['before']==rows[ph,n0]['object_sha256'] and d['resolved']==rows[ph,n0]['object']
   else:assert n0 in providers and d['before']==providers[n0],(ph,n,n0)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for n in ['ArithmeticPackingCells','ArithmeticConstructionVariation']:print('client object identical?',n,rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'])
for kind in ['names','interfaces','simp','instances']:
 for ph in ['baseline','final']:
  x=read(R/f'probe-{kind}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticPacking']['object_sha256'] and x['log_sha256']==h(x['log'])
 a=(R/('baseline-'+kind+'.log')).read_bytes();b=(R/('final-'+kind+'.log')).read_bytes();print('target probe',kind,'identical?',a==b,'line counts',len(a.splitlines()),len(b.splitlines()))
for client in ['ArithmeticPackingCells','ArithmeticConstructionVariation']:
 records=read(R/(client+'-probe-records.json'));assert len(records)==8
 for x in records:
  ph=x['phase'];expected=[rows[ph,n]['object_sha256'] for n in ['ArithmeticPacking',client]];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==expected and all(h(p)==v for p,v in zip(x['objects'],expected)) and x['log_sha256']==h(x['log'])
 for k in ['names','interfaces','simp','instances']:
  a=(R/('baseline-'+client+'-'+k+'.log')).read_bytes();b=(R/('final-'+client+'-'+k+'.log')).read_bytes();assert a==b;print('client probe',client,k,'identical',len(a.splitlines()),'lines, target/client pinned')
 assert sum(x.startswith('DECL ') for x in (R/('baseline-'+client+'-names.log')).read_text().splitlines())==({'ArithmeticPackingCells':88,'ArithmeticConstructionVariation':6}[client])
f=read(R/'setup-failed/baseline-records.json')[0];assert f['status']!=0 and f['before']==f['after']==h(R/'baseline/DiophantineConsistency/ArithmeticPacking.lean') and f['log_sha256']==h(R/'setup-failed/baseline-ArithmeticPacking.log') and f['time']==(R/'setup-failed/baseline-ArithmeticPacking.time').read_text() and 'ArithmeticPackingBlocks.olean' in (R/'setup-failed/baseline-ArithmeticPacking.log').read_text();print('initial missing-overlay failure receipt and copied log/time match')
assert 'Unknown identifier `exp_mul_add`' in (R/'probe-failed.log').read_text();print('standalone failure log preserved; exact pre-fix source overwritten')
print('PASS paired builds/probe receipts; transitive closure remains cached')
