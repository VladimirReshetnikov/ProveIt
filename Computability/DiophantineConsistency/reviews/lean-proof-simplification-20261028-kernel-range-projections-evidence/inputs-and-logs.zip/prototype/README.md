# Generated kernel range projections

This isolated candidate changes `SplitKernelData59` and `GapKernelData66` and
their two generators. Each of six coefficient-bound proofs previously bound
eight conjunct projections under one-use names. It now passes the same eight
projections directly to `nlinarith only`, preserving the four original range
guards, the port-box facts, each coefficient record, the target bound, and the
existing imports. It removes 48 `have` lines with no new declaration or tactic.
No repository file has been changed by this experiment.

The candidate and baseline sources and generators are under `final` and
`baseline`. `source-generator-comparison.json` verifies the transformation is
exactly this substitution, and verifies the two production wrapper sources are
unchanged. `generator-check-records.json` records successful split-generator
replay and gap-generator `--check` for both snapshots, including unchanged
source/output hashes, SHA-pinned data, helper-generator hashes and logs. The
generator helper sources are resolved from the workspace through symlinks;
the record contains their actual paths and hashes. An early Python setup typo
failed before starting generation; `generator-setup-failure.log` preserves it.

The replay overlays use source-matched providers: SplitGeometry59 and
GapGeometry66 from `geometry-provider-records.json`; SplitWordBounds from
`wordbounds-provider-records.json`; and the two certificate providers from the
same geometry record. The records contain the source and object hashes. These
providers and package objects rely on a cached transitive closure; this is not a
full current-source closure rebuild. The candidate was tested first, followed
by the baseline, with sequential jobs and shared machine load. See
`kernel-final-records.json` and `kernel-baseline-records.json` for input hashes,
commands, outputs and timings. Each phase builds both changed targets and the
existing SplitKernels59 and GapKernels66 production wrappers.

A specific cached boundary is visible in `wordbounds-provider-records.json`:
SplitWordBounds uses PolynomialRangeBounds object
`b99e674cf03dbe97caf6ec673511b526367648168630893a8df075c01e06c420`,
which uses SelectiveCoefficientBounds object
`1f2bffef4cc603725a857ae379e246498e36d7d85ad5645c36fbc14adab1c1a8`.
That object was recorded against source
`37e667a4173b07151027ba0f0deba69afee759e41ff47fd162e3c5dec179d175`,
while the workspace source currently hashes to
`3ae275d0b3db3d542b2595967966857138365924da4fd8f3102ae539d10ad7ee`.
All paired builds use the same pinned provider objects. Other transitive
inputs are cached and may also differ from current sources.

For context, prior paired receipts in `prior-coefficient-receipts/` rebuild
PolynomialRangeBounds against both that old SelectiveCoefficientBounds object
and the current-source object
`2db897e32f0defa0396d4d13ae237205c807fd33f923dbfa23243fc3ab70040f`.
Both produced the exact same PolynomialRangeBounds object `b99e674c…`.
This narrows the observed effect but does not change which transitive object
the present overlays actually load; the cached-boundary qualification remains.

Both target and wrapper builds succeeded. Baseline / candidate user CPU was
89.78 / 89.89 seconds for SplitKernelData59, 82.83 / 82.34 for
GapKernelData66, 54.02 / 55.23 for SplitKernels59, and 49.83 / 51.93 for
GapKernels66. One paired sample under shared load is not a general benchmark.
All four baseline and candidate `.olean` hashes differ, including the wrapper
objects; the interface probes below test the corresponding visible effects.

`coherent-probe-records.json` pins both targets for paired probes: all 88
names, public type/axiom outputs and private type/axiom outputs match; the
55,118-entry global simp and 23,324-entry instance reports match. The probes
also print selected definition equations in `probe-*-names.log`.
`client-probe-records.json` pins all four targets and wrappers. The 36 wrapper
names, public type/axiom outputs, private-name census (empty in both phases),
55,118 simp entries, and 23,324 instance entries match. Matching outputs are
byte-identical; `coherent-names-diff.json` and `client-names-diff.json` have no
added or removed names. These focused probes do not prove equality of every
possible environment extension or every transitive client.
