import DiophantineConsistency.SplitKernels59
import DiophantineConsistency.GapKernels66
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.SplitKernels59).isPrefixOf n ||
     (`DiophantineConsistency.GapKernels66).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.GapKernels66" ||
     (toString n).startsWith "_private.DiophantineConsistency.SplitKernels59" then
   logInfo m!"DECL {n}"
