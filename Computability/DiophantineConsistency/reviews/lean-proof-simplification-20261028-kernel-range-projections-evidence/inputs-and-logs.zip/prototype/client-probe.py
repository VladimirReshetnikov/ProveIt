from pathlib import Path
import os,subprocess,hashlib,json,re
R=Path('/tmp/kernel-range-projections');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
def run(phase,probe):
 src=R/(probe+'.lean');out=R/('client-probe-'+phase+'-'+probe+'.log');env=os.environ.copy();env['LEAN_PATH']=str(R/('objects-'+phase))+':'+base;cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)];b=sha(src);obj=[R/('objects-'+phase)/'DiophantineConsistency'/f'{n}.olean' for n in ['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66']];h=[sha(o) for o in obj]
 with out.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'probe':probe,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'source':str(src),'source_before':b,'source_after':sha(src),'objects_before':h,'objects_after':[sha(o) for o in obj],'status':r.returncode,'log':str(out),'log_sha256':sha(out)};records.append(rec);(R/'client-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,probe,r.returncode,flush=True)
 if r.returncode or b!=rec['source_after'] or h!=rec['objects_after']:raise SystemExit(1)
for phase in ['baseline','final']:run(phase,'client-names')
def names(p):return {s[5:] for s in (R/('client-probe-'+p+'-client-names.log')).read_text().splitlines() if s.startswith('DECL ')}
a=names('baseline');b=names('final');print('names:',len(a),len(b),'removed',len(a-b),'added',len(b-a));(R/'client-names-diff.json').write_text(json.dumps({'removed':sorted(a-b),'added':sorted(b-a)},indent=2)+'\n')
ns=[n for n in sorted(a&b) if not n.startswith('_private.')]
(R/'client-interfaces.lean').write_text('import DiophantineConsistency.SplitKernels59\nimport DiophantineConsistency.GapKernels66\nset_option pp.universes true\nset_option pp.explicit true\n'+''.join(f'#check {n}\n#print axioms {n}\n' for n in ns))
for phase in ['baseline','final']:
 for probe in ['client-interfaces','client-simp','client-instances']:run(phase,probe)
for phase in ['baseline','final']:run(phase,'client-private')
