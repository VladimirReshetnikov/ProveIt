from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/kernel-range-projections'); P=Path('Computability/DiophantineConsistency').resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); records=[]
inputs=[P/'tools/generate_split_certificate59.py',P/'tools/generate_gap_certificate66.py',P/'data/split59/split_kernels.json']+[P/'candidates/gap2082-compact54/data/H2082'/n for n in ['source.json','layout.json','kernels.json']]
for phase in ['baseline','final']:
 root=R/phase
 for kind in ['split','gap']:
  src=[root/'Lean/DiophantineConsistency'/n for n in (['SplitKernelData59.lean'] if kind=='split' else ['GapKernelData66.lean','GapKernels66.lean'])]
  script=root/('tools/generate_'+kind+'_kernels'+('59.py' if kind=='split' else '66.py'))
  cmd=['python3',str(script)]+(['--check'] if kind=='gap' else [])
  before={str(p):sha(p) for p in [script,*inputs,*src]}
  log=R/f'gen-{phase}-{kind}.log'
  with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  after={str(p):sha(p) for p in [script,*inputs,*src]}
  records.append({'phase':phase,'kind':kind,'command':cmd,'status':r.returncode,'before':before,'after':after,'log':str(log),'log_sha256':sha(log)})
  (R/'generator-check-records.json').write_text(json.dumps(records,indent=2)+'\n')
  print(phase,kind,r.returncode,'unchanged',before==after,flush=True)
  if r.returncode or before!=after:raise SystemExit(1)
