import DiophantineConsistency.GapKernelData66
#print equations DiophantineConsistency.SplitKernelData59.sparseKernel
#print equations DiophantineConsistency.GapKernelData66.D0
#print equations DiophantineConsistency.GapKernelData66.D1
#print equations DiophantineConsistency.GapKernelData66.D2
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.SplitKernelData59).isPrefixOf n ||
     (`DiophantineConsistency.GapKernelData66).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.GapKernelData66" ||
     (toString n).startsWith "_private.DiophantineConsistency.SplitKernelData59" then
   logInfo m!"DECL {n}"
