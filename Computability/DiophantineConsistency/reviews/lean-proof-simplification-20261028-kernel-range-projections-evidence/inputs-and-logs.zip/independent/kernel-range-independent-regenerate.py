from pathlib import Path
import hashlib,subprocess,json,shutil
r=Path('/tmp/kernel-range-projections');out=Path('/tmp/kernel-range-independent-regenerate');out.mkdir(exist_ok=True);h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for phase in ('baseline','final'):
 src=r/phase;dest=out/phase;(dest/'tools').mkdir(parents=True,exist_ok=True);(dest/'Lean/DiophantineConsistency').mkdir(parents=True,exist_ok=True)
 for q in ('data','candidates'):(dest/q).symlink_to((src/q).resolve(),target_is_directory=True)
 for q in (src/'tools').iterdir():
  t=dest/'tools'/q.name
  if q.name in ('generate_split_kernels59.py','generate_gap_kernels66.py'):shutil.copy2(q,t)
  else:t.symlink_to(q.resolve())
 for n in ('SplitKernelData59.lean','GapKernelData66.lean','SplitKernels59.lean','GapKernels66.lean'):shutil.copy2(src/'Lean/DiophantineConsistency'/n,dest/'Lean/DiophantineConsistency'/n)
 for kind in ('split','gap'):
  pin=next(x for x in json.loads((r/'generator-check-records.json').read_text()) if x['phase']==phase and x['kind']==kind);inputs={k:h(k) for k in pin['before'] if not k.startswith(str(src))}; assert all(v==pin['before'][k] for k,v in inputs.items());script=dest/'tools'/('generate_'+kind+'_kernels'+('59.py' if kind=='split' else '66.py'));cmd=['python3',str(script)]+(['--check'] if kind=='gap' else []);before=h(script);q=subprocess.run(cmd,capture_output=True);log=out/(phase+'-'+kind+'.log');log.write_bytes(q.stdout+q.stderr);assert q.returncode==0 and h(script)==before
  names=['SplitKernelData59.lean'] if kind=='split' else ['GapKernelData66.lean','GapKernels66.lean'];outputs={n:h(dest/'Lean/DiophantineConsistency'/n) for n in names};assert all(h(src/'Lean/DiophantineConsistency'/n)==v for n,v in outputs.items());assert all(h(k)==v for k,v in inputs.items());records.append({'external_inputs_before':inputs,'external_inputs_after':{k:h(k) for k in inputs},'phase':phase,'kind':kind,'command':cmd,'status':q.returncode,'script_sha256':before,'outputs':outputs,'log':str(log),'log_sha256':h(log)});print(phase,kind,'independent regeneration matches',outputs)
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
