from pathlib import Path
import hashlib
r=Path('/tmp/kernel-range-projections');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fields='bkmf'
old=''.join(f'  have h{q}{i} := h{q}.{i+1}\n' for q in fields for i in (0,1))
oldrefs=','.join(f'h{q}{i}' for q in fields for i in (0,1));newrefs=','.join(f'h{q}.{i+1}' for q in fields for i in (0,1))
for folder,n,expected in [('Lean/DiophantineConsistency','SplitKernelData59.lean',3),('Lean/DiophantineConsistency','GapKernelData66.lean',3),('tools','generate_split_kernels59.py',1),('tools','generate_gap_kernels66.py',1)]:
 a=r/'baseline'/folder/n;b=r/'final'/folder/n;s=a.read_text();assert s.count(old)==expected and s.count(oldrefs)==expected and s.replace(old,'').replace(oldrefs,newrefs)==b.read_text();print(n,'matches exact projection substitution',expected,'source hashes',h(a),h(b))
for n in ('SplitKernels59.lean','GapKernels66.lean'):
 a=r/'baseline/Lean/DiophantineConsistency'/n;b=r/'final/Lean/DiophantineConsistency'/n;assert a.read_bytes()==b.read_bytes();print('wrapper identical',n,h(a))
