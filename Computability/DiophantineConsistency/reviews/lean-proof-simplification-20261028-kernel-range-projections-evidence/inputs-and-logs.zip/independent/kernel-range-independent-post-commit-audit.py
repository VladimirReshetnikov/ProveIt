from pathlib import Path
import hashlib,json,subprocess
r=Path('/tmp/kernel-range-projections');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior={};rows={}
for f in ('geometry-provider-records.json','wordbounds-provider-records.json'):
 for x in json.loads((r/f).read_text()):
  if x.get('phase','final')=='final' and x['status']==0:
   n=x['module'];assert x['before']==x['after'] and x['object_sha256']==h(x['object'])
   if n=='SelectiveCoefficientBounds':
    old=hashlib.sha256(subprocess.check_output(['git','show','dcba8839c3^:Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+n+'.lean'])).hexdigest();assert x['before']==old and old!=h(repo/(n+'.lean'));print('cached older transitive',n,'source',old,'object',x['object_sha256'],'current source',h(repo/(n+'.lean')))
   else:assert x['before']==h(x['source'])==h(repo/(n+'.lean'));print('provider',n,'current source/object',x['before'],x['object_sha256'])
   prior[n]=x
for ph in ('baseline','final'):
 xs=json.loads((r/f'kernel-{ph}-records.json').read_text());assert len(xs)==4
 for x in xs:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'kernel-{ph}-{n}.time').read_text()
  if ph=='baseline' or n in ('SplitKernels59','GapKernels66'):assert x['before']==h(r/'baseline/Lean/DiophantineConsistency'/(n+'.lean') if n in ('SplitKernelData59','GapKernelData66') else repo/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1]
   if m in prior:assert d['before']==prior[m]['object_sha256'];print('prior direct provider',ph,n,m)
   elif m in ('SplitKernelData59','GapKernelData66'):assert d['resolved']==rows[(ph,m)]['object'] and d['before']==rows[(ph,m)]['object_sha256'];print('same-phase direct',ph,n,m)
   else:assert d['module']=='Mathlib.Tactic.Linarith'
  rows[(ph,n)]=x;print('build',ph,n,x['time'].strip())
for x in json.loads((r/'generator-check-records.json').read_text()):
 assert x['status']==0 and x['before']==x['after'] and all(h(k)==v for k,v in x['before'].items()) and h(x['log'])==x['log_sha256'];print('generator prior check',x['phase'],x['kind'],'pins',len(x['before']))
for x in json.loads(Path('/tmp/kernel-range-independent-regenerate/records.json').read_text()):
 assert x['status']==0 and x['external_inputs_before']==x['external_inputs_after'] and all(h(k)==v for k,v in x['external_inputs_before'].items()) and h(x['log'])==x['log_sha256'];print('independent generator',x['phase'],x['kind'],'pins',len(x['external_inputs_before']))
print('wrapper object matches?',[(n,rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256']) for n in ('SplitKernels59','GapKernels66')])
for f,mods in [('coherent-probe-records.json',['SplitKernelData59','GapKernelData66']),('client-probe-records.json',['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66'])]:
 xs=json.loads((r/f).read_text());assert len(xs)==10
 for x in xs:
  ph=x['phase'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(x['log']) and x['objects_before']==x['objects_after']==[rows[(ph,n)]['object_sha256'] for n in mods]
  for n,v in zip(mods,x['objects_before']):assert h(r/('objects-'+ph)/'DiophantineConsistency'/(n+'.olean'))==v
  print('probe',f,ph,x['probe'],'verified')
for prefix,names in [('probe',['names','coherent-interfaces','simp','instances','private']),('client-probe',['client-names','client-interfaces','client-simp','client-instances','client-private'])]:
 for n in names:
  a=(r/f'{prefix}-baseline-{n}.log').read_bytes();b=(r/f'{prefix}-final-{n}.log').read_bytes();assert a==b;print(prefix,n,'identical',len(a.splitlines()),'lines')
oldsrc='37e667a4173b07151027ba0f0deba69afee759e41ff47fd162e3c5dec179d175';newsrc='3ae275d0b3db3d542b2595967966857138365924da4fd8f3102ae539d10ad7ee';oldobj='1f2bffef4cc603725a857ae379e246498e36d7d85ad5645c36fbc14adab1c1a8';newobj='2db897e32f0defa0396d4d13ae237205c807fd33f923dbfa23243fc3ab70040f';outputs=[]
for ph,rf,cf,ss,oo in [('baseline','baseline-records.json','baseline-clients-records.json',oldsrc,oldobj),('final','final-records.json','final-clients2-records.json',newsrc,newobj)]:
 root=r/'prior-coefficient-receipts';x=next(q for q in json.loads((root/rf).read_text()) if q['module']=='SelectiveCoefficientBounds');y=next(q for q in json.loads((root/cf).read_text()) if q['module']=='PolynomialRangeBounds')
 for q in (x,y):assert q['status']==0 and q['before']==q['after']==h(q['source']) and q['object_sha256']==h(q['object']) and q['log_sha256']==h(q['log']) and q['time']==Path(q['command'][q['command'].index('-o')+1]).read_text()
 assert x['before']==ss and x['object_sha256']==oo and y['direct_inputs'][0]['before']==y['direct_inputs'][0]['after']==oo and y['direct_inputs'][0]['resolved']==x['object'];outputs.append(y['object_sha256']);print('prior coefficient comparison',ph,'source/object and direct linkage verified')
assert outputs[0]==outputs[1]==prior['PolynomialRangeBounds']['object_sha256'];print('PolynomialRangeBounds output hashes equal across prior coefficient providers')

import subprocess
root='Computability/DiophantineConsistency/'
for folder,n in [('Lean/DiophantineConsistency','SplitKernelData59.lean'),('Lean/DiophantineConsistency','GapKernelData66.lean'),('tools','generate_split_kernels59.py'),('tools','generate_gap_kernels66.py')]:
 for ph,ref in [('baseline','784c1c2775^'),('final','784c1c2775')]:
  data=subprocess.check_output(['git','show',ref+':'+root+folder+'/'+n]);assert data==(r/ph/folder/n).read_bytes()
  if ph=='final':assert data==Path(root+folder+'/'+n).read_bytes()
  print('git',ph,n,'snapshot verified')
