import os,pathlib,subprocess,json,hashlib,time,sys
P=pathlib.Path;root=P('/tmp/kernel-eval-rewrite');shared=root/'normal-prereq';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[]
for phase in ('baseline','final'):
 overlay=root/('normal-'+phase)
 for ns in ('BusyBeaver','Diophantine','DiophantineConsistency'):
  for p in (shared/ns).rglob('*.olean'):
   q=overlay/p.relative_to(shared);q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(p.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','');n='CurrentKernelResidues2011';srcroot=root/(phase+'-src');src=srcroot/'DiophantineConsistency'/(n+'.lean');obj=overlay/'DiophantineConsistency'/(n+'.olean');obj.unlink(missing_ok=True)
 for tag,p,srcbase,o in [('target',src,srcroot,obj),('client-units',P('Computability/DiophantineConsistency/Lean/DiophantineConsistency/CurrentControllerUnits2011.lean'),P('Computability/DiophantineConsistency/Lean'),overlay/'DiophantineConsistency/CurrentControllerUnits2011.olean'),('client-checks',P('Computability/DiophantineConsistency/Lean/DiophantineConsistency/CurrentKernelResidues2011Checks.lean'),P('Computability/DiophantineConsistency/Lean'),overlay/'DiophantineConsistency/CurrentKernelResidues2011Checks.olean')]:
  o.unlink(missing_ok=True);log=root/('normal-'+phase+'-'+tag+'.log');tm=root/('normal-'+phase+'-'+tag+'.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcbase),str(p),'-o',str(o)];t=time.monotonic();before=sha(p)
  with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  d={'phase':phase,'tag':tag,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':sha(p),'log_sha256':sha(log),'time_sha256':sha(tm)}
  if o.exists():d.update(object_sha256=sha(o),object_bytes=o.stat().st_size)
  rec.append(d);(root/'normal-phases.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,tag,v.returncode,round(d['seconds'],2),flush=True)
  if v.returncode or before!=sha(p):sys.exit(1)
 probe=root/(n+'-axioms.lean');log=root/('normal-'+phase+'-axioms.log');cmd=['lean','-M6000','-j1','-DElab.async=false',str(probe)];t=time.monotonic()
 with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec.append({'phase':phase,'tag':'axioms','cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':sha(probe),'log_sha256':sha(log),'target_object_sha256':sha(obj)});(root/'normal-phases.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,'axioms',v.returncode,flush=True)
 if v.returncode:sys.exit(v.returncode)
if (root/'normal-baseline-axioms.log').read_bytes()!=(root/'normal-final-axioms.log').read_bytes():sys.exit('axiom reports differ')
print('all 19 axiom reports match',flush=True)
