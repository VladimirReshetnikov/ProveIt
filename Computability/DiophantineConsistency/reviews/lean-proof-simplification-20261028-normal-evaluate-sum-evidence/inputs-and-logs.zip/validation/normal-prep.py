import os,pathlib,re,subprocess,json,hashlib,time,sys
P=pathlib.Path;root=P('/tmp/kernel-eval-rewrite');overlay=root/'normal-prereq';base=P('/tmp/list-getd-sharing-20261028/normal-fresh');build=P('.lake/build/lib/lean').resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for ns in ('DiophantineConsistency','Diophantine','BusyBeaver'):
 src=(base/ns) if (base/ns).exists() else build/ns
 for p in src.rglob('*.olean'):
  q=overlay/p.relative_to(src.parent);q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(p.resolve())
roots=[P('Computability/DiophantineConsistency/Lean'),P('Computability/HilbertTenthProblem/Lean'),P('Computability/BusyBeaver/Lean')];graph={}
def walk(n):
 if n in graph:return
 p=next((r/(n.replace('.','/')+'.lean') for r in roots if (r/(n.replace('.','/')+'.lean')).exists()),None)
 if p is None:return
 ds=re.findall(r'^import\s+([\w.]+)',p.read_text(),re.M);obj=overlay/(n.replace('.','/')+'.olean');graph[n]={'source':str(p),'source_sha256':sha(p),'imports':ds,'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':sha(obj) if obj.exists() else None}
 for d in ds:walk(d)
for n in ('DiophantineConsistency.CurrentKernelResidues2011','DiophantineConsistency.CurrentControllerUnits2011','DiophantineConsistency.CurrentKernelResidues2011Checks'):walk(n)
(root/'normal-graph-before.json').write_text(json.dumps(graph,indent=2)+'\n');env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','');records=[]
for name in ['WangTiles942Core','WangTiles942','WangTiles942Permutation','WangTiles942PhysicalData','WangTiles942PhysicalOrder','CurrentControllerData2011']:
 n='DiophantineConsistency.'+name;p=P(graph[n]['source']);out=overlay/(n.replace('.','/')+'.olean');out.unlink(missing_ok=True);log=root/('normal-prep-'+name+'.log');tm=root/('normal-prep-'+name+'.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p),'-o',str(out)];t=time.monotonic()
 with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_before':graph[n]['source_sha256'],'source_after':sha(p),'log_sha256':sha(log),'time_sha256':sha(tm)}
 if out.exists():rec.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
 records.append(rec);(root/'normal-prep-records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,v.returncode,round(rec['seconds'],2),flush=True)
 if v.returncode or rec['source_before']!=rec['source_after']:sys.exit(1)
