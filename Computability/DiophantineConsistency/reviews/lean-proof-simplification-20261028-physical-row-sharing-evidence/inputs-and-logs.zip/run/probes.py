from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/physical-rows-sharing'); base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();rs=[]
for phase in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/('verified-'+phase+'-lib'))+':'+base
 for tag in ('names','interface'):
  s=p/(tag+'.lean'); log=p/f'verified-{phase}-{tag}.log';tm=p/f'verified-{phase}-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false',str(s)];before=h(s);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  rs.append({'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':h(s),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':time.monotonic()-t});(p/'probe-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,tag,r.returncode,flush=True)
  if r.returncode or h(s)!=before:raise SystemExit(1)
