from pathlib import Path
import tomllib,json,re,hashlib
P=Path('/tmp/physical-rows-sharing');root=Path.cwd();configs=tomllib.loads((root/'lakefile.toml').read_text());roots=list(dict.fromkeys((root/x.get('srcDir','.')).resolve() for x in configs['lean_lib']));h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();seen={}; ext=set(); stack=['DiophantineConsistency.WangTiles942PhysicalData']
while stack:
 n=stack.pop()
 if n in seen or n in ext:continue
 if n in ('DiophantineConsistency.WangTiles942PhysicalData','DiophantineConsistency.MFWangTiles942PhysicalData'):
  f=P/'final/DiophantineConsistency'/(n.split('.')[-1]+'.lean')
 else:
  paths=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).exists()))
  if not paths:ext.add(n);continue
  assert len(paths)==1,(n,paths);f=paths[0]
 im=[]
 for line in f.read_text().splitlines():
  if line.startswith('import '):im.extend(line.split('--')[0].split()[1:])
 seen[n]={'source':str(f),'source_sha256':h(f),'imports':im};stack.extend(im)
for n,v in seen.items():
 if n in ('DiophantineConsistency.WangTiles942PhysicalData','DiophantineConsistency.MFWangTiles942PhysicalData'):continue
 v.update(objects={})
 for phase in ('verified-baseline-lib','verified-final-lib','header-lib'):
  obj=P/phase/(n.replace('.','/')+'.olean')
  if obj.exists():v['objects'][phase]={'path':str(obj.resolve()),'sha256':h(obj)}
  else:v['objects'][phase]={'path':None,'sha256':None}
 if len({x['sha256'] for x in v['objects'].values()})>1: print('MISMATCH',n)
print('source graph',len(seen),'external',len(ext),'project namespaces',sorted({x.split('.')[0] for x in seen}));print('BusyBeaver',sorted(x for x in seen if x.startswith('BusyBeaver.')))
(P/'independent-graph.json').write_text(json.dumps({'nodes':seen,'external':sorted(ext)},indent=2)+'\n')
