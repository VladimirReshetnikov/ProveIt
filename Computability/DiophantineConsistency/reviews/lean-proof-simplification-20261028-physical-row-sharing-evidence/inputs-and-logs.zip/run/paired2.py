from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/physical-rows-sharing'); repo=Path('Computability/DiophantineConsistency/Lean');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=[]
for phase in ['baseline','final']:
 overlay=p/('verified-'+phase+'-lib');env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+base
 for tag,src,root,output in [('target',p/phase/'DiophantineConsistency/WangTiles942PhysicalData.lean',p/phase,overlay/'DiophantineConsistency/WangTiles942PhysicalData.olean'),('client',repo/'DiophantineConsistency/WangTiles942PhysicalOrder.lean',repo,overlay/'DiophantineConsistency/WangTiles942PhysicalOrder.olean')]:
  if output.exists() or output.is_symlink():output.unlink()
  logfile=p/f'verified-{phase}-{tag}.log'; tm=p/f'verified-{phase}-{tag}.time'; cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(output)]; before=h(src);t=time.monotonic()
  with logfile.open('wb') as out:run=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env)
  r={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':run.returncode,'source':str(src),'source_sha256':before,'source_after':h(src),'log_sha256':h(logfile),'time_sha256':h(tm),'object_sha256':h(output) if output.exists() else None,'elapsed':time.monotonic()-t};rs.append(r);(p/'verified-paired-records.json').write_text(json.dumps(rs,indent=2)+'\n'); print(phase,tag,run.returncode,round(r['elapsed'],1),flush=True)
  if run.returncode or before!=r['source_after']:raise SystemExit(1)
