from pathlib import Path
import hashlib,json
p=Path('/tmp/physical-rows-sharing'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for fn in ('verified-paired-records.json','probe-records.json'):
 rs=json.loads((p/fn).read_text());assert len(rs)==4
 for r in rs:
  cmd=r['command'];src=[Path(x) for x in cmd if x.endswith('.lean')];assert len(src)==1
  assert r['status']==0 and h(src[0])==r['source_sha256']==r['source_after'];assert r['lean_path'].split(':')[0]==str(p/('verified-'+r['phase']+'-lib'));assert h(cmd[4])==r['time_sha256']
  log=p/f"verified-{r['phase']}-{r['tag']}.log";assert h(log)==r['log_sha256']
  if 'object_sha256' in r:assert cmd[-2]=='-o' and h(cmd[-1])==r['object_sha256']
 print(fn,'four source/object/log/time/path receipts checked')
assert (p/'verified-baseline-interface.log').read_bytes()==(p/'verified-final-interface.log').read_bytes()
b=set((p/'verified-baseline-names.log').read_text().splitlines());f=set((p/'verified-final-names.log').read_text().splitlines());base='DiophantineConsistency.WangTiles942PhysicalData.';assert b-f=={base+'rows.eq_1',base+'rows_good._simp_2',base+'rows_good._simp_3'} and not f-b
assert 'rows.eq_1' in (p/'verified-final-interface.log').read_text();assert (p/'baseline-foundation-retry.log').read_bytes()==(p/'final-foundation-retry.log').read_bytes()
r=json.loads((p/'data-defeq-record.json').read_text());assert r['status']==0 and r['source_sha256']==r['source_after']==h(p/'data-defeq.lean') and h(p/'data-defeq-recorded.log')==r['log_sha256'] and h(p/'data-defeq-recorded.time')==r['time_sha256']
print('248 matched surviving/forced declarations; lazy rows.eq_1 materialized; 61 data rfl examples pass')
print('Two rows_good generated simp auxiliaries removed; neither registered in default simp set')
print('Ordinary Foundation Matrix collision reproduced identically in baseline and final')
