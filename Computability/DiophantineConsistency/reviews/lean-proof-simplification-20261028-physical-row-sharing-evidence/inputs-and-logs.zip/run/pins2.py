from pathlib import Path
import re,json,hashlib
p=Path('/tmp/physical-rows-sharing');root=Path('Computability/DiophantineConsistency/Lean'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest(); seen=set(); todo=['DiophantineConsistency.WangTiles942PhysicalData']; nodes={}
while todo:
 n=todo.pop()
 if n in seen:continue
 seen.add(n);s=(p/'final/DiophantineConsistency/WangTiles942PhysicalData.lean' if n.endswith('.WangTiles942PhysicalData') else root/(n.replace('.','/')+'.lean'));imports=[m for line in s.read_text().splitlines() if line.startswith('import ') for m in line.split()[1:] if m.startswith('DiophantineConsistency.')];todo.extend(imports);nodes[n]={'source':str(s),'source_sha256':h(s),'imports':imports}
rank={r['module']:r for r in json.loads(Path('/tmp/rank-sharing/target-pins.json').read_text())}; assembly={r['module']:r for r in json.loads(Path('/tmp/outer-seed-bound-sharing/assembly-builds2.json').read_text())};pair=json.loads(Path('/tmp/rank-sharing/paired-records.json').read_text()); selected=next(r for r in pair if r['phase']=='final' and r['tag']=='target'); assert len(nodes)==10
for n,v in nodes.items():
 if n.endswith('.WangTiles942PhysicalData'):continue
 obj=p/'verified-final-lib'/Path(n.replace('.','/')+'.olean');v['object_path']=str(obj.resolve());v['object_sha256']=h(obj)
 if n=='DiophantineConsistency.WangTiles942Permutation': r=selected;v['receipt']='/tmp/rank-sharing/paired-records.json'
 elif n=='DiophantineConsistency.MFWangTiles942PhysicalData':r=assembly[n];v['receipt']='/tmp/outer-seed-bound-sharing/assembly-builds2.json'
 else:r=rank[n];v['receipt']='/tmp/rank-sharing/target-pins.json'
 assert r['source_sha256']==v['source_sha256'] and r['object_sha256']==v['object_sha256'],n
 for ph in ('baseline','final'):assert h(p/('verified-'+ph+'-lib')/Path(n.replace('.','/')+'.olean'))==v['object_sha256'],(n,ph)
(p/'verified-pins.json').write_text(json.dumps(nodes,indent=2)+'\n');print('10-node target graph; all 9 local prerequisites match prior receipts and both overlay object hashes')
