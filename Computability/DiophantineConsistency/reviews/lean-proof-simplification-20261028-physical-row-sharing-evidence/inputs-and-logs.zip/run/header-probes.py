from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/physical-rows-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(p/'header-lib')+':'+base;h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();rs=[]
for tag in ('names','interface','data-defeq'):
 s=p/(tag+'.lean');log=p/f'header-{tag}.log';tm=p/f'header-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false',str(s)];before=h(s)
 with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rs.append({'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':h(s),'log_sha256':h(log),'time_sha256':h(tm)});(p/'header-probe-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(tag,r.returncode,flush=True)
 if r.returncode or h(s)!=before:raise SystemExit(1)
assert (p/'header-interface.log').read_bytes()==(p/'verified-baseline-interface.log').read_bytes()
assert set((p/'header-names.log').read_text().splitlines())==set((p/'verified-final-names.log').read_text().splitlines())
print('248 interface reports match; 61 data examples pass')
