import DiophantineConsistency.WangTiles942PhysicalData
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.WangTiles942PhysicalData).isPrefixOf n then
      logInfo m!"{n}"
