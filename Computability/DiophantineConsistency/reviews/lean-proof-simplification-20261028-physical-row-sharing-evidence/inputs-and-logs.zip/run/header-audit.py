from pathlib import Path
import json,hashlib
p=Path('/tmp/physical-rows-sharing');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
for name,expected in [('header-records.json',3),('header-probe-records.json',3)]:
 rs=json.loads((p/name).read_text());assert len(rs)==expected
 for r in rs:
  cmd=r['command'];src=[Path(x) for x in cmd if x.endswith('.lean')];assert len(src)==1
  assert r['status']==0 and r['source_sha256']==r['source_after']==h(src[0]);assert r['lean_path'].split(':')[0]==str(p/'header-lib');assert r['time_sha256']==h(cmd[4]);assert r['log_sha256']==h(p/f"header-{r['tag']}.log")
  if 'object_sha256' in r:assert cmd[-2]=='-o' and h(cmd[-1])==r['object_sha256']
 print(name,len(rs),'source/output/log/time/path receipts verified')
assert (p/'header-interface.log').read_bytes()==(p/'verified-baseline-interface.log').read_bytes();assert set((p/'header-names.log').read_text().splitlines())==set((p/'verified-final-names.log').read_text().splitlines());assert not (p/'header-data-defeq.log').read_bytes()
a=(p/'baseline/DiophantineConsistency/MFWangTiles942PhysicalData.lean').read_text();b=(p/'final/DiophantineConsistency/MFWangTiles942PhysicalData.lean').read_text();begin=a.index('/-! Matrix-free clone');end=a.index(' -/',begin)+3;begin2=b.index('/-! Matrix-free physical');end2=b.index(' -/',begin2)+3;assert a[:begin]==b[:begin2] and a[end:]==b[end2:]
print('MF source delta restricted to the stale header; 248 declaration reports and 61 explicit rfl proofs pass')
