from pathlib import Path
import hashlib,json,re
p=Path('/tmp/physical-rows-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[];counts={}
for fn in ('verified-paired-records.json','probe-records.json','header-records.json','header-probe-records.json','foundation-retry-records.json'):
 rows=json.loads((p/fn).read_text());counts[fn]=len(rows)
 for r in rows:
  phase=r.get('phase');tag=r.get('tag');cmd=r['command'];src=[Path(x) for x in cmd if x.endswith('.lean')];assert len(src)==1,(fn,tag);label=f'{phase}-{tag}' if phase and tag else (phase or tag)
  if h(src[0])!=r['source_sha256'] or (r.get('source_after') and r['source_after']!=r['source_sha256']):issues.append([fn,label,'source'])
  if r['status']!=(1 if fn=='foundation-retry-records.json' else 0):issues.append([fn,label,'status'])
  if fn=='verified-paired-records.json':log=p/f'verified-{phase}-{tag}.log'
  elif fn=='probe-records.json':log=p/f'verified-{phase}-{tag}.log'
  elif fn=='header-records.json' or fn=='header-probe-records.json':log=p/f'header-{tag}.log'
  else:log=p/f'{phase}-foundation-retry.log'
  if h(log)!=r['log_sha256']:issues.append([fn,label,'log'])
  if r.get('time_sha256') and h(cmd[4])!=r['time_sha256']:issues.append([fn,label,'time'])
  if r.get('object_sha256') and (cmd[-2]!='-o' or h(cmd[-1])!=r['object_sha256']):issues.append([fn,label,'object'])
  if fn.startswith('header') and r['lean_path'].split(':')[0]!=str(p/'header-lib'):issues.append([fn,label,'path'])
for n in ('WangTiles942PhysicalData','MFWangTiles942PhysicalData'):
 if h(p/'baseline/DiophantineConsistency'/(n+'.lean'))!=h(Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean')):issues.append([n,'baseline/workspace drift'])
for ph in ('baseline','final'):
 if (p/f'verified-{ph}-interface.log').read_bytes()!=(p/'header-interface.log').read_bytes():issues.append([ph,'interface'])
for n,v in json.loads((p/'verified-pins.json').read_text()).items():
 f=Path(v['source'])
 if h(f)!=v['source_sha256']:issues.append([n,'source pin drift'])
 if 'object_sha256' in v:
  for folder in ('verified-baseline-lib','verified-final-lib'):
   f=p/folder/(n.replace('.','/')+'.olean')
   if h(f)!=v['object_sha256']:issues.append([n,folder,'object pin'])
  if n!='DiophantineConsistency.MFWangTiles942PhysicalData' and h(p/'header-lib'/(n.replace('.','/')+'.olean'))!=v['object_sha256']:issues.append([n,'header object pin'])
print('counts',counts,'issues',len(issues));print(json.dumps(issues[:30],indent=2));(p/'independent-audit.json').write_text(json.dumps({'counts':counts,'issues':issues},indent=2)+'\n')
