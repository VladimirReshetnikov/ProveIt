import DiophantineConsistency.WangTiles942PhysicalData
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  logInfo m!"DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_2: {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_2 true false)} {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_2 false false)} {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_2 true true)} {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_2 false true)}"
  logInfo m!"DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_3: {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_3 true false)} {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_3 false false)} {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_3 true true)} {t.isLemma (.decl `DiophantineConsistency.WangTiles942PhysicalData.rows_good._simp_3 false true)}"
