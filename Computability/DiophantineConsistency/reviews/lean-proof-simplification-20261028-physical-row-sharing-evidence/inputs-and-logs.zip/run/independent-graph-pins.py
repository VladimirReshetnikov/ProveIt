from pathlib import Path
import json,hashlib
p=Path('/tmp/physical-rows-sharing');g=json.loads((p/'independent-graph.json').read_text()); rec=json.loads((p/'verified-paired-records.json').read_text());hdr=json.loads((p/'header-records.json').read_text());paths={'baseline':next(r['lean_path'] for r in rec if r['phase']=='baseline' and r['tag']=='target').split(':'),'final':next(r['lean_path'] for r in rec if r['phase']=='final' and r['tag']=='target').split(':'),'header':hdr[1]['lean_path'].split(':')};old=json.loads(Path('/tmp/outer-seed-bound-sharing/assembly-busy-pins.json').read_text())['nodes'];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();pins={};issues=[]
for n,v in g['nodes'].items():
 if n in ('DiophantineConsistency.WangTiles942PhysicalData','DiophantineConsistency.MFWangTiles942PhysicalData'):continue
 row={'source':v['source'],'source_sha256':h(v['source']),'objects':{}}
 for ph,pathsph in paths.items():
  found=None
  for base in pathsph:
   base=Path(base);root=base/n.split('.')[0]
   if root.exists():
    f=base/(n.replace('.','/')+'.olean')
    if f.exists():found=f;break
    issues.append([n,ph,'namespace shadow missing']);break
  if found is None:issues.append([n,ph,'missing object']);continue
  row['objects'][ph]={'path':str(found.resolve()),'sha256':h(found)}
 if len({x['sha256'] for x in row['objects'].values()})>1:issues.append([n,'phase object difference'])
 if n in old:
  r=old[n]; row['prior_source_match']=row['source_sha256']==r['source_sha256'];row['prior_object_match']=row['objects']['baseline']['sha256']==r['object_sha256']
 pins[n]=row
(p/'independent-graph-pins.json').write_text(json.dumps({'pins':pins,'issues':issues},indent=2)+'\n');print('pinned non-target local modules',len(pins),'issues',issues);print('BusyBeaver prior object matches',sum(v.get('prior_object_match',False) for n,v in pins.items() if n.startswith('BusyBeaver.')))
