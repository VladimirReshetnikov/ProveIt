from pathlib import Path
import json,hashlib,re
r=Path('/tmp/window-rem-bound');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); rows={};prior=json.loads(Path('/tmp/mask-ins-simplify/independent-direct-provider-audit.json').read_text());extras={}
for f,n,phase,sk in [('/tmp/mask-ins-simplify/records.json','ArithmeticMaskConstants','final','before'),('/tmp/binom-odd-sharing/final-records.json','ArithmeticHalfBinomial2011','final','before'),('/tmp/positive-shift-sharing/source-clean/records.json','ArithmeticCurrentSentence2011','final','source_sha256_before')]:
 a=json.loads(Path(f).read_text());x=next(x for x in a if x.get('module',x.get('name'))==n and x.get('phase')==phase and x.get('status')==0);extras[n]=(x[sk],x['object_sha256'],f)
for ph in ('baseline','final'):
 for x in json.loads((r/f'{ph}-records.json').read_text()):
  n=x['module'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
  if ph=='baseline' or n!='ArithmeticWindowInterface':assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(p) and d['source_before']==d['source_after']==h(d['source']);m=d['module'].split('.')[-1]
   if m=='ArithmeticWindowInterface':assert d['resolved']==rows[(ph,m)]['object'] and d['object_before']==rows[(ph,m)]['object_sha256'];print('same phase target',ph,n)
   elif m in extras:assert (d['source_before'],d['object_before'])==extras[m][:2];print('prior exact pair',ph,m,extras[m][2])
   else:q=prior[d['module']];assert (d['source_before'],d['object_before'])==(q['source_sha256'],q['object_sha256']) and q['matching_prior_rows'];print('prior exact pair',ph,m,'independent-direct-provider-audit.json')
  rows[(ph,n)]=x;print('build',ph,n,x['timing'])
 for x in json.loads((r/f'{ph}-probes.json').read_text()):assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[(ph,'ArithmeticWindowInterface')]['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);print('probe',ph,x['name'])
assert rows['baseline','ArithmeticWindowZero']['object_sha256']==rows['final','ArithmeticWindowZero']['object_sha256'];print('client output byte-identical')
def parse(p):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',p.read_text(),re.M|re.S)}
a=parse(r/'baseline-interfaces.log');b=parse(r/'final-interfaces.log');assert a==b;print('target declarations/type/axioms identical',len(a))
for n in ('simp','instances'):a=(r/f'baseline-{n}.log').read_bytes();b=(r/f'final-{n}.log').read_bytes();assert a==b;print(n,'identical',len(a.splitlines()))
