from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/tmp/window-rem-bound');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={};prior=json.loads(Path('/tmp/mask-ins-simplify/independent-direct-provider-audit.json').read_text());extra={}
path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWindowInterface.lean'
for ref,phase in [('94638c37e5^','baseline'),('94638c37e5','final')]:
 data=subprocess.check_output(['git','show',ref+':'+path]);assert data==(R/'sources'/phase/'DiophantineConsistency/ArithmeticWindowInterface.lean').read_bytes()
assert Path(path).read_bytes()==(R/'sources/final/DiophantineConsistency/ArithmeticWindowInterface.lean').read_bytes()
print('parent, commit and workspace snapshots verified')
def historic(path):
 return R/'sources/baseline/DiophantineConsistency/ArithmeticWindowInterface.lean' if Path(path).name=='ArithmeticWindowInterface.lean' else Path(path)
for f,n,ph,sk in [('/tmp/mask-ins-simplify/records.json','ArithmeticMaskConstants','final','before'),('/tmp/binom-odd-sharing/final-records.json','ArithmeticHalfBinomial2011','final','before'),('/tmp/positive-shift-sharing/source-clean/records.json','ArithmeticCurrentSentence2011','final','source_sha256_before')]:
 x=next(x for x in json.loads(Path(f).read_text()) if x.get('module',x.get('name'))==n and x.get('phase')==ph and x.get('status')==0);extra[n]=(x[sk],x['object_sha256'])
for ph in ['baseline','final']:
 for x in json.loads((R/f'{ph}-records.json').read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(historic(x['workspace']))
  for k in ['object','log','time']:assert x[k+'_sha256']==h(x[k])
  if ph=='baseline' or x['module']!='ArithmeticWindowInterface':assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(p) and d['source_before']==d['source_after']==h(historic(d['source']));n=d['module'].split('.')[-1]
   if n=='ArithmeticWindowInterface': assert d['object_before']==rows[ph,n]['object_sha256'] and d['resolved']==rows[ph,n]['object']
   elif n in extra:assert extra[n]==(d['source_before'],d['object_before'])
   else:
    q=prior[d['module']];assert (q['source_sha256'],q['object_sha256'])==(d['source_before'],d['object_before']) and q['matching_prior_rows']
  rows[ph,x['module']]=x;print('build',ph,x['module'],x['timing'])
 for x in json.loads((R/f'{ph}-probes.json').read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticWindowInterface']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
assert rows['baseline','ArithmeticWindowZero']['object_sha256']==rows['final','ArithmeticWindowZero']['object_sha256'];print('client object matches')
def read(ph):
 s=(R/f'{ph}-interfaces.log').read_text();return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',s) if v.strip()}
a,b=read('baseline'),read('final');assert len(a)==43 and a==b;print('all named and generated declarations/type/axioms match',len(a))
for n in ['simp','instances']:
 a=(R/f'baseline-{n}.log').read_bytes();b=(R/f'final-{n}.log').read_bytes();assert a==b;print(n,len(a.splitlines()))
for n in ['ArithmeticHalfBinomial','ArithmeticBinomLegendre','ArithmeticPellRecurrence']:
 p=R/'objects-baseline/DiophantineConsistency'/(n+'.olean');print('cached boundary',n,'object',h(p),'source',h(Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean')),'resolved',p.resolve())
print('all checks passed')
