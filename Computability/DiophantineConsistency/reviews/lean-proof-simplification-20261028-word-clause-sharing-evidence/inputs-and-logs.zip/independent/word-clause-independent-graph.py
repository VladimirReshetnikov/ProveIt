from pathlib import Path
import re,json,hashlib,tomllib
p=Path('/tmp/word-clause-sharing');W=Path.cwd();saved=json.loads((p/'graph.json').read_text());roots=list(dict.fromkeys((W/x.get('srcDir','.')).resolve() for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']));h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[]
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(f):
 out=[]
 for line in strip(Path(f).read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out
G={};E=set()
def visit(n):
 if n in G or n in E:return
 if n=='DiophantineConsistency.CurrentWordClause2011':f=p/'final/DiophantineConsistency/CurrentWordClause2011.lean'
 else:
  loc=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
  if not loc:E.add(n);return
  if len(loc)!=1:issues.append(['ambiguous',n]);return
  f=loc[0]
 im=imports(f);G[n]=im
 for a in im:visit(a)
for n in ('CurrentWordClause2011','MFCurrentWordClause2011','CurrentWordClause2011Checks','CurrentWordTopBounds2011','CurrentWordTopBounds2011Checks'):visit('DiophantineConsistency.'+n)
if set(G)!=set(saved['nodes']):issues.append(['nodes',sorted(set(G)^set(saved['nodes']))])
if E!=set(saved['external']):issues.append(['external',sorted(E^set(saved['external']))])
for n,im in G.items():
 if n not in saved['nodes']:continue
 v=saved['nodes'][n]
 if sorted(im)!=sorted(v['imports']):issues.append(['edge',n,sorted(set(im)^set(v['imports']))])
 if h(v['source'])!=v['sha256']:issues.append(['source drift',n])
order=saved['order'];pos={x:i for i,x in enumerate(order)}
for n,v in saved['nodes'].items():
 for dep in v['imports']:
  if dep in pos and pos[dep]>=pos[n]:issues.append(['topological',n,dep])
result={'local':len(G),'external':len(E),'issues':issues};print(json.dumps(result,indent=2));(Path('/tmp/word-clause-independent-graph.json')).write_text(json.dumps(result,indent=2)+'\n')
if issues:raise SystemExit(1)
