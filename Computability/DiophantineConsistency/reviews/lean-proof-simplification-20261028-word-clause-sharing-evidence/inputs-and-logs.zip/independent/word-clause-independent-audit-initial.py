from pathlib import Path
import json,hashlib
p=Path('/tmp/word-clause-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for n in ('build-records.json','names-records.json','interface-records.json','compat-records.json'):
 for r in json.loads((p/n).read_text()):
  c=r['command'];src=[x for x in c if x.endswith('.lean')];assert len(src)==1
  assert r['status']==0 and h(src[0])==r['source_sha256']==r['source_after']
  assert h(c[4])==r['time_sha256'] and r['lean_path'].split(':')[0]==str(p/r['phase'])
  tag=r.get('name',{'names-records.json':'names','interface-records.json':'interface','compat-records.json':'compat'}.get(n));assert h(p/(r['phase']+'-'+tag+'.log'))==r['log_sha256']
  if 'object_sha256' in r:
   assert c[-2]=='-o' and h(c[-1])==r['object_sha256'] and Path(c[-1]).stat().st_size==r['object_bytes']
   assert r['direct_inputs']==r['direct_inputs_after']
   for d in r['direct_inputs']:assert h(d['path'])==d['sha256'],d['module']
 print(n,'all records and inputs match')
assert (p/'baseline-interface.log').read_bytes()==(p/'final-interface.log').read_bytes()
assert (p/'baseline-compat.log').read_bytes()==(p/'final-compat.log').read_bytes()
print('matching interface and compatibility logs')
