from pathlib import Path
import json,hashlib
p=Path('/tmp/word-clause-sharing');d=json.loads((p/'inventory.json').read_text()); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest(); assert not d['issues'];count={}
for x in d['local']:
 for ph,v in x['phase'].items():
  assert h(v['source'])==v['source_sha256'],(x['module'],ph,'source')
  assert h(v['object'])==v['object_sha256'],(x['module'],ph,'object')
  count[v['status']]=count.get(v['status'],0)+1
for x in d['external']:assert h(x['path'])==x['sha256'],x['module']
print('verified',len(d['local']),'local nodes both phases,',len(d['external']),'external object hashes; statuses',count)
