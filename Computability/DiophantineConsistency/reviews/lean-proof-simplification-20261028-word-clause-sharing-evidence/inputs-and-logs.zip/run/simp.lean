import DiophantineConsistency.CurrentWordClause2011
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n0 := `DiophantineConsistency.CurrentWordClause2011.clause_convolution._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordClause2011.clause_convolution._proof_1: {t.isLemma (.decl n0 true false)} {t.isLemma (.decl n0 false false)} {t.isLemma (.decl n0 true true)} {t.isLemma (.decl n0 false true)}"
  let n1 := `DiophantineConsistency.CurrentWordClause2011.normalized_word_strict._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordClause2011.normalized_word_strict._proof_1: {t.isLemma (.decl n1 true false)} {t.isLemma (.decl n1 false false)} {t.isLemma (.decl n1 true true)} {t.isLemma (.decl n1 false true)}"
  let n2 := `DiophantineConsistency.CurrentWordClause2011.normalized_word_strict._proof_2
  logInfo m!"DiophantineConsistency.CurrentWordClause2011.normalized_word_strict._proof_2: {t.isLemma (.decl n2 true false)} {t.isLemma (.decl n2 false false)} {t.isLemma (.decl n2 true true)} {t.isLemma (.decl n2 false true)}"
  let n3 := `DiophantineConsistency.CurrentWordClause2011.shifted_clause_zero._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordClause2011.shifted_clause_zero._proof_1: {t.isLemma (.decl n3 true false)} {t.isLemma (.decl n3 false false)} {t.isLemma (.decl n3 true true)} {t.isLemma (.decl n3 false true)}"
