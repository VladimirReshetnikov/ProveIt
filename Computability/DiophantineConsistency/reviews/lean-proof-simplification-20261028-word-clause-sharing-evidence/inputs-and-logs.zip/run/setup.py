from pathlib import Path
import shutil,re
p=Path('/tmp/word-clause-sharing');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=Path('/tmp/word-padding-sharing/post-copies-final')
for ph in ('baseline','final'):
 o=p/ph;o.mkdir(exist_ok=True)
 for d in base.iterdir():
  q=o/d.name
  if not q.exists():q.symlink_to(d.resolve(),target_is_directory=d.is_dir())
 target=o/'DiophantineConsistency';target.unlink(missing_ok=True);target.mkdir()
 for f in (base/'DiophantineConsistency').iterdir():
  if f.is_file(): (target/f.name).symlink_to(f.resolve())
 for n in ('CurrentWordClause2011','MFCurrentWordClause2011'):shutil.copyfile(root/(n+'.lean'),target/(n+'.lean'))
p1=p/'final/DiophantineConsistency/CurrentWordClause2011.lean';s=p1.read_text();s='import DiophantineConsistency.MFCurrentWordClause2011\n'+s
names={'base_aligned':'j','clause_convolution':'a dummy marker j','physical_count':'a dummy marker j','shifted_clause_zero':'a dummy marker s j','rotation_whole':'a dummy marker hd hm s k','rotation_clause_zero':'a dummy marker hd hm s j','low_carry_zero':'a dummy marker hd hm W k digits (facts_toMF _ _ _ _ hf) j e he','normalized_clause':'a dummy marker hd hm s k digits (facts_toMF _ _ _ _ hf) j','clause_mask_pass':'a dummy marker hd hm s k digits (facts_toMF _ _ _ _ hf) j','normalized_word_strict':'a dummy marker hd hm s k digits (facts_toMF _ _ _ _ hf)'}
for n,args in names.items():
 m=re.search(r'(?m)^theorem '+n+r'\b[\s\S]*? := by\n',s);assert m,n;after=m.end();t=re.search(r'(?m)^(?=(?:theorem |private |def |/-|omit |end ))',s[after:]);assert t,n;end=after+t.start();s=s[:after]+'  exact MF.CurrentWordClause2011.'+n+' '+args+'\n\n'+s[end:]
marker='/-- Every bounded normalization of the constructed word resets the complete\n'
bridge='''private theorem facts_toMF {n : ℕ} [NeZero n] (c : ZMod n → ℕ) (W : ℕ)\n    (k digits : ZMod n → ℕ) (hf : CurrentCarryConstruction2011.Facts c W k digits) :\n    MF.CurrentCarryConstruction2011.Facts c W k digits :=\n  ⟨hf.carry_bound, hf.digit_bound, hf.recurrence, hf.decomposition, hf.word_bound, hf.transport⟩\n\n'''
assert s.count(marker)==1;s=s.replace(marker,bridge+marker);p1.write_text(s)
p2=p/'final/DiophantineConsistency/MFCurrentWordClause2011.lean';s=p2.read_text();s=re.sub(r'/-! Matrix-free clone of `DiophantineConsistency.CurrentWordClause2011`:[\s\S]*?-/', '/-! Matrix-free clause proofs used by local normalization and by\n`DiophantineConsistency.CurrentWordClause2011`. -/', s,count=1);p2.write_text(s)
