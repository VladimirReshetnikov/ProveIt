import DiophantineConsistency.CurrentWordClause2011
import DiophantineConsistency.MFCurrentWordClause2011
open DiophantineConsistency
example {n : ℕ} [NeZero n] (c k digits : ZMod n → ℕ) (W : ℕ) :
    CurrentCarryConstruction2011.Facts c W k digits ↔ MF.CurrentCarryConstruction2011.Facts c W k digits := by
  constructor <;> intro h
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
example (s : ℕ) : CurrentWordClause2011.displacement s = MF.CurrentWordClause2011.displacement s := rfl
example (a : ZMod 0 → Fin 942) (dummy marker : ZMod 0 → ℕ)
    (hd : ∀ j, dummy j ≤ 1) (hm : ∀ j, marker j ≤ 1) (s : ℕ) (k : ZMod (0*2011)) :
    NativeCyclicRotation.binaryRotation 47 (CurrentWordClause2011.displacement s)
      (CurrentWordConstruction2011.word a dummy marker) k =
      CurrentWordConstruction2011.word a dummy marker (k-((2011*s : ℕ) : ZMod (0*2011))) :=
  CurrentWordClause2011.rotation_whole a dummy marker hd hm s k
