from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/tmp/word-clause-sharing');g=json.loads((p/'graph.json').read_text());inv=json.loads((p/'inventory.json').read_text());nodes=g['nodes'];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];seq=('MFCurrentWordClause2011','MFCurrentWordTopBounds2011','CurrentWordClause2011','CurrentWordClause2011Checks','CurrentWordTopBounds2011','CurrentWordTopBounds2011Checks');built={'DiophantineConsistency.'+n for n in seq};old=json.loads((p/'build-records.json').read_text());old={(x['phase'],x['name']):x for x in old}
for phase in ('baseline','final'):
 srcroot=p/phase;root=p/('pinned-'+phase);root.mkdir(exist_ok=True)
 for d in srcroot.iterdir():
  if d.name=='DiophantineConsistency':continue
  q=root/d.name
  if not q.exists():q.symlink_to(d.resolve(),target_is_directory=d.is_dir())
 dst=root/'DiophantineConsistency';dst.mkdir(exist_ok=True)
 for f in (srcroot/'DiophantineConsistency').iterdir():
  if f.is_file() and f.name.endswith(('.olean','.olean.private','.olean.server','.ir')):
   q=dst/f.name
   if not q.exists():q.symlink_to(f.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+base
 pins=[]
 for x in inv['local']:
  if x['module'] not in built:
   v=x['phase'][phase];pins.append((v['source'],v['source_sha256']));pins.append((v['object'],v['object_sha256']))
 for x in inv['external']:pins.append((x['path'],x['sha256']))
 def verify():
  for path,expected in pins:
   if h(path)!=expected:raise RuntimeError(('pin mismatch',phase,path))
 for n in seq:
  assert shutil.disk_usage('.').free>850*1024**2,'disk reserve';verify();mod='DiophantineConsistency.'+n
  if n in ('MFCurrentWordClause2011','CurrentWordClause2011'):src=srcroot/'DiophantineConsistency'/(n+'.lean');leanroot=srcroot
  else:src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');leanroot=Path('Computability/DiophantineConsistency/Lean')
  direct=[]
  for dep in nodes[mod]['imports']:
   if dep not in nodes:continue
   obj=root/(dep.replace('.','/')+'.olean')
   if not obj.exists():
    for path in env['LEAN_PATH'].split(':')[1:]:
     q=Path(path)/(dep.replace('.','/')+'.olean')
     if q.exists():obj=q;break
   assert obj.exists(),(mod,dep);direct.append({'module':dep,'path':str(obj.resolve()),'sha256':h(obj)})
  out=dst/(n+'.olean');out.unlink(missing_ok=True);log=p/(phase+'-pinned-'+n+'.log');tm=p/(phase+'-pinned-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(leanroot),str(src),'-o',str(out)];before=h(src)
  with log.open('wb') as f:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  verify();directafter=[h(x['path']) for x in direct];rec={'phase':phase,'name':n,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src.resolve()),'source_sha256':before,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'prior_object_sha256':old[(phase,n)]['object_sha256'],'log_sha256':h(log),'time_sha256':h(tm),'pins_count':len(pins),'pins_verified_before_after':True,'direct_inputs':direct,'direct_inputs_after':directafter,'elapsed':round(time.monotonic()-t,3)};records.append(rec);(p/'pinned-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,rc,flush=True)
  if rc or rec['source_sha256']!=rec['source_after'] or rec['object_sha256']!=rec['prior_object_sha256'] or any(x['sha256']!=y for x,y in zip(direct,directafter)):raise SystemExit(1)
