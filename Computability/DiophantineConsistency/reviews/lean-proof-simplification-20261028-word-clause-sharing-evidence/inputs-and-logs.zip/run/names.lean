import DiophantineConsistency.CurrentWordClause2011
#print equations DiophantineConsistency.CurrentWordClause2011.displacement
open Lean Elab Command
run_cmd do
 for (n, _) in (← getEnv).constants.toList do
  if (`DiophantineConsistency.CurrentWordClause2011).isPrefixOf n then logInfo m!"{n}"
