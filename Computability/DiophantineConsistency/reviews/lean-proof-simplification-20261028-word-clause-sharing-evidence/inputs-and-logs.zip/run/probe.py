from pathlib import Path
import os,subprocess,json,hashlib,time,sys
p=Path('/tmp/word-clause-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();tag=sys.argv[1];records=[]
for phase in ('baseline','final'):
 root=p/phase;src=p/(tag+'.lean');env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+base;log=p/(phase+'-'+tag+'.log');tm=p/(phase+'-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p),str(src)];before=h(src)
 with log.open('wb') as f:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 r={'phase':phase,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,3)};records.append(r);(p/(tag+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,rc,flush=True)
 if rc or before!=r['source_after']:raise SystemExit(1)
