from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/tmp/word-clause-sharing');g=json.loads((p/'graph.json').read_text());nodes=g['nodes'];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
sequence=('MFCurrentWordClause2011','MFCurrentWordTopBounds2011','CurrentWordClause2011','CurrentWordClause2011Checks','CurrentWordTopBounds2011','CurrentWordTopBounds2011Checks')
for phase in ('baseline','final'):
 root=p/phase;env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+base;paths=env['LEAN_PATH'].split(':')
 for n in sequence:
  assert shutil.disk_usage('.').free>850*1024**2,'disk reserve'
  module='DiophantineConsistency.'+n
  if n in ('MFCurrentWordClause2011','CurrentWordClause2011'):src=root/'DiophantineConsistency'/(n+'.lean');srcroot=root
  else:src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');srcroot=Path('Computability/DiophantineConsistency/Lean')
  direct=[]
  for dep in nodes[module]['imports']:
   if dep not in nodes:continue
   obj=root/(dep.replace('.','/')+'.olean')
   if not obj.exists():
    for b in paths[1:]:
     q=Path(b)/(dep.replace('.','/')+'.olean')
     if q.exists():obj=q;break
   assert obj.exists(),(module,dep)
   direct.append({'module':dep,'path':str(obj.resolve()),'sha256':h(obj)})
  out=root/'DiophantineConsistency'/(n+'.olean');out.unlink(missing_ok=True)
  log=p/(phase+'-'+n+'.log');tm=p/(phase+'-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(out)];before=h(src)
  with log.open('wb') as f:t=time.monotonic();status=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  rec={'phase':phase,'name':n,'status':status,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src.resolve()),'source_sha256':before,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'object_bytes':out.stat().st_size if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'direct_inputs':direct,'direct_inputs_after':[h(x['path']) for x in direct],'elapsed':round(time.monotonic()-t,3)}
  records.append(rec);(p/'build-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,status,flush=True)
  if status or rec['source_sha256']!=rec['source_after'] or any(x['sha256']!=y for x,y in zip(direct,rec['direct_inputs_after'])):raise SystemExit(1)
