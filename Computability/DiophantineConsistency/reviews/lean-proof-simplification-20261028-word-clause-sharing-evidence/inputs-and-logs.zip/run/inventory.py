from pathlib import Path
import json,hashlib
p=Path('/tmp/word-clause-sharing');graph=json.loads((p/'graph.json').read_text()); prior=json.loads(Path('/tmp/word-padding-sharing/post-copies-inventory.json').read_text());prev={x['module']:x for x in prior['local']};ext={x['module']:x for x in prior['external']};h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rebuilt={'DiophantineConsistency.'+n for n in ('MFCurrentWordClause2011','MFCurrentWordTopBounds2011','CurrentWordClause2011','CurrentWordClause2011Checks','CurrentWordTopBounds2011','CurrentWordTopBounds2011Checks')};local=[];issues=[]
for n,v in graph['nodes'].items():
 r={'module':n,'imports':v['imports'],'phase':{}}
 for ph in ('baseline','final'):
  src=(p/ph/'DiophantineConsistency'/(n.split('.')[-1]+'.lean')) if n in ('DiophantineConsistency.CurrentWordClause2011','DiophantineConsistency.MFCurrentWordClause2011') else Path(v['source']);obj=p/ph/(n.replace('.','/')+'.olean')
  if not obj.exists():
   prevpath=prev.get(n,{}).get('phase',{}).get('final',{}).get('object');obj=Path(prevpath) if prevpath else obj
  if not src.exists() or not obj.exists():issues.append([n,ph,'missing']);continue
  z={'source':str(src.resolve()),'source_sha256':h(src),'object':str(obj.resolve()),'object_sha256':h(obj),'status':'rebuilt' if n in rebuilt else 'matched previous selected object'};r['phase'][ph]=z
  if n not in rebuilt:
   if n not in prev:issues.append([n,ph,'no previous receipt']);continue
   a=prev[n]['phase']['final'];
   if z['source_sha256']!=a['source_sha256'] or z['object_sha256']!=a['object_sha256']:issues.append([n,ph,'previous mismatch'])
 if n not in rebuilt and len(r['phase'])==2 and r['phase']['baseline']['object_sha256']!=r['phase']['final']['object_sha256']:issues.append([n,'phase mismatch'])
 local.append(r)
external=[]
for n in graph['external']:
 if n not in ext:issues.append([n,'external missing']);continue
 r=ext[n];a=r['phase']['final'];obj=Path(a['object'])
 if not obj.exists() or h(obj)!=a['object_sha256']:issues.append([n,'external mismatch']);continue
 external.append({'module':n,'path':str(obj.resolve()),'sha256':h(obj)})
(p/'inventory.json').write_text(json.dumps({'local':local,'external':external,'issues':issues},indent=2)+'\n');print('local',len(local),'external',len(external),'issues',issues)
assert not issues
