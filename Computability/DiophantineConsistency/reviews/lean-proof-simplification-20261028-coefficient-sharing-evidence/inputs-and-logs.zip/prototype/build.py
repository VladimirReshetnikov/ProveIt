from pathlib import Path
import json,subprocess,hashlib,os,time,re,sys
R=Path('/tmp/coeff-bound-sharing'); phase=sys.argv[1]; mods=sys.argv[2:]; srcroot=R/phase; out=R/('objects-'+phase); (out/'DiophantineConsistency').mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(out)+':/dev/shm/shared-box-prototype/coherent-common:'+base;records=[]
for mod in mods:
 src=srcroot/'DiophantineConsistency'/f'{mod}.lean';obj=out/'DiophantineConsistency'/f'{mod}.olean';obj.unlink(missing_ok=True);log=R/f'{phase}-{mod}.log';tm=R/f'{phase}-{mod}.time';deps=[]
 for n in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=n.replace('.','/')+'.olean';d=next((Path(q,rel) for q in env['LEAN_PATH'].split(':') if Path(q,rel).is_file()),None)
  if not d:raise RuntimeError('missing import '+n)
  deps.append({'module':n,'path':str(d),'resolved':str(d.resolve()),'before':sha(d)})
 before=sha(src);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(obj)];t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for x in deps:x['after']=sha(x['path'])
 rec={'phase':phase,'module':mod,'status':r.returncode,'source':str(src),'before':before,'after':sha(src),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(rec);(R/f'{phase}-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,mod,r.returncode,rec['time'].strip(),flush=True)
 if r.returncode or before!=rec['after'] or any(x['before']!=x['after'] for x in deps):raise SystemExit(1)
