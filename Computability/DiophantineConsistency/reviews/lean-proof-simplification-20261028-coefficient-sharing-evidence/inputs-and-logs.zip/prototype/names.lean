import DiophantineConsistency.SelectiveCoefficientBounds
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.SelectiveCoefficientBounds).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.SelectiveCoefficientBounds" then
   logInfo m!"DECL {n}"
