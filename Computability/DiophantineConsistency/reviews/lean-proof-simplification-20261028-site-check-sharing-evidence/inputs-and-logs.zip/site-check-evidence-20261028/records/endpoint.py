from pathlib import Path
import os,subprocess,hashlib,json
r=Path('/tmp/site-check-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(phase,name):
 src=r/f'{name}.lean';log=r/f'{phase}-{name}.log';tm=r/f'{phase}-{name}.time';env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+base;before=sha(src);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'phase':phase,'name':name,'source':str(src),'before':before,'after':sha(src),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':p.returncode,'time':tm.read_text(),'log_sha256':sha(log)};records.append(row);(r/'endpoint-records.json').write_text(json.dumps(records,indent=2));print(phase,name,p.returncode,flush=True)
 if p.returncode or before!=row['after']:raise SystemExit(1)
for phase in ['baseline','final']:run(phase,'endpoint')
