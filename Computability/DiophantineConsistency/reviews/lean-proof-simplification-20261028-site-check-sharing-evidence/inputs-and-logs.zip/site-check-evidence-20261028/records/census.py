from pathlib import Path
import os,subprocess,hashlib,json
r=Path('/tmp/site-check-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(phase,name):
 src=r/f'{name}.lean';log=r/f'{phase}-{name}.log';tm=r/f'{phase}-{name}.time';env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+base;before=sha(src);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'phase':phase,'name':name,'source':str(src),'before':before,'after':sha(src),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':p.returncode,'time':tm.read_text(),'log_sha256':sha(log)};records.append(row);(r/'census-records.json').write_text(json.dumps(records,indent=2));print(phase,name,p.returncode,flush=True)
 if p.returncode or before!=row['after']:raise SystemExit(1)
(r/'names.lean').write_text('''import DiophantineConsistency.ArithmeticRuntimeBoundTapeRun
#print equations DiophantineConsistency.ArithmeticSite215.startValue
#print equations DiophantineConsistency.ArithmeticSite215.targetValue
#print equations DiophantineConsistency.ArithmeticRuntimeBoundTapeControl.siteB
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticSite215).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticRuntimeBoundTapeControl).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticSite215).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticRuntimeBoundTapeControl).isPrefixOf n then
      logInfo m!"DECL {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
       t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
''')
for phase in ['baseline','final']:run(phase,'names')
def sets(p,prefix):return {s.split(prefix,1)[1].strip() for s in p.read_text().splitlines() if prefix in s}
a=sets(r/'baseline-names.log','DECL ');b=sets(r/'final-names.log','DECL ');sa=sets(r/'baseline-names.log','SIMP ');sb=sets(r/'final-names.log','SIMP ');print('names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),'global simp',len(sa),len(sb),'equal',sa==sb,flush=True)
common=sorted(n for n in a&b if not n.startswith('_private.'))
(r/'interfaces.lean').write_text('import DiophantineConsistency.ArithmeticRuntimeBoundTapeRun\nset_option pp.universes true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in common))
for phase in ['baseline','final']:run(phase,'interfaces')
print('public/generated',len(common),'reports equal',(r/'baseline-interfaces.log').read_bytes()==(r/'final-interfaces.log').read_bytes(),flush=True)
(r/'private.lean').write_text('''import DiophantineConsistency.ArithmeticRuntimeBoundTapeRun
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`_private.DiophantineConsistency.ArithmeticSite215).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticRuntimeBoundTapeControl).isPrefixOf n then
      let typ ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let axioms ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {typ} AXIOMS {axioms}"
''')
for phase in ['baseline','final']:run(phase,'private')
