import DiophantineConsistency.ArithmeticRuntimeBoundTapeRun
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`_private.DiophantineConsistency.ArithmeticSite215).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticRuntimeBoundTapeControl).isPrefixOf n then
      let typ ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let axioms ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {typ} AXIOMS {axioms}"
