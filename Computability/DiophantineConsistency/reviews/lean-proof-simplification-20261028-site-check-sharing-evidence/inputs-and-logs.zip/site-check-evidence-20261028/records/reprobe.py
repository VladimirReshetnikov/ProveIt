from pathlib import Path
import os,re,subprocess,json,hashlib
r=Path('/tmp/site-check-sharing');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+lp;roots=[Path(x) for x in env['LEAN_PATH'].split(':')]
 for n in ['names','interfaces','private','endpoint']:
  src=r/f'{n}.lean';before=sha(src);inputs={}
  for d in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
   obj=next((x/(d.replace('.','/')+'.olean') for x in roots if (x/(d.replace('.','/')+'.olean')).is_file()),None)
   if obj is None:raise Exception('missing '+d)
   inputs[d]={'path':str(obj.resolve()),'before':sha(obj)}
  log=r/f'{phase}-reprobe-{n}.log';tm=r/f'{phase}-reprobe-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for i in inputs.values():i['after']=sha(Path(i['path']))
  row={'phase':phase,'probe':n,'source':str(src),'before':before,'after':sha(src),'inputs':inputs,'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log)};rec.append(row);(r/'reprobe-records.json').write_text(json.dumps(rec,indent=2));print(phase,n,q.returncode,flush=True)
  if q.returncode or before!=row['after'] or any(i['before']!=i['after'] for i in inputs.values()):raise SystemExit(1)
