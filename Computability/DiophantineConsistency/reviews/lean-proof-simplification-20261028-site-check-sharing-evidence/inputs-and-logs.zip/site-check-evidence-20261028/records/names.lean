import DiophantineConsistency.ArithmeticRuntimeBoundTapeRun
#print equations DiophantineConsistency.ArithmeticSite215.startValue
#print equations DiophantineConsistency.ArithmeticSite215.targetValue
#print equations DiophantineConsistency.ArithmeticRuntimeBoundTapeControl.siteB
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticSite215).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticRuntimeBoundTapeControl).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticSite215).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticRuntimeBoundTapeControl).isPrefixOf n then
      logInfo m!"DECL {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
       t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
