import Lean.Elab.Command
import DiophantineConsistency.ObjectCodeBound
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ObjectCodeBound).isPrefixOf n then
      logInfo m!"{n}"
