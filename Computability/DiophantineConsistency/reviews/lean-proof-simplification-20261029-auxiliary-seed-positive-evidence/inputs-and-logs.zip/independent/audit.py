from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/auxiliary-seed-positive');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
N='ArithmeticPellAuxiliarySeed';b=(R/'baseline/DiophantineConsistency'/f'{N}.lean').read_text();f=(R/'final/DiophantineConsistency'/f'{N}.lean').read_text();rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+N+'.lean';assert subprocess.check_output(['git','show','0e833fe200^:'+rel]).decode()==b and subprocess.check_output(['git','show','0e833fe200:'+rel]).decode()==f and (W/(N+'.lean')).read_text()==f;print('PASS exact commit/parent target snapshots and final workspace')
changes=[('''    by_contra h
    have hz : o=0 := le_antisymm (le_of_not_gt h) (by simp)
    have hzero : u+c=0 := by simpa [hz] using ho
    exact (ne_of_gt (add_pos hu hc)) hzero''','''    apply pos_of_mul_pos_right (a := f*f) _ (by simp)
    rw [←ho]
    exact add_pos hu hc'''),('''    by_contra h
    have hz : T=0 := le_antisymm (le_of_not_gt h) (by simp)
    have hzero : o+R=0 := by simpa [hz] using hT.symm
    exact (ne_of_gt (lt_of_lt_of_le ho0 (by simp))) hzero''','''    apply pos_of_mul_pos_right (a := c) _ (by simp)
    rw [hT]
    exact lt_of_lt_of_le ho0 (by simp)'''),('''    by_contra h
    have hz : u=0 := le_antisymm (le_of_not_gt h) (by simp)
    have hzero : xcoord R (I-2)=0 := by simpa [hz] using hux
    have hxpos : 0<xcoord R (I-2) := lt_of_lt_of_le (by simp : (0:V)<1) (one_le_x R (I-2))
    exact (ne_of_gt hxpos) hzero''','''    apply pos_of_mul_pos_right (a := I) _ (by simp)
    rw [←hux]
    exact lt_of_lt_of_le (by simp : (0:V)<1) (one_le_x R (I-2))''')]
for a,z in changes:assert b.count(a)==1;b=b.replace(a,z)
assert b==f
print('PASS exact three proof substitutions; statement, guards, imports unchanged')
paths={'ArithmeticTilingWord':'/tmp/tiling-band-dispatch/final-records.json','ArithmeticPackingCells':'/tmp/packing-rotation-simplify/final-records.json','ArithmeticController':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','ArithmeticConstructionUnit':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','ArithmeticConstructionVariation':'/tmp/packing-rotation-simplify/final-records.json','ArithmeticRankForcing2011':'/tmp/four-positive-wrappers/refreshed-final-records.json','ArithmeticOuterSeed':'/tmp/four-positive-wrappers/binom-final-records.json','ArithmeticPellSquaredSeed':'/tmp/four-positive-wrappers/upstream-records.json','ArithmeticPellHalfIndex':'/tmp/four-positive-wrappers/upstream-records.json'};providers={}
for n,p in paths.items():
 xs=[x for x in read(p) if (x.get('module') or x.get('name','')).split('.')[-1]==n and x.get('status')==0]
 for x in xs:
  a=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');z=x.get('after') or x.get('source_after') or x.get('source_sha256_after') or x.get('source_sha256')
  if a==z==h(W/(n+'.lean')):providers[n]=x['object_sha256'];break
 assert n in providers,(n,p)
 print('PASS source/object producer',n,providers[n])
mods=['ArithmeticPellAuxiliarySeed','ArithmeticPellAuxiliarySeedChecks','ArithmeticConstructionBoundPell','ArithmeticConstructionAssembly'];edges=sorted(p.stem for p in W.glob('*.lean') if re.search(r'^import DiophantineConsistency.ArithmeticPellAuxiliarySeed$',p.read_text(),re.M));assert edges==sorted(mods[1:]);print('PASS module-directory direct clients',edges)
for ph in ('baseline','final'):
 rows=read(R/(ph+'-records.json'));assert [x['module'] for x in rows]==mods;this={x['module']:x for x in rows}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!=N:assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p);n=d['module'].split('.')[-1];assert d['before']==(this[n]['object_sha256'] if n in this else providers[n])
  print('PASS',ph,x['module'],x['time'].strip())
for mod in mods[1:]:
 x=next(x for x in read(R/'baseline-records.json') if x['module']==mod);y=next(x for x in read(R/'final-records.json') if x['module']==mod);assert x['object_sha256']==y['object_sha256']
print('PASS all three paired client object hashes identical')
for probe in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=read(R/f'probe-{probe}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log'])
 a=(R/f'baseline-{probe}.log').read_text();b=(R/f'final-{probe}.log').read_text()
 if probe=='interfaces':
  def blocks(s):return {x.split(' TYPE ',1)[0]:x for x in re.split(r'(?m)^DECL ',s) if x}
  assert blocks(a)==blocks(b);print('PASS interfaces',len(blocks(a)))
 else:assert set(a.splitlines())==set(b.splitlines());print('PASS',probe,len(set(a.splitlines())))
print('PASS target census; cached transitive closure not rebuilt')
