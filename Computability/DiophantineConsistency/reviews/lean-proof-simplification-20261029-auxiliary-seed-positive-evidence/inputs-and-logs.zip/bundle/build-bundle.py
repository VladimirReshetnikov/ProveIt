from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs');R=Path('/tmp/auxiliary-seed-positive');D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-auxiliary-seed-positive-evidence';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();items={}
def add(n,p):assert n not in items;items[n]=Path(p).read_bytes()
def git(p,rev):return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=ROOT)
rev='0e833fe200805788d1e3ab6af77bc67fad875abf';parent='025320b05898fc759af8367f6401e31bea180a8d';mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for ph,ref in [('baseline',parent),('final',rev)]:
 key=f'commit/{ph}.lean';items[key]=git(mod+'ArithmeticPellAuxiliarySeed.lean',ref);assert items[key]==(R/ph/'DiophantineConsistency/ArithmeticPellAuxiliarySeed.lean').read_bytes()
items['provider-sources/signed-pairs-pre-f37.lean']=git(mod+'ArithmeticSignedPairs.lean','f37a2aad85^');items['provider-sources/signed-pairs-current.lean']=git(mod+'ArithmeticSignedPairs.lean',rev)
assert sha(items['provider-sources/signed-pairs-pre-f37.lean'])=='802f596f97526763820fb8bb4cd0f6619b2544eae7039577bc9f37bcb6d435a2'
for n in ['ArithmeticPellAuxiliarySeedChecks','ArithmeticConstructionBoundPell','ArithmeticConstructionAssembly','ArithmeticTilingWord','ArithmeticPackingCells','ArithmeticController','ArithmeticConstructionUnit','ArithmeticConstructionVariation','ArithmeticRankForcing2011','ArithmeticOuterSeed','ArithmeticPellSquaredSeed','ArithmeticPellHalfIndex']:
 items[f'provider-sources/{n}.lean']=git(mod+n+'.lean',rev)
for f in sorted(R.rglob('*')):
 parts=f.relative_to(R).parts
 if f.is_file() and f.suffix not in ('.olean','.ilean','.c') and not any(x=='common' or x.startswith('objects-') for x in parts):add('prototype/'+f.relative_to(R).as_posix(),f)
for n,p in {'prior/tiling-band-final.json':'/tmp/tiling-band-dispatch/final-records.json','prior/packing-rotation-final.json':'/tmp/packing-rotation-simplify/final-records.json','prior/outer-seed-assembly.json':'/tmp/outer-seed-bound-sharing/assembly-builds2.json','prior/four-wrapper-refreshed-final.json':'/tmp/four-positive-wrappers/refreshed-final-records.json','prior/four-wrapper-binom-final.json':'/tmp/four-positive-wrappers/binom-final-records.json','prior/four-wrapper-upstream.json':'/tmp/four-positive-wrappers/upstream-records.json','prior/signed-pairs-baseline.json':'/tmp/signed-pairs-factors/baseline-records.json','independent/review.txt':'/tmp/auxiliary-seed-independent-review-b.txt','independent/audit.py':'/tmp/auxiliary-seed-independent-audit-b.py','independent/audit.log':'/tmp/auxiliary-seed-independent-audit-b.log','bundle/build-bundle.py':'/tmp/build-auxiliary-seed-positive-bundle.py'}.items():add(n,p)
zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):
  i=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Simplify three AuxiliarySeed positive-factor proofs',
'validation':'Paired target and three tracked direct module clients pass, with phase-specific BoundPell input for Assembly. All client object pairs match. Source-current direct producer pairs are mapped to earlier receipts. Target probes match five declarations/type/axiom reports and global default simp/instance entries.',
'limitations':['The Assembly search path sampled after builds resolved SignedPairs to old object 5b043450… from pre-f37a2aad85 source 802f596f…. The sample is not a contemporaneous pin proving the transitive bytes loaded. Both old and current source snapshots and the prior baseline producer receipt are retained.', 'Wider project, Foundation and Mathlib transitive dependencies remain cached; matching direct providers do not establish a full current-source closure.', 'Target census and equal client objects do not prove every persistent environment extension or behavior of untested downstream clients. One paired shared-load timing sample is not a benchmark.', 'The standalone positivity probe lacks before/after input pins; paired builds provide validation. Author artifacts are historical and the included independent review/audit verify commit and parent.', 'Compiled objects and cached overlay contents are omitted; receipts record hashes and paths and independent byte checks need external objects.'],
'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(items)
 for n,b in items.items():assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes();print(n,sha(b),len(b))
