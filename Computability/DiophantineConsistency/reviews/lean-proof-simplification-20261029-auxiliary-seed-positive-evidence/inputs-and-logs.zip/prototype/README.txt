Auxiliary Pell seed positive witnesses: isolated proof simplification

Baseline ArithmeticPellAuxiliarySeed SHA-256 664281fe7ad7a67f97bd1438968aaa07aa0d0bcb03585f426319bf6214718186;
final SHA-256 f3769f93fe14b8ad50310050e8dbf9b7fa4347adda34af63eeee1abe470fd2c2.
The three positive-factor arguments for o, T and u use pos_of_mul_pos_right
on the same previously established product identities and nonnegative factors,
replacing the zero-contradiction proofs. The existing witnesses, all guards,
statements, definitions, imports and data remain unchanged. Thirteen lines are
replaced with nine. git blame attributes the changed proofs to 4c935808518,
whose commit message has no Co-Authored-By trailer; no Claude attribution is
claimed for these lines.

baseline/final-records.json record paired target and three direct source clients
(PellAuxiliarySeedChecks, ConstructionBoundPell, ConstructionAssembly), with
current source snapshots, first direct-object inputs before/after, logs, timings
and output objects. BoundPell is rebuilt in each phase before Assembly, which
pins both that phase's AuxiliarySeed and BoundPell objects. The target's
SquaredSeed and HalfIndex inputs match current-source producer rows in
/tmp/four-positive-wrappers/upstream-records.json. Assembly's other direct
providers match current-source input pairs in its earlier
/tmp/four-positive-wrappers/binom-final-records.json, and OuterSeed also has a
current-source producer there. Direct provider source hashes were matched to
prior receipts, rather than captured at the time of these builds. audit.py/.log
verify these source/object matches and selected phase input resolution.

Both phases and all three clients pass; all client object bytes match. Target
probes match all five namespace declaration/type/axiom reports and global
28,977 default simp/13,170 instance entries. These probes do not establish
proof-body identity, equality of every environment extension or behavior of
untested downstream clients. Single shared-load baseline/final user CPU samples:
target 39.27/38.84 seconds, Checks 2.18/2.23, BoundPell 6.25/6.29, Assembly
18.73/19.21. They are not general benchmarks. Neither phase produced target or
client warnings. The final target was built before the paired baseline and is
retained separately in final-target-records.json; final-records.json combines
that stable target receipt and the later final-client-records.json.

The endpoint overlay incorporates the adopted Pow and PellCongruences changes
but a post-build search-path sample in both phases resolves SignedPairs to the
older object 5b043450cd1f2924fcd0a51afe60fbffd1e39a1bcae221910fe8077af0c521ac.
Its successful earlier producer receipt in /tmp/signed-pairs-factors/baseline-
records.json used source 802f596f97526763820fb8bb4cd0f6619b2544eae7039577bc9f37bcb6d435a2,
matching f37a2aad85's parent, not the current adopted proof source. That sample
was taken after the present builds; it does not pin which transitive bytes were
loaded. Other project/Foundation/Mathlib dependencies are cached too: no full
current-source transitive closure was rebuilt. The standalone product-positivity
probe lacks before/after input pins, and the paired target/client builds are the
validation evidence.
