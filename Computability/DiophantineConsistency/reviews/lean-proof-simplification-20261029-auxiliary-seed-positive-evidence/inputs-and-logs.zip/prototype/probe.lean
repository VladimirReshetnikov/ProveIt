import DiophantineConsistency.ArithmeticPellAuxiliarySeed
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (a b : V) (h : 0 < a*b) : 0 < b := by
  exact pos_of_mul_pos_right h (by simp)
