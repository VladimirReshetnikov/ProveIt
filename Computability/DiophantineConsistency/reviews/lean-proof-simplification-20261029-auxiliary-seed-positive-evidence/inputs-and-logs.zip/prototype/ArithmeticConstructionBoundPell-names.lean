import DiophantineConsistency.ArithmeticConstructionBoundPell
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticConstructionBoundPell).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticConstructionBoundPell" then
   logInfo m!"DECL {n}"
