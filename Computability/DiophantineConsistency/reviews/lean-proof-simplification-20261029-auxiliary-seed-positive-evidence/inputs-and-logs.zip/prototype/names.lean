import DiophantineConsistency.ArithmeticPellAuxiliarySeed
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellAuxiliarySeed).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellAuxiliarySeed" then
   logInfo m!"DECL {n}"
