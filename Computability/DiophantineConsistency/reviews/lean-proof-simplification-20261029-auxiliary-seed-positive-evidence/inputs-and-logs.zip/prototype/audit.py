from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/auxiliary-seed-positive');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
up=load('/tmp/four-positive-wrappers/upstream-records.json');ending=load('/tmp/four-positive-wrappers/binom-final-records.json');oldasm=next(x for x in ending if x['module']=='ArithmeticConstructionAssembly');records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
providers={}
for n in ('ArithmeticPellSquaredSeed','ArithmeticPellHalfIndex'):
 x=next(x for x in up if x['module']==n);assert x['status']==0 and x['before']==x['after']==h(W/f'{n}.lean') and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256']
x=next(x for x in ending if x['module']=='ArithmeticOuterSeed');assert x['status']==0 and x['before']==x['after']==h(W/'ArithmeticOuterSeed.lean') and x['object_sha256']==h(x['object']);providers['ArithmeticOuterSeed']=x['object_sha256']
for d in oldasm['direct_inputs']:
 n=d['module'].split('.')[-1]
 if n in ('ArithmeticPellAuxiliarySeed','ArithmeticConstructionBoundPell'):continue
 assert d['source_before']==d['source_after']==h(W/f'{n}.lean') and d['before']==d['after'];providers[n]=d['before']
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticPellAuxiliarySeed','ArithmeticPellAuxiliarySeedChecks','ArithmeticConstructionBoundPell','ArithmeticConstructionAssembly']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if ph=='baseline' or x['module']!='ArithmeticPellAuxiliarySeed':assert x['before']==h(W/f"{x['module']}.lean")
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticPellAuxiliarySeed':assert d['before']==rr[0]['object_sha256']
   elif n=='ArithmeticConstructionBoundPell':assert d['before']==rr[2]['object_sha256']
   else:assert d['before']==providers[n]
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
for x,y in zip(records['baseline'][1:],records['final'][1:]):assert x['object_sha256']==y['object_sha256']
old=next(x for x in load('/tmp/signed-pairs-factors/baseline-records.json') if x['module']=='ArithmeticSignedPairs');blob=subprocess.check_output(['git','show','f37a2aad85^:Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticSignedPairs.lean']);assert old['status']==0 and old['before']==old['after']==hashlib.sha256(blob).hexdigest()
for ph in ('baseline','final'):
 x=records[ph][-1];rel='DiophantineConsistency/ArithmeticSignedPairs.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert h(p)==old['object_sha256']
print('PASS paired target/three clients, direct provider receipt matches, target census, historical SignedPairs path sample')
