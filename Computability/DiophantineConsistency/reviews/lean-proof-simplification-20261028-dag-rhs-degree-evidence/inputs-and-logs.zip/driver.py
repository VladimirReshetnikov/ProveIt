import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/dag-rhs-degree-validation');phase,task=sys.argv[1:]
env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
lean='Computability/DiophantineConsistency/Lean';src=Path(lean)/'DiophantineConsistency'
sets={'pre':['QuarticCost','CompilerSupport'],'targets':['DAGQuartic','NaturalDAGQuartic']}
if task in sets:jobs=[(n,str(src/(n+'.lean')),True) for n in sets[task]]
else:jobs=[('NaturalRegisterProgram',str(src/'NaturalRegisterProgram.lean'),False),('DAGQuarticCheck',lean+'/checks/DAGQuartic.lean',False),('NaturalDAGQuarticCheck',lean+'/checks/NaturalDAGQuartic.lean',False),('axioms',str(root/'axioms.lean'),False)]
records=[]
for tag,path,obj in jobs:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',lean,path]
 if obj:cmd+=['-o',str(root/phase/'DiophantineConsistency'/(tag+'.olean'))]
 t=time.monotonic();p=subprocess.run(cmd,capture_output=True,env=env);dt=time.monotonic()-t;log=root/(phase+'-'+tag+'.log');log.write_bytes(p.stdout+p.stderr)
 rec={'tag':tag,'cmd':cmd,'status':p.returncode,'seconds':dt,'source_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and p.returncode==0:
  q=root/phase/'DiophantineConsistency'/(tag+'.olean');rec.update(object_sha256=hashlib.sha256(q.read_bytes()).hexdigest(),object_bytes=q.stat().st_size)
 records.append(rec);(root/(phase+'-'+task+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,p.returncode,round(dt,2),flush=True)
 if p.returncode:sys.exit(p.returncode)
