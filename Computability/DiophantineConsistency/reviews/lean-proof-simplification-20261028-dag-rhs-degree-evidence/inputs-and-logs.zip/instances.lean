import DiophantineConsistency.NaturalDAGQuartic
open DiophantineConsistency.ArithmeticDAG
open DiophantineConsistency.NaturalDAGQuartic
variable {inputs fixed : ℕ}
def checkedNodeInstance (p : Fin fixed → ℤ) (n : Node inputs fixed) : Decidable (NodeAllowed p n) := inferInstance
def checkedListInstance (nodes : List (Node inputs fixed)) (p : Fin fixed → ℤ) : Decidable (Allowed nodes p) := inferInstance
#print axioms checkedNodeInstance
#print axioms checkedListInstance
