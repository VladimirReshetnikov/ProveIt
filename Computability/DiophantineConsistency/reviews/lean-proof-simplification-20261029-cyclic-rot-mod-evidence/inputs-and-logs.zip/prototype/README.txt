Cyclic word rotation congruence: isolated proof simplification

Baseline ArithmeticCyclicWord source SHA-256 77a152f2a1811dcb22400890dda84c14e437e6a57d819543e58032c7407dc2d8;
final SHA-256 890bb35639daad00a18c22c38679fb9bceb3e3bd84c2090e9a785f19e32e1926.
In rot_mod, use div_add_mod directly and factor the same modulus-plus-one term,
then ring, removing an intermediate commuted division equality. The diff adds
six and deletes nine lines; all declarations, guards, data and imports remain
unchanged. The tested snapshots match 5c94a5dd2d and its parent.
Original source commit 5fcd5632b3b753237437f22904b899653f69916b
contains Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>.

baseline/final-records.json record source and direct-input object hashes,
commands, logs, timings and outputs of the target and all three direct source
clients (WindowCarry, PackingBlocks, CellTransfer). WindowDigits, StandardCasts,
ModularCancellation and CellLabels direct providers match successful current-
source producer pairs in /tmp/window-digit-replace/final-records.json,
/tmp/binary-half-direct/final-supplement-records.json,
/tmp/shared-modular-cancel/records.json and /tmp/support-cast/refresh-records.json,
respectively. Mathlib input is object-pinned but not rebuilt. Source match for
those direct providers comes from prior receipts, not contemporaneous source
samples in the present builds. audit.py/.log verify these links, paired builds,
first path resolution and probes. This is not a full transitive closure rebuild:
other project, Foundation and Mathlib dependencies remain cached.

Target baseline/final user CPU 6.30/6.25 seconds, WindowCarry 5.29/5.66,
PackingBlocks 45.72/47.48, CellTransfer 7.87/7.88. These single shared-load
samples are not general performance benchmarks. PackingBlocks and CellTransfer
client objects match; WindowCarry bytes differ (baseline 2a27243ea8cc124d…,
final edfab1e75f895054…) for an unestablished reason. Target namespace census
matches all 25 declaration/type/axiom reports and default simp/instances
(29,063/13,173). Paired WindowCarry probes pin both target and client objects
before/after and match all 37 declaration/type/axiom reports and global
registrations (29,063/13,173). The census does not establish equality of proof
bodies or every persistent environment extension. Both target and WindowCarry
logs retain one identical existing warning each; the other clients have none.

The initial baseline invocation built target, WindowCarry and PackingBlocks but
the build script stopped before invoking Lean for CellTransfer: the overlay was
missing ModularCancellation. setup-failure.txt and baseline-before-client-
records.json preserve the failure's details and successful first three builds;
the missing providers were supplied and the client was retried separately, with
baseline-client-retry-records.json retaining its receipt. baseline-records.json
combines both. A preliminary successful final target receipt is preserved as
preliminary-final-records.json, but its object and log paths were later reused;
the full paired lane is the validation evidence.
