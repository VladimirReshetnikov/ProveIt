import DiophantineConsistency.ArithmeticPackingBlocks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPackingBlocks).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPackingBlocks" then
   logInfo m!"DECL {n}"
