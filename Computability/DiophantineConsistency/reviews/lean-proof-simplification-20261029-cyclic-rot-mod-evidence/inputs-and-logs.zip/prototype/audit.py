from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/cyclic-rot-mod');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
paths={'ArithmeticWindowDigits':'/tmp/window-digit-replace/final-records.json','ArithmeticStandardCasts':'/tmp/binary-half-direct/final-supplement-records.json','ArithmeticModularCancellation':'/tmp/shared-modular-cancel/records.json','ArithmeticCellLabels':'/tmp/support-cast/refresh-records.json'};providers={}
for n,f in paths.items():
 x=next(x for x in load(f) if x['module']==n);before=x.get('before') or x.get('source_before');after=x.get('after') or x.get('source_after');assert x['status']==0 and before==after==h(W/f'{n}.lean');providers[n]=x['object_sha256']
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticCyclicWord','ArithmeticWindowCarry','ArithmeticPackingBlocks','ArithmeticCellTransfer']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if x['module']!='ArithmeticCyclicWord':assert x['before']==h(W/f"{x['module']}.lean")
  else:
   rev='5c94a5dd2d^' if ph=='baseline' else '5c94a5dd2d'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticCyclicWord.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert h(W/'ArithmeticCyclicWord.lean')==x['before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticCyclicWord':assert d['before']==rr[0]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=load(R/'ArithmeticWindowCarry-probe-records.json');assert len(rows)==8
for x in rows:assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[z['object_sha256'] for z in records[x['phase']][:2]] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-ArithmeticWindowCarry-{n}.log').read_bytes()==(R/f'final-ArithmeticWindowCarry-{n}.log').read_bytes()
for n in ('ArithmeticPackingBlocks','ArithmeticCellTransfer'):assert next(x for x in records['baseline'] if x['module']==n)['object_sha256']==next(x for x in records['final'] if x['module']==n)['object_sha256']
print('PASS direct-provider producer matches, paired target/three clients and target/differing-client probes')
