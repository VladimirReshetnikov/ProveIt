from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/tmp/cyclic-rot-mod');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticCyclicWord.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticCyclicWord.lean').read_text();start='  have hX : X = X / Exp.exp (w*(n-e))';end='  rw [e1, mod_add_mul _ _ hM]'
i=b.index(start);j=b.index(end,i);k=f.index('  have hc := exp_complement w n e he\n',f.index('theorem rot_mod'));l=f.index(end,k);assert b[:i]==f[:k] and b[j:]==f[l:]
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticCyclicWord.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('5c94a5dd2d^')==b and gitfile('5c94a5dd2d')==f and (W/'ArithmeticCyclicWord.lean').read_text()==f
print('PASS only rot_mod proof differs; commit/parent snapshots and final workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticCyclicWord$','--','*.lean'],text=True).splitlines();assert sorted(Path(s).stem for s in clients)==['ArithmeticCellTransfer','ArithmeticPackingBlocks','ArithmeticWindowCarry'],clients
print('PASS three tracked Lean direct clients',clients)
paths={'ArithmeticWindowDigits':'/tmp/window-digit-replace/final-records.json','ArithmeticStandardCasts':'/tmp/binary-half-direct/final-supplement-records.json','ArithmeticModularCancellation':'/tmp/shared-modular-cancel/records.json','ArithmeticCellLabels':'/tmp/support-cast/refresh-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module']==n);a=x.get('before') or x.get('source_before');z=x.get('after') or x.get('source_after');assert x['status']==0 and a==z==h(W/f'{n}.lean');providers[n]=x['object_sha256']
 print('PASS prior source/object pair',n,a,providers[n])
rec={}
for phase in ('baseline','final'):
 rr=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rr};assert set(rec[phase])=={'ArithmeticCyclicWord','ArithmeticWindowCarry','ArithmeticPackingBlocks','ArithmeticCellTransfer'}
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticCyclicWord':assert x['before']==h(W/(x['module']+'.lean'))
  imports=re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M);assert imports==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file())
   assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   n=d['module'].split('.')[-1]
   if n=='ArithmeticCyclicWord':assert d['before']==rr[0]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
   else:assert d['module']=='Mathlib.Algebra.BigOperators.Ring.Finset'
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticPackingBlocks','ArithmeticCellTransfer'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
assert rec['baseline']['ArithmeticWindowCarry']['object_sha256']!=rec['final']['ArithmeticWindowCarry']['object_sha256']
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticCyclicWord']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=read(R/'ArithmeticWindowCarry-probe-records.json');assert len(rows)==8
for x in rows:
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[x['phase']][n]['object_sha256'] for n in ('ArithmeticCyclicWord','ArithmeticWindowCarry')] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-ArithmeticWindowCarry-{n}.log').read_bytes()==(R/f'final-ArithmeticWindowCarry-{n}.log').read_bytes()
a=read(R/'baseline-before-client-records.json');retry=read(R/'baseline-client-retry-records.json');assert len(a)==3 and len(retry)==1 and [x['object_sha256'] for x in a+retry]==[rec['baseline'][n]['object_sha256'] for n in ('ArithmeticCyclicWord','ArithmeticWindowCarry','ArithmeticPackingBlocks','ArithmeticCellTransfer')]
assert 'missing import DiophantineConsistency.ArithmeticModularCancellation' in (R/'setup-failure.txt').read_text()
print('PASS paired target and differing-client probes, setup retry provenance; remaining closure cached')
