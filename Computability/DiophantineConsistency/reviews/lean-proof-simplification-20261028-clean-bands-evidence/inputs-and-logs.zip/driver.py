import os,subprocess,sys,time,hashlib,json
from pathlib import Path
root=Path('/tmp/native-clean-pair-validation');phase=sys.argv[1];kind=sys.argv[2];lean='Computability/DiophantineConsistency/Lean';base=Path(lean)/'DiophantineConsistency';env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
pre=json.loads((root/'graph-before.json').read_text())['prebuild']
if kind=='pre':jobs=[(n,str(base/(n+'.lean')),True) for n in pre]
elif kind=='targets':jobs=[(n,str(base/(n+'.lean')),True) for n in ['NativeCleanBands54','NativeHighPort54','NativeTemporalSupport54']]
else:jobs=[('focus',lean+'/checks/NativeCleanBands54.lean',False),('axioms',str(root/'axioms.lean'),False)]
rows=[]
for tag,path,obj_needed in jobs:
 p=Path(path);obj=root/phase/'DiophantineConsistency'/(tag+'.olean');log=root/(phase+'-'+tag+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R',lean,str(p)]
 if obj_needed:cmd+=['-o',str(obj)]
 t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(v.stdout+v.stderr);q={'tag':tag,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj_needed and v.returncode==0:q.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
 rows.append(q);(root/(phase+'-'+kind+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,tag,v.returncode,round(q['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
