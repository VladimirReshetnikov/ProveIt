import os,subprocess,sys,time,json,hashlib
from pathlib import Path
r=Path('/tmp/shared-standard-casts-validation');env=os.environ.copy();env['LEAN_PATH']=str(r/'baseline')+':'+env.get('LEAN_PATH','');names=sys.argv[1:];rec=[]
for n in names:
 p=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');obj=r/'baseline/DiophantineConsistency'/(n+'.olean');log=r/('pre-'+n+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p),'-o',str(obj)]
 t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(v.stdout+v.stderr);q={'module':n,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if not v.returncode:q['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest()
 rec.append(q);(r/'prebuild-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(n,v.returncode,round(q['seconds'],1),flush=True)
 if v.returncode:print(log.read_text()[:1000],flush=True);sys.exit(v.returncode)
