import os, subprocess, sys, time, hashlib, json
from pathlib import Path
r=Path('/tmp/shared-standard-casts-validation'); phase=sys.argv[1]; env=os.environ.copy(); env['LEAN_PATH']=str(r/phase)+':'+env.get('LEAN_PATH','')
root=Path('Computability/DiophantineConsistency/Lean')
res=[]
for n in ['ArithmeticCellDecoding','ArithmeticControllerStride']:
 p=root/'DiophantineConsistency'/f'{n}.lean'; cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(p)]; t=time.monotonic(); v=subprocess.run(cmd,env=env,capture_output=True); log=r/f'{phase}-{n}-client.log'; log.write_bytes(v.stdout+v.stderr); x={'module':n,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}; res.append(x); (r/f'{phase}-client-records.json').write_text(json.dumps(res,indent=2)+'\n'); print(phase,n,v.returncode,round(x['seconds'],1),flush=True)
 if v.returncode: print(log.read_text()[:1000],flush=True); sys.exit(v.returncode)
