import os, subprocess, time, hashlib, json
from pathlib import Path
r=Path('/tmp/shared-standard-casts-validation'); root=Path('Computability/DiophantineConsistency/Lean'); overlay=r/'final'; out=overlay/'DiophantineConsistency'; out.mkdir(parents=True,exist_ok=True)
mods=['ArithmeticStandardCasts','ArithmeticMaskConstants','ArithmeticCellTransfer','ArithmeticPackingCells','ArithmeticControllerData']
for entry in (r/'baseline').iterdir():
 if entry.name!='DiophantineConsistency': (overlay/entry.name).symlink_to(entry.resolve(),target_is_directory=True)
for entry in (r/'baseline/DiophantineConsistency').iterdir():
 if entry.name not in {m+'.olean' for m in mods}: (out/entry.name).symlink_to(entry.resolve())
env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','');res=[]
for m in mods:
 p=root/'DiophantineConsistency'/f'{m}.lean'; obj=out/f'{m}.olean'; cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(root),str(p),'-o',str(obj)]; t=time.monotonic(); v=subprocess.run(cmd,env=env,capture_output=True); log=r/f'final-{m}.log';log.write_bytes(v.stdout+v.stderr); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); x={'module':m,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':sha(p),'object_sha256':sha(obj) if obj.exists() else None,'log_sha256':sha(log)};res.append(x);(r/'final-records.json').write_text(json.dumps(res,indent=2)+'\n');print(m,v.returncode,round(x['seconds'],1),flush=True)
 if v.returncode: print(log.read_text()[:1500],flush=True);raise SystemExit(v.returncode)
