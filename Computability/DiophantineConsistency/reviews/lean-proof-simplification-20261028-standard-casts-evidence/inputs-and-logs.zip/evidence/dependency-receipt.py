import re,hashlib,json
from pathlib import Path
r=Path('/tmp/shared-standard-casts-validation');root=Path('Computability/DiophantineConsistency/Lean');out=r/'final'; todo=['ArithmeticMaskConstants','ArithmeticCellTransfer','ArithmeticPackingCells','ArithmeticControllerData']; seen={}; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while todo:
 n=todo.pop(); p=root/'DiophantineConsistency'/f'{n}.lean'
 if n in seen or not p.exists():continue
 s=p.read_text();deps=re.findall(r'^import DiophantineConsistency\.([\w]+)',s,re.M); o=out/'DiophantineConsistency'/f'{n}.olean';seen[n]={'source_sha256':sha(p),'object_path':str(o.resolve()) if o.exists() else None,'object_sha256':sha(o) if o.exists() else None,'direct_local_imports':deps};todo.extend(deps)
(r/'final-dependency-receipt.json').write_text(json.dumps(seen,indent=2,sort_keys=True)+'\n');print(len(seen),'modules;',sum(v['object_path'] is None for v in seen.values()),'local objects missing');print('Boundary: Foundation, Mathlib, Lean and BusyBeaver objects are precompiled and not recursively revalidated.')
