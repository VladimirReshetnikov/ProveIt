import os,subprocess,time,json,hashlib,sys
from pathlib import Path
r=Path('/tmp/shared-standard-casts-validation');env=os.environ.copy();env['LEAN_PATH']=str(r/'probe-overlay')+':'+env.get('LEAN_PATH','');out=[]
for n in sys.argv[1:]:
 p=r/'candidate/DiophantineConsistency'/(n+'.lean');obj=r/'probe-overlay/DiophantineConsistency'/(n+'.olean');log=r/('probe-'+n+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(r/'candidate'),str(p),'-o',str(obj)];t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(v.stdout+v.stderr);x={'module':n,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};out.append(x);(r/'probe-records.json').write_text(json.dumps(out,indent=2)+'\n');print(n,v.returncode,round(x['seconds'],1),flush=True)
 if v.returncode:print(log.read_text()[:900],flush=True);sys.exit(v.returncode)
