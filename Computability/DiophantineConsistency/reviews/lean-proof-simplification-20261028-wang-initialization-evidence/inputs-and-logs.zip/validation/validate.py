from pathlib import Path
import json,hashlib,os,subprocess,time,sys
R=Path('/tmp/wang-encoding-initialized-20261028'); root=Path('Computability/DiophantineConsistency/Lean'); prior=Path('/tmp/kernel-eval-rewrite/normal-prereq'); shared=R/'shared';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for ns in ['BusyBeaver','Diophantine','DiophantineConsistency']:
 src=prior/ns
 for p in src.rglob('*.olean'):
  dst=shared/p.relative_to(prior);dst.parent.mkdir(parents=True,exist_ok=True)
  if not dst.exists() and not dst.is_symlink():dst.symlink_to(p.resolve())
env=os.environ.copy(); inherited=env['LEAN_PATH'];env['LEAN_PATH']=str(shared)+':'+inherited

def run(phase,name,src,base,out,environment):
 log=R/(phase+'-'+name+'.log');tm=R/(phase+'-'+name+'.time');cmd=['lean','-M6000','-j1','-DElab.async=false'];
 if out:cmd+=['-R',str(base)]
 cmd+=[str(src)]
 if out:cmd+=['-o',str(out)]
 start=time.monotonic();v=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss_kb=%M','-o',str(tm)]+cmd,stdout=log.open('wb'),stderr=subprocess.STDOUT,env=environment);d={'phase':phase,'name':name,'status':v.returncode,'command':cmd,'lean_path':environment['LEAN_PATH'],'seconds':round(time.monotonic()-start,2),'time':tm.read_text().strip(),'source_sha256':sha(src),'log_sha256':sha(log),'object_sha256':sha(out) if out and out.exists() else None};records.append(d);(R/'records.json').write_text(json.dumps(records,indent=2));print(phase,name,v.returncode,d['seconds'],flush=True)
 if v.returncode:sys.exit(v.returncode)
init=shared/'DiophantineConsistency/DecimalMachineInitialization.olean';init.unlink(missing_ok=True);run('shared','DecimalMachineInitialization',root/'DiophantineConsistency/DecimalMachineInitialization.lean',root,init,env)
for phase in ['baseline','final']:
 overlay=R/phase/'overlay'
 for ns in ['BusyBeaver','Diophantine','DiophantineConsistency']:
  for p in (shared/ns).rglob('*.olean'):
   q=overlay/p.relative_to(shared);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 envp=os.environ.copy();envp['LEAN_PATH']=str(overlay)+':'+inherited;target=overlay/'DiophantineConsistency/WangMachineEncoding.olean';target.unlink(missing_ok=True);srcroot=R/('baseline-source' if phase=='baseline' else 'source');run(phase,'target',srcroot/'DiophantineConsistency/WangMachineEncoding.lean',srcroot,target,envp)
 run(phase,'axioms',R/'axioms.lean',None,None,envp)
 for n in ['WangMachineEncodingChecks','WangMachineAction','WangMachineStep']:
  out=overlay/'DiophantineConsistency'/(n+'.olean');out.unlink(missing_ok=True);run(phase,n,root/'DiophantineConsistency'/(n+'.lean'),root,out,envp)
if (R/'baseline-axioms.log').read_bytes()!=(R/'final-axioms.log').read_bytes():sys.exit('axiom reports differ')
print('axiom reports identical',flush=True)
