from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/wang-encoding-initialized-20261028');base=Path('Computability/DiophantineConsistency/Lean');records=[];env=os.environ.copy();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for phase in ['baseline','final']:
 overlay=R/phase/'overlay';e=env.copy();e['LEAN_PATH']=str(overlay)+':'+env['LEAN_PATH']
 for n in ['extra-axioms','WangTiles942RowEncoding','WangTiles942FinishConstruction']:
  src=R/'extra-axioms.lean' if n=='extra-axioms' else base/'DiophantineConsistency'/(n+'.lean');out=overlay/'DiophantineConsistency'/(n+'.olean') if n!='extra-axioms' else None;log=R/(phase+'-'+n+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false'];
  if out:out.unlink(missing_ok=True);cmd+=['-R',str(base)]
  cmd.append(str(src));
  if out:cmd+=['-o',str(out)]
  t=time.monotonic();v=subprocess.run(cmd,env=e,stdout=log.open('wb'),stderr=subprocess.STDOUT);records.append({'phase':phase,'name':n,'status':v.returncode,'command':cmd,'lean_path':e['LEAN_PATH'],'seconds':round(time.monotonic()-t,2),'source_sha256':sha(src),'log_sha256':sha(log),'object_sha256':sha(out) if out and out.exists() else None});(R/'extra-records.json').write_text(json.dumps(records,indent=2));print(phase,n,v.returncode,records[-1]['seconds'],flush=True)
