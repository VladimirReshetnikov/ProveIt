from pathlib import Path
import re,json,hashlib
R=Path('/tmp/wang-encoding-initialized-20261028');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/HilbertTenthProblem/Lean'),Path('Computability/BusyBeaver/Lean')];ov=R/'shared';graph={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def walk(n):
 if n in graph:return
 p=next((r/(n.replace('.','/')+'.lean') for r in roots if (r/(n.replace('.','/')+'.lean')).exists()),None)
 if p is None:return
 im=re.findall(r'^(?:public\s+)?(?:meta\s+)?import\s+([\w.]+)',p.read_text(),re.M);o=ov/(n.replace('.','/')+'.olean');graph[n]={'source':str(p),'source_sha256':sha(p),'object':str(o.resolve()) if o.exists() else None,'object_sha256':sha(o) if o.exists() else None,'imports':im}
 for q in im:walk(q)
for n in ['DiophantineConsistency.DecimalMachineInitialization','DiophantineConsistency.WangMachineEncodingChecks','DiophantineConsistency.WangMachineAction','DiophantineConsistency.WangMachineStep']:walk(n)
(R/'graph.json').write_text(json.dumps(graph,indent=2));print('graph',len(graph),'missing',[(n,v['object']) for n,v in graph.items() if v['object'] is None])
