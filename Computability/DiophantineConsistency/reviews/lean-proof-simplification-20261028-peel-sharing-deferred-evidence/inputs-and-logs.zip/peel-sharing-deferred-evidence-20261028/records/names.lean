import DiophantineConsistency.ArithmeticRuntimeBoundTapeSymbolic
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRuntimeBoundTapeSymbolic).isPrefixOf n ||
     (`_private.DiophantineConsistency.ArithmeticRuntimeBoundTapeSymbolic).isPrefixOf n then
   logInfo m!"DECL {n}"
