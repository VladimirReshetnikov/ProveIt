import subprocess,sys
for phase in ('baseline','final'):
 for name in ('interfaces','global-simp'):
  subprocess.run([sys.executable,'/tmp/peel-sharing/probe.py',phase,name],check=True)
