from pathlib import Path
import hashlib,json,subprocess
r=Path('/tmp/peel-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for label in ('removed','changed-common'):
 term=r/(label+'-short.txt');out=r/(label+'-reference-search.log');cmd=['rg','-n','-F','-f',str(term),'--glob','*.lean','--glob','*.py','Computability/DiophantineConsistency','Computability/BusyBeaver'];before=h(term)
 with out.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 x={'label':label,'command':cmd,'status':q.returncode,'terms':str(term),'terms_before':before,'terms_after':h(term),'log':str(out),'log_sha256':h(out),'bytes':out.stat().st_size};records.append(x);assert q.returncode==1 and not out.stat().st_size and before==h(term)
(r/'reference-search-records.json').write_text(json.dumps(records,indent=2)+'\n');print('both searches: status 1, zero output')
