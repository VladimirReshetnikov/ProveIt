import hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path('/tmp/pred-certificate-simplify-20261028');p=r/'boundaries.lean';env=os.environ.copy();env['LEAN_PATH']=str(r/'baseline')+':'+env.get('LEAN_PATH','');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p)]
t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log=r/'baseline-boundaries.log';log.write_bytes(v.stdout+v.stderr)
x={'tag':'boundaries','cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};records=json.loads((r/'baseline-records.json').read_text());records[-1]=x;(r/'baseline-records.json').write_text(json.dumps(records,indent=2)+'\n');print('baseline boundary retry',v.returncode,flush=True);sys.exit(v.returncode)
