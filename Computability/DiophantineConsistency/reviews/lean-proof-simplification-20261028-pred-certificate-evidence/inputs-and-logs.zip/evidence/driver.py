import os,subprocess,sys,time,json,hashlib
from pathlib import Path
r=Path('/tmp/pred-certificate-simplify-20261028');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+env.get('LEAN_PATH','');lean='Computability/DiophantineConsistency/Lean';src=Path(lean)/'DiophantineConsistency';items=[]
jobs=[('QuadraticTreeCodeGraphs',src/'QuadraticTreeCodeGraphs.lean',True),('QuadraticListHead',src/'QuadraticListHead.lean',True),('ObjectPredecessorSyntax',src/'ObjectPredecessorSyntax.lean',True),('focus',Path(lean+'/checks/QuadraticRegisterComposition.lean'),False),('axioms',r/'axioms.lean',False),('boundaries',r/'boundaries.lean',False)]
for tag,p,write in jobs:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',lean,str(p)];obj=r/phase/'DiophantineConsistency'/(tag+'.olean')
 if write:cmd+=['-o',str(obj)]
 t=time.monotonic();v=subprocess.run(cmd,capture_output=True,env=env);log=r/(phase+'-'+tag+'.log');log.write_bytes(v.stdout+v.stderr)
 x={'tag':tag,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if write and not v.returncode:x.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
 items.append(x);(r/(phase+'-records.json')).write_text(json.dumps(items,indent=2)+'\n');print(phase,tag,v.returncode,flush=True)
 if v.returncode:sys.exit(v.returncode)
