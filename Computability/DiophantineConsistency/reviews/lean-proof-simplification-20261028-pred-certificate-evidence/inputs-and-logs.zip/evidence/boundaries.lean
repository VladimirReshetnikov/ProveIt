import DiophantineConsistency.QuadraticTreeCodeGraphs
open DiophantineConsistency.QuadraticTreeCodeGraphs
example : PredCertificate 0 0 := (pred_certificate_iff 0 0).2 rfl
example : ¬ PredCertificate 1 0 := by
  intro h
  have he : (1 : ℕ) = 0 := by simpa using (pred_certificate_iff 1 0).1 h
  omega
example : PredCertificate 0 1 := (pred_certificate_iff 0 1).2 rfl
example : PredCertificate 9 10 := (pred_certificate_iff 9 10).2 rfl
