import os,subprocess,sys,time,json,hashlib
from pathlib import Path
root=Path('/tmp/divmod-proof-reuse-20261028');setup=json.loads((root/'setup.json').read_text());env=os.environ.copy();env['LEAN_PATH']=str(root/'baseline')+':'+env.get('LEAN_PATH','');items=[]
for path in setup['prep_order']:
 p=Path(path);name=p.stem;obj=root/'baseline/DiophantineConsistency'/(name+'.olean');log=root/('pre-'+name+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p),'-o',str(obj)]
 t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log.write_bytes(v.stdout+v.stderr);q={'tag':name,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if not v.returncode:q.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
 items.append(q);(root/'pre-records.json').write_text(json.dumps(items,indent=2)+'\n');print(name,v.returncode,round(q['seconds'],2),flush=True)
 if v.returncode:sys.exit(v.returncode)
