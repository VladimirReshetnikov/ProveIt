from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/ratio-reparam-proof-20261028');pre='Computability/DiophantineConsistency/Lean/';mode=sys.argv[1]
items=[('target',pre+'DiophantineConsistency/RatioReparameterization.lean',True),('axioms',str(p/'axioms.lean'),False)]
if mode=='final':items += [('focus',pre+'checks/RatioReparameterization.lean',False),('client',pre+'DiophantineConsistency/NativeNineRatio52.lean',False)]
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free<65*1024*1024:raise SystemExit('disk guard: '+str(free))
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency/RatioReparameterization.olean')]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/ratio-reparam-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);secs=time.monotonic()-start
 log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 records.append({'name':name,'argv':cmd,'exit_status':r.returncode,'seconds':secs,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
