from pathlib import Path
import hashlib,json,re,subprocess,tomllib
repo=Path.cwd()
base='8e13da9d92cf9f4f4aa004d80f34c98fd26ba093'
prefix='Computability/DiophantineConsistency/Lean/'
roots=['Computability/DiophantineConsistency/Lean/DiophantineConsistency/WangMachineStep.lean', 'Computability/DiophantineConsistency/Lean/DiophantineConsistency/WangMachineStepChecks.lean', 'Computability/DiophantineConsistency/Lean/DiophantineConsistency/WangTiles942HeadBounds.lean', 'Computability/DiophantineConsistency/Lean/DiophantineConsistency/WangTiles942StepConstruction.lean']
tracked=set(subprocess.check_output(['git','ls-files','-z'],text=True).split('\0'))-{''}
tracked.update([prefix+'DiophantineConsistency/EnumeratorSemantics.lean',prefix+'DiophantineConsistency/DirectScalarEnumeratorCore.lean',prefix+'checks/EnumeratorCompatibility.lean'])
libs=tomllib.loads((repo/'lakefile.toml').read_text())['lean_lib']
mapping={}
for lib in libs:
 for root in lib.get('roots',[lib['name']]):mapping.setdefault(root,[]).append(lib.get('srcDir','.'))
def resolve(module):
 candidates=[]
 for root,dirs in mapping.items():
  if module==root or module.startswith(root+'.'):
   for directory in dirs:
    path=(Path(directory)/(module.replace('.','/')+'.lean')).as_posix().removeprefix('./')
    if path in tracked:candidates.append(path)
 candidates=list(dict.fromkeys(candidates))
 if len(candidates)>1:raise RuntimeError((module,candidates))
 if candidates:return candidates[0]
 if any(module==root or module.startswith(root+'.') for root in mapping):raise RuntimeError(('missing tracked project module',module))
 return None
def strip_comments(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s.startswith('/-',i):depth+=1;i+=2
  elif depth and s.startswith('-/',i):depth-=1;i+=2
  elif depth:
   if s[i]=='\n':out.append('\n')
   i+=1
  elif s.startswith('--',i):
   end=s.find('\n',i);i=len(s) if end<0 else end
  else:out.append(s[i]);i+=1
 return ''.join(out)
seen=set();edges={};todo=roots[:]
while todo:
 path=todo.pop()
 if path in seen:continue
 assert path in tracked,path
 seen.add(path);imports=[]
 for m in re.finditer(r'^\s*(?:(?:public|meta)\s+)*import\s+([^\n]+)',strip_comments((repo/path).read_text()),re.M):
  for module in m.group(1).split():
   if module=='all':continue
   dep=resolve(module)
   if dep:imports.append(dep);todo.append(dep)
 edges[path]=imports
pins=['lakefile.toml','lake-manifest.json','lean-toolchain','Computability/DiophantineConsistency/equation.tex','Computability/DiophantineConsistency/equation.pdf']
protected=seen|set(pins)
files={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in sorted(protected)}
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
mathlib='.lake/packages/mathlib'
mathlib_head=subprocess.check_output(['git','-C',mathlib,'rev-parse','HEAD'],text=True).strip()
mathlib_clean=not subprocess.check_output(['git','-C',mathlib,'status','--porcelain','--untracked-files=no'],text=True).strip()
assert mathlib_head=='81a5d257c8e410db227a6665ed08f64fea08e997' and mathlib_clean
result={'base':base,'checked_commit':commit,'roots':sorted(set(roots)),'files':files,'project_import_edges':edges,'mathlib_head':mathlib_head,'mathlib_tracked_clean':mathlib_clean}
Path('/tmp/wang-step-20261028/graph-before.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checked_commit':commit,'roots':len(set(roots)),'project_sources':len(seen),'protected_files':len(files),'mathlib_head':mathlib_head,'mathlib_tracked_clean':mathlib_clean},indent=2))
