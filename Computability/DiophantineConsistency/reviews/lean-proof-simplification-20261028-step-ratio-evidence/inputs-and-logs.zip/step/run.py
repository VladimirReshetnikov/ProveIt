from pathlib import Path
import hashlib, json, shutil, subprocess, sys, time
p=Path('/tmp/wang-step-20261028'); pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; mode=sys.argv[1]
items=([('encoding',pre+'WangMachineEncoding.lean',True),('action',pre+'WangMachineAction.lean',True)] if mode=='baseline' else []) + [('target',pre+'WangMachineStep.lean',True),('axioms',str(p/'axioms.lean'),False)]
if mode=='final': items += [('focus',pre+'WangMachineStepChecks.lean',False),('head',pre+'WangTiles942HeadBounds.lean',False),('step',pre+'WangTiles942StepConstruction.lean',False)]
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free < 65*1024*1024: print('DISK CUTOFF before',name,free,flush=True);sys.exit(90)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 out = p/'overlay/DiophantineConsistency'/({'target':'WangMachineStep','encoding':'WangMachineEncoding','action':'WangMachineAction'}.get(name,'unused')+'.olean')
 if obj:argv += ['-o',str(out)]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/wang-step-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);secs=time.monotonic()-start
 log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr);src=Path(source)
 rec={'name':name,'argv':cmd,'exit_status':r.returncode,'seconds':secs,'free_before':free,'source':source,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:rec['object']={'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size}
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
