from pathlib import Path
import os,subprocess,hashlib,json
R=Path('/dev/shm/target-near-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();src=R/'kernel-probe.lean';records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/('kernel-'+phase))+':'+base;objs=[R/('kernel-'+phase)/'DiophantineConsistency'/f'{n}.olean' for n in ['SplitKernels59','GapKernels66']];bs=sha(src);bh=[sha(x) for x in objs];log=R/f'kernel-{phase}-probe.log';cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':r.returncode,'source':str(src),'source_before':bs,'source_after':sha(src),'objects':[str(x) for x in objs],'object_hashes_before':bh,'object_hashes_after':[sha(x) for x in objs],'log':str(log),'log_sha256':sha(log)};records.append(rec);(R/'kernel-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,r.returncode,flush=True)
 if r.returncode or bs!=rec['source_after'] or bh!=rec['object_hashes_after']:raise SystemExit(1)
