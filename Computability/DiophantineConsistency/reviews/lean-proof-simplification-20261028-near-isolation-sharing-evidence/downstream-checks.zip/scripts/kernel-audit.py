from pathlib import Path
import json,re,hashlib
R=Path('/dev/shm/target-near-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();errors=[];cnt=0;deps=0
for phase in ['baseline','final']:
 for x in json.loads((R/f'kernel-{phase}-records.json').read_text()):
  cnt+=1;src=Path(x['source']);obj=Path(x['object']);log=Path(x['log'])
  if x['status'] or sha(src)!=x['after'] or x['before']!=x['after'] or sha(obj)!=x['object_sha256'] or sha(log)!=x['log_sha256']:errors.append((phase,x['module'],'source/object/log/status'))
  im=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M)
  if sorted(im)!=sorted(d['module'] for d in x['direct_inputs']):errors.append((phase,x['module'],'imports'))
  for d in x['direct_inputs']:
   deps+=1;p=Path(d['path']);rel=d['module'].replace('.','/')+'.olean';hits=[Path(q,rel) for q in x['LEAN_PATH'].split(':') if Path(q,rel).is_file()]
   if not p.is_file() or sha(p)!=d['after'] or d['before']!=d['after'] or p.resolve()!=Path(d['resolved']) or not hits or hits[0].resolve()!=p.resolve():errors.append((phase,x['module'],d['module']))
probe=json.loads((R/'kernel-probe-records.json').read_text())
for x in probe:
 if x['status'] or sha(x['source'])!=x['source_after'] or x['source_before']!=x['source_after'] or x['object_hashes_before']!=x['object_hashes_after'] or [sha(p) for p in x['objects']]!=x['object_hashes_after'] or sha(x['log'])!=x['log_sha256']:errors.append((x['phase'],'probe'))
identical=(R/'kernel-baseline-probe.log').read_bytes()==(R/'kernel-final-probe.log').read_bytes()
for n in ['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66']:
 if (R/f'kernel-baseline-{n}.log').read_bytes()!=(R/f'kernel-final-{n}.log').read_bytes():errors.append((n,'paired logs'))
print('builds',cnt,'direct inputs',deps,'probes',len(probe),'identical probe logs',identical,'errors',errors)
(R/'kernel-audit.json').write_text(json.dumps({'builds':cnt,'direct_inputs':deps,'probes':len(probe),'probe_logs_identical':identical,'errors':errors},indent=2)+'\n')
if errors or not identical:raise SystemExit(1)
