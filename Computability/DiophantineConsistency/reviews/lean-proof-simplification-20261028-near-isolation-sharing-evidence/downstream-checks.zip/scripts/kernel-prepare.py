from pathlib import Path
R=Path('/dev/shm/target-near-sharing');common=Path('/dev/shm/shared-box-prototype/coherent-common/DiophantineConsistency'); orig=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');mods=['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66'];up=['SelectiveCarry','SelectiveCoefficientBounds','PolynomialRangeBounds','SplitWordBounds'];src=R/'kernel-sources/DiophantineConsistency';src.mkdir(parents=True,exist_ok=True)
for n in mods:(src/f'{n}.lean').write_bytes((orig/f'{n}.lean').read_bytes())
for phase in ['baseline','final']:
 base=R/phase;out=R/('kernel-'+phase);out.mkdir(exist_ok=True)
 for f in base.iterdir():
  if f.name=='DiophantineConsistency':
   d=out/f.name;d.mkdir(exist_ok=True)
   for g in f.iterdir():
    p=d/g.name
    if not p.exists():p.symlink_to(g)
  elif not (out/f.name).exists():(out/f.name).symlink_to(f)
 for n in up:
  p=out/'DiophantineConsistency'/f'{n}.olean';p.unlink(missing_ok=True);p.symlink_to(common/f'{n}.olean')
 for n in mods:(out/'DiophantineConsistency'/f'{n}.olean').unlink(missing_ok=True)
