# Geometry sharing: adopted kernel downstream replay

28 October 2026. This supplements `/tmp/target-near-isolation-evidence-20261028-v2.zip`
(SHA-256 945a36c23a2d5578013da710fec655516f2aa1ff232a05fdecbd21c9db367793).
It tests the geometry candidate against the subsequently adopted port-bound
sharing in SplitKernelData59 and GapKernelData66. All four production source
snapshots (the two data modules and their two wrappers) match commit
5093f59cd6. The same source bytes are used in both geometry phases.

The baseline and final overlays each rebuilt SplitKernelData59, GapKernelData66,
SplitKernels59 and GapKernels66 in that order. All eight builds passed. The
records include exact commands, LEAN_PATH, source-before/after hashes,
direct-input paths and before/after hashes, output object hashes, log hashes
and timings. Both pairs of corresponding logs are byte-identical. The focused
combined-wrapper probe reports identical types and axioms for the adopted
port-box helper, all six strict record bounds and three kernel-bound theorems;
both probe runs passed. `records/kernel-audit.json` reports a recheck of eight
builds, 18 direct-input occurrences and both probes without discrepancy.

## Provider chain and historical failure

The same four current-source prerequisite objects are used for both phases:
SelectiveCarry, SelectiveCoefficientBounds, PolynomialRangeBounds and
SplitWordBounds. Their original source/object/direct-input receipts and logs
are included under provenance, together with the per-phase fresh geometry,
SplitCertificate59, GapSource66 and GapCertificate66 records from the prior
experiment. DegreeSeparatedCoding matched the earlier current-source/object
receipt included here. The earlier independent shared-port evidence package was
`/tmp/shared-box-generated-kernel-evidence-20261028.zip` with SHA-256
edec22541e76261f5de966600b0eb26766a6b0a2e1ae99b5fa9f6e8e00bcfc63.

An earlier, separate baseline SplitKernels59 replay against an inherited stale
SelectiveCarry object failed with unknown `SelectiveCarry.encoded_degree_le`.
Its record, log and timing are retained in historical/. It is not counted as a
successful build, and no result was overwritten by the new kernel replay. The
four-module refresh was performed before the successful paired runs. In the
prior geometry build records, the preliminary GapCertificate66 objects were
later overwritten at their original paths by the source-pinned replays. Copies
were saved locally in that experiment's historical directory; the compiled
objects are not included here.

## Limits

The paired chain is source-rebuilt at the stated boundaries; inherited upstream
objects, Mathlib and Lean remain cached and are not included. Matching hashes
and the earlier DegreeSeparatedCoding receipt do not establish a clean complete
source-closure build, and these four clients do not exhaust all downstream
users. Geometry and common source snapshots describe the specific recorded
inputs, while object paths and scripts rely on the original temporary overlays.
The archive excludes compiled objects and cannot replay independently. Its
hashes establish internal consistency, not a signed provenance. Timings are
single local runs and are not general performance claims.

`manifest.sha256` covers every file except itself.
