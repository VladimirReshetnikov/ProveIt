from pathlib import Path
import hashlib,json
root=Path('/dev/shm/target-near-sharing'); repo=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency'); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for phase in ['baseline','final']:
 f=root/f'kernel-{phase}-records.json'
 if not f.exists():print(phase,'PENDING');continue
 records=json.loads(f.read_text()); print(phase,'count',len(records))
 for x in records:
  errs=[]
  def check(ok,msg):
   if not ok: errs.append(msg)
  check(x['status']==0,'exit')
  check(x['before']==x['after']==H(x['source'])==H(repo/(x['module']+'.lean')),'source')
  check(x['object_sha256']==H(x['object']),'object')
  check(x['log_sha256']==H(x['log']),'log')
  for dep in x['direct_inputs']:
   p=Path(dep['path']); rel=dep['module'].replace('.','/')+'.olean'; first=next((Path(d)/rel for d in x['LEAN_PATH'].split(':') if (Path(d)/rel).is_file()),None)
   check(dep['before']==dep['after']==H(p),'input-hash '+dep['module'])
   check(first==p and str(p.resolve())==dep['resolved'],'input-first '+dep['module'])
  print(x['module'],x['status'],x['time'].strip(),'direct',len(x['direct_inputs']),'errors',errs)
