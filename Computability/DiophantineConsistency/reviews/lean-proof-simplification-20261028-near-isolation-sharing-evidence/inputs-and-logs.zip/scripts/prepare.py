from pathlib import Path
R=Path('/dev/shm/target-near-sharing');orig=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=Path('/tmp/word-origin-sharing/final');mods=['SplitGeometry59','GapGeometry66','SplitCertificate59','GapCertificate66']
for phase in ['baseline','final']:
 out=R/phase;out.mkdir(exist_ok=True)
 for f in base.iterdir():
  if f.name=='DiophantineConsistency':
   d=out/f.name;d.mkdir(exist_ok=True)
   for g in f.iterdir():
    p=d/g.name
    if not p.exists():p.symlink_to(g)
  elif not (out/f.name).exists():(out/f.name).symlink_to(f)
 for n in mods:(out/'DiophantineConsistency'/f'{n}.olean').unlink(missing_ok=True)
source=R/'baseline-source/DiophantineConsistency';source.mkdir(parents=True,exist_ok=True)
for n in mods:(source/f'{n}.lean').write_bytes((orig/f'{n}.lean').read_bytes())
