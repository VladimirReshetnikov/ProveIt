from pathlib import Path
import hashlib,json,re
R=Path('/dev/shm/target-near-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bad=[];count=0;depcount=0
for f in ['build-records.json','replay-baseline-records.json','replay-final-records.json']:
 for x in json.loads((R/f).read_text()):
  count+=1;src=Path(x['source']);obj=Path(x['object']);log=Path(x['log']);
  if x['status']!=0 or not src.exists() or sha(src)!=x['after'] or x['before']!=x['after']:bad.append((f,x['phase'],x['module'],'source/status'))
  if f=='build-records.json' and x['module']=='GapCertificate66':obj=R/'historical'/x['phase']/'GapCertificate66.olean'
  if not obj.exists() or sha(obj)!=x['object_sha256']:bad.append((f,x['phase'],x['module'],'object'))
  if not log.exists() or sha(log)!=x['log_sha256']:bad.append((f,x['phase'],x['module'],'log'))
  imports=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M)
  if sorted(imports)!=sorted(d['module'] for d in x['direct_inputs']):bad.append((f,x['phase'],x['module'],'imports'))
  for d in x['direct_inputs']:
   depcount+=1;p=Path(d['resolved'])
   if not p.exists() or d['before']!=d['after'] or sha(p)!=d['after']:bad.append((f,x['phase'],x['module'],d['module']))
pr=json.loads((R/'probe-records.json').read_text())
for x in pr:
 if x['status'] or sha(x['source'])!=x['source_after'] or x['source_before']!=x['source_after'] or x['objects_before']!=x['objects_after'] or sha(x['log'])!=x['log_sha256']:bad.append(('probe',x['phase'],x['probe']))
g=json.loads((R/'generator-records.json').read_text())
if g['before']!=g['after'] or any(sha(p)!=h for p,h in g['after'].items()):bad.append(('generator','source/data'))
print('builds',count,'direct input occurrences',depcount,'probes',len(pr),'bad',bad)
(R/'audit.json').write_text(json.dumps({'builds':count,'direct_input_occurrences':depcount,'probes':len(pr),'bad':bad},indent=2)+'\n')
if bad:raise SystemExit(1)
