from pathlib import Path
import subprocess,hashlib,json,sys
R=Path('/dev/shm/target-near-sharing');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=[R/'tools'/x for x in ['generate_split_certificate59.py','generate_gap_certificate66.py']]+list((R/'data/split59').glob('*.json'))+list((R/'candidates/gap2082-compact54/data/H2082').glob('*.json'))+[R/'Lean/DiophantineConsistency'/f'{x}.lean' for x in ['SplitGeometry59','GapGeometry66','SplitCertificate59','GapCertificate66']];before={str(p):sha(p) for p in files};records=[]
for name,args in [('split',[]),('gap',['--check'])]:
 cmd=[sys.executable,str(R/'tools'/('generate_split_certificate59.py' if name=='split' else 'generate_gap_certificate66.py')),*args];r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=R/f'generator-{name}.log';log.write_bytes(r.stdout);records.append({'cmd':cmd,'status':r.returncode,'log':str(log),'log_sha256':sha(log)});print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
after={str(p):sha(p) for p in files};(R/'generator-records.json').write_text(json.dumps({'before':before,'after':after,'records':records},indent=2)+'\n');print('all generator/data/output hashes unchanged',before==after)
if before!=after:raise SystemExit(1)
