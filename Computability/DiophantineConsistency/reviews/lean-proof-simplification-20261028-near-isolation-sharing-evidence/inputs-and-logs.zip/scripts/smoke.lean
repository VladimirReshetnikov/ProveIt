import Mathlib.Tactic
 theorem target_cross_of_near {t u a b d : ℕ} (ha : a ≤ d) (hb : b ≤ d)
    (near : t ≤ u + d → u ≤ t + d → b + (t - a) ≠ u) :
    b + (t - a) ≠ u := by
  by_cases h : t ≤ u + d
  · by_cases h' : u ≤ t + d
    · exact near h h'
    · intro he
      have hs := Nat.sub_le t a
      omega
  · intro he
    omega
example (weights : Fin 31 → ℕ) (targets : Fin 22 → ℕ) (maxw : ∀ i, weights i ≤ 116)
    (k l : Fin 22) (i j : Fin 31)
    (near : targets k ≤ targets l + 116 → targets l ≤ targets k + 116 →
      weights j + (targets k - weights i) ≠ targets l) :
    weights j + (targets k - weights i) ≠ targets l := by
  exact target_cross_of_near (maxw i) (maxw j) near
example (weights : Fin 31 → ℕ) (targets : Fin 22 → ℕ) (maxw : ∀ i, weights i ≤ 116)
    (a : ℕ) (hp : a ≤ 232) (k l : Fin 22) (i j : Fin 31)
    (near : targets k ≤ targets l + 232 → targets l ≤ targets k + 232 →
      weights i + weights j + (targets k - a) ≠ targets l) :
    weights i + weights j + (targets k - a) ≠ targets l := by
  have hwi := maxw i
  have hwj := maxw j
  have hb : weights i + weights j ≤ 232 := by omega
  exact target_cross_of_near hp hb near
