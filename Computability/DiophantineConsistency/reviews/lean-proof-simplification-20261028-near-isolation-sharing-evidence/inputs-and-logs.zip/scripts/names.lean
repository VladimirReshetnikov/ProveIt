import DiophantineConsistency.GapGeometry66
#print equations DiophantineConsistency.SplitCertificate59.targets
#print equations DiophantineConsistency.SplitCertificate59.activePair
#print equations DiophantineConsistency.SplitCertificate59.quadraticSupport
#print equations DiophantineConsistency.GapCertificate66.targets
#print equations DiophantineConsistency.GapCertificate66.activePair
#print equations DiophantineConsistency.GapCertificate66.quadraticSupport
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.SplitCertificate59).isPrefixOf n ||
     (`DiophantineConsistency.GapCertificate66).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.GapGeometry66" ||
     (toString n).startsWith "_private.DiophantineConsistency.SplitGeometry59" then
   logInfo m!"DECL {n}"
