from pathlib import Path
p=Path('/dev/shm/target-near-sharing/tools/generate_split_certificate59.py');s=p.read_text();mark="    out.append('''theorem linear_span :"; assert s.count(mark)==1
helper="""    out.append('''/-- A cross target is isolated globally if nearby targets are isolated. -/
theorem target_cross_of_near {t u a b d : ℕ} (ha : a ≤ d) (hb : b ≤ d)
    (near : t ≤ u + d → u ≤ t + d → b + (t - a) ≠ u) :
    b + (t - a) ≠ u := by
  by_cases h : t ≤ u + d
  · by_cases h' : u ≤ t + d
    · exact near h h'
    · intro he
      have hs := Nat.sub_le t a
      omega
  · intro he
    omega
''')
"""
s=s.replace(mark,helper+mark);s=s.replace("'def quadraticIndices ', 'def quadraticSupport ', 'theorem linear_span '","'def quadraticIndices ', 'def quadraticSupport ', 'theorem target_cross_of_near ', 'theorem linear_span '")
old='''  have hw := maximum_weight i
  have hwj := maximum_weight j
  by_cases h1 : targets k ≤ targets l+116
  · by_cases h2 : targets l ≤ targets k+116
    · exact linear_cross_near k l hkl h1 h2 i hi j
    · intro he
      have hs := Nat.sub_le (targets k) (weights i)
      omega
  · intro he
    omega'''
new='''  exact SplitCertificate59.target_cross_of_near (maximum_weight i) (maximum_weight j)
    (fun h1 h2 => linear_cross_near k l hkl h1 h2 i hi j)'''; assert s.count(old)==1;s=s.replace(old,new)
old='''  by_cases h1 : targets k ≤ targets l+232
  · by_cases h2 : targets l ≤ targets k+232
    · exact quadratic_cross_near k l hkl h1 h2 a ha i j
    · intro he
      have hs := Nat.sub_le (targets k) (pairWeight weights (activePair a))
      omega
  · intro he
    omega''';new='''  have hb : weights i + weights j ≤ 232 := by omega
  exact SplitCertificate59.target_cross_of_near hp hb
    (fun h1 h2 => quadratic_cross_near k l hkl h1 h2 a ha i j)''';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
