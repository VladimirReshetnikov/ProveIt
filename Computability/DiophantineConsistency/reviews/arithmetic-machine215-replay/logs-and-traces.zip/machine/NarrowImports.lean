import Foundation.FirstOrder.Arithmetic.HFS.PRF
import Mathlib.Data.Fin.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
set_option Elab.async false
example (f : ℕ → ℕ) (j : ℕ) : (∑ k ∈ Finset.range (j+1), f k) = (∑ k ∈ Finset.range j, f k) + f j := by
  simp only [Finset.sum_range_succ]
example (f : ℕ → ℕ) (j : ℕ) : (∏ k ∈ Finset.range (j+1), f k) = (∏ k ∈ Finset.range j, f k) * f j := by
  simp only [Finset.prod_range_succ]
example : ∀ q : Fin 215, q.val < 215 := by decide +kernel
#check Equiv
#check Int.toNat
