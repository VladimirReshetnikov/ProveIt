from pathlib import Path
import subprocess,time,json,hashlib,sys
p=Path('/tmp/nine-polynomial-map-20261028'); mode=sys.argv[1]; pre='Computability/DiophantineConsistency/Lean/'
if mode=='prepare':
 g=json.loads((p/'graph-before.json').read_text())['project_import_edges']; z=pre+'DiophantineConsistency/'; a={z+'SidonPositions.lean',z+'PolynomialRangeBounds.lean'}
 while True:
  b=a|{s for s,ds in g.items() if a.intersection(ds)}
  if b==a:break
  a=b
 seen=set();order=[]
 def visit(v):
  if v in seen:return
  seen.add(v)
  for d in g[v]:
   if d in a:visit(d)
  order.append(v)
 for v in sorted(a):visit(v)
 aroots={z+'NativeNinePolynomial52.lean',z+'NativeNineEquation52.lean',pre+'checks/NativeNinePolynomial52.lean'}
 items=[(Path(s).stem,s,True) for s in order if s not in aroots]
 for name,source,obj in items:
  out=p/'overlay/DiophantineConsistency'/(name+'.olean')
  assert out.is_symlink();out.unlink()
else:
 items=[('target',pre+'DiophantineConsistency/NativeNinePolynomial52.lean',True),('axioms',str(p/'axioms.lean'),False)]
 if mode=='final':items += [('focus',pre+'checks/NativeNinePolynomial52.lean',False),('client',pre+'DiophantineConsistency/NativeNineEquation52.lean',False)]
records=[]
for name,source,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency'/(name+'.olean' if mode=='prepare' else 'NativeNinePolynomial52.olean'))]
 timing=p/(mode+'-'+name+'.time');cmd=['/usr/bin/time','-v','-o',str(timing),'lake','env','bash','-c','export LEAN_PATH="/tmp/nine-polynomial-map-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True); elapsed=time.monotonic()-start;log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 q=Path(source); rec={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'source':source,'source_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'time':str(timing),'time_sha256':hashlib.sha256(timing.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  o=Path(argv[-1]);rec['object']=str(o);rec['object_sha256']=hashlib.sha256(o.read_bytes()).hexdigest();rec['object_bytes']=o.stat().st_size
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 print(mode,name,r.returncode,round(elapsed,2),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
