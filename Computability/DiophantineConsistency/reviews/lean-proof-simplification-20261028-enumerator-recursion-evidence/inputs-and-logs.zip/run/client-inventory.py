from pathlib import Path
import re,json,hashlib
R=Path('/tmp/enumerator-recursor-sharing');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('Computability/HilbertTenthProblem/Lean')];ov=R/'final';H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();seen={}
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');src=next((r/(rel+'.lean') for r in roots if (r/(rel+'.lean')).exists()),None)
 if not src:return
 ds=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:ds+=m.group(1).split()
 local=[a for a in ds if any((r/(a.replace('.','/')+'.lean')).exists() for r in roots)];o=ov/(rel+'.olean');v={'source':str(src.resolve()),'source_sha256':H(src),'imports':local}
 if o.exists():v.update(object=str(o.resolve()),object_sha256=H(o),source_mtime=src.stat().st_mtime,object_mtime=o.stat().st_mtime)
 seen[n]=v
 for a in local:visit(a)
for n in ['Bridge','ExplicitZFC','GraphSizeBounds','NativeZFC']:visit('DiophantineConsistency.'+n)
(R/'client-inventory.json').write_text(json.dumps(seen,indent=2)+'\n');missing=[n for n,v in seen.items() if 'object' not in v];older=[n for n,v in seen.items() if 'object' in v and v['source_mtime']>v['object_mtime']];print('nodes',len(seen),'missing',len(missing),'source-newer',len(older));print('missing',missing);print('source-newer',older)
