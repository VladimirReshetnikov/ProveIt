from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/enumerator-recursor-sharing');g=json.loads((R/'graph.json').read_text());skip={'DiophantineConsistency.DirectScalarEnumeratorCore','DiophantineConsistency.Computability','DiophantineConsistency.DirectScalarEnumerator','DiophantineConsistency.DirectGraphEnumerator','DiophantineConsistency.NativeGraphEnumerator'};ov=R/'common';env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env.get('LEAN_PATH','');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for n in g['order']:
 if n in skip:continue
 z=g['nodes'][n];source=Path(z['source']);obj=ov/(n.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);obj.unlink(missing_ok=True);root=next(x for x in ['Computability/DiophantineConsistency/Lean','Computability/BusyBeaver/Lean','Computability/HilbertTenthProblem/Lean'] if (Path(x)/(n.replace('.','/')+'.lean')).exists());tag=n.replace('.','_');log=R/('common-'+tag+'.log');tm=R/('common-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',root,str(source),'-o',str(obj)];before=H(source);start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'source_after':H(source),'log_sha256':H(log),'time_sha256':H(tm),'timing':tm.read_text().strip(),'object_sha256':H(obj) if obj.exists() else None};records.append(rec);(R/'common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode or rec['source_after']!=before:raise SystemExit(1)
print('common graph built',len(records),flush=True)
