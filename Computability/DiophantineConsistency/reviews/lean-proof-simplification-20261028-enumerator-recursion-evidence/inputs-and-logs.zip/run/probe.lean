import DiophantineConsistency.DirectScalarEnumeratorCore
namespace DiophantineConsistency.DirectEnumerator
open SetTheory SetTheory.BusyBeaver.ZFC EnumPerm Code254 KCode222

theorem boundedRun_rec_probe (n : ℕ) :
    Nat.rec (encodeOption (some initialState)) (fun _ acc => optionStep acc) n =
      encodeOption (boundedRun n initialState) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    change optionStep (Nat.rec _ _ n) = _
    rw [ih, optionStep_encode]
    change _ = encodeOption ((fun o : Option St => o.bind enumStep)^[n + 1] (some initialState))
    rw [Function.iterate_succ_apply']
    rfl
end DiophantineConsistency.DirectEnumerator
