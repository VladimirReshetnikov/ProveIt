from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/tmp/enumerator-recursor-sharing');W=Path('/home/codex/.codex/worktrees/62ff/Proofs');dest=W/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261028-enumerator-recursion-evidence';dest.mkdir(parents=True,exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest();files={}
def add(n,b):
 if n in files and files[n]!=b:raise ValueError('duplicate '+n)
 files[n]=b
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.lean','.py','.json','.log','.time'}:add('run/'+p.name,p.read_bytes())
for tree in ['baseline-source','source']:
 for p in sorted((R/tree).rglob('*.lean')):add('run/'+str(p.relative_to(R)),p.read_bytes())
inv=json.loads((R/'client-inventory.json').read_text());changed={'DiophantineConsistency.DirectScalarEnumeratorCore','DiophantineConsistency.DirectGraphEnumerator','DiophantineConsistency.NativeGraphEnumerator'}
for n,x in sorted(inv.items()):
 p=(R/'baseline-source/DiophantineConsistency'/(n.split('.')[-1]+'.lean')) if n in changed else Path(x['source']); b=p.read_bytes()
 if H(b)!=x['source_sha256']:raise ValueError('source hash mismatch '+n)
 add('sources/baseline/'+n.replace('.','/')+'.lean',b)
for n in sorted(changed):
 p=R/'source/DiophantineConsistency'/(n.split('.')[-1]+'.lean'); b=p.read_bytes();current=W/'Computability/DiophantineConsistency/Lean'/Path(n.replace('.','/')+'.lean')
 if current.read_bytes()!=b:raise ValueError('final source differs from committed source '+n)
 add('sources/final/'+n.replace('.','/')+'.lean',b)
for p in [W/'Computability/DiophantineConsistency/Lean/checks/EnumeratorCompatibility.lean',W/'lean-toolchain',W/'lakefile.toml',W/'lake-manifest.json']:
 add('context/'+str(p.relative_to(W)),p.read_bytes())
zip_path=dest/'inputs-and-logs.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(zip_path) as z:
 if z.testzip() is not None:raise ValueError('archive CRC failure')
 if len(z.namelist())!=len(files) or len(set(z.namelist()))!=len(files):raise ValueError('archive membership failure')
 for n,b in files.items():
  if H(z.read(n))!=H(b):raise ValueError('member hash mismatch '+n)
manifest={
 'schema':'enumerator-recursion-evidence-v1',
 'change_commit':'b22cefad65e80b4aade6abb70381782cd0f2b224',
 'baseline_commit':'2e5b3dba2eef0e7107810a8c7514716945f4d5a6',
 'lean_version':'Lean 4.32.0, commit 8c9756b28d64dab099da31a4c09229a9e6a2ef35, Release',
 'archive':{'file':'inputs-and-logs.zip','sha256':H(zip_path.read_bytes()),'bytes':zip_path.stat().st_size,'member_count':len(files)},
 'members':{n:{'sha256':H(b),'bytes':len(b)} for n,b in sorted(files.items())},
 'coverage':[
  'Both exact versions of the three edited sources, plus 234 baseline local project sources inventoried from the four broad client graphs, verified against the recorded source hashes.',
  '37 freshly built unchanged local prerequisites, five baseline/final target-chain modules, EnumeratorCompatibility, full-record rfl probes, named/generated equation and axiom census, and four preliminary broad clients.',
  '18 additional affected local prerequisites freshly built for GraphSizeBounds; each phase records 149 local dependency source/object paths and hashes. The two client logs match and only the three changed module object hashes differ.',
  'Archived scripts, logs, JSON records and timing files retain original absolute paths. Compiled object binaries are intentionally omitted; their hashes, selected paths and command receipts are included.'
 ],
 'caveats':[
  'Freshness checking identified FirstOrder.Fol as out of date; it lies outside the three inventoried project namespaces and remained a precompiled input. Unaffected local objects, Mathlib and other package objects also remain precompiled. This is not a full clean build.',
  'Bridge, ExplicitZFC and NativeZFC built in both phases using additional stale/precompiled inputs. Their successes are cache-bounded; only the affected local GraphSizeBounds slice was refreshed.',
  'A census of 256 old names finds 253 retained names, three removed unstable compiler-generated boundedRunProgram._proof_1 names, and one new shared theorem. Axiom output matches on all 253 retained names after equations for 108 definitions are materialized; the removed auxiliaries and new theorem report propext, Classical.choice and Quot.sound.',
  'The original axiom-check.py intentionally stops once the missing generated names are discovered. Its terminal failure output was not captured; script, names-difference.json and name-census logs preserve the cause, while axiom-check-v2.py checks the retained names and removed auxiliaries separately.',
  'The first dependency-refresh attempt was interrupted when requested, and a subsequent seed-count mismatch aborted the first restart. Their complete terminal outputs were not preserved; the recorded final coherent refresh and client builds succeeded.',
  'The shared fresh local prerequisite logs contain six existing TarskiComplete warnings and three NinePoly warnings; baseline and final target and GraphSizeBounds logs match. The baseline auxiliary axiom probe contains three Lean warnings about unstable generated names.',
  'The context copies of project configuration and EnumeratorCompatibility were collected when this bundle was created. The archived probe and source receipts record validation-time hashes where available; the presence of these context copies does not independently authenticate every package binary.',
  'Resource/timing measurements describe these individual runs only and are not controlled performance benchmarks.'
 ]}
(dest/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive_sha256':manifest['archive']['sha256'],'bytes':manifest['archive']['bytes'],'members':len(files),'manifest_sha256':H((dest/'BUNDLE.json').read_bytes())},indent=2))
