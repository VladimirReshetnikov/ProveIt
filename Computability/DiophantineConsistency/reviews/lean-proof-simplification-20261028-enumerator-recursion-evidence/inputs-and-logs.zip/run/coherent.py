from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/enumerator-recursor-sharing'); common=R/'common'; inv=json.loads((R/'client-inventory.json').read_text()); existing=json.loads((R/'common-records.json').read_text()); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); phase_names=['DirectScalarEnumeratorCore','Computability','DirectScalarEnumerator','DirectGraphEnumerator','NativeGraphEnumerator']; fresh={r['module'] for r in existing}|{'DiophantineConsistency.'+n for n in phase_names}|{'DiophantineConsistency.AffineBudget'}
seed={r['module'] for r in existing if H(Path('.lake/build/lib/lean')/(r['module'].replace('.','/')+'.olean')) != r['object_sha256']} | {n for n,x in inv.items() if x['source_mtime']>x['object_mtime']}
affected=set(seed)
while True:
 newer=affected | {n for n,x in inv.items() if any(d in affected for d in x['imports'])}
 if newer==affected: break
 affected=newer
seen=set();order=[]
def visit(n):
 if n in seen:return
 seen.add(n)
 for d in inv[n]['imports']: visit(d)
 order.append(n)
visit('DiophantineConsistency.GraphSizeBounds')
for n in seen:
 if H(inv[n]['source']) != inv[n]['source_sha256']: raise Exception('source changed '+n)
todo=[n for n in order if n in affected and n not in fresh and n!='DiophantineConsistency.GraphSizeBounds'];print('closure',len(seen),'seeds',len(seed),'refresh',len(todo),flush=True)
if len(todo)!=18:raise Exception('unexpected rebuild count '+str(todo))
env=os.environ.copy();env['LEAN_PATH']=str(common)+':'+env.get('LEAN_PATH','');records=[]
for n in todo:
 source=Path(inv[n]['source']);obj=common/(n.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);obj.unlink(missing_ok=True);root=next(x for x in ['Computability/DiophantineConsistency/Lean','Computability/BusyBeaver/Lean','Computability/HilbertTenthProblem/Lean'] if (Path(x)/(n.replace('.','/')+'.lean')).exists());tag=n.replace('.','_');log=R/('coherent-'+tag+'.log');tm=R/('coherent-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',root,str(source),'-o',str(obj)];pre=H(source);start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-start,'source_sha256':pre,'source_after':H(source),'log_sha256':H(log),'time_sha256':H(tm),'timing':tm.read_text().strip(),'object_sha256':H(obj) if obj.exists() else None};records.append(rec);(R/'coherent-common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode or rec['source_after']!=pre:raise SystemExit(1)
(R/'coherent-graph.json').write_text(json.dumps({'seeds':sorted(seed),'affected':sorted(affected),'closure':sorted(seen),'built':todo},indent=2)+'\n')
