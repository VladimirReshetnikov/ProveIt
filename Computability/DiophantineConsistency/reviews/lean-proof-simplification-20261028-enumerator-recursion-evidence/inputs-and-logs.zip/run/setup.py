from pathlib import Path
R=Path('/tmp/enumerator-recursor-sharing');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');names=['DirectScalarEnumeratorCore','DirectGraphEnumerator','NativeGraphEnumerator'];out=R/'source/DiophantineConsistency';base=R/'baseline-source/DiophantineConsistency';out.mkdir(parents=True,exist_ok=True);base.mkdir(parents=True,exist_ok=True)
old='''  intro n
  induction n with
  | zero => rfl
  | succ n ih =>
    change optionStep (Nat.rec _ _ n) = _
    rw [ih, optionStep_encode]
    change _ = encodeOption ((fun o : Option St => o.bind enumStep)^[n + 1] (some initialState))
    rw [Function.iterate_succ_apply']
    rfl'''
for n in names:
 s=(root/(n+'.lean')).read_text();(base/(n+'.lean')).write_text(s);p=s.index('def boundedRunProgram');pre=s[:p];post=s[p:];assert post.count(old)==1,n
 if n=='DirectScalarEnumeratorCore':
  lemma='''/-- The scalar iterator follows the literal bounded enumerator on every input. -/
theorem boundedRun_rec (n : ℕ) :
    Nat.rec (encodeOption (some initialState)) (fun _ acc => optionStep acc) n =
      encodeOption (boundedRun n initialState) := by
'''+old+'\n\n'
  lemma=lemma.replace('  intro n\n  induction n with','  induction n with',1);s=pre+lemma+post.replace(old,'  exact boundedRun_rec',1)
 else:s=pre+post.replace(old,'  exact DirectEnumerator.boundedRun_rec',1)
 (out/(n+'.lean')).write_text(s)
print('snapshots created')
