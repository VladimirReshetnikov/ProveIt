from pathlib import Path
import os,subprocess,time,json,hashlib,re
R=Path('/tmp/enumerator-recursor-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
def run(phase,tag,p):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+env.get('LEAN_PATH','');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(R/(phase+'-'+tag+'.time')),'lean','-M9000','-j1','-DElab.async=false',str(p)];log=R/(phase+'-'+tag+'.log');start=time.monotonic();before=h(p)
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'tag':tag,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'log_sha256':h(log),'timing':(R/(phase+'-'+tag+'.time')).read_text().strip()};records.append(rec);(R/'axiom-v2-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,q.returncode,flush=True)
 if q.returncode:raise SystemExit(1)
a=set(re.findall(r'^CENSUS (\S+)',(R/'baseline-names.log').read_text(),re.M));b=set(re.findall(r'^CENSUS (\S+)',(R/'final-names.log').read_text(),re.M));expected={'DiophantineConsistency.'+ns+'.boundedRunProgram._proof_1' for ns in ['DirectEnumerator','DirectGraphEnumerator','NativeGraphEnumerator']};assert a-b==expected and b-a=={'DiophantineConsistency.DirectEnumerator.boundedRun_rec'}
materialize='\n'.join(l for l in (R/'Names.lean').read_text().splitlines() if l.startswith('#print equations '))
s='import DiophantineConsistency.NativeGraphEnumerator\n'+materialize+'\nopen Lean Elab Command\nrun_cmd logInfo "AXIOMS_BEGIN"\n'+''.join('#print axioms '+n+'\n' for n in sorted(a & b));(R/'AxiomsCommon.lean').write_text(s)
for phase in ['baseline','final']:run(phase,'axioms-common',R/'AxiomsCommon.lean')
logs=[(R/(p+'-axioms-common.log')).read_text().split('AXIOMS_BEGIN\n',1)[1] for p in ['baseline','final']];print('common axiom outputs match',logs[0]==logs[1],flush=True)
if logs[0]!=logs[1]:raise SystemExit(2)
(R/'OldAux.lean').write_text('import DiophantineConsistency.NativeGraphEnumerator\n'+''.join('#print axioms '+n+'\n' for n in sorted(expected)))
(R/'NewHelper.lean').write_text('import DiophantineConsistency.DirectScalarEnumeratorCore\n#print axioms DiophantineConsistency.DirectEnumerator.boundedRun_rec\n')
run('baseline','old-aux',R/'OldAux.lean');run('final','new-helper',R/'NewHelper.lean')
print('common reports',len(a&b),flush=True)
