import DiophantineConsistency.NativeGraphEnumerator
open SetTheory SetTheory.BusyBeaver.ZFC EnumPerm Code254 KCode222

namespace DiophantineConsistency.DirectEnumerator
open ScalarPRCode DirectScalar
def oldBoundedRunProgram : R (fun n => encodeOption (boundedRun n initialState)) := by
  refine (iterate optionStepProgram (encodeOption (some initialState))).ofEq ?_
  intro n
  induction n with
  | zero => rfl
  | succ n ih =>
    change optionStep (Nat.rec _ _ n) = _
    rw [ih, optionStep_encode]
    change _ = encodeOption ((fun o : Option St => o.bind enumStep)^[n + 1] (some initialState))
    rw [Function.iterate_succ_apply']
    rfl

example : oldBoundedRunProgram = boundedRunProgram := by rfl
end DiophantineConsistency.DirectEnumerator

namespace DiophantineConsistency.DirectGraphEnumerator
open DirectEnumerator
def oldBoundedRunProgram : R (fun n => encodeOption (boundedRun n initialState)) := by
  refine ofEq (iterate optionStepProgram (encodeOption (some initialState))) ?_
  intro n
  induction n with
  | zero => rfl
  | succ n ih =>
    change optionStep (Nat.rec _ _ n) = _
    rw [ih, optionStep_encode]
    change _ = encodeOption ((fun o : Option St => o.bind enumStep)^[n + 1] (some initialState))
    rw [Function.iterate_succ_apply']
    rfl

example : oldBoundedRunProgram = boundedRunProgram := by rfl
end DiophantineConsistency.DirectGraphEnumerator

namespace DiophantineConsistency.NativeGraphEnumerator
open DirectGraphEnumerator (R ofEq identity constant successor add sub iterate)
open DirectEnumerator (encodeState decodeState encodeOption rawStep rawStep_eq optionStep optionStep_encode)
def oldBoundedRunProgram : R (fun n => encodeOption (boundedRun n initialState)) := by
  refine ofEq (iterate optionStepProgram (encodeOption (some initialState))) ?_
  intro n
  induction n with
  | zero => rfl
  | succ n ih =>
    change optionStep (Nat.rec _ _ n) = _
    rw [ih, optionStep_encode]
    change _ = encodeOption ((fun o : Option St => o.bind enumStep)^[n + 1] (some initialState))
    rw [Function.iterate_succ_apply']
    rfl

example : oldBoundedRunProgram = boundedRunProgram := by rfl
end DiophantineConsistency.NativeGraphEnumerator
