from pathlib import Path
import re,json,hashlib
R=Path('/tmp/enumerator-recursor-sharing');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('Computability/HilbertTenthProblem/Lean')];lib=Path('.lake/build/lib/lean');seen={};order=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');src=next((r/(rel+'.lean') for r in roots if (r/(rel+'.lean')).exists()),None)
 if src is None:return
 ds=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:ds.extend(m.group(1).split())
 local=[d for d in ds if any((r/(d.replace('.','/')+'.lean')).exists() for r in roots)];obj=lib/(rel+'.olean');v={'source':str(src),'source_sha256':sha(src),'imports':ds,'local_imports':local}
 if obj.exists():v.update(object=str(obj.resolve()),object_sha256=sha(obj),source_mtime=src.stat().st_mtime,object_mtime=obj.stat().st_mtime)
 seen[n]=v
 for d in local:visit(d)
 order.append(n)
for n in ['DirectScalarEnumeratorCore','DirectGraphEnumerator','NativeGraphEnumerator']:visit('DiophantineConsistency.'+n)
(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n');missing=[n for n,x in seen.items() if 'object' not in x];older=[n for n,x in seen.items() if 'object' in x and x['source_mtime']>x['object_mtime']];print('nodes',len(seen),'missing',len(missing),'source newer',len(older));print('missing',missing);print('source newer',older)
