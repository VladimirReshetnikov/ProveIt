from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/enumerator-recursor-sharing');common=R/'common';inv=json.loads((R/'client-inventory.json').read_text());graph=json.loads((R/'coherent-graph.json').read_text());H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();targets=['DirectScalarEnumeratorCore','Computability','DirectScalarEnumerator','DirectGraphEnumerator','NativeGraphEnumerator'];root=Path('Computability/DiophantineConsistency/Lean');records=[]
for phase in ['baseline','final']:
 ov=R/(phase+'-coherent');dc=ov/'DiophantineConsistency';dc.mkdir(parents=True,exist_ok=True)
 for p in (common/'DiophantineConsistency').rglob('*.olean'):
  q=dc/p.relative_to(common/'DiophantineConsistency');q.parent.mkdir(parents=True,exist_ok=True);q.unlink(missing_ok=True);q.symlink_to(p.resolve())
 for n in targets:
  p=R/phase/'DiophantineConsistency'/(n+'.olean');q=dc/p.name;q.unlink(missing_ok=True);q.symlink_to(p.resolve())
 for ns in ['BusyBeaver','Diophantine']:
  q=ov/ns;q.unlink(missing_ok=True);q.symlink_to((common/ns).resolve(),target_is_directory=True)
 src=root/'DiophantineConsistency/GraphSizeBounds.lean';out=dc/'GraphSizeBounds.olean';out.unlink(missing_ok=True)
 deps={}
 for n in graph['closure']:
  if n=='DiophantineConsistency.GraphSizeBounds':continue
  source=Path(inv[n]['source']);obj=ov/(n.replace('.','/')+'.olean')
  if H(source)!=inv[n]['source_sha256']:raise Exception('source changed '+n)
  if n in {'DiophantineConsistency.DirectScalarEnumeratorCore','DiophantineConsistency.DirectGraphEnumerator','DiophantineConsistency.NativeGraphEnumerator'}:
   source=R/('baseline-source' if phase=='baseline' else 'source')/'DiophantineConsistency'/(n.split('.')[-1]+'.lean')
  if not obj.exists():raise Exception('missing object '+n)
  deps[n]={'source':str(source),'source_sha256':H(source),'object':str(obj.resolve()),'object_sha256':H(obj)}
 env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env.get('LEAN_PATH','');log=R/(phase+'-coherent-GraphSizeBounds.log');tm=R/(phase+'-coherent-GraphSizeBounds.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];before=H(src);start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'source_after':H(src),'log_sha256':H(log),'time_sha256':H(tm),'timing':tm.read_text().strip(),'object_sha256':H(out) if out.exists() else None,'dependencies':deps};records.append(rec);(R/'coherent-client-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,'GraphSizeBounds',r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode or before != H(src):raise SystemExit(1)
 for n,z in deps.items():
  if H(z['source'])!=z['source_sha256'] or H(z['object'])!=z['object_sha256']:raise Exception('dependency changed '+n)
