import pathlib,json,hashlib
P=pathlib.Path('/tmp/enumerator-recursor-sharing');H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for fn in ['common-records.json','phase-records.json','axiom-records.json','axiom-v2-records.json','coherent-common-records.json','coherent-client-records.json']:
 rs=json.loads((P/fn).read_text());bad=[]
 for r in rs:
  cmd=r.get('cmd',r.get('command'));tag=r.get('tag',r.get('module',r.get('phase')));src=[x for x in cmd if x.endswith('.lean')];assert len(src)==1,(fn,tag,src);time=pathlib.Path(cmd[4]);log=time.with_suffix('.log')
  if H(src[0])!=r['source_sha256'] or ('source_after' in r and r['source_sha256']!=r['source_after']):bad.append((tag,'source'))
  if H(log)!=r['log_sha256']:bad.append((tag,'log'))
  if time.read_text().strip()!=r['timing'].strip():bad.append((tag,'timing'))
  if 'time_sha256' in r and H(time)!=r['time_sha256']:bad.append((tag,'time sha'))
  if r.get('object_sha256'):
   if cmd[-2]!='-o' or H(cmd[-1])!=r['object_sha256']:bad.append((tag,'object'))
   if 'object_bytes' in r and pathlib.Path(cmd[-1]).stat().st_size!=r['object_bytes']:bad.append((tag,'bytes'))
  if r['status']!=0:bad.append((tag,'status'))
 print(fn,len(rs),'bad',bad)
