from pathlib import Path
import os,re,json,hashlib,subprocess,time
R=Path('/tmp/enumerator-recursor-sharing');common=R/'common';root=Path('Computability/DiophantineConsistency/Lean');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[];targets=['DirectScalarEnumeratorCore','Computability','DirectScalarEnumerator','DirectGraphEnumerator','NativeGraphEnumerator']; clients=['Bridge','ExplicitZFC','GraphSizeBounds','NativeZFC']
for ns in ['BusyBeaver','Diophantine','DiophantineConsistency']:
 source=Path('.lake/build/lib/lean')/ns;dest=common/ns
 if not source.exists():continue
 for p in source.rglob('*.olean'):
  d=dest/p.relative_to(source)
  if ns=='DiophantineConsistency' and p.stem in targets+clients:continue
  if not d.exists() and not d.is_symlink():d.parent.mkdir(parents=True,exist_ok=True);d.symlink_to(p.resolve())
for phase in ['baseline','final']:
 d=R/phase/'DiophantineConsistency';d.mkdir(parents=True,exist_ok=True)
 for p in (common/'DiophantineConsistency').iterdir():
  if p.suffix=='.olean' and p.stem not in targets+clients:
   q=d/p.name
   if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 for ns in ['BusyBeaver','Diophantine']:
  q=R/phase/ns
  if not q.exists() and not q.is_symlink():q.symlink_to((common/ns).resolve(),target_is_directory=True)
def run(phase,tag,source,srcroot,output=None,required=True):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+env.get('LEAN_PATH','');log=R/(phase+'-'+tag+'.log');tm=R/(phase+'-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(srcroot),str(source)]
 if output is not None:output.unlink(missing_ok=True);cmd+=['-o',str(output)]
 pre=h(source);start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'tag':tag,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-start,'source_sha256':pre,'source_after':h(source),'log_sha256':h(log),'time_sha256':h(tm),'timing':tm.read_text().strip()}
 if output is not None and output.exists():rec.update(object_sha256=h(output),object_bytes=output.stat().st_size)
 records.append(rec);(R/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,r.returncode,round(rec['seconds'],2),flush=True)
 if required and (r.returncode or rec['source_after']!=pre):raise SystemExit(1)
 return r.returncode
run('shared','AffineBudget',root/'DiophantineConsistency/AffineBudget.lean',root,common/'DiophantineConsistency/AffineBudget.olean')
for phase in ['baseline','final']:
 q=R/phase/'DiophantineConsistency/AffineBudget.olean'
 if not q.exists() and not q.is_symlink():q.symlink_to((common/'DiophantineConsistency/AffineBudget.olean').resolve())
for phase in ['baseline','final']:
 srcroot=R/('baseline-source' if phase=='baseline' else 'source')
 for n in targets:
  src=(srcroot if n in ['DirectScalarEnumeratorCore','DirectGraphEnumerator','NativeGraphEnumerator'] else root)/'DiophantineConsistency'/(n+'.lean');rroot=srcroot if n in ['DirectScalarEnumeratorCore','DirectGraphEnumerator','NativeGraphEnumerator'] else root
  run(phase,n,src,rroot,R/phase/'DiophantineConsistency'/(n+'.olean'))
 run(phase,'defeq',R/'defeq.lean',R)
 run(phase,'EnumeratorCompatibility',root/'checks/EnumeratorCompatibility.lean',root)
 for n in clients:run(phase,'client-'+n,root/'DiophantineConsistency'/(n+'.lean'),root,R/phase/'DiophantineConsistency'/(n+'.olean'),required=False)
print('phase builds complete',flush=True)
