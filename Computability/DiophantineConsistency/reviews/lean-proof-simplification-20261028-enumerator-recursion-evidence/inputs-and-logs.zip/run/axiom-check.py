from pathlib import Path
import os,subprocess,time,json,hashlib,re
R=Path('/tmp/enumerator-recursor-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
def run(phase,tag,p):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+env.get('LEAN_PATH','');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(R/(phase+'-'+tag+'.time')),'lean','-M9000','-j1','-DElab.async=false',str(p)];log=R/(phase+'-'+tag+'.log');start=time.monotonic();before=h(p)
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'tag':tag,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'log_sha256':h(log),'timing':(R/(phase+'-'+tag+'.time')).read_text().strip()};records.append(rec);(R/'axiom-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,q.returncode,flush=True)
 if q.returncode:raise SystemExit(1)
for phase in ['baseline','final']:run(phase,'names',R/'Names.lean')
a=set(re.findall(r'^CENSUS (\S+)',(R/'baseline-names.log').read_text(),re.M));b=set(re.findall(r'^CENSUS (\S+)',(R/'final-names.log').read_text(),re.M));print('old',len(a),'new',len(b),'added',sorted(b-a),'removed',sorted(a-b),flush=True)
(R/'names-difference.json').write_text(json.dumps({'old_count':len(a),'new_count':len(b),'added':sorted(b-a),'removed':sorted(a-b)},indent=2)+'\n')
if a-b:raise SystemExit('old public names missing')
materialize='\n'.join(l for l in (R/'Names.lean').read_text().splitlines() if l.startswith('#print equations '))
s='import DiophantineConsistency.NativeGraphEnumerator\n'+materialize+'\n'+''.join('#print axioms '+n+'\n' for n in sorted(a))
(R/'AxiomsAll.lean').write_text(s)
for phase in ['baseline','final']:run(phase,'axioms',R/'AxiomsAll.lean')
a=(R/'baseline-axioms.log').read_bytes();b=(R/'final-axioms.log').read_bytes();print('full axioms-and-equations logs equal:',a==b,flush=True)
if a!=b:raise SystemExit(2)
(R/'NewHelper.lean').write_text('import DiophantineConsistency.DirectScalarEnumeratorCore\n#print axioms DiophantineConsistency.DirectEnumerator.boundedRun_rec\n')
run('final','new-helper',R/'NewHelper.lean')
