from pathlib import Path
import json,os,hashlib,subprocess,time
R=Path('/tmp/enumerator-firstorder-refresh');pinned=json.loads((R/'pinned-records.json').read_text());extern=json.loads((R/'external-object-receipts.json').read_text())['modules'];H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 prev=next(r for r in pinned if r['phase']==phase and r['tag']=='GraphSizeBounds');deps=prev['dependencies']
 for d in deps.values():
  if H(d['source_path'])!=d['source_sha256'] or H(d['object_path'])!=d['object_sha256']:raise Exception('local input changed')
 for n,d in extern.items():
  if H(d['object_path'])!=d['object_sha256']:raise Exception('external object changed '+n)
 src=Path(prev['source_path']);out=R/(phase+'-fully-pinned-GraphSizeBounds.olean');out.unlink(missing_ok=True);log=R/(phase+'-fully-pinned-GraphSizeBounds.log');tm=R/(phase+'-fully-pinned-GraphSizeBounds.time');env=os.environ.copy();env['LEAN_PATH']=prev['lean_path'];cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(out)];start=time.monotonic();before=H(src)
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps.values():
  if H(d['source_path'])!=d['source_sha256'] or H(d['object_path'])!=d['object_sha256']:raise Exception('local input changed during build')
 for n,d in extern.items():
  if H(d['object_path'])!=d['object_sha256']:raise Exception('external object changed during build '+n)
 rec={'phase':phase,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'source_after':H(src),'object_sha256':H(out) if out.exists() else None,'log_sha256':H(log),'time_sha256':H(tm),'timing':tm.read_text().strip(),'local_dependencies':deps,'direct_external_dependencies':extern};records.append(rec);(R/'fully-pinned-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,'GraphSizeBounds',r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode or before!=H(src):raise SystemExit(1)
