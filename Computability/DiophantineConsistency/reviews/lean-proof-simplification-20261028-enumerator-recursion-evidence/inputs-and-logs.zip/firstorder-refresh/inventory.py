import re,json,hashlib,tomllib
from pathlib import Path
R=Path('/tmp/enumerator-firstorder-refresh');W=Path.cwd();config=tomllib.loads((W/'lakefile.toml').read_text());roots=[]
for v in config['lean_lib']:
 p=(W/v.get('srcDir','.')).resolve()
 if p not in roots:roots.append(p)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();seen={};external={};order=[]
def visit(n):
 if n in seen or n in external:return
 rel=Path(n.replace('.','/')+'.lean');hits=[r/rel for r in roots if (r/rel).exists()];hits=list(dict.fromkeys(p.resolve() for p in hits))
 if not hits:external[n]=True;return
 if len(hits)!=1:raise Exception('Ambiguous source '+n+' '+str(hits))
 src=hits[0];imports=[]
 for l in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',l)
  if m:imports.extend(m.group(1).split())
 obj=W/'.lake/build/lib/lean'/Path(n.replace('.','/')+'.olean');z={'source':str(src),'source_sha256':H(src),'imports':imports}
 if obj.exists():z.update(object=str(obj.resolve()),object_sha256=H(obj),source_mtime=src.stat().st_mtime,object_mtime=obj.stat().st_mtime)
 seen[n]=z
 for d in imports:visit(d)
 order.append(n)
visit('DiophantineConsistency.GraphSizeBounds')
if 'FirstOrder.Fol' not in seen:raise Exception('FirstOrder.Fol absent')
affected={'FirstOrder.Fol'}
for n in order:
 if any(i in affected for i in seen[n]['imports']):affected.add(n)
missing=[n for n in seen if 'object' not in seen[n]];print('local',len(seen),'external',len(external),'affected',len(affected),'missing',len(missing),flush=True);print('affected topological',*[n for n in order if n in affected],sep='\n',flush=True)
(R/'inventory.json').write_text(json.dumps({'nodes':seen,'external':sorted(external),'order':order,'affected':sorted(affected),'missing':missing},indent=2)+'\n')
