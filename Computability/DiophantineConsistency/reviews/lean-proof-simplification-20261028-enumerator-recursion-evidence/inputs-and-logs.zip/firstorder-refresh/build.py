from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/enumerator-firstorder-refresh');P=Path('/tmp/enumerator-recursor-sharing');g=json.loads((R/'inventory.json').read_text());H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();common=R/'common';common.mkdir(exist_ok=True);phasenames={'DiophantineConsistency.'+n for n in ['DirectScalarEnumeratorCore','Computability','DirectScalarEnumerator','DirectGraphEnumerator','NativeGraphEnumerator','GraphSizeBounds']};changed={'DiophantineConsistency.'+n for n in ['DirectScalarEnumeratorCore','DirectGraphEnumerator','NativeGraphEnumerator']};order=[n for n in g['order'] if n in set(g['affected'])];shared=[n for n in order if n not in phasenames]; assert len(shared)==13 and len(order)==19;records=[]
def build(n,phase,ov,base):
 src=Path(g['nodes'][n]['source']);root=next(p for p in [Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('Computability/HilbertTenthProblem/Lean'),Path('Logic/FirstOrder/Lean')] if (p/(n.replace('.','/')+'.lean')).exists())
 if n in changed:
  root=P/('baseline-source' if phase=='baseline' else 'source');src=root/(n.replace('.','/')+'.lean')
 obj=ov/(n.replace('.','/')+'.olean');obj.parent.mkdir(parents=True,exist_ok=True);obj.unlink(missing_ok=True);tag=phase+'-'+n.replace('.','_');log=R/(tag+'.log');tm=R/(tag+'.time');env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+(str(common)+':' if ov!=common else '')+str(base)+':'+env.get('LEAN_PATH','');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];before=H(src);start=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'module':n,'phase':phase,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-start,'source_path':str(src.resolve()),'source_sha256':before,'source_after':H(src),'log_path':str(log),'log_sha256':H(log),'time_path':str(tm),'time_sha256':H(tm),'timing':tm.read_text().strip(),'object_path':str(obj),'object_sha256':H(obj) if obj.exists() else None,'object_bytes':obj.stat().st_size if obj.exists() else None};records.append(rec);(R/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,round(rec['seconds'],1),flush=True)
 if r.returncode or rec['source_after']!=before:raise SystemExit(1)
# Populate namespace overlays with symlinks; Lean resolves a namespace in one search root.
base=P/'baseline-coherent'
for ns in ['BusyBeaver','DiophantineConsistency']:
 src=base/ns;dst=common/ns;dst.mkdir(parents=True,exist_ok=True)
 for p in src.rglob('*.olean'):
  q=dst/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True)
  if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
q=common/'Diophantine'
if not q.exists() and not q.is_symlink():q.symlink_to((base/'Diophantine').resolve(),target_is_directory=True)
for n in shared:build(n,'shared',common,base)
for phase in ['baseline','final']:
 ov=R/phase;base=P/(phase+'-coherent');ov.mkdir(exist_ok=True)
 for ns in ['BusyBeaver','Diophantine','FirstOrder']:
  q=ov/ns
  if not q.exists() and not q.is_symlink():q.symlink_to((common/ns).resolve(),target_is_directory=True)
 src=common/'DiophantineConsistency';dst=ov/'DiophantineConsistency';dst.mkdir(parents=True,exist_ok=True)
 for p in src.rglob('*.olean'):
  q=dst/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True)
  if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
 for n in phasenames:
  p=base/(n.replace('.','/')+'.olean');q=ov/(n.replace('.','/')+'.olean');q.unlink(missing_ok=True);q.symlink_to(p.resolve())
 for n in [n for n in order if n in phasenames]:build(n,phase,ov,base)
print('all first-order affected builds complete',flush=True)
