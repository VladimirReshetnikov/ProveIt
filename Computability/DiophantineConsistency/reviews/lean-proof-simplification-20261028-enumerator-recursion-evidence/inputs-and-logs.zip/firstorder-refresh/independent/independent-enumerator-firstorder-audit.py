from pathlib import Path
import hashlib,json,re,tomllib
R=Path('/tmp/enumerator-firstorder-refresh');W=Path.cwd();g=json.load(open(R/'inventory.json'));fail=[];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();roots=[]
for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']:
 p=(W/x.get('srcDir','.')).resolve()
 if p not in roots:roots.append(p)
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(p):
 return [n for line in strip(Path(p).read_text()).splitlines() for m in [re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)] if m for n in m.group(1).split()]
seen={};external=set();order=[]
def visit(n):
 if n in seen or n in external:return
 hits=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).exists()))
 if not hits:external.add(n);return
 if len(hits)!=1:fail.append('ambiguous '+n);return
 p=hits[0];im=imports(p);seen[n]={'source':str(p),'source_sha256':h(p),'imports':im}
 for d in im:visit(d)
 order.append(n)
visit('DiophantineConsistency.GraphSizeBounds')
if set(seen)!=set(g['nodes']):fail.append('node mismatch '+str(set(seen)^set(g['nodes'])))
if external!=set(g['external']):fail.append('external mismatch '+str(external^set(g['external'])))
for n,x in seen.items():
 v=g['nodes'].get(n,{})
 if any(x[k]!=v.get(k) for k in ['source','source_sha256','imports']):fail.append('inventory source/import mismatch '+n)
affected={'FirstOrder.Fol'}
for n in order:
 if any(i in affected for i in seen[n]['imports']):affected.add(n)
if affected!=set(g['affected']):fail.append('affected mismatch '+str(affected^set(g['affected'])))
changed=['DirectScalarEnumeratorCore','DirectGraphEnumerator','NativeGraphEnumerator']
for phase in ['baseline','final']:
 for n in changed:
  name='DiophantineConsistency.'+n;p=Path('/tmp/enumerator-recursor-sharing')/('baseline-source' if phase=='baseline' else 'source')/'DiophantineConsistency'/(n+'.lean')
  if imports(p)!=seen[name]['imports']:fail.append('phase imports differ '+phase+' '+name)
for x in json.load(open(R/'records.json'))+json.load(open(R/'pinned-records.json')):
 if x['status']!=0:fail.append('failed record '+str(x))
 for p,k in [('source_path','source_sha256'),('log_path','log_sha256'),('time_path','time_sha256'),('object_path','object_sha256'),('output_object_path','output_object_sha256')]:
  if x.get(p) and x.get(k) and (not Path(x[p]).is_file() or h(x[p])!=x[k]):fail.append('mismatch '+x.get('module',x.get('tag','?'))+' '+p)
 if x['source_sha256']!=x['source_after']:fail.append('source changed '+str(x))
 if Path(x['time_path']).read_text().strip()!=x['timing']:fail.append('timing mismatch '+str(x))
 if x['command'][x['command'].index('-o')+1]!=x['time_path']:fail.append('command time path '+str(x))
 if str(x['source_path']) not in [str(Path(y).resolve()) for y in x['command'] if y.endswith('.lean')]:fail.append('command source path '+str(x))
for x in json.load(open(R/'fully-pinned-records.json')):
 ph=x['phase'];cmd=x['command'];out=Path(cmd[cmd.index('-o',cmd.index('lean')+1)+1]);log=R/(ph+'-fully-pinned-GraphSizeBounds.log');tm=R/(ph+'-fully-pinned-GraphSizeBounds.time');src=Path(cmd[cmd.index('-R')+2]);
 for p,k in [(src,'source_sha256'),(out,'object_sha256'),(log,'log_sha256'),(tm,'time_sha256')]:
  if not p.is_file() or h(p)!=x[k]:fail.append('fully pinned '+ph+' '+k)
 if x['status'] or x['source_sha256']!=x['source_after'] or tm.read_text().strip()!=x['timing']:fail.append('fully pinned status '+ph)
 if set(x['local_dependencies'])!=set(seen) or set(x['direct_external_dependencies'])!=external:fail.append('dependency coverage '+ph)
 for n,d in x['local_dependencies'].items():
  for p,k in [('source_path','source_sha256'),('object_path','object_sha256')]:
   if not Path(d[p]).is_file() or h(d[p])!=d[k]:fail.append('local pin '+ph+' '+n+' '+p)
  selected=R/ph/(n.replace('.','/')+'.olean')
  if not selected.is_file() or selected.resolve()!=Path(d['object_path']).resolve() or h(selected)!=d['object_sha256']:fail.append('local selected '+ph+' '+n)
  if d['imports']!=seen[n]['imports']:fail.append('local imports '+ph+' '+n)
 for n,d in x['direct_external_dependencies'].items():
  if not Path(d['object_path']).is_file() or h(d['object_path'])!=d['object_sha256']:fail.append('external hash '+ph+' '+n)
  possible=[Path(q)/(n.replace('.','/')+'.olean') for q in x['lean_path'].split(':') if q]
  candidate=next((p.resolve() for p in possible if p.is_file()),None)
  if candidate!=Path(d['object_path']).resolve():fail.append('external selected '+ph+' '+n)
records=json.load(open(R/'records.json'));want=[n for n in order if n in affected];shared=[x['module'] for x in records if x['phase']=='shared'];bp=[x['module'] for x in records if x['phase']=='baseline'];fp=[x['module'] for x in records if x['phase']=='final']
if len(shared)!=13 or len(bp)!=6 or bp!=fp or set(shared+bp)!=affected or [n for n in want if n in shared]!=shared or [n for n in want if n in bp]!=bp:fail.append('build closure/order mismatch')
for tag in ['defeq','EnumeratorCompatibility']:
 if (R/('baseline-pinned-'+tag+'.log')).read_bytes()!=(R/('final-pinned-'+tag+'.log')).read_bytes():fail.append('paired log mismatch '+tag)
for tag in ['DirectScalarEnumeratorCore','Computability','DirectScalarEnumerator','DirectGraphEnumerator','NativeGraphEnumerator','GraphSizeBounds']:
 a=(R/('baseline-DiophantineConsistency_'+tag+'.log')).read_text();b=(R/('final-DiophantineConsistency_'+tag+'.log')).read_text()
 if a!=b:fail.append('paired phase output mismatch '+tag)
print('independent graph:',len(seen),'nodes',len(external),'external',len(affected),'affected; records',len(records),'pinned',8,'fully-pinned',2,'failures',len(fail));print('\n'.join(fail));

a=(R/'baseline-pinned-axioms-common.log').read_text();b=(R/'final-pinned-axioms-common.log').read_text();start="'DiophantineConsistency.DirectEnumerator.boundedRunProgram' depends on axioms:"
if a[a.index(start):]!=b[b.index(start):]:raise SystemExit('axiom suffix mismatch')
print('axiom suffix identical, reports',a[a.index(start):].count('depends on axioms:')+a[a.index(start):].count('does not depend on any axioms'),'warnings',a.count('warning:'),b.count('warning:'))
if fail:raise SystemExit(1)
