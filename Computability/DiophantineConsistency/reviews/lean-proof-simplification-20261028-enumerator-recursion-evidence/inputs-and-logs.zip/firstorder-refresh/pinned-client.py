from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/enumerator-firstorder-refresh');P=Path('/tmp/enumerator-recursor-sharing');g=json.loads((R/'inventory.json').read_text());H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();changed={'DiophantineConsistency.'+n for n in ['DirectScalarEnumeratorCore','DirectGraphEnumerator','NativeGraphEnumerator']};records=[]
for phase in ['baseline','final']:
 ov=R/phase;deps={}
 for n,v in g['nodes'].items():
  src=Path(v['source']);
  if H(src)!=v['source_sha256']:raise Exception('source changed after inventory '+n)
  if n in changed:src=P/('baseline-source' if phase=='baseline' else 'source')/Path(n.replace('.','/')+'.lean')
  obj=ov/Path(n.replace('.','/')+'.olean')
  if not obj.exists():raise Exception('object missing '+n+' '+str(obj))
  deps[n]={'source_path':str(src.resolve()),'source_sha256':H(src),'object_path':str(obj.resolve()),'object_sha256':H(obj),'imports':v['imports']}
 env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env.get('LEAN_PATH','');tests=[('GraphSizeBounds',Path(g['nodes']['DiophantineConsistency.GraphSizeBounds']['source']),Path('Computability/DiophantineConsistency/Lean')),('defeq',P/'defeq.lean',P),('EnumeratorCompatibility',Path('Computability/DiophantineConsistency/Lean/checks/EnumeratorCompatibility.lean'),Path('Computability/DiophantineConsistency/Lean')),('axioms-common',P/'AxiomsCommon.lean',P)]
 for tag,src,root in tests:
  log=R/(phase+'-pinned-'+tag+'.log');tm=R/(phase+'-pinned-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(root),str(src)];out=R/(phase+'-pinned-GraphSizeBounds.olean') if tag=='GraphSizeBounds' else None
  if out:out.unlink(missing_ok=True);cmd+=['-o',str(out)]
  before=H(src);start=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  rec={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-start,'source_path':str(src.resolve()),'source_sha256':before,'source_after':H(src),'log_path':str(log),'log_sha256':H(log),'time_path':str(tm),'time_sha256':H(tm),'timing':tm.read_text().strip(),'output_object_path':str(out) if out else None,'output_object_sha256':H(out) if out and out.exists() else None,'dependencies':deps};records.append(rec);(R/'pinned-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,r.returncode,round(rec['seconds'],1),flush=True)
  if r.returncode or before!=H(src):raise SystemExit(1)
  for n,d in deps.items():
   if H(d['source_path'])!=d['source_sha256'] or H(d['object_path'])!=d['object_sha256']:raise Exception('dependency changed during build: '+n)
