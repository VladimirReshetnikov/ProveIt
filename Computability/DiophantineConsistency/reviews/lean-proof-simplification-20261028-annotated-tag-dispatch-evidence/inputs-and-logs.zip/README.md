# Deferred annotated tag-dispatch experiment

This isolated experiment groups the eight finite tag cases in
`AnnotatedRenameLocal.localCheck_correct` and `AnnotatedBoundLocal.localCheck_correct`.
All original statements, imports, definitions, tag guards, lookup conditions and
the explicit ≥8 branch are retained. The prototype sources remain outside the
repository; the deferred research note and evidence bundle are separate.

- `final/` is the first variant using `all_goals try { solve | simp [...] }`.
  It passed the paired seven-module chain recorded in `records.json`, but the
  residual ≥8 branch is harder to read, so it was superseded.
- `v2/` is the direct grouped disjunction. It passed the complete chain in
  `v2-records.json`, but reparenthesizing the original `omega` proposition
  changed the types of the existing generated public `localCheck_correct._proof_1`
  declarations in both targets. The diff is in `baseline-interfaces.log` versus
  `v2-interfaces.log`; this variant is unsuitable under the interface goal.
- `v3/` retains the original disjunction and reassociates it with `or_assoc`
  before explicitly splitting finite tags from the ≥8 case. Its source hashes
  are `31f49ecf957985b9208e67d7a71181e08755ed6692a7e2e45f986d902235a53c`
  (RenameLocal) and `b751e8a1cc0062f4924a2ca11684be3e5c7c342fb6fbaf0bd88c4388b3a03b80`
  (BoundLocal). `v3-records.json` and the baseline half of `records.json`
  record the seven-module source-pinned chains and direct-input hashes. Both
  targets and five downstream builds pass; all five downstream objects match
  baseline. Transitive dependencies beyond the recorded current-source provider
  chain remain cached.

The v3 co-import probes (`v3-probe-records.json`) retain all 119 existing
name/type/axiom reports; two public generated `_simp_1` reassociation proofs
are added. Global simp (25,319 entries) and instances (11,807 entries) match.
The original and candidate v3 source files reduce the combined total by six
lines, but the extra reassociation and generated declarations make the per-tag
checks less direct. On that tradeoff the candidate is deferred, not adopted.

Shared-load target user CPU in the first baseline/v3 run was 2.42/2.42 s for
RenameLocal and 2.74/3.21 s for BoundLocal; one later paired repeat in
`v3repeat-records.json` was 2.52/2.36 s and 2.70/2.78 s respectively. These
small samples do not establish a general performance regression or improvement.
The preliminary independent proofs and `tag-probe.log` remain historical;
the exploratory trace printed all eight finite case labels and the final ≥8
case label. No further client or production changes are implied.
