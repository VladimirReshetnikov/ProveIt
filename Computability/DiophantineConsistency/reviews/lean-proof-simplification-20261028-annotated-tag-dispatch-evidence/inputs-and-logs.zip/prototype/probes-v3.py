from pathlib import Path
import os,subprocess,hashlib,json,sys
R=Path('/tmp/annotated-tag-dispatch');base=os.environ['LEAN_PATH'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for kind in ('interfaces','simp','instances'):
 for phase in ('baseline','v3'):
  out=R/('objects-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(out)+':/tmp/annotated-bound-witness/objects-v3fresh:'+base
  src=R/(kind+'.lean');log=R/(phase+'-'+kind+'.log');before=sha(src);mods=['AnnotatedRenameLocal','AnnotatedRenameLocalPR','AnnotatedRenameScan','AnnotatedRenameScanPR','AnnotatedBound','AnnotatedBoundLocal','AnnotatedBoundScan'];objs=[{'path':str(out/'DiophantineConsistency'/(m+'.olean')),'before':sha(out/'DiophantineConsistency'/(m+'.olean'))} for m in mods]
  cmd=['lean','-M10000','-j1','-DElab.async=false',str(src)]
  with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in objs:x['after']=sha(x['path'])
  records.append({'phase':phase,'probe':kind,'status':p.returncode,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'source':str(src),'source_before':before,'source_after':sha(src),'objects':objs,'log':str(log),'log_sha256':sha(log)});(R/'v3-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,kind,p.returncode,flush=True)
  if p.returncode or before!=sha(src) or any(x['before']!=x['after'] for x in objs):sys.exit(1)
