import json,os,subprocess,sys,time,hashlib
from pathlib import Path
root=Path('/tmp/binary-half-reuse-20261028');phase=sys.argv[1];kind=sys.argv[2];env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');modroot='Computability/DiophantineConsistency/Lean'
if kind=='targets':jobs=[(x,src/(x+'.lean'),True) for x in ('ArithmeticBinaryPopulation','ArithmeticBinaryCarry','ArithmeticRankForcing')]
elif kind=='new-helper':jobs=[('new-helper',root/'new-helper.lean',False)]
else:jobs=[('population-check',src/'ArithmeticBinaryPopulationChecks.lean',False),('repunit-client',src/'ArithmeticRepunit.lean',False),('axioms',root/'axioms.lean',False),('instances',root/'instances.lean',False)]
rows=[]
for tag,path,obj in jobs:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',modroot,str(path)]
 if obj:cmd+=['-o',str(root/phase/'DiophantineConsistency'/(tag+'.olean'))]
 t=time.monotonic();p=subprocess.run(cmd,capture_output=True,env=env);log=root/(phase+'-'+tag+'.log');log.write_bytes(p.stdout+p.stderr)
 x={'tag':tag,'cmd':cmd,'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and not p.returncode:
  q=root/phase/'DiophantineConsistency'/(tag+'.olean');x.update(object_sha256=hashlib.sha256(q.read_bytes()).hexdigest(),object_bytes=q.stat().st_size)
 rows.append(x);(root/(phase+'-'+kind+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,tag,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
