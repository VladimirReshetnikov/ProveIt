from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-runtrace-step-bound-evidence';out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/runtrace-step-bound');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','alternate','final','exploratory','setup-failed']:
 for p in sorted((R/phase).rglob('*')):
  if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('snapshots/'+str(p.relative_to(R)),p)
for name in ['runtrace-independent-review.txt','runtrace-independent-audit.py','runtrace-independent-audit.log','runtrace-independent-audit-initial-failure.log','runtrace-independent-audit-postcommit-stale-check.log']:add('independent/'+name,I/name)
add('prior/wang-initial-records.json',I/'wang-initial-sharing/records.json');add('bundle/build-runtrace-bundle.py',Path(__file__))
commit='3735d5569074591b988f44281a0ac818df0f3e7f';parent='68500896e179ae0d6bdc3b260c8d0c6fb4475eaf';base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';h=lambda b:hashlib.sha256(b).hexdigest()
for phase,ref in [('baseline',parent),('alternate',commit)]:
 for name in ['ArithmeticRunTrace','ArithmeticTilingTable']:
  data=subprocess.check_output(['git','show',ref+':'+base+name+'.lean']);assert data==files['snapshots/'+phase+'/DiophantineConsistency/'+name+'.lean']
  if name=='ArithmeticRunTrace':files['commit/'+('final' if phase=='alternate' else 'baseline')+'.lean']=data
prior=next(x for x in json.loads(files['prior/wang-initial-records.json']) if x['phase']=='final' and x['module']=='ArithmeticWangPlane');data=subprocess.check_output(['git','show',commit+':'+base+'ArithmeticWangPlane.lean']);assert prior['status']==0 and h(data)==prior['before'];files['providers/current/ArithmeticWangPlane.lean']=data
failed=json.loads(files['snapshots/setup-failed/final-records.json'])[0];assert failed['status']!=0 and h(files['snapshots/exploratory/source.lean'])==failed['before'] and h(files['snapshots/setup-failed/final-ArithmeticRunTrace.log'])==failed['log_sha256']
review=files['independent/runtrace-independent-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Simplify run-trace head-step bounds',
 'validation':'Paired target and ArithmeticTilingTable direct-client builds pass using the prior source-current WangPlane provider. All 79 target and 73 client namespace declaration/type/axiom reports match, as do 29,730 default simp and 13,383 instance entries. Paired client probes pin both target and client objects.',
 'limitations':['The baseline and selected ArithmeticTilingTable object hashes differ for an undetermined reason; matching interface and registration probes do not establish identical compiled proof terms or every environment extension.','The sole direct source importer found under Computability/DiophantineConsistency/Lean is ArithmeticTilingTable. Other transitive clients and environment extensions remain outside checked scope.','An initial setup build failed because a BusyBeaver provider path was absent; its source, structured receipt, log and time are preserved. Plain simp on the lower bound also failed; its source/log/status are preserved without a full hash receipt.','The superseded simp [le_tsub_add] variant compiled but added public generated le_hstep._simp_1; the selected alternate does not. Earlier exploratory and selected-target provisional object paths were later reused, so their old output objects are not independently retained.','Two initial independent-audit runs failed, one on a log-text assertion and one on a pre-commit baseline/workspace comparison; their logs are retained and the corrected post-commit audit passes. A later audit-script filename collision was corrected and the final audit rerun successfully; these script-only issues did not alter Lean builds.','The source-current direct WangPlane provider has a prior receipt but its project, BusyBeaver, Foundation and Mathlib transitive closure is cached. One shared-load timing pair is not a general benchmark. Compiled objects are not archived; live external objects are required for independent byte checks.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
