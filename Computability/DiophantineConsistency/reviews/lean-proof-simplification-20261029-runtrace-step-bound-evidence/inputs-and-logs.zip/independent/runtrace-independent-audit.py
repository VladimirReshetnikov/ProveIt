from pathlib import Path
import hashlib,json,subprocess,subprocess
R=Path('/tmp/runtrace-step-bound');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
a=(R/'baseline/DiophantineConsistency/ArithmeticRunTrace.lean').read_text();b=(R/'alternate/DiophantineConsistency/ArithmeticRunTrace.lean').read_text()
old1='''  split
  · exact le_add_of_nonneg_right (Arithmetic.zero_le 1)
  · split
    · exact le_trans (tsub_le_self) (le_add_of_nonneg_right (Arithmetic.zero_le 1))
    · exact le_rfl
''';old2='''  split
  · exact le_add_of_nonneg_right (Arithmetic.zero_le 1)
  · split
    · exact le_tsub_add
    · exact le_trans (le_add_of_nonneg_right (Arithmetic.zero_le 1))
        (le_add_of_nonneg_right (Arithmetic.zero_le 1))
''';assert a.count(old1)==a.count(old2)==1;assert b==a.replace(old1,'  split_ifs <;> simp\n').replace(old2,'  split_ifs <;> first | exact le_tsub_add | simp\n');rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRunTrace.lean'
for ref,ph in [('3735d55690^','baseline'),('3735d55690','alternate')]:
 assert hashlib.sha256(subprocess.check_output(['git','show',ref+':'+rel])).hexdigest()==h(R/ph/'DiophantineConsistency/ArithmeticRunTrace.lean');print('git source snapshot matches',ref,ph)
assert h(W/'ArithmeticRunTrace.lean')==h(R/'alternate/DiophantineConsistency/ArithmeticRunTrace.lean');print('exact two-proof substitution; workspace now selected alternate')
prior=next(x for x in read('/tmp/wang-initial-sharing/records.json') if x['phase']=='final' and x['module']=='ArithmeticWangPlane');assert prior['status']==0 and prior['before']==prior['after']==h(W/'ArithmeticWangPlane.lean') and prior['object_sha256']==h(prior['object']);print('prior current-source WangPlane producer',prior['object_sha256'])
rows={}
for ph in ['baseline','alternate']:
 rec=read(R/(ph+'-records.json'));assert len(rec)==2
 for x in rec:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][4]).read_text()
  if n!='ArithmeticRunTrace':assert x['before']==h(W/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n0=d['module'].split('.')[-1]
   if n0=='ArithmeticRunTrace':assert d['before']==rows[ph,n0]['object_sha256'] and d['resolved']==rows[ph,n0]['object']
   else:assert n0=='ArithmeticWangPlane' and d['before']==prior['object_sha256']
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
print('TilingTable client object hashes equal?',rows['baseline','ArithmeticTilingTable']['object_sha256']==rows['alternate','ArithmeticTilingTable']['object_sha256'])
for k in ['names','interfaces','simp','instances']:
 for ph in ['baseline','alternate']:
  x=read(R/f'probe-{k}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticRunTrace']['object_sha256'] and x['log_sha256']==h(x['log'])
 a=(R/('baseline-'+k+'.log')).read_bytes();b=(R/('alternate-'+k+'.log')).read_bytes();assert a==b;print('target probe',k,len(a.splitlines()),'identical')
for x in read(R/'client-probe2-records.json'):
 ph=x['phase'];k=x['probe'];expected=[rows[ph,n]['object_sha256'] for n in ['ArithmeticRunTrace','ArithmeticTilingTable']];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==expected and all(h(p)==v for p,v in zip(x['objects'],expected)) and x['log_sha256']==h(x['log'])
for k in ['names','interfaces','simp','instances']:
 a=(R/('baseline-client2-'+k+'.log')).read_bytes();b=(R/('alternate-client2-'+k+'.log')).read_bytes();assert a==b;print('client probe',k,len(a.splitlines()),'identical; target/client pinned')
base={x[5:] for x in (R/'baseline-names.log').read_text().splitlines() if x.startswith('DECL ')};old={x[5:] for x in (R/'final-names.log').read_text().splitlines() if x.startswith('DECL ')};assert old-base=={'DiophantineConsistency.ArithmeticRunTrace.le_hstep._simp_1'} and not base-old;print('superseded simp [le_tsub_add] added generated public name')
f=read(R/'setup-failed/final-records.json')[0];assert f['status']!=0 and f['before']==f['after']==h(R/'exploratory/source.lean') and f['log_sha256']==h(R/'setup-failed/final-ArithmeticRunTrace.log') and f['time']==(R/'setup-failed/final-ArithmeticRunTrace.time').read_text() and 'ArithmeticMachineGraphPerm252.olean' in (R/'setup-failed/final-ArithmeticRunTrace.log').read_text();print('failed setup source, log/time and receipt match')
assert (R/'plain-simp-probe-status.txt').read_text().strip()=='1' and 'made no progress' in (R/'plain-simp-probe.log').read_text();print('plain-simp failed probe preserved, no full hash receipt claimed')
print('PASS; client bytes differ and cached transitive closure is not rebuilt')

assert h(W/'ArithmeticRunTrace.lean')==rows['alternate','ArithmeticRunTrace']['before'];print('post-commit workspace matches tested alternate')
