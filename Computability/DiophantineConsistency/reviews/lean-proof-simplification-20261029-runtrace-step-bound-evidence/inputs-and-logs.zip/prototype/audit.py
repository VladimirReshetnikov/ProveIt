from pathlib import Path
import hashlib,json
R=Path('/tmp/runtrace-step-bound'); W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records={p:json.loads((R/f'{p}-records.json').read_text()) for p in ('baseline','alternate')}
for phase,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticRunTrace','ArithmeticTilingTable']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log'])
  for dep in x['direct_inputs']: assert dep['before']==dep['after']==h(dep['path'])
  if x['module']=='ArithmeticTilingTable': assert x['before']==h(W/'ArithmeticTilingTable.lean') and x['direct_inputs'][0]['before']==rr[0]['object_sha256']
 assert rr[0]['direct_inputs'][0]['before']=='7bfeae9ade3ec83c1f07f662cb50551e92aa725f3296096722bbb031406e98c9'
assert records['baseline'][0]['before']==h(W/'ArithmeticRunTrace.lean')
p=next(x for x in json.loads(Path('/tmp/wang-initial-sharing/records.json').read_text()) if x['phase']=='final' and x['module']=='ArithmeticWangPlane')
assert p['status']==0 and p['before']==p['after']==h(W/'ArithmeticWangPlane.lean') and p['object_sha256']==records['baseline'][0]['direct_inputs'][0]['before']
for probe in ('names','interfaces','simp','instances'):
 for phase in ('baseline','alternate'):
  x=json.loads((R/f'probe-{probe}-{phase}.json').read_text())
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[phase][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{probe}.log').read_bytes()==(R/f'alternate-{probe}.log').read_bytes()
rows=json.loads((R/'client-probe2-records.json').read_text());assert len(rows)==8
for x in rows:
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[z['object_sha256'] for z in records[x['phase']]] and x['log_sha256']==h(x['log'])
for probe in ('names','interfaces','simp','instances'):assert (R/f'baseline-client2-{probe}.log').read_bytes()==(R/f'alternate-client2-{probe}.log').read_bytes()
print('PASS: current-source target/client, provider prior source/object receipt, pinned builds and paired target/client census logs')
