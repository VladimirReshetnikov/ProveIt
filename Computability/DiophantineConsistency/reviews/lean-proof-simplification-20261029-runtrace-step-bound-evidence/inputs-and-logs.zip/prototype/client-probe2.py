from pathlib import Path
import json,subprocess,hashlib,os,sys
R=Path('/tmp/runtrace-step-bound');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();rows=[]
for probe in ['names','interfaces','simp','instances']:
 for ph in ['baseline','alternate']:
  source=R/f'client-{probe}.lean'; objs=[R/f'objects-{ph}/DiophantineConsistency/{n}.olean' for n in ['ArithmeticRunTrace','ArithmeticTilingTable']];log=R/f'{ph}-client2-{probe}.log';env=os.environ.copy();env['LEAN_PATH']=str(R/f'objects-{ph}')+':/tmp/wang-initial-sharing/objects-final:/tmp/fin-one-simplification/trace-full-fresh:'+base+':/home/codex/src/Proofs/.lake/build/lib/lean';sb=h(source);before=[h(x) for x in objs];cmd=['lean','-M10000','-j1','-DElab.async=false',str(source)]
  with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  x={'phase':ph,'probe':probe,'status':p.returncode,'source':str(source),'source_before':sb,'source_after':h(source),'objects':[str(o) for o in objs],'objects_before':before,'objects_after':[h(o) for o in objs],'log':str(log),'log_sha256':h(log),'command':cmd,'LEAN_PATH':env['LEAN_PATH']};rows.append(x);(R/'client-probe2-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(ph,probe,p.returncode,flush=True)
  if p.returncode or x['objects_before']!=x['objects_after']:raise SystemExit(1)
