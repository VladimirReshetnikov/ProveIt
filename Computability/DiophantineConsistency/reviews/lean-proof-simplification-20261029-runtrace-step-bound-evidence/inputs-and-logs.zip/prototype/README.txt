ArithmeticRunTrace step-bound proof simplification (isolated prototype)

Selected alternate source: alternate/DiophantineConsistency/ArithmeticRunTrace.lean
SHA-256 3e268557858826c6ddc7d297a9cec52759dacec29910c7dbc2d42fde254e9c4b
Baseline source: baseline/DiophantineConsistency/ArithmeticRunTrace.lean
SHA-256 34dd933850c9451ab3d8f98f2075d9f80803ffa05982ddaae0c7b3880254b4c4
The baseline matches the current workspace. Only the proofs of hstep_le and
le_hstep change, retaining all declarations, statements, guards and imports.
The two conditional definitions have identical three branch cases; unfold and
split_ifs dispatches them, simp proves the upper bound, and le_tsub_add handles
the subtraction case of the lower bound. The Lean diff is 2 additions/11
deletions. Initial module commit 5fcd5632b3b753237437f22904b899653f69916b
carries Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>.

baseline-records.json and alternate-records.json record successful builds of
the current-source target and its sole directly importing project source,
ArithmeticTilingTable, including source, direct object, output and log hashes.
The direct ArithmeticWangPlane object is 7bfeae9ade3ec83c1f07f662cb50551e92aa725f3296096722bbb031406e98c9;
/tmp/wang-initial-sharing/records.json records a successful final build of it
from source fa4d7e4c552cc4e5062dc206aa1b4cf0ab00ecd76adb02dd2f67c70da12d0106,
matching the current workspace. This is a direct-provider source/object match,
not a fresh full transitive closure build: other project, BusyBeaver, foundation
and Mathlib objects came from cached paths. The target/build provider and target
object are pinned in direct-input receipts before and after each build.

CPU times (single sequential samples, shared-machine conditions): target 16.13s
baseline, 16.55s alternate; client 8.98s baseline, 9.19s alternate. Earlier
alternate target sample also used 16.55s; alternate-target-records.json retains
that receipt, although its object and log paths were reused by the final build.
Baseline and alternate target warn about the same preexisting nine lints at
shifted source lines; the client logs have no new warnings. Differing client
object bytes are expected possible build variation, not evidence that client
exports changed: baseline 9d201990e4564b93f8bd7f71710e887d500bbc49d7227aeb07e99f6d55f731cd,
alternate 863a2460bd4cd7d3da2b574ccb7340d32d3b862596c287e18afd738514843d79.
No cause for the differing bytes was established.

Target probes (probe-{names,interfaces,simp,instances}-{baseline,alternate}.json)
match byte-for-byte between phases: 79 target namespace declarations and their
type/axiom reports, 29,730 global simp entries, and 13,383 instances. Paired
client probes (client-probe2-records.json) independently pin both target and
client objects before/after; all 73 client namespace declarations and their
type/axiom reports, and both global registration lists, match byte-for-byte.
These checks do not assert equivalence of private proof bodies or entire olean
serialization. audit.py verifies all recorded source, log and direct-input pins,
prior provider match, paired outputs, and probe objects; audit.log records success.

Superseded trials are retained separately: final/ and final-records.json have a
successful earlier alternate using simp [le_tsub_add], which adds generated
public le_hstep._simp_1 despite unchanged simp/instance registrations; this is
not the selected alternate. exploratory/ preserves a still earlier working
version with an unused simp argument warning. Plain split_ifs <;> simp on the
lower bound fails with "simp made no progress" (plain-simp-probe.lean/.log and
status). setup-failed/ captures a preliminary failed build caused by a missing
BusyBeaver provider path; final builds added the correct path. These historical
trials are not evidence for the selected result.
