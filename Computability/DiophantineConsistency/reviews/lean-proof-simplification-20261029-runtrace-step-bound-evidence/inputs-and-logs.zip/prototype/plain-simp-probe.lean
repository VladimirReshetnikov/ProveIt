import DiophantineConsistency.ArithmeticRunTrace
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticRunTrace
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (c h : V) : h ≤ hstep c h + 1 := by
  unfold hstep
  split_ifs <;> simp
