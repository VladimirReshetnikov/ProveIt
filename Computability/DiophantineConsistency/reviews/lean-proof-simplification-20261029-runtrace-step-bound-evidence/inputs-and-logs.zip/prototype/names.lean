import DiophantineConsistency.ArithmeticRunTrace
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRunTrace).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRunTrace" then
   logInfo m!"DECL {n}"
