from pathlib import Path
import hashlib,json
r=Path('/tmp/variation-tail-sharing'); h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();out=[]
records=[]
for f in ['/tmp/origin-block-sharing/records.json','/tmp/controller-stride-period/common-records.json','/tmp/controller-stride-period/variant2-records.json','/tmp/wang-initial-sharing/records.json','/tmp/kernel-residues-sharing/coherent-refresh-records.json','/dev/shm/claude-transport-sharing/assembly-common-records.json','/tmp/variation-tail-sharing/refreshed-common-records.json','/tmp/variation-tail-sharing/refreshed2-common-records.json']:
 for x in json.loads(Path(f).read_text()):
  if x.get('status')==0:
   m=x.get('module','').split('.')[-1];src=x.get('source_before',x.get('source_sha256',x.get('before')));obj=x.get('object_sha256');records.append((m,src,obj,f))
for f in ['/tmp/mask-ins-construction/provider-mapping.json','/tmp/rowrel-independent-pins.json']:
 for x in json.loads(Path(f).read_text()): records.append((x['module'].split('.')[-1],x['source_sha256'],x['object_sha256'],f))
for ph in ('refreshed-common','refreshed2-common','refreshed2-baseline','refreshed2-final'):
 for x in json.loads((r/f'{ph}-records.json').read_text()):
  if ph=='refreshed-common' and x['module']=='ArithmeticPackingCells': continue # superseded older WangPlane provider
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
  if ph!='refreshed2-final' or x['module']!='ArithmeticConstructionVariation':assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(p) and d['source_before']==d['source_after']==h(d['source']);n=d['module'].split('.')[-1]
   if n=='ArithmeticConstructionVariation':assert ph.startswith('refreshed2-') and d['resolved']==str(r/('objects-'+ph)/'DiophantineConsistency/ArithmeticConstructionVariation.olean'); matches=['same phase target; source sample is pre-candidate workspace']
   else:
    matches=sorted(set(f for m,s,o,f in records if (m,s,o)==(n,d['source_before'],d['object_before']))); assert matches,(ph,x['module'],n,d['source_before'],d['object_before'])
   out.append({'phase':ph,'client':x['module'],'module':n,'source':d['source_before'],'object':d['object_before'],'matches':matches});print(ph,x['module'],'direct',n,'matched',','.join(matches))
for ph in ('refreshed2-baseline','refreshed2-final'):
 for x in json.loads((r/f'{ph}-probes.json').read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);print(ph,'probe',x['name'],'passed')
for n in ('simp','instances','interfaces'):assert (r/f'refreshed2-baseline-{n}.log').read_bytes()==(r/f'refreshed2-final-{n}.log').read_bytes();print(n,'identical',len((r/f'refreshed2-final-{n}.log').read_text().splitlines()))
a=next(x for x in json.loads((r/'refreshed2-baseline-records.json').read_text()) if x['module']=='ArithmeticConstructionAssembly');b=next(x for x in json.loads((r/'refreshed2-final-records.json').read_text()) if x['module']=='ArithmeticConstructionAssembly');print('client objects equal',a['object_sha256']==b['object_sha256'])
(r/'refreshed2-provider-matches.json').write_text(json.dumps(out,indent=2)+'\n')
