from pathlib import Path
import json,hashlib
r=Path('/tmp/variation-tail-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for ph in ('baseline','final'):
 x=json.loads((r/f'repeat-{ph}-records.json').read_text())[0];orig=json.loads((r/f'{ph}-records.json').read_text())[0]
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==orig['source_before'] and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object'])==orig['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
 assert x['LEAN_PATH']==orig['LEAN_PATH']
 for d,o in zip(x['direct_inputs'],orig['direct_inputs']):
  assert d['module']==o['module'] and d['resolved']==o['resolved'] and d['object_before']==d['object_after']==h(d['path'])==o['object_before'] and d['source_before']==d['source_after']==h(d['source'])==o['source_before']
 print(ph,'repeat matched original source, object and direct inputs;',x['timing'])
