from pathlib import Path
import json,hashlib,re
r=Path('/tmp/variation-tail-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); rows=[]
prior=json.loads(Path('/tmp/mask-ins-construction/provider-mapping.json').read_text())
targets={'ArithmeticPacking':('/dev/shm/claude-transport-sharing/assembly-phase-records.json','DiophantineConsistency.ArithmeticPacking'), 'ArithmeticControllerChoice':('/tmp/controller-dmap-sharing/final-records.json','ArithmeticControllerChoice')}
for ph in ('baseline','final'):
 xs=json.loads((r/f'{ph}-records.json').read_text());assert len(xs)==2
 for x in xs:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
  if ph=='baseline' or x['module']=='ArithmeticConstructionAssembly':assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(p) and d['source_before']==d['source_after']==h(d['source']);n=d['module'].split('.')[-1]
   if n=='ArithmeticConstructionVariation':assert d['resolved']==str(r/('objects-'+ph)/'DiophantineConsistency/ArithmeticConstructionVariation.olean')
   elif n in targets:
    f,m=targets[n]; a=json.loads(Path(f).read_text());assert any(q.get('status')==0 and q.get('module')==m and q.get('phase')=='final' and q.get('source_before',q.get('source_sha256'))==d['source_before'] and q.get('object_sha256')==d['object_before'] for q in a)
   else:assert any(q['module']==d['module'] and q['source_sha256']==d['source_before'] and q['object_sha256']==d['object_before'] for q in prior),(ph,n)
  print('build',ph,x['module'],len(x['direct_inputs']),'inputs matched');rows.append(x)
 for q in json.loads((r/f'{ph}-probes.json').read_text()):
  assert q['status']==0 and q['source_before']==q['source_after']==h(q['source']) and q['object_before']==q['object_after']==h(q['object']) and q['log_sha256']==h(q['log']) and q['time_sha256']==h(q['time']);print('probe',ph,q['name'],'verified')
for n in ('simp','instances'):
 assert (r/f'baseline-{n}.log').read_bytes()==(r/f'final-{n}.log').read_bytes();print(n,'identical',len((r/f'{ph}-{n}.log').read_text().splitlines()))
def parse(p):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',p.read_text(),re.M|re.S)}
a=parse(r/'baseline-interfaces.log');b=parse(r/'final-interfaces.log');print('declarations baseline',len(a),'final',len(b),'removed',sorted(a.keys()-b.keys()),'added',sorted(b.keys()-a.keys()),'changed',sorted(n for n in a.keys()&b.keys() if a[n]!=b[n]))
for n in sorted(a.keys()&b.keys()):
 if a[n]!=b[n]: print('CHANGED',n,'baseline',a[n],'final',b[n])
f=json.loads((r/'initial-failed-records.json').read_text())[0];assert f['status']!=0 and h(r/'initial-failed.log')==f['log_sha256'] and h(r/'initial-failed.time')==f['time_sha256'];print('initial incomplete-overlay failure preserved')
