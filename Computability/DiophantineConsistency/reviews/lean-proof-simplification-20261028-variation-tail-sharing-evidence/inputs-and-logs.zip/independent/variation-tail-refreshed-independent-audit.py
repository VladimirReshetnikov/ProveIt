from pathlib import Path
import json,hashlib,re
R=Path('/tmp/variation-tail-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['/tmp/origin-block-sharing/records.json','/tmp/controller-stride-period/common-records.json','/tmp/controller-stride-period/variant2-records.json','/tmp/wang-initial-sharing/records.json','/tmp/kernel-residues-sharing/coherent-refresh-records.json','/dev/shm/claude-transport-sharing/assembly-common-records.json','/tmp/variation-tail-sharing/refreshed-common-records.json','/tmp/variation-tail-sharing/refreshed2-common-records.json'];providers=[]
for fn in files:
 for x in json.loads(Path(fn).read_text()):
  if x.get('status')==0:providers.append((x.get('module','').split('.')[-1],x.get('source_before',x.get('source_sha256',x.get('before'))),x.get('object_sha256'),fn))
for fn in ['/tmp/mask-ins-construction/provider-mapping.json','/tmp/rowrel-independent-pins.json']:
 for x in json.loads(Path(fn).read_text()):providers.append((x['module'].split('.')[-1],x['source_sha256'],x['object_sha256'],fn))
rows=[]
for ph in ['refreshed-common','refreshed2-common','refreshed2-baseline','refreshed2-final']:
 for x in json.loads((R/f'{ph}-records.json').read_text()):
  if ph=='refreshed-common' and x['module']=='ArithmeticPackingCells':continue
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']) and x['timing'].strip()==Path(x['time']).read_text().strip()
  if (ph,x['module'])!=('refreshed2-final','ArithmeticConstructionVariation'):assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';q=next(Path(t)/rel for t in x['LEAN_PATH'].split(':') if (Path(t)/rel).is_file());assert str(q)==d['path'] and str(q.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(q) and d['source_before']==d['source_after']==h(d['source']);n=d['module'].split('.')[-1]
   if n=='ArithmeticConstructionVariation':
    t=next(v for v in rows if v['phase']==ph and v['module']==n);assert d['object_before']==t['object_sha256'] and d['resolved']==str(R/f'objects-{ph}/DiophantineConsistency/{n}.olean')
   else:assert any(a==n and s==d['source_before'] and o==d['object_before'] for a,s,o,_ in providers),(ph,n)
  rows.append(x);print('BUILD',ph,x['module'],'inputs',len(x['direct_inputs']),'timing',x['timing'])
for ph in ['refreshed2-baseline','refreshed2-final']:
 for x in json.loads((R/f'{ph}-probes.json').read_text()):
  target=next(v for v in rows if v['phase']==ph and v['module']=='ArithmeticConstructionVariation');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==target['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);print('PROBE',ph,x['name'],'OK')
for n in ['interfaces','simp','instances']:
 a=(R/f'refreshed2-baseline-{n}.log').read_bytes();b=(R/f'refreshed2-final-{n}.log').read_bytes();assert a==b;print('COMPARE',n,'equal lines',len(a.splitlines()))
a=next(x for x in rows if x['phase']=='refreshed2-baseline' and x['module']=='ArithmeticConstructionAssembly');b=next(x for x in rows if x['phase']=='refreshed2-final' and x['module']=='ArithmeticConstructionAssembly');assert a['object_sha256']==b['object_sha256'];print('ASSEMBLY object identical',a['object_sha256'])
for ph in ['refreshed2-baseline','refreshed2-final']:
 p=R/f'objects-{ph}/DiophantineConsistency'
 for n in ['ArithmeticPackingBlocks','ArithmeticWangPlane','ArithmeticPellRecurrence','ArithmeticPellClassification','ArithmeticPellPeriodicity','ArithmeticPellResidueClasses','ArithmeticHalfBinomial','ArithmeticTilingWord','ArithmeticTilingBand','ArithmeticTilingRows','ArithmeticTilingTable','ArithmeticRunTrace']:
  q=p/(n+'.olean');print('TRANSITIVE',ph,n,h(q),q.resolve())
