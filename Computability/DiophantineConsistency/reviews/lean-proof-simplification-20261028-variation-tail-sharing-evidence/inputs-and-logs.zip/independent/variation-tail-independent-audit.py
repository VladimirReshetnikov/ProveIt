from pathlib import Path
import json,hashlib,re
R=Path('/tmp/variation-tail-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();mapping=json.loads(Path('/tmp/mask-ins-construction/provider-mapping.json').read_text());prior=[]
for f in ['/dev/shm/claude-transport-sharing/assembly-phase-records.json','/tmp/controller-dmap-sharing/final-records.json']:
 prior+=json.loads(Path(f).read_text())
allrows={}
for phase in ['baseline','final']:
 rows=json.loads((R/f'{phase}-records.json').read_text());assert len(rows)==2
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']) and x['timing'].strip()==Path(x['time']).read_text().strip()
  if phase=='baseline' or x['module']=='ArithmeticConstructionAssembly':assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';first=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(first) and d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n=='ArithmeticConstructionVariation':assert d['resolved']==str(R/f'objects-{phase}/DiophantineConsistency/ArithmeticConstructionVariation.olean') and d['object_before']==rows[0]['object_sha256']
   elif n in ['ArithmeticPacking','ArithmeticControllerChoice']:
    assert any(q.get('status')==0 and q.get('module','').split('.')[-1]==n and q.get('phase')=='final' and q.get('source_before',q.get('source_sha256'))==d['source_before'] and q.get('object_sha256')==d['object_before'] for q in prior),n
   else:assert any(q['module']==d['module'] and q['source_sha256']==d['source_before'] and q['object_sha256']==d['object_before'] for q in mapping),n
  print('BUILD',phase,x['module'],'direct inputs',len(x['direct_inputs']),x['timing']);allrows[phase,x['module']]=x
 for x in json.loads((R/f'{phase}-probes.json').read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==allrows[phase,'ArithmeticConstructionVariation']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);print('PROBE',phase,x['name'],'verified')
for ph in ['baseline','final']:
 x=json.loads((R/f'repeat-{ph}-records.json').read_text())[0];orig=allrows[ph,'ArithmeticConstructionVariation'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==orig['source_before'] and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object'])==orig['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']) and x['timing'].strip()==Path(x['time']).read_text().strip() and x['LEAN_PATH']==orig['LEAN_PATH']
 for a,b in zip(x['direct_inputs'],orig['direct_inputs']):assert a['module']==b['module'] and a['resolved']==b['resolved'] and a['object_before']==a['object_after']==h(a['path'])==b['object_before'] and a['source_before']==a['source_after']==h(a['source'])==b['source_before']
 print('REPEAT',ph,x['timing'])
def parse(p):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',p.read_text(),re.M|re.S)}
a=parse(R/'baseline-interfaces.log');b=parse(R/'final-interfaces.log');assert a==b;print('DECLARATIONS',len(a),'equal')
for n in ['simp','instances']:
 a=(R/f'baseline-{n}.log').read_bytes();b=(R/f'final-{n}.log').read_bytes();assert a==b;print(n,'equal lines',len(a.splitlines()))
assert allrows['baseline','ArithmeticConstructionAssembly']['object_sha256']==allrows['final','ArithmeticConstructionAssembly']['object_sha256'];print('ASSEMBLY object equal',allrows['baseline','ArithmeticConstructionAssembly']['object_sha256'])
f=json.loads((R/'initial-failed-records.json').read_text())[0];assert f['status']!=0 and f['log_sha256']==h(R/'initial-failed.log') and f['time_sha256']==h(R/'initial-failed.time');print('INITIAL failed incomplete overlay retained')
old=Path('/tmp/variation-tail-sharing/objects-final/DiophantineConsistency/ArithmeticPackingBlocks.olean');print('TRANSITIVE BLOCK cached',old.resolve(),h(old));print('TRANSITIVE BLOCK current source',h('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPackingBlocks.lean'))
