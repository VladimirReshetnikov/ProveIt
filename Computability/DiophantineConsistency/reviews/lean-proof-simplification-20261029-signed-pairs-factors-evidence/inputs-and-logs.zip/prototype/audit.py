from pathlib import Path
import json,hashlib
r=Path('/tmp/signed-pairs-factors');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();counts={}
for fname in ['baseline-records.json','final-records.json']:
 rows=json.loads((r/fname).read_text());counts[fname]=len(rows)
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']), (fname,x['module'],'source')
  assert h(x['log'])==x['log_sha256'] and h(x['object'])==x['object_sha256'] and not Path(x['object']).is_symlink(),(fname,x['module'],'output')
  for d in x['direct_inputs']:
   assert d['before']==d['after']==h(d['path']) and str(Path(d['path']).resolve())==d['resolved'],(fname,x['module'],d['module'],'object')
   if d['source']: assert d['source_before']==d['source_after']==h(d['source']),(fname,x['module'],d['module'],'source')
for phase in ['baseline','final']:
 for x in json.loads((r/(phase+'-probes.json')).read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and h(x['log'])==x['log_sha256']
  assert [h(p) for p in x['objects']]==x['objects_before']==x['objects_after']
c=json.loads((r/'comparison.json').read_text());assert not c['names']['removed'] and not c['names']['added'];assert not c['interfaces']['changed_common'];assert not c['simp']['removed'] and not c['simp']['added'];assert not c['instances']['removed'] and not c['instances']['added']
print('Pinned source, direct inputs, logs, regular outputs and probe objects verified:',counts)
print('Comparison:',[(k,c[k]['baseline_count'],c[k]['final_count']) for k in ['names','interfaces','simp','instances']])
