import Foundation.FirstOrder.Arithmetic.IOpen.Basic
import Mathlib.Tactic.Ring
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
#check pos_of_mul_pos_left
#check pos_of_mul_pos_right
#check mul_pos_iff
#check mul_ne_zero_iff
#check mul_eq_one_iff
#check eq_one_of_mul_eq_one_left
#check eq_one_of_mul_eq_one_right
#check le_of_mul_le_mul_right
#check le_of_dvd
#check IsUnit.eq_one
#check one_le_iff_ne_zero
