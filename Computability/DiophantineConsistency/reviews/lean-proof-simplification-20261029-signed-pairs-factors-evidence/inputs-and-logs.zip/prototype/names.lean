import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCarrierSoundness2011
import DiophantineConsistency.ArithmeticCurrentSentence2011
import DiophantineConsistency.ArithmeticSignedPairsChecks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticSignedPairs).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticSignedPairs" then
   logInfo m!"DECL {n}"
