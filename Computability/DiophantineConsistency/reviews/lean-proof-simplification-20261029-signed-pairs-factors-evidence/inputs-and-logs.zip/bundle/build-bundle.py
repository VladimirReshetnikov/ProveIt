from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs');R=Path('/tmp/signed-pairs-factors');D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-signed-pairs-factors-evidence';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();items={}
def add(n,p):assert n not in items;items[n]=Path(p).read_bytes()
def git(p,rev):return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=ROOT)
rev='f37a2aad85457c303df59fe58ae2e962fb8d2dfe';parent='c8f338ddda1ecb4fb4bba0c3c5305a34646f1b75';mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for ph,ref in [('baseline',parent),('final',rev)]:
 key=f'commit/{ph}.lean';items[key]=git(mod+'ArithmeticSignedPairs.lean',ref);assert items[key]==(R/ph/'DiophantineConsistency/ArithmeticSignedPairs.lean').read_bytes()
for n in ['ArithmeticSignedPairsChecks','ArithmeticCurrentSentence2011','ArithmeticCarrierSoundness2011','FoundationHACurrentNoZero2011','CurrentEquationSyntax2011','ArithmeticNegativeNorms','ArithmeticPellFirstIndex']:
 items['provider-sources/'+n+'.lean']=git(mod+n+'.lean',rev)
for f in sorted(R.rglob('*')):
 parts=f.relative_to(R).parts
 if f.is_file() and f.suffix not in ('.olean','.ilean','.c') and not any(x=='common' or x.startswith('objects-') for x in parts):add('prototype/'+f.relative_to(R).as_posix(),f)
for n,p in {'prior/positive-shift-source-clean.json':'/tmp/positive-shift-sharing/source-clean/records.json','prior/four-wrapper-final.json':'/tmp/four-positive-wrappers/refreshed-final-records.json','prior/four-wrapper-upstream.json':'/tmp/four-positive-wrappers/upstream-records.json','independent/review.txt':'/tmp/signed-pairs-factors-peer-review.txt','independent/audit.py':'/tmp/signed-pairs-factors-peer-audit.py','independent/audit.log':'/tmp/signed-pairs-factors-peer-audit.log','independent/audit-phase-mismatch.log':'/tmp/signed-pairs-factors-peer-audit-preliminary-phase-mismatch.log','bundle/build-bundle.py':'/tmp/build-signed-pairs-factors-bundle.py'}.items():add(n,p)
zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):
  i=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Simplify private SignedPairs factors_one proof via positive product and divisibility',
'validation':'Paired target and all three tracked direct module clients pass. Four current-source external direct provider pairs match prior producer receipts; all three client object pairs match byte-for-byte. Combined target/client-pinned probes match 39 target names/type/axiom reports and global default simp and instance lists.',
'limitations':['Foundation and Mathlib direct inputs and wider project transitive closure remain cached; matching direct producer pairs do not establish a full current-source closure.', 'Probe comparisons do not establish equality of proof bodies or all persistent environment extensions. Single shared-load timing samples are not a general benchmark.', 'An exploratory missing-Foundation check log was overwritten; the corrected check retains expected unknown-lemma diagnostics. A provisional target probe lacks full paired input pins.', 'The independent audit initially selected the wrong prior FoundationHACurrentNoZero2011 phase; its failed log and corrected postcommit audit are included.', 'Compiled objects and cached overlays are omitted; receipts preserve hashes and paths, and independent byte verification requires external objects.'],
'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(items)
 for n,b in items.items():assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes();print(n,sha(b),len(b))
