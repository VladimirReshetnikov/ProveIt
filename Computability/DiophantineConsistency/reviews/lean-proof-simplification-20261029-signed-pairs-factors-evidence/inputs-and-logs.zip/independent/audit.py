from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/signed-pairs-factors');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticSignedPairs.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticSignedPairs.lean').read_text();old='''  have hp : 0<a := by
    by_contra hn
    have hz : a=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le a)
    simp [hz] at h
  have hq : 0<b := by
    by_contra hn
    have hz : b=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le b)
    simp [hz] at h
  have ha : a≤1 := calc
    a=a*1 := by ring
    _≤a*b := mul_le_mul_of_nonneg_left (pos_iff_one_le.mp hq) (by simp)
    _=1 := h''';new='''  have hp : 0<a := pos_of_mul_pos_left (by rw [h]; simp) (Arithmetic.zero_le b)
  have ha : a≤1 := le_of_dvd (by simp) ⟨b,h.symm⟩'''
assert b.count(old)==1 and b.replace(old,new)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticSignedPairs.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('f37a2aad85^')==b and gitfile('f37a2aad85')==f and (W/'ArithmeticSignedPairs.lean').read_text()==f
print('PASS exact proof replacement, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticSignedPairs$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(p).stem for p in clients)==['ArithmeticCarrierSoundness2011','ArithmeticCurrentSentence2011','ArithmeticSignedPairsChecks']
print('PASS three tracked direct module clients',clients)
paths={'FoundationHACurrentNoZero2011':'/tmp/positive-shift-sharing/source-clean/records.json','CurrentEquationSyntax2011':'/tmp/positive-shift-sharing/source-clean/records.json','ArithmeticNegativeNorms':'/tmp/four-positive-wrappers/refreshed-final-records.json','ArithmeticPellFirstIndex':'/tmp/four-positive-wrappers/upstream-records.json'};providers={}
for n,p in paths.items():
 xs=[x for x in read(p) if x.get('module','').split('.')[-1]==n and x.get('status')==0 and (p!='/tmp/positive-shift-sharing/source-clean/records.json' or x.get('phase')=='final')]
 for x in xs:
  a=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');z=x.get('after') or x.get('source_after') or x.get('source_sha256_after') or x.get('source_sha256')
  if a==z==h(W/(n+'.lean')):providers[n]=x['object_sha256'];break
 assert n in providers,(n,p);print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticSignedPairs','ArithmeticSignedPairsChecks','ArithmeticCurrentSentence2011','ArithmeticCarrierSoundness2011'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticSignedPairs':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d.get('source_before') is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n=='ArithmeticSignedPairs':assert d['before']==rec[phase][n]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
   else:assert d['module'] in ['Foundation.FirstOrder.Arithmetic.IOpen.Basic','Mathlib.Tactic.Ring']
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticSignedPairsChecks','ArithmeticCurrentSentence2011','ArithmeticCarrierSoundness2011'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS 3 source-matched direct clients with identical output objects')
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][Path(p).stem]['object_sha256'] for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
print('PASS four-object-pinned namespace/type/axiom and global registration probes')
