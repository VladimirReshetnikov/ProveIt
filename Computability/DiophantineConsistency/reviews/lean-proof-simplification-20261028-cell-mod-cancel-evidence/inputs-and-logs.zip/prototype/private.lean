import DiophantineConsistency.ArithmeticCellTransfer
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`_private.DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n then
      let typ ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let axioms ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {typ} AXIOMS {axioms}"
