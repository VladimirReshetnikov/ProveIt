import DiophantineConsistency.ArithmeticCellTransfer
#print equations DiophantineConsistency.ArithmeticCellTransfer.inSupport
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n then
      logInfo m!"DECL {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
       t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
