from pathlib import Path
import json,hashlib
r=Path('/tmp/cell-mod-cancel');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();xs=json.loads((r/'records.json').read_text());assert len(xs)==4
for x in xs:
 assert x['status']==0 and x['source_before']==x['source_after'] and (x['source_before']==h(x['source']) or (x['phase']=='base' and x['module']=='ArithmeticCellTransfer' and x['source_before']==h(r/'commit-parent.lean') and h(x['source'])==h(r/'commit-final.lean')));o=Path(x['command'][-1]);log=r/f"{x['phase']}-{x['module']}.log";tm=Path(x['command'][x['command'].index('-o')+1]);assert not o.is_symlink() and x['object_sha256']==h(o) and x['log_sha256']==h(log) and x['time']==tm.read_text()
 for n,d in x['inputs'].items():
  rel=n.replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p.resolve())==d['object'] and d['object_before']==d['object_after']==h(p)
  if d['source']:assert d['source_before']==d['source_after'] and (d['source_before']==h(d['source']) or (n.endswith('ArithmeticCellTransfer') and d['source_before']==h(r/'commit-parent.lean') and h(d['source'])==h(r/'commit-final.lean')))
  if n.endswith('ArithmeticCellTransfer'):assert d['object']==str(r/x['phase']/'DiophantineConsistency/ArithmeticCellTransfer.olean')
 print(x['phase'],x['module'],len(x['inputs']),'direct inputs verified')
for x in json.loads((r/'census-records.json').read_text()):
 log=r/f"{x['phase']}-{x['name']}.log";assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['direct_before']==x['direct_after']==h(x['direct_object']) and x['log_sha256']==h(log);print('probe',x['phase'],x['name'],'verified')
for n in ('interfaces','private'):assert (r/f'base-{n}.log').read_bytes()==(r/f'final-{n}.log').read_bytes();print(n,'identical')
# Current-source chain supporting the shared CellLabels object.
rr=json.loads(Path('/tmp/support-cast/refresh-records.json').read_text())
for n in ('ArithmeticCellLocal','ArithmeticCellLabels'):
 x=next(x for x in rr if x['phase']=='fresh' and x['module']==n);assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_sha256']==h(x['command'][-1]);print('provider',n,'source/object match fresh receipt')
 if n=='ArithmeticCellLabels':assert x['inputs']['DiophantineConsistency.ArithmeticCellLocal']['object_before']==next(y['object_sha256'] for y in rr if y['module']=='ArithmeticCellLocal' and y['phase']=='fresh')
print('four successful builds, eight direct input occurrences')
