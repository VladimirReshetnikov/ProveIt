from pathlib import Path
import os,subprocess,json,hashlib,re,time,sys
root=Path('/tmp/current-packing-positive-sharing');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=os.environ['LEAN_PATH'];records=[]
for phase in ['baseline','final']:
 srcroot=root/phase;out=root/('objects-'+phase);env=os.environ.copy();env['LEAN_PATH']=f'{out}:/tmp/current-packing-positive-sharing/common:/tmp/native-ordinary-source-root-7cz0jxs2/lib:/tmp/mask-ins-simplify/final:{base}'
 for mod in ['CurrentPositiveZero2011', 'CurrentWitnessEquivalence2011', 'CurrentPositiveZero2011Checks', 'CurrentWitnessEquivalence2011Checks']:
  src=srcroot/'DiophantineConsistency'/f'{mod}.lean'
  if not src.exists():src.write_bytes((repo/f'{mod}.lean').read_bytes())
  obj=out/'DiophantineConsistency'/f'{mod}.olean';log=root/f'{phase}-{mod}.log';tim=root/f'{phase}-{mod}.time';obj.unlink(missing_ok=True)
  deps=[]
  for name in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
   rel=name.replace('.','/')+'.olean';p=next((Path(s)/rel for s in env['LEAN_PATH'].split(':') if (Path(s)/rel).is_file()),None)
   if p is None:raise RuntimeError('missing '+name)
   deps.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':sha(p)})
  pre=sha(src);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tim),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(obj)];start=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for d in deps:d['after']=sha(d['path'])
  rec={'phase':phase,'module':mod,'status':r.returncode,'source':str(src),'before':pre,'after':sha(src),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tim.read_text(),'elapsed':round(time.monotonic()-start,2)};records.append(rec);(root/'records.json').write_text(json.dumps(records,indent=2)+'\n')
  print(phase,mod,r.returncode,rec['time'].strip(),flush=True)
  if r.returncode or pre!=rec['after'] or any(d['before']!=d['after'] for d in deps):sys.exit(1)
