import DiophantineConsistency.CurrentWitnessEquivalence2011
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.CurrentPositiveZero2011).isPrefixOf n ||
     (`DiophantineConsistency.CurrentWitnessEquivalence2011).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.CurrentPositiveZero2011" ||
     (toString n).startsWith "_private.DiophantineConsistency.CurrentWitnessEquivalence2011" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
