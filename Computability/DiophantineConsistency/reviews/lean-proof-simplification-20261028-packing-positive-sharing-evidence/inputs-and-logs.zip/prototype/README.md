# Shared packing-to-positive-zero construction

## Refreshed provider-chain replay (supersedes earlier samples below)

The earlier three-direct-provider refresh consumed an unmatched cached
ThirteenFreshSeed object `a0fce5e42c4c785a452f17a54908310b8b3fe4afeb75b72923fd08bc404c3b34`.
An attempted current-source rebuild failed because its cached
ThirteenCarrierSoundness lacked `affine_carrier_pos`; the failed command,
input pins and log remain in `refresh2-records.json` and
`refresh2-ThirteenFreshSeed.log`.

The subsequent `refresh3-records.json` records successful sequential builds
of current-source ThirteenCarrierSoundness, ThirteenFreshSeed, and
NativePositiveSourceConstruction. Their respective source hashes are
`50c6e6c5264f169638da56ac0791f8998c219a03c702faf025f13c719ab30ff7`,
`6ebf7f8df7557638a5be8e2e44aba62e65e214e51306e87037aac6a55f86dd2b`, and
`f96ba070ef8dac85ea4d63cf687efbee7b9f75f65e35ef498c9c028551bacf5d`;
their corresponding object hashes are
`6d33322be77d9f136fb00b5d55fc33f73ce3d26a2eff2ad6d1868579030a11e7`,
`422676d8eb9005a4b2af4bf7ebabcfb38e97287d3ef0da649b571f74fa763a18`, and
`8f764c39d545f79988b1c74961ce194aaeb201f04b5cfb269f3962c94cab97ef`.
The latter two receipts pin the preceding fresh object. The target replay
uses these alongside the earlier fresh CurrentHaltPacking2011 and
CurrentSoundness2011 providers.

The closure is still not source-matched. In particular, the freshly built
ThirteenCarrierSoundness directly consumes cached SignedPellResidue object
`45937af80eafe9cb6fd29e046d3f7f87b35d309da8f84bfdd9c99ae1347ab93a`.
The prior `prior-reused-provider-manifest.json` (SHA-256
`9a21ab835c005789828944b317d4421ac40e2349862e54c757e78337fd831835`)
records that same reused object and prior source hash
`46afed5402b7bf1a63d567e32906e28f4c06a26b1aab6c8788ef46a405a69fb4`;
current source hashes to
`ecd4dfbb29cc66499f65941f497640d48788284e8b52324d2ef8dba4fae772be`.
That manifest does not establish a current-source rebuild. Other transitive
inputs also remain cached; no whole-closure claim is made.

The new `records2.json` and `driver2.log` record successful paired targets
and both existing check clients. The two pairs of client objects are again
byte-identical, with hashes `a0032ba5…` and `d552c27d…` as below. Baseline /
final target user CPU was 2.96 / 2.96 s for PositiveZero and 2.59 / 2.20 s
for Witness; the separate `repeat2-records.json` gives 2.94 / 2.94 s and
2.62 / 2.29 s. These small shared-load samples are not general benchmarks.
An initial overlay setup failed because direct-provider symlinks were absent;
its unchanged evidence is saved under `setup-failure-*`, before the corrected
replay.

Fresh `probe2-records.json` and `name-probe2-records.json` pin the new
candidate objects. Every corresponding interface, simp, instance, short-name,
and opens output matches its earlier phase-specific log byte for byte;
therefore the precise generated-name and registration observations below
also hold for the refreshed provider chain. These checks do not exhaust all
possible imports or persistent environment extensions.

## Earlier source, experiments, and detailed observations

This is an isolated candidate; no repository sources have been edited. The
original baseline snapshots are:

- `baseline/DiophantineConsistency/CurrentPositiveZero2011.lean`:
  `cdbd33de5ccb176c253d1cfca41f1d34b8d0121790a4b06c5d38d461b72b648c`.
- `baseline/DiophantineConsistency/CurrentWitnessEquivalence2011.lean`:
  `2da5f02765c0c6a2856b8bd6e324cbd1fba3a98bd9d011b5e73190ebbb493758`.

The candidate snapshots are:

- `final/DiophantineConsistency/CurrentPositiveZero2011.lean`:
  `a81fa9662a77b8e0a1035b0b8f13791168e204c625518af35c40f2d14a90186c`.
- `final/DiophantineConsistency/CurrentWitnessEquivalence2011.lean`:
  `6e0d3305f00404373f0324ac25665cd2f8589d860bdf13e09771234c4f26f505`.

A new `CurrentPositiveZero2011.packing_positive_zero` theorem performs the
previously duplicated construction from the actual `ExistsPacking 0`.
The original `not_conZFC_positive_zero` still takes `¬ ConZFC` and obtains
that packing through `not_conZFC_constructs_packing`; the original
`blank_halts_positive_zero` still takes the explicit K215 blank halt and
obtains its packing through `blank_halts_constructs_packing`. Both retain
their exact endpoint statements and use the same packing-to-source proof;
imports and data are unchanged. The direct refutation endpoint is also
unchanged.

`refresh-records.json` records successful fresh source builds of direct
providers CurrentHaltPacking2011, NativePositiveSourceConstruction and
CurrentSoundness2011. Their fresh object hashes are `b08dd9fd…`, `e37bf4ee…`
and `4c2cbee2…`; all differ from the corresponding older pilot objects
`66978241…`, `f806f56f…` and `50883df9…`. The reason for those object
changes was not investigated. Direct input hashes and commands are in the
receipts. Their much larger transitive dependency closure remains cached and
may include pre-adoption objects, so this is not a complete current-source
closure rebuild. The initial `pilot.log`/`pilot.time` build used the older
reused provider set and is not current-provider validation.

`records.json` records successful paired current-direct-provider builds of
both targets and the existing CurrentPositiveZero2011Checks and
CurrentWitnessEquivalence2011Checks clients. Both pairs of check-client
objects are byte-identical (`a0032ba5…` and `d552c27d…`). Source, direct
input, output and log hashes are recorded. First baseline/final user CPU
samples were 2.96/3.14 s for PositiveZero and 2.68/2.21 s for Witness; one
paired repeat (`repeat-records.json`) gave 2.94/2.87 s and 2.53/2.21 s.
These shared-load samples do not establish a general performance difference.

`probe-records.json` records successful paired co-import probes of both
targets. All 22 common declaration/type/axiom blocks match, including the
original endpoints and their assumptions. Exactly two existing generated
public names disappear:

- `DiophantineConsistency.CurrentPositiveZero2011.not_conZFC_positive_zero._proof_1`.
- `DiophantineConsistency.CurrentWitnessEquivalence2011.blank_halts_positive_zero._proof_1`.

The added names are `CurrentPositiveZero2011.packing_positive_zero` and its
generated `packing_positive_zero._proof_1`. The two removed generated proof
type/axiom blocks are identical to each other and to the new generated proof
block. Global simp (55,579 entries) and instance (23,485 entries) reports match;
neither removed name appears in either baseline registration report.
Preserving those exact names would require retaining redundant elaboration or
writing aliases to compiler-generated declarations, which would obscure this
proof-sharing change and depend on implementation-generated names.

`name-probe-records.json` pins the two target objects for the checked co-import
environment. Only the new helper has the short name `packing_positive_zero`
in that environment; it and the qualified original endpoints resolve with
CurrentPositiveZero2011, CurrentWitnessEquivalence2011 and
CurrentHaltPacking2011 open. This does not prove absence of collisions in all
other possible co-imports or equality of every persistent environment
extension.

`search-records.json` documents a completed search of all tracked Lean files
and of 12 tracked endpoint-specific source/replay-report files: neither
removed generated name occurs. An initially broader search across tracked
Lean, Markdown, JSON and TeX was intentionally terminated after sustained
I/O; its empty partial log is not an exhaustive all-document result. The
searches were made before any potential adoption.
