import DiophantineConsistency.CurrentWitnessEquivalence2011
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  let s := toString n
  if s == "packing_positive_zero" || s.endsWith ".packing_positive_zero" then
   logInfo m!"SHORT {n}"
