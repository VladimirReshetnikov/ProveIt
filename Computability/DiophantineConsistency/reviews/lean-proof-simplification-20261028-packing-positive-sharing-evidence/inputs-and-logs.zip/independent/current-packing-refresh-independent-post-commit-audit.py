from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/tmp/current-packing-positive-sharing');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();root=json.loads(Path('/tmp/native-ordinary-source-root-7cz0jxs2/ROOT.json').read_text());providers={x['module']:x for x in root['selected_custom']};fresh={};rows={}
for x in json.loads((r/'refresh-records.json').read_text()):
 if x['module'] in ('CurrentHaltPacking2011','CurrentSoundness2011'):fresh[x['module']]=x
for x in json.loads((r/'refresh3-records.json').read_text()):
 n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source'])==h(r/('baseline-commit-'+n+'.lean') if n in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011') else repo/(n+'.lean')) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/('refresh3-'+n+'.time')).read_text()
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1]
  if m in fresh:assert d['resolved']==fresh[m]['object'] and d['before']==fresh[m]['object_sha256'];print('fresh input',n,m)
  elif m=='SignedPellResidue':
   man=json.loads(Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261028-evidence/manifest.json').read_text());q=next(q for q in man['reused_objects'] if q['source'].endswith('/SignedPellResidue.lean'));assert q['sha256']==d['before'];old=man['protected'][q['source']];current=h(repo/(m+'.lean'));assert old!=current and old==hashlib.sha256(subprocess.check_output(['git','show','92fe8ac532:'+q['source']])).hexdigest();print('cached historical',m,'source at inventory',old,'object',d['before'],'current source',current)
  else:
   q=providers[d['module']];src=Path('Computability/HilbertTenthProblem/Lean' if d['module'].startswith('Diophantine.Paper') else 'Computability/DiophantineConsistency/Lean')/(d['module'].replace('.','/')+'.lean');assert q['object']['sha256']==d['before'] and q['source']['sha256']==h(src);print('ROOT source/object match',m)
 fresh[n]=x;print('refresh3 build',n,'passed',x['time'].strip())
for x in json.loads((r/'records2.json').read_text()):
 ph=x['phase'];n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['log_sha256']==h(x['log']) and x['object_sha256']==h(x['object']) and x['time']==(r/('current2-'+ph+'-'+n+'.time')).read_text()
 if ph=='baseline' or n not in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011'):assert x['before']==h(r/('baseline-commit-'+n+'.lean') if n in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011') else repo/(n+'.lean'))
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1];y=fresh[m] if m in fresh else rows[(ph,m)];assert d['resolved']==y['object'] and d['before']==y['object_sha256']
 rows[(ph,n)]=x;print('fresh paired build',ph,n,x['time'].strip())
for x in json.loads((r/'probe2-records.json').read_text()):
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(x['log'])
 for o in x['objects']:assert o['before']==o['after']==h(o['path'])
 assert (r/('current2-'+x['phase']+'-'+x['probe']+'.log')).read_bytes()==(r/(x['phase']+'-'+x['probe']+'.log')).read_bytes();print('fresh probe matches original',x['phase'],x['probe'])
for n in ('CurrentPositiveZero2011Checks','CurrentWitnessEquivalence2011Checks'):print('fresh client objects match',n,rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'])
f=json.loads((r/'refresh2-records.json').read_text())[0];assert f['status']!=0 and f['log_sha256']==h(f['log']) and f['before']==f['after']==h(f['source']);print('earlier failed seed replay retained')
for x in json.loads((r/'name-probe2-records.json').read_text()):
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(x['log'])
 for o in x['objects']:assert o['before']==o['after']==h(o['path'])
 assert (r/('current2-'+x['phase']+'-'+x['probe']+'.log')).read_bytes()==(r/(x['phase']+'-'+x['probe']+'.log')).read_bytes();print('fresh name probe matches original',x['phase'],x['probe'])
for x in json.loads((r/'repeat2-records.json').read_text()):
 ph=x['phase'];n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object'])==rows[(ph,n)]['object_sha256'] and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1];y=fresh[m] if m in fresh else rows[(ph,m)];assert d['resolved']==y['object'] and d['before']==y['object_sha256']
 print('fresh repeat',ph,n,x['time'].strip())
f=json.loads((r/'setup-failure-records2.json').read_text())[0];assert f['status']!=0 and f['before']==f['after']==h(f['source']) and f['log_sha256']==h(r/'setup-failure-current2-baseline-CurrentPositiveZero2011.log') and f['time']==(r/'setup-failure-current2-baseline-CurrentPositiveZero2011.time').read_text();print('failed namespace-overlay setup preserved')
for n,x in json.loads((r/'search-records.json').read_text()).items():
 if n!='broad_documents':assert x['status']==1 and x['sha256']==h(r/x['log']);print('recorded scoped reference search',n,'no matches')
print('deeper direct inputs source/object matches were established by sampling current source after the build and comparing against historical ROOT receipts; no in-build current-source hashes were recorded')

import subprocess
for n in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011'):
 for phase,ref in [('baseline','c54276ca56^'),('final','c54276ca56')]:
  data=subprocess.check_output(['git','show',ref+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+n+'.lean']);assert data==(r/(phase+'-commit-'+n+'.lean')).read_bytes()==(r/phase/'DiophantineConsistency'/(n+'.lean')).read_bytes()
  if phase=='final':assert data==(repo/(n+'.lean')).read_bytes()
  print('git',phase,n,'snapshot verified')
