from pathlib import Path
import json,hashlib,re
r=Path('/tmp/current-packing-positive-sharing');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();root=json.loads(Path('/tmp/native-ordinary-source-root-7cz0jxs2/ROOT.json').read_text());assert root['status']=='PASS';providers={x['module']:x for x in root['selected_custom']};fresh={};rows={}
for x in json.loads((r/'refresh-records.json').read_text()):
 assert x['status']==0 and x['before']==x['after']==h(x['source'])==h(repo/(x['module']+'.lean')) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/('refresh-'+x['module']+'.time')).read_text()
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
  n=d['module'].split('.')[-1];a=providers[d['module']];source=h(r/('baseline-commit-'+n+'.lean') if n in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011') else repo/(n+'.lean'))
  if n=='ThirteenFreshSeed':
   assert a['object']['sha256']!=d['before'] and a['source']['sha256']!=source;print('UNMATCHED direct refreshed provider',n,'current source',source,'object',d['before'],'historical root source/object',a['source']['sha256'],a['object']['sha256'])
  else:assert a['object']['sha256']==d['before'] and a['source']['sha256']==source;print('ROOT source/object match',n)
 fresh[x['module']]=x;print('refreshed',x['module'],'passed',x['time'].strip())
for x in json.loads((r/'records.json').read_text()):
 ph=x['phase'];n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/(ph+'-'+n+'.time')).read_text()
 if ph=='baseline' or n not in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011'):assert x['before']==h(r/('baseline-commit-'+n+'.lean') if n in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011') else repo/(n+'.lean'))
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1];y=fresh[m] if m in fresh else rows[(ph,m)];assert y['object_sha256']==d['before'] and y['object']==d['resolved']
 rows[(ph,n)]=x;print('paired build',ph,n,x['time'].strip())
for f in ('probe-records.json','name-probe-records.json'):
 for x in json.loads((r/f).read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(x['log'])
  for o in x['objects']:assert o['before']==o['after']==h(o['path'])
  print('probe',x['phase'],x['probe'],'objects',len(x['objects']))
def parse(name):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',(r/name).read_text(),re.M|re.S)}
a=parse('baseline-interfaces.log');b=parse('final-interfaces.log');assert len(a)==len(b)==24 and all(a[n]==b[n] for n in a.keys()&b.keys());print('added',sorted(b.keys()-a.keys()),'removed',sorted(a.keys()-b.keys()))
assert a.keys()-b.keys()=={'DiophantineConsistency.CurrentPositiveZero2011.not_conZFC_positive_zero._proof_1','DiophantineConsistency.CurrentWitnessEquivalence2011.blank_halts_positive_zero._proof_1'}
assert b.keys()-a.keys()=={'DiophantineConsistency.CurrentPositiveZero2011.packing_positive_zero','DiophantineConsistency.CurrentPositiveZero2011.packing_positive_zero._proof_1'}
old=[a[n].split(' TYPE ',1)[1] for n in a.keys()-b.keys()];new=b['DiophantineConsistency.CurrentPositiveZero2011.packing_positive_zero._proof_1'].split(' TYPE ',1)[1];assert old[0]==old[1]==new;print('removed/generated replacement type and axiom blocks match')
for k in ('simp','instances'):
 t=(r/f'baseline-{k}.log').read_text();assert t==(r/f'final-{k}.log').read_text();print(k,'entries',len(t.splitlines()))
 for n in a.keys()-b.keys():assert n not in t
 print('removed generated names absent from',k)
assert (r/'baseline-short-names.log').read_text()=='' and 'CurrentPositiveZero2011.packing_positive_zero' in (r/'final-short-names.log').read_text();print('short-names and final namespace-open checks recorded')
for n in ('CurrentPositiveZero2011Checks','CurrentWitnessEquivalence2011Checks'):assert rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'];print('checks client identical',n)

import subprocess
for n in ('CurrentPositiveZero2011','CurrentWitnessEquivalence2011'):
 for phase,ref in [('baseline','c54276ca56^'),('final','c54276ca56')]:
  data=subprocess.check_output(['git','show',ref+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+n+'.lean']);assert data==(r/(phase+'-commit-'+n+'.lean')).read_bytes()==(r/phase/'DiophantineConsistency'/(n+'.lean')).read_bytes()
  if phase=='final':assert data==(repo/(n+'.lean')).read_bytes()
  print('git',phase,n,'snapshot verified')
