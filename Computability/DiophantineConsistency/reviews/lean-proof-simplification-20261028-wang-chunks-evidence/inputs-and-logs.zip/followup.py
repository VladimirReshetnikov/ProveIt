from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path('/tmp/wang-chunk-validation'); phase=sys.argv[1]; out=r/phase; overlay=out/'overlay'
repo=Path.cwd(); root=repo/'Computability/DiophantineConsistency/Lean'; env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','')
lean=['lean','-M7500','-j1','-DElab.async=false']; source=root/'DiophantineConsistency'/'WangTiles942Data.lean'; rr=root
if phase=='baseline': source=r/'source/DiophantineConsistency/WangTiles942Data.lean'; rr=r/'source'
tasks=[('target',source,rr,overlay/'DiophantineConsistency/WangTiles942Data.olean'),('table',root/'DiophantineConsistency/WangTiles942TableData.lean',root,overlay/'DiophantineConsistency/WangTiles942TableData.olean'),('core',root/'DiophantineConsistency/WangTiles942Core.lean',root,overlay/'DiophantineConsistency/WangTiles942Core.olean'),('focus',r/'focus.lean',root,None),('axioms',r/'axioms.lean',root,None)]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
tasks=tasks[3:]
for name,src,rt,obj in tasks:
 cmd=lean+['-R',str(rt),str(src)]+(['-o',str(obj)] if obj else [])
 start=time.monotonic();cp=subprocess.run(['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(out/(name+'.time'))]+cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=360)
 log=out/(name+'.log');log.write_bytes(cp.stdout)
 rec={'name':name,'status':cp.returncode,'seconds':time.monotonic()-start,'cmd':cmd,'source':str(src),'source_sha256':sha(src),'log_sha256':sha(log),'timing':(out/(name+'.time')).read_text().strip(),'object_sha256':sha(obj) if obj and obj.exists() else None,'object_bytes':obj.stat().st_size if obj and obj.exists() else None}
 records.append(rec);(out/'records-followup.json').write_text(json.dumps(records,indent=2)+'\n');print(name,cp.returncode,round(rec['seconds'],2),flush=True)
 if cp.returncode:break
