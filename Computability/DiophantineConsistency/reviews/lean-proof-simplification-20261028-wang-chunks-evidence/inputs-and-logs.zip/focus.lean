import DiophantineConsistency.WangTiles942Data
open DiophantineConsistency.WangTiles942
example : action ⟨0, by decide⟩ = DiophantineConsistency.DecimalMachine215.action 0 := action_eq_decoder ⟨0, by decide⟩
example : action ⟨429, by decide⟩ = DiophantineConsistency.DecimalMachine215.action 429 := action_eq_decoder ⟨429, by decide⟩
example (d : Bool) : (railCache d)[0]?.getD 0 = railFormula d 0 := railCache_eq_formula d ⟨0, by decide⟩
example (d : Bool) : (railCache d)[215]?.getD 0 = railFormula d 215 := railCache_eq_formula d ⟨215, by decide⟩
