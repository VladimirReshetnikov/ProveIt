from pathlib import Path
import json,hashlib
r=Path('/tmp/controller-stride-period');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); builds={}
for f in ['common-records.json','baseline-records.json','variant2-records.json','baseline-r1-records.json','variant2-r1-records.json','baseline-r2-records.json','variant2-r2-records.json','final-records.json']:
 for x in json.loads((r/f).read_text()):
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
  builds[(x['phase'],x['module'])]=x;print('build',f,x['module'],'direct',len(x['direct_inputs']),'verified')
for ph in ('baseline','variant2'):
 for n in ('names','interfaces','simp','instances'):
  x=json.loads((r/f'probe-{n}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==builds[(ph,'ArithmeticControllerStride')]['object_sha256'] and x['log_sha256']==h(x['log']);print('probe',ph,n,'verified')
for n in ('names','interfaces','simp','instances'): assert (r/f'baseline-{n}.log').read_bytes()==(r/f'variant2-{n}.log').read_bytes(); print(n,'equal',len((r/f'baseline-{n}.log').read_text().splitlines()))
assert builds[('baseline','ArithmeticController')]['object_sha256']==builds[('variant2','ArithmeticController')]['object_sha256']
assert builds[('baseline','ArithmeticControllerStride')]['before']==h(r/'baseline-commit.lean')
assert builds[('variant2','ArithmeticControllerStride')]['before']==h(r/'variant2-commit.lean')==h(repo/'ArithmeticControllerStride.lean')
for n in ('ArithmeticController','ArithmeticControllerChoice'): assert builds[('baseline' if n=='ArithmeticController' else 'common',n)]['before']==h(repo/(n+'.lean'))
print('workspace snapshots match baseline/unchanged client and common provider; clients identical')
data=next(x for x in json.loads(Path('/tmp/origin-block-sharing/records.json').read_text()) if x['phase']=='final' and x['module']=='ArithmeticControllerData'); assert data['status']==0 and data['source_before']==h(repo/'ArithmeticControllerData.lean') and data['object_sha256']==builds[('baseline','ArithmeticControllerStride')]['direct_inputs'][0]['before']==h(builds[('baseline','ArithmeticControllerStride')]['direct_inputs'][0]['path']);print('ControllerData current source and prior object match')
print('prior ControllerData record keys',sorted(data.keys()))
failed=json.loads((r/'failed-initial-records.json').read_text())[0];assert failed['status']!=0 and failed['before']==h(r/'failed-initial.lean') and failed['log_sha256']==h(r/'failed-initial.log') and failed['time']==(r/'failed-initial.time').read_text();print('relocated failed source, log and timing match')
initial=json.loads((r/'variant2-initial-target-records.json').read_text())[0];assert initial['before']==h(initial['source']) and initial['object_sha256']==h(initial['object']) and initial['log_sha256']==h(initial['log']);print('earlier variant2 source/object/log match; recorded time matches current file:',initial['time']==Path(initial['command'][initial['command'].index('-o')+1]).read_text())
cyc=next(x for x in json.loads(Path('/tmp/outer-seed-bound-sharing/assembly-builds2.json').read_text()) if x['module']=='DiophantineConsistency.ArithmeticCyclicWord');obj=Path('/tmp/controller-stride-period/objects-variant2/DiophantineConsistency/ArithmeticCyclicWord.olean');assert cyc['status']==0 and cyc['object_sha256']==h(obj) and cyc['source_sha256']==h(repo/'ArithmeticCyclicWord.lean');print('transitive CyclicWord current source and prior object match')
cantor=next(x for x in json.loads(Path('/tmp/dag-independent-audit/fol-refresh-records.json').read_text()) if x['module']=='BusyBeaver.ZFC.ArithmeticCantor'); assert cantor['status']==0 and cantor['source_sha256']==cantor['source_after']==h(cantor['source']) and cantor['object_sha256']==h(cantor['object'])==builds[('common','ArithmeticControllerChoice')]['direct_inputs'][1]['before'];print('common-provider Cantor current source and prior object match')
inp=data['inputs']['DiophantineConsistency.ArithmeticPackingBlocks'];block=next(x for x in json.loads(Path('/tmp/origin-block-sharing/records.json').read_text()) if x['phase']=='final' and x['module']=='ArithmeticPackingBlocks' and x['status']==0);assert inp['source_before']==inp['source_after'] and inp['object_before']==inp['object_after']==h(inp['object'])==block['object_sha256'] and block['source_before']==block['source_after']==h(block['source'])==h(inp['source']);print('ControllerData PackingBlocks object matches current final source receipt; workspace source sample was pre-adoption')

import subprocess
p='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticControllerStride.lean'
for phase,ref in [('baseline','61116bd1db^'),('variant2','61116bd1db')]:
 data=subprocess.check_output(['git','show',ref+':'+p]);assert data==(r/(phase+'-commit.lean')).read_bytes()==(r/phase/'DiophantineConsistency/ArithmeticControllerStride.lean').read_bytes();print('commit',phase,'source matches snapshot')
