from pathlib import Path
import json,subprocess,hashlib,os,sys
R=Path('/tmp/controller-stride-period'); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for probe in sys.argv[1:]:
 for phase in ['baseline','variant2']:
  obj=R/f'objects-{phase}/DiophantineConsistency/ArithmeticControllerStride.olean'; source=R/f'{probe}.lean'; log=R/f'{phase}-{probe}.log';env=os.environ.copy();env['LEAN_PATH']=str(R/f'objects-{phase}')+':/tmp/mask-ins-simplify/final:'+base+':/home/codex/src/Proofs/.lake/build/lib/lean';before=sha(source); ob=sha(obj);cmd=['lean','-M10000','-j1','-DElab.async=false',str(source)]
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  x=dict(probe=probe,phase=phase,status=r.returncode,command=cmd,LEAN_PATH=env['LEAN_PATH'],source=str(source),source_before=before,source_after=sha(source),object=str(obj),object_before=ob,object_after=sha(obj),log=str(log),log_sha256=sha(log));records.append(x);(R/f'probe-{probe}-{phase}.json').write_text(json.dumps(x,indent=2)+'\n');print(probe,phase,r.returncode,flush=True)
  if r.returncode:raise SystemExit(1)
