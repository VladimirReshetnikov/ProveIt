import DiophantineConsistency.ArithmeticControllerStride
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticControllerStride).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticControllerStride" then
   logInfo m!"DECL {n}"
