from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/tmp/arithmetic-shared-literal');phase=sys.argv[1];base=Path('Computability/DiophantineConsistency/Lean'); env=os.environ.copy();env['LEAN_PATH']=str(root/phase/'lib')+':'+env.get('LEAN_PATH','')
names=['ArithmeticCarrierSoundness2011','ArithmeticConstructionZero']; rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in names:
 src=(root/'original-source' if phase.startswith('baseline') else root/'probe')/'DiophantineConsistency'/(n+'.lean')
 out=root/phase/'lib'/'DiophantineConsistency'/(n+'.olean')
 cmd=['/usr/bin/time','-f','elapsed=%e rss=%M','-o',str(root/f'{phase}-{n}.time'),'lean','-M6000','-j1','-DElab.async=false','-R',str(root/'original-source' if phase.startswith('baseline') else root/'probe'),str(src),'-o',str(out)]
 t=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True);log=root/f'{phase}-{n}.log';log.write_bytes(p.stdout+p.stderr);item={'source':str(src),'source_sha256':sha(src),'command':cmd,'status':p.returncode,'seconds':time.monotonic()-t,'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None,'object_bytes':out.stat().st_size if out.exists() else None};rows.append(item);print(phase,n,p.returncode,flush=True)
 if p.returncode:break
(root/f'{phase}-builds.json').write_text(json.dumps(rows,indent=2)+'\n')
if len(rows)!=2 or any(r['status'] for r in rows):sys.exit(1)
