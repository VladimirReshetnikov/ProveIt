from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/tmp/arithmetic-shared-literal');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(root/phase/'lib')+':'+env.get('LEAN_PATH','')
base=Path('Computability/DiophantineConsistency/Lean'); checks={'focus':base/'DiophantineConsistency/ArithmeticCarrierSoundness2011Checks.lean','axioms':root/'old-axioms.lean'}
if phase.startswith('final'):checks['helpers']=root/'helper-axioms.lean'
rows=[]
for label,src in checks.items():
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(base),str(src)];t=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True);log=root/f'{phase}-{label}.log';log.write_bytes(p.stdout+p.stderr);rows.append({'label':label,'command':cmd,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'status':p.returncode,'seconds':time.monotonic()-t,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});print(phase,label,p.returncode,flush=True)
(root/f'{phase}-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['status'] for r in rows):sys.exit(1)
