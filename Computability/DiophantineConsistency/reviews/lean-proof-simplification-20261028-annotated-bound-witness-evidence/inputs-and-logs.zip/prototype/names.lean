import DiophantineConsistency.AnnotatedBound
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.AnnotatedBound).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.AnnotatedBound" then
   logInfo m!"DECL {n}"
