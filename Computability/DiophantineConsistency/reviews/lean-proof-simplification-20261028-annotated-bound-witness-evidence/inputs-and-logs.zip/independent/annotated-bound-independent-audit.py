from pathlib import Path
import json,hashlib,subprocess
R=Path('/tmp/annotated-bound-witness');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=['directverify-records.json','common-prior-records.json','common2-records.json','base2-records.json','v3fresh-records.json','base2a-records.json','v3fresha-records.json','base2b-records.json','v3freshb-records.json']; byfile={}
for f in files:
 recs=json.load(open(R/f));byfile[f]=recs
 for x in recs:
  assert x['status']==0 and x['before']==x['after']==sha(x['source']) and x['object_sha256']==sha(x['object']) and x['log_sha256']==sha(x['log'])
  cmd=x['command'];t=Path(cmd[cmd.index('-o')+1]);assert t.read_text()==x['time'],(f,x['module'],'time')
  for d in x['direct_inputs']:
   assert d['before']==d['after']==sha(d['path'])==sha(d['resolved']),(f,x['module'],d['module'])
  p=repo/(x['module']+'.lean')
  if p.exists() and x['module'] != 'AnnotatedBound':assert sha(p)==x['before'],(f,x['module'],'workspace')
  if p.exists() and x['module'] == 'AnnotatedBound' and sha(p)!=x['before']:
   assert x['before']==sha(R/'baseline/DiophantineConsistency/AnnotatedBound.lean')
   assert sha(p)==sha(R/'variant3/DiophantineConsistency/AnnotatedBound.lean')
   print('HISTORICAL WORKSPACE',f,x['before'],'current',sha(p))
  print('BUILD',f,x['module'],'OK',x['object_sha256'],x['time'].strip())
prior=byfile['common-prior-records.json']; shared=byfile['directverify-records.json']+[x for x in prior if x['module']=='NatIterate']+byfile['common2-records.json'];providers={x['module']:x['object_sha256'] for x in shared}
for phase in ('base2','v3fresh'):
 allrecs=shared+byfile[phase+'-records.json'];expected={x['module']:x['object_sha256'] for x in allrecs}
 for x in allrecs:
  for d in x['direct_inputs']:
   n=d['module'].split('.')[-1]
   if n in expected:assert d['before']==expected[n],(phase,x['module'],n)
 print('PROJECT PROVIDER CHAIN',phase,'OK')
assert sha(R/'variant3/DiophantineConsistency/AnnotatedBound.lean')==sha(R/'v3fresh/DiophantineConsistency/AnnotatedBound.lean')
for k in ('names','interfaces','simp','instances'):
 for ph in ('base2','v3fresh'):
  x=json.load(open(R/f'probe-{k}-{ph}.json'));assert x['status']==0 and x['source_before']==x['source_after']==sha(x['source']) and x['object_before']==x['object_after']==sha(x['object']) and x['log_sha256']==sha(x['log'])
 a=R/f'base2-{k}.log';b=R/f'v3fresh-{k}.log';assert a.read_bytes()==b.read_bytes();print('PROBE',k,'MATCH',len(a.read_text().splitlines()),sha(a))
for mod in ('AnnotatedBoundLocal','AnnotatedBoundScan'):
 a=R/'objects-base2/DiophantineConsistency'/(mod+'.olean');b=R/'objects-v3fresh/DiophantineConsistency'/(mod+'.olean');assert sha(a)==sha(b);print('CLIENT',mod,'IDENTICAL',sha(a))
for f in ('repeatbaseline1-records.json','repeatfinal1-records.json','repeatbaseline2-records.json','repeatfinal2-records.json','variant2-records.json','repeatbaseline3-records.json','repeatvariant3a-records.json','repeatbaseline4-records.json','repeatvariant3b-records.json'):
 for x in json.load(open(R/f)):
  assert x['status']==0 and x['before']==x['after']==sha(x['source']) and x['object_sha256']==sha(x['object']) and x['log_sha256']==sha(x['log'])
  t=Path(x['command'][x['command'].index('-o')+1]);assert t.read_text()==x['time']
  for d in x['direct_inputs']:assert d['before']==d['after']==sha(d['path'])==sha(d['resolved'])
  print('HISTORICAL',f,'OK',x['time'].strip())

commit='fc85f9a87dee2b62622ef495ffdc8ea590941e10';target='Computability/DiophantineConsistency/Lean/DiophantineConsistency/AnnotatedBound.lean'
for phase,ref,snapshot in [('baseline',commit+'^','baseline'),('final',commit,'variant3')]:
 b=subprocess.check_output(['git','show',ref+':'+target]);p=R/snapshot/'DiophantineConsistency/AnnotatedBound.lean';assert hashlib.sha256(b).hexdigest()==sha(p)
 print('GIT',phase,ref,'snapshot',sha(p),'workspace',sha(target),'matches',sha(p)==sha(target))
