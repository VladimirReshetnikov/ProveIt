from pathlib import Path
p=Path('/tmp/word-origin-sharing');base=p/'common'
for ph in ('baseline','final'):
 root=p/ph
 for x in base.iterdir():
  dest=root/x.name
  if x.name=='DiophantineConsistency':
   dest.mkdir(exist_ok=True)
   for f in x.iterdir():
    if f.is_file():
     out=dest/f.name
     if not out.exists():out.symlink_to(f.resolve())
  elif not dest.exists():dest.symlink_to(x.resolve(),target_is_directory=x.is_dir())
 print(ph,'prepared')
