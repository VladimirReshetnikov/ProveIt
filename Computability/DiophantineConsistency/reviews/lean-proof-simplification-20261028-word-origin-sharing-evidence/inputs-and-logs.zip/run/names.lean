import Lean.Elab.Command
import DiophantineConsistency.CurrentWordOrigin2011
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.CurrentWordOrigin2011).isPrefixOf n ||
       (n.toString.startsWith "_private.DiophantineConsistency.CurrentWordOrigin2011.") then
      logInfo m!"DECL {n}"
