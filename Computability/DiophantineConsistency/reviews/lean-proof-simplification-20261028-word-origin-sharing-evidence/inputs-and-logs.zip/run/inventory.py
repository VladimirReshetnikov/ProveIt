from pathlib import Path
import os,json,hashlib,shutil,subprocess
p=Path('/tmp/word-origin-sharing');g=json.loads((p/'graph.json').read_text());old=json.loads(Path('/tmp/word-padding-sharing/post-copies-inventory.json').read_text());prior={x['module']:x for x in old['local']};h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();paths=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip().split(':');targets={'CurrentWordOrigin2011','MFCurrentWordOrigin2011','CurrentWordOrigin2011Checks','CurrentWordHighMask2011'};commons={x['name'] for x in json.loads((p/'common-records.json').read_text())};seeds={'CurrentWordClause2011','MFCurrentWordClause2011'};rows=[];issues=[]
for n,v in g['nodes'].items():
 name=n.split('.')[-1]; row={'module':n,'imports':v['imports'],'phase':{}}
 for ph in ('baseline','final'):
  f=(p/ph/'DiophantineConsistency'/(name+'.lean')) if name in ('CurrentWordOrigin2011','MFCurrentWordOrigin2011') else Path(v['source']);q=p/ph/(n.replace('.','/')+'.olean')
  if not f.exists() or not q.exists():issues.append([n,ph,'missing']);continue
  fs=h(f);obj=h(q)
  if name not in ('CurrentWordOrigin2011','MFCurrentWordOrigin2011') and fs!=v['sha256']:issues.append([n,ph,'source drift'])
  if name in targets:status='phase rebuilt'
  elif name in commons:status='shared rebuilt'
  elif name in seeds:status='committed clause receipt'
  else:
   z=prior.get(n,{}).get('phase',{}).get('final',{});status='matched previous selected object' if z.get('object_sha256')==obj and z.get('source_sha256')==fs else 'unmatched cached'
  row['phase'][ph]={'source':str(f.resolve()),'source_sha256':fs,'object':str(q.resolve()),'object_sha256':obj,'status':status}
  snap=p/'sources'/ph/(n.replace('.','/')+'.lean');snap.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,snap)
 if len(row['phase'])==2 and name not in targets and row['phase']['baseline']['object_sha256']!=row['phase']['final']['object_sha256']:issues.append([n,'phase object mismatch'])
 rows.append(row)
external=[]
for n in g['external']:
 q=None
 for b in paths:
  b=Path(b)
  if (b/n.split('.')[0]).exists():
   a=b/(n.replace('.','/')+'.olean')
   if a.exists():q=a;break
   issues.append([n,'external shadow missing']);break
 if q is None:issues.append([n,'external missing']);continue
 external.append({'module':n,'path':str(q.resolve()),'sha256':h(q)})
report={'local':rows,'external':external,'issues':issues};(p/'inventory.json').write_text(json.dumps(report,indent=2)+'\n');from collections import Counter
print('local',len(rows),'external',len(external),'issues',issues,'status',Counter(x['phase']['final']['status'] for x in rows if 'final' in x['phase']));assert not issues
