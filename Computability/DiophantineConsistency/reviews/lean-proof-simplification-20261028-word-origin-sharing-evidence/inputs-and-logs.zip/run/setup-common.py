from pathlib import Path
import json,os,hashlib
p=Path('/tmp/word-origin-sharing');base=Path('/tmp/word-padding-sharing/post-copies-final');out=p/'common';out.mkdir(exist_ok=True);h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for x in base.iterdir():
 if x.name=='DiophantineConsistency':
  d=out/x.name;d.mkdir(exist_ok=True)
  for f in x.iterdir():
   if f.is_file():
    t=d/f.name
    if not t.exists():t.symlink_to(f.resolve())
 elif not (out/x.name).exists(): (out/x.name).symlink_to(x.resolve(),target_is_directory=x.is_dir())
records=json.loads(Path('/tmp/word-clause-sharing/build-records.json').read_text());checked=[]
for n in ('MFCurrentWordClause2011','CurrentWordClause2011'):
 r=next(x for x in records if x['phase']=='final' and x['name']==n)
 for a in r['direct_inputs']:
  m=a['module'];top=m.split('.')[0];f=out/(m.replace('.','/')+'.olean')
  if not (out/top).exists():continue
  assert f.exists() and h(f)==a['sha256'],(n,m,'input mismatch')
 src=Path(r['object']);assert h(src)==r['object_sha256'];dst=out/'DiophantineConsistency'/(n+'.olean');dst.unlink(missing_ok=True);dst.symlink_to(src.resolve());checked.append({'module':n,'source':r['source'],'source_sha256':r['source_sha256'],'object':str(src),'object_sha256':r['object_sha256'],'direct_inputs':r['direct_inputs']})
(p/'clause-seeds.json').write_text(json.dumps(checked,indent=2)+'\n');print('validated clause inputs and selected both final objects')
