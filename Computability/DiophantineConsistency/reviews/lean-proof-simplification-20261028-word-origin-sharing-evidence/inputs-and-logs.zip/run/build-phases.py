from pathlib import Path
import json,os,subprocess,hashlib,time,shutil
p=Path('/tmp/word-origin-sharing');g=json.loads((p/'graph.json').read_text())['nodes'];path=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
for ph in ('baseline','final'):
 for name in ('MFCurrentWordOrigin2011','CurrentWordOrigin2011','CurrentWordOrigin2011Checks','CurrentWordHighMask2011'):
  if shutil.disk_usage('.').free<850*1024*1024:raise RuntimeError('disk below 850 MiB reserve')
  module='DiophantineConsistency.'+name;root=p/ph;f=(root/'DiophantineConsistency'/(name+'.lean')) if 'Checks' not in name and name!='CurrentWordHighMask2011' else Path(g[module]['source']);out=root/'DiophantineConsistency'/(name+'.olean');log=p/(ph+'-'+name+'.log');tm=p/(ph+'-'+name+'.time');env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+path
  inputs=[]
  for n in g[module]['imports']:
   if n not in g:continue
   q=root/(n.replace('.','/')+'.olean');assert q.exists(),(ph,name,n,'missing');inputs.append({'module':n,'path':str(q.resolve()),'sha256':h(q)})
  out.unlink(missing_ok=True);before=h(f);srcroot=str(root) if f.is_relative_to(root) else 'Computability/DiophantineConsistency/Lean';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',srcroot,str(f),'-o',str(out)]
  with log.open('wb') as o:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT).returncode
  rec={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(f),'source_sha256':before,'source_after':h(f),'direct_inputs':inputs,'direct_inputs_after':[h(x['path']) for x in inputs],'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,3)};records.append(rec);(p/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True)
  assert rc==0 and rec['source_sha256']==rec['source_after'] and [x['sha256'] for x in inputs]==rec['direct_inputs_after']
