from pathlib import Path
import os,subprocess,hashlib,json,time
p=Path('/tmp/word-origin-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();path=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();rs=[]
for ph in ('baseline','final'):
 for tag in ('imports',):
  f=p/(tag+'.lean');log=p/(ph+'-'+tag+'.log');tm=p/(ph+'-'+tag+'.time');env=os.environ.copy();env['LEAN_PATH']=str(p/ph)+':'+path;before=h(f);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p),str(f)]
  with log.open('wb') as o:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT).returncode
  r={'phase':ph,'tag':tag,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source_sha256':before,'source_after':h(f),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,3)};rs.append(r);(p/'import-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,tag,rc,flush=True);assert rc==0 and before==r['source_after']
