from pathlib import Path
import json,os,subprocess,hashlib,time,shutil
p=Path('/tmp/word-origin-sharing');base=p/'common';g=json.loads((p/'graph.json').read_text())['nodes']; path=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip(); env=os.environ.copy();env['LEAN_PATH']=str(base)+':'+path; h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
names=('MFCurrentWordCopies2011','MFCurrentWordPadding2011','MFCurrentWordTopBounds2011','CurrentWordCopies2011','CurrentWordPadding2011','CurrentWordTopBounds2011')
for name in names:
 if shutil.disk_usage('.').free<850*1024*1024:raise RuntimeError('disk reserve below 850 MiB')
 module='DiophantineConsistency.'+name; f=Path(g[module]['source']);out=base/'DiophantineConsistency'/(name+'.olean');log=p/('common-'+name+'.log');tm=p/('common-'+name+'.time')
 inputs=[]
 for n in g[module]['imports']:
  if n not in g:continue
  q=base/(n.replace('.','/')+'.olean')
  assert q.exists(),(name,n,'missing direct input');inputs.append({'module':n,'path':str(q.resolve()),'sha256':h(q)})
 before=h(f);out.unlink(missing_ok=True);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(f),'-o',str(out)]
 with log.open('wb') as o:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT).returncode
 rec={'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(f),'source_sha256':before,'source_after':h(f),'direct_inputs':inputs,'direct_inputs_after':[h(x['path']) for x in inputs],'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,3)};records.append(rec);(p/'common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,rc,flush=True)
 assert rc==0 and rec['source_sha256']==rec['source_after'] and [x['sha256'] for x in inputs]==rec['direct_inputs_after']
