import DiophantineConsistency.CurrentWordOrigin2011
import DiophantineConsistency.MFCurrentWordOrigin2011
open DiophantineConsistency
example {n : ℕ} [NeZero n] (s : ℤ) (a : ZMod n → Fin 942) :
    WangTiles942Periodic.MarkedWord n s a ↔ MF.WangTiles942Periodic.MarkedWord n s a := by
  constructor <;> intro h
  · exact ⟨h.start_at_zero, h.horizontal, h.temporal⟩
  · exact ⟨h.start_at_zero, h.horizontal, h.temporal⟩
example {n : ℕ} [NeZero n] (c k digits : ZMod n → ℕ) (W : ℕ) :
    CurrentCarryConstruction2011.Facts c W k digits ↔ MF.CurrentCarryConstruction2011.Facts c W k digits := by
  constructor <;> intro h
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
example {N : ℕ} (a : ZMod N → Fin 942) (dummy : ZMod N → ℕ) (s : ℕ) :
    CurrentWordCopies2011.constructedWord a dummy s = MF.CurrentWordCopies2011.constructedWord a dummy s := rfl
