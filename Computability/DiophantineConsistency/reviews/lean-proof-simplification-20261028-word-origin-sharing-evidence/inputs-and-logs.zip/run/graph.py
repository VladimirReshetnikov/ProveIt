from pathlib import Path
import re,json,hashlib,tomllib
p=Path('/tmp/word-origin-sharing');W=Path.cwd();roots=list(dict.fromkeys((W/x.get('srcDir','.')).resolve() for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']));h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[]
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(f):
 out=[]
 for line in strip(Path(f).read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out
G={};E=set();sources={}
def visit(n):
 if n in G or n in E:return
 if n in ('DiophantineConsistency.CurrentWordOrigin2011','DiophantineConsistency.MFCurrentWordOrigin2011'):
  f=p/'final/DiophantineConsistency'/(n.split('.')[-1]+'.lean')
 else:
  loc=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
  if not loc:E.add(n);return
  if len(loc)!=1:issues.append(['ambiguous',n]);return
  f=loc[0]
 im=imports(f);G[n]=im;sources[n]={'source':str(f),'sha256':h(f),'imports':im}
 for a in im:visit(a)
for n in ('CurrentWordOrigin2011','MFCurrentWordOrigin2011','CurrentWordOrigin2011Checks','CurrentWordHighMask2011'):visit('DiophantineConsistency.'+n)
result={'nodes':sources,'external':sorted(E),'issues':issues};(p/'graph.json').write_text(json.dumps(result,indent=2)+'\n');print('local',len(G),'external',len(E),'clause',[x for x in G if 'WordClause2011' in x]);assert not issues
