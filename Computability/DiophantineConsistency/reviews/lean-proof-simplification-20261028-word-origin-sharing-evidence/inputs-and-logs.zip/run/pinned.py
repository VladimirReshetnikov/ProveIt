from pathlib import Path
import json,os,subprocess,hashlib,time,shutil
p=Path('/tmp/word-origin-sharing');inv=json.loads((p/'inventory.json').read_text());g=json.loads((p/'graph.json').read_text())['nodes'];lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
targets={'DiophantineConsistency.'+x for x in ('MFCurrentWordOrigin2011','CurrentWordOrigin2011','CurrentWordOrigin2011Checks','CurrentWordHighMask2011')}
def pin(ph,root):
 for x in inv['local']:
  n=x['module']
  if n in targets:continue
  v=x['phase'][ph];src=Path(v['source']);snapshot=p/'sources'/ph/(n.replace('.','/')+'.lean');obj=root/(n.replace('.','/')+'.olean')
  assert h(src)==h(snapshot)==v['source_sha256'],(ph,n,'source mismatch')
  assert obj.exists() and h(obj)==v['object_sha256'],(ph,n,'object mismatch')
 for x in inv['external']:assert h(x['path'])==x['sha256'],(ph,x['module'],'external mismatch')
for ph in ('baseline','final'):
 orig=p/ph;root=p/('pinned-'+ph);root.mkdir(exist_ok=True)
 for x in orig.iterdir():
  t=root/x.name
  if x.name=='DiophantineConsistency':
   t.mkdir(exist_ok=True)
   for f in x.iterdir():
    if f.is_file():
     q=t/f.name
     if not q.exists():q.symlink_to(f.resolve())
  elif not t.exists():t.symlink_to(x.resolve(),target_is_directory=x.is_dir())
 env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp
 for name in ('MFCurrentWordOrigin2011','CurrentWordOrigin2011','CurrentWordOrigin2011Checks','CurrentWordHighMask2011'):
  if shutil.disk_usage('.').free < 850*1024*1024:raise RuntimeError('disk reserve below 850 MiB')
  n='DiophantineConsistency.'+name;f=p/'sources'/ph/'DiophantineConsistency'/(name+'.lean');out=root/'DiophantineConsistency'/(name+'.olean');log=p/(ph+'-pinned-'+name+'.log');tm=p/(ph+'-pinned-'+name+'.time');pin(ph,root);inputs=[]
  for d in g[n]['imports']:
   if d not in g:continue
   q=root/(d.replace('.','/')+'.olean');assert q.exists(),(name,d);inputs.append({'module':d,'path':str(q.resolve()),'sha256':h(q)})
  out.unlink(missing_ok=True);before=h(f);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p/'sources'/ph),str(f),'-o',str(out)]
  with log.open('wb') as o:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT).returncode
  pin(ph,root);rec={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(f),'source_sha256':before,'source_after':h(f),'object':str(out),'object_sha256':h(out) if out.exists() else None,'original_object_sha256':h(orig/'DiophantineConsistency'/(name+'.olean')),'log_sha256':h(log),'time_sha256':h(tm),'local_pins':len(inv['local'])-len(targets),'external_pins':len(inv['external']),'pins_verified_before_after':True,'direct_inputs':inputs,'direct_inputs_after':[h(x['path']) for x in inputs],'elapsed':round(time.monotonic()-t,3)};records.append(rec);(p/'pinned-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True)
  assert rc==0 and rec['source_sha256']==rec['source_after'] and rec['object_sha256']==rec['original_object_sha256'] and [x['sha256'] for x in inputs]==rec['direct_inputs_after']
