from pathlib import Path
import hashlib,json
p=Path('/tmp/word-origin-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=json.loads((p/'pinned-records.json').read_text());assert len(rs)==8
for r in rs:
 c=r['command'];assert r['status']==0 and c[-2]=='-o' and h(r['source'])==r['source_sha256']==r['source_after'] and h(r['object'])==r['object_sha256']==r['original_object_sha256'];assert h(c[4])==r['time_sha256'] and h(p/(r['phase']+'-pinned-'+r['name']+'.log'))==r['log_sha256'];assert r['pins_verified_before_after'] and r['local_pins']==164 and r['external_pins']==65
 assert [d['sha256'] for d in r['direct_inputs']]==r['direct_inputs_after']
 for d in r['direct_inputs']:assert h(d['path'])==d['sha256'],d['module']
print('eight pinned replay records, reproducible phase objects, direct inputs and logs verified')
