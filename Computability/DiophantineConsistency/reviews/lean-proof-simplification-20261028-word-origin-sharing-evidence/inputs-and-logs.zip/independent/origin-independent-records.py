from pathlib import Path
import json,hashlib
p=Path('/tmp/word-origin-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();count=0
for fn in ('common-records.json','phase-records.json'):
 for r in json.loads((p/fn).read_text()):
  prefix=r.get('phase','common');tag=r['name'];cmd=r['command'];assert r['status']==0 and cmd[-2]=='-o' and Path(cmd[-1]).resolve()==Path(r['object']).resolve();assert h(r['source'])==r['source_sha256']==r['source_after'];assert h(r['object'])==r['object_sha256'];assert h(p/(prefix+'-'+tag+'.log'))==r['log_sha256'] and h(cmd[4])==r['time_sha256'];assert r['lean_path'].split(':')[0]==str(p/(prefix if prefix!='common' else 'common'));assert [d['sha256'] for d in r['direct_inputs']]==r['direct_inputs_after']
  for d in r['direct_inputs']:assert h(d['path'])==d['sha256'],(prefix,tag,d['module'])
  count+=1
print(count,'common/paired records and direct object inputs checked')
for fn in ('probe-records.json','interface-records.json','simp-compat-records.json'):
 for r in json.loads((p/fn).read_text()):
  cmd=r['command'];phase=r['phase'];tag=r['tag'];src=p/(tag+'.lean');assert r['status']==0 and h(src)==r['source_sha256']==r['source_after'] and h(p/(phase+'-'+tag+'.log'))==r['log_sha256'] and h(cmd[4])==r['time_sha256'];assert r['lean_path'].split(':')[0]==str(p/phase)
  count+=1
print(count,'build and probe records checked')
