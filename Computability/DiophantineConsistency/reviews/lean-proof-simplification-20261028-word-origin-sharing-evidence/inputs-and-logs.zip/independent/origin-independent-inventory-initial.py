from pathlib import Path
import hashlib,json,collections
p=Path('/tmp/word-origin-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();i=json.loads((p/'inventory.json').read_text());assert len(i['local'])==168 and len(i['external'])==65 and not i['issues'];c=collections.Counter()
for x in i['local']:
 for ph in ('baseline','final'):
  v=x['phase'][ph];assert h(v['source'])==v['source_sha256'],(x['module'],ph,'source');assert h(v['object'])==v['object_sha256'],(x['module'],ph,'object')
 c[x['phase']['final'].get('status','unknown')]+=1
for x in i['external']:
 for ph in ('baseline','final'):
  v=x['phase'][ph];assert h(v['object'])==v['object_sha256'],(x['module'],ph)
print('168 local source/object pairs and 65 external object pins verified in both phases')
print('final input classifications',dict(c))
