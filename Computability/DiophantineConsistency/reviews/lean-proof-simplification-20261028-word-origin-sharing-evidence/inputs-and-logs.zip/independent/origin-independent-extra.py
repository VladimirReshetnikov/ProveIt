from pathlib import Path
import json,hashlib
p=Path('/tmp/word-origin-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();count=0
for fn in ('private-meta-records.json','foundation-records.json','import-records.json'):
 for r in json.loads((p/fn).read_text()):
  ph=r['phase'];tag=r['tag'];expected=1 if tag in ('foundation-forward','foundation-reverse') else 0;cmd=r['command'];src=p/(tag+'.lean');assert r['status']==expected and h(src)==r['source_sha256']==r['source_after'] and h(p/(ph+'-'+tag+'.log'))==r['log_sha256'] and h(cmd[4])==r['time_sha256'];assert r['lean_path'].split(':')[0]==str(p/ph);count+=1
print(count,'private/Foundation/import records verified')
for tag in ('foundation-forward','foundation-reverse','mf-foundation-forward','mf-foundation-reverse'):
 assert (p/('baseline-'+tag+'.log')).read_bytes()==(p/('final-'+tag+'.log')).read_bytes(),tag
print('Foundation comparison logs identical in both orders')
a=set((p/'baseline-imports.log').read_text().splitlines());b=set((p/'final-imports.log').read_text().splitlines());print('new imports',sorted(b-a));print('removed imports',sorted(a-b));assert b-a=={'DiophantineConsistency.MFCurrentWordOrigin2011'} and not a-b
