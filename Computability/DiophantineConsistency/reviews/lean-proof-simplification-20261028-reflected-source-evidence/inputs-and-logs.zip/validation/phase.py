from pathlib import Path
import os,subprocess,time,json,hashlib,shutil
R=Path('/tmp/reflected-source-share-20261028');prev=Path('/tmp/selector-shared-20261028');root=Path('Computability/DiophantineConsistency/Lean');names=['CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for phase in ['baseline','final']:
 d=R/phase/'DiophantineConsistency';d.mkdir(parents=True,exist_ok=True)
 foundation=R/phase/'Foundation'
 if not foundation.exists() and not foundation.is_symlink():foundation.symlink_to('/home/codex/src/Proofs/.lake/build/lib/lean/Foundation',target_is_directory=True)
 for p in (prev/'final/DiophantineConsistency').iterdir():
  if p.suffix=='.olean' and p.stem not in names+['ReflectedSource']:
   q=d/p.name
   if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
for tag,p in [('normal','/tmp/reflected-geometry-reuse-20261028/axioms.lean'),('mf','/tmp/mf-reflected-geometry-reuse/axioms.lean')]:
 (R/('axioms-'+tag+'.lean')).write_bytes(Path(p).read_bytes())
for tag,n in [('normal',names[0]),('mf',names[1])]:
 (R/('imports-'+tag+'.lean')).write_text('import DiophantineConsistency.'+n+'\nopen Lean Elab Command\nrun_cmd do\n  for n in (← getEnv).allImportedModuleNames do\n    logInfo m!"{n}"\n')
(R/'new-axiom.lean').write_text('import DiophantineConsistency.ReflectedSource\n#print axioms DiophantineConsistency.ReflectedSource.source\n')
(R/'foundation.lean').write_text('import Foundation.Vorspiel.Matrix\nimport DiophantineConsistency.MFCurrentReflectedGeometry2011\n#check Matrix.vecCons_zero\n#check DiophantineConsistency.MF.CurrentReflectedGeometry2011.reflected_source\n')
def run(phase,tag,source,srcroot,output=None):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+env.get('LEAN_PATH','');tm=R/(phase+'-'+tag+'.time');log=R/(phase+'-'+tag+'.log');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcroot),str(source)]
 if output is not None:output.unlink(missing_ok=True);cmd+=['-o',str(output)]
 before=sha(source);start=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'source_after':sha(source),'log_sha256':sha(log),'timing':tm.read_text().strip()}
 if output and output.exists():rec.update(object_sha256=sha(output),object_bytes=output.stat().st_size)
 records.append(rec);(R/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,q.returncode,round(rec['seconds'],1),flush=True)
 if q.returncode or rec['source_after']!=before:raise SystemExit(1)
run('final','helper',R/'source/DiophantineConsistency/ReflectedSource.lean',R/'source',R/'final/DiophantineConsistency/ReflectedSource.olean')
for phase in ['baseline','final']:
 srcroot=R/('baseline' if phase=='baseline' else 'source')
 for n in names:run(phase,n,srcroot/'DiophantineConsistency'/(n+'.lean'),srcroot,R/phase/'DiophantineConsistency'/(n+'.olean'))
 for tag in ['normal','mf']:
  for kind in ['axioms','imports']:run(phase,kind+'-'+tag,R/(kind+'-'+tag+'.lean'),R)
 run(phase,'foundation',R/'foundation.lean',R)
 for n in ['CurrentReflectedGeometry2011Checks','CurrentEarlyPadding2011','CurrentPhaseParity2011','MFCurrentCopyParity2011']:
  run(phase,'client-'+n,root/'DiophantineConsistency'/(n+'.lean'),root,R/phase/'DiophantineConsistency'/(n+'.olean'))
for tag in ['axioms-normal','axioms-mf','foundation']:
 if (R/('baseline-'+tag+'.log')).read_bytes()!=(R/('final-'+tag+'.log')).read_bytes():print('DIFFERENCE',tag,flush=True);raise SystemExit(2)
run('final','new-axiom',R/'new-axiom.lean',R)
for tag in ['normal','mf']:
 a=set((R/('baseline-imports-'+tag+'.log')).read_text().splitlines());b=set((R/('final-imports-'+tag+'.log')).read_text().splitlines());print(tag,'imports added',sorted(b-a),'removed',sorted(a-b),flush=True)
print('all complete, old axiom reports match',flush=True)
