import Foundation.Vorspiel.Matrix
import DiophantineConsistency.ReflectedSource
#check Matrix
#print axioms DiophantineConsistency.ReflectedSource.source
