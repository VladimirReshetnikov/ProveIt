from pathlib import Path
R=Path('/tmp/reflected-source-share-20261028');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=R/'baseline/DiophantineConsistency';out=R/'source/DiophantineConsistency';base.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
for n in ['CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011']:
 s=(root/(n+'.lean')).read_text();(base/(n+'.lean')).write_text(s)
 s='import DiophantineConsistency.ReflectedSource\n'+s
 start=s.index('private theorem add_residue');end=s.index('/-- A negative same-cell offset',start);s=s[:start]+s[end:]
 start=s.index('theorem reflected_source');body=s.index(':= by\n',start)+len(':= by\n');end=s.index('\ndef source ',body)
 s=s[:body]+'  exact ReflectedSource.source c ↑lowSupport (fun f hf => support_le hf) hsupport b hb hh hp\n'+s[end:]
 (out/(n+'.lean')).write_text(s)
(out/'ReflectedSource.lean').write_bytes((R/'probe.lean').read_bytes())
dst=R/'overlay/DiophantineConsistency';dst.mkdir(parents=True,exist_ok=True)
for p in Path('/tmp/selector-shared-20261028/final/DiophantineConsistency').iterdir():
 if p.suffix=='.olean' and p.stem not in ['CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011','ReflectedSource']:
  q=dst/p.name
  if not q.exists() and not q.is_symlink():q.symlink_to(p.resolve())
print('snapshots created')
