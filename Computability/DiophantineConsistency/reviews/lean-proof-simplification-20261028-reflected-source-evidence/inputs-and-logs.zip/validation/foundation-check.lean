import Foundation.Vorspiel.Matrix
import DiophantineConsistency.ReflectedSource
#check Matrix.vecCons_zero
#print axioms DiophantineConsistency.ReflectedSource.source
