import DiophantineConsistency.ExecutableJones
namespace DiophantineConsistency.ExecutableJones
open Jones1982 NinePolynomial
/-- Jones syntax for any quartic compiled from a pair of natural expressions. -/
theorem hasNaturalZero_quartic {m : ℕ} (p q : NatExpr (Empty ⊕ Fin m)) :
    (∃ a : Fin 9 → ℕ, (expression (QuarticSyntax.expression p q) 0).eval
      (fun i => (a i : ℤ)) = 0) ↔ Wset (QuarticCompiler.quartic p q) 1 := by
  have hν : 1 ≤ QuarticCompiler.witnessCount p q := by
    dsimp only [QuarticCompiler.witnessCount]
    omega
  have hP : (QuarticSyntax.expression p q).toPolynomial.totalDegree ≤ 4 := by
    rw [QuarticSyntax.polynomial_expression]
    exact QuarticCompiler.quartic_degree p q
  have hnorm : Normalized (QuarticSyntax.expression p q).toPolynomial := by
    rw [QuarticSyntax.polynomial_expression]
    exact QuarticCompiler.quartic_normalized p q
  simpa only [QuarticSyntax.polynomial_expression] using
    hasNaturalZero_expression (QuarticSyntax.expression p q) hν hP hnorm 0


end DiophantineConsistency.ExecutableJones
