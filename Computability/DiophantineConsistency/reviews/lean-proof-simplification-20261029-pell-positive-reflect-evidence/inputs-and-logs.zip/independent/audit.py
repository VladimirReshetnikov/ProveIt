from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/pell-positive-reflect');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
changed=['ArithmeticPellClassification','ArithmeticPellFirstNorm'];old='''  have h1 : 1≤x*x := by rw [h]; simp
  by_contra hn
  have hz : x=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le x)
  simp [hz] at h1''';new='''  exact pos_of_mul_pos_left (b := x) (by rw [h]; simp) (Arithmetic.zero_le x)'''
for n in changed:
 b=(R/'baseline/DiophantineConsistency'/f'{n}.lean').read_text();f=(R/'final/DiophantineConsistency'/f'{n}.lean').read_text();assert b.count(old)==1 and b.replace(old,new)==f
 rel=f'Computability/DiophantineConsistency/Lean/DiophantineConsistency/{n}.lean';assert subprocess.check_output(['git','show',f'477b3197a1^:{rel}']).decode()==b and subprocess.check_output(['git','show',f'477b3197a1:{rel}']).decode()==f and (W/f'{n}.lean').read_text()==f;print('PASS exact positive_x substitution, commit/parent',n)
edges={n:sorted(p.stem for p in W.glob('*.lean') if re.search(r'^import DiophantineConsistency\.'+re.escape(n)+r'$',p.read_text(),re.M)) for n in changed};assert edges=={'ArithmeticPellClassification':['ArithmeticPellClassificationChecks','ArithmeticPellCongruences','ArithmeticPellKnownUnit'],'ArithmeticPellFirstNorm':['ArithmeticPellFirstIndex','ArithmeticPellFirstNormChecks']};print('PASS direct client graph',edges)
paths={'ArithmeticPellRecurrence':'/tmp/pell-balance-sharing/final-targets-records.json','ArithmeticPellHalfIndex':'/tmp/four-positive-wrappers/upstream-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module'].split('.')[-1]==n);assert x['status']==0 and x['before']==x['after']==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])==set(changed+sum(edges.values(),[]))
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module'] not in changed:assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d.get('source_before') is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n in rec[phase]:assert d['before']==rec[phase][n]['object_sha256']
   else:assert d['before']==providers[n]
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in set(rec['baseline'])-set(changed):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS five unchanged direct clients have byte-identical objects')
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][Path(p).stem]['object_sha256'] for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
up=next(x for x in read('/tmp/four-positive-wrappers/upstream-records.json') if x['module']=='ArithmeticPellHalfIndex');sq=read('/tmp/pell-square-direct/final-records.json');idx=next(x for x in sq if x['module']=='ArithmeticPellIndexDivisibility');inte=next(x for x in sq if x['module']=='ArithmeticPellIntegralSolution');common=next(x for x in sq if x['module']=='ArithmeticPellCommonUnit');gcd=next(x for x in read('/tmp/pell-reflection-simp/refresh-records.json') if x['module']=='ArithmeticGcdNormalization')
def inp(x,n):return next(d['before'] for d in x['direct_inputs'] if d['module'].endswith('.'+n))
assert up['object_sha256']==providers['ArithmeticPellHalfIndex'] and inp(up,'ArithmeticPellIndexDivisibility')==idx['object_sha256'] and inp(idx,'ArithmeticPellIntegralSolution')==inte['object_sha256'] and inp(inte,'ArithmeticPellCommonUnit')==common['object_sha256'] and inp(common,'ArithmeticGcdNormalization')==gcd['object_sha256']
assert inte['before']==inte['after']!=h(W/'ArithmeticPellIntegralSolution.lean') and gcd['before']==gcd['after']!=h(W/'ArithmeticGcdNormalization.lean')
print('PASS seven-object-pinned 25 target declaration reports and matching simp/instances')
print('PASS historical HalfIndex->Index->old IntegralSolution/CommonUnit->old GCD producer provenance; transitive load-time bytes are not pinned')
