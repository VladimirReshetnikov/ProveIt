import Lean.Elab.Command
import DiophantineConsistency.ArithmeticPellFirstIndex
import DiophantineConsistency.ArithmeticPellClassificationChecks
import DiophantineConsistency.ArithmeticPellFirstNormChecks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellClassification).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellClassification" ||
     (`DiophantineConsistency.ArithmeticPellFirstNorm).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNorm" then
   logInfo m!"DECL {n}"
