import Lean.Elab.Command
import DiophantineConsistency.ArithmeticPellFirstIndex
import DiophantineConsistency.ArithmeticPellClassificationChecks
import DiophantineConsistency.ArithmeticPellFirstNormChecks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if Lean.Meta.isInstanceCore env n then
   let p ← liftCoreM <| Lean.Meta.getInstancePriority? n
   logInfo m!"INSTANCE {n} {p}"
