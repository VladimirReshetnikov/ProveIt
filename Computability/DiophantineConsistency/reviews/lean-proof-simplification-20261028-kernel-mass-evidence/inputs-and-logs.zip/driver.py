import os,sys,json,time,hashlib,subprocess
from pathlib import Path
base=Path('/tmp/shared-mask-20261028')
phase=sys.argv[1]; overlay=base/phase/'overlay'; target=overlay/'DiophantineConsistency'; target.mkdir(parents=True,exist_ok=True)
for p in Path('.lake/build/lib/lean/DiophantineConsistency').resolve().glob('*.olean'):
 q=target/p.name
 if not q.exists() and p.name not in ('CurrentKernel2011.olean','CurrentClause2011.olean','CurrentSelectorTail2011.olean'):q.symlink_to(p)
q=target/'ArithmeticMaskKernel.olean'
if not q.exists():q.symlink_to(base/'overlay/DiophantineConsistency/ArithmeticMaskKernel.olean')
root='Computability/DiophantineConsistency/Lean'; p=Path(root)/'DiophantineConsistency'
commands=[('target',str(p/'CurrentKernel2011.lean'),str(target/'CurrentKernel2011.olean')),('focus',str(p/'CurrentKernel2011Checks.lean'),None),('clause',str(p/'CurrentClause2011.lean'),str(target/'CurrentClause2011.olean')),('tail',str(p/'CurrentSelectorTail2011.lean'),str(target/'CurrentSelectorTail2011.olean')),('axioms',str(base/'axioms.lean'),None)]
records=[]
for label,src,out in commands:
 cmd=['lake','env','bash','-c','export LEAN_PATH="$1:$LEAN_PATH"; shift; exec "$@"','bash',str(overlay),'/usr/bin/time','-f','elapsed=%e maxrss=%M','lean','-M6000','-j1','-DElab.async=false','-R',root,src]
 if out:cmd+=['-o',out]
 start=time.monotonic(); r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); elapsed=time.monotonic()-start
 log=base/'logs'/f'{phase}-{label}.log';log.write_bytes(r.stdout)
 data={'label':label,'command':cmd,'status':r.returncode,'seconds':elapsed,'source_sha256':hashlib.sha256(Path(src).read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(r.stdout).hexdigest()}
 if out and Path(out).exists():data.update(object_sha256=hashlib.sha256(Path(out).read_bytes()).hexdigest(),object_bytes=Path(out).stat().st_size)
 records.append(data);(base/(phase+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,label,r.returncode,round(elapsed,2),flush=True)
 if r.returncode:break
