from pathlib import Path
import hashlib,os,subprocess,json,time
r=Path('/tmp/gap-source-consolidation');f=r/'fresh';s=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/GapSource66.lean');o=f/'overlay/DiophantineConsistency/GapSource66.olean';env=os.environ.copy();env['LEAN_PATH']=str(f/'overlay')+':'+env.get('LEAN_PATH','');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=sha(s);cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(s),'-o',str(o)];start=time.monotonic()
with (f/'priority-target.log').open('wb') as log:
 try:p=subprocess.run(['/usr/bin/time','-f','elapsed=%e rss_kb=%M',*cmd],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300);rc=p.returncode
 except subprocess.TimeoutExpired:rc=124;log.write(b'\nTIMEOUT\n')
res={'cmd':cmd,'status':rc,'elapsed':time.monotonic()-start,'source_sha_before':before,'source_sha_after':sha(s),'log_sha256':sha(f/'priority-target.log')}
if rc==0:res.update({'object_sha256':sha(o),'object_bytes':o.stat().st_size})
(f/'priority-target.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
