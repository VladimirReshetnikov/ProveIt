from pathlib import Path
import os,subprocess,sys,time,json,hashlib
r=Path('/tmp/gap-source-consolidation'); phase=sys.argv[1]; dest=r/phase; overlay=dest/'overlay'
env=os.environ.copy(); env['LEAN_PATH']=str(overlay)+':'+env.get('LEAN_PATH','')
root='Computability/DiophantineConsistency/Lean'; prefix=['lean','-M6000','-j1','-DElab.async=false','-R',root]
tasks=[('target',root+'/DiophantineConsistency/GapSource66.lean',str(overlay/'DiophantineConsistency/GapSource66.olean')),('client',root+'/DiophantineConsistency/GapCertificate66.lean',str(overlay/'DiophantineConsistency/GapCertificate66.olean')),('focus',root+'/checks/GapSource66.lean',None),('axioms',str(r/'axioms.lean'),None)]
records=[]
for tag,source,obj in tasks:
 cmd=prefix+[source]+(['-o',obj] if obj else [])
 start=time.monotonic()
 with (dest/(tag+'.log')).open('wb') as f:
  try: p=subprocess.run(['/usr/bin/time','-f','elapsed=%e rss_kb=%M',*cmd],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=300); code=p.returncode
  except subprocess.TimeoutExpired: code=124;f.write(b'\nTIMEOUT\n')
 def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
 rec={'tag':tag,'cmd':cmd,'status':code,'elapsed':time.monotonic()-start,'source_sha256':sha(source),'log_sha256':sha(dest/(tag+'.log'))}
 if obj and code==0:rec.update({'object_sha256':sha(obj),'object_bytes':Path(obj).stat().st_size})
 records.append(rec);(dest/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 print(phase,tag,'status',code,'seconds',round(rec['elapsed'],1),flush=True)
 if code:break
