from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/tmp/gap-source-consolidation');d=r/'fresh';o=d/'overlay'; env=os.environ.copy();env['LEAN_PATH']=str(o)+':'+env.get('LEAN_PATH','')
names='SidonPositions QuadraticFiber QuadraticCoding SelectiveQuadraticCoding DegreeSeparatedCoding SplitGeometry59 SplitCertificate59 GapGeometry66'.split();records=[]
for name in names:
 src='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+name+'.lean';obj=o/'DiophantineConsistency'/f'{name}.olean'; cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',src,'-o',str(obj)];start=time.monotonic()
 with (d/(name+'.log')).open('wb') as f:
  try: p=subprocess.run(['/usr/bin/time','-f','elapsed=%e rss_kb=%M',*cmd],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=300);code=p.returncode
  except subprocess.TimeoutExpired:code=124;f.write(b'\nTIMEOUT\n')
 sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
 rec={'tag':name,'status':code,'command':cmd,'elapsed':time.monotonic()-start,'source_sha256':sha(src),'log_sha256':sha(d/(name+'.log'))}
 if code==0: rec['object_sha256']=sha(obj);rec['object_bytes']=obj.stat().st_size
 records.append(rec);(d/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,code,round(rec['elapsed'],1),flush=True)
 if code:break
