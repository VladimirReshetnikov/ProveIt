from pathlib import Path
import os,subprocess,sys,time,json,hashlib
r=Path('/tmp/gap-source-consolidation'); phase=sys.argv[1]; dest=r/('fresh-'+phase); dest.mkdir(exist_ok=True); overlay=dest/'overlay'/'DiophantineConsistency';overlay.mkdir(parents=True,exist_ok=True)
fresh=r/'fresh'/'overlay'/'DiophantineConsistency';names='SidonPositions QuadraticFiber QuadraticCoding SelectiveQuadraticCoding DegreeSeparatedCoding SplitGeometry59 SplitCertificate59 GapGeometry66'.split()
for f in Path('.lake/build/lib/lean/DiophantineConsistency').glob('*.olean'):
 if f.stem not in ('GapSource66','GapCertificate66'):
  target=(fresh/f.name) if f.stem in names else f.resolve()
  assert target.exists(),target
  (overlay/f.name).symlink_to(target)
env=os.environ.copy();env['LEAN_PATH']=str(overlay.parent)+':'+env.get('LEAN_PATH','')
repo='Computability/DiophantineConsistency/Lean'; target=(str(r/'baseline-src/DiophantineConsistency/GapSource66.lean') if phase=='baseline' else repo+'/DiophantineConsistency/GapSource66.lean');targetroot=(str(r/'baseline-src') if phase=='baseline' else repo)
tasks=[('target',target,str(overlay/'GapSource66.olean'),targetroot),('client',repo+'/DiophantineConsistency/GapCertificate66.lean',str(overlay/'GapCertificate66.olean'),repo),('focus',repo+'/checks/GapSource66.lean',None,repo),('axioms',str(r/'axioms.lean'),None,repo)]
records=[]
for tag,source,obj,root in tasks:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',root,source]+(['-o',obj] if obj else []);start=time.monotonic()
 with (dest/(tag+'.log')).open('wb') as f:
  try:p=subprocess.run(['/usr/bin/time','-f','elapsed=%e rss_kb=%M',*cmd],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=300);code=p.returncode
  except subprocess.TimeoutExpired: code=124;f.write(b'\nTIMEOUT\n')
 sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
 rec={'tag':tag,'cmd':cmd,'status':code,'elapsed':time.monotonic()-start,'source_sha256':sha(source),'log_sha256':sha(dest/(tag+'.log'))}
 if obj and code==0:rec.update({'object_sha256':sha(obj),'object_bytes':Path(obj).stat().st_size})
 records.append(rec);(dest/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,'status',code,'seconds',round(rec['elapsed'],1),flush=True)
 if code:break
