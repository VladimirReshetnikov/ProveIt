from pathlib import Path
import runpy,hashlib
m=runpy.run_path('Computability/DiophantineConsistency/tools/generate_gap_source66.py')
s=m['OUTPUT'].read_text();old=Path('/tmp/gap-source-consolidation/original.lean').read_text();start=m['START'];end=m['END'];pre,r=s.split(start,1);b,post=r.split(end,1);opre,r=old.split(start,1);ob,opost=r.split(end,1)
assert pre==opre and post==opost and b==m['generate']() and ob.split('private theorem row_identity_0',1)[0]==b.split('theorem row_identity',1)[0]
before=hashlib.sha256(m['OUTPUT'].read_bytes()).hexdigest();m['main']();assert hashlib.sha256(m['OUTPUT'].read_bytes()).hexdigest()==before
print('Generator reproduces output; row data and non-generated source are byte-identical')
