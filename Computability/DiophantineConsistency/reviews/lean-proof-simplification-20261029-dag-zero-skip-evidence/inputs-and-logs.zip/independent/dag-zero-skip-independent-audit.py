from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/dag-zero-skip');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRuntimeBoundDagRootA.lean'
assert subprocess.check_output(['git','show','4e897bac04^:'+path])==(R/'baseline.lean').read_bytes()
assert subprocess.check_output(['git','show','4e897bac04:'+path])==(R/'src/DiophantineConsistency/ArithmeticRuntimeBoundDagRootA.lean').read_bytes()==Path(path).read_bytes()
print('parent, commit and current source verified')
def historic(p):return R/'baseline.lean' if str(p)==path else Path(p)

prior=next(x for x in json.loads(Path('/tmp/dag-linear-bound-sharing/final-client-records.json').read_text()) if x['module']=='ArithmeticRuntimeBoundDagMacrosD' and x['phase']=='final' and x['status']==0)
for x in json.loads((R/'records.json').read_text()):
 ph=x['phase'];n=x['module'];assert x['status']==0 and x['source_before']==x['source_after']==h(historic(x['source'])) and x['object_sha256']==h(R/ph/'DiophantineConsistency'/(n+'.olean')) and x['log_sha256']==h(R/(ph+'-'+n+'.log')) and x['time']==(R/(ph+'-'+n+'.time')).read_text()
 if ph=='base' and n=='ArithmeticRuntimeBoundDagRootA':assert x['source_before']==h(R/'baseline.lean')
 for name,d in x['inputs'].items():
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p.resolve())==d['object'] and d['object_before']==d['object_after']==h(p)
  if d['source']:assert d['source_before']==d['source_after']==h(historic(d['source']))
  m=name.split('.')[-1]
  if m=='ArithmeticRuntimeBoundDagMacrosD':assert d['source_before']==prior['source_before']==prior['source_after'] and d['object_before']==prior['object_sha256']
  elif m.startswith('ArithmeticRuntimeBoundDagRoot'):assert d['object_before']==rows[ph,m]['object_sha256']
  else:raise AssertionError(name)
 rows[ph,n]=x;print(ph,n,x['time'].strip())
for n in ['ArithmeticRuntimeBoundDagRootB','ArithmeticRuntimeBoundDagRootC']:assert rows['base',n]['object_sha256']==rows['final',n]['object_sha256'];print('client identical',n,rows['base',n]['object_sha256'])
for x in json.loads((R/'census-records.json').read_text()):
 ph=x['phase'];n=x['name'];assert x['status']==0 and x['source_before']==x['source_after']==h(R/(n+'.lean')) and x['log_sha256']==h(R/(ph+'-'+n+'.log')) and x['time']==(R/(ph+'-'+n+'.time')).read_text()
 for m,v in x['inputs_before'].items():assert v==x['inputs_after'][m]==rows[ph,m]['object_sha256']==h(R/ph/'DiophantineConsistency'/(m+'.olean'))
for n in ['interfaces','private']:assert (R/('base-'+n+'.log')).read_bytes()==(R/('final-'+n+'.log')).read_bytes()
for kind,num in [('DECL',324),('SIMP',29279),('INSTANCE',13370)]:
 read=lambda ph:{s for s in (R/(ph+'-names.log')).read_text().splitlines() if s.startswith(kind+' ')}
 a,b=read('base'),read('final');assert a==b and len(a)==num;print(kind,len(a))
s=(R/'base-interfaces.log').read_text();assert s.count('depends on axioms:')+s.count('does not depend on any axioms')==294;print('294 public/generated type/axiom reports and private reports match')
print('all checks passed')
