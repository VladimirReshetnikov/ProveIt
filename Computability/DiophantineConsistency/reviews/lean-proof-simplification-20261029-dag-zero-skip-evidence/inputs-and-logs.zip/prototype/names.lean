import DiophantineConsistency.ArithmeticRuntimeBoundDagRootC
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticRuntimeBoundDagMacros).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticRuntimeBoundDagRootA).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticRuntimeBoundDagRootB).isPrefixOf n || (`_private.DiophantineConsistency.ArithmeticRuntimeBoundDagRootC).isPrefixOf n then
      logInfo m!"DECL {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) || t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
    if Lean.Meta.isInstanceCore env n then
      let p ← liftCoreM <| Lean.Meta.getInstancePriority? n
      logInfo m!"INSTANCE {n} {p}"
