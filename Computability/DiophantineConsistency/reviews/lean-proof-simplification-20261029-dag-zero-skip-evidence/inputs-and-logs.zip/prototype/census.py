from pathlib import Path
import os,subprocess,hashlib,json
r=Path('/tmp/dag-zero-skip');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[];mods=['ArithmeticRuntimeBoundDagRootA','ArithmeticRuntimeBoundDagRootB','ArithmeticRuntimeBoundDagRootC'];imports='import DiophantineConsistency.ArithmeticRuntimeBoundDagRootC\n';pred='(`DiophantineConsistency.ArithmeticRuntimeBoundDagMacros).isPrefixOf n || '+ ' || '.join(f'(`_private.DiophantineConsistency.{n}).isPrefixOf n' for n in mods)
(r/'names.lean').write_text(imports+'''open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if '''+pred+''' then
      logInfo m!"DECL {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) || t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
    if Lean.Meta.isInstanceCore env n then
      let p ← liftCoreM <| Lean.Meta.getInstancePriority? n
      logInfo m!"INSTANCE {n} {p}"
''')
def run(phase,name):
 src=r/(name+'.lean');env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':/tmp/dag-linear-bound-sharing/objects-final:'+lp;inp={n:sha(r/phase/'DiophantineConsistency'/(n+'.olean')) for n in mods};before=sha(src);log=r/(phase+'-'+name+'.log');tm=r/(phase+'-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'phase':phase,'name':name,'source_before':before,'source_after':sha(src),'inputs_before':inp,'inputs_after':{n:sha(r/phase/'DiophantineConsistency'/(n+'.olean')) for n in mods},'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':p.returncode,'time':tm.read_text(),'log_sha256':sha(log)};rec.append(row);(r/'census-records.json').write_text(json.dumps(rec,indent=2));print(phase,name,p.returncode,flush=True)
 if p.returncode or row['source_before']!=row['source_after'] or row['inputs_before']!=row['inputs_after']:raise SystemExit(1)
for phase in ['base','final']:run(phase,'names')
def vals(p,k):return {s.split(k,1)[1].strip() for s in p.read_text().splitlines() if k in s}
a=vals(r/'base-names.log','DECL ');b=vals(r/'final-names.log','DECL ');print('names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),flush=True)
for k in ['SIMP ','INSTANCE ']:
 x=vals(r/'base-names.log',k);y=vals(r/'final-names.log',k);print(k,len(x),len(y),'equal',x==y,flush=True)
common=sorted(n for n in a&b if not n.startswith('_private.'));(r/'interfaces.lean').write_text(imports+'set_option pp.universes true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in common))
for phase in ['base','final']:run(phase,'interfaces')
print('common public/generated',len(common),'equal',(r/'base-interfaces.log').read_bytes()==(r/'final-interfaces.log').read_bytes(),flush=True)
(r/'private.lean').write_text(imports+'''import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if '''+' || '.join(f'(`_private.DiophantineConsistency.{n}).isPrefixOf n' for n in mods)+''' then
      let typ ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let axioms ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {typ} AXIOMS {axioms}"
''')
for phase in ['base','final']:run(phase,'private')
print('private reports equal',(r/'base-private.log').read_bytes()==(r/'final-private.log').read_bytes(),flush=True)
