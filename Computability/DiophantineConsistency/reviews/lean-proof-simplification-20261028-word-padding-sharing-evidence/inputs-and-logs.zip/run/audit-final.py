from pathlib import Path
import hashlib,json
p=Path('/tmp/word-padding-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();g=json.loads((p/'graph.json').read_text());inventory=json.loads((p/'post-copies-inventory.json').read_text());r=json.loads((p/'pinned-records.json').read_text());assert len(g['nodes'])==167 and len(g['external'])==65 and len(r)==12
for rec in r:
 assert rec['status']==0 and rec['source_sha256']==rec['source_after']==h(rec['source']) and h(rec['log'])==rec['log_sha256'] and h(rec['time'])==rec['time_sha256']
 assert rec['lean_path'].split(':')[0]==str(p/('post-copies-'+rec['phase']))
 assert len(rec['inputs_before'])==228 and rec['inputs_before']==rec['inputs_after']
 for n,v in rec['inputs_before'].items():
  if 'source' in v:assert h(v['source'])==v['source_sha256'],n
  assert h(v['object'])==v['object_sha256'],n
 if rec['object']:assert h(rec['object'])==rec['object_sha256']
 assert rec['target_before']==rec['target_after']
for ph in ('baseline','final'):
 for name in ('CurrentWordPadding2011','MFCurrentWordPadding2011'):
  target=p/ph/'DiophantineConsistency'/(name+'.lean')
  if ph=='baseline':assert target.read_bytes()==(Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(name+'.lean')).read_bytes()
for tag in ('mf','target','checks','client','interface','compat'):
 assert (p/('baseline-pinned-'+tag+'.log')).read_bytes()==(p/('final-pinned-'+tag+'.log')).read_bytes(),tag
for tag in ('foundation-normal','foundation-reverse'):
 assert (p/('post-copies-baseline-'+tag+'.log')).read_bytes()==(p/('post-copies-final-'+tag+'.log')).read_bytes(),tag
for ph in ('baseline','final'):
 for tag in ('names','private'):
  assert (p/(ph+'-'+tag+'.log')).read_bytes()==(p/('post-copies-'+ph+'-'+tag+'.log')).read_bytes(),(ph,tag)
assert len(inventory['local'])==167 and len(inventory['external'])==65
print('12 pinned runs checked; 163 local and 65 external inputs per run; baseline sources match; paired target/client/interface/Foundation logs match; namespace and private census unchanged since preliminary')
