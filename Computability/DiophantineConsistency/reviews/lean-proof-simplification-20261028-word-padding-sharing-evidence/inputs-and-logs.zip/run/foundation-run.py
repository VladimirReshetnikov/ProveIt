from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-padding-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();rs=[]
for ph in ('baseline','final'):
 for tag in ('normal','reverse'):
  src=p/('foundation-'+tag+'.lean');env=os.environ.copy();env['LEAN_PATH']=str(p/(ph+'-lib'))+':'+base;log=p/(ph+'-foundation-'+tag+'.log');tm=p/(ph+'-foundation-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false',str(src)];before=h(src)
  with log.open('wb') as f:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  r={'phase':ph,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':rc,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':time.monotonic()-t};rs.append(r);(p/'foundation-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,tag,rc,flush=True)
