from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/tmp/word-padding-sharing');repo=Path('Computability/DiophantineConsistency/Lean');g=json.loads((p/'graph.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();ov=p/'post-carry-common';base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x];rows=[]
for n,v in g['nodes'].items():assert h(v['source'])==v['sha256'],('source drift',n)
def locate(m):
 for root in roots:
  q=root/(m.replace('.','/')+'.olean')
  if q.is_file():return q
 raise RuntimeError('missing '+m)
for n in ('CurrentWordCopies2011','MFCurrentWordTopBounds2011','CurrentWordTopBounds2011','CurrentWordOrigin2011'):
 assert shutil.disk_usage('.').free>850*1024*1024
 src=repo/'DiophantineConsistency'/(n+'.lean');before=h(src);im=[x for line in src.read_text().splitlines() if line.startswith('import ') for x in line.split()[1:]];inputs=[]
 for m in im:
  f=locate(m);inputs.append({'module':m,'path':str(f),'resolved':str(f.resolve()),'sha256':h(f)})
 obj=ov/'DiophantineConsistency'/(n+'.olean');obj.unlink(missing_ok=True);log=p/('post-carry-common-'+n+'.log');tm=p/('post-carry-common-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(repo),str(src),'-o',str(obj)];start=time.monotonic()
 with log.open('wb') as out:rc=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
 for i in inputs:i['after_sha256']=h(i['path'])
 r={'module':n,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':inputs,'elapsed':round(time.monotonic()-start,2)};rows.append(r);(p/'post-carry-common-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(n,rc,r['elapsed'],flush=True)
 if rc or before!=r['source_after'] or any(x['sha256']!=x['after_sha256'] for x in inputs):raise SystemExit(1)
for n,v in g['nodes'].items():assert h(v['source'])==v['sha256'],('source drift after',n)
