import DiophantineConsistency.CurrentWordPadding2011
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n0 := `DiophantineConsistency.CurrentWordPadding2011.bit3_clear_of_residue._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.bit3_clear_of_residue._proof_1: {t.isLemma (.decl n0 true false)} {t.isLemma (.decl n0 false false)} {t.isLemma (.decl n0 true true)} {t.isLemma (.decl n0 false true)}"
  let n1 := `DiophantineConsistency.CurrentWordPadding2011.bit3_clear_of_residue._simp_1
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.bit3_clear_of_residue._simp_1: {t.isLemma (.decl n1 true false)} {t.isLemma (.decl n1 false false)} {t.isLemma (.decl n1 true true)} {t.isLemma (.decl n1 false true)}"
  let n2 := `DiophantineConsistency.CurrentWordPadding2011.normalized_padding_residue._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.normalized_padding_residue._proof_1: {t.isLemma (.decl n2 true false)} {t.isLemma (.decl n2 false false)} {t.isLemma (.decl n2 true true)} {t.isLemma (.decl n2 false true)}"
  let n3 := `DiophantineConsistency.CurrentWordPadding2011.padding_marker_input_zero._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_marker_input_zero._proof_1: {t.isLemma (.decl n3 true false)} {t.isLemma (.decl n3 false false)} {t.isLemma (.decl n3 true true)} {t.isLemma (.decl n3 false true)}"
  let n4 := `DiophantineConsistency.CurrentWordPadding2011.padding_marker_input_zero._proof_2
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_marker_input_zero._proof_2: {t.isLemma (.decl n4 true false)} {t.isLemma (.decl n4 false false)} {t.isLemma (.decl n4 true true)} {t.isLemma (.decl n4 false true)}"
  let n5 := `DiophantineConsistency.CurrentWordPadding2011.padding_mask._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_mask._proof_1: {t.isLemma (.decl n5 true false)} {t.isLemma (.decl n5 false false)} {t.isLemma (.decl n5 true true)} {t.isLemma (.decl n5 false true)}"
  let n6 := `DiophantineConsistency.CurrentWordPadding2011.padding_mask._proof_2
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_mask._proof_2: {t.isLemma (.decl n6 true false)} {t.isLemma (.decl n6 false false)} {t.isLemma (.decl n6 true true)} {t.isLemma (.decl n6 false true)}"
  let n7 := `DiophantineConsistency.CurrentWordPadding2011.padding_raw_residue._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_raw_residue._proof_1: {t.isLemma (.decl n7 true false)} {t.isLemma (.decl n7 false false)} {t.isLemma (.decl n7 true true)} {t.isLemma (.decl n7 false true)}"
  let n8 := `DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._proof_5
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._proof_5: {t.isLemma (.decl n8 true false)} {t.isLemma (.decl n8 false false)} {t.isLemma (.decl n8 true true)} {t.isLemma (.decl n8 false true)}"
  let n9 := `DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._proof_6
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._proof_6: {t.isLemma (.decl n9 true false)} {t.isLemma (.decl n9 false false)} {t.isLemma (.decl n9 true true)} {t.isLemma (.decl n9 false true)}"
  let n10 := `DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._simp_4
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._simp_4: {t.isLemma (.decl n10 true false)} {t.isLemma (.decl n10 false false)} {t.isLemma (.decl n10 true true)} {t.isLemma (.decl n10 false true)}"
  let n11 := `DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._simp_5
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_reflected_residue._simp_5: {t.isLemma (.decl n11 true false)} {t.isLemma (.decl n11 false false)} {t.isLemma (.decl n11 true true)} {t.isLemma (.decl n11 false true)}"
  let n12 := `DiophantineConsistency.CurrentWordPadding2011.padding_source_le._proof_1
  logInfo m!"DiophantineConsistency.CurrentWordPadding2011.padding_source_le._proof_1: {t.isLemma (.decl n12 true false)} {t.isLemma (.decl n12 false false)} {t.isLemma (.decl n12 true true)} {t.isLemma (.decl n12 false true)}"
