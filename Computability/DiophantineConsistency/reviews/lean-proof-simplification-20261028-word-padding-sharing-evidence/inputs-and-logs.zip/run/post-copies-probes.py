from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-padding-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=[]
for ph in ('baseline','final'):
 ov=p/('post-copies-'+ph);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base
 for tag in ('names','interface','private','compat','foundation-normal','foundation-reverse'):
  src=p/(tag+'.lean');log=p/('post-copies-'+ph+'-'+tag+'.log');tm=p/('post-copies-'+ph+'-'+tag+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(p),str(src)];before=h(src);selected=[]
  for n in ('CurrentWordPadding2011','MFCurrentWordPadding2011'):
   obj=ov/'DiophantineConsistency'/(n+'.olean');selected.append({'module':n,'path':str(obj),'sha256':h(obj)})
  start=time.monotonic()
  with log.open('wb') as f:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  for v in selected:v['after_sha256']=h(v['path'])
  r={'phase':ph,'tag':tag,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'selected':selected,'elapsed':round(time.monotonic()-start,2)};rs.append(r);(p/'post-copies-probe-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,tag,rc,flush=True)
  if (rc!=1 if tag.startswith('foundation') else rc!=0) or before!=r['source_after'] or any(x['sha256']!=x['after_sha256'] for x in selected):raise SystemExit(1)
