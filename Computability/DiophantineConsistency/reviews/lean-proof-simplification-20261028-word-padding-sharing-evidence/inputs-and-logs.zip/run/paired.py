from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-padding-sharing');root=Path('Computability/DiophantineConsistency/Lean');leanpath=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for ph in ('baseline','final'):
 env=os.environ.copy();out=p/(ph+'-lib');env['LEAN_PATH']=str(out)+':'+leanpath
 for n in ('MFCurrentWordPadding2011','CurrentWordPadding2011','CurrentWordPadding2011Checks','CurrentWordHighMask2011'):
  is_target=n in ('MFCurrentWordPadding2011','CurrentWordPadding2011');src=(p/ph/'DiophantineConsistency'/(n+'.lean')) if is_target else (root/'DiophantineConsistency'/(n+'.lean'));srcroot=(p/ph) if is_target else root;obj=out/'DiophantineConsistency'/(n+'.olean');obj.unlink(missing_ok=True)
  log=p/(ph+'-'+n+'.log');tim=p/(ph+'-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tim),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(obj)];before=h(src)
  with log.open('wb') as f:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  r={'phase':ph,'module':n,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source_sha256':before,'source_after':h(src),'object_sha256':h(obj) if obj.exists() else None,'log_sha256':h(log),'time_sha256':h(tim),'elapsed':time.monotonic()-t};records.append(r);(p/'paired-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,n,rc,round(r['elapsed'],1),flush=True)
  if rc or r['source_after']!=before:raise SystemExit(1)
