import DiophantineConsistency.CurrentWordPadding2011
import DiophantineConsistency.MFCurrentWordPadding2011
open DiophantineConsistency
example {n : ℕ} [NeZero n] (c k digits : ZMod n → ℕ) (W : ℕ) :
    CurrentCarryConstruction2011.Facts c W k digits ↔ MF.CurrentCarryConstruction2011.Facts c W k digits := by
  constructor <;> intro h
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
  · exact ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩
