import DiophantineConsistency.CurrentWordPadding2011
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if n.toString.startsWith "_private.DiophantineConsistency.CurrentWordPadding2011." then
      logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
