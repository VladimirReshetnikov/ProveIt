from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/tmp/word-padding-sharing');repo=Path('Computability/DiophantineConsistency/Lean');inv=json.loads((p/'post-copies-inventory.json').read_text());old={(r['phase'],r['module']):r for r in json.loads((p/'post-copies-paired-records.json').read_text())};h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();names=('MFCurrentWordPadding2011','CurrentWordPadding2011','CurrentWordPadding2011Checks','CurrentWordHighMask2011');excluded={'DiophantineConsistency.'+n for n in names};rows=[]
def pin(ph):
 o={}
 for x in inv['local']:
  if x['module'] in excluded:continue
  z=x['phase'][ph];sh=h(z['source']);oh=h(z['object']);assert sh==z['source_sha256'] and oh==z['object_sha256'],(ph,x['module']);o[x['module']]={'source':z['source'],'source_sha256':sh,'object':z['object'],'object_sha256':oh,'status':z['status']}
 for x in inv['external']:
  z=x['phase'][ph];oh=h(z['object']);assert oh==z['object_sha256'],(ph,x['module']);o[x['module']]={'object':z['object'],'object_sha256':oh,'status':'direct-external'}
 return o
for ph in ('baseline','final'):
 ov=p/('post-copies-'+ph);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+lp
 for tag in ('mf','target','checks','client','interface','compat'):
  assert shutil.disk_usage('.').free>850*1024*1024
  n={'mf':names[0],'target':names[1],'checks':names[2],'client':names[3]}.get(tag);target=n in names[:2] if n else False
  src=(p/ph/'DiophantineConsistency'/(n+'.lean')) if target else ((repo/'DiophantineConsistency'/(n+'.lean')) if n else p/(tag+'.lean'));root=(p/ph) if target else (repo if n else p);obj=ov/'DiophantineConsistency'/(n+'.olean') if n else None;log=p/(ph+'-pinned-'+tag+'.log');tm=p/(ph+'-pinned-'+tag+'.time');before=pin(ph);sb=h(src)
  targetpins={t:h(ov/'DiophantineConsistency'/(t+'.olean')) for t in names[:2]};cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src)]
  if obj:obj.unlink(missing_ok=True);cmd+=['-o',str(obj)]
  start=time.monotonic()
  with log.open('wb') as f:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  after=pin(ph);output=h(obj) if obj and obj.is_file() else None;targetafter={t:h(ov/'DiophantineConsistency'/(t+'.olean')) for t in names[:2]};r={'phase':ph,'tag':tag,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':sb,'source_after':h(src),'object':str(obj) if obj else None,'object_sha256':output,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'inputs_before':before,'inputs_after':after,'target_before':targetpins,'target_after':targetafter,'elapsed':round(time.monotonic()-start,2)};rows.append(r);(p/'pinned-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(ph,tag,rc,r['elapsed'],flush=True)
  assert rc==0 and sb==r['source_after'] and before==after
  if obj:assert output==old[(ph,n)]['object_sha256'],(ph,n,'object changed from paired build')
  assert targetpins==targetafter,(ph,tag,'target output changed')
