from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-padding-sharing');src=p/'names.lean';base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();rs=[]
for ph in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/(ph+'-lib'))+':'+base;log=p/(ph+'-names.log');tm=p/(ph+'-names.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false',str(src)];before=h(src)
 with log.open('wb') as f:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 r={'phase':ph,'command':cmd,'lean_path':env['LEAN_PATH'],'status':rc,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':time.monotonic()-t};rs.append(r);(p/'names-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,rc,flush=True)
 if rc:raise SystemExit(1)
