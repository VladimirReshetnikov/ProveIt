from pathlib import Path
import json,hashlib
p=Path('/tmp/word-padding-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[];counts={}
for fn in ('post-copies-common-records.json','post-copies-paired-records.json','post-copies-probe-records.json','pinned-records.json'):
 data=json.loads((p/fn).read_text());counts[fn]=len(data)
 for i,r in enumerate(data):
  lab=(fn,i);cmd=r['command'];tag=r.get('tag','');expected=1 if tag in ('foundation-normal','foundation-reverse') else 0
  if r['status']!=expected:issues.append([lab,'status',r['status']])
  if h(r['source'])!=r['source_sha256'] or r['source_sha256']!=r['source_after']:issues.append([lab,'source'])
  for f,key in (('log','log_sha256'),('time','time_sha256')):
   if h(r[f])!=r[key]:issues.append([lab,f])
  if r.get('object') and h(r['object'])!=r['object_sha256']:issues.append([lab,'object'])
  expected_overlay=('post-carry-common' if 'phase' not in r else 'post-copies-'+r['phase'])
  if r['lean_path'].split(':')[0]!=str(p/expected_overlay):issues.append([lab,'overlay'])
  for x in r.get('direct_inputs',r.get('selected',[])):
   if h(x['path'])!=x['sha256'] or x['sha256']!=x['after_sha256']:issues.append([lab,'input',x['module']])
  if 'inputs_before' in r:
   if r['inputs_before']!=r['inputs_after']:issues.append([lab,'pin before/after'])
   if len(r['inputs_before'])!=228:issues.append([lab,'pin count',len(r['inputs_before'])])
   for n,v in r['inputs_before'].items():
    if h(v['object'])!=v['object_sha256'] or ('source' in v and h(v['source'])!=v['source_sha256']):issues.append([lab,'pin',n])
for n in ('CurrentWordPadding2011','MFCurrentWordPadding2011'):
 a=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');b=p/'baseline/DiophantineConsistency'/(n+'.lean')
 if h(a)!=h(b):issues.append(['baseline',n,'source drift'])
for tag in ('interface','compat','foundation-normal','foundation-reverse'):
 a=(p/('baseline-pinned-'+tag+'.log')).read_bytes() if (p/('baseline-pinned-'+tag+'.log')).exists() else (p/('post-copies-baseline-'+tag+'.log')).read_bytes()
 b=(p/('final-pinned-'+tag+'.log')).read_bytes() if (p/('final-pinned-'+tag+'.log')).exists() else (p/('post-copies-final-'+tag+'.log')).read_bytes()
 if a!=b:issues.append(['paired logs',tag])
print(json.dumps({'records':counts,'issues':issues},indent=2));(p/'independent-audit.json').write_text(json.dumps({'records':counts,'issues':issues},indent=2)+'\n')
if issues:raise SystemExit(1)
