from pathlib import Path
import json,hashlib,subprocess
p=Path('/tmp/word-padding-sharing');peer=Path('/tmp/word-copies-sharing');rows=json.loads((peer/'phase-records.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();roots=[p/'post-carry-common']+[Path(x) for x in lp.split(':') if x];override={};out=[]
def locate(m):
 if m in override:return override[m]
 for root in roots:
  q=root/(m.replace('.','/')+'.olean')
  if q.is_file():return q
 raise RuntimeError('missing '+m)
for n in ('MFCurrentWordCopies2011','CurrentWordCopies2011'):
 r=next(x for x in rows if x['phase']=='final' and x['module']==n);source=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');assert h(source)==r['source_sha256']==r['source_after'] and h(r['object'])==r['object_sha256']
 fail=[]
 for x in r['direct_inputs']:
  q=locate(x['module']);actual=h(q)
  if actual!=x['sha256'] or actual!=x['after_sha256']:fail.append(x['module'])
 print(n,'direct mismatches',fail);assert not fail
 override['DiophantineConsistency.'+n]=Path(r['object']);out.append({'module':n,'source':str(source),'source_sha256':h(source),'object':r['object'],'object_sha256':r['object_sha256'],'direct_inputs':r['direct_inputs']})
(p/'copies-reconcile.json').write_text(json.dumps(out,indent=2)+'\n')
for x in out:
 dest=p/'post-carry-common'/'DiophantineConsistency'/(x['module']+'.olean');dest.unlink(missing_ok=True);dest.symlink_to(Path(x['object']).resolve())
print('selected exact peer final objects')
