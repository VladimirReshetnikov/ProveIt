from pathlib import Path
import os,hashlib,json,subprocess
p=Path('/tmp/word-padding-sharing');peer=Path('/tmp/word-copies-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=json.loads((peer/'common-records.json').read_text());v={x['module']:x for x in rs};names=['CurrentPhaseParity2011','CurrentCopyParity2011','CurrentCount2011','CurrentSelectorTail2011','CurrentEarlyPadding2011','CurrentWindowCarry2011','CurrentPolynomialWindow2011','CurrentOneHot2011','CurrentAdjacency2011'];lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();roots=[p/'post-carry-common']+[Path(x) for x in lp.split(':') if x];overrides={};out=[]
def locate(m):
 if m in overrides:return overrides[m]
 for root in roots:
  q=root/(m.replace('.','/')+'.olean')
  if q.is_file():return q
 raise Exception(('missing',m))
for short in names:
 n='DiophantineConsistency.'+short;r=v[n];fail=[]
 if r['status']!=0 or h(r['source'])!=r['source_sha256'] or h(r['object'])!=r['object_sha256']:fail.append('source/object mismatch')
 for d in r['direct_inputs']:
  try:
   q=locate(d['module']);actual=h(q)
   if actual!=d['sha256'] or actual!=d['after_sha256']:fail.append(d['module'])
  except Exception:fail.append(d['module']+' missing')
 out.append({'module':n,'record':r,'mismatched_inputs':fail})
 if not fail:overrides[n]=Path(r['object'])
print('results:')
for x in out:print(x['module'].split('.')[-1],len(x['mismatched_inputs']),', '.join(x['mismatched_inputs'][:4]))
(p/'peer-reconcile.json').write_text(json.dumps(out,indent=2)+'\n')
