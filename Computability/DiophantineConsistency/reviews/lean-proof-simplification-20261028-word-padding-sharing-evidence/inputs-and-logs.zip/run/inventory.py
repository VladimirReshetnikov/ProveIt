from pathlib import Path
import hashlib,json
p=Path('/tmp/word-padding-sharing');g=json.loads((p/'graph.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();r=[]
for name,v in g['nodes'].items():
 src=Path(v['source']); ent={'module':name,'source':str(src),'source_sha256':h(src),'graph_source_sha256':v['sha256'],'imports':v['imports']}
 for ph in ('baseline','final'):
  f=p/(ph+'-lib')/(name.replace('.','/')+'.olean');ent[ph]={'object':str(f.resolve()),'sha256':h(f)} if f.is_file() else None
 r.append(ent)
(p/'inventory.json').write_text(json.dumps(r,indent=2)+'\n')
print('local',len(r),'missing',sum(not x[ph] for x in r for ph in ('baseline','final')),'source drift',sum(x['source_sha256']!=x['graph_source_sha256'] for x in r))
print('differing phase objects', [x['module'] for x in r if x['baseline'] and x['final'] and x['baseline']['sha256']!=x['final']['sha256']])
