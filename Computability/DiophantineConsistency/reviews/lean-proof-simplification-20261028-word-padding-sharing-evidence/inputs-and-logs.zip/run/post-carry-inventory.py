from pathlib import Path
import os,json,hashlib,subprocess
p=Path('/tmp/word-padding-sharing');g=json.loads((p/'graph.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();prior=json.loads(Path('/tmp/word-top-sharing/inventory.json').read_text())['local'];carry={x['module']:x for x in json.loads(Path('/tmp/carry-proof-sharing/independent-full-pins.json').read_text())};common={x['module']:x for x in json.loads((p/'post-carry-common-records.json').read_text())};paired={(x['phase'],x['module']):x for x in json.loads((p/'post-carry-paired-records.json').read_text())};lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();rows=[]
for n,v in g['nodes'].items():
 short=n.split('.')[-1];e={'module':n,'imports':v['imports'],'phase':{}}
 for ph in ('baseline','final'):
  ov=p/('post-carry-'+ph);obj=ov/(n.replace('.','/')+'.olean');assert obj.is_file(),(n,ph);src=(p/ph/'DiophantineConsistency'/(short+'.lean')) if short in ('CurrentWordPadding2011','MFCurrentWordPadding2011') else Path(v['source']);sh=h(src);oh=h(obj);status='unmatched precompiled'
  rec=paired.get((ph,short))
  if rec and rec['source_sha256']==sh and rec['object_sha256']==oh:status='rebuilt paired target/client'
  elif short in common and common[short]['source_sha256']==sh and common[short]['object_sha256']==oh:status='rebuilt post-carry common'
  elif n in carry and carry[n]['source_sha256']==sh and carry[n]['final']['sha256']==oh:status='matched carry full pin'
  elif n in prior and prior[n]['source_sha256']==sh and prior[n]['object_sha256']==oh:status='matched prior top inventory'
  e['phase'][ph]={'source':str(src),'source_sha256':sh,'object':str(obj),'resolved':str(obj.resolve()),'object_sha256':oh,'status':status}
 rows.append(e)
external=[]
for n in g['external']:
 ent={'module':n,'phase':{}}
 for ph in ('baseline','final'):
  roots=[p/('post-carry-'+ph)]+[Path(x) for x in lp.split(':') if x];found=next((q for r in roots if (q:=r/(n.replace('.','/')+'.olean')).is_file()),None)
  assert found is not None,(n,ph)
  ent['phase'][ph]={'object':str(found),'resolved':str(found.resolve()),'object_sha256':h(found)}
 external.append(ent)
from collections import Counter
r={'local':rows,'external':external};(p/'post-carry-inventory.json').write_text(json.dumps(r,indent=2)+'\n')
for ph in ('baseline','final'):print(ph,dict(Counter(x['phase'][ph]['status'] for x in rows)))
print('local',len(rows),'external',len(external),'local object phase differences',[x['module'] for x in rows if x['phase']['baseline']['object_sha256']!=x['phase']['final']['object_sha256']])
