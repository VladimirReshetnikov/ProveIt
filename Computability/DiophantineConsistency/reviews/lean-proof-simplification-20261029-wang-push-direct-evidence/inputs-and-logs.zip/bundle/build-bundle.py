from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/dev/shm/wang-push-direct')
D=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-wang-push-direct-evidence');D.mkdir(parents=True,exist_ok=True)
files={}
for p in sorted(R.rglob('*')):
 if p.is_file() and not p.is_symlink() and not str(p.relative_to(R)).startswith('objects-') and p.suffix!='.olean' and p.name!='build-bundle.py': files['prototype/'+str(p.relative_to(R))]=p.read_bytes()
prior={'fin-one-full-fresh.json':'/tmp/fin-one-simplification/full-fresh-records.json','wholefield-provider.json':'/tmp/occupation-selector-sharing/provider-records.json','packing-final.json':'/tmp/packing-rotation-simplify/final-records.json','standardcasts-final.json':'/tmp/binary-half-direct/final-supplement-records.json','kernel-input-sample.json':'/tmp/variation-tail-sharing/refreshed2-common-records.json','pell-old.json':'/tmp/pell-balance-sharing/baseline-targets-records.json','halfbinomial-old.json':'/tmp/halfbinom-cancel/baseline-records.json','binarycarry-old.json':'/tmp/binary-half-reuse-20261028/final-targets.json','signedpairs-old.json':'/tmp/signed-pairs-factors/baseline-records.json'}
for n,p in prior.items(): files['prior/'+n]=Path(p).read_bytes()
for x in ('wang-push-direct-peer-review.txt','wang-push-direct-peer-audit.py','wang-push-direct-peer-audit.log','wang-push-direct-peer-audit-incomplete-probes.log','wang-push-direct-peer-audit-inflight.log'): files['independent/'+x]=Path('/tmp',x).read_bytes()
c=subprocess.check_output(['git','rev-parse','224acccf56'],text=True).strip();par=subprocess.check_output(['git','rev-parse',c+'^'],text=True).strip(); base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for rev,label in ((par,'baseline'),(c,'final')):
 b=subprocess.check_output(['git','show',rev+':'+base+'ArithmeticWangPlane.lean']);assert b==files['prototype/'+label+'/DiophantineConsistency/ArithmeticWangPlane.lean'];files['commit/'+label+'.lean']=b
for n in ('ArithmeticWangStrip','ArithmeticOccupation','ArithmeticRunTrace','ArithmeticPackingCells','ArithmeticWangRowStep','ArithmeticWangTable','ArithmeticMachineRun215','ArithmeticWholeField','ArithmeticPacking','ArithmeticStandardCasts','CurrentKernelData2011'):
 files['commit/inputs/'+n+'.lean']=subprocess.check_output(['git','show',c+':'+base+n+'.lean'])
files['bundle/build-bundle.py']=Path('/dev/shm/wang-push-direct/build-bundle.py').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest();zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':c,'source_parent':par,'scope':'Simplify binary push division and remainder proofs and the two left-move bit bounds','validation':'Paired target and all five tracked direct Lean clients compile. WangRowStep object matches; WangStrip, Occupation, RunTrace and PackingCells objects differ but their both-object-pinned namespace/type/axiom and global simp/instance probes match. Target declaration and registration probes match.','limitations':['The initial Occupation overlay failed from missing CellDecoding and was retried; baseline records combine first target/Strip successes and later client retries.','CurrentKernelData2011 matches a prior input sample, not its producer; WangTable and MachineRun215 prior producer records have only one source digest. Other provider associations use prior source-matched producer receipts.','Post-build path samples resolve older PellRecurrence, HalfBinomial, BinaryCarry and SignedPairs; these samples are not contemporaneous transitive load-time pins. Project, BusyBeaver, Foundation and Mathlib closure remains cached.','Byte-different client objects have unestablished causes. Declaration/registration reports do not establish equality of proof bodies or every persistent extension. Single shared-load timing pairs are not general benchmarks.','Compiled objects are excluded; recorded object hashes and provider paths require external objects for independent byte verification. The standalone arithmetic probe lacks full input pins.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'independent_review_sha256':sha(files['independent/wang-push-direct-peer-review.txt']),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(files['independent/wang-push-direct-peer-review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,b in files.items():assert z.read(n)==b
assert sha((D/'independent-review.txt').read_bytes())==m['independent_review_sha256'];print('PASS members',len(files),'zip sha',m['archive_sha256'],'review sha',m['independent_review_sha256'])
