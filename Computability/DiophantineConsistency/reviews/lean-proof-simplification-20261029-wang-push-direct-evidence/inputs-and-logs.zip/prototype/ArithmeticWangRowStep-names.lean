import DiophantineConsistency.ArithmeticWangRowStep
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticWangRowStep).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticWangRowStep" then
   logInfo m!"DECL {n}"
