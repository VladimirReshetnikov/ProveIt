from pathlib import Path
import hashlib,json
R=Path('/dev/shm/wang-push-direct');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text());providers={}
for n in ('ArithmeticWangTable','ArithmeticMachineRun215'):
 x=next(x for x in load('/tmp/fin-one-simplification/full-fresh-records.json') if x['module'].split('.')[-1]==n);assert x['status']==0 and x['source_sha256']==h(W/f'{n}.lean');providers[n]=x['object_sha256']
for n,f in [('ArithmeticWholeField','/tmp/occupation-selector-sharing/provider-records.json'),('ArithmeticPacking','/tmp/packing-rotation-simplify/final-records.json'),('ArithmeticStandardCasts','/tmp/binary-half-direct/final-supplement-records.json')]:
 x=next(x for x in load(f) if x['module']==n);b=x.get('before') or x.get('source_before');a=x.get('after') or x.get('source_after');assert x['status']==0 and b==a==h(W/f'{n}.lean') and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256']
x=next(x for x in load('/tmp/variation-tail-sharing/refreshed2-common-records.json') if x['module']=='ArithmeticPackingCells');d=next(d for d in x['direct_inputs'] if d['module'].endswith('.CurrentKernelData2011'));assert d['source_before']==d['source_after']==h(W/'CurrentKernelData2011.lean') and d['object_before']==d['object_after'];providers['CurrentKernelData2011']=d['object_before']
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')};mods=['ArithmeticWangPlane','ArithmeticWangStrip','ArithmeticOccupation','ArithmeticRunTrace','ArithmeticPackingCells','ArithmeticWangRowStep']
for ph,rr in records.items():
 assert [x['module'] for x in rr]==mods
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if ph=='baseline' or x['module']!='ArithmeticWangPlane':assert x['before']==h(W/f"{x['module']}.lean")
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticWangPlane':assert d['before']==rr[0]['object_sha256']
   else:assert d['before']==providers[n]
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
for c in mods[1:-1]:
 rows=load(R/f'{c}-probe-records.json');assert len(rows)==8
 for x in rows:
  rr=records[x['phase']];z=next(z for z in rr if z['module']==c);assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[rr[0]['object_sha256'],z['object_sha256']] and x['log_sha256']==h(x['log'])
 for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{c}-{n}.log').read_bytes()==(R/f'final-{c}-{n}.log').read_bytes()
assert records['baseline'][-1]['object_sha256']==records['final'][-1]['object_sha256']
old=load(R/'setup-failed/baseline-records.json');assert [x['status'] for x in old]==[0,0,1] and old[2]['log_sha256']==h(R/'setup-failed/baseline-ArithmeticOccupation.log') and 'ArithmeticCellDecoding.olean' in (R/'setup-failed/baseline-ArithmeticOccupation.log').read_text()
print('PASS paired target/five clients, direct provider prior matches, target/four differing-client probes and preserved setup failure')
