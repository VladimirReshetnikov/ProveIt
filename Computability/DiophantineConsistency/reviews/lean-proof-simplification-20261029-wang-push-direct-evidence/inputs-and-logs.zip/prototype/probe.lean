import DiophantineConsistency.ArithmeticWangPlane
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (x w : V) (hw : w ≤ 1) : (w+2*x)/2=x := by
  have hw2 : w<2 := lt_of_le_of_lt hw (by norm_num)
  rw [show w+2*x=x*2+w by ring, div_mul_add _ _ hw2]
example (x w : V) (hw : w ≤ 1) : (w+2*x)%2=w := by
  have hw2 : w<2 := lt_of_le_of_lt hw (by norm_num)
  rw [mod_add_mul' _ _ (by norm_num : (0:V)<2), mod_eq_self_of_lt hw2]
example (l : V) : l%2 ≤ 1 := lt_two_iff_le_one.mp (by simp)
