Wang plane binary push arithmetic: isolated proof simplification

Baseline ArithmeticWangPlane SHA-256 fa4d7e4c552cc4e5062dc206aa1b4cf0ab00ecd76adb02dd2f67c70da12d0106;
final SHA-256 4ea25b65ebc3388c1f5ceb5ce8ea23bdadabf85277d091671f3e40a73498b99e.
The existing w≤1 guard gives w<2. push_div and push_mod now use standard
quotient/remainder facts directly, and the identical l%2≤1 case splits in
both left-move proofs use the standard remainder bound. These replace four bit
case analyses with direct bounds (ten lines replaced by six). All original
statements, guards, definitions, data and imports are unchanged. Original file
commit 64422b55f4e6b31ffc4bf20160e32e9d0b2cd1cc has Co-Authored-By: Claude
Opus 5.5 <noreply@anthropic.com>.

baseline/final-records.json record source and first direct input object hashes
before/after, commands, logs, timings and outputs for the target and all five
tracked Lean direct clients WangStrip, Occupation, RunTrace, PackingCells and
WangRowStep. All pass in both phases. Target's WangTable and MachineRun215
objects match the source hashes and output hashes in /tmp/fin-one-simplification/
full-fresh-records.json; those historical producer rows do not record a source-
after hash. Occupation's WholeField and PackingCells' Packing and StandardCasts
match current-source producers in /tmp/occupation-selector-sharing/provider-
records.json, /tmp/packing-rotation-simplify/final-records.json and
/tmp/binary-half-direct/final-supplement-records.json. PackingCells' additional
CurrentKernelData2011 object matches the historical source/object input sample
in /tmp/variation-tail-sharing/refreshed2-common-records.json; that sample is
not itself a producer build. audit.py/.log verify these prior source/object
associations, current first-provider resolution, selected builds and probes.
Direct provider source hashes were matched to prior records rather than sampled
during these builds.

WangRowStep object bytes match. The other four client objects differ without an
established cause; full hashes are recorded in the phase receipts. Each of their
paired probes pins both target and client objects before/after; all names/type/
axiom and global simp/instance reports match: WangStrip 4 / 29,729 / 13,379;
Occupation 71 / 33,463 / 14,822; RunTrace 79 / 29,730 / 13,383; PackingCells
88 / 29,791 / 13,431. Target probes match all 59 namespace reports and 29,729
simp/13,379 instances. These comparisons do not establish equality of proof
bodies, every persistent environment extension or untested downstream behavior.
Single shared-load baseline/final user CPU samples: target 16.21/15.46 s,
WangStrip 6.99/6.95, Occupation 9.10/9.31, RunTrace 16.04/15.99, PackingCells
41.70/40.18, WangRowStep 20.81/20.93. They are not general benchmarks. The same
preexisting warning counts appear in both phases: target 2, WangStrip 1,
Occupation 2, RunTrace 9, PackingCells 4 and WangRowStep 0.

The first baseline target and WangStrip succeeded, but Occupation failed at
import loading because CellDecoding was absent from the overlay. Its failed
receipt/log/time and the two successful partial records are preserved under
setup-failed/. Missing symlinks were filled from the Occupation overlay and the
remaining clients retried. The selected baseline-records.json combines those
first two successful rows and baseline-retry-records.json. The final target was
built first and remains stable; final-target-records.json and final-client-
records.json are separately retained and combined in final-records.json.

A post-build sample of the PackingCells search path resolves older cached
PellRecurrence 7f88b2f434d384e7d6e32e10e242f11a1146f460896aabddbc238e077311a5cc,
HalfBinomial e451723c0c0f1f11dabe7aa0df0bb81ed19984562d9163b839c16cc5e962b156,
BinaryCarry a338938c8e26e9003abceff91a004a12c82e46fe7660c4d6e7a8625c056073e0,
and SignedPairs 5b043450cd1f2924fcd0a51afe60fbffd1e39a1bcae221910fe8077af0c521ac.
These samples are not contemporaneous transitive input pins. Other project,
BusyBeaver, Foundation and Mathlib objects remain cached; no full current-source
transitive closure is claimed. The standalone arithmetic probe lacks full input
pins; the selected paired full builds are the validation evidence.
