import DiophantineConsistency.ArithmeticPackingCells
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPackingCells).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPackingCells" then
   logInfo m!"DECL {n}"
