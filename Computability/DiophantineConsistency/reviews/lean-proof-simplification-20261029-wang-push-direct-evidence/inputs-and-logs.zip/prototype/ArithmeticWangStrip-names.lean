import DiophantineConsistency.ArithmeticWangStrip
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticWangStrip).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticWangStrip" then
   logInfo m!"DECL {n}"
