import DiophantineConsistency.ArithmeticWangPlane
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticWangPlane).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticWangPlane" then
   logInfo m!"DECL {n}"
