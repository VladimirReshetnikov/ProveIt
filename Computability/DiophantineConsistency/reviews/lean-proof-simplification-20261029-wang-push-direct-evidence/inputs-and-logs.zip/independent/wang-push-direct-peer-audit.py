from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/dev/shm/wang-push-direct');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticWangPlane.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticWangPlane.lean').read_text()
changes=[('''  rcases bit_cases hw with rfl | rfl
  · simp
  · rw [add_comm]; exact two_mul_add_one_div_two x''','''  have hw2 : w < 2 := lt_of_le_of_lt hw (by norm_num)
  rw [show w + 2*x = x*2 + w by ring, div_mul_add _ _ hw2]'''),('''  rcases bit_cases hw with rfl | rfl
  · simp
  · rw [add_comm]; simp [mod_mul_add' _ _ (by simp : (0:V) < 2)]''','''  have hw2 : w < 2 := lt_of_le_of_lt hw (by norm_num)
  rw [mod_add_mul' _ _ (by norm_num : (0:V) < 2), mod_eq_self_of_lt hw2]'''),('''  have hm : l % 2 ≤ 1 := by
    rcases mod_two l with h | h <;> simp [h]''','''  have hm : l % 2 ≤ 1 := lt_two_iff_le_one.mp (by simp)''')]
for a,z in changes:
 c=2 if 'have hm' in a else 1;assert b.count(a)==c;b=b.replace(a,z)
assert b==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWangPlane.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}'])
assert gitfile('224acccf56^')==(R/'baseline/DiophantineConsistency/ArithmeticWangPlane.lean').read_bytes() and gitfile('224acccf56')==f.encode() and (W/'ArithmeticWangPlane.lean').read_text()==f;print('PASS exact substitutions, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticWangPlane$','--','*.lean'],text=True).splitlines();expected=['ArithmeticWangStrip','ArithmeticOccupation','ArithmeticRunTrace','ArithmeticPackingCells','ArithmeticWangRowStep'];assert sorted(Path(p).stem for p in clients)==sorted(expected),clients;print('PASS five tracked direct Lean clients',clients)
paths={'ArithmeticWangTable':'/tmp/fin-one-simplification/full-fresh-records.json','ArithmeticMachineRun215':'/tmp/fin-one-simplification/full-fresh-records.json','ArithmeticWholeField':'/tmp/occupation-selector-sharing/provider-records.json','ArithmeticPacking':'/tmp/packing-rotation-simplify/final-records.json','ArithmeticStandardCasts':'/tmp/binary-half-direct/final-supplement-records.json'};providers={}
for n,path in paths.items():
 xs=[x for x in read(path) if (x.get('module') or x.get('name','')).split('.')[-1]==n and x.get('status')==0]
 for x in xs:
  a=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');z=x.get('after') or x.get('source_after') or x.get('source_sha256_after') or x.get('source_sha256')
  if a==z==h(W/(n+'.lean')):providers[n]=x['object_sha256'];break
 assert n in providers,(n,path);print('PASS prior producer source/object',n,providers[n])
prior=next(x for x in read('/tmp/variation-tail-sharing/refreshed2-common-records.json') if x['module']=='ArithmeticPackingCells');d=next(d for d in prior['direct_inputs'] if d['module'].endswith('.CurrentKernelData2011'));assert d['source_before']==d['source_after']==h(W/'CurrentKernelData2011.lean') and d['object_before']==d['object_after'];providers['CurrentKernelData2011']=d['object_before'];print('PASS prior input sample source/object CurrentKernelData2011',providers['CurrentKernelData2011'])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])==set(['ArithmeticWangPlane']+expected)
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticWangPlane':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticWangPlane':assert d['before']==rec[phase][n]['object_sha256']
   else:assert d['before']==providers[n]
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in expected:print('client output',n,'identical',rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256'])
print('PASS build, first-provider pins and external producer/source-sample associations')
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticWangPlane']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
print('PASS target declaration/type/axiom and registration reports')
for client in ('ArithmeticWangStrip','ArithmeticOccupation','ArithmeticRunTrace','ArithmeticPackingCells'):
 rows=read(R/f'{client}-probe-records.json');assert len(rows)==8
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[x['phase']][n]['object_sha256'] for n in ('ArithmeticWangPlane',client)] and x['log_sha256']==h(x['log'])
 for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{client}-{n}.log').read_bytes()==(R/f'final-{client}-{n}.log').read_bytes()
 print('PASS both-object-pinned differing client reports',client)
old=read(R/'setup-failed/baseline-records.json');x=next(x for x in old if x['module']=='ArithmeticOccupation');assert x['status']!=0 and x['log_sha256']==h(R/'setup-failed/baseline-ArithmeticOccupation.log') and 'ArithmeticCellDecoding.olean' in (R/'setup-failed/baseline-ArithmeticOccupation.log').read_text()
print('PASS preserved initial missing-CellDecoding setup failure')
oldpaths={'ArithmeticPellRecurrence':('/tmp/pell-balance-sharing/baseline-targets-records.json','7f88b2f434d384e7d6e32e10e242f11a1146f460896aabddbc238e077311a5cc'),'ArithmeticHalfBinomial':('/tmp/halfbinom-cancel/baseline-records.json','e451723c0c0f1f11dabe7aa0df0bb81ed19984562d9163b839c16cc5e962b156'),'ArithmeticBinaryCarry':('/tmp/binary-half-reuse-20261028/final-targets.json','a338938c8e26e9003abceff91a004a12c82e46fe7660c4d6e7a8625c056073e0'),'ArithmeticSignedPairs':('/tmp/signed-pairs-factors/baseline-records.json','5b043450cd1f2924fcd0a51afe60fbffd1e39a1bcae221910fe8077af0c521ac')}
for n,(path,obj) in oldpaths.items():
 x=next(x for x in read(path) if x.get('object_sha256')==obj);source=x.get('before') or x.get('source_sha256');assert x['status']==0 and source!=h(W/(n+'.lean'))
 for phase in ('baseline','final'):
  env=rec[phase]['ArithmeticPackingCells']['LEAN_PATH'];p=next(Path(z)/'DiophantineConsistency'/(n+'.olean') for z in env.split(':') if (Path(z)/'DiophantineConsistency'/(n+'.olean')).is_file());assert h(p)==obj;print('PASS post-build path sample',phase,n,obj,p.resolve())
print('PASS old-source producer receipts and post-build samples; samples are not transitive load-time pins')
