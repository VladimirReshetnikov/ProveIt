from pathlib import Path
import hashlib,json,subprocess
r=Path('/tmp/carrier-set-iff-sharing');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());fresh={};rows={}
for recordset,prefix in [('provider2-records.json','provider2'),('provider3-records.json','provider3')]:
 for x in get(recordset):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source'])==h(w/(n+'.lean')) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{prefix}-{n}.time').read_text()
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
   name=d['module'].split('.')[-1]
   if name in fresh:assert d['before']==fresh[name]['object_sha256'] and d['resolved']==fresh[name]['object']
  fresh[n]=x;print('provider',n,'verified')
for x in get('records.json'):
 ph=x['phase'];n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
 if n=='CurrentCarrierArithmetic2011':
  ref='2ad82db137^' if ph=='baseline' else '2ad82db137'
  committed=subprocess.check_output(['git','show',f'{ref}:{w}/{n}.lean']);assert x['before']==hashlib.sha256(committed).hexdigest();print('tested',ph,'matches',ref)
 else:assert x['before']==h(w/(n+'.lean'))
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);name=d['module'].split('.')[-1];y=fresh[name] if name in fresh else rows[ph,name];assert d['before']==y['object_sha256'] and d['resolved']==y['object']
 rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for n in ('CurrentCarrierArithmetic2011Checks','CurrentHighDigits2011','CurrentSparseDigits2011'):assert rows['baseline',n]['object_sha256']==rows['final',n]['object_sha256'];print('client object identical',n)
x=get('provider-records.json')[0];assert x['status']!=0 and x['log_sha256']==h(x['log']) and x['time']==(r/'provider-CurrentMasks2011.time').read_text();print('failed initial CurrentMasks provider log/time preserved')
for x in get('coherent-probe-records.json'):
 ph=x['phase'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(x['log']) and x['objects_before']==x['objects_after']==[rows[ph,'CurrentCarrierArithmetic2011']['object_sha256']]
for n in ('names','coherent-interfaces','simp','instances','private'):
 a=(r/f'probe-baseline-{n}.log').read_bytes();b=(r/f'probe-final-{n}.log').read_bytes();assert a==b;print('probes',n,len(a.splitlines()),'lines identical')
assert (r/'probe-baseline-names.log').read_text().count('DECL ')==18
print('18 target declarations match')
old=json.loads(Path('/tmp/current-packing-positive-sharing/refresh3-records.json').read_text());y=next(x for x in old if x['module']=='ThirteenFreshSeed');d=next(d for d in fresh['ThirteenCarrierComplete']['direct_inputs'] if d['module'].endswith('.ThirteenFreshSeed'));assert y['status']==0 and y['before']==y['after']==h(y['source'])==h(w/'ThirteenFreshSeed.lean') and d['before']==y['object_sha256']==h(y['object']);print('prior refreshed ThirteenFreshSeed current source/object matched')
for x in get('repeat-records.json'):
 ph=x['phase'];n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source'])==rows[ph,n]['before'] and x['object_sha256']==h(x['object'])==rows[ph,n]['object_sha256'] and x['log_sha256']==h(x['log']) and x['time']==(r/f'repeat1-{ph}-{n}.time').read_text()
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)==fresh[d['module'].split('.')[-1]]['object_sha256']
 print('repeat',ph,x['time'].strip())
manifest=get('prior-reused-provider-manifest.json');q=next(x for x in manifest['reused_objects'] if x['source'].endswith('/SignedPellResidue.lean'));rel='DiophantineConsistency/SignedPellResidue.olean';p=next(Path(root)/rel for root in rows['final','CurrentCarrierArithmetic2011']['LEAN_PATH'].split(':') if (Path(root)/rel).is_file());old=manifest['protected'][q['source']];assert h(p)==q['sha256']=='45937af80eafe9cb6fd29e046d3f7f87b35d309da8f84bfdd9c99ae1347ab93a' and old=='46afed5402b7bf1a63d567e32906e28f4c06a26b1aab6c8788ef46a405a69fb4' and old!=h(q['source']);print('prior SignedPell cached boundary verified; provenance inventory is not a fresh build receipt')

assert h(w/'CurrentCarrierArithmetic2011.lean')==rows['final','CurrentCarrierArithmetic2011']['before'];print('post-commit workspace matches tested final')
