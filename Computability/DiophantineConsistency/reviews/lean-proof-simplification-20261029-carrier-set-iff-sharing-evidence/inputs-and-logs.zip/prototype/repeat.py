from pathlib import Path
import os,subprocess,json,hashlib,re
R=Path('/tmp/carrier-set-iff-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=os.environ['LEAN_PATH'];records=[]
for mod in ('CurrentCarrierArithmetic2011',):
 for rep in (1,):
  for phase in ('baseline','final'):
   label=f'repeat{rep}-{phase}-{mod}';out=R/('objects-'+label)/'DiophantineConsistency';out.mkdir(parents=True,exist_ok=True);provider=R/('objects-'+phase)/'DiophantineConsistency'
   for p in provider.glob('*.olean'):
    if p.stem!=mod:(out/p.name).symlink_to(p)
   root=R/phase;src=root/'DiophantineConsistency'/(mod+'.lean');obj=out/(mod+'.olean');env=os.environ.copy();env['LEAN_PATH']=str(out.parent)+':/tmp/carrier-set-iff-sharing/common:/tmp/native-ordinary-source-root-7cz0jxs2/lib:/tmp/mask-ins-simplify/final:'+base
   deps=[]
   for n in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
    rel=n.replace('.','/')+'.olean';p=next((Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file()),None)
    if p is None:raise RuntimeError('missing '+n)
    deps.append({'module':n,'path':str(p),'resolved':str(p.resolve()),'before':sha(p)})
   log=R/(label+'.log');tm=R/(label+'.time');before=sha(src);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)]
   with log.open('wb') as f:x=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   for d in deps:d['after']=sha(d['path'])
   rec={'phase':phase,'rep':rep,'module':mod,'status':x.returncode,'source':str(src),'before':before,'after':sha(src),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tm.read_text()};records.append(rec);(R/'repeat-records.json').write_text(json.dumps(records,indent=2)+'\n');print(label,x.returncode,rec['time'].strip(),flush=True)
   if x.returncode or before!=rec['after'] or any(d['before']!=d['after'] for d in deps):raise SystemExit(1)
