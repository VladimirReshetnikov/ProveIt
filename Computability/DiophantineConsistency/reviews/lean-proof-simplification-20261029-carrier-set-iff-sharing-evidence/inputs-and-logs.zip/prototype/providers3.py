from pathlib import Path
import os,subprocess,json,hashlib,re,sys,time
R=Path('/tmp/carrier-set-iff-sharing'); root=Path('Computability/DiophantineConsistency/Lean');out=R/'common';base=os.environ['LEAN_PATH'];env=os.environ.copy();env['LEAN_PATH']=str(out)+':/tmp/native-ordinary-source-root-7cz0jxs2/lib:/tmp/mask-ins-simplify/final:'+base;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();recs=[]
for mod in ['ListGetDCases','NativeVariableMask']:
 src=root/'DiophantineConsistency'/(mod+'.lean');obj=out/'DiophantineConsistency'/(mod+'.olean');log=R/('provider3-'+mod+'.log');tm=R/('provider3-'+mod+'.time');before=sha(src);deps=[]
 for n in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
  rel=n.replace('.','/')+'.olean';p=next((Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file()),None)
  if p is None:raise RuntimeError('missing '+n)
  deps.append({'module':n,'path':str(p),'resolved':str(p.resolve()),'before':sha(p)})
 cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];start=time.monotonic()
 with log.open('wb') as f:x=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in deps:d['after']=sha(d['path'])
 rec={'module':mod,'status':x.returncode,'source':str(src),'before':before,'after':sha(src),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-start,2)};recs.append(rec);(R/'provider3-records.json').write_text(json.dumps(recs,indent=2)+'\n');print(mod,x.returncode,rec['time'].strip(),flush=True)
 if x.returncode or before!=rec['after'] or any(d['before']!=d['after'] for d in deps):sys.exit(1)
