# Carrier positive-zero iff sharing

This isolated candidate simplifies `positive_zero_69_iff_70` and
`positive_zero_70_iff_71` in `CurrentCarrierArithmetic2011.lean`. Both retain
the original proof that beta is positive. The pointwise theorem gives 69 iff
71 and 70 iff 71 for each positive assignment. For 69 iff 70 the proof composes
the first iff with the inverse of the second; for 70 iff 71 it takes the second
iff directly. `exists_congr` and `and_congr_right` lift the result to the same
positive witness in both directions. No declaration statements, imports, definitions,
endpoint hypotheses, data, or unrelated proof bodies change; neither endpoint
acquires an assumption that K is positive.

Baseline source SHA-256:
`5f749fdfe0a3857c6d84b0505574f1b1d09f5b859167659a34b04ba392f4a5b3`.
Final source SHA-256:
`4cd66c6237fe896d93bbc7a3bbed53933610b1d91b5b0a256a0b48069b381a41`.
Both snapshots and the three direct clients are under `baseline` and `final`.
The search in `direct-clients.log` covers Lean files under the module directory
and found the check module, CurrentHighDigits2011 and CurrentSparseDigits2011.
All eight sequential target/client builds pass; `records.json` pins source,
first direct inputs, outputs and logs. The check, high-digit and sparse-digit
client objects are byte-identical across phases (respectively `49c4ea69…`,
`5ebad757…`, `b1e8fb9e…`).

The first target sample used 2.87/2.68 s user CPU baseline/final, and the
paired repeat `repeat-records.json` used 2.74/2.68 s. High-digit client used
149.66/142.55 s, sparse-digit 4.80/3.22 s and checks 2.32/2.35 s. Small
shared-load samples do not establish general performance. A completed pair of
high-digit builds was retained; the client proofs were not modified.

Both target providers CurrentMasks2011 and ThirteenCarrierComplete and client
providers ListGetDCases and NativeVariableMask were rebuilt from current
sources; CurrentMaskData2011 was also rebuilt first. See `provider2-records.json`
and `provider3-records.json`. The initial CurrentMasks2011 rebuild against an
old CurrentMaskData2011 object failed because the latter lacked
`lowSupport_range_Ico_disjoint`; the failure and original direct input pins
remain in `provider-records.json` and `provider-CurrentMasks2011.log`.
ThirteenCarrierComplete uses the previously refreshed ThirteenFreshSeed
object `422676d8…`, recorded with current source in `refresh3-records.json`.

These freshly rebuilt providers still consume cached LowMaskData,
NativeSourceMask, NativeRadixDigits and Carrier66Source objects for which this
experiment has not found matching current-source build receipts. Further,
ThirteenFreshSeed's recorded provider chain consumes the older SignedPellResidue
object `45937af8…` associated with old source `46afed54…`, while the sampled
current source is `ecd4dfbb…`; the prior manifest and refresh receipts are
copied here. The broader project and package closure remains cached, and this
is not a whole-closure current-source rebuild.

`coherent-probe-records.json` pins target objects in paired interface probes.
All 18 target namespace declarations and their types/axioms match; no private
names were present. Both printed definition equations, 55,241 global simp
entries, and 23,370 instance entries match byte-for-byte. The reproducible
`compare-probes.py` and `probe-comparison.json` cover the five paired output
logs. These observations do not exhaust every persistent environment extension
or all transitive clients. No repository files were edited by this experiment.
