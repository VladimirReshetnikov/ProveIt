import DiophantineConsistency.CurrentCarrierArithmetic2011
#print equations DiophantineConsistency.CurrentCarrierArithmetic2011.PositiveZero
#print equations DiophantineConsistency.CurrentCarrierArithmetic2011.polynomial69
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.CurrentCarrierArithmetic2011).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.CurrentCarrierArithmetic2011" then
   logInfo m!"DECL {n}"
