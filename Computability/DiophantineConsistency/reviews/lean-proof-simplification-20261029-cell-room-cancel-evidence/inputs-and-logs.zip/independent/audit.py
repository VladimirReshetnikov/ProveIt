from pathlib import Path
import hashlib,json,re,subprocess
r=Path('/dev/shm/cell-room-cancel'); w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
base=r/'baseline/DiophantineConsistency/ArithmeticCellTransfer.lean';final=r/'final/DiophantineConsistency/ArithmeticCellTransfer.lean'
assert base.read_bytes()==(w/'ArithmeticCellTransfer.lean').read_bytes()
diff=subprocess.run(['diff','-u',str(base),str(final)],capture_output=True,text=True);assert diff.returncode==1 and 'lt_of_mul_lt_mul_left hb (by simp)' in diff.stdout and len(diff.stdout.splitlines())==14
for phase in ['baseline','final']:
 rows=json.loads((r/(phase+'-records.json')).read_text()); assert [x['module'] for x in rows]==['ArithmeticCellTransfer','ArithmeticCellDecoding']
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256']; assert x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and d['before']==d['after']==h(p); assert d['source_before']==d['source_after']==h(d['source'])
  for d in x['extra_inputs']:
   p=next(Path(q)/'DiophantineConsistency'/(d['module']+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(d['module']+'.olean')).is_file());assert p==Path(d['path']) and d['before']==d['after']==h(p)
 assert (r/(phase+'-ArithmeticCellTransfer.log')).read_bytes()==b''
 warn=(r/(phase+'-ArithmeticCellDecoding.log')).read_text();assert warn.count('warning:')==1 and 'section variable(s) unused' in warn and '\n  H\n' in warn and 'cell_digit' in warn
# Normalize only the phase directory: warnings otherwise byte-identical.
a=(r/'baseline-ArithmeticCellDecoding.log').read_text().replace('/baseline/','/PHASE/');b=(r/'final-ArithmeticCellDecoding.log').read_text().replace('/final/','/PHASE/');assert a==b
for stem,count in [('names',59),('ArithmeticCellDecoding-names',71),('simp',33296),('instances',14696),('ArithmeticCellDecoding-simp',33296),('ArithmeticCellDecoding-instances',14696)]:
 a=(r/('baseline-'+stem+'.log')).read_bytes();b=(r/('final-'+stem+'.log')).read_bytes();assert a==b and len(a.splitlines())==count
for stem in ['interfaces','ArithmeticCellDecoding-interfaces']:
 assert (r/('baseline-'+stem+'.log')).read_bytes()==(r/('final-'+stem+'.log')).read_bytes()
for phase in ['baseline','final']:
 rows=json.loads((r/(phase+'-probes.json')).read_text()); builds=json.loads((r/(phase+'-records.json')).read_text());assert len(rows)==4
 for x in rows: assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(q) for q in x['objects']]==[builds[0]['object_sha256']] and h(x['log'])==x['log_sha256']
rows=json.loads((r/'ArithmeticCellDecoding-probe-records.json').read_text());assert len(rows)==8
for x in rows:
 builds=json.loads((r/(x['phase']+'-records.json')).read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(q) for q in x['objects']]==[b['object_sha256'] for b in builds] and h(x['log'])==x['log_sha256']
for n,p in [('ArithmeticStandardCasts','/tmp/binary-half-direct/final-supplement-records.json'),('ArithmeticModularCancellation','/tmp/shared-modular-cancel/records.json'),('ArithmeticCyclicWord','/dev/shm/cell-no-carry/refresh-records.json'),('ArithmeticCellLabels','/dev/shm/cell-no-carry/refresh-records.json'),('ArithmeticBinaryCarry','/tmp/binary-half-direct/final-records.json'),('ArithmeticBinaryPopulation','/tmp/binary-half-direct/final-records.json'),('ArithmeticWindowDigits','/dev/shm/cell-no-carry/refresh-records.json')]:
 rows=json.loads(Path(p).read_text()); hits=[x for x in rows if x['module'].split('.')[-1]==n and x['status']==0 and x.get('source_before',x.get('before'))==x.get('source_after',x.get('after'))==h(w/(n+'.lean'))]; assert hits
 rec=json.loads((r/'final-records.json').read_text())[0];ds=rec['direct_inputs']+rec['extra_inputs'];d=next(d for d in ds if d['module'].split('.')[-1]==n);assert any(x['object_sha256']==d['before'] for x in hits)
print('PASS baseline source, targeted diff, paired builds, identical existing warning, 4+8 pinned probe reports, and 7 source-matched providers')
