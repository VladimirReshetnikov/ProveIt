CellTransfer cell-room multiplication cancellation

In cell_room, the existing strict inequality between products immediately
gives the strict bound on b/2011 by lt_of_mul_lt_mul_left; this replaces the
contradiction argument. The bound, both hypotheses, definitions and imports
remain unchanged. Baseline/final source SHA-256:
40d89a21d612e26efd3316ab34a60fbbf4a4d970de9cb7a505745c68a5635026 /
d972455d407d7efc87307928949b735ee4d0cadf814e39f715fbc1e891e0b49b.
The baseline was current when built; the candidate is isolated. The original
module was introduced in Claude-coauthored f79467f544.

The paired target and its only tracked direct Lean client, CellDecoding, pass.
Client object bytes differ across phases; both-object-pinned probes match 71
client namespace/type/axiom reports and global registrations. All 59 target
namespace/type/axiom reports and 33,296 default simp / 14,696 instance entries
also match. These reports do not prove equality of proof bodies or of every
persistent extension. Original user CPU target timings 7.54/7.52 seconds are a
single shared-load pair, not a general benchmark. Both client builds emit the
same pre-existing unused section variable `H` warning in `cell_digit`; the
target builds emit no warnings.

Direct StandardCasts and ModularCancellation source/object pairs match prior
successful /tmp/binary-half-direct/final-supplement-records.json and
/tmp/shared-modular-cancel/records.json producers. Direct CyclicWord and adopted
CellLabels match the source-current producer rows in
/dev/shm/cell-no-carry/refresh-records.json. Each target/client build records
first-path BinaryCarry, BinaryPopulation and WindowDigits hashes before/after;
those match successful source-current /tmp/binary-half-direct/final-records.json
and /dev/shm/cell-no-carry/refresh-records.json producers. audit.py/.log verify
these associations and all source/object/log/time pins and probe comparisons.
Other project, Foundation and Mathlib dependencies remain cached; there is no
claim of full source-current transitive closure or behavior of untested downstream
clients. Outputs are temporary under /dev/shm.
