from pathlib import Path
import json,hashlib,re
r=Path('/dev/shm/cell-room-cancel');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticCellTransfer','ArithmeticCellDecoding'];rec[phase]={}
 for x in rows:
  rec[phase][x['module']]=x;assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
   if d['module'].endswith('.ArithmeticCellTransfer'):assert d['before']==rec[phase]['ArithmeticCellTransfer']['object_sha256']
  for d in x['extra_inputs']:
   p=next(Path(q)/'DiophantineConsistency'/(d['module']+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(d['module']+'.olean')).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
  if x['module']=='ArithmeticCellDecoding':assert h(x['source'])==h(w/'ArithmeticCellDecoding.lean')
  print('PASS build',phase,x['module'])
 for p in json.loads((r/(phase+'-probes.json')).read_text()):
  assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[phase]['ArithmeticCellTransfer']['object_sha256']] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
for p in json.loads((r/'ArithmeticCellDecoding-probe-records.json').read_text()):
 phase=p['phase'];assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[phase][n]['object_sha256'] for n in ('ArithmeticCellTransfer','ArithmeticCellDecoding')] and h(p['log'])==p['log_sha256']
for n in ('names','interfaces','simp','instances'):
 assert (r/('baseline-'+n+'.log')).read_bytes()==(r/('final-'+n+'.log')).read_bytes()
 assert (r/('baseline-ArithmeticCellDecoding-'+n+'.log')).read_bytes()==(r/('final-ArithmeticCellDecoding-'+n+'.log')).read_bytes()
print('PASS target and both-object-pinned differing-client probes')
providers={'ArithmeticStandardCasts':('/tmp/binary-half-direct/final-supplement-records.json','ArithmeticStandardCasts'),'ArithmeticModularCancellation':('/tmp/shared-modular-cancel/records.json','ArithmeticModularCancellation'),'ArithmeticCyclicWord':('/dev/shm/cell-no-carry/refresh-records.json','ArithmeticCyclicWord'),'ArithmeticCellLabels':('/dev/shm/cell-no-carry/refresh-records.json','ArithmeticCellLabels')}
for d in rec['final']['ArithmeticCellTransfer']['direct_inputs']:
 n=d['module'].split('.')[-1];p,m=providers[n];xs=[x for x in json.load(open(p)) if x['module'].split('.')[-1]==m and x['status']==0 and x['object_sha256']==d['before']];assert xs;x=xs[-1];before=x.get('source_before',x.get('before',x.get('source_sha256')));after=x.get('source_after',x.get('after',x.get('source_sha256')));assert before==after==d['source_before'];print('PASS source-current direct producer',n,d['before'])
for n,p in [('ArithmeticBinaryCarry','/tmp/binary-half-direct/final-records.json'),('ArithmeticBinaryPopulation','/tmp/binary-half-direct/final-records.json'),('ArithmeticWindowDigits','/dev/shm/cell-no-carry/refresh-records.json')]:
 d=next(d for d in rec['final']['ArithmeticCellTransfer']['extra_inputs'] if d['module']==n);x=next(x for x in json.load(open(p)) if x['module']==n and x['status']==0 and x['object_sha256']==d['before']);before=x.get('source_before',x.get('before'));after=x.get('source_after',x.get('after'));assert before==after==h(w/(n+'.lean'));print('PASS source-current extra producer',n,d['before'])
print('PASS all checks; cached transitive closure not audited')
