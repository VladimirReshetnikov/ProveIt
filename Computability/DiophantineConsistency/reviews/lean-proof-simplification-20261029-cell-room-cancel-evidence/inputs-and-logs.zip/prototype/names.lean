import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellTransfer
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCellTransfer" then
   logInfo m!"DECL {n}"
