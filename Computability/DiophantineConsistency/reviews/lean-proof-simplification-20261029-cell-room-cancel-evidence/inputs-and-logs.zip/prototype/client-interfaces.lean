import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellDecoding
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticCellDecoding).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCellDecoding" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
