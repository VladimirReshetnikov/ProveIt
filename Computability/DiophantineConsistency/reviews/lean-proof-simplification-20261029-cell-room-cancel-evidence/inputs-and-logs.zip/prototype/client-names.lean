import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellDecoding
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticCellDecoding).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCellDecoding" then
   logInfo m!"DECL {n}"
