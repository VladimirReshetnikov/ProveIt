from pathlib import Path
import json,hashlib,re
r=Path('/tmp/rank-mask-residue');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();p=json.loads(Path('/tmp/mask-ins-simplify/independent-direct-provider-audit.json').read_text());mask=next(x for x in json.loads(Path('/tmp/mask-ins-simplify/records.json').read_text()) if x['name']=='ArithmeticMaskConstants' and x['phase']=='final' and x['status']==0);mapping=json.loads(Path('/tmp/variation-tail-sharing/post-commit-provider-matches.json').read_text());var=next(x for x in json.loads(Path('/tmp/variation-tail-sharing/refreshed2-final-records.json').read_text()) if x['module']=='ArithmeticConstructionVariation');rows={}
for ph in ('paired-baseline','paired-final'):
 for x in json.loads((r/f'{ph}-records.json').read_text()):
  n=x['module'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
  if ph=='paired-baseline' or n=='ArithmeticConstructionAssembly':assert x['source_before']==x['workspace_before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';o=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(o)==d['path'] and str(o.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(o) and d['source_before']==d['source_after']==h(d['source']);m=d['module'].split('.')[-1]
   if n=='ArithmeticRankForcing2011':
    if m=='ArithmeticMaskConstants':assert (d['source_before'],d['object_before'])==(mask['before'],mask['object_sha256'])
    else:q=p[d['module']];assert (d['source_before'],d['object_before'])==(q['source_sha256'],q['object_sha256']) and q['matching_prior_rows']
    print('target prior direct pair',ph,m)
   elif m=='ArithmeticRankForcing2011':assert d['resolved']==rows[(ph,m)]['object'] and d['object_before']==rows[(ph,m)]['object_sha256'];print('client same-phase target',ph)
   elif m=='ArithmeticConstructionVariation':assert d['source_before']==var['source_before'] and d['object_before']==var['object_sha256'];print('client prior adopted Variation pair',ph)
   else:assert any(v['module']==m and v['source']==d['source_before'] and v['object']==d['object_before'] and v['matches'] for v in mapping),(ph,m);print('client prior direct pair',ph,m)
  rows[(ph,n)]=x;print('build',ph,n,x['timing'])
 for x in json.loads((r/f'{ph}-probes.json').read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[(ph,'ArithmeticRankForcing2011')]['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);print('probe',ph,x['name'])
assert rows['paired-baseline','ArithmeticConstructionAssembly']['object_sha256']==rows['paired-final','ArithmeticConstructionAssembly']['object_sha256'];print('client object identical')
def parse(q):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',q.read_text(),re.M|re.S)}
a=parse(r/'paired-baseline-interfaces.log');b=parse(r/'paired-final-interfaces.log');assert a==b;print('declarations/types/axioms match',len(a))
for n in ('simp','instances'):
 a=(r/f'paired-baseline-{n}.log').read_bytes();b=(r/f'paired-final-{n}.log').read_bytes();assert a==b;print(n,'matches',len(a.splitlines()))
for ph in ('paired-baseline','paired-final'):
 x=json.loads((r/f'repeat-{ph}-records.json').read_text())[0];orig=rows[(ph,'ArithmeticRankForcing2011')];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])==orig['source_before'] and x['object_sha256']==h(x['object'])==orig['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']) and x['LEAN_PATH']==orig['LEAN_PATH']
 for d,e in zip(x['direct_inputs'],orig['direct_inputs']):assert d['module']==e['module'] and d['resolved']==e['resolved'] and d['object_before']==d['object_after']==h(d['path'])==e['object_before'] and d['source_before']==d['source_after']==h(d['source'])==e['source_before']
 print('repeat target',ph,x['timing'])
x=json.loads((r/'closure-probe-record.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(r/'closure-probe.log')
for d in x['objects']:assert d['before']==d['after']==h(d['path'])
assert (r/'closure-probe.log').read_text().splitlines()==['NAMESPACE DiophantineConsistency.ArithmeticModularCancellation COUNT 0','NAMESPACE DiophantineConsistency.SplitKernelData59 COUNT 0','NAMESPACE DiophantineConsistency.GapKernelData66 COUNT 0'];print('closure probe: all three namespaces absent')
g=json.loads((r/'full-graph.json').read_text());assert not g['ambiguous_modules'] and all(h(v['source'])==v['sha256'] for v in g['source_hashes'].values());im=g['imports'];root='DiophantineConsistency.ArithmeticConstructionAssembly'
def reaches(n,t,seen=None):
 if seen is None:seen=set()
 if n==t:return True
 if n in seen:return False
 seen.add(n);return any(reaches(k,t,seen) for k in im.get(n,[]))
assert reaches(root,'DiophantineConsistency.ArithmeticModularCancellation') and not reaches(root,'DiophantineConsistency.SplitKernelData59') and not reaches(root,'DiophantineConsistency.GapKernelData66');print('local current-source graph',len(im),'nodes',len(g['missing_modules']),'unresolved external modules: helper reachable, generated kernel modules not reached')
