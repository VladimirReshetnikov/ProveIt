from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/rank-order-cleanup');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
rows={}
for ph in ('baseline','final'):
 rr=load(R/f'{ph}-records.json'); assert [r['module'] for r in rr]==['ArithmeticRankForcing','ArithmeticRankForcing2011']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==sha(x['source']) and x['object_sha256']==sha(x['object']) and x['log_sha256']==sha(x['log'])
  if x['module']!='ArithmeticRankForcing':assert sha(W/f"{x['module']}.lean")==x['before']
  else:
   rev='062d55baa1^' if ph=='baseline' else '062d55baa1'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRankForcing.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert sha(W/'ArithmeticRankForcing.lean')==x['before']
  for d in x['direct_inputs']:
   assert d['before']==d['after']==sha(d['path'])
   if d['module'].endswith('.ArithmeticRankForcing'):assert d['before']==rr[0]['object_sha256']
  rows[ph,x['module']]=x
 assert all(x['status']==0 and x['source_before']==x['source_after']==sha(x['source']) and x['object_before']==x['object_after']==rr[0]['object_sha256'] and x['log_sha256']==sha(x['log']) for x in load(R/f'{ph}-probes.json'))
assert rows['baseline','ArithmeticRankForcing2011']['object_sha256']==rows['final','ArithmeticRankForcing2011']['object_sha256']
carry=next(x for x in load('/tmp/binary-carry-simplify/final-records.json') if x['module']=='ArithmeticBinaryCarry');assert carry['status']==0 and carry['before']==carry['after']==sha(W/'ArithmeticBinaryCarry.lean') and carry['object_sha256']==sha(carry['object'])
for ph in ('baseline','final'):
 x=rows[ph,'ArithmeticRankForcing'];assert x['direct_inputs'][0]['before']==carry['object_sha256']
prior=load('/tmp/rank-mask-residue/paired-final-records.json')[0]
for ph in ('baseline','final'):
 for x in rows[ph,'ArithmeticRankForcing2011']['direct_inputs']:
  if x['module'].endswith('.ArithmeticRankForcing'):continue
  d=next(d for d in prior['direct_inputs'] if d['module']==x['module']);name=x['module'].split('.')[-1];assert x['before']==d['object_before']==d['object_after'] and sha(W/f'{name}.lean')==d['source_before']==d['source_after']
for n in ('simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
def dec(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/f'{ph}-interfaces.log').read_text()) if v.strip()}
a,b=dec('baseline'),dec('final');removed=a.keys()-b.keys();assert len(b)==9 and len(removed)==2 and not b.keys()-a.keys() and all(a[n]==b[n] for n in b);assert {n.split('.')[-1] for n in removed}=={'le_split','one_le_of_pos'}
for n in ('simp','instances'):
 for d in removed:assert d not in (R/f'baseline-{n}.log').read_text()
f=load(R/'attempt1-baseline-records.json');assert len(f)==2 and f[0]['status']==0 and f[1]['status']!=0 and f[1]['log_sha256']==sha(R/'attempt1-baseline-ArithmeticRankForcing2011.log') and 'ArithmeticMaskPopulation.olean' in (R/'attempt1-baseline-ArithmeticRankForcing2011.log').read_text()
old=next(x for x in load('/tmp/window-digit-replace/baseline-records.json') if x['module']=='ArithmeticWindowDigits');assert old['before']==old['after']==hashlib.sha256(subprocess.check_output(['git','show','3e1cc2606b^:Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWindowDigits.lean'])).hexdigest();assert old['before']!=sha(W/'ArithmeticWindowDigits.lean')
for ph in ('baseline','final'):
 x=rows[ph,'ArithmeticRankForcing2011'];rel='DiophantineConsistency/ArithmeticWindowDigits.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert sha(p)==old['object_sha256']
print('PASS source snapshots, target/client receipts and pins, source-matched providers, census, failed attempt and post-build old WindowDigits sample')
print('Removed',*sorted(removed),sep='\n')
