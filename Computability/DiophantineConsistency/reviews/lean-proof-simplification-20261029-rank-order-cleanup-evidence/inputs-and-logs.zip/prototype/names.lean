import Lean.Elab.Command
import DiophantineConsistency.ArithmeticRankForcing
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRankForcing).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRankForcing" then
   logInfo m!"DECL {n}"
