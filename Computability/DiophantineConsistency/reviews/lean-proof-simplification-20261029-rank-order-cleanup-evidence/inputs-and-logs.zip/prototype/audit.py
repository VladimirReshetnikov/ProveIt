from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/tmp/rank-order-cleanup');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());rows={};m={}
carry=next(x for x in json.loads(Path('/tmp/binary-carry-simplify/final-records.json').read_text()) if x['module']=='ArithmeticBinaryCarry');assert carry['status']==0 and carry['before']==carry['after']==h(w/'ArithmeticBinaryCarry.lean') and carry['object_sha256']==h(carry['object']);m['ArithmeticBinaryCarry']=(carry['before'],carry['object_sha256']);print('adopted current BinaryCarry producer verified')
prior=json.loads(Path('/tmp/rank-mask-residue/paired-final-records.json').read_text())[0];assert prior['module']=='ArithmeticRankForcing2011' and prior['status']==0
for d in prior['direct_inputs']:
 n=d['module'].split('.')[-1]
 if n=='ArithmeticRankForcing':continue
 assert d['source_before']==d['source_after']==h(w/(n+'.lean')) and d['object_before']==d['object_after']==h(d['path']);m[n]=(d['source_before'],d['object_before']);print('historical current source/object pair',n)
for ph in ('baseline','final'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n=='ArithmeticRankForcing':
   ref='062d55baa1^' if ph=='baseline' else '062d55baa1';assert x['before']==hashlib.sha256(subprocess.check_output(['git','show',f'{ref}:{w}/{n}.lean'])).hexdigest();print('tested',ph,'matches',ref)
  else:assert x['before']==h(w/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);name=d['module'].split('.')[-1]
   if name in m:assert (h(w/(name+'.lean')),d['before'])==m[name]
   elif name=='ArithmeticRankForcing':assert d['before']==rows[ph,name]['object_sha256'] and d['resolved']==rows[ph,name]['object']
   else:raise Exception(name)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for ph in ('baseline','final'):
 for x in get(ph+'-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticRankForcing']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
assert rows['baseline','ArithmeticRankForcing2011']['object_sha256']==rows['final','ArithmeticRankForcing2011']['object_sha256'];print('client object identical')
def decl(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(r/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decl('baseline'),decl('final');rm={'_private.DiophantineConsistency.ArithmeticRankForcing.0.DiophantineConsistency.ArithmeticRankForcing.le_split','_private.DiophantineConsistency.ArithmeticRankForcing.0.DiophantineConsistency.ArithmeticRankForcing.one_le_of_pos'};assert a.keys()-b.keys()==rm and not b.keys()-a.keys() and len(b)==9 and all(a[k]==b[k] for k in b);print('9 existing declarations match; two private wrappers removed')
for n,c in [('simp',28971),('instances',13167)]:
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==c and all(name.encode() not in a for name in rm);print(n,c,'identical; removed names unregistered')
f=get('attempt1-baseline-records.json');assert len(f)==2 and f[0]['status']==0 and f[1]['status']!=0 and f[1]['log_sha256']==h(r/'attempt1-baseline-ArithmeticRankForcing2011.log');assert 'ArithmeticMaskPopulation.olean' in (r/'attempt1-baseline-ArithmeticRankForcing2011.log').read_text();print('initial nested-overlay client failure preserved')
import subprocess
prior=next(x for x in json.loads(Path('/tmp/window-digit-replace/baseline-records.json').read_text()) if x['module']=='ArithmeticWindowDigits');assert prior['status']==0 and prior['before']==prior['after']==hashlib.sha256(subprocess.check_output(['git','show','3e1cc2606b^:Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticWindowDigits.lean'])).hexdigest();assert h(w/'ArithmeticWindowDigits.lean')!=prior['before']
for ph in ('baseline','final'):
 x=rows[ph,'ArithmeticRankForcing2011']
 for name in ('ArithmeticWindowDigits','ArithmeticPellRecurrence','ArithmeticBinomLegendre','ArithmeticHalfBinomial'):
  rel='DiophantineConsistency/'+name+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());print('post-build cached closure sample',ph,name,str(p.resolve()),h(p))
  if name=='ArithmeticWindowDigits':assert h(p)==prior['object_sha256']
print('cached transitive inputs were not pinned at RankForcing build time')

assert h(w/'ArithmeticRankForcing.lean')==rows['final','ArithmeticRankForcing']['before'];print('post-commit workspace matches final')
