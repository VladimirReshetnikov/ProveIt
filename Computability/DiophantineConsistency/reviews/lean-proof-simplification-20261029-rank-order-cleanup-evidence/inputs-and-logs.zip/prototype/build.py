from pathlib import Path
import os,json,hashlib,subprocess,sys
r=Path('/tmp/rank-order-cleanup');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');common=r/'coherent';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ph=sys.argv[1];env=os.environ.copy();lib=r/('objects-'+ph);lib.mkdir(exist_ok=True)
if not (lib/'DiophantineConsistency').exists():subprocess.run(['cp','-as',str(common/'DiophantineConsistency'),str(lib/'DiophantineConsistency')],check=True)
for n in ('ArithmeticRankForcing','ArithmeticRankForcing2011'):(lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True)
s=r/ph/'DiophantineConsistency';s.mkdir(parents=True,exist_ok=True)
if ph=='baseline':(s/'ArithmeticRankForcing.lean').write_bytes((w/'ArithmeticRankForcing.lean').read_bytes())
(s/'ArithmeticRankForcing2011.lean').write_bytes((w/'ArithmeticRankForcing2011.lean').read_bytes())
jobs=[('ArithmeticRankForcing',s/'ArithmeticRankForcing.lean',['ArithmeticBinaryCarry']),('ArithmeticRankForcing2011',s/'ArithmeticRankForcing2011.lean',['ArithmeticRankForcing','ArithmeticMaskPopulation','ArithmeticMaskConstants','ArithmeticCarrierRadix2011'])];env['LEAN_PATH']=str(lib)+':/tmp/mask-ins-construction/final:'+env['LEAN_PATH'];rows=[]
for n,src,imports in jobs:
 inputs=[]
 for name in imports:
  rel='DiophantineConsistency/'+name+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());inputs.append({'module':'DiophantineConsistency.'+name,'path':str(p),'resolved':str(p.resolve()),'before':h(p)})
 obj=lib/'DiophantineConsistency'/(n+'.olean');tm=r/(ph+'-'+n+'.time');log=r/(ph+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/ph),str(src),'-o',str(obj)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path'])
 rec={'phase':ph,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None};rows.append(rec);(r/(ph+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(ph,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
