from pathlib import Path
import os,json,hashlib
p=Path('/tmp/claude-ax-sharing');g=json.loads((p/'graph.json').read_text())['nodes'];old=Path('/tmp/bisim-share/forward-baseline');root=Path('/dev/shm/claude-ax-current/common');root.mkdir(parents=True,exist_ok=True);h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for name in ('Foundation','PAHF','Diophantine'):
 f=old/name;t=root/name
 if f.exists() and not t.exists():t.symlink_to(f.resolve(),target_is_directory=True)
for n,v in g.items():
 for suf in ('.olean','.olean.private','.olean.server','.ir'):
  f=old/(n.replace('.','/')+suf);t=root/(n.replace('.','/')+suf)
  if f.exists() and not t.exists():t.parent.mkdir(parents=True,exist_ok=True);t.symlink_to(f.resolve())
fol=Path('/tmp/enumerator-firstorder-refresh/common/FirstOrder/Fol.olean');f=root/'FirstOrder/Fol.olean';f.unlink(missing_ok=True);f.parent.mkdir(exist_ok=True);f.symlink_to(fol.resolve());print('linked old graph objects plus fresh Fol:',len(g))
rec=json.loads(Path('/tmp/dag-independent-audit/fol-refresh-records.json').read_text());candidates={r['module']:r for r in rec if r['phase']=='shared' and r['module'] in g};selected=[];skipped=[]
for n,v in g.items():pass
# Preserve recorded refresh order; each candidate can only be reused if its current source and direct inputs match.
for r in rec:
 if r['phase']!='shared' or r['module'] not in candidates:continue
 n=r['module'];f=Path(g[n]['source']);out=Path(r['object']);reasons=[]
 if h(f)!=r['source_sha256'] or h(out)!=r['object_sha256']:reasons.append('source/object mismatch')
 for dep,x in r['direct_project_inputs'].items():
  t=root/(dep.replace('.','/')+'.olean')
  if not t.exists() or h(t)!=x['sha256']:reasons.append(dep)
 if reasons:skipped.append({'module':n,'reason':reasons});continue
 t=root/(n.replace('.','/')+'.olean');t.parent.mkdir(parents=True,exist_ok=True);t.unlink(missing_ok=True);t.symlink_to(out.resolve());selected.append(n)
(p/'coherent-seeds.json').write_text(json.dumps({'root':str(root),'fol':{'path':str(fol.resolve()),'sha256':h(fol)},'selected':selected,'skipped':skipped},indent=2)+'\n');print('reused',len(selected),'skipped',len(skipped));print('skip details',skipped[:8])
