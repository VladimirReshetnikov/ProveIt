from pathlib import Path
import os,json,subprocess,hashlib,time,shutil
p=Path('/tmp/claude-ax-sharing');root=Path('/dev/shm/claude-ax-current/common');g=json.loads((p/'graph.json').read_text())['nodes'];plan=json.loads((p/'coherent-plan.json').read_text());lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp;h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();records=[]
for n in plan['common_order']:
 if shutil.disk_usage('.').free<850*1024*1024 or shutil.disk_usage('/dev/shm').free<256*1024*1024:raise RuntimeError('disk or shm reserve too low')
 f=Path(g[n]['source']);suffix=n.replace('.','/')+'.lean';assert str(f).endswith(suffix);srcroot=str(f)[:-len(suffix)].rstrip('/');out=root/(n.replace('.','/')+'.olean');log=p/('common-'+n.replace('.','_')+'.log');tm=p/('common-'+n.replace('.','_')+'.time');inputs=[]
 for d in g[n]['imports']:
  if d not in g:continue
  q=root/(d.replace('.','/')+'.olean');assert q.exists(),(n,d,'missing');inputs.append({'module':d,'path':str(q.resolve()),'sha256':h(q)})
 before=h(f);assert before==g[n]['sha256'],(n,'source drift');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',srcroot,str(f),'-o',str(out)]
 with log.open('wb') as o:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT).returncode
 rec={'module':n,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(f),'source_sha256':before,'source_after':h(f),'direct_inputs':inputs,'direct_inputs_after':[h(x['path']) for x in inputs],'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,3)};records.append(rec);(p/'coherent-common-records.json').write_text(json.dumps(records,indent=2)+'\n');print(len(records),n,rc,flush=True)
 assert rc==0 and rec['source_sha256']==rec['source_after'] and [x['sha256'] for x in inputs]==rec['direct_inputs_after']
