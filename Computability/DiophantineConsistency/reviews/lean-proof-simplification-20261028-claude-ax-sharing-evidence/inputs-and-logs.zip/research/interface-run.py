from pathlib import Path
import os,subprocess,hashlib,json,time
p=Path('/tmp/claude-ax-sharing');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=[]
for ph in ('baseline','final'):
 root=Path('/dev/shm/claude-ax-current')/ph;env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp;pins=json.loads((p/(ph+'-phase-input-pins.json')).read_text())
 for tag in ('interface','private-meta'):
  f=p/(tag+'.lean');log=p/(ph+'-'+tag+'.log');tm=p/(ph+'-'+tag+'.time')
  def verify():
   for x in pins['local']:assert h(x['source'])==h(x['source_snapshot'])==x['source_sha256'] and h(x['object'])==x['object_sha256'],(ph,x['module'])
   for x in pins['external']:assert h(x['path'])==x['sha256'],(ph,x['module'])
   for x in json.loads((p/'phase-records.json').read_text()):
    if x['phase']==ph:assert h(x['source'])==x['source_sha256']==x['source_after'] and h(x['object'])==x['object_sha256'],(ph,x['module'],'phase target drift')
  verify();before=h(f);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p),str(f)]
  with log.open('wb') as o:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT).returncode
  verify();r={'phase':ph,'tag':tag,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(f),'source_sha256':before,'source_after':h(f),'log_sha256':h(log),'time_sha256':h(tm),'local_pins':len(pins['local']),'external_pins':len(pins['external']),'phase_target_pins':6,'pins_verified_before_after':True,'elapsed':round(time.monotonic()-t,3)};rs.append(r);(p/'interface-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,tag,rc,flush=True);assert rc==0 and before==r['source_after']
