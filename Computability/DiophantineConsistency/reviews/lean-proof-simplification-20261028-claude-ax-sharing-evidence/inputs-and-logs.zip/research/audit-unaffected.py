from pathlib import Path
import json,hashlib
p=Path('/tmp/claude-ax-sharing');g=json.loads((p/'graph.json').read_text())['nodes'];plan=json.loads((p/'coherent-plan.json').read_text());old={r['module']:r for r in json.loads(Path('/tmp/bisim-share/forward-common-pins.json').read_text())['selected']};root=Path('/dev/shm/claude-ax-current/common');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rows=[]
for n in sorted(set(g)-set(plan['affected'])):
 q=root/(n.replace('.','/')+'.olean');f=Path(g[n]['source']);r=old[n];assert q.exists() and h(q)==r['object_sha256'] and h(f)==r['source_sha256'];rows.append({'module':n,'source':str(f),'source_sha256':h(f),'object':str(q.resolve()),'object_sha256':h(q),'prior_receipt':'/tmp/bisim-share/forward-common-pins.json'})
(p/'unaffected-pins.json').write_text(json.dumps(rows,indent=2)+'\n');print('verified unaffected source/object pairs',len(rows))
