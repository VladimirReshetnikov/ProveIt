from pathlib import Path
import os,subprocess,hashlib,json,time,shutil
p=Path('/tmp/claude-ax-sharing');G=json.loads((p/'graph.json').read_text());g=G['nodes'];lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();name_order=['ArithmeticCommandPreservationPerm222','ArithmeticCommandPreservationPerm222Checks','ArithmeticEnumSoundnessPerm222','ArithmeticEnumBoundSoundness','ArithmeticRuntimeBound215','ArithmeticRuntimeBoundDagHalt'];targets={'DiophantineConsistency.'+n for n in name_order};records=[]
for ph in ('baseline','final'):
 root=Path('/dev/shm/claude-ax-current')/ph;env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp;local=[];external=[]
 for n,v in g.items():
  if n in targets:continue
  f=Path(v['source']);s=p/'sources'/ph/(n.replace('.','/')+'.lean');o=root/(n.replace('.','/')+'.olean');assert f.exists() and s.exists() and o.exists(),(n,'missing pin');assert h(f)==h(s)==v['sha256'],(n,'source drift');local.append({'module':n,'source':str(f),'source_snapshot':str(s),'source_sha256':h(f),'object':str(o.resolve()),'object_sha256':h(o)})
 for n in G['external']:
  q=None
  for part in env['LEAN_PATH'].split(':'):
   b=Path(part)
   if (b/n.split('.')[0]).exists():
    t=b/(n.replace('.','/')+'.olean')
    if t.exists():q=t;break
    raise RuntimeError((n,'shadow missing',part))
  assert q is not None,(n,'external missing');external.append({'module':n,'path':str(q.resolve()),'sha256':h(q)})
 (p/(ph+'-phase-input-pins.json')).write_text(json.dumps({'local':local,'external':external},indent=2)+'\n')
 def pins():
  for x in local:assert h(x['source'])==h(x['source_snapshot'])==x['source_sha256'] and h(x['object'])==x['object_sha256'],(ph,x['module'],'local drift')
  for x in external:assert h(x['path'])==x['sha256'],(ph,x['module'],'external drift')
 for name in name_order:
  if shutil.disk_usage('.').free<850*1024*1024 or shutil.disk_usage('/dev/shm').free<256*1024*1024:raise RuntimeError('disk or shm reserve too low')
  n='DiophantineConsistency.'+name;src=p/'sources'/ph/(n.replace('.','/')+'.lean');out=root/(n.replace('.','/')+'.olean');log=p/(ph+'-'+name+'.log');tm=p/(ph+'-'+name+'.time');pins();direct=[]
  for d in g[n]['imports']:
   if d not in g:continue
   q=root/(d.replace('.','/')+'.olean');assert q.exists(),(name,d);direct.append({'module':d,'path':str(q.resolve()),'sha256':h(q)})
  before=h(src);out.unlink(missing_ok=True);out.parent.mkdir(parents=True,exist_ok=True);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p/'sources'/ph),str(src),'-o',str(out)]
  with log.open('wb') as o:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT).returncode
  pins();rec={'phase':ph,'module':n,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'direct_inputs':direct,'direct_inputs_after':[h(x['path']) for x in direct],'local_pins':len(local),'external_pins':len(external),'pins_verified_before_after':True,'elapsed':round(time.monotonic()-t,3)};records.append(rec);(p/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(ph,name,rc,flush=True);assert rc==0 and rec['source_sha256']==rec['source_after'] and [x['sha256'] for x in direct]==rec['direct_inputs_after']
