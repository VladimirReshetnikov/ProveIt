import DiophantineConsistency.ArithmeticEnumBoundSoundness
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n0 := `DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_7
  logInfo m!"DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_7: {t.isLemma (.decl n0 true false)} {t.isLemma (.decl n0 false false)} {t.isLemma (.decl n0 true true)} {t.isLemma (.decl n0 false true)}"
  let n1 := `DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_8
  logInfo m!"DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_8: {t.isLemma (.decl n1 true false)} {t.isLemma (.decl n1 false false)} {t.isLemma (.decl n1 true true)} {t.isLemma (.decl n1 false true)}"
  let n2 := `DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._simp_6
  logInfo m!"DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._simp_6: {t.isLemma (.decl n2 true false)} {t.isLemma (.decl n2 false false)} {t.isLemma (.decl n2 true true)} {t.isLemma (.decl n2 false true)}"
  let n3 := `DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_10
  logInfo m!"DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_10: {t.isLemma (.decl n3 true false)} {t.isLemma (.decl n3 false false)} {t.isLemma (.decl n3 true true)} {t.isLemma (.decl n3 false true)}"
  let n4 := `DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_9
  logInfo m!"DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._proof_9: {t.isLemma (.decl n4 true false)} {t.isLemma (.decl n4 false false)} {t.isLemma (.decl n4 true true)} {t.isLemma (.decl n4 false true)}"
  let n5 := `DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._simp_8
  logInfo m!"DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._simp_8: {t.isLemma (.decl n5 true false)} {t.isLemma (.decl n5 false false)} {t.isLemma (.decl n5 true true)} {t.isLemma (.decl n5 false true)}"
  let n6 := `DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._simp_7
  logInfo m!"DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses_le._simp_7: {t.isLemma (.decl n6 true false)} {t.isLemma (.decl n6 false false)} {t.isLemma (.decl n6 true true)} {t.isLemma (.decl n6 false true)}"
