from pathlib import Path
import os
p=Path('/tmp/claude-ax-sharing');base=Path('/dev/shm/claude-ax-current/common')
for ph in ('baseline','final'):
 root=Path('/dev/shm/claude-ax-current')/ph;root.mkdir(parents=True,exist_ok=True)
 for parent,dirs,files in os.walk(base,followlinks=False):
  a=Path(parent);r=root/a.relative_to(base);r.mkdir(parents=True,exist_ok=True)
  for n in list(dirs):
   f=a/n;t=r/n
   if f.is_symlink():
    if not t.exists():t.symlink_to(f.resolve(),target_is_directory=True)
    dirs.remove(n)
  for n in files:
   f=a/n;t=r/n
   if not t.exists():t.symlink_to(f.resolve())
 print(ph,'prepared')
