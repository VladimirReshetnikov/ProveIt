import DiophantineConsistency.ArithmeticEnumBoundSoundness
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open _root_.SetTheory.BusyBeaver.ZFC ArithmeticCantor
open _root_.SetTheory.BusyBeaver.ZFC.ArithmeticProofConstructors222
open DiophantineConsistency.ArithmeticCommandPreservationPerm222
open DiophantineConsistency.ArithmeticEnumBoundSoundness
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (B a b c u ph : V) :
    witnessBound B (axWitnesses a b c u ph) =
      witnessBound B [gateWitness a b c, node 3 (cantor a b), node 4 (cantor a (cantor b c)),
        node 5 (cantor a (cantor b c)), node 6 (cantor a (cantor b c)),
        node 7 (cantor a (cantor b c)), node 8 (cantor a c), node 9 (cantor a (cantor b c)),
        node 10 (cantor a (cantor b (cantor c u))), node 2 (cantor u ph)] := rfl
