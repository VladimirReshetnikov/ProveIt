from pathlib import Path
p=Path('/tmp/claude-ax-sharing');src=Path('/tmp/bisim-share/forward-baseline');dest=p/'overlay';dest.mkdir(exist_ok=True)
for x in src.iterdir():
 if x.name=='DiophantineConsistency':
  d=dest/x.name;d.mkdir(exist_ok=True)
  for f in x.iterdir():
   if f.is_file() and not (d/f.name).exists():(d/f.name).symlink_to(f.resolve())
 elif not (dest/x.name).exists():(dest/x.name).symlink_to(x.resolve(),target_is_directory=x.is_dir())
print('overlay ready')
