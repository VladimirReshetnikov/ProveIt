from pathlib import Path
import json
p=Path('/tmp/claude-ax-sharing');G=json.loads((p/'graph.json').read_text())['nodes'];a={'FirstOrder.Fol'}
while True:
 nxt={n for n,v in G.items() if any(d in a for d in v['imports'])}
 if nxt<=a:break
 a|=nxt
seed=set(json.loads((p/'coherent-seeds.json').read_text())['selected'])|{'FirstOrder.Fol','BusyBeaver.ZFC.ArithmeticMachineStepPerm252'}
targets={'DiophantineConsistency.'+n for n in ('ArithmeticCommandPreservationPerm222','ArithmeticEnumBoundSoundness','ArithmeticEnumSoundnessPerm222','ArithmeticCommandPreservationPerm222Checks','ArithmeticRuntimeBoundDagHalt','ArithmeticRuntimeBound215')};todo=a-seed-targets;order=[]
while todo:
 ready=sorted(n for n in todo if not any(i in todo for i in G[n]['imports']));assert ready,todo
 order.extend(ready);todo-=set(ready)
assert len(order)==42 and not any(set(G[n]['imports'])&targets for n in order)
(p/'coherent-plan.json').write_text(json.dumps({'affected':sorted(a),'seeds':sorted(seed),'common_order':order,'phase_targets':sorted(targets)},indent=2)+'\n');print('common order',len(order),'phase targets',len(targets))
