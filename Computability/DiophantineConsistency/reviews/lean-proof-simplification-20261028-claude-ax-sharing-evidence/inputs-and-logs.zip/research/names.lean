import Lean.Elab.Command
import DiophantineConsistency.ArithmeticEnumBoundSoundness
#print equations DiophantineConsistency.ArithmeticCommandPreservationPerm222.witnessBound
#print equations DiophantineConsistency.ArithmeticEnumBoundSoundness.gateWitness
#print equations DiophantineConsistency.ArithmeticEnumBoundSoundness.axWitnesses
#print equations DiophantineConsistency.ArithmeticEnumBoundSoundness.soundBound
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticCommandPreservationPerm222).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticEnumBoundSoundness).isPrefixOf n ||
       n.toString.startsWith "_private.DiophantineConsistency.ArithmeticCommandPreservationPerm222." ||
       n.toString.startsWith "_private.DiophantineConsistency.ArithmeticEnumBoundSoundness." then
      logInfo m!"DECL {n}"
