from pathlib import Path
import hashlib,json,shutil
p=Path('/tmp/claude-ax-sharing');g=json.loads((p/'graph.json').read_text())['nodes'];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();changed={'DiophantineConsistency.ArithmeticCommandPreservationPerm222','DiophantineConsistency.ArithmeticEnumBoundSoundness'};issues=[]
for ph in ('baseline','final'):
 for n,v in g.items():
  f=(p/ph/'DiophantineConsistency'/(n.split('.')[-1]+'.lean')) if n in changed else Path(v['source'])
  if n not in changed and h(f)!=v['sha256']:issues.append(n)
  t=p/'sources'/ph/(n.replace('.','/')+'.lean');t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,t)
print('snapshots',len(g)*2,'issues',issues);assert not issues
