from pathlib import Path
import json,hashlib
P=Path('/tmp/claude-ax-sharing');R=Path('/dev/shm/claude-ax-current/common');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();g=json.loads((P/'graph.json').read_text())['nodes'];pins=json.loads((P/'baseline-phase-input-pins.json').read_text());pins={x['module']:x for x in pins['local']};s=json.loads((P/'coherent-seeds.json').read_text()); prior=json.loads(Path('/tmp/dag-independent-audit/fol-refresh-records.json').read_text());prior={r['module']:r for r in prior if r['phase']=='shared'}
assert len(s['selected'])==35 and not s['skipped'] and H(s['fol']['path'])==s['fol']['sha256']
for n in s['selected']:
 r=prior[n]; assert r['status']==0 and H(r['source'])==r['source_sha256']==r['source_after']==pins[n]['source_sha256'] and H(r['object'])==r['object_sha256']==pins[n]['object_sha256'],n
 assert H(r['log'])==r['log_sha256'] and H(r['time'])==r['time_sha256'],n
 for d,x in r['direct_project_inputs'].items():assert H(R/(d.replace('.','/')+'.olean'))==x['sha256'],(n,d)
 assert set(r['direct_project_inputs'])==set(g[n]['imports']) & set(g),(n,'direct coverage')
print('35 prior seeds: source/object/log/time and complete selected local direct-input hashes match')
a=json.loads((P/'additional-seed.json').read_text());assert H(a['source'])==a['source_sha256']==pins[a['module']]['source_sha256'] and H(a['object'])==a['object_sha256']==pins[a['module']]['object_sha256']
for x in a['direct_inputs']:assert H(R/(x['module'].replace('.','/')+'.olean'))==x['sha256']
print('additional seed source/object and its recorded direct input match; fol source/object is a prior cache boundary')
prev=json.loads(Path('/tmp/bisim-share/forward-common-pins.json').read_text());prev={x['module']:x for x in prev['selected']};un=json.loads((P/'unaffected-pins.json').read_text());assert len(un)==66
for x in un:
 n=x['module']; y=prev[n]; assert H(x['source'])==x['source_sha256']==y['source_sha256']==pins[n]['source_sha256'] and H(x['object'])==x['object_sha256']==y['object_sha256']==pins[n]['object_sha256'],n
print('66 unaffected local objects have matching prior source/object pins; no assertion of complete direct-input provenance')
