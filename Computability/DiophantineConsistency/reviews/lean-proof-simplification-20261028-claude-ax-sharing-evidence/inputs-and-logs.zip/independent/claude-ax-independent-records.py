import json,hashlib
from pathlib import Path
P=Path('/tmp/claude-ax-sharing'); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
G=json.loads((P/'graph.json').read_text()); nodes=G['nodes']; old={}; finals={}
for phase in ('baseline','final'):
 pin=json.loads((P/(phase+'-phase-input-pins.json')).read_text()); assert len(pin['local'])==145 and len(pin['external'])==9
 for x in pin['local']:
  assert H(x['source'])==H(x['source_snapshot'])==x['source_sha256'] and H(x['object'])==x['object_sha256'],x['module']
 for x in pin['external']:assert H(x['path'])==x['sha256'],x['module']
 print(phase,'145 local + 9 direct external pins match')
rs=json.loads((P/'coherent-common-records.json').read_text());assert len(rs)==42
for x in rs:
 assert x['status']==0 and H(x['source'])==x['source_sha256']==x['source_after'] and H(x['object'])==x['object_sha256'],x['module']
 assert [i['sha256'] for i in x['direct_inputs']]==x['direct_inputs_after'],x['module']
 for i in x['direct_inputs']: assert H(i['path'])==i['sha256'],(x['module'],i['module'])
 n=x['module'].replace('.','_'); assert H(P/('common-'+n+'.log'))==x['log_sha256'] and H(P/('common-'+n+'.time'))==x['time_sha256']
 assert set(i['module'] for i in x['direct_inputs'])==set(nodes[x['module']]['imports']) & set(nodes),(x['module'],'direct coverage')
print('42 common builds: source, output, log, timing and direct inputs match')
rs=json.loads((P/'phase-records.json').read_text());assert len(rs)==12,len(rs)
for x in rs:
 ph=x['phase'];n=x['module'].split('.')[-1];assert x['status']==0 and H(x['source'])==x['source_sha256']==x['source_after'] and H(x['object'])==x['object_sha256'],x['module']
 assert (x['local_pins'],x['external_pins'])==(145,9) and x['pins_verified_before_after']
 assert [i['sha256'] for i in x['direct_inputs']]==x['direct_inputs_after'],x['module']
 for i in x['direct_inputs']:assert H(i['path'])==i['sha256'],(ph,x['module'],i['module'])
 assert set(i['module'] for i in x['direct_inputs'])==set(nodes[x['module']]['imports']) & set(nodes),(ph,x['module'],'direct coverage')
 assert H(P/(ph+'-'+n+'.log'))==x['log_sha256'] and H(P/(ph+'-'+n+'.time'))==x['time_sha256']
 print(ph,n,'ok, direct',len(x['direct_inputs']))
print('12 paired targets: source, output, log, timing and direct input pins match')
