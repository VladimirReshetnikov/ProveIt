from pathlib import Path
import hashlib,json
P=Path('/tmp/claude-ax-sharing');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for f in ('probe-records.json','interface-records.json'):
 rs=json.loads((P/f).read_text());assert len(rs)==4
 for x in rs:
  assert x['status']==0 and H(x['source'])==x['source_sha256']==x['source_after'] and (x['local_pins'],x['external_pins'],x['phase_target_pins'])==(145,9,6) and x['pins_verified_before_after']
  assert H(P/(x['phase']+'-'+x['tag']+'.log'))==x['log_sha256'] and H(P/(x['phase']+'-'+x['tag']+'.time'))==x['time_sha256']
  print(x['phase'],x['tag'],'ok')
print('eight probes: source, logs, timings, and before/after pin assertions verified')
for n in ('witness-equality','private-meta'):
 assert (P/('baseline-'+n+'.log')).read_bytes()==(P/('final-'+n+'.log')).read_bytes(),n
print('witness and private-meta logs match')
