import DiophantineConsistency.ArithmeticTilingWord
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticTilingWord).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticTilingWord" then
   logInfo m!"DECL {n}"
