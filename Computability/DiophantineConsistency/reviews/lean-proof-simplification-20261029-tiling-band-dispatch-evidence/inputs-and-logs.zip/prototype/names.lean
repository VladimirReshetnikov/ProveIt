import DiophantineConsistency.ArithmeticTilingBand
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticTilingBand).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticTilingBand" then
   logInfo m!"DECL {n}"
