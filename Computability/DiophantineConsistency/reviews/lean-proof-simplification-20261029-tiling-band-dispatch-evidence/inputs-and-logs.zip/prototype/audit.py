from pathlib import Path
import hashlib,json,re
R=Path('/tmp/tiling-band-dispatch');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
prior={}
for n,f in [('ArithmeticTilingRows','/tmp/rowrel-sharing/alternate-records.json'),('ArithmeticPow','/tmp/outer-seed-bound-sharing/prereq2-records.json')]:
 x=next(x for x in json.loads(Path(f).read_text()) if x.get('module','').split('.')[-1]==n and x.get('status')==0 and x.get('source_before',x.get('source_sha256'))==h(W/(n+'.lean')));prior[n]=x['object_sha256'];print('current-source prior receipt',n,prior[n],f)
for ph in ['baseline','final']:
 rows[ph]=json.loads((R/(ph+'-records.json')).read_text())
 for x in rows[ph]:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-'+n+'.time')).read_text()
  if ph=='baseline' or n!='ArithmeticTilingBand':assert x['before']==h(W/(n+'.lean'))
  imports=re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M);assert imports==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1]
   if m in prior:assert d['before']==prior[m]
   elif m=='ArithmeticTilingBand':assert d['before']==rows[ph][0]['object_sha256'] and d['resolved']==rows[ph][0]['object']
   else:raise AssertionError(m)
  print('build',ph,n,x['time'].strip())
 for n in ['names','interfaces','simp','instances']:
  x=json.loads((R/f'probe-{n}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
for x in json.loads((R/'client-probe2-records.json').read_text()):
 ph=x['phase'];n=x['probe'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[rows[ph][0]['object_sha256'],rows[ph][1]['object_sha256']] and all(h(p)==v for p,v in zip(x['objects'],x['objects_before'])) and x['log_sha256']==h(x['log'])
 assert (R/f'{ph}-client-{n}.log').read_bytes()==(R/f'{ph}-client2-{n}.log').read_bytes()
def ds(ph,prefix):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(ph+'-'+prefix+'interfaces.log')).read_text()) if v.strip()}
for prefix,count in [('',57),('client2-',18)]:
 a,b=ds('baseline',prefix),ds('final',prefix);assert len(a)==count and a==b;print(prefix or 'target',count,'declaration/type/axiom reports match')
for prefix,counts in [('',[29730,13394]),('client2-',[29733,13397])]:
 for n,c in zip(['simp','instances'],counts):
  a=(R/('baseline-'+prefix+n+'.log')).read_bytes();b=(R/('final-'+prefix+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==c;print(prefix or 'target',n,c)
print('TilingWord object hashes differ',rows['baseline'][1]['object_sha256'],rows['final'][1]['object_sha256']);assert rows['baseline'][1]['object_sha256']!=rows['final'][1]['object_sha256']
samples=[]
for n in ['ArithmeticBinaryCarry','ArithmeticHalfBinomial','ArithmeticBinomLegendre','ArithmeticPellRecurrence']:
 lp=rows['baseline'][0]['LEAN_PATH'];rel='DiophantineConsistency/'+n+'.olean';p=next(Path(q)/rel for q in lp.split(':') if (Path(q)/rel).is_file());samples.append({'module':n,'path':str(p),'resolved':str(p.resolve()),'object_sha256':h(p),'current_source_sha256':h(W/(n+'.lean'))})
(R/'post-build-path-samples.json').write_text(json.dumps(samples,indent=2)+'\n');print('post-build search-path samples (not build-pinned inputs)',*[x['module']+':'+x['object_sha256'] for x in samples])
print('all checks passed')
