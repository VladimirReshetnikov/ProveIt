from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-tiling-band-dispatch-evidence';out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/tiling-band-dispatch');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','final']:
 for p in sorted((R/phase).rglob('*.lean')):add('snapshots/'+str(p.relative_to(R)),p)
for name in ['tiling-band-independent-review.txt','tiling-band-independent-audit.py','tiling-band-independent-audit.log']:add('independent/'+name,I/name)
refs={'prior/rowrel-alternate-records.json':'rowrel-sharing/alternate-records.json','prior/pow-prereq-records.json':'outer-seed-bound-sharing/prereq-records.json','prior/pow-prereq2-records.json':'outer-seed-bound-sharing/prereq2-records.json','prior/binary-carry-assembly-builds2.json':'outer-seed-bound-sharing/assembly-builds2.json','prior/rank-mask-cached-boundaries.json':'rank-mask-residue/cached-boundaries.json'}
for n,p in refs.items():add(n,I/p)
add('bundle/build-tiling-band-bundle.py',Path(__file__))
commit='e579fb28da3ee5b6487598d5827dba80e113b604';parent='3b145fe9782afb8edce9172e4af7ad846cac8682';base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';h=lambda b:hashlib.sha256(b).hexdigest()
for phase,ref in [('baseline',parent),('final',commit)]:
 for name in ['ArithmeticTilingBand','ArithmeticTilingWord']:
  data=subprocess.check_output(['git','show',ref+':'+base+name+'.lean']);assert data==files['snapshots/'+phase+'/DiophantineConsistency/'+name+'.lean'];
  if name=='ArithmeticTilingBand':files['commit/'+phase+'.lean']=data
row=next(x for x in json.loads(files['prior/rowrel-alternate-records.json']) if x['module']=='ArithmeticTilingRows' and x['status']==0);powr=next(x for x in json.loads(files['prior/pow-prereq-records.json']) if x['module'].endswith('.ArithmeticPow') and x['status']==0)
for mod,expected in [('ArithmeticTilingRows',row['source_before']),('ArithmeticPow',powr['source_sha256'])]:
 data=subprocess.check_output(['git','show',commit+':'+base+mod+'.lean']);assert h(data)==expected;files['providers/current/'+mod+'.lean']=data
review=files['independent/tiling-band-independent-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Simplify tiling-band conditional relation proofs',
 'validation':'Paired target and ArithmeticTilingWord direct-client builds pass with matching source-current Rows and Pow provider receipts. All 57 target and 18 client declaration/type/axiom reports match; target and client simp/instance reports match. Corrected client probes pin both target and client objects before and after each probe.',
 'limitations':['The baseline and final ArithmeticTilingWord object hashes differ for an undetermined reason; matching interface and registration probes do not establish identical compiled proof terms or every environment extension.','The only direct source importer found under Computability/DiophantineConsistency/Lean is ArithmeticTilingWord. Other transitive clients and all environment extensions remain outside checked scope.','Post-build search-path samples resolve older BinaryCarry, HalfBinomial, BinomLegendre and PellRecurrence objects. These transitive entries were not individually pinned during target builds, so the samples do not prove their historical bytes or that each was loaded. Other project/Foundation/package dependencies are cached; no full current-source closure build is established.','One shared-load timing pair is not a general benchmark. Target and client warnings occur in both phases; source line numbers shift in the changed target.','The successful preliminary final build log/time survive, but its referenced target output path was overwritten by the paired final build. No failed proof attempt was recorded.','Compiled objects are not included in the ZIP; object hashes and input resolution are preserved in receipts, and external objects are needed for independent byte checks.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
