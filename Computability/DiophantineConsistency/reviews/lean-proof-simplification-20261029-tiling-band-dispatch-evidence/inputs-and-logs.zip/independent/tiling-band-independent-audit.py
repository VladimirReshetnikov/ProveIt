from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/tiling-band-dispatch');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
a=(R/'baseline/DiophantineConsistency/ArithmeticTilingBand.lean').read_text();b=(R/'final/DiophantineConsistency/ArithmeticTilingBand.lean').read_text()
old1='''  by_cases h0 : k = 0
  · simp [h0]
  · by_cases h1 : k = 1
    · simp [h1]
    · by_cases h2 : k + 1 = H <;> simp [h0, h1, h2]
''';old2='''  by_cases hX : X = 0
  · simp [hX]
  · by_cases h0 : k = 0
    · simp [hX, h0]
    · by_cases h1 : k + 1 = H
      · simp [hX, h0, h1]
      · by_cases h2 : k + 2 = H <;> simp [hX, h0, h1, h2]
''';new='  split_ifs <;> simp_all\n';assert a.count(old1)==a.count(old2)==1 and b==a.replace(old1,new).replace(old2,new);rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingBand.lean'
for ref,ph in [('e579fb28da^','baseline'),('e579fb28da','final')]:
 assert hashlib.sha256(subprocess.check_output(['git','show',ref+':'+rel])).hexdigest()==h(R/ph/'DiophantineConsistency/ArithmeticTilingBand.lean');print('git source snapshot matches',ref,ph)
assert h(W/'ArithmeticTilingBand.lean')==h(R/'final/DiophantineConsistency/ArithmeticTilingBand.lean');print('exact two-proof substitution, workspace now final')
prior=read('/tmp/rowrel-sharing/alternate-records.json');rowsprov=next(x for x in prior if x['module']=='ArithmeticTilingRows' and x['status']==0);assert rowsprov['source_before']==rowsprov['source_after']==h(W/'ArithmeticTilingRows.lean') and rowsprov['object_sha256']==h(rowsprov['object']);print('Rows prior source/object receipt matched',rowsprov['object_sha256'])
pows=read('/tmp/outer-seed-bound-sharing/prereq-records.json');power=next(x for x in pows if x['module'].endswith('.ArithmeticPow') and x['status']==0);assert power['source_sha256']==h(W/'ArithmeticPow.lean');print('Pow prior source receipt matched',power['object_sha256'])
rows={}
for ph in ['baseline','final']:
 rec=read(R/(ph+'-records.json'));assert len(rec)==2
 for x in rec:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][4]).read_text()
  if n!='ArithmeticTilingBand':assert x['before']==h(W/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n0=d['module'].split('.')[-1]
   if n0=='ArithmeticTilingBand':assert d['before']==rows[ph,n0]['object_sha256'] and d['resolved']==rows[ph,n0]['object']
   elif n0=='ArithmeticTilingRows':assert d['before']==rowsprov['object_sha256']
   elif n0=='ArithmeticPow':assert d['before']==power['object_sha256']
   else:raise AssertionError(n0)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
print('TilingWord client objects identical?',rows['baseline','ArithmeticTilingWord']['object_sha256']==rows['final','ArithmeticTilingWord']['object_sha256'])
for k in ['names','interfaces','simp','instances']:
 for ph in ['baseline','final']:
  x=read(R/f'probe-{k}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticTilingBand']['object_sha256'] and x['log_sha256']==h(x['log'])
 a=(R/('baseline-'+k+'.log')).read_bytes();b=(R/('final-'+k+'.log')).read_bytes();assert a==b;print('probe',k,'identical',len(a.splitlines()),'lines')
for k in ['names','interfaces','simp','instances']:
 for ph in ['baseline','final']:
  x=read(R/f'client-probe-{k}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticTilingWord']['object_sha256'] and x['log_sha256']==h(x['log'])
 a=(R/('baseline-client-'+k+'.log')).read_bytes();b=(R/('final-client-'+k+'.log')).read_bytes();assert a==b;print('client probe',k,'identical',len(a.splitlines()),'lines')
assert sum(s.startswith('DECL ') for s in (R/'baseline-client-names.log').read_text().splitlines())==18
for x in read(R/'client-probe2-records.json'):
 ph=x['phase'];k=x['probe'];expected=[rows[ph,n]['object_sha256'] for n in ['ArithmeticTilingBand','ArithmeticTilingWord']]
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==expected and all(h(p)==v for p,v in zip(x['objects'],expected)) and x['log_sha256']==h(x['log'])
 assert Path(x['log']).read_bytes()==(R/(ph+'-client-'+k+'.log')).read_bytes();print('strong client probe',ph,k,'pins target/client and matches earlier log')
pre=read(R/'preliminary-final-records.json')[0]
assert pre['status']==0 and pre['before']==pre['after']==h(pre['source']) and pre['log_sha256']==h(R/'preliminary-final.log') and pre['time']==(R/'preliminary-final.time').read_text();print('preliminary final log/time match; original target object path overwritten by paired replay')
print('PASS; transitive cached closure not rebuilt')
