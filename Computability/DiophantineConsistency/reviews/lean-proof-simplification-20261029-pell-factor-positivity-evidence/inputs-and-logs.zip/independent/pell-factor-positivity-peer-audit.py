from pathlib import Path
import hashlib,json,subprocess
p=Path('/dev/shm/pell-factor-positivity');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); n='ArithmeticPellIntegralSolution';h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
a=(p/'baseline/DiophantineConsistency'/f'{n}.lean').read_text(); b=(p/'final/DiophantineConsistency'/f'{n}.lean').read_text();assert b==(repo/f'{n}.lean').read_text()
rel=str(repo/f'{n}.lean')
assert subprocess.check_output(['git','show','3b87f2fa76^:'+rel]).decode()==a
assert subprocess.check_output(['git','show','3b87f2fa76:'+rel]).decode()==b
print('Commit 3b87f2fa76 and parent match final/baseline snapshots')
old1='''    by_contra hng
    have hz : g=0 := le_antisymm (le_of_not_gt hng) (Arithmetic.zero_le g)
    have hnz : n=0 := by simpa [hz] using hgn
    exact (ne_of_gt hn) hnz'''
new1='''    obtain ⟨k, hk⟩ := hgn
    exact pos_of_mul_pos_left (by rw [← hk]; exact hn) (by simp)'''
old2='''  have hmp : 0<m := by
    by_contra hm
    have hz : m=0 := le_antisymm (le_of_not_gt hm) (Arithmetic.zero_le m)
    simp [hz] at hnm
    exact (ne_of_gt hnp) hnm'''
new2='''  have hmp : 0<m :=
    pos_of_mul_pos_right (by rw [← hnm]; exact hnp) (by simp)'''
assert a.count(old1)==a.count(old2)==1 and a.replace(old1,new1).replace(old2,new2)==b
print('Only two exact positivity proofs changed; original statements and assumptions preserved')
rows={}
for phase in ['baseline','final']:
 rows[phase]=json.loads((p/f'{phase}-records.json').read_text()); assert [x['module'] for x in rows[phase]]==[n,n+'Checks','ArithmeticPellIndexDivisibility']
 for r in rows[phase]:
  assert r['status']==0 and r['before']==r['after']==h(r['source']) and r['object_sha256']==h(r['object']) and r['log_sha256']==h(r['log']) and Path(r['command'][2]).read_text()==r['time']
  for d in r['direct_inputs']:
   assert d['before']==d['after']==h(d['path'])
   if d.get('source_before'):assert d['source_before']==d['source_after']==h(d['source'])
   fn=d['module'].replace('.','/')+'.olean';first=next(Path(q)/fn for q in r['LEAN_PATH'].split(':') if (Path(q)/fn).exists());assert first.resolve()==Path(d['path']).resolve()
 print(phase,'target and two clients: source, inputs, output/log/time pins pass')
for x,y in zip(rows['baseline'][1:],rows['final'][1:]): assert x['object_sha256']==y['object_sha256']
print('Both client objects byte-identical')
prior=json.loads(Path('/tmp/gcd-product-positivity/final-records.json').read_text())
for d in rows['baseline'][0]['direct_inputs']:
 name=d['module'].split('.')[-1]
 matches=[x for x in prior if x['module']==name and x['status']==0 and x['object_sha256']==d['before'] and x['before']==x['after']==d['source_before']]
 assert matches,name
 print('current-source producer match',name)
for phase in ['baseline','final']:
 records=json.loads((p/f'{phase}-probes.json').read_text()); assert {r['name'] for r in records}=={'names','interfaces','simp','instances'}
 for r in records:
  assert r['status']==0 and r['source_before']==r['source_after']==h(r['source']) and r['objects_before']==r['objects_after']==[h(q) for q in r['objects']] and r['log_sha256']==h(r['log']) and r['time_sha256']==h(r['time'])
for name in ['names','interfaces','simp','instances']:
 assert (p/f'baseline-{name}.log').read_bytes()==(p/f'final-{name}.log').read_bytes()
 print(name,'matching',len((p/f'final-{name}.log').read_text().splitlines()),'lines')
print('PASS')
for name,path in [('ArithmeticPellClassification','/tmp/pell-square-direct/final-records.json'),('ArithmeticPellFirstNorm','/tmp/pell-y-add/final-records.json')]:
 record=next(r for r in json.loads(Path(path).read_text()) if r['module']==name and r['status']==0)
 assert record['before']==record['after'] and record['before']!=h(repo/(name+'.lean'))
 for phase in ['baseline','final']:
  paths=rows[phase][0]['LEAN_PATH'].split(':');fn='DiophantineConsistency/'+name+'.olean';first=next(Path(q)/fn for q in paths if (Path(q)/fn).exists());assert h(first)==record['object_sha256']
 print('Post-build path sample historical old-source provider',name,path)
