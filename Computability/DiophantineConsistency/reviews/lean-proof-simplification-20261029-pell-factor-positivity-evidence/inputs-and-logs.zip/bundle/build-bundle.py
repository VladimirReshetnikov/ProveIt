from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/dev/shm/pell-factor-positivity');D=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-pell-factor-positivity-evidence');D.mkdir(parents=True,exist_ok=True);files={}
for p in sorted(R.rglob('*')):
 if p.is_file() and not p.is_symlink() and not str(p.relative_to(R)).startswith('objects-') and p.suffix!='.olean' and p.name!='build-bundle.py':files['prototype/'+str(p.relative_to(R))]=p.read_bytes()
prior={'gcd-product-providers.json':'/tmp/gcd-product-positivity/final-records.json','classification-old.json':'/tmp/pell-square-direct/final-records.json','firstnorm-old.json':'/tmp/pell-y-add/final-records.json'}
for n,p in prior.items():files['prior/'+n]=Path(p).read_bytes()
for n in ('pell-factor-positivity-peer-review.txt','pell-factor-positivity-peer-audit.py','pell-factor-positivity-peer-audit.log'):files['independent/'+n]=Path('/tmp',n).read_bytes()
c=subprocess.check_output(['git','rev-parse','3b87f2fa76'],text=True).strip();par=subprocess.check_output(['git','rev-parse',c+'^'],text=True).strip();base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
for rev,label in ((par,'baseline'),(c,'final')):
 b=subprocess.check_output(['git','show',rev+':'+base+'ArithmeticPellIntegralSolution.lean']);assert b==files['prototype/'+label+'/DiophantineConsistency/ArithmeticPellIntegralSolution.lean'];files['commit/'+label+'.lean']=b
for n in ('ArithmeticPellIntegralSolutionChecks','ArithmeticPellIndexDivisibility','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility','ArithmeticPellClassification','ArithmeticPellFirstNorm'):
 files['commit/inputs/'+n+'.lean']=subprocess.check_output(['git','show',c+':'+base+n+'.lean'])
files['bundle/build-bundle.py']=Path('/dev/shm/pell-factor-positivity/build-bundle.py').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':c,'source_parent':par,'scope':'Derive positive Pell factors directly from positive products','validation':'Paired target and both tracked direct Lean clients pass; client object hashes match. Five declaration/type/axiom reports and global simp/instance registrations match. Direct CommonUnit and StrongDivisibility source/object pairs match prior successful producer receipts.','limitations':['Post-build search-path samples resolve older PellClassification and PellFirstNorm objects with old-source producer receipts; samples are not contemporaneous transitive load-time pins. The remaining project, Foundation and Mathlib closure is cached and downstream clients were not rebuilt.','Matching reports do not establish equality of proof bodies or all persistent extensions. One shared-load timing pair is not a general benchmark; the standalone probe lacks complete input pins.','Compiled objects are excluded; external objects are needed to independently verify recorded hashes.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'independent_review_sha256':sha(files['independent/pell-factor-positivity-peer-review.txt']),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(files['independent/pell-factor-positivity-peer-review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,b in files.items():assert z.read(n)==b
assert sha((D/'independent-review.txt').read_bytes())==m['independent_review_sha256'];print('PASS members',len(files),'zip sha',m['archive_sha256'],'review sha',m['independent_review_sha256'])
