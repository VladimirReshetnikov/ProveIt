import DiophantineConsistency.ArithmeticPellIntegralSolution
namespace DiophantineConsistency.PellFactorPositivityProbe
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example {g n : V} (hn : 0<n) (hgn : g∣n) : 0<g := by
  obtain ⟨k, hk⟩ := hgn
  exact pos_of_mul_pos_left (by rw [← hk]; exact hn) (by simp)
example {m n e : V} (hnp : 0<n) (hnm : n=e*m) : 0<m :=
  pos_of_mul_pos_right (by rw [← hnm]; exact hnp) (by simp)
end DiophantineConsistency.PellFactorPositivityProbe
