from pathlib import Path
import json,hashlib,re
r=Path('/dev/shm/pell-factor-positivity');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticPellIntegralSolution','ArithmeticPellIntegralSolutionChecks','ArithmeticPellIndexDivisibility'];rec[phase]={}
 for x in rows:
  rec[phase][x['module']]=x;assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
   if d['module'].endswith('.ArithmeticPellIntegralSolution'):assert d['before']==rec[phase]['ArithmeticPellIntegralSolution']['object_sha256']
  if x['module']!='ArithmeticPellIntegralSolution':assert h(x['source'])==h(w/(x['module']+'.lean'))
  print('PASS build',phase,x['module'])
 for p in json.loads((r/(phase+'-probes.json')).read_text()):
  assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[phase][n]['object_sha256'] for n in ('ArithmeticPellIntegralSolution','ArithmeticPellIntegralSolutionChecks','ArithmeticPellIndexDivisibility')] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
for n in ('ArithmeticPellIntegralSolutionChecks','ArithmeticPellIndexDivisibility'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
for n in ('names','interfaces','simp','instances'):assert (r/('baseline-'+n+'.log')).read_bytes()==(r/('final-'+n+'.log')).read_bytes()
print('PASS matching client objects and target type/axiom and global registrations')
rows=json.load(open('/tmp/gcd-product-positivity/final-records.json'))
for d in rec['final']['ArithmeticPellIntegralSolution']['direct_inputs']:
 n=d['module'].split('.')[-1];x=next(x for x in rows if x['module']==n);assert x['status']==0 and x['before']==x['after']==d['source_before'] and x['object_sha256']==d['before'];print('PASS prior producer',n,d['before'])
for n,obj,prior in [('ArithmeticPellClassification','2ffb62f2a100827905aefd12de16eefe894002d828379c3516bedf2da3c2ee60','/tmp/pell-square-direct/final-records.json'),('ArithmeticPellFirstNorm','e209f93c9aba6d8b88bec905f978b4997eff6445b04fa603aff290e5e5d371c6','/tmp/pell-y-add/final-records.json')]:
 x=next(x for x in json.load(open(prior)) if x['module']==n and x['object_sha256']==obj);assert x['status']==0 and x['before']!=h(w/(n+'.lean'))
 env=rec['final']['ArithmeticPellIntegralSolution']['LEAN_PATH'];p=next(Path(q)/'DiophantineConsistency'/(n+'.olean') for q in env.split(':') if (Path(q)/'DiophantineConsistency'/(n+'.olean')).is_file());assert h(p)==obj;print('PASS post-build old-source path sample',n,obj)
print('PASS all checks; samples do not pin transitive load time')
