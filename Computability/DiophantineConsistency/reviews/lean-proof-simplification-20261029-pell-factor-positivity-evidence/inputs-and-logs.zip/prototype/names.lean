import Lean.Elab.Command
import DiophantineConsistency.ArithmeticPellIndexDivisibility
import DiophantineConsistency.ArithmeticPellIntegralSolutionChecks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellIntegralSolution).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellIntegralSolution" then
   logInfo m!"DECL {n}"
