from pathlib import Path
import hashlib,json,re
R=Path('/tmp/object-binary-unique');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
for ph in ['provider','baseline','final','baseline-repeat','final-repeat','baseline-repeat2','final-repeat2']:
 rows[ph]=json.loads((R/(ph+'-records.json')).read_text())
 for x in rows[ph]:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-'+x['module']+'.time')).read_text()
  if x['module']!='ObjectCodeBound' or ph.startswith('baseline'):assert x['before']==h(W/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ObjectCodeClosure' and ph!='provider':assert d['resolved']==rows['provider'][0]['object'] and d['before']==rows['provider'][0]['object_sha256']
   if n=='ObjectCodeBound':assert d['resolved']==rows[ph][0]['object'] and d['before']==rows[ph][0]['object_sha256']
  print('build',ph,x['module'],x['time'].strip())
for ph in ['baseline','final']:
 for n in ['names','interfaces','simp','instances']:
  x=json.loads((R/f'probe-{n}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
assert rows['baseline'][1]['object_sha256']==rows['final'][1]['object_sha256'];print('client object identical',rows['final'][1]['object_sha256'])
def decls(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decls('baseline'),decls('final');assert len(a)==88 and len(b)==89 and all(a[k]==b[k] for k in a);print('existing declarations match, added',list(b.keys()-a.keys()))
for n in ['simp','instances']:
 a=(R/('baseline-'+n+'.log')).read_bytes();b=(R/('final-'+n+'.log')).read_bytes();assert a==b;print(n,len(a.splitlines()))
f=json.loads((R/'failed-probe/probe-names-baseline.json').read_text());assert f['status']!=0 and f['source_before']==f['source_after']==h(R/'failed-probe/names.lean') and f['log_sha256']==h(R/'failed-probe/baseline-names.log');print('initial failed probe retained')
print('all checks passed')
