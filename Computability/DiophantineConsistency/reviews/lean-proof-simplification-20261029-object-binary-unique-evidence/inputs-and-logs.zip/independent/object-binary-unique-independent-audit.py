from pathlib import Path
import hashlib,json,re,subprocess
r=Path('/tmp/object-binary-unique'); w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest(); get=lambda n:json.loads((r/n).read_text())
base=(r/'baseline/DiophantineConsistency/ObjectCodeBound.lean').read_text();final=(r/'final/DiophantineConsistency/ObjectCodeBound.lean').read_text();assert hashlib.sha256(subprocess.check_output(['git','show','3148a695af^:'+str(w/'ObjectCodeBound.lean')])).hexdigest()==h(r/'baseline/DiophantineConsistency/ObjectCodeBound.lean');assert hashlib.sha256(subprocess.check_output(['git','show','3148a695af:'+str(w/'ObjectCodeBound.lean')])).hexdigest()==h(r/'final/DiophantineConsistency/ObjectCodeBound.lean')==h(w/'ObjectCodeBound.lean');print('parent matches tested baseline; commit and workspace match tested final')
helper=final[final.index('private theorem binary_unique'):final.index('/-- The bound is single-valued')];assert '(ht : 3 ≤ t ∧ t ≤ 5)' in helper and helper.count('boundCodeRel_binary_inv H t ht')==2 and 'rw [← hea, ← hed] at hab\'' in helper and 'exact addRel_unique H hab hab\'' in helper
for t in (3,4,5):
 old=f'''    obtain ⟨a1, d1, ha1, hd1, hab⟩ := boundCodeRel_binary_inv H {t} (by decide) hb
    obtain ⟨a2, d2, ha2, hd2, hab'⟩ := boundCodeRel_binary_inv H {t} (by decide) hb'
    have hea := ha a1 a2 ha1 ha2
    have hed := hd d1 d2 hd1 hd2
    rw [← hea, ← hed] at hab'
    exact addRel_unique H hab hab'
''';assert base.count(old)==1;base=base.replace(old,f'    exact binary_unique H {t} (by decide) ha hd hb hb\'\n')
assert final==base.replace('/-- The bound is single-valued',helper+'/-- The bound is single-valued');print('exact three old proof bodies shared; other source, statements, guards, imports unchanged')
rows={}
for ph in ('provider','baseline','final','baseline-repeat','final-repeat','baseline-repeat2','final-repeat2'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['log_sha256']==h(x['log']) and x['object_sha256']==h(x['object']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n!='ObjectCodeBound':assert x['before']==h(w/(n+'.lean'))
  else:assert x['before']==h(r/('baseline' if ph.startswith('baseline') else 'final')/'DiophantineConsistency/ObjectCodeBound.lean')
  for d in x['direct_inputs']:
   p=next(Path(q)/d['module'].replace('.','/') for q in [] ) if False else next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
   if d['module'].endswith('.ObjectCodeClosure'):assert d['resolved']==rows['provider','ObjectCodeClosure']['object'] and d['before']==rows['provider','ObjectCodeClosure']['object_sha256']
   if d['module'].endswith('.ObjectCodeBound'):assert d['resolved']==rows[ph,'ObjectCodeBound']['object'] and d['before']==rows[ph,'ObjectCodeBound']['object_sha256']
  rows[ph,n]=x;print('verified',ph,n,x['time'].strip())
assert rows['baseline','ObjectCodeSeal']['object_sha256']==rows['final','ObjectCodeSeal']['object_sha256']; print('client object hashes match')
for ph in ('baseline','final'):
 for n in ('names','interfaces','simp','instances'):
  x=get(f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ObjectCodeBound']['object_sha256'] and x['log_sha256']==h(x['log'])
def decls(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(r/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decls('baseline'),decls('final');assert len(a)==88 and len(b)==89 and all(b[k]==v for k,v in a.items());assert len(b.keys()-a.keys())==1 and 'binary_unique' in next(iter(b.keys()-a.keys()))
for n,count in [('simp',12375),('instances',5184)]:
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==count
print('88 existing declaration reports identical, one private helper added; simp/instances unchanged')
f=get('failed-probe/probe-names-baseline.json');assert f['status']!=0 and f['source_before']==f['source_after']==h(r/'failed-probe/names.lean') and f['log_sha256']==h(r/'failed-probe/baseline-names.log');print('failed missing-import probe preserved')
p=get('preliminary-final-records.json')[0];assert p['status']==0 and p['log_sha256']==h(r/'preliminary-final.log') and p['time']==(r/'preliminary-final.time').read_text();print('preliminary cached-provider target log/time preserved; original object overwritten')
