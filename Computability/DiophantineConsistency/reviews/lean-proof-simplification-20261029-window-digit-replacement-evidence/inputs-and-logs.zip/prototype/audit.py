from pathlib import Path
import json,hashlib,re
r=Path('/tmp/window-digit-replace');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());rows={};providers={}
for n,f in [('ArithmeticBinaryPopulation','/tmp/binary-half-reuse-20261028/final-targets.json'),('ArithmeticBinaryCarry','/tmp/binary-carry-simplify/final-records.json')]:
 a=json.loads(Path(f).read_text());x=next(x for x in a if x.get('tag',x.get('module'))==n);sh=x.get('source_sha256',x.get('before'));assert x['status']==0 and sh==h(w/(n+'.lean'));p=r/'common/DiophantineConsistency'/(n+'.olean');assert h(p)==x['object_sha256'];providers[n]=x['object_sha256'];print('current source/object prior receipt',n,providers[n])
for ph in ('provider','baseline','final'):
 for x in get(ph+'-records.json'):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n!='ArithmeticWindowDigits' or ph=='baseline':assert x['before']==h(w/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);name=d['module'].split('.')[-1]
   if name in providers:assert d['before']==providers[name]
   elif name=='ArithmeticRepunit':assert d['before']==rows['provider',name]['object_sha256'] and d['resolved']==rows['provider',name]['object']
   elif name=='ArithmeticWindowDigits':assert d['before']==rows[ph,name]['object_sha256'] and d['resolved']==rows[ph,name]['object']
   else:raise Exception(name)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for ph in ('baseline','final'):
 for x in get(ph+'-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticWindowDigits']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
assert rows['baseline','ArithmeticWindowBits']['object_sha256']==rows['final','ArithmeticWindowBits']['object_sha256'];print('client object identical')
def decl(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(r/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=decl('baseline'),decl('final');assert len(a)==51 and len(b)==52 and all(b[k]==v for k,v in a.items()) and len(b.keys()-a.keys())==1 and 'dig_replace_low' in next(iter(b.keys()-a.keys()));print('51 declaration reports match; one private helper added')
for n,c in [('simp',28973),('instances',13172)]:
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==c and b'dig_replace_low' not in b;print(n,c,'identical')
assert 'error: unsolved goals' in (r/'target-v2.log').read_text();print('v2 failed unrestricted rewrite source and log preserved; no build-time hash receipt')
