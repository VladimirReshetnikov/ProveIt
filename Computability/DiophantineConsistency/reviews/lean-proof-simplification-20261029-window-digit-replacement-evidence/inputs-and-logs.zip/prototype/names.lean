import Lean.Elab.Command
import DiophantineConsistency.ArithmeticWindowDigits
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticWindowDigits).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticWindowDigits" then
   logInfo m!"DECL {n}"
