from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/tmp/window-digit-replace');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior={};rows={}
path=str(W/'ArithmeticWindowDigits.lean')
assert subprocess.check_output(['git','show','3e1cc2606b^:'+path])==(R/'baseline/DiophantineConsistency/ArithmeticWindowDigits.lean').read_bytes()
assert subprocess.check_output(['git','show','3e1cc2606b:'+path])==(R/'final/DiophantineConsistency/ArithmeticWindowDigits.lean').read_bytes()==Path(path).read_bytes()
print('parent, commit and current source verified')
for n,f in [('ArithmeticBinaryPopulation','/tmp/binary-half-reuse-20261028/final-targets.json'),('ArithmeticBinaryCarry','/tmp/binary-carry-simplify/final-records.json')]:
 x=next(x for x in json.loads(Path(f).read_text()) if x.get('tag',x.get('module'))==n);sh=x.get('source_sha256',x.get('before'));assert x['status']==0 and sh==h(W/(n+'.lean'));p=R/'common/DiophantineConsistency'/(n+'.olean');assert h(p)==x['object_sha256'];prior[n]=x['object_sha256'];print('prior current source/object',n,x['object_sha256'])
for ph in ['provider','baseline','final']:
 for x in json.loads((R/(ph+'-records.json')).read_text()):
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/(ph+'-'+n+'.time')).read_text()
  if n!='ArithmeticWindowDigits' or ph=='baseline':assert x['before']==h(R/'baseline/DiophantineConsistency/ArithmeticWindowDigits.lean' if n=='ArithmeticWindowDigits' else W/(n+'.lean'))
  actual=re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M);assert actual==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1]
   if m in prior:assert d['before']==prior[m]
   elif m=='ArithmeticRepunit':assert d['before']==rows['provider',m]['object_sha256'] and d['resolved']==rows['provider',m]['object']
   elif m=='ArithmeticWindowDigits':assert d['before']==rows[ph,m]['object_sha256'] and d['resolved']==rows[ph,m]['object']
   else:raise AssertionError(m)
  rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for ph in ['baseline','final']:
 for x in json.loads((R/(ph+'-probes.json')).read_text()):assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticWindowDigits']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
assert rows['baseline','ArithmeticWindowBits']['object_sha256']==rows['final','ArithmeticWindowBits']['object_sha256'];print('WindowBits client object matches')
def ds(ph):return {v.split(' TYPE ',1)[0]:v for v in re.split(r'(?m)^DECL ',(R/(ph+'-interfaces.log')).read_text()) if v.strip()}
a,b=ds('baseline'),ds('final');assert len(a)==51 and len(b)==52 and all(a[k]==b[k] for k in a) and 'dig_replace_low' in next(iter(b.keys()-a.keys()));print('51 existing declaration reports match, added',list(b.keys()-a.keys()))
for n,num in [('simp',28973),('instances',13172)]:
 a=(R/('baseline-'+n+'.log')).read_bytes();b=(R/('final-'+n+'.log')).read_bytes();assert a==b and len(a.splitlines())==num and b'dig_replace_low' not in b;print(n,num)
assert 'error: unsolved goals' in (R/'target-v2.log').read_text();assert (R/'prototype-v2-failed.lean').is_file();print('failed v2 source/log retained without contemporaneous hash receipt')
print('all checks passed')
