from pathlib import Path
import zipfile,json,hashlib,subprocess
root=Path('Computability/DiophantineConsistency');out=root/'reviews/lean-proof-simplification-20261029-window-digit-replacement-evidence';out.mkdir(parents=True,exist_ok=True)
R=Path('/tmp/window-digit-replace');I=Path('/tmp');files={}
def add(arc,path):
 data=Path(path).read_bytes();assert arc not in files;files[arc]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in {'.py','.lean','.json','.log','.time','.txt'}:add('prototype/'+p.name,p)
for phase in ['baseline','final']:
 for p in sorted((R/phase).rglob('*.lean')):add('snapshots/'+str(p.relative_to(R)),p)
for name in ['window-digit-independent-review.txt','window-digit-independent-audit.py','window-digit-independent-audit.log']:add('independent/'+name,I/name)
refs={'prior/binary-population-final-targets.json':'binary-half-reuse-20261028/final-targets.json','prior/binary-population-build.log':'binary-half-reuse-20261028/final-ArithmeticBinaryPopulation.log','prior/binary-carry-final-records.json':'binary-carry-simplify/final-records.json'}
for n,p in refs.items():add(n,I/p)
add('bundle/build-window-digit-bundle.py',Path(__file__))
commit='3e1cc2606b2ef79990478457fa499aa3dcda9660';parent='e579fb28da3ee5b6487598d5827dba80e113b604';base='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';h=lambda b:hashlib.sha256(b).hexdigest()
for phase,ref in [('baseline',parent),('final',commit)]:
 for name in ['ArithmeticWindowDigits','ArithmeticWindowBits']:
  data=subprocess.check_output(['git','show',ref+':'+base+name+'.lean']);assert data==files['snapshots/'+phase+'/DiophantineConsistency/'+name+'.lean'];
  if name=='ArithmeticWindowDigits':files['commit/'+phase+'.lean']=data
pop=next(x for x in json.loads(files['prior/binary-population-final-targets.json']) if x.get('tag')=='ArithmeticBinaryPopulation');carry=next(x for x in json.loads(files['prior/binary-carry-final-records.json']) if x.get('module')=='ArithmeticBinaryCarry');rep=json.loads(files['prototype/provider-records.json'])[0]
for name,expected in [('ArithmeticBinaryPopulation',pop['source_sha256']),('ArithmeticBinaryCarry',carry['before']),('ArithmeticRepunit',rep['before'])]:
 data=subprocess.check_output(['git','show',commit+':'+base+name+'.lean']);assert h(data)==expected;files['providers/current/'+name+'.lean']=data
assert pop['status']==carry['status']==rep['status']==0 and pop['log_sha256']==h(files['prior/binary-population-build.log'])
review=files['independent/window-digit-independent-review.txt'];(out/'independent-review.txt').write_bytes(review)
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'source_parent':parent,'scope':'Share low-digit replacement invariant in window digit proofs',
 'validation':'Paired target and ArithmeticWindowBits builds pass with identical client objects. Fresh ArithmeticRepunit and prior source-current BinaryPopulation/BinaryCarry providers are recorded. All 51 existing target declaration/type/axiom reports match, one private helper is added, and 28,973 default simp and 13,172 instance entries match.',
 'limitations':['ArithmeticCyclicWord and ArithmeticMaskConstants also directly import the target and were not rebuilt. Target-pinned probes do not cover every environment extension or all downstream clients.','The earlier unrestricted rewrite v2 failed because it also rewrote the quotient on the right; its source/log/time are retained without contemporaneous input/output hash receipts. The v1 and v3 provisional evidence is also historical; their original output object path was overwritten and they are not the paired evidence.','The prior BinaryPopulation build receipt does not pin its own Foundation/Mathlib direct inputs. Other transitive project and package inputs remain cached; no full current-source closure build is established.','One shared-load timing pair is not a general performance benchmark. Compiled objects are not included in the ZIP; object hashes and first-provider resolution are retained in receipts, and external objects are required for independent byte checks.'],
 'archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{n:{'sha256':h(data),'bytes':len(data)} for n,data in sorted(files.items())},'independent_review':{'file':'independent-review.txt','sha256':h(review)}}
(out/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,v in manifest['members'].items():
  x=z.read(n);assert len(x)==v['bytes'] and h(x)==v['sha256']
assert h((out/'independent-review.txt').read_bytes())==manifest['independent_review']['sha256'];print('bundle',out,'members',len(files),'archive',manifest['archive_sha256'],'review',h(review),'PASS CRC and hashes')
