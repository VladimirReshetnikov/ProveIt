from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/wang-action-proof-20261028'); pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; mode=sys.argv[1]
items=[]
if mode=='baseline': items.append(('prerequisite',pre+'WangMachineEncoding.lean','WangMachineEncoding'))
items += [('target',pre+'WangMachineAction.lean','WangMachineAction'),('axioms',str(p/'axioms.lean'),None)]
if mode=='final': items += [(n,pre+n+'.lean',None) for n in ['WangMachineActionChecks','WangTiles942HeadBounds','WangTiles942StepConstruction']]
records=[]
for name,source,obj in items:
 if shutil.disk_usage('.').free < 70*1024**2: raise SystemExit('disk free <70 MiB; remaining calls not started')
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj: argv+=['-o',str(p/'overlay/DiophantineConsistency'/(obj+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/wang-action-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic(); r=subprocess.run(cmd,capture_output=True); elapsed=time.monotonic()-start
 log=p/(mode+'-'+name+'.log'); log.write_bytes(r.stdout+r.stderr)
 rec={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  b=(p/'overlay/DiophantineConsistency'/(obj+'.olean')).read_bytes(); rec['object_sha256']=hashlib.sha256(b).hexdigest(); rec['object_bytes']=len(b)
 records.append(rec); (p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode: raise SystemExit(r.returncode)
