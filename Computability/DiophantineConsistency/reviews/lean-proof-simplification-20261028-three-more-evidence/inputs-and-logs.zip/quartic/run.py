from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/quartic-compiler-proof-20261028'); pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; mode=sys.argv[1]
items=[('target',pre+'QuarticCompiler.lean',True),('axioms',str(p/'axioms.lean'),False)]
if mode=='final': items += [(n,pre+n+'.lean',False) for n in ['QuarticSyntax','GatesSemiring','NaturalSimplifier','EquationFromRep']]
records=[]
for name,source,obj in items:
 if shutil.disk_usage('.').free < 45*1024*1024: raise SystemExit('disk cutoff before '+name)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj: argv+=['-o',str(p/'overlay/DiophantineConsistency/QuarticCompiler.olean')]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/quartic-compiler-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic(); r=subprocess.run(cmd,capture_output=True); elapsed=time.monotonic()-start
 log=p/(mode+'-'+name+'.log'); log.write_bytes(r.stdout+r.stderr); src=Path(source)
 records.append({'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode: raise SystemExit(r.returncode)
