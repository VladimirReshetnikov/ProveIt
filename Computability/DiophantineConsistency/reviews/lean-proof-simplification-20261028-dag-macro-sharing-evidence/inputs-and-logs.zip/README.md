# Shared bounded DAG transfer and copy proofs

28 October 2026. This isolated experiment replaces 17 repeated proofs in
`ArithmeticRuntimeBoundDagMacrosA.lean` with private generic `transferMacro`
and `copyMacro` lemmas. The existing loop theorem statements, node equalities,
physical register distinctness checks, register bounds, output-size bounds and
tower-clock guards are preserved. The file loses 35 net lines. The module was
introduced by commit `ca0c31b62d`, which has a Claude Opus 5.5 coauthor
trailer; the commit text is in `provenance/origin-commit.txt`.

## Versions and results

`sources/baseline/` contains the original, `sources/final-v1/` the first
compiling prototype, and `sources/final-v2/` the revised candidate. V1 had the
same 51 non-generated declaration type and axiom reports, and the same 67
namespace declaration names, but two pairs of Lean-generated `._proof_`
auxiliaries exchanged types because register guards were elaborated in a
different order. The raw unrestricted V1 reports are
`logs/baseline-interfaces-all.log` and `logs/final-interfaces-all.log`, using
`scripts/interfaces-all.lean`; V1 is superseded by V2. Reordering the private
helper's guard arguments in V2 preserves the generated auxiliaries as well.
The source files and their baseline-to-V2 delta are included.

For both baseline and V2, all eight modules from Macros A through Macros B–D,
Root A–C and `ArithmeticRuntimeBoundDagHalt` compiled successfully. Their
original command lines, before/after source hashes, before/after hashes of
all 36 direct imports across the three runs, output and log hashes, timing
and exact `LEAN_PATH` are preserved in `records/records.json` (baseline and
V1) and `records/records-v2.json` (V2). The two fresh Halt object files were
byte-identical, SHA-256
`cce23f960ab95413d809995623475df768d64f0a3810ea585b4a33500745f084`.
The object files themselves are not included in this compact archive.

Timed V2 probes in `records/probe-records-v2.json` enumerate the same 67
names, compare `#check` and `#print axioms` output for all 67 byte-for-byte,
and compare default simp membership (both sets empty). This includes the
generated proof names. The raw logs and Lean probe sources are in `logs/`
and `scripts/`. V1's earlier `probe-records.json` is kept as historical data,
but the shared `interfaces.lean` and baseline interface logs were later
regenerated for V2, so that particular V1 receipt is no longer fully
self-contained. The preserved V1 `interfaces-all` reports support the
auxiliary-type finding independently of that superseded probe receipt.

## First failed setup

The first prototype invocation failed before elaboration with `unknown module
prefix 'Foundation'`: the temporary overlay copier did not follow the
Foundation directory symlink. The first `prototype.log` was subsequently
overwritten by the successful V1 rerun, so that raw failed log and its exit
timing are unavailable. `logs/initial-failure-transcript.txt` identifies the
error retained from the terminal tool output; it is a reconstruction, not a
raw compiler log. Adding the Foundation symlink fixed the setup. The failed
invocation is not counted as proof validation.

## Provenance and limits

The builds used the cached `/dev/shm/claude-ax-current/final` overlay and the
installed project/toolchain libraries. These are incremental comparisons,
not a fresh rebuild of all Foundation or upstream dependencies. Each direct
import was hashed before and after each recorded module compilation, but the
records do not prove that every transitive provider was freshly built from its
current source. Earlier overlay DAG planning, common rebuild receipts, AX
phase receipts and source/provider pin records are included in `provenance/`;
they use absolute paths from the original machine and are not a standalone
replay environment. A copy of each unchanged direct client source was checked
against the recorded source hashes at bundle creation. The scripts similarly
retain original absolute temporary paths and require the original overlays.
No repository files were changed as part of the experiment.

`manifest.sha256` covers every other file in this directory.
