from pathlib import Path
import hashlib,json,shutil
E=Path(__file__).resolve().parent.parent;R=Path('/tmp/dag-macro-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r1=json.loads((R/'records.json').read_text());r2=json.loads((R/'records-v2.json').read_text());allrecords=r1+r2
for phase,label in [('baseline','baseline'),('final','final-v1'),('final-v2','final-v2')]:
 rec=next(x for x in allrecords if x['phase']==phase and x['module']=='ArithmeticRuntimeBoundDagMacrosA');src=Path(rec['source']);assert sha(src)==rec['source_before']==rec['source_after'];shutil.copy2(src,E/'sources'/label/src.name)
for rec in allrecords:
 assert rec['status']==0 and rec['source_before']==rec['source_after']
 assert all(x['sha256_before']==x['sha256_after'] for x in rec['direct_inputs'])
 assert sha(rec['object'])==rec['object_sha256']
 if rec['module']!='ArithmeticRuntimeBoundDagMacrosA':
  src=Path(rec['source']);assert sha(src)==rec['source_before'];out=E/'sources/clients'/src.name
  if out.exists():assert sha(out)==sha(src)
  else:shutil.copy2(src,out)
for p in R.glob('*.log'):shutil.copy2(p,E/'logs'/p.name)
for p in R.glob('*.time'):shutil.copy2(p,E/'logs'/p.name)
for n in ['audit.py','audit-v2.py','make.py','probes.py','probes-v2.py','names.lean','interfaces.lean','interfaces-all.lean','simp.lean']:
 shutil.copy2(R/n,E/'scripts'/n)
for n in ['records.json','records-v2.json','probe-records.json','probe-records-v2.json','name-differences.json','name-differences-v2.json']:
 shutil.copy2(R/n,E/'records'/n)
for n in ['graph.json','coherent-common-records.json','phase-records.json']:
 shutil.copy2(Path('/tmp/claude-ax-sharing')/n,E/'provenance'/n)
for n in ['forward-plan.json','forward-common-pins.json','forward-build-records.json']:
 shutil.copy2(Path('/tmp/bisim-share')/n,E/'provenance'/n)
print('build records',len(allrecords),'direct input checks',sum(len(x['direct_inputs']) for x in allrecords))
