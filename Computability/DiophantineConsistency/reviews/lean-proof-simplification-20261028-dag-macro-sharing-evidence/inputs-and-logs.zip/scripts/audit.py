from pathlib import Path
import hashlib,json,os,re,subprocess,time,shutil
R=Path('/tmp/dag-macro-sharing');P=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');C=Path('/dev/shm/claude-ax-current/final');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
names=['ArithmeticRuntimeBoundDagMacrosA','ArithmeticRuntimeBoundDagMacrosB','ArithmeticRuntimeBoundDagMacrosC','ArithmeticRuntimeBoundDagMacrosD','ArithmeticRuntimeBoundDagRootA','ArithmeticRuntimeBoundDagRootB','ArithmeticRuntimeBoundDagRootC','ArithmeticRuntimeBoundDagHalt']
for phase in ['final','baseline']:
 out=R/phase;out.mkdir(exist_ok=True)
 for p in C.rglob('*'):
  if p.is_file():
   q=out/p.relative_to(C);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists():q.symlink_to(p.resolve())
 if not (out/'Foundation').exists():(out/'Foundation').symlink_to((C/'Foundation').resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base
 for name in names:
  src=(R/'sources'/phase/'DiophantineConsistency'/f'{name}.lean') if name==names[0] else P/f'{name}.lean';root=R/'sources'/phase if name==names[0] else P.parent
  obj=out/'DiophantineConsistency'/f'{name}.olean';obj.unlink(missing_ok=True);log=R/f'{phase}-{name}.log';tm=R/f'{phase}-{name}.time'
  deps=[]
  for n in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
   ps=[Path(d)/(n.replace('.','/')+'.olean') for d in env['LEAN_PATH'].split(':')];p=next((x for x in ps if x.is_file()),None)
   if p is None:raise Exception('Missing import '+n)
   deps.append({'module':n,'visible_path':str(p),'resolved_path':str(p.resolve()),'sha256_before':sha(p)})
  cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(obj)];before=sha(src);t=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in deps:x['sha256_after']=sha(x['visible_path'])
  rec={'phase':phase,'module':name,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_before':before,'source_after':sha(src),'direct_inputs':deps,'object':str(obj),'object_sha256':sha(obj) if obj.exists() else None,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,3)};records.append(rec);(R/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,p.returncode,rec['time'].strip(),flush=True)
  if p.returncode or rec['source_before']!=rec['source_after'] or any(x['sha256_before']!=x['sha256_after'] for x in deps):raise SystemExit(1)
