from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/dag-macro-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(phase,probe):
 src=R/(probe+'.lean');out=R/(phase+'-'+probe+'.log');tm=R/(phase+'-'+probe+'.time');env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base;cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=sha(src);t=time.monotonic()
 with out.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'phase':phase,'probe':probe,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'input_sha256_before':before,'input_sha256_after':sha(src),'object_sha256':sha(R/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.olean'),'log_sha256':sha(out),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)};records.append(rec);(R/'probe-records-v2.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,probe,r.returncode,rec['time'].strip(),flush=True);assert r.returncode==0 and before==rec['input_sha256_after']
for phase in ['baseline','final-v2']:run(phase,'names')
read=lambda p:{x[5:] for x in (R/(p+'-names.log')).read_text().splitlines() if x.startswith('DECL ')}
a=read('baseline');b=read('final-v2');removed=a-b;added=b-a;print('names counts',len(a),len(b),'removed',sorted(removed),'added',sorted(added),flush=True)
(R/'name-differences-v2.json').write_text(json.dumps({'baseline_count':len(a),'final_count':len(b),'removed':sorted(removed),'added':sorted(added)},indent=2)+'\n')
stable=sorted(a)
(R/'interfaces.lean').write_text('import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA\nset_option pp.universes true\n'+''.join('#check '+x+'\n#print axioms '+x+'\n' for x in stable))
for phase in ['baseline','final-v2']:
 run(phase,'interfaces');run(phase,'simp')
assert (R/'baseline-interfaces.log').read_bytes()==(R/'final-v2-interfaces.log').read_bytes()
assert set((R/'baseline-simp.log').read_text().splitlines())==set((R/'final-v2-simp.log').read_text().splitlines())
print('Stable interface and simp reports match, stable declarations:',len(stable),flush=True)
