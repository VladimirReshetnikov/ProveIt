from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent.parent;manifest=root/'manifest.sha256';files=sorted(p for p in root.rglob('*') if p.is_file() and p!=manifest);manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in files));print(len(files),'manifest entries')
