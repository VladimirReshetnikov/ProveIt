from pathlib import Path
import re
p=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.lean');s=p.read_text()
start=s.index('/-! ## The transfer and copy loops -/');helper='''/-! ## The transfer and copy loops -/

/-- Package a two-register transfer after bounding its output size. -/
private theorem transferMacro {n m src dst : Nat}
    (hn : DagPerm.dagPerm.nodes n = (.decnz src, .node m))
    (hm : DagPerm.dagPerm.nodes m = (.inc dst, .cont 2))
    (hd : phys src ≠ phys dst) (hdr : dst < 9) (hsr : src < 9)
    (st : AS V) (hs : sz st ≤ tower j L)
    (hsz : sz (updAS (updAS st dst (field st dst + field st src)) src 0) ≤ sz st + sz st) :
    Mac (.node n) st (updAS (updAS st dst (field st dst + field st src)) src 0) j L 1 := by
  have h := transferB (p := DagPerm.dagPerm) R.run_zero R.run_add R.run_one
    ArithmeticDagControlPerm222.spec hn hm hd (enc st)
  rw [lreg_enc st dst hdr, lreg_enc st src hsr, lupd_enc st dst hdr,
    lupd_enc _ src hsr] at h
  exact mac_intro hL hs h (field_le_sz st src) (by norm_num) hsz

/-- Package a three-register copy after bounding its output size. -/
private theorem copyMacro {n m m' src d1 d2 : Nat}
    (hn : DagPerm.dagPerm.nodes n = (.decnz src, .node m))
    (hm : DagPerm.dagPerm.nodes m = (.node m', .cont 2))
    (hm' : DagPerm.dagPerm.nodes m' = (.inc d1, .inc d2))
    (h1 : phys src ≠ phys d1) (h2 : phys src ≠ phys d2) (h12 : phys d1 ≠ phys d2)
    (hd1 : d1 < 9) (hsr : src < 9) (hd2 : d2 < 9)
    (st : AS V) (hs : sz st ≤ tower j L)
    (hsz : sz (updAS (updAS (updAS st d1 (field st d1 + field st src)) d2
      (field st d2 + field st src)) src 0) ≤ sz st + sz st) :
    Mac (.node n) st (updAS (updAS (updAS st d1 (field st d1 + field st src)) d2
      (field st d2 + field st src)) src 0) j L 1 := by
  have h := copy2B (p := DagPerm.dagPerm) R.run_zero R.run_add R.run_one
    ArithmeticDagControlPerm222.spec hn hm hm' h1 h2 h12 (enc st)
  rw [lreg_enc st d1 hd1, lreg_enc st src hsr, lreg_enc st d2 hd2,
    lupd_enc st d1 hd1, lupd_enc _ d2 hd2, lupd_enc _ src hsr] at h
  exact mac_intro hL hs h (field_le_sz st src) (by norm_num) hsz
'''
s=s[:start]+helper+s[start+len('/-! ## The transfer and copy loops -/'):]
pat=r'(theorem loop\d+M \(st : AS V\) \(hs : sz st ≤ tower j L\) :\n    Mac [^\n]+ := by\n)(.*?)(?=\n(?:theorem loop|end DiophantineConsistency))'
count=[0,0]
def change(match):
 head,body=match.groups()
 if 'have h := transferB' in body:
  n,m,src,dst=re.search(r'\(n := (\d+)\) \(m := (\d+)\) \(src := (\d+)\) \(dst := (\d+)\)',body).groups();count[0]+=1
  return head+f'''  apply transferMacro hL (n := {n}) (m := {m}) (src := {src}) (dst := {dst}) rfl rfl
    (by decide) (by omega) (by omega) st hs
  exact le_trans (le_of_eq (by simp only [sz, updAS, field]; ring)) le_self_add
'''
 if 'have h := copy2B' in body:
  n,m,mp,src,d1,d2=re.search(r"\(n := (\d+)\) \(m := (\d+)\) \(m' := (\d+)\) \(src := (\d+)\) \(d1 := (\d+)\)\s+\(d2 := (\d+)\)",body).groups();count[1]+=1
  field={'0':'np','1':'tw','2':'ws','3':'ac','4':'p1','5':'p2','6':'s1','7':'s2','8':'pl'}[src]
  return head+f'''  apply copyMacro hL (n := {n}) (m := {m}) (m' := {mp}) (src := {src}) (d1 := {d1}) (d2 := {d2})
    rfl rfl rfl (by decide) (by decide) (by decide) (by omega) (by omega) (by omega) st hs
  exact le_trans (le_of_eq (by simp only [sz, updAS, field]; ring : _ = sz st + st.{field}))
    (_root_.add_le_add le_rfl (field_le_sz st {src}))
'''
 raise Exception(head)
s=re.sub(pat,change,s,flags=re.S);print('replacements',count)
Path('/tmp/dag-macro-sharing/src/DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.lean').write_text(s)
