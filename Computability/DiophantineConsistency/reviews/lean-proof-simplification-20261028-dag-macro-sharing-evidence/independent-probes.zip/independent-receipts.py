from pathlib import Path
import json,hashlib,re
P=Path('/tmp/dag-macro-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[x for x in json.loads((P/'records.json').read_text()) if x['phase']=='baseline']+json.loads((P/'records-v2.json').read_text()); errors=[];cnt=0
for x in rows:
 src=Path(x['source']); obj=Path(x['object']);log=Path(x['log']);
 if x['status']!=0 or not src.exists() or sha(src)!=x['source_after'] or x['source_before']!=x['source_after']:errors.append((x['phase'],x['module'],'source/status'))
 if not obj.exists() or sha(obj)!=x['object_sha256']:errors.append((x['phase'],x['module'],'object'))
 if not log.exists() or sha(log)!=x['log_sha256']:errors.append((x['phase'],x['module'],'log'))
 im=re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M);deps=x['direct_inputs']
 if sorted(im)!=sorted(d['module'] for d in deps):errors.append((x['phase'],x['module'],'imports'))
 for d in deps:
  cnt+=1; p=Path(d['visible_path']);r=Path(d['resolved_path']);rel=d['module'].replace('.','/')+'.olean';hits=[Path(q,rel) for q in x['lean_path'].split(':') if Path(q,rel).is_file()]
  if not p.exists() or sha(p)!=d['sha256_after'] or d['sha256_before']!=d['sha256_after'] or p.resolve()!=r or not hits or hits[0].resolve()!=r:errors.append((x['phase'],x['module'],d['module']))
print('build records',len(rows),'direct input occurrences',cnt,'errors',errors)
