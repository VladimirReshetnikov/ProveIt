import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA
#print equations DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.IRB
#print equations DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.RnB
#print equations DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.sz
#print equations DiophantineConsistency.ArithmeticRuntimeBoundDagMacros.Mac
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRuntimeBoundDagMacros).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA" then
   logInfo m!"DECL {n}"
