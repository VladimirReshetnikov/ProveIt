from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/dag-macro-sharing');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final-v2']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base
 for test in ['force','global-simp','instances','attribute-kinds']:
  src=R/f'independent-{test}.lean';obj=R/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.olean';log=R/f'{phase}-replay-{test}.log';tm=R/f'{phase}-replay-{test}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=sha(src);object_before=sha(obj);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  rec={'phase':phase,'probe':test,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'source':str(src),'source_before':before,'source_after':sha(src),'input_object':str(obj.resolve()),'input_object_before':object_before,'input_object_after':sha(obj),'status':r.returncode,'log':str(log),'log_sha256':sha(log),'time':tm.read_text(),'elapsed':time.monotonic()-t};records.append(rec);(R/'independent-replay-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,test,r.returncode,flush=True)
  if r.returncode or before!=rec['source_after'] or object_before!=rec['input_object_after']:raise SystemExit(1)
