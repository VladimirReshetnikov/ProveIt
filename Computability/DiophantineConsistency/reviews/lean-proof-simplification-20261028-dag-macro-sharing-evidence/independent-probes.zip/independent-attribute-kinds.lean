import DiophantineConsistency.ArithmeticRuntimeBoundDagMacrosA
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for n in Lean.getAttributeNames env do
  logInfo m!"ATTR {n}"
