from pathlib import Path
import json,hashlib
P=Path('/tmp/rowrel-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();allrows=[]
for phase in ('baseline','alternate'):
 records=json.loads((P/f'{phase}-records.json').read_text()); assert len(records)==7
 for x in records:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['workspace_before']==x['workspace_after']==h(x['workspace'])
  if phase=='baseline' or x['module']!='ArithmeticTilingRows':assert x['source_before']==x['workspace_before']
  assert x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']) and x['timing']==Path(x['time']).read_text().strip()
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';first=next(Path(y)/rel for y in x['lean_path'].split(':') if (Path(y)/rel).is_file());assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['object_before']==d['object_after']==h(first)
   if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
  allrows.append(x); print(phase,x['iteration'],x['module'],len(x['direct_inputs']),'inputs verified')
for x in json.loads((P/'alternate-probe-records.json').read_text()):
 src=P/(x['probe']+'.lean');obj=P/x['phase']/'DiophantineConsistency/ArithmeticTilingRows.olean';assert x['status']==0 and x['source_before']==x['source_after']==h(src) and x['object_before']==x['object_after']==h(obj) and x['log_sha256']==h(x['log']);print('probe',x['phase'],x['probe'],'verified')
for n in ('alternate-interfaces','private','global-simp'):assert (P/f'baseline-alt-{n}.log').read_bytes()==(P/f'alternate-alt-{n}.log').read_bytes();print(n,'logs identical')
print('total',len(allrows),'builds',sum(len(x['direct_inputs']) for x in allrows),'direct input occurrences')
