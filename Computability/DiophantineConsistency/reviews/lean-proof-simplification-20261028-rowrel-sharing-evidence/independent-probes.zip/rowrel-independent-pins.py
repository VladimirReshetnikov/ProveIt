import json
from pathlib import Path
p=Path('/tmp/rowrel-sharing');known={}
def put(n,s,o,v):
 if n and s and o:known.setdefault((n,s,o),[]).append(v)
for x in json.load(open('/tmp/positive-shift-sharing/transport-receipts/provider-audit.json')):
 if x['source_recorded']==x['source_current'] and x['object_recorded']==x['object_current'] and all(d['actual']==d['recorded'] for d in x['direct']):put(x['module'],x['source_current'],x['object_current'],'transport:'+x['receipt'])
for x in json.load(open('/tmp/pell-construction-refresh/local-pins.json')):
 for fld in ['baseline_sha256','final_sha256']:put(x['module'],x['source_sha256'],x.get(fld),'pell-local-pins')
for x in json.load(open('/tmp/positive-shift-sharing/source-clean/records.json')):
 if x['status']==0:put('DiophantineConsistency.'+x['module'],x['source_sha256_before'],x['object_sha256'],'positive-shift-clean:'+x['phase'])
for x in json.load(open('/tmp/controller-dmap-sharing/final-records.json')):
 if x['status']==0:put('DiophantineConsistency.'+x['module'],x['source_before'],x['object_sha256'],'controller-dmap-final')
for x in json.load(open('/tmp/seam-sharing/coherent-final-records.json')):
 if x['status']==0:put('DiophantineConsistency.'+x['module'],x['source_before'],x['object_sha256'],'seam-coherent-final')
records=[]
for ph in ['baseline','final','alternate']:
 path=p/(ph+'-records.json')
 if path.exists():records+=json.load(open(path))
for x in records:
 if x['status']==0:put('DiophantineConsistency.'+x['module'],x['source_before'],x['object_sha256'],'rowrel-fresh:'+x['phase'])
rows=[]
for x in records:
 if x['status']:continue
 for i in x['direct_inputs']:
  matches=known.get((i['module'],i['source_before'],i['object_before']),[]);fresh=[v for (n,s,o),vv in known.items() if n==i['module'] and o==i['object_before'] for v in vv if v=='rowrel-fresh:'+x['phase']];rows.append({'phase':x['phase'],'client':x['module'],'module':i['module'],'source_sha256':i['source_before'],'object_sha256':i['object_before'],'matches':matches,'fresh_same_phase':bool(fresh)})
Path('/tmp/rowrel-independent-pins.json').write_text(json.dumps(rows,indent=2)+'\n');bad=[x for x in rows if not x['matches'] and not x['fresh_same_phase']];print('inputs',len(rows),'unmatched',len(bad));print('\n'.join(str((x['phase'],x['client'],x['module'],x['object_sha256'][:12])) for x in bad))
