from pathlib import Path
import os,hashlib,json,subprocess
p=Path('/tmp/rowrel-sharing/alternate');s=Path('/tmp/rowrel-independent-generated.lean');o=p/'DiophantineConsistency/ArithmeticTilingRows.olean';log=Path('/tmp/rowrel-independent-generated.log');H=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();env=os.environ.copy();env['LEAN_PATH']=str(p)+':'+env['LEAN_PATH'];b=H(s);ob=H(o);cmd=['lean','-M10000','-j1','-DElab.async=false',str(s)]
with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
x={'status':r.returncode,'source':str(s),'before':b,'after':H(s),'direct_object':str(o),'object_before':ob,'object_after':H(o),'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'log':str(log),'log_sha256':H(log)};Path('/tmp/rowrel-independent-generated.json').write_text(json.dumps(x,indent=2)+'\n');print(r.returncode)
