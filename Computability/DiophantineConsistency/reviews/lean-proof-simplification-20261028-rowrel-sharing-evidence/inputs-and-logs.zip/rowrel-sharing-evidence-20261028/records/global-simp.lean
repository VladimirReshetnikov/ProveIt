import DiophantineConsistency.ArithmeticTilingRows
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    let s := n.toString
    if s.endsWith "InternalZero" || s.endsWith "split_positiveShift" || s.endsWith "internalZero_positiveShift" then
      logInfo m!"CANDIDATE {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
       t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
