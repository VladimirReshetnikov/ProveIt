import DiophantineConsistency.ArithmeticTilingRows
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000
open SetTheory.BusyBeaver SetTheory.BusyBeaver.ZFC
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticTilingRows
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (y c H X : V) : RowRel y c H X ↔ y = rowIdx c H X := by
  unfold RowRel rowIdx
  split_ifs <;> tauto
