from pathlib import Path
import shutil,hashlib,json,difflib,zipfile,subprocess
P=Path('/tmp/rowrel-sharing');D=Path('/tmp/rowrel-sharing-evidence-20261028');D.mkdir(exist_ok=True)
def copy(src,rel):
 dst=D/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for x in P.iterdir():
 if x.is_file() and not x.is_symlink() and x.suffix in {'.lean','.log','.time','.json','.py'}:copy(x,Path('records')/x.name)
for ph in ['baseline','final','alternate']:
 for x in (P/'sources'/ph).rglob('*.lean'):copy(x,Path('sources')/ph/x.relative_to(P/'sources'/ph))
for n in ['provider-audit.json','assembly-phase-records.json','assembly-common-records.json','assembly-input-pins.json']:copy(Path('/tmp/positive-shift-sharing/transport-receipts')/n,Path('provenance/transport')/n)
copy(Path('/tmp/pell-construction-refresh/local-pins.json'),Path('provenance/pell-local-pins.json'));copy(Path('/tmp/positive-shift-sharing/source-clean/records.json'),Path('provenance/positive-shift-clean-records.json'));copy(Path('/tmp/controller-dmap-sharing/final-records.json'),Path('provenance/controller-dmap-final-records.json'));copy(Path('/tmp/seam-sharing/coherent-final-records.json'),Path('provenance/seam-coherent-final-records.json'))
(D/'provenance/claude-source-commit.txt').write_text(subprocess.check_output(['git','show','--format=fuller','--no-patch','3cd04ac37f'],text=True));(D/'provenance/toolchain.txt').write_text(subprocess.check_output(['lean','--version'],text=True));head='af34addf607ee863a31f84e45d9052a8320f7f25';h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();baseline=P/'sources/baseline/DiophantineConsistency';rows=[]
for f in baseline.glob('*.lean'):
 repo='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+f.name;raw=subprocess.check_output(['git','show',head+':'+repo]);digest=hashlib.sha256(raw).hexdigest();assert digest==h(f),(f.name,digest,h(f));rows.append({'module':f.stem,'git_ref':head,'sha256':digest})
(D/'provenance/baseline-source-audit.json').write_text(json.dumps(rows,indent=2)+'\n');a=(baseline/'ArithmeticTilingRows.lean').read_text().splitlines(keepends=True);b=(P/'sources/alternate/DiophantineConsistency/ArithmeticTilingRows.lean').read_text().splitlines(keepends=True);(D/'prototype.patch').write_text(''.join(difflib.unified_diff(a,b,fromfile='baseline/ArithmeticTilingRows.lean',tofile='alternate/ArithmeticTilingRows.lean')))
(D/'README.md').write_text('''# Tiling row relation proof simplification: isolated evidence

The alternate candidate shortens ArithmeticTilingRows.rowRel_iff by unfolding the unchanged definitions once, splitting the existing zero/head/receiver guards, and deriving the complementary receiver conditions by De Morgan's laws. It retains all guards, assumptions, imports, definitions and the theorem statement; the diff removes 47 net lines. The baseline target is byte-identical to the Claude Opus 5.5 coauthored commit 3cd04ac37f. All five baseline target/client snapshots match validation HEAD `'''+head+'''`; `provenance/baseline-source-audit.json` records their Git-reconstructed hashes. The candidate is a prototype, not a repository edit.

## Paired builds and performance

Three full target builds per phase passed under `-j1 -DElab.async=false`. Baseline user CPU was 26.30, 28.93, 26.44 seconds (median 26.44); alternate was 24.11, 26.14, 25.67 seconds (median 25.67, ratio 0.971). Max RSS is approximately 1.89 GB in both phases. These are paired incremental runs, not a formal benchmark, but show no 3x whole-target elaboration regression. The three existing target warnings match after normalizing source paths and line locations.

The target's current-source clients ArithmeticTilingBand (including the adopted seam proof), ArithmeticTilingWord, ArithmeticConstructionAssembly and ArithmeticCurrentConstruction2011 all built in both baseline and alternate phases. Their warning logs match after normalizing source paths: Band has one, Word nine, and Assembly and CurrentConstruction none. `records/{baseline,alternate}-records.json` contain source and workspace hashes before/after, direct object and source hashes before/after, commands, environment, output/log/time hashes and timings. The 54 direct input occurrences across baseline, earlier final and alternate all match same-phase outputs or included prior current-source/object provider receipts (`records/input-pin-audit.json`). The compilation graph reused the adopted positive-shift, dmap and seam providers; other cached transitive libraries and package inputs were not rebuilt.

## Interfaces and experiments

`records/alternate-name-diff.json` shows all 59 pre-existing namespace names retained, with only two newly materialized generated names, rowRel_iff._simp_3 and rowRel_iff._simp_4. The 59 common public/generated #check and #print axioms reports match byte-for-byte; private environment type/axiom reports also match. Global default simp declaration membership/flag logs contain identical sets of 29,730 entries. No project Lean source references to those two generated names were found in a targeted search. Earlier candidate `sources/final/` also passed paired builds, but generated a third name, RowRel.eq_1; it is superseded by the alternate. Existing autogenerated declarations may be unstable even when no old name is removed.

The initial broad split_ifs/tauto experiments exhausted recursion or were interrupted because they ran too long; their probe sources and logs are retained as failed/terminated exploration and are not counted as passing evidence. The first probe source was modified before a separate hash was retained. `probe5` exposed an unused simp-argument warning; `probe6` and `probe7` succeeded after correction. The full `alternate` phase is the accepted candidate evidence.

## Scope

This is an incremental comparison, not a clean full repository/Foundation closure build. Prior transport, positive-shift, controller-dmap, seam and Pell receipt material is included under `provenance/`; historical transitive objects and installed packages remain cached, compiled binaries are excluded, and the original scripts depend on absolute temporary paths and the installed Lean environment. The archived timings are individual runs under the recorded environment, not a universal performance claim.
''')
files=sorted(x for x in D.rglob('*') if x.is_file() and x.name!='manifest.sha256');(D/'manifest.sha256').write_text(''.join(h(x)+'  '+x.relative_to(D).as_posix()+'\n' for x in files));zpath=Path(str(D)+'.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for x in sorted(x for x in D.rglob('*') if x.is_file()):z.write(x,x.relative_to(D.parent))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for x in z.infolist():assert hashlib.sha256(z.read(x)).hexdigest()==h(D.parent/x.filename)
print('files',len(files)+1,'size',zpath.stat().st_size,'sha256',h(zpath))
