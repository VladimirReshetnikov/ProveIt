from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path('/tmp/rowrel-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=[]
def run(ph,n):
 env=os.environ.copy();env['LEAN_PATH']=str(p/ph)+':'+base;s=p/(n+'.lean');log=p/(ph+'-alt-'+n+'.log');obj=p/ph/'DiophantineConsistency/ArithmeticTilingRows.olean';before=h(s);ob=h(obj);t=time.monotonic();cmd=['lean','-M10000','-j1','-DElab.async=false',str(s)]
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 z={'phase':ph,'probe':n,'status':r.returncode,'source_before':before,'source_after':h(s),'object_before':ob,'object_after':h(obj),'command':cmd,'lean_path':env['LEAN_PATH'],'log':str(log),'log_sha256':h(log),'elapsed':time.monotonic()-t};rs.append(z);(p/'alternate-probe-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,n,r.returncode,flush=True)
 if r.returncode or z['source_before']!=z['source_after'] or z['object_before']!=z['object_after']:raise SystemExit(1)
for ph in ['baseline','alternate']:run(ph,'names')
def names(ph):return {l[5:] for l in (p/(ph+'-alt-names.log')).read_text().splitlines() if l.startswith('DECL ')}
a=names('baseline');b=names('alternate');d={'baseline_count':len(a),'alternate_count':len(b),'removed':sorted(a-b),'added':sorted(b-a)};(p/'alternate-name-diff.json').write_text(json.dumps(d,indent=2)+'\n');print(d,flush=True)
common=sorted(x for x in a&b if not x.startswith('_private.'));(p/'alternate-interfaces.lean').write_text('import DiophantineConsistency.ArithmeticTilingRows\nset_option pp.universes true\n'+''.join('#check '+x+'\n#print axioms '+x+'\n' for x in common))
for ph in ['baseline','alternate']:
 for n in ['alternate-interfaces','private','global-simp']:run(ph,n)
for n in ['alternate-interfaces','private','global-simp']:print(n,'equal',(p/('baseline-alt-'+n+'.log')).read_bytes()==(p/('alternate-alt-'+n+'.log')).read_bytes(),flush=True)
