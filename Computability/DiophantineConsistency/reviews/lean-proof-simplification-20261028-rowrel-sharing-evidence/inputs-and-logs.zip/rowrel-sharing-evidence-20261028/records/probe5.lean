import DiophantineConsistency.ArithmeticTilingRows
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000
open SetTheory.BusyBeaver SetTheory.BusyBeaver.ZFC
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open ArithmeticCantor
open DiophantineConsistency.ArithmeticTilingRows DiophantineConsistency.ArithmeticWangTable
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (y c H X : V) : RowRel y c H X ↔ y = rowIdx c H X := by
  by_cases h0 : first c = 0
  · by_cases hX : X = H <;> simp [RowRel, rowIdx, h0, hX]
  · by_cases hX : X = H
    · simp [RowRel, rowIdx, h0, hX]
    · by_cases hr : (X = H + 1 ∧ eastC (headIdx c) ≠ 0) ∨ (X + 1 = H ∧ westC (headIdx c) ≠ 0)
      · rcases hr with ⟨h1, h2⟩ | ⟨h1, h2⟩
        · simp [RowRel, rowIdx, h0, hX, h1, h2]
        · simp [RowRel, rowIdx, h0, hX, h1, h2]
      · have hn := not_or.mp hr
        have hn1 : X ≠ H + 1 ∨ eastC (headIdx c) = 0 := by
          simpa only [not_and_or, not_not] using hn.1
        have hn2 : X + 1 ≠ H ∨ westC (headIdx c) = 0 := by
          simpa only [not_and_or, not_not] using hn.2
        simp [RowRel, rowIdx, h0, hX, hr, hn1, hn2]
