import DiophantineConsistency.ArithmeticTilingRows
#print equations DiophantineConsistency.ArithmeticTilingRows.bitAt
#print equations DiophantineConsistency.ArithmeticTilingRows.headIdx
#print equations DiophantineConsistency.ArithmeticTilingRows.rcvIdx
#print equations DiophantineConsistency.ArithmeticTilingRows.rowIdx
#print equations DiophantineConsistency.ArithmeticTilingRows.finIdx
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticTilingRows).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticTilingRows).isPrefixOf n then
      logInfo m!"DECL {n}"
      if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
         t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
        logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
