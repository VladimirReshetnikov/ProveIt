import DiophantineConsistency.ArithmeticTilingRows
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000
open SetTheory.BusyBeaver SetTheory.BusyBeaver.ZFC
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open DiophantineConsistency.ArithmeticTilingRows DiophantineConsistency.ArithmeticWangTable
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (y c H X : V) : RowRel y c H X ↔ y = rowIdx c H X := by
  unfold RowRel rowIdx
  by_cases h0 : first c = 0
  · by_cases hX : X = H <;> simp [h0, hX]
  · by_cases hX : X = H
    · simp [h0, hX]
    · by_cases hr : (X = H + 1 ∧ eastC (headIdx c) ≠ 0) ∨ (X + 1 = H ∧ westC (headIdx c) ≠ 0)
      · simp only [h0, hX, hr, if_false, if_true, not_false_eq_true, false_and, true_and, false_or] 
        tauto
      · simp only [h0, hX, hr, if_false, if_true, not_false_eq_true, false_and, true_and, false_or]
        tauto
