import os,sys,hashlib,json,time,subprocess
from pathlib import Path
r=Path('/tmp/reflected-geometry-reuse-20261028');phase=sys.argv[1];task=sys.argv[2];base=Path('Computability/DiophantineConsistency/Lean');d=base/'DiophantineConsistency';env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+env.get('LEAN_PATH','')
if task=='target':jobs=[('target',d/'CurrentReflectedGeometry2011.lean',True)]
else:jobs=[('early',d/'CurrentEarlyPadding2011.lean',True),('phase',d/'CurrentPhaseParity2011.lean',True),('focus',d/'CurrentReflectedGeometry2011Checks.lean',False),('axioms',r/'axioms.lean',False)]
items=[]
for tag,src,obj in jobs:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(base),str(src)]
 if obj:
  outname={'target':'CurrentReflectedGeometry2011','early':'CurrentEarlyPadding2011','phase':'CurrentPhaseParity2011'}[tag]
  out=r/phase/'DiophantineConsistency'/(outname+'.olean');cmd+=['-o',str(out)]
 t=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True);log=r/(phase+'-'+tag+'.log');log.write_bytes(p.stdout+p.stderr)
 row={'tag':tag,'cmd':cmd,'status':p.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and p.returncode==0:row.update(object_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),object_bytes=out.stat().st_size)
 items.append(row);(r/(phase+'-'+task+'-records.json')).write_text(json.dumps(items,indent=2)+'\n');print(phase,tag,p.returncode,round(row['seconds'],2),flush=True)
 if p.returncode:sys.exit(p.returncode)
