from pathlib import Path
import re,subprocess,json,hashlib,time,os,concurrent.futures,threading
R=Path('/tmp/selector-shared-20261028');root=Path('Computability/DiophantineConsistency/Lean');common=R/'common/DiophantineConsistency';names=['ArithmeticCellPhysical','ArithmeticCellLocal','CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011'];hs=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]; lock=threading.Lock()
for phase in ['baseline','final']:
 d=R/phase/'DiophantineConsistency';d.mkdir(parents=True,exist_ok=True)
 for p in common.iterdir():
  if p.suffix=='.olean' and p.stem not in names:
   t=d/p.name
   if not t.exists() and not t.is_symlink():t.symlink_to(p.resolve())
for n,src in [('local','/tmp/list-getd-sharing-20261028/source/AxiomsArithmeticCellLocal.lean'),('local-generated','/tmp/list-getd-sharing-20261028/source/AxiomsLocalGenerated.lean'),('normal','/tmp/reflected-geometry-reuse-20261028/axioms.lean'),('mf','/tmp/mf-reflected-geometry-reuse/axioms.lean')]:
 (R/('axioms-'+n+'.lean')).write_bytes(Path(src).read_bytes())
s=(R/'baseline/DiophantineConsistency/ArithmeticCellPhysical.lean').read_text();public=re.findall(r'^(?:noncomputable\s+)?(?:def|abbrev|theorem|lemma|structure|inductive)\s+(\w+)',s,re.M)
exports=re.search(r'^export MF\.WangTiles942 \(([^)]*)\)',s,re.M).group(1).split(); public+=exports
(R/'axioms-physical.lean').write_text('import DiophantineConsistency.ArithmeticCellPhysical\n'+''.join('#print axioms DiophantineConsistency.ArithmeticCellPhysical.'+n+'\n' for n in public))
(R/'axioms-new.lean').write_text('import DiophantineConsistency.ArithmeticCellPhysical\n#print axioms DiophantineConsistency.ArithmeticCellPhysical.selector_sum_le\n#print axioms DiophantineConsistency.ArithmeticCellPhysical.selector_weighted_lt\n')
def run(phase,tag,source,srcroot,output=None):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+env.get('LEAN_PATH','');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(R/(phase+'-'+tag+'.time')),'lean','-M9000','-j1','-DElab.async=false','-R',str(srcroot),str(source)]
 if output is not None:output.unlink(missing_ok=True);cmd+=['-o',str(output)]
 log=R/(phase+'-'+tag+'.log');before=hs(source);start=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-start,'source_sha256':before,'source_after':hs(source),'log_sha256':hs(log),'timing':(R/(phase+'-'+tag+'.time')).read_text().strip()}
 if output and output.exists():rec.update(object_sha256=hs(output),object_bytes=output.stat().st_size)
 with lock:
  records.append(rec);(R/'phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,q.returncode,round(rec['seconds'],1),flush=True)
 if q.returncode or rec['source_after']!=before:raise RuntimeError(phase+' '+tag)
def target(phase,n):return run(phase,n,(R/('baseline' if phase=='baseline' else 'source')/'DiophantineConsistency'/(n+'.lean')),R/('baseline' if phase=='baseline' else 'source'),R/phase/'DiophantineConsistency'/(n+'.olean'))
for p in ['baseline','final']:target(p,'ArithmeticCellPhysical')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 tasks=[ex.submit(target,p,n) for n in names[1:] for p in ['baseline','final']]
 for t in tasks:t.result()
for phase in ['baseline','final']:
 for tag in ['physical','local','local-generated','normal','mf']:
  run(phase,'axioms-'+tag,R/('axioms-'+tag+'.lean'),R)
for tag in ['physical','local','local-generated','normal','mf']:
 a=(R/('baseline-axioms-'+tag+'.log')).read_bytes();b=(R/('final-axioms-'+tag+'.log')).read_bytes()
 if a!=b:print('AXIOM DIFFERENCE',tag,flush=True);raise SystemExit(2)
run('final','axioms-new',R/'axioms-new.lean',R)
for p in ['baseline','final']:
 for n in ['ArithmeticCellLabels','CurrentReflectedGeometry2011Checks','CurrentPhaseParity2011','MFCurrentCopyParity2011']:
  run(p,'client-'+n,root/'DiophantineConsistency'/(n+'.lean'),root,R/p/'DiophantineConsistency'/(n+'.olean'))
print('all complete, public axioms match',flush=True)
