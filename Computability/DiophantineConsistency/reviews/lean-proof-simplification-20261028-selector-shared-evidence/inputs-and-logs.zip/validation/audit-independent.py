from pathlib import Path
import re,hashlib,json,subprocess
R=Path('/tmp/selector-shared-20261028');D=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bad=[]
def chk(ok,msg):
 if not ok:bad.append(msg)
names=['ArithmeticCellPhysical','ArithmeticCellLocal','CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011']
for n in names:
 base=R/'baseline/DiophantineConsistency'/(n+'.lean');final=R/'source/DiophantineConsistency'/(n+'.lean');v2=R/'source2/DiophantineConsistency'/(n+'.lean');old=subprocess.check_output(['git','show','HEAD:'+str(D/(n+'.lean'))]);chk(base.read_bytes()==old,n+' baseline matches HEAD');chk(final.read_bytes()==v2.read_bytes(),n+' source equals v2');
records=json.loads((R/'phase-records.json').read_text());chk(len(records)==27,'27 phase records')
for x in records:
 phase,tag,cmd=x['phase'],x['tag'],x['command'];lg=R/(phase+'-'+tag+'.log');tm=R/(phase+'-'+tag+'.time');src=[Path(a) for a in cmd if a.endswith('.lean') and Path(a).is_file()];chk(x['status']==0,phase+' '+tag+' status');chk(len(src)==1,phase+' '+tag+' source count');
 if len(src)==1:chk(H(src[0])==x['source_sha256']==x['source_after'],phase+' '+tag+' source');
 chk(lg.exists() and H(lg)==x['log_sha256'],phase+' '+tag+' log');chk(tm.exists() and tm.read_text().strip()==x['timing'],phase+' '+tag+' timing');chk(x['lean_path'].split(':')[0]==str(R/phase),phase+' '+tag+' path');
 if 'object_sha256' in x:
  ix=len(cmd)-1-cmd[::-1].index('-o');out=Path(cmd[ix+1]);chk(out.exists() and H(out)==x['object_sha256'] and out.stat().st_size==x['object_bytes'],phase+' '+tag+' object')
for t in ['physical','local','local-generated','normal','mf']:
 a=R/('baseline-axioms-'+t+'.log');b=R/('final-axioms-'+t+'.log');chk(a.read_bytes()==b.read_bytes(),t+' axiom logs');print(t,'reports', (R/('axioms-'+t+'.lean')).read_text().count('#print axioms'))
for n in ['ArithmeticCellLabels','CurrentReflectedGeometry2011Checks','CurrentPhaseParity2011','MFCurrentCopyParity2011']:
 a=R/('baseline-client-'+n+'.log');b=R/('final-client-'+n+'.log');chk(a.read_bytes()==b.read_bytes(),n+' client logs')
a=(R/'baseline-ArithmeticCellLocal.log').read_text();b=(R/'final-ArithmeticCellLocal.log').read_text();normal=lambda s: re.sub(r'/tmp/selector-shared-20261028/(baseline|source)/DiophantineConsistency/ArithmeticCellLocal\.lean:\d+:\d+', '<source>:LINE', s);chk(normal(a)==normal(b),'normalized cell warning logs');print('cell warnings',a.count('warning:'),b.count('warning:'))
# direct check names in public probe; declarations can have attributes inline.
for n,t,prefix in [('ArithmeticCellPhysical','physical','DiophantineConsistency.ArithmeticCellPhysical.'),('ArithmeticCellLocal','local','DiophantineConsistency.ArithmeticCellLocal.'),('CurrentReflectedGeometry2011','normal','DiophantineConsistency.CurrentReflectedGeometry2011.'),('MFCurrentReflectedGeometry2011','mf','DiophantineConsistency.MF.CurrentReflectedGeometry2011.')]:
 text=(R/'baseline/DiophantineConsistency'/(n+'.lean')).read_text();decl=re.findall(r'^(?:@\[[^\]]+\]\s*)?(?:noncomputable\s+)?(?:def|abbrev|theorem|lemma|structure|inductive)\s+(\w+)',text,re.M);s=(R/('axioms-'+t+'.lean')).read_text() + ((R/'axioms-local-generated.lean').read_text() if t=='local' else '');present={v for v in re.findall(r'^#print axioms\s+(\S+)',s,re.M)};missing=[x for x in decl if prefix+x not in present];chk(not missing,n+' missing declarations '+str(missing));print(n,'named decl',len(decl),'missing',missing)
# Selected graph inherited verbatim from previous reviewed refactor.
selected=json.loads((R/'selected-objects.json').read_text());prior=json.loads(Path('/tmp/reflected-shared-20261028/selected-objects.json').read_text());old={x['module']:x for x in prior};chk(len(selected)==55 and len(old)==55,'55 pins')
for x in selected:
 n=x['module'];p=old.get(n);chk(p is not None and x['source_sha256']==p['source_sha256'] and x['object_sha256']==p['object_sha256'],n+' previous pin');src=Path(x['source']);obj=Path(x['object']);chk(src.exists() and H(src)==x['source_sha256'],n+' source');chk(obj.exists() and H(obj)==x['object_sha256'],n+' object');loc=R/'common/DiophantineConsistency'/(n.split('.')[-1]+'.olean');chk(loc.exists() and H(loc)==x['object_sha256'],n+' common selection');
 imports=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:imports.extend(z for z in m.group(1).split() if z.startswith('DiophantineConsistency.') and (D.parent/(z.replace('.','/')+'.lean')).exists())
 chk(imports==x['local_imports'],n+' import edges')
# Both phase overlays select same dependency objects as audited common.
for x in selected:
 n=x['module']
 for phase in ['baseline','final']:
  p=R/phase/'DiophantineConsistency'/(n.split('.')[-1]+'.olean');chk(p.exists() and H(p)==x['object_sha256'],phase+' '+n+' selection')
print('phase records',len(records),'selected objects',len(selected));print('failures:',bad)
if bad:raise SystemExit(1)
