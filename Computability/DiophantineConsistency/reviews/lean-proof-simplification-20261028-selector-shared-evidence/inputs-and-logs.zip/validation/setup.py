from pathlib import Path
R=Path('/tmp/selector-shared-20261028');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');out=R/'source/DiophantineConsistency';base=R/'baseline/DiophantineConsistency';out.mkdir(parents=True,exist_ok=True);base.mkdir(parents=True,exist_ok=True);names=['ArithmeticCellPhysical','ArithmeticCellLocal','CurrentReflectedGeometry2011','MFCurrentReflectedGeometry2011']
for n in names:
 s=(root/(n+'.lean')).read_text();(base/(n+'.lean')).write_text(s)
 if n=='ArithmeticCellPhysical':
  probe=(R/'probe.lean').read_text();helper=probe[probe.index('theorem selector_sum_le'):probe.index('\nend Test')];pos=s.index('\n/-! ### The physical selector tail');s=s[:pos]+'\n\n'+helper+'\n'+s[pos:]
 else:
  start=s.index('theorem selector_source_sum_le');body=s.index(':= by\n',start)+len(':= by\n');end=s.index('\ntheorem selector_reflection_lt',body) if n=='ArithmeticCellLocal' else s.index('\nomit [NeZero (N * 2011)] in\ntheorem selector_reflection_lt',body)
  new=('  exact ArithmeticCellPhysical.selector_sum_le h (fun j => cw (4022 + j))\n') if n=='ArithmeticCellLocal' else '  simpa only [Fin.sum_univ_eq_sum_range] using\n    (ArithmeticCellPhysical.selector_sum_le h (fun j => c (b + (j : ZMod (N * 2011)))))\n'
  s=s[:body]+new+s[end:]
  start=s.index('theorem selector_reflection_lt');body=s.index(':= by\n',start)+len(':= by\n');end=s.index('\ntheorem control_reflection_le',body) if n=='ArithmeticCellLocal' else s.index('\nomit [NeZero (N * 2011)] in\ntheorem control_reflection_le',body)
  new=('  exact ArithmeticCellPhysical.selector_weighted_lt h (fun j => cw (4022 + j)) hone\n') if n=='ArithmeticCellLocal' else '  apply ArithmeticCellPhysical.selector_weighted_lt h (fun j => c (b + (j : ZMod (N * 2011))))\n  simpa only [Fin.sum_univ_eq_sum_range] using hone\n'
  s=s[:body]+new+s[end:]
 (out/(n+'.lean')).write_text(s)
dst=R/'overlay/DiophantineConsistency';dst.mkdir(parents=True,exist_ok=True)
for p in Path('/tmp/reflected-shared-20261028/final/DiophantineConsistency').iterdir():
 if p.suffix=='.olean' and p.stem not in names:
  d=dst/p.name
  if not d.exists() and not d.is_symlink():d.symlink_to(p.resolve())
print('candidate snapshots ready')
