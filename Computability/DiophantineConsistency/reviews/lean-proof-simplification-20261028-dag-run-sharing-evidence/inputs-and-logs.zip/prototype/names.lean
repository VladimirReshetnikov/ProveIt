import DiophantineConsistency.ArithmeticRuntimeBoundDagRun
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticRuntimeBoundDagRun).isPrefixOf n ||
     (`_private.DiophantineConsistency.ArithmeticRuntimeBoundDagRun).isPrefixOf n then
   logInfo m!"DECL {n}"
