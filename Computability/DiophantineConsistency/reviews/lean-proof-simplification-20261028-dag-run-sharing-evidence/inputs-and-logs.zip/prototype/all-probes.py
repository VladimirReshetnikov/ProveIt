import subprocess,sys
for phase in ('baseline','final'):
 for probe in ('interfaces','global-simp'):
  subprocess.run([sys.executable,'/tmp/dag-run-sharing/probe.py',phase,probe],check=True)
