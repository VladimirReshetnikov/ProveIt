import pathlib,subprocess,json,os,time,hashlib,concurrent.futures
P=pathlib.Path('/tmp/dag-run-sharing'); R=pathlib.Path('/tmp/bisim-share');path=json.loads((R/'forward-phase-records.json').read_text())[0]['lean_path'];H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();records=[]
def run(phase,tag,src,root,out=None):
 env=os.environ.copy();env['LEAN_PATH']=str(P/phase)+':'+path;log=P/f'{phase}-{tag}.log';tm=P/f'{phase}-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(root),str(src)];
 if out:cmd+=['-o',str(out)]
 before=H(src);t=time.monotonic()
 with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 z={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':H(src),'log_sha256':H(log),'time_sha256':H(tm),'elapsed':time.monotonic()-t};
 if out and out.exists():z['object_sha256']=H(out)
 records.append(z);(P/'records.json').write_text(json.dumps(records,indent=2));print(phase,tag,r.returncode,flush=True);return r.returncode
for phase in ['baseline','final']:
 src=P/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean';out=src.with_suffix('.olean');assert run(phase,'target',src,P/phase,out)==0
 assert run(phase,'probe',P/'probe.lean',P)==0
 src=pathlib.Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.lean');out=P/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.olean';run(phase,'client',src,'Computability/DiophantineConsistency/Lean',out)
