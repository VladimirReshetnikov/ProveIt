from pathlib import Path
import json,hashlib
r=Path('/tmp/dag-run-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();all=[]
for phase in ('baseline','final'):
 xs=json.loads((r/f'{phase}-records.json').read_text());xs=[x for x in xs if x['status']==0]
 if phase=='final':xs+=json.loads((r/'final-resumed-records.json').read_text())
 assert [x['module'] for x in xs]==['ArithmeticRuntimeBoundDagRun','ArithmeticRuntimeBoundDagMacrosA','ArithmeticRuntimeBoundDagMacrosB']
 for x in xs:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['workspace_before']==x['workspace_after'] and (x['workspace_before']==h(x['workspace']) or (x['module']=='ArithmeticRuntimeBoundDagRun' and x['workspace_before']==h(r/'snapshots/baseline/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean') and h(x['workspace'])==h(r/'snapshots/final/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean'))) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
  if phase=='baseline' or x['module']!='ArithmeticRuntimeBoundDagRun':assert x['before']==x['workspace_before']
  for d in x['direct_inputs']:
   q=next(Path(y)/(d['module'].replace('.','/')+'.olean') for y in x['LEAN_PATH'].split(':') if (Path(y)/(d['module'].replace('.','/')+'.olean')).is_file());assert str(q)==d['path'] and str(q.resolve())==d['resolved'] and d['before']==d['after']==h(q)
   if d['source']:assert d['source_before']==d['source_after'] and (d['source_before']==h(d['source']) or (d['module'].endswith('.ArithmeticRuntimeBoundDagRun') and d['source_before']==h(r/'snapshots/baseline/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean') and h(d['source'])==h(r/'snapshots/final/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean')))
   if d['module'].endswith('ArithmeticRuntimeBoundDagRun'):assert d['resolved']==str(r/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagRun.olean')
   if d['module'].endswith('ArithmeticRuntimeBoundDagMacrosA'):assert d['resolved']==str(r/phase/'DiophantineConsistency/ArithmeticRuntimeBoundDagMacrosA.olean')
   if d['module'].endswith('ArithmeticEnumBoundTower'):assert d['resolved']=='/tmp/cantor-bound-simplify/tower-final/DiophantineConsistency/ArithmeticEnumBoundTower.olean'
  all.append(x);print('build',phase,x['module'],len(x['direct_inputs']),'inputs verified')
 for probe in ('names','interfaces','global-simp'):
  x=json.loads((r/f'{phase}-{probe}-record.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log']);print('probe',phase,probe,'verified')
x=json.loads((r/'final-helpers-record.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object']) and x['log_sha256']==h(x['log']);print('helper probe verified')
for p in ['interfaces','global-simp']:assert (r/f'baseline-{p}.log').read_bytes()==(r/f'final-{p}.log').read_bytes();print(p,'identical')
old=json.loads((r/'final-interrupted-records.json').read_text())[-1];assert old['status']==143 and h(r/'final-interrupted-ArithmeticRuntimeBoundDagMacrosB.log')==old['log_sha256'] and h(r/'final-interrupted-ArithmeticRuntimeBoundDagMacrosB.time')==old['time_sha256'];print('interrupted failure preserved')
prev=json.loads(Path('/tmp/dag-independent-audit/fol-refresh-records.json').read_text());tower=json.loads(Path('/tmp/cantor-bound-simplify/build-records.json').read_text())
for n in ['BusyBeaver.ZFC.ArithmeticDagLoops','BusyBeaver.ZFC.ArithmeticDagRootPerm222']:
 x=next(x for x in prev if x['module']==n);assert x['status']==0 and x['source_sha256']==x['source_after']==h(x['source']) and x['object_sha256']==h(x['object']);print('provider',n,'prior source/object match')
x=next(x for x in tower if x.get('name')=='ArithmeticEnumBoundTower' and x['phase']=='final');assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h('/tmp/cantor-bound-simplify/tower-final/DiophantineConsistency/ArithmeticEnumBoundTower.olean');print('provider tower prior source/object match')
print('total',len(all),'successful builds',sum(len(x['direct_inputs']) for x in all),'input occurrences')
