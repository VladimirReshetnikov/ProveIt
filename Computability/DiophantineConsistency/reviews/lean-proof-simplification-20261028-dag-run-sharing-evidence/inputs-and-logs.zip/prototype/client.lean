import DiophantineConsistency.ArithmeticRuntimeBoundDagRun
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open SetTheory.BusyBeaver.ZFC SetTheory.BusyBeaver.ZFC.RMDag
open DiophantineConsistency.ArithmeticRuntimeBoundDagRun
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
variable {p : Prog} {rows : Nat → Option ArithmeticControlBisim.Row} {run : V → V → V}
variable {n k : Nat} {a b : Edge} {x y A : V}
example (hn : p.nodes n = (a,b)) (h : IRunB p rows run a x (.brk 1) y A) :
  IRunB p rows run (.node n) x .normal y A := run_skipB hn h
example (hn : p.nodes n = (a,b)) (h : IRunB p rows run a x .halt y A) :
  IRunB p rows run (.node n) x .halt y A := run_halt_carB hn h
example (hn : p.nodes n = (a,b)) (h : IRunB p rows run a x (.brk (k+2)) y A) :
  IRunB p rows run (.node n) x (.brk (k+1)) y A := run_brk_carB hn h
example (hn : p.nodes n = (a,b)) (h : IRunB p rows run a x (.cont (k+1)) y A) :
  IRunB p rows run (.node n) x (.cont (k+1)) y A := run_cont_carB hn h
