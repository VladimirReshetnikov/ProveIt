from pathlib import Path
import json,hashlib
r=Path('/tmp/dag-run-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for ph in ('baseline','final'):
 x=json.loads((r/f'repeat-{ph}-record.json').read_text());prev=json.loads((r/f'{ph}-records.json').read_text())[0];d=x['direct_inputs'][0];assert x['status']==0 and x['before']==x['after']==h(x['source'])==prev['before'] and x['workspace_before']==x['workspace_after']==h(r/'snapshots/baseline/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean') and h(x['workspace'])==h(r/'snapshots/final/DiophantineConsistency/ArithmeticRuntimeBoundDagRun.lean') and x['object_sha256']==h(x['object'])==prev['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time']);assert d['before']==d['after']==h(d['path'])==prev['direct_inputs'][0]['before'] and d['source_before']==d['source_after']==h(d['source']);print(ph,x['timing'],'source/object/input verified')
