from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/trace-bounds-proof-20261028');pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';mode=sys.argv[1]
prereqs=['WangMachineEncoding','WangMachineAction','WangMachineStep','WangTiles942FinishConstruction','WangTiles942StepConstruction']
if mode=='baseline':items=[(n,pre+n+'.lean',n) for n in prereqs]+[('target',pre+'WangMachineTraceBounds.lean','WangMachineTraceBounds'),('axioms',str(p/'axioms.lean'),None)]
else:items=[('target',pre+'WangMachineTraceBounds.lean','WangMachineTraceBounds'),('axioms',str(p/'axioms.lean'),None),('focus',pre+'WangMachineTraceBoundsChecks.lean',None),('client',pre+'WangTiles942TraceCycle.lean',None)]
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free<60*1024*1024: raise SystemExit('disk guard: '+str(free))
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency'/(obj+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/trace-bounds-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-t;log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 z={'name':name,'argv':cmd,'status':r.returncode,'seconds':elapsed,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  q=p/'overlay/DiophantineConsistency'/(obj+'.olean');z['object']=str(q);z['object_sha256']=hashlib.sha256(q.read_bytes()).hexdigest();z['object_bytes']=q.stat().st_size
 records.append(z);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
