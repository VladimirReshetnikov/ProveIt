from pathlib import Path
import os,json,hashlib,subprocess,time,re
R=Path('/tmp/wang-rail-card-20261028');S=Path('Computability/DiophantineConsistency/Lean');old=(R/'baseline-source/DiophantineConsistency/WangTiles942Language.lean').read_text();names=re.findall(r'^(?:noncomputable\s+)?(?:theorem|def|abbrev|lemma|inductive|structure)\s+(\w+)',old,re.M);prefix='DiophantineConsistency.WangTiles942Language.';generated=(R/'allowed-prefix2.log').read_text().splitlines();allnames=list(dict.fromkeys([prefix+n for n in names]+generated));probe=R/'axioms.lean';probe.write_text('import DiophantineConsistency.WangTiles942Language\n'+''.join('#print axioms '+n+'\n' for n in allnames));print('probing',len(allnames),'declarations',flush=True)
clients=['WangTiles942LanguageChecks','WangTiles942Boundary','WangTiles942Periodic','WangTiles942ResetHorizontal','WangTiles942InitialHorizontal','WangMachineAction','WangTiles942FinishConstruction','CurrentOccupation2011'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/(phase+'-fresh'))+':'+env.get('LEAN_PATH','')
 for n in clients+['axioms']:
  src=probe if n=='axioms' else S/'DiophantineConsistency'/(n+'.lean');log=R/(phase+'-fresh-'+n+'.log');tm=R/(phase+'-fresh-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(S),str(src)];out=None
  if n!='axioms':out=R/(phase+'-fresh')/'DiophantineConsistency'/(n+'.olean');out.unlink(missing_ok=True);cmd+=['-o',str(out)]
  before=sha(src);t=time.monotonic()
  with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  rec={'phase':phase,'job':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':sha(src),'log_sha256':sha(log),'timing':tm.read_text().strip()}
  if out and out.exists():rec.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
  rows.append(rec);(R/'fresh-client-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,q.returncode,round(rec['seconds'],1),flush=True)
  if q.returncode:print(log.read_text()[:1500],flush=True)
assert (R/'baseline-fresh-axioms.log').read_bytes()==(R/'final-fresh-axioms.log').read_bytes(),'axioms differ'
print('axioms identical',flush=True)
