from pathlib import Path
import json,re,hashlib
R=Path('/tmp/wang-rail-card-20261028');srcroot=Path('Computability/DiophantineConsistency/Lean');overlay=R/'baseline-fresh';seen={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def walk(n):
 if n in seen:return
 src=srcroot/(n.replace('.','/')+'.lean')
 if not src.is_file():return
 imports=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:imports.extend(m.group(1).split())
 o=overlay/(n.replace('.','/')+'.olean');v={'source':str(src),'source_sha256':sha(src),'imports':imports}
 if o.exists():v.update(object=str(o.resolve()),object_sha256=sha(o),source_newer=src.stat().st_mtime>o.stat().st_mtime)
 seen[n]=v
 for x in imports:
  if x.startswith('DiophantineConsistency.'):walk(x)
walk('DiophantineConsistency.CurrentOccupation2011');(R/'occupation-graph.json').write_text(json.dumps(seen,indent=2)+'\n');print('nodes',len(seen),'missing',[n for n,v in seen.items() if 'object' not in v]);print('source-newer',[n for n,v in seen.items() if v.get('source_newer')])
