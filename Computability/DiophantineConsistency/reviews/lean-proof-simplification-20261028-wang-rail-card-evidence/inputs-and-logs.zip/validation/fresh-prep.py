from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/tmp/wang-rail-card-20261028');K=Path('/tmp/kernel-eval-rewrite/shared');D=R/'common-fresh/DiophantineConsistency';D.mkdir(parents=True,exist_ok=True);src=R/'baseline/DiophantineConsistency';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in src.iterdir():
 if p.suffix=='.olean' and p.exists():
  d=D/p.name
  if not d.exists() and not d.is_symlink():d.symlink_to(p.resolve())
(R/'common-fresh/BusyBeaver').symlink_to(K/'BusyBeaver',target_is_directory=True)
rs=json.loads(Path('/tmp/kernel-eval-rewrite/shared-builds.json').read_text());wanted=['BusyBeaver.Core','BusyBeaver.ZFC.KDense215','BusyBeaver.ZFC.KDenseBridge','BusyBeaver.ZFC.KZip','BusyBeaver.ZFC.KTable215','BusyBeaver.ZFC.KTableCore','DiophantineConsistency.DecimalMachine215','DiophantineConsistency.WangTiles942Data','DiophantineConsistency.WangTiles942TableData'];pins=[]
for n in wanted:
 rec=next(x for x in rs if x['module']==n);cmd=rec['cmd'];f=next(Path(a) for a in cmd if a.endswith('.lean') and Path(a).exists());obj=K/(n.replace('.','/')+'.olean');assert sha(f)==rec['source_before'] and sha(obj)==rec['object_sha256'] and rec['status']==0,n;pins.append({'module':n,'source':str(f),'source_sha256':sha(f),'object':str(obj),'object_sha256':sha(obj)})
 if n.startswith('DiophantineConsistency.'):
  t=D/(n.split('.')[-1]+'.olean');t.unlink(missing_ok=True);t.symlink_to(obj.resolve())
(R/'fresh-pins.json').write_text(json.dumps(pins,indent=2)+'\n');env=os.environ.copy();env['LEAN_PATH']=str(R/'common-fresh')+':'+env.get('LEAN_PATH','');base=Path('Computability/DiophantineConsistency/Lean');records=[]
for n in ['WangTiles942Core','DecimalMachineInitialization','WangMachineEncoding']:
 src=base/'DiophantineConsistency'/(n+'.lean');out=D/(n+'.olean');out.unlink(missing_ok=True);log=R/('fresh-'+n+'.log');tm=R/('fresh-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(base),str(src),'-o',str(out)];before=sha(src);t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':sha(src),'log_sha256':sha(log),'timing':tm.read_text().strip()}
 if out.exists():rec['object_sha256']=sha(out)
 records.append(rec);(R/'fresh-prep-records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,q.returncode,round(rec['seconds'],1),flush=True)
 if q.returncode or before!=sha(src):raise SystemExit(1)
