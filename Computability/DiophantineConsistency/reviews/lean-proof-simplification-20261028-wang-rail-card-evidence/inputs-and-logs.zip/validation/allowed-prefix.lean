import DiophantineConsistency.WangTiles942Language
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.WangTiles942Language.Allowed).isPrefixOf n then
      logInfo m!"{n}"
