from pathlib import Path
import json,hashlib,re
R=Path('/tmp/wang-rail-card-20261028');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('Computability/HilbertTenthProblem/Lean')];cache=[R/'baseline',Path('.lake/build/lib/lean')];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();seen={};order=[]
def walk(n):
 if n in seen:return
 rel=n.replace('.','/')+'.lean';src=next((r/rel for r in roots if (r/rel).exists()),None)
 if not src:return
 if n=='DiophantineConsistency.WangTiles942Language':src=R/'baseline-source/DiophantineConsistency/WangTiles942Language.lean'
 imports=[]
 for line in src.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:imports.extend(m.group(1).split())
 relobj=n.replace('.','/')+'.olean';obj=next((x/relobj for x in cache if (x/relobj).exists()),None);z={'source':str(src),'source_sha256':sha(src),'imports':imports}
 if obj:z.update(object=str(obj.resolve()),object_sha256=sha(obj))
 seen[n]=z
 for x in imports:walk(x)
 order.append(n)
walk('DiophantineConsistency.WangTiles942Language');(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order},indent=2)+'\n');print('nodes',len(seen),'missing',[n for n,x in seen.items() if 'object' not in x]);
for n,x in seen.items():
 if 'object' in x and Path(x['source']).stat().st_mtime>Path(x['object']).stat().st_mtime:print('source-newer',n)
