from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/wang-rail-card-20261028');hs=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for phase in ['baseline','final']:
 src=R/('baseline-source' if phase=='baseline' else 'source')/'DiophantineConsistency/WangTiles942Language.lean';out=R/(phase+'-fresh')/'DiophantineConsistency/WangTiles942Language.olean';env=os.environ.copy();env['LEAN_PATH']=str(R/(phase+'-fresh'))+':'+env.get('LEAN_PATH','');log=R/(phase+'-fresh-target.log');tm=R/(phase+'-fresh-target.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(src.parent.parent),str(src),'-o',str(out)];sh=hs(src);t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'phase':phase,'job':'target','command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'seconds':time.monotonic()-t,'source_sha256':sh,'source_after':hs(src),'log_sha256':hs(log),'timing':tm.read_text().strip()}
 if out.exists():rec['object_sha256']=hs(out)
 rows.append(rec);(R/'fresh-target-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(phase,q.returncode,round(rec['seconds'],2),flush=True)
 if q.returncode or rec['source_after']!=sh:raise SystemExit(1)
