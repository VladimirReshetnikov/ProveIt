from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/dev/shm/tiling-colours-direct');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticTilingTable.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticTilingTable.lean').read_text()
changes=[('''  · have h : (433 : V) + 1 = 434 := by norm_num
    rw [h]; exact c434''','''  · convert c434 (V := V) using 1; norm_num'''),('''  · have h : (431 : V) + 1 = 432 := by norm_num
    have h2 : (432 : V) + 1 = 433 := by norm_num
    rw [h, h2]; exact c432''','''  · convert c432 (V := V) using 1 <;> norm_num'''),('''  · have h : (923 : V) + 1 = 924 := by norm_num
    rw [h]; exact c924''','''  · convert c924 (V := V) using 1; norm_num'''),('''  · have h : (925 : V) + 1 = 926 := by norm_num
    have h2 : (432 : V) + 1 = 433 := by norm_num
    rw [h, h2]; exact c926''','''  · convert c926 (V := V) using 1 <;> norm_num''')]
for a,z in changes:assert b.count(a)==1;b=b.replace(a,z)
assert b==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingTable.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}'])
assert gitfile('ab35b49240^')==(R/'baseline/DiophantineConsistency/ArithmeticTilingTable.lean').read_bytes() and gitfile('ab35b49240')==f.encode() and (W/'ArithmeticTilingTable.lean').read_text()==f
print('PASS exact four substitutions, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticTilingTable$','--','*.lean'],text=True).splitlines();assert clients==['Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingRows.lean'],clients;print('PASS sole tracked Lean direct client',clients)
x=next(x for x in read('/tmp/runtrace-step-bound/alternate-records.json') if x['module']=='ArithmeticRunTrace');assert x['status']==0 and x['before']==x['after']==h(W/'ArithmeticRunTrace.lean') and x['object_sha256']==h(x['object']);provider=x['object_sha256'];print('PASS source-current prior RunTrace object',provider)
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticTilingTable','ArithmeticTilingRows'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticTilingTable':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   assert d['before']==(provider if n=='ArithmeticRunTrace' else rec[phase]['ArithmeticTilingTable']['object_sha256'])
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
assert rec['baseline']['ArithmeticTilingRows']['object_sha256']!=rec['final']['ArithmeticTilingRows']['object_sha256']
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticTilingTable']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=read(R/'ArithmeticTilingRows-probe-records.json');assert len(rows)==8
for x in rows:
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[x['phase']][n]['object_sha256'] for n in ('ArithmeticTilingTable','ArithmeticTilingRows')] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-ArithmeticTilingRows-{n}.log').read_bytes()==(R/f'final-ArithmeticTilingRows-{n}.log').read_bytes()
print('PASS target and differing client declaration/type/axiom and registration reports, both-object pins')
rows=read(R/'superseded/final-records.json');assert len(rows)==2
for x in rows:
 assert x['status']==0 and x['log_sha256']==h(R/'superseded'/('final-'+x['module']+'.log')) and x['object_sha256']==h(R/'superseded'/(x['module']+'.olean')) and Path(R/'superseded'/('final-'+x['module']+'.time')).read_text()==x['time']
 if x['module']=='ArithmeticTilingTable':assert x['before']==x['after']==h(R/'superseded/source.lean')
print('PASS superseded source and copied output/log/time hashes; original paths reused')
