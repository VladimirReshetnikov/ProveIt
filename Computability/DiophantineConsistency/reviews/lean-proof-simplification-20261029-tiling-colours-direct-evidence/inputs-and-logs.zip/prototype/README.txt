Tiling-table bit-colour branches: isolated proof simplification

Baseline ArithmeticTilingTable SHA-256 9465aed8e07d8f3985e54c21725eba3dd60229a2d8b0a15e622df03cef9a5a2a;
final SHA-256 c31916181af1959856edd29792883bc0ce6dc2e9b67a0ef62ebfc816f0dafe07.
In each of pass_colours, halt_colours, finish_colours and finish_head_colours,
the existing bit=1 branch now converts the already certified standard tile
colour directly and normalizes the numeral equality, rather than naming one or
two intermediate numeral equalities. The bit=0 branches and all statements,
guards, colour data, definitions and imports are unchanged. Ten proof lines are
replaced by four. Tested sources match commit ab35b49240 and its parent.
Original source commit 5fcd5632b3b753237437f22904b899653f69916b
has Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>.

baseline/final-records.json capture target and sole tracked Lean direct client
ArithmeticTilingRows source, direct input objects before/after, commands, logs,
timings and outputs. The target's only direct project provider RunTrace matches
the current-source build in /tmp/runtrace-step-bound/alternate-records.json;
audit.py/.log check that producer, first-provider paths, selected builds and
probes. This does not rebuild a full project, BusyBeaver, Foundation or Mathlib
closure; provider sources are matched through prior receipts rather than sampled
at the time of these builds.

The target and client pass both phases; target CPU 8.97/8.36 s and client
23.09/22.44 s (baseline/final single shared-load samples, not a benchmark).
TilingRows output object bytes differ (baseline b0b4a45c696a01493627bc5ee607351e0d2dc7b53bf5efd5335f061432fedcea,
final 15702307b8e80bc5726dc24262b67880466b42f4a446c8d7ed79a36598deb7f3), for
an unestablished reason. Paired client probes pin both target and client object
before/after and show all 58 namespace declaration/type/axiom reports and the
29,730 default simp/13,388 instance entries match. Target probes match all 73
namespace reports and 29,730 simp/13,383 instance entries. These checks do not
establish equality of proof bodies, every persistent extension or untested
downstream behavior. Both phases retain the same six preexisting target lint
warnings and three client lint warnings, at shifted source line numbers.

The superseded/ directory preserves the prior successful candidate and client
receipts, source, logs, timings and objects. That candidate used unnecessary
<;> sequencing in two single-goal branches, which generated two new linter
warnings. The selected source replaces those two with semicolon sequencing;
all target and client builds and probes described above use the selected source.
