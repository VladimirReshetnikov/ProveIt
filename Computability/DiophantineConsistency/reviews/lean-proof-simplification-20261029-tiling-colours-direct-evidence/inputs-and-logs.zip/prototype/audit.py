from pathlib import Path
import hashlib,json,subprocess
R=Path('/dev/shm/tiling-colours-direct');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
provider=next(x for x in load('/tmp/runtrace-step-bound/alternate-records.json') if x['module']=='ArithmeticRunTrace');assert provider['status']==0 and provider['before']==provider['after']==h(W/'ArithmeticRunTrace.lean') and provider['object_sha256']==h(provider['object'])
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticTilingTable','ArithmeticTilingRows']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if x['module']!='ArithmeticTilingTable':assert x['before']==h(W/f"{x['module']}.lean")
  else:
   rev='ab35b49240^' if ph=='baseline' else 'ab35b49240'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingTable.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert h(W/'ArithmeticTilingTable.lean')==x['before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   assert d['before']==(provider['object_sha256'] if n=='ArithmeticRunTrace' else rr[0]['object_sha256'])
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
rows=load(R/'ArithmeticTilingRows-probe-records.json');assert len(rows)==8
for x in rows:assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[q['object_sha256'] for q in records[x['phase']]] and x['log_sha256']==h(x['log'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-ArithmeticTilingRows-{n}.log').read_bytes()==(R/f'final-ArithmeticTilingRows-{n}.log').read_bytes()
print('PASS source-matched RunTrace provider, paired target/client and both-object pinned namespace/registration probes')
