import DiophantineConsistency.ArithmeticTilingTable
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticTilingTable).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticTilingTable" then
   logInfo m!"DECL {n}"
