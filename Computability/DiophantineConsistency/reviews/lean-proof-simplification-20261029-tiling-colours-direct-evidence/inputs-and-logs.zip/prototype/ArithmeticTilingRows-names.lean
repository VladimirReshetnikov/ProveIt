import DiophantineConsistency.ArithmeticTilingRows
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticTilingRows).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticTilingRows" then
   logInfo m!"DECL {n}"
