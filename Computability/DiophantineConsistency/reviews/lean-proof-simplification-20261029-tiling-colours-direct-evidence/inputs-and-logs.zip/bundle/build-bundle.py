from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/dev/shm/tiling-colours-direct');D=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-tiling-colours-direct-evidence');D.mkdir(parents=True,exist_ok=True);files={}
for p in sorted(R.rglob('*')):
 if p.is_file() and not p.is_symlink() and not str(p.relative_to(R)).startswith('objects-') and p.suffix!='.olean' and p.name!='build-bundle.py':files['prototype/'+str(p.relative_to(R))]=p.read_bytes()
for n,p in {'runtrace-alternate-records.json':'/tmp/runtrace-step-bound/alternate-records.json','wang-initial-records.json':'/tmp/wang-initial-sharing/records.json'}.items():files['prior/'+n]=Path(p).read_bytes()
for x in ('tiling-colours-direct-peer-review.txt','tiling-colours-direct-peer-audit.py','tiling-colours-direct-peer-audit.log'):files['independent/'+x]=Path('/tmp',x).read_bytes()
c='ab35b492408dfaf8c352a4e7e33fffed454446e8';par='c0fb426562276873211dbd6e6bab098e2c3e94dd';rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticTilingTable.lean'
for rev,label in ((par,'baseline'),(c,'final')):
 files['commit/'+label+'.lean']=subprocess.check_output(['git','show',rev+':'+rel]);assert files['commit/'+label+'.lean']==files['prototype/'+label+'/DiophantineConsistency/ArithmeticTilingTable.lean']
files['bundle/build-bundle.py']=Path('/dev/shm/tiling-colours-direct/build-bundle.py').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':c,'source_parent':par,'scope':'Simplify four Boolean tile-colour branches using direct numeral normalization','validation':'Paired target and sole tracked direct Lean client TilingRows compile using the source-matched RunTrace provider. Client object bytes differ but target/client name/type/axiom and simp/instance reports match with both objects pinned. Selected candidate adds no warnings.','limitations':['The project, BusyBeaver, Foundation and Mathlib transitive closure was not rebuilt; direct RunTrace source/object match comes from prior producer receipts.','The superseded candidate compiled but introduced two unnecessary-sequencing warnings; its source, logs, timing and receipts are retained, while selected candidate avoids these. Original output/log paths were reused, and saved superseded compiled objects are excluded.','Single shared-load timing pairs are not general benchmarks. Matching namespace/registration reports do not establish equality of proof bodies, every persistent extension or untested downstream behavior.','Compiled objects are excluded; recorded hashes and first-provider paths require external objects for independent byte verification.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'independent_review_sha256':sha(files['independent/tiling-colours-direct-peer-review.txt']),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}}
(D/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'independent-review.txt').write_bytes(files['independent/tiling-colours-direct-peer-review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,b in files.items():assert z.read(n)==b
assert sha((D/'independent-review.txt').read_bytes())==manifest['independent_review_sha256'];print('PASS members',len(files),'zip sha',manifest['archive_sha256'],'review sha',manifest['independent_review_sha256'])
