import DiophantineConsistency.ArithmeticPellRecurrence
import DiophantineConsistency.ArithmeticGcdNormalization
import Mathlib.Algebra.Ring.Divisibility.Basic
#check dvd_mul_of_dvd_left
#check dvd_mul_of_dvd_right
#check dvd_add
#print axioms dvd_add
#print axioms dvd_mul_of_dvd_left
#print axioms dvd_mul_of_dvd_right
