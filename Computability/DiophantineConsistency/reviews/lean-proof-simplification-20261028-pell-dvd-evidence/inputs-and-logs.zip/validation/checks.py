from pathlib import Path
import os,subprocess,json,time,hashlib
b=Path('/tmp/pell-dvd-reuse');env=os.environ.copy();rec=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
for phase in ['baseline','final']:
 d=b/phase;lib=d/'lib';e=env.copy();e['LEAN_PATH']=str(lib)+':'+env['LEAN_PATH']
 for name in ['Axioms','Imports','ArithmeticPellStrongDivisibilityChecks','ArithmeticPellIntegralSolution']:
  src=b/(name+'.lean') if name in ['Axioms','Imports'] else root/(name+'.lean');out=lib/'DiophantineConsistency'/(name+'.olean');log=d/(name+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false'];
  if name not in ['Axioms','Imports']:
   cmd+=['-R','Computability/DiophantineConsistency/Lean']
   if out.is_symlink():out.unlink()
  cmd+=[str(src)]
  if name not in ['Axioms','Imports']:cmd+=['-o',str(out)]
  t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'phase':phase,'name':name,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(src),'log_sha256':h(log),'object_sha256':h(out) if name not in ['Axioms','Imports'] and out.exists() else None});(b/'check-records.json').write_text(json.dumps(rec,indent=2));print(phase,name,r.returncode,rec[-1]['seconds'],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
a=(b/'baseline/Axioms.log').read_bytes();c=(b/'final/Axioms.log').read_bytes();print('axioms identical',a==c,flush=True)
if a!=c:raise SystemExit(1)
x=set((b/'baseline/Imports.log').read_text().splitlines());y=set((b/'final/Imports.log').read_text().splitlines());print('additional modules:',sorted(y-x),flush=True);print('removed modules:',sorted(x-y),flush=True)
