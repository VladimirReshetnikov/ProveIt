import DiophantineConsistency.ArithmeticPellRecurrence
import DiophantineConsistency.ArithmeticGcdNormalization
#check dvd_add
#check dvd_mul_of_dvd_left
#check Dvd.dvd.add
#check Dvd.dvd.mul_right
#check dvd_add_iff_left
#check dvd_add_iff_right
