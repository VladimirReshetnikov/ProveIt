import DiophantineConsistency.ArithmeticPellStrongDivisibility
open Lean Elab Command
run_cmd do
  for n in (← getEnv).allImportedModuleNames do
    logInfo m!"{n}"
