from pathlib import Path
import json,re,hashlib
b=Path('/tmp/pell-dvd-reuse');ov=b/'prereqs';roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean'),Path('/home/codex/src/Proofs/lib/FormalizedFormalLogic-Foundation'),Path('Logic/FirstOrder/Lean')];known={}
for n,v in json.loads(Path('/tmp/fin-one-more/ArithmeticPellRecurrence-coherent-inventory.json').read_text()).items():
 if v['object_sha256'] and v['matching_receipts']:known.setdefault(n,[]).append({'source':v['source_sha256'],'object':v['object_sha256'],'receipt':'/tmp/fin-one-more/ArithmeticPellRecurrence-coherent-inventory.json'})
for file in ['/tmp/fin-one-more/build-records.json','/tmp/fin-one-more/client-prereq-records.json','/tmp/fin-one-more/check-records.json','/tmp/pell-dvd-reuse/prereq-records.json']:
 for r in json.load(open(file)):
  m=r.get('module',r.get('name'));phase=r.get('phase');status=r.get('status');obj=r.get('object_sha256');src=r.get('source_sha256');
  if m and '.' not in m:m='DiophantineConsistency.'+m
  if m and status==0 and obj and (phase is None or phase=='final'):known.setdefault(m,[]).append({'source':src,'object':obj,'receipt':file})
seen={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');src=next((r/(rel+'.lean') for r in roots if (r/(rel+'.lean')).exists()),None)
 if src is None:return
 deps=re.findall(r'^(?:public\s+)?(?:meta\s+)?import\s+((?:DiophantineConsistency|BusyBeaver|Foundation|FirstOrder)(?:\.\w+)+)',src.read_text(),re.M);obj=ov/(rel+'.olean');obj=obj if obj.exists() else Path('.lake/build/lib/lean')/(rel+'.olean');ss=sha(src);oo=sha(obj) if obj.exists() else None;match=[x['receipt'] for x in known.get(n,[]) if x['source']==ss and x['object']==oo];seen[n]={'source':str(src.resolve()),'source_sha256':ss,'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':oo,'matching_receipts':match,'imports':deps}
 for d in deps:visit(d)
for n in ['DiophantineConsistency.ArithmeticPellStrongDivisibility','DiophantineConsistency.ArithmeticPellIntegralSolution']:visit(n)
(b/'inventory.json').write_text(json.dumps(seen,indent=2));print('modules',len(seen),'matched',sum(bool(v['matching_receipts']) for v in seen.values()));print('unmatched', [n for n,v in seen.items() if v['object'] and not v['matching_receipts']]);print('missing', [n for n,v in seen.items() if not v['object']])
