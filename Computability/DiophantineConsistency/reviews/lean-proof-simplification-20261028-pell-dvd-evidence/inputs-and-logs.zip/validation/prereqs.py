from pathlib import Path
import subprocess,os,time,hashlib,json
b=Path('/tmp/pell-dvd-reuse');root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');e=os.environ.copy();e['LEAN_PATH']=str(b/'prereqs')+':'+e['LEAN_PATH'];records=[];h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
for n in ['ArithmeticPellKnownUnit','ArithmeticPellCommonUnit']:
 src=root/(n+'.lean');out=b/'prereqs'/'DiophantineConsistency'/(n+'.olean');log=b/(n+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(src),'-o',str(out)];t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);records.append({'module':n,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(src),'log_sha256':h(log),'object_sha256':h(out) if out.exists() else None});(b/'prereq-records.json').write_text(json.dumps(records,indent=2));print(n,r.returncode,records[-1]['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
