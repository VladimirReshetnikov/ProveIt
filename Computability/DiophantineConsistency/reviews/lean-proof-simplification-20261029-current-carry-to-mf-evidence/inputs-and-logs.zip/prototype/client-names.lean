import Lean.Elab.Command
import DiophantineConsistency.CurrentWordScalarWitness2011
import DiophantineConsistency.CurrentDummySafety2011
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.CurrentWordScalarWitness2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordScalarWitness2011" ||
     (`DiophantineConsistency.CurrentDummySafety2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentDummySafety2011" then
   logInfo m!"DECL {n}"
