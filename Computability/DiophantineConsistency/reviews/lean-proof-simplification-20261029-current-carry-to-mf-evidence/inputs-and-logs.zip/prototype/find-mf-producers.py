from pathlib import Path
import json,hashlib
w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');names=['MFCurrentCarryConstruction2011','MFCurrentWordClause2011','MFCurrentWordPadding2011','MFCurrentWordTopBounds2011','MFCurrentWordCopies2011','MFCurrentWordOrigin2011','MFCurrentWordHighMask2011'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();hashes={n:h(w/(n+'.lean')) for n in names};found={n:[] for n in names}
for dirname in ['carry-proof-sharing','carry-map-sharing','word-clause-sharing','word-copies-sharing','word-padding-sharing','word-origin-sharing','word-top-sharing','highmask-sharing']:
 for p in Path('/tmp',dirname).glob('*records*.json'):
  try:rows=json.loads(p.read_text())
  except (OSError,ValueError):continue
  if not isinstance(rows,list):continue
  for x in rows:
   if not isinstance(x,dict):continue
   n=str(x.get('module') or x.get('name','')).split('.')[-1]
   if n not in hashes or x.get('status')!=0:continue
   s=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');o=x.get('object') or x.get('output');v=x.get('object_sha256') or x.get('output_sha256')
   if s==hashes[n] and o and Path(o).is_file() and v==h(o):found[n].append({'receipt':str(p),'source':s,'object':o,'sha256':v})
Path('/tmp/current-carry-to-mf/prior-mf-producers.json').write_text(json.dumps(found,indent=2)+'\n')
for n,x in found.items():print(n,len(x),x[0] if x else '')
