import Lean.Elab.Command
import DiophantineConsistency.CurrentNativePacking2011
import DiophantineConsistency.CurrentDummySafety2011
import DiophantineConsistency.CurrentCarryConstruction2011Checks
import DiophantineConsistency.CurrentWordClause2011Checks
import DiophantineConsistency.CurrentWordPadding2011Checks
import DiophantineConsistency.CurrentWordTopBounds2011Checks
import DiophantineConsistency.CurrentWordCopies2011Checks
import DiophantineConsistency.CurrentWordOrigin2011Checks
import DiophantineConsistency.CurrentWordHighMask2011Checks
open Lean Elab Command
run_cmd do
 let env ← getEnv
 let t ← liftCoreM Lean.Meta.getSimpTheorems
 for (n, _) in env.constants.toList do
  if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) || t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
   logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
