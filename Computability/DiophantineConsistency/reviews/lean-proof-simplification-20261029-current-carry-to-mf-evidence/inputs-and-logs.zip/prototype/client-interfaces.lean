import Lean.Elab.Command
import DiophantineConsistency.CurrentWordScalarWitness2011
import DiophantineConsistency.CurrentDummySafety2011
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.CurrentWordScalarWitness2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordScalarWitness2011" ||
     (`DiophantineConsistency.CurrentDummySafety2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentDummySafety2011" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
