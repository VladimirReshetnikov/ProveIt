from pathlib import Path
import json,hashlib
r=Path('/tmp/current-carry-to-mf');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();counts={}
for fname in ['fresh-baseline-records.json','fresh-final-records.json']:
 rows=json.loads((r/fname).read_text());counts[fname]=len(rows)
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']), (fname,x['module'],'source')
  assert h(x['log'])==x['log_sha256'] and h(x['object'])==x['object_sha256'] and not Path(x['object']).is_symlink(),(fname,x['module'],'output')
  for d in x['direct_inputs']:
   assert d['before']==d['after']==h(d['path']) and str(Path(d['path']).resolve())==d['resolved'],(fname,x['module'],d['module'],'object')
   if d['source']: assert d['source_before']==d['source_after']==h(d['source']),(fname,x['module'],d['module'],'source')
for phase in ['fresh-baseline','fresh-final']:
 for x in json.loads((r/(phase+'-probes.json')).read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and h(x['log'])==x['log_sha256']
  assert [h(p) for p in x['objects']]==x['objects_before']==x['objects_after']
c=json.loads((r/'comparison.json').read_text());assert len(c['names']['removed'])==6 and len(c['names']['added'])==1 and all(x.endswith('.facts_toMF') for x in c['names']['removed']) and c['names']['added'][0].endswith('.Facts.toMF');assert not c['interfaces']['changed_common'];assert not c['simp']['removed'] and not c['simp']['added'];assert not c['instances']['removed'] and not c['instances']['added']
print('Pinned source, direct inputs, logs, regular outputs and probe objects verified:',counts)
print('Comparison:',[(k,c[k]['baseline_count'],c[k]['final_count']) for k in ['names','interfaces','simp','instances']])

cc=json.loads((r/'client-comparison.json').read_text());assert not cc['client-names']['added'] and not cc['client-names']['removed'] and not cc['client-interfaces']['changed'] and not cc['client-interfaces']['added'] and not cc['client-interfaces']['removed']
for ph in ['fresh-baseline','fresh-final']:
 for x in json.loads((r/(ph+'-client-probes.json')).read_text()):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and h(x['log'])==x['log_sha256'] and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]
print('Client comparisons and pinned objects verified:',cc['client-interfaces']['baseline'])
