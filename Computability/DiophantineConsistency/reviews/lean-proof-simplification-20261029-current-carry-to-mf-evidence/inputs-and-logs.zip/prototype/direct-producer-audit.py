from pathlib import Path
import json,hashlib
r=Path('/tmp/current-carry-to-mf');rows=json.loads((r/'fresh-final-records.json').read_text());built={x['module'] for x in rows};external={d['module'].split('.')[-1]:{'source':d['source_before'],'object':d['before'],'resolved':d['resolved'],'matches':[]} for x in rows for d in x['direct_inputs'] if d['module'].split('.')[-1] not in built}
dirs=['carry-proof-sharing','carry-map-sharing','word-clause-sharing','word-copies-sharing','word-padding-sharing','word-origin-sharing','word-top-sharing','highmask-sharing','cell-construction-share','positive-shift-sharing/source-clean','construction-share','pell-construction-refresh','cell-weight-congruence','current-packing-positive-sharing','shared-box-prototype']
for dirname in dirs:
 for p in list(Path('/tmp',dirname).glob('*records*.json'))+([Path('/tmp/word-top-sharing/lowmask-record.json')] if dirname=='word-top-sharing' else []):
  try:rr=json.loads(p.read_text())
  except (ValueError,OSError):continue
  if isinstance(rr,dict):rr=[rr]
  if not isinstance(rr,list):continue
  for x in rr:
   if not isinstance(x,dict) or x.get('status')!=0:continue
   n=str(x.get('module') or x.get('name','')).split('.')[-1]
   if n not in external:continue
   a=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');b=x.get('after') or x.get('source_after') or x.get('source_sha256_after') or x.get('source_sha256');o=x.get('object_sha256') or x.get('output_sha256')
   if a==b==external[n]['source'] and o==external[n]['object']:external[n]['matches'].append(str(p))
(r/'direct-producer-audit.json').write_text(json.dumps(external,indent=2)+'\n')
for n,x in external.items():print(n,'matches',len(x['matches']),x['matches'][0] if x['matches'] else 'UNMATCHED',x['source'][:12] if x['source'] else '',x['object'][:12])
