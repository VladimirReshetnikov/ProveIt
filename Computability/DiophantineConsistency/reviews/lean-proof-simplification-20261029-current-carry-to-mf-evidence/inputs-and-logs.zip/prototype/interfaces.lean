import Lean.Elab.Command
import DiophantineConsistency.CurrentNativePacking2011
import DiophantineConsistency.CurrentDummySafety2011
import DiophantineConsistency.CurrentCarryConstruction2011Checks
import DiophantineConsistency.CurrentWordClause2011Checks
import DiophantineConsistency.CurrentWordPadding2011Checks
import DiophantineConsistency.CurrentWordTopBounds2011Checks
import DiophantineConsistency.CurrentWordCopies2011Checks
import DiophantineConsistency.CurrentWordOrigin2011Checks
import DiophantineConsistency.CurrentWordHighMask2011Checks
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.CurrentCarryConstruction2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentCarryConstruction2011" ||
     (`DiophantineConsistency.CurrentWordClause2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordClause2011" ||
     (`DiophantineConsistency.CurrentWordPadding2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordPadding2011" ||
     (`DiophantineConsistency.CurrentWordTopBounds2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordTopBounds2011" ||
     (`DiophantineConsistency.CurrentWordCopies2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordCopies2011" ||
     (`DiophantineConsistency.CurrentWordOrigin2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordOrigin2011" ||
     (`DiophantineConsistency.CurrentWordHighMask2011).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.CurrentWordHighMask2011" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
