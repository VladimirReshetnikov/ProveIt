import DiophantineConsistency.CurrentCellConstruction2011
import DiophantineConsistency.CurrentCellCoordinate2011
import DiophantineConsistency.WangTiles942Periodic

/-!
# Assembling the Boolean cyclic word from actual tile cells

The whole-word representative is divided by2011 to select the tile and
reduced modulo2011 to select its local field. The safe dummy and marker
maps are independently supplied. No high-mask, matching or carry theorem
is presumed by this assembly.
-/

namespace DiophantineConsistency.CurrentWordConstruction2011

open WangTiles942 CurrentMasks2011 CurrentCellLabels2011 CurrentCellConstruction2011
open CurrentCellTranslation2011 CurrentCellCycle2011 CurrentCellCoordinate2011

set_option Elab.async false
set_option maxRecDepth 10000

variable {N : ℕ} [NeZero N]

theorem wordLength_pos : 0 < N*2011 := Nat.mul_pos (NeZero.pos N) (by decide)

/-- The physical base of a canonical cell coordinate. -/
def base (j : ZMod N) : ZMod (N*2011) := ((j.val*2011 : ℕ) : ZMod (N*2011))

/-- The actual assembled digit function, with two separate control slots. -/
def word (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (k : ZMod (N*2011)) : ℕ :=
  let j : ZMod N := ((k.val/2011 : ℕ) : ZMod N)
  let e := k.val%2011
  if e = 977 then dummy j else if e = 1004 then marker j else localDigit (a j) e

omit [NeZero N] in
theorem word_boolean (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (hd : ∀ j, dummy j ≤ 1) (hm : ∀ j, marker j ≤ 1) (k : ZMod (N*2011)) :
    word a dummy marker k ≤ 1 := by
  unfold word
  dsimp only
  split_ifs <;> first | exact hd _ | exact hm _ | exact localDigit_boolean _ _

omit [NeZero N] in
theorem word_support (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (k : ZMod (N*2011)) (hk : k.val%2011 ∉ lowSupport) : word a dummy marker k = 0 := by
  have hd : k.val%2011 ≠ 977 := by
    intro h
    apply hk
    rw [h]
    simp only [lowSupport_def,Finset.mem_union,Finset.mem_range,Finset.mem_Ico,
      Finset.mem_singleton]
    omega
  have hm : k.val%2011 ≠ 1004 := by
    intro h
    apply hk
    rw [h]
    simp only [lowSupport_def,Finset.mem_union,Finset.mem_singleton,or_true]
  simp only [word,if_neg hd,if_neg hm]
  exact localDigit_support _ _ hk

/-- No field inside a canonical cell crosses the full cyclic representative
boundary, including the last cell and the single-cell modulus. -/
theorem base_add_val (j : ZMod N) (e : ℕ) (he : e < 2011) :
    (base j+(e : ZMod (N*2011))).val = j.val*2011+e := by
  have hj := ZMod.val_lt j
  unfold base
  rw [← Nat.cast_add, ZMod.val_natCast_of_lt (by omega : j.val*2011+e < N*2011)]

theorem base_add_field (j : ZMod N) (e : ℕ) (he : e < 2011) :
    (base j+(e : ZMod (N*2011))).val%2011 = e := by
  rw [base_add_val j e he]
  omega

theorem base_add_index (j : ZMod N) (e : ℕ) (he : e < 2011) :
    (((base j+(e : ZMod (N*2011))).val/2011 : ℕ) : ZMod N) = j := by
  rw [base_add_val j e he]
  have hdiv : (j.val*2011+e)/2011 = j.val := by omega
  rw [hdiv,ZMod.natCast_zmod_val]

theorem word_at_base (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (j : ZMod N) (e : ℕ) (he : e < 2011) :
    word a dummy marker (base j+(e : ZMod (N*2011))) =
      if e = 977 then dummy j else if e = 1004 then marker j else localDigit (a j) e := by
  simp only [word,base_add_field j e he,base_add_index j e he]

/-- Scaling the modulus and the representative together handles arbitrarily
many whole periods; no coprimality assumption is involved. -/
theorem base_natCast (m : ℕ) : base (m : ZMod N) = ((m*2011 : ℕ) : ZMod (N*2011)) := by
  unfold base
  apply (scaled_cast_eq_iff (N := N) (m : ZMod N).val m).mpr
  exact ZMod.natCast_zmod_val _

theorem word_at_nat_base (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (m e : ℕ) (he : e < 2011) :
    word a dummy marker ((m*2011+e : ℕ) : ZMod (N*2011)) =
      if e = 977 then dummy (m : ZMod N)
      else if e = 1004 then marker (m : ZMod N) else localDigit (a (m : ZMod N)) e := by
  rw [Nat.cast_add,← base_natCast m]
  exact word_at_base a dummy marker _ e he

theorem word_data (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (j : ZMod N) (e : ℕ) (he : e < 986) (hd : e ≠ 977) :
    word a dummy marker (base j+(e : ZMod (N*2011))) = localDigit (a j) e := by
  rw [word_at_base a dummy marker j e (by omega),if_neg hd,
    if_neg (show e ≠ 1004 by omega)]

theorem word_dummy (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ) (j : ZMod N) :
    word a dummy marker (base j+977) = dummy j := by
  simpa only [ite_true,Nat.cast_ofNat] using word_at_base a dummy marker j 977 (by decide)

theorem word_marker (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ) (j : ZMod N) :
    word a dummy marker (base j+1004) = marker j := by
  simpa only [show (1004 : ℕ) ≠ 977 by decide,ite_false,ite_true,Nat.cast_ofNat] using
    word_at_base a dummy marker j 1004 (by decide)

theorem word_selected (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ) (j : ZMod N) :
    Selected (selectorValue (word a dummy marker) (base j)) (a j) :=
  selected_of_local _ _ _ (word_data a dummy marker j)

theorem word_copiedWord (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ) (j : ZMod N) :
    copiedWord (word a dummy marker) (base j) = complementedTile (a j) :=
  copiedWord_of_local _ _ _ (word_data a dummy marker j)

theorem word_selectorPayload (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (j : ZMod N) : selectorPayload (word a dummy marker) (base j) = 1+packedTile (tile (a j)) :=
  selectorPayload_of_local _ _ _ (word_data a dummy marker j)

theorem word_selectorCount (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (j : ZMod N) : CurrentClause2011.selectorCount (word a dummy marker) (base j) = 1 := by
  change (∑ i : Fin 942, selectorValue (word a dummy marker) (base j) i) = 1
  simpa only [one_mul] using (word_selected a dummy marker j).weighted_sum (fun _ => 1)

/-- The same base as the established aligned-cell coordinate, exactly. -/
theorem base_eq_coordinate (j : ZMod N) :
    base j = ((coordinate.symm j : Cell N) : ZMod (N*2011)) :=
  (coe_coordinate_symm j).symm

theorem base_coordinate (b : Cell N) : base (coordinate b) = (b : ZMod (N*2011)) := by
  rw [base_eq_coordinate,Equiv.symm_apply_apply]

theorem word_at_cell (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (b : Cell N) (e : ℕ) (he : e < 2011) :
    word a dummy marker ((b : ZMod (N*2011))+(e : ZMod (N*2011))) =
      if e = 977 then dummy (coordinate b)
      else if e = 1004 then marker (coordinate b) else localDigit (a (coordinate b)) e := by
  simpa only [base_coordinate] using word_at_base a dummy marker (coordinate b) e he

theorem word_cell_data (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ) (b : Cell N) :
    Selected (selectorValue (word a dummy marker) b) (a (coordinate b)) ∧
    copiedWord (word a dummy marker) b = complementedTile (a (coordinate b)) ∧
    selectorPayload (word a dummy marker) b = 1+packedTile (tile (a (coordinate b))) := by
  simpa only [base_coordinate] using
    And.intro (word_selected a dummy marker (coordinate b))
      (And.intro (word_copiedWord a dummy marker (coordinate b))
        (word_selectorPayload a dummy marker (coordinate b)))

theorem word_origin (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ) :
    word a dummy marker 0 = if a 0 = 0 then 1 else 0 := by
  have h := word_at_base a dummy marker 0 0 (by decide)
  simpa only [base,ZMod.val_zero,Nat.zero_mul,Nat.cast_zero,add_zero,
    show ¬ (0 : ℕ) = 977 by decide,show ¬ (0 : ℕ) = 1004 by decide,
    ite_false,localDigit_origin] using h

theorem word_origin_of_marked (a : ZMod N → Fin 942) (dummy marker : ZMod N → ℕ)
    (s : ℤ) (h : WangTiles942Periodic.MarkedWord N s a) : word a dummy marker 0 = 1 := by
  rw [word_origin,h.start_at_zero]
  rfl

/-- A separately defined candidate marker map, with its sign explicit.
No temporal-copy orientation theorem is asserted here. -/
def shiftedStartMarker (a : ZMod N → Fin 942) (stride : ZMod N) (j : ZMod N) : ℕ :=
  (decide (a (j+stride) = 0)).toNat

omit [NeZero N] in
theorem shiftedStartMarker_boolean (a : ZMod N → Fin 942) (stride j : ZMod N) :
    shiftedStartMarker a stride j ≤ 1 := by
  have hb (b : Bool) : b.toNat ≤ 1 := by cases b <;> decide
  exact hb _

omit [NeZero N] in
theorem shiftedStartMarker_eq_one (a : ZMod N → Fin 942) (stride j : ZMod N) :
    shiftedStartMarker a stride j = 1 ↔ a (j+stride) = 0 := by
  simp only [shiftedStartMarker,Bool.toNat_eq_one,decide_eq_true_eq]

end DiophantineConsistency.CurrentWordConstruction2011
