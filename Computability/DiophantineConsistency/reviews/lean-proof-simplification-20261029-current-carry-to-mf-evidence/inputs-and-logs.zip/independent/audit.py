from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/current-carry-to-mf');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def gitfile(rev,n):
 rel=f'Computability/DiophantineConsistency/Lean/DiophantineConsistency/{n}.lean';return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
words=['CurrentWordClause2011','CurrentWordPadding2011','CurrentWordTopBounds2011','CurrentWordCopies2011','CurrentWordOrigin2011','CurrentWordHighMask2011'];changed=['CurrentCarryConstruction2011']+words
private='''private theorem facts_toMF {n : ℕ} [NeZero n] (c : ZMod n → ℕ) (W : ℕ)
    (k digits : ZMod n → ℕ) (hf : CurrentCarryConstruction2011.Facts c W k digits) :
    MF.CurrentCarryConstruction2011.Facts c W k digits :=
  ⟨hf.carry_bound, hf.digit_bound, hf.recurrence, hf.decomposition, hf.word_bound, hf.transport⟩

'''
for n in words:
 b=(R/'fresh-baseline/DiophantineConsistency'/f'{n}.lean').read_text();f=(R/'fresh-final/DiophantineConsistency'/f'{n}.lean').read_text();assert b.count(private)==1 and b.replace(private,'').replace('(facts_toMF _ _ _ _ hf)','(hf.toMF)')==f and gitfile('e8e12903c2^',n)==b and gitfile('e8e12903c2',n)==f and (W/(n+'.lean')).read_text()==f;print('PASS exact helper removal/use and commit/parent',n)
n=changed[0];b=(R/'fresh-baseline/DiophantineConsistency'/f'{n}.lean').read_text();f=(R/'fresh-final/DiophantineConsistency'/f'{n}.lean').read_text();marker='/-- Every Boolean word has an actual bounded normalization, even at a\n';helper='''/-- View a carry construction through the shared mathematical foundation interface. -/
theorem Facts.toMF {c k digits : ZMod n → ℕ} {W : ℕ}
    (h : Facts c W k digits) : MF.CurrentCarryConstruction2011.Facts c W k digits :=
  ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition, h.word_bound, h.transport⟩

''';old='''  have hmf : MF.CurrentCarryConstruction2011.Facts c W k digits :=
    ⟨h.carry_bound, h.digit_bound, h.recurrence, h.decomposition,
      h.word_bound, h.transport⟩
  exact hmf.word_lt i hi''';assert b.count(marker)==b.count(old)==1 and b.replace(marker,helper+marker).replace(old,'  exact h.toMF.word_lt i hi')==f and gitfile('e8e12903c2^',n)==b and gitfile('e8e12903c2',n)==f and (W/(n+'.lean')).read_text()==f;print('PASS public helper, inline conversion and commit/parent')
search=read(R/'direct-client-search.json')
for n in changed:
 rows=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.'+n+'$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(rows)==sorted(search[n]),(n,rows,search[n])
print('PASS scoped tracked Lean direct import graph; umbrella identified')
rec={}
for phase in ('fresh-baseline','fresh-final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert len(rows)==len(rec[phase])==18
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module'] not in changed:assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d.get('source_before') is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n in rec[phase]:assert d['before']==rec[phase][n]['object_sha256']
  print('PASS build',phase,x['module'],x['time'].strip())
 for n in changed:
  for client in search[n]:
   if client.endswith('/DiophantineConsistency.lean'):continue
   assert Path(client).stem in rec[phase],client
print('PASS all scoped non-umbrella direct clients included')
for phase in ('fresh-baseline','fresh-final'):
 for kind in ('probes','client-probes'):
  rows=read(R/f'{phase}-{kind}.json');assert len(rows)==(4 if kind=='probes' else 2)
  for x in rows:
   assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][Path(p).stem]['object_sha256'] for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
def blocks(p):return {t.split(' TYPE ',1)[0]:'DECL '+t for t in re.split(r'(?m)^DECL ',Path(p).read_text())[1:]}
a=blocks(R/'fresh-baseline-interfaces.log');z=blocks(R/'fresh-final-interfaces.log');removed=set(a)-set(z);added=set(z)-set(a);assert len(removed)==6 and all(n.endswith('.facts_toMF') for n in removed) and added=={'DiophantineConsistency.CurrentCarryConstruction2011.Facts.toMF'} and len(set(a)&set(z))==90 and all(a[n]==z[n] for n in set(a)&set(z))
assert 'AXIOMS [propext, Classical.choice, Quot.sound]' in z[next(iter(added))]
for n in ('simp','instances','client-names','client-interfaces'):assert (R/f'fresh-baseline-{n}.log').read_bytes()==(R/f'fresh-final-{n}.log').read_bytes()
for n in ('simp','instances'):assert all(q not in (R/f'fresh-baseline-{n}.log').read_text() and q not in (R/f'fresh-final-{n}.log').read_text() for q in removed|added)
print('PASS 18-object-pinned target/client census; six private names removed, public Facts.toMF added, 90 common blocks')
for n in ('CurrentWordScalarWitness2011','CurrentDummySafety2011'):assert rec['fresh-baseline'][n]['object_sha256']!=rec['fresh-final'][n]['object_sha256']
for n in ('CurrentCarryConstruction2011Checks','CurrentWordClause2011Checks','CurrentWordPadding2011Checks','CurrentWordTopBounds2011Checks','CurrentWordCopies2011Checks','CurrentWordOrigin2011Checks','CurrentWordHighMask2011Checks','CurrentNativePacking2011','CurrentDummyMutation2011'):assert rec['fresh-baseline'][n]['object_sha256']==rec['fresh-final'][n]['object_sha256']
print('PASS two differing client objects and nine unchanged output pairs')
producers=read(R/'direct-producer-audit.json');external={}
for phase in ('fresh-baseline','fresh-final'):
 for x in rec[phase].values():
  for d in x['direct_inputs']:
   n=d['module'].split('.')[-1]
   if n not in rec[phase]:
    assert n in producers and d['source_before']==producers[n]['source'] and d['before']==producers[n]['object']
    external[n]=producers[n]
assert len(external)==len(producers)==15
unmatched={n for n,v in producers.items() if not v['matches']};assert unmatched=={'WangTiles942PowerDimensions','NativeRankVariation'}
for n,v in producers.items():
 assert v['source']==h(W/(n+'.lean')) and v['object']==h(v['resolved'])
 if n in unmatched:print('UNMATCHED direct cached pair',n,v['source'],v['object']);continue
 found=False
 for path in v['matches']:
  rows=read(path);rows=rows if isinstance(rows,list) else [rows]
  for x in rows:
   if not isinstance(x,dict) or x.get('status')!=0 or (x.get('module') or x.get('name','')).split('.')[-1]!=n:continue
   a=x.get('before') or x.get('source_before') or x.get('source_sha256') or x.get('source_sha256_before');z=x.get('after') or x.get('source_after') or x.get('source_sha256_after') or x.get('source_sha256');obj=x.get('object_sha256') or x.get('output_sha256')
   if a==z==v['source'] and obj==v['object']:found=True;break
  if found:break
 assert found,n;print('PASS prior successful direct producer pair',n)
print('PASS 13 authenticated external pairs; two source/object samples lack producer receipt')
old=read(R/'final-records.json');assert len(old)==17 and all(x['status']==0 for x in old) and old[-1]['module']=='CurrentDummyMutation2011'
x=next(x for x in old if x['module']=='CurrentCarryConstruction2011');d=next(d for d in x['direct_inputs'] if d['module'].endswith('.MFCurrentCarryConstruction2011'));oldproducer=next(x for x in read('/tmp/carry-proof-sharing/phase-records.json') if x.get('object_sha256')==d['before']);assert oldproducer['status']==0 and oldproducer['source_sha256']==oldproducer['source_after']=='676d672df0384b5354225dc42de0025fb95c27cf48e41fccad0f0419a806699e' and d['source_before']=='8e05befc70df6f325915a9a4d83a06f0f88f751511387bbe6e2bdd77126b2252'
print('PASS 17-row preliminary lane has historical stale MF producer; interrupted DummySafety has no completed row')
