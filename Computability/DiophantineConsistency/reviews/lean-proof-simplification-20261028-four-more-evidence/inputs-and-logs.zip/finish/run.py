from pathlib import Path
import subprocess,time,json,hashlib,sys
p=Path('/tmp/finish-proof-20261028'); pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; mode=sys.argv[1]
items=[('target',pre+'WangTiles942FinishConstruction.lean',True),('axioms',str(p/'axioms.lean'),False)]
if mode=='final': items += [('focus',pre+'WangTiles942FinishConstructionChecks.lean',False),('client',pre+'WangTiles942TraceCycle.lean',False)]
records=[]
for name,source,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj: argv+=['-o',str(p/'overlay/DiophantineConsistency/WangTiles942FinishConstruction.olean')]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/finish-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic(); r=subprocess.run(cmd,capture_output=True); elapsed=time.monotonic()-start
 log=p/(mode+'-'+name+'.log'); log.write_bytes(r.stdout+r.stderr)
 records.append({'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode: raise SystemExit(r.returncode)
