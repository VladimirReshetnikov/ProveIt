from pathlib import Path
import sys,subprocess,time,hashlib,json
p=Path('/tmp/omega-semiring-proof-20261028'); phase=sys.argv[1]; prefix='Computability/DiophantineConsistency/Lean/'; out=p/'overlay/DiophantineConsistency'
source=prefix+'DiophantineConsistency/'
items=[('target',source+'ObjectOmegaSemiring.lean',out/'ObjectOmegaSemiring.olean')]
if phase=='final':
 items += [(n,source+n+'.lean',out/(n+'.olean')) for n in ['ObjectNaturalSemiring','ObjectNaturalOrder','ObjectNaturalZero']]
 items += [('focus',prefix+'checks/ObjectOmegaSemiring.lean',None)]
items += [('audit',str(p/'audit.lean'),None)]
records=[]
for tag,src,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',src]
 if obj: argv+=['-o',str(obj)]
 cmd=['lake','env','bash','-c',f'export LEAN_PATH="{p}/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic(); proc=subprocess.run(cmd,capture_output=True); duration=time.monotonic()-start
 log=p/(phase+'-'+tag+'.log'); log.write_bytes(proc.stdout+proc.stderr)
 records.append({'tag':tag,'command':cmd,'exit_status':proc.returncode,'elapsed_seconds':duration,'source':src,'source_sha256':hashlib.sha256(Path(src).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'log_bytes':log.stat().st_size})
 (p/(phase+'-results.json')).write_text(json.dumps({'records':records},indent=2)+'\n')
 if proc.returncode: raise SystemExit(proc.returncode)
