from pathlib import Path
import subprocess,sys,time,json,hashlib
base=Path('/tmp/tile-colors-20261028'); overlay=base/'overlay/DiophantineConsistency'; src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); mode=sys.argv[1]
prep=['CurrentSelectorTail2011','CurrentEarlyPadding2011','CurrentOneHot2011','CurrentCellLabels2011','CurrentDecodedWindow2011','CurrentSouthShift2011','CurrentWholeField2011','CurrentAdjacency2011','CurrentOccupation2011']
if mode=='baseline': items=[(x,str(src/(x+'.lean')),True) for x in prep]+[('target',str(src/'CurrentTileColors2011.lean'),True),('axioms',str(base/'axioms.lean'),False)]
elif mode=='final': items=[(x,str(src/(x+'.lean')),True) for x in ['CurrentCellCycle2011','CurrentOccupation2011','CurrentCellCoordinate2011']]+[('target',str(src/'CurrentTileColors2011.lean'),True),('client',str(src/'CurrentMarkedWindow2011.lean'),False),('focus',str(src/'CurrentTileColors2011Checks.lean'),False),('axioms',str(base/'axioms.lean'),False)]
else:raise SystemExit('unknown mode')
records=[]
for tag,path,obj in items:
 output=overlay/((tag if tag!='target' else 'CurrentTileColors2011')+'.olean')
 if obj and output.is_symlink():output.unlink()
 argv=['lake','env','bash','-c','export LEAN_PATH="/tmp/tile-colors-20261028/overlay:$LEAN_PATH"; exec "$@"','bash','lean','-M6000','-j1','-DElab.async=false',path]
 if obj:argv.extend(['-o',str(output)])
 start=time.monotonic(); r=subprocess.run(argv,capture_output=True); seconds=time.monotonic()-start
 log=base/(mode+'-'+tag+'.log'); log.write_bytes(r.stdout+r.stderr)
 h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
 record={'tag':tag,'argv':argv,'exit':r.returncode,'seconds':seconds,'source':path,'source_sha256':h(path),'log':str(log),'log_sha256':h(log),'log_bytes':log.stat().st_size}
 if obj and output.exists():record.update({'object':str(output),'object_sha256':h(output),'object_bytes':output.stat().st_size})
 records.append(record); (base/(mode+'-commands.json')).write_text(json.dumps(records,indent=2)+'\n')
 print(mode,tag,'exit',r.returncode,'elapsed',round(seconds,2),flush=True)
 if r.returncode:sys.exit(r.returncode)
