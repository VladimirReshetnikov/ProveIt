from pathlib import Path
import sys,subprocess,time,json,hashlib
out=Path('/tmp/cell-cycle-20261028'); mode=sys.argv[1]; pref='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
items=[('target',pref+'CurrentCellCycle2011.lean',True),('axioms',str(out/'axioms.lean'),False)]
if mode=='final':items=[('target',pref+'CurrentCellCycle2011.lean',True)]+[(n,pref+n+'.lean',False) for n in ['CurrentCellCoordinate2011','CurrentOccupation2011','CurrentCellCycle2011Checks']]+[('axioms',str(out/'axioms.lean'),False)]
records=[]
for name,source,obj in items:
 cmd=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:cmd+=['-o',str(out/'overlay/DiophantineConsistency/CurrentCellCycle2011.olean')]
 argv=['lake','env','bash','-c','export LEAN_PATH="/tmp/cell-cycle-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*cmd]
 start=time.monotonic(); cp=subprocess.run(argv,capture_output=True); log=out/(mode+'-'+name+'.log');log.write_bytes(cp.stdout+cp.stderr)
 records.append({'name':name,'argv':argv,'status':cp.returncode,'seconds':time.monotonic()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}); (out/(mode+'-records.json')).write_text(json.dumps(records,indent=2)+'\n')
 if cp.returncode:sys.exit(cp.returncode)
