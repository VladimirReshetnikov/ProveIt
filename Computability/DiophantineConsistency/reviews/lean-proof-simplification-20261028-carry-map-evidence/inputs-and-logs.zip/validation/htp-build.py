import pathlib,os,subprocess,json,hashlib,time,sys
P=pathlib.Path;r=P('/tmp/carry-map-sharing');ov=r/'htp';base=P('/tmp/quartic-gates/shared/Diophantine');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[]
for p in base.rglob('*.olean'):
 q=ov/'Diophantine'/p.relative_to(base);q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(p.resolve())
env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+env.get('LEAN_PATH','');sr=P('Computability/HilbertTenthProblem/Lean')
for n in ['Master2','Master3','Packing']:
 src=sr/'Diophantine/Paper1982'/(n+'.lean');out=ov/'Diophantine/Paper1982'/(n+'.olean');out.unlink(missing_ok=True);log=r/('htp-'+n+'.log');tm=r/('htp-'+n+'.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(sr),str(src),'-o',str(out)];t=time.monotonic();pre=sha(src)
 with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 x={'module':'Diophantine.Paper1982.'+n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':sha(src),'log_sha256':sha(log),'time_sha256':sha(tm)}
 if out.exists():x.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
 rec.append(x);(r/'htp-builds.json').write_text(json.dumps(rec,indent=2)+'\n');print(n,v.returncode,round(x['seconds'],2),flush=True)
 if v.returncode or pre!=sha(src):sys.exit(1)
