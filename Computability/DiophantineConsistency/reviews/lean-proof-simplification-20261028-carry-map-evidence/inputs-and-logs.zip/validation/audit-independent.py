import pathlib,json,hashlib,subprocess,re
P=pathlib.Path;R=P('/tmp/carry-map-sharing');H=lambda p:hashlib.sha256(P(p).read_bytes()).hexdigest(); failures=[]
def check(ok,msg):
 if not ok:failures.append(msg)
records=json.loads((R/'coherent-phases.json').read_text());check(len(records)==20,'record count')
for v in records:
 phase,job,cmd=v['phase'],v['job'],v['cmd'];p=R/('coherent-'+phase+'-'+job+'.log');check(v['status']==0,f'{phase} {job} status');check(v['lean_path'].split(':')[0]==str(R/(phase+'-coherent')),f'{phase} {job} lean path')
 ins=[P(a) for a in cmd if a.endswith('.lean') and P(a).is_file()];check(len(ins)==1,f'{phase} {job} source list {ins}')
 if len(ins)==1:check(H(ins[0])==v['source_sha256'],f'{phase} {job} source hash')
 check(p.exists() and H(p)==v['log_sha256'],f'{phase} {job} log hash')
 if '-o' in cmd:
  o=P(cmd[len(cmd)-1-cmd[::-1].index('-o')+1]);check(o.exists() and H(o)==v['object_sha256'],f'{phase} {job} object hash')
 if 'time_sha256' in v:
  p=P(cmd[cmd.index('-o')-1]) if False else P(cmd[3]);check(p.exists() and H(p)==v['time_sha256'],f'{phase} {job} time hash')
for n in ['MultiTargetCarry','SparseBorrowCarry']:
 base=R/'baseline-src/DiophantineConsistency'/(n+'.lean');final=R/'final-src/DiophantineConsistency'/(n+'.lean');working=P('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean')
 old=subprocess.check_output(['git','show','HEAD:'+str(working)]);check(base.read_bytes()==old,n+' baseline HEAD');check(final.read_bytes()==working.read_bytes(),n+' final working')
 for suffix in ['axioms','check']:
  a=(R/f'coherent-baseline-{n}-{suffix}.log').read_bytes();b=(R/f'coherent-final-{n}-{suffix}.log').read_bytes();check(a==b,n+' '+suffix+' logs')
 for phase in ['baseline','final']:
  check((R/f'coherent-{phase}-{n}.log').read_bytes()==b'',n+' target warning '+phase)
 # check public declarations in baseline original, exclude private and instance absent
 s=base.read_text(); decl=re.findall(r'^(?:noncomputable\s+)?(?:theorem|lemma|def|abbrev|structure|inductive|instance)\s+(\w+)',s,re.M)
 txt=(R/(n+'-axioms.lean')).read_text();reported=set(re.findall(r'^#print axioms \S+\.([A-Za-z][A-Za-z0-9_]*)$',txt,re.M));missing=(set(decl)-{'never'})-reported;check(not missing,n+' missing named '+str(missing)); print(n,'public named',len(decl),'reported generated',len(re.findall(r'^#print axioms .*\.eq_\d+',txt,re.M)))
# Verify all selected graph source/object pairs and parsed import edges against snapshots for edited sources.
graph=json.loads((R/'dependency-graph-before.json').read_text())
for n,v in graph.items():
 source=P(v['source']);actual=R/'baseline-src/DiophantineConsistency'/(n.split('.')[-1]+'.lean') if n in ['DiophantineConsistency.MultiTargetCarry','DiophantineConsistency.SparseBorrowCarry'] else source
 check(actual.exists() and H(actual)==v['source_sha256'],n+' graph source hash');check(P(v['object']).exists() and H(v['object'])==v['object_sha256'],n+' graph object hash')
 imports=[]
 for line in actual.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:imports.extend(m.group(1).split())
 check(imports==v['imports'],n+' import mismatch '+str((imports,v['imports'])))
for v in json.loads((R/'dependency-audit.json').read_text()):check(v['matching_receipts'] and v['source_match'] and v['object_match'],v['module']+' audit failure')
# Current source/object matches fresh build receipts.
for fn in ['htp-builds.json','bridge-builds.json']:
 for v in json.loads((R/fn).read_text()):
  cmd=v['command'];src=[P(a) for a in cmd if a.endswith('.lean') and P(a).exists()];o=P(cmd[len(cmd)-1-cmd[::-1].index('-o')+1]);check(v['status']==0,v['module']+' status');check(len(src)==1 and H(src[0])==v['source_sha256'],v['module']+' src');check(o.exists() and H(o)==v['object_sha256'],v['module']+' obj')
  name=v['module'].split('.')[-1];prefix='htp-' if fn=='htp-builds.json' else 'bridge-';p=R/(prefix+name+'.log');tm=R/(prefix+name+'.time');check(H(p)==v['log_sha256'] and H(tm)==v['time_sha256'],v['module']+' log/time')
print('records',len(records),'graph',len(graph),'dependency receipts',len(json.loads((R/'dependency-audit.json').read_text())))
print('FAILURES:',failures)
if failures:raise SystemExit(1)
