import os,pathlib,subprocess,json,hashlib,time,sys
P=pathlib.Path;root=P('/tmp/carry-map-sharing');prior=P('/tmp/encoded-degree-reuse/final/DiophantineConsistency');repo=P('Computability/DiophantineConsistency/Lean');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rs=[]
for phase in ('baseline','final'):
 overlay=root/(phase+'-fresh');ns=overlay/'DiophantineConsistency';ns.mkdir(parents=True,exist_ok=True)
 for p in prior.glob('*.olean'):(ns/p.name).symlink_to(p.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+str(root/'htp')+':'+env.get('LEAN_PATH','');srcroot=root/(phase+'-src')
 jobs=[('MultiTargetCarry',srcroot/'DiophantineConsistency/MultiTargetCarry.lean',srcroot),('SparseBorrowCarry',srcroot/'DiophantineConsistency/SparseBorrowCarry.lean',srcroot),('SelectiveCarry',repo/'DiophantineConsistency/SelectiveCarry.lean',repo),('SplitCarry',repo/'DiophantineConsistency/SplitCarry.lean',repo)]
 for name,src,sr in jobs:
  out=ns/(name+'.olean');out.unlink(missing_ok=True);log=root/('fresh-'+phase+'-'+name+'.log');tm=root/('fresh-'+phase+'-'+name+'.time');cmd=['/usr/bin/time','-v','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(sr),str(src),'-o',str(out)];t=time.monotonic();pre=sha(src)
  with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  rec={'phase':phase,'job':name,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':pre,'source_after':sha(src),'log_sha256':sha(log),'time_sha256':sha(tm)}
  if out.exists():rec.update(object_sha256=sha(out),object_bytes=out.stat().st_size)
  rs.append(rec);(root/'fresh-phases.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,name,v.returncode,round(rec['seconds'],2),flush=True)
  if v.returncode or pre!=sha(src):sys.exit(1)
 for name in ['MultiTargetCarry','SparseBorrowCarry']:
  probe=root/(name+'-axioms.lean');log=root/('fresh-'+phase+'-'+name+'-axioms.log');cmd=['lean','-M6000','-j1','-DElab.async=false',str(probe)];t=time.monotonic()
  with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  rs.append({'phase':phase,'job':name+'-axioms','cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':sha(probe),'log_sha256':sha(log)});(root/'fresh-phases.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,name,'axioms',v.returncode,flush=True)
  if v.returncode:sys.exit(v.returncode)
 for name in ['MultiTargetCarry','SparseBorrowCarry']:
  src=repo/'checks'/(name+'.lean');log=root/('fresh-'+phase+'-'+name+'-check.log');cmd=['lean','-M6000','-j1','-DElab.async=false',str(src)];t=time.monotonic()
  with log.open('wb') as f:v=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  rs.append({'phase':phase,'job':name+'-check','cmd':cmd,'lean_path':env['LEAN_PATH'],'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':sha(src),'log_sha256':sha(log)});(root/'fresh-phases.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,name,'check',v.returncode,flush=True)
  if v.returncode:sys.exit(v.returncode)
for n in ['MultiTargetCarry','SparseBorrowCarry']:
 if (root/('fresh-baseline-'+n+'-axioms.log')).read_bytes()!=(root/('fresh-final-'+n+'-axioms.log')).read_bytes():sys.exit('axioms differ: '+n)
print('all public axioms match',flush=True)
