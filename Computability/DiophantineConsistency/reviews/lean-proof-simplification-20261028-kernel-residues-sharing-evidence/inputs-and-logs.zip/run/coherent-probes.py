from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/kernel-residues-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();tags=os.environ.get('KERNEL_PROBES','names').split(',');rs=[]
for ph in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(p/('coherent-'+ph))+':'+lp
 for tag in tags:
  src=p/(tag+'.lean');log=p/f'coherent-{ph}-{tag}.log';tm=p/f'coherent-{ph}-{tag}.time';before=h(src);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];t=time.monotonic()
  with log.open('wb') as f:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  x={'phase':ph,'tag':tag,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,2)};rs.append(x);(p/('coherent-probes-'+tags[0]+'.json')).write_text(json.dumps(rs,indent=2)+'\n');print(ph,tag,rc,flush=True)
  if rc or before!=x['source_after']:raise SystemExit(1)
