from pathlib import Path
import os,subprocess,time,json,hashlib
p=Path('/tmp/kernel-residues-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();path=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ('baseline','final'):
 for name in ('CurrentKernelResidues2011','CurrentKernelResidues2011Checks','CurrentControllerUnits2011'):
  root=p/phase;f=(root/'DiophantineConsistency'/f'{name}.lean') if name=='CurrentKernelResidues2011' else Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/f'{name}.lean';out=root/'DiophantineConsistency'/f'{name}.olean';out.unlink(missing_ok=True)
  log=p/f'{phase}-{name}.log';tm=p/f'{phase}-{name}.time';env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+path
  srcroot=str(root) if name=='CurrentKernelResidues2011' else 'Computability/DiophantineConsistency/Lean';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',srcroot,str(f),'-o',str(out)];before=h(f)
  with log.open('wb') as dest:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=dest,stderr=subprocess.STDOUT).returncode
  rec={'phase':phase,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source_sha256':before,'source_after':h(f),'object_sha256':h(out) if out.exists() else None,'object_bytes':out.stat().st_size if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,3)};records.append(rec);(p/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,rc,flush=True)
  if rc or rec['source_sha256']!=rec['source_after']:raise SystemExit(1)
