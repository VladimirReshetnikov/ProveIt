import DiophantineConsistency.CurrentKernelResidues2011
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.CurrentKernelResidues2011).isPrefixOf n then
      logInfo m!"{n}"
