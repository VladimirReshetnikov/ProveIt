from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/tmp/kernel-residues-sharing');g=json.loads((p/'graph.json').read_text());inv=json.loads((p/'coherent-inventory.json').read_text());h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();repo=Path.cwd()/'Computability/DiophantineConsistency/Lean';rs=[]
for ph in ('baseline','final'):
 ov=p/('coherent-'+ph);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+lp;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def find(n):
  for r in roots:
   q=r/(n.replace('.','/')+'.olean')
   if q.is_file():return q
  raise RuntimeError('missing '+n)
 for name in ('CurrentKernelResidues2011','CurrentKernelResidues2011Checks','CurrentControllerUnits2011'):
  assert shutil.disk_usage('.').free>850*1024*1024,'disk reserve'
  src=(p/ph/'DiophantineConsistency'/f'{name}.lean') if name=='CurrentKernelResidues2011' else repo/'DiophantineConsistency'/f'{name}.lean';root=p/ph if name=='CurrentKernelResidues2011' else repo
  local=[]
  for n,x in inv['local'].items():
   q=find(n);assert h(x['source'])==x['source_sha256'] and h(q)==x['object_sha256'],(ph,name,n);local.append({'module':n,'source':x['source'],'source_sha256':x['source_sha256'],'object':str(q),'object_sha256':h(q)})
  external=[]
  for n,x in inv['external'].items():
   q=find(n);assert h(q)==x['object_sha256'],(ph,name,n);external.append({'module':n,'object':str(q),'object_sha256':h(q)})
  direct=[]
  for n in [x for l in src.read_text().splitlines() if l.startswith('import ') for x in l.split()[1:]]:
   q=find(n);direct.append({'module':n,'path':str(q),'resolved_path':str(q.resolve()),'sha256':h(q)})
  out=ov/'DiophantineConsistency'/f'{name}.olean';out.unlink(missing_ok=True);log=p/f'coherent-{ph}-{name}.log';tm=p/f'coherent-{ph}-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];before=h(src);t=time.monotonic()
  with log.open('wb') as f:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  for x in local:x['source_after']=h(x['source']);x['object_after']=h(x['object'])
  for x in external:x['object_after']=h(x['object'])
  for x in direct:x['after_sha256']=h(x['path'])
  rec={'phase':ph,'name':name,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'timing':tm.read_text().strip(),'elapsed':round(time.monotonic()-t,2),'local_pins':local,'external_pins':external,'direct_inputs':direct};rs.append(rec);(p/'coherent-phase-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(ph,name,rc,rec['elapsed'],flush=True)
  if rc or rec['source_after']!=before or any(x['source_after']!=x['source_sha256'] or x['object_after']!=x['object_sha256'] for x in local) or any(x['object_after']!=x['object_sha256'] for x in external) or any(x['after_sha256']!=x['sha256'] for x in direct):raise SystemExit(1)
print('both pinned target/client chains passed')
