from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
p=Path('/tmp/kernel-residues-sharing');g=json.loads((p/'graph.json').read_text());nodes=g['nodes'];inv=json.loads(Path('/tmp/word-top-sharing/inventory.json').read_text());h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();overlay=p/'coherent-common';lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+lp;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x];rs=[]
for n,v in nodes.items():assert h(v['source'])==v['source_sha256'],('source drift',n)
for n,v in inv['local'].items():
 if n not in nodes:continue
 f=overlay/(n.replace('.','/')+'.olean');assert f.is_file() and h(f)==v['object_sha256'] and h(v['source'])==v['source_sha256'],('inherited pin mismatch',n)
def find(n):
 rel=n.replace('.','/')+'.olean'
 for r in roots:
  f=r/rel
  if f.is_file():return f
 raise RuntimeError('missing '+n)
names=['CurrentControllerData2011','MFWangTiles942PhysicalData','NativeRankVariation','MFWangTiles942PhysicalOrder','WangTiles942PhysicalData','ArithmeticConstructionKernel','WangTiles942PhysicalOrder']
for name in names:
 assert shutil.disk_usage('.').free>850*1024*1024,'disk reserve'
 n='DiophantineConsistency.'+name;v=nodes[n];src=Path(v['source']);before=h(src);im=[]
 for m in v['imports']:
  f=find(m);im.append({'module':m,'path':str(f),'resolved_path':str(f.resolve()),'sha256':h(f),'local':m in nodes})
 out=overlay/(n.replace('.','/')+'.olean');out.unlink(missing_ok=True);log=p/f'common-{name}.log';tm=p/f'common-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(Path.cwd()/'Computability/DiophantineConsistency/Lean'),str(src),'-o',str(out)];start=time.monotonic()
 with log.open('wb') as dest:rc=subprocess.run(cmd,stdout=dest,stderr=subprocess.STDOUT,env=env).returncode
 for x in im:x['after_sha256']=h(x['path'])
 r={'module':n,'status':rc,'command':cmd,'lean_path':env['LEAN_PATH'],'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'timing':tm.read_text().strip(),'direct_inputs':im,'elapsed':round(time.monotonic()-start,2)};rs.append(r);(p/'coherent-refresh-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(name,rc,r['elapsed'],flush=True)
 if rc or before!=r['source_after'] or any(x['sha256']!=x['after_sha256'] for x in im):raise SystemExit(1)
for n,v in nodes.items():assert h(v['source'])==v['source_sha256'],('source drift after',n)
print('seven source builds passed',flush=True)
