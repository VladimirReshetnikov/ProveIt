import DiophantineConsistency.CurrentKernelResidues2011
open Lean Elab Command
run_cmd do
  for n in (← getEnv).allImportedModuleNames do
    logInfo m!"{n}"
