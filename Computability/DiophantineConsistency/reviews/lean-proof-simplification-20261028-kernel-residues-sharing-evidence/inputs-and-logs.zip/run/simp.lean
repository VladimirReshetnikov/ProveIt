import DiophantineConsistency.CurrentKernelResidues2011
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n := ("DiophantineConsistency.CurrentKernelResidues2011.K_cast_2011._proof_1".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("DiophantineConsistency.CurrentKernelResidues2011.K_cast_47._proof_1".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("DiophantineConsistency.CurrentKernelResidues2011.K_cast_auxiliary._proof_1".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("DiophantineConsistency.CurrentKernelResidues2011.selector_reflection._proof_2".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernel2011.position.match_1.eq_1".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernel2011.position.match_1.eq_2".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernel2011.position.match_1.eq_3".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernel2011.position.match_1.eq_4".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernel2011.position.match_1.eq_5".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernel2011.position.match_1.splitter".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.cast_factor".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.controls_common".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.controls_common._proof_1".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.evaluate_rows".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.mod_of_cast".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.radix_common".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.rows_common".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.rows_common._proof_1".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.start_weight".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
  let n := ("_private.DiophantineConsistency.CurrentKernelResidues2011.0.DiophantineConsistency.CurrentKernelResidues2011.start_weight._proof_1".splitOn ".").foldl (fun a s => match s.toNat? with | some i => Name.num a i | none => Name.str a s) Name.anonymous
  logInfo m!"{n}: {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
