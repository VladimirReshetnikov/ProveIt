from pathlib import Path
import tomllib,json,hashlib
p=Path('/tmp/kernel-residues-sharing');root=Path.cwd();cfg=tomllib.loads((root/'lakefile.toml').read_text());roots=list(dict.fromkeys((root/x.get('srcDir','.')).resolve() for x in cfg['lean_lib']));h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();seen={};ext=set();q=['DiophantineConsistency.CurrentKernelResidues2011','DiophantineConsistency.CurrentKernelResidues2011Checks','DiophantineConsistency.CurrentControllerUnits2011']
while q:
 n=q.pop()
 if n in seen or n in ext:continue
 if n in ('DiophantineConsistency.CurrentKernelResidues2011',):
  f=p/'final/DiophantineConsistency'/(n.split('.')[-1]+'.lean')
 else:
  paths=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).exists()))
  if not paths:ext.add(n);continue
  assert len(paths)==1,(n,paths);f=paths[0]
 im=[]
 for line in f.read_text().splitlines():
  if line.startswith('import '):im+=line.split('--')[0].split()[1:]
 seen[n]={'source':str(f),'source_sha256':h(f),'imports':im};q.extend(im)
records=json.loads((p/'records.json').read_text());paths={ph:next(r['lean_path'] for r in records if r['phase']==ph and r['name']=='CurrentKernelResidues2011').split(':') for ph in ('baseline','final')};issues=[]
for n,v in seen.items():
 if n in ('DiophantineConsistency.CurrentKernelResidues2011','DiophantineConsistency.CurrentKernelResidues2011Checks','DiophantineConsistency.CurrentControllerUnits2011'):continue
 v['objects']={}
 for ph,bases in paths.items():
  found=None
  for b in bases:
   b=Path(b)
   if (b/n.split('.')[0]).exists():
    obj=b/(n.replace('.','/')+'.olean')
    if obj.exists():found=obj;break
    issues.append([n,ph,'shadow missing']);break
  if not found:issues.append([n,ph,'missing']);continue
  v['objects'][ph]={'path':str(found.resolve()),'sha256':h(found)}
 if len({x['sha256'] for x in v['objects'].values()})!=1:issues.append([n,'phase diff'])
report={'nodes':seen,'external':sorted(ext),'issues':issues};(p/'graph.json').write_text(json.dumps(report,indent=2)+'\n');print('nodes',len(seen),'external',len(ext),'busy',sum(n.startswith('BusyBeaver.') for n in seen),'issues',issues)
