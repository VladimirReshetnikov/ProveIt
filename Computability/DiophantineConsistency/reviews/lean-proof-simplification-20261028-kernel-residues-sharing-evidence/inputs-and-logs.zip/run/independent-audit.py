from pathlib import Path
import json,hashlib,re,tomllib
p=Path('/tmp/kernel-residues-sharing');root=Path.cwd();h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();g=json.loads((p/'graph.json').read_text()); inv=json.loads((p/'coherent-inventory.json').read_text()); cfg=tomllib.loads((root/'lakefile.toml').read_text());srcroots=list(dict.fromkeys((root/z.get('srcDir','.')).resolve() for z in cfg['lean_lib']));counter={}
def uncomment(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s.startswith('/-',i):depth+=1;i+=2;continue
  if depth and s.startswith('-/',i):depth-=1;i+=2;continue
  if depth:
   if s[i]=='\n':out.append('\n')
   i+=1;continue
  if s.startswith('--',i):
   j=s.find('\n',i);i=len(s) if j<0 else j;continue
  out.append(s[i]);i+=1
 return ''.join(out)
def reconstruct(ph):
 seen={};ext=set();queue=['DiophantineConsistency.CurrentKernelResidues2011','DiophantineConsistency.CurrentKernelResidues2011Checks','DiophantineConsistency.CurrentControllerUnits2011']
 while queue:
  n=queue.pop()
  if n in seen or n in ext:continue
  if n=='DiophantineConsistency.CurrentKernelResidues2011':f=p/ph/'DiophantineConsistency/CurrentKernelResidues2011.lean'
  else:
   fs=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in srcroots if (r/(n.replace('.','/')+'.lean')).is_file()))
   if not fs:ext.add(n);continue
   assert len(fs)==1,(n,fs);f=fs[0]
  deps=[]
  for line in uncomment(f.read_text()).splitlines():
   if line.startswith('import '):deps+=line.split()[1:]
  seen[n]={'source':str(f),'source_sha256':h(f),'imports':deps};queue.extend(deps)
 return seen,ext
b,be=reconstruct('baseline');f,fe=reconstruct('final');assert set(f)==set(g['nodes']) and fe==set(g['external']);assert all(f[n]['source_sha256']==g['nodes'][n]['source_sha256'] and f[n]['imports']==g['nodes'][n]['imports'] for n in f)
assert (p/'baseline/DiophantineConsistency/CurrentKernelResidues2011.lean').read_bytes()==(root/'Computability/DiophantineConsistency/Lean/DiophantineConsistency/CurrentKernelResidues2011.lean').read_bytes()
for n,x in inv['local'].items():assert h(x['source'])==x['source_sha256'] and h(x['object'])==x['object_sha256'],n
for n,x in inv['external'].items():assert h(x['object'])==x['object_sha256'],n
for fn in ('coherent-refresh-records.json','coherent-phase-records.json','coherent-probes-names.json','coherent-probes-interface.json','coherent-probes-private.json','coherent-probes-simp.json','coherent-probes-foundation-normal-first.json'):
 records=json.loads((p/fn).read_text());counter[fn]=len(records)
 for x in records:
  assert x['status']==(1 if 'foundation' in x.get('tag','') else 0),(fn,x.get('module'),x.get('name'),x.get('tag'))
  assert x['source_sha256']==x['source_after']==h(x['source']),(fn,x['source'])
  if x.get('object_sha256'):assert h(x['object'])==x['object_sha256'],(fn,x['object'])
  cmd=x['command'];assert Path(cmd[4]).is_file() and h(cmd[4])==x['time_sha256']; assert x['lean_path'].split(':')[0].startswith(str(p))
  if 'module' in x: log=p/('common-'+x['module'].split('.')[-1]+'.log')
  elif 'name' in x:log=p/('coherent-'+x['phase']+'-'+x['name']+'.log')
  else:log=p/('coherent-'+x['phase']+'-'+x['tag']+'.log')
  assert h(log)==x['log_sha256'],(fn,log)
  for z in x.get('direct_inputs',[]):assert z['sha256']==z['after_sha256']==h(z['path']),(fn,z['module'])
  for z in x.get('local_pins',[]):assert z['source_sha256']==z['source_after']==h(z['source']) and z['object_sha256']==z['object_after']==h(z['object']),(fn,z['module'])
  for z in x.get('external_pins',[]):assert z['object_sha256']==z['object_after']==h(z['object']),(fn,z['module'])
assert (p/'coherent-baseline-interface.log').read_bytes()==(p/'coherent-final-interface.log').read_bytes()
for n in ('CurrentKernelResidues2011','CurrentKernelResidues2011Checks','CurrentControllerUnits2011','foundation-normal-first','foundation-first'):assert (p/('coherent-baseline-'+n+'.log')).read_bytes()==(p/('coherent-final-'+n+'.log')).read_bytes()
result={'status':'PASS','baseline_local_modules':len(b),'final_local_modules':len(f),'baseline_external_modules':len(be),'final_external_modules':len(fe),'record_counts':counter,'local_pins':len(inv['local']),'external_pins':len(inv['external']),'graph_source_hashes_verified':True,'limitation':'Unaffected local and transitive external objects remain precompiled; this is not a full clean build.'}
(p/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
