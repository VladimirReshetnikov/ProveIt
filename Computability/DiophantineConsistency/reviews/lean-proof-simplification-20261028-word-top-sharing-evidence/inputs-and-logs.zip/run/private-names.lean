import DiophantineConsistency.CurrentWordTopBounds2011
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (toString n).contains "facts_toMF" then logInfo m!"{n}"
