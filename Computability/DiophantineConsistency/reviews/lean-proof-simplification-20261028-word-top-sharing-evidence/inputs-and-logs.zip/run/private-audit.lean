import DiophantineConsistency.CurrentWordTopBounds2011
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    if (toString n).contains "facts_toMF" then
      let axs ← collectAxioms n
      logInfo m!"PRIVATE {n}\nTYPE {c.type}\nAXIOMS {axs}"
