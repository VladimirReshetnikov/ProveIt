from pathlib import Path
import json,hashlib,collections
p=Path('/tmp/word-top-sharing');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest(); issues=[];counts={};g=json.loads((p/'graph.json').read_text()); inv=json.loads((p/'inventory.json').read_text()); assert len(inv['local'])==148 and len(inv['external'])==65
for fn in ('refresh-records.json','phase-records.json','pinned-records.json','coherent-probe-records.json','client-interface-records.json','foundation-retry-records.json'):
 rs=json.loads((p/fn).read_text());counts[fn]=len(rs)
 for r in rs:
  tag=r.get('tag');phase=r.get('phase');name=r.get('module','').split('.')[-1];cmd=r['command'];src=Path(r.get('source') or next(x for x in cmd if str(x).endswith('.lean')));label=(phase or '')+' '+(tag or name)
  if h(src)!=r['source_sha256'] or (r.get('source_after') and r['source_sha256']!=r['source_after']):issues.append((fn,label,'source'))
  if r['status'] != (1 if fn=='foundation-retry-records.json' or (fn=='coherent-probe-records.json' and tag=='foundation') else 0):issues.append((fn,label,'status'))
  if fn=='refresh-records.json':log=p/('common-'+name+'.log')
  elif fn=='phase-records.json':log=p/f'{phase}-{tag}.log'
  elif fn=='pinned-records.json':log=p/f'{phase}-pinned-{tag}.log'
  elif fn=='coherent-probe-records.json':log=p/f'coherent-{phase}-{tag}.log'
  elif fn=='client-interface-records.json':log=p/f'{phase}-client-interface.log'
  else:log=p/f'coherent-{phase}-foundation-retry.log'
  if h(log)!=r['log_sha256']:issues.append((fn,label,'log'))
  if r.get('time_sha256') and h(cmd[4])!=r['time_sha256']:issues.append((fn,label,'time'))
  if r.get('object_sha256') and (cmd[-2]!='-o' or h(cmd[-1])!=r['object_sha256']):issues.append((fn,label,'object'))
  for dep in r.get('direct_inputs',[]):
   if h(dep['path'])!=dep['sha256'] or dep.get('after_sha256')!=dep['sha256']:issues.append((fn,label,'direct '+dep['module']))
  if 'inputs_before' in r:
   before=r['inputs_before'];after=r['inputs_after'];assert len(before)==213
   if before!=after:issues.append((fn,label,'input inventory changed'))
   for n,v in before.items():
    if h(v['object'])!=v['object_sha256'] or ('source' in v and h(v['source'])!=v['source_sha256']):issues.append((fn,label,'pin '+n))
for tag in ('target','checks','client','interface'):
 if (p/f'baseline-pinned-{tag}.log').read_bytes()!=(p/f'final-pinned-{tag}.log').read_bytes():issues.append(('pinned',tag,'logs differ'))
if (p/'baseline-client-interface.log').read_bytes()!=(p/'final-client-interface.log').read_bytes():issues.append(('client','interface','logs differ'))
if (p/'coherent-baseline-foundation-retry.log').read_bytes()!=(p/'coherent-final-foundation-retry.log').read_bytes():issues.append(('foundation','retry','logs differ'))
if 'true' in (p/'coherent-baseline-simp.log').read_text():issues.append(('simp','baseline','removed name registered'))
b=set((p/'coherent-baseline-names.log').read_text().splitlines());f=set((p/'coherent-final-names.log').read_text().splitlines());removed=json.loads((p/'removed-names.json').read_text());assert len(b)==43 and len(f)==16 and set(removed)==b-f and not f-b
result={'counts':counts,'source_object_categories':inv['counts'],'old_namespace':len(b),'new_namespace':len(f),'removed_generated':len(removed),'issues':issues};(p/'audit-results.json').write_text(json.dumps(result,indent=2)+'\n');print('records',counts);print('148 local pin categories',inv['counts']);print('43 old, 16 retained, 27 generated removed');print('issues',len(issues));assert not issues
