from pathlib import Path
import os
p=Path('/tmp/word-top-sharing');src=p/'coherent-common'
for phase in ('baseline','final'):
 dst=p/('phase-'+phase);count=0
 for parent,dirs,files in os.walk(src,followlinks=False):
  base=Path(parent);rel=base.relative_to(src);(dst/rel).mkdir(parents=True,exist_ok=True)
  for name in files:
   source=base/name;out=dst/rel/name
   if rel==Path('DiophantineConsistency') and name in ('CurrentWordTopBounds2011.olean','CurrentWordTopBounds2011Checks.olean','CurrentWordScalarWitness2011.olean'):continue
   if source.exists() and not out.exists() and not out.is_symlink():out.symlink_to(source.resolve());count+=1
 print(phase,count,'selected symlinks')
