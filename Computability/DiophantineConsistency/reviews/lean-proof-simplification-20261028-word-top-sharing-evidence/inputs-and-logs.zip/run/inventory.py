from pathlib import Path
import json,hashlib,collections
p=Path('/tmp/word-top-sharing');g=json.loads((p/'graph.json').read_text());nodes=g['nodes'];seen=set();todo=['DiophantineConsistency.CurrentWordTopBounds2011','DiophantineConsistency.CurrentWordScalarWitness2011']
while todo:
 n=todo.pop()
 if n in seen:continue
 seen.add(n);todo += [m for m in nodes[n]['imports'] if m in nodes]
external=sorted({m for n in seen for m in nodes[n]['imports'] if m not in nodes});excluded={'DiophantineConsistency.CurrentWordTopBounds2011','DiophantineConsistency.CurrentWordScalarWitness2011'};seen-=excluded
cell={r['module']:r for r in json.loads(Path('/tmp/cell-construction-share/local-pins.json').read_text())};fresh={r['module']:r for r in json.loads((p/'refresh-records.json').read_text())};r=json.loads((p/'lowmask-record.json').read_text());fresh[r['module']]=r;h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();out={};cnt=collections.Counter()
for n in sorted(seen):
 source=Path(nodes[n]['source']);source= p/'final/DiophantineConsistency/MFCurrentWordTopBounds2011.lean' if n.endswith('.MFCurrentWordTopBounds2011') else source;so=h(source);ob=h(p/'phase-final'/Path(n.replace('.','/')+'.olean'));assert h(p/'phase-baseline'/Path(n.replace('.','/')+'.olean'))==ob,n
 if n in fresh and fresh[n]['source_sha256']==so and fresh[n]['object_sha256']==ob: status='fresh'
 elif n in cell and cell[n]['source_sha256']==so and cell[n]['final_sha256']==ob:status='cell '+cell[n]['status']
 else:raise RuntimeError('unmatched '+n)
 out[n]={'source':str(source.resolve()),'source_sha256':so,'object_sha256':ob,'status':status};cnt[status]+=1
assert len(out)==148 and len(external)==65;(p/'inventory.json').write_text(json.dumps({'local':out,'external':external,'counts':dict(cnt)},indent=2)+'\n');print('148 local pins:',dict(cnt),'; 65 direct external imports')
