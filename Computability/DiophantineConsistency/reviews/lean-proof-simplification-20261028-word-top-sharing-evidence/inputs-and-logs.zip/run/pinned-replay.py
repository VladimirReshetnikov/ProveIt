from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-top-sharing');repo=Path.cwd()/'Computability/DiophantineConsistency/Lean';inv=json.loads((p/'inventory.json').read_text());base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();rs=[]
base_main=p/'baseline/DiophantineConsistency/CurrentWordTopBounds2011.lean';base_mf=p/'baseline/DiophantineConsistency/MFCurrentWordTopBounds2011.lean';assert h(repo/'DiophantineConsistency/CurrentWordTopBounds2011.lean')==h(base_main);assert h(repo/'DiophantineConsistency/MFCurrentWordTopBounds2011.lean')==h(base_mf)
for phase in ('baseline','final'):
 ov=p/('phase-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def locate(n):
  rel=n.replace('.','/')+'.olean'
  for root in roots:
   f=root/rel
   if f.is_file():return f
  raise RuntimeError('missing '+n)
 def snapshot():
  d={}
  for n,v in inv['local'].items():
   src=Path(v['source']);obj=locate(n);assert h(src)==v['source_sha256'],('source',n);assert h(obj)==v['object_sha256'],('object',n)
   d[n]={'source':str(src),'source_sha256':v['source_sha256'],'object':str(obj.resolve()),'object_sha256':v['object_sha256'],'status':v['status']}
  for n in inv['external']:
   obj=locate(n);d[n]={'object':str(obj.resolve()),'object_sha256':h(obj),'status':'direct-external'}
  return d
 tasks=[('target',p/phase/'DiophantineConsistency/CurrentWordTopBounds2011.lean',p/phase,'CurrentWordTopBounds2011',True),('checks',repo/'DiophantineConsistency/CurrentWordTopBounds2011Checks.lean',repo,'CurrentWordTopBounds2011Checks',True),('client',repo/'DiophantineConsistency/CurrentWordScalarWitness2011.lean',repo,'CurrentWordScalarWitness2011',True),('interface',p/'interface.lean',None,None,False)]
 for tag,src,root,name,build in tasks:
  assert h(repo/'DiophantineConsistency/CurrentWordTopBounds2011.lean')==h(base_main);assert h(repo/'DiophantineConsistency/MFCurrentWordTopBounds2011.lean')==h(base_mf)
  pre=snapshot(); target=ov/'DiophantineConsistency/CurrentWordTopBounds2011.olean'; target_before=h(target) if target.exists() else None;log=p/f'{phase}-pinned-{tag}.log';tm=p/f'{phase}-pinned-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false'];out=None
  if build:
   out=ov/'DiophantineConsistency'/(name+'.olean');out.unlink(missing_ok=True);cmd += ['-R',str(root),str(src),'-o',str(out)]
  else:cmd += [str(src)]
  before=h(src);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  after=snapshot();assert pre==after,('inputs changed',phase,tag);assert h(repo/'DiophantineConsistency/CurrentWordTopBounds2011.lean')==h(base_main);assert h(repo/'DiophantineConsistency/MFCurrentWordTopBounds2011.lean')==h(base_mf)
  target_after=h(target) if target.exists() else None
  if tag!='target':assert target_before==target_after,(phase,tag,'target input drift')
  z={'phase':phase,'tag':tag,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(out) if out else None,'object_sha256':h(out) if out and out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'target_before':target_before,'target_after':target_after,'inputs_before':pre,'inputs_after':after};rs.append(z);(p/'pinned-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,tag,r.returncode,round(z['elapsed'],1),flush=True)
  if r.returncode or before!=h(src):raise SystemExit(1)
print('pinned replay completed')
