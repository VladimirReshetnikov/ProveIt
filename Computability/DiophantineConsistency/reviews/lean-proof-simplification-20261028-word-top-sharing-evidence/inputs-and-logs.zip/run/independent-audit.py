from pathlib import Path
import json,hashlib,functools
p=Path('/tmp/word-top-sharing');issues=[];counts={}
@functools.lru_cache(maxsize=None)
def h(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
for fn in ('refresh-records.json','phase-records.json','coherent-probe-records.json','pinned-records.json','foundation-retry-records.json'):
 rs=json.loads((p/fn).read_text());counts[fn]=len(rs)
 for r in rs:
  ph=r.get('phase');tag=r.get('tag');name=r.get('module','').split('.')[-1];cmd=r['command']; src=[Path(x) for x in cmd if x.endswith('.lean')];label=str(ph)+':'+str(tag or name)
  if len(src)!=1:issues.append([fn,label,'source arg']);continue
  if h(str(src[0]))!=r['source_sha256'] or r.get('source_after',r['source_sha256'])!=r['source_sha256']:issues.append([fn,label,'source'])
  if fn=='refresh-records.json':log=p/('common-'+name+'.log')
  elif fn=='phase-records.json':log=p/(ph+'-'+tag+'.log')
  elif fn=='coherent-probe-records.json':log=p/('coherent-'+ph+'-'+tag+'.log')
  elif fn=='pinned-records.json':log=p/(ph+'-pinned-'+tag+'.log')
  else:log=p/('coherent-'+ph+'-foundation-retry.log')
  if h(str(log))!=r['log_sha256']:issues.append([fn,label,'log'])
  if h(cmd[4])!=r['time_sha256']:issues.append([fn,label,'time'])
  if r.get('object_sha256') and (cmd[-2]!='-o' or h(r['object'])!=r['object_sha256'] or not Path(r['object']).is_relative_to(Path(r['lean_path'].split(':')[0]))):issues.append([fn,label,'object/path'])
  fail=fn=='foundation-retry-records.json' or tag=='foundation'
  if (r['status']!=0)!=fail:issues.append([fn,label,'status'])
  for item in r.get('direct_inputs',[]):
   if item['sha256']!=item['after_sha256'] or h(item['path'])!=item['sha256']:issues.append([fn,label,'direct input',item['module']])
  if 'inputs_before' in r:
   if r['inputs_before']!=r['inputs_after']:issues.append([fn,label,'input drift'])
   for n,v in r['inputs_before'].items():
    if h(v['object'])!=v['object_sha256'] or ('source' in v and h(v['source'])!=v['source_sha256']):issues.append([fn,label,'pinned input',n])
   if tag!='target' and r['target_before']!=r['target_after']:issues.append([fn,label,'target drift'])
for fn in ('lowmask-record.json',):
 r=json.loads((p/fn).read_text());cmd=r['command'];src=Path(r['source']);name=r['module'].split('.')[-1]
 if r['status'] or h(str(src))!=r['source_sha256'] or r['source_after']!=r['source_sha256'] or h(r['object'])!=r['object_sha256'] or h(str(p/('common-'+name+'.log')))!=r['log_sha256'] or h(cmd[4])!=r['time_sha256']:issues.append([fn,'record mismatch'])
 for x in r['direct_inputs']:
  if x['sha256']!=x['after_sha256'] or h(x['path'])!=x['sha256']:issues.append([fn,'input',x['module']])
counts['lowmask-record.json']=1
for n in ('CurrentWordTopBounds2011','MFCurrentWordTopBounds2011'):
 a=p/'baseline/DiophantineConsistency'/(n+'.lean');b=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean')
 if h(str(a))!=h(str(b)):issues.append([n,'baseline mismatch'])
print('checked',counts,'issues',len(issues));print(json.dumps(issues[:20],indent=2));(p/'independent-audit.json').write_text(json.dumps({'counts':counts,'issues':issues},indent=2)+'\n')
