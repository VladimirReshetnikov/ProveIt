from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-top-sharing');repo=Path.cwd()/'Computability/DiophantineConsistency/Lean';g=json.loads((p/'graph.json').read_text());nodes=g['nodes'];base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rs=[]
for phase in ('baseline','final'):
 ov=p/('phase-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x]
 def locate(n):
  rel=n.replace('.','/')+'.olean'
  for root in roots:
   f=root/rel
   if f.is_file():return f
  raise RuntimeError('missing object '+n)
 tasks=[('target',p/phase/'DiophantineConsistency/CurrentWordTopBounds2011.lean',p/phase,'CurrentWordTopBounds2011'),('checks',repo/'DiophantineConsistency/CurrentWordTopBounds2011Checks.lean',repo,'CurrentWordTopBounds2011Checks'),('client',repo/'DiophantineConsistency/CurrentWordScalarWitness2011.lean',repo,'CurrentWordScalarWitness2011')]
 for tag,src,root,name in tasks:
  if tag=='target': im=[m for line in src.read_text().splitlines() if line.startswith('import ') for m in line.split()[1:]]
  else:im=[m for line in src.read_text().splitlines() if line.startswith('import ') for m in line.split()[1:]]
  inputs=[]
  for dep in im:
   f=locate(dep);inputs.append({'module':dep,'path':str(f),'resolved_path':str(f.resolve()),'sha256':h(f),'local':dep in nodes})
  out=ov/'DiophantineConsistency'/(name+'.olean');out.unlink(missing_ok=True);log=p/f'{phase}-{tag}.log';tm=p/f'{phase}-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];before=h(src);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  for x in inputs:x['after_sha256']=h(x['path'])
  z={'phase':phase,'tag':tag,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':before,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'direct_inputs':inputs};rs.append(z);(p/'phase-records.json').write_text(json.dumps(rs,indent=2)+'\n');print(phase,tag,r.returncode,round(z['elapsed'],1),flush=True)
  if r.returncode or before!=h(src) or any(x['sha256']!=x['after_sha256'] for x in inputs):raise SystemExit(1)
print('paired target, checks and direct scalar client passed')
