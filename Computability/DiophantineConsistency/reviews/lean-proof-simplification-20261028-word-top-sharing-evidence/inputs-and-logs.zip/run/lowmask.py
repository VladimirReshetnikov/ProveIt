from pathlib import Path
import os,subprocess,json,hashlib,time
p=Path('/tmp/word-top-sharing');g=json.loads((p/'graph.json').read_text());n='DiophantineConsistency.CurrentWordLowMask2011';v=g['nodes'][n];ov=p/'coherent-common';base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base;roots=[Path(x) for x in env['LEAN_PATH'].split(':') if x];h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
def find(m):
 rel=m.replace('.','/')+'.olean'
 for root in roots:
  f=root/rel
  if f.is_file():return f
 raise RuntimeError('missing '+m)
s=Path(v['source']);assert h(s)==v['sha256'];inputs=[]
for dep in v['imports']:
 f=find(dep);inputs.append({'module':dep,'path':str(f),'resolved_path':str(f.resolve()),'sha256':h(f)})
out=ov/(n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True);log=p/'common-CurrentWordLowMask2011.log';tm=p/'common-CurrentWordLowMask2011.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(Path.cwd()/'Computability/DiophantineConsistency/Lean'),str(s),'-o',str(out)];t=time.monotonic()
with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
for x in inputs:x['after_sha256']=h(x['path'])
r={'module':n,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(s),'source_sha256':v['sha256'],'source_after':h(s),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'direct_inputs':inputs};(p/'lowmask-record.json').write_text(json.dumps(r,indent=2)+'\n');print(n,'status',r['status']);assert r['status']==0 and r['source_after']==v['sha256'] and all(x['sha256']==x['after_sha256'] for x in inputs)
