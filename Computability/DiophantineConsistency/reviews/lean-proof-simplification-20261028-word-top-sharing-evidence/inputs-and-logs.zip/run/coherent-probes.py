from pathlib import Path
import os,json,hashlib,subprocess,time
p=Path('/tmp/word-top-sharing');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();records=[]
for phase in ('baseline','final'):
 ov=p/('phase-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+base
 tags=['names','interface','imports','foundation']+(['simp'] if phase=='baseline' else ['private-audit'])
 for tag in tags:
  s=p/(tag+'.lean');log=p/f'coherent-{phase}-{tag}.log';tm=p/f'coherent-{phase}-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false',str(s)];before=h(s);t=time.monotonic()
  with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  z={'phase':phase,'tag':tag,'status':r.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source_sha256':before,'source_after':h(s),'log_sha256':h(log),'time_sha256':h(tm)};records.append(z);(p/'coherent-probe-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,tag,r.returncode,round(z['elapsed'],1),flush=True)
  if before!=h(s) or (r.returncode and tag!='foundation'):raise SystemExit(1)
print('coherent probes complete')
