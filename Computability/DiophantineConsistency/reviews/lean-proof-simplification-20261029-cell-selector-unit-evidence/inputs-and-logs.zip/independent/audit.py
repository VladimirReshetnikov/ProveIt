import hashlib,json,re,subprocess
from pathlib import Path
r=Path('/dev/shm/cell-selector-unit');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rs={}
for ph in ('baseline','final'):
 rows=json.loads((r/f'{ph}-records.json').read_text());assert [x['module'] for x in rows]==['ArithmeticCellLocal','ArithmeticCellLabels'];rs[ph]={x['module']:x for x in rows}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_sha256']==H(x['object']) and x['log_sha256']==H(x['log']);assert x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  for i in x['direct_inputs']:
   path=next(Path(q)/(i['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(i['module'].replace('.','/')+'.olean')).is_file());assert path==Path(i['path']) and str(path.resolve())==i['resolved'] and i['before']==i['after']==H(path)
   if i['source']:assert i['source_before']==i['source_after']==H(i['source'])
  if x['module']=='ArithmeticCellLabels':assert H(x['source'])==H(w/'ArithmeticCellLabels.lean') and x['direct_inputs'][0]['before']==rs[ph]['ArithmeticCellLocal']['object_sha256']
assert H(rs['baseline']['ArithmeticCellLocal']['source'])==H(w/'ArithmeticCellLocal.lean')
assert rs['baseline']['ArithmeticCellLabels']['object_sha256']==rs['final']['ArithmeticCellLabels']['object_sha256']
probes=json.loads((r/'probe-records.json').read_text());assert len(probes)==16
for p in probes:
 assert p['status']==0 and p['source_before']==p['source_after']==H(p['source']) and H(p['log'])==p['log_sha256'];names=['ArithmeticCellLocal']+(['ArithmeticCellLabels'] if p['client'] else []);assert p['objects_before']==p['objects_after']==[H(q) for q in p['objects']]==[rs[p['phase']][n]['object_sha256'] for n in names]
for stem in ('simp','instances','client-names','client-interfaces','client-simp','client-instances'):assert (r/('baseline-'+stem+'.log')).read_bytes()==(r/('final-'+stem+'.log')).read_bytes()
def reports(ph):return {m.group(1):m.group(0) for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',(r/(ph+'-interfaces.log')).read_text())}
a,b=reports('baseline'),reports('final');rem=sorted(a.keys()-b.keys());add=sorted(b.keys()-a.keys());chg=sorted(k for k in a.keys()&b.keys() if a[k]!=b[k]);assert len(a.keys()&b.keys())==177 and len(rem)==10 and len(add)==7 and len(chg)==2 and all(x.startswith('_private.') for x in rem+add+chg) and all('selectorUnit16' in x or 'selectorUnit2048' in x for x in rem) and all('selectorUnit' in x for x in add) and all('weight_mod_2048' in x or 'weight_mod_sixteen' in x for x in chg)
logs=[Path(rs[p]['ArithmeticCellLocal']['log']).read_text() for p in ('baseline','final')];normalize=lambda s:re.sub(r'/dev/shm/cell-selector-unit/(baseline|final)/DiophantineConsistency/ArithmeticCellLocal.lean:\d+:\d+:','SOURCE:',s);assert normalize(logs[0])==normalize(logs[1]) and logs[0].count('warning:')==3
for mod,owner,path in [('ArithmeticCellPhysical','ArithmeticCellLocal','/tmp/construction-share/bound-refresh-records.json'),('NativePreliminaryCount2011','ArithmeticCellLocal','/tmp/construction-share/bound-refresh-records.json'),('CurrentHighDigitFacts2011','ArithmeticCellLocal','/tmp/high-digits-module-sharing/final-records.json'),('MFDoubledClause2011','ArithmeticCellLabels','/tmp/construction-share/bound-refresh-records.json')]:
 d=next(d for d in rs['final'][owner]['direct_inputs'] if d['module'].split('.')[-1]==mod);xs=[x for x in json.load(open(path)) if x['module'].split('.')[-1]==mod and x['status']==0 and x['object_sha256']==d['before']];assert xs;x=xs[-1];before=x.get('source_before',x.get('before',x.get('source_sha256')));after=x.get('source_after',x.get('after',x.get('source_sha256')));assert before==after==d['source_before']
search=subprocess.run(['git','grep','-n','-E','selectorUnit16|selectorUnit2048','--','*.lean','*.py'],capture_output=True,text=True,check=False);lines=search.stdout.splitlines();assert search.returncode==0 and len(lines)==9 and all(x.startswith(str(w/'ArithmeticCellLocal.lean')+':') for x in lines)
print('PASS paired source, object and log pins; 16 probes; private name census; equal client objects; 4 current-source providers; exact 9 source-only references')
