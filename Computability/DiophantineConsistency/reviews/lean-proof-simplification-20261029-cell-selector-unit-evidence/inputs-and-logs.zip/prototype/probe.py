from pathlib import Path
import json,subprocess,hashlib,os
r=Path('/dev/shm/cell-selector-unit');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();out=[]
for probe in ['names','interfaces','simp','instances']:
 for client in [False,True]:
  for ph in ['baseline','final']:
   rows=json.loads((r/f'{ph}-records.json').read_text());source=r/('client-' if client else '') ;source=r/(('client-' if client else '')+probe+'.lean');objs=[Path(x['object']) for x in rows[:2 if client else 1]];log=r/(ph+('-client-' if client else '-')+probe+'.log');env=os.environ.copy();env['LEAN_PATH']=rows[0]['LEAN_PATH'];sb=h(source);before=[h(x) for x in objs];cmd=['lean','-M10000','-j1','-DElab.async=false',str(source)]
   with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   x={'phase':ph,'client':client,'probe':probe,'status':p.returncode,'source':str(source),'source_before':sb,'source_after':h(source),'objects':[str(o) for o in objs],'objects_before':before,'objects_after':[h(o) for o in objs],'log':str(log),'log_sha256':h(log),'command':cmd,'LEAN_PATH':env['LEAN_PATH']};out.append(x);(r/'probe-records.json').write_text(json.dumps(out,indent=2)+'\n');print(ph,client,probe,p.returncode,flush=True)
   if p.returncode or x['objects_before']!=x['objects_after']:raise SystemExit(1)
