from pathlib import Path
import os,json,hashlib,subprocess,sys,re,shutil
r=Path('/dev/shm/cell-selector-unit');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();phase=sys.argv[1];names=['ArithmeticCellLocal','ArithmeticCellLabels'];lib=r/('obj-'+phase);lib.mkdir(exist_ok=True);subprocess.run(['cp','-as','/dev/shm/cell-sum-unique/obj-final/DiophantineConsistency',str(lib/'DiophantineConsistency')],check=True)
for n in names:(lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True)
shutil.copyfile(w/'ArithmeticCellLabels.lean',r/phase/'DiophantineConsistency/ArithmeticCellLabels.lean')
base=json.loads(Path('/dev/shm/cell-sum-unique/final-records.json').read_text())[0];env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+base['LEAN_PATH'];rows=[]
for n in names:
 src=r/phase/'DiophantineConsistency'/(n+'.lean');inputs=[]
 for name in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());leaf=name.split('.')[-1];sp=r/phase/'DiophantineConsistency'/(leaf+'.lean') if leaf in names else w/(leaf+'.lean');inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 out=lib/'DiophantineConsistency'/(n+'.olean');tm=r/(phase+'-'+n+'.time');log=r/(phase+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/phase),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 rec={'phase':phase,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};rows.append(rec);(r/(phase+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
