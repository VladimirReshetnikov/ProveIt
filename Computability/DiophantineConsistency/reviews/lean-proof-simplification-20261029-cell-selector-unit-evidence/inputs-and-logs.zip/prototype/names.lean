import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCellLocal
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticCellLocal).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCellLocal" then
   logInfo m!"DECL {n}"
