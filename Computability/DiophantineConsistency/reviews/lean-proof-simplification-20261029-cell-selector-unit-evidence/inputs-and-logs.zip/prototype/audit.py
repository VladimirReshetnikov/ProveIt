from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/dev/shm/cell-selector-unit');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); rec={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticCellLocal','ArithmeticCellLabels'];rec[phase]={}
 for x in rows:
  rec[phase][x['module']]=x;assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
   if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
   if d['module'].endswith('.ArithmeticCellLocal'):assert d['before']==rec[phase]['ArithmeticCellLocal']['object_sha256']
  if x['module']=='ArithmeticCellLabels':assert h(x['source'])==h(w/'ArithmeticCellLabels.lean')
  print('PASS build',phase,x['module'])
assert rec['baseline']['ArithmeticCellLabels']['object_sha256']==rec['final']['ArithmeticCellLabels']['object_sha256']
logs=[Path(rec[p]['ArithmeticCellLocal']['log']).read_text() for p in ('baseline','final')];clean=lambda s:re.sub(r'/dev/shm/cell-selector-unit/(baseline|final)/DiophantineConsistency/ArithmeticCellLocal.lean:\d+:\d+:','SOURCE:',s)
assert clean(logs[0])==clean(logs[1]) and logs[0].count('warning:')==3
assert all(Path(rec[p]['ArithmeticCellLabels']['log']).read_bytes()==b'' for p in ('baseline','final'))
probes=json.loads((r/'probe-records.json').read_text());assert len(probes)==16
for p in probes:
 phase=p['phase'];names=['ArithmeticCellLocal']+(['ArithmeticCellLabels'] if p['client'] else []);assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[phase][n]['object_sha256'] for n in names] and h(p['log'])==p['log_sha256']
for stem in ('simp','instances','client-names','client-interfaces','client-simp','client-instances'):
 assert (r/('baseline-'+stem+'.log')).read_bytes()==(r/('final-'+stem+'.log')).read_bytes()
def interfaces(phase):
 s=(r/(phase+'-interfaces.log')).read_text();return {m.group(1):m.group(0) for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',s)}
a=interfaces('baseline');b=interfaces('final');removed=sorted(a.keys()-b.keys());added=sorted(b.keys()-a.keys());changed=sorted(n for n in a.keys()&b.keys() if a[n]!=b[n]);assert len(removed)==10 and len(added)==7 and len(changed)==2
assert all(n.startswith('_private.') and ('selectorUnit16' in n or 'selectorUnit2048' in n) for n in removed);assert all(n.startswith('_private.') and 'selectorUnit' in n for n in added);assert all(n.startswith('_private.') and ('weight_mod_2048' in n or 'weight_mod_sixteen' in n) for n in changed);print('PASS target common',len(a.keys()&b.keys()),'with 10 private removed, 7 added, 2 private reports changed; client and registrations match')
for mod,owner,path in [('ArithmeticCellPhysical','ArithmeticCellLocal','/tmp/construction-share/bound-refresh-records.json'),('NativePreliminaryCount2011','ArithmeticCellLocal','/tmp/construction-share/bound-refresh-records.json'),('CurrentHighDigitFacts2011','ArithmeticCellLocal','/tmp/high-digits-module-sharing/final-records.json'),('MFDoubledClause2011','ArithmeticCellLabels','/tmp/construction-share/bound-refresh-records.json')]:
 d=next(d for d in rec['final'][owner]['direct_inputs'] if d['module'].split('.')[-1]==mod);xs=[x for x in json.load(open(path)) if x['module'].split('.')[-1]==mod and x['status']==0 and x['object_sha256']==d['before']];assert xs;x=xs[-1];before=x.get('source_before',x.get('before',x.get('source_sha256')));after=x.get('source_after',x.get('after',x.get('source_sha256')));assert before==after==d['source_before'];print('PASS source-current direct producer',mod,d['before'])
result=subprocess.run(['git','grep','-n','-E','selectorUnit16|selectorUnit2048','--','*.lean','*.py'],text=True,stdout=subprocess.PIPE,check=False);lines=result.stdout.splitlines();assert all('ArithmeticCellLocal.lean:' in l for l in lines);print('PASS tracked-name reference search',len(lines),'all confined to original file')
print('PASS all checks; cached transitive closure not audited')
