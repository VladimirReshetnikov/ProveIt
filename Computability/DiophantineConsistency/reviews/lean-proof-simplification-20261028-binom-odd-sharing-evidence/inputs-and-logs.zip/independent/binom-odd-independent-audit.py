from pathlib import Path
import hashlib,json,re
r=Path('/tmp/binom-odd-sharing');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows={}
prior=[]
for f in ('/tmp/outer-seed-bound-sharing/prereq2-records.json','/tmp/pell-construction-refresh/resumed-records.json'):
 for x in json.loads(Path(f).read_text()):
  if x.get('status')==0:prior.append((x.get('module','').split('.')[-1],x.get('source_sha256'),x.get('object_sha256'),f))
for ph in ('baseline','final','baseline-repeat','final-repeat'):
 a=json.loads((r/f'{ph}-records.json').read_text());assert len(a)==(1 if ph.endswith('repeat') else 4)
 for x in a:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f"{ph}-{x['module']}.time").read_text()
  if ph.startswith('baseline') or x['module']!='ArithmeticBinomLegendre':assert x['before']==h(repo/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if (ph,n) in rows:assert d['resolved']==rows[(ph,n)]['object'] and d['before']==rows[(ph,n)]['object_sha256']
   else:
    src=h(repo/(n+'.lean')); matches=[f for mod,s,o,f in prior if (mod,s,o)==(n,src,d['before'])];assert matches,(ph,n,src,d['before']);print('prior provider',ph,n,matches[0])
  rows[(ph,x['module'])]=x;print('build',ph,x['module'],x['time'].strip())
for n in ('ArithmeticHalfBinomial','ArithmeticOuterSeed','ArithmeticHalfBinomial2011'):assert rows[('baseline',n)]['object_sha256']==rows[('final',n)]['object_sha256'];print('client identical',n,rows[('baseline',n)]['object_sha256'])
for ph in ('baseline','final'):
 for n in ('names','interfaces','simp','instances'):
  x=json.loads((r/f'probe-{n}-{ph}.json').read_text());assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[(ph,'ArithmeticBinomLegendre')]['object_sha256'] and x['log_sha256']==h(x['log']);print('probe',ph,n,'passed')
def parse(p):return {m.group(1):m.group(0) for m in re.finditer(r'^DECL (\S+) TYPE .*?(?=^DECL |\Z)',p.read_text(),re.M|re.S)}
a=parse(r/'baseline-interfaces.log');b=parse(r/'final-interfaces.log');added=b.keys()-a.keys();assert len(a)==11 and len(b)==12 and len(added)==1 and not a.keys()-b.keys() and all(a[n]==b[n] for n in a);print('unchanged',len(a),'added',*added)
for n in ('simp','instances'):x=(r/f'baseline-{n}.log').read_bytes();y=(r/f'final-{n}.log').read_bytes();assert x==y;print(n,'identical entries',len(x.splitlines()))
for ph in ('baseline','final'):print('repeat target matches initial',ph,rows[(ph,'ArithmeticBinomLegendre')]['object_sha256']==rows[(ph+'-repeat','ArithmeticBinomLegendre')]['object_sha256'])
old=json.loads((r/'initial-final-records.json').read_text())[0];print('superseded initial final log bytes match current reused path (not independently retained)?',old['log_sha256']==h(old['log']),'recorded time equals current reused path?',old['time']==Path(old['command'][old['command'].index('-o')+1]).read_text())
