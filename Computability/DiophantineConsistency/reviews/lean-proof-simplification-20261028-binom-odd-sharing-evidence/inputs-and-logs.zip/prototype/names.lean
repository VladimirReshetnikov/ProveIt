import DiophantineConsistency.ArithmeticBinomLegendre
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticBinomLegendre).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticBinomLegendre" then
   logInfo m!"DECL {n}"
