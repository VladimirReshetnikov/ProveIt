from pathlib import Path
import hashlib,json,re
R=Path('/tmp/binom-odd-sharing'); W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records={}
for phase in ('baseline','final','baseline-repeat','final-repeat'):
 a=json.loads((R/(phase+'-records.json')).read_text()); records[phase]=a
 for x in a:
  assert x['status']==0 and x['before']==x['after']==H(x['source']) and x['object_sha256']==H(x['object']) and x['log_sha256']==H(x['log'])
  assert x['time']==(R/(phase+'-'+x['module']+'.time')).read_text()
  if x['module']!='ArithmeticBinomLegendre' or phase.startswith('baseline'): assert x['before']==H(W/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   first=next(Path(p)/(d['module'].replace('.','/')+'.olean') for p in x['LEAN_PATH'].split(':') if (Path(p)/(d['module'].replace('.','/')+'.olean')).is_file())
   assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==H(first)
 print(phase,len(a),'passed',a[0]['time'].strip())
for x,y in zip(records['baseline'],records['final']):
 assert x['module']==y['module']
 if x['module']!='ArithmeticBinomLegendre': assert x['object_sha256']==y['object_sha256']
for phase in ('baseline','final'):
 print(phase,'repeat object matches initial:',records[phase][0]['object_sha256']==records[phase+'-repeat'][0]['object_sha256'])
for probe in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=json.loads((R/('probe-'+probe+'-'+phase+'.json')).read_text())
  assert x['status']==0 and x['source_before']==x['source_after']==H(x['source']) and x['object_before']==x['object_after']==H(x['object']) and x['log_sha256']==H(x['log'])
print('probe records verified')
for probe in ('simp','instances'): assert (R/('baseline-'+probe+'.log')).read_bytes()==(R/('final-'+probe+'.log')).read_bytes()
def decls(p):
 s=Path(p).read_text();return {x.split(' TYPE ',1)[0]:x for x in re.split(r'(?m)^DECL ',s) if x.strip()}
a=decls(R/'baseline-interfaces.log');b=decls(R/'final-interfaces.log');assert all(b[k]==v for k,v in a.items()) and len(b)==len(a)+1
print('interfaces',len(a),len(b),'added:',*set(b)-set(a));print('simp and instances match')
priors=[]
for f in ['/tmp/outer-seed-bound-sharing/prereq2-records.json','/tmp/pell-construction-refresh/resumed-records.json']:
 priors+=json.loads(Path(f).read_text())
for x in records['baseline']:
 for d in x['direct_inputs']:
  name=d['module'].split('.')[-1]
  if name in [r['module'] for r in records['baseline']]:continue
  source=H(W/(name+'.lean'))
  matches=[r for r in priors if r.get('module') in (name,d['module']) and r.get('status')==0 and r.get('source_sha256')==source and r.get('object_sha256')==d['before']]
  assert matches,(name,source,d['before'])
  print('prior direct provider',name,source,d['before'])
print('all checks passed')
