from pathlib import Path
import json,hashlib,os
R=Path('/tmp/bisim-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); roots=[Path('/tmp/control-bisim-perm215-root-1czao7t5/lib'),Path('/tmp/runtime215-root-_hxbq4kn/lib'),Path('/tmp/enum-soundnessperm222-root-peer-wmzrngb7/lib')];receipts=[]
for rt in roots:
 for f in ['inputs.json','ROOT.json','author-packet.json','final-authentication.json']:
  p=rt.parent/f
  if p.exists():receipts.append(p)
receipts.append(Path('Computability/DiophantineConsistency/research/c222-runtime215-composition-plan-20261027/cache-plan.json'))
known={}
def walk(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str):known.setdefault(Path(x['path']).name,set()).add(x['sha256'])
  if isinstance(x.get('source'),str) and isinstance(x.get('source_sha256'),str):known.setdefault(Path(x['source']).name,set()).add(x['source_sha256'])
  for y in x.values():walk(y)
 elif isinstance(x,list):
  for y in x:walk(y)
for p in receipts:walk(json.load(open(p)))
g=json.load(open(R/'client-inventory.json'));selected=[];missing=[];bad=[]
for n in g['order']:
 v=g['nodes'][n];objname=n.replace('.','/')+'.olean';candidates=[rt/objname for rt in roots if (rt/objname).exists()]
 if not candidates:missing.append(n);continue
 o=candidates[0];sh=v['source_sha256'];oh=h(o); name=Path(v['source']).name
 d={'module':n,'source':str(Path(v['source']).resolve()),'source_sha256':sh,'object':str(o.resolve()),'object_sha256':oh,'source_receipt_match':sh in known.get(name,set()),'object_receipt_match':oh in known.get(Path(objname).name,set()),'imports':v['imports']};selected.append(d)
 if not d['source_receipt_match'] or not d['object_receipt_match']:bad.append(d)
(R/'client-pins.json').write_text(json.dumps({'receipts':[{'path':str(p.resolve()),'sha256':h(p)} for p in receipts],'selected':selected,'missing':missing,'unmatched':bad},indent=2)+'\n');print('selected',len(selected),'missing',len(missing),'unmatched',len(bad));print('\n'.join(x['module']+' '+str((x['source_receipt_match'],x['object_receipt_match'])) for x in bad))
