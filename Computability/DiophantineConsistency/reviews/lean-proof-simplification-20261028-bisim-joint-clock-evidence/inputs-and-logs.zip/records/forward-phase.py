from pathlib import Path
import os,subprocess,hashlib,json,time,re
R=Path('/tmp/bisim-share');lib=R/'forward-common';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticRuntimeBound215.lean');root=src.parent.parent;records=[];plan=json.load(open(R/'forward-plan.json'));assert h(src)==plan['nodes']['DiophantineConsistency.ArithmeticRuntimeBound215']['source_sha256']
for phase in ['baseline','final']:
 out=R/('forward-'+phase);out.mkdir(exist_ok=True)
 for p in lib.rglob('*'):
  if not p.is_file():continue
  q=out/p.relative_to(lib);q.parent.mkdir(parents=True,exist_ok=True)
  if q.exists():assert h(q)==h(p)
  else:q.symlink_to(p.resolve())
 p=out/'DiophantineConsistency/ArithmeticRuntimeBoundBisim.olean';p.symlink_to((R/phase/'DiophantineConsistency/ArithmeticRuntimeBoundBisim.olean').resolve())
def run(phase,name,source,output=None):
 out=R/('forward-'+phase);env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base;log=R/f'forward-{phase}-{name}.log';tm=R/f'forward-{phase}-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false'];
 if output:output.unlink(missing_ok=True);cmd+=['-R',str(root)]
 cmd+=[str(source)]
 if output:cmd+=['-o',str(output)]
 pre=h(source);deps=[]
 if output:
  for n in plan['nodes']['DiophantineConsistency.ArithmeticRuntimeBound215']['imports']:
   p=out/(n.replace('.','/')+'.olean');assert p.exists(),n;deps.append({'module':n,'object':str(p.resolve()),'sha256':h(p)})
 start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'phase':phase,'name':name,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'elapsed':time.monotonic()-start,'source':str(source.resolve()),'source_sha256':pre,'source_after':h(source),'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(output) if output else None,'object_sha256':h(output) if output and output.exists() else None,'direct_project_inputs':deps};records.append(d);(R/'forward-phase-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,p.returncode,round(d['elapsed'],1),flush=True)
 if p.returncode or pre!=d['source_after']:raise SystemExit(1)
for phase in ['baseline','final']:run(phase,'target',src,R/('forward-'+phase)/'DiophantineConsistency/ArithmeticRuntimeBound215.olean')
probe=R/'forward-names.lean';probe.write_text('''import DiophantineConsistency.ArithmeticRuntimeBound215
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticRuntimeBound215).isPrefixOf n then
      logInfo m!"DECL {n}"
''')
for phase in ['baseline','final']:run(phase,'names',probe)
parse=lambda p:sorted(set(x.removeprefix('DECL ') for x in p.read_text().splitlines() if x.startswith('DECL ')))
a=parse(R/'forward-baseline-names.log');b=parse(R/'forward-final-names.log');assert a==b,(a,b);(R/'forward-names-comparison.json').write_text(json.dumps(a,indent=2)+'\n');probe=R/'forward-axioms.lean';probe.write_text('import DiophantineConsistency.ArithmeticRuntimeBound215\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in a))
for phase in ['baseline','final']:run(phase,'axioms',probe)
assert (R/'forward-baseline-axioms.log').read_bytes()==(R/'forward-final-axioms.log').read_bytes()
print('forward client and',len(a),'declaration reports matched',flush=True)
