import pathlib,json,hashlib,subprocess
P=pathlib.Path('/tmp/bisim-share'); H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for f in ['paired-records.json','axiom-records.json','forward-build-records.json','forward-phase-records.json']:
 rs=json.loads((P/f).read_text()); ok=0
 for r in rs:
  assert H(r['source'])==r['source_sha256']==r['source_after'],(f,r.get('name',r.get('module')),'source')
  assert H(r['log'])==r['log_sha256'],(f,r.get('name',r.get('module')),'log')
  assert pathlib.Path(r['command'][4]).read_text()==r.get('time',r.get('timing')),(f,r.get('name',r.get('module')),'time')
  if r.get('object_sha256'):assert H(r['object'])==r['object_sha256'],(f,r.get('name',r.get('module')),'object')
  if r.get('object'):assert r['command'][-2:]==['-o',r['object']],(f,r.get('name',r.get('module')),'objectpath')
  for d in r.get('direct_project_inputs',[]):assert H(d['object'])==d['sha256'],(f,r.get('name',r.get('module')),d['module'],'direct')
  ph=r.get('phase')
  if ph: assert r['lean_path'].split(':')[0]==str(P/(('forward-' if f=='forward-phase-records.json' else '')+ph)),(f,r.get('name'),'overlay')
  elif f=='forward-build-records.json':assert r['lean_path'].split(':')[0]==str(P/'forward-common')
  ok+=r['status']==0
 print(f,'records',len(rs),'passed',ok,'failed',len(rs)-ok,'all receipt fields checked')
for n in ['ArithmeticRuntimeBoundBisim','ArithmeticRuntimeBoundBisimReverse']:
 repo='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+n+'.lean';current=pathlib.Path(repo).read_bytes();head=subprocess.check_output(['git','show','HEAD:'+repo]);baseline=(P/'baseline/DiophantineConsistency'/(n+'.lean')).read_bytes();print(n,'baseline matches HEAD and working',baseline==head==current)
for f in ['axioms','client']:
 print(f,'equal logs',(P/('baseline-'+f+'.log')).read_bytes()==(P/('final-'+f+'.log')).read_bytes())
for f in ['axioms','names']:
 print('forward',f,'equal logs',(P/('forward-baseline-'+f+'.log')).read_bytes()==(P/('forward-final-'+f+'.log')).read_bytes())
