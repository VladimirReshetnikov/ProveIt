import DiophantineConsistency.ArithmeticRuntimeBound215
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticRuntimeBound215).isPrefixOf n then
      logInfo m!"DECL {n}"
