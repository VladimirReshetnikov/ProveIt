from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/tmp/bisim-share');out=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261028-bisim-joint-clock-evidence');out.mkdir(parents=True,exist_ok=False);h=lambda b:hashlib.sha256(b).hexdigest();members={}
def add(name,data):
 assert name not in members,name
 members[name]=data
for p in sorted(R.iterdir()):
 if p.is_file() and p.suffix in ('.json','.lean','.py','.log','.time','.txt'):add('records/'+p.name,p.read_bytes())
for phase in ['baseline','final']:
 for n in ['ArithmeticRuntimeBoundBisim','ArithmeticRuntimeBoundBisimReverse']:
  p=R/phase/'DiophantineConsistency'/(n+'.lean');add('snapshots/'+phase+'/'+n+'.lean',p.read_bytes())
plan=json.load(open(R/'forward-plan.json'))
for n,v in sorted(plan['nodes'].items()):
 p=(R/'baseline/DiophantineConsistency/ArithmeticRuntimeBoundBisim.lean') if n=='DiophantineConsistency.ArithmeticRuntimeBoundBisim' else Path(v['source'])
 data=p.read_bytes();assert h(data)==v['source_sha256'],n;add('snapshots/forward-inputs/'+n.replace('.','/')+'.lean',data)
for x in json.load(open(R/'prior-141-pins.json')):
 p=Path(x['source']);data=p.read_bytes();assert h(data)==x['source_sha256'],x['module'];add('snapshots/prior-inputs/'+x['module'].replace('.','/')+'.lean',data)
receipts={
 'control/inputs.json':'/tmp/control-bisim-perm215-root-1czao7t5/inputs.json',
 'control/author-packet.json':'/tmp/control-bisim-perm215-root-1czao7t5/author-packet.json',
 'runtime/inputs.json':'/tmp/runtime215-root-_hxbq4kn/inputs.json',
 'runtime/ROOT.json':'/tmp/runtime215-root-_hxbq4kn/ROOT.json',
 'runtime/final-authentication.json':'/tmp/runtime215-root-_hxbq4kn/final-authentication.json',
 'enum-soundness/inputs.json':'/tmp/enum-soundnessperm222-root-peer-wmzrngb7/inputs.json',
 'enum-soundness/ROOT.json':'/tmp/enum-soundnessperm222-root-peer-wmzrngb7/ROOT.json',
 'runtime/cache-plan.json':'Computability/DiophantineConsistency/research/c222-runtime215-composition-plan-20261027/cache-plan.json'}
for name,path in receipts.items():add('predecessor-receipts/'+name,Path(path).read_bytes())
commit='2e5b3dba2eef0e7107810a8c7514716945f4d5a6'
for n in ['ArithmeticRuntimeBoundBisim','ArithmeticRuntimeBoundBisimReverse']:
 path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'+n+'.lean'; actual=subprocess.check_output(['git','show',commit+':'+path]);assert actual==members['snapshots/final/'+n+'.lean'],n
archive=out/'inputs-and-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert sorted(z.namelist())==sorted(members)
 for name,data in members.items():assert z.read(name)==data,name
bundle={'schema':'lean-proof-simplification-evidence-v1','source_commit':commit,'scope':'Joint bounded bisimulation clock induction shared by forward and reverse transfers','validation':'Paired Bisim targets and concrete compatibility clients pass; 13 existing public/generated types and axiom reports match. Both new declarations have only propext, Classical.choice and Quot.sound. A 25-module source refresh passes and the ArithmeticRuntimeBound215 production client and all six names/axiom reports pass in both phases. All 25 refresh logs and both production-client logs have no warnings. The package audit rechecked 46 command/source/object/log records, 141 predecessor source/object pairs, 113 borrowed project pairs, 405 compiled companions, and all recorded direct project inputs.','limitations':'ArithmeticRefutationHaltBound was not rebuilt: its first attempted paired runs fail before elaboration at missing ArithmeticProofWordBound. Initial ArithmeticRuntimeBound215 attempts likewise failed at missing ArithmeticRuntime215, then the coherent refreshed runs passed. The first two refresh attempts failed before elaboration due to missing Foundation server and IR companions; both are retained. One run was interrupted on user direction after 24 successful prerequisites; the 25th was resumed after rechecking source/object/input hashes. Foundation, Mathlib and other authenticated inputs remain precompiled. The archive includes source snapshots, logs, scripts and source/object hash receipts, but not binary object payloads or the external toolchain; it is an audit record, not a self-contained replay environment.','archive':'inputs-and-logs.zip','archive_sha256':h(archive.read_bytes()),'members':{name:{'sha256':h(data),'bytes':len(data)} for name,data in sorted(members.items())}}
(out/'BUNDLE.json').write_text(json.dumps(bundle,indent=2,ensure_ascii=False)+'\n')
loaded=json.load(open(out/'BUNDLE.json'));assert loaded['archive_sha256']==h(archive.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(loaded['members'])
 for n,m in loaded['members'].items():
  data=z.read(n);assert h(data)==m['sha256'] and len(data)==m['bytes']
print('archive',archive,'members',len(members),'bytes',archive.stat().st_size,'sha256',loaded['archive_sha256'])
