from pathlib import Path
import os,subprocess,hashlib,json,time,re
R=Path('/tmp/bisim-share');lib=R/'forward-common';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+base;plan=json.load(open(R/'forward-plan.json'));records=[]
for n in plan['build_order']:
 src=Path(plan['nodes'][n]['source']);assert h(src)==plan['nodes'][n]['source_sha256'];out=lib/(n.replace('.','/')+'.olean');out.parent.mkdir(parents=True,exist_ok=True);out.unlink(missing_ok=True)
 deps=[]
 for name in plan['nodes'][n]['imports']:
  p=lib/(name.replace('.','/')+'.olean')
  if not p.exists():raise RuntimeError('missing direct dependency '+name+' for '+n)
  deps.append({'module':name,'object':str(p.resolve()),'sha256':h(p)})
 tag=n.replace('.','_');log=R/(tag+'.log');tm=R/(tag+'.time');root=Path('Computability/DiophantineConsistency/Lean' if n.startswith('DiophantineConsistency.') else 'Computability/BusyBeaver/Lean');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];pre=h(src);start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'elapsed':time.monotonic()-start,'source':str(src.resolve()),'source_sha256':pre,'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.exists() else None,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'direct_project_inputs':deps};records.append(d);(R/'forward-build-records.json').write_text(json.dumps(records,indent=2)+'\n');print(len(records),n,p.returncode,round(d['elapsed'],1),flush=True)
 if p.returncode or pre!=d['source_after']:raise SystemExit(1)
