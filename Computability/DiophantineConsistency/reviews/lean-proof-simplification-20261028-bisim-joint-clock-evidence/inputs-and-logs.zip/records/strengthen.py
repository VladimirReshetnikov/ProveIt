from pathlib import Path
p=Path('/tmp/bisim-share/final/DiophantineConsistency/ArithmeticRuntimeBoundBisim.lean');q=p.with_name('ArithmeticRuntimeBoundBisimReverse.lean');s=p.read_text();t=q.read_text()
include='''include reg_fileOf live_ne runA_zero runB_zero runA_add runB_add runA_one runB_one
  runA_halted runB_halted specA specB reg_write_same reg_write_other hcheck hlive hreg in'''
helper='''include reg_fileOf runA_zero runB_zero runA_add runB_add runA_one runB_one
  runA_halted runB_halted specA specB reg_write_same reg_write_other hcheck hlive hreg in
/-- Both clocks stay between the number of certified steps and its fuel bound. -/
theorem bounded_clocks (a b : V) (h0 : Rel reg live cert N a b) (n : V) :
    ∃ ta tb, ta ≤ ((fuel : V) + 1) * n ∧ n ≤ ta ∧
      tb ≤ ((fuel : V) + 1) * n ∧ n ≤ tb ∧
      ((runA ta a = 0 ∧ runB tb b = 0) ∨ Rel reg live cert N (runA ta a) (runB tb b)) := by
  haveI : 𝚺₁-Relation[V] (Rel reg live cert N) :=
    (rel_defined reg live cert N liveDef regDef).to_definable
  let K : V := (fuel : V) + 1
  have hK1 : (1 : V) ≤ K := le_add_self
  change ∃ ta tb, ta ≤ K * n ∧ n ≤ ta ∧ tb ≤ K * n ∧ n ≤ tb ∧ _
  induction n using ISigma1.sigma1_succ_induction
  · definability
  case zero =>
    exact ⟨0, 0, by simp, le_rfl, by simp, le_rfl,
      .inr (by simpa only [runA_zero, runB_zero] using h0)⟩
  case succ n ih =>
    obtain ⟨ta, tb, hta, hta', htb, htb', hq⟩ := ih
    have hKn : K * (n+1) = K * n + K := by ring
    rcases hq with ⟨hza, hzb⟩ | hr
    · refine ⟨ta+1, tb+1, ?_, _root_.add_le_add hta' le_rfl, ?_,
        _root_.add_le_add htb' le_rfl, .inl ⟨?_, ?_⟩⟩
      · rw [hKn]; exact _root_.add_le_add hta hK1
      · rw [hKn]; exact _root_.add_le_add htb hK1
      · rw [runA_add, hza, runA_halted]
      · rw [runB_add, hzb, runB_halted]
    · obtain ⟨ka, kb, hka, hkb, hkaK, hkbK, hs⟩ :=
        rel_step_both fileOf reg_fileOf stepA stepB runA runB rowsA rowsB cert fuel N
          runA_zero runB_zero runA_add runB_add runA_one runB_one specA specB
          reg_write_same reg_write_other hcheck _ _ hr
      refine ⟨ta+ka, tb+kb, ?_, _root_.add_le_add hta' hka, ?_,
        _root_.add_le_add htb' hkb, ?_⟩
      · rw [hKn]; exact _root_.add_le_add hta hkaK
      · rw [hKn]; exact _root_.add_le_add htb hkbK
      · rw [runA_add, runB_add]; exact hs

'''
s=s.replace(include,helper+include,1)
body='''  have h0 : Rel reg live cert N (live (e.a : V) x) (live (e.b : V) x) := by
    obtain ⟨e', he', _, _, _, hpos⟩ := entryOK_spec rowsA rowsB cert fuel N 0 (hcheck 0 hN)
    rw [he] at he'
    cases he'
    exact rel_of_entry 0 hN e he hpos x x x
      (fun p => by rw [hα p]; simp) (fun p => by rw [hβ p]; simp)
  obtain ⟨ta, tb, hta, hta', htb, htb', hq⟩ := bounded_clocks
    fileOf reg_fileOf liveDef regDef stepA stepB runA runB rowsA rowsB cert fuel N
    runA_zero runB_zero runA_add runB_add runA_one runB_one runA_halted runB_halted
    specA specB reg_write_same reg_write_other hcheck _ _ h0 t
'''
forward=body+'''  have hz : runB tb (live (e.b : V) x) = 0 := by
    rw [← add_tsub_cancel_of_le htb', runB_add, ht, runB_halted]
  rcases hq with ⟨hza, _⟩ | hr
  · exact ⟨ta, hta, hza⟩
  · obtain ⟨_, _, _, _, _, _, _, _, hb, _, _⟩ := rel_entry _ _ hr
    exact absurd hz (hb ▸ live_ne _ _)
'''
reverse=body+'''  have hz : runA ta (live (e.a : V) x) = 0 := by
    rw [← add_tsub_cancel_of_le hta', runA_add, ht, runA_halted]
  rcases hq with ⟨_, hzb⟩ | hr
  · exact ⟨tb, htb, hzb⟩
  · obtain ⟨_, _, _, _, _, _, _, ha, _, _, _⟩ := rel_entry _ _ hr
    exact absurd hz (ha ▸ live_ne _ _)
'''
def replace(s,name,body):
 i=s.index(' := by\n',s.index('theorem '+name))+len(' := by\n');j=s.index('\nend Main',i);return s[:i]+body+s[j:]
s=replace(s,'halts_le_of_check ',forward);t=replace(t,'halts_le_of_check_rev ',reverse)
p.write_text(s);q.write_text(t)
