from pathlib import Path
import json,re,hashlib
R=Path('/tmp/bisim-share');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean')];seen={};order=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def visit(n):
 if n in seen:return
 rel=n.replace('.','/');p=next((x/(rel+'.lean') for x in roots if (x/(rel+'.lean')).is_file()),None)
 if not p:return
 im=[]
 for line in p.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:im.extend([d for d in m.group(1).split() if d.startswith(('DiophantineConsistency.','BusyBeaver.'))])
 seen[n]={'source':str(p),'source_sha256':sha(p),'imports':im}
 for d in im:visit(d)
 order.append(n)
for n in ['ArithmeticRuntimeBound215','ArithmeticRefutationHaltBound']:visit('DiophantineConsistency.'+n)
libs=[Path('/tmp/runtime215-root-_hxbq4kn/lib'),Path('/tmp/outer-seed-bound-sharing/assembly-common'),Path('/tmp/control-bisim-perm215-root-1czao7t5/lib')]
for n,v in seen.items():
 o=n.replace('.','/')+'.olean';v['candidates']=[str(p/o) for p in libs if (p/o).exists()]
missing=[n for n in order if not seen[n]['candidates'] and n.startswith('DiophantineConsistency.')];(R/'client-inventory.json').write_text(json.dumps({'nodes':seen,'order':order,'missing_dc':missing,'scanned_libs':list(map(str,libs))},indent=2)+'\n');print('nodes',len(seen),'dc missing',len(missing));print('\n'.join(missing))
