from pathlib import Path
import json,hashlib
R=Path('/tmp/bisim-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();results=[];fail=[]
for file in ['paired-records.json','axiom-records.json','forward-build-records.json','forward-phase-records.json']:
 for x in json.load(open(R/file)):
  name=x.get('name',x.get('module'));ident=file+':'+str(x.get('phase',''))+':'+str(name)
  checks={}
  for label,pathkey,hashkey in [('source','source','source_sha256'),('log','log','log_sha256'),('object','object','object_sha256')]:
   p=x.get(pathkey);expected=x.get(hashkey)
   if p and expected:
    checks[label]=Path(p).is_file() and h(p)==expected
    if not checks[label]:fail.append(ident+' '+label)
  if 'source_after' in x:
   checks['source_before_after']=x['source_sha256']==x['source_after']
   if not checks['source_before_after']:fail.append(ident+' source changed')
  for d in x.get('direct_project_inputs',[]):
   ok=Path(d['object']).is_file() and h(d['object'])==d['sha256']
   if not ok:fail.append(ident+' dependency '+d['module'])
  checks['direct_project_input_count']=len(x.get('direct_project_inputs',[]));results.append({'record':ident,'status':x['status'],'checks':checks})
for p in [R/'prior-141-pins.json']:
 for x in json.load(open(p)):
  for k in ['source','object']:
   if not Path(x[k]).is_file() or h(x[k])!=x[k+'_sha256']:fail.append('prior pin '+x['module']+' '+k)
common=json.load(open(R/'forward-common-pins.json'))
client=json.load(open(R/'client-pins.json'))
by_module={x['module']:x for x in client['selected']}
for x in common['selected']:
 p=R/'forward-common'/(x['module'].replace('.','/')+'.olean')
 q=by_module[x['module']]
 if not p.is_file() or h(p)!=x['object_sha256'] or not q['source_receipt_match'] or not q['object_receipt_match'] or h(x['source'])!=x['source_sha256']:fail.append('borrowed pin '+x['module'])
for f in ['forward-companions.json','forward-ir-pins.json']:
 for x in json.load(open(R/f)):
  if not Path(x['path']).is_file() or h(x['path'])!=x['sha256']:fail.append('companion '+x['path'])
for n in ['ArithmeticRuntimeBoundBisim','ArithmeticRuntimeBoundBisimReverse']:
 a=R/'final/DiophantineConsistency'/f'{n}.lean'; b=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/f'{n}.lean'
 if h(a)!=h(b):fail.append('applied file '+n)
for f in ['names-comparison.json']:
 x=json.load(open(R/f));
 if x['removed']:fail.append('removed declarations')
for a,b in [('baseline-axioms.log','final-axioms.log'),('forward-baseline-axioms.log','forward-final-axioms.log'),('forward-baseline-target.log','forward-final-target.log')]:
 if (R/a).read_bytes()!=(R/b).read_bytes():fail.append('logs differ '+a+' '+b)
obj={'results':results,'prior_pins_checked':141,'borrowed_project_pins_checked':len(common['selected']),'companion_lists_checked':['forward-companions.json','forward-ir-pins.json'],'failures':fail};(R/'package-audit.json').write_text(json.dumps(obj,indent=2)+'\n');print('records',len(results),'prior pins',141,'failures',len(fail));print('\n'.join(fail));assert not fail
