from pathlib import Path
import json,hashlib,os
R=Path('/tmp/bisim-share');dst=R/'forward-common';dst.mkdir(exist_ok=True);h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();libs=[Path('/tmp/control-bisim-perm215-root-1czao7t5/lib'),Path('/tmp/runtime215-root-_hxbq4kn/lib'),Path('/tmp/enum-soundnessperm222-root-peer-wmzrngb7/lib')];plan=json.load(open(R/'forward-plan.json'));count=0;overlap=0
for lib in libs:
 for p in lib.rglob('*.olean'):
  rel=p.relative_to(lib);q=dst/rel;q.parent.mkdir(parents=True,exist_ok=True)
  if q.exists():
   assert h(p)==h(q),str(rel);overlap+=1
  else:q.symlink_to(p.resolve());count+=1
f=Path('/home/codex/src/Proofs/.lake/build/lib/lean/Foundation')
for p in f.rglob('*.olean'):
 q=dst/'Foundation'/p.relative_to(f);q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert h(p)==h(q),str(q);overlap+=1
 else:q.symlink_to(p.resolve());count+=1
for n in plan['build_order']+plan['targets']:
 p=dst/(n.replace('.','/')+'.olean');p.unlink(missing_ok=True)
records=[]
for n,v in plan['nodes'].items():
 p=dst/(n.replace('.','/')+'.olean')
 if p.exists():records.append({'module':n,'source':str(Path(v['source']).resolve()),'source_sha256':h(v['source']),'object':str(p.resolve()),'object_sha256':h(p),'imports':v['imports']})
meta={'libraries':[str(p) for p in libs],'canonical_foundation':str(f),'added_objects':count,'byte_identical_overlaps':overlap,'selected':records};(R/'forward-common-pins.json').write_text(json.dumps(meta,indent=2)+'\n');print('selected reachable',len(records),'added',count,'overlaps',overlap,flush=True)
