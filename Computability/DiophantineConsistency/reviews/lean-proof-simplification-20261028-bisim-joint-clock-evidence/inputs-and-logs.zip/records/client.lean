import DiophantineConsistency.ArithmeticRuntimeBoundBisimReverse
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open SetTheory.BusyBeaver.ZFC
open DiophantineConsistency.ArithmeticRuntimeBoundBisim
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (x t : V) (h : ArithmeticControl215Table.run215 t (ArithmeticControlFile.liveValue 1 x) = 0) :
    ∃ k ≤ 7*t, ArithmeticDagControlPerm222.run k (ArithmeticControlFile.liveValue 1 x) = 0 :=
  dag_halts_le_of_215 x t h
example (x t : V) (h : ArithmeticDagControlPerm222.run t (ArithmeticControlFile.liveValue 1 x) = 0) :
    ∃ k ≤ 7*t, ArithmeticControl215Table.run215 k (ArithmeticControlFile.liveValue 1 x) = 0 :=
  p215_halts_le_of_dag x t h
