from pathlib import Path
import json
R=Path('/tmp/bisim-share');g=json.load(open(R/'client-inventory.json'));pins=json.load(open(R/'client-pins.json'));ns=g['nodes'];root='DiophantineConsistency.ArithmeticRuntimeBound215';seen=set()
def walk(n):
 if n in seen or n not in ns:return
 seen.add(n)
 for x in ns[n]['imports']:walk(x)
walk(root);seeds={x['module'] for x in pins['unmatched']} & seen;affected=set(seeds)
for n in g['order']:
 if n in seen and any(x in affected for x in ns[n]['imports']):affected.add(n)
missing={x for x in pins['missing'] if x in seen};targets={'DiophantineConsistency.ArithmeticRuntimeBoundBisim',root};build=[n for n in g['order'] if n in (affected|missing)-targets];plan={'root':root,'seeds':sorted(seeds),'nodes':{n:ns[n] for n in seen},'affected':sorted(affected),'missing':sorted(missing),'build_order':build,'targets':sorted(targets)};(R/'forward-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('seeds',len(seeds),'affected',len(affected),'missing',len(missing),'prereq builds',len(build));print('\n'.join(build))
