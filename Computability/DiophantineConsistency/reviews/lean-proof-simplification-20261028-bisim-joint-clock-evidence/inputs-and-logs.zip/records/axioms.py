from pathlib import Path
import os,subprocess,hashlib,json,time
R=Path('/tmp/bisim-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
def run(phase,name,src):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':/tmp/control-bisim-perm215-root-1czao7t5/lib:'+base
 log=R/f'{phase}-{name}.log';tm=R/f'{phase}-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false',str(src)];pre=h(src);now=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'phase':phase,'name':name,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'elapsed':time.monotonic()-now,'source':str(src),'source_sha256':pre,'source_after':h(src),'log':str(log),'log_sha256':h(log),'timing':tm.read_text()};records.append(d);(R/'axiom-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,p.returncode,round(d['elapsed'],1),flush=True)
 if p.returncode or pre!=d['source_after']:raise SystemExit(1)
for phase in ['baseline','final']:run(phase,'client',R/'client.lean')
for phase in ['baseline','final']:run(phase,'names',R/'names.lean')
parse=lambda p:sorted(set(x.removeprefix('DECL ') for x in p.read_text().splitlines() if x.startswith('DECL ')))
a=parse(R/'baseline-names.log');b=parse(R/'final-names.log');removed=sorted(set(a)-set(b));added=sorted(set(b)-set(a));(R/'names-comparison.json').write_text(json.dumps({'baseline':a,'final':b,'removed':removed,'added':added},indent=2)+'\n');print('names',len(a),'removed',removed,'added',added,flush=True)
if removed:raise SystemExit(2)
probe=R/'axioms.lean';probe.write_text('import DiophantineConsistency.ArithmeticRuntimeBoundBisimReverse\nset_option pp.all true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in a))
for phase in ['baseline','final']:run(phase,'axioms',probe)
if (R/'baseline-axioms.log').read_bytes()!=(R/'final-axioms.log').read_bytes():raise SystemExit('old declaration check/axiom reports differ')
if added:
 probe=R/'new-axioms.lean';probe.write_text('import DiophantineConsistency.ArithmeticRuntimeBoundBisimReverse\n'+''.join('#print axioms '+n+'\n' for n in added));run('final','new-axioms',probe)
