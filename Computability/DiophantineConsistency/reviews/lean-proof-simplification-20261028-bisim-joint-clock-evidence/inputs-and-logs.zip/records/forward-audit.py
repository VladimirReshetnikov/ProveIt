from pathlib import Path
import json,hashlib
R=Path('/tmp/bisim-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();plan=json.load(open(R/'forward-plan.json'));build=json.load(open(R/'forward-build-records.json'));inputs=json.load(open(R/'forward-common-pins.json'));assert len(build)==len(plan['build_order']);assert [x['module'] for x in build]==plan['build_order'];library=R/'forward-common';issues=[]
for n,v in plan['nodes'].items():
 p=Path(v['source']);
 if not p.exists() or h(p)!=v['source_sha256']:issues.append('changed source '+n)
for x in build:
 if x['status'] or x['source_sha256']!=x['source_after'] or h(x['object'])!=x['object_sha256'] or h(x['log'])!=x['log_sha256']:issues.append('bad build '+x['module'])
 for d in x['direct_project_inputs']:
  p=library/(d['module'].replace('.','/')+'.olean')
  if not p.exists() or h(p)!=d['sha256']:issues.append('changed build input '+x['module']+' -> '+d['module'])
for x in inputs['selected']:
 p=library/(x['module'].replace('.','/')+'.olean')
 if not p.exists() or h(p)!=x['object_sha256']:issues.append('changed borrowed input '+x['module'])
for nm in ['forward-companions.json','forward-ir-pins.json']:
 for x in json.load(open(R/nm)):
  if not Path(x['path']).exists() or h(x['path'])!=x['sha256']:issues.append('changed companion '+x['path'])
summary={'planned':len(plan['build_order']),'completed':len(build),'borrowed':len(inputs['selected']),'issues':issues,'warnings':sum(Path(x['log']).read_text().count('warning:') for x in build)};(R/'forward-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));assert not issues
