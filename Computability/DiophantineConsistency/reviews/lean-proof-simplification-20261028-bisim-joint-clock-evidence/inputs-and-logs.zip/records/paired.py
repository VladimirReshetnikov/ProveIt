from pathlib import Path
import os,subprocess,hashlib,json,time
R=Path('/tmp/bisim-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
def run(phase,name,src,root=None,output=None,allow=False):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':/tmp/control-bisim-perm215-root-1czao7t5/lib:'+base
 log=R/f'{phase}-{name}.log';tm=R/f'{phase}-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false']
 if root:cmd+=['-R',str(root)]
 cmd += [str(src)]
 if output:output.unlink(missing_ok=True);cmd+=['-o',str(output)]
 pre=h(src);now=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 d={'phase':phase,'name':name,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'elapsed':time.monotonic()-now,'source':str(src),'source_sha256':pre,'source_after':h(src),'log':str(log),'log_sha256':h(log),'timing':tm.read_text(),'object':str(output) if output else None,'object_sha256':h(output) if output and output.exists() else None};records.append(d);(R/'paired-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,p.returncode,round(d['elapsed'],1),flush=True)
 if not allow and (p.returncode or pre!=d['source_after']):raise SystemExit(1)
for phase in ['baseline','final']:
 for name in ['ArithmeticRuntimeBoundBisim','ArithmeticRuntimeBoundBisimReverse']:
  src=R/phase/'DiophantineConsistency'/f'{name}.lean';run(phase,name,src,R/phase,src.with_suffix('.olean'))
root=Path('Computability/DiophantineConsistency/Lean')
for phase in ['baseline','final']:
 for name in ['ArithmeticRuntimeBound215','ArithmeticRefutationHaltBound']:
  src=root/'DiophantineConsistency'/f'{name}.lean';run(phase,name,src,root,None,True)
