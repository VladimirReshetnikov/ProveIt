import DiophantineConsistency.ArithmeticProofWordBoundLevel
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open _root_.SetTheory.BusyBeaver.ZFC ArithmeticCantor ArithmeticCode254
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (x y : V) : cantor x y ≤ (x + y + 1) * (x + y + 1) := by
  rw [show (x+y+1)*(x+y+1) = (x+y)*(x+y+1)+(x+y+1) by ring]
  exact le_trans (cantor_polybound x y)
    (_root_.add_le_add le_rfl (le_trans le_add_self le_self_add))
