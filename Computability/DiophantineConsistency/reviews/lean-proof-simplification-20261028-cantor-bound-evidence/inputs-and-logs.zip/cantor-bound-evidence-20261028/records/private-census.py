from pathlib import Path
import os,re,subprocess,hashlib,json
r=Path('/tmp/cantor-bound-simplify');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
def run(lane,phase,probe):
 overlay=r/f'{lane}-{phase}';source=r/f'{lane}-{probe}.lean';env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+lp;log=r/f'{lane}-{phase}-{probe}.log';tm=r/f'{lane}-{phase}-{probe}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(source)];before=sha(source)
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'lane':lane,'phase':phase,'probe':probe,'source':str(source),'before':before,'after':sha(source),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log)};records.append(row);(r/'private-records.json').write_text(json.dumps(records,indent=2));print(lane,phase,probe,q.returncode,flush=True)
 if q.returncode or before!=row['after']:raise SystemExit(1)
for lane,mod in [('level','ArithmeticProofWordBoundLevel'),('tower','ArithmeticEnumBoundTower')]:
 ns='DiophantineConsistency.'+mod;priv='_private.'+ns
 text=f'import {ns}\nimport Lean.Util.CollectAxioms\n'+'''open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
'''+f'    if (`{priv}).isPrefixOf n then\n'+'''      let typ ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let axioms ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {typ} AXIOMS {axioms}"
'''
 (r/f'{lane}-private.lean').write_text(text)
 for phase in ['baseline','final']:run(lane,phase,'private')
 print(lane,'private reports equal',(r/f'{lane}-baseline-private.log').read_bytes()==(r/f'{lane}-final-private.log').read_bytes(),flush=True)
