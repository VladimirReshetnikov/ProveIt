from pathlib import Path
import os,re,subprocess,hashlib,json
r=Path('/tmp/cantor-bound-simplify');base=Path('Computability/DiophantineConsistency/Lean');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=[]
for lane,target,client in [('level','ArithmeticProofWordBoundLevel','ArithmeticProofWordBound'),('tower','ArithmeticEnumBoundTower','ArithmeticRuntimeBoundDagMacrosA')]:
 for phase in ['baseline','final']:
  overlay=r/f'{lane}-{phase}';env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+lp;roots=[Path(x) for x in env['LEAN_PATH'].split(':')]
  for name in [target,client]:
   source=(r/'src/DiophantineConsistency'/f'{name}.lean') if phase=='final' and name==target else base/'DiophantineConsistency'/f'{name}.lean';root=r/'src' if str(source).startswith(str(r/'src')) else base;before=sha(source);deps=re.findall(r'^import\s+(\S+)',source.read_text(),re.M);inputs={}
   for d in deps:
    obj=next((x/(d.replace('.','/')+'.olean') for x in roots if (x/(d.replace('.','/')+'.olean')).is_file()),None)
    if obj is None:raise Exception(f'missing {d} for {lane} {phase} {name}')
    inputs[d]={'path':str(obj.resolve()),'before':sha(obj)}
   out=overlay/'DiophantineConsistency'/f'{name}.olean';out.unlink(missing_ok=True);log=r/f'{lane}-{phase}-{name}.log';tm=r/f'{lane}-{phase}-{name}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(source),'-o',str(out)]
   with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   for x in inputs.values():x['after']=sha(Path(x['path']))
   row={'lane':lane,'phase':phase,'name':name,'source':str(source),'before':before,'after':sha(source),'inputs':inputs,'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};rec.append(row);(r/'build-records.json').write_text(json.dumps(rec,indent=2));print(lane,phase,name,q.returncode,row['time'].strip(),flush=True)
   if q.returncode or before!=row['after'] or any(x['before']!=x['after'] for x in inputs.values()):raise SystemExit(1)
