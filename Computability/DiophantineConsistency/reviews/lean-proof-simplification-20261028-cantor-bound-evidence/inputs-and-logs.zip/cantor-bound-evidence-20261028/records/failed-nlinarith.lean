import DiophantineConsistency.ArithmeticProofWordBoundLevel
open LO LO.FirstOrder LO.FirstOrder.Arithmetic
open scoped LO.FirstOrder.Arithmetic
open _root_.SetTheory.BusyBeaver.ZFC ArithmeticCantor
variable {V : Type*} [ORingStructure V] [V↓[ℒₒᵣ] ⊧* 𝗜𝚺₁]
example (x y : V) : cantor x y ≤ (x + y + 1) * (x + y + 1) := by
  have h := cantor_polybound x y
  have hy : y ≤ x + y + 1 := le_trans le_add_self le_self_add
  nlinarith
