from pathlib import Path
import os,re,subprocess,hashlib,json
r=Path('/tmp/cantor-bound-simplify');lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
def run(lane,phase,probe):
 overlay=r/f'{lane}-{phase}';source=r/f'{lane}-{probe}.lean';env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+lp;log=r/f'{lane}-{phase}-{probe}.log';tm=r/f'{lane}-{phase}-{probe}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(source)];before=sha(source)
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'lane':lane,'phase':phase,'probe':probe,'source':str(source),'before':before,'after':sha(source),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':q.returncode,'time':tm.read_text(),'log_sha256':sha(log)};records.append(row);(r/'census-records.json').write_text(json.dumps(records,indent=2));print(lane,phase,probe,q.returncode,flush=True)
 if q.returncode or before!=row['after']:raise SystemExit(1)
for lane,mod,defs in [('level','ArithmeticProofWordBoundLevel',['lev','levDef','cb']),('tower','ArithmeticEnumBoundTower',['tower','depth'])]:
 ns='DiophantineConsistency.'+mod; priv='_private.'+ns
 text=f'import {ns}\n'+''.join(f'#print equations {ns}.{d}\n' for d in defs)+'''open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
'''+f'    if (`{ns}).isPrefixOf n || (`{priv}).isPrefixOf n then\n'+'''      logInfo m!"DECL {n}"
      if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
         t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
        logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
'''
 (r/f'{lane}-names.lean').write_text(text)
 for phase in ['baseline','final']:run(lane,phase,'names')
 def sets(p,prefix):return {s.split(prefix,1)[1].strip() for s in p.read_text().splitlines() if prefix in s}
 a=sets(r/f'{lane}-baseline-names.log','DECL ');b=sets(r/f'{lane}-final-names.log','DECL ');sa=sets(r/f'{lane}-baseline-names.log','SIMP ');sb=sets(r/f'{lane}-final-names.log','SIMP ');print(lane,'names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),'simp equal',sa==sb,flush=True)
 common=sorted(n for n in a&b if not n.startswith('_private.'))
 (r/f'{lane}-interfaces.lean').write_text('import '+ns+'\nset_option pp.universes true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in common))
 for phase in ['baseline','final']:run(lane,phase,'interfaces')
 print(lane,'common',len(common),'interfaces equal',(r/f'{lane}-baseline-interfaces.log').read_bytes()==(r/f'{lane}-final-interfaces.log').read_bytes(),flush=True)
