import os,subprocess,sys,time,hashlib,json
from pathlib import Path
root=Path('/tmp/arith-mask-reuse-20261028');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
items=[]
for tag in ('axioms','boundaries','foundation'):
 p=root/(tag+'.lean');cmd=['lean','-M6000','-j1','-DElab.async=false','-R','Computability/DiophantineConsistency/Lean',str(p)]
 t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log=root/(phase+'-'+tag+'.log');log.write_bytes(v.stdout+v.stderr)
 items.append({'tag':tag,'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (root/(phase+'-checks.json')).write_text(json.dumps(items,indent=2)+'\n');print(phase,tag,v.returncode,flush=True)
