import DiophantineConsistency.MFDoubledClause2011

def probeMask : ℕ := 2 ^ 45 - 4

theorem probe (x : ℕ) : x &&& probeMask = 0 ↔ x % 2 ^ 45 ≤ 3 := by
  exact DiophantineConsistency.MF.DoubledClause2011.mask_iff x
#print axioms probe
