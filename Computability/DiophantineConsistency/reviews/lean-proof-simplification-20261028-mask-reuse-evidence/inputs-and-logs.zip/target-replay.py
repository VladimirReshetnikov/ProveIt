import os,subprocess,sys,time,json,hashlib
from pathlib import Path
r=Path('/tmp/arith-mask-reuse-20261028');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+env.get('LEAN_PATH','')
if phase=='baseline2':src=r/'original-source/DiophantineConsistency/ArithmeticCellLabels.lean';module_root=r/'original-source'
else:src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticCellLabels.lean');module_root=Path('Computability/DiophantineConsistency/Lean')
obj=r/phase/'DiophantineConsistency/ArithmeticCellLabels.olean';cmd=['lean','-M6000','-j1','-DElab.async=false','-R',str(module_root),str(src),'-o',str(obj)]
t=time.monotonic();v=subprocess.run(cmd,env=env,capture_output=True);log=r/(phase+'-replay.log');log.write_bytes(v.stdout+v.stderr)
x={'cmd':cmd,'status':v.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
if not v.returncode:x.update(object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),object_bytes=obj.stat().st_size)
(r/(phase+'-target-record.json')).write_text(json.dumps(x,indent=2)+'\n');print(phase,'target',v.returncode,flush=True)
sys.exit(v.returncode)
