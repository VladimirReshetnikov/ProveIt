import DiophantineConsistency.ArithmeticCellLabels
open DiophantineConsistency.ArithmeticCellLabels.DC
example : (3 &&& mask) = 0 := (mask_iff 3).2 (by decide)
example : ¬ (4 &&& mask) = 0 := by intro h; have := (mask_iff 4).1 h; norm_num at this
example : ((2^45 + 3) &&& mask) = 0 := (mask_iff (2^45+3)).2 (by decide)
