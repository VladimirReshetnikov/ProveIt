from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/controller-two-proof-20261028');pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';mode=sys.argv[1]
if mode=='prep':items=[(Path(s).stem,s,True) for s in json.loads((p/'prep-order.json').read_text())]
elif mode=='baseline':items=[(n,pre+n+'.lean',True) for n in ['CurrentControllerUnits2011','CurrentControllerSubsets2011']]+[(n+'-axioms',str(p/(n+'-axioms.lean')),False) for n in ['CurrentControllerUnits2011','CurrentControllerSubsets2011']]
elif mode=='final':items=[(n,pre+n+'.lean',True) for n in ['CurrentControllerUnits2011','CurrentControllerSubsets2011']]+[(n+'-axioms',str(p/(n+'-axioms.lean')),False) for n in ['CurrentControllerUnits2011','CurrentControllerSubsets2011']]+[(n,pre+n+'.lean',False) for n in ['CurrentControllerUnits2011Checks','CurrentControllerSubsets2011Checks','CurrentSafeController2011']]
else:raise SystemExit('bad mode')
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free<65*1024**2:raise SystemExit('insufficient disk before '+name)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 output=p/'overlay/DiophantineConsistency'/(name+'.olean')
 if obj:argv+=['-o',str(output)]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/controller-two-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-t
 log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 sh=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
 rec={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'free_before':free,'source':source,'source_sha256':sh(source),'log':str(log),'log_sha256':sh(log)}
 if obj and r.returncode==0:rec.update({'object':str(output),'object_sha256':sh(output),'object_bytes':output.stat().st_size})
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
