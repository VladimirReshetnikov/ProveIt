import hashlib,json
from pathlib import Path
p=Path('/tmp/gates-semiring-sharing'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for r in json.loads((p/'records.json').read_text()):
 cmd=r['command']; src=[x for x in cmd if x.endswith('.lean')];assert len(src)==1
 assert r['status']==0 and r['source_sha256']==r['source_after']==h(src[0]);assert r['lean_path'].split(':')[0].endswith(r['phase'])
 assert h(cmd[4])==r['time_sha256'] and h(cmd[-1])==r['object_sha256'] and h(p/(r['phase']+'-'+r['tag']+'.log'))==r['log_sha256']
print('Four target/client build receipts verified')
for suffix in ('interface.log','names.log','equations.log'):
 assert (p/('baseline-'+suffix)).read_bytes()==(p/('final-'+suffix)).read_bytes();print(suffix,'identical')
print('Scope: paired targets/client and retained namespace probes; transitive and package inputs precompiled.')
