import pathlib,json,os,hashlib,subprocess
P=pathlib.Path('/tmp/gates-semiring-sharing');prior=pathlib.Path('/tmp/enumerator-recursor-sharing/final-coherent');r=json.loads(pathlib.Path('/tmp/enumerator-recursor-sharing/coherent-client-records.json').read_text())[0];lp=r['lean_path'].split(':',1)[1];h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();rec=[]
for phase in ['baseline','final']:
 root=P/phase;d=root/'DiophantineConsistency'
 for f in prior.iterdir():
  if f.name=='DiophantineConsistency':continue
  q=root/f.name
  if not q.exists():q.symlink_to(f.resolve(),target_is_directory=f.is_dir())
 for f in (prior/'DiophantineConsistency').iterdir():
  if f.name.startswith(('GatesSemiring.','QuarticSemiring.')):continue
  q=d/f.name
  if not q.exists() and not q.is_symlink():q.symlink_to(f.resolve(),target_is_directory=f.is_dir())
 env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp
 for tag,src,srcroot,out in [('target',d/'GatesSemiring.lean',root,d/'GatesSemiring.olean'),('client',pathlib.Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/QuarticSemiring.lean'),'Computability/DiophantineConsistency/Lean',d/'QuarticSemiring.olean')]:
  out.unlink(missing_ok=True);log=P/f'{phase}-{tag}.log';tm=P/f'{phase}-{tag}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(out)];before=h(src)
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  z={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'object_sha256':h(out) if out.exists() else None};rec.append(z);(P/'records.json').write_text(json.dumps(rec,indent=2));print(phase,tag,q.returncode,flush=True)
  if q.returncode:raise SystemExit(q.returncode)
