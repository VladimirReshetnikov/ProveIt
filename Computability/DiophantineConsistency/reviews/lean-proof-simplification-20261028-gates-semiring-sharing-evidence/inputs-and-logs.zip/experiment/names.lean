import DiophantineConsistency.GatesSemiring
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.Expr).isPrefixOf n || (`DiophantineConsistency.QuarticCompiler.Gates).isPrefixOf n then
      logInfo m!"{n}"
