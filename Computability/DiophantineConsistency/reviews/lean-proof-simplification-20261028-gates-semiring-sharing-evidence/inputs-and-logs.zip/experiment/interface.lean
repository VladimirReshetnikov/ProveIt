import DiophantineConsistency.GatesSemiring
set_option pp.all true
set_option linter.auxLemma false
#check DiophantineConsistency.Expr
#print axioms DiophantineConsistency.Expr
#check DiophantineConsistency.Expr.SemiringZero
#print axioms DiophantineConsistency.Expr.SemiringZero
#check DiophantineConsistency.Expr.SemiringZero.eq_1
#print axioms DiophantineConsistency.Expr.SemiringZero.eq_1
#check DiophantineConsistency.Expr._sizeOf_1
#print axioms DiophantineConsistency.Expr._sizeOf_1
#check DiophantineConsistency.Expr._sizeOf_inst
#print axioms DiophantineConsistency.Expr._sizeOf_inst
#check DiophantineConsistency.Expr.add
#print axioms DiophantineConsistency.Expr.add
#check DiophantineConsistency.Expr.add.elim
#print axioms DiophantineConsistency.Expr.add.elim
#check DiophantineConsistency.Expr.add.inj
#print axioms DiophantineConsistency.Expr.add.inj
#check DiophantineConsistency.Expr.add.injEq
#print axioms DiophantineConsistency.Expr.add.injEq
#check DiophantineConsistency.Expr.add.noConfusion
#print axioms DiophantineConsistency.Expr.add.noConfusion
#check DiophantineConsistency.Expr.add.sizeOf_spec
#print axioms DiophantineConsistency.Expr.add.sizeOf_spec
#check DiophantineConsistency.Expr.below
#print axioms DiophantineConsistency.Expr.below
#check DiophantineConsistency.Expr.brecOn
#print axioms DiophantineConsistency.Expr.brecOn
#check DiophantineConsistency.Expr.brecOn.eq
#print axioms DiophantineConsistency.Expr.brecOn.eq
#check DiophantineConsistency.Expr.brecOn.go
#print axioms DiophantineConsistency.Expr.brecOn.go
#check DiophantineConsistency.Expr.casesOn
#print axioms DiophantineConsistency.Expr.casesOn
#check DiophantineConsistency.Expr.constant
#print axioms DiophantineConsistency.Expr.constant
#check DiophantineConsistency.Expr.constant.elim
#print axioms DiophantineConsistency.Expr.constant.elim
#check DiophantineConsistency.Expr.constant.inj
#print axioms DiophantineConsistency.Expr.constant.inj
#check DiophantineConsistency.Expr.constant.injEq
#print axioms DiophantineConsistency.Expr.constant.injEq
#check DiophantineConsistency.Expr.constant.noConfusion
#print axioms DiophantineConsistency.Expr.constant.noConfusion
#check DiophantineConsistency.Expr.constant.sizeOf_spec
#print axioms DiophantineConsistency.Expr.constant.sizeOf_spec
#check DiophantineConsistency.Expr.ctorElim
#print axioms DiophantineConsistency.Expr.ctorElim
#check DiophantineConsistency.Expr.ctorElimType
#print axioms DiophantineConsistency.Expr.ctorElimType
#check DiophantineConsistency.Expr.ctorIdx
#print axioms DiophantineConsistency.Expr.ctorIdx
#check DiophantineConsistency.Expr.eval
#print axioms DiophantineConsistency.Expr.eval
#check DiophantineConsistency.Expr.eval._f
#print axioms DiophantineConsistency.Expr.eval._f
#check DiophantineConsistency.Expr.eval._sunfold
#print axioms DiophantineConsistency.Expr.eval._sunfold
#check DiophantineConsistency.Expr.eval._unsafe_rec
#print axioms DiophantineConsistency.Expr.eval._unsafe_rec
#check DiophantineConsistency.Expr.eval.eq_1
#print axioms DiophantineConsistency.Expr.eval.eq_1
#check DiophantineConsistency.Expr.eval.eq_2
#print axioms DiophantineConsistency.Expr.eval.eq_2
#check DiophantineConsistency.Expr.eval.eq_3
#print axioms DiophantineConsistency.Expr.eval.eq_3
#check DiophantineConsistency.Expr.eval.eq_4
#print axioms DiophantineConsistency.Expr.eval.eq_4
#check DiophantineConsistency.Expr.eval.eq_5
#print axioms DiophantineConsistency.Expr.eval.eq_5
#check DiophantineConsistency.Expr.eval.eq_def
#print axioms DiophantineConsistency.Expr.eval.eq_def
#check DiophantineConsistency.Expr.eval_add
#print axioms DiophantineConsistency.Expr.eval_add
#check DiophantineConsistency.Expr.eval_constant
#print axioms DiophantineConsistency.Expr.eval_constant
#check DiophantineConsistency.Expr.eval_eq_zero_iff_splitNatural
#print axioms DiophantineConsistency.Expr.eval_eq_zero_iff_splitNatural
#check DiophantineConsistency.Expr.eval_mul
#print axioms DiophantineConsistency.Expr.eval_mul
#check DiophantineConsistency.Expr.eval_pow
#print axioms DiophantineConsistency.Expr.eval_pow
#check DiophantineConsistency.Expr.eval_rename
#print axioms DiophantineConsistency.Expr.eval_rename
#check DiophantineConsistency.Expr.eval_splitNatural
#print axioms DiophantineConsistency.Expr.eval_splitNatural
#check DiophantineConsistency.Expr.eval_sub
#print axioms DiophantineConsistency.Expr.eval_sub
#check DiophantineConsistency.Expr.eval_subst
#print axioms DiophantineConsistency.Expr.eval_subst
#check DiophantineConsistency.Expr.eval_toPolynomial
#print axioms DiophantineConsistency.Expr.eval_toPolynomial
#check DiophantineConsistency.Expr.eval_var
#print axioms DiophantineConsistency.Expr.eval_var
#check DiophantineConsistency.Expr.instAdd
#print axioms DiophantineConsistency.Expr.instAdd
#check DiophantineConsistency.Expr.instMul
#print axioms DiophantineConsistency.Expr.instMul
#check DiophantineConsistency.Expr.instNeg
#print axioms DiophantineConsistency.Expr.instNeg
#check DiophantineConsistency.Expr.instOfNat
#print axioms DiophantineConsistency.Expr.instOfNat
#check DiophantineConsistency.Expr.instPowNat
#print axioms DiophantineConsistency.Expr.instPowNat
#check DiophantineConsistency.Expr.instSub
#print axioms DiophantineConsistency.Expr.instSub
#check DiophantineConsistency.Expr.mul
#print axioms DiophantineConsistency.Expr.mul
#check DiophantineConsistency.Expr.mul.elim
#print axioms DiophantineConsistency.Expr.mul.elim
#check DiophantineConsistency.Expr.mul.inj
#print axioms DiophantineConsistency.Expr.mul.inj
#check DiophantineConsistency.Expr.mul.injEq
#print axioms DiophantineConsistency.Expr.mul.injEq
#check DiophantineConsistency.Expr.mul.noConfusion
#print axioms DiophantineConsistency.Expr.mul.noConfusion
#check DiophantineConsistency.Expr.mul.sizeOf_spec
#print axioms DiophantineConsistency.Expr.mul.sizeOf_spec
#check DiophantineConsistency.Expr.noConfusion
#print axioms DiophantineConsistency.Expr.noConfusion
#check DiophantineConsistency.Expr.noConfusionType
#print axioms DiophantineConsistency.Expr.noConfusionType
#check DiophantineConsistency.Expr.pow
#print axioms DiophantineConsistency.Expr.pow
#check DiophantineConsistency.Expr.pow._f
#print axioms DiophantineConsistency.Expr.pow._f
#check DiophantineConsistency.Expr.pow._sunfold
#print axioms DiophantineConsistency.Expr.pow._sunfold
#check DiophantineConsistency.Expr.pow._unsafe_rec
#print axioms DiophantineConsistency.Expr.pow._unsafe_rec
#check DiophantineConsistency.Expr.pow.eq_1
#print axioms DiophantineConsistency.Expr.pow.eq_1
#check DiophantineConsistency.Expr.pow.eq_2
#print axioms DiophantineConsistency.Expr.pow.eq_2
#check DiophantineConsistency.Expr.pow.eq_def
#print axioms DiophantineConsistency.Expr.pow.eq_def
#check DiophantineConsistency.Expr.pow.match_1
#print axioms DiophantineConsistency.Expr.pow.match_1
#check DiophantineConsistency.Expr.rec
#print axioms DiophantineConsistency.Expr.rec
#check DiophantineConsistency.Expr.recOn
#print axioms DiophantineConsistency.Expr.recOn
#check DiophantineConsistency.Expr.rename
#print axioms DiophantineConsistency.Expr.rename
#check DiophantineConsistency.Expr.rename._f
#print axioms DiophantineConsistency.Expr.rename._f
#check DiophantineConsistency.Expr.rename._sunfold
#print axioms DiophantineConsistency.Expr.rename._sunfold
#check DiophantineConsistency.Expr.rename._unsafe_rec
#print axioms DiophantineConsistency.Expr.rename._unsafe_rec
#check DiophantineConsistency.Expr.rename.eq_1
#print axioms DiophantineConsistency.Expr.rename.eq_1
#check DiophantineConsistency.Expr.rename.eq_2
#print axioms DiophantineConsistency.Expr.rename.eq_2
#check DiophantineConsistency.Expr.rename.eq_3
#print axioms DiophantineConsistency.Expr.rename.eq_3
#check DiophantineConsistency.Expr.rename.eq_4
#print axioms DiophantineConsistency.Expr.rename.eq_4
#check DiophantineConsistency.Expr.rename.eq_5
#print axioms DiophantineConsistency.Expr.rename.eq_5
#check DiophantineConsistency.Expr.rename.eq_def
#print axioms DiophantineConsistency.Expr.rename.eq_def
#check DiophantineConsistency.Expr.semiringZero_rename
#print axioms DiophantineConsistency.Expr.semiringZero_rename
#check DiophantineConsistency.Expr.semiringZero_rename._simp_1
#print axioms DiophantineConsistency.Expr.semiringZero_rename._simp_1
#check DiophantineConsistency.Expr.semiringZero_var_add
#print axioms DiophantineConsistency.Expr.semiringZero_var_add
#check DiophantineConsistency.Expr.semiringZero_var_add._simp_1
#print axioms DiophantineConsistency.Expr.semiringZero_var_add._simp_1
#check DiophantineConsistency.Expr.semiringZero_var_mul
#print axioms DiophantineConsistency.Expr.semiringZero_var_mul
#check DiophantineConsistency.Expr.semiringZero_var_mul._simp_1
#print axioms DiophantineConsistency.Expr.semiringZero_var_mul._simp_1
#check DiophantineConsistency.Expr.semiringZero_var_nat
#print axioms DiophantineConsistency.Expr.semiringZero_var_nat
#check DiophantineConsistency.Expr.semiringZero_var_nat._simp_1
#print axioms DiophantineConsistency.Expr.semiringZero_var_nat._simp_1
#check DiophantineConsistency.Expr.semiringZero_var_var
#print axioms DiophantineConsistency.Expr.semiringZero_var_var
#check DiophantineConsistency.Expr.semiringZero_var_var._simp_1
#print axioms DiophantineConsistency.Expr.semiringZero_var_var._simp_1
#check DiophantineConsistency.Expr.splitNatural
#print axioms DiophantineConsistency.Expr.splitNatural
#check DiophantineConsistency.Expr.splitNatural._f
#print axioms DiophantineConsistency.Expr.splitNatural._f
#check DiophantineConsistency.Expr.splitNatural._sunfold
#print axioms DiophantineConsistency.Expr.splitNatural._sunfold
#check DiophantineConsistency.Expr.splitNatural._unsafe_rec
#print axioms DiophantineConsistency.Expr.splitNatural._unsafe_rec
#check DiophantineConsistency.Expr.splitNatural.eq_1
#print axioms DiophantineConsistency.Expr.splitNatural.eq_1
#check DiophantineConsistency.Expr.splitNatural.eq_2
#print axioms DiophantineConsistency.Expr.splitNatural.eq_2
#check DiophantineConsistency.Expr.splitNatural.eq_3
#print axioms DiophantineConsistency.Expr.splitNatural.eq_3
#check DiophantineConsistency.Expr.splitNatural.eq_4
#print axioms DiophantineConsistency.Expr.splitNatural.eq_4
#check DiophantineConsistency.Expr.splitNatural.eq_5
#print axioms DiophantineConsistency.Expr.splitNatural.eq_5
#check DiophantineConsistency.Expr.splitNatural.eq_def
#print axioms DiophantineConsistency.Expr.splitNatural.eq_def
#check DiophantineConsistency.Expr.splitNatural.match_1
#print axioms DiophantineConsistency.Expr.splitNatural.match_1
#check DiophantineConsistency.Expr.splitNatural_eval_rename
#print axioms DiophantineConsistency.Expr.splitNatural_eval_rename
#check DiophantineConsistency.Expr.sub
#print axioms DiophantineConsistency.Expr.sub
#check DiophantineConsistency.Expr.sub.elim
#print axioms DiophantineConsistency.Expr.sub.elim
#check DiophantineConsistency.Expr.sub.inj
#print axioms DiophantineConsistency.Expr.sub.inj
#check DiophantineConsistency.Expr.sub.injEq
#print axioms DiophantineConsistency.Expr.sub.injEq
#check DiophantineConsistency.Expr.sub.noConfusion
#print axioms DiophantineConsistency.Expr.sub.noConfusion
#check DiophantineConsistency.Expr.sub.sizeOf_spec
#print axioms DiophantineConsistency.Expr.sub.sizeOf_spec
#check DiophantineConsistency.Expr.subst
#print axioms DiophantineConsistency.Expr.subst
#check DiophantineConsistency.Expr.subst._f
#print axioms DiophantineConsistency.Expr.subst._f
#check DiophantineConsistency.Expr.subst._sunfold
#print axioms DiophantineConsistency.Expr.subst._sunfold
#check DiophantineConsistency.Expr.subst._unsafe_rec
#print axioms DiophantineConsistency.Expr.subst._unsafe_rec
#check DiophantineConsistency.Expr.subst.eq_1
#print axioms DiophantineConsistency.Expr.subst.eq_1
#check DiophantineConsistency.Expr.subst.eq_2
#print axioms DiophantineConsistency.Expr.subst.eq_2
#check DiophantineConsistency.Expr.subst.eq_3
#print axioms DiophantineConsistency.Expr.subst.eq_3
#check DiophantineConsistency.Expr.subst.eq_4
#print axioms DiophantineConsistency.Expr.subst.eq_4
#check DiophantineConsistency.Expr.subst.eq_5
#print axioms DiophantineConsistency.Expr.subst.eq_5
#check DiophantineConsistency.Expr.subst.eq_def
#print axioms DiophantineConsistency.Expr.subst.eq_def
#check DiophantineConsistency.Expr.toPolynomial
#print axioms DiophantineConsistency.Expr.toPolynomial
#check DiophantineConsistency.Expr.toPolynomial._f
#print axioms DiophantineConsistency.Expr.toPolynomial._f
#check DiophantineConsistency.Expr.toPolynomial._sunfold
#print axioms DiophantineConsistency.Expr.toPolynomial._sunfold
#check DiophantineConsistency.Expr.toPolynomial.eq_1
#print axioms DiophantineConsistency.Expr.toPolynomial.eq_1
#check DiophantineConsistency.Expr.toPolynomial.eq_2
#print axioms DiophantineConsistency.Expr.toPolynomial.eq_2
#check DiophantineConsistency.Expr.toPolynomial.eq_3
#print axioms DiophantineConsistency.Expr.toPolynomial.eq_3
#check DiophantineConsistency.Expr.toPolynomial.eq_4
#print axioms DiophantineConsistency.Expr.toPolynomial.eq_4
#check DiophantineConsistency.Expr.toPolynomial.eq_5
#print axioms DiophantineConsistency.Expr.toPolynomial.eq_5
#check DiophantineConsistency.Expr.toPolynomial.eq_def
#print axioms DiophantineConsistency.Expr.toPolynomial.eq_def
#check DiophantineConsistency.Expr.var
#print axioms DiophantineConsistency.Expr.var
#check DiophantineConsistency.Expr.var.elim
#print axioms DiophantineConsistency.Expr.var.elim
#check DiophantineConsistency.Expr.var.inj
#print axioms DiophantineConsistency.Expr.var.inj
#check DiophantineConsistency.Expr.var.injEq
#print axioms DiophantineConsistency.Expr.var.injEq
#check DiophantineConsistency.Expr.var.noConfusion
#print axioms DiophantineConsistency.Expr.var.noConfusion
#check DiophantineConsistency.Expr.var.sizeOf_spec
#print axioms DiophantineConsistency.Expr.var.sizeOf_spec
#check DiophantineConsistency.QuarticCompiler.Gates.Wire
#print axioms DiophantineConsistency.QuarticCompiler.Gates.Wire
#check DiophantineConsistency.QuarticCompiler.Gates.Wire._f
#print axioms DiophantineConsistency.QuarticCompiler.Gates.Wire._f
#check DiophantineConsistency.QuarticCompiler.Gates.Wire._sunfold
#print axioms DiophantineConsistency.QuarticCompiler.Gates.Wire._sunfold
#check DiophantineConsistency.QuarticCompiler.Gates.Wire._unsafe_rec
#print axioms DiophantineConsistency.QuarticCompiler.Gates.Wire._unsafe_rec
#check DiophantineConsistency.QuarticCompiler.Gates.Wire.match_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.Wire.match_1
#check DiophantineConsistency.QuarticCompiler.Gates.complete
#print axioms DiophantineConsistency.QuarticCompiler.Gates.complete
#check DiophantineConsistency.QuarticCompiler.Gates.count
#print axioms DiophantineConsistency.QuarticCompiler.Gates.count
#check DiophantineConsistency.QuarticCompiler.Gates.count._f
#print axioms DiophantineConsistency.QuarticCompiler.Gates.count._f
#check DiophantineConsistency.QuarticCompiler.Gates.count._sunfold
#print axioms DiophantineConsistency.QuarticCompiler.Gates.count._sunfold
#check DiophantineConsistency.QuarticCompiler.Gates.count._unsafe_rec
#print axioms DiophantineConsistency.QuarticCompiler.Gates.count._unsafe_rec
#check DiophantineConsistency.QuarticCompiler.Gates.index
#print axioms DiophantineConsistency.QuarticCompiler.Gates.index
#check DiophantineConsistency.QuarticCompiler.Gates.index._f
#print axioms DiophantineConsistency.QuarticCompiler.Gates.index._f
#check DiophantineConsistency.QuarticCompiler.Gates.index._sunfold
#print axioms DiophantineConsistency.QuarticCompiler.Gates.index._sunfold
#check DiophantineConsistency.QuarticCompiler.Gates.index._unsafe_rec
#print axioms DiophantineConsistency.QuarticCompiler.Gates.index._unsafe_rec
#check DiophantineConsistency.QuarticCompiler.Gates.instFintypeWire
#print axioms DiophantineConsistency.QuarticCompiler.Gates.instFintypeWire
#check DiophantineConsistency.QuarticCompiler.Gates.polynomial_rename
#print axioms DiophantineConsistency.QuarticCompiler.Gates.polynomial_rename
#check DiophantineConsistency.QuarticCompiler.Gates.residual
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residual
#check DiophantineConsistency.QuarticCompiler.Gates.residual.eq_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residual.eq_1
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax._f
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax._f
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax._sunfold
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax._sunfold
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax._unsafe_rec
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax._unsafe_rec
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_1
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_2
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_2
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_3
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_3
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_4
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_4
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_5
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_5
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_6
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_6
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_7
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_7
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_8
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_8
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_def
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.eq_def
#check DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.match_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residualSyntax.match_1
#check DiophantineConsistency.QuarticCompiler.Gates.residual_degree
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residual_degree
#check DiophantineConsistency.QuarticCompiler.Gates.residual_degree._proof_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.residual_degree._proof_1
#check DiophantineConsistency.QuarticCompiler.Gates.root
#print axioms DiophantineConsistency.QuarticCompiler.Gates.root
#check DiophantineConsistency.QuarticCompiler.Gates.root._proof_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.root._proof_1
#check DiophantineConsistency.QuarticCompiler.Gates.semiringAssignment
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringAssignment
#check DiophantineConsistency.QuarticCompiler.Gates.semiringAssignment.eq_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringAssignment.eq_1
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues._f
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues._f
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues._sunfold
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues._sunfold
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues._unsafe_rec
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues._unsafe_rec
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_1
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_2
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_2
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_3
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_3
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_4
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_4
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_5
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_5
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_6
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_6
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_7
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_7
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_8
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_8
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_def
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.eq_def
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues.match_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues.match_1
#check DiophantineConsistency.QuarticCompiler.Gates.semiringValues_root
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiringValues_root
#check DiophantineConsistency.QuarticCompiler.Gates.semiring_complete
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiring_complete
#check DiophantineConsistency.QuarticCompiler.Gates.semiring_sound
#print axioms DiophantineConsistency.QuarticCompiler.Gates.semiring_sound
#check DiophantineConsistency.QuarticCompiler.Gates.sound
#print axioms DiophantineConsistency.QuarticCompiler.Gates.sound
#check DiophantineConsistency.QuarticCompiler.Gates.values
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values
#check DiophantineConsistency.QuarticCompiler.Gates.values._f
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values._f
#check DiophantineConsistency.QuarticCompiler.Gates.values._sunfold
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values._sunfold
#check DiophantineConsistency.QuarticCompiler.Gates.values._unsafe_rec
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values._unsafe_rec
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_1
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_2
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_2
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_3
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_3
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_4
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_4
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_5
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_5
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_6
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_6
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_7
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_7
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_8
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_8
#check DiophantineConsistency.QuarticCompiler.Gates.values.eq_def
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.eq_def
#check DiophantineConsistency.QuarticCompiler.Gates.values.match_1
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values.match_1
#check DiophantineConsistency.QuarticCompiler.Gates.values_root
#print axioms DiophantineConsistency.QuarticCompiler.Gates.values_root
#print equations DiophantineConsistency.Expr.SemiringZero
#print equations DiophantineConsistency.QuarticCompiler.Gates.semiringAssignment
#print equations DiophantineConsistency.QuarticCompiler.Gates.semiringValues
