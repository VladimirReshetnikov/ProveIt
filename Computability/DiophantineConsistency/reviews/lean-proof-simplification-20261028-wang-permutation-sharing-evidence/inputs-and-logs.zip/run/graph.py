from pathlib import Path
import re,json,hashlib
root=Path.cwd(); path=root/'Computability/DiophantineConsistency/Lean'; R=Path('/tmp/rank-sharing'); h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest(); g={}; pending=['DiophantineConsistency.WangTiles942Permutation','DiophantineConsistency.CurrentClause2011','DiophantineConsistency.WangTiles942PermutationChecks'];
while pending:
 n=pending.pop()
 if n in g:continue
 source=path/(n.replace('.','/')+'.lean')
 if n == 'DiophantineConsistency.WangTiles942Permutation':source=R/'source/DiophantineConsistency/WangTiles942Permutation.lean'
 t=source.read_text();imports=[]
 for line in t.splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.*)',line)
  if m:
   imports += [x for x in m.group(1).split() if x.startswith('DiophantineConsistency.')]
 obj=R/'final-lib'/(n.replace('.','/')+'.olean')
 g[n]={'source':str(source),'source_sha256':h(source),'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':h(obj) if obj.exists() else None,'imports':imports};pending+=imports
p=json.load(open('/tmp/reflected-shared-20261028/selected-objects.json')); ref={x['module']:x for x in p};ref.update({x['module']:x for x in json.load(open('/tmp/outer-seed-bound-sharing/assembly-builds2.json'))});ref.update({x['module']:x for x in json.load(open('/tmp/outer-seed-bound-sharing/prereq2-records.json'))});
bad=[]
for n,x in g.items():
 if n.endswith(('WangTiles942Permutation','CurrentClause2011','WangTiles942PermutationChecks')):continue
 y=ref.get(n)
 if not y or y['source_sha256']!=x['source_sha256'] or y['object_sha256']!=x['object_sha256']:bad.append((n,'no receipt' if not y else ('source' if y['source_sha256']!=x['source_sha256'] else 'object')))
print('project graph',len(g),'unmatched',len(bad));print(*bad,sep='\n');(R/'graph.json').write_text(json.dumps(g,indent=2))
