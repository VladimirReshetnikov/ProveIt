from pathlib import Path
import os,subprocess,json,hashlib,time
R=Path('/tmp/rank-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[]
for tag in ['names','axioms']:
 for phase in ['baseline','final']:
  env=os.environ.copy();env['LEAN_PATH']=str(R/(phase+'-verified'))+':'+env['LEAN_PATH'];src=R/('names.lean' if tag=='names' else phase+'-axioms.lean');log=R/(phase+'-'+tag+'.log');tim=R/(phase+'-'+tag+'.time');before=h(src);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tim),'lean','-M10000','-j1','-DElab.async=false','-R',str(R),str(src)];t=time.monotonic()
  with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  z={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'timing':tim.read_text().strip()};rec.append(z);(R/'probe-records.json').write_text(json.dumps(rec,indent=2));print(phase,tag,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
