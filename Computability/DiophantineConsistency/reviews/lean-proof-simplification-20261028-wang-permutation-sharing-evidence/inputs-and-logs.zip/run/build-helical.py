from pathlib import Path
import os,subprocess,json,hashlib,time
R=Path('/tmp/rank-sharing');base=Path('Computability/DiophantineConsistency/Lean');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[]
for n in ['WangTiles942Language','WangTiles942Periodic']:
 for phase in ['baseline','final']:
  q=R/(phase+'-verified')/'DiophantineConsistency'/f'{n}.olean'
  if q.exists() or q.is_symlink():q.unlink()
for n in ['WangTiles942Language','WangTiles942Periodic','WangTiles942HelicalQuotient']:
 phases=['shared'] if n!='WangTiles942HelicalQuotient' else ['baseline','final']
 for phase in phases:
  selected='baseline' if phase=='shared' else phase;env=os.environ.copy();env['LEAN_PATH']=str(R/(selected+'-verified'))+':'+env['LEAN_PATH'];src=base/'DiophantineConsistency'/f'{n}.lean';out=(R/'fresh' if phase=='shared' else R/(phase+'-verified'))/'DiophantineConsistency'/f'{n}.olean';log=R/f'{phase}-{n}.log';tim=R/f'{phase}-{n}.time';before=h(src);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tim),'lean','-M10000','-j1','-DElab.async=false','-R',str(base),str(src),'-o',str(out)];t=time.monotonic()
  with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  z={'phase':phase,'module':'DiophantineConsistency.'+n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'timing':tim.read_text().strip(),'object_sha256':h(out) if out.exists() else None};rec.append(z);(R/'helical-records.json').write_text(json.dumps(rec,indent=2));print(phase,n,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
  if phase=='shared':
   for phase2 in ['baseline','final']:(R/(phase2+'-verified')/'DiophantineConsistency'/f'{n}.olean').symlink_to(out)
