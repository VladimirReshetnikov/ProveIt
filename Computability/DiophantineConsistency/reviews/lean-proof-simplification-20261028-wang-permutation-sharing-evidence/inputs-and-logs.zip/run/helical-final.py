from pathlib import Path
import os,subprocess,json,hashlib,time
R=Path('/tmp/rank-sharing');base=Path('Computability/DiophantineConsistency/Lean');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[];n='WangTiles942HelicalQuotient'
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/(phase+'-verified'))+':'+env['LEAN_PATH'];src=base/'DiophantineConsistency'/f'{n}.lean';out=R/(phase+'-verified')/'DiophantineConsistency'/f'{n}.olean';out.unlink(missing_ok=True);log=R/f'{phase}-{n}-final.log';tim=R/f'{phase}-{n}-final.time';before=h(src);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tim),'lean','-M10000','-j1','-DElab.async=false','-R',str(base),str(src),'-o',str(out)];t=time.monotonic()
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 z={'phase':phase,'module':'DiophantineConsistency.'+n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'timing':tim.read_text().strip(),'object_sha256':h(out) if out.exists() else None};rec.append(z);(R/'helical-final-records.json').write_text(json.dumps(rec,indent=2));print(phase,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
