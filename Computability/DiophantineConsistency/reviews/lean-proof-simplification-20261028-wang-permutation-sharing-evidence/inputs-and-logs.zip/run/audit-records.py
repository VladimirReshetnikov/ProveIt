import pathlib,json,hashlib
P=pathlib.Path('/tmp/rank-sharing');h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for fn in ['paired-records.json','helical-records.json','helical-final-records.json','probe-records.json']:
 rs=json.loads((P/fn).read_text())
 for r in rs:
  phase=r['phase'];cmd=r['command'];tag=r.get('tag',r.get('module','').split('.')[-1]);log=P/(pathlib.Path(cmd[4]).stem+'.log');selected='baseline' if phase=='shared' else phase;assert r['status']==0 and r['lean_path'].split(':')[0]==str(P/(selected+'-verified')),(fn,phase,tag,'status/path')
  assert pathlib.Path(cmd[4]).read_text().strip()==r['timing'],(fn,phase,tag,'timing')
  src=[pathlib.Path(x) for x in cmd if x.endswith('.lean')];assert len(src)==1 and h(src[0])==r['source_sha256']==r['source_after'],(fn,phase,tag,'source')
  assert h(log)==r['log_sha256'],(fn,phase,tag,'log')
  if r.get('object_sha256'):assert cmd[-2]=='-o' and h(cmd[-1])==r['object_sha256'],(fn,phase,tag,'object')
 print(fn,'checked',len(rs),'status, phase, source, log, time and output hashes')
for n in ['WangTiles942Language','WangTiles942Periodic']:
 for phase in ['baseline','final']:assert (P/(phase+'-verified')/'DiophantineConsistency'/(n+'.olean')).resolve()==(P/'fresh/DiophantineConsistency'/(n+'.olean')).resolve(),(n,phase)
print('paired helical prerequisites use same freshly built objects')
