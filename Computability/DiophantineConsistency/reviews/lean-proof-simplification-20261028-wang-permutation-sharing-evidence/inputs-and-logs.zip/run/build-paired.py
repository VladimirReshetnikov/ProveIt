from pathlib import Path
import os,subprocess,json,hashlib,time
R=Path('/tmp/rank-sharing');base=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=json.loads((R/'paired-records.json').read_text())
for tag in ['target','checks']:
 for phase in ['baseline','final']:
  if tag=='target' and phase=='baseline':continue
  env=os.environ.copy();env['LEAN_PATH']=str(R/(phase+'-verified'))+':'+env['LEAN_PATH'];src=R/('source' if phase=='final' else phase)/'DiophantineConsistency/WangTiles942Permutation.lean' if tag=='target' else base/'WangTiles942PermutationChecks.lean';out=R/(phase+'-verified')/'DiophantineConsistency'/(('WangTiles942Permutation' if tag=='target' else 'WangTiles942PermutationChecks')+'.olean');root=R/('source' if phase=='final' else phase) if tag=='target' else Path('Computability/DiophantineConsistency/Lean');log=R/(phase+'-'+tag+'.log');tim=R/(phase+'-'+tag+'.time');before=h(src);cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tim),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)];t=time.monotonic()
  with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  z={'phase':phase,'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'seconds':time.monotonic()-t,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'timing':tim.read_text().strip(),'object_sha256':h(out) if out.exists() else None};rec.append(z);(R/'paired-records.json').write_text(json.dumps(rec,indent=2));print(phase,tag,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
