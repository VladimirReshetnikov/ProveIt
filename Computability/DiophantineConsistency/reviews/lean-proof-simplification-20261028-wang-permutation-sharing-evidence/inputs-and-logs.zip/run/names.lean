import DiophantineConsistency.WangTiles942Permutation
open Lean Elab Command
#print equations DiophantineConsistency.WangTiles942.recoveredIndex
#print equations DiophantineConsistency.WangTiles942.strictUpper
#print equations DiophantineConsistency.WangTiles942.strictRank
#print equations DiophantineConsistency.WangTiles942.nonStartWeight
#print equations DiophantineConsistency.WangTiles942.physicalMap
#print equations DiophantineConsistency.WangTiles942.physicalEquiv
#print equations DiophantineConsistency.WangTiles942.physicalWeight
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.WangTiles942).isPrefixOf n then
      logInfo m!"DECL {n}"
