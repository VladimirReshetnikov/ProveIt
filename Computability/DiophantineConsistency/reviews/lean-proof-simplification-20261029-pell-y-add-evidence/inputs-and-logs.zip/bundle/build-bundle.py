from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path('/tmp/pell-y-add');D=Path('Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-pell-y-add-evidence');D.mkdir(parents=True,exist_ok=True);files={}
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.is_symlink() or str(p.relative_to(R)).startswith('objects-') or p.suffix=='.olean' or p.name in ('build-bundle.py','client-probe.py'):continue
 if p.parent==R and p.name.startswith('ArithmeticPell') and p.suffix=='.lean':continue
 files['prototype/'+str(p.relative_to(R))]=p.read_bytes()
files['prior/pell-square-direct-final-records.json']=Path('/tmp/pell-square-direct/final-records.json').read_bytes()
for x in ('pell-y-add-peer-review.txt','pell-y-add-peer-audit.py','pell-y-add-peer-audit.log'):files['independent/'+x]=Path('/tmp',x).read_bytes()
c='20eb14ccb97dc1ee592ee8143d6f57b8076b0459';par='d37e8eebb62a7edd894f34611a0148c14087f595';rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellCongruences.lean'
for rev,label in ((par,'baseline'),(c,'final')):
 files['commit/'+label+'.lean']=subprocess.check_output(['git','show',rev+':'+rel]);assert files['commit/'+label+'.lean']==files['prototype/'+label+'/DiophantineConsistency/ArithmeticPellCongruences.lean']
files['bundle/build-bundle.py']=Path('/tmp/pell-y-add/build-bundle.py').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
manifest={'schema':'lean-proof-simplification-evidence-v1','source_commit':c,'source_parent':par,'scope':'Simplify ArithmeticPellCongruences.y_add_ge using direct one-le multiplication bounds','validation':'Paired target and its three tracked Lean direct clients pass; all three client objects match. Nine target declaration/type/axiom reports and default simp/instance reports match. Classification and KnownUnit direct providers match adopted square-direct current-source producer receipts.','limitations':['A full current-source transitive project, Foundation and Mathlib closure was not rebuilt; direct provider source/object matches rely on prior producer receipts, rather than source hashes contemporaneously sampled by these builds.','The preliminary final target receipt references object/log paths reused by the final paired lane; it is not independent validation.','Single shared-load timing pairs do not establish general performance changes. Matching declarations and registrations do not establish equality of proof bodies, every persistent extension or untested downstream behavior.','Compiled objects are excluded; their recorded hashes and paths require external objects for independent byte verification.'],'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'independent_review_sha256':sha(files['independent/pell-y-add-peer-review.txt']),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}}
(D/'BUNDLE.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'independent-review.txt').write_bytes(files['independent/pell-y-add-peer-review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for n,b in files.items():assert z.read(n)==b
assert sha((D/'independent-review.txt').read_bytes())==manifest['independent_review_sha256'];print('PASS members',len(files),'zip sha',manifest['archive_sha256'],'review sha',manifest['independent_review_sha256'])
