from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/pell-y-add');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticPellCongruences.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticPellCongruences.lean').read_text();start='theorem y_add_ge';end='theorem y_strictMono';i=b.index(start);j=b.index(end,i);k=f.index(start);l=f.index(end,k)
assert b[:i]==f[:k] and b[j:]==f[l:] and b[i:j].split(':= by',1)[0]==f[k:l].split(':= by',1)[0]
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellCongruences.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('20eb14ccb9^')==b and gitfile('20eb14ccb9')==f and (W/'ArithmeticPellCongruences.lean').read_text()==f
print('PASS only y_add_ge proof changed, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticPellCongruences$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(p).stem for p in clients)==['ArithmeticPellCongruencesChecks','ArithmeticPellFirstNorm','ArithmeticPellPeriodicity']
print('PASS direct module clients',clients)
prior={x['module']:x for x in read('/tmp/pell-square-direct/final-records.json')}
for n in ('ArithmeticPellClassification','ArithmeticPellKnownUnit'):
 x=prior[n];assert x['status']==0 and x['before']==x['after']==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);print('PASS adopted source/object provider',n,x['object_sha256'])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticPellCongruences','ArithmeticPellCongruencesChecks','ArithmeticPellFirstNorm','ArithmeticPellPeriodicity'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticPellCongruences':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   n=d['module'].split('.')[-1]
   if n=='ArithmeticPellCongruences':assert d['before']==rec[phase][n]['object_sha256']
   else:assert d['before']==prior[n]['object_sha256']
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('names','interfaces','simp','instances'):
 for phase in ('baseline','final'):
  x=read(R/f'probe-{n}-{phase}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rec[phase]['ArithmeticPellCongruences']['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
print('PASS target namespace and registration reports match')
for n in ('ArithmeticPellCongruencesChecks','ArithmeticPellFirstNorm','ArithmeticPellPeriodicity'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS all three direct client objects byte-identical')
