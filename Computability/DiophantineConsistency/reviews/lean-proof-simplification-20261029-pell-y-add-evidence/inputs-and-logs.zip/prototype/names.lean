import DiophantineConsistency.ArithmeticPellCongruences
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellCongruences).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellCongruences" then
   logInfo m!"DECL {n}"
