from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/pell-y-add');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
prior=load('/tmp/pell-square-direct/final-records.json');providers={}
for n in ('ArithmeticPellClassification','ArithmeticPellKnownUnit'):
 x=next(x for x in prior if x['module']==n);assert x['status']==0 and x['before']==x['after']==h(W/f'{n}.lean') and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256']
records={ph:load(R/f'{ph}-records.json') for ph in ('baseline','final')}
for ph,rr in records.items():
 assert [x['module'] for x in rr]==['ArithmeticPellCongruences','ArithmeticPellCongruencesChecks','ArithmeticPellFirstNorm','ArithmeticPellPeriodicity']
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if x['module']!='ArithmeticPellCongruences':assert x['before']==h(W/f"{x['module']}.lean")
  else:
   rev='20eb14ccb9^' if ph=='baseline' else '20eb14ccb9'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellCongruences.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert h(W/'ArithmeticPellCongruences.lean')==x['before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(z)/rel for z in x['LEAN_PATH'].split(':') if (Path(z)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);n=d['module'].split('.')[-1]
   if n=='ArithmeticPellCongruences':assert d['before']==rr[0]['object_sha256']
   else:assert d['before']==providers[n]
for n in ('names','interfaces','simp','instances'):
 for ph in ('baseline','final'):
  x=load(R/f'probe-{n}-{ph}.json');assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==records[ph][0]['object_sha256'] and x['log_sha256']==h(x['log'])
 assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
for x,y in zip(records['baseline'][1:],records['final'][1:]):assert x['object_sha256']==y['object_sha256']
print('PASS target, three client builds, direct source/object providers, target census and matching clients')
