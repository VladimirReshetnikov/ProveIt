PellCongruences ordinate addition lower bound: isolated proof simplification

Baseline source SHA-256 43a4e20045fbf7b65c4720ce7abcfabdbf09bd46c471effd4f11e0c52a7cb1ec;
final source SHA-256 afdb16050ac37d0c213d7124f1821ea4ef8aa2137253a120fb1d517781e1b157.
The y_add_ge proof directly combines the existing coordinate lower bounds with
the two one-le multiplication lemmas, then commutes the sum. It replaces ten
lines with four, preserving the theorem statement, all guards, definitions,
imports and data. Tested snapshots match 20eb14ccb9 and its parent.
The original module was added by commit 6809609c61, which has
no Co-Authored-By trailer; no Claude authorship claim is made here.

baseline/final-records.json record source hashes, first-provider direct input
object hashes, logs, timings and outputs for the target and all three tracked
Lean direct source clients (PellCongruencesChecks, PellFirstNorm and
PellPeriodicity). Target Classification and FirstNorm's additional KnownUnit
provider match the current-source producer rows of
/tmp/pell-square-direct/final-records.json, including the adopted square-direct
Classification change. Direct input source hashes were matched to those prior
receipts rather than contemporaneously sampled during these builds. audit.py
and audit.log verify these matches, output pins and census. This is not a full
current-source transitive closure rebuild; other project, Foundation and
Mathlib dependencies remain cached.

The target and all three clients pass in each phase; all three client output
objects match byte-for-byte. All nine target namespace declaration/type/axiom
reports and global simp/instance lists (28,968/13,167 entries) match exactly.
These checks do not establish equality of proof bodies, every persistent
extension or untested downstream behavior. Single paired shared-load user CPU
samples: target 6.52/6.51 s, Checks 1.75/1.78 s, FirstNorm 8.82/9.08 s and
Periodicity 7.35/7.46 s; these are not general performance benchmarks. Neither
phase produced target or client warnings. The preliminary final target receipt
is preserved as preliminary-final-records.json, but its object and log paths
were reused; the paired target/client builds are the validation evidence.
