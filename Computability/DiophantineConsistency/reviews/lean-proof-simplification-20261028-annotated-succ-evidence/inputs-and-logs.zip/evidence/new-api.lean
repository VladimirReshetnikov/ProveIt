import DiophantineConsistency.AnnotatedSyntaxGraphs
open DiophantineConsistency AnnotatedSyntaxGraphs
#print axioms forkCertificate_succ
example (a b t s m : Nat) : ¬ ForkCertificate 0 a b t s m := by
  intro h
  have hp := (forkCertificate_iff 0 a b t s m).mp h
  exact (Nat.lt_irrefl 0) hp.2
