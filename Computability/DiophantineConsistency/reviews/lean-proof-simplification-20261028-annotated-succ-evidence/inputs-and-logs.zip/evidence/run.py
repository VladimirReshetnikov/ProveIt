from pathlib import Path
import subprocess,time,json,hashlib,sys
p=Path('/tmp/annotated-succ-20261028');pref='Computability/DiophantineConsistency/Lean/';mode=sys.argv[1]
if mode=='prep': items=[(Path(src).stem,src,True) for src in json.loads((p/'preparation-order.json').read_text())]
elif mode=='baseline':items=[('target',pref+'DiophantineConsistency/AnnotatedSyntaxGraphs.lean',True),('axioms',str(p/'axioms.lean'),False)]
else:items=[('target',pref+'DiophantineConsistency/AnnotatedSyntaxGraphs.lean',True),('axioms',str(p/'axioms.lean'),False),('focus',pref+'checks/AnnotatedSyntaxGraphs.lean',False),('client',pref+'DiophantineConsistency/AnnotatedSharedSyntax.lean',False),('new-api',str(p/'new-api.lean'),False)]
records=[]
for name,source,obj in items:
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency'/(Path(source).stem+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/annotated-succ-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-start
 log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
 rec={'name':name,'argv':cmd,'status':r.returncode,'seconds':elapsed,'source':source,'source_sha256':h(source),'log':str(log),'log_sha256':h(log)}
 if obj and r.returncode==0:rec.update({'object':argv[-1],'object_sha256':h(argv[-1])})
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
