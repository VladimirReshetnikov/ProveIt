from pathlib import Path
import json,hashlib
b=Path('/tmp/gcd-remainder-sharing');prior=Path('/tmp/pell-dvd-reuse/inventory.json');x=json.load(open(prior));exclude={'DiophantineConsistency.ArithmeticGcdNormalization','DiophantineConsistency.ArithmeticPellStrongDivisibility','DiophantineConsistency.ArithmeticPellIntegralSolution','DiophantineConsistency.ArithmeticPellCommonUnit'};h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
for phase in ['baseline','final']:
 lib=b/phase/'lib';bad=[];checked=[]
 for n,v in x.items():
  if n in exclude or not v['matching_receipts']:continue
  src=Path(v['source']);obj=lib/(n.replace('.','/')+'.olean')
  if not obj.exists():obj=Path('.lake/build/lib/lean')/(n.replace('.','/')+'.olean')
  a=h(src) if src.exists() else None;c=h(obj) if obj.exists() else None;ok=a==v['source_sha256'] and c==v['object_sha256'];checked.append({'module':n,'source_sha256':a,'object_sha256':c,'object':str(obj.resolve()) if obj.exists() else None,'matching_receipts':v['matching_receipts'],'match':ok})
  if not ok:bad.append(n)
 results.append({'phase':phase,'matched':len(checked)-len(bad),'mismatches':bad,'modules':checked});print(phase,'matched',len(checked)-len(bad),'mismatches',bad)
(b/'dependency-audit.json').write_text(json.dumps({'prior_inventory':str(prior),'prior_inventory_sha256':h(prior),'excluded_rebuilt_targets_and_clients':sorted(exclude),'phases':results},indent=2))
if any(r['mismatches'] for r in results):raise SystemExit(1)
