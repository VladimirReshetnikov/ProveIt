from pathlib import Path
import os,subprocess,json,hashlib,time
b=Path('/tmp/gcd-remainder-sharing');env=os.environ.copy();rec=[];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
for phase in ['baseline','final']:
 d=b/phase;lib=d/'lib';e=env.copy();e['LEAN_PATH']=str(lib)+':'+env['LEAN_PATH']
 for name in ['Names','ArithmeticGcdNormalizationChecks','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility']:
  src=b/'Names.lean' if name=='Names' else root/(name+'.lean');out=lib/'DiophantineConsistency'/(name+'.olean');log=d/(name+'.log');cmd=['lean','-M6000','-j1','-DElab.async=false']
  if name!='Names':
   cmd+=['-R','Computability/DiophantineConsistency/Lean']
   if out.is_symlink():out.unlink()
  cmd.append(str(src))
  if name!='Names':cmd+=['-o',str(out)]
  t=time.monotonic();r=subprocess.run(cmd,env=e,stdout=log.open('w'),stderr=subprocess.STDOUT);rec.append({'phase':phase,'name':name,'command':cmd,'lean_path':e['LEAN_PATH'],'status':r.returncode,'seconds':round(time.monotonic()-t,3),'source_sha256':h(src),'log_sha256':h(log),'object_sha256':h(out) if name!='Names' and out.exists() else None});(b/'client-records.json').write_text(json.dumps(rec,indent=2));print(phase,name,r.returncode,rec[-1]['seconds'],flush=True)
  if r.returncode:raise SystemExit(r.returncode)
