from pathlib import Path
import hashlib,json,subprocess,re
R=Path('/tmp/gcd-remainder-sharing');T=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticGcdNormalization.lean');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bad=[]
def chk(cond,msg):
 if not cond:bad.append(msg)
old=subprocess.check_output(['git','show','HEAD:'+str(T)]);b=R/'baseline/source/DiophantineConsistency/ArithmeticGcdNormalization.lean';f=R/'final/source/DiophantineConsistency/ArithmeticGcdNormalization.lean';chk(old==b.read_bytes(),'baseline matches HEAD');chk(f.read_bytes()==T.read_bytes(),'final matches working')
for fn in ['build-records.json','client-records.json','axiom-records.json']:
 rs=json.loads((R/fn).read_text());print(fn,len(rs))
 for x in rs:
  phase=x['phase'];cmd=x['command'];src=[Path(a) for a in cmd if a.endswith('.lean') and Path(a).is_file()];tag='target' if fn=='build-records.json' else 'axioms-all' if fn=='axiom-records.json' else x['name'];log=R/phase/(tag+'.log');chk(x['status']==0,phase+' '+tag+' status');chk(x['lean_path'].split(':')[0]==str(R/phase/'lib'),phase+' '+tag+' path');chk(len(src)==1 and sha(src[0])==x['source_sha256'],phase+' '+tag+' source');chk(log.exists() and sha(log)==x['log_sha256'],phase+' '+tag+' log');
  if x.get('object_sha256'):
   o=Path(cmd[cmd.index('-o')+1]);chk(o.exists() and sha(o)==x['object_sha256'],phase+' '+tag+' object')
for n in ['target','ArithmeticGcdNormalizationChecks','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility','axioms-all']:
 a=(R/'baseline'/(n+'.log')).read_bytes();c=(R/'final'/(n+'.log')).read_bytes();chk(a==c,n+' paired logs');print(n,'matching log; warnings',a.decode().count('warning:'))
prefix='DiophantineConsistency.ArithmeticGcdNormalization';names={x for x in (R/'baseline/Names.log').read_text().splitlines() if x.startswith(prefix)};names2={x for x in (R/'final/Names.log').read_text().splitlines() if x.startswith(prefix)};probes=set(re.findall(r'^#print axioms\s+(\S+)',(R/'AxiomsAll.lean').read_text(),re.M));chk(names==names2==probes,'enumerated names equal probes');chk(len(names)==26,'26 public/generated names');print('enumerated names',len(names))
prior=Path('/tmp/pell-dvd-reuse/inventory.json');dep=json.loads((R/'dependency-audit.json').read_text());chk(sha(prior)==dep['prior_inventory_sha256'],'inventory hash');inv=json.loads(prior.read_text());exclude=set(dep['excluded_rebuilt_targets_and_clients']);chk(set(inv)-exclude==set(x['module'] for x in dep['phases'][0]['modules']),'all prior graph nodes represented')
for p in dep['phases']:
 phase=p['phase'];chk(p['matched']==98 and not p['mismatches'],phase+' count')
 for v in p['modules']:
  n=v['module'];z=inv[n];src=Path(z['source']);obj=R/phase/'lib'/(n.replace('.','/')+'.olean')
  if not obj.exists():obj=Path('.lake/build/lib/lean')/(n.replace('.','/')+'.olean')
  chk(src.exists() and sha(src)==v['source_sha256']==z['source_sha256'],phase+' '+n+' source');chk(obj.exists() and sha(obj)==v['object_sha256']==z['object_sha256'],phase+' '+n+' object');chk(v['matching_receipts']==z['matching_receipts'] and bool(v['matching_receipts']),phase+' '+n+' receipt labels')
print('prior graph',len(inv),'selected pins',len(dep['phases'][0]['modules']))
print('failures:',bad)
if bad:raise SystemExit(1)
