import DiophantineConsistency.ArithmeticGcdNormalization
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.ArithmeticGcdNormalization).isPrefixOf n then
      logInfo m!"{n}"
