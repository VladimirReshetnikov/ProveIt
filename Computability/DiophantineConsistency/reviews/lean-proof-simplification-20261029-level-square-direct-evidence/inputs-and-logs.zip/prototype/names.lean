import Lean.Elab.Command
import DiophantineConsistency.ArithmeticProofWordBound
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticProofWordBoundLevel).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticProofWordBoundLevel" then
   logInfo m!"DECL {n}"
