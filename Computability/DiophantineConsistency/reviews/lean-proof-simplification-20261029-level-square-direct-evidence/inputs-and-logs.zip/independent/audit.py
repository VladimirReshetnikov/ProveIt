from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/level-square-direct');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticProofWordBoundLevel.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticProofWordBoundLevel.lean').read_text();start='theorem tail_le_lev';end='/-- One replaced command';i=b.index(start);j=b.index(end,i);k=f.index(start);l=f.index(end,k);assert b[:i]==f[:k] and b[j:]==f[l:] and b[i:j].split(':= by',1)[0]==f[k:l].split(':= by',1)[0]
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticProofWordBoundLevel.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('2cdde09b46^')==b and gitfile('2cdde09b46')==f and (W/'ArithmeticProofWordBoundLevel.lean').read_text()==f
print('PASS only tail_le_lev proof changed, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticProofWordBoundLevel$','--','*.lean'],text=True).splitlines();assert clients==['Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticProofWordBound.lean'];print('PASS sole tracked Lean direct client',clients)
paths={'ArithmeticCommandCircuitPerm222':'/tmp/claude-ax-sharing/coherent-common-records.json','ArithmeticEnumBoundFair':'/tmp/enum-fair-sharing/final-doc2-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module'].split('.')[-1]==n);a=x.get('source_sha256') or x.get('source_sha256_before');z=x.get('source_after') or x.get('source_sha256_after');assert x['status']==0 and a==z==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticProofWordBoundLevel','ArithmeticProofWordBound'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticProofWordBoundLevel':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d.get('source_before') is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n=='ArithmeticProofWordBoundLevel':assert d['before']==rec[phase][n]['object_sha256']
   else:assert d['before']==providers[n]
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
print('client objects equal?',rec['baseline']['ArithmeticProofWordBound']['object_sha256']==rec['final']['ArithmeticProofWordBound']['object_sha256'])
assert rec['baseline']['ArithmeticProofWordBound']['object_sha256']==rec['final']['ArithmeticProofWordBound']['object_sha256']
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][Path(p).stem]['object_sha256'] for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
s=read(R/'setup-failed-baseline-records.json');assert len(s)==1 and s[0]['status']!=0 and s[0]['log_sha256']==h(R/'setup-failed-baseline-ArithmeticProofWordBoundLevel.log')
print('PASS both-object-pinned target census and preserved failed setup')
