import DiophantineConsistency.BoundedForallRepresentation
local macro "templateDvdGraphs" : term =>
  pure (Lean.mkIdent (Lean.mkPrivateNameCore
    `DiophantineConsistency.BoundedForallRepresentation
    `DiophantineConsistency.BoundedForallRepresentation.dvdGraphs))
#check templateDvdGraphs
