from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/affine-budget-proof-20261028'); pre='Computability/DiophantineConsistency/Lean/';mode=sys.argv[1]
def tag(s):return Path(s).stem
if mode=='prep':
 paths=json.loads((p/'prep-order.json').read_text());items=[(tag(s),s,True) for s in paths]
 for _,s,_ in items:
  f=p/'overlay/DiophantineConsistency'/(tag(s)+'.olean')
  if f.is_symlink():f.unlink()
elif mode=='baseline':items=[('target',str(p/'oldsrc/DiophantineConsistency/GraphSizeBounds.lean'),True),('axioms',str(p/'axioms.lean'),False)]
elif mode=='final':items=[('helper',pre+'DiophantineConsistency/AffineBudget.lean',True),('target',pre+'DiophantineConsistency/GraphSizeBounds.lean',True),('axioms',str(p/'axioms.lean'),False),('helper_axioms',str(p/'helper-axioms.lean'),False),('focus',pre+'checks/RepresentationSize.lean',False),('depth',pre+'DiophantineConsistency/BoundedForallDepth.lean',False),('enumeration',pre+'DiophantineConsistency/NativeEnumerationSize.lean',False)]
else:raise ValueError(mode)
records=[]
for name,source,obj in items:
 if shutil.disk_usage('.').free<100*1024*1024:raise SystemExit('disk below 100 MiB safety cutoff')
 argv=['lean','-M6000','-j1','-DElab.async=false']
 if source.startswith(pre): argv += ['-R',pre]
 elif '/oldsrc/' in source: argv += ['-R',str(p/'oldsrc')]
 argv += [source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency'/(tag(source)+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/affine-budget-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);secs=time.monotonic()-start;log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 b=Path(source).read_bytes();rec={'name':name,'argv':cmd,'exit_status':r.returncode,'seconds':secs,'source':source,'source_sha256':hashlib.sha256(b).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  ob=p/'overlay/DiophantineConsistency'/(tag(source)+'.olean');rec['object']=str(ob);rec['object_sha256']=hashlib.sha256(ob.read_bytes()).hexdigest()
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 print(mode,name,r.returncode,round(secs,1),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
