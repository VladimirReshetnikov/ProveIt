import DiophantineConsistency.AnnotatedProofChecker
open DiophantineConsistency.AnnotatedProofChecker

example (r : Rule) (hs : r.side = true)
    (ready : ∀ j ∈ r.premises, HasFragment j) : HasFragment r.output :=
  fragment r hs ready

example (r : Rule) (a b c : Judgment) (hs : r.side = true)
    (hm : r.premises = [a, b, a, c])
    (ha : HasFragment a) (hb : HasFragment b) (hc : HasFragment c) : HasFragment r.output :=
  fragment r hs (by simpa [hm] using And.intro ha (And.intro hb (And.intro ha hc)))

#print axioms DiophantineConsistency.AnnotatedProofChecker.collect_fragments
#print axioms DiophantineConsistency.AnnotatedProofChecker.fragment
