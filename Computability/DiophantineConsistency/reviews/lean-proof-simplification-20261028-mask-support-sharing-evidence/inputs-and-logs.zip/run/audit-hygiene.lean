import DiophantineConsistency.CurrentMaskRecipes2011
import DiophantineConsistency.ArithmeticMaskData
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    let s := n.toString
    if s.startsWith "DiophantineConsistency.CurrentMasks2011." && s.contains "._@." then
      let axs ← collectAxioms n
      logInfo m!"NAME {n}\nTYPE {c.type}\nAXIOMS {axs}"
