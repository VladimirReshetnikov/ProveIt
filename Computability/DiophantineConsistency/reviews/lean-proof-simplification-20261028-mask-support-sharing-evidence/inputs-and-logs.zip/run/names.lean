import DiophantineConsistency.CurrentMaskRecipes2011
import DiophantineConsistency.ArithmeticMaskData
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.CurrentMasks2011).isPrefixOf n || (`DiophantineConsistency.ArithmeticMaskData).isPrefixOf n then
      logInfo m!"{n}"
