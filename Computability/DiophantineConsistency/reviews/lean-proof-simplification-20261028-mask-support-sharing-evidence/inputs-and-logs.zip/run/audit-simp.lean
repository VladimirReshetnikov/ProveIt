import DiophantineConsistency.CurrentMaskRecipes2011
import DiophantineConsistency.ArithmeticMaskData
open Lean Elab Command
run_cmd do
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  let n0 := `DiophantineConsistency.ArithmeticMaskData.support_value._proof_2
  logInfo m!"DiophantineConsistency.ArithmeticMaskData.support_value._proof_2: {t.isLemma (.decl n0 true false)} {t.isLemma (.decl n0 false false)} {t.isLemma (.decl n0 true true)} {t.isLemma (.decl n0 false true)}"
  let n1 := `DiophantineConsistency.ArithmeticMaskData.support_value._proof_4
  logInfo m!"DiophantineConsistency.ArithmeticMaskData.support_value._proof_4: {t.isLemma (.decl n1 true false)} {t.isLemma (.decl n1 false false)} {t.isLemma (.decl n1 true true)} {t.isLemma (.decl n1 false true)}"
  let n2 := `DiophantineConsistency.ArithmeticMaskData.support_value._simp_1
  logInfo m!"DiophantineConsistency.ArithmeticMaskData.support_value._simp_1: {t.isLemma (.decl n2 true false)} {t.isLemma (.decl n2 false false)} {t.isLemma (.decl n2 true true)} {t.isLemma (.decl n2 false true)}"
  let n3 := `DiophantineConsistency.ArithmeticMaskData.support_value._simp_2
  logInfo m!"DiophantineConsistency.ArithmeticMaskData.support_value._simp_2: {t.isLemma (.decl n3 true false)} {t.isLemma (.decl n3 false false)} {t.isLemma (.decl n3 true true)} {t.isLemma (.decl n3 false true)}"
  let n4 := `DiophantineConsistency.ArithmeticMaskData.support_value._simp_3
  logInfo m!"DiophantineConsistency.ArithmeticMaskData.support_value._simp_3: {t.isLemma (.decl n4 true false)} {t.isLemma (.decl n4 false false)} {t.isLemma (.decl n4 true true)} {t.isLemma (.decl n4 false true)}"
  let n5 := `DiophantineConsistency.ArithmeticMaskData.support_value._simp_4
  logInfo m!"DiophantineConsistency.ArithmeticMaskData.support_value._simp_4: {t.isLemma (.decl n5 true false)} {t.isLemma (.decl n5 false false)} {t.isLemma (.decl n5 true true)} {t.isLemma (.decl n5 false true)}"
  let n6 := `DiophantineConsistency.CurrentMasks2011.lowSupport_card._proof_1
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_card._proof_1: {t.isLemma (.decl n6 true false)} {t.isLemma (.decl n6 false false)} {t.isLemma (.decl n6 true true)} {t.isLemma (.decl n6 false true)}"
  let n7 := `DiophantineConsistency.CurrentMasks2011.lowSupport_card._proof_2
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_card._proof_2: {t.isLemma (.decl n7 true false)} {t.isLemma (.decl n7 false false)} {t.isLemma (.decl n7 true true)} {t.isLemma (.decl n7 false true)}"
  let n8 := `DiophantineConsistency.CurrentMasks2011.lowSupport_value._proof_2
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_value._proof_2: {t.isLemma (.decl n8 true false)} {t.isLemma (.decl n8 false false)} {t.isLemma (.decl n8 true true)} {t.isLemma (.decl n8 false true)}"
  let n9 := `DiophantineConsistency.CurrentMasks2011.lowSupport_value._proof_4
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_value._proof_4: {t.isLemma (.decl n9 true false)} {t.isLemma (.decl n9 false false)} {t.isLemma (.decl n9 true true)} {t.isLemma (.decl n9 false true)}"
  let n10 := `DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_1
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_1: {t.isLemma (.decl n10 true false)} {t.isLemma (.decl n10 false false)} {t.isLemma (.decl n10 true true)} {t.isLemma (.decl n10 false true)}"
  let n11 := `DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_2
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_2: {t.isLemma (.decl n11 true false)} {t.isLemma (.decl n11 false false)} {t.isLemma (.decl n11 true true)} {t.isLemma (.decl n11 false true)}"
  let n12 := `DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_3
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_3: {t.isLemma (.decl n12 true false)} {t.isLemma (.decl n12 false false)} {t.isLemma (.decl n12 true true)} {t.isLemma (.decl n12 false true)}"
  let n13 := `DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_4
  logInfo m!"DiophantineConsistency.CurrentMasks2011.lowSupport_value._simp_4: {t.isLemma (.decl n13 true false)} {t.isLemma (.decl n13 false false)} {t.isLemma (.decl n13 true true)} {t.isLemma (.decl n13 false true)}"
