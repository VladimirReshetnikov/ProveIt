from pathlib import Path
import os,subprocess,time,json,hashlib
p=Path('/tmp/mask-support-sharing-20261028'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip(); records=[]
for phase in ('baseline','final'):
 src=p/'audit-equations.lean';o=p/(phase+'-audit-equations.log');tm=p/(phase+'-audit-equations.time');env=os.environ.copy();env['LEAN_PATH']=str(p/phase)+':'+lp;cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M8000','-j1','-DElab.async=false',str(src)]; before=h(src)
 with o.open('wb') as f:t=time.monotonic();rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 records.append({'phase':phase,'command':cmd,'lean_path':env['LEAN_PATH'],'status':rc,'source_sha256':before,'source_after':h(src),'log_sha256':h(o),'time':tm.read_text(),'elapsed':round(time.monotonic()-t,2)});(p/'audit-equations-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,rc,flush=True)
 if rc or before!=h(src):raise SystemExit(1)
