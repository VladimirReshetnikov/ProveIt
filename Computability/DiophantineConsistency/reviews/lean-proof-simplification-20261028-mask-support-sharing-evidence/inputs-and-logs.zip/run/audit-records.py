import hashlib,json
from pathlib import Path
p=Path('/tmp/mask-support-sharing-20261028');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for fn,count in [('records.json',8),('client-records.json',6),('name-records.json',2),('interface-records.json',2)]:
 records=json.loads((p/fn).read_text());assert len(records)==count
 for r in records:
  cmd=r['command'];phase=r['phase'];name=r['name'];src=[Path(x) for x in cmd if x.endswith('.lean')];assert len(src)==1
  assert r['status']==0 and r['lean_path'].split(':')[0]==str(p/phase)
  assert r['source_sha256']==r['source_after']==h(src[0]);assert cmd[-2]=='-o' and h(cmd[-1])==r['object_sha256']
  assert h(p/(phase+'-'+name+'.log'))==r['log_sha256'];assert Path(cmd[4]).read_text()==r['time']
 print(fn,count,'records checked')
root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
for n in ('CurrentMaskData2011','CurrentMasks2011','CurrentMaskRecipes2011','ArithmeticMaskData'):
 assert h(root/(n+'.lean'))==h(p/'baseline/DiophantineConsistency'/(n+'.lean'))
print('4 baseline snapshots match worktree')
assert (p/'baseline-interface.log').read_bytes()==(p/'final-interface.log').read_bytes()
a=set((p/'baseline-names.log').read_text().splitlines());b=set((p/'final-names.log').read_text().splitlines());rem=set((p/'removed-names.txt').read_text().splitlines());assert a-b==rem
print('Namespace counts',len(a),len(b),'removed',len(rem),'added',len(b-a)); print('added:', sorted(b-a))
