import re,json,tomllib,hashlib
from pathlib import Path
r=Path.cwd(); p=Path('/tmp/mask-support-sharing-20261028');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest(); conf=tomllib.loads(Path('lakefile.toml').read_text()); roots=[Path(x.get('srcDir','.')) for x in conf.get('lean_lib',[])];roots=list(dict.fromkeys(roots));
def source(m):
 for root in roots:
  f=root/(m.replace('.','/')+'.lean')
  if f.exists():return f
 return None
def obj(m,phase):
 file=m.replace('.','/')+'.olean'
 for d in (p/phase,Path('.lake/build/lib/lean')):
  f=d/file
  if f.exists():return f
 return None
queue=['DiophantineConsistency.'+x for x in ['CurrentMaskData2011','CurrentMasks2011','CurrentMaskRecipes2011','ArithmeticMaskData','CurrentMasks2011Checks','ArithmeticMaskConstants','MFCurrentMasks2011']]; seen=set();nodes={};ext=set()
while queue:
 n=queue.pop()
 if n in seen:continue
 seen.add(n);s=source(n)
 if s is None:ext.add(n);continue
 im=[]
 for line in s.read_text().splitlines():
  if line.startswith('import '):im+=line.split('--')[0].split()[1:]
 queue+=im
 nodes[n]={'source':str(s),'source_sha256':h(s),'imports':im}
for n,x in nodes.items():
 a=obj(n,'baseline');b=obj(n,'final'); x.update(baseline_object=str(a.resolve()) if a else None,final_object=str(b.resolve()) if b else None,baseline_sha256=h(a) if a else None,final_sha256=h(b) if b else None)
rec=[]
for fn in ['/tmp/selector-shared-20261028/selected-objects.json','/tmp/outer-seed-bound-sharing/assembly-builds2.json','/tmp/bound-graph-independent/audit-phases.json']:
 data=json.loads(Path(fn).read_text());rows=data if isinstance(data,list) else data['local_pins'];rec += [(str(Path(fn)),x) for x in rows if x.get('source_sha256') and x.get('object_sha256')]
for n,x in nodes.items():
 x['matches']=[f for f,y in rec if y.get('module')==n and y['source_sha256']==x['source_sha256'] and y['object_sha256']==x['baseline_sha256']]
changed={'DiophantineConsistency.'+x for x in ['CurrentMaskData2011','CurrentMasks2011','CurrentMaskRecipes2011','ArithmeticMaskData','CurrentMasks2011Checks','ArithmeticMaskConstants','MFCurrentMasks2011']}
unchanged={n:x for n,x in nodes.items() if n not in changed};diff=[n for n,x in unchanged.items() if x['baseline_sha256']!=x['final_sha256']];missing=[n for n,x in unchanged.items() if not x['baseline_sha256']];matched=[n for n,x in unchanged.items() if x['matches']];unmatched=[n for n,x in unchanged.items() if not x['matches']]
result={'nodes':nodes,'external':sorted(ext),'summary':{'local_count':len(nodes),'external_count':len(ext),'unchanged':len(unchanged),'different':diff,'missing':missing,'matched':len(matched),'unmatched':unmatched}}
(p/'audit-graph.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['summary'],indent=2))
