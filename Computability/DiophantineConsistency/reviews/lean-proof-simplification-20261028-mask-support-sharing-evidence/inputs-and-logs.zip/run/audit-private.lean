import DiophantineConsistency.CurrentMaskRecipes2011
import DiophantineConsistency.ArithmeticMaskData
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    let s := n.toString
    if s.startsWith "_private.DiophantineConsistency.CurrentMaskData2011." ||
       s.startsWith "_private.DiophantineConsistency.CurrentMasks2011." ||
       s.startsWith "_private.DiophantineConsistency.CurrentMaskRecipes2011." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticMaskData." then
      let axs ← collectAxioms n
      logInfo m!"NAME {n}\nTYPE {c.type}\nAXIOMS {axs}"
