from pathlib import Path
import hashlib,json,subprocess,re
r=Path('/dev/shm/pell-unit-advance-sharing-refresh');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest();names=['ArithmeticPellKnownUnit','ArithmeticPellFirstNorm','ArithmeticPellKnownUnitChecks','ArithmeticPellCommonUnit','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex'];rec={}
for ph in ('baseline','final'):
 rows=json.loads((r/(ph+'-records.json')).read_text());assert [x['module'] for x in rows]==names;rec[ph]={}
 for x in rows:
  assert x['phase']==ph and x['status']==0 and h(x['source'])==x['before']==x['after'] and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time'];assert 'warning:' not in Path(x['log']).read_text().lower();rec[ph][x['module']]=x
  if ph=='baseline' or x['module'] not in names[:2]:assert x['before']==h(w/(x['module']+'.lean'))
  for d in x['direct_inputs']:
   path=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert path==Path(d['path']) and str(path.resolve())==d['resolved'] and h(path)==d['before']==d['after'] and h(d['source'])==d['source_before']==d['source_after'];mod=d['module'].split('.')[-1]
   if mod in rec[ph]:assert d['before']==rec[ph][mod]['object_sha256'] and d['source_before']==rec[ph][mod]['before']
 probes=json.loads((r/(ph+'-probes.json')).read_text());assert [x['name'] for x in probes]==['names','interfaces','simp','instances']
 for p in probes:
  assert p['phase']==ph and p['status']==0 and h(p['source'])==p['source_before']==p['source_after'] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256'];objs=[]
  for n in names:
   o=next(Path(q)/'DiophantineConsistency'/(n+'.olean') for q in p['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(n+'.olean')).is_file());assert o==Path(rec[ph][n]['object']);objs.append(h(o))
  assert p['objects']==[rec[ph][n]['object'] for n in names] and p['objects_before']==p['objects_after']==objs
 print('PASS',ph,'6 builds, input first providers and 4 six-object-pinned probes')
for n in names[2:5]:assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
assert rec['baseline']['ArithmeticPellFirstIndex']['object_sha256']!=rec['final']['ArithmeticPellFirstIndex']['object_sha256']
for kind in ('simp','instances'):assert (r/('baseline-'+kind+'.log')).read_bytes()==(r/('final-'+kind+'.log')).read_bytes()
def get(ph):
 s=(r/(ph+'-interfaces.log')).read_text();return {m.group(1):m.group(0).split(' TYPE ',1)[1] for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',s)}
a,b=get('baseline'),get('final');old='_private.DiophantineConsistency.ArithmeticPellKnownUnit.0.DiophantineConsistency.ArithmeticPellKnownUnit.advance_iff';new='DiophantineConsistency.ArithmeticPellKnownUnit.advance_iff';assert set(a)-set(b)=={old} and set(b)-set(a)=={new} and a[old].split()==b[new].split() and all(a[n]==b[n] for n in set(a)&set(b)) and len(set(a)&set(b))==38
for name,path in [('ArithmeticPellClassification','/tmp/pell-positive-reflect/final-records.json'),('ArithmeticPellCongruences','/tmp/pell-y-add/final-records.json'),('ArithmeticGcdNormalization','/tmp/gcd-product-positivity/final-records.json'),('ArithmeticPellHalfIndex','/tmp/four-positive-wrappers/upstream-records.json')]:
 inputs=[d for x in rec['baseline'].values() for d in x['direct_inputs'] if d['module'].split('.')[-1]==name];assert inputs;d=inputs[0];matches=[x for x in json.load(open(path)) if x.get('module','').split('.')[-1]==name and x.get('status')==0 and x.get('object_sha256')==d['before'] and x.get('before')==x.get('after')==d['source_before']];assert matches
 for ph in ('baseline','final'):
  for d2 in [z for x in rec[ph].values() for z in x['direct_inputs'] if z['module'].split('.')[-1]==name]:assert (d2['before'],d2['source_before'])==(d['before'],d['source_before'])
 print('PASS source-current direct producer',name,d['before'])
p=subprocess.run(['git','grep','-n','-E',r'(ArithmeticPellKnownUnit\.advance_iff|_private\.DiophantineConsistency\.ArithmeticPellKnownUnit.*advance_iff)','--','*.lean','*.py'],capture_output=True,text=True);assert p.returncode==1
print('PASS 38 common declaration reports, promoted theorem same type/axioms, global registrations and no tracked references to old/new names; cached closure not audited')
