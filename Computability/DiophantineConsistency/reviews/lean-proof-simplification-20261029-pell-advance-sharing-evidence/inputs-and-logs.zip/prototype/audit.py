from pathlib import Path
import hashlib,json,collections
r=Path('/dev/shm/pell-unit-advance-sharing-refresh');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ns=['ArithmeticPellKnownUnit','ArithmeticPellFirstNorm','ArithmeticPellKnownUnitChecks','ArithmeticPellCommonUnit','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex'];records={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text()); assert [x['module'] for x in rows]==ns
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source'])
  assert x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/(phase+'-'+x['module']+'.time')).read_text()
  for a in x['direct_inputs']:
   assert a['before']==a['after']==h(a['path']) and a['source_before']==a['source_after']==h(a['source'])
 rows_probe=json.loads((r/(phase+'-probes.json')).read_text());assert [x['name'] for x in rows_probe]==['names','interfaces','simp','instances']
 for x in rows_probe:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source'])
  assert x['objects_before']==x['objects_after']==[y['object_sha256'] for y in rows]
  assert x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
 records[phase]=rows
 print('PASS builds and six-object-pinned probes',phase)
for i,n in enumerate(ns):
 a=records['baseline'][i];b=records['final'][i]
 print('client object' if i>1 else 'target object',n,'equal',a['object_sha256']==b['object_sha256'])
 if i in (2,3,4):assert a['object_sha256']==b['object_sha256']
for n in ('simp','instances'):
 a=(r/('baseline-'+n+'.log')).read_bytes();b=(r/('final-'+n+'.log')).read_bytes();assert a==b;print('PASS',n,'registrations',len(a.splitlines()))
def blocks(ph):
 s=(r/(ph+'-interfaces.log')).read_text();return {z.split(' TYPE ',1)[0]:z.split(' TYPE ',1)[1] for z in s.split('DECL ')[1:]}
a,b=blocks('baseline'),blocks('final');common=a.keys()&b.keys();old='_private.DiophantineConsistency.ArithmeticPellKnownUnit.0.DiophantineConsistency.ArithmeticPellKnownUnit.advance_iff';new='DiophantineConsistency.ArithmeticPellKnownUnit.advance_iff';assert a.keys()-b.keys()=={old} and b.keys()-a.keys()=={new};assert all(a[k]==b[k] for k in common);assert a[old].split()==b[new].split();print('PASS',len(common),'common declaration/type/axiom reports; existing private equivalence promoted to public')
producers={'ArithmeticPellClassification':'/tmp/pell-positive-reflect/final-records.json','ArithmeticPellCongruences':'/tmp/pell-y-add/final-records.json','ArithmeticGcdNormalization':'/tmp/gcd-product-positivity/final-records.json','ArithmeticPellHalfIndex':'/tmp/four-positive-wrappers/upstream-records.json'}
for n,p in producers.items():
 ins=[x for y in records['baseline'] for x in y['direct_inputs'] if x['module'].split('.')[-1]==n];assert ins
 rows=json.loads(Path(p).read_text());matches=[x for x in rows if x.get('module')==n and x.get('status')==0 and x.get('object_sha256')==ins[0]['before'] and x.get('before')==x.get('after')==ins[0]['source_before']];assert matches
 for phase in ('baseline','final'):
  for x in [x for y in records[phase] for x in y['direct_inputs'] if x['module'].split('.')[-1]==n]:assert (x['before'],x['source_before'])==(ins[0]['before'],ins[0]['source_before'])
 print('PASS source-matched producer',n,p)
print('PASS; broader transitive closure remains cached')
