import Lean.Elab.Command
import DiophantineConsistency.ArithmeticPellKnownUnit
import DiophantineConsistency.ArithmeticPellFirstNorm
import DiophantineConsistency.ArithmeticPellKnownUnitChecks
import DiophantineConsistency.ArithmeticPellCommonUnit
import DiophantineConsistency.ArithmeticPellFirstNormChecks
import DiophantineConsistency.ArithmeticPellFirstIndex
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellKnownUnit).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellKnownUnit" || (`DiophantineConsistency.ArithmeticPellFirstNorm).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNorm" || (`DiophantineConsistency.ArithmeticPellKnownUnitChecks).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellKnownUnitChecks" || (`DiophantineConsistency.ArithmeticPellCommonUnit).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellCommonUnit" || (`DiophantineConsistency.ArithmeticPellFirstNormChecks).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNormChecks" || (`DiophantineConsistency.ArithmeticPellFirstIndex).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstIndex" then
   logInfo m!"DECL {n}"
