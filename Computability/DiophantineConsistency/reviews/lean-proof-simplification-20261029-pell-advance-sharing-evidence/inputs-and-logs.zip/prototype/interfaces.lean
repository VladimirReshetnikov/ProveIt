import Lean.Elab.Command
import DiophantineConsistency.ArithmeticPellKnownUnit
import DiophantineConsistency.ArithmeticPellFirstNorm
import DiophantineConsistency.ArithmeticPellKnownUnitChecks
import DiophantineConsistency.ArithmeticPellCommonUnit
import DiophantineConsistency.ArithmeticPellFirstNormChecks
import DiophantineConsistency.ArithmeticPellFirstIndex
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, info) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticPellKnownUnit).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellKnownUnit" || (`DiophantineConsistency.ArithmeticPellFirstNorm).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNorm" || (`DiophantineConsistency.ArithmeticPellKnownUnitChecks).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellKnownUnitChecks" || (`DiophantineConsistency.ArithmeticPellCommonUnit).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellCommonUnit" || (`DiophantineConsistency.ArithmeticPellFirstNormChecks).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNormChecks" || (`DiophantineConsistency.ArithmeticPellFirstIndex).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticPellFirstIndex" then
   let ty ← liftTermElabM (Lean.Meta.ppExpr info.type)
   let ax ← Lean.collectAxioms n
   logInfo m!"DECL {n} TYPE {ty} AXIOMS {ax}"
