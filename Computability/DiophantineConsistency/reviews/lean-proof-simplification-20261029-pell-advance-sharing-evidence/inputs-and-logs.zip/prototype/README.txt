Share the generic Pell unit-advance equivalence

The final candidate promotes ArithmeticPellKnownUnit.advance_iff from private to
public, then uses that existing generic equivalence to prove
ArithmeticPellFirstNorm.norm_advance_iff at the explicit unit (2*q+3, 2).
The specialized polynomial proof shrinks by nine net lines; no existing theorem
statement, definition or assumption changes. The promoted theorem has the same
type and axioms as its former private declaration. The affected proof and
original helper came from commits ad92d07c8a9 and eecfc7f4e29, respectively,
whose commit messages do not credit Claude.

Both phases build KnownUnit, FirstNorm and all four tracked direct Lean clients
(KnownUnitChecks, CommonUnit, FirstNormChecks, FirstIndex). Three client objects
are byte-identical; FirstIndex differs. Probe records pin all six exact phase
objects: all 38 common namespace/type/axiom reports match, with one private
advance_iff name replaced by one public name. Global sampled simp (28977) and
instance (13170) entries match. These comparisons do not establish proof-body or
full persistent-extension equality. Neither target nor client builds emitted
warnings. Checks files print axiom reports in their regular build logs.

Each phase directly pins source and object inputs before and after building.
The four external direct providers Classification, Congruences,
GcdNormalization and HalfIndex match successful source-current producer rows
in the paths named by audit.py. The Classification object in this refresh is
0ff552f5..., replacing the older object 2ffb62f2... used in the earlier
baseline-only lane at /dev/shm/pell-unit-advance-sharing. Their wider transitive
closures and other downstream clients remain cached or untested; matching a
producer's direct source does not establish a complete current-source rebuild.
All paths under /dev/shm are transient. audit.py verifies the build/probe records,
actual objects and source hashes, four source-matched producer rows, comparison
results, and timings. Audit output is audit.log.
