from pathlib import Path
import hashlib,json,shutil,re,subprocess,os
B=Path(__file__).resolve().parent.parent;W=Path('/tmp/oracle-share');R=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads((W/'baseline-records.json').read_text());fin=json.loads((W/'audit-records.json').read_text());
for phase,items in [('baseline',base),('final',fin)]:
 for item in items:
  if item['name']=='interface':continue
  p=Path(item['source']);assert item['before']==item['after']
  assert item['status']==0
  dest=(B/'sources'/phase if item['name'] in ['ArithmeticSymbolicCore215','ArithmeticRuntimeBoundTapeSymbolic'] else B/'sources/clients')/p.name
  if phase=='baseline' and item['name'] in ['ArithmeticSymbolicCore215','ArithmeticRuntimeBoundTapeSymbolic']:
   data=subprocess.check_output(['git','show','7468398429d01977e93511a024d427c81591c038:'+str(p)])
   assert hashlib.sha256(data).hexdigest()==item['before'];dest.write_bytes(data)
  else:
   assert sha(p)==item['before'],p
   if dest.exists():assert sha(dest)==sha(p)
   else:shutil.copy2(p,dest)
  if item['object']:assert sha(item['object'])==item['object_sha256'],item['object']
for p in W.glob('*.log'):shutil.copy2(p,B/'logs'/p.name)
for p in W.glob('*.time'):shutil.copy2(p,B/'logs'/p.name)
for name in ['make.py','audit.py','audit-final.py']:shutil.copy2(W/name,B/'scripts'/name)
shutil.copy2(W/'baseline-records.json',B/'records'/'baseline-original-records.json');shutil.copy2(W/'audit-records.json',B/'records'/'final-original-records.json')
for n in ['forward-plan.json','forward-common-pins.json','forward-build-records.json','forward-ir-pins.json','forward-companions.json']:
 p=Path('/tmp/bisim-share')/n
 if p.exists():shutil.copy2(p,B/'provenance'/n)
# Input hashes below were sampled after the compile, not at the time of each compile.
lakepath=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip().split(':')
inputs=[]
for phase,items in [('baseline',base),('final',fin)]:
 search=[W/phase]+[Path(x) for x in lakepath]
 for item in items:
  if item['name']=='interface':continue
  source=(B/'sources'/phase if item['name'] in ['ArithmeticSymbolicCore215','ArithmeticRuntimeBoundTapeSymbolic'] else B/'sources/clients')/(item['name']+'.lean')
  mods=re.findall(r'^import\s+([^\s]+)',source.read_text(),re.M)
  for m in mods:
   candidates=[d/(m.replace('.','/')+'.olean') for d in search]; obj=next((p for p in candidates if p.is_file()),None)
   inputs.append({'phase':phase,'client':item['name'],'module':m,'visible_object_path':str(obj) if obj else None,'resolved_path':str(obj.resolve()) if obj else None,'post_run_object_sha256':sha(obj) if obj else None})
(B/'provenance'/'direct-inputs-post-run.json').write_text(json.dumps(inputs,indent=2)+'\n')
plan=json.loads(Path('/tmp/bisim-share/forward-plan.json').read_text())['nodes']; pins=json.loads(Path('/tmp/bisim-share/forward-common-pins.json').read_text())['selected']; build=json.loads(Path('/tmp/bisim-share/forward-build-records.json').read_text());pinned={x['module']:x for x in pins};built={x['module']:x for x in build};seen=set();todo=['DiophantineConsistency.ArithmeticControlFrame215']
while todo:
 n=todo.pop()
 if n in seen or n not in plan:continue
 seen.add(n);todo+=plan[n]['imports']
closure=[]
for n in sorted(seen):
 info=plan[n];src=Path(info['source']); obj=W/'lib'/(n.replace('.','/')+'.olean');record=built.get(n) or pinned.get(n)
 closure.append({'module':n,'source':str(src),'planned_source_sha256':info['source_sha256'],'post_run_source_sha256':sha(src) if src.is_file() else None,'overlay_object':str(obj),'post_run_object_sha256':sha(obj) if obj.is_file() else None,'receipt_kind':('forward-build-records' if n in built else 'forward-common-pins' if n in pinned else None),'receipt_object_sha256':record.get('object_sha256') if record else None,'receipt_source_sha256':record.get('source_sha256') if record else None})
(B/'provenance'/'control-frame-closure-post-run.json').write_text(json.dumps(closure,indent=2)+'\n')
print('snapshots copied; inputs',len(inputs),'missing',sum(x['post_run_object_sha256'] is None for x in inputs),'closure',len(closure),'source mismatch',sum(x['post_run_source_sha256']!=x['planned_source_sha256'] for x in closure),'receipt object mismatch',sum(x['post_run_object_sha256']!=x['receipt_object_sha256'] for x in closure if x['receipt_object_sha256']),'no receipt',sum(x['receipt_object_sha256'] is None for x in closure))
