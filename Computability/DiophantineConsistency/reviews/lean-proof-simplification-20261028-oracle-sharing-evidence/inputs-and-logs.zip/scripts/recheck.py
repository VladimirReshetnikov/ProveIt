from pathlib import Path
import hashlib,json,os,subprocess,time
B=Path(__file__).resolve().parent.parent; W=Path('/tmp/oracle-share'); results=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip()
for phase in ['baseline','final']:
 for probe in ['interface','names','stable-interfaces','all-interfaces','simp']:
  src=B/'scripts'/f'{probe}.lean'; log=B/'verified'/f'{phase}-{probe}.log'; tm=B/'verified'/f'{phase}-{probe}.time'
  env=os.environ.copy();env['LEAN_PATH']=str(W/phase)+':'+base
  cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
  before=sha(src);t=time.monotonic()
  with log.open('wb') as f: p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  result={'phase':phase,'probe':probe,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'elapsed':round(time.monotonic()-t,2),'source_sha256_before':before,'source_sha256_after':sha(src),'log_sha256':sha(log),'time':tm.read_text()};results.append(result)
  print(phase,probe,p.returncode,result['time'].strip(),flush=True)
  assert before==result['source_sha256_after']
  assert p.returncode==(1 if phase=='final' and probe=='all-interfaces' else 0)
(B/'verified'/'recheck-records.json').write_text(json.dumps(results,indent=2)+'\n')
for probe in ['interface','stable-interfaces']:
 assert (B/'verified'/f'baseline-{probe}.log').read_bytes()==(B/'verified'/f'final-{probe}.log').read_bytes(),probe
n=lambda phase:{s for s in (B/'verified'/f'{phase}-names.log').read_text().splitlines() if s.startswith('DECL ')}
a=n('baseline');b=n('final');assert a-b=={'DECL DiophantineConsistency.ArithmeticRuntimeBoundTapeSymbolic.sstep_actualB._proof_21'};assert b-a=={'DECL DiophantineConsistency.ArithmeticRuntimeBoundTapeSymbolic.sstep_actualB._proof_25','DECL DiophantineConsistency.ArithmeticSymbolicCore215.oracle_of_boxes'}
s=lambda phase:set((B/'verified'/f'{phase}-simp.log').read_text().splitlines());assert s('baseline')==s('final') and len(s('baseline'))==16
print('All expected comparisons passed.')
