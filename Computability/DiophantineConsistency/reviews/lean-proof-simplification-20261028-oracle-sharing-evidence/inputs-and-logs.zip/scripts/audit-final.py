from pathlib import Path
import os,subprocess,time,hashlib,json
R=Path('/tmp/oracle-share'); orig=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency'); base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip(); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); rec=[]
for phase in ['final']:
 out=R/phase;out.mkdir(exist_ok=True)
 for p in (R/'lib').rglob('*'):
  if not p.is_file():continue
  q=out/p.relative_to(R/'lib');q.parent.mkdir(parents=True,exist_ok=True)
  if not q.exists():q.symlink_to(p.resolve())
 env=os.environ.copy();env['LEAN_PATH']=str(out)+':'+base
 def run(name,src,emit=True):
  obj=out/'DiophantineConsistency'/f'{name}.olean' if emit else None
  if obj: obj.unlink(missing_ok=True)
  log=R/f'{phase}-{name}.log';tm=R/f'{phase}-{name}.time';root=R/'src' if str(src).startswith(str(R/'src')) else orig.parent
  cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src)]
  if obj: cmd+=['-o',str(obj)]
  start=time.monotonic();before=sha(src)
  with log.open('wb') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  entry={'phase':phase,'name':name,'source':str(src),'before':before,'after':sha(src),'status':proc.returncode,'time':tm.read_text(),'object':str(obj) if obj else None,'object_sha256':sha(obj) if obj and obj.exists() else None,'log':str(log),'log_sha256':sha(log),'elapsed':round(time.monotonic()-start,1)};rec.append(entry);(R/'audit-records.json').write_text(json.dumps(rec,indent=2));print(phase,name,proc.returncode,entry['time'].strip(),flush=True)
  if proc.returncode or before!=entry['after']:raise SystemExit(1)
 for n in ['ArithmeticSymbolicCore215','ArithmeticHome215','ArithmeticSite215','ArithmeticControlFrame215','ArithmeticRuntimeBoundTape','ArithmeticRuntimeBoundTapeBoxes','ArithmeticRuntimeBoundTapeSymbolic','ArithmeticRuntimeBoundTapeControl']:
  src=(R/'src/DiophantineConsistency'/f'{n}.lean') if phase=='final' and n in ['ArithmeticSymbolicCore215','ArithmeticRuntimeBoundTapeSymbolic'] else orig/f'{n}.lean'
  run(n,src)
 run('ArithmeticSymbolicCore215Checks',orig/'ArithmeticSymbolicCore215Checks.lean',False)
 run('interface',R/'interface.lean',False)
