from pathlib import Path
p=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')
a=(p/'ArithmeticSymbolicCore215.lean').read_text();b=(p/'ArithmeticRuntimeBoundTapeSymbolic.lean').read_text()
start=a.index('/-- The actual checker oracle,');end=a.index('\nnoncomputable def segValue',start); block=a[start:end];proof=block[block.index('  cases x with'):];proof=proof.replace('box_mark v ⟨r,hr⟩ L k','hmark ⟨r,hr⟩').replace('box_inc v ⟨r,hr⟩ L k','hinc ⟨r,hr⟩').replace('box_decp v ⟨r,hr⟩ L k hp','hdecp ⟨r,hr⟩ hp').replace('box_dec0 v ⟨r,hr⟩ L k hk hz','hdec0 ⟨r,hr⟩ hz')
generic='''/-- Oracle dispatch is independent of the relation used to certify each box. -/
theorem oracle_of_boxes (v : Fin 9 → V) (k L : V) (R : V → V → Prop)
    (hmark : ∀ r : Fin 9, R (frameSparse (skipState r) L (plain v k))
      (leftFrame (markExit r) L (marked v r k)))
    (hinc : ∀ r : Fin 9, R (frameSparse 64 L (marked v r k))
      (leftFrame 40 L (plain (Function.update v r (v r+1)) (k+1))))
    (hdecp : ∀ r : Fin 9, 0 < v r → R (frameSparse 0 L (marked v r k))
      (leftFrame 40 (2*L+1) (plain (Function.update v r (v r-1)) k)))
    (hdec0 : ∀ r : Fin 9, v r = 0 → R (frameSparse 0 L (marked v r k))
      (leftFrame 97 L (plain v k)))
    {q q' : Nat} {br : Branch} {x x' : BoxSt} {extra : Bool}
    (h : KRuntimeCore.oracle q br x=some (q',x',extra)) (hv : BranchValid br v) :
    R (frameSparse q L (boxValue v k x))
      (leftFrame q' (if extra then 2*L+1 else L) (boxValue v k x')) := by
'''+proof
oldhead=block[:block.index(' := by\n')+len(' := by\n')]
new=oldhead+'''  exact oracle_of_boxes v k L ReachPos
    (fun r => box_mark v r L k) (fun r => box_inc v r L k)
    (fun r hr => box_decp v r L k hr) (fun r hr => box_dec0 v r L k hk hr) h hv
'''
a=a[:start]+generic+'\n\n'+new+a[end:]
start=b.index('/-- `oracle_actual` within the box bound. -/');end=b.index('\nlemma peelLeft_actualB',start);block=b[start:end];head=block[:block.index(' := by\n')+len(' := by\n')];new=head+'''  exact oracle_of_boxes v k L (fun a b => ReachPosB a b (boxW v k))
    (fun r => box_markB v r L k) (fun r => box_incB v r L k)
    (fun r hr => box_decpB v r L k hr) (fun r hr => box_dec0B v r L k hk hr) h hv
''';b=b[:start]+new+b[end:]
Path('/tmp/oracle-share/src/DiophantineConsistency/ArithmeticSymbolicCore215.lean').write_text(a);Path('/tmp/oracle-share/src/DiophantineConsistency/ArithmeticRuntimeBoundTapeSymbolic.lean').write_text(b)
