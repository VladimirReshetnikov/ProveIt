from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent.parent
manifest=root/'manifest.sha256'
files=sorted(x for x in root.rglob('*') if x.is_file() and x!=manifest)
manifest.write_text(''.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+x.relative_to(root).as_posix()+'\n' for x in files))
print('manifest entries:',len(files))
