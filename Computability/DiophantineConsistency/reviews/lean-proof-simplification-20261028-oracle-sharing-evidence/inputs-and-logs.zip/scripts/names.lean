import DiophantineConsistency.ArithmeticRuntimeBoundTapeControl
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticSymbolicCore215).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticRuntimeBoundTapeSymbolic).isPrefixOf n then
      logInfo m!"DECL {n}"
