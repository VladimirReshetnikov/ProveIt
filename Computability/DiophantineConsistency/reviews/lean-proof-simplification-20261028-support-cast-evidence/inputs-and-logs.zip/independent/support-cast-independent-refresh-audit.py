from pathlib import Path
import json,hashlib
r=Path('/tmp/support-cast');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();xs=json.loads((r/'refresh-records.json').read_text());assert len(xs)==6;mapping=[]
for x in xs:
 assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']);o=Path(x['command'][-1]);log=r/f"{x['phase']}-{x['module']}.log";tm=Path(x['command'][x['command'].index('-o')+1]);assert o.is_file() and not o.is_symlink() and x['object_sha256']==h(o) and x['log_sha256']==h(log) and x['time']==tm.read_text()
 for n,d in x['inputs'].items():
  rel=n.replace('.','/')+'.olean';first=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(first.resolve())==d['object'] and d['object_before']==d['object_after']==h(first)
  if d['source']:assert d['source_before']==d['source_after']==h(d['source'])
  mapping.append({'client':x['phase']+':'+x['module'],'module':n,'source_sha256':d['source_before'],'object_sha256':d['object_before'],'object':d['object']})
 print(x['phase'],x['module'],len(x['inputs']),'inputs verified',x['time'].strip())
for ph in ('fresh-base','fresh-final'):
 x=next(x for x in xs if x['phase']==ph and x['module']=='ArithmeticCellDecoding'); y=next(y for y in xs if y['phase']==ph and y['module']=='ArithmeticCellTransfer');assert x['inputs']['DiophantineConsistency.ArithmeticCellTransfer']['object']==y['command'][-1] and x['inputs']['DiophantineConsistency.ArithmeticCellTransfer']['object_before']==y['object_sha256']
for n in ('ArithmeticCellLocal','ArithmeticCellLabels'):
 x=next(x for x in xs if x['phase']=='fresh' and x['module']==n)
 if n=='ArithmeticCellLabels':assert x['inputs']['DiophantineConsistency.ArithmeticCellLocal']['object']==next(y['command'][-1] for y in xs if y['phase']=='fresh' and y['module']=='ArithmeticCellLocal')
(r/'independent-refresh-mapping.json').write_text(json.dumps(mapping,indent=2)+'\n');print('total',len(xs),'builds',len(mapping),'direct inputs; outputs regular')
