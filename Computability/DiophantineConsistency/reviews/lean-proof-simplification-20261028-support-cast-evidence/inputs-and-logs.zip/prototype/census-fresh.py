from pathlib import Path
import os,subprocess,hashlib,json
r=Path('/tmp/support-cast');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(phase,name):
 src=r/f'{name}.lean';log=r/f'{phase}-{name}.log';tm=r/f'{phase}-{name}.time';env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':/tmp/mask-ins-simplify/final:'+base;before=sha(src);inp=Path(env['LEAN_PATH'].split(':')[0])/'DiophantineConsistency/ArithmeticCellTransfer.olean'; ibefore=sha(inp);cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'phase':phase,'name':name,'source':str(src),'before':before,'after':sha(src),'direct_object':str(inp),'direct_before':ibefore,'direct_after':sha(inp),'cmd':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':p.returncode,'time':tm.read_text(),'log_sha256':sha(log)};records.append(row);(r/'fresh-census-records.json').write_text(json.dumps(records,indent=2));print(phase,name,p.returncode,flush=True)
 if p.returncode or before!=row['after'] or ibefore!=row['direct_after']:raise SystemExit(1)
(r/'names.lean').write_text('''import DiophantineConsistency.ArithmeticCellTransfer
#print equations DiophantineConsistency.ArithmeticCellTransfer.inSupport
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let t ← liftCoreM Lean.Meta.getSimpTheorems
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n ||
       (`_private.DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n then
      logInfo m!"DECL {n}"
    if t.isLemma (.decl n true false) || t.isLemma (.decl n false false) ||
       t.isLemma (.decl n true true) || t.isLemma (.decl n false true) then
      logInfo m!"SIMP {n} {t.isLemma (.decl n true false)} {t.isLemma (.decl n false false)} {t.isLemma (.decl n true true)} {t.isLemma (.decl n false true)}"
''')
for phase in ['fresh-base','fresh-final']:run(phase,'names')
def sets(p,prefix):return {s.split(prefix,1)[1].strip() for s in p.read_text().splitlines() if prefix in s}
a=sets(r/'fresh-base-names.log','DECL ');b=sets(r/'fresh-final-names.log','DECL ');sa=sets(r/'fresh-base-names.log','SIMP ');sb=sets(r/'fresh-final-names.log','SIMP ');print('names',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a),'global simp',len(sa),len(sb),'equal',sa==sb,flush=True)
common=sorted(n for n in a&b if not n.startswith('_private.'))
(r/'interfaces.lean').write_text('import DiophantineConsistency.ArithmeticCellTransfer\nset_option pp.universes true\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in common))
for phase in ['fresh-base','fresh-final']:run(phase,'interfaces')
print('public/generated',len(common),'reports equal',(r/'fresh-base-interfaces.log').read_bytes()==(r/'fresh-final-interfaces.log').read_bytes(),flush=True)
(r/'private.lean').write_text('''import DiophantineConsistency.ArithmeticCellTransfer
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, info) in env.constants.toList do
    if (`_private.DiophantineConsistency.ArithmeticCellTransfer).isPrefixOf n then
      let typ ← liftTermElabM (Lean.Meta.ppExpr info.type)
      let axioms ← Lean.collectAxioms n
      logInfo m!"PRIVATE {n} TYPE {typ} AXIOMS {axioms}"
''')
for phase in ['fresh-base','fresh-final']:run(phase,'private')
