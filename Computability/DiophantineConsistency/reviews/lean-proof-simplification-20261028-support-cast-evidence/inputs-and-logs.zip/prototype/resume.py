from pathlib import Path
import re,os,subprocess,hashlib,json
r=Path('/tmp/support-cast'); base=Path('Computability/DiophantineConsistency/Lean'); lp=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip(); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); records=json.loads((r/'refresh-records.json').read_text())
def build(phase,n,src,root):
 overlay=r/phase; env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':/tmp/mask-ins-simplify/final:'+lp; roots=[Path(x) for x in env['LEAN_PATH'].split(':')]; before=sha(src); inputs={}
 for name in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
  obj=next((x/(name.replace('.','/')+'.olean') for x in roots if (x/(name.replace('.','/')+'.olean')).is_file()),None)
  if obj is None: raise RuntimeError('missing '+name)
  source=base/(name.replace('.','/')+'.lean'); inputs[name]={'object':str(obj.resolve()),'object_before':sha(obj),'source':str(source) if source.exists() else None,'source_before':sha(source) if source.exists() else None}
 out=overlay/'DiophantineConsistency'/f'{n}.olean';log=r/f'{phase}-{n}.log';tm=r/f'{phase}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e user=%U system=%S maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(root),str(src),'-o',str(out)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for x in inputs.values():
  x['object_after']=sha(Path(x['object'])); x['source_after']=sha(Path(x['source'])) if x['source'] else None
 row={'phase':phase,'module':n,'source':str(src),'source_before':before,'source_after':sha(src),'inputs':inputs,'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':p.returncode,'time':tm.read_text(),'log_sha256':sha(log),'object_sha256':sha(out) if out.exists() else None};records.append(row);(r/'refresh-records.json').write_text(json.dumps(records,indent=2));print(phase,n,p.returncode,row['time'].strip(),flush=True)
 if p.returncode or before!=row['source_after'] or any(x['object_before']!=x['object_after'] or x['source_before']!=x['source_after'] for x in inputs.values()): raise SystemExit(1)
for phase in ['fresh-base','fresh-final']:
 (r/phase/'DiophantineConsistency').mkdir(parents=True,exist_ok=True)
 subprocess.run(['cp','-as',str(r/'fresh/DiophantineConsistency')+'/.' ,str(r/phase/'DiophantineConsistency/')],check=True)
 for n in ['ArithmeticCellTransfer','ArithmeticCellDecoding']:
  src=r/'src/DiophantineConsistency'/f'{n}.lean' if phase=='fresh-final' and n=='ArithmeticCellTransfer' else base/'DiophantineConsistency'/f'{n}.lean';root=r/'src' if src.is_relative_to(r/'src') else base
  build(phase,n,src,root)
