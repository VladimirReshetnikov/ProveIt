from pathlib import Path
import json,hashlib,collections
p=Path('/tmp/pell-construction-refresh'); h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[];counts={}
for fn in ('rotation-records.json','resumed-records.json','probe-records-v2.json','records.json'):
 rs=json.loads((p/fn).read_text()); counts[fn]=len(rs)
 for r in rs:
  key=r.get('module',r.get('tag'));cmd=r['command'];phase=r.get('phase');
  if r['status']!=0 or h(r['source'])!=r['source_sha256'] or r['source_sha256']!=r['source_after']:issues.append([fn,key,'status/source'])
  skip=fn=='records.json' and key in ('DiophantineConsistency.ArithmeticConstructionBound','DiophantineConsistency.ArithmeticCurrentConstruction2011')
  if not skip:
   for fld in ('log','time'):
    if h(r[fld])!=r[fld+'_sha256']:issues.append([fn,key,fld])
   if Path(r['time']).read_text().strip()!=r['timing']:issues.append([fn,key,'timing'])
  if 'object' in r:
   if h(r['object'])!=r['object_sha256'] or cmd[-2:]!=['-o',r['object']]:issues.append([fn,key,'object'])
   if not Path(r['object']).is_relative_to(Path(r['lean_path'].split(':')[0])):issues.append([fn,key,'overlay'])
  for x in r.get('local_inputs',[])+r.get('direct_external_inputs',[]):
   if x['sha256']!=x['after_sha256'] or h(x['path'])!=x['sha256']:issues.append([fn,key,'input',x['module']])
for name in ('interface','equations','construction','current'):
 if (p/('baseline-probe-v2-'+name+'.log')).read_bytes()!=(p/('final-probe-v2-'+name+'.log')).read_bytes():issues.append(['probe mismatch',name])
a=set((p/'baseline-probe-v2-names.log').read_text().splitlines());b=set((p/'final-probe-v2-names.log').read_text().splitlines()); print('namespace old/new',len(a),len(b),'removed',sorted(a-b),'added',sorted(b-a))
for n in ('ArithmeticGcdNormalization','ArithmeticPellCommonUnit','ArithmeticPellIntegralSolution','ArithmeticPellIndexDivisibility'):
 root=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');old=Path('/tmp/pell-norm-sharing/baseline/DiophantineConsistency')/(n+'.lean');
 if h(root)!=h(old):issues.append(['baseline drift',n])
print('checked records',counts,'issues',len(issues));print(json.dumps(issues[:20],indent=2));(p/'independent-audit-initial.json').write_text(json.dumps({'counts':counts,'issues':issues},indent=2)+'\n')
