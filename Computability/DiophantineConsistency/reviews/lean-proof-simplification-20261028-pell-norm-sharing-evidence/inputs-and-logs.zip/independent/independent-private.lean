import DiophantineConsistency.ArithmeticPellIndexDivisibility
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    let s := n.toString
    if s.startsWith "_private.DiophantineConsistency.ArithmeticGcdNormalization." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticPellCommonUnit." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticPellIntegralSolution." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticPellIndexDivisibility." then
      let axs ← collectAxioms n
      logInfo m!"NAME {n}\nTYPE {c.type}\nAXIOMS {axs}"
