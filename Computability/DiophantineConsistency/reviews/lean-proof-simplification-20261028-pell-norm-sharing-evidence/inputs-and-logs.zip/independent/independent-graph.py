from pathlib import Path
import re,json,tomllib,hashlib
p=Path('/tmp/pell-construction-refresh');plan=json.loads((p/'updated-plan.json').read_text());W=Path.cwd();roots=list(dict.fromkeys((W/x.get('srcDir','.')).resolve() for x in tomllib.loads((W/'lakefile.toml').read_text())['lean_lib']));h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[]
def strip(s):
 out=[];i=0;depth=0
 while i<len(s):
  pair=s[i:i+2]
  if depth:
   if pair=='/-':depth+=1;i+=2
   elif pair=='-/':depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif pair=='/-':depth=1;i+=2
  elif pair=='--':
   while i<len(s) and s[i]!='\n':i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def imports(f):
 out=[]
 for line in strip(Path(f).read_text()).splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:out.extend(m.group(1).split())
 return out
G={};E=set()
def visit(n):
 if n in G or n in E:return
 loc=list(dict.fromkeys((r/(n.replace('.','/')+'.lean')).resolve() for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()))
 if not loc:E.add(n);return
 if len(loc)!=1:issues.append(['ambiguous',n,len(loc)]);return
 f=loc[0];im=imports(f);G[n]=im
 for a in im:visit(a)
visit('DiophantineConsistency.ArithmeticConstructionBound')
if set(G)!=set(plan['nodes']):issues.append(['local graph',sorted(set(G)^set(plan['nodes']))])
if E!={x['module'] for x in plan['external']}:issues.append(['external graph',sorted(E^{x['module'] for x in plan['external']})])
for n,im in G.items():
 if sorted(im)!=sorted(plan['nodes'][n]['imports']):issues.append(['edges',n])
 if h(plan['nodes'][n]['source'])!=plan['nodes'][n]['source_sha256']:issues.append(['source drift',n])
for n in plan['changed']:
 for phase in ('baseline','final'):
  f=Path('/tmp/pell-norm-sharing')/phase/(n.replace('.','/')+'.lean')
  if imports(f)!=G[n]:issues.append(['phase import diff',phase,n])
for x in plan['external']:
 if h(x['object'])!=x['sha256']:issues.append(['external object drift',x['module']])
for x in json.loads((p/'local-pins.json').read_text()):
 for phase in ('baseline','final'):
  if h(x[phase+'_object'])!=x[phase+'_sha256']:issues.append(['local object drift',phase,x['module']])
changed=set(plan['changed']);imp=set(changed)
while True:
 old=len(imp);imp|={n for n,im in G.items() if set(im)&imp}
 if len(imp)==old:break
if imp!=set(plan['order']):issues.append(['changed descendant closure',sorted(imp^set(plan['order']))])
S={'nodes':len(G),'external':len(E),'affected':len(imp),'issues':issues};(p/'independent-graph-result.json').write_text(json.dumps(S,indent=2)+'\n');print(json.dumps(S,indent=2))
