import Lean.Elab.Command
import DiophantineConsistency.ArithmeticPellIndexDivisibility
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticGcdNormalization).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellCommonUnit).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellIntegralSolution).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellIndexDivisibility).isPrefixOf n then
      logInfo m!"{n}"
