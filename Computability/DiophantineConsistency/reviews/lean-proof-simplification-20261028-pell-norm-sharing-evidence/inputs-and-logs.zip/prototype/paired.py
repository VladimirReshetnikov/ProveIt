import pathlib,json,os,subprocess,hashlib,concurrent.futures
P=pathlib.Path('/tmp/pell-norm-sharing');r=json.loads(pathlib.Path('/tmp/pell-share/paired-records.json').read_text())[0];lp=r['lean_path'].split(':',1)[1];W=pathlib.Path('Computability/DiophantineConsistency/Lean');h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def phase(ph):
 root=P/ph;d=root/'DiophantineConsistency';env=os.environ.copy();env['LEAN_PATH']=str(root)+':'+lp;rec=[]
 targets=['ArithmeticGcdNormalization','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility','ArithmeticPellIntegralSolution','ArithmeticPellIndexDivisibility','ArithmeticPellHalfIndex']
 for n in targets:
  src=d/(n+'.lean') if (d/(n+'.lean')).exists() else W/'DiophantineConsistency'/(n+'.lean');srcroot=root if src.is_relative_to(root) else W;obj=d/(n+'.olean');obj.unlink(missing_ok=True);log=P/f'{ph}-{n}.log';tm=P/f'{ph}-{n}.time';cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M9000','-j1','-DElab.async=false','-R',str(srcroot),str(src),'-o',str(obj)];before=h(src)
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  z={'phase':ph,'module':n,'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'source_sha256':before,'source_after':h(src),'log_sha256':h(log),'time_sha256':h(tm),'object_sha256':h(obj) if obj.exists() else None};rec.append(z);(P/(ph+'-records.json')).write_text(json.dumps(rec,indent=2));print(ph,n,q.returncode,flush=True)
  if q.returncode:return
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(phase,['baseline','final']))
