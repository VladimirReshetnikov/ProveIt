from pathlib import Path
import json,hashlib,os,shutil
R=Path('/tmp/pell-construction-refresh');p=json.loads((R/'plan.json').read_text());nodes=p['nodes'];W=Path.cwd();h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();n='DiophantineConsistency.MFNativeBooleanRotation';v=nodes[n];src=Path(v['source']);old=Path('/tmp/construction-share/bound-graph-after-mask.json');prev=json.loads(old.read_text())['nodes'][n]
assert h(src)!=v['source_sha256'] and v['source_sha256']==prev['source_sha256'];imports=[l.split()[1] for l in src.read_text().splitlines() if l.startswith('import ')];assert sorted(imports)==sorted(v['imports']);v['source_sha256']=h(src)
changed=[x for x,v in nodes.items() if h(v['source'])!=v['source_sha256']];assert not changed,changed
affected={n}
while True:
 a=affected|{x for x,v in nodes.items() if any(i in affected for i in v['imports'])}
 if a==affected:break
 affected=a
assert affected & set(p['order'])=={'DiophantineConsistency.ArithmeticConstructionBound'}
seen=set();active=set();order=[]
def visit(x):
 if x in seen:return
 assert x not in active;active.add(x)
 for d in nodes[x]['imports']:
  if d in affected:visit(d)
 active.remove(x);seen.add(x);order.append(x)
for x in sorted(affected):visit(x)
assert order[-1]=='DiophantineConsistency.ArithmeticConstructionBound' and len(order)==15
p['rotation_affected']=order;p['rotation_scope']='MFNativeBooleanRotation docstring changed; ordinary module outside Bound graph';p['prior_plan_sha256']=h(R/'plan.json');(R/'updated-plan.json').write_text(json.dumps(p,indent=2)+'\n')
shutil.copy2(R/'records.json',R/'interrupted-baseline-records.json');shutil.copy2(R/'console.log',R/'interrupted-baseline-console.log')
base=Path('/tmp/construction-share/pinned-final');ov=R/'rotation-common';ov.mkdir()
for dirpath,dirs,files in os.walk(base,followlinks=False):
 src=Path(dirpath);dst=ov/src.relative_to(base);dst.mkdir(exist_ok=True)
 for d in dirs[:]:
  q=src/d
  if q.is_symlink():os.symlink(str(q.resolve()),dst/d);dirs.remove(d)
 for f in files:os.symlink(str((src/f).resolve()),dst/f)
print('rotation descendants:',len(order),'shared rebuilds:',len(order)-1,'prior baseline builds:',len(json.loads((R/'records.json').read_text())))
