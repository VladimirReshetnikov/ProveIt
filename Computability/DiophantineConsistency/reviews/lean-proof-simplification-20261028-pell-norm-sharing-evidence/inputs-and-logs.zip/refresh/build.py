from pathlib import Path
import os,json,hashlib,subprocess,time
R=Path('/tmp/pell-construction-refresh');W=Path.cwd();p=json.loads((R/'plan.json').read_text());nodes=p['nodes'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=[]
prior=json.loads(Path('/tmp/construction-share/pinned-replay-records.json').read_text());lp=next(r['lean_path'].split(':',1)[1] for r in prior if r['phase']=='final')
client='DiophantineConsistency.ArithmeticCurrentConstruction2011';client_src=W/'Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticCurrentConstruction2011.lean'; client_imports=[l.split()[1] for l in client_src.read_text().splitlines() if l.startswith('import ')];assert all(x in nodes for x in client_imports)
for phase in ('baseline','final'):
 overlay=R/phase;env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+lp
 for n in p['order']+[client]:
  source=Path(nodes[n]['source']) if n!=client else client_src
  if n in p['changed']:
   source=R/(phase+'-source')/'DiophantineConsistency'/(n.split('.')[-1]+'.lean')
  srcroot=R/(phase+'-source') if n in p['changed'] else W/'Computability/DiophantineConsistency/Lean'
  imports=nodes[n]['imports'] if n!=client else client_imports
  local=[d for d in imports if d in nodes];before=[]
  for d in local:
   obj=overlay/(d.replace('.','/')+'.olean');assert obj.is_file(),(phase,n,d)
   before.append({'module':d,'path':str(obj),'resolved_path':str(obj.resolve()),'sha256':h(obj)})
  ext=[d for d in imports if d not in nodes];external={x['module']:x for x in p['external']}
  extbefore=[{'module':d,'path':external[d]['object'],'sha256':h(external[d]['object'])} for d in ext if d in external]
  output=overlay/(n.replace('.','/')+'.olean');output.parent.mkdir(parents=True,exist_ok=True);output.unlink(missing_ok=True)
  label=n.split('.')[-1];log=R/(phase+'-'+label+'.log');tm=R/(phase+'-'+label+'.time');src_hash=h(source)
  cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(srcroot),str(source),'-o',str(output)];t=time.monotonic()
  with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  inputs_after=[dict(a,after_sha256=h(a['path'])) for a in before];external_after=[dict(a,after_sha256=h(a['path'])) for a in extbefore]
  z={'phase':phase,'module':n,'source':str(source),'source_sha256':src_hash,'source_after':h(source),'command':cmd,'lean_path':env['LEAN_PATH'],'status':q.returncode,'elapsed':time.monotonic()-t,'object':str(output),'object_sha256':h(output) if output.is_file() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'local_inputs':inputs_after,'direct_external_inputs':external_after,'unmatched_direct_external_imports':[d for d in ext if d not in external]};rec.append(z);(R/'records.json').write_text(json.dumps(rec,indent=2)+'\n')
  print(phase,label,q.returncode,round(z['elapsed'],1),flush=True)
  assert q.returncode==0 and src_hash==z['source_after'] and all(x['sha256']==x['after_sha256'] for x in inputs_after+external_after),n
 for x in p['external']:assert h(x['object'])==x['sha256'],x['module']
 for n,v in nodes.items():assert h(v['source'])==v['source_sha256'],n
print('Both phases completed',flush=True)
