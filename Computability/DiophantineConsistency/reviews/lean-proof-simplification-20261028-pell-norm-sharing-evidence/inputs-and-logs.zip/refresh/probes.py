from pathlib import Path
import os,json,hashlib,time,subprocess
R=Path('/tmp/pell-construction-refresh');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();lp=next(x['lean_path'].split(':',1)[1] for x in json.loads((R/'resumed-records.json').read_text()) if x['phase']=='final');rec=[]
probes={'names':'/tmp/pell-norm-sharing/names.lean','interface':'/tmp/pell-norm-sharing/interface.lean','equations':'/tmp/pell-norm-sharing/equations.lean','construction':'/tmp/construction-share/coherent-axioms.lean'}
for phase in ('baseline','final'):
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+lp
 for name,src0 in probes.items():
  src=Path(src0); log=R/(phase+'-probe-'+name+'.log');tm=R/(phase+'-probe-'+name+'.time'); cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false',str(src)];before=h(src);t=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  rec.append({'phase':phase,'tag':name,'command':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':before,'source_after':h(src),'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip()});(R/'probe-records.json').write_text(json.dumps(rec,indent=2)+'\n');print(phase,name,p.returncode,flush=True);assert p.returncode==0 and h(src)==before
for n in ('interface','equations','construction'):
 assert (R/('baseline-probe-'+n+'.log')).read_bytes()==(R/('final-probe-'+n+'.log')).read_bytes(),n
b=set((R/'baseline-probe-names.log').read_text().splitlines());f=set((R/'final-probe-names.log').read_text().splitlines());print('Name additions',sorted(f-b),'deletions',sorted(b-f));assert len(f-b)==1 and 'norm_tsub_to_add' in next(iter(f-b)) and not b-f
