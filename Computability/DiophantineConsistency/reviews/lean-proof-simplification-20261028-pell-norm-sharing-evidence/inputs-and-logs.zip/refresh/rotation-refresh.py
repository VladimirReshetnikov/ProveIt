from pathlib import Path
import json,hashlib,os,subprocess,time
R=Path('/tmp/pell-construction-refresh');W=Path.cwd();p=json.loads((R/'updated-plan.json').read_text());nodes=p['nodes'];ov=R/'rotation-common';h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();lp=next(r['lean_path'].split(':',1)[1] for r in json.loads(Path('/tmp/construction-share/pinned-replay-records.json').read_text()) if r['phase']=='final');env=os.environ.copy();env['LEAN_PATH']=str(ov)+':'+lp;records=[]
for n in p['rotation_affected'][:-1]:
 v=nodes[n];src=Path(v['source']);assert h(src)==v['source_sha256'];ins=[]
 for dep in v['imports']:
  if dep in nodes:
   d=ov/(dep.replace('.','/')+'.olean');assert d.is_file(),(n,dep);ins.append({'module':dep,'path':str(d),'resolved_path':str(d.resolve()),'sha256':h(d)})
 ext={x['module']:x for x in p['external']};xs=[{'module':d,'path':ext[d]['object'],'sha256':h(ext[d]['object'])} for d in v['imports'] if d in ext]
 out=ov/(n.replace('.','/')+'.olean');out.unlink(missing_ok=True);name=n.split('.')[-1];log=R/('rotation-'+name+'.log');tm=R/('rotation-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(W/'Computability/DiophantineConsistency/Lean'),str(src),'-o',str(out)];t=time.monotonic()
 with log.open('wb') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 ia=[dict(x,after_sha256=h(x['path'])) for x in ins];ea=[dict(x,after_sha256=h(x['path'])) for x in xs]
 z={'module':n,'status':q.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-t,'source':str(src),'source_sha256':v['source_sha256'],'source_after':h(src),'object':str(out),'object_sha256':h(out) if out.is_file() else None,'log':str(log),'log_sha256':h(log),'time':str(tm),'time_sha256':h(tm),'timing':tm.read_text().strip(),'local_inputs':ia,'direct_external_inputs':ea};records.append(z);(R/'rotation-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,q.returncode,round(z['elapsed'],1),flush=True)
 assert q.returncode==0 and z['source_after']==v['source_sha256'] and all(x['sha256']==x['after_sha256'] for x in ia+ea),n
for n,v in nodes.items():assert h(v['source'])==v['source_sha256'],n
for x in p['external']:assert h(x['object'])==x['sha256'],x['module']
print('Rotation shared descendants rebuilt',flush=True)
