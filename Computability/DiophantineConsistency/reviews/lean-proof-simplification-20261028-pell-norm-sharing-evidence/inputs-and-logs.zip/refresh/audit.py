from pathlib import Path
import json,hashlib
R=Path('/tmp/pell-construction-refresh');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();p=json.loads((R/'updated-plan.json').read_text());nodes=p['nodes'];issues=[];checks=[]
for fname in ('rotation-records.json','resumed-records.json','probe-records-v2.json'):
 data=json.loads((R/fname).read_text());
 for r in data:
  key=r.get('module',r.get('tag'));cmd=r['command']
  for n in ('source','log','time'):
   if h(r[n])!=r[n+'_sha256']:issues.append((fname,key,n))
  if r['status']!=0 or h(r['source'])!=r['source_after'] or Path(r['time']).read_text().strip()!=r['timing']:issues.append((fname,key,'status or timing'))
  if 'object' in r and h(r['object'])!=r['object_sha256']:issues.append((fname,key,'object'))
  if 'object' in r and (cmd[-2:]!=['-o',r['object']] or not r['lean_path'].split(':')[0] in str(Path(r['object']).parent)):issues.append((fname,key,'path'))
  for x in r.get('local_inputs',[])+r.get('direct_external_inputs',[]):
   if x['sha256']!=x['after_sha256'] or h(x['path'])!=x['sha256']:issues.append((fname,key,'input',x['module']))
 checks.append((fname,len(data)))
for n,v in nodes.items():
 if h(v['source'])!=v['source_sha256']:issues.append((n,'current source drift'))
for x in p['external']:
 if h(x['object'])!=x['sha256']:issues.append((x['module'],'external drift'))
changed=set(p['order']);diff=[];pins=[]
for n,v in nodes.items():
 bs=R/'baseline'/(n.replace('.','/')+'.olean');fs=R/'final'/(n.replace('.','/')+'.olean');bh=h(bs);fh=h(fs)
 if bh!=fh:diff.append(n)
 if n not in changed and bh!=fh:issues.append((n,'unexpected phase difference'))
 pins.append({'module':n,'source':v['source'],'source_sha256':v['source_sha256'],'baseline_object':str(bs),'baseline_sha256':bh,'final_object':str(fs),'final_sha256':fh})
for n in ('interface','equations','construction','current'):
 if (R/('baseline-probe-v2-'+n+'.log')).read_bytes()!=(R/('final-probe-v2-'+n+'.log')).read_bytes():issues.append((n,'probe output diff'))
base=set((R/'baseline-probe-v2-names.log').read_text().splitlines());final=set((R/'final-probe-v2-names.log').read_text().splitlines())
if len(final-base)!=1 or 'norm_tsub_to_add' not in next(iter(final-base)) or base-final:issues.append('namespace difference')
for ph in ('baseline','final'):
 for n in ('ArithmeticConstructionAssembly','ArithmeticConstructionBound','ArithmeticCurrentConstruction2011'):
  if (R/(ph+'-'+n+'.log')).read_bytes():issues.append((ph,n,'nonempty log'))
summary={'checked_records':checks,'local_source_objects_per_phase':len(pins),'external_objects':len(p['external']),'phase_different_objects':sorted(diff),'phase_different_count':len(diff),'namespace_additions':sorted(final-base),'namespace_deletions':sorted(base-final),'issues':issues,'limitations':['Transitive external dependencies and unaffected local objects remain precompiled.','The original baseline run stopped after all 20 modules passed because the MF header changed during the run; its original Bound log/timing paths were overwritten by the resumed run. Other original logs/timings and all record hashes remain retained.','Shared rotation prerequisite builds have no paired preparation baseline.']}
(R/'local-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(R/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));assert not issues
