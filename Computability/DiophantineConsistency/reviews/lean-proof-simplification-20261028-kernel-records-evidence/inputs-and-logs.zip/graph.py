from pathlib import Path
import hashlib,json,re,sys
root=Path.cwd(); srcroot=root/'Computability/DiophantineConsistency/Lean'; objs=root/'.lake/build/lib/lean'
seeds=['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66','SplitNinePolynomial59','GapNinePolynomial66']
todo=['DiophantineConsistency.'+s for s in seeds];seen={}
while todo:
 m=todo.pop()
 if m in seen: continue
 p=srcroot/Path(m.replace('.','/')+'.lean')
 if not p.exists():continue
 data=p.read_bytes(); imports=[]
 for line in data.decode().splitlines():
  match=re.match(r'^import\s+(.+)$',line)
  if match:imports.extend(match.group(1).split())
 q=objs/Path(m.replace('.','/')+'.olean')
 seen[m]={'source':str(p.relative_to(root)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'source_mtime_ns':p.stat().st_mtime_ns,'object_exists':q.exists(),'object_mtime_ns':q.stat().st_mtime_ns if q.exists() else None,'imports':imports}
 todo.extend(imports)
out={'seeds':seeds,'local_modules':dict(sorted(seen.items())),'scope':'Modules whose source resolves under Computability/DiophantineConsistency/Lean only; external project, Mathlib and Lean modules are precompiled boundaries.'}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')
print('local modules',len(seen),'newer sources',sum(v['object_exists'] and v['source_mtime_ns']>v['object_mtime_ns'] for v in seen.values()),'missing objects',sum(not v['object_exists'] for v in seen.values()))
