from pathlib import Path
import json,hashlib
b=Path('/tmp/record-bounds-validation'); cur=json.loads((b/'final-graph.json').read_text())['local_modules']
prior={x['name']:x for x in json.loads(Path('/tmp/nine-coefficient-consolidation/graph-after-edit.json').read_text())}
borrow=json.loads(Path('/tmp/nine-coefficient-consolidation/refreshed/borrowed.json').read_text())
checks={x['tag']:x for x in borrow}
conv_graph=json.loads(Path('/tmp/diophantine-convolution-factorization/final-graph.json').read_text())['files']
conv_status={x['label']:x for x in json.loads(Path('/tmp/diophantine-convolution-factorization/final/statuses.json').read_text())}
conv_names={'SelectiveCoefficientBounds','NativeQuadraticPositions','PolynomialRangeBounds','SplitCoefficientBounds','SplitCarry','SplitWordBounds','SplitSourceBounds'}
for x in json.loads(Path('/tmp/nine-coefficient-consolidation/refreshed/statuses.json').read_text()):
 if x.get('object_sha256'):checks[x['name']]=x
seed={'DiophantineConsistency.RatioReparameterization'}
while True:
 updated=seed|{n for n,r in cur.items() if set(r['imports'])&seed}
 if updated==seed:break
 seed=updated
seed|={'DiophantineConsistency.'+n for n in ['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66','SplitNinePolynomial59','GapNinePolynomial66']}
changed={'DiophantineConsistency.'+n for n in ['SplitKernelData59','GapKernelData66','SplitNinePolynomial59','GapNinePolynomial66']}
assert len(seed)==21,(len(seed),seed)
prev=Path('/tmp/nine-coefficient-consolidation/refreshed/overlay/DiophantineConsistency')
out=b/'fresh'/'overlay'/'DiophantineConsistency';out.mkdir(parents=True,exist_ok=True)
receipt=[]
for n,v in sorted(cur.items()):
 assert n in prior,n
 old=prior[n];assert old['imports']==v['imports'],n
 if n not in changed:assert old['source_sha256']==v['sha256'],n
 if n in seed:continue
 name=n.rsplit('.',1)[-1];source=Path(v['source']);obj=prev/(name+'.olean')
 assert source.exists() and obj.exists(),n
 source_hash=hashlib.sha256(source.read_bytes()).hexdigest();object_hash=hashlib.sha256(obj.read_bytes()).hexdigest()
 assert source_hash==v['sha256'],n
 if name in checks:
  rec=checks[name]; assert rec.get('status',rec.get('exit'))==0,n
  assert rec['source_sha256']==source_hash,n
  assert rec['object_sha256']==object_hash,n
  evidence='prior refreshed build/borrow record'
 else:
  assert old['object_sha256']==object_hash,(n,old['object_sha256'],object_hash)
  evidence='prior graph object pin'
 if name in conv_names:
  assert conv_status[name]['status']==0,n
  assert conv_graph[str(source)]==source_hash,n
  assert obj.resolve()==(Path('/tmp/diophantine-convolution-factorization/final/overlay/DiophantineConsistency')/(name+'.olean')).resolve(),n
  evidence+='; prior convolution final build passed and final source graph matches'
 target=out/(name+'.olean')
 if target.exists() or target.is_symlink():target.unlink()
 target.symlink_to(obj.resolve())
 receipt.append({'module':n,'source_sha256':source_hash,'object_sha256':object_hash,'object_path':str(obj.resolve()),'authentication':evidence})
remaining=set(seed);order=[]
while remaining:
 ready=sorted(n for n in remaining if not (set(cur[n]['imports'])&remaining))
 assert ready,remaining
 order.extend(ready);remaining-=set(ready)
(b/'fresh').mkdir(exist_ok=True)
(b/'fresh'/'setup.json').write_text(json.dumps({'borrowed':receipt,'build_order':order,'source_graph':str(b/'final-graph.json'),'prior_graph':'/tmp/nine-coefficient-consolidation/graph-after-edit.json','prior_borrowed':'/tmp/nine-coefficient-consolidation/refreshed/borrowed.json','prior_statuses':'/tmp/nine-coefficient-consolidation/refreshed/statuses.json','limitations':'Prior graph object hashes authenticate identity only; the separately cited convolution statuses and source graph establish those seven module builds, but their earlier prerequisite chain and external Mathlib/project dependencies retain the prior precompiled boundary.'},indent=2)+'\n')
print('authenticated borrowed:',len(receipt))
print('rebuild order:',*[n.rsplit('.',1)[-1] for n in order])
