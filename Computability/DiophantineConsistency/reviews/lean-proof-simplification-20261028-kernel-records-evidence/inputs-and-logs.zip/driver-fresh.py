import json, os, pathlib, subprocess, sys, time, hashlib
root=pathlib.Path.cwd()
phase=sys.argv[1]; tags=sys.argv[2:]
base=pathlib.Path('/tmp/record-bounds-validation')/phase
ov=base/'overlay'
env=os.environ.copy(); env['LEAN_PATH']=str(ov)+':'+env.get('LEAN_PATH','')
leanroot=pathlib.Path('Computability/DiophantineConsistency/Lean')
mods=['SplitKernelData59','GapKernelData66','SplitKernels59','GapKernels66','SplitNinePolynomial59','GapNinePolynomial66']
def digest(path):
 p=pathlib.Path(path)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for tag in tags:
 if tag=='axioms': src=pathlib.Path('/tmp/record-bounds-validation/axioms.lean'); out=None
 elif tag.startswith('check-'): src=leanroot/'checks'/(tag[6:]+'.lean'); out=None
 else:
  assert (leanroot/'DiophantineConsistency'/(tag+'.lean')).exists()
  src=leanroot/'DiophantineConsistency'/(tag+'.lean'); out=ov/'DiophantineConsistency'/(tag+'.olean')
  if out.is_symlink(): out.unlink()
 log=base/(tag+'.log');timing=base/(tag+'.time')
 args=['lean','-M6000','-j1','-DElab.async=false','-R',str(leanroot),str(src)]
 if out is not None: args+=['-o',str(out)]
 cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(timing)]+args
 start=time.monotonic()
 with log.open('wb') as f:
  try: result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=360).returncode
  except subprocess.TimeoutExpired: result=124
 data={'tag':tag,'command':cmd,'lean_path':env['LEAN_PATH'],'status':result,'elapsed':time.monotonic()-start,'source':digest(src),'log':digest(log),'timing':digest(timing) if timing.exists() else None}
 if out is not None and out.exists():data['object']=digest(out)
 (base/(tag+'.json')).write_text(json.dumps(data,indent=2)+'\n')
 print(tag,result,round(data['elapsed'],2),flush=True)
 if result!=0: sys.exit(1)
