import DiophantineConsistency.GapKernelData66
namespace RecordBoundsProbe
open DiophantineConsistency.GapKernelData66
set_option maxRecDepth 20000
set_option maxHeartbeats 3000000
private theorem box_facts (ports : Fin 4 → ℤ) (B K : ℤ)
    (hB : 2 ≤ B) (hK : 16*B ≤ K)
    (hb : 0 ≤ ports 0 ∧ ports 0 < B)
    (hk : 0 ≤ ports 1 ∧ ports 1 < K)
    (hm : 0 ≤ ports 2 ∧ ports 2 < B)
    (hf : 0 ≤ ports 3 ∧ ports 3 < 2*B) :
    ports 0 ^ 2 ≤ B ^ 2 ∧ ports 3 * ports 0 ≤ 2*B^2 ∧
      ports 0 * (ports 1+1) < B*K ∧ 16*B^2 ≤ B*K := by
  have hsq : ports 0 ^ 2 ≤ B ^ 2 :=
    (sq_le_sq₀ hb.1 (by omega)).mpr hb.2.le
  have hp : ports 3 * ports 0 ≤ 2*B^2 := by
    calc
      _ ≤ (2*B)*B := mul_le_mul hf.2.le hb.2.le hb.1 (by omega)
      _ = _ := by ring
  have hl : ports 0 * (ports 1+1) < B*K := by
    calc
      _ ≤ ports 0*K := mul_le_mul_of_nonneg_left (by omega) hb.1
      _ < B*K := mul_lt_mul_of_pos_right hb.2 (by omega)
  refine ⟨hsq,hp,hl,?_⟩
  nlinarith [mul_nonneg (by omega : 0 ≤ B) (sub_nonneg.mpr hK)]


theorem records0_lt (ports : Fin 4 → ℤ) (B K : ℤ)
    (hB : 2 ≤ B) (hK : 16*B ≤ K)
    (hb : 0 ≤ ports 0 ∧ ports 0 < B)
    (hk : 0 ≤ ports 1 ∧ ports 1 < K)
    (hm : 0 ≤ ports 2 ∧ ports 2 < B)
    (hf : 0 ≤ ports 3 ∧ ports 3 < 2*B) :
    ∀ i, |coefficients0 ports i| < 2*B*K := by
  obtain ⟨hsq,hp,hl,hBK⟩ := box_facts ports B K hB hK hb hk hm hf
  have hb0 := hb.1
  have hb1 := hb.2
  have hk0 := hk.1
  have hk1 := hk.2
  have hm0 := hm.1
  have hm1 := hm.2
  have hf0 := hf.1
  have hf1 := hf.2
  intro i
  fin_cases i <;> dsimp [coefficients0] <;> rw [abs_lt] <;> constructor <;>
    nlinarith only [hB,hK,hb0,hb1,hk0,hk1,hm0,hm1,hf0,hf1,hsq,hp,hl,hBK,sq_nonneg B]

theorem records1_lt (ports : Fin 4 → ℤ) (B K : ℤ)
    (hB : 2 ≤ B) (hK : 16*B ≤ K)
    (hb : 0 ≤ ports 0 ∧ ports 0 < B)
    (hk : 0 ≤ ports 1 ∧ ports 1 < K)
    (hm : 0 ≤ ports 2 ∧ ports 2 < B)
    (hf : 0 ≤ ports 3 ∧ ports 3 < 2*B) :
    ∀ i, |coefficients1 ports i| < 2*B*K := by
  obtain ⟨hsq,hp,hl,hBK⟩ := box_facts ports B K hB hK hb hk hm hf
  have hb0 := hb.1
  have hb1 := hb.2
  have hk0 := hk.1
  have hk1 := hk.2
  have hm0 := hm.1
  have hm1 := hm.2
  have hf0 := hf.1
  have hf1 := hf.2
  intro i
  fin_cases i <;> dsimp [coefficients1] <;> rw [abs_lt] <;> constructor <;>
    nlinarith only [hB,hK,hb0,hb1,hk0,hk1,hm0,hm1,hf0,hf1,hsq,hp,hl,hBK,sq_nonneg B]

theorem records2_lt (ports : Fin 4 → ℤ) (B K : ℤ)
    (hB : 2 ≤ B) (hK : 16*B ≤ K)
    (hb : 0 ≤ ports 0 ∧ ports 0 < B)
    (hk : 0 ≤ ports 1 ∧ ports 1 < K)
    (hm : 0 ≤ ports 2 ∧ ports 2 < B)
    (hf : 0 ≤ ports 3 ∧ ports 3 < 2*B) :
    ∀ i, |coefficients2 ports i| < 2*B*K := by
  obtain ⟨hsq,hp,hl,hBK⟩ := box_facts ports B K hB hK hb hk hm hf
  have hb0 := hb.1
  have hb1 := hb.2
  have hk0 := hk.1
  have hk1 := hk.2
  have hm0 := hm.1
  have hm1 := hm.2
  have hf0 := hf.1
  have hf1 := hf.2
  intro i
  fin_cases i <;> dsimp [coefficients2] <;> rw [abs_lt] <;> constructor <;>
    nlinarith only [hB,hK,hb0,hb1,hk0,hk1,hm0,hm1,hf0,hf1,hsq,hp,hl,hBK,sq_nonneg B]

end RecordBoundsProbe
