from pathlib import Path
import os,json,hashlib,subprocess
r=Path('/dev/shm/window-positive');q=Path('/dev/shm/cell-room-cancel');base=next(x for x in json.load(open('/dev/shm/cell-no-carry/refresh-records.json')) if x['module']=='ArithmeticWindowDigits');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
for module in ['ArithmeticWindowDigits','ArithmeticCyclicWord']:
 for kind in ['names','interfaces','simp','instances']:
  p=r/(module+'-'+kind+'.lean');p.write_text((q/(kind+'.lean')).read_text().replace('ArithmeticCellTransfer',module))
  for phase in ['baseline','final']:
   env=os.environ.copy();env['LEAN_PATH']=str(r/('lane-'+phase))+':'+base['LEAN_PATH'];objects=[r/('lane-'+phase)/'DiophantineConsistency'/('ArithmeticWindowDigits.olean')];objects+=([r/('lane-'+phase)/'DiophantineConsistency'/(module+'.olean')] if module!='ArithmeticWindowDigits' else []);before=list(map(h,objects));log=r/(phase+'-'+module+'-'+kind+'.log');source_before=h(p);cmd=['lean','-M10000','-j1','-DElab.async=false',str(p)]
   with log.open('wb') as f:result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   rows.append({'module':module,'kind':kind,'phase':phase,'source':str(p),'source_before':source_before,'source_after':h(p),'objects':[str(x) for x in objects],'before':before,'after':list(map(h,objects)),'command':cmd,'LEAN_PATH':env['LEAN_PATH'],'status':result.returncode,'log':str(log),'log_sha256':h(log)});(r/'probe-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(module,kind,phase,result.returncode,flush=True)
   if result.returncode:raise SystemExit(result.returncode)
