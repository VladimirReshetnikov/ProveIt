from pathlib import Path
import hashlib,json
r=Path('/dev/shm/window-positive');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();phases={}
for phase in ['baseline','final']:
 rows=json.loads((r/(phase+'-records.json')).read_text());assert len(rows)==4;phases[phase]=rows
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256']
  for i in x['inputs']:assert i['before']==i['after']==h(i['path']) and (not i['source'] or i['source_before']==i['source_after']==h(i['source']))
  print('PASS',phase,x['module'])
ps=json.loads((r/'probe-records.json').read_text());assert len(ps)==16
for p in ps:
 assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['before']==p['after']==list(map(h,p['objects'])) and h(p['log'])==p['log_sha256']
 record=phases[p['phase']];assert p['before'][0]==record[0]['object_sha256']
 if len(p['before'])>1:assert p['before'][1]==next(x['object_sha256'] for x in record if x['module']==p['module'])
for n in ['ArithmeticWindowDigits','ArithmeticCyclicWord']:
 for k in ['names','interfaces','simp','instances']:
  assert (r/('baseline-'+n+'-'+k+'.log')).read_bytes()==(r/('final-'+n+'-'+k+'.log')).read_bytes()
for i in [2,3]:assert phases['baseline'][i]['object_sha256']==phases['final'][i]['object_sha256']
for n,p in [('ArithmeticRepunit','/tmp/binary-half-direct/final-records.json'),('ArithmeticBinaryCarry','/tmp/binary-half-direct/final-records.json'),('ArithmeticStandardCasts','/tmp/binary-half-direct/final-supplement-records.json')]:
 inputs=[i for x in phases['baseline'] for i in x['inputs'] if i['module']=='DiophantineConsistency.'+n];assert inputs
 row=next(x for x in json.loads(Path(p).read_text()) if x.get('module')==n and x.get('status')==0 and x.get('object_sha256')==inputs[0]['before']);assert row['before']==row['after']==inputs[0]['source_before'];print('PASS producer',n)
print('PASS exact target and CyclicWord probes; mask clients byte-identical; wider dependency closure cached')
