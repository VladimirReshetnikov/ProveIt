from pathlib import Path
import os,json,subprocess,hashlib,re,sys,shutil
r=Path('/dev/shm/window-positive');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');phase=sys.argv[1];names=['ArithmeticWindowDigits','ArithmeticCyclicWord','ArithmeticMaskConstants','ArithmeticWindowBits'];d=r/phase/'DiophantineConsistency';d.mkdir(parents=True,exist_ok=True);obj=r/('lane-'+phase)/'DiophantineConsistency';obj.mkdir(parents=True,exist_ok=True)
for p in Path('/dev/shm/cell-no-carry/objects-refreshed/DiophantineConsistency').iterdir():
 if p.name not in {n+'.olean' for n in names}: (obj/p.name).symlink_to(p)
for n in names:
 if phase=='baseline' or n!='ArithmeticWindowDigits': shutil.copyfile(w/(n+'.lean'),d/(n+'.lean'))
base=next(x for x in json.load(open('/dev/shm/cell-no-carry/refresh-records.json')) if x['module']=='ArithmeticWindowDigits');env=os.environ.copy();env['LEAN_PATH']=str(obj.parent)+':'+base['LEAN_PATH'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
for n in names:
 src=d/(n+'.lean');inputs=[]
 for imp in re.findall(r'^import\s+(\S+)',src.read_text(),re.M):
  rel=imp.replace('.','/')+'.olean';path=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());sp=w/(imp.split('.')[-1]+'.lean');inputs.append({'module':imp,'path':str(path),'resolved':str(path.resolve()),'before':h(path),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 log=r/(phase+'-'+n+'.log');tm=r/(phase+'-'+n+'.time');out=obj/(n+'.olean');cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/phase),str(src),'-o',str(out)];sb=h(src)
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for i in inputs:
  i['after']=h(i['path']);i['source_after']=h(i['source']) if i['source'] else None
 rows.append({'module':n,'phase':phase,'source':str(src),'before':sb,'after':h(src),'inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None});(r/(phase+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,p.returncode,tm.read_text().strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
