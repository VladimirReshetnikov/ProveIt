import Lean.Elab.Command
import DiophantineConsistency.ArithmeticCyclicWord
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticCyclicWord).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticCyclicWord" then
   logInfo m!"DECL {n}"
