from pathlib import Path
import hashlib,json,re
r=Path('/dev/shm/window-positive');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec={}
for phase in ('baseline','final'):
 rows=json.loads((r/(phase+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticWindowDigits','ArithmeticCyclicWord','ArithmeticMaskConstants','ArithmeticWindowBits'];rec[phase]={x['module']:x for x in rows}
 for x in rows:
  assert x['phase']==phase and x['status']==0 and h(x['source'])==x['before']==x['after'] and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticWindowDigits':assert x['before']==h(w/(x['module']+'.lean'))
  for i in x['inputs']:
   p=next(Path(q)/(i['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(i['module'].replace('.','/')+'.olean')).is_file());assert p==Path(i['path']) and str(p.resolve())==i['resolved'] and h(p)==i['before']==i['after']
   if i['source']:assert i['source_before']==i['source_after']==h(i['source'])
   if i['module']=='DiophantineConsistency.ArithmeticWindowDigits':assert i['before']==rec[phase]['ArithmeticWindowDigits']['object_sha256'];assert i['source_before']==rec['baseline']['ArithmeticWindowDigits']['before'] if phase=='final' else i['source_before']==rec[phase]['ArithmeticWindowDigits']['before']
assert h(w/'ArithmeticWindowDigits.lean')==rec['baseline']['ArithmeticWindowDigits']['before']
probes=json.loads((r/'probe-records.json').read_text());assert len(probes)==16
for p in probes:
 ph=p['phase'];assert p['status']==0 and h(p['source'])==p['source_before']==p['source_after'] and h(p['log'])==p['log_sha256'];names=['ArithmeticWindowDigits']+(['ArithmeticCyclicWord'] if p['module']=='ArithmeticCyclicWord' else []);objects=[]
 for mod in names:
  obj=next(Path(q)/'DiophantineConsistency'/(mod+'.olean') for q in p['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(mod+'.olean')).is_file());assert obj==Path(rec[ph][mod]['object']);objects.append(h(obj))
 assert p['before']==p['after']==objects
for m in ('ArithmeticWindowDigits','ArithmeticCyclicWord'):
 for k in ('names','interfaces','simp','instances'):
  assert (r/f'baseline-{m}-{k}.log').read_bytes()==(r/f'final-{m}-{k}.log').read_bytes()
for m in ('ArithmeticMaskConstants','ArithmeticWindowBits'):assert rec['baseline'][m]['object_sha256']==rec['final'][m]['object_sha256']
for m in ('ArithmeticWindowDigits','ArithmeticMaskConstants','ArithmeticWindowBits'):
 for ph in ('baseline','final'):assert not Path(rec[ph][m]['log']).read_bytes()
f=lambda ph:re.sub(r'/dev/shm/window-positive/(baseline|final)/DiophantineConsistency/','SOURCE/',Path(rec[ph]['ArithmeticCyclicWord']['log']).read_text());a,b=f('baseline'),f('final');assert a==b and a.count('warning:')==1
for name,path in [('ArithmeticRepunit','/tmp/binary-half-direct/final-records.json'),('ArithmeticBinaryCarry','/tmp/binary-half-direct/final-records.json'),('ArithmeticStandardCasts','/tmp/binary-half-direct/final-supplement-records.json'),('ArithmeticMaskData','/dev/shm/claude-transport-sharing/assembly-common-records.json'),('ArithmeticMaskKernel','/dev/shm/claude-transport-sharing/assembly-common-records.json')]:
 ds=[i for x in rec['baseline'].values() for i in x['inputs'] if i['module'].split('.')[-1]==name];assert len(ds)==1;d=ds[0];xs=[x for x in json.load(open(path)) if x.get('module','').split('.')[-1]==name and x.get('status')==0 and x.get('object_sha256')==d['before']];assert xs;x=xs[-1];before=x.get('source_before',x.get('before',x.get('source_sha256')));after=x.get('source_after',x.get('after',x.get('source_sha256')));assert before==after==d['source_before'];print('PASS source-current producer',name,d['before'])
print('PASS source snapshots, eight builds, exact target/client probe pins, reports, warnings, producer associations; wider dependency closure cached')
