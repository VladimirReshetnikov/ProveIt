from pathlib import Path
import json,hashlib,subprocess
r=Path('/tmp/nonzero-sphere-sharing');repo=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();fresh={};rows={}
for x in json.loads((r/'provider-records.json').read_text()):
 n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source'])==h(repo/(n+'.lean')) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/('provider-'+n+'.time')).read_text()
 for d in x['direct_inputs']:
  rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p)
  if d['module'].endswith('.CurrentPositiveZero2011'):
   q=next(x for x in json.loads(Path('/tmp/current-packing-positive-sharing/records2.json').read_text()) if x['phase']=='final' and x['module']=='CurrentPositiveZero2011');assert q['status']==0 and q['before']==q['after']==h(q['source'])==h(repo/'CurrentPositiveZero2011.lean') and d['before']==q['object_sha256'];print('adopted current PositiveZero source/object matched')
 fresh[n]=x;print('provider',n,'passed',x['time'].strip())
for ph,filename in [('baseline','pre-docfix-records.json'),('final','final-docfix-records.json')]:
 xs=[x for x in json.loads((r/filename).read_text()) if x['phase']==ph];assert len(xs)==2
 for x in xs:
  n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
  if n=='CarrierNonzeroSpheres':
   ref='6f53b13909^' if ph=='baseline' else '6f53b13909'
   committed=subprocess.check_output(['git','show',f'{ref}:{repo}/{n}.lean']);assert x['before']==hashlib.sha256(committed).hexdigest();print('tested',ph,'matches',ref)
  else:assert x['before']==h(repo/(n+'.lean'))
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);m=d['module'].split('.')[-1];y=fresh[m] if m in fresh else rows[(ph,m)];assert d['resolved']==y['object'] and d['before']==y['object_sha256']
  rows[(ph,n)]=x;print('build',ph,n,x['time'].strip())
for x in json.loads((r/'repeat-records.json').read_text()):
 ph=x['phase'];n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source'])==rows[(ph,n)]['before'] and x['object_sha256']==h(x['object'])==rows[(ph,n)]['object_sha256'] and x['log_sha256']==h(x['log']) and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
 for d in x['direct_inputs']:assert d['before']==d['after']==h(d['path'])==fresh[d['module'].split('.')[-1]]['object_sha256']
 print('repeat',ph,x['time'].strip())
assert rows['baseline','CarrierNonzeroSpheresChecks']['object_sha256']==rows['final','CarrierNonzeroSpheresChecks']['object_sha256'];print('checks client object identical')
for x in json.loads((r/'coherent-probe-records.json').read_text()):
 ph=x['phase'];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['log_sha256']==h(x['log']) and x['objects_before']==x['objects_after']==[rows[(ph,'CarrierNonzeroSpheres')]['object_sha256']];print('probe',ph,x['probe'])
for n in ('names','coherent-interfaces','simp','instances','private'):
 a=(r/f'probe-baseline-{n}.log').read_bytes();b=(r/f'probe-final-{n}.log').read_bytes();assert a==b;print(n,'identical',len(a.splitlines()))
s=(r/'probe-baseline-names.log').read_text();assert s.count('DECL ')==46
s=(r/'probe-baseline-coherent-interfaces.log').read_text();assert s.count('depends on axioms:')+s.count('does not depend on any axioms')==40
s=(r/'probe-baseline-private.log').read_text();assert s.count('PRIVATE ')==6;print('46 declarations, 40 public/generated and six private reports match')
for x in json.loads((r/'pre-docfix-records.json').read_text()):
 if x['phase']=='final':
  n=x['module'];assert x['status']==0 and x['log_sha256']==h(r/('pre-docfix-final-'+n+'.log')) and x['time']==(r/('pre-docfix-final-'+n+'.time')).read_text();print('superseded pre-docfix log/time retained',n)
old=next(x for x in json.loads((r/'pre-docfix-records.json').read_text()) if x['phase']=='final' and x['module']=='CarrierNonzeroSpheres');assert h(r/'pre-docfix-reconstructed.lean')==old['before'] and old['object_sha256']!=h(old['object']);print('pre-docfix source reconstructed by hash; target object overwritten')
base=(r/'baseline/DiophantineConsistency/CarrierNonzeroSpheres.lean').read_text();final=(r/'final/DiophantineConsistency/CarrierNonzeroSpheres.lean').read_text();doc='/-- External exact-current-port equivalences, not internal HA/ZFC derivations. -/';assert base.count(doc)==final.count(doc)==1 and doc not in (r/'pre-docfix-reconstructed.lean').read_text();print('baseline documentation restored in final')
assert h(repo/'CarrierNonzeroSpheres.lean')==rows['final','CarrierNonzeroSpheres']['before'];print('post-commit workspace matches tested final')
man=json.loads((r/'prior-reused-provider-manifest.json').read_text());q=next(x for x in man['reused_objects'] if x['source'].endswith('/SignedPellResidue.lean'));lp=rows['final','CarrierNonzeroSpheres']['LEAN_PATH'];rel='DiophantineConsistency/SignedPellResidue.olean';o=next(Path(p)/rel for p in lp.split(':') if (Path(p)/rel).is_file());assert h(o)==q['sha256'];old=man['protected'][q['source']];assert old==hashlib.sha256(subprocess.check_output(['git','show','92fe8ac532:'+q['source']])).hexdigest() and old!=h(q['source']);print('cached SignedPellResidue',q['sha256'],'earlier inventory source',old,'current',h(q['source']))
