from pathlib import Path
import hashlib,json
R=Path('/tmp/nonzero-sphere-sharing');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result={}
for label,prefix,kinds in [('target','probe',['names','coherent-interfaces','simp','instances','private'])]:
 for k in kinds:
  a=R/(prefix+'-baseline-'+k+'.log');b=R/(prefix+'-final-'+k+'.log');aa=a.read_bytes();bb=b.read_bytes();result[label+'/'+k]={'baseline':str(a),'baseline_sha256':sha(a),'final':str(b),'final_sha256':sha(b),'byte_equal':aa==bb,'lines':len(aa.splitlines())}
  if aa!=bb:raise SystemExit('mismatch '+label+'/'+k)
(R/'probe-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',len(result),'paired logs byte identical')
