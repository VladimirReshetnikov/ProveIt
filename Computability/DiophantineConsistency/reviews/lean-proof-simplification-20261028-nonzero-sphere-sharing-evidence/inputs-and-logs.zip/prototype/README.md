# Positive-zero endpoint simplification

This isolated candidate simplifies the proofs of `current_positive_zero71_iff`
and `current_positive_zero72_iff` in `CarrierNonzeroSpheres.lean`. After the
unchanged proof that beta is positive, each proof unfolds the two positive-zero
predicates and polynomial wrappers, rewrites their evaluation lemmas, and
lifts the existing pointwise equivalence with `exists_congr` and
`and_congr_right`. It retains the identical witness, its positivity assumption,
and beta positivity in both directions. No definitions, statements, imports or
other proof bodies change. The external-derivation docstring is retained.

Baseline source SHA-256 is
`f2fb2bfc613e152e9b62d690d1564b41735f34dd2f7ec71c1a5980212b4ed51a`;
final source is
`75785154203f0b52eed16240d5198641b61f15abf7c3a0f906cb3f1f47e38d00`.
`pre-docfix-records.json` holds the successful baseline target and check-client
builds; `final-docfix-records.json` holds the successful final builds. An initial
candidate accidentally omitted a docstring, and its distinct preliminary logs
and records are retained under `pre-docfix-*`; its original object was overwritten.
`pre-docfix-reconstructed.lean` recreates its source by removing the restored
docstring and matches the historical recorded source hash. It is not the final
snapshot.
The tracked direct-import search in `tracked-direct-clients.log` covers Lean
files under the DiophantineConsistency module directory and found the existing
`CarrierNonzeroSpheresChecks` client, which compiled in both phases. The paired
check object hash is identical: `e95d4438ee616d6274eeb133bcff2e8237c405c8fa2e887f94787eb90f09f6bd`.

`provider-records.json` pins successful current-source rebuilds of both direct
providers `NearSquareNormZero` and `CarrierScaledAuxiliary118`. The latter
uses the previously source-matched current `CurrentPositiveZero2011` object
`f522e6d68e6c794e7ef33cb7ab5241f2f0061719ee72cbfbf1c9e464e76f5533`;
`records2.json` records its build, `refresh3-records.json` and
`refresh-records.json` the refreshed provider chain. The much larger closure
remains cached: ThirteenCarrierSoundness consumed SignedPellResidue object
`45937af80eafe9cb6fd29e046d3f7f87b35d309da8f84bfdd9c99ae1347ab93a`,
which the copied prior manifest records alongside old source
`46afed5402b7bf1a63d567e32906e28f4c06a26b1aab6c8788ef46a405a69fb4`;
workspace source was `ecd4dfbb29cc66499f65941f497640d48788284e8b52324d2ef8dba4fae772be`.
This does not establish a clean current-source closure.

The baseline/final target user CPU sample was 8.32 / 8.57 seconds, and the
sequential paired repeat was 8.46 / 8.36 seconds. These small shared-load
samples do not establish a general performance effect.
`coherent-probe-records.json` pins the target objects for paired probes; all
46 declarations (40 public, six private), existing public types/axioms,
private types/axioms, 55,579 global simp entries and 23,485 instance entries
match. The two value definition equations printed in the names probe match.
`compare-probes.py` and `probe-comparison.json` verify five paired output logs
are byte-identical. These probes do not cover every possible environment
extension or every downstream client.
