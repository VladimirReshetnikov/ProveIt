import DiophantineConsistency.CarrierNonzeroSpheres
#print equations DiophantineConsistency.CarrierNonzeroSpheres.value71
#print equations DiophantineConsistency.CarrierNonzeroSpheres.value72
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.CarrierNonzeroSpheres).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.CarrierNonzeroSpheres" then
   logInfo m!"DECL {n}"
