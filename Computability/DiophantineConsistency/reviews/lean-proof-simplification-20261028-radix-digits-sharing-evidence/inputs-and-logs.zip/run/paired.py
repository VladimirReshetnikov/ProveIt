from pathlib import Path
import os,subprocess,time,json,hashlib
p=Path('/tmp/radix-digits-sharing');root=Path('Computability/DiophantineConsistency/Lean');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ('baseline','final'):
 overlay=p/(phase+'-lib');env=os.environ.copy();env['LEAN_PATH']=str(overlay)+':'+base
 for name in ('MFNativeRadixDigits','NativeRadixDigits','NativeVariableMask'):
  src=(p/phase/'DiophantineConsistency'/(name+'.lean')) if name in ('MFNativeRadixDigits','NativeRadixDigits') else root/'DiophantineConsistency'/(name+'.lean');out=overlay/'DiophantineConsistency'/(name+'.olean');out.unlink(missing_ok=True);log=p/(phase+'-'+name+'.log');tm=p/(phase+'-'+name+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M10000','-j1','-DElab.async=false','-R',str(p/phase if src.is_relative_to(p/phase) else root),str(src),'-o',str(out)];before=h(src);t=time.monotonic()
  with log.open('wb') as o:r=subprocess.run(cmd,env=env,stdout=o,stderr=subprocess.STDOUT)
  records.append({'phase':phase,'name':name,'command':cmd,'lean_path':env['LEAN_PATH'],'status':r.returncode,'source_sha256':before,'source_after':h(src),'object_sha256':h(out) if out.exists() else None,'log_sha256':h(log),'time_sha256':h(tm),'elapsed':round(time.monotonic()-t,2)});(p/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,name,r.returncode,flush=True)
  if r.returncode or before!=h(src):raise SystemExit(1)
