import DiophantineConsistency.NativeRadixDigits
import DiophantineConsistency.MFNativeRadixDigits
open DiophantineConsistency
example {n : ℕ} [NeZero n] : NativeCyclicConvolution.word (n := n) = MF.NativeCyclicConvolution.word (n := n) := by rfl
example (r L N : ℕ) (hL : 0 < L) (a : Fin L → ℕ) :
    (∑ i : Fin (N * L), a ⟨i.val % L, Nat.mod_lt _ hL⟩ * r ^ i.val) =
      (∑ j : Fin L, a j * r ^ j.val) * (∑ k : Fin N, (r ^ L) ^ k.val) :=
  NativeRadixDigits.periodic_sum r L N hL a
