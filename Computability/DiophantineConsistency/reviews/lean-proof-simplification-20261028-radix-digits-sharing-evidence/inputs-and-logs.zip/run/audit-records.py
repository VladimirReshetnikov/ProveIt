from pathlib import Path
import json,hashlib
p=Path('/tmp/radix-digits-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();issues=[]
for fn,count in [('records.json',6),('name-records.json',2),('interface-records.json',2),('equation-axiom-records.json',2)]:
 rs=json.loads((p/fn).read_text());assert len(rs)==count
 for r in rs:
  cmd=r['command'];phase=r['phase'];src=[Path(x) for x in cmd if x.endswith('.lean')];assert len(src)==1; tag=r.get('name') or {'name-records.json':'names','interface-records.json':'interface','equation-axiom-records.json':'equation-axioms'}[fn]
  if r['status'] or h(src[0])!=r['source_sha256'] or r['source_sha256']!=r['source_after'] or r['lean_path'].split(':')[0]!=str(p/(phase+'-lib')):issues.append([fn,phase,tag,'source/status/path'])
  if h(p/(phase+'-'+tag+'.log'))!=r['log_sha256'] or h(cmd[4])!=r['time_sha256']:issues.append([fn,phase,tag,'log/time'])
  if r.get('object_sha256') and (cmd[-2]!='-o' or h(cmd[-1])!=r['object_sha256']):issues.append([fn,phase,tag,'object'])
for n in ('NativeRadixDigits','MFNativeRadixDigits'):
 src=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency')/(n+'.lean');old=p/'baseline/DiophantineConsistency'/(n+'.lean')
 if h(src)!=h(old):issues.append(['baseline/worktree drift',n])
for n in ('MFNativeRadixDigits','NativeRadixDigits','NativeVariableMask','interface','equation-axioms'):
 if (p/('baseline-'+n+'.log')).read_bytes()!=(p/('final-'+n+'.log')).read_bytes():issues.append(['output mismatch',n])
for n,v in json.loads((p/'graph.json').read_text())['nodes'].items():
 if h(v['source'])!=v['source_sha256']:issues.append(['graph source drift',n])
print('12 build/probe records checked, issues',issues);(p/'audit-records.json').write_text(json.dumps({'issues':issues,'records_checked':12},indent=2)+'\n');assert not issues
