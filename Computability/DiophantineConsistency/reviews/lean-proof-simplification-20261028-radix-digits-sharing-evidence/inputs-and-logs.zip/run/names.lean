import DiophantineConsistency.NativeRadixDigits
open Lean Elab Command
run_cmd do
  for (n, _) in (← getEnv).constants.toList do
    if (`DiophantineConsistency.NativeRadixDigits).isPrefixOf n then
      logInfo m!"{n}"
