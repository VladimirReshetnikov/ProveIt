import hashlib,json
from pathlib import Path
p=Path('/tmp/radix-digits-sharing');h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for fn in ('records.json','name-records.json','interface-records.json','equation-axiom-records.json'):
 for r in json.loads((p/fn).read_text()):
  cmd=r['command'];src=[a for a in cmd if a.endswith('.lean')];assert len(src)==1 and r['status']==0
  assert h(src[0])==r['source_sha256']==r['source_after'] and h(cmd[4])==r['time_sha256']
  assert r['lean_path'].split(':')[0]==str(p/(r['phase']+'-lib'))
  tag=r.get('name',{'name-records.json':'names','interface-records.json':'interface','equation-axiom-records.json':'equation-axioms'}.get(fn)); assert h(p/(r['phase']+'-'+tag+'.log'))==r['log_sha256']
  if 'object_sha256' in r: assert cmd[-2]=='-o' and h(cmd[-1])==r['object_sha256']
 print(fn,'all records checked')
for n in ('interface','equation-axioms'):
 assert (p/('baseline-'+n+'.log')).read_bytes()==(p/('final-'+n+'.log')).read_bytes()
print('retained interface and forced equation logs identical')
g=json.loads((p/'graph.json').read_text());print('graph field names:',list(g))
for n,v in g['nodes'].items():
 assert h(v['source'])==v['source_sha256'],n
 for dep in v['imports']:
  assert dep in g['nodes'] or dep in g['external'],(n,dep)
 for ph,x in v.get('objects',{}).items():assert h(x['path'])==x['sha256'],(n,ph)
print(len(g['nodes']),'node source and selected object hashes verified')
