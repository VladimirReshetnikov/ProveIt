from pathlib import Path
import subprocess,time,json,hashlib,shutil,sys
p=Path('/dev/shm/controller-order-20261028');pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';mode=sys.argv[1]
items=[('target',pre+'CurrentControllerData2011.lean',True),('axioms',str(p/'axioms.lean'),False)]
if mode=='final':items += [('focus',pre+'CurrentControllerData2011Checks.lean',False),('positions',pre+'CurrentControllerPositions2011.lean',False),('auxiliary',pre+'CurrentAuxiliaryOrder2011.lean',False)]
if mode=='rankstride': items=[('rankstride',pre+'CurrentRankStride2011.lean',False)]
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free<60*1024*1024:print('disk cutoff before',name,'free',free,flush=True);raise SystemExit(75)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency/CurrentControllerData2011.olean')]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/dev/shm/controller-order-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-start;log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 rec={'name':name,'argv':cmd,'status':r.returncode,'seconds':elapsed,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj:
  f=p/'overlay/DiophantineConsistency/CurrentControllerData2011.olean'
  if f.exists():rec['object']=str(f);rec['object_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,round(elapsed,2),'seconds',flush=True)
 if r.returncode:raise SystemExit(r.returncode)
