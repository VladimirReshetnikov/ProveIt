from pathlib import Path
import json,hashlib,shutil,subprocess,time
p=Path('/dev/shm/controller-order-20261028');g=json.loads((p/'graph-before.json').read_text())['project_import_edges'];pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/';t=pre+'CurrentRankStride2011.lean';seed=pre+'WangMachineTraceBounds.lean';anc=set();todo=[t]
while todo:
 x=todo.pop()
 if x in anc:continue
 anc.add(x);todo+=g.get(x,[])
aff={seed}
while True:
 new={x for x in anc if any(y in aff for y in g.get(x,[]))}
 if new<=aff:break
 aff|=new
remaining=(aff&anc)-{t};order=[]
while remaining:
 ready=sorted(x for x in remaining if not set(g.get(x,[]))&remaining);assert ready,remaining
 order+=ready;remaining-=set(ready)
assert len(order)==10
for source in order:
 dest=p/'overlay/DiophantineConsistency'/(Path(source).stem+'.olean')
 if dest.is_symlink():dest.unlink()
records=[]
for source in order:
 free=shutil.disk_usage('.').free
 if free<60*1024*1024:print('disk cutoff before',source,'free',free,flush=True);raise SystemExit(75)
 name=Path(source).stem;obj=p/'overlay/DiophantineConsistency'/(name+'.olean');args=['lake','env','bash','-c','export LEAN_PATH="/dev/shm/controller-order-20261028/overlay:$LEAN_PATH"; exec "$@"','bash','lean','-M6000','-j1','-DElab.async=false',source,'-o',str(obj)]
 begin=time.monotonic();r=subprocess.run(args,capture_output=True);elapsed=time.monotonic()-begin;log=p/('trace-refresh-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 rec={'name':name,'argv':args,'exit_status':r.returncode,'seconds':elapsed,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj.exists():rec['object']=str(obj);rec['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest();rec['object_bytes']=obj.stat().st_size
 records.append(rec);(p/'trace-refresh-results.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,round(elapsed,2),'seconds',flush=True)
 if r.returncode:raise SystemExit(r.returncode)
