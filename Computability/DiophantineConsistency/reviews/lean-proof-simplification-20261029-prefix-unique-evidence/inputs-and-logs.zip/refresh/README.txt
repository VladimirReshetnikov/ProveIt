Prefix uniqueness using Finset.sum_le_one_iff

In ArithmeticCellDecoding.prefix_unique, apply Finset.sum_le_one_iff directly
to the two positive entries of the bounded prefix sum. This removes the separate
pair-subset and contradiction argument. The diff is 2 insertions, 8 deletions,
and preserves imports, statements, hypotheses and definitions. The original
proof was introduced in Claude-coauthored f79467f5448.

Paired ArithmeticCellDecoding and its sole tracked direct Lean client
ArithmeticWholeField builds pass. Target objects and client objects differ
between phases. Object-pinned probes match all 75 client declarations' printed
types and axioms and all sampled global default simp and instance registrations.
For the target, 69 declarations are common; 68 have equal printed types and
axioms, and generated public prefix_unique._proof_2 has changed type. Two
generated public prefix_unique._simp_1 and _simp_2 names disappear; one new
generated public prefix_unique._proof_1 appears. A tracked Lean/Python search
found no references to the removed names or changed proof name. All sampled
target registrations also match. These printed reports do not establish proof
body equality or equality of all persistent extensions. Each probe pins both
phase-specific target and client objects, even when it imports only the target.

The direct ArithmeticCellTransfer input matches the source-current producer
in /dev/shm/cell-sum-unique/final-records.json; the fresh phase target provides
the client input. Extra first-provider pins record CellLabels, CellLocal,
MFDoubledClause2011, StandardCasts, ModularCancellation and CyclicWord before
and after each build. Other project, Foundation and Mathlib dependencies remain
cached; no full current-source closure or downstream builds are claimed. Paired
build records, logs, timings, probe sources and records are retained here.
Both target builds issue the same existing unused-section-variable warning;
both client builds issue the same 11 pre-existing warnings after phase-path
normalization.
The baseline/final target user CPU samples are 6.59/6.76 seconds and client
samples 21.38/21.51 seconds, individual shared-load observations only.

audit.py/log verify the above source/object pins, reports and provider receipt;
these files and the compiled objects under /dev/shm are temporary.

Refreshed provider replay: both phases above were repeated after commit
cf31781e72 using its source-matched CellLocal object from
/dev/shm/cell-selector-unit/final-records.json (adc4572fe7fd4b190055e55bde4cae61f603cc22c266eb9e034c030fcbd9b63e)
and source-matched CellLabels object from the same lane (ff9065671a7e0232527038fa7725a11d02707655f462332f5d7b121476f6651b).
The original and refreshed phase target/client objects differ, but all 16
refreshed printed probes match their original-lane counterparts byte for byte.
The rebuilt current CellTransfer provider against these objects reproduces the
exact 4c1bcca7312649de7e185075c1aff72a79ac5212a056ba1e2fe4a3bf13fe5857
object used by both phases, recorded in provider-transfer-record.json. The
provider's direct sources and inputs and both additional current-source objects
are pinned; broader transitive dependencies remain cached. Baseline and final
target builds each have the same one warning and client builds the same 11,
after phase path and line number normalization. Build and probe records and
actual refreshed objects are in this directory.
