from pathlib import Path
import hashlib,json,re,os,subprocess
r=Path('/dev/shm/prefix-unique-refresh');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=json.load(open('/dev/shm/wholefield-orbit-refresh/provider-record.json'));env=os.environ.copy();env['LEAN_PATH']=str(r/'provider-transfer')+':'+base['LEAN_PATH'];src=w/'ArithmeticCellTransfer.lean';ins=[]
for n in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
 p=next(Path(q)/(n.replace('.','/')+'.olean') for q in env['LEAN_PATH'].split(':') if (Path(q)/(n.replace('.','/')+'.olean')).is_file());sp=w/(n.split('.')[-1]+'.lean');ins.append({'module':n,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp),'source_before':h(sp)})
extra=[]
for n in ['ArithmeticCellLabels','ArithmeticCellLocal']:
 p=next(Path(q)/'DiophantineConsistency'/(n+'.olean') for q in env['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(n+'.olean')).is_file());extra.append({'module':n,'path':str(p),'resolved':str(p.resolve()),'before':h(p)})
out=r/'provider-transfer/DiophantineConsistency/ArithmeticCellTransfer.olean';assert out.is_symlink();out.unlink();tm=r/'provider-transfer.time';log=r/'provider-transfer.log';before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(w.parent),str(src),'-o',str(out)]
with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
for d in ins:d['after']=h(d['path']);d['source_after']=h(d['source'])
for d in extra:d['after']=h(d['path'])
row={'module':'ArithmeticCellTransfer','status':p.returncode,'source':str(src),'before':before,'after':h(src),'direct_inputs':ins,'extra_inputs':extra,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};(r/'provider-transfer-record.json').write_text(json.dumps(row,indent=2)+'\n');print(p.returncode,row['time'].strip(),row['object_sha256'],flush=True)
