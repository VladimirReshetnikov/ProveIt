from pathlib import Path
import os,json,hashlib,subprocess,sys,re
r=Path('/dev/shm/prefix-unique-refresh');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');phase=sys.argv[1];lib=r/('obj-'+phase);lib.mkdir(exist_ok=True);libd=lib/'DiophantineConsistency'
if not libd.exists():subprocess.run(['cp','-as','/dev/shm/prefix-unique-refresh/provider/DiophantineConsistency',str(libd)],check=True)
names=['ArithmeticCellDecoding','ArithmeticWholeField']; h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in names:
 p=libd/(n+'.olean')
 if p.is_symlink():p.unlink()
base=json.load(open('/dev/shm/wholefield-orbit-refresh/provider-record.json'));env=os.environ.copy();env['LEAN_PATH']=str(lib)+':'+base['LEAN_PATH'];rows=[]
for n in names:
 src=r/phase/'DiophantineConsistency'/(n+'.lean');inputs=[]
 for name in re.findall(r'^import\s+([^\s]+)',src.read_text(),re.M):
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());leaf=name.split('.')[-1];sp=r/phase/'DiophantineConsistency'/(leaf+'.lean') if leaf in names else w/(leaf+'.lean');inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p),'source':str(sp) if sp.exists() else None,'source_before':h(sp) if sp.exists() else None})
 extras=[]
 for en in ('ArithmeticCellLabels','ArithmeticCellTransfer','ArithmeticCellLocal','MFDoubledClause2011','ArithmeticStandardCasts','ArithmeticModularCancellation','ArithmeticCyclicWord'):
  ep=next(Path(q)/'DiophantineConsistency'/(en+'.olean') for q in env['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(en+'.olean')).is_file());extras.append({'module':en,'path':str(ep),'resolved':str(ep.resolve()),'before':h(ep)})
 out=libd/(n+'.olean');tm=r/(phase+'-'+n+'.time');log=r/(phase+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M10000','-j1','-DElab.async=false','-R',str(r/phase),str(src),'-o',str(out)]
 with log.open('wb') as f:pr=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path']);d['source_after']=h(d['source']) if d['source'] else None
 for ep in extras:ep['after']=h(ep['path'])
 rec={'extra_inputs':extras,'phase':phase,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':pr.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(out),'object_sha256':h(out) if out.exists() else None};rows.append(rec);(r/(phase+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(phase,n,pr.returncode,rec['time'].strip(),flush=True)
 if pr.returncode:sys.exit(pr.returncode)
