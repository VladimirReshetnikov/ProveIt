from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/dev/shm/prefix-unique-refresh');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec={}
for ph in ('baseline','final'):
 rows=json.loads((r/(ph+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticCellDecoding','ArithmeticWholeField'];rec[ph]={}
 for x in rows:
  rec[ph][x['module']]=x;assert x['status']==0 and x['before']==x['after']==h(x['source']) and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'] and x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p) and d['source_before']==d['source_after']==h(d['source'])
   if d['module'].endswith('.ArithmeticCellDecoding'):assert d['before']==rec[ph]['ArithmeticCellDecoding']['object_sha256']
  for d in x['extra_inputs']:assert d['before']==d['after']==h(d['path']) and str(Path(d['path']).resolve())==d['resolved']
  if x['module']=='ArithmeticWholeField':assert h(x['source'])==h(w/'ArithmeticWholeField.lean')
  print('PASS build',ph,x['module'])
 probes=json.loads((r/(ph+'-probes.json')).read_text());assert len(probes)==8
 for p in probes:
  assert p['status']==0 and p['source_before']==p['source_after']==h(p['source']) and p['objects_before']==p['objects_after']==[h(q) for q in p['objects']]==[rec[ph][n]['object_sha256'] for n in ('ArithmeticCellDecoding','ArithmeticWholeField')] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
for ns in ('ArithmeticCellDecoding','ArithmeticWholeField'):
 for n in ('simp','instances'):
  assert (r/('baseline-'+ns+'-'+n+'.log')).read_bytes()==(r/('final-'+ns+'-'+n+'.log')).read_bytes()
 def interfaces(ph):
  s=(r/(ph+'-'+ns+'-interfaces.log')).read_text();return {m.group(1):m.group(0) for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',s)}
 a,b=interfaces('baseline'),interfaces('final');removed=sorted(a.keys()-b.keys());added=sorted(b.keys()-a.keys());changed=sorted(k for k in a.keys()&b.keys() if a[k]!=b[k]);print(ns,'common',len(a.keys()&b.keys()),'removed',removed,'added',added,'changed',changed)
 if ns=='ArithmeticWholeField':assert len(a)==len(b)==75 and not removed and not added and not changed
 else:
  pre='DiophantineConsistency.ArithmeticCellDecoding.prefix_unique.';assert len(a.keys()&b.keys())==69 and removed==[pre+'_simp_1',pre+'_simp_2'] and added==[pre+'_proof_1'] and changed==[pre+'_proof_2']
for ph in ('baseline','final'):
 d=rec[ph]['ArithmeticCellDecoding']['direct_inputs'][0];x=next(x for x in json.loads(Path('/dev/shm/cell-sum-unique/final-records.json').read_text()) if x['module']=='ArithmeticCellTransfer');assert x['status']==0 and d['before']==x['object_sha256'] and d['source_before']==x['before']==x['after'];print('PASS source-current direct provider',ph,d['before'])
 assert rec[ph]['ArithmeticWholeField']['before']==h(w/'ArithmeticWholeField.lean')
for name in ('_simp_1','_simp_2','_proof_2'):
 p=subprocess.run(['git','grep','-n','-F','prefix_unique.'+name,'--','*.lean','*.py'],capture_output=True,text=True);assert p.returncode==1,(name,p.stdout,p.stderr)
x=json.loads((r/'provider-transfer-record.json').read_text());assert x['status']==0 and x['before']==x['after']==h(x['source'])==h(w/'ArithmeticCellTransfer.lean') and x['object_sha256']==h(x['object'])==rec['baseline']['ArithmeticCellDecoding']['direct_inputs'][0]['before']==rec['final']['ArithmeticCellDecoding']['direct_inputs'][0]['before'] and x['log_sha256']==h(x['log'])
for d in x['direct_inputs']:assert d['before']==d['after']==h(d['path']) and d['source_before']==d['source_after']==h(d['source'])
for d in x['extra_inputs']:assert d['before']==d['after']==h(d['path'])
for n in ('ArithmeticCellLocal','ArithmeticCellLabels'):
 d=next(d for d in x['extra_inputs'] if d['module']==n);provider=next(y for y in json.loads(Path('/dev/shm/cell-selector-unit/final-records.json').read_text()) if y['module']==n);assert provider['status']==0 and provider['object_sha256']==d['before'] and provider['before']==provider['after']==h(w/(n+'.lean'))
for ph in ('baseline','final'):
 for t in ('ArithmeticCellDecoding','ArithmeticWholeField'):
  for n in ('names','interfaces','simp','instances'):
   assert (r/(ph+'-'+t+'-'+n+'.log')).read_bytes()==(Path('/dev/shm/prefix-unique')/(ph+'-'+t+'-'+n+'.log')).read_bytes()
print('PASS rebuilt CellTransfer against current CellLabels and CellLocal exactly reproduces replay object')
print('PASS refreshed and original printed probes match; wider closure cached')
