from pathlib import Path
import hashlib,json,re,subprocess
r=Path('/dev/shm/prefix-unique');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec={}
for ph in ('baseline','final'):
 rows=json.loads((r/(ph+'-records.json')).read_text());assert [x['module'] for x in rows]==['ArithmeticCellDecoding','ArithmeticWholeField'];rec[ph]={x['module']:x for x in rows}
 for x in rows:
  assert x['phase']==ph and x['status']==0 and h(x['source'])==x['before']==x['after'] and h(x['object'])==x['object_sha256'] and h(x['log'])==x['log_sha256'];assert x['time']==Path(x['command'][x['command'].index('-o')+1]).read_text()
  for d in x['direct_inputs']:
   p=next(Path(q)/(d['module'].replace('.','/')+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/(d['module'].replace('.','/')+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and h(p)==d['before']==d['after'] and h(d['source'])==d['source_before']==d['source_after']
  for d in x['extra_inputs']:
   p=next(Path(q)/'DiophantineConsistency'/(d['module']+'.olean') for q in x['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(d['module']+'.olean')).is_file());assert p==Path(d['path']) and str(p.resolve())==d['resolved'] and h(p)==d['before']==d['after']
  if x['module']=='ArithmeticWholeField':assert h(w/'ArithmeticWholeField.lean')==x['before'] and x['direct_inputs'][0]['before']==rec[ph]['ArithmeticCellDecoding']['object_sha256']
 for p in json.loads((r/(ph+'-probes.json')).read_text()):
  assert p['status']==0 and h(p['source'])==p['source_before']==p['source_after'] and h(p['log'])==p['log_sha256'] and h(p['time'])==p['time_sha256']
  objects=[]
  for mod in ('ArithmeticCellDecoding','ArithmeticWholeField'):
   obj=next(Path(q)/'DiophantineConsistency'/(mod+'.olean') for q in p['LEAN_PATH'].split(':') if (Path(q)/'DiophantineConsistency'/(mod+'.olean')).is_file());assert obj==Path(rec[ph][mod]['object']);objects.append(h(obj))
  assert p['objects_before']==p['objects_after']==objects
 assert len(json.loads((r/(ph+'-probes.json')).read_text()))==8
assert h(w/'ArithmeticCellDecoding.lean')==rec['baseline']['ArithmeticCellDecoding']['before'];assert rec['baseline']['ArithmeticWholeField']['before']==rec['final']['ArithmeticWholeField']['before']
for n in ('ArithmeticCellDecoding','ArithmeticWholeField'):
 norm=lambda phase:re.sub(r'/dev/shm/prefix-unique/(baseline|final)/DiophantineConsistency/'+n+r'.lean:\d+:\d+:','SOURCE:',Path(rec[phase][n]['log']).read_text())
 a,b=norm('baseline'),norm('final');assert a==b and a.count('warning:')==({'ArithmeticCellDecoding':1,'ArithmeticWholeField':11}[n])
 for kind in ('simp','instances'):
  assert (r/f'baseline-{n}-{kind}.log').read_bytes()==(r/f'final-{n}-{kind}.log').read_bytes()
 def get(ph):
  s=(r/f'{ph}-{n}-interfaces.log').read_text();return {m.group(1):m.group(0) for m in re.finditer(r'(?ms)^DECL (\S+) TYPE .*?(?=^DECL |\Z)',s)}
 a,b=get('baseline'),get('final');print(n,'common',len(a.keys()&b.keys()),'removed',sorted(a.keys()-b.keys()),'added',sorted(b.keys()-a.keys()),'changed',sorted(k for k in a.keys()&b.keys() if a[k]!=b[k]))
 if n=='ArithmeticCellDecoding':
  pre='DiophantineConsistency.ArithmeticCellDecoding.prefix_unique.';assert len(a.keys()&b.keys())==69 and sorted(a.keys()-b.keys())==[pre+'_simp_1',pre+'_simp_2'] and sorted(b.keys()-a.keys())==[pre+'_proof_1'] and [k for k in a.keys()&b.keys() if a[k]!=b[k]]==[pre+'_proof_2']
 else: assert len(a)==len(b)==75 and a==b
for ph in ('baseline','final'):
 d=rec[ph]['ArithmeticCellDecoding']['direct_inputs'][0];x=next(x for x in json.loads(Path('/dev/shm/cell-sum-unique/final-records.json').read_text()) if x['module']=='ArithmeticCellTransfer');assert d['before']==x['object_sha256'] and d['source_before']==x['before']==x['after'] and x['status']==0
for s in ('_simp_1','_simp_2','_proof_2'):
 p=subprocess.run(['git','grep','-n','-F','prefix_unique.'+s,'--','*.lean','*.py'],text=True,capture_output=True);assert p.returncode==1
print('PASS builds, first-provider paths, object-pinned probes, declaration reports, warnings, registrations and transfer receipt')
