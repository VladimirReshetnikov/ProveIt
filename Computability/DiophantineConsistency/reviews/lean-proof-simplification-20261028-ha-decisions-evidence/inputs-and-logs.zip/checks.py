import hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path('/tmp/ha-decision-reuse-20261028');phase=sys.argv[1];env=os.environ.copy();env['LEAN_PATH']=str(r/phase)+':'+env.get('LEAN_PATH','');base='Computability/DiophantineConsistency/Lean';src=Path(base)/'DiophantineConsistency'
jobs=[('bounded-focus',str(src/'HABoundedQuantifiersChecks.lean')),('delta-focus',str(src/'FoundationHADeltaZeroChecks.lean')),('delta-gg',str(src/'FoundationHADeltaZeroGG.lean')),('bounded-double-negation',str(src/'HABoundedDoubleNegation.lean')),('axioms',str(r/'axioms.lean'))];recs=[]
for tag,path in jobs:
 cmd=['lean','-M6000','-j1','-DElab.async=false','-R',base,path];t=time.monotonic();p=subprocess.run(cmd,capture_output=True,env=env);sec=time.monotonic()-t;log=r/(phase+'-'+tag+'.log');log.write_bytes(p.stdout+p.stderr)
 rec={'tag':tag,'cmd':cmd,'status':p.returncode,'seconds':sec,'source_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};recs.append(rec);(r/(phase+'-checks.json')).write_text(json.dumps(recs,indent=2)+'\n');print(phase,tag,p.returncode,round(sec,2),flush=True)
 if p.returncode:sys.exit(p.returncode)
