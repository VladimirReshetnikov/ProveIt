import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/ha-decision-reuse-20261028');phase=sys.argv[1];task=sys.argv[2]; env=os.environ.copy();env['LEAN_PATH']=str(root/phase)+':'+env.get('LEAN_PATH','')
lean='Computability/DiophantineConsistency/Lean';src=Path(lean)/'DiophantineConsistency';order=json.loads((root/'order.json').read_text());targets=['HABoundedQuantifiers','FoundationHADeltaZero']
mods=order if task=='all' else targets
records=[]
for n in mods:
 p=src/(n+'.lean');cmd=['lean','-M6000','-j1','-DElab.async=false','-R',lean,str(p),'-o',str(root/phase/'DiophantineConsistency'/(n+'.olean'))]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,env=env);elapsed=time.monotonic()-start
 log=root/(phase+'-'+n+'.log');log.write_bytes(r.stdout+r.stderr)
 rec={'module':n,'cmd':cmd,'status':r.returncode,'seconds':elapsed,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if r.returncode==0:
  out=root/phase/'DiophantineConsistency'/(n+'.olean');rec['object_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();rec['object_bytes']=out.stat().st_size
 records.append(rec);(root/(phase+'-'+task+'-records.json')).write_text(json.dumps(records,indent=2)+'\n');print(phase,n,r.returncode,round(elapsed,2),flush=True)
 if r.returncode:sys.exit(r.returncode)
