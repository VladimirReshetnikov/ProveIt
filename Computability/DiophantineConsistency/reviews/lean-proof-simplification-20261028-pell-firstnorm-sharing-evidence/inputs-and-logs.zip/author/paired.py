from pathlib import Path
import os,subprocess,hashlib,json,time
R=Path('/tmp/pell-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();root=Path('Computability/DiophantineConsistency/Lean');records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']=str(R/phase)+':'+base
 for n in ['ArithmeticPellFirstNorm','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex','ArithmeticPellFirstIndexChecks','ArithmeticPellPowerRecovery','ArithmeticPellPowerRecoveryChecks']:
  target=R/phase/'DiophantineConsistency'/(n+'.olean');target.unlink(missing_ok=True)
  source=(R/phase/'DiophantineConsistency'/(n+'.lean')) if n=='ArithmeticPellFirstNorm' else root/'DiophantineConsistency'/(n+'.lean');srcroot=(R/phase) if n=='ArithmeticPellFirstNorm' else root
  log=R/(phase+'-'+n+'.log');tm=R/(phase+'-'+n+'.time');cmd=['/usr/bin/time','-f','elapsed=%e maxrss=%M','-o',str(tm),'lean','-M6000','-j1','-DElab.async=false','-R',str(srcroot),str(source),'-o',str(target)];pre=h(source);start=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  d={'phase':phase,'module':n,'status':p.returncode,'command':cmd,'lean_path':env['LEAN_PATH'],'elapsed':time.monotonic()-start,'source':str(source.resolve()),'source_sha256':pre,'source_after':h(source),'object':str(target),'object_sha256':h(target) if target.exists() else None,'log':str(log),'log_sha256':h(log),'time':tm.read_text()};records.append(d);(R/'paired-records.json').write_text(json.dumps(records,indent=2)+'\n');print(phase,n,p.returncode,round(d['elapsed'],1),flush=True)
  if p.returncode or pre!=d['source_after']:raise SystemExit(1)
