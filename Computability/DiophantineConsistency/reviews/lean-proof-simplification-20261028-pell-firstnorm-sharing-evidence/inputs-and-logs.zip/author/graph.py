from pathlib import Path
import hashlib,json,re
R=Path('/tmp/pell-share');roots=[Path('Computability/DiophantineConsistency/Lean'),Path('Computability/BusyBeaver/Lean')];seen={};order=[];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pins=json.load(open('/tmp/outer-seed-bound-sharing/assembly-final-pins.json'));pins={x['module']:x for x in pins if x['phase']=='baseline'};lib=R/'baseline'
def visit(n):
 if n in seen:return
 p=next((r/(n.replace('.','/')+'.lean') for r in roots if (r/(n.replace('.','/')+'.lean')).is_file()),None)
 if not p:return
 im=[]
 for line in p.read_text().splitlines():
  m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
  if m:im.extend(k for k in m.group(1).split() if k.startswith(('DiophantineConsistency.','BusyBeaver.')))
 obj=lib/(n.replace('.','/')+'.olean');node={'source':str(p.resolve()),'source_sha256':h(p),'imports':im,'object':str(obj.resolve()) if obj.exists() else None,'object_sha256':h(obj) if obj.exists() else None,'assembly_pin':pins.get(n)};seen[n]=node
 for k in im:visit(k)
 order.append(n)
for n in ['ArithmeticPellFirstNorm','ArithmeticPellKnownUnit','ArithmeticPellFirstIndex','ArithmeticPellPowerRecovery']:visit('DiophantineConsistency.'+n)
errs=[]
for n,v in seen.items():
 p=v['assembly_pin']
 if not p:errs.append((n,'not in prior assembly pin'))
 elif v['source_sha256']!=p['source_sha256'] or v['object_sha256']!=p['object_sha256']:errs.append((n,'source/object mismatch'))
(R/'graph.json').write_text(json.dumps({'nodes':seen,'order':order,'issues':errs},indent=2)+'\n');print('nodes',len(seen),'issues',len(errs));print('\n'.join(map(str,errs)))
