from pathlib import Path
import json,hashlib,subprocess
R=Path('/tmp/pell-share');P=Path('/tmp/pell-independent-audit');O=Path('/tmp/outer-seed-bound-sharing');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();issues=[];pairs=json.load(open(R/'paired-records.json'));axioms=json.load(open(R/'axiom-records.json'));audit=json.load(open(R/'audit.json'));g=json.load(open(R/'graph.json'));prereqs={x['module']:x for x in json.load(open(O/'prereq2-records.json'))}
for x in pairs:
 for k in ['source','object','log']:
  if not Path(x[k]).is_file() or h(x[k])!=x[k+'_sha256']:issues.append('paired '+x['phase']+' '+x['module']+' '+k)
 if x['status'] or x['source_sha256']!=x['source_after'] or Path(x['command'][4]).read_text()!=x['time']:issues.append('paired status/timing '+x['module'])
for x in axioms:
 if x['status'] or h(x['source'])!=x['source_sha256'] or h(x['log'])!=x['log_sha256'] or Path(x['command'][4]).read_text()!=x['time']:issues.append('axiom record '+x['phase']+' '+x['name'])
for x in audit['phase_pins']:
 for k in ['source','object']:
  if h(x[k])!=x[k+'_sha256']:issues.append('phase pin '+x['phase']+' '+x['module']+' '+k)
 for d in x['direct_project_inputs']:
  if h(d['object'])!=d['sha256']:issues.append('direct input '+d['module'])
 if not x['fresh']:
  q=prereqs.get(x['module'])
  if not q or q['status'] or q['source_sha256']!=x['source_sha256'] or q['object_sha256']!=x['object_sha256']:issues.append('prior input '+x['module'])
for name in ['private-names','private-meta']:
 for x in json.load(open(P/(name+'-records.json'))):
  log=P/(x['phase']+'-'+name+'.log')
  if x['status'] or h(log)!=x['log_sha256']:issues.append(name+' log '+x['phase'])
  if x.get('source_sha256') and h(P/(name+'.lean'))!=x['source_sha256']:issues.append(name+' source '+x['phase'])
for a,b in [('baseline-axioms.log','final-axioms.log')]:
 if (R/a).read_bytes()!=(R/b).read_bytes():issues.append('public reports differ')
if (P/'baseline-private-meta.log').read_bytes()!=(P/'final-private-meta.log').read_bytes():issues.append('private metadata differ')
commit='6d9e6e43a7707063d9c09935462288e7891ebcc5';path='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellFirstNorm.lean';committed=subprocess.check_output(['git','show',commit+':'+path]);final=(R/'final/DiophantineConsistency/ArithmeticPellFirstNorm.lean').read_bytes()
if committed!=final:issues.append('commit differs final snapshot')
for n,v in g['nodes'].items():
 p=R/'baseline/DiophantineConsistency/ArithmeticPellFirstNorm.lean' if n.endswith('.ArithmeticPellFirstNorm') else Path(v['source'])
 if h(p)!=v['source_sha256']:issues.append('graph source '+n)
report={'paired_records':len(pairs),'axiom_records':len(axioms),'phase_pins':len(audit['phase_pins']),'graph_sources':len(g['nodes']),'independent_private_names':17,'issues':issues};(R/'package-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(report);assert not issues
