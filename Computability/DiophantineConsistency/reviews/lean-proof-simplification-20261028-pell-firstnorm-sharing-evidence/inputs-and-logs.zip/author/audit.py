from pathlib import Path
import hashlib,json,re
R=Path('/tmp/pell-share');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();g=json.load(open(R/'graph.json'));paired=json.load(open(R/'paired-records.json'));pr={(x['phase'],x['module']):x for x in paired};issues=[];pins=[]
for x in paired:
 if x['status']!=0 or x['source_sha256']!=x['source_after'] or h(x['source'])!=x['source_sha256'] or h(x['log'])!=x['log_sha256'] or h(x['object'])!=x['object_sha256']:issues.append('paired record '+x['phase']+x['module'])
for phase in ['baseline','final']:
 for n,v in g['nodes'].items():
  short=n.removeprefix('DiophantineConsistency.');isfresh=(phase,short) in pr
  src=Path(pr[(phase,short)]['source']) if isfresh else Path(v['source']);obj=R/phase/(n.replace('.','/')+'.olean');sha=h(src);oh=h(obj)
  if isfresh:
   p=pr[(phase,short)]
   if sha!=p['source_sha256'] or oh!=p['object_sha256']:issues.append('fresh '+phase+' '+n)
  else:
   pin=v['assembly_pin']
   if not pin or sha!=pin['source_sha256'] or oh!=pin['object_sha256']:issues.append('borrowed '+phase+' '+n)
  imports=[]
  for line in src.read_text().splitlines():
   m=re.match(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+?)\s*$',line)
   if m:
    for dep in m.group(1).split():
     if dep.startswith(('DiophantineConsistency.','BusyBeaver.')):
      p=R/phase/(dep.replace('.','/')+'.olean')
      if not p.is_file():issues.append('missing '+phase+' '+n+' -> '+dep)
      else:imports.append({'module':dep,'object':str(p.resolve()),'sha256':h(p)})
  pins.append({'phase':phase,'module':n,'source':str(src.resolve()),'source_sha256':sha,'object':str(obj.resolve()),'object_sha256':oh,'fresh':isfresh,'direct_project_inputs':imports})
for n in ['ArithmeticPellFirstNorm','ArithmeticPellFirstNormChecks','ArithmeticPellFirstIndex','ArithmeticPellFirstIndexChecks','ArithmeticPellPowerRecovery','ArithmeticPellPowerRecoveryChecks']:
 if (R/('baseline-'+n+'.log')).read_bytes()!=(R/('final-'+n+'.log')).read_bytes():issues.append('log differs '+n)
if (R/'baseline-axioms.log').read_bytes()!=(R/'final-axioms.log').read_bytes():issues.append('axiom or type reports differ')
x=json.load(open(R/'names-comparison.json'))
if x['removed'] or x['added']:issues.append('changed declaration names')
if h('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellFirstNorm.lean')!=h(R/'baseline/DiophantineConsistency/ArithmeticPellFirstNorm.lean'):issues.append('worktree target changed')
result={'phase_pins':pins,'paired_records_checked':len(paired),'old_names_checked':len(x['baseline']),'axiom_probe_warning_count_per_phase':(R/'baseline-axioms.log').read_text().count('warning:'),'issues':issues};(R/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print('phase pins',len(pins),'records',len(paired),'names',len(x['baseline']),'warnings per axiom probe',result['axiom_probe_warning_count_per_phase'],'issues',len(issues));print('\n'.join(issues));assert not issues
