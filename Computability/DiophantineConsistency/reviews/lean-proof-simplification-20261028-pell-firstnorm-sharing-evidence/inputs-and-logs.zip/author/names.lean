import DiophantineConsistency.ArithmeticPellPowerRecovery
open Lean Elab Command
#print equations DiophantineConsistency.ArithmeticPellFirstNorm.discriminant
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (`DiophantineConsistency.ArithmeticPellFirstNorm).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellFirstIndex).isPrefixOf n ||
       (`DiophantineConsistency.ArithmeticPellPowerRecovery).isPrefixOf n then
      logInfo m!"DECL {n}"
