import DiophantineConsistency.ArithmeticPellPowerRecovery
open Lean Elab Command
#print equations DiophantineConsistency.ArithmeticPellFirstNorm.discriminant
run_cmd do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    let s := n.toString
    if s.startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNorm." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticPellFirstIndex." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticPellPowerRecovery." then
      logInfo m!"PRIVATE {n}"
