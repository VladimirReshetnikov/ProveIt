from pathlib import Path
import subprocess,os,json,hashlib
R=Path('/tmp/pell-independent-audit');base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']='/tmp/pell-share/'+phase+':'+base;cmd=['lean','-M6000','-j1','-DElab.async=false',str(R/'private-names.lean')];log=R/(phase+'-private-names.log')
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'phase':phase,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 if p.returncode:raise SystemExit(1)
(R/'private-names-records.json').write_text(json.dumps(records,indent=2)+'\n')
for phase in ['baseline','final']:
 log=(R/(phase+'-private-names.log')).read_text();print(phase, len([x for x in log.splitlines() if x.startswith('PRIVATE ')]))
