import DiophantineConsistency.ArithmeticPellPowerRecovery
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option pp.all true
run_cmd do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    let s := n.toString
    if s.startsWith "_private.DiophantineConsistency.ArithmeticPellFirstNorm." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticPellFirstIndex." ||
       s.startsWith "_private.DiophantineConsistency.ArithmeticPellPowerRecovery." then
      let axs ← collectAxioms n
      logInfo m!"PRIVATE {n}\nTYPE {c.type}\nAXIOMS {axs}"
