from pathlib import Path
import subprocess,os,json,hashlib
R=Path('/tmp/pell-independent-audit');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();src=R/'private-meta.lean';base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']='/tmp/pell-share/'+phase+':'+base;cmd=['lean','-M6000','-j1','-DElab.async=false',str(src)];log=R/(phase+'-private-meta.log')
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'phase':phase,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'source_sha256':H(src),'log_sha256':H(log)});(R/'private-meta-records.json').write_text(json.dumps(records,indent=2)+'\n')
 if p.returncode:raise SystemExit(1)
print('logs match',(R/'baseline-private-meta.log').read_bytes()==(R/'final-private-meta.log').read_bytes())
