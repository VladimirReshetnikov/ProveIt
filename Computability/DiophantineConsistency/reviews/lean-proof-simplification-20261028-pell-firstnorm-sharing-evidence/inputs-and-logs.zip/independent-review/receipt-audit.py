from pathlib import Path
import json,hashlib,re
R=Path('/tmp/pell-share');O=Path('/tmp/outer-seed-bound-sharing');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();paired=json.loads((R/'paired-records.json').read_text());audit=json.loads((R/'audit.json').read_text());g=json.loads((R/'graph.json').read_text());prereq={x['module']:x for x in json.loads((O/'prereq2-records.json').read_text())};first={x['module']:x for x in json.loads((O/'prereq-records.json').read_text())};issues=[]
for x in paired:
 for kind in ['source','object','log']:
  if H(x[kind]) != x[kind+'_sha256']:issues.append('paired '+x['phase']+' '+x['module']+' '+kind)
 if x['status']!=0 or x['source_sha256']!=x['source_after']:issues.append('status/source '+x['module'])
 if Path(x['command'][4]).read_text()!=x['time']:issues.append('timing '+x['module'])
for x in audit['phase_pins']:
 for kind in ['source','object']:
  if H(x[kind])!=x[kind+'_sha256']:issues.append('pin '+x['phase']+' '+x['module']+' '+kind)
 for z in x['direct_project_inputs']:
  if H(z['object'])!=z['sha256']:issues.append('edge '+x['phase']+' '+x['module']+' '+z['module'])
 if not x['fresh']:
  n=x['module'];q=prereq.get(n)
  if not q or q['status'] or q['source_sha256']!=x['source_sha256'] or q['object_sha256']!=x['object_sha256']:issues.append('prior receipt '+n)
  elif q['provenance']=='first-pass':
   f=first.get(n)
   if not f or f['status'] or f['source_sha256']!=q['source_sha256'] or f['object_sha256']!=q['object_sha256']:issues.append('first-pass receipt '+n)
for x in json.loads((R/'axiom-records.json').read_text()):
 if x['status'] or H(x['source'])!=x['source_sha256'] or H(x['log'])!=x['log_sha256']:issues.append('axiom record '+x['phase']+' '+x['name'])
 if Path(x['command'][4]).read_text()!=x['time']:issues.append('axiom timing '+x['phase']+' '+x['name'])
a=json.loads((R/'names-comparison.json').read_text());probe=(R/'axioms.lean').read_text();names=a['baseline'];checks=re.findall(r'^#check (\S+)$',probe,re.M);axioms=re.findall(r'^#print axioms (\S+)$',probe,re.M)
if names!=checks or names!=axioms or a['added'] or a['removed']:issues.append('public census coverage')
if (R/'baseline-axioms.log').read_bytes()!=(R/'final-axioms.log').read_bytes():issues.append('public reports differ')
if (Path('/tmp/pell-independent-audit/baseline-private-meta.log').read_bytes()!=Path('/tmp/pell-independent-audit/final-private-meta.log').read_bytes()):issues.append('private reports differ')
target=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticPellFirstNorm.lean')
if H(target)!=H(R/'baseline/DiophantineConsistency/ArithmeticPellFirstNorm.lean'):issues.append('workspace target diverged')
print('paired',len(paired),'local phase pins',len(audit['phase_pins']),'public names',len(names),'private names',17,'graph nodes',len(g['nodes']),'issues',issues)
Path('/tmp/pell-independent-audit/receipt-audit.json').write_text(json.dumps({'paired':len(paired),'local_phase_pins':len(audit['phase_pins']),'public_names':len(names),'private_names':17,'graph_nodes':len(g['nodes']),'issues':issues},indent=2)+'\n')
if issues:raise SystemExit(1)
