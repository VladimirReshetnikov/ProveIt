from pathlib import Path
import subprocess,os,json,hashlib
R=Path('/tmp/pell-independent-audit');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=sorted({x.removeprefix('PRIVATE ') for x in (R/'baseline-private-names.log').read_text().splitlines() if x.startswith('PRIVATE ')});b=sorted({x.removeprefix('PRIVATE ') for x in (R/'final-private-names.log').read_text().splitlines() if x.startswith('PRIVATE ')});assert a==b
names=[x for x in a if x.endswith('.comparisonDef')];assert len(names)==1;src=R/'private-axioms.lean';src.write_text('import DiophantineConsistency.ArithmeticPellPowerRecovery\nset_option pp.all true\n#print equations '+names[0].replace('.0.', '.«0».')+'\n'+''.join('#check '+n.replace('.0.', '.«0».')+'\n#print axioms '+n.replace('.0.', '.«0».')+'\n' for n in a));base=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],text=True).strip();records=[]
for phase in ['baseline','final']:
 env=os.environ.copy();env['LEAN_PATH']='/tmp/pell-share/'+phase+':'+base;cmd=['lean','-M6000','-j1','-DElab.async=false',str(src)];log=R/(phase+'-private-axioms.log')
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'phase':phase,'cmd':cmd,'lean_path':env['LEAN_PATH'],'status':p.returncode,'source_sha256':H(src),'log_sha256':H(log)})
 if p.returncode:raise SystemExit(1)
(R/'private-axioms-records.json').write_text(json.dumps(records,indent=2)+'\n');print('private declarations',len(a),'logs match',(R/'baseline-private-axioms.log').read_bytes()==(R/'final-private-axioms.log').read_bytes(),'warnings', (R/'baseline-private-axioms.log').read_text().count('warning:'))
