from pathlib import Path
import subprocess, time, json, hashlib, sys, shutil
p=Path('/tmp/early-padding-modulus-20261028'); pre='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'; mode=sys.argv[1]; order=json.loads((p/'order.json').read_text()); target=pre+'CurrentEarlyPadding2011.lean'; idx=order.index(target); roots={target,pre+'CurrentEarlyPadding2011Checks.lean',pre+'CurrentOneHot2011.lean'}
if mode=='prep': items=[(Path(s).stem,s,True) for s in order[:idx]]
elif mode=='baseline':items=[('target',target,True),('axioms',str(p/'axioms.lean'),False)]
elif mode=='final':items=[('target',target,True)]+[(Path(s).stem,s,True) for s in order[idx+1:] if s not in roots]+[('focus',pre+'CurrentEarlyPadding2011Checks.lean',False),('client',pre+'CurrentOneHot2011.lean',False),('axioms',str(p/'axioms.lean'),False)]
else:raise ValueError(mode)
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('/').free
 if free<65*1024*1024:
  print('STOP DISK',free,name,flush=True);sys.exit(75)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj:argv+=['-o',str(p/'overlay/DiophantineConsistency'/(Path(source).stem+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/early-padding-modulus-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-t;log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 rec={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  o=Path(argv[-1]);rec['object']=str(o);rec['object_sha256']=hashlib.sha256(o.read_bytes()).hexdigest()
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n');print(mode,len(records),name,r.returncode,'free',free,flush=True)
 if r.returncode:sys.exit(r.returncode)
