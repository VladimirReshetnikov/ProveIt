from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
p=Path('/tmp/polynomial-range-proof-20261028'); pre='Computability/DiophantineConsistency/Lean/'; mode=sys.argv[1]
prep=['MultiQuadraticCoding','SelectiveCertificate52','MultiTargetCarry','NativeQuadraticParent','SelectiveCarry','SelectiveCoefficientBounds','NativeQuadraticPositions']
items=[(n,pre+'DiophantineConsistency/'+n+'.lean',n) for n in prep] if mode=='prep' else [('target',pre+'DiophantineConsistency/PolynomialRangeBounds.lean','PolynomialRangeBounds'),('axioms',str(p/'axioms.lean'),None)]
if mode=='final': items += [(n,pre+'DiophantineConsistency/'+n+'.lean',None) for n in ['SplitWordBounds','NativeBaseBounds52','NativeQuadraticSource52']]+[('focus',pre+'checks/SelectiveCarry.lean',None)]
records=[]
for name,source,obj in items:
 free=shutil.disk_usage('.').free
 if free<65*1024**2: print('disk cutoff before',name,'free',free,flush=True); raise SystemExit(90)
 argv=['lean','-M6000','-j1','-DElab.async=false',source]
 if obj: argv+=['-o',str(p/'overlay/DiophantineConsistency'/(obj+'.olean'))]
 cmd=['lake','env','bash','-c','export LEAN_PATH="/tmp/polynomial-range-proof-20261028/overlay:$LEAN_PATH"; exec "$@"','bash',*argv]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True);elapsed=time.monotonic()-start
 log=p/(mode+'-'+name+'.log');log.write_bytes(r.stdout+r.stderr)
 rec={'name':name,'argv':cmd,'exit_status':r.returncode,'elapsed_seconds':elapsed,'free_before':free,'source':source,'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 if obj and r.returncode==0:
  ob=p/'overlay/DiophantineConsistency'/(obj+'.olean');rec.update({'object':str(ob),'object_sha256':hashlib.sha256(ob.read_bytes()).hexdigest()})
 records.append(rec);(p/(mode+'-results.json')).write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
