from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/gcd-product-positivity');W=Path('/home/codex/.codex/worktrees/62ff/Proofs/Computability/DiophantineConsistency/Lean/DiophantineConsistency')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
b=(R/'baseline/DiophantineConsistency/ArithmeticGcdNormalization.lean').read_text();f=(R/'final/DiophantineConsistency/ArithmeticGcdNormalization.lean').read_text()
old='''  have hg0 : 0<g := by
    by_contra hn
    have hz : g=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le g)
    simp [hz] at hRt
    simp [hRt] at hR
  have ht0 : 0<t := by
    by_contra hn
    have hz : t=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le t)
    simp [hz] at hRt
    simp [hRt] at hR
  have hd0 : 0<d := by
    by_contra hn
    have hz : d=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le d)
    simp [hz] at hDd
    simp [hDd] at hD''';new='''  have hg0 : 0<g := pos_of_mul_pos_left (by rw [←hRt]; exact hR) (by simp)
  have ht0 : 0<t := pos_of_mul_pos_right (by rw [←hRt]; exact hR) (by simp)
  have hd0 : 0<d := pos_of_mul_pos_right (by rw [←hDd]; exact hD) (by simp)'''
old2='''  have hs0 : 0<s := by
    by_contra hn
    have hz : s=0 := le_antisymm (le_of_not_gt hn) (Arithmetic.zero_le s)
    simp [hz] at hgs
    simp [hgs] at hg0''';new2='''  have hs0 : 0<s := pos_of_mul_pos_right (by rw [←hgs]; exact hg0) (by simp)'''
assert b.count(old)==b.count(old2)==1 and b.replace(old,new).replace(old2,new2)==f
rel='Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticGcdNormalization.lean'
def gitfile(rev):return subprocess.check_output(['git','show',f'{rev}:{rel}']).decode()
assert gitfile('c0fb426562^')==b and gitfile('c0fb426562')==f and (W/'ArithmeticGcdNormalization.lean').read_text()==f
print('PASS exact substitutions, commit/parent and workspace match')
clients=subprocess.check_output(['git','grep','-l','-E','^import DiophantineConsistency\\.ArithmeticGcdNormalization$','--','Computability/DiophantineConsistency/Lean/*.lean'],text=True).splitlines();assert sorted(Path(p).stem for p in clients)==['ArithmeticGcdNormalizationChecks','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility'];print('PASS three tracked direct module clients',clients)
paths={'ArithmeticPellKnownUnit':'/tmp/pell-square-direct/final-records.json','ArithmeticPellRecurrence':'/tmp/pell-balance-sharing/final-targets-records.json'};providers={}
for n,p in paths.items():
 x=next(x for x in read(p) if x['module'].split('.')[-1]==n);assert x['status']==0 and x['before']==x['after']==h(W/(n+'.lean')) and x['object_sha256']==h(x['object']);providers[n]=x['object_sha256'];print('PASS prior source/object pair',n,providers[n])
rec={}
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-records.json');rec[phase]={x['module']:x for x in rows};assert set(rec[phase])=={'ArithmeticGcdNormalization','ArithmeticGcdNormalizationChecks','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility'}
 for x in rows:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and Path(x['command'][x['command'].index('-o')+1]).read_text()==x['time']
  if x['module']!='ArithmeticGcdNormalization':assert x['before']==h(W/(x['module']+'.lean'))
  assert re.findall(r'^import\s+([^\s]+)',Path(x['source']).read_text(),re.M)==[d['module'] for d in x['direct_inputs']]
  for d in x['direct_inputs']:
   p=next(Path(z)/('/'.join(d['module'].split('.'))+'.olean') for z in x['LEAN_PATH'].split(':') if (Path(z)/('/'.join(d['module'].split('.'))+'.olean')).is_file());assert p==Path(d['path']) and p.resolve()==Path(d['resolved']) and d['before']==d['after']==h(p)
   if d.get('source_before') is not None:assert d['source_before']==d['source_after']==h(d['source'])
   n=d['module'].split('.')[-1]
   if n=='ArithmeticGcdNormalization':assert d['before']==rec[phase][n]['object_sha256']
   elif n in providers:assert d['before']==providers[n]
   else:assert d['module'] in ['Foundation.FirstOrder.Arithmetic.IOpen.Basic','Mathlib.Tactic.Ring','Mathlib.Algebra.Ring.Divisibility.Basic']
  print('PASS build',phase,x['module'],x['time'].strip(),x['object_sha256'])
for n in ('ArithmeticGcdNormalizationChecks','ArithmeticPellCommonUnit','ArithmeticPellStrongDivisibility'):assert rec['baseline'][n]['object_sha256']==rec['final'][n]['object_sha256']
print('PASS three direct client output objects match')
for phase in ('baseline','final'):
 rows=read(R/f'{phase}-probes.json');assert len(rows)==4
 for x in rows:
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==[rec[phase][Path(p).stem]['object_sha256'] for p in x['objects']] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ('names','interfaces','simp','instances'):assert (R/f'baseline-{n}.log').read_bytes()==(R/f'final-{n}.log').read_bytes()
print('PASS target/client-pinned probes, 29 declaration reports and matching simp/instances')
