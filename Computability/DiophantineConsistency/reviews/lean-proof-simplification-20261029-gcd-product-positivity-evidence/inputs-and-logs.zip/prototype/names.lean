import Lean.Elab.Command
import DiophantineConsistency.ArithmeticGcdNormalizationChecks
import DiophantineConsistency.ArithmeticPellCommonUnit
import DiophantineConsistency.ArithmeticPellStrongDivisibility
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticGcdNormalization).isPrefixOf n || (toString n).startsWith "_private.DiophantineConsistency.ArithmeticGcdNormalization" then
   logInfo m!"DECL {n}"
