from pathlib import Path
import hashlib,json,subprocess
R=Path('/tmp/binary-half-direct');W=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text());rows={}
mods=['ArithmeticBinaryPopulation','ArithmeticBinaryCarry','ArithmeticRepunit','ArithmeticBinaryPopulationChecks','ArithmeticStandardCasts','ArithmeticBinomLegendre','ArithmeticSaturation']
for ph in ('baseline','final'):
 rr=load(R/f'{ph}-records.json')+load(R/f'{ph}-supplement-records.json');assert [x['module'] for x in rr]==mods
 for x in rr:
  assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(R/f"{ph}-{x['module']}.time").read_text()
  if x['module']!='ArithmeticBinaryPopulation':assert x['before']==h(W/f"{x['module']}.lean")
  else:
   rev='55ddd54db0^' if ph=='baseline' else '55ddd54db0'
   blob=subprocess.check_output(['git','show',rev+':Computability/DiophantineConsistency/Lean/DiophantineConsistency/ArithmeticBinaryPopulation.lean'])
   assert hashlib.sha256(blob).hexdigest()==x['before']
   if ph=='final':assert h(W/'ArithmeticBinaryPopulation.lean')==x['before']
  for d in x['direct_inputs']:
   rel=d['module'].replace('.','/')+'.olean';first=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(first)==d['path'] and str(first.resolve())==d['resolved'] and d['before']==d['after']==h(first)
   if d['module'].endswith('.ArithmeticBinaryPopulation'):assert d['before']==rr[0]['object_sha256']
   if x['module']=='ArithmeticSaturation':assert d['before']==rr[1]['object_sha256']
  rows[ph,x['module']]=x
 for r in load(R/f'{ph}-probes.json'):
  assert r['status']==0 and r['source_before']==r['source_after']==h(r['source']) and r['object_before']==r['object_after']==rr[0]['object_sha256'] and r['log_sha256']==h(r['log']) and r['time_sha256']==h(r['time'])
 for r in load(R/f'{ph}-client-probes.json'):
  want=[rr[0]['object_sha256'],rr[1]['object_sha256'],rr[5]['object_sha256']]
  assert r['status']==0 and r['source_before']==r['source_after']==h(r['source']) and r['objects_before']==r['objects_after']==want and r['log_sha256']==h(r['log']) and r['time_sha256']==h(r['time'])
producer=next(x for x in load('/tmp/outer-seed-bound-sharing/prereq2-records.json') if x['module']=='DiophantineConsistency.ArithmeticBinomFactorial')
assert producer['status']==0 and producer['source_sha256']==producer['source_after']==h(W/'ArithmeticBinomFactorial.lean')
for ph in ('baseline','final'):
 dep=next(d for d in rows[ph,'ArithmeticBinomLegendre']['direct_inputs'] if d['module'].endswith('.ArithmeticBinomFactorial'));assert dep['before']==producer['object_sha256']
for mod in ('ArithmeticRepunit','ArithmeticBinaryPopulationChecks','ArithmeticStandardCasts','ArithmeticSaturation'):assert rows['baseline',mod]['object_sha256']==rows['final',mod]['object_sha256']
for mod in ('ArithmeticBinaryCarry','ArithmeticBinomLegendre'):assert rows['baseline',mod]['object_sha256']!=rows['final',mod]['object_sha256']
for n in ('names','interfaces','simp','instances'):
 for prefix in ('','client-'):assert (R/f'baseline-{prefix}{n}.log').read_bytes()==(R/f'final-{prefix}{n}.log').read_bytes()
for ph in ('baseline','final'):
 x=rows[ph,'ArithmeticBinaryPopulation'];q=next(d for d in x['direct_inputs'] if d['module'].endswith('HFS.PRF'));y=rows[ph,'ArithmeticBinaryPopulationChecks'];rel=q['module'].replace('.','/')+'.olean';p2=next(Path(p)/rel for p in y['LEAN_PATH'].split(':') if (Path(p)/rel).is_file());assert h(p2)==q['before']
assert (R/'baseline-ArithmeticBinaryPopulationChecks.log').read_bytes()==(R/'final-ArithmeticBinaryPopulationChecks.log').read_bytes()
attempt=load(R/'attempt1-baseline-supplement-records.json');assert [x['status'] for x in attempt]==[0,0,1]
for x in attempt: assert x['log_sha256']==h(R/f"attempt1-baseline-{x['module']}.log")
assert 'HFS/Vec.olean' in (R/'attempt1-baseline-ArithmeticBinomLegendre.log').read_text()
print('PASS seven-module paired target/client receipts, first input resolution, retained combined Saturation, target and differing-client probes')
