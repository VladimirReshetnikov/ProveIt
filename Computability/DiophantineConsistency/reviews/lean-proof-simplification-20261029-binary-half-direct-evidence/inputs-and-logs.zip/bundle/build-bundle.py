from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('/home/codex/.codex/worktrees/62ff/Proofs');R=Path('/tmp/binary-half-direct')
D=ROOT/'Computability/DiophantineConsistency/reviews/lean-proof-simplification-20261029-binary-half-direct-evidence';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();items={}
def add(n,p):assert n not in items;items[n]=Path(p).read_bytes()
def git(p,rev):return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=ROOT)
rev='55ddd54db04c055edc0a24849f1436899f4b681b';parent='f783b73128515b943cff12d8b798acc6c0972834';mod='Computability/DiophantineConsistency/Lean/DiophantineConsistency/'
items['commit/baseline.lean']=git(mod+'ArithmeticBinaryPopulation.lean',parent);items['commit/final.lean']=git(mod+'ArithmeticBinaryPopulation.lean',rev)
for phase in ('baseline','final'):assert items['commit/'+phase+'.lean']==(R/phase/'DiophantineConsistency/ArithmeticBinaryPopulation.lean').read_bytes()
for n in ['ArithmeticBinaryCarry','ArithmeticRepunit','ArithmeticBinaryPopulationChecks','ArithmeticStandardCasts','ArithmeticBinomLegendre','ArithmeticBinomFactorial','ArithmeticSaturation']:
 items['provider-sources/'+n+'.lean']=git(mod+n+'.lean',rev)
for f in sorted(R.rglob('*')):
 if f.is_file() and f.suffix not in ('.olean','.ilean','.c') and not any('objects-' in x for x in f.relative_to(R).parts):add('prototype/'+f.relative_to(R).as_posix(),f)
for n,p in {
 'prior/binom-factorial-prereq2-records.json':'/tmp/outer-seed-bound-sharing/prereq2-records.json',
 'independent/review.txt':'/tmp/binary-half-peer-review-claude-a.txt',
 'independent/audit.py':'/tmp/binary-half-peer-audit-claude-a.py',
 'independent/audit.log':'/tmp/binary-half-peer-audit-claude-a.log',
 'independent/client-search.log':'/tmp/binary-half-peer-client-search-claude-a.log',
 'bundle/build-bundle.py':'/tmp/build-binary-half-direct-bundle.py'}.items():add(n,p)
zpath=D/'inputs-and-logs.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):
  info=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b)
m={'schema':'lean-proof-simplification-evidence-v1','source_commit':rev,'source_parent':parent,'scope':'Simplify ArithmeticBinaryPopulation.half_lt using imported division bound',
'validation':'Paired target and five tracked direct clients in the module directory build. Paired combined replay builds current ArithmeticSaturation over each phase’s rebuilt BinaryCarry and BinaryPopulation. Target name/type/axiom and registrations agree; combined probes pin target and both differing clients and their name/type/axiom and registrations agree. Four client object pairs including Saturation are byte-identical; BinaryCarry and BinomLegendre differ.',
'limitations':['BinaryCarry and BinomLegendre object hashes differ for an unestablished reason; matching namespace and registration probes do not establish proof-body, serialized-object or all persistent-extension equality.', 'The combined Saturation replay does not rebuild its downstream closure. Wider project, Foundation and Mathlib closure remains cached and not rebuilt from current source.', 'The first supplemental baseline BinomLegendre build failed because an overlay lacked HFS/Vec; failure records/logs are retained. Successful supplemental builds use a fuller cached Foundation. Post-build samples of supplemental HFS.PRF match the target direct input but do not prove supplemental transitive load-time bytes.', 'The provisional standalone probe lacks complete input pin receipts; final paired builds provide validation. Shared-load paired timings are single samples, not a general benchmark.', 'Tracked direct-client search is scoped to the module directory; historical Lean source copies under reviews are outside this scope.', 'Compiled objects are omitted. Receipts contain hashes and first-provider paths; independent byte checks require external objects.'],
'archive':'inputs-and-logs.zip','archive_sha256':sha(zpath.read_bytes()),'members':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(items.items())}}
(D/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n');(D/'independent-review.txt').write_bytes(items['independent/review.txt'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(items)
 for n,b in items.items():assert z.read(n)==b
print('bundle',D,'members',len(items))
for n in ['inputs-and-logs.zip','BUNDLE.json','independent-review.txt']:
 b=(D/n).read_bytes();print(n,sha(b),len(b))
