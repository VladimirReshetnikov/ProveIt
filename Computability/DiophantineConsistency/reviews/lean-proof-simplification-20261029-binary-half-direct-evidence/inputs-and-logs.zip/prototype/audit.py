from pathlib import Path
import json,hashlib
r=Path('/tmp/binary-half-direct');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();get=lambda n:json.loads((r/n).read_text());rows={}
old=next(x for x in json.loads(Path('/tmp/outer-seed-bound-sharing/prereq2-records.json').read_text()) if x['module'].endswith('.ArithmeticBinomFactorial'));assert old['status']==0 and old['source_sha256']==old['source_after']==h(w/'ArithmeticBinomFactorial.lean');print('current BinomFactorial prior producer source/object',old['source_sha256'],old['object_sha256'])
for ph in ('baseline','final'):
 for records in ('records','supplement-records'):
  for x in get(ph+'-'+records+'.json'):
   n=x['module'];assert x['status']==0 and x['before']==x['after']==h(x['source']) and x['object_sha256']==h(x['object']) and x['log_sha256']==h(x['log']) and x['time']==(r/f'{ph}-{n}.time').read_text()
   if n!='ArithmeticBinaryPopulation' or ph=='baseline':assert x['before']==h(w/(n+'.lean'))
   for d in x['direct_inputs']:
    rel=d['module'].replace('.','/')+'.olean';p=next(Path(q)/rel for q in x['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());assert str(p)==d['path'] and str(p.resolve())==d['resolved'] and d['before']==d['after']==h(p);name=d['module'].split('.')[-1]
    if name in ('ArithmeticBinaryPopulation','ArithmeticBinaryCarry'):assert d['before']==rows[ph,name]['object_sha256'] and d['resolved']==rows[ph,name]['object']
    elif name=='ArithmeticBinomFactorial':assert d['before']==old['object_sha256']
    else:assert d['module'] in ('Foundation.FirstOrder.Arithmetic.HFS.PRF','Mathlib.Tactic.Ring')
   rows[ph,n]=x;print('build',ph,n,x['time'].strip())
for d in rows['baseline','ArithmeticBinaryPopulation']['direct_inputs']:
 e=next(v for v in rows['final','ArithmeticBinaryPopulation']['direct_inputs'] if v['module']==d['module']);assert d['before']==e['before'];print('same target direct object both phases',d['module'],d['before'])
for ph in ('baseline','final'):
 for x in get(ph+'-probes.json'):
  assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['object_before']==x['object_after']==h(x['object'])==rows[ph,'ArithmeticBinaryPopulation']['object_sha256'] and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
 for x in get(ph+'-client-probes.json'):
  expected=[rows[ph,n]['object_sha256'] for n in ('ArithmeticBinaryPopulation','ArithmeticBinaryCarry','ArithmeticBinomLegendre')];assert x['status']==0 and x['source_before']==x['source_after']==h(x['source']) and x['objects_before']==x['objects_after']==[h(p) for p in x['objects']]==expected and x['log_sha256']==h(x['log']) and x['time_sha256']==h(x['time'])
for n in ('ArithmeticBinaryCarry','ArithmeticRepunit','ArithmeticBinaryPopulationChecks','ArithmeticStandardCasts','ArithmeticBinomLegendre','ArithmeticSaturation'):
 a=rows['baseline',n]['object_sha256'];b=rows['final',n]['object_sha256'];print('client object',n,'identical',a==b,a,b)
for pre in ('','client-'):
 for n in ('names','interfaces','simp','instances'):
  a=(r/f'baseline-{pre}{n}.log').read_bytes();b=(r/f'final-{pre}{n}.log').read_bytes();assert a==b;print('probe',pre+n,'lines',len(a.splitlines()),'identical')
assert (r/'baseline-names.log').read_text().count('DECL ')==58 and (r/'baseline-client-names.log').read_text().count('DECL ')==26
f=get('attempt1-baseline-supplement-records.json');assert len(f)==3 and f[0]['status']==f[1]['status']==0 and f[2]['status']!=0 and f[2]['log_sha256']==h(r/'attempt1-baseline-ArithmeticBinomLegendre.log');assert 'HFS/Vec.olean' in (r/'attempt1-baseline-ArithmeticBinomLegendre.log').read_text();print('first supplemental missing-Vec failure preserved')
print('proof equality and assumptions verified by paired builds; cached Foundation/package closure is not fully rebuilt')
for ph in ('baseline','final'):
 d=next(x for x in rows[ph,'ArithmeticBinaryPopulation']['direct_inputs'] if x['module']=='Foundation.FirstOrder.Arithmetic.HFS.PRF');p=r/('supplement-objects-'+ph)/'Foundation/FirstOrder/Arithmetic/HFS/PRF.olean';assert h(p)==d['before'];print('post-build supplement PRF object matches main target direct input',ph,h(p))
