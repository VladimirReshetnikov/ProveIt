from pathlib import Path
import os,json,hashlib,subprocess,sys
r=Path('/tmp/binary-half-direct');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=Path('/tmp/binary-half-reuse-20261028/final');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ph=sys.argv[1];env=os.environ.copy();lib=r/('objects-'+ph);lib.mkdir(exist_ok=True)
for q in base.iterdir():
 if not (lib/q.name).exists():subprocess.run(['cp','-as',str(q),str(lib/q.name)],check=True)
for n in ('ArithmeticBinaryPopulation','ArithmeticBinaryCarry','ArithmeticRepunit'):(lib/'DiophantineConsistency'/(n+'.olean')).unlink(missing_ok=True)
s=r/ph/'DiophantineConsistency';s.mkdir(parents=True,exist_ok=True)
if ph=='baseline':(s/'ArithmeticBinaryPopulation.lean').write_bytes((w/'ArithmeticBinaryPopulation.lean').read_bytes())
for n in ('ArithmeticBinaryCarry','ArithmeticRepunit'):(s/(n+'.lean')).write_bytes((w/(n+'.lean')).read_bytes())
jobs=[('ArithmeticBinaryPopulation',['Foundation.FirstOrder.Arithmetic.HFS.PRF','Mathlib.Tactic.Ring']),('ArithmeticBinaryCarry',['DiophantineConsistency.ArithmeticBinaryPopulation']),('ArithmeticRepunit',['DiophantineConsistency.ArithmeticBinaryPopulation'])];env['LEAN_PATH']=str(lib)+':'+str(base)+':'+env['LEAN_PATH'];rows=[]
for n,imports in jobs:
 src=s/(n+'.lean');inputs=[]
 for name in imports:
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p)})
 obj=lib/'DiophantineConsistency'/(n+'.olean');tm=r/(ph+'-'+n+'.time');log=r/(ph+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M6000','-j1','-DElab.async=false','-R',str(r/ph),str(src),'-o',str(obj)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path'])
 rec={'phase':ph,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None};rows.append(rec);(r/(ph+'-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(ph,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
