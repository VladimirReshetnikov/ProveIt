import Lean.Elab.Command
import DiophantineConsistency.ArithmeticBinaryPopulation
open Lean Elab Command
run_cmd do
 let env ← getEnv
 for (n, _) in env.constants.toList do
  if (`DiophantineConsistency.ArithmeticBinaryPopulation).isPrefixOf n ||
     (toString n).startsWith "_private.DiophantineConsistency.ArithmeticBinaryPopulation" then
   logInfo m!"DECL {n}"
