from pathlib import Path
import os,json,hashlib,subprocess,sys
r=Path('/tmp/binary-half-direct');w=Path('Computability/DiophantineConsistency/Lean/DiophantineConsistency');base=Path('/tmp/binary-half-reuse-20261028/final');extra=Path('/tmp/binom-odd-sharing/objects-final/DiophantineConsistency');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ph=sys.argv[1];env=os.environ.copy();lib=r/('supplement-objects-'+ph);lib.mkdir(exist_ok=True);dst=lib/'DiophantineConsistency';s=r/ph/'DiophantineConsistency'
if not dst.exists():subprocess.run(['cp','-as',str(r/('objects-'+ph)/'DiophantineConsistency'),str(dst)],check=True)
(lib/'Foundation').symlink_to('/home/codex/src/Proofs/.lake/build/lib/lean/Foundation',target_is_directory=True) if not (lib/'Foundation').exists() else None
for f in extra.iterdir():
 q=dst/f.name
 if not q.exists() and not q.is_symlink():q.symlink_to(f)
for n in ('ArithmeticBinaryPopulationChecks','ArithmeticStandardCasts','ArithmeticBinomLegendre','ArithmeticSaturation'):
 (s/(n+'.lean')).write_bytes((w/(n+'.lean')).read_bytes());(dst/(n+'.olean')).unlink(missing_ok=True)
jobs=[('ArithmeticBinaryPopulationChecks',['DiophantineConsistency.ArithmeticBinaryPopulation']),('ArithmeticStandardCasts',['DiophantineConsistency.ArithmeticBinaryPopulation']),('ArithmeticBinomLegendre',['DiophantineConsistency.ArithmeticBinomFactorial','DiophantineConsistency.ArithmeticBinaryPopulation']),('ArithmeticSaturation',['DiophantineConsistency.ArithmeticBinaryCarry'])];env['LEAN_PATH']=str(lib)+':'+str(base)+':'+env['LEAN_PATH'];rows=[]
for n,imports in jobs:
 src=s/(n+'.lean');inputs=[]
 for name in imports:
  rel=name.replace('.','/')+'.olean';p=next(Path(q)/rel for q in env['LEAN_PATH'].split(':') if (Path(q)/rel).is_file());inputs.append({'module':name,'path':str(p),'resolved':str(p.resolve()),'before':h(p)})
 obj=dst/(n+'.olean');tm=r/(ph+'-'+n+'.time');log=r/(ph+'-'+n+'.log');before=h(src);cmd=['/usr/bin/time','-o',str(tm),'-f','elapsed=%e user=%U system=%S maxrss=%M','lean','-M6000','-j1','-DElab.async=false','-R',str(r/ph),str(src),'-o',str(obj)]
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 for d in inputs:d['after']=h(d['path'])
 rec={'phase':ph,'module':n,'source':str(src),'before':before,'after':h(src),'direct_inputs':inputs,'LEAN_PATH':env['LEAN_PATH'],'command':cmd,'status':p.returncode,'log':str(log),'log_sha256':h(log),'time':tm.read_text(),'object':str(obj),'object_sha256':h(obj) if obj.exists() else None};rows.append(rec);(r/(ph+'-supplement-records.json')).write_text(json.dumps(rows,indent=2)+'\n');print(ph,n,p.returncode,rec['time'].strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
