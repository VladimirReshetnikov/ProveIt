#!/usr/bin/env python3
"""Explore one genuinely larger relation span than the published depth-4 obstruction.

Generation is exact, but no conclusion follows without an exact replay certificate.
"""
from word_algebra import *
from bounded_source import rel2,rel4,expand,product_poly,antisym,target
from itertools import product,combinations
from pathlib import Path
from math import gcd
from collections import Counter
import json,time

W,D=7,5
base=Path(__file__).resolve().parent
start=time.monotonic()
def depth(w):return sum(a!=Z for a in w)
def encode(w):
    x=0
    for a in w:x=5*x+a+1
    return x
byweight={0:[()]}
for weight in range(1,W):
    byweight[weight]=[w for w in product(range(-1,4),repeat=weight)
                      if admissible(w) and depth(w)<=D]
def admissible_at(weight,d):
    return [w for w in byweight[weight] if depth(w)<=d]
rows=[];desc=[];seen=set();counts=Counter()
def insert(row,ds):
    row=odd_projection(row)
    if not row:return
    assert all(admissible(w) and len(w)==W and depth(w)<=D for w in row)
    g=0
    for c in row.values():g=gcd(g,c)
    if row[min(row)]<0:g=-g
    row={encode(w):c//g for w,c in row.items()}
    key=tuple(sorted(row.items()))
    if key in seen:return
    seen.add(key);rows.append(row);desc.append(ds+[g]);counts[ds[0]]+=1
for p in [1,2,3]:
    us=byweight[p]+([(0,)] if p==1 else [])
    vs=byweight[W-p]
    for u in us:
        for v in vs:
            if depth(u)+depth(v)>D:continue
            if (u,v)>(conjugate(u),conjugate(v)):continue
            insert(double_shuffle(u,v),['ds',u,v])
    print('DS factor',p,'rows',len(rows),'time',time.monotonic()-start,flush=True)
for weight in range(1,W+1):
    for d in range(1,min(weight,D)+1):
        for cuts in combinations(range(1,weight),d-1):
            edges=(0,)+cuts+(weight,)
            exponents=tuple(edges[j+1]-edges[j] for j in range(d))
            for colors in product((0,1),repeat=d):
                if exponents[0]==1 and colors[0]==0:continue
                ind=tuple(zip(exponents,colors))
                row={to_word(tuple((a,2*c) for a,c in ind)):1}
                for eps in product((0,2),repeat=d):
                    w=to_word(tuple((a,(c+e)%4) for (a,c),e in zip(ind,eps)))
                    row=plus(row,{w:1},-2**(weight-d))
                for v in admissible_at(W-weight,D-d):
                    insert(product_poly(row,{v:1}) if v else row,['dist',ind,v])
    print('DIST weight',weight,'rows',len(rows),'time',time.monotonic()-start,flush=True)
for weight in (3,5):
    row=antisym(rel2() if weight==3 else rel4())
    for v in admissible_at(W-weight,D-2):
        insert(product_poly(row,plus({v:1},{conjugate(v):1})),['lift',weight,v])
print('LIFT rows',len(rows),'time',time.monotonic()-start,flush=True)
for weight in range(1,W+1):
    for w in product('zxbyh',repeat=weight):
        if w[0]=='x' or w[-1]=='z':continue
        common=min(w.count('z'),w.count('x'))
        if common<1:continue
        seed_depth=weight-common
        if seed_depth>D or (weight<W and seed_depth==D):continue
        original=expand(w)
        transformed={}
        for u,c in original.items():transformed=plus(transformed,cayley(u),c)
        row=plus(original,transformed,-1)
        if not odd_projection(row):continue
        for v in admissible_at(W-weight,D-seed_depth):
            insert(product_poly(row,{v:1}) if v else row,['cayley_lift',w,v])
    print('CAYLEY weight',weight,'rows',len(rows),'time',time.monotonic()-start,flush=True)
targ=odd_projection(target())
rows.append({encode(w):c for w,c in targ.items()});desc.append(['target'])
cols=set().union(*(r.keys() for r in rows))
with (base/'depth5_rows.txt').open('w') as f:
    f.write(f'{len(rows)} {5**W}\n')
    for r in rows:
        f.write(str(len(r))+' '+' '.join(f'{a} {c}' for a,c in sorted(r.items()))+'\n')
(base/'depth5_descriptors.json').write_text(json.dumps(desc,separators=(',',':'))+'\n')
summary={'weight':W,'depth':D,'counts':counts,'target_terms':len(targ),'columns':len(cols),'rows':len(rows)-1,'entries':sum(map(len,rows)),'elapsed_seconds':time.monotonic()-start}
(base/'depth5_generation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
