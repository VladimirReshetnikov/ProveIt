#!/usr/bin/env python3
"""Check target scaling using rational arithmetic; no assertion R6 = 0."""
from fractions import Fraction as Q
from pathlib import Path
import json
scale = 128588
actual = {
    "u61": 128588, "g61": 3138084, "g52": 1592832, "g43": 521184,
    "beta7": -216172, "beta4_zeta3": 48861, "beta6_log2": 257176,
}
expected = {
    "u61": scale,
    "g61": scale*(1+Q(12334,527)),
    "g52": scale*Q(384,31),
    "g43": scale*Q(2136,527),
    "beta7": -scale*Q(3179,5713920)/Q(61,184320),
    "beta4_zeta3": scale*Q(801,2108),
    "beta6_log2": scale*2,
}
assert actual == expected
receipt = json.loads((Path(__file__).parent/"target_normalization.json").read_text())
assert receipt["scaled_coordinate_coefficients"] == actual
print("PASS: exact scalar normalization only; no assertion that R6 vanishes.")
