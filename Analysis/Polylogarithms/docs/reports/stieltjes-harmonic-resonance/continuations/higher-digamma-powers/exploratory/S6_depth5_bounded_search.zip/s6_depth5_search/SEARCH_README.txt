DEPTH-FIVE GAUSSIAN S6 EXPLORATION

Source baseline
  ProveIt commit b7667ae40a2957eed9a53d8559d53a3ee20dd1c1.
  Canonical target: cycloquot:conj:S6 in 04-cyclotomic-quotients.tex.
  Source code is adapted from the Independent Orders incoming report's
  word_algebra.py and the Exact Resonant Identities incoming report's
  bounded_relations.py. Both report archives are dated 2026-10-11.

Purpose
  The inherited exact obstruction concerns specified extra relations of
  total input depth at most four, even after adjoining the full Cayley
  shuffle ideal. This experiment raises the explicit row cutoff to five.
  It does NOT assert that its balanced Cayley lifts generate the full
  Cayley ideal at depth five.

Exact generated family (weight seven)
  14,908 distinct double-shuffle rows;
   4,938 distinct distribution rows and convergent product lifts;
     128 lifts of the proved S2/S4 imaginary identities by real factors;
   2,322 balanced Cayley rows and the specified stuffle product lifts.
  Total: 22,296 rows, 8,786 imaginary word coordinates.
  Duplicate rows are identified after primitive integer normalization.
  Only the single divergent Li_1(1) factor is regularized in double shuffle.
  Its common divergent word cancels, and every final word is admissible.

Target
  target_normalization.json records the exact rational check that the
  generated target evaluates to 128588 times the canonical short residual.
  It does not assert that this residual vanishes.

Reproduction
  python generate_depth5.py
  g++ -O3 -std=c++17 modular_complete.cpp -o modular_complete
  ./modular_complete depth5_rows.txt 600 > depth5_complete.json \
      2> depth5_complete.log

  The generated rows and descriptors use exact integers. The eliminator
  works only over F_2147483647. At a time limit it writes a reduced-matrix
  checkpoint that can be passed back as the input. Checkpoints are already
  reduced modulo the prime; they are not rational identity certificates.

Interpretation
  A modular zero is a search signal, not a proof over Q. A modular nonzero
  residual after exhaustion is a finite-field statement and does not by
  itself prove nonmembership in the rational span, because the integer
  matrix can lose rank modulo the prime. A nonzero residual before
  exhaustion does not even establish finite-field nonmembership.
  The current S6 and revised S8 period identities must therefore retain
  conjectural status unless a separate exact rational certificate is given.

Files to retain with a research package
  generate_depth5.py, word_algebra.py, bounded_source.py,
  modular_complete.cpp, depth5_generation.json, depth5_complete.json,
  depth5_complete.log, target_normalization.json, SEARCH_README.txt.
  The generated matrix/descriptors/checkpoints and local executable need
  not be distributed because the script reconstructs the integer input.

Earlier capped run
  depth5_search.json records a separate four-minute run at 7,000 pivots,
  with 16 target terms and row_span_exhausted=false. It is not an obstruction
  theorem. The modular_search.cpp code of that run is inherited provenance.

Final completed run
  The specified family was exhausted in 327.756 seconds, before the
  600-second cap. Its rank over F_2147483647 was 8,705 in 8,786 occupied
  columns. The target retained 16 nonzero coordinates. This establishes
  nonmembership only in the stated finite-field row span. No rational
  separating functional, rational identity certificate, or period
  nonvanishing theorem is claimed. No further search was performed.
  The enlarged finite family is insufficient modulo the stated prime;
  the mathematical S6 conjecture remains unresolved by this experiment.

Target displayed in period notation
  Let g_ab = Im Li_{a,b}(i,1), beta be the Dirichlet beta function, and
  S6 = sum_{n>=0} (-1)^n H_n/(2n+1)^6. The short residual is
    R6 = S6 + (12334/527) g_61 + (384/31) g_52
         + (2136/527) g_43 - (3179/5713920) pi^7
         + (801/2108) beta(4) zeta(3) + 2 beta(6) log(2).
  The generated target's imaginary evaluation is 128588 R6. The
  verify_target_normalization.py script checks its scalar coefficients
  with Python's exact Fraction arithmetic; it does not evaluate R6.

Reproducibility limits
  Timing is machine dependent. The prime, row counts, rank, and nonzero
  target are the reported mathematical computation. A different ordering
  of row reductions may produce a different representative residual.
  The complete source of the deterministic run is included. The retained
  log is a computation record rather than a compact independently replayed
  dual certificate. The raw matrix can be regenerated in about 24 seconds.
