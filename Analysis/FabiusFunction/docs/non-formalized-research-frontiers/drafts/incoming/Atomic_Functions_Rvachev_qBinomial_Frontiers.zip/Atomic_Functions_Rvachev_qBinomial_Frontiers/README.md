# Atomic Functions, Rvachev's up-Function, and q-Binomial Derivative Geometry

This package contains the final English reconstruction and expansion of the attached
Rvachev source material.

## Main files

- `Atomic_Functions_Rvachev_qBinomial_Frontiers.tex` - LaTeX source.
- `Atomic_Functions_Rvachev_qBinomial_Frontiers.pdf` - rendered 45-page report.
- `experiments.py` - deterministic numerical experiments and figure/data generator.
- `CORPUS_AUDIT.md` - repository pin, inherited-result boundary, and targeted
  nonduplication searches.
- `figures/` and `data/` - generated report assets and validation tables.

## Rebuild

Install the Python dependencies:

```bash
python -m pip install -r requirements.txt
```

Regenerate the numerical assets:

```bash
python experiments.py
```

Compile the report from this directory:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  Atomic_Functions_Rvachev_qBinomial_Frontiers.tex
```

The report uses only standard TeX Live packages and falls back from Libertinus to Latin
Modern if Libertinus is unavailable.

## Reproducibility notes

All pseudo-random experiments use fixed seeds. Exact identities are proved in the report;
the floating-point and 90-digit calculations are independent implementation checks.
`experiments.py` writes all outputs deterministically under `figures/` and `data/`.
