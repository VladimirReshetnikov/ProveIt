# Atomic Functions Beyond the Critical Dyadic Case

This archive contains the English reconstruction and expansion of the attached Rvachev chapter.

## Build

```bash
python experiments.py --output .
latexmk -pdf -interaction=nonstopmode -halt-on-error Atomic_Functions_Beyond_Dyadic_Expanded.tex
```

The script uses the fixed seed `20260828`. All figures are written in PDF and PNG formats, and the numerical audits are written to `data/`.

## Status markers in the report

- `[S]`: translated or reconstructed source material.
- `[R]`: repository or established literature connection.
- `[N]`: proved deduction in the report, without a priority claim.
- `[F]`: post-audit frontier formula not found in the inspected repository snapshot.
- `[C]`: conjecture or research program.
