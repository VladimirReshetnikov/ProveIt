from fractions import Fraction as F
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from complex_interval_core import I,iv,S,sinp,cosp,trig_rad
J=32
bs=[sinp(F(1,2**(j+1)))/cosp(F(1,2**(j+1))) for j in range(1,J+1)]
def mean(t):
 a=trig_rad(t,'sin')/trig_rad(t,'cos');m=iv(0)
 for b in bs:m=m+(a*b)/(1+a*b)
 # tan x lies below the chord(4/pi)x on[0,pi/4].
 m=I(m.lo,m.hi+(a*F(2,2**J)).hi)
 return iv(t)*(1+a.square())/a*(1+m)
lo=F(3413848,10**7);hi=F(3484140,10**7)
a=mean(lo);b=mean(hi)
if not F(a.hi,S)<F(33,20) or not F(b.lo,S)>F(833,500):raise RuntimeError('saddle range fails')
out={'t_interval':[str(lo),str(hi)],'slope_interval':['33/10','833/250'],'mean_lower_endpoint_upper':str(F(a.hi,S)),'mean_upper_endpoint_lower':str(F(b.lo,S)),'all_pass':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
