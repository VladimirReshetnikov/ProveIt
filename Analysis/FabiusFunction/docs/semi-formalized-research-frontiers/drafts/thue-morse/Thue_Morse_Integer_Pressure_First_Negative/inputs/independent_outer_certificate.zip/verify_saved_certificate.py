"""Replay the saved certificate and prove exact binary partition coverage."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,time
from sharp_outer_bound import best_upper,S
from replay_outer_scalar import ensure,trig_rad,iv,R
root=Path(__file__).resolve().parent
path=root/'sharp_outer_certificate.json'; data=json.loads(path.read_text())
domain=tuple(map(F,data['domain_t']+data['domain_theta_over_pi']))
ensure(domain==(F(3413848,10**7),F(3484140,10**7),F(153,1000),F(1,2)),'wrong domain')
leaves=[tuple(map(F,row[:6])) for row in data['cells']]
ensure(len(leaves)==len(set(leaves)),'duplicate leaves')
rem=set(leaves);t0,t1,q0,q1=domain
stack=[(t0,t1,q0,q1,F(1),F(3,2)),(t0,t1,q0,q1,F(3,2),F(2))];nodes=0
while stack:
 b=stack.pop();nodes+=1
 ensure(nodes<=2*len(leaves),'tree mismatch')
 if b in rem:rem.remove(b);continue
 widths=[b[1]-b[0],b[3]-b[2],(b[5]-b[4])**2]
 i=2*max(range(3),key=lambda j:widths[j]);m=(b[i]+b[i+1])/2
 l=list(b);r=list(b);l[i+1]=m;r[i]=m;stack.extend([tuple(l),tuple(r)])
ensure(not rem,'unmatched leaf')
a=trig_rad(t1,'sin')/trig_rad(t1,'cos');ensure(a.hi<iv(R).lo,'radius bound')
start=time.time();maximum=F(0)
for box,row in zip(leaves,data['cells']):
 value=F(best_upper(box),S)
 ensure(value==F(row[6]),'saved bound differs')
 ensure(value<F(999,1000),'strict target fails')
 maximum=max(maximum,value)
ensure(maximum==F(data['maximum_squared_ratio_upper']),'maximum mismatch')
ensure(F(999,1000)<F(1999,2000)**2,'eta comparison fails')
out={'all_pass':True,'cells':len(leaves),'nodes':nodes,'maximum_squared_ratio_upper':str(maximum),'eta':'1999/2000','certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'seconds':time.time()-start}
(root/'portable_replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
