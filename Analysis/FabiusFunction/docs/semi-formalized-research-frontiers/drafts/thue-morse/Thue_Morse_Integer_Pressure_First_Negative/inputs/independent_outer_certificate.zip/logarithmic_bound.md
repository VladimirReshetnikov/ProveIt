# A rigorous spatial sharpening for the outer contour certificate

Use the notation of complex_contour_reduction.md. On a box in(t,theta/pi,X), retain the same complex interval a=tan(t exp(i theta)) in every factor. Put u=Re a and v=|a|^2. For either sign epsilon=+/-1, write
f_j(X)=cos(gamma_j X)+epsilon a sin(gamma_j X), gamma_j=pi/2^j.

For real c=cos(gamma_j X),s=sin(gamma_j X), the exact scalar formulas are
|f_j|^2=c^2+2epsilon u c s+v s^2,
(d/dX)log|f_j|^2=2gamma_j [epsilon u(c^2-s^2)+(v-1)c s]/|f_j|^2.
Thus an interval bound retains the common complex phase; it does not replace a by its modulus inside the factors.

The real weight h=H_(2/5) is positive and log-concave on[0,1/2], since every factor is positive and its logarithm has negative second derivative. Its minimum on a distance cell is at an endpoint. The finite positive real prefix is a lower bound, because every omitted factor exceeds1. This also proves h>=1 from h(0)=1 and a certified h(1/2)>1.

Let J=20. For real X in[0,Xmax], set tau=pi Xmax/2^(J+1). For |a|<=R=2/5, every omitted factor obeys
|f_j|>=1-R tau-tau^2/2,
|f'_j|<=gamma_j(R+tau).
As sum_(j>J) gamma_j=pi/2^J, the omitted squared logarithmic derivative has absolute value at most
D_tail(Xmax)=2pi/2^J (R+tau)/(1-R tau-tau^2/2).
All denominators are positive by exact rational checks. The full derivative of
F_epsilon(X)=log(|H_(epsilon a)(X)|^2/h(dist(X,Z))^2)
is therefore enclosed by the finite derivative sums, with an added symmetric error interval of radius D_tail(2)+D_tail(1/2). The sign of the real denominator derivative is+1 belowX=3/2 and-1 above it; no box crosses that point.

At the midpoint Xm of a spatial box, bound the first20 squared factors directly and the geometric product tail by (1-E)^(-2), where
E=R pi Xm/2^J+(pi Xm)^2/(6*4^J).
Use the positive prefix lower bound for h(dist(Xm,Z)). If |F'_epsilon|<=D on the whole box and its half-width isw, then
exp(F_epsilon(X))<=exp(F_epsilon(Xm)) exp(Dw)
<=exp(F_epsilon(Xm))/(1-Dw), providedDw<1.
Every operation is outward-rounded rational interval arithmetic. Where an interval factor denominator is not certified positive, orDw>=1, the implementation falls back to the direct squared-factor enclosure.

Finally multiply by |a|^2 L_R^2/g(tan t)^4, using a certified upper bound for L_R, the same complex a interval, and the real lower endpoint of t for g, which is increasing. This yields a rigorous upper bound for the SQUARE of(G). A bound strictly below1 is sufficient. The implementation is sharp_outer_bound.py; replay_outer_scalar.py contains the separate direct squared-factor formula and real endpoint bounds.

At a representative near-worst box t in[.3413848,.3414348],theta/pi in[.153,.15305],X in[1.835,1.845], the derivative method gives squared upper ratio<.999432 while the direct scalar product bound is>1. This is only an illustration; the adaptive producer must still certify the entire domain.
