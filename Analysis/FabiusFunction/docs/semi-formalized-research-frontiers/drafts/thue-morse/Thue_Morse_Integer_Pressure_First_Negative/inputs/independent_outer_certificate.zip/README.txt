Exact outer complex-contour certificate

This portable Python-standard-library bundle certifies inequality (G) in the
Thue--Morse first-negative contour reduction, for
 t in [3413848/10^7,3484140/10^7],
 theta/pi in [153/1000,1/2], and X in [1,2].
It proves a squared ratio below 999/1000, hence eta=1999/2000 is admissible.
The proof of the spatial logarithmic derivative bound is logarithmic_bound.md.

Run, from this folder:
  python -O verify_saved_certificate.py
  python -O verify_saddle_range.py

The first command independently reconstructs the exact binary box partition,
recomputes every saved upper bound, and checks strictness. The second checks
that the t interval contains the second saddle for slopes [3.3,3.332].
The saved certificate contains 2,812 boxes. Runtime is about one minute.
All interval operations use directed integer rounding on a 10^32 grid.
There are no third-party Python dependencies or absolute filesystem imports.

Optional regeneration:
  python -O produce_sharp_outer.py
This rewrites the certificate deterministically except for elapsed runtime.

The scalar certificate establishes this analytic inequality and saddle range.
The operator and coefficient asymptotic implications are separate arguments
in the enclosing first-negative report.
