BLACK-HOLE SINGULARITIES AND ALGEBRAIC QUANTIZATION FROM THE NULL CONE
Analysis of arXiv:2611.34924v1, prepared 25 November 2026

MAIN RESULT
The paper does not demonstrate a resolution of black-hole singularities
or continuation of infalling worldlines. This is a conclusion about what
has been established, not a claim that the proposed quantum theory must
retain the classical singularity.

CONTENTS
black_hole_singularity_analysis.pdf   Complete research analysis
black_hole_singularity_analysis.tex   Editable LaTeX source
references.bib                       References and source locators
numerical_table.tex                  Numerical table used by the report
calculations.py                      Symbolic checks and figure generation
numerical_results.json               Constants, results, and diagnostics
equation_checks.txt                  Output of the symbolic verification
figures/                            Original figures in PDF and PNG
build.sh                            LaTeX build command
source_provenance.json               Source version, locators, and provenance
CHECKSUMS.sha256                     SHA-256 hashes of packaged files

REPRODUCIBILITY
Python 3 with sympy, numpy, matplotlib:
  python3 calculations.py

LaTeX installation with latexmk, pdflatex, and bibtex:
  bash build.sh

The numerical table is a static rounded rendering of numerical_results.json.
All figures concern the explicitly stated classical Schwarzschild baseline.
They do not simulate or predict the proposed theory's quantum interior.

SCOPE
The report identifies exact sections, equations, and pages in the source.
It includes a finite-proper-time calculation, tidal-deviation analysis,
a Planck-curvature diagnostic, a bounded-null-clock/unbounded-curvature
example, and a finite-dimensional unitary-evolution counterexample.
The latter is a logical illustration, not a Hamiltonian from the paper.
No claim of a full independent verification of the proposed quantization
is made.

ORIGINAL SOURCE
Venkatesa Chandrasekaran, An algebraic quantization of gravity from the null cone
https://arxiv.org/abs/2611.34924v1
https://arxiv.org/pdf/2611.34924v1

The original article is not redistributed in this archive. Source page
references use the printed PDF numbering, which agrees with one-based
PDF page numbering for this version.
