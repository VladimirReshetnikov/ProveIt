#!/usr/bin/env python3
"""Reproduce the report's classical diagnostics and figures.

These calculations concern Schwarzschild geometry and do not predict the
strong-curvature dynamics of arXiv:2611.34924.  The condition K*l_P**4 = 1
is a heuristic diagnostic, not a transition or bounce derived by that paper.

Requirements: Python 3, sympy, numpy, matplotlib.
Run: python3 calculations.py
Outputs are written beside this script.

Constants:
  G = 6.67430e-11 m^3 kg^-1 s^-2 (CODATA recommended central value).
  c and h are exact SI defining constants; hbar = h/(2*pi).
  (GM_sun)^N = 1.3271244e20 m^3 s^-2 (IAU 2015 Resolution B3).
The examples use multiples of the nominal solar mass parameter, not an
independently measured solar mass.  Uncertainties are not propagated.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import sympy as sp


OUTPUT = Path(__file__).resolve().parent
FIGURES = OUTPUT / "figures"


def symbolic_checks() -> tuple[list[dict], str]:
    """Check algebraic consequences of the standard Schwarzschild equations."""
    r, mu, c, delta, lp, tp, rs, eps = sp.symbols(
        "r mu c delta lp tp rs eps", positive=True
    )
    checks: list[dict] = []

    def zero(name: str, expression: sp.Expr) -> None:
        residual = sp.simplify(expression)
        passed = residual == 0
        checks.append({"name": name, "passed": bool(passed), "residual": str(residual)})
        if not passed:
            raise AssertionError(f"{name}: residual = {residual}")

    # Here mu=GM, delta=tau_s-tau, and d/dtau=-d/ddelta.
    r_delta = (sp.Rational(9, 2) * mu * delta**2) ** sp.Rational(1, 3)
    dr_dtau = -sp.diff(r_delta, delta)
    zero("E=1 radial velocity: dr/dtau=-sqrt(2GM/r)", dr_dtau + sp.sqrt(2 * mu / r_delta))
    zero("Integrated radial infall: r^3=(9/2)GM*delta^2", r_delta**3 - sp.Rational(9, 2) * mu * delta**2)

    delta_r = 2 * r ** sp.Rational(3, 2) / (3 * sp.sqrt(2 * mu))
    zero("Proper-time integral derivative", sp.diff(delta_r, r) - sp.sqrt(r / (2 * mu)))
    zero("Horizon-to-endpoint time=4GM/(3c^3)", delta_r.subs(r, 2 * mu / c**2) - 4 * mu / (3 * c**3))

    # K below is the standard Schwarzschild curvature invariant; these checks
    # verify substitutions, not an independent tensor derivation of K.
    K = 48 * mu**2 / (c**4 * r**6)
    zero("K=12*r_s^2/r^6", K.subs(mu, rs * c**2 / 2) - 12 * rs**2 / r**6)
    K_delta = sp.simplify(K.subs(r, r_delta))
    zero("K(delta)=64/(27*c^4*delta^4)", K_delta - 64 / (27 * c**4 * delta**4))
    zero("Dimensionless K*l_P^4=(64/27)*(t_P/delta)^4", (K_delta * lp**4).subs(lp, c * tp) - sp.Rational(64, 27) * (tp / delta) ** 4)

    rQ = (12 * rs**2 * lp**4) ** sp.Rational(1, 6)
    zero("Threshold radius solves K*l_P^4=1", 12 * rs**2 * lp**4 / rQ**6 - 1)
    zero("Threshold radius=12^(1/6)*(r_s*l_P^2)^(1/3)", rQ - 12 ** sp.Rational(1, 6) * (rs * lp**2) ** sp.Rational(1, 3))
    deltaQ = sp.simplify(delta_r.subs(r, rQ).subs(rs, 2 * mu / c**2).subs(lp, c * tp))
    threshold_coefficient = sp.Rational(64, 27) ** sp.Rational(1, 4)
    zero("Threshold remaining time=(64/27)^(1/4)*t_P", deltaQ - threshold_coefficient * tp)

    # For radial ingoing null rays in Eddington-Finkelstein coordinates,
    # g_(v,r)=[[-f,1],[1,0]] and Gamma^a_rr=0.  Thus r is affine.
    f = 1 - rs / r
    g = sp.Matrix([[-f, 1], [1, 0]])
    g_inv = g.inv()
    coords = (sp.Symbol("v", real=True), r)
    for a in range(2):
        gamma_a_rr = sum(
            g_inv[a, b]
            * (2 * sp.diff(g[1, b], r) - sp.diff(g[1, 1], coords[b]))
            / 2
            for b in range(2)
        )
        zero(f"Ingoing null affine connection Gamma^{a}_rr=0", gamma_a_rr)

    theta = -2 / r
    zero("Shear-free null Raychaudhuri equation", -sp.diff(theta, r) + theta**2 / 2)
    clock = (1 - eps) * rs
    capK = 12 / (eps**6 * rs**4)
    zero("Cap curvature: K*r_s^4=12/epsilon^6", (K.subs(mu, rs * c**2 / 2).subs(r, eps * rs)) * rs**4 - 12 / eps**6)
    clock_limit = sp.limit(clock / rs, eps, 0, dir="+")
    curvature_limit = sp.limit(capK * rs**4, eps, 0, dir="+")
    if clock_limit != 1 or curvature_limit != sp.oo:
        raise AssertionError("Incorrect cap limits")
    checks.append({"name": "epsilon->0: bounded normalized clock and divergent curvature", "passed": True, "clock_limit": str(clock_limit), "curvature_limit": str(curvature_limit)})

    p = sp.Symbol("p", real=True)
    radial_powers = sp.solve(p * (p - 1) - sp.Rational(4, 9), p)
    transverse_powers = sp.solve(p * (p - 1) + sp.Rational(2, 9), p)
    if radial_powers != [sp.Rational(-1, 3), sp.Rational(4, 3)]:
        raise AssertionError("Incorrect radial Jacobi powers")
    if transverse_powers != [sp.Rational(1, 3), sp.Rational(2, 3)]:
        raise AssertionError("Incorrect transverse Jacobi powers")
    checks.append({"name": "Jacobi exponents", "passed": True,
                   "radial": [str(x) for x in radial_powers],
                   "transverse": [str(x) for x in transverse_powers],
                   "generic_volume_exponent": str(radial_powers[0] + 2 * transverse_powers[0])})

    notes = [
        "SYMBOLIC EQUATION CHECKS",
        "========================",
        "All calculations are classical Schwarzschild diagnostics.",
        "mu=GM; delta=tau_s-tau; r_s=2GM/c^2; l_P=c*t_P.",
        "The standard formula K=48(GM)^2/(c^4 r^6) is an input.",
        "This script verifies its algebraic consequences, not the paper's quantum theory.",
        "",
    ]
    for check in checks:
        notes.append("PASS: " + check["name"])
        for key, value in check.items():
            if key not in {"name", "passed"}:
                notes.append(f"      {key}: {value}")
    notes.extend([
        "",
        "SCOPE",
        "-----",
        "Timelike example: radial geodesic with energy per rest energy e=1.",
        "A pointlike test probe is assumed; its backreaction is neglected.",
        "The Jacobi powers describe infinitesimal freely falling bundles only.",
        "Null example: future inward radial rays normalized by dr/dlambda=-1.",
        "The paper's coordinate from cap to corner reverses that orientation.",
        "The clock is an affine-distance reading, not proper time along a null ray.",
        "Every epsilon>0 region is smooth; the epsilon->0 family is a classical",
        "diagnostic, not a limit established in the paper's fixed-epsilon construction.",
        "K*l_P^4=1 is a heuristic curvature threshold, not a predicted bounce.",
        "No classical continuation or quantum trajectory is asserted in the shaded region.",
        "",
    ])
    return checks, "\n".join(notes)


def numerical_results(checks: list[dict]) -> dict:
    G = 6.67430e-11
    c = 299792458.0
    h = 6.62607015e-34
    hbar = h / (2 * math.pi)
    nominal_solar_mu = 1.3271244e20
    lp = math.sqrt(hbar * G / c**3)
    tp = lp / c
    coefficient = (64 / 27) ** 0.25
    rows = []
    for ratio in (10, 1_000_000, 4_000_000):
        mu = nominal_solar_mu * ratio
        rs = 2 * mu / c**2
        rQ = 12 ** (1 / 6) * (rs * lp**2) ** (1 / 3)
        delta_h = 4 * mu / (3 * c**3)
        delta_Q = 2 * rQ**1.5 / (3 * math.sqrt(2 * mu))
        if not math.isclose(delta_Q, coefficient * tp, rel_tol=1e-12):
            raise AssertionError("Numerical threshold-time consistency failed")
        if not math.isclose(12 * rs**2 * lp**4 / rQ**6, 1.0, rel_tol=1e-12):
            raise AssertionError("Numerical threshold-curvature consistency failed")
        rows.append({
            "mass_ratio_nominal_solar": ratio,
            "gravitational_mass_parameter_m3_s2": mu,
            "schwarzschild_radius_m": rs,
            "horizon_to_endpoint_proper_time_s": delta_h,
            "planck_curvature_radius_m": rQ,
            "radius_ratio": rQ / rs,
            "threshold_remaining_proper_time_s": delta_Q,
        })
    return {
        "description": "Classical Schwarzschild diagnostics; not strong-curvature predictions of arXiv:2611.34924.",
        "trajectory": "Radial timelike e=1 test geodesic; static nonrotating uncharged Schwarzschild mass.",
        "threshold_definition": "K*l_P^4=1 (heuristic only)",
        "constants": {
            "G_m3_kg_s2": G,
            "c_m_s": c,
            "h_J_s": h,
            "hbar_J_s": hbar,
            "nominal_solar_GM_m3_s2": nominal_solar_mu,
            "planck_length_m": lp,
            "planck_time_s": tp,
            "threshold_time_in_planck_times": coefficient,
            "G_source": "CODATA recommended value; central value only",
            "c_h_source": "SI exact defining constants",
            "nominal_solar_GM_source": "IAU 2015 Resolution B3",
        },
        "symbolic_checks": checks,
        "rows": rows,
    }


def configure_figures() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9.5,
        "axes.titlesize": 10.5,
        "axes.labelsize": 9.5,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.edgecolor": "#84919B",
        "axes.labelcolor": "#233844",
        "text.color": "#233844",
        "xtick.color": "#42545F",
        "ytick.color": "#42545F",
        "grid.color": "#DCE3E8",
        "grid.linewidth": 0.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.facecolor": "white",
    })


def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(FIGURES / f"{stem}.pdf", metadata={"Title": stem, "Author": "OpenAI analysis", "Subject": "Classical diagnostic, not a quantum prediction"})
    fig.savefig(FIGURES / f"{stem}.png", dpi=220)
    plt.close(fig)


def make_null_clock_figure() -> None:
    eps = np.geomspace(1, 1e-6, 600)
    fig, axes = plt.subplots(1, 2, figsize=(7, 3.7))
    fig.subplots_adjust(left=0.09, right=0.975, top=0.79, bottom=0.235, wspace=0.38)
    fig.text(0.5, 0.945, "CLASSICAL DIAGNOSTIC", ha="center", fontsize=10.5, fontweight="bold", color="#AA5228")
    fig.text(0.5, 0.89, "A bounded null clock does not by itself bound curvature", ha="center", fontsize=10.5)
    blue = "#246B92"
    orange = "#B65B34"

    axes[0].plot(eps, 1 - eps, color=blue, lw=2.4)
    axes[0].axhline(1, color="#647781", lw=1.0, ls=(0, (4, 3)))
    axes[0].set_title("Normalized clock reading", pad=8)
    axes[0].set_ylabel(r"$\bar u_*/r_s=1-\epsilon$")
    axes[0].set_ylim(-0.025, 1.12)
    axes[0].set_yticks([0, 0.25, 0.5, 0.75, 1])
    axes[0].text(0.001, 0.82, r"limit $=1$", ha="center", color=blue, fontsize=10)

    axes[1].plot(eps, 12 * eps ** (-6), color=orange, lw=2.4)
    axes[1].set_yscale("log")
    axes[1].set_title("Curvature at the cap", pad=8)
    axes[1].set_ylabel(r"$K_{\rm cap}r_s^4=12\epsilon^{-6}$")
    axes[1].set_ylim(1, 1e39)
    axes[1].set_yticks([1, 1e12, 1e24, 1e36])

    for ax in axes:
        ax.set_xscale("log")
        ax.set_xlim(1, 1e-6)
        ax.set_xticks([1, 1e-2, 1e-4, 1e-6])
        ax.set_xlabel(r"$\epsilon=r_{\rm cap}/r_s$  (deeper $\longrightarrow$)")
        ax.grid(True, which="major", axis="both")
        ax.set_axisbelow(True)

    fig.text(0.5, 0.078, "Each positive cap radius defines a smooth classical region.", ha="center", fontsize=8.5)
    fig.text(0.5, 0.035, r"The $\epsilon\to0$ comparison is not a limit proved in the paper's fixed-$\epsilon$ quantum construction.", ha="center", fontsize=8)
    save_figure(fig, "null_clock_curvature")


def make_proper_time_figure(coefficient: float) -> None:
    x = np.geomspace(coefficient, 1e3, 600)
    y = (64 / 27) / x**4
    fig, ax = plt.subplots(figsize=(7, 3.7))
    fig.subplots_adjust(left=0.12, right=0.975, top=0.805, bottom=0.235)
    fig.text(0.5, 0.945, "CLASSICAL BASELINE", ha="center", fontsize=10.5, fontweight="bold", color="#AA5228")
    fig.text(0.5, 0.89, "Not a prediction of the paper's quantum dynamics", ha="center", fontsize=10.5)
    ax.axvspan(0.03, coefficient, color="#F8E7CF", alpha=0.90, zorder=0)
    ax.plot(x, y, color="#246B92", lw=2.5, zorder=3)
    ax.scatter([coefficient], [1], color="#246B92", s=28, zorder=4)
    ax.axhline(1, color="#8B6B48", lw=1.1, ls=(0, (4, 3)), zorder=1)
    ax.axvline(coefficient, color="#9F7B52", lw=1.0, ls=(0, (3, 3)), zorder=2)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(1e3, 0.03)
    ax.set_ylim(1e-12, 1e2)
    ax.set_xticks([1e3, 1e2, 1e1, 1, 0.1])
    ax.set_yticks([1e-12, 1e-8, 1e-4, 1, 1e2])
    ax.set_xlabel(r"Classical time remaining $x=(\tau_s-\tau)/t_P$  (endpoint $\longrightarrow$)")
    ax.set_ylabel(r"Dimensionless curvature $K\ell_P^4$")
    ax.grid(True, which="major", color="#DCE3E8", alpha=0.75)
    ax.set_axisbelow(True)
    ax.text(45, 3e-4, r"$K\ell_P^4=\dfrac{64}{27x^4}$", fontsize=11.5, color="#246B92", ha="center")
    ax.text(20, 3e-10, r"Radial $e=1$ Schwarzschild infall", fontsize=8.7, ha="center", color="#246B92")
    ax.text(0.20, 2e-4, "UNKNOWN\nQUANTUM REGIME", ha="center", va="center", fontsize=10.4, color="#8D4B20", fontweight="bold", linespacing=1.45)
    ax.text(0.20, 5e-8, "No curve asserted", ha="center", fontsize=8.8, color="#8D4B20")
    ax.text(75, 2.3, r"Heuristic threshold: $K\ell_P^4=1$", fontsize=8.6, color="#7F6041", ha="center")
    fig.text(0.5, 0.078, r"Threshold time: $(64/27)^{1/4}t_P\simeq1.241\,t_P$, independent of mass for this trajectory.", ha="center", fontsize=8.5)
    fig.text(0.5, 0.035, "Shading marks a curvature diagnostic, not a demonstrated transition or bounce.", ha="center", fontsize=8.3)
    save_figure(fig, "curvature_proper_time")


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    checks, checks_text = symbolic_checks()
    results = numerical_results(checks)
    (OUTPUT / "equation_checks.txt").write_text(checks_text, encoding="utf-8")
    (OUTPUT / "numerical_results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    configure_figures()
    make_null_clock_figure()
    make_proper_time_figure(results["constants"]["threshold_time_in_planck_times"])
    print(f"Passed {len(checks)} symbolic checks.")
    print(f"Planck length = {results['constants']['planck_length_m']:.10e} m")
    print(f"Planck time   = {results['constants']['planck_time_s']:.10e} s")
    for row in results["rows"]:
        print("M/nominal_solar={mass_ratio_nominal_solar:g}: "
              "r_s={schwarzschild_radius_m:.8e} m; "
              "r_Q={planck_curvature_radius_m:.8e} m; "
              "delta_tau_h={horizon_to_endpoint_proper_time_s:.8e} s".format(**row))
    print("Created numerical_results.json, equation_checks.txt, and both PDF/PNG figure pairs.")


if __name__ == "__main__":
    main()
