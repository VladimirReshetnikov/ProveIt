"""Finite certificates accompanying the ProveIt article assessment.

Run with python check_examples.py (Python 3 and SymPy). All integer and
rational comparisons are exact. Run without the -O flag to retain assertions.
"""
from fractions import Fraction
from itertools import combinations
from math import gcd, prod
import warnings
from sympy import Poly, primerange, symbols, zeros, cancel, isprime
from sympy.polys.numberfields import round_two
from sympy.utilities.exceptions import SymPyDeprecationWarning

# Columns q, p, a, b, v5, transcribed in q order from dir:tab:quintic.
DATA = """
47 2 9 1 5
79 2 7 1 5
103 2 5 1 5
127 2 1 1 5
131 3 29 1 5
179 3 16 2 5
227 3 8 2 5
347 3 25 1 3
443 3 23 1 3
523 7 220 6 5
571 5 58 4 5
619 5 109 1 5
683 3 17 1 5
691 5 38 4 5
739 5 26 4 3
787 7 59 9 5
947 3 5 1 5
1051 5 107 1 3
1123 7 239 3 3
1723 11 149 19 3
1747 17 1565 43 5
1867 7 4 6 5
2203 7 255 1 5
2347 17 1810 32 5
2683 11 344 14 5
"""
SIGNS = (1, 1, -1, 1, -1, -1, 1, -1)


def check_densities():
    # A witness for polynomial ratios (Article section 13).
    deficits = {
        0, 1, 4, 5, 11, 13, 14, 16, 20, 30, 37, 38, 41, 42, 48, 50, 51,
        53, 57, 67, 111, 112, 115, 116, 122, 124, 125, 127, 131, 141,
        148, 149, 152, 153, 159, 161, 162, 164, 168, 178, 333, 334, 337,
        338, 344, 346, 347, 349, 353, 363, 370, 371, 374, 375, 381, 383,
        384, 386, 390, 437, 440, 441, 444, 449, 450, 453, 455, 464, 467,
        468, 471, 476, 477, 480,
    }
    assert len(deficits) == 74
    for left, right in combinations(deficits, 2):
        total = left + right
        assert total % 2 or total // 2 not in deficits

    z = Fraction(127, 128)
    greedy = [sum(((bits >> j) & 1) * 3**j for j in range(7)) for bits in range(128)]
    difference = sum(z**b for b in deficits) - sum(z**a for a in greedy)
    # The first omitted number with ternary digits zero or one is 3**7.
    omitted = z**2187 / (1 - z)
    assert difference > Fraction(16, 1000) and omitted < Fraction(1, 100000)
    assert difference - omitted > Fraction(3, 200)
    print("Polynomial witness: 2701 midpoint checks, weighted excess above",
          f"{float(difference - omitted):.10f}")

    # Bounds for the integer construction (Article section 14).
    primes = list(primerange(2, 1428))
    odd_primes = primes[1:]
    product_odd = prod(odd_primes)
    exponents = (2, 5, 11, 14)
    mass = sum(Fraction(1, 2**k) for k in exponents)
    mass_squared_terms = sum(Fraction(1, 2**(2*k)) for k in exponents)
    greedy_bound = prod(1 + Fraction(1, 2**k) for k in (1, 3, 9)) + Fraction(1, 2**26)
    gain = mass - (greedy_bound - 1) + sum(
        mass/p - mass_squared_terms/p**2 - (greedy_bound - mass)/p**3
        for p in odd_primes
    )
    rough_factor = Fraction(1427, 1428) * prod(1 - Fraction(1, p) for p in primes)
    assert len(primes) == 225 and product_odd < 3 * 10**590
    assert gain > Fraction(9, 100000) and rough_factor > Fraction(1, 15)
    assert rough_factor * gain / product_odd > Fraction(1, 10**596)
    print("Integer witness: 225 primes, density gain exceeds 10^(-596)")


def check_quintics():
    x = symbols("x")
    polys = []
    for line in DATA.splitlines():
        if not line:
            continue
        q, p, a, b, v5 = map(int, line.split())
        assert isprime(q) and q % 4 == 3 and isprime(p)
        assert 4 * p**5 == a*a + q*b*b and gcd(p, a) == 1 and (a-b) % 2 == 0
        polynomial = Poly(x**5 - 5*p*x**3 + 5*p*p*x - a, x)
        assert polynomial.is_irreducible
        _, field_discriminant = round_two(polynomial)
        assert field_discriminant == q**2 * 5**v5
        polys.append(polynomial)
    # Maximal real subfield of Q(zeta_11).
    polys.append(Poly(x**5 + x**4 - 4*x**3 - 3*x**2 + 3*x + 1, x))
    assert len(polys) == 26
    need_irreducibility = set(range(len(polys)))
    need_distinction = set(combinations(range(len(polys)), 2))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", SymPyDeprecationWarning)
        for prime in primerange(2, 72):
            patterns = []
            for i, poly in enumerate(polys):
                factors = poly.set_modulus(prime).factor_list()[1]
                if any(exponent > 1 for _, exponent in factors):
                    patterns.append(None)
                    continue
                pattern = tuple(sorted(factor.degree() for factor, _ in factors))
                patterns.append(pattern)
                if pattern == (5,):
                    need_irreducibility.discard(i)
            for i, j in list(need_distinction):
                if patterns[i] and patterns[j] and patterns[i] != patterns[j]:
                    need_distinction.remove((i, j))
    assert not need_irreducibility and not need_distinction
    print("25 norms and field discriminants, 26 irreducibilities, 325 distinct pairs: passed")


def check_cycle():
    cutoff = Fraction(1397, 500)
    initial = (cutoff, Fraction(-1), cutoff)
    words = {(): (initial, initial)}
    for length in range(1, 28):
        surviving = {}
        for word, boundary_states in words.items():
            for sign in (-1, 1):
                new_states = []
                for (a, b, c), t in zip(boundary_states, (sign, -sign)):
                    A, B, C = c-b*b/a, -1+b*t/a, cutoff-1/a
                    if A <= 0 or A*C <= B*B:
                        break
                    new_states.append((A, B, C))
                if len(new_states) == 2:
                    surviving[word + (sign,)] = new_states
        words = surviving
    expected = {tuple(SIGNS[(k+j) % 8] for j in range(27)) for k in range(8)}
    assert set(words) == expected
    x, z = symbols("x z")
    adjacency = zeros(8)
    for i in range(8):
        for offset, weight in [(1, 1), (2, SIGNS[i])]:
            j, wrap = (i+offset) % 8, (i+offset) // 8
            adjacency[i, j] += weight * z**wrap
            adjacency[j, i] += weight * z**(-wrap)
    h, u = x*x-4, z+1/z
    formula = h**4 - (16+2*u)*h**2 + u**2+19*u+38
    assert cancel(adjacency.charpoly(x).as_expr()-formula) == 0
    print("8 surviving length-27 words and signed-cycle Laurent polynomial: passed")


if __name__ == "__main__":
    check_densities()
    check_quintics()
    check_cycle()
