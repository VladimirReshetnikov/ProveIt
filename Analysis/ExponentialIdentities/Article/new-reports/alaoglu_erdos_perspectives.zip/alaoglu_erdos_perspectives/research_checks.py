#!/usr/bin/env python3
"""Reproducible algebraic and analytic checks for the accompanying article.

Dependencies: Python >= 3.9, numpy, sympy, mpmath, matplotlib.
Run: python research_checks.py --out .

The symbolic checks are exact. Floating-point calculations illustrate proved
asymptotics; they are NOT directed-rounding certificates and do not search for
an Alaoglu--Erdos counterexample. In particular beta=sqrt(2) is an analytic
model, not a hypothetical integer-output exponent.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import sympy as sp
import mpmath as mp


def valuation(n: int, p: int) -> int:
    """Return v_p(n) for a positive integer n and prime p."""
    if n < 1 or p < 2:
        raise ValueError('Positive n and p >= 2 required')
    result = 0
    while n % p == 0:
        result += 1
        n //= p
    return result


def prime_quotient(q: int) -> dict:
    """Build the exact consecutive-ratio valuation matrix and its section."""
    primes = list(sp.primerange(2, q + 1))
    r, R = len(primes), q - 1
    V = sp.Matrix([[valuation(n + 1, p) - valuation(n, p)
                    for n in range(1, q)] for p in primes])
    U = sp.Matrix([[int(n < p) for p in primes] for n in range(1, q)])
    assert V * U == sp.eye(r)
    X = sp.symbols(f'x0:{r}')
    star = []
    for j in range(r):
        star.append(sp.expand(-X[1] * X[j]))  # a_j coefficient
    for j in range(r):
        star.append(sp.expand(X[0] * X[j]))   # b_j coefficient
    mons = [X[i] * X[j] for i in range(r) for j in range(i, r)]
    C = sp.Matrix([[sp.Poly(f, *X).coeff_monomial(m) for f in star] for m in mons])
    assert C.rank() == 2 * r - 1
    null = C.nullspace()
    assert len(null) == 1
    control = sp.zeros(2*r, 1)
    control[0], control[r+1] = 1, 1
    assert C * control == sp.zeros(len(mons), 1)
    return {'q': q, 'primes': primes, 'increments': R,
            'quadratic_ambient': R*(R+1)//2,
            'known_quadratic_kernel': R*(R+1)//2-r*(r+1)//2,
            'prime_quadratic_quotient': r*(r+1)//2,
            'star_dimension': 2*r-1,
            'V': [[int(a) for a in V.row(i)] for i in range(r)],
            'U': [[int(a) for a in U.row(i)] for i in range(R)]}


def product_log_bounds(beta: float, radius: float, multiple: float = 10.0) -> dict:
    """Evaluate a finite product plus analytic tail enclosures.

    Bounds derive from c*t^2-1 <= N(t) <= c*(t+1+beta)^2-1.
    These formulas are proved in the article, but their numerical evaluation
    here is ordinary floating point, so the printed intervals are illustrative.
    """
    T = multiple * radius
    total, count = 0.0, 0
    for k in range(int(T / beta) + 1):
        n0 = 1 if k == 0 else 0
        n1 = int(np.floor(T - beta*k))
        s = np.arange(n0, n1+1, dtype=float) + beta*k
        if s.size:
            total += float(np.log1p((radius/s)**4).sum())
            count += int(s.size)
    c, B = 1/(2*beta), 1+beta
    fT = np.log1p((radius/T)**4)
    J2 = 2*radius**2*np.arctan(radius**2/T**2)
    mp.mp.dps = 40
    J1 = float(4*radius*mp.quad(lambda u: 1/(1+u**4), [T/radius, mp.inf]))
    low_tail = c*J2 - (count+1)*fT
    high_tail = c*J2 + 2*c*B*J1 + (c*B**2 - 1 - count)*fT
    low, high = np.log(radius)+total+low_tail, np.log(radius)+total+high_tail
    scale = np.pi*c*radius**2
    return {'r': radius, 'T': T, 'nodes': count,
            'logM_lower_illustration': float(low), 'logM_upper_illustration': float(high),
            'normalized_lower': float(low/scale), 'normalized_upper': float(high/scale),
            'two_term_prediction': float(1+np.sqrt(2)*(1+beta)/radius)}


def fock_prefix_energies(beta: mp.mpf, tau: mp.mpf, count: int = 10) -> list:
    """Small high-precision example of the exact minimum-norm formula.

    Values are rounded samples of exp(sigma*s^2), not claimed to remain feasible
    with uniformly bounded energies. The demonstration intentionally has no
    interpretation as evidence of a counterexample or of the open target.
    """
    mp.mp.dps = 100
    nodes = sorted([mp.mpf(n)+beta*k for n in range(count) for k in range(count)])[:count]
    sigma = tau/3
    values = [int(mp.nint(mp.exp(sigma*s*s))) for s in nodes]
    rows = []
    previous = mp.mpf(0)
    for N in range(1, count+1):
        ss = nodes[:N]
        K = mp.matrix([[mp.exp(-tau*(x-y)**2) for y in ss] for x in ss])
        w = mp.matrix([mp.exp(-tau*x*x)*values[i] for i,x in enumerate(ss)])
        # Cholesky solution avoids explicitly forming an inverse.
        solved = mp.cholesky_solve(K, w)
        energy = (w.T*solved)[0]
        assert energy >= previous-mp.mpf('1e-60')
        previous = energy
        rows.append({'N': N, 'energy': mp.nstr(energy, 24), 'last_value': values[N-1]})
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path('.'))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out/'figures').mkdir(exist_ok=True)
    exact = [prime_quotient(q) for q in (5,7,11,13)]
    # L3 = L1-L2: exact valuation identity, with columns indexed from zero.
    V5 = sp.Matrix(exact[0]['V'])
    assert V5[:,2] == V5[:,0]-V5[:,1]
    # Verify the rank-three coefficient determinant without floating point.
    rr, vv, hh, ww, tt = sp.symbols('r v h w t')
    B = sp.Matrix([[rr, hh/2, tt/2], [hh/2, -vv, -ww/2], [tt/2, -ww/2, 0]])
    assert sp.expand(4*B.det() + rr*ww**2 + hh*ww*tt - vv*tt**2) == 0
    beta = float(np.sqrt(2))
    rows = [product_log_bounds(beta, float(r)) for r in (10,20,40,80,160)]
    mp.mp.dps = 100
    fock = fock_prefix_energies(mp.sqrt(2), mp.mpf('0.1'))
    ratio = 416*mp.pi*mp.log(2)*mp.log(3)
    result = {'status': 'Exact algebra; illustrative non-directed floating-point analysis.',
              'prime_quotient': exact, 'ternary_determinant_exact_check': True,
              'product_beta': beta, 'product': rows,
              'type_ratio_per_beta': mp.nstr(ratio, 30),
              'fock_model_beta': 'sqrt(2)', 'fock_model_tau': '0.1', 'fock_prefix_energies': fock}
    (args.out/'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7.1,4.2))
    rr = np.array([r['r'] for r in rows])
    lower = np.array([r['normalized_lower'] for r in rows])
    upper = np.array([r['normalized_upper'] for r in rows])
    mid = (lower+upper)/2
    ax.errorbar(1/rr, mid, yerr=(upper-lower)/2, fmt='o', capsize=4,
                label='Finite product + tail bounds')
    grid = np.linspace(0, 0.105, 150)
    ax.plot(grid, 1+np.sqrt(2)*(1+beta)*grid, '--', label='Two-term asymptotic')
    ax.set_xlabel(r'$1/r$')
    ax.set_ylabel(r'$2\beta\log M(C_\beta,r)/(\pi r^2)$')
    ax.set_title(r'Four-ray product: $\beta=\sqrt{2}$ (analytic model)')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(args.out/'figures'/'product_convergence.pdf')
    fig.savefig(args.out/'figures'/'product_convergence.png', dpi=180)
    plt.close(fig)
    print(json.dumps({'type_ratio_per_beta':result['type_ratio_per_beta'],
                      'product': rows, 'fock': fock}, indent=2))

if __name__ == '__main__':
    main()
