// Exact dyadic-interval verification of the (2,3) integer-output conjecture.
// Build: g++ -O3 -std=c++17 verify_integer_outputs.cpp -o verify_integer_outputs
// Run:   ./verify_integer_outputs 1000000
// Floating point only proposes a bracket. Every accepted bracket is certified
// by integer arithmetic. No floating-point value enters a proof inequality.
#include <boost/multiprecision/cpp_int.hpp>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
using boost::multiprecision::uint256_t;
using U = uint256_t;
constexpr unsigned PREC=112, TERMS=36;
const U S=U(1)<<PREC;
struct Interval { U lo, hi; };
U ceildiv(U a,U b) { return (a+b-1)/b; }
Interval atanh_twice(std::uint64_t a,std::uint64_t b) {
    // 0 <= a/b <= 1/3. Returned endpoints bound S*2*atanh(a/b).
    if (3*a>b) throw std::runtime_error("range reduction failed");
    U zl=(S*a)/b, zh=ceildiv(S*a,b);
    U wl=(zl*zl)>>PREC, wh=ceildiv(zh*zh,S);
    U tl=zl, th=zh, sl=0, sh=0;
    for(unsigned j=0;j<TERMS;++j) {
        unsigned d=2*j+1;
        sl+=tl/d; sh+=ceildiv(th,d);
        if(j+1<TERMS) {tl=(tl*wl)>>PREC; th=ceildiv(th*wh,S);}
    }
    // 2 sum_{j>=N} z^(2j+1)/(2j+1)
    // <= 9/[4(2N+1)3^(2N+1)] for 0<=z<=1/3.
    U power=1; for(unsigned j=0;j<2*TERMS+1;++j) power*=3;
    U tail=ceildiv(9*S, U(4)*(2*TERMS+1)*power);
    return {2*sl, 2*sh+tail};
}
const Interval LOG2=atanh_twice(1,3);
Interval log_bounds(std::uint64_t n) {
    if(!n) throw std::runtime_error("logarithm of zero");
    unsigned e=63-__builtin_clzll(n);
    std::uint64_t b=std::uint64_t(1)<<e;
    auto v=atanh_twice(n-b,n+b);
    return {v.lo+e*LOG2.lo, v.hi+e*LOG2.hi};
}
Interval multiply(Interval a,Interval b) {return {a.lo*b.lo,a.hi*b.hi};}
struct Minimum { bool set=false; U lo=0,hi=0; std::uint64_t m=0,n=0; };
void consider(Minimum& best,Interval a,std::uint64_t m,std::uint64_t n) {
    if(a.lo==0) throw std::runtime_error("uncertified strict gap");
    // min of lower bounds and min of upper bounds encloses the global
    // minimum, even when equal gaps recur under (m,n) -> (2m,3n).
    if(!best.set) {best={true,a.lo,a.hi,m,n}; return;}
    if(a.lo<best.lo) best.lo=a.lo;
    if(a.hi<best.hi) {best.hi=a.hi;best.m=m;best.n=n;}

}
int main(int argc,char**argv) {
  try {
    std::uint64_t limit=argc>1?std::stoull(argv[1]):1000000;
    if(limit<2 || limit>100000000) throw std::runtime_error("limit must lie in [2,100000000]");
    const auto log3=log_bounds(3);
    std::uint64_t certified=0,exact=0,adjustments=0;
    Minimum best;
    for(std::uint64_t m=1;m<=limit;++m) {
      if((m&(m-1))==0) {++exact;continue;}
      auto target=multiply(log_bounds(m),log3);
      // Merely a proposed floor of m^(log(3)/log(2)).
      double proposal=std::exp(std::log(double(m))*std::log(3.0)/std::log(2.0));
      if(!std::isfinite(proposal) || proposal<1 || proposal>double(m*m))
          throw std::runtime_error("floating-point proposal outside safe range");
      std::uint64_t k=static_cast<std::uint64_t>(proposal);
      if(k<1) k=1;
      bool done=false;
      for(int tries=0;tries<10;++tries) {
        auto below=multiply(log_bounds(k),LOG2);
        auto above=multiply(log_bounds(k+1),LOG2);
        if(below.hi<target.lo && target.hi<above.lo) {
           consider(best,{target.lo-below.hi,target.hi-below.lo},m,k);
           consider(best,{above.lo-target.hi,above.hi-target.lo},m,k+1);
           ++certified;done=true;break;
        }
        if(target.hi<below.lo && k>1) {--k;++adjustments;continue;}
        if(above.hi<target.lo) {++k;++adjustments;continue;}
        throw std::runtime_error("unresolved logarithmic comparison at m="+std::to_string(m));
      }
      if(!done) throw std::runtime_error("bracket proposal failed");
    }
    std::cout << "limit="<<limit<<"\nprecision_bits="<<PREC<<"\natanh_terms="<<TERMS
      <<"\nstrictly_certified_nonpowers="<<certified<<"\nexact_powers_of_two="<<exact
      <<"\nbracket_adjustments="<<adjustments
      <<"\nsmallest_upper_bound_m="<<best.m<<"\nsmallest_upper_bound_n="<<best.n
      <<"\nminimum_gap_lower_numerator="<<best.lo
      <<"\nminimum_gap_upper_numerator="<<best.hi
      <<"\nminimum_gap_denominator=2^"<<2*PREC<<"\nPASS\n";
    return 0;
  } catch(const std::exception&e) {std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}
}
