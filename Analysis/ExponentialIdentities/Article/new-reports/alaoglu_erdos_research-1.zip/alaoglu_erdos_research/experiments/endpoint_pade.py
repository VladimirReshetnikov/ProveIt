#!/usr/bin/env python3
"""Exact endpoint-constrained Hermite-Pade prototype (SymPy required).

This tests rational input quadruples; it does not instantiate a conjectural
Alaoglu-Erdos counterexample. The analytic upper bound is a rational number.
Usage: python endpoint_pade.py --degree 1 --denominator 1000
"""
from __future__ import annotations
import argparse
from functools import reduce
from math import gcd
import sympy as sp

def construct(u: list[sp.Rational], n: int, common=sp.Integer(0)):
    if len(u) != 4 or any(abs(t)>=1 or t==common for t in u) or abs(common)>=1 or n < 1:
        raise ValueError('Invalid logarithmic parameters or degree.')
    N = 7*n+1
    fs = [[sp.Integer(k == 0) for k in range(N)]]
    fs += [[sp.Integer(0)] + [-(t**k-common**k)/sp.Integer(k) for k in range(1,N)] for t in u]
    for i,j in [(1,4),(2,3)]:
        fs.append([sum((fs[i][k]*fs[j][m-k] for k in range(m+1)),sp.Integer(0)) for m in range(N)])
    cols = [(i,j) for i in range(7) for j in range(n+1)]
    rows = [[fs[i][k-j] if k>=j else sp.Integer(0) for i,j in cols] for k in range(N)]
    for a in range(1,5): rows.append([sp.Integer(i==a) for i,j in cols])
    rows.append([sp.Integer(i in (5,6)) for i,j in cols])
    mat = sp.Matrix(rows)
    basis = mat.nullspace()
    chosen = next((v for v in basis if sum(v[:n+1]) != 0),None)
    if chosen is None:
        return N,mat,basis,None
    den = sp.ilcm(*[t.q for t in chosen])
    iv = [int(t*den) for t in chosen]
    common = reduce(gcd,iv)
    iv = [t//common for t in iv]
    if sum(iv[:n+1]) < 0: iv = [-t for t in iv]
    assert mat*sp.Matrix(iv) == sp.zeros(mat.rows,1)
    pol = [iv[i*(n+1):(i+1)*(n+1)] for i in range(7)]
    return N,mat,basis,pol

def bound(u, pol, N, R, common=sp.Integer(0)):
    n=len(pol[0])-1
    if not 1 < R < 1/max([abs(t) for t in u]+[abs(common)]):
        raise ValueError('R is outside the analytic disk.')
    # |log(1-u*z)| <= -log(1-u*R) <= u*R/(1-u*R).
    K=[abs(t)*R/(1-abs(t)*R)+abs(common)*R/(1-abs(common)*R) for t in u]
    H=[sum(abs(c) for c in row) for row in pol]
    return sp.factor(R**(n-N)*(H[0]+sum(H[i+1]*K[i] for i in range(4))+H[5]*K[0]*K[3]+H[6]*K[1]*K[2]))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--degree',type=int,default=1)
    ap.add_argument('--denominator',type=int,default=1000)
    ap.add_argument('--bases',nargs=4,help='Four rational bases > 1, e.g. 2 3 5 7')
    ap.add_argument('--mobius',action='store_true',help='Use a rational, endpoint-preserving range reduction.')
    args=ap.parse_args()
    D=args.denominator
    if D<=12: raise ValueError('denominator must exceed 12')
    if args.bases:
        bases=[sp.Rational(t) for t in args.bases]
        if any(t<=1 for t in bases): raise ValueError('Bases must exceed 1.')
        u=[1-1/t for t in bases]
    else:
        u=[sp.Rational(a,D) for a in (1,2,3,6)]
        bases=[1/(1-t) for t in u]
    common=sp.Integer(0)
    if args.mobius:
        c=2*max(bases)/(max(bases)+1)
        u=[1-c/t for t in bases]
        common=1-c
    N,mat,basis,pol=construct(u,args.degree,common)
    print('CONTROL INPUT, NOT AN ALAOGLU-ERDOS CANDIDATE')
    print('bases =',bases)
    print('u =',u,'; common =',common,'; n =',args.degree,'; N =',N)
    print('matrix_shape =',mat.shape,'; nullity =',len(basis))
    if pol is None:
        print('No vector with P0(1) != 0 found. No certificate.');return
    for i,cs in enumerate(pol): print(f'P{i}_coefficients_ascending = {cs}')
    s=max([abs(t) for t in u]+[abs(common)])
    R=1/(2*s)
    if R<=1: R=(1+1/s)/2
    B=bound(u,pol,N,R,common)
    print('P0(1) =',sum(pol[0]),'; R =',R)
    print('rational_upper_bound =',B)
    print('upper_bound_decimal =',sp.N(B,15))
    relative=sp.factor(B/abs(sum(pol[0])))
    print('relative_upper_bound =',relative)
    print('relative_upper_bound_decimal =',sp.N(relative,15))
    print('PROVED: log(r1)*log(r4)-log(r2)*log(r3) != 0' if relative<1 else 'BOUND DOES NOT CLOSE')
    print('All Taylor and endpoint constraints checked exactly.')
if __name__=='__main__': main()
