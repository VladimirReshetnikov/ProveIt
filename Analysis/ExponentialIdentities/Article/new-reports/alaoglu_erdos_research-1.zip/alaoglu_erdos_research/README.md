# The Alaoglu–Erdős Integer-Exponent Problem
## Valuation geometry, sharp interpolation, and endpoint-constrained Padé methods

Research continuation prepared for Vladimir Reshetnikov, 4 September 2026.

## Contents

- `alaoglu_erdos_research.pdf`: the 27-page article (including front matter).
- `alaoglu_erdos_research.tex`: self-contained LaTeX source with its bibliography.
- `experiments/verify_integer_outputs.cpp`: exact dyadic-interval verifier for the
  integer-output problem for the prime pair (2,3).
- `experiments/verification_10000.txt` and `verification_1000000.txt`: executed
  verification results.
- `experiments/endpoint_pade.py`: exact rational linear-algebra prototype for the
  endpoint-constrained seven-function Padé certificate.
- `experiments/endpoint_pade_controls.txt`: seven executed control experiments,
  including coefficient vectors and exact upper bounds.
- `SHA256SUMS.txt`: checksums for the other files in this package.

## Scope and status

This article is not a proof of the full Alaoglu–Erdős conjecture. It distinguishes
rational outputs from integer outputs, establishes structural implications,
and gives explicit auxiliary constructions and their remaining proof obligations.

The principal developments are the valuation-sign classification and its
mixed-witness consequence, the incompatibility between a two-prime switching
collision and an integer-output exception, quantitative localization/height
estimates, balanced positive interpolation, and an endpoint-constrained Padé
nonvanishing certificate. The exact sparse Newton-polygon threshold is credited
to the linked report rather than presented as a new result.

The control experiments demonstrate successful certificates for rational bases
very close to one and failure of the present bounds in other regimes. They do
not establish that the Padé construction succeeds for every hypothetical
counterexample. No claim of priority or independently checked Lean formalization
is made. Source citations and the exact unproved bridge statements appear in
the article.

## Build the article

A sufficiently complete TeX Live installation with pdfLaTeX is required. The
source uses standard mathematical packages and New PX text/math fonts; no
external figures, BibTeX database, or shell escape are needed.

Run from this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error alaoglu_erdos_research.tex
pdflatex -interaction=nonstopmode -halt-on-error alaoglu_erdos_research.tex
```

The supplied PDF was compiled with pdfTeX 1.40.26. Different TeX distributions
may change pagination slightly. PDF metadata and timestamps mean a rebuilt PDF
need not be byte-for-byte identical.

## Reproduce the finite verification

Requirements: a C++17 compiler and the Boost.Multiprecision header library.
No external numeric library needs to be linked.

```sh
cd experiments
g++ -O3 -std=c++17 verify_integer_outputs.cpp -o verify_integer_outputs
./verify_integer_outputs 10000
./verify_integer_outputs 1000000
```

For the second run the recorded outcome is:

```text
strictly_certified_nonpowers=999980
exact_powers_of_two=20
PASS
```

The certificate covers every positive integer first coordinate m <= 1,000,000.
For each non-power of two it proves, by strict integer-arithmetic interval
comparisons, that m^(log(3)/log(2)) lies between consecutive integers. Powers of
two give the expected integer-exponent solutions. This is a bounded verification,
not an assertion about larger first coordinates.

Floating-point arithmetic only proposes a bracket. Every accepted bracket is
independently checked by exact arithmetic; an unresolved comparison causes a
nonzero exit status. The number of bracket adjustments can depend on the
platform's floating-point library without affecting the exact acceptance test.
The implementation enforces an input range compatible with its 256-bit arithmetic.
It is executable research code, not a kernel-checked proof object.

## Reproduce the endpoint Padé controls

The script was tested with Python 3.13.5 and SymPy 1.14.0. It does not require
floating-point decisions for certification. From `experiments/`:

```sh
python endpoint_pade.py --degree 1 --denominator 1000
python endpoint_pade.py --degree 2 --denominator 1000
python endpoint_pade.py --degree 3 --denominator 1000
python endpoint_pade.py --degree 1 --bases 2 3 5 7
python endpoint_pade.py --degree 1 --bases 2 3 5 7 --mobius
python endpoint_pade.py --degree 2 --bases 2 3 5 7 --mobius
python endpoint_pade.py --degree 1 --bases 2 3 4 9
```

Exact nullspace computations can become expensive as the degree increases. Each
reported vector is checked against all rational Taylor and endpoint constraints.
The scale-invariant certificate compares B/|P0(1)| with 1 as an exact rational
number. A decimal rendering is printed only for readability.

The first three controls give normalized bounds approximately 9.65e-7,
2.94e-18, and 1.06e-29. The four remaining controls report `BOUND DOES NOT CLOSE`.
This message is not a claim that the logarithm determinant vanishes. In the
last control it does vanish for the elementary reason 4=2^2 and 9=3^2, so a
nonvanishing certificate must not succeed.

## Source report

The article continues the user's public report at:

https://github.com/VladimirReshetnikov/ProveIt/tree/main/Analysis/ExponentialIdentities/Article/alaoglu-erdos-unified-report

Its live main source was consulted on 4 September 2026. External articles and
the source report are cited, not redistributed in this archive.
