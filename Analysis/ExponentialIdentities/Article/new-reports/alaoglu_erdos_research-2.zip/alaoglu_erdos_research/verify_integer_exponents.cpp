// Exact, outward-rounded verification for the pair (2,3).
// The floating-point estimate chooses a candidate interval only; it never
// decides a mathematical assertion. Every accepted interval is certified
// using integer bounds for logarithms and 256-bit integer comparisons.
// Requires C++17, GCC/Clang (__int128), and Boost.Multiprecision headers.
#include <boost/multiprecision/cpp_int.hpp>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
using u128 = unsigned __int128;
using u256 = boost::multiprecision::uint256_t;
using Big = boost::multiprecision::cpp_int;
constexpr unsigned PREC = 80, TERMS = 32;
constexpr u128 SCALE = u128(1) << PREC;
struct Interval { u128 lo, hi; };
static Interval LOG2, LOG3;
static u128 ceil_div(u128 x, uint64_t d) { return x/d + (x%d != 0); }
static Interval reduced_log(uint64_t a, uint64_t b) {
    // 0 <= a/b <= 1/3; return enclosure of 2*atanh(a/b), scaled by 2^80.
    if (a == 0) return {0,0};
    if (a > b/3) throw std::runtime_error("reduction invariant failed");
    u128 low = SCALE*a/b, high = ceil_div(SCALE*a,b);
    u128 sumlo=0, sumhi=0;
    for (unsigned j=0;j<TERMS;++j) {
        const uint64_t d=2*j+1;
        sumlo += (2*low)/d;
        sumhi += ceil_div(2*high,d);
        if (j+1<TERMS) for (unsigned r=0;r<2;++r) {
            low=low*a/b;
            high=ceil_div(high*a,b);
        }
    }
    return {sumlo, sumhi+1}; // exact uniform tail bound is less than one unit
}
static Interval log_integer(uint64_t n) {
    if (n==0 || n >= (uint64_t(1)<<33))
        throw std::runtime_error("log_integer input outside proved range");
    unsigned e=63-__builtin_clzll(n);
    uint64_t d=uint64_t(1)<<e;
    Interval r=reduced_log(n-d,n+d);
    return {e*LOG2.lo+r.lo,e*LOG2.hi+r.hi};
}
static bool is_power_two(uint64_t n) { return n && !(n&(n-1)); }
static bool bracket(const Interval& lm,uint64_t n,u256& margin) {
    if (!n || n+1 >= (uint64_t(1)<<33)) return false;
    Interval ln=log_integer(n), ln1=log_integer(n+1);
    u256 alo=u256(lm.lo)*u256(LOG3.lo), ahi=u256(lm.hi)*u256(LOG3.hi);
    u256 blo=u256(ln1.lo)*u256(LOG2.lo), bhi=u256(ln.hi)*u256(LOG2.hi);
    if (!(alo>bhi && blo>ahi)) return false;
    margin=std::min(alo-bhi,blo-ahi);
    return true;
}
struct Block { uint64_t count=0, argm=0, argn=0; u256 margin=0; };
int main(int argc,char**argv) {
    try {
        unsigned exponent=20;
        if (argc>1) { unsigned long val=std::stoul(argv[1]);
            if (val<1 || val>20) throw std::runtime_error("exponent must be 1..20");
            exponent=static_cast<unsigned>(val); }
        Big pow3=1; for (unsigned j=0;j<2*TERMS+1;++j) pow3*=3;
        if (!(Big(9)*(Big(1)<<PREC) < Big(4)*(2*TERMS+1)*pow3))
            throw std::runtime_error("Taylor remainder bound failed");
        LOG2=reduced_log(1,3); LOG3=log_integer(3);
        const uint64_t bound=uint64_t(1)<<exponent;
        const long double theta=std::log((long double)3)/std::log((long double)2);
        std::vector<Block> blocks(exponent);
        uint64_t checked=0,powers=0,adjustments=0;
        for(uint64_t m=1;m<bound;++m) {
            if(is_power_two(m)) { ++powers; continue; }
            Interval lm=log_integer(m);
            long double hint=std::pow((long double)m,theta);
            if(!std::isfinite(hint) || hint<1 || hint >= (uint64_t(1)<<33)-2)
                throw std::runtime_error("floating-point hint out of range");
            uint64_t n=static_cast<uint64_t>(std::floor(hint));
            u256 gap;
            bool ok=bracket(lm,n,gap);
            if(!ok) {
                const uint64_t orig=n;
                for(int offset : {-1,1,-2,2}) {
                    if(int64_t(orig)+offset<1) continue;
                    n=uint64_t(int64_t(orig)+offset);
                    if(bracket(lm,n,gap)) { ok=true; ++adjustments; break; }
                }
            }
            if(!ok) {
                std::cerr<<"UNRESOLVED m="<<m<<"; no conclusion for full range.\n";
                return 2;
            }
            unsigned e=63-__builtin_clzll(m);
            Block& b=blocks[e];
            if(!b.count || gap<b.margin) { b.margin=gap;b.argm=m;b.argn=n; }
            ++b.count; ++checked;
        }
        if(checked+powers != bound-1 || powers != exponent)
            throw std::runtime_error("coverage invariant failed");
        std::cout<<"CERTIFIED: pair (2,3), 1 <= m < 2^"<<exponent<<"\n";
        std::cout<<"Fixed precision: "<<PREC<<" bits; Taylor terms: "<<TERMS<<"\n";
        std::cout<<"Nonpower bases certified: "<<checked<<"\n";
        std::cout<<"Power-of-two bases handled symbolically: "<<powers<<"\n";
        std::cout<<"Floating-point hint corrections: "<<adjustments<<"\n";
        std::cout<<"Each margin below is an exact positive integer, scaled by 2^160.\n";
        std::cout<<"e,count,argmin_m,bracketing_n,minimum_interval_margin\n";
        for(unsigned e=0;e<exponent;++e) {
            const auto& b=blocks[e];
            std::cout<<e<<','<<b.count<<','<<b.argm<<','<<b.argn<<','<<b.margin<<'\n';
        }
        std::cout<<"Endpoint m=2^"<<exponent<<" is symbolic: n=3^"<<exponent<<".\n";
        std::cout<<"CONCLUSION: 2^x,3^x positive integers and 0 <= x <= "
                 <<exponent<<" imply x is an integer.\n";
        return 0;
    } catch(const std::exception& e) { std::cerr<<"ERROR: "<<e.what()<<'\n';return 1; }
}
