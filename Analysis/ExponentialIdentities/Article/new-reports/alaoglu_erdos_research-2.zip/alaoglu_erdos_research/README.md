# The Alaoglu–Erdős Integer Exponent Conjecture
## Saturation, valuation polarity, and quantitative routes toward a proof

Research article prepared for Vladimir Reshetnikov, dated 4 September 2026.

## Article

- `alaoglu_erdos_research.pdf`: compiled 25-page article, with linked contents and references.
- `alaoglu_erdos_research.tex`: complete LaTeX source, including its bibliography. No external figure or bibliography files are required.

The article develops an explicit rational-exponent saturation theorem, a valuation-sign classification of the integer and localized output sets, a conditional consequence for colossally abundant transition collisions, exact height formulae and counting criteria, and concrete sparse-polynomial and adelic-determinant research targets. It does not claim a complete proof of the conjecture or a global novelty claim. Standard transcendence theorems used as inputs are explicitly cited. The supplied repository's Lean development was not independently rebuilt.

## Exhaustive finite verification

`verify_integer_exponents.cpp` checks the pair (2,3). Its executed range is every integer base `1 <= m < 2^20`. It certifies that `m^(log(3)/log(2))` lies strictly between two integers for all 1,048,555 non-power-of-two bases. The 20 powers of two in this half-open range and the endpoint `m=2^20` are handled symbolically. The resulting statement is:

    If 2^t and 3^t are positive integers and 0 <= t <= 20, then t is an integer.

The proof comparisons use exact outward-rounded integer bounds for logarithms, at scale 2^80 with 32 Taylor terms. Floating point supplies a trial bracket only. An uncertified bracket is never accepted. The exact tail estimate, rounding rules, coverage, and arithmetic-type bounds are explained in Section 11 of the article.

Requirements: GCC or Clang with C++17 and `unsigned __int128`, plus Boost.Multiprecision headers.

```sh
g++ -O3 -std=c++17 -Wall -Wextra verify_integer_exponents.cpp -o verify
./verify 20
```

The optional exponent argument must be in 1..20. The executed output is in `verification_output.txt`. Each block's minimum margin is an exact integer in units of 2^-160; it is not a distance in the original power-curve coordinates. This is a computer-assisted finite verification, not a Lean/kernel-checked certificate, and no computational-record claim is made.

## Independent sample cross-check

`crosscheck.py` uses Python's exact `Fraction` arithmetic, with a direct rational Taylor sum and rational geometric remainder. It checks 641 nonpower sample bases, including every block-margin minimizer, all nonpowers through 512, and an additional reproducible sample. It also cross-checks the fixed-point enclosures. Nine sample powers of two are handled symbolically.

Requirements: Python 3.9 or later; standard library only.

```sh
python3 crosscheck.py
```

Keep `verification_output.txt` beside the script. Its executed output is in `crosscheck_output.txt`. This sample check is not a second exhaustive verification of the full range.

## Rebuilding the PDF

Requirements: TeX Live (or equivalent), pdfLaTeX, latexmk, and the standard packages used in the source, including New TX, microtype, tcolorbox, hyperref, and cleveref.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error alaoglu_erdos_research.tex
```

Alternatively, use `make article`, `make check`, and `make crosscheck`. The PDF was compiled successfully with no unresolved references or box warnings, rendered, and visually inspected. Font files are not distributed; the PDF embeds the fonts needed to display the document.

## Integrity

`SHA256SUMS` records the checksums of the other distributed files. On systems with the corresponding utility, run:

```sh
sha256sum -c SHA256SUMS
```
