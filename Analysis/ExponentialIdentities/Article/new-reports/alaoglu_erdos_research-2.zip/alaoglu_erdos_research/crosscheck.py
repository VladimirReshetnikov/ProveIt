#!/usr/bin/env python3
"""Independent sample cross-check using exact fractions, not floating logs.

Default sample: m=2..512, all block-margin minimizers from the C++ run,
and 128 reproducibly sampled bases. This is not a second full-range proof.
The C++ verifier supplies the exhaustive check. Python 3 standard library only.
"""
from fractions import Fraction as F
from pathlib import Path
import random
import math

K = 32
S = 1 << 80

def reduced_log(a: int, b: int) -> tuple[F, F]:
    if not 0 <= 3*a <= b:
        raise ValueError('invalid reduction')
    z = F(a, b)
    partial = sum((2*z**(2*j+1)/F(2*j+1) for j in range(K)), F(0))
    tail = 2*z**(2*K+1)/(F(2*K+1)*(1-z*z))
    return partial, partial + tail

L2 = reduced_log(1, 3)

def log_interval(n: int) -> tuple[F, F]:
    if n < 1:
        raise ValueError('positive integer required')
    e = n.bit_length()-1
    d = 1 << e
    lo, hi = reduced_log(n-d, n+d)
    return lo+e*L2[0], hi+e*L2[1]

L3 = log_interval(3)

def fixed_reduced(a: int, b: int) -> tuple[int, int]:
    # Separate emulation of the C++ recurrence, for enclosure cross-checking.
    if a == 0:
        return 0, 0
    low, high = S*a//b, (S*a+b-1)//b
    sl = sh = 0
    for j in range(K):
        d = 2*j+1
        sl += 2*low//d
        sh += (2*high+d-1)//d
        if j+1 < K:
            for _ in range(2):
                low = low*a//b
                high = (high*a+b-1)//b
    return sl, sh+1

F2 = fixed_reduced(1, 3)

def fixed_interval(n: int) -> tuple[int, int]:
    e = n.bit_length()-1
    d = 1 << e
    lo, hi = fixed_reduced(n-d, n+d)
    return lo+e*F2[0], hi+e*F2[1]

def certify(m: int, n: int) -> bool:
    lm, ln, ln1 = log_interval(m), log_interval(n), log_interval(n+1)
    for integer, reference in ((m,lm),(n,ln),(n+1,ln1)):
        flo, fhi = fixed_interval(integer)
        assert F(flo,S) <= reference[0] <= reference[1] <= F(fhi,S)
    return ln[1]*L2[1] < lm[0]*L3[0] and lm[1]*L3[1] < ln1[0]*L2[0]

def main() -> None:
    samples = set(range(2,513))
    report = Path(__file__).with_name('verification_output.txt')
    for line in report.read_text().splitlines():
        fields = line.split(',')
        if len(fields) == 5 and fields[0].isdigit() and int(fields[1]):
            samples.add(int(fields[2]))
    rng = random.Random(20260904)
    samples.update(rng.randrange(2,1<<20) for _ in range(128))
    checked = powers = 0
    for m in sorted(samples):
        if m & (m-1) == 0:
            powers += 1
            continue
        n0 = math.floor(m**(math.log(3)/math.log(2)))
        if not any(n0+d > 0 and certify(m,n0+d) for d in (0,-1,1)):
            raise ArithmeticError(f'Unresolved sample m={m}')
        checked += 1
    assert F(9,4*(2*K+1)*3**(2*K+1)) < F(1,S)
    print(f'PASS: exact-Fraction brackets for {checked} nonpower sample bases.')
    print(f'Symbolically handled sample powers of two: {powers}.')
    print('PASS: fixed-point logarithm enclosures contain the rational-series enclosures.')
    print('PASS: uniform Taylor tail < 2^-80.')
    print('This sample cross-check is not a second exhaustive verification.')

if __name__ == '__main__':
    main()
