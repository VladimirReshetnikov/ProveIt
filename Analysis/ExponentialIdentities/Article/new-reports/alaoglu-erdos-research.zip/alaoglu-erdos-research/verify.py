"""Independent arbitrary-integer check of the interval method and selected cases.
Python 3.9+, standard library only. Run `python verify.py --limit 65536`.
Use --limit 16777216 for a much slower independent full-range replay.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
from decimal import Decimal, localcontext
from functools import lru_cache
import math

BITS = 128
SCALE = 1 << BITS
TERMS = 48

def reduced_log(numerator: int, denominator: int) -> tuple[int, int]:
    """Enclose 2*atanh(numerator/denominator), in units 2^-128."""
    if not (0 <= 3 * numerator <= denominator):
        raise ValueError("reduced argument must lie in [0, 1/3]")
    lo = SCALE * numerator // denominator
    hi = lo + 1
    square_lo = lo * lo // SCALE
    square_hi = (hi * hi + SCALE - 1) // SCALE
    power_lo, power_hi = lo, hi
    total_lo = total_hi = 0
    for odd in range(1, 2 * TERMS, 2):
        total_lo += power_lo // odd
        total_hi += (power_hi + odd - 1) // odd
        power_lo = power_lo * square_lo // SCALE
        power_hi = (power_hi * square_hi + SCALE - 1) // SCALE
    # The omitted tail is below one unit. Verify this by rational arithmetic.
    return 2 * total_lo, 2 * total_hi + 1

LOG2 = reduced_log(1, 3)

@lru_cache(maxsize=2048)
def log_interval(n: int) -> tuple[int, int]:
    if n < 1:
        raise ValueError("logarithm argument must be positive")
    k = n.bit_length() - 1
    two_k = 1 << k
    lo, hi = reduced_log(n - two_k, n + two_k)
    return k * LOG2[0] + lo, k * LOG2[1] + hi

LOG3 = log_interval(3)

def certificate(m: int, n: int) -> tuple[int, int]:
    lm, ln, lnp = log_interval(m), log_interval(n), log_interval(n + 1)
    left = lm[0] * LOG3[0] - ln[1] * LOG2[1]
    right = lnp[0] * LOG2[0] - lm[1] * LOG3[1]
    return left, right

def check(m: int) -> int:
    proposal = int(math.exp(math.log(m) * math.log(3) / math.log(2)))
    for n in range(max(1, proposal - 2), proposal + 3):
        left, right = certificate(m, n)
        if left > 0 and right > 0:
            return n
    raise ArithmeticError(f"unresolved interval for m={m}")

def exact_fraction_log(n: int, terms: int = 64) -> tuple[Fraction, Fraction]:
    """A second interval construction, with exact fractions and no fixed point."""
    k = n.bit_length() - 1
    def atanh_log(z: Fraction) -> tuple[Fraction, Fraction]:
        total = 2 * sum((z ** (2*j + 1) / (2*j + 1)
                         for j in range(terms)), Fraction(0))
        tail = 2 * z ** (2*terms + 1) / ((2*terms + 1) * (1 - z*z))
        return total, total + tail
    a, b = atanh_log(Fraction(1, 3))
    c, d = atanh_log(Fraction(n - (1 << k), n + (1 << k)))
    return k*a+c, k*b+d

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=65536)
    args = ap.parse_args()
    if not 4 <= args.limit <= 16777216:
        ap.error("limit must be in 4..16777216")
    tail = Fraction(2, 1) * Fraction(1, 3)**(2*TERMS+1) / (
        (2*TERMS+1) * (1-Fraction(1, 9)))
    assert tail < Fraction(1, SCALE)
    count = 0
    for m in range(2, args.limit):
        if m & (m - 1):
            check(m)
            count += 1
    print(f"independent_range_exclusive={args.limit}")
    print(f"independently_checked_nonpowers={count}")
    for m in (189427, 958460, 3506622, 7126099, 16777215):
        print(f"selected_pair={m},{check(m)}")
    m, n = 7126099, 72696450718
    lm, ln = exact_fraction_log(m), exact_fraction_log(n)
    l2, l3 = exact_fraction_log(2), exact_fraction_log(3)
    low = lm[0]*l3[0] - ln[1]*l2[1]
    high = lm[1]*l3[1] - ln[0]*l2[0]
    assert low > 0
    print("near_miss_exact_fraction_positive=True")
    print(f"near_miss_fraction_interval_float={float(low):.17e},{float(high):.17e}")
    # Decimal conversion is only for presentation; the positivity test above is exact.
    with localcontext() as ctx:
        ctx.prec = 60
        print("near_miss_fraction_lower_decimal=" + str(Decimal(low.numerator) / Decimal(low.denominator)))
        print("near_miss_fraction_upper_decimal=" + str(Decimal(high.numerator) / Decimal(high.denominator)))

if __name__ == "__main__":
    main()
