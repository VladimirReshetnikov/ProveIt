# Prime-Anchored Exponential Rigidity

Structural reductions, arithmetic interpolation, and routes toward the
Alaoglu–Erdős integer-exponent conjecture.

Prepared for Vladimir Reshetnikov, 4 September 2026.

## Contents

- `alaoglu-erdos-research.pdf`: the compiled article.
- `alaoglu-erdos-research.tex`: standalone LaTeX source, including bibliography.
- `certify.cpp`: exhaustive exact-integer interval verification for inputs below 2^24.
- `certificate.txt`: the executed full-range C++ transcript.
- `verify.py`: independent arbitrary-integer and exact-Fraction checks.
- `independent-check.txt`: the executed independent-check transcript.
- `determinantal_divisors.py`: exact maximal-minor, step-divisor, Gram-determinant,
  and primitive-kernel experiments.
- `divisor-experiments.json`: the executed experiment output.
- `MANIFEST.sha256`: SHA-256 hashes of the other files.

## Main mathematical content

The article starts from the exact two-generator counterexample structure already
present in the supplied report and gives a direct valuation normalization. It
then develops explicit auxiliary-polynomial estimates, a rank-three logarithmic
normal form, and a joint lattice/extrapolation proof criterion. In particular,
the ratio of consecutive maximal-minor gcds is exactly the universal divisor
forced at the next evaluation, while the initial gcd reduces coefficient height
through the integer-kernel covolume formula.

These are proved reductions and sufficient criteria, not a claimed proof of the
global conjecture. The needed arithmetic estimates for the proposed proof route
are explicitly identified as missing. Deep established inputs such as Baker's
theorem and six exponentials are cited, rather than reproved.

## Rebuilding the PDF

A TeX Live installation with the packages in the preamble is sufficient.
The document uses the New PX text and math fonts installed by TeX Live.
No font files are distributed in this archive.

Run three times, or use an equivalent latexmk build:

```sh
pdflatex -interaction=nonstopmode -halt-on-error alaoglu-erdos-research.tex
pdflatex -interaction=nonstopmode -halt-on-error alaoglu-erdos-research.tex
pdflatex -interaction=nonstopmode -halt-on-error alaoglu-erdos-research.tex
```

The supplied PDF was produced using pdfTeX 1.40.26 / TeX Live 2025/dev/Debian.

## Reproducing the finite exclusion

The C++ program requires GCC or a compatible Clang implementation with
`__uint128_t`, and the header-only Boost.Multiprecision library. It is suitable
for Linux or WSL; the provided source is not a direct MSVC build.

```sh
g++ -O3 -std=c++17 certify.cpp -o certify
./certify 16777216 > certificate-replayed.txt
```

The program accepts exclusive limits from 4 through 16777216. The full executed
range checked all 16,777,191 non-power-of-two inputs below 2^24, with no unresolved
cases. Consequently, for real x < 24, integral 2^x and 3^x force integral x.
The endpoint x = 24 is itself integral, so any nonintegral counterexample must
have x > 24.

All successful acceptance tests use outward-rounded integer intervals. Floating
point only proposes the neighboring integer. The first pass uses a scale of
2^-60 and the refinement uses 2^-96. An unresolved refined interval causes a
nonzero exit status. The appendix proves the truncation bounds and describes
the intermediate integer-size bounds.

The FNV-1a checksum in the transcript is an audit of the ordered (m,n) stream,
with each integer encoded as eight little-endian bytes. It is not a cryptographic
certificate and does not replace verification. Elapsed time and decimal display
format may differ between environments. The full C++ run was executed with GCC
14.2.0; the final replay took about 9.7 seconds in the execution environment.

## Independent Python checks

The Python programs need only the standard library and target Python 3.9 or later.
They were executed with Python 3.13.5.

```sh
python verify.py --limit 65536
python determinantal_divisors.py
```

The independent full-range Python check covers inputs below 2^16 and selected
large inputs. An exact-Fraction calculation independently proves positivity of
the recorded near-miss logarithmic determinant and prints high-precision decimal
bounds. Decimal and floating-point output are only presentations; the positivity
check is an exact rational comparison.

The optional command below performs a substantially slower independent full-range
replay. This full Python replay was NOT run for the supplied article:

```sh
python verify.py --limit 16777216
```

The mixed determinant experiment with anchors (2,3) and formal outputs (5,13) is
an arithmetic control, NOT an asserted counterexample. It does not satisfy or
assume equality of log(5)/log(2) and log(13)/log(3). The program checks maximal
minor gcds, exact step divisors, kernel covolume squares, and a final primitive
kernel vector using only integer arithmetic.

## Source and trust boundaries

The linked repository location and report files were checked, but the very large
current TeX blob could not be fully retrieved through the available connector.
Detailed comparison used an accessible indexed copy of the unified report, not
a complete audit of the latest main branch. The article does not claim to have
rerun or extended the repository's Lean verification.

The finite exclusion is computer-assisted, not a proof-assistant certificate.
It depends on the documented algorithm, its implementation, the compiler, and
the executed integer operations. The article distinguishes that result from
conditional structural mathematics and from unproved research targets.
