// Exact fixed-point interval certificate for 2^x,3^x integral, 2^x < limit.
// Floating point proposes n=floor(m^(log(3)/log(2))); it never certifies a claim.
// All acceptance tests use integer interval arithmetic. Boost is header-only.
// Build: g++ -O3 -std=c++17 certify.cpp -o certify
// Run: ./certify 16777216 > certificate.txt
#include <boost/multiprecision/cpp_int.hpp>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
using U64=std::uint64_t;
using U128=__uint128_t;
using U256=boost::multiprecision::uint256_t;
struct I60 { U128 lo,hi; };
struct I96 { U128 lo,hi; };
constexpr U64 B60=U64(1)<<60;
const U128 B96=U128(1)<<96;
const U256 MASK96=(U256(1)<<96)-1;
I60 core60(U64 numerator,U64 denominator) {
    U64 zl=U64((U128(numerator)<<60)/denominator), zh=zl+1;
    U64 sl=U64((U128(zl)*zl)>>60);
    U64 sh=U64((U128(zh)*zh+B60-1)>>60);
    U64 pl=zl,ph=zh,tl=0,th=0;
    for(unsigned j=1;j<48;j+=2) {
        tl+=pl/j; th+=(ph+j-1)/j;
        pl=U64((U128(pl)*sl)>>60);
        ph=U64((U128(ph)*sh+B60-1)>>60);
    }
    // True tail: 2*z^49/(49*(1-z^2)) < 2^-60, as z<=1/3.
    return {2*tl,2*th+1};
}
I96 core96(U64 numerator,U64 denominator) {
    U128 zl=(U128(numerator)<<96)/denominator, zh=zl+1;
    U128 sl=U128((U256(zl)*zl)>>96);
    U128 sh=U128((U256(zh)*zh+MASK96)>>96);
    U128 pl=zl,ph=zh,tl=0,th=0;
    for(unsigned j=1;j<80;j+=2) {
        tl+=pl/j; th+=(ph+j-1)/j;
        pl=U128((U256(pl)*sl)>>96);
        ph=U128((U256(ph)*sh+MASK96)>>96);
    }
    // True tail: 2*z^81/(81*(1-z^2)) < 2^-96.
    return {2*tl,2*th+1};
}
const I60 LN2_60=core60(1,3), LN3_60=[](){auto t=core60(1,5);return I60{LN2_60.lo+t.lo,LN2_60.hi+t.hi};}();
const I96 LN2_96=core96(1,3), LN3_96=[](){auto t=core96(1,5);return I96{LN2_96.lo+t.lo,LN2_96.hi+t.hi};}();
I60 log60(U64 m) {
    if(!m) throw std::runtime_error("log zero");
    unsigned k=63-__builtin_clzll(m); U64 t=U64(1)<<k;
    auto c=core60(m-t,m+t);
    return {k*LN2_60.lo+c.lo,k*LN2_60.hi+c.hi};
}
I96 log96(U64 m) {
    if(!m) throw std::runtime_error("log zero");
    unsigned k=63-__builtin_clzll(m); U64 t=U64(1)<<k;
    U64 numerator=m-t,denominator=m+t;
    // numerator can exceed 2^32: use 256-bit division here.
    U128 zl=U128((U256(numerator)<<96)/denominator),zh=zl+1;
    U128 sl=U128((U256(zl)*zl)>>96),sh=U128((U256(zh)*zh+MASK96)>>96);
    U128 pl=zl,ph=zh,tl=0,th=0;
    for(unsigned j=1;j<80;j+=2) {
        tl+=pl/j;th+=(ph+j-1)/j;
        pl=U128((U256(pl)*sl)>>96);ph=U128((U256(ph)*sh+MASK96)>>96);
    }
    return {k*LN2_96.lo+2*tl,k*LN2_96.hi+2*th+1};
}
struct Margin { long double lo,hi; };
Margin margin96(U64 m,U64 n,bool upper) {
    auto lm=log96(m),ln=log96(n);
    U256 a,b,c,d;
    if(!upper) {a=U256(lm.lo)*LN3_96.lo;b=U256(ln.hi)*LN2_96.hi;
                c=U256(lm.hi)*LN3_96.hi;d=U256(ln.lo)*LN2_96.lo;}
    else {a=U256(ln.lo)*LN2_96.lo;b=U256(lm.hi)*LN3_96.hi;
          c=U256(ln.hi)*LN2_96.hi;d=U256(lm.lo)*LN3_96.lo;}
    if(a<=b || c<=d) return {-1,-1};
    return {std::ldexp((a-b).convert_to<long double>(),-192),
            std::ldexp((c-d).convert_to<long double>(),-192)};
}
int main(int argc,char**argv) {
  try {
    U64 limit=argc>1?std::stoull(argv[1]):16777216;
    if(limit<4 || limit>16777216) throw std::runtime_error("supported limit: 4..16777216");
    const auto start=std::chrono::steady_clock::now();
    U64 checked=0,fallback=0,hash=14695981039346656037ULL;
    long double bestUpper=std::numeric_limits<long double>::infinity();
    Margin best{0,0}; U64 bm=0,bn=0; bool bupper=false;
    const long double alpha=std::log(3.0L)/std::log(2.0L);
    auto hashword=[&](U64 x){for(int i=0;i<8;++i){hash^=(x&255);hash*=1099511628211ULL;x>>=8;}};
    for(U64 m=2;m<limit;++m) {
      if((m&(m-1))==0) continue;
      long double proposal=std::exp(alpha*std::log((long double)m));
      if(!std::isfinite(proposal) || proposal<1 || proposal>282429536483.0L)
          throw std::runtime_error("floating proposal outside safe integer range");
      U64 n=U64(std::floor(proposal));
      auto lm=log60(m),ln=log60(n),lnp=log60(n+1);
      U128 a=U128(lm.lo)*LN3_60.lo,b=U128(ln.hi)*LN2_60.hi;
      U128 c=U128(lnp.lo)*LN2_60.lo,d=U128(lm.hi)*LN3_60.hi;
      bool ok60=(a>b && c>d);
      bool need=(!ok60);
      if(ok60) {
          long double small=std::min(std::ldexp((long double)(a-b),-120),std::ldexp((long double)(c-d),-120));
          need=small<=bestUpper;
      }
      if(need) {
        ++fallback;
        auto lower=margin96(m,n,false),upper=margin96(m,n+1,true);
        if(lower.lo<=0 || upper.lo<=0) {
          // Re-propose locally; every accepted new n still has two exact tests.
          bool found=false;
          for(int delta=-2;delta<=2;++delta) {
            U64 nn=U64((std::int64_t)n+delta);
            if(nn<1) continue;
            auto l=margin96(m,nn,false),u=margin96(m,nn+1,true);
            if(l.lo>0&&u.lo>0){n=nn;lower=l;upper=u;found=true;break;}
          }
          if(!found) throw std::runtime_error("unresolved interval at m="+std::to_string(m));
        }
        if(lower.hi<bestUpper){bestUpper=lower.hi;best=lower;bm=m;bn=n;bupper=false;}
        if(upper.hi<bestUpper){bestUpper=upper.hi;best=upper;bm=m;bn=n+1;bupper=true;}
      }
      hashword(m);hashword(n);++checked;
    }
    std::cout<<std::setprecision(24);
    std::cout<<"limit_exclusive="<<limit<<"\nchecked_nonpowers="<<checked
      <<"\nunresolved=0\nrefined_to_96_bits="<<fallback
      <<"\nsmallest_margin_m="<<bm<<"\nsmallest_margin_neighbor="<<bn
      <<"\nsmallest_margin_side="<<(bupper?"upper":"lower")
      <<"\nsmallest_margin_lower_bound="<<best.lo
      <<"\nsmallest_margin_upper_bound="<<best.hi
      <<"\nfnv1a64_little_endian_m_n="<<std::hex<<std::setw(16)<<std::setfill('0')<<hash<<std::dec
      <<"\nelapsed_seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"\n";
  } catch(const std::exception&e) {std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}
}
