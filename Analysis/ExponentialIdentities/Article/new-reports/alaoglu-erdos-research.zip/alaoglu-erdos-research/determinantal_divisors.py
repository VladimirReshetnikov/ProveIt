"""Exact small determinantal-divisor experiments (Python 3.9+, standard library).
The mixed example is an arithmetic control, NOT a conjectural counterexample:
5 != 2**(log(13)/log(3)). No real rank-one claim is made for that example.
"""
from itertools import combinations
from math import gcd, factorial
import json

def determinant(matrix):
    a = [list(row) for row in matrix]
    n = len(a)
    if n == 0:
        return 1
    sign, previous = 1, 1
    for k in range(n-1):
        if a[k][k] == 0:
            swap = next((j for j in range(k+1,n) if a[j][k]), None)
            if swap is None:
                return 0
            a[k], a[swap] = a[swap], a[k]
            sign = -sign
        pivot = a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                value = a[i][j]*pivot-a[i][k]*a[k][j]
                assert value % previous == 0
                a[i][j] = value // previous
            a[i][k] = 0
        previous = pivot
    return sign*a[-1][-1]

def divisors(rows):
    d = len(rows[0])
    values = [1]
    for r in range(1, len(rows)+1):
        delta = 0
        for cols in combinations(range(d), r):
            minor = [[rows[i][j] for j in cols] for i in range(r)]
            delta = gcd(delta, abs(determinant(minor)))
            if delta == 1:
                break
        if not delta:
            raise ArithmeticError('prefix loses row rank')
        assert delta % values[-1] == 0
        values.append(delta)
    return values, [values[j+1]//values[j] for j in range(len(rows))]

columns = [(0,0),(1,0),(0,1),(2,0),(1,1),(3,0),(0,2),(2,1)]
nodes = [2**a*3**b for a,b in columns]
ordinary = [[z**j for z in nodes] for j in range(8)]
row_coordinates = [(0,0),(1,0),(2,0),(0,1),(3,0),(1,1),(4,0),(2,1)]
mixed = [[(2**a*3**b)**n*(5**a*13**b)**k for a,b in columns]
         for n,k in row_coordinates]
D1,d1 = divisors(ordinary)
D2,d2 = divisors(mixed)
assert all(d1[j] % factorial(j) == 0 for j in range(8))
def kernel_data(rows, Delta):
    """Check exact Gram determinants and the primitive codimension-one kernel."""
    data = []
    for r in range(1, len(rows)):
        gram = [[sum(x*y for x,y in zip(rows[i], rows[j]))
                 for j in range(r)] for i in range(r)]
        gram_det = determinant(gram)
        assert gram_det > 0 and gram_det % (Delta[r]**2) == 0
        data.append(gram_det // (Delta[r]**2))
    r = len(rows)-1
    primitive = []
    for j in range(len(rows[0])):
        minor = [[row[k] for k in range(len(row)) if k != j] for row in rows[:r]]
        numerator = (-1)**j * determinant(minor)
        assert numerator % Delta[r] == 0
        primitive.append(numerator // Delta[r])
    assert all(sum(x*y for x,y in zip(row,primitive)) == 0 for row in rows[:r])
    assert sum(x*x for x in primitive) == data[-1]
    last_value = sum(x*y for x,y in zip(rows[-1],primitive))
    assert abs(last_value) == Delta[-1] // Delta[-2]
    return {'kernel_covolume_squared':data,
            'last_primitive_kernel_vector':primitive,
            'last_kernel_value':last_value}

print(json.dumps({'nodes':nodes,
 'ordinary':{'Delta':D1,'step_divisors':d1, **kernel_data(ordinary,D1)},
 'mixed_control':{'anchors':[2,3], 'outputs':[5,13],
                  'row_coordinates':row_coordinates,'Delta':D2,'step_divisors':d2,
                  **kernel_data(mixed,D2)}},
 indent=2))
