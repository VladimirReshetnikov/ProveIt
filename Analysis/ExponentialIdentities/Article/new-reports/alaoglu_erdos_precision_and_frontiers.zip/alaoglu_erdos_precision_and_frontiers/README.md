# The Alaoglu–Erdős Integer-Exponent Conjecture
## Precision, local rank, and arithmetic routes beyond the unified report

Research article prepared for Vladimir Reshetnikov. Literature checked through
4 September 2026. The article is 33 pages, including its title page, contents,
appendices, and references.

## Mathematical status

This package does not claim a proof of the conjecture. It contains proved local
interpolation and determinant lemmas, an exact finite-fitting criterion, a
residue-tree algorithm, explicit research targets, and a software-assisted
finite exclusion. Existing structural reductions are attributed separately.
No global originality claim is made for the auxiliary mathematics.

The exhaustive run certifies that for every integer 1 <= m < 2^24 that is not a
power of two, m^(log(3)/log(2)) is nonintegral and has distance greater than
10^(-12) from the nearest integer. It checks 16,777,191 such inputs and skips
24 canonical powers of two. This implies that any nonintegral counterexample
exponent would exceed 24. It does not exclude counterexamples beyond that range.

All acceptance decisions use arbitrary-size integer arithmetic. Floating point
only proposes a candidate floor. This is not a Lean-kernel certificate. A digest
is reproducibility metadata, not a substitute for the checker and its proof.

## Files

- alaoglu_erdos_precision_and_frontiers.tex: stand-alone LaTeX source.
- alaoglu_erdos_precision_and_frontiers.pdf: compiled article.
- certify_range.py: exact rational/fixed-point logarithm range checker.
- certificate.json: output of the complete range check.
- verify_auxiliary.py: deterministic finite checks and a residue-tree implementation.
- auxiliary_checks.json: output of the auxiliary checks.
- README.md: this file.
- checksums.txt: SHA-256 hashes of the delivered files other than itself.

## Reproduce the exhaustive run

Use Python 3.10 or later. No third-party Python packages are required.

    python certify_range.py --start 1 --stop 16777216 --output reproduced.json

The interval is half-open. To run a quick test instead:

    python certify_range.py --start 1 --stop 10000 --output quick_test.json

The recorded full run took about 182 seconds in the preparation environment.
Runtime and floating-point proposal/fallback behavior may vary by platform.
The exact accepted floors, coverage, and mathematical acceptance inequalities
are the relevant invariants. A failed or unresolved comparison raises an error;
inputs are never silently skipped. Raising the cutoff can require more precision
or better floor proposals; no arbitrary-range performance promise is made.

The SHA-256 digest of the complete accepted (m,n) bracket stream was:

    10d2cc8ce734533eee928e9742bb344213183499323dca81b2a88628060b8716

## Reproduce the supplementary checks

Run from the extracted package directory:

    python verify_auxiliary.py

This recreates auxiliary_checks.json. It checks the residue-tree routine against
exhaustive subsets in 80 cases, determinant divisibility in 60 cases, 172 exact
logarithm enclosures using a second Fraction-based implementation, finite graph
counts, and the explicit congruence and period-germ examples. These finite tests
complement the general proofs; they do not replace them.

The general Smith-normal-form fitting criterion is proved in the article.
The package does not claim to implement a complete large-matrix fitting optimizer
or to provide a completed proof-assistant formalization.

## Compile the article

A conventional TeX Live or equivalent installation is sufficient. The source
uses standard packages and an embedded bibliography; no external images, data,
BibTeX file, or downloaded assets are needed.

    pdflatex -interaction=nonstopmode -halt-on-error alaoglu_erdos_precision_and_frontiers.tex
    pdflatex -interaction=nonstopmode -halt-on-error alaoglu_erdos_precision_and_frontiers.tex
    pdflatex -interaction=nonstopmode -halt-on-error alaoglu_erdos_precision_and_frontiers.tex

The delivered PDF was visually inspected after compilation. Its source build
has no unresolved references or overfull-box warnings. Recompilation may change
PDF metadata and its binary hash without changing the mathematical content.
