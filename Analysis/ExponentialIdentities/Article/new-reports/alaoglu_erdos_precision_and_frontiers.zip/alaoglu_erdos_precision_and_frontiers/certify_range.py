#!/usr/bin/env python3
"""Exact rational interval certificates for m**(log(3)/log(2)).

Python's arbitrary-size integers perform every acceptance test. Floating point
is used ONLY to propose a floor; the two exact sign checks certify that floor.
A failed sign check is inconclusive, never silently accepted.

Example: python certify_range.py --start 1 --stop 16777216 --output certificate.json
The interval is half-open. No third-party Python packages are required.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import time

BITS = 112
SCALE = 1 << BITS
GRID = 256


def ceil_div(a: int, b: int) -> int:
    """Ceiling for nonnegative numerator and positive denominator."""
    return (a + b - 1) // b


def atanh_log_bounds(a: int, b: int, terms: int, z_bound_den: int) -> tuple[int, int]:
    """Enclose log((b+a)/(b-a)), multiplied by SCALE, for 0 <= a/b <= 1/D.

    Sum 2*sum_{j=0}^{terms-1} z**(2*j+1)/(2*j+1) with outward
    fixed-point rounding. The tail is at most
       3 / ((2*terms+1)*D**(2*terms+1))
    when D >= 3. All arithmetic here is exact integer arithmetic.
    """
    if not (0 <= a < b and z_bound_den >= 3 and a*z_bound_den <= b):
        raise ValueError("Invalid logarithm reduction")
    if a == 0:
        return (0, 0)
    lo = a*SCALE // b
    hi = ceil_div(a*SCALE, b)
    z2lo = lo*lo // SCALE
    z2hi = ceil_div(hi*hi, SCALE)
    plo, phi = lo, hi
    slo = shi = 0
    for j in range(terms):
        d = 2*j + 1
        slo += plo // d
        shi += ceil_div(phi, d)
        plo = plo*z2lo // SCALE
        phi = ceil_div(phi*z2hi, SCALE)
    tail = ceil_div(3*SCALE, (2*terms+1)*z_bound_den**(2*terms+1))
    return (2*slo, 2*shi + tail)


LOG2 = atanh_log_bounds(1, 3, 44, 3)
TABLE = [atanh_log_bounds(j, 512+j, 44, 3) for j in range(GRID)]


def log_bounds(n: int) -> tuple[int, int]:
    """Exact enclosing interval for SCALE*log(n), n a positive integer."""
    if n < 1:
        raise ValueError("log_bounds requires a positive integer")
    e = n.bit_length() - 1
    power = 1 << e
    j = (GRID*n // power) - GRID
    anchor_num = power*(GRID+j)
    a = GRID*n - anchor_num
    b = GRID*n + anchor_num
    # anchor <= n/2**e < anchor + 1/256, so a/b <= 1/513.
    rlo, rhi = atanh_log_bounds(a, b, 7, 513)
    tlo, thi = TABLE[j]
    return (e*LOG2[0] + tlo + rlo, e*LOG2[1] + thi + rhi)


LOG3 = log_bounds(3)


def determinant_bounds(lm: tuple[int,int], ln: tuple[int,int]) -> tuple[int,int]:
    """Enclose SCALE**2*(log(3)*log(m)-log(2)*log(n))."""
    return (LOG3[0]*lm[0] - LOG2[1]*ln[1],
            LOG3[1]*lm[1] - LOG2[0]*ln[0])


def certify(start: int, stop: int) -> dict:
    if not (1 <= start < stop <= (1 << 40)):
        raise ValueError("Require 1 <= start < stop <= 2**40")
    theta_proposal = math.log(3.0)/math.log(2.0)
    checked = controls = fallbacks = 0
    best_num, best_den = 1, 1
    best = None
    # An independent, fixed threshold tested for every noncontrol input.
    threshold_den = 10**12
    h = hashlib.sha256()
    begun = time.monotonic()
    for m in range(start, stop):
        if m & (m-1) == 0:
            controls += 1
            continue
        n = int(math.exp(theta_proposal*math.log(m)))
        lm, ln = log_bounds(m), log_bounds(n)
        low, _ = determinant_bounds(lm, ln)
        # log(n+1) >= log(n) + 1/n - 1/(2*n*n).
        # This is a convenient bound, with an exact-log fallback if needed.
        next_lo = ln[0] + (SCALE*(2*n-1))//(2*n*n)
        upper_next = LOG3[1]*lm[1] - LOG2[0]*next_lo
        if low <= 0 or upper_next >= 0:
            fallbacks += 1
            # A floor proposal may be off by one; acceptance remains exact.
            found = False
            for candidate in range(max(1,n-2), n+3):
                lc, ld = log_bounds(candidate), log_bounds(candidate+1)
                low_c, _ = determinant_bounds(lm,lc)
                _, high_d = determinant_bounds(lm,ld)
                if low_c > 0 and high_d < 0:
                    n, low, upper_next = candidate, low_c, high_d
                    found = True
                    break
            if not found:
                raise ArithmeticError(f"Unresolved m={m}; increase precision or inspect it")
        checked += 1
        # Certified lower bounds on each of the two distances to an integer:
        # n*(exp(z)-1) >= n*z and (n+1)*(1-exp(-w)) >= (n+1)*w/(1+w).
        q = SCALE*LOG2[1]
        distances = ((n*low, q, 'lower'),
                     ((n+1)*(-upper_next), q-upper_next, 'upper'))
        for num, den, side in distances:
            if num*threshold_den <= den:
                raise ArithmeticError(f"Uniform distance threshold not certified at {m}")
            if num*best_den < best_num*den:
                best_num, best_den = num, den
                best = {'m':m, 'floor':n, 'side':side}
        # Digest of the accepted bracket table; not itself a proof.
        h.update(f'{m},{n}\n'.encode('ascii'))
    return {
        'start_inclusive':start, 'stop_exclusive':stop,
        'precision_bits':BITS, 'grid_size':GRID,
        'checked_nonpowers':checked, 'skipped_powers_of_two':controls,
        'failures':0, 'exact_log_fallbacks':fallbacks,
        'uniform_distance_lower_bound':f'1/{threshold_den}',
        'smallest_certified_distance_location':best,
        'smallest_certified_distance_numerator':str(best_num),
        'smallest_certified_distance_denominator':str(best_den),
        'smallest_certified_distance_approx':best_num/best_den,
        'accepted_brackets_sha256':h.hexdigest(),
        'elapsed_seconds':round(time.monotonic()-begun,3),
        'trust_boundary':'Python integer arithmetic; not a Lean kernel certificate',
        'log2_bounds_scaled':list(map(str,LOG2)),
        'log3_bounds_scaled':list(map(str,LOG3)),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', type=int, default=1)
    parser.add_argument('--stop', type=int, default=1<<24)
    parser.add_argument('--output', type=Path, default=Path('certificate.json'))
    args = parser.parse_args()
    result = certify(args.start,args.stop)
    args.output.write_text(json.dumps(result, indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2), flush=True)

if __name__ == '__main__':
    main()
