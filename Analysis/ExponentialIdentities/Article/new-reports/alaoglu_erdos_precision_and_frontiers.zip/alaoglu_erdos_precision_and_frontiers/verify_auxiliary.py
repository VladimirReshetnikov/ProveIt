#!/usr/bin/env python3
"""Reproduce finite examples and cross-check the article's algorithms.

Uses only the Python standard library. These finite tests complement, and do
not replace, the proofs in the article. The full range certificate is produced
separately by certify_range.py.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import random
from certify_range import SCALE, log_bounds


def valuation(n: int, p: int) -> int:
    if n == 0:
        raise ValueError('Use valuation only on nonzero integers')
    n = abs(n)
    v = 0
    while n % p == 0:
        n //= p
        v += 1
    return v


def precision_budget_brute(nodes: list[int], precisions: list[int], p: int) -> int:
    n = len(nodes)
    weights = {(i,j): valuation(nodes[i]-nodes[j],p)
               for i in range(n) for j in range(i+1,n)}
    return min(sum(precisions[i] for i in range(n) if not (mask>>i)&1)
               + sum(w for (i,j),w in weights.items()
                     if (mask>>i)&1 and (mask>>j)&1)
               for mask in range(1<<n))


def precision_budget_tree(nodes: list[int], precisions: list[int], p: int) -> int:
    """Residue-tree dynamic programming, with one edge per p-adic digit."""
    if len(nodes) != len(precisions) or len(set(nodes)) != len(nodes):
        raise ValueError('Distinct nodes and one precision per node required')
    if not nodes or min(precisions) < 0 or p < 2:
        raise ValueError('Nonempty nodes, nonnegative precisions and prime p required')
    # Primality is a precondition of this mathematical routine, not tested here.
    infinity = 1 + sum(precisions) + sum(valuation(nodes[i]-nodes[j], p)
                                       for i,j in combinations(range(len(nodes)),2))
    def visit(indices: list[int], depth: int) -> list[int]:
        if len(indices) == 1:
            return [precisions[indices[0]], 0]
        modulus = p**(depth+1)
        groups: dict[int,list[int]] = {}
        for i in indices:
            groups.setdefault(nodes[i] % modulus, []).append(i)
        merged = [0]
        for group in groups.values():
            child = visit(group, depth+1)
            combined = [infinity]*(len(merged)+len(child)-1)
            for a, av in enumerate(merged):
                for b, bv in enumerate(child):
                    combined[a+b] = min(combined[a+b], av+bv)
            merged = combined
        # depth 0 is an artificial root: congruence modulo 1 gives no valuation.
        if depth:
            merged = [value+s*(s-1)//2 for s,value in enumerate(merged)]
        return merged
    return min(visit(list(range(len(nodes))),0))


def rational_log_bounds(n: int, terms: int=80) -> tuple[Fraction,Fraction]:
    """A second implementation using exact fractions, not fixed point."""
    def atanh_sum(z: Fraction) -> tuple[Fraction,Fraction]:
        power = z
        total = Fraction(0)
        for j in range(terms):
            total += 2*power/(2*j+1)
            power *= z*z
        tail = 2*power/((2*terms+1)*(1-z*z))
        return total, total+tail
    e = n.bit_length()-1
    r = Fraction(n,1<<e)
    a,b = atanh_sum(Fraction(1,3))
    c,d = atanh_sum((r-1)/(r+1))
    return e*a+c,e*b+d


def main() -> None:
    rng = random.Random(20260904)
    budget_tests = 0
    for p in (2,3,5,7):
        for _ in range(20):
            n = rng.randrange(2,9)
            nodes = [p*x for x in rng.sample(range(1,200),n)]
            ks = [rng.randrange(0,20) for _ in range(n)]
            brute = precision_budget_brute(nodes,ks,p)
            tree = precision_budget_tree(nodes,ks,p)
            assert brute == tree,(p,nodes,ks,brute,tree)
            budget_tests += 1
    equal_nodes = [49*i for i in range(6)]
    equal_budget = precision_budget_tree(equal_nodes,[3]*6,7)
    assert equal_budget == 14

    determinant_tests = 0
    # det(y_i**j) is the ordinary Vandermonde product; no determinant library.
    for p in (3,5,7):
        for _ in range(20):
            n = rng.randrange(2,7)
            nodes = [p*x for x in rng.sample(range(1,100),n)]
            ks = [rng.randrange(1,12) for _ in range(n)]
            ys = [1+t+t*t + p**k*rng.randrange(1,10)
                  for t,k in zip(nodes,ks)]
            det = 1
            for i,j in combinations(range(n),2):
                det *= ys[j]-ys[i]
            budget = precision_budget_tree(nodes,ks,p)
            assert det == 0 or valuation(det,p) >= budget
            determinant_tests += 1

    graph_tests = []
    for p,k,J in [(7,1,(2,6,6,2)),(3,2,(1,0,0,3)),(3,2,(3,0,0,3))]:
        modulus = p**k
        a,b,c,d = J
        det = a*d-b*c
        delta_val = valuation(det,p)
        count = 0
        for s in range(modulus):
            for t in range(modulus):
                x=(a*s+b*t)%modulus
                y=(c*s+d*t)%modulus
                count += y == (x*x+3*x+1)%modulus
        bound = min(p**(2*k),p**(k+delta_val))
        assert count <= bound
        graph_tests.append({'p':p,'k':k,'matrix':list(J),
                            'count':count,'bound':bound})

    U=2**24*5**6
    V=3**24*13**6
    assert U%49==1 and V%49==36
    assert valuation(U-1,7)==2 and valuation(V-1,7)==1

    values = {1,2,3,5,7126099,72696450718,72696450719,2**24-1}
    values.update(2**k+d for k in range(2,41) for d in (-1,0,1))
    values.update(rng.randrange(2,3**24) for _ in range(50))
    for n in sorted(values):
        a,b = log_bounds(n)
        c,d = rational_log_bounds(n)
        assert Fraction(a,SCALE) <= c <= d <= Fraction(b,SCALE),n
    # Polynomial germ in the period-model negative control M=4, N=9.
    leading = Fraction(3,4)*Fraction(2,3)-Fraction(8,9)*Fraction(1,2)
    assert leading == Fraction(1,18)
    out = {
        'deterministic_seed':20260904,
        'residue_tree_against_exhaustive_tests':budget_tests,
        'determinant_transfer_tests':determinant_tests,
        'independent_fraction_log_tests':len(values),
        'equal_weight_example':{'nodes':equal_nodes,'p':7,'K':3,'budget':equal_budget,
                                'full_vandermonde_budget':30},
        'finite_graph_counts':graph_tests,
        'vertical_fiber_example':{'M':5,'N':13,'p':7,'s':4,'t':1,
                                  'U':U,'V':V,'U_mod_49':U%49,'V_mod_49':V%49,
                                  'valuation_U_minus_1':2,'valuation_V_minus_1':1},
        'canonical_period_germ_z2_coefficient':'1/18',
        'failures':0,
        'scope':'Finite validation tests, not substitutes for the general proofs.'
    }
    destination=Path(__file__).with_name('auxiliary_checks.json')
    destination.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
