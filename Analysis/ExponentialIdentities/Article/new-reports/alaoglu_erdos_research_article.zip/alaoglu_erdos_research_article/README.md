# Toward the Alaoglu–Erdős Integer Exponent Conjecture

Research article dated 4 September 2026.

## Contents

- `alaoglu_erdos_proof_targets.tex`: self-contained LaTeX article, including bibliography.
- `alaoglu_erdos_proof_targets.pdf`: compiled 29-page article.
- `verify_results.py`: standard-library Python exact-arithmetic checks.
- `verification_results.json`: results from the completed verification run.
- `build.sh`: three-pass PDF build.
- `SHA256SUMS`: checksums for the other archive files.

## Scope and status

The article investigates the statement

    x real, 2^x and 3^x integers  =>  x is a nonnegative integer.

It does not claim an unconditional proof or a counterexample. It proves local
regularity obstructions, exact interpolation denominator minima, a prime-form
Hessian and monodromy rank calculation, and an explicit prime-adapted Padé
construction with a counterexample-conditioned radius jump and exact growth
obstruction. It proposes additional holonomy, local-arithmetic, and sparse
auxiliary targets with their missing assumptions stated explicitly.

The upstream unified report and primary literature are cited in the article.
The source comparison was targeted, not an exhaustive audit of the entire
repository. No upstream commit was pinned, no Lean build was run, and no
claim of global priority is made for the refinements.

## Build the article

Use a TeX Live installation providing newtx, amsmath, amsthm, mathtools,
geometry, microtype, hyperref, cleveref, aliascnt, booktabs, listings,
fancyhdr, and the other usual packages named in the preamble. From this
folder run:

    sh build.sh

No bibliography tool or external data download is needed. The PDF contains
embedded fonts as normal; no font files are distributed in this archive.

## Run the exact checks

Python 3.10 or later; no third-party packages:

    python3 verify_results.py --output verification_results.json

The recorded run passed 23,536 categorized finite test cases. This is a count
of test cases, not of individual assertions and not a bound in a search for
counterexamples. Arithmetic uses integers and fractions.Fraction only.
The synthetic example pairs are not asserted to satisfy the conjectured
logarithmic equality. The tests do not verify the analytic proofs, the
external holonomy theorem, or a Lean formalization.

## Main results to inspect

- Theorems 3.1 and 3.2: differentiability obstruction and exact Hölder metric.
- Theorems 4.1 and 4.3: minimum exterior denominator and two-direction law.
- Theorem 5.2: the rank-three/rank-four Hessian reduction.
- Theorem 6.1 and Corollary 6.2: monodromy dimension and minimal differential order.
- Proposition 6.3: neutrality of removing a rational pole.
- Theorems 7.1 and 7.3: exact Padé construction and asymptotics.
- Theorems 8.1, 8.3, and 8.4: arithmetic structure, genuine radius jump,
  and the fixed-depth integer-smallness obstruction.
- Sections 9–11: concrete research targets and quantitative success tests.

See the PDF and LaTeX source for the full hypotheses of every statement.
