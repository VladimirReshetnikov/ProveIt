#!/usr/bin/env python3
"""Exact checks for the companion Alaoglu--Erdos research article.

Python 3.10+, standard library only. These are checks of finite identities,
not a search bound for the conjecture and not a formal proof verification.
Run: python3 verify_results.py --output verification_results.json
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from math import comb, gcd, lcm
import json
from pathlib import Path


def factors(n: int) -> dict[int, int]:
    if n < 1:
        raise ValueError("factorization requires a positive integer")
    out: dict[int, int] = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
        p += 1
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def exterior(n: int) -> int:
    for p in (2, 3):
        while n % p == 0:
            n //= p
    return n


def common_denominator(poly: list[F]) -> int:
    d = 1
    for c in poly:
        d = lcm(d, c.denominator)
    return d


def value(poly: list[F], x: int) -> F:
    v = F(0)
    for c in reversed(poly):
        v = v * x + c
    return v


def stencil(q: int, r: int, alpha: int, lam: int, k: int) -> list[F]:
    return [F(0), F((alpha * alpha - lam) * r**k,
                    alpha * (alpha - 1) * q**k),
            F((lam - alpha) * r**k,
              alpha * (alpha - 1) * q**(2*k))]


def predicted_exterior(q: int, r: int, k: int) -> int:
    fq, fr = factors(q), factors(r)
    out = 1
    for p in fq:
        if p >= 5:
            out *= p**(k * max(0, 2*fq[p] - fr.get(p, 0)))
    return out


def rank(matrix: list[list[int | F]]) -> int:
    if not matrix:
        return 0
    a = [[F(x) for x in row] for row in matrix]
    nr, nc, row = len(a), len(a[0]), 0
    for col in range(nc):
        pivot = next((i for i in range(row, nr) if a[i][col]), None)
        if pivot is None:
            continue
        a[row], a[pivot] = a[pivot], a[row]
        scale = a[row][col]
        a[row] = [x/scale for x in a[row]]
        for i in range(nr):
            if i != row and a[i][col]:
                scale = a[i][col]
                a[i] = [x-scale*y for x, y in zip(a[i], a[row])]
        row += 1
        if row == nr:
            break
    return row


def q_data(m: int, a: int):
    fm, fa = factors(m), factors(a)
    primes = sorted(set([2, 3]) | set(fm) | set(fa))
    ix = {p: i for i, p in enumerate(primes)}
    s = len(primes)
    h = [[0]*s for _ in range(s)]
    # Q = X_3 * L_M - X_2 * L_A. H is the exact Hessian.
    for p in primes:
        i = ix[p]
        h[ix[3]][i] += fm.get(p, 0)
        h[i][ix[3]] += fm.get(p, 0)
        h[ix[2]][i] -= fa.get(p, 0)
        h[i][ix[2]] -= fa.get(p, 0)
    vectors = [[int(p == 2) for p in primes],
               [int(p == 3) for p in primes],
               [fm.get(p, 0) for p in primes],
               [fa.get(p, 0) for p in primes]]
    degrees = {p: (2 if h[ix[p]][ix[p]] else
                    1 if any(h[ix[p]]) else 0) for p in primes}
    return primes, h, rank(vectors), degrees


def q_value(m: int, a: int, x: dict[int, F]) -> F:
    fm, fa = factors(m), factors(a)
    lm = sum((e*x[p] for p, e in fm.items()), F(0))
    la = sum((e*x[p] for p, e in fa.items()), F(0))
    return x[3]*lm - x[2]*la


def pade(b: int, n: int) -> tuple[int, F]:
    """A_n and B_n, independently from the finite Laurent integral."""
    c: dict[int, int] = {}
    for k in range(n+1):
        for ell in range(n+1):
            j = k + ell - n
            c[j] = c.get(j, 0) + (-1)**(n-k+ell)*comb(n,k)*comb(n,ell)*b**(n-ell)
    an = c.get(0, 0)
    bn = -sum((F(v, j)*(F(b)**j - 1) for j, v in c.items() if j), F(0))
    return an, bn


def pade_recurrence(b: int, depth: int) -> list[tuple[int, F]]:
    out = [(1, F(0))]
    if depth == 0:
        return out
    out.append((b+1, F(2*(b-1))))
    for n in range(1, depth):
        old_a, old_b = out[-2]
        an, bn = out[-1]
        new_a = F((2*n+1)*(b+1)*an-n*(b-1)**2*old_a, n+1)
        new_b = ((2*n+1)*(b+1)*bn-n*(b-1)**2*old_b)/(n+1)
        assert new_a.denominator == 1
        out.append((int(new_a), new_b))
    return out


def main(output: Path) -> None:
    counts = {"stencil_quadratics": 0, "bidirectional_budgets": 0,
              "perturbed_polynomials": 0, "hessian_pairs": 0,
              "pade_integral_recurrence": 0, "prime_pade_denominators": 0,
              "prime_log_taylor_denominators": 0}
    for q in range(2, 31):
        for r in range(2, 31):
            for k in range(1, 5):
                for alpha, lam in ((2,3), (3,2)):
                    poly = stencil(q,r,alpha,lam,k)
                    assert value(poly, 0) == 0
                    assert value(poly, q**k) == r**k
                    assert value(poly, alpha*q**k) == lam*r**k
                    assert exterior(common_denominator(poly)) == predicted_exterior(q,r,k)
                    counts["stencil_quadratics"] += 1
                    # Perturbation vanishing at all three nodes, with rational scaling.
                    t, c = q**k, F((-1)**k, 35)
                    perturbed = poly + [F(0)]
                    perturbed[1] += c*alpha*t*t
                    perturbed[2] -= c*(1+alpha)*t
                    perturbed[3] += c
                    assert value(perturbed,t) == r**k
                    assert value(perturbed,alpha*t) == lam*r**k
                    assert exterior(common_denominator(perturbed)) % predicted_exterior(q,r,k) == 0
                    counts["perturbed_polynomials"] += 1
                d = predicted_exterior(q,r,k)*predicted_exterior(r,q,k)
                assert d % (exterior(q*r)**k) == 0
                counts["bidirectional_budgets"] += 1
    for m in range(2, 81):
        for a in range(2, 81):
            primes, h, r, deg = q_data(m,a)
            hr = rank(h)
            is_control = any(m == 2**k and a == 3**k for k in range(1,8))
            assert (hr == 0) == is_control
            if r == 4:
                assert hr == 4
            if r == 3:
                assert hr in (2,3)
            counts["hessian_pairs"] += 1
    for b in range(2, 21):
        seq = pade_recurrence(b, 12)
        d = 1
        for n in range(13):
            if n:
                d = lcm(d,n)
            an, bn = pade(b,n)
            assert (an,bn) == seq[n]
            assert an == sum(comb(n,k)**2*b**k for k in range(n+1))
            assert (d*bn).denominator == 1
            counts["pade_integral_recurrence"] += 1
    examples = []
    for m,a in ((4,9),(5,25),(5,15),(5,7),(10,75),(25,27)):
        primes,h,r,deg = q_data(m,a)
        seqs = {p: pade_recurrence(p,12) for p in primes}
        d = 1
        first = []
        for n in range(13):
            if n:
                d = lcm(d,n)
            approx = {p:F(seqs[p][n][1],seqs[p][n][0]) for p in primes}
            cn = 1
            for p in primes:
                cn *= seqs[p][n][0]**deg[p]
            en = cn*q_value(m,a,approx)
            assert (d*d*en).denominator == 1
            if rank(h) == 0:
                assert en == 0
            if n < 5:
                first.append(str(en))
            counts["prime_pade_denominators"] += 1
        # Exact Taylor check Q(log(1+(p-1)z)).
        logs = {p:[F(0)]+[F((-1)**(j+1)*(p-1)**j,j) for j in range(1,25)] for p in primes}
        fm,fa=factors(m),factors(a)
        d=1
        for n in range(25):
            if n:
                d=lcm(d,n)
            fn=F(0)
            for i in range(n+1):
                fn += logs[3][i]*sum((e*logs[p][n-i] for p,e in fm.items()),F(0))
                fn -= logs[2][i]*sum((e*logs[p][n-i] for p,e in fa.items()),F(0))
            assert (d*d*fn).denominator == 1
            counts["prime_log_taylor_denominators"] += 1
        examples.append({"M":m,"A":a,"valuation_rank":r,"hessian_rank":rank(h),
                         "minimal_degrees":deg,"first_E_n":first,
                         "status":"integer control" if rank(h)==0 else "synthetic noncandidate"})
    results={"purpose":"Exact finite identity checks; not a counterexample search or a proof of AE",
             "arithmetic":"Python integers and fractions.Fraction only", "passed":True,
             "counts":counts,"total_checks":sum(counts.values()),"examples":examples,
             "holonomy_type_constants":{"rank_five":"33/25","rank_six":"23/18"}}
    output.write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in results.items() if k!="examples"},indent=2))

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path("verification_results.json"))
    args=parser.parse_args()
    main(args.output)
