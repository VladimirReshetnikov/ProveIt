# Infinitesimal Gauge Holonomy as a Quantum Resource

**Surreal scales, exact discrimination bounds, postselection costs, and quaternionic obstructions**

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.
Mathematical development and exposition: ChatGPT.

## Contents

- `article.pdf`: 30-page article, including 25 numbered mathematical results, three worked examples, a resource-frontier diagram, a proof/source audit, and 16 references.
- `article.tex`: standalone LaTeX source with internal bibliography. No repository checkout or external figure file is needed.
- `verify.py`: independent exact checks of finite identities and example coefficients.
- `verification.json` and `verification.txt`: recorded results; 148 exact checks passed with SymPy 1.14.0.
- `build.sh`: reruns the checks and compiles the article three times.
- `requirements.txt`: Python dependency used for the checks.
- `build-report.json`: compilation and artifact-validation summary.
- `SHA256SUMS.txt`: checksums of the other delivered files.

## Main question

How much of an infinitesimal non-Abelian holonomy can an ordinary finite quantum protocol resolve, and how much success probability is needed to amplify its conditional signal?

The model uses a real closed ordered field K containing the ordinary reals. Surcomplex amplitudes lie in K(i), and surquaternions describe SU(2) gates. All dimensions, ancillas, circuit depths, instrument lists, and query counts are ordinary finite. No proper-class Hilbert space, global surreal exponential, or infinite-query experiment is assumed.

## Central result

For infinitesimal imaginary quaternions u and v with nonzero cross product, define

    Q(u) = (1+u)/sqrt(1+||u||^2),
    q = Q(u)Q(v)Q(u)^(-1)Q(v)^(-1),
    w = 1 - Re(q)
      = 2||u x v||^2 / ((1+||u||^2)(1+||v||^2)).

The hypotheses are the two known gates I and chi(q), where chi is the standard complex 2-by-2 representation. With at most m queries, including finite ancillas and adaptive controls, let

    w_m = 1 - T_m(1-w),

where T_m is the Chebyshev polynomial. The optimal equal-prior unambiguous success probability is exactly w_m. At prescribed common success probability p, the largest conditional trace distance is

    D_max(p) = 1                              if p <= w_m,
             = sqrt(2 w_m/p - (w_m/p)^2)      if p > w_m.

If kappa = nu(u x v) and beta = nu(p), the exact arbitrary-rank law is

    nu(w_m) = 2 kappa,
    nu(D_max(p)) = max(0, kappa - beta/2).

Here nu is the natural valuation, and its ordered value group need not embed in the reals. This is an attained optimum, not only an upper estimate. See Theorems 5.1, 6.3, and 7.1.

## Further results

Regular bounded-coefficient polynomial class observables of one unit quaternion vary at valuation at least 2 kappa, whereas a coherent probe resolves valuation kappa (Theorem 4.3). This distinguishes a pure Wilson observable from a measurement that includes a preparation and reference system.

No ordinary finite number of queries perfectly distinguishes a nontrivial infinitesimal gate perturbation with certainty (Corollary 5.2). Postselection attains appreciable conditional distinguishability only at infinitesimal total success probability.

The alignment-sensitive coefficient certificate (Theorem 8.4) preserves the leading cross product and all resulting operational scales. A nearly parallel example shows that the strict precision threshold cannot be weakened uniformly.

The sharp conditioning estimate is

    D(Phi(rho)/p, Phi(sigma)/q) <= D(rho,sigma)/max(p,q),

with an explicit equality example (Theorem 8.5). This separates input calibration error from holonomy truncation error.

For fundamental quaternionic amplitudes, finite processes admit complex simulations over the same ordered field (Theorem 10.2). A separate dimension argument rules out the naive quaternionic product dimension under the specified assumptions of bilinear independent preparation and product measurement statistics (Theorem 10.3); it does not rule out all Jordan-algebraic composites.

## Application and novelty status

The positive application is an exact, cancellation-sensitive scale calculus for gauge probes and noncommuting controls. A rank-two example retains a signal below every power of an accessible scale. The article also gives an ordinary real family with x=h and y=exp(-1/h), so the finite formulas can be used without interpreting literal surreal numbers as measured quantities.

The state-separation formula is classical Chefles--Barnett theory, and the ordinary gate-discrimination geometry has Acin's work as an ancestor. Quaternionic complex simulation is also classical. These are credited and reproved under the chosen field hypotheses, not claimed as new.

The candidate contribution is the exact arbitrary-rank gauge/query/postselection synthesis and its finite-resource, alignment, and certification consequences. Historical priority is not independently certified. No empirical departure from ordinary quantum mechanics is established, and no continuum gauge measure or quantum-gravity theory is constructed.

The repository comparison used the pinned tree

    934810abdde4c6d74c08777b069445de43602934

of `VladimirReshetnikov/Surreal`, with targeted inspection of the maintained physics, surquaternion, and surcomplex spectral guides. It was not a complete audit of every repository proof. An incomplete code-search result was not treated as evidence of absence. The article supplies the relevant finite proofs independently of the repository.

## Build

To compile just the article, run:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

A TeX installation needs the packages listed in the preamble, including AMS mathematics, Latin Modern, microtype, TikZ, hyperref, cleveref, geometry, fancyhdr, and booktabs. The delivered PDF has resolved references and no overfull boxes. Minor underfull-box notices concern ordinary spacing, not clipping.

For the exact tests:

```sh
python3 -m pip install -r requirements.txt
python3 verify.py
```

Or, after installing the dependencies, run `sh build.sh` for both steps. The Python code was tested with Python 3.13.5 and SymPy 1.14.0; it requires Python 3.9 or later. Running the verification script overwrites its two result files. Rebuilding may change PDF metadata and checksums; the included checksums describe the delivered files.

The tests check polynomial/rational identities, sample exact contraction inequalities, finite Chebyshev orders, and leading coefficients. They do not formally verify the optimization over all adaptive protocols or the underlying field theory. No Lean formalization is included or claimed.
