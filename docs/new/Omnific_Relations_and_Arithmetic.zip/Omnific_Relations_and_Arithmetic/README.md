# Proper-Class Relations and Arithmetic Endomorphisms of Omnific Ideals

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.tex`: self-contained LaTeX source, including the bibliography.
- `article.pdf`: compiled 19-page article with linked contents and references.
- `code/verify.py`: exact finite arithmetic and matrix checks.
- `requirements.txt`: the tested SymPy version.
- `data/verification.json`: output of the delivered verification run, including all 347 check labels.
- `data/build_report.json`: compilation and document-validation record.

No Lean formalization is included. No font files, repository checkout, or third-party paper PDFs are included.

## Mathematical scope

The article treats the real omnific ring Oz and the Gaussian omnific ring Oz[i].
It separates statements about the full proper-class rings from ordinary homological
algebra over explicitly constructed set-sized subrings A_kappa.

The main results are:

1. A finite constant-matrix kernel decomposition A^r + m^(d-r), with a direct-sum
   interpretation. The integer d is the coefficient-field kernel dimension; r is
   the dimension that descends to Q or Q(i). In the full rings, any positive
   m-summand prevents generation by a set.
2. An explicit two-generated ideal (omega, sqrt(2) omega) with no set-presentation,
   and an exact kappa-relation threshold in the specified bounded-support model
   for each uncountable regular cardinal kappa.
3. A classification of Hom, End, and module isomorphisms for coefficient-lattice
   monomial ideals. Arithmetic orders and their unit groups are recovered from
   their endomorphism rings. Products of ideals correspond to products of
   coefficient lattices, and ideal-power generator growth detects algebraic degree.
4. Over A_kappa, exact Tor formulas and tensor-product torsion expressed by the
   kernel of coefficient multiplication L tensor_D M -> k. The worked examples
   distinguish quadratic, cubic, transcendental, and mixed quadratic data.

All proofs are in the article. The appendix proves the universal set-sized
quotient statement used for the intrinsic interpretation of the endomorphism
orders; that background result is not included among the novelty candidates.

## Status and attribution

This is an AI-assisted research manuscript, not an independently peer-reviewed
paper. No named factorisation conjecture is claimed to be resolved.

The elementary D+M noncoherence mechanism and the M^(n-1) relation-module shape
have classical antecedents in Dobbs (1975) and Dobbs–Papick (1976), explicitly
identified in the article. The proposed additions are the precise omnific size,
constant-kernel, arithmetic, and multiplication-obstruction refinements. Their
novelty is provisional; the literature search is not an exhaustive priority audit.

The source audit records repository revision:

    71e9606d297c9b98c732070dc462682cc6948981

It also distinguishes the documentation inspected from an exhaustive source audit
or a fresh Lean build. No latter audit or build is claimed.

## Rebuild the PDF

Use a reasonably complete TeX Live or MiKTeX installation with pdfLaTeX and the
packages named in the preamble (including newtx, amsmath/amsthm, mathtools,
microtype, hyperref, and cleveref). From the package directory run:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Alternatively:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

The bibliography is embedded in the source; BibTeX is not required. The delivered
final compilation had no LaTeX warnings or overfull/underfull boxes. The PDF was
rendered for visual inspection; an initial table-of-contents spill was corrected.

## Reproduce the finite checks

Python 3.10 or later is required. Install the dependency in a virtual environment:

    python -m pip install -r requirements.txt
    python code/verify.py

The default command rewrites `data/verification.json`. To preserve the delivered
record, choose another destination:

    python code/verify.py --output verification-local.json

The delivered run passed 347 checks with exact rational/polynomial arithmetic.
The deterministic random seed is 20260923. Matrices labeled as number-field
matrices are reduced modulo an explicitly checked irreducible polynomial; no
floating-point approximation is used. Kernel bases labeled `over_Q` are rational
bases and are not advertised as general integral-lattice bases.

These computations check the finite arithmetic examples and identities. They do
not constitute a proof about all Hahn supports, cardinal regularity, proper
classes, or Tor functors. Those statements are justified by the written proofs.
