# Infinitesimal Scales, Observable Limits, and Gauge Topology

## Surreal, surcomplex, and surquaternionic methods in theoretical physics

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

The PDF has **33 pages**: one title page, two contents pages, and 30 numbered
pages of article, appendices, and references. The TeX is standalone and has
an internal bibliography; it does not require downloaded source files or
external figures.

## Contents

- `article.pdf` — the complete manuscript.
- `article.tex` — editable LaTeX source.
- `verification.py` — exact finite symbolic checks, with no floating-point tolerances.
- `verification_results.txt` — saved successful output: **40 checks passed**.
- `requirements.txt` — the version of SymPy used for those checks.
- `source_audit.md` — repository snapshot, literature pointers, dependencies, and novelty limits.
- `build.sh` / `build.ps1` — local PDF build commands for Unix-like systems / PowerShell.
- `pdf_quality_check.txt` — build and rendering checks.
- `SHA256SUMS.txt` — checksums for the other package files.

## Main results

Theorem 4.3 derives the conditional residue of a nonzero rare branch from its
first nonzero Gram matrix. It gives the exact probability valuation even
when ordinary standard-part conditioning would divide zero by zero.

Theorems 5.1 and 6.2 construct an exact support-controlled effective block
and its inverse-splitting-scale dynamics. The three-level worked example
recovers a nontrivial ordinary transition probability from an infinitesimal
mediated coupling. Theorem 6.4 gives a finite-depth spectral hierarchy, and
Theorem 7.1 describes finite thermal reductions at several surreal scales.

Theorem 8.2 states the precise doubled-dimensional complex simulation of the
specified finite surquaternionic instrument model, without claiming that
all subsystem or locality structures are preserved.

Theorems 10.1–10.2 prove exact fixed-bundle charge rigidity and the sharp
valuation of the excess Yang–Mills action. Theorem 11.2 constructs the Hahn
Kuranishi map under stated ordinary Hodge–Green identities. Theorems
12.1–12.2 give a persistent leading obstruction and an attained leading
action floor. Theorem 12.3 supplies an explicit two-scale flat-torus
obstruction independent of an unconstructed irreducible background.

## Build and check

Use a TeX distribution providing pdfLaTeX, New TX fonts, AMS packages,
mathtools, microtype, geometry, booktabs, fancyhdr, hyperref, and bookmark.
A normal TeX Live or MiKTeX installation with these packages is sufficient.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `./build.sh` or `./build.ps1` in PowerShell. The scripts do
not download packages. Installing missing TeX packages is a separate local
setup step.

For the exact symbolic checks, use Python 3.9 or later:

```sh
python -m pip install -r requirements.txt
python verification.py
```

The supplied run used Python 3.13.5 and SymPy 1.14.0; consult the saved output
for the authoritative runtime version. The code uses deterministic exact
symbolic arithmetic. A failed identity raises an exception instead of
printing a successful result.

## Proof and interpretation status

The manuscript contains mathematical proofs under their stated hypotheses.
The finite symbolic checks are supplements, not formal verification of the
general theorems. They do not establish arbitrary Hahn summability,
elliptic regularity, ordinary Chern–Weil integrality, or an infinite-dimensional
quantum theory. No new Lean formalization was run or supplied.

The work builds on classical mechanisms and existing repository results.
The candidate contribution is the support- and valuation-resolved package
and its applications; priority in the literature has not been established.
The manuscript does not claim experimental evidence, a new physical law,
a singularity resolution, or an unqualified equivalence of every complex
and quaternionic quantum theory.

Repository baseline:
`934810abdde4c6d74c08777b069445de43602934`
at https://github.com/VladimirReshetnikov/Surreal.
The repository was read, not modified. Third-party papers and font files are
not included.
