# Common-Domain Linearization over Surcomplex Hahn Fields
## A rational-rank bound for nonscalar multipliers

Research article prepared for Vladimir Reshetnikov, 22 September 2026.

## Main result

Let Lambda be a finite-dimensional, ordinary complex diagonal unitary
multiplier, with no nonlinear resonance. Let tau be the exponential growth
rate of its inverse homological divisors, and let r be the rational rank of
its angles modulo the rational constants:

    r = dim_Q span_Q(1, theta_1, ..., theta_d) - 1.

For any set-sized ordered abelian group Gamma, consider

    F(z) = Lambda z + sum_{s in S} t^s f_s(z),

where S is well ordered and positive, every f_s is holomorphic on the same
polydisk D_R^d, and every f_s vanishes to order at least two. The exact
linear part is Lambda: no infinitesimal linear drift is allowed.

If tau is finite, every Hahn coefficient of the normalized linearizing
coordinate and its inverse is holomorphic on the single polydisk

    D_{R exp(-r tau)}^d.

This domain is independent of the Hahn exponent, support-word depth, rank
of Gamma, and individual coefficient norms. Finite tau is also necessary
for the corresponding universal common-domain assertion. When r = 1 the
universally guaranteed radius is sharp, including nonscalar multipliers.
For r > 1 the optimal radius is not determined; the article proves bounds.

The central new argument bounds the number of distinct positive exponential
approximation rates by rational angular rank. Together with colored-tree
contractions, it bounds divisor products at fixed internal tree complexity.
Hahn support supplies precisely that fixed-complexity condition at each
output exponent. The article gives the full proof, examples, a surcomplex
halo realization, and explicit limitations.

## Repository question

Comparison is pinned to VladimirReshetnikov/Surreal commit

    048b72cf7cbfc8ab246e4f73788c10460cb3f6e0

and, principally, to

    docs/surcomplex/dynamics-and-normal-forms/article.tex

The paragraph following the depth-dependent radius theorem explicitly
leaves the nonscalar common-domain question open. The repository already
contains a sharp scalar theorem; that theorem is not claimed as new here.
This package proposes a proved affirmative answer to the remaining
nonscalar question under the hypotheses above. No repository files were
modified. See SOURCES.md and the article's audit section for the exact
comparison boundary.

## Files

- article.tex: self-contained LaTeX source, with embedded bibliography.
- article.pdf: compiled article.
- verify.py: reproducible finite exact checks, Python standard library only.
- verification_results.txt: recorded successful output of verify.py.
- SOURCES.md: source links, snapshot identifiers, and inspection scope.
- SHA256SUMS: hashes of the delivered files other than this checksum file.

## Build

A standard TeX installation with the packages named in article.tex suffices.
No external graphics or bibliography database is required.

    latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex

Alternatively, run pdflatex repeatedly until references and the contents
stabilize. There are no bundled font files.

## Run the exact checks

Python 3.9 or later, with no third-party packages:

    python verify.py

The script checks 18,466 marked-subset contractions across 2,730 exhaustive
small colored-tree configurations, another 1,000 deterministically sampled
larger contractions, and eight exact two-component conjugacy/inverse
identities. Polynomial arithmetic uses rational real and imaginary parts;
there is no floating point or numerical tolerance. The truncation is
parameter degree at most 3 and total spatial degree at most 6.

## Research status and limitations

This is an AI-assisted, unrefereed research draft. Its main arguments have
not been independently peer reviewed or formalized in Lean. Finite exact
checks detect bookkeeping and algebra errors; they do not establish the
infinite, asymptotic, or analytic assertions.

The resolved question is a specified question in an unpublished repository
report, not a named published conjecture. The targeted literature comparison
did not locate the rational-rank theorem in the inspected material; it is
not an exhaustive proof of priority. An earlier equivalent result under
other terminology remains possible.

The theorem concerns common domains of ordinary coefficient functions in
Hahn expansions and their finite-halo realization. It does not assert
convergence after replacing t by a nonzero ordinary complex parameter, or
ordinary sequential convergence in the full surreal fine topology. No
extension to drifting multipliers, resonances, Jordan blocks, nonunitary
analytic problems, or infinite coordinate dimension is claimed.
