# Finite Positive Generation and Multiscale Theta Series over the Surreals

Research manuscript, September 22, 2026. The compiled article has 21 pages.

## Contents

- `article.tex`: complete, editable LaTeX source, including its bibliography.
- `article.pdf`: compiled article with linked contents and cross-references.
- `code/verify.py`: reproducible exact example checks (Python 3.10+, standard library only).
- `data/verification.json` and `data/verification.txt`: results from the executed checks.
- `build.sh`: rebuilds the PDF using pdfLaTeX.

## Principal results

Theorem 3.2 gives a constructive affirmative answer to Question 11.14 in
Amini and Nicolussi, *Higher rank inner products, Voronoi tilings and metric
degenerations of tori*, Annales Henri Lebesgue 8 (2025), 1109–1188,
DOI 10.5802/ahl.257. That question concerns finite positive generation of
admissible higher-rank lattices. It is an adjacent geometric question, not
one originally formulated specifically for surreal numbers. The paper
establishes the connection with surreal-valued forms and theta series.

The proof uses acute generators on a graded quotient, then a bounded
allocation of lower-level generators. It also covers non-full admissible
lattices by restriction to their real span.

Theorem 4.3 characterizes exactly which quadratic lattice exponent families
are strongly Hahn-summable. The conditions include rational radicals,
positive semidefinite successive restrictions, global mixed-pairing
annihilation, final nondegeneracy, and compatible linear terms.

Theorem 5.2 gives the exact exponent-support order type omega^s, where s is
the number of strict radical-flag drops. With positive monomial residues,
this is the actual Conway normal-form support length, not the birthday.

Theorems 6.1, 7.1, and 7.3 provide unit robustness, finite global-minimum
certificates, terminating descent on the admissible domain, and a complete
zero-cost minimizer graph with at most 2^g vertices and diameter at most g.

Theorem 8.2 lifts smooth initial theta zeros with an explicit positive
support-monoid certificate. It does not assert analogous unique behavior
at singular initial zeros or construct an abelian-variety uniformization.

## Status and scope

The article contains written proofs. It has not been independently refereed
or checked in a proof assistant. It should be read as a research manuscript
for specialist scrutiny, not as a certified priority announcement. The
claim concerning Question 11.14 is pinned to its published formulation;
the targeted literature search cannot certify absence of a later or
independent solution. The classical rank-one, Hahn-support, and
initial-form ingredients are distinguished from the proposed contributions.

The repository audit uses revision
`a3124af79f66b8b9c196d76b4cbc5ac3938907c4` of
`VladimirReshetnikov/Surreal`. It was targeted, not exhaustive.
No files in the user's repository were changed.

All theta sums are set-sized strong Hahn sums. No fine-topological or
ordinary sequential limit of finite partial sums is asserted. The article
includes explicit descending-support obstructions, an omega^2 support
example, an irrational-shear positive-generating set, and a genuinely
coupled two-scale theta zero.

## Rebuild the article

A normal TeX Live or MiKTeX installation with pdfLaTeX and the packages
listed in the source is sufficient. No external bibliography processor,
images, downloaded font files, or shell escape are required.

```sh
sh build.sh
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error
article.tex` three times. The bibliography is embedded in the source.

## Reproduce the checks

```sh
python3 code/verify.py
```

The program writes the results to `data/`. It uses exact integer and
rational arithmetic and exact signs in Q(sqrt(2)), not floating point.
It checks 5,555 allocation cases, 1,681 irrational-shear decompositions,
441 compatible linear-parameter cases, 12 Pell identities, and the
specified theta-zero row through degree eight. The minimization comparison
uses an independent exact quotientwise solution, not a guessed finite box.
All checks passed in the supplied run.

These are finite example checks. They do not machine-prove the arbitrary
rank, arbitrary support, positive-generation, or ordinal theorems. The
largest observed descent length (35) is not a general complexity bound.
The included program is not a general-purpose surreal algebra package.

## PDF checks performed

The final PDF was compiled with all references resolved and without TeX
warnings. All pages were rendered and inspected for layout; selected proof,
contents, and example pages were also inspected at higher resolution.
