# Gamma and Zeta over the Surcomplex Numbers

**Strong summation, a Hurwitz–Gamma bridge, phase choices, and exact inverse-zeta fibers**  
Research article dated September 22, 2026. Prepared with ChatGPT for Vladimir Reshetnikov.

## Read the article

`article.pdf` is the 31-page compiled article; `article.tex` is its self-contained LaTeX source, including its bibliography.

The principal results are:

- **Sections 7–9:** a strongly summable right-infinite zeta function, a faithful evaluation of the formal Dirichlet-convolution algebra, and complete integer-indexed fibers over every nonzero infinitesimal surcomplex value. The inverse coefficients have an explicit finite multiplicative-factorization formula. Their full rational-exponent sector is `log(1+u)/log(2)`.
- **Sections 5–6:** an exact formal Hurwitz–Gamma/Lerch bridge, Stirling recurrence and Gauss multiplication identities, a canonical finite-phase horn, and explicitly chosen phase extensions beyond that horn.
- **Sections 3 and 10:** exact finite-lift zero geometry, and an explicitly phase-dependent one-sided left-reflection prescription. In particular the latter can give zero or a nonzero value at `-omega`, depending on its declared phase convention.

The inverse branches are proved to exhaust the stated right-infinite, finite-imaginary-part domain. No exhaustive fiber claim is made outside that domain. The left-reflection construction is explicitly one-sided; it is not presented as a previously established global functional equation.

## Scope and research status

This is an unrefereed research draft with detailed mathematical proofs. It has **not** been verified in Lean or another proof assistant. The ordinary-complex computations are illustrations, and the exact symbolic computations check only finite truncations.

The article distinguishes existing theory, repository precedents, and proposed contributions. The Taylor–Stirling Gamma baseline and finite-phase horn already have precedents. Lagrange inversion and inverse-zeta investigations also have existing literature. No exhaustive novelty or priority claim is made, and no resolution of the classical Riemann hypothesis is claimed.

Repository inspected (read-only): `VladimirReshetnikov/Surreal`, commit
`804c63c2c675be9fd4e5086460bfa795f17a6d86`.
The inspection was targeted, not an audit of every file. No repository build was run.

## Rebuild the PDF

Use a standard TeX Live or MiKTeX installation with the ordinary packages named in the source:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Without latexmk, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times so that the table of contents and cross-references stabilize.

## Reproduce the finite checks

Python 3.10 or newer is required. The recorded run used Python 3.13.5, SymPy 1.14.0, and mpmath 1.3.0.

```sh
python -m pip install -r requirements.txt
python verification.py
```

The script writes `verification-results.json` and `inverse-coefficients.csv` next to itself. It asserts all finite symbolic identities before recording success. It also checks ordinary-complex roots of `zeta(s)=1+1e-8` on five branches, using 100 decimal digits of working precision.

The coefficient file stores exponents by exact positive rational indices `r`, standing for `log_2(r)`. A symbol `Lp` means `log_2(p)` for the odd prime `p`. This notation uses prime factorization to make logarithmic collisions exact; it assumes no algebraic independence of logarithms.

## Files

- `article.tex`, `article.pdf`: main source and compiled article.
- `verification.py`, `requirements.txt`: reproducible finite checks.
- `verification-results.json`: recorded output, including the numerical roots and residuals.
- `inverse-coefficients.csv`: all retained inverse coefficients with rational index `r < 8`.
- `source-audit.json`: inspected repository snapshot and principal external references.
- `build-quality.json`: PDF build and rendering checks, with proof-assistant status kept separate.

No font files or copies of the repository are included.
