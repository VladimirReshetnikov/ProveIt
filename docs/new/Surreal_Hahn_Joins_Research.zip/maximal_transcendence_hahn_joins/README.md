# Maximal Transcendence in Hahn Joins
## Mixed-support independence and prime omnific integers

AI-assisted research manuscript, 23 September 2026.

## Contents

- `article.pdf`: the complete typeset article (27 pages, including cover,
  contents and references).
- `article.tex`: standalone LaTeX source with embedded bibliography.
- `verify.py`: finite exact algebraic and combinatorial verification.
- `verification.txt`: output from the successful verification run.
- `build.sh`: a minimal LaTeX build and verification script.
- `README.md`: this guide.

## Mathematical contribution

The core result is a mixed-support algebraic-independence criterion over the
ordinary compositum of two full Hahn fields. Its proof uses coordinate Euler
derivations, a finite homogeneous system over one factor field, and the
noncancellation of terms in distinct exponent cosets. No convex separation of
the factor exponent groups is required.

Applications proved in the manuscript:

1. For every infinite cardinal kappa, explicit real and complex Hahn joins have
   transcendence degree exactly 2^kappa over the compositum of their two factors.
   The independent witnesses are omnific integers.
2. An explicit countable Archimedean exponent group yields continuum many
   independent witnesses of the form
   P_eta = 1 + sum_{n in B_eta} omega^(p_(2n)^(-3/2) + p_(2n+1)^(-3/2)).
   The p_n are the ordinary primes in increasing order and B_eta is the set
   of codes of nonempty prefixes of a binary branch eta.
3. Classical one-row primality, with a proved constant-term pullback and set
   localization, makes each P_eta prime in both Oz and Oz[i]. Primality itself
   is explicitly credited to the published input, not presented as new.
4. A fixed pair of explicit class-sized support subfields has an ordinal-indexed
   independent omnific family over its compositum, and no set transcendence basis.
5. In the set-sized complex examples, there are exactly 2^(2^kappa) ordinary
   automorphisms fixing the compositum, but only the identity is Hahn-strong.
   Relative derivations have the same cardinality, while the strong relative
   derivation space is zero.

The manuscript also includes ten further research questions, a dependency audit,
worked examples, failure boundaries, and a proposed Lean formalization roadmap.

## Scope and evidence

The mathematical arguments are written out, but have not been independently
refereed or checked by Lean. Novelty and priority are not certified. The work
answers the transcendence-degree part of a proposed repository question for
specified examples; it does not characterize every Hahn compositum and does not
claim to settle a named longstanding conjecture.

The finite verification is not a proof of the infinite Hahn, cardinality, or
primality assertions. It checks an exact symbolic annihilator and quotient rule,
34,112 finite Boolean patterns, and binary-prefix examples. It also includes
an explicitly labeled numerical orientation check of the first exponents.
A numeric specialization typo discovered during verification was corrected before
this release; the final article and script agree.

## Repository and literature provenance

Comparison snapshot:
`f388f950f44664f21f50f04b8ac74dab56c8ff2f`

Repository:
https://github.com/VladimirReshetnikov/Surreal

Primary target:
`docs/surreal/independent-surreal-copies/article.tex`, specifically its research
question headed "An exact description of ordinary composita".

Published specialized input:
D. Pitteloud (2001), Biljakovic--Kochetov--Kuhlmann (2006, Theorem 4.12), and the
account and generalizations in S. L'Innocente and V. Mantova,
*A factorisation theory for generalised power series and omnific integers*,
arXiv:1710.07304v5 (22 January 2024).

The repository comparison was targeted, not an exhaustive scan of all archives.
The manuscript does not rely on unreviewed full-surreal-copy constructions.

## Rebuild

Run `sh build.sh` from a system with pdfLaTeX and the standard packages listed
in the TeX preamble, plus Python 3 and SymPy. Alternatively:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
python3 verify.py > verification.txt
```

The supplied verification output was generated using Python 3.13.5 and
SymPy 1.14.0. No external data or network connection are needed to run the checks.
No figures, font files, or separate BibTeX database need to be downloaded.

## PDF checks

The final LaTeX build has no unresolved references, missing citations, overfull
boxes, or underfull-box warnings. All pages were rendered for a contact-sheet
inspection, with detailed inspection of representative title, proof, table,
and reference pages.
