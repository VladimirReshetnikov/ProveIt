# Arithmetic Tensors in the Omnific Integers

**Coefficient lattices, nonlinear Rees equations, and ideal-class phenomena
in surreal and surcomplex rings**

Research manuscript prepared for VladimirReshetnikov/Surreal, September 23, 2026.

## Contents

- `article.pdf`: the 19-page typeset manuscript, including detailed proofs,
  references, size conventions, and a source/novelty ledger.
- `article.tex`: self-contained LaTeX source; its bibliography is embedded.
- `verify.py`: exact finite arithmetic and tensor-action checks.
- `verification.json`: output from the delivered run (2,189 assertions passed).
- `requirements.txt`: the SymPy version used in that run.
- `build.py`: a cross-platform wrapper running pdfLaTeX three times.
- `provenance.json`: repository snapshot and verification boundaries.

## Principal results

For a nonzero finite coefficient lattice M in R, let L(M)=M+I, where I is the
ideal of surreal normal forms with strictly positive omega exponents.
Multiplying L(M) by a positive omega monomial produces an actual omnific ideal.

The manuscript gives an explicit tensor normal form, the complete multiplication
kernel, symmetric and exterior powers, all nonlinear Rees equations, scalar Hom
and isomorphism classifications, a number-field ideal-class realization, and
uniform dual/reflexive-hull formulas. The two-generated ideal
(omega, 2^(1/d)*omega) has its first nonlinear equation in precisely degree d.
All these constructions also have Gaussian omnific and explicit set-sized
finite-support versions.

## Build the PDF

With `pdflatex` on PATH and the packages named in `article.tex` installed:

```text
python build.py
```

Or run the following command three times:

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

No separate bibliography processor, external image, or external font file is
required. Font packages are ordinary LaTeX distribution dependencies; no font
files are included in this archive.

## Run the finite checks

Python 3.9 or later is required.

```text
python -m pip install -r requirements.txt
python verify.py --output verification.json
```

The checks use exact integers, rational arithmetic, symbolic matrices, and a
finite-support model over Q(sqrt(2)). The random test seed is fixed. Failures
raise an exception instead of silently writing a passing report.

## Proof and novelty status

The new results have English mathematical proofs and supplementary exact finite
checks, but no peer review or new Lean verification. The checked repository
snapshot is `71e9606d297c9b98c732070dc462682cc6948981`. No repository files were
changed. Existing repository formalization is not presented as a proof of the
new theorems.

Historical priority is not certified. Classical normal forms, standard
commutative algebra, and results already in the companion omnific manuscripts
are explicitly separated from the proposed contributions. No resolution of a
major named Conway factorization or refinement conjecture is claimed.

For the full proper-class ring, explicit universal carriers replace an assumed
general class-module tensor construction. Ordinary flat dimensions and
set-indexed colimits are used only in the expressly set-sized model.
