# Normalization and Arithmetic Fibres of the Omnific Integers

**Real-rooted lifts, Boolean powers, and integral surcomplex doubling**  
Prepared for Vladimir Reshetnikov by OpenAI ChatGPT, 23 September 2026.

## Files

- `article.pdf` — the 23-page article, with full proofs, a provenance audit,
  further questions, and bibliography.
- `article.tex` — self-contained LaTeX source with an embedded bibliography.
- `checks.py` — exact finite symbolic and rational checks.
- `checks.txt` — output from the completed check run.
- `build.sh` — three-pass LaTeX build followed by the checks.
- `README.md` — this file.

## Main results

Write A = Oz = Z + J, where J is the purely infinite ideal. Let N_R and
N_C be the integral closures of A in No and No(i), and set
B_R = N_R / JN_R and B_C = N_C / JN_C.

The article proves radicality of the two extended ideals, torsion-freeness
and reducedness of the quotients, and an exact characterization of those
quotients as the elements integral over Z in their rationalizations.
It identifies each quotient with a finite-partition Boolean power of the
ring of all complex algebraic integers. The Boolean algebra of idempotents
is left as an undetermined parameter, not assumed to be trivial or set-sized.

It also proves constructive real-rooted lifting and an integral isomorphism
B_C ≅ B_R × B_R. Conjugation exchanges the factors. Explicit integral
idempotents show that the splitting survives reduction modulo 2. Those
characteristic-p quotients are NOT asserted to be reduced; the paper proves
that they contain nilpotents of arbitrarily large finite orders.

Building on the repository's small-image theorem for Oz, which is credited
and reproved in the article, all set-sized domain images of N_R and N_C
are classified: they are the ring of all algebraic integers in characteristic
zero and an algebraic closure of F_p in characteristic p. The extended ideal
is exactly the common kernel of countable-domain representations. Existence
and separation of class quotient maps use the stated global-choice/class
Boolean-ultrafilter argument.

## Research status

This is a proof-bearing research draft. The normalization-fibre and integral
doubling package is proposed as an original contribution, not certified as a
historical first. The targeted literature search did not locate a matching
statement. No named classical factorization conjecture is claimed to be
resolved. Standard integral-closure algebra, Boolean constructions, and the
classical Bezout property of the algebraic integers are not claimed as new.

The written arguments have not been independently peer reviewed or checked
in Lean. The included program does not verify the surreal or class-sized
mathematics. It checks only the specific finite identities and inequalities
listed below.

## Repository provenance

Repository: https://github.com/VladimirReshetnikov/Surreal

Pinned inspection commit:
`befe739b56f4f0d7298d9232e8bb74e0de9f1eea`

The audit covers the documentation catalogue and selected relevant source
manuscripts, not all Git history or all Lean declarations. In particular,
the inspected catalogue says that nine manuscripts from the recent
omnific delivery still awaited integration. The article explicitly records
this limitation. No repository files were modified.

## Verification performed

The delivered PDF was built successfully with pdfTeX 1.40.26. The final
LaTeX pass reported no undefined references, LaTeX warnings, or overfull or
underfull boxes. The document has 23 PDF pages (the title page is unnumbered).
All pages were rendered and inspected in page contact sheets; selected
proof and front-matter pages were also inspected at a larger scale.

The exact checks ran successfully with Python 3.13.5 and SymPy 1.14.0:

- 5 integral-unit and idempotent identities;
- 6 rational doubling identities;
- 12 finite spectral-projector identities;
- 14 Catalan coefficient checks;
- 216 rational endpoint tests, covering 24 polynomials of degrees 1 through 8.

All 253 primary checks passed. These are finite checks, not formal theorem
verification. The program contains additional guard assertions around the
reported primary checks.

## Rebuild

Required: a standard LaTeX installation with pdfLaTeX, Latin Modern,
AMS packages, mathtools, aliascnt, cleveref, hyperref, geometry, microtype,
booktabs, enumitem, fancyhdr, and xcolor; Python 3.10+ with SymPy for the
optional computational checks.

On a Unix-like system:

```sh
bash build.sh
```

Alternatively, from this folder, run the following on any platform with
these commands available:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
python checks.py
```

No external graphics, font files, or separate bibliography files are required.
