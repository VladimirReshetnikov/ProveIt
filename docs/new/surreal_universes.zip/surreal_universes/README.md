# Surreal Fields Across Set-Theoretic Universes

**Fresh gaps, exact saturation thresholds, and surcomplex real forms**  
Research manuscript prepared with ChatGPT, 22 September 2026.

## Files

- `surreal_universes.pdf` — the 21-page article, including contents and references.
- `surreal_universes.tex` — self-contained LaTeX source with an embedded bibliography.
- `check_finite_signs.py` — small finite sign-order and block-code regression tests.
- `finite_checks.json` — output from the executed regression tests.
- `PROOF_STATUS.md` — scope of the mathematical claims and verification.

## Main results

Let M be a transitive inner model of the ambient universe N, with the same
ordinals, in the class-theoretic framework stated in the article. Put F = No^M.
All external sets, cardinalities, and cofinalities below are computed in N.

1. Set-presented gaps of F are canonically in bijection with fresh sign
   sequences: new sequences all of whose proper prefixes belong to M. Each
   such gap is symmetric, with both cofinalities equal to the N-cofinality
   of the sign's ordinal length.
2. The least size of an omitted separated pair is exactly the least length
   of a new ordinal-valued sequence. For uncountable cardinals kappa,
   external kappa-saturation of F is equivalent to no new ordinal sequences
   of length below kappa. Finite-parameter saturation instead detects
   whether new reals have been added.
3. Pure surcomplex fields retain saturation over all ambient sets of
   parameters and are class-isomorphic. Transporting conjugation yields
   nonconjugate real forms distinguished by the gap invariant, although
   all have no set-sized cofinal subset. Suitable finite forcing towers
   yield arbitrarily long finite lists, with all involutions agreeing on
   every ordinary complex number.

The article gives written proofs and distinguishes the proposed new surreal
applications from classical ingredients and prior results in the repository.
It does not claim to resolve a named published open conjecture or certify
historical priority.

## Build the PDF

Use a current TeX Live or MiKTeX installation with the standard packages
listed in the preamble, including `newtx`, `amsmath`, `geometry`, `microtype`,
`tocloft`, `hyperref`, and `cleveref`.

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode surreal_universes.tex
```

Alternatively run `pdflatex` three times. There is no external `.bib`, no
external figure, no shell escape, and no downloaded font dependency.

## Run the finite regression checks

Python 3.9 or newer; standard library only:

```sh
python check_finite_signs.py --output finite_checks.json
```

Executed result: 127 finite sign strings, 16,129 ordered-pair comparison
checks, 127 prefix-cone convexity checks, 340 block-code cases, and 1,744
nested endpoint pairs; all passed. These are not tests of transfinite
freshness, forcing, saturation, or class-field isomorphisms.

## Repository comparison

Repository: `VladimirReshetnikov/Surreal`  
Pinned revision: `4f2645599121fa872c7104995e47f86f0382351f`.

Inspected material includes the main README, documentation catalogue,
foundations README, and relevant source sections of
`docs/surcomplex/surcomplex-field-automorphisms/article.tex`.
The existing nonconjugate-real-form and class-back-and-forth constructions
are acknowledged as prior work. The new target is the exact ground-surreal
gap calculation and its use to separate real forms with the same
no-set-cofinality property. This was not an exhaustive repository or
historical-literature audit.
