# Effective Notations for Omnific Integers

**Rational–omega expressions, decidable equality, computable integer parts,
and sharp representation barriers**

Research article prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.pdf`: typeset article, with linked contents and bibliography.
- `article.tex`: complete self-contained editable LaTeX source.
- `code/omega_notation.py`: exact-arithmetic research prototype.
- `code/verify.py`: reproducible finite regression tests.
- `data/verification.json`: recorded test result and individual assertion names.
- `data/provenance.json`: reviewed repository snapshot, source scope, and claim status.
- `CLAIMS.md`: brief novelty and verification ledger.
- `requirements.txt` and `Makefile`: dependency and build instructions.

The article defines F as the values of finite expressions built from exact
rational constants, field operations, and Conway's omega map Ω(x) = ω^x.
This is NOT the full surreal exponential. Its omnific subring is A = F ∩ Oz.

The main results give equality/order decision procedures, an effective
separated-grid compiler, omnific membership, exact truncations at represented
exponents, coefficient extraction, and the omnific floor. The article also
proves an exact ε₀ ordinal trace, a sharp ω^ω support barrier, explicit values
outside F, and an always-valid stream presentation with Π⁰₁-complete equality.
The no-compiler theorem persists even for values with at most one supported
term that individually belong to F at omega-depth two.

## Rebuild the article

Run from this directory with a standard TeX installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. No BibTeX/Biber, external graphics, or supplied font files are
needed. `make pdf` performs the latexmk build where Make is available.

## Reproduce the exact checks

Use Python 3.9 or newer. A virtual environment is recommended.

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

On Windows, `py` can replace `python`. The recorded run used Python 3.13.5
and SymPy 1.14.0. It passed 197 exact assertions. The runner exits with an
exception if a check fails and rewrites `data/verification.json` on success.
The tests require no network access after dependencies are installed.

## Example

From this directory, start Python with `code` on the import path:

```python
import sys
from fractions import Fraction
sys.path.insert(0, "code")
from omega_notation import (
    om, equivalent, is_omnific, omnific_floor,
    truncate_at, coefficient_at,
)

w = om(1)
B = om(w) / (1 - 1/w)
assert is_omnific(B)                          # Infinite normal-form support.
assert not is_omnific(B + Fraction(1, 2))
assert equivalent(omnific_floor(B - 1/w), B - 1)
assert coefficient_at(B, w - 3) == 1
assert equivalent(truncate_at(B, w - Fraction(3, 2)),
                  om(w) + om(w - 1))
```

Use `equivalent(x, y)` for semantic equality, not Python object equality.
Construct exact rational constants with integers or `fractions.Fraction`;
floating-point literals are rejected. Ordinary powers accept only integer
exponents; use `om` explicitly for Conway's omega map. The supplied interface
is Python construction, not a parser for arbitrary mathematical notation.
Public factory operations preserve representation invariants; directly
constructing malformed internal `Value` objects is unsupported.

## Status and scope

The proofs are research-draft arguments, not independently refereed or
Lean-checked results. Finite tests are not proofs of the infinite or
computability theorems. No halting oracle is implemented. The prototype is
not a complete surreal computer algebra system, and it makes no uniform
complexity or production-readiness promise.

The inspected repository snapshot is
`a45d72292a46dac13300d395101df188efb84eef` of
`VladimirReshetnikov/Surreal`. The review read relevant index/README/bridge
notes; it did not audit the entire repository, read the full merged
computability report, or run a Lean build. No repository files were changed.

The targeted literature review did not establish publication-wide novelty.
The article explicitly distinguishes proposed effective formulations from
classical normal forms, general truncation closure, computability facts,
and standard algebraic certificates. See `CLAIMS.md` and the source review
in the article before treating any result as a priority claim.
