# A Single-Loss Theorem for Exact-Multiplier Surcomplex Linearization

Research draft prepared with ChatGPT, 22 September 2026.

## Main result

For a one-variable positive-support Hahn perturbation

    F(z) = lambda*z + sum_gamma t^gamma f_gamma(z),

with an **exact** irrational unit multiplier, f_gamma(0)=f_gamma'(0)=0,
and every input coefficient holomorphic on the same disk of radius R,
put

    tau = limsup_n log^+(1/|lambda^n - 1|) / n.

If tau is finite, every coefficient of the normalized linearizer and its
inverse is holomorphic on the same disk of radius R*exp(-tau). The radius
loss occurs once, independently of Hahn coefficient order. A single
positive-exponent perturbation with g(z)=z^2/(R-z) proves this universal
radius is sharp. If tau is infinite, the same example has a forced first
coefficient of radius zero.

The proof uses a small-divisor bound for positively weighted rooted trees,
a polynomial count at fixed tree size, and positive-support word finiteness.
An additional operator proof reaches the same result in the inverse
coordinate convention.

## Scope and status

This resolves the **one-dynamical-variable case** of the repository's
exact-multiplier common-domain question. It does not solve the general
several-variable case, nor the drifted-multiplier/cyclic-value-group question.
Several formal parameters are allowed, but that is different from several
dynamical variables.

The conclusion is coefficientwise Hahn analyticity, including actual
surcomplex halo evaluation in set-sized workspaces. It does not assert
ordinary convergence after replacing a Hahn monomial by a nonzero complex
parameter, uniform coefficient norm bounds, or fine-topology convergence.

The draft is not peer-reviewed and is not formally verified in Lean or
another proof assistant. The finite checks do not prove the infinite
analytic theorem. Novelty is assessed by a targeted comparison, not by
an exhaustive priority determination. Classical tree expansions and
Hahn support lemmas are explicitly credited in the article.

## Files

- `single_loss_linearization.tex`: standalone article with internal bibliography.
- `single_loss_linearization.pdf`: compiled article.
- `verify.py`: finite exact standard-library Python verification program.
- `verification.json`: recorded successful verification run.
- `Makefile`: PDF build and verification targets.
- `repository_scope.md`: pinned provenance and precise relation to the open question.
- `build_report.json`: compilation and PDF inspection record.

## Build

A standard LaTeX installation with the packages named in the preamble is
sufficient. No external bibliography, images, network access, or shell
escape is needed.

    pdflatex -interaction=nonstopmode -halt-on-error single_loss_linearization.tex
    pdflatex -interaction=nonstopmode -halt-on-error single_loss_linearization.tex
    pdflatex -interaction=nonstopmode -halt-on-error single_loss_linearization.tex

Alternatively run `make pdf`.

## Reproduce finite checks

Python 3.10 or later; no third-party dependencies:

    python verify.py

To save a new record:

    python verify.py --output fresh-verification.json

The program refuses to overwrite an existing output file. The delivered
record is not changed by the default invocation or by `make verify`.

The tests cover 83,996 divisible-subtree packing cases, 33,030 finite
rational approximation cases, and formal conjugacy/inverse computations
through parameter order four and Taylor degree eight. Their precise
scope and limitations are in Section 10 of the article.
