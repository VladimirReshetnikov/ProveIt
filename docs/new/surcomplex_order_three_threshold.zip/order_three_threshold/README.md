# The Order-Three Threshold for Entire Hahn–Surcomplex Functions

**Second-order rigidity, Newton-corner spectra, and sharp theta examples**  
Prepared for Vladimir Reshetnikov — 23 September 2026

## Main result

Over K = k((t^Gamma)), with k of characteristic zero and Gamma any ordered
abelian group, a strongly entire power series satisfying a nonzero algebraic
differential equation of order at most two is a polynomial. Equivalently,
every nonpolynomial strongly entire f has algebraically independent f, f', f''
over K(z). Differentiation is in the external variable z and fixes K.

Combined with the prior theta construction and the prior no-order-unit
obstruction, this gives an exact threshold: the minimum possible differential
order is three when Gamma has an order unit, and no finite order is possible
for a nonpolynomial strongly entire function otherwise.

The new proof answers the explicit order-two question in the earlier project
manuscript *Theta Descent and the Exact Boundary of Differential Rigidity*.
The theta identity itself is classical; the theta descent and no-order-unit
obstruction are credited as prior work, not presented as new discoveries.

## Contents

- `article.pdf`: the complete 26-page article, including nine research questions.
- `article.tex`: standalone source, with its bibliography included.
- `code/verify.py`: exact finite symbolic checks and rational q-adic computations.
- `data/verification.json`: recorded results; all 600 checks passed.
- `data/build_report.json`: compilation and PDF-validation record.
- `SOURCE_AUDIT.md`: provenance, source scope, and novelty boundaries.
- `requirements.txt`: Python dependency for the finite checks.
- `SHA256SUMS.txt`: hashes of the package files other than the hash list itself.

## Build the article

A TeX installation with pdfLaTeX and the packages named in the source is needed,
including Libertinus, AMS mathematics, microtype, hyperref, and the standard
layout/table packages. No font files are distributed in this package.

From this directory:

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex
```

Alternatively run this command three times to stabilize the contents and
cross-references:

```sh
pdflatex -halt-on-error -interaction=nonstopmode article.tex
```

The source is self-contained; no BibTeX database, external diagram, or private
source manuscript is needed to compile it.

## Reproduce the finite checks

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

The script writes `data/verification.json`. It was run with Python 3.13.5 and
SymPy 1.14.0. The code uses Python 3.9-compatible syntax, but those older Python
runtimes were not separately tested.

The 600 checks include the complete cleared theta differential identity and
Jacobi product through q^47, with each coefficient compared exactly in Q[z];
a symbolic arbitrary-gap binomial identity; all 242 nonzero polynomials with
degree at most four and coefficients in {-1,0,1} in the initial-form test;
and the independent Euler-jet and residue calculations.

## Scope and proof status

The article contains complete written arguments. The finite program is a check
on algebra and transcription, not a formal verification of arbitrary supports,
all value groups, or all scales. No new Lean verification, independent referee
report, or certified bibliographic priority is claimed.

Entireness is relative to a specified Hahn field. The theta example is not
strongly entire on the whole proper class No(i). The external derivative is not
the Berarducci–Mantova derivation. Omnific zero rounding is inherited from the
prior construction and is labeled accordingly.

Repository baseline: `b895e8672990e8b5a56f97dd7246f9dd5f86c771`.
