# Fredholm Windows and the Unavoidable Infinitesimal Spectrum

A 25-page research article prepared for the Surreal project, dated
September 22, 2026. The standalone LaTeX file has an internal bibliography.

## Files

- `article.tex`: complete article, statements, proofs, examples, and provenance appendix.
- `article.pdf`: compiled and visually inspected PDF.
- `code/verify.py`: deterministic exact finite checks (SymPy).
- `requirements.txt`: the tested symbolic-algebra dependency.
- `data/verification.json`: recorded result: **1,268 checks passed**.
- `data/build_report.json`: compilation and PDF inspection information.
- `PROVENANCE.md`: repository pin, literature scope, and claim boundaries.
- `build.sh`: reproducible PDF build; optional finite verification.

## Principal results

Theorem 6.1 computes both the algebra-relative and module-bijectivity spectra
of `A = T + E` on `H((t^Gamma))`. Here `H` is an ordinary infinite-dimensional
separable complex Hilbert space, `T` is ordinary injective compact
self-adjoint, and `E` is a self-adjoint Hahn series of bounded operators
with strictly positive valuation. The exponent group is nonzero, set-sized,
ordered, and divisible; no rank-one or commutation assumption is made.
The spectrum consists of the entire complex infinitesimal monad of zero
and finite Hermitian eigenvalue clusters over the nonzero ordinary
spectral values of `T`. The monad contains no eigenvalues and has a
persistent infinite-dimensional cokernel. Corollary 6.2 identifies the
algebraic Fredholm spectrum; Corollary 6.3 distinguishes point-spectrum
invariance from spectral-monad growth under exponent-group enlargement.

Theorem 7.1 gives an explicit positive self-adjoint example with trace-class
coefficients and individually defined eigenbranches but no global unitary
diagonalizer in the bounded-coefficient Hahn algebra. Theorems 9.1 and 9.2
show that the same example has a well-defined coefficientwise trace and
Fredholm determinant but no coefficientwise ordinary eigenvalue trace sum
or eigenvalue determinant product. Exact finite boundary identities explain
both failures.

Theorem 8.4 constructs an exact Hahn Fredholm alternative on the
nonnegative valuation component of the coefficientwise trace-class ideal.
Theorem 10.1 describes its finite-coupling analytic determinant.
Theorem 10.5 rules out a coherent analytic characteristic function through
the spectral accumulation monad. Section 11 gives actual surreal scales
`omega^-1` and `omega^-omega` and a multiple-cluster support example.

## Build

A standard TeX Live installation with the packages named in `article.tex`
is sufficient. From this directory:

```sh
./build.sh
```

To run the finite checks as well:

```sh
python3 -m pip install -r requirements.txt
./build.sh --verify
```

The commands can also be run separately:

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex
python3 code/verify.py --output data/verification.json
```

The check script was tested with Python 3.13.5 and SymPy 1.14.0. It uses
only exact rational and symbolic arithmetic. Its runtime and timestamp
will vary; the deterministic mathematical checks use seed 20260922.

## Evidence and limitations

The proofs are mathematical arguments, not proof-assistant certificates.
The finite checks do not prove the support lemmas, infinite-dimensional
spectral classification, continuum-dimensional range defect, or universal
nonexistence statements. Classical compact spectral theory, Hahn support
theory, finite Hermitian algebra, and ordinary Fredholm determinant theory
are explicitly credited.

The range-factorization theorem is already in the repository and is
re-proved as an inherited input, not claimed as new. The novelty assessment
is a targeted comparison at revision
`048b72cf7cbfc8ab246e4f73788c10460cb3f6e0`, not an exhaustive priority audit.
No named published conjecture is claimed solved. The candidate additions
are identified separately in the article and `PROVENANCE.md`.

No repository files were modified or uploaded by this work.
