# Ramification in Omnific Normalizations

**Nilpotent fibres, Boolean splitting, and exact scale refinement**  
AI-assisted research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Read the article

`article.pdf` is the 25-page typeset article. `article.tex` is the standalone
LaTeX source, with its bibliography included. It contains complete conventional
proofs, a nine-question research agenda, a resolution ledger, and a discussion
of verification and novelty limits.

The setting is an actual cyclic surreal or surcomplex workspace:

    T = omega^a, a > 0
    (k,D) = (R,Z) or (C,Z[i])
    A = D + T k[T] inside F = k((T^-1))
    N = integral closure of A in F
    B = integral closure of k[T] in F
    I = (T k[T]) N

The main results include explicit nilpotents of every finite order in N/I;
the exact index ceil(n/m) after T=U^m; the identity I=TB and a finite-branch
normalization criterion; a reduced bounded-denominator Puiseux limit;
fixed-workspace Boolean atomlessness and exact cardinal invariants; and
periodic homology over the *coefficient* fibre B/TB. The analogous periodic
complex over the *arithmetic* fibre N/I is proved not to be exact.

The results answer the fixed-cyclic cases of two questions recorded in the
repository, not the general classification of all exponent groups. They are
unrefereed and not proof-assistant checked. Priority is not certified.

## Files

- `article.pdf` — typeset article.
- `article.tex` — complete LaTeX source with internal bibliography.
- `verify.py` — exact finite regression checks, Python standard library only.
- `verification.json` — recorded output of the checks, including their scope.
- `RESEARCH_AUDIT.md` — source pin, proof dependencies, and limitations.
- `BUILD_REPORT.json` — compilation and document checks.
- `build.sh` / `build.ps1` — build and test commands for Unix or PowerShell.

## Rebuild

Install a LaTeX distribution with pdfLaTeX and the packages listed at the
beginning of `article.tex` (ordinary TeX Live/MiKTeX packages), plus Python 3.9
or later. No BibTeX run is needed. From this directory:

```text
python verify.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `bash build.sh` or `pwsh -File build.ps1`. The scripts stop
on failure. Rebuilding a PDF can change its byte hash because of PDF metadata;
that is not by itself a content difference.

The finite checks do not establish integral closure, arbitrary-support
summability, existence of prime extensions, transfinite cardinality results,
or exactness of an infinite resolution. The proofs of those statements are
in the article. Neither Lean nor the Surreal repository build was run.

## Repository baseline

The comparison is pinned to:

    343dc2c471212bb9b53ff4623bace2e1943f255b

The key source is
`docs/surreal/set-sized-quotients-of-omnific-integers/article.tex`, especially
`osq:nf:q:fibre`, `osq:q:normalization`, `osq:bb:thm:descent`, and
`osq:bb:thm:rational`. The article and audit identify what is prior material
and what is proved here.
