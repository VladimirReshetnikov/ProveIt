# Polynomial Rigidity of Omnific Integer Lattices

**Sharp ordinary-output dichotomies, canonical translations, and rational maps**  
Research draft prepared for Vladimir Reshetnikov, September 23, 2026.

## Contents

- `article.pdf`: the compiled 21-page article, including proofs, bibliography, and source audit.
- `article.tex`: self-contained LaTeX source; no external graphics or bibliography files.
- `verify.py`: exact finite regression checks using SymPy.
- `verification_results.json`: output of the executed checks: **499 assertions passed**.
- `requirements.txt`: the SymPy version used for those checks.
- `build.sh`: a clean, three-pass PDF build, without leaving LaTeX auxiliary files here.
- `build_report.json`: compilation, rendering, and verification scope.

## Main results and locations

Write `(A,D) = (Oz,Z)` or `(Oz[i],Z[i])`. All polynomial degrees are ordinary finite ones.

**Theorem 3.3 (abstract discrete-ring theorem).** If a degree-d polynomial preserves a discretely ordered ring B, or its Gaussian complexification, then its ordinary-output locus has at most d inputs, unless the polynomial is an ordinary integer-valued polynomial after translating its input. In the latter case the locus is exactly one translate of the ordinary lattice. The exceptional bound is sharp for every positive d.

**Theorems 5.1–5.2 (canonical omnific form).** An omnific integer-preserving polynomial with more than d ordinary-output inputs satisfies

    f(X) = ct(f)(X - eta),       f^(-1)(D) = eta + D,

for a unique purely infinite eta. Its candidate is read from its top two coefficients:

    eta = -(a_(d-1) - ct(a_(d-1))) / (d * a_d),

provided the leading coefficient is ordinary. A single polynomial translation and coefficient comparison tests the identity, relative to exact coefficient operations.

**Theorem 6.1 (translated targets).** In degree at least two, at most one translated target `b + D` has more than d preimages. Such a target exists exactly for a polynomial obtained from its ordinary reduction by a purely infinite input translation and output translation.

**Theorem 7.1 (composition).** For nonlinear translated ordinary polynomials

    f = p(X - eta) + beta,       g = q(X - xi) + gamma,

a rich translated target for `f o g` exists exactly when `gamma = eta`. The article gives the exact nonzero coefficient obstructing the misaligned case.

**Further deductions.** The article classifies integer-valued polynomials in finitely many variables, gives finite testing sets, directly proves rational-to-polynomial rigidity, classifies every surjective rational self-map as `u*X+b` with ordinary unit `u`, and reduces matrix and truncated-jet preservation to the ordinary coefficient ring.

## Provenance and limits

The sharp ordinary-output, canonical translation, rich-target uniqueness, and composition-alignment statements are proposed contributions. They were not located in the inspected sources; this is not a guarantee of historical priority. Appendix A records the repository reference, inspected files, and limits of the search.

The constant-term framework, ordinary integer-valued-polynomial theory, and D-ring precedent are classical or prior repository context. In particular, rational-to-polynomial collapse is explicitly **not** presented as a new general D-ring theorem. No named longstanding conjecture is claimed solved.

The proofs are written mathematical arguments, not Lean-checked proofs or peer-reviewed results. The program tests exact identities and restricted finite-support models `Q[H]` and `Q(i)[H]`. It does not implement arbitrary surreal arithmetic, prove the general theorems, or verify historical novelty.

## Build

A LaTeX installation with pdfLaTeX and the packages listed in the preamble is required. The delivered PDF was built with TeX Live 2022.

```sh
bash build.sh
```

The shell script only rebuilds the PDF. The equivalent basic compilation is repeated pdfLaTeX runs on `article.tex`; the bibliography is embedded.

## Run the checks

Tested with Python 3.13.5 and SymPy 1.14.0. A separate environment is recommended for reproducibility.

```sh
python -m venv .venv
# Activate the environment using the command appropriate to your shell.
python -m pip install -r requirements.txt
python verify.py
```

The script exits with an error at the first failed assertion. On success it prints a JSON report and updates `verification_results.json` beside the script. Its timestamp records the local execution, so rerunning changes that field.
