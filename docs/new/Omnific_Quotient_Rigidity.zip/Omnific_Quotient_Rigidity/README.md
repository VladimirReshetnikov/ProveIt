# Small Quotients and Large Internal Fields of the Omnific Integers

**Constant-term rigidity, surcomplex embeddings, and a Cantor algebra in a principal quotient**

Research manuscript prepared for Vladimir Reshetnikov, 22 September 2026.

## Files

- `article.pdf` — the 27-page typeset article, including bibliography and two appendices.
- `article.tex` — self-contained LaTeX source; no external figures or bibliography files.
- `verify_finite.py` — reproducible exact finite algebra checks.
- `verification_results.json` — results of the 621 named checks, all passed.
- `SOURCE_AUDIT.md` — inspection scope, sources, and novelty limitations.
- `requirements.txt` — the SymPy version used for the finite checks.

## Main results

The main theorem proves that every unital homomorphism from the full class ring
of omnific integers to a set-sized ring factors uniquely through the integer
constant term. The target may have zero divisors and nilpotents and need not
be commutative. The coefficient-ring version also treats Gaussian omnific
integers. The article deduces classifications of small quotients and small
modules, and identifies the arithmetic profinite and prime-adic completions.

A complementary localization theorem shows that making any nonzero purely
infinite element invertible forces a copy of the full surreal field into
the target. The complex version forces a copy of the surcomplex field.

For every positive surreal exponent a, the nonzero quotient Oz/(1 + omega^a)
contains a surcomplex field and an explicitly embedded algebra of locally
constant functions on the 2-adic integers, with coefficients in an
algebraically closed class field. It has an infinite family of nonzero
orthogonal idempotents and fails the ascending chain condition on ideals,
yet has no unital homomorphism to any nonzero set-sized ring.

The key exact-kernel theorem rules out extra polynomial relations arising
from arbitrary ambient surreal exponents. The Cantor algebra is a specified
subalgebra, not a claimed classification of the entire quotient.

## Build and verify

A standard TeX Live installation with the packages used in `article.tex`
suffices. The bibliography is embedded in the source.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
python -m pip install -r requirements.txt
python verify_finite.py --output verification_results.json
```

Repeated runs of `pdflatex article.tex` can replace `latexmk`. The verification
script requires Python 3.10 or later. It makes no network requests.

## Status and limitations

This is an AI-assisted research manuscript, not an independently refereed
publication. Its main statements are presented as candidate-original
contributions with full mathematical proofs. No identical formulation was
located in the targeted sources inspected, but historical priority is not
certified. No resolution of Conway's refinement conjecture is claimed or used.

The finite checks are not a representation of arbitrary surreal numbers and
do not verify the class-size or infinite-support arguments. No Lean proof
or local build of the linked Surreal repository was performed. The article
states its classical normal-form/Hahn prerequisites and makes the set/class
and strong-summation/topological-limit distinctions explicit.

The source repository was inspected at commit:
`37eefca1a309a967d8c8237606ccf6290475adfa`.
