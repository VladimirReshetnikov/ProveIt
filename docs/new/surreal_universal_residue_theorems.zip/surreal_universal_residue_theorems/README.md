# What Set-Sized Algebra Can See of Surreal Arithmetic

**Universal residue theorems for omnific integers and surcomplex rings**  
Research manuscript prepared for the Surreal project, 22 September 2026.

## Files

- `article.pdf`: the compiled 24-page article.
- `article.tex`: the complete editable LaTeX source, including bibliography.
- `verify_identities.py`: deterministic exact finite checks, requiring Python 3.9+ and no third-party Python packages.
- `verification.json`: the resulting finite-check report.
- `SOURCE_AUDIT.md`: provenance, repository snapshot, and verification boundaries.
- `build_report.json`: compilation, rendering, and package checks.
- `Makefile`: optional build commands.

## Main results

Theorem 5.1 proves that every unital ring homomorphism from `D + J_k` to an arbitrary set-sized ring factors through the constant coefficient in `D`. Here `k` is the ordinary real or complex coefficient field; `J_k` consists of set-supported normal forms on strictly positive surreal exponents. The target need not be commutative. Taking `D = Z`, `k = R` gives the full omnific integer ring.

Theorem 7.2 proves the parallel statement for `D + m_k`, with strictly negative supports, and hence the universal property of standard part on finite surreal and surcomplex rings.

Theorem 11.1 shows that countably supported forms already suffice for both universal properties. Finite supports do not: summing the finitely many coefficients defines a counterexample homomorphism. The full surreal exponent class is retained throughout this support-threshold statement.

The article derives complete classifications of set-realizable quotients and set-sized modules, restrictions on derivations, and the absence of nonzero set-sized representations after inverting a single element of the residue kernel. It also gives target-cardinality lower bounds in fixed Hahn workspaces, where the full-class collapse theorem is false.

## Status

The article contains mathematical proofs, not a Lean formalization. The central countable telescoping mechanism has a direct precursor in L'Innocente–Mantova, Remark 3.4.4; it is explicitly credited. The proposed new contribution is the universal factorization and support-threshold package, not the basic geometric-series identity or the previously developed finite-quotient arithmetic.

A bounded literature and project comparison did not identify the exact universal statements. Publication priority has not been established, and the manuscript is unrefereed. It does not claim to resolve a named published open conjecture.

The Python checks establish only finite identities and counterexample illustrations. They do not verify countable Hahn multiplication, class quantification, or novelty. No Lean build or kernel verification of the new theorems was performed.

## Build

Run:

```sh
python3 verify_identities.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

On Windows, use `python` in place of `python3` when that is the installed command.

Alternatively, run `make` in an environment with Python 3 and pdfLaTeX installed. Standard LaTeX packages used by the source include `amsmath`, `amsthm`, `mathtools`, `lmodern`, `microtype`, `geometry`, `booktabs`, `longtable`, `enumitem`, `fancyhdr`, `needspace`, `hyperref`, and `bookmark`. No BibTeX run or image asset is needed.

The inspected repository snapshot is `cd80e5e0adc2a1a25e8cc64d52abc8acb093d801`. The archive does not modify the repository and does not bundle third-party manuscripts or font files.
