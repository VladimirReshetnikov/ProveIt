# Low-Order Nonlinear Rigidity at Surreal Scales

**Newton transitions, Euler-jet geometry, and omnific coefficient descent**  
Prepared for Vladimir Reshetnikov, 23 September 2026.

## Main result

Over `K = k((t^Gamma))`, where `k` is trivially valued of characteristic zero
and `Gamma` is a nonzero set-sized ordered abelian group, every strongly
entire solution of an algebraic differential equation of order at most two
is a polynomial. There is no restriction on differential degree or value-group
rank. There is also a third-order result for differential degree at most three,
and a more general first-polar criterion.

The article proposes a proof of the unrestricted second-order case of the
nonlinear question identified as Question 19.1 (`hol:q:nonlinear`) in the
repository's holonomic report. It does **not** claim the unrestricted all-order,
order-unit case, historical-priority certification, independent refereeing,
or a Lean-checked proof.

`d/dz` kills every scalar constant. It is NOT the Berarducci–Mantova derivation.
“Entire” means strong Hahn summability over one specified Hahn field, NOT over
the full surreal/surcomplex class. External constants in a polynomial relation
are allowed by finite coefficient descent, without changing that analytic domain.

## Contents

- `article.tex`: standalone LaTeX source, internal bibliography, no external figures.
- `article.pdf`: compiled 24-page article, including ten research questions.
- `PROOF_AUDIT.md`: critical proof steps, scope and verification limits.
- `SOURCES_AND_SCOPE.md`: exact repository pin, inspected source paths and literature scope.
- `code/verify.py`: reproducible exact finite algebraic certificates.
- `data/verification.json`: recorded successful run (259 assertions).
- `data/build_audit.json`: PDF compilation and layout audit summary.
- `requirements.txt`: computational verification dependency.
- `build.py`: optional portable build/verification helper.

## Rebuild

A reasonably complete TeX Live or MiKTeX installation with `pdflatex` is needed.
The article uses standard packages, including Latin Modern, AMS mathematics,
`microtype`, `booktabs`, `tabularx`, `xurl`, `hyperref`, and `bookmark`.
No BibTeX run or external graphics are required.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Or use the portable helper:

```sh
python build.py
```

For exact finite checks (Python 3.9+):

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

Or run checks and rebuild together:

```sh
python build.py --verify
```

The recorded run used Python 3.13.5 and SymPy 1.14.0. The tests verify finite
identities and finite Newton windows. They do not certify quantified claims
about all infinite supports, the complete mathematical proof, or novelty.

## Repository comparison

`VladimirReshetnikov/Surreal` at
`3d40856953f4bb0f5d069e45a3b4bab6eda33040`.

The comparison used targeted README and scope/audit reads, not a complete
line-by-line review of every report or the Lean formalization. The repository
was not built during preparation of this delivery. Existing repository proof
coverage does not certify the new results.

No third-party papers or font files are bundled.
