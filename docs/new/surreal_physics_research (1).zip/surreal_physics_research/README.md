# Surreal Scales in Quantum Operations, Soft-Mode Reduction, and Non-Abelian Interferometry

**Exact residue theorems, rare-event amplification, and limits of scalar extension**

Research article prepared for Vladimir Reshetnikov, 23 September 2026.

## Read the article

- `article.pdf` — the typeset article, including full proofs, examples, audit, and references.
- `article.tex` — standalone LaTeX source with an internal bibliography.
- `code/verify.py` — deterministic exact rational and symbolic example checks.
- `code/build.sh` — verification and PDF build script.
- `requirements.txt` — tested Python dependency.
- `data/verification.json` — recorded results: 1,861 assertions passed.
- `data/build_validation.json` — build and PDF inspection record.
- `RESEARCH_AUDIT.md` — repository and literature inspection boundaries.

## Principal results

The main fixed-shadow classification concerns a limited positive-semidefinite
Hermitian block matrix H with a positive-definite eliminated block D. For a fixed
ordinary shadow H0, every possible standard part of A - B D^{-1} B* is exactly

    S0 - Delta,  where 0 <= Delta <= S0 and rank(Delta) <= dim ker(D0),
    S0 = A0 - B0 D0^dagger B0*.

Every permitted defect is realized using ordinary matrices and a single positive
infinitesimal. A nonzero defect in a retained direction requires an unlimited
unrestricted minimizing displacement. A separate gap-relative bound distinguishes
static relaxation from an energy-dependent Feshbach reduction.

The quantum results include a leading-Gram formula for arbitrary finite rare
Kraus branches and the sharp bound

    max(p,q) D(conditional outputs) <= D(inputs).

The quaternion application identifies an exact, state-independent heralded
unitary at the dark port of a controlled SU(2) loop. For a commutator c, its
success probability has valuation twice that of c - 1. The article includes
amplitude precision, incoherent background, entanglement-filtering, and real-family
specialization results.

## Status

This is an AI-assisted mathematical research draft, not a refereed paper.
Full mathematical proofs are supplied relative to standard real-closed Hahn-field
foundations. No Lean formalization or independently verified repository build is
claimed. The exact checks cover finite identities and examples, not the general
theorems or arbitrary Hahn supports.

The fixed-shadow classification and the combined quantum/gauge application are
candidate contributions. No first-in-literature status or solution of a named
open conjecture is claimed. Classical ingredients and existing repository
coverage are distinguished in the article. No new empirical physics, universal
metrological advantage, ultraviolet regularization, or singularity resolution is
asserted.

All matrix dimensions, circuit lengths, and trial counts in the algebraic model
are ordinary finite integers. Reciprocal success probability describes independent
real trial budgets, not a universal quantum gate-complexity lower bound.

## Build

Python 3.10 or later and SymPy are needed for the checks. The delivered run used
Python 3.13.5 and SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/verify.py
bash code/build.sh
```

The PDF build requires a TeX distribution with the packages listed at the top of
`article.tex`, including `newtxtext` and `newtxmath`. `latexmk` is preferred; the
script falls back to three `pdflatex` passes. No external image or bibliography
files are needed. Font files and third-party articles are not distributed.

## Repository snapshot

The comparison uses `VladimirReshetnikov/Surreal` at commit
`c0a36eebe5cf30aa72abfe4ef8ff9e46f63c3c28`.
The audit is targeted, not an exhaustive review of the repository or literature.
The repository was read but not modified.
