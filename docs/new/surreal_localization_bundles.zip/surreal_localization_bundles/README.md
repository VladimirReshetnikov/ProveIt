# Localization-resistant bundles in Hahn-coherent surcomplex analysis

**Essential singularities, nilpotent representations, and exact isomorphism classification**

Research manuscript dated September 22, 2026. The PDF has 28 pages, including
the title page and contents. The LaTeX source is standalone and contains its
own bibliography. No external graphics, bibliography database, or custom font
files are required.

## Main mathematical results

The ordinary base is the complex plane. The coefficient category is explicitly
specified: common-domain holomorphic Hahn series, its nonnegative-support
integral subring, or common-domain coefficientwise meromorphic Hahn series.
For a strictly decreasing positive exponent profile `alpha_n`, the transitions
are finite nilpotent exponentials

    G_n = exp(t^(alpha_n) exp(1/(z-n)) J_r),

where `J_r` is a nilpotent Jordan block. Its exponential is a polynomial of
degree at most `r-1`.

The article proves a zero-annihilator support obstruction and derives:

- Global sections `H^0(E_alpha,r) = A e_1`, and the complete morphism formula
  for bundles attached to arbitrary constant finite-dimensional nilpotents.
- Indecomposability, nontriviality, and failure of stable triviality in every
  rank at least two, even after monomial localization and coefficientwise
  meromorphic extension. Every bounded restriction is integral-trivial.
- Exact profile classification: integral isomorphism is eventual equality;
  full holomorphic or meromorphic Hahn isomorphism is eventual equality up
  to one constant exponent translation. All isomorphisms cover the identity
  of the ordinary plane.
- An ordered-group rigidity dichotomy, continuum many localized isomorphism
  classes in every noncyclic group, explicit endomorphism rings and tensor
  decompositions, and nonsemidecidability of either side of the isomorphism
  relation for uniformly computable rational profiles.

These are the article's proposed new construction and structural results.
The underlying Hahn support facts, nilpotent Jordan identities, ordinary
Cousin theorem, and halting obstruction are classical and are not claimed
as new.

## Scope and research status

This is an AI-assisted mathematical research manuscript, not a refereed paper
or a proof-assistant-checked development. The proofs are provided in full.
The novelty assessment is bounded by the repository snapshot and primary
sources inspected; it is not a certification of historical priority.

The repository's specific hidden and deep **pole-only** examples after
holomorphic monomial localization are NOT claimed to be settled here. This
paper constructs and classifies a different, essential-singularity family
that resists even the explicitly defined meromorphic enlargement. It does
not classify all Hahn bundles or all fine-topological bundles on No[i].

Repository inspected:

    https://github.com/VladimirReshetnikov/Surreal
    commit 0097304c7ae9d5de46d2ea342e2494f8fc126303

See section 1.3 for the research-status boundary and section 12 for the proof
audit and remaining questions. PROVENANCE.json records the consulted paths
and selected primary-source identifiers. The repository was not modified.

## Build the PDF

With a standard TeX Live or MiKTeX installation and latexmk:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times to settle cross-references and the table of contents.

The delivered build has no LaTeX warnings, undefined references or citations,
duplicate PDF destinations, overfull boxes, or underfull boxes. All 28 pages
were rendered for visual inspection. See data/build_qa.json.

## Reproduce the finite exact audit

Tested with Python 3.13.5 and SymPy 1.14.0:

    python -m pip install -r code/requirements.txt
    python code/verify.py --max-rank 6 --output fresh-verification.json

The program passed 12,355 exact checks. It checks finite matrix identities,
Jordan rank profiles, and finite rational/lexicographic exponent samples.
It does NOT verify the essential-singularity theorem, infinite well-ordering
arguments, sheaf descent, classification, undecidability, or novelty.

No file is written unless `--output` is supplied. Using a fresh output path
preserves the delivered evidence in data/verification.json and
 data/verification.txt. The program makes no network calls.

## Contents

    article.tex                    Complete standalone LaTeX source
    article.pdf                    Typeset 28-page article
    README.md                      This guide
    PROVENANCE.json                Repository and literature audit scope
    SHA256SUMS.txt                  Checksums of all other package files
    code/verify.py                 Exact finite verification program
    code/requirements.txt          Tested dependency pin
    data/verification.json         Recorded machine-readable PASS report
    data/verification.txt          Recorded standard output
    data/build_qa.json             Build and PDF layout checks

The typesetting auxiliaries and rendered review images are intentionally not
part of the package.
