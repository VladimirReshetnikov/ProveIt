# The Birthday Expansion of the Surreal Field

**Recovering set theory, detecting forcing, and rigidity of surcomplex embeddings**

Research article prepared with ChatGPT, 22 September 2026.
The PDF has 28 pages, including the title page, contents, appendices, and references.

## Files

- `surreal_birthday_set_theory.pdf`: typeset article with linked contents and references.
- `surreal_birthday_set_theory.tex`: complete, self-contained LaTeX source, including bibliography.
- `finite_checks.py`: dependency-free finite diagnostic checks.
- `finite_checks_output.json`: output of the executed checks.
- `README.md`: build instructions, mathematical scope, and research status.

## Main construction

The article studies the ordered surreal field expanded by the birthday map
as an endofunction: b(x) is the embedded all-plus ordinal giving the sign length
of x. This is not an external ordinal sort fixed pointwise by every morphism.

The principal theorem supplies uniform parameter-free first-order
bi-interpretations between the birthday-expanded field of birthdays below
an uncountable cardinal kappa and (H_kappa, membership), including singular
kappa. Formula-by-formula, the full birthday-expanded surreal class is
bi-interpretable with the set-theoretic universe.

The proof gives explicit sign-reading formulas, a bounded ordinal pairing
term, well-founded extensional graph codes, and definable composite
isomorphisms. The reverse interpretation uses local arithmetic certificates
with a single hereditary-cardinality bound; it does not assume that H_kappa
satisfies all of ZFC.

Further results concern cardinality plateaux at non-cardinal epsilon stages,
outer-model elementarity, the least new birthday, definable arithmetic and
failure of saturation, and class elementary self-embedding rigidity. In
particular, the epsilon_0 stage already interprets all hereditarily countable
sets. The surcomplex statements name conjugation and the maximum of the two
coordinate birthdays. Under the stated class assumptions, the only elementary
self-embeddings of that expansion are identity and conjugation; naming i
leaves only identity.

## Build the article

Use a current TeX Live or MiKTeX installation with the standard packages named
in the source, including `newtxtext`, `newtxmath`, `amsmath`, `amsthm`,
`mathtools`, `geometry`, `microtype`, `booktabs`, `longtable`, `enumitem`,
`xcolor`, `fancyhdr`, `xurl`, `needspace`, `hyperref`, and `cleveref`.

From this directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_birthday_set_theory.tex
```

Alternatively, run the following command three times:

```sh
pdflatex -interaction=nonstopmode -halt-on-error surreal_birthday_set_theory.tex
```

No bibliography processor, shell escape, network connection, external images,
or separately supplied font files are needed. The TeX distribution supplies
the required fonts. No font files or third-party papers are included here.

## Run the finite checks

Python 3.10 or later is sufficient:

```sh
python finite_checks.py --output finite_checks_output.json
```

The recorded run passed 16,129 prefix comparisons, 642 individual-sign tests,
819 ordinal-polynomial addresses, and 42,849 graph-pair tests for each of
isomorphism and membership. There are 207 labeled graphs in the graph test
family, decoding 12 distinct hereditarily finite sets. An explicit example
also checks that omitting predecessor-closedness produces a false membership
answer.

These are finite consistency checks, not proofs of transfinite statements,
well-foundedness for arbitrary graphs, all-subset quantification, hereditary
size bounds, or class embedding theorems. Those arguments are in the article.

## Prerequisites and research status

The classical prerequisites are explicitly attributed: the sign model and
canonical cuts; natural ordinal arithmetic; van den Dries--Ehrlich closure of
epsilon birthday stages; Mostowski collapse; quantifier elimination for real
closed and algebraically closed fields; and Kunen's inconsistency in the
specified class-parameter formulation.

The reconstruction and its applications are proposed new contributions,
supported by written proofs. They have not been independently refereed or
formalized in Lean. The article makes no unconditional claim to historical
priority or exhaustive literature coverage. It does not claim a new proof of
Kunen's inconsistency, nor rigidity of the pure surreal field, nor a
classification of all bounded-stage elementary self-embeddings. A proper
outer-model inclusion being non-elementary in the expanded language does
not by itself assert different parameter-free complete theories.

The read-only repository comparison is pinned to:

```text
VladimirReshetnikov/Surreal
4f2645599121fa872c7104995e47f86f0382351f
```

Its scope is recorded in Appendix B: the repository tree, root README,
report catalogue, initial formalization ledger, foundations introduction,
and surcomplex-automorphisms package README. No full claim-by-claim audit of
all repository reports, historical sources, or Lean code is claimed. The
repository was neither modified nor built.

## Artifact checks

The final PDF was compiled successfully with resolved references and without
LaTeX warnings or overfull boxes. Its page layouts were rendered and inspected.
The finite diagnostic program was executed successfully. Compilation and page
inspection are document checks, not an independent mathematical proof audit.
