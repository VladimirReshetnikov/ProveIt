# Equality for Omnific Notations

**Hereditary normal forms, finite-state Hahn series, and sharp representation barriers**  
Research report prepared for Vladimir Reshetnikov and the Surreal project, 23 September 2026.

## Contents

- `article.pdf`: the 26-page article, including full mathematical proofs, algorithms,
  examples, references, and a dependency/novelty ledger.
- `article.tex`: complete editable LaTeX source with an embedded bibliography.
- `code/verify.py`: deterministic, exact-rational regression tests; standard library only.
- `data/verification.json`: actual finite-test results, counts, seeds, and runtime version.
- `data/provenance.json`: repository pin, audit boundary, and document validation summary.
- `data/checksums.json`: SHA-256 hashes of the other deliverable files.
- `Makefile`: optional PDF-build and test targets.

## Main results

Theorem 3.1 constructs canonical hereditary finite normal forms. Theorem 3.2
adds decidable omnific membership and the correct infinitesimal floor adjustment.
The ordinal fragment is exactly the ordinals below epsilon-zero (Theorem 3.3).

Theorems 4.1 and 4.2 realize a shielded polynomial ring inside the omnific
integers and transfer equality by many-one reductions. The general statement
is about promised valid names; it becomes an ordinary many-one equivalence
when the naming domains are decidable. Theorem 5.2 specializes this to an
explicit epsilon-zero-shielded ring with decidable validity, equality, and
order. Corollary 5.4 gives infinite supports of order type omega^r for every
positive finite r. Proposition 5.3 proves a precise non-real-closedness
boundary for its coefficient fraction field.

Theorems 6.1 and 6.2 give finite certificates for the leading term and equality
of matrix-described Hahn series, separating independent scales from scales
with collisions. Proposition 6.4 supplies a constructive Cauchy-product
closure bound.

Theorem 7.1 proves Pi^0_1-complete equality on one fixed explicit support.
Theorem 8.1 retains this hardness even though every value has a rational
generating function and every coefficient is 1 or 2. Corollary 8.2 places
such hard alternative names inside the very same ring that admits decidable
fraction names. Theorem 8.3 computes the exact minimal state dimension of a
switch stream and proves there is no computable uniform dimension bound.

Theorem 9.2 proves Pi^1_1-complete support admissibility with decidable dyadic
supports inside [1,2) and all nonzero coefficients equal to 1. This is a
validity theorem, not an assertion that promised equality is Pi^1_1-complete.
Proposition 10.1 establishes a separate effective support-rank boundedness result.

## Rebuild the PDF

Use a standard TeX installation with the packages in the source preamble.
No external bibliography database, figures, or font downloads are needed.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `latexmk -pdf article.tex` or `make pdf`.

## Reproduce the finite checks

Python 3.9 or later, with no third-party dependencies:

```sh
python code/verify.py
```

On Windows, `py code/verify.py` also works. The runner resolves its output
path relative to its own location, so it need not run from the package root.
It exits with an error if any assertion fails and writes a fresh
`data/verification.json` after a successful run. Rerunning updates that file's
timestamp, so its checksum will then differ from the supplied manifest.

The supplied run used Python 3.13.5 and passed **18,109 exact finite assertions**.
The JSON separates their categories; these are not 18,109 independently proved
theorems. The largest category checks the dyadic coding on finite pairs of
sequences. The other checks exercise hereditary arithmetic and floor,
finite matrix numerator identities, leading-term bounds, cancellation,
and switch-stream realizations and Hankel ranks.

## Research and verification status

This is an AI-assisted research manuscript, not a refereed publication.
The full proofs are written in ordinary mathematics. Finite tests provide
regression evidence, not proofs of the infinite or undecidability theorems.
The package does not implement arbitrary omnific arithmetic, decide the
halting set, validate arbitrary well-orders, or contain new Lean proofs.

Classical normal-form, rational-series, and computability facts are attributed
to prior sources. The shielding/equality-transfer construction, its epsilon-zero
calculus, the collision-aware leading-term formulation, and the rational-realization
gap are proposed contribution candidates. The limited literature search did
not verify a literature-wide priority claim. Nothing is claimed absent from
uninspected portions of the repository.

The targeted repository review was pinned to:

`a45d72292a46dac13300d395101df188efb84eef`

See Section 1.1 and Appendix B for exactly which material was reviewed.
The original repository was not modified, and no repository-wide Lean build
was run. The PDF was compiled without LaTeX warnings and visually inspected
after rendering all 26 pages.
