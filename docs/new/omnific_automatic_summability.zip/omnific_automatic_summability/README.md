# Automatic Summability from Omnific Arithmetic

Research article prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.tex`: standalone LaTeX source, including the bibliography.
- `article.pdf`: compiled article.
- `checks/verify.py`: standard-library Python program using exact rational arithmetic.
- `data/verification.json`: recorded finite-check results.
- `SOURCES.md`: repository snapshot, primary literature, and provenance boundaries.
- `SHA256SUMS.txt`: hashes of the deliverable files other than this checksum file.

## Principal result

Every field automorphism of the full surreal field preserving the omnific
integers is automatically strongly real-linear: it preserves every set-indexed
Hahn-summable family and its sum. Every unital ring automorphism of the omnific
integers extends uniquely to one of these field automorphisms.

The proof uses the equivalence

    (x_i) is Hahn summable
        iff for every y, ct(x_i * y) is nonzero for only finitely many i.

The same pairing recovers the sum. The article applies this to extend the
stated scope of the pinned repository's real omnific-stabilizer classification
beyond automorphisms assumed in advance to be strong.

## Additional results

The article proves a strong-dual representation and an algebraic-adjoint
criterion for full set-sized Hahn fields. It also constructs a strong real-linear
functional on the full surreal class that cannot be represented by any surreal
kernel, so those set-sized duality statements cannot simply be transferred to
full surreal numbers. It gives rank-one classifications, a higher-rank shear,
precise surcomplex extensions, and eight proposed research directions.

## Status and limitations

This is an AI-assisted mathematical research draft, not a refereed or
Lean-verified paper. Proofs are supplied for the asserted results, with classical
Hahn-field prerequisites cited. The main proposed advance is the application to
all real omnific-preserving automorphisms, relative to the stated scope of the
inspected repository snapshot. Global priority is not certified. Finiteness-space
duality and general Hahn-automorphism decompositions are prior work and are
explicitly credited.

The unrestricted Gaussian-omnific automatic-strongness problem is NOT claimed
solved. Neither are the general embedding problem or global surreal exponential
compatibility. All full-surreal sums in this article are set-indexed. Class
automorphism-group notation is interpreted elementwise, not as an NBG class of
proper-class graphs.

The included computations validate finite identities only; they do not prove
the infinite or class-sized theorems. No new Lean formalization was run. The
repository was read, not modified.

## Build

A conventional TeX Live or MiKTeX installation with the packages named in the
preamble is sufficient. No external images, font files, or BibTeX step are needed.

    latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex

Alternatively, run `pdflatex -halt-on-error article.tex` repeatedly until the
references and contents stabilize.

To reproduce finite checks, with Python 3.9 or newer:

    python checks/verify.py

The program writes `data/verification.json` and also prints its results.
