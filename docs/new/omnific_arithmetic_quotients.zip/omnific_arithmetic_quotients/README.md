# Arithmetic Quotients of Omnific Chevalley Groups and Lie Rings

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 23 September 2026.

## Main results

The article develops an all-root-type extension of the Surreal repository's elementary-matrix arithmetic-quotient program. Write A = D + Pi_k, where k is R or C and Pi_k consists of normal forms supported on strictly positive growth exponents. Ordinary omnific integers correspond to (D,k) = (Z,R); Gaussian omnific integers correspond to (Z[i],C).

For a finite reduced root system with no A1 component, every abstract homomorphism from the constant-term kernel of E_Phi(A) to any set-sized group is trivial. Therefore E_Phi(D) is the universal set-sized quotient. This includes C2, G2, and all exceptional types, as well as a Steinberg version. The root reconstruction requires 2 Pi_k = Pi_k, not that 2 be a unit of A.

For ordinary and Gaussian omnific integers, the repository's rank-one obstruction, reproved here, completes an exact componentwise classification in the simply connected elementary category: a universal set-sized quotient exists exactly when there is no A1 component.

For a finite free integral Lie ring Lambda, the current Lie ring Lambda tensor A has a universal set-sized Lie-ring quotient exactly when Lambda tensor Q is perfect. The quotient is then Lambda tensor D. Targets may be arbitrary Lie rings, including torsion targets. In particular, sl2(Oz) has the arithmetic Lie-ring quotient even though E2(Oz) has no universal set-sized group quotient.

The article also gives structural consequences, a ring–group transfer equivalence, exact conditional cardinal thresholds, explicit small-rank matrices, and twelve further research questions.

## Files

- `article.pdf`: the 28-page article, with full written proofs and an embedded bibliography.
- `article.tex`: self-contained LaTeX source.
- `verify.py`: deterministic exact finite checks using SymPy.
- `verification_results.json`: output of the successful 2,188-check run.
- `requirements.txt`: the dependency version used for that run.
- `Makefile`: PDF and verification targets.
- `SOURCES_AND_SCOPE.md`: source pin, literature roles, and novelty limitations.
- `PROOF_AUDIT.md`: critical proof steps and exclusions.
- `BUILD_REPORT.md`: build and PDF inspection record.
- `SHA256SUMS.txt`: checksums of the other package files.

## Build and reproduce

A standard TeX Live or MiKTeX installation with the packages named in the preamble is needed. The bibliography is internal. There are no external figures or font files, and no shell escape is required.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex article.tex` repeatedly until references stabilize.

For the finite checks, use Python 3.10 or newer:

```sh
python -m pip install -r requirements.txt
python verify.py
```

The verifier writes `verification_results.json` beside itself. Run without Python optimization flags. The recorded run used Python 3.13.5 and SymPy 1.14.0.

## Research status

This is an AI-assisted, unrefereed research manuscript. Full written arguments are supplied, with classical dependencies identified. The all-type transfer and Lie classification are proposed contributions; priority has not been established by an exhaustive literature review or independently certified. No named published conjecture is claimed solved.

The scalar set-sized quotient, type-A matrix results, rank-one amalgam, and several kernel arguments are credited to the existing repository rather than claimed as new. The article proves the needed statements explicitly before extending them.

The finite checks validate polynomial matrix identities, finite root configurations, and finite leading-term examples. They do not prove the class-theoretic or arbitrary-homomorphism theorems. No new Lean formalization is supplied and no repository Lean build was performed.

The main group statement concerns elementary, root-generated groups, not every point of a Chevalley group scheme over Oz. The Steinberg constant-term kernel is not identified with K2, and rootwise commutator bounds are not claimed to be global width bounds.

Repository snapshot: `7af8a3026c8440944e94df89020d42ca08f4e3dd` in `VladimirReshetnikov/Surreal`. No repository files were modified.
