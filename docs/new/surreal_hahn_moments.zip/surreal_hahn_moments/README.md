# Positive Moment Functionals with Invisible Negative Mass
## Strong Hahn Measures over the Surreals

Research manuscript prepared for Vladimir Reshetnikov, 22 September 2026.
The PDF has 27 pages including the cover and contents.

## Contents

- `article.tex` — complete LaTeX source, including the bibliography.
- `article.pdf` — compiled article with linked contents and cross-references.
- `verify.py` — self-contained exact finite verification, using Python's standard library.
- `verification_results.json` — detailed machine-readable results.
- `verification_summary.txt` — short verification report.
- `build.sh` — rebuild the PDF and run the finite checks.

## Main mathematical results

Theorem 3.3 proves that strongly countably additive real or complex Hahn-valued
measures on countably separated measurable spaces are automatically strongly
summable families of point masses. Neither atomicity nor a common exponent
support is assumed. Theorem 4.2 gives an exact moment representation criterion
using finite signed coefficient measures, a common well-order, and positivity
of the reconstructed singleton weights.

Theorems 6.1 and 6.4 establish polynomial and continuous-function positivity
barriers. The explicit example in Theorem 7.1 is normalized and strictly
positive on every nonzero Hahn-coefficient polynomial that is nonnegative on
the ordinary real interval. Its restriction extends to a positive functional
on ordinary continuous functions. Nevertheless, its moments force singleton
mass `-t` at zero in every signed strong representing measure, ruling out a
positive strong measure on that ordinary sample space.

Theorem 7.3 proves a sharp ordinal boundary: global support order type at most
omega cannot exhibit this failure, while omega+1 does. Theorem 8.2 computes all
Hankel determinant valuations and leading coefficients. Theorems 9.2 and 9.4
provide positive finite Gaussian quadrature, identify the nodes' standard
parts, and show that at least one node is genuinely non-Archimedean at every
order. Section 10 transfers the construction to actual surreal values by
`t^q -> omega^(-q)` and develops its surcomplex Hermitian forms.

## Exact verification

Run:

```sh
python3 verify.py
```

The recorded run passed **682 assertions**. All arithmetic uses rational
coefficients and rational exponents in *finite* sparse Hahn polynomials.
There is no floating-point substitution for the infinitesimal scale.

The checks compare independent determinant and atomic subset expansions,
verify leading-term formulas and coefficient recurrences, test finite
Hahn-coefficient polynomials, and explicitly exhibit the eventual failure
of positivity in every tested finite truncation. They are not a proof of
any infinite-support or universal-degree theorem.

## Building the article

Python 3.10 or newer is sufficient for the verification script. A standard
TeX distribution with the packages listed in the source is needed for the PDF.
No external bibliography database, downloaded images, or custom font files
are required.

```sh
sh build.sh
```

Or build only the PDF:

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex
```

When `latexmk` is unavailable, run `pdflatex` three times with the same options.

## Scope and research status

“Strong” always means the exact support-and-finite-coefficient-activity
condition in Definition 2.1. These results do **not** rule out other
non-Archimedean probability conventions, generalized-limit measures, or
representations on a sample space containing nonreal Hahn points.

The main support-sensitive package is proposed as a candidate original
contribution, not a certified priority claim and not the announced solution
of a named published open problem. Classical finite linear algebra is
identified separately. The proofs have not been independently refereed or
formalized in Lean.

Appendix A records the repository and literature audit and its limits. The
inspected repository commit was
`4cf691c7d951e037739d32d9f5c387dcce724f3c`. Its documentation catalogue and
selected source sections were read; binary manuscripts were not exhaustively
inspected. Repository search was uninformative even on a positive-control
term and was not treated as evidence of absence. No repository was modified.
