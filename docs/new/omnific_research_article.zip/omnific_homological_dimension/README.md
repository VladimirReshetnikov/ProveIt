# Arithmetic Invisibility and Homological Dimension in Omnific Integer Cores

Research article prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `omnific_homological_dimension.pdf`: the 21-page typeset article.
- `omnific_homological_dimension.tex`: self-contained LaTeX source, including bibliography.
- `check_boolean_tor.py`: reproducible exact-arithmetic regression audit.
- `audit_results.json`: recorded successful audit of 780 multidegrees.
- `build.sh`: PDF rebuild commands.

## Main results

For A = D + M, where M comprises finite nonconstant monomial sums with
coefficients in K and exponents in the coordinate cone of nonnegative
rational vectors, the article constructs an explicit flat Boolean resolution
of D and computes Tor(A)(D, A/(X_i : i in F)) in every multidegree.

For d coordinates, the quotient D has flat dimension d although all its
positive self-Tor groups vanish. For D=Z, K=R and D=Z[i], K=C, the rings embed
in actual real and Gaussian omnific integers. They are noncoherent and have
an explicitly presented cyclic module of flat dimension d+1. Countably many
coordinates give infinite flat dimension. Finite arithmetic quotients and
profinite completions detect only D. Enlarging the monomial cone to all
positive elements of the same real exponent group reduces the quotient's
flat dimension to one; the article proves that this extension is not flat.

## Rebuilding the PDF

Use a TeX Live or equivalent installation with pdfLaTeX and the packages
listed in the source. In particular, `newpxtext`, `newpxmath`, `tcolorbox`,
`titlesec`, `needspace`, and `xurl` are required. No external images, fonts,
BibTeX database, or downloaded input files are needed.

On a shell with pdfLaTeX in PATH:

    sh build.sh

Alternatively run the following command three times from this directory:

    pdflatex -interaction=nonstopmode -halt-on-error omnific_homological_dimension.tex

## Running the audit

Python 3.10 or later and SymPy are required:

    python -m pip install sympy
    python check_boolean_tor.py

Run without Python's `-O` option: the program intentionally uses assertions
as test checks. It constructs exact rational boundary matrices for the
auxiliary coefficient pair Q contained in Q(sqrt(2)), checks that successive
boundaries compose to zero, and checks homology dimensions on a five-point
coordinate grid in ranks 1 through 4. It writes `audit_results.json` alongside
the script. The delivered run passed all 780 multidegrees.

These finite tests do not establish the general theorem and do not replace
integral-module arguments. Full symbolic proofs are in the article.

## Scope and verification status

The proposed novelty is the precise Tor computations, explicit module
witnesses, and their paired surreal/Gaussian and ordered-cone formulations.
The D+M framework and the idempotent-kernel formal-etaleness mechanism are
classical and are credited. No named historical conjecture is claimed solved.
The bounded literature/repository comparison is not a priority certificate.
The mathematical arguments have not been independently refereed or verified
in Lean. There is no claim about the homological dimensions of the full
proper-class omnific ring, nor an exact finite-rank weak global dimension.

The PDF was compiled successfully, checked for unresolved references and
out-of-margin text, and visually inspected after rendering. The build has
one benign underfull-line warning in the provenance table and no overfull
boxes or unresolved references.
