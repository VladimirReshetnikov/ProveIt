# Defining Arithmetic Inside Omnific Integers

**Pell rigidity, intersective polynomials, and the constant-term ideal**  
Research draft prepared with ChatGPT — September 23, 2026

## Files

- `article.pdf`: the 22-page typeset article (cover, contents, and 20 numbered pages).
- `article.tex`: complete LaTeX source, with an embedded bibliography; no external figures or bibliography database are needed.
- `verify.py`: exact symbolic and finite checks, using only the Python standard library.
- `verification.txt`: recorded output of the successful verification run.
- `build.sh`: a small PDF build script.

## Main results

The article gives complete written proofs of a proposed explicit definability package:

1. The same parameter-free existential system, with five witnesses and three polynomial equations, defines the ordinary integers inside the omnific integers and the Gaussian integers inside the Gaussian omnific integers.
2. In the real case, a single quartic polynomial equation with six witnesses defines the ordinary integers.
3. For the classical polynomial
   `P(T) = (T^2 - 13)(T^2 - 17)(T^2 - 221)`,
   the equation `a*s = P(t)` is solvable in either full omnific ring exactly when the constant coefficient of `a` is nonzero.
4. Consequently the purely infinite ideal has a two-variable universal definition. The constant-term map has explicit existential-universal and universal-existential definitions. The ideal is also the largest ideal whose quotient has no root of `P`.
5. The proofs extend to the specified Hahn rings of arbitrary ordered abelian rank and arbitrary set-sized reverse-well-ordered supports, and the constant-definition construction extends to subrings of each fixed number field using a tailored polynomial.

The article also proves norm-form rigidity, gives support bounds for explicit witnesses, states logical consequences, and supplies counterexamples showing why the coefficient-ring and nonnegative-exponent hypotheses matter.

## Build the PDF

Use a standard LaTeX installation with `pdflatex` and the packages listed in the source. From this directory run:

```sh
sh build.sh
```

Alternatively:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The bibliography is included in `article.tex`; BibTeX and Biber are not required.

## Reproduce the checks

Python 3.10 or later is sufficient. No third-party packages or network access are needed.

```sh
python3 verify.py
```

Do not use Python's `-O` option: this program uses assertions. The checks include the exact universal witness identity, support-degree computations for the polynomial witnesses, modular roots through 4096, Pell return/divisibility checks through modulus 500, concrete ordinary and Gaussian witnesses, the quartic's total degree, and its explicit Gaussian counterexample.

These checks supplement the proofs; they do not establish the general quantified statements, the full Hahn support theory, prime existence in the number-field extension, or the proper-class interpretation.

## Status, sources, and verification boundary

The explicit formula package is proposed as a research contribution, not asserted to have certified publication priority. The literature check is targeted, not exhaustive. Established ingredients—including Pell methods, the displayed intersective polynomial, Lagrange's four-square theorem, and the general undecidability background—are credited in the article. No named longstanding conjecture is declared solved.

This package contains written mathematical proofs and reproducible exact finite checks. It is not an independently refereed or Lean-verified development. No repository-wide Lean build was performed, and no new Lean module is supplied.

The repository reference point is:

`VladimirReshetnikov/Surreal`

commit `71e9606d297c9b98c732070dc462682cc6948981`.

The inspection covered its README, report inventory, and the opening scope and implementation discussion in `docs/FORMALIZATION.md`; it was not an exhaustive audit of every research report. The article distinguishes the proposed formalization route from existing checked repository coverage.

All proper-class claims are interpreted formula by formula; ordinary first-order model-theoretic assertions are stated for set-sized Hahn rings. The results are not claimed for the full surreal or surcomplex fields without the omnific-ring restriction.
