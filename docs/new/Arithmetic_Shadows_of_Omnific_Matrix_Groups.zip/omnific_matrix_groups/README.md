# Arithmetic Shadows of Omnific Matrix Groups

**Set-invisible perfect kernels, Steinberg groups, and cardinal thresholds for ordinary representations**

Research manuscript dated 23 September 2026. The compiled article has 24 pages.

## Main result

For n >= 3 and (A,D) = (Oz,Z) or (Oz[i],Z[i]), every homomorphism from
E_n(A) to a set-sized group factors uniquely through entrywise constant term
E_n(A) -> SL_n(D). The elementary constant-term kernel itself has no
nontrivial homomorphism to any set-sized group. This assertion is about
maps defined on the kernel, not just restrictions of maps on E_n(A).

The article proves that the matrix kernel is nonabelian, torsion-free,
centerless, perfect, and non-simple. It gives Steinberg-group analogues,
set-sized Hahn-fragment versions with explicit cardinal bounds, a
finite-support counterexample, and a real profinite-completion corollary.

The preceding small-ring-image theorem is attributed to the Surreal
repository and reproved. Reconstruction of coefficient algebra from root
commutators is an established broader idea; no claim to originate that idea
is made. The proposed contribution is the omnific group quotient and its
internal-kernel and cardinal consequences.

## Files

- `omnific_matrix_groups.pdf`: compiled article.
- `omnific_matrix_groups.tex`: complete, self-contained LaTeX source with inline bibliography.
- `verify.py`: deterministic exact-arithmetic finite identity checks; standard library only.
- `verification_results.json`: actual output of the check script (2,111 checks, all passed).
- `PROOF_AUDIT.md`: hypotheses, dependencies, and proof-review checklist.
- `SOURCES_AND_SCOPE.md`: repository snapshot, source roles, and novelty limits.
- `BUILD_REPORT.md`: compilation and rendering checks.

No external images, bibliography database, or custom font files are required.

## Build

A standard TeX Live installation with the packages named in the source is sufficient.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error omnific_matrix_groups.tex
```

Without latexmk, run the following command three times to resolve the table of
contents and cross-references:

```sh
pdflatex -interaction=nonstopmode -halt-on-error omnific_matrix_groups.tex
```

Run the finite checks with Python 3.10 or later:

```sh
python verify.py
```

The script overwrites `verification_results.json` beside itself. It requires no
network access and uses exact rational arithmetic, not floating-point approximations.

## Scope

This is an unrefereed, AI-assisted, proof-bearing research manuscript. The
arguments have not been independently certified or formalized in Lean, and
priority is not established. No named longstanding conjecture is claimed solved.

The main matrix theorems concern E_n(A), not automatically all of SL_n(A).
Rank two is left separate. The Steinberg constant-term kernel is not identified
with K_2. Finite arithmetic checks do not verify arbitrary Hahn supports,
cardinal statements, or proper-class algebra.

The source repository was read at commit:

`9693b28c24e6fcb317ce47969a40185c5dfef402`

No changes were made to the repository.
