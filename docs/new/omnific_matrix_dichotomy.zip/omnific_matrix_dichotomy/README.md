# A Matrix-Size Dichotomy over the Omnific Integers

**Countable representations, invisible congruence kernels, and one-step stabilization**

Prepared for Vladimir Reshetnikov by OpenAI ChatGPT, 23 September 2026.

## Contents

- `article.pdf`: 25-page article (cover plus 24 numbered pages), with full mathematical arguments and linked references.
- `article.tex`: self-contained LaTeX source. The bibliography is included in the source; no BibTeX step is needed.
- `checks.py`: exact symbolic checks and finite regression examples.
- `checks-results.json` and `checks-output.txt`: the recorded successful check run.
- `requirements.txt`: the SymPy version used for the recorded checks.
- `SHA256SUMS.txt`: hashes of the delivered files, excluding this hash list itself.

## Main results

Let R be Oz or Oz[i], D be Z or Z[i], and N_n be the kernel of constant-coefficient reduction from the elementary matrix group E_n(R) to SL_n(D).

For n >= 3, every homomorphism from N_n itself to a set-sized group is trivial. Every set-sized group image of E_n(R) therefore factors through SL_n(D).

For n = 2, homomorphisms into the fixed countable group SL_2(Frac(D)(t)) separate every finite subset of E_2(R). The kernel N_2 is a free product of additive purely infinite ideals indexed by P^1(Frac(D)). Nevertheless all finite group images kill N_2.

Thus a nonidentity purely infinite congruence element has minimum detecting target cardinality aleph_0 in two rows, but no set-sized detecting target in three or more rows. Elements with nonidentity constant reduction are detectable by finite groups.

The article also treats the real/Gaussian abelianization contrast, proves a finite cusp-residue obstruction to elementary generation, and exhibits Cohn-type unipotents that become explicit relative commutators after one stabilization.

## Scope and research status

These are statements about **finite products of elementary matrices**, not a classification of all special linear matrices. The distinction is proved necessary by an explicit counterexample.

All series supports are sets. The source rings and groups can be proper classes. All target groups in the detection theorems are ordinary sets. Homomorphisms are not assumed continuous or compatible with Hahn summation.

The main detection theorem package is proposed as an original omnific deduction. The article credits the classical Cohn presentation and abelianization machinery, the classical Cohn matrix pattern, and the repository's earlier scaled-field collision argument. The literature check does not establish priority. No named historical open conjecture is claimed resolved.

The article is a proof-bearing research draft, not peer-reviewed work. No Lean proof was produced or checked. The finite symbolic checks do not establish the transfinite-support or class-size theorems.

## Rebuilding the PDF

A standard LaTeX installation with the packages named in the preamble is sufficient. From this directory, run the following commands (also valid in PowerShell when `pdflatex` is on PATH):

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The repeated passes resolve the contents, citations, and cross-references. The delivered build has no undefined references, overfull boxes, or LaTeX warnings. The PDF was rendered and visually inspected.

## Running the exact checks

The recorded run used Python 3.13.5 and SymPy 1.14.0. Install the dependency and run:

```text
python -m pip install -r requirements.txt
python checks.py
```

The script reports 23 successful checks, including an aggregate test of 120 exact reduced alternating polynomial words. It rewrites `checks-results.json` with the local runtime versions. All arithmetic is symbolic and exact; there are no floating-point experiments.

The checks cover three-index elementary commutators, the Gaussian diagonal commutator, the nilpotent matrix pattern, the stabilized eight-factor word, the finite cusp-ratio identity, and finite examples of the target normal form. The arbitrary-word argument and all support/cardinality arguments are proved in the article, not by these examples.

## Repository provenance

Repository: `VladimirReshetnikov/Surreal`

Snapshot inspected:

```text
fb5c4b530e3ec04b5661347d51d5382526d5aa02
```

Relevant prior report:

```text
docs/surreal/set-sized-quotients-of-omnific-integers/article.tex
```

The source inventory and formalization ledger were also inspected. Links to the pinned source and to the primary mathematical literature are in the article's bibliography. This delivery does not modify the repository.
