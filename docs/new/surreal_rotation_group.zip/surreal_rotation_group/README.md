# Rotations of the Surreal Plane

**The norm-one torus, infinitesimal angles, and topology at every scale**  
September 22, 2026 — 30-page article

## Contents

- `surreal_rotation_group.pdf`: the compiled article, with a linked table of contents and references.
- `surreal_rotation_group.tex`: self-contained LaTeX source; the bibliography is embedded and no external figures are required.
- `verify.py`: exact finite symbolic checks for displayed polynomial, rational, and truncated-series identities.
- `verification_results.json`: recorded output; all 41 checks passed using SymPy 1.14.0.
- `requirements.txt`: dependency for the optional verification script.
- `build.sh` and `build.ps1`: PDF build commands for a POSIX shell and PowerShell.
- `SHA256SUMS`: checksums for the package files.

## Main structure

The article develops

    SO(2, No) ≅ T(No) ≅ O / (2π Z) ≅ T(R) × (m, +),

where O is the additive group of finite surreal numbers and m is the infinitesimal ideal. It distinguishes this finite-angle quotient from the normalized global phase quotient No / (2π Oz), with Oz the omnific integers.

The treatment includes isometry rigidity, rational/projective coordinates, the infinitesimal logarithm, roots and torsion, valuation filtrations, displacement at arbitrary radii, algebraic representations, global phase extensions, fine topology, standard-part topology, semialgebraic geometry, and local angular velocities.

## Build the PDF

Use a LaTeX installation providing latexmk, pdfLaTeX, the AMS packages, Latin Modern, geometry, microtype, booktabs, longtable, array, enumitem, aliascnt, xcolor, fancyhdr, hyperref, and cleveref.

From this directory:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_rotation_group.tex
```

Alternatively, run `sh build.sh` or `./build.ps1`. No BibTeX or Biber run is needed.

## Reproduce the finite checks

Python 3.9 or later:

```text
python -m pip install -r requirements.txt
python verify.py
```

The script exits with an error if an identity fails and writes `verification_results.json` after a successful run. These are **finite symbolic checks**, not proof-assistant verification of the general surreal theorems. No Lean compilation or independent kernel verification of this article was performed.

## Research provenance and limits

The repository snapshot consulted was:

    VladimirReshetnikov/Surreal
    dcf86662b574988e75d08d515d3a2a5ba7bbc0d7

The finite-angle splitting and global-normalization discussion already occur in the repository's trigonometry report. The article acknowledges this overlap and cites published sources for surreal normal forms, Hahn evaluation, the Ehrlich–Kaplan global normalization, algebraic groups, and semialgebraic homotopy. It is a self-contained group-centered exposition, not a claim of priority or a resolution of a named open problem.

Every infinite sum used for infinitesimal functions is a set-supported Hahn sum. Such a sum must not be confused with convergence in the full surreal fine topology. Class-size and universe restrictions are stated explicitly in the article.
