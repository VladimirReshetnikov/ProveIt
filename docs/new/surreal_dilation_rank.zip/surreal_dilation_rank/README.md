# Support Rank and Algebraic Freeness under Surreal Dilations

Research article prepared with ChatGPT for Vladimir Reshetnikov, 23 September 2026.

## Main result

Let `S_q(sum a_g t^g) = sum a_g t^(q g)` denote positive rational
**exponent dilation** of a characteristic-zero Hahn series, in the
reverse-well-ordered growth-support convention.

Any `m` distinct positive rational dilates of a series are algebraically
independent when its support has rational rank at least `m`. The result
also holds relative to a full Hahn subfield, with rank measured modulo
that subfield's rational exponent space.

For finite-support series and rational functions of finitely many monomials,
the transcendence degree of any `m` distinct dilates is exactly
`min(m, support rank)`. In particular, autonomous algebraic order equals
support rank. This answers Section 16, Question 1 of the repository report
`docs/surcomplex/autonomous-dilation-relations/article.tex` at commit:

    958b5c4865819bd55ea1f5ffc050282aea7ef570

The paper also proves explicit jointly independent omnific dilation orbits,
arbitrary set-sized free families over a prescribed set-sized surcomplex
base, and an infinite-support hierarchy of support rank `r` and exact order
`r + 1`. It gives 11 further research questions.

## Contents

- `article.pdf`: the compiled 23-page paper, including title, contents,
  full proofs, examples, 11 research questions, audits, and bibliography.
- `article.tex`: standalone LaTeX source; bibliography is internal.
- `verify.py`: exact finite determinant, rank, identity, and boundary checks.
- `verification_results.json`: recorded successful run, 549 named cases and
  1,918 subsidiary independent-basis comparisons.
- `build.py`: portable three-pass pdfLaTeX build helper.
- `requirements.txt`: Python dependency for the finite verification script.
- `PROOF_AND_SOURCE_AUDIT.md`: hypotheses, proof checkpoints, source scope,
  and priority/verification limitations.
- `BUILD_REPORT.json`: document, rendering, and build-validation record.
- `SHA256SUMS.txt`: checksums for the delivered files, except itself.

## Read first

- Theorem 4.3: relative support-rank obstruction.
- Theorem 5.1: exact finite-support theorem, answering the repository question.
- Theorem 6.3: rational-profile extension and its finite invariant.
- Theorems 7.1 and 7.4: explicit omnific orbit and prescribed-base construction.
- Theorem 8.3: infinite-support rank/order hierarchy.
- Section 11: further research questions.

## Status and scope

This is an AI-assisted, unrefereed research draft containing complete
proposed mathematical proofs. It is not independently verified, and no
Lean proof or Lean build is supplied. Priority relative to the world's
literature is not certified. The source comparison establishes the
specific gap in the inspected, pinned repository report; it is not a
claim to have resolved a named classical conjecture.

The finite tests check finite identities and potential cancellation/sign
errors. They do not prove the infinite Hahn or proper-class statements.
The new proofs do not assume the repository's proposed first-order
support-collapse theorem. Standard Hahn normal forms and classical
algebraic tools are explicitly credited in the paper.

`S_q` is not exponentiation of a surreal value, the surreal exponential,
a derivation, or argument dilation of a function. Theorems require
characteristic zero and distinct positive rational dilation parameters.
The arbitrary-base theorem applies to **each prescribed set-sized field**,
not to independence over all surcomplex numbers.

## Build the PDF

Install TeX Live or MiKTeX with pdfLaTeX, New PX text/math, and the standard
packages named in the source preamble. Run:

    python build.py

The script invokes pdfLaTeX three times. It requires no BibTeX, shell
escape, external illustrations, or network access. It writes normal
LaTeX auxiliary files and three diagnostic build logs in this directory.

## Reproduce the finite checks

Use Python 3.9+ with SymPy; the recorded run used Python 3.13.5 and
SymPy 1.14.0. From this directory:

    python -m pip install -r requirements.txt
    python verify.py --output verification_results.json

The second command overwrites the named output JSON; choose another
output name to preserve the delivered record. The seed is fixed at
20260923. Environment and elapsed-time fields vary. The recorded detailed
random-case counts correspond to the stated Python version; the asserted
identities and success conditions are the substantive check.

No third-party papers or font files are included.
