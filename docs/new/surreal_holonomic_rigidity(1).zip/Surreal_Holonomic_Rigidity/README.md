# Entire Hahn Functions and Holonomic Rigidity
## A sharp order-unit criterion for surcomplex dilations

Research manuscript, September 22, 2026. The PDF has 24 pages.

## Main result

Let K_Gamma = C((t^Gamma)), where Gamma is a nonzero set-sized divisible
ordered abelian group. A series is strongly entire when its ordinary
power-series evaluation family is Hahn-summable at every element of this
fixed field: both a well-ordered union of supports and finite multiplicity
at every exponent are required.

For a fixed nonzero q of infinite multiplicative order, there is a
nonpolynomial strongly entire solution of a nonzero linear q-difference
equation over K_Gamma(z) if and only if |v(q)| is a positive order unit of
Gamma. An order unit beta is a positive element whose positive integer
multiples are cofinal in Gamma. This distinguishes two dilations even in
the same rank-two field.

Every strongly entire ordinary D-finite series over K_Gamma(z) is a
polynomial. D is differentiation in the power-series variable; it kills
all Hahn scalars and is NOT the Berarducci--Mantova scalar derivation.

The article includes a recurrence escape-chain argument, exact exclusion
bounds, the near-root-of-unity valuation case, partial-theta sharpness
with arbitrary Hahn tails, and an explicit entire series

    F(z) = sum_{n>=0} omega^(-omega^n) z^n

on the workspace Gamma = direct_sum_{n>=0} Q*omega^n. This F is not
D-finite and satisfies no nonzero linear single-dilation equation for
ANY nontorsion q in that workspace.

## Files

- article.tex: standalone LaTeX source, including bibliography.
- article.pdf: compiled 24-page article.
- verification.py: standard-library Python finite exact-arithmetic checks.
- verification_results.txt: actual output, 2,043 checks passed, none failed.
- literature_audit.md: inspected sources, repository snapshot, priority limits.
- build_report.txt: actual compilation and rendering checks.
- SHA256SUMS.txt: checksums of the preceding deliverables and this README.

## Build and run

A normal TeX Live or MiKTeX installation with the packages named in the
preamble is sufficient. No external graphics, BibTeX, shell escape, or
repository checkout is needed.

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
    python verification.py

Python 3.9 or later is sufficient. No third-party Python package is used.
To write a fresh verification record:

    python verification.py --output my_verification_results.txt

## Status

The arbitrary-rank fixed-dilation classification is a proposed original
contribution with a complete mathematical proof. Publication priority is
not certified. No named published conjecture is claimed solved. The
classical D-finite/recurrence equivalence, partial theta function, and
support lemmas are credited as established ingredients. The literature
audit was targeted, not exhaustive.

No independent peer review or Lean verification is claimed. The finite
checks do NOT prove strong summability, eventuality, cofinality, or the
universal nonexistence results. They test finite identities, indexing,
and valuation comparisons. Finite truncations of the explicit series
are polynomials and cannot witness its nonholonomicity.

The theorems concern LINEAR differential and dilation equations. They do
not claim nonlinear differential transcendence or unrestricted mixed-
dilation independence. Entireness always refers to one fixed set-sized
Hahn workspace, never the whole proper class No[i].

## Repository comparison

The inspected repository snapshot is

    VladimirReshetnikov/Surreal
    a3124af79f66b8b9c196d76b4cbc5ac3938907c4

The main comparison is with the report under
`docs/surcomplex/entire-functions-at-arbitrary-rank/`. That report concerns
entire-ring structure and scalar extension; the present report concerns
which fixed differential/dilation operators admit entire solutions.
The mathematical proofs here do not depend on unverified claims from
another AI-assisted repository report. No repository files were modified
and none of their source articles is redistributed in this archive.
