# Differential Rigidity of Hahn Rings
## Curves, Abelian Varieties, and Omnific Diophantine Points

Research article prepared for Vladimir Reshetnikov, September 23, 2026.
Author: OpenAI ChatGPT. The compiled article has 21 PDF pages.

## Main result

For a characteristic-zero field k and a nonzero set-sized ordered abelian
group Gamma, let B consist of the Hahn series in k((t^Gamma)) whose
well-ordered support is contained in Gamma_{<=0}. If C is a smooth
geometrically integral affine curve over k, then

    C(B) != C(k) if and only if C is isomorphic over k to the affine line.

The underlying theorem proves X(B) = X(k) for every smooth proper
finite-type k-scheme with globally generated cotangent sheaf. This includes
positive-genus proper curves and abelian varieties. Further consequences
cover tori, semi-abelian varieties, finite covers, and unimodular projective
coordinates. The mechanism contracts global differentials along Euler
derivations in two opposite rings and uses their trivial intersection.

For omnific integers, the article answers the smooth geometrically integral
curve part of the repository's Question 14.1. In particular, all omnific
points on y^2 = x^3 + a*x + b with integer a,b and 4*a^3 + 27*b^2 != 0 are
ordinary integer points. Singular cubics admit explicit infinite families.
An independent elementary argument proves the elliptic result and the more
general squarefree superelliptic assertion. A characteristic-two Hahn
counterexample shows that the characteristic-zero hypothesis is essential.

## Files

- `article.tex`: standalone LaTeX source with internal bibliography.
- `article.pdf`: compiled research article, 21 pages.
- `verify.py`: exact finite algebraic regression checks.
- `verification.json`: recorded successful run (3,440 assertions).
- `SOURCE_AUDIT.md`: repository snapshot, source comparison, and proof scope.
- `BUILD_AUDIT.json`: build and PDF-layout checks.
- `requirements.txt`: Python dependency for the regression checks.
- `Makefile`: build, verification, and cleanup commands.
- `README.md`: this guide.

No font files or third-party manuscripts are redistributed.

## Build and reproduce

A TeX installation providing pdfLaTeX, latexmk, and the packages in the
source preamble is sufficient. No external bibliography processor is needed.

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex
python3 -m pip install -r requirements.txt
python3 verify.py
```

Alternatively, `make` builds the PDF and `make check` runs the checks.
Without latexmk, run pdfLaTeX repeatedly until references and the table of
contents stabilize. `make clean` removes auxiliary TeX files, not the PDF.
The verification script requires Python 3.10 or newer and was tested with
Python 3.13.5 and SymPy 1.14.0. Its random tests use a fixed seed.

## Repository basis

Repository: https://github.com/VladimirReshetnikov/Surreal
Snapshot: `4cdeaec43ff1692ed2ad9f5bdf761a41872975a5`.
Principal input: `docs/surreal/omnific-diophantine-geometry/article.tex`,
especially Section 7 and Question 14.1 (`odg:q:affine`). Euler derivations,
support degree, constant-term retraction, and earlier separated-power
results are credited to the existing report, not claimed as new here.

## Evidence and limitations

The article supplies complete mathematical proofs of the proposed results.
It is an AI-assisted research draft, not a refereed or Lean-verified paper.
The finite checks test displayed identities, examples, and finite-series
algebra. They do not verify the infinite-support, algebraic-geometric, or
proper-class arguments, and are not a substitute for those proofs.

The literature comparison is targeted, not exhaustive. In particular, the
bibliographic record and abstract of van den Dries's 1981 paper were checked,
but its full proof was not accessible through the consulted route. Historical
priority and the word "breakthrough" are not certified. The general singular
curve and higher-dimensional parts of the repository's question, and the
primitive-but-non-unimodular Fermat problem, are not claimed solved.
