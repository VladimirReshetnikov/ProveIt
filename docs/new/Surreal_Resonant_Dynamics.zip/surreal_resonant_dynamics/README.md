# Sharp Linearization at Surreal Scales

**Hahn summability, resonant periodic cycles, transcendental conjugacies, and omnific rational maps**

A 23-page research article (including the title page), with a standalone LaTeX
source, seven principal theorem statements, complete proofs of the proposed
results, eleven further research questions, and exact finite regression checks.

## Read first

Open `article.pdf`. The main results are:

- **Theorems 4.2 and 5.4:** exact maximal centered strong-linearization ball for
  `f(z) = (zeta + d) z + sum_j a_j z^(1+jm)` over an arbitrary-rank divisible
  complex Hahn field, where `zeta` is an ordinary primitive mth root of unity
  and `v(d) > 0`. The exact threshold is
  `rho = max_j (v(d) - v(a_j))/(jm)`.
- **Theorems 6.1 and 6.4:** a finite residue polynomial determines the reduced
  linearizing coordinate, with an exact criterion for its algebraicity and a
  one-way transcendence certificate for the full conjugacy.
- **Theorems 8.1, 9.1, and 10.1:** classification of all infinitesimal periodic
  points of integral equivariant polynomials, finite shell realization, and
  reciprocal rational maps with prescribed Gaussian omnific periodic sets.

The explicit real two-scale example has precisely the infinitely large finite
periodic points `omega`, `-omega`, `omega^omega`, and `-omega^omega`, paired into
two exact two-cycles. Its rational-map coefficients have an explicit purely
infinite omnific presentation.

## Status and limits

These are proposed research contributions, not externally refereed results.
The written proofs are supplied, but no Lean verification of these new results
is claimed. Novelty is provisional. No resolution of a named longstanding
conjecture is asserted.

The paper explicitly credits Lindahl's rank-one linearization work, standard
Hahn-field algebraic closedness, and Neumann's summability lemma. It does not
assume the truth of unreviewed repository research claims. The repository
inspection was a targeted guide/notation audit, not an exhaustive reading of
all manuscripts. See `SOURCE_AUDIT.md` and Appendix B.

In particular:

- Strong Hahn summation is not identified with sequential convergence.
- Exact rotational symmetry and finite polynomial input are essential to the
  stated sharp linearization theorem.
- The algebraicity criterion is an equivalence for the reduced conjugacy;
  failure certifies transcendence upstairs, but success does not prove
  algebraicity upstairs.
- A rational-map presentation over `Oz[i]` is not a self-map of the entire ring.
- The radius shell is not being called a topological boundary.

## Files

- `article.tex`, `article.pdf`: standalone source and final typeset article.
- `verify.py`: reproducible exact finite regression checks.
- `verification.json`, `verification.txt`: actual successful run results.
- `requirements.txt`: the tested SymPy version.
- `build.sh`, `build.ps1`: Unix and PowerShell build scripts.
- `SOURCE_AUDIT.md`: source scope, repository pin, and priority limitations.
- `PROOF_AUDIT.md`: proof dependencies and sensitive steps.
- `BUILD_REPORT.json`: compilation and PDF quality-control record.

No font files or third-party manuscripts are included.

## Reproduce the finite checks

Use Python 3.10 or later. The supplied run used Python 3.13.5 and SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python verify.py
```

The supplied run passed **1,863 assertions in six groups**. This is a finite
regression test suite, not a formal proof of infinite summability or universal
period classification. `--output-dir PATH` writes the test reports elsewhere.

## Rebuild the PDF

A TeX Live or MiKTeX installation with pdfLaTeX and the packages named in the
preamble is sufficient. The bibliography is internal; no BibTeX or external
images are required.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `sh build.sh`, or `./build.ps1` in PowerShell. These scripts
also rerun the finite checks. They intentionally update the local PDF and
verification reports. The checked build has no unresolved references, TeX
warnings, or overfull/underfull boxes.
