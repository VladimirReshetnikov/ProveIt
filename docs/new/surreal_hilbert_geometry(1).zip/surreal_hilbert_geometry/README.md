# Hilbert Geometry at Surreal Scales

**Orthogonal subspaces, infinitesimal graphs, metric rigidity, and projection-lattice obstructions**

Research manuscript prepared for Vladimir Reshetnikov, September 23, 2026.

## Contents

- `surreal_hilbert_geometry.tex`: standalone LaTeX article, with internal bibliography.
- `surreal_hilbert_geometry.pdf`: compiled 25-page article.
- `build.sh`: LaTeX build command.
- `verify_finite.py`: standard-library Python checks using exact rational arithmetic.
- `verification.json`: output of the finite checks.
- `RESEARCH_AUDIT.md`: source comparison, proof status, and scope limitations.

## Principal results

The setting is `E_Gamma(H) = H((t^Gamma))`, where H is an ordinary real or complex Hilbert space and Gamma is a set-sized ordered abelian group. An ordinary orthonormal basis makes the vector coordinates Hahn scalars. For Gamma contained in No, `t^gamma = omega^(-gamma)` makes these actual surreal or surcomplex coordinates. Section 11 constructs the extension over all of No or No[i] with set-supported vectors.

Theorem 6.3 classifies all orthogonally complemented subspaces above a fixed ordinary closed residue as graphs of positive-order Hahn series of ordinary bounded operators. This uses, rather than claims to invent, the classical two-projection intertwiner and the repository's automatic adjointability theorem.

Theorem 8.1 gives an exact criterion for the infinitesimal graph of an ordinary closed densely defined operator: it is orthoclosed and valuation-spherically complete, but orthogonally complemented exactly when the ordinary operator is bounded.

Theorem 9.1 constructs a positive self-adjoint operator with only three exponents whose kernel is not orthogonally complemented. Theorem 9.3 uses the same example to show that the projection poset on a Hahn extension of l2 is not even a lattice. Theorem 9.4 gives a countable mutually orthogonal rank-one family with no least upper bound, all at one infinitesimal scale. These conclusions hold at every nonzero ordered value group.

Theorem 10.1 proves that a positive Hahn metric with strictly positive ordinary residue is linearly isometric to the canonical metric exactly when its residue has a positive ordinary uniform lower bound. No continuity or adjointability of the hypothetical bijective isometry is assumed. Infinitesimal coercivity alone does not suffice.

Theorem 11.1 proves automatic set-supported bounded-operator expansions for globally adjointable class-linear maps over the full surreal or surcomplex scalar class. The geometric theorems and counterexamples therefore persist globally.

## Build and finite checks

A standard TeX Live installation with pdflatex and latexmk suffices:

```sh
./build.sh
python3 verify_finite.py --output verification.json
```

Equivalently, build directly with:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_hilbert_geometry.tex
```

Python 3.10 or later is required for the verification script. It has no external dependencies. The script completed **234 exact identity checks**, including the order-14 formal-prefix identities, using exact rational arithmetic throughout. The script does not verify the infinite-dimensional theorems or the proper-class constructions.

## Delivery checks

The article was compiled successfully with pdfLaTeX via latexmk. The final source has no unresolved references or citations and no overfull boxes. The PDF pages were rendered and visually inspected, including the projection-family formulas and the metric and global sections. A geometric text-bounding-box scan found no text close to the page edge. A harmless underfull-box diagnostic remains in the contribution table; it is not clipped text.

The mathematical proofs have not been independently refereed or verified in Lean or another proof assistant. Candidate novelty is distinguished from inherited results in the article and audit. No named published conjecture is claimed solved.

## Repository pin

The observed repository snapshot was:

`a45d72292a46dac13300d395101df188efb84eef`

The consulted repository descriptions identify several substantial predecessors; they are credited throughout. The audit is targeted rather than a claim to have exhaustively searched or independently checked every repository manuscript.
