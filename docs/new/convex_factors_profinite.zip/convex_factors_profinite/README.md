# Convex Factors and Profinite Obstructions for Initial Surreal Groups

**Sign-tree compression, omnific realizations, and explicit noninitial arithmetic models**  
AI-assisted research draft prepared for the Surreal project, 23 September 2026.

## Contents

- `convex_factors_profinite.pdf` — the compiled, 23-page article, including the title page, contents, appendices, and references.
- `convex_factors_profinite.tex` — standalone LaTeX source with an internal bibliography; no external images or bibliography database are required.
- `code/verify.py` — exact finite regression checks, Python 3.10 or later, standard library only.
- `data/verification.json` — recorded successful verification run and sample factorial generators.
- `PROVENANCE.md` — source, dependency, novelty, and review boundaries.

## Main results developed in the article

The central theorem gives an explicit initial surreal realization of every convex factor of an initially realizable ordered abelian group. It combines interval restriction of normal forms with retained-ancestor sign compression. All convex subgroup sequences split in a chosen initial realization, and the factor constructions are coherent under nested restrictions.

For a model of additive Presburger arithmetic, initial surreal realization is equivalent to initial omnific realization, to splitting of its least-positive cyclic subgroup, and to its coherent residue image in the profinite integers consisting only of ordinary integers. A factorial family supplies continuum many countable rigid counterexamples. The article also treats dense elementary-equivalence counterexamples, an omitted recursive type, ultrapowers, nonstandard Peano arithmetic, unit-preserving omnific embeddings, and rectangular surcomplex modules.

Here “initial” means closed under proper prefixes in the surreal sign tree. “Initially realizable” means isomorphic as an ordered additive group to such a subgroup. These notions must not be confused with literal initiality of a subgroup in its original position.

## Build

From this directory, with a LaTeX installation containing the packages named in the source:

```sh
pdflatex -interaction=nonstopmode -halt-on-error convex_factors_profinite.tex
pdflatex -interaction=nonstopmode -halt-on-error convex_factors_profinite.tex
```

An additional pass can be used if the compiler requests updated cross-references. Alternatively:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error convex_factors_profinite.tex
```

## Run the checks

```sh
python3 code/verify.py --output data/verification.json
```

The program prints a JSON report and writes the requested output file. Run without Python's `-O` flag, because its checks use assertions. The recorded run returns `PASS`, including 1,398,609 finite order/prefix/meet pair checks, 324,632 coherence point checks, and the finite arithmetic checks reported in the article.

These are regression tests, not a proof of the transfinite or model-theoretic theorems. The proofs are in the article, with external structural results explicitly identified. No Lean code or Lean verification is delivered.

## Status

The central convex-factor result and the surreal applications are proposed research contributions with complete written proofs. Neither priority nor independent referee certification is claimed. The classical initial Hahn criterion, divisible-group embedding theorem, profinite residue structure, and extension-class background are credited rather than presented as new.

The repository was inspected at commit `9693b28c24e6fcb317ce47969a40185c5dfef402`. The package is a standalone article, not a modification of that repository. It does not claim to settle the full published optimality problem for all theories between ordered abelian groups and divisible ordered abelian groups.
