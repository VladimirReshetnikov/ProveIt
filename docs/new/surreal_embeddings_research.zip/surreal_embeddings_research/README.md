# Coefficient Gaps and Proper Self-Embeddings of the Surreal Field

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 23 September 2026.

## Files

- `surreal_embeddings.tex`: standalone article, with all proofs, ten proposed research questions, and internal bibliography.
- `surreal_embeddings.pdf`: compiled article.
- `verify_finite_models.py`: exact, deterministic, standard-library Python tests.
- `verification.json`: output of the supplied tests; 3,880 assertions passed.
- `SOURCE_AUDIT.md`: repository pin, inspected material, novelty boundaries, and proof assumptions.
- `Makefile`: optional build and test commands.

## Mathematical contribution

The central theorem classifies strongly additive field embeddings of full real Hahn fields that take canonical coefficient-one monomials to canonical coefficient-one monomials and preserve the canonical integer parts. For an exponent embedding tau, the real coefficient section has to lie in the Hahn field on the largest convex subgroup disjoint from the value image except at zero. This is also sufficient.

Consequences include an omnific-preserving proper self-embedding moving a real transcendental b to b + omega^-1; an independent cofinality/coinitiality dichotomy; closedness and nowhere density of proper classified images; continuum many nonconjugate copies under omnific-preserving ambient automorphisms, even though they are ambiently field-conjugate; parameter-fixed discrete and nondiscrete proper copies; and conjugation-compatible surcomplex analogues.

## Scope and limitations

This is a research draft with mathematical proofs, not a refereed publication or a Lean-verified development. Priority is provisional. The classification has a substantive exact-monomial hypothesis and is not a classification of all surreal embeddings. The coefficient Taylor automorphisms, exponent lifts, reconstruction of constants, and classical field-theoretic inputs are credited as prior work. The derivations of the real field use an ordinary choice of a transcendence basis; the construction is not a computable procedure for arbitrary real inputs.

The finite tests do not prove infinite-support, proper-class, conjugacy, or model-theoretic theorems. They check finite algebra and sign conventions only. No remote repository was modified or built.

## Build

Requires Python 3.10+ for the tests and a standard TeX Live installation for the PDF.

```sh
python3 verify_finite_models.py --output verification.json
pdflatex -interaction=nonstopmode -halt-on-error surreal_embeddings.tex
pdflatex -interaction=nonstopmode -halt-on-error surreal_embeddings.tex
```

Alternatively run `make` (with `latexmk` installed) and `make test`.

## Repository baseline

Repository: https://github.com/VladimirReshetnikov/Surreal

Actual pinned commit: `cf56b89d0417cf66b26f9292654f6cae60182339`.

The repository was changing during research. An earlier API response provided the Git tree identifier `a6c68ac3826ac337762b71a2ef901997d019260c`, not a commit. Relevant document blobs were checked again at the actual commit as recorded in `SOURCE_AUDIT.md`.
