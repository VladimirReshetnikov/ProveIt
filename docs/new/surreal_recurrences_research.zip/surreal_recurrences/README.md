# Valuation Rigidity and Coefficient Universality in Surreal Recurrences

**A mixed differential–dilation theorem and the limits of coefficientwise predictability**  
Research draft prepared for Vladimir Reshetnikov, 23 September 2026.

## Files

- `article.pdf`: the 22-page typeset article, including proofs, boundary examples, 12 further research questions, and bibliography.
- `article.tex`: complete standalone LaTeX source; no external graphics or BibTeX database is required.
- `verify.py`: standard-library Python exact-arithmetic regression checks for explicit identities and examples.
- `verification.txt`: actual output from the checks; 4,605 checks passed.
- `SOURCE_AUDIT.md`: repository snapshot, comparison passages, source roles, and the novelty/verification boundary.
- `build.sh`: optional rebuild command.
- `SHA256SUMS`: checksums of the other archive files.

## Principal results and where to read them

Theorem 5.5 and Theorem 7.1: eventual affine valuation/leading-Conway-exponent profiles on finitely many ordinary arithmetic progressions for all finite constant-coefficient surcomplex recurrences, with zero classes treated separately. The value group may have arbitrary rank.

Theorem 6.2: for valuation-unit characteristic roots, any set-sized collection of coefficient-polynomial equations reduces to a finite subcollection along the entire orbit. Its hitting set has a period determined by the torsion of the root-residue group.

Theorem 7.3: for every real sequence b, the purely infinite omnific initial value

    A_b = sum_{m >= 0} b_m omega^(omega-m)

satisfies `[omega^omega](omega^n A_b) = b_n`. The ordinary first-order recurrence with fixed multiplier omega therefore has completely unrestricted observations at one fixed Conway coefficient. This is pre-encoding in an infinite initial value, not an algorithm that generates arbitrary information.

Theorem 10.1 and Corollary 10.2: the mixed unit-dilation rigidity statement left unclassified in the inspected repository report is proved at manuscript level, including value groups with an order unit.

Theorem 10.4: for a finitely generated torsion-free dilation group, a nonpolynomial strongly entire solution of some nonzero finite linear differential–dilation equation exists exactly when the dilation valuations generate the entire value group as a convex subgroup. A partial theta series gives the positive witness. The pure theta construction is credited to the repository rather than presented as a new special function.

## Rebuild

A conventional TeX Live or MiKTeX installation with the packages named in the preamble suffices. On a POSIX system:

```sh
./build.sh
```

The underlying commands, also usable independently on other platforms, are:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
python3 verify.py
```

Python 3.10 or newer is required; no third-party Python packages are used. The script raises an exception and exits unsuccessfully if a check fails. LaTeX produces auxiliary files in the working directory. Build timestamps can cause a rebuilt PDF to differ byte-for-byte from the supplied PDF even when the content is identical.

## Status

This is an AI-assisted, unrefereed research manuscript. It contains full written arguments relative to explicitly cited standard theorems, especially Skolem–Mahler–Lech and the Hahn–Neumann support lemma. Independent correctness and worldwide priority have not been certified. No Lean formalization was produced or represented as checked. The repository comparison was targeted, not exhaustive.

The finite tests check examples, coefficient formulas, and indexing. They are not substitutes for proofs of the infinite-support or universal results. The manuscript does not solve the classical Skolem problem, does not assert unrestricted nonlinear mixed rigidity, and does not establish that the coefficient-encoding observation is definable in the pure omnific ring.

All recurrence indices are ordinary natural numbers. Statements about strong entireness concern a fixed set-sized Hahn field, not simultaneous entireness on the entire proper class of surcomplex numbers. The derivative is the variable derivative fixing the coefficient field, not the Berarducci–Mantova derivation on surreal coefficients.
