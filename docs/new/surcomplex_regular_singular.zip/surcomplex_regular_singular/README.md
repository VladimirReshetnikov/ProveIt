# Regular-Singular Spectral Selection over Surcomplex Numbers

**Finite resonance data, Hahn normal forms, resonant logarithms, and complete solution classification**

Research draft, September 22, 2026. Prepared in response to a request to develop substantial new results related to the VladimirReshetnikov/Surreal repository.

## Main results

For t = omega^(-1), delta = -omega * partial (the normalized Berarducci–Mantova derivation), and K = C((t^R)), the article treats delta y = A y with A of nonnegative Hahn order and ordinary complex residual matrix A0.

* The full surcomplex solution space has complex dimension equal to the total algebraic multiplicity of the **real** eigenvalues of A0. Every ambient solution already lies in K[log t].
* An explicit support-controlled normal form has constant matrix iD + N, with D real diagonal, N nilpotent, and DN = ND. Only finitely many resonance-reaching coefficients determine N, even when the input support accumulates below a finite exponent.
* Phase labels and the nilpotent Jordan partitions classify these systems over K. Over the full surcomplex field only the phase multiplicities remain. The article also proves exact morphism dimensions, an inhomogeneous kernel–cokernel theorem, a minimal one-logarithm extension result, finite-monomial workspace bounds, and a counterexample outside the power-Hahn coefficient hypothesis.

## Files

- `article.pdf`: typeset article.
- `article.tex`: self-contained LaTeX source, including bibliography.
- `verify.py`: exact finite-support normalizer and symbolic regression checks.
- `verification.json`: machine-readable output of the recorded successful checks.
- `verification.txt`: human-readable transcript of the same run.
- `requirements.txt`: pinned version of the symbolic library used for the recorded checks.
- `Makefile`: build, verification, and cleanup commands.

No external figures, bibliography database, or font files are required.

## Build

A standard TeX Live installation with pdfLaTeX and the packages listed in the preamble is sufficient:

```sh
make pdf
```

Equivalently, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times. The last run resolves cross-references and the table of contents.

## Reproduce the exact checks

The recorded run used Python 3 and SymPy 1.14.0:

```sh
python -m pip install -r requirements.txt
python verify.py --output verification.json > verification.txt
```

Or run `make verify`. The checks use exact rational and Gaussian-rational arithmetic; no floating-point tolerance is used. The deterministic regression seed is 20260922.

The code handles finite positive rational supports, a specified rational cutoff, and an explicitly supplied generalized-eigenvalue block decomposition. It is not a parser or decision procedure for arbitrary surreal numbers or arbitrary indirectly described infinite supports. The infinite-support theorems are proved in the article, not established by these finite tests.

## Status and novelty

The draft supplies complete mathematical arguments under its stated hypotheses. It is not independently refereed or Lean-verified. Classical Levelt theory, Hahn support principles, and the Berarducci–Mantova differential structure are credited as antecedents. The scalar oscillation obstruction and existing matrix work in the repository are explicitly acknowledged. The proposed contribution is the finite-resonance support theorem and the explicit two-field classification package, not a claim that regular-singular theory or the scalar obstruction is new.

No named published open conjecture is asserted to have been resolved. The specific formulations were not located in the primary sources and repository materials reviewed; this is a limited priority assessment, not an exhaustive literature guarantee. See Section 15 and the audit appendix.

The repository was read only and was not modified. The initially inspected tree reported commit a3124af79f66b8b9c196d76b4cbc5ac3938907c4; the article distinguishes that provenance from a claim that every subsequently read README was immutable during the review.
