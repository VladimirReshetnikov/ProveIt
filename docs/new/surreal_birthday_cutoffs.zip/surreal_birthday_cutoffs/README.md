# What a Birthday Cutoff Remembers

**Hereditary Set Universes, Elementary Obstructions, and Forcing Invisibility**

Research article prepared for Vladimir Reshetnikov, September 22, 2026.
The PDF has 25 pages. The LaTeX source is standalone; its bibliography is
embedded and it does not require BibTeX or any downloaded font files.

## Main mathematical content

For an epsilon number lambda, let B_lambda be the field of surreal numbers
of birthday below lambda, expanded by its ordinal-valued birthday function.
The article specifies a single parameter-free, four-dimensional first-order
interpretation whose exact image is H_{kappa(lambda)}, where kappa(lambda)
is the least infinite cardinal at least lambda.

It proves the bounded coding theorem with explicit budgets for domain,
relation, subset, and cone-isomorphism codes. Consequences include:

* Every countable epsilon cutoff, including epsilon_0, interprets all
  hereditarily countable sets.
* A single sentence holds exactly at noncardinal epsilon cutoffs.
* No noncardinal epsilon cutoff has a proper canonical elementary
  birthday-fragment extension. Any elementary inclusion between epsilon
  fragments requires cardinal cutoffs and an elementary inclusion of their
  hereditary universes.
* A single translated Power Set sentence holds exactly when the cutoff is a
  strong-limit cardinal. This does NOT characterize regularity.
* Under the explicit measurable-cardinal hypothesis, ordinary Prikry forcing
  leaves the birthday-enriched field below kappa literally unchanged while
  making the cofinality of kappa countable. Thus ambient regularity cannot
  be uniformly recognized by a fixed first-order sentence of the fragment.
* The results transfer to the explicitly enriched surcomplex field with
  conjugation, a named i, and a coordinate birthday function.

## Attribution and status

Chen--Hamkins--Yang's announced full-class bi-interpretation is prior work,
not a novelty claim of this article. The proposed contributions are the
size-sharp bounded refinement and its cutoff/forcing consequences. The exact
formulations were not found in the inspected sources, but priority is not
certified. This is an unrefereed research manuscript with mathematical proofs,
not a machine-checked formalization and not a claimed solution of every open
problem in surreal foundations. See Section 13 and SOURCE_AUDIT.md.

The forcing theorem imports the classical properties of ordinary Prikry
forcing; it neither constructs a measurable cardinal nor proves its existence.

## Files

- article.pdf: the typeset article.
- article.tex: complete standalone source.
- code/verify_finite.py: exact finite regression tests, standard library only.
- data/verification.json: recorded test results.
- data/verification_summary.tex: the generated test-summary paragraph;
  already embedded in article.tex, so not needed to compile the article.
- data/build.json: build and proof-status metadata.
- SOURCE_AUDIT.md: source scope and novelty limitations.
- SHA256SUMS.txt: delivery checksums for all other package files.

## Rebuild

From this directory, with a standard TeX installation:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Three passes stabilize the table of contents, citations, and cross-references.
The commands work in PowerShell as well as a Unix shell. Packages are standard
TeX Live/MiKTeX packages, including amsmath, amsthm, lmodern, microtype,
geometry, hyperref, cleveref, and booktabs.

To rerun the finite tests (Python 3.9 or later):

    python code/verify_finite.py

The executed build used Python 3.13.5. The test program overwrites its two
files in data/, so run it on a copy when preserving original delivery bytes.
All recorded checks passed: 65,025 prefix comparisons; 1,538 bit positions;
173,880 natural-ordinal matrix addresses on exact finite Cantor-normal-form
samples; 687 relabellings of all 16 elements of V_4; 1,024 pairs of equality
and membership tests; and rejection of four invalid graph codes.

Finite tests do not prove the transfinite interpretation or forcing results.
Their role is to check the coding conventions and implementation examples.
