# Unit-Dilation Rigidity at Surreal Scales

A valuation form of Skolem–Mahler–Lech and an exact relative-scale criterion
for mixed differential–dilation equations.

Prepared for Vladimir Reshetnikov, 23 September 2026.

## Files

- `unit_dilation_rigidity.pdf`: the complete research article.
- `unit_dilation_rigidity.tex`: standalone LaTeX source, with inline bibliography.
- `verify_finite.py`: standard-library Python exact finite checks.
- `finite_verification.json`: output from the supplied script.
- `SOURCES_AND_SCOPE.md`: pinned comparison, theorem map, and limits of the claims.
- `README.md`: this file.

## Main mathematical results

The ambient field is K = k((t^Gamma)), with k of characteristic zero and Gamma
a nonzero set-sized ordered abelian group. Entire means strong Hahn summability
of the evaluation family at every point of this one field. D_z kills K.

1. Theorem 4.7: Hahn-valued exponential-polynomial sequences have eventually
   affine valuations on finitely many arithmetic progressions, with identically
   zero progressions allowed. Unit bases give eventual periodic valuations.
2. Theorem 6.4 and Corollary 6.5: mixed linear differential–dilation equations
   at noncofinal relative scales have only polynomial strongly entire solutions.
   This answers the pinned repository's explicit unit-valuation question.
3. Theorem 7.2: for a finite prescribed set of multipliers with no root-of-unity
   ratios, some nonzero mixed linear equation admits a nonpolynomial strongly
   entire solution if and only if an absolute relative valuation is an order
   unit. Two prescribed multipliers and first derivatives suffice for a witness.

The article also includes polynomial forcing, uniform degree bounds, common
exterior evaluation obstructions, surcomplex examples, boundary counterexamples,
and 12 proposed research questions.

## Build

Use a standard TeX Live installation with pdfLaTeX and the packages named in
the source preamble. No images, downloaded data, font files, or BibTeX run are
needed. From this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error unit_dilation_rigidity.tex
pdflatex -interaction=nonstopmode -halt-on-error unit_dilation_rigidity.tex
pdflatex -interaction=nonstopmode -halt-on-error unit_dilation_rigidity.tex
```

The third pass ensures the table of contents and all page references settle.
The delivered PDF was compiled without undefined references or overfull boxes.

## Run the finite checks

Requires Python 3.10 or later; no third-party packages.

```sh
python3 verify_finite.py --output finite_verification.json
```

The delivered run passed 16,579 exact assertions in 11 categories. They check
finite algebra and examples only. Their count is not a measure of proof coverage.
They do not verify arbitrary Hahn supports, all field arguments, SML, eventual
exceptional-zero bounds, nonexistence of an annihilator, or novelty.

## Research and verification status

This is an AI-assisted proof-bearing research draft. It has not been
independently refereed or formalized in Lean. The classical
Skolem–Mahler–Lech theorem is explicitly imported; the article proves the new
deductions and provides the support and recurrence arguments in detail.

The comparison is to the specific repository snapshot named in
SOURCES_AND_SCOPE.md. The result answers an explicit question in that snapshot;
it is not presented as the resolution of a named historical conjecture or as
a certified first occurrence of every statement. The exact finite-set theorem
classifies existence of SOME equation, not solvability of EVERY prescribed
operator, nor simultaneous systems. Nonlinear order-unit rigidity is not solved.

No repository files were changed or uploaded. The PDF and source are the new
standalone deliverables.
