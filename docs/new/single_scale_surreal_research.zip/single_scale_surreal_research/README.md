# Differential Freedom at a Single Surreal Scale

**Factorial-height entire functions, exact relation ideals, and omnific codes**

AI-assisted research manuscript prepared 23 September 2026 for the Surreal
project. The main source is `article.tex`; the compiled article is `article.pdf`.

## Central result

For `S_A(q) = sum_{n in A} q^(n!)` and
`F_A(q,z) = sum_{n in A} q^(n!) z^n`, the manuscript gives an exact description
of all differential-algebraic relations in every finite family of index sets.
After explicit finite polynomial corrections, the relation ideal is generated
by the linear relations among the membership patterns occurring infinitely
often. All remaining generators and their jets are algebraically independent.
The construction also works for increasing integer heights with successive
ratios tending to infinity.

The pure z-derivative assertion allows the **entire Hahn scalar field** in the
coefficients of a proposed differential equation, not just Q(q). The mixed
q,z assertion has base k(q,z) with both derivations explicitly defined.
These are different assertions and must not be conflated.

Applications include strongly entire functions at a single cofinal scale,
continuum-sized jointly independent families with arbitrary finite Hermite
data, actual surreal numbers with independent Berarducci–Mantova jets over
the bounded-support fraction field, an exact common strong-evaluation domain
in No[i], algebraically independent omnific codes, and exact floor profiles.

## Research status

The source includes full written proofs relative to standard Hahn/Conway and
Berarducci–Mantova foundations. The results have **not** been independently
refereed or formalized in Lean. Novelty is proposed, not certified.

The numerical single-series gap theorem is classical: Ostrowski's 1920 paper,
Section 5 immediately before Theorem 11, attributes the unbounded-ratio gap
criterion to Grönwall. That result is expressly **not** claimed as a new discovery.
The proposed contribution is the joint and exact-relation package and its
specified Hahn/surreal/omnific realizations.

The universal question whether every differentially algebraic strongly entire
function in an order-unit Hahn field must be polynomial is **not** solved here.
Nor is any primality or irreducibility statement made for the omnific codes.

## Contents

- `article.tex`, `article.pdf`: self-contained source and compiled manuscript.
- `PROOF_AUDIT.md`: proof-sensitive steps, dependencies, and non-claims.
- `SOURCES_AND_SCOPE.md`: pinned repository comparison and literature findings.
- `verify.py`, `verification_results.json`: exact finite regression checks and
  the recorded successful run (8,608 checks).
- `build.py`, `build_audit.json`: three-pass builder and compilation audit.
- `visual_audit.json`: page-layout inspection and text-boundary checks.
- `requirements.txt`: the SymPy version used by the finite checks.

## Reproduce

Install Python 3.10 or later and a TeX installation with pdfLaTeX, AMS packages,
New PX text/math, geometry, microtype, xcolor, booktabs, tabularx, longtable,
enumitem, fancyhdr, needspace, hyperref, and bookmark. No font files are included.

```sh
python build.py
python -m pip install -r requirements.txt
python verify.py --output verification_results_rerun.json
```

The builder writes auxiliary files to `.build/` and replaces `article.pdf`
after a successful three-pass build. It rejects unresolved references and
overfull boxes. Byte-for-byte reproducibility of PDF metadata is not claimed.
The checks use exact sparse polynomial and integer arithmetic; they do not
numerically approximate infinite surreal sums and do not prove the infinite
theorems.

## Repository snapshot

`https://github.com/VladimirReshetnikov/Surreal`

Pinned commit: `bcac55ae6fd3f2b354e568ba1d2e94d496a2cc59`.

The package does not modify the repository and makes no claim of an exhaustive
review of its reports or Lean declarations.
