# Set-Sized Shadows of Omnific Integers

**Universal Arithmetic Quotients, Sharp Cardinal Barriers, and Invisible Infinite Primes**

Research manuscript prepared for Vladimir Reshetnikov with OpenAI ChatGPT,
22 September 2026.

## Files

- `omnific_set_shadows.pdf`: the typeset article.
- `omnific_set_shadows.tex`: standalone LaTeX source with an internal bibliography.
- `verify.py`: deterministic exact finite checks; Python 3.10+, standard library only.
- `verification.json`: the executed check report (597 assertions, all passed).
- `SOURCE_AUDIT.md`: repository pin, sources, novelty and verification boundaries.
- `build.sh`: verification and LaTeX build script.

## Principal results

Let I be the class of surreal normal forms with strictly positive exponents.
Every unital ring homomorphism from Oz = Z + I into any set-sized ring factors
uniquely through its integer constant coefficient. More generally the same
holds for D + I_k, where k is R or C and D is a unital subring of k. All
set-sized modules factor through the same coefficient ring.

For every cardinal lambda >= continuum with lambda^(aleph_0) = lambda, the
article constructs explicit subrings A_lambda of Oz, and Gaussian versions
inside No(i), of cardinality lambda. Any ring image or module detecting their
positive-support ideal must have at least lambda elements. The lower bound
is attained: every nonzero element of that ideal maps to 1 in some residue
field of cardinality lambda. In the integer-constant case all other residue
fields are ordinary prime fields; there are at least lambda non-arithmetic
maximal ideals.

The article also proves the set-sized quotient and profinite classifications,
the invisibility of infinite irreducibles to set-sized ring maps, the exact
set-valued derivation statements (including Gaussian 2-torsion), and the ideal's
aleph_1 generator bound, flatness, idempotence, and self-Tor consequences.

## Build

With Python 3.10+ and a TeX installation containing `newtx`, `amsmath`,
`amsthm`, `mathtools`, `geometry`, `microtype`, `booktabs`, `tabularx`,
`enumitem`, `xcolor`, `xurl`, `hyperref`, and `fancyhdr`:

```sh
sh build.sh
```

The script uses `latexmk` when available, otherwise three passes of `pdflatex`.
No external bibliography database, image files, or font files are required.
No network requests are made by the verification program or build script.

To run only the finite checks:

```sh
python3 verify.py
```

The check report is written beside the script. An alternate destination is
available through `python3 verify.py --output path/to/report.json`.

## Scope and status

The principal universal and sharp cardinal theorems are candidate-original
results supported by full written proofs. Their historical novelty remains
provisional after a targeted literature and repository comparison. No named
factorization conjecture is claimed to have been solved. The prime
omega^(sqrt(2)) + omega + 1 is an established theorem of L'Innocente and Mantova,
not a new primality result of this manuscript.

The full-surreal assertions concern class functions in a class theory such
as GBC. The explicit set-sized constructions are in ZFC. No class-sized Zorn
argument or proper-class Hahn sum is used. The Gaussian omnific ring is a
subring of the surcomplex field, not the full field.

The finite checks do not verify infinite supports, surreal cuts, cardinal
arithmetic, maximal-ideal existence, or historical novelty. No Lean proof,
other proof-assistant verification, or independent referee review is supplied.
