# Universal Symmetries and Exact Difference Equations over the Surreals

**Prepared for Vladimir Reshetnikov — 23 September 2026**

A standalone research manuscript on group actions on the actual surreal
field and omnific ring, with exact additive and multiplicative difference
obstructions. The PDF has 25 pages, including its title page, contents,
proofs, twelve further research questions, appendices, and bibliography.

## Main results developed in the manuscript

- **Theorem 1.1:** A set-sized group acts faithfully on `No`, or on `Oz`,
  if and only if it is left-orderable. The sufficient action can be chosen
  strong, real-linear, and exact-monomial, preserving `Oz`, with every
  nonidentity element fixing exactly `R` and with the orbit of `omega`
  algebraically independent over `R`.
- **Theorem 5.1:** Such universality persists after fixing any prescribed
  set of parameters. Every nonidentity element then has the same explicit
  two-level Hahn-support fixed field.
- **Theorems 7.1 and 8.1:** A downward-orbit Green operator gives the exact
  additive obstruction and classifies all nonzero ordinary
  constant-coefficient scalar difference operators.
- **Theorems 9.2 and 9.4:** Multiplicative differences have precisely a
  leading-coefficient obstruction in the global action; an explicit
  multiplicative retraction onto the fixed field gives all three
  obstructions for the relative action.
- **Theorem 10.1:** Every scalar first-order equation is reduced to an
  ordinary leading coefficient and, in the resonant case, one explicit
  transformed constant-coefficient test.
- **Theorem 11.2 and Proposition 11.4:** Cocycles of groups with a central
  nonidentity element have exact character-plus-coboundary normal forms;
  free groups have additional explicitly described invariants.
- **Theorem 12.2:** With standard conjugation named, the groups that act
  faithfully on the surcomplex field preserving the Gaussian omnific
  ring are exactly the left-orderable groups and the groups `H x C_2`
  with `H` left-orderable.

The simplest explicit example is

    S(sum c_gamma * omega^gamma) = sum c_gamma * omega^(omega*gamma).

For this map,

    x = sum_{n>=1} omega^(omega^(-n))

is a purely infinite omnific integer satisfying `S(x) - x = omega`, while
`S(x) - x = 1` has no solution even in `No[i]`.

## Files

`article.tex` is the complete standalone LaTeX source, with an internal
bibliography. `article.pdf` is its typeset version. `verify.py` contains
finite exact-arithmetic checks, and `verification.json` records the
successful deterministic run. `SOURCE_AND_PROOF_AUDIT.md` records the
source review and proof boundaries. `BUILD_REPORT.json` records the final
build and PDF checks. `Makefile` supplies convenient build/check targets.

## Rebuild

Requirements: Python 3.10 or later; a TeX installation with pdfLaTeX,
latexmk, and standard packages including Latin Modern, AMS packages,
microtype, geometry, booktabs, longtable, enumitem, fancyhdr, xurl,
hyperref, and needspace.

```sh
python3 verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The verification script also accepts an alternate output path:

```sh
python3 verify.py --output /tmp/surreal-verification.json
```

It uses only Python's standard library. The recorded run passed **5,555
assertions in 29 groups**, using exact rational arithmetic. These are
finite formula checks, not a machine proof of the paper's theorems.

## Verification and novelty boundary

The proofs are manuscript arguments and have not been independently
refereed or formalized in Lean. The two Hahn lifts are established prior
constructions. The real-form centralizer factorization is also prior
material. The proposed contribution is their combination with a free
ordered action and exact fixed-field, inverse-operator, multiplicative
retraction, and cocycle results.

The repository review was pinned to
`e93a06de3d0da021022b574b498324bb041a0fe8` and was targeted, not an
exhaustive inspection of every report. Priority is not certified.
No named published exponential-automorphism question is claimed solved.
These automorphisms generally do not commute with the omega-map or the
Gonshor exponential. The first-order classification does not settle
arbitrary higher-order variable-coefficient or matrix equations.

The work does not modify the repository. No repository files, third-party
papers, or font files are redistributed in this package.
