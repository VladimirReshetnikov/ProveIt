# Omnific Integers and Diophantine Geometry
## Arithmetic retractions, rigidity, and infinite families

Research article prepared for the Surreal project, 22 September 2026.

## Files

- `article.tex`: standalone LaTeX source, including bibliography.
- `article.pdf`: compiled article.
- `verify_examples.py`: exact symbolic identity and finite-support checks.
- `verification.txt`: output from the supplied checks.
- `requirements.txt`: the version of SymPy used for those checks.
- `PROVENANCE.md`: source snapshot, proof dependencies, and verification limits.

## Main mathematical results

The paper uses the classical description Oz = Z + I, where I consists of
surreal normal forms supported at strictly positive exponents.

The constant-coefficient map is a split ring retraction Oz -> Z. It makes
ordinary-integer-coefficient equation existence over Oz exactly equivalent
to equation existence over Z. This does not preserve nonvanishing or order
conditions, and it does not mean that every solution has ordinary coordinates.

A unit argument gives an exact description of the constant-coefficient
fibers of equations that factor into affine linear forms and have a nonzero
constant right-hand side. Applications include Pell equations, binary forms
with at least two nonproportional complex linear factors, and full
number-field norm forms: every omnific solution on such a nonzero standard
level is an ordinary integer solution.

For a nondegenerate indefinite integral quadratic form in at least three
variables, every ordinary integer point on a nonzero standard level instead
has an injective polynomial family of purely infinite perturbations. The
construction uses a skew nilpotent operator N with N^3 = 0 and the finite
polynomial U(T) = Id + T N + (T^2/2) N^2. It proves a dimension/signature
dichotomy for the occurrence of genuinely infinite points on nonzero
nondegenerate quadratic levels. The paper does not claim to parametrize all
points of those higher-dimensional quadrics.

Additional results cover the corrected floor formula at negative
infinitesimal boundaries, finite quotients, completions, set-sized common
denominators and common multiples, the idempotent ideal I^2 = I,
factorization pathologies, an explicit pair without a gcd, a nonterminating
ordered division algorithm, homogeneous solvability, support obstructions,
and Euclidean versus indefinite orthogonal groups over Oz.

## Build the PDF

With TeX Live or an equivalent distribution:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Alternatively run `pdflatex article.tex` three times. Required packages are
listed in the preamble. They include newpxtext, newpxmath, microtype,
amsmath, amsthm, mathtools, geometry, enumitem, longtable, fancyhdr, and
hyperref. No external image files, BibTeX database, or supplied font files
are required.

## Run the checks

Use Python 3.9 or later:

    python -m pip install -r requirements.txt
    python verify_examples.py

The bundled output was produced using Python 3.13.5 and SymPy 1.14.0.
It reports 13 exact symbolic identity checks and checks all 49 ordered
products of seven finite-support fixtures. Failure raises an exception;
there are no floating-point tolerances in these checks.

## Scope and status

This is an AI-assisted mathematical manuscript with detailed English proofs.
It is not a fully Lean-verified development and has not received independent
peer review. The finite checks are not a substitute for the general proofs.
No mathematical priority claim is made.

The referenced repository was inspected at commit
`2cb9c0200af749fbbd27796c97d017e7f16fbf33`:

https://github.com/VladimirReshetnikov/Surreal

Its documented infrastructure informs the proposed formalization plan; the
repository was not modified and no Lean build was run. The paper records the
September 2026 Conway-refinement proof announcement as a qualified source
status update, not as a dependency of its own results.
