# Nonlinear Differential Rigidity of Entire Hahn Functions

**First-order algebraic equations, finite certificates, and positive-weight Euler equations**

Research manuscript prepared for Vladimir Reshetnikov, 22 September 2026.
The PDF has 23 physical pages, including the title, contents, and references.

## Main result

Let `K = k((t^Gamma))`, with `k` a characteristic-zero field with trivial
valuation and `Gamma` any nonzero set-sized ordered abelian group. If
`f in K[[z]]` is strongly Hahn summable at every argument in this one field
and satisfies a nonzero equation `P(z,f,f') = 0`, with polynomial coefficients
in `K`, then `f` is a polynomial. Equivalently, every nonpolynomial strongly
entire function and its first derivative are algebraically independent over
`K(z)`.

The derivative is formal differentiation in `z` and kills all Hahn
coefficients. It is not the Berarducci–Mantova scalar derivation. Strong
summability requires both a well-ordered support union and finitely many
contributors at every exponent, before cancellation.

The manuscript also proves a solution-dependent finite exclusion certificate,
a finite candidate-degree theorem, an algebraic parametrization of the entire
solution set, a positive-weight multivariable Euler analogue, and a
higher-order sufficient criterion. Worked examples include Riccati equations,
the displayed Painleve I and II equations, explicit independent pairs of Hahn
functions and their derivatives, and sharp limitations on the method.

## Relation to the requested research problem

The comparison uses repository revision
`048b72cf7cbfc8ab246e4f73788c10460cb3f6e0` of
`VladimirReshetnikov/Surreal`. Its holonomic-rigidity report explicitly leaves
nonlinear algebraic differential equations as Question 15.1. This manuscript
answers the **first-order case**, not the unrestricted higher-order question.

The exact arbitrary-rank formulations and certificates are proposed
contributions. A targeted repository and primary-literature comparison did
not identify the same theorem package. This is not a certified priority claim
or an exhaustive audit of the repository, its Git history, or the literature.
See `SOURCES_AND_SCOPE.md` and Section 12 of the article.

The results have detailed written proofs but have not been independently
refereed or formalized in Lean. The finite tests are supporting algebraic
checks, not proofs of arbitrary-support statements. See `PROOF_AUDIT.md`.

## Package contents

- `article.pdf` and `article.tex`: the complete manuscript and standalone LaTeX source.
- `code/verify.py`: reproducible exact finite checks, Python standard library only.
- `code/build.py`: three-pass TeX build with a strict final-log audit.
- `data/verification.json`: the delivered result, **2,113 checks passed**.
- `data/build_report.json`: final TeX log audit and source/PDF hashes.
- `data/layout_audit.json`: page-boundary checks and rendered-page review record.
- `PROOF_AUDIT.md` and `SOURCES_AND_SCOPE.md`: mathematical dependencies and research boundaries.
- `SHA256SUMS.txt`: integrity hashes for the delivered files other than itself.

## Reproduce the finite checks

Python 3.9 or later is sufficient. No third-party packages or network access
are needed. From this directory:

```sh
python code/verify.py --output data/verification-rerun.json
```

The program refuses to overwrite an existing result file. Choose another
output name for a subsequent run. The deterministic default seed is 20260922.
The result records six test groups: 450 finite Hahn-certificate checks, 240
first-order nondegeneracy checks, 480 higher-order corner checks, 500 ordered-
group radius checks, 360 weighted Euler checks, and 83 example checks.

These are counts of program checks, not counts of independently proved
theorems. No infinite surreal sum is numerically approximated.

## Build the PDF

Install a TeX distribution containing the packages named in `article.tex`,
including New PX text/math, AMS math, microtype, tabularx, hyperref, and bookmark.
From this directory:

```sh
python code/build.py
```

Alternatively run the following command three times:

```sh
pdflatex -halt-on-error -interaction=nonstopmode article.tex
```

The bibliography is internal; no BibTeX run, shell escape, external graphics,
network requests, or separately downloaded fonts are needed. Installed TeX
fonts are embedded in the PDF in the usual way; no font files or third-party
papers are distributed. A successful PDF build is not a mathematical proof
check. Build timestamps can change PDF hashes without changing the text.
