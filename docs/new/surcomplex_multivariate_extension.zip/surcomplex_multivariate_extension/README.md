# Multivariate Entire Hahn Series across New Surreal Scales

**Exact support domains, nonclosed valuation cones, and a classification of exceptional projective directions**

Research manuscript prepared for Vladimir Reshetnikov, 22 September 2026.

## Files

- `article.pdf` — 27-page article with full proofs, examples, references, and scope audit.
- `article.tex` — self-contained LaTeX source with an embedded bibliography.
- `code/verify_examples.py` — standard-library Python exact finite checks.
- `data/verification.json` — delivered results: 1,072 assertions passed.
- `data/research-audit.json` — pinned repository version, source comparisons, and status.
- `data/build.json` — final typesetting and PDF review record.

## Main results

Theorem 5.3 answers the scalar-extension part of the repository question
`ent:q:several`. For a finite-variable entire series over an old full Hahn
field, evaluation in an enlarged field is strongly summable exactly when the
ordinary support's weight image in the quotient by the convex hull of the
old value group is well ordered. Infinite fibers are allowed. The proof
handles arbitrary coefficient supports and nonmonomial arguments.

Theorem 6.6 gives a finite inequality criterion for semilinear supports.
Theorem 6.9 exhibits an exact nonclosed weight cone in two variables.

Theorems 7.4, 8.2, and 8.4 distinguish homogeneous-block evaluation from
individual-monomial evaluation. Polynomial line restrictions determine the
block-exceptional directions at new scales. Over ordinary complex projective
space their possible loci are exactly countable unions of projective algebraic
sets, realized by entire Hahn series when the old value group is countably
cofinal. For a nonpolynomial two-variable series, these loci are precisely the
at most countable subsets of the projective line (Corollary 8.5).

Section 9 transfers the statements to actual surreal and surcomplex fields
through Conway normal forms, with all size and entireness hypotheses explicit.

## Status and provenance

Repository comparison: `VladimirReshetnikov/Surreal`, commit
`4cf691c7d951e037739d32d9f5c387dcce724f3c`.

This is a proposed original contribution following a targeted repository and
primary-literature comparison, not a certified priority claim. The scalar-
extension clause is addressed; the repository question's preparation and
ideal-theoretic clauses are not claimed solved. Existing entire growth and
cofinality criteria, the one-variable extension theorem, and classical Hahn
and algebraic inputs are explicitly credited.

The proofs have not been independently refereed or checked in Lean. The
finite verification suite proves no infinite well-ordering or summability
theorem. Its count is not a confidence score. Binary repository archives and
all historical source documents were not audited exhaustively.

## Build the article

A standard TeX Live or MiKTeX installation with the packages named in the
source is sufficient. No external graphics, bibliography file, repository
checkout, or shell escape is needed.

Run from this directory:

```sh
pdflatex -halt-on-error -interaction=nonstopmode article.tex
pdflatex -halt-on-error -interaction=nonstopmode article.tex
pdflatex -halt-on-error -interaction=nonstopmode article.tex
```

Alternatively, use `latexmk -pdf -halt-on-error article.tex`.

## Run the checks

Python 3.9 or later; no third-party dependencies:

```sh
python code/verify_examples.py --output data/verification.json
```

The script uses integers and `fractions.Fraction`, prints its JSON report,
and exits with an error if an assertion fails. Running the displayed command
replaces the local verification record. To retain that record, choose another
output filename or omit `--output` to print only.
