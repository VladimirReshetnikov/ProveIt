# What Birthday-Enriched Surreal Fields Remember

**Subtitle:** Hereditary-size interpretations, choice, forcing, and surcomplex orientation  
**Date:** 22 September 2026  
**Length:** 30 PDF pages, including the title and two contents pages  
**Author line:** Research article prepared with ChatGPT

## Files

- `surreal_memory.pdf` — the compiled article with linked contents, theorem references, and bibliography.
- `surreal_memory.tex` — complete standalone LaTeX source, including its bibliography.
- `finite_checks.py` — standard-library Python regression tests for the finite coding formulas.
- `finite_checks.txt` — recorded output from those tests.
- `README.md` — these build, scope, provenance, and verification notes.

No external bibliography file, images, shell escape, or network access is required to compile the source. No third-party papers or font files are included.

## Main mathematical contribution

For every uncountable cardinal kappa, including singular cardinals, the article supplies a uniform parameter-free bi-interpretation between the birthday-enriched surreal field of signs of length less than kappa and the membership structure H_kappa. The local proof explicitly constructs hereditarily small witnesses for addition and multiplication; it does not assume H_kappa satisfies Replacement or Power Set.

The main results are:

- Theorem 1.1, proved in Sections 2–6: uniform hereditary-size reconstruction, with compatible inclusions.
- Theorem 7.1 and Corollary 7.3: exact transfer of elementary embeddings, elementary inclusion, and elementary equivalence.
- Theorems 8.1–8.2: a fixed first-order strong-limit test and a finite-beth collection sentence separating beth_omega from its successor cardinal.
- Theorem 9.2: in ZF without Choice, the graph interpretation has exactly the sets with well-orderable transitive closure as its range; external surjectivity onto V is equivalent to Choice.
- Theorem 10.1 and Corollaries 10.2–10.3: preservation under no-new-bounded-subsets extensions, and the relative-consistency example of an unchanged enriched field at a cutoff whose cofinality changes by Prikry forcing.
- Theorem 11.4 and Section 12: two complex lifts of each real elementary embedding, the exact real/nonreal parameter threshold for orientation, and the distinction between mutual interpretation and bi-interpretation after naming an imaginary unit.

The complex structure is explicitly enriched by conjugation and the function B(a+ib) = max(b(a), b(b)). This is a specified coordinate-birthday convention, not an assertion that every use of “surcomplex birthday” has this meaning. Its automorphism conclusions do not apply to the unrestricted pure surcomplex field.

## Priority and proof status

Chen–Hamkins–Yang's publicly announced global bi-interpretation of birthday-enriched surreal arithmetic with set theory is prior work and is credited prominently. The general complex-conjugation obstruction to parameter-free bi-interpretability already appears in Emil Jeřábek's 2021 explanation and is also credited. Field closure at uncountable cardinals and the classical Prikry forcing facts are imported results, not new claims.

The principal proposed refinement is the uniform localization at every uncountable cardinal, including singular cutoffs, with explicit small arithmetic witnesses and the stated compatibility and boundary results. Historical novelty is provisional: the exact theorem was not located in the sources inspected, but neither an exhaustive literature search nor an exhaustive repository-history audit is claimed.

This is a written mathematical research article. It is not peer-reviewed or Lean-certified. The proof, finite tests, and typesetting checks are separate forms of evidence. No longstanding named open problem is claimed to have been settled.

## Repository comparison

The comparison is pinned to:

```text
VladimirReshetnikov/Surreal
4f2645599121fa872c7104995e47f86f0382351f
```

Appendix B records the actual portions retrieved, including the foundations inventory and the existing surcomplex-automorphisms report. Their prior results are not claimed anew. The comparison was targeted, not an audit of every report or retired manuscript. No repository files were modified, and no independent Lean build was performed.

## Build

Use a TeX distribution with the standard packages listed in the source, including `newtxtext`, `newtxmath`, `amsmath`, `amsthm`, `mathtools`, `geometry`, `microtype`, `xcolor`, `booktabs`, `array`, `longtable`, `enumitem`, `needspace`, `ragged2e`, `fancyhdr`, `aliascnt`, `hyperref`, and `cleveref`.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_memory.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error surreal_memory.tex` three times.

## Finite checks

Requires Python 3.10 or later, with no third-party packages:

```sh
python finite_checks.py
```

The recorded run passed:

- All 16,129 prefix-formula comparisons and 642 bit-formula comparisons on the 127 sign words of length at most six.
- Pairing injectivity, boundedness, and coordinate monotonicity on 10,000 pairs of finite ordinals.
- Every rooted relation on one, two, or three vertices: 1,570 rooted inputs, yielding 15 valid pointed well-founded extensional codes.
- All 225 pairs of those valid codes, for both code equality and downward-initial membership.

These tests do not prove the transfinite, model-theoretic, Choice, or forcing theorems. Their precise finite scope is printed by the program.

## PDF checks

The delivered source compiles to 30 pages with resolved references and no LaTeX warnings, overfull boxes, or underfull boxes in the final build. All pages were rendered for layout inspection; selected mathematical pages were also examined at higher resolution. A text-coordinate check found no text outside the page boundaries. The PDF has 58 linked section, subsection, and bibliography bookmarks.
