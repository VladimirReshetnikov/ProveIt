# Gaussian-Omnific Real Forms and Geometric Symmetrization

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.pdf`: compiled 24-page research article.
- `article.tex`: standalone LaTeX source with an internal bibliography.
- `verify.py`: dependency-free exact finite regression checks (Python 3.9+).
- `verification.json`: results from the supplied check program.
- `SOURCES.md`: repository snapshot, provenance, and claim boundaries.
- `build.sh`: optional POSIX build script.
- `SHA256SUMS.txt`: checksums of the other deliverable files.

## Main mathematics

For the surcomplex field K = No(i), let J = Oz[i] and let O be the Hahn
valuation ring. The article classifies involutions preserving J and O.
It proves that each is conjugate to its ordinary complex coefficient action
by a strong, C-linear, value-fixing, J-preserving automorphism. Its formula is

    H_j(sum a_g t^g) = sum a_g t^(g/2) j(t^(g/2)).

The proof verifies all summability requirements and constructs a strong
arithmetic-preserving inverse. A characteristic-free orbit-product theorem
normalizes finite group actions on full Hahn fields when the exponent group
is divisible by the group order.

For the surcomplex application, conjugacy classes are classified by real
closed coefficient fields E of transcendence degree continuum. The descended
ring Z + P_E is an integer part exactly when E is Archimedean. There are exactly
2^continuum conjugacy classes in the valued Gaussian sector, already among
integer-part real forms. The construction supplies that many pairwise
nonisomorphic fixed fields and fixed rings. The example involutions remain
pairwise nonconjugate even under unrestricted surcomplex field automorphisms.

The abstract fixed ring recovers E. Thus it is isomorphic to Oz precisely when
E is isomorphic to R. Nevertheless all these rings have the same ordinary
finite quotients and the same solvability of polynomial equation systems
with ordinary integer coefficients.

## Build the PDF

A normal TeX Live or MiKTeX installation with the packages listed in the source
is sufficient. No external illustrations, bibliography database, custom font
files, or shell escape are required.

From this directory, run:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

The optional `build.sh` performs these steps and runs the verification program.
On Windows, the same pdflatex commands can be run in PowerShell.

## Run the finite checks

    python verify.py --output verification.json

On systems using the Python launcher:

    py -3 verify.py --output verification.json

The delivered record reports **457 successful assertions** at truncation order
8, with exact Gaussian rational coefficients and deterministic seed 20260923.
The tests cover the orbit-product formula, flow composition and multiplicativity,
involution and conjugacy identities, geometric inverses, leading values, and
sampled negative-support preservation. No floating-point arithmetic is used.

## Verification and novelty limits

This is an AI-assisted, unrefereed mathematical manuscript. The proofs are
intended to establish the displayed claims under their assumptions; novelty
and independent correctness certification are not guaranteed. The formal
operator-inversion theorem is an explicitly cited external input. The needed
repository automatic-strongness argument is credited and reproved.

The finite checks do NOT verify infinite Hahn summability, proper-class
constructions, cardinalities, or all possible automorphisms. No Lean verification
was performed, and the repository's Lean build was not run.

The unrestricted question whether every automorphism of the Gaussian omnific
ring preserves the Hahn valuation is **not resolved**. The complete conjugacy
classification concerns the valuation-compatible Gaussian sector. The exact
2^continuum upper bound is not claimed for all pure-field involutions.

The repository was read at commit
`110efe9dea646a092a640838515af4ad2d7ee2e0`; no repository writes were made.
