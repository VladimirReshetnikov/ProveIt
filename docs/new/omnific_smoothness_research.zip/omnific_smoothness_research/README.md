# Smooth Rigidity and Bounded-Scale Flexibility of Omnific-Preserving Maps

A standalone mathematical research manuscript, September 2026.

## Start here

`article.pdf` is the complete article. `article.tex` is its standalone LaTeX source, with an internal bibliography. The article includes full proofs, 12 proposed further research questions, source attribution, a proof-dependency discussion and explicit limitations.

**Status:** AI-assisted, unrefereed research. The written proofs have not been independently reviewed or checked in Lean. Novelty is proposed rather than historically certified. No named longstanding conjecture is claimed settled.

## Main results

- Every globally smooth semialgebraic map over a real closed field preserving a cofinal discrete subring is a coordinatewise numerical polynomial. This applies to the actual surreal field and the omnific integers in every finite dimension.
- A scalar graph description of degree at most D needs only global C^(D^2) regularity, independently of input dimension. The resulting polynomial has total degree at most D. For vector maps, this bound applies when each scalar coordinate graph has that degree bound.
- Every semialgebraic preserver is polynomial on each tail, and the algebra of its two-end germs is the product of two numerical-polynomial rings.
- For a > 0, multiplication by omega^b makes sqrt(x) omnific for every omnific x in [0, omega^a] exactly when b > n*a for every ordinary positive integer n.
- For every finite k, an explicit C^k semialgebraic bump maps all omnific inputs into the purely infinite ideal, but is not representable on the lattice by finitely many polynomials. These give nonpolynomial lattice-preserving C^k shears with Jacobian determinant 1.
- No coefficient-independent set of tests certifies omnific preservation, even for globally smooth algebraic branches of total graph degree 2.
- The paper gives real-semialgebraic surcomplex extensions and explains the additional Cauchy–Riemann consequence without introducing a global surreal exponential.

Classical finite differences, semialgebraic nonflatness, Hahn-field real closedness, Newton interpolation and the repository's numerical-polynomial descriptions are credited as inputs rather than claimed as new.

## Files

- `article.tex`, `article.pdf`: source and compiled article.
- `code/verify.py`: exact finite sanity checks, using only the Python standard library.
- `audit/verification.json`: recorded result of those checks.
- `audit/SOURCE_AUDIT.md`: repository pin, inspected sources and originality boundaries.
- `audit/PROOF_AUDIT.md`: sensitive proof obligations and the scope of verification.
- `audit/build_report.json`: PDF build, inspection and artifact integrity record.
- `build.sh`, `build.ps1`: LaTeX build scripts for Unix-like shells and PowerShell.

## Build

Install a normal TeX Live or MiKTeX distribution with pdfLaTeX and the packages named in the preamble. No bibliography processor, shell escape, external images or custom fonts are required.

From this folder, use:

```sh
sh build.sh
python3 code/verify.py
```

PowerShell:

```powershell
./build.ps1
python ./code/verify.py
```

The source can also be uploaded directly to a LaTeX editor and compiled with pdfLaTeX; three passes resolve the table of contents and references. The verification script was run with CPython 3.13.5. Its annotated type syntax requires Python 3.10 or later; it has no third-party dependencies. The Windows build script is provided but was not executed in this Linux environment.

## Verification boundary

All 1,578 recorded exact assertions passed. They cover finite polynomial identities, finite binomial jets, rational interpolation, finite Newton grids, sampled lexicographic exponent comparisons and the displayed negative-exponent witness. They are not a proof-assistant verification, do not establish arbitrary infinite Hahn summability or class-sized claims, and cannot certify novelty.

Repository snapshot: `738a39017285045f8eeeac1286b4c8f37d34bef1`, in VladimirReshetnikov/Surreal. Selected sources were read through the repository interface. No repository checkout, modification, Lean build or Wolfram computation was performed. Newly delivered or unintegrated manuscripts were not exhaustively audited.
