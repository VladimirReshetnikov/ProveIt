# Period Arithmetic and Noncanonical Surcomplex Exponentials

**Profinite defects, minimal multiplier rings, and a partial answer to an
Ehrlich–Kaplan question**

Research manuscript, September 22, 2026. The PDF has 25 pages, including its
contents, proof and source audit, and internal bibliography.

## Main results

The central construction (Theorems 7.5 and 7.7) preserves any chosen ordinary
phase character while choosing its infinitesimal component so that the
multiplier ring of the period group is exactly the ordinary integers. The
profinite defect is unchanged. It works on the specified continuum-sized
fields and, with global choice, on the full surreal class.

Theorem 8.4 applies this construction to surcomplex exponentials on
No(epsilon_0)[i] and No[i]. Their kernel-multiplier ring is the initial ring Z,
but is not an integer part. They retain the canonical finite-imaginary strip,
modulus and conjugation laws, and the exact local normalized Taylor identity.
The examples can differ from the canonical exponential only by an
infinitesimal unit-circle factor at each argument. This is a partial negative
answer to the first robustness question in Ehrlich–Kaplan, Section 11.1—not a
classification of all further sufficient hypotheses.

Other results are a prescribed-defect realization theorem (5.3), reduced and
split phase kernels on R((t^Q)) (5.4), cofinal rationally divisible periods for
every phase on all of No (6.1), and a free action of real valued-field
translations on admissible phases (9.3).

## Contents

- `article.tex`: standalone LaTeX, with an internal bibliography.
- `article.pdf`: compiled manuscript.
- `verify_examples.py`: standard-library-only exact finite checks.
- `verification.json`: generated results of those checks.
- `source_audit.md`: inspected sources, repository pin, and priority boundaries.
- `Makefile`: build and verification commands.
- `README.md`: this guide.

## Build

With a normal TeX Live installation and Python 3.10 or later:

```sh
python3 verify_examples.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `make` for both tasks. The LaTeX uses Latin Modern and
standard mathematics packages. No external bibliography, private fonts,
network access, shell escape, or external graphics are required.

## Verification status

The finite tests passed: 128 CRT moduli, 645 residue-compatibility pairs,
58,081 character-additivity pairs, 1,575 translation-composition coefficients,
24 one-step multiplier witnesses, and 20 constant-term shadow checks, plus the
displayed phase examples. All arithmetic is exact, not floating point.

These tests do **not** establish the infinite or transfinite theorems. Their
proofs are in the article. No Lean verification or independent repository
build was performed. The PDF was compiled without undefined references or
overfull-box warnings and inspected by rendering.

This is an AI-assisted, unrefereed research draft. Published group-theoretic
prerequisites and existing repository results are explicitly credited. The
proposed novelty is based on a targeted audit, not certified historical
priority. See Section 1.3 and Appendix B.
