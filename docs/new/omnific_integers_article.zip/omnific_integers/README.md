# Omnific Integers and Diophantine Rigidity

**Constant terms, infinite supports, and arithmetic at surreal scales**  
A proof-based research exposition, dated 22 September 2026.

## Files

- `article.pdf`: the complete, typeset 29-page article.
- `article.tex`: self-contained LaTeX source, including its bibliography.
- `verify_examples.py`: exact, finite symbolic and integer checks.
- `verification.txt`: output from the supplied program with its default inputs.
- `requirements.txt`: the Python dependency used for the checks.
- `BUILD.md`: PDF build and verification instructions.

## Main results

The article develops the constant-term retraction from the omnific integers
Oz to the ordinary integers Z and separates the existence of solutions from
the possibility of infinite coordinates.

Its proofs establish:

1. Exact equivalence of solvability over Oz and over Z for finite systems of
   integer-coefficient polynomial equations, together with standard-modulus
   congruence and quotient results.
2. Rigidity of nonzero constant levels of binary homogeneous forms, including
   Pell and Thue equations, and a full classification for x^2 - 2y^2 = 1.
3. Rigidity of a*x^m + b*y^n = c for nonzero ordinary integer a,b,c and fixed
   ordinary m,n >= 2, allowing arbitrary set-sized normal-form supports.
4. Rigidity of nonzero unimodular Fermat triples for every exponent >= 3,
   contrasted with explicit infinite homogeneous solutions and an infinite
   unimodular Pythagorean family.
5. Factorization of every unital homomorphism from the full class ring Oz to
   a set-sized ring through constant term.
6. A parameter-free quartic Diophantine definition of Z inside Oz, and an
   explicit failed existential induction instance.

The article also treats nontermination of ordered Euclidean division,
common monomial divisors, finite and set-sized quotients, root-support
obstructions with omnific coefficients, failed simple-root lifting,
finite-support specialization to polynomial arcs, and a Lean formalization
route for the repository.

## Mathematical scope and status

Complete prose proofs are included. The classical normal-form theorem,
Lagrange's four-square theorem, Shepherdson's theorem, the DPRM theorem,
and classical Fermat are identified as imported results. The article is not
independently peer reviewed and has not been formally verified in Lean.
No historical-priority claim is made for the arguments developed here.

The Python program checks finitely many exact identities and witnesses; it
does **not** verify the full-support or class-theoretic theorems. A finite
search is never used as a completeness proof for an integer solution set.

The set-target and support-clearing results are about the **full class** of
surreal exponents. They are not asserted for an arbitrary fixed set-sized
Hahn exponent group.

## Repository snapshot

The documentation index and normal-form bridge note were reviewed at:

`VladimirReshetnikov/Surreal`

Commit: `2cb9c0200af749fbbd27796c97d017e7f16fbf33`

No repository files were changed and its Lean implementation was not rebuilt
or audited for this article. References and the recent refinement-proof
announcement are documented in the article's bibliography, with the
announcement explicitly not used as a theorem.
