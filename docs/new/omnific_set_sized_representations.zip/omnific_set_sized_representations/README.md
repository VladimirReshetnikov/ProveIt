# Omnific Integers Have Only Ordinary Set-Sized Representations

**A universal constant-term theorem, small modules, and invisible prime quotients**  
Research manuscript, 23 September 2026.

## Main result

Every unital ring homomorphism from the **full proper-class ring** of omnific
integers to a **set-sized** associative ring B is

    z -> ct(z) * 1_B,

where ct(z) is the ordinary integer coefficient at exponent zero in the
Conway normal form. The map is not assumed continuous, order-preserving, or
compatible with infinite sums. The coefficient map is not standard part.

More generally, for K = R or C and a unital subring A of K, the class ring
A + I_K (I_K = positive-exponent normal forms) has A as its universal
set-sized ring quotient.

The article develops the binomial divisibility proof, uniform divisibility
of set families, all set-sized quotients and modules, Gaussian-omnific
representations, quotient/polynomial/localization universal properties,
prime quotients with no nonzero set-sized modules, and sharp limitations.

## Files

- `article.pdf`: the typeset article.
- `article.tex`: complete LaTeX source, including bibliography.
- `verify_identities.py`: dependency-free exact finite-algebra checks.
- `finite_checks.json`: the recorded results (820 passing test cases).
- `SOURCE_AUDIT.md`: source scope, repository snapshot, novelty boundaries,
  and verification limitations.
- `README.md`: this guide.

## Build the article

Use a recent TeX Live or equivalent installation containing the standard
AMS packages, `newtx`, `microtype`, `geometry`, `hyperref`, `cleveref`,
`aliascnt`, `needspace`, `booktabs`, and `longtable`.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex article.tex` three times. The bibliography is
embedded; no BibTeX, external image downloads, or font files are required.

## Run the finite checks

Python 3.9 or later; no third-party packages:

```sh
python3 verify_identities.py --output finite_checks.json
```

The tests use exact rational coefficients and finite polynomial dictionaries
with exponent pairs (a,b) representing a+b/omega, ordered lexicographically.
The seed is fixed at 20260923. A failed test or a report-writing failure
produces a nonzero process exit code.

**The checks are not a formal verification of the main theorem.** They test
finite telescoping, finite divisor truncations, constant-term arithmetic,
finite-support evaluation, and Gaussian matrix evaluation. They do not check
arbitrary supports, infinite Hahn sums, the Hartogs argument, or primality.

## Source and novelty status

The main theorem and separation construction are candidate-original results.
No identical formulation was found in the inspected literature; this is
not exhaustive priority certification. Written proofs are supplied, but no
independent referee review or Lean formalization was performed.

The primality of omega^(sqrt(2)) + omega + 1 is an established theorem of
Sonia L'Innocente and Vincenzo Mantova (Advances in Mathematics 442, 2024,
article 109513). It is cited, not claimed as new. The representation-theoretic
consequence for its quotient is developed in this article.

The Surreal repository already contains an analogous universal set-sized
quotient result for rotation groups. That conceptual precedent is credited;
its theorem is not a dependency of the present binomial-divisibility proof.

Prepared with ChatGPT in response to a research request. The repository
was read but not changed.
