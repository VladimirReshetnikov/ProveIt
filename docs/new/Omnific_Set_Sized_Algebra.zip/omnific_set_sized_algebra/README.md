# What Set-Sized Algebra Can See of the Omnific Integers

AI-assisted research draft, 22 September 2026. The article is 20 pages.

## Files

- `omnific_set_sized_algebra.tex`: self-contained LaTeX source, including references.
- `omnific_set_sized_algebra.pdf`: compiled article.
- `SOURCE_AUDIT.md`: provenance, repository comparison, and novelty limitations.
- `code/check_finite_identities.py`: standard-library Python exact finite checks.
- `data/finite_checks.json`: results from the supplied script.
- `build.sh`: reproducible LaTeX build and finite-check commands.

## Main results

For the full class ring of omnific integers Oz, every unital homomorphism
into a set-sized ring A sends x to ct(x) times 1_A. Here ct extracts the
integer constant coefficient of Conway normal form. The target need not be
commutative and the map need not preserve order, topology, or Hahn sums.
For the Gaussian omnific ring Oz[i], the universal set-sized quotient is Z[i].

The article proves classifications of set-sized quotients and modules,
localization and polynomial-presentation consequences, a finite-support to
countable-support extension obstruction, and a cardinal-relative version.
It also gives two proofs of a negative answer to the posted question whether
the natural ordinal Grothendieck ring is a quotient of Oz. The simpler proof
of that particular obstruction uses only additive divisibility.

The technical step constructs arbitrarily large monomial families whose
pairwise differences divide a fixed purely infinite series. A precisely
checked Hahn geometric expansion supplies the quotients; pigeonhole in a
set-sized target then kills the series.

## Scope and status

These are proposed research contributions, with complete written proofs but
without independent refereeing or Lean formalization. Novelty is assessed
only against the sources actually inspected. Lower-scale geometric division,
bounded-support Hahn ring families, and the normal-form background have
published precedents. The inspected repository already contains a different
universal set-sized quotient theorem for a rotation group. None of those
prior ideas is claimed as originating here.

The main theorem is about the FULL class ring relative to one fixed ambient
universe. It is not asserted for the identity representation of a set-sized
fragment viewed in a larger universe. The article states a separate
cardinal-relative theorem for set-sized exponent groups.

## Rebuild

A LaTeX installation with the packages named in the preamble is required,
including newtx, amsthm, tcolorbox, xurl, and cleveref. No font files or external
images are distributed or needed beyond the installed LaTeX packages.

Run from this folder:

```sh
sh build.sh
```

Or compile manually three times:

```sh
pdflatex -interaction=nonstopmode -halt-on-error omnific_set_sized_algebra.tex
pdflatex -interaction=nonstopmode -halt-on-error omnific_set_sized_algebra.tex
pdflatex -interaction=nonstopmode -halt-on-error omnific_set_sized_algebra.tex
```

Run the finite checks with Python 3.10 or later (no third-party packages):

```sh
python3 code/check_finite_identities.py --output data/finite_checks.json
```

The supplied run passed 1858 exact checks at seed 20260922. They check finite
identities over Gaussian rationals and lexicographic rational-pair exponents;
they do NOT verify infinite Hahn summability, proper-class arguments, the
universal theorem, or priority claims.

## Repository snapshot

https://github.com/VladimirReshetnikov/Surreal

Commit: `37eefca1a309a967d8c8237606ccf6290475adfa`.

No repository files were modified and no repository build was performed.
