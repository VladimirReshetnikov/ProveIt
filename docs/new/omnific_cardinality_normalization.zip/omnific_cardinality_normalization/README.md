# Cardinal Visibility and Normalization of Omnific Integers

A proof-based research manuscript prepared for the
VladimirReshetnikov/Surreal project, September 2026.

## Contents

- `omnific_cardinality_normalization.pdf`: typeset article.
- `omnific_cardinality_normalization.tex`: complete editable LaTeX source,
  including the bibliography; no external figures or font files are required.
- `verify_identities.py`: exact finite algebra checks using Python's standard library.
- `verification_results.txt`: output from the included check program.
- `SOURCE_NOTES.md`: provenance, novelty boundary, and verification scope.

## Main statements

For every infinite cardinal kappa of uncountable cofinality, the article
constructs an actual real closed Hahn subfield F_kappa of the surreal field.
Its omnific integer part A_kappa has cardinality theta = kappa^(aleph_0).
Every ring target and module of cardinality below theta sees only constant
terms; theta is the exact least size detecting each nonzero element of the
purely infinite ideal. The ideal requires exactly cf(kappa) generators.
The construction uses ZFC, with no continuum hypothesis or inaccessible cardinal.

For the full omnific ring, every set-generated intermediate algebra has one
monomial denominator and is uniformly discrete in the fine order. Its integral
closure is nevertheless proper and dense, has zero conductor, and is not
set-generated over the omnific ring. Its complete integral closure is the entire
surreal field. The article treats Gaussian/surcomplex analogues, including the
nonzero complexification defect annihilated by 2, and a set-valued valuation
obstruction.

These statements are accompanied by mathematical proofs. The article carefully
credits the earlier full-class constant-term theorem and support-clearing lemma
to the companion omnific draft rather than claiming them as new.

## Build the PDF

A standard TeX Live installation with newtx, amsmath, amsthm, mathtools,
geometry, microtype, tcolorbox, tocloft, hyperref, and cleveref is sufficient.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error omnific_cardinality_normalization.tex
```

Alternatively, run `pdflatex` three times on the same source to resolve the
contents and cross-references. The bibliography is embedded in the source, so
BibTeX is unnecessary.

## Run the finite checks

Python 3.9 or later is sufficient; no package installation is needed.

```sh
python verify_identities.py
python verify_identities.py --terms 64
```

The script uses exact rational arithmetic. It checks finite telescoping,
quadratic-unit coefficients and residuals, and finite lexicographic examples.
It does not verify infinite support arguments, cardinalities, class theory,
or any Lean proof. The main results are not independently peer reviewed or
formally verified. Historical priority is not certified.
