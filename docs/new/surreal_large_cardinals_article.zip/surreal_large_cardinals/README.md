# Large Cardinals and the Support Geometry of Surreal Embeddings

**Exact equalizers, additional normal-form terms, and omnific algebraic independence**

Research article prepared with ChatGPT for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `surreal_large_cardinals.pdf`: the 30-page article, including title page,
  contents, detailed proofs, thirteen research questions, a dependency audit,
  and eighteen references.
- `surreal_large_cardinals.tex`: complete, self-contained LaTeX source.
  The bibliography is embedded; no external `.bib` file is required.
- `PROOF_STATUS.md`: assumptions, principal results, and verification boundaries.
- `build.sh`: a three-pass pdfLaTeX build.

## Build

Use a reasonably complete TeX Live or MiKTeX installation with the packages
listed in the source preamble, including `newtxtext`, `newtxmath`, `microtype`,
`hyperref`, `bookmark`, and the standard AMS packages. No external images or
font files are required. The fonts are supplied by the installed TeX packages,
not included in this archive.

On a shell with pdfLaTeX available:

```sh
sh build.sh
```

Alternatively, run the following command three times from this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error surreal_large_cardinals.tex
```

The delivered PDF was produced using pdfTeX 1.40.26. Its final build had no
undefined references, missing citations, overfull boxes, or LaTeX warnings.
Rendered pages were visually reviewed. These checks concern document production,
not independent verification of the mathematical proofs.

## Mathematical orientation

The central comparison is between the action `J` of a measurable-cardinal
ultrapower on surreal sign sequences and the strongly additive Hahn lift `T`
of its exponent action. Their equalizer is exactly the field of surreals whose
normal-form support has cardinality below the critical point. The manuscript
gives the entire discrepancy as a complementary normal-form subseries.

A separate algebraic-independence theorem needs no large cardinal: almost-
disjoint subsets of an uncountable cardinal give independent omnific masks
over the entire short-support surreal field. The maximal-cardinality application
assumes `2^{<kappa} = kappa`.

The numerical measurability criterion retains Hadamard (coefficientwise)
multiplication on masks. It is not a first-order characterization in the bare
ordered-field or omnific-ring language. The strong/supercompactness and weak-
compactness presentations are explicitly credited translations of standard
large-cardinal principles.

## Repository provenance

Targeted comparison used the public repository `VladimirReshetnikov/Surreal`
at commit:

`0865f043aec113c14c69ef45006bbc7546a4e75a`

The main documentation and the introductions and scope statements of the
most relevant reports were inspected. This was not a complete audit of all
repository manuscripts or Lean code. The article contains precise permalink
references and a scope statement. No repository files were modified.

## Research status

This is an unrefereed AI-assisted research manuscript. Its central contributions
are proposed new theorems with written proofs; neither priority nor independent
formal verification is certified. No established named open problem is claimed
to have been settled. See `PROOF_STATUS.md` and Appendix A of the article.
