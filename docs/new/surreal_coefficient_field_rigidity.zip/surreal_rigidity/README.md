# Coefficient-Field Rigidity at Unbounded Surreal Scales

**All-order differential and dilation transcendence in Hahn workspaces**

A 23-page research article, dated 22 September 2026, prepared for Vladimir
Reshetnikov. It includes complete written proofs, explicitly identified
classical inputs, concrete surreal examples, and scope/priority qualifications.
It is an unrefereed AI-assisted manuscript, not a claim of completed Lean
verification.

## Main results

For K = k((t^Gamma)), characteristic(k) = 0:

- **Theorem A.** If Gamma has no order unit, every nonpolynomial strongly
  entire series f has all its derivative/dilation jets algebraically
  independent over the full K(z), provided distinct dilation parameters
  have quotients that are not roots of unity. This includes every
  nonlinear algebraic differential equation of every finite order.
- **Theorem B.** Infinite rational rank of the leading values of the Taylor
  coefficients suffices for the same mixed-jet independence; no entireness
  or no-order-unit assumption is needed for this individual-series test.
- **Theorem C.** An order unit exists exactly when there is a nonpolynomial
  strongly entire series with a finite-transcendence-degree coefficient
  field; equivalently, exactly when universal non-torsion mixed-jet
  independence fails. Partial theta is an explicit witness.

The key formal theorem shows that any finite algebraic differential-dilation
relation forces all Taylor coefficients into one finitely generated scalar
field. The differential-only proof is elementary. The mixed extension uses
the classical Skolem-Mahler-Lech theorem.

The concrete surreal function sum_n omega^(-omega^n) z^n is already in the
repository. This manuscript upgrades its conclusions to all-order and joint
non-torsion dilation/derivative independence over its full Hahn workspace.

## Repository comparison

Repository: VladimirReshetnikov/Surreal
Pinned commit: 465a54b479a1ee842cbf7db1689a7d2f6bfe25e1

The article resolves the **no-order-unit portion** of the holonomic report's
Question 19.1 and the corresponding no-order-unit case of its mixed question
19.4. It does not claim to solve the arbitrary order-unit case of purely
differential rigidity or a named historical published conjecture.

The audit was targeted, not exhaustive. Proposed originality is qualified.
See SOURCE_AUDIT.md and Section 11 of the article.

## Files

article.tex          Standalone LaTeX, including its bibliography
article.pdf          Compiled 23-page article
verify.py            Exact finite regression tests, Python standard library only
verification.json    Recorded successful run (9,308 checks)
SOURCE_AUDIT.md      Source scope, dependency and novelty boundaries
build_report.json    Compilation and layout checks for the delivered PDF
Makefile             Convenience build and verification targets

## Build

A normal TeX Live installation with pdfLaTeX and latexmk is sufficient.
The packages used are listed at the top of article.tex. No external images,
font files, .bib files, repository checkout, or network access is required.

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Alternatively, run pdfLaTeX three times to resolve contents and cross-references.

Run the finite verification with Python 3.10 or later:

    python verify.py --output verification-rerun.json

An existing output is refused unless --force is passed. All arithmetic in the
checks is exact. No third-party Python package is required.

## Important boundaries

“Entire” means strong Hahn evaluation at all points of one specified
set-sized field. It does not mean entireness on the whole class No(i), nor
ordinary real/complex convergence of constant coefficients. D = d/dz kills
every Hahn scalar; it is not the Berarducci-Mantova scalar derivation.

The order-unit sharpness example has a dilation equation. It is not claimed
to be a counterexample to purely differential rigidity. Algebraic
independence concerns formal functions, not their values at a fixed point.

Finite checks do not prove infinite support, recurrence zero-set,
cofinality, or transcendence assertions. The written proofs and the cited
classical theorems are the evidence for those conclusions.
