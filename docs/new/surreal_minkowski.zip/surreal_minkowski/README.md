# Surreal-Valued Fields on Minkowski Space
## Lorentz Geometry, Tensor Calculus, and Causal Hahn Dynamics

Prepared for Vladimir Reshetnikov — 22 September 2026.

The article is a 37-page mathematical development (including the cover,
contents, appendices, and references). Its two main settings are algebraic
Minkowski space over a real-closed surreal Hahn workspace and ordinary real
Minkowski spacetime carrying coherent surreal-valued coefficient fields.
Taylor prolongation relates them on finite surreal neighborhoods.

## Files

- `article/surreal_minkowski.pdf` — compiled article.
- `article/surreal_minkowski.tex` — self-contained LaTeX, including bibliography.
- `verification/check_identities.py` — 42 exact finite symbolic checks.
- `verification/verification_results.json` — recorded machine-readable results.
- `verification/verification_log.txt` — recorded output from the successful run.
- `SOURCE_AUDIT.md` — repository baseline, inspected sources, and claim scope.
- `Makefile` — optional build and verification commands.
- `requirements.txt` — the version of SymPy used for the recorded checks.

## Mathematical content

The development includes causal cones, arbitrary-scale Lorentz boosts,
four-momentum, tensor representations, Hodge and exterior calculus, the
codifferential, moving frames, bounded-Lorentz reduction, infinitesimal
matrix logarithms, and a near-null perturbation criterion. The field theory
includes coefficientwise Stokes and cohomology, Maxwell and scalar equations,
perfect-fluid tensors, stress–energy and conserved charges, support-preserving
Cauchy solutions, retarded inverses for positive-order perturbations, and a
transfinite cubic-wave deformation theorem.

Two particularly useful diagnostics are the exact doubling of the leading
Maxwell scale in its energy, including null radiation, and the obstruction
to representing a nonzero pure infinite-frequency oscillation in the chosen
coherent smooth Hahn algebra. Infinite boosts and infinite-time evaluation
are treated explicitly rather than assumed to preserve that algebra.

## Rebuild the PDF

A TeX Live installation with `newtx`, AMS packages, `microtype`, `tcolorbox`,
`hyperref`, and `cleveref` is sufficient. No external images, bibliography
files, or bundled fonts are needed.

```sh
cd article
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_minkowski.tex
```

Alternatively, run `pdflatex` repeatedly until cross-references stabilize
(normally three runs from a clean directory).

## Repeat the checks

Python 3.10 or later and SymPy are required. The recorded run used SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python verification/check_identities.py
```

The script raises an exception if a check fails and rewrites the JSON record
only after all checks pass. It uses exact symbolic arithmetic, not numerical
tolerances. The script does not read or modify the upstream repository.

## Scope and qualifications

The finite algebra is valid over a real-closed coefficient workspace. Smooth
field operations require the article's common-domain, well-ordered support
conditions. PDE statements explicitly import real Cauchy or Green theory
and prove coefficientwise or positive-order lifts of those results. A Hahn
formal solution need not converge after substituting a positive real scale.

The 42 symbolic checks are not proofs of support summability, infinite
series identities, PDE existence, or the entire article. No Lean formalization
or Lean build is included or claimed. The article makes no exhaustive novelty
claim and no claim of experimental validation or singularity resolution.

Repository baseline:
`VladimirReshetnikov/Surreal` at
`d22a5b35d5b3040e870c3cfd6d1c8f7259e094b0`.
