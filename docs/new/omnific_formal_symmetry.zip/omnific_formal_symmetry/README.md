# All Derivations Integrate
## Formal Symmetry and Coefficient Definability of Omnific Arithmetic

Research report prepared for Vladimir Reshetnikov, dated 23 September 2026.

The PDF has 25 pages, including the cover, contents, full written proofs,
11 further research questions, two appendices, and references.

## Main contribution and status

The article answers the question labeled `opa:par:q:directions` ("Formal
directions") in the repository's *Omnific-Preserving Automorphisms* report
at commit `889b87c7d2ee2c69ad929fd96c553ffa374ef4f0`.

Every ring derivation of the omnific integers preserves the purely infinite
ideal, takes the whole ring into that ideal, and admits a unique iterative
integral Hasse–Schmidt extension. The same statement holds for Gaussian
omnific integers. No Hahn-strongness or common-support hypothesis is needed.

The report develops the full integral exponential–logarithm correspondence,
finite-jet lifting with nonsplit successive group extensions, a classification
of marked coefficient sections, and a polynomial/formal definability contrast.
It includes counterparts for the surreal and surcomplex fields.

This is an unrefereed research draft, not a Lean-verified contribution.
The claims have detailed written proofs; the finite computations are regression
checks, not proofs of the class, support, or algebraic-geometry arguments.
Priority beyond the specified repository comparison and inspected literature
is not certified. No independently published long-standing conjecture is
claimed solved.

## Reading guide

- Theorem 1.1 and Section 4: unrestricted formal integration.
- Theorem 5.3: all parameter-fixing formal automorphisms tangent to the identity.
- Theorems 6.1 and 6.4: every finite jet lifts; the Nth jet group has nilpotency
  class exactly N; the successive central extensions do not split for N >= 2.
- Theorems 7.1 and 7.3: coefficient sections and their common arithmetic core.
- Theorem 8.2: one existential formula defines coefficients in finite polynomial,
  Laurent, and mixed extensions.
- Section 9: what that formula sees in formal completions, including the
  surcomplex-field parity exception.
- Theorem 10.2 and Corollary 10.4: no coefficient section has definable image
  in the formal completion after naming any set of parameters and T.
- Sections 11–13: relation to earlier parameter rigidity, proof audit, and
  further research questions.

All power-series parameters here are external formal variables. The report
never silently evaluates such a parameter at a surreal infinitesimal.
Collections of class maps are interpreted externally, as explained in Section 2.

## Files

`article.tex` is the self-contained LaTeX source, with an internal bibliography.
`article.pdf` is the compiled report.
`SOURCE_AUDIT.md` records provenance, the repository snapshot, and the novelty
boundary. `BUILD_REPORT.json` records the actual build and check results.
`code/verify.py` runs exact-rational finite checks; its recorded output is
`data/verification.json`. `build.sh` rebuilds the PDF and reruns the checks.

## Rebuild

Requirements: Python 3.10 or later and a conventional LaTeX installation with
pdfLaTeX and the packages used in `article.tex` (including Latin Modern,
amsmath, amsthm, mathtools, microtype, booktabs, longtable, enumitem, hyperref,
cleveref, fancyhdr, and xurl). No Python packages beyond the standard library
are required. No network access is needed to build.

On a system with Bash:

```sh
bash build.sh
```

The script writes temporary TeX outputs under `build/`, refreshes
`data/verification.json`, and copies the final PDF to `article.pdf`.
It does not update the delivered historical `BUILD_REPORT.json`.

Equivalent individual commands, usable from a suitable command prompt:

```sh
python code/verify.py --output data/verification.json
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The delivered run passed 1,576 checks using `fractions.Fraction`, with a fixed
random seed. Finite tests cover iterated Leibniz, Hasse–Schmidt product and
iterative identities, integral coefficients, noncommuting exponential/logarithm
inversion, commutators, jet nonsplitting witnesses, and formal square roots.
They use the model `Z + X Q[X]` and finite formal jets, not the full surreal field.

No repository write or modification was performed. No source PDFs from other
authors or font files are included.
