# Maximal Henselian Branching at Omnific Augmentations

**Forced complexification, invisible completions, and the arithmetic Galois factor**

Research draft prepared for Vladimir Reshetnikov, September 2026.

## Main result

For every infinite cardinal κ and any prescribed set of at most κ surreal numbers,
the article constructs a real closed subfield E of No, of cardinality κ, whose
actual induced omnific integer part B = E ∩ Oz has fraction field E and an
idempotent constant-term ideal J. Let A = B_J and H = A^h.

The local ring H has exactly 2^κ minimal primes, each with fraction field E[i],
although both A and H have adic completion Q and zero cotangent space at their
closed points. The generic fiber E ⊗_A H is a locally constant function algebra
on a Stone space X with |X| = 2^κ. Strict henselization adds the arithmetic
Galois-group factor; Gaussian complexification doubles the generic spectrum.

The proof includes the essential step that *every* finite generic branch
survives localization at the selected residue point. The normalization splitter
used to prove it is credited to and re-derived from the Surreal repository.

## Contents

- `article.pdf`: 24-page article with full written proofs, examples, twelve
  further research questions, proof-dependency audit, and bibliography.
- `article.tex`: standalone LaTeX source; bibliography included internally.
- `code/verify.py`: exact finite algebraic and combinatorial checks.
- `data/verification.json`: recorded passing verification run (5,760 assertions).
- `data/build_audit.json`: compilation and PDF validation record.
- `PROOF_AUDIT.md`: critical proof obligations and explicit limitations.
- `SOURCES_AND_SCOPE.md`: repository provenance and novelty boundary.
- `requirements.txt`: Python dependency for the finite checks.
- `build.sh`: reproduction script.

## Build

With Python 3, SymPy, and a standard TeX Live / MiKTeX installation:

```sh
python3 -m pip install -r requirements.txt
bash build.sh
```

The LaTeX file uses ordinary packages (amsmath, amsthm, hyperref, cleveref,
Latin Modern, microtype, geometry, fancyhdr, and related standard packages).
No font files, proprietary assets, external bibliography files, or remote
resources are required by the build.

To run the checks independently:

```sh
python3 code/verify.py --output data/verification.json
```

## Research status

This is a proof-bearing, internally reviewed research draft, not a claim of
independent peer review or certified historical priority. No Lean verification
of the main theorem is supplied. The finite program checks algebraic identities
and finite models; it does not verify arbitrary supports, all localization
denominators, transfinite constructions, or cardinality theorems.

All spectra and henselizations in the main results are set-sized. The article
does not claim a full proper-class spectrum or henselization of Oz, a complete
classification of its generic Boolean algebra, or a solution to a named
published factorization or automorphism conjecture.
