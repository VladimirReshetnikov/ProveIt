# Omnific Fractions
## Rationality, Denominator Ideals, and Dense Arithmetic Fibres

Research article prepared for Vladimir Reshetnikov, September 23, 2026.
The PDF has 21 pages (including its title page and contents) and approximately
9,300 words. It is an AI-assisted mathematical draft, not a peer-reviewed or
Lean-verified paper.

## Files

- `omnific_fractions.pdf`: the complete typeset article.
- `omnific_fractions.tex`: standalone LaTeX source, including the bibliography.
- `verify_examples.py`: exact finite symbolic checks, not a theorem prover.
- `verification_report.json`: the recorded successful run of 92 assertions.
- `requirements.txt`: the SymPy version used for those checks.
- `build.sh`, `build.ps1`: Unix-shell and PowerShell document build helpers.
- `SHA256SUMS.txt`: checksums for the delivered files other than itself.

## Results and scope

The classical identity `Frac(Oz) = No` is not claimed as new. Nor are the
repository's constant-term arithmetic, common monomial divisors, non-generation
of the purely infinite ideal, or irrational-real no-gcd obstruction.

The principal candidate contributions are the exact presentation module and
rational/irrational denominator dichotomy (Theorems 6.3 and 6.4), the one-scale
rational-function classification (Theorem 7.1), the congruence-kernel orbit
classification (Theorem 8.2), and the set-wise focusing theorem and dense
arithmetic fibres (Theorem 9.2 and Corollaries 9.3–9.5).

Here `Pi` consists of the normal forms supported on strictly positive exponents,
`B = R + Pi`, and `Oz = Z + Pi`. The classification is proved on the projective
region admitting a unimodular presentation over B. It covers every rational
function in a single surreal monomial, with real coefficients, and controls
all its omnific presentations, not only polynomial denominators.

A useful example: for irrational real r and T = omega^alpha, alpha > 0,
`r + 1/T` has least positive denominator T, whereas `r + 1/(T+1)` has no least
denominator and no presentation possessing a gcd. Their difference is
`1/(T(T+1))`. Opposite denominator types occur in every surreal interval.

The exact candidate statements were not found in the searched sources; this
is not a certification of historical novelty. The paper lists the search
scope, prior results, proof dependencies, unresolved extensions, and all
verification limits. It does not claim that every surreal has a B-unimodular
presentation or that arbitrary primitive pairs are Bezout pairs.

## Repository baseline

Repository: https://github.com/VladimirReshetnikov/Surreal

Inspected commit: `9a385d3957bdfe3d9ea79f9a524751c90bd2c894`.

The central comparison source was
`docs/surreal/omnific-diophantine-geometry/article.tex` and its companion README,
with the root and collection guides. Only selected current sources were
reviewed; this was not an exhaustive review of unintegrated historical
manuscripts. The repository was not cloned, built, or modified. No Lean files
or purported Lean proofs are included.

## Rebuild the PDF

Install TeX Live or MiKTeX with standard packages including `newtx`, the AMS
packages, `geometry`, `microtype`, `mathtools`, `booktabs`, `enumitem`, `xcolor`,
`fancyhdr`, `xurl`, `hyperref`, and `tikz-cd`.

On Unix-like systems:

```sh
./build.sh
```

In PowerShell:

```powershell
./build.ps1
```

Or run directly:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error omnific_fractions.tex
```

There is no external bibliography file or image dependency. The delivered PDF
compiled without undefined references, warnings, or overfull/underfull boxes;
all pages were rendered and inspected for layout. Font files are not included.

## Run the finite checks

Python 3.9 or later is required. From the archive directory:

```text
python -m pip install -r requirements.txt
python verify_examples.py
```

A successful run prints the number of checks and rewrites
`verification_report.json` beside the script. A failure exits nonzero.
The symbolic checks cover matrix identities, Bezout certificates, sample
polynomial coprimality and normalization, local-density formulas, and finite
rational order examples. They do not verify support well-ordering, proper-class
separation, non-generation of ideals, the full theorems, or novelty.
