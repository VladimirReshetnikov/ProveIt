# Gamma and Zeta over Surcomplex Fields

**Canonical finite lifts, infinite-scale obstructions, and Riemann-hypothesis transfer**

Research article prepared for Vladimir Reshetnikov, dated 22 September 2026.
The compiled PDF contains 28 physical pages (title page plus pages 1–27),
with complete proofs, a theorem/dependency ledger, and 20 bibliography entries.

## Files

- `Surcomplex_Gamma_Zeta_and_RH.pdf` — compiled article.
- `Surcomplex_Gamma_Zeta_and_RH.tex` — standalone LaTeX source, including bibliography.
- `verify_identities.py` — exact symbolic checks for finite coefficient identities.
- `verification.json` — recorded successful run: 296 of 296 checks passed.
- `requirements.txt` — Python dependency for the checks.

## Mathematical scope

The article distinguishes three constructions: canonical Taylor–Laurent lifting
at finite surcomplex arguments; strongly summable asymptotic constructions at
specified infinite arguments; and elementary extensions equipped with transported
classical functions. These constructions are not silently identified.

Principal results include finite divisor rigidity and equivalence of finite RH
with classical RH; equivalence of universal symmetric infinitesimal stability
with RH plus simplicity; a normalized infinite-scale Gamma-ratio cocycle; an
exact obstruction to imposing reflection on bare Stirling evaluation; a faithful
formal Dirichlet-algebra realization in the positive-infinite right tube; and
precise transfer statements for classical partial results. A final theorem shows,
conditionally on RH and simplicity, that nonreal zeros of the negative-infinitesimal-
time de Bruijn–Newman deformation escape every finite monad.

This is an unrefereed research draft, not a proof of classical RH. It does not
assert a canonical global zeta function on all of No[i], compatibility of every
elementary realization with Hahn evaluation or Gonshor exponentiation, an
exhaustive priority search, or proof-assistant verification. The finite symbolic
checks accompany, but do not replace, the mathematical proofs.

## Build the PDF

Use a standard TeX Live or MiKTeX installation with the packages listed in the
source preamble:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error Surcomplex_Gamma_Zeta_and_RH.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error` on the source
until the cross-references stabilize, normally three passes. No external images,
custom font files, bibliography database, or network access are required.

The shipped PDF was compiled successfully, with no LaTeX warnings, unresolved
references, or overfull/underfull boxes. Rendered pages were visually inspected.

## Reproduce the exact checks

Python 3.10 or later is required. The recorded run used Python 3.13.5 and
SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python verify_identities.py --output verification-rerun.json
```

The default output name is also `verification-rerun.json`; the shipped evidence
is not overwritten unless explicitly selected as the output. The script exits
with a nonzero status if a check fails. It tests exact finite identities involving
Bernoulli polynomials, Stirling shifts, normalized Gamma ratios, reflection
corrections, Dirichlet convolution, and formal root perturbations. It does not
numerically verify zeros, represent an infinite surreal by floating point,
or certify general summability and transfer theorems.

## Repository and source audit

The targeted repository audit used revision:

`905dd19954db43ac81f76f72036520d0eadc5710`

of `VladimirReshetnikov/Surreal`. The scope was the report catalogue, the initial
foundational material of the surcomplex analysis manuscript, and the detailed
maintained Gamma report description. It was not a complete repository proof
review. Classical results were checked against primary papers and official
publisher or DLMF sources. The article gives precise references and does not
claim that its selected quantitative benchmarks are the latest records.
