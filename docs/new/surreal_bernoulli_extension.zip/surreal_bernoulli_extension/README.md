# Beyond the Square-Summability Barrier

## Exact Bernoulli Product Extension at Surreal Scales

Research manuscript prepared for Vladimir Reshetnikov, 22 September 2026.

The article is a standalone 24-page PDF with its LaTeX source. It develops
an exact extension criterion for independent Bernoulli laws whose
probabilities are infinitesimal Hahn perturbations of arbitrary strictly
interior real baseline probabilities.

For every exponent gamma, the coefficient row a[j,gamma] must satisfy

    sum_j min(abs(a[j,gamma]),
              abs(a[j,gamma])**2 / (p[j] * (1 - p[j]))) < infinity.

Equivalently, each row lies in the sum of the absolute-summability space
and the weighted square-summability space. Uniform separation of p[j]
from zero and one is not assumed.

The central result is Theorem 5.1. Theorem 4.2 supplies the finite-parameter
entire complex likelihood construction; Theorem 4.4 gives its single
imaginary-parameter test for real rows. Theorem 7.1 gives an exact power-law
threshold. Examples distinguish the mixed space from either individual
sufficient class, and demonstrate a failure at the surreal scale
omega^(-omega) despite valid coefficients at every lower integer scale.

## Files

- `article.pdf`: complete article, 24 pages.
- `article.tex`: standalone LaTeX source with internal bibliography.
- `code/verify.py`: exact finite checks, Python 3.9 or newer, standard library.
- `data/verification_results.json`: 4,670 passing rational assertions.
- `data/build_validation.json`: PDF/build checks and verification scope.
- `RESEARCH_AUDIT.md`: repository pin, literature boundary, proof review.
- `build.sh`: Linux/macOS build and finite verification.
- `build.ps1`: Windows PowerShell build and finite verification.
- `SHA256SUMS.txt`: hashes of the delivered files (excluding itself).

## Build

Install a TeX distribution with pdfLaTeX and the usual packages used in the
preamble (amsmath, amsthm, lmodern, microtype, geometry, hyperref, and related
standard packages). No external graphics, BibTeX run, or bundled font files
are needed.

On Linux/macOS:

    bash build.sh

On Windows PowerShell, from this directory:

    .\build.ps1

Or run the commands directly:

    python code/verify.py
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Use `python3` rather than `python` where required by your environment.
The scripts stop on a failed check or failed LaTeX invocation. PDF metadata
may change on rebuilding; the supplied hashes identify the delivered files.

## Mathematical and verification status

The all-scale nonuniform theorem is offered as a proposed new strengthening
of the inspected repository, with full written proofs. No named published
conjecture is claimed solved. The literature check did not identify an exact
published match, but cannot certify historical priority. Classical
independent-series methods, the Neumann lemma, and the surreal normal-form
bridge are credited as background.

The finite Python checks do not prove the infinite-dimensional statements.
No independent referee report or Lean/kernel verification is claimed.

The measure uses ordinary countable addition separately at each exponent.
It is not strongly Hahn countably additive and is not additive by convergence
in the fine surreal topology. The sample space and value-group workspace
are sets; this is not a measure on the proper class of all surreal numbers.

Repository comparison is pinned to:

    465a54b479a1ee842cbf7db1689a7d2f6bfe25e1

Relevant source:
`docs/surreal/hahn-valued-measures-and-probability/article.tex` in
`VladimirReshetnikov/Surreal`.
