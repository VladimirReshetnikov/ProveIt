# Differential Rigidity of Omnific Points

**Smooth-curve classification, squarefree equations, and algebraic groups**  
Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `omnific_differential_rigidity.pdf`: the 29-page article, including proofs,
  counterexamples, dependency and verification audits, and references.
- `omnific_differential_rigidity.tex`: standalone LaTeX source with internal
  bibliography; no external figures, fonts, or bibliography files are needed.
- `verify_certificates.py`: exact symbolic and finite Hahn-algebra checks.
- `verification_report.txt`: the recorded successful run (12,874 assertions).
- `SOURCE_AND_PROOF_AUDIT.md`: repository baseline, theorem provenance, scope,
  and important proof-review boundaries.
- `build.sh`: PDF build script.
- `requirements.txt`: the tested SymPy version for the optional checks.

## Main results and reading paths

For the direct Diophantine argument, read Sections 2–4. Theorem 4.1 proves
that a solution of y^m = F(x) in the nonnegative-support Hahn ring is constant
when the coefficients are constant, the characteristic is zero, F is
squarefree, and m and deg(F) are at least two. Section 4.1 gives an explicit
universal cubic certificate. Section 4.2 treats general nonsingular
Weierstrass equations with ordinary integer or Gaussian integer coefficients.

For the geometric theorem, read Sections 5–7. Theorem 5.1 is the abstract
two-ring differential-annihilation principle. Theorems 6.1 and 6.3 turn
cotangent or symmetric-differential detection into constancy. Theorems 7.4
and 7.5 classify smooth geometrically integral affine curves over C and R:
the only curves with nonconstant nonnegative-support points are affine lines.
Corollary 7.6 adds the projective line to classify all smooth separated curves
of finite type over these two fields.

Section 8 gives exact arithmetic fibers (Theorem 8.1) and proves that every
nonordinary omnific point on such a smooth affine curve has a finite-support
witness through the same ordinary base point (Corollary 8.2).

Section 9 proves rigidity for abelian and semiabelian varieties and computes
the nonconstant kernel of every smooth connected commutative algebraic group's
points: after choosing coordinates on its maximal unipotent subgroup Ga^d,
that kernel is I^d. This is a splitting of point groups, not a claim that the
algebraic group itself splits.

Section 10 treats unimodular projective tuples on positive-genus curves.
Sections 11–12 record sharpness and unresolved boundaries.

## Research status

This is a proof-bearing, AI-assisted research draft. The main extensions have
full arguments in the article, but have not been independently refereed or
formally verified. Priority is provisional. The finite checks are not a proof
of the infinite-support or scheme-theoretic statements.

The article resolves the nonsingular elliptic test and the smooth-curve
portion of Question 14.1 in the inspected repository report. That repository
question is explicitly a continuation question, not a certified open problem
in the published literature. This package does not claim to resolve the
primitive-but-not-unimodular Fermat question, arbitrary singular curves,
arbitrary affine varieties, or Conway's general factorization questions.

## Repository baseline

Repository: https://github.com/VladimirReshetnikov/Surreal

Pinned commit: `4cdeaec43ff1692ed2ad9f5bdf761a41872975a5`

Main inspected source:
`docs/surreal/omnific-diophantine-geometry/article.tex`

See `SOURCE_AND_PROOF_AUDIT.md` for the specific source ranges and distinction
between existing material and the proposed extensions.

## Build

A standard TeX Live or MiKTeX installation with pdfLaTeX and the packages named
in the preamble is sufficient. The source uses standard `lmodern`, `amsmath`,
`amssymb`, `amsthm`, `mathtools`, `mathrsfs`, `aliascnt`, `geometry`, `microtype`, `booktabs`,
`array`, `longtable`, `enumitem`, `fancyhdr`, `hyperref`, `cleveref`, `listings`,
and `xurl` packages.

On a Unix-like system:

```sh
sh build.sh
```

On other systems, run this command three times in the extracted directory:

```text
pdflatex -interaction=nonstopmode -halt-on-error omnific_differential_rigidity.tex
```

## Optional exact checks

Requires Python 3.10 or newer. The recorded run used Python 3.13.5 and
SymPy 1.14.0. In an appropriate Python environment:

```sh
python -m pip install -r requirements.txt
python verify_certificates.py --output verification_report.txt
```

The script has a fixed random seed and uses exact rational/symbolic algebra.
Its checks do not certify mathematical originality or the geometric proofs.
PDF builds need not be byte-for-byte identical because of embedded timestamps.
