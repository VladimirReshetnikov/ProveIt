# Prime Spectra at Surreal Infinity

**Reduced entire divisors, valuation fibres, and splitting under cofinal scalar extension**

A 28-page research article with complete written proofs of its main results,
prepared in response to a request to extend research in the Surreal repository.

## Start here

Open `prime_spectra_at_surreal_infinity.pdf`. Its standalone source is
`prime_spectra_at_surreal_infinity.tex`; the bibliography is included in that
file, so no separate BibTeX database is required.

The setting is a fixed, set-sized Hahn field K = k((t^Gamma)), with k equal to
R or C and Gamma a divisible ordered abelian group of countable cofinality.
“Entire” means strong Hahn summability of the ordinary monomial family at
every point of that particular field. It does not mean entireness on all of No(i).

## Principal results

- **Theorem 4.5:** all primes above a reduced one-node-per-shell entire divisor,
  parametrized by ultrafilters and convex subgroups of explicit ultraproduct
  value groups. Theorem 4.7 gives their local valuation rings.
- **Theorem 6.3:** the divisor quotient is zero-dimensional exactly when the
  value group has an order unit. Otherwise every nonprincipal-ultrafilter
  fibre contains a continuum-sized strict chain of primes, despite simple zeros.
- **Theorems 7.1–7.2:** finite ideals are principal and projective, and finite
  matrices have Smith diagonal forms, even in the infinite-dimensional case.
- **Theorem 8.4:** exact prime contraction under cofinal scalar extension,
  with every extension classified by an interval of convex subgroups.
- **Theorem 9.3 and Corollary 9.5:** an explicit cofinal enlargement of surreal
  scale groups adds continuum chains of prime extensions without changing
  the entire function or its zero set. Even an old maximal ideal can have
  continuum many nonmaximal extensions. Both endpoint spectra remain unchanged.
- **Theorem 11.2:** a precise uniform-multiplicity threshold for recovering the
  spectrum from the reduced divisor, together with an exact radical-membership test.

## Provenance and novelty limits

Repository snapshot:
`465a54b479a1ee842cbf7db1689a7d2f6bfe25e1`.

The exact interpolation quotient and the maximal-ideal classification were
already in the repository. They are credited as such; the simple-node analytic
input is reproved in the article. The abstract ultraproduct/valuation-domain
prime mechanism is classical, notably in the work of Finocchiaro, Frisch and
Windisch. It is not presented as a new abstract theory.

The proposed contributions are the full analytic prime-fibre description,
the reduced-divisor order-unit dichotomy, and the explicit cofinal splitting
construction and its consequences. The report records a targeted source
comparison, not an exhaustive priority search. No named published conjecture
is declared solved. This manuscript has not been independently refereed or
verified in Lean.

See `SOURCE_AUDIT.md` and the provenance sections of the article for details.

## Build

A LaTeX installation providing pdfLaTeX and the standard packages named in the
preamble is required. On a Unix-like system:

```sh
sh build.sh
```

Alternatively, run pdfLaTeX on the `.tex` file three times. The source uses
standard Latin Modern fonts through LaTeX; no external font files are included.

## Exact finite sanity checks

Only the Python standard library is required:

```sh
python3 verify_finite.py --json verification_results.json
```

The delivered run passed **10,889 assertions**, including **200 finite Smith
matrix cases**. The program checks finite cardinal identities, ordered-group
damping inequalities, rational-cut intersection witnesses, representative
power-gap inequalities, and finite multiplicity tests.

These are sanity checks, not machine verification of the article. In
particular, they do not establish strong summability, construct a free
ultrafilter, prove continuum-chain assertions, or certify novelty.

## Package contents

- `prime_spectra_at_surreal_infinity.pdf`: typeset article.
- `prime_spectra_at_surreal_infinity.tex`: complete standalone source.
- `verify_finite.py`: deterministic exact-arithmetic sanity checks.
- `verification_results.json`: actual output of the delivered run.
- `SOURCE_AUDIT.md`: sources, inherited results, and originality limits.
- `BUILD_REPORT.json`: compilation and PDF-layout checks.
- `build.sh`: rebuild helper.
- `README.md`: this guide.
