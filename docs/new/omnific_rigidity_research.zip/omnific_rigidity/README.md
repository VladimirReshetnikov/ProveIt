# Small-Target Rigidity and Arithmetic Specialization for Omnific Integers

Research manuscript dated September 23, 2026. The PDF has 21 pages.

## Files

- `article.pdf`: the typeset article with full proofs and references.
- `article.tex`: self-contained LaTeX source; the bibliography is embedded.
- `verify.py`: exact finite algebra checks, using Python 3.9+ and only its standard library.
- `verification.txt`: output from running the checks.
- `source_manifest.json`: repository snapshot, inspected sources, and verification boundaries.
- `SHA256SUMS.txt`: hashes of the other distributed files.

## Main results

Theorem 4.1: every unital ring homomorphism from the full class of omnific
integers to a set-sized ring factors through the ordinary integer constant
coefficient. The target need not be commutative. The theorem also covers
Gaussian omnific integers and a general constant subring of a coefficient field.

Theorem 5.3: the ordinal Grothendieck ring under natural operations cannot be
a quotient of the omnific integers. This answers the final quotient-ring
addition in Jesse Elliott's 2014 MathOverflow question, NOT the original
transcendence-degree question. Two independent proofs are supplied.

Theorem 8.2: the nonzero constant fiber of a product of affine linear forms
is exactly the union, over its ordinary points, of the pure Hahn series in
the common kernel of the linear parts. Theorem 9.2 applies this to finite
etale norm forms: nonzero norm equations acquire no new omnific solutions.
Pell equations and a cubic norm provide concrete examples.

The remaining sections give the small quotient and module classifications,
the purely infinite ideal's monomial filtration and size-correct homological
properties, equation-only Diophantine transfer, and sharp counterexamples.

## Build

A normal TeX Live or MiKTeX installation with the packages named in the source
is sufficient. No fonts or bibliography database need to be downloaded from
this package.

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times to settle cross-references and contents. The document uses Latin
Modern fonts supplied by the TeX distribution.

## Reproduce the finite checks

    python verify.py

The script uses exact rational arithmetic, not numerical tolerances, and its
checks remain active under `python -O`. It checks 51 finite geometric remainder
identities and support positivity, the cubic norm determinant, a Laurent norm
identity, a rank-deficient example, and a selected constant-coefficient identity.

## Verification and priority boundaries

The mathematical arguments were developed and reviewed while preparing this
manuscript. They are unrefereed and have not been independently validated or
machine-checked in Lean. The finite script does not verify arbitrary Hahn sums,
surreal cuts, proper-class cardinal arguments, or the general theorems.

The final PDF compiled successfully, with no LaTeX warnings, unresolved
references, missing-character warnings, or overfull/underfull boxes reported
in the final log. Pages were rendered and visually inspected, with the title,
contents, bibliography, and central theorem pages checked at reading scale.

Novelty is provisional. The article identifies established ingredients and
routine consequences separately from its proposed contributions. A bounded
web/repository search did not establish that the main statements are absent
from all literature or prior drafts. No claim about the current status of
Conway's refinement conjecture is needed or made.

The repository was read-only and pinned to
71e9606d297c9b98c732070dc462682cc6948981. It was not modified, compiled, or
comprehensively audited for this delivery. See Section 11 and the manifest.

The full-class size hypothesis is essential. In the optional two-universe
formulation, small targets belong to the smaller universe, while the source
ring is treated as a set in the larger universe. Do not replace this by a
claim about all maps out of every fixed set-sized Hahn ring.
