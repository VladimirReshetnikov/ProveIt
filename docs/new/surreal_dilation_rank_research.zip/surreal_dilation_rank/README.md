# Support Rank and Algebraic Independence of Dilation Orbits

Research article prepared with ChatGPT for Vladimir Reshetnikov, 23 September 2026.

The PDF has 29 pages: a title page, two contents pages, and 26 numbered pages.

## Main results

Theorem 1.1 proves a support-rank lower bound for algebraic independence of
positive exponent dilates in arbitrary Hahn fields. It permits infinite
supports and coefficients in a full Hahn subfield. The ordered scalar field
can be Q, or R when the coefficient field and exponent space support it.

Theorem 1.2 and Corollary 6.6 give exact autonomous order for every finite-support
surreal, surcomplex, or omnific number: the order under any rational dilation
d > 0, d != 1, is its rational support rank. Any m distinct positive rational
dilates have transcendence degree min(m, rank).

This resolves the research question "Exact order from finite support" in the pinned
repository report `docs/surcomplex/autonomous-dilation-relations/article.tex`.
Corollary 5.2 also resolves the rational-rank component of the next question:
a relation of order r forces support rank at most r, even for infinite support.
The order-type and denominator-growth parts of that question remain open here.

Theorems 6.3 and 6.4 extend the exact formula to rational functions in finitely
many monomials. For a reduced quotient P/Q, rank is the dimension of the
rational span of all differences between exponents in supp(P) union supp(Q).

Theorem 8.2 proves that the omnific integer

    Xi = sum_{n >= 0} omega^(omega^(-n))

has an algebraically independent orbit under all distinct positive REAL
exponent dilations, over C. Theorem 9.3 gives an explicit ordinal family whose
tail has that joint independence property over every prescribed set-sized
Hahn coefficient core. All proper-class claims mean finite-instance
algebraic independence and use only set-sized linear algebra.

The article also proves a finite-support prime-field formula after grouping
dilations by their p-free parts, and gives twelve further research questions.

## Files

- `article.tex`: standalone LaTeX source with internal bibliography.
- `article.pdf`: compiled article.
- `PROOF_AND_SOURCE_AUDIT.md`: claim boundaries, dependencies, source audit.
- `code/verify.py`: exact finite checks, Python 3.9+ standard library only.
- `data/verification_results.json`: reproducible recorded run.
- `BUILD_RECORD.json`: build, rendering, and verification metadata.
- `build.sh` and `build.ps1`: local rebuild scripts.
- `SHA256SUMS.txt`: hashes of the delivered files other than the checksum file.

## Reproduce

From this directory, with Python 3.9+ and a TeX installation on PATH:

```sh
python code/verify.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `./build.sh` on a Unix-like system or `./build.ps1` in
PowerShell. The source uses standard TeX packages, including newtx, amsmath,
amsthm, mathtools, geometry, microtype, booktabs, enumitem, tcolorbox, hyperref,
aliascnt and cleveref. No external images, private fonts, bibliography
processor, network access, or Python dependencies are needed.

The scripts rewrite the local PDF and JSON results. They do not contact a
service or change the Surreal repository. PDF byte hashes can differ on a
rebuild because of TeX version and PDF creation timestamps.

## Verification and status

The recorded run passed 1,490 check units, including 217 exact polynomial
Jacobian expansions and four cleared rational-function Jacobians. These are
finite consistency checks, not a proof-assistant verification of infinite
Hahn summation, basis extension, or the proper-class conclusions.

The final PDF compiled without LaTeX warnings, overfull boxes, undefined
references, or missing citations, and all pages were rendered for visual
inspection. Written proofs have been reviewed during preparation but have not
been independently refereed or formalized in Lean. Novelty is proposed;
priority is not certified. The classical power-sum special case, greedy
selection, logarithmic series derivations, and Hahn arithmetic are credited.
No famous published conjecture is claimed solved.

Repository snapshot:
`efc5446229dbf61a97bdd5edae91dba20af9d131`.
