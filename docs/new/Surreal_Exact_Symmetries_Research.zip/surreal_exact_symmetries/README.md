# Relative Universality and Exact Fixed Fields of Strong Omnific Symmetries

**24-page research article, 23 September 2026.**
Prepared for Vladimir Reshetnikov as an AI-assisted research manuscript.

## Main result

For a subclass B of the surreals, H(B) denotes the real-coefficient Conway
normal forms with set-sized reverse-well-ordered support contained in B.
For every set S of surreals and every nontrivial set-sized left-orderable
group G, the article constructs a faithful action by strong,
real-coefficient-fixing, omnific-preserving field automorphisms such that

    Fix(sigma_g) = H(H(S))  for every g != 1.

In particular, every left-orderable set group can act on No freely outside
R, and on Oz freely outside Z. Conversely, a set group acting faithfully
by field automorphisms of No, or unital ring automorphisms of Oz, must be
left-orderable. Prescribed set parameters are handled by their two-level
normal-form supports.

The surcomplex/Gaussian classification with named conjugation is also
exact: the admissible set groups are the left-orderable groups and the
groups H x C2 with H left-orderable. A fixed nonreal parameter eliminates
the latter sign alternative.

## Files

- `article.pdf` — typeset article, 24 physical pages, including the title page.
- `article.tex` — standalone LaTeX source with an internal bibliography.
- `verify.py` — standard-library Python exact finite checks.
- `verification.json` — recorded successful run: 11,330 assertions.
- `PROOF_AUDIT.md` — proof dependencies, critical steps, and limitations.
- `SOURCE_AUDIT.md` — repository pin, antecedents, and novelty boundary.
- `BUILD_REPORT.json` — compilation, rendering, and structural checks.
- `build.sh` and `Makefile` — reproduction commands.
- `SHA256SUMS.txt` — integrity hashes for the delivered files other than itself.

## Rebuild

Requirements: Python 3.10 or later; a standard LaTeX distribution with
pdfLaTeX, Latin Modern, AMS packages, microtype, geometry, hyperref,
bookmark, enumitem, fancyhdr, and tabularx.

```sh
python3 verify.py
sh build.sh
```

`build.sh` reruns the finite checks and runs pdfLaTeX three times. No
BibTeX, network access, external bibliography, images, or proprietary fonts
are needed. `make clean` removes only temporary LaTeX build files, not the
article PDF or verification output. The PDF embeds the necessary fonts;
standalone font files are not included.

## Status and limitations

The article contains complete manuscript arguments for its stated
results. These arguments have not been independently refereed or checked
in Lean. The finite checks verify formulas in finite models; they do not
verify infinite Hahn support arguments or class recursion.

The ordinary external/double Hahn lifting framework is established
literature and is credited accordingly. Existing repository work already
contains fixed-field, parameter-stabilizer, and nonabelian-action results.
The exact all-left-orderable-group realization with one fixed field for
every nonidentity element is presented as a proposed contribution, not a
certified first-in-literature discovery. No solution of an unrelated named
open conjecture is claimed.

The constructions do not preserve the Gonshor exponential, the named
omega map, or birthdays in general. They do preserve the class of Conway
monomials. They use the full proper-class surreal field in NBG with Global
Choice. They are not automatically theorems about a specified birthday
cutoff.

Repository comparison is pinned to commit:
`efc5446229dbf61a97bdd5edae91dba20af9d131`.

The hashes identify the delivered release. A rebuild may change PDF metadata
and therefore its byte hash even when the rendered article is unchanged.
