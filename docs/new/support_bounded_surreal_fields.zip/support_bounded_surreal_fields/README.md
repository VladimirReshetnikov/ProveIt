# Support-Bounded Surreal Fields

**Sharp saturation and spherical thresholds, an exponential obstruction,
and indistinguishable omnific quotients**

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Files

- `article.tex`: standalone LaTeX source, including bibliography.
- `article.pdf`: compiled 25-page article.
- `verify.py`: exact finite rational checks, Python standard library only.
- `verification.json`: recorded run; 31,672 checks passed.
- `SOURCE_AUDIT.md`: source scope, novelty boundary, and proof checkpoints.
- `BUILD_REPORT.json`: compilation and PDF validation record.
- `build.sh`: convenience build script for POSIX environments.

## Main results

For every uncountable cardinal kappa, F_kappa is the class of surreal
numbers with fewer than kappa nonzero Conway normal-form terms. No bound
is imposed on the exponents themselves. The paper treats singular as well
as regular cardinals.

Theorem 4.3 classifies all set-presented gaps by first-kappa prefixes.
Theorem 4.4 computes their character as (cf(kappa),cf(kappa)). Corollary
5.2 gives the exact ordered-field saturation threshold. Theorems 6.2 and
6.4 give the sharp strong-sum and nested-ball thresholds. Proposition 8.2
gives the exact inherited exponential image, and Theorem 8.6 proves that
no surjective ordered-group exponential exists on this exp-closed field.
Theorem 9.3 proves that every map from O_kappa to a set-sized ring factors
through the integer constant term. Theorem 10.3 produces an intrinsic
proper-class family of nonconjugate surcomplex involutions.

Section 12 contains eight proposed further research questions and routes.
Section 13 and SOURCE_AUDIT.md separate classical machinery, prior
repository results, and the candidate contributions.

## Rebuild

A TeX installation with pdfLaTeX, Latin Modern, amsmath, amsthm, mathtools,
microtype, geometry, booktabs, longtable, enumitem, xcolor, xurl, hyperref,
and fancyhdr is sufficient. No BibTeX run or external figures are needed.

Run from this directory:

```sh
python3 verify.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

These commands also work in an appropriately configured Windows terminal
with `python` replacing `python3`. Alternatively run `sh build.sh` on POSIX.
The checking script writes `verification.json`; a different destination can
be supplied with `--output PATH`.

## Status

AI-assisted, unrefereed research manuscript. Full written proofs are
provided, but no theorem here is claimed Lean-verified or independently
peer-reviewed. Bibliographic priority is not certified. The finite checks
verify finite identities and boundary conventions, not cardinal arguments,
saturation, infinite Hahn summability, class back-and-forth, or the
nonexistence theorem.

Repository baseline:
343dc2c471212bb9b53ff4623bace2e1943f255b.
The repository was not modified by this task.
