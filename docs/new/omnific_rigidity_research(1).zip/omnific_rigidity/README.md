# Algebraic-Parameter Rigidity of the Omnific Integers

**Strong cancellation, finite-type embeddings, and nonalgebraizable formal flows**

Research article prepared for Vladimir Reshetnikov, 23 September 2026.
Author: OpenAI ChatGPT. The PDF has 25 pages, including its title page.

## Principal results

The article proves an exact monomial-divisibility criterion for positive-support
Hahn integer rings: every nonzero element divides a monomial exactly when the
nonzero divisible exponent group has no order unit. Such rings, including Oz
and Oz[i], satisfy the article's “root-covered” condition.

An injective map from a root-covered domain into a polynomial or Laurent
polynomial ring over a domain must land in its coefficient ring (Theorems 5.1
and 5.3). This yields coefficient-preserving strong cancellation against an
arbitrary comparison ring, with equal total variable counts (Theorem 6.1),
polynomial and Laurent automorphism consequences, and the stable
Makar-Limanov formula ML(R[T_1,...,T_n]) = R (Theorem 8.3).

A general finite-type embedding theorem forces images into a finite algebraic
constant field (Theorem 4.4). A chosen rational point then makes any compatible
embedding constant (Theorem 9.1). These general finite-type assertions are
stated for set-sized domains, with explicit Hahn examples. The elementary
polynomial/cancellation arguments are also explained for class rings.

Explicit commuting omnific derivations integrate to compatible formal flows
of all orders, but nonzero first jets cannot come from polynomial families.
The exact formula for the monomial orbit field is

    trdeg_F F(exp(w*s) : w in chi(Gamma)) = dim_Q chi(Gamma).

For nonzero chi this field is not contained in a finitely generated extension
of F inside F((s)), even when that displayed transcendence degree is finite.
One explicit omnific flow has a continuum-sized algebraically independent
monomial-orbit family over No (or No(i) in the Gaussian case).

## Files

- `article.tex`: standalone LaTeX source, with embedded bibliography.
- `article.pdf`: compiled 25-page article.
- `verify.py`: exact finite coefficient and determinant checks.
- `verification.json`: actual output; 7,041 assertions passed.
- `source_audit.md`: sources inspected, comparison scope, and novelty limits.
- `build_audit.json`: build, rendering, and file-integrity record.
- `Makefile`: compilation, check, and cleanup commands.

## Reproduction

The TeX source needs a standard TeX Live or MiKTeX installation with the packages
listed in its preamble. It requires no external images, bibliography database,
or bibliography processor.

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex
python3 verify.py
```

Without latexmk, run pdflatex repeatedly until the contents and references
stabilize. The check script uses Python 3.9 or later and only the standard
library. `make`, `make check`, and `make clean` provide equivalent shortcuts
in an environment with make installed.

## Research and verification status

The central deductions are proved in conventional mathematical form. The
proposed novelty is the linked omnific/Hahn-integer rigidity and deformation
package, not the established terminology or all of its elementary ingredients.
Targeted searches did not locate the principal omnific statements in this form,
but do not establish historical priority. No named open factorisation conjecture
is claimed to be solved.

The manuscript is not peer reviewed and its new results were not formalized
or checked in Lean. The 7,041 finite assertions test coefficient identities
and explicit determinants; they do not certify the infinite Hahn, class-size,
cancellation, or novelty claims. Full proofs, standard inputs, and the
formalization boundary are separated in the article and source audit.

Repository comparison snapshot:
`fb5c4b530e3ec04b5661347d51d5382526d5aa02`.
The user's repository was read but not modified.
