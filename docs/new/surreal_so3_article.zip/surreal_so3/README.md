# Rotations of Surreal Three-Space
## Algebra, Spin, Infinitesimal Structure, and Topology

22 September 2026

This package contains a 31-page article with 19 main sections, 26 numbered
mathematical statements, two reference appendices, and a bibliography.

## Files

- `article.pdf`: the compiled article.
- `article.tex`: self-contained LaTeX source, including its bibliography.
- `verify.py`: exact symbolic and finite-algebra checks.
- `verification.txt`: recorded output of all 24 successful checks.
- `requirements.txt`: the tested SymPy version.
- `SHA256SUMS.txt`: hashes of the package contents other than this hash file.

## Main subjects

The article defines SO(3,No) as the origin-preserving, orientation-preserving
isometry class group and proves the linearity of those isometries. It develops
axis-angle, quaternion/spin, Euler, and Cayley descriptions; conjugacy and
centralizers (including the half-turn exception); the split standard-part
extension; unique divisibility and perfectness of the infinitesimal kernel;
infinitesimal conjugacy of finite subgroups to real subgroups; strong Hahn
exp/log and BCH; and the valuation-graded cross-product algebra.

It also treats the finite-angle and Ehrlich–Kaplan global phases, the fibers and
fine differential of the global rotation exponential, exact multi-scale examples,
and the differences between full surreal fine topology, intrinsic workspace
topology, and semialgebraic homotopy.

The finite-algebra results are proved over real closed fields. Standard-part
results assume an extension of the ordinary real field. Strong series use an
explicit Hahn/normal-form interpretation, not an assumed convergence of partial
sums in the full surreal fine topology. Proper-class and universe restrictions
are stated in the article.

## Build the article

From this directory, with a TeX distribution containing the packages named in
the preamble:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times to resolve the contents and cross-references. No BibTeX run, network
access, external images, or separately supplied font files are needed.

The delivered PDF was compiled with pdfLaTeX. Its final build had no unresolved
references, overfull boxes, or LaTeX warnings. All pages were rendered for layout
inspection; the Jacobian page was additionally inspected at higher resolution.

## Run the checks

```text
python -m pip install -r requirements.txt
python verify.py
```

On Windows the Python launcher can be used in place of `python`:

```text
py -m pip install -r requirements.txt
py verify.py
```

The recorded run used Python 3.13.5 and SymPy 1.14.0. The script checks exact
polynomial/rational identities, including quaternion associativity, the complex
matrix representation, Cayley composition, the scalar commutator construction,
and the right-trivialized Jacobian. It also checks all 576 products of the
24-element octahedral group and an exact rational averaging intertwiner.

These checks are not a Lean formalization and do not establish the support,
real-closedness, or topology theorems by computation. The article supplies
mathematical proofs or explicit references for those results.

## Repository and research provenance

The inspected Surreal repository snapshot was:

```text
https://github.com/VladimirReshetnikov/Surreal
commit dcf86662b574988e75d08d515d3a2a5ba7bbc0d7
```

The repository's documentation index, introductory formalization-ledger status,
surquaternion README, and relevant surquaternion source sections were reviewed.
The bibliography distinguishes report directories identified through that index
from source sections actually inspected. The repository was not rebuilt, and
this package does not change its files.

The article is an AI-assisted research exposition. It does not claim new priority
for classical quaternion theory or for the perfectness of the infinitesimal
rotation group; the Bays–Peterzil precedent is explicitly acknowledged. It also
does not claim a classification of all abstract subgroups or a complete Lean
verification. The detailed argument remains subject to mathematical review.
