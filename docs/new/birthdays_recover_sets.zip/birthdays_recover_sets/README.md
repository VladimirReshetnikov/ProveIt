# Birthdays Recover Sets

**Bi-interpretability, Elementary Embeddings, and Forcing in Surreal and
Surcomplex Fields**

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT,
22 September 2026.

## Read the article

- `birthdays_recover_sets.pdf`: compiled article.
- `birthdays_recover_sets.tex`: self-contained editable LaTeX source,
  including the bibliography.

The principal claim is a uniform, parameter-free bi-interpretation between

    (No_{<kappa}; 0,1,+,-,*,<,birthday)

and `(H_kappa, membership)` for every uncountable regular cardinal kappa.
The paper supplies graph codes modulo bisimulation, small certificates for
Conway arithmetic, and both definable round trips. It derives an elementary
embedding correspondence and an explicit formula detecting new ordinal
subsets across proper same-ordinal transitive outer universes.

The surcomplex version names conjugation, i, and the coordinate birthday
beta(x+i*y) = max(birthday(x), birthday(y)). An orientation proposition
explains why deleting the named i gives mutual interpretation but not
parameter-free bi-interpretation with the standard hereditary-set structure.

## Status and boundaries

These are candidate-original results supported by written mathematical
proofs. The work has not been independently refereed or formally verified.
It does not advertise the resolution of a named published open problem.
The literature and repository audit was targeted, not exhaustive; historical
priority remains unverified. Classical sign arithmetic, cardinal birthday
closure, well-founded recursion, and quantifier elimination are cited inputs.
Simplicity rigidity already covered by the repository is treated as prior
work, not as a new contribution.

The main set-sized theorem assumes kappa uncountable regular. H_kappa is
not generally V_kappa; they agree at strongly inaccessible kappa. The full
outer-universe theorem assumes transitive ZFC models with the same ordinals.
The article states separately how its internal interpretation applies to
possibly nonstandard models. The complex beta is a coordinate convention,
not an asserted game-theoretic birthday.

## Build

A TeX Live installation with latexmk, pdfLaTeX, newtx, amsmath, amsthm,
mathtools, microtype, geometry, hyperref, cleveref, aliascnt, tocloft, xurl,
fancyhdr, enumitem, and the usual table packages is sufficient.

```sh
./build.sh
```

Alternatively:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error birthdays_recover_sets.tex
```

No external bibliography file, image, or distributed font file is needed.

## Finite diagnostics

Python 3.10 or newer, standard library only:

```sh
python3 code/check_finite_models.py
```

The script checks 65,025 ordered pairs of finite signs; 4,096 pairs of
four-node acyclic graphs, with 65,536 root-pair equality checks and the
same number of membership checks; 64 graph-matrix round trips;
49 finite rectangle cases; and 30 missing-row cases.
It also checks the specific counterexample to dropping the length
inequality in the prefix formula.

The preserved output is `data/finite_checks.json`. These finite tests
are diagnostic only. They do not prove transfinite recursion, cardinal
closure, first-order bi-interpretability, or forcing results.

## Repository comparison

`data/repository_audit.json` records the pinned repository revision and the
selected requested source ranges. Some large returned excerpts were
truncated. No complete scan of every manuscript, historical archive, or
Lean declaration was performed. The remote repository was not modified,
and its Lean build was not run for this work.
