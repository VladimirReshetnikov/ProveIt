# Transfinite Critical Potentials over the Surreals

**Exact solvability, hidden logarithmic scales, and Hahn-field solution jumps**  
Research report prepared for Vladimir Reshetnikov, 22 September 2026.

## Contents

- `article.pdf`: the 21-page typeset research article.
- `article.tex`: complete LaTeX source, with an embedded bibliography.
- `verify.py`: exact finite symbolic identity checks.
- `verification.txt`: the actual verification run; all 70 checks passed.
- `manifest.json`: file inventory, sizes, digests, and scope metadata.

## Main results developed in the article

The derivative is the distinguished Berarducci–Mantova scalar derivation,
normalized by d(omega) = 1. The unknown in each differential equation is a
scalar in a specified differential field, not an ordinary analytic function
of a real or complex coordinate.

Using the established ordinal log-atomic tower ell_alpha = omega^(omega^(-alpha)),
the report constructs the strong Hahn sum

    Q_alpha = (1/4) sum_{beta < alpha} (ell_beta' / ell_beta)^2.

For every set ordinal alpha and real constant c, the equation

    y'' + [Q_alpha + c (ell_alpha' / ell_alpha)^2] y = 0

has an explicit two-dimensional solution space in the surreal or surcomplex
field when c <= 1/4, and no nonzero scalar solution when c > 1/4.

At every nonzero limit ordinal, the same critical equation has solution-space
dimensions 0, 1, and 2 in three explicitly constructed nested, derivative-stable
real closed Hahn fields. Their algebraically closed complexifications have the
same dimension jump. The minimal solution-generated Picard–Vessiot extension
over the first complex field has the upper triangular Borel subgroup of
SL(2,C) as its differential Galois group.

The report also proves earlier-scale invisibility of a solvability-changing
perturbation, a no-final-stage statement, and a Schwarzian reformulation.
The first limit stage (alpha = omega) is worked out in Conway normal form.

## Mathematical and novelty status

This is a research draft with detailed proofs relative to explicitly cited
foundational theorems. It is not independently refereed or verified in a proof
assistant. No named published conjecture is claimed to be resolved.

The Berarducci–Mantova derivation, the ordinal log-atomic derivative formulas,
Hahn real closedness, the finite Euler threshold, and the surcomplex phase
obstruction are inherited inputs or mechanisms, not priority claims.
The transfinite combination and, especially, the explicit limit-stage
Hahn-field filtration and its differential Galois calculation are proposed
contributions. Appendix A records the literature and repository review and
its limits. Absence from all literature or from the complete repository is
not certified.

Repository reference point:

    VladimirReshetnikov/Surreal
    048b72cf7cbfc8ab246e4f73788c10460cb3f6e0

No repository modification was made.

## Build the PDF

Use a TeX distribution with the standard packages listed in `article.tex`.
From this directory:

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex
```

Alternatively, run `pdflatex -halt-on-error -interaction=nonstopmode article.tex`
repeatedly until cross-references stabilize. The bibliography is embedded;
no BibTeX run, external figures, or bundled font files are needed.

## Run the finite checks

Use Python 3.10 or later and SymPy. The included run records its exact Python
and SymPy versions. If SymPy is absent, install it in your Python environment:

```sh
python -m pip install sympy
python verify.py
python verify.py --output verification.txt
```

The script performs exact symbolic algebra, not floating-point sampling. It
raises an error and returns a nonzero exit status on a failed identity.
Its suites cover 39 finite hierarchy identities, 8 Euler identities, 4 gauge
identities, 4 Schwarzian identities, and 15 Picard–Vessiot matrix/group identities.

**These checks are not a verification of the infinite theorems.** They do not
construct all surreals, prove the imported derivative formula, certify Hahn
summability at transfinite stages, or establish bibliographic novelty. Those
obligations are addressed by the proofs and attributed sources in the article.
