# Polynomial-Composition Rigidity at Surreal Scales

**Weighted nonlinear equations, finite degree bounds, and omnific Diophantine universality**

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.tex`: self-contained LaTeX source, including bibliography.
- `article.pdf`: compiled article.
- `verify.py`: exact finite checks, using Python and SymPy.
- `verification.json`: the delivered run and its assertion counts.
- `SOURCE_AUDIT.md`: sources, repository pin, novelty boundary, and proof review.
- `BUILD_REPORT.json`: compilation and PDF inspection record.
- `requirements.txt`: Python dependency used for the checks.
- `Makefile`: build and verification commands.

## Main results

The article proves a strict composition-weight criterion for polynomiality of
strongly entire Hahn functions, valid for all nonzero set-sized ordered exponent
groups in characteristic zero. It also gives an explicit degree bound with
indicial resonances, a matrix version, and finite coefficient descriptions.

For ordinary integer or Gaussian-integer linear data, the degree bound and
Smith normal form give a complete parametrization of omnific polynomial
solutions. For nonlinear data, an explicit Euler-operator construction encodes
arbitrary polynomial coefficient equations while retaining a prescribed finite
degree bound. Classical Diophantine undecidability consequently survives inside
the rigid class, including a degree-at-most-ten subclass using Sun's published
eleven-variable result.

## Mathematical scope

The field is `K = k((t^Gamma))`, with `k` characteristic zero and trivially valued,
and `Gamma` a nonzero set-sized ordered abelian group. Strong entireness is
relative to that field and means Hahn summability of each evaluation family
before cancellation. Differentiation is in the function variable, fixes `K`,
and is not a derivation on surreal scalars.

Nonpolynomial strongly entire examples exist in many such fields, but not for
one countable Taylor series at every radius of the full proper class No. Also,
omnific-coefficient entire series are already polynomials for a simpler support
reason; the additional arithmetic content is the equation-specific degree bound
and the coefficient locus, not a new proof of that elementary observation.

## Reproduce

A current TeX Live installation with `newtx`, `amsmath`, `amsthm`, `mathtools`,
`microtype`, `tcolorbox`, `hyperref`, and `cleveref` is sufficient.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex

python -m pip install -r requirements.txt
python verify.py --output verification.json
```

Alternatively, run `make` and `make verify`.

The delivered run used Python 3.13.5 and SymPy 1.14.0 and passed 2,369 exact
assertions. It checks finite identities and examples, not arbitrary infinite
Hahn supports, peer-review status, historical priority, or Lean proofs.

## Repository comparison

Pinned revision:
`bcac55ae6fd3f2b354e568ba1d2e94d496a2cc59`

Repository: https://github.com/VladimirReshetnikov/Surreal

The inspected report guides and audits are listed in `SOURCE_AUDIT.md`.
The full repository and all historical manuscripts were not exhaustively
audited. No change was made to the repository.

## Status

This is an AI-assisted research manuscript with written proofs and finite
computational checks. It is not an independently refereed paper or a Lean
formalization. The proposed new contribution is the combined composition-weight,
resonance, and universal-encoding theorem package. Priority is not certified;
the ordinary complex entire-Mahler result and the classical undecidability
inputs are explicitly credited rather than presented as new.
