# Singular Curves over Omnific Integers

**Conductor differentials, a complete Hahn-rigidity criterion, and polynomial witnesses at every surreal scale**

Prepared for Vladimir Reshetnikov. AI-assisted mathematical research draft, 23 September 2026.

## Main result

Let k be a characteristic-zero field, Gamma a nonzero ordered abelian group,
and B the subring of the Hahn field k((t^Gamma)) consisting of series with
well-ordered support contained in the nonpositive exponents. For every
geometrically integral finite-type affine curve C over k, including singular
curves, the article proves the equivalence

    C(B) != C(k)  <=>  normalization(C) is A^1_k
                 <=>  a nonconstant polynomial map A^1_k -> C exists.

Existence is independent of the rank or divisibility of Gamma. Whenever a
nonconstant point exists, one exists with finite support on any prescribed
positive monomial scale. This is an existence/classification theorem, not a
claim that every Hahn point lifts to a B-valued point of the normalization.

The proposed addition to the supplied Surreal repository is the extension
from smooth curves to arbitrary curve singularities. The proof uses a finite
normalization conductor and Seidenberg's classical derivation identity;
neither the classical identity nor the prior smooth theorem is claimed new.

## Contents

- `article.pdf`: 20-page typeset article, including proofs, examples, eight
  research questions, verification boundaries, and a bibliography.
- `article.tex`: self-contained LaTeX source; bibliography is internal.
- `verify.py`: exact finite regression checks, using Python and SymPy.
- `verification.json`: recorded successful verification run.
- `build.sh`: reproducible PDF build command.
- `requirements.txt`: pinned Python dependency for the finite checks.
- `SOURCE_AUDIT.md`: source comparison, mathematical dependencies, and scope.
- `build_report.json`: typesetting and artifact checks.
- `SHA256SUMS.txt`: SHA-256 checksums of the other package files.

## Build the PDF

Use a TeX installation providing pdfLaTeX and the packages named in the source.
The source uses standard Latin Modern fonts, AMS mathematics, microtype,
hyperref, cleveref, geometry, fancyhdr, enumitem, booktabs, and longtable.
No separate bibliography processor or external image assets are required.

    bash build.sh

The script uses latexmk when available and otherwise runs pdfLaTeX three times.
On Windows, the equivalent direct command is

    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Run that command three times to resolve cross-references.

## Run the exact checks

Python 3.10 or later is required. The recorded run used Python 3.13.5 and
SymPy 1.14.0.

    python -m pip install -r requirements.txt
    python verify.py --output verification.json

The recorded run passed 113,940 finite assertions. Most come from testing
36,071 superelliptic multiplicity configurations against three related
formulas. Additional checks cover finite Taylor identities, exact Bezout and
normalization identities, finite Hahn arithmetic, and valuation inequalities.
These counts are NOT counts of independently verified mathematical theorems.

## Reading route

Section 1 states the main criterion. Sections 2-5 prove it. Section 6 gives
structural consequences. Section 7 classifies repeated-root superelliptic
examples; Section 8 gives a singular elliptic example with a seventh-order
certificate. Section 9 passes to omnific and Gaussian omnific integers.
Sections 10-12 state the boundaries, further research questions, and audit.

## Important boundaries

The main theorem assumes characteristic zero, constant coefficients,
geometric integrality, dimension one, and finite type. The extension to
all affine schemes of dimension at most one is stated over an algebraically
closed characteristic-zero field. Full surreal statements are made only
after reduction to set-sized Hahn workspaces.

The proofs have not been independently refereed or formalized in Lean.
Finite tests and clean PDF compilation do not establish the universal proof.
A targeted comparison did not locate the exact combined singular-Hahn
criterion in the material consulted, but historical novelty and priority
have not been established. This package does not assert a certified solution
to a named longstanding open problem.

Repository snapshot: bcac55ae6fd3f2b354e568ba1d2e94d496a2cc59.
