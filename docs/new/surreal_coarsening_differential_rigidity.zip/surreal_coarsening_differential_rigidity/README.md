# Coarsening Descent and Nonlinear Differential Rigidity

A 20-page research article prepared for Vladimir Reshetnikov, dated 22 September 2026.

## Files

- `article.pdf` — the typeset article.
- `article.tex` — complete standalone source with an internal bibliography.
- `SOURCES_AND_SCOPE.md` — repository comparison, source access, and novelty limits.
- `PROOF_AUDIT.md` — hypotheses, dependency chain, and sensitive proof steps.
- `verify.py`, `requirements.txt`, `verification.json` — exact finite checks and recorded output.
- `build.py`, `build_audit.json` — a portable build helper and the delivery's layout/build audit.

## Main results

Let K = k((t^Gamma)) have characteristic zero. Let E be the formal power series strongly Hahn summable at every point of this one K, and let M = Frac(E), viewed inside K((z)). The derivation is d/dz and kills all of K.

1. If the values of a subfield F of K lie in a proper convex subgroup of Gamma, then E intersect F[[z]] = F[z] and M intersect F((z)) = F(z).
2. If Gamma has no order unit, the elements of M differentially algebraic over K(z) are exactly K(z). The entire ones are exactly K[z]. This covers every finite differential order, including singular and nonlinear equations.
3. In the reverse-lexicographic group direct-sum_{m>=1} Q e_m, an explicit binary-prefix family of strongly entire series has all its jets jointly algebraically independent over the full Hahn constant field K(z). Over complex coefficients, dtrdeg(M/K(z)) equals the continuum.

The article also proves a meromorphic exclusion for Painleve I in this category, gives a finite rational ODE-system corollary, and interprets the constructions in an actual set-sized subfield of No[i].

## Relation to the repository

The inspected revision is:

`465a54b479a1ee842cbf7db1689a7d2f6bfe25e1`

The current holonomic report calls the nonlinear problem **Question 19.1**, label `hol:q:nonlinear`. Its source-10 audit refers to the older **Question 15.1**. The article answers the no-order-unit regime in all orders; it does not claim to settle the unrestricted higher-order case for groups with an order unit.

The companion entire-functions report already contains polynomial intersection obstructions for noncofinal workspace extensions. The meromorphic coefficient-field descent and its nonlinear consequences are the proposed additions here. Classical finite coefficient recurrences and valuation-rank arguments are not claimed new.

## Rebuild

Install a TeX Live or MiKTeX distribution containing New PX, AMS packages, microtype, geometry, fancyhdr, enumitem, needspace, tcolorbox, booktabs, tabularx, xurl, and hyperref. Then run, in this directory:

```text
python build.py
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times.

No bibliography processor, shell escape, external images, or network access is required during compilation once the TeX packages are installed. Font files are not distributed.

## Rerun the finite checks

Python 3.9 or later:

```text
python -m pip install -r requirements.txt
python verify.py --output verification-rerun.json
```

The delivered run passed eight check groups, comprising 8,673 finite cases. Most of the case count comes from binary-prefix comparisons; this is not a count of independently established mathematical theorems. The output records Python and SymPy versions.

## Verification boundary

The PDF was compiled successfully, all references resolved, and the final LaTeX log contains no warnings, overfull boxes, or underfull boxes. All 20 pages were rendered for visual review. The audit also checked extracted text boundaries for obvious clipping.

The arbitrary-support and infinite-family results are justified by the written proofs, NOT by the finite computations. No Lean verification or independent peer review has been performed. Historical priority is not certified. The exact mathematical category, valuation hypotheses, and derivation are essential; in particular, nothing here is asserted to be entire on the full proper class No[i].
