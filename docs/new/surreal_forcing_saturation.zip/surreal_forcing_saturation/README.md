# Forcing and Saturation of Surreal and Surcomplex Fields

**Subtitle:** Exact preservation criteria and a real-form dichotomy  
**Date:** 22 September 2026  
**Author line:** Research manuscript prepared with ChatGPT  
**Length:** 24 PDF pages, including title page, contents, and references

## Package contents

- `surreal_forcing_saturation.pdf`: the typeset article with linked contents,
  theorem references, and an embedded bibliography.
- `surreal_forcing_saturation.tex`: the complete LaTeX source.
- `verify_sign_code.py`: deterministic finite checks for the sign-code lemmas.
- `verification_results.txt`: the recorded output of those checks.
- `README.md`: these scope and build notes.

## Main results and conventions

Let M be an accessible transitive inner class model of ZFC inside V, with
all the ordinals of V. The paper works in an ambient class theory such as
GBC with Global Choice; all cardinalities and types are external, computed
in V, unless explicitly indicated otherwise. Its main theorem says that,
for every uncountable V-cardinal kappa, the old surreal ordered field
No^M is kappa-saturated exactly when V has no new ordinal-valued sequences
of length less than kappa over M. No regularity assumption on kappa is
required. The shortest new sequence has regular cardinal length delta
and yields an explicit omitted cut of exact character (delta, delta).

The omega endpoint is different: omega-saturation means saturation over
finite parameter sets, and for the old real closed field it is equivalent
to the absence of new reals. Countable-parameter saturation is
omega_1-saturation. These conventions matter in the Prikry example.

The old surcomplex field, in the pure field language, remains saturated
over every external set of parameters. Naming its canonical conjugation
recovers precisely the real-field obstruction. The article also proves a
first-birthday comparison, computes the invariants in three forcing
examples, and derives a class-isomorphism and nonconjugate-real-form
contrast. The new real forms have no set-sized cofinal subsets; their
obstruction is instead witnessed by bounded omitted cuts.

## Build

With a standard TeX distribution, run:

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode surreal_forcing_saturation.tex
```

Alternatively, run the following command repeatedly (normally three times)
until all references and the contents stabilize:

```sh
pdflatex -halt-on-error -interaction=nonstopmode surreal_forcing_saturation.tex
```

The source uses standard LaTeX packages, including amsmath, amsthm,
newtxtext, newtxmath, geometry, mathtools, microtype, xcolor, booktabs,
array, longtable, enumitem, fancyhdr, tocloft, hyperref, aliascnt, and
cleveref. No shell escape, external graphics, or BibTeX run is required.
Install any missing packages through the package manager of your TeX
distribution. No font files are distributed here.

## Finite checks and PDF verification

Run the checks with Python 3.10 or later:

```sh
python verify_sign_code.py
```

There are no external Python dependencies or network calls. The supplied
run passes 304,000 bounded checks, including comparison with exact dyadic
values, the two-bound prefix identity, decoding, nesting, and finite cone
intersections. These checks do not verify transfinite recursion, forcing,
class theory, or saturation. The mathematical proofs are in the article.

The final PDF compiled successfully with resolved references and no
LaTeX warnings or overfull/underfull box diagnostics. All pages were
rendered and their layouts inspected, with detailed inspection of the
title page, contents, code lemmas, comparison table, and bibliography.
This is a document-production check, not a mathematical proof certificate.

## Prior work, novelty, and limitations

Repository comparison is pinned to:

```text
VladimirReshetnikov/Surreal
4f2645599121fa872c7104995e47f86f0382351f
```

The article records the actual scope of the repository and literature
inspection. In particular, the existing automorphism manuscript already
contains class back-and-forth and a noncanonical real form with a
countable cofinal subset. Those results are explicitly credited as prior
work; neither is claimed as a discovery of this manuscript.

The relative-universe criteria, ordinal-block cut construction, and their
combined real-form consequences are proposed contributions not found in
the inspected material. This is not an exhaustive historical-priority
claim and not a claimed resolution of a named published open problem.
The paper supplies written proofs, not a peer-reviewed or Lean-certified
development. Its classical algebra, quantifier-elimination, saturation,
and forcing inputs are identified and cited. No full repository audit
or independent Lean build is claimed, and no repository files were changed.

The package contains no third-party papers or font files.
