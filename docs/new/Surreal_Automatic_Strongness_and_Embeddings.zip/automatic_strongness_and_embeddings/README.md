# Automatic Strongness and Proper Embeddings of the Omnific Integers

**Constant-term duality, full stabilizers, and the surreal–surcomplex boundary**

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.pdf` — the 24-page paper, with complete written proofs, bibliography,
  scope qualifications, and ten proposed research questions.
- `article.tex` — standalone LaTeX source, with an internal bibliography.
- `SOURCE_AUDIT.md` — repository/literature comparison and claim boundary.
- `verify.py` — deterministic finite checks using exact rational arithmetic.
- `verification.json` — actual output of the checks: 17,774 assertions passed.
- `Makefile` — build and check commands.
- `BUILD_AUDIT.json` — build, PDF, and file-integrity record.

## Main results

Theorem 5.5 proves that every unital ring automorphism of the omnific integers
extends uniquely to an R-linear, strongly additive ordered-field automorphism
of the surreal numbers. The proof reconstructs the constant projection from
the integer part, then uses constant-term pairings to detect Hahn summability.
Theorem 6.2 consequently applies the prior strong stabilizer factorization to
the entire real omnific stabilizer. Its admissibility qualifications remain.

Theorem 9.5 constructs proper, strongly additive embeddings J of No into No
with J^{-1}(Oz) = Oz and ct(J(x)) = ct(x), but J(b) = b + omega^{-1} for a
chosen transcendental real b. Their image intersects R in the kernel of the
chosen derivation. The image fails to supply all scalar pairing tests
(Corollary 9.7). These maps exhibit failure of coefficient rigidity for
embeddings, not a counterexample to strongness of all such embeddings.

Theorem 7.3 characterizes strong coefficient-field-linear maps of set-sized
full Hahn fields by constant-term adjoints; Theorem 7.4 gives canonical linear
retractions for strong field embeddings. Theorem 8.1 provides an explicit
proper-class obstruction to extending scalar representability to all of No.

Theorems 10.1 and 10.2 give surcomplex versions for valuation-preserving or
conjugation-compatible Gaussian-omnific automorphisms, respectively. No
unrestricted Gaussian valuation-preservation theorem is asserted.

## Status and provenance

This is an unrefereed research manuscript. It is not verified in Lean or any
other proof assistant. Finite checks are not proofs of infinite-support or
class-theoretic claims. No named published longstanding conjecture or
historical-priority certification is claimed.

The repository comparison is pinned to:

    a6c68ac3826ac337762b71a2ef901997d019260c

Prior work is expressly credited for the fraction-field identity, intrinsic
coefficient reconstruction, the strong admissible-character framework and
convex-support criterion, and finiteness-space support duality. The proposed
new central contribution is the automatic-strongness upgrade, together with
the embedding contrast and associated consequences. The comparison was
limited to the sources recorded in `SOURCE_AUDIT.md`, not every repository
file or all relevant literature.

## Build

A TeX Live installation with pdfLaTeX, latexmk, newtx, amsmath, amsthm,
mathtools, microtype, geometry, enumitem, needspace, hyperref, bookmark,
fancyhdr and the other standard packages imported in the preamble is enough.
No external bibliography processor, figures, font files, or network access
is needed by the source.

    make pdf

Alternatively:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Run a third pass if a cross-reference warning remains.

## Reproduce finite checks

Python 3.10 or later; no third-party packages are required.

    make check

or

    python verify.py --output verification.json

The checks use a fixed random seed and `fractions.Fraction`. They cover finite
triangular detection, weighted monomial adjoints, projection and tower laws,
nonmultiplicativity of a linear retraction, and Taylor block identities in a
lexicographic rank-two model, including formal reciprocal prefixes.

The derivation on all real numbers is chosen through a transcendence basis
in the mathematical proof. The program does not purport to construct it or
to encode arbitrary surreal numbers.
