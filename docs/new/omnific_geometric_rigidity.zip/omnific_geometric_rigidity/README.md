# Geometric Rigidity over Omnific Integer Rings

**Smooth curves, semiabelian varieties, and logarithmic differential certificates**  
AI-assisted research draft prepared for Vladimir Reshetnikov, 23 September 2026.

## Main contribution

The article gives a complete characteristic-zero rigidity argument for the
nonpositive-support Hahn ring A inside k((t^Gamma)), with no rank, divisibility,
finite-support, or countability assumption on the ordered exponent group.

Its central comparison puts the same differential contraction in the strictly
negative-support ideal I and in the Hahn valuation ring V. Since I intersect V
is zero, the contraction vanishes. A separating family of coefficientwise
Euler derivations turns this vanishing into constancy.

Principal results in the PDF:

- **Theorem 3.1 and Corollary 3.3:** all A-solutions of y^m=f(x), for m>=2 and
  squarefree f of degree >=2, are constant. In particular, every nonsingular
  Weierstrass equation over Z has exactly its ordinary integer solutions in
  the omnific integers. The analogous Gaussian statement also holds.
- **Theorems 4.3, 5.3, and 5.5:** logarithmic symmetric differential annihilation;
  semiabelian rigidity; and rigidity for varieties quasi-finite over a
  semiabelian variety.
- **Theorem 6.1:** over algebraically closed characteristic-zero k and nonzero
  Gamma, the only smooth connected curves with nonconstant A-points are the
  affine and projective lines.
- **Theorems 7.1, 8.1, and 9.1:** arithmetic descent, unimodular projective
  rigidity for positive-genus curves, and rigidity for ample cotangent bundles.
- **Proposition 10.1:** an explicit negative-support point on a smooth elliptic
  curve in characteristic two disproves the characteristic-free analogue.

## Contents

`article.tex` is the standalone LaTeX source, with an internal bibliography.
`article.pdf` is the compiled 24-page article.
`code/verify.py` performs exact finite algebraic checks.
`data/verification.json` is the recorded successful run.
`data/build_report.json` records compilation and PDF checks.
`PROOF_AUDIT.md` records the mathematical review boundary and sensitive steps.
`build.sh` and `build.ps1` rebuild the PDF.
`requirements.txt` pins the version of SymPy used for finite checks.
`CHECKSUMS.sha256` hashes the shipped files other than itself.

## Rebuild the PDF

A normal TeX Live or MiKTeX installation with pdfLaTeX and standard packages is
sufficient. No bibliography processor, network download, external image, or
external font file is needed. From this directory:

```sh
sh build.sh
```

On Windows with PowerShell:

```powershell
./build.ps1
```

Equivalently, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. The shipped build has no undefined references, overfull boxes,
underfull boxes, or LaTeX warnings.

## Reproduce finite checks

Python 3.9 or later and SymPy are required. The recorded run used Python 3.13.5
and SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

Printing does not overwrite the shipped report. To write another report:

```sh
python code/verify.py --output verification-rerun.json
```

All seven groups, containing 2,820 finite cases, passed. Most cases are simple
valuation-margin samples; the more substantive finite checks verify symbolic
polynomial identities, exact rank-two finite Hahn calculations, and
characteristic-two Frobenius telescoping. These computations do not verify the
infinite-support theorems or the algebraic geometry. Tests remain active under
Python's `-O` flag.

## Provenance and limits

Repository comparison is pinned to:

`934810abdde4c6d74c08777b069445de43602934`

https://github.com/VladimirReshetnikov/Surreal

The inspected omnific Diophantine README explicitly leaves the general
Weierstrass equation with a nonzero linear term outside its method. The present
article supplies an elementary proof and a general geometric explanation.
Appendix A gives the exact files and line ranges inspected.

The geometric package is a candidate-original research contribution, not a
certified priority claim. The full text of van den Dries's related 1981 paper
could not be inspected, and not every unintegrated repository companion was
read. The article has not received independent peer review or Lean verification.
It does not claim to settle a named longstanding conjecture, compute ordinary
integral points, classify singular curves, or decide arbitrary omnific
Diophantine equations.
