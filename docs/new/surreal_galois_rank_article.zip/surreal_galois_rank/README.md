# A Galois Rank Dichotomy for Omnific Fraction Fields

**Finite covers, independent radical towers, and collapse at a new surreal scale**

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT, 23 September 2026.

## Read the article

`galois_rank_dichotomy.pdf` is the 27-page article. Its standalone LaTeX source is
`galois_rank_dichotomy.tex`; the bibliography is embedded in that source.
The article includes complete written arguments relative to the classical inputs
identified in the bibliography, twelve further research directions, a dependency
ledger, and an audit of delicate proof steps.

The main contribution is a proposed Galois-theoretic extension of the repository's
cofinal support-descent theorem. The support theorem itself, the positive
closedness theorem without an order unit, and the classical geometric and Galois
mechanisms are expressly credited as prior work. Historical novelty has not been
certified. No independent referee review or proof-assistant verification is claimed.

## Main theorem package

For a nonzero ordered abelian group Gamma, let K_Gamma(k) be the full Hahn field
k((t^Gamma)), let B_Gamma(k) consist of its series whose supports are bounded above
in Gamma, and let F_Gamma(k) be the fraction field of B_Gamma(k).
These are also the fraction fields of the canonical real or Gaussian omnific
subrings with this prescribed exponent group. They are not, in general, the
full Hahn fields.

* **Rank dichotomy and finite groups (Theorems 4.2, 5.2, 7.2).** For divisible
  Gamma, F_Gamma(C) is algebraically closed exactly when Gamma has no order unit.
  If Gamma has an order unit, every finite group is realized as a Galois group
  over F_Gamma(C), inside K_Gamma(C). More strongly, every product of at most
  continuum many finite groups is realized there. The realization statements
  themselves do not require Gamma to be divisible.
* **Explicit towers (Theorems 6.3, 6.5, 8.1, 9.2).** Normalized binomial roots
  of 1-a*t^u have exact joint degrees and give a product of copies of the
  profinite integers. The polynomial X^m-X-t^u has Galois group S_m. Over the
  real fraction field a compatible radical tower gives a generalized-dihedral
  extension, with complex conjugation acting by inversion.
* **An exhaustive change-of-scale alternative (Theorem 10.3).** For an ordered
  inclusion Gamma into Delta with Gamma nonzero and divisible, cofinality
  preserves every finite complex extension and its degree; Galois groups and
  intermediate-field data are preserved. Noncofinality instead splits every
  finite extension after scalar extension to F_Delta(C). The induced map on
  absolute Galois groups is respectively surjective or trivial. The criterion
  is on exponent inclusions; the two group-map descriptions coincide when
  the old absolute Galois group is trivial.
* **Concrete surreal interpretation (Section 11, Theorem 11.1).** The root
  sqrt(1-omega^(-1)) is not a fraction of canonical omnific integers using only
  real exponents. It becomes such a fraction after adjoining omega to the
  exponent group. A countable tower repeats this phenomenon; each stage
  realizes every finite group, while the union is algebraically closed in the
  complex case and real closed in the real case.

These results concern named set-sized subfields of No and No[i]. They do not
assert nontrivial algebraic extensions of the full algebraically closed
surcomplex field. No named published conjecture is claimed solved.

## Contents

- `galois_rank_dichotomy.tex`, `galois_rank_dichotomy.pdf`: article and source.
- `SOURCE_AUDIT.md`: repository pin, actual scope of inspection, sources,
  prior-work boundary, proof checkpoints, and verification limitations.
- `code/verify.py`: deterministic exact finite regression tests.
- `code/build.py`: three-pass PDF builder; optional verification runner.
- `requirements.txt`: the SymPy version used for the finite tests.
- `data/verification_results.json`, `data/verification_console.txt`: recorded
  successful finite-check results.
- `data/build_audit.json`: final artifact and PDF validation facts.
- `MANIFEST.sha256`: integrity hashes for the other release files.

## Build

A TeX installation with pdfLaTeX and the packages named in the source is required,
including `newtxtext`, `newtxmath`, `aliascnt`, `cleveref`, `microtype`, and
`hyperref`. Fonts are supplied by the user's TeX installation; no font files are
included in this archive.

From the package directory, either run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error galois_rank_dichotomy.tex
```

or use the Python helper, which runs pdfLaTeX three times:

```sh
python3 code/build.py
```

The helper reports remaining LaTeX warnings and rejects unresolved references,
missing citations, or overfull boxes. It writes local build transcripts under
`data/`; these are not mathematical verification certificates.

## Run the finite checks

The verification script needs Python 3.10 or later and SymPy. The recorded run
used Python 3.13.5 and SymPy 1.14.0.

```sh
python3 -m pip install -r requirements.txt
python3 code/verify.py
```

To build and test in one command:

```sh
python3 code/build.py --verify
```

All **8,950 exact assertions in 18 test groups** passed. They check truncated
binomial identities, compatible radicals, finite support projections, polynomial
discriminants, local coefficient recurrences, Chinese-remainder idempotents,
finite symmetric groups, finite generalized-dihedral identities, and sample
lexicographic support shifts. They do not establish the infinite Hahn-support,
Riemann-existence, infinite Galois, or cardinality arguments. Those require the
written proofs and their cited mathematical inputs.

## Source and verification boundary

The repository comparison is pinned to:

```text
343dc2c471212bb9b53ff4623bace2e1943f255b
```

Selected guides, metadata, and source audits were read through the connected
GitHub reader. The full repository was not cloned or built; its full collection
of manuscripts was not audited. The decisive prior report is
`docs/surreal/transcendence-over-bounded-support/README.md`, especially its
statements of Theorem 3.2, Corollaries 3.3–3.4, Theorem 7.1, Corollary 7.2, and
Section 8.4. The needed support arguments are reproved in the article, rather
than importing uninspected proofs. Consult `SOURCE_AUDIT.md` for the exact
contribution boundary.
