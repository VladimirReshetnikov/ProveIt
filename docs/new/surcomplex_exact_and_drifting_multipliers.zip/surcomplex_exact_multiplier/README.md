# Exact and Drifting Multipliers in Surcomplex Dynamics

**Sharp common-domain linearization and a cyclic-workspace obstruction**  
Research manuscript prepared with ChatGPT, 22 September 2026.

## Main results

For an irrational rotation multiplier lambda, define

    tau = limsup_n log^+(1 / |lambda^n - 1|) / n.

1. **Exact scalar multiplier.** If every positive Hahn coefficient of
   F(z) - lambda z has zero constant and linear terms and is holomorphic
   on a common polydisk of radius R, then, when tau is finite, the
   normalized conjugacy and its inverse have all coefficients holomorphic
   on the same polydisk of radius R exp(-tau). The guarantee is optimal.
   This holds in every finite complex dimension for lambda times the
   identity, over every nonzero set-sized ordered abelian value group.

2. **Drifting multiplier, one cyclic scale.** For

       F_epsilon(z) = (lambda + epsilon) z + epsilon z^2/(1-z/R),

   the coefficient of epsilon^m in the normalized conjugacy to the
   actual multiplier lambda + epsilon has radius exactly R exp(-m tau)
   when 0 < tau < infinity. Thus each coefficient converges, but no
   positive disk works for all of them. The proof controls all terms
   that collide after two auxiliary parameters are identified.

The fixed-depth small-divisor estimate and the pole noncancellation
argument are proved in the article. They address the exact-scalar
subcase and the fixed-cyclic-workspace question in the repository's
specified research report. The general nonscalar diagonal-multiplier
problem is not resolved.

## Contents

- `article.pdf`: 24-page article, including complete proofs of the new
  claims, precise categories, sharp examples, actual surcomplex halo
  realizations, limitations, and references.
- `article.tex`: standalone LaTeX source; internal bibliography.
- `code/verify.py`: finite exact checks over the Gaussian rationals.
- `data/verification.json`: supplied record of the successful check run.
- `data/build_report.json`: build and PDF validation record.
- `SOURCE_AUDIT.md`: source scope, pinned repository questions, claim ledger,
  and limits of the novelty assessment.
- `requirements.txt`: the tested SymPy version.
- `build.sh`: rebuild the PDF with latexmk.

## Build the PDF

Use a TeX Live or MiKTeX installation providing the standard packages in
`article.tex`, including `latexmk`, `amsmath`, `amsthm`, `aliascnt`,
`hyperref`, and `cleveref`.

```sh
./build.sh
```

Equivalent command:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The document needs no external bibliography, graphics, shell escape,
or network access to compile.

## Run the exact checks

The supplied run used Python 3.13.5 and SymPy 1.14.0. The script is intended
for Python 3.10 or newer with SymPy installed.

```sh
python code/verify.py --output data/verification-rerun.json
```

An existing output path is rejected unless `--overwrite` is supplied.
Use a fresh output path to preserve the original evidence. Running the
script without `--output` prints the report rather than creating one.

The tests check finite polynomial identities, parameter collisions,
reciprocal coefficients, and combinatorial packing. They do not prove
analytic radii, irrationality, infinite Hahn summability, asymptotic
limits, universal quantifiers, or novelty. These points are handled by
mathematical proofs or explicitly disclaimed in the article.

## Baseline and status

Repository: `VladimirReshetnikov/Surreal`.
Frozen commit: `a3124af79f66b8b9c196d76b4cbc5ac3938907c4`.
Relevant report: `docs/surcomplex/dynamics-and-normal-forms/article.tex`.

This is an unrefereed research manuscript with proposed results and
proofs, not an independently certified priority claim. No Lean or other
proof-assistant formalization is supplied. No source repository files
were changed. Ordinary complex specialization of a positive Hahn
parameter, global all-surcomplex analyticity, and internal surreal
(Berarducci–Mantova) differentiation are not asserted.
