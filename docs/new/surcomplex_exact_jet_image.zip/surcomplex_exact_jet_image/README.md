# The Exact Infinite Jet Image over Surcomplex Hahn Fields

Shellwise Hermite interpolation, sharp Bezout criteria, and explicit residue
fields at infinity. Research manuscript prepared for Vladimir Reshetnikov,
September 22, 2026. The PDF has 22 pages including the title and contents.

## Contents

- `article.tex`: standalone LaTeX source with an embedded bibliography.
- `article.pdf`: compiled article.
- `verify.py`: exact finite algebra and ordered-group checks, standard library only.
- `checks.json`: the delivered record of 1,958 passing checks.
- `build_report.json`: compilation and PDF-review record.
- `README.md`: this guide.

## Main contribution

For a radially finite divisor in a fixed full Hahn field C((t^Gamma)), group
nodes by valuation shell. Normalize a shell of radius rho_n to valuation zero
and form its finite Hermite interpolation polynomial R_n. Define

    V_n = {x : v(x) >= -m*rho_n for some finite nonnegative integer m}.

The complete infinite prescription has a strongly entire interpolant exactly
when the coefficients of R_n belong to V_n for all sufficiently large n.
The number of nodes and the finite jet orders need not be uniformly bounded.
For one value per shell this reduces to eventual membership of that value in V_n.

Theorem 4.1 proves the criterion. Theorem 5.3 identifies the quotient by the
canonical product as an algebraic restricted product. Theorem 6.3 gives the
sharp Bezout criterion. Theorem 7.3 treats extremely close pairs with 0/1
values. Theorem 8.1 constructs explicit non-evaluation maximal ideals and
ultraproduct residue fields.

## Scope and status

The new image theorem addresses the gap described in the repository report
`docs/surcomplex/entire-functions-at-arbitrary-rank`, at commit
`a3124af79f66b8b9c196d76b4cbc5ac3938907c4`. The existing coefficient criterion,
canonical-product background, order-unit interpolation, and the repository's
non-Bezout pair are credited rather than claimed as new.

This is a proposed original research contribution with detailed proofs,
not a claim to have solved a named published conjecture. Priority is not
certified. No independent refereeing or Lean verification is claimed.
The theory concerns a fixed set-sized Hahn workspace, not a nonpolynomial
power series entire on the whole proper class No[i].

Finite checks do not prove infinite summability, interpolation, nonexistence,
or the ultrafilter theorem. The article makes the boundary explicit.

## Reproduce

Python 3.10 or later, standard library only:

    python3 verify.py --output checks-rerun.json

The script refuses to overwrite an existing output. Its arithmetic is exact
and its random seed is fixed. A second run during preparation reproduced
the delivered JSON exactly.

For the PDF, use an ordinary TeX Live or MiKTeX installation with latexmk:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

No network access, external figures, shell escape, BibTeX, or repository
checkout is required. Standard packages include the AMS packages, lmodern,
mathrsfs, geometry, microtype, booktabs, tabularx, xcolor, fancyhdr, enumitem,
needspace, hyperref, and bookmark. The delivered build has no LaTeX warnings,
undefined references, undefined citations, or overfull/underfull boxes.
