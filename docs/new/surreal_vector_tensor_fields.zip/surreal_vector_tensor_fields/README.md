# Three-Dimensional Surreal Vector and Tensor Fields

**Support-controlled differential geometry, integral theorems, and multiscale continuum equations**

Article dated 22 September 2026. Prepared for the request to develop a theory of
three-dimensional vector and tensor fields with surreal components.

## Files

- `surreal_vector_tensor_fields.pdf`: the compiled 33-page article.
- `surreal_vector_tensor_fields.tex`: self-contained LaTeX source, with its
  bibliography included. No separate bibliography or image assets are required.
- `verify_examples.py`: finite, exact symbolic checks using SymPy.
- `verification_results.txt`: recorded execution of the verification program.
- `README.md`: this guide.

## Mathematical framework

The main analytic model is a Hahn series of ordinary smooth fields with one
well-ordered scale support. A fixed set-sized divisible exponent group supplies
an actual surreal realization through t^gamma = omega^(-gamma). The article
also develops polynomial/rational fields on genuine surreal coordinate domains,
Taylor-halo evaluation, and affine charts with infinite or infinitesimal scales.

The development includes vector and tensor algebra, spatial derivatives,
exterior calculus, regular Hahn metrics, curvature, compact-chain Stokes,
polynomial-chain integration, potentials, de Rham cohomology, ordinary-background
and regular-metric Hodge decompositions, exact linear inverses, and a quadratic
lifting theorem. Applications include infinitesimally forced stationary
incompressible flow on the three-torus, Maxwell conservation identities,
elasticity, stress, scale connections, monopole flux, and distributional sources.

The article carefully distinguishes this calculus from arbitrary pointwise
surreal-valued functions, from ordinary fine-topological integration, and from
a scalar surreal derivation. Singularly scaled evolution and degenerating
leading metrics have explicit counterexamples and stated boundaries.

## Repository provenance

The inspected repository is `VladimirReshetnikov/Surreal`, pinned to commit:

    d22a5b35d5b3040e870c3cfd6d1c8f7259e094b0

The inspected root README, documentation catalogue, and contours/Stokes README
are identified in the article. Existing repository results are not presented as
new discoveries. The bibliography links to the pinned repository and to primary
mathematical sources. No repository changes were made.

## Build the PDF

Use a TeX distribution containing the standard `newtx`, AMS, `mathtools`,
`microtype`, `geometry`, `booktabs`, `hyperref`, `bookmark`, `fancyhdr`,
`enumitem`, and `listings` packages. From this directory run:

    pdflatex -interaction=nonstopmode -halt-on-error surreal_vector_tensor_fields.tex
    pdflatex -interaction=nonstopmode -halt-on-error surreal_vector_tensor_fields.tex
    pdflatex -interaction=nonstopmode -halt-on-error surreal_vector_tensor_fields.tex

The repeated runs resolve the table of contents and cross-references. Alternatively:

    latexmk -pdf surreal_vector_tensor_fields.tex

No external program execution, network connection, or shell escape is needed.
The delivered PDF was built with pdfTeX 1.40.26. Its final compilation had no
undefined references or overfull/underfull box warnings. The rendered pages were
reviewed for layout.

## Run the finite checks

Requires Python 3.10 or newer and SymPy. Tested with Python 3.13.5 and SymPy 1.14.0.

    python -m pip install sympy
    python verify_examples.py

To regenerate the recorded output:

    python verify_examples.py > verification_results.txt

All 11 check groups passed. They cover finite vector identities, anisotropic
cross products, differential identities, box flux, radial potentials, conformal
curvature computed from Christoffel symbols, scale-connection defects, elastic
energy, a Beltrami field, the quadratic/Catalan recursion through degree 12,
softened monopole density, and the final worked field.

## Evidence and limitations

The checks are regression tests of finite identities and examples. They do not
prove infinite Hahn summability, operator existence, nonlinear lifting, or Hodge
theory. Written mathematical proofs and explicitly cited real/scalar theorems
provide the basis for those parts of the article.

This is a research exposition, not a claim of peer review, established priority,
or completed formal verification. No Lean source or Lean-checked proof is
included. The formalization section proposes an architecture rather than an
implemented extension. The physics examples establish mathematical identities,
not experimental validation or resolution of physical singularities.
