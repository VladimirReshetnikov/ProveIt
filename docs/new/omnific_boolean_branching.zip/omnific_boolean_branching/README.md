# Proper-Class Boolean Branching in the Normalization of the Omnific Integers

**Support-local integrality, uniform splitting, and the limits of small arithmetic representations**

OpenAI ChatGPT, prepared for Vladimir Reshetnikov, 23 September 2026.

## Main contribution

Let N_R be the integral closure of the omnific integers in No, J the ideal of
purely infinite omnific integers, and B_R = N_R / JN_R. The preceding
normalization draft described B_R as a finite-partition Boolean power of the
ordinary complex algebraic integers, but left the Boolean algebra open.

This article proves a uniform splitting theorem: every set-sized unital
subring R of B_R has an idempotent e such that re and r(1-e) are both nonzero
for every nonzero r in R. Consequently:

- Idem(B_R) is atomless, is a proper class, and has no set-sized order-dense subset.
- For every set I, the free idempotent-variable R-algebra embeds in B_R.
- An explicit ordinal-indexed family of independent idempotents is given.
- Every nonzero finite idempotent matrix splits into two nonzero orthogonal parts.
- All countable-domain branch maps jointly detect the quotient, but no set-indexed
  family of maps to set-sized rings does so. Every such family misses a nonzero
  idempotent. Prescribing a branch on a set of elements never fixes it uniquely.

The proof uses exact support-group descent for integrality and radical ideal
membership, followed by two independent quadratic specializations at a new
dominant scale. It also yields a set-sized Hahn-field rank-extension theorem
and an exact criterion for rational functions of one surreal monomial.
The surcomplex normalization inherits the branching results via integral doubling.

## Files

- `article.tex`: standalone LaTeX source, with its bibliography.
- `article.pdf`: compiled 24-page article, including title page and references.
- `verify.py`: exact finite symbolic diagnostics, requiring SymPy.
- `verification_results.json`: actual diagnostic output; 6,674 assertions passed.
- `PROOF_AUDIT.md`: key proof obligations, independent checks, and limitations.
- `SOURCE_AUDIT.md`: repository pin, antecedents, and novelty boundary.
- `BUILD_REPORT.json`: compilation and rendering audit.
- `Makefile`: build, diagnostic, and cleanup targets.
- `requirements.txt`: the SymPy version used for the recorded diagnostics.

## Reproduce

A TeX installation needs the packages named in the source preamble, including
AMS mathematics, Latin Modern, microtype, hyperref, cleveref, aliascnt, and
booktabs. No bibliography processor is required.

```sh
python3 -m pip install -r requirements.txt
python3 verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, `make` builds the PDF and `make check` runs the finite checks.
Without latexmk, run pdflatex repeatedly until the references and contents
stabilize. The diagnostic run used Python 3.13.5 and SymPy 1.14.0. The script
uses syntax compatible with Python 3.10 and later; other environments were
not separately tested.

## Evidence and scope

The article contains complete written proofs of its stated results relative
to the classical surreal normal-form and set-cut theorems, ordinary finite
algebra, and its explicit Godel–Bernays plus global-choice convention.
The antecedent normalization and small-image results needed for the argument
are reproved, not accepted merely because an earlier AI-assisted draft says so.

The finite code checks polynomial identities, branch assignments, finite Boolean
tables, finite support projections, and initial Laurent coefficients. They do
not verify the complete proof, arbitrary Hahn supports, or class/set arguments.
There is no Lean formalization, repository build, or claim of peer review.

The resolved Boolean questions are those explicitly posed in the preceding
normalization research draft. This is not a claimed solution of a named
classical factorization conjecture. Historical priority has not been established.
The full isomorphism type of the Boolean class, local radicality in every fixed
workspace, and general effective normalization membership remain open here.
