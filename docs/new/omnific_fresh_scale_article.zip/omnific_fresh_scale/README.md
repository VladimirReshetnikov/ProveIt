# Fresh-Scale Image Gaps and Rational Rigidity for Omnific Integers

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Files

- `omnific_fresh_scale.pdf`: typeset article, with complete proofs and references.
- `omnific_fresh_scale.tex`: standalone LaTeX source; bibliography is embedded.
- `verify_finite.py`: deterministic exact finite-algebra regression checks.
- `verification_results.txt`: the supplied successful verification run.
- `requirements.txt`: the SymPy version used for that run.

## Principal results

For a set-sized Hahn coefficient field K_G and a fresh surreal exponent b
larger than every member of G, t = omega^b separates formal Laurent powers
into disjoint support blocks. The article proves:

1. For every polynomial f of degree at least two,
   f(A_D) intersect (f(t) + K_G) = {f(t)}, where A_D = D + P_k and P_k is
   the class of normal forms supported on strictly positive exponents.
   Each root of f(Y) = f(t) + c, c != 0 in K_G, has a nonzero forbidden
   negative block among the first degree(f)-1 layers. Its coefficient is
   computed from a finite centered-polynomial defect.
2. Exact fresh fibers are described by the roots of unity preserving the
   centered polynomial, together with an explicit constant-term/support test.
3. Surjective rational self-maps of the real omnific integers are precisely
   +/-X+a. On Gaussian omnific integers they are uX+a, for
   u in {1,-1,i,-i}. Nonlinear polynomial self-maps omit a proper class of values.
4. Constant-ring transfer describes all integer-valued polynomial operations.
   For real omnific polynomials, a finite lower-set grid is an optimal test.
5. Rational maps admit finite coefficient-workspace-dependent certificates,
   but no set-sized coefficient-independent sample works, even for globally
   pole-free functions of numerator degree 0 and denominator degree 1.
6. A rational function that preserves the integer ring outside a set of
   exceptions preserves it everywhere.

The real case is k=R, D=Z. The Gaussian case is k=C, D=Z[i]. A positive
exponent need not be an ordinary positive real. Freshness means domination
of the entire coefficient exponent group, not merely of finitely many
leading terms.

## Status and provenance

These are written mathematical proofs in an unrefereed research manuscript.
The principal proposed new contributions are the quantitative image-gap and
fresh-fiber results and the scale-sensitive testing package. Novelty has not
been certified by an exhaustive literature review.

Newton/binomial interpolation is classical. Rational-to-polynomial collapse
has a classical D-ring precedent; the article explicitly credits it and does
not present that basic phenomenon alone as new. No named longstanding open
conjecture is claimed to have been resolved.

The finite verification run passed 1,354 exact assertions, including 150
centered defect cases and 22 formal inverse branches. These checks do not
verify arbitrary Hahn supports or proper-class reasoning. No Lean build or
formal proof of this manuscript was performed.

Repository inspected:
https://github.com/VladimirReshetnikov/Surreal
Snapshot: 71e9606d297c9b98c732070dc462682cc6948981

The repository was not modified. The catalogue and normal-form bridge were
reviewed; this was not an exhaustive audit of all repository mathematics.

## Rebuild the PDF

A standard TeX Live or MiKTeX installation with pdfLaTeX and the packages used
in the preamble is sufficient. No external figures, proprietary fonts, or
bibliography database are needed.

    pdflatex -interaction=nonstopmode -halt-on-error omnific_fresh_scale.tex
    pdflatex -interaction=nonstopmode -halt-on-error omnific_fresh_scale.tex
    pdflatex -interaction=nonstopmode -halt-on-error omnific_fresh_scale.tex

Or use:

    latexmk -pdf omnific_fresh_scale.tex

## Re-run finite checks

Python 3.9 or later is intended. The supplied run used Python 3.13.5 and
SymPy 1.14.0. Run:

    python -m pip install -r requirements.txt
    python verify_finite.py

The script writes `verification_results.txt` beside itself. An alternative
output path can be supplied with `--output`.

## Reading route

Sections 2-3 establish the support machinery. Sections 4-6 contain the
image-gap, fiber, and rational-surjectivity results. Sections 7-9 develop the
polynomial/rational testing contrast. Section 10 contains explicit cubic and
quartic computations; Section 11 discusses scope and further questions.
