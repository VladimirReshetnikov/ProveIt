# Infinite Surcomplex Spectral Synthesis

**Hahn-orthonormal bases, exact resolvents, and sharp graph-locality bounds**

Research draft prepared with ChatGPT, September 22, 2026.

## Files

- `article.pdf`: the complete typeset article.
- `article.tex`: standalone LaTeX source, including its bibliography.
- `code/verify.py`: exact finite symbolic verification using SymPy.
- `data/verification.json`: recorded results, including every check.
- `PROVENANCE.md`: repository pin, literature comparison, and scope.
- `build.sh`: PDF build command.
- `requirements.txt`: the SymPy version used for verification.

## Main results

For a set-sized ordered abelian group Gamma and pairwise distinct ordinary
real labels d_i, the article studies A = diag(d_i) + B in

    RCF_I(C)((t^Gamma)),

where every Hahn coefficient matrix is row- and column-finite and B is
Hermitian with one globally well-ordered positive support. The algebra acts
on C^(I)((t^Gamma)): vectors have finite-support coefficients, not necessarily
finitely many nonzero Hahn coordinates.

The article proves a unique near-identity normalized Hahn-unitary
diagonalization, exact vectorwise spectral synthesis, a full commutant and
spectral-projection classification, and coherent resolvents at every
noneigenvalue. It also proves weighted-walk dependence, marked-edge
stability, coefficientwise finite-section exactness, and a sharp order
2r+2 boundary threshold for one-scale locally finite graphs.

There is no uniform ordinary spectral-gap assumption and no divisibility
assumption on Gamma. There *is* a simple ordinary residue hypothesis and a
global Hahn support condition. Counterexamples show that these cannot be
silently replaced by an assertion about arbitrary positive infinite matrices,
arbitrary entrywise Hahn matrices, or bounded Hilbert-space operators.

## Research status

This uses the "new theorems" alternative of the request. It does not claim
to settle a named published open problem. The combined infinite-dimensional
support-controlled theorem package is offered as a candidate original
contribution; priority is not certified. Classical perturbation recursions,
Higman's and Neumann's support tools, and matrix-walk correspondences are
explicitly credited. The proofs have not been independently refereed or
formalized in a proof assistant.

No change was made to the GitHub repository.

## Build the article

A standard TeX Live installation with latexmk and the packages listed in the
preamble is sufficient. There are no external figures or bibliography files.

```sh
./build.sh
```

Equivalently:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

## Reproduce the checks

The included run used Python 3.13.5 and SymPy 1.14.0 and passed **218/218**
exact checks. The program supports Python 3.10+.

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

The script raises an exception at the first failed check and otherwise writes
`data/verification.json`. Checks are finite symbolic identities, not proofs
of the infinite-dimensional theorem. The two-scale test uses finite
bidegrees, not an allegedly finite initial segment of a lexicographic
valuation group.
