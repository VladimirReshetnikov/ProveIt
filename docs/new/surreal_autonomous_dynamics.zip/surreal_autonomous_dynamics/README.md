# Derivation-Independent Autonomous Dynamics over the Surreal and Surcomplex Numbers

Research manuscript prepared for the VladimirReshetnikov/Surreal project.
September 22, 2026.

## Files

- `article.tex`: self-contained LaTeX source, including bibliography.
- `article.pdf`: compiled article.
- `verify.py`: exact symbolic finite checks (Python and SymPy).
- `verification.txt`: actual output from the default verification run.
- `sources.md`: literature and repository-review scope.
- `build.sh`: rebuild the PDF and run the checks.

## Main results

For a normalized strongly additive surreal derivation D with D(omega)=1,
constant field R, exponential compatibility, and the H-field sign rule, the
paper classifies all nonconstant surcomplex realizations of a meromorphic
vector field on a smooth projective complex curve.

All such solutions reduce to ordinary zeros of the vector field. A simple
zero contributes trajectories exactly when its linear coefficient is negative
real. A zero of order m+1 >= 2 contributes m complex one-parameter branches,
all expressible by formal power series in omega^(-1/m) and log(omega)/omega.

All solutions of a fixed equation lie in a single set-sized differential Hahn
field with a finitely generated monomial group. All normalized surreal
derivations agree on this field. This yields equality of the solution sets
of F(y,Dy)=0 for every F in C[Y,Z]; for nonzero F the derivatives themselves
agree at every solution.

Additional results give a squarefree hyperelliptic nonexistence theorem and
the exact logarithmic-derivative image of every constant abelian variety.
The latter is formulated for all normalized derivations; its explicit
primitive obstruction uses surjectivity, in particular the
Berarducci–Mantova derivation.

## Status and limits

The article supplies mathematical proofs. It is not peer-reviewed or
Lean-verified. No named published open problem is claimed solved, and no
exhaustive priority certificate is claimed. Classical formal normal forms,
Hahn-series machinery, and the published construction of surreal derivations
are identified as inputs. The proposed contributions concern their precise
ambient realization, exhaustive support localization, derivation-independence,
and abelian image consequences.

The verification program checks exact finite identities and a degree-four
formal implicit expansion. Those tests passed in the recorded environment;
they do not validate the general mathematical proofs or their novelty.

The derivative is the algebraic surreal derivation, not the derivative of an
arbitrary fine-topological class function. All infinite evaluations use Hahn
summability, not fine-topological convergence. The finite monomial-generation
bound is not a finite transcendence-degree bound. The theorem on constant
curves does not extend here to arbitrary higher-order equations, variable
coefficients, or higher-dimensional nonlinear systems.

## Rebuilding

The source uses standard pdfLaTeX packages (amsmath, amsthm, mathtools,
geometry, lmodern, microtype, hyperref, fancyhdr, enumitem, and booktabs).
No external images or separate bibliography file are required.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
python3 verify.py > verification.txt
```

The Python script requires SymPy. The recorded environment was Python 3.13.5
with SymPy 1.14.0. It accepts `--degree N` for N between 2 and 7. Larger
orders may take longer; the default is 4.

Alternatively, execute `sh build.sh` from this directory.
