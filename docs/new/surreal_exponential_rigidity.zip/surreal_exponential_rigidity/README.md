# Exponential Rigidity from Valuation Data

**A negative answer to Kaplan–Krapp–Serra Question 5.4, with surcomplex and differential extensions**

Research manuscript dated 22 September 2026. The PDF is 17 pages.

## Main result

A unital field endomorphism sigma of the surreal numbers is the identity if
it fixes the natural valuation pointwise and commutes with the usual surreal
exponential. In particular, there are no nonidentity exponential field
1-automorphisms. Neither strong additivity nor real-linearity nor
surjectivity is assumed.

The source question is Question 5.4 on page 10 of Kaplan, Krapp, and Serra,
*Decomposing the automorphism group of the surreal numbers*,
arXiv:2509.22374v3 (23 April 2026). The article cites the version inspected.
The proof is not a numerical experiment: exponential compatibility forces
all displacements into the finite ring, and a finite field identity rules
out globally bounded nonzero displacement.

## Contents

- `exponential_valuation_rigidity.pdf`: the article.
- `exponential_valuation_rigidity.tex`: self-contained source, with internal bibliography.
- `code/verify.py`: exact, standard-library-only finite algebra checks.
- `verification.json`: recorded output from the default check run.
- `SOURCE_AUDIT.md`: source/version audit and limits of the novelty claim.
- `Makefile`: build, check, and cleanup commands.

The article proves the main answer, faithful value-group action, profile
rigidity on final intervals, cofinal exponential commutation defects, an
unbounded-valuation-loss theorem for compatible derivations, and the
identity/conjugation kernel theorem for the specified surcomplex real-form
structure. It includes complete proofs, boundary examples, class-foundation
bookkeeping, and a compact independent proof audit.

## Build

Use a conventional TeX installation providing pdfLaTeX, newtx, amsmath,
amsthm, mathtools, geometry, microtype, enumitem, fancyhdr, and hyperref.
No BibTeX run or external image files are needed.

```sh
make pdf
```

Or run this command three times from the directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error exponential_valuation_rigidity.tex
```

The delivered build has no undefined references, LaTeX warnings, or overfull
boxes. All pages were rendered, with a contact-sheet review and detailed
inspection of the title and central theorem pages. Renderings and build
intermediates are not included in the archive.

## Reproduce the finite checks

Requires Python 3.10 or later, with no external Python packages.

```sh
python code/verify.py --output verification-rerun.json
```

The default seed is 20260922. The default run passes 6,132 named checks:
two universal polynomial identities, two inverse-composition checks through
order 48, 128 leading-displacement formula checks, and six check families
on 1,000 deterministic randomized examples. The script correctly retains
guard coefficients when multiplying truncated Laurent substitutions.

```sh
python code/verify.py --seed 42 --samples 2000 --output verification-seed42.json
```

The code checks finite identities and examples, not arbitrary surreal
numbers, proper-class maps, arbitrary-rank valuations, or the general
logical implications in the article. No proof assistant verification is
claimed, and no Lean implementation is included. Optimized Python mode
(`python -O`) is rejected.

## Scope and status

This is an unrefereed, AI-assisted manuscript prepared for the Surreal
research project; no external person is represented as having reviewed or
endorsed its proofs. The named question is explicitly present in the
inspected source version. An exhaustive historical-priority search has not
been established. The elementary bounded-image lemma is not itself claimed
as a new general lemma.

“Fixing every value” is stronger than merely preserving valuation
comparisons. The theorem proves uniqueness from value-group action, not a
classification of which value-group actions extend. The surcomplex kernel
statement requires the chosen real form and conjugation, and imposes
exponential compatibility only on the real form. It does not assume or
construct a total surcomplex exponential.

The source repository was read but not modified. No third-party papers or
font files are included.
