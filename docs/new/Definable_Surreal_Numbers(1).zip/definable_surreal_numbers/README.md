# Definable Surreal Numbers and Omnific Integers

**Ambient truth, bounded coding, and the maximal initial core**  
Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `definable_surreals.pdf`: the complete typeset article.
- `definable_surreals.tex`: standalone LaTeX source, including its bibliography.
- `SOURCE_AND_PROOF_AUDIT.md`: scope, dependencies, novelty qualifications, and proof status.
- `verify_finite.py`: exact finite regression checks; Python standard library only.
- `verification.json`: output of the actual verification run.
- `Makefile`: optional build and verification targets.

No bibliography database, external figures, proprietary fonts, shell-escape step, or network access is needed to build the article.

## Main results

The manuscript distinguishes ambient set-theoretic definability, intrinsic definability in a specified surreal structure, and ordinal definability.

Its central proposed contributions are:

1. A parameter-free ambient-definable order embedding of all surreals into monomial omnific integers between 0 and omega, with a definable inverse on its image. There is a local version in every infinitely wide omnific interval.
2. A uniformly definable family of omnific integers between 0 and omega whose birthdays exceed any prescribed ordinal, and a bounded noncollection theorem for internally definable sets.
3. An explicit normal-form encoding of an arbitrary subset of an ordinal, demonstrating two distinct failures of pointwise definitions of a “definable series.”
4. A maximal initial elementary exponential core: when rho is the first externally identified ordinal not definable over a transitive model M from A, rho is an epsilon number and the core is D_M(A) intersected with No of birthday below rho.
5. Explicit birthday-controlled denominators proving that the core is the fraction field of its own omnific integer part. The core contains every term, coefficient, and exponent of each of its normal forms.

Further material covers valuation and residue fields, OD/HOD, bounded tests for pointwise definability and V=HOD, language dependence, finite omnific quotients, non-Noetherian behavior, and the limits of transferring full-class results to externally set-sized fragments.

## Build

With a standard LaTeX installation containing the packages listed in the preamble:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error definable_surreals.tex
```

Without latexmk, run the following command three times to resolve contents and references:

```sh
pdflatex -interaction=nonstopmode -halt-on-error definable_surreals.tex
```

Run the independent finite checks with:

```sh
python3 verify_finite.py --output verification.json
```

On systems naming the interpreter `python`, substitute that executable. The optional `Makefile` provides `make`, `make verify`, and `make clean`.

## Semantic and verification boundaries

The main semantic setting is an externally fixed transitive set model M of ZFC, with standard first-order formulas and finite tuples from an allowed external parameter set A. The article does not assume an internal truth predicate and does not assert that ZFC proves the existence of such a transitive model.

The new results have written mathematical proofs, not Lean-checked proofs. Finite computations do not verify the transfinite or model-theoretic theorems. Literature searches and repository comparisons support the novelty qualifications in the article, but do not establish priority. In particular, Hamkins's 2012 density/HOD theorem and the repository's earlier birthday, topology, and full-class quotient results are explicitly credited rather than claimed as new.

Repository comparison snapshot:
`9a385d3957bdfe3d9ea79f9a524751c90bd2c894`.
