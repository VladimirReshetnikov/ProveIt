# Exponential Automorphism Rigidity for Surreal and Surcomplex Numbers

**Research manuscript dated 22 September 2026 — 17 pages.**

The article proves that a unital field endomorphism of the surreal field that
commutes with the canonical Gonshor exponential and fixes the natural valuation
pointwise is the identity. This gives a negative answer to Question 5.4 in the
checked version of Kaplan–Krapp–Serra, *Decomposing the automorphism group of the
surreal numbers*, arXiv:2509.22374v3.

The article also proves rigidity for every nontrivial convex valuation on an
ordered exponential field, including proper coarsenings, and proves a
surcomplex analogue with kernel consisting precisely of identity and
conjugation under the stated real-structure hypotheses. It includes explicit
counterexamples, complete proofs, a foundational scope discussion, and a
verification audit.

## Files

- `exponential_automorphism_rigidity.tex` — self-contained LaTeX source, with an internal bibliography.
- `exponential_automorphism_rigidity.pdf` — compiled article.
- `verification.py` — reproducible finite exact algebraic checks.
- `verification_results.txt` — recorded output: 309 checks passed.
- `requirements.txt` — Python dependency version used for these checks.

## Build and reproduce

A TeX Live installation with the packages named in the preamble and `latexmk`
is sufficient; no external bibliography file or graphics are needed.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error exponential_automorphism_rigidity.tex
python -m pip install -r requirements.txt
python verification.py
```

The recorded computation used Python 3.13.5 and SymPy 1.14.0. The script uses
exact rational arithmetic, symbolic polynomial identities, and finite formal
series truncations. Its rational samples use seed 20260922.

## Precise scope

“Fixes the valuation pointwise” means `v(sigma(x)) = v(x)` for every nonzero
`x`. Merely preserving comparisons of values allows a nonidentity action on
the value group and does not imply identity. The result proves a trivial
kernel and uniqueness of lifts, not that all exponential automorphisms are
trivial, and not that every value-group automorphism has a lift.

The surcomplex theorem assumes commutation with conjugation and preservation
of the canonical exponential on the real axis. It does not postulate a global
surcomplex exponential or classify unrestricted surcomplex field automorphisms.

## Provenance and review status

Primary question checked in arXiv version 3, revised 23 April 2026:
https://arxiv.org/abs/2509.22374v3
In particular: Definitions 2.4–2.5, Proposition 5.2, and Question 5.4.
The PDF pages containing the definitions and question were visually inspected.

Repository context:
https://github.com/VladimirReshetnikov/Surreal
Inspected snapshot: `608dd23c0539fce73723843949ee627641c27b30`.
The root README and `docs/README.md` were used to select a separate research
direction. No repository files were modified.

This is an AI-assisted research manuscript, not an independently refereed or
machine-checked proof. The mathematical arguments are supplied in full.
Passing the finite checks does not prove the class-sized theorems. No Lean
proof was compiled. The elementary auxiliary lemmas are not individually
claimed to be novel. The checked source still poses the selected question;
bibliographic priority beyond that observation has not been certified.

The PDF was compiled with no LaTeX warnings, unresolved references, or
oversized boxes and rendered for visual inspection.
