# Exact Homological Dimensions and Arithmetic Intersections in Omnific Integer Rings

Research manuscript dated 23 September 2026. The PDF has 25 pages.

## Contents

- `article.pdf`: complete article with proofs, examples, bibliography, and source comparison.
- `article.tex`: self-contained LaTeX source; bibliography is included in this file.
- `verify.py`: exact finite checks, requiring Python 3.9+ and only its standard library.
- `verification_results.json`: the output of the supplied verification run, including integer matrices.
- `build.sh` and `build.ps1`: PDF build scripts for a POSIX shell and PowerShell.
- `provenance.json`: repository pin, scope, and verification metadata.
- `SHA256SUMS.txt`: hashes of the deliverable files.

## Principal result

For the finite-support coordinate core

    A_d = D + direct_sum_{0 != alpha in Q_{>=0}^d} k X^alpha,

with a field k and a unital subring D, the article proves

    pd_{A_d}(D) = d + 1.

More generally, killing the open coordinate faces in a nonempty set U gives
flat dimension |U| and projective dimension |U|+1. The top extension group
contains an explicitly embedded copy of the quotient of D-valued sequences
by finitely supported sequences. The proof uses a displayed free telescope
and an infinite-support obstruction, not merely a finite computation.

For coefficient lattices of rank at least two over a PID, the previously
bounded projective dimensions become d+1 for the lattice module and d+2
for its monomial ideal quotient.

The second part computes all pairwise Tor groups in the ordered-cone core
and, with the stated universe convention, the full real/Gaussian omnific
rings. Second Tor detects the kernel of coefficient multiplication, independently
of surreal scale. It detects arithmetic linear disjointness for coefficient
orders. Its specified boundary embedding reconstructs an order's multiplication,
whereas derived constant-term reduction gives only an additive square-zero model.

## Repository comparison

The inspected repository snapshot is:

    VladimirReshetnikov/Surreal
    9693b28c24e6fcb317ce47969a40185c5dfef402

The primary compared source is:

    docs/surreal/set-sized-quotients-of-omnific-integers/article.tex

The exact finite-coordinate dimension resolves the uncertainty explicitly left
in `osq:hd:prop:pd`, including its ensuing paragraph. The flat face resolution,
coefficient syzygy, additive tensor kernel, and related prerequisites are
already in that source and are credited as such. The additive second-Tor formula
is presented as a consequence/extension of that tensor picture, not as an
unrelated first discovery. See Appendix B for the detailed comparison.

The pinned main report was inspected; every unpublished companion and all
historical literature were not exhaustively audited. Global priority is not
certified. This is not a claim to solve a major named factorization conjecture.

## Mathematical and verification status

The manuscript supplies written proofs. It has not been independently refereed
and was not checked in Lean or another proof assistant.

The included run passed 1,008 exact Koszul/transition identities and 600 exact
finite telescope/support checks, plus arithmetic kernel and discriminant checks.
These tests do NOT prove the infinite Ext nonvanishing, and the article says so
explicitly. The nonvanishing is proved by the finite-support argument in Theorem 4.1.

The coordinate-core results and ordered-core examples are ordinary set-sized
ZFC mathematics. The notation for full surreal rings is interpreted using the
two-universe convention in Section 5. It is not an unqualified use of ordinary
module categories over a literal proper-class ring.

Order reconstruction requires the specified boundary embedding and distinguished
unit. An abstract Tor group alone is not asserted to reconstruct an order.

## Rebuild and rerun

A LaTeX installation with pdfLaTeX and the standard packages listed in the
source is needed to build the PDF. No external bibliography program is needed.

POSIX shell:

    bash build.sh
    python3 verify.py

PowerShell:

    ./build.ps1
    python verify.py

The build scripts run pdfLaTeX three times to settle the contents, cross-references,
and PDF bookmarks. The verification script accepts `--output PATH` to write its
JSON results elsewhere. It makes no network requests and changes no repository.
