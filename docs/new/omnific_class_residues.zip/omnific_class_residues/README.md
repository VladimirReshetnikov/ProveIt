# Beyond the Constant Term
## Class Residue Fields of the Omnific Integers

Prepared for Vladimir Reshetnikov, 23 September 2026.

**Read `article.pdf`; edit or reuse `article.tex`.** The source is standalone:
all bibliography entries are included, and no external images, private fonts,
or repository checkout are needed to compile it.

## Mathematical scope

The article addresses the existence aspect of the pinned Surreal report's
question about nonarithmetic class primes. It works explicitly in
Gödel–Bernays set theory with global choice (GBC). It proves maximal class
extensions by a recursion with set-valued states, derives characteristic-zero
maximal ideals above `1 + omega^a`, determines the exact zero-or-unit cutoff
for monomials, lifts dyadic branches to actual maximal ideals, and realizes
nonarithmetic maximal quotients inside the surcomplex field `No[i]`.

It also gives the class-ring maximal-ideal/global-choice equivalence, using
credited classical polynomial compatibility arguments, and classifies prime
ideals subject to BOTH term-closure and strong-sum-closure. The article
contains eight further research questions, including the choice strength for
this particular ring and algebraic closedness of its binomial residue fields.

## Status

This is an AI-assisted, unrefereed mathematical research draft. The proofs
are written out, but they have not been independently refereed or formalized
in Lean. Historical priority is not certified. The generic Krull method,
Hahn-field closure, field reservoirs, and dyadic finite product algebras have
antecedents explicitly acknowledged in the paper. The general class-ring
choice equivalence must not be confused with a necessity result for one
specific omnific ring.

`PROOF_SOURCE_AUDIT.md` explains the source comparison, imports, hypotheses,
limitations, and verification boundaries.

## Files

- `article.pdf` and `article.tex`: complete article and source.
- `code/verify.py`: deterministic Python standard-library finite checks.
- `data/verification.json` and `.txt`: recorded results.
- `data/build_report.json`: PDF build and inspection record.
- `build.sh` and `build.ps1`: rebuild scripts.
- `PROOF_SOURCE_AUDIT.md`: proof and provenance audit.
- `SHA256SUMS.txt`: checksums for the delivered files other than itself.

## Build

Requires a TeX installation with pdfLaTeX and standard packages including
`lmodern`, `microtype`, `amsmath`, `amsthm`, `mathtools`, `geometry`, `booktabs`,
`longtable`, `enumitem`, `needspace`, `etoolbox`, `fancyhdr`, `xurl`, and
`hyperref`. These are commonly included in TeX Live or MiKTeX.

On a Unix-like system:

```sh
bash build.sh
```

In PowerShell on Windows:

```powershell
.\build.ps1
```

Both scripts compile three times, write temporary TeX files to `.build`,
replace `article.pdf` with the rebuilt document, and run the finite checks.
Rebuilding may change PDF metadata and checksums. The delivered build record
and checksums describe the delivered files, not a later local rebuild.

To run only the checks, using Python 3.9 or later:

```sh
python code/verify.py
```

The delivered run used Python 3.13.5 and passed **133,770 assertions**. These
are finite algebra sanity checks, not proof-assistant verification of the
proper-class results or infinite Hahn identities. No network is needed.

## Repository snapshot

The comparison is pinned to:

```text
VladimirReshetnikov/Surreal
51c1cc70240d208f88704b0bb0b95855701be702
```

The specific report is
`docs/surreal/set-sized-quotients-of-omnific-integers/`.
The audit does not claim a complete novelty search of every repository
manuscript, every companion, or the entire published literature.
