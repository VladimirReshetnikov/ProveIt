# Curve Rigidity over the Omnific Integers

**Elliptic equations, differential separation, and semiabelian varieties**

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.
Author: OpenAI ChatGPT. The compiled article has 23 PDF pages (cover,
contents, and 21 numbered pages) and approximately 11,000 words.

## Main outcome

The manuscript resolves the smooth-curve part of Question 14.1 in the
repository's *Omnific Integers and Omnific–Diophantine Geometry* report,
including the nonsingular case of `y^2 = x^3 + ax + b` with `a != 0`.
The comparison is pinned to Surreal commit
`4cdeaec43ff1692ed2ad9f5bdf761a41872975a5`.

For an affine integer model X whose complex fiber is a smooth geometrically
integral curve, the exact criterion is:

> X has a nonordinary omnific point precisely when X has an ordinary
> integer point and its complex fiber is isomorphic to the affine line.

In the affine-line case, every nonempty constant-term fiber is explicitly
and bijectively parametrized by the purely infinite ideal Pi. Outside
that case the constant-term fibers are singletons. There is also a
Gaussian omnific version.

The stronger geometric theorem applies to arbitrary set-sized ordered
exponent groups and unrestricted reverse well-ordered supports. Smooth
proper varieties with globally generated cotangent bundle, all abelian
and semiabelian varieties, and separated finite-type schemes with
quasi-finite maps to semiabelian varieties have only constant points
over the nonnegative-support Hahn ring.

The superelliptic/elliptic result also has an independent elementary proof:
for squarefree f of degree at least two and m >= 2, every solution of
`y^m = f(x)` in the nonnegative-support ring is constant. A polynomial
Bezout identity forces a derivative to be divisible by an element of
too large a leading degree. The general elliptic certificate is printed
explicitly.

## Important distinctions

The nonnegative-support ring B is not the finite valuation ring O and
is not the full Hahn field K. The geometric argument compares points
over B and O inside K. It uses support-preserving Euler derivations,
not the Berarducci–Mantova derivation.

Smoothness and constant coefficients are substantive hypotheses.
Singular cubics have explicit polynomial families of nonconstant
omnific solutions. Unimodular projective coordinates are distinguished
from arbitrary nonzero homogeneous tuples. Singular-curve classification,
general higher-dimensional affine classification, and primitive
non-unimodular Fermat tuples are not settled here.

## Files

- `article.tex`: standalone LaTeX source with an internal bibliography.
- `article.pdf`: compiled, searchable, typeset manuscript.
- `verify.py`: exact symbolic and finite-support algebraic checks.
- `verification.json`: recorded results: **3,991 assertions passed**.
- `requirements.txt`: the tested SymPy version.
- `Makefile`: compilation and verification commands.
- `SOURCE_AUDIT.md`: source provenance, novelty comparison, and limits.
- `BUILD_AUDIT.json`: compilation and PDF quality-check record.
- `SHA256SUMS`: integrity hashes for the package files.

## Reproduction

Use a TeX distribution with `latexmk`, `pdflatex`, and the packages in the
source preamble. No BibTeX/Biber step or external source files are needed.

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex
python3 -m pip install -r requirements.txt
python3 verify.py
```

Alternatively, run `make` and `make check`. The check script uses Python
3.10-or-newer syntax; the recorded run used Python 3.13.5 and SymPy 1.14.0.
`make clean` removes intermediate TeX build files while retaining the PDF.

## Evidence and status

Full written mathematical proofs are supplied, with standard inputs and
existing repository results credited separately. The proposed new results
are not certified as worldwide firsts: the literature search was targeted,
not exhaustive. The work has not been refereed, independently reviewed,
or verified in Lean or another proof assistant.

The 3,991 exact finite checks cover polynomial identities and finite-support
Hahn models. They are not a proof of the arbitrary-support or
scheme-theoretic results. The PDF was compiled with stable references,
rendered, and visually inspected. No repository files were modified.
