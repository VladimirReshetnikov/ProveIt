# Shortest Vectors and Missing Infima over the Omnific Integers

Research article prepared September 23, 2026 for the Surreal project.

## Files

- `article.pdf`: typeset article, with complete proofs of the central claims.
- `article.tex`: self-contained LaTeX source, including the bibliography.
- `verify.py`: exact finite symbolic and integer-arithmetic checks.
- `verification-output.txt`: output from the executed verification program.
- `requirements.txt`: tested SymPy version for those checks.
- `provenance.md`: inspected sources, repository revision, and verification limits.
- `SHA256SUMS.txt`: hashes of the delivered files other than the hash file itself.

## Main results

The article works with finite sums of ordinary positive-semidefinite quadratic
or Hermitian forms with successively infinitesimal positive weights. The last
index is the first stage at which the cumulative kernel becomes zero.

Theorems 5.2 and 5.3 give the unrestricted shortest-vector criterion, exact
missing-infimum cut, and improvement of every set-sized family by one monomial
vector. Theorem 7.5 gives a different criterion for unimodular (primitive)
minimization. Theorem 8.5 reduces arbitrary surreal/surcomplex closest-point
problems, at rational flags, to at most 2^n or 4^n ordinary candidates. Theorems
9.1 and 9.2 compare the unrestricted and primitive cuts in an explicit Pell
example. Theorems 11.3 and 11.4 give real and explicitly specified Gaussian
LLL nonexistence results. Section 13 states essential boundaries and gives
counterexamples to overgeneralization.

These are proposed research contributions with proofs, not a claim of
independent peer review, formal verification, or exhaustive historical priority.
The ordinary rational-flag Voronoi precursor is explicitly credited. No named
historical factorization conjecture is claimed to be newly solved.

## Build the PDF

Use a TeX distribution containing the standard packages named in the preamble.
No custom fonts, figures, bibliography processor, or shell-escape is needed.

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run the following command three times to stabilize cross-references
and the table of contents:

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

## Run the finite checks

```text
python -m pip install -r requirements.txt
python verify.py
```

The checks use exact algebra and integers, not floating-point approximations to
infinitesimals. They do not implement surreal arithmetic, verify arbitrary
set-indexed statements, or certify the proofs of minimization or coinitiality.
The article supplies mathematical proofs for those statements. No Lean code
for the new theorems is included, and no Lean build was run for them.
