# Fractions of Omnific Integers

## Rational Specialization, Lowest Terms, Denominator Ideals, and Scale Extensions

Prepared for Vladimir Reshetnikov, 23 September 2026.
Author: OpenAI ChatGPT.

The article is a 23-page research draft with complete written proofs relative
to classical surreal normal-form and cut-existence results. The LaTeX source
is self-contained, including its bibliography.

## Main results

Write Oz = Z + Pi, where Pi consists of the positive-exponent purely infinite
normal forms, including zero. The identity Frac(Oz) = No is classical and is
not claimed as new.

For any nonzero tau in Pi and any finite tuple of real rational functions,
choose a common polynomial numerator-denominator vector with gcd one. Its
projective value at zero determines every omnific representation, even those
with arbitrary infinite supports:

- Rational projective value: after a common real normalization making the
  constant vector primitive integral, the scalar multipliers are exactly Oz.
  The simultaneous denominator ideal is principal, and unique lowest terms
  and a least positive common denominator exist.
- Irrational projective value: the multipliers are exactly Pi. The denominator
  ideal is a scalar copy of Pi, has no set of generators, and no representation
  has a gcd. Every positive denominator can be halved.

For a single reduced f in R(T), the criterion is f(0) in Q union {infinity}.
Other results include a pair of individually reduced fractions without a
least common denominator; primitive homogeneous coordinates on real rational
curves; the exact denominator defect under T = U^m; an explicit nonflat,
non-module-finite integral extension and its Tor_1 witness; a localization
with rational residue independently prescribed from real standard part;
monomial denominator criteria; and Gaussian omnific analogues.

The proposed new content is the exact rational-function classification and
denominator-defect package, not the general pullback method, classical
fraction-field identity, or previously known irrational-constant examples.
Historical priority is uncertain; the search was targeted, not exhaustive.

## Contents

- `omnific_fractions.tex` — complete article source and internal bibliography.
- `omnific_fractions.pdf` — compiled article, 23 pages.
- `verify.py` — deterministic exact finite checks.
- `verification.json` — recorded result: 833 assertions passed, using SymPy 1.14.0.
- `requirements.txt` — Python dependency.
- `Makefile` — build, check, and auxiliary cleanup commands.
- `SOURCE_AUDIT.md` — repository pin, comparison scope, and novelty limitations.
- `build_audit.json` — final compilation and artifact-validation record.

## Reproduce the PDF

A TeX distribution with pdflatex and the packages named in the preamble is
required. No external bibliography processor is needed.

```sh
latexmk -pdf -halt-on-error -interaction=nonstopmode omnific_fractions.tex
```

Without latexmk, run pdflatex with the same two flags repeatedly until the
references and contents stabilize. `make pdf` is equivalent to the latexmk
command above.

## Reproduce the finite checks

Python 3.10 or later is required.

```sh
python -m pip install -r requirements.txt
python verify.py --output verification.json
```

The script checks polynomial gcd normalization; rational projective residue
classification over Q(sqrt(2)); polynomial and integer Bezout identities;
the lifted integer-constant Bezout certificates; sample scalar membership;
the article's examples; scale substitutions; truncated coefficient spaces;
and the displayed algebraic relations. It also checks finite falling-factorial
independence used in one example.

These are supplementary exact checks, not a proof assistant or a substitute
for the written arguments. They do not verify arbitrary surreal supports,
proper-class size statements, all universal quantifiers, or historical
priority. No Lean formalization, repository build, or peer review is claimed.

## Repository relationship

The comparison is pinned to Surreal commit
`9a385d3957bdfe3d9ea79f9a524751c90bd2c894`.
The repository was read through the GitHub connector and was not changed.
The article proves its needed elementary inputs rather than depending on
unreviewed repository theorems. See Appendix B and `SOURCE_AUDIT.md`.
