# Hankel Square-Class Profiles over Surreal Hahn Fields
## Exact Factor Counts, Splitting Fields, and Definite Pencils

Research manuscript prepared for Vladimir Reshetnikov, 22 September 2026.
The PDF is 22 pages, including the title page, contents, and references.

## Main result and its hypotheses

Let Gamma be a set-sized ordered abelian group; divisibility is NOT assumed.
Work over F = R((t^Gamma)), with complexification K = C((t^Gamma)).
Let p be monic, squarefree, and real-rooted, of degree n >= 1.
Compute its Newton sums s_j from its coefficients, form the Hankel matrix
H = (s_(i+j))_(0 <= i,j < n), and put h_0 = 1 and
h_k = det(H[0:k,0:k]). Every h_k is positive.

Theorem 5.1 identifies the exact splitting field as

    F(sqrt(h_1), ..., sqrt(h_n))
      = R((t^(Gamma + sum_k Z*v(h_k)/2))).

Its degree is 2 to the dimension of the span of the classes v(h_k) modulo
2*Gamma. The corresponding statement holds over K.

Theorem 6.2 identifies the number of distinct irreducible factors as

    #{k : v(h_k) - v(h_(k-1)) belongs to 2*Gamma}.

The full multiplicity profile of those pivot classes gives factor counts
after every ordered Hahn base enlargement. The paper also proves a profile
realizability theorem, invariance and precision results, and sharp dimension
bounds for positive definite Hermitian pencils. Explicit examples show why
one discriminant or the valuations of individual roots are insufficient,
and why the profile need not determine all irreducible factor degrees.

For Gamma embedded in No, t^gamma maps to omega^(-gamma). The extensions in
these statements are extensions of fixed Hahn workspaces already inside
No or No[i], NOT extensions of the full surreal or surcomplex class field.

## Contents of this package

- article.pdf: complete typeset manuscript.
- article.tex: standalone LaTeX source, including the bibliography.
- check_examples.py: exact symbolic checks for the finite examples.
- verification_results.json: machine-readable output of the executed checks.
- verification_output.txt: readable output of the same run.
- PROOF_AUDIT.md: dependency map, boundaries, and verification status.
- requirements.txt: the SymPy version used for the checks.
- build.sh: optional POSIX build command.
- SHA256SUMS.txt: checksums of the other package files.

No external bibliography file, images, custom fonts, or downloaded source
files are needed to compile the manuscript.

## Building the article

Use a TeX distribution with pdflatex and the standard packages listed in the
source. From this directory, run:

    pdflatex -halt-on-error -interaction=nonstopmode article.tex
    pdflatex -halt-on-error -interaction=nonstopmode article.tex

A third run is harmless if references have not yet stabilized. On a POSIX
system the included build.sh performs three runs. On Windows the same two
pdflatex commands work in PowerShell after installing a TeX distribution.

The delivered PDF was compiled successfully with pdfTeX 1.40.26. Its final
log had no undefined references, overfull boxes, underfull boxes, or warnings.
Rendered pages were inspected for layout.

## Running the finite checks

Use Python 3.9 or newer, without the -O flag (the script uses assertions):

    python -m pip install -r requirements.txt
    python check_examples.py

The script overwrites verification_results.json in its own directory and
prints its findings. To recreate the readable log:

    python check_examples.py > verification_output.txt

All checks passed using SymPy 1.14.0. They cover companion/Hankel identities,
the quadratic and quartic examples, the pair of degree-six profiles, a
positive definite pencil, affine covariance, a radical-product identity,
and squarefree reduction. These checks are exact finite symbolic
calculations, not a proof of general Hahn-field theorems.

## Novelty, sources, and limitations

The comparison uses the pinned Surreal repository revision
4cf691c7d951e037739d32d9f5c387dcce724f3c. The audit was targeted: the reader
map, relevant spectral-theory material, and the polynomial-algebra inventory.
It was not a line-by-line review of the whole repository or all its history.

Existing Hahn spectral descent, classical trace-form identities, and earlier
multiquadratic spectral results are explicitly acknowledged, not presented
as new. The exact Hankel splitting-field and pivot-profile package is offered
as a candidate original contribution: no matching statement was located in
the targeted search, but priority is not certified. No named published open
conjecture is claimed solved. The article contains detailed general proofs,
but has not been independently refereed or completely formalized in Lean.
