# Face Topology and Arithmetic Homology in Omnific Integer Rings

**Polyhedral cores, radical monomial quotients, and a simpliciality criterion**

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Files

- `article.pdf`: the 30-page article, including complete mathematical arguments, examples, bibliography, and twelve research questions.
- `article.tex`: standalone LaTeX source with an internal bibliography.
- `verify.py`: exact, standard-library-only finite verification program.
- `verification_results.json`: recorded check results and example multiplicities.
- `SOURCE_AUDIT.md`: repository snapshot, literature comparisons, and novelty boundary.
- `PROOF_AUDIT.md`: critical proof steps, assumptions, and verification limitations.
- `BUILD_REPORT.json`: compilation and PDF inspection record.
- `Makefile`: verification and PDF build targets.
- `SHA256SUMS`: integrity hashes for the package files (excluding the checksum file itself).

## Main result

Let C be a pointed full-dimensional rational polyhedral cone in R^d, let k be a field, and let D be a unital subring of k. Define the **finite-support** ring

    A_D(C) = D + direct_sum_{0 != m in C intersect Q^d} k X^m.

For a face F, projection onto its monomials gives a quotient A_D(F). The article proves

    fd_{A_D(C)} A_D(F)
      = max { dim G : G is a face of C and G intersect F = {0} }.

The zero face is included in the maximum. The main consequences are:

1. The constant quotient has flat dimension d for every such cone.
2. C is simplicial precisely when every facet quotient has flat dimension one.
3. A cone over an n-cube has a facet quotient of flat dimension n, despite that facet's codimension being one.
4. More generally, reduced homology of a finite join complex computes the flat dimension of every radical coefficient-full monomial quotient in the positive tail.
5. All those quotient maps have vanishing positive self-Tor, even though their flat dimensions can be large.
6. For D a PID that is not a field, a nonzero arithmetic D-module has flat dimension 1 if it is torsion, and d otherwise.
7. A two-monomial relation proves that embedding a core of dimension at least two into a compatible total-order core is not flat. The same finite relation obstruction holds in the full omnific target.

For (D,k) = (Z,R) and (Z[i],C), these rings embed concretely into the omnific and Gaussian omnific integers. The two realizations have identical characteristic-zero face multiplicities.

## Status and scope

This is an AI-assisted proof-bearing draft, not a refereed paper or a Lean-verified development. The arbitrary-cone formula and detector construction are proposed contributions; exhaustive publication priority is not certified. Classical cellular and lcm-lattice methods and the repository's existing orthant results are credited explicitly.

All derived-functor calculations use set-sized rings and modules. The full proper-class omnific ring appears only as a target for a concrete embedding and a finite equational nonflatness certificate. No weak/global dimension of the full omnific ring is asserted. No extension to unrestricted infinite Hahn supports is asserted. The geometric monomial class excludes arithmetic ideals with nonzero constant terms.

## Reproduce

Requirements: Python 3.10 or later; a LaTeX distribution with pdfLaTeX, latexmk, and the packages listed in the source. No nonstandard Python packages or network access are needed.

    python3 verify.py
    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Or run:

    make

The verification program writes `verification_results.json` beside itself. Its elapsed-time field varies by machine; the mathematical check counts are deterministic. The recorded run passed 52,080 exact assertions, covering 188 face quotients, 1,329 additional antichains, 56 actual cancellation steps, and 2,457 rational cap checks. These are finite consistency checks, not a machine proof of the infinite-ring theorems.

## Repository pin

    7b256e0792df7718995b816ad12a77bf56731f8f

The comparison centered on `docs/surreal/set-sized-quotients-of-omnific-integers/`, especially the coordinate-orthant resolution and flat-dimension source labels. See `SOURCE_AUDIT.md` for the exact inspection boundary.
