# Drazin Halos and Ramified Spectral Mapping over Surcomplex Hahn Fields

Research manuscript dated September 22, 2026. The PDF has 20 pages, including
its title page, contents, proofs, examples, audit, verification discussion,
and bibliography.

## Main results

For every nonzero unital complex algebra A and every nonzero set-sized ordered
abelian group Gamma, the spectrum of a constant T relative to A((t^Gamma)) is

    Sigma_Gamma(T) = sigma_A(T) union (sigma_D,A(T) + m_Gamma).

Here sigma_D is the finite-index Drazin spectrum, and m_Gamma includes zero.
The theorem needs neither normality, a norm on A, divisibility, nor rank one.
Every infinitesimally shifted inverse descends to a finite-negative-tail Laurent
series in the displacement. Its exact leading valuation records the Drazin index.

For a nonconstant complex polynomial p, the manuscript also gives the complete
spectral image. At b=p(a), a ramification index r permits precisely nonzero
infinitesimal images with valuation in r*Gamma. Spectral mapping holds exactly
when every relevant Drazin-spectral fiber contains a preimage whose ramification
index acts surjectively on Gamma.

The examples include Volterra, increasing lengths of nilpotent Jordan blocks,
a concrete missing-odd-valuation spectral-mapping image, and a two-rank actual
surreal displacement. The final specialization uses actual surcomplex scalars
and set-supported operator-valued normal forms, with the locality argument explicit.

## Files

- `article.tex`: standalone LaTeX source; bibliography included.
- `article.pdf`: compiled, visually inspected 20-page article.
- `RESEARCH_AUDIT.md`: pinned repository comparison and literature/novelty limits.
- `code/verify.py`: exact finite checks, Python standard library only.
- `data/verification.json`: actual recorded run, 484 passed assertions.
- `data/build_report.json`: compilation and rendering checks.
- `SHA256SUMS.txt`: hashes of the delivered files other than this hash manifest.

## Build the article

Run from this directory with a LaTeX distribution containing the packages
listed in the preamble:

    latexmk -pdf -halt-on-error -interaction=nonstopmode article.tex

Alternatively run this command three times to stabilize references:

    pdflatex -halt-on-error -interaction=nonstopmode article.tex

No external bibliography tool, custom font file, shell escape, or downloaded
figure is required.

## Reproduce the finite checks

Python 3.10 or later; no third-party packages. From this directory:

    python code/verify.py

The command prints JSON and writes nothing. To save a new run without changing
the delivered record:

    python code/verify.py --output rerun/verification.json

All arithmetic uses fractions.Fraction. The 484 assertions test finite matrix
identities and finite-degree formal calculations. They do not prove arbitrary
Hahn support statements, the Volterra spectrum, the infinite-block spectrum,
or any proper-class assertion. Those claims are supported by the article's
mathematical arguments, not by a finite approximation.

## Scope and status

The closest repository result already classifies constant **normal** operators.
This manuscript credits that overlap and the classical Drazin/Laurent, Hahn
support, and surreal normal-form inputs. Its proposed contribution is the
combined arbitrary-rank nonnormal classification and exact ramification theorem.

The repository comparison is pinned to:

    048b72cf7cbfc8ab246e4f73788c10460cb3f6e0

The literature comparison was targeted, not exhaustive. Priority is not
certified; no named published conjecture is claimed solved. The proofs have not
been independently refereed or checked by a proof assistant. Spectra are relative
to the named algebras, not silently to every possible linear-operator category.

No repository files were changed or commits made during this work.
