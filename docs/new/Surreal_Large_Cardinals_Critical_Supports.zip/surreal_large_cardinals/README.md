# Critical Supports and Large Cardinals in Surreal Arithmetic

**Ultrapower transport, Hahn lifts, and omnific descent**  
Research article prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.pdf`: the compiled 27-page article, with a linked contents page,
  numbered statements and proofs, nine further research questions, an audit
  appendix, and references.
- `article.tex`: standalone LaTeX source; the bibliography is embedded.
- `PROOF_STATUS.md`: provenance, verification boundary, and theorem ledger.
- `build.sh`: local build helper.

## Principal results

For an elementary universe embedding `j: V -> M` with critical point kappa,
let `J` transport a surreal as a set and let `H_j` transport the exponents
of its Conway normal form term by term.

**Theorem 3.3:** `J(x) = H_j(x)` exactly when the support of `x` has fewer
than kappa nonzero terms. Theorem 3.5 gives the same sharp cardinal
threshold for preservation of arbitrary strongly summable families by `J`.

**Theorem 4.2:** the difference is the exact normal form on the missing
indices `j(lambda) \ j''lambda`; its first term comes from index kappa.

**Theorem 4.6:** the ratio between `H_j(exp(x))` and `exp(H_j(x))` is
`exp(J(x^up) - H_j(x^up))`, where `x^up` is the positive-exponent part.
Hence exponential compatibility holds exactly when that part has fewer
than kappa terms. Corollary 4.7 gives the one/infinitesimal/infinite
classification of the ratio.

**Theorem 5.1:** for every individual normal form of ordinal length lambda,
`H_j(x)` belongs to the target model exactly when `j''lambda` belongs to
it. For a set-ultrapower, Lemma 5.3 identifies this with closure under
ambient lambda-sequences.

**Theorem 6.3:** for a normal-measure ultrapower on kappa, support size
below kappa gives agreement; size exactly kappa gives unequal values
both in the target; size above kappa makes the Hahn-lifted value leave
the target. No GCH hypothesis is used.

**Theorem 7.1:** a coefficient of the defect on explicit bounded surreal
codes recovers the normal measure. Corollary 7.3 provides omnific codes.

**Theorems 8.2–8.3:** fine complete ultrafilters correspond to internally
short binary-support covers; normal fine complete ultrafilters correspond
to exact descent of one canonical series. These are equivalences with
the classical compactness principles, not new consistency proofs.

**Theorems 9.1–9.2:** transfer to surcomplex numbers, omnific integers,
and Gaussian omnific integers.

## Build

Run:

```sh
./build.sh
```

Or run `latexmk -pdf article.tex` in this directory. A reasonably complete
TeX Live installation with NewTX, AMS packages, mathtools, microtype,
cleveref, aliascnt, tcolorbox, and hyperref is sufficient. No bibliography
processor or external data files are needed. No font files are shipped.

## Status

This is an AI-assisted research draft with written proofs. The exact
comparison and descent statements are proposed contributions whose
priority is not certified. The classical Hahn and ultrapower ingredients
are credited separately. The new statements have not been independently
refereed or formalized in Lean. No named published conjecture is claimed
resolved, and no large-cardinal axiom is claimed proved in ZFC.

The PDF was compiled, checked for unresolved references and overfull
boxes, and visually inspected. That document verification is not a
machine verification of the mathematics.
