# Infinite Products of Surreal Probabilities

**Sharp l1/l2 extension thresholds, transfinite positivity, and rigidity of Hahn countable additivity**

Research manuscript prepared for Vladimir Reshetnikov, September 22, 2026.

## Read and rebuild

`article.pdf` is the typeset article. `article.tex` is its self-contained LaTeX
source, including the bibliography. Run `sh build.sh` in this directory, or run
pdflatex three times with `-halt-on-error -interaction=nonstopmode`.
The source requires a normal TeX installation with newtx, amsmath, amsthm,
mathtools, microtype, geometry, enumitem, booktabs, array, longtable, xcolor,
fancyhdr, needspace, hyperref, bookmark, and listings. No font files are distributed.

Run the exact finite checks with Python 3.10 or later:

    python code/verify.py --output data/verification.json

Only the Python standard library is used. The recorded run passes 1,009 exact
rational-arithmetic assertions. A failed assertion causes a nonzero exit.

## Main results and scope

Theorem 4.1 gives the exact exponent-row weighted l2 condition for infinitesimal
independent Bernoulli perturbations of real biases uniformly separated from
zero and one. Theorem 5.1 gives the exact l1 condition at a deterministic
baseline. Theorem 6.1 combines interior and boundary coordinates.
All assume one well-ordered positive exponent set common to the coordinates.
No uniform norm bound across exponents and no rank-one assumption is imposed.

Corollary 7.1 excludes a nonreal constant Bernoulli bias in the precisely defined
coefficientwise-regular extension class. Theorem 8.2 classifies strong Hahn
countable additivity by finite support of every coefficient measure. Corollary
8.4 gives the exact finite-row threshold at a deterministic baseline. Theorem
8.5 and Corollary 8.6 give finite-orbit and exchangeability consequences.

A coefficientwise-regular measure has one globally well-ordered Hahn support
and finite signed/complex countably additive coefficient measures. Strong Hahn
countable additivity additionally requires finite incidence at each exponent
across disjoint events. These are different conventions. The nonexistence
results do not rule out probability theories with other additivity axioms.

## Research status

This is an AI-assisted research manuscript, not an independently peer-reviewed
paper or a Lean formalization. The article gives mathematical proofs, naming
classical foundational inputs. The supplied program checks finite algebra only;
it does not certify infinite extension, arbitrary-rank support, or transfinite
positivity arguments.

The combined theorem formulations are presented as candidate new results.
The repository and literature review was targeted, not exhaustive; see
RESEARCH_AUDIT.md and Appendix A. No previously named historical conjecture is
claimed to have been resolved.

## Package contents

- article.tex and article.pdf
- code/verify.py and its recorded output data/verification.json
- README.md, RESEARCH_AUDIT.md, and build.sh
- data/build_summary.json, recording compilation and inspection status
