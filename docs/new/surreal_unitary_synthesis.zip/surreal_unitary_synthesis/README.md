# Simultaneous Unitary Straightening at Surreal Scales

**An exact synthesis criterion, atomic spectral calculus, and uniformly
controlled counterexamples**

Research draft prepared for Vladimir Reshetnikov, September 23, 2026.
The PDF has 22 pages, including the title page, contents, and references.

## Main result

For a set-indexed orthogonal family of projections in
`B(H)((t^Gamma))`, a simultaneous near-identity Hahn unitary exists exactly
when the canonical coefficient columns both:

1. extend to bounded operators on the ordinary Hilbert direct sum, at each
   exponent; and
2. have a well-ordered active support.

The article gives an explicit construction for both complete and incomplete
residual families. It proves scale-enlargement invariance, a finite-jet
criterion, and an atomic functional-calculus equivalence. It also gives
independent counterexamples to the two conditions. In the stronger example,
every individual projection coefficient is uniformly bounded over the
family at every order, but collective synthesis still fails. A selected
subfamily has no join. The final application classifies projections and
unitaries with omnific or Gaussian-omnific matrix entries in the stated
operator category.

This is a proposed resolution of the infinite-synthesis question identified
in the repository's Hahn–Hilbert geometry guide, within the exact category
specified above. It is not a claim to solve every spectral problem over
surreal scalars, nor a claim of independently certified novelty.

## Files

- `article.tex`: standalone LaTeX source with an internal bibliography.
- `article.pdf`: compiled article.
- `verify.py`: exact rational finite matrix-series diagnostics.
- `verification_results.json`: the recorded run; 159 assertion groups passed.
- `requirements.txt`: Python dependency for the checks.
- `build.sh`: POSIX PDF build script.
- `build.ps1`: PowerShell PDF build script.
- `BUILD_REPORT.json`: PDF and verification validation scope.

## Build the PDF

A modern TeX Live or MiKTeX installation with pdfLaTeX and the standard
packages used in the preamble is sufficient. These include `newtx`,
`amsmath`, `amsthm`, `mathtools`, `geometry`, `microtype`, `enumitem`,
`booktabs`, `fancyhdr`, `hyperref`, and `bookmark`.

On a POSIX shell:

```sh
./build.sh
```

On PowerShell:

```powershell
./build.ps1
```

Equivalently, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. No separate BibTeX run is required. No font files are bundled.

## Run the exact diagnostics

```sh
python -m pip install -r requirements.txt
python verify.py --output verification_results.json
```

The script uses exact SymPy matrix arithmetic. It tests complete and
incomplete finite projection families, both unitary identities, the
canonical construction, finite jets, rank-two flat-block identities, and
the rational-scale block expression.

These tests do not establish infinite-dimensional boundedness, arbitrary
ordered-group support lemmas, or mathematical novelty. Those assertions
are addressed by the written proofs, not by the finite test count. There
is no Lean formalization in this package.

## Provenance and review boundary

Repository: https://github.com/VladimirReshetnikov/Surreal

Inspected revision: `fc27d87646ea3b7ed5e04e0a9c00a307dfe12fe2`.

The repository catalogues and relevant report guides were inspected to
identify the open assembly question and avoid duplicating earlier results.
This is not a full audit of all repository report proofs. The main argument
here is self-contained apart from standard Hahn support calculus and
ordinary Hilbert operator theory.

The article is AI-assisted and unrefereed. Independent proof review,
priority assessment, and formal verification remain separate tasks. It
contains twelve further research questions and an explicit dependency and
proof-checking audit.
