# Gamma, Zeta, and the Riemann Hypothesis over Surcomplex Numbers

Research article prepared for Vladimir Reshetnikov, 22 September 2026.

## Contents

- `surcomplex_gamma_zeta.tex`: self-contained LaTeX source and bibliography.
- `surcomplex_gamma_zeta.pdf`: 31-page compiled article.
- `code/verify.py`: exact finite symbolic checks (Python + SymPy).
- `data/verification.json`: executed check results and limitations.
- `data/source_audit.json`: repository snapshot, source versions, and audit scope.
- `data/build_review.json`: build and visual-review record.

## Main results and scope

Theorem 3.1 proves divisor rigidity of canonical finite Taylor-Laurent lifts.
Theorem 5.4 and Corollary 5.5 show that two infinitesimal constant perturbations
characterize real/simple zeros and, for Xi, classical RH plus simplicity.
Theorem 6.3 protects simple critical-line zeros under real-even infinitesimal
deformations. Theorems 7.1 and 7.3 provide an exact Dirichlet arithmetic algebra,
Euler product, and zero-free positive-infinite chart. Theorem 8.1 gives an exact
Hurwitz/Lerch/Stirling bridge. Theorem 10.2 specifies global RH in a transported
elementary model. Theorem 12.1 conditionally forces nonreal heat-flow zeros at
negative infinitesimal time to have infinite modulus.

The article distinguishes finite canonical values, selected transseries values,
and functions transported into a set-sized surreal subfield. It does not assert
that these have been identified as one canonical function on all No(i).
It does not prove or disprove classical RH or prove simplicity of all zeta zeros.
The new arguments are unrefereed research notes; no priority certificate or
complete proof-assistant verification is claimed.

The recent August/September 2026 zero-proportion preprints are separately labeled
as imported preprint results. The older published simple-zero bound supplies an
independent baseline for the deformation application.

## Rebuild the PDF

A standard TeX Live installation with newtx, amsmath, amsthm, mathtools,
microtype, geometry, enumitem, booktabs, fancyhdr, and hyperref is sufficient.
No font files are bundled. Run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error surcomplex_gamma_zeta.tex
```

Alternatively, run pdflatex on the source three times.

## Rerun the finite checks

```sh
python code/verify.py --output /tmp/gamma-zeta-checks.json
```

The shipped run used Python 3.13.5 and SymPy 1.14.0.
All 350 exact finite checks passed. They check algebraic identities and finite
coefficients, not general Hahn summability, implicit-function theory, transfer,
analytic-number-theory inputs, or RH. A required output path prevents a default
rerun from silently replacing the supplied evidence.

## Repository audit

Snapshot: `905dd19954db43ac81f76f72036520d0eadc5710`.
The repository catalogue and maintained Gamma/analysis summaries were inspected.
This was not a full line-by-line audit of every source file or Lean declaration.
The central local mathematical results needed here are proved in the article.
