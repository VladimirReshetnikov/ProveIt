# Finite Symmetry Descent and Real Forms of Gaussian Omnific Integers

Research article prepared with ChatGPT for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `finite_symmetry_descent.pdf`: the complete 27-page article.
- `finite_symmetry_descent.tex`: standalone LaTeX source with an internal bibliography.
- `SOURCE_AND_PROOF_AUDIT.md`: source provenance, novelty boundary, hypotheses, and review checklist.
- `build.sh`: rebuilds the PDF and reruns the finite verifier.
- `code/verify_finite.py`: standard-library-only exact arithmetic checks for the worked example.
- `data/verification.json`: recorded successful regression run, 3,751 assertions at order 12.
- `data/verification_console.txt`: readable output of that run.
- `data/build_validation.json`: compilation and PDF inspection record.

## Main results

The article gives an explicit norm-section conjugator for finite groups of
strong valued automorphisms of a full Hahn field with divisible exponents,
provided the action stabilizes the coefficient field and strictly negative
support. Both the set-sized and the set-supported surreal-exponent cases
are treated. Surjectivity and strongness of the inverse are proved separately.

For strong valued automorphisms of `No[i]` preserving `Oz[i]`, the resulting
involution conjugacy types are classified by real closed coefficient fields
of transcendence degree continuum. The fixed pair is

    ( F((t^No)), Z + F((t^(No_<0))) ).

The second component is an integer part exactly when F is Archimedean.
The first component is a copy of No exactly when F is a copy of R.
There are exactly 2^continuum conjugacy types in the specified category;
a family of that size has pairwise nonisomorphic fixed fields and genuine
integer-part fixed rings. Its members remain nonconjugate even under arbitrary
plain field automorphisms.

## Reading route

Section 1 states the main results. Sections 3–5 contain the norm proof and
its support, maximality, class-local, and inverse-summability arguments.
Sections 7–10 give coefficient reconstruction, the involution classification,
the integer-part criterion, and the cardinality theorem. Section 11 contains
a nonlinear worked example. Sections 12–14 explain the boundaries, source
position, and ten proposed research questions. The appendices give a proof
audit and a formalization-oriented interface.

## Build

Requires a TeX installation with pdfLaTeX, latexmk, and the packages named in
the source (including Latin Modern, amsmath, amsthm, aliascnt, cleveref,
microtype, hyperref, fancyhdr, and geometry). No external bibliography file
is required. Python 3.10 or later is sufficient for the regression checks;
there are no third-party Python dependencies.

From this directory:

```sh
sh build.sh
```

Or separately:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error finite_symmetry_descent.tex
python3 code/verify_finite.py --order 12 --output data/verification.json
```

The build helper overwrites the generated PDF and the verification output
files in this package. It does not modify an external repository or library.
The PDF metadata and compression may differ between TeX installations.

## Mathematical and novelty status

Complete written proofs are supplied relative to the classical inputs
listed in the article. The main theorem package is proposed as a research
contribution, not a certified breakthrough or a solution of an unrestricted
named published conjecture. Priority and correctness have not been
independently certified. The source search and repository comparison were
focused, not exhaustive.

No Lean formalization or independent referee review is claimed. The finite
verifier checks exact identities in Q(i)[u]/(u^12), not infinite Hahn sums,
class theory, maximality, or cardinalities. Its successful run is not a
machine verification of the article's main theorems.

The repository baseline was
`343dc2c471212bb9b53ff4623bace2e1943f255b`. Selected repository guides were
read through the GitHub connector. The repository was neither modified nor
built. The article's proofs do not assume an unreviewed new theorem from it.
No third-party papers or font files are included.
