# Exponential Kernels and Arithmetic Rigidity in the Surcomplex Field

**Subtitle:** Minimal multiplier rings, nonsplit periods, and the limits of canonical extension  
**Date:** 22 September 2026  
**Prepared for:** Vladimir Reshetnikov  
**Format:** 28-page research article, with self-contained LaTeX source and an internal bibliography.

## Files

- `surcomplex_exponential_kernels.tex`: complete article source.
- `surcomplex_exponential_kernels.pdf`: compiled article, including contents and references.
- `verify.py`: standard-library-only exact finite sanity checks.
- `verification_results.json`: results of the included verification run.
- `build.sh`: compilation and verification helper.
- `README.md`: this guide.

## Main mathematical content

The central result constructs a normalized exponential on the surcomplex field whose kernel multiplier ring is exactly the ordinary integers. That ring is initial in the surreal simplicity tree but is not an integer part of the surreal field. The construction can preserve a character prescribed on any set-sized rational subspace of the purely infinite surreals.

The article proves an exact criterion: the multiplier ring is an integer part precisely when the normalized kernel is closed under multiplication. It constructs both split and nonsplit period extensions with minimal multiplier ring, reflects both constructions to arbitrarily large set-sized initial epsilon fragments, and gives a parameter-free first-order sentence separating them from the canonical exponential. It also proves that ordinary integers become parameter-free definable in the minimal examples, which omit a countable finitely satisfiable type. An explicit value-preserving shift automorphism gives a separate naturality obstruction for global phases.

## Relation to prior work

The principal question addressed is the first open question in Section 11.1 of Philip Ehrlich and Elliot Kaplan, *Surreal ordered exponential fields*, arXiv:2002.07739v3, printed page 34. The article refutes the sufficiency of initiality alone and provides an exact extra binary kernel condition. It does **not** resolve their subsequent question comparing exponentials induced by different initial embeddings of the same trigonometric-exponential field.

Repository snapshot inspected:

`465a54b479a1ee842cbf7db1689a7d2f6bfe25e1`

Repository: https://github.com/VladimirReshetnikov/Surreal

The finite-phase structure, the abstract classification by characters, and the unavoidable existence of infinite periods are already in `docs/surcomplex/trigonometry/article.tex`, Section 17. They are treated as prior results. The article records the scope of the repository audit and does not claim an exhaustive search of every report or historical revision. The repository was not modified or rebuilt.

## Build

A standard TeX Live or MiKTeX installation with pdfLaTeX and the packages named in the source is sufficient. The bibliography is internal; no BibTeX or external bibliography file is needed. No font files are included.

On a POSIX shell:

```sh
sh build.sh
```

Or manually, from this folder:

```sh
pdflatex -interaction=nonstopmode -halt-on-error surcomplex_exponential_kernels.tex
pdflatex -interaction=nonstopmode -halt-on-error surcomplex_exponential_kernels.tex
pdflatex -interaction=nonstopmode -halt-on-error surcomplex_exponential_kernels.tex
python3 verify.py --output verification_results.json
```

The Python script requires Python 3.10 or later and no third-party packages. On Windows, `python` may replace `python3`.

## Verification and review status

The included run passed **47,939 exact finite checks**. These cover compatible CRT residues, rational-character additivity, finite rational root towers, truncated coefficient identities for the shift automorphisms, and finite Laurent-polynomial instances of support separation. All arithmetic uses exact integers and fractions.

These checks are **not** a formal proof of the transfinite construction, arbitrary surreal-support claims, or the reflection theorem. The article supplies mathematical arguments for those claims. No new Lean proof was completed or built. The draft is AI-assisted, unrefereed, and not independently reviewed; novelty and priority remain provisional.

The delivered PDF was compiled without LaTeX warnings or unresolved references. Its layout was rendered and visually inspected, including the construction proof, the logic section, and the bibliography.
