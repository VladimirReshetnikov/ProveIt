# Curve Rigidity over Omnific Integers

**Logarithmic differentials, elliptic equations, and denominator ideals**  
Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Files

- `article.pdf`: the typeset 25-page manuscript.
- `article.tex`: standalone LaTeX source, including its bibliography.
- `verification.py`: supplementary exact symbolic and finite-support checks.
- `verification_report.json`: the recorded successful run.
- `SOURCE_AUDIT.md`: provenance, comparison scope, and proof boundaries.
- `requirements.txt`: the Python dependency used for the checks.
- `SHA256SUMS.txt`: checksums of the nine primary deliverable files.
- `build.sh` and `build.ps1`: build and check commands for Unix-like systems and PowerShell.

## Main results

The main theorem classifies smooth integral affine curves over an algebraically
closed characteristic-zero field that admit nonconstant points in the Hahn ring
of series supported on nonpositive exponents: precisely the affine line does.
No finite-support, rank-one, or divisible-group hypothesis is imposed.

An independent elementary theorem proves constant-solution rigidity for
`y^m = P(x)` when `m >= 2` and `P` is squarefree of degree at least two.
Consequently every omnific-integer solution of a nonsingular ordinary integral
short Weierstrass equation is an ordinary integer solution. A polynomial family
proves the sharp singular alternative.

Further theorems cover positive-genus projective curves, smooth proper varieties
with globally generated cotangent bundle, abelian and semiabelian varieties,
descent to separated models over the ordinary integers, and the exact obstruction
from noninvertible homogeneous-coordinate ideals.

## Scope and status

This is an AI-assisted research manuscript, not an independently refereed or
formally verified paper. Complete arguments are included. Their correctness and
priority remain appropriate subjects for independent review; the manuscript does
not certify a historic breakthrough or the resolution of a published major
conjecture.

The explicit repository target is the nonsingular Weierstrass case of Question
14.1 in the omnific Diophantine report, together with its broader smooth affine
curve question, at commit:

`89bec380b218c0a5bb865f53a86f5abf7f8fb5ad`

The results do not assert rigidity over the entire surreal or surcomplex field,
do not classify all singular curves or higher-dimensional affine varieties, and
do not settle primitive non-unimodular Fermat triples. Full-class notation is
interpreted through set-sized workspaces, not through proper-class spectra.

## Build

Use a LaTeX distribution with `latexmk`, `pdflatex`, Latin Modern, the AMS packages,
`microtype`, `geometry`, `booktabs`, `longtable`, `enumitem`, `fancyhdr`, `hyperref`,
`xurl`, `aliascnt`, and `cleveref`. No external bibliography processor is required.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Without `latexmk`, run `pdflatex` three times so that the contents and references
stabilize. The source contains no external images or private font dependencies.

To repeat the supplementary checks with Python 3.9 or later:

```sh
python -m pip install -r requirements.txt
python verification.py
```

The supplied run used SymPy 1.14.0 and passed 49 recorded checks, including
35 differential-ideal certificates and 400 seeded finite-support trials.
These computations are not formal verification of the arbitrary-support or
algebraic-geometric theorems. No Lean build was performed.

The build scripts assume the required programs are already installed. They do
not download or install software automatically.
