# Set-Sized Shadows of Omnific Arithmetic

**Universal quotients, numerical polynomials, p-adic characters, and surcomplex lattice rigidity**

Research manuscript dated 22 September 2026. The PDF has 26 pages. Its LaTeX
source is self-contained, including the bibliography.

## Files

- `omnific_arithmetic.pdf`: the complete article.
- `omnific_arithmetic.tex`: editable LaTeX source, with embedded references.
- `checks.py`: deterministic exact-arithmetic regression checks.
- `check_results.txt`: output of the successful supplied check run.
- `requirements.txt`: the SymPy version used for that run.
- `Makefile`: build and check targets.

## Main results

Theorem 3.4 proves that every class ring homomorphism from the full omnific
integer ring Oz to a set-sized ring factors through constant coefficient
Oz -> Z. No continuity, order preservation, summation preservation, or
finite-dimensionality is assumed. The theorem also covers Gaussian omnific
integers and a general class Hahn construction with a coefficient subring.
Theorem 3.3 isolates the quantitative monomial-difference obstruction that
proves it.

The principal consequences and extensions are:

* Theorem 4.2: every set-sized quotient presentation of Oz is Z or Z/nZ,
  with the explicitly identified class ideal as kernel.
* Theorems 4.5 and 4.7: set-carrier Oz-modules are ordinary abelian groups;
  derivations into such modules vanish.
* Theorems 5.2, 5.3, and 5.5: exact descriptions of real and Gaussian
  omnific-integer-valued polynomials, including the real finite-grid test.
* Theorem 5.7: the ordinary integer-valued polynomial ring is the universal
  set-sized image of the omnific numerical-polynomial ring.
* Theorem 6.3: a finite lcm/Newton coefficient criterion handles every
  omnific congruence modulus, including infinite ones.
* Theorem 7.3 and Corollary 7.4: the p-adic completion is the ring of
  continuous Z_p-valued functions on Z_p^r. This is not called a profinite
  completion: the finite-level polynomial-ring quotients are infinite.
* Theorem 7.6: all characters to F_p are parametrized by p-adic tuples;
  noninteger parameters do not arise by evaluation at omnific tuples.
* Theorems 8.4 and 8.5: nonlinear polynomial images on the real or Gaussian
  omnific lattice have holes of every prescribed surreal radius.
  Corollary 8.6 classifies rational bijections as affine maps with unit slope.

## Build

A normal TeX Live installation with Latin Modern and the packages named in
the preamble is sufficient. No custom font files or external bibliography
processor are required.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error omnific_arithmetic.tex
```

Alternatively run `pdflatex omnific_arithmetic.tex` three times to settle
cross-references and the contents page. `make pdf` runs the latexmk command.

## Run the exact finite checks

Python 3.10 or newer is required.

```sh
python -m pip install -r requirements.txt
python checks.py
```

The delivered run used Python 3.13.5 and SymPy 1.14.0. It passed 171,395
reported test cases, with additional internal guards. The code checks
finite symbolic identities, modular indicator formulas, Newton
reconstruction, and finite geometric products. It does not implement
arbitrary surreals or formalize the class-sized theorems.

## Provenance and research status

Repository inspected: VladimirReshetnikov/Surreal, snapshot
`a5c2a97df4b545dfe7f4cb8c11e4efed83101f6e`.
The exact reading scope is stated in Section 10. It includes repository
indexes and relevant foundational/status material; it is not represented
as an exhaustive read of every report and archive.

The article acknowledges the repository's related group-theoretic
small-quotient result and separately cites classical work on omnific
factorization, binomial rings, integer-valued polynomials, and congruence
preservation. The central ring theorem was not located in the targeted
review; that is a bounded novelty assessment, not a guarantee of priority.
No named factorization conjecture is claimed to be resolved here.

This is an AI-assisted research manuscript with full written proofs. It has
not been independently refereed or verified in Lean. Passing the finite
checks does not change that status. In particular, the distinctions between
set and class targets, strong Hahn sums and topological limits, and constant
coefficient and standard part are essential assumptions, not optional
interpretations.
