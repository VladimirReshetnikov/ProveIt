# Omnific Integers Do Not Determine Surreal Monomials

**Exact support-cut stabilizers, fixed fields, and parameterwise nondefinability**  
Research article prepared for Vladimir Reshetnikov, 23 September 2026.  
Author: OpenAI ChatGPT. The delivered PDF has 27 pages.

## Principal results

The paper characterizes the strongly coefficient-linear, leading-term-fixing
Hahn automorphisms preserving the subring `R_D = D + I`, where `I` consists
of series with strictly positive exponents. In a divisible ordered exponent
group, every shift `h` in the image of a positive monomial with exponent `g`
must satisfy `n*h < g` for every positive integer `n`. This condition is also
sufficient. It gives an exact Archimedean/non-Archimedean rank dichotomy in
that automorphism factor.

Explicit frozen-shift twists have a proved support bound, two-sided inverses,
an additive composition law, and an exact fixed-field formula. The fixed
field consists of series supported in the kernel of the exponent functional.
A leading-displacement formula excludes nontrivial finite orbits and proves
relative algebraic closedness of the fixed field.

On the full surreal class, coefficient extraction on the exponent group
produces automorphisms fixing any prescribed set of parameters, all real
constants, all leading terms, and the omnific-integer predicate. They send a
suitable monomial to a two-term omnific integer. Consequently the monomial
class, the omega-map, simplicity, and Gonshor exponential are not first-order
definable from the ordered field and its omnific integer part, even with any
set of parameters and the three signed normal-form projections named. There
are also support-confinement results for definable closure and a Gaussian
extension preserving the real axis and conjugation.

## Files

- `article.tex`: standalone LaTeX source with an internal bibliography.
- `article.pdf`: the compiled 27-page article.
- `verify.py`: exact finite checks, Python 3.9+ and standard library only.
- `verification.json`: actual check output; **28,668 assertions passed**.
- `source_audit.md`: repository/literature scope, attribution, proof checks,
  and limits on novelty.
- `build_audit.json`: build, PDF integrity, rendering, and checksum metadata.
- `Makefile`: build, check, and cleanup commands.

## Reproduce

```sh
make
make check
```

Without Make:

```sh
pdflatex -halt-on-error -interaction=nonstopmode article.tex
pdflatex -halt-on-error -interaction=nonstopmode article.tex
pdflatex -halt-on-error -interaction=nonstopmode article.tex
python3 verify.py
```

The TeX source uses the packages in its preamble, including `newpxtext`,
`newpxmath`, `microtype`, `amsmath`, `amsthm`, `mathtools`, `hyperref`,
`cleveref`, `needspace`, and `longtable`. No separate bibliography program or
network connection is required to compile or run the checks.

## Research and verification status

This is a research draft with complete written arguments, not a refereed or
Lean-verified paper. The exact stabilizer/fixed-field/parameter-fixing package
is proposed as new; a targeted search cannot certify priority. General Hahn
automorphism theory, the ambient valued decomposition, simplicity rigidity,
and the repository's coefficient-field and fraction-field reconstruction
are explicitly credited as prior work. No named published open conjecture
is claimed to be solved.

The repository comparison is pinned to commit
`58cd8e1c8259a3b9626e009bb994b153fec9a417`. It involved the collection guide,
relevant report guides, and the supplementary reconstruction source audit,
not an exhaustive read of every manuscript. The independent proofs in this
article do not require the correctness of unreviewed repository results.

The finite tests check algebraic identities and truncated examples. They do
not prove arbitrary Hahn summability, class-sized constructions, or
model-theoretic nondefinability. The original repository was not modified.
