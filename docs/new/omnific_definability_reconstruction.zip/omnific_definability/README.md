# Definable Arithmetic and Coefficient Reconstruction in Omnific Integer Rings

**Pell rigidity, explicit Diophantine formulas, and the real–Gaussian asymmetry**  
Research article prepared with ChatGPT, 23 September 2026.

The package contains a 24-page article with written proofs, an inline bibliography,
reproducible finite sanity checks, and a source/novelty audit. It is an unrefereed
research draft, not a Lean-verified contribution.

## Main results

The real omnific ring is denoted Oz; its Gaussian extension is Oz[i].

1. The equation `exists y: x^2 = 2*y^2` defines the purely infinite ideal in
   both rings.
2. One integer-coefficient polynomial of total degree five, with seven
   existential witnesses, defines the ordinary integers inside Oz.
3. Three integer-coefficient equations, with five existential witnesses,
   define the ordinary Gaussian integers inside Oz[i]. This is a finite
   system; it is not silently replaced by a sum of squares.
4. The constant-term retractions have Diophantine graphs. The real graph
   admits a single degree-ten polynomial with eight witnesses.
5. The multiplier ring of the purely infinite ideal, inside the fraction
   field, is exactly the nonnegative-exponent series ring. Its units,
   together with zero, recover the actual coefficient field.
6. Consequently the pure ring Oz reconstructs No, its canonical real
   coefficients, its order, its natural finite valuation ring, and standard
   part. Every automorphism of Oz fixes those real coefficients pointwise.
7. The Gaussian analogue recovers complex coefficients but not the surreal
   real axis: a coefficient-fixing phase twist preserves Oz[i] and sends
   omega to i*omega.

The main arithmetic and multiplier arguments also hold for the specified
set-sized Hahn rings. The manuscript states the exact hypotheses and does
not identify their fraction fields with whole Hahn fields without proof.

## Novelty and proof status

First-order definability of the ordinary integers in Oz, and nonsaturation
of Oz, have an explicit 2018 MathOverflow precedent credited in the paper.
These are not claimed as new. The proposed contributions are the explicit
positive-existential formulas, the order-free Gaussian construction, and
coefficient reconstruction through the multiplier ring.

The intersective polynomial used for the Gaussian certificate is classical.
Phase twists already occur in the Surreal repository's automorphism report;
the manuscript credits this and verifies the additional preservation of
Oz[i]. Historical priority for the proposed theorem package is not guaranteed.
No named classical factorization conjecture is claimed to be resolved.

The proofs are written mathematical arguments. Finite checks validate
identities and examples, not universal statements over infinite supports.
No Lean formalization or independent repository build was performed.

## Files

- `article.pdf`: typeset article, 24 pages including front matter.
- `article.tex`: self-contained LaTeX source with bibliography.
- `SOURCE_AUDIT.md`: comparison scope, prior work, and non-claims.
- `code/verify.py`: exact finite checks; Python 3.10+ and SymPy.
- `data/verification.json`: recorded output from the supplied check program.
- `data/build_report.json`: compilation and rendering summary.
- `requirements.txt`: the SymPy version used for the checks.
- `Makefile`: build and check commands.

## Rebuild

A LaTeX installation with `latexmk`, pdfLaTeX, and the packages named in the
source is sufficient. No external bibliography processor, images, or font
files are required in this package.

```sh
make pdf
```

Equivalently:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=_build article.tex
cp _build/article.pdf article.pdf
```

## Rerun checks

```sh
python -m pip install -r requirements.txt
python code/verify.py --output verification-rerun.json
```

The default ranges are all moduli 1 through 500 for the Pell unit-order test
and all moduli 1 through 2000 for the intersective-polynomial root test. The
program also checks the polynomial degrees, the complete displayed real
examples, six Gaussian examples, the four-square product identity, and
finite-support ideal/twist identities. It writes only to the path explicitly
provided, so the recorded evidence can remain unchanged.

## Repository snapshot

The source comparison is pinned to:

`71e9606d297c9b98c732070dc462682cc6948981`

in `VladimirReshetnikov/Surreal`. It is a focused catalogue and relevant-report
comparison, not an exhaustive audit of all repository mathematics. The
package does not modify the repository.
