# Algebraic Rigidity and Topological Collapse of Surreal Arithmetic

**Hahn summation, omnific integer topologies, and the discrete-exponent boundary**

Prepared for Vladimir Reshetnikov, 23 September 2026.

## Files

- `Surreal_Arithmetic_Topological_Collapse.pdf`: the 29-page article.
- `Surreal_Arithmetic_Topological_Collapse.tex`: standalone LaTeX source with an internal bibliography.
- `SOURCE_AUDIT.md`: source comparison, the repository update, and exact claim boundaries.
- `verify.py`: reproducible finite checks using Python's standard library.
- `verification.json`: the actual run, with 27,139 exact assertions passing.
- `Makefile`: build and check commands.
- `BUILD_AUDIT.json`: compilation and visual-review record.

## Proposed new results

The mathematical contribution is an exact topological obstruction, not a claim that surreal arithmetic has no Hausdorff topology.

1. If the exponent group is densely ordered, every jointly continuous ring topology on `o + Pi_k` realizing all Hahn sums as limits is pulled back from a ring topology on `o` along the constant-term homomorphism.
2. In particular, such topologies on `Oz` and `Oz[i]` see only `Z` and `Z[i]`. No such omnific topology is Hausdorff. For the full omnific rings, countable monomial null sequences already force this classification.
3. On `No` and `No[i]`, every such ring topology is indiscrete.
4. A set-sized full Hahn field `k((t^Gamma))` admits a Hausdorff Hahn-compatible ring topology exactly when `Gamma` is trivial or order-isomorphic to `Z`. A discrete noncyclic group such as lexicographic `Z^2` is not an exception.

The proofs use a dense-interval covering obstruction, the closure-of-zero ideal, and an elementary ordered-group lemma. They do not assume continuity of the coefficient map or a valuation.

## The repository update matters

The initial consulted version of the omnific-automorphism report still asked whether all omnific automorphisms are strongly additive. A renewed directory read found newly added companions 12 and 13 already giving the affirmative answer and related scalar-duality results. The article explicitly credits these and does not claim automatic strongness as a new resolution. Its proposed new contribution is the universal topological collapse and classification above.

The included proof of automatic strongness is useful for the resulting contrast: omnific arithmetic algebraically forces preservation of all formal Hahn sums, but a jointly continuous ring topology realizing all of those sums loses the purely infinite information.

## Build and checks

Requires Python 3.9 or newer and a conventional TeX Live installation with pdfLaTeX, latexmk, Latin Modern, amsmath, amsthm, microtype, hyperref, cleveref, xurl, geometry, enumitem, fancyhdr, and aliascnt.

```sh
make
make check
```

No external bibliography file or network download is needed. The source uses installed TeX fonts; no font files are included.

## Verification and limitations

The article supplies complete written proofs. They have not been independently refereed or checked in a proof assistant. Historical priority is not certified. The source comparison was targeted, not an exhaustive audit of the entire repository or literature.

The Python checks validate finite algebraic identities, support manipulations, and order-reflection steps. They are **not** proofs about infinite supports, arbitrary topologies, or proper classes. In particular, a finite mesh cannot test the infinite dense-interval obstruction.

The 12 further research questions include nondense truncated support rings, minimal forbidden summation families, Gaussian automatic strongness, restricted support fields, and a proposed formalization interface.
