# Gamma and Zeta on the Surcomplex Horizontal Tube

**Strong Dirichlet sums, omnific divisors, and arithmetic independence**  
Research article, September 22, 2026 — 34-page PDF.

## Contents

- `article.pdf`: the complete article, with proofs, examples, notation, and references.
- `article.tex`: self-contained LaTeX source; no external figures or bibliography database.
- `code/verify.py`: exact finite symbolic and arithmetic checks.
- `data/verification.json`: the recorded successful run (1,670/1,670 checks).
- `data/build-quality.json`: PDF build and layout checks.
- `requirements.txt`: the tested symbolic-computation dependency.

## Mathematical scope

The principal domain is the class of surcomplex numbers with finite imaginary
part. The construction combines canonical finite Taylor–Laurent halos, an exact
strongly summed Stirling logarithm, strong Dirichlet sums at positive-infinite
real part, and reflection using an explicitly specified global phase.

Theorem 6.1 identifies Gamma's poles. Theorem 8.2 identifies zeta's zeros and
pole. For the canonical Ehrlich–Kaplan phase, the Gamma poles are exactly the
nonpositive omnific integers, and the trivial zeta zeros are exactly the negative
even omnific integers. Theorem 9.1 proves that completion cancels all additional
infinite divisors: the completed xi function on this domain has precisely the
ordinary nontrivial zeta zeros, with the same multiplicities.

Theorem 10.6 proves algebraic independence of all ordinary-real-shift zeta jets
at an infinite Conway monomial X over the explicit field

    C((X^(-R)))(exp(-lambda X): lambda in R)(exp(X log X)).

This field contains Gamma(X+b) for every ordinary real b. The theorem does NOT
assert that the Gamma values themselves are independent.

Section 11 develops an exact infinite-parameter Euler–Maclaurin/Hurwitz model,
including its difference and distribution identities, Bernoulli values,
zero-freeness at finite spectral arguments, and its log-Gamma derivative at zero.
Proposition 13.1 additionally extends the canonical right-infinite Dirichlet
branch to unrestricted imaginary parts, without claiming a completed extension
on the central infinite-height vertical region.

All sums are set-indexed strong Hahn sums. A pole is a Laurent germ, not a field
value called infinity. Derivatives are argument derivatives, not automatically
Berarducci–Mantova scalar derivatives. The Riemann hypothesis is not proved.

## Provenance and status

The focused repository review used the snapshot
`804c63c2c675be9fd4e5086460bfa795f17a6d86` of
`VladimirReshetnikov/Surreal`. The article identifies the actual review scope.
Published inputs include Costin–Ehrlich, Ehrlich–Kaplan, the NIST DLMF, and Pong's
arithmetic-function independence results. The canonical surcomplex exponential
and the classical arithmetic independence antecedents are explicitly credited.

The article is an unrefereed research draft. Its mathematical arguments and its
finite symbolic checks are separate forms of evidence. No proof-assistant
verification or exhaustive novelty certification is claimed.

## Build the PDF

Use a standard TeX distribution with the packages listed in `article.tex`:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex` repeatedly until references stabilize. The recorded
build has no LaTeX warnings, undefined references, overfull or underfull boxes,
or missing characters. All 34 pages were rendered and inspected in contact
sheets, with selected mathematical pages and the title viewed at larger scale.

## Rerun the exact checks

Python 3.10 or later and SymPy are required. The recorded environment was
Python 3.13.5 and SymPy 1.14.0. There is no network access in the checking program.

```sh
python -m pip install -r requirements.txt
python code/verify.py --output verification-rerun.json
```

The default output is `verification-rerun.json`, not the shipped record. The
program refuses to overwrite an existing output unless `--overwrite` is supplied.
Exit status is zero only when every check passes.

The checks concern finite Bernoulli identities, Stirling and Hurwitz
coefficients, finite prime-Jacobian identities, and finite Dirichlet arithmetic.
They do not computationally prove strong summability, class quantification,
infinite algebraic independence, or novelty. See `data/verification.json` for
actual counts and truncation bounds.
