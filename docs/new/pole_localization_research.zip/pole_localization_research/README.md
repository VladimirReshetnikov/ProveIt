# Pole Localization and Omnific Interpolation

**Explicit bundle trivializations, persistent line classes, and a surcomplex Bézout obstruction**  
Prepared for Vladimir Reshetnikov, September 23, 2026.

## Read first

`article.pdf` is the 27-page article. `article.tex` is its complete editable source, including the bibliography. The article has full written proofs and nine proposed research questions, plus a concrete formalization route.

The main result gives a determinant-one Laurent trivialization of the exact rank-three pole-only example in the inspected Surreal repository. The more general construction treats descending positive exponent profiles with finite-order pole coefficients and one fixed nilpotent matrix. It does not classify arbitrary noncommuting pole cocycles.

The same construction gives persistent line and extension classes, an explicit omnific-valued cardinal-sine family, an unsolvable reciprocal interpolation problem, a proper nonprincipal locally unit ideal, a quotient of projective dimension two, explicit ultrafilter maximal ideals and residue fields, and an exact finite-halo zero classification.

The coefficient category is essential: the functions are common-domain holomorphic Hahn families, interpreted on finite surcomplex halos by Taylor prolongation. The article does not claim evaluation at arbitrary infinite surcomplex arguments. “Integral” in the bundle statements means nonnegative Hahn valuation, not membership in the omnific integers.

## Files

- `article.pdf`: compiled article.
- `article.tex`: self-contained LaTeX source.
- `verify.py`: reproducible exact finite symbolic checks.
- `verification_results.json`: delivered run, **215/215 checks passed**, SymPy 1.14.0.
- `requirements.txt`: the tested symbolic-computation dependency.
- `SOURCE_AUDIT.md`: repository pin, source comparison, references, and novelty boundary.
- `build_report.json`: compilation and layout-inspection record.
- `SHA256SUMS`: checksums of the delivered component files.

## Rebuild the PDF

A standard TeX Live or MiKTeX installation with the listed LaTeX packages is sufficient. No external figures or font files are needed.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` repeatedly until the references stabilize. The bibliography is embedded; BibTeX is not required.

## Run the finite checks

Python 3.9 or later and SymPy are required.

```sh
python -m pip install -r requirements.txt
python verify.py
```

The program writes `verification_results.json` next to the script by default. To preserve the delivered report:

```sh
python verify.py --output verification_results_rerun.json
```

A failed identity or an execution error produces a nonzero exit status and a report marked `FAIL`. The successful checks cover finite matrix identities, symmetric powers in degrees 1 through 6, finite-node pole cancellation with simple and multiple poles, cardinal-sine formulas, and finite support sanity checks.

## Status

This is an unrefereed AI-assisted research manuscript. The proofs have not been independently peer reviewed or formalized in Lean. The finite tests do not verify infinite support arguments, Weierstrass existence, sheaf cohomology, or the transfinite implicit recursion. Those arguments are in the article.

The resolved question is the specific repository boundary at the pinned version described in `SOURCE_AUDIT.md`, not a named classical conjecture. The results are proposed research contributions; a targeted literature search does not certify novelty or publication priority.
