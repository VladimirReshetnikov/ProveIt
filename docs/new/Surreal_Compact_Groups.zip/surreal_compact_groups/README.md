# Small Representations and Normal Structure of Surreal Compact Groups

Prepared for Vladimir Reshetnikov, 23 September 2026.

## Contents

- `article.tex`: standalone LaTeX source with an internal bibliography.
- `article.pdf`: compiled 24-page article, including title, contents, and references.
- `verify.py`: exact finite matrix, Lie-algebra, formal-series, and enumeration checks.
- `verification_results.json`: the delivered run; all 33 named checks passed.
- `SOURCE_AUDIT.md`: sources inspected, overlap with the repository, and novelty limits.
- `requirements.txt`: Python dependency for the finite checks.
- `build.sh`: optional build helper.

## Main result

For a connected real linear algebraic group G whose real points are compact
and connected, write mu_G for the kernel of standard part on G(No). Let S be
its connected semisimple derived group and Z its connected central torus.

The article gives detailed proofs that every homomorphism from G(No) into any
set-sized group kills mu_S, and that these are exactly the elements invisible
to all such homomorphisms. A separating class quotient is G(R) x mu_Z.
Consequently a universal set-sized quotient exists if and only if G is
semisimple, in which case it is standard part G(No) -> G(R).

The supporting results include exact one-scale normal generation in simple
compact Lie type, ambient-normal valuation-cut classification, mixed
commutator-subgroup equalities, and perfect residuals. The article separately
proves triviality of all set-sized images of SL_n(No) and SL_n(No(i)), and
explains the finite integral collapse of compact omnific matrix groups.

## Build

Use a standard TeX Live installation with pdfLaTeX. No external figures or
bibliography file are needed.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

To reproduce the finite checks:

```sh
python -m pip install -r requirements.txt
python verify.py
```

Alternatively, `sh build.sh` runs the checks followed by LaTeX. The delivered
PDF was compiled with no unresolved-reference, overfull-box, or underfull-box
warnings in the final log. Rendered pages were inspected, including all-page
layout contact sheets and full-size key pages.

## Research status

This is an AI-assisted research manuscript, not an independently refereed or
Lean-verified paper. The finite program checks do not prove the general
Nash-transfer or class-theoretic arguments. The article identifies classical
and repository precedents, including the prior SO(3), SO(n), SU(n), and
circle/U(n) results. The all-compact-group small-observation classification
and exact semisimplicity criterion are the main candidate-original package;
historical priority is not certified. No named longstanding open problem is
claimed solved.

Repository comparison was pinned to:
`9693b28c24e6fcb317ce47969a40185c5dfef402`.
