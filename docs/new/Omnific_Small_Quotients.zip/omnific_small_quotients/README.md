# What Small Rings Can See of Omnific Integers

**Universal quotients, invisible equations, and sharp cardinal models**  
Research manuscript prepared with ChatGPT — 22 September 2026.

The article is 26 PDF pages, including the title page, linked table of contents,
source audit, notation appendix, and bibliography.

## Files

- `omnific_small_quotients.tex`: self-contained LaTeX source, with an inline bibliography.
- `omnific_small_quotients.pdf`: compiled article.
- `SOURCE_AUDIT.md`: repository snapshot, source comparison, and novelty limitations.
- `finite_checks.py`: exact finite checks using only the Python standard library.
- `finite_checks.txt`: recorded output; all 1,277 finite test cases passed.
- `BUILD_REPORT.md`: compilation and document-quality checks.

## Main results

Theorem 4.3 proves that every ring homomorphism from the full omnific-integer
ring Oz to a set-sized ring factors through its constant-coefficient retraction
Oz -> Z. The theorem includes nonunital maps and noncommutative targets. Theorem
5.1 gives the Gaussian analogue Oz[i] -> Z[i]. Consequences concern quotient
rings, small modules, derivations, localizations, finite-congruence ideal
closures, and monic equations whose lack of omnific roots is invisible in every
set-sized target.

Theorem 10.1 constructs, for **every infinite cardinal kappa**, a truncation-closed
real closed subfield F_kappa of No with integer part A_kappa = F_kappa intersect
Oz, both of cardinality kappa. Every map from A_kappa to a smaller ring factors
through Z. The positive-support ideal needs exactly cf(kappa) generators.
Characteristic-zero maximal residue fields exist and have cardinality exactly
kappa. The construction handles singular cardinals without CH, GCH, or a
strong-limit assumption.

## Rebuild

A standard TeX Live installation with pdfLaTeX and latexmk is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error omnific_small_quotients.tex
```

The source uses standard mathematical and typography packages, including
amsmath, amsthm, mathtools, microtype, hyperref, xurl, fancyhdr, and tocloft.
There are no external figures, bibliography databases, or custom font files.

Run the finite checks with Python 3.10 or later:

```sh
python finite_checks.py
```

## Mathematical and novelty status

Complete mathematical proofs are supplied after explicitly stated standard
Conway–Hahn prerequisites. The two main universal-quotient/cardinal-construction
formulations are candidate-original results, not certified historical priority
claims. The text distinguishes them from familiar coefficient retractions,
binomial series, and published higher-scale divisibility results.

The work has not been independently refereed or checked by a proof assistant.
The finite tests do not certify infinite Hahn summation, proper-class arguments,
real closedness, or the cardinal construction. This article does not claim to
resolve the broad outstanding factorization problems for omnific integers.

No changes were made to the source GitHub repository.
