# Recovering Surreal Coefficients from Monomial Extensions

**Quartic definitions, arbitrary-rank rigidity, and sharp cancellation**  
Prepared for Vladimir Reshetnikov, 23 September 2026.

## Read the article

`article.pdf` is the 24-page article; `article.tex` is its standalone LaTeX
source, with an internal bibliography. There are four main theorems, full
proofs of the elementary arguments, further reconstruction and automorphism
results, explicit counterexamples, a dependency table, a proof-obligation
checklist, and eleven further research questions.

The objects are finite-support group/monoid algebras and their fraction
fields. The parameter groups and monoids are sets, of arbitrary rank.
Coefficient rings can be the literal surreal, surcomplex, omnific, and
Gaussian omnific classes. These extensions are **not Hahn completions**.

## Principal results

* A single existential quartic formula recovers a real-closed or
  algebraically closed characteristic-zero coefficient field F inside
  Frac(F[G]), for every torsion-free abelian group G. A denominator-cleared
  existential formula recovers Oz and Oz[i] in their cancellative
  torsion-free monoid algebras. See Main Theorem A and Sections 3–4.
* A nonmonomial fraction P/Q cannot become an nth power in any rational
  monomial extension unless n is at most max(weight(P), weight(Q)) − 1.
  The bound is sharp and independent of rank or new exponent denominators.
  See Main Theorem B and Section 5.
* Every field automorphism of Frac(F[G]) is semilinear monomial exactly
  when Hom(G,Z)=0, under the closed-field hypotheses. The general result
  uses Lin–Wang's defect-freeness theorem; divisible and certain prime-local
  groups have an independent proof here. See Main Theorem C and Section 8.
* For the parameter groups Q^(kappa), coefficient-preserving cancellation
  against arbitrary comparison rings/fields holds exactly at finite rank.
  Explicit absorption examples prove failure at every infinite cardinal.
  See Main Theorem D and Section 9.

The article also recovers the pair (closed coefficient field, exponent
group) from the fraction field, gives group-algebra and divisible-monoid
automorphism formulas, and shows why the quartic detector fails upon
passage to Hahn series.

## Status and provenance

This is a proof-bearing research draft, not a refereed or formally verified
paper. Historical priority is not certified, and no named Conway
factorisation conjecture or unrestricted surreal automorphism problem is
claimed solved. The general defect theorem and two-frame reconstruction
method are explicitly credited to Lin and Wang. The classical polynomial
abc and sparse multiplicity arguments are reproved. The earlier manuscript
*Algebraic-Parameter Rigidity of the Omnific Integers* is credited rather
than repackaged as new. `SOURCE_AUDIT.md` records sources and exact limits.

## Reproduce

Python 3.9 or later is sufficient for the checks; no third-party Python
package is required:

```sh
python verify.py --output verification.json
```

The delivered run passed **1,314 exact checks**. These are finite tests,
not formal proofs of arbitrary-rank or class-sized assertions.

To rebuild the PDF, install a standard TeX Live or MiKTeX distribution
with the packages listed at the beginning of `article.tex`, then run:

```sh
python build.py
```

This runs the checks and pdfLaTeX three times, writing compiler transcripts
to `build_logs/`. Alternatively, run `pdflatex article.tex` three times.
No bibliography processor or external figure files are needed. The build
script intentionally updates the PDF and verification report; it does not
update the delivery-specific audit or hash manifest. PDF metadata timestamps
can differ even when the mathematical content is unchanged.

## Package contents

`article.tex`, `article.pdf`, `README.md`, `SOURCE_AUDIT.md`, `verify.py`,
`verification.json`, `build.py`, `build_report.json`, and `SHA256SUMS.txt`.
The ZIP contains no external papers, repository checkout, font files, or
intermediate LaTeX files. Font subsets are embedded normally in the PDF.
