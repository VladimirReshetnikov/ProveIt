# Automatic Hahn Linearity of Omnific Isomorphisms
## Residue duality, full stabilizers, and coefficient-drifting self-embeddings

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.

## Read the article

`article.pdf` is the typeset article. `article.tex` is its self-contained LaTeX
source, including the bibliography. No repository checkout or external `.bib`
file is needed to compile it.

The main results are:

- **Theorems 3.3 and 4.1:** Hahn summability is detected by constant-term
  products, already using countably supported binary multipliers. A
  constant-term-compatible field isomorphism preserving its coefficient
  field is automatically strongly additive.
- **Theorem 6.1:** Every abstract ring automorphism of the omnific integers
  extends uniquely to a strongly real-linear automorphism of the surreal
  field. This removes the strongness hypothesis from the existing real
  omnific stabilizer description (Theorems 7.1–7.2).
- **Theorems 8.1 and 8.3:** Residue representation and an adjoint
  characterization of strong linear maps for set-sized full Hahn fields.
  Example 11.2 explains the proper-class obstruction to the converse.
- **Theorem 9.5 and Corollary 9.7:** A proper, strongly additive embedding
  of `(No, Oz)` sends any chosen transcendental real `b` to `b + omega^(-1)`
  and sends `omega` to `omega^omega`. The omnific predicate is both
  preserved and reflected. Even its restriction to the real coefficient
  field extends to no automorphism of the pair.
- **Theorems 10.1–10.2:** Surcomplex analogues, either with conjugation
  named or with valuation compatibility assumed. Arbitrary Gaussian
  automorphisms without these hypotheses are not classified.

Section 12 proposes ten further research questions. Section 13 distinguishes
proofs, finite calculations, established ingredients, and proposed novelty.

## Status

This is an AI-assisted, unrefereed research manuscript with mathematical
proofs, not a proof-assistant-certified result or a certified resolution of a
named classical conjecture. Historical priority has not been established.
Earlier repository results about omnific fractions, coefficient reconstruction,
strong stabilizers, and shears are explicitly credited and are not presented
as new discoveries. See `SOURCE_AUDIT.md` for the scope of the comparison.

All Hahn supports and summation families are sets. Claims about all surreal
maps are interpreted as class-map statements in the stated class foundations.
The scalar strong-dual representation theorem is explicitly restricted to
set-sized exponent groups. The real automorphism theorem is not restricted
to set-sized exponent groups.

## Reproduce the finite checks

Requires Python 3.10 or later; only the standard library is used.

```sh
python3 code/verify.py
```

The recorded run passes **13,885 exact assertions**. The program checks
finite Laurent identities, binary finite-row choices, residue adjoints and
retractions, and finite scale-separated Taylor models. It writes its report
to `data/verification.json` by default; another path can be supplied with
`--output`.

These calculations are supplementary. They do not verify infinite summability,
class foundations, transcendence bases, or the main theorem in Lean.

## Build the PDF

A standard TeX Live or MiKTeX installation with pdfLaTeX, Latin Modern,
AMS packages, microtype, geometry, hyperref, and the packages listed in the
preamble is sufficient.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

On a Unix-like system, `./build.sh` runs the finite checks, compiles in a
temporary directory, and replaces only `article.pdf` and the verification
report. It leaves no TeX auxiliary files in this directory.

## Files

- `article.tex`, `article.pdf`: complete article and source.
- `code/verify.py`: runnable exact finite checks.
- `data/verification.json`: recorded results and counts.
- `SOURCE_AUDIT.md`: source versions, comparison boundaries, and novelty status.
- `build.sh`: reproducible build wrapper.
- `BUILD_REPORT.json`: local build and PDF inspection record.

No repository files were modified. No repository Lean build was executed.
