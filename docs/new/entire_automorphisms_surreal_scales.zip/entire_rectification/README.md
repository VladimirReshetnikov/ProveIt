# Entire Automorphisms at Surreal Scales

**An order-unit dichotomy, omnific rectification, and exact fat-point ideals**

Research manuscript prepared for Vladimir Reshetnikov, 23 September 2026.
25 pages, with full proofs, a bibliography, and a bounded novelty assessment.

## Main results

For the fixed Hahn workspace K = k((t^Gamma)), where k is R or C with its
trivial valuation and Gamma is a nonzero set-sized divisible ordered abelian
group, an entire series means whole-family strong Hahn summability at every
point of that workspace.

1. In dimension d >= 2 and with cf(Gamma) = aleph_0, every radially finite
   configuration is sent into a coordinate line by an entire automorphism
   if and only if Gamma has an order unit.
2. Without an order unit, an explicit escaping sequence of infinitesimal
   d-simplices cannot be sent into any affine hyperplane. The proof uses
   eventual polynomial reduction of an entire automorphism and its inverse
   along a convex-subgroup exhaustion.
3. Every radially finite configuration with coordinates supported in
   Gamma_{<=0} is nevertheless line-rectifiable. This includes the indicated
   real and Gaussian omnific fragments. The ambient coordinate automorphism
   is not asserted to preserve the omnific ring.
4. On a rectifiable configuration, a total-multiplicity fat-point ideal with
   maximum multiplicity M has exactly binomial(M+d-1,d-1) generators in a
   minimal generating family. Unbounded multiplicities imply non-finite-
   generation for d >= 2; dimension one remains principal.

## Contents

- `entire_rectification.tex`: standalone LaTeX source, bibliography included.
- `entire_rectification.pdf`: compiled 25-page manuscript.
- `verify.py`: exact finite symbolic checks, not a formal proof of the paper.
- `verification-results.json`: output of a successful verification run.
- `requirements.txt`: the tested SymPy version.
- `build.sh`: reruns the checks and compiles the manuscript.
- `SOURCE_AUDIT.md`: provenance, scope, and claim boundaries.
- `BUILD_REPORT.json`: compilation and PDF inspection results.
- `README.md`: this guide.

## Reproduction

Use Python 3.10+ and a reasonably complete TeX Live installation with
pdflatex, Latin Modern, AMS packages, hyperref, microtype, and the other
standard packages named in the source.

```sh
python3 -m pip install -r requirements.txt
sh build.sh
```

The checks were run with SymPy 1.14.0. They test finite cardinal interpolation,
linear division, normalized simplex determinants in dimensions two and three,
40 homogeneous-jet counting cases, and finite polynomial fat-point ideals.
They do not verify arbitrary-rank convergence or universal mathematical claims.

## Repository baseline

Pinned source repository commit:
`71e9606d297c9b98c732070dc462682cc6948981`

https://github.com/VladimirReshetnikov/Surreal/tree/71e9606d297c9b98c732070dc462682cc6948981

Existing one-variable entire-function results are credited as background;
the manuscript does not claim their rediscovery as a contribution.

## Status and limitations

This is an AI-assisted, unrefereed research draft. It supplies mathematical
proofs, but no Lean formalization and no claim of independent peer review.
The principal results are proposed new contributions relative to the inspected
repository and literature, not certified priority claims. No named published
conjecture is claimed to have been resolved.

All analytic conclusions are workspace-relative. They are not assertions
about a single entire-function theory on the full proper class No(i).
