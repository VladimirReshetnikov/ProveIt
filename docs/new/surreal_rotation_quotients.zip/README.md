# Valuation Cuts and the Universal Set-Sized Quotient of Surreal Rotation Groups

Research manuscript prepared for Vladimir Reshetnikov, 22 September 2026.

## Contents

- `article.pdf`: the typeset article.
- `article.tex`: standalone LaTeX source, including its bibliography.
- `verify.py`: exact finite-algebra verification program.
- `verification.json`: output of the executed verification program.
- `requirements.txt`: the SymPy version used for those checks.
- `SOURCE_AUDIT.md`: repository pin, source comparison, and limits of the novelty search.
- `build.sh` and `build.ps1`: optional compilation and verification helpers.

## Main results

The article gives a cut-sensitive commutator calculus for SO(3) over real
closed fields with their natural valuation, classifies normal subgroups of the
full rotation group, computes the lower-central and derived series of every
principal infinitesimal subgroup, and identifies the surviving perfect residual.

Its main surreal-specific result is that every class homomorphism

    SO(3, No) -> H, with H a set-sized group,

factors uniquely through standard part onto SO(3, R). Finite elimination extends
the factorization to SO(n, No), n >= 3, and SU(n, No(i)), n >= 2. No continuity
hypothesis is needed. An explicit coefficient character of the infinitesimal
angle shows that the analogous assertion fails for SO(2) and for U(n).

The class statements use NBG-style set/class foundations. A set-sized target
means a set in the same foundation. The paper distinguishes this from an
arbitrary higher-universe target in type theory.

## Compile

Use a current TeX distribution containing the standard packages in the preamble.
There are no external figures, font files, bibliography files, or shell-escape
requirements.

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Alternatively:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

## Run the finite checks

Python 3.9 or later and SymPy are required. The delivered output was generated
using Python 3.13.5 and SymPy 1.14.0.

    python -m pip install -r requirements.txt
    python verify.py --output verification.json

All 39 named checks passed. They consist of general polynomial/rational
identities and finite one-parameter examples. They are NOT a formal proof of
any universal valuation statement, normal-subgroup classification, transfinite
intersection, or proper-class theorem. The program raises an error on a failed
check, including when Python is run in optimized mode.

## Research status

This is an AI-assisted, unrefereed manuscript with detailed mathematical proofs.
It is not Lean-verified. The single-commutator theorem for the entire
infinitesimal kernel is already published and already in the repository; it is
explicitly credited. The proposed additions are the cut-sensitive structure,
its exact consequences, and especially the universal set-sized quotient result.
No named historical open problem is claimed solved, and no exhaustive priority
claim is made. See `SOURCE_AUDIT.md` and Section 1 of the article.

The normal-subgroup classification is for subgroups normal in the FULL SO(3)
group, not for arbitrary subgroups normal only in its infinitesimal kernel.
The universal factorization has the same important domain restriction.
