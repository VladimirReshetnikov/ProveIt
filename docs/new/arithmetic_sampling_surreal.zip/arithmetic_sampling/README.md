# Arithmetic Sampling in Surreal Hahn Fields

**Entire rigidity, coefficientwise algebraic division, omnific exceptional
loci, and a computability barrier**

24-page research manuscript, 23 September 2026.

## Main results

The setting is a fixed Hahn field `K = k((t^Gamma))`, with `k = R` or `C`,
and whole-family strong Hahn summation. Put `Pi = {series supported at
strictly negative exponents}`, `B = k + Pi`, and `A = D + Pi`, with `D = Z`
or `Z[i]`. In a compatible surreal normal-form realization, `A` is the
intersection with the real or Gaussian omnific integers.

| Result | Location |
|---|---|
| Exact coefficientwise lifting for polynomial matrices over `k[X]` | Theorem 4.3, p. 9 |
| Faithful flatness of the entire ring over `k[X]` | Theorem 4.5, p. 9 |
| Zariski-dense ordinary sampling with values in `B` forces polynomiality | Theorem 5.2, p. 10 |
| Exact arithmetic restriction to ordinary algebraic loci | Theorem 5.5, p. 11 |
| Entire integer-part preservers are `Int(D^d,D) + Pi[X]` | Theorem 6.2, p. 12 |
| A finite positive-tail ideal gives the exact ordinary exceptional locus | Theorem 7.2, pp. 13–14 |
| A sharp bound of `D0 + 1` actual scales in one variable | Theorem 7.4, p. 14 |
| The same finite scales control every finite jet order | Theorem 8.3, p. 15 |
| Every nonzero polynomial ideal has a nonpolynomial entire realization when `cf(Gamma) = aleph_0` | Theorem 9.2, pp. 16–17 |
| One-point omnific membership is undecidable in an explicit quadratic-growth family | Theorem 10.2, p. 18 |

Section 11 gives counterexamples marking the precise hypotheses.
Section 12 proposes ten further research questions.

## Status and scope

These are proposed research contributions supported by the written proofs.
They have not been independently refereed or verified in Lean. Historical
priority is not certified, and no named published conjecture is claimed to
have been settled. The source audit distinguishes established ingredients
and existing repository material from the proposed additions.

The main analytic distinction is essential: *strong Hahn summation is not
ordinary complex convergence*. Nonpolynomial results concern fixed
set-sized Hahn workspaces. An ordinary set-indexed power series that is
strongly entire on the full class `No` or `No[i]` is already polynomial;
Corollary 9.4 explains this boundary.

The finite exceptional-locus theorem is algebraic for `B`-valued points.
For `A`-valued points, the additional ordinary constant-term condition in
`D` must be retained. Leading valuation alone is not an omnific test.

## Files

- `arithmetic_sampling.tex`: standalone article source with bibliography.
- `arithmetic_sampling.pdf`: compiled article.
- `verify.py`, `verification.json`: exact finite checks and recorded output.
- `requirements.txt`: dependency for those checks.
- `build.py`, `build_report.json`: portable PDF build helper and recorded run.
- `SOURCE_AUDIT.md`: inspected sources, comparison, and verification limits.
- `ARTIFACT_MANIFEST.json`: final artifact hashes and PDF validation record.

## Build the PDF

Install a TeX distribution providing pdfLaTeX and the standard packages used
in the preamble. From this directory:

```text
python build.py
```

The helper compiles in a temporary directory, makes three passes, copies
only the resulting PDF back, and writes `build_report.json`. It does not
leave TeX auxiliary files in the deliverable directory. Standard packages
include `lmodern`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `hyperref`,
`aliascnt`, and `cleveref`.

A direct build also works:

```text
pdflatex -interaction=nonstopmode -halt-on-error arithmetic_sampling.tex
pdflatex -interaction=nonstopmode -halt-on-error arithmetic_sampling.tex
pdflatex -interaction=nonstopmode -halt-on-error arithmetic_sampling.tex
```

## Run the exact finite checks

Python 3.9 or later is required; the delivered run used Python 3.13.5 and
SymPy 1.14.0.

```text
python -m pip install -r requirements.txt
python verify.py --output verification.json
```

The delivered run passes **8,774 exact assertions in ten groups**. The
program uses rational and symbolic polynomial arithmetic, with random seed
20260923. These checks are not proofs of infinite summability, arbitrary-rank
lifting, faithful flatness, or undecidability. In particular, the finite
machine-family checks use specified bounded examples; they do not decide
whether arbitrary machines halt.

The positive finite algorithms also have limits. A finite coefficient list
permits computation of its positive-tail ideal over an effective field.
A general infinite stream does not provide a computable stopping rule for
that ideal. Theorem 10.2 proves this explicitly rather than assuming it.

## Repository reference

The targeted comparison used Vladimir Reshetnikov's Surreal collection at
commit `343dc2c471212bb9b53ff4623bace2e1943f255b`.
See `SOURCE_AUDIT.md` for exact paths and the extent of the inspection.
This package does not modify that repository and does not contain a copy of
its source tree or of external papers.
