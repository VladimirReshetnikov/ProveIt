# Surreal Fields Across Set-Theoretic Universes
## Exact Saturation, Forcing, and Surcomplex Real Forms

Research article prepared with ChatGPT, 22 September 2026.

## Files

- `surreal_universe_saturation.pdf`: the 25-page article, including cover, contents, complete written proofs, proof/priority audit, and 14 references.
- `surreal_universe_saturation.tex`: self-contained LaTeX source; the bibliography is embedded, so BibTeX is not required.
- `verify_finite_models.py`: standard-library Python checker for finite interval and sign-string constructions.
- `finite_check_results.txt`: saved output of a successful checker run.
- `Makefile`: optional convenience targets for the PDF and finite checks.
- `README.md`: this file.

## Main theorem

Work in an outer universe W satisfying ZFC, with a definable transitive inner model M satisfying ZFC and having the same ordinals. Types, parameter sets, and cardinalities are computed in W. For every uncountable W-cardinal kappa:

    No^M is externally kappa-saturated as an ordered field
        if and only if
    every W ordinal-valued sequence of length < kappa belongs to M.

The proof constructs a definable, absolute tree of nested surreal intervals with ordinal-labeled children. A new sequence whose proper initial segments are old gives an omitted cut of old numbers inside (0,1). Any old separator would decode the entire new sequence inside M.

The finite-parameter boundary is different: external aleph_0-saturation is equivalent to M and W having the same subsets of omega. The pure surcomplex field No^M(i) remains saturated over every W-set of parameters, whereas naming its conjugation restores exactly the old real field's saturation spectrum.

Further results identify the first new sequence length as a regular cardinal, translate the spectrum into a forcing-distributivity criterion, distinguish Cohen and Prikry extensions, and prove the old field is closed and nowhere dense inside the new field despite being elementary and cofinal. Under the explicit additional GBC/global-choice assumptions of Section 10, the article constructs nonconjugate real-field involutions on one pure surcomplex field, with elementarily equivalent expansions and different external saturation spectra.

## Reading guide

Sections 1-3 give the precise foundations, definitions, and classical inputs. Section 4 contains the main ordinal-branch interval construction. Sections 5-8 prove the exact real, pure-complex, and conjugation-expanded spectra. Section 9 treats forcing examples. Sections 10-11 develop real-form and topological consequences. Section 12 records proof-sensitive points, prior work, the repository inspection, and the limits of the novelty claim. Section 13 concludes.

The setting is internal to the stipulated outer universe W. The results are not claims about arbitrary externally countable models considered in an unstated larger metaverse. Set-sized parameter sets are distinguished from proper-class structures throughout. No unrestricted class truth predicate or class-valued elementary transfinite recursion is assumed.

## Status and repository comparison

The exact cross-universe results are proposed original contributions with detailed written proofs. No matching statement was located in the targeted inspection described in Section 12. This is not an exhaustive priority claim, an announcement of a solution to a named published open problem, a Lean certification, or independent peer review.

Repository comparison is pinned to:

    VladimirReshetnikov/Surreal
    4f2645599121fa872c7104995e47f86f0382351f

The inspection included the documentation catalogue and the directly relevant foundations and surcomplex-automorphism sources. Not every repository manuscript was read in full. A GitHub code-search response marked incomplete was not treated as exhaustive. These qualifications, and the literature actually located, are recorded explicitly in the article.

## Build the PDF

Use a TeX distribution containing the standard AMS packages, newtx fonts, geometry, microtype, booktabs, enumitem, fancyhdr, xurl, aliascnt, hyperref, and cleveref. No separate font files or external figure assets are included or required.

From this directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_universe_saturation.tex

Alternatively run `pdflatex` three times to resolve contents and cross-references. The supplied PDF was built with pdfTeX. Its final log had no undefined references, undefined citations, overfull/underfull boxes, or LaTeX warnings. All pages were rendered and visually reviewed.

## Run the finite checks

Use Python 3.10 or later, without third-party dependencies:

    python3 verify_finite_models.py

The checker uses exact rational arithmetic and reports:

    1,365 finite interval nodes / closed-form comparisons
    20,475 separated child pairs
    1,364 finite branch decodings
    65,025 canonical-cut / prefix comparisons

These tests cover finite natural labels and finite sign strings only. They can expose finite formula/indexing mistakes, but they do not verify transfinite recursion, forcing, saturation, the full surreal operations, or novelty. The infinite theorems are supported by the written mathematical proofs, not by the checker.
