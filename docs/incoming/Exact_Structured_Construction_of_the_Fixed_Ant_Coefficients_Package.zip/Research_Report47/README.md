# Research Report 47

Exact Structured Construction of the Fixed Ant Coefficients

The fixed coefficients of Report 44 now have a literal-1-and-3 arithmetic prefix with 29,081,374 paid gates: 13,182,377 multiplications and 15,898,997 additions/subtractions. The full two-input source has 31,388,831 gates and 465 positive witnesses; the one-input source has 31,388,841 gates and 467 witnesses. Both retain one equation and exact variable degree 2,304,000. All 1,152,598 old coefficient labels are bound and used.

This is a unit-cost arithmetic-source reduction, not a numerical bit-complexity or execution-time claim. The enormous fixed integers have unchanged values and are not materialized. The old dense prefix and its bound remain valid for their original grammar. No optimality, universal-operation record or stronger ant theorem is claimed.

## Read

- `Research_Report47.pdf`: mathematical report, including full event, ownership, cut, coefficient and splice proofs
- `Research_Report47.tex` and `joined_evidence.tex`: editable LaTeX source
- `science/PROOF.md`, `science/SPLICE.md`, `science/geometry/README.md`: exact scientific construction and finite ownership details
- `science/verification/independent-prefix-audit/AUDIT.md` and `JOIN_ADDENDUM.md`: independent scientific verdicts; the join addendum supersedes only the original audit's historical pending-join statement
- `verification/`: separate science-copy, manuscript, PDF and release evidence
- `references/Report44_recovered_authenticated.zip`: the unchanged inherited Report 44 release, including its original delivered recovered PDF and full contracts; retained for reference, never executed by this replay

## Frozen science and source identities

The science payload is copied byte-for-byte from the independently approved candidate. Its manifest SHA-256 is:

635efaf1943255b24513267e951b887e7a2a7b35e96504fc9d3b33f0b1913777

The exact canonical new arithmetic streams have these SHA-256 identities:

- Prefix: `6a01d7c1d8ee6b268d49c921b3263b578c152e49c62810d5aa877a4103cb9759`
- Complete two-input: `b235ba1d2baf0cf089c9658b1995f9c19fbe3ff033dc6ae67c76ec8cd6522d03`
- Complete one-input: `737866317089c07465253a0d489813bf1bab50aaba0dda6083acbf78ef45f276`

All three streams were actually traversed and hashed. Their large flat text files are not retained; exact finite generators, data and receipts are supplied. All-label modular checks are supplementary to the exact algebraic and geometric proofs. A hash identifies a stream, not the truth of the inherited ant, history or Pell theorem.

## Authenticate before replay

Use the final manifest digest supplied independently with the delivered archive. Do not treat a digest recomputed from an untrusted manifest as authentication. The final root `MANIFEST.json` inventories every delivered file except itself, including frozen science, PDF and tooling. The archive digest authenticates the complete ZIP separately.

After checking the archive and manifest against those trusted values, run:

    python3 -I -B verify_release.py --manifest-sha256 "$TRUSTED_MANIFEST_SHA256" --verify-only

Every replay output must be a new external directory, not a subdirectory of this release. Run the full relocated replay with ordinary assertion-enabled Python 3:

    python3 -I -B verify_release.py --manifest-sha256 "$TRUSTED_MANIFEST_SHA256" --output /path/to/new-report47-replay

The replay authenticates the exact file inventory, copies science to a disposable external directory, regenerates the prefix and both actual strict joins, rebuilds all eleven compact profile artifacts byte-for-byte, and reruns independent profile, all-label prefix and joined-source validation. It checks the original release's bytes, permissions and modification times are unchanged. Expect several minutes and substantial transient memory. No enormous fixed integer or flat joined source is stored.

The historical independent checkers have prototype absolute paths. The release wrapper imports those checker bytes unchanged and rebinds only their documented input/output path globals in the disposable run. The checker functions, logic and self-hashes remain identical. The wrapper records this relocation explicitly. It adds one exact copy of the prefix reference receipt to the disposable science root for a legacy receipt lookup; the frozen science itself is never modified.

All mathematical constants and schema counts are checked using assertion-enabled execution. Do not invoke the scientific compilers with `-O` or `-OO`; the release replay rejects optimized Python. No source or dependencies are installed, downloaded or fetched by replay. Python's standard library suffices for science replay.

## Rebuild the PDF

Requires a local TeX Live pdfLaTeX installation with the packages listed in the TeX preamble. No package installation or network access is attempted. Shell escape is explicitly disabled. The build uses a fixed source date and suppressed volatile PDF identity fields.

    python3 -I -B build_pdf.py --output /path/to/new-report47-pdf --check-packaged --manifest-sha256 "$TRUSTED_MANIFEST_SHA256"

The output PDF must match the packaged PDF byte-for-byte with the recorded toolchain. A different TeX distribution may render the same article without byte identity; that is a different build identity, not a scientific discrepancy. The build writes only to the new external directory and checks source bytes/modes/timestamps are preserved.

## Rebuild the ZIP

    python3 -I -B archive_release.py --manifest-sha256 "$TRUSTED_MANIFEST_SHA256" --output /path/to/new-Research_Report47.zip

The ZIP has stable file order, member dates, permissions and compression settings. With the recorded Python/zlib toolchain it reproduces the delivered archive byte-for-byte. Archive creation does not rewrite the release.

## Execution boundary

The prefix executes only newly authored algebraic lowering and finite JSON-map union code. The fixed compressed row nodes are data; no ant or Boolean tape is evolved, and no saved `prefix_rows` schedule is read. No upstream physical-ant program, color recipe, random-access row decoder or upstream saved arithmetic schedule is executed.

The strict join reuses only the inspected, authenticated Report 44-owned arithmetic generator `main_source/merged_source.py`, SHA-256 `eafe92d6e57782347f430a4f1d6ea5693bd6a48300d2db0294b3ab7026b96395`, and its three reconstructed arithmetic JSON specifications. Its regenerated original main hashes must match the old authenticated hashes. Its opcode stream is then explicitly bound to the new literal prefix.

The inherited source PDF in the reference ZIP has SHA-256 `2e50599d284e318b04c748eac8e0ce114bbe49dce8ae6ff47dc0dcdbb77a1da8`. The reference archive has SHA-256 `3025a1efd5947e624a23f90a07dea7a826410d25944c3c968ea45edfd71013eb`. `verification/report44-provenance.json` identifies its exact PDF member. Report 47 is a new construction, not a byte reconstruction or erratum of Report 44.
