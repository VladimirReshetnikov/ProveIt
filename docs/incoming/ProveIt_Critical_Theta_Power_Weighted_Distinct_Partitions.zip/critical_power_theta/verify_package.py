#!/usr/bin/env python3
"""Verify every manifest-listed file with explicit checks, including under -O."""
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PROVENANCE.json').read_text())
for rel,expected in manifest['sha256'].items():
    path=root/rel
    if not path.is_file():
        raise RuntimeError(f'Missing package file: {rel}')
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise RuntimeError(f'Hash mismatch: {rel}: {actual} != {expected}')
print(f"Verified {len(manifest['sha256'])} package file hashes; checks remain active under python -O.")
