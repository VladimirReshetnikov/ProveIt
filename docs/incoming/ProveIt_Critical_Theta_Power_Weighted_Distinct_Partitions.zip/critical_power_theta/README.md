# Critical theta asymptotics for power weighted distinct partitions

This package studies

    A_a(n) = [q^n] product_{k>=1} (1+k^a q^k)

in the growing-power regime lambda = a(log K-1)/K^(1/3) in a fixed compact subset of (0,infinity), where K is the larger exact saddle root. It is a companion to the previously delivered fixed-power report, not a revision of it.

## Results

- A uniform relative coefficient equivalent with a positive Jacobi theta multiplier
- The exact count phase mu=E(sum_{k>=2}X_k) and conditional variance Q=Var R-Cov(R,S)^2/Var S
- The limit Q=pi^2/(3 lambda^3)+o(1)
- A full uniform Fourier proof, including the consecutive-block transition range and frozen-tail phases
- Integer-power sequences with single-Gaussian ratios converging to distinct limits above and below one
- Theta-adjusted logarithmic derivative H'=t+O(1/K), strict coefficient monotonicity, and inverse-index error o(K^(2/3))
- Qualified asymptotic threshold brackets and a leading joint-parameter Lambert inverse

The results are unrefereed ordinary mathematics, not formally verified. There is no effective onset, no exact-range nearest-integer recovery in the critical regime, and no theorem uniform as lambda tends to zero or infinity. The full asymptotic series and exponentially small remainder questions remain open here.

## Fixed-power companion

The existing report is titled *Relative Expansions and Exact Range Inversion for Power Weighted Distinct Partitions* (1 October 2026), delivered as:

    ProveIt_Power_Weighted_Distinct_Partitions_Relative_Expansions.zip

Its SHA-256 is 225b20707b7ce95c99dff0d973b986658400570e6b2970388a58f28c39343b2f. That package remains unchanged. Its compact-fixed-a error estimates and eventual exact-range rounding are not imported into the growing-a window. The present critical-window proof is self-contained.

## Files

- article.pdf and article.tex: complete 13-page proof and report
- diagnostics.tex, context.tex, references_extra.tex: included TeX sections
- checks/check_identities.py and .json: eight exact algebraic consistency checks
- checks/diagnostics/: numerical programs, source inputs, saved results, summary TSV, and detailed computational README
- run_checks.sh: exact algebraic checks and sanity checks on saved diagnostics
- build_local.sh: reproducible preparation-environment build helper
- verify_package.py and PROVENANCE.json: explicit file-hash verification and source links

The numerical diagnostics are not exact integer coefficient counts or interval-certified enclosures. Their high-precision agreement concerns retained Fourier arcs; omitted arcs are assessed separately through numerically integrated characteristic-function envelopes. The report and diagnostic README state these distinctions explicitly. All 18 cases are complete. No coefficient computation remains pending.

## Quick replay

Python 3 and SymPy are needed for exact algebraic checks; the saved-diagnostic sanity checks use only the Python standard library. Run:

    python3 -O verify_package.py
    bash run_checks.sh
    python3 -O checks/check_identities.py
    python3 -O checks/diagnostics/verify_summary.py

Acceptance checks use explicit exceptions and remain enabled under python -O. These tests verify algebraic identities or consistency of saved numerical output, not the analytic asymptotic estimates.

A standard TeX Live installation can build article.tex with two pdflatex passes. Required packages are geometry, amsmath, amssymb, amsthm, mathtools, lmodern, microtype, booktabs, hyperref and xurl. The included build_local.sh preserves the explicit font/format configuration used during preparation; on another system ordinary pdflatex is usually sufficient. Volatile PDF date and trailer metadata are suppressed to support identical PDF replay. No network access is required once the dependencies are installed.

Full numerical reruns require NumPy, SciPy and mpmath; the independent binary128 audit also requires g++ with libquadmath. Commands and precision limitations are in checks/diagnostics/README.md. These full numerical reruns are optional and substantially more expensive than the quick checks.

## Source scope

The cited OEIS entry is https://oeis.org/A292189. The bounded source comparison examined the ProveIt repository at commit 6591a56b3551e08700aef333cb98849c8cdfe69e:

https://github.com/VladimirReshetnikov/ProveIt/tree/6591a56b3551e08700aef333cb98849c8cdfe69e

This is not worldwide priority certification. The mathematical proof is independent of the source-search outcome.
