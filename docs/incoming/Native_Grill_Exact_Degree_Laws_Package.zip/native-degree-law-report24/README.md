# Report 24 Parametric exact degree laws

This standalone report proves the exact degree law for the pinned weak-cone native Grill polynomial for every fixed nonempty run table.

For m phases and g distinct exponents, put N=2m+g+5. With independent degree-one supplied coordinates:

- Native unit degree: 63N−4
- Maximum native residual degree: 12N+10
- Complete native polynomial degree: 87N+16
- After adding integer residuals of exact maximum degree D inside the same finalizer: 63N−4+2 max(12N+10,D)
- Generic width-k recoder residual maximum: max(k+1,20), for k≥4
- Specified two-recoder loader maximum: max(34,k+1), canonical width fixed at 32
- Fresh polynomial input of degree δ≥1: native degree (δ+2)(29N−8)+40

The PDF gives the hypotheses, complete symbolic proofs, highest homogeneous part, exact coefficient on the all-coordinate ray, one-phase/allzero cases, witness-count corollaries, counterexamples, and limits of the claims. These are degrees of the specified polynomial, with no minimality or new universality claim. Arbitrary algebraic loader attachments require separate semantic justification.

## Read

- `article/report24.pdf`: the complete article
- `article/report24.tex`: editable LaTeX source
- `qa/MATH_REVIEW.md`: independent mathematical review, pinned to the article source
- `qa/RENDER_QA.json`: all-page visual and PDF checks
- `reproducibility/README.md`: detailed replay and provenance guide

## Replay the self-contained core

Python 3.10 or later, standard library only. No network, installation, earlier report, or upstream Python execution is needed.

    python -B verify_release.py
    python -B -O verify_release.py

These commands check the outer release inventory and article-review pins, then run all bundled small-fixture, full-coefficient, fresh-input, generic-degree, and loader checks. They verify that every release file and directory is unchanged afterward. Receipts are printed to standard output. To save a receipt, pass `--output` with a destination outside this release.

Integrity-only and mutation checks:

    python -B verify_release.py --integrity-only
    python -B test_release_integrity.py
    python -B -O test_release_integrity.py
    python -B reproducibility/test_integrity.py
    python -B -O reproducibility/test_integrity.py

## Optional full regression

The 3,600,546-gate universal DAG is not duplicated in this small archive. To replay it, extract the unchanged Report 23 revision 1 archive and explicitly provide its `reproducibility/frozen/arithmetic` directory:

    python -B verify_release.py --universal --source-dir <Report23-v1>/reproducibility/frozen/arithmetic
    python -B -O verify_release.py --universal --source-dir <Report23-v1>/reproducibility/frozen/arithmetic

The core always runs first. All eight required optional source pins are checked. Missing or changed optional inputs fail; there is no directory scan, filename fallback, or silent skip. Expected full degree: 69,339,973, with leading residues 3 modulo 17 and 53,942,795 modulo 1,000,000,007.

## Rebuild the PDF

Use an installed TeX Live distribution with the packages named at the start of the LaTeX source. The script creates TeX caches and all outputs only in a caller-selected directory outside this release:

    sh article/build.sh <outside-output-directory>

The rebuilt PDF is `<outside-output-directory>/report24.pdf`. TeX versions may affect its bytes and pagination; the provided PDF is the visually reviewed version.

## Integrity and provenance

`RELEASE_INVENTORY.json` seals every payload file and exact directory inventory; its digest is in `RELEASE_INVENTORY.sha256`. These two self-referential seal files are excluded from the inventory's own file list. The separately supplied archive SHA-256 is the external integrity anchor. Checksums detect accidental changes; they are not a cryptographic signature of authorship.

Original source/data bytes, adapted checker bytes, and portable reference certificates have separate identities in `reproducibility/PROVENANCE.json`. Python producer source is inert `.py.txt` evidence. The executable code is the new verification code only. All core source pins, including the native proof note, are mandatory.

Report 23 revision 1 and the earlier source archives are unchanged. This is a new report and portable verification packet.
