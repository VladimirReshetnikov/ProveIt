# Research Report 71: Shorter exactness windows

This is a companion to the separately sealed Research Report 70. Both blocks of the binary conservative five-particle full-shift extension are newly defined. Pair exactness remains `L=3D+4`; triple exactness becomes `b=4D+5`.

## Mathematical result and boundary

- Both new blocks are number-conserving full-shift involutions
- Every admissible forward and inverse step and every exact clock agrees with Reports 26 and 70
- Main sufficient radius: `76D+105+3J`
- Same-rule changed-output-support refinement: `76D+104+3J`
- Inherited universal-ledger substitutions: 38,722,713 and 38,722,712 respectively

These are sufficient bounds, not measured or minimum radii. The universal source table is absent, and its universality and normalization remain inherited premises. Boundary predicates in the phase block still read the complete old write interval; the one-site refinement changes no rule. Both actual block inequalities on malformed inputs are proved in the article. Pair-padding failure examples apply only to unchanged templates/selector with an enabled nonzero branch. There is no new-rule evaluator, arbitrary-input arithmetic certificate, priority claim or proof-assistant formalization.

The article includes all local definitions and proofs for the new theorem. Report 70 retains broader architectural background and the separate radius-two appendix; this article neither repeats nor uses that classification.

## Contents

- `Report71.pdf`: publication article
- `Report71.tex`: complete flattened editable LaTeX source
- `manuscript/`: editable modular source and exact module pins
- `science/proof-packet/`: complete short-exactness proof and evidence, retained inert
- `science/source-packet-seal/`: original short-exactness ZIP and seal receipt
- `science/predecessor-proof-packet/`: full inherited proof provenance and original Report 26 archive, retained inert
- `audits/fresh-independent/`: complete fresh independent audit, disposition pass without mathematical correction
- `audits/accepted-static/` and `audits/accepted-radius2/`: authenticated inherited audit provenance; radius-two files are retained only because they are covered by the inherited manifest
- `tools/`: owned, inspected presentation/authentication/release tools only
- `qa/`: provenance, build, visual review, independent review and release-check receipts

Scientific helper programs, source programs, interpreters, simulations, schedules and Lean are not invoked by the release workflow. New executable work is presentation, authentication, file/JSON/hash processing and safe archive operations only.

## Preservation and provenance

Frozen source/audit copies preserve bytes, modes and nanosecond modification times. Report 70 is not modified. The historical short-exactness source observations did see concurrent Report 70 QA activity: 49 added file/directory entries and one existing `qa` directory mtime change. The later independent audit's equal endpoint observations do not erase that qualification. Before/after snapshots establish endpoint equality, not continuous immutability or atomic snapshots. Access times are outside the scope.

Source manifest SHA-256: `72f8024c49a364bfd26ccc9f0e89d128e4390c1bf045477aa3d584bba3eaea31`

Source proof SHA-256: `d2229bcae33affd26eefb513e942891edf1d09c8b8d9e32ab1f8220fd2ea9962`

Fresh independent audit manifest SHA-256: `befa9a29fd2c31a93bfecdda67794a830e5ebbedc71c4c76b85fd3fb4f161614`

Fresh independent audit text SHA-256: `09cca9ebcc31338b083a502f3345e7825869fcdf043350ce16421d4ef5f7b9bd`

Sealed Report 70 manifest SHA-256: `0f96f8aa8bba3eb581070a3db48798ecba3ef0c49daa47a124e62b6754ee30e1`

Sealed Report 70 PDF SHA-256: `d061fda50f26cad711e4f20d028d126d1ce232469425b0745728eed014895010`

## Presentation and release commands

The completed release records external manuscript and dependency-lock pins below. Run tools using `python3 -I -S -B`, without optimization. All generated build/prepare/archive/extraction destinations must be fresh absolute paths outside the release and protected source trees. Commands never run scientific source programs.

The build uses a fresh TeX format, isolated allowlisted environment, disabled shell escape, three TeX passes and the union of the format and every pass's recorded inputs. Dependency locking covers executable/interpreter bytes and recorded TeX/font inputs plus selected maps, not shared libraries, Python's standard library or the operating system. A bootstrap records dependencies and is not a lock-verified replay.

The release manifest authenticates exact descendant inventories, bytes, modes and mtimes; the manifest file's own metadata and top-level root metadata are outside that boundary. Obtain its digest outside the archive. Hashes are identity checks, not digital signatures or proofs of authorship. The supplied authenticated extractor restores descendant nanosecond mtimes that ordinary ZIP extraction can discard. It rejects unsafe paths, symlinks, hardlinks, special files and unexpected entries. Two independently generated ZIPs are required to agree byte for byte.

Presentation pins:

- Manuscript pin map: `f0c4ebf30e03d9b1dbf09c5786649c07fda36c204f1f6480b78e19a4720d583b`
- Flattened LaTeX: `8d63dafe592cfb215f938fe4ac075f8e16dbe14c74d5d5c61b0b1abd030fa1e5`
- PDF: `0e88bb6899c39ba2a7991df468551cafef92730bcb66c00e91094e872b65d275`
- Build dependency lock: `741c8b653fd8783c9afc29f8021a4a2c803140576cb0f6b1eb5ad39a9181e308`
- Frozen input map: `ad643bd888c3a046c74d976d63c5753e65c3c72cbdf82ab7d6454c57483548e3`

From the release directory, choose fresh external destinations for the examples below. Replace `MANIFEST_SHA` with the externally supplied final release-manifest digest. The release manifest cannot self-contain its digest.

```bash
python3 -I -S -B tools/release71.py check-inputs
python3 -I -S -B tools/provenance71.py --output-dir /tmp/report71-provenance-fresh
python3 -I -S -B tools/build_report71.py \
  --pins-sha f0c4ebf30e03d9b1dbf09c5786649c07fda36c204f1f6480b78e19a4720d583b \
  --dependency-lock-sha 741c8b653fd8783c9afc29f8021a4a2c803140576cb0f6b1eb5ad39a9181e308 \
  --require-packaged-match --output-dir /tmp/report71-replay-fresh
python3 -I -S -B tools/selftest71.py --output-dir /tmp/report71-selftests-fresh
python3 -I -S -B tools/release71.py verify --manifest-sha256 MANIFEST_SHA
python3 -I -S -B tools/release71.py archive --manifest-sha256 MANIFEST_SHA --output /tmp/Report71-a.zip
python3 -I -S -B tools/release71.py archive --manifest-sha256 MANIFEST_SHA --output /tmp/Report71-b.zip
cmp /tmp/Report71-a.zip /tmp/Report71-b.zip
python3 -I -S -B tools/release71.py extract --manifest-sha256 MANIFEST_SHA \
  --archive /tmp/Report71-a.zip --output-dir /tmp/report71-extracted-fresh
python3 -I -S -B /tmp/report71-extracted-fresh/tools/release71.py verify --manifest-sha256 MANIFEST_SHA
```

The original-environment endpoint check adds `--compare-originals` to the provenance command. It requires the original four source trees at their recorded absolute paths; portable retained-evidence authentication does not require those paths. Its baseline is pinned as `d47017623dd7104ed32a65a578a5ac65bb4143574dac3e82182c9864fa1535ad`.

For authorized manuscript edits, `release71.py prepare --output-dir /fresh/external/path` creates a new standalone source and module pin map. Review those files before explicitly installing them; then bootstrap the new manuscript in an external directory, install its reviewed dependency lock, and run locked replay. Do not reuse the above presentation pins after editing. Final post-seal verification remains a separate gate.
