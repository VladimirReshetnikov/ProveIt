# Lexicographic Well-Orders of the Surreals II

**Cut classification, support thresholds, and class-model absoluteness**  
Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

## Contents

- `article.pdf` — the compiled article, with proofs, references, formalization
  proposals, and further research questions.
- `article.tex` — standalone LaTeX source with an internal bibliography.
- `verification.py` — standard-library-only finite regression tests.
- `verification_results.json` — the delivered successful test run.
- `build.sh` — reproducible two-pass PDF build.
- `RESEARCH_STATUS.md` — assumptions, result ledger, limitations, and repository audit.
- `SHA256SUMS.txt` — hashes of the delivered files other than the manifest itself.

## Main results

The article works in GBC with a fixed class bijection b: Ord -> No for its
class-level theorems. P_b is the ordinary class of canonical set-support
permutation codes of b. Collections of class enumerations and class cuts
are explicitly treated as virtual collections, not as ordinary classes
containing classes.

1. Every proper normalized class cut of P_b is uniquely a cylinder edge,
   a numerical gap after a set prefix, or an Ord-long injective branch trace.
   The paper gives its characters, including the principal-cut exception.
2. Exhaustive traces are characterized and reconstructed by elementary
   conditions on crossing prefixes and coverage. Coverage already forces
   coherence here because the alphabet is proper. Adding classes while
   retaining the sets and baseline cannot newly realize an old cut.
3. Character pairs completely classify the class-automorphism orbits of
   normalized core cuts. Exhaustive representability is not invariant:
   an automorphism can carry an exhaustive trace to a nonbranch cylinder edge.
4. For every infinite set cardinal kappa, support of cardinality <kappa
   yields exactly eta_(cf kappa) saturation, not eta_((cf kappa)^+).
   A witnessing omitted configuration has minimum support cost kappa.
5. The trace of an unrestricted class well-order depends exactly on its
   canonical initial Ord-branch; the convex fiber is the family of
   well-orders of the omitted residual alphabet.

## Scope and status

This is an AI-assisted, unrefereed mathematical research manuscript with
conventional written proofs. No historical-priority claim is made.
The new theorems have NOT been verified in Lean. Proposed module names and
logical pseudocode are not presented as existing or compiled code.
The finite diagnostics all passed, but do not certify infinite-cardinal
or class-theoretic theorems.

The prefix-boundary classification is relative to named cylinders. The
separate orbit theorem explains why a bare-order, automorphism-invariant
criterion cannot recognize exhaustive representability.

The targeted predecessor was inspected at ProveIt commit:
`0ecd158fd163bc4aca0ee40ccf6479ca6cf5f2a8`.
The bibliography supplies pinned links. The repository has not been changed.

## Reproduction

From this directory:

```sh
sha256sum -c SHA256SUMS.txt
python3 verification.py
bash build.sh
```

`verification.py` uses only the Python standard library. The delivered run
used Python 3.13.5. The PDF build requires `pdflatex` and the standard TeX
packages listed in the preamble. No bibliography download is necessary.
Rebuilding the PDF can change its hash because TeX embeds build metadata;
rerunning on a different Python version also changes the recorded version.
The manifest checks the delivered files, not byte-identical rebuilds on
all environments.

No fonts, repository clones, or LaTeX auxiliary files are included.
