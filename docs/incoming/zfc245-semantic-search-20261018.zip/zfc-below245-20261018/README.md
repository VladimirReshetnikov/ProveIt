# Research toward fewer than 245 states

**Outcome: no machine below 245 working states has been established to satisfy**

\[
\mathrm{ZFC}\vdash\neg\mathrm{Halt}(M,\mathbf0)\leftrightarrow\mathrm{Con}(\mathrm{ZFC}).
\]

This is a research contribution prepared on 18 October 2026 for ProveIt. It
contains exact new certificates, alternative logical encodings, finite
experiments, and concrete reasons for rejecting two apparent 244-state
reductions. The rejected tables are not proposed as validated consistency
machines. No new end-to-end Coq or Lean theorem was compiled in this work.

Read **[report.pdf](report.pdf)** for the mathematical account. Its complete
editable source is **[report.tex](report.tex)**. Detailed component READMEs
explain each checker and its precise assumptions.

## Main results

| Investigation | Result | Strength of evidence |
| --- | --- | --- |
| Reorder closed AX components with disjoint register footprints | Exactly 1,669 ideals, 2,068 edges, approximately 9.388e81 legal fine words | Reconstructed dependency automaton; exact integer count; mathematical commutation argument |
| Parse any legal ordering with the 44 coarse atoms | Exact minimum 533 calls | All dictionary edges checked, integer potentials, matching parse |
| Add 51 fixed non-AX words to the free dictionary | Exact minimum 108 calls | Same complete graph argument, 95 entries |
| Select grammar rules in the serialized semantic length-20 vocabulary | Exact optimum **128 = 51 fixed + 77 private rules** | Exact integer dual certificate and matching feasible grammar in the same model |
| Replace the four-parameter propositional axiom by K/S/Peirce | Equivalent formula calculus; retained literal machine **250 states** | Both logical translations checked; updated enumeration macros; source and conditional affine audits; exact blank bootstrap |
| Flatten the negative conjunction of four theory components | Equivalent already in minimal implication; best flat routed grammar **129**, hence projected total **246** | Two exact Hilbert proofs; symbolic AX stacks; retained grammar witness |
| All ordered conjunction shapes and leaf permutations | 264 encodings; best retained grammar **128**, hence **245** total | Complete finite cost experiment; no claim of unrestricted grammar optimality |
| Delete an additional scanner state | Actual 244-state table; wrong next pointer on its own blank run at step **348,237** | Sparse and dense literal interpreters plus independent source interpreter |
| Delete the shared equality-transfer decoder | Actual 244-state table; violates the AX freshness-tail contract | Exact four-occurrence tree rewrite and complete 58/41-step source counterexample |
| Replace `Move(X,H); Inc(H)` by `Inc(X); Move(X,H)` | Sound for all registers; new literal implementation still **245 states** | Algebraic proof, exact two-row table edit, all 8,391 conditional affine cases, sparse/dense blank replay |
| Finite state eliminations, pair identifications, repairs, and grammar searches | No accepted reduction | Frozen fixtures, C++ sources, retained summaries, independent reconstruction and grammar checks |

The exact 128-rule optimum is **restricted**: the vocabulary, 51 fixed rules,
entry orientations, zero-run constraints, and one implementation per semantic
trace are part of the model. It is not a lower bound on unrestricted grammars
or Turing machines. Longer new semantic words or identities beyond disjoint
commutation can fall outside it.

The short-scanner witness rejects the intended **one-source-instruction
contract at the next qualifying dispatcher return**. It does not show that
the mutant eventually halts, has different eventual halting behavior, or
cannot match the expected frame at some later return under another relation.
The shared-loop witness rejects a universal source contract; its chosen AX
entry is not asserted to be reachable from blank tape.

## One-command independent replay

Use Python 3.10 or newer with assertions enabled:

```sh
python verify.py
```

This command uses only Python's standard library. It first checks the SHA-256
manifest and all literal table counts, then copies the package to a temporary
directory and runs the checkers there. Generated audit files therefore do not
alter the delivered certificate tree. It uses no network, optimizer, C++
compiler, Coq, or Lean. Progress goes to stderr; a complete JSON result goes
to stdout. The temporary copy is removed after the run.

To save a new replay summary or additionally check every admissible production
split over the exact serialized LP vocabulary:

```sh
python verify.py --output /tmp/zfc245-replay.json
python verify.py --complete-productions --output /tmp/zfc245-complete-replay.json
```

The default replay checks the exact dual bound. The additional production
check establishes completeness of the production list within its frozen word
vocabulary. It does not widen that vocabulary or turn the result into an
unrestricted lower bound.

For byte integrity and literal table accounting alone:

```sh
python verify.py --manifest-only
```

Do not run with `python -O`. Assertions implement many certificate obligations.
The wrapper refuses optimized mode and does not propagate `PYTHONOPTIMIZE`
or an external `PYTHONPATH` to child checkers.

The retained `verification/` reports record fresh execution during preparation
of this archive. Verification recomputes the underlying facts and does not
trust a recorded `PASS` string. The final top-level replay summary records the
whole isolated run. Imported reports and search logs retain their original
scope; a finite boot `PASS` does not establish source equivalence.

## Contents

| Path | Purpose |
| --- | --- |
| `report.tex`, `report.pdf` | Complete mathematical report and bibliography |
| `inputs/` | Pinned 245-state baseline tables and ordered logical source leaves |
| `experiments/trace_grammar/` | Exact trace automaton, dictionary certificates, integer dual, feasible grammar, independent verifier, optional search producer |
| `experiments/foundations/` | K/S/Peirce translations, flat-bundle proofs, generic stack identities, all finite encoding results, complete alternative 250-state table and replay |
| `experiments/scanner/` | New independent source and literal interpreters; actual blank-reachable scanner failure; rejected 244-state scanner table |
| `experiments/shared_loop/` | Source counterexample, four exact substitutions, independent review data, rejected 244-state transfer-deletion table and boot data |
| `experiments/logic_matrices/` | Small standalone verifier of the fixed-falsity propositional countermodel |
| `experiments/machine_search/` | Mutation C++ sources, finite fixtures and rebuilder, grammar heuristics, valid 245-state arithmetic rewrite and conditional affine audit |
| `verification/` | Fresh replay results |
| `PROVENANCE.json`, `MANIFEST.sha256` | Repository pins, input hashes, and hashes of all delivered files except the manifest itself |
| `NOTICE.txt`, component licenses | Attribution and licensing scope |

All ordinary machines use a single two-way infinite tape, alphabet `{0,1}`,
blank initial tape, and left/right moves. Working-state counts exclude the
halt state. Original state labels are not consecutive; a highest label is
not a state count. The normalized baseline and KSP250 table use start state 0.
The original-label tables use start 95 and halt label 254.

### Important distinction between the two `hg` artifacts

`experiments/machine_search/results/hg-swap/hg245.tm` is the audited literal
245-state table: baseline grammar plus the two outgoing-row edits at state
142, source depth 51. Its blank prefix is 416,557 steps and its seed is
`(3,0,0,0,3,0,0,0,0)`, with gap 183.

The same directory's final heuristic `result.json` is a different abstract
128-rule grammar with source properties `(3,6,52)`. That search result was
not compiled or covered by the literal table's affine audit.

### Important distinction between source proofs and binary audits

The KSP logical certificates prove equality of formula derivability after
the basis replacement. The mathematical notes also supply the revised
three-field proof coding and cofinal padding argument; they do not silently
reuse the old four-field theorem. The 250-state table has 3,171 source-control
pairs, 8,794 guarded affine cases, and a checked 407,915-step blank prefix.
Its affine check assumes the inherited register-box contracts. A final formal
consistency endpoint for the changed source and literal table remains open.

The same scope distinction applies to the 245-state `hg` variant. A true
source identity and a universal symbolic calculation under inherited macro
contracts are substantial evidence, but are not advertised as a newly
compiled proof-assistant theorem.

## Optional expensive reproductions

See the individual component READMEs for full commands. The top-level quick
replay does not rerun the millions of mutation recipes or elapsed-time-limited
annealing searches. It reconstructs the finite input bytes, checks the
retained resulting grammars, and replays the exact certificates and witnesses.

The finite pair-identification family has 119,560 recipes; single-entry
elimination has 133,712; the retained additional-repair family has 3,499,936.
The same families were tested with several acceptance relations and overlap.
Counts describe recipes, not necessarily distinct machines. Full search
commands require a C++17 compiler. Stochastic iteration counts can vary with
processor speed even with a fixed seed because termination uses elapsed time.

Regenerating LP discoveries requires NumPy/SciPy/HiGHS; verifying the retained
integer certificate does not. `experiments/foundations/verify.py --searches`
also reruns the 1,296 basis-orientation and 264 bundle-encoding cost cases.

To rebuild the PDF with TeX Live and latexmk:

```sh
mkdir -p build
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build report.tex
```

The rebuilt file is `build/report.pdf`; PDF timestamps may make its bytes
differ from the retained PDF without changing the mathematical content.

## Pinned sources and integration

- ProveIt commit: `6d69a46dce1de15397a9d2448dcc946d08c90327`.
- Upstream busy-beaver branch `zf-254`: `c132d7eae8158cd3a9850ea3eb7251158c3dd821`.
- Existing candidate: `Computability/BusyBeaver/Research/ZFC/candidate-routing245/`.
- Prior research intake: `docs/incoming/` at the same ProveIt commit.

The archive filename `zfc245-semantic-search-20261018.zip` deliberately differs
from the already present `zfc-below245-research-20261018.zip`. It can be added
to `docs/incoming/` without replacing that earlier work. The contribution is
research evidence; it does not authorize promoting either rejected table to
the repository's validated candidate area. No branch was pushed and no pull
request was opened.

The most promising boundary identified by these results is compression using
proved register effects and entry invariants. Every use of a shared decoder
must satisfy the invariant of its proposed rewrite. An apparently dead
transfer can still provide essential scratch clearing. The archive supplies
exact examples of both an invalid deletion and a sound semantic replacement.
