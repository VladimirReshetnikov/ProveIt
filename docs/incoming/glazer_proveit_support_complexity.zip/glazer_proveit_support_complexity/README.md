# Exact Support Complexity and Strong Summation in Hahn Fields

**An order-obstruction classification and certificates that restore continuity**  
Research report prepared with ChatGPT for Vladimir Reshetnikov, 4 October 2026.

## Contents

- `article.pdf`: the 25-page compiled article.
- `article.tex`: self-contained LaTeX source, including bibliography.
- `checks.py`: standard-library Python checks using exact rational arithmetic.
- `checks.txt`: output from the supplied checks.
- `sources.md`: source and provenance ledger.
- `Makefile`: build and test commands.
- `SHA256SUMS`: checksums for the other package files.

## Main results

For a fixed countable linear order L, well-ordered binary supports and valid real coefficient arrays have the following exact descriptive pointclasses: the whole ambient space when L is well ordered; Sigma-0-2-complete when L is not well ordered and does not contain an increasing sequence of omega-star blocks; Pi-0-3-complete when L is scattered and contains those blocks; and Pi-1-1-complete when L contains a copy of the rationals. The two nontrivial Borel Wadge degrees for binary supports are precisely Fin and independent row-finiteness Fin^N. See Theorem 4.6.

This answers the exact Borel-level and Wadge-degree portions of Question 12.3 in the earlier project report, *Borel Presentations and Support Barriers in Omnific Arithmetic*. It does not claim an effective classifier from arbitrary decomposition codes. The general scattered-support Pi-0-3 upper bound is established prior art, credited to Guevara and Uzcategui.

Strongly summable real Hahn families have an exact parallel classification, with a Pi-0-3-complete domain already over integer exponents. Strong summation is Baire class 1 but nowhere continuous in the raw coefficient topology. Closed Polish certificate spaces restore continuity. Integer-valued bounds have a low-level Borel selector but admit no Baire-class-1 selector. Real-valued bounds admit an explicit Baire-class-1 selector, obtained as a limit of continuous finite-support regularizations. Those regularizations converge in the certificate space exactly for strongly summable inputs. See Theorems 6.2, 7.1, 8.3, and 9.3.

No exact standard Borel naming system with all coefficients Borel observable exists for a non-scattered full-support exponent order. Recognizing scatteredness remains coanalytic-complete even among orders on a fixed free abelian group with a prescribed least positive element. See Theorems 10.2 and 11.3.

## Scope and proof status

All spaces are set-sized; exponent orders and index sets are countable. Real coefficients carry their usual topology, and raw arrays carry the product topology. These statements are not about a valuation topology or a topology on the proper class of all surreal numbers. Complexity is boldface, not a claim of computability for arbitrary order presentations.

The article supplies complete mathematical arguments and identifies classical dependencies. Historical priority for its extensions has not been established, and the manuscript has not been independently peer reviewed. No new theorem is claimed to be Lean-checked. The inspected ProveIt source was not rebuilt in this task.

The finite tests validate formula conventions and finite algebra only. They do not prove infinitary well-foundedness, Borel completeness, or correctness of the full mathematical argument. Every finite regularization is legal even for an illegal infinite input; convergence of all certificate bounds is essential.

## Build and test

A TeX Live installation containing standard packages, including newpx, tcolorbox, and xurl, is sufficient. No font files or external papers are bundled.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
python3 checks.py
```

Alternatively, run `make` and `make check`. The bibliography is included in the TeX source, so BibTeX or Biber is not required. On systems without latexmk, run pdflatex repeatedly until references and the contents stabilize.

## Repository anchor

The selected implementation source is pinned to commit
`c39974f12a45c8795575ab222f3b84b2901c394f`:

`Algebra/SurrealNumbers/Surreal/HahnSeries/StrongEvaluation.lean`

The article explains the relationship with `PowerSeriesSummable`, Hahn `SummableFamily`, and strong evaluation. Its formalization section is a proposed route, not an assertion of newly implemented code.
