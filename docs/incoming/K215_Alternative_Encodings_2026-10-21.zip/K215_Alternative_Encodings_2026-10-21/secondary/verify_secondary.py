#!/usr/bin/env python3
"""Verify the rho6 alternative; optional fresh universal replay uses shared runtime."""
from pathlib import Path
import json,gzip,hashlib,sys,subprocess,argparse
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'code'))
from reconstruct import table,serial
import source_tools as s
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def graph_distinct(A,B):
 f={0:0,254:254};rev={0:0,254:254};todo=[0]
 while todo:
  q=todo.pop();r=f[q]
  for bit in(0,1):
   w,d,z=A[q,bit];v,e,t=B[r,bit]
   if(w,d)!=(v,e)or z in f and f[z]!=t or t in rev and rev[t]!=z:return[q,r,bit]
   if z not in f:f[z]=t;rev[t]=z;todo.append(z)
 raise AssertionError('Unexpected graph isomorphism')
def check(parent,work,fresh_runtime=False):
 if not __debug__ or sys.flags.optimize:raise RuntimeError("Run verification without Python optimization")
 parent,work=Path(parent),Path(work);work.mkdir(parents=True,exist_ok=True)
 recipe=json.loads((HERE/'source/recipe.json').read_text());A=table(parent/recipe['parent_native']);T=dict(A)
 for q,b,w,d,z,nw,nd,nz in recipe['replacement_rows']:
  assert T[q,b]==(w,d,z);T[q,b]=(nw,nd,nz)
 assert serial(T).encode()==(HERE/'machine/k215.native.tm').read_bytes()
 Q={q for q,b in T};assert len(Q)==215 and len(T)==430
 seen={0};todo=[0]
 while todo:
  q=todo.pop()
  for b in(0,1):
   z=T[q,b][2]
   if z!=254 and z not in seen:seen.add(z);todo.append(z)
 assert seen==Q
 M={int(k):v for k,v in json.loads((HERE/'machine/native_to_canonical.json').read_text()).items()};assert set(M)==Q|{254}and set(M.values())==set(range(216))and M[0]==0 and M[254]==215
 C={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in T.items()};assert serial(C).encode()==(HERE/'machine/k215.tm').read_bytes()
 nm={301:79,302:102};N={(nm.get(q,q),b):(w,d,nm.get(z,z))for(q,b),(w,d,z)in T.items()};assert serial(N).encode()==(HERE/'machine/k215.normalized.tm').read_bytes()
 old=json.loads((parent/recipe['parent_source']).read_text());rows=json.loads((HERE/'source/sites215.json').read_text());expected=json.loads(json.dumps(old))
 for i in recipe['changed_ordinals']:assert expected[i][2]==3;expected[i][2]=5
 assert expected==rows and s.compact(rows)==(HERE/'source/sites215.json').read_bytes();assert sha(HERE/'source/sites215.json')==recipe['source_sha256']
 ga,_resolver_checks=s.graph_arithmetic(rows);edges=sum(len(x[1])for x in ga);assert ga==s.graph_intervals(rows);go,_=s.graph_arithmetic(old);assert [x[1]for x in ga]==[x[1]for x in go];assert edges==6175
 lo,hi=recipe['interval'];inbound={(i,j)for i,(_,js)in enumerate(ga)for j in js if not lo<=i<hi and lo<=j<hi};outbound={(i,j)for i,(_,js)in enumerate(ga)for j in js if lo<=i<hi and not lo<=j<hi};assert inbound=={(882,888)}and outbound=={(1165,1171)}
 for i in range(lo,hi):
  p,op,arg=old[i];want=8-arg if op in('CI','CD')and arg in(3,5)else arg;assert rows[i]==[p,op,want]
 assert s.metrics(s.tree(rows))['dag_nodes']==202
 r=json.loads((HERE/'evidence/runtime.json').read_text());cases=json.loads(gzip.decompress((HERE/'evidence/runtime_cases.json.gz').read_bytes()));st=json.loads(gzip.decompress((HERE/'evidence/startup.json.gz').read_bytes()))
 assert r['status']=='UNIVERSAL_MATHEMATICAL_PASS'and r['proved_cases']==r['expected_cases']==6176 and not r['failures'];assert r['table_sha256']==sha(HERE/'machine/k215.native.tm')and r['sites_sha256']==sha(HERE/'source/sites215.json')
 assert r['checker_sha256']==sha(ROOT/'code/runtime/symbolic_runtime.py')and r['helper_sha256']==sha(ROOT/'code/runtime/independent_runtime.py')
 assert[(c['site_index'],c['positive'])for c in cases]==[(i,p)for i,x in enumerate(rows)for p in([False,True]if x[1]=='CD'else[False])]
 assert all(len(c['duration'])==13 and c['duration'][0]>0 and all(v>=0 for v in c['duration'])for c in cases);assert sum(c['symbolic_steps']for c in cases)==1699838 and min(c['duration'][0]for c in cases)==6
 lm={int(k):v for k,v in json.loads((ROOT/'code/inputs/legacy_mapping.json').read_text()).items()}
 for q in Q|{254}:lm.setdefault(q,q+1000)
 rev={lm[q]:q for q in Q};used={tuple(row)for c in cases for row in c['rows']}
 for block in r['blocks']:
  for e in block['trace']:
   if e[0]in('literal','unary'):used.add(tuple(e[1][:2]))
 assert {(rev[q],b)for q,b in used}==set(T)
 assert st['steps']==95714 and st['state']==84 and st['head']==-8 and st['registers']==[4,0,0,0,0,0,0,0,0]and st['gap']==1 and st['spares']==[1]*40 and len(st['one_cells'])==95
 # Separately parsed dense canonical replay; every cell outside the finite array stays zero.
 parsed=table(HERE/'machine/k215.tm');tape=bytearray(4096);q=cq=0;h=2048
 for tick in range(st['steps']):
  b=tape[h];w,d,z=T[q,b];cw,cd,cz=parsed[cq,b];assert(w,d,M[z])==(cw,cd,cz);step=1 if d=='R'else -1
  assert st['trace'][tick]==[q,h-2048,b,w,step,z];assert(q,b)not in((199,1),(206,0));tape[h]=w;q,cq,h=z,cz,h+step;assert 0<h<4095
 assert(q,h-2048,[i-2048 for i,v in enumerate(tape)if v])==(84,-8,st['one_cells'])
 conflict=graph_distinct(A,T);prior=table(HERE/'evidence/intake199-prefix.native.tm');prior_conflict=graph_distinct(prior,T);assert json.loads((HERE/'evidence/intake199-source-price.json').read_text())['source_sha256']==sha(HERE/'source/sites215.json')
 if fresh_runtime:
  dest=work/'secondary_runtime';log=work/'secondary_runtime.log'
  with log.open('w')as f:p=subprocess.run([sys.executable,'-B',str(ROOT/'code/validate_native.py'),str(HERE/'machine/k215.native.tm'),str(HERE/'source/sites215.json'),str(dest)],stdout=f,stderr=subprocess.STDOUT)
  assert p.returncode==0,log.read_text()[-4000:];fresh=json.loads((dest/'runtime.json').read_text());assert fresh['status']=='UNIVERSAL_MATHEMATICAL_PASS'and fresh['proved_cases']==6176
  assert json.loads((dest/'runtime_cases.json').read_text())==cases and json.loads((dest/'startup.json').read_text())==st
 result=dict(status='SECONDARY_RHO6_215_PASS',fresh_runtime=fresh_runtime,working_states=215,guarded_cases=6176,symbolic_rules=1699838,source_edges=edges,blank_steps=95714,parent_nonisomorphism=conflict,public_prefix_nonisomorphism=prior_conflict,scope='Same public rho6 source, distinct verified physical allocation. Ordinary mathematical proof, not a proof-assistant kernel endpoint.')
 (work/'secondary_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True);return result
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--parent',type=Path,required=True);ap.add_argument('--work',type=Path,required=True);ap.add_argument('--runtime',action='store_true');a=ap.parse_args();check(a.parent,a.work,a.runtime)
