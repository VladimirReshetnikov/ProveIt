# The secondary 215-state rho6 sampler

## Result and exact construction

This is a verified alternative with 215 working states, 430 binary transitions, and a separate halting state. It is not a 214-state result. The supplied evidence records a fresh universal runtime proof for all 6,176 guarded primitive cases, 1,699,838 symbolic proof rules, strictly positive affine durations (minimum constant 6), and coverage of all 430 transition rows.

The two-row recipe is relative to the original 215-state machine in the included parent archive, not to this packet's primary 33-six-zero-address alternative:

- Native row 199/1: 1R166 becomes 1R12.
- Native row 206/0: 0R186 becomes 0R76.

Exactly four source operands change, at ordinals 959, 964, 1137, and 1142: register 3 becomes register 5. Every source path, operation kind, and control successor is retained. The source has 4,751 leaves and 202 distinct DAG nodes. The entire changed emitter occupies the half-open interval [888,1171), has one external entry and one external exit, and consists of 283 leaves. Both independent guarded-control resolvers check the complete source.

The normalized, restored-native, and canonical tables and their mappings are supplied under `machine/`. Canonical working labels are 0 through 214, initial state 0, and halt 215. Native labels retain initial 0 and halt 254. The verifier checks every transition under each bijection.

## All-natural source calibration

Retain Cantor pairing P, implication I(a,b)=4P(a,b), quantification Q_a(x)=4P(a,x)+2, and N(x)=I(x,1). The retained universal axiom is

rho6(a,x) = I(N(Q_a(N(Q_a(x)))),x).

The parent emitter produces rho6(A,C). The new emitter produces rho6(A,B). At that stage registers 3, 4, and 5 contain C, A, and B. Conjugate the original emitter by exchanging coordinates 3 and 5. Every increment, decrement, and decrement guard corresponds exactly under this exchange; control instructions remain unchanged. The original emitter preserves all parameter registers, clears its scratches, and transforms (T,W) into (rho6(A,C),P(T,W)). Consequently its conjugate preserves the same parameter store and transforms (T,W) into (rho6(A,B),P(T,W)). This is a step-by-step proof for arbitrary natural stores, not a test over decoded formulas.

Every new generated code remains an instance of the same universally quantified numerical axiom schema. Other emitted rows, the dominated classical schema, theorem-only generalization, the literal gated set-theoretic bundle, MP, and stack commands are unchanged. Thus the inherited theoremhood invariant and halting-soundness argument remain valid for every raw command stream, including junk codes.

## Explicit strong proof compiler

Use the parent's strong block contract: from any (t,w,0,0), a block for F either halts soundly or returns (F,w,0,0). Tuple coordinates are (T,W,D,H).

The inherited reset block is

DISCARD = MP(1); AX(1;0,0); NIP^10.

It returns (0,w,0,0). MP fails against zero cache because I(t,1)>0. The disabled AX resets the counter, and its ten pushed entries are removed. The changed sixth entry remains an implication code, never falsity 1, so this argument is unchanged.

For any natural a,b, issue AX(c=a;x=a,y=b), with the exact local-reader wire fields [a+3,b,a]. From the reset state this supplies U=0, A=a, B=b, C=a. The bundle gate is disabled because C=A, and the new rho6(a,b) occupies the sixth pop slot. Therefore the strong axiom block is

DISCARD; AX(a;a,b); NIP^6; DROP; NIP^5.

Six pops select the target. DROP makes it current and pushes the zero current top. Five further pops remove that extra zero and the four remaining entries, leaving the saved old top 0 in cache and restoring the arbitrary protected underlying stack w. All discarded logical rows are implication codes, and the generated quantified code has residue 2, so none is falsity 1. The block terminates normally for every a,b and arbitrary w.

All other axiom compiler blocks retain their row positions and cleanup counts. Their unused sixth entry changes but is still a sound nonfalsity code. MP and GEN compilation are unchanged. The inherited cofinal reset padding and exact first-candidate encoding continue to give refutation programs above cutoff 4. No renaming operation on arbitrary derived formulas, monotonicity assumption about raw codes, or alteration of the literal bundle is introduced.

Together with the parent's numerical-calculus/ZFC calibration, this proves the same halting/consistency equivalence for the new source.

## Binary runtime and exact blank initialization

The supplied fresh runtime certificate proves every primitive interface for independently arbitrary natural primary registers and gap, an arbitrary nonempty finite spare list, and a complete zero exterior. Positive affine durations connect finite source transitions with finite binary execution. These are ordinary mathematical symbolic-induction certificates, not a new Lean or Rocq kernel endpoint.

A literal blank run takes exactly 95,714 transitions to native state 84, head -8, with logical registers [4,0,0,0,0,0,0,0,0], gap 1, forty spare registers all equal to 1, and exactly 95 one-cells. Every other cell is zero. Neither changed row occurs in this prefix. An independently parsed dense canonical interpreter checks the complete trace, each state-renaming equation, and the entire endpoint tape. Thus the inherited clean-root calibration applies unchanged.

The ordinary proof establishes, within ZFC, that this machine fails to halt on the blank tape exactly when ZFC is consistent. It neither assumes consistency nor claims unconditional nonhalting or minimality.

## Attribution and comparison with public intake199

The rho6 permutation and its calibration are upstream work. Commit 7de71bd17b85db67529e8f10083c066ab0ed0c56 publicly records this exact 215-state source composition, SHA256 19da13e482ea0f3d57432aad852bdf2448093e58a6e3b3873ac744eae7440693, and a prefix-valid 215-state allocation without a full runtime proof. No independent priority is claimed for that source or idea.

The table here is a different physical allocation. It differs from that public prefix allocation on 62 literal state/symbol keys and is not merely a relabeling: rooted labelled graph comparison forces its state 115 to our state 135, where read-1 actions conflict (0L302 versus 1R143). It is also nonisomorphic to the included original 215-state parent. The supplied verifier checks both comparisons.

The contribution here is the distinct physical allocation with a completed fresh universal runtime proof and exact blank-start audit. The baseline machine, source language, numerical calculus, source permutation, and generic proof engine retain their upstream attribution and licenses.
