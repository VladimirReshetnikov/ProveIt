# Independent review of the routed 245-state candidate

Prepared 18 October 2026 for Vladimir Reshetnikov.

## Result

The independent checks strongly corroborate the exact 245-state candidate. No valid smaller construction was found. Three explicit 244-state attempts fail the proposed instruction contract; the bounded grammar searches do not establish minimality. The exact 245-state Lean endpoint and PA-internal equivalence remain open at the pinned repository commit.

Read `report.pdf` for the seven-page review, or edit `report.tex`. The report distinguishes the mathematical proof argument, kernel-checked endpoints, finite tests and heuristic searches.

Pinned ProveIt commit: `5b154d85fac5f7190d65bf7134cab374e580c69e`.
Canonical 245 table SHA-256: `17f4d430747c4a0cd580dc2cc13ea06a74ce7f51f12be4c2d12f6a646691dd13`.

## Contents

- `code/`: newly authored independent audit programs and small packaging adapters
- `results/`: exact full-run results, 8,391 duration/motion formulas, finite diagnostics and concrete/parametric witnesses
- `search/`: newly authored grammar/routing searches, exact local obstruction, bounded enumeration, logs and search summary
- `INPUTS.json`: pinned input identities and a fixed archive-member allowlist
- `PROVENANCE.json`: release identities, scope and path-only adaptation records
- `MANIFEST.sha256`: all included deliverable files, except the manifest itself

The original incoming ZIP, downloaded implementation code, inherited input tables and upstream Coq/Lean source files are not included. They retain their original authorship and rights. `fetch_inputs.py` obtains only required inert inputs after exact identity checks; it never runs downloaded programs. Numerical traces and generated search data are included as new research results.

## Quick reproduction

Requirements: Python 3.10 or newer and its standard library. Assertions must remain enabled; do not run with `-O` or `PYTHONOPTIMIZE`. The portable symbolic entry and its helper explicitly reject optimized execution. No Lean/Rocq compiler or third-party Python package is needed for the independent audits.

From the extracted archive directory:

```sh
python3 -B code/verify_manifest.py
python3 -B code/fetch_inputs.py
unset PYTHONOPTIMIZE
python3 -B code/audit_table_and_boot.py
python3 -B code/audit_source_certificate.py
python3 -B code/run_symbolic_checked.py --output results/reproduced_universal_summary.json
```

`fetch_inputs.py` downloads the pinned 2,846,575-byte original archive into memory, verifies its SHA-256 and Git blob identity, and extracts only 17 individually hash-checked data members into `inputs/`. Supply `--archive /path/to/zfc245-proof-20261018.zip` to use an already downloaded exact copy without network access. It rejects path traversal, duplicate archive names and symbolic-link members.

The universal check takes roughly three minutes on the review machine. It must finish with `UNIVERSAL_MATHEMATICAL_PASS`, 8,391 expected/completed cases, 2,312,645 symbolic rules and a minimum actual-duration lower bound of 13. All 490 rows are covered after including the block-schema traces. A partial result, `NOT_PROVED`, an exception, timeout or nonzero exit is not success.

The retained final release receipt is `results/baseline245_portable_release_universal_summary.json`; the exact case formulas are in its `_cases.json` companion. That completed run used optimization level 0, debug assertions enabled, `PYTHONOPTIMIZE` unset and bytecode disabled. Its engine/helper bytes are included unchanged. The receipt deliberately retains the original absolute input/output paths and command line as historical execution provenance; they are not required for reproduction and have not been silently rewritten. The supported entry points resolve the extracted package paths or the documented environment overrides. A fresh run records its own environment and timing, so summary bytes may differ; case formulas should agree exactly as parsed JSON.

To use another location, set `B245_INPUTS` and `B245_OUTPUT` to existing/writable directories. The symbolic engine accepts `--table`, `--sites` and `--output`; new candidates still require their own source correspondence and blank-start proofs. Its fixed ordered-source guard deliberately prevents silently changing the reference program.

`independent_runtime.py` is an imported helper for these public entries. Its historical `main()` is not a supported reproduction entry. Use the commands above or the separate candidate builder below.

## Reproduce diagnostic candidates and witnesses

```sh
python3 -B code/build_failed_candidates.py
python3 -B code/finite_regression.py
python3 -B code/test_sparezero244.py
python3 -B code/prove_counterexample_family.py
python3 -B code/verify_quotient_and_drift.py
python3 -B code/check_symbolic_instantiation.py
```

The builder regenerates the exact three failed old-label tables under `results/candidates/` and the changed reassociation site list. They are diagnostic failures, not proposed smaller consistency machines. The finite regression expects baseline 0 failures, reassociation 702, and scanner 99, out of 8,391 cases per table. The spare-zero test rejects all 1,931 zero-decrement cases in each of three profiles. The parametric witness proves the reassociation's wrong return after `658 + 8*n` steps for arbitrary padding and any nonempty spare suffix.

The counterexamples establish wrong instruction outcomes in valid frames. Reachability of those frames from the blank run, or different eventual halting status, is not asserted.

`synthesize_grammar.py proposed-grammar.json output-prefix` reconstructs a table with the same framework from a proposed grammar. It is a syntactic constructor only, not a correctness certificate. On the unchanged pinned grammar it reproduces both published tables byte-for-byte.

The bounded row-replacement searches are `code/search_retarget.py`, `code/search75_retarget.py` and `code/search75_fullcases.py`; run them after building the failed candidate tables. They write separate result JSON under `B245_OUTPUT`. Their scope is the conservative local contracts and finite whole-instruction profiles described in the report.

## Grammar search

See `search/SEARCH_REPORT.md` and `search/search-results.json` for exact scopes and terminal statuses. Six time-capped heuristic runs tried 102,191,077 proposals, with best 128 grammar rules. The finite two-rotation family exhausted 26,001 proposals and contains no smaller or zero-five grammar under its specified restrictions. The all-bootstrap-locks zero-five obstruction is exact. Restricted MILP infeasibility is solver-reported, and broader timeouts are inconclusive.

Search source dependencies: Python standard library; C++17 for C++ searches; NumPy and SciPy/HiGHS only for optional MILP models. No downloaded repository code is imported or compiled. To rerun the stdlib exact obstruction and enumeration:

```sh
export B245_INPUTS="$PWD/inputs"
export B245_OUTPUTS="$PWD/search-reproduced"
mkdir -p "$B245_OUTPUTS"
python3 -B search/prepare_search.py
python3 -B search/prepare_joint.py
python3 -B search/prepare_unlocked_roots.py
python3 -B search/verify_zero5_obstruction.py
python3 -B search/surgical_zero5.py
```

`search/reproduce_search.sh` also reruns the time-capped stochastic jobs and optional MILP jobs. Inspect its commands before running; it requires a C++ compiler and the optional solver dependencies. Time-based search cooling means the same seed on another machine need not yield identical proposal counts or grammar bytes. The retained logs are the actual reported runs.

## Rebuild the document

With a normal TeX Live installation including Latin Modern, AMS packages, enumitem, microtype and hyperref:

```sh
make pdf
```

The PDF was rendered and visually inspected page by page. No transient TeX build artifacts or compiled search binaries are distributed.

## Attribution and limitations

Mira-Cult supplied the original calculus and machine; Jeff Ketchersid supplied the upstream verification; Andrew James Wade supplied the compiler framework; ProveIt contributors and the routed-grammar submission supplied subsequent reductions. This archive adds independent checking, diagnostic experiments and the described search work. It does not replace or relicense inherited sources.

The pinned ProveIt root license is MIT No Attribution. Its imported upstream busy-beaver snapshot is explicitly excluded from that blanket grant. The original incoming archive's notices preserve that distinction. Input retrieval is provided instead of redistribution of those inherited materials. No newly compiled Lean/Rocq theorem, serialized first-order ZFC proof, PA-internal endpoint, unconditional nonhalting or state-minimality claim is made.
