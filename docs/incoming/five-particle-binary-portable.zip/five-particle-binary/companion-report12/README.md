# Companion Report 12

These three authored files are copied byte-for-byte from the prior delivered four-mass report:

- four-mass-decidability.pdf
- four-mass-decidability.tex
- figures/binary-four-particle-shuttle.pdf

They make the sharp-threshold lower-bound dependency directly inspectable. The new article does not re-prove this separate all-rule classification. The companion's original executable suite remains in its separate prior release and is not replayed by the new archive. The unchanged companion describes the absence of a binary upper bound in that earlier report; the new report supplies it.

COMPANION_SHA256SUMS pins the copied bytes. The main release manifest pins this file and the companion manifest as well.
