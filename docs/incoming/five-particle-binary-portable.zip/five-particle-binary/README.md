# Five particles in a binary conservative cellular automaton

This portable release contains a 24-page mathematical report, its editable LaTeX source, the exact binary compiler and finite-horizon polynomial emitter, the pinned literal universal two-counter source and its all-input simulation proofs, complete examples, and independent executable audits.

## Main conclusions

- Every finite deterministic two-counter ADD/SUB program compiles to a fixed binary conservative CA using exactly five occupied sites on valid runs
- The rule is fully defined and conservative on arbitrary binary configurations; malformed simulation geometry is not excluded
- The pinned 8,408-row universal instance has radius 756,787 and an anchored halt word of length 50,452
- Its 1,272,679,260 indexed guarded component cases and its 2^1,513,575-row Boolean truth table are specified by the finite algorithm; neither is materialized as a flat table
- For each fixed literal-source horizon h, the natural-domain polynomial core has 10,750h witnesses, 2,344h+1 squared residuals and degree at most four, with an empty or singleton complete witness fiber
- Exact physical time costs one more variable and square; nonnegative-real witness semantics cost one more selector-norm square per source step, still with natural external inputs

Universality uses the primary finite-input Neary–Woods theorem and the included all-input source simulations, not the row count. The sharp five-particle threshold additionally uses the separately proved lower bound in companion Report 12, included unchanged. No priority, reversibility, intrinsic-universality, efficiency, minimal-radius or unbounded universal-polynomial claim is made.

## Read and reproduce

Open report/five-particle-binary-compiler.pdf for the report. Run from any directory:

    python /path/to/five-particle-binary/replay.py

Python 3.10 or later and its standard library are sufficient. Replay verifies the full manifest before and after executing all producer checks, the source verifier, independent audits, normal and optimized compiler regressions, API boundary tests, and report-fixture reconstruction. It prints a final JSON receipt. No network or package installation is required.

To rebuild the main PDF with TeX Live:

    cd report
    sh build.sh

The bundled PDF uses the included vector figure; regenerating that figure is optional and requires matplotlib. The exact trace and plotting source are under report/figures/. Only the main report is rebuilt by build.sh. The three authored companion files are byte-preserved from the earlier release.

## Contents

- report/: main PDF, LaTeX, reproducible build script, vector trace, source and verified trace data
- compiler/: exact compiler, emitter, small accepted polynomial and witness, universal h=1 schema, proof text, receipts and source replay
- verification/: numerical fixture identity check
- provenance/: primary-source review receipt and user-facing provenance
- companion-report12/: unchanged authored lower-bound PDF, LaTeX and required vector figure; its prior executable suite is not duplicated here
- SHA256SUMS: all release file digests except this manifest itself

The universal h=1 constant-input schema is not accepting; the independent report fixture check confirms this. The separate small example genuinely accepts after two source instructions and 472 CA ticks, with all five particles traced at every tick.

The report and proofs were prepared with AI assistance and independently audited as mathematical arguments. These are not proof-assistant certificates. Third-party primary PDFs and screenshots, private drafts, caches, and prior executable releases are not included.
