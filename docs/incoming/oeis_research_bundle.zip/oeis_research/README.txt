SIGNS, FACTORIAL DIVERGENCE, AND BELL NORMALIZATION
New results for OEIS A321941, A088714, and A088713
Research manuscript, 4 October 2026

MAIN FILES

  oeis_research.pdf       Complete article.
  oeis_research.tex       Self-contained editable LaTeX source.
  SOURCE_AUDIT.json       Pinned repository paths, blob identifiers,
                          inherited inputs, new results, and review scope.
  MANIFEST.sha256         SHA-256 checksums of the files in this archive.
  code/                  Exact verifiers and numerical diagnostics.
  data/                  Exact coefficients and recorded verification output.

The TeX source embeds its bibliography and its short finite certificate.
It does not require any external image or TeX fragment.

MAIN RESULTS

1. For the Brent--Glasser--Guttmann coefficients r_k = 64^k d_k,
   r_k < 0 for every k >= 3. Exact arithmetic checks k = 3,...,31;
   the manuscript proves a uniform strict bound for every k >= 32.

2. The same coefficients have an all-orders large-k expansion. In
   particular, r_k ~ -16^k (k!)^2 / (pi^(3/2) k^(3/2)).
   The transform sum d_k s^k/(2k)! has radius 16 and a logarithmic
   singularity at the positive boundary.

3. For A088714, a_n = C_* N_n (1 + O(W(n)^5/n)), where 0 < C_* < infinity
   and N_n is the explicit smooth normalizer in the article.
   Therefore a_n ~ C_* Bell(n) exp(W(n)^2 + 3W(n)).

4. For its companion A088713, c_n ~ a_(n-1), with a fixed-order
   endpoint expansion and the same normalization constant C_*.

The article proves the complementary-endpoint expansion needed for
the full normalization and gives nine further research questions.
The value of C_* is not certified numerically in this deliverable.
The sharper pointwise ratio correction for A088714 remains open here.

BUILD THE PDF

Use a standard TeX Live installation with latexmk:

  latexmk -pdf -interaction=nonstopmode -halt-on-error oeis_research.tex

Alternatively, run pdflatex repeatedly until references stabilize:

  pdflatex -interaction=nonstopmode -halt-on-error oeis_research.tex

The source uses ordinary packages, including amsmath, amsthm, mathtools,
mathrsfs, lmodern, microtype, booktabs, tabularx, xurl, enumitem, fancyhdr,
listings, and hyperref.

RUN THE VERIFICATION

Python 3.11 or later is recommended. The primary verification uses only
the Python standard library:

  python3 code/run_checks.py

This command runs the scripts in a temporary directory, compares their
results with the recorded files, and writes data/verification_run.txt
and data/verification_summary.json.

An optional independent symbolic cross-check uses SymPy. The exact
version used for the delivered run is pinned in requirements-symbolic.txt.
With SymPy available, include it by running:

  python3 code/run_checks.py --symbolic

The primary exact finite certificate and coefficient generator do not
require SymPy. Individual scripts can also be run directly:

  python3 code/finite_certificate.py
  python3 code/verify_sign.py
  python3 code/independent_check.py
  python3 code/large_order.py
  python3 code/verify_complement.py

When run directly, the first group of full verifiers writes its JSON
results next to the script. The short finite certificate only prints
its successful conclusion. The endpoint verifier prints JSON.

To reproduce the finite normalization table:

  python3 code/normalization_diagnostics.py --max-index 600 --precision 80 \
    --coefficients data/coefficients_600.txt --output data/normalization_80.json

  python3 code/normalization_diagnostics.py --max-index 600 --precision 120 \
    --coefficients data/coefficients_600.txt --output data/normalization_120.json

The coefficient file contains consecutive "n a_n" lines from 0 through
600, with exact integers. To regenerate it from scratch, choose a new
nonexistent path with --coefficients. Generation through 600 took about
35 seconds on the research runtime; timings vary by machine.

The optional independent large-order check can be run as:

  python3 code/asymptotic_check.py 8

WHAT THE CHECKS MEAN

The sign certificate uses fractions.Fraction, so sign decisions are exact.
The independent sign computation starts from the published BGG polynomial
recurrence and compares it with a separately constructed heat expansion.
The endpoint verifier checks exact coefficient identities and both
large-index decompositions in a finite range.

The normalization diagnostics use high-precision Decimal arithmetic,
with Newton iteration for the positive real Lambert W function.
Agreement at two precisions is a numerical stability check, not interval
arithmetic and not a certified bound on the limiting constant C_*.

Infinite sign assertions, asymptotic tails, convergence, and error rates
are proved in the manuscript. They are not inferred from finite tests.

SOURCE AND REVIEW STATUS

The repository snapshot is:
  b7e4f25b6e79cc669fb245cba520017a0f4228b7

See SOURCE_AUDIT.json and the article's source appendix for precise
paths, exact file blobs, inherited theorems, and the novelty boundary.

The proofs and their integration received independent internal reviews.
The manuscript is not externally peer reviewed or proof-assistant
formalized, and no exhaustive worldwide priority claim is made.
The deliverable does not modify the repository or the OEIS entries.
