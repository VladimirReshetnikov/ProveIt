# Collision-Sensitive Amplification of Respected Arrangements

Research manuscript prepared for Vladimir Reshetnikov, 6 October 2026.

## Main files

- `collision_sensitive_arrangements.pdf`: the 27-page compiled article.
- `collision_sensitive_arrangements.tex`: self-contained LaTeX source, including bibliography.
- `verify.py`: deterministic finite checks, using only the Python standard library.
- `verification_results.json`: structured output from the executed verification run.
- `verification.txt`: readable execution log.
- `integration.md`: proposed interfaces for the supplied Lean development; no claim of compilation.
- `provenance.json`: pinned repository sources and public literature references.
- `build.sh`: reruns the checks and compiles the article with pdfLaTeX.

## Main proved statements

Theorem 3.3 gives the division-free inequality

    R_2^(d-1) <= C^(d-2) R_d,    C = R_1,    d >= 2.

Lemma 4.1 proves C <= sum_x |B_x|^3. Corollary 4.2 gives sharp density-sensitive refinements of Gowers's Lemma 14.7.

Theorem 5.5 retains the SAME collision parameter in the preceding product-property step:

    a_2 >= gamma^(8 * 2^k) chi^4.

Theorem 5.6 combines these before estimating chi, obtaining

    a_d >= beta^((3d-2) * 4^k)
           * gamma^((6d-4) * k * 4^k + 8 * (d-1) * 2^k).

For d=8 this is

    a_8 >= beta^(22 * 4^k) * gamma^(44 * k * 4^k + 56 * 2^k).

The definitions are a_d = R_d/(M^(2d+1) n^(2d-1)) and chi = C/(M^3 n), where M is the horizontal ambient size and n the vertical ambient size. The group-valued product property is stated precisely in Definition 5.1. For the paper's cyclic setting, M=N^k and n=N.

Theorem 8.2 proves a dimension-free inverse result near the cubic cap:

    Q(A) >= (1-epsilon) |A|^3,    0 <= epsilon <= 1/100

implies a Cartesian coset C0 with

    |A intersect C0| >= (1-8 epsilon)|A|,
    |C0| <= (1+2 epsilon)|A|,
    |A symmetric_difference C0| <= 18 epsilon |A|.

Theorem 10.2 gives a complete normal form for simultaneous equality in moment amplification and the cubic cap. Theorem 12.1 extends the main bounds to vertex-product weights in [0,1]. The article also proves spectral stability, side-vector profile refinements, sharpness examples, and a geometry–amplification dichotomy.

## Important source distinction

The inspected repository already documents that the gamma exponent printed in Corollary 14.6 is not supported by its proof. It uses the safe exponent 3*k*4^(k+1), and consequently 21*k*4^(k+1) in Lemma 14.8. The article compares with this corrected statement and separately derives the unweakened supported exponent. It does NOT claim to establish the smaller unsupported printed exponent.

The repository pin is:

    9ea383e9b28d885a936d5d681cd5584fffd2cb29

## Reproduce the checks

Requirements: Python 3.10 or later. No third-party Python packages or network access are needed.

    python3 verify.py

The mathematical count and inequality checks use integers or `fractions.Fraction`. Thirteen auxiliary Fourier checks alone use complex floating point with tolerance 1e-9. The small-group stability checks mostly encounter exact equality; two additional positive-deficit examples are included. This limitation is stated in the article.

The run checks 1,036 exhaustive nonempty horizontal subsets, 6,560 exhaustive partial-domain joint-extremizer cases, 180 additional ternary joint-extremizer cases, rational vertex weights, label decompositions, and other examples. See the JSON file for the complete case counts.

## Rebuild the PDF

Requirements: a normal TeX Live or MiKTeX installation with pdfLaTeX, Latin Modern, AMS packages, microtype, geometry, booktabs, enumitem, hyperref, and fancyhdr.

    sh build.sh

No BibTeX run is required; the bibliography is embedded in the TeX file. Three pdfLaTeX passes resolve the contents and references. The PDF is copied back to the package root, while build logs remain in `build/`.

## Status and limits

The universal statements are supported by the written mathematical proofs. Finite tests supplement these proofs; they are not a substitute for them. This is a research manuscript, not a peer-reviewed publication. Priority over the full literature has not been established.

No new Lean theorem was compiled or kernel-checked in this work, no repository changes were pushed, and no new final Szemeredi bound is claimed. Existing repository build/audit reports are identified as source reports, not independently reproduced results. Later proof-chain obligations and proposed further research are distinguished from the proved local theorems.
