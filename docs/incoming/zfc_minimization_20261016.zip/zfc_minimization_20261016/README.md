# Small Consistency Machines

Research continuation prepared for Vladimir Reshetnikov, 16 October 2026.
The complete report is [report.pdf](report.pdf), with editable source in
[report.tex](report.tex) and sections/.

## Outcome

**No new blank-start consistency machine below 253 working states was
established.** The existing 253-state table is prior work by mira-emmy,
reducing Mira-Cult's machine and using Jeff's verification infrastructure.
This archive gives a detailed proposal, a proved obstruction to dropping
output support, a measured fixed-label CP/GIC experiment, and finite
state-sharing searches with explicit certificates and limitations.

The mathematical target is a binary one-tape machine, started on all-zero
tape, for which ZFC proves that nonhalting is equivalent to Con(ZFC).
Every working initialization state is counted; a separate halt state is not.

| Item | Result | Scope |
|---|---|---|
| Existing public baseline | 253 working states | Upstream Coq finite-refutation equivalence, successful CI; no new local Coq rebuild |
| Unsupported closure theory | ZFC constructs its ordinal model | Ordinary proof in the report; even Extensionality, Power Set, Infinity and Foundation do not fix the weakening |
| Fixed CP/GIC emission | 283 states after 1,272 compilations | Original complete logical rows retained; intermediate certificates, no new machine consistency theorem |
| State-sharing search | 453,939 single-row changes; 707 runtime survivors | No accepted startup within bounds; 2,106 long representatives remain unresolved |
| Prepared runtime detours | Three additional 252-state tables | Same blank-start halting behavior as the known prepared core; no new initializer |

## Read the report

Sections 1–3 audit the requested commits, benchmark, machine model and small
theories. Section 4 proves the regular-ordinal obstruction. Section 5 gives
finite-presentation design restrictions. Sections 6–7 describe the new
compiler and machine experiments. Sections 8–9 state the internal proof
obligation and research proposal. Appendix A explains the artifacts.

The report distinguishes external proof-assistant verification, ordinary
mathematical proofs, executable finite certificates, bounded searches and
uncompleted internalization. A register-program certificate is not a theorem
about an arbitrary binary-tape compiler.

## Quick offline verification

Python 3.10 or later is sufficient, with assertions enabled. No downloads or
third-party Python packages are required.

    python3 reproduce.py --quick

The gate verifies the archive manifest and exact table hashes; audits the
253-, 254- and experimental 283-state tables; checks the fixed emitter,
144 scalar cases, and 4,248-pair register-operation certificate; and verifies
the optimizer's runtime contracts, finite invariant, first-write classes,
and 2,845 short blank-ray certificates.

It does not repeat the 1,272 compiler runs or the 6.3 billion moves of
bounded startup simulation. Full reproduction instructions are in
[fixed_emission/README.md](fixed_emission/README.md) and
[optimizer/README.md](optimizer/README.md). Run full experiments in a fresh
copy: they overwrite generated outputs and timing metadata.

## Build the report

Use a standard pdfLaTeX installation and GNU Make:

    make pdf

Alternatively, run this command three times:

    pdflatex -interaction=nonstopmode -halt-on-error report.tex

The report has no network dependencies or external bibliography database.
The build directory is temporary; it is excluded from the archive.

## Provenance

Measurement snapshot:
VladimirReshetnikov/ProveIt@4747142d5d15213eb711bdadfa3cc7e769fcb7a7.

Requested commits:
6d8bc7f1ba02c83e54757366f019f61b966ed0b7,
63c83cf79986f8a92bb75460848a1d4f863b7b15,
0301aa64e0676bed17402a63de46996631252a51.

Public 253-state source:
mira-emmy/busy-beaver@0d544f2a2e3c18f12278441a74b7879f31cbe856,
[upstream PR 20](https://github.com/jeff87654/busy-beaver/pull/20).

Public 254-state and theory snapshot:
jeff87654/busy-beaver@297ab8df7e5de329605c3875b4934643b371a5e3.

Later ProveIt batch-150 proposals were inspected for attribution, using
catalogue 38798c7ddf97a5b555db304722cde1b5adf0fa18 and observed head
2f9c650e1fbc174f13d9a524099be16390922192. Numerical measurements remain
frozen to the earlier snapshot.

Full citations are in the report bibliography; machine and source hashes
are in the data and experiment manifests. Upstream licenses and attribution
notices are retained alongside the relevant sources. The archive includes
only the small source snapshots needed to reproduce these experiments.

## Integration status

This is a research artifact for review and incorporation. It does not alter
the ProveIt repository or designate an experimental table as a replacement
for the verified baseline. The source-09 fixed-label idea and later native
closure/environment proposals are explicitly attributed as prior work.
The exact internalization obligations are in
[data/internalization_obligations.json](data/internalization_obligations.json).
