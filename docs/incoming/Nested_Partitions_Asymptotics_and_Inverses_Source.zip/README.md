# Nested partitions with distinct block lengths

Research report 181, 3 October 2026. The sequence is OEIS A358836.

## Main results

The report starts from Andrew Howroyd's existing product for collections of integer-partition blocks whose numbers of parts are distinct. Its exact nested-denominator reduction gives every fixed power-log order of the free energy. A zero-free disk of radius proportional to t², an all-angle characteristic-function estimate, and an integrated weighted Taylor remainder prove every fixed exact-saddle Edgeworth order.

The three leading growth tiers are made explicit. The constant-order completion gives an elementary relative equivalent with error O(n^(-1/4) log^4 n). Finite saddle reversion supplies any fixed additional algebraic accuracy. A one-dimensional inverse carrier has bounded error for the integer threshold. Higher-order threshold information is expressed as two-floor envelopes, with rounding and the fixed piecewise-linear interpolation barrier stated explicitly.

Uniform complex-marker estimates prove the Gaussian law for the occupied-length count. Truncated-product coefficient ratios prove the largest-length Gumbel law and its joint independence from that Gaussian limit. The conditional mean correction is also explicit.

The article includes the analytic proofs, source comparison and further questions. It does not claim an effective finite asymptotic onset, convergence of its full formal series, a universal exact inverse floor formula, or global historical priority.

## Credit and scope

The product is prior work, recorded by Andrew Howroyd on OEIS in 2022. Gus Wiseman's composition interpretation is also prior. Jacobi and eta transformations, MacMahon/Mellin expansions, saddle and Edgeworth methods, Fermi-type counting and conditioning are classical. SOURCE_AUDIT.md preserves the bounded search scope, exact model distinctions, and which primary sources were actually read or were inaccessible. Search misses are not novelty certificates.

## Files and reproduction

- Report181.tex: complete editable manuscript
- build.py: deterministic no-shell-escape PDF/source-ZIP builder
- code/ and data/: standard-library exact verifier and reference inputs
- optional/: floating-point diagnostics and separate dependency notes
- README_CODE.md: precise commands, ranges, dependencies and integrity model
- guard_tests.py and test_build.py: mathematical and package guard tests
- verify_manifest.py: package-manifest verification

Run the commands in README_CODE.md. The normal build needs Python 3.10 or later and pdfLaTeX; the exact mathematical core uses only the Python standard library. Optional mpmath diagnostics are not part of the exact or proof-critical build.

The exact core regenerates all 601 coefficients a_0 through a_600 with ordinary integer convolution, independently enumerates compositions through n=18, checks all ten finite-end coefficients, enumerates E1/E2, checks the free-energy algebra through t^10, and verifies the constant-order Legendre identity. These finite tests support the formulas; they are not a proof of an asymptotic theorem. The manuscript proves those theorems separately. Frozen numerical tables are diagnostic observations, not rigorous interval enclosures or certificates of conditioned limit laws.

No external repository or OEIS entry is modified by this package. Building does not download dependencies or execute optional experiments. PDF and source ZIP are intended to be reproducible with the same TeX toolchain; reproducibility across different TeX versions is not promised.
