# Stirling residues and finite candidate lists

The report proves an exact congruence identifying a scaled Lehmer–Comtet block with an unsigned Stirling row. It determines the first nontrivial digits of the associated p-adic roots and combines them with a real derivative-root bound.

Main conclusions:

- For p>m≥2, every positive integer zero on offset m(p−1) belongs to the explicit small set of j<m for which p divides the Stirling number c(m,j), plus at most one larger candidate m−1+C_p p², where C_p is binomial(m,2) modulo p
- Every positive-column entry on offset 5(p−1) is nonzero for every odd prime p
- On offset (p−1)², for odd prime p, the only possible positive integer zero is Y=p²+p−2
- On the different offset p²−1, for p≥5, every positive integer zero must have 1≤Y≤p−1

A candidate is not an asserted zero. The final candidates in the two square families are not classified in general. The structural Y=0 derivative cancellation remains, and the global Lehmer–Comtet exact zero conjecture is still open.

Contents:

- article.pdf and article.tex: full proofs, source scope, and primary references
- verify_stirling.py / stirling_checks.json: direct rational powers check 134 Stirling residues, 134 scaled-triangle congruences, and 134 derivative/root-displacement identities
- verify_prime_square_lifts.py / prime_square_lifts.json: exact roots modulo p³ for p=3,5,7,11
- verify_square_candidates.py / square_candidates.json: exact rational values at the one remaining (p−1)² candidate for p=3,5,7,11,13,17,19, all nonzero
- replay_falling_products.py / replay_falling_products.json: an independent integer-product replay with 162 checks of each residue, derivative and displacement, plus prime-square branches through p=19 and the seven distinct-square candidates
- prime_multiple_companion.pdf and prime_multiple_companion_source.zip: unchanged preceding report with the positivity cone, arithmetic localization, complete multiplier2/3/4 families, and general fixed-m nonvanishing theorem
- build_local.sh: local TeX build wrapper

All four current checkers use only the Python standard library:

    python verify_stirling.py
    python verify_prime_square_lifts.py
    python verify_square_candidates.py
    python -O replay_falling_products.py

The polynomial construction in the prime-square lift checker is the longest replay. All checkers use exact rational/integer arithmetic and explicit failure checks. Finite replays provide reproducibility; the manuscript proves the infinite statements.

The source comparison is pinned to ProveIt commit ca81647a9f679e96d49ffdbc54b0c0ab13d10a36, file blob 7344f3aa4dc9344fb8648326e74e0d4bcc33eada, whose relevant current version was checked on 1 October 2026. The note credits the classical Bernoulli/Stirling p-adic framework and derivative barrier. It makes no exhaustive priority claim and is a conventional mathematical proof, not a formal proof-assistant development.
