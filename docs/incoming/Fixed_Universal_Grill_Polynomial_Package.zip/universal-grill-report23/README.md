# Report 23 — A fixed universal Grill polynomial

Read `article/report23.pdf` (19 pages). Editable LaTeX is `article/report23.tex`; `article/build.sh` rebuilds the PDF with a conventional installed LaTeX distribution. The complete scientific source and independent checks are in `reproducibility/`.

## Result and scope

One literal 397,488-phase Grill program gives one complete arithmetic polynomial with ordinary positive input and five program parameters fixed for each represented computably enumerable language. It has 797,135 positive witnesses and 3,600,546 operations: 803,517 multiplications and 2,797,029 additions/subtractions. Its total-degree upper bound is 71,731,007.

The language theorem is conditional on the pinned full native/recoder and finite-input U15 theorems and applies to the explicit valid five-parameter slices. It is not a new general MRDP theorem or an optimality claim. No full giant Pell tuple or complete universal accepting execution is claimed to have been materialized. The costs use literal-integer arithmetic, not bit complexity.

The actual 61,209,290-byte DAG is included, not just its generator. Its SHA-256 is:

`a07c1ba41e3a18fafd05c19b8ac39211b0475e30ed8a08ddf43c45a9f5f440f2`

## Offline checks

Python 3.10 or newer on Linux is required; only the standard library is used. The resource-limited checkers rely on Linux/Unix resource measurements. Allow about 1 GiB RAM, 250 MiB temporary disk, and several minutes. No network access or upstream Python execution is used.

From the extracted release directory:

```sh
python3 -B verify_release.py
python3 -B verify_release.py --replay
python3 -B -O verify_release.py --replay
python3 -B reproducibility/test_integrity.py
python3 -B -O reproducibility/test_integrity.py
```

These entry points also work from any CWD when passed their full extracted path. The replay writes only to a temporary directory outside the sealed release. It re-emits the complete DAG, compares its exact hash and scientific manifest, and runs all 15 source/component/whole-circuit checks. Normal and optimized Python both retain explicit invariant validation. The inventory is checked again after replay.

`RELEASE_INVENTORY.json` covers every delivered file, including the article, build script, proofs, audits, data, source, and portable code. Its digest is in `RELEASE_INVENTORY.sha256`. The nested reproducibility inventory is independently enforced. Added files, missing files, byte changes, undeclared empty directories, and symlinks are rejected. The separately supplied ZIP hash is the external distribution anchor; a local manifest cannot authenticate an attacker who replaces both files and all digests.

## Provenance and review

`reproducibility/PROVENANCE.json` keeps original frozen hashes separate from delivered hashes and transformations. `reproducibility/PORTABILITY.md` documents path sanitation, inert original-source naming, module-relative replay paths, assertion-to-exception changes, and staged metadata adaptations. This makes the release portable without falsely relabelling transformed bytes as original bytes.

`qa/` contains the article review and portable-replay receipts. Historical scientific audit files keep their original scope, including statements about work still pending when those audits were written. The complete composition proof and final whole-circuit audits record the completed mathematical and source result.

No previous report or upstream repository was altered. A replay's bounded simulations and exact circuit checks support the implementation; the parametric proofs and explicitly imported full positive converses establish the unbounded theorem.
