#!/usr/bin/env python3
"""Check the exact U214 -> U213 source change, independently of its builder.

This is a finite source/CFG binding audit, not a proof-assistant certificate.
Uniform arithmetic macro contracts and the logical exchange theorem are
separate mathematical premises recorded in the accompanying paper.
"""
from pathlib import Path
import argparse
import hashlib
import json
from functools import cache

OLD_SHA = '9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083'
NEW_SHA = '2138b34bea88ab0fd469155229e6cb34ee185d45047d1b9994f4933be4d88896'
K215_SHA = '17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
RANGES = {
    'a': (26, 52), 'b': (52, 78), 'c': (107, 133),
    'I': (78, 105), 'Q': (78, 107), 'R': (695, 723), 'N': (995, 1042),
}
WORD = 'a c c a R a I Q c a a c R a b R I Q a c a R I I Q N I Q'.split()
START, STOP = 2885, 3659


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse(rows):
    leaves = {p: (op, arg) for p, op, arg in rows}
    need(len(leaves) == len(rows), 'Duplicate source path')
    prefixes = {p[:i] for p in leaves for i in range(len(p))}
    need(not prefixes.intersection(leaves), 'Overlapping source path')
    need(all(p + bit in prefixes or p + bit in leaves
             for p in prefixes for bit in '01'), 'Not a full binary tree')

    def visit(path):
        if path in leaves:
            return leaves[path]
        return visit(path + '0'), visit(path + '1')

    return visit('')


def leaf(node):
    return isinstance(node[0], str)


def metrics(root, rows):
    nodes = set()

    def visit(node):
        if node in nodes:
            return
        nodes.add(node)
        if not leaf(node):
            visit(node[0])
            visit(node[1])

    visit(root)
    return {
        'dag_nodes': len(nodes), 'leaf_occurrences': len(rows),
        'maximum_depth': max(len(p) for p, _, _ in rows),
        'maximum_zero_run': max(len(z) for p, _, _ in rows for z in p.split('1')),
    }


def cfg_intervals(rows):
    bounds = {}
    for i, (path, _, _) in enumerate(rows):
        for j in range(len(path) + 1):
            prefix = path[:j]
            if prefix not in bounds:
                bounds[prefix] = [i, i + 1]
            else:
                bounds[prefix][1] = i + 1
    result = []
    for i, (path, op, arg) in enumerate(rows):
        if op == 'CI':
            targets = (i + 1,)
        elif op == 'CH':
            targets = ()
        else:
            edge = '1' if op == 'CC' else '0'
            depth = 1 if op == 'CD' else arg
            positions = [j for j, bit in enumerate(path) if bit == edge]
            need(depth <= len(positions), ('Escaping branch', i, path))
            ancestor = path[:positions[-depth]]
            target = bounds[ancestor][0 if op == 'CC' else 1]
            targets = (target, i + 1) if op == 'CD' else (target,)
        result.append((op, arg, targets))
    return result


def cfg_arithmetic(rows):
    leaves = {path: i for i, (path, _, _) in enumerate(rows)}
    width = max(map(len, leaves))
    checks = 0

    def locate(prefix):
        nonlocal checks
        padded = prefix + '0' * width
        for size in range(1, width + 1):
            if padded[:size] in leaves:
                need('1' not in prefix[size:], 'Stray one after successor')
                checks += 1
                return leaves[padded[:size]]
        raise ValueError('Successor has no source leaf')

    def inc(path):
        if not path:
            return ''
        return format((int(path, 2) + 1) % (1 << len(path)), '0' + str(len(path)) + 'b')

    def cut(path, bit, depth):
        positions = [i for i, value in enumerate(path) if value == bit]
        return path[:positions[-depth]] if len(positions) >= depth else ''

    result = []
    for path, op, arg in rows:
        if op == 'CI':
            targets = (locate(inc(path)),)
        elif op == 'CD':
            targets = (locate(inc(cut(path, '0', 1))), locate(inc(path)))
        elif op == 'CB':
            targets = (locate(inc(cut(path, '0', arg))),)
        elif op == 'CC':
            targets = (locate(cut(path, '1', arg)),)
        else:
            need(op == 'CH', ('Unknown primitive', op))
            targets = ()
        result.append((op, arg, targets))
    need(locate('') == 0, 'Initial source ordinal is not zero')
    return result, checks


def symbolic(word):
    saved, top = ['original-stack'], 'original-top'
    for token in word:
        if token in ('a', 'b', 'c'):
            saved.append(top)
            top = token
        elif token == 'N':
            top = ('I', top, 'F')
        else:
            need(token in ('I', 'Q', 'R') and len(saved) > 1, 'Stack underflow')
            top = (token, saved.pop(), top)
    need(saved == ['original-stack', 'original-top'], 'Incorrect net stack effect')
    return top


def audit(new_path, old_path, k215_path):
    need(sha(new_path) == NEW_SHA, 'Incorrect new source')
    need(sha(old_path) == OLD_SHA, 'Incorrect U214 source')
    need(sha(k215_path) == K215_SHA, 'Incorrect K215 source')
    new, old, k215 = [json.loads(p.read_text()) for p in (new_path, old_path, k215_path)]
    root = parse(new)
    need(len(new) == len(old) == 3928, 'Incorrect source length')
    ng, og, kg = map(cfg_intervals, (new, old, k215))
    exact = []
    for token in WORD:
        lo, hi = RANGES[token]
        offset = START + len(exact)
        for op, arg, targets in kg[lo:hi]:
            need(op != 'CH' and all(lo <= dst <= hi for dst in targets),
                 ('Macro escapes its interval', token))
            exact.append((op, arg, tuple(offset + dst - lo for dst in targets)))
    need(START + len(exact) == STOP and ng[START:STOP] == exact,
         'New emitter differs from exact inherited macro concatenation')
    outside = list(range(START)) + list(range(STOP, len(old)))
    for i in outside:
        need(all(not START < dst < STOP for dst in og[i][2]),
             ('Exterior branch enters old emitter interior', i))
        need(ng[i] == og[i], ('Changed exterior instruction or control target', i))
        need(new[i] == old[i], ('Changed exterior address', i))
    arithmetic, count = cfg_arithmetic(new)
    normalized = [(op, arg, tuple(dst % len(new) for dst in targets))
                  for op, arg, targets in ng]
    need(arithmetic == normalized, 'Independent control-flow resolvers disagree')
    I = lambda a, b: ('I', a, b)
    Q = lambda a, b: ('Q', a, b)
    R = lambda a, b: ('R', a, b)
    E = R('c', 'a')
    G = Q('a', I(R('a', 'c'), R('a', 'b')))
    U = Q('c', I(E, 'a'))
    L = Q('c', I(G, I('a', E)))
    H = Q('a', I(U, I(L, 'F')))
    need(symbolic(WORD) == H, 'Incorrect constructor expression')
    result = {
        'status': 'EXACT_SOURCE_AND_CONSTRUCTOR_BINDING_PASS',
        'source_sha256': NEW_SHA, 'baseline_source_sha256': OLD_SHA,
        'k215_source_sha256': K215_SHA, 'source_metrics': metrics(root, new),
        'emitter_interval': [START, STOP], 'emitter_primitive_count': len(exact),
        'exterior_primitive_count': len(outside),
        'exterior_addresses_and_guarded_control_graph_unchanged': True,
        'no_external_entry_to_strict_emitter_interior': True,
        'independent_successor_checks': count,
        'changed_source_addresses': sum(x[0] != y[0] for x, y in zip(new, old)),
        'macro_word': WORD, 'symbolic_shell': H,
        'scope': 'Exact finite source binding only; macro contracts, logical exchange, '
                 'physical runtime, and blank startup are separately justified.',
    }
    need(result['source_metrics'] == {
        'dag_nodes': 198, 'leaf_occurrences': 3928,
        'maximum_depth': 45, 'maximum_zero_run': 6}, 'Source metric mismatch')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('new_source', type=Path)
    parser.add_argument('u214_source', type=Path)
    parser.add_argument('k215_source', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = audit(args.new_source, args.u214_source, args.k215_source)
    encoded = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end='')


if __name__ == '__main__':
    main()
