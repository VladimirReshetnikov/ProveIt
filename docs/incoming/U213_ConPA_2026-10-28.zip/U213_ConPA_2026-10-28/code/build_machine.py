#!/usr/bin/env python3
"""Reconstruct the frozen U213 table; no optimizer or network is required."""
from pathlib import Path
import argparse
import hashlib
import json


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse(path):
    rows, starts = {}, []
    for line in path.read_text(encoding='ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(line)
        if not line or line.startswith('#'):
            continue
        fields = line.split()
        need(len(fields) == 5, 'Wrong transition width')
        q, bit, write, direction, target = fields
        q, bit, write, target = map(int, (q, bit, write, target))
        need(q >= 0 and target >= 0 and bit in (0, 1) and write in (0, 1),
             'Invalid state or symbol')
        need(direction in ('L', 'R') and (q, bit) not in rows,
             'Invalid direction or duplicate row')
        rows[q, bit] = write, (1 if direction == 'R' else -1), target
    need(starts == ['#! start 0'], 'Wrong start declaration')
    return rows


def encode(rows):
    return ('#! start 0\n' + ''.join(
        f'{q} {bit} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, bit), (w, d, z) in sorted(rows.items()))).encode('ascii')


def census(rows, count, halt=254):
    states = {q for q, bit in rows}
    need(len(states) == count, 'Wrong working-state count')
    need(set(rows) == {(q, b) for q in states for b in (0, 1)},
         'Partial deterministic table')
    need(0 in states and halt not in states, 'Wrong start/halt convention')
    need({z for w, d, z in rows.values()} - states == {halt},
         'Wrong target closure')
    reached, pending = {0}, [0]
    for q in pending:
        for bit in (0, 1):
            z = rows[q, bit][2]
            if z != halt and z not in reached:
                reached.add(z)
                pending.append(z)
    need(reached == states, 'Graph-unreachable working state')
    return states


def dense(rows):
    states = census(rows, 213)
    forward = {q: i for i, q in enumerate(sorted(states))}
    forward[254] = 213
    result = {(forward[q], b): (w, d, forward[z])
              for (q, b), (w, d, z) in rows.items()}
    census(result, 213, 213)
    inverse = {v: k for k, v in forward.items()}
    need({(inverse[q], b): (w, d, inverse[z])
          for (q, b), (w, d, z) in result.items()} == rows,
         'Dense relabeling is not bijective')
    return result, forward


def build(root, output):
    output.mkdir(parents=True, exist_ok=True)
    recipe = json.loads((root / 'machine/table_recipe.json').read_text())
    base = root / 'inputs/u217_reentry.native.tm'
    need(sha(base) == recipe['baseline_sha256'], 'Wrong U217 input')
    need(sha(root / 'machine/sites.json') == recipe['source_sha256'],
         'Wrong source')
    old = parse(base)
    census(old, 217)
    need(recipe['removed_states'] == [500, 501, 502, 503],
         'Wrong state deletion')
    changes = recipe['changed_rows']
    need(len(changes) == 64 and len({tuple(x[:2]) for x in changes}) == 64,
         'Wrong row-patch census')
    native = dict(old)
    for q, b, w, d, z in changes:
        need((q, b) in old and q not in recipe['removed_states'], 'New/deleted row')
        need((w, d, z) != old[q, b], 'Redundant row patch')
        native[q, b] = w, d, z
    native = {k: v for k, v in native.items() if k[0] not in recipe['removed_states']}
    final, mapping = dense(native)
    for filename, table, key in [('u213.native.tm', native, 'native_sha256'),
                                 ('u213.tm', final, 'dense_sha256')]:
        raw = encode(table)
        need(hashlib.sha256(raw).hexdigest() == recipe[key], 'Table hash mismatch')
        need(raw == (root / 'machine' / filename).read_bytes(), 'Frozen table differs')
        (output / filename).write_bytes(raw)
    stated = json.loads((root / 'machine/state_map.json').read_text())
    need({int(k): v for k, v in stated['native_to_dense'].items()} == mapping,
         'Forward map mismatch')
    need({int(k): v for k, v in stated['dense_to_native'].items()} ==
         {v: k for k, v in mapping.items()}, 'Inverse map mismatch')
    need(native[189, 0] == (0, 1, 182), 'Missing guarded-entry repair')
    return {'status': 'EXACT_U213_RECONSTRUCTION_PASS',
            'working_states': 213, 'transition_rows': 426,
            'native_sha256': recipe['native_sha256'],
            'dense_sha256': recipe['dense_sha256'],
            'changed_retained_rows_from_u217': 64,
            'deleted_states_from_u217': recipe['removed_states'],
            'all_working_states_graph_reachable': True,
            'dense_map_bijective': True}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.root, args.output), indent=2))
