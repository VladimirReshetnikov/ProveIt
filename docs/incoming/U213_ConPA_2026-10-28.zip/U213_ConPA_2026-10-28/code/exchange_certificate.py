#!/usr/bin/env python3
"""Construct/check a schematic numerical-calculus equivalence certificate.

Kernel rules: inherited K,S implication schemas; numerical modus ponens;
unrestricted generalization of theorems; rho2 universal distribution.
The certificate is universally instantiated at arbitrary natural selectors.
No decoding, well-formedness, freshness, inequality, or nonzero premise.
This is not a Rocq/Lean/MM0 kernel artifact.
"""
from __future__ import annotations
from functools import cache
from pathlib import Path
import json,hashlib,copy

def I(a,b):return ('I',a,b)
def Q(v,a):return ('Q',v,a)
def R(a,b):return ('R',a,b)
F=('literal',1)
def P(v):return ('parameter',v)
class D:
 def __init__(self):self.nodes=[];self.index={}
 def node(self,rule,formula,*parents,label=None):
  k=(rule,formula,parents,label)
  if k not in self.index:
   deps=frozenset((formula,))if rule=='HYP'else frozenset().union(*(self.nodes[i][4]for i in parents))
   if rule=='GEN':assert not deps
   self.index[k]=len(self.nodes);self.nodes.append((rule,formula,parents,label,deps))
  return self.index[k]
 def f(self,p):return self.nodes[p][1]
 def hyp(self,f):return self.node('HYP',f)
 def K(self,a,b):return self.node('K',I(a,I(b,a)))
 def S(self,a,b,c):return self.node('S',I(I(a,I(b,c)),I(I(a,b),I(a,c))))
 def mp(self,p,q):
  fp,fq=self.f(p),self.f(q);assert fp[0]=='I'and fp[1]==fq
  return self.node('MP',fp[2],p,q)
 def identity(self,a):
  return self.mp(self.mp(self.S(a,I(a,a),a),self.K(a,I(a,a))),self.K(a,a))
 @cache
 def ded(self,h,p):
  rule,f,ps,label,deps=self.nodes[p]
  if h not in deps:return self.mp(self.K(f,h),p)
  if rule=='HYP':assert f==h;return self.identity(h)
  assert rule=='MP'
  fp=self.f(ps[0]);a,b=fp[1:]
  return self.mp(self.mp(self.S(h,a,b),self.ded(h,ps[0])),self.ded(h,ps[1]))
 def exchange(self,a,b,c):
  h=I(a,I(b,c));hh=self.hyp(h);aa=self.hyp(a);bb=self.hyp(b)
  out=self.mp(self.mp(hh,aa),bb)
  return self.ded(h,self.ded(b,self.ded(a,out)))
 def qlift(self,v,p):
  a,b=self.f(p)[1:];g=self.node('GEN',Q(v,I(a,b)),p,label=v)
  k=self.node('QDIST',I(Q(v,I(a,b)),I(Q(v,a),Q(v,b))),label=v)
  return self.mp(k,g)
 def leftlift(self,u,p):
  a,b=self.f(p)[1:];h=I(u,a)
  out=self.mp(p,self.mp(self.hyp(h),self.hyp(u)))
  return self.ded(h,self.ded(u,out))
 def contra(self,p):
  a,b=self.f(p)[1:];h=I(b,F)
  out=self.mp(self.hyp(h),self.mp(p,self.hyp(a)))
  return self.ded(h,self.ded(a,out))
 def bundlelift(self,p):
  # p : Lold -> Lnew.  Negated bundle preserves this orientation.
  return self.contra(self.leftlift(V,self.qlift('a',self.leftlift(U,self.contra(p)))))

a,b,c=map(P,'abc');E=R('c','a');G=Q('a',I(R('a','c'),R('a','b')))
U=Q('c',I(E,a));L=Q('c',I(a,I(G,E)));Lp=Q('c',I(G,I(a,E)))
V=I(R('a','b'),Q('c',R('a','b')))
H=Q('a',I(U,I(L,F)));Hp=Q('a',I(U,I(Lp,F)))
B=I(I(V,H),F);Bp=I(I(V,Hp),F)

def construct():
 d=D();p=d.bundlelift(d.qlift('c',d.exchange(a,G,E)));q=d.bundlelift(d.qlift('c',d.exchange(G,a,E)))
 assert d.f(p)==I(B,Bp)and d.f(q)==I(Bp,B)
 assert not d.nodes[p][4]and not d.nodes[q][4]
 terms=[];ti={};proof=[];pi={}
 def term(f):
  if f in ti:return ti[f]
  if f[0]=='I':r=['I',term(f[1]),term(f[2])]
  elif f[0]=='Q':r=['Q',f[1],term(f[2])]
  else:r=list(f)
  ti[f]=len(terms);terms.append(r);return ti[f]
 def visit(i):
  if i in pi:return pi[i]
  rule,f,ps,label,deps=d.nodes[i];assert not deps
  parents=[visit(j)for j in ps]
  pi[i]=len(proof);proof.append({'rule':rule,'formula':term(f),'parents':parents,'label':label});return pi[i]
 roots=[visit(p),visit(q)]
 return {'description':'All natural a,b,c; retained K,S,rho2,MP,GEN only. No extra assumptions.',
 'terms':terms,'proof':proof,'roots':roots,'expected_terms':[term(I(B,Bp)),term(I(Bp,B))]}

def check(cert):
 """Finite syntactic proof checking; reconstruct formula trees independently."""
 fs=[]
 for row in cert['terms']:
  tag=row[0]
  if tag=='I':
   if not len(row)==3 or not all(type(x)is int and 0<=x<len(fs)for x in row[1:]):raise ValueError('term topology')
   f=('I',fs[row[1]],fs[row[2]])
  elif tag=='Q':
   if len(row)!=3 or row[1]not in('a','b','c')or type(row[2])is not int or not 0<=row[2]<len(fs):raise ValueError('Q term')
   f=('Q',row[1],fs[row[2]])
  elif tag=='R':
   if len(row)!=3 or any(v not in('a','b','c')for v in row[1:]):raise ValueError('R term')
   f=tuple(row)
  elif tag=='parameter':
   if len(row)!=2 or row[1]not in('a','b','c'):raise ValueError('parameter')
   f=tuple(row)
  elif tag=='literal':
   if row!=['literal',1]:raise ValueError('literal')
   f=tuple(row)
  else:raise ValueError('term opcode')
  fs.append(f)
 proved=[]
 for n,line in enumerate(cert['proof']):
  if type(line['formula'])is not int or not 0<=line['formula']<len(fs):raise ValueError('formula pointer')
  f=fs[line['formula']];r=line['rule'];ps=line['parents'];v=line['label']
  if not all(type(j)is int and 0<=j<n for j in ps):raise ValueError('proof topology')
  good=False
  if r=='K'and not ps and v is None:
   good=len(f)==3 and f[0]=='I'and f[2][0]=='I'and f[1]==f[2][2]
  elif r=='S'and not ps and v is None:
   if f[0]=='I'and f[1][0]=='I'and f[1][2][0]=='I':
    aa,bb,cc=f[1][1],f[1][2][1],f[1][2][2]
    good=f==('I',('I',aa,('I',bb,cc)),('I',('I',aa,bb),('I',aa,cc)))
  elif r=='MP'and len(ps)==2 and v is None:
   good=proved[ps[0]]==('I',proved[ps[1]],f)
  elif r=='GEN'and len(ps)==1 and v in('a','b','c'):
   good=f==('Q',v,proved[ps[0]])
  elif r=='QDIST'and not ps and v in('a','b','c'):
   if f[0]=='I'and f[1][0]=='Q'and f[1][2][0]=='I':
    aa,bb=f[1][2][1:];good=f==('I',('Q',v,('I',aa,bb)),('I',('Q',v,aa),('Q',v,bb)))
  if not good:raise ValueError(f'bad line {n}: {r}')
  proved.append(f)
 expected=[I(B,Bp),I(Bp,B)]
 if len(cert['roots'])!=2 or len(cert['expected_terms'])!=2:raise ValueError('root arity')
 for i,j in enumerate(cert['roots']):
  if type(j)is not int or not 0<=j<len(proved)or proved[j]!=expected[i]:raise ValueError('wrong exact endpoint')
  if fs[cert['expected_terms'][i]]!=expected[i]:raise ValueError('wrong advertised endpoint')
 return {'proof_lines':len(proved),'formula_nodes':len(fs),'exact_both_bundle_directions':True,'extra_assumptions':False}

def main():
 here=Path(__file__).resolve().parent;cert=construct();summary=check(cert);controls=[]
 for control in('wrong_target','broken_modus_ponens','wrong_quantifier','bad_K_instance'):
  bad=copy.deepcopy(cert)
  if control=='wrong_target':bad['roots'][0]=bad['roots'][1]
  elif control=='broken_modus_ponens':
   row=next(x for x in bad['proof']if x['rule']=='MP');row['parents']=list(reversed(row['parents']))
  elif control=='wrong_quantifier':
   row=next(x for x in bad['proof']if x['rule']=='GEN');row['label']='b'if row['label']!='b'else'c'
  else:
   row=next(x for x in bad['proof']if x['rule']=='K');row['formula']=0
  try:check(bad)
  except(ValueError,IndexError,TypeError):controls.append(control)
  else:raise AssertionError('negative control accepted')
 raw=(json.dumps(cert,separators=(',',':'))+'\n').encode();path=here/'exchange_proof.json';path.write_bytes(raw)
 summary.update(status='SCHEMATIC_NUMERICAL_EXCHANGE_PASS',negative_controls_rejected=controls,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),rules=['K','S','MP','GEN','rho2'],scope='Schematic proof under inherited uniform numerical logical rules; not newly kernel checked.')
 (here/'exchange_receipt.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
