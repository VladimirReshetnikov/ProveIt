#!/usr/bin/env python3
"""Generate the paper's exact table and metrics only after a full runtime pass."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from reproduce import runtime_audit
from build_machine import parse, census


def main():
    _, metrics = runtime_audit(ROOT / 'machine/u213.native.tm', ROOT / 'machine/sites.json',
                               ROOT / 'evidence/runtime')
    table = parse(ROOT / 'machine/u213.tm')
    census(table, 213, 213)
    rows = [r'\begin{center}\small',
            r'\setlength{\tabcolsep}{7pt}',
            r'\begin{longtable}{rll@{\qquad}rll@{\qquad}rll}',
            r'\toprule',
            r'State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
            r'\midrule\endfirsthead',
            r'\toprule',
            r'State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
            r'\midrule\endhead', r'\bottomrule\endfoot']
    for i in range(71):
        cells = []
        for q in (i, i + 71, i + 142):
            cells.append(str(q))
            for bit in (0, 1):
                w, d, z = table[q, bit]
                target = 'H' if z == 213 else str(z)
                cells.append(r'\texttt{' + f'{w}{"R" if d == 1 else "L"}{target}' + '}')
        rows.append(' & '.join(cells) + r'\\')
    rows.extend([r'\end{longtable}', r'\end{center}', ''])
    (ROOT / 'paper/transition_table.tex').write_text('\n'.join(rows))
    values = [('RuntimeRules', metrics['symbolic_rule_applications']),
              ('RuntimeMinClock', metrics['minimum_affine_duration_constant']),
              ('RuntimeCoverage', metrics['primitive_transition_rows_covered'])]
    (ROOT / 'paper/results.tex').write_text(''.join(
        '\\newcommand{\\' + name + '}{' + format(value, ',').replace(',', '{,}') + '}\n'
        for name, value in values))
    (ROOT / 'evidence/runtime_metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
    print(json.dumps(metrics, indent=2))


if __name__ == '__main__':
    main()
