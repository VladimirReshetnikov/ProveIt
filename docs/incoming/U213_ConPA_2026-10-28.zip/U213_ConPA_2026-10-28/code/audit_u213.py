#!/usr/bin/env python3
"""Independent finite audit of the frozen U213 source/table/startup pair.

Standard library only.  No imports from the builder, allocator, source-language
utilities, symbolic engine, or local proof checker.  The independently replayed
checks below do not replace the separate all-natural-register runtime proof or
the inherited numerical-calculus calibration.  The two-cell delivery lemma is
a proof with opaque exterior, not a comparison with the rejected allocation.
"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json


NATIVE_SHA256 = '38767d552131fb78e047225856c6759a9d45903c7c820bd0f06e071af07053b4'
DENSE_SHA256 = '0947330921e9ad0c26b2379aeb8a821108a1d42dab7c0eaa980fdcb29e5715c5'
SOURCE_SHA256 = '2138b34bea88ab0fd469155229e6cb34ee185d45047d1b9994f4933be4d88896'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def compact(value):
    return (json.dumps(value, separators=(',', ':')) + '\n').encode('ascii')


def parse_table(raw):
    rows = {}
    starts = []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(line)
        if not line or line.startswith('#'):
            continue
        words = line.split()
        require(len(words) == 5, 'Transition must have five fields')
        q, bit, write, direction, target = words
        q, bit, write, target = map(int, (q, bit, write, target))
        require(q >= 0 and target >= 0, 'Negative state label')
        require(bit in (0, 1) and write in (0, 1), 'Nonbinary symbol')
        require(direction in ('L', 'R'), 'Invalid movement')
        require((q, bit) not in rows, 'Duplicate transition')
        rows[q, bit] = (write, -1 if direction == 'L' else 1, target)
    require(starts == ['#! start 0'], 'Wrong start declaration')
    return rows


def encode_table(rows):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(rows.items()))).encode('ascii')


def census(rows, halt=254):
    states = {q for q, _ in rows}
    require(len(states) == 213, 'Wrong working-state count')
    require(set(rows) == {(q, b) for q in states for b in (0, 1)},
            'Transition table is partial')
    require(0 in states and halt not in states, 'Wrong start/halt convention')
    require({z for _, _, z in rows.values()} - states == {halt},
            'Wrong external target set')
    reached = {0}
    pending = [0]
    while pending:
        q = pending.pop()
        if q == halt:
            continue
        for bit in (0, 1):
            z = rows[q, bit][2]
            if z not in reached:
                reached.add(z)
                pending.append(z)
    require(reached == states | {halt}, 'Graph-unreachable state')
    return sorted(states)


def relabel(rows, dense_path=None, map_path=None):
    native_states = census(rows)
    forward = {q: i for i, q in enumerate(native_states)}
    forward[254] = 213
    inverse = {d: n for n, d in forward.items()}
    require(len(inverse) == len(forward) == 214, 'Nonbijective relabeling')
    dense = {(forward[q], b): (w, move, forward[z])
             for (q, b), (w, move, z) in rows.items()}
    require(census(dense, halt=213) == list(range(213)), 'Dense labels')
    require({(inverse[q], b): (w, move, inverse[z])
             for (q, b), (w, move, z) in dense.items()} == rows,
            'Relabeling round trip failed')
    dense_raw = encode_table(dense)
    require(digest(dense_raw) == DENSE_SHA256, 'Dense table hash')
    if dense_path is not None:
        require(dense_path.read_bytes() == dense_raw, 'Supplied dense table differs')
    if map_path is not None:
        mapping = json.loads(map_path.read_text())
        require({int(q): v for q, v in mapping['native_to_dense'].items()} == forward,
                'Supplied forward map differs')
        require({int(q): v for q, v in mapping['dense_to_native'].items()} == inverse,
                'Supplied inverse map differs')
        require(mapping['native_halt'] == 254 and mapping['dense_halt'] == 213
                and mapping['native_dispatcher'] == 84, 'Map metadata differs')
    # Optional file comparisons do not change the deterministic receipt.
    return {'working_states': 213, 'transition_rows': 426, 'native_start': 0,
            'native_halt': 254, 'dense_start': 0, 'dense_halt': 213,
            'dense_dispatcher': forward[84], 'native_states': native_states,
            'all_working_states_graph_reachable': True,
            'canonical_dense_sha256': digest(dense_raw),
            'dense_relabeling_bijective': True}


def source_structure(rows):
    require(isinstance(rows, list), 'Source must be a list')
    primitives = {}
    for entry in rows:
        require(isinstance(entry, list) and len(entry) == 3, 'Malformed source row')
        path, op, arg = entry
        require(isinstance(path, str) and path and set(path) <= {'0', '1'},
                'Malformed source address')
        require(path not in primitives, 'Duplicate source address')
        require(op in ('CI', 'CD', 'CB', 'CC', 'CH'), 'Unknown source opcode')
        require((op == 'CH' and arg is None) or
                (op in ('CI', 'CD') and type(arg) is int and 0 <= arg < 9) or
                (op in ('CB', 'CC') and type(arg) is int and arg >= 1),
                'Invalid source argument')
        primitives[path] = (op, arg)
    require([p for p, _, _ in rows] == sorted(primitives), 'Noncanonical source order')
    prefixes = {p[:n] for p in primitives for n in range(len(p))}
    require(not prefixes.intersection(primitives), 'Source leaf/prefix collision')
    require(all(p + b in prefixes or p + b in primitives
                for p in prefixes for b in '01'), 'Source tree is not full')
    subtrees = {}
    intervals = {}
    ordinal = {p: i for i, (p, _, _) in enumerate(rows)}

    def build(p):
        if p in primitives:
            result = primitives[p]
            intervals[p] = (ordinal[p], ordinal[p] + 1)
        else:
            left, right = build(p + '0'), build(p + '1')
            require(intervals[p + '0'][1] == intervals[p + '1'][0],
                    'Subtree interval discontinuity')
            intervals[p] = (intervals[p + '0'][0], intervals[p + '1'][1])
            result = (left, right)
        subtrees[p] = result
        return result

    build('')
    require(intervals[''] == (0, len(rows)), 'Root interval mismatch')
    counts = dict(sorted(Counter(op for _, op, _ in rows).items()))
    metrics = {'dag_nodes': len(set(subtrees.values())),
               'leaf_occurrences': len(rows), 'proper_prefixes': len(prefixes),
               'maximum_depth': max(map(len, primitives)),
               'maximum_zero_run': max(len(x) for p in primitives for x in p.split('1')),
               'decrement_occurrences': counts.get('CD', 0)}
    require(metrics == {'dag_nodes': 198, 'leaf_occurrences': 3928,
                        'proper_prefixes': 3927, 'maximum_depth': 45,
                        'maximum_zero_run': 6, 'decrement_occurrences': 1181},
            'Wrong source metrics')

    # Resolve every successor twice, using interval ascent and bit arithmetic.
    width = metrics['maximum_depth']

    def interval_jump(p, edge, level):
        while p:
            last, p = p[-1], p[:-1]
            if last == edge:
                level -= 1
                if level == 0:
                    return intervals[p][1 if edge == '0' else 0] % len(rows)
        return 0

    def cut(p, edge, level):
        positions = [i for i, bit in enumerate(p) if bit == edge]
        return p[:positions[-level]] if len(positions) >= level else ''

    def increment(p):
        return '' if not p else format((int(p, 2) + 1) % 2 ** len(p), f'0{len(p)}b')

    def locate(p):
        extended = p + '0' * width
        for n in range(1, width + 1):
            if extended[:n] in ordinal:
                require('1' not in p[n:], 'Stray one beyond successor leaf')
                return ordinal[extended[:n]]
        raise ValueError('Cannot resolve source successor')

    graph = []
    for i, (p, op, arg) in enumerate(rows):
        after = (i + 1) % len(rows)
        if op == 'CI':
            a, b = [after], [locate(increment(p))]
        elif op == 'CD':
            a = [interval_jump(p, '0', 1), after]
            b = [locate(increment(cut(p, '0', 1))), locate(increment(p))]
        elif op == 'CB':
            a, b = [interval_jump(p, '0', arg)], [locate(increment(cut(p, '0', arg)))]
        elif op == 'CC':
            a, b = [interval_jump(p, '1', arg)], [locate(cut(p, '1', arg))]
        else:
            a, b = [], []
        require(a == b, 'Independent source graph resolvers disagree')
        graph.append([op, arg, a])
    require(locate('') == 0, 'Root successor is not first source leaf')
    return {'metrics': metrics, 'opcode_counts': counts,
            'quantified_primitive_case_count': len(rows) + counts['CD'],
            'independent_cfg_resolvers_agree': True,
            'cfg_sha256': digest(compact(graph))}, sorted(prefixes)


def prefix_bindings(table, prefixes):
    bindings = []
    maximum_steps = 0
    total_steps = 0
    rows_used = set()
    for prefix in prefixes:
        known = {-1: 1}
        known.update({i: int(bit) for i, bit in enumerate(prefix)})
        before = dict(known)
        q, head = 84, 0
        ticks = 0
        while head != len(prefix):
            require(ticks < 10000, 'Prefix did not finish')
            require(head in known, 'Prefix decoder reads opaque exterior')
            bit = known[head]
            require((q, bit) in table, 'Prefix enters halt/undefined row')
            write, move, target = table[q, bit]
            rows_used.add((q, bit))
            known[head] = write
            head += move
            q = target
            ticks += 1
        require(known == before, 'Prefix decoder changes input tape')
        require(q != 254, 'Prefix decoder halts')
        bindings.append([prefix, q])
        maximum_steps = max(maximum_steps, ticks)
        total_steps += ticks
    return {'prefix_count': len(bindings), 'binding_sha256': digest(compact(bindings)),
            'all_prefix_tapes_unchanged': True, 'opaque_exterior_never_read': True,
            'maximum_literal_steps': maximum_steps, 'total_literal_steps': total_steps,
            'transition_rows_used': [list(x) for x in sorted(rows_used)],
            'scope': 'Literal source-address decoding only; opcode effects are covered '
                     'by the separate quantified runtime certificate.'}


def delivery(table):
    require(table[189, 0] == (0, 1, 182), 'Changed edge does not establish the guard')
    cases = []
    for bit in (0, 1):
        known = {-1: 0, 0: bit}
        original = dict(known)
        q, head = 182, 0
        intended = 90 if bit == 0 else 61
        trace = []
        while (q, head) != (intended, 1):
            require(len(trace) < 10, 'Local delivery did not rendezvous')
            require(head in known, 'Local delivery reads opaque exterior')
            scanned = known[head]
            require((q, scanned) in table, 'Local delivery halts')
            write, move, target = table[q, scanned]
            trace.append([q, head, scanned, write, move, target])
            known[head] = write
            q, head = target, head + move
        require(known == original, 'Local delivery changes tape')
        require(len(trace) == (5 if bit == 0 else 1), 'Local delivery length changed')
        cases.append({'current_bit': bit, 'trace': trace, 'steps': len(trace),
                      'endpoint_state': q, 'endpoint_head': head,
                      'known_tape': [[-1, 0], [0, bit]]})
    return {'incoming_guard_row': [189, 0, 0, 1, 182],
            'entry_invariant': 'The preceding cell is zero after native189/0.',
            'intended_actions': [[0, 0, 1, 90], [1, 1, 1, 61]], 'cases': cases,
            'whole_tape_unchanged': True, 'opaque_exterior_never_read': True,
            'scope': 'Correct implementation at this guarded entry, not equivalence '
                     'to the rejected table that used target150.'}


def expected_startup():
    head = -8
    marker = head - 1
    header = head + 65
    expected = {marker, header}
    physical = [0] * 9
    physical[6] = 4
    position = header + 1
    for value in physical + [1] * 40:
        expected.update(range(position + 1, position + value + 2))
        position += value + 2
    return expected


def bootstrap(table, supplied=None):
    q, head = 0, 0
    ones = set()
    trace_hash = hashlib.sha256()
    visited = set()
    if supplied is not None:
        require(isinstance(supplied.get('trace'), list)
                and len(supplied['trace']) == 95726, 'Saved startup trace length')
    for tick in range(95726):
        bit = int(head in ones)
        require((q, bit) in table, 'Startup enters halt/undefined row')
        write, move, target = table[q, bit]
        event = [q, head, bit, write, move, target]
        if supplied is not None:
            require(supplied['trace'][tick] == event,
                    f'Saved startup transition differs at step{tick}')
        trace_hash.update((','.join(map(str, event)) + '\n').encode('ascii'))
        visited.add((q, bit))
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        q, head = target, head + move
    require((q, head) == (84, -8), 'Startup state/head mismatch')
    require(ones == expected_startup(), 'Entire sparse startup tape differs')
    descriptor = {'status': 'CALIBRATED_DIRTY_ROOT_SEED', 'steps': 95726,
                  'state': 84, 'head': -8, 'gap': 1,
                  'registers': [4, 0, 0, 0, 0, 0, 0, 0, 0],
                  'spares': [1] * 40, 'one_cells': sorted(ones)}
    if supplied is not None:
        require(all(supplied.get(k) == value for k, value in descriptor.items()),
                'Saved startup descriptor differs')
    descriptor.update(whole_tape_verified=True, trace_sha256=trace_hash.hexdigest(),
                      visited_rows=len(visited))
    return descriptor


def negative_controls(table, source, saved):
    rejected = []

    def reject(name, action):
        try:
            action()
        except (ValueError, KeyError, TypeError):
            rejected.append(name)
        else:
            raise ValueError('Negative control was accepted: ' + name)

    def mutation(key, value):
        result = dict(table)
        result[key] = value
        return result

    raw = encode_table(table)
    reject('duplicate_transition', lambda: parse_table(raw + b'0 0 1 R 94\n'))
    partial = dict(table)
    partial.pop((0, 1))
    reject('missing_transition', lambda: census(partial))
    reject('guard_writes_one', lambda: delivery(mutation((189, 0), (1, 1, 182))))
    reject('rejected_target150', lambda: delivery(mutation((189, 0), (0, 1, 150))))
    reject('unsafe_helper209_to17', lambda: delivery(mutation((209, 0), (0, 1, 17))))
    reject('helper_changes_tape', lambda: delivery(mutation((157, 0), (1, -1, 67))))
    reject('wrong_one_branch', lambda: delivery(mutation((182, 1), (1, 1, 90))))
    reject('duplicate_source_leaf', lambda: source_structure(source + [source[0]]))
    if saved is not None:
        wrong_trace = dict(saved)
        wrong_trace['trace'] = list(saved['trace'])
        wrong_trace['trace'][0] = list(saved['trace'][0])
        wrong_trace['trace'][0][3] ^= 1
        reject('altered_saved_startup_step', lambda: bootstrap(table, wrong_trace))
        wrong_tape = dict(saved)
        wrong_tape['one_cells'] = list(saved['one_cells']) + [1000000]
        reject('extra_saved_startup_one', lambda: bootstrap(table, wrong_tape))
    return rejected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--table', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--startup', type=Path,
                        help='Optional saved literal trace to compare step by step')
    parser.add_argument('--dense-table', type=Path)
    parser.add_argument('--state-map', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    table_raw, source_raw = args.table.read_bytes(), args.source.read_bytes()
    require(digest(table_raw) == NATIVE_SHA256, 'Not the frozen U213 native table')
    require(digest(source_raw) == SOURCE_SHA256, 'Not the frozen U213 source')
    table = parse_table(table_raw)
    require(encode_table(table) == table_raw, 'Noncanonical native table bytes')
    source = json.loads(source_raw)
    saved = json.loads(args.startup.read_text()) if args.startup is not None else None
    source_report, prefixes = source_structure(source)
    report = {'status': 'INDEPENDENT_FINITE_U213_AUDIT_PASS',
              'native_sha256': digest(table_raw), 'source_sha256': digest(source_raw),
              'machine': relabel(table, args.dense_table, args.state_map),
              'source': source_report,
              'decoder_prefixes': prefix_bindings(table, prefixes),
              'guarded_delivery': delivery(table), 'startup': bootstrap(table, saved),
              'saved_startup_trace_checked': saved is not None,
              'negative_controls_rejected': negative_controls(table, source, saved),
              'scope': 'Independent finite table/source structure, dense relabeling, '
                       'literal prefix contracts, arbitrary-exterior guarded delivery, '
                       'and complete literal blank startup. All-natural primitive '
                       'simulation and inherited Con(PA) calibration are separate obligations.'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'native_sha256',
                                           'source_sha256', 'negative_controls_rejected')}, indent=2))


if __name__ == '__main__':
    main()
