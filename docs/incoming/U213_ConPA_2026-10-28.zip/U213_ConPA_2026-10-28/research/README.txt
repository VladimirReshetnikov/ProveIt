Discovery record and rejected candidates
========================================

The delivered machine is ../machine/u213.tm, native SHA-256
38767d552131fb78e047225856c6759a9d45903c7c820bd0f06e071af07053b4.
Research candidates and prefix passes are not additional accepted machines.

The accepted source was found by searching exact closed parenthesizations
of a 28-macro emitter and logically equivalent covering shells. It exchanges
the two antecedents in the lower clause of U214, keeping its matrix/output
role a, source role b, gate and exterior program. Source metrics remain
198 distinct subtrees, 3928 primitive occurrences, depth 45 and zero run 6.
The frozen source_recipe.json provides deterministic reconstruction.

allocate_from215.py and its companion utilities are retained as discovery
code adapted from the pinned ProveIt K215 role-pool. They require NumPy and
SciPy, which are NOT dependencies of the final offline reproduction. This
allocator is a bounded search tool. Its protected-row filter and source-prefix
checks do not certify arbitrary-register runtime. In particular, its initial
leaf compatibility logic did not distinguish the preceding-bit condition of
native 150's relation-macro role. Do not treat a new allocator result as
accepted merely because its source-prefix check passes.

The accepted search family allocated the source on the U217 reentry table,
protecting rows 134/0, 134/1, 158/0, 218/0, 218/1. The first 213 result required a
single target correction: 189/0 from 150 to 182. The final proof checks 182's
known-left-zero delivery on the retained helper rows and then validates every
primitive on the exact corrected table. Numerical solver choices and output
allocations can vary; the final machine is reproduced from its frozen row
recipe rather than by rerunning this optimization.

targeted_repair.json records the 36 guarded cases inside the affected 28-leaf
macro. concrete_repair.json records a valid all-zero-register frame where the
rejected allocation gives the wrong result after 536 steps and the corrected
one gives the specified result after 576 steps. These are local controls, not
the global acceptance test. local_delivery.json proves the guarded delivery.

rejected_attempts.json records the failed scan 50 shortening and the failed
source-preserving allocations, with exact hashes and failure locations. The
112-to7 local fold remains a valid theorem relative to its intermediate
table; the intermediate does not implement the source correctly. Its local
certificate therefore does not establish a consistency machine.

The authoritative global runtime evidence is ../evidence/runtime/. Its
summary must say UNIVERSAL_MATHEMATICAL_PASS, with 5,109/5,109 cases and the
delivered table/source hashes. The --full reproduction option rederives it.

The finite searches provide no lower bound and no proof of optimality among
arbitrary binary Turing machines. No accepted 212-state machine was obtained.
