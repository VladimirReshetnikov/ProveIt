#!/usr/bin/env python3
"""Offline U213 reconstruction and mathematical evidence audit.

Python 3.10+, standard library only. --full rederives all symbolic cases.
No newly compiled proof-assistant endpoint is claimed.
"""
from pathlib import Path, PurePosixPath
import argparse
import copy
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'code'))
from build_machine import build, sha, need, parse
from audit_source import audit as source_audit
import exchange_certificate as exchange


def load(path):
    return json.loads(path.read_text())


def command(script, args, work, label):
    print(label + ' ...', flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONOPTIMIZE', None)
    result = subprocess.run([sys.executable, '-B', str(script), *map(str, args)],
                            cwd=work, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    if result.returncode:
        print(result.stdout, end='')
        raise RuntimeError(label + ' failed')
    print(label + ': PASS', flush=True)


def manifest():
    seen = set()
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        p = PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts and '\\' not in name,
             'Unsafe manifest path')
        need(name not in seen, 'Duplicate manifest member')
        seen.add(name)
        need(sha(ROOT / name) == digest, 'Digest mismatch: ' + name)
    required = {'paper/report.tex', 'paper/report.pdf', 'machine/u213.tm',
                'machine/u213.native.tm', 'machine/sites.json', 'reproduce.py',
                'inputs/U214_ConPA_Reduction_2026-10-28.zip',
                'evidence/runtime/runtime.json', 'evidence/runtime/runtime_cases.json',
                'evidence/runtime/startup.json', 'evidence/exchange_proof.json'}
    need(required <= seen, 'Principal files omitted from manifest')
    return len(seen)


def safe_extract(archive, dest):
    with zipfile.ZipFile(archive) as z:
        seen = set()
        for info in z.infolist():
            p = PurePosixPath(info.filename)
            need(not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename,
                 'Unsafe archive path')
            need(info.filename not in seen and
                 not stat.S_ISLNK((info.external_attr >> 16) & 0xffff),
                 'Duplicate archive member or symbolic link')
            seen.add(info.filename)
            target = dest.joinpath(*p.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, target.open('wb') as dst:
                    while True:
                        data = src.read(1048576)
                        if not data:
                            break
                        dst.write(data)


def logical_audit():
    cert = load(ROOT / 'evidence/exchange_proof.json')
    need(cert == exchange.construct(), 'Schematic derivation reconstruction differs')
    result = exchange.check(cert)
    rejected = []
    for name in ('wrong_target', 'broken_modus_ponens', 'wrong_quantifier', 'bad_K_instance'):
        bad = copy.deepcopy(cert)
        if name == 'wrong_target':
            bad['roots'][0] = bad['roots'][1]
        elif name == 'broken_modus_ponens':
            row = next(x for x in bad['proof'] if x['rule'] == 'MP')
            row['parents'] = list(reversed(row['parents']))
        elif name == 'wrong_quantifier':
            row = next(x for x in bad['proof'] if x['rule'] == 'GEN')
            row['label'] = 'b' if row['label'] != 'b' else 'c'
        else:
            row = next(x for x in bad['proof'] if x['rule'] == 'K')
            row['formula'] = 0
        try:
            exchange.check(bad)
        except (ValueError, IndexError, TypeError):
            rejected.append(name)
        else:
            raise ValueError('Logical negative control accepted: ' + name)
    need(result['proof_lines'] == 372, 'Unexpected logical derivation size')
    return {**result, 'status': 'SCHEMATIC_NUMERICAL_EXCHANGE_PASS',
            'negative_controls_rejected': rejected}


def runtime_audit(table, source, folder):
    summary = load(folder / 'runtime.json')
    cases = load(folder / 'runtime_cases.json')
    sites = load(source)
    need(summary['status'] == 'UNIVERSAL_MATHEMATICAL_PASS' and not summary['failures'],
         'Runtime was not proved')
    need(summary['working_states'] == 213 and summary['table_sha256'] == sha(table)
         and summary['sites_sha256'] == sha(source), 'Runtime binding differs')
    need(summary['checker_sha256'] == sha(ROOT / 'code/runtime/symbolic_runtime.py')
         and summary['helper_sha256'] == sha(ROOT / 'code/runtime/independent_runtime.py'),
         'Runtime checker bytes differ')
    need(summary['proved_cases'] == summary['expected_cases'] == len(cases) == 5109,
         'Incomplete runtime census')
    expected = [(i, b) for i, x in enumerate(sites)
                for b in ((False, True) if x[1] == 'CD' else (False,))]
    need([(x['site_index'], x['positive']) for x in cases] == expected,
         'Missing, repeated, or reordered symbolic cases')
    mapping = {int(k): int(v) for k, v in
               load(ROOT / 'code/inputs/legacy_mapping.json').items()}
    native = parse(table)
    for q in {q for q, bit in native} | {254}:
        if q not in mapping:
            mapping[q] = q + 1000
    legacy_rows = {(mapping[q], b) for q, b in native}
    used = set()
    for case in cases:
        need(len(case['duration']) == 13 and case['duration'][0] > 0
             and all(type(v) is int and v >= 0 for v in case['duration']),
             'No positive affine progress')
        need(case['symbolic_steps'] == sum(case['kinds'].values()),
             'Symbolic step census differs')
        rows = {tuple(r) for r in case['rows']}
        need(rows <= legacy_rows, 'Runtime cites a missing transition row')
        used.update(rows)
    need(summary['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED',
         'Uncalibrated startup')
    metrics = {'proved_cases': len(cases),
               'symbolic_rule_applications': sum(x['symbolic_steps'] for x in cases),
               'minimum_affine_duration_constant': min(x['duration'][0] for x in cases),
               'primitive_transition_rows_covered': len(used)}
    return summary, metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    need(__debug__ and not sys.flags.optimize, 'Run Python with assertions enabled')
    begun = time.monotonic()
    files = manifest()
    with tempfile.TemporaryDirectory(prefix='u213-replay-') as name:
        temp = Path(name)
        out = temp / 'build'
        out.mkdir()
        command(ROOT / 'code/build_source.py',
                ['--baseline', ROOT / 'inputs/k215_sites.json',
                 '--recipe', ROOT / 'machine/source_recipe.json',
                 '--output', out / 'sites.json'], temp, 'Reconstruct exact source')
        need((out / 'sites.json').read_bytes() == (ROOT / 'machine/sites.json').read_bytes(),
             'Source reconstruction differs')
        construction = build(ROOT, out)
        source = source_audit(out / 'sites.json', ROOT / 'inputs/u214_sites.json',
                             ROOT / 'inputs/k215_sites.json')
        need(json.loads(json.dumps(source)) == load(ROOT / 'evidence/source_audit.json'),
             'Source audit differs')
        logical = logical_audit()
        print('Exact source and full-bundle logical exchange: PASS', flush=True)
        saved, metrics = runtime_audit(out / 'u213.native.tm', out / 'sites.json',
                                       ROOT / 'evidence/runtime')
        command(ROOT / 'code/audit_u213.py',
                ['--table', out / 'u213.native.tm', '--source', out / 'sites.json',
                 '--startup', ROOT / 'evidence/runtime/startup.json',
                 '--output', temp / 'independent_machine.json'],
                temp, 'Independent table, local entry, and complete blank trace')
        independent = load(temp / 'independent_machine.json')
        need(independent == load(ROOT / 'evidence/independent_machine.json'),
             'Independent machine audit differs')
        if args.full:
            fresh = temp / 'fresh_runtime'
            command(ROOT / 'code/validate_native.py',
                    [out / 'u213.native.tm', out / 'sites.json', fresh], temp,
                    'Rederive all 5109 arbitrary-register cases')
            actual, fresh_metrics = runtime_audit(out / 'u213.native.tm', out / 'sites.json', fresh)
            need(actual['blocks'] == saved['blocks'], 'Block induction derivations differ')
            need(fresh_metrics == metrics, 'Runtime metrics differ')
            for file in ('runtime_cases.json', 'startup.json'):
                need(load(fresh / file) == load(ROOT / 'evidence/runtime' / file),
                     'Fresh runtime record differs: ' + file)
        archive = ROOT / 'inputs/U214_ConPA_Reduction_2026-10-28.zip'
        need(sha(archive) == 'b3a520e2181b739fec7257a7935b979acb00400f8d8147b5a2c212fd53a38d2c',
             'Wrong inherited archive')
        safe_extract(archive, temp / 'parent')
        parent = temp / 'parent/U214_ConPA_Reduction_2026-10-28'
        for here, there in [('u214.native.tm', 'machine/u214.native.tm'),
                            ('u217_reentry.native.tm', 'machine/u217_reentry.native.tm'),
                            ('u214_sites.json', 'machine/sites.json'),
                            ('k215_sites.json', 'inputs/k215_sites.json')]:
            need((ROOT / 'inputs' / here).read_bytes() == (parent / there).read_bytes(),
                 'Inherited input differs: ' + here)
        command(parent / 'reproduce.py', ['--report', temp / 'parent_replay.json'], parent,
                'Inherited U214 reconstruction and mathematical audit')
        need(load(temp / 'parent_replay.json')['status'] ==
             'U214_RECONSTRUCTION_AND_PROOF_AUDIT_PASS', 'Inherited audit failed')
        report = {
            'status': 'U213_FULL_REPRODUCTION_PASS' if args.full else
                      'U213_RECONSTRUCTION_AND_EVIDENCE_AUDIT_PASS',
            'manifest_files': files, 'construction': construction,
            'source_metrics': source['source_metrics'],
            'exterior_instructions_unchanged': 3154,
            'logical_exchange': logical, 'runtime_metrics': metrics,
            'symbolic_cases_rederived_in_this_run': 5109 if args.full else 0,
            'independent_machine_audit': True, 'blank_start_steps': 95726,
            'inherited_u214_audit': True,
            'seconds': round(time.monotonic() - begun, 3),
            'scope': 'Exact reconstruction and executable mathematical checks. '
                     'Full mode freshly rederives quantified symbolic runtime. '
                     'Inherited ordinary U/PA calibration is retained. '
                     'No newly compiled proof-assistant endpoint is claimed.'}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
