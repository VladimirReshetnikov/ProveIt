# Revision with sharp leading rank constant

The decision result remains coNP-completeness for complete binary DFA finite stabilization, under either clock.

This edition adds a full proof that every finite-rank complete s-state DFA satisfies R(L) <= s^2 + 3. Combined with the existing deterministic lower family, the bounds are now

    (s - 7)^2 + 2 <= F_DFA(s) <= s^2 + 3, for s >= 8.

Hence F_DFA(s)/s^2 tends to 1. The earlier edition only established the leading-constant interval [1, 2].

The proof uses actual-to-stable alphabet inclusions after s positions, an entire safe SCC stripe, and the disjoint state budgets of entry and exit paths shortened modulo the SCC period. It applies to complete DFAs over any finite alphabet. It does not extend this leading-one bound to general NFAs.

Section 7 is new. The abstract, main theorem, consequences, and remaining questions have been updated. The four finite checkers and their results are unchanged; the new universal upper bound is proved analytically.

1 October 2026
