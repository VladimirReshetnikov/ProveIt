# State-reduction research below K215

**Target status: not met. No machine with at most 214 working states is established by this packet.**

This contribution contains a new equiconsistent inequality presentation, explicit alternative-code transfer arguments, checked source invariants, a new exact **215-state** parameter variant, and reproducible bounded searches. A source DAG count is not a physical Turing-machine state count. Experimental or rejected tables must not be promoted to accepted candidates.

## Read first

- `report.pdf` is the complete research report; `report.tex`, `final_search_results.tex`, and `theory/` are its editable sources.
- `STATUS.json` states the exact acceptance boundary.
- `machine215/` and `evidence/fresh-variant/` identify the only new table for which this packet supplies both a calibrated source argument and the full fresh symbolic runtime replay.
- `research/README.md` indexes the explorations and explains their reproduction limits.
- `rejected/README.md` explains why the tempting 214-state scanner is not accepted.

The baseline is ProveIt commit `2762b8a183830b1f5a30cf059ffb4d92e77cddde`, under `Computability/BusyBeaver/Research/ZFC/candidate-k215`. The parent's code, theory calibration and verification architecture remain inherited work; this packet does not replace their attribution or claim a new proof-assistant formalization.

## Main mathematical result

Retag primitive equality as inequality `N(a,b)` and define equality as `N(a,b) -> F`, where `F=1`. Replace the fused equality row by

    N(a,b) -> Q_kappa(a,b) ((N(c,a) -> F) -> N(c,b)).

The binder `kappa(a,b)` may be asymmetric, provided it is different from both endpoint labels when the labels differ. With the retained rows, the report derives relative explosion, equality reflexivity and symmetry, and the required fresh equality helper. The inherited membership-defined-equality comparison then calibrates the new calculus to ZFC. In this calculus any odd theorem code yields a refutation. The best source found still has 209 DAG nodes and no smaller physical table was allocated.

Two other complete mathematical discussions treat a two-outer-tag encoding and exponential pairing `(2b+1)*2**a - 1`. The report explains the special code-zero alias and the actual-matrix-code/private-variable coupling. It explicitly separates coding transfer from verification of an exact compiler or binary table.

## Reproduce the accepted 215-state variant

Python 3.10 or later; standard library only; assertions must be enabled:

```sh
python3 -B code/verify_variant.py --output replay-output
```

This reconstructs the source and literal table, checks two source CFG resolvers and decoder prefixes, independently reconstructs the complete blank startup, and replays all 6,176 guarded symbolic cases. The run used for the packet took about 134 seconds; timing is not a proof premise.

A shorter check that intentionally omits the quantified runtime replay is:

```sh
python3 -B code/verify_variant.py --structural-only --output structural-output
```

Do not use `python -O` or `PYTHONOPTIMIZE`. A structural-only receipt is not a full acceptance receipt.

The checked table has 215 working states, 430 transition rows, native start state 0, dispatcher 84 and halt label 254. The separate halt state is not counted. A dense table with working states 0 through 214 and halt 215 is in `evidence/fresh-variant/variant215.tm`.

Native-table SHA-256:

    5ae9559203b0eb54e2d417e6d58793a2a696d023d40e7969d7192771005db28e

Source SHA-256:

    19da13e482ea0f3d57432aad852bdf2448093e58a6e3b3873ac744eae7440693

The full replay proves all 6,176 cases using 1,699,838 symbolic rules, with positive duration and all 430 rows accounted for. The separately checked blank prefix lasts 95,726 steps. These are executable mathematical induction checks and an ordinary calibration proof, not a new Lean or Rocq kernel endpoint.

## Build and inspect the report

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The supplied PDF was compiled and visually reviewed. Standard TeX Live packages are used; no shell escape is needed.

## Integrity and provenance

`SHA256SUMS` covers every delivered file other than itself. `research/selection_manifest.json` records the selected research snapshots. Large repetitive negative-search witness streams are omitted; their aggregate receipts, hashes and generators remain. No omitted stream is represented as delivered evidence.

Upstream source pins, notices and licenses are retained under `upstream/`. The main verifier is self-contained. Some exploratory scripts require a checkout of the pinned repository and NumPy/SciPy; use the research guide for their original workspace layout. Solver infeasibility and bounded folding failures are not general lower bounds.
