import sys,runpy,json,gzip,heapq,random,time
from pathlib import Path
sys.path.insert(0,'encoding_work');import permute_allocate as a
from swap_q_e import make
sys.argv=[sys.argv[0],'--steps','0'];g=runpy.run_path('root_work/search_rotations.py')
pack,collect,options,replace,thaw=[g[x]for x in('pack','collect','options','replace','thaw')];ns,zeros,crit,depths=[g[x]for x in('ns','zeros','crit','depths')]
tr=make((1,)*6,1);start=pack(tr);basegraph=a.s.graph_intervals(a.s.sites(tr));best=203;expanded=0;t0=time.monotonic();rng=random.Random(215)
seenroots={start};pending=[(0,0,start)];saved=0
while pending and expanded<1200:
 _,_,r=heapq.heappop(pending);expanded+=1
 for n in collect(r):
  for v in options(n):
   rt=replace(r,n,v)
   if rt in seenroots:continue
   seenroots.add(rt);d=len(collect(rt))
   if zeros[rt]>6 or d>203:continue
   if d<best:
    best=d;print('BEST',best,expanded,'zero',zeros[rt],flush=True)
   if d<=202 and saved<8:
    rr=a.s.sites(thaw(rt));assert a.s.graph_intervals(rr)==basegraph
    (a.O/f'swap-rotation-{saved}-{d}.sites.json.gz').write_bytes(gzip.compress(a.s.compact(rr),mtime=0));saved+=1
   if d<=201:break
   heapq.heappush(pending,(d*100+crit[rt]*2+depths[rt]*0.0001+rng.random(),rng.random(),rt))
 if best<=201:break
 if len(pending)>6000:pending=heapq.nsmallest(3500,pending);heapq.heapify(pending)
 if expanded%100==0:print('PROGRESS',expanded,'best',best,'pending',len(pending),'interned',len(ns),'sec',round(time.monotonic()-t0,1),flush=True)
print('FINISHED',expanded,best,'sec',round(time.monotonic()-t0,1),flush=True)
(a.O/'swap-rotation-results.json').write_text(json.dumps({'expanded':expanded,'minimum':best,'seen_roots':len(seenroots),'interned':len(ns),'seconds':time.monotonic()-t0},indent=2))
