"""Price contrapositive modal row; calibration is deliberately pending."""
import sys,json,gzip,os,itertools
sys.path.insert(0,'encoding_work');import permute_allocate as a
s=a.s;rows=s.sites(a.old);tokens=json.load(open('independent_work/baseline-macro-tokens.json'))['tokens'];edits=[]
for i,n,L in tokens:
 if 888<=i<1171:
  p=os.path.commonprefix([rows[i][0],rows[i+L-1][0]]);assert len(s.sites(s.subtree(a.old,p)))==L;edits.append(p)
def node(q):return next(iter(a.oldgroups[q]))
par={4:node(98),5:node(12),3:node(166)};Q=node(86);I=node(90);F=s.subtree(a.old,edits[4]);assert len(s.sites(F))==20
E={tuple(x)for x in json.load(open('encoding_work/engine_rows219_repaired.json'))['rows']}
results=[]
for x,y in itertools.permutations((3,4,5),2):
 word=[par[y],F,I,par[x],par[x],par[y],Q,F,I,Q,I];d=dict(zip(edits,word))
 def rec(n,p=''):
  if p in d:return d[p]
  if s.leaf(n):return n
  return rec(n[0],p+'0'),rec(n[1],p+'1')
 tr=rec(a.old);met=s.metrics(tr);z={'binder_reg':x,'formula_reg':y,'metrics':met};print(json.dumps(z),flush=True)
 name=f'rho6-contrapositive-{x}{y}-{met["dag_nodes"]}';(a.O/(name+'.sites.json.gz')).write_bytes(gzip.compress(s.compact(s.sites(tr)),mtime=0))
 if met['dag_nodes']<=202 and met['maximum_zero_run']<=6:
  info,T,S=a.tryperm(tuple(range(9)),E,20,tr);z['allocation']=info;print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True)
  if T:(a.O/(name+'.native.tm')).write_bytes(a.b.table_bytes(T))
 results.append(z)
(a.O/'rho6-contrapositive-results.json').write_text(json.dumps(results,indent=2))
