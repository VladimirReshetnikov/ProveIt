"""Permute closed AX row blocks on the literal source's maximal closed frontier.
The old binary skeleton is kept; every moved chunk is closed and returns normally.
"""
from pathlib import Path
import sys,json,itertools,time
from functools import cache
sys.path.insert(0,str(Path(__file__).parent));import permute_allocate as a
s=a.s;old=a.old;rows=s.sites(old);bounds=[479,888,1171,1467,1766,2062,2412,2643]
@cache
def size(t):return 1 if s.leaf(t)else size(t[0])+size(t[1])
children=[];leafvalues=[];depth=[];leading=[];zeros=[];intern={}
def node(t):
 if s.leaf(t):key=t
 else:key=node(t[0]),node(t[1])
 return make(key)
def make(key):
 if key in intern:return intern[key]
 k=len(children);intern[key]=k
 if isinstance(key[0],str):children.append(None);leafvalues.append(key);depth.append(0);leading.append(0);zeros.append(0)
 else:
  l,r=key;children.append(key);leafvalues.append(None);depth.append(1+max(depth[l],depth[r]));leading.append(1+leading[l]);zeros.append(max(zeros[l],zeros[r],leading[k]))
 return k
root=node(old);chunks=[[]for _ in range(7)];slotnodes=[]
def skeleton(t,i=0,p=''):
 j=i+size(t)
 for k in range(7):
  if bounds[k]<=i<j<=bounds[k+1] and s.boundary(t)==(0,0,False):
   z=len(slotnodes);nid=node(t);slotnodes.append(nid);chunks[k].append(nid);return('slot',z)
 if j<=bounds[0]or i>=bounds[-1]:return('fixed',node(t))
 assert not s.leaf(t),(p,t,i)
 return('pair',skeleton(t[0],i,p+'0'),skeleton(t[1],i+size(t[0]),p+'1'))
sk=skeleton(old)
def instantiate(t,slots):
 if t[0]=='slot':return slots[t[1]]
 if t[0]=='fixed':return t[1]
 return make((instantiate(t[1],slots),instantiate(t[2],slots)))
def reachable(n):
 seen=set();todo=[n]
 while todo:
  k=todo.pop()
  if k in seen:continue
  seen.add(k)
  if children[k]:todo.extend(children[k])
 return len(seen)
@cache
def expand(n):return leafvalues[n] if children[n]is None else tuple(expand(c)for c in children[n])
assert instantiate(sk,slotnodes)==root
print('BASE',reachable(root),'CHUNKS',list(map(len,chunks)),flush=True)
start=time.monotonic();best=999;records=[];count=0;best_any=999
for perm in itertools.permutations(range(7)):
 slots=[n for k in perm for n in chunks[k]];r=instantiate(sk,slots);n=reachable(r);best_any=min(best_any,n)
 if zeros[r]>6:continue
 count+=1
 if n<best:best=n;records=[];print('BEST',n,perm,'depth',depth[r],'zero',zeros[r],flush=True)
 if n==best and len(records)<40:records.append((n,perm,r,depth[r],zeros[r]))
print('DONE',best,'UNCONSTRAINED',best_any,'VALID',count,'INTERNED',len(children),'SECONDS',time.monotonic()-start,flush=True)
graph=s.graph_intervals(rows);saved=[]
for index,(n,perm,r,d,z)in enumerate(records):
 new=s.sites(expand(r));leaforder=list(range(bounds[0]));newbounds={};pos=bounds[0]
 for k in perm:
  newbounds[k]=(pos,pos+bounds[k+1]-bounds[k]);leaforder.extend(range(bounds[k],bounds[k+1]));pos=newbounds[k][1]
 leaforder.extend(range(bounds[-1],len(rows)));mapping={old:newi for newi,old in enumerate(leaforder)}
 desired=[]
 for oldi in leaforder:
  row=next((k for k in range(7)if bounds[k]<=oldi<bounds[k+1]),None);e,ts=graph[oldi]
  def dest(t):
   if row is not None and t==bounds[row+1]:return newbounds[row][1]
   if row is None and t==bounds[0]:return bounds[0]
   return mapping[t]
  desired.append([e,list(map(dest,ts))])
 assert [[o,k]for p,o,k in new]==[[rows[i][1],rows[i][2]]for i in leaforder]
 assert s.graph_intervals(new)==desired,('graph mismatch',perm)
 assert s.graph_arithmetic(new)[0]==desired
 rec=dict(nodes=n,permutation=perm,depth=d,zero=z,source_graph_verified=True)
 if perm!=tuple(range(7)) or n<202:
  stem='row-order'+str(index)+'-'+str(n);(a.O/(stem+'.sites.json')).write_bytes(s.compact(new));rec['source']=stem+'.sites.json'
 saved.append(rec)
(a.O/'row-order-results.json').write_text(json.dumps(dict(best=best,best_any=best_any,orders=5040,valid_orders=count,records=saved),indent=2))
