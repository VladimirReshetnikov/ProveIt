"""Price calibrated asymmetric affine crossed-equality helper layouts."""
from pathlib import Path
import sys,json,itertools,time
from functools import cache
sys.path.insert(0,str(Path(__file__).parent));import permute_allocate as a
from replace_closed import replace
sys.path.insert(0,str(a.O.parent/'formalism_work'));from delete_closed import remove
s=a.s;original=s.sites(a.old);P={3:next(iter(a.oldgroups[166])),4:next(iter(a.oldgroups[98])),5:next(iter(a.oldgroups[12]))};C={k:p[1]for k,p in P.items()};CI=('CI',1)
@cache
def parse(xs):
 if len(xs)==1:return(xs[0],)
 return tuple((l,r)for k in range(1,len(xs))for l in parse(xs[:k])for r in parse(xs[k:]))
def rename_rows(rows,lo,hi,old,new):
 for j in range(lo,hi):
  if rows[j][1]in('CI','CD')and rows[j][2]==old:rows[j][2]=new
records=[];best=999;count=0;t0=time.monotonic()
for firstdrop,finaldrop,x,y in itertools.product(range(2),range(2),(3,4,5),(3,4,5)):
 if x==y:continue
 rows=json.loads(json.dumps(original))
 # Surviving first atom is old E(C,A) or E(C,B); rename its two independent argument loads.
 lo=561 if firstdrop else 479;rename_rows(rows,lo,lo+26,3,x);rename_rows(rows,lo+26,lo+52,5 if firstdrop else 4,y)
 # Last atom E(A,B) becomes E(y,x).
 rename_rows(rows,723,749,4,y);rename_rows(rows,749,775,5,x)
 cut0=(479,561)if firstdrop else(561,643);cut1=(861,888)if finaldrop else(834,861)
 base=remove(rows,[cut0,cut1]);assert len(base)==len(rows)-109
 bt=s.tree(base);left,right=base[561][0],base[640][0];cp=''
 for c,d in zip(left,right):
  if c!=d:break
  cp+=c
 assert len(s.sites(s.subtree(bt,cp)))==80
 for double in(x,y):
  args=[x,y,double]
  for order in sorted(set(itertools.permutations(args))):
   for ai,node in enumerate(parse((P[order[0]],C[order[1]],C[order[2]],CI))):
    tree=s.replace(bt,cp,node);m=s.metrics(tree);n=m['dag_nodes'];count+=1
    if m['maximum_zero_run']>9:continue
    rec=dict(dag=n,drop_first=firstdrop,drop_final=finaldrop,x=x,y=y,double=double,order=order,association=ai,metrics=m)
    if n<best:best=n;records=[];print('BEST',rec,flush=True)
    if n==best and len(records)<12:
     stem='crossed-affine'+str(len(records))+'-'+str(n);rec['file']=stem+'.sites.json';(a.O/rec['file']).write_bytes(s.compact(s.sites(tree)));records.append(rec)
print('DONE',count,'BEST',best,'SECONDS',time.monotonic()-t0,flush=True)
(a.O/'crossed-affine-results.json').write_text(json.dumps(dict(best=best,cases=count,records=records),indent=2))
