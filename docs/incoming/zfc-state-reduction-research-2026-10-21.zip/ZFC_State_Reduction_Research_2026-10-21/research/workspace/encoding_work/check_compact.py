from pathlib import Path
import sys,json,time,hashlib
K=Path('/workspace/scratch/e33dac3aae74/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215');sys.path.insert(0,str(K/'code/runtime-inputs'));import validate_native as v
s=v.s;p=Path(sys.argv[1]);src=Path(sys.argv[2]);out=Path(sys.argv[3]);T=s.r.table(p)
m={int(k):int(w)for k,w in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in {q for q,b in T}|{254}:m.setdefault(q,q+1000)
L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()};start=time.monotonic();nc=rules=0;fails=[];st=v.startup(T,1500000);print('STARTUP',st['status'],st['steps'],flush=True)
try:lemmas,blocks=s.prove_blocks(L)
except Exception as e:fails=[dict(block=str(e)[:2000])]
if not fails:
 for i,site in enumerate(json.loads(src.read_text())):
  for pos in((False,True)if site[1]=='CD'else(False,)):
   try:r=s.case(L,lemmas,site,pos);nc+=1;rules+=r['symbolic_steps']
   except Exception as e:fails.append(dict(index=i,site=site,positive=pos,error=str(e)[:1500]));break
  if fails:break
  if(i+1)%1000==0:print('SITE',i+1,'CASES',nc,'SECONDS',round(time.monotonic()-start,2),flush=True)
result=dict(status='PASS'if not fails else'NOT_PROVED',table_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),working_states=len(T)//2,proved_cases=nc,symbolic_rules=rules,failures=fails,startup={k:x for k,x in st.items()if k not in('trace','one_cells')},seconds=time.monotonic()-start)
out.write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
