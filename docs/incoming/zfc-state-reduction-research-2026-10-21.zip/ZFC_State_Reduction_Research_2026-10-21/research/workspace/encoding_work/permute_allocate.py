"""Search physical register renamings with all freshly observed engine rows fixed.
Synthesis only; source/runtime/blank proofs must be checked independently.
"""
from pathlib import Path
from collections import defaultdict,Counter
from functools import cache
import sys,json,itertools,time,argparse
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import lil_matrix
K=Path('/workspace/scratch/e33dac3aae74/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(K/'code'))
import source_language as s,build221 as b
O=Path('/workspace/scratch/e33dac3aae74/encoding_work')
T=b.read_table((K/'k215.native.tm').read_bytes());old=s.tree(json.loads((K/'sites215.json').read_text()));oldgroups,oldpaths=b.decoder_map(T,old)
oldstates=defaultdict(set)
for q,ns in oldgroups.items():
 for n in ns:oldstates[n].add(q)
def paths(n,p=''):
 if s.leaf(n):return
 yield p,n
 yield from paths(n[0],p+'0');yield from paths(n[1],p+'1')
def edge(q,p,bit):
 tape={-1:1,**{i:int(x)for i,x in enumerate(p+str(bit))}};before=dict(tape);h=len(p);used=[]
 for _ in range(100):
  if h==len(p)+1:return (q if tape==before else None),used
  if h not in tape or(q,tape[h])not in T:return None,used
  k=(q,tape[h]);used.append(k);w,d,q=T[k];tape[h]=w;h+=d
 return None,used
@cache
def compat(n,p,q):
 if q not in oldstates.get(n,()):return False
 for bit,ch in enumerate(n):
  if s.leaf(ch):
   if q==108 and bit==1:
    req={'CC':'101','CB':'001'}.get(ch[0])
    if req and not('1'+p+'1').endswith(req):return False
   continue
  z,_=edge(q,p,bit)
  if z is None or not compat(ch,p+str(bit),z):return False
 return True
leafacts=defaultdict(Counter)
for q,ns in oldgroups.items():
 for n in ns:
  for bit,ch in enumerate(n):
   if s.leaf(ch):leafacts[ch,bit][T[q,bit]]+=1
for op,arg,q in[('CC',1,1),('CC',2,16),('CB',1,302)]:
 key=((op,arg),1)
 if key in leafacts:leafacts[key][0,-1,q]+=1
defaults={k:max([a for a in v if a[:2]==(k[1],1)]or v,key=lambda a:v[a])for k,v in leafacts.items()}

def tryperm(perm,engine,limit,new_override=None,seed=None,release=None):
 @cache
 def rename(n):
  if s.leaf(n):return(n[0],perm[n[1]])if n[0]in('CI','CD')else n
  return(rename(n[0]),rename(n[1]))
 new=rename(old) if new_override is None else new_override;occ=defaultdict(list)
 for p,n in paths(new):occ[n].append(p)
 fixed={n:{q for q in oldstates.get(n,())if all(compat(n,p,q)for p in ps)}for n,ps in occ.items()};fixed={n:q for n,q in fixed.items()if q and (release is None or n not in release)}
 changed=[n for n in occ if n not in fixed];used=set().union(*fixed.values());pool=sorted({q for q,_ in T}-used)
 protected=set(engine)
 for n,qs in fixed.items():
  for p in occ[n]:
   for q in qs:
    for bit,ch in enumerate(n):
     if not s.leaf(ch):
      z,trace=edge(q,p,bit);assert z is not None;protected.update(trace[1:])
 domains={n:set(pool)for n in changed};reqs={}
 fixed_uses=defaultdict(set);rewrite_fixed=[]
 for n,qs in fixed.items():
  for q in qs:
   for bit,ch in enumerate(n):fixed_uses[q,bit].add(ch)
 for n,qs in fixed.items():
  for q in qs:
   for bit,ch in enumerate(n):
    if s.leaf(ch) or ch in fixed:continue
    if (q,bit) not in protected and T[q,bit][:2]==(bit,1) and len(fixed_uses[q,bit])==1:
     rewrite_fixed.append((q,bit,ch))
    else:
     for p in occ[n]:
      z,_=edge(q,p,bit);assert z is not None;domains[ch]&={z}

 if new in domains:domains[new]&={84}
 else:assert fixed[new]=={84}
 for n in changed:
  for q in list(domains[n]):
   valid=True;req=[]
   for bit,ch in enumerate(n):
    if(q,bit)not in protected:continue
    act=T[q,bit]
    if s.leaf(ch):valid &=act in leafacts.get((ch,bit),())
    elif act[:2]!=(bit,1):valid=False
    elif ch in fixed:valid &=act[2]in fixed[ch]
    else:req.append((ch,act[2]))
   if valid:reqs[n,q]=req
   else:domains[n].remove(q)
 stable=False
 while not stable:
  stable=True
  for n in changed:
   for q in list(domains[n]):
    if any(t not in domains[ch]for ch,t in reqs[n,q]):domains[n].remove(q);stable=False
 info={'perm':perm,'new_nodes':len(changed),'fixed_nodes':len(fixed),'fixed_states':len(used),'pool':len(pool),'protected':len(protected),'empty_domains':sum(not v for v in domains.values())}
 if info['empty_domains']:
  info['empty_oldstates']=[sorted(oldstates.get(n,()))for n,v in domains.items()if not v]
  return info,None,None
 if not changed:return{**info,'states':215,'identity':True},T,new
 choices=[(n,q)for n in changed for q in sorted(domains[n])];idx={v:i for i,v in enumerate(choices)};rows=[];lo=[];hi=[]
 for n in changed:rows.append({idx[n,q]:1 for q in domains[n]});lo.append(1);hi.append(1)
 for q in pool:rows.append({idx[n,q]:1 for n in changed if q in domains[n]});lo.append(0);hi.append(1)
 for n,q in choices:
  for ch,t in reqs[n,q]:rows.append({idx[n,q]:1,idx[ch,t]:-1});lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rows),len(choices)))
 for i,row in enumerate(rows):
  for j,v in row.items():A[i,j]=v
 mandatory={q for q,bit in protected}|{T[k][2]for k in protected}|used|{0}
 rng=np.random.default_rng(seed)
 costs=np.array([1000*(q not in mandatory)+(q/100000 if seed is None else float(rng.random())) for n,q in choices])
 info.update(mandatory_states=len(mandatory-{254}),objective="physical state reuse")
 ans=milp(costs,integrality=np.ones(len(choices)),bounds=Bounds(0,1),constraints=LinearConstraint(A.tocsc(),lo,hi),options={'time_limit':limit})
 info.update(variables=len(choices),solver=ans.message)
 if ans.x is None:return info,None,None
 mapped={n:set(qs)for n,qs in fixed.items()}
 for(n,q),x in zip(choices,ans.x):
  if x>.5:mapped[n]={q}
 N=dict(T)
 for q,bit,ch in rewrite_fixed:N[q,bit]=(bit,1,min(mapped[ch]))
 for n in changed:
  q=next(iter(mapped[n]))
  for bit,ch in enumerate(n):
   if(q,bit)in protected:continue
   if s.leaf(ch):
    if(ch,bit)not in defaults:return{**info,'missing':(ch,bit)},None,None
    N[q,bit]=defaults[ch,bit]
   else:N[q,bit]=(bit,1,min(mapped[ch]))
 assert all(N[k]==T[k]for k in protected)
 reach={0};todo=[0]
 for q in todo:
  for bit in(0,1):
   z=N[q,bit][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 N={k:v for k,v in N.items()if k[0]in reach}
 info.update(states=len(reach),removed=sorted({q for q,b in T}-reach),changed_rows=[[q,bit,*N[q,bit]]for q,bit in N if N[q,bit]!=T[q,bit]])
 return info,N,new

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--limit',type=float,default=3);ap.add_argument('--random',type=int,default=0);ap.add_argument('--source',type=Path);a=ap.parse_args();record=json.loads(a.engine.read_text());engine={tuple(x)for x in record['rows']}
 identity=tuple(range(9));perms=[identity]
 for i in range(9):
  for j in range(i+1,9):
   p=list(identity);p[i],p[j]=p[j],p[i];perms.append(tuple(p))
 if a.random:
  import random
  rng=random.Random(28451)
  for _ in range(a.random):
   p=list(identity);rng.shuffle(p);perms.append(tuple(p))
 new_override=s.tree(json.loads(a.source.read_text())) if a.source else None
 if a.source:perms=[identity]
 receipt=[]
 for ix,perm in enumerate(perms):
  started=time.monotonic();info,N,tree=tryperm(perm,engine,a.limit,new_override);info.update(index=ix,seconds=time.monotonic()-started)
  print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True);receipt.append(info)
  stem=a.source.stem if a.source else 'permutation'
  (O/(stem+'_search.json')).write_text(json.dumps(receipt,indent=2))
  if N and (a.source or info.get('states',999)<=214):
   stem+=str(ix)+'-'+str(info['states']);(O/(stem+'.native.tm')).write_bytes(b.table_bytes(N));(O/(stem+'.sites.json')).write_bytes(s.compact(s.sites(tree)));(O/(stem+'.json')).write_text(json.dumps(info,indent=2));break
if __name__=='__main__':main()
