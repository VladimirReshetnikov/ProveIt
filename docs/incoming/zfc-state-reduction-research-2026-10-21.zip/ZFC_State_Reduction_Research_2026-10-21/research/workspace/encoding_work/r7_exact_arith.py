import sys,json,functools,itertools,time
from pathlib import Path
sys.path[:0]=['encoding_work','independent_work'];import replace_closed as rc,permute_allocate as a
s=rc.s;ROOT=a.O.parent
ns={'__file__':str(ROOT/'independent_work/audit_r7.py')};exec((ROOT/'independent_work/audit_r7.py').read_text().split('oldstart,oldend=')[0],ns)
old=ns['old'];loc=ns['local_graph'];norm=ns['normalize_increments'];expand=ns['expand']
@functools.cache
def nodes(t):return frozenset([t])if s.leaf(t)else frozenset([t])|nodes(t[0])|nodes(t[1])
ON=nodes(s.tree(old))
def findmacro(i):
 pattern=norm(loc(s.sites(expand('ENode '+str(i)))))
 return [t for t in ON if not s.leaf(t)and s.boundary(t)==(0,0,False)and len(s.sites(t))==len(pattern)and norm(loc(s.sites(t)))==pattern]
@functools.cache
def assoc(xs):
 if len(xs)==1:return(xs[0],)
 return tuple((l,r)for i in range(1,len(xs))for l in assoc(xs[:i])for r in assoc(xs[i:]))
I=('CI',1);I2=(I,I);I4=(I2,I2);I8=(I4,I4);I16=(I8,I8);moveX=(('CD',1),(('CI',6),('CC',2)));moveY=(('CD',1),(('CI',7),('CC',2)));scale16=(('CD',7),(I16,('CC',2)))
pairs=findmacro(162);scales=findmacro(117);best=999;rank=[];seen=set();E={tuple(x)for x in json.load(open('encoding_work/engine_rows219_repaired.json'))['rows']}
for pair in pairs:
 for six in (I2,I4), (I4,I2), (I2,I2,I2):
  for n in assoc((I,moveX,pair,scale16,*six)):
   if n in seen:continue
   seen.add(n);cost=len(nodes(n)-ON)
   if cost>12:continue
   rr=rc.replace(old,25+698,25+809,n);t=s.tree(rr);m=s.metrics(t)
   if m['dag_nodes']<best:best=m['dag_nodes'];print('BEST exact',best,m,'newnodes',cost,'macro',len(s.sites(n)),flush=True)
   rank.append((m['dag_nodes'],cost,len(s.sites(n)),rr,n,m))
for pair in pairs:
 for scale in scales:
  for six in (I2,I4), (I4,I2), (I2,I2,I2):
   for n in assoc((I,moveX,pair,scale,moveY,scale,*six)):
    if n in seen:continue
    seen.add(n);cost=len(nodes(n)-ON)
    if cost>12:continue
    rr=rc.replace(old,25+698,25+809,n);t=s.tree(rr);m=s.metrics(t)
    if m['dag_nodes']<best:best=m['dag_nodes'];print('BEST exact composition',best,m,'newnodes',cost,'macro',len(s.sites(n)),flush=True)
    rank.append((m['dag_nodes'],cost,len(s.sites(n)),rr,n,m))
print('DONE',len(rank),'best',best,flush=True)
for ix,x in enumerate(sorted(rank,key=lambda x:x[:3])[:10]):
 count,cost,leaves,rr,n,m=x;name=f'r7_exactarith{ix}_{count}';(a.O/(name+'.sites.json')).write_bytes(s.compact(rr));(a.O/(name+'.macro.json')).write_text(json.dumps(n));
 if count<=202:
  i,T,S=a.tryperm(tuple(range(9)),E,10,s.tree(rr));print('ALLOC',name,{k:v for k,v in i.items()if k!='changed_rows'},flush=True)
  if T:(a.O/(name+'.native.tm')).write_bytes(a.b.table_bytes(T))
