import sys,json,itertools
sys.path.insert(0,'encoding_work');import permute_allocate as a
T=a.b.read_table((a.O/'r7-no-fresh-binder0-215.native.tm').read_bytes());S=a.s.tree(json.load(open(a.O/'r7-no-fresh-binder0-215.sites.json')));groups,paths=a.b.decoder_map(T,S)
contexts=[]
for p in paths[171]:
 known='1'+p;ctx=known[-8:];want=164 if p[-1]=='1'else 90
 if(ctx,want)not in contexts:contexts.append((ctx,want))
print('contexts',contexts)
hits=[];Q=sorted({q for q,b in T}-{7})
for action in itertools.product((0,1),(-1,1),Q):
 valid=True;worst=0
 for prefix,want in contexts:
  old={i-len(prefix):int(b)for i,b in enumerate(prefix)};old[0]=0;t=dict(old);q=171;h=0
  for step in range(97):
   if h==1:
    if q==want and t==old:worst=max(worst,step);break
    valid=False;break
   if h not in t or q==7:valid=False;break
   if(q,t[h])==(171,0):
    if step:valid=False;break
    w,d,q=action
   else:w,d,q=T[q,t[h]]
   t[h]=w;h+=d
  else:valid=False
  if not valid:break
 if valid:hits.append((action,worst))
print('hits',hits)
(a.O/'retire7_search.json').write_text(json.dumps(dict(contexts=contexts,hits=hits)))
