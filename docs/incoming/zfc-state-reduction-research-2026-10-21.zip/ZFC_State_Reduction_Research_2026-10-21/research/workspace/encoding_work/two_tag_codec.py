"""Two-tag formula codec via exact constructor-site transformations.
Proof/list pairing stays Cantor P. Uses local closed AST substitution only.
"""
import sys,json,os,gzip,itertools
from functools import cache
sys.path.insert(0,'encoding_work');import permute_allocate as a
s=a.s;old=a.old;rows=s.sites(old)
tokens=json.load(open('independent_work/baseline-macro-tokens.json'))['tokens']
def node(q):return next(iter(a.oldgroups[q]))
P=node(58);SET=node(105);F4=node(106);S4=node(125);I=('CI',1);IX=('CI',6)
S2=(('CD',7),((I,I),('CC',2)));F2=(P,S2);C2=(SET,F2)
@cache
def cats(xs):
 if len(xs)==1:return (xs[0],)
 return tuple((u,v)for k in range(1,len(xs))for u in cats(xs[:k])for v in cats(xs[k:]))

def make(qstyle=0,mstyle=0):
 qm=cats((SET,IX,F2,I))[qstyle];mm=cats((C2,F2,I))[mstyle]
 edits={};kinds={}
 for i,n,L in tokens:
  if n not in ('M','Q','E'):continue
  p=os.path.commonprefix([rows[i][0],rows[i+L-1][0]])
  if n=='M':
   assert len(s.sites(s.subtree(old,p)))==28
   edits[p]=mm;kinds[p]='M'
  elif n=='E':
   assert rows[i+28][1:]==['CI',1]
   edits[rows[i+28][0]]=F2;kinds[rows[i+28][0]]='E-middle-tag'
  elif len(s.sites(s.subtree(old,p)))==29:
   edits[p]=qm;kinds[p]='Q'
  else:
   # One Q has CONS and the two final increments across different parents.
   fp=os.path.commonprefix([rows[i+11][0],rows[i+26][0]])
   ip=os.path.commonprefix([rows[i+27][0],rows[i+28][0]])
   assert s.subtree(old,fp)==F4 and s.subtree(old,ip)==(I,I)
   edits[fp]=(IX,F2);edits[ip]=I;kinds[fp]='Q-pair';kinds[ip]='Q-tag'
 def rec(n,p=''):
  if p in edits:return edits[p]
  if n==S4:return S2
  if s.leaf(n):return n
  return rec(n[0],p+'0'),rec(n[1],p+'1')
 tr=rec(old)
 # All replacements are closed and preserve their enclosing control interfaces.
 assert all(s.boundary(v)==(0,0,False)for v in edits.values())
 rr=s.sites(tr);assert s.graph_arithmetic(rr)[0]==s.graph_intervals(rr)
 return tr,{'qstyle':qstyle,'mstyle':mstyle,'metrics':s.metrics(tr),'edits':[[p,kinds[p],len(s.sites(edits[p]))]for p in edits]}

if __name__=='__main__':
 results=[];best=999
 for qstyle in range(5):
  for mstyle in range(2):
   tr,info=make(qstyle,mstyle);results.append(info);print(json.dumps({k:v for k,v in info.items()if k!='edits'}),flush=True)
   d=info['metrics']['dag_nodes']
   if d<=best:
    best=d;name=f'two-tag-q{qstyle}m{mstyle}-{d}.sites.json.gz'
    (a.O/name).write_bytes(gzip.compress(s.compact(s.sites(tr)),mtime=0))
 (a.O/'two-tag-results.json').write_text(json.dumps(results,indent=2))
