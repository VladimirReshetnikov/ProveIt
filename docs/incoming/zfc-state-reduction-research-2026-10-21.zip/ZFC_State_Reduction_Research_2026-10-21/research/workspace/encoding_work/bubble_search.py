from pathlib import Path
import sys,json,time
from collections import defaultdict
sys.path.insert(0,str(Path(__file__).parent));import permute_allocate as a
E={tuple(x)for x in json.loads((a.O/'engine_rows219_repaired.json').read_text())['rows']}
records=[]
SOURCES=[('baseline',a.old),('rho6',a.s.tree(json.loads(Path('formalism_work/row-rho6-swapBC-202.json').read_text()))),('gated',a.s.tree(json.loads(Path('formalism_work/gated_crossed/gated-r0c0e5j2-205.json').read_text())))]
for name,S in SOURCES:
 occ=defaultdict(list)
 for p,n in a.paths(S):occ[n].append(p)
 fixed={n:{q for q in a.oldstates.get(n,())if all(a.compat(n,p,q)for p in ps)}for n,ps in occ.items()};fixed={n:qs for n,qs in fixed.items()if qs}
 changed=set(occ)-set(fixed)
 neighbors=defaultdict(set)
 for n in occ:
  for ch in n:
   if not a.s.leaf(ch):neighbors[n].add(ch);neighbors[ch].add(n)
 alias={n for n,qs in fixed.items()if any(len(a.oldgroups[q])>1 for q in a.oldstates[n]) or len(a.oldstates[n])>1}
 alias|={n for n,qs in fixed.items()if any(not a.s.leaf(ch) and a.T[q,b][:2]!=(b,1) for q in qs for b,ch in enumerate(n))}
 R=set();edge=set(changed)
 variants=[]
 for depth in range(1,4):
  edge={ch for n in edge for ch in neighbors[n]}-R;R|=edge
  variants.append(('depth'+str(depth),R&set(fixed)-alias))
 variants.extend([('all-simple',set(fixed)-alias),('engine-simple',{n for n,qs in fixed.items()if n not in alias and any((q,b)in E for q in qs for b in(0,1))})])
 seen=set()
 for tag,R in variants:
  key=frozenset(R)
  if not R or key in seen:continue
  seen.add(key);t=time.monotonic();info,T,NS=a.tryperm(tuple(range(9)),E,30,S,release=R);info.update(source=name,variant=tag,release=len(R),seconds=time.monotonic()-t)
  print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True);records.append({k:v for k,v in info.items()if k!='changed_rows'})
  if T:
   try:a.b.decoder_map(T,NS);print('DECODER OK',flush=True)
   except Exception as ex:print('DECODER FAIL',repr(ex),flush=True);continue
   if info['states']<=214:
    stem=name+'-'+tag;(a.O/(stem+'.native.tm')).write_bytes(a.b.table_bytes(T));(a.O/(stem+'.sites.json')).write_bytes(a.s.compact(a.s.sites(NS)));(a.O/(stem+'.allocation.json')).write_text(json.dumps(info));raise SystemExit
 (a.O/'bubble-search-results.json').write_text(json.dumps(records))
