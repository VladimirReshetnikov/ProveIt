from pathlib import Path
import sys,json,time,itertools
from collections import defaultdict
sys.path.insert(0,str(Path(__file__).parent));import permute_allocate as a
E={tuple(x)for x in json.loads((a.O/'engine_rows219_repaired.json').read_text())['rows']}
records=[];base=tuple(range(9))
for ix,(triple,direction)in enumerate(itertools.product(itertools.combinations(range(9),3),range(2))):
 p=list(base);x,y,z=triple
 if direction:p[x],p[y],p[z]=z,x,y
 else:p[x],p[y],p[z]=y,z,x
 t=time.monotonic();info,T,S=a.tryperm(tuple(p),E,2);info.update(index=ix,seconds=time.monotonic()-t)
 print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True);records.append({k:v for k,v in info.items()if k!='changed_rows'})
 if T:
  try:a.b.decoder_map(T,S);print('DECODER OK',flush=True)
  except Exception as ex:print('DECODER FAIL',repr(ex),flush=True);continue
  stem='cycle'+str(ix);(a.O/(stem+'.native.tm')).write_bytes(a.b.table_bytes(T));(a.O/(stem+'.sites.json')).write_bytes(a.s.compact(a.s.sites(S)));(a.O/(stem+'.allocation.json')).write_text(json.dumps(info))
  if info['states']<=214:raise SystemExit
 if ix%20==0:(a.O/'cycles-search-results.json').write_text(json.dumps(records))
(a.O/'cycles-search-results.json').write_text(json.dumps(records))
