"""Price prefix-free variable-length low-bit formula constructor tags."""
import sys,json,os,gzip,itertools
from functools import cache
sys.path.insert(0,'encoding_work');import two_tag_codec as d
s=d.s;a=d.a;I=d.I;tokens=d.tokens;rows=d.rows
@cache
def increments(k):
 if k==1:return(I,)
 return tuple((x,y)for j in range(1,k)for x in increments(j)for y in increments(k-j))
@cache
def balanced(k):return I if k==1 else(balanced(k//2),balanced(k-k//2))
@cache
def tail(k):return(d.P,(('CD',7),(balanced(k),('CC',2))))
Fpaths={}
for i,n,L in tokens:
 if n in ('I','M','Q','E'):
  p=os.path.commonprefix([rows[i+11][0],rows[i+26][0]])
  assert s.subtree(a.old,p)==d.F4
  Fpaths[p]=n

def build(tags,qs,es,ep):
 edits={p:tail(tags[n][0]) for p,n in Fpaths.items()}
 for i,n,L in tokens:
  if n=='Q':
   p=os.path.commonprefix([rows[i+27][0],rows[i+28][0]])
   assert s.subtree(a.old,p)==(I,I)
   edits[p]=increments(tags['Q'][1])[qs]
  if n=='E' and tags['E'][1]!=3:
   edits[rows[i+27+ep][0]]=increments(tags['E'][1]-2)[es]
 def rec(n,p=''):
  if p in edits:return edits[p]
  if s.leaf(n):return n
  return rec(n[0],p+'0'),rec(n[1],p+'1')
 return rec(a.old)

if __name__=='__main__':
 tagsets=[{'I':(2,0),'M':(4,1),'Q':(8,3),'E':(8,7)}, {'I':(2,0),'M':(4,1),'Q':(8,7),'E':(8,3)}, {'I':(2,0),'M':(8,1),'Q':(4,3),'E':(8,5)}, {'I':(2,0),'M':(8,1),'Q':(8,5),'E':(4,3)}]
 best=999;rec=[]
 for ti,tags in enumerate(tagsets):
  mine=999;num=0
  for qs in range(len(increments(tags['Q'][1]))):
   for ep in range(3 if tags['E'][1]!=3 else 1):
    for es in range(len(increments(tags['E'][1]-2))):
     tr=build(tags,qs,es,ep);met=s.metrics(tr);info={'tagset':ti,'qs':qs,'es':es,'ep':ep,'metrics':met};num+=1
     cost=met['dag_nodes'];mine=min(mine,cost)
     if cost<=best:
      rec.append(info)
      if cost<best:print(json.dumps(info),flush=True);best=cost
      if met['maximum_zero_run']<=7:
       (a.O/f'prefix-codec-t{ti}q{qs}e{es}p{ep}-{cost}.sites.json.gz').write_bytes(gzip.compress(s.compact(s.sites(tr)),mtime=0))
  print(json.dumps({'tagset':ti,'minimum':mine,'layouts':num}),flush=True)
 (a.O/'prefix-codec-results.json').write_text(json.dumps({'best':best,'records':rec,'tags':tagsets},indent=2))
