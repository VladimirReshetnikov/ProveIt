from pathlib import Path
from functools import cache
import json,sys
sys.path.insert(0,str(Path(__file__).parent));import permute_allocate as a
marks={a.s.subtree(a.old,x['pc'][:-1])for x in json.loads((a.O/'hazard37.json').read_text())};print('MARKS',len(marks),flush=True)
a.T[34,0]=(0,-1,75)
for b in(0,1):del a.T[50,b]
E={tuple(x)for x in json.loads((a.O/'engine_rows219_repaired.json').read_text())['rows']if x[0]!=50}
a.leafacts[(('CB',1),0)][0,-1,302]=1;a.defaults[(('CB',1),0)]=(0,-1,302)
receipts=[]
for dead in(('CI',1),('CD',6),('CC',2),('CH',None)):
 nop=(('CB',1),dead)
 @cache
 def tr(n):
  if a.s.leaf(n):return n
  out=tr(n[0]),tr(n[1])
  return(nop,out)if n in marks else out
 new=tr(a.old);metrics=a.s.metrics(new);rows=a.s.sites(new);bad=[p for p,o,k in rows if o in('CI','CD')and p.endswith('000000')]
 print('SOURCE',dead,metrics,'HAZARD_LEAVES',len(bad),flush=True)
 info,T,S=a.tryperm(tuple(range(9)),E,10,new);info.update(dead=dead,metrics=metrics,hazard_count=len(bad));print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True);receipts.append({k:v for k,v in info.items()if k!='changed_rows'})
 if T and info['states']<=214:
  stem='padded'+str(dead[0])+str(dead[1]);(a.O/(stem+'.native.tm')).write_bytes(a.b.table_bytes(T));(a.O/(stem+'.sites.json')).write_bytes(a.s.compact(rows));(a.O/(stem+'.allocation.json')).write_text(json.dumps(info))
(a.O/'scanner-padding-results.json').write_text(json.dumps(receipts,indent=2))
