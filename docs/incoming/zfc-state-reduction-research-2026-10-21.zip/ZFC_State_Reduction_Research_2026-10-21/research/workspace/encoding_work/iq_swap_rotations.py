import sys,runpy,json,gzip,heapq,random,time
sys.path.insert(0,'encoding_work');import permute_allocate as a
sys.argv=[sys.argv[0],'--steps','0'];g=runpy.run_path('root_work/search_rotations.py')
pack,collect,options,replace,thaw=[g[x]for x in('pack','collect','options','replace','thaw')];ns,zeros,crit,depths=[g[x]for x in('ns','zeros','crit','depths')]
p='independent_work/tag_permutations/tags-I2Q0E3-i0q0.sites.json.gz';tr=a.s.tree(json.loads(gzip.decompress(open(p,'rb').read())))
start=pack(tr);basegraph=a.s.graph_intervals(a.s.sites(tr));best=(203,10);bestcost=400;expanded=0;t0=time.monotonic();rng=random.Random(216)
seenroots={start};pending=[(0,0,start)];saved=0
while pending and expanded<1500:
 _,_,r=heapq.heappop(pending);expanded+=1
 for n in collect(r):
  for v in options(n):
   rt=replace(r,n,v)
   if rt in seenroots:continue
   seenroots.add(rt);d=len(collect(rt));z=zeros[rt];c=10*d+4*z
   if z>10 or d>205:continue
   if c<bestcost:
    bestcost=c;best=(d,z);print('BEST',best,expanded,flush=True)
   if d<=203 and z<=6 and saved<4:
    rr=a.s.sites(thaw(rt));assert a.s.graph_intervals(rr)==basegraph
    (a.O/f'iq-swap-rotation-{saved}-{d}.sites.json.gz').write_bytes(gzip.compress(a.s.compact(rr),mtime=0));saved+=1
   heapq.heappush(pending,(100*(d-203)+40*(z-6)+2*crit[rt]+rng.random(),rng.random(),rt))
 if saved:break
 if len(pending)>6000:pending=heapq.nsmallest(3500,pending);heapq.heapify(pending)
 if expanded%100==0:print('PROGRESS',expanded,'best',best,'pending',len(pending),'interned',len(ns),'sec',round(time.monotonic()-t0,1),flush=True)
print('FINISHED',expanded,best,'saved',saved,'sec',round(time.monotonic()-t0,1),flush=True)
(a.O/'iq-swap-rotation-results.json').write_text(json.dumps({'expanded':expanded,'minimum_score':best,'saved':saved,'seen_roots':len(seenroots),'interned':len(ns),'seconds':time.monotonic()-t0},indent=2))
