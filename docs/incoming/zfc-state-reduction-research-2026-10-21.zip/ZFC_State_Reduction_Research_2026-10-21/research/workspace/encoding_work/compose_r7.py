import sys,json,time
from pathlib import Path
sys.path[:0]=['encoding_work','independent_work'];import permute_allocate as a,general_folds as f
s=a.s;base=s.tree(json.load(open('formalism_work/r7-no-fresh-binder.json')));E={tuple(x)for x in json.load(open('encoding_work/engine_rows219_repaired.json'))['rows']};oldload=s.subtree(a.old,'11010010111');variants={}
for name,node in [('cache',(('CD',4),(('CI',5),('CC',2)))),('omit',oldload[1])]:variants['r7_mp_'+name]=s.replace(base,'11010010111',node)
# Counter preincrement / postincrement variants.
C=(('CD',0),(('CI',8),(('CI',6),('CC',3))));R=(('CD',6),(('CI',0),('CC',2)));I=('CI',0)
for name,n in [('pre_right',(I,(C,R))),('pre_left',((I,C),R)),('post_right',(C,(R,I))),('post_left',((C,R),I))]:variants['r7_counter_'+name]=s.replace(base,'01',n)
receipts=[]
for name,S in variants.items():
 met=s.metrics(S);i,T,S=a.tryperm(tuple(range(9)),E,10,S);i.update(name=name,metrics=met);print(json.dumps({k:v for k,v in i.items()if k!='changed_rows'}),flush=True);receipts.append(i)
 if T:
  folds=f.folds(T);print('FOLDS',folds,flush=True);i['folds']=folds;(a.O/(name+'.native.tm')).write_bytes(a.b.table_bytes(T));(a.O/(name+'.sites.json')).write_bytes(s.compact(s.sites(S)))
(a.O/'r7_compositions.json').write_text(json.dumps(receipts,indent=2))
