"""Swap the tags of universal and equality constructors (2 and3)."""
import sys,json,os,gzip,itertools
sys.path.insert(0,'encoding_work');import permute_allocate as a
sys.path.insert(0,'formalism_work');from delete_closed import remove
s=a.s;old=a.old;rows=s.sites(old);tokens=json.load(open('independent_work/baseline-macro-tokens.json'))['tokens'];I=('CI',1)
Estarts=[i for i,n,L in tokens if n=='E'];Qstarts=[i for i,n,L in tokens if n=='Q']

def make(choices,qside):
 deleted=sorted(i+27+c for i,c in zip(Estarts,choices));rr=remove(rows,[(i,i+1)for i in deleted]);tr=s.tree(rr)
 edits={}
 for i in Qstarts:
  j=i+27+qside-sum(z<i for z in deleted)
  assert rr[j][1:]==['CI',1]
  edits[rr[j][0]]=(I,I)
 def rec(n,p=''):
  if p in edits:return edits[p]
  if s.leaf(n):return n
  return rec(n[0],p+'0'),rec(n[1],p+'1')
 return rec(tr)
if __name__=='__main__':
 rec=[];best=203;saved=0
 choiceslist=[(j,)*6 for j in range(3)]
 if '--all' in sys.argv:choiceslist=itertools.product(range(3),repeat=6)
 for choices in choiceslist:
  for qside in range(2):
   tr=make(choices,qside);met=s.metrics(tr);info={'choices':choices,'qside':qside,'metrics':met}
   c=met['dag_nodes']
   if c<=best:
    rec.append(info)
    if c<best:best=c;print(json.dumps(info),flush=True)
    if met['maximum_zero_run']<=6 and saved<8:
     saved+=1
     name='swap-q-e-'+''.join(map(str,choices))+f'-{qside}-{c}.sites.json.gz';(a.O/name).write_bytes(gzip.compress(s.compact(s.sites(tr)),mtime=0))
 (a.O/'swap-q-e-results.json').write_text(json.dumps({'best':best,'records':rec},indent=2))
