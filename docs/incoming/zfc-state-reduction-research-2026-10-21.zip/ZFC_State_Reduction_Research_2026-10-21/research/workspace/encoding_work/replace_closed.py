"""Replace a closed instruction interval by a closed macro, checking exact retained CFG."""
import sys,json
sys.path.insert(0,'encoding_work');import permute_allocate as a
s=a.s

def replace(rows,lo,hi,node):
 old=s.tree(rows);graph=s.graph_intervals(rows);N=len(rows)
 assert s.boundary(node)==(0,0,False)
 incoming={t for i,(_,ts) in enumerate(graph)if not lo<=i<hi for t in ts if lo<=t<hi}
 outgoing={t for i in range(lo,hi)for t in graph[i][1]if not lo<=t<hi}
 assert incoming=={lo} and outgoing=={hi}
 indices={p:i for i,(p,_,_)in enumerate(rows)};labels=[];m=len(s.sites(node))
 def prune(t,p=''):
  if s.leaf(t):
   i=indices[p]
   if i==lo:
    labels.extend(('new',j)for j in range(m));return node
   if lo<i<hi:return None
   labels.append(('old',i));return t
  l=prune(t[0],p+'0');r=prune(t[1],p+'1')
  if l is None:return r
  if r is None:return l
  return l,r
 tr=prune(old);new=s.sites(tr);M=len(new);mapping={v:j for j,v in enumerate(labels)};start=mapping['new',0]
 def dest(i):
  if i==lo:return start
  assert not lo<i<hi
  return mapping['old',i]
 ng=s.graph_intervals(s.sites((node,('CH',None))))
 desired=[]
 for typ,i in labels:
  if typ=='old':e,ts=graph[i];desired.append([e,[dest(t)for t in ts]])
  else:e,ts=ng[i];desired.append([e,[start+t for t in ts]])
 paths={p:i for i,(p,o,k)in enumerate(new)};ints={}
 def interval(p):
  if p in paths:x=paths[p],paths[p]+1
  else:l,r=interval(p+'0'),interval(p+'1');x=l[0],r[1]
  ints[p]=x;return x
 interval('')
 def cut(p,edge,k):
  while p:
   bit,p=p[-1],p[:-1]
   if bit==edge:
    k-=1
    if k==0:return ints[p][1]%M if edge=='0'else ints[p][0]
  return 0
 for j,(p,o,k)in enumerate(new):
  if o in('CB','CC'):
   edge='0'if o=='CB'else'1';want=desired[j][1][0];possible=[d for d in range(1,len(p)+2)if cut(p,edge,d)==want];assert possible,(labels[j],p,o,want)
   new[j][2]=min(possible)
  elif o=='CD':assert desired[j][1]==[cut(p,'0',1),(j+1)%M],(labels[j],p,'CD',desired[j])
  elif o=='CI':assert desired[j][1]==[(j+1)%M]
 assert s.graph_intervals(new)==desired
 assert s.graph_arithmetic(new)[0]==desired
 return new

if __name__=='__main__':
 from functools import cache
 rows=s.sites(a.old);par1=s.subtree(a.old,'11010010111');copy=par1[1]
 @cache
 def rename(n):
  if s.leaf(n):return(n[0],5 if n[0]in('CI','CD')and n[1]==4 else n[1])
  return rename(n[0]),rename(n[1])
 copyH=rename(copy);I=('CI',1)
 E={tuple(x)for x in json.load(open('encoding_work/engine_rows219_repaired.json'))['rows']}
 variants=[(par1,(copyH,I)),((par1,copyH),I)]
 for j,n in enumerate(variants):
  rr=replace(rows,25+618,25+698,n);tr=s.tree(rr);met=s.metrics(tr);name=f'r7_sumfresh{j}';print(name,met,flush=True);(a.O/(name+'.sites.json')).write_bytes(s.compact(rr))
  info,T,S=a.tryperm(tuple(range(9)),E,20,tr);info.update(metrics=met);print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True);(a.O/(name+'.json')).write_text(json.dumps(info,indent=2))
  if T:(a.O/(name+'.native.tm')).write_bytes(a.b.table_bytes(T))
