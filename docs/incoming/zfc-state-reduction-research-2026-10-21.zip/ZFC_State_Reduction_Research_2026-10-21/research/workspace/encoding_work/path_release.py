"""Reallocate canonical roles while retaining inherited contextual aliases."""
import sys,json,gzip
from collections import defaultdict
sys.path.insert(0,'encoding_work');import permute_allocate as a
from path_allocate import try_path
s=a.s
p=sys.argv[1];raw=open(p,'rb').read();rr=json.loads(gzip.decompress(raw)if p.endswith('.gz')else raw);tr=s.tree(rr)
prior={p:q for q,ps in a.oldpaths.items()for p in ps};occ=defaultdict(list)
for pth,n in a.paths(tr):occ[n].append(pth)
release=set()
for n,ps in occ.items():
 qs={prior.get(pth)for pth in ps}
 if None in qs or len(qs)!=1:continue
 q=next(iter(qs))
 if len(a.oldgroups[q])!=1 or any(a.T[q,b][:2]!=(b,1)for b,ch in enumerate(n)if not s.leaf(ch)):continue
 release.add(n)
E={tuple(x)for x in json.load(open('encoding_work/engine_rows219_repaired.json'))['rows']}
print('RELEASE',len(release),flush=True)
z,T,S=try_path(tr,E,45,release=release)
print(json.dumps({k:v for k,v in z.items()if k!='changed_rows'}),flush=True)
stem='path-release-'+p.rsplit('/',1)[-1].replace('.sites.json.gz','').replace('.sites.json','');(a.O/(stem+'.allocation.json')).write_text(json.dumps(z,indent=2))
if T:(a.O/(stem+'.native.tm')).write_bytes(a.b.table_bytes(T))
