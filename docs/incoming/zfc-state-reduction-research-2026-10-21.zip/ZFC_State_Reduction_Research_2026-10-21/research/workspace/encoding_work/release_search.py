from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path(__file__).parent));import permute_allocate as a
E={tuple(x) for x in json.loads((a.O/'engine_rows219_repaired.json').read_text())['rows']}
records=[]
def run(tag,S,R,limit=3):
 t=time.monotonic();info,T,S=a.tryperm(tuple(range(9)),E,limit,S,release=R);info.update(tag=tag,release=len(R),seconds=time.monotonic()-t)
 records.append({k:v for k,v in info.items()if k!='changed_rows'})
 print(json.dumps(records[-1]),flush=True)
 if T and info['states']<=214:
  print('SUCCESS',tag,info['states'],flush=True)
  (a.O/(tag+'.native.tm')).write_bytes(a.b.table_bytes(T));(a.O/(tag+'.sites.json')).write_bytes(a.s.compact(a.s.sites(S)));(a.O/(tag+'.allocation.json')).write_text(json.dumps(info))
  try:a.b.decoder_map(T,S);print('DECODER OK',flush=True)
  except Exception as e:print('DECODER FAIL',repr(e),flush=True)
  (a.O/'release-search-results.json').write_text(json.dumps(records));raise SystemExit
for p in sorted(Path('formalism_work/gated_crossed').glob('*-205.json')):
 run('gated-'+p.stem,a.s.tree(json.loads(p.read_text())),set())
for q,ns in a.oldgroups.items():run('baseline-release'+str(q),a.old,set(ns))
(a.O/'release-search-results.json').write_text(json.dumps(records))
