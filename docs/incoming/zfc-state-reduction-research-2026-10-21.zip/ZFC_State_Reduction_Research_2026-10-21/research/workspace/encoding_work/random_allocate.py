import sys,json,time
sys.path[:0]=['encoding_work','independent_work'];import permute_allocate as a,general_folds as f
from pathlib import Path
E={tuple(x)for x in json.loads((a.O/'engine_rows219_repaired.json').read_text())['rows']};S=a.s.tree(json.load(open('formalism_work/row-rho6-swapBC-202.json')));receipts=[];start=time.monotonic()
for seed in range(80):
 i,T,t=a.tryperm(tuple(range(9)),E,5,S,seed=seed);i.pop('changed_rows',None);folds=f.folds(T)if T else[];i.update(seed=seed,folds=folds);receipts.append(i)
 if folds or i.get('states',999)<=214:
  stem=f'rho6_random{seed}';(a.O/(stem+'.native.tm')).write_bytes(a.b.table_bytes(T));(a.O/(stem+'.sites.json')).write_bytes(a.s.compact(a.s.sites(S)));print('HIT',stem,i,flush=True);break
 if seed%10==0:print('SEARCH',seed,round(time.monotonic()-start,3),i.get('states'),flush=True)
(a.O/'rho6_random_search.json').write_text(json.dumps(receipts,indent=2))
