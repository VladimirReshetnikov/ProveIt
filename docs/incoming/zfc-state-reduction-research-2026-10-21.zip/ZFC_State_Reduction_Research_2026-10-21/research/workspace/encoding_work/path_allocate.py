"""Preserve inherited physical aliases using unchanged path/local-node roles.
This extends the restricted allocator; every result needs fresh universal replay.
"""
import sys,json,gzip
from collections import defaultdict
sys.path.insert(0,'encoding_work');import permute_allocate as a
s=a.s

def try_path(tree,engine,limit=30,seed=None,release=None):
 original_states=a.oldstates;original_compat=a.compat;original_compat.cache_clear()
 prior={p:q for q,ps in a.oldpaths.items()for p in ps}
 occ=defaultdict(list)
 for p,n in a.paths(tree):occ[n].append(p)
 # Freeze original compatibility before augmenting the logical role catalog.
 original_fixed={n:{q for q in original_states.get(n,())if all(original_compat(n,p,q)for p in ps)}for n,ps in occ.items()}
 extra={}
 for n,ps in occ.items():
  candidates=set();valid=True
  for p in ps:
   if p not in prior:valid=False;break
   q=prior[p];o=s.subtree(a.old,p)
   if any(s.leaf(x)!=s.leaf(y)or(s.leaf(x)and x!=y)for x,y in zip(o,n)):
    valid=False;break
   if q==108 and s.leaf(n[1]):
    req={'CC':'101','CB':'001'}.get(n[1][0])
    if req and not('1'+p+'1').endswith(req):valid=False;break
   candidates.add(q)
  if valid and len(candidates)==1:extra[n]=set(candidates)
 # A path binding must reach every already fixed child at its actual physical
 # endpoint. This prevents giving an old state incompatible old and new roles.
 while True:
  combined={n:original_fixed.get(n,set())|extra.get(n,set())for n in occ}
  removed=[]
  for n,qs in extra.items():
   for q in qs:
    bad=False
    for bit,ch in enumerate(n):
     if s.leaf(ch)or not combined[ch]:continue
     for p in occ[n]:
      z,_=a.edge(q,p,bit)
      if z not in combined[ch]:bad=True;break
     if bad:break
    if bad:removed.append((n,q))
  if not removed:break
  for n,q in removed:
   extra[n].remove(q)
   if not extra[n]:del extra[n]
 states=defaultdict(set,{n:set(qs)for n,qs in original_states.items()})
 for n,qs in extra.items():states[n].update(qs)
 def compat(n,p,q):return q in original_fixed.get(n,())or q in extra.get(n,())
 a.oldstates=states;a.compat=compat
 try:
  z,T,S=a.tryperm(tuple(range(9)),engine,limit,tree,seed,release)
  z['inherited_path_bindings']=len(extra)
  return z,T,S
 finally:
  a.oldstates=original_states;a.compat=original_compat;original_compat.cache_clear()

if __name__=='__main__':
 p=sys.argv[1];raw=open(p,'rb').read();rr=json.loads(gzip.decompress(raw)if p.endswith('.gz')else raw);tree=s.tree(rr)
 E={tuple(x)for x in json.load(open('encoding_work/engine_rows219_repaired.json'))['rows']}
 info,T,S=try_path(tree,E,float(sys.argv[2])if len(sys.argv)>2 else 30)
 print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True)
 stem='path-'+p.rsplit('/',1)[-1].replace('.sites.json.gz','').replace('.sites.json','')
 (a.O/(stem+'.allocation.json')).write_text(json.dumps(info,indent=2))
 if T:(a.O/(stem+'.native.tm')).write_bytes(a.b.table_bytes(T))
