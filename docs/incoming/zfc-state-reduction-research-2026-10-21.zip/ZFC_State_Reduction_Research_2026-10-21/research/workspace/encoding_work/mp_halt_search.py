import sys,json,itertools
from pathlib import Path
sys.path.insert(0,'encoding_work');import permute_allocate as a
s=a.s
mp=s.subtree(a.old,'11010010111');push,copy=mp
nip=s.subtree(a.old,'111');pop=nip[1][1];clear=(('CD',5),('CC',1));nipnew=(clear,pop)
I4=('CI',4);D4=('CD',4);CH=('CH',None);CB=('CB',1)
def parses(xs):
 if len(xs)==1:yield xs[0];return
 for k in range(1,len(xs)):
  for l in parses(xs[:k]):
   for r in parses(xs[k:]):yield(l,r)
variants=[]
for k,normal in enumerate(parses([I4,I4,copy])):
 cond=(D4,((D4,(normal,CB)),CH))
 for retainpush in(0,1):
  n=(push,cond)if retainpush else cond
  t=s.replace(s.replace(a.old,'11010010111',n),'111',nipnew)
  name=f'mphalt_{k}_push{retainpush}';m=s.metrics(t);print(name,m,s.boundary(n),flush=True);variants.append((name,t,m))
for k,normal in enumerate(parses([I4,copy,('CI',1),I4])):
 cond=(D4,((D4,(normal,CB)),CH))
 for retainpush in(0,1):
  n=(push,cond)if retainpush else cond
  t=s.replace(s.replace(a.old,'11010010111',n),'111',nipnew)
  name=f'mphalt_alt{k}_push{retainpush}';m=s.metrics(t);print(name,m,s.boundary(n),flush=True);variants.append((name,t,m))
for name,t,m in variants:
 if m['dag_nodes']<=205:(a.O/(name+'.sites.json')).write_bytes(s.compact(s.sites(t)))
(a.O/'mphalt_prices.json').write_text(json.dumps([dict(name=n,metrics=m)for n,t,m in variants],indent=2))
