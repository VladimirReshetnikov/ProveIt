from pathlib import Path
import sys,json,time,hashlib
K=Path('/workspace/scratch/e33dac3aae74/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(K/'code/runtime-inputs'))
import validate_native as v
s=v.s
T=s.r.table(K/'k215.native.tm')
T[34,0]=(0,1,75)
for b in range(2):del T[50,b]
out=Path('/workspace/scratch/e33dac3aae74/encoding_work')
raw='#! start 0\n'+''.join(f'{q} {b} {w} {"L" if d==-1 else "R"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))
(out/'shortscan214.native.tm').write_text(raw)
m={int(k):int(w)for k,w in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in {q for q,b in T}|{254}:m.setdefault(q,q+1000)
L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}
lemmas,blocks=s.prove_blocks(L)
ss=json.loads((K/'sites215.json').read_text());begun=time.monotonic();nc=0;fails=[];totalrules=0
for i,site in enumerate(ss):
 for pos in((False,True)if site[1]=='CD'else(False,)):
  try:
   ans=s.case(L,lemmas,site,pos);nc+=1;totalrules+=ans['symbolic_steps']
  except Exception as e:
   fails.append({'index':i,'site':site,'positive':pos,'reason':str(e)})
   print('FAIL',json.dumps(fails[-1]),flush=True)
   break
 if fails:break
 if(i+1)%1000==0:print('SITE',i+1,'CASES',nc,'SECONDS',time.monotonic()-begun,flush=True)
result={'proved_cases':nc,'failures':fails,'total_rules':totalrules,'seconds':time.monotonic()-begun,'hash':hashlib.sha256(raw.encode()).hexdigest()}
if not fails:
 st=v.startup(T,500000)
 result['startup']={k:val for k,val in st.items()if k not in['trace','one_cells']}
 if 'trace' in st:
  import gzip
  (out/'shortscan214.startup.json.gz').write_bytes(gzip.compress(json.dumps(st,separators=(',',':')).encode()))
(out/'shortscan214.result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2),flush=True)
