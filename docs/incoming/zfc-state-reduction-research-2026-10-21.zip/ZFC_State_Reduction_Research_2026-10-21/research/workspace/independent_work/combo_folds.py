from pathlib import Path
import json,itertools,time
ns={};src=Path('independent_work/rotation_fold_search.py').read_text();exec(src[:src.index('records=[];')],ns)
T,folds=ns['T'],ns['folds'];recs=json.loads(Path('independent_work/rotation_results.json').read_text());patches=[]
for rec in recs:
 q,r,d=rec['q'],rec['r'],rec['direction']
 if d=='left':
  qa,rb,rc=T[q,0][2],T[r,0][2],T[r,1][2]
  patch={(q,0):(0,1,r),(q,1):(1,1,rc),(r,0):(0,1,qa),(r,1):(1,1,rb)}
 else:
  ra,rb,qc=T[r,0][2],T[r,1][2],T[q,1][2]
  patch={(q,0):(0,1,ra),(q,1):(1,1,r),(r,0):(0,1,rb),(r,1):(1,1,qc)}
 patches.append(patch)
ans=[];t0=time.monotonic();count=0
for k in(2,3,4):
 for ids in itertools.combinations(range(len(recs)),k):
  keys=[q for i in ids for q in(recs[i]['q'],recs[i]['r'])]
  if len(set(keys))!=len(keys):continue
  N=dict(T)
  for i in ids:N.update(patches[i])
  fs=folds(N);count+=1
  if fs:
   z={'rotations':[recs[i]for i in ids],'folds':fs};ans.append(z);print('FOUND',json.dumps(z),flush=True)
   Path('independent_work/combo-found.json').write_text(json.dumps(ans,indent=2))
   if len(ans)>=10:raise SystemExit
  if count%1000==0:print('PROGRESS',k,count,round(time.monotonic()-t0,2),flush=True)
 print('LEVEL',k,count,round(time.monotonic()-t0,2),flush=True)
print('DONE',count,len(ans),round(time.monotonic()-t0,2),flush=True)
