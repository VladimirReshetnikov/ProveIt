from pathlib import Path
from functools import lru_cache
from collections import Counter
import sys,json,time,hashlib
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code'));import source_language as s
oldrows=json.loads((p/'sites215.json').read_text());old=s.tree(oldrows);cfg=s.graph_intervals(oldrows);N=len(oldrows)
@lru_cache(None)
def replaceall(n,old,new):
 if n==old:return new
 if s.leaf(n):return n
 return replaceall(n[0],old,new),replaceall(n[1],old,new)
def retag(root):
 rows=s.sites(root);interval={};ix=0
 def rec(n,p):
  nonlocal ix
  start=ix
  if s.leaf(n):ix+=1
  else:rec(n[0],p+'0');rec(n[1],p+'1')
  interval[p]=(start,ix)
 rec(root,'')
 changes=[]
 for i,(p,op,arg)in enumerate(rows):
  if op in('CI','CH'):continue
  edge='1'if op=='CC'else'0';targets=[]
  for j in range(len(p)-1,-1,-1):
   if p[j]==edge:targets.append(interval[p[:j]][0]if edge=='1'else interval[p[:j]][1]%N)
  targets.append(0)
  want=cfg[i][1][0]
  if op=='CD':
   if targets[0]!=want:return None,None
  else:
   if targets[min(arg-1,len(targets)-1)]!=want:
    ks=[k+1 for k,t in enumerate(targets)if t==want]
    if not ks:return None,None
    k=ks[0];changes.append([i,op,arg,k]);rows[i][2]=k
 return s.tree(rows),changes
nodes={};
def allnodes(n,p=''):
 if s.leaf(n):return
 nodes.setdefault(n,[]).append(p);allnodes(n[0],p+'0');allnodes(n[1],p+'1')
allnodes(old)
engine=None;allocator=None;receipts=[];valid=0;t0=time.monotonic()
def score(n):
 rows=s.sites(n);m=s.metrics(n);critical=sum(op in('CI','CD')and p.endswith('000000')for p,op,arg in rows)
 return m,critical
for no,(node,paths)in enumerate(nodes.items()):
 for way in('left','right'):
  side=1 if way=='left'else 0
  if s.leaf(node[side]):continue
  if way=='left':a,(bb,c)=node;new=((a,bb),c)
  else:(a,bb),c=node;new=(a,(bb,c))
  raw=replaceall(old,node,new);out,changed=retag(raw)
  if out is None:continue
  valid+=1;m,critical=score(out)
  if m['dag_nodes']<=202 or (m['dag_nodes']<=204 and critical==0):
   rows=s.sites(out)
   assert s.graph_intervals(rows)==cfg
   try:arith,_=s.graph_arithmetic(rows);assert arith==cfg
   except Exception:continue
   rec={'index':no,'way':way,'paths':paths,'retags':changed,'metrics':m,'critical':critical}
   receipts.append(rec);print(json.dumps(rec),flush=True)
   stem=Path(f'independent_work/openrot-{no}-{way}')
   stem.with_suffix('.sites.json').write_bytes(s.compact(rows))
   if allocator is None:
    sys.path.insert(0,str(Path('encoding_work').resolve()));import permute_allocate as allocator
    engine={tuple(x)for x in json.loads(Path('encoding_work/engine_rows219_repaired.json').read_text())['rows']}
   info,table,tree=allocator.tryperm(tuple(range(9)),engine,3,new_override=out)
   rec['allocation']=info;print('ALLOC',no,way,json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True)
   if table:
    stem.with_suffix('.native.tm').write_bytes(allocator.b.table_bytes(table))
   stem.with_suffix('.json').write_text(json.dumps(rec,indent=2))
   if info.get('states',999)<=214:
    print('FOUND',no,way,info['states'],flush=True)
    Path('independent_work/openrot-found.json').write_text(json.dumps(rec,indent=2));raise SystemExit
 print('PROGRESS',no,len(nodes),valid,len(receipts),round(time.monotonic()-t0,2),flush=True)if no%50==0 else None
Path('independent_work/openrot_results.json').write_text(json.dumps(receipts,indent=2));print('DONE',valid,len(receipts),time.monotonic()-t0)
