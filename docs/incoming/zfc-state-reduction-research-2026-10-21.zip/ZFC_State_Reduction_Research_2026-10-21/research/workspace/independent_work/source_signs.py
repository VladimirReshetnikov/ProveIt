#!/usr/bin/env python3
"""Inductive finite abstraction of counter source values: {0},{1},{>=2}."""
import sys,json,collections,gzip
from pathlib import Path
sys.path.insert(0,'independent_work');import macro_audit as a
r=json.load(open(a.BASE/'sites215.json'));g=a.s.graph_intervals(r);n=len(r)
inv=[None]*n;inv[0]=[4]+[1]*8;todo=collections.deque([0]);queued={0};updates=0

def inc(m):return (2 if m&1 else 0)|(4 if m&6 else 0)
def dec(m):return (1 if m&2 else 0)|(6 if m&4 else 0)
while todo:
 i=todo.popleft();queued.discard(i);v=inv[i];p,o,k=r[i];out=[]
 if o=='CD':
  if v[k]&1:w=v.copy();w[k]=1;out.append((g[i][1][0],w))
  if v[k]&6:w=v.copy();w[k]=dec(v[k]);out.append((g[i][1][1],w))
 elif o=='CI':w=v.copy();w[k]=inc(v[k]);out.append((g[i][1][0],w))
 else:out=[(j,v)for j in g[i][1]]
 for j,w in out:
  new=w.copy() if inv[j] is None else [x|y for x,y in zip(inv[j],w)]
  if new!=inv[j]:
   inv[j]=new;updates+=1
   if j not in queued:queued.add(j);todo.append(j)
# Independent closure replay.
for i,v in enumerate(inv):
 if v is None:continue
 p,o,k=r[i];out=[]
 if o=='CD':
  if v[k]&1:w=v.copy();w[k]=1;out.append((g[i][1][0],w))
  if v[k]&6:w=v.copy();w[k]=dec(v[k]);out.append((g[i][1][1],w))
 elif o=='CI':w=v.copy();w[k]=inc(v[k]);out.append((g[i][1][0],w))
 else:out=[(j,v)for j in g[i][1]]
 for j,w in out:assert inv[j] is not None and all(x&~y==0 for x,y in zip(w,inv[j]))
print({'updates':updates,'reachable_sites':sum(v is not None for v in inv),'restricted_coordinates':sum(sum(x!=7 for x in v)for v in inv if v is not None)})
for i in [0,26,1545,2829]:print(i,r[i],inv[i])
Path('independent_work/source-sign-invariant.json.gz').write_bytes(gzip.compress(json.dumps(inv,separators=(',',':')).encode(),mtime=0))
