#!/usr/bin/env python3
"""Decode literal structured-counter source by archived Coq macro CFGs.
This module does not consult a Turing-machine decoder or a proposed macro map.
Only commuting adjacent increments with no external entry are normalized.
"""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(BASE/'code'));import source_language as s
text=(ROOT/'formalism_work/Dag254.v').read_text();nodes={}
for m in re.finditer(r'^\s*\| (\d+) => \(([^,]+), ([^)]+)\)',text,re.M):nodes[int(m[1])]=(m[2],m[3])
def expand(e):
 p=e.split();n=p[0];a=int(p[1])if len(p)>1 else None
 if n=='ENode':return tuple(expand(c)for c in nodes[a])
 return ({'EInc':'CI','EDecnz':'CD','EBreak':'CB','EContinue':'CC','EHalt':'CH'}[n],a)
def local_graph(rows):
 n=len(rows);bounds={}
 for i,(p,o,a)in enumerate(rows):
  for j in range(len(p)+1):
   pref=p[:j]
   if pref not in bounds:bounds[pref]=[i,i+1]
   else:bounds[pref][1]=i+1
 def target(p,b,k):
  hits=[j for j,c in enumerate(p)if c==b]
  if len(hits)<k:raise ValueError(('open macro',p,b,k))
  lo,hi=bounds[p[:hits[-k]]];return hi if b=='0'else lo
 out=[]
 for i,(p,o,a)in enumerate(rows):
  e=['increment',a]if o=='CI'else['decrement',a]if o=='CD'else['halt']if o=='CH'else['identity']
  ts=[i+1]if o=='CI'else[target(p,'0',1),i+1]if o=='CD'else[target(p,'0',a)]if o=='CB'else[target(p,'1',a)]if o=='CC'else[]
  out.append([e,ts])
 return out
def normalize(g):
 g=json.loads(json.dumps(g));n=len(g);i=0
 while i<n:
  if g[i][0][0]!='increment':i+=1;continue
  j=i+1
  while j<n and g[j][0][0]=='increment':j+=1
  for k in range(i,j):
   if g[k][1]!=[k+1]:raise ValueError('nonlinear increment run')
  for k in range(i+1,j):
   if {z for z,(_,ts)in enumerate(g)if k in ts}!={k-1}:raise ValueError('external entry inside increment run')
  for k,a in zip(range(i,j),sorted(g[k][0][1]for k in range(i,j))):g[k][0][1]=a
  i=j
 return g
macros={'par1':166,'par2':121,'par3':168,'I':119,'M':181,'Q':180,'E':182,'push':171,'F':177,'read1':175,'read2':176,'read3':174}
impl={name:s.sites(expand('ENode '+str(i)))for name,i in macros.items()}
mg={name:normalize(local_graph(rows))for name,rows in impl.items()}
profiles={name:tuple(o for p,o,a in rows)for name,rows in impl.items()}
def tokenize(rows):
 g,_=s.graph_arithmetic(rows)
 assert g==s.graph_intervals(rows)
 profile=tuple(o for p,o,a in rows);tokens=[];i=0
 while i<len(rows):
  matches=[]
  for name,pat in impl.items():
   k=len(pat)
   if profile[i:i+k]!=profiles[name]:continue
   h=[[e,[z-i for z in ts]]for e,ts in g[i:i+k]]
   try:h=normalize(h)
   except ValueError:continue
   if h==mg[name]:matches.append(name)
  if matches:
   name=max(matches,key=lambda name:len(impl[name]));k=len(impl[name]);tokens.append((i,name,k));i+=k
  else:
   p,o,a=rows[i];tokens.append((i,(o,a),1));i+=1
 return tokens,g

def evaluate(tokens,top='T',stack=None,params=None):
 stack=list(stack or ['W']);params=dict(params or {'par1':'A','par2':'B','par3':'C'})
 for i,name,k in tokens:
  if name in params:stack.insert(0,top);top=params[name]
  elif name in ('F','push'):stack.insert(0,top);top=1 if name=='F' else 0
  elif name in ('I','M','Q','E'):top=(name,stack.pop(0),top)
  else:raise ValueError(('nonconstructor',i,name))
 return top,stack
if __name__=='__main__':
 path=Path(sys.argv[1])if len(sys.argv)>1 else BASE/'sites215.json'
 rows=json.loads(path.read_text());tokens,g=tokenize(rows)
 print(json.dumps({'path':str(path),'metrics':s.metrics(s.tree(rows)),'tokens':tokens},indent=2))
