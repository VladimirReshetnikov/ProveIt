"""Derived symbolic primitive verifier; relaxes only inessential spare/gap data.
Uses baseline literal and independently proved list-induction steps.  It checks
primary-register affine values exactly, along with the source program counter,
then proves the rest is a finite nonempty list of well-formed B(v) blocks.
"""
from pathlib import Path
import sys,json
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code/runtime-inputs'));import validate_native as v
s=v.s

def postcondition(state,successor,physical):
 key=state.key()
 if state.direction!=1 or state.left!=s.normal([s.bit(1),s.BLANK]):return False
 a=list(state.right)
 def consume_bit(b):
  if not a or a[0][:2]!=('run',b) or a[0][2][0]<1:return False
  n=s.minus1(a[0][2]);a[0]=s.run(b,n)
  if n==s.ZERO:a.pop(0)
  return True
 for b in successor:
  if not consume_bit(int(b)):return False
 # The gap is arbitrary but supplies at least64 bits total after the PC.
 if not a or a[0][:2]!=('run',0):return False
 gap=s.add(a.pop(0)[2],s.num(len(successor)-64))
 if not s.nonnegative(gap):return False
 if not consume_bit(1):return False
 for val in physical:
  if not consume_bit(0):return False
  if not a or a[0]!=s.run(1,s.add(val,s.num(1))):return False
  a.pop(0)
 count=0;lists=0
 while a and a[0]!=s.BLANK:
  if a[0][:2]==('list','B') and a[0][3] is False:
   lists+=1;a.pop(0);continue
  if not consume_bit(0):return False
  if not a or a[0][:2]!=('run',1) or not s.nonnegative(s.minus1(a[0][2])):return False
  a.pop(0);count+=1
 return len(a)==1 and a[0]==s.BLANK and count>0

def case(table,lemmas,site,positive,keep_trace=False):
 pc,op,arg=site
 values=[s.var(2+i)for i in range(9)]
 if op=='CD':values[arg]=s.add(s.num(1),values[arg])if positive else s.ZERO
 physical=[None]*9
 for i,j in enumerate(s.r.PHY):physical[j]=values[i]
 result=physical.copy()
 if op=='CI':
  result[s.r.PHY[arg]]=s.add(result[s.r.PHY[arg]],s.num(1));successor,overflow=s.r.inc(pc)
 elif op=='CD'and positive:
  result[s.r.PHY[arg]]=s.minus1(result[s.r.PHY[arg]]);successor,overflow=s.r.inc(pc)
 elif op in('CD','CB'):successor,overflow=s.r.inc(s.r.strip(pc,'0',arg if op=='CB'else 1))
 elif op=='CC':successor=s.r.strip(pc,'1',arg)
 elif op=='CH':successor=''
 else:raise AssertionError(site)
 state=s.State(96,[s.bit(1),s.BLANK],[s.bit(int(b))for b in pc]+[s.run(0,s.add(s.var(1),s.num(64-len(pc)))),s.bit(1)]+s.file_bits(physical))
 clock=s.ZERO;motion=s.ZERO;trace=[];rows=set()
 for count in range(4000):
  state.key()
  if count and ((op=='CH'and state.q==254)or(op!='CH'and state.q==96 and postcondition(state,successor,result))):
   assert op=='CH'or postcondition(state,successor,result),('Root postcondition failed',site,positive,state.key())
   assert s.nonnegative(clock)and clock[0]>0
   return {'symbolic_steps':count,'duration':clock,'rows':rows,'trace':trace,'spares':state.right}
  clock,motion,event=state.step(table,lemmas,clock,motion)
  if event[0]!='list':rows.add(event[1][:2])
  if keep_trace:trace.append(event)
 raise AssertionError(('No dispatcher return',site,positive,state.key()))
