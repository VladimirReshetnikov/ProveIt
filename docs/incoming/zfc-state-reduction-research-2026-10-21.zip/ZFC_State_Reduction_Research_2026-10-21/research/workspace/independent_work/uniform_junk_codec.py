#!/usr/bin/env python3
"""Uniform formula radix with unused residues interpreted as true junk formulas.
I=bP,M=bP+1,Q=bP+q,E=bP+e, with distinct residues.
"""
import sys,json,gzip,itertools,time
from pathlib import Path
from functools import cache
sys.path.insert(0,'encoding_work');import prefix_codec as p
s=p.s;d=p.d;I=p.I
out=Path('independent_work/uniform_junk');out.mkdir(exist_ok=True)
@cache
def nodes(n):
 if s.leaf(n):return frozenset()
 return nodes(n[0])|nodes(n[1])|{n}
@cache
def scale_change(n,inc):
 if n==d.S4:return(('CD',7),(inc,('CC',2)))
 if s.leaf(n):return n
 return scale_change(n[0],inc),scale_change(n[1],inc)
if __name__=='__main__':
 start=time.time();records=[];best=999;best6=999;count=0
 for q in [2,3,4]:
  for e in [3,4,5]:
   if q==e:continue
   for qs in range(len(p.increments(q))):
    for es in range(len(p.increments(e-2))):
     for ep in range(3 if e!=3 else 1):
      tagged=p.build({'I':(4,0),'M':(4,1),'Q':(4,q),'E':(4,e)},qs,es,ep)
      available=nodes(tagged)
      for b in range(max(q,e,4)+1,9):
       words=p.increments(b);costs=[len(nodes(w)-available)for w in words];lo=min(costs)
       for bs,(inc,cost)in enumerate(zip(words,costs)):
        if cost>lo:continue
        tr=scale_change(tagged,inc);count+=1;n=len(nodes(tr))+23;
        if n>max(best,best6):continue
        met=s.metrics(tr);info={'radix':b,'Q_tag':q,'E_tag':e,'Q_shape':qs,'E_shape':es,'E_position':ep,'scale_shape':bs,'metrics':met}
        if n<best or met['maximum_zero_run']<=6 and n<best6:
         best=min(best,n)
         if met['maximum_zero_run']<=6:best6=min(best6,n)
         records.append(info);print(json.dumps(info),flush=True)
         if n<=203:(out/'best.sites.json.gz').write_bytes(gzip.compress(s.compact(s.sites(tr)),mtime=0))
       scale_change.cache_clear()
      nodes.cache_clear()
 print(json.dumps({'count':count,'minimum':best,'minimum_zero6':best6,'seconds':time.time()-start}),flush=True)
 (out/'results.json').write_text(json.dumps({'minimum':best,'minimum_zero6':best6,'records':records,'count':count},indent=2))
