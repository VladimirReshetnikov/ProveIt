from pathlib import Path
import sys,json,time,functools
ROOT=Path(__file__).resolve().parents[1]
code=(ROOT/'independent_work/build_selfq.py').read_text().split('best=999;out=[];')[0]
ns={'__file__':str(ROOT/'independent_work/build_selfq.py')};exec(code,ns)
s=ns['s'];rc=ns['rc'];old=ns['old'];assoc=ns['assoc'];nodes=ns['nodes'];oldnodes=ns['oldnodes'];findmacro=ns['findmacro'];pairs=ns['pairs'];scales=ns['scales']
variants=set(ns['variants']);I=('CI',1);C6=('CI',6);C7=('CI',7)
move16=(('CD',1),(C6,('CC',2)));move17=(('CD',1),(C7,('CC',2)))
for pair in pairs:
 for scale4 in scales:
  # all closed parenthesizations; the same scale4 subtree is reused twice
  variants.update(assoc((move16,pair,scale4,move17,scale4,(I,I))))
  quad=scale4[1][0]
  for sixteen in assoc((quad,quad,quad,quad)):
   scale16=(('CD',7),(sixteen,('CC',2)))
   variants.update(assoc((move16,pair,scale16,(I,I))))
qbest=sorted(variants,key=lambda t:len(nodes(t)-oldnodes));mincost=len(nodes(qbest[0])-oldnodes)
qbest=[t for t in qbest if len(nodes(t)-oldnodes)<=mincost+1]
print('QVARIANTS',len(variants),'COST',mincost,'KEPT',len(qbest),flush=True)
pars1=findmacro(166);pars2=findmacro(121);equals=findmacro(182);implies=findmacro(119)
base=rc.replace(old,479,888,('CI',0));bt=s.tree(base);prefix=base[479][0]
assert base[479][1:]==['CI',0]
# Keep exact outside subtrees, without caching a large full-source node set
# separately for every trial.
spine=[];cur=bt;outside=set()
for digit in prefix:
 bit=int(digit);spine.append((bit,cur[1-bit]));outside.update(nodes(cur[1-bit]));cur=cur[bit]
def attach(node):
 seen=outside|set(nodes(node));t=node
 for bit,sibling in reversed(spine):
  t=(t,sibling)if bit==0 else(sibling,t);seen.add(t)
 return t,len(seen)
# Full node census includes new ancestor paths, making the cost exact.
best=999;answers={};count=0;start=time.monotonic()
for p1 in pars1:
 for p2 in pars2:
  for eq in equals:
   for imp in implies:
    for qself in qbest:
     for node in assoc((p1,p2,eq,p2,p1,eq,qself,imp)):
      tree,n=attach(node);count+=1
      if n<best:best=n;print('BEST',n,'seen',count,'seconds',round(time.monotonic()-start,3),flush=True)
      if n<=201:
       answers[tree]=(qself,node)
print('FINISH',count,'BEST',best,'ELIGIBLE',len(answers),'SECONDS',time.monotonic()-start,flush=True)
if not answers:
 # Keep the twenty best even if over201 for a fresh physical allocator.
 besttrees={}
 for qself in qbest:
  for node in assoc((pars1[0],pars2[0],equals[0],pars2[0],pars1[0],equals[0],qself,implies[0])):
   tree,n=attach(node)
   if n==best:besttrees[tree]=(qself,node)
 answers=besttrees
for num,(tree,(qself,node))in enumerate(sorted(answers.items(),key=lambda z:len(nodes(z[0])))[:30]):
 rows=s.sites(tree);met=s.metrics(tree);assert s.graph_arithmetic(rows)[0]==s.graph_intervals(rows)
 # Replay the generic source splice independently of the fast placeholder path.
 assert rows==rc.replace(old,479,888,node)
 path=ROOT/f'independent_work/r7-crossed-selfq-{num}-{met["dag_nodes"]}.sites.json';path.write_bytes(s.compact(rows))
 recipe={'old_span':[479,888],'replacement_macro':node,'selfq_macro':qself,'metrics':met,'selfq_new_nodes':len(nodes(qself)-oldnodes),'macro_leaf_count':len(s.sites(node))}
 path.with_name(path.name.replace('.sites.json','.recipe.json')).write_text(json.dumps(recipe,indent=2)+'\n')
 print('OUTPUT',path.name,met,flush=True)
