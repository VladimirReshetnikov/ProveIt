#!/usr/bin/env python3
"""Closed-region RePair grammar search with exact ordinal-CFG preservation."""
from pathlib import Path
import sys,json,random,itertools,time,bisect,collections
from functools import cache
import macro_audit as a
sys.path.insert(0,str(a.ROOT/'encoding_work'))
from replace_closed import replace
s=a.s
R=json.loads((a.BASE/'sites215.json').read_text());T=s.tree(R);G=s.graph_intervals(R)
LO,HI=479,2643
assert {j for i,(_,ts)in enumerate(G)if not LO<=i<HI for j in ts if LO<=j<HI}=={LO}
assert {j for i in range(LO,HI)for j in G[i][1]if not LO<=j<HI}=={HI}
@cache
def length(t):return 1 if s.leaf(t)else length(t[0])+length(t[1])
def extract(lo,hi):
 def prune(t,i=0):
  j=i+length(t)
  if j<=lo or hi<=i:return None
  if lo<=i and j<=hi:return t
  l=prune(t[0],i);r=prune(t[1],i+length(t[0]))
  return r if l is None else l if r is None else(l,r)
 t=prune(T);rows=s.sites(t);ints={}
 def spans(q,p='',i=0):
  if s.leaf(q):z=i,i+1
  else:l=spans(q[0],p+'0',i);r=spans(q[1],p+'1',l[1]);z=l[0],r[1]
  ints[p]=z;return z
 spans(t)
 for i,(p,o,k)in enumerate(rows):
  if o in('CB','CC'):
   edge='0'if o=='CB'else'1';want=G[lo+i][1][0]-lo;found=[];count=0
   for z in range(len(p)-1,-1,-1):
    if p[z]==edge:
     count+=1;v=ints[p[:z]][1]if edge=='0'else ints[p[:z]][0]
     if v==want:found.append(count)
   assert found,(lo,hi,i,p,o,want);rows[i][2]=min(found)
 t=(rows[0][1],rows[0][2])if len(rows)==1 else s.tree(rows);assert s.boundary(t)==(0,0,False)
 assert a.local_graph(rows)==[[e,[j-lo for j in ts]]for e,ts in G[lo:hi]],(lo,hi)
 return t
# A cut is prohibited by any nonlocal forward edge or crossing backedge.
diff=[0]*(len(R)+2)
for i,(e,ts)in enumerate(G):
 if not LO<=i<HI:continue
 for j in ts:
  x,y=(i+1,j)if j>i else(j+1,i+1)
  if x<y:diff[x]+=1;diff[y]-=1
cuts=[];n=0
for k in range(len(R)+1):
 n+=diff[k]
 if LO<=k<=HI and n==0:cuts.append(k)
assert cuts[0]==LO and cuts[-1]==HI
atoms=[extract(lo,hi)for lo,hi in zip(cuts,cuts[1:])]
# Build one stable canonical registry containing the baseline and all atoms.
I={};nodes=[];stats=[];masks=[];literal=[]
def code(t):
 key=t if s.leaf(t)else(code(t[0]),code(t[1]))
 if key not in I:
  z=len(nodes);I[key]=z;nodes.append(key);literal.append(t)
  if s.leaf(t):stats.append((0,0,0));masks.append(1<<z)
  else:
   x,y=key;dx,zx,lx=stats[x];dy,zy,ly=stats[y];stats.append((1+max(dx,dy),max(zx,zy,1+lx),1+lx));masks.append(masks[x]|masks[y]|(1<<z))
 return I[key]
baseline_id=code(T);baseline_mask=masks[baseline_id];seq=[code(t)for t in atoms]
# Obtain the literal outside frame using a unique placeholder instruction.
placeholder=(('CI',0),(('CI',0),('CI',0)));fr=s.tree(replace(R,LO,HI,placeholder));outside=set();frame_count=0;arm_path=None
@cache
def contains(t):return t==placeholder or(not s.leaf(t)and(contains(t[0])or contains(t[1])))
def scanframe(t,p=''):
 global frame_count,arm_path
 if t==placeholder:arm_path=p;return
 if contains(t):
  frame_count+=1;scanframe(t[0],p+'0');scanframe(t[1],p+'1')
 else:
  z=code(t);outside.add(z)
scanframe(fr)
fixed=0
for z in set(seq)|outside:fixed|=masks[z]
baseI=dict(I);baseNodes=list(nodes);baseStats=list(stats);baseMasks=list(masks);baseLiteral=list(literal)
print('GRAMMAR',{'atoms':len(atoms),'types':len(set(seq)),'fixed_nodes':fixed.bit_count(),'frame':frame_count,'arm_path':arm_path,'registry':len(nodes)},flush=True)
# Resetting the small registry each restart avoids retaining huge trial DAGs.
def run(seed,mode=0):
 rng=random.Random(seed);I=dict(baseI);nodes=list(baseNodes);stats=list(baseStats);masks=list(baseMasks);used=fixed;word=list(seq)
 def join(x,y):
  key=x,y
  if key not in I:
   z=len(nodes);I[key]=z;nodes.append(key);dx,zx,lx=stats[x];dy,zy,ly=stats[y];stats.append((1+max(dx,dy),max(zx,zy,1+lx),1+lx));masks.append(masks[x]|masks[y]|(1<<z))
  return I[key]
 def materialize(q):
  if q<len(baseLiteral):return baseLiteral[q]
  x,y=nodes[q];return materialize(x),materialize(y)
 rulecount=0
 trail=len(arm_path)-len(arm_path.rstrip('0'));rootbudget=6-trail
 while len(word)>1:
  occ=collections.defaultdict(list)
  for i in range(len(word)-1):occ[word[i],word[i+1]].append(i)
  opts=[]
  for (x,y),positions in occ.items():
   if 1+stats[x][2]>6:continue
   good=[];last=-2
   for p in positions:
    if p>last+1:good.append(p);last=p
   # A leading-zero-6 rule can appear only at the final suffix.
   if 1+stats[x][2]==6 and any(p+2<len(word)for p in good):continue
   if 0 in good and ((2<len(word) and 1+stats[x][2]>=rootbudget)or(2==len(word)and 1+stats[x][2]>rootbudget)):continue
   z=I.get((x,y));free=z is not None and bool(((used|baseline_mask)if mode>=5 else used)>>z&1)
   count=len(good)
   if count<2 and not free:continue
   score=count if free else count-1
   bias=0
   if mode==1:bias=(1 if z is not None else 0)*0.2
   elif mode==2:bias=-0.03*stats[x][2]
   elif mode==3:bias=-0.01*max(stats[x][0],stats[y][0])
   opts.append((score+bias,rng.random(),x,y,good,free))
  if not opts:break
  if seed==0:_,_,x,y,positions,free=max(opts,key=lambda z:(z[0],z[5],-z[2],-z[3]))
  else:
   opts.sort(reverse=True)
   if mode in (4,6):
    bound=opts[0][0]-1;near=[x for x in opts if x[0]>=bound];_,_,x,y,positions,free=rng.choice(near[:8])
   else:_,_,x,y,positions,free=opts[0]
  z=join(x,y);used|=masks[z];rulecount+=1;ps=set(positions);new=[];i=0
  while i<len(word):
   if i in ps:new.append(z);i+=2
   else:new.append(word[i]);i+=1
  word=new
 # No shared or free adjacent pair remains: every additional joining node is
 # new, barring coincident parses of already compacted atoms. We nevertheless
 # compute the true final union and verify the final literal source census.
 @cache
 def finish(i,j,budget):
  if j-i==1:return (stats[word[i]][0],word[i])if stats[word[i]][2]<=budget else None
  if budget<1:return None
  best=None
  # Balanced splits first, then all alternatives for minimum source depth.
  for k in sorted(range(i+1,j),key=lambda k:abs(2*k-i-j)):
   l=finish(i,k,budget-1);r=finish(k,j,6)
   if l is None or r is None:continue
   d=1+max(l[0],r[0]);candidate=d,k,l[1],r[1]
   if best is None or candidate[:2]<best[:2]:best=candidate
  if best is None:return None
  d,k,x,y=best;return d,join(x,y)
 trail=len(arm_path)-len(arm_path.rstrip('0'));res=finish(0,len(word),6-trail)
 if res is None:return None
 root=res[1];used|=masks[root];n=used.bit_count()+frame_count
 return n,materialize(root),{'seed':seed,'mode':mode,'rules':rulecount,'forest':len(word),'depth':res[0],'registry':len(nodes),'predicted_dag':n}
if __name__=='__main__':
 limit=int(sys.argv[1])if len(sys.argv)>1 else 500
 best=999;start=time.time();reports=[];out=a.ROOT/'independent_work/grammar';out.mkdir(exist_ok=True)
 for seed in range(limit):
  v=run(seed,seed%8)
  if v is None:continue
  n,t,info=v
  if n<=best:
   rr=replace(R,LO,HI,t);m=s.metrics(s.tree(rr));assert m['dag_nodes']==n,(n,m,info)
   if n<best:
    best=n;info['metrics']=m;print('BEST',best,info,'elapsed',round(time.time()-start,2),flush=True)
    (out/'best.sites.json').write_bytes(s.compact(rr));(out/'best-recipe.json').write_text(json.dumps(info,indent=2));reports.append(info)
  if seed%25==0:print('PROGRESS',seed,best,round(time.time()-start,2),flush=True)
 (out/'search.json').write_text(json.dumps({'best':best,'restarts':limit,'improvements':reports,'seconds':round(time.time()-start,2)},indent=2))
 print('DONE',best,round(time.time()-start,2),flush=True)
