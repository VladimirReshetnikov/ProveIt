#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <algorithm>
#include <chrono>
#include <sstream>
struct Row {int w,d,q;};
struct Config {std::array<unsigned char,1024> a{};int q=84,h=256;};
std::array<std::array<Row,2>,400>T;
std::vector<int>Q;
int PHY[9]={6,2,0,4,3,8,7,5,1};
struct Probe {Config initial;std::string succ;std::array<int,9> result;int steps;};
bool post(const Config&c,const Probe&p){
 int h=c.h;
 if(h<5||h>512||!c.a[h-1])return false;
 for(int i=0;i<h-1;i++)if(c.a[i])return false;
 for(char b:p.succ){if(c.a[h++]!=b-'0')return false;}
 int k=h;while(k<1000&&!c.a[k])k++;
 if(k-c.h<64)return false;
 k++;
 for(int val:p.result){if(k>=1000||c.a[k++])return false;int n=0;while(k<1000&&c.a[k]){n++;k++;}if(n!=val+1)return false;}
 int count=0;
 while(k<1000){
  if(c.a[k])return false;
  if(!c.a[k+1])break;
  k++;while(k<1000&&c.a[k])k++;count++;
 }
 if(!count)return false;
 for(;k<1024;k++)if(c.a[k])return false;
 return true;
}
Probe probe(std::string pc,int op,int arg,bool pos,int variant){
 Probe p;int h=p.initial.h;
 p.initial.a[h-1]=1;
 for(char b:pc)p.initial.a[h++]=b-'0';
 h=p.initial.h+65+variant%3;p.initial.a[h++]=1;
 std::array<int,9>logical{};
 if(variant)for(int i=0;i<9;i++)logical[i]=(i*3+variant)%5;
 if(op==1)logical[arg]=pos?1+(variant%3):0;
 for(int i=0;i<9;i++)p.result[PHY[i]]=logical[i];
 for(int val:p.result){p.initial.a[h++]=0;for(int j=0;j<=val;j++)p.initial.a[h++]=1;}
 for(int z=0;z<=variant%3;z++){p.initial.a[h++]=0;for(int j=0;j<=1+variant%4;j++)p.initial.a[h++]=1;}
 if(op==0)p.result[PHY[arg]]++;
 if(op==1&&pos)p.result[PHY[arg]]--;
 if(op==1&&!pos){auto z=pc.find_last_of('0');pc=pc.substr(0,z);}
 int j=pc.size()-1;for(;j>=0&&pc[j]=='1';j--);p.succ=pc.substr(0,j)+"1";if(j<0)p.succ="";
 for(p.steps=0;p.steps<10000;p.steps++){
  Config &c=p.initial;
  if(c.q==66)break;
  Row r=T[c.q][c.a[c.h]];c.a[c.h]=r.w;c.h+=r.d;c.q=r.q;
 }
 if(p.steps>=10000){std::cerr<<"no66\n";exit(2);}
 return p;
}
bool test(const Probe&p,Row zero,Row one){
 Config c=p.initial;
 for(int i=0;i<3000;i++){
  if(c.q==84&&post(c,p))return true;
  if(c.h<1||c.h>1000||c.q==198||c.q==254)return false;
  int bit=c.a[c.h];Row r=c.q==66?(bit?one:zero):T[c.q][bit];
  c.a[c.h]=r.w;c.h+=r.d;c.q=r.q;
 }
 return false;
}
int main(int argc,char**argv){
 std::ifstream f(argv[1]);std::string line;
 while(std::getline(f,line)){if(line.empty()||line[0]=='#')continue;std::istringstream ss(line);int q,b,w,z;char d;ss>>q>>b>>w>>d>>z;T[q][b]={w,d=='R'?1:-1,z};if(!b&&q!=198)Q.push_back(q);}
 std::vector<Row>rows;for(int w:{0,1})for(int d:{-1,1})for(int q:Q)rows.push_back({w,d,q});
 std::vector<Probe> ps;
 ps.push_back(probe("000",1,8,true,0));ps.push_back(probe("01010",0,8,false,0));ps.push_back(probe("000",1,8,false,0));
 for(int variant:{1,2,3}){ps.push_back(probe("000",1,8,true,variant));ps.push_back(probe("01010",0,8,false,variant));ps.push_back(probe("000",1,8,false,variant));}
 int original0=0,original1=0;for(int i=0;i<(int)rows.size();i++){if(rows[i].w==1&&rows[i].d==1&&rows[i].q==198)original0=i;if(rows[i].w==1&&rows[i].d==-1&&rows[i].q==54)original1=i;}
 std::vector<int>count(ps.size()+1,0);auto start=std::chrono::steady_clock::now();
 for(int b=0;b<(int)rows.size();b++){
  for(int a=0;a<(int)rows.size();a++){
   int n=0;for(const auto&p:ps){if(!test(p,rows[a],rows[b]))break;n++;}count[n]++;
   if(n>=3)std::cout<<"PARTIAL "<<rows[a].w<<" "<<rows[a].d<<" "<<rows[a].q<<" / "<<rows[b].w<<" "<<rows[b].d<<" "<<rows[b].q<<" PROBES "<<n<<std::endl;
  }
  if(b%100==0)std::cerr<<"PROGRESS "<<b<<" "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;
 }
 for(int i=0;i<(int)count.size();i++)std::cout<<"COUNT "<<i<<" "<<count[i]<<std::endl;
}
