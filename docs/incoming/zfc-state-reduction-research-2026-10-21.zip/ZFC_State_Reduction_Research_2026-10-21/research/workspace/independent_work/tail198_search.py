from pathlib import Path
import sys,json,time,signal,collections
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code/runtime-inputs'));import validate_native as v
s=v.s;T=s.r.table(p/'k215.native.tm');sites=json.loads((p/'sites215.json').read_text());Q=sorted({q for q,a in T})
m={int(k):int(w)for k,w in json.loads(v.MAPPATH.read_text()).items()}
for q in set(Q)|{254}:m.setdefault(q,q+1000)
def timeout(*_):raise TimeoutError('timeout')
signal.signal(signal.SIGALRM,timeout)
def chk(L,lem,site,pos,app):
 try:
  signal.setitimer(signal.ITIMER_REAL,0.12)
  z=s.case(L,lem,site,pos,append=app)
  signal.setitimer(signal.ITIMER_REAL,0)
  return True
 except Exception:signal.setitimer(signal.ITIMER_REAL,0);return False
# ensure different early registers and CB/CC depths get quick coverage
ci=[x for x in sites if x[1]=='CI'];cd=[x for x in sites if x[1]=='CD'];branch=[x for x in sites if x[1]in('CB','CC')]
ci=list({x[2]:x for x in ci}.values());cd=list({x[2]:x for x in cd}.values());branch=list({(x[1],x[2]):x for x in branch}.values())
print('PROBES',ci,cd,branch,flush=True)
results=[];t0=time.monotonic()
for w in(0,1):
 for d in(-1,1):
  for q in Q:
   if q==198:continue
   N={k:row for k,row in T.items()if k[0]!=198};N[66,0]=(w,d,q)
   L={(m[a],b):(x,y,m[c])for(a,b),(x,y,c)in N.items()}
   try:lem,_=s.prove_blocks(L)
   except Exception:continue
   apps=[a for a in(None,0,1,2)if chk(L,lem,ci[0],False,a)]
   if not apps:continue
   nr=0
   for site in cd:
    if not chk(L,lem,site,False,1):break
    nr+=1
   rec={'row':N[66,0],'app':apps,'zero_cd':nr};print('PARTIAL',rec,flush=True);results.append(rec)
   if nr<len(cd):continue
   app=apps[0]
   for site in ci[1:]:
    if not chk(L,lem,site,False,app):break
   else:
    for site in cd:
     if not chk(L,lem,site,True,1):break
    else:
     for site in branch:
      if not chk(L,lem,site,False,1):break
     else:
      name=f'independent_work/tail198-{w}{d}{q}.native.tm';Path(name).write_text('#! start 0\n'+''.join(f'{a} {b} {x} {"R"if y==1 else"L"} {c}\n'for(a,b),(x,y,c)in sorted(N.items())));print('FOUND',name,app,flush=True)
print('DONE',time.monotonic()-t0,results,flush=True)
Path('independent_work/tail198_search.json').write_text(json.dumps(results,indent=2))
