#!/usr/bin/env python3
"""Enumerate exact-CFG local parses of alternative arithmetic kernels."""
import json,sys,itertools,time
from pathlib import Path
from functools import cache
import macro_audit as a
s=a.s
j=json.load(open(a.ROOT/'independent_work/exponential-pair-info.json'))
def tuplify(t):return tuple(tuplify(x)for x in t)if isinstance(t,list)else t
newnodes={k:tuplify(v)for k,v in j['new_arithmetic'].items()}
oldnodes={k:tuplify(v)for k,v in j['old_arithmetic'].items()}
old=s.tree(json.loads((a.BASE/'sites215.json').read_text()))
@cache
def shapes(lo,hi):
 if hi-lo==1:return(lo,)
 return tuple((a,b)for k in range(lo+1,hi)for a in shapes(lo,k)for b in shapes(k,hi))
def variants(t):
 rows=s.sites(t);g=a.local_graph(rows);n=len(rows);out=[]
 for shape in shapes(0,n):
  paths={};intervals={}
  def fill(q,p=''):
   if isinstance(q,int):paths[q]=p;z=q,q+1
   else:l=fill(q[0],p+'0');r=fill(q[1],p+'1');z=l[0],r[1]
   intervals[p]=z;return z
  fill(shape);ops=[];ok=True
  for i,(p0,o,k0)in enumerate(rows):
   p=paths[i];k=k0
   if o=='CD':
    z=p.rfind('0')
    if z<0 or intervals[p[:z]][1]!=g[i][1][0]:ok=False;break
   elif o in ('CB','CC'):
    edge='0'if o=='CB'else'1';want=g[i][1][0];count=0;k=None
    for q in range(len(p)-1,-1,-1):
     if p[q]==edge:
      count+=1;got=intervals[p[:q]][1]if edge=='0'else intervals[p[:q]][0]
      if got==want:k=count;break
    if k is None:ok=False;break
   ops.append((o,k))
  if ok:
   def build(q):return ops[q]if isinstance(q,int)else(build(q[0]),build(q[1]))
   z=build(shape)
   if s.boundary(z)==(0,0,False):out.append(z)
 return tuple(out)
vs={k:variants(v)for k,v in newnodes.items()}
print('VARIANTS',{k:len(v)for k,v in vs.items()},flush=True)
def finger(t):
 try:return json.dumps(a.normalize(a.local_graph(s.sites(t))),sort_keys=True)
 except(ValueError,AssertionError):return None
fingers={finger(v):k for k,v in oldnodes.items()};matched={};seen=set()
def scan(t):
 if t in seen:return
 seen.add(t)
 if s.leaf(t):return
 if len(s.sites(t))in(8,10):
  f=finger(t)
  if f in fingers:matched[t]=fingers[f]
 scan(t[0]);scan(t[1])
scan(old)
# Hash-cons integer IDs make whole-source DAG census cheap.
intern={};trees={}
def code(t):
 key=t if s.leaf(t)else(code(t[0]),code(t[1]))
 if key not in intern:z=len(intern);intern[key]=z;trees[z]=t
 return intern[key]
def pair(x,y):
 k=x,y
 if k not in intern:z=len(intern);intern[k]=z;trees[z]=trees[x],trees[y]
 return intern[k]
vids={k:[code(v)for v in arr]for k,arr in vs.items()}
@cache
def skeleton(t):
 if t in matched:return matched[t]
 if s.leaf(t):return code(t)
 return skeleton(t[0]),skeleton(t[1])
sk=skeleton(old)
def rebuild(selection):
 memo={}
 def go(t):
  if isinstance(t,int):return t
  if isinstance(t,str):return vids[t][selection[t]]
  if t not in memo:memo[t]=pair(go(t[0]),go(t[1]))
  return memo[t]
 q=go(sk);seen=set()
 def visit(z):
  if z in seen:return
  seen.add(z);t=trees[z]
  if not s.leaf(t):visit(code(t[0]));visit(code(t[1]))
 visit(q)
 return len(seen),q
names=list(vs);chosen={k:0 for k in names};records=[]
for turn in range(4):
 changed=False
 for k in names:
  opts=[]
  for i in range(len(vs[k])):
   pick=chosen|{k:i};n,q=rebuild(pick);opts.append((n,i,q))
  n,i,q=min(opts);changed|=chosen[k]!=i;chosen[k]=i
  print('COORD',turn,k,n,i,flush=True)
 if not changed:break
# Keep near-best alternatives for a joint search.
short={}
for k in names:
 opts=[]
 for i in range(len(vs[k])):
  n,q=rebuild(chosen|{k:i});opts.append((n,i))
 best=min(n for n,i in opts);short[k]=[i for n,i in sorted(opts)if n<=best+1][:30]
print('SHORT',{k:len(v)for k,v in short.items()},flush=True)
best=999;bestroot=None;bestsel=None;count=0
for ix in itertools.product(*(short[k]for k in names)):
 sel=dict(zip(names,ix));n,q=rebuild(sel);count+=1
 if n<best:
  best=n;bestroot=q;bestsel=sel;print('BEST',best,bestsel,flush=True)
t=trees[bestroot];out=a.ROOT/'independent_work';(out/'exponential-pair-optimized.sites.json').write_bytes(s.compact(s.sites(t)))
info={'best_DAG':best,'selection':bestsel,'variant_counts':{k:len(v)for k,v in vs.items()},'joint_count':count,'metrics':s.metrics(t),'arithmetic':{k:vs[k][bestsel[k]]for k in names},'scope':'Experimental alternative pairing. Exact local CFG preserved for chosen arithmetic macros. Global mathematical calibration and binary allocation not proved.'}
(out/'exponential-pair-optimized.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2),flush=True)
