from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import sys,json,time
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code'));import build221 as b,source_language as s
T=b.read_table((p/'k215.native.tm').read_bytes());root=s.tree(json.loads((p/'sites215.json').read_text()));groups,ps=b.decoder_map(T,root)
oldroles=defaultdict(set);leafacts=defaultdict(set)
for q,ns in groups.items():
 for n in ns:
  oldroles[n].add(q)
  for bit,ch in enumerate(n):
   if s.leaf(ch):leafacts[ch,bit].add(T[q,bit])
@lru_cache(None)
def replaceall(n,old,new):
 if n==old:return new
 if s.leaf(n):return n
 return replaceall(n[0],old,new),replaceall(n[1],old,new)
oldcfg=s.graph_intervals(s.sites(root));oldword=[x[1:] for x in s.sites(root)]
def folds(N):
 incoming=defaultdict(list)
 for(q,x),(w,d,z)in N.items():incoming[z].append((q,x,w,d))
 def ib(q):
  a=incoming[q];b=a[0][1]if a else None
  return b if a and all(x==w==b and d==1 for z,x,w,d in a)else None
 Q=sorted({q for q,b in N});out=[]
 for a in(0,1):
  for iq,q in enumerate(Q):
   for r in Q[iq+1:]:
    if N[q,1-a]!=N[r,1-a]or N[q,a][:2]!=(a,1)or N[r,a][:2]!=(a,1):continue
    bq,br=ib(q),ib(r)
    if bq is None or br is None or bq==br:continue
    want={bq:N[q,a][2],br:N[r,a][2]}
    # Need provider reading marker at -1; known endpointa at0.
    for h in Q:
     good=True;used=set()
     for marker in(0,1):
      tape={-1:marker,0:a};pos=-1;state=h
      for steps in range(32):
       if pos==1 and state==want[marker] and tape=={-1:marker,0:a}:break
       if pos not in tape or(state,tape[pos])not in N:good=False;break
       used.add(state);w,d,state=N[state,tape[pos]];tape[pos]=w;pos+=d
      else:good=False
      if not good:break
     if good and q not in used and r not in used:out.append((q,r,a,h))
 return out
records=[];t0=time.monotonic()
for q,ns in groups.items():
 if len(ns)!=1:continue
 n=next(iter(ns))
 if any(T[q,bit][:2]!=(bit,1) for bit in(0,1)):continue
 for direction in('left','right'):
  child=1 if direction=='left' else 0
  if s.leaf(n[child]):continue
  r=T[q,child][2]
  if groups.get(r)!= {n[child]} or any(T[r,bit][:2]!=(bit,1)for bit in(0,1)):continue
  if direction=='left':A,(B,C)=n;new=((A,B),C)
  else:(A,B),C=n;new=(A,(B,C))
  if s.leaf(B)or not all(s.boundary(x)==(0,0,False)for x in(A,B,C)):continue
  nr=replaceall(root,n,new);N=dict(T)
  if direction=='left':
   qa,rb,rc=T[q,0][2],T[r,0][2],T[r,1][2]
   N[q,0]=(0,1,r);N[q,1]=(1,1,rc);N[r,0]=(0,1,qa);N[r,1]=(1,1,rb)
  else:
   ra,rb,qc=T[r,0][2],T[r,1][2],T[q,1][2]
   N[q,0]=(0,1,ra);N[q,1]=(1,1,r);N[r,0]=(0,1,rb);N[r,1]=(1,1,qc)
  try:ng,np=b.decoder_map(N,nr)
  except Exception:continue
  roles=defaultdict(set)
  for node,qs in oldroles.items():roles[replaceall(node,n,new)].update(qs)
  roles[new].add(q);roles[new[1-child]].add(r)
  bad=[]
  for z,nodes in ng.items():
   for node in nodes:
    if z not in roles.get(node,()):bad.append((z,'role'))
   for path in np[z]:
    node=s.subtree(nr,path)
    for bit,ch in enumerate(node):
     if s.leaf(ch):
      if N[z,bit]not in leafacts[ch,bit]:bad.append((z,'leafentry'))
      if z==108 and bit==1 and not('1'+path+'1').endswith({'CC':'101','CB':'001'}[ch[0]]):bad.append((z,'108'))
  if bad:
   print('REJECT',q,r,direction,bad[:5],flush=True)
   continue
  assert [x[1:] for x in s.sites(nr)]==oldword and s.graph_intervals(s.sites(nr))==oldcfg
  fs=folds(N)
  # literal row-equivalent quotient option.
  buckets=defaultdict(list)
  for z in {z for z,_ in N}:buckets[N[z,0],N[z,1]].append(z)
  dup=[v for v in buckets.values()if len(v)>1]
  rec={'q':q,'r':r,'direction':direction,'source_paths':ps[q],'folds':fs,'literal_duplicates':dup,'metrics':s.metrics(nr)}
  records.append(rec);print(json.dumps(rec),flush=True)
  if fs or dup:
   stem=Path(f'independent_work/rotation-{q}-{r}-{direction}')
   stem.with_suffix('.tm').write_bytes(b.table_bytes(N));stem.with_suffix('.json').write_text(json.dumps(s.sites(nr)))
Path('independent_work/rotation_results.json').write_text(json.dumps(records,indent=2));print('DONE',len(records),time.monotonic()-t0)
