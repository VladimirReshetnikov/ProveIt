#!/usr/bin/env python3
"""Experimental positive-endpoint fixed-zero helper source layouts.
This is a source construction only; logical calibration is a separate task.
"""
import sys,json,itertools
from pathlib import Path
from functools import cache
import macro_audit as a
sys.path.insert(0,str(a.ROOT/'encoding_work'))
from replace_closed import replace
s=a.s
oldrows=json.loads((a.BASE/'sites215.json').read_text());old=s.tree(oldrows)
push=a.expand('ENode 171')
# Use the literal current PUSH subtree, which differs by harmless CI ordering.
seen=set();impl={}
def scan(t):
 if t in seen:return
 seen.add(t)
 if not s.leaf(t):
  if len(s.sites(t))==19:
   try:
    if a.normalize(a.local_graph(s.sites(t)))==a.mg['push']:impl['push']=t
   except (ValueError,AssertionError):pass
  scan(t[0]);scan(t[1])
scan(old);push=impl['push']
base_rows=replace(oldrows,643,723,push);base=s.tree(base_rows)
CI=('CI',1)
# Insert exactly one increment after each endpoint copy.
ends=[531,613,749-61,775-61]
def ends_at(rows,t,end):
 p=rows[end-1][0];res=[]
 for k in range(len(p),-1,-1):
  q=p[:k]
  if any(c!='1'for c in p[k:]):continue
  u=s.subtree(t,q)
  if s.boundary(u)==(0,0,False):res.append(q)
 return res
options=[ends_at(base_rows,base,j)for j in ends]
print('BASE',s.metrics(base),'OPTIONS',list(map(len,options)),flush=True)
# Disjoint insertion nodes are needed; nested nodes ending at different points
# can also be edited longest-path-first without shifting their paths.
best=999;records=[];out=a.ROOT/'independent_work/fixed_zero';out.mkdir(exist_ok=True)
@cache
def descendants(t):
 if s.leaf(t):return frozenset((t,))
 return descendants(t[0])|descendants(t[1])|{t}
for choices in itertools.product(*options):
 t=base
 for p in sorted(choices,key=len,reverse=True):t=s.replace(t,p,(s.subtree(t,p),CI))
 m=s.metrics(t);n=m['dag_nodes']
 if m['maximum_zero_run']>6:continue
 rec={'dag':n,'paths':choices,'metrics':m}
 if n<best:best=n;print('BEST',rec,flush=True)
 records.append((n,choices,m,t))
for j,(n,ps,m,t)in enumerate(sorted(records,key=lambda z:(z[0],z[2]['maximum_depth'],z[1]))[:12]):
 name=f'fixed-zero-endpoint-{j}-{n}'
 (out/(name+'.sites.json')).write_bytes(s.compact(s.sites(t)))
 (out/(name+'.recipe.json')).write_text(json.dumps({'dag':n,'paths':ps,'metrics':m},indent=2))
(a.ROOT/'independent_work/fixed-zero-results.json').write_text(json.dumps({'best':best,'layouts':len(records),'top':[{'dag':n,'paths':ps,'metrics':m}for n,ps,m,t in sorted(records,key=lambda z:z[0])[:30]]},indent=2))
print('DONE',best,len(records),flush=True)
