from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[1]
ns={'__file__':str(ROOT/'independent_work/build_selfq.py')};exec((ROOT/'independent_work/build_selfq.py').read_text().split('best=999;out=[];')[0],ns)
s=ns['s'];rc=ns['rc'];dc=ns['dc'];old=ns['old'];nodes=ns['nodes'];oldnodes=ns['oldnodes'];variants=ns['variants'];assoc=ns['assoc'];pairs=ns['pairs'];scales=ns['scales']
I=('CI',1);move16=(('CD',1),(('CI',6),('CC',2)));move17=(('CD',1),(('CI',7),('CC',2)))
for pair in pairs:
 for scale in scales:
  variants.update(assoc((move16,pair,scale,move17,scale,(I,I))))
  quad=scale[1][0]
  for sixteen in assoc((quad,quad,quad,quad)):
   scale16=(('CD',7),(sixteen,('CC',2)));variants.update(assoc((move16,pair,scale16,(I,I))))
variants=sorted(variants,key=lambda n:len(nodes(n)-oldnodes));variants=[n for n in variants if len(nodes(n)-oldnodes)<=6]
renamed=json.loads(json.dumps(old))
for lo,hi,src,dst in((479,505,3,4),(505,531,4,5),(723,749,4,5),(749,775,5,4)):
 for i in range(lo,hi):
  if renamed[i][1]in('CI','CD')and renamed[i][2]==src:renamed[i][2]=dst
best=999;results=[];start=time.monotonic()
for final in(834,861):
 base=dc.remove(renamed,[(561,723),(final,final+27)])
 for k,node in enumerate(variants):
  rows=rc.replace(base,643,672,node);tree=s.tree(rows);met=s.metrics(tree);n=met['dag_nodes']
  if n<best:best=n;print('BEST',final,k,met,'seconds',time.monotonic()-start,flush=True)
  results.append((n,final,k,met,rows,node))
print('DONE',len(results),'BEST',best,'SECONDS',time.monotonic()-start,flush=True)
for num,(n,final,k,met,rows,node)in enumerate(sorted(results,key=lambda r:r[0])[:20]):
 path=ROOT/f'independent_work/r7-crossed-local-{num}-{n}.sites.json';path.write_bytes(s.compact(rows));
 path.with_name(path.name.replace('.sites.json','.recipe.json')).write_text(json.dumps({'renamings':[[479,505,3,4],[505,531,4,5],[723,749,4,5],[749,775,5,4]],'deleted_spans':[[561,723],[final,final+27]],'replacement_after_deletion':[643,672],'selfq_macro':node,'metrics':met},indent=2)+'\n')
 print('OUTPUT',path.name,met,flush=True)
