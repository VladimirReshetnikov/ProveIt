#!/usr/bin/env python3
"""Price three prefix partitions by arithmetic progressions modulo3/6.
Every rewrite is a closed source subtree, preserving its enclosing control edges.
"""
import sys,json,gzip,os,itertools,time
from pathlib import Path
sys.path.insert(0,'encoding_work');import prefix_codec as p
s=p.s;a=p.a;d=p.d;I=p.I;rows=p.rows
out=Path('independent_work/ternary');out.mkdir(exist_ok=True)
sets=[{'I':(3,0),'M':(3,1),'Q':(6,2),'E':(6,5)},
      {'I':(3,0),'M':(6,1),'Q':(3,2),'E':(6,4)},
      {'I':(6,0),'M':(3,1),'Q':(3,2),'E':(6,3)}]
def build(tags,t3,t6,es,ep):
 tails={k:(d.P,(('CD',7),(v,('CC',2)))) for k,v in [(3,t3),(6,t6)]}
 edits={path:tails[tags[n][0]] for path,n in p.Fpaths.items()}
 for i,n,L in p.tokens:
  if n=='E' and tags['E'][1]!=3:
   edits[rows[i+27+ep][0]]=p.increments(tags['E'][1]-2)[es]
 def rec(n,path=''):
  if path in edits:return edits[path]
  if s.leaf(n):return n
  return rec(n[0],path+'0'),rec(n[1],path+'1')
 return rec(a.old)
if __name__=='__main__':
 recs=[];overall=999;best6=999
 for j,tags in enumerate(sets):
  best=999;best_local6=999;count=0;start=time.time()
  for i3,t3 in enumerate(p.increments(3)):
   for i6,t6 in enumerate(p.increments(6)):
    for ep in range(3 if tags['E'][1]!=3 else 1):
     for es in range(len(p.increments(tags['E'][1]-2))):
      tr=build(tags,t3,t6,es,ep);met=s.metrics(tr);n=met['dag_nodes'];count+=1
      inf={'tagset':j,'scale3_shape':i3,'scale6_shape':i6,'e_shape':es,'e_position':ep,'metrics':met}
      if n<best:best=n;print(json.dumps(inf),flush=True)
      if met['maximum_zero_run']<=6:best_local6=min(best_local6,n)
      if n<overall or met['maximum_zero_run']<=6 and n<best6:
       overall=min(overall,n)
       if met['maximum_zero_run']<=6:best6=min(best6,n)
       recs.append(inf)
       if n<=207:(out/'best.sites.json.gz').write_bytes(gzip.compress(s.compact(s.sites(tr)),mtime=0))
  print(json.dumps({'tagset':j,'count':count,'minimum':best,'minimum_zero6':best_local6,'seconds':time.time()-start}),flush=True)
 (out/'results.json').write_text(json.dumps({'tags':sets,'records':recs,'minimum':overall,'minimum_zero6':best6},indent=2))
