from pathlib import Path
import sys,json,gzip,collections,time,signal
def timeout(*_):raise TimeoutError("search screening timeout")
signal.signal(signal.SIGALRM,timeout)
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code/runtime-inputs'));import validate_native as v
s=v.s
T=s.r.table(p/'k215.native.tm');sites=json.loads((p/'sites215.json').read_text())
m={int(k):int(w) for k,w in json.loads(v.MAPPATH.read_text()).items()}
for q in {q for q,b in T}|{254}:m.setdefault(q,q+1000)
inv={z:q for q,z in m.items()}
cases=json.load(gzip.open(p/'verification/root-run1/runtime/runtime_cases.json.gz'))
uses=collections.defaultdict(list)
for i,c in enumerate(cases):
 for q,b in c['rows']:uses[inv[q],b].append(i)
opts=[]
Q=sorted({q for q,b in T})
for q in Q:
 for r in Q:
  if q==r or q==0:continue
  if T[q,0]==T[r,0] or T[q,1]==T[r,1] or (q,r)in((13,108),(108,13)):
   opts.append((q,r))
opts = [(13,108),(108,13)] + [(q,r) for q,r in opts if q>69 and (q,r)!=(108,13)]
ans=[]
for q,r in opts:
 N={(z,b):(w,d,r if t==q else t) for(z,b),(w,d,t)in T.items()if z!=q}
 L={(m[z],b):(w,d,m[t])for(z,b),(w,d,t)in N.items()}
 try:lemmas,_=s.prove_blocks(L)
 except Exception:continue
 used=set(uses[q,0]+uses[q,1]);todo=sorted(used,key=lambda i:cases[i]['symbolic_steps'],reverse=True)
 # Check maximal duration, then minimal duration, then every affected case.
 if len(todo)>1:todo=[todo[0],todo[-1]]+todo[1:-1]
 tested=0;started=time.monotonic();fail=None
 for i in todo:
  c=cases[i]
  try:
   signal.setitimer(signal.ITIMER_REAL,2)
   s.case(L,lemmas,sites[c['site_index']],c['positive'])
   signal.setitimer(signal.ITIMER_REAL,0)
  except Exception as e:
   signal.setitimer(signal.ITIMER_REAL,0)
   fail={'case':i,'message':str(e)[:180]};break
  tested+=1
 record={'drop':q,'keep':r,'tested':tested,'used':len(used),'seconds':round(time.monotonic()-started,3),'fail':fail}
 print(json.dumps(record),flush=True)
 ans.append(record)
 if fail is None:
  print('FOUND',record,flush=True)
  Path(f'independent_work/alias{q}_{r}.native.tm').write_text('#! start 0\n'+''.join(f'{z} {b} {w} {"R" if d==1 else "L"} {t}\n'for(z,b),(w,d,t)in sorted(N.items())))
Path('independent_work/alias_search.json').write_text(json.dumps(ans,indent=2))
