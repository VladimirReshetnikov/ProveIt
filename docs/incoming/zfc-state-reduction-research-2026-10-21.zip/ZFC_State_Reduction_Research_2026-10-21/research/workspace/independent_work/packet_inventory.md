# Independent search: final status and artifact index

No machine with at most 214 working states was validated in this branch. All state counts below are source DAG counts unless explicitly called machine states.

## Strong new checked invariant

`source_signs.py` computes the Cartesian abstraction of each register into 0, 1, or at least 2, starting from the actual startup register vector (4, 0, ..., 0). It independently replays every guarded transfer to check closure. The compressed certificate covers all 4751 literal source sites: 4748 are abstractly reachable, and 4672, 4673, 4734 are unreachable. It constrains 12447 register coordinates beyond the unrestricted mask.

Two deletions follow rigorously at source level. The MP-success transfer loop 4671..4674 reads a known-zero top register; deleting it gives 203 DAG nodes. The final halt comparison's clear-X tail 4733..4735 reads a known-zero X register; deleting it gives 204 nodes. Both deletions together give 205 nodes. Every variant retains maximum zero-run 6. The extra DAG cost comes from losing existing shared subtrees, despite fewer primitive occurrences.

## Exhaustive pair screen within a bounded semantic test

The C++ screen tests all 45,796 ordered identifications of one working state with another, excluding deletion of the dispatcher 84. It checks whole primitive results and permits an arbitrary valid nonempty spare suffix. Eleven aliases survive representative probes. Every survivor fails the attempted full 6,176-case, three-pattern screen. Repeating with only values compatible with the checked source invariant gives the same result. Each concrete attempt is capped at 50,000 steps; these are negative search receipts, not an impossibility proof.

Stronger finite tests at N=4 with forty spare registers equal to 1 still reject 153→184, 153→213, and 118→158. `semantic-stronger-frame-results.json` records the exact vectors and first-clean-dispatch times. Exact reachability of each counterexample vector is not claimed; a future correlated source invariant could be stronger than the present abstraction.

The proposed append-free edit 94/0=0L40 also fails a valid all-one-spare frame: site 0/CD8 with all primaries zero returns the wrong program counter and two altered primary registers. The full details appear in `packet_inventory.json`.

## Codec results and proof limits

The symmetric reserved-coordinate two-tag codec has minimum 216 DAG nodes, not 215. The ternary split family has minimum 209. Uniform radix 5 with unused junk residues gives 203 and zero-run 6; eleven minimal scale layouts across radices 5, 6, and 8 are listed in `uniform_junk/minimal-scale-layouts.json`. The retained-alias allocator does not allocate the best source. Constructor decoding and numerical bounds were checked, but a complete new finite-kernel/source/Rocq calibration was not rebuilt for these codecs.

The best tag permutation gives 203 nodes but zero-run 10 and uses a new Q-zero truth alias. E-zero permutations use ordinary finite syntax with code 0=E(0,0), but the inherited finite-kernel normalization receipt still needs re-instantiation. Neither is a calibrated replacement machine.

## Mathematical material worth retaining

`inequality-row-audit.tex` proves the new inequality-row reduction for arbitrary fresh binders, including asymmetric binders. `r7-source-audit.json` prevents the unsound omission of the canonical equality-vacuity helper. `gated-source-audit.json` independently checks the 205-node gated crossed-helper source. These are distinct from a claim of a smaller machine.

`packet_inventory.json` is the authoritative compact manifest, including hashes, exact masks, file paths, and qualification of each result. Large old uncompressed JSON intermediates were replaced by archival-pointer stubs; their full content remains in matching `.json.gz` files.
