import relaxed_tail as r,json
s=r.s;T=s.r.table(r.p/'k215.native.tm');m={int(k):int(v)for k,v in json.loads(r.v.MAPPATH.read_text()).items()}
for q in {q for q,b in T}|{254}:m.setdefault(q,q+1000)
T[66,0]=(1,-1,54)
L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()};lem,_=s.prove_blocks(L)
site=['000','CD',8];pc,op,arg=site;vals=[s.var(2+i)for i in range(9)];vals[arg]=s.ZERO;physical=[None]*9
for i,j in enumerate(s.r.PHY):physical[j]=vals[i]
state=s.State(96,[s.bit(1),s.BLANK],[s.bit(int(b))for b in pc]+[s.run(0,s.add(s.var(1),s.num(64-len(pc)))),s.bit(1)]+s.file_bits(physical));clock=s.ZERO;motion=s.ZERO
for count in range(1000):
 state.key()
 if count and state.q==96:
  print('root',count,state.direction,state.left,state.right[:12],flush=True)
 try:clock,motion,event=state.step(L,lem,clock,motion)
 except Exception as e:print('FAIL',count,str(e));break
