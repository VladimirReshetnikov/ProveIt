#!/usr/bin/env python3
"""Jointly permute parameters inside unrestricted logical rows R1--R6.
Each row's formula family is unchanged; the gate and theory bundle stay fixed.
"""
import json,itertools,time,sys
from pathlib import Path
from functools import cache
import macro_audit as a
s=a.s
path=a.ROOT/'formalism_work/gated_crossed/gated-r0c0e5j2-205.json'
rows=json.loads(path.read_text());old=s.tree(rows)
regions=[('R6',479,762),('R5',762,1058),('R4',1058,1357),('R3',1357,1653),('R2',1653,2003),('R1',2003,2234)]
perms=list(itertools.permutations((3,4,5)))
# Verify closed exact source intervals before treating each as independent.
g=s.graph_intervals(rows)
for name,lo,hi in regions:
 assert {t for i,(_,ts)in enumerate(g)if not lo<=i<hi for t in ts if lo<=t<hi}=={lo},name
 assert {t for i in range(lo,hi)for t in g[i][1]if not lo<=t<hi}=={hi},name
intern={};trees={};desc={}
def code(t):
 key=t if s.leaf(t)else(code(t[0]),code(t[1]))
 if key not in intern:
  z=len(intern);intern[key]=z;trees[z]=t
  desc[z]=(1<<z)if s.leaf(t)else desc[key[0]]|desc[key[1]]|(1<<z)
 return intern[key]
code(old)
@cache
def rename(t,p):
 if s.leaf(t):return(t[0],p[t[1]-3]if t[0]in('CI','CD')and t[1]in(3,4,5)else t[1])
 return rename(t[0],p),rename(t[1],p)
terminals=[];outside=0;rowmasks=[[0]*6 for r in regions]
def skeleton(t,lo=0):
 global outside
 hi=lo+len(s.sites(t))
 for r,(name,a0,b0)in enumerate(regions):
  if a0<=lo and hi<=b0:
   ids=[]
   for p,perm in enumerate(perms):
    z=code(rename(t,perm));ids.append(z);rowmasks[r][p]|=desc[z]
   terminals.append((r,tuple(ids)));return ('T',r,tuple(ids))
 if not any(lo<b0 and a0<hi for name,a0,b0 in regions):
  z=code(t);outside|=desc[z];return('C',z)
 assert not s.leaf(t)
 return('N',skeleton(t[0],lo),skeleton(t[1],lo+len(s.sites(t[0]))))
frame=skeleton(old)
def assess(choice,build=False):
 mask=outside
 for r,p in enumerate(choice):mask|=rowmasks[r][p]
 temp={};tnodes={}
 def visit(t):
  nonlocal mask
  if t[0]=='C':return t[1]
  if t[0]=='T':return t[2][choice[t[1]]]
  x=visit(t[1]);y=visit(t[2]);key=x,y
  if key in intern:
   z=intern[key];mask|=1<<z;return z
  if key not in temp:z=-len(temp)-1;temp[key]=z;tnodes[z]=key
  return temp[key]
 root=visit(frame);n=mask.bit_count()+len(temp)
 if not build:return n
 def materialize(z):
  if z>=0:return trees[z]
  x,y=tnodes[z];return materialize(x),materialize(y)
 t=materialize(root);assert s.metrics(t)['dag_nodes']==n
 return n,t
start=time.time();best=999;records=[];out=a.ROOT/'independent_work/gated_permuted';out.mkdir(exist_ok=True)
for k,choice in enumerate(itertools.product(range(6),repeat=len(regions))):
 n=assess(choice)
 if n<best:best=n;records=[];print('BEST',best,choice,'at',k,'seconds',round(time.time()-start,2),flush=True)
 if n==best:records.append(choice)
 if k%10000==0:print('PROGRESS',k,best,flush=True)
for j,choice in enumerate(records[:40]):
 n,t=assess(choice,True);m=s.metrics(t);name=f'gated-permuted-{j}-{n}'
 (out/(name+'.sites.json')).write_bytes(s.compact(s.sites(t)))
 (out/(name+'.recipe.json')).write_text(json.dumps({'source':str(path),'regions':regions,'choice':choice,'permutations':[perms[p]for p in choice],'metrics':m},indent=2))
info={'best':best,'count':6**len(regions),'best_count':len(records),'best_choices':records,'regions':regions,'perms':perms,'seconds':round(time.time()-start,2)}
(a.ROOT/'independent_work/gated-row-permute-results.json').write_text(json.dumps(info,indent=2));print('DONE',info,flush=True)
