from pathlib import Path
from functools import lru_cache
import json,sys,random,time,heapq,hashlib
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code'));import source_language as s
old=s.tree(json.loads((p/'sites215.json').read_text()));oldcfg=s.graph_intervals(s.sites(old));nodes=[];ids={}
def mk(n):
 if n in ids:return ids[n]
 i=len(nodes);ids[n]=i;nodes.append(n);return i
def encode(t):return mk(t)if s.leaf(t)else mk((encode(t[0]),encode(t[1])))
start=encode(old)
def leaf(i):return isinstance(nodes[i][0],str)
@lru_cache(None)
def decode(i):return nodes[i]if leaf(i)else(decode(nodes[i][0]),decode(nodes[i][1]))
def dag(i):
 seen=set();todo=[i]
 while todo:
  z=todo.pop()
  if z in seen:continue
  seen.add(z)
  if not leaf(z):todo.extend(nodes[z])
 return seen
base=dag(start)
@lru_cache(None)
def shift(i,edge,depth,sign):
 n=nodes[i]
 if leaf(i):
  op,arg=n
  rel=(edge==0 and op in('CB','CD'))or(edge==1 and op=='CC')
  if not rel:return i
  k=1 if op=='CD'else arg
  if sign==1:
   if k<=depth:return i
   if op=='CD':return None
   return mk((op,k+1))
  else:
   if k<=depth:return i
   if k==depth+1:return None
   if op=='CD':return None
   return mk((op,k-1))
 a=shift(n[0],edge,depth+int(edge==0),sign);b=shift(n[1],edge,depth+int(edge==1),sign)
 return None if a is None or b is None else mk((a,b))
@lru_cache(None)
def rotate(i,way):
 if leaf(i):return None
 x,y=nodes[i]
 if way=='swap':
  return mk((y,x)) if leaf(x)and leaf(y)and nodes[x][0]==nodes[y][0]=='CI'and x!=y else None
 if way=='left':
  if leaf(y):return None
  b,c=nodes[y];a=shift(x,0,0,1);c=shift(c,1,0,-1)
  return None if a is None or c is None else mk((mk((a,b)),c))
 else:
  if leaf(x):return None
  a,b=nodes[x];a=shift(a,0,0,-1);c=shift(y,1,0,1)
  return None if a is None or c is None else mk((a,mk((b,c))))
def replace(root,old,new):
 @lru_cache(None)
 def rec(i):
  if i==old:return new
  if leaf(i):return i
  a,b=nodes[i];return mk((rec(a),rec(b)))
 return rec(root)
@lru_cache(None)
def critical(i,k=0):
 if leaf(i):return int(nodes[i][0]in('CI','CD')and k>=6)
 a,b=nodes[i];return critical(a,k+1)+critical(b,0)
@lru_cache(None)
def leading(i):return 0 if leaf(i)else 1+leading(nodes[i][0])
@lru_cache(None)
def maxrun(i):return 0 if leaf(i)else max(leading(i),maxrun(nodes[i][0]),maxrun(nodes[i][1]))
@lru_cache(None)
def depth(i):return 0 if leaf(i)else 1+max(map(depth,nodes[i]))
parents={start:None};scores={start:(len(base),critical(start),depth(start),0)};seen={start};beam=[start];rng=random.Random(214);best=(202,37,47,0);begun=time.monotonic();outputs=[]
def emit(i,level):
 root=decode(i);rows=s.sites(root)
 graph=s.graph_intervals(rows)
 assert s.graph_arithmetic(rows)[0]==graph
 shape=lambda g:[(['increment',0] if e[0]=='increment' else e,t)for e,t in g]
 assert shape(graph)==shape(oldcfg)
 stem=Path(f'independent_work/swap-openbeam-{len(outputs)}-{scores[i][0]}-{scores[i][1]}');stem.with_suffix('.sites.json').write_bytes(s.compact(rows));chain=[];z=i
 while parents[z] is not None:
  prev,oldid,way=parents[z];target=decode(oldid);r=decode(prev);paths=[]
  def walk(n,p=''):
   if n==target:paths.append(p);return
   if not s.leaf(n):walk(n[0],p+'0');walk(n[1],p+'1')
  walk(r);chain.append({'direction':way,'paths':paths});z=prev
 chain.reverse();record={'level':level,'score':scores[i],'metrics':s.metrics(root),'recipe':chain,'source_sha256':hashlib.sha256(stem.with_suffix('.sites.json').read_bytes()).hexdigest()};stem.with_suffix('.json').write_text(json.dumps(record,indent=2));outputs.append(str(stem));print('OUTPUT',str(stem),json.dumps({'score':scores[i],'metrics':s.metrics(root),'steps':len(chain)}),flush=True)
for level in range(1,41):
 pool=[];generated=0
 for root in beam:
  oldset=dag(root)
  for i in oldset:
   for way in('left','right','swap'):
    out=rotate(i,way)
    if out is None:continue
    nr=replace(root,i,out)
    if nr in seen:continue
    seen.add(nr);newset=dag(nr);n=len(newset)
    if n>204 or maxrun(nr)>6:continue
    score=(n,critical(nr),depth(nr),len(newset-base));scores[nr]=score;parents[nr]=(root,i,way);pool.append(nr);generated+=1
    if score<best:
     best=score;print('BEST',level,best,'nodes',len(nodes),'seen',len(seen),'seconds',round(time.monotonic()-begun,2),flush=True)
     if n<202 or(n<=202 and score[1]==0):emit(nr,level);raise SystemExit
 if not pool:break
 pool.sort(key=scores.get)
 best201=[i for i in pool if scores[i][0]<=201]
 compact=[i for i in pool if scores[i][0]==202]
 wider=[i for i in pool if scores[i][0]==203]
 largest=[i for i in pool if scores[i][0]==204]
 beam=pool[:20]+rng.sample(compact,min(10,len(compact)))+wider[:10]+rng.sample(wider,min(10,len(wider)))+largest[:5]
 beam=list(dict.fromkeys(beam))
 print('LEVEL',level,'generated',generated,'beam',len(beam),'best',scores[pool[0]],'nodes',len(nodes),'seconds',round(time.monotonic()-begun,2),flush=True)
 if level%10==0:emit(pool[0],level)
print('DONE',len(seen),len(nodes),time.monotonic()-begun,flush=True)
