#!/usr/bin/env python3
"""Alternative arithmetic kernel P(a,b)=(2b+1)2^a-1.
This is an uncalibrated experimental source transform, not a machine claim.
"""
import json,sys,hashlib
from pathlib import Path
from functools import cache
import macro_audit as a
s=a.s
CI=lambda r:('CI',r);CD=lambda r:('CD',r);CC=lambda k:('CC',k)
def move(x,y):return CD(x),(CI(y),CC(2))
A=(CD(1),((CI(7),CI(7)),CC(2)))
B=move(7,1)
PAIR=(A,(CD(6),((B,CI(7)),CC(3))))
def unpair(i):return (CD(i),((CD(i),(CI(7),CC(3))),((CI(6),move(7,i)),CC(3))))
oldnodes={'PAIR':a.expand('ENode 162'),'UNPAIR2':a.expand('ENode 116'),'UNPAIR8':a.expand('ENode 115')}
newnodes={'PAIR':PAIR,'UNPAIR2':unpair(2),'UNPAIR8':unpair(8)}
def finger(t):
 try:return json.dumps(a.normalize(a.local_graph(s.sites(t))),sort_keys=True)
 except (ValueError,AssertionError):return None
oldfinger={finger(t):name for name,t in oldnodes.items()}
old=s.tree(json.loads((a.BASE/'sites215.json').read_text()))
matched={};seen=set()
def search(t):
 if t in seen:return
 seen.add(t)
 if s.leaf(t):return
 if len(s.sites(t))in(8,10):
  f=finger(t)
  if f in oldfinger:matched[t]=oldfinger[f]
 search(t[0]);search(t[1])
search(old)
@cache
def rewrite(t):
 if t in matched:return newnodes[matched[t]]
 if s.leaf(t):return t
 return rewrite(t[0]),rewrite(t[1])
new=rewrite(old);rows=s.sites(new)
# Primitive evaluator has an explicit exit obtained by appending a halt.
def run(t,regs,limit=1000000):
 rows=s.sites((t,('CH',None)));g=s.graph_intervals(rows);v=list(regs);i=0
 for steps in range(limit):
  e,ts=g[i]
  if e[0]=='halt':return v,steps
  if e[0]=='increment':v[e[1]]+=1;i=ts[0]
  elif e[0]=='decrement':
   k=e[1]
   if v[k]:v[k]-=1;i=ts[1]
   else:i=ts[0]
  else:i=ts[0]
 raise RuntimeError(('step limit',regs))
for x in range(7):
 for y in range(12):
  v=[0]*9;v[6]=x;v[1]=y;v[4]=23;want=(2*y+1)*2**x-1
  out,k=run(PAIR,v);assert out[7]==want and out[1]==out[6]==0 and out[4]==23
for i in(2,8):
 for n in range(200):
  v=[0]*9;v[i]=n;v[4]=23;out,k=run(unpair(i),v)
  assert out[i]==0 and out[4]==23 and (2*out[7]+1)*2**out[6]-1==n
info={'status':'EXPERIMENTAL_CONTRACT_SAMPLES_PASS','pairing':'P(a,b)=(2*b+1)*2**a-1','old_metrics':s.metrics(old),'new_metrics':s.metrics(new),'matched_distinct_old_subtrees':{name:sum(z==name for z in matched.values())for name in oldnodes},'old_arithmetic':oldnodes,'new_arithmetic':newnodes,'new_boundary':{name:s.boundary(t)for name,t in newnodes.items()},'assumptions':'PAIR requires scratch7=0; UNPAIR requires scratch6=scratch7=0. Full source calibration and runtime are not claimed.'}
O=a.ROOT/'independent_work';(O/'exponential-pair.sites.json').write_bytes(s.compact(rows));(O/'exponential-pair-info.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps({k:v for k,v in info.items()if k not in ('old_arithmetic','new_arithmetic')},indent=2))
