#include <algorithm>
#include <array>
#include <bitset>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <chrono>
using namespace std;
struct Row{int w,d,t;};
struct Case{int site,pos,op,arg;array<int,9> mask;string pc,nxt;};
struct Test{int cid,pattern;bitset<512> used;};
array<array<Row,2>,512> T;
vector<int> Q;
vector<Case> C;
array<vector<int>,512> picks;
constexpr int N=8192,OR=4096;
const int PHY[9]={6,2,0,4,3,7,8,5,1};
struct Answer{bool ok;int steps;bitset<512> used;};
Answer run(int cid,int pattern,int drop,int keep){
 const auto &c=C[cid];if(c.mask[0]==0 || c.op==1 && !(c.mask[c.arg] & (c.pos?6:1)))return{true,0,{}};array<unsigned char,N> tape{};
 int vals[9],expected[9];
 for(int i=0;i<9;i++){
  int m=c.mask[i];
  vals[i]=pattern==0 ? ((m&1)?0:(m&2)?1:2) : pattern==1 ? ((m&2)?1:(m&4)?2:0) : ((m&4)?2+i%3:(m&2)?1:0);
 }
 if(c.op==1)vals[c.arg]=c.pos ? (pattern==2 && (c.mask[c.arg]&4)?2: (c.mask[c.arg]&2)?1:2) : 0;
 for(int i=0;i<9;i++)expected[PHY[i]]=vals[i];
 if(c.op==0)expected[PHY[c.arg]]++;
 if(c.op==1&&c.pos)expected[PHY[c.arg]]--;
 int h=OR,q=84,lo=OR-1,hi=OR+65;
 tape[OR-1]=1;tape[OR+65]=1;
 for(int i=0;i<(int)c.pc.size();i++)tape[OR+i]=c.pc[i]=='1';
 int physical[9];for(int i=0;i<9;i++)physical[PHY[i]]=vals[i];
 int p=OR+66;
 for(int i=0;i<12;i++){
  int val=i<9?physical[i]:1;
  p++;for(int j=0;j<val+1;j++)tape[p++]=1;
 }
 hi=p-1;bitset<512> used;
 auto post=[&](){
  while(hi>=lo&&!tape[hi])hi--;
  if(h<1||h+(int)c.nxt.size()+64>=N||!tape[h-1])return false;
  for(int i=lo;i<h-1;i++)if(tape[i])return false;
  for(int i=0;i<(int)c.nxt.size();i++)if(tape[h+i]!=(c.nxt[i]=='1'))return false;
  int p=h+c.nxt.size();while(p<=hi&&!tape[p])p++;
  if(p>hi||p<h+64)return false;
  p++;
  for(int i=0;i<9;i++){
   if(p>hi||tape[p++])return false;
   for(int j=0;j<expected[i]+1;j++)if(p>hi||!tape[p++])return false;
   if(p<=hi&&tape[p])return false;
  }
  int spares=0;
  while(p<=hi){
   if(tape[p++])return false;
   if(p>hi)break;
   if(!tape[p])return false;
   while(p<=hi&&tape[p])p++;
   spares++;
  }
  return spares>0;
 };
 for(int step=0;step<50000;step++){
  if(step&&q==254)return{c.op==4,step,used};
  if(step&&q==84&&c.op!=4&&post())return{true,step,used};
  if(q==254||h<1||h>=N-1)return{false,step,used};
  used.set(q);auto a=T[q][tape[h]];tape[h]=a.w;lo=min(lo,h);hi=max(hi,h);
  h+=a.d;q=a.t==drop?keep:a.t;
 }
 return{false,50000,used};
}
int main(int argc,char**argv){
 ifstream f("independent_work/semantic-fold-input.txt");int n;f>>n;
 while(n--){int q;f>>q;Q.push_back(q);for(int b=0;b<2;b++)f>>T[q][b].w>>T[q][b].d>>T[q][b].t;}
 f>>n;while(n--){Case c;f>>c.site>>c.pos>>c.pc>>c.op>>c.arg>>c.nxt;for(int j=0;j<9;j++)f>>c.mask[j];if(c.nxt=="-")c.nxt="";C.push_back(c);}
 f>>n;while(n--){int q,m;f>>q>>m;while(m--){int i;f>>i;picks[q].push_back(i);}}
 if(argc>3&&string(argv[1])=="verify"){
  int drop=stoi(argv[2]),keep=stoi(argv[3]);int passed=0;
  for(int i=0;i<(int)C.size();i++)for(int pat=0;pat<3;pat++){
   auto a=run(i,pat,drop,keep);
   if(!a.ok){cout<<"FULL_FAIL drop "<<drop<<" keep "<<keep<<" case "<<i<<" site "<<C[i].site<<" pattern "<<pat<<" steps "<<a.steps<<" passed "<<passed<<"\n";return 3;}passed++;
  }
  cout<<"FULL_PASS "<<drop<<" "<<keep<<" probes "<<passed<<"\n";return 0;
 }
 vector<int> drops={50,198,34,66};
 if(argc>1&&string(argv[1])=="all")for(int q:Q)if(q!=84&&find(drops.begin(),drops.end(),q)==drops.end())drops.push_back(q);
 long long total=0;int survivors=0;auto start=chrono::steady_clock::now();
 for(int q:drops){
  vector<Test> tests;
  for(int pat=0;pat<3;pat++)for(int i:picks[q]){auto a=run(i,pat,-1,-1);if(!a.ok){cerr<<"BASELINE_FAIL "<<q<<" "<<i<<" "<<pat<<"\n";return 2;}if(a.used[q])tests.push_back({i,pat,a.used});}
  if(tests.empty()){cout<<"NO_PROBES "<<q<<"\n";continue;}
  int best=0,near=0;
  for(int r:Q){if(r==q)continue;total++;int good=0;
   for(auto &x:tests){auto a=run(x.cid,x.pattern,q,r);if(!a.ok)break;good++;}
   best=max(best,good);
   if(good==(int)tests.size()){survivors++;cout<<"SURVIVOR "<<q<<" "<<r<<" probes "<<good<<"\n"<<flush;}
   else if(good>=5){near++;cout<<"NEAR "<<q<<" "<<r<<" passed "<<good<<" of "<<tests.size()<<"\n"<<flush;}
  }
  cout<<"DROP "<<q<<" probes "<<tests.size()<<" best "<<best<<" near "<<near<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n"<<flush;
 }
 cout<<"DONE pairs "<<total<<" survivors "<<survivors<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
}
