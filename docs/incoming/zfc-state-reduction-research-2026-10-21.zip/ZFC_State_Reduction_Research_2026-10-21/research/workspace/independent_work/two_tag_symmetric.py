#!/usr/bin/env python3
"""Symmetric two-tag codec source: reserve the second outer coordinate zero for atoms.
Only closed arithmetic intervals are replaced; every surviving CFG edge is checked.
"""
from pathlib import Path
import sys,json,itertools,hashlib,time
sys.path[:0]=['independent_work','encoding_work']
import macro_audit as a
import replace_closed as rc
s=a.s
R=json.loads((a.BASE/'sites215.json').read_text());T=s.tree(R);tokens,g=a.tokenize(R)
I=('CI',1)
def actual(lo,hi):
 ps=[p for p,o,k in R[lo:hi]];p=ps[0]
 while any(not q.startswith(p) for q in ps):p=p[:-1]
 n=s.subtree(T,p)
 assert len(s.sites(n))==hi-lo
 return n
ci6=('CI',6)
pair=actual(184,194) # first CONS at173, pair after11
scale=lambda reg:(('CD',7),((('CI',reg),('CI',reg)),('CC',2)))
f2=(pair,scale(1));move=(('CD',1),(ci6,('CC',2)))

def build(direct=False,assoc=0):
 edits=[]
 for i,name,k in tokens:
  if name not in ('I','M','Q','E'):continue
  assert k=={'I':27,'M':28,'Q':29,'E':30}[name]
  edits.append((i+21,i+27,scale(6 if direct and name in ('M','E') else 1)))
  if name=='Q':
   edits.append((i+11,i+21,(I,pair)))
   edits.append((i+27,i+29,I))
  if name=='M':
   n=(f2,I) if direct else ((move,f2),I) if assoc==0 else (move,(f2,I))
   edits.append((i+27,i+28,n))
  if name=='E':
   if direct:edits.extend([(i+27,i+28,ci6),(i+28,i+29,f2)])
   else:edits.append((i+28,i+29,(move,f2)))
 rr=R
 for lo,hi,node in sorted(edits,reverse=True):rr=rc.replace(rr,lo,hi,node)
 n=s.tree(rr)
 return rr,s.metrics(n)
if __name__=='__main__':
 out=Path('independent_work/two_tag');out.mkdir(exist_ok=True)
 for direct,assoc in [(False,0),(False,1),(True,0)]:
  start=time.time();rr,met=build(direct,assoc);name=f'symmetric-{int(direct)}-{assoc}';path=out/(name+'.sites.json');path.write_bytes(s.compact(rr));info={'name':name,'metrics':met,'elapsed_seconds':time.time()-start,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};print(json.dumps(info),flush=True);(out/(name+'.json')).write_text(json.dumps(info,indent=2))
