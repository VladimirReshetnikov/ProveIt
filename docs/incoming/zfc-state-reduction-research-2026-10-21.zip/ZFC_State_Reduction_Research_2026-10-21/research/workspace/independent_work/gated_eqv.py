import json,itertools,time,sys
sys.path.insert(0,str(__import__("pathlib").Path.cwd()))
from pathlib import Path
exec(Path('symbolic_ax.py').read_text().split('marked=')[0])
from delete_closed import remove
old=r;oldrows=s.sites(old)
base_rows=remove(oldrows,[(25+618,25+698),(25+780,25+809)])
base=s.tree(base_rows)
def findword(w):
 return next(n for ns in g.values()for n in ns if word(n)==w)
par={1:findword(par1),2:findword(par2),3:findword(par3)}
consnode=findword(cons);walnode=findword(cons+[('CI',1)]*2)
CI=('CI',1)
def endings(index):
 p=base_rows[index-1][0];result=[]
 for k in range(len(p),0,-1):
  if '0'in p[k:]:break
  q=p[:k];t=s.subtree(base,q)
  if s.boundary(t)==(0,0,False):result.append(q)
 return result
entry=endings(25+2618-109);join=endings(25+4484-109)
print('SPLICES',entry,join,flush=True)

# Canonical integer IDs keep parsing searches independent of enormous
# repeated tuples in the source. The small frozenset records new nodes.
intern={};trees={};stats={};desc={}
def code(t):
 if s.leaf(t):key=t;ds=set();stat=(0,0,0)
 else:
  a,b=code(t[0]),code(t[1]);key=(a,b);ds=desc[a]|desc[b]
  da,za,la=stats[a];db,zb,lb=stats[b]
  stat=(1+max(da,db),max(za,zb,1+la),1+la)
 if key not in intern:
  z=len(intern)+1;intern[key]=z;trees[z]=t;stats[z]=stat;desc[z]=ds|{z}
 return intern[key]
baseid=code(base);base_nodes=desc[baseid]
code(old)
def pair(a,b):
 key=(a,b)
 if key not in intern:
  z=len(intern)+1;intern[key]=z;trees[z]=(trees[a],trees[b])
  da,za,la=stats[a];db,zb,lb=stats[b]
  stats[z]=(1+max(da,db),max(za,zb,1+la),1+la)
 return intern[key]
def count(t):
 seen=set()
 def go(q):
  if q in seen:return
  seen.add(q)
  if not s.leaf(q):go(q[0]);go(q[1])
 go(t);return len(seen)

start=time.time();best=999;records=[];saved=0;out=Path('../independent_work/gated_eqv');out.mkdir(exist_ok=True)
for reverse in (0,1):
 a,b=(2,1) if reverse else (1,2)
 atoms=[par[a],par[b],consnode,CI,CI,CI,par[3],par[a],par[b],consnode,CI,CI,CI,walnode,consnode]
 ids=[code(t)for t in atoms];fixed=base_nodes|set().union(*(desc[z]for z in ids))
 chart={}
 for i,z in enumerate(ids):chart[i,i+1]=[(z,frozenset())]
 for length in range(2,len(ids)+1):
  for i in range(len(ids)-length+1):
   j=i+length;found={}
   for k in range(i+1,j):
    for a,sa in chart[i,k]:
     for b,sb in chart[k,j]:
      z=pair(a,b)
      if stats[z][1]>6:continue
      ss=sa|sb
      if z not in fixed:ss=ss|{z}
      if z not in found or len(ss)<len(found[z]):found[z]=ss
   ranked=sorted(found.items(),key=lambda x:(len(x[1]),stats[x[0]][0],stats[x[0]][2],x[0]))
   # Keep grammatical alternatives with distinct leading-zero/depth stats.
   keep=ranked[:28]
   seenstats={(stats[z][0],stats[z][2])for z,ss in keep}
   for z,ss in ranked[28:]:
    key=stats[z][0],stats[z][2]
    if key not in seenstats:keep.append((z,ss));seenstats.add(key)
    if len(keep)>=40:break
   chart[i,j]=keep
  print('DP',reverse,length,'nodes',len(intern),flush=True)
 for ci,(z,ss) in enumerate(chart[0,len(ids)]):
  helper=trees[z]
  for ei,p in enumerate(entry):
   for ji,q in enumerate(join):
    # Paths are disjoint. Closed wrappers preserve all old guarded edges.
    t=s.replace(base,p,(s.subtree(base,p),helper))
    t=s.replace(t,q,(s.subtree(base,q),consnode))
    n=count(t);m=s.metrics(t)
    if m['maximum_zero_run']>6:continue
    rec=(n,reverse,ci,ei,ji,m)
    if n<best:best=n;saved=0;print('BEST',rec,flush=True)
    records.append(rec)
    if n<=best and saved<25:
     name=f'gated-eqv-r{reverse}c{ci}e{ei}j{ji}-{n}'
     (out/(name+'.json')).write_bytes(s.compact(s.sites(t)))
     saved+=1
print('DONE best',best,'seconds',round(time.time()-start,2),'top',sorted(records)[:50],flush=True)
Path('../independent_work/gated-eqv-results.json').write_text(json.dumps({'best':best,'records':sorted(records)},indent=2))
