from pathlib import Path
import sys,json,time,signal,collections,gzip
import relaxed_tail as r
s=r.s;v=r.v;p=r.p;T=s.r.table(p/'k215.native.tm');sites=json.loads((p/'sites215.json').read_text());Q=sorted({q for q,a in T})
m={int(k):int(w)for k,w in json.loads(v.MAPPATH.read_text()).items()}
for q in set(Q)|{254}:m.setdefault(q,q+1000)
cs=json.load(gzip.open(p/'verification/root-run1/runtime/runtime_cases.json.gz'))
def timeout(*_):raise TimeoutError('timeout')
signal.signal(signal.SIGALRM,timeout)
def chk(L,lem,site,pos):
 try:
  signal.setitimer(signal.ITIMER_REAL,0.06)
  z=r.case(L,lem,site,pos)
  signal.setitimer(signal.ITIMER_REAL,0)
  return True
 except Exception:signal.setitimer(signal.ITIMER_REAL,0);return False
# all primitive kinds/operand/guards, preferring shortest baseline certificates
probe={}
for c in sorted(cs,key=lambda c:c['symbolic_steps']):
 site=sites[c['site_index']];probe.setdefault((site[1],site[2],c['positive']),(site,c['positive']))
probes=[(sites[0],False),(sites[3],False),(sites[0],True)]+list(probe.values())
results=[];t0=time.monotonic()
for drop,caller in((94,(0,0)),(66,(94,0))):
 for w in(0,1):
  for d in(-1,1):
   for q in Q:
    if q==drop:continue
    N={k:row for k,row in T.items()if k[0]!=drop};N[caller]=(w,d,q)
    L={(m[a],b):(x,y,m[c])for(a,b),(x,y,c)in N.items()}
    try:lem,_=s.prove_blocks(L)
    except Exception:continue
    nr=0
    for site,pos in probes:
     if not chk(L,lem,site,pos):break
     nr+=1
    if nr<2:continue
    rec={'drop':drop,'caller':caller,'row':N[caller],'proved_probes':nr,'total_probes':len(probes)};print('PARTIAL',rec,flush=True);results.append(rec)
    if nr==len(probes):
     name=f'independent_work/tail-chain-drop{drop}-{w}{d}{q}.native.tm';Path(name).write_text('#! start 0\n'+''.join(f'{a} {b} {x} {"R"if y==1 else"L"} {c}\n'for(a,b),(x,y,c)in sorted(N.items())));print('FOUND',name,flush=True)
 print('DROP_DONE',drop,time.monotonic()-t0,flush=True)
print('DONE',time.monotonic()-t0,results,flush=True)
Path('independent_work/tail_chain_search.json').write_text(json.dumps(results,indent=2))
