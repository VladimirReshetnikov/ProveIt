from pathlib import Path
import sys,json,itertools,time,functools
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'encoding_work'));import replace_closed as rc
s=rc.s
sys.path.insert(0,str(ROOT/'formalism_work'));import delete_closed as dc
# Load independently parsed macro definitions without running its fixed audit.
code=(ROOT/'independent_work/audit_r7.py').read_text().split('oldstart,oldend=')[0]
ns={'__file__':str(ROOT/'independent_work/audit_r7.py')};exec(code,ns)
old=ns['old'];local_graph=ns['local_graph'];norm=ns['normalize_increments'];expand=ns['expand']
base=dc.remove(old,[(643,723)])
tr=s.tree(old)
@functools.cache
def nodes(t):return frozenset([t])if s.leaf(t)else frozenset([t])|nodes(t[0])|nodes(t[1])
oldnodes=nodes(tr)
def findmacro(i):
 pattern=norm(local_graph(s.sites(expand('ENode '+str(i)))))
 ans=[]
 for t in oldnodes:
  if s.leaf(t)or s.boundary(t)!=(0,0,False):continue
  rr=s.sites(t)
  if len(rr)!=len(pattern):continue
  if norm(local_graph(rr))==pattern:ans.append(t)
 return ans or [expand('ENode '+str(i))]
pairs=findmacro(162);scales=findmacro(117)
@functools.cache
def assoc(xs):
 if len(xs)==1:return(xs[0],)
 return tuple((l,r)for i in range(1,len(xs))for l in assoc(xs[:i])for r in assoc(xs[i:]))
def tagcontinue(t,p=''):
 if s.leaf(t):return ('CC',p.count('1'))if t[0]=='CC'else t
 return tagcontinue(t[0],p+'0'),tagcontinue(t[1],p+'1')
loops=set()
for perm in set(itertools.permutations((6,6,7))):
 for t in assoc((('CD',1),*(('CI',a)for a in perm),('CC',1))):
  t=tagcontinue(t)
  if s.boundary(t)!=(0,0,False):continue
  g=local_graph(s.sites(t));want=[[['decrement',1],[5,1]],*[[['increment',a],[i+2]]for i,a in enumerate(perm)],[['identity'],[0]]]
  if g==want:loops.add(t)
print('PARTS',len(loops),len(pairs),len(scales),flush=True)
variants=set()
for loop in loops:
 for pair in pairs:
  for scale in scales:
   variants.update(assoc((loop,pair,scale,('CI',1),('CI',1))))
print('VARIANTS',len(variants),flush=True)
best=999;out=[];start=time.monotonic()
for k,node in enumerate(variants):
 # Cheap union score rejects most possibilities before the whole-source transform.
 cost=len(nodes(node)-oldnodes)
 if cost>9:continue
 rows=rc.replace(base,725,754,node);tree=s.tree(rows);met=s.metrics(tree);n=met['dag_nodes']
 if n<best:best=n;print('BEST',k,n,met,'cost',cost,'seconds',time.monotonic()-start,flush=True)
 if n<=202:
  out.append((n,cost,k,rows,node,met))
print('FINISH',best,'eligible',len(out),'seconds',time.monotonic()-start,flush=True)
for num,(n,cost,k,rows,node,met)in enumerate(sorted(out,key=lambda x:(x[0],x[1]))[:30]):
 path=ROOT/f'independent_work/r7-selfq-{num}-{n}.sites.json';path.write_bytes(s.compact(rows));
 (ROOT/f'independent_work/r7-selfq-{num}-{n}.recipe.json').write_text(json.dumps({'drop':[643,723],'replace_after_drop':[725,754],'macro':node,'macro_metrics':s.metrics(node),'source_metrics':met,'new_nodes':cost},indent=2)+'\n')
 print('OUTPUT',path.name,met,flush=True)
