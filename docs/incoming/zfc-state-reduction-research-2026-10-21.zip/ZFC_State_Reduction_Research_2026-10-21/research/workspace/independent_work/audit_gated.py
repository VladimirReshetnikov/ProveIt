#!/usr/bin/env python3
"""Independent constructor, gate and collapsed-CFG audit of gated crossed helper.
Known macro implementations are reconstructed from archived Coq DAG254.v.
The caller supplies only the candidate's literal primitive site list.
"""
from pathlib import Path
import json,sys,hashlib
import macro_audit as a
s=a.s
old=json.loads((a.BASE/'sites215.json').read_text())
path=Path(sys.argv[1])if len(sys.argv)>1 else a.ROOT/'formalism_work/gated_crossed/gated-r0c0e5j2-205.json'
new=json.loads(path.read_text())
def macro_program(rows):
 tok,g=a.tokenize(rows);owner={i:k for k,(j,n,l)in enumerate(tok)for i in range(j,j+l)}
 incoming={}
 for i,(e,ts)in enumerate(g):
  for j in ts:incoming.setdefault(j,[]).append(i)
 collapsed=[]
 for k,(i,n,l)in enumerate(tok):
  if isinstance(n,str):
   assert all(owner[z]==k for j in range(i+1,i+l)for z in incoming.get(j,[])),('entry inside macro',i,n)
   collapsed.append([n,[owner[(i+l)%len(rows)]]])
  else:collapsed.append([g[i][0],[owner[j]for j in g[i][1]]])
 return tok,g,collapsed
O,OG,OC=macro_program(old);N,NG,NC=macro_program(new)
# The sole long straight constructor region is AX's matrix-building arm.
def region(tokens):
 start=next(k for k,(i,n,l)in enumerate(tokens)if i==26)
 end=next(k for k in range(start,len(tokens))if not isinstance(tokens[k][1],str))
 assert all(n in ('par1','par2','par3','I','M','Q','E','push','F','read1','read2')for i,n,l in tokens[start:end])
 return start,end
os,oe=region(O);ns,ne=region(N)
assert os==ns
assert [n for i,n,l in O[:os]]==[n for i,n,l in N[:ns]]
assert [n[0] if isinstance(n,tuple)else n for i,n,l in O[oe:]]==[n[0]if isinstance(n,tuple)else n for i,n,l in N[ne:]]
# Validate each retained prefix/suffix primitive/macro effect and every edge.
# Retained graph edges may target matrix emission entry/exit, not its interior.
def projected(c,start,end):
 def target(k):
  if k<start:return k
  if k==start:return start
  if k<end:raise AssertionError(('entry inside replaced emission',k,start,end))
  return k-(end-start)+1
 out=[]
 for k,(op,ts)in enumerate(c):
  if start<k<end:continue
  if k==start:out.append(['MATRIX-EMISSION',[start+1]])
  else:out.append([op,[target(j)for j in ts]])
 return out
assert projected(OC,os,oe)==projected(NC,ns,ne)
# Symbolic stack evaluation. Read parameters are named by their final value;
# the retained read operation adds an arbitrary proof-list field to the old
# value. Both programs use literally the same read macro at the same point.
def symbolic(tokens):
 top='T';stack=['W'];params={'par1':'U','par2':'H','par3':'C'};reads=[]
 for i,n,k in tokens:
  if n in params:stack.insert(0,top);top=params[n]
  elif n in ('push','F'):stack.insert(0,top);top=0 if n=='push'else 1
  elif n in ('I','M','Q','E'):top=(n,stack.pop(0),top)
  elif n=='read1':reads.append((n,params['par1'],'A'));params['par1']='A'
  elif n=='read2':reads.append((n,params['par2'],'B'));params['par2']='B'
  else:raise AssertionError(n)
 return top,stack,params,reads
ot,ow,op,orr=symbolic(O[os:oe]);nt,nw,np,nrr=symbolic(N[ns:ne])
D=('I',('E','A','B'),('Q','C',('E','B','A')))
R7=('I',('E','C','A'),('I',('E','C','B'),('Q',('M','A','B'),('E','A','B'))))
assert ot[0]=='I' and ot[2]==1
expected=('I',('I',D,ot[1]),1)
assert nt==expected,('new bundle does not equal intended conjunction',nt,expected)
assert ow.count(R7)==1 and nw==[x for x in ow if x!=R7],('other emitted stack rows changed',ow,nw)
assert op==np and orr==nrr
# Equality gate: retained literal source gives exactly the same collapsed
# graph and register effects from immediately after matrix emission onward.
# Thus its already established C!=A,B condition and erasure behavior persist.
report={'status':'INDEPENDENT_FINITE_SOURCE_AND_SYMBOLIC_MACRO_AUDIT_PASS','candidate':str(path),'old_sha256':hashlib.sha256((a.BASE/'sites215.json').read_bytes()).hexdigest(),'new_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'old_metrics':s.metrics(s.tree(old)),'new_metrics':s.metrics(s.tree(new)),'macro_origin':'Archived Dag254.v, with contracts from ProgLib254.v; no physical decoder map or proposer tokenization is used.','old_emission_primitive_interval':[O[os][0],O[oe][0]],'new_emission_primitive_interval':[N[ns][0],N[ne][0]],'old_constructor_tokens':oe-os,'new_constructor_tokens':ne-ns,'retained_prefix_and_gate_and_suffix_collapsed_CFG_identical':True,'new_helper':D,'old_bundle':ot,'new_bundle':nt,'deleted_row':R7,'old_output_stack':ow,'new_output_stack':nw,'final_parameter_symbols':np,'parameter_read_trace':nrr,'scope':'This proves literal macro refinement, the symbolic output identity, unchanged retained control, and unchanged guard implementation. Logical equiconsistency and exact binary runtime are separate obligations. Macro equations rely on inherited named Coq contracts; the source-to-macro CFG matching is checked here independently.'}
out=a.ROOT/'independent_work/gated-source-audit.json';out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in ('old_bundle','new_bundle','old_output_stack','new_output_stack')},indent=2))
