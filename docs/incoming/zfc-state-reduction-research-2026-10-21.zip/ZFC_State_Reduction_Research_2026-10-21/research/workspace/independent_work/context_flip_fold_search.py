from pathlib import Path
from collections import defaultdict
from functools import lru_cache
import json,itertools,time,sys
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code'));import build221 as b
T=b.read_table((p/'k215.native.tm').read_bytes())
def context_folds(N,depth=3):
 Q=sorted({q for q,b in N});incoming=defaultdict(list)
 for(q,x),(w,d,z)in N.items():incoming[z].append((q,x,w,d))
 allwords={n:set(itertools.product((0,1),repeat=n))for n in range(depth+1)}
 @lru_cache(None)
 def ctx(q,n):
  if n==0:return frozenset({()})
  if q==0 or not incoming[q]:return frozenset(allwords[n])
  out=set()
  for p,x,w,d in incoming[q]:
   if d==-1:return frozenset(allwords[n])
   out|={c+(w,)for c in ctx(p,n-1)}
  return frozenset(out)
 contexts={q:ctx(q,depth)for q in Q}
 words=sorted(allwords[depth]);providers=[{},{}]
 for a in(0,1):
  for h,w0 in itertools.product(Q,(0,1)):
   vals={}
   for word in words:
    tape={i-depth:v for i,v in enumerate(word)};tape[0]=a;original=dict(tape);tape[0]=w0;pos=-1;state=h;used=set()
    for steps in range(48):
     if pos==1:break
     if pos not in tape or(state,tape[pos])not in N:break
     used.add(state);w,d,state=N[state,tape[pos]];tape[pos]=w;pos+=d
    if pos==1 and tape==original:vals[word]=(state,used)
   providers[a][w0,h]=vals
 opts={}
 for q in Q:
  if any(N[q,a][:2]!=(a,1)for a in(0,1)):continue
  for a in(0,1):
   hs={}
   for h,vals in providers[a].items():
    if all(c in vals and vals[c][0]==N[q,a][2]and q not in vals[c][1]for c in contexts[q]):
     hs[h]=set().union(*(vals[c][1]for c in contexts[q]))
   opts[q,a]=hs
 out=[]
 for iq,q in enumerate(Q):
  if(q,0)not in opts:continue
  for r in Q[iq+1:]:
   if(r,0)not in opts or not contexts[q].isdisjoint(contexts[r]):continue
   hs=[]
   for a in(0,1):
    if N[q,a]==N[r,a]:hs.append(('direct',N[q,a][2]));continue
    good=[h for h in opts[q,a].keys()&opts[r,a].keys()if r not in opts[q,a][h] and q not in opts[r,a][h]]
    if not good:break
    hs.append(('left',*good[0]))
   if len(hs)==2:
    out.append({'q':q,'r':r,'choices':hs,'qcontexts':sorted(contexts[q]),'rcontexts':sorted(contexts[r]),'depth':depth})
 return out
if __name__=='__main__':
 for d in(2,3,4,5):
  begun=time.monotonic();ans=context_folds(T,d);print('DEPTH',d,time.monotonic()-begun,json.dumps(ans),flush=True)
  if ans:Path('independent_work/context_flip_folds.json').write_text(json.dumps(ans,indent=2))
