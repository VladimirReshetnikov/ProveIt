#!/usr/bin/env python3
"""Constructor tag permutations with M fixed at1; all arithmetic remains4P.
Changing tag0 to E uses a true atomic zero seed. Q-zero needs a quotient codec.
"""
from pathlib import Path
import sys,json,gzip,os,itertools,time
sys.path[:0]=['independent_work','encoding_work','formalism_work']
import macro_audit as m
import replace_closed as rc
import delete_closed as dc
import prefix_codec as p
s=m.s;R=json.loads((m.BASE/'sites215.json').read_text());old=s.tree(R);tokens,g=m.tokenize(R)
I=('CI',1)

def actual(lo,hi):
 pre=os.path.commonprefix([R[lo][0],R[hi-1][0]]);n=s.subtree(old,pre);assert len(s.sites(n))==hi-lo;return n
C=actual(173,200)
def build(tags,ishape=0,qshape=0,eshape=0,corestyle=0):
 edits=[]
 for i,n,L in tokens:
  if n not in ('I','M','Q','E'):continue
  k=tags[n]
  if n=='I' and k:
   inc=p.increments(k)[ishape]
   if corestyle==0:node=(C,inc)
   elif corestyle==1:node=(C[0],(C[1],inc))
   elif corestyle==2:node=((C[0],C[1][0]),(C[1][1],inc))
   else:raise ValueError(corestyle)
   edits.append((i,i+27,node))
  elif n in ('Q','E') and k != (2 if n=='Q' else 3):
   edits.append((i+27,i+L,p.increments(k)[qshape if n=='Q' else eshape] if k else None))
 rr=R
 for lo,hi,node in sorted(edits,key=lambda z:z[0],reverse=True):
  rr=dc.remove(rr,[(lo,hi)]) if node is None else rc.replace(rr,lo,hi,node)
 return rr,s.metrics(s.tree(rr))
if __name__=='__main__':
 out=Path('independent_work/tag_permutations');out.mkdir(exist_ok=True);results=[]
 for tags in [{'I':2,'M':1,'Q':3,'E':0},{'I':3,'M':1,'Q':2,'E':0},{'I':2,'M':1,'Q':0,'E':3},{'I':3,'M':1,'Q':0,'E':2}]:
  for ishape in range(len(p.increments(tags['I']))):
   for qshape in range(len(p.increments(tags['Q'])) if tags['Q'] else 1):
    start=time.time();rr,met=build(tags,ishape,qshape);name='tags-I%dQ%dE%d-i%dq%d'%(tags['I'],tags['Q'],tags['E'],ishape,qshape);info={'name':name,'tags':tags,'ishape':ishape,'qshape':qshape,'metrics':met,'seconds':time.time()-start};results.append(info);print(json.dumps(info),flush=True)
    (out/(name+'.sites.json.gz')).write_bytes(gzip.compress(s.compact(rr),mtime=0))
 (out/'results.json').write_text(json.dumps(results,indent=2))
