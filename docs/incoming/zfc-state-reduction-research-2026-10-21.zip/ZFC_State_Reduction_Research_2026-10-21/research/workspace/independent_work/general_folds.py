from collections import defaultdict
def folds(N):
 incoming=defaultdict(list)
 for(q,x),(w,d,z)in N.items():incoming[z].append((q,x,w,d))
 def ib(q):
  a=incoming[q];b=a[0][1]if a else None
  return b if a and all(x==w==b and d==1 for z,x,w,d in a)else None
 Q=sorted({q for q,b in N});pro=[defaultdict(list),defaultdict(list)]
 for a in(0,1):
  for h in Q:
   ends=[];used=set();good=True
   for marker in(0,1):
    tape={-1:marker,0:a};pos=-1;state=h
    for steps in range(32):
     if pos==1:break
     if pos not in tape or(state,tape[pos])not in N:good=False;break
     used.add(state);w,d,state=N[state,tape[pos]];tape[pos]=w;pos+=d
    else:good=False
    if pos!=1 or tape!={-1:marker,0:a}:good=False
    if not good:break
    ends.append(state)
   if good:pro[a][tuple(ends)].append((h,used))
 out=[]
 for iq,q in enumerate(Q):
  bq=ib(q)
  if bq is None or any(N[q,a][:2]!=(a,1)for a in(0,1)):continue
  for r in Q[iq+1:]:
   br=ib(r)
   if br is None or br==bq or any(N[r,a][:2]!=(a,1)for a in(0,1)):continue
   choices=[]
   for a in(0,1):
    want=[None,None];want[bq]=N[q,a][2];want[br]=N[r,a][2]
    if want[0]==want[1]:choices.append(('direct',want[0]))
    else:
     hs=[h for h,used in pro[a].get(tuple(want),())if q not in used and r not in used]
     if not hs:break
     choices.append(('left',hs[0]))
   if len(choices)==2:out.append((q,r,*choices))
 return out
