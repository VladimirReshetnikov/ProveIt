#!/usr/bin/env python3
"""Independent literal-source audit of the proposed R7 constructor deletion.
Known macro implementations are reconstructed from the archived Coq DAG, not
from the proposer’s tokenization or from the physical decoder table.
This proves a finite source identity and symbolic macro equation, not logical
adequacy of the modified calculus.
"""
from pathlib import Path
import json,re,sys,hashlib,bisect
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(BASE/'code'));import source_language as s
old=json.loads((BASE/'sites215.json').read_text());new=json.loads((ROOT/'formalism_work/r7-no-fresh-binder.json').read_text())
G,_=s.graph_arithmetic(old);H,_=s.graph_arithmetic(new)
assert G==s.graph_intervals(old) and H==s.graph_intervals(new)
ranges=[(643,723),(805,834)];removed=set().union(*(set(range(a,b))for a,b in ranges));retained=[i for i in range(len(old))if i not in removed]
def project(i):return bisect.bisect_left(retained,i)%len(retained)
assert len(new)==len(retained)==4642
for j,i in enumerate(retained):
 assert old[i][1]==new[j][1],(i,j,'opcode')
 if old[i][1] in ('CI','CD','CH'):assert old[i][2]==new[j][2],(i,j,'operand')
 assert H[j]==[G[i][0],[project(k)for k in G[i][1]]],(i,j,'control')
closed=[]
for a,b in ranges:
 ins={k for i,(_,ks)in enumerate(G)if i<a or i>=b for k in ks if a<=k<b}
 outs={k for i in range(a,b)for k in G[i][1]if k<a or k>=b}
 assert ins=={a}and outs=={b},(a,b,ins,outs)
 closed.append({'interval':[a,b],'incoming_targets':sorted(ins),'outgoing_targets':sorted(outs)})
# Parse the independently archived generated Coq DAG.
text=(ROOT/'formalism_work/Dag254.v').read_text();nodes={}
for m in re.finditer(r'^\s*\| (\d+) => \(([^,]+), ([^)]+)\)',text,re.M):nodes[int(m[1])]=(m[2],m[3])
def expand(e):
 parts=e.split();name=parts[0];arg=int(parts[1])if len(parts)>1 else None
 if name=='ENode':return tuple(expand(c)for c in nodes[arg])
 return ({'EInc':'CI','EDecnz':'CD','EBreak':'CB','EContinue':'CC','EHalt':'CH'}[name],arg)
macros={'par1':166,'par2':121,'par3':168,'I':119,'M':181,'Q':180,'E':182,'push':171}
impl={name:s.sites(expand('ENode '+str(i)))for name,i in macros.items()}
# A local CFG resolver with an explicit normal exit; it distinguishes exit
# from a root continuation, which the global cyclic ordinal graph does not.
def local_graph(rows):
 n=len(rows);bounds={}
 for i,(p,o,a)in enumerate(rows):
  for j in range(len(p)+1):
   pref=p[:j]
   if pref not in bounds:bounds[pref]=[i,i+1]
   else:bounds[pref][1]=i+1
 def target(p,b,k):
  hits=[j for j,c in enumerate(p)if c==b]
  assert len(hits)>=k,('open macro',p,b,k)
  lo,hi=bounds[p[:hits[-k]]];return hi if b=='0'else lo
 out=[]
 for i,(p,o,a)in enumerate(rows):
  effect=['increment',a]if o=='CI'else['decrement',a]if o=='CD'else['halt']if o=='CH'else['identity']
  edges=[i+1]if o=='CI'else[target(p,'0',1),i+1]if o=='CD'else[target(p,'0',a)]if o=='CB'else[target(p,'1',a)]if o=='CC'else[]
  out.append([effect,edges])
 return out
Mgraphs={name:local_graph(rows)for name,rows in impl.items()}
def normalize_increments(graph):
 g=json.loads(json.dumps(graph));n=len(g);i=0
 while i<n:
  if g[i][0][0]!='increment':i+=1;continue
  j=i+1
  while j<n and g[j][0][0]=='increment':j+=1
  for k in range(i,j):assert g[k][1]==[k+1]
  for k in range(i+1,j):
   incoming={z for z,(_,ts)in enumerate(g)if k in ts}
   assert incoming=={k-1},('external entry inside CI run',i,j,k,incoming)
  for k,a in zip(range(i,j),sorted(g[k][0][1]for k in range(i,j))):g[k][0][1]=a
  i=j
 return g
Mgraphs={name:normalize_increments(g)for name,g in Mgraphs.items()}
oldstart,oldend=479,888
seq=[];cursor=oldstart
while cursor<oldend:
 matches=[]
 for name,rows in impl.items():
  k=len(rows)
  if cursor+k>oldend:continue
  literal=[(o,a)for p,o,a in old[cursor:cursor+k]]
  expected=[(o,a)for p,o,a in rows]
  if [o for o,a in literal]!=[o for o,a in expected]:continue
  g=[[eff,[j-cursor for j in ts]]for eff,ts in G[cursor:cursor+k]]
  if normalize_increments(g)==Mgraphs[name]:matches.append(name)
 assert matches,('No archived macro match',cursor)
 name=max(matches,key=lambda n:len(impl[n]));seq.append((cursor,name,len(impl[name])));cursor+=len(impl[name])
assert cursor==oldend
# Retained macro sequence and its exact new-source local CFG.
kept=[(a,name,k)for a,name,k in seq if a not in removed]
for a,name,k in seq:
 assert all((i in removed)==(a in removed)for i in range(a,a+k))
for a,name,k in kept:
 j=project(a);g=[[eff,[z-j for z in ts]]for eff,ts in H[j:j+k]]
 assert normalize_increments(g)==Mgraphs[name],(a,j,name,'new macro CFG')
# Symbolic stack execution justified by ProgLib254.v named macro lemmas.
# Pairing is represented freely here, so no numeric alias is assumed away.
def evaluate(seq):
 top='T';stack=['W'];par={'par1':'A','par2':'B','par3':'C'}
 for a,name,k in seq:
  if name in par:stack.insert(0,top);top=par[name]
  elif name=='push':stack.insert(0,top);top=0
  else:
   x=stack.pop(0);top=(name,x,top)
 return top,stack
oldvalue,oldstack=evaluate(seq);newvalue,newstack=evaluate(kept)
expectedold=('I',('E','C','A'),('I',('E','C','B'),('Q',('M','A','B'),('E','A','B'))))
expectednew=('I',('E','C','A'),('I',('E','C','B'),('E','A','B')))
assert oldvalue==expectedold and newvalue==expectednew
assert oldstack==newstack==['T','W']
def P(a,b):return (a+b)*(a+b+1)//2+b
def val(e,env):
 if isinstance(e,int):return e
 if isinstance(e,str):return env[e]
 op,a,b=e;a=val(a,env);b=val(b,env);return 4*P(a,b)+{'I':0,'M':1,'Q':2,'E':3}[op]
samples=[]
for A,B,C in((0,0,0),(0,1,2),(1,0,3),(2,3,4),(7,5,1)):
 env=dict(A=A,B=B,C=C);samples.append({'A':A,'B':B,'C':C,'old_R7':val(oldvalue,env),'new_R7':val(newvalue,env),'binder':4*P(A,B)+1,'binder_gt_AB':4*P(A,B)+1>max(A,B)})
report={'status':'FINITE_SOURCE_AND_SYMBOLIC_MACRO_EQUATION_PASS','scope':'Does NOT prove logical equiconsistency or binary runtime. Macro equations rely on archived ProgLib254.v contracts; literal implementations and guarded CFGs are checked independently up to certified swaps of independent adjacent increment instructions.','old_sha256':hashlib.sha256((BASE/'sites215.json').read_bytes()).hexdigest(),'new_sha256':hashlib.sha256((ROOT/'formalism_work/r7-no-fresh-binder.json').read_bytes()).hexdigest(),'old_metrics':s.metrics(s.tree(old)),'new_metrics':s.metrics(s.tree(new)),'retained_primitive_occurrences':len(retained),'closed_deleted_intervals':closed,'original_sequence':seq,'retained_sequence':kept,'old_R7':oldvalue,'new_R7':newvalue,'output_stack':oldstack,'numeric_samples':samples,'logical_obligation':'Derive equality vacuity or otherwise prove adequacy after replacing quantified R7. Semantic freshness by itself does not establish that the remaining numerical calculus proves the old R7.'}
(ROOT/'independent_work/r7-source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
