from pathlib import Path
import sys,json
p=Path('ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215').resolve();sys.path.insert(0,str(p/'code'));import build221 as b
T=b.read_table(Path('encoding_work/r7-no-fresh-binder0-215.native.tm').read_bytes());Q=sorted({q for q,a in T}-{7})
# Universal finite-tape macro synthesis: lazily split any previously unobserved
# tape bit, carrying its original value and requiring complete restoration.
def check(row,mark,limit):
 target=90 if mark==0 else 164
 w,d,q=row;orig={-1:mark,0:0};tape={-1:mark,0:w};seen=set();branches=0
 def walk(q,h,tape,orig,depth,trail):
  nonlocal branches
  branches+=1
  if branches>2000:return False
  if q==target and h==1:return tape==orig
  if depth>=limit or abs(h)>6 or q==7 or q==254:return False
  key=(q,h,tuple(sorted(tape.items())),tuple(sorted(orig.items())))
  if key in trail:return False
  trail=trail|{key}
  if h not in tape:
   return all(walk(q,h,{**tape,h:x},{**orig,h:x},depth,trail-set([key]))for x in(0,1))
  x=tape[h];r=row if(q,x)==(171,0)else T[q,x]
  w,d,z=r;return walk(z,h+d,{**tape,h:w},orig,depth+1,trail)
 return walk(q,d,tape,orig,1,frozenset())
for limit in(8,16,24,40):
 found=[]
 for w in(0,1):
  for d in(-1,1):
   for q in Q:
    row=w,d,q
    if check(row,0,limit)and check(row,1,limit):found.append(row)
 print(limit,found,flush=True)
