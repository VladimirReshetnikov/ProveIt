from pathlib import Path
import sys,json,time,signal,collections,gzip
import relaxed_tail as r
s=r.s;v=r.v;p=r.p;T=s.r.table(p/'k215.native.tm');sites=json.loads((p/'sites215.json').read_text());Q=sorted({q for q,a in T} - {198})
m={int(k):int(w)for k,w in json.loads(v.MAPPATH.read_text()).items()}
for q in set(Q)|{254}:m.setdefault(q,q+1000)
cs=json.load(gzip.open(p/'verification/root-run1/runtime/runtime_cases.json.gz'))
def timeout(*_):raise TimeoutError('timeout')
signal.signal(signal.SIGALRM,timeout)
def chk(L,lem,site,pos):
 try:
  signal.setitimer(signal.ITIMER_REAL,0.08)
  z=r.case(L,lem,site,pos)
  signal.setitimer(signal.ITIMER_REAL,0)
  return True
 except Exception:signal.setitimer(signal.ITIMER_REAL,0);return False
probe={}
for c in sorted(cs,key=lambda c:c['symbolic_steps']):
 site=sites[c['site_index']];probe.setdefault((site[1],site[2],c['positive']),(site,c['positive']))
probes=[(sites[0],False),(sites[3],False),(sites[0],True)]+list(probe.values())
def make(zero,one):
 N={k:row for k,row in T.items()if k[0]!=198};N[66,0]=zero;N[66,1]=one
 L={(m[a],b):(x,y,m[c])for(a,b),(x,y,c)in N.items()};return N,L
allrows=[(w,d,q)for w in(0,1)for d in(-1,1)for q in Q]
N,L=make((0,1,254),T[66,1]);lem,_=s.prove_blocks(L)
ones=[];t0=time.monotonic()
for one in allrows:
 N,L=make((0,1,254),one)
 if chk(L,lem,sites[0],True):ones.append(one);print('ONE',one,flush=True)
print('ONE_DONE',len(ones),time.monotonic()-t0,flush=True)
for one in ones:
 for zero in allrows:
  N,L=make(zero,one)
  if not chk(L,lem,sites[0],False):continue
  if not chk(L,lem,sites[3],False):continue
  nr=2
  for site,pos in probes[2:]:
   if not chk(L,lem,site,pos):break
   nr+=1
  print('PARTIAL',zero,one,nr,len(probes),flush=True)
  if nr==len(probes):
   name=f'independent_work/paired66-{zero[0]}{zero[1]}{zero[2]}-{one[0]}{one[1]}{one[2]}.native.tm';Path(name).write_text('#! start 0\n'+''.join(f'{a} {b} {x} {"R"if y==1 else"L"} {c}\n'for(a,b),(x,y,c)in sorted(N.items())));print('FOUND',name,flush=True)
print('DONE',time.monotonic()-t0,flush=True)
