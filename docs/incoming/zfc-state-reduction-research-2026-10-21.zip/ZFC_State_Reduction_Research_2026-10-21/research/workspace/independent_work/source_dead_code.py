#!/usr/bin/env python3
"""Delete source no-ops certified by finite register sign invariants."""
import sys,json,gzip
from pathlib import Path
sys.path[:0]=['independent_work','formalism_work']
import macro_audit as a
import delete_closed as d
s=a.s;R=json.load(open(a.BASE/'sites215.json'));G=s.graph_intervals(R)
V=json.loads(gzip.decompress(Path('independent_work/source-sign-invariant.json.gz').read_bytes()))
assert V[4671][1]==1 and V[4672] is None and V[4673] is None
assert V[4733][6]==1 and V[4734] is None
original=s.graph_arithmetic
out=Path('independent_work/dead_code');out.mkdir(exist_ok=True)
for x,y in [(True,False),(False,True),(True,True)]:
 ranges=[];modified=json.loads(json.dumps(G))
 if x:ranges.append((4671,4674))
 if y:
  ranges.append((4733,4735));modified[4733][1]=[4735];modified[4734][1]=[4735]
 def graph(rows):
  if rows==R:return modified,original(rows)[1]
  return original(rows)
 s.graph_arithmetic=graph
 try:rr=d.remove(R,ranges)
 finally:s.graph_arithmetic=original
 n=s.tree(rr);met=s.metrics(n);name=f'dead-mp{int(x)}halt{int(y)}';print(name,met,flush=True)
 (out/(name+'.sites.json.gz')).write_bytes(gzip.compress(s.compact(rr),mtime=0))
 (out/(name+'.json')).write_text(json.dumps({'metrics':met,'deleted_intervals':ranges,'source_sign_invariant':'source-sign-invariant.json.gz','semantic_reason':'Every removed decrement reads a provably zero register; every other removed primitive is unreachable.'},indent=2))
