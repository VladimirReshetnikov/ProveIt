import sys,json,gzip,collections
from pathlib import Path
sys.path.insert(0,'independent_work');import relaxed_tail as r
T=r.s.r.table(r.p/'k215.native.tm');sites=json.load(open(r.p/'sites215.json'));cs=json.load(gzip.open(r.p/'verification/root-run1/runtime/runtime_cases.json.gz'));M={int(k):int(v)for k,v in json.load(open(r.v.MAPPATH)).items()}
Q=sorted({q for q,b in T})
for q in set(Q)|{254}:M.setdefault(q,q+1000)
inv={v:k for k,v in M.items()};uses=collections.defaultdict(set)
for i,c in enumerate(cs):
 for q,b in c['rows']:uses[inv[q]].add(i)
selected={};pool=set()
for q in Q:
 todo=sorted(uses[q],key=lambda i:cs[i]['symbolic_steps']);by={}
 for i in todo:
  z=cs[i];site=sites[z['site_index']];by.setdefault((site[1],site[2],z['positive']),i)
 picks=list(by.values())
 if todo:picks+=todo[:2]+todo[-2:]
 picks=list(dict.fromkeys(picks));selected[q]=picks;pool.update(picks)
ids=list(range(len(cs)));idx={v:i for i,v in enumerate(ids)}
V=json.loads(gzip.decompress(Path('independent_work/source-sign-invariant.json.gz').read_bytes()))
p=Path('independent_work/semantic-fold-input.txt')
with p.open('w') as f:
 print(len(Q),file=f)
 for q in Q:print(q,*T[q,0],*T[q,1],file=f)
 print(len(ids),file=f)
 for i in ids:
  c=cs[i];pc,o,a=sites[c['site_index']]
  if o=='CI' or o=='CD' and c['positive']:nxt,_=r.s.r.inc(pc)
  elif o in('CD','CB'):nxt,_=r.s.r.inc(r.s.r.strip(pc,'0',a if o=='CB'else 1))
  elif o=='CC':nxt=r.s.r.strip(pc,'1',a)
  else:nxt=''
  print(c['site_index'],int(c['positive']),pc,{'CI':0,'CD':1,'CB':2,'CC':3,'CH':4}[o],a if a is not None else -1,nxt or '-',*(V[c['site_index']] or [0]*9),file=f)
 print(len(Q),file=f)
 for q in Q:print(q,len(selected[q]),*(idx[i]for i in selected[q]),file=f)
print({'cases':len(ids),'drops':len(Q),'bytes':p.stat().st_size})
