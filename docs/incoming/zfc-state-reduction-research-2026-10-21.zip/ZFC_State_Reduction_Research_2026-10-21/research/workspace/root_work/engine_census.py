#!/usr/bin/env python3
"""Fresh post-decoder engine-row census; synthesis guidance, not correctness alone."""
from pathlib import Path
import sys,json,time,collections
base=Path(__file__).resolve().parents[1]/'ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(base/'code/runtime-inputs/runtime'))
import symbolic_runtime as s
T=s.r.table(base/'k215.native.tm');sites=json.loads((base/'sites215.json').read_text())
m={int(k):int(v)for k,v in json.loads((base/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in {q for q,b in T}|{254}:m.setdefault(q,q+1000)
inv={v:k for k,v in m.items()};L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}
lemmas,blocks=s.prove_blocks(L);used=collections.Counter();entries=collections.defaultdict(set);cases=0;t0=time.monotonic()
for block in blocks:
    for event in block['trace']:
        if event[0]!='list':used[inv[event[1][0]],event[1][1]]+=1
for i,site in enumerate(sites):
    for positive in ((False,True)if site[1]=='CD'else(False,)):
        ans=s.case(L,lemmas,site,positive,keep_trace=True);inside=False;pos=0
        for event in ans['trace']:
            kind=event[0]
            if inside:
                if kind!='list':used[inv[event[1][0]],event[1][1]]+=1
                continue
            assert kind=='literal',('nonliteral decoder',i,event)
            _,row=event;q,b,w,d,z=row
            if pos==len(site[0])-1:
                inside=True;entries[site[1],site[2],b].add((w,d,inv[z]))
            pos+=d
        assert inside;cases+=1
    if(i+1)%1000==0:print('PROGRESS',i+1,cases,len(used),round(time.monotonic()-t0,2),flush=True)
out={'status':'FRESH_ENGINE_CENSUS','scope':'Synthesis filter. Complete primitive proofs freshly run on parent; new allocation must be checked separately.','cases':cases,'rows':sorted(used),'uses':[[*k,v]for k,v in sorted(used.items())],'entries':[[*k,sorted(v)]for k,v in entries.items()],'blocks':blocks,'seconds':time.monotonic()-t0}
p=Path(__file__).with_name('engine_rows215.json');p.write_text(json.dumps(out,indent=2)+'\n');print('DONE',len(used),'states',len({q for q,b in used}),'seconds',time.monotonic()-t0,flush=True)
