from pathlib import Path
import sys,json
K=Path('/workspace/scratch/e33dac3aae74/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(K));import source_language as s
root=s.tree(json.loads((K/'sites215.json').read_text()));nip=s.subtree(root,'111');print('nip',nip)
test=(('CD',5),((('CD',5),('CC',2)),('CH',None)))
new=s.replace(root,'111',(test,nip[1][1]))
Path('/workspace/scratch/e33dac3aae74/root_work/odd_halt.json').write_text(json.dumps(s.sites(new),indent=2)+'\n');print(s.boundary(test),s.metrics(new))
print('test',test)
