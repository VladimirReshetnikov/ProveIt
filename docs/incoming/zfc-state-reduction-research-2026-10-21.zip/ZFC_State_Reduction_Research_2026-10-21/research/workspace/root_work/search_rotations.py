#!/usr/bin/env python3
"""Bounded synthesis search; every output still needs semantic/runtime checks."""
from pathlib import Path
import sys,json,random,math,time,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215'))
import source_language as s

ap=argparse.ArgumentParser();ap.add_argument('--steps',type=int,default=100000);ap.add_argument('--seed',type=int,default=214);a=ap.parse_args()
base=Path(__file__).resolve().parents[1]/'ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215'
ns=[];ids={};bounds=[];zeros=[];leads=[];depths=[];opts={};crit=[];cleads=[]
def put(n):
    if n in ids:return ids[n]
    i=len(ns);ids[n]=i;ns.append(n)
    if isinstance(n[0],str):
        op,r=n;b=(1,0)if op=='CD'else(r,0)if op=='CB'else(0,r)if op=='CC'else(0,0)
        bounds.append(b);zeros.append(0);leads.append(0);depths.append(0);crit.append(0 if op in('CI','CD')else -1000);cleads.append(crit[-1])
    else:
        u,v=n;bu,bv=bounds[u],bounds[v]
        bounds.append((max(bu[0]-1,bv[0],0),max(bu[1],bv[1]-1,0)))
        leads.append(1+leads[u]);zeros.append(max(1+leads[u],zeros[u],zeros[v]));depths.append(1+max(depths[u],depths[v]))
        cleads.append(1+cleads[u]);crit.append(max(1+cleads[u],crit[u],crit[v]))
    return i
def pack(n):return put(n if s.leaf(n)else(pack(n[0]),pack(n[1])))
def thaw(i):return ns[i]if isinstance(ns[i][0],str)else tuple(thaw(x)for x in ns[i])
start=pack(s.tree(json.loads((base/'sites215.json').read_text())))
def collect(r):
    seen=set();todo=[r]
    while todo:
        n=todo.pop()
        if n in seen:continue
        seen.add(n)
        if isinstance(ns[n][0],int):todo.extend(ns[n])
    return seen
def options(n):
    if n in opts:return opts[n]
    out=[]
    if isinstance(ns[n][0],int):
        l,r=ns[n]
        if isinstance(ns[r][0],int):
            b,c=ns[r]
            if all(bounds[x]==(0,0)for x in(l,b,c)):out.append(put((put((l,b)),c)))
        if isinstance(ns[l][0],int):
            a,b=ns[l]
            if all(bounds[x]==(0,0)for x in(a,b,r)):out.append(put((a,put((b,r)))))
    opts[n]=out;return out
def replace(r,old,new):
    memo={}
    def go(i):
        if i==old:return new
        if i in memo:return memo[i]
        n=ns[i]
        ans=i if isinstance(n[0],str)else put(tuple(go(x)for x in n))
        memo[i]=ans;return ans
    return go(r)
def score(r,seen):return len(seen)+max(0,crit[r]-4)+max(0,zeros[r]-6)*3
rng=random.Random(a.seed);r=start;seen=collect(r);cost=score(r,seen);best=cost;bestnum=202;found=set();starttime=time.monotonic()
archive=[start];last=0
for step in range(a.steps):
    if step%2000==0:
        r=rng.choice(archive);seen=collect(r);cost=score(r,seen)
    movable=[n for n in seen if options(n)]
    old=rng.choice(movable);new=rng.choice(options(old));trial=replace(r,old,new)
    ts=collect(trial);tc=score(trial,ts)
    temperature=max(0.07,0.65*(1-(step%2000)/2000))
    if tc<=cost or rng.random()<math.exp((cost-tc)/temperature):r,seen,cost=trial,ts,tc
    if tc<best or (len(ts)<bestnum and zeros[trial]<=6):
        best=min(best,tc);bestnum=min(bestnum,len(ts));archive.append(trial)
        print('BEST',step,len(ts),zeros[trial],depths[trial],'nodes',len(ns),'seconds',round(time.monotonic()-starttime,1),flush=True)
    if len(ts)+zeros[trial]<208 and zeros[trial]<=6 and (len(ts),zeros[trial])not in found:
        found.add((len(ts),zeros[trial]));t=thaw(trial);rows=s.sites(t)
        assert s.graph_intervals(rows)==s.graph_intervals(s.sites(thaw(start)))
        p=Path(__file__).parent/f'rotation_n{len(ts)}_z{zeros[trial]}_seed{a.seed}.json';p.write_bytes(s.compact(rows))
        print('SAVED',p,flush=True)
    if step%5000==0:print('PROGRESS',step,'current',len(seen),zeros[r],'best',best,'interned',len(ns),'seconds',round(time.monotonic()-starttime,1),flush=True)
print('DONE','best',best,'found',sorted(found),'seconds',round(time.monotonic()-starttime,1),flush=True)
