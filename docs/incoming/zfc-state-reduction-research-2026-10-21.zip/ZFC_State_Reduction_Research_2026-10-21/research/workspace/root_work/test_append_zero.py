from pathlib import Path
import sys,json,time
K=Path('/workspace/scratch/e33dac3aae74/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(K/'code/runtime-inputs'))
import validate_native as v
s=v.s;T=s.r.table(K/'k215.native.tm');T[66,0]=(1,-1,54)
for b in(0,1):del T[198,b]
out=Path('/workspace/scratch/e33dac3aae74/root_work')
raw='#! start 0\n'+''.join(f'{q} {b} {w} {"L" if d==-1 else "R"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))
(out/'append_zero214b.native.tm').write_text(raw)
st=v.startup(T,200000)
print('STARTUP',json.dumps({k:x for k,x in st.items()if k not in('trace','one_cells')}),flush=True)
m={int(k):int(w)for k,w in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in {q for q,b in T}|{254}:m.setdefault(q,q+1000)
L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()};lemmas,blocks=s.prove_blocks(L)
ss=json.loads((K/'sites215.json').read_text());nc=0;fails=[];start=time.monotonic()
for i,site in enumerate(ss):
 for pos in((False,True)if site[1]=='CD'else(False,)):
  try:s.case(L,lemmas,site,pos,append=0);nc+=1
  except Exception as e:fails.append({'index':i,'site':site,'positive':pos,'error':str(e)});print('FAIL',fails[-1],flush=True)
 if len(fails)>=3:break
 if (i+1)%1000==0:print('PROGRESS',i+1,nc,flush=True)
(out/'append_zero214b.result.json').write_text(json.dumps({'startup':{k:x for k,x in st.items()if k not in('trace','one_cells')},'cases':nc,'failures':fails,'seconds':time.monotonic()-start},indent=2))
