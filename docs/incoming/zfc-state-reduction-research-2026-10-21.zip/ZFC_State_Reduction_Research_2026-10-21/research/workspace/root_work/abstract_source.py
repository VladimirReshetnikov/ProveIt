#!/usr/bin/env python3
"""Finite sound abstract interpretation of source register values."""
from pathlib import Path
from collections import deque,Counter
import sys,json
base=Path(__file__).resolve().parents[1]/'ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(base));import source_language as s
rows=json.loads((base/'sites215.json').read_text());graph=s.graph_intervals(rows);K=4
TOP=(1<<(K+1))-1
inc=[0]*(TOP+1);dec=[0]*(TOP+1)
for mask in range(TOP+1):
 for x in range(K+1):
  if mask>>x&1:
   inc[mask]|=1<<min(K,x+1)
   if x:
    dec[mask]|=1<<(x-1)
    if x==K:dec[mask]|=1<<K
facts=[None]*len(rows);facts[0]=tuple([1<<K]+[1]*8);work=deque([0]);queued={0};iterations=0
def send(j,r):
 old=facts[j];new=tuple(r)if old is None else tuple(x|y for x,y in zip(old,r))
 if old!=new:
  facts[j]=new
  if j not in queued:work.append(j);queued.add(j)
while work:
 i=work.popleft();queued.remove(i);v=list(facts[i]);_,op,k=rows[i];targets=graph[i][1];iterations+=1
 if op=='CI':v[k]=inc[v[k]];send(targets[0],v)
 elif op=='CD':
  if v[k]&1:
   w=v.copy();w[k]=1;send(targets[0],w)
  if v[k]&~1:
   w=v.copy();w[k]=dec[v[k]&~1];send(targets[1],w)
 elif op!='CH':send(targets[0],v)
unreachable=[i for i,v in enumerate(facts)if v is None]
zero=[i for i,(_,op,k)in enumerate(rows)if op=='CD'and facts[i]is not None and facts[i][k]==1]
positive=[i for i,(_,op,k)in enumerate(rows)if op=='CD'and facts[i]is not None and not facts[i][k]&1]
record={'abstract_max':K,'iterations':iterations,'unreachable':unreachable,'always_zero':zero,'always_positive':positive,'zero_sites':[rows[i]for i in zero],'positive_sites':[rows[i]for i in positive],'facts':facts}
Path(__file__).with_name('abstract_source.json').write_text(json.dumps(record,separators=(',',':'))+'\n')
print('ABSTRACT FIXPOINT',iterations,'unreachable',len(unreachable),'zero',len(zero),'positive',len(positive))
print('ZERO',[(i,rows[i])for i in zero]);print('POSITIVE',[(i,rows[i])for i in positive])
new=[r.copy()for r in rows]
for i in zero:new[i][1:]=['CB',1]
tr=s.tree(new);print('ALL ZERO REPLACED',s.metrics(tr));Path(__file__).with_name('zero_specialized.json').write_bytes(s.compact(new))
