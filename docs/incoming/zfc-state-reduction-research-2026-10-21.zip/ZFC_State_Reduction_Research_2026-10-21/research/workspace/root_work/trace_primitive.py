from pathlib import Path
import sys,json
K=Path('/workspace/scratch/e33dac3aae74/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215');sys.path.insert(0,str(K/'code/runtime-inputs'));import validate_native as v
s=v.s;T=s.r.table(K/'k215.native.tm');m={int(k):int(w)for k,w in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in {q for q,b in T}|{254}:m.setdefault(q,q+1000)
inv={v:k for k,v in m.items()};L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()};lemmas,blocks=s.prove_blocks(L)
for pos in(False,True):
 site=['111100000','CD',5];a=s.case(L,lemmas,site,pos,keep_trace=True);print('CASE',pos)
 for ev in a['trace']:
  if ev[0]=='list':print('LIST',inv[ev[1][0]],ev[1][1:])
  else:
   q,b,w,d,z=ev[1];print(ev[0],inv[q],b,w,d,inv[z],''if len(ev)<3 else ev[2])
