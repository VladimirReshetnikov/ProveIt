from pathlib import Path
import sys,json,collections
K=Path('/workspace/scratch/e33dac3aae74/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215');sys.path[:0]=[str(K),str(K/'code')]
import source_language as s,build221 as b
r=s.tree(json.loads((K/'sites215.json').read_text()));T=b.read_table((K/'k215.native.tm').read_bytes());g,paths=b.decoder_map(T,r)
allsub={};
def walk(n,p=''):
 allsub.setdefault(n,[]).append(p)
 if not s.leaf(n):walk(n[0],p+'0');walk(n[1],p+'1')
walk(r)
for n,pp in allsub.items():
 if all(p.startswith('111') for p in pp):
  print('UNIQUE',pp,'states',[q for q,ns in g.items()if n in ns],'size',len(s.sites(n)),n)
print('NIPROOTS',[(q,ns)for q,ns in g.items()if s.subtree(r,'111')in ns]);print('leafCD5')
for p,op,a in s.sites(r):
 if op=='CD' and a==5:
  pre=p[:-1];parent=s.subtree(r,pre);qs=[q for q,ns in g.items()if parent in ns]
  for q in qs:print(p,q,T[q,int(p[-1])]);
  if p.startswith('111'):print('NIP CD5',p)
