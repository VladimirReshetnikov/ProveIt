import sys,json
from pathlib import Path
sys.path[:0]=['encoding_work'];import replace_closed as c
s=c.s;a=c.a
rows=s.sites(a.old)
rr=c.replace(rows,717,721,('CI',1));tr=s.tree(rr)
met=s.metrics(tr);Path('root_work/r7-pair-plus-one.sites.json').write_bytes(s.compact(rr));print('METRICS',met,flush=True)
E={tuple(x)for x in json.load(open('encoding_work/engine_rows219_repaired.json'))['rows']}
info,T,S=a.tryperm(tuple(range(9)),E,20,tr);info.update(metrics=met);print(json.dumps({k:v for k,v in info.items()if k!='changed_rows'}),flush=True);Path('root_work/r7-pair-plus-one.result.json').write_text(json.dumps(info,indent=2))
if T:Path('root_work/r7-pair-plus-one.native.tm').write_bytes(a.b.table_bytes(T))
