from pathlib import Path
from collections import defaultdict
import sys,json,time
sys.path.insert(0,'encoding_work');import permute_allocate as a
s=a.s;old=a.old;O=Path('root_work/dead_contexts');O.mkdir(exist_ok=True)
allnodes=set(n for p,n in a.paths(old));dead=[('1101001011100',('CD',1)),('111100110',('CD',6))]
options=[[n for n in allnodes if n[0]==guard]for path,guard in dead]
print('OPTIONS',list(map(len,options)),flush=True)
E={tuple(x)for x in json.loads(Path('encoding_work/engine_rows219_repaired.json').read_text())['rows']}
results=[];best=999
for i,n in enumerate(options[0]):
 for j,m in enumerate(options[1]):
  t=s.replace(s.replace(old,dead[0][0],n),dead[1][0],m)
  met=s.metrics(t)
  if met['maximum_zero_run']>6:continue
  if met['dag_nodes']>202:continue
  info,N,tr=a.tryperm(tuple(range(9)),E,3,t)
  r={'i':i,'j':j,'metrics':met,**info};results.append(r)
  print(json.dumps({k:v for k,v in r.items()if k!='changed_rows'}),flush=True)
  if N and info.get('states',999)<=215:
   stem=f'dead-{i}-{j}-{info["states"]}'
   (O/(stem+'.native.tm')).write_bytes(a.b.table_bytes(N));(O/(stem+'.sites.json')).write_bytes(s.compact(s.sites(tr)));(O/(stem+'.json')).write_text(json.dumps(r,indent=2))
(O/'results.json').write_text(json.dumps(results,indent=2))
