import json,sys,itertools,time,os
from pathlib import Path
ROOT=Path('/workspace/scratch/e33dac3aae74');os.chdir(ROOT/'formalism_work');sys.path.insert(0,str(ROOT/'formalism_work'));sys.path.insert(0,str(ROOT/'encoding_work'))
import delete_closed as dc
exec(Path('ineq_search.py').read_text().split('start=time.time();best=')[0])
import permute_allocate as alloc
out=ROOT/'root_work'/'ineq_simplified';out.mkdir(exist_ok=True)
E={tuple(x)for x in json.loads((ROOT/'encoding_work/engine_rows219_repaired.json').read_text())['rows']}
results=[];best=999
for er,br,bind in itertools.product(range(2),range(2),range(1,5)):
 reg=make_reverse(er,br);local=999;lh=[]
 for k,c in enumerate(itertools.product(*choices[:-1])):
  t=build(c,reg,bind);rows=s.sites(t)
  shift=5*47+(bind-1 if bind<4 else 49)
  # Every earlier Eq construction gets one NEG; binder additions are before rho1.
  lo=axoff+2495+shift;hi=axoff+2542+shift
  assert [(o,a)for p,o,a in rows[lo:hi]]==word(neg)
  tr=s.tree(dc.remove(rows,[(lo,hi)]))
  n=s.metrics(tr)
  if n['maximum_zero_run']>6:continue
  if n['dag_nodes']<local:local=n['dag_nodes'];lh=[]
  if n['dag_nodes']==local:lh.append((k,c,tr,n))
 print('FAMILY',er,br,bind,local,len(lh),flush=True)
 for k,c,tr,met in lh[:8]:
  if local>206:continue
  name=f'e{er}b{br}t{bind}c{k}-{local}'
  r={'name':name,'metrics':met};results.append(r)
  (out/(name+'.sites.json')).write_bytes(s.compact(s.sites(tr)))
  if local<=202:
   info,N,new=alloc.tryperm(tuple(range(9)),E,5,tr);r['allocation']=info
   if N:(out/(name+f'-{info["states"]}.native.tm')).write_bytes(alloc.b.table_bytes(N))
  print(json.dumps(r),flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2))
