#!/usr/bin/env python3
import sys,runpy,random,heapq,time
from pathlib import Path
sys.argv=[sys.argv[0],'--steps','0']
g=runpy.run_path(str(Path(__file__).with_name('search_rotations.py')))
globals().update(g)
rng=random.Random(214);seenroots={start};pending=[(0,rng.random(),start)];best=208;expanded=0;t0=time.monotonic()
while pending and expanded<2500:
    _,_,r=heapq.heappop(pending);seen=collect(r);expanded+=1
    candidates=[]
    for n in list(seen):
        for v in options(n):
            tr=replace(r,n,v)
            if tr in seenroots:continue
            seenroots.add(tr);ts=collect(tr);cost=len(ts)+crit[tr]
            if zeros[tr]>6 or len(ts)>203:continue
            if cost<best:
                best=cost;print('BEST',expanded,len(ts),zeros[tr],crit[tr],len(ns),flush=True)
                rows=s.sites(thaw(tr));assert s.graph_intervals(rows)==s.graph_intervals(s.sites(thaw(start)))
                p=Path(__file__).parent/f'beam_n{len(ts)}_z{zeros[tr]}_c{crit[tr]}.json';p.write_bytes(s.compact(rows));print('SAVED',p,flush=True)
            # Most searches remain on the zero-cost plateau, with occasional +1 excursion.
            priority=5*(len(ts)-202)+3*(crit[tr]-6)+0.0001*depths[tr]+rng.random()
            candidates.append((priority,rng.random(),tr))
    for x in candidates:heapq.heappush(pending,x)
    if len(pending)>8000:pending=heapq.nsmallest(5000,pending);heapq.heapify(pending)
    if expanded%100==0:print('PROGRESS',expanded,'frontier',len(pending),'seen',len(seenroots),'interned',len(ns),'best',best,'secs',round(time.monotonic()-t0,1),flush=True)
    if best<208:break
print('FINISHED',expanded,best,len(ns),'secs',round(time.monotonic()-t0,1),flush=True)
