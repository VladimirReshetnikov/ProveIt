#!/usr/bin/env python3
"""First-spare-one quantified primitive proof and exact native-row census.

Only the frame's first spare value is specialized. The remaining finite
spare list, primary register values and gap remain arbitrary. One-block
traversal schemas still quantify over arbitrary natural block values.
No upstream file is modified. No expanded case or transition traces are saved.
"""
from pathlib import Path
import argparse,collections,hashlib,importlib.util,json,sys,time
HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215'
RUNTIME=BASE/'code/runtime-inputs/runtime'
sys.path.insert(0,str(RUNTIME))
spec=importlib.util.spec_from_file_location('spare1_checker',HERE/'symbolic_runtime_spare1.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--table',type=Path,default=BASE/'k215.native.tm');ap.add_argument('--sites',type=Path,default=BASE/'sites215.json');ap.add_argument('--output',type=Path,default=HERE/'spare1-row-census.json');args=ap.parse_args()
 T=s.r.table(args.table);sites=json.loads(args.sites.read_text());working={q for q,b in T}
 assert len(working)==215 and len(T)==430
 assert all((q,b) in T for q in working for b in (0,1))
 assert {z for w,d,z in T.values()}-working=={254}
 leaves={pc for pc,op,arg in sites};prefixes={pc[:i] for pc in leaves for i in range(len(pc))}
 assert len(leaves)==len(sites) and not leaves&prefixes
 assert all(p+b in leaves|prefixes for p in prefixes for b in ('0','1'))
 m={int(k):int(v) for k,v in json.loads((BASE/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
 for q in working|{254}:
  if q not in m:m[q]=q+1000
 inv={v:k for k,v in m.items()};assert len(inv)==len(m)
 L={(m[q],b):(w,d,m[z]) for (q,b),(w,d,z) in T.items()}
 started=time.monotonic();lemmas,blocks=s.prove_blocks(L)
 block_counts=collections.Counter();block_entries=collections.defaultdict(list)
 for block in blocks:
  rows=set(event[1][:2] for event in block['trace'] if event[0]!='list')
  for q,b in rows:
   row=inv[q],b;block_counts[row]+=1;block_entries[row].append(inv[block['entry']])
 direct=collections.Counter();first={};tracked=collections.defaultdict(list)
 count=0;symbolic=0;minimum=None;case_hash=hashlib.sha256();failures=[]
 for i,site in enumerate(sites):
  for positive in ((False,True) if site[1]=='CD' else (False,)):
   try:ans=s.case(L,lemmas,site,positive)
   except Exception as e:
    failures.append({'site_index':i,'site':site,'positive':positive,'reason':str(e)})
    print('FAIL',failures[-1],flush=True);continue
   rows={(inv[q],b) for q,b in ans['rows']}
   for row in rows:
    direct[row]+=1
    first.setdefault(row,{'case_index':count,'site_index':i,'site':site,'positive':positive})
    if row in ((66,1),(198,1)) and len(tracked[row])<12:tracked[row].append({'site_index':i,'site':site,'positive':positive})
   case_hash.update(json.dumps({'i':i,'positive':positive,'duration':ans['duration'],'motion':ans['motion'],'rows':sorted(rows),'symbolic_steps':ans['symbolic_steps']},sort_keys=True,separators=(',',':')).encode()+b'\n')
   symbolic+=ans['symbolic_steps'];minimum=ans['duration'][0] if minimum is None else min(minimum,ans['duration'][0]);count+=1
   if count%1000==0:print('PROVED',count,'SECONDS',round(time.monotonic()-started,2),flush=True)
 total=sum(2 if op=='CD' else 1 for pc,op,arg in sites)
 census=[]
 for q,b in sorted(T):
  w,d,z=T[q,b]
  census.append({'state':q,'read':b,'write':w,'direction':'R' if d==1 else 'L','target':z,'direct_case_count':direct[q,b],'block_schema_count':block_counts[q,b],'block_schema_entries':block_entries[q,b],'first_direct_witness':first.get((q,b))})
 unused=[list(row) for row in sorted(T) if not direct[row] and not block_counts[row]]
 report={'status':'UNIVERSAL_FIRST_SPARE_ONE_PASS' if count==total and not failures else 'NOT_PROVED','scope':'All independent natural primary register values at the relevant guard; arbitrary natural gap; first spare exactly1; arbitrary remaining finite spare list (includingempty); whole zero exterior. Generic block schemas still cover arbitrary natural values.','table_sha256':digest(args.table),'sites_sha256':digest(args.sites),'upstream_checker_sha256':digest(RUNTIME/'symbolic_runtime.py'),'specialized_checker_sha256':digest(HERE/'symbolic_runtime_spare1.py'),'helper_sha256':digest(Path(s.r.__file__)),'census_driver_sha256':digest(Path(__file__)),'expected_cases':total,'proved_cases':count,'failures':failures,'symbolic_rules':symbolic,'minimum_duration_constant':minimum,'elapsed_seconds':time.monotonic()-started,'ordered_case_digest':case_hash.hexdigest(),'directly_used_rows':len(direct),'block_schema_rows':len(block_counts),'total_covered_rows':len(set(direct)|set(block_counts)),'unused_rows':unused,'target_rows':{str(q)+'/'+str(b):{'case_count':direct[q,b],'block_schema_count':block_counts[q,b],'witnesses':tracked[q,b]} for q,b in ((66,1),(198,1))},'row_census':census}
 args.output.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k not in ('row_census','target_rows')},indent=2),flush=True)
 print('TARGET_ROWS',json.dumps(report['target_rows']),flush=True)
if __name__=='__main__':main()
