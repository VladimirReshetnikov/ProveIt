import json,itertools,time,gzip
from pathlib import Path
exec(Path('symbolic_ax.py').read_text().split('marked=')[0])
from delete_closed import remove
oldrows=s.sites(r)
# J(a,b,c) with (a,b,c)=(C,A,B): N(C,A),k(C,A),not N(B,C),N(B,A),I,Q,I.
renames={562:4,618:5,644:3,698:5,724:4}
rows=[q.copy()for q in oldrows]
for i,reg in renames.items():
 for j in range(25+i,25+i+26):
  p,o,a=rows[j]
  if o in ('CI','CD')and a in(3,4,5):rows[j][2]=reg
import sys
tag=int(sys.argv[1]) if len(sys.argv)>1 else 3
ranges=([(25+615+tag,25+618)] if tag<3 else [])+[(25+807,25+809),(25+2495,25+2542)]
base_rows=remove(rows,ranges);base=s.tree(base_rows)
nip=s.subtree(base,'111');test=(('CD',5),((('CD',5),('CC',2)),('CH',None)))
base=s.replace(base,'111',(test,nip[1][1]));base_rows=s.sites(base)
def findword(w):return next(n for ns in g.values()for n in ns if word(n)==w)
copyA=findword(par1[19:]);neg=findword(push+[('CI',1)]+cons);CI=('CI',1)
insertions=[(698,((CI,CI),neg)),(836,(CI,CI)),(1228,neg),(1823,neg)]
def newindex(old):return old-sum(max(0,min(old,b)-a)for a,b in ranges)
def endings(index):
 p=base_rows[index-1][0];result=[]
 for k in range(len(p),0,-1):
  if '0'in p[k:]:break
  q=p[:k];t=s.subtree(base,q)
  if s.boundary(t)==(0,0,False):result.append(q)
 return result
choices=[endings(newindex(25+i))for i,t in insertions]
print('BASE',s.metrics(base),'CHOICES',list(map(len,choices)),choices,flush=True)
def build(cs):
 wraps={p:t for p,(i,t)in zip(cs,insertions)};prefix={''}
 for p in wraps:
  for k in range(len(p)+1):prefix.add(p[:k])
 def go(t,p=''):
  if p not in prefix:return t
  q=t if s.leaf(t)else(go(t[0],p+'0'),go(t[1],p+'1'))
  if p in wraps:q=(q,wraps[p])
  return q
 return go(base)
def count(t):
 seen=set()
 def go(q):
  if q in seen:return
  seen.add(q)
  if not s.leaf(q):go(q[0]);go(q[1])
 go(t);return len(seen)
start=time.time();best={6:999,7:999};hits={6:[],7:[]};saved={6:0,7:0}
for k,cs in enumerate(itertools.product(*choices)):
 t=build(cs);n=count(t)
 if n>max(best.values()):continue
 m=s.metrics(t)
 for limit in(6,7):
  if m['maximum_zero_run']>limit:continue
  if n<best[limit]:best[limit]=n;hits[limit]=[];saved[limit]=0;print('BEST',limit,n,k,m,flush=True)
  if n==best[limit]:
   hits[limit].append((k,cs,m))
   if saved[limit]<3:
    with gzip.open(f'inequality-Jnative-t{tag}-z{limit}-{n}-{k}.json.gz','wb')as f:f.write(s.compact(s.sites(t)))
    saved[limit]+=1
print('DONE',best,'seconds',round(time.time()-start,2),'hits',{q:len(v)for q,v in hits.items()},flush=True)
Path(f'inequality-Jnative-t{tag}-results.json').write_text(json.dumps({'best':best,'hits':hits},indent=2))
