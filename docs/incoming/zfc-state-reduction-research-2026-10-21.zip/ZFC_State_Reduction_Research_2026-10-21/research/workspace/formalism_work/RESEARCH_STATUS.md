# Formalism search status

These are working artifacts, not a completed candidate packet.

## Calibrated transformations

* Independent permutations of the three parameter registers inside each
  of the seven closed retained logical-row builders preserve the emitted
  axiom families. The complete 6^7 search on the original K215 source has
  minimum 202 unique source subtrees. Four choices attain that minimum:
  identity; interchange B/C in rho6; interchange B/C in rho4 and rho2;
  and all three interchanges together.
* A canonical equality helper may use any computable binder function
  kappa(a,b) different from a,b off the diagonal. Source125 explicitly
  proves this generality, with a membership-indiscernibility interpretation
  and the actual-code K adapter. Source128's fused-row proof transfers
  the same generality to the existing R7 constructor.
* The asymmetric crossed helper E(a,b) -> All_kappa(a,b) E(b,a) can replace
  the fused R7 when kappa exceeds both endpoints and is asymmetric off
  the diagonal. This is an equiconsistency transformation; equality of
  all numerical theorem sets is neither needed nor claimed. In particular,
  kappa(a,b)=E(b,a) allows the matrix and binder to be computed once.
  `crossed_self_helper.tex` records the precise proof and provenance.

## Rejected shortcut

`r7-no-fresh-binder.json` has 200 unique subtrees and its source control
flow after macro deletion is checked. It is **not a calibrated candidate**.
The current R7's quantifier deliberately carries the canonical equality
helper introduced in Source125 and fused in Source128. Removing it also
removes that logical resource. Ordinary semantic vacuity of a fresh
quantifier does not justify deleting the resource from this weaker
numerical calculus. The old theory bundle supplies membership vacuity,
not full primitive equality vacuity. The independent source audit confirmed
this issue. All `row_permutations_nobinder` artifacts inherit this caveat.

## Checked but non-improving routes

* Halting on any membership-atom theorem (code 1 modulo 4) is refutationally
  equivalent to halting on code1; `membership_halt.tex` gives a direct
  syntactic GEN/specialization proof. The straightforward source grows.
* Defining primitive equality as the negation of a tag3 inequality atom
  permits an odd-code halt test. The tested source costs205 subtrees;
  complete per-row parameter permutations do not reduce that minimum.
* The cofinal successful proof-code padding meets every residue class
  modulo any fixed power of2. `stride_padding.tex` proves this, permitting
  dyadic-stride enumeration if a cheaper implementation is found.

Source counts are logical DAG costs. A physical table allocation, a
complete quantified primitive simulation and a calibrated blank startup
are separate obligations.
