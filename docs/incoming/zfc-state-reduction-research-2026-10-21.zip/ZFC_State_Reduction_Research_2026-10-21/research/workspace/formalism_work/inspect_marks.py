import json
from functools import lru_cache
tokens=json.load(open('ax-tokens.json'))
T='T';W=[];D='U';H='H';C='C'
marks={863,1442,2037,2387}
def st(x):
 if isinstance(x,str):return x
 a,b=x[1:];return{'I':lambda:f'({st(a)} -> {st(b)})','Q':lambda:f'forall {st(a)}.({st(b)})','M':lambda:f'{st(a)} in {st(b)}','E':lambda:f'{st(a)} = {st(b)}'}[x[0]]()
for k,(i,name,ln)in enumerate(tokens):
 if i in marks: print('MARK',i,'TOP',st(T),'STACK', [st(x)for x in W]);print('NEXTTOKENS',tokens[k:k+8])
 if name in ['par1','par2','par3','v1','push']:
  W.append(T);T={'par1':D,'par2':H,'par3':C,'v1':'F','push':'Truth'}[name]
 elif name in ['cons','wel','wal','weq']:
  assert W,(i,name)
  T=({'cons':'I','wel':'M','wal':'Q','weq':'E'}[name],W.pop(),T)
 elif name=='read1':D='A'
 elif name=='read2':H='B'
 elif i==0 and name=="('CD', 3)":pass
 else: print('STOP',i,name);break
print('LASTTOP',st(T)); print('LASTSTACK', [st(x)for x in W])
