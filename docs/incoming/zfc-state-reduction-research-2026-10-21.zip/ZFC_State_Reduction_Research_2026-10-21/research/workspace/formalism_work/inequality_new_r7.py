import json,itertools,time,gzip
from pathlib import Path
exec(Path('symbolic_ax.py').read_text().split('marked=')[0])
from delete_closed import remove
rows=json.load(open('inequality-odd.json'))
base_rows=remove(rows,[(25+454,25+863+141),(2755,2849)])
base=s.tree(base_rows)
def findword(w):return next(n for ns in g.values()for n in ns if word(n)==w)
par={1:findword(par1),2:findword(par2),3:findword(par3)}
copy={j:findword(word(t)[19:])for j,t in par.items()}
consnode=findword(cons);walnode=findword(cons+[('CI',1)]*2)
neg=findword(push+[('CI',1)]+cons);CI=('CI',1)
def endings(index):
 p=base_rows[index-1][0];result=[]
 for k in range(len(p),0,-1):
  if '0'in p[k:]:break
  q=p[:k];t=s.subtree(base,q)
  if s.boundary(t)==(0,0,False):result.append(q)
 return result
entries=endings(25+454)
print('BASE',s.metrics(base),'SPLICES',entries,flush=True)
intern={};trees={};stats={};desc={}
def code(t):
 if s.leaf(t):key=t;ds=set();stat=(0,0,0)
 else:
  a,b=code(t[0]),code(t[1]);key=(a,b);ds=desc[a]|desc[b]
  da,za,la=stats[a];db,zb,lb=stats[b]
  stat=(1+max(da,db),max(za,zb,1+la),1+la)
 if key not in intern:
  z=len(intern)+1;intern[key]=z;trees[z]=t;stats[z]=stat;desc[z]=ds|{z}
 return intern[key]
baseid=code(base);base_nodes=desc[baseid]
code(r)
def pair(a,b):
 key=(a,b)
 if key not in intern:
  z=len(intern)+1;intern[key]=z;trees[z]=(trees[a],trees[b])
  da,za,la=stats[a];db,zb,lb=stats[b]
  stats[z]=(1+max(da,db),max(za,zb,1+la),1+la)
 return intern[key]
def parse(atoms):
 ids=[code(t)for t in atoms];fixed=base_nodes|set().union(*(desc[z]for z in ids));chart={}
 for i,z in enumerate(ids):chart[i,i+1]=[(z,frozenset())]
 for length in range(2,len(ids)+1):
  for i in range(len(ids)-length+1):
   j=i+length;found={}
   for k in range(i+1,j):
    for a,sa in chart[i,k]:
     for b,sb in chart[k,j]:
      z=pair(a,b)
      if stats[z][1]>7:continue
      ss=sa|sb
      if z not in fixed:ss=ss|{z}
      if z not in found or len(ss)<len(found[z]):found[z]=ss
   ranked=sorted(found.items(),key=lambda x:(len(x[1]),stats[x[0]][0],stats[x[0]][2],x[0]))
   chart[i,j]=ranked[:20]
 return [trees[z]for z,ss in chart[0,len(ids)]]
def count(t):
 seen=set()
 def go(q):
  if q in seen:return
  seen.add(q)
  if not s.leaf(q):go(q[0]);go(q[1])
 go(t);return len(seen)
best=999;hits=[];saved=0;start=time.time()
for perm in itertools.permutations((1,2,3)):
 a,b,c=perm
 atoms=[par[a],par[b],consnode,CI,CI,CI,par[a],copy[b],CI,par[c],par[a],consnode,CI,CI,CI,neg,par[c],par[b],consnode,CI,CI,CI,consnode,walnode,consnode]
 variants=parse(atoms)
 print('PARSED',perm,len(variants),'seconds',round(time.time()-start,2),flush=True)
 for vi,x in enumerate(variants):
  for ei,p in enumerate(entries):
   t=s.replace(base,p,(s.subtree(base,p),x));n=count(t)
   if n>best:continue
   m=s.metrics(t)
   if m['maximum_zero_run']>7:continue
   if n<best:best=n;hits=[];saved=0;print('BEST',n,perm,vi,ei,m,flush=True)
   hits.append((n,perm,vi,ei,m))
   if saved<4:
    with gzip.open(f'inequality-J-{n}-'+''.join(map(str,perm))+f'-{vi}-{ei}.json.gz','wb')as f:f.write(s.compact(s.sites(t)))
    saved+=1
print('DONE',best,len(hits),'seconds',round(time.time()-start,2),flush=True)
Path('inequality-J-results.json').write_text(json.dumps({'best':best,'hits':hits},indent=2))
