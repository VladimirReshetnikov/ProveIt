"""Remove closed source intervals, preserving the remaining guarded CFG.

This is a syntactic program transform, not a theorem-equivalence checker.
Every incoming edge to a removed interval must land at its first ordinal,
and every outgoing edge must land at its end. The caller justifies omitting
the corresponding register-level macro.
"""
import sys,json,bisect
from pathlib import Path
sys.path.insert(0,'../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
import source_language as s

def remove(rows,ranges):
 old=s.tree(rows);graph,_=s.graph_arithmetic(rows);N=len(rows)
 removed={i for a,b in ranges for i in range(a,b)}
 for a,b in ranges:
  incoming={v for i,e in enumerate(graph)if not a<=i<b for v in e[1]if a<=v<b}
  outgoing={v for i in range(a,b)for v in graph[i][1]if not a<=v<b}
  assert incoming=={a},(a,b,'incoming',incoming)
  assert outgoing=={b},(a,b,'outgoing',outgoing)
 oldindex={p:i for i,(p,o,a)in enumerate(rows)}
 labels=[]
 def prune(t,p=''):
  if s.leaf(t):
   i=oldindex[p]
   if i in removed:return None
   labels.append(i);return t
  l=prune(t[0],p+'0');r=prune(t[1],p+'1')
  if l is None:return r
  if r is None:return l
  return l,r
 tree=prune(old);nr=s.sites(tree);M=len(nr)
 assert len(labels)==M
 mapping={i:j for j,i in enumerate(labels)}
 def dest(i):
  k=bisect.bisect_left(labels,i)
  return k if k<M else 0
 desired=[[e,[dest(v)for v in ts]]for i,(e,ts)in enumerate(graph)if i not in removed]
 paths={p:i for i,(p,o,a)in enumerate(nr)};intervals={}
 def visit(p):
  if p in paths:x=paths[p],paths[p]+1
  else:
   a,b=visit(p+'0'),visit(p+'1');x=a[0],b[1]
  intervals[p]=x;return x
 visit('')
 def unwind(p,edge,count):
  while p:
   bit,p=p[-1],p[:-1]
   if bit==edge:
    count-=1
    if count==0:return intervals[p][1]%M if edge=='0'else intervals[p][0]
  return 0
 for j,(p,o,a)in enumerate(nr):
  if o in ('CB','CC'):
   edge='0'if o=='CB'else'1';want=desired[j][1][0]
   poss=[k for k in range(1,len(p)+2)if unwind(p,edge,k)==want]
   assert poss,(labels[j],p,o,want)
   nr[j][2]=min(poss)
  elif o=='CD':
   got=[unwind(p,'0',1),(j+1)%M]
   assert got==desired[j][1],(labels[j],p,'CD',got,desired[j][1])
  elif o=='CI':assert desired[j][1]==[(j+1)%M]
 g2,_=s.graph_arithmetic(nr)
 assert g2==desired
 assert s.graph_intervals(nr)==desired
 return nr

if __name__=='__main__':
 rows=json.load(open('../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215/sites215.json'))
 new=remove(rows,[(25+618,25+698),(25+780,25+809)])
 Path('r7-no-fresh-binder.json').write_bytes(s.compact(new))
 print(s.metrics(s.tree(new)))
