import json,sys,itertools,time,os
from pathlib import Path
exec(Path('symbolic_ax.py').read_text().split('marked=')[0])
base=r;allrows=s.sites(base);axprefix='110100100'
axoff=next(i for i,(p,o,a)in enumerate(allrows)if p.startswith(axprefix))
tokens=json.load(open('ax-tokens.json'))
neg=next(n for n in g[184]if word(n)==push+[('CI',1)]+cons)
nip=s.subtree(base,'111');test=(('CD',5),((('CD',5),('CC',2)),('CH',None)))
odd=(test,nip[1][1]);CI=('CI',1)
def nodes(t):
 seen=set()
 def go(q):
  if q in seen:return
  seen.add(q)
  if not s.leaf(q):go(q[0]);go(q[1])
 go(t);return seen
eqs=[(i,z,n) for i,z,n in tokens if z=='weq']
choices=[]
for i,_,n in eqs:
 p=allrows[axoff+i+n-1][0]
 cs=[]
 for k in range(len(p),0,-1):
  q=p[:k]
  if '0' in p[k:]:break
  t=s.subtree(base,q)
  if s.boundary(t)==(0,0,False):cs.append(q)
 choices.append(cs)
print('CHOICES',[len(x)for x in choices],choices,flush=True)

def loadmap(reg,index,other):
 # Replace just the register read/copy operands in a 26-leaf parameter macro.
 for j in range(index,index+26):
  p,o,a=allrows[axoff+j]
  if o in ('CI','CD')and a in (3,4,5):reg[p]=(o,other)

def make_reverse(eqreverse,bindreverse):
 reg={}
 if eqreverse:
  for k,(i,z,n)in enumerate(tokens):
   if z!='weq':continue
   x,y=tokens[k-2:k]
   assert x[1].startswith('par')and y[1].startswith('par')
   rs={'par1':4,'par2':5,'par3':3}
   loadmap(reg,x[0],rs[y[1]]);loadmap(reg,y[0],rs[x[1]])
 if bindreverse:loadmap(reg,618,5);loadmap(reg,644,4)
 return reg

def build(c,reg,bind):
 wraps={p:neg for p in c}
 # binder starts as M(A,B); append 0,1,2 increments, or 2 then NEG.
 bpath=allrows[axoff+697][0]
 if bind==1:pass
 elif bind==2:wraps[bpath]=CI
 elif bind==3:wraps[bpath]=(CI,CI)
 elif bind==4:wraps[bpath]=((CI,CI),neg)
 else:raise AssertionError(bind)
 prefix={''}
 for p in list(wraps)+list(reg)+['111']:
  for k in range(len(p)+1):prefix.add(p[:k])
 def go(t,p=''):
  if p=='111':return odd
  if p not in prefix:return t
  if s.leaf(t):q=reg.get(p,t)
  else:q=go(t[0],p+'0'),go(t[1],p+'1')
  if p in wraps:q=(q,wraps[p])
  return q
 return go(base)

start=time.time();best=999;hits=[];summary=[]
out=Path('ineq_variants');out.mkdir(exist_ok=True)
for er,br,bind in itertools.product(range(2),range(2),range(1,5)):
 reg=make_reverse(er,br);local=999;lh=[]
 for k,c in enumerate(itertools.product(*choices)):
  t=build(c,reg,bind);n=len(nodes(t))
  if n<local:local=n;lh=[(k,c)]
  elif n==local:lh.append((k,c))
  if n<best:best=n;hits=[];print('BEST',n,'eqrev',er,'bindrev',br,'bind',bind,'choice',k,flush=True)
  if n==best:hits.append((er,br,bind,k,c))
 summary.append((local,er,br,bind,len(lh)))
 for k,c in lh[:8]:
  if local<=205:
   t=build(c,reg,bind)
   (out/f'e{er}b{br}t{bind}c{k}-{local}.json').write_bytes(s.compact(s.sites(t)))
 print('FAMILY',local,er,br,bind,'hits',len(lh),flush=True)
print('DONE',round(time.time()-start,2),'BEST',best,'HITS',len(hits),'SUMMARY',sorted(summary),flush=True)
Path('inequality-search.json').write_text(json.dumps({'best':best,'hits':hits,'summary':summary},indent=2))
