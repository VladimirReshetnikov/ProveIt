# Mathematical status of the formalism search

This note separates mathematical calibrations, source-program measurements, and unproved proposals. No work in this directory establishes a binary machine with 214 or fewer working states. A distinct-subtree count is not a working-state count. The mathematical arguments below are ordinary finite arguments formalizable in ZFC; they are not new Lean/Rocq exact-table endpoints.

## Calibrated changes and measured results

| Change | Mathematical status | Best measured source result in this search | Remaining implementation work |
|---|---|---|---|
| Independent A/B/C permutations of the seven logical rows | Exactly the same axiom families; parameter renaming is bijective, including coincident numerical values | Exhaustive 6^7 = 279,936 cases: minimum 202 distinct subtrees, four ties. The rho6 B/C swap was allocated and checked by the encoding agent at 215 states | No reduction below215 obtained |
| Halt on any code congruent1 modulo4 | Proven refutation-equivalent: a derived membership atom specializes first to a diagonal atom and then to M00 | 206 subtrees | Full source/compiler/table checks if retained |
| Literal inequality interpretation Eab := ¬Nab; halt on any odd theorem | Calibrated definitional interpretation; N atom theorem gives F directly by GEN and translated rho1, while membership atoms use the same specialization | 205 subtrees, 5,025 leaves, zero-run6; all6^7 row permutations retain minimum205 | No improving physical allocation; not a smaller machine |
| Cancel the two adjacent negations in translated rho1 | Valid using the explicitly derived relative-falsity classical bridge | 207 subtrees, 4,931 leaves, zero-run6 | Lower leaf count increased shared-source cost |
| Contrapose both inequality membership-congruence rows | Equivalent under the same relative classical bridge | 212 subtrees, 5,025 leaves, zero-run7 | No improvement |
| Replace fused R7 by the transported-binder inequality J schema | New calibrated logical presentation, proved in `inequality_J_calibration.tex`; all mixed-zero cases covered | κ=Nab:209 subtrees,4,839 leaves,zero-run7; κ=a+b+1:211 subtrees,4,791 leaves,zero-run7 | Best beam parses only; no universal optimality or physical allocation claimed |
| Replace R7 by gated crossed helper C1, fused with G | Calibrated by the inherited single-crossed-helper theorem; emitted source independently audited from Coq macro CFGs | 205 subtrees,4,615 leaves,depth46,zero-run6. Remaining6^6 parameter permutations retain minimum205 | Retained-alias allocation found no improving physical table; stack row-selection compiler must account for deletion of R7 |
| Fresh helper binder κ=a+b+1 in otherwise retained R7 | Calibrated generic-helper instance | Encoding agent reports204 subtrees | No smaller allocation obtained |
| Exponential pairing Pe(a,b)=(2b+1)2^a−1 throughout | Coding transfer proved in `exponential_pairing_transfer.tex`; pairing/inverse are primitive recursive, fields bounded by code, I00=0 retained | Arithmetic/source pricing belongs to independent agent | Exact PAIR/UNPAIR order, every stack/proof field, runtime, bootstrap and cofinal reset word must be checked |
| Two-outer-tag formula grammar | Coding transfer proved in `two_tag_codec_transfer.tex`; keepsF1 andtruth0, with I=2P and I00=0 | Encoding agent has current prices; no state count claimed here | Every constructor, implication recognizer, binder increment, runtime and blank bootstrap |

The gated crossed source is `gated_crossed/gated-r0c0e5j2-205.json`, SHA256 `7ceea7f31fecae9a129ae0af4f4c61fe68d9e4c85baae659a2ad75b8b113391b`. Its independent audit is `independent_work/gated-source-audit.json`. The emitted bundle is `¬(D→X)` where the old bundle was `¬X`, and `D=E(A,B)→Q_C E(B,A)`; thus it is `D∧G` under the same gate C≠A,B. No C1 instance leaks through a failed gate.

## The new J theorem

Retain rho1–rho6, dominated rho8, full membership vacuity, the equality-free K template, MP and closed GEN, interpreting each old equality occurrence as d_ab=¬N(a,b). Replace old fusedR7 by

    Jκ(a,b,c): Nab → Qκ(a,b)(¬Nca → Ncb),

for any computableκ with a≠b implyingκ(a,b)≠a,b. No condition on diagonalκ(a,a) is needed, andκ need not be symmetric.

The proof derives diagonal¬Naa, then Nab→Qκ Nab. Seriality and rho6 give QiQiX→X, so a supplied helper X→QiX also gives QiX→X. Crossed instances give Nab→Qκ(a,b) Nba and Nba→Qκ(b,a) Nab. Quantifier commutation transports the helper between these two binders and yields symmetry. Existential monotonicity followed by rho6 gives the negative helper ¬Nab→Qκ¬Nab. These are exactly the primitive-symmetry and canonical-helper premises of the inherited membership-defined-equality calibration; oldrho7 is not used after its deletion.

Relative falsity is explicit. Let F=M00 and A=Qi((QiX)→F). Rho6 is (A→F)→X, while implicationalK proves F→(A→F). Their composition proves F→X. This gives relative explosion; the retained pure classical implication basis then supplies all relative Boolean steps, including double-negation cancellation. The proof does not silently treat M00 as a syntactically closed primitive bottom.

## Conditional or rejected proposals

* **Deleting the entire fresh quantifier from R7:** the source falls to200 subtrees /4,642 leaves /zero-run6, and its primitive CFG was audited. This is **not calibrated**: the quantifier intentionally packages the equality-vacuity helper. Source control equivalence does not replace that missing logical resource. Do not promote `r7-no-fresh-binder.json` as a candidate.
* **Fixed binder0 with positive R7 endpoints:** sound individual schemas, but the current lower-calibration attempt needs mixed-zero equality symmetry/helper transport. A positive-only proof fragment does not supply that. No equivalence claim.
* **Uniform positive-only labels to reserve quantifier field0:** avoids the preceding local gap inside the positive fragment, but the exact K+IR lower comparison still uses IR=∀0(M00→bottom), which translates to ∀0(F→F). Removing Q0 requires a new adapter; renaming IR to a positive label changes the membership atom and loses this identity. Shared AX fields also serve as arbitrary formula codes. Not automatically calibrated.
* **Cofinal fresh or own-code membership vacuity replacing full membership vacuity:** the upstream countervaluation below refutes the usual logical recovery. It is not a K countermodel, so a wholly new K-dependent consistency proof remains conceivable; none is supplied.
* **Atomic self-specialization in place of equality:** `atomic_specialization_obstruction.tex` gives a four-world countervaluation validating normality, commutation, rho6, full membership vacuity and both positive/negative atomicT, yet refutingT for a disjunction. Hence structural specialization cannot be imported from those rows alone. This is a logic-only obstruction, not a K countermodel.
* **Contraposed rho6:** replacing `¬Qi¬QiX→X` by `¬X→Qi¬QiX` loses the established explosion bootstrap. A one-world valuation with allQi identity, all membership atoms true, allEq atoms false validates the replacement logical rows and negatively encoded G, but falsifiesF→Eq00 and the oldrho6. A separate finite-refutation translation would be necessary.
* **Bottom0 with a halt test only on successful MP:** existing reset/cache/failed-AX zeros can enter the theorem stack throughDROP. Changing0 from truth to bottom breaks that invariant even if NIP no longer tests0. This requires a new presence/validity invariant or altered command handling.
* **Single crossed helper with symmetricκ=a+b+1:** the inherited single-crossed theorem requires an asymmetric off-diagonalκ. The double-boxed crossed theorem permits symmetricκ, and the newJ theorem permits arbitrary freshκ; these are different schemas.

## Exact zero-alias dependency in the dominated proof

The source compiler itself uses truth0, I(t,1)>0, I(0,u)>0 foru>0, and that generated rows/quantifiers are not1. It does not essentially need I00=0: J(0) simply omitsMP, which remains valid when I00 becomes positive.

The propositional certificate is different. `audit_dominated_zero_alias.py` independently checks all3728 nodes and1260 structural domination guards in the pinned Source149 certificate. With I(T,T)=T, all checks pass. Without that normalization, exactly one node fails: node8, the schema X→T with T literal0. Every other recorded MP/substitution check remains valid. Therefore a nonzero-Imp-tag permutation is **conditional on** independently deriving X→0 (or replacing this certificate). Constructor dominance alone is insufficient to cite the old proof.

The replay uses `source149-dominated-certificate.json.gz`; its exact uncompressed SHA256 is `3cf18a5fe9f187b50b79d97b84535ce9bf776305728b0cdfe17285e94f028452`. Results are in `dominated-zero-alias-audit.json`. Two-tagI=2P and exponentialI=4Pe retainI00=0 and do not encounter this obstruction.

One possible source repair is to define a nonzero-tag implication as0 at(a,b)=(0,0), retaining the alias, and use4P+tag otherwise. Guarded tag addition would implement that. MP could reject exceptionalcode0 without harming refutation completeness if the strong compiler handles every requested conclusion0 directly viaDiscard. This is a proposed implementation route, not a checked source.

## Finalized proof fragments

* `inequality_J_calibration.tex`: new J theorem, all-label bootstrap, explicit relative-falsity bridge, inherited K adapter, odd halt.
* `two_tag_codec_transfer.tex`: unique decoding, zero convention, code/label inequalities, helper and dominated-row transfer, actual-code K adapter.
* `exponential_pairing_transfer.tex`: primitive-recursive pairing, strict field/tail bounds, formula coding, logical transfer, cofinality obligations.
* `atomic_specialization_obstruction.tex`: complete four-world logical obstruction, including negative atomicT.
* `membership_halt.tex`: any membership theorem yieldsM00, all coincident endpoints included.
* `crossed_self_helper.tex`: the asymmetric single-crossed helper and exact K coupling.
* `stride_padding.tex`: Cantor successful-code padding is cofinal in each dyadic residue class. This arithmetic theorem does not automatically transfer to another pairing.

## Primary provenance

All paths below lie in `SetTheory/Cardinals/docs/reports/set-theory/zfc-closure-kernels/data/`, except the command/compiler source and candidate proof path.

| Input | Exact path or basename | Git blob |
|---|---|---|
| Generic helper, either rho7 or primitiveSym | `116-eqred-proofs-general_kappa_equality_helper.md` | `0c0e8b50485f6c431f0fef5d80cb763972e3e7eb` |
| Relative falsity / equality interpretation audit | `116-eqred-audit-mathematical_audit.md` | `fb4d70c959fa7cca47a82e1678fb0878137b3fac` |
| Actual-code K private-label adapter | `125-k224-portable-theory-k_equality_helper_extension.md` | `a55e1b0c77db28e25f6e629bb602a4eacae0a282` |
| Symmetry+helper suffices for currentK | `128-k223g-research-equality_frontends-symmetry_k_calibration.md` | `4e356172869ffeadbaf894f3b20f0876aabcf9c8` |
| Single crossed helper | `128-k223g-research-equality_frontends-single_crossed_helper_calibration.md` | `fca1214c48bcbd51e350edb30d7b79e3f95a9a8c` |
| Double-boxed crossed helper | `128-k223g-research-equality_frontends-crossed_box_helper_calibration.md` | `2c537d2953bc55b8adda62d05895799e8113d352` |
| Cofinal membership-vacuity obstruction | `128-k223g-research-equality_frontends-canonical_membership_vacuity_obstruction.md` | `8573e8d1e5e2958db9ff3a3bcc65a661551610ae` |
| Dominated schematic proof | `149-dom-theory-dominated_rho8_full_certificate.json` | `63d6ff541b49b2b93e31bd252af6ca4c19dd9895` |
| Its original check receipt | `149-dom-theory-dominated_rho8_full_check.json` | `d6f7337ebf5ad288b18ba3ae259fb541ac4068d9` |
| Dominated exposition | `Computability/BusyBeaver/Research/ZFC/candidate-k218/alternatives/dominated/proof.md` | `e6741526327d5533c4c613c6f92c43e5db9c1b68` |

The exact strong command compiler and packing convention were checked in `Computability/BusyBeaver/Research/ZFC/candidate-k215/provenance/permuted-commands/sections/source_calibration.tex`. First-candidate packing omits an outer successor, while every later command-tail cell has one; this distinction is essential when evaluating alternate pairings or enumeration padding.
