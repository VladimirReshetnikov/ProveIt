import json,sys,collections,itertools,time
from functools import lru_cache
sys.path.insert(0,'../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
import source_language as s
old=s.tree(json.load(open('../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215/sites215.json')))
pop=s.subtree(old,'11111')
@lru_cache(None)
def shapes(n):
 if n==1:return (None,)
 return tuple((a,b) for k in range(1,n) for a in shapes(k) for b in shapes(n-k))
def leaf_paths(sh,p=''):
 if sh is None:return[p]
 return leaf_paths(sh[0],p+'0')+leaf_paths(sh[1],p+'1')
def fill(sh,ls):
 if sh is None:return next(ls)
 return fill(sh[0],ls),fill(sh[1],ls)
def nodes(t,seen=None):
 if seen is None:seen=set()
 if t in seen:return seen
 seen.add(t)
 if not s.leaf(t):nodes(t[0],seen);nodes(t[1],seen)
 return seen
# Nodes of final root assembled from replacement (computed cheaply).
base=nodes(s.replace(old,'111',('CH',None)))
def valid(g,word):
 for v in (0,1,2,3,4,5,6,7,8,9,12,13,15,16,17,20,21):
  p=0;h=v
  for step in range(150):
   if p==len(word):
    if h!=0 or v%4==1:return False
    break
   op=word[p][0]
   if op=='CH':
    if v%4!=1:return False
    break
   if op=='CD':
    if h: h-=1;p=g[p][1]
    else:p=g[p][0]
   else:p=g[p][0]
  else:return False
 return True
best=999;hits=0;count=0;start=time.time();results=[]
n=7
for sh in shapes(n):
 # Calculate all possible jump destinations directly from precomputed wrapping paths.
 paths=['0'+p for p in leaf_paths(sh)]+['1']; rows=[[p,'CD',5]for p in paths]
 dec=[x[1] for x in s.graph_intervals(rows)]
 cont={};brk={}
 for d in range(1,4):
  cont[d]=[x[1][0] for x in s.graph_intervals([[p,'CC',d]for p in paths])]
  brk[d]=[x[1][0] for x in s.graph_intervals([[p,'CB',d]for p in paths])]
 for ch,cc,cb in itertools.permutations(range(n),3):
  for k,b in itertools.product(range(1,4),repeat=2):
   word=[('CD',5)]*n;word[ch]=('CH',None);word[cc]=('CC',k);word[cb]=('CB',b)
   g=[dest.copy() for dest in dec];g[ch]=[];g[cc]=[cont[k][cc]];g[cb]=[brk[b][cb]]
   if not valid(g,word):continue
   t=fill(sh,iter(word))
   if s.boundary(t)!=(0,0,True):continue
   nip=(t,pop);new=s.replace(old,'111',nip);score=s.metrics(new)['dag_nodes']
   hits+=1
   if score<=best:
    best=score;results.append((score,t,g[:n]));print('BEST',score,'HITS',hits,'SEC',round(time.time()-start,2),t,flush=True)
    open('mod4-best.json','wb').write(s.compact(s.sites(new)))
print('DONE',hits,best,round(time.time()-start,2));open('mod4-results.json','w').write(json.dumps(results))
