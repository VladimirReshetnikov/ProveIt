import json,sys,itertools,time,random
from pathlib import Path
exec(Path('permute_rows.py').read_text().split('start=time.time()')[0])
swapped='--swap35' in sys.argv
inequality='--ineq' in sys.argv
nobinder='--nobinder' in sys.argv
if nobinder:
 oldrows=json.load(open('r7-no-fresh-binder.json'));old=s.tree(oldrows)
 spans=[(a if j==0 else a-109,b-109)for j,(a,b)in enumerate(spans)]
if inequality:
 oldrows=json.load(open('inequality-odd.json'));old=s.tree(oldrows)
 added=0;newspans=[]
 for (a,b),eqs in zip(spans,[3,0,1,0,1,0,1]):
  newspans.append((a+added,b+added+47*eqs));added+=47*eqs
 spans=newspans
if swapped:
 a,b=spans[2];c,d=spans[4]
 assert b-a==d-c
 changed=[r.copy()for r in oldrows]
 for k in range(b-a):
  changed[a+k][1:]=oldrows[c+k][1:]
  changed[c+k][1:]=oldrows[a+k][1:]
 oldrows=changed;old=s.tree(oldrows)

oldrows=json.load(open('gated_crossed/gated-r0c0e5j2-205.json'));old=s.tree(oldrows)
spans=[(a-409,b-409)for a,b in spans[1:]]
# Intern every subtree contained in a single row, under all six parameter
# permutations. Only nodes crossing row boundaries vary during the search.
intern={}; children={}
def canon(t):
 if s.leaf(t): key=t
 else: key=(canon(t[0]),canon(t[1]))
 if key not in intern:
  z=len(intern)+1;intern[key]=z
  children[z]=() if s.leaf(t) else key
 return intern[key]
def bits(z):
 r=1<<z
 for x in children[z]:r|=bits(x)
 return r
fixed=0
rowbits=[[0]*6 for j in spans]
ops=[];variants=[]
def template(t,i=0):
 global fixed
 end=i+size(t)
 for j,(a,b) in enumerate(spans):
  if a<=i and end<=b:
   ids=[]
   for p in range(6):
    z=canon(ren(t,perms[p]));ids.append(z);rowbits[j][p]|=bits(z)
   variants.append((j,ids))
   return ('v',len(variants)-1)
 if not any(i<b and a<end for a,b in spans):
  z=canon(t);fixed|=bits(z);return ('c',z)
 if s.leaf(t):raise AssertionError('partial leaf')
 l=template(t[0],i);r=template(t[1],i+size(t[0]))
 ops.append((l,r));return ('o',len(ops)-1)
root=template(old)
print('TEMPLATE',len(intern),'local nodes',len(variants),'variable fragments',len(ops),'boundary nodes',flush=True)
def quick(c):
 allbits=fixed
 for j,p in enumerate(c):allbits|=rowbits[j][p]
 vals=[ids[c[j]] for j,ids in variants]
 out=[];extra={}
 def val(ref):
  kind,k=ref
  return k if kind=='c' else vals[k] if kind=='v' else out[k]
 for l,r in ops:
  key=(val(l),val(r));z=intern.get(key)
  if z is None:
   z=extra.get(key)
   if z is None:z=-len(extra)-1;extra[key]=z
  else:allbits|=1<<z
  out.append(z)
 return allbits.bit_count()+len(extra)

for c in [(0,)*len(spans),(1,)+(0,)*(len(spans)-1)]+[tuple(random.randrange(6) for _ in range(len(spans)))for _ in range(15)]:
 assert quick(c)==len(nodes(mutate(old,c))),(c,quick(c),len(nodes(mutate(old,c))))
print('Cross-check passed',flush=True)
start=time.time();best=len(nodes(old));hits=[];tally={}
for c in itertools.product(range(6),repeat=len(spans)):
 n=quick(c);tally[n]=tally.get(n,0)+1
 if n<=best:
  if n<best:hits=[];best=n;print('BEST',n,c,flush=True)
  hits.append((n,c))
print('DONE seconds',round(time.time()-start,3),'best',best,'HITS',len(hits),'TALLY',sorted(tally.items()),flush=True)
out=Path('gated_permutations');out.mkdir(exist_ok=True)
for n,c in sorted(hits)[:8]:
 if c==(0,)*len(spans):continue
 p=out/('p'+''.join(map(str,c))+'-'+str(n)+'.json')
 p.write_bytes(s.compact(s.sites(mutate(old,c))))
print('HITS',sorted(hits),flush=True)
Path('gated-permutation-results.json').write_text(json.dumps({'offset':offset,'spans':spans,'perms':perms,'results':sorted(hits),'best':best,'tally':tally},indent=2))
