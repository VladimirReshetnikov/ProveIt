import json,sys,itertools,time,hashlib
from functools import lru_cache
from pathlib import Path
sys.path.insert(0,'../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
import source_language as s
oldrows=json.load(open('../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215/sites215.json'));old=s.tree(oldrows)
offset=next(i for i,(p,o,a)in enumerate(oldrows)if p.startswith('110100100'))
spans=[(454,863),(863,1146),(1146,1442),(1442,1741),(1741,2037),(2037,2387),(2387,2618)]
spans=[(a+offset,b+offset)for a,b in spans]
perms=list(itertools.permutations((4,5,3))) # map old A=4,B=5,C=3 respectively
names=['rho7','rho6','rho5','rho4','rho3','rho2','rho1']
@lru_cache(None)
def size(t):return 1 if s.leaf(t)else size(t[0])+size(t[1])
@lru_cache(None)
def ren(t,p):
 if s.leaf(t):
  op,a=t
  return (op,p[(4,5,3).index(a)])if op in ('CI','CD')and a in(4,5,3)else t
 return ren(t[0],p),ren(t[1],p)
def mutate(t,choice,i=0):
 end=i+size(t)
 for j,(a,b)in enumerate(spans):
  if a<=i and end<=b:return ren(t,perms[choice[j]])
 if not any(i<b and a<end for a,b in spans):return t
 if s.leaf(t):return t
 return mutate(t[0],choice,i),mutate(t[1],choice,i+size(t[0]))
def nodes(t):
 seen=set()
 def go(q):
  if q in seen:return
  seen.add(q)
  if not s.leaf(q):go(q[0]);go(q[1])
 go(t);return seen
oldn=len(nodes(old));print('OFFSET',offset,'SPANS',spans,'PERMS',perms,'BASE',oldn,flush=True)
# Check all row slices are closed in the full CFG.
graph,_=s.graph_arithmetic(oldrows)
for name,(a,b)in zip(names,spans):
 exits=set(v for i in range(a,b)for v in graph[i][1]if not a<=v<b)
 assert exits=={b},(name,exits)
print('All row intervals closed',flush=True)
start=time.time();best=oldn;results=[]
def test(c):
 global best
 t=mutate(old,c);n=len(nodes(t))
 if n<oldn or n<=best:
  rec={'choice':c,'nodes':n,'permutations':[perms[x]for x in c]}
  results.append(rec)
  if n<best:
   best=n;print('BEST',n,c,rec['permutations'],'seconds',round(time.time()-start,2),flush=True)
  if n<oldn:
   tag=''.join(map(str,c));out=Path('row_permutations');out.mkdir(exist_ok=True)
   (out/(tag+'.json')).write_bytes(s.compact(s.sites(t)))
 return n
single=[]
for j in range(7):
 for p in range(1,6):
  c=[0]*7;c[j]=p;n=test(tuple(c));single.append((n,j,p))
print('SINGLES',sorted(single),flush=True)
# Every combination, ordered by coordinate descent candidates first.
for c in itertools.product(range(6),repeat=7):
 test(c)
print('DONE',best,'seconds',round(time.time()-start,2),flush=True)
Path('row-permutation-results.json').write_text(json.dumps({'offset':offset,'spans':spans,'perms':perms,'results':results,'best':best},indent=2))
