import json,sys,collections
sys.path.insert(0,'../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215/code')
import source_language as s,build221 as b
p='../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215/'
r=s.tree(json.load(open(p+'sites215.json')));T=b.read_table(open(p+'k215.native.tm','rb').read());g,ps=b.decoder_map(T,r)
word=lambda t:[(o,a)for p,o,a in s.sites(t)]
par1=word(next(iter(g[98])));push=par1[:19]
copy=par1[19:]
par2=push+[(o,5 if a==4 else a)for o,a in copy]
par3=push+[(o,3 if a==4 else a)for o,a in copy]
cons=word(next(t for t in g[150]if len(s.sites(t))==54))[:27]
readbase=word(next(iter(g[104])))
patts={'par1':par1,'par2':par2,'par3':par3,'push':push,'cons':cons,'v1':push+[('CI',1)],'read1':readbase+[('CD',6),('CI',4),('CC',2)],'read2':readbase+[('CD',6),('CI',5),('CC',2)]}
# Prefer whole atomic constructors.
for tag in(1,2,3):patts[{1:'wel',2:'wal',3:'weq'}[tag]]=cons+[('CI',1)]*tag
patts=sorted(patts.items(),key=lambda x:-len(x[1]))
rows=s.sites(s.subtree(r,'110100100'));ops=[(o,a)for p,o,a in rows]
marked={x+'1' for x in ps[164] if x.startswith('110100100')}
starts={}
for k,(path,o,a)in enumerate(rows):
 for m in marked:
  if ('110100100'+path).startswith(m) and m not in starts:starts[m]=k
print('MARKS',starts)
i=0;tokens=[]
while i<len(ops):
 for name,pat in patts:
  if ops[i:i+len(pat)]==pat:
   tok=(i,name,len(pat));tokens.append(tok);i+=len(pat);break
 else:tokens.append((i,str(ops[i]),1));i+=1
for k,(i,name,ln)in enumerate(tokens):
 print(k,i,name,'MARKED' if i in starts.values() else'')
open('ax-tokens.json','w').write(json.dumps(tokens))
