import json
from pathlib import Path
exec(Path('symbolic_ax.py').read_text().split('marked=')[0])
from delete_closed import remove
q=json.load(open('inequality-odd.json'));t=s.tree(q)
neg=push+[('CI',1)]+cons
start=25+2465+5*47+30
assert [(o,a)for p,o,a in q[start:start+94]]==neg*2
newrows=remove(q,[(start,start+94)])
u=s.tree(newrows)
print('Delete double NEG',start,start+94,s.metrics(u),flush=True)
Path('inequality-rho1-simplified.json').write_bytes(s.compact(newrows))
