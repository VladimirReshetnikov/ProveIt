#!/usr/bin/env python3
"""Independently replay Source149 with/without numeric I(0,0)=0.
Every inference and structural dominance guard is checked. This is a
schema proof, not a source-program or binary-runtime verification.
"""
from pathlib import Path
import functools, gzip, hashlib, json
HERE=Path(__file__).resolve().parent
RAW=gzip.decompress((HERE/'source149-dominated-certificate.json.gz').read_bytes())
DOC=json.loads(RAW)

def replay(normalize):
    nodes=[]; intern={}
    def put(x):
        if x not in intern:intern[x]=len(nodes);nodes.append(x)
        return intern[x]
    truth=put('T')
    def pair(a,b):return truth if normalize and a==b==truth else put((a,b))
    terms=[]
    for t in DOC['term_table']:
        terms.append(truth if t=='T' else put('v'+str(t['var'])) if isinstance(t,dict) else pair(terms[t[0]],terms[t[1]]))
    def subst(t,mapping):
        @functools.lru_cache(None)
        def run(t):
            x=nodes[t]
            if isinstance(x,tuple):return pair(run(x[0]),run(x[1]))
            if x.startswith('v') and x[1:] in mapping:return terms[mapping[x[1:]]]
            return t
        return run(t)
    def canon(t):
        names={}
        @functools.lru_cache(None)
        def run(t):
            x=nodes[t]
            if isinstance(x,tuple):return pair(run(x[0]),run(x[1]))
            if x=='T':return truth
            if x not in names:names[x]=len(names)
            return put('v'+str(names[x]))
        return run(t)
    def imp(t):
        if isinstance(nodes[t],tuple):return nodes[t]
        if normalize and t==truth:return truth,truth
        raise ValueError('not an implication')
    @functools.lru_cache(None)
    def subterm(a,u):
        x=nodes[a]
        return a==u or isinstance(x,tuple) and any(subterm(t,u) for t in x)
    def dominated(t):
        lhs,rhs=imp(t);cu,a=imp(lhs);c,u=imp(cu)
        ac,bc=imp(rhs);aa,cc=imp(ac);b,ccc=imp(bc)
        return a==aa and c==cc==ccc and (u==truth or subterm(a,u))
    failures=[];rules={}
    for n in DOC['nodes']:
        idx=n['id'];r=n['rule'];target=terms[n['term']];kind=r['kind']
        rules[kind]=rules.get(kind,0)+1;reason=''
        prev=lambda j:terms[DOC['nodes'][j]['term']]
        try:
            if kind=='truth':good=target==truth
            elif kind=='dominated_rho8':good=dominated(target)
            elif kind=='mp':
                assert r['major']<idx and r['minor']<idx
                good=prev(r['major'])==pair(prev(r['minor']),target)
            elif kind=='substitution':
                assert r['parent']<idx
                good=subst(prev(r['parent']),r['substitution'])==target
            elif kind=='mp_substitution':
                assert r['major']<idx and r['minor']<idx
                major=subst(prev(r['major']),r['major_substitution'])
                minor=subst(prev(r['minor']),r['minor_substitution'])
                ant,con=imp(major)
                good=ant==minor and canon(con)==canon(target)
                if not good:reason='antecedent mismatch' if ant!=minor else 'conclusion mismatch'
            else:raise ValueError('unknown rule '+kind)
        except (ValueError,AssertionError) as e:good=False;reason=str(e)
        if not good:failures.append({'node':idx,'rule':kind,'reason':reason})
    return {'normalize_implication_truth_truth':normalize,'proof_nodes':len(DOC['nodes']),'shared_terms':len(DOC['term_table']),'rule_counts':rules,'verified':not failures,'failures':failures}

if __name__=='__main__':
    result={'source_path':'SetTheory/Cardinals/docs/reports/set-theory/zfc-closure-kernels/data/149-dom-theory-dominated_rho8_full_certificate.json','source_git_blob':'63d6ff541b49b2b93e31bd252af6ca4c19dd9895','source_sha256':hashlib.sha256(RAW).hexdigest(),'with_alias':replay(True),'without_alias':replay(False),'conclusion':'Only node8, the schema X->T, materially uses I(T,T)=T. Supplying X->0 independently repairs the remaining schematic derivation, subject to the same constructor-dominance guards.'}
    assert result['with_alias']['verified']
    assert result['without_alias']['failures']==[{'node':8,'rule':'mp_substitution','reason':'antecedent mismatch'}]
    (HERE/'dominated-zero-alias-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
