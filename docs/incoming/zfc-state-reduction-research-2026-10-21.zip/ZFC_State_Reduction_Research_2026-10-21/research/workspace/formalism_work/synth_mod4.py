import json,sys
from functools import lru_cache
from itertools import product
sys.path.insert(0,'../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215')
import source_language as s
old=s.tree(json.load(open('../ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215/sites215.json')))
@lru_cache(None)
def shapes(n):
 if n==1:return (None,)
 return tuple((a,b) for k in range(1,n) for a in shapes(k)for b in shapes(n-k))
def fill(t,ls):
 if t is None:return next(ls)
 return fill(t[0],ls),fill(t[1],ls)
base=[('CD',5)]*4+[('CC',1),('CB',1),('CH',None)]
want=[[7,1],[6,2],[5,3],[5,4],[0],[7],[]]
count=0;best=[]
for sh in shapes(7):
 for cc,cb in product(range(1,5),repeat=2):
  ls=base.copy();ls[4]=('CC',cc);ls[5]=('CB',cb)
  t=fill(sh,iter(ls));wrap=(t,('CI',8));rows=s.sites(wrap)
  try:g,_=s.graph_arithmetic(rows)
  except ValueError:continue
  if [x[1]for x in g[:7]]!=want:continue
  if s.boundary(t)!=(0,0,True):continue
  count+=1
  nip=(t,s.subtree(old,'11111'))
  # Original NIP pop is old 11111: source 111=(CI6,((eq,CH),pop))
  new=s.replace(old,'111',nip)
  m=s.metrics(new)
  best.append((m['dag_nodes'],cc,cb,t,nip,m))
print('found',count)
for item in sorted(best,key=lambda x:(x[0],x[1],str(x[3])))[:20]:print(item)
