# Selected research scripts, snapshots and receipts

This directory contains exploratory material. **Only `../machine215/` together with `../evidence/fresh-variant/` is a newly accepted exact-table construction.** All other tables, source snapshots and solver results require the qualifications in the report. No bounded failure or restricted MILP infeasibility is a lower bound.

## Index

| Topic | Main files under `workspace/` |
|---|---|
| New inequality calculus | `formalism_work/inequality_new_r7_native.py`, `inequality-J-native-results.json`, best 209-node compressed source; `independent_work/inequality-row-audit.tex` |
| Gated crossed helper | `formalism_work/build_gated_crossed.py`, `gated-crossed-results.json.gz`; `independent_work/audit_gated.py`, `gated-source-audit.json` |
| Two-tag / prefix / tag swaps | `encoding_work/two_tag_codec.py`, `prefix_codec.py`, `swap_q_e.py`, their results and best sources |
| Uniform radix five and junk residues | `independent_work/uniform_junk_codec.py`, `uniform_junk/` |
| Exponential pairing | `independent_work/exponential_pair.py`, optimized source; mathematical transfer in `../theory/` |
| Zero alias in the propositional bootstrap | `formalism_work/audit_dominated_zero_alias.py`, compressed Source149 certificate and audit receipt |
| Restricted physical allocation | `encoding_work/permute_allocate.py`, `path_allocate.py`, `path_release.py`, allocation receipts and `final_inventory.json` |
| Finite-window folding | `root_work/check_joint_fold.py`, `check_blank_fold.py`, `filter_source.py`, `search_*folds.py`, aggregate `result.json` files |
| Whole-primitive alias screen | `independent_work/semantic_fold_screen.cpp`, `semantic_fold_data.py`, finite-screen logs/receipts |
| Source reachability abstraction | `independent_work/source_signs.py`, `source-sign-invariant.json.gz`, `source_dead_code.py`, `dead_code/` |
| First spare fixed to one | `formalism_work/spare1_census.py`, `symbolic_runtime_spare1.py`, row census and concrete witnesses |
| Consolidated branch inventories | `encoding_work/final_inventory.json`, `independent_work/packet_inventory.json`, `formalism_work/MATHEMATICAL_STATUS.md` |

The report is authoritative if a historical exploratory file uses an earlier label or tentative description. In particular:

- A 214-node source is not a 214-state table.
- Nonzero implication-tag proposals still need the `X -> 0` bootstrap; the audit fails exactly at Source149 node 8 without `I(0,0)=0`.
- The second-coordinate-reserved two-tag source reached 216 nodes.
- `path-final-4-215.native.tm` is a different two-row-change allocation. Its bounded folding search is complete, but it has not received the full fresh runtime replay supplied for the main 42-row-change table.
- Pure coding-transfer arguments do not certify every arithmetic substitution in a raw exploratory source or supply a new kernel formalization.

## Restoring the exploratory workspace

The scripts preserve the original experiment text and hashes. Their working directories matter; some also contain the original absolute research prefix. To prepare a separate replay copy, point the helper at a checkout of the pinned ProveIt revision:

```sh
python3 ../code/prepare_research_workspace.py --repo /absolute/path/to/ProveIt --output /absolute/path/to/new-replay
```

The output must not already exist. The helper copies the four research directories, rewrites only the old absolute workspace prefix in the copied Python files, links the specified repository as `ProveIt`, and decompresses the selected compressed inputs. It records the rewritten files. It never edits the repository or this archive. The pinned Git HEAD is checked.

Most `encoding_work`, `independent_work` and `root_work` scripts run from the replay root; most constructor-row scripts in `formalism_work` run from that subdirectory. Set `PYTHONPATH` to the pinned candidate's `code/` directory when an early exploratory script imports its helpers from the candidate root. MILP searches require NumPy and SciPy; the C++ finite screen requires a C++17 compiler. The exact accepted-machine verification does not require any of these dependencies.

Only selected best source snapshots and aggregate receipts are included. A generator may recreate intermediate files before a later experiment can consume them. Receipts retain historical absolute paths and input hashes. The complete primary-machine reproduction path is `../code/verify_variant.py`, independent of these exploratory-path conventions.

## Search scope and omitted logs

The full pair/action census in each `result.json` is finite and precisely scoped. Failure of a bounded join test is failure to find that proof diagram; it need not be a semantic counterexample. The concrete C++ screen similarly uses finite values and step limits. The source sign invariant and first-spare specialization are genuine inductive invariants but do not cover all possible correlated facts about the complete proof-search execution.

Large repetitive negative-search witness streams are not included. For completed runs the aggregate receipt records the stream digest; the generator can reproduce the family. The omitted full streams were discarded after the completed-run receipts were recorded; their old digests do not imply that the streams are delivered. The interrupted first rho6 fold run is excluded; its complete rerun is in `root_work/rho6-blank8-rerun/`. The final two-row-allocation search hashed the stream incrementally and retained only sixteen witnesses. These omissions do not affect the fully delivered primary-machine runtime and blank traces.
