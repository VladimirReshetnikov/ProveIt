#!/usr/bin/env python3
"""Measure the selected literal sources. DAG nodes are not physical TM states."""
from pathlib import Path
import argparse,gzip,hashlib,json
import source_language as s
BASE=Path(__file__).resolve().parents[1]
W='research/workspace/'
SOURCES=[
('parent','upstream/sites215.json','Accepted upstream 215-state construction.'),
('rho6_parameter_variant','machine215/row-rho6-swapBC-2020-215.sites.json','Accepted new 215-state construction; full fresh runtime and blank check.'),
('inequality_J_native',W+'formalism_work/inequality-J-native-209-123-0-2.json.gz','Calibrated calculus; no smaller native table.'),
('inequality_J_affine',W+'formalism_work/inequality-J-211-123-0-2.json.gz','Calibrated calculus; no smaller native table.'),
('gated_crossed',W+'formalism_work/gated_crossed/gated-r0c0e5j2-205.json.gz','Calibrated calculus and independently audited source; no smaller native table.'),
('two_tag',W+'encoding_work/two-tag-q3m0-214.sites.json.gz','Coding transfer given; 214 means source nodes, not TM states.'),
('two_tag_symmetric',W+'independent_work/two_tag/symmetric-0-0.sites.json.gz','Codec experiment; no complete new physical implementation.'),
('exponential_pairing',W+'independent_work/exponential-pair-optimized.sites.json.gz','Coding transfer given; full changed-source compiler/runtime not certified.'),
('uniform_radix5',W+'independent_work/uniform_junk/best.sites.json.gz','Admissible coding with junk residues; raw arithmetic source and native table not fully calibrated.'),
('QE_tag_swap',W+'encoding_work/swap-q-e-111111-1-203.sites.json.gz','Admissible tag permutation; no smaller native table allocated.'),
('IQ_tag_swap',W+'independent_work/tag_permutations/tags-I2Q0E3-i0q0.sites.json.gz','CALIBRATION PENDING: Source149 zero-alias bootstrap and zero run 10.'),
('contraposed_rho6',W+'encoding_work/rho6-contrapositive-34-206.sites.json.gz','CALIBRATION PENDING: relative falsity and outer K interpretation.'),
('dead_MP_loop',W+'independent_work/dead_code/dead-mp1halt0.sites.json.gz','Source-level deletion justified by checked invariant; no smaller native allocation.'),
('dead_halt_loop',W+'independent_work/dead_code/dead-mp0halt1.sites.json.gz','Source-level deletion justified by checked invariant; no smaller native allocation.'),
('both_dead_loops',W+'independent_work/dead_code/dead-mp1halt1.sites.json.gz','Source-level deletion justified by checked invariant; no smaller native allocation.'),
]

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);a=ap.parse_args()
    result=[]
    for name,path,status in SOURCES:
        q=BASE/path;raw=q.read_bytes()
        if q.suffix=='.gz':raw=gzip.decompress(raw)
        rows=json.loads(raw);metrics=s.metrics(s.tree(rows))
        result.append({'name':name,'path':path,'source_sha256':hashlib.sha256(raw).hexdigest(),'metrics':metrics,'status':status})
    document={'count_kind':'Distinct structured-source subtrees, including primitive leaves. These are not physical TM-state counts.','measurements':result}
    if a.output:a.output.write_text(json.dumps(document,indent=2)+'\n')
    for r in result:print(r['name'],json.dumps(r['metrics']))
if __name__=='__main__':main()
