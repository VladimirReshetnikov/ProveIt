#!/usr/bin/env python3
"""Reconstruct and freshly verify the new 215-state rho6 parameter variant.
Pure Python 3.10+, assertions enabled. No optimizer. This is mathematical
symbolic checking, not a proof-assistant kernel or a 214-state claim.
"""
from pathlib import Path
import argparse, gzip, hashlib, json, sys, time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE/'runtime'))
import source_language as sl
import build221 as bt
import symbolic_runtime as sr

PARENT_TABLE='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
PARENT_SOURCE='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
VARIANT_TABLE='5ae9559203b0eb54e2d417e6d58793a2a696d023d40e7969d7192771005db28e'
VARIANT_SOURCE='19da13e482ea0f3d57432aad852bdf2448093e58a6e3b3873ac744eae7440693'
NAME='row-rho6-swapBC-2020-215'

def sha(data):return hashlib.sha256(data).hexdigest()
def dump(path,data):path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--output',type=Path,default=ROOT/'evidence'/'fresh-variant')
 ap.add_argument('--structural-only',action='store_true')
 a=ap.parse_args()
 assert __debug__ and not sys.flags.optimize,'Assertions must be enabled'
 a.output.mkdir(parents=True,exist_ok=True)
 begun=time.monotonic()
 raw=(ROOT/'upstream/k215.native.tm').read_bytes()
 source=(ROOT/'upstream/sites215.json').read_bytes()
 assert sha(raw)==PARENT_TABLE and sha(source)==PARENT_SOURCE
 old=bt.read_table(raw); oldrows=json.loads(source)
 rows=[x.copy() for x in oldrows]
 lo,hi=888,1171
 for i in range(lo,hi):
  p,op,arg=rows[i]
  if op in ('CI','CD') and arg in (3,5):rows[i]=[p,op,8-arg]
 newsource=sl.compact(rows)
 assert sha(newsource)==VARIANT_SOURCE
 assert newsource==(ROOT/'machine215'/f'{NAME}.sites.json').read_bytes()
 g0,_=sl.graph_arithmetic(oldrows);g1,_=sl.graph_arithmetic(rows)
 assert g0==sl.graph_intervals(oldrows) and g1==sl.graph_intervals(rows)
 assert [t for e,t in g0]==[t for e,t in g1]
 assert {v for i in range(lo,hi) for v in g0[i][1] if not lo<=v<hi}=={hi}
 assert all(not lo<v<hi for i in range(len(g0)) if not lo<=i<hi for v in g0[i][1])
 recipe=json.loads((ROOT/'machine215'/f'{NAME}.json').read_text())
 T=old.copy()
 for q,b,w,d,z in recipe['changed_rows']:
  assert (q,b) in T and d in (-1,1) and w in (0,1)
  T[q,b]=(w,d,z)
 newraw=bt.table_bytes(T)
 assert sha(newraw)==VARIANT_TABLE
 assert newraw==(ROOT/'machine215'/f'{NAME}.native.tm').read_bytes()
 assert len(T)==430 and len({q for q,b in T})==215
 states=sorted({q for q,b in T})
 mapping={q:i for i,q in enumerate(states)};mapping[254]=215
 assert mapping[0]==0
 dense={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in T.items()}
 dense_raw=bt.table_bytes(dense)
 (a.output/'variant215.tm').write_bytes(dense_raw)
 dump(a.output/'canonicalization.json',{'native_to_dense':mapping,'start':0,'halt':215})
 groups,paths=bt.decoder_map(T,sl.tree(rows))
 metric=sl.metrics(sl.tree(rows))
 assert metric=={'dag_nodes':202,'leaf_occurrences':4751,'maximum_depth':47,'maximum_zero_run':6}
 # Independent complete blank execution, followed by literal frame construction.
 q,h,ones=0,0,set(); tracehash=hashlib.sha256()
 with gzip.open(a.output/'blank_trace.jsonl.gz','wt') as f:
  for tick in range(95726):
   b=int(h in ones);w,d,z=T[q,b]
   line=json.dumps([q,h,b,w,d,z],separators=(',',':'))+'\n'
   tracehash.update(line.encode());f.write(line)
   if w:ones.add(h)
   else:ones.discard(h)
   q,h=z,h+d
 physical=[0]*9;physical[sr.r.PHY[0]]=4
 expected={-9,57};p=58
 for v in physical+[1]*40:
  expected.update(range(p+1,p+v+2));p+=v+2
 assert (q,h)==(84,-8) and ones==expected
 startup={'steps':95726,'state':q,'head':h,'header':57,'gap':1,
          'registers':[4,0,0,0,0,0,0,0,0],'spares':[1]*40,
          'ones':sorted(ones),'complete_zero_exterior':True,
          'uncompressed_trace_sha256':tracehash.hexdigest()}
 dump(a.output/'startup.json',startup)
 report={'status':'STRUCTURAL_AND_BLANK_PASS','working_states':215,
         'transition_rows':430,'table_sha256':sha(newraw),
         'source_sha256':sha(newsource),'dense_sha256':sha(dense_raw),
         'source_metrics':metric,'changed_rows':len(recipe['changed_rows']),
         'row_interval':[lo,hi],'source_recipe':'swap register roles 3 and 5 in CI/CD only within [888,1171)',
         'both_CFG_resolvers_agree':True,'guarded_edges_unchanged':True,
         'closed_single_entry_row':True,'decoder_prefixes':sum(map(len,paths.values())),
         'blank':startup,'kernel_checked':False}
 if not a.structural_only:
  m={int(k):int(v) for k,v in json.loads((HERE/'inputs/legacy_mapping.json').read_text()).items()}
  for q in states+[254]:
   if q not in m:m[q]=q+1000
  assert len({m[q]for q in states+[254]})==216
  L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}
  lemmas,blocks=sr.prove_blocks(L)
  used=set();count=rules=0;minimum=None;casehash=hashlib.sha256()
  for block in blocks:
   for event in block['trace']:
    if event[0]!='list':used.add(tuple(event[1][:2]))
  with gzip.open(a.output/'runtime_cases.jsonl.gz','wt') as f:
   for i,site in enumerate(rows):
    for positive in ((False,True) if site[1]=='CD' else (False,)):
     ans=sr.case(L,lemmas,site,positive)
     count+=1;rules+=ans['symbolic_steps'];used.update(ans['rows'])
     minimum=ans['duration'][0] if minimum is None else min(minimum,ans['duration'][0])
     ans['rows']=sorted(ans['rows']);ans.pop('trace')
     line=json.dumps({'site_index':i,'positive':positive,**ans},separators=(',',':'))+'\n'
     f.write(line);casehash.update(line.encode())
    if (i+1)%1000==0:print('VERIFIED',i+1,'sites;',count,'cases',flush=True)
  assert count==6176 and rules==1699838 and minimum>0
  assert used==set(L),'All literal rows must be accounted for by cases or block schemas'
  report.update(status='UNIVERSAL_MATHEMATICAL_PASS',proved_cases=count,
                symbolic_rules=rules,minimum_duration_constant=minimum,
                covered_transition_rows=len(used),blocks=blocks,
                uncompressed_case_stream_sha256=casehash.hexdigest(),
                runtime_scope='All natural primary values at each guard, arbitrary natural gap, arbitrary nonempty finite spare list, complete zero exterior. Unary and finite-list induction; finite bounds only on proof construction.')
 report['seconds']=time.monotonic()-begun
 report['checker_sha256']=sha(Path(sr.__file__).read_bytes())
 report['helper_sha256']=sha(Path(sr.r.__file__).read_bytes())
 report['source_semantics']='Ordinary rho6 parameter-renaming argument in report.tex, relying on pinned upstream K215 compiler/calculus calibration.'
 dump(a.output/'result.json',report)
 print(json.dumps({k:v for k,v in report.items()if k not in ('blocks','blank')},indent=2),flush=True)

if __name__=='__main__':main()
