#!/usr/bin/env python3
"""Prepare a relocated copy of selected exploratory inputs; never edit the archive/repo."""
from pathlib import Path
import argparse,gzip,json,shutil,subprocess
PIN='2762b8a183830b1f5a30cf059ffb4d92e77cddde'
OLD='/workspace/scratch/e33dac3aae74'

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();repo=a.repo.resolve();out=a.output.resolve()
    if out.exists():ap.error('Output must not already exist')
    head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
    if head!=PIN:ap.error('Repository HEAD differs from pinned revision '+PIN)
    source=Path(__file__).resolve().parents[1]/'research/workspace'
    if out.is_relative_to(repo) or out.is_relative_to(source.parents[1]):
        ap.error('Replay output must be outside the repository and archive')
    shutil.copytree(source,out)
    (out/'ProveIt').symlink_to(repo,target_is_directory=True)
    changed=[];expanded=[]
    for p in sorted(x for name in ('root_work','encoding_work','formalism_work','independent_work') for x in (out/name).rglob('*.py')):
        s=p.read_text();t=s.replace(OLD,str(out))
        if s!=t:p.write_text(t);changed.append(str(p.relative_to(out)))
    for p in sorted(x for name in ('root_work','encoding_work','formalism_work','independent_work') for x in (out/name).rglob('*.json.gz')):
        dest=p.with_suffix('');data=gzip.decompress(p.read_bytes())
        if dest.exists() and dest.read_bytes()!=data:
            raise ValueError('Conflicting compressed/uncompressed input: '+str(dest))
        if not dest.exists():dest.write_bytes(data);expanded.append(str(dest.relative_to(out)))
    receipt={'pinned_repository':str(repo),'commit':head,'replay_root':str(out),'rewritten_python_files':changed,'expanded_inputs':expanded,'note':'Exploratory scripts retain their individual working-directory conventions. This helper is not a machine verification.'}
    (out/'RELOCATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
