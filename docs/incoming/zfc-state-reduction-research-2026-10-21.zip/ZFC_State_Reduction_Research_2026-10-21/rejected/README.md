# Rejected and incomplete machine proposals

**Nothing in this directory is an accepted ZFC consistency machine with at most 214 states.**

## Shortened scanner

`shortscan214.native.tm` removes native state 50 and changes row 34/0 from `0 L 50` to `0 R 75`. It can reach a plausible frame from blank input after 86,816 steps, but the full inherited quantified runtime checker cannot prove 37 guarded cases. The first failing case is source site 26, a zero decrement of register 1. The problematic addresses end in six zeros. See `shortscan214.result.json` and the report.

Failure of this universal simulation contract blocks this proposed proof. It is not, by itself, a theorem that the machine's ultimate halting predicate differs from the parent's. The table is supplied to prevent rediscovering and inadvertently accepting the same unsupported shortcut.

## Append-zero experiment

If present, `append_zero214b.*` records a separate failed attempt to remove a spare-handling state. It does not have a verified blank bootstrap or universal source simulation. Later experiments show that rows 66/1 and 198/1 are still needed with all spare blocks equal to one: they inspect the selected primary register.
