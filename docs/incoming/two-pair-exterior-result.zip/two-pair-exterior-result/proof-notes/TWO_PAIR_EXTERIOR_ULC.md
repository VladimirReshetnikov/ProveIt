# ULC with two overlapping pair-neighborhood exterior populations

Status: proposed computer-assisted theorem, independent audit pending. All earlier frozen packages remain unchanged.

## Theorem and precise graph

Let the bipartite shores be

    P union X0 union X1,    Q union Y,

where P={p0,p1}, Q={q0,q1,q2}, and all physical vertex sets are disjoint. The edge set is exactly

    P x Q, P x Y, X0 x {q0,q1}, X1 x {q0,q2}.

The exterior populations X0,X1,Y are arbitrary finite sets. Assign every vertex its own independent nonnegative activity, and count each feasible equal-sized endpoint support once. Then the support polynomial Gamma(t)=sum gamma_k t^k is ULC at its actual surviving degree.

This is a genuinely incomplete exterior family: neither X population is universal to Q. It does not cover arbitrary missing-edge 2+3 graphs, arbitrary orientations, or independent edge weights. Strictness of all inequalities is NOT asserted here.

## Degree and normalization

The physical vertex cover P union Q has size five. If the actual degree d is at most four, delete zero-activity vertices and apply the already approved arbitrary-weight bipartite rank-four theorem. Therefore it suffices to prove

 gamma_1^2 >= (5/2)gamma_2,
 gamma_2^2 >= 2gamma_1 gamma_3,
 gamma_3^2 >= 2gamma_2 gamma_4,
 2gamma_4^2 >= 5gamma_3 gamma_5

at actual degree five. Positive submatchings give no internal zeros.

At degree five both P activities, all three Q activities, and both X-population activity sums are positive. The positive Y population has at least two vertices. Scale every right activity by 1/e1(Y); this scales gamma_k by a positive k-th power and does not change the inequalities. Henceforth e1(Y)=1 and S=e2(Y) satisfies 0<S<1/2.

Write u0,u1 for the P activities and q0,q1,q2 for the head activities, and put

 A=u0+u1, B=u0 u1,
 C=q0+q1+q2, D=q0q1+q0q2+q1q2, E=q0q1q2,
 L=e1(X0), K=e1(X1), M=e2(X0), N=e2(X1).

Both L,K are positive. One of M,N can be zero even at degree five. In this note N is a SECOND moment, not a third elementary sum.

## Exact support decomposition

For the exterior relation X0 union X1 -> Q, let f(t)=1+A0 t+B0 t^2+C0 t^3. Direct Boolean matching gives

 A0=(q0+q1)L+(q0+q2)K,
 B0=q0q1 M+q0q2 N+D L K,
 C0=E(M K+L N).

A size-three exterior support must select two tails from one population and one from the other; either pattern is feasible. A mixed size-two exterior support can use any two Q heads. These facts give the formulas without matching multiplicity.

Let g(t) describe supports using one additional distinguished universal tail of unit activity, and h(t) those using two. Then

 g(t)=C t+G2 t^2+G3 t^3,       h(t)=D t^2+H3 t^3,
 G2=D(L+K), G3=E(M+N+L K), H3=E(L+K).

Every two-head set intersects each pair-neighborhood, explaining G2. Any two distinct X tails admit a matching into Q, explaining G3.

Partitioning by the number of selected Y heads now gives the exact identity

    Gamma(t)=(1+A t+B S t^2)f(t)+(A+B t)g(t)+B h(t).          (1)

For one selected Y head and both P tails selected, either P vertex can witness the Y edge; the endpoint support is still counted once. This accounts for coefficient B, not 2B. Consequently

 gamma_0=1,
 gamma_1=A0+A(C+1),
 gamma_2=B0+A(G2+A0)+B(D+C+S),
 gamma_3=C0+A(G3+B0)+B(H3+G2+S A0),
 gamma_4=A C0+B(G3+S B0),
 gamma_5=B S C0.                                            (2)

The producer's solver-free replay independently reconstructs all six coefficients using a direct perfect-matching existence test on each selected core/population pattern and checks equality with (2).

## Exterior moment coordinates

For every finite nonempty population, e1^2-2e2 is a positive sum of activity squares. Thus

 0<=M<L^2/2,    0<=N<K^2/2,    0<S<1/2.

There are unique nonnegative V0,V1 and positive W with

 M=L^2 V0/[2(1+V0)],
 N=K^2 V1/[2(1+V1)],
 S=W/[2(1+W)].                                               (3)

The inverse formulas are V0=2M/(L^2-2M), V1=2N/(K^2-2N), and W=2S/(1-2S). These cover all finite positive-degree-five data; V0 or V1 may vanish. No unbounded-population limit is used as an assumption.

## Two exact middle certificates

Substitute (3) into each middle gap in (2), and multiply by

    64(1+V0)^2(1+V1)^2(1+W)^2.                              (4)

The result is an integer polynomial in the order

    (u0,u1,q0,q1,q2,L,K,V0,V1,W).

Both substitutions are exact. Unlike the complete-exterior three-head proof, no third-moment upper-bound replacement is used here.

The files core63_gap2.json and core63_gap3.json supply identities

    F(x)=sum_l lambda_l x^(m_l)(r_l x^(a_l)-x^(b_l))^2+R(x),  (5)

with positive rational lambda_l,r_l, nonnegative integer exponents, and every remainder coefficient nonnegative. Their statistics are:

 file                 target terms   squares   positive remainder terms
 core63_gap2.json          6174          398            5730
 core63_gap3.json          3892          158            3700

Exact expansion proves both middle inequalities for all nonnegative moment coordinates. Some coordinates can vanish, so a nonempty remainder is not by itself used to assert strictness.

## Ordinary reduction of the last gap

The following algebra works more generally for any X -> Q exterior relation when the two P tails are universal and Y is universal to P. Retain the side quantities A0,B0,C0,G2,G3,H3 in (2), and define

 J=(4-5S)G3-S B0,
 T=2(G3+S B0)^2-5S C0(H3+G2+S A0),
 tau=4B/A^2 in (0,1],    eta=B/A>0.

Expansion of (2) gives

 [2gamma_4^2-5gamma_3gamma_5]/A^2
 =C0^2(2-5 tau S/4)+eta C0 J+eta^2 T.                       (6)

At fixed eta and all side quantities, the right side decreases as tau increases to one. The case tau=1 is realized by equal P activities 2eta each. Thus equal P activities are sufficient for the last-gap problem after this normalization; no analogous claim is made for the middle gaps.

Define the smaller polynomial

 Delta=(6-5S)G3^2+2(4-3S)G3 B0+S(3-2S)B0^2
       -(8-5S)C0(H3+G2+S A0).                              (7)

The exact identities

    (8-5S)T-J^2=5S Delta

and

 [2gamma_4^2-5gamma_3gamma_5]/A^2
 >= {[(8-5S)C0+2eta J]^2+20S eta^2 Delta}/[4(8-5S)]         (8)

follow from tau<=1. Since 8-5S>0, it suffices to prove Delta>=0. The separate exact checker check_last_reduction.py verifies every identity (6)--(8), including the positive tau slack, as symbolic identities.

## Four ordered discriminant certificates and complete coverage

First substitute (3) into (7) and multiply by the same positive factor (4). This gives an integer polynomial in

    (q0,q1,q2,L,K,V0,V1,W).

The graph and formulas are invariant under swapping q1 with q2 while simultaneously swapping X0 with X1, hence L with K, M with N, and V0 with V1. Therefore assume q1<=q2 without loss of generality. There are three head-order cases. Write c>0 and d,e>=0 for the minimum and consecutive head differences.

1. q1<=q0<=q2: q1=c, q0=c+d, q2=c+d+e. Keep L,K independent. Use ordered_discriminant_1.json.
2. q1<=q2<=q0: q1=c, q2=c+d, q0=c+d+e. Keep L,K independent. Use ordered_discriminant_2.json.
3. q0<=q1<=q2: q0=c, q1=c+d, q2=c+d+e. Split by the exterior sums:
   - L>=K: set K=b>0, L=b+h with h>=0; use ordered_discriminant_mass_0.json.
   - K>=L: set L=b>0, K=b+h with h>=0; use ordered_discriminant_mass_1.json.

The substitutions permit ties and cover every activity assignment. The case variables are ordered (c,d,e,L,K,V0,V1,W) for cases 1,2 and (c,d,e,b,h,V0,V1,W) for the split case 3. Moment variables V0,V1 keep their original population meaning throughout; the polynomial already contains each population sum squared in (3), so substituting L,K also transforms those factors exactly.

Each of the four resulting targets has the form (5). Exact statistics are:

 file                                  target terms  squares  positive remainder terms
 ordered_discriminant_1.json                2403        172           2212
 ordered_discriminant_2.json                2475        123           2333
 ordered_discriminant_mass_0.json           3258        183           3053
 ordered_discriminant_mass_1.json           3330        125           3186

All coefficients of all four reconstructed remainders are nonnegative. Hence Delta>=0 in every case, including zero second moments and vanishing order differences. Equations (6)--(8) prove the last Newton inequality for arbitrary P activities.

## First gap and the actual-degree conclusion

The universal compatibility-graph argument at matching degree five gives gamma_1^2>=(5/2)gamma_2. Namely, arc/edge weights give total mass gamma_1 on the edge-disjointness graph, whose clique number is five. Moving mass between nonadjacent vertices toward the larger weighted neighborhood cannot decrease the weighted edge sum, and eventually leaves a clique. Cauchy's inequality bounds that edge sum by 2gamma_1^2/5. Every size-two endpoint support has at least one witness of the same activity weight.

Here the positive P x Y block contains a K_(2,2), so the first gap is in fact strict. We do not need or claim strictness of the other three gaps on all moment/order boundaries.

Combining this first inequality, the two middle certificates, and the last-gap reduction proves ULC at degree five. The frozen arbitrary-weight bipartite rank-four theorem handles all lower actual degrees, including every zero-activity or missing-population drop.

## Exact replay and proof status

There are six retained certificates and 1,159 positive rational square terms in total. Exact reconstruction gives 20,214 positive remainder terms. Run replay_pair_certificates.py in a directory containing all six JSON certificate files. The checker uses only Python's standard library. It reconstructs the Boolean support polynomial, verifies (2), constructs the two middle targets and the four discriminant targets, expands all rational squares, and checks every residual coefficient including newly introduced monomials. It records all target, remainder and certificate SHA-256 values in pair_exact_replay.json.

Run check_last_reduction.py separately for the four symbolic ordinary last-gap identities; it uses SymPy 1.14.0 and writes last_reduction_receipt.json.

Floating-point optimization was used only to discover candidate certificates. All retained coefficients were reconstructed as rationals and checked by exact subtraction. Solver status and random searches are not proof inputs. The target/remainder counts above describe full algebraic identities on unbounded domains, not sampled populations. A dedicated independent reconstruction and proof audit are pending.
