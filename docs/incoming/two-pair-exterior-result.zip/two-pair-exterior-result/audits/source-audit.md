# Independent audit: two overlapping pair-neighborhood populations

Verdict: **APPROVED**, October 1, 2026. The actual-degree ULC theorem follows from the ordinary support/moment/symmetrization reduction and six exact rational certificates, with the approved weighted bipartite rank-four theorem for degree drops. Strictness of all four inequalities is not asserted.

## Exact graph and Boolean support counts

The physical shores are disjoint `P union X0 union X1` and `Q union Y`, with two P vertices, three Q vertices and exactly `P×Q`, `P×Y`, `X0×{q0,q1}`, `X1×{q0,q2}`. All populations are arbitrary finite sets and activities are independent nonnegative vertex activities. No arbitrary orientations, missing edges within these blocks, or independent edge weights are included.

The independent checker constructs each selected physical subgraph and applies Hall's condition to every selected-tail subset. Each X population can contribute at most two selected tails, and the total exterior-tail count is at most three, because its neighborhood lies in Q. These are structural bounds on a single support, not bounds on the populations. It reconstructs the six full coefficients and the three side polynomials f,g,h, where the distinguished universal tail or tails are forced to be selected in g and h.

The side formulas in the note agree exactly. Three exterior tails must split 2+1 or1+2 across the populations; two from different populations can match every two-head subset. One universal extra tail can accompany every feasible exterior pair, while two universal extra tails can accompany each exterior singleton. These are Boolean conditions; no factor counting witnesses is inserted.

The full identity `(1+A t+B S t^2)f+(A+B t)g+B h` is exact after e1(Y)=1. In the one-Y-head/two-P-tail case, choosing which P tail supplies the Y edge is a matching witness choice, not a new endpoint support. The correct coefficient is B. Independent full selected-subgraph reconstruction agrees with the convolution, verifying all six displayed gamma coefficients without relying only on that explanation.

## Positive-degree domain and moment coordinates

At degree five, the five-vertex physical cover is saturated by a positive matching. Thus all P/Q activities are positive, at least two positive Y activities exist, and `gamma5=B S E(M K+L N)>0`. In particular L,K>0 and at least one of M,N is positive, but the other may vanish. Scaling all right activities by the positive e1(Y) preserves every Newton sign and normalizes e1(Y)=1.

For every finite population with positive first moment, the sum of individual activity squares is positive, so `2M<L^2`, `2N<K^2`, `2S<1`. The note's rational inverse coordinates therefore exist with V0,V1>=0 and W>0. They cover all finite degree-five cases, including a population with only one positive vertex. There is no assertion that every relaxed moment point has to be realizable by a finite population.

Both middle substitutions are exact; N is the second moment of X1 and is not replaced by any third-moment bound. The positive factor `64(1+V0)^2(1+V1)^2(1+W)^2` clears every denominator. The independent checker reconstructs these target polynomials from the Hall coefficients. It also directly compares rational substitution and denominator-cleared evaluation for each middle target and for the discriminant target.

## Harmonic-mean symmetrization and last-gap direction

Write J,T as in the note. Exact expansion gives

`(2 gamma4^2−5 gamma3 gamma5)/A^2=C0^2(2−5 tau S/4)+eta C0 J+eta^2 T`,

with `tau=4B/A^2<=1` and `eta=B/A>0`. Holding eta and all side data fixed, its derivative with respect to tau is `−5S C0^2/4<=0`. Replacing both P activities by `2eta=2u0u1/(u0+u1)` realizes tau=1 with the same eta. This is the harmonic mean, not a fixed-sum averaging argument; comparing the normalized gaps is sufficient because A^2 is positive. No symmetrization of the middle gaps is assumed.

The independently verified identity `(8−5S)T−J^2=5S Delta` gives the displayed completed square. Since S<1/2, its denominator `4(8−5S)` is positive. Hence Delta>=0 suffices for the last Newton inequality. The condition is sufficient, not an asserted equivalence. All four ordinary symbolic identities, including the tau slack direction and completed-square numerator, pass exact independent expansion.

## Head orders, mass cases and zero boundaries

Swapping private heads q1,q2 together with X0,X1 leaves the graph and all side formulas invariant. The independent symbolic check confirms the simultaneous swap of L,K and M,N as well. Thus q1<=q2 may be assumed, while q0 can be the minimum, middle or maximum. The first two certificates treat q1<=q0<=q2 and q1<=q2<=q0 directly. The remaining order q0<=q1<=q2 is split by L>=K or K>=L. These four cases cover all assignments.

The head coordinates are the positive minimum c and two nonnegative consecutive differences d,e. In the split mass case, b=min(L,K)>0 and h=|L−K|>=0. Ties are allowed; all maps use closed nonnegative cones. V0,V1 retain their original population labels. Substituting L,K after the moment substitution correctly changes the population-sum-squared factors, rather than incorrectly treating M,N as fixed under a mass relabeling.

The independent target reconstruction first forms the exact Delta from the Hall-derived side coefficients, applies the moment substitution, then applies the stated head/mass linear maps. All four resulting target polynomials agree with the exact supplied certificate data. A nonempty remainder is not used to infer strict positivity: V0 or V1, head differences and the mass difference can all vanish at degree five. Nonnegativity is enough, and the final theorem correctly claims ULC only.

## Exact certificates and all-degree conclusion

Both middle and all four discriminant targets pass independent square subtraction: 398,158,172,123,183,125 positive rational squares respectively, totaling1,159. Their reconstructed nonnegative remainders have5,730,3,700,2,212,2,333,3,053,3,186 nonzero coefficients, totaling20,214. The checker verifies exponent dimensions/nonnegative integrality and positive rational scalar weights, subtracts all three terms of every square including previously absent monomials, and rejects every negative residual. It invokes no producer code or numerical solver. Every target and remainder hash matches the separately implemented producer replay.

The first degree-five inequality follows from the universal edge-compatibility/Motzkin–Straus argument. It is actually strict because positive P×Y contains a K2,2 with duplicate matching witnesses, although the theorem does not require strictness. Positive submatchings give no internal zeros.

For every lower actual degree, delete zero-activity vertices before invoking the approved arbitrary-weight bipartite matching-rank-at-most-four theorem. The induced graph's matching number equals the surviving degree, and its support polynomial is unchanged. This handles empty populations and all activity-induced rank drops without dividing by a zero moment or retaining order-five normalization.

The final result is computer-assisted through six rational identities on unbounded parameter domains, not inferred from finite numerical samples. Earlier releases remain frozen; general missing-edge2+3 graphs remain open. No real-rootedness, blanket strictness, priority or proof-assistant claim is made.

## Replay

`check.py` accepts `--data-dir` and `--output-dir` and uses Python3 plus SymPy for independent symbolic reconstruction. It rejects disabled assertions. The 208 selected-subgraph Hall tests cover every support pattern needed for the formal coefficients. The receipt pins the exact proof note and all six certificates. Finite/rational evaluations corroborate the reviewed identities rather than replacing their symbolic proof.
