# Weighted support inequalities for overlapping pair neighborhoods

This package proves actual-degree rank ultra log concavity for a bipartite graph with a complete two-by-three core, two exterior tail populations adjacent respectively to head pairs {0,1} and {0,2}, and an exterior head population universal to the two core tails. Every vertex has its own independent nonnegative activity, and all three exterior populations are arbitrary finite sets.

The paper includes a vector block-adjacency diagram and a complete edge-set definition. Neither exterior tail population is universal to the three core heads. Each feasible endpoint support is counted once, regardless of matching multiplicity.

## Proof

An exact support decomposition gives all six coefficients. Rational moment coordinates cover arbitrary finite populations, including zero second moments. Two exact certificates prove the middle Newton inequalities. An ordinary harmonic-mean reduction shows that equal activities on the two universal core tails are worst for the normalized last gap; a square identity then reduces the last gap to a smaller discriminant polynomial. Four head-order/mass cases cover that polynomial, including all ties.

There are six certificates, 1,159 positive rational square terms and 20,214 positive remainder terms. Two independently implemented reconstructions agree on every target and remainder hash. The universal first-gap proof and the previously approved rank-four theorem supply the outer first inequality and correct normalization after degree drops.

No blanket strictness or real-rootedness is claimed. Zero moment coordinates and order differences can occur even at degree five. General missing-edge 2+3 graphs, arbitrary directed orientations and independent edge weights remain outside the theorem.

## Files

- `article/two-pair-exterior.pdf` and `.tex`: standalone paper, vector diagram and editable source
- `proof-notes/TWO_PAIR_EXTERIOR_ULC.md`: approved proof snapshot with all case substitutions
- `certificates/`: two middle and four discriminant certificates
- `reproducibility/producer/`: solver-free rational replay and exact scalar-identity checks
- `reproducibility/independent/`: direct Hall reconstruction and independent exact certificate replay
- `audits/`: independent source and integrated-paper approval
- `dependency/`: unchanged complete rank-four package and readable manuscript
- `qa/visual-qa.json`: final every-page PDF inspection record

The approved snapshot retains its historical pending-status line so its pinned bytes remain unchanged. The included later approval receipts state the review outcome.

## Replay

Use Python 3.10 or later and SymPy 1.14.0, with assertions enabled. Tested with Python 3.12.14:

    PYTHONDONTWRITEBYTECODE=1 python3 verify.py

The producer certificate checker itself uses only the standard library. The scalar and independent checkers use SymPy for exact algebra. No optimizer is required. The driver verifies exact manifest coverage, safely extracts the frozen rank-four dependency into temporary storage, replays all four of its checkers and regenerates its earlier certificate, then runs temporary copies of all new checks. Every deterministic receipt field must agree, excluding timings only. It separately compares all six producer and independent target/remainder hashes. No released file is overwritten.

The independent reconstruction performs 208 selected-subgraph Hall tests, checks six support and six side coefficients, verifies four ordinary scalar identities and the branch-swap symmetry, and replays all six certificates. Numerical optimization was used only for discovery; rational identities and residual signs constitute the proof.

## Degree drop dependency

`dependency/matching-rank-four-package.zip` is the byte-preserved earlier release, SHA-256 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66. Its Theorem 1.1 covers arbitrary nonnegative vertex weights on every bipartite graph whose positive-activity matching number is at most four. That is precisely the fallback used here; padded degree-five inequalities are not treated as surviving-degree normalization.

Rebuild the article in a copy using a normal TeX Live or MiKTeX installation with TikZ:

    sh build.sh

Rebuilding can change PDF metadata and hashes. No proof-assistant formalization, literature-wide priority claim or external publication is asserted. All previous frozen releases remain unchanged.
