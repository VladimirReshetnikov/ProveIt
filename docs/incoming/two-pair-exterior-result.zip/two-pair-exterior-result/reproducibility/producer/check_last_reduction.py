#!/usr/bin/env python3
import sympy as s,json
from pathlib import Path
A,B,S,A0,B0,C0,G2,G3,H3,eta,tau=s.symbols('A B S A0 B0 C0 G2 G3 H3 eta tau')
g3=C0+A*(G3+B0)+B*(H3+G2+S*A0)
g4=A*C0+B*(G3+S*B0);g5=B*S*C0
K=(4-5*S)*G3-S*B0
Q=2*(G3+S*B0)**2-5*S*C0*(H3+G2+S*A0)
Delta=(6-5*S)*G3**2+2*(4-3*S)*G3*B0+S*(3-2*S)*B0**2-(8-5*S)*C0*(H3+G2+S*A0)
assert s.expand(2*g4**2-5*g3*g5-(C0*C0*(2*A*A-5*B*S)+A*B*C0*K+B*B*Q))==0
assert s.expand((8-5*S)*Q-K*K-5*S*Delta)==0
assert s.cancel((2*g4**2-5*g3*g5)/A**2-(C0*C0*(2-s.Rational(5,4)*tau*S)+eta*C0*K+eta**2*Q).subs({tau:4*B/A**2,eta:B/A}))==0
lower=C0*C0*(2-s.Rational(5,4)*S)+eta*C0*K+eta**2*Q
square=((8-5*S)*C0+2*eta*K)**2+20*S*eta**2*Delta
assert s.expand(4*(8-5*S)*lower-square)==0
receipt={'verdict':'PASS','master_last_gap_expansion':True,'tail_symmetrization_identity':True,'discriminant_identity':True,'final_square_identity':True,'sympy_version':s.__version__}
Path(__file__).with_name('last_reduction_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
