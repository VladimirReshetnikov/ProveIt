#!/usr/bin/env python3
"""Solver-free exact replay for the two pair-neighborhood exterior family."""
if not __debug__:raise SystemExit('Run without -O; assertions are required.')
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import comb
from functools import lru_cache
import hashlib,json,time
ROOT=Path(__file__).resolve().parent

def add(*polys):
 r={}
 for p in polys:
  for a,c in p.items():r[a]=r.get(a,0)+c
 return{a:c for a,c in r.items()if c}
def scale(p,c):return {a:b*c for a,b in p.items()if b*c}
def mul(p,q):
 r={}
 for a,c in p.items():
  for b,d in q.items():
   e=tuple(x+y for x,y in zip(a,b));r[e]=r.get(e,0)+c*d
 return {e:c for e,c in r.items()if c}
def sq(p):return mul(p,p)
def var(dim,i):
 e=[0]*dim;e[i]=1;return{tuple(e):1}
def const(dim,c):return{(0,)*dim:c}if c else{}
def side(dim,offset):
 q0,q1,q2,L,K,M,N,S=[var(dim,offset+i)for i in range(8)]
 D=add(mul(q0,q1),mul(q0,q2),mul(q1,q2));E=mul(mul(q0,q1),q2)
 A0=add(mul(add(q0,q1),L),mul(add(q0,q2),K))
 B0=add(mul(mul(q0,q1),M),mul(mul(q0,q2),N),mul(mul(D,L),K))
 C0=mul(E,add(mul(M,K),mul(L,N)))
 G2=mul(D,add(L,K));G3=mul(E,add(M,N,mul(L,K)));H3=mul(E,add(L,K))
 return A0,B0,C0,G2,G3,H3,D,E,S,add(q0,q1,q2)
def kernel():
 g=[{}for _ in range(6)]
 for I in range(4):
  tails=[i for i in range(2)if I>>i&1]
  for J in range(8):
   heads=[j for j in range(3)if J>>j&1]
   for counts in product(range(3),repeat=2):
    if sum(counts)>3:continue
    k=len(tails)+sum(counts);ny=k-len(heads)
    if not(0<=ny<=2 and k<=5):continue
    neighbors=[list(range(len(heads)+ny))for _ in tails]
    for mask,num in zip([3,5],counts):neighbors.extend([[j for j,q in enumerate(heads)if mask>>q&1]]*num)
    def exists(at,used):return at==len(neighbors)or any(not used>>j&1 and exists(at+1,used|1<<j)for j in neighbors[at])
    if not exists(0,0):continue
    a=tuple((I>>i)&1 for i in range(2))+tuple((J>>j)&1 for j in range(3))+tuple(int(c==1)for c in counts)+tuple(int(c==2)for c in counts)+(int(ny==2),)
    g[k][a]=g[k].get(a,0)+1
 return g
def cone(p,core_count):
 start=core_count+2;powers=[max(a[i]for a in p)for i in range(start,start+3)];out={}
 for a,c in p.items():
  mom=a[start:];base=list(a[:start]);base[core_count]+=2*mom[0];base[core_count+1]+=2*mom[1];c=F(c)*64/F(2**sum(mom))
  for shifts in product(*(range(d-e+1)for d,e in zip(powers,mom))):
   e=tuple(base)+tuple(x+y for x,y in zip(mom,shifts));value=c
   for d,m,h in zip(powers,mom,shifts):value*=comb(d-m,h)
   out[e]=out.get(e,F(0))+value
 return{e:c for e,c in out.items()if c},powers
@lru_cache(None)
def linear_power(dim,cols,n):
 p=const(dim,1);q=add(*(var(dim,i)for i in cols))
 for _ in range(n):p=mul(p,q)
 return p
def transform(p,maps):
 dim=len(next(iter(p)));out={}
 for a,c in p.items():
  tail=list(a)
  for i in maps:tail[i]=0
  term={tuple(tail):c}
  for i,cols in maps.items():term=mul(term,linear_power(dim,tuple(cols),a[i]))
  out=add(out,term)
 return out
def phash(p):return hashlib.sha256(json.dumps([[list(a),str(F(c))]for a,c in sorted(p.items())],separators=(',',':')).encode()).hexdigest()
def verify(file,target):
 data=json.loads((ROOT/file).read_text());record=data['record'];dim=len(next(iter(target)))
 assert record.get('terms',record.get('target_terms'))==len(target)
 assert record.get('negatives',record.get('negative_terms'))==sum(c<0 for c in target.values())
 assert record['squares']==len(data['squares']);r={a:F(c)for a,c in target.items()}
 for coefficient,(m,a,b,rho)in data['squares']:
  coefficient,rho=F(coefficient),F(rho);assert coefficient>0 and rho>0
  assert all(len(e)==dim and all(type(i)is int and i>=0 for i in e)for e in [m,a,b])
  for e,c in [(tuple(x+2*y for x,y in zip(m,a)),coefficient*rho*rho),(tuple(x+y+z for x,y,z in zip(m,a,b)),-2*coefficient*rho),(tuple(x+2*y for x,y in zip(m,b)),coefficient)]:r[e]=r.get(e,F(0))-c
 assert all(c>=0 for c in r.values()),file
 r={a:c for a,c in r.items()if c};assert r
 return {'file':file,'target_terms':len(target),'negative_target_terms':sum(c<0 for c in target.values()),'squares':len(data['squares']),'positive_remainder_terms':len(r),'target_sha256':phash(target),'remainder_sha256':phash(r),'certificate_sha256':hashlib.sha256((ROOT/file).read_bytes()).hexdigest()}
start=time.monotonic();records=[];g=kernel()
u0,u1=var(10,0),var(10,1);A=add(u0,u1);B=mul(u0,u1)
A0,B0,C0,G2,G3,H3,D,E,S,C=side(10,2)
formula=[const(10,1),add(A0,mul(A,add(C,const(10,1)))),add(B0,mul(A,add(G2,A0)),mul(B,add(D,C,S))),add(C0,mul(A,add(G3,B0)),mul(B,add(H3,G2,mul(S,A0)))),add(mul(A,C0),mul(B,add(G3,mul(S,B0)))),mul(mul(B,S),C0)]
assert g==formula
for k in [2,3]:
 target,powers=cone(add(sq(g[k]),scale(mul(g[k-1],g[k+1]),-2)),5)
 assert powers==[2,2,2]
 records.append(verify(f'core63_gap{k}.json',target))
A0,B0,C0,G2,G3,H3,D,E,S,C=side(8,0);one=const(8,1)
Delta=add(mul(add(scale(one,6),scale(S,-5)),sq(G3)),scale(mul(mul(add(scale(one,4),scale(S,-3)),G3),B0),2),mul(mul(S,add(scale(one,3),scale(S,-2))),sq(B0)),scale(mul(mul(add(scale(one,8),scale(S,-5)),C0),add(H3,G2,mul(S,A0))),-1))
base,powers=cone(Delta,3);assert powers==[2,2,2]
for branch,order in [(1,(1,0,2)),(2,(1,2,0))]:
 maps={col:tuple(range(rank+1))for rank,col in enumerate(order)}
 records.append(verify(f'ordered_discriminant_{branch}.json',transform(base,maps)))
ordered=transform(base,{0:(0,),1:(0,1),2:(0,1,2)})
for branch,maps in enumerate([{3:(3,4),4:(3,)},{3:(3,),4:(3,4)}]):
 records.append(verify(f'ordered_discriminant_mass_{branch}.json',transform(ordered,maps)))
assert sum(r['squares']for r in records)==1159
receipt={'verdict':'PASS','support_coefficients':6,'middle_certificates':2,'discriminant_certificates':4,'total_squares':sum(r['squares']for r in records),'total_positive_remainder_terms':sum(r['positive_remainder_terms']for r in records),'middle_variable_order':['u0','u1','q0','q1','q2','L','K','V0','V1','W'],'discriminant_variable_order':['q0','q1','q2','L','K','V0','V1','W'],'records':records,'elapsed_seconds':round(time.monotonic()-start,3)}
(ROOT/'pair_exact_replay.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='records'},indent=2))
