#!/usr/bin/env python3
"""Independent Hall targets, harmonic-tail identities and six rational certificates."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from functools import lru_cache
from math import comb
import argparse,hashlib,json,time
import sympy as s
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data-dir',type=Path,default=Path('/workspace/shared/two-pair-exterior-extension'))
parser.add_argument('--output-dir',type=Path,default=Path(__file__).parent)
args=parser.parse_args();started=time.monotonic();hall_tests=0
u0,u1,q0,q1,q2,L,K,M,N,S=s.symbols('u0 u1 q0 q1 q2 L K M N S')
fullvars=(u0,u1,q0,q1,q2,L,K,M,N,S);sidevars=(q0,q1,q2,L,K,M,N,S)
q=[q0,q1,q2];u=[u0,u1]
def feasible(universal,heads,n0,n1,ny=0):
 global hall_tests
 hall_tests+=1
 rows=[(1<<(len(heads)+ny))-1]*universal
 rows += [sum(1<<j for j,h in enumerate(heads)if h in(0,1))]*n0
 rows += [sum(1<<j for j,h in enumerate(heads)if h in(0,2))]*n1
 assert len(rows)==len(heads)+ny
 for mask in range(1,1<<len(rows)):
  union=0
  for i,row in enumerate(rows):
   if mask>>i&1:union|=row
  if union.bit_count()<mask.bit_count():return False
 return True
g=[s.Integer(0)]*6
for im,jm,n0,n1 in product(range(4),range(8),range(3),range(3)):
 I=[i for i in range(2)if im>>i&1];J=[j for j in range(3)if jm>>j&1]
 k=len(I)+n0+n1;ny=k-len(J)
 if k>5 or n0+n1>3 or not 0<=ny<=2:continue
 if feasible(len(I),J,n0,n1,ny):g[k]+=s.prod(u[i]for i in I)*s.prod(q[j]for j in J)*[1,L,M][n0]*[1,K,N][n1]*[1,1,S][ny]
g=list(map(s.expand,g))
side=[]
for universals in range(3):
 row=[s.Integer(0)]*4
 for jm,n0,n1 in product(range(8),range(3),range(3)):
  J=[j for j in range(3)if jm>>j&1];k=universals+n0+n1
  if k!=len(J) or k>3:continue
  if feasible(universals,J,n0,n1):row[k]+=s.prod(q[j]for j in J)*[1,L,M][n0]*[1,K,N][n1]
 side.append(list(map(s.expand,row)))
f,gg,hh=side;A=u0+u1;B=u0*u1
conv=[s.Integer(0)]*6
for i,c in enumerate([1,A,B*S]):
 for j,t in enumerate(f):conv[i+j]+=c*t
for i,c in enumerate([A,B]):
 for j,t in enumerate(gg):conv[i+j]+=c*t
for j,t in enumerate(hh):conv[j]+=B*t
assert all(s.expand(a-b)==0 for a,b in zip(g,conv))
A0,B0,C0=f[1:];C,G2,G3=gg[1:];D,H3=hh[2:]
expected=[(q0+q1)*L+(q0+q2)*K,q0*q1*M+q0*q2*N+(q0*q1+q0*q2+q1*q2)*L*K,q0*q1*q2*(M*K+L*N),(q0*q1+q0*q2+q1*q2)*(L+K),q0*q1*q2*(M+N+L*K),q0*q1*q2*(L+K)]
assert all(s.expand(x-y)==0 for x,y in zip([A0,B0,C0,G2,G3,H3],expected))
# Independent algebra before specialization to the side-family formulas.
aa,bb,a0,b0,c0,g2,g3,h3,ss,eta,tau=s.symbols('A B A0 B0 C0 G2 G3 H3 S eta tau')
cc3=c0+aa*(g3+b0)+bb*(h3+g2+ss*a0);cc4=aa*c0+bb*(g3+ss*b0);cc5=bb*ss*c0
kk=(4-5*ss)*g3-ss*b0;qq=2*(g3+ss*b0)**2-5*ss*c0*(h3+g2+ss*a0)
delta=(6-5*ss)*g3**2+2*(4-3*ss)*g3*b0+ss*(3-2*ss)*b0**2-(8-5*ss)*c0*(h3+g2+ss*a0)
assert s.expand(2*cc4**2-5*cc3*cc5-(c0**2*(2*aa**2-5*bb*ss)+aa*bb*c0*kk+bb**2*qq))==0
assert s.expand((8-5*ss)*qq-kk**2-5*ss*delta)==0
Fnormalized=c0**2*(2-5*tau*ss/4)+eta*c0*kk+eta**2*qq
assert s.diff(Fnormalized,tau)==-5*ss*c0**2/4
assert s.expand(4*(8-5*ss)*Fnormalized.subs(tau,1)-((8-5*ss)*c0+2*eta*kk)**2-20*ss*eta**2*delta)==0
Delta=s.expand(delta.subs({a0:A0,b0:B0,c0:C0,g2:G2,g3:G3,h3:H3,ss:S}))
assert s.expand(Delta-Delta.subs({q1:q2,q2:q1,L:K,K:L,M:N,N:M},simultaneous=True))==0
def terms(expr,vs):return {a:F(int(c.p),int(c.q))for a,c in s.Poly(expr,*vs).terms()}
def multiply(p,q):
 r={}
 for a,c in p.items():
  for b,d in q.items():
   e=tuple(x+y for x,y in zip(a,b));r[e]=r.get(e,F(0))+c*d
 return {e:c for e,c in r.items()if c}
def cone(raw):
 dim=len(next(iter(raw)));out={}
 for a,c in raw.items():
  moments=a[-3:];assert all(n<=2 for n in moments)
  base=list(a[:-3]);base[-2]+=2*moments[0];base[-1]+=2*moments[1]
  factor=c*F(64,2**sum(moments))
  for shift in product(*(range(3-n)for n in moments)):
   e=tuple(base)+tuple(n+h for n,h in zip(moments,shift));value=factor
   for n,h in zip(moments,shift):value*=comb(2-n,h)
   out[e]=out.get(e,F(0))+value
 return {e:c for e,c in out.items()if c}
@lru_cache(None)
def linear_power(dim,cols,n):
 zero=(0,)*dim;out={zero:F(1)};linear={}
 for col in cols:
  e=list(zero);e[col]=1;linear[tuple(e)]=F(1)
 for _ in range(n):out=multiply(out,linear)
 return out
def substitute_linear(poly,mapping):
 dim=len(next(iter(poly)));out={}
 for a,c in poly.items():
  base=list(a)
  for j in mapping:base[j]=0
  current={tuple(base):c}
  for j,cols in mapping.items():current=multiply(current,linear_power(dim,tuple(cols),a[j]))
  for e,vv in current.items():out[e]=out.get(e,F(0))+vv
 return {e:c for e,c in out.items()if c}
def evalpoly(poly,values):return sum(c*s.prod(F(x)**n for x,n in zip(values,a))for a,c in poly.items())
def hashpoly(poly):return hashlib.sha256(json.dumps([[list(a),str(c)]for a,c in sorted(poly.items())],separators=(',',':')).encode()).hexdigest()
targets={f'core63_gap{k}.json':cone(terms(s.expand(g[k]**2-2*g[k-1]*g[k+1]),fullvars))for k in [2,3]}
base=cone(terms(Delta,sidevars))
for branch,order in [(1,(1,0,2)),(2,(1,2,0))]:
 mapping={col:tuple(range(position+1))for position,col in enumerate(order)}
 targets[f'ordered_discriminant_{branch}.json']=substitute_linear(base,mapping)
small=substitute_linear(base,{0:(0,),1:(0,1),2:(0,1,2)})
targets['ordered_discriminant_mass_0.json']=substitute_linear(small,{3:(3,4),4:(3,)})
targets['ordered_discriminant_mass_1.json']=substitute_linear(small,{3:(3,),4:(3,4)})
records=[];hashes={}
for name,target in targets.items():
 path=args.data_dir/name;data=json.loads(path.read_text());meta=data['record'];hashes[name]=hashlib.sha256(path.read_bytes()).hexdigest()
 assert meta['terms']==len(target)
 assert meta.get('negatives',meta.get('negative_terms'))==sum(c<0 for c in target.values())
 assert meta['squares']==len(data['squares'])
 remainder=dict(target);dim=len(next(iter(target)))
 for coefficient,(outer,left,right,rho)in data['squares']:
  weight,rho=F(coefficient),F(rho);assert weight>0 and rho>0
  assert all(len(a)==dim and all(type(x)is int and x>=0 for x in a)for a in [outer,left,right])
  for e,c in [(tuple(m+2*a for m,a in zip(outer,left)),weight*rho*rho),(tuple(m+a+b for m,a,b in zip(outer,left,right)),-2*weight*rho),(tuple(m+2*b for m,b in zip(outer,right)),weight)]:remainder[e]=remainder.get(e,F(0))-c
 assert all(c>=0 for c in remainder.values()),name
 remainder={e:c for e,c in remainder.items()if c};assert remainder
 records.append({'file':name,'target_terms':len(target),'squares':len(data['squares']),'positive_remainder_terms':len(remainder),'target_sha256':hashpoly(target),'remainder_sha256':hashpoly(remainder)})
# Independent denominator-clearing checks for both middle targets and the base Delta.
ordinary_substitution_checks=0
for expr,vs in [(s.expand(g[2]**2-2*g[1]*g[3]),fullvars),(s.expand(g[3]**2-2*g[2]*g[4]),fullvars),(Delta,sidevars)]:
 target=cone(terms(expr,vs));vals=[F(i+1,i%3+1)for i in range(len(vs))]
 mass0,mass1=vals[-5:-3];V,W,Z=vals[-3:]
 rawvals=vals[:-3]+[mass0**2*V/(2*(1+V)),mass1**2*W/(2*(1+W)),Z/(2*(1+Z))]
 actual=expr.subs(dict(zip(vs,[s.Rational(x.numerator,x.denominator)for x in rawvals])))
 multiplier=64*(1+V)**2*(1+W)**2*(1+Z)**2
 assert s.Rational(evalpoly(target,vals))==actual*multiplier
 ordinary_substitution_checks+=1
receipt={'verdict':'PASS','source':'Independent selected-subgraph Hall construction; symbolic ordinary reduction; exact rational square subtraction, no producer imports or optimizer','source_note_sha256':hashlib.sha256((args.data_dir/'TWO_PAIR_EXTERIOR_ULC.md').read_bytes()).hexdigest(),'selected_subgraph_Hall_tests':hall_tests,'support_coefficients':6,'side_coefficients':6,'harmonic_tail_and_discriminant_identities':4,'private_branch_swap_identity':True,'denominator_evaluation_checks':ordinary_substitution_checks,'certificate_count':6,'positive_rational_squares':sum(r['squares']for r in records),'positive_remainder_terms':sum(r['positive_remainder_terms']for r in records),'all_remainders_nonempty':True,'strictness_not_inferred':True,'certificate_sha256':hashes,'records':records,'elapsed_seconds':round(time.monotonic()-started,3)}
args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'independent_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k not in['records','certificate_sha256']},indent=2))
