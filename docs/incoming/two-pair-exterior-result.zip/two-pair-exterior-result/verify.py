#!/usr/bin/env python3
"""Read-only full dependency, certificate and ordinary-identity replay."""
if not __debug__:raise SystemExit('Run without -O; assertions are required.')
from pathlib import Path,PurePosixPath
import hashlib,json,os,shutil,stat,subprocess,sys,tempfile,time,zipfile
ROOT=Path(__file__).resolve().parent
DEP_SHA='9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(v):
 if isinstance(v,dict):return{k:canonical(x)for k,x in v.items()if k not in {'seconds','elapsed_seconds'}}
 if isinstance(v,list):return[canonical(x)for x in v]
 return v
def manifest(p,exact=True):
 r={}
 for line in (p/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);n=n.removeprefix('./');assert n not in r and sha(p/n)==h,n;r[n]=h
 if exact:assert {q.relative_to(p).as_posix()for q in p.rglob('*')if q.is_file()and q.name!='SHA256SUMS'}==set(r),'Manifest coverage is not exact'
 return r
def run(script,cwd,args=()):
 p=subprocess.run([sys.executable,str(script),*map(str,args)],cwd=cwd,text=True,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 if p.returncode:
  print(p.stdout);print(p.stderr,file=sys.stderr);raise AssertionError(script.name)
 return p.stdout
def compare(actual,expected,label):
 assert canonical(actual)==canonical(expected),f'Receipt mismatch: {label}'
 print(f'PASS: {label}; every deterministic receipt field matches',flush=True)
def main():
 start=time.monotonic();original=manifest(ROOT);checks=[]
 print(f'PASS: {len(original)} release hashes and exact manifest coverage',flush=True)
 archive=ROOT/'dependency/matching-rank-four-package.zip';assert sha(archive)==DEP_SHA
 with tempfile.TemporaryDirectory(prefix='two-pair-exterior-replay-')as temp:
  base=Path(temp);dep=base/'rank-four';dep.mkdir()
  with zipfile.ZipFile(archive)as z:
   names=z.namelist();assert len(names)==len(set(names));assert z.testzip()is None
   for info in z.infolist():
    p=PurePosixPath(info.filename);assert not p.is_absolute()and '..'not in p.parts
    assert not stat.S_ISLNK(info.external_attr>>16)
   z.extractall(dep)
  pins=manifest(dep)
  assert (dep/'matching-rank-four.pdf').read_bytes()==(ROOT/'dependency/matching-rank-four.pdf').read_bytes()
  for script,receipt in [('check_weighted_rank_four.py','verification.json'),('check_rank_three_minimum.py','rank-three-minimum-verification.json'),('check_rank_three_bijections.py','rank-three-bijections-verification.json'),('check_rank_five_certificate.py','rank-five-verification.json')]:
   actual=json.loads(run(dep/script,dep));compare(actual,json.loads((dep/receipt).read_text()),'dependency/'+script);checks.append(script)
  target=base/'regenerated-rank-five.json'
  actual=json.loads(run(dep/'generate_rank_five_certificate.py',dep,['--output',target]))
  compare(actual,json.loads((dep/'rank-five-generation.json').read_text()),'dependency/certificate-generation')
  assert target.read_bytes()==(dep/'rank-five-certificate.json').read_bytes();assert manifest(dep)==pins
  checks.append('dependency certificate regeneration')
  data=base/'data';data.mkdir()
  for p in [*(ROOT/'certificates').glob('*.json'),*(ROOT/'proof-notes').glob('*.md')]:shutil.copyfile(p,data/p.name)
  source=ROOT/'reproducibility/producer/replay_pair_certificates.py';copied=data/source.name;shutil.copyfile(source,copied)
  run(copied,data);actual=json.loads((data/'pair_exact_replay.json').read_text());producer_records=actual['records']
  compare(actual,json.loads(source.with_name('pair_exact_replay.json').read_text()),'producer certificate replay');checks.append('producer six certificates')
  ordinary=base/'ordinary';ordinary.mkdir();source=ROOT/'reproducibility/producer/check_last_reduction.py';copied=ordinary/source.name;shutil.copyfile(source,copied)
  run(copied,ordinary);actual=json.loads((ordinary/'last_reduction_receipt.json').read_text())
  compare(actual,json.loads(source.with_name('last_reduction_receipt.json').read_text()),'ordinary scalar identities');checks.append('ordinary last-gap identities')
  independent=base/'independent';independent.mkdir();source=ROOT/'reproducibility/independent/check.py';copied=independent/source.name;shutil.copyfile(source,copied)
  run(copied,independent,['--data-dir',data,'--output-dir',independent]);actual=json.loads((independent/'independent_receipt.json').read_text())
  compare(actual,json.loads(source.with_name('independent_receipt.json').read_text()),'independent Hall and certificate replay');checks.append('independent reconstruction')
  mine={r['file']:(r['target_sha256'],r['remainder_sha256'])for r in producer_records}
  theirs={r['file']:(r['target_sha256'],r['remainder_sha256'])for r in actual['records']}
  assert mine==theirs and len(mine)==6
  print('PASS: all six independent target and remainder hashes agree',flush=True)
 assert manifest(ROOT)==original
 print(json.dumps({'verdict':'PASS','manifest_files':len(original),'checks':checks,'all_six_target_remainder_hashes_agree':True,'elapsed_seconds':round(time.monotonic()-start,3)},indent=2))
if __name__=='__main__':main()
