# Three certified alternative 221-state machines

This self-contained packet gives **three distinct, explicitly constructed
221-working-state, two-symbol Turing machines**. Each is universally
halting-equivalent to the retained K221 construction, by fresh, independently
checked positive common-endpoint diagrams. They are small alternative
implementations of the same logical construction, not three different
consistency calculi.

The inherited ordinary mathematical endpoint is

    ZFC proves: Nonhalt(M, blank) if and only if Con(ZFC).

This transfers from the complete pinned K221 packet through the all-tape
equivalence proved here. It does **not** assert Con(ZFC), unconditional
nonhalting, or a new exact-byte theorem compiled in Rocq/Lean. No new internal
PA endpoint, minimality, or global-priority claim is made.

## Start here

- `report/report.pdf` and `report/report.tex`: mathematical description, exact
  identities, proof boundaries, and secondary research toward 220 states.
- `machine/row103/k221.tm`: first certified alternative, canonical labels.
- `machine/row157/k221.tm`: second certified alternative, canonical labels.
- `machine/both/k221.tm`: simultaneous alternative, canonical labels.
- Each directory also contains `k221.native.tm` and `canonicalization.json`.
- `machine/sites221.json`: the unchanged common source.
- `verification/`: fresh proof receipts and clean replay logs.
- `vendor/K221_Construction_2026-10-20.zip`: unchanged complete baseline release,
  with its full inherited proof chain and original attribution.
- `exploratory/`: **not certified binary alternatives**. Ten grammar seeds and
  one rho6 source variant are separated here for further research.

## Offline replay

From this packet root, using Python 3.10 or later, standard library only:

    python3 -B portable/reproduce.py --output-dir /tmp/k221-alternatives-replay

Use an initially empty directory outside this packet. The release is tested
on Linux with Python 3.12; on Windows, use WSL. Native Windows byte-for-byte
replay is not claimed because retained predecessor scripts use platform text
newlines. Assertions must remain enabled; do not use `-O` or `PYTHONOPTIMIZE`.

The default checks the exact file inventory, safely extracts the pinned
baseline, replays its complete quick certificate audit, deterministically
reconstructs all three native tables, freshly checks the all-tape macro proofs
and a second independent finite-window proof for every variant, and independently
simulates each native/canonical table to the exact initialization endpoint.
It compares every rebuilt table and canonicalization receipt with the delivery.
No network, optimizer, external package, or proof assistant is required.

`--full-baseline` freshly rederives the baseline's 6,167 unbounded final-runtime
cases instead of auditing the stored runtime receipts. `--deep-baseline` also
requests fresh inherited runtime derivations through the baseline driver.
These stronger modes can take substantially longer. The local equivalence
proofs of all three alternatives are fresh in every mode.
`--skip-baseline-replay` is explicitly weaker and is provided only for debugging.

## Exact conventions

The tape is indexed by all integers. Its alphabet is `{0,1}`; the initial tape
is all zero, initial head position is 0, and initial state is 0. Each transition
writes one symbol and moves exactly one cell left or right. A row is
`state read write direction next_state`.

Every canonical table has working states **0 through 220**, **442 rows**, and
separate terminal state **221**, which has no outgoing rows. All 221 working
states are graph-reachable from state 0. This reachability statement concerns
the transition graph, not a claim that the blank computation visits every state.
The canonical dispatcher is 22. Native inherited labels are not consecutive;
their terminal label is 254.

Canonicalization is deterministic breadth-first numbering from state 0, trying
read 0 before read 1. All three canonical hashes differ from one another and
from the original K221 table: these are not merely state renamings.

| Variant | Changes in native labels | Canonical SHA-256 |
|---|---|---|
| `row103` | `(103,1) -> (0,L,142)` | `f2f59296a6f7ed2e5a63eb389707d221c9f17e2aa01aa418abf5a9d67b011324` |
| `row157` | `(157,1) -> (1,L,187)` | `f6740b4e9ea3d6da9e89f4366ecd0313d8a391235b75577f69fd9734e93b824e` |
| `both` | both changes above | `87ae75a04848f14fe0108c5f21561a24856c02131195049d19ca97c2ddf5b79c` |

Both new actions replace one baseline row; all other rows remain identical.
The changed labels in this table are **native**, not canonical labels.

## What is proved

1. The baseline table and common source are exactly those of the pinned release.
2. The first checker independently derives and rechecks an inductive
   constant-bit invariant from an unconstrained initial tape. It checks every
   changed positive macro diamond and all unchanged rows.
3. The second checker independently recomputes an 11-cell inductive window
   invariant, initialized with all 2,048 binary windows. It checks all 91,065
   admitted state/window contexts, with arbitrary exterior cells. Every changed
   block joins before reading outside the window; the whole tape, head and
   state agree at the join. A deliberately corrupted immediate halt is rejected.
4. Every old block has one or two transitions and every new block one, two,
   or three. Both lengths are strictly positive. This yields equivalence of
   halting, including infinite runs, rather than bounded testing.
5. The native-to-canonical maps are exact bijections. Both representations of
   every alternative independently reach the complete published initialization
   configuration in **409,835 observed steps**. The driver searches for the
   endpoint; it does not assume this duration.

Universal equivalence holds from state 0 for every initial binary tape and every
integer head position. The logical calibration is inherited, not re-established
by finite blank simulation. The research seeds in `exploratory/` are excluded
from these certification claims and from the main verification result.
