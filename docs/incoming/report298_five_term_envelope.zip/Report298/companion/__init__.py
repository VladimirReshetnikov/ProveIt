"""Report298 offline exact companion; no upstream executable dependencies."""
