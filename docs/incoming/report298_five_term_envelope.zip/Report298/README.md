# Report 298

## An Explicit Five-Term Envelope Below Gowers' Numerical Threshold

For every real 0 < delta <= 1/2, the complete Fejer starting threshold at ProveIt commit af74fb522c24a6331886b11db76942642a6a0e42 satisfies

    H_f(delta) < 2^(2^(delta^(-2^76)))
               < 2^(2^(delta^(-2^16384))) = T_paper(delta).

The article proves the stronger intermediate estimate log2(log2(H_f)) <= x^(2^67), where x = 2/alpha and alpha = (delta^5/64000)^16. It expands every numerical Fourier and geometric dependency, the zero-spectrum case, the finite maxima and ceilings, all local Fejer constants, and the complete density iteration. The exponent 76 is conservative, not an optimization claim.

The progression consequence uses the inspected natural_five_term_fejer source theorem as an input. No independent Lean compilation, complete imported-theorem audit, optimal integer cutoff, modern-best bound, or priority claim is made.

## Later source development

As inspected on 7 October 2026, commit aee4846afb6e926595e577bef3a04e20f5d1f284 adds Lean theorem declarations with proof bodies for the weaker exponent-1100 envelope, its progression consequence, and the exact five-term specialization of the paper's theorem. The theorem file is unchanged at examined commit 130fca9b1131fd983bd0af27565d36e8dfd2865a. The numerical H_f and its dependencies are unchanged across the three pins. Section 11 and CURRENT_SOURCE_STATUS.json distinguish these source findings from an independent kernel build and from the article's stronger ordinary-mathematical exponent-76 estimate.

The general all-length theorem_18_2 remains a Prop-valued target. Its separate five-term theorem must not be conflated with the all-length statement.

## Contents

- Report298.pdf and Report298.tex: the complete article and editable source
- companion/: standard-library exact checks and their coefficient/exponent ledger
- tests/: 27 companion tests and 41 guarded-builder tests
- SOURCE_MANIFEST.json: 50 complete-source identity records, not the complete files
- source_excerpts.json and SOURCES.md: 56 exact Lean excerpts, two math-only paper spans, and pinned declaration links
- provenance/PROOF.md: the frozen reference proof, preserved byte-for-byte
- CURRENT_SOURCE_STATUS.json: dated later-source findings and theorem links
- build.py and REPRODUCING.md: bounded offline reproduction and deterministic packaging
- MANIFEST.sha256: hashes of all other public distribution files

The compact package contains no complete third-party paper, repository runtime, or prior-report dependency. The offline companion does not authenticate unbundled source files or prove all-real inequalities by finite testing. See SOURCES.md and companion/README.md for its exact scope.

## Quick start

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B build.py reproduce --output /tmp/report298-replay

Use a fresh or empty absolute output directory outside the extracted source directory. The reference build requires Linux, Python, pdfTeX, and the standard LaTeX packages and fonts named in the TeX source. The companion requires only Python's standard library. Detailed commands, guards, toolchain versions, and authenticity limitations are in REPRODUCING.md.
