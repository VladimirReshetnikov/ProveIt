"""Bounded exact finite diagnostics for Report286; no universal word is computed."""
