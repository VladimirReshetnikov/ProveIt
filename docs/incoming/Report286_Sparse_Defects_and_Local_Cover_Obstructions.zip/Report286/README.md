# Report 286

## Sparse Defects and Local Cover Obstructions

Prepared for Vladimir Reshetnikov, 7 October 2026.

For every fixed integer k >= 1 and every fixed 0 < gamma < 1, the report constructs full-domain maps on (Z/NZ)^(k+1), for every sufficiently large integer N, that satisfy the exact two premises of the pinned Lemma 16.10 interface, the full weighted function and relation product properties, and the specified upstream structural/selection predicates, while failing the parameter-one local cover conclusion. The local target covers at most 5/16 of a specified box, versus the required 1/2.

A positive companion theorem constructs short-interval-alphabet words with simultaneous affine avoidance on all long proper modular progressions. It gives an exact optimal-list law, rigidity of restrictions, and deficit (q-s)L/(8R), including composite moduli and nonunit steps. The all-positive-dimension extension is fully proved in the manuscript.

These are mathematical proofs, not a Lean kernel certificate. No astronomical witness word was computed. Removing the sparse slab leaves the zero map, so the result does not refute existential global reselection, Theorem 16.2, Gowers's contextual theorem, or any global Szemeredi estimate. Source 50's earlier two-input counterexample and endpoint characterization, and source 49's conditional acyclic retained-core theorem, are credited rather than claimed anew. No publication-priority claim is made.

## Contents

- `Report286.pdf`: complete standalone manuscript
- `article.tex`: editable source
- `companion/exact_checks.py`: bounded deterministic exact diagnostics
- `companion/README.md`: detailed diagnostic scope and public API
- `tests/test_companion.py`: exact-check and provenance regressions
- `tests/test_build.py`: inventory, path, process, archive and replay regressions
- `build.py`: guarded offline build and deterministic ZIP packaging
- `SOURCES.md`, `provenance/source_manifest.json`, and five source snapshots: exact evidence and attribution
- `MANIFEST.sha256`: byte integrity of the distribution (excluding the manifest itself)

The original archives, full canonical combined manuscript, original-paper PDF, and private working reviews are deliberately omitted. Four included Lean files are source evidence; this package does not contain a Lean project or run Lean.

## Quick checks

From the extracted `Report286` directory:

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B tests/test_companion.py
    python3 -I -B tests/test_build.py

No network access or third-party Python package is used. The companion accepts no command-line options and writes its deterministic JSON report to standard output. The diagnostic public helpers have explicit bounded input validation. Runtime mathematical checks use explicit exceptions, not Python `assert` statements.

## Reproduce the complete distribution

Choose a fresh absolute output directory outside the extracted source tree, for example:

    python3 -I -B build.py reproduce --output /tmp/report286-replay

The output directory must not exist or must be empty. The builder refuses source ancestors/descendants, unsafe locations, aliases, symlinks, hard-linked source files, unexpected source entries, and existing output files. It runs the builder tests, companion tests, and exact checks both normally and with `-O`, using an isolated child environment and a 640-digit integer-string limit. It checks matching standard output in the two modes and unchanged original/staged source inventories.

It then creates a local TeX format, compiles the article three times with shell escape disabled and restricted input/output policies, checks its log, and writes the PDF, manifest, deterministic ZIP, ZIP SHA-256 pin, and a reproduction receipt. The public ZIP contains only the fixed member allowlist; build logs and the receipt stay outside it.

Additional commands:

    python3 -I -B build.py reproduce --output /tmp/report286-pdf-only --no-zip
    python3 -I -B build.py package --output /tmp/report286-package-only

`package` requires an already manifest-pinned distribution. It repackages the exact existing PDF and sources without compiling them.

## Toolchain and reproducibility boundary

The reference build uses Linux, Python 3.12.14, pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian), Latin Modern and the standard LaTeX packages named in `article.tex`. The guarded builder requires Linux no-follow directory handles and `/proc/self/fd`; it fails closed elsewhere. `/usr/bin/pdftex` and `/usr/bin/pdflatex` must be present. It neither installs dependencies nor downloads a TeX distribution.

The archive uses sorted names, a fixed 7 October 2026 timestamp, fixed file modes, and fixed deflate settings. Byte-identical PDF/ZIP replay requires a matching TeX/font and Python/zlib toolchain. If the PDF bytes differ, the distribution replay fails and reports that difference rather than silently replacing the reference. Mathematical diagnostics can still be run independently.

The compiler gate rejects overfull boxes, unresolved references/citations, and missing PDF structure. Every final PDF page must also be visually checked; text extraction alone is not a layout check.

## What the finite tests establish

The exact checks cover coset intersections, affine prefixes, elementary tail-bound certificates, complete one- and two-lists on a fixed nonunit-step progression, the subgroup-alphabet counterexample, sparse weighted-energy identities over small prime and composite moduli, general-dimensional alternating signs and exponent comparisons, and all bundled source identities. They are finite regression evidence, not proof by enumeration of the infinite theorems.

The word on the small N=40 progression is only a local example and is not claimed to satisfy the full universal word theorem at its L0. The N=32768 scale check certifies nonvacuity, not the construction of its word. The manuscript proves the arbitrary-parameter statements.

Source digests verify included raw bytes. External archive identities and member equality were checked during preparation; offline replay does not refetch omitted archives. The recorded canonical base64 digests are alternate byte-representation hashes, not original transport receipts. See `SOURCES.md` for exact distinctions.
