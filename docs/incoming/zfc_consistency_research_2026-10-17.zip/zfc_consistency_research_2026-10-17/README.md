# Toward a Smaller Con(ZFC) Machine

Research report prepared for ProveIt, 17 October 2026 (UTC).

Read **report.pdf** (28 pages), or edit **report.tex** and the files in
**sections/**. The bibliography is in **references.tex**.

## Main conclusion

This package does **not** establish a new consistency-equivalent machine
with fewer than 253 working states. The comparison point is the public
253-state construction in Jeff's PR 20, not just the merged 254-state
predecessor. The included 252-state table is the already known runtime
fold and has **no calibrated blank initializer**.

The report provides these additional results relative to the pinned audit:

- A normalized integer-ray refinement of source 36's support countermodel.
  It satisfies EPSC1, literal Extensionality, all finite membership-cycle
  prohibitions, Empty Set, Union, Power Set, Infinity, the exact native CP, full Separation,
  and source-covered partial Replacement, while Pairing and a fixed
  equality-free EPSC2 instance fail.
- A proof for every fixed support capacity k, using 2k+1 components.
- An elementary exact repair: the fixed image principle for replacing
  empty inputs by a parameter and fixing nonempty inputs is equivalent
  to Pairing over Power Set + Union + full Separation.
- An ordinary ZFC-level reconstruction of the existing CP/GIC/IR
  consistency calibration, using the internal bisimulation quotient,
  then its internal well-founded part and constructible part.
- An exhaustive fixed-gap Python audit: all 8,391 local cases pass
  at each tested gap 36, 37, 38 and 40.
- Exact prepared-tape countertraces showing real register corruption
  for selected gap-32 and gap-35 cases, with gap-36 positive controls.
- A 100-million-move bounded inspection of runtime252 from blank tape
  and a sound structured dirty root reached after 60,606 moves, whose
  gap-19 binary simulation remains unproved.

The basic EPSC1/Pairing separation is **prior source 36 work**. The
dirty-root theorem and fixed-gap adapter are **prior source 35 work**.
They are credited throughout. The new refinements are ordinary
mathematical proofs and finite computations, not new Lean/Rocq certificates.

## Proposed construction

Keep the already calibrated native theory and optimize the complete
decoder and blank initialization together. Use any certified sound dirty
root rather than insisting on the public RM330 initializer. The concrete
barriers are now explicit: the blank orbit attains recognized gap 32 in
the tested prefix, fixed gap 36 passes every local contract, some shorter
gaps really corrupt registers, and a fixed header cannot simply overlap
all deep PC leaves.

The one-parameter consistency question remains open to a different
directed-core interpretation. Failure to derive Pairing does not prove
lower consistency strength.

## Audit pins

| Resource | Exact pin |
|---|---|
| ProveIt primary audit | 3d731d8cf44941560752abc625149f7bfa109930 |
| ProveIt novelty recheck, including sources 35/36 | ba00775e2bf56b184d071346867db74f2eb0c621 |
| Jeff merged reference | 297ab8df7e5de329605c3875b4934643b371a5e3 |
| Public 253-state PR 20 head | 0d544f2a2e3c18f12278441a74b7879f31cbe856 |

The three user-specified commits are cited individually in the report.
The report is pinned; it does not claim to describe later moving-branch changes.

## Reproduce the finite diagnostics

Python 3.10+ and the standard library suffice. Run without Python's
optimization option; attributed input code uses assertion-based integrity
checks. From the extracted package root:

~~~sh
python3 -B code/reproduce.py --output /tmp/zfc-replay
python3 -B code/reproduce.py --full --output /tmp/zfc-full
python3 -B code/reproduce.py --full --long-run --output /tmp/zfc-long
~~~

Default replay checks file identities, the finite support construction,
the exact public table generator, all gap-36 contracts, all selected
literal countertraces, and one million blank moves. Full replay checks
both complete gap censuses. The optional long run checks all 100 million
moves. The output directory must be outside the supplied package.

The recorded full packaging replay is in **data/reproduction_result.json**.
Elapsed times can differ; logical counts, complete tapes, and trace digests
must match. The 100M run was performed during research; the packaging
replay repeated the 1M run and both complete local censuses.

See **code/machine/README.md** for individual commands and the data-file map.
No network connection or installed Lean/Rocq is needed for these diagnostics.

## Build the manuscript

~~~sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
~~~

Or use **make pdf**. Standard LaTeX packages are listed in the preamble;
no BibTeX run is needed.

The identity manifests describe the exact delivered files. Rebuilding a PDF
changes its metadata and therefore normally its byte hash. Run the identity
replay on the fresh extracted package before rebuilding or editing it.
After intentional edits, **code/prepare_archive.py** can regenerate the
archive-wide manifest and make a new package; it does not relabel changed
third-party inputs as the old pinned sources.

## Contents and status

| Directory or file | Status |
|---|---|
| report.tex, sections/, references.tex | Complete editable ordinary-mathematics report |
| report.pdf | Compiled and visually reviewed PDF |
| code/support_orbits.py | Finite combinatorial diagnostics, not a finite EPSC1 model |
| code/machine/ | New audit drivers plus attributed prior executors and minimal upstream inputs |
| data/machine/ | Literal machines, bounded traces, complete gap tables, provenance |
| data/machine/runtime252_known_oldlabels.tm | Known 252-state runtime; blank start uncalibrated |
| BUILD_AND_QA.md | Exact validation scope and final PDF QA |
| THIRD_PARTY.md | Attribution and component notice inventory |
| MANIFEST.json | Package file identities; no proof certification implied |

The supplied source excerpts are sufficient for the Python replay. They
are not a complete proof-assistant source closure. No new kernel proof,
serialized ZFC derivation, or state record is claimed.

