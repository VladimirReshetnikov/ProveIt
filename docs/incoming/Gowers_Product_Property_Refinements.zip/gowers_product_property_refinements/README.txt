SMALLER CONSTRAINT FAMILIES IN GOWERS' PRODUCT PROPERTY
Weighted cube counts, optimal local tests, and an explicit stronger
extraction theorem

Research manuscript prepared for Vladimir Reshetnikov and ProveIt
7 October 2026

CONTENTS

gowers_product_property_refinements.tex
    Complete standalone LaTeX article. No external figure, fragment,
    bibliography database, or original-paper file is required.
gowers_product_property_refinements.pdf
    Compiled and visually inspected article.
code/verify_rank.py
    Exact integer checks of the relation bases and local test lower bounds.
code/verify_counting.py
    Exact gluing, weighted counting, recurrence, and coordinate-order checks.
code/verify_parameters.py
    Exact parameter and selection-budget diagnostics.
data/rank_checks.json
data/counting_checks.json
data/parameter_checks.json
    Recorded results of the delivery verification run.
SOURCE_AUDIT.txt
    Pinned repository baseline, attribution, and scope of the new claims.
INTEGRATION.txt
    Suggested mathematical placement and proof-status cautions.
Makefile
    Convenience targets for building the PDF and running the checks.

BUILD

Use a standard TeX Live or MiKTeX installation with the packages named
in the preamble. The delivery build used pdfLaTeX and latexmk.

    latexmk -pdf -interaction=nonstopmode -halt-on-error \
        gowers_product_property_refinements.tex

Alternatively, run pdflatex repeatedly until cross-references settle.
The bibliography is included directly in the source.

EXACT CHECKS

Python 3.10 or newer is sufficient. The three verification programs
use only the Python standard library.

    python3 code/verify_rank.py > data/rank_checks.json
    python3 code/verify_counting.py --output data/counting_checks.json
    python3 code/verify_parameters.py --output data/parameter_checks.json

The article's general proofs do not depend on these finite checks.
No floating-point feasibility decision is used. Decimal logarithms in
the parameter report are illustrative; governing-branch comparisons
are certified with integers.

PRINCIPAL RESULTS

Under Gowers' product property PP_gamma on a product of k finite
abelian groups of total size M, for a domain of density beta > 0:

  respected configurations >=
      M^3 beta^(4^k) gamma^(8(4^k - 3^k));

  respected parallel cube pairs >=
      M^3 beta^(4^k) gamma^(4(4^k - 2^k)).

The former exponent was 2k4^k for both counts. The new bounds are
strictly stronger for k >= 2 and 0 < gamma < 1. The homogeneous
weighted cube theorem permits every nonnegative weight w and uses
(E w^(2^(1-k)))^(4^k). Unequal coordinate parameters and general
coefficient profiles are also treated.

Coupling with the existing collision-sensitive amplification gives
the eight-arrangement bound

  a_8 >= beta^(22*4^k) gamma^(88*4^k - 32*2^k),

which is carried through the existing degree-weighted selection
theorem with all field-size and characteristic assumptions explicit.

The integral configuration basis has size exactly 3^k. The minimum
raw-test list for a reference/comparison cube certificate has size
exactly 2^k. The configuration density exponent 4^k and coefficient
one are optimal in the universal product-property bound. Optimality
of the final frequency exponents remains open.

SCOPE

This is a proved local strengthening and an explicit Section 14--15
composition. It does not establish a new final Szemeredi bound, claim
historical priority beyond the inspected project comparison, or supply
new Lean kernel-checked theorems. Existing amplification and selection
results are attributed in the article and source audit.
