# Cubic Diophantine Certificates Without Computation Histories

**Canonical sandpile odometers, spatial universality, and exact eventual periods**  
Research report prepared for the ProveIt project — October 2, 2026.

Read `article.pdf`; the complete editable source is `article.tex`.

## Main result

For a fixed finite, loopless, undirected multigraph whose nonsink components
all reach a sink, the compact compiler produces an integer polynomial of
total degree at most three with exactly one natural certificate zero for
every nonnegative initial configuration. Its certificate contains the exact
odometer and stable final state. No toppling history is stored.

With n nonsink vertices and E nonzero undirected internal adjacencies:

| Compiler | Natural certificate coordinates | Nonnegative structured summands |
|---|---:|---:|
| Baseline | 13n + 12E | 14n + 12E |
| Compact | 10n + 6E | 10n + 7E |

Parallel-edge multiplicities are fixed coefficients, not extra adjacency
entries. Input heights are separate free parameters. These are **not**
optimized arithmetic-operation counts or expanded-monomial counts.

Both complete natural zero sets are related by explicit inverse maps. A
finite-box extension adds an exterior collar and a canonical-radius test.
The spatial polynomial is compiled for a specified radius; it is not one
fixed-arity cubic universal polynomial.

The article also proves the exact minimal eventual period of finite-graph
stabilizations along an input ray a+t*h. Under the stated positivity
hypothesis, this period is the least positive q for which q*L^{-1}h is
integral, and the odometer increases by q*L^{-1}h every q inputs.

## Contents

- `article.tex`, `article.pdf`: proofs, source audit, directed counterexample,
  exact formula counts, spatial bounds, uniform-MRDP boundary, eight research
  directions, and a proposed formalization route.
- `sandpile_cubic.py`: baseline compiler, exact evaluator, canonical
  certificate constructor, legal stabilizers, burning ranks, and box utilities.
- `sandpile_compact.py`: smaller compiler, five-way edge gadget, and explicit
  inverse maps on complete natural zero sets.
- `sandpile_spatial.py`: compact spatial polynomial for a finite periodic table
  plus explicit finite height replacements; exterior collar and canonical radius.
- `verify.py`, `verify_compact.py`, `verify_spatial.py`: reproducible exact checks.
- `verification*.json`: saved receipts from successful runs.
- `example/`: complete integer coefficient tables, readable polynomial
  expansions, and huge-input certificates for the two-site graph.
- `SOURCES.md`: primary sources, pinned repository revision, and novelty boundary.
- `requirements.txt`, `build.sh`: tested dependency and rebuild commands.
- `MANIFEST.sha256`: byte-level hashes of the delivered files.

## Reproduce

Python 3.10 or newer is required. Tested here with Python 3.13.5 and SymPy
1.14.0. The finite and spatial certificate evaluators use only the standard
library; symbolic exports and the full verification suites use SymPy.

```sh
python -m pip install -r requirements.txt
python sandpile_cubic.py
python sandpile_compact.py
python sandpile_spatial.py
python verify.py --output verification.json --export-dir example
python verify_compact.py
python verify_spatial.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

These direct commands also work on Windows when Python and a TeX distribution
providing pdfLaTeX are on PATH. On a POSIX shell, `bash build.sh` runs the three
verification suites and compiles the paper. Verifiers regenerate their JSON
receipts and polynomial examples. Do not use Python's `-O` flag: the tests use
assertions, and their entry points reject disabled-assertion mode.

A minimal compact example is:

```python
from sandpile_cubic import Graph
from sandpile_compact import certificate, evaluate

graph = Graph(((0, 1), (1, 0)), (2, 2))
t = 10**100 + 7
odometer = ((2*t - 1)//3, (t - 1)//3)  # Proved in article.tex, Section 8.
witness = certificate(graph, (t, 0), odometer)
assert len(witness) == 26
assert evaluate(graph, (t, 0), witness) == 0
```

Supplying an odometer does not bypass validation: the constructor checks its
stable endpoint and support-burning criterion, then evaluates the complete
polynomial. Without a supplied odometer it runs a legal stabilizer. Explicit
runtime limits raise exceptions, rather than returning incomplete trajectories.
The implementation uses dense adjacency matrices and is a transparent reference
compiler, not an optimized sparse-grid solver.

## Verification actually performed

The saved runs include 86,975 proposed-odometer checks; 7,660 proposed-rank
assignments; 20,800 comparison-gadget tuples; and 37,179 five-way-gadget tuples.
The baseline and compact suites separately test 120 seeded weighted graphs.
The compact suite tests 275 small-input zero-set round trips and rejects 15,361
single-coordinate mutations. The spatial suite tests 103 input/box pairs,
rejects 969 mutations, and checks the spatial counts in dimensions 1–3.

For the two-site graph, the baseline has 38 witnesses, 40 structured summands,
and 216 expanded monomials. The compact version has 26 witnesses, 27 structured
summands, and 324 expanded monomials. Both have exact degree three. Thus the
coordinate reduction is not an expanded-size reduction.

Both structured and expanded polynomials evaluate exactly to zero for input
(10^100+7, 0), whose legal stabilization requires 10^100+6 topplings. No such
lengthy trajectory is simulated by that check.

The coefficient-table hashes inside verification receipts hash normalized JSON
objects (sorted keys and compact separators), not the formatted files' bytes.
`MANIFEST.sha256` instead records file-byte hashes. Rebuilding the PDF can change
its byte hash because pdfLaTeX includes build metadata.

## Scope and trust

The self-contained mathematical proofs, not the finite tests, support the
all-input finite-graph theorems. The directed counterexample explains why the
hypotheses may not be replaced by arbitrary directed dissipativity.

Natural witnesses include zero. Over unrestricted integer witnesses, the
weighted-square nonnegativity argument does not apply. The paper states the
separate four-square, finite-fold integer-domain corollary with its degree cost.

Cairns's three-dimensional periodic-plus-finite sandpile universality is an
imported theorem. No Turing-machine-to-sandpile loader is implemented here.
The finite periodic-table interface is explicit, but the radius is a compiler
parameter and the number of variables increases with it. The package does not
settle single-fold MRDP, finite-fold MRDP, or a fixed cubic universal equation,
and does not improve ProveIt's 75/87 operation bounds.

The proposed explicit arithmetic constructions are proved in the manuscript;
worldwide priority has not been established. Burning, least action, sandpile
universality, and the group-periodicity mechanism are prior work. Neither the
new proofs nor the supplied code have been checked by Lean. ProveIt was not
rebuilt or modified.
