REPORT198: WEIGHTED DISTINCT POSITIVE MULTIPLICITY VALUES
Reproducible report and computational package for OEIS A373273, 4 October 2026

Definition and mathematical scope
---------------------------------
For a partition lambda, let M_j be the number of copies of the part size j.
W(lambda) is the SUM of the distinct positive VALUES among the M_j. Let
  a_n = sum over all partitions lambda of n of W(lambda),
with a_0=0 and p(0)=1. For example, 5+5+3+3+3+1 has positive multiplicities
2,3,1 and W=6. The partition 4+4+2+2 has positive multiplicities 2,2 and W=2.
Repeated multiplicity values are included once. This is different from the
number of distinct multiplicity values and from the total number of parts.

The accompanying manuscript proves a five-scale expansion for a_n/p(n),
the equivalent absolute expansion, and an eventual shrinking-width inverse
envelope. This computational package checks exact finite data and algebra.
It does not prove analytic remainders, an effective onset, an explicit error
constant, a distributional limit, an all-orders theorem, a single-ceiling
inverse valid at every threshold, or a worldwide novelty assertion.

Requirements and commands
-------------------------
Python 3.9+ and its standard library suffice for all mathematical checks.
No NumPy, SciPy, SymPy, mpmath, or network access is required. Full report
builds additionally require an installed pdfLaTeX/pdfTeX/kpsewhich stack
and the installed fonts and packages referenced by Report198.tex.
Run from this code directory (or substitute absolute script paths):

  python3 -I -S -B symbolic_checks.py
  python3 -I -S -B verify.py
  python3 -I -S -B -O verify.py
  python3 -I -S -B diagnostics.py
  python3 -I -S -B guard_tests.py --unit-only
  python3 -I -S -B -O guard_tests.py --unit-only
  python3 -I -S -B build.py --check
  python3 -I -S -B build.py --output-dir /absolute/path/to/new-output
  python3 -I -S -B -O build.py --output-dir /absolute/path/to/another-new-output

Every verifier and builder recomputes all n=0,...,2500 terms. There is no
reduced-size build mode. Each build runs the full verifier, guards, and
floating diagnostics in both normal and optimized Python and requires their
respective receipts to be byte-identical. The integration suite performs four
actual full builds: source normal/-O,
then two genuine separately validated ZIP extractions rebuilt normal/-O.
It compares every byte in all four output trees and checks that all source
trees remain unchanged. Each build itself repeats the full mathematical
verifier and guard suite under normal and optimized Python:

  python3 -I -S -B guard_tests.py
  python3 -I -S -B -O guard_tests.py

Use --unit-only for guards without those recursive integration builds.
The full builder creates Report198.pdf, Report198.tex, Report198_code.zip,
ARTIFACTS.json, and package/ containing the complete independently rebuildable
release. It never edits the source manuscript. The manuscript is copied from
the validated in-memory source payload into isolated private TeX storage.

verify.py optionally writes --output NEW_JSON and --terms-output NEW_TEXT.
guard_tests.py optionally writes --output NEW_JSON. These output files must
be distinct, absent, disjoint from the source tree, and have existing parents
without symlink ancestors. The builder's destination must likewise be absent
and disjoint; existing directories, regular files, symlinks and dangling
links are refused. Do not place receipts, caches, or additional files inside
the code package. Its inventory is intentionally closed.

Exact counting methods
----------------------
Write
  P(q)=product_(j>=1) (1-q^j)^(-1),
  Q_m(q)=product_(j>=1) (1-q^(mj)+q^((m+1)j)).
Then
  sum_(n>=0) a_n q^n = P(q) sum_(m>=1) m*(1-Q_m(q)).
The complement for m starts in degree m, so the finite calculation through
N uses m<=N and j<=floor(N/m). The verifier multiplies each Q_m by descending
integer coefficient updates, combines their WEIGHTED complements, and makes
one convolution with the partition coefficients. Intermediate Q coefficients
may be negative. Final totals must be nonnegative. Partition coefficients are
independently checked through N=2500 by Euler's pentagonal recurrence.

The independent allowed-occupancy DP works through 450. For each m it directly
constructs
  P_m(q)=product_j ((1-q^j)^(-1)-q^(mj)),
which counts partitions with no part-size multiplicity equal to m. At each
part size it first permits every multiplicity and subtracts the old-row
contribution with exactly m copies. Every intermediate coefficient is checked
nonnegative. Its weighted sum m*(p(n)-[q^n]P_m) must agree with the Q-product
method. This method does not build Q_m and does not use a final convolution.

The third calculation enumerates descending partitions through n=43 and sums
the distinct positive adjacent Ferrers gaps, including the last part minus
zero. Conjugation turns these gaps into the positive multiplicities of the
conjugate partition. This provides another representation of the weighted
total and checks the number of partitions enumerated against p(n). Every
43-term OEIS value is therefore covered by all three counting methods.
The elementary bounds p(n)<=a_n<=n*p(n), n>=1, are also checked through 2500.

Exact symbolic checks
---------------------
symbolic_checks.py uses fractions.Fraction and sparse Laurent polynomials.
Its 35 checks cover S2/S3 finite-difference rational identities, radial moment
arithmetic, noncentered and centered H2 profiles and local constant -1/32,
the far-tail endpoint arithmetic -1/16, H3=1/81 and H22=-1/256, the removable
contribution Z(0)=1/6, cancellation of the zeta derivative, K=9607/20736-gamma/24,
Gaussian moments, the absolute and normalized saddle polynomials, the
log-amplitude derivative, and conversion from canonical to absolute form.
These are exact algebraic checks AFTER the analytic reductions in the proof;
they do not independently certify convergence, contour shifts, localization,
error terms, or the existence/onset of an inverse bound.

Floating diagnostics and their limits
------------------------------------
Let A=pi^2/6, tau=sqrt(A/(n-1/24)), ell=log(1/tau),
c=3/2-gamma/2, K=9607/20736-gamma/24. The canonical template is
  (ell/2+c)/tau - 7*sqrt(pi)/(16*sqrt(tau))
  + (1/24+1/(4*A))*ell + K + (7/8-gamma/4)/A.
The smooth absolute template for x=sqrt(n-1/24) is
  Phi(x)=exp(2*sqrt(A)*x)/(4*sqrt(3)*x^2)
    * [(x/sqrt(A))*(log(x/sqrt(A))/2+c)
       - 7*sqrt(pi)/(16*A^(1/4))*sqrt(x)
       + log(x/sqrt(A))/24 + K + 1/(8*A)].
diagnostics.py compares the canonical formula at seven n-values through 2500
and finds a numerical smooth-template root at the exact integer a_n using
fixed-step bisection on log(Phi). It records x_root^2+1/24-n. No integer
rounding/ceiling claim is made. The root calculation is not interval-certified.

The same script samples the sector Boltzmann expansion at |t|=.01,.003,.001
and arg(t)=-.2,0,.2, using a fixed truncated linear-plus-collision sum. Its
cutoffs are recorded in each row. There is no certified truncation or rounding
bound. These finite residuals are diagnostics only and never supply an
asymptotic remainder constant, an onset, or an inverse envelope certificate.
All floating values are explicitly stringified in their receipt. No PASS
verdict is attached to the mathematical asymptotic claims by this script.

Pinned data, provenance, and attribution
---------------------------------------
data/exact_A373273.txt has exactly 2,501 canonical ASCII rows with columns
n, a_n, p_n and no header. SHA-256:
  0b6ba19a1ea9490ef1ca8e15c3e86bd07519f332f6a07a9bc25a2858f213f54d
It is a locally computed exact reference, not an OEIS b-file. The full table
is regenerated from the definition on every verifier/build invocation.

data/A373273.seq is the official OEIS-maintained record read on 4 October
2026 from https://github.com/oeis/oeisdata/blob/main/seq/A373/A373273.seq .
Its SHA-256 is:
  37a7ec9af3a7c099c22b4254c066792f9ebaf2fb92975335fe8444798c448103
The record supplies 43 terms beginning at n=1 and credits Olivier Gerard
(the record retains the original accented spelling). Offline rebuilding checks
this pinned record and those 43 values; it does not perform a new live lookup.
Sequence link: https://oeis.org/A373273 . OEIS data terms:
https://oeis.org/wiki/The_OEIS_End-User_License_Agreement and
https://creativecommons.org/licenses/by-sa/4.0/ .

The computational infrastructure, guarded I/O and exact polynomial utilities
are adapted from the preceding Report197 reproducibility package. The two
weighted counting sums and Ferrers-gap statistic are adapted explicitly for
A373273; its symbolic weighted constants and diagnostics are newly specified.
No A373271 theorem or coefficient is used as a mathematical premise.

Manifests, source safety, and reproducibility
-------------------------------------------
SOURCE_MANIFEST.json hashes the TeX manuscript, every code/data source and
this README, explicitly excluding itself. MANIFEST.json in the complete
package hashes every source, SOURCE_MANIFEST.json, PDF and generated file,
explicitly excluding itself. The ZIP contains that full package and cannot
contain itself. Outer ARTIFACTS.json hashes every delivered file, the ZIP and
every file in package/, including both inner manifests, excluding only itself.
The complete package has no unlisted files or empty/unexpected directories.
Each record gives full SHA-256 and byte count. Manifests are integrity records,
not signatures, authenticity guarantees, or a substitute for checking code.

Only when the manuscript AND all code/data sources are final and no source manifest exists, an author
may run:
  python3 -I -S -B build.py --freeze-source
This exclusively creates the source manifest. Ordinary builds never rewrite
it. They validate names, types, bounds and closed inventories; reject source
and destination symlinks and special files; reject traversal and collisions;
check source hashes and the actual captured bytes; execute only the copied,
validated sources in a temporary staging directory; publish into an exclusively
created directory; and verify that the source tree remained unchanged.

No mathematical or safety check uses Python assert. The unit suite exercises
66 guard cases under both normal and optimized Python. These safeguards are
for ordinary isolated builds, not a sandbox for arbitrary hostile code and
not a guarantee against another process changing directory ancestors during
the build. A failed write can leave an incomplete NEW destination; it cannot
replace a pre-existing destination.

Generated BUILD_INFO.json records the actual Python, pdfTeX and kpathsea
versions, integer/float representation, fixed build settings and TeX passes.
TeX runs with shell escape disabled, restrictive file access, fixed metadata,
a fixed epoch, locale and private home/cache/TEXMF directories. When the
installed TeX format is absent, prepare_tex initializes a private format from
the installed distribution only; it does not download or modify system files.
Cross-references must stabilize within four passes; overfull boxes, missing
characters, unresolved/multiply-defined citations or labels cause failure.

ZIP order, timestamps, permissions and compression are fixed; entries use
ZIP_STORED. The extraction tests validate inventory, paths, member types,
permissions, timestamps, compression, flags, metadata, byte counts and hashes
before accepting a complete package. The default integration suite performs
actual extracted-ZIP builds, rather than merely comparing existing hashes.

No wall-clock timestamp, duration, absolute working path or optimization flag
enters a generated receipt. Exact integer/Fraction results are deterministic.
Byte-identical complete builds are promised only for identical source bytes
and the same installed Python/system-libm/TeX/font toolchain. Floating bytes,
runtime identity or PDF bytes can differ across versions/platforms. There is
no cross-toolchain byte-identity claim.
