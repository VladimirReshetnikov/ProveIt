#!/usr/bin/env python3
"""Offline construction, local proof, startup, comparison, and runtime replay."""
import argparse
import gzip
import hashlib
import json
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
import build_machine
import check_block_simulation as block
import check_comparison
import check_paths_independent as paths
import check_startup

PARENT_ARCHIVE_SHA = '09e869763555e19d73f1b7900eee7305105ee02219196dcc88bb6854f34d7f29'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verify_manifest():
    seen = set()
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        p = (ROOT / name).resolve()
        require(p.is_relative_to(ROOT) and p.is_file(), 'unsafe or absent manifest path')
        require(name not in seen, 'duplicate manifest path')
        require(sha(p) == expected, 'manifest mismatch: ' + name)
        seen.add(name)
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
              if p.is_file() and p.name != 'SHA256SUMS'}
    require(seen == actual, 'manifest does not cover exactly the release files')
    return len(seen)

def extract_parent(destination):
    source = ROOT / 'inputs/direct_transfer_parent.zip'
    require(sha(source) == PARENT_ARCHIVE_SHA, 'wrong exact parent archive')
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(source) as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            require(target.is_relative_to(destination.resolve()), 'unsafe parent archive path')
            require((member.external_attr >> 16) & 0o170000 != 0o120000, 'archive symlink')
        archive.extractall(destination)
    return destination / 'U213_ConPA_2026-10-28'

def execute(arguments, log):
    result = subprocess.run([sys.executable, '-B', *map(str, arguments)],
                            text=True, capture_output=True, cwd=ROOT)
    log.write_text(result.stdout + result.stderr)
    require(result.returncode == 0, 'command failed; log: ' + str(log) + '\n' + result.stdout[-1800:] + result.stderr[-1800:])

def saved_runtime_audit(parent):
    source = json.loads((ROOT / 'machine/sites.json').read_text())
    report = json.loads((ROOT / 'evidence/runtime.json').read_text())
    cases = json.loads(gzip.decompress((ROOT / 'evidence/runtime_cases.json.gz').read_bytes()))
    expected = [(i, p) for i, row in enumerate(source)
                for p in ((False, True) if row[1] == 'CD' else (False,))]
    require([(c['site_index'], c['positive']) for c in cases] == expected, 'saved case coverage')
    require(len(cases) == 5084 and report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS', 'saved runtime status')
    require(report['table_sha256'] == sha(ROOT / 'machine/u212.native.tm'), 'runtime table binding')
    require(report['source_sha256'] == sha(ROOT / 'machine/sites.json'), 'runtime source binding')
    require(report['literal_rows_covered'] == 424 and report['header_base'] == 56, 'runtime conventions')
    for case in cases:
        require(len(case['duration']) == 13 and case['duration'][0] > 0
                and all(x >= 0 for x in case['duration']), 'non-positive duration certificate')
        require(len(case['motion']) == 13 and case['symbolic_steps'] > 0, 'bad symbolic certificate')
    require(sum(c['symbolic_steps'] for c in cases) == 1275761, 'inference census')
    mapping = {int(k): int(v) for k, v in json.loads((parent / 'inputs/legacy_mapping.json').read_text()).items()}
    table = block.read_table(ROOT / 'machine/u212.native.tm', 212)
    wanted = {(mapping.get(q, q + 1000), b) for q, b in table}
    used = {tuple(row) for case in cases for row in case['rows']}
    for lemma in report['blocks']:
        used.update(tuple(event[1][:2]) for event in lemma['trace'])
    require(used == wanted, 'saved literal row coverage')
    return {'cases': len(cases), 'rows': len(used), 'symbolic_inferences': 1275761,
            'scope': 'Audits saved records. --full reconstructs the derivations.'}

def replay(work, full):
    parent = extract_parent(work / 'parent')
    old_path, new_path = parent / 'machine/u213.native.tm', ROOT / 'machine/u212.native.tm'
    construction = build_machine.build(old_path, work / 'constructed')
    for name in ('u212.native.tm', 'u212.tm', 'state_map.json', 'summary.json'):
        require((work / 'constructed' / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
                'construction file mismatch: ' + name)
    require((ROOT / 'machine/sites.json').read_bytes() == (parent / 'machine/sites.json').read_bytes(),
            'source changed')
    old, new = block.read_table(old_path, 213), block.read_table(new_path, 212)
    local = block.verify(old, new)
    controls = block.negative_controls(old, new)
    require(len(controls) == 8, 'negative control census')
    independent = paths.verify(paths.read(old_path), paths.read(new_path))
    comparison = check_comparison.audit(ROOT)
    startup = check_startup.run(parent, new_path, ROOT / 'machine/sites.json')
    (work / 'startup.json').write_text(json.dumps(startup, indent=2) + '\n')
    saved = saved_runtime_audit(parent)
    execute([parent / 'reproduce.py', '--report', work / 'parent_replay.json'], work / 'parent_replay.log')
    parent_receipt = json.loads((work / 'parent_replay.json').read_text())
    require(parent_receipt['status'] == 'U213_FINITE_REPLAY_PASS', 'parent finite replay')
    runtime = None
    if full:
        execute([ROOT / 'code/verify_runtime.py', '--parent', parent,
                 '--table', new_path, '--source', ROOT / 'machine/sites.json',
                 '--output', work / 'runtime', '--expected', ROOT / 'evidence/runtime_cases.json.gz',
                 '--gzip'], work / 'runtime.log')
        runtime = json.loads((work / 'runtime/runtime.json').read_text())
        require(runtime['status'] == 'UNIVERSAL_MATHEMATICAL_PASS'
                and runtime['saved_expected_cases_match'] is True, 'fresh runtime replay')
        for key in ('table_sha256', 'source_sha256', 'working_states', 'site_count', 'proved_cases',
                    'expected_cases', 'header_base', 'literal_rows_covered', 'symbolic_steps',
                    'minimum_duration_constant', 'blocks'):
            require(runtime[key] == json.loads((ROOT / 'evidence/runtime.json').read_text())[key],
                    'fresh runtime summary mismatch: ' + key)
    return {
        'status': 'U212_FULL_REPLAY_PASS' if full else 'U212_FINITE_REPLAY_PASS',
        'construction': construction, 'admissible_local_frames': local['admitted_frames'],
        'independent_path_identities': len(independent['blocks']),
        'semantic_negative_controls_rejected': len(controls),
        'comparison_status': comparison['status'], 'distinct_input_tables': 8,
        'startup_status': startup['status'], 'startup_steps': startup['literal_steps'],
        'startup_source_ordinal': startup['source_ordinal'], 'source_seed_steps': startup['source_steps'],
        'saved_runtime_audit': saved, 'fresh_runtime_cases': 5084 if full else 0,
        'fresh_runtime_rows': runtime['literal_rows_covered'] if runtime else None,
        'parent_status': parent_receipt['status'], 'parent_inherited_audit': parent_receipt['parent'],
        'scope': 'Exact literal reduction, finite source/data bindings and startup; --full rederives arbitrary-natural runtime contracts. Mathematical U/PA interpretations remain inherited, with no new end-to-end proof-assistant certificate.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--report', type=Path)
    parser.add_argument('--work', type=Path, help='Keep intermediate outputs in this initially absent directory.')
    args = parser.parse_args()
    require(__debug__ and not sys.flags.optimize, 'Do not use -O or PYTHONOPTIMIZE.')
    for p in (args.report, args.work):
        if p:
            require(not p.resolve().is_relative_to(ROOT), 'Keep output paths outside the sealed release.')
    start = time.monotonic()
    count = verify_manifest()
    if args.work:
        require(not args.work.exists(), '--work directory already exists')
        args.work.mkdir(parents=True)
        result = replay(args.work.resolve(), args.full)
    else:
        with tempfile.TemporaryDirectory(prefix='u212-replay-') as temporary:
            result = replay(Path(temporary), args.full)
    require(verify_manifest() == count, 'release changed during replay')
    result.update(manifest_files=count, seconds=round(time.monotonic() - start, 3))
    text = json.dumps(result, indent=2) + '\n'
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text)
    print(text, end='')

if __name__ == '__main__':
    main()
