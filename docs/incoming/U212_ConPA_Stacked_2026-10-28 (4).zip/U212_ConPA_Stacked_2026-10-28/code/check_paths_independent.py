#!/usr/bin/env python3
"""Finite certificate of four whole-tape path identities for U213 -> U212.

Unspecified cells are opaque: accessing one is an error. Therefore each checked
identity applies to every extension of its specified finite tape fragment.
The incoming-edge inventories establish the sole required entry invariant.
"""
from pathlib import Path
import argparse,json,hashlib
HERE=Path(__file__).resolve().parent

def need(test,message):
    if not test:raise ValueError(message)
def read(path):
    table={};start=[]
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):start.append(int(line[9:]));continue
        if not line or line.startswith('#'):continue
        q,b,w,d,r=line.split();q,b,w,r=map(int,(q,b,w,r))
        need((q,b)not in table and b in (0,1)and w in (0,1)and d in ('L','R'),'invalid transition')
        table[q,b]=w,(-1 if d=='L'else 1),r
    need(start==[0],'wrong start');return table
def execute_opaque(T,fragment,path):
    tape=dict(fragment);trace=[]
    for (q,h),(r,k)in zip(path,path[1:]):
        need(q!=254,'internal halt')
        need(h in tape,'path touches unspecified exterior')
        b=tape[h];w,d,z=T[q,b]
        need((z,h+d)==(r,k),'literal path mismatch')
        trace.append([q,h,b,w,d,z]);tape[h]=w
    need(tape==fragment,'path changes complete tape')
    return trace
def verify(A,C):
    need(len(A)==426 and len(C)==424,'transition count')
    need(A[180,1]==(1,1,172)and A[172,0]==(0,-1,112),'parent patch inputs')
    B=dict(A);B[180,1]=(1,1,211)
    expected={k:v for k,v in B.items()if k[0]!=112};expected[172,0]=(0,-1,67)
    need(C==expected,'candidate is not exact declared patch')
    need([k for k,v in A.items()if v[2]==172]==[(116,0),(180,1)],'old172 incoming inventory')
    need([k for k,v in B.items()if v[2]==172]==[(116,0)],'new172 incoming inventory')
    need(B[116,0]==(0,1,172),'172 must have preceding zero')
    need([k for k,v in B.items()if v[2]==112]==[(172,0)],'112 incoming inventory')
    need(0 not in (172,112),'invariant starts before either state')
    states={q for q,b in C}
    need(len(states)==212 and set(C)=={(q,b)for q in states for b in (0,1)},'total212-state machine')
    need({r for w,d,r in C.values()}-states=={254},'halt and target inventory')
    records=[]
    blocks=[
        ('next_one',{0:1,1:1},[(180,0),(172,1),(184,2)],[(180,0),(211,1),(184,2)]),
        ('next_zero_then_zero',{0:1,1:0,2:0},[(180,0),(172,1),(112,0),(209,1),(157,2),(67,1),(151,2),(90,3)],[(180,0),(211,1),(218,2),(90,3)]),
        ('next_zero_then_one',{0:1,1:0,2:1},[(180,0),(172,1),(112,0),(209,1),(157,2),(148,1),(186,2),(86,3)],[(180,0),(211,1),(218,2),(86,3)])]
    for name,frag,old,new in blocks:
        need(old[0]==new[0]and old[-1]==new[-1],'synchronization endpoint')
        records.append({'name':name,'fragment':frag,'old_path':old,'new_path':new,'old_trace':execute_opaque(A,frag,old),'new_trace':execute_opaque(B,frag,new),'old_steps':len(old)-1,'new_steps':len(new)-1})
    frag={-1:0,0:0};old=[(172,0),(112,-1),(157,0),(67,-1),(151,0)];new=[(172,0),(67,-1),(151,0)]
    records.append({'name':'preceding_zero_deletion','fragment':frag,'old_path':old,'new_path':new,'old_trace':execute_opaque(B,frag,old),'new_trace':execute_opaque(C,frag,new),'old_steps':4,'new_steps':2})
    return {'status':'EXACT_OPAQUE_EXTERIOR_BLOCK_CERTIFICATE_PASS','parent_states':213,'candidate_states':212,'candidate_rows':424,'bypass_helper':211,'deleted_state':112,'changed_retained_rows':[[180,1,1,1,211],[172,0,0,-1,67]],'incoming172_after_bypass':[[116,0]],'incoming112_after_bypass':[[172,0]],'blocks':records,'scope':'Each literal path reads only the displayed fragment and preserves every cell. The unique-entry invariant and induction on positive blocks yield PA-formalizable all-initial-tapes halting equivalence from state0. This finite checker is not a proof-assistant kernel.'}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--parent',type=Path,required=True);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    report=verify(read(a.parent),read(a.candidate));report['parent_sha256']=hashlib.sha256(a.parent.read_bytes()).hexdigest();report['candidate_sha256']=hashlib.sha256(a.candidate.read_bytes()).hexdigest()
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='blocks'},indent=2))
if __name__=='__main__':main()
