#!/usr/bin/env python3
"""Recheck all eight input-table/source censuses from retained snapshots."""
import argparse
import hashlib
import json
from pathlib import Path

from check_block_simulation import read_table, require

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def metrics(path):
    rows = json.loads(path.read_text())
    leaves = {p: (op, arg) for p, op, arg in rows}
    require(len(leaves) == len(rows), 'duplicate source address')
    prefixes = {p[:j] for p in leaves for j in range(len(p))}
    require(not (prefixes & leaves.keys()), 'non-prefix-free source')
    require(all(p + b in prefixes or p + b in leaves for p in prefixes for b in '01'),
            'incomplete binary source')
    nodes = set()
    def tree(p):
        node = leaves[p] if p in leaves else (tree(p + '0'), tree(p + '1'))
        nodes.add(node)
        return node
    tree('')
    return {'dag_nodes': len(nodes), 'primitive_occurrences': len(rows),
            'guarded_cases': sum(2 if op == 'CD' else 1 for p, op, arg in rows),
            'maximum_depth': max(len(p) for p in leaves),
            'maximum_zero_run': max(len(s) for p in leaves for s in p.split('1'))}

def audit(root):
    root = Path(root)
    ledger = json.loads((root / 'comparison/census.json').read_text())
    base_path = root / 'comparison/u214.native.tm'
    base = read_table(base_path, 214)
    require(sha(base_path) == ledger['baseline_u214_sha256'], 'wrong U214 snapshot')
    base_states = {q for q, b in base}
    hashes, results = set(), []
    for item in ledger['proposals']:
        table_path, source_path = root / item['native_table'], root / item['source_path']
        require(sha(table_path) == item['native_sha256'], 'table hash: ' + item['id'])
        require(sha(source_path) == item['source_sha256'], 'source hash: ' + item['id'])
        rows = read_table(table_path, 213)
        states = {q for q, b in rows}
        require(metrics(source_path) == item['metrics'], 'source census: ' + item['id'])
        relative = {'removed_states': sorted(base_states - states),
                    'added_states': sorted(states - base_states),
                    'changed_retained_rows': sum(rows[k] != base[k] for k in rows if k in base)}
        require(relative == item['relative_to_u214'], 'table comparison: ' + item['id'])
        incoming = [[q, b, w, 'R' if d == 1 else 'L', r]
                    for (q, b), (w, d, r) in sorted(rows.items()) if r == 172]
        require(incoming == item['incoming172'], 'incoming inventory: ' + item['id'])
        helpers = sorted(q for q in states if rows[q, 0] == (0, 1, 218)
                         and rows[q, 1] == (1, 1, 184))
        require(helpers == item['old167_exact_row_pair_states'], 'helper census: ' + item['id'])
        hashes.add(sha(table_path))
        results.append({'id': item['id'], 'states': len(states), 'rows': len(rows),
                        **item['metrics'], 'matching_bypass_helpers': helpers})
    require(len(results) == len(hashes) == 8, 'expected eight distinct native tables')
    return {'status': 'EIGHT_PROPOSAL_CENSUS_PASS', 'distinct_native_tables': 8, 'proposals': results}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    print(json.dumps(audit(args.root), indent=2))
