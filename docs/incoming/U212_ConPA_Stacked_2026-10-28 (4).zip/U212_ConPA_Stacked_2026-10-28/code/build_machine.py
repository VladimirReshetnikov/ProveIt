#!/usr/bin/env python3
"""Construct the exact U212 native/dense tables by the two-row parent patch."""
import argparse
import hashlib
import json
from pathlib import Path

from check_block_simulation import read_table, require

PARENT_SHA = 'bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7'
NATIVE_SHA = '386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
DENSE_SHA = 'c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def encode(rows):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {r}\n'
        for (q, b), (w, d, r) in sorted(rows.items()))).encode()

def build(parent, output):
    parent, output = Path(parent), Path(output)
    require(digest(parent.read_bytes()) == PARENT_SHA, 'wrong parent table identity')
    old = read_table(parent, 213)
    rows = dict(old)
    rows[180, 1] = 1, 1, 211
    rows[172, 0] = 0, -1, 67
    del rows[112, 0]
    del rows[112, 1]
    states = sorted({q for q, b in rows})
    require(len(states) == 212 and len(rows) == 424, 'wrong construction count')
    require({r for w, d, r in rows.values()} - set(states) == {254}, 'dangling target')
    mapping = {q: i for i, q in enumerate(states)}
    mapping[254] = 212
    dense = {(mapping[q], b): (w, d, mapping[r]) for (q, b), (w, d, r) in rows.items()}
    native_bytes, dense_bytes = encode(rows), encode(dense)
    require(digest(native_bytes) == NATIVE_SHA, 'native construction mismatch')
    require(digest(dense_bytes) == DENSE_SHA, 'dense construction mismatch')
    reached, todo = set(), [0]
    while todo:
        q = todo.pop()
        if q in reached or q == 254:
            continue
        reached.add(q)
        todo.extend(rows[q, b][2] for b in (0, 1))
    require(reached == set(states), 'unreachable working state in transition graph')
    output.mkdir(parents=True, exist_ok=True)
    (output / 'u212.native.tm').write_bytes(native_bytes)
    (output / 'u212.tm').write_bytes(dense_bytes)
    state_map = {'native_to_dense': mapping, 'dense_to_native': {v: k for k, v in mapping.items()},
                 'native_halt': 254, 'dense_halt': 212, 'start': 0}
    (output / 'state_map.json').write_text(json.dumps(state_map, indent=2) + '\n')
    summary = {
        'status': 'EXACT_U212_CONSTRUCTION_PASS', 'working_states': 212, 'transitions': 424,
        'symbols': [0, 1], 'blank': 0, 'tapes': 1, 'tape_index': 'integers',
        'initial_state': 0, 'initial_head': 0, 'initial_tape': 'all zero',
        'moves': ['L', 'R'], 'dense_halt': 212, 'native_halt': 254,
        'parent_sha256': PARENT_SHA, 'native_sha256': NATIVE_SHA, 'dense_sha256': DENSE_SHA,
        'changed_retained_rows': [[180, 1, 1, 'R', 211], [172, 0, 0, 'L', 67]],
        'deleted_states': [112], 'graph_reachable_working_states': len(reached),
        'note': 'Graph reachability does not assert visitation of every state on the blank run.'}
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('parent', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.parent, args.output), indent=2))
