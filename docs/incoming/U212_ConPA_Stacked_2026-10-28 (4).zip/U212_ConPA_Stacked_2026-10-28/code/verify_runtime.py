#!/usr/bin/env python3
"""Re-derive all 5,084 universal primitive contracts for the supplied U212 table.

The four hash-pinned helper modules are loaded from the extracted U213 (1)
parent archive. No external packages or session-specific paths are used.
"""
import argparse,gzip,hashlib,importlib,json,sys,time
from pathlib import Path
sys.dont_write_bytecode=True

HELPERS={
 'code/symbolic_runtime.py':'61b9c66272e8fd149829177cc384013814aea3c6b3b6b6f48e462d3913ea2022',
 'code/independent_runtime.py':'d490397a2b31be4f7f62461a3d9bcd88faf9093de904e43eea1b865561e7b7ee',
 'code/source_language.py':'4b355b81373a06ce2d8d99f56ac88afee8bbbd934d21f4f2729d864d9807683f',
 'code/build_table.py':'b2b129c1199485e1276466e08ad3bd25812259baaa5f77da12752a76f3b7e78a',
 'inputs/legacy_mapping.json':'26a4bff859adcc510f1faf4364a597681fec014a136bc1d00dc9ce1904ad6bbf'}
SOURCE_SHA256='7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'

def need(ok,msg):
    if not ok:raise ValueError(msg)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_json(path):
    raw=Path(path).read_bytes()
    if str(path).endswith('.gz'):raw=gzip.decompress(raw)
    return json.loads(raw)

def run(parent,table,source,out,expected=None,compress=False):
    need(__debug__ and not sys.flags.optimize,'Assertions must remain enabled; do not use -O.')
    parent,table,source,out=map(lambda p:Path(p).resolve(),(parent,table,source,out))
    for name,sha in HELPERS.items():need(digest(parent/name)==sha,'Parent helper hash differs: '+name)
    need(digest(source)==SOURCE_SHA256,'Wrong source identity')
    need(source.read_bytes()==(parent/'machine/sites.json').read_bytes(),'Source differs from parent')
    sys.path.insert(0,str(parent/'code'))
    s=importlib.import_module('symbolic_runtime')
    bt=importlib.import_module('build_table')
    sl=importlib.import_module('source_language')
    for mod in (s,bt,sl,s.r):
        need(Path(mod.__file__).resolve().parent==parent/'code','Unexpected imported helper location')
    T=bt.parse(table.read_bytes());Q=bt.validate(T,212)
    rows=load_json(source);tree=sl.tree(rows)
    need(sl.metrics(tree)=={'dag_nodes':197,'leaf_occurrences':3909,'maximum_depth':42,'maximum_zero_run':6},'Source census')
    graph,checks=sl.graph_arithmetic(rows)
    need(graph==sl.graph_intervals(rows),'Source CFG disagreement')
    need(checks==5084,'Guarded successor census')
    mapping={int(k):int(v)for k,v in load_json(parent/'inputs/legacy_mapping.json').items()}
    for q in Q|{254}:mapping.setdefault(q,q+1000)
    need(len({mapping[q]for q in Q|{254}})==len(Q)+1,'Native/legacy map not injective')
    need(mapping[84]==96 and mapping[254]==254,'Dispatcher/halt mapping')
    literal={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in T.items()}
    need(s.HEADER_BASE==56,'Wrong header base')
    need(s.r.PHY==(6,2,0,4,3,7,8,5,1),'Wrong register permutation')
    start=time.monotonic();lemmas,blocks=s.prove_blocks(literal);cases=[];used=set()
    for i,site in enumerate(rows):
        for positive in ((False,True)if site[1]=='CD'else(False,)):
            answer=s.case(literal,lemmas,site,positive)
            used.update(answer['rows']);answer['rows']=sorted(answer['rows']);answer.pop('trace')
            cases.append({'site_index':i,'positive':positive,**answer})
        if (i+1)%1000==0:print('Proved',len(cases),'cases',flush=True)
    need(len(cases)==5084,'Case coverage')
    for block in blocks:
        for event in block['trace']:used.add(tuple(event[1][:2]))
    need(used==set(literal),'Literal row coverage')
    cases=json.loads(json.dumps(cases))
    expected_match=None
    if expected is not None:
        need(cases==load_json(expected),'Fresh derivations differ from saved expected cases')
        expected_match=True
    out.mkdir(parents=True,exist_ok=True)
    case_bytes=(json.dumps(cases,indent=2)+'\n').encode()
    case_name='runtime_cases.json.gz'if compress else'runtime_cases.json'
    (out/case_name).write_bytes(gzip.compress(case_bytes,mtime=0)if compress else case_bytes)
    report={
        'status':'UNIVERSAL_MATHEMATICAL_PASS',
        'checker_sha256':digest(__file__),'helper_sha256':HELPERS,
        'table_sha256':digest(table),'source_sha256':digest(source),
        'working_states':212,'site_count':3909,'proved_cases':len(cases),
        'expected_cases':5084,'header_base':56,'literal_rows_covered':len(used),
        'symbolic_steps':sum(x['symbolic_steps']for x in cases),
        'minimum_duration_constant':min(x['duration'][0]for x in cases),
        'blocks':blocks,'seconds':time.monotonic()-start,
        'saved_expected_cases_match':expected_match,
        'case_records_file':case_name,
        'uncompressed_case_records_sha256':hashlib.sha256(case_bytes).hexdigest(),
        'scope':'All natural primary registers at each decrement guard; arbitrary natural gap; arbitrary nonempty finite spare list; complete zero exterior. Unary and finite-list induction, not bounded register testing. Source calibration and blank startup are separate. No proof-assistant kernel certificate.'}
    (out/'runtime.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('parent','table','source','output'):ap.add_argument('--'+name,type=Path,required=True)
    ap.add_argument('--expected',type=Path,help='Expected case records, JSON or JSON.gz')
    ap.add_argument('--gzip',action='store_true',help='Write deterministic gzip-compressed case records')
    args=ap.parse_args()
    print(json.dumps(run(args.parent,args.table,args.source,args.output,args.expected,args.gzip),indent=2))
if __name__=='__main__':main()
