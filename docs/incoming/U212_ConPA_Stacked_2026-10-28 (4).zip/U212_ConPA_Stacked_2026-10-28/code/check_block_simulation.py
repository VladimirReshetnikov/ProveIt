#!/usr/bin/env python3
"""Independent finite certificate for a whole-tape U213 -> U212 simulation.

The tape outside [-2,2] is opaque. A test is rejected if it reads that exterior.
Exhausting this window is therefore a proof of each local identity for every
exterior tape, not a truncation or blank-exterior assumption. No parent modules
or construction routines are imported.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path

def require(test, message):
    if not test:
        raise ValueError(message)

def read_table(path, count):
    rows = {}
    starts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        elif line and not line.startswith('#'):
            tokens = line.split()
            require(len(tokens) == 5, 'bad row length')
            q, b, w, d, r = tokens
            q, b, w, r = map(int, (q, b, w, r))
            require(b in (0, 1) and w in (0, 1) and d in ('L', 'R'), 'bad row')
            require((q, b) not in rows, 'duplicate row')
            rows[q, b] = w, (1 if d == 'R' else -1), r
    states = {q for q, b in rows}
    require(starts == [0], 'initial state must be zero')
    require(len(states) == count, 'wrong state count')
    require(set(rows) == {(q, b) for q in states for b in (0, 1)}, 'incomplete table')
    require({r for w, d, r in rows.values()} - states == {254}, 'wrong halt closure')
    require(0 in states and 254 not in states, 'wrong start/halt')
    return rows

def guard(q, h, tape):
    return q != 112 and (q != 172 or tape[h - 1] == 0)

def run(rows, q, tape, length):
    h = 0
    tape = dict(tape)
    trace = []
    for _ in range(length):
        require(q != 254, 'halt inside a comparison block')
        require(h in tape, 'read of opaque exterior')
        b = tape[h]
        w, d, r = rows[q, b]
        trace.append([q, h, b, w, d, r])
        tape[h] = w
        h += d
        q = r
    return q, h, tape, trace

def check_blocks(old, new):
    counts = {}
    examples = {}
    admitted = 0
    for q in sorted({q for q, b in old} - {112}):
        for bits in itertools.product((0, 1), repeat=5):
            tape = dict(zip(range(-2, 3), bits))
            if not guard(q, 0, tape):
                continue
            admitted += 1
            if q == 180 and tape[0] == 1:
                kind = 'bypass_11' if tape[1] else 'bypass_10' + str(tape[2])
                lengths = (2, 2) if tape[1] else (7, 3)
            elif q == 172 and tape[0] == 0:
                kind, lengths = 'two_zero_fold', (4, 2)
            else:
                kind, lengths = 'ordinary', (1, 1)
            a = run(old, q, tape, lengths[0])
            b = run(new, q, tape, lengths[1])
            require(a[:3] == b[:3], 'whole-tape endpoint mismatch: ' + str((q, bits, kind, a, b)))
            require(guard(a[0], a[1], a[2]), 'checkpoint guard not preserved')
            require(lengths[1] <= lengths[0] and 3 * lengths[0] <= 7 * lengths[1], 'time bound')
            counts[kind] = counts.get(kind, 0) + 1
            if kind != 'ordinary':
                examples.setdefault(kind, {'initial_window': tape, 'old_trace': a[3],
                                            'new_trace': b[3], 'endpoint': list(a[:2]),
                                            'old_steps': lengths[0], 'new_steps': lengths[1]})
    require(admitted == 6768, 'unexpected frame census')
    return {'admitted_frames': admitted, 'radius': 2, 'counts': counts, 'examples': examples}

def verify(old, new):
    require(new == {k: ((1, 1, 211) if k == (180, 1) else
                        (0, -1, 67) if k == (172, 0) else v)
                    for k, v in old.items() if k[0] != 112}, 'not the specified patch')
    require(old[180, 1] == (1, 1, 172), 'wrong bypass origin')
    require(old[172, 0] == (0, -1, 112), 'wrong deletion origin')
    incoming = {s: sorted([q, b, w, d] for (q, b), (w, d, r) in old.items() if r == s)
                for s in (172, 112)}
    require(incoming[172] == [[116, 0, 0, 1], [180, 1, 1, 1]], 'wrong incoming inventory172')
    require(incoming[112] == [[172, 0, 0, -1]], 'wrong incoming inventory112')
    proof = check_blocks(old, new)
    return {'status': 'ALL_TAPE_BLOCK_SIMULATION_PASS', 'old_states': 213, 'new_states': 212,
            'initial_state': 0, 'halt': 254, 'incoming': incoming,
            'checkpoint_invariant': 'q != 112 and (q != 172 or tape[head-1] == 0)',
            'time_bounds': 'T_new <= T_old <= (7/3) T_new, conditional on halting',
            'formalization': 'Finite path identities and induction on coded execution length in PA.',
            'kernel_checked': False, **proof}

def negative_controls(old, new):
    tests = []
    def mutated(label, key, value):
        t = dict(new)
        t[key] = value
        tests.append((label, old, t))
    mutated('omit bypass', (180, 1), (1, 1, 172))
    mutated('bypass writes zero', (180, 1), (0, 1, 211))
    mutated('bypass moves left', (180, 1), (1, -1, 211))
    mutated('wrong helper exit', (211, 1), (1, 1, 86))
    mutated('fold writes one', (172, 0), (1, -1, 67))
    mutated('fold moves right', (172, 0), (0, 1, 67))
    mutated('fold wrong target', (172, 0), (0, -1, 151))
    a, b = dict(old), dict(new)
    a[116, 0] = b[116, 0] = (1, 1, 172)
    tests.append(('destroy zero entry tag in both tables', a, b))
    rejected = []
    for label, a, b in tests:
        try:
            check_blocks(a, b)
        except (ValueError, KeyError) as error:
            rejected.append({'mutation': label, 'status': 'REJECTED', 'reason': str(error)[:180]})
        else:
            raise ValueError('negative control was accepted: ' + label)
    return rejected

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old', type=Path)
    parser.add_argument('new', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    old, new = read_table(args.old, 213), read_table(args.new, 212)
    result = verify(old, new)
    result['negative_controls'] = negative_controls(old, new)
    result['sha256'] = {k: hashlib.sha256(p.read_bytes()).hexdigest()
                        for k, p in [('old', args.old), ('new', args.new)]}
    data = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(data)
    print(data, end='')

if __name__ == '__main__':
    main()
