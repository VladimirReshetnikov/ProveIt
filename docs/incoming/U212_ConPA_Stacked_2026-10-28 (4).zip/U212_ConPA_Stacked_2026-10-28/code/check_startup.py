#!/usr/bin/env python3
"""Replay U212's exact blank initialization and the inherited source-seed link.

The parent checker is hash-pinned and rerun on the parent. The candidate is
replayed by this module's own sparse-tape simulator. Complete tapes must agree.
"""
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True

PARENT_CHECKER_SHA256='f9581dd132940de80a142b06b519363f48ee8a3203d5426e489893f5f63ff285'
PARENT_TABLE_SHA256='bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7'
SOURCE_SHA256='7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'

def need(ok,msg):
    if not ok:raise ValueError(msg)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read_table(path):
    transitions={};starts=[]
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):starts.append(int(line[9:]));continue
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need((q,b)not in transitions and b in (0,1)and w in (0,1)and d in ('L','R'),'Malformed transition')
        transitions[q,b]=(w,1 if d=='R'else-1,z)
    need(starts==[0],'Wrong initial state')
    states={q for q,b in transitions}
    need(set(transitions)=={(q,b)for q in states for b in (0,1)},'Incomplete binary table')
    need(0 in states and 254 not in states,'Start/halt census')
    need({z for w,d,z in transitions.values()}-states=={254},'Target census')
    return transitions

def run(parent,table,source):
    parent,table,source=map(lambda p:Path(p).resolve(),(parent,table,source))
    parent_table=parent/'machine/u213.native.tm';parent_source=parent/'machine/sites.json'
    checker=parent/'code/check_startup_independent.py'
    need(digest(checker)==PARENT_CHECKER_SHA256,'Parent startup checker identity')
    need(digest(parent_table)==PARENT_TABLE_SHA256,'Parent table identity')
    need(digest(source)==SOURCE_SHA256,'Source identity')
    need(source.read_bytes()==parent_source.read_bytes(),'Candidate source differs from parent')
    spec=importlib.util.spec_from_file_location('_u213_parent_startup',checker)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    # This freshly checks both the parent's literal frame and the 141 source
    # steps from ordinal106, registers(1,0,4,0,0,1,0,0,1), to ordinal136.
    inherited=module.audit(parent_table,parent_source)
    need(inherited==json.loads((parent/'evidence/startup_independent.json').read_text()),'Parent startup differs from its saved receipt')
    need(inherited['literal_steps']==48140,'Parent startup length')
    T=read_table(table);A=read_table(parent_table);states={q for q,b in T}
    need(len(states)==212 and len(T)==424,'Candidate census')
    changed={key for key in T if key not in A or T[key]!=A[key]}
    need(changed=={(180,1),(172,0)},'Unexpected candidate retained-row changes')
    need(set(A)-set(T)=={(112,0),(112,1)},'Unexpected deleted rows')
    need(T[180,1]==(1,1,211)and T[172,0]==(0,-1,67),'Wrong candidate patch')
    q=head=0;ones=set();used=set();trace_hash=hashlib.sha256()
    for tick in range(48140):
        bit=int(head in ones);write,move,next_q=T[q,bit]
        trace_hash.update((json.dumps([tick,q,head,bit,write,move,next_q],separators=(',',':'))+'\n').encode())
        used.add((q,bit))
        if write:ones.add(head)
        else:ones.discard(head)
        q,head=next_q,head+move
    need((q,head)==(84,-2),'Candidate startup control endpoint')
    # Explicitly reconstruct the frame rather than trusting a saved cell list.
    pc='001100110101010';registers=[1,0,13,0,0,1,0,0,1]
    rows=json.loads(source.read_text());need(rows[136][0]==pc,'Source ordinal/address')
    permutation=(6,2,0,4,3,7,8,5,1);physical=[0]*9
    for i,j in enumerate(permutation):physical[j]=registers[i]
    want={-3,54}|{head+i for i,c in enumerate(pc)if c=='1'};position=55
    for value in physical+[1]*43:
        want.update(range(position+1,position+value+2));position+=value+2
    need(ones==want==set(inherited['one_cells']),'Complete startup tape and zero exterior')
    need(len(ones)==120,'Startup one-cell count')
    need(not used&changed,'Changed row unexpectedly used during startup')
    need(trace_hash.hexdigest()==inherited['literal_delta_sha256'],'Startup traces differ')
    return {
        'status':'EXACT_U212_BLANK_STARTUP_AND_SOURCE_SEED_PASS',
        'checker_sha256':digest(__file__),
        'parent_checker_sha256':PARENT_CHECKER_SHA256,
        'parent_table_sha256':PARENT_TABLE_SHA256,
        'table_sha256':digest(table),'source_sha256':digest(source),
        'working_states':212,'rows':424,'literal_steps':48140,
        'state':q,'head':head,'header':54,'header_distance':56,'additional_gap':0,
        'source_ordinal':136,'source_address':pc,'registers':registers,
        'spares':[1]*43,'one_cells':sorted(ones),'changed_rows_visited':[],
        'literal_delta_sha256':trace_hash.hexdigest(),
        'source_seed_ordinal':inherited['source_seed_ordinal'],
        'source_seed':inherited['source_seed'],'source_steps':inherited['source_steps'],
        'source_trace':inherited['source_trace'],
        'scope':'Fresh exact candidate blank run, identical complete parent frame and trace, and freshly checked inherited 141-step source-seed connection. Infinite source-suffix safety, credit, and theory calibration remain inherited mathematical obligations.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('parent','table','source','output'):ap.add_argument('--'+name,type=Path,required=True)
    args=ap.parse_args();report=run(args.parent,args.table,args.source)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in ('source_trace','one_cells','spares')},indent=2))
if __name__=='__main__':main()
