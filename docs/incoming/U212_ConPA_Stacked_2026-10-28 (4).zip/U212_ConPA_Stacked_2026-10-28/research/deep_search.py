from pathlib import Path
import sys,json,time

def read(p):
 return {(int(q),int(b)):(int(w),1 if d=='R' else -1,int(z)) for line in Path(p).read_text().splitlines() if line and not line.startswith('#') for q,b,w,d,z in [line.split()]}
def invariants(T,K=3):
 states={q for q,b in T}; I={0:{}}
 change=True
 while change:
  change=False
  for q in list(I):
   for b in (0,1):
    if 0 in I[q] and I[q][0]!=b:continue
    w,d,z=T[q,b]
    if z not in states:continue
    a={**I[q],0:w};a={k-d:v for k,v in a.items() if -K<=k-d<=K}
    new=a if z not in I else {k:v for k,v in I[z].items() if a.get(k)==v}
    if z not in I or new!=I[z]:I[z]=new;change=True
 return I
class Unknown(Exception):pass

def match(A,B,q,r,initial,max_steps=12,max_nodes=500):
 nodes=0;leaves=[]
 def explore(ass):
  nonlocal nodes
  nodes+=1
  if nodes>max_nodes:return False
  histories=[[],[]];status=[[q,0,{}],[r,0,{}]]
  for t in range(max_steps+1):
   for side,T in enumerate((A,B)):
    a,h,writes=status[side]
    clean={k:v for k,v in writes.items() if ass.get(k)!=v}
    sig=(a,h,tuple(sorted(clean.items())))
    histories[side].append(sig)
    if sig in histories[1-side]:
     times=[len(histories[0])-1,len(histories[1])-1];times[1-side]=histories[1-side].index(sig)
     leaves.append((dict(ass),times[0],times[1],sig));return True
   if t==max_steps:return False
   for side,T in enumerate((A,B)):
    a,h,writes=status[side]
    if (a,0) not in T:return False
    b=writes.get(h,ass.get(h))
    if b is None:
     return explore({**ass,h:0}) and explore({**ass,h:1})
    w,d,z=T[a,b]
    writes={**writes,h:w}
    status[side]=[z,h+d,writes]
  return False
 ok=explore(initial)
 return ok,nodes,leaves

def search(p,out):
 T=read(p);I=invariants(T,6);states=sorted({q for q,b in T});results=[]
 print('TABLE',p,'STATES',len(states),'INVARIANTS',len([x for x in I.values() if x]),flush=True)
 for q in states:
  if q==0:continue
  for r in states:
   if q==r:continue
   B={(a,b):(w,d,r if z==q else z) for (a,b),(w,d,z) in T.items() if a!=q}
   ok,n,leaves=match(T,B,q,r,I.get(q,{}),max_steps=20,max_nodes=400)
   if ok:
    result={'remove':q,'target':r,'invariant':I[q],'leaves':leaves};results.append(result);print('FOUND',q,r,I[q],len(leaves),flush=True)
  if q%50==0: print('at',q,flush=True)
 Path(out).write_text(json.dumps(results,indent=2))
if __name__=='__main__':search(*sys.argv[1:])
