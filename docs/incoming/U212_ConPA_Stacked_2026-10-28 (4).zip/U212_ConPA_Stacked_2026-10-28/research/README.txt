BOUNDED LOCAL REDUCTION SEARCH

The accepted result elsewhere in the deliverable is 212 states. These exploratory
searches found no additional deletion. They do not establish a lower bound.

See bounded_search_receipt.json for exact table hashes and search limits.
The Python utilities use only the standard library. Run from the extracted release root:

  python3 -B research/local_search.py TABLE OUTPUT_JSON
  python3 -B research/pattern_search.py TABLE OUTPUT_JSON
  python3 -B research/deep_search.py TABLE OUTPUT_JSON
  python3 -B research/bypass_search.py TABLE OUTPUT_JSON
  python3 -B research/entry_eliminate.py TABLE OUTPUT_JSON

A local equivalence candidate is checked in the actually edited table to avoid
circular helper reuse. Stronger invariants, unbounded scan lemmas, multi-state
rewrites, source changes, and longer local identities remain open directions.

The empty result JSON files record completed searches; diagnostic logs and
intermediate bypass histories are not proof certificates. The accepted 212
proof does not depend on these utilities or this negative research result.
