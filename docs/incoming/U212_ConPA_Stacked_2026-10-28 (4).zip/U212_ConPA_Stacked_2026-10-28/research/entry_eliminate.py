from pathlib import Path
import local_search as l
import sys,json,itertools

def search(p,out):
 T=l.read(p);I=l.invariants(T,8);states=sorted({q for q,b in T});results=[];partial=[]
 inc={q:[] for q in states}
 for e,(w,d,z) in T.items():
  if z in inc and e[0]!=z:inc[z].append(e)
 for q in states:
  if q==0:continue
  choices={};allgood=True
  for e in inc[q]:
   w,d,_=T[e];pre=I.get(e[0],{})
   if 0 in pre and pre[0]!=e[1]:raise RuntimeError('dead')
   ctx={k-d:v for k,v in {**pre,0:w}.items()}
   options=[]
   for nd in (d,-d):
    for r in states:
     if r==q:continue
     B={**T,e:(w,nd,r)}
     ok,n,leaves=l.match(T,B,q,r,ctx,max_steps=12,max_nodes=250,shift=nd-d)
     if ok:options.append({'target':r,'direction':nd,'context':ctx,'leaves':leaves})
   if not options:allgood=False;break
   choices[e]=options
  if allgood and inc[q]:
   print('ALL ENTRIES',q,{str(e):[(x['target'],x['direction'])for x in opts]for e,opts in choices.items()},flush=True)
   for selected in itertools.islice(itertools.product(*choices.values()),500):
    B={e:a for e,a in T.items() if e[0]!=q}
    for e,ch in zip(choices,selected):B[e]=(T[e][0],ch['direction'],ch['target'])
    # Verify every bypass in the final simultaneous table, guarding circular reuse.
    cert=[];yes=True
    for e,ch in zip(choices,selected):
     ok,n,leaves=l.match(T,B,q,ch['target'],ch['context'],max_steps=15,max_nodes=500,shift=ch['direction']-T[e][1])
     if not ok:yes=False;break
     cert.append({'entry':e,'target':ch['target'],'direction':ch['direction'],'context':ch['context'],'leaves':leaves})
    if yes:
     res={'remove':q,'certificate':cert};results.append(res);print('FOUND',res,flush=True)
     Path(out).write_text(json.dumps(results,indent=2));break
  elif choices:partial.append({'q':q,'tested_successful_entries':{str(e):opts for e,opts in choices.items()},'failure_entry':e})
  if q%25==0:print('at',q,flush=True)
 Path(out).write_text(json.dumps(results,indent=2))
 Path(out).with_suffix('.partial.json').write_text(json.dumps(partial,indent=2))
if __name__=='__main__':search(*sys.argv[1:])
