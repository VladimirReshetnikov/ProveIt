from pathlib import Path
from collections import deque
import local_search as l
import sys,json

def patterns(T,K=3):
 states={q for q,b in T};mask=(1<<(2*K+1))-1
 I={q:set() for q in states};I[0]=set(range(mask+1));todo=deque((0,p) for p in I[0])
 while todo:
  q,p=todo.popleft();b=(p>>K)&1;w,d,z=T[q,b]
  if z not in states:continue
  p=(p&~(1<<K))|(w<<K)
  if d==1: nxt=(p>>1,(p>>1)|(1<<(2*K)))
  else:nxt=((p<<1)&mask,((p<<1)&mask)|1)
  for pp in nxt:
   if pp not in I[z]:I[z].add(pp);todo.append((z,pp))
 return I

def match(A,B,q,r,initial,pat,K=3,max_steps=12,max_nodes=500):
 nodes=0;leaves=[]
 def explore(ass,pat):
  nonlocal nodes
  nodes+=1
  if nodes>max_nodes:return False
  histories=[[],[]];status=[[q,0,{}],[r,0,{}]]
  for t in range(max_steps+1):
   for side,T in enumerate((A,B)):
    a,h,writes=status[side]
    clean={k:v for k,v in writes.items() if ass.get(k)!=v}
    sig=(a,h,tuple(sorted(clean.items())))
    histories[side].append(sig)
    if sig in histories[1-side]:
     times=[len(histories[0])-1,len(histories[1])-1];times[1-side]=histories[1-side].index(sig)
     leaves.append((dict(ass),times[0],times[1],sig));return True
   if t==max_steps:return False
   for side,T in enumerate((A,B)):
    a,h,writes=status[side]
    if (a,0) not in T:return False
    b=writes.get(h,ass.get(h))
    if b is None:
     for x in (0,1):
      sub={p for p in pat if (p>>(h+K))&1==x} if -K<=h<=K else pat
      if sub and not explore({**ass,h:x},sub):return False
     return True
    w,d,z=T[a,b];writes={**writes,h:w};status[side]=[z,h+d,writes]
  return False
 ok=explore(initial,pat)
 return ok,nodes,leaves

def search(p,out):
 T=l.read(p);I=l.invariants(T,4);P=patterns(T,3);states=sorted({q for q,b in T});results=[]
 print('TABLE',p,'STATES',len(states),'PATTERNS',sum(map(len,P.values())),flush=True)
 for q in states:
  if q==0:continue
  for r in states:
   if q==r:continue
   B={(a,b):(w,d,r if z==q else z) for (a,b),(w,d,z) in T.items() if a!=q}
   ok,n,leaves=match(T,B,q,r,I.get(q,{}),P[q],max_steps=12,max_nodes=200)
   if ok:
    result={'remove':q,'target':r,'invariant':I[q],'patterns':sorted(P[q]),'leaves':leaves};results.append(result);print('FOUND',q,r,I[q],len(leaves),flush=True)
  if q%50==0: print('at',q,flush=True)
 Path(out).write_text(json.dumps(results,indent=2))
if __name__=='__main__':search(*sys.argv[1:])
