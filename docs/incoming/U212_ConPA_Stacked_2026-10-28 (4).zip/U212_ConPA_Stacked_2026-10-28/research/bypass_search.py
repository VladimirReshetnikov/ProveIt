from pathlib import Path
import local_search as l
import sys,json,time

def search(p,out):
 T=l.read(p);I=l.invariants(T,4);states=sorted({q for q,b in T});results=[];bypasses=[]
 inc={q:[] for q in states}
 for e,(w,d,z) in T.items():
  if z in inc:inc[z].append(e)
 for q in states:
  if q==0 or len(inc[q])<2:continue
  for e in inc[q]:
   w,d,_=T[e]
   pre=I.get(e[0],{})
   if 0 in pre and pre[0]!=e[1]:continue
   context={k-d:v for k,v in {**pre,0:w}.items()}
   for r in states:
    if r==q:continue
    B={**T,e:(w,d,r)}
    ok,n,leaves=l.match(T,B,q,r,context,max_steps=12,max_nodes=300)
    if not ok:continue
    J=l.invariants(B,4)
    if J.get(q,{})==I.get(q,{}):continue
    by={'source':e,'old_target':q,'new_target':r,'old_invariant':I[q],'new_invariant':J[q],'leaves':leaves}
    bypasses.append(by)
    print('BYPASS',e,q,'to',r,'invariant',I[q],'->',J[q],flush=True)
    for s in states:
     if s==q:continue
     C={(a,b):(v,f,s if z==q else z) for (a,b),(v,f,z) in B.items() if a!=q}
     yes,nn,ls=l.match(B,C,q,s,J[q],max_steps=16,max_nodes=500)
     if yes:
      result={'bypass':by,'remove':q,'target':s,'leaves':ls};results.append(result);print('FOUND',e,'bypass',q,r,'remove',q,s,flush=True)
      Path(out).write_text(json.dumps(results,indent=2))
  print('DONE',q,flush=True)
 Path(out).write_text(json.dumps(results,indent=2))
 Path(out).with_suffix('.bypasses.json').write_text(json.dumps(bypasses,indent=2))
if __name__=='__main__':search(*sys.argv[1:])
