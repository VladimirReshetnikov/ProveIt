U212: combining two supplied U213 reductions
===========================================
Research prepared for Vladimir Reshetnikov, 28 October 2026.

RESULT
------
machine/u212.tm is an explicit binary, single-tape Turing machine with
212 working states, 424 transitions, and a separate halt label.
Working states: 0..211. Halt: 212. Start: state 0, head 0, all-zero
two-way infinite tape. Every step writes a bit and moves L or R.
Initialization is included in the count.

Read report.pdf for the comparison of all eight U213 proposals, the
complete mathematical proof, precise inherited calibration, verification,
further research questions, and full dense transition table.
report.tex plus transition_table.tex are its complete editable sources.

THE COMBINATION
---------------
Parent: U213_ConPA_2026-10-28 (1).zip, the direct-transfer source with
197 distinct subtrees, 3,909 primitives, and seven-zero origin detector.
Transfer: the entry-bypass argument in u213_from_u214_2026-10-28.zip.
In this parent's allocation, existing state 211 supplies the helper
behavior that state 167 supplied in the bypass proposal.

The complete native retained-row patch is:

  180/read 1: (1,R,172) -> (1,R,211)
  172/read 0: (0,L,112) -> (0,L,67)

Delete both outgoing rows of native 112. Every other retained row and
the entire source program are unchanged. Native halt remains 254;
native labels are names, not state counts.

PROOF AND STATUS
----------------
Four whole-tape identities have old/new lengths 2/2, 7/3, 7/3, and 4/2.
After bypassing the one-writing entry, the only entrance to 172 writes
zero immediately left of the head. This invariant justifies deleting 112.
Induction on positive bounded blocks proves halting equivalence from
state 0 on every common initial tape. For blank or arithmetically coded
tapes the proof formalizes in PA, without any consistency assumption.

The new theorem is:

  PA |- Halt(U212, blank) <-> Halt(exact U213 parent, blank).

Composing it with the explicitly retained parent's numerical-calculus
and Theory U interpretation arguments gives the intended endpoint:

  PA |- not Halt(U212, blank) <-> Con(U) <-> Con(PA).

The endpoint inherits those mathematical arguments. This package has
no newly compiled end-to-end Lean, Rocq, MM0, or exported PA certificate.
The independent checks here are assistant reviews, not external peer
review. No unconditional nonhalting, minimum state count, or global
priority claim is made.

VERIFICATION
------------
- Exact 212-state/424-row construction and native/dense bijection.
- All eight distinct input tables/source censuses recomputed.
- Independent whole-tape checkpoint proof on 6,768 admissible radius-two
  frames; no access to unspecified exterior cells is allowed.
- Four explicit path identities checked by a separate implementation.
- Eight deliberately damaged semantic controls rejected.
- Fresh 5,084/5,084 arbitrary-natural source-runtime contracts passed.
- All 424 literal rows covered; 1,275,761 symbolic inference applications.
- Minimum constant primitive duration: 5 literal steps.
- Fresh exact blank startup: 48,140 transitions to the same complete
  interior frame as the parent; neither edited row occurs in this prefix.
- The exact parent archive's finite reconstruction, source/proof binding,
  startup, and inherited U214/U218 audits pass.

The 5,084 cases are unary/list-inductive source-site contracts, not 5,084
sampled numerical register assignments. Their saved records are not
proof-assistant certificates. --full reconstructs the symbolic derivations.

REPRODUCE OFFLINE
----------------
Requires Python 3.10+ and only its standard library:

  python3 -B reproduce.py
  python3 -B reproduce.py --full --report /tmp/u212-replay.json

Use any writable report path outside this extracted release.
--work PATH retains intermediate outputs in an initially absent directory
outside the release. Otherwise temporary work is removed.

Default replay verifies the sealed manifest, table reconstruction,
two local checks, mutation controls, eight-proposal census, startup,
saved runtime coverage, and the parent's finite audit.
--full additionally regenerates every candidate runtime case and compares
all records exactly. Assertions must stay enabled: do not use -O or
PYTHONOPTIMIZE. No network, solver, optimizer, or proof assistant is needed.

To rederive the parent's universal runtime independently, extract
inputs/direct_transfer_parent.zip elsewhere and run its reproduce.py --full.

To rebuild the report, use a separate copy with a normal TeX installation:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

Auxiliary files and altered PDF timestamps would invalidate the sealed
manifest. PDF byte identity may vary across TeX environments.

CONTENTS
--------
report.tex / report.pdf       Complete new report.
transition_table.tex          Exact generated dense table appendix.
machine/                      Native/dense tables, source, map, summary.
code/ and reproduce.py        Portable construction and verification.
evidence/                     Local, runtime, startup, and review records.
comparison/                   All 8 table/source/README snapshots and census.
inputs/                       Two exact full source archives and Theory U.
research/                     Bounded further-search scripts and receipts.
PROVENANCE.json               Exact public input URLs, hashes, snapshot.
licenses/ and NOTICE.txt      Retained attribution and licensing.
SHA256SUMS                    Integrity manifest for all other release files.

IDENTITIES (SHA-256)
-------------------
Dense:
c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e
Native:
386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4
Unchanged source:
7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00
Parent native:
bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7

The source snapshot is ProveIt commit
6b3145c0bbbf7563bd7bce44c974b4515656a5b0.
Both construction-input archives are retained unchanged. Their original
names are recorded in PROVENANCE.json; shorter local filenames do not
change their bytes or identities.

The full-replay receipt predates the final text-only clarifications and
addition of the receipt itself. The literal tables, source, runtime engine,
and verification code are identical. The final ZIP is checked separately.
