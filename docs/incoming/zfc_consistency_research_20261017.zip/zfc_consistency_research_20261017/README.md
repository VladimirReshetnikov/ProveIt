# Toward a Smaller ZFC-Consistency Machine

Research report for ProveIt, 17 October 2026. Start with `report.pdf`.
The complete editable report is `report.tex` plus `sections/*.tex`.

## Result and limits

The inspected ProveIt snapshot already has a **252-working-state binary
blank-tape machine** with a closed external Lean equivalence to ordinary
ZF consistency, including Foundation and Power. Its local ZFC implication
is one-directional; the exact comparison inside ZFC remains a separate task.
The included table is that attributed existing machine, not a new record.

This investigation supplies:

- A proved all-input bound for the exact C254 proof encoding. An input with
  `b` binary digits has a canonical sparse certificate with at most
  `floor(sqrt(3*b+1))` rows, including the invalid-zero row. Positive unfolded
  occurrences obey `N*(N+2) <= 3*b`. Correct extra interior rows may be
  accepted by the verifier, so the bound is for the canonical certificate.
- An executable exact checker and finite arithmetic graphs for acceptance
  and rejection, preserving all twelve tags, the zero/truth distinction,
  exact MP, GEN, native equality and both bundle gates.
- A proved ranked continuation criterion, its finite program certificate,
  and complete searches of 55,471 uniform folds and 132,048 full incoming
  actions. No candidate obtained the required sufficient certificate.
- A proved balanced involutive search architecture, inside-out contexts,
  and an optional one-comparison phase lift. No binary compiler, expanded
  ZFC query, or state bound is supplied for this architecture.
- A precise conditional route to the requested proof inside ZFC, with
  countable coded models and guarded witness transport. Its four actual
  all-code project obligations are explicitly still open in this deliverable.

No new machine below 252 states, minimality theorem, unconditional
nonhalting proof, or fresh Lean/Coq build is claimed. The strongest new
proved result is an arithmetic-certificate improvement. A smaller complete
binary controller remains a compiler experiment.

## Pinned sources

- ProveIt: `fab89c5d26b81cd2ccab2ee5d213ff23725c7726`.
- Upstream busy-beaver main: `ec9ed4f713d8c017f15743ad0692cdf31a59952a`.
- Upstream identity underlying the local formal comparison:
  `297ab8df7e5de329605c3875b4934643b371a5e3`.
- Public 253 PR20 head: `0d544f2a2e3c18f12278441a74b7879f31cbe856`.
- Canonical 252 table SHA256:
  `8dae0c2359aa8bf87d32543b9e53e1f87fe4716c016a4e2fd174bfe09e520797`.

The report contains permanent source links, attribution, proofs, limitations,
and prioritized research questions. See `NOTICE.md` before reusing source
material; this package does not impose a blanket license on upstream files.

## Reproduction

Python 3.10+ and its standard library suffice for the mathematical experiments:

```sh
python3 reproduce.py
python3 reproduce.py --full-searches --output full-reproduction.json
```

The ordinary run verifies the entire literal 82,552-step blank bootstrap,
source-export identity, explicit arithmetic graph regeneration, the sparse
checker suite, the involutive suite and structural audit, and the ranked
continuation certificate/ledger audit. It works in a temporary copy so the
delivered evidence remains frozen. The large numeric suite evaluates one
conclusion above 22 million bits; allow time for that exact integer work.

The optional full run repeats both bounded deletion searches and all four
modular phase analyses. A symbolic stop is not proof of global inequivalence;
the search report explains the exact finite family and checker limitations.

Compile the report with a standard LaTeX installation:

```sh
make report.pdf
```

Regenerate the optional vector figure using Matplotlib:

```sh
python3 code/make_figure.py
```

`MANIFEST.sha256` identifies the frozen deliverable files. The reproduction
driver validates it when present; `--skip-manifest` supports an intentionally
edited working copy. Runtime measurements and host paths are not mathematical
reproduction targets. The source excerpts are not a complete Lean dependency
checkout and are not advertised as independently compilable modules here.

## Suggested integration

Retain the archive as a research contribution first. The sparse checker
equivalence and dependency bound are suitable separate formalization targets.
Do not replace the calibrated machine or update a state record from this
report. Its new controller has not been compiled and its deletion search
has no survivor. Complete the stated internal ZFC bridge and measure any
replacement with its whole initializer and fixed query before changing the
record table.
