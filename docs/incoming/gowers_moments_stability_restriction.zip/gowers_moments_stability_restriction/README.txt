FURTHER QUANTITATIVE REFINEMENTS OF GOWERS'S SZEMEREDI ARGUMENT
Higher norm comparisons, joint quadratic rigidity, and restriction by affine rank

Prepared for Vladimir Reshetnikov / the ProveIt project
6 October 2026
Mathematical development and verification with ChatGPT

MAIN DELIVERABLE

  gowers_moments_stability_restriction.tex
  gowers_moments_stability_restriction.pdf

The TeX file contains the complete article, all proofs, 13 proposed research
questions, and its bibliography. It uses the supplied vector figure at
figures/norm_bounds.pdf. No external bibliography database is required.

MAIN RESULTS

1. For real f with no Fourier support on self-inverse characters, put
   m = 2^(d-2). The article proves

       ||f||_(U^d)^(2^d) >= 2^(-m) binom(2m,m) ||f||_(U^2)^(2^d).

   For centered functions on odd-order groups this improves the previously
   used comparison for every d >= 4. At d = 4 the coefficient is 35/8.
   Moment equality/stability, the full self-inverse-mass profile, and lower
   bounds for the unresolved sharp Gowers constants are included.

2. Joint quadratic endpoint stability on every finite abelian group:
   for a selector with row sums <= 1 and defect epsilon <= 2^(-9),
   normalized squared function error and selector mass defect are both
   <= 22 epsilon, with 24 as a convenient common constant. For a supplied
   single-frequency graph the disagreement bound is 20 epsilon.
   A mixed theorem has common constant 192 at epsilon <= 2^(-12).
   The linear order of the errors is optimal; the numerical constants are
   not claimed optimal.

3. For translation-invariant linear systems over a fixed finite field,
   exact survival by augmented domain rank and full error rank yields a
   size threshold 8 q S_(q,s)/(alpha eta) and retained tuple count

       alpha^(s+1) eta^s |B|^s / (2(4q)^s),

   with respected proportion >= 1/(1+eta), where
   S_(q,s) = 1 + q + ... + q^(s-2).
   A weaker coefficient removes the size threshold. The proof addresses
   source 17's question about retaining the actual survival of degenerate
   tuples. A generic higher-error-rank extension is also proved.

STATUS AND SCOPE

These are self-contained local mathematical results developed for the
project. The source comparison covers the combined first five reports,
the full historical manuscripts numbered 06-20, and three incoming
archives at the pinned snapshot. It is not an exhaustive priority search.

The article distinguishes:
  - sharp autocorrelation moment bounds from unresolved sharp norm bounds;
  - an absolute endpoint with constrained selectors from unrestricted
    weighted relative-energy stability;
  - fixed-field restriction from an all-moduli cyclic-group theorem.

No improvement of a global Szemeredi bound and no new Lean formalization
are claimed. The finite verification programs supplement the written
proofs. They are not proofs of the universal theorems.

REPOSITORY PROVENANCE

Repository: https://github.com/VladimirReshetnikov/ProveIt
Inspected commit: e3125e6982abe2d44bd7cb9369063d4e69d41a2d
Relevant project directory: Combinatorics/Ramsey

data/source_audit.json records exact source paths, historical archive
commits, checksums, relevant theorem/question locators, and the audit scope.
The article bibliography gives primary literature and pinned source links.
Older third-party manuscripts and archives are not redistributed here.

BUILD

From this directory:

  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    gowers_moments_stability_restriction.tex

or:

  make

This uses pdfLaTeX and standard TeX Live packages, including Latin Modern,
amsmath, amsthm, mathtools, microtype, graphicx, booktabs, tabularx, enumitem,
xcolor, hyperref, xurl, bookmark, fancyhdr, and needspace.

The supplied figure PDF is sufficient for an ordinary manuscript build.
To regenerate the figure:

  python code/make_figures.py

VERIFICATION

  make verify

or:

  python code/verify_moments.py --output data/moment_verification.json
  python code/verify_coefficients.py --output data/coefficients.json
  python code/verify_rank_restriction.py --output data/rank_verification.json
  python code/verify_joint_rigidity.py --output data/joint_verification.json

The first three verification programs need only the Python standard
library. Joint numerical diagnostics require NumPy. Figure generation
requires NumPy and Matplotlib; requirements.txt records the versions used.
The scripts use deterministic examples or seeded random generators.

The recorded checks all pass:
  - 65 direct cube-product norm cases, 480 Fourier-profile checks,
    25 moment sharpness cases, and 50 odd-cyclic lower-bound examples;
  - the exact balanced four-cube count 222 and 50 interval-model identities;
  - 294,881 exact map-tuple incidence checks in five restriction cases;
  - 96 exact quadratic integrations, with 11,376 polarization and
    11,376 derivative identities;
  - all 65,536 maps F_2^4 -> F_2 and all 81 maps C_4 -> C_3;
  - 96 averaged-symmetry diagnostics, 80 mixed transform identities,
    56 self and 56 mixed endpoint reconstructions, and six sharp-rate cases.

Integer/rational checks and floating-point diagnostics are identified
separately in the article and JSON output.

PACKAGE LAYOUT

  gowers_moments_stability_restriction.tex   Complete manuscript
  gowers_moments_stability_restriction.pdf   Compiled article
  Makefile                                Build and verification commands
  requirements.txt                        Tested numerical dependencies
  code/                                   Verification and figure scripts
  data/                                   Results and source provenance
  figures/                                Vector figure and PNG preview

INTEGRATION NOTES

Keep the source and figures/ directory together when copying the article.
The mathematical development is independent of the old report's macro
namespace. For a combined document, theorem labels use gmsr:, jr:, and rr:
prefixes; adapt those prefixes and the preamble to the destination.
The article includes an explicit proposed Lean formalization order.
No changes to the repository or proof-status ledger were made for this
delivery. No licensing terms for the existing repository are changed.
