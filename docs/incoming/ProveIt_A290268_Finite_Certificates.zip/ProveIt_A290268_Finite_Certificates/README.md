# From Infinite Nonvanishing to Finite Certificates

## Bulk positivity, fixed-depth finiteness, and a four-depth solution for OEIS A290268

Research continuation prepared for Vladimir Reshetnikov, 29 September 2026.
Repository snapshot: `afb2d1227d8bc5df3beffc1463e958db3544960b`.

## Results

Set

    phi(w) = (1+w)^2 log(1+w)
    gamma(k,d,M) = [w^M] (2+w)^k phi(w)^d.

The article proves:

1. **All-depth bulk positivity:** for every integer d >= 1 and k >= 0,
   gamma(k,d,M) > 0 whenever d <= M <= k+2d+1.
2. **Effective fixed-depth finiteness:** at every fixed d >= 3, all possible
   additional zeros lie in an explicitly bounded finite rectangle in (k,q),
   where q = M-k-2d-1. The bounds are elementary integers given in Section 6.
   This is a terminating fixed-depth decision procedure, not a finite proof
   simultaneously covering all depths.
3. **Complete classification at depths 1 through 4:** for M >= d,
   gamma(k,d,M) = 0 if and only if M=k+4d+1 and k+d is even.
   Depths 1 and 2 follow analytically. The new completions at depths 3 and 4
   use a proved reduction followed by exact finite arithmetic.
4. **A zero-count bound:** for fixed k,d the interpolating Mellin transform
   has at most d distinct real zeros in q > -1, with sharper parity bounds.
5. **An unconditional derivative-term-count lower bound**, plus eight
   specific further research questions.

## Scope and proof status

The full A290268 counting formula is NOT proved. Nonvanishing at depths
5 and above remains unresolved by this article. The general finite bounds
are deliberately crude and are not claimed to be practical at those depths.
No global historical-priority claim, independent refereeing, or Lean/Rocq
kernel certification is made. The first two depth classifications and the
symmetry-hole phenomenon were already discussed in the repository. Classical
Meixner-Pollaczek theory is cited rather than presented as a new family.

The finite computations are computer-assisted parts of an explicit proof,
not extrapolation from numerical samples. All arithmetic is exact and uses
only Python's standard library; no floating-point arithmetic is involved.

## Files

- `article.pdf`: compiled 22-page article.
- `article.tex`: complete self-contained LaTeX source, including bibliography.
- `code/verify.py`: full exact verifier, independent Pascal recurrence,
  original differentiation-lattice cross-check, and data generation.
- `code/minimal_verify.py`: standalone compact verifier from Appendix A.
- `data/finite_certificate.csv`: all 16,034 rectangle cells, signs, and
  residues modulo 1009 and 1013.
- `data/verification.json`: executed-check summary and exact seed integers.
- `data/sign_thresholds.csv`: observed left first-negative and right
  first-positive reduced-expectation indices in each tested row; a right
  endpoint equal to Q uses the analytically certified tail seed.
- `SOURCE_AUDIT.md`: source identity, inspected scope, and limitations.
- `Makefile`: optional build and verification commands.
- `SHA256SUMS.txt`: integrity hashes of package files, excluding itself.

## Reproduce the finite proof obligations

From this directory, with Python 3.9 or later:

    python3 code/minimal_verify.py
    python3 code/verify.py

Both commands must finish successfully. The compact script prints `PASS`.
The full script prints a JSON report with `"status": "PASS"`. Verification
failures raise explicit exceptions even with Python assertions disabled.

To regenerate the included CSV/JSON data:

    python3 code/verify.py --write-data

The optional `--lattice-order N` controls only the supplementary original
lattice cross-check. Its default is 80. It does not change the two finite
rectangles or the six seed signs required for the infinite theorem.

## Executed verification

The two independent recurrences agree on every rectangle entry:

| Depth | k range | q range | Cells | Symmetry zeros | Nonzero |
|---|---|---|---:|---:|---:|
| 3 | 0..12 | 0..37 | 494 | 6 | 488 |
| 4 | 0..83 | 0..184 | 15,540 | 42 | 15,498 |
| Total | | | 16,034 | 48 | 15,986 |

Every nonzero entry has a nonzero residue modulo 1009 or 1013. The six
analytic-threshold seed signs also pass. An independent differentiation
recurrence through order 80 checks 69,701 positive bulk cells, 21,320
integer-bridge identities, and 5,780 first-four-depth classifications.
The supplementary cross-checks are not substituted for the infinite-to-finite
proof in the article.

## Build the article

With a normal TeX Live installation including the packages named in the
source:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Alternatively run `pdflatex` at least twice. No external bibliography file,
image assets, shell escape, or proprietary font is required. The supplied
PDF has already been compiled.

## Repository relationship

No repository files were changed. The article builds on the inspected
A290268 notes and conditional support-to-count development, not on unrelated
claims elsewhere in ProveIt. See `SOURCE_AUDIT.md` for pinned source URLs.
