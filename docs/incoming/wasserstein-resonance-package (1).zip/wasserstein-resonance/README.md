# Linear and quadratic Wasserstein separation at a dyadic resonance

Let U_a be the centered uniform probability law on an interval of width a. Let mu_q be the law of the sum of independent centered uniforms of widths 1, q, q^2, ... . For a fixed probability factor sigma, measure its distance from factorability by

    Delta_sigma(q) = inf_{nu in P_1(R)} W_1(mu_q, sigma * nu).

This package treats two different prescribed factors near q = 1/2.

## Results

For sigma_1 = U_(1/2) * U_(1/3), there are strictly positive one-sided coefficients c_plus and c_minus:

    Delta_1(1/2 +/- t) = c_plus/minus * t + o(t), as t decreases to zero.

The article proves exact L^1 tangent-cone representations and bounds

    |P| / [6*pi*(1 + 12*pi)] <= c_plus, c_minus <= 1/4,

where P = product_{k>=2} sinc(6*pi*2^(-k)) is nonzero. It also proves the global adaptive bound Delta_1(q) <= |q - 1/2| / 4. These results resolve the pinned report's sharp-distance question for this factor. They apply to arbitrary real parameters near the resonance, without an irrationality assumption. Neither coefficient is evaluated and their equality is not claimed.

For sigma_2 = U_(1/2) * U_(1/4), the article instead proves

    Delta_2(q) = Theta((q - 1/2)^2)

on both sides. The first-order signed remainder has chi-square energy at most 4735, allowing its negative part to be removed and the positive part normalized at quadratic cost. The resulting deliberately crude constructive bound is Delta_2(q) <= 6259*(q - 1/2)^2 for |q - 1/2| <= 0.01. A positive quadratic Fourier lower bound matches the exponent. No second-order limiting coefficient is established.

## Files

- `wasserstein-resonance.pdf`: nine-page mathematical article with complete proofs, attribution, and limitations
- `wasserstein-resonance.tex`: editable standalone LaTeX source
- `check_linear.py` and `linear-verification.json`: finite linear-defect regressions
- `check_nested.py` and `nested-verification.json`: exact finite arithmetic and quadratic-defect regressions
- `SOURCE.txt`: pinned source URL, question location, and inspected-source hash
- `build.sh`: ordinary two-pass pdfLaTeX build
- `SHA256SUMS`: package checksums

## Reproduce the checks

Use Python 3 and its standard library, with assertions enabled. Do not use `-O`.

    python3 check_linear.py > linear-verification-new.json
    diff -u linear-verification.json linear-verification-new.json
    python3 check_nested.py > nested-verification-new.json
    diff -u nested-verification.json nested-verification-new.json

The linear checker runs 1,713 finite regression cases: 700 pairwise compact-source inequalities, 12 Fourier derivative ratios approaching from both sides, and 1,001 comparisons between analytic lower and upper bounds. The tail products are truncated at index 99.

The nested checker verifies the discrete convolution coefficients with rational arithmetic, the energy-bound arithmetic 4735, the local Taylor constant comparison with 9, and the final constant 6259. It also checks 12 floating-point derivative ratios. These are not interval-certified infinite products.

Neither program computes either optimal Wasserstein distance, the tangent-cone coefficients, the density w itself, or the actual chi-square integral. The universal results rest on the article's mathematical proofs, not on the tests. No Lean or other proof-assistant formalization is included.

## Build

Install a working pdfLaTeX distribution with amsmath, amssymb, amsthm, lmodern, geometry, booktabs, microtype, and hyperref, then run:

    sh build.sh

Every page of the delivered PDF was visually inspected after compilation.

## Attribution and scope

The motivating ProveIt question and exact pin appear in SOURCE.txt and the article. The one-dimensional CDF transport formula is credited to S. S. Vallender (1974). Classical Fabius-type convolution background is credited to Juan Arias de Reyna. The elementary convolution, Fourier, convex-distance, and positivity-repair arguments are given in full.

This is a resolution and extension of the specific pinned repository question, without a claim of worldwide priority. Optimal constants, equality of the two linear coefficients, quadratic limiting coefficients, and higher nested-factor laws remain outside the established results.

Prepared 1 October 2026 for Vladimir Reshetnikov.
