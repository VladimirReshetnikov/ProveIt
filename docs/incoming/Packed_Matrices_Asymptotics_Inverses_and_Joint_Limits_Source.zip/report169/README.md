# Report 169: Packed matrices on the total-weight 2n diagonal

This source package accompanies the standalone PDF on OEIS A261784. The model has n ordered nonzero rows, arbitrary ordered nonzero columns, nonnegative integer entries, and total 2n. It proves fixed-order count refinements and safe inverse brackets, and gives a complex-uniform marked theorem with column moment corrections and a joint Gaussian/Poisson law.

The leading equivalent is credited to Václav Kotěšovec (OEIS, 2017; updated 2024); the exact transform is due to Munarini–Poneti–Rinaldi. The report credits the relevant marked-enumeration, saddle, column-limit and collision precedents. Neither the report nor these checks establishes historical priority or worldwide novelty.

## Contents

- `report169.pdf`: complete prebuilt standalone report
- `source/report169.tex`: complete editable mathematical report
- `companion/`: exact integer and rational-arithmetic code, frozen data, examples, and tests
- `sources.json`: public primary-source URLs, inspected-source hashes, and reference locations
- `build_pdf.py`: exclusive, deterministic PDF build
- `build_archive.py`: exclusive, deterministic complete-report ZIP build
- `release_tools.py`: descriptor-pinned POSIX file operations
- `SHA256SUMS`: hashes of every other ZIP member, relative to this directory

No third-party PDFs are redistributed. All checks run offline from the included frozen data. No account, credential, upload, or repository modification is required.

## Exact companion

Python 3.10 or newer is recommended. The default companion uses the standard library. From the package directory:

    python3 -m unittest discover -s companion -p 'test_*.py' -v
    python3 -O -m unittest discover -s companion -p 'test_*.py' -v
    python3 companion/run_companion.py --help

The companion README gives the exact generation and optional symbolic-check commands, input bounds, and larger-run instructions. The optional CAS check uses SymPy; it is isolated from the standard-library tests. Decimal evaluations and asymptotic residuals are explicitly uncertified and are not replacements for the proofs. Integer identities and rational coefficient expressions are exact.

## Build the PDF

The build requires a POSIX system with `/proc/self/fd`, pdfTeX/pdfLaTeX, and the standard TeX packages used in the source. Its default TeX trees are `/usr/share/texlive/texmf-dist` and `/usr/share/texmf`; installations elsewhere can adapt the `TEXMF` setting in the script. These are dependency locations, not mathematical inputs. It creates a private format and caches inside a new directory, disables shell escape, settles cross-references, and rejects settled warnings or layout errors.

    python3 build_pdf.py --output-dir pdf-build

`pdf-build` must not already exist. The result is `pdf-build/report169.pdf`; logs and the local TeX format are retained there for diagnosis. Repeating the same command refuses the existing directory, leaving it unchanged. A fresh second directory permits a reproducibility check:

    python3 build_pdf.py --output-dir pdf-build-second
    cmp pdf-build/report169.pdf pdf-build-second/report169.pdf
    cmp report169.pdf pdf-build/report169.pdf

Metadata dates and PDF trailer IDs are suppressed; a fixed source date is supplied. Byte-for-byte PDF reproducibility requires the same engine, TeX package versions, and font files. The mathematical source is portable to other compatible LaTeX installations, but their PDF bytes can differ.

## Build the complete ZIP

    python3 build_archive.py --output report169-complete.zip

The output file must not exist. The ZIP uses a fixed member list, sorted ordering, fixed timestamps and permissions, and uncompressed storage for byte-level stability. It includes the final standalone PDF and excludes caches, logs, and review material. The build rejects symlink inputs and output ancestors, parent traversal, and existing output paths. It does not overwrite or clean up any existing destination.

To verify an extracted archive on a system with GNU coreutils:

    sha256sum --check SHA256SUMS

Alternatively, use Python's `hashlib` to check the listed bytes. Regenerating the ZIP from the extracted package produces the same bytes when the included files are unchanged.

## Scope

All asymptotic expansions are at fixed order. Remainder constants and sufficiently-large-index thresholds are not numerically certified. The count inverse is bracketed by two ceilings; a finite real approximation is not advertised as an exact ceiling rule near integer boundaries. Probability limits are weak convergence statements. The high-probability transfer to total excess does not by itself transfer its unbounded moments.
