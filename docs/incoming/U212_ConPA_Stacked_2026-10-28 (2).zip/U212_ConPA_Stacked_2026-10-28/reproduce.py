#!/usr/bin/env python3
"""Offline reconstruction, local proof, source audit, and optional full replay.

Run with Python 3.10+ on Linux/WSL, without -O. No external packages are needed.
The bundled parent is extracted into a temporary directory and never modified.
"""
import argparse
import gzip
import hashlib
import json
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT_ZIP_SHA256 = '09e869763555e19d73f1b7900eee7305105ee02219196dcc88bb6854f34d7f29'
sys.dont_write_bytecode = True


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(arguments, optimized=False):
    cmd = [sys.executable, '-B'] + (['-O'] if optimized else []) + list(map(str, arguments))
    result = subprocess.run(cmd, text=True, capture_output=True, cwd=ROOT)
    if result.returncode:
        raise RuntimeError('Failed: ' + ' '.join(cmd) + '\n' + result.stdout + '\n' + result.stderr)
    return result.stdout


def manifest():
    names = []
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = (ROOT / name).resolve()
        need(path.is_relative_to(ROOT) and path.is_file(), 'unsafe or missing manifest file')
        need(sha(path) == expected, 'manifest mismatch: ' + name)
        names.append(name)
    need(len(names) == len(set(names)), 'duplicate manifest entry')
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
    need(set(names) == actual, 'manifest does not cover exactly the release files')
    return len(names)


def unpack_parent(work):
    archive = ROOT / 'inputs/U213_parent.zip'
    need(sha(archive) == PARENT_ZIP_SHA256, 'wrong parent ZIP')
    target = work / 'parent'
    target.mkdir()
    with zipfile.ZipFile(archive) as zipped:
        for item in zipped.infolist():
            need((target / item.filename).resolve().is_relative_to(target), 'unsafe parent ZIP entry')
            need((item.external_attr >> 16) & 0o170000 != 0o120000, 'parent ZIP symlink')
        zipped.extractall(target)
    return target / 'U213_ConPA_2026-10-28'


def check_comparison(parent):
    sys.path.insert(0, str(parent / 'code'))
    import build_table as bt
    import source_language as sl
    ledger = json.loads((ROOT / 'comparisons/index.json').read_text())
    need([row['label'] for row in ledger] == list('ABCDEFGH'), 'comparison inventory')
    for entry in ledger:
        directory = ROOT / 'comparisons' / entry['label']
        for name, expected in entry['retained_files'].items():
            need(sha(directory / name) == expected, 'comparison file digest')
        native = bt.parse((directory / 'u213.native.tm').read_bytes())
        bt.validate(native, 213)
        dense_bytes = (directory / 'u213.tm').read_bytes()
        if not any(line.startswith(b'#! start ') for line in dense_bytes.splitlines()):
            # Proposal D's unmodified dense file omits the optional header;
            # its README explicitly specifies initial state zero. Normalize
            # only the parser input, preserving the original bytes and hash.
            need(entry['label'] == 'D', 'unexpected missing dense start declaration')
            need('It starts in state 0 at coordinate 0' in (directory / 'README.txt').read_text(), 'unbound initial state')
            dense_bytes = b'#! start 0\n' + dense_bytes
        dense = bt.parse(dense_bytes)
        bt.validate(dense, 213, 213)
        stats = sl.metrics(sl.tree(json.loads((directory / 'sites.json').read_text())))
        need(stats['dag_nodes'] == entry['source_subtrees'], 'comparison subtree count')
        need(stats['leaf_occurrences'] == entry['source_primitives'], 'comparison primitive count')
        incoming = [dict(row=list(key), transition=[w, 'R' if d == 1 else 'L', z])
                    for key, (w, d, z) in sorted(native.items()) if z == 172]
        need(incoming == entry['incoming_172'], 'comparison incoming-edge inventory')
        fast = [q for q, b in sorted(native) if b == 0
                and native[q, 0] == (0, 1, 218) and native[q, 1] == (1, 1, 184)]
        need(fast == entry['fast_bypass_states'], 'comparison role inventory')
    return dict(proposals=8, counts_and_role_inventories_checked=True,
                all_predecessors_fully_replayed=False)


def check_runtime_receipts(parent):
    cases = json.loads(gzip.decompress((ROOT / 'evidence/runtime_cases.json.gz').read_bytes()))
    report = json.loads((ROOT / 'evidence/runtime.json').read_text())
    source = json.loads((ROOT / 'machine/sites.json').read_text())
    expected = [(i, positive) for i, row in enumerate(source)
                for positive in ((False, True) if row[1] == 'CD' else (False,))]
    need([(row['site_index'], row['positive']) for row in cases] == expected, 'guarded case coverage')
    need(len(cases) == 5084 and report['proved_cases'] == 5084, 'runtime count')
    need(report['table_sha256'] == sha(ROOT / 'machine/u212.native.tm'), 'runtime table binding')
    need(report['source_sha256'] == sha(ROOT / 'machine/sites.json'), 'runtime source binding')
    need((ROOT / 'machine/sites.json').read_bytes() == (parent / 'machine/sites.json').read_bytes(), 'source changed')
    for row in cases:
        need(len(row['duration']) == 13 and all(x >= 0 for x in row['duration'])
             and row['duration'][0] > 0, 'invalid primitive duration')
    need(sum(row['symbolic_steps'] for row in cases) == report['symbolic_steps'] == 1275761, 'step inventory')
    need(report['literal_rows_covered'] == 424 and report['header_base'] == 56, 'runtime convention')
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true', help='rederive all 5,084 candidate contracts')
    parser.add_argument('--parent-full', action='store_true', help='also rederive the selected parent contracts')
    parser.add_argument('--report', type=Path, help='write a result outside the sealed release directory')
    args = parser.parse_args()
    need(__debug__ and not sys.flags.optimize, 'do not run the inherited symbolic engine with -O')
    if args.report:
        need(not args.report.resolve().is_relative_to(ROOT), '--report must be outside the sealed release')
    start = time.monotonic()
    count = manifest()
    with tempfile.TemporaryDirectory(prefix='u212-replay-') as temp:
        work = Path(temp).resolve()
        parent = unpack_parent(work)
        native = ROOT / 'machine/u212.native.tm'
        original = parent / 'machine/u213.native.tm'
        command([ROOT / 'code/build_machine.py', original, work / 'machine'])
        for name in ('u212.native.tm', 'u212.tm', 'state_map.json', 'summary.json'):
            need((work / 'machine' / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(), 'build differs: ' + name)
        command([ROOT / 'code/check_local.py', '--parent', original, '--candidate', native, '--output', work / 'local.json'])
        command([ROOT / 'code/check_frames.py', '--parent', original, '--candidate', native, '--output', work / 'frames.json'])
        command([ROOT / 'code/check_paths.py', original, native, '--output', work / 'paths.json'])
        # The two new independent finite checkers use explicit exceptions, not assertions.
        command([ROOT / 'code/check_frames.py', '--parent', original, '--candidate', native, '--output', work / 'frames-opt.json'], optimized=True)
        need(json.loads((work / 'frames.json').read_text()) == json.loads((work / 'frames-opt.json').read_text()), 'finite proof depends on assertions')
        local = json.loads((work / 'local.json').read_text())
        frames = json.loads((work / 'frames.json').read_text())
        paths = json.loads((work / 'paths.json').read_text())
        need(frames['total'] == 6768 and len(paths['semantic_negative_controls']) == 24, 'local proof coverage')
        comparisons = check_comparison(parent)
        saved_cases = check_runtime_receipts(parent)
        parent_args = [parent / 'reproduce.py', '--report', work / 'parent.json']
        if args.parent_full:
            parent_args.append('--full')
        command(parent_args)
        parent_result = json.loads((work / 'parent.json').read_text())
        need(parent_result['status'] == ('U213_FULL_REPLAY_PASS' if args.parent_full else 'U213_FINITE_REPLAY_PASS'), 'parent replay')
        runtime = None
        if args.full:
            print('Re-deriving all 5,084 candidate contracts ...', flush=True)
            command([ROOT / 'code/verify_runtime.py', '--parent', parent, '--candidate', native, '--output', work / 'runtime'])
            need(json.loads((work / 'runtime/runtime_cases.json').read_text()) == saved_cases, 'fresh case records differ')
            runtime = json.loads((work / 'runtime/runtime.json').read_text())
        result = dict(status='U212_FULL_REPLAY_PASS' if args.full else 'U212_FINITE_REPLAY_PASS',
                      manifest_files=count, working_states=212, rows=424,
                      native_sha256=sha(native), dense_sha256=sha(ROOT / 'machine/u212.tm'),
                      local_frame_cases=frames['total'], independent_path_cases=len(paths['cases']),
                      semantic_mutations_rejected=dict(frames=7, paths=24),
                      startup_steps=local['startup']['candidate_steps'],
                      startup_identical_complete_frame=True, comparison=comparisons,
                      candidate_cases_rederived=5084 if args.full else 0,
                      parent_cases_rederived=parent_result['runtime_cases_rederived'],
                      inherited_U214_finite_audit=parent_result['parent']['status'],
                      literal_rows_covered=runtime['literal_rows_covered'] if runtime else None,
                      seconds=round(time.monotonic() - start, 3),
                      scope='Exact finite local proof and PA-formalizable literal halting transfer. Consistency endpoint uses the bundled parent calibration; no newly compiled proof-assistant endpoint.')
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
