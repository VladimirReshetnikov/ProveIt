#!/usr/bin/env python3
"""Independent finite certificate for the U213(1) -> U212 path replacement.

The verifier executes every admissible radius-two configuration. It refuses
to read a cell outside the explicitly provided window. The local checks thus
cover an arbitrary, unchanged exterior; no sampled blank exterior is assumed.
No code from the construction or its original certificate is imported.
"""
import argparse
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path



def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    result = {}
    for line in path.read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        source, symbol, output, direction, destination = line.split()
        source, symbol, output, destination = map(int, (source, symbol, output, destination))
        require(symbol in (0, 1) and output in (0, 1), 'nonbinary row')
        require(direction in ('L', 'R'), 'nonmoving row')
        require((source, symbol) not in result, 'duplicate row')
        result[source, symbol] = (output, -1 if direction == 'L' else 1, destination)
    states = {state for state, _ in result}
    require(set(result) == {(state, symbol) for state in states for symbol in (0, 1)}, 'partial table')
    require({row[2] for row in result.values()} - states == {254}, 'bad terminal labels')
    require(254 not in states, 'halt has outgoing rows')
    return result


def execute(table, state, head, tape, count):
    tape = dict(tape)
    trace = []
    for tick in range(count):
        require(state != 254, 'halt in interior')
        require(head in tape, 'opaque exterior inspected')
        key = (state, tape[head])
        require(key in table, 'missing transition')
        write, move, next_state = table[key]
        trace.append([state, head, tape[head], write, move, next_state])
        tape[head] = write
        state, head = next_state, head + move
    return (state, head, tape), trace


def check_blocks(old, new):
    states = sorted({state for state, _ in new})
    require(112 not in states, 'deleted state still present')
    cases = Counter()
    records = []
    for state in states:
        for bits in itertools.product((0, 1), repeat=5):
            tape = dict(zip(range(-2, 3), bits))
            # This is a checkpoint invariant, not an old raw-state invariant.
            if state == 172 and tape[-1] != 0:
                continue
            if state == 180 and tape[0] == 1:
                if tape[1] == 1:
                    tag, old_length, new_length = 'bypass-one', 2, 2
                elif tape[2] == 0:
                    tag, old_length, new_length = 'bypass-zero-zero', 7, 3
                else:
                    tag, old_length, new_length = 'bypass-zero-one', 7, 3
            elif state == 172 and tape[0] == 0:
                tag, old_length, new_length = 'two-zero-fold', 4, 2
            else:
                tag, old_length, new_length = 'ordinary', 1, 1
            before = (state, bits)
            left, old_trace = execute(old, state, 0, tape, old_length)
            right, new_trace = execute(new, state, 0, tape, new_length)
            require(left == right, f'endpoint mismatch: {before}, {tag}, {left}, {right}')
            finish_state, finish_head, finish_tape = left
            require(finish_state != 112, f'deleted state at checkpoint: {before}')
            if finish_state == 172:
                require(finish_head - 1 in finish_tape, 'cannot establish next invariant')
                require(finish_tape[finish_head - 1] == 0, 'next checkpoint left marker is not zero')
            require(0 < new_length <= old_length and 3 * old_length <= 7 * new_length, 'bad block length')
            cases[tag] += 1
            records.append([state, list(bits), tag, old_trace, new_trace])
    encoded = json.dumps(records, separators=(',', ':')).encode()
    return dict(cases=dict(sorted(cases.items())), total=sum(cases.values()),
                trace_digest=hashlib.sha256(encoded).hexdigest(),
                opaque_exterior_never_inspected=True,
                checkpoint_invariant_preserved=True,
                positive_duration_and_no_internal_halt=True,
                old_new_time_ratio_at_most='7/3')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--parent', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    old, new = load(args.parent), load(args.candidate)
    require(len(old) == 426 and len(new) == 424, 'wrong working-state counts')
    require({key: value for key, value in old.items() if value[2] == 172} ==
            {(116, 0): (0, 1, 172), (180, 1): (1, 1, 172)}, 'old incoming172 mismatch')
    require({key: value for key, value in old.items() if value[2] == 112} ==
            {(172, 0): (0, -1, 112)}, 'old incoming112 mismatch')
    old_states, new_states = {q for q, _ in old}, {q for q, _ in new}
    require(old_states - new_states == {112} and not (new_states - old_states), 'wrong state deletion')
    difference = {key: (old[key], value) for key, value in new.items() if old[key] != value}
    require(difference == {(180, 1): ((1, 1, 172), (1, 1, 211)),
                           (172, 0): ((0, -1, 112), (0, -1, 67))}, 'wrong retained-row patch')
    result = check_blocks(old, new)

    # These controls bypass the exact-patch check above. They are rejected by
    # actual path execution/equality or invariant preservation, not by a hash.
    negative_controls = []
    for key in [(180, 1), (172, 0), (211, 0), (211, 1), (218, 0), (218, 1), (67, 0)]:
        bad = dict(new)
        write, move, target = bad[key]
        bad[key] = (1 - write, move, target)
        try:
            check_blocks(old, bad)
        except (ValueError, KeyError) as error:
            negative_controls.append(dict(row=list(key), mutation='flip write', rejected=True,
                                          reason=str(error)[:300]))
        else:
            raise ValueError(f'semantic negative control accepted: {key}')
    result.update(status='INDEPENDENT_UNIVERSAL_LOCAL_CERTIFICATE_PASS',
                  parent_sha256=hashlib.sha256(args.parent.read_bytes()).hexdigest(),
                  candidate_sha256=hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
                  parent_working_states=len(old) // 2, candidate_working_states=len(new) // 2,
                  tested_negative_controls=negative_controls,
                  scope='Exact finite local certificate; mathematical PA-formalizable simulation; no proof-assistant endpoint.')
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
