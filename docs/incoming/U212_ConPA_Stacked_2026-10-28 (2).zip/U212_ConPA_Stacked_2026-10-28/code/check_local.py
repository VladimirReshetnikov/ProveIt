#!/usr/bin/env python3
"""Exact U213(1) -> U212 bypass stack, including universal local identities.

Every universal path checks only specified cells. Reading an opaque exterior
raises an error, so the checks quantify over arbitrary tape exteriors.
"""
import argparse, hashlib, itertools, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def need(value, message):
    if not value:
        raise ValueError(message)

def table(path):
    answer = {}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q,b,w,d,z = line.split()
        q,b,w,z = map(int,(q,b,w,z))
        need((q,b) not in answer and b in (0,1) and w in (0,1) and d in ('L','R'), 'invalid row')
        answer[q,b] = (w, 1 if d == 'R' else -1, z)
    return answer

def path(T, q, h, cells, steps):
    cells = dict(cells)
    trace = []
    for _ in range(steps):
        need(h in cells, 'path inspected opaque exterior')
        read = cells[h]
        w,d,z = T[q,read]
        trace.append([q,h,read,w,d,z])
        cells[h],q,h = w,z,h+d
    return (q,h,cells), trace

def local(A, C, check_patch=True):
    need([(k,v) for k,v in A.items() if v[2] == 172] == [((116,0),(0,1,172)), ((180,1),(1,1,172))], 'incoming 172 mismatch')
    need([(k,v) for k,v in A.items() if v[2] == 112] == [((172,0),(0,-1,112))], 'incoming 112 mismatch')
    expected = dict(A)
    expected[180,1] = (1,1,211)
    expected[172,0] = (0,-1,67)
    del expected[112,0],expected[112,1]
    if check_patch:
        need(C == expected, 'unexpected table patch')
    cases = [
        ('bypass-one',180,{0:1,1:1},2,2,(184,2)),
        ('bypass-zero-zero',180,{0:1,1:0,2:0},7,3,(90,3)),
        ('bypass-zero-one',180,{0:1,1:0,2:1},7,3,(86,3)),
        ('two-zero-fold',172,{-1:0,0:0},4,2,(151,0)),
    ]
    out = []
    for name,q,cells,na,nc,endpoint in cases:
        a,ta = path(A,q,0,cells,na)
        c,tc = path(C,q,0,cells,nc)
        need(a == c, name + ': endpoints differ')
        need(a == (*endpoint,cells), name + ': wrong endpoint or tape change')
        need(all(x[0] != 254 for x in ta+tc), 'internal halt')
        out.append(dict(name=name,cells=cells,old_trace=ta,new_trace=tc,endpoint=endpoint))
    return out

def startup(A,C):
    # Equal-state checkpoints compressed by the four universal identities.
    q=h=ta=tc=0
    ones=set()
    counts={'bypass-one':0,'bypass-zero':0,'two-zero-fold':0,'ordinary':0}
    digest=hashlib.sha256()
    while ta < 48140:
        read=int(h in ones)
        if q == 180 and read == 1:
            b=int(h+1 in ones)
            na,nc=(2,2) if b else (7,3)
            kind='bypass-one' if b else 'bypass-zero'
        elif q == 172 and read == 0:
            need(h-1 not in ones,'zero-left checkpoint invariant')
            na,nc,kind=4,2,'two-zero-fold'
        else:
            na=nc=1;kind='ordinary'
        need(ta+na <= 48140, 'endpoint is inside a block')
        configurations=[]
        for T,n in ((A,na),(C,nc)):
            q0,h0,tape=q,h,set(ones)
            for _ in range(n):
                b=int(h0 in tape);w,d,z=T[q0,b]
                if w:tape.add(h0)
                else:tape.discard(h0)
                q0,h0=z,h0+d
            configurations.append((q0,h0,tape))
        need(configurations[0]==configurations[1],'blank synchronization failed')
        q,h,ones=configurations[0]
        ta+=na;tc+=nc;counts[kind]+=1
        digest.update(json.dumps([ta,tc,q,h,kind],separators=(',',':')).encode()+b'\n')
    need((q,h)==(84,-2),'wrong final dispatcher')
    # Match the complete parent frame, including exterior zeros.
    registers=[1,0,13,0,0,1,0,0,1]
    permutation=(6,2,0,4,3,7,8,5,1)
    physical=[0]*9
    for i,j in enumerate(permutation):physical[j]=registers[i]
    pc='001100110101010'
    want={-3,54}|{h+i for i,c in enumerate(pc) if c=='1'}
    pos=55
    for n in physical+[1]*43:
        want.update(range(pos+1,pos+n+2));pos+=n+2
    need(ones==want,'whole-tape frame mismatch')
    need(ta-tc==4*counts['bypass-zero']+2*counts['two-zero-fold'],'time identity')
    return dict(parent_steps=ta,candidate_steps=tc,counts=counts,state=q,head=h,
                one_cells=sorted(ones),registers=registers,spares=[1]*43,
                source_ordinal=136,source_address=pc,header=54,
                checkpoint_sha256=digest.hexdigest())

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--parent',type=Path,required=True)
    p.add_argument('--candidate',type=Path,default=ROOT/'machine/u212.native.tm')
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    parent=a.parent;candidate=a.candidate
    A,C=table(parent),table(candidate)
    proofs=local(A,C)
    states={q for q,b in C};need(len(states)==212 and len(C)==424,'state count')
    need(set(C)=={(q,b)for q in states for b in (0,1)},'incomplete table')
    need({v[2]for v in C.values()}-states=={254},'unknown target')
    negatives=0
    for row in [(180,1),(172,0),(211,0),(211,1),(218,0),(218,1),(67,0)]:
        wrong=dict(C);w,d,z=wrong[row];wrong[row]=(1-w,d,z)
        try:local(A,wrong,check_patch=False)
        except (ValueError,KeyError):negatives+=1
        else:raise ValueError('negative control accepted')
    result=dict(status='U212_LOCAL_AND_BLANK_CERTIFICATE_PASS',working_states=212,rows=424,
                parent_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
                candidate_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest(),
                cases=proofs,negative_controls_rejected=negatives,startup=startup(A,C),
                scope='Four universal bounded paths with opaque arbitrary tape exterior; a last-incoming-edge invariant; exact blank startup. Mathematical PA-formalizable transfer; no newly compiled proof-assistant endpoint.')
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('cases','startup')},indent=2))
    print('Blank steps:',result['startup']['candidate_steps'])

if __name__ == '__main__':main()
