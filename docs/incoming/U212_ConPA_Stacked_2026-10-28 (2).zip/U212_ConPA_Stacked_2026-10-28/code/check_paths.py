#!/usr/bin/env python3
"""Independent finite-window checker for the U213(1) to U212 transfer.

The checker discovers the first common local configurations instead of taking
the comparison lengths from a receipt. All cells outside each listed window
are opaque. These finite checks certify universal, bounded local identities.
They do not establish the inherited U213 consistency calibration.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_table(path):
    rows = {}
    starts = []
    for text in Path(path).read_text(encoding='ascii').splitlines():
        if text.startswith('#! start '):
            starts.append(int(text[9:]))
        if not text or text.startswith('#'):
            continue
        q, b, w, direction, z = text.split()
        q, b, w, z = map(int, (q, b, w, z))
        require(q >= 0 and z >= 0 and b in (0, 1) and w in (0, 1)
                and direction in ('L', 'R'), 'invalid transition')
        require((q, b) not in rows, 'duplicate row')
        rows[q, b] = w, (1 if direction == 'R' else -1), z
    require(starts == [0], 'invalid start state declaration')
    states = {q for q, b in rows}
    require(0 in states and 254 not in states, 'start/halt census')
    require(set(rows) == {(q, b) for q in states for b in (0, 1)}, 'partial table')
    require({z for w, d, z in rows.values()} - states == {254}, 'target closure')
    return rows


def histories(table, start, values, bound=12):
    state, head = start, 0
    tape = values.copy()
    result = []
    rows = []
    for step in range(1, bound + 1):
        if state == 254 or head not in tape:
            break
        b = tape[head]
        w, direction, nxt = table[state, b]
        rows.append((state, head, b, w, direction, nxt))
        tape[head] = w
        state, head = nxt, head + direction
        result.append(((state, head, tuple(sorted(tape.items()))), tuple(rows)))
    return result


def discover_blocks(before, after):
    cases = []
    # A 180/read1 checkpoint covers every binary value in the following cells.
    for b, c in itertools.product((0, 1), repeat=2):
        cases.append(('bypass_%d%d' % (b, c), 180, {0: 1, 1: b, 2: c}))
    # A remaining 172 entry always follows 116/read0, which wrote this zero.
    cases.append(('zero_guard', 172, {-1: 0, 0: 0}))
    results = []
    for label, start, cells in cases:
        left = histories(before, start, cells)
        right = histories(after, start, cells)
        matches = []
        for i, (a, atrace) in enumerate(left, 1):
            for j, (b, btrace) in enumerate(right, 1):
                if a == b and a[0] not in (112, 172, 254):
                    matches.append((i + j, i, j, a, atrace, btrace))
        require(matches, 'no common opaque-exterior endpoint in ' + label)
        _, i, j, endpoint, atrace, btrace = min(matches)
        require(endpoint[2] == tuple(sorted(cells.items())), 'tape changed in ' + label)
        require(all(row[0] != 254 for row in atrace + btrace), 'internal halt')
        results.append({'name': label, 'initial_state': start, 'cells': cells,
                        'before_steps': i, 'after_steps': j,
                        'endpoint_state': endpoint[0], 'endpoint_head': endpoint[1],
                        'before_rows': atrace, 'after_rows': btrace})
    return results


def incoming(table, target):
    return sorted((q, b, w, d) for (q, b), (w, d, z) in table.items() if z == target)


def validate_patch(before, after):
    require(len(before) == 426 and len(after) == 424, 'incorrect row counts')
    require(incoming(before, 172) == [(116, 0, 0, 1), (180, 1, 1, 1)],
            'unexpected parent entries into 172')
    require(incoming(before, 112) == [(172, 0, 0, -1)],
            'unexpected parent entry into 112')
    require(incoming(after, 172) == [(116, 0, 0, 1)],
            'candidate 172 entries do not establish left zero')
    require(not incoming(after, 112), 'candidate still enters removed state')
    expected = before.copy()
    expected[180, 1] = (1, 1, 211)
    expected[172, 0] = (0, -1, 67)
    del expected[112, 0], expected[112, 1]
    require(expected == after, 'patch is not the exact two-row deletion')


def semantic_mutations(before, after):
    rejected = []
    # All changes keep the asserted syntactic patch relation intact. Damage to
    # a shared helper is applied identically to both machines; damage to a
    # deleted row is applied to the parent alone. Thus rejection must come
    # from the local tape semantics, not from a table-difference check.
    helpers = [(211, 0), (211, 1), (218, 0), (218, 1), (209, 0),
               (157, 0), (157, 1), (148, 0), (186, 1), (151, 0),
               (112, 0), (112, 1)]
    for key in helpers:
        for mode in ('write', 'move'):
            a, b = before.copy(), after.copy()
            w, d, z = a[key]
            row = (1 - w, d, z) if mode == 'write' else (w, -d, z)
            a[key] = row
            if key in b:
                b[key] = row
            validate_patch(a, b)
            try:
                discover_blocks(a, b)
            except (KeyError, ValueError) as exc:
                rejected.append({'row': list(key), 'mutation': mode,
                                 'patch_relation_preserved': True,
                                 'semantic_rejection': str(exc)})
            else:
                raise ValueError('semantic negative control accepted: %r %s' % (key, mode))
    return rejected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('parent', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    parent, candidate = read_table(args.parent), read_table(args.candidate)
    validate_patch(parent, candidate)
    blocks = discover_blocks(parent, candidate)
    mutations = semantic_mutations(parent, candidate)
    result = {'status': 'PASS', 'parent_sha256': hashlib.sha256(args.parent.read_bytes()).hexdigest(),
              'candidate_sha256': hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
              'checker_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'working_states_before': 213, 'working_states_after': 212,
              'cases': blocks, 'semantic_negative_controls': mutations,
              'entry_guard': 'The only candidate transition to 172 is 116/read0, writing 0 and moving R.',
              'proof_scope': 'All initial binary tapes in state 0; positive local blocks preserve full tape and head.',
              'time_relation': 's <= t <= 7*s/3 for parent time t and candidate time s at common halts.',
              'trust_boundary': 'Independent executable local certificate, not a proof-assistant endpoint or proof of the inherited consistency calibration.'}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'cases': len(blocks),
                      'semantic_negative_controls_rejected': len(mutations),
                      'candidate_sha256': result['candidate_sha256']}, indent=2))


if __name__ == '__main__':
    main()
