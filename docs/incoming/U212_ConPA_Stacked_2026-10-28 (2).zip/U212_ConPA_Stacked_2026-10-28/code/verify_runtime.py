#!/usr/bin/env python3
"""Re-derive all 5,084 universal primitive obligations on the stacked U212."""
import argparse,hashlib,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def need(v,msg):
    if not v:raise ValueError(msg)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--parent',type=Path,required=True)
    parser.add_argument('--candidate',type=Path,default=ROOT/'machine/u212.native.tm')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    parent=args.parent.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    sys.dont_write_bytecode=True
    sys.path.insert(0,str(parent/'code'))
    import symbolic_runtime as s
    import build_table as bt
    import source_language as sl
    need(__debug__,'Python assertions required')
    tm=args.candidate;source=parent/'machine/sites.json'
    T=bt.parse(tm.read_bytes());Q=bt.validate(T,212)
    rows=json.loads(source.read_text());tree=sl.tree(rows)
    need(sl.metrics(tree)=={'dag_nodes':197,'leaf_occurrences':3909,'maximum_depth':42,'maximum_zero_run':6},'source census')
    graph,count=sl.graph_arithmetic(rows);need(graph==sl.graph_intervals(rows)and count==5084,'source CFG')
    mapping={int(k):int(v)for k,v in json.loads((parent/'inputs/legacy_mapping.json').read_text()).items()}
    for q in Q|{254}:mapping.setdefault(q,q+1000)
    need(len({mapping[q]for q in Q|{254}})==len(Q)+1,'naming map')
    L={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in T.items()}
    need(s.HEADER_BASE==56,'header base')
    lemmas,blocks=s.prove_blocks(L);cases=[];used=set();start=time.monotonic()
    for i,site in enumerate(rows):
        for positive in ((False,True)if site[1]=='CD'else(False,)):
            result=s.case(L,lemmas,site,positive)
            used.update(result['rows']);result['rows']=sorted(result['rows']);result.pop('trace')
            cases.append({'site_index':i,'positive':positive,**result})
        if(i+1)%1000==0:print('Proved',len(cases),'cases',flush=True)
    for block in blocks:
        for event in block['trace']:used.add(tuple(event[1][:2]))
    need(len(cases)==5084,'case coverage');need(used==set(L),'literal row coverage')
    result=dict(status='U212_UNIVERSAL_RUNTIME_PASS',working_states=212,rows=424,
                table_sha256=hashlib.sha256(tm.read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                source_primitives=3909,source_subtrees=197,proved_cases=5084,
                literal_rows_covered=len(used),header_base=56,
                symbolic_steps=sum(x['symbolic_steps']for x in cases),
                minimum_duration_constant=min(x['duration'][0]for x in cases),
                seconds=time.monotonic()-start,blocks=blocks,
                scope='All natural primary register values, arbitrary natural gap, arbitrary first spare and finite remaining spare list; unary/list induction. Not a proof-assistant kernel certificate.')
    (out/'runtime_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
    (out/'runtime.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='blocks'},indent=2))

if __name__=='__main__':main()
