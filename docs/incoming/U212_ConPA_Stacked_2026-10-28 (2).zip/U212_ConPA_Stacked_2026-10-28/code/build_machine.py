#!/usr/bin/env python3
"""Build exact U212 from the archived 197-subtree, seven-zero U213 table."""
import argparse,hashlib,json
from pathlib import Path

PARENT_SHA256='bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7'

def need(v,msg):
    if not v:raise ValueError(msg)

def build(parent,out):
    data=parent.read_bytes();need(hashlib.sha256(data).hexdigest()==PARENT_SHA256,'wrong frozen parent')
    rows={}
    for line in data.decode().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need((q,b)not in rows and b in (0,1)and w in (0,1)and d in ('L','R'),'invalid row')
        rows[q,b]=(w,d,z)
    need(rows[180,1]==(1,'R',172)and rows[172,0]==(0,'L',112),'old edited rows')
    need(rows[211,0]==(0,'R',218)and rows[211,1]==(1,'R',184),'fast decoder')
    rows[180,1]=(1,'R',211);rows[172,0]=(0,'L',67)
    del rows[112,0],rows[112,1]
    states=sorted({q for q,b in rows});need(len(states)==212 and len(rows)==424,'count')
    need(set(rows)=={(q,b)for q in states for b in (0,1)},'not total')
    need({z for w,d,z in rows.values()}-set(states)=={254},'unknown destination')
    reached={0};pending=[0]
    while pending:
        q=pending.pop()
        for b in (0,1):
            z=rows[q,b][2]
            if z!=254 and z not in reached:reached.add(z);pending.append(z)
    need(reached==set(states),'unreachable graph state')
    mapping={q:i for i,q in enumerate(states)};mapping[254]=212
    out.mkdir(parents=True,exist_ok=True)
    hashes={}
    for name,mp in [('u212.native.tm',{q:q for q in states+[254]}),('u212.tm',mapping)]:
        text='#! start 0\n'+''.join(f'{mp[q]} {b} {w} {d} {mp[z]}\n'for(q,b),(w,d,z)in sorted(rows.items()))
        (out/name).write_bytes(text.encode('ascii'))
        hashes[name]=hashlib.sha256(text.encode()).hexdigest()
    (out/'state_map.json').write_bytes((json.dumps(mapping,indent=2)+'\n').encode('ascii'))
    result=dict(status='U212_RECONSTRUCTION_PASS',working_states=212,rows=424,
                graph_reachable_working_states=len(reached),start=0,halt_native=254,
                halt_dense=212,blank_symbol=0,tape='one bi-infinite binary tape',
                parent_sha256=PARENT_SHA256,sha256=hashes,
                changed_rows=[{'state':180,'read':1,'old':[1,'R',172],'new':[1,'R',211]},
                              {'state':172,'read':0,'old':[0,'L',112],'new':[0,'L',67]}],
                deleted_states=[112])
    (out/'summary.json').write_bytes((json.dumps(result,indent=2)+'\n').encode('ascii'))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    print(json.dumps(build(a.parent,a.output),indent=2))
