# U212: a 212-state candidate for Con(PA)

The archive contains a complete binary Turing machine with **212 working
states**, **424 transitions**, one two-way infinite tape, blank symbol 0,
initial state 0, and head coordinate 0. Every transition moves L or R.
The initializer is included. The dense halt label is 212 and has no rows.

Read `report.pdf` for the comparison, complete proof, calibration scope,
verification details, further research questions, and full transition table.
Editable sources are `report.tex`, `proofs/*.tex`, and `transition_table.tex`.

## The reduction

Start from `U213_ConPA_2026-10-28 (1).zip`, the supplied 197-subtree source
with the seven-zero origin detector. Rebind the bypass idea from
`u213_from_u214_2026-10-28.zip` to the correct physical decoder, native 211.

| Native row | Parent | Candidate |
| --- | --- | --- |
| 180 / 1 | 1 R 172 | 1 R 211 |
| 172 / 0 | 0 L 112 | 0 L 67 |

Delete both rows of state 112. No state is added, and every other retained
row is unchanged. The source program is byte-for-byte unchanged.

Four explicit local identities and a checkpoint invariant prove, independently
of the theory calibration,

    PA proves Halt(U212, blank) iff Halt(U213_parent, blank).

The ordinary mathematical statement holds from state 0 on every common initial
binary tape. Composing it with the supplied parent's mathematical calibration
gives the intended endpoint:

    PA proves not Halt(U212, blank) iff Con(U) iff Con(PA).

This is a conventional mathematical proof with executable certificates.
There is no new compiled Lean/Rocq/MM0 or exported PA endpoint. The exact
parent archive, including its mathematical dependencies, is retained. This
packet does not prove unconditional nonhalting or absolute minimality.

## Completed verification

- All 5,084 arbitrary-natural primitive contracts freshly derived for U212.
- All 424 literal rows covered; 1,275,761 symbolic inference applications.
- All 6,768 admissible radius-two local frames checked with arbitrary opaque exterior.
- A separate checker discovers the matching path endpoints and rejects 24
  semantic mutations preserving the syntactic patch relation.
- The frame checker rejects seven additional semantic write mutations.
- Exact blank startup: 48,140 steps to the same complete parent frame.
- Selected parent's full replay passed, including its 5,084 contracts and
  the retained U214 finite audit. Older ancestors were not all fully rederived.
- Tables, source counts, and relevant decoder/entry inventories checked for
  all eight supplied U213 proposals. The complete ledger is `comparisons/index.json`.

## Reproduce offline

Use Python 3.10+ on Linux or WSL, standard library only. Keep assertions enabled.
Run from this extracted directory:

```sh
python3 -B reproduce.py --report /tmp/u212-finite.json
python3 -B reproduce.py --full --report /tmp/u212-full.json
python3 -B reproduce.py --full --parent-full --report /tmp/u212-with-parent.json
```

Default replay checks the release manifest, reconstructs the literal tables,
replays the local certificates and complete blank startup, checks comparison
inventories and stored runtime bindings, and runs the parent's finite audit.
`--full` freshly rederives all candidate symbolic contracts; `--parent-full`
also rederives the selected parent's contracts. The first invocation alone
does not rederive all symbolic proofs. No network or solver is needed.

Temporary data are removed. Keep any `--report` output outside this sealed
directory. To rebuild the PDF, use a separate copy and run `pdflatex` twice
on `report.tex`; auxiliary files and changed PDF bytes affect the manifest.

## Exact machine identities

Dense `machine/u212.tm` SHA-256:

    c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e

Native `machine/u212.native.tm` SHA-256:

    386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4

The state map includes native halt 254 mapping to dense halt 212. Each table
line is `state read_bit write_bit direction next_state`.

## Contents and attribution

`machine/` specifies the result; `code/` and `reproduce.py` verify it;
`evidence/` retains completed receipts; `comparisons/` contains all eight
reviewed source/table selections; `inputs/U213_parent.zip` is the exact
selected parent. `research/` records scoped unsuccessful searches for another
state saving. `licenses/` and `references/` retain upstream terms and credit.

Inspection was pinned to ProveIt commit
`6b3145c0bbbf7563bd7bce44c974b4515656a5b0`. New work consists of identifying
the compatible role 211, stacking the two reductions, proving the literal
transfer, and assembling its independent checks and comparison. The earlier
source, detector, bypass idea, arithmetic/compiler framework, and theory
calibration remain attributed to the supplied constructions and their upstreams.
