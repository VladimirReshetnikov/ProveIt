#include <iostream>
#include <fstream>
#include <vector>
#include <array>
#include <map>
#include <set>
#include <sstream>
#include <random>
#include <algorithm>
using namespace std;
struct Trans { int w,d,q; };
struct Conf { int q,h; unsigned long long tape; bool operator==(const Conf &c)const{return q==c.q && h==c.h && tape==c.tape;} };
array<array<Trans,2>,600> tab;
vector<int> states;
map<int,set<pair<int,int>>> guards;
const int lo=-5,hi=8,steps=24;
bool compare(int q,int r,unsigned long long bits,int &maxOld,int &maxNew){
 vector<Conf>a,b; Conf c{q,0,bits};
 for(int i=0;i<steps;i++){
  if(c.q==254||c.h<lo||c.h>hi)break;
  int bit=(c.tape>>(c.h-lo))&1;
  Trans t=tab[c.q][bit];
  c.tape=(c.tape&~(1ull<<(c.h-lo)))|((long long)t.w<<(c.h-lo));
  c.q=t.q;c.h+=t.d;a.push_back(c);
 }
 c={r,0,bits};
 for(int j=0;j<steps;j++){
  if(c.q==254||c.h<lo||c.h>hi)break;
  int bit=(c.tape>>(c.h-lo))&1;
  Trans t=tab[c.q][bit];
  c.tape=(c.tape&~(1ull<<(c.h-lo)))|((long long)t.w<<(c.h-lo));
  c.q=t.q==q?r:t.q;c.h+=t.d;
  for(int i=0;i<(int)a.size();i++)if(c==a[i] && c.q!=q){maxOld=max(maxOld,i+1);maxNew=max(maxNew,j+1);return true;}
 }
 return false;
}
int main(int argc,char**argv){
 if(argc<2)return 1;
 ifstream f(argv[1]);string line;set<int> st;
 while(getline(f,line)){
  if(line.empty()||line[0]=='#')continue;
  istringstream s(line);int q,b,w,z;char d;s>>q>>b>>w>>d>>z;
  tab[q][b]={w,d=='R'?1:-1,z};st.insert(q);
  guards[z].insert({d=='R'?-1:1,w});
 }
 states.assign(st.begin(),st.end());mt19937_64 rng(451622);
 unsigned long long maxmask=1ull<<(hi-lo+1);
 vector<unsigned long long> first{0,maxmask-1};
 for(int i=0;i<200;i++)first.push_back(rng()%maxmask);
 int count=0;
 for(int q:states){
  if(q==0)continue;
  int gp=0,gv=0;
  if(guards[q].size()==1){gp=guards[q].begin()->first;gv=guards[q].begin()->second;}
  for(int r:states){
   if(q==r)continue;
   auto bitsGuard=[&](unsigned long long v){if(gp)v=(v&~(1ull<<(gp-lo)))|((long long)gv<<(gp-lo));return v;};
   int mo=0,mn=0;bool ok=true;
   for(auto bits:first){if(!compare(q,r,bitsGuard(bits),mo,mn)){ok=false;break;}}
   if(!ok)continue;
   for(unsigned long long bits=0;bits<maxmask;bits++){
    if(gp&&int((bits>>(gp-lo))&1)!=gv)continue;
    if(!compare(q,r,bits,mo,mn)){ok=false;break;}
   }
   if(ok){cout<<"fold "<<q<<" -> "<<r<<" guard "<<gp<<"="<<gv<<" maxsteps "<<mo<<","<<mn<<"\n"<<flush;count++;}
  }
 }
 cerr<<"found "<<count<<"\n";
}
