#include <iostream>
#include <fstream>
#include <vector>
#include <array>
#include <map>
#include <set>
#include <sstream>
#include <random>
#include <algorithm>
#include <deque>
using namespace std;
struct Trans { int w,d,q; };
struct Conf { int q,h; unsigned int tape; bool operator==(const Conf &c)const{return q==c.q && h==c.h && tape==c.tape;} };
array<array<Trans,2>,600> tab;
vector<int> states;
int radius=5,steps=30;
bool compare(int q,int r,unsigned int bits,int &maxOld,int &maxNew){
 vector<Conf>a; Conf c{q,0,bits};
 for(int i=0;i<steps;i++){
  if(c.q==254||c.h<-radius||c.h>radius)break;
  int bit=(c.tape>>(c.h+radius))&1;Trans t=tab[c.q][bit];
  c.tape=(c.tape&~(1u<<(c.h+radius)))|(t.w<<(c.h+radius));
  c.q=t.q;c.h+=t.d;a.push_back(c);
 }
 c={r,0,bits};
 for(int j=0;j<steps;j++){
  if(c.q==254||c.h<-radius||c.h>radius)break;
  int bit=(c.tape>>(c.h+radius))&1;Trans t=tab[c.q][bit];
  c.tape=(c.tape&~(1u<<(c.h+radius)))|(t.w<<(c.h+radius));
  c.q=t.q==q?r:t.q;c.h+=t.d;
  for(int i=0;i<(int)a.size();i++)if(c==a[i] && c.q!=q){maxOld=max(maxOld,i+1);maxNew=max(maxNew,j+1);return true;}
 }
 return false;
}
int main(int argc,char**argv){
 if(argc<2)return 1;if(argc>2)radius=stoi(argv[2]);
 ifstream f(argv[1]);string line;set<int> st;
 while(getline(f,line)){
  if(line.empty()||line[0]=='#')continue;
  istringstream s(line);int q,b,w,z;char d;s>>q>>b>>w>>d>>z;
  tab[q][b]={w,d=='R'?1:-1,z};st.insert(q);
 }
 states.assign(st.begin(),st.end());unsigned maxmask=1u<<(2*radius+1),msk=maxmask-1;
 vector<vector<unsigned char>> seen(600,vector<unsigned char>(maxmask,0));
 vector<vector<unsigned>> masks(600);deque<pair<int,unsigned>> todo;
 auto add=[&](int q,unsigned v){if(!seen[q][v]){seen[q][v]=1;masks[q].push_back(v);todo.push_back({q,v});}};
 for(unsigned b=0;b<maxmask;b++)add(0,b);
 long count=0;
 while(!todo.empty()){
  auto[q,b]=todo.front();todo.pop_front();count++;
  if(q==254)continue;
  int read=(b>>radius)&1;Trans t=tab[q][read];
  b=(b&~(1u<<radius))|(t.w<<radius);
  if(t.d==1){b>>=1;add(t.q,b);add(t.q,b|(1u<<(2*radius)));}
  else{b=(b<<1)&msk;add(t.q,b);add(t.q,b|1u);}
 }
 cerr<<"abstract nodes "<<count<<"\n";
 mt19937 rng(19812);
 for(int q:states)shuffle(masks[q].begin(),masks[q].end(),rng);
 int found=0;
 for(int q:states){
  if(q==0||masks[q].empty())continue;
  for(int r:states){
   if(q==r)continue;
   int mo=0,mn=0;bool ok=true;
   for(auto bits:masks[q])if(!compare(q,r,bits,mo,mn)){ok=false;break;}
   if(ok){cout<<"fold "<<q<<" -> "<<r<<" guards "<<masks[q].size()<<" maxsteps "<<mo<<","<<mn<<"\n"<<flush;found++;}
  }
 }
 cerr<<"found "<<found<<"\n";
}
