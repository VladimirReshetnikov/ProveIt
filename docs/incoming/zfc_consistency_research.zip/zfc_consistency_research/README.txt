SMALL MACHINES FOR Con(ZFC)
A quantifier obstruction and a binding-certificate proposal
Research report prepared for Vladimir Reshetnikov, 16 October 2026

START HERE

Read report.pdf (complete article) or edit report.tex. The report examines
the four distinct requested ProveIt commits and newer material through:

  96836f9eea3540e96322c3d28c7127a582aae223
  16 October 2026, 19:51:28 UTC

This is a research proposal with new verified syntax results, an executable
reference checker, and reproducible compiler controls. It does not claim a
new smaller, fully calibrated binary Turing machine.

MAIN RESULTS

1. A checked Lean theorem proves a stronger obstruction to the fixed-slot
   PSC-only compiler lane: interpreting quantifiers as the identity and
   R(i,j) as (i >= 2 and j = 0) validates every PSC matrix instance, even
   with same-variable universal specialization and extensive modal repairs.
   Both primitive Bottom and relative falsity R(0,0) remain false.

2. A constructive complete-calculus proposal makes binding operations
   explicit through finite, locally checked certificates. It supplies
   opening, closing, slot plugging, full classical first-order rules, a
   PSC adapter, an exact binary format, and fair certificate enumeration.
   Separate Lean syntax lemmas establish the binding identities. The
   Python implementation and its future TM compilation are not formally
   verified by those lemmas.

3. A compiler audit shows that only 12 of 24 abstract permutations of the
   retained implicational axiom preserve its destructive-parameter-read
   interface. An unsafe permutation can actually emit a false formula.
   Reproducible controls have 269 and 283 working states. The former is a
   reproduced prior result; neither is a new calibrated state bound.

FILES

  report.tex, report.pdf     Complete report, including 20 primary sources
  formal/                   Two checked Lean developments
  code/                     New binder kernel, binary codec, finite tests
  examples/                 Eight-line valid non-refutation, JSON and bits
  audit_artifacts/           Independent implementation audit and evidence
  machines/                 Attributed prior 253- and raw 248-state tables
  compiler/                 Controls, independent RM certificate, scripts
  results/                  Authoring-time finite results and Lean logs
  provenance/               Commit metadata, archive hashes, source status
  reproduce.py              Offline finite reproduction entry point
  MANIFEST.json             SHA-256 identities for all distributed files
  NOTICE.txt, licenses/      Attribution and preserved license notices

OFFLINE REPRODUCTION

Use Python 3.12 (the tested version), or a compatible Python 3 installation.
Only the standard library is needed. Do not use Python -O.

  python3 reproduce.py

This checks every distributed file hash, reruns the binder semantics and
wire-format tests, reruns the independent mutation audit, independently
checks the included 4,533-pair register-program certificate, and verifies
the complete numeric transition-table conventions. It does not run an
unbounded consistency search, download dependencies, install a compiler,
or claim consistency from a bounded absence of refutations.

An explicit output destination may be supplied:

  python3 reproduce.py --output /tmp/zfc-reproduction.json

To inspect the example proof:

  python3 code/binder_wire.py examples/binding-proof.bits

The expected answer is a valid eight-line derivation of 392 bits, with
accepted_refutation equal to false. The bit file deliberately has no
trailing newline: the codec rejects every unconsumed suffix.

LEAN

The formal files were checked with Lean 4.32.0, commit 8c9756b. A matching
lean-toolchain file is included. With that compiler available:

  lean formal/PSCIdentityObstruction.lean
  lean formal/BinderSyntax.lean

Both checks exited successfully. Principal theorem assumption reports
contain only Lean's standard propext, with no sorry or project-specific
axioms. The authoring-time logs are preserved in results/.

The first file proves a statement about its precisely defined finite-syntax
calculus. The second proves syntax identities and scope properties. Neither
file proves correctness of Python, the binary parser, or a literal TM.

OPTIONAL SOURCE-DEPENDENT COMPARISONS

The fixed-slot obstruction audit evaluates the actual repository emitter:

  python3 reproduce.py --repo /path/to/ProveIt

This requires the exact ProveIt snapshot above and checks the relevant source
hashes before running 100,000 numerical cases for each of the base-three and
base-four codecs. It supplements the infinite Lean proof; it does not replace it.

The original incoming 248-state archive was independently reproduced in full
during authoring. Its 62-file manifest, codec/macro tests, prior PSC checker,
two 3,394-pair RM certificates and exact regenerated tables all passed.
The saved evidence is results/prior248-reproduction.json. To repeat that
separate earlier suite, extract docs/incoming/zfc_small_machines_20261016.zip
from the pinned repository and follow that archive's own instructions.

See compiler/OFFLINE-README.txt and compiler/compiler-audit.txt for the new
compiler controls and their source-dependent regeneration commands. The
included 269-state RM equivalence certificate is independently checkable
without that checkout or compiler.

PDF REBUILD

With a standard TeX Live installation:

  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The report uses standard article/AMS, Latin Modern, microtype, geometry,
booktabs, longtable, enumitem, listings, fancyhdr, xurl and hyperref packages.
Rebuilding the PDF changes its byte identity and therefore the distributed
manifest check. Keep the original archive if immutable reproduction matters.

PROOF STATUS

The exact goal is an internal theorem:

  ZFC proves NH(M) if and only if Con(ZFC).

The report's recommended development program specifies both finite
interfaces: a ZFC refutation produces a halting trace, and a halting trace
produces a ZFC refutation. The inspected upstream 253-state construction
provides published Coq finite-refutation/machine equivalences and successful
CI evidence. A clean local Coq rebuild was not performed here. An explicit
internalization for fixed ZFC proof codes remains a separate deliverable.

The supplied 248-state tables are prior experimental C/G candidates with
logical-calibration and full binary-simulation gaps. The new PSC obstruction
is about a different fixed-slot PSC-only lane and does not disprove the
ordinary equality-free PSC theory's consistency calibration.

All finite tests, state counts, checked theorems, and remaining obligations
are separated in the report. No finite test is offered as evidence of
Con(ZFC), no bounded optimizer run establishes a lower bound, and no
unproved compiler correspondence is inherited by a smaller table.
