# Report 229

Exact third high outdegree sectors in rooted unlabeled trees

5 October 2026. This is a mathematical continuation of Report 227, which is
included unchanged as public source context. It concerns maximum outdegree
exactly k, not maximum undirected degree.

## Main result

For every integer k >= 1 and 0 <= r < k,

    T(3k+r+1,k) = f_(2k+r) - b_(k+r) + U_r + k V_r.

The article gives explicit series U,V, a complete type-deletion proof, an exact
nonnegative root-tail remainder, the first following boundary (-7 for k >= 2,
-6 for k = 1), both missing negative-even-pole cancellations, and independently
controlled all-fixed-order asymptotics. The crossover parameter is k/r^2 and
the errors remain uniform when this ratio is unbounded.

Every fixed order does not mean a convergent infinite asymptotic expansion,
optimal truncation, or a complete exponential transseries. Numerical decimals
are not interval-certified. Full-text priority comparison with Goh–Schmutz
(1994) remains unresolved; this report makes no worldwide first-discovery claim.
The first next boundary is not a full fourth-sector theorem.

## Contents

- report229.tex and Report229.pdf: the standalone mathematical article
- code/: self-contained Python verification code and its documentation
- tests/: exact, guard, numerical, and optional symbolic reference outputs
- build.py: nonmutating check, TeX compilation, and archive builder
- build_checks.json: receipt for the compiled release
- MANIFEST.sha256: checksums of source and reference-output files
- SOURCES.md: attribution, source-access scope, and numerical qualifications
- public227/: our unchanged public Report 227 TeX/PDF; no code is imported from it

No external copyrighted paper PDFs, unpublished supporting notes, or external
source-code dependencies are included. The exact and Decimal computations use
only Python's standard library. The optional symbolic certificate needs SymPy.

## Complete build

Use Python 3.11 or newer and a local TeX Live or equivalent installation with
pdftex, pdflatex, and the packages named by report229.tex. There is no network
step. The builder creates its own TeX format in the output directory and does
not need a user-global cache. It does not change its source package.

From this directory, with a new output directory outside it:

    python3 -B build.py --out ../build229 --optional

The --optional flag requires SymPy and runs the exact symbolic certificate.
Without it, all standard-library exact, guard, and Decimal checks still run;
the receipt labels the symbolic check as not run. It never labels an unavailable
optional check as passed.

The optimized replay command is:

    python3 -B -O build.py --out ../build229-optimized --optional

Both modes are expected to give the same exact fixtures. The builder propagates
optimization to its mathematical subprocesses. Its own manifest, destination,
subprocess, and layout guards also use explicit exceptions, not assertions.
The build output directory must not already exist and must be outside the package.
Individual verification CLIs also refuse to overwrite existing output files or
follow output symlinks; their final write uses exclusive creation. The manifest
must match before any build work starts; symlinks in the source tree or output
ancestry are rejected. Python __pycache__ files are ignored as interpreter
byproducts, but no other extra source files are silently ignored.

The build runs the full N=192, k=64 checks, root-tail remainder tests, literal
small trees, input/guard tests under normal and optimized Python, and Decimal
constants. It compares each fresh JSON file byte-for-byte with its included
fixture. It then compiles three TeX passes and rejects unresolved references,
missing glyphs, and overfull boxes. It writes Report229.pdf, build_checks.json,
and a deterministic Report229.zip to the requested output directory.

Build logs and freshly computed JSON are in that output directory. Suppressed
PDF dates, a fixed epoch and sorted fixed-timestamp ZIP members remove avoidable
nondeterminism. Identical PDF bytes still require a matching TeX toolchain.
The release was rendered and visually inspected as a separate quality check;
TeX warning checks alone cannot prove visual quality.

## Individual checks and resource caps

See code/README.md for exact commands and algorithms. Default required results:

- 1,536 exact strict third-sector cases
- 7,840 all-size deficit coefficients
- 47 next-boundary cases, including k=1
- 287 explicit root-tail remainder coefficient comparisons
- 7,813 literal rooted-tree types and 144 bounded-count comparisons
- 37 rejected API/integrity checks, five valid edge cases, and seven rejected CLI
  calls in each Python optimization mode, plus 12 output-path rejection tests
  per mode (existing files and live/dangling symlinks across all four CLIs),
  three direct exclusive-write checks, and two failed-computation/no-file checks

The main exact cap is N <= 256 and k <= 80. The rooted-count helper allows up to
512; literal trees are capped at size 12; root-tail tests at degree 64; numeric
tails at 480 and Decimal precision at 200 digits. Exact bounds and accepted
lower endpoints are documented in code/README.md. They limit accidental resource
use and remain active under python -O. They do not limit the proved theorems.

## Integrity and interpretation

The manifest excludes only the generated Report229.pdf and build_checks.json
(and the manifest itself); the release build records the generated PDF hash.
It includes the frozen public227 files. Cryptographic hashes identify a version;
they are not signatures or mathematical proofs. Finite tests corroborate the
proofs, and arbitrary precision is not a certified decimal error bound.
