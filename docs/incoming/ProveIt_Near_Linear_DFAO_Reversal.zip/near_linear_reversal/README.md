# Near-linear thresholds and theta limits for binary DFAO reversal

Research article prepared for Vladimir Reshetnikov, 30 September 2026.

## Read the article

`article.pdf` is the typeset article. `article.tex` is self-contained: no
external figures, bibliography database, repository macros, or source
downloads are needed to build it.

The article continues the binary DFAO reversal project in ProveIt, pinned to
commit `781594d886f8dc56069221e2b56bd1e94d9c6e5f`.
The relevant directory is:

```
SetTheory/Cardinals/docs/reports/automata-and-formal-languages/
  dfao-reversal-coloring-obstruction/
```

## Main mathematical contributions

For k >= 4, write B_k(a,b) for the number of proper k-colorings of the
complete bipartite graph K_(a,b), and let (a_n,b_n) be the closest positive
coprime split of n. The paper proves

    R_2(n,k) = k^n - B_k(a_n,b_n) + a_n*b_n

for every n >= T(k), where

    S(k) = ceil(1 + 2*k*log(8*k))
    T(k) = max(4*k^2, 3*S(k)+k+1, 6*(k+2))  for 4 <= k <= 20
    T(k) = 2*S(k)+k                         for k >= 21.

Here log is natural. Thus T(k) = 4*k*log(k) + O(k). A convenient sufficient
condition for all k >= 4 is n >= ceil(16*k*log(8*k)). This improves the
inspected repository's uniform quartic sufficient range, not its already
stronger individual small-output results.

The proof uses a positive complementary-palette envelope, diagonal
amplification, a binomial-tilting estimate, and a paired-label occupancy
construction. In particular, it does not use numerical checks to bridge the
new threshold. The article includes a quantitative nonfull-collision-graph
gap and extends existing extremizer rigidity to the larger range.

Two joint-limit results follow for the actual optimal deficit: a parity
sensitive theta-series limit when n/k^2 tends to a positive constant, and

    D_k(n) ~ 2^k * (k/2)^n * sqrt(k/n)

when k*log(k) = o(n) and n = o(k^2). Discrete and continuous Gaussian laws
also describe palette sizes in uniformly sampled missing reversal states.
Eight further research questions distinguish the remaining dense-output,
threshold, generation, stability, asymptotic, and formalization problems.

## Status and dependencies

This manuscript is unrefereed and has not been checked in Lean or another
proof assistant. It contains proofs of its mathematical assertions, with
one substantive external existence input: Davies's published two-cycle
witness (Theorem 3 and Corollary 3 of arXiv:1705.07150v2).
The coloring reduction and strict balancing already appear in the
repository; they are credited and re-derived, not claimed as new.
The new near-linear bound and joint-limit results are extensions relative
to the inspected sources. Historical priority is not certified by an
exhaustive literature review. The full all-n, all-k<n conjecture is NOT
claimed solved, nor is the diagonal k=n problem.

## Reproduce

Build with a normal TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Run the Python checks (Python 3.11+; standard library only):

```sh
python code/verify.py --full
```

The delivered full run completed 477 structural rows and 167,095 strict
exact-integer comparisons, plus exact counting, literal-coloring,
balancing, and occupancy-subfamily checks. Decimal computations at
65–70 digits provide additional numerical diagnostics, NOT interval
certificates. The theorem's logarithmic ceilings are mathematically defined;
Decimal is used only to display their values.

The first command builds only the document. The second overwrites
`data/verification.json`; it does not change the article or the user's
repository. Remove `--full` to omit the selected threshold structural scans.

## Package contents

- `article.tex`, `article.pdf`: complete article.
- `code/verify.py`: reproducible verification and diagnostics.
- `data/verification.json`: full recorded output, including every structural
  row's minimum strict margin, threshold values, and theta diagnostics.
- `data/console.txt`: the verification run summary.
- `RESEARCH_STATUS.md`: provenance, limitations, and verification audit.

The diagnostic JSON calls its chromatic expression `candidate_deficit_scaled`
and records whether the row lies inside this article's exactness range.
A diagnostic below that range is not a claim of exact optimality there.
