U217: a 217-state reduction of the primary PA consistency candidate
=================================================================
Research prepared for Vladimir Reshetnikov, 28 October 2026.

RESULT
------
An explicit deterministic single-tape binary machine with 217 working
states and 434 transition rows, including blank-tape initialization.
Dense working states: 0 through 216. Separate halt: 217.
Initial state/head: 0/0. Initial tape: all zeros. Moves: L or R only.

The new, source-independent mathematical theorem is

  PA |- Halt(U217, blank) <-> Halt(U218, blank).

Composing it with the supplied U218 correctness and unary-theory
interpretation arguments gives

  PA |- not Halt(U217, blank) <-> Con(U) <-> Con(PA).

This package supplies an ordinary proof formalizable in PA and exact
executable certificates. It does not contain a newly compiled complete
Lean, Rocq, or MM0 consistency-endpoint proof. No absolute minimality,
global record, priority, or unconditional consistency is asserted.

EXACT EDIT
----------
In the parent's native labels, change just

  172 0 0 L 112

to

  172 0 0 L 134

and delete the two rows of state 112. All 433 other retained rows remain
identical. State 112 has no other predecessor. Native halt is 254;
native labels are names, not state counts.

The edit is justified by three exact local whole-tape identities.
At state 172 scanning zero, let b/c be the left/right neighboring bits:

  b=0:        old 2 steps / new 4 steps -> state 157, same head.
  b=1,c=0:    old 6 steps / new 4 steps -> state 90, head two cells right.
  b=1,c=1:    old 6 steps / new 4 steps -> state 86, head two cells right.

Every tape cell is unchanged during each block; no intermediate state
halts. No reachable-tape invariant is required. All other steps agree.
This gives finite-run equivalence from every retained initial state on
every binary tape. At matched halts:

  T217 = T218 + 2*(left-zero blocks) - 2*(left-one blocks),
  (2/3)*T218 <= T217 <= 2*T218.

The source and theory calibration are unchanged. This is not an ordinary
one-step state quotient; the paper includes explicit failed-lockstep
witnesses to explain the need to advance both computations.

START HERE
----------
paper/report.pdf                Full report, proof, and complete table.
paper/report.tex                Main editable LaTeX.
paper/local_proof.tex           Complete local and finite PA transport proof.
paper/transition_table.tex      Complete literal table appendix.
machine/u217.tm                 Complete dense table.
machine/u217.native.tm          Same machine in inherited native names.
machine/state_map.json          Exact two-way relabeling.
machine/sites.json              Unchanged 202-subtree / 3891-occurrence source.
machine/machine_summary.json    Counts, edits, hashes, and representation details.

Each table line is:

  state  read_symbol  write_symbol  direction  next_state

There are two rows per working state and no halt rows.

VERIFIED
--------
* 217 working states, 434 rows, complete binary transition function;
  all working states reachable in the transition graph.
* Exact native/dense bijection and deterministic reconstruction.
* Independent local checks: four complete three-cell frames and
  three sparse contexts covering arbitrary exterior tapes.
* Fourteen rejected mutation-test executions, including coherently
  corrupted helper rows in both tables.
* All 5060 arbitrary-register symbolic primitive cases pass, with
  four exact-table traversal schemas rederived.
* Exact blank initialization: 95726 steps, native dispatcher 84,
  head -8, gap 1, logical registers (4,0,0,0,0,0,0,0,0),
  forty spare registers all equal to 1, and 95 nonzero cells.
* The entire native initialization trace matches U218. The edited
  row is never visited in that prefix.
* Fresh full reproduction of the immutable U218 baseline also passed.

The symbolic cases quantify over arbitrary natural register values and
gap, and arbitrary nonempty finite spare-register lists. They are not
bounded tests of sampled values. The local certificates establish all
finite induction premises of the written proof, rather than trying to
infer infinite behavior from a finite blank-tape run.

REPRODUCE OFFLINE
----------------
Python 3.10 or later, standard library only. No network or solver.
Run from this extracted directory:

  python3 -B reproduce.py
  python3 -B reproduce.py --full
  python3 -B reproduce.py --full --baseline-full

The default checks release hashes, exact construction, local proofs,
controls, complete startup, and saved runtime bindings/coverage.
--full rederives all 5060 symbolic cases and compares every record.
--baseline-full also reruns the parent's complete full reproduction.
The full candidate replay takes several minutes; actual time varies.

To write an additional receipt without changing the release:

  python3 -B reproduce.py --full --report /some/external/path/result.json

Work files are temporary. Do not place that output inside the release
directory unless intentionally regenerating its manifest. Use enabled
Python assertions: -O and PYTHONOPTIMIZE are rejected.

The portable discovery search is separate from acceptance verification:

  python3 -B research/search_reduction.py
  python3 -B research/search_reduction.py --table machine/u217.native.tm

Its finite limits do not establish state-count optimality. The final
three-case proof does not depend on its reachability approximation.

To regenerate the table appendix and compile the paper:

  python3 -B code/build_paper_data.py
  cd paper
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

PDF metadata can vary with the TeX installation. Rebuilding or editing
release files changes SHA256SUMS; retain an untouched extraction for
exact-byte verification.

PROVENANCE AND DEPENDENCIES
--------------------------
All incoming GitHub inputs were retrieved at ProveIt commit:

  1dd14d95976856bfabe06ab7294e78508556e0d1

The exact supplied U218 archive is retained in inputs/. It includes the
U222 parent, runtime proof code, theory report, logical proof artifacts,
source data, and original notices. The new machine has exactly the same
source bytes as the parent. New research notes discuss source variants
and K215 ideas that did not yield another accepted reduction.

The complete mathematical endpoint still inherits the supplied U218,
U222, and theory-U proof arguments. The existing K215/ZFC theorem is
not asserted to certify the changed machine automatically.
The independent checkers here were written separately within the same
assistant research collaboration, not by external human reviewers.

SHA-256 IDENTITIES
-----------------
U217 native:
fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f

U217 dense:
639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6

Unchanged source:
bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f

Original U218 archive:
73c7d0774d955c9b003eec0e9e0876e280f028f653a127c7518d132b914c8bc9

SHA256SUMS covers every release file other than itself.
