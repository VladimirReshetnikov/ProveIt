#!/usr/bin/env python3
"""Concrete local witnesses refuting the tempting one-step quotient proof.

The actual U217 machine is valid. The rejected assertion is specifically
that the state map 112 -> 134 commutes with every old step from a common initial configuration.
Both witnesses start in retained state 172 with a zero under the head.
"""
from pathlib import Path
import argparse
import json

from check_local_blocks import read_table


def step(table, state, head, ones):
    tape = set(ones)
    w, d, z = table[state, int(head in tape)]
    if w:
        tape.add(head)
    else:
        tape.discard(head)
    return z, head + d, tape


def records(table, ones, ticks):
    q, h, tape = 172, 0, set(ones)
    out = [{'time': 0, 'state': q, 'head': h, 'ones': sorted(tape)}]
    for tick in range(1, ticks + 1):
        q, h, tape = step(table, q, h, tape)
        out.append({'time': tick, 'state': q, 'head': h, 'ones': sorted(tape)})
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old', type=Path)
    parser.add_argument('new', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    old, _ = read_table(args.old)
    new, _ = read_table(args.new)
    cases = []
    for ones in ([], [-1]):
        before = records(old, ones, 2)
        after = records(new, ones, 2)
        f = lambda q: 134 if q == 112 else q
        assert f(before[1]['state']) == after[1]['state']
        assert before[1]['head'] == after[1]['head']
        assert before[1]['ones'] == after[1]['ones']
        assert f(before[2]['state']) != after[2]['state']
        cases.append({
            'initial_state': 172, 'initial_head': 0,
            'initial_ones': ones, 'all_other_cells': 0,
            'old_trace': before, 'new_trace': after,
            'assertion_rejected': 'The projection 112 -> 134 is a one-step quotient.',
            'first_mismatch_time': 2,
            'projected_old_state': f(before[2]['state']),
            'new_state': after[2]['state'],
        })
    result = {
        'status': 'LOCKSTEP_PROJECTION_REJECTED_BY_CONCRETE_TAPES',
        'scope': 'These refute an incorrect proof method, not the U217 construction.',
        'cases': cases,
    }
    text = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(text, encoding='ascii')
    print(text, end='')


if __name__ == '__main__':
    main()
