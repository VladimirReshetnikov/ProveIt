#!/usr/bin/env python3
"""Independent exact local certificate for deleting native state 112.

This checker imports no source compiler, simulator, parent certificate, or
window-search result. It parses the two literal tables and exhausts the four
possible tapes on the three cells read by the replacement blocks. The
exterior tape is opaque and cannot be read or changed by the interpreter.

The certificate covers every binary tape and every initial control state
other than 112, with the same tape and head at each block boundary. It is a
finite mathematical certificate; it is not a proof-assistant kernel proof.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_table(path):
    table = {}
    starts = []
    for line in path.read_text(encoding='ascii').splitlines():
        if line.startswith('#! start'):
            require(line == '#! start 0', 'incorrect initial-state header')
            starts.append(0)
            continue
        if not line.strip() or line.startswith('#'):
            continue
        fields = line.split()
        require(len(fields) == 5, 'incorrect transition-field count')
        q, b, w, direction, z = fields
        q, b, w, z = map(int, (q, b, w, z))
        require(q >= 0 and z >= 0, 'negative control-state label')
        require(b in (0, 1) and w in (0, 1), 'nonbinary symbol')
        require(direction in ('L', 'R'), 'nonmoving action')
        require((q, b) not in table, 'duplicate transition')
        table[q, b] = w, (-1 if direction == 'L' else 1), z
    require(starts == [0], 'exactly one initial-state header required')
    states = {q for q, b in table}
    require(0 in states and 254 not in states, 'invalid start/halt labels')
    require(set(table) == {(q, b) for q in states for b in (0, 1)},
            'table must be total on both symbols')
    require({z for w, d, z in table.values()} - states == {254},
            'exactly the native halt label must be undefined')
    return table, states


def local_run(table, steps, tape):
    """Run from 172, head 0, refusing every unknown exterior access."""
    q, h, t = 172, 0, dict(tape)
    trace = []
    for tick in range(steps):
        require(q != 254, 'internal halt in a replacement block')
        require(h in t, ('opaque exterior read', q, h, tick))
        b = t[h]
        w, d, z = table[q, b]
        trace.append({'state': q, 'head': h, 'read': b,
                      'write': w, 'direction': d, 'target': z})
        t[h] = w
        h, q = h + d, z
    require(q != 254, 'unexpected halting block endpoint')
    return q, h, t, trace


def check_tables(old, old_states, new, new_states):
    require(len(old_states) == 218 and len(new_states) == 217,
            'wrong working-state counts')
    require(new_states == old_states - {112}, 'wrong deleted state')
    incoming = sorted((q, b, w, d, z)
                      for (q, b), (w, d, z) in old.items() if z == 112)
    require(incoming == [(172, 0, 0, -1, 112)],
            ('unexpected predecessor of deleted state', incoming))
    expected = {key: action for key, action in old.items() if key[0] != 112}
    expected[172, 0] = 0, -1, 134
    require(new == expected, 'candidate differs from the exact one-row edit')

    cases = []
    for left, right in itertools.product((0, 1), repeat=2):
        tape = {-1: left, 0: 0, 1: right}
        old_steps = 2 if left == 0 else 6
        oq, oh, ot, old_trace = local_run(old, old_steps, tape)
        nq, nh, nt, new_trace = local_run(new, 4, tape)
        require((oq, oh, ot) == (nq, nh, nt),
                ('block endpoints differ', left, right))
        require(oq != 112, 'deleted state remains a boundary state')
        require(ot == tape and nt == tape, 'replacement block changed the tape')
        cases.append({'left': left, 'current': 0, 'right': right,
                      'old_steps': old_steps, 'new_steps': 4,
                      'endpoint_state': oq, 'endpoint_head': oh,
                      'whole_tape_unchanged': True,
                      'old_trace': old_trace, 'new_trace': new_trace})

    ordinary = 0
    for q in sorted(new_states):
        for b in (0, 1):
            if (q, b) == (172, 0):
                continue
            require(old[q, b] == new[q, b], 'ordinary transition differs')
            require(old[q, b][2] != 112, 'ordinary transition enters deleted state')
            ordinary += 1
    require(ordinary == 433, 'wrong ordinary-transition count')
    return {
        'status': 'EXACT_LOCAL_BLOCK_BISIMULATION_PASS',
        'old_working_states': 218,
        'new_working_states': 217,
        'deleted_state': 112,
        'edited_retained_row': {
            'state': 172, 'read': 0,
            'old': [0, -1, 112], 'new': [0, -1, 134]},
        'unchanged_retained_transitions': ordinary,
        'deleted_state_predecessors': incoming,
        'local_cells': [-1, 0, 1],
        'local_case_count': len(cases),
        'cases': cases,
        'initial_configurations': 'EVERY_BINARY_TAPE_AND_HEAD_IN_EVERY_RETAINED_WORKING_STATE_OR_HALT',
        'boundary_relation': 'identical state, head, and whole tape; state is not 112',
        'block_lengths': [[1, 1], [2, 4], [6, 4]],
        'halt_preservation': 'No special block halts internally; ordinary halt transitions agree.',
        'halting_time_bounds': 'At paired halting times n(old), m(new): 2*n <= 3*m and m <= 2*n.',
        'argument': 'Totalize both steps at halt and use block (1,1) there. '
                    'Primitive recursion constructs common boundaries C_i and '
                    'cumulative counters u_i,v_i, with both counters at least i. '
                    'For a first old halt at n, bounded minimization finds the '
                    'least j<=n with u_j>=n. Absence of internal halts forces '
                    'u_j=n; the paired new first halt is v_j<=2*n. Conversely '
                    'a first new halt at m gives j<=m with v_j=m and old first '
                    'halt u_j satisfying 2*u_j<=3*m. This finite construction '
                    'and its induction are formalizable in PA.',
        'constant_optimality_scope': 'The ratios 2/3 and 2 are attained by individual '
                    'matched blocks. No global optimality claim for first-halting '
                    'time ratios is made. At positive first halts, m<=2*n-1 and '
                    '3*m>=2*n+1 also hold.',
        'kernel_certificate': False,
    }


def check(old_path, new_path):
    old, old_states = read_table(old_path)
    new, new_states = read_table(new_path)
    result = check_tables(old, old_states, new, new_states)
    result['old_sha256'] = hashlib.sha256(old_path.read_bytes()).hexdigest()
    result['new_sha256'] = hashlib.sha256(new_path.read_bytes()).hexdigest()
    return result


def mutation_controls(old_path, new_path):
    old, old_states = read_table(old_path)
    new, new_states = read_table(new_path)
    results = []

    def rejected(name, before, after):
        try:
            check_tables(before, old_states, after, new_states)
        except ValueError as error:
            results.append({'name': name, 'status': 'REJECTED', 'reason': str(error)})
            return
        raise ValueError('mutation control accepted: ' + name)

    bad = dict(new)
    bad[172, 0] = 0, -1, 133
    rejected('wrong_replacement_target', old, bad)
    bad = dict(new)
    bad[172, 0] = 1, -1, 134
    rejected('wrong_replacement_write', old, bad)
    bad = dict(new)
    bad[172, 0] = 0, 1, 134
    rejected('wrong_replacement_direction', old, bad)
    before = dict(old)
    after = dict(new)
    before[0, 1] = after[0, 1] = 1, 1, 112
    rejected('extra_predecessor_of_deleted_state', before, after)
    before = dict(old)
    after = dict(new)
    before[134, 0] = after[134, 0] = 0, 1, 90
    rejected('coherently_corrupted_helper_row', before, after)
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old', type=Path)
    parser.add_argument('new', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = check(args.old, args.new)
    result['mutation_controls'] = mutation_controls(args.old, args.new)
    text = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(text, encoding='ascii')
    print(text, end='')


if __name__ == '__main__':
    main()
