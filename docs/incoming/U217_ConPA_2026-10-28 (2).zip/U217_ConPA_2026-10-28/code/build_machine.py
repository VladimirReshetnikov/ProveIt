#!/usr/bin/env python3
"""Deterministic, solver-free reconstruction of the 217-state machine."""
import argparse
import hashlib
import json
from pathlib import Path

from check_local_blocks import read_table, require

BASELINE_SHA256 = "366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30"
NATIVE_SHA256 = "fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f"
DENSE_SHA256 = "639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6"
SOURCE_SHA256 = "bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f"
ARCHIVE_SHA256 = "73c7d0774d955c9b003eec0e9e0876e280f028f653a127c7518d132b914c8bc9"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def encode(table):
    lines = ["#! start 0"]
    for (q, b), (w, d, z) in sorted(table.items()):
        direction = "R" if d == 1 else "L"
        lines.append(f"{q} {b} {w} {direction} {z}")
    return ("\n".join(lines) + "\n").encode("ascii")


def source_census(path):
    require(digest(path) == SOURCE_SHA256, "unexpected source bytes")
    sites = json.loads(path.read_text())
    trie = {}
    for pc, op, arg in sites:
        node = trie
        for bit in pc:
            require(bit in "01", "invalid source address")
            node = node.setdefault(bit, {})
        require("leaf" not in node, "duplicate source address")
        node["leaf"] = (op, arg)
    identifiers = {}

    def visit(node):
        if "leaf" in node:
            require(set(node) == {"leaf"}, "leaf/prefix collision")
            key = ("leaf", *node["leaf"])
        else:
            require(set(node) == {"0", "1"}, "incomplete source tree")
            key = ("branch", visit(node["0"]), visit(node["1"]))
        return identifiers.setdefault(key, len(identifiers))

    visit(trie)
    operations = {}
    for _, op, _ in sites:
        operations[op] = operations.get(op, 0) + 1
    require(len(sites) == 3891 and len(identifiers) == 202, "wrong source census")
    require(operations.get("CD") == 1169, "wrong decrement census")
    return {
        "occurrences": len(sites),
        "distinct_subtrees": len(identifiers),
        "operations": operations,
        "symbolic_cases": len(sites) + operations["CD"],
    }


def build(baseline, source, destination):
    require(digest(baseline) == BASELINE_SHA256, "wrong U218 input")
    old, states = read_table(baseline)
    require(len(states) == 218, "wrong baseline state count")
    incoming = [(q, b, *action) for (q, b), action in old.items() if action[2] == 112]
    require(incoming == [(172, 0, 0, -1, 112)], "unexpected deleted-state predecessor")
    new = {key: value for key, value in old.items() if key[0] != 112}
    new[172, 0] = (0, -1, 134)
    require(len(new) == 434, "wrong new transition count")
    retained = sorted({q for q, b in new})
    require(len(retained) == 217 and 0 in retained and 254 not in retained,
            "incorrect retained labels")
    require({z for w, d, z in new.values()} - set(retained) == {254},
            "dangling working target")
    native = encode(new)
    require(hashlib.sha256(native).hexdigest() == NATIVE_SHA256,
            "native reconstruction hash differs")
    rename = {q: i for i, q in enumerate(retained)}
    rename[254] = 217
    inverse = {v: k for k, v in rename.items()}
    dense = {(rename[q], b): (w, d, rename[z])
             for (q, b), (w, d, z) in new.items()}
    require({(inverse[q], b): (w, d, inverse[z])
             for (q, b), (w, d, z) in dense.items()} == new,
            "relabeling is not a table isomorphism")
    require(set(dense) == {(q, b) for q in range(217) for b in (0, 1)},
            "dense labels are not consecutive")
    dense_bytes = encode(dense)
    require(hashlib.sha256(dense_bytes).hexdigest() == DENSE_SHA256,
            "dense reconstruction hash differs")
    seen, pending = {0}, [0]
    while pending:
        q = pending.pop()
        if q == 254:
            continue
        for bit in (0, 1):
            z = new[q, bit][2]
            if z not in seen:
                seen.add(z)
                pending.append(z)
    require(seen == set(retained) | {254}, "graph-reachability census differs")
    census = source_census(source)
    mapping = {"native_to_dense": rename, "dense_to_native": inverse}
    summary = {
        "status": "EXACT_U217_CONSTRUCTION_AND_BIJECTION_PASS",
        "working_states": 217, "binary_transitions": 434,
        "unchanged_retained_rows": 433,
        "graph_reachable_working_states": 217,
        "alphabet": [0, 1], "tapes": 1, "heads": 1,
        "moves": ["L", "R"], "blank_symbol": 0, "initial_state": 0,
        "native_halt": 254, "dense_halt": 217,
        "deleted_native_state": 112,
        "edited_native_row": {
            "key": [172, 0], "before": [0, -1, 112], "after": [0, -1, 134]},
        "old_native_sha256": BASELINE_SHA256,
        "native_sha256": NATIVE_SHA256, "dense_sha256": DENSE_SHA256,
        "source_sha256": SOURCE_SHA256, "source": census,
        "special_native_to_dense": {
            str(q): rename[q] for q in (0, 84, 134, 157, 172, 182, 209, 218, 254)},
    }
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "u217.native.tm").write_bytes(native)
    (destination / "u217.tm").write_bytes(dense_bytes)
    (destination / "sites.json").write_bytes(source.read_bytes())
    for name, value in (("state_map.json", mapping), ("machine_summary.json", summary)):
        (destination / name).write_text(json.dumps(value, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.baseline, args.source, args.output), indent=2))
