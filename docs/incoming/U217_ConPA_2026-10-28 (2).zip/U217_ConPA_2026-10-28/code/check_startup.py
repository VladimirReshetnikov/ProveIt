#!/usr/bin/env python3
"""Literal replay of the complete unchanged blank initialization."""
import argparse
import hashlib
import json
from pathlib import Path

from check_local_blocks import read_table, require


def replay(table, record):
    require(record["steps"] == len(record["trace"]) == 95726, "wrong trace length")
    q, head, ones = 0, 0, set()
    edited_visits = 0
    for expected in record["trace"]:
        require(q != 254, "premature blank-start halt")
        bit = int(head in ones)
        if (q, bit) == (172, 0):
            edited_visits += 1
        write, move, target = table[q, bit]
        require(expected == [q, head, bit, write, move, target],
                ("literal startup trace mismatch", expected))
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head += move
        q = target
    require(q == record["state"] == 84 and head == record["head"] == -8,
            "wrong startup control or head")
    require(sorted(ones) == record["one_cells"] and len(ones) == 95,
            "whole-tape startup mismatch")
    require(edited_visits == 0, "edited transition was used during startup")
    # Independently decode the complete block representation, including spare registers.
    require(min(ones) == head - 1, "left frame marker differs")
    rights = sorted(x for x in ones if x > head - 1)
    require(rights and rights[0] == head + 65, "root or register-header frame differs")
    position, last = rights[0] + 1, max(ones)
    values = []
    while position <= last:
        require(position not in ones and position + 1 in ones, "bad register separator")
        position += 1
        count = 0
        while position in ones:
            position += 1
            count += 1
        values.append(count - 1)
    physical_order = (6, 2, 0, 4, 3, 7, 8, 5, 1)
    registers = [values[j] for j in physical_order]
    require(registers == record["registers"] == [4, 0, 0, 0, 0, 0, 0, 0, 0],
            "wrong logical initialization")
    require(values[9:] == record["spares"] == [1] * 40, "wrong spare-register tail")
    require(record["gap"] == 1, "wrong gap")
    return {
        "steps": len(record["trace"]), "native_state": q, "head": head,
        "gap": 1, "logical_registers": registers,
        "spares": values[9:], "nonzero_cells": len(ones),
        "edited_row_visits": edited_visits,
        "all_unspecified_cells_zero": True,
    }


def check(old_path, new_path, old_startup, new_startup):
    old, _ = read_table(old_path)
    new, _ = read_table(new_path)
    before, after = json.loads(old_startup.read_text()), json.loads(new_startup.read_text())
    require(before == after, "entire initialization records differ")
    a, b = replay(old, before), replay(new, after)
    require(a == b, "replayed startup endpoints differ")
    return {
        "status": "IDENTICAL_COMPLETE_LITERAL_INITIALIZATION_PASS",
        "old_sha256": hashlib.sha256(old_path.read_bytes()).hexdigest(),
        "new_sha256": hashlib.sha256(new_path.read_bytes()).hexdigest(),
        "startup_record_sha256": hashlib.sha256(new_startup.read_bytes()).hexdigest(),
        "entire_native_trace_identical": True,
        **b,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("old", "new", "old_startup", "new_startup"):
        parser.add_argument(name, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.old, args.new, args.old_startup, args.new_startup)
    output = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(output)
    print(output, end="")
