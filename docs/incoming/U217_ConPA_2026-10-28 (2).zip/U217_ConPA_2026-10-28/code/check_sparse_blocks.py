#!/usr/bin/env python3
"""Independent two-table all-tape macro-equivalence premises for U217.

This checker imports no synthesis, source, runtime, or other checkers.
Its three sparse tape contexts stand for every possible exterior tape.
"""
import argparse
import hashlib
import json
from pathlib import Path


def need(condition, message):
    if not condition:
        raise ValueError(message)


def parse(path):
    t = {}
    for line in path.read_text().splitlines():
        if line and not line.startswith('#'):
            q,b,w,d,z = line.split()
            q,b,w,z = map(int,(q,b,w,z))
            need((q,b) not in t, 'duplicate row')
            need(b in (0,1) and w in (0,1) and d in ('L','R'), 'invalid row')
            t[q,b]=(w,-1 if d=='L' else 1,z)
    s={q for q,b in t}
    need(set(t)=={(q,b) for q in s for b in (0,1)}, 'incomplete binary table')
    need({z for w,d,z in t.values()}-s=={254}, 'unexpected halt')
    return t


def run(t,ctx,n):
    q,h,tape,trace=172,0,dict(ctx),[]
    for step in range(n):
        need(q!=254, 'interior halt')
        need(h in tape, 'unprovided exterior cell inspected')
        b=tape[h]
        need((q,b) in t, 'missing transition')
        w,d,z=t[q,b]
        trace.append([q,h,b,w,d,z])
        need(step==0 or (q,b)!=(172,0), 'modified row inside macro')
        tape[h]=w; h+=d; q=z
    need(q!=254, 'unexpected macro halt')
    need(q!=112, 'macro ends at omitted state')
    return (q,h,tape),trace


def audit(old,new):
    oldstates={q for q,b in old};newstates={q for q,b in new}
    need(len(oldstates)==218 and len(newstates)==217, 'wrong state counts')
    need(newstates==oldstates-{112}, 'wrong deleted state')
    need(0 in newstates and 172 in newstates, 'start/entry absent')
    need([k for k,v in old.items() if v[2]==112]==[(172,0)],
         'omitted state has another incoming edge')
    need(old[172,0]==(0,-1,112), 'wrong old incoming action')
    need(new[172,0]==(0,-1,134), 'wrong new incoming action')
    need(all(new[k]==old[k] for k in new if k!=(172,0)),
         'unexpected retained row edit')
    records=[]
    # Left-zero context does not constrain or inspect the right neighbor.
    cases=[({-1:0,0:0},2),({-1:1,0:0,1:0},6),({-1:1,0:0,1:1},6)]
    for ctx,nold in cases:
        a,ta=run(old,ctx,nold);b,tb=run(new,ctx,4)
        need(a==b, 'unequal whole-tape endpoints')
        need(a[2]==ctx, 'input neighborhood not restored')
        records.append({'context':ctx,'old_steps':nold,'new_steps':4,
                        'old_trace':ta,'new_trace':tb,'endpoint':a})
    return records


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('baseline',type=Path)
    ap.add_argument('candidate',type=Path)
    ap.add_argument('--out',type=Path,default=Path(__file__).parent/'u217_independent.json')
    args=ap.parse_args()
    old,new=parse(args.baseline),parse(args.candidate)
    records=audit(old,new)
    controls=[]
    # These mutations consistently alter both tables where appropriate;
    # rejecting them tests the local joins, not just byte-delta checking.
    for label,key,action,both in [
        ('wrong_target',(172,0),(0,-1,18),False),
        ('wrong_write',(172,0),(1,-1,134),False),
        ('wrong_move',(172,0),(0,1,134),False),
        ('bad_tag_return',(182,0),(0,-1,133),True),
        ('bad_zero_provider',(134,0),(0,1,150),True),
        ('bad_one_provider',(134,1),(1,1,174),True),
        ('bad_right_zero',(218,0),(0,1,86),True),
        ('bad_right_one',(218,1),(1,1,90),True),
        ('extra_deleted_incoming',(0,0),(1,1,112),True),
    ]:
        a,b=dict(old),dict(new)
        if both:a[key]=action
        b[key]=action
        try:
            audit(a,b)
        except ValueError as exc:
            controls.append({'name':label,'status':'REJECT','reason':str(exc)})
        else:
            raise ValueError(f'negative control accepted: {label}')
    result={'status':'PASS','baseline_sha256':hashlib.sha256(args.baseline.read_bytes()).hexdigest(),
            'candidate_sha256':hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
            'working_states':217,'local_macro_cases':records,'negative_controls':controls,
            'guard_scope':'No reachability invariant: all tapes at state172 reading0.',
            'unlisted_rows_exact':True,'unique_incoming_to_112':True,
            'clock_formula':'T_new=T_old+2*N_left0-2*N_left1',
            'halting_clock_bounds':'(2/3)*T_old <= T_new <= 2*T_old',
            'proof_status':'Finite premises for the written ordinary induction proof, not a kernel-checked theorem.'}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='local_macro_cases'},indent=2))


if __name__=='__main__':main()
