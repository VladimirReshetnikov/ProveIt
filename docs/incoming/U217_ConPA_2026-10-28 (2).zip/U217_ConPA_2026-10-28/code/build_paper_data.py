#!/usr/bin/env python3
"""Regenerate the complete dense table appendix from its pinned literal bytes."""
import hashlib
import json
from pathlib import Path

from build_machine import DENSE_SHA256
from check_local_blocks import require

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "machine/u217.tm"
require(hashlib.sha256(path.read_bytes()).hexdigest() == DENSE_SHA256,
        "wrong dense machine")
table = {}
for line in path.read_text().splitlines():
    if not line or line.startswith("#"):
        continue
    q, b, w, d, z = line.split()
    table[int(q), int(b)] = f"{w}{d}{z}"
mapping = json.loads((ROOT / "machine/state_map.json").read_text())["dense_to_native"]
lines = [
    r"{\small",
    r"\setlength{\tabcolsep}{5pt}",
    r"\begin{longtable}{@{}rrcc@{\hspace{1.4em}}rrcc@{}}",
    r"\toprule",
    r"Dense & Native & Read 0 & Read 1 & Dense & Native & Read 0 & Read 1\\",
    r"\midrule\endfirsthead",
    r"\toprule",
    r"Dense & Native & Read 0 & Read 1 & Dense & Native & Read 0 & Read 1\\",
    r"\midrule\endhead",
    r"\midrule\multicolumn{8}{r}{\small Continued on next page}\\\endfoot",
    r"\bottomrule\endlastfoot",
]


def cells(q):
    if q >= 217:
        return ["", "", "", ""]
    return [str(q), str(mapping[str(q)]),
            r"\texttt{" + table[q, 0] + "}", r"\texttt{" + table[q, 1] + "}"]


for q in range(109):
    lines.append(" & ".join(cells(q) + cells(q + 109)) + r"\\")
lines += [r"\end{longtable}", "}"]
(ROOT / "paper/transition_table.tex").write_text("\n".join(lines) + "\n")
print("Generated all 217 states / 434 transitions.")
