#!/usr/bin/env python3
"""Reconstruct U217 and replay its exact local and initialization certificates.

--full also rederives all arbitrary-register runtime cases.
--baseline-full reruns the immutable U218 parent's full reproduction.
No network or solver is used. Work files are temporary; --report is optional.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "code"))
from build_machine import (ARCHIVE_SHA256, BASELINE_SHA256, DENSE_SHA256,
                           NATIVE_SHA256, SOURCE_SHA256, build, digest)
from check_local_blocks import check, mutation_controls, require
from check_startup import check as startup_check


def load(path):
    return json.loads(path.read_text())


def manifest_check():
    manifest = ROOT / "SHA256SUMS"
    require(manifest.is_file(), "release manifest missing")
    names = set()
    for line in manifest.read_text().splitlines():
        wanted, name = line.split("  ", 1)
        rel = PurePosixPath(name)
        require(not rel.is_absolute() and ".." not in rel.parts and "\\" not in name,
                "unsafe manifest path")
        require(name not in names, "duplicate manifest path")
        names.add(name)
        require(digest(ROOT / name) == wanted, "manifest mismatch: " + name)
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*")
              if p.is_file() and p.name != "SHA256SUMS"
              and "__pycache__" not in p.parts and p.suffix != ".pyc"}
    require(names == actual, "manifest does not cover exactly the release files")
    return {"status": "PASS", "files_checked": len(names)}


def extract(archive, destination, expected_root):
    seen = set()
    with zipfile.ZipFile(archive) as handle:
        for info in handle.infolist():
            name = info.filename
            rel = PurePosixPath(name)
            require(rel.parts and not rel.is_absolute() and ".." not in rel.parts,
                    "unsafe archive path")
            require("\\" not in name and rel.parts[0] == expected_root,
                    "unexpected archive root or separator")
            require(name not in seen, "duplicate archive member")
            seen.add(name)
            require(not stat.S_ISLNK((info.external_attr >> 16) & 0xffff),
                    "archive symlink rejected")
            target = destination.joinpath(*rel.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with handle.open(info) as source, target.open("wb") as output:
                while True:
                    part = source.read(1048576)
                    if not part:
                        break
                    output.write(part)
    return destination / expected_root


def command(script, arguments, cwd, title):
    print(title + " ...", flush=True)
    environment = dict(os.environ)
    environment.pop("PYTHONOPTIMIZE", None)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [sys.executable, "-B", str(script), *map(str, arguments)],
        cwd=cwd, env=environment, text=True, capture_output=True)
    require(result.returncode == 0,
            title + " failed:\n" + result.stdout[-7000:] + result.stderr[-7000:])
    print(title + ": PASS", flush=True)


def runtime_bindings(report, cases, source, parent):
    require(report["status"] == "UNIVERSAL_MATHEMATICAL_PASS", "runtime not proved")
    require(report["table_sha256"] == NATIVE_SHA256, "runtime table binding differs")
    require(report["sites_sha256"] == SOURCE_SHA256, "runtime source binding differs")
    require(report["checker_sha256"] == digest(parent / "code/runtime/symbolic_runtime.py"),
            "runtime checker binding differs")
    require(report["helper_sha256"] == digest(parent / "code/runtime/independent_runtime.py"),
            "runtime helper binding differs")
    require(report["working_states"] == 217 and report["site_count"] == 3891,
            "runtime census differs")
    require(report["expected_cases"] == report["proved_cases"] == 5060,
            "runtime case count differs")
    require(not report["failures"] and len(report["blocks"]) == 4,
            "runtime failures or incomplete traversal schemas")
    require(report["startup_status"] == "CALIBRATED_DIRTY_ROOT_SEED",
            "runtime initialization was not calibrated")
    expected = {(i, b) for i, row in enumerate(source)
                for b in ((False, True) if row[1] == "CD" else (False,))}
    observed = {(row["site_index"], row["positive"]) for row in cases}
    require(len(cases) == len(observed) == 5060 and observed == expected,
            "saved runtime case coverage differs")
    for case in cases:
        duration = case["duration"]
        require(len(duration) == 13 and all(isinstance(v, int) and v >= 0
                                           for v in duration) and duration[0] > 0,
                "invalid positive affine duration")
        require(case["symbolic_steps"] > 0 and len(case["motion"]) == 13,
                "invalid case derivation summary")
    return {"cases": len(cases), "traversal_schemas": len(report["blocks"])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--baseline-full", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    require(__debug__ and not sys.flags.optimize,
            "verification requires enabled assertions; omit -O and PYTHONOPTIMIZE")
    began = time.monotonic()
    manifest = manifest_check()
    archive = ROOT / "inputs/U218_ConPA_2026-10-28.zip"
    require(digest(archive) == ARCHIVE_SHA256, "wrong immutable U218 archive")
    with tempfile.TemporaryDirectory(prefix="u217-reproduce-") as directory:
        temporary = Path(directory)
        baseline = extract(archive, temporary / "baseline", "U218_ConPA_2026-10-28")
        require(digest(baseline / "machine/u218.native.tm") == BASELINE_SHA256,
                "baseline archive table differs")
        require((baseline / "machine/u218.native.tm").read_bytes()
                == (ROOT / "inputs/u218.native.tm").read_bytes(),
                "loose baseline table is not the archived table")
        require((baseline / "machine/sites.json").read_bytes()
                == (ROOT / "machine/sites.json").read_bytes(), "source was changed")
        parent = extract(baseline / "inputs/U222_ConU_2026-10-28.zip",
                         temporary / "parent", "u222_consistency_machine")
        candidate = temporary / "candidate"
        summary = build(ROOT / "inputs/u218.native.tm",
                        ROOT / "machine/sites.json", candidate)
        for name in ("u217.native.tm", "u217.tm", "state_map.json",
                     "machine_summary.json", "sites.json"):
            require((candidate / name).read_bytes() == (ROOT / "machine" / name).read_bytes(),
                    "exact reconstruction differs: " + name)
        local = check(ROOT / "inputs/u218.native.tm", candidate / "u217.native.tm")
        local["mutation_controls"] = mutation_controls(
            ROOT / "inputs/u218.native.tm", candidate / "u217.native.tm")
        require(json.loads(json.dumps(local)) == load(ROOT / "evidence/local_blocks.json"),
                "local certificate differs")
        command(ROOT / "code/check_sparse_blocks.py",
                [ROOT / "inputs/u218.native.tm", candidate / "u217.native.tm",
                 "--out", temporary / "sparse.json"], temporary,
                "Independent sparse-context identities and nine controls")
        require(load(temporary / "sparse.json") == load(ROOT / "evidence/sparse_blocks.json"),
                "sparse certificate differs")
        startup = startup_check(
            ROOT / "inputs/u218.native.tm", candidate / "u217.native.tm",
            baseline / "evidence/startup.json", ROOT / "evidence/startup.json")
        require(startup == load(ROOT / "evidence/startup_independent.json"),
                "independent startup receipt differs")
        source = load(candidate / "sites.json")
        saved = load(ROOT / "evidence/runtime.json")
        cases = load(ROOT / "evidence/runtime_cases.json")
        runtime_bindings(saved, cases, source, parent)
        old_receipt = load(ROOT / "evidence/baseline_full_replay.json")
        require(old_receipt["status"] == "U218_FULL_REPRODUCTION_PASS"
                and old_receipt["native_sha256"] == BASELINE_SHA256
                and old_receipt["symbolic_cases_rerun"] is True,
                "fresh baseline full receipt differs")
        if args.full:
            runtime = temporary / "runtime"
            command(parent / "code/validate_native.py",
                    [candidate / "u217.native.tm", candidate / "sites.json", runtime],
                    temporary, "All 5060 arbitrary-register symbolic cases")
            fresh = load(runtime / "runtime.json")
            fresh_cases = load(runtime / "runtime_cases.json")
            runtime_bindings(fresh, fresh_cases, source, parent)
            require(fresh_cases == cases, "regenerated case records differ")
            require(fresh["blocks"] == saved["blocks"], "regenerated block lemmas differ")
            require(load(runtime / "startup.json") == load(ROOT / "evidence/startup.json"),
                    "regenerated startup trace differs")
        if args.baseline_full:
            command(baseline / "reproduce.py",
                    ["--full", "--report", temporary / "baseline.json"],
                    baseline, "Complete inherited U218 full reproduction")
            require(load(temporary / "baseline.json")["status"] == "U218_FULL_REPRODUCTION_PASS",
                    "fresh baseline replay failed")
        result = {
            "status": "U217_FULL_REPRODUCTION_PASS" if args.full
                      else "U217_RECONSTRUCTION_AND_LOCAL_PROOF_AUDIT_PASS",
            "manifest": manifest, "working_states": 217, "binary_transitions": 434,
            "native_sha256": NATIVE_SHA256, "dense_sha256": DENSE_SHA256,
            "source_sha256": SOURCE_SHA256, "parent_archive_sha256": ARCHIVE_SHA256,
            "exact_native_dense_source_and_bijection_reconstructed": True,
            "unchanged_retained_rows": 433, "local_full_frames": 4,
            "local_sparse_contexts": 3, "negative_control_executions_rejected": 14,
            "startup_steps": 95726, "entire_native_startup_trace_identical": True,
            "source_occurrences": 3891, "source_distinct_subtrees": 202,
            "saved_runtime_cases_checked": 5060, "symbolic_cases_rerun": args.full,
            "baseline_full_replayed_this_invocation": args.baseline_full,
            "seconds": round(time.monotonic() - began, 3),
            "scope": "Exact reconstruction and executable mathematical certificates. "
                     "The written finite-run proof is PA-formalizable; the consistency "
                     "calibration is inherited. No new complete proof-assistant endpoint.",
        }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
