#!/usr/bin/env python3
"""Bounded two-sided discovery search (not an acceptance checker).
Reproduce with: python3 -B research/search_reduction.py
Only the three-case certificate is required for the accepted U217 proof.
"""
import argparse
import itertools
import json
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    table = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        table[int(q), int(b)] = int(w), (1 if d == 'R' else -1), int(z)
    return table

def windows(table, radius):
    width = 2 * radius + 1
    mask = (1 << width) - 1
    seen = {q: set() for q, b in table}
    seen[254] = set()
    seen[0] = set(range(1 << width))
    queue = deque((0, frame) for frame in sorted(seen[0]))
    while queue:
        q, frame = queue.popleft()
        if q == 254:
            continue
        b = (frame >> radius) & 1
        w, d, z = table[q, b]
        frame = (frame & ~(1 << radius)) | (w << radius)
        if d == 1:
            outcomes = (frame >> 1, (frame >> 1) | (1 << (width - 1)))
        else:
            x = (frame << 1) & mask
            outcomes = (x, x | 1)
        for outcome in outcomes:
            if outcome not in seen[z]:
                seen[z].add(outcome)
                queue.append((z, outcome))
    return seen

def old_goals(table, q, frame, radius, drop, limit):
    head, goals = radius, {}
    for tick in range(1, limit + 1):
        if q == 254 or not 0 <= head <= 2 * radius:
            break
        b = (frame >> head) & 1
        w, d, z = table[q, b]
        frame = (frame & ~(1 << head)) | (w << head)
        head += d
        q = z
        if tick >= 2 and q != drop:
            goals[q, head, frame] = tick
    return goals

def new_join(table, row, frame, radius, drop, edit, goals, limit):
    q, head = row[0], radius
    for tick in range(1, limit + 1):
        if q in (254, drop) or not 0 <= head <= 2 * radius:
            return None
        b = (frame >> head) & 1
        w, d, z = edit if (q, b) == row else table[q, b]
        frame = (frame & ~(1 << head)) | (w << head)
        head += d
        q = z
        if (q, head, frame) in goals:
            return goals[q, head, frame], tick
    return None

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--table', type=Path, default=ROOT / 'inputs/u218.native.tm')
    parser.add_argument('--radius', type=int, default=4)
    parser.add_argument('--old-limit', type=int, default=11)
    parser.add_argument('--new-limit', type=int, default=31)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    table = read(args.table)
    seen = windows(table, args.radius)
    states = sorted({q for q, b in table})
    candidates, partial = [], []
    for drop in states:
        if drop == 0:
            continue
        incoming = [key for key, action in table.items() if action[2] == drop]
        if any(q == drop for q, b in incoming):
            continue
        routes = []
        for q, b in incoming:
            cases = [(m, old_goals(table, q, m, args.radius, drop, args.old_limit))
                     for m in sorted(seen[q]) if ((m >> args.radius) & 1) == b]
            options = []
            if all(goals for m, goals in cases):
                for w, d, representative in itertools.product((0, 1), (-1, 1), states):
                    if representative == drop:
                        continue
                    lengths = []
                    for frame, goals in cases:
                        answer = new_join(table, (q, b), frame, args.radius, drop,
                                          (w, d, representative), goals, args.new_limit)
                        if answer is None:
                            break
                        lengths.append(answer)
                    else:
                        options.append({
                            'row': [q, b], 'action': [w, d, representative],
                            'step_pairs': [list(v) for v in sorted(set(lengths))],
                            'frames': len(cases)})
            routes.append(options)
        result = {'drop': drop, 'incoming': [list(k) for k in incoming], 'routes': routes}
        if routes and all(routes):
            candidates.append(result)
        elif any(routes):
            partial.append(result)
    output = {
        'status': 'BOUNDED_DISCOVERY_SEARCH_COMPLETE',
        'radius': args.radius, 'old_step_limit': args.old_limit,
        'new_step_limit': args.new_limit, 'working_states': len(states),
        'abstract_frames': sum(map(len, seen.values())),
        'candidates': candidates, 'partial_reroutings': partial,
        'scope': 'Restricted search, not a lower bound. Multi-predecessor options '
                 'must be checked together; the accepted candidate has one predecessor. '
                 'Acceptance depends on the independent local certificates.'}
    text = json.dumps(output, indent=2) + '\n'
    if args.output:
        args.output.write_text(text)
    print(text, end='')

if __name__ == '__main__':
    main()

