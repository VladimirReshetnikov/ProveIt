# Exact spectral detection, faster uniformity limits, and sharp affine recovery

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and the ProveIt Ramsey project, 7 October 2026.

## Main files

- `gowers_spectral_uniformity_affine.tex`: complete article, including proofs and bibliography.
- `gowers_spectral_uniformity_affine.pdf`: compiled article.
- `figures/`: two vector PDF figures and PNG previews.
- `verification/`: four reproducible verification programs and their recorded results.
- `make_figures.py`: regenerates both figures from the proved formulas.
- `data/`: figure values and source provenance.

The TeX source is a single file. Its only local build dependencies are the two figure PDFs already included in this archive. No bibliography processor, source manuscript, network connection, or external repository is required to compile it.

## Results and attribution

The article proves extensions relative to the audited ProveIt research materials:

1. The complete seven-branch four-frequency missing-arc profile, with a new cubic contact equation, quartic transition, and unique extremizers. The nonclassical transition angle is proved to be an irrational multiple of pi.
2. An exact final band for every Fourier cutoff, including its active-frequency transitions.
3. An exact finite-grid central correction, its oscillating second-order term, and an all-size half-circle formula for orders divisible by four.
4. An absolute, family-uniform rate `c_d(F) - D(F) = O(d * 2^(-d/2))`, improving the earlier `O(sqrt(d) * 2^(-d/4))` rate.
5. The exact first correction on each fixed odd prime cyclic group, through a subset-sum cube polynomial with an explicit leading coefficient.
6. Sharp affine recovery at graph defect below one quarter for every abelian target, a complete quarter-endpoint dichotomy, and the optimal universal order-thirteen cutoff for the non-affine energy maximum.
7. Partial-domain consequences, a larger high-correlation recovery range following Gowers' Proposition 6.1, and deterministic decoding.

Earlier results are explicitly credited and the required proofs are included. In particular, the bounded endpoint `1/3`, Fourier-tail and smoothing lemmas, local cubic energy profiles, and multilevel overlap inequality are prior inputs. The quarter threshold and cutoff thirteen were already known in the supplied elementary-abelian-three-target case; this article extends them to arbitrary abelian targets.

The exact Fourier optimization is over probability measures. Its consequences for sets are valid bounds; the article distinguishes these from sharp bounds for fixed-density indicator functions and from half-open exclusions. The fixed-prime lower obstruction concerns a rate uniform over families; it is not a lower bound on the all-odd excess above `1/3`.

No stronger global Szemeredi or Ramsey bound, worldwide priority determination, external peer review, or Lean verification is claimed. The article gives a formalization map to inspected existing declarations and sixteen further research questions.

## Build

A standard TeX Live installation with pdfLaTeX, latexmk, AMS packages, Latin Modern, microtype, graphicx, booktabs, enumitem, fancyhdr, hyperref, and bookmark suffices. The supplied build was made with TeX Live 2023/Debian.

```sh
make pdf
```

Equivalently:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_spectral_uniformity_affine.tex
```

The bibliography is embedded in the TeX source. Figure regeneration is optional for a normal PDF build.

## Verification

The norm and rigidity programs use only the Python standard library. The Fourier diagnostics require NumPy and SciPy; figure regeneration also requires Matplotlib. Versions used for the supplied numerical diagnostics are recorded in `data/provenance.json`.

```sh
make verify
make figures
```

Or run the programs separately:

```sh
python3 verification/fourier_verify.py --output verification/fourier_verification_results.json
python3 verification/norm_verify_rate.py --output verification/norm_rate_certificates.json
python3 verification/norm_verify_prime.py --output verification/norm_prime_certificates.json
python3 verification/rigidity_checks.py
```

The Fourier program checks 24 exact algebraic/finite-field assertions, 2,009 complete-profile instances, 8,127 all-cutoff instances, and 174 independent finite-grid linear programs. Sampled positivity and floating-point agreement supplement the written interval proofs; they do not replace them.

The norm-rate program certifies eight finite parameter choices with integer/rational logarithm and exponential enclosures. The prime program computes exact coefficients for primes 3, 5, 7, 11, and 13, and checks the defining derivative recursion independently for the smaller primes.

The rigidity program checks 13,656 normalized maps in 32 exhaustive small-domain suites, 2,484 specified sparse maps on larger domains, and the exact scalar inequalities needed at order thirteen. Its exhaustive and specified scopes are separated in the output.

## Source baseline and integration

Repository baseline:

`6d494222250ce2d8616435cec118d74e493b95b5`

[Pinned Ramsey directory](https://github.com/VladimirReshetnikov/ProveIt/tree/6d494222250ce2d8616435cec118d74e493b95b5/Combinatorics/Ramsey)

The merged research article at that revision contains sources 01–39. Later supplied manuscripts were also audited; their titles, source roles, and content hashes are recorded in `data/provenance.json`. The new manuscript does not assign itself a source number and does not assume that all later reports have already been merged.

For integration, keep the article and `figures/` together, or adjust the two `includegraphics` paths. Preserve attribution to the previous manuscripts and distinguish proposed Lean targets from already implemented declarations. The package contains no changes to the existing Lean development or original Gowers transcription.
