# A213863 and binary tree-child network amplitudes

This package accompanies the self-contained mathematical article `tree_child_amplitude.pdf`. The standalone editable source is `tree_child_amplitude.tex`.

## Contents and scope

The article proves a positive leading amplitude and a full Poincaré expansion for the constrained-word/Young-tableau sequence A213863. The exact normalization transfers those expansions to maximal-reticulation binary tree-child networks. An elementary quantitative consequence of published lemmas gives a total/maximal ratio error O(n^(−2/3)), a Poisson total-variation rate of the same order, and the first explicit correction for the total network count. A full all-order total-count expansion is not claimed. The article includes convergent amplitude representations, exact correction algorithms, and qualified inverse formulas.

No certified decimal amplitude, convergent infinite correction series, exponentially small sector, or exhaustive literature-priority claim is made. Finite verification scripts are not machine proofs of the analytic estimates.

## Verify and build

1. Before changing any files, run `python3 verify_release.py` to verify the archived integrity inventory and recorded check outcomes. The manifest is an integrity check, not a cryptographic signature.
2. Run `bash build.sh` to compile the standalone TeX three times. The build requires a standard TeX Live installation with pdfTeX, Latin Modern, AMS packages, microtype, geometry, fancyhdr, booktabs, enumitem, and hyperref. No bibliography database, external figures, network, or companion proof is needed. The script rejects overfull boxes and unresolved references.
3. Run `python3 checks/run_checks.py` for the complete exact suite. Requirements are Python 3.10+ and SymPy 1.14.0. It runs every section normally and under `python -O`, followed by 44 intended corruption rejections. The run usually takes a few minutes. Details are in `checks/README.md` and `checks/RESULTS.md`.

The rerun updates build products and validation logs. For a pristine archive comparison, extract a second fresh copy; the original manifest records the shipped files rather than future run timestamps.

## Optional numerical diagnostics

The directory `diagnostics/` contains saved integer-DP diagnostics and a reproduction script. These are explicitly uncertified floating-point diagnostics, not amplitude enclosures. They are not needed for the proof or exact suite.

Requirements: mpmath 1.3.0 and SymPy 1.14.0. Run `python3 diagnostics/reproduce_dp.py 3000 fresh_dp_3000.json`. It evaluates exact integer counts before converting to 75-digit floating-point quantities. The output name is relative to `diagnostics/`; the script refuses to overwrite an existing output. A normal and optimized replay at n=100 matches the saved experiment. The full n=3000 saved output includes the rows quoted in the article.

## Provenance and limitations

`SOURCES.md` identifies the primary literature, versions, and exact results used. `provenance/sources.json` records hashes of inspected primary PDF snapshots where available; third-party papers are not redistributed. The article and software are the deliverables. `MANIFEST.json` inventories their precise bytes. `qa/REVIEW.md` records rendering, extraction, and clean-build checks without redistributing page-image intermediates.
