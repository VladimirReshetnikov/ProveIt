#!/usr/bin/env python3
"""Verify the shipped A213863 report inventory before rebuilding or replaying."""
import ast
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def strict_object(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, 'Duplicate JSON key: '+key)
        obj[key] = value
    return obj


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=strict_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON: '+value)))


def main():
    manifest = read_json(ROOT/'MANIFEST.json')
    require(type(manifest.get('schema')) is int and manifest['schema'] == 1, 'Unsupported release manifest')
    files = manifest.get('files')
    require(isinstance(files, dict) and len(files) >= 20, 'Incomplete release file inventory')
    required = {'tree_child_amplitude.pdf', 'tree_child_amplitude.tex', 'README.md',
                'SOURCES.md', 'build.sh', 'verify_release.py', 'checks/verify_exact.py',
                'checks/run_checks.py', 'checks/input_manifest.json', 'checks/results/suite.json',
                'checks/inputs/formal_9.json', 'checks/inputs/endpoint_9.json', 'qa/REVIEW.md',
                'provenance/sources.json'}
    require(required <= set(files), 'Missing mandatory release entries')
    for name, expected in files.items():
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name != 'MANIFEST.json',
                'Unsafe or self-referential inventory path')
        target = ROOT/p
        require(target.is_file(), 'Missing release file: '+name)
        raw = target.read_bytes()
        require(len(raw) == expected.get('bytes'), 'Release size mismatch: '+name)
        require(hashlib.sha256(raw).hexdigest() == expected.get('sha256'),
                'Release SHA-256 mismatch: '+name)
    require((ROOT/'tree_child_amplitude.pdf').read_bytes().startswith(b'%PDF-'), 'Invalid PDF header')
    tex = (ROOT/'tree_child_amplitude.tex').read_text()
    require('\\end{document}' in tex and ',qquad' not in tex, 'Incomplete or mistyped TeX')
    suite = read_json(ROOT/'checks/results/suite.json')
    require(suite.get('status') == 'PASS', 'Exact suite did not pass')
    require(len(suite.get('baseline', [])) == 2, 'Missing baseline mode')
    require({item['mode'] for item in suite['baseline']} == {'normal', 'optimized'}, 'Wrong baseline modes')
    require(all(item.get('status') == 'PASS' for item in suite['baseline']), 'Failed baseline mode')
    corruptions = suite.get('corruption_tests', [])
    require(len(corruptions) == 44, 'Wrong corruption coverage')
    require(all(item.get('status') == 'REJECTED' for item in corruptions), 'Accepted corrupted input')
    for filename in ['verify_release.py', 'checks/verify_exact.py', 'checks/run_checks.py']:
        tree = ast.parse((ROOT/filename).read_text())
        require(not any(isinstance(node, ast.Assert) for node in ast.walk(tree)), 'Disabled-under-O assertion gate')
    print(f'PASS: {len(files)} shipped files match the inventory; both exact modes and all 44 rejections passed')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(f'FAIL: {type(error).__name__}: {error}', file=sys.stderr)
        sys.exit(1)
