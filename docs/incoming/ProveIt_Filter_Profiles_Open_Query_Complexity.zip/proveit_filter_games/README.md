# Filter Profiles and Open-Query Complexity

**Exact finite-derivative classification, ultrafilter thresholds, and a three-color separation**

Research report prepared for Vladimir Reshetnikov, September 29, 2026.

## Main contribution

This report continues Research question 1 in Section 27 of ProveIt's
*Open-query games on ordinal spaces*, at repository commit
`2d49198382cc068f46747d1b3d9067d47cee4f24`.

For every Hausdorff space with a finite nonempty derived set, every finite
coloring has a complete admissible-word profile represented by a finite
directed graph. If the coloring uses q colors and the graph's minimum
directed feedback vertex set has size tau, the exact minimum layer count
is q + tau and the minimum worst-case query depth is ceil(log2(q + tau)).

The paper also proves an exact local-capacity criterion for attainment of
the rank-one bound, a complete three-color classification, positive results
under local compactness or first countability, and closed threshold formulas
for arbitrary finite sums of free-ultrafilter spaces.

In particular, three countable one-point free-ultrafilter spaces have
three-color query invariant 2, whereas three convergent sequences have
invariant 3. Both spaces are countably infinite, zero-dimensional Hausdorff,
with exactly three nonisolated points and empty second derivative.

## Scope and status

The report contains conventional mathematical proofs, not Lean or Rocq
formalizations, and has not been independently refereed. The proposed new
contribution is the filter-profile classification and its topological
consequences. No standalone priority claim is made for the elementary
graph-theoretic ingredients. The literature search is not exhaustive.

The classification concerns a finite nonempty first derived set. It does
not settle all finite-height spaces, infinite derived sets, transfinite
play, or expected-cost optimization. Free ultrafilter existence is used in
ZFC. The Python checks do not simulate or construct an infinite ultrafilter.

## Read and rebuild

- `article.pdf`: the 20-page report.
- `article.tex`: standalone source with internal bibliography.
- `SOURCES.md`: repository pin, source roles, and novelty boundary.
- `code/verify.py`: standard-library finite verifier and certificate generator.
- `results/`: executed verification results and exact threshold tables.

A standard TeX Live installation with pdfLaTeX, Latin Modern, amsmath,
amsthm, microtype, booktabs, ragged2e, enumitem, listings, hyperref and
cleveref is sufficient. No external figures or bibliography database are
required. Run:

```sh
make pdf
```

or:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

## Reproduce the computations

Python 3.10 or newer is required; no third-party packages are used.
Run without `-O`, since assertions are verification conditions.

```sh
make verify
```

To preserve the shipped records and write a separate run:

```sh
python3 code/verify.py --output fresh-results
```

The full default run checked all 4,165 loopless directed graphs on one
through four labeled vertices against an independent reduced-word search;
11,515 positive-cell word conditions; 98 capacity-attainment cases; and
10 small extremal arc thresholds, including every equality graph. It also
generates exact query-jump thresholds and checks balanced extremal arc
counts through 64 labels. This last range is not exhaustive digraph
verification through 64 vertices.

`results/strategy_certificates.json` gives optimal words, feedback sets,
topological orders, and balanced suffix-query trees for the two principal
three-color examples. A suffix index in the JSON is zero-based. Its
interpretation as a genuine open set is proved in the article rather than
encoded as an infinite collection of neighborhoods.

`SHA256SUMS` records delivered file hashes. Rebuilding the PDF can change
its bytes because TeX metadata includes compilation timestamps; the hash is
for this delivered PDF, not a promise of a bit-reproducible TeX toolchain.
No changes were made to the upstream repository.
