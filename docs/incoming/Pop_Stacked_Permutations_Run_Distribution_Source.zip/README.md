# Report 166 Run distribution in pop stacked permutations

The report derives an explicit bivariate exponential generating function for maximal ascending runs of distinct pop-stacked output permutations. It proves exact linear moment asymptotics, a central limit theorem, and a uniform lattice local limit with O(n^-1) absolute error. The distribution is uniform on distinct outputs, not induced by uniform inputs.

The separate fixed-run denominator section is an alternate proof. Shivam Patel publicly posted a valid inclusion-exclusion proof on 20 August 2026; the report credits it and distinguishes the site's unverified-claim label from our independent mathematical assessment. No first-resolution or worldwide-priority claim is made.

## Files

- `Report166.pdf`: checked 16-page report
- `Report166.tex`: editable mathematical source
- `companion/`: bounded standard-library exact computations, tests, and published fixtures
- `data/`: deterministic computed JSON receipts, distinct from published fixtures
- `SOURCE_PROVENANCE.json`: source URLs, locations, snapshot hashes and scope
- `author_review_receipt.json`: local build, test and visual-review evidence
- `SHA256SUMS`: checksums of the fixed source-ZIP allowlist
- `build_pdf.py`, `make_zip.py`, `release_tools.py`, `test_release.py`: reproduction helpers and output-safety tests

The full paper and MathDB snapshots used for research are not redistributed in this package. Their URLs and hashes are recorded for attribution and provenance.

## Exact calculations

Python 3.10 or newer is recommended. The companion uses only the Python standard library and no file/network API. Run from the package root:

    python -B companion/run_checks.py all
    python -B companion/run_checks.py coefficients --n 40 --literal 9 --include-data
    python -B companion/run_checks.py slopes
    python -B companion/run_checks.py filtration --n 40 --filtration 12 --include-data
    python -B companion/run_checks.py all --n 40 --literal 9 --filtration 12 --include-data
    python -B companion/run_tests.py
    python -B -O companion/run_tests.py

Every public command prints one deterministic JSON object on standard output. The default checks polynomials through n=12, literal images through n=7, published fixed-k formulas and the rational slopes. Filtration is opt-in for `all`. Full bounded verification was run at n=40, literal n=9, filtration k=12. See `companion/README.md` for exact limits, separate scopes and the API. Checks use explicit exceptions and remain active under `-O`.

The JSON files in `data/` are saved outputs from these commands. Finite checks do not replace the all-size mathematical proofs. Beta and gamma are defined analytically in the report; their displayed decimals are not interval-certified. The slope intervals are certified. No numerical asymptotic error constant or onset is certified.

## PDF reproduction

Requires a POSIX environment with `/proc/self/fd`, Python, `pdftex`, `pdflatex`, the standard LaTeX packages listed in the source, Latin Modern and AMS fonts. TeX Live 2023 / pdfTeX 1.40.26 was used. Run with an output directory that does not exist and has an existing trusted parent:

    python -B build_pdf.py --output-dir /tmp/report166-pdf-replay

The script creates a local format, isolates TeX cache/config directories, disables shell escape, fixes metadata and stabilizes cross-references in at most six passes. It rejects any settled warnings, overfull/underfull boxes or missing glyphs. Output is `Report166.pdf` in the new directory. Different TeX/font installations may produce different PDF bytes; identical bytes were obtained in two clean builds here.

## ZIP reproduction

First verify the package:

    sha256sum -c SHA256SUMS
    python -B test_release.py
    python -B -O test_release.py

Then select a new file in an existing trusted parent directory:

    python -B make_zip.py --output /tmp/Report166_Source_replay.zip

The builder validates the exact allowlist and every SHA-256 digest before producing a stored ZIP with sorted members and fixed metadata. The manifest itself is included. Outputs are exclusive and never overwrite an existing file or directory. Symbolic-link path components and parent traversal are rejected; opened parent directories are pinned. Helpers assume trusted source files and output parents. They are not a sandbox for malicious TeX or a hostile actor able to replace directory contents.

Two PDF builds, two ZIP creations, normal/optimized computational outputs and regression tests, and all-page visual inspection were required before release. Rendered page images and temporary build files are not included.

## Claim boundaries

There is no global bivariate polar-set classification, reduced/minimal fixed-run denominator theorem, improvement in full run-refined enumeration complexity, Edgeworth expansion, global large-deviation theorem, or certified numerical error onset. The source search is bounded. The fixed-run denominator representation is credited prior public work. Reports 161 and 164 were not changed. No publication, author contact, OEIS edit or repository modification was performed during preparation.
