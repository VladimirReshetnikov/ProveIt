THE EXACT INSPECTION COST OF INFINITE HAT GUESSING
Geometric query laws, bounded-depth obstructions,
and affine rigidity of optimal finite teams

Research report prepared for Vladimir Reshetnikov
4 October 2026

CONTENTS

hat_inspection_frontier.pdf
    Complete typeset article.
hat_inspection_frontier.tex
    Standalone LaTeX source; no external figures or bibliography file.
code/verify_finite.py
    Exact finite verification using only standard Python.
data/verification.json
    Exact results from the successful verification run.
SOURCE_AUDIT.txt
    Primary sources, pinned repository revision, prior-work distinctions.
PROOF_STATUS.txt
    Theorem scope, independent review, and remaining verification boundary.
build.sh
    Three-pass pdflatex build from this directory.

MAIN RESULTS

1. Uniformly bounded deterministic adaptive inspection depth implies
   probability zero that S_n - n/2 tends to positive infinity.
   This resolves Research question 13.2 in the predecessor report
   No Universal Sublinear Bound for Measurable Hat Guessing.

2. Exact geometric inspection frontier:
   if divergence has positive probability, then for every nonnegative
   nondecreasing cost phi,
       sup_i E phi(Q_i) >= E phi(G), P(G=j)=2^(-j), j>=1.
   One finite-tree implementation of Eldredge's existing block strategy
   attains equality for all such costs and has almost-sure divergence.
   The sharp uniform expected query bound is 2. The optimal tail is
   2^(-r). The sharp uniform exponential moment at base 1<=z<2 is
   z/(2-z); no finite uniform bound is possible at z>=2.

3. Sharp variance bound:
       Var(2S_n-n) <= n + sum_{i<=n} E Q_i.
   Bounded mean inspection forces limiting success density 1/2 a.s.

4. Exact minimum-depth finite classification:
   attaining P(S_N>=s)=N/(2s), s>N/2, requires depth >=s-1.
   Attainment at depth s-1 is possible exactly for
       N=m(2^r-1), s=m*2^(r-1), r,m>=1.
   The failure set must be affine with every nonzero parity-check
   column repeated m times. A replicated trace construction realizes
   every allowed pair. For odd N at strict majority this forces an
   affine Hamming failure code.

5. The explicit stage schedule also has exact every-prefix surplus
   rates, an endpoint central limit theorem, realized average query
   cost tending to 3/2, and maximum query cost asymptotic to log_2 n.

REPRODUCING THE PDF

Use a standard TeX Live or MiKTeX installation with pdflatex and the
packages listed in the source preamble. From the extracted directory:

    sh build.sh

The source is self-contained. No network access is needed to compile.

REPRODUCING FINITE CHECKS

Use Python 3.8 or later:

    python3 code/verify_finite.py

The verified run covers 19 exhaustive parameter cases and 59,546
hat assignments, including 838,498 own-hat flip comparisons.
These tests verify finite constructions, not the infinite theorems.

MODEL AND ATTRIBUTION

The sharp geometric frontier uses deterministic adaptive trees whose
only observations are charged hat queries. Free public randomness
with costs averaged over that randomness changes the theorem.
The critical bound is sup_i E Q_i=2; individual E Q_i<2 is compatible
with that supremum.

Eldredge's Proposition 6.6 already supplies the rare exceptional-block
strategy and almost-sure divergent excess. This article refines its
query implementation and proves matching cost obstructions.
Hypercontractivity and the constant-weight linear-code classification
are classical and explicitly credited. The adaptive leaf-to-affine
argument and the quantified cost conclusions are proved in the text.

This is an AI-assisted, unrefereed research manuscript. Independent
mathematical reviews and finite checks found no remaining substantive
error. Global historical priority and proof-assistant verification are
not claimed. No changes were made to the ProveIt repository.
