A SMALL PROOF SEARCH FOR Con(ZFC)
Empty-seed closure, quantified NAND, and a route to a smaller Turing machine
Research report prepared for Vladimir Reshetnikov -- 16 October 2026

START HERE

Read report.pdf. The main proposal is a complete equality-free EPSC refutation
search with the two formula constructors R(i,j) and Q(A,B)=forall x not(A and B).
The report gives ordinary mathematical proofs and a tested reference checker.
It does not claim a newly certified sub-253 binary Turing machine.

report.tex, sections/*.tex, and references.tex are the complete report source.
The bibliography includes immutable repository links and primary literature.

COMPUTATIONAL REPLAY

Requirements: Python 3.10 or later, standard library only, assertions enabled.
From this directory:

    python3 reproduce.py

This runs the main finite tests, additional finite audit, exact examples,
the fixed 269-state control recipe, and the independent register-certificate
verifier. It compares delivered metrics and the total table hash, then writes
logs and a summary under reproduced/. No network or proof assistant is needed.
It does not rerun the grammar search or execute an unbounded consistency search.

To run the finite checker tests individually:

    python3 code/test_qnand.py --output reproduced_qnand.json
    python3 code/audit_qnand.py --output reproduced_audit.json
    python3 code/qnand.py --prefix 1000

The last command checks a finite prefix only. The unbounded search() function
is a mathematical ideal-storage specification. Its sole successful halt is
an accepted EPSC refutation. Host memory errors are not refutations.

examples/qnand_examples.json contains two valid generic logic tableaux and a
rejected attempt to reuse an old witness name. None is an EPSC refutation.

MACHINE CONTROL

machine_control/ is a separate experiment preserving the original full logical
program. It matches the existing 269-state control; it is not the new Q checker.
Its own README.md documents the fixed recipe, 4,533-pair register certificate,
538-row total binary table, source pins, and attribution.

The public Wade framework contributes 62 states and the candidate program 207.
The binary compiler and complete blank-start simulation are not proved here.

REBUILDING THE PDF

Requirements: a conventional LaTeX distribution with latexmk and the packages
listed in report.tex. Run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Or use:

    make pdf

The PDF was compiled and its rendered pages inspected. No Lean or Coq build
was performed in this investigation. The upstream 253-state Coq results are
reported with their precise published scope and pinned source.

INTEGRITY AND PROVENANCE

On a system with sha256sum:

    sha256sum -c SHA256SUMS

The digest list covers all delivered files except itself. Rebuilding the PDF
or editing any source will naturally change its digest.

results/source_snapshot.json records the repository and upstream pins.
results/verification.json records the final package replay.
results/pdf_review.json records the PDF layout review.

The original EPSC/PSC work and earlier checker/compiler infrastructure are
credited in the report. Quantified NAND is Schonfinkel's classical operator.
The new contribution is this precise EPSC frontend, its reference code and
proof audit, and the separate library-priced grammar comparison.

Original upstream and imported helper notices remain in machine_control/.
No blanket new license is assigned to those sources.
