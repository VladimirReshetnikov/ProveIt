LEXICOGRAPHIC ORDERS OF SURREAL WELL-ORDERS
Exact Birthday Spectra, Word Products, Topological Transitions,
and Class Comparability

Research manuscript prepared for Vladimir Reshetnikov
3 October 2026

CONTENTS

surreal_orders_new_structures.pdf
    The complete 57-page article, with 14 sections, an embedded
    bibliography, 61 theorem/lemma/proposition/corollary statements,
    and 12 principal research questions.

surreal_orders_new_structures.tex
    One self-contained LaTeX source. No external figures, bibliography
    file, repository checkout, or network access is needed to compile it.

SOURCE_AUDIT.txt
    The scope of the pinned ProveIt audit, source synchronization findings,
    relevant inherited results, and the status of the earlier manuscripts.

PROOF_STATUS.txt
    Results and assumptions, review coverage, and the principal remaining
    mathematical gaps. Written and internally reviewed proofs are distinct
    from proof-assistant verification.

source_manifest.json
    Exact GitHub source URLs, Git blob SHA1 and file SHA256 hashes, byte
    counts, and identities/hashes of the three cited earlier manuscripts.
    Also records build information and final TeX/PDF hashes.

verification.json
    Compilation, reference-resolution, and PDF inspection metadata.

BUILD

From this directory, with a standard TeX Live installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error surreal_orders_new_structures.tex

Alternatively, run pdflatex on the source repeatedly until references
and the contents table stabilize (normally two or three runs).

The delivered PDF was compiled with pdfTeX 1.40.25, TeX Live 2023/Debian,
and latexmk 4.83. It uses standard LaTeX packages including amsmath,
amssymb, amsthm, mathtools, mathrsfs, lmodern, geometry, microtype,
booktabs, longtable, tabularx, enumitem, fancyhdr, xcolor, hyperref,
xurl, cleveref, and TikZ. No shell escape is required.

READING GUIDE

Sections 1-3: Interpretations, size levels, provenance, fixed-set baseline.
Section 4: Exact numerical birthday embedding spectrum, in ZF.
Section 5: All enumeration lengths at noninitial birthday cutoffs.
Section 6: Increasing words, the centered product, and zero conventions.
Section 7: Numerically well-ordered proper-class carriers and adjacency.
Section 8: Countable strata, topology, Borel structure, and products.
Section 9: Ordered prefix-tree automorphisms and class branches.
Section 10: Global well-orders, represented cuts, and higher-order size.
Section 11: Condensation histories and strong class comparability.
Sections 12-14: Formalization, further research, and proof status.

The main distinctions throughout are: isomorphism versus equimorphism;
set carriers versus proper classes; supplied class relations versus a
collection of class relations; and a supplied recursion history versus
an existence principle for such histories.

STATUS

This is an AI-assisted research manuscript with conventional written
proofs and independent internal mathematical review. It is not a refereed
publication, and no publication-priority claim or new Lean verification
is made. The bibliography identifies project manuscripts separately
from published or publicly available primary mathematical sources.
The exact source audit is pinned to ProveIt commit
7ff7736ecf3a0adc8536b2d083cf819e1ba39ace.
