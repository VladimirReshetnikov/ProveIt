# Canonical Boolean Obstructions
## Complete Extremizers and Sharp Dimension-Free Stability

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and the
ProveIt project, 7 October 2026.

## Main results

For the canonical symmetric tensor

    C_d^{u,v}(h_1,...,h_d) = sum_i v(h_i) product_{j != i} u(h_j)

on F_2^n, with independent linear forms u,v and d >= 4, the manuscript proves:

1. The complete maximizing-function family is
   exp(2*pi*i*(P + theta*|u|)), where P is a circle-valued polynomial of degree
   at most d-1 and theta is arbitrary in R/Z. An integrable correction to the
   tensor adds its primitive to the phase.
2. If delta = 1-(d+1)/2^d - E_C(f), and D is squared normalized L2 distance to
   this family, then D <= A_d*delta uniformly in the ambient dimension.
   More sharply, D <= 2*delta/(2^d-2d-2) + O_d(delta^(3/2)). The leading
   coefficient is optimal even on F_2^2.
3. Exact and robust relative polynomial gluing, the complete endpoint Hessian,
   a four-point energy formula, the topology of the extremizer family, and
   exact root-of-unity truth-table certificates support the two main results.

The universal energy endpoint and endpoint **tensor** classification are
credited to preceding ProveIt drafts. This work answers their separate
maximizing-**function** and dimension-independent phase-stability questions
for d >= 4. The all-dimensional cubic function problem remains open here.

## Status and limits

The paper contains mathematical proofs and exact finite regression checks.
It is AI-assisted, unrefereed, and not verified in a proof assistant. External
publication priority is not established. No independent human review is claimed.

The dimension-uniform entry argument uses the published qualitative
near-extremizer theorem of Eisner and Tao. The local radius, transverse gap,
and remainder bound are explicit. A numerical global entry threshold and an
optimal all-deficit constant are not extracted. No new global bound for
Szemeredi's theorem or arithmetic-progression-free sets is claimed.

The review of VladimirReshetnikov/math reports selected preprint claims and
formal-comparator limitations; none of its large quantitative claims is an
assumption in the proofs delivered here.

## Contents

- `boolean_endpoint_rigidity.tex`: complete self-contained LaTeX source.
- `boolean_endpoint_rigidity.pdf`: compiled article.
- `code/verify.py`: deterministic exact regression checker, standard library.
- `data/verification.json`, `data/verification_optimized.json`: executed records.
- `PROVENANCE.md`: inspected sources, snapshot pins, and review scope.
- `PROOF_AUDIT.md`: proof dependencies, critical checks, and limitations.
- `FORMALIZATION.md`: proposed formalization stages, not a Lean verification.
- `Makefile`: check and PDF build targets.

## Reproduction

Run from this directory with Python 3.10 or newer and a normal LaTeX installation:

```sh
make check
make pdf
```

Equivalent commands:

```sh
python3 code/verify.py --output data/verification.json
python3 -O code/verify.py --output data/verification_optimized.json
cmp data/verification.json data/verification_optimized.json
latexmk -pdf -interaction=nonstopmode -halt-on-error boolean_endpoint_rigidity.tex
```

The checker uses integers, rational arithmetic, and exact cyclotomic reductions.
It does not use a numerical optimizer, downloaded data, or Python assertions for
verification. The two JSON records are identical. Finite tests do not replace
the continuous and all-dimensional arguments in the article.

Suggested placement:

    Combinatorics/Ramsey/Research/GowersSzemeredi/boolean-endpoint-rigidity/

No repository write or theorem-status change was performed. The archive contains
no copies of third-party papers or standalone font files.
