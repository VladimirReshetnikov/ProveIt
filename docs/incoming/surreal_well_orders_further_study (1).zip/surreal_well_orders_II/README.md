# Lexicographic Well-Orders of the Surreal Numbers, II

**Exact cut spectra, branch recognition, optimal support reserves, and automorphism-extension obstructions**

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

## Contents

- `article.pdf`: the 29-page article, with a linked table of contents, full written proofs, interpretation and foundation discussions, 13 further research questions, dependency ledger, and bibliography.
- `article.tex`: standalone LaTeX source; its bibliography is internal.
- `finite_checks.py`: deterministic finite-mechanism tests, requiring only Python's standard library (Python 3.10 or later).
- `finite_checks.json`: the actual successful test results.
- `build.sh`: reruns the tests and compiles the article three times with pdfLaTeX.
- `research_status.md`: scope, provenance, assumptions, and verification boundary.
- `SHA256SUMS.txt`: checksums of the other payload files.

## Main results

For an infinite cardinal kappa, let X = No_{<kappa}, mu = 2^{<kappa}, r = cf(kappa), q = cf(mu), and let P be the lexicographic order of bijections mu -> X.

The article gives exact point characters (q,q), cylinder and global cofinality/coinitiality r, density/weight/cellularity mu^{<mu} (cellularity as a supremum), a dense-open fusion theorem, and the complete genuine-gap spectrum:

    {(r,r),(q,q)} union {(theta,r),(r,theta) : theta infinite regular, theta < mu}.

Over GBC, it proves a criterion for a lower class cut of a bounded-support core to represent an injective Ord-word: a prefix cylinder must straddle the cut at every set-ordinal length. A separate coverage condition characterizes exhaustive words. The elementary reconstruction yields an automorphism-extension criterion, an example of a core automorphism which does not extend, and detection of new enumerations in same-set class extensions.

Other results include the exact additional-support cardinal for extending a set partial injection, and the maximal factorial-sized adjacency components of unrestricted class well-orders, whose condensation is dense.

## Repository provenance

The source report was read at:

    repository: VladimirReshetnikov/ProveIt
    commit: 0ecd158fd163bc4aca0ee40ccf6479ca6cf5f2a8
    path: Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-well-orders/article.tex
    blob: f20837b76f8d981cb1dce3da79f633e280edad41

The source is a merged report from four earlier manuscripts. This article is a follow-up, not a replacement, and explicitly credits inherited results. The repository was neither modified nor built. The older report is not included in this ZIP.

## Build and verify

With Python 3.10+ and a TeX Live installation providing the packages declared in `article.tex`:

    bash build.sh

To run just the finite checks:

    python3 finite_checks.py --output finite_checks.json

To check the downloaded payload before rebuilding:

    sha256sum -c SHA256SUMS.txt

PDF creation timestamps and TeX versions can change the PDF checksum on rebuilding even when the mathematical text is unchanged. The deterministic JSON output is independent of those PDF timestamps.

## Status

AI-assisted research with written mathematical proofs. Not independently peer-reviewed or Lean-verified; no claim of historical priority. Finite tests verify only finite mechanisms, not the transfinite or class-theoretic results. Hypotheses and unresolved extensions are stated in the article and `research_status.md`. No fonts or external font files are distributed.
