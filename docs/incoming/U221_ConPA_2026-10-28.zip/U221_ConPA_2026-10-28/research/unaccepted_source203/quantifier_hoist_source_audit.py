#!/usr/bin/env python3
"""Finite source binding audit only; DOES NOT certify calculus completeness."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'baseline/u222'
CANDIDATE = Path(__file__).resolve().with_name('sites.json')


def need(p, message):
    if not p:
        raise ValueError(message)


def graph(rows):
    intervals = {}
    for i, (path, _, _) in enumerate(rows):
        for k in range(len(path)+1):
            intervals.setdefault(path[:k], [i, i+1])[1] = i+1
    def jump(path, bit, count):
        for j in range(len(path)-1, -1, -1):
            if path[j] == bit:
                count -= 1
                if not count:
                    return intervals[path[:j]][0 if bit == '1' else 1]
        raise ValueError('branch escapes complete source')
    out = []
    for i, (path, op, a) in enumerate(rows):
        if op == 'CI': targets = (i+1,)
        elif op == 'CD': targets = (jump(path, '0', 1), i+1)
        elif op == 'CB': targets = (jump(path, '0', a),)
        elif op == 'CC': targets = (jump(path, '1', a),)
        elif op == 'CH': targets = ()
        else: raise ValueError(op)
        out.append((op, a, targets))
    return out


def main():
    old = json.loads((BASE/'inputs/k215_sites.json').read_text())
    new = json.loads(CANDIDATE.read_text())
    go, gn = graph(old), graph(new)
    ranges = json.loads((BASE/'machine/construction.json').read_text())['macro_source_intervals']
    V = ('I', ('R', 'a', 'b'), ('Q', 'n', ('R', 'a', 'b')))
    G = ('Q', 'n', ('I', ('R', 'n', 1), ('R', 'n', 0)))
    L = ('Q', 1, ('I', G, ('I', 'n', ('R', 1, 'n'))))
    U = ('Q', 1, ('I', ('R', 1, 'n'), 'n'))
    expression = ('N', ('Q', 'n', ('I', V, ('I', L, ('N', U)))))
    def word(t):
        if not isinstance(t, tuple): return [t]
        if t[0] == 'N': return word(t[1]) + ['N']
        return word(t[1]) + word(t[2]) + [t[0]]
    tokens = word(expression)
    mapping = {0:171, 1:177, 'a':166, 'b':121, 'n':168,
               'I':119, 'Q':180, 'R':181, 'N':218}
    lo, old_hi = 2643, 4556
    expected = []
    for token in tokens:
        a, z = ranges[str(mapping[token])]
        offset = lo + len(expected)
        for op, arg, targets in go[a:z]:
            need(all(a <= t <= z for t in targets), 'nonclosed macro')
            expected.append((op, arg, tuple(offset+t-a for t in targets)))
    new_hi = lo + len(expected)
    need(gn[lo:new_hi] == expected, 'primitive expression/CFG mismatch')
    def remap(i):
        if i <= lo: return i
        if i >= old_hi: return i + new_hi - old_hi
        raise ValueError('outside branch enters replaced interior')
    exterior = 0
    for i, (op, arg, targets) in enumerate(go):
        if lo <= i < old_hi: continue
        need(gn[remap(i)] == (op, arg, tuple(map(remap, targets))),
             'exterior primitive/CFG changed')
        exterior += 1
    stack = ['old-stack']
    current = 'old-current'
    for t in tokens:
        if t in mapping and t not in ('I','Q','R','N'):
            stack.append(current); current = t
        elif t == 'N': current = ('N', current)
        else: current = (t, stack.pop(), current)
    need(current == expression, 'postfix expression result differs')
    need(stack == ['old-stack', 'old-current'], 'stack effect differs')
    result = {'status': 'EXACT_EXPRESSION_AND_CFG_BINDING_PASS',
              'candidate_sha256': hashlib.sha256(CANDIDATE.read_bytes()).hexdigest(),
              'expression': expression, 'postfix_word': tokens,
              'old_replacement_interval': [lo, old_hi],
              'new_replacement_interval': [lo, new_hi],
              'new_primitive_instructions_bound': len(expected),
              'unchanged_exterior_primitives_and_edges': exterior,
              'net_stack_effect': 'Push prior current once, then compute stated new bundle.',
              'calibration_status': 'UNRESOLVED: recover full membership vacuity before using inherited completeness.',
              'machine_state_count_claim': None}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
