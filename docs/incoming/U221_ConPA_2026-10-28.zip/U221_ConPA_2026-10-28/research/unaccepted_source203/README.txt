UNACCEPTED SOURCE-LEVEL RESEARCH CANDIDATE

This is not the source of the verified U221 machine. U221 retains the exact
U222 source under baseline/u222/machine/sites.json.

The file sites.json is a concrete 203-shared-node,3891-primitive alternative
source. Its maximum depth is 45 and maximum zero run is 6. It hoists an output
quantifier across a membership-vacuity conjunct under the old freshness
gate. Ordinary first-order equivalence is insufficient for acceptance:
the restricted numerical proof calculus obtains membership vacuity from
the original bundle before proving full logical completeness. The new
bundle puts that conjunct under an existential quantifier. A noncircular
derivation of the required vacuity family from the retained rows and new
bundle remains to be supplied.

There is no compiled literal transition table for this source and no
claimed machine-state saving. Full numerical calibration, source binding,
literal compilation, initialization and universal runtime checks would be
needed before it could replace the source of any accepted machine.

Candidate SHA256:
da44fb080fecf057fb8f9c0cd143487e5da2bb17a38a102a4d8d517cedd8ff0a

See ../source_search_notes.txt for exact search scope and other obstructions.
