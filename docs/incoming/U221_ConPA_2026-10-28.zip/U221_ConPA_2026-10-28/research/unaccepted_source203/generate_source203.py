#!/usr/bin/env python3
"""Reconstruct the UNACCEPTED 203-subtree hoisted-bundle research source.

Adapted source-tree/closed-splice mechanics: ProveIt K215 / U222 release,
ultimately the K225/K226 source-language packet and Wade's MIT-0 framework.
Preserve the corresponding attribution notices with redistribution.

This is a source construction, not a machine reduction. Membership-vacuity
bootstrapping in the weak numerical calculus remains unproved. Ordinary
first-order equivalence of the hoisted bundle is insufficient for that step.
"""
from pathlib import Path
from functools import cache
import argparse
import hashlib
import json


def need(ok, message):
    if not ok:
        raise ValueError(message)


def leaf(t):
    return isinstance(t[0], str)


def parse(rows):
    instructions = {p: (op, arg) for p, op, arg in rows}
    need(len(instructions) == len(rows), 'duplicate instruction')
    prefixes = {p[:i] for p in instructions for i in range(len(p))}
    need(not prefixes.intersection(instructions), 'overlapping instruction')
    need(all(p+b in prefixes or p+b in instructions
             for p in prefixes for b in '01'), 'nonbinary source tree')
    def visit(p):
        return instructions[p] if p in instructions else (visit(p+'0'), visit(p+'1'))
    t = visit('')
    need(sites(t) == rows, 'noncanonical source ordering')
    return t


def sites(t, p=''):
    return [[p, *t]] if leaf(t) else sites(t[0], p+'0') + sites(t[1], p+'1')


@cache
def size(t):
    return 1 if leaf(t) else size(t[0])+size(t[1])


@cache
def boundary(t):
    if leaf(t):
        op, arg = t
        return (1 if op == 'CD' else arg if op == 'CB' else 0,
                arg if op == 'CC' else 0, op == 'CH')
    a, b = boundary(t[0]), boundary(t[1])
    return max(a[0]-1, b[0], 0), max(a[1], b[1]-1, 0), a[2] or b[2]


def serial(parts):
    need(bool(parts), 'empty source factor')
    return parts[0] if len(parts) == 1 else (parts[0], serial(parts[1:]))


def closed_factor(t, lo, hi):
    result = []
    def visit(n, start):
        end = start+size(n)
        if end <= lo or hi <= start:
            return
        if lo <= start and end <= hi:
            need(boundary(n) == (0, 0, False), 'factor escapes its interval')
            result.append(n)
            return
        need(not leaf(n), 'part of a primitive')
        visit(n[0], start)
        visit(n[1], start+size(n[0]))
    visit(t, 0)
    need(sum(map(size, result)) == hi-lo, 'factor size differs')
    return serial(result)


def splice(t, lo, hi, replacement):
    inserts = 0
    def visit(n, start):
        nonlocal inserts
        end = start+size(n)
        if end <= lo or hi <= start:
            return n
        if lo <= start and end <= hi:
            need(boundary(n) == (0, 0, False), 'removed factor is not closed')
            if start == lo:
                inserts += 1
                return replacement
            return None
        need(not leaf(n), 'partial primitive replacement')
        a = visit(n[0], start)
        b = visit(n[1], start+size(n[0]))
        if a is None:
            need(b is None or boundary(b)[:2] == (0, 0), 'open right remainder')
            return b
        if b is None:
            need(boundary(a)[:2] == (0, 0), 'open left remainder')
            return a
        return a, b
    answer = visit(t, 0)
    need(inserts == 1, 'replacement count')
    return answer


def metrics(t):
    seen = set()
    def visit(n):
        if n in seen:
            return
        seen.add(n)
        if not leaf(n):
            visit(n[0])
            visit(n[1])
    visit(t)
    rows = sites(t)
    return {'dag_nodes': len(seen), 'leaf_occurrences': len(rows),
            'maximum_depth': max(len(p) for p, _, _ in rows),
            'maximum_zero_run': max(len(z) for p, _, _ in rows for z in p.split('1'))}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline', type=Path, required=True,
                    help='U222 inputs/k215_sites.json, the pinned K215 source')
    ap.add_argument('--recipe', type=Path,
                    default=Path(__file__).with_name('hoisted203_recipe.json'))
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    recipe = json.loads(args.recipe.read_text())
    raw = args.baseline.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == recipe['baseline_sha256'], 'baseline hash')
    old = parse(json.loads(raw))
    macros = {k: closed_factor(old, *v) for k, v in recipe['macro_intervals'].items()}
    def decode(x):
        if isinstance(x, str):
            return macros[x]
        if isinstance(x, dict):
            need(set(x) == {'primitive'}, 'unknown recipe field')
            return tuple(x['primitive'])
        need(isinstance(x, list) and len(x) == 2, 'invalid recipe node')
        return decode(x[0]), decode(x[1])
    replacement = decode(recipe['replacement'])
    need(boundary(replacement) == (0, 0, False), 'open replacement')
    result = splice(old, *recipe['replacement_interval'], replacement)
    need(boundary(result) == (0, 0, True), 'global source boundary')
    data = (json.dumps(sites(result), separators=(',', ':'))+'\n').encode('ascii')
    digest = hashlib.sha256(data).hexdigest()
    need(digest == recipe['expected_sha256'], 'result hash')
    info = metrics(result)
    need(info == recipe['expected_metrics'], 'source metrics')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(data)
    print(json.dumps({'status': 'UNACCEPTED_RESEARCH_SOURCE_RECONSTRUCTED',
                      'sha256': digest, **info,
                      'unproved_obligation': recipe['obligation']}, indent=2))


if __name__ == '__main__':
    main()
