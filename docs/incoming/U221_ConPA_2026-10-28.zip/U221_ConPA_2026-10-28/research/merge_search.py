"""Search contextual whole-state folds, testing only old differing-row cases first.
A candidate is never accepted on this screen; survivors need full validation.
"""
from pathlib import Path
import sys,json,time,collections,multiprocessing
BASE=Path(__file__).resolve().parents[1]/'baseline/u222'
sys.path.insert(0,str(BASE/'code/runtime'))
import symbolic_runtime as s
T=s.r.table(BASE/'machine/u.native.tm')
S=sorted({q for q,b in T})
MP={int(k):int(v)for k,v in json.loads((BASE/'code/inputs/legacy_mapping.json').read_text()).items()}
for q in S+[254]:MP.setdefault(q,q+1000)
SS=json.loads((BASE/'machine/sites.json').read_text())
CS=json.loads((BASE/'evidence/runtime_cases.json').read_text())
ROWCASES=collections.defaultdict(list)
for c in CS:
 for q,b in c['rows']:ROWCASES[q,b].append((c['site_index'],c['positive']))

def trial(args):
 q,r,b=args
 t={(a,bit):(w,d,r if z==q else z)for(a,bit),(w,d,z)in T.items()if a!=q}
 lt={(MP[a],bit):(w,d,MP[z])for(a,bit),(w,d,z)in t.items()}
 cc=ROWCASES[MP[q],1-b]
 # Most diverse first cases, then exhaust remainder if still successful.
 seen=set();samples=[]
 for i,pos in cc:
  key=SS[i][1],SS[i][2],pos
  if key not in seen:seen.add(key);samples.append((i,pos))
 samples+=list(cc)
 try:
  lemmas,_=s.prove_blocks(lt)
  done=set()
  for i,pos in samples:
   if(i,pos)in done:continue
   s.case(lt,lemmas,SS[i],pos);done.add((i,pos))
  return {'merge':[q,r],'same_bit':b,'checked_cases':len(done),'status':'SURVIVED'}
 except Exception as e:
  return {'merge':[q,r],'status':'NOT_PROVED','reason':str(e)[:100]}
if __name__=='__main__':
 fixed={0,40,64,84,97,254}
 tasks=[]
 for q in S:
  if q in fixed:continue
  for r in S:
   if r==q:continue
   for b in (0,1):
    if T[q,b]==T[r,b]:tasks.append((q,r,b));break
 print('tasks',len(tasks),flush=True)
 results=[];start=time.monotonic()
 with multiprocessing.Pool(3) as pool:
  for x in pool.imap_unordered(trial,tasks,chunksize=1):
   results.append(x)
   if x['status']=='SURVIVED':print(x,flush=True)
   if len(results)%50==0:print('checked',len(results),'seconds',round(time.monotonic()-start,2),flush=True)
 Path(__file__).with_name('merge_search.json').write_text(json.dumps(results,indent=2)+'\n')
 print('complete',len(results),round(time.monotonic()-start,2),flush=True)
