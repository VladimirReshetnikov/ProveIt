#!/usr/bin/env python3
"""Construct U221 from the frozen U222 table by one guarded state quotient.

This deterministic builder does not search, optimize, or evaluate any proof
enumerator. The independent audit and the paper establish correctness.
All integrity checks remain enabled with Python -O.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

BASELINE_SHA = '88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427'
NATIVE_SHA = 'ea6b259004292b7e8268c20d041ce29ed0b0e7e5428108949b095c40e5a9a7a2'
DENSE_SHA = 'c40abea4044f003fea96ff63ae89052e53d33aee154da74c156163deab06979e'
SOURCE_SHA = '1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_table(data):
    start = None
    table = {}
    for line in data.decode('ascii').splitlines():
        if line.startswith('#! start '):
            require(start is None, 'Duplicate start declaration')
            start = int(line[9:])
        elif line.strip() and not line.startswith('#'):
            fields = line.split()
            require(len(fields) == 5, 'Invalid transition width')
            q, bit, write, direction, target = fields
            q, bit, write, target = map(int, (q, bit, write, target))
            require((q, bit) not in table, 'Duplicate transition')
            require(bit in (0, 1) and write in (0, 1), 'Invalid bit')
            require(direction in ('L', 'R'), 'Invalid movement')
            table[q, bit] = write, direction, target
    require(start == 0, 'Unexpected initial state')
    return table


def encode(table):
    rows = ''.join(f'{q} {b} {w} {d} {z}\n'
                   for (q, b), (w, d, z) in sorted(table.items()))
    return ('#! start 0\n' + rows).encode('ascii')


def validate(table, halt, expected_count):
    states = {q for q, _ in table}
    require(len(states) == expected_count, 'Wrong working-state count')
    require(0 in states and halt not in states, 'Start/halt error')
    require(set(table) == {(q, b) for q in states for b in (0, 1)},
            'Working table is not complete and binary')
    require({z for _, _, z in table.values()} - states == {halt},
            'Undefined target other than the halt')
    reached = {0}
    frontier = [0]
    for q in frontier:
        for bit in (0, 1):
            target = table[q, bit][2]
            if target != halt and target not in reached:
                reached.add(target)
                frontier.append(target)
    require(reached == states, 'Unreachable state in the transition graph')
    return states


def construct(baseline):
    raw = baseline.read_bytes()
    require(sha(raw) == BASELINE_SHA, 'Frozen U222 hash mismatch')
    old = read_table(raw)
    validate(old, 254, 222)
    require(old[200, 0] == old[209, 0] == (0, 'R', 157),
            'Live transition mismatch')
    require([k for k, v in old.items() if v[2] == 200] == [(112, 1)],
            'Unexpected predecessor of state 200')
    require([k for k, v in old.items() if v[2] == 112] == [(172, 0)],
            'Unexpected predecessor of state 112')
    require(old[172, 0] == (0, 'L', 112), 'Written-zero premise differs')
    require(old[112, 1] == (1, 'R', 200), 'Return premise differs')

    def quotient(q):
        return 209 if q == 200 else q

    native = {(q, b): (w, d, quotient(z))
              for (q, b), (w, d, z) in old.items() if q != 200}
    states = validate(native, 254, 221)
    native_raw = encode(native)
    require(sha(native_raw) == NATIVE_SHA, 'Native result hash mismatch')
    rename = {q: i for i, q in enumerate(sorted(states))}
    rename[254] = 221
    dense = {(rename[q], b): (w, d, rename[z])
             for (q, b), (w, d, z) in native.items()}
    validate(dense, 221, 221)
    dense_raw = encode(dense)
    require(sha(dense_raw) == DENSE_SHA, 'Dense result hash mismatch')
    inverse = {v: k for k, v in rename.items()}
    require({(inverse[q], b): (w, d, inverse[z])
             for (q, b), (w, d, z) in dense.items()} == native,
            'State renaming is not an exact table isomorphism')
    mapping = {
        'u222_native_to_u221_native': {str(q): quotient(q)
                                      for q in sorted({q for q, _ in old} | {254})},
        'u221_native_to_dense': {str(q): v for q, v in rename.items()},
        'native_halt': 254,
        'dense_halt': 221,
        'start': 0,
    }
    summary = {
        'name': 'U221',
        'working_states': 221,
        'transition_rows': 442,
        'graph_reachable_working_states': 221,
        'native_halt': 254,
        'dense_halt': 221,
        'blank_symbol': 0,
        'start_state': 0,
        'removed_native_states': [200],
        'changed_retained_native_rows': [[112, 1, 1, 'R', 209]],
        'u222_native_sha256': BASELINE_SHA,
        'native_sha256': NATIVE_SHA,
        'dense_sha256': DENSE_SHA,
        'unchanged_source_sha256': SOURCE_SHA,
        'theorem': 'Exact tape, head, and time preservation from state 0 on any tape.',
        'endpoint_dependency': 'The supplied U222 consistency theorem transfers.',
        'kernel_status': 'No newly compiled end-to-end proof-assistant certificate.',
    }
    return native_raw, dense_raw, mapping, summary


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path,
                        default=root / 'baseline/u222/machine/u.native.tm')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    native, dense, mapping, summary = construct(args.baseline)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'u221.native.tm').write_bytes(native)
    (args.output / 'u221.tm').write_bytes(dense)
    for name, value in [('state_map.json', mapping), ('summary.json', summary)]:
        (args.output / name).write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
