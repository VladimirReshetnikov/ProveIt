#!/usr/bin/env python3
"""Generate the complete dense transition-table appendix from the .tm file."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
table = {}
for line in (ROOT / 'machine/u221.tm').read_text().splitlines():
    if line and not line.startswith('#'):
        q, bit, write, direction, target = line.split()
        table[int(q), int(bit)] = write + direction + ('H' if target == '221' else target)

header = r'\toprule ' + ' & '.join(['State & Read 0 & Read 1'] * 3)
header += r'\\\midrule'
rows = [r'\begingroup\small\setlength{\tabcolsep}{7pt}',
        r'\begin{longtable}{rll@{\qquad}rll@{\qquad}rll}', header,
        r'\endfirsthead',
        header,
        r'\endhead', r'\bottomrule\endfoot']
for q in range(74):
    entries = []
    for r in (q, q + 74, q + 148):
        if r <= 220:
            entries.append(f'{r} & {table[r, 0]} & {table[r, 1]}')
        else:
            entries.append(' & & ')
    rows.append(' & '.join(entries) + r'\\')
rows += [r'\end{longtable}\endgroup', '']
(ROOT / 'paper/transition_table.tex').write_text('\n'.join(rows))
print('Generated all 221 states and 442 transitions.')
