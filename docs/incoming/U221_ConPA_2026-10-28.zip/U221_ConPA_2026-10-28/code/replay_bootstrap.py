#!/usr/bin/env python3
"""Independently replay U222, U221 native, and U221 dense from blank.

The checkpoint is a finite test separate from the unbounded quotient proof.
Every tape, head, and renamed state is compared at every step.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    transitions = {}
    start = None
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            require(start is None, 'Repeated start declaration')
            start = int(line.split()[-1])
        elif line and not line.startswith('#'):
            q, b, w, move, target = line.split()
            key = int(q), int(b)
            require(key not in transitions, 'Repeated transition')
            require(move in ('L', 'R'), 'Invalid move')
            transitions[key] = int(w), (-1 if move == 'L' else 1), int(target)
    require(start == 0, 'Invalid initial state')
    return transitions


def tick(table, configuration):
    q, h, tape = configuration
    w, d, target = table[q, int(h in tape)]
    if w:
        tape.add(h)
    else:
        tape.discard(h)
    return target, h + d, tape


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    paths = [root / 'baseline/u222/machine/u.native.tm',
             root / 'machine/u221.native.tm', root / 'machine/u221.tm']
    tables = list(map(load, paths))
    mapping = json.loads((root / 'machine/state_map.json').read_text())
    dense = {int(q): z for q, z in mapping['u221_native_to_dense'].items()}
    checkpoint = json.loads((root / 'baseline/u222/evidence/startup.json').read_text())
    require(checkpoint['steps'] == 95714, 'Unexpected baseline checkpoint')
    configurations = [(0, 0, set()), (0, 0, set()), (0, 0, set())]
    visits = 0
    for time in range(checkpoint['steps'] + 1):
        old, new, canonical = configurations
        expected_q = 209 if old[0] == 200 else old[0]
        require(new == (expected_q, old[1], old[2]), f'Native mismatch at {time}')
        require(canonical == (dense[new[0]], new[1], new[2]),
                f'Dense mismatch at {time}')
        if old[0] == 200:
            require(old[1] not in old[2], 'Guard failure during bootstrap')
            visits += 1
        if time < checkpoint['steps']:
            configurations = [tick(t, c) for t, c in zip(tables, configurations)]
    q, head, tape = configurations[1]
    require(q == checkpoint['state'] == 84, 'Incorrect final state')
    require(head == checkpoint['head'] == -8, 'Incorrect final head')
    require(sorted(tape) == checkpoint['one_cells'], 'Incorrect complete tape')
    result = {
        'status': 'THREE_LITERAL_BLANK_RUNS_PASS',
        'steps': checkpoint['steps'],
        'configurations_compared': checkpoint['steps'] + 1,
        'original_state_200_visits': visits,
        'native_final_state': q,
        'dense_final_state': dense[q],
        'head': head,
        'one_cells': sorted(tape),
        'gap': checkpoint['gap'],
        'logical_registers': checkpoint['registers'],
        'spares': checkpoint['spares'],
        'table_sha256': [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths],
        'scope': 'Finite bootstrap; unbounded equivalence proved by the invariant.',
    }
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('one_cells', 'spares')}, indent=2))


if __name__ == '__main__':
    main()
