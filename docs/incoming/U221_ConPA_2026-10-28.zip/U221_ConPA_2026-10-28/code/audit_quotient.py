#!/usr/bin/env python3
"""Independent exact audit of the U222 -> U221 guarded state quotient.

This does not import the allocator, source compiler, or symbolic runtime. Its
certificate is the unique two-transition write-return predecessor pattern.
The accompanying proof note gives the quantified run argument. Tests here
check finite premises and exact transition-map equations, not run samples.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path

ERASE = 200
KEEP = 209
VIA = 112
WRITER = 172
LIVE_BIT = 0


def require(condition, description):
    if not condition:
        raise ValueError(description)


def parse(path):
    rows = {}
    start = None
    for line in Path(path).read_text(encoding='ascii').splitlines():
        if line.startswith('#! start '):
            require(start is None, 'duplicate start declaration')
            start = int(line.split()[-1])
        elif line.strip() and not line.startswith('#'):
            fields = line.split()
            require(len(fields) == 5, 'bad transition format')
            q, b, w, direction, target = fields
            q, b, w, target = map(int, (q, b, w, target))
            require(b in (0, 1) and w in (0, 1), 'nonbinary symbol')
            require(direction in ('L', 'R'), 'bad direction')
            require((q, b) not in rows, 'duplicate transition')
            rows[q, b] = w, direction, target
    require(start is not None, 'missing start declaration')
    states = {q for q, _ in rows}
    require(start in states, 'start outside working states')
    require(all((q, b) in rows for q in states for b in (0, 1)),
            'partial working-state row')
    undefined = {t for _, _, t in rows.values()} - states
    require(undefined == {254}, 'unexpected halt/undefined targets')
    return start, rows


def image(q):
    return KEEP if q == ERASE else q


def incoming(rows, state):
    return sorted((q, b) for (q, b), (_, _, t) in rows.items() if t == state)


def check_guard(start, rows):
    require(start not in (ERASE, VIA), 'initial state evades predecessor history')
    require(incoming(rows, ERASE) == [(VIA, 1)], 'erased-state predecessors differ')
    require(incoming(rows, VIA) == [(WRITER, 0)], 'via-state predecessors differ')
    written, outward, next_state = rows[WRITER, 0]
    _, returning, final_state = rows[VIA, 1]
    require(written == LIVE_BIT, 'writer does not establish live input bit')
    require((outward, returning) in (('L', 'R'), ('R', 'L')),
            'two moves do not return to written cell')
    require(next_state == VIA and final_state == ERASE, 'broken two-step chain')
    return {'start': start, 'erased_state': ERASE, 'survivor_state': KEEP,
            'via_state': VIA, 'writer_state': WRITER,
            'incoming_erased': incoming(rows, ERASE),
            'incoming_via': incoming(rows, VIA),
            'writer_transition': list(rows[WRITER, 0]),
            'return_transition': list(rows[VIA, 1]),
            'reachable_read_symbol': LIVE_BIT,
            'scope': 'Every initial tape with the declared start state.'}


def make_quotient(rows):
    return {(q, b): (w, d, image(t))
            for (q, b), (w, d, t) in rows.items() if q != ERASE}


def check_exact_quotient(source_start, source, target_start, target):
    guard = check_guard(source_start, source)
    require(target_start == image(source_start), 'wrong quotient start')
    old_states = {q for q, _ in source}
    new_states = {q for q, _ in target}
    require(new_states == old_states - {ERASE}, 'wrong quotient working states')
    require(set(target) == {(q, b) for q in new_states for b in (0, 1)},
            'wrong quotient transition domain')
    checked = 0
    for (q, b), (w, direction, t) in source.items():
        if q == ERASE and b != LIVE_BIT:
            continue
        expected = w, direction, image(t)
        require(target[image(q), b] == expected,
                f'quotient equation fails at source row {(q, b)}')
        checked += 1
    require(target == make_quotient(source), 'candidate is not the exact quotient')
    return {'guard': guard, 'working_states_before': len(old_states),
            'working_states_after': len(new_states),
            'mapped_source_rows_checked': checked,
            'excluded_source_rows': [[ERASE, 1 - LIVE_BIT]],
            'transition_count_after': len(target)}


def local_invariant_audit(start, source, candidate_start, candidate):
    """Exhaustive finite induction premise, independent of predecessor checks.

    A window at offsets -2..2 contains every tape cell that either antecedent
    or successor invariant can inspect, for a unit left/right transition.
    No unrepresented tape cell is assigned a default value.
    """
    offsets = tuple(range(-2, 3))
    patterns = [dict(zip(offsets, bits))
                for bits in itertools.product((0, 1), repeat=len(offsets))]

    def invariant(q, window, head=0):
        if q == VIA:
            return window[head + 1] == 0
        if q == ERASE:
            return window[head] == 0
        return True

    require(candidate_start == image(start), 'local audit start map fails')
    require(all(invariant(start, p) for p in patterns),
            'initial invariant is not true for every tape')
    states = sorted({q for q, _ in source})
    preserved = 0
    guarded_out = 0
    for q in states:
        for before in patterns:
            if not invariant(q, before):
                guarded_out += 1
                continue
            symbol = before[0]
            w, direction, t = source[q, symbol]
            displacement = 1 if direction == 'R' else -1
            after = dict(before)
            after[0] = w
            require(invariant(t, after, displacement),
                    f'local invariant fails at {(q, symbol)} with {before}')
            new_w, new_direction, new_t = candidate[image(q), symbol]
            require((new_w, new_direction, new_t) == (w, direction, image(t)),
                    f'local commuting square fails at {(q, symbol)}')
            preserved += 1
    return {'window_offsets': list(offsets), 'patterns_per_state': len(patterns),
            'working_states': len(states), 'all_initial_patterns_checked': len(patterns),
            'inductive_cases_checked': preserved, 'excluded_by_invariant': guarded_out,
            'invariant': 'q=112 implies tape(head+1)=0; q=200 implies tape(head)=0',
            'outside_window': 'Arbitrary and uninspected; transition changes only offset 0.',
            'commuting_square': 'All invariant-admissible local patterns checked.'}


def negative_controls(start, source, candidate_start, candidate):
    controls = []

    def reject(name, s, a, t, b):
        try:
            check_exact_quotient(s, a, t, b)
        except ValueError as error:
            try:
                local_invariant_audit(s, a, t, b)
            except (ValueError, KeyError) as local_error:
                local_rejection = str(local_error)
            else:
                raise ValueError('local checker accepted negative control: ' + name)
            controls.append({'name': name, 'status': 'REJECTED', 'reason': str(error), 'local_checker_reason': local_rejection})
        else:
            raise ValueError('negative control unexpectedly accepted: ' + name)

    bad = deepcopy(source)
    _, d, t = bad[WRITER, 0]
    bad[WRITER, 0] = 1, d, t
    reject('wrong bit written before return', start, bad, start, make_quotient(bad))

    bad = deepcopy(source)
    w, _, t = bad[VIA, 1]
    bad[VIA, 1] = w, bad[WRITER, 0][1], t
    reject('return goes in same direction', start, bad, start, make_quotient(bad))

    bad = deepcopy(source)
    w, d, _ = bad[start, 0]
    bad[start, 0] = w, d, ERASE
    reject('unprotected alternative entry to erased state', start, bad,
           start, make_quotient(bad))

    bad = deepcopy(source)
    w, d, _ = bad[start, 0]
    bad[start, 0] = w, d, VIA
    reject('unprotected alternative entry to via state', start, bad,
           start, make_quotient(bad))

    reject('start at erased state', ERASE, source, KEEP, candidate)
    reject('start at via state', VIA, source, VIA, candidate)

    bad = deepcopy(candidate)
    _, d, t = bad[KEEP, LIVE_BIT]
    bad[KEEP, LIVE_BIT] = 1, d, t
    reject('survivor live row writes wrong symbol', start, source, start, bad)

    bad = deepcopy(candidate)
    key = next(k for k, value in source.items() if value[2] == ERASE)
    bad[key] = source[key]
    reject('incoming edge not redirected', start, source, start, bad)

    # The adjacent cell can receive either symbol: it is not the returned-to cell.
    harmless = deepcopy(source)
    w, d, t = harmless[VIA, 1]
    harmless[VIA, 1] = 1 - w, d, t
    check_exact_quotient(start, harmless, start, make_quotient(harmless))
    local_invariant_audit(start, harmless, start, make_quotient(harmless))
    controls.append({'name': 'different write at adjacent cell',
                     'status': 'ACCEPTED_POSITIVE_CONTROL'})
    return controls


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    start, source = parse(args.source)
    candidate_start, candidate = parse(args.candidate)
    result = check_exact_quotient(start, source, candidate_start, candidate)
    result['independent_local_invariant_check'] = local_invariant_audit(
        start, source, candidate_start, candidate)
    result.update(status='EXACT_GUARDED_QUOTIENT_PASS',
                  source_sha256=hashlib.sha256(args.source.read_bytes()).hexdigest(),
                  candidate_sha256=hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
                  verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  negative_controls=negative_controls(start, source, candidate_start, candidate),
                  conclusion='Identical tape, head, and halting times under state map 200 -> 209.',
                  certificate_scope='Finite structural premises for the accompanying quantified proof; no sampled runtime inference.')
    data = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(data)
    print(data, end='')


if __name__ == '__main__':
    main()
