U221: A 221-STATE REDUCTION OF THE PRIMARY U222 MACHINE
28 October 2026

RESULT
------
machine/u221.tm is a deterministic, single-tape, binary Turing machine
with 221 working states, including initialization. It starts in state 0,
head coordinate 0, on a completely blank two-way infinite tape. Its working
states are 0..220 and its separate halt label is 221. There are 442 rows.

The new mathematical theorem proves exact time-preserving equivalence to
the supplied U222 table, from state 0 on EVERY initial tape. In PA,

    Halt(U221, blank) <-> Halt(U222, blank).

Composing this with the supplied U222 and theory-U consistency theorems:

    PA proves Nonhalt(U221, blank) <-> Con(U) <-> Con(PA).

The new reduction is proved independently of the inherited source and
theory interpretation. The consistency endpoint retains their original
status: ordinary mathematical proofs and executable verification, without
a newly compiled end-to-end Lean, Rocq, or MM0 certificate for U221.
No unconditional consistency or nonhalting assertion, global priority,
or state minimality is claimed.

EXACT PATCH IN ORIGINAL NATIVE LABELS
------------------------------------
Delete state 200 and its two rows. Change only this surviving row:

    112 1 1 R 200    ->    112 1 1 R 209

Keep start 0 and native halt 254, then rename the surviving working states
in increasing order to 0..220. The complete map is machine/state_map.json.

WHY IT WORKS
------------
The complete original table has only these incoming transitions:

    into 112: (172,0) -> (0,L,112)
    into 200: (112,1) -> (1,R,200)

Hence every run from state 0 satisfies

    state 112 implies the cell immediately right of the head contains 0;
    state 200 implies the cell under the head contains 0.

The first step writes 0 and moves left; the second moves back to that
unchanged zero. The row200/read 1 is therefore unreachable. Rows200/read 0
and209/read 0 are both (0,R,157). Identifying 200 with 209 preserves each
individual transition on the run. Original state 209 may still read 1;
its row on1 is retained exactly.

The K215 baseline also had215/read 1 ->112. U222 redirected that entry to 61,
creating this stronger invariant. Thus the same proof cannot simply be
applied to K215 to claim a 214-state ZFC machine.

START HERE
----------
paper/report.pdf             Complete report, proof and full dense table.
paper/report.tex             Editable LaTeX source.
machine/u221.tm              Dense literal table, start0 and halt221.
machine/u221.native.tm       Native literal table, start0 and halt254.
machine/state_map.json       Quotient map plus dense-state bijection.
machine/summary.json         Counts, exact patch and SHA256 identities.
code/build.py                Deterministic construction; no solver.
code/audit_quotient.py        Independent structural and local-induction checks.
code/replay_bootstrap.py     Three complete blank runs, compared at every step.
evidence/                    Fresh structural, bootstrap and runtime receipts.
baseline/u222/               The complete original U222 packet, unchanged.
research/                    Search records and an explicitly unaccepted lead.
PROVENANCE.json              Exact inputs and new-result scope.
SHA256SUMS                   Release file integrity manifest.

REPRODUCE
---------
Python3.10+ and the standard library are sufficient. No network or external
repository is needed. From the extracted top-level directory:

    python3 -B reproduce.py --receipt /tmp/u221-receipt.json

This verifies file integrity, reconstructs both tables, checks the guarded
quotient by two independent methods and mutation controls, compares all
three literal blank runs, and reruns the original source/baseline audit.
Its construction and local-invariant components are checked both with and
without Python optimization. The main driver refuses -O because inherited
symbolic verification uses assertions.

To regenerate every U221 arbitrary-register symbolic proof case as well:

    python3 -B reproduce.py --full --receipt /tmp/u221-full.json

The full run takes several minutes. It compares all 5,060 individual case
records and the complete startup trace. The fresh delivered run passed
5060/5060 cases; the domain is arbitrary natural register values and gap,
plus an arbitrary nonempty finite spare-register list. These are inductive
symbolic contracts, not bounded register samples.

Scratch work is temporary; the optional receipt is the only saved output.
The original U222 packet has its own independent reproduce.py and manifest.

To rebuild the PDF, use a standard TeXLive installation:

    cd paper
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex

The table appendix can be regenerated with code/build_table_appendix.py.
PDF byte identities can depend on TeX versions and timestamps. Rebuilding
changes the release manifest's PDF digest, so use a working copy.

VERIFICATION COUNTS
-------------------
221 working states; 442 transitions; all 221 states graph reachable.
443 admissible original transition-map equations.
7072 admissible five-cell invariant cases, plus 32 initial patterns.
Eight negative controls rejected independently by both local checkers.
One harmless adjacent-write positive control accepted by both.
95714 literal blank transitions in each of three presentations.
5060/5060 arbitrary-register primitive cases freshly checked.
The initialization prefix does not visit state 200; its correctness alone
would therefore not validate this optimization.

RESEARCH STATUS
---------------
The bounded directed-fold screen considered 484 candidates. Only 200->112
and 200->209 survived; both express this same one-state saving. The other
482 are NOT_PROVED, not claims of semantic impossibility.

A quantifier-hoisted emitter has 203 shared source nodes rather than 204,
but it introduces an unresolved numerical-calculus membership-vacuity
obligation and has no compiled literal table. It is clearly separated in
research/unaccepted_source203/. It is not the source of U221, and its node
count is not a machine-state bound.

ATTRIBUTION
-----------
The U222 packet, supplied theory-U manuscript, K215 framework, and upstream
Mira/Wade/busy-beaver contributions retain their original notices and
terms. See NOTICE.txt and baseline/u222/licenses/. Separate assistant
audits are internal reviews during this research session, not external
human endorsements.
