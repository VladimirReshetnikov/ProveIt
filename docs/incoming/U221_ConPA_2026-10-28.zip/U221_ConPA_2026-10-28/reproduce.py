#!/usr/bin/env python3
"""Reproduce U221 and its exact quotient certificate using Python's stdlib.

Default: integrity, deterministic construction, both invariant checks and
controls, three blank runs, and U222's source/calibration binding audit.
--full additionally regenerates all 5,060 symbolic runtime cases for U221.
All scratch work is temporary; an optional receipt is the only written output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def run(script, args, folder, name, optimized=False):
    command = [sys.executable, '-B']
    if optimized:
        command.append('-O')
    command.extend([str(script), *map(str, args)])
    log = folder / (name + '.log')
    print('Checking ' + name, flush=True)
    with log.open('w') as output:
        result = subprocess.run(command, cwd=folder, stdout=output,
                                stderr=subprocess.STDOUT, check=False,
                                env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    if result.returncode:
        print(log.read_text(), flush=True)
        raise RuntimeError(name + ' failed')


def check_manifest():
    manifest = ROOT / 'SHA256SUMS'
    require(manifest.is_file(), 'Missing release manifest')
    seen = set()
    for line in manifest.read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts,
                'Unsafe manifest path')
        require(name not in seen, 'Duplicate manifest entry')
        seen.add(name)
        require(sha(ROOT / path) == expected, 'Hash mismatch: ' + name)
    required = {'machine/u221.tm', 'machine/u221.native.tm', 'paper/report.tex',
                'paper/report.pdf', 'code/audit_quotient.py', 'code/build.py'}
    require(required <= seen, 'Principal output missing from manifest')
    return len(seen)


def check_runtime(report, summary, sites):
    total = sum(2 if operation == 'CD' else 1 for _, operation, _ in sites)
    require(report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS', 'Runtime failed')
    require(report['table_sha256'] == summary['native_sha256'], 'Runtime table differs')
    require(report['sites_sha256'] == summary['unchanged_source_sha256'],
            'Runtime source differs')
    require(report['expected_cases'] == report['proved_cases'] == total == 5060,
            'Incomplete runtime case coverage')
    require(report['working_states'] == 221 and report['site_count'] == 3891,
            'Runtime counts differ')
    require(not report['failures'], 'A runtime case failed')
    require(report['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED',
            'Startup was not calibrated')
    runtime = ROOT / 'baseline/u222/code/runtime'
    require(report['checker_sha256'] == sha(runtime / 'symbolic_runtime.py'),
            'Unexpected symbolic checker')
    require(report['helper_sha256'] == sha(runtime / 'independent_runtime.py'),
            'Unexpected symbolic helper')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    require(__debug__ and not sys.flags.optimize,
            'Run without -O; the inherited symbolic checker uses assertions')
    started = time.monotonic()
    count = check_manifest()
    summary = read(ROOT / 'machine/summary.json')
    baseline = ROOT / 'baseline/u222'
    sites = read(baseline / 'machine/sites.json')
    check_runtime(read(ROOT / 'evidence/runtime/runtime.json'), summary, sites)
    with tempfile.TemporaryDirectory(prefix='u221-reproduction-') as directory:
        temporary = Path(directory)
        for optimized, suffix in [(False, 'normal'), (True, 'optimized')]:
            target = temporary / ('build-' + suffix)
            run(ROOT / 'code/build.py', ['--output', target], temporary,
                'construction-' + suffix, optimized)
            for name in ('u221.tm', 'u221.native.tm', 'state_map.json', 'summary.json'):
                require((target / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
                        'Deterministic construction differs: ' + name)
            audit_path = temporary / ('quotient-' + suffix + '.json')
            run(ROOT / 'code/audit_quotient.py',
                [baseline / 'machine/u.native.tm', target / 'u221.native.tm',
                 '--output', audit_path], temporary, 'quotient-' + suffix, optimized)
            audit = read(audit_path)
            require(audit == read(ROOT / 'evidence/guarded_quotient_audit.json'),
                    'Quotient certificate differs')
        run(ROOT / 'code/replay_bootstrap.py',
            ['--output', temporary / 'bootstrap.json'], temporary, 'blank-bootstrap')
        require(read(temporary / 'bootstrap.json') == read(ROOT / 'evidence/bootstrap.json'),
                'Independent blank replay differs')
        run(baseline / 'reproduce.py', ['--report', temporary / 'baseline.json'],
            temporary, 'inherited-source-and-baseline-audit')
        inherited = read(temporary / 'baseline.json')
        require(inherited['status'] == 'U222_RECONSTRUCTION_AUDIT_PASS',
                'Inherited source/baseline audit failed')
        if args.full:
            target = temporary / 'runtime'
            run(baseline / 'code/validate_native.py',
                [ROOT / 'machine/u221.native.tm', baseline / 'machine/sites.json', target],
                temporary, 'all-5060-symbolic-runtime-cases')
            check_runtime(read(target / 'runtime.json'), summary, sites)
            for name in ('runtime_cases.json', 'startup.json'):
                require(read(target / name) == read(ROOT / 'evidence/runtime' / name),
                        'Regenerated runtime evidence differs: ' + name)
        receipt = {
            'status': 'U221_FULL_REPRODUCTION_PASS' if args.full
                      else 'U221_EXACT_REDUCTION_REPRODUCTION_PASS',
            'manifest_files_checked': count,
            'working_states': 221,
            'transition_rows': 442,
            'ordinary_and_optimized_construction_agree': True,
            'ordinary_and_optimized_invariant_checks_agree': True,
            'admissible_source_rows': 443,
            'local_inductive_cases': 7072,
            'negative_controls_rejected_by_both_checkers': 8,
            'positive_controls_accepted_by_both_checkers': 1,
            'blank_steps_in_all_three_presentations': 95714,
            'inherited_source_binding_audit_passed': True,
            'symbolic_runtime_cases': 5060,
            'symbolic_runtime_cases_rerun': args.full,
            'native_sha256': summary['native_sha256'],
            'dense_sha256': summary['dense_sha256'],
            'source_sha256': summary['unchanged_source_sha256'],
            'seconds': round(time.monotonic() - started, 3),
            'proof_status': 'Ordinary PA-formalizable proof and executable certificates; '
                            'no new end-to-end kernel proof.',
        }
    if args.receipt:
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
