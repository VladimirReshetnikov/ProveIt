# K224: an explicit 224-state machine for Con(ZFC)

This contribution constructs a deterministic, two-symbol, one-tape Turing
machine with **224 working states**, strictly fewer than the pinned ProveIt
225-state candidate. It starts in state 0 on the all-zero, two-way infinite
tape, with head position 0. Working states are 0 through 223; **224 is the
separate halting state**. Every transition writes a bit and moves left or right.

The mathematical result is

\[
\mathrm{ZFC}\vdash
\bigl(M_{224}\text{ does not halt on the blank tape}
\iff \operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The definitive table is `portable/machine/results/candidate224.tm`.
Its SHA-256 is:

```text
6361b0b29c2e0485bf8cf025dcf2606c2fac071f3f6e24fbde04016466d92168
```

Read `report/main.pdf` for the mathematical proof, construction, complete
transition table, verification scope, and research alternatives. Its editable
sources are `report/main.tex` and `report/table224.tex`.

## What makes the reduction work

The successful construction combines three changes.

1. **Fuse the formula.** Cancel four double-negation pairs in the K formula
   and its final bundle. Reassociate the closed existential constructor
   program. This removes eight negation constructors and one distinct source
   subtree, but by itself leaves 225 machine states.
2. **Change the equality helper.** Retain full membership vacuity and the
   original bundle gate, but use only the canonical primitive-equality helper
   `Eq(a,b) -> All(RelCode(a,b), Eq(a,b))`, with
   `RelCode(a,b) = 4*P(a,b)+1`. This binder is strictly larger than both
   endpoint labels. The logical interpretation restores the required
   consistency strength. Its K-specific step chooses the private variable
   from the matrix code **after translating equality**. Three closed source
   rotations then expose the useful decoder layout.
3. **Share two decoder states.** In the resulting 225-state parent, inherited
   K states 157 and 191 are entered after writing opposite preceding tape
   bits. Redirect the latter to the former and use existing helper states to
   reproduce their four transitions in blocks of three or five steps.
   This deletes one working state and adds none.

The final fold is independently proved for **every initial binary tape** at
the start state. It preserves the entire tape and head position at simulated
endpoints, has positive block lengths, and preserves halting in both directions.

## Verification results

| Obligation | Result |
|---|---:|
| Working states / literal transition rows | 224 / 448 |
| Working states reachable in the transition graph | 224 |
| Source instruction occurrences | 4,799 |
| Distinct source subtrees, including leaves | 210 |
| Source depth / maximum zero run | 38 / 6 |
| Guarded instruction cases | 6,238 / 6,238 |
| Symbolic runtime rule applications | 1,503,342 |
| Literal rows covered by runtime proof | 448 / 448 |
| Minimum concrete instruction-block duration | 13 steps |
| Largest symbolic case derivation | 403 symbolic steps |
| Exact blank initialization | 409,835 steps |
| One-cells in the complete initialized tape | 351 |
| Final fold block census on the 450 old rows | 446 of length 1, 3 of length 3, 1 of length 5 |

The runtime proof quantifies over all nine independent natural register
values, an arbitrary natural extra gap, an arbitrary first spare value, and
an arbitrary finite remaining spare list. Its symbolic proof-search bounds
are **not bounds on these natural values or on concrete execution time**.
Initialization is checked against the complete finite support, with every
other tape cell zero. The independent fold checker rejects three deliberately
incorrect mutations.

Eleven local register-program bisimulations connect the changed macros to
the pinned upstream arithmetic contracts, with 263 related branch/return
cutpoints. The exact emitter expression is independently reconstructed and
bound to the fusion certificate. The new equality-helper certificate has
68 closed roots and 59,947 checked proof nodes; the fusion certificate has
1,563 nodes. The restored Source116 replays additionally exercise the logical
bootstrap and auxiliary-variable edge cases. The uniform mathematical
arguments, including the arbitrary-matrix K coupling, are in the report and
theory notes; finite parameter examples are not substituted for those proofs.

## Proof status

The archive supplies an ordinary mathematical proof formalizable in ZFC,
literal transition tables, exact reconstruction scripts, and independently
replayed finite and inductive certificates. The pinned predecessor contains
the upstream K230 Rocq development. **This contribution does not claim a newly
compiled end-to-end Rocq or Lean theorem for the exact 224-state table.**
The new equality interpretation, source adapter, and final machine endpoint
remain to be serialized into a proof assistant if that additional gate is
desired for repository acceptance.

Assuming ZFC is consistent, the machine does not halt, and ZFC cannot prove
its non-halting. There is no minimality claim below 224 states.

## Offline reproduction

Use Python 3.10 or newer with assertions enabled. No third-party Python
package, network connection, or proof-assistant installation is required.
Run from the extracted archive's top-level directory, choosing a new output
directory:

```sh
python3 -B portable/reproduce.py --full --full-baseline --output-dir replay
```

This verifies all input manifests, extracts the unchanged predecessor,
replays its full K226/K225 checks, reconstructs the changed source and its
parent table, links those freshly generated bytes to the machine module,
checks the final fold and initialization, replays the logical certificates,
binds the fusion proof to the **freshly reconstructed** emitter expression,
and rederives all 6,238 unbounded runtime cases. It writes phase logs and a
machine-readable `replay.json` to the output directory. A complete run takes
several minutes on the development environment; time varies by machine.

The options are independent:

```sh
# Fresh source, fold, initialization and logic checks; audit stored runtimes.
python3 -B portable/reproduce.py --output-dir replay-quick

# Also rederive the final 224-state runtime, retaining the upstream quick mode.
python3 -B portable/reproduce.py --full --output-dir replay-final-runtime
```

`--full-baseline` passes the predecessor's `--full --full-baseline` options
to its driver. Combining it with `--full` gives the complete replay above.
Do not use `-O`, `-OO`, or `PYTHONOPTIMIZE` with the aggregate or source checks.
Packaged files are kept immutable; fresh outputs go to the selected replay
directory. The two new logical certificate checkers themselves use explicit
checks and were also verified with Python optimization enabled.

To rebuild the report, run twice in `report/`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

## Review map

| Path | Purpose |
|---|---|
| `report/` | Complete LaTeX report, PDF, and exact printed table |
| `portable/reproduce.py` | Aggregate offline reproduction |
| `portable/verification/` | Exact source construction, local macro bisimulations, emitter contract |
| `portable/parent225/` | Canonical-helper parent, source, startup support, source certificates, runtime evidence |
| `portable/machine/` | Final 224-state tables, maps, construction, independent fold and runtime proofs |
| `portable/theory/` | New K/equality and enumerator arguments, finite logical certificates, restored Source116 subset |
| `portable/vendor/` | Unchanged complete K225 predecessor ZIP |
| `research/` | Additional equiconsistency results and scoped negative-search evidence |
| `verification/` | Recorded aggregate replay receipt and PDF QA record |
| `PROVENANCE.json` | Pinned repositories, hashes, artifact identity, and proof boundary |
| `SHA256SUMS` | Hashes of the final distributed files |

The K-labelled parent and final tables use inherited sparse names with halt
254. A separate legacy numbering supports the unchanged symbolic-runtime
engine. `renumbering224.json` explicitly relates these to the canonical
consecutive numbering. Only the canonical table uses working states 0–223
and halt 224.

## Additional mathematical results

The report proves that **conditionally seeded K plus irreflexivity is
equiconsistent with ZFC**. A two-marker hereditary-domain interpretation
recovers an empty object internally and then the unconditional K schema.
The detailed proof is in `research/conditional_k_calibration.md`.

A related interpretation with no raw empty object supports fixed native
input/output labels `(0,1)`, including the otherwise troublesome codes 0
and 1. That alternative is calibrated in
`research/native_fixed01_calibration.md`, but its direct source encoding
had 219 distinct subtrees and did not yield a smaller machine here.

Deleting the support clause from K is insufficient: the weakened theory has
the explicit model `(Q,<,=)`. The obstruction and other equivalent K shapes
are recorded in `research/k_schema_obstructions.md`. Logical formula size,
source subtree count, and final machine-state count are kept separate.

## Starting points and attribution

The ProveIt checkout is pinned to
`ad8cbe8249445f43408617e88a0edb668b00248d`. The unchanged
`K225_Construction_2026-10-19.zip` is the immediate predecessor, with SHA-256
`75b58ce7b5840ef3a3158341f7cf1e601aab67d19ab147d96cf37d1186cb6cbc`.
Its K230 dependency is Elliot Glazer's development at
`3142e4dd980f0be12f4abb636c4ae2528afc17eb`.

The contribution reuses ProveIt's Source116 logical proof subset and
Source124/K225 runtime machinery with exact hash records. `NOTICE.md` and
the unchanged predecessor preserve attribution and third-party license
information. The new material uses ProveIt's MIT No Attribution license.
