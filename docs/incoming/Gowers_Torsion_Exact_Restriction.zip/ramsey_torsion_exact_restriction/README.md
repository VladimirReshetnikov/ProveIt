# Exact Freiman Restriction in Arbitrary Finite Abelian Groups

**Torsion-uniform coloring, relation-energy retention, and logarithmic order barriers**

Research manuscript prepared for the ProveIt project, dated 6 October 2026.
Mathematical development and exact computational checks with ChatGPT.

## Main results

For a graph Γ of a map between arbitrary finite abelian groups, with
`|Γ − Γ| ≤ K |Γ|`, the whole domain admits a partition into at most

`5m K^((2m+1) log_2(5m))`

exact order-m Freiman restrictions. A sharper bound uses the actual number of
vertical defects. The partition retains weighted additive energies with
explicit losses and retains any one specified scalar correlation on some cell.

If the graph has at least `alpha |B|^15` respected additive sixteen-tuples, an
exact order-eight restriction satisfies simultaneously

`|B'| ≥ 2^(-2193) alpha^911 |B|`

and

`E_8(B') = E_8^phi(B') ≥ 2^(-35277) alpha^14655 |B|^15`.

The same bounds follow directly from graph additive energy at least
`alpha |B|^3`. All tuples are ordered, and repetitions are allowed. The theorem
holds without a modulus threshold and without restrictions on ambient group
orders, ranks, or exponents.

For the associated forbidden-difference coloring problem, its universal power
exponent satisfies

`floor(log_2(m)) + 1 ≤ b_m ≤ log_2(5m)` for `m ≥ 2`.

Thus `b_m = log_2(m) + O(1)`. Explicit primary-torsion examples prove the lower
bound. A separate canonical-section graph construction gives necessary lower
bounds for graph extraction exponents.

## Scope and mathematical status

This is an AI-assisted, unrefereed research manuscript with full written proofs
and reproducible exact finite checks. No human referee review or proof-assistant
verification is claimed. Publication priority for these formulations has not
been established by an exhaustive literature review.

The BSG and Plünnecke–Ruzsa ingredients are standard and explicitly attributed;
the numerical BSG input used here is deliberately conservative. The general
order-eight size bound is weaker than some existing prime-field bounds in the
repository. Its gains are generality, a complete exact partition, and
threshold-free relation-energy retention. No improved global Szemerédi bound or
full derivative-spectrum compatibility theorem is claimed.

The pinned repository already contains `lemma_9_3_holds`. This article gives a
stronger alternative mathematical route, not a claim to fill an unproved
repository statement. No repository write action was performed.

## Files

- `ramsey_torsion_exact_restriction.tex`: standalone, fully referenced article.
- `ramsey_torsion_exact_restriction.pdf`: compiled 23-page article.
- `code/exact_restriction.py`: standard-library exact finite construction.
- `code/run_checks.py`: exhaustive and sampled exact checks.
- `checks/results.json` and `checks/run.log`: results from the delivered run.
- `INTEGRATION.md`: placement and mathematical interface notes.
- `FORMALIZATION.md`: proposed theorem dependency order; not a Lean proof.
- `SOURCE_AUDIT.md`: source provenance and limits of the inspection.
- `VALIDATION.md`: coverage and mathematical review checklist.
- `Makefile`: compilation and test commands.
- `manifest.json`: package metadata and file digests.

## Build

A TeX Live installation with pdfLaTeX, latexmk, newtx, amsthm, mathtools,
geometry, microtype, fancyhdr, hyperref, bookmark, and xurl is sufficient.
The bibliography is included in the TeX file; BibTeX is not required.

```sh
make paper
```

Without latexmk, run `pdflatex` at least twice until cross-references stabilize.
The article uses only standard installed LaTeX resources; no external figure or
font files are distributed.

## Reproduce the exact checks

Python 3.10 or later, with no third-party dependencies:

```sh
make check
# equivalently:
python3 code/run_checks.py
```

Do not use `python -O`: the checks rely on assertions. The script overwrites
`checks/results.json`; elapsed time will vary. The sampling seed is fixed at
20261006. The module explicitly enumerates finite groups and sumsets: it is a
small-instance reference implementation, not a compressed-input polynomial-time
algorithm.

## Suggested integration destination

`Combinatorics/Ramsey/Research/GowersSzemeredi/torsion-exact-restriction/`

The source uses the `ter:` label prefix. Retain the mathematical status and
source notes when integrating; do not update a formalization ledger on the basis
of this package alone.
