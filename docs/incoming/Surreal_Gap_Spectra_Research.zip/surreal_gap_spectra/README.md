# Cofinality Compression and Coordinate Spectra of Old Surreal Fields

**Research manuscript dated 28 September 2026.**

The package contains the LaTeX source and compiled PDF, a proof/dependency audit,
source provenance, and finite executable checks. It responds to the spectrum and
simultaneous-real-form questions in the ProveIt surreal-fields-across-universes
report at commit `e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`.

## Main results

1. The exact character spectrum of an old surreal field is the image of its
   **pointed, ground-regular fresh-function spectrum under outer cofinality**.
   The paper proves both coding directions and reproves the fresh-sign/gap
   correspondence.

2. For an infinite ground-regular cardinal kappa, forcing with
   `Fn_{<kappa}(kappa,2)` produces exactly the character kappa, without a GCH or
   `2^{<kappa}=kappa` assumption. The same result holds for the single-collapse
   presentation `Fn_{<kappa}(kappa,theta)`, theta >= kappa. The proof measures the
   density of an old presentation in the extension and uses the generic string
   to enumerate all old short strings.

3. Under ground GCH, take a full countable product of Cohen forcings at strictly
   increasing uncountable regular cardinals kappa_n with supremum lambda. In the
   one common extension, omit any coordinate set F from an intermediate ground.
   Its old surreal field has exactly the characters kappa_n for n in F, plus
   lambda^+ **if and only if F is infinite**. The infinite case uses a precisely
   identified published singular-product theorem. The relative argument uses
   short-name localization and intersections of mutually generic extensions;
   it does not assume that old factors remain closed in intermediate grounds.

4. In GBC with Global Choice, one surcomplex field has continuum many pairwise
   nonconjugate involutions agreeing with ordinary conjugation on its ordinary
   complex numbers, with equal saturation thresholds and different full gap
   spectra. Their fixed fields have no set-sized cofinal subsets. Within this
   coordinate family, the spectrum recovers F and classifies the fields.

Here a character mu abbreviates the symmetric pair (mu,mu), and only gaps with
set-sized cofinal and coinitial presentations are considered.

## Files

- `article.tex`: standalone LaTeX source, with an internal bibliography.
- `article.pdf`: compiled article.
- `PROOF_AUDIT.md`: assumptions, dependencies, verification limits, and review targets.
- `SOURCES.md`: pinned repository sources and primary literature.
- `verify_finite.py`: standard-library-only finite tests.
- `verification_results.json`: results of the actual test run.
- `BUILD_REPORT.md`: PDF and build checks.
- `Makefile`: build and test commands.

## Build

A TeX distribution with `newtxtext`, `newtxmath`, `microtype`, `cleveref`,
`hyperref`, `xurl`, and the usual AMS packages is sufficient. For example:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Without latexmk, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times to stabilize the contents and cross-references.

Run the finite tests with Python 3.10 or later:

```sh
python3 verify_finite.py --output verification_results.json
```

No third-party Python libraries or network access are needed for those tests.

## Mathematical and priority status

These are written mathematical proofs in a research manuscript, not a completed
Lean formalization or an independently refereed publication. The advanced
forcing input is credited to Fischer, Koelbing, and Wohofsky, specifically
Proposition 4.10 and Corollary 4.21 of *Fresh function spectra* (2023). The
underlying singular-product theorem is credited to Shelah in that source.

The claimed progress is relative to the precise repository questions inspected.
The manuscript does not claim priority over all literature, classify arbitrary
real forms or arbitrary forcings, or solve the published general fresh-spectrum
realization problem. Its eight further research questions state the remaining
boundaries.

The finite tests check sign-order identities, finite block coding, a finite
condition-extension operation, and coordinate-mask bookkeeping. They do **not**
verify freshness, genericity, infinite cofinality, cardinal preservation,
saturation, or any proper-class argument.
