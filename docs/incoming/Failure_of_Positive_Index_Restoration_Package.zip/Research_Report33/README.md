# Research Report 33

## Failure of positive index restoration

The report proves that for every actual complete74 compiler export and every
positive ordinary input, the signed19 eliminated child has infinitely many
strictly positive supplied-witness zeros with reconstructed R < 0. The input
root is positive. A negative W is an allowed computed register, not a supplied
coordinate. The positive parent theorem and established universal74/86 bounds
are unaffected.

Appendix A proves the broader algebraic interface theorem for every integer
d >= 1 with B = 2^d, positive odd b, nonnegative K0, and arbitrary fixed integral
mask ports. These arbitrary ports are not asserted to be compiler exports.
Appendix B gives audited necessary conditions for raw29/positive21 and explicitly
leaves those two domains unresolved.

## Contents

- Research_Report33.pdf: standalone 17-page mathematical article
- Research_Report33.tex: complete editable LaTeX source
- build_pdf.sh: local offline PDF build with shell escape disabled
- verify_package.py and MANIFEST.json: enclosing identity gate
- repro/: frozen normal/-O arithmetic and source-identity replay for the main proof
- supplements/: separate normal/-O replay and audited Appendix A/B evidence
- context/: later pinned repository note credited for its auxiliary-only result
- QA.json: release verification record
- SHA256SUMS: hashes for the payload plus identity-gate files

## Verify without installation

Python 3.9+ and its standard library suffice. From any working directory:

    python3 -I -B /path/to/Research_Report33/verify_package.py --replay
    python3 -I -B -O /path/to/Research_Report33/verify_package.py --replay

The enclosing launcher first verifies its literal manifest digest and every
payload hash before executing the two separately pinned replay launchers.
Each subpacket authenticates its own inventory before running newly authored
checks from verified bytes. JSON receipt comparison is exact-typed and
byte-for-byte; explicit checks remain active under Python -O. The replay runs
in isolated Python processes from an unrelated directory, puts outputs only in
temporary directories, and does not mutate packaged evidence.

The main suite also checks four tampered copies fail before evidence execution.
No upstream Python module or arithmetic schedule is executed. Upstream .py
files are inert authenticated source evidence. Hashes establish integrity
relative to the independently recorded pins; they are not a digital signature.
The enclosing launcher itself is the final small trust root, identified by
SHA256SUMS and the release record. Do not regenerate hashes to hide a failed check.

## Rebuild the PDF

A standard TeX Live installation with pdfTeX and the packages named in the
LaTeX preamble is required. No network or shell escape is used.

    sh /path/to/Research_Report33/build_pdf.sh /an/external/build/directory

The script prints the resulting PDF path. If the directory argument is omitted,
a fresh temporary directory is allocated; no artifact source is overwritten.
On minimal Debian TeX Live configurations it bootstraps the local pdflatex format
and font map from installed assets, keeping those caches in the build directory.
PDF regeneration is separate from arithmetic verification. The delivered PDF
was rebuilt byte-identically in a fresh extracted packet in the same TeX environment;
cross-version font or TeX differences may legitimately change PDF bytes.

## Evidence limits

The existence theorem depends on Dirichlet's prime-progression theorem,
irrational-rotation density on a free linear progression, and exact Pell
identities. The finite checks corroborate components. They do not locate a
main/first ratio hit or materialize a complete giant child witness.
The outer numerical fixtures use toy fixed numerals, not authenticated compiler
exports. One small auxiliary-only tuple is materialized; it is not a full
child/compiler zero. No machine-specific false acceptance or improved universal
operation bound is claimed.

Core equation sources are pinned to ProveIt commit
2dde7850ffeb9c923a7bd92e3f2ee2b5af0e36ff. A later contextual note is pinned
separately at 93ad43375a4a5610de0cfb25d64f84ec018d02f7 and credited for overlapping
auxiliary-only results. The main and supplementary source manifests record exact
public URLs, Git blob identities, and SHA256 hashes. All original cached source
bytes are preserved. A few historical upstream notes contain their original
example /tmp command locations; these are inert provenance text, not private
paths or paths used by the portable tools. No third-party PDF cache is included.
