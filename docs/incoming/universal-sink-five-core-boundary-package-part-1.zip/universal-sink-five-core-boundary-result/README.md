# The rank four boundary for five vertex cores with universal sinks

## Result

For an arbitrary loopless directed five-vertex core with a finite independent cloud of universal sinks, under independent nonnegative tail and head activities, the two degree-four interior coefficient inequalities hold on the entire face gamma5=0:

- gamma2² >= (9/4) gamma1 gamma3
- gamma3² >= (8/3) gamma2 gamma4

Together with the universal first comparison, this proves rank ultra log concavity at **actual degree four**. Every feasible ordered pair of disjoint endpoint sets is counted once, regardless of its matching witnesses. No transitivity is needed, so preorder cores are included. The fifth vertex's head role is retained when its tail activity is zero.

This package does not infer a general actual-degree-three theorem from the quartic normalization. It is separate from the earlier actual-degree-five and four-core releases.

## Read

- `article/universal-sink-five-core-boundary.pdf`: complete seven-page theorem and proof
- `article/universal-sink-five-core-boundary.tex` and `article/core-appendix.tex`: editable mathematical source
- `FOUR_ACTIVE_TAILS.md` and `FIVE_TAILS_FINITE_SINKS.md`: expanded ordinary last-gap arguments
- `audits/`: independent exact receipts, per-certificate hashes, and mathematical reviews

The first interior comparison is computer-assisted. Its two exact collections cover 3,044 marked-core classes with one inactive tail and 9,608 full-core classes with at most four positive sink heads. The last comparison has ordinary proofs using a reciprocal-tail identity and a three-square completion. The source distinguishes these proof types explicitly.

## Extract both delivery ZIPs first

This release has two normal ZIP parts with complementary named data shards. **Extract both ZIPs into the same parent folder**, allowing their shared `universal-sink-five-core-boundary-result/` directory to merge. The README is identical in both ZIPs. Neither part alone contains the complete proof data. The shared manifest and verifier reject missing or altered shards. No byte-splitting or manual file concatenation is needed.

- `universal-sink-five-core-boundary-package-part-1.zip`: article, verifier, audits, zero-tail certificates, and the first bounded-sink data shard
- `universal-sink-five-core-boundary-package-part-2.zip`: the remaining bounded-sink data shard and this identical README

## Full exact replay

Use Python 3.10 or later, with approximately **2 GB of temporary disk space** available:

    python /path/to/universal-sink-five-core-boundary-result/verify.py

Optional controls:

    python verify.py --workers 4 --output /tmp/fresh-receipt.json
    python verify.py --mode hashes

Full verification uses only the Python standard library. It checks integrity, safely streams the three solid-compressed certificate archives into a fresh temporary directory, checks every decoded certificate against its independent audit hash, and freshly reconstructs every Boolean support target. It then expands all rational squares, checks every remainder coefficient, and verifies disjoint complete coverage of all 2^16 and 2^20 relevant labeled graphs. Finally, it replays exact corroboration of the ordinary Boolean lemmas and square identities. The driver leaves the package unchanged and removes its temporary directory on exit.

There are 12,652 certificates totaling 1,703,371,669 uncompressed bytes. Solid compression keeps delivery compact while preserving each original JSON file byte-for-byte. Full replay takes longer than hash checking; progress is printed. No numerical solver, producer import, prior archive, third-party Python module, or network access is required. Hash-only mode checks integrity and is not mathematical verification.

The zero-tail collection has 212,319 binomial squares and 158 already coefficientwise-nonnegative targets. The bounded-four-sink collection has 1,755,474 rational polynomial squares and 57 already coefficientwise-nonnegative targets. All coefficients and exponents are checked exactly. The full counts and hashes are in the audit receipts.

## Scope of the moment bound

For arbitrary sink count, A=sqrt(sum w²) and B=sum w−A are nonnegative. The first three moments obey the ordinary upper-E3 envelope in the article. With at most four positive sink heads, Cauchy's inequality gives A>=B, allowing A=B+C with B,C>=0. This enlarged cone is sufficient; no sharpness or finite-four-sink equivalence claim is made.

The boundary splits completely because gamma5=e5(u)E5(w): either one tail activity is zero, or at most four sink heads are positive. Further zero roles are included without deleting active head roles or padding the ULC degree.

## Optional reproduction of discovery and typesetting

`discovery/` contains the candidate-generation scripts and catalogs. NumPy, SciPy and SymPy are optional discovery dependencies only. In a working copy of that directory, `python certify_four_active.py` generates the zero-tail candidates; `python bounded_moment_cubic.py` generates binomial candidates for the bounded-sink branch, and `python parallel_precise_bounded.py 9608 4` fills remaining cases using polynomial squares and exact active-system reconstruction. Different solver versions may choose different valid certificates. Optional regeneration is unnecessary for proof replay.

`bash build.sh` typesets the article with a standard TeX installation. Rebuilding may change PDF metadata and hashes. The supplied final PDF was rendered and every page visually inspected.

No external publication, priority/novelty, general weighted-preorder, real-rootedness, or stability claim is made.
