# Vertex-weighted preorder support polynomials, degree at most three

The main result is in `weighted-degree-three.pdf`; its editable source is
`weighted-degree-three.tex`.

For any finite preorder, assign each physical vertex a nonnegative activity.
Count each feasible ordered pair of disjoint tail and head supports once, with
weight equal to the product of the selected vertex activities. If the resulting
polynomial has actual surviving degree at most three, its coefficients divided
by the corresponding binomial coefficients form a log-concave sequence.

The theorem allows arbitrarily many vertices and zero activities. It does not
assert the still-open general independent-tail/head-activity extension or
real-rootedness. The paper gives a cubic with nonreal roots and explains every
activity-scope boundary in the finite reduction.

## Reproduce the exact verification

Requirements: Python 3.10 or later and a C++17 compiler (`g++` by default, or the
compiler named by the `CXX` environment variable). No network, numerical solver,
third-party Python package, or supplied executable binary is needed.

Run from any working directory:

    python /path/to/weighted-degree-three-result/verify.py

The wrapper verifies `SHA256SUMS` and `dependency-pins.json`, safely extracts the
frozen dependency archives into temporary directories, and runs:

1. The full vertex audit: residual-domain regeneration, the frozen partial role
   ledger, all 100 direct vertex certificates, the complete selected ledger,
   all 223 six-vertex role identities and all 24 total-preorder role targets
2. The nested mixed/same two-attachment and marked-five certificate audits
3. The role-cover companion's exact algebra and supplementary finite support
   checks, compiling its included C++ sources into temporary storage
4. An independent Hall/bijection recount of the nonreal cubic example

A successful run writes `local-replay.json`. The original approval receipts are
preserved. Running with `python -O` is rejected because the imported independent
checkers use assertions. The standard-library Python vertex audit can also be
run independently after extracting its ZIP and invoking `verify_all.py`.

The exact finite checks complement the ordinary proofs in the article. They do
not formalize Gallai--Edmonds, Wagner's Rayleigh theorem, or the real-stability
preserver theorem used in the included companion paper.

## Contents and dependency boundary

- `weighted-degree-three.pdf`, `.tex`: final article
- `verify.py`: portable top-level exact replay
- `dependency-pins.json`: SHA-256 pins for the immutable dependency archives
- `dependency-closure.json`: approved theorem and selected-ledger scope summary
- `checker/vertex-degree-three-audit-package.zip`: full exact finite and
  certificate closure, including the separate frozen vertex and role ledgers
- `checker/role-cover-package.zip`: complete companion proof, algebra, support
  checkers, and independent audits for the two-tail/two-head role-cover theorem
- `proofs/`: readable structural proof notes and the companion TeX/PDF
- `audit/`: final mathematical review record; the independent fresh-extraction
  replay receipt is saved alongside the final archive
- `visual-qa.json`: page-by-page rendering inspection record
- `SHA256SUMS`: hashes of the distributed files
- `build.sh`: optional LaTeX build; unnecessary for mathematical verification

The vertex ledger is complete. The role ledger is intentionally incomplete and
is used only through proved targets. No vertex-only target is used to justify a
role-changing extremal-class refinement. The final vertex ledger has 97 selected
vertex certificates; all 100 produced vertex files are included, with three
redundant files retained for transparency.

The included structural notes are frozen provenance copies. Some preserve an
earlier draft status paragraph; pinned independent approval receipts and the
final article govern the approved scope. None of the ongoing role-search
numerical solvers or exploratory candidate files is part of this package.

## Rebuild the PDF

With a standard LaTeX installation containing the packages in the TeX preamble:

    bash build.sh

The script also supports the font paths used in the original build environment.
Generated build products and page-rendering PNGs are not required by the theorem
and are excluded from the distributed checker archive.

This is an exact computer-assisted theorem, not a proof-assistant formalization
or a literature-wide priority claim.
