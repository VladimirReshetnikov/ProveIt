#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
export TEXINPUTS=".:/usr/share/texlive/texmf-dist/tex//:/usr/share/texmf/tex//:${TEXINPUTS:-}"
if [ -d /tmp/hamiltonian-rank-build ]; then
 export TEXFORMATS="/tmp/hamiltonian-rank-build:${TEXFORMATS:-}"
 export TEXFONTMAPS="/tmp/hamiltonian-rank-build:/usr/share/texlive/texmf-dist/fonts/map//:/usr/share/texmf/fonts/map//:${TEXFONTMAPS:-}"
fi
export TFMFONTS="/usr/share/texlive/texmf-dist/fonts/tfm//:/usr/share/texmf/fonts/tfm//:${TFMFONTS:-}"
export VFFONTS="/usr/share/texlive/texmf-dist/fonts/vf//:/usr/share/texmf/fonts/vf//:${VFFONTS:-}"
export T1FONTS="/usr/share/texlive/texmf-dist/fonts/type1//:/usr/share/texmf/fonts/type1//:${T1FONTS:-}"
export ENCFONTS="/usr/share/texlive/texmf-dist/fonts/enc//:/usr/share/texmf/fonts/enc//:${ENCFONTS:-}"
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build weighted-degree-three.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build weighted-degree-three.tex
cp build/weighted-degree-three.pdf weighted-degree-three.pdf
