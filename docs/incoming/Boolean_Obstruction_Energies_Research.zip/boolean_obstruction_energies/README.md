# Exact Boolean Obstruction Energies

**Derivative periods, sharp quartic–sextic integration, and dimension-free
higher-degree extremizers**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and the
ProveIt project, 6 October 2026. This is a standalone research contribution,
not a change to the repository or a proof-assistant-verified library.

## Principal results

For a symmetric multilinear tensor T of degree d on F_2^n, the selected energy is

    E_T(f) = average_h |average_x (∂_{h1} ... ∂_{h(d-1)} f)(x)
                                   (-1)^T(h1,...,h(d-1),x)|^2,

where ∂_h f(x) = f(x+h) conjugate(f(x)), all averages are normalized,
and |f| <= 1.

The canonical nonintegrable tensors

    C_d(h1,...,hd) = sum_i v(hi) product_{j != i} u(hj)

for independent u,v have maximum energy exactly `1 - (d+1)/2^d` in every
degree d >= 3 and dimension n >= 2. The function is allowed to depend on all
n coordinates. This answers the explicit quartic stabilization question in
`boolean_phase_integration.tex`.

For **all** symmetric nonintegrable tensors, the exact maxima in degrees
3, 4, 5, 6 are respectively

    1/2, 11/16, 13/16, 57/64.

For every d >= 3 the universal upper bound is

    1 - min(d+1, 7)/2^d.

The canonical lower bound and universal upper bound coincide through degree
six. Equality of these bounds in higher degrees is not claimed. The paper
also proves a sharp 7/32 non-pure trilinear support theorem, classifies pure
and one-dimensional-image defects, gives an exact nonnegative deficit
recursion, and retains error margins for corrupted selectors.

## Contents

- `article.pdf`: compiled article with full proofs and nine research questions.
- `article.tex`: standalone source; labels use the `boe:` prefix.
- `code/verify.py`: exact, standard-library-only finite checks.
- `data/verification.json`: generated verification record.
- `FORMALIZATION.md`: proposed dependency graph and proof obligations.
- `SOURCE_AUDIT.md`: inspected sources, baseline, new results, and limitations.
- `RESEARCH_STATUS.md`: theorem-by-theorem status and remaining questions.
- `Makefile`: build and verification commands.

## Reproduce

Python 3.10 or later:

```sh
python3 code/verify.py --max-degree 10
```

This uses exact Gaussian integer/fraction arithmetic and finite Boolean
calculations. It performs no web requests, installs nothing, and does not
need NumPy, SciPy, Mathematica, or Lean. The `--max-degree` flag controls the
exhaustive canonical constant counts, not a general theorem verification.

With an ordinary TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex` repeatedly until references stabilize. The
bibliography is embedded in the TeX file. No shell escape is needed.

## Suggested repository integration

A standalone location would be

`Combinatorics/Ramsey/Research/GowersSzemeredi/boolean-obstruction-energies/`.

Alternatively the manuscript can be incorporated into the existing local
quantitative refinements collection. Preserve the `boe:` label prefix, the
normalization, the full-symmetry hypothesis, and the distinction between
homogeneous multilinear maps and the project's `IsMultilinear` multiaffine
predicate. The prior quartic question should be marked resolved by the
fixed-derivative lemma and canonical induction, not by an unproved general
claim about pullbacks preserving maximum energy.

No repository files were modified. No third-party paper, prior manuscript,
font file, compiled Lean artifact, or unchecked Lean proof is included.

## Status

The manuscript contains mathematical proofs and exact supplementary tests.
It has not been independently refereed or formally verified. It does not
claim a new global bound for Szemerédi's theorem, a complete low-characteristic
inverse theorem, or an exhaustive literature-priority determination.
