RELATIONS, DEFINABLE ATOMS, AND REPLACEMENT
A finite/countable/continuum classification and exact kernels from rooted components

Research manuscript prepared with ChatGPT, 4 October 2026.

CONTENTS

  atom_actions.pdf                  Complete 28-page article, including references.
  atom_actions.tex                  Complete editable LaTeX source.
  verify_presentations.py            Exact arithmetic checks and finite enumerations.
  verification_results.json          Output of the supplied verification program.
  figures/antichain_upsets.pdf        Vector figure used by the article.
  figures/antichain_upsets.png        Preview of that figure.
  figures/make_figure.py              Source for regenerating the figure.
  README.txt                        This guide.
  SHA256SUMS.txt                     Integrity hashes for the other package files.

READING GUIDE

Section 1 identifies the research intersection and the exact repository
questions addressed. Sections 2-5 develop the atom universe, rooted codes,
definable kernels, and nonabelian examples. Sections 6-8 prove and make
effective the finite/countable/continuum trichotomy. Section 9 classifies
all connected types for commuting injections satisfying f^m = g^n,
including noncoprime exponents and local automorphism groups. Section 10
gives sharp Replacement, Collection, and reflection consequences.
Section 11 describes the verification boundary and a formalization plan.
Section 12 proposes twelve further research directions. The appendices
provide notation, reproducibility information, and a source audit.

COMPILE THE ARTICLE

Unzip the complete folder, change into it, and run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error atom_actions.tex

Alternatively, run pdflatex on atom_actions.tex repeatedly until references
and the table of contents stabilize. The bibliography is included directly
in the TEX source; no separate BIB file or network access is required.
Keep the figures directory beside atom_actions.tex.

The article was compiled with pdfTeX 1.40.25 and latexmk 4.83. It uses standard
LaTeX packages: fontenc, inputenc, lmodern, microtype, geometry, amsmath,
amssymb, amsthm, mathtools, mathrsfs, enumitem, booktabs, longtable, array,
graphicx, xcolor, fancyhdr, url, hyperref, and cleveref.

REPRODUCE THE COMPUTATIONS

Use Python 3.10 or later with SymPy installed, then run:

  python verify_presentations.py --output verification_results_reproduced.json

The delivered run used SymPy 1.14.0. All linear algebra and enumeration
are exact. The program checks fourteen relation matrices; enumerates all
24,301 weak compositions for the 64 pairs 1 <= a,b <= 8; groups them into
3,521 cyclic classes; checks their counting formulas and stabilizers; and
checks normalized ideals for five coprime numerical semigroups.

The runtime metadata in a regenerated JSON file can differ from the
delivered JSON if Python or SymPy versions differ. The mathematical
results should agree. Running Python with optimization (-O) would disable
assertions and must not be used for the verification run.

To regenerate the optional figure, install Matplotlib and run:

  python figures/make_figure.py

The supplied vector PDF is already sufficient to compile the article.

RESEARCH SCOPE AND STATUS

The source questions are Questions 23.1-23.3 in the ProveIt report:

  SetTheory/Cardinals/docs/reports/ordinals-and-order-types/
  naming-elementary-embeddings/article.tex

The inspected repository snapshot is:

  715a716a3002b1e9f28daa2d81c009a392851b94

Repository: https://github.com/VladimirReshetnikov/ProveIt

The research-interest match uses Glazer and Yao's primary paper
Reflection Principles in ZFU (arXiv:2602.21970), Glazer's thesis, and the
repository's explicit atom-model questions. The LinkedIn page supplied
with the request did not provide readable contents during this work.

The article supplies mathematical proofs under its explicit hypotheses:
an ambient well-founded set theory with atoms and Choice, actual atom
kernels, a finite named injective signature, and stated parameter
conventions. The principal type-count theorem assumes a finitely
generated commutative monoid. The all-object fixed-point theorem is
proved at the finite cutoff only. Ordinary definability is distinguished
from definability with pure real parameters or arbitrary pure parameters.

Separate ChatGPT agents reviewed the written proofs. The finite program
checks examples and identities; it does not prove the infinite theorems.
No proof-assistant verification, external peer review, or publication
priority claim is made. Standard localization, group-action, polyhedral,
and rational-Catalan ingredients, as well as previously established
fixed-action axiom criteria, are credited in the article. The proposed
research questions are extensions of the present results, not a claim
that every wording is a longstanding published open problem.

Elliot Glazer and Bokai Yao are cited researchers, not authors or endorsers
of this manuscript.
