# Threshold-Resolved Amplification for Boolean Sensitivity

**Research draft — October 8, 2026. Prepared for Vladimir Reshetnikov.**

The article strengthens the quantitative ordinary-sensitivity separation supported by the nested-tournament construction in OpenAI's September 25, 2026 manuscript *A superquadratic separation between sensitivity and block sensitivity* (family 132 of `openai/math`). It does **not** claim the first qualitative superquadratic separation.

## Main theorem

There is a computably specified total Boolean seed `f`, zero at the all-zero input, and positive integers `A`, `beta`, `W`, with `n = beta*W`, such that its disjoint composition powers `F_m` obey

```text
minimum_accepting_weight(F_m) = W^m
block_sensitivity(F_m, all_zero_input) = beta^m
W^m <= sensitivity(F_m) <= A^m
beta > A^(3667/1809).
```

Consequently

```text
block_sensitivity(F_m, 0) / sensitivity(F_m)^(3667/1809) -> infinity,
3667/1809 = 2.027086788... > 2.027.
```

The logarithmic ratio of the certified seed bounds is approximately `2.02717077057970031843`. This is not an asserted optimal exponent or the exact ratio of the true sensitivity values.

The fixed parameters are depth 16, tournament outdegree 14,400,000,000, four children per row, forbidden coherent-set size 34, 30,000 base blocks, and 62,500 OR copies. The theorem is an asymptotic existence result: its seed dimension has 188 decimal digits. Neither the large labelling nor the full seed truth table has been materialized.

## Read first

- `article.pdf`: the complete 19-page article, including proofs, exact arithmetic certificate, comparisons, and eight further research questions.
- `article.tex`, `references.tex`, `references.bib`: editable article and bibliography sources.
- `docs/VERIFICATION.md`: what the executed checks do and do not establish.
- `docs/NOVELTY_AND_ATTRIBUTION.md`: inherited ideas, refinements, and limits on priority claims.

## Reproduce the exact certificate

Use ordinary Python, **without `-O` or `-OO`**. The primary verifier rejects optimization mode because its checks use assertions. The arithmetic verifiers use only the standard library; no Internet, solver, floating-point optimization, or proof assistant is needed.

```sh
python3 code/verify_certificate.py
python3 code/compact_certificate.py
```

Python 3.11 or later is recommended (`Decimal.ln` is used only for diagnostic decimals). Python's arbitrary-size integers are used in every proof-relevant calculation.

The main verifier recomputes all profile arrays, compares 1,938 meaningful entries with an independently structured memoized implementation, compares regenerated arrays and constants with the included certificates, and checks

```text
binomial(28,800,000,001, 34) < 4^527 = 2^1054
A^50 < 2^14472
beta^50 > 2^29336
beta^1000 > A^2027.
```

The exponent implication follows exactly from `29336/14472 = 3667/1809`. The compact script is the reference recurrence printed in Appendix A and provides another small executable check.

To intentionally regenerate the certificate files:

```sh
python3 code/verify_certificate.py --write
python3 code/make_tables.py
```

JSON certificate numbers are arbitrary-size integers. Do not read them through a parser that silently converts integers to IEEE-754 double precision (for example, default JavaScript `JSON.parse`). Python's standard `json` parser preserves these integers.

## Reproduce the supplementary finite tests

NumPy is needed only for the truth-table test suite. The included report was produced with NumPy 2.3.5.

```sh
python3 -m pip install -r requirements-test.txt
python3 code/test_local_geometry.py
```

The test suite covers 71,368 local threshold configurations and eight 18-bit Boolean functions, totaling 2,097,152 input assignments and 37,748,736 bit-difference comparisons. It also executes conditional-expectation labelling for a seven-row example. These finite checks are supplementary evidence, not a proof of the all-input inequalities.

## Build the PDF

A standard TeX Live installation with pdfLaTeX and the packages used in `article.tex` is sufficient. The typeset bibliography is supplied as `references.tex`; **BibTeX is not required**. The `.bib` file is included for citation reuse.

```sh
./build.sh
```

This first verifies the certificate, regenerates display tables, then runs pdfLaTeX three times to settle references. It does not install dependencies or download anything. `make test` also runs the supplementary NumPy tests; `make regenerate` rewrites arithmetic certificates and tables.

## Package map

```text
article.pdf / article.tex        Complete paper
references.tex / references.bib  Typeset and machine-readable bibliography
code/profiles.py                 Threshold-indexed integer recurrence + DAG checker
code/verify_certificate.py       Exact certificate verifier and regeneration
code/compact_certificate.py      Short, self-contained Appendix A check
code/labels.py                   Exact conditional-expectation labelling, small guard
code/test_local_geometry.py      Exhaustive local and truth-table tests
code/make_tables.py              Display tables, fixed-parameter ablations, source scan
certificates/                   Exact constants, all profiles, small label witness
results/                        Executed test reports and reproducible display data
docs/                           Verification, attribution, source hashes, formalization plan
SHA256SUMS                      Hash manifest for delivered files
```

## Status

The construction and inequalities are proved in the article; the arithmetic certificates and finite tests have been executed. This is an AI-assisted research draft, not an independently refereed or proof-assistant-verified result. Novelty relative to all literature has not been certified. No source-repository files were modified, and no claim is made to have implemented an efficient arbitrary-function sensitivity algorithm or a practical full-seed generator.
