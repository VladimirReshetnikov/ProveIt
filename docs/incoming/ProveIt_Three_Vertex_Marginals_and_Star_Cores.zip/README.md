# Lorentzian Marginals on Three Vertices

The report proves that the degree-three selected-left marginal of any bipartite
graph with exactly three left vertices is Lorentzian, for arbitrary positive
right activities. An exact rooted vertex-sum argument gives all-field ULC at
order q+3 for a 3+q cover whose core is a star centered on the three-vertex
shore. In particular, every genuine 3+3 cover with core matching rank at most
one is ULC6 for arbitrary positive fields on both shores.

This does not settle the general rank-six middle gaps or provide an arbitrary
rank-three-block lift.

## Reproduce the exact checks

Run python -O code/replay_all.py from this directory. Only the Python standard
library is required. The main generator and independent reconstruction both
verify all 5,339 integer coefficients of the Hessian determinant, matching the
complete data/determinant.json certificate exactly. The independent version
uses explicit neighborhood sums and the five-term symmetric determinant formula.
The support checker separately tests 240 three-left graphs and 160 star-core
graphs by exact endpoint-state enumeration.

The regression tests are supplementary. The finite universal proof input is the
complete determinant identity, whose mathematical reduction is given in the
article. All assertions in the scripts are explicit runtime checks and remain
active under optimized Python.

## Files and build

- article.tex and article.pdf: the report and editable source
- data/determinant.json: all determinant coefficients and their canonical digest
- code/: two exact reconstructions, endpoint regressions and a combined runner
- VERIFICATION.md: verification scope and results
- SHA256SUMS: checksums of the shipped files
- build_local.sh: compilation helper for the installed TeX layout

Ordinary TeX installations can run pdflatex article.tex twice. The included
helper sets explicit paths for the environment in which this report was built.
No Lean formalization, formal proof-kernel verification, external referee
endorsement or exhaustive priority claim is made.
