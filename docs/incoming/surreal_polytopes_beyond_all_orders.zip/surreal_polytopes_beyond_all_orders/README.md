# Beyond-All-Orders Extension Complexity in Surreal Polygon Geometry

**Flat deformations, classical face lattices, and a sharp-order complexity gap**

Research manuscript prepared for Vladimir Reshetnikov, September 30, 2026.
Developed with ChatGPT; independent review and formalization pending.

## Start here

Read `article.pdf` (26 pages). The self-contained source is `article.tex`, with an
internal bibliography and no external images or bibliography database.

## Main result

For every n = 2^m, m >= 2, the manuscript constructs a regular n-gon R_n and an
explicit cyclic surreal n-gon P_n on the same unit circle. With epsilon = 1/omega,
corresponding vertex coordinates differ by less than epsilon^M for every ordinary
positive integer M, yet

    m <= xc(R_n) <= 2m,
    ceil(sqrt(n)) <= xc(P_n) <= min(n, ceil(24 sqrt(n))).

Here xc is extension complexity: the least number of facets of a bounded
higher-dimensional polytope admitting an affine projection onto the given
polytope. The ratio is of order sqrt(n)/log(n).

The perturbations are explicit Conway monomials

    mu_i = omega^(-omega sqrt(q_i)),

where q_i are distinct ordinary primes, inserted into a rational parametrization
of the circle. The manuscript also proves an exact criterion for unbounded
complexity gaps in all-order coordinate-jet fibers: the ideal

    I_epsilon = intersection over M >= 1 of epsilon^M O

must be nonzero. Here O is the ring of elements bounded by ordinary real numbers.
This is equivalent to the valuation of epsilon not being an order unit in the
natural value group. The choice of observation scale matters, not only the
rank of the field.

Further results include compatible finite-order slack factorizations with no
exact lift of the same size; a finite-precision rank-one analogue; perturbations
below any prescribed set of surreal tolerances; real-algebraic realization
transfer preserving exact extension complexity; and a rational-chart
construction. Nine further research questions appear in Section 12.

## Status and attribution

The flat-fiber classification and explicit beyond-all-orders construction are
proposed research contributions with manuscript proofs. Their correctness and
priority have not been independently certified. No named published conjecture
is claimed solved. This is not a refereed article and is not Lean-verified.

Classical ingredients are attributed in the article: real-closed-field transfer;
Yannakakis's factorization theorem; parameter-count lower bounds for extensions;
reflection constructions for regular polygons; and the Kwan--Sauermann--Zhao
upper bound for cyclic polygons. In particular, the classical square-root and
logarithmic bounds themselves are not claimed as new.

The repository audit concerns selected source documents at ProveIt commit
6996fee43cc97b6c16351def7507d59a95bf62f0. It is not an exhaustive audit of the
repository or its Lean library, and no repository changes were made.

## Files

- `article.pdf`: typeset manuscript, 26 pages.
- `article.tex`: standalone source with bibliography.
- `code/verify.py`: exact symbolic identities and finite-example checks.
- `data/verification.json`: successful recorded run, 114/114 checks.
- `requirements.txt`: pinned SymPy version used for the recorded run.
- `build.sh`: build the PDF with pdfLaTeX.

## Reproduce the finite checks

From this directory, in a Python environment with SymPy installed:

    python -m pip install -r requirements.txt
    python code/verify.py

The recorded environment was Python 3.13.5 and SymPy 1.14.0. The script does not
need internet access once SymPy is installed. It exits with an error if a check
fails and writes `data/verification.json` only after a successful run.

**Scope:** the 114 checks cover exact rational identities, finite slack matrices,
reflection formulas, factor normalization, and elementary bound calculations.
They do not compute minimum nonnegative rank, prove the infinite-family lower
bound, verify surreal algebraic independence, or provide a Lean formalization.
The quantifier-elimination decision procedure discussed in the article is not
implemented by this script.

## Rebuild the article

A standard TeX installation with pdfLaTeX and the packages named in the preamble
is required (including Latin Modern, AMS packages, microtype, geometry, enumitem,
booktabs, longtable, xcolor, fancyhdr, aliascnt, etoolbox, hyperref, and cleveref).

    sh build.sh

Alternatively, run pdfLaTeX on `article.tex` three times. The supplied PDF was
compiled from the supplied source, checked for undefined references and layout
warnings, rendered, and visually inspected.
