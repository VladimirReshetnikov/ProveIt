# A Direct Contour Proof for the A290268 Regular Region

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

## Main results

The exact source coefficient is reduced to one meromorphic contour integral. A proved comparison between the odd and even hyperbolic product factors turns positive local curvature into a global angular bound.

For every fixed κ₁<κc, the report proves a uniform additive cosine law on 0≤k/d≤κ₁ and |b|/d≤δ₀(κ₁), with an explicit analytic prefactor and O(1/d) normalized error. The positive width δ₀ is existential. The proof covers κ=0 directly.

After shrinking δ₀, the entire closed strip has only O(N^(5/3)) exact cancellations among Θ(N²) candidates at derivative order N. A separate analytic exceptional-set argument gives qualitative density one on compact patches of any connected region where the uniform cosine law is already proved and its directional curvature is not identically zero.

The full noncancellation conjecture remains open. The report does not continue the saddle law beyond an established dominance boundary, identify exact coefficient zeros from leading cosine zeros, or give a numerical eventual threshold.

## Files

- `article.pdf`: full report
- `article.tex`: complete LaTeX source, independent of the earlier nested proof
- `build_local.sh`: local build wrapper
- `verify_reduction.py`, `reduction_checks.json`: 112 independent exact coefficient comparisons using only the Python standard library
- `check_prefactors.py`, `prefactor_checks.json`: numerical comparisons with exact integer coefficients at d=200,400,800 and independent nested-action/prefactor checks; requires mpmath

Run `python verify_reduction.py` for the exact checks. The numerical diagnostic is optional and does not enter the proof. On a standard LaTeX installation, run `pdflatex article.tex` twice; the wrapper supplies local format and font maps for the research environment.

## Review status

The arguments were independently mathematically reviewed. Every rendered page was visually checked, and the final build has no undefined references or overflows. The work is not Lean-formalized or externally refereed; no exhaustive priority claim is made. The classical hyperbolic products and generalized Bernoulli normalization are cited to the DLMF. The exact inspected ProveIt commit is identified in the bibliography.
