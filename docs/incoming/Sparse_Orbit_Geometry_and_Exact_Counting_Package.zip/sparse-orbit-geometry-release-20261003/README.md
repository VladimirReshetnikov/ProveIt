# Report 30 Sparse orbit geometry and exact counting

3 October 2026. A successor to the separately delivered Report 29.

## Read first

- `report30.pdf`: full mathematical report, with all pages rendered and visually checked
- `report30.tex`: editable LaTeX source
- `scientific/geometry/`: original geometry proof, counting review, local CA audit, and unchanged author receipts
- `scientific/examples/`: independent mathematical review and separately implemented example checker
- `scientific/first-visit/`: canonical first-hit quartic construction, independent review, algebra fixtures and unchanged receipts
- `scientific/original-frame/`: complete-configuration injectivity corollary and independent review
- `figures/`: vector figure of actual simulated occupied-site unions and its authored generation script
- `verification/`: exact expected receipts and source lineage

The main results are stationary-frame semilinearity, common containing rank at most two, exact degree zero/one/two box quasipolynomials, quadratic shuttle clocks, sharp discovery and inverse estimates, piecewise quadratic first arrivals, and explicit globally conservative weighted CA examples. Restored drift can produce a nonsemilinear set and the exact nonquasipolynomial count 3(N+1)−2A(N)−B(N)=3N−3√N+O(1). Rank three is sharp even against finite unions of planar tubes.

The constructive appendix selects first hits before compiling quartics. For each fixed CA and input it gives exactly one natural witness tuple for each stationary-frame visited site, reachable canonically encoded configuration, or successful anchor of a fixed finite pattern including zeros. A separate whole-orbit injectivity argument extends the complete-configuration certificate to the original frame, with at most 7B_ch+1 witness variables on expanding tails. This does not extend original-frame site or pattern first-hit claims. With time external, the actual expanding-clock construction has W=B+I+2C+1 variables and R=3+I+H+2C squared residual slots; internal time adds one witness. These are input-dependent counts, not a uniform arity theorem or a generic single-fold MRDP claim.

## Dependency and scope

Report 30 uses the effective orbit classification proved in Report 29, especially its fixed unoriented flight line, additive scalar gap, complete phase domains and affine within-cycle timing. It does not reprove that classification. The exact Report 29 release hashes are recorded in `verification/source-lineage.json`; that predecessor is separately delivered, not bundled again.

All inputs are finite and have conserved positive integer mass at most four, on a finite weighted alphabet with a unique weight-zero vacuum and at most one weight-one symbol. The examples have alphabet {0,u,E,W}, weights 0,1,2,2. They are actual globally conservative CAs by an unrestricted disjoint-write proof. They are not presented as binary or reversible constructions. No novelty or priority claim is made. Existing Presburger counting theorems and the close classical two-pebble literature are explicitly distinguished.

The source Markdown files preserve their original relative provenance references and historical hashes. Those references document their original research context; report-level dependencies and portable replay paths are resolved by the current inventory and lineage record. No private absolute source path or downloaded copyrighted paper cache is included.

## Verify and replay

From the extracted release directory:

    sh reproduce.sh --verify-only
    sh reproduce.sh --output-dir ../report30-replay

The output directory must be absent or empty and external to the release. The replay runs the geometry checker, independent example checker, and first-visit algebra fixtures in separate fresh normal and optimized copies using Python isolated mode and disabled bytecode writes. It compares all receipts recursively by exact type and value. A boolean is not accepted as integer one. It verifies that release file bytes, modes and modification times are unchanged. Six focused tamper regressions exercise the trusted bootstrap. Replay output is never written into the sealed payload.

Before any packaged helper runs, `reproduce.sh` checks an independently fixed required inventory and pinned payload hashes, then checks the manifest. This detects deleted required scripts even when the manifest is edited, and altered pinned scripts or expected receipts even when their manifest entries are resealed. The bootstrap itself and its reference pins are the trust boundary. This is not protection against an attacker replacing the entire bootstrap and reference package together.

### Runtime requirements

- Python 3.10 or later; tested with Python 3.12.14
- Geometry and independent example checks: Python standard library only
- First-visit algebra fixtures: SymPy, tested with SymPy 1.14.0
- PDF build: a conventional TeX Live installation with pdfLaTeX, Latin Modern, AMS packages, geometry, microtype, hyperref, fancyhdr, enumitem, and graphicx
- Optional figure regeneration: Matplotlib, tested version recorded in the lineage record
- Optional page rendering: Poppler `pdftoppm` and `pdfinfo`

SymPy is needed for the symbolic joint-degree and integer-coefficient checks; it is not silently treated as a standard-library dependency. Replay does not install software or access the network. It fails visibly if a dependency is missing. The three scientific scripts can also be run directly in isolated external copies, but the trusted entry point provides the full inventory, typed-receipt and preservation checks.

## Build the PDF without changing the payload

    sh build.sh ../report30-build

The build writes only into the external output directory, uses no shell escape, and rejects overfull boxes and unresolved references/citations. The included figure PDF is sufficient; figure regeneration is optional:

    python3 -I -B figures/make_figures.py --output-dir ../report30-figures

The figure comes from actual transitions of the authored CA simulator. It is not inferred from an abstract schedule. The left panel shows the stationary wedge through section 15; the right panel shows vertical drift through time 180, with k=3 in both. Rebuilt image bytes can differ across Matplotlib/font versions; the included vector figure is pinned.

## Scientific audit coverage

The author audit has explicit non-removable guards and a deliberate failing-guard self-test. It tests both planar and horizontal variants, malformed configurations, section states, stationary counts, and drift counts. Its cellwise radius-six evaluator reuses the same rule predicate as the global evaluator; this checks an independent evaluation route, not an independent transition-rule implementation.

The second checker independently transcribes the transition logic and cellwise calculation. Its expected receipt records 17,265 malformed configurations, 67,623 cellwise checks, 48,130 orbit steps, 610 sections, 12,650 first arrivals, 48,082 exact physical-time counts, 300 horizontal inverses, 120,015 distinct drift points, 39,942 box counts and 210 large-integer root boundary checks. It also checks the sharp safe horizontal threshold N≥k+1 and the one-point failure at N=k; the report conservatively states its exact drift formula for N≥2k+4.

The independent checker differs from its reviewed original only in the SOURCE assignment, now resolved relative to its packaged location. The complete geometry source packet is preserved byte-for-byte, including its manifest and receipts, so all source fingerprints in the independent receipt remain unchanged. Mathematical counts and receipt contents are unchanged. Exact original and portable script hashes plus this one-line adaptation are recorded in the lineage record.

The first-visit fixtures test canonical signed quotients, inactive auxiliaries, finite witness cubes, rejected mutations, common-denominator polarization, pooled output timing, shared-cycle timing, integer coefficients, and ordinary degree at most four. They do not implement general Presburger elimination or a CA normal-form compiler.

Finite checks test transcription and arithmetic; unrestricted conservation, definability, first-hit uniqueness, growth estimates and rank obstructions rest on the proofs. The report is an ordinary mathematical argument with independent review, not a formal proof assistant development.
