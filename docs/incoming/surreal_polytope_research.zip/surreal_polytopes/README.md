# Infinitesimal Boundary Geometry of Surreal Polytopes

**Lexicographic traces, one-parameter descent, and Ehrhart universality**  
Research manuscript prepared for Vladimir Reshetnikov, September 30, 2026.

## Contents

- `surreal_polytopes.pdf`: the 28-page article.
- `surreal_polytopes.tex`: self-contained LaTeX source, including the bibliography and TikZ figure.
- `verify.py`: exact finite verification using the Python standard library only.
- `verification.json`: successful verification report produced by the supplied program.
- `counts.csv`: quadrilateral counting values for n = 0,...,100.
- `README.md`: this guide.

## Main results developed in the article

Theorem 4.2 gives a finite lexicographic description of the real trace of a polytope over a real closed extension of R, with at most d+1 levels per inequality in dimension d.

Theorem 5.1 uses this description and classical semialgebraic curve selection to obtain one-parameter algebraic descent preserving the entire real trace, labeled face lattice, and vertex shadows. Every ordinary lattice-counting value is preserved; eventual agreement with real specializations is pointwise in the dilation, not uniform in all dilations.

Theorem 6.1 implants any real polytope T into a proper face G of a rational shadow Q, yielding

    L_P(n) = L_Q(n) - L_G(n) + L_T(n),  n >= 1.

Theorem 7.1 constructs a quadrilateral with the four integral vertex shadows of the unit square and

    L_P(n) = (n+1)^2 - ceil(alpha*n),

for irrational alpha in (0,1). It proves non-quasipolynomiality and nonrationality directly. Pólya–Carlson then gives a natural boundary, and the sequence is not P-recursive. The exact checker uses alpha = 1/sqrt(2).

Theorem 8.3 identifies the surface coefficient for every full-dimensional lattice shadow. Theorems 9.1 and 9.3 determine its complete attainable interval; for a simple shadow the full interval is attained while retaining the labeled face lattice and every integral vertex shadow.

Theorem 10.2 gives a sufficient rational-flag condition for positive-dilation quasipolynomiality. Corollary 10.5 records the classical analytic dichotomy for every real-bounded trace count: rationality, D-finiteness, P-recursiveness, and eventual quasipolynomiality are equivalent; otherwise the generating function has the unit circle as a natural boundary.

Section 13 proposes twelve further research questions. Section 11 gives a staged formalization roadmap and a theorem-dependency map.

## Scope and status

These are mathematical arguments in an unrefereed research manuscript, not a completed Lean development. Classical real-closed-field theory, curve selection, Ehrhart reciprocity, and Pólya–Carlson are explicitly cited inputs. The manuscript does not claim a new proof of those classical theorems, certified novelty of every assembled result, or the resolution of a named published open conjecture.

All counts use ordinary nonnegative integer dilations of polytopes bounded by a real box. In the surreal case bounded omnific lattice points are exactly ordinary integer lattice points. Infinite omnific dilations and unbounded polytopes are not covered.

The repository snapshot inspected was:

    VladimirReshetnikov/ProveIt
    6996fee43cc97b6c16351def7507d59a95bf62f0

The substantive Lean source read was:

    Algebra/SurrealNumbers/Surreal/Foundations/OmnificUnits.lean

Its `omnific_bounded_iff` theorem supplies the bounded-omnific bridge. The file was read at the pinned commit, but the repository was not locally rebuilt or comprehensively axiom-audited. No repository files were changed.

## Reproduce the checks

Requires Python 3.10 or newer; there are no third-party Python dependencies.

```sh
python3 verify.py
```

The script rewrites `verification.json` and `counts.csv` in its own directory. To choose another output directory:

```sh
python3 verify.py --out-dir /path/to/results
```

All assertions use exact integer, rational, Q(sqrt(2)), or infinitesimal-polynomial arithmetic. The successful run included:

- 16 vertex–facet slacks, four orientation determinants, and an exact area identity;
- 1,205,575 direct quadrilateral candidate tests for dilations 1 through 150;
- ceiling and increment checks through dilation 10,000;
- 3,960 rational-threshold cases;
- 443,555 cube-implantation candidate tests for dilations 1 through 35;
- 353,700 exact comparisons for pointwise real specialization through dilation 100.

Finite checks do not prove the general theorems, infinite nonperiodicity, or analytic natural-boundary statements. Those claims depend on the arguments and attributed inputs in the article.

## Compile the article

Use a standard LaTeX distribution with AMS packages, Latin Modern, microtype, TikZ, hyperref, bookmark, fancyhdr, and needspace.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_polytopes.tex
```

Alternatively, run `pdflatex` until cross-references stabilize. No BibTeX run or external figure files are needed.
