# Unit Weight Failure of Matching Rank Normalization

This research note proves that matching-support polynomials need not be
ultra-log-concave after normalization by maximum matching size, even when
every vertex activity is 1.

The main explicit connected bipartite graph has matching rank 3450,
6916 vertices, and 174228 edges. A second graph has matching rank 125508
and smaller shore size 125509, showing failure at deficiency exactly one.

## Files

- `article.pdf`: the five-page report
- `article.tex`: editable LaTeX source
- `code/verify.py`: complete verification entry point
- `code/verify_unit_witness.py`: exact support-deficit counting, independent
  normalized tail formulas, edge counts, and matching/cover checks
- `code/verify_gadget_identity.py`: independent small-graph endpoint-set tests
- `data/`: exact witness and verification records
- `PROOF_STATUS.md`: scope and remaining questions
- `SOURCES.md`: provenance and prior results

## Verify

Python 3 and its standard library suffice:

    python3 code/verify.py

No numerical optimizer or external Python package is required. The large
examples are verified by a proved support-counting formula and exact integer
arithmetic; the program does not enumerate their perfect matchings.

## Build the PDF

With a normal TeX Live or MiKTeX installation:

    pdflatex article.tex
    pdflatex article.tex

`make verify` and `make pdf` provide the same commands. `build_local.sh`
is included for the restricted research environment used to produce the PDF.

## Status

The proofs and certificates are ordinary mathematics, independently checked
but unrefereed and not formally verified in Lean. The numerical search that
found the parameters is not part of the proof. No minimum-size or worldwide
priority claim is made.
