# Uniform saddle sums for bounded gap 132 avoiders

This package contains the complete nine-page research note, editable LaTeX source, reproducible checks, and build information.

The main theorem gives one positive exact-tilt saddle sum for the scalar envelope for all n >= c0 m log m, with fixed c0 > 0. It transfers to the actual avoidance class when n (log m)^2 / m^2 tends to zero. In the intermediate band m log m << n << m (log m)^2, only the distinct floor and ceiling of the exact mean count are needed.

The same analysis proves that the Gaussian periodization is relatively valid for n >> m (log m)^(3/2). At n ~ c m (log m)^(3/2), a cubic correction persists. A half-integer phase sequence has a ratio cosh(1/(192c^2)) to the unmodified Gaussian equivalent.

## Contents

- uniform_avoider_saddle_sum.pdf: reader-facing report
- uniform_avoider_saddle_sum.tex: exact editable proof source
- build.sh: ordinary three-pass pdfLaTeX build
- checks/verify_saddle_algebra.py: standard-library exact algebra checks
- checks/saddle_algebra_results.json: exact check results
- checks/saddle_diagnostics.py: optional NumPy/SciPy scalar diagnostics
- checks/saddle_diagnostics.json: twenty diagnostic rows
- checks/README.md: instructions and limits of the checks
- SOURCES.md: source pin and attribution
- validation.json: package validation
- latex-build.log: clean final compiler log
- SHA256SUMS: checksums for all packaged files except this manifest

## Build

Run bash build.sh in a normal TeX Live environment with pdfLaTeX, Latin Modern, geometry, amsmath, amssymb, amsthm, mathtools, microtype, hyperref and xurl.

The exact checker uses Python's standard library and remains active under python -O. The optional diagnostics require NumPy and SciPy.

The proof is not formally verified or externally refereed. Numerical diagnostics illustrate finite scalar coefficients and do not prove the theorem or count actual avoiders at those lengths. The theorem's lower constant c0 is fixed; the scalar and actual-class ranges are distinct.

