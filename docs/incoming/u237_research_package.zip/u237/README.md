# U237: a 237-state binary machine for Con(U)

This package gives an explicit blank-tape, two-symbol Turing machine with
**237 working states** and a mathematical proof, formalizable in PA, of

    PA proves: Nonhalt(U237) iff Con(U).

U is the equality-free unary power-cover theory in the source archive linked
in `PROVENANCE.json`. Its PA-provable consistency equivalence with ordinary
PA is used through uniform finite proof translations. The machine retains
the published PA238 proof enumerator and saves one state in its physical
implementation. This is an achieved upper bound; absolute minimality is
not claimed.

## Start here

- `report.pdf`: construction, proof, exact verification scope, and full table.
- `report.tex` and `sections/`: editable LaTeX source.
- `machine/u237.tm`: complete literal transition table.
- `code/check_all.py`: reproduce the supplied checks.

The exact machine SHA-256 is:

```text
ec31958ae3c64f6352fff50f3e0aece33994c0cc0b72051a64fb1012dcdaf3df
```

## Machine convention

The tape is indexed by all integers and initially contains only zeros. The
head starts at coordinate 0 in state 0. Working states are 0 through 236;
state 237 is terminal and excluded from the working-state count. Every row
has `state read write direction next_state`, with direction `L` or `R`.
There are exactly 474 transition rows. Each step writes, moves, and changes
state. No input word is required.

## Reproduce

Run from this extracted directory with Python 3, without `-O`:

```bash
python3 code/check_all.py
```

Only Python's standard library is required. The unchanged reference
source-only audit also uses Unix `fcntl`, as in its upstream checker.
The full check normally takes seconds to a few minutes depending on the
machine. It writes generated receipts under `verification-output/` and
compares them with the distributed certificates.

The checks cover:

1. All distributed file hashes and the authenticated reference table.
2. The exact four-row patch, deletion of old state 1, and complete bijective
   state renaming; all 237 working states are graph reachable.
3. Two guarded local computation identities, with arbitrary unread tape.
4. A complete 717,670-step bootstrap, checked in both table labelings and
   replayed by an independent implementation.
5. All 4,409 instruction sites from all 185 physical program nodes, including
   8,817 branch variants, for every natural extra gap G and arbitrary register
   values under the proved register-file contracts.
6. The reference PA238 source manifest, 150 PA modules, and their 192-source
   dependency closure.

The universal symbolic checker uses exact affine runs and four inductive
file-operation lemmas. Those lemmas and the checker soundness argument are
explained in the report and `proofs/runtime_audit.txt`. They are mathematical
proof obligations, not sampled register tests. The checker additionally
verifies the literal transition premises of the file lemmas.

## Proof status

The new result is supported by an arithmetizable mathematical proof and
executable finite/symbolic certificates. **This is not a newly kernel-checked
Rocq theorem or an exported end-to-end PA proof object.** The original
PA238 formal development is bundled unchanged. Its README documents its
separate Coq 8.20.1 kernel-check procedure. A source-only pass does not mean
that procedure has run, nor would the reference procedure automatically
certify the new machine.

The supplied theory-U interpretation was mathematically audited; its exact
original archive is included at `reference/theory_u/pa_unary_power_cover.zip`,
together with its repository license and source hash. This package does not
introduce a new fully mechanized PA-to-U proof translator.

## Exact reduction from PA238

In the original labels, change these four rows:

| State | Read | Original | New |
|---:|---:|:---:|:---:|
| 0 | 0 | 1 L 1 | 1 L 4 |
| 119 | 0 | 0 R 0 | 0 R 3 |
| 3 | 0 | 1 R 6 | 1 L 9 |
| 3 | 1 | 1 L 4 | 0 L 2 |

Start in old state 3, delete old state 1, and apply the supplied renaming.
All other surviving rows remain unchanged. The bootstrap reaches the
reference source's initial active registers with a 36-cell program area
and 307 zero spare blocks. The universal simulation explicitly verifies
this smaller area and the modified zero-decrement exit state.

## Build the report

With a standard LaTeX distribution:

```bash
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

Rebuilding the PDF can change its metadata and hence its file hash. The
distributed `SHA256SUMS` describes the exact distributed version; verify it
before rebuilding. This has no effect on the literal machine's hash.

## Attribution

The reference PA238 machine is attributed to Mira / mira-emmy; the archived
proof development is preserved from `jeff87654/busy-beaver` at commit
`05c050f8f60037929008c4d7c7ad5231adb032bf`. The theory-U manuscript is the
supplied `pa_unary_power_cover.zip` in `VladimirReshetnikov/ProveIt`.
Upstream notices are preserved, including the MPL-2.0 Coq Library of
Undecidability and MIT/MIT-X11 BusyCoq notices. No new license grant for
upstream work is asserted here.
