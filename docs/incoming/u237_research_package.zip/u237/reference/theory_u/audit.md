# Theory U audit and machine-facing calibration

The source archive is `research/theory_u/pa_unary_power_cover/`, SHA-256
`0fcb1117a5353766a3366bab04e56b4efbd0607833cdc73ffb34b67e6808b0ff`.
This note is a mathematical audit, not a proof-assistant verification.

## Exact theory

Classical first-order logic over nonempty domains, one binary predicate E,
no equality, constants, or functions. Define

`Sub(x,a) := forall t (E(t,x) -> E(t,a))`.

For every formula phi with FV(phi) contained in {x}, U contains

`forall a exists b [(forall x (E(x,b) -> phi(x))) and
                   forall x (Sub(x,a) -> (phi(x) -> E(x,b)))]`.

The source variable a may not occur freely in phi. Quantifier complexity
and the number of bound variable names in phi are unrestricted.

## Audit of the lower interpretation

The manuscript's order of dependencies avoids the obvious circularity:

1. Coextensionality Eq is defined by identical member profiles.
2. Numerical objects are saturated transitive linear orders of
   coextensionality classes with endpoints on every represented cutoff
   intersection. Empty objects exist from the false matrix.
3. Every nonempty number has a predecessor, even before successors are
   known to be total.
4. For a unary failure predicate, weak filtering at a numerical source
   identifies failures among its members. A least failure inside the
   source contradicts the step premise. If there is none inside, the
   source itself is the failure and its predecessor suffices. No successor
   of the source is needed.
5. Parameterized induction follows by the unary formula
   Q(v) = forall parameters (base-and-step(parameters) -> theta(v,parameters)).
6. Induction yields comparison and least numerical tuples.
7. For a numerically parameterized bounded construction, quantify its
   lexicographically least failing tuple *inside* the matrix. This removes
   all free numerical parameters. Invariance and a support object yield
   an exact output by the weak upper/lower bounds.
8. This gives total numerical successors and exact powers of numbers.
9. Saturated Kuratowski pair profiles and graphs are obtained from
   numerical parameter tuples. Canonical extension/restriction uses an
   existentially bound old graph, avoiding a prohibited graph parameter.
10. Histories give total addition/multiplication and all PA induction
    instances. Equality in the interpreted arithmetic is Eq.

I found no mathematical defect in this chain on inspection. Important
qualifications already stated by the source: global extensionality is
not assumed, Eq is not an ambient congruence, and arbitrary source-free
weak filters cannot be replaced by exact filters. The orbit model
in unary_separation.tex witnesses that last distinction.

## Upper interpretation and internal proof transport

Interpret E(x,a) by bit x of a. PA proves Sub(x,a) implies x <= a and
has finite comprehension for every fixed arithmetic formula, by induction
on a finite binary-code bound. This validates even the unrestricted
parameter version of the schema. PA also proves forall a not E(a,a),
since 2^a > a.

Each argument is a finite, uniform syntactic proof template. Inserting a
formula into the template, freshening bound names, translating a proof,
and concatenating derivations are primitive recursive. The claimed
PA-internal consistency reductions follow from those proof transformations;
one must not replace them by an appeal merely to standard-model truth or
semantic equiconsistency. The archive contains no complete mechanized
PA-to-U proof translator or formal certificate for this interpretation.

## The easiest machine-facing theory

Let W use the same weak power-cover schema with arbitrary free parameters
in phi, including the source. Let IR be forall x not E(x,x). Then

    PA proves Con(U) iff Con(W+IR) iff Con(PA).

For the first useful implication, U is a syntactic subtheory of W+IR;
for the reverse calibration use the two interpretations above.
Consequently a machine need not check the unary restriction.

If the proof calculus already has equality, add the usual equality
axioms to W+IR. This does not affect the upper interpretation (ordinary
equality in PA) or lower interpretation. This route is preferable to
silently assuming that an equality-free numerical calculus proves
capture-avoiding instantiation or renaming.

## Named-role collision hazard

For a source a, tested label b, output label c, and formula m, the W shell
is

    exists c [forall b (E(b,c) -> m)
              and forall b (Sub(b,a) -> (m -> E(b,c)))].

The subset guard can reuse c as its local binder, because it contains no
reference to the output object: Sub(b,a)=forall c(E(c,b)->E(c,a)).
But if a=b, the inner test quantifier captures the source occurrence and
turns Sub(b,a) into Sub(b,b). The shell then becomes unrestricted
comprehension, which is not valid in the finite-set interpretation.
The K gate c!=a and c!=b does not prevent this. A correct generic W
emitter requires a!=b as well, or a fixed pair of distinct source/test
labels, or an independently justified safe collision scheme.

## Archive's calibrated positive fixed-role emitter

Use positive syntax atoms, implications, and universal quantifiers:

    pi(i,j)=(i+j)(i+j+1)/2+j
    R(i,j)=2*pi(i,j)
    A(v,f)=4*pi(f,v)+1
    I(f,g)=4*pi(f,g)+3.

This is a bijective total coding. Code0 is E(v0,v0), code1 is
D=forall v0 E(v0,v0), code3 is q0->q0. Positive variable labels in
code n are <n. Fix source0/test1/local guard2 and
G=A(2,I(R(2,1),R(2,0)))=1512069. Then

    e=R(1,n)
    h=I(e+n,0)
    u=A(1,h+4*n)
    v=A(1,I(G,h+4*e))
    g(n)=I(A(n,I(v,I(u,0))),0).

All n>=2 give a correct positive W shell with fresh output n. The n=0
collision is equivalent to q0 or existence of an empty object. The n=1
collision is equivalent to q0 or J, where J=forall x(E(x,x)->D).
Under not D the second collision forces IR globally. The regular part
generates the missing matrices0 and1 via equivalent padded codes27 and33.
Thus nonderivability of q0 in the positive emitted theory is PA-provably
equivalent to Con(PA), hence to Con(U).

The emitter takes nine constructor pairings with shared reverse
implications. Its polynomial degree and register count are not a TM
state bound. A complete literal binary table still needs construction
and a soundness/completeness/simulation proof.
