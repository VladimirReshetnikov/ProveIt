#!/usr/bin/env python3
"""Independent executable audit of the PA237 instruction-site simulation.

This is a direct Python translation of the mathematical symbolic executor in
jeff87654/busy-beaver PA/m238/coq/tm/{Symbolic238,Boxed238,
BoxedNormalize238,BoxedExecute238,SiteCheck238}.v.  It does not invoke Rocq.

The symbolic gap variable ranges over ALL naturals.  Register contents are
opaque and universally quantified; four register-file contracts are the
separate inductive obligations explained in ../proofs/runtime_audit.txt.  In the 237
variant only the zero-decrement gate exit changes, to state 7 for every slot.
Everything outside the register-file gates is checked against literal rows.

Usage: python3 check_symbolic_sites.py [--gap 36] [--baseline]
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'machine'
UPSTREAM = HERE.parent / 'reference/pa238/PA/m238'
SLOTS = (6, 7, 0, 2, 1, 8, 4, 3, 5)
SELECTORS = (119, 100, 80, 75, 60, 71, 52, 126, 147)
PLAIN = ('plain',)


def load_table(path):
    rows = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, n = line.split()
        rows[int(q), int(b)] = (int(w), d, int(n))
    return rows


def check_file_gate_rows(table, baseline):
    """Check every literal premise of the four inductive file contracts.

    The proofs themselves are given in runtime_audit.txt and the cited
    upstream files. This finite check prevents silently applying those
    contracts to a table with a changed macro-internal transition.
    """
    pairs = {
        2: ((0, 'L', 2), (1, 'L', 5)),
        4: ((0, 'L', 7), (1, 'L', 4)),
        5: ((0, 'L', 8), (1, 'L', 5)),
        6: ((0, 'L', 9), (1, 'R', 10)),
        9: ((1, 'L', 13), (1, 'L', 9)),
        10: ((0, 'R', 6), (1, 'R', 10)),
        13: ((0, 'L', 15), (0, 'L', 9)),
        15: ((0, 'L', 11), (1, 'L', 15)),
        78: ((0, 'R', 98), (1, 'R', 78)),
        98: ((0, 'R', 117), (1, 'R', 78)),
        99: ((0, 'R', 118), (1, 'R', 99)),
        117: ((0, 'L', 0), (1, 'R', 10)),
        118: ((1, 'R', 137), (1, 'R', 99)),
        137: ((1, 'R', 149), (1, 'R', 137)),
        149: ((0, 'L', 15), (0, 'R', 137)),
    }
    required = {(q, b): row for q, rows in pairs.items()
                for b, row in enumerate(rows)}
    required.update({(7, 1): (1, 'L', 4), (8, 1): (1, 'L', 5),
                     (11, 1): (1, 'L', 15)})
    for r, q in enumerate(SELECTORS):
        required[q, 1] = (1, 'R', q)
        required[q, 0] = (0, 'R', SELECTORS[r-1] if r else (0 if baseline else 3))
    if baseline:
        required.update({(0, 0): (1, 'L', 1), (0, 1): (0, 'L', 2),
                         (1, 0): (0, 'L', 3), (3, 1): (1, 'L', 4)})
    else:
        required.update({(0, 0): (1, 'L', 4), (3, 1): (0, 'L', 2)})
    for key, expected in required.items():
        assert table.get(key) == expected, ('file-contract premise', key, expected, table.get(key))
    return sorted(required)


def inventory(program_path=None):
    """Read the published complete leaf inventory, independently of site.tsv."""
    src = (program_path or UPSTREAM / 'coq/tm/Prog238.v').read_text()
    body = src.split('Definition path_inventory238', 1)[1].split('].', 1)[0]
    rows = re.findall(r'\((\d+)%positive, E(Inc|Decnz|Break|Continue|Halt)(?: (\d+))?\)', body)
    listed = [(int(p), tuple(map(int, bin(int(p))[3:])), op, int(arg or 0))
              for p, op, arg in rows]
    assert len(listed) == 4409

    # Independent completeness check: enumerate every root-to-leaf path from
    # the 185-node graph, then compare the ordered inventory exactly.
    def edge(text):
        m = re.fullmatch(r'E(Node|Inc|Decnz|Break|Continue|Halt)(?: (\d+))?', text.strip())
        assert m is not None, text
        return m[1], int(m[2] or 0)

    graph_text = src.split('Definition nodes238', 1)[1].split('end.', 1)[0]
    graph = {int(n): (edge(a), edge(b)) for n, a, b in
             re.findall(r'\| (\d+) => \(([^,]+), ([^)]+)\)', graph_text)}
    assert set(graph) == set(range(185))
    generated, visited = [], set()

    def descend(n, path, active):
        assert n not in active, 'decision graph must be acyclic'
        visited.add(n)
        for bit, (op, arg) in enumerate(graph[n]):
            nextpath = path + (bit,)
            if op == 'Node':
                descend(arg, nextpath, active | {n})
            else:
                p = int('1' + ''.join(map(str, nextpath)), 2)
                generated.append((p, nextpath, op, arg))

    descend(0, (), set())
    assert visited == set(graph)
    assert generated == listed, 'published inventory must equal complete graph expansion'
    return listed


def inc(path):
    if not path:
        return ()
    n = (int(''.join(map(str, path)), 2) + 1) % (1 << len(path))
    return tuple(map(int, f'{n:0{len(path)}b}'))


def strip(bit, k, path):
    end = len(path)
    while end and k:
        end -= 1
        if path[end] == bit:
            k -= 1
    return path[:end]


def route(path, op, arg, zero):
    if op == 'Inc':
        return None, inc(path), all(path), ('incremented', SLOTS[arg])
    if op == 'Decnz':
        slot = SLOTS[arg]
        if zero:
            chopped = strip(0, 1, path)
            return (slot, True), inc(chopped), all(chopped), PLAIN
        return (slot, False), inc(path), all(path), ('decremented', slot)
    if op == 'Break':
        chopped = strip(0, arg, path)
        return None, inc(chopped), all(chopped), PLAIN
    if op == 'Continue':
        return None, strip(1, arg, path), False, PLAIN
    assert op == 'Halt'
    return None


def site_start(path, gap, extra=0, phase=PLAIN):
    # SCell(b) is (b,); SRun(b,a,c) is (b,a,c), denoting a*G+c bits.
    assert gap + extra >= len(path)
    return (25, False, ((1,),),
            tuple((b,) for b in path) + ((0, 1, gap + extra - len(path)), (1,)), phase)


def normalize(segments, left=False):
    out = []
    for s in segments:
        b, a, c = (s[0], 0, 1) if len(s) == 1 else s
        if a == c == 0:
            continue
        if out and out[-1][0] == b:
            _, aa, cc = out.pop()
            a, c = a + aa, c + cc
        out.append((b, a, c))
    if left:
        while out and out[-1][0] == 0:
            out.pop()
    return tuple(out)


def fingerprint(s):
    q, on_left, left, right, phase = s
    return q, on_left, normalize(left, True), normalize(right), phase


def file_gate(q, phase, branch, baseline):
    if phase == PLAIN:
        if q not in SELECTORS:
            return None
        r = SELECTORS.index(q)
        return (2 if r == 0 else 8), ('marked', r), 'mark'
    if phase[0] == 'marked':
        r = phase[1]
        if r >= 9:
            return None
        if q == 99:
            return 11, ('incremented', r), 'increment'
        if q == 78 and branch is not None and branch[0] == r:
            if branch[1]:
                return (3 if baseline and r == 0 else 7), PLAIN, 'decrement_zero'
            return (15 if r == 0 else 11), ('decremented', r), 'decrement_positive'
    return None


def join_equal_head(segments):
    """Exact representation change:  b^(a*G+c)b^(a'*G+c')=b^((a+a')*G+c+c')."""
    b = segments[0][0]
    a = c = count = 0
    for seg in segments:
        if seg[0] != b:
            break
        count += 1
        if len(seg) == 1:
            c += 1
        else:
            a += seg[1]
            c += seg[2]
    if count < 2 or not c:
        return None
    return ((b, a, c),) + segments[count:]


def advance(s, branch, table, baseline, join_runs=False):
    """Returns (next, progress, audit_event); raises if no proved rule applies."""
    q, on_left, left, right, phase = s
    if not on_left and not right:
        gate = file_gate(q, phase, branch, baseline)
        if gate is not None:
            n, newphase, name = gate
            return (n, True, left, (), newphase), True, ('macro', name)
        row = table.get((q, 0))
        if row is not None and row[:2] == (0, 'L'):
            return (row[2], True, left, (), phase), True, ('cell', q, 0)
        raise ValueError(('file gate missing', s, branch))
    if on_left:
        if not left:
            return (q, False, (), ((0,),) + right, phase), False, ('view',)
        seg, tail = left[0], left[1:]
        if len(seg) == 1:
            return (q, False, tail, (seg,) + right, phase), False, ('view',)
        b, a, c = seg
        row = table.get((q, b))
        if row is not None and row[1:] == ('L', q):
            return (q, True, tail, ((row[0], a, c),) + right, phase), c > 0, ('scan', q, b, a, c)
        if c:
            return (q, True, ((b,), (b, a, c - 1)) + tail, right, phase), False, ('expose',)
        if not a:
            return (q, True, tail, right, phase), False, ('empty',)
        joined = join_equal_head(left) if join_runs else None
        if joined is not None:
            n = len(left) - len(joined) + 1
            return (q, True, joined, right, phase), False, ('join_left', q, left[:n], joined[0])
        raise ValueError(('unexposable variable left run', s))
    seg, tail = right[0], right[1:]
    b = seg[0]
    row = table.get((q, b))
    if len(seg) == 1:
        if row is None:
            raise ValueError(('undefined transition', s))
        w, d, n = row
        if d == 'L':
            return (n, True, left, ((w,),) + tail, phase), True, ('cell', q, b)
        return (n, False, ((w,),) + left, tail, phase), True, ('cell', q, b)
    _, a, c = seg
    if row is not None and row[1:] == ('R', q):
        return (q, False, ((row[0], a, c),) + left, tail, phase), c > 0, ('scan', q, b, a, c)
    if c:
        return (q, False, left, ((b,), (b, a, c - 1)) + tail, phase), False, ('expose',)
    if not a:
        return (q, False, left, tail, phase), False, ('empty',)
    joined = join_equal_head(right) if join_runs else None
    if joined is not None:
        n = len(right) - len(joined) + 1
        return (q, False, left, joined, phase), False, ('join_right', q, right[:n], joined[0])
    raise ValueError(('unexposable variable right run', s))


def execute(start, target, branch, table, baseline, fuel=768, join_runs=False):
    current, moved = start, False
    trace = []
    want = None if target is None else fingerprint(target)
    for iteration in range(fuel):
        accepted = current[0] == 238 if target is None else fingerprint(current) == want
        if moved and accepted:
            return current, trace
        current, progress, event = advance(current, branch, table, baseline, join_runs)
        trace.append(event)
        moved |= progress
    raise ValueError(('out of fuel', current, target))


def main():
    if not __debug__:
        raise SystemExit('Run without Python -O: assertions are verification checks.')
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline', action='store_true')
    ap.add_argument('--gap', type=int, default=36)
    ap.add_argument('--join-runs', action='store_true',
                    help='add a zero-transition rule joining adjacent equal-bit runs/cells')
    ap.add_argument('--report', type=Path)
    ap.add_argument('--table', type=Path, help='literal table using the original PA238 state labels')
    ap.add_argument('--program', type=Path, help='upstream Prog238.v containing the complete path inventory')
    args = ap.parse_args()
    tablepath = args.table or (UPSTREAM / 'machine/pa_238.tm' if args.baseline else BASE / 'u237_oldlabels.tm')
    table = load_table(tablepath)
    file_gate_rows = check_file_gate_rows(table, args.baseline)
    sites = inventory(args.program)
    successes = []
    events = Counter()
    used_rows = set()
    maximum = 0
    joins = []
    for p, path, op, arg in sites:
        for zero in [False] if op == 'Halt' else [False, True]:
            start = site_start(path, args.gap)
            routing = route(path, op, arg, zero)
            if routing is None:
                branch, target = None, None
            else:
                branch, path2, overflow, phase = routing
                target = site_start(path2, args.gap, int(overflow), phase)
            try:
                end, trace = execute(start, target, branch, table, args.baseline,
                                     join_runs=args.join_runs)
            except ValueError as err:
                print(json.dumps({'success': False, 'path': p, 'op': op, 'arg': arg,
                                  'zero': zero, 'error': err.args}, indent=2))
                raise
            for iteration, event in enumerate(trace):
                events[event[0] if event[0] != 'macro' else event[1]] += 1
                if event[0] in ('cell', 'scan'):
                    used_rows.add(event[1:3])
                if event[0] in ('join_left', 'join_right'):
                    joins.append({'path_positive': p, 'op': op, 'arg': arg, 'zero': zero,
                                  'symbolic_iteration': iteration, 'side': event[0][5:],
                                  'state': event[1], 'before': event[2], 'after': event[3]})
            maximum = max(maximum, len(trace))
            successes.append([p, op, arg, zero, len(trace)])
    report = {
        'success': True,
        'variant': 'PA238 baseline' if args.baseline else 'PA237 old labels',
        'literal_table_sha256': hashlib.sha256(tablepath.read_bytes()).hexdigest(),
        'program_sha256': hashlib.sha256((args.program or UPSTREAM / 'coq/tm/Prog238.v').read_bytes()).hexdigest(),
        'base_gap': args.gap,
        'adjacent_run_joining_enabled': args.join_runs,
        'gap_quantifier': 'for every natural G; available path area = base_gap + G',
        'file_quantifier': 'every list vs of naturals with len(vs)>=9, under the selected zero/nonzero branch hypothesis',
        'site_count': len(sites),
        'inventory_coverage': 'all root-to-leaf paths independently regenerated from the 185-node acyclic graph and compared exactly',
        'variant_count': len(successes),
        'maximum_symbolic_iterations': maximum,
        'maximum_path_length': max(len(path) for _, path, _, _ in sites),
        'events': dict(sorted(events.items())),
        'literal_rows_checked': [list(x) for x in sorted(used_rows)],
        'file_gate_literal_premises_checked': [list(x) for x in file_gate_rows],
        'adjacent_run_joins': joins,
        'success_rows_sha256': hashlib.sha256(json.dumps(successes, separators=(',', ':')).encode()).hexdigest(),
        'qualification': 'Executable symbolic certificate, not a Rocq kernel-checked result. File gates require the separate inductive proofs.'
    }
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ('literal_rows_checked', 'file_gate_literal_premises_checked',
                                   'adjacent_run_joins')}, indent=2))
    if args.report:
        args.report.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
