#!/usr/bin/env python3
"""Reproduce PA237 from Mira's exact, authenticated PA238 transition table.

Only four transition rows change. Old state1 is deleted. The old label3 is
new start, and breadth-first relabelling yields start0 and terminal237.
Every retained state, including the terminal, must be graph reachable.
This generator proves finite table identity, not semantic equivalence.
"""
from __future__ import annotations
import argparse
from collections import deque
import hashlib
import json
from pathlib import Path

BASE_SHA256 = 'ffe370842d70bae96688ad5e290073edffe0bb213cf12fe562a75a74bec966de'
PA237_SHA256 = 'ec31958ae3c64f6352fff50f3e0aece33994c0cc0b72051a64fb1012dcdaf3df'
DELTA = {(0, 0): (1, 'L', 4), (119, 0): (0, 'R', 3),
         (3, 0): (1, 'L', 9), (3, 1): (0, 'L', 2)}
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MACHINE = ROOT / 'machine'
REFERENCE = ROOT / 'reference/pa238/PA/m238'

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def parse(data: bytes):
    rows = {}
    start = None
    for line in data.decode('ascii').splitlines():
        if line.startswith('#! start '):
            assert start is None
            start = int(line.split()[-1])
        elif line and not line.startswith('#'):
            q, b, w, d, t = line.split()
            q, b, w, t = map(int, (q, b, w, t))
            assert b in (0, 1) and w in (0, 1) and d in ('L', 'R')
            assert (q, b) not in rows
            rows[q, b] = w, d, t
    assert start is not None
    return start, rows

def render(start: int, rows: dict) -> bytes:
    return ('#! start %d\n' % start + ''.join(
        f'{q} {b} {w} {d} {t}\n'
        for (q, b), (w, d, t) in sorted(rows.items()))).encode('ascii')

def generate(baseline: bytes):
    assert sha256(baseline) == BASE_SHA256, 'Baseline hash mismatch'
    start, rows = parse(baseline)
    assert start == 0
    assert set(rows) == {(q, b) for q in range(238) for b in (0, 1)}
    original = dict(rows)
    assert all(rows[k] != v for k, v in DELTA.items())
    rows.update(DELTA)
    assert {k for k, v in rows.items() if v != original[k]} == set(DELTA)
    rows = {k: v for k, v in rows.items() if k[0] != 1}
    assert len(rows) == 474 and all(t != 1 for _, _, t in rows.values())
    seen, todo, order = {3}, deque([3]), []
    while todo:
        q = todo.popleft()
        order.append(q)
        if q == 238:
            continue
        for b in (0, 1):
            t = rows[q, b][2]
            if t not in seen:
                seen.add(t)
                todo.append(t)
    assert seen == set(range(239)) - {1}, 'Graph unreachable retained state'
    order.remove(238)
    order.append(238)
    forward = {old: new for new, old in enumerate(order)}
    dense = {(forward[q], b): (w, d, forward[t])
             for (q, b), (w, d, t) in rows.items()}
    assert len(order) == 238 and forward[3] == 0 and forward[238] == 237
    assert set(dense) == {(q, b) for q in range(237) for b in (0, 1)}
    output = render(0, dense)
    assert sha256(output) == PA237_SHA256, 'Generated table hash mismatch'
    metadata = {
        'baseline_sha256': BASE_SHA256, 'sha256': PA237_SHA256,
        'states': 237, 'transitions': 474, 'terminal_state': 237,
        'start_state': 0, 'blank_symbol': 0,
        'all_237_working_states_graph_reachable': True,
        'old_to_new': forward, 'new_to_old': order,
        'old_label_patch': {f'{q}/{b}': list(v) for (q, b), v in DELTA.items()},
        'deleted_old_state': 1, 'start_old': 3, 'halting_old': 238,
        'verification_scope': 'Exact finite construction and graph reachability only'
    }
    return output, render(3, rows), metadata

def main():
    if not __debug__:
        raise SystemExit('Run without Python -O: assertions are verification checks.')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, default=REFERENCE/'machine/pa_238.tm')
    p.add_argument('--output-dir', type=Path, default=MACHINE)
    p.add_argument('--check', action='store_true', help='Compare existing table bytes; write nothing.')
    a = p.parse_args()
    dense, old, metadata = generate(a.baseline.read_bytes())
    if a.check:
        assert (a.output_dir/'u237.tm').read_bytes() == dense
        assert (a.output_dir/'u237_oldlabels.tm').read_bytes() == old
    else:
        a.output_dir.mkdir(parents=True, exist_ok=True)
        (a.output_dir/'u237.tm').write_bytes(dense)
        (a.output_dir/'u237_oldlabels.tm').write_bytes(old)
        (a.output_dir/'u237_labels.json').write_text(json.dumps(metadata, indent=2)+'\n')
    print(json.dumps({k: metadata[k] for k in (
        'states', 'transitions', 'sha256', 'all_237_working_states_graph_reachable')}, indent=2))

if __name__ == '__main__':
    main()
