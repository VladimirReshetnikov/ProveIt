#!/usr/bin/env python3
"""Verify the complete 717670-step blank-tape PA237 bootstrap.

Both the compact transition table and the original-label view are executed.
The final tape is compared with a separately specified complete register-file
encoding, including every spare block. This is finite computational evidence.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from generate_u237 import generate, parse, PA237_SHA256

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
STEPS = 717670
ACTIVE = [0, 2, 0, 0, 0, 0, 6, 0, 0]
SPARES = 307
ORIGIN = -15
HEADER = 22
HEAD = -14
STATE_OLD = 25

def expected_tape():
    cells = {ORIGIN, HEADER}
    cursor = HEADER + 1
    for value in ACTIVE + [0] * SPARES:
        cells.update(range(cursor + 1, cursor + value + 2))
        cursor += value + 2
    return cells

def execute(raw, steps):
    q, table = parse(raw)
    actions = {(s, b): (w, -1 if d == 'L' else 1, t)
               for (s, b), (w, d, t) in table.items()}
    head, ones, minimum, maximum = 0, set(), 0, 0
    for clock in range(steps):
        action = actions.get((q, int(head in ones)))
        assert action is not None, f'Early halt at step {clock}'
        w, direction, q = action
        if w:
            ones.add(head)
        else:
            ones.discard(head)
        head += direction
        minimum, maximum = min(minimum, head), max(maximum, head)
    return q, head, ones, [minimum, maximum]

def main():
    if not __debug__:
        raise SystemExit('Run without Python -O.')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, default=ROOT/'reference/pa238/PA/m238/machine/pa_238.tm')
    p.add_argument('--machine', type=Path, default=ROOT/'machine/u237.tm')
    p.add_argument('--report', type=Path, help='Optional JSON report output.')
    a = p.parse_args()
    compact, old, metadata = generate(a.baseline.read_bytes())
    assert a.machine.read_bytes() == compact
    expected = expected_tape()
    old_end = execute(old, STEPS)
    new_end = execute(compact, STEPS)
    compact_state = metadata['old_to_new'][STATE_OLD]
    assert old_end[:3] == (STATE_OLD, HEAD, expected)
    assert new_end[:3] == (compact_state, HEAD, expected)
    assert old_end[3] == new_end[3]
    tape_hash = hashlib.sha256((json.dumps(sorted(expected), separators=(',', ':'))+'\n').encode()).hexdigest()
    assert tape_hash == 'fbc655a38f8447b4d8a6e85debf71030083775d27acb191e3ea48f53aa94b88f'
    report = {
        'status': 'PASS finite exact bootstrap verification',
        'machine_sha256': PA237_SHA256, 'literal_steps': STEPS,
        'initial_blank_symbol': 0, 'initial_state': 0,
        'final_state': compact_state, 'final_state_old': STATE_OLD,
        'head': HEAD, 'marker': ORIGIN, 'header': HEADER,
        'program_counter': [], 'gap': HEADER - HEAD,
        'physical_registers': ACTIVE, 'spare_blocks': SPARES,
        'all_spare_values_zero': True, 'total_blocks': 9 + SPARES,
        'one_cells': len(expected), 'one_cell_range': [min(expected), max(expected)],
        'visited_head_range': new_end[3],
        'complete_tape_sha256': tape_hash,
        'complete_tape_hash_encoding': 'ASCII compact JSON sorted one-cell coordinates, followed by LF',
        'all_one_cell_coordinates': sorted(expected),
        'scope': 'Finite literal replay and table relabelling; not an unbounded simulation theorem.'
    }
    if a.report:
        a.report.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='all_one_cell_coordinates'},indent=2))

if __name__ == '__main__':
    main()
