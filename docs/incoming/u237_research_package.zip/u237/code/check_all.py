#!/usr/bin/env python3
"""Reproduce U237 checks using only Python's standard library.

The reference source-only audit is not a Coq kernel check. The symbolic
certificate uses the mathematical file-contract lemmas in the report.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def check_hashes():
    manifest = ROOT / 'SHA256SUMS'
    if not manifest.is_file():
        raise SystemExit('Missing distributed SHA256SUMS manifest.')
    count = 0
    for line in manifest.read_text().splitlines():
        digest, relative = line.split('  ', 1)
        p = Path(relative)
        assert not p.is_absolute() and '..' not in p.parts
        actual = hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
        assert actual == digest, f'SHA-256 mismatch: {relative}'
        count += 1
    print(f'PASS: all {count} distributed file hashes match.', flush=True)


def run(args, log_name, out):
    print('Running ' + ' '.join(args), flush=True)
    result = subprocess.run([sys.executable, *args], cwd=ROOT,
                            capture_output=True, text=True)
    (out / log_name).write_text(result.stdout + result.stderr)
    if result.returncode:
        print(result.stdout, end='')
        print(result.stderr, end='', file=sys.stderr)
        raise SystemExit(result.returncode)
    print(f'PASS: {log_name}', flush=True)


def main():
    if not __debug__:
        raise SystemExit('Run without Python -O: assertions are verification checks.')
    check_hashes()
    out = ROOT / 'verification-output'
    out.mkdir(exist_ok=True)
    run(['code/generate_u237.py', '--check'], 'construction.log', out)
    run(['code/verify_patch.py'], 'independent_patch_and_bootstrap.json', out)
    run(['code/verify_bootstrap.py', '--report', str(out/'bootstrap.json')],
        'bootstrap.log', out)
    run(['code/check_symbolic_sites.py', '--gap', '36', '--join-runs',
         '--report', str(out/'symbolic_u237_gap36.json')], 'symbolic_u237.log', out)
    run(['code/check_symbolic_sites.py', '--baseline', '--gap', '38',
         '--report', str(out/'symbolic_pa238_gap38.json')], 'symbolic_reference.log', out)
    run(['reference/pa238/PA/m238/check.py', '--source-only'],
        'reference_source_only.log', out)
    for current, reference in (
        ('bootstrap.json', 'bootstrap.json'),
        ('symbolic_u237_gap36.json', 'symbolic_u237_gap36.json'),
        ('symbolic_pa238_gap38.json', 'symbolic_pa238_gap38.json'),
        ('independent_patch_and_bootstrap.json', 'independent_review.json'),
    ):
        generated = json.loads((out/current).read_text())
        expected = json.loads((ROOT/'certificates'/reference).read_text())
        assert generated == expected, f'Receipt mismatch: {current}'
    print('PASS: every reproduced receipt equals its distributed certificate.')
    print('COMPLETE: finite checks and universal symbolic certificate reproduced.')
    print('No PA or Rocq kernel certificate was compiled by this script.')


if __name__ == '__main__':
    main()
