#!/usr/bin/env python3
"""Independent literal patch audit: guarded symbolic traces and blank prefix.

The symbolic traces leave every unlisted tape cell arbitrary. They fail if
execution tries to read such a cell. Their equality therefore applies to
every surrounding tape, not just a finite list of sample tapes.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / 'reference/pa238/PA/m238/machine/pa_238.tm'
NEW = ROOT / 'machine/u237_oldlabels.tm'
NORMAL = ROOT / 'machine/u237.tm'
MAPPING = ROOT / 'machine/u237_labels.json'


def read_table(path):
    lines = path.read_text().splitlines()
    assert lines[0].startswith('#! start ')
    start = int(lines[0].split()[-1])
    table = {}
    for line in lines[1:]:
        if not line.strip() or line.startswith('#'):
            continue
        q, b, w, d, t = line.split()
        key = int(q), int(b)
        assert key not in table
        assert d in ('L', 'R')
        table[key] = int(w), (-1 if d == 'L' else 1), int(t)
    return start, table


def symbolic(table, q, known, steps):
    cells = dict(known)
    head = 0
    trace = []
    for _ in range(steps):
        assert head in cells, 'attempt to read arbitrary context'
        bit = cells[head]
        write, direction, target = table[q, bit]
        trace.append([q, head, bit, write, direction, target])
        cells[head] = write
        head += direction
        q = target
    return (q, head, cells), trace


def main():
    if not __debug__:
        raise SystemExit('Run without Python -O: assertions are verification checks.')
    oldstart, old = read_table(OLD)
    start, new = read_table(NEW)
    normalstart, normal = read_table(NORMAL)
    assert oldstart == 0 and start == 3 and normalstart == 0
    assert set(old) == {(q, b) for q in range(238) for b in (0, 1)}
    assert set(new) == {(q, b) for q in range(238) if q != 1 for b in (0, 1)}
    assert set(normal) == {(q, b) for q in range(237) for b in (0, 1)}
    patches = {
        (0, 0): (1, -1, 4),
        (119, 0): (0, 1, 3),
        (3, 0): (1, -1, 9),
        (3, 1): (0, -1, 2),
    }
    assert {key: value for key, value in new.items() if value != old[key]} == patches
    assert all(t != 1 for _, _, t in new.values())
    mapping = {int(k): v for k, v in
               json.loads(MAPPING.read_text())['old_to_new'].items()}
    assert set(mapping) == (set(range(239)) - {1})
    assert set(mapping.values()) == set(range(238))
    assert mapping[start] == normalstart and mapping[238] == 237
    assert {(mapping[q], bit): (write, move, mapping[target])
            for (q, bit), (write, move, target) in new.items()} == normal

    traces = []
    for name, state, cells, length in (
        ('zero_decrement', 0, {-2: 1, -1: 0, 0: 0}, 3),
        ('register_selection', 119, {0: 0, 1: 1}, 2),
    ):
        oldresult, oldtrace = symbolic(old, state, cells, length)
        newresult, newtrace = symbolic(new, state, cells, length)
        assert oldresult == newresult
        traces.append({'name': name, 'known_cells': cells,
                       'old_trace': oldtrace, 'new_trace': newtrace,
                       'common_result': oldresult})

    # Independently replay the released contiguous-label table.
    state, head, ones = normalstart, 0, set()
    for clock in range(717670):
        write, move, state = normal[state, int(head in ones)]
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head += move

    # The full tape is specified from the reference physical register file.
    active = [0, 2, 0, 0, 0, 0, 6, 0, 0]
    spares = [0] * 307
    expected = {-15, 22}
    cursor = 23
    for value in active + spares:
        expected.update(range(cursor + 1, cursor + value + 2))
        cursor += value + 2
    assert (state, head, ones) == (19, -14, expected)
    incoming = {str(q): [[a, b] for (a, b), (_, _, t) in old.items() if t == q]
                for q in (0, 1, 3, 117, 119)}
    result = {
        'status': 'PASS_INDEPENDENT_LITERAL_REVIEW',
        'normal_table_sha256': hashlib.sha256(NORMAL.read_bytes()).hexdigest(),
        'symbolic_macro_traces': traces,
        'reference_incoming_edges': incoming,
        'blank_prefix_steps': 717670,
        'checkpoint_normal_state': state,
        'checkpoint_old_label': 25,
        'head': head,
        'marker': -15,
        'header': 22,
        'gap': 36,
        'all_316_registers_and_entire_tape_match': True,
        'active_registers': active,
        'spare_register_count': len(spares),
        'nonzero_spares': [],
        'one_cells': len(ones),
        'scope': 'Guarded universal local macros plus finite blank-prefix replay. '
                 'Full runtime correctness additionally needs the register/dispatcher '
                 'invariant and gap-36 site verification described in the review note.',
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
