# Height-Two Preorder Polynomials

**Matching supports, nonreal-root families, and crown obstructions**  
Research manuscript developed with ChatGPT for Vladimir Reshetnikov, 28 September 2026.

## Read first

`article.pdf` is the 26-page article. `article.tex` is its complete LaTeX source,
including its bibliography and both TikZ diagrams. No external image or font
files are needed to rebuild it.

The main proposed contributions are:

1. For a height-at-most-two **poset** with bipartite comparability graph G,
   the support polynomial is `(1+t)^n p_G(t/(1+t)^2)`, where `p_G` counts
   distinct perfectly matchable vertex subsets, not individual matchings.
2. For the graph Theta_m consisting of m parallel paths of length three,
   the article proves a closed polynomial formula and the exact number of
   real roots. For m >= 3, its preorder support polynomial has only two real
   roots for even m and four for odd m; the proportion of nonreal roots tends
   to one while the graph remains connected and has treewidth at most two.
3. A sixth-root-of-unity cactus matrix gives a determinantal formula, a
   stable multivariate refinement, weighted real-rootedness, and interlacing.
   Univariate cactus real-rootedness is explicitly credited to prior work.
4. Induced crowns force arbitrarily large minimal nonfaces in every lattice
   triangulation of the canonical ProveIt root polytope and indispensable
   toric binomials of arbitrarily large degree. This does not disprove the
   existence of some other flag polytope with the same h-vector.

## Priority and proof status

The first disproof of the preorder real-rootedness conjecture is **not**
claimed as new. A previously posted eight-element example by Shivam Patel
was discovered during the source audit. It is Theta_3; independent exact
enumeration confirms its 1,281 lattice points and polynomial. The general
Theta_m formula and root-distribution theorem extend it.

The separate 17-element example is a transfer of the classical
Stembridge–Ohsugi–Tsuchiya graph polynomial, not a newly discovered graph
counterexample and not a minimum-size claim.

The manuscript is not independently refereed or checked in Lean. It states
two published root-polytope inputs explicitly. No unrefereed general theorem
in ProveIt is needed for the principal proofs. See `STATUS.md` and
`sources.md` for precise boundaries.

## Reproduce the exact checks

Requirements: Python 3.10+ (standard library only), a C++17 compiler, and
LaTeX only when rebuilding the PDF. From this directory:

```sh
python3 code/verify.py
python3 code/verify_theta.py
mkdir -p build
c++ -O3 -std=c++17 -Wall -Wextra -pedantic \
    code/direct_counterexample.cpp -o build/direct_counterexample
./build/direct_counterexample > data/direct_counterexample.json
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, `make verify` runs all computational checks, and `make pdf`
rebuilds the article.

### Recorded checks

- All 512 labeled bipartite 3-by-3 graphs: direct ideal-inequality enumeration
  versus the support formula; independent demand-vector counting.
- 24 additional 4-by-3 graphs, with recorded seed 20260928.
- Crown formulas through r=8 and direct lattice checks through r=4.
- 936 exact square-minor comparisons in six cactus test configurations.
- Theta-family matching-support enumeration through m=9; direct lattice
  enumeration through m=4; rational Sturm root counts through m=20.
- Two graph-polynomial calculations for the 17-element example and a
  separate C++ enumeration of all 8,408,566 original lattice points.

All tests passed in the recorded run. The Python checks use integers and
fractions, the cactus minors use pairs of integers in Z[zeta], and the C++
program uses exact finite state sets. No floating-point root calculation is
needed by the certificates. Finite computations are checks of the proofs,
not extrapolations establishing their infinite-family claims.

## Package contents

- `article.tex`, `article.pdf`: complete source and compiled article.
- `code/verify.py`: graph, preorder, crown, and cactus checks.
- `code/verify_theta.py`: theta formulas, direct enumeration, exact Sturm checks.
- `code/direct_counterexample.cpp`: independent full 17-element enumeration.
- `data/verification.json`: primary exact verification output.
- `data/theta_verification.json`: theta coefficient vectors and root counts.
- `data/direct_counterexample.json`: direct C++ counts.
- `data/board_certificate.csv`: all 90 polynomial states of the interval-board recurrence.
- `STATUS.md`, `sources.md`: claim audit and sources consulted.
- `SHA256SUMS.txt`: integrity checksums of package files (other than itself).

The article includes ten proposed research questions and a staged
formalization plan. No changes were made to the ProveIt repository.
