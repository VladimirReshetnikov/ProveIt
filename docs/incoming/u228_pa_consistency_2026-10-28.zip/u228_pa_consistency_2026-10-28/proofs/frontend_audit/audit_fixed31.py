"""Independent, newly authored structural/macro checks; reads supplied JSON only."""
from pathlib import Path
import json, hashlib, math
ROOT=Path('/workspace/scratch/ce29ab924f1c')
F=ROOT/'u_machine_20261028/frontend'
def freeze(v): return tuple(map(freeze,v)) if isinstance(v,list) else v
def leaf(t): return isinstance(t[0],str)
def size(t): return 1 if leaf(t) else size(t[0])+size(t[1])
def fromsites(rows):
 d={r[0]:tuple(r[1:]) for r in rows}
 def rec(p): return d[p] if p in d else (rec(p+'0'),rec(p+'1'))
 return rec('')
def cfg(t):
 rows=[]
 def visit(n,entry,breaks,continues):
  if leaf(n):
   op,r=n
   if op=='CI': nxt=(entry+1,)
   elif op=='CD': nxt=(breaks[0],entry+1)
   elif op=='CB': nxt=(breaks[r-1],)
   elif op=='CC': nxt=(continues[r-1],)
   elif op=='CH': nxt=()
   else: raise ValueError(op)
   rows.append((op,None if op in ('CB','CC') else r,nxt)); return
  split=entry+size(n[0]);end=split+size(n[1])
  visit(n[0],entry,[end]+breaks,continues)
  visit(n[1],split,breaks,[entry]+continues)
 visit(t,0,[],[]);return rows

def run(t,regs,cap=100000):
 code=cfg(t);r=list(regs);pc=0
 for step in range(cap):
  if pc==len(code):return r,step
  assert 0<=pc<len(code),(pc,len(code))
  op,k,nxt=code[pc]
  if op=='CI':r[k]+=1;pc=nxt[0]
  elif op=='CD':
   if r[k]==0:pc=nxt[0]
   else:r[k]-=1;pc=nxt[1]
  else:pc=nxt[0]
 raise ValueError('cap exceeded')
def pair(a,b):return (a+b)*(a+b+1)//2+b
def unpair(z):
 n=(math.isqrt(8*z+1)-1)//2;b=z-n*(n+1)//2;return n-b,b
M={k:freeze(v) for k,v in json.loads((F/'macros_fixed31.json').read_text()).items()}
old=fromsites(json.loads((ROOT/'research215_encoding/partial_permuted210.sites.json').read_text()))
new=fromsites(json.loads((F/'fixed31_dp.sites.json').read_text()))
meta=json.loads((F/'FIXED31_SOURCE.json').read_text());lo,hi=meta['replaced_interval'];delta=size(new)-size(old)
# Reconstruct complete replacement by ordered closed macros, without builder imports.
def seq(ts):return ts[0] if len(ts)==1 else (ts[0],seq(ts[1:]))
repl=seq([M['gate'],M['readc'],('CI',4),('CI',4),('CI',4),('CI',5)]+[M[t] for t in meta['tokens'][2:]]);oc,nc,rc=cfg(old),cfg(new),cfg(repl)
assert nc[lo:hi+delta]==[(o,k,tuple(j+lo for j in es)) for o,k,es in rc]
for i,(o,k,es) in enumerate(oc):
 if lo<=i<hi:continue
 def shift(j):
  assert not lo<j<hi
  return j if j<=lo else j+delta
 assert nc[i if i<lo else i+delta]==(o,k,tuple(map(shift,es)))
# Original and retained final gate must be same literal code/CFG.
assert oc[4556:4590]==[(o,k,tuple(j+4556 for j in es))for o,k,es in cfg(M['gate'])]
assert nc[4556+delta:4590+delta]==[(o,k,tuple(j+4556+delta for j in es))for o,k,es in cfg(M['gate'])]
checks={}
count=0
for a in range(6):
 for b in range(6):
  for c in range(6):
   for top in (0,1,7):
    r=[31,top,17,c,a,b,0,0,23];out,_=run(M['gate'],r)
    exp=[31,0 if c in (a,b) else top,17,0,0,0,0,0,23]
    assert out==exp,(r,out,exp);count+=1
checks['gate_cases']=count
count=0
for name,target in [('readc',3),('reada',4),('readb',5)]:
 for z in range(150):
  r=[31,7,17,0,0,0,0,0,z];out,_=run(M[name],r);a,b=unpair(z);exp=r.copy();exp[target]=a;exp[8]=b
  assert out==exp,(name,z,out,exp);count+=1
checks['reader_cases']=count
count=0
for a in range(12):
 for b in range(12):
  r=[31,7,17,13,a,b,0,0,23];out,_=run(M['affine'],r);exp=r.copy();exp[4]=a+b+1;assert out==exp;count+=1
checks['affine_cases']=count
count=0
for macro,tag in [('I',0),('R',1),('Q',2),('E',3)]:
 for a in range(5):
  for b in range(5):
   for w in (0,3):
    r=[31,b,pair(a,w),11,12,13,0,0,23];out,_=run(M[macro],r);exp=r.copy();exp[1]=4*pair(a,b)+tag;exp[2]=w
    assert out==exp,(macro,a,b,w,out,exp);count+=1
checks['binary_constructor_cases']=count
count=0
for name,target in [('a',4),('b',5),('c',3)]:
 for top in range(5):
  for w in range(5):
   r=[31,top,w,2,3,4,0,0,23];out,_=run(M[name],r);exp=r.copy();exp[1]=r[target];exp[2]=pair(top,w)
   assert out==exp;(count:=count+1)
checks['push_parameter_cases']=count
for top in range(12):
 r=[31,top,3,11,12,13,0,0,23];out,_=run(M['N'],r);exp=r.copy();exp[1]=4*pair(top,1);assert out==exp
checks['negation_cases']=12
# Independent postfix symbolic evaluator: old RV pushed once, exactly W remains.
stack=['OLD_STACK'];top='OLD_RV'
for token in meta['tokens'][2:]:
 if token in ('a','b','c'):
  stack.append(top);top=token
 elif token=='N':top=('N',top)
 else:top=(token,stack.pop(),top)
assert freeze(meta['formula'])==top and stack==['OLD_STACK','OLD_RV']
result={'scope':'Independent finite structural and macro regression checks; not the all-natural proof alone','baseline_sha256':hashlib.sha256((ROOT/'research215_encoding/partial_permuted210.sites.json').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((F/'fixed31_dp.sites.json').read_bytes()).hexdigest(),'source_leaves':len(nc),'replacement_interval_old':[lo,hi],'replacement_interval_new':[lo,hi+delta],'exterior_complete_cfg_preserved':True,'final_gate_same_literal_macro':True,'postfix_exact_formula_and_extra_RV_stack_head':True,'checks':checks}
Path('/workspace/shared/u_machine_calibration/FIXED31_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
