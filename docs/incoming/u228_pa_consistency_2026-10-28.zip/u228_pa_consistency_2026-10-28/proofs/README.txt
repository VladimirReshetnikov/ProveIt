Proof evidence map

WEAK_COVER_CALIBRATION.md is the complete frontend proof record, reproduced
in Appendix B of report.pdf. Its historical workspace references map to:
  research215_encoding/... -> portable_u_machine/inputs/base.sites.json
  frontend/fixed10_dp.sites.json -> portable_u_machine/source/u228.sites.json
  FIXED10_CHECKS.json -> evidence/FIXED10_CHECKS.json
  AUDIT.md -> proofs/calibration_audit.md
  source116/proofs/general_kappa_equality_helper.md -> sources/logical_dependencies/general_kappa_equality_helper.md
  source116/audit/mathematical_audit.md -> sources/logical_dependencies/mathematical_audit.md
  portable/theory/k_equality_helper_extension.md -> sources/logical_dependencies/k_equality_helper_extension.md
  research215_round13_calculus/inputs/DominatedImplication.lean -> sources/logical_dependencies/DominatedImplication.lean
  PA238/coq/logic/NumericNamed238.v -> sources/logical_dependencies/NumericNamed238.v

The exact supplied U manuscript is inside sources/pa_unary_power_cover.zip,
including its original TeX/PDF and manifest. FINAL_EQUIVALENCE_AUDIT.md
independently checks the fixed10 proof and supplies the explicit
relative-falsity derivation also printed in Section4.1 of the report.
The cover3/fixed31 variants are historical explanatory alternatives;
only fixed10 is used by the selected literal228 machine. Their historical
scripts/receipts are labeled under frontend_audit. The release's portable
checks/audit_fixed10.py is the supported independent source audit.
