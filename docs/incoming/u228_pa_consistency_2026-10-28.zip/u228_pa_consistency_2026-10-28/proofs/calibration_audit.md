# U / arithmetic front-end calibration audit

Date: 2026-10-28. Scope: read-only inspection and original mathematical analysis; no delivered or repository executable was run. Hash verification used independent standard-library code written for this audit.

## Useful conclusions

1. The ZIP really is the source-free unary weak-cover theory U, not an older two-free-role source-only draft.
2. The supplied efficient numerical theorem stream is **not a literal U-axiom stream**. It deliberately emits unrestricted positive matrices and uses low-code collisions. Its calibration passes through unrestricted weak covering W plus global irreflexivity IR, then PA, then U.
3. The supplied nine-pairing emitter and eight-case theorem stream are complete abstract arithmetic specifications, not a binary blank-tape TM or a state bound.
4. A direct K215/K230 weak-cover replacement has a concrete hazard: allowing coincident source and tested variable labels turns the subset guard into a tautology and yields unrestricted comprehension. The existing private-label gate alone does not prevent this.
5. Safe native adaptation can keep the entire existing logical interface, including full membership vacuity, while replacing the strong K seed by W only when the two active labels differ and by truth otherwise. No smaller literal table is certified by this note.

## Exact source pins

* ProveIt repository commit: `651d6258e9d57f974839ff2ef98060466973a512` (main observed 2026-10-28 17:33 UTC).
* ZIP path: `docs/incoming/pa_unary_power_cover.zip`.
* ZIP Git blob: `ee798b6ae9921965b2a4738bfe3b9bb3c3ca08f4`.
* ZIP bytes: 555471.
* ZIP SHA-256: `0fcb1117a5353766a3366bab04e56b4efbd0607833cdc73ffb34b67e6808b0ff`.
* All 33 entries in the archive's `SHA256SUMS` independently matched.
* Local extracted input: `/workspace/shared/u_machine_calibration/pa_unary_power_cover/`.
* K230 repository commit: `a8312f0ca703bc81baac16695a437a7d3788f690`.
* K215-PA repository commit: `992b76d60d1a138d84e184cd8b6796243646a984`.
* Busy-beaver main observed: `05c050f8f60037929008c4d7c7ad5231adb032bf`. K230's own formal dependency remains `c132d7eae8158cd3a9850ea3eb7251158c3dd821`, not this current main.

Relevant K230 blobs read:

| File | Blob |
|---|---|
| `coq/settheory/KCode230.v` | `daea67fd86c0d3bbd435d98777e830ac3da2d0a9` |
| `coq/settheory/KDecoder230.v` | `3270b8387580f3c066158d780fe2ce9ce0c130e5` |
| `coq/settheory/KDecodeFresh.v` | `22c9b4f530cad1919031fdd3af63ba48d8e81567` |
| `coq/logic/Codes230.v` | `f42857171e34013c708e9a2de484b6309ed19023` |
| `coq/logic/Thm230.v` | `ce8d0eb8f12d667a250c95cd4f50ff73373974fb` |
| `coq/logic/Enum230.v` | `c1f5767326f57e69075cd0e1b56a34fc628113fa` |
| `coq/logic/Seed230.v` | `505636a3f314a5d3eada4546ac7e043fe1c840f9` |
| `coq/logic/Bridge230.v` | `be5fc17e8789611f2df37b9a4b3a49057fd16091` |

## U and the arithmetic interpretation

Language: classical equality-free first-order logic over a nonempty domain; sole primitive relation E. Abbreviate Sub(x,a) by forall t(E(t,x) -> E(t,a)). For every matrix phi with FV(phi) subset {x}, U has exactly:

`forall a exists b [forall x(E(x,b)->phi(x)) and forall x(Sub(x,a)->(phi(x)->E(x,b)))]`.

The manuscript's lower proof was read in `sections/unary_core.tex` and `unary_arithmetic.tex`. Its dependency order is coherent on inspection:

* Eq is coextensionality, not an assumed ambient congruence in the first argument.
* Saturated endpoint-bounded transitive class orders define numerical representatives.
* Existing-successor induction is proved before successor totality. A failure below n is isolated by the legal unary matrix not Q(x); if no failure occurs below n, n itself is used, avoiding an illicit successor-of-n assumption.
* Arbitrary induction parameters are internalized in the unary formula forall p(BaseStep(p)->theta(x,p)). This is not a claim that U itself accepts free parameters.
* Global comparison and least failing numerical tuples follow from that induction.
* Bounded numerical comprehension internalizes the unique least failed tuple. It requires both numeric-parameter invariance and a supporting source; it does not yield arbitrary ambient parameter comprehension.
* Only then are total successors, numerical powers and saturated ordered-pair codes produced.
* Histories are extended or restricted using a formula existentially quantifying all histories with the specified numeric data. The previous graph is not used as a free filter parameter. Prior pointwise uniqueness makes this canonical relation functional.
* These histories define addition and multiplication, and full representative induction verifies every translated PA induction instance.

No immediate circularity or illicit free-source use was found in this review. This is an ordinary mathematical assessment, not a proof-assistant certification.

The upper interpretation in `upper_transport.tex` uses E(x,a)=Bit(a,x). Subset-of-a implies x<=a, and PA proves the required finite-comprehension instance by induction through a+1. This validates even unrestricted matrix parameters. PA also proves IR because Bit(a,a) is false. The syntax transformations asserted by the manuscript are primitive recursive proof transformations; no truth predicate or reflection is required.

Exact internal calibration obligations are:

`PA |- Prf_PA(p,bottom) -> Prf_U(f(p),bottom)`

and

`PA |- Prf_U(q,bottom) -> Prf_PA(g(q),bottom)`.

Their negated existential versions give the advertised PA consistency biconditional. The package gives conventional uniform proof templates, but not implemented general f/g, a fixed formal object-level proof calculus implementation for those maps, or a kernel-checked PA derivation. A report must preserve this distinction.

## Supplied numerical interface

The positive grammar is bijective:

* R(i,j)=2*pi(i,j).
* A(v,f)=4*pi(f,v)+1 (body-first pairing).
* I(f,g)=4*pi(f,g)+3.
* pi(i,j)=(i+j)(i+j+1)/2+j.

All naturals decode; recursive fields are smaller than their parent; code0 is E(v0,v0), code1 is D=forall v0 E(v0,v0), and code3 is the identity implication.

The fixed guard G=A(2,I(R(2,1),R(2,0))) is 1512069 (21 bits). The emitter is:

```
e = R(1,n)
h = I(e+n,0)
u = A(1,h+4*n)
v = A(1,I(G,h+4*e))
g(n) = I(A(n,I(v,I(u,0))),0)
```

It needs nine constructor pairings after guard initialization, or nine nonlinear multiplications in the supplied division-free factored polynomial (degree128, leading coefficient2^71). The matrix is dec(n) and output-variable label n is fresh for n>=2. Low cases are not rejected:

* g(0) is equivalent to E(a,a) OR existence of an empty object.
* g(1) is equivalent to E(a,a) OR J, where J=forall x(E(x,x)->D).

With seed not D, these give global IR. Under IR the regular positive shells yield unrestricted W. Conversely W+IR verifies every raw emitter output, including the two exceptional cases. Missing matrix codes0/1 have padded equivalent codes27/33. Thus the calibrated assertion is nondeducibility of code0, **not ordinary consistency of the positive theory alone**, which has a one-object total-relation model.

The theorem stream has eight cases: K, S, Peirce, capture-avoiding UI, freshness-checked QD, AX, MP, GEN. Failed QD or MP emits the identity theorem3. Only MP and GEN consult strictly earlier descriptions. Its proof-producing and proof-compiling maps are conventional primitive recursive transformations. The search halts on output0. Every layer still needs a literal implementation and finite-run correctness proof to conclude a TM theorem.

## Safe K-native weak-cover replacement

Native constructors are I(a,b)=4*pi(a,b), R(a,b)=I(a,b)+1, Q(a,b)=I(a,b)+2, Eq(a,b)=I(a,b)+3; raw truth=0 and raw falsity=1. KDecoder230 treats implications to raw1 as genuine negation, with a separate relative-falsity/IR bridge. Do not import the positive ZIP grammar's special cases into this different codec.

For distinct source/test labels a,b and private label c distinct from both, use matrix code c and define

```
S = Q(c, I(R(c,b), R(c,a)))
U = Q(b, I(R(b,c), c))
V = Q(b, I(S, I(c,R(b,c))))
W = I(Q(c, I(V,I(U,1))),1)
```

This is the ordinary source-open weak-cover instance, with the local subset binder c shadowing the output binder only inside the guard. `KDecodeFresh.v` proves c is free-variable fresh for D(c), including code0's closed tautology. All exceptional native constructor aliases must nevertheless pass through the existing IR bridge rather than being called literal syntactic equality.

If a=b, S decodes to forall c(E(c,a)->E(c,a)), hence the lower clause has no source restriction. W becomes unrestricted comprehension. For a diagonal-negation matrix this is Russell's contradiction. Therefore the old gate c!=a,b is insufficient.

A robust arithmetic family is:

* Retain all original logical rows and the full original membership-vacuity component RV(a,b,c).
* Keep the old private gate c!=a,b.
* Replace only the strong K seed slot by W when a!=b, and truth0 when a=b.

This preserves diagonal membership vacuity. Gating the entire bundle additionally on a!=b is not justified by the inherited logical completeness theorem, whose hypotheses explicitly include full membership vacuity. A new diagonal-vacuity derivation would be needed before using that shortcut.

For completeness, normalize each ordinary W matrix to fixed distinct source/test names, apply the unchanged membership-defined equality translation theta, pad the matrix with double negation, and only then set c to its actual native encoded value. The resulting c exceeds all names and makes both gates pass. The outer W template contains only membership and logical connectives, so it commutes with theta. This is the same actual-code/private-binder coupling repair used in the accepted K equality-helper extension, with W replacing K. Equality-bearing W+IR is PA-equiconsistent because its equality-free part contains U and its binary-membership interpretation uses ordinary arithmetic equality.

## Required exact-machine proof chain

A literal candidate must separately establish, with finite syntax/computation arguments provable in PA:

1. Exact table identities, binary alphabet, L/R moves, start, halt, and working-state census including blank initialization.
2. Full raw-input source/command semantics, not just samples; every inserted formula remains a theorem even for aliased codes and failed gates.
3. Primitive recursive finite-refutation conversions between the modified numerical calculus and W+IR, hence U. A proof that the previous K/ZFC machine was calibrated does not establish this changed endpoint.
4. Complete proof enumeration from the actual seed/cutoff. A nonzero initial counter requires the cofinal candidate argument, not an all-zero abstract seed theorem alone.
5. Exact primitive simulation for arbitrary natural registers and admissible whole-tape frames; all decoder prefixes, contextual marker folds, scratch/spare invariants and positive-duration bounds.
6. Blank-tape startup to a frame satisfying that new source's invariant. The old K215 prefix may no longer apply after source reallocation.
7. Arithmetization of both finite-run directions in PA. An external semantic equivalence or an unchanged-state bounded trace is insufficient.

The original K215 theorem calibrates to Con(ZFC), not Con(U). Reusing its literal table unchanged cannot answer the user. The target here is a provable endpoint for the changed literal machine, not merely a shorter high-level emitter.
