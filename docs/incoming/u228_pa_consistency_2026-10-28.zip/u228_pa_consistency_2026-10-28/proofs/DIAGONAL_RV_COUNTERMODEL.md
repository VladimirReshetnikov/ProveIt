# Off-diagonal membership vacuity does not imply diagonal vacuity by the retained logic alone

Date: 2026-10-28. New mathematical countermodel; no received code executed.

## Conclusion

Let H_off retain the K215 substitution-free numerical logical rows, truth0, MP, theorem GEN, and **only** the membership-vacuity axioms

`R(a,b) -> Q_c R(a,b)` for a!=b and c!=a,b.

Retain either the original equality-vacuity axioms, or the restricted helper / merged G used by K215. Even the stronger original full equality-vacuity family does not change the conclusion below.

For a!=0 and c!=a, H_off does **not** derive

`R(a,a) -> Q_c R(a,a)`.

It also does not derive `R(a,a) -> F`, where F=R(0,0), nor arbitrary explosion from R(a,a).

This is a countermodel of the logical subsystem, **not** a model of the proposed weak-cover seed theory. The weak-cover axioms are not valid in it. Thus a new proof that essentially uses weak covering is not excluded; the proposed logic-only GEN/instantiation or IR/ex-falso shortcut is excluded.

## Interpretation of the exact substitution-free calculus

Let worlds be all assignments s:N->N. Interpret native quantification Q_i by varying coordinate i:

`[[Q_i A]](s)` iff for every n in N, `[[A]](s[i:=n])`.

Interpret implication classically, equality atoms by actual equality of values, and membership atoms by the following deliberately nonlocal rule:

* `[[Eq(i,j)]](s)` iff s(i)=s(j).
* If i!=j, `[[R(i,j)]](s)` is false.
* `[[R(0,0)]](s)` is false.
* For a!=0, `[[R(a,a)]](s)` iff `forall k!=a, s(k)!=s(a)`.

Thus nonzero diagonal atoms assert that their coordinate's value is unique among **all** coordinates. This is not an interpretation of ordinary first-order relation syntax with the substitution lemma. It is a valuation of the actual substitution-free native Hilbert system. That is sufficient for a nonderivability proof; admissibility of ordinary substitution is exactly what is under examination.

Interpret numeric code0 as true. The alias `I(0,0)=0` is compatible because true->true is true. Raw falsity code1 is R(0,0), hence false at every world. Therefore native negation `N(A)=I(A,1)`, conjunction, and existential quantification have their usual classical meanings. The exact native constructor arithmetic does not introduce another semantic assumption.

## Verification of every retained logical component

1. **Classical implicational row rho8.** Its displayed formula
   `((C->U)->A)->((A->C)->(B->C))`
   is a classical propositional tautology. It remains valid when U is restricted by the dominated source condition. All derived propositional rules, including explosion from F, are consequently valid.

2. **rho2 / QI.** `Q_i(A->B)->(Q_i A->Q_i B)` is valid for coordinate quantification, irrespective of any nonlocal dependencies of A or B.

3. **rho4 / commutation.** `Q_i Q_j A -> Q_j Q_i A` is valid because coordinate updates commute when i!=j, and the equal-label case is trivial.

4. **rho6 / B6c.** `Ex_i Q_i A -> A` is valid. The inner universal statement is independent of the incoming value at i and includes the current value at i among its instances. Nonlocal atoms cause no problem for this argument.

5. **rho1 / equality witness.** `Ex_i Eq(i,j)` is valid: assign coordinate i the current value at j. If i=j, equality is already reflexive.

6. **rho7 / Euclidean equality and any equality symmetry/reflexivity consequences.** These use actual equality of natural values and are valid.

7. **Membership congruence rho3.** Consider `Eq(a,b)->(R(c,a)->R(c,b))`. If a=b as labels, the two membership formulas are identical. If a!=b and s(a)=s(b), truth of R(c,a) would require c=a!=0 and uniqueness of s(a), contradicted by the different coordinate b. Thus its antecedent membership atom is false and the implication holds.

8. **Membership congruence rho5.** For `Eq(c,a)->(R(c,b)->R(a,b))`, the c=a case is identical-formula implication. If c!=a and values are equal, truth of R(c,b) would require c=b!=0 and uniqueness of s(c), contradicted by coordinate a. Again the implication holds.

9. **Off-diagonal membership vacuity.** Its antecedent R(a,b) is false by definition, so every retained instance is valid.

10. **Full ordinary equality vacuity (if present).** `Eq(a,b)->Q_c Eq(a,b)` is valid for c!=a,b, because changing coordinate c leaves the two values unchanged. The a=b case is also valid.

11. **Restricted equality helper and merged G.** For any builder kappa satisfying a!=b implies kappa(a,b)!=a,b, `Eq(a,b)->Q_kappa Eq(a,b)` is valid: off-diagonal equalities are unaffected by the fresh coordinate; diagonal equalities remain reflexive under every update. Therefore `Eq(c,a)->(Eq(c,b)->Q_kappa Eq(a,b))` is valid as well. The K215 native constructor builder meets this freshness condition.

12. **MP and theorem GEN.** MP preserves global validity. If A is true at every assignment, so is Q_i A. This is theorem generalization, not generalization under an arbitrary open assumption.

These checks establish soundness of H_off by induction on its actual finite derivations.

## A falsified target

Take any a!=0 and c!=a, and let s(k)=k. The assignment is injective, so R(a,a) is true. Let s'=s[c:=a]. Now c!=a and s'(c)=s'(a), so R(a,a) is false at s'. Consequently Q_c R(a,a) is false at s, and the diagonal vacuity implication is false there.

At the same injective assignment R(a,a) is true and F=R(0,0) is false. Hence the conditional `R(a,a)->F` also fails. In particular, the syntactically special F must not be silently replaced by arbitrary diagonal atoms.

## Exact obstruction in the proposed GEN/UI argument

The theorem rule GEN allows one to infer

`Q_b [R(a,b)->Q_c R(a,b)]`

from an off-diagonal RV instance with a,b,c pairwise distinct. The blocked step is instantiation b:=a.

The inspected concrete analogue is `NumericNamed238.named_universal_instance` in

`u_machine_20261028/sources/busy-beaver/PA/m238/coq/logic/NumericNamed238.v`.

It first requires `r -> Q_b r` for the substituted target r. Here

`r = R(a,a) -> Q_c R(a,a)`.

Its `named_vacuity` proof reaches the atomic obligation

`R(a,a) -> Q_b R(a,a)`,

which is another unavailable diagonal RV instance. Moreover, its quantified equality-replacement case requires `Eq(b,a)->Q_c Eq(b,a)`; the K215 merged equality helper does not directly supply arbitrary c. Restricting attention to non-diagonal atoms in the **pre-substitution** formula does not remove the target-vacuity dependency.

The inherited source116 audit states the same dependency explicitly: quantifier-free specialization first yields an existential of the substituted expression, then eliminates that existential using fresh vacuity of the substituted expression. See `source116/audit/mathematical_audit.md`, section2B, in the retained K224 proof materials.

## Why the existing membership-target theorem does not rescue it

`research215_alternatives_calibration/MEMBERSHIP_TAG_HALT_INDEPENDENT_REVIEW.md` proves a **theorem-level** transformation from a proved membership atom to native F using the full existing bundle. It explicitly uses diagonal RV instances:

* Stage1 uses `R(b,b)->Q_a R(b,b)` to reduce a general membership theorem to a diagonal theorem.
* Stage2 uses `F->Q_b F` (available by explosion) together with the full logical machinery to reach F.

That result is not the universally valid conditional `R(a,b)->F`; it must not be used as one. Its stage1 loses a required premise when the diagonal membership-vacuity family is removed.

The raw image of the ordinary IR axiom is `Q_0(F->F)`, a generalized identity. It does not install a primitive rule making every R(a,a) false, as this countermodel demonstrates.
