# Exact weak-cover frontend: finite-proof calibration

2026-10-28. This is a conventional mathematical proof and source audit, not a newly kernel-checked PA proof object. Repository programs were inspected as text, not executed. The independent readers/interpreters named below were authored for this task. The binary primitive simulation and blank initialization are separate certificates; this note supplies the arithmetic frontend and finite-proof transports they require.

## 1. Exact source identities and scope

Baseline source `research215_encoding/partial_permuted210.sites.json` has SHA-256
`17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba`.

Three exact replacements have been independently checked:

* `u_machine_20261028/frontend/weak_cover3_dp.sites.json`: SHA-256 `3069db9a3a732861a0950dfe9fdc0b5abe11d3ba341de7ebf592595b379ac794`, 3985 primitive occurrences. Old interval [2885,4556) is replaced by [2885,3790).
* `u_machine_20261028/frontend/fixed31_dp.sites.json`: SHA-256 `fddb275b58af4edbcc5d33c7541c7553947698c2b0f2c247e38bee9ba3ec54ef`, 3953 occurrences. Old interval [2885,4556) is replaced by [2885,3758).

* `u_machine_20261028/frontend/fixed10_dp.sites.json`: SHA-256 `27d2b58fc9027cbf7c6adda6b52afd54890bfbd1b5db48d35162b3b5dfeda96e`, 3950 occurrences. Old interval [2885,4556) is replaced by [2885,3755).

The independent check reconstructs every source control edge, verifies that no exterior edge enters the removed interval's interior, and compares every exterior primitive and shifted edge, not merely a subtree count. The final old private-label gate [4556,4590) is literal in all three sources at its shifted address. Evidence is `SPLIT_AX3_CHECKS.json` / `audit_split_axiom3.py` , `FIXED31_CHECKS.json` / `audit_fixed31.py`, and `FIXED10_CHECKS.json` / `audit_fixed10.py` in this directory. The fixed-role checkers also run regression tests of unused library macros; these tests do not assert that those macros occur in fixed31.

The old strong K seed is removed. The old membership-vacuity component is retained separately, with its full original parameter coverage. The seven logical rows, dominated eighth row, generalization slot, saved top, all non-AX commands, and the outer enumeration are unchanged. In particular this is not a reuse of the old ZFC endpoint.

## 2. Native formula and gates

Let P(a,b)=(a+b)(a+b+1)/2+b. Define I(a,b)=4P(a,b), R(a,b)=4P(a,b)+1, Q(a,b)=4P(a,b)+2, E(a,b)=4P(a,b)+3, F=1=R(0,0), N(X)=I(X,F). Native truth is 0, and I(0,0)=0. These are the K-native constructors, not the different positive grammar in the supplied U ZIP.

For source label a, tested label b, and private label k, write

    S = Q(k,I(R(k,b),R(k,a)))
    U = Q(b,I(R(b,k),k))
    V = Q(b,I(S,I(k,R(b,k))))
    W(a,b,k) = N(Q(k,I(V,N(U)))).

The two occurrences of the bare natural k in matrix positions denote the native formula with code k. The same k is the output-variable label. Under the relative-falsity interpretation and IR this is

    exists k [ forall b(Sub(b,a) -> (D(k) -> R(b,k)))
               and forall b(R(b,k) -> D(k)) ].

The subset guard uses a *local* binder k, shadowing the outer output binder only inside the guard. Its body contains no output reference. This shadowing is therefore intentional and harmless. The formula is safe only when a and b differ as variable names. At a=b the subset guard becomes a tautology and the schema becomes unrestricted comprehension; the old k-not-equal-a,b gate alone would not repair that collision.

The cover3 replacement does the following, in order:

1. Apply the original gate to the already-built RV(A,B,C)=I(R(A,B),Q(C,R(A,B))). The gate makes this 0 if C=A or C=B, otherwise leaves it intact. It clears registers 3 through 7, preserving top/stack/proof-tail except for the conditional top clearing.
2. Read three new payload fields k,p,q, leaving the unconsumed tail in register 8. Registers 3,4,5 receive k,p,q.
3. Increment register 4, transfer register 5 into registers 4 and 6, and transfer register 6 back into 5. Thus a=p+q+1, b=q, and scratch 6 is zero. Every loop is a decreasing natural transfer; the effect is for all naturals, not inferred from test coverage. In cover3 the initial increment and association of the loop are exactly the revised left-entry version.
4. Evaluate the displayed postfix expression W. A parameter push saves the previous top; a binary constructor consumes its left operand from the stack and combines it with the top; N changes only the top. Structural induction on the postfix tree gives final top W and stack with exactly one additional head, the gated old RV.
5. Apply the retained old gate again. This second gate compares k to the **computed** a=p+q+1 and to q, not to the pre-affine p. It clears registers 3 through 7.

Thus a>b always, and every nongated W is an ordinary distinct-role instance.

In fixed31 steps 2 and 3 instead read only k, increment register 4 three times and register 5 once, yielding a=3,b=1. The same final gate rejects k=1 or k=3. Code k=0 is allowed by this gate: the decoder's special code-0 matrix is true, so it is not a soundness exception. Completeness will use k>3.

In fixed10 the replacement is exactly gate; read k; increment register 4 once; build W; final old gate. Its roles are a=1,b=0. The final gate rejects k=0 and k=1, so every emitted nontruth W has k>=2. There is no shifted reader and no hidden additional payload. Completeness uses a padded actual matrix code k>1.

The independent finite tests additionally cover 648 gate cases, 450 reader cases, 144 affine cases, 200 constructor cases, 75 parameter pushes, and 12 negations. Their role is regression evidence. Universal correctness is the decreasing-loop and postfix induction just given, together with the unchanged native constructor contracts.

## 3. Exact command equations

At a command boundary retain (t,w,d,h), respectively top, paired stack, additive counter and cache. Let [x1,...,xm;w] denote nested P-pairing. Put

    U0=d, A=d+x, B=h+y, C=c.

In cover3 the command AX(c;x,y;k,p,q) has wire fields

    [c+3, y, x, k, p, q].

Let gRV be RV(A,B,c), except 0 when c=A or c=B. Let a=p+q+1, b=q, and let gW be W(a,b,k), except 0 when k=a or k=b. Then the command returns

    top = gW; counter = cache = 0;
    stack = [gRV, R1(A,B,c),...,R7(A,B,c),
             L(A,B,c,U0), Q(U0,h), t; w].

Here h in Q(U0,h) is the incoming cache, before adding y. There are **eleven** new heads. The dominated row is

    L(A,B,C,U0)=I(I(I(C,U0),A),I(I(A,C),I(B,C))), U0<=A.

For fixed31 use AX(c;x,y;k), wire [c+3,y,x,k], and gW=W(3,1,k) or 0 according to its gate. For fixed10 use the same one-field wire and gW=W(1,0,k) or 0 when k=0 or k=1. The eleven-head stack equation is identical in both fixed-role versions.

Unchanged commands have selectors NIP=0, DROP=1, MP=2 and fields [0], [1], [2,x]. Their equations are

    MP(x): y=d+x;
      if I(t,y)=h, return (y,P(0,w),y,0);
      otherwise return (0,w,y,0).
    DROP: return (h,P(t,w),d,h).
    NIP: halt if h=1; otherwise let (h',w')=unpair(w)
         and return (t,w',d,h').

Zero unpairs to (0,0). The exact exterior CFG check transfers the baseline selector tests, reader order YX, return routes and source-root recurrence. The new readers also restore their scratch registers and only shorten the proof tail.

## 4. Numerical proof system and soundness invariant

Define D to have truth 0, numerical MP, theorem GEN, the seven retained logical rows, the dominated L family, the complete gated RV family, and exactly the W family supplied by the selected replacement (cover3: a>b and k different from a,b; fixed31: a=3,b=1 and k different from 3,1; fixed10: a=1,b=0 and k>=2).

All stack heads generated by AX are D-theorems if the incoming top and cache are D-theorems. Its Q(U0,h) slot is theorem GEN. Failed gates and failed MP insert truth. DROP and NIP only move theorem codes. Thus the invariant that top, cache, and every iterated stack head are D-theorems is preserved for every natural input payload, including malformed candidate encodings and code aliases. The unique halt test is cache=1. Starting with all retained registers zero gives

    source halting -> D proves 1.

This is a finite derivation-producing induction on the source command trace; it is not a semantic truth argument.

## 5. Explicit eleven-head proof compiler

A strong block B_X from every (t,w,0,0) either halts or returns (X,w,0,0). Early halt is permitted and already establishes the desired result.

For cover3 use default new fields D0=(0,0,0), so the second gate is disabled: computed source=1,test=0,private=0. For fixed31 and fixed10 use default private field D0=1, likewise disabling the second gate. Abbreviate AX(...;D0) accordingly. Define

    Discard = MP(1); AX(1;0,0;D0); NIP^11.
    J(u) = empty if u=0, and MP(u) if u>0.

Discard maps any (t,w,0,0) to (0,w,0,0). Its MP fails since I(t,1)>0; its first AX gate has old source=private=1, while its second gate is disabled by D0. Generated logical heads, RV and GEN are not code 1; saved top is 0. J(u) maps (0,w,0,0) to (0,w,u,0). Omitting MP(0) avoids the I(0,0)=0 successful-MP alias and its extra stack zero.

Leaf blocks are:

    truth: Discard.
    R_j(A,B,c), 1<=j<=7:
      Discard; AX(c;A,B;D0); NIP^(j+1); DROP; NIP^(11-j).
    L(A,B,c,U0), U0<=A:
      Discard; J(U0); AX(c;A-U0,B;D0); NIP^9; DROP; NIP^3.
    RV(A,B,c), c distinct from A,B:
      Discard; AX(c;A,B;D0); NIP; DROP; NIP^11.
    cover3 W(a,b,k), a>b, k distinct from a,b:
      Discard; AX(0;0,0;k,a-b-1,b); NIP^11.
    fixed31 W(3,1,k), k distinct from 3,1, or fixed10 W(1,0,k), k>=2:
      Discard; AX(0;0,0;k); NIP^11.

For a derived Q(i,X), use

    B_X; DROP; J(i); NIP; AX(i;0,0;D0);
    NIP^10; DROP; NIP; NIP.

For MP premises X and I(X,Y), use

    B_X; DROP; B_I(X,Y); NIP; DROP; NIP; MP(Y);
    AX(Y;0,0;D0); NIP^11; DROP; NIP; NIP.

These identities follow directly from Section 3. For example the GEN target is stack head 10; the MP reset saves Y at head 11, above the MP-added zero. Both selected results are restored with the old underlying stack and zero counter/cache. If an intermediate cache is already 1, the next NIP halts instead, which satisfies the strong contract. Induction on a finite D derivation constructs B_X, primitive recursively.

## 6. Packing and completeness from the actual cutoff 4

For fields fs and tail r let E(fs,r) be right-folded P. Define tail encoding

    enc([])=0,
    enc(command::L)=1+E(fields(command),enc(L)).

A fresh candidate is loaded directly, with NO initial outer successor; later commands first decrement a positive proof-list value and then read fields. Every unpairing tail is at most its input. Hence every later nonhalting command starting at positive tail v leaves a tail <=v-1. Each arithmetic macro terminates; the extra one or three readers do not alter the decrease. Every candidate drains, and candidate fetch increments N once. This proves fairness by natural induction, including zero/missing fields.

Given B_1, let Finish=DROP;NIP;NIP and R=enc(B_1;Finish). Start_Y=AX(0;1,Y;D0) resets counter/cache from every retained tuple; its top is 0. The strong contract therefore makes Start_Y;B_1;Finish halt from every incoming tuple.

For cover3 the first-candidate number is

    N_Y=P(3,P(Y,P(1,P(0,P(0,P(0,R)))))) >= Y.

For both fixed-role versions, whose default private field is 1, it is

    N_Y=P(3,P(Y,P(1,P(1,R)))) >= Y.

Choose Y>=4. The search starting with register tuple (N,T,W,A,D,H,X,Y,L)=(4,0,0,0,0,0,0,0,0) either halts earlier or drains all candidates up to N_Y and then halts there. Consequently, for the actual source seed,

    PA proves: source halts iff D proves 1.

This theorem uses finite proof coding, macro induction, bounded candidate enumeration and the displayed compiler. It does not require the machine to start at candidate 0.

## 7. Logical calibration: why the restricted actual-code W family suffices

### 7.1 Retained logical interface

The dominated implicational basis supplies the unrestricted classical row by a fixed finite proof. The representation-independent certificate `research215_round13_calculus/inputs/DominatedImplication.lean` uses only MP, dominated rows, reflexivity of <= and growth of each constructor operand. Native I satisfies these inequalities, including its zero alias. Thus this proof instantiates for all natural formula codes; it uses no K or set-theoretic axiom.

Full RV(a,b,c), c distinct from a,b, is retained, including a=b. The retained merged equality row supplies the restricted helper E(a,b)->Q(kappa(a,b),E(a,b)), with kappa the existing membership-code builder; its positive tag makes kappa(a,b)>a,b. The seven rows and this helper supply a finite interpretation of the full ordinary equality calculus. The exact uniform proofs are:

* `portable/theory/source116/proofs/general_kappa_equality_helper.md`;
* `portable/theory/source116/audit/mathematical_audit.md`, Sections 1--3;
* `portable/theory/k_equality_helper_extension.md`, Sections 1--2;

under `recovered_k224_package/K224_Independent_Verification/evidence/busybeaver-k224-intake-20261020/received/K224_Construction_2026-10-20/`.

Here is their relevant content, independent of their old ZFC endpoint. In genuine-bottom named syntax define theta to preserve membership, implication and every universal binder, send bottom to F, and replace primitive equality between a,b by the conjunction of inward and outward membership indiscernibility quantified at the safe auxiliary z=4P(a,b)+3. Membership-only fresh vacuity is proved structurally from full RV (bottom uses relative explosion). Quantifier-free specialization follows from membership congruence, equality symmetry, rho1/rho2 and this vacuity. Explicit transport between safe auxiliaries uses a fresh maximum-plus-one. These yield every translated equality-vacuity and congruence row, including auxiliary collisions. The restricted equality helper first bootstraps primitive reflexivity/symmetry, then Eq(a,b)->theta(Eq(a,b)); rho1 and existential monotonicity give translated equality existence. MP and GEN commute literally with theta. No general native renaming or substitution rule is silently assumed.

All these are uniform finite derivations, with only finite-tree recursion and maximum-plus-one choices. General ordinary logical proofs may be compiled to this full substitution-free comparison calculus: its finite specialization/alpha derivations are obtained by induction on formulas with fresh binders, followed by the deduction theorem and theorem GEN. A concrete corresponding finite proof construction is visible in the pinned PA238 `coq/logic/NumericNamed238.v`, notably `named_equality_replace`, `named_universal_instance`, `named_universal_alpha` and finite generalization. This is a proof-syntax argument, not an appeal to semantic completeness or model existence within PA. Translating the comparison derivation by theta then replaces each logical axiom by the finite derivation just described.

### 7.2 Actual code/private-binder coupling

For any ordinary W matrix, first choose a capture-free genuine-bottom named representative f with source 3 and tested variable 1; choose all other names fresh. This normalization is performed in the full ordinary comparison calculus, BEFORE theta. Put

    psi=theta(f), pp=NN psi, k=enc(pp).

Every finite encoded tree used here has positive code; by the constructor inequalities every label in pp is strictly below its code. Double-negation padding gives k>3. Thus k is fresh for both f and psi. Choose the ordinary comparison W axiom with private name k and matrix NN f. Its choice of private name is made AFTER encoding the interpreted matrix, not by incorrectly identifying enc(f) with enc(theta(f)).

The W template has only membership, logical connectives, binders and matrix insertions. Therefore its theta-translation is literally W(3,1,k) with matrix code k. Fixed31 supplies it directly. Cover3 supplies it by new fields (k,p,q)=(k,1,1), which compute source 3/test 1. Both gates pass. Ordinary double-negation equivalence and capture-free normalization recover every needed W instance in the comparison proof; translating that finite proof gives a native derivation. The translated IR sentence forall 0(R(0,0)->bottom) is Q(0,I(F,F)), a generalized identity.

There is no recoding of arbitrary decoder values in this lower direction. In particular enc(dec(0)) need not equal 0 and is never assumed to do so.

### 7.3 Fixed roles other than 3 and 1

Any two distinct fixed roles work by the same argument. Odd free/even bound names were one naming convention, not a logical invariant. For source 2/test 1, reserve 1 and 2 and use fresh names elsewhere; padding gives k>2. A shifted reader k=raw+3 covers the needed k by raw=k-3.

Source 1/test 0 also works, but its justification must respect designated bottom. The source116 proof explicitly treats F as designated falsehood in its proof interpretation, proves F->Q_i F by explosion even at i=0, and handles translated axioms when a substituted membership atom collapses to R(0,0). Normalize f in the genuine-bottom comparison language first, then apply theta and choose k=enc(NN theta(f))>1. Theta preserves binder 0 literally, so the W template still commutes. One must NOT rename the raw atom R(0,0) as though it were a closed bottom after interpretation. This distinction removes the initial reserved-zero concern without assuming a new native renaming rule. In the exact fixed10 source, supply the private payload k itself: every k>1 passes its final gate. Therefore the same primitive-recursive comparison-proof transport applies to fixed10, with its unchanged full RV and equality-helper families.

## 8. Upper interpretation and U endpoint

The actual U is the pinned equality-free unary weak-cover theory in `pa_unary_power_cover.zip`, SHA-256 `0fcb1117a5353766a3366bab04e56b4efbd0607833cdc73ffb34b67e6808b0ff`; its schema restricts FV(phi) to the tested variable alone. It is not the unrestricted W theory implemented as the intermediate native frontend.

For the upper direction interpret R(x,a) as the binary-bit relation Bit(a,x), and primitive equality as arithmetic equality. PA proves IR. If Sub(x,a), PA proves x<=a. For each formula phi, PA's finite-comprehension induction through a+1 constructs the required weak-cover output. The construction works with arbitrary parameters, so validates every regular W matrix. The K-native decoder's freshness lemma gives that k is absent from the decoded matrix for k>0; the code-0 matrix is separately a closed truth. Both gate conditions and distinct source/test roles therefore suffice for all raw native codes. The existing relative-falsity bridge handles I(_,1) and code-zero constructor aliases; these must not be replaced by an incorrect literal inverse encoder/decoder assertion.

This is a finite PA-proof producer for each D axiom. Recursion on a finite D proof produces a PA proof of bottom if D proves 1. No uniform truth predicate or reflection for PA is used.

For the lower direction, unrestricted W includes every U schema instance. Section 7 transforms any finite ordinary U refutation into a D proof of 1, including normalization of the finitely many axiom matrices and translation of the logical proof. Thus PA proves

    not Con(U) -> D proves 1.

The supplied U manuscript also gives uniform arithmetic-interpretation proof templates in the other direction: existing-successor induction first, parameter internalization and least failures next, then total successors, canonical saturated histories, arithmetic operations and induction. These produce a finite U proof from a finite PA proof of bottom. Their mathematical review is recorded in `AUDIT.md`; they are conventional uniform proof templates, not an independently implemented kernel certificate. Combining this proof producer with D-to-PA gives

    D proves 1 -> not Con(PA) -> not Con(U).

Hence, with ordinary syntactic proof predicates,

    PA proves: (D proves 1) iff not Con(U).

Equivalently one may use the two reviewed U/PA refutation transports and the intermediate W+IR comparison. No old K-to-ZFC calibration is used, and no assumption Con(PA), Con(U), or Con(ZFC) is made.

## 9. PA arithmetization and literal machine consequence

All objects in this argument are finite natural-number codes: formulas, derivations, register tuples, proof-field lists, source locations, finite tape support and finite runs. Pairing/unpairing, constructors, fresh labels, matrix padding, proof substitution, block compilation and candidate padding are primitive recursive. PA proves their defining equations and termination by ordinary induction. The uniform axiom proof templates are coded proofs, not a semantic assertion that all axioms are true.

Thus the argument consists of PA-provable implications between existentially quantified finite certificates:

    U refutation -> D proof of 1 -> finite source halt;
    finite source halt -> D proof of 1 -> PA refutation -> U refutation.

An exact binary primitive simulation adds source-halt -> machine-halt by concatenating positive-duration finite primitive runs. Its converse follows by induction on the remaining length of a putative machine halting run: a nonhalting source primitive has a positive-duration simulated block whose strict interior contains no machine halt, so peel that block; the halting primitive is the sole terminal case. Finite-support tape coding removes any need for actual infinite tape objects in PA. A verified blank trace to the source root with N=4 and all other registers zero supplies the initial premise.

For any particular literal table whose source identity, universal primitive simulation and blank-root trace have separately been established for one of the above exact sources, PA therefore proves

    Halt_M(blank) iff not Con(U),
    Nonhalt_M(blank) iff Con(U).

The state census and table hash must be taken from that table's own runtime certificate. This note alone does not certify a table or infer a state count from a source DAG count. It establishes a conventional PA-formalizable proof; no new compiled Rocq/Lean/PA certificate is claimed.
