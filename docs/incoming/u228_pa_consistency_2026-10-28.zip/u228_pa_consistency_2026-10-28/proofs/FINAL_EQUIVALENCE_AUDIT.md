# Independent final equivalence audit

Date: 2026-10-28. Scope: ordinary mathematical proof audit of the fixed10 frontend and its PA-internal endpoint. The literal binary runtime and bootstrap are separate obligations and are not certified by this note.

## Verdict

The finite-proof calibration in `WEAK_COVER_CALIBRATION.md` is sound as a conventional PA-formalizable argument, with the explicit dependency boundary below. I found no remaining obstruction from the fixed source/test labels 1 and 0, the actual-matrix-code/private-name coupling, the eleven-head compiler, or the unary U arithmetic interpretation. This is not a new kernel-checked PA derivation or an independently implemented end-to-end proof translator.

The conclusion applies to the exact fixed10 source with SHA-256 `27d2b58fc9027cbf7c6adda6b52afd54890bfbd1b5db48d35162b3b5dfeda96e`. Combining it with independently established universal primitive simulation, exact blank initialization, and the exact step-preserving quotient establishes the stated theorem for the final u228 table. The existence of those separate certificates must be checked before making the literal-machine conclusion.

## 1. Fixed10 and designated falsehood

Native F=R(0,0) is not syntactically a closed falsehood. It must not be renamed as if it were one. Nevertheless, a finite uniform proof makes F behave as designated bottom in the proof interpretation, including under binder 0.

For any formula A and binder i, write Ex_i B = I(Q(i,I(B,F)),F). The K tautology gives

    F -> Ex_i All_i A,

because the right side is an implication ending in F. Retained rho6 gives

    Ex_i All_i A -> A.

For an entirely literal expansion, put

    E_i(A) = I(Q(i,I(Q(i,A),F)),F).

The K instance at antecedent F and second argument Q(i,I(Q(i,A),F)) is I(F,E_i(A)). The rho6 instance is I(E_i(A),A). The derived composition row I(I(F,E_i(A)),I(I(E_i(A),A),I(F,A))) followed by these two premises via MP gives I(F,A).

Composition therefore derives F->A. In particular F->Q(0,F) is available. This argument uses only a finite propositional proof and rho6, not semantic falsity, IR, or a hidden fresh-variable condition.

The correct lower-proof order is:

1. Work in genuine-bottom ordinary named syntax.
2. Normalize source and tested labels to 1 and 0, using capture-free ordinary logical derivations.
3. Apply theta, which preserves membership, implication and every binder, interprets primitive equality by inward/outward membership profiles, and sends genuine bottom to F.
4. Set k to the native code of NN theta(f), after the interpretation, and choose this k as the output label in the ordinary weak-cover instance.

Every label in the padded finite tree is smaller than its positive code k, so k is fresh and k>1. The exact fixed10 gate accepts k. The weak-cover template commutes with theta, since it contains only membership, connectives, binders and matrix insertions. No claim that theta commutes with raw substitution or raw renaming is needed. The interpreted IR sentence is Q(0,I(F,F)), an instance of theorem generalization of identity.

The inherited equality interpretation explicitly handles auxiliary collisions and atoms that become R(0,0) after substitution. Its proof uses full membership vacuity, including diagonal membership atoms. The exact fixed10 source retains that full family separately; it does not impose the source/test inequality on the membership-vacuity family.

## 2. Compiler identities checked independently

Use the exact command equations from Section 3 of the calibration note. Every strong block starts with counter/cache zero and preserves the underlying stack, unless it halts early.

For GEN, after B_X;DROP;J(i);NIP the tuple is (0,w,i,X). AX(i;0,0;1) places Q(i,X) at new stack head 10, with a saved zero at head 11. NIP^10 selects Q(i,X). DROP;NIP;NIP restores it to the top with stack w and counter/cache zero. The empty J(0) case is essential to avoid the successful I(0,0)=0 MP alias.

For MP, after B_X;DROP;B_I(X,Y);NIP;DROP;NIP the tuple is (X,w,0,I(X,Y)). MP(Y) succeeds and returns (Y,[0;w],Y,0). AX(Y;0,0;1) saves Y at head 11. NIP^11;DROP;NIP;NIP restores (Y,w,0,0). If an intermediate cache equals 1, NIP halts, as allowed by the strong contract.

The row and RV selection counts likewise match their literal positions among the eleven new heads. Discard clears top/counter/cache without changing the old stack: MP(1) fails because I(t,1)>0; the following first gate collides at old source/private 1 and the fixed10 second gate collides at private/source 1. None of the discarded logical heads is code 1.

Candidate packing distinguishes the first directly loaded candidate from successor-prefixed later commands. For every later positive tail v, the initial decrement and nonincreasing unpairing tails force a strict decrease. The displayed Start_Y block resets counter/cache and returns top zero from any retained tuple. The candidate N_Y=P(3,P(Y,P(1,P(1,R)))) is at least Y, so choosing Y>=4 supplies a cofinal halting candidate above the actual seed. This is a finite induction argument, not an assumption that the search starts at zero.

## 3. U interpretation and PA proof transport

I inspected `sections/unary_core.tex` and `sections/unary_arithmetic.tex` in the exact pinned U packet. The potentially circular points are resolved in the stated order:

- Numerical representatives are defined by saturation, transitivity, class order and endpoint conditions.
- Existing-successor induction is proved before successor totality, using a least failure below n or n itself when none lies below it.
- Arbitrary parameters are internalized into a unary universally quantified matrix.
- Global comparison and least numerical tuples precede bounded numerical comprehension.
- The least-failed-tuple matrix binds all numerical parameters; the support source is chosen in the proof and is not a forbidden free matrix parameter.
- Only then are successors, numerical powers, and saturated pair codes constructed.
- Numerical history extension and restriction bind all graph witnesses and use earlier pointwise uniqueness. No graph object is smuggled into a unary matrix as a free parameter.
- Addition and multiplication are defined by these histories; translated PA induction is an instance of the already proved representative induction theorem.

These are finite formula-dependent proof templates, not merely a model-existence comparison. Once the arithmetic interpretation is fixed, the finitely many arithmetic axiom proofs are fixed, while an arbitrary PA induction instance is translated by inserting its translated formula into the representative-induction template. Formula recursion, substitution, fresh-name selection, proof concatenation and induction on coded proofs are all PA-formalizable.

The reverse arithmetic interpretation of unrestricted weak covering is binary membership. Sub(x,a) implies x<=a, and formula-specific finite comprehension through a+1 constructs the cover. This is again an axiom proof producer. There is no appeal to uniform arithmetic truth or PA reflection.

Thus D-refutation gives a PA refutation and then a U refutation; a U refutation gives a native D-refutation through the genuine-bottom comparison calculus and the actual-code construction above. Both directions are syntactic finite-proof transports. The old K/ZFC endpoint is not used as a replacement for this calibration.

## 4. Dependency and validation boundary

The conventional proof uses the inherited finite dominated-implication derivation, the full-RV membership-defined equality proof, the exact source command contracts and the U manuscript's finite arithmetic interpretation. These texts should be included in the deliverable, with source identities, rather than replaced by an external model-equiconsistency citation.

Finite macro regression tests do not prove the universal source contracts. The latter use decreasing transfer loops, postfix-tree induction, retained exact macro contracts, and complete exterior control-flow preservation. Similarly, finite literal simulations do not prove all-natural binary simulation. That separate universal symbolic proof and its frame/initialization hypotheses must remain explicit.

Once those machine obligations are independently established, the PA endpoint follows by finite certificate transformations and strong induction on a putative finite halting trace. There is no need for an actual infinite tape object, transfinite induction, a semantic completeness theorem inside PA, or a new consistency assumption.
