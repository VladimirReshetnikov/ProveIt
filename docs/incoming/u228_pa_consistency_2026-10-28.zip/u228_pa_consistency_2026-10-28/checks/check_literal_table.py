#!/usr/bin/env python3
"""Independent structural audit of numeric binary TM text; no source execution."""
import argparse
import hashlib
import json
from collections import deque
from pathlib import Path

def parse_table(path, halt):
    rows = {}
    start = None
    raw = path.read_bytes()
    for number, line in enumerate(raw.decode("ascii").splitlines(), 1):
        fields = line.split()
        if not fields:
            continue
        if fields[:2] == ["#!", "start"]:
            if len(fields) != 3 or start is not None:
                raise ValueError(f"line {number}: invalid/duplicate start header")
            start = int(fields[2])
            continue
        if fields[0].startswith("#"):
            continue
        if len(fields) != 5:
            raise ValueError(f"line {number}: expected state read write move next")
        q, bit, write, direction, target = fields
        q, bit, write, target = map(int, (q, bit, write, target))
        if min(q, target) < 0 or bit not in (0, 1) or write not in (0, 1):
            raise ValueError(f"line {number}: invalid numeric field")
        if direction not in ("L", "R"):
            raise ValueError(f"line {number}: invalid direction")
        if (q, bit) in rows:
            raise ValueError(f"line {number}: duplicate transition")
        rows[q, bit] = (write, direction, target)
    if start is None:
        raise ValueError("missing start header")
    states = sorted({q for q, _ in rows})
    if halt in states:
        raise ValueError("halting state has outgoing rows")
    if start not in states:
        raise ValueError("initial state missing")
    if set(rows) != {(q, b) for q in states for b in (0, 1)}:
        raise ValueError("a working state lacks a binary transition")
    if any(t not in states and t != halt for _, _, t in rows.values()):
        raise ValueError("transition targets an undeclared nonhalting state")
    return raw, start, states, rows

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("table", type=Path)
    ap.add_argument("--halt", type=int, required=True)
    args = ap.parse_args()
    raw, start, states, rows = parse_table(args.table, args.halt)
    seen = {start}
    queue = deque([start])
    while queue:
        q = queue.popleft()
        for b in (0, 1):
            t = rows[q, b][2]
            if t != args.halt and t not in seen:
                seen.add(t)
                queue.append(t)
    normalized = "#! start " + str(start) + "\n" + "".join(
        f"{q} {b} {rows[q,b][0]} {rows[q,b][1]} {rows[q,b][2]}\n"
        for q in states for b in (0, 1))
    duplicates = []
    for i, q in enumerate(states):
        for r in states[i + 1:]:
            if all(rows[q, b] == rows[r, b] for b in (0, 1)):
                duplicates.append([q, r])
    # Greatest deterministic write/move/target bisimulation. This compares
    # states on all input-symbol words, not only on the actual blank run.
    classes = {q: 0 for q in states}
    rounds = 0
    while True:
        keys = {}
        refined = {}
        for q in states:
            signature = tuple((w, d, ("halt",) if t == args.halt else
                               ("work", classes[t]))
                              for w, d, t in (rows[q, 0], rows[q, 1]))
            if signature not in keys:
                keys[signature] = len(keys)
            refined[q] = keys[signature]
        rounds += 1
        if refined == classes:
            break
        classes = refined
    groups = [[q for q in states if classes[q] == c]
              for c in sorted(set(classes.values()))]
    print(json.dumps({
        "scope": "Literal syntax, numeric state count, totality, target closure, static reachability and identical-row checks only; no nonhalting or PA-equivalence proof",
        "table_name": args.table.name,
        "raw_bytes": len(raw),
        "raw_sha256": hashlib.sha256(raw).hexdigest(),
        "canonical_numeric_order_sha256": hashlib.sha256(normalized.encode()).hexdigest(),
        "start_state": start,
        "halting_state": args.halt,
        "working_states": len(states),
        "transitions": len(rows),
        "state_labels": states,
        "state_labels_contiguous": states == list(range(min(states), max(states) + 1)),
        "halting_transitions": [list(k) for k,v in sorted(rows.items()) if v[2] == args.halt],
        "static_graph_reachable_working_states": len(seen),
        "static_graph_unreachable_working_states": sorted(set(states) - seen),
        "pairs_with_identical_transition_rows": duplicates,
        "deterministic_write_move_bisimulation_rounds": rounds,
        "deterministic_write_move_bisimulation_classes": len(groups),
        "nonsingleton_deterministic_bisimulation_classes": [g for g in groups if len(g) > 1],
    }, indent=2, sort_keys=True))

if __name__ == "__main__":
    main()
