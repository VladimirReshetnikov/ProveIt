#!/usr/bin/env python3
"""Merge a specified pair of identical binary TM rows and densely relabel.

This proves only an explicit finite transition homomorphism, not the original
machine's higher-level correctness. The source table is never modified.
"""
import argparse
import hashlib
import json
from pathlib import Path
from check_literal_table import parse_table

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("source", type=Path)
    ap.add_argument("--halt", type=int, required=True)
    ap.add_argument("--remove", type=int, required=True)
    ap.add_argument("--retain", type=int, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--certificate", type=Path, required=True)
    args = ap.parse_args()
    if args.output.resolve() == args.source.resolve():
        raise SystemExit("Source overwrite is forbidden")
    raw, start, states, rows = parse_table(args.source, args.halt)
    a, b = args.remove, args.retain
    if a == b or a not in states or b not in states:
        raise SystemExit("The requested pair is not two distinct working states")
    if any(rows[a, bit] != rows[b, bit] for bit in (0, 1)):
        raise SystemExit("Complete transition rows are not identical")
    representatives = [q for q in states if q != a]
    dense = {q: i for i, q in enumerate(representatives)}
    mapping = {q: dense[b if q == a else q] for q in states}
    mapping[args.halt] = len(representatives)
    new = {}
    for q in representatives:
        for bit in (0, 1):
            w, d, t = rows[q, bit]
            new[mapping[q], bit] = (w, d, mapping[t])
    for (q, bit), (w, d, t) in rows.items():
        if new[mapping[q], bit] != (w, d, mapping[t]):
            raise RuntimeError("Transition homomorphism failed")
    data = (f"#! start {mapping[start]}\n" + "".join(
        f"{q} {bit} {new[q,bit][0]} {new[q,bit][1]} {new[q,bit][2]}\n"
        for q in range(len(representatives)) for bit in (0, 1))).encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(data)
    cert = {
        "scope": "Exact finite transition homomorphism; yields step-for-step all-tape equivalence by induction, conditional on the semantics of the source table; does not establish its Con(U) calibration",
        "source_name": args.source.name,
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "output_name": args.output.name,
        "output_sha256": hashlib.sha256(data).hexdigest(),
        "source_working_states": len(states),
        "output_working_states": len(representatives),
        "source_halt": args.halt,
        "output_halt": mapping[args.halt],
        "source_start": start,
        "output_start": mapping[start],
        "removed_state": a,
        "retained_state": b,
        "state_map": {str(k): v for k, v in sorted(mapping.items())},
        "source_rows_checked": len(rows),
        "all_transition_homomorphism_identities_hold": True,
        "halt_fiber_is_singleton": all(mapping[q] != mapping[args.halt] for q in states),
    }
    args.certificate.parent.mkdir(parents=True, exist_ok=True)
    args.certificate.write_text(json.dumps(cert, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k,v in cert.items() if k != "state_map"}, indent=2))

if __name__ == "__main__":
    main()
