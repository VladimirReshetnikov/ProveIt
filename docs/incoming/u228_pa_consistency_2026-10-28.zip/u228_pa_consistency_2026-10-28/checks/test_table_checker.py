#!/usr/bin/env python3
"""Positive fixtures and rejection controls for the owned structural checker."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

CHECKER = Path(__file__).with_name("check_literal_table.py")

def main():
    good = "#! start 0\n0 0 0 R 0\n0 1 1 R 0\n1 0 0 R 1\n1 1 1 R 1\n"
    bad = {
        "duplicate_row": good + "0 0 0 R 0\n",
        "missing_row": good.replace("1 1 1 R 1\n", ""),
        "bad_write": good.replace("0 0 0 R 0", "0 0 2 R 0"),
        "bad_read": good.replace("0 0 0 R 0", "0 2 0 R 0"),
        "bad_direction": good.replace("0 0 0 R 0", "0 0 0 S 0"),
        "unknown_target": good.replace("0 0 0 R 0", "0 0 0 R 9"),
        "halting_outgoing": good + "2 0 0 R 2\n2 1 1 R 2\n",
        "missing_start": good.replace("#! start 0\n", ""),
        "unknown_start": good.replace("#! start 0", "#! start 7"),
    }
    results = []
    with tempfile.TemporaryDirectory(prefix="owned_tm_checker_") as directory:
        path = Path(directory) / "fixture.tm"
        def call(data):
            path.write_text(data)
            return subprocess.run([sys.executable, str(CHECKER), str(path),
                                   "--halt", "2"], capture_output=True, text=True)
        out = call(good)
        if out.returncode:
            raise RuntimeError(out.stderr)
        report = json.loads(out.stdout)
        if report["deterministic_write_move_bisimulation_classes"] != 1:
            raise RuntimeError("Two equivalent loop states were not merged")
        if report["static_graph_unreachable_working_states"] != [1]:
            raise RuntimeError("Graph reachability fixture failed")
        results.append({"test": "two_equivalent_loops", "passed": True})
        out = call(good.replace("1 0 0 R 1", "1 0 0 L 1"))
        if out.returncode or json.loads(out.stdout)["deterministic_write_move_bisimulation_classes"] != 2:
            raise RuntimeError("Distinct movement fixture failed")
        results.append({"test": "different_movement_separates_states", "passed": True})
        for name, fixture in bad.items():
            out = call(fixture)
            if out.returncode == 0:
                raise RuntimeError("Invalid fixture accepted: " + name)
            results.append({"test": name, "passed": True, "rejected": True})
    print(json.dumps({"scope": "Finite tests of the owned structural checker, not a formal correctness proof",
                      "tests": results, "all_passed": True}, indent=2))

if __name__ == "__main__":
    main()
