A 228-state binary Turing machine for unary power covering
28 October 2026

RESULT
The literal machine has 228 working states, alphabet {0,1}, a blank
bi-infinite tape, start state 0, and halt state 228. Every transition
writes, moves L/R, then changes state. All initialization is counted.
The mathematical report establishes in PA:
  nonhalting of this machine iff Con(U).
This is an ordinary PA-formalizable proof, not a new kernel-checked
Rocq/Lean/PA certificate. No global minimality is claimed.

START HERE
report.pdf / report.tex       Mathematical report and complete literal table
portable_u_machine/machine/u228.tm  Exact executable transition table
portable_u_machine/reproduce.py    Offline complete build/check entry point
proofs/                       Full calibration, final audit, U audit
sources/pa_unary_power_cover.zip   Exact supplied theory/proof packet
sources/logical_dependencies/     Inherited finite logical proof evidence
SHA256SUMS                    Integrity manifest (excludes itself)

REPLAY
Requires Python 3 (standard library only):
  python3 checks/audit_fixed10.py
  python3 portable_u_machine/reproduce.py
Do not use python -O: optimized mode is explicitly refused because
assertions form part of the checks. Replay may take several minutes.
The script reconstructs source and parent machine, checks 5,143 all-natural
symbolic primitive cases, verifies the exact quotient and 15,429 finite
literal cases, and checks the 95,702-step blank initialization.
Finite simulations are cross-checks, not the nonhalting proof.

PDF BUILD
With a normal TeX Live installation:
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
Alternatively bash build_local.sh builds into build/ and handles this
workspace's read-only local TeX cache. TeX-version changes may alter PDF
bytes. The literal table's hash is fixed:
  f935bad5c880eb94f8255453e2a94e73bf5b935a2a9b301ec2c9b5a3ad5bdaaf

PROOF SCOPE
The source-to-calculus compiler and finite-proof translations are detailed
mathematical arguments. The checkers establish exact source/table facts,
all-natural primitive simulation and a stepwise all-tape quotient; they do
not implement a general end-to-end PA/U proof transformer. Existing logical
and unary-theory proof dependencies are included for independent review.
No upstream repository was modified. This packet does not certify earlier
rejected candidate reductions. Their counterexamples are supplementary.

AUDIT NOTE SCOPE
Read-only/source-inspection statements in historical calibration notes
refer to those particular source reviews. The verification workflow did
execute the hash-bound historically authored runtime modules after
provenance verification, as recorded in OWNED_CHECKER_PROVENANCE.json.
