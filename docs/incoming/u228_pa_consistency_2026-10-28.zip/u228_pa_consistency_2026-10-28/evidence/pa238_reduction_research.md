# PA238 reduction inspection — 2026-10-28

## Useful result first

**No sub-238 machine has been established by this inspection.** A particularly
tempting one-state deletion passes the entire published blank bootstrap, but is
refuted by a valid instruction-frame counterexample. It must not be reported as
PA237 or as a machine for Con(U).

The useful reusable output is an independently authored symbolic evaluator for
the exact PA238 table. It reproduces all 5,732 guarded source-instruction cases
(4,409 sites, with both decrement branches), using an arbitrary natural gap and
an opaque complete register file. All baseline endpoints match. This is
mathematical/checker evidence, **not** a newly compiled Rocq certificate or a
serialized PA derivation.

## Pinned baseline

- Repository: `jeff87654/busy-beaver`, clone HEAD
  `05c050f8f60037929008c4d7c7ad5231adb032bf` (parent-observed).
- Literal file: `PA/m238/machine/pa_238.tm`.
- SHA-256: `ffe370842d70bae96688ad5e290073edffe0bb213cf12fe562a75a74bec966de`.
- 238 working states 0–237; initial 0; separate terminal 238; blank 0;
  476 defined transitions. `pa_238.tm` in this folder is byte-identical.
- Endpoint source: `PA/m238/coq/e2e/Targets238.v`, theorem
  `pa238_iff_ordinary_proved`, asserting
  `blank_halts238 <-> PA238.PAeq_inconsistent`.
- This endpoint is an external Rocq proposition. Its finite-proof compilation
  structure is relevant to PA formalizability, but its mere existence is not an
  internal PA theorem and must not be described as one without the additional
  arithmetized proof-compiler argument.

## Rejected state-23 shortcut

Proposed old-label edit:

```
delete 23
22 0 0 L 24     # instead of 22 0 0 L 23
```

If the two cells left of the head are zero when state 22 reads zero, the old
three-step block `22 -> 23 -> 24 -> 24` equals the proposed one-step block,
including the entire tape and head. All 3,099 affected events in the first
799,504 blank steps satisfy this guard. The published endpoint is reproduced:
state 25, head -20, marker -21, 38 gap cells, active physical registers
`[0,2,0,0,0,0,6,0,0]`, and all 324 spare blocks retained.

However, the universal instruction audit has **50 bad guarded cases at 25
distinct sites** among 14,605 exposed state-22/read-0 events. The first is
zero-based site 41, path `11101001001000000`, instruction `EDecnz 1`. The head's
nearest left cell is 1, not 0. This is not merely a symbolic inability to prove
a true guard: the independent sibling audit concretized it at gap 0 and
register file `[0,0,0,0,0,0,0,1,0]`, observing an incorrect dispatcher return.
See `/workspace/shared/pa237_audit/concrete_counterexample.json`.

## Exact symbolic evaluator and proof obligations

`symbolic_guard.py` reads table and source inventory as inert data. It does not
execute upstream programs. A segment `(b,a,c)` denotes the finite run
`b^(a*g+c)` for every natural `g`. Literal cell steps use the table verbatim.
Whole-run scans are permitted only for literal same-state self-loops in the
scan direction. A non-self-loop may expose a cell only when the constant part
is positive. Canonical comparison merges adjacent same-symbol runs and removes
only exterior left zeros; it compares the complete PC/gap/header and file phase.

Opaque register-file steps use exactly the four published contracts for marking,
increment, zero decrement, and positive decrement, preserving every arbitrary
old register/spare and appending the prescribed new zero spare. The proposed
state-23 modification is outside these file routines. Those contracts are
inherited dependencies, not assumed sampled-register equivalences. To elevate
this checker to an independent end-to-end proof, review its four contracts and
their source-table correspondence; its representation, scan, and finite loop
rules; complete inventory extraction; and the baseline proof-calculus/source
and PA-internalization layers. No such kernel build was run here.

The baseline audit records: 5,732 cases; 8,824 file macro events; 17,736 recorded
right-run scans; 1,227,058 literal cell events; maximum 497 symbolic operations
per case. Left-run scans also execute correctly but were not included in the
`scans` statistic. This census is not a count of literal elapsed time.

## Other bounded negative searches

1. `search_marker_fold.py`: no exact 1/3-step two-state predecessor-marker fold.
2. `search_marker_both.py`: no one-row two-cell fold using either left or right
   marker and up to 64 literal moves.
3. `search_marker_full.py`: 5,570 pairs with opposite syntactically guaranteed
   predecessor markers, permitting both merged rows to change; no fold confined
   to the marker/current cells with an existing helper entry. Neither this nor
   the prior searches is a general state-minimization theorem.
4. `search_suffix_fold.py`: sound incoming-CFG suffix sets of widths 2,3,4,5;
   respectively 61,78,86,94 eligible one-row pairs; no exact finite-window fold.
5. `source_rotations.py`: complete single global binary associativity rotations
   with exact guarded ordinal CFG equality. Baseline has 209 distinct AST terms
   (185 internal nodes, 24 primitive leaves). Ninety valid equal-cost rotations,
   120 valid +1 rotations, and no valid one-rotation saving. One 208-term result
   fails CFG equality. Six nontrivial physical folded edges need attention in
   any literal reallocator; source subtree counts are not state counts.
6. `search_boot.cpp`: own C++ search after redirecting `0/0` to `(1,L,4)`, so
   normal runtime states 1 and 3 can be bypassed when old state 3 reads 1.
   Delete 3 and repurpose 1 as a fresh start whose first row is any of 944
   write/direction/target choices (targets exclude 1,3). No qualifying root frame
   was found in three million moves per choice within a 16,384-cell tape window.
   Qualifying frames required gap >=38, all scratch/pending/top/stack/cache zero,
   next-proof <=32, and arbitrary parameter-1. This is a bounded search result,
   not a universal impossibility statement. The earlier log used the narrower
   published checkpoint and 1.5 million moves.

`pa238.sites.json` is the independently extracted 4,409-entry source inventory
in `[bitpath,CI/CD/CB/CC/CH,operand]` form for transplantation experiments.
Logical-to-physical slot permutation is `[6,7,0,2,1,8,4,3,5]`. No successful
K215-backend transplantation is asserted by this folder.

## Remaining concrete routes

An alternative bootstrap family keeps `0/0 -> 1`, changes `1/0 -> 4`, deletes
3, and uses the ordinarily unused row 1/1 as an initializer hook. A sibling
agent found no such hook among all 237 start states within 10,000 moves (215
bounded limits and 22 certified blank escapes). A completed 180-second beam
search lowered the number of CD paths ending in at least six zeros from 25 to
6 while retaining 185 internal nodes, but did not eliminate them; the snapshot
is `/workspace/shared/pa237_audit/tailzero_best.json`.
Source reassociation lowering problematic zero runs
could make the state-23 shortcut valid, but must preserve the exact source CFG,
literal runtime and blank initialization; a low node count alone is insufficient.
