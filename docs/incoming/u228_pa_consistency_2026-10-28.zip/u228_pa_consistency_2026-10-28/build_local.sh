#!/bin/bash
# Local TeX Live repair for the read-only Debian installation in this workspace.
# A standard complete TeX installation can simply run pdflatex twice instead.
set -euo pipefail
cd "$(dirname "$0")"
export TEXINPUTS='.:/usr/share/texlive/texmf-dist/tex//:/usr/share/texmf/tex//:'
export TEXFORMATS="$PWD/build/texcache//:"
export TEXMFVAR="$PWD/build/texcache/var"
export TEXMFCONFIG="$PWD/build/texcache/config"
export TEXFONTMAPS='/usr/share/texlive/texmf-dist/fonts/map//:/usr/share/texmf/fonts/map//:'
export TFMFONTS='/usr/share/texmf/fonts/tfm//:/usr/share/texlive/texmf-dist/fonts/tfm//:'
export T1FONTS='/usr/share/texmf/fonts/type1//:/usr/share/texlive/texmf-dist/fonts/type1//:'
export VFFONTS='/usr/share/texmf/fonts/vf//:/usr/share/texlive/texmf-dist/fonts/vf//:'
export ENCFONTS='/usr/share/texmf/fonts/enc//:/usr/share/texlive/texmf-dist/fonts/enc//:'
mkdir -p build/texcache
if [ ! -f build/texcache/pdflatex.fmt ]; then
  (cd build/texcache; pdftex -ini -etex -no-shell-escape -jobname=pdflatex -progname=pdflatex pdflatex.ini > format.log)
fi
for pass in 1 2; do
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -output-directory=build report.tex > "build/typeset-$pass.log"
done
pdfinfo build/report.pdf
