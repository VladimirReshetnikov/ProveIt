from pathlib import Path
R=Path(__file__).resolve().parents[1]
def leaf(t):return isinstance(t[0],str)
def tree(ss):
 d={r[0]:tuple(r[1:])for r in ss}
 def go(p):return d[p]if p in d else(go(p+'0'),go(p+'1'))
 return go('')
def sites(t,p=''):
 return [[p,*t]]if leaf(t)else sites(t[0],p+'0')+sites(t[1],p+'1')
