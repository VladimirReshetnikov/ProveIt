"""Owned W frontend construction; never executes imported repository programs.
Source nodes are inert literals. Output is a path-register program, NOT a certified TM.
"""
import json,hashlib
from functools import lru_cache
import macro_data as X
I=X.I
O=I.R/'generated'
@lru_cache(None)
def nodes(t):return frozenset([t])if I.leaf(t)else frozenset([t])|nodes(t[0])|nodes(t[1])
def cfg(t):
 out=[]
 def go(n,i,bs,cs):
  if I.leaf(n):
   op,k=n;edges=[]if op=='CH'else[cs[-k]]if op=='CC'else[bs[-k]]if op=='CB'else[bs[-1],i+1]if op=='CD'else[i+1]
   out.append((op,None if op in['CB','CC']else k,tuple(edges)));return
  go(n[0],i,bs+[i+X.size(n)],cs);go(n[1],i+X.size(n[0]),bs,cs+[i])
 go(t,0,[],[]);return out

def seq(xs):
 assert xs
 return xs[0]if len(xs)==1 else(xs[0],seq(xs[1:]))
def isolate(a,b):
 ps=X.pieces(a,b);assert all(X.bounds(t)==(0,0,False)for i,j,t in ps)
 return seq([t for i,j,t in ps])
def splice(t,lo,hi,repl):
 def go(n,i):
  j=i+X.size(n)
  if j<=lo or hi<=i:return n
  if lo<=i and j<=hi:
   assert X.bounds(n)==(0,0,False),(i,j)
   return repl if i==lo else None
  a=go(n[0],i);b=go(n[1],i+X.size(n[0]));return b if a is None else a if b is None else(a,b)
 return go(t,0)

def bestseq(xs,known):
 pool={}
 for t in known:
  if X.bounds(t)==(0,0,False):pool.setdefault(X.word(t),[]).append(t)
 dp={}
 for n in range(1,len(xs)+1):
  for i in range(len(xs)-n+1):
   j=i+n;ref=seq(xs[i:j]);alts=[t for t in pool.get(X.word(ref),[])if cfg(t)==cfg(ref)]
   if alts:dp[i,j]=(0,min(alts,key=lambda t:len(nodes(t))));continue
   if n==1:dp[i,j]=(len(nodes(ref)-known),ref);continue
   opts=[]
   for k in range(i+1,j):
    ac,a=dp[i,k];bc,b=dp[k,j];z=(a,b);opts.append((ac+bc+(z not in known),k,z))
   c,k,z=min(opts,key=lambda r:r[:2]);dp[i,j]=(c,z)
 return dp[0,len(xs)][1]
M=X.M.copy();M['gate']=isolate(4556,4590);M['readc']=isolate(9,23);M['reada']=isolate(200,214);M['readb']=isolate(159,173)
loop=((('CD',5),(('CI',4),(('CI',6),('CC',3)))),(('CD',6),(('CI',5),('CC',2))))
M['affine']=(('CI',4),loop)
assert X.bounds(M['affine'])==(0,0,False)
# Formula syntax: R, I, Q take two parameters; N is negation. a,b,c are push macros.
R=lambda a,b:('R',a,b);Imp=lambda a,b:('I',a,b);Q=lambda a,b:('Q',a,b);Neg=lambda a:('N',a)
sub=Q('c',Imp(R('c','b'),R('c','a')))
upper=Q('b',Imp(R('b','c'),'c'))
lower=Q('b',Imp(sub,Imp('c',R('b','c'))))
formula=Neg(Q('c',Imp(lower,Neg(upper))))
def emit(f):return[f]if isinstance(f,str)else sum((emit(a)for a in f[1:]),[])+[f[0]]
tokens=['gate','readc']+emit(formula)
xs=[M[k]for k in tokens];lo,hi=2885,4556
results=[]
for mode in ['right','dp']:
 body=seq(xs[2:])if mode=='right'else bestseq(xs[2:],nodes(X.T))
 fixed=(('CI',4),body)
 repl=(M['gate'],(M['readc'],fixed));new=splice(X.T,lo,hi,repl)
 oldcfg,newcfg=cfg(X.T),cfg(new);delta=X.size(repl)-(hi-lo)
 def shift(j):
  assert not lo<j<hi,('external entry',j)
  return j if j<=lo else j+delta
 assert newcfg[lo:hi+delta]==[(op,k,tuple(j+lo for j in es))for op,k,es in cfg(repl)]
 for i,(op,k,es)in enumerate(oldcfg):
  if not lo<=i<hi:assert newcfg[i if i<lo else i+delta]==(op,k,tuple(shift(j)for j in es))
 p=O/f'fixed10_{mode}.sites.json';p.write_text(json.dumps(I.sites(new),separators=(',',':'))+'\n')
 results.append(dict(mode=mode,dag_nodes=len(nodes(new)),leaves=X.size(new),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_path=str(p),whole_source_cfg_transport=True))
r=dict(status='SOURCE_CONSTRUCTED_NOT_TM_CERTIFIED',input_source='research215_encoding/partial_permuted210.sites.json',baseline_nodes=len(nodes(X.T)),baseline_leaves=X.size(X.T),replaced_interval=[lo,hi],formula=formula,tokens=tokens,results=results)
(O/'FIXED10_SOURCE.json').write_text(json.dumps(r,indent=2)+'\n');(O/'macros_fixed10.json').write_text(json.dumps(M,separators=(',',':'))+'\n');print(json.dumps(r,indent=2))
