import inspect_frontend as I,json
from functools import lru_cache
fr=lambda x:tuple(map(fr,x))if isinstance(x,list)else x
M={k:fr(v)for k,v in json.load(open(I.R/'inputs/macros.json')).items()}
S=json.load(open(I.R/'inputs/base.sites.json'));T=I.tree(S);W=tuple(tuple(r[1:])for r in S)
@lru_cache(None)
def word(t):return(t,)if I.leaf(t)else word(t[0])+word(t[1])
@lru_cache(None)
def size(t):return len(word(t))
@lru_cache(None)
def bounds(t):
 if I.leaf(t):
  o,k=t;return(1,0,False)if o=='CD'else(k,0,False)if o=='CB'else(0,k,False)if o=='CC'else(0,0,o=='CH')
 a,b=bounds(t[0]),bounds(t[1]);return(max(0,a[0]-1,b[0]),max(0,a[1],b[1]-1),a[2]or b[2])
spans={}
def span(t,i=0,p=''):
 spans[i,i+size(t)]=(p,t)
 if not I.leaf(t):span(t[0],i,p+'0');span(t[1],i+size(t[0]),p+'1')
span(T)
def pieces(lo,hi):
 out=[]
 def go(t,i):
  j=i+size(t)
  if j<=lo or i>=hi:return
  if lo<=i and j<=hi:out.append((i,j,t));return
  go(t[0],i);go(t[1],i+size(t[0]))
 go(T,0);return out
