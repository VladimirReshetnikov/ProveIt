"""Owned conservative literal compiler exploration. No supplied code is executed.
New decoder states are fresh; existing ones reused only at byte-identical subtrees.
Full primitive runtime and startup verification remain mandatory.
"""
from pathlib import Path
import json,collections,hashlib,os
import inspect_frontend as I
O=I.R/'generated'
def table(p):
 d={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,m,z=line.split();d[int(q),int(b)]=(int(w),1 if m=='R'else-1,int(z))
 return d
def encode(d):return '#! start 0\n'+''.join(f'{q} {b} {w} {"R"if m==1 else"L"} {z}\n'for(q,b),(w,m,z)in sorted(d.items()))
def mapping(T,t):
 roles=collections.defaultdict(set);gates=[];pp={}
 def walk(n,p):
  if I.leaf(n):return
  x={-1:1,**dict(enumerate(map(int,p)))};old=x.copy();q,h=84,0;seen=set()
  while h!=len(p):
   assert h in x and q!=254,(p,q,h)
   sig=q,h,tuple(sorted(x.items()));assert sig not in seen;seen.add(sig)
   w,d,q=T[q,x[h]];x[h]=w;h+=d
  assert x==old,('dirty prefix',p,q,h,old,x);roles[n].add(q);pp[p]=q
  for b,ch in enumerate(n):
   if I.leaf(ch):gates.append((ch,b,T[q,b],p+str(b)))
   else:walk(ch,p+str(b))
 walk(t,'');return roles,gates,pp
T=table(I.R/'inputs/base.native.tm');old=I.tree(json.load(open(I.R/'inputs/base.sites.json')))
roles,gates,pp=mapping(T,old);print('baseline roles',len(roles),'states',len(set(pp.values())))
choices=collections.defaultdict(set)
for op,b,act,p in gates:
 if act[:2]==(b,1):choices[op,b].add(act)
actions={k:next(iter(v))for k,v in choices.items()if len(v)==1}
for op in {op for op,b in choices if op[0]=='CI'}:
 zs={act[2]for (o,b),acts in choices.items()if o==op for act in acts}
 if len(zs)==1:
  z=next(iter(zs));actions[op,0]=(0,1,z);actions[op,1]=(1,1,z)
actions[('CI',6),1]=(1,1,82)
actions[('CC',3),1]=(0,-1,42);actions[('CC',1),1]=(0,-1,1);actions[('CC',2),1]=(0,-1,16);actions[('CB',1),1]=(0,-1,302)
print('interfaces',len(actions),'baseline leafvariants',len(set((op,b)for op,b,act,p in gates)))
from functools import lru_cache
@lru_cache(None)
def nodes(t):return frozenset([t])if I.leaf(t)else frozenset([t])|nodes(t[0])|nodes(t[1])
for mode in os.environ.get('MODES','dp').split(','):
 new=I.tree(json.load(open(O/f'{os.environ.get('SOURCE_PREFIX','fixed10')}_{mode}.sites.json')));U=T.copy();assigned={n:min(qs-{int(q)for q in os.environ.get('BAN_STATES','189,194').split(',')if q})for n,qs in roles.items()if qs-{int(q)for q in os.environ.get('BAN_STATES','189,194').split(',')if q}};assigned[new]=84;created=[];reused=[];claimed={84:new};origins={}
 def align(n,o):
  if I.leaf(n)or I.leaf(o):return
  if n!=o and o not in nodes(new):origins.setdefault(n,o)
  align(n[0],o[0]);align(n[1],o[1])
 align(new,old)
 qroles=collections.defaultdict(set)
 for n,qs in roles.items():
  for q in qs:qroles[q].add(n)
 def go(n):
  if n in assigned:return assigned[n]
  o=origins.get(n);qs=roles.get(o,set());qs=[q for q in qs if qroles[q]=={o}and q not in claimed and q not in {int(z)for z in os.environ.get('PROTECT_STATES','11,26').split(',')if z}]
  if qs:q=min(qs);reused.append(q)
  else:q=max(q for q,b in T)+1+len(created);created.append(q)
  assigned[n]=q;claimed[q]=n
  for b,ch in enumerate(n):
   if I.leaf(ch):assert(ch,b)in actions,('missing interface',ch,b);U[q,b]=actions[ch,b]
   else:U[q,b]=(b,1,go(ch))
  return q
 for b,ch in enumerate(new):U[84,b]=(b,1,go(ch))if not I.leaf(ch)else actions[ch,b]
 reach={0};todo=[0]
 for q in todo:
  for b in(0,1):
   z=U[q,b][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 U={r:act for r,act in U.items()if r[0]in reach};p=O/f'{os.environ.get('SOURCE_PREFIX','fixed10')}_{mode}.incremental{os.environ.get('SUFFIX','_unfold194')}.uncertified.native.tm';p.write_text(encode(U))
 failure=None
 try:rr,gg,ps=mapping(U,new)
 except Exception as e:failure=repr(e)
 result=dict(status='UNVERIFIED_EXPLORATION_TABLE',states=len(reach),rows=len(U),new_decoder_states=len(created),reused_decoder_states=reused,old_states_removed=sorted({q for q,b in T}-reach),prefix_failure=failure,source_path=str(O/f'{os.environ.get('SOURCE_PREFIX','fixed10')}_{mode}.sites.json'),table_path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),warning='No universal primitive runtime or blank startup theorem. Do not present as solving Con(U).')
 (O/f'{os.environ.get('SOURCE_PREFIX','fixed10')}_{mode}.incremental{os.environ.get('SUFFIX','_unfold194')}.compilation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
