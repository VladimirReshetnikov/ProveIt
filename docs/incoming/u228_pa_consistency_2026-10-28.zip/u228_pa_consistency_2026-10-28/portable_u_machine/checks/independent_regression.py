"""Independently authored literal finite regression plus syntax/source coverage checks.
No supplied executable modules imported. This is NOT universal proof evidence.
"""
from pathlib import Path
if not __debug__: raise RuntimeError("Auditing requires Python assertions; do not use -O.")
import json,hashlib,collections,time,argparse
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser()
ap.add_argument('--table',type=Path,default=ROOT/'machine/u228.tm')
ap.add_argument('--sites',type=Path,default=ROOT/'source/u228.sites.json')
ap.add_argument('--dispatch',type=int,default=82)
ap.add_argument('--output',type=Path,default=ROOT/'evidence/independent_regression.json')
args=ap.parse_args();F=args.table;SP=args.sites;DISPATCH=args.dispatch

T={}
for ln in F.read_text().splitlines():
 if ln and not ln.startswith('#'):
  q,b,w,d,z=ln.split();q,b,w,z=map(int,[q,b,w,z]);assert(q,b)not in T and b in(0,1)and w in(0,1)and d in('L','R');T[q,b]=(w,1 if d=='R'else-1,z)
Q={q for q,b in T};assert len(T)==2*len(Q)and all((q,b)in T for q in Q for b in (0,1));HS={z for w,d,z in T.values()}-Q;assert len(HS)==1;HALT=next(iter(HS));assert 0 in Q and DISPATCH in Q
S=json.loads(SP.read_text());leaves={row[0]:row[1:]for row in S};prefix={pc[:i] for pc in leaves for i in range(len(pc))};assert not set(leaves)&prefix and all(p+b in set(leaves)|prefix for p in prefix for b in'01')
assert all(isinstance(pc,str) and pc and set(pc)<={'0','1'} for pc in leaves)
assert len(leaves)==len(S) and max(map(len,leaves))<=64
assert all(op in ('CI','CD','CB','CC','CH') and ((arg is None) if op=='CH' else type(arg)is int and (0<=arg<9 if op in('CI','CD') else arg>=1)) for _,op,arg in S)
REACH={0};todo=[0]
for q in todo:
 if q==HALT:continue
 for b in(0,1):
  z=T[q,b][2]
  if z not in REACH:REACH.add(z);todo.append(z)
assert Q<=REACH and HALT in REACH
PHY=(6,2,0,4,3,7,8,5,1)
def frame(pc,rs,sp,gap):
 vals=[0]*9
 for i,j in enumerate(PHY):vals[j]=rs[i]
 row=list(map(int,pc))+[0]*(64+gap-len(pc))+[1]
 for v in vals+sp:row += [0]+[1]*(v+1)
 return {-1}|{i for i,b in enumerate(row) if b}
def inc(pc):
 n=len(pc);v=int(pc or'0',2)+1;return(format(v%2**n,'0'+str(n)+'b')if n else'',int(v==2**n))
def cut(pc,b,k):
 while pc and k:
  if pc[-1]==b:k-=1
  pc=pc[:-1]
 return pc
def target(site,rs,sp,gap):
 pc,op,arg=site;rs=rs[:];sp=sp[:];shift=0
 if op=='CH':return None
 if op=='CI':rs[arg]+=1;sp.append(1);pc,shift=inc(pc)
 elif op=='CD' and rs[arg]:rs[arg]-=1;gap+=1;pc,shift=inc(pc)
 elif op in('CD','CB'):pc,shift=inc(cut(pc,'0',arg if op=='CB' else 1))
 elif op=='CC':pc=cut(pc,'1',arg)
 return -shift,{i-shift for i in frame(pc,rs,sp,gap+shift)},rs,sp
coverage=collections.Counter();cases=0;failure=None;start=time.monotonic()
for idx,site in enumerate(S):
 for positive in ([False,True]if site[1]=='CD'else[False]):
  for v in (0,1,2):
   rs=[v]*9
   if site[1]=='CD':rs[site[2]]=v+1 if positive else 0
   sp=[v,1,0];gap=v
   want=target(site,rs,sp,gap);t=frame(site[0],rs,sp,gap);q,h=DISPATCH,0
   for tick in range(100000):
    if tick and ((q==HALT)if want is None else q==DISPATCH and h==want[0] and t==want[1]):cases+=1;break
    if q==HALT:failure=dict(status='unexpected_halt',site_index=idx,site=site,regs=rs,spares=sp,gap=gap,steps=tick);break
    b=int(h in t);coverage[q,b]+=1;w,d,z=T[q,b]
    if w:t.add(h)
    else:t.discard(h)
    q=z;h+=d
   else:failure=dict(status='target_not_reached_within_limit',site_index=idx,site=site,regs=rs,spares=sp,gap=gap,steps=100000,state=q,head=h,ones=sorted(t))
   if failure:break
  if failure:break
 if failure:break
 if idx%1000==0:print(idx,cases,'seconds',round(time.monotonic()-start,2),flush=True)
# Exact blank computation compared directly against a self-constructed frame.
q=h=0;t=set()
for tick in range(95702):
 b=int(h in t);w,d,z=T[q,b]
 if w:t.add(h)
 else:t.discard(h)
 q=z;h+=d
bootwant={i-8 for i in frame('',[4]+[0]*8,[1]*40,1)}
boot=dict(steps=95702,state=q,head=h,exact_frame_pass=(q,h,t)==(DISPATCH,-8,bootwant),ones=sorted(t))
result=dict(status='FINITE_PASS'if not failure and boot['exact_frame_pass'] else'FINITE_FAIL',table_sha256=hashlib.sha256(F.read_bytes()).hexdigest(),sites_sha256=hashlib.sha256(SP.read_bytes()).hexdigest(),states=len(Q),rows=len(T),start=0,halt=HALT,dispatch=DISPATCH,all_states_graph_reachable=True,site_count=len(S),max_depth=max(map(len,leaves)),complete_prefix_tree=True,cases=cases,expected_cases=3*sum(2 if s[1]=='CD' else 1 for s in S),failure=failure,rows_observed=len(coverage),unobserved_rows=[list(k)for k in T if not coverage[k]],blank=boot,seconds=time.monotonic()-start)
args.output.write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='blank'}));print('blank',q,h,boot['exact_frame_pass'])
