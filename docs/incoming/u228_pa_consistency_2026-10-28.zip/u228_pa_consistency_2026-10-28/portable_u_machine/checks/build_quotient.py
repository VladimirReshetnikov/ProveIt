"""Independently authored exact one-step quotient certificate; external files are data.
The finite checked equation is delta_Q(pi(q),b)=(w,d,pi(q')) whenever
parent delta(q,b)=(w,d,q'). It holds for all 458 parent rows, hence all tapes.
"""
from pathlib import Path
if not __debug__: raise RuntimeError("Auditing requires Python assertions; do not use -O.")
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'machine/parent_u229.native.tm';S=ROOT/'source/u228.sites.json'
raw=P.read_bytes();assert hashlib.sha256(raw).hexdigest()=='24d0a396375b50e373406538d20a7b0d76352b6ea22cbdd0e313b8df5ceb565b';assert hashlib.sha256(S.read_bytes()).hexdigest()=='27d2b58fc9027cbf7c6adda6b52afd54890bfbd1b5db48d35162b3b5dfeda96e'
T={}
for line in raw.decode().splitlines():
 if not line or line.startswith('#'):continue
 q,b,w,d,z=line.split();q,b,w,z=map(int,[q,b,w,z]);assert(q,b)not in T and b in(0,1)and w in(0,1)and d in('L','R');T[q,b]=(w,d,z)
Q={q for q,b in T};assert len(Q)==229 and len(T)==458 and all((q,b)in T for q in Q for b in(0,1));assert {z for w,d,z in T.values()}-Q=={254};assert T[26,0]==T[310,0] and T[26,1]==T[310,1]
remaining=sorted(Q-{310});M={q:i for i,q in enumerate(remaining)};M[310]=M[26];M[254]=228;assert M[0]==0 and set(M.values())==set(range(229))
C={}
for(q,b),(w,d,z)in T.items():
 key=M[q],b;value=w,d,M[z]
 assert key not in C or C[key]==value
 C[key]=value
assert set(C)=={(q,b)for q in range(228)for b in(0,1)}
text='#! start 0\n'+''.join(f'{q} {b} {w} {d} {z}\n'for(q,b),(w,d,z)in sorted(C.items()));F=ROOT/'machine/u228.tm';F.write_text(text)
V={}
for line in F.read_text().splitlines():
 if line and not line.startswith('#'):
  q,b,w,d,z=line.split();V[int(q),int(b)]=(int(w),d,int(z))
checks=[]
for(q,b),(w,d,z)in sorted(T.items()):
 assert V[M[q],b]==(w,d,M[z]);checks.append([q,b,M[q],w,d,z,M[z]])
assert all((q==254)==(M[q]==228)for q in Q|{254})
reach={0};todo=[0]
for q in todo:
 if q==228:continue
 for b in(0,1):
  z=V[q,b][2]
  if z not in reach:reach.add(z);todo.append(z)
assert reach==set(range(229))
receipt=dict(status='ALL_TAPE_ONE_STEP_COMMUTATION_PASS',parent_sha256=hashlib.sha256(raw).hexdigest(),source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),quotient_sha256=hashlib.sha256(F.read_bytes()).hexdigest(),merged_parent_states=[26,310],working_states=228,transitions=456,parent_rows_checked=len(checks),start=0,halt=228,dispatch=M[84],all_states_graph_reachable=True,halting_reflection_checked=True,relation='R((q,tape),(p,tape)) iff p=pi(q); tape and head unchanged',induction='For every parent configuration c and n, quotient_run(n,pi(c)) = pi(parent_run(n,c)), interpreting halt as terminal. Thus halting occurs at exactly the same finite times in both machines, on every tape.',scope='Unconditional exact table quotient; source-to-theory calibration is separate.',native_to_quotient={str(q):M[q]for q in sorted(M)},row_checks=checks)
(ROOT/'machine/state_map.json').write_text(json.dumps({str(q):M[q]for q in sorted(M)},indent=2)+'\n');(ROOT/'evidence/quotient_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k not in('row_checks','native_to_quotient')}))
