"""Rebuild and check the raw fixed10 machine, stdlib only, no network/install."""
from pathlib import Path
if not __debug__: raise RuntimeError("Reproduction requires assertions; do not use -O.")
import subprocess,sys,hashlib,os
R=Path(__file__).resolve().parent
for name in ['build_fixed10.py','compile_incremental.py']:
 subprocess.run([sys.executable,'-B',str(R/'checks'/name)],cwd=R,check=True)
for a,b in [('generated/fixed10_dp.incremental_unfold194.uncertified.native.tm','machine/parent_u229.native.tm'),('generated/fixed10_dp.sites.json','source/u228.sites.json')]:
 assert (R/a).read_bytes()==(R/b).read_bytes(),(a,b)
subprocess.run([sys.executable,'-B',str(R/'checks/verify_runtime.py')],cwd=R,check=True)
import json
assert json.load(open(R/'evidence/RUNTIME.json'))['status']=='PASS'
subprocess.run([sys.executable,'-B',str(R/'checks/build_quotient.py')],cwd=R,check=True)
subprocess.run([sys.executable,'-B',str(R/'checks/independent_regression.py')],cwd=R,check=True)
runtime=json.loads((R/'evidence/RUNTIME.json').read_text())
quotient=json.loads((R/'evidence/quotient_receipt.json').read_text())
finite=json.loads((R/'evidence/independent_regression.json').read_text())
raw_sha='24d0a396375b50e373406538d20a7b0d76352b6ea22cbdd0e313b8df5ceb565b'
source_sha='27d2b58fc9027cbf7c6adda6b52afd54890bfbd1b5db48d35162b3b5dfeda96e'
final_sha='f935bad5c880eb94f8255453e2a94e73bf5b935a2a9b301ec2c9b5a3ad5bdaaf'
assert runtime['status']=='PASS' and runtime['checked_cases']==runtime['expected_cases']==5143
assert runtime['table_sha256']==raw_sha and runtime['source_sha256']==source_sha
assert quotient['status']=='ALL_TAPE_ONE_STEP_COMMUTATION_PASS'
assert quotient['parent_sha256']==raw_sha and quotient['quotient_sha256']==final_sha
assert quotient['parent_rows_checked']==458 and quotient['working_states']==228
assert finite['status']=='FINITE_PASS' and finite['failure'] is None
assert finite['cases']==finite['expected_cases']==15429
assert finite['table_sha256']==final_sha and finite['sites_sha256']==source_sha
assert finite['blank']['exact_frame_pass'] and finite['blank']['steps']==95702
result=dict(status='PASS',raw_table_sha256=raw_sha,source_sha256=source_sha,canonical_table_sha256=final_sha,
 working_states=228,universal_cases=5143,quotient_rows=458,finite_cases=15429,blank_steps=95702,
 scope='Exact source/table rebuild, all-natural primitive runtime, all-tape quotient and finite regression/blank bootstrap; source/theory proof is separate.')
(R/'evidence/REPRODUCTION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
print('Exact reconstruction and all-natural primitive runtime PASS. See report for source/theory proof.')
