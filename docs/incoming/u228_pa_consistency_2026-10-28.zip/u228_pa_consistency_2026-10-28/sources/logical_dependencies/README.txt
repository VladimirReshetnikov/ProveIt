Selected read-only logical proof dependencies

DominatedImplication.lean was taken from the existing local
research215_round13_calculus/inputs/DominatedImplication.lean.
The proof uses only MP, dominated implication rows and constructor growth.
It was inspected, not compiled afresh for this packet.

general_kappa_equality_helper.md, mathematical_audit.md and
k_equality_helper_extension.md are from the previously delivered
K224_Construction_2026-10-20 portable/theory tree (source116 proof/audit
subdirectories for the first two). Only their logical finite-proof
arguments are reused; their old K/ZFC endpoint is not reused.

NumericNamed238.v is read-only source from jeff87654/busy-beaver commit
05c050f8f60037929008c4d7c7ad5231adb032bf, PA/m238/coq/logic/.
It provides concrete finite named-logic specialization/alpha proof patterns.
It is not a standalone module and was not compiled in this release.

The archive integrity manifest binds all copied bytes. These source files
are supporting proof evidence, not newly generated formal certificates.
