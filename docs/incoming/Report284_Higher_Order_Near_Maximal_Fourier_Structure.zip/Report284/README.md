# Report284 Higher order near maximal Gowers norms

This package contains a self-contained mathematical article, editable TeX, a PDF, exact bounded diagnostics, regression tests, an offline builder, and three narrowly selected source snapshots. It is a mathematical research report with AI assistance, not a Lean implementation or a proof of a global Ramsey bound.

For every finite abelian group and d >= 1, cube-average defect epsilon <= 1/[20*6^(d-1)*(2^(d+2)+1)] gives a globally separately additive dual-valued frequency map and derivative Fourier coefficients greater than 3/4 on more than 70% of all tuples. On every cyclic group the frequency is c times the product of the directions and the ambient box can consist of full cycles. The large-coefficient assertion concerns a dense subset of that box.

The article also proves stronger-threshold uniqueness and symmetry, a near-one selected-energy bound, and proximity on every cyclic group Z/NZ to an N-periodic rational polynomial phase e(P(x))=exp(2*pi*i*P(x)). For k >= 2, N >= 2, A_k=(2^k+1)*6^((k-2)*(k-1)/2), and 0 < epsilon <= 3/(10*A_k), the hypothesis Q_k(f)>1-epsilon for |f|<=1 gives P in Q[x], P(0)=0, degree at most k-1, and a unit scalar z with squared normalized L2 error less than 2*(1-sqrt(1-A_k*epsilon))+epsilon <= (2*A_k+1)*epsilon. The exponential is N-periodic on all integers; the rational polynomial itself need not be periodic.

The cyclic integration uses the unique rational polynomial P with P(0)=0 and P(x+N)-P(x)=c*binom(x,d), whose coefficient of x^(d+1) is c/((d+1)!*N). Any integer lift of c can be used. Changing that lift may change the phase but not its required top-derivative character frequency. The article gives triangular and Newton-basis constructions, handles negative representatives, and proves the exact backward-sign demodulated-energy identity for arbitrary complex inputs. Polar normalization occurs once before descent.

The narrower ordinary residue-ring target z*e_N(p), with p in (Z/NZ)[x], is available under the sufficient condition gcd((k-1)!,N)=1. That condition belongs only to this classical-target corollary. The rational target has no factorial restriction on cyclic groups. No integration theorem on general noncyclic groups or symmetry between derivative directions and character evaluation is assumed or claimed; the Fourier and energy theorems continue to hold for every finite abelian group.

Eisner and Tao's established near-extremizer theorem and the established dense difference-map extension are credited. No historical priority, arbitrary-positive-uniformity inverse theorem, new global Ramsey estimate, formal verification, upload, or publication is claimed.

## Offline reproduction

Requirements: Linux, Python 3.11 or later, and installed TeX Live with pdftex, pdflatex, Latin Modern, microtype, amsmath, amssymb, amsthm, mathtools, geometry, hyperref, enumitem, booktabs, and array. Only Python's standard library, the installed TeX toolchain, and bundled files are used. The source snapshots are not a standalone Lean project. No network access or package download is required.

Run from any working directory using the absolute package path:

    python3 -I -B /path/to/Report284/build.py verify
    python3 -I -B /path/to/Report284/build.py reproduce --output /tmp/report284-rebuild

The output must be a fresh or empty absolute directory outside the source tree, and not an ancestor of it. Do not build into this payload. Use a new output path for each run. Existing output files are never overwritten. Symlink and hard-link aliases, nonregular entries, oversized files, extra source files/directories, and protected system output paths are rejected.

The verify command checks the exact source allowlist and, for a frozen distribution, the SHA-256 manifest. Reproduce stages exact source bytes, runs builder tests, companion tests, and all diagnostics both normally and with Python -O, and requires identical stdout. Checks remain active under optimization because validation uses explicit exceptions. Original and staged inventories are rechecked after every command, including failures.

Each build-launched test or diagnostic process uses a 640-digit integer-conversion cap, a 900-second wall-time cap, and a combined stdout/stderr cap of 4 MiB. Nested test subprocesses are covered by the enclosing process budget; the builder does not claim that every nested Python invocation inherits the same conversion flag. Source files are capped at 12 MiB each, total source bytes at 32 MiB, and source entries at 128. These are engineering guardrails for trusted bundled code, not a security sandbox for arbitrary Python or TeX.

A successful build writes, outside the public payload:

- Report284.pdf
- report284_higher_order_fourier.zip and its .sha256 file
- MANIFEST.sha256 covering all public files except itself
- reproduction_receipt.json, isolated working directories, and logs

The ZIP has sorted Report284/ paths, fixed timestamps and permissions, deterministic compression, and an exact member allowlist. Its sidecar covers the actual ZIP bytes. Byte hashes establish integrity, not mathematical correctness or author authentication.

To recreate only the ZIP from a frozen, manifest-pinned distribution:

    python3 -I -B /path/to/Report284/build.py package --output /tmp/report284-repack

Use reproduce with --no-zip to run the full checks and PDF compilation without creating a ZIP. The external receipt then records a null ZIP hash.

## PDF toolchain

The reference environment uses Python 3.12.14 and pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian). The builder fixes SOURCE_DATE_EPOCH=1791331200, UTC, and locale, generates a local pdflatex format, and runs three compile passes. Shell escape is disabled. The final log must have no overfull boxes, unresolved or multiply-defined references, missing citations, or rerun warning. Volatile PDF metadata is suppressed.

For a frozen distribution, the rebuilt PDF must match the bundled PDF byte-for-byte. Different TeX/font/package versions may change PDF bytes despite unchanged mathematics. Inspect the toolchain and logs rather than altering the supplied manifest to hide a mismatch. A separate source-only copy can be used for a personal non-bit-identical build.

## Exact diagnostic scope

The fixed program companion/exact_checks.py uses integers, Fraction arithmetic, modular polynomial differences, small exact cyclotomic fields Q[z]/Phi_n(z), with n in {2,3,4,5,7}, and the rational group algebra of Q/Z. There are no floating-point acceptance tests or tolerances. It prints deterministic JSON to stdout and does not write into the package. Parameter overrides are rejected.

The fixed workload contains:

- Main, symmetry, and recurrence constants for d=1 through 30
- 780 nonzero scalar multiplication kernels over cyclic groups of orders 2 through 40
- All 3,353 qualifying dense partial maps to Z/2Z or Z/3Z for domain orders 1 through 6; all 59 partially additive maps extend uniquely
- 286 nonzero scalar multilinear maps over ten small binary-vector-space product families, attaining the sharp support bound
- Eight generic agreement-data examples at the support threshold, explicitly not Fourier counterexamples
- Exact nonclassical Z/2 phase examples for d=1 through 8
- All recursive descent budgets for k=2 through 20
- 19,265 exact coefficient/increment tests in eleven polynomial families, including cyclic composite moduli 9, 25, and 35
- Eight exact cube/derivative/Fourier normalization cases, five exact demodulated-energy families, and 80 exact pointwise disk-return identities and inequalities
- 510 exact triangular/Newton rational-antiderivative comparisons for N=2 through 12 and m=2 through 7, using the distinct integers in {-2,-1,0,1,2,N-1,N,N+1}; 650 integer-binomial values, including 320 negative-argument identities
- 18,186 integer shift values, 90,930 point-representative checks, 4,590 signed/zero derivative recipes, 32,886 cyclic derivative values, 32,130 increment aliases, and 1,020 coefficient-lift changes with 5,100 point comparisons; repeated increment recipes count as repeated checks
- The exact N=2 cubic and eight N=2 torsion cases; 64 direct-cube versus selected-energy identities for unit and nonunit inputs; 32 formal wrong-sign mismatches, distinguished from a separate exact cyclotomic witness with correct energy 1 and wrong-sign energy 1/3; rational-descent budgets for k=2 through 30, covering 406 stages
- Byte-length, SHA-256, Git-blob SHA-1, pinned URL, and dependency checks for the three source snapshots

The 38 builder tests and 33 companion tests additionally check exact root arithmetic, Fourier sign, zero-free dense domains, strict boundary rejection, live guards under optimization, malformed parameters, source mutation, deterministic packaging, output limits, timeouts, and file-alias defenses. Equality in the formal group algebra implies equality of the associated complex expressions; inequality need not, which is why the wrong-sign witness is checked separately in an exact cyclotomic field. These are finite diagnostics, not universal proofs. The article proves the mathematical statements without extrapolating from the tested ranges. The deterministic JSON states all finite ranges and counts.

## Public payload

The payload contains 13 files: eleven sources, the PDF, and MANIFEST.sha256. Provenance sources are Definitions.lean, Mathlib_Fourier_ZMod.lean, and lake-manifest.json. They are read-only snapshots with precisely recorded pins. The full canonical article, external papers, private mathematical reviews, raw connector receipts, build logs, and exploratory research notes are excluded. No repository files are edited or uploaded by the build.
