# One-parameter closure with a fixed binary-union clause

Research prepared for Vladimir Reshetnikov and the ProveIt project.
Comparison snapshot: `2c74914bdfc98920ddcc3ff7c092cce10db4d709`,
observed 16 October 2026 at 23:15:58 UTC.

## Main result

The proposed consistency-search theory is **EPSC1 + BU**, in classical
equality-free first-order logic with membership as its only relation:

    BU := forall A B exists C forall y,
            y in C iff (y in A or y in B).

EPSC1 is empty-input, locally subset-bounded, supported positive closure
with one additional free matrix parameter. Bound variables and quantifier
complexity are unrestricted. Its support clause allows any preimage, not
only an active preimage.

The report proves that EPSC1 + BU interprets full extensional EPSC. Composed
with the established unrestricted closure calibration, this gives the
ordinary ZFC-formalizable consistency equivalence

    ZFC proves Con(EPSC1 + BU) iff Con(ZFC).

No separate raw Extensionality axiom or equality constructor is required.
BU can be fused into every unary instance:

    forall p (LB_rho(p) -> (BU and Hull_rho(p))).

The false-matrix instance supplies BU, while projection supplies ordinary
EPSC1. This is one recursive schema, not one first-order sentence.

The proof uses an intermediate incoming-profile Pairing sentence DP.
Exact profile singletons already follow from unary closure; BU combines
two of them into DP. Conversely, the raw Union of a DP profile pair gives
BU. Pure Pairing then permits finite parameter codes. The key transfer
targets EPSC directly, so empty activation is absolute in the hereditary
domain and no second seed/filter parameter is needed.

## What is new and what remains open

New relative to the pinned project corpus:

- A calibrated unary closure interface with the fixed BU repair, including
  a full parameter ledger and the equivalent fused schema.
- A normalized hereditary one-support interpretation showing that unary
  least exact closure, Extensionality, arbitrary finite coarse bounds,
  and even all finite membership-cycle prohibitions do not imply Pairing.
- A full-schema obstruction to deleting the support clause, allowing
  arbitrarily many matrix parameters.
- A precise AST generator for the new theory, with exhaustive finite
  encoding checks and negative controls.
- Two predecessor-specific state-deletion search families, each replayed
  at radii 4 and 6, around the existing public253 machine.

**No new complete machine below 253 working states was found.** The
253-state table in this archive is the existing attributed public machine;
the 254-state table is its baseline. No table here implements the new BU
theory. The new machine searches found zero complete deletions.

The consistency strength of **unmodified EPSC1** remains open. The
counterstructure is a deductive separation and a failure of the specified
hereditary interpretation. Its pure tagged part contains the ambient
universe, so it is not evidence for a consistency-strength separation.
It is a definable class interpretation in ZFC, not a set model whose
existence ZFC proves.

The mathematical proofs were reviewed independently within this
investigation. They are ordinary mathematics, not new Lean/Coq proof
certificates. In particular, the complete arithmetic proof-code bridge
and binary-machine/internal-Con(ZFC) theorem are not exported here.

## Read the report

`report.pdf` is the complete compiled report. Its sources are `report.tex`
and `sections/*.tex`. The main mathematical proofs are:

- `sections/unary_theory.tex`: normalized counterstructure; acyclic
  variant; unary Pairing/BU repair; hereditary interpretation and ledger.
- `sections/support_deletion.tex`: arbitrary-parameter closure after
  support is omitted.
- `sections/implementation_roadmap.tex`: concrete proof and compiler
  obligations for the proposed machine.

The report also audits the three requested commits, later formal progress,
the public253 endpoint, and the actual Foundation/Choice bridge in the
upstream proof library. All comparisons are pinned; later repository
developments may go beyond this snapshot.

## Reproduce the finite evidence

Python 3.10 or later and its standard library suffice for the default
verification. The optional search replay needs a C++17 compiler.

```sh
python3 verify.py
python3 verify.py --search
```

The verifier creates temporary copies and compares complete parsed
outputs with the retained evidence. It checks:

1. Support diagnostics: 132,096 invariant finite relations and 350,400
   prefixed-subset comparisons, with explicit controls showing that the
   rank cutoff is not a model of the full schema.
2. Theory syntax: all 530 nonempty relation structures of sizes 1–3;
   6,360 schema-instance comparisons, 1,590 fixed-axiom comparisons,
   and six malformed/out-of-interface matrix rejections.
3. Literal 253/254 tables, exact public generator reproduction, and both
   complete blank bootstraps including the entire finite tape support.
4. With `--search`, all four C++ runs, including every parsed edge option
   and the complete counters. Each family has 218 eligible deletions and
   407 incoming edges. Target-only runs test 102,564 choices; whole-action
   runs test 410,256. All four have zero complete deletions.

The finite checks diagnose their stated constructions; they do not prove
consistency by searching a finite prefix. The optional search replay uses
retained contexts. To regenerate contexts, see `machine/MACHINE_AUDIT.md`
and `machine/REPRODUCIBILITY.md`.

The measured fixed-formula tree/DAG sizes are DP 71/31 and BU 27/17.
The improvement is 44 primitive tree nodes or 14 exact named DAG nodes.
Variable-label bit lengths and compiler costs are uncharged. These are
not Turing-machine-state savings.

## Build the PDF

```sh
make report
```

The Makefile uses `latexmk -pdf` when available and otherwise runs
`pdflatex` three times. Standard TeX Live packages used are listed in
`report.tex`. Bibliographic references are included in the TeX sources;
no network or BibTeX/Biber run is needed. `make clean` removes auxiliary
TeX outputs while retaining the PDF.

`SHA256SUMS` records delivered file hashes. A later PDF rebuild can change
PDF metadata and hence its byte hash even when its rendered content is
unchanged.

## Baseline attribution and next experiment

The 254-state machine is attributed to Mira-Cult, with Jeff's Coq
verification and Andrew James Wade's compiler framework. The 253-state
reduction is attributed to mira-emmy. Selected ProveIt files and the
source-04 affine adapter retain their provenance. See `NOTICE.md`,
`machine/provenance.json`, and the bibliography for immutable source URLs.
These selected excerpts are not a complete upstream proof build tree.

The next counted comparison should hold the complete logical engine,
backend, data representation, and blank initializer fixed and compile:

1. The established EPSC2 interface.
2. EPSC1 plus a separate BU sentence.
3. The fused BU/EPSC1 schema.

Only an emitted total binary table with complete initialization and
halting-equivalence proofs should be compared as a smaller calibrated
machine. The current package gives the new theory, its proof, exact
generator reference, and reproducible negative machine evidence needed
to make that experiment concrete.
