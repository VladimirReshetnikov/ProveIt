# A113226 refined enumeration

This addendum supplies a direct record/cycle explanation of the exponential transform, an exact downset-and-isolate marking, complex-uniform all-orders coefficient asymptotics, and all-orders local large deviations for the number of distinct nonempty strict downsets. The density range is compact subsets of (0,1/2). Conditional isolated elements have a Poisson law with an explicit correction and O(n^(-2/3)) total-variation error.

## Read

- `a113226-refined-addendum.pdf`: the nine-page report
- `a113226-refined-addendum.tex`: editable mathematical source
- `refined-proof.md`: expanded companion proof
- `literature-screen.md`: attribution and bounded overlap screen
- `mathematical-review.md`: fresh independent mathematical audit and pinned proof/source hashes
- `typesetting-review.md`: report-to-proof and visual checks
- `reproduction-review.md`: replay environment, tests, and limits

The original A113226 report is unchanged. These are fixed-order Poincare expansions; no convergence of the correction series, endpoint-density theorem, or exponentially complete transseries is asserted. The direct cycle bijection does not claim an explicit map to every previously known A136127 interpretation.

## Reproduce

Python 3 with SymPy 1.14.0 and mpmath 1.3.0 is sufficient for the mathematical computations. PDF rebuilding also requires an ordinary TeX Live installation with the packages used by the source.

- `bash verify.sh`: verify hashes, regenerate both saddle algorithms, run independent direct-poset/singularity/both-saddle audits and hand-expanded second-saddle checks through b3, test the record/cycle bijection exhaustively through n=8, regenerate exact rows through n=120, and compare the recorded numerical samples
- `bash verify.sh --full --build`: repeat all exact rows through n=400 and rebuild the PDF in isolated temporary storage; verify that the PDF is byte-identical
- `bash build.sh`: rebuild the report locally
- `python refined_coefficients.py --order 3`: display and regenerate the provided first- and second-saddle coefficients; higher fixed orders are supported, with potentially increasing symbolic cost

Verification requires the complete `SHA256SUMS` manifest, uses temporary storage, and does not overwrite the release. The manifest covers every release member except itself. Numerical-output equality was checked with the pinned Python dependencies; byte-identical PDF rebuilding was checked with the TeX version in `reproduction-review.md` and is not promised across different TeX toolchains. The full n=400 validation took about four minutes in the preparation environment; runtime is machine-dependent.

## Data and algorithms

`exact_rows.json` contains A_(n,k) by n=0,...,400 and k=0,...,floor(n/2), as exact integers. `validation.json` records independent literal binary-word counts, singular expansions, moments, local-count ratios, complex-parameter comparisons, and conditional isolated means. `record_bijection_validation.json` records all 30,326 forward/inverse round trips through n=8 and exact one-cycle counts. `refined_coefficients.json` supplies corrections through order three. `root_two_saddle_audit.py/json` is a separate hand expansion of the first two marking-saddle corrections that does not import the coefficient generator. `independent_b3_audit.py/json` independently hand-expands the degree-six exponent and verifies the third correction against the recorded formula, without importing the generator.

`fresh-independent-audit.py/json` constructs actual naturally labelled posets directly through n=8, without the binary-word enumeration; independently expands both saddles through order three and the local singular coefficients; and checks the conditional correction and covariance. It imports none of the other computation modules. `root-refinement-review.md` retains the earlier pinned mathematical reviews, with the fresh review providing the final source coverage.

Finite computations verify exact identities on finite ranges and test asymptotic formulas. They do not certify finite-n remainder constants or replace the proofs. In particular, convergence can be slow toward the lower density boundary.
