from pathlib import Path
import sys,json,itertools,collections,time,hashlib
ROOT=Path(__file__).resolve().parents[1];K=ROOT/'baseline';sys.path.insert(0,str(ROOT/'code/vendor'));import source_language as s,build221 as b
base=json.loads((K/'sites215.json').read_text());old=s.tree(base);T=b.read_table((K/'k215.native.tm').read_bytes());groups,ps=b.decoder_map(T,old);states=sorted({q for q,b in T});defaults={}
for q,nodes in groups.items():
 for n in nodes:
  for bit,ch in enumerate(n):
   if s.leaf(ch)and ch[0]in('CI','CD')and T[q,bit][:2]==(bit,1):
    if ch in defaults:assert defaults[ch]==T[q,bit][2]
    defaults[ch]=T[q,bit][2]
def minimize(U):
 cls={q:0 for q in states};cls[254]=-1
 while 1:
  sig={};new={254:-1}
  for q in states:
   key=tuple((w,d,cls[z])for b in(0,1)for w,d,z in[U[q,b]])
   if key not in sig:sig[key]=len(sig)
   new[q]=sig[key]
  if len(sig)==len(set(cls[q]for q in states)):return len(sig),new
  cls=new
import argparse
ap=argparse.ArgumentParser(description='Exact finite census of 720 simple register-entry rewrites; no general minimality claim.');ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=False);results=[];start=time.monotonic();count=collections.Counter()
for v in itertools.permutations([0,2,3,4,7,8]):
 perm=dict(zip([0,2,3,4,7,8],v));U=dict(T);wanted=collections.defaultdict(set)
 for q,nodes in groups.items():
  for n in nodes:
   for bit,ch in enumerate(n):
    if s.leaf(ch)and ch[0]in('CI','CD')and perm.get(ch[1],ch[1])!=ch[1]:wanted[q,bit].add((bit,1,defaults[ch[0],perm[ch[1]]]))
 if any(len(z)!=1 for z in wanted.values()):count['conflict']+=1;continue
 for k,val in wanted.items():U[k]=next(iter(val))
 # Record literal equality separately; the complete bisimulation refinement
 # below also checks cyclic equivalences without initially identical rows.
 sigs={q:(U[q,0],U[q,1])for q in states}
 if len(set(sigs.values()))==215:count['no_identical_rows']+=1
 n,cls=minimize(U);count['min'+str(n)]+=1
 if n>=215:continue
 N=[[p,op,perm.get(arg,arg)if op in('CI','CD')else arg]for p,op,arg in base]
 try:b.decoder_map(U,s.tree(N))
 except Exception as e:count['prefix_fail']+=1;continue
 dest=out/('perm'+''.join(str(perm.get(i,i))for i in range(9)));dest.mkdir(exist_ok=True);(dest/'candidate.native.tm').write_bytes(b.table_bytes(U));(dest/'sites.json').write_bytes(s.compact(N));(dest/'partition.json').write_text(json.dumps(cls,indent=2)+'\n');results.append({'perm':[perm.get(i,i)for i in range(9)],'states':n,'path':str(dest)});print(results[-1],flush=True)
res={'recipes':720,'counts':dict(count),'survivors':results,'seconds':time.monotonic()-start,'scope':'Restricted simple register-entry rewriting, exact same-head action bisimulation only; not global lower bound.'};(out/'results.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
