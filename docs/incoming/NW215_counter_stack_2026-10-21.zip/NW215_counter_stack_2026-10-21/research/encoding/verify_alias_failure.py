#!/usr/bin/env python3
"""Independent finite replay of a rejected context-insensitive allocation.

No source compiler or inherited simulation code is imported. The conjectured
global alias is excluded by one explicit valid primitive frame. This script
does not assert anything about the rejected table's blank-tape consistency.
"""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent


def table(path):
    t = {}
    for row in path.read_text().splitlines():
        if not row or row.startswith('#'):
            continue
        q, b, w, d, z = row.split()
        key = (int(q), int(b))
        assert key not in t and d in ('L', 'R')
        t[key] = int(w), (1 if d == 'R' else -1), int(z)
    return t


def frame(pc):
    # Nine all-zero primary registers followed by one all-zero spare.
    ones = {-1, 64} | {i for i, bit in enumerate(pc) if bit == '1'}
    ones.update(range(66, 85, 2))
    return ones


def clean(q, head, ones):
    if q != 84 or head - 1 not in ones or any(i < head - 1 for i in ones):
        return False
    right = sorted(i for i in ones if i >= head + 52)
    if not right or right[0] < head + 64:
        return False
    p, last, count = right[0] + 1, max(ones), 0
    while p < last:
        if p in ones or p + 1 not in ones:
            return False
        p += 1
        while p in ones:
            p += 1
        count += 1
    return p == last + 1 and count >= 10


def replay(t, pc, bound):
    q, h, ones = 84, 0, frame(pc)
    for steps in range(bound + 1):
        if steps and clean(q, h, ones):
            return steps, q, h, sorted(ones)
        assert steps < bound, 'No terminal clean frame within bound'
        w, d, q = t[q, int(h in ones)]
        if w:
            ones.add(h)
        else:
            ones.discard(h)
        h += d
    raise AssertionError('unreachable')


def main():
    assert __debug__, 'Run with assertions enabled'
    case = json.loads((HERE / 'case.json').read_text())
    source = HERE / 'direct-transfer.sites.json'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == case['source_sha256']
    assert json.loads(source.read_text())[case['site_index']] == case['site']
    assert case['initial_registers'] == [0] * 9
    assert case['initial_spares'] == [0] and case['initial_gap'] == 0
    path = HERE / 'rejected-alias215.native.tm'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == case['table_sha256']
    t = table(path)
    assert len(t) == 430 and t[103, 0] == (0, 1, 13)
    pc, op, register = case['site']
    assert op == 'CD' and register == 6 and pc.endswith('0')
    # A zero decrement exits its enclosing left branch, then increments PC.
    parent = pc[:pc.rfind('0')]
    successor = format(int(parent, 2) + 1, '0' + str(len(parent)) + 'b')
    expected = (84, 0, sorted(frame(successor)))
    wrong = replay(t, pc, 10000)
    assert wrong[0] == 630 and wrong[1:] != expected and len(wrong[3]) == 25
    t[103, 0] = 0, 1, 108
    fixed = replay(t, pc, 10000)
    assert fixed[0] == 616 and fixed[1:] == expected and len(fixed[3]) == 22
    print(json.dumps({
        'status': 'CONCRETE_ALIAS_COUNTEREXAMPLE_PASS',
        'source_ordinal': 4560,
        'expected': expected,
        'rejected_table': wrong,
        'restored_context_entry': fixed,
        'scope': 'One valid primitive frame; not a blank-run assertion or an unbounded-runtime proof.'
    }, indent=2))


if __name__ == '__main__':
    main()
