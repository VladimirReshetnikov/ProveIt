from pathlib import Path
import json,sys
from marker_scan import parse

def run(T,q,h,cells,targetq,targeth,goal=None,limit=300):
 seen=set()
 for k in range(1,limit+1):
  if h not in cells or(q,cells[h])not in T:return None
  key=q,h,tuple(sorted(cells.items()))
  if key in seen:return None
  seen.add(key);w,d,q=T[q,cells[h]];cells[h]=w;h+=d
  if(q,h)==(targetq,targeth) and(goal is None or cells==goal):return k,cells
 return None

def main(path):
 start,T=parse(path);states=sorted({q for q,b in T});found=[];ends=[]
 for q in states:
  if q==198:continue
  for w in(0,1):
   for d in(-1,1):
    N={key:act for key,act in T.items()if key[0]!=198};N[66,0]=(w,d,q)
    out=run(N,66,0,{0:0,1:1},97,-1,{0:0,1:1})
    if out is None:continue
    ends.append((w,d,q,out[0]))
    cells={i:0 for i in range(20)}
    out0=run(N,66,0,cells,54,-1)
    if out0 is None:continue
    k,cells=out0
    if cells[0]!=1:continue
    # After old counter extension at0, arbitrary extra zero-delimited positive blocks.
    last=max((i for i,b in cells.items()if b),default=0)
    extra=''.join(str(cells[i])for i in range(1,last+1))
    found.append(dict(entry=(w,d,q),positive_steps=out[0],zero_steps=k,extra=extra))
 print(json.dumps({'path':str(path),'branch1_candidates':ends,'found':found}),flush=True)
 # State-neutral refill programs with arbitrary finite spare words.
 fills=[]
 for q in states:
  if q==198:continue
  for w in(0,1):
   for d in(-1,1):
    N=dict(T);N[198,0]=(w,d,q)
    cells={i:0 for i in range(-1,20)};cells[-1]=1
    out=run(N,198,0,cells,54,-2)
    if out is None:continue
    k,cells=out
    if cells[-1]!=1:continue
    last=max((i for i,b in cells.items()if b),default=-1)
    extra=''.join(str(cells[i])for i in range(last+1))
    fills.append(dict(entry=(w,d,q),steps=k,extra=extra))
 print(json.dumps({'fill_candidates':fills}),flush=True)

if __name__=='__main__':
 for p in sys.argv[1:]:main(Path(p))
