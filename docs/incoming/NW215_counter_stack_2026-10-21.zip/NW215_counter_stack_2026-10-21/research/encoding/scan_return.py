import sys,json
from pathlib import Path
from marker_scan import parse

def simulate(T,q,h,cells,targetq,targeth,limit=100):
 initial=cells.copy();seen=set()
 for k in range(1,limit+1):
  if h not in cells or (q,cells[h]) not in T:return None
  key=q,h,tuple(sorted(cells.items()))
  if key in seen:return None
  seen.add(key)
  w,d,q=T[q,cells[h]];cells[h]=w;h+=d
  if (q,h,cells)==(targetq,targeth,initial):return k
 return None

def scan(path):
 start,T=parse(path)
 if T is None:return
 incoming=[key for key,act in T.items()if act[2]==50]
 if incoming !=[(34,0)]:print('Unexpected',path,incoming);return
 found=[]
 for r in sorted({q for q,b in T}-{50}):
  for w in(0,1):
   for d in(-1,1):
    N={key:act for key,act in T.items()if key[0]!=50};N[34,0]=(w,d,r)
    blocks=[]
    for x in(0,1):
     cells={i:0 for i in range(7)};cells[-1]=x
     k=simulate(N,34,0,cells,75 if x==0 else 2,-2)
     if k is None:break
     blocks.append(k)
    if len(blocks)==2:found.append(dict(entry=N[34,0],durations=blocks))
 print(path,found)
if __name__=='__main__':
 for p in sys.argv[1:]:scan(Path(p))
