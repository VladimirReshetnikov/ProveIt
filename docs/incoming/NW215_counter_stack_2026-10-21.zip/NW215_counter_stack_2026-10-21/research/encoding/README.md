# Physical-allocation investigation and a concrete alias counterexample

This folder contains **failed or incomplete research**, not a 214-state candidate.
It accompanies the new machine supplied elsewhere in the main packet. All
state counts exclude the separate halt. The inspected checkout is
`a10b2c302cad2b3f3d0a4ce51022eb1ed5995acb`; its latest reported ZFC-path
commit was `2cfbb19346b234857e0cd8c8832ea1a9884c38c0`.
`PROVENANCE.json` records exact upstream paths, byte hashes, and dependencies
for this supplement.

## Exact invalid substitution

The existing global optional-row allocator was applied to the direct-transfer
source (`candidate-k215/alternatives/direct-transfer/source/st215.sites.json`,
SHA-256 recorded in `case.json`) using canonical K215 engine rows. It produced
a 215-state table and passed every complete decoder-prefix check. It nevertheless
substituted `0 R 13` for the contextual entry `103/0 = 0 R 108`.

These two states are not interchangeable at every represented source
occurrence. At source ordinal 4560, the instruction is

```
00110011101011000100 : CD6
```

Take all nine registers zero, gap zero, and spare list `[0]`. The incorrect
table reaches its first clean dispatcher frame after 630 transitions, with
25 one-cells instead of the required 22. Restoring only `103/0 = 0 R 108`
reaches the exact required frame after 616 transitions. This is a concrete
counterexample to the proposed primitive correspondence. It is **not** a
claim about the incorrect table's blank behavior.

Run the independent, standard-library-only replay from this directory:

```
python3 -B verify_alias_failure.py
```

From another directory, give the script's absolute path. Its input files are
resolved relative to the script, so the current directory does not matter.
Run all checks with assertions enabled: do not pass `-O` or set
`PYTHONOPTIMIZE` to a nonzero value.

`rejected-alias215.native.tm` is included only to make the counterexample
reproducible. The new verifier parses the literal table, constructs the whole
finite support of the input tape, executes transitions, checks the first
clean dispatcher frame, and independently computes the required zero-decrement
successor. It imports no allocator, source compiler, or inherited simulator.

This failure clarifies a proof obligation: a shared syntax node and a global
catalogue of individually valid primitive entry rows do not justify moving
those rows to a different source context. The all-natural primitive theorem
must be checked for the actual occurrence. In particular, preserved decoder
prefixes are insufficient.

## Restricted search results

Three physical-allocation models were examined on the 201-node direct-transfer
source. Its 201 count includes 178 internal source nodes and 23 distinct
primitive leaves.

| Model | Result | Scope |
|---|---|---|
| Frozen engine/helper and all contextual entry rows | Infeasible, 17,622 variables and 15,552 constraints | Restricted allocation model only |
| Optional contextual entry rows | 215 states, 20,647 variables and 316,293 constraints | Prefix pass, but the alias substitution above is invalid |
| Optional rows plus active-state variables and a 214-state cap | 120-second time limit, no incumbent; 337,150 constraints | Neither infeasibility nor a lower bound |

The exact solver receipts are included. The active-state model enforces
closure of selected states under preserved engine/provider transitions and
allows rows that have no source or engine obligation to be reassigned. Its
search was inconclusive. A separate local allocator retaining compatible old
source roles found only the 215-state allocation: seven new internal roles
use seven compatible remaining physical slots. No claim of optimality beyond
that restricted allocation is made.

Additional small local searches found no reduction: two-cell predecessor-marker
selectors for the 19 opposite-marker common-branch pairs in canonical K215;
all 856 replacements of scanner entry `34/0` after deleting state 50 while
requiring exact restoration of the known zero context within 100 steps; and
all 856 replacements of refill entry `66/0` after deleting state 198 under
the two explicit local refill/decrement exit contracts. The same screens
were run on the N/W register-exchange table. These are bounded searches over
specified local substitutions, not unrestricted nonexistence theorems.

The source language, decoder compiler, original allocation code, numerical
calibration, and K215 engine are inherited from ProveIt and its retained
upstream attributions. The active-state allocation extension, local search
scripts, concrete failure analysis, and independent finite replay are new
work for this packet. The main packet preserves the inherited licensing.

## Reproduce the optional searches

The finite alias counterexample above needs only Python's standard library.
The allocation models additionally require NumPy and SciPy (with `scipy.optimize.milp`).
Run from this directory; output paths must not already exist:

```sh
python3 -B marker_scan.py inputs/k215.native.tm
python3 -B scan_return.py inputs/k215.native.tm
python3 -B spare_search.py inputs/k215.native.tm
python3 -B allocate_frozen.py --source direct-transfer.sites.json --output /tmp/k215-frozen-new --seconds 60
python3 -B allocate_optional.py --source direct-transfer.sites.json --output /tmp/k215-optional-new --seconds 60
python3 -B allocate_active.py --source direct-transfer.sites.json --output /tmp/k215-active-new --seconds 120 --max-states 214
```

Solver timings and its choice among equally scored tables can vary. The saved
invalid table and independent concrete counterexample are the authoritative
reproducible evidence for that failure; successful regeneration of a different
allocation does not invalidate the counterexample.

The advertised allocation commands import only the included
`vendor/source_language.py` and `vendor/build221.py`; their complete data
dependencies are also included. The old standalone `build221.py` command is
not a reproduction route for this supplement: its historical K222
construction data are intentionally absent. Its original header and command
body are retained unchanged for provenance, while the allocator imports its
table and decoder helpers.

Original working paths in saved search receipts are historical provenance;
none is required by the advertised commands. The inherited engine-row census
is a synthesis filter and is not a fresh proof about the rejected table.
See `../../NOTICE.md` and `../../licenses/` for the retained licensing and
upstream notices. All inherited file bytes listed in `PROVENANCE.json` were
checked against the inspected checkout and its Git index.
