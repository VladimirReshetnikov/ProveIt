from pathlib import Path
from collections import defaultdict
import json,sys

def parse(p):
 T={};start=0
 for line in p.read_text().splitlines():
  if line.startswith('#! start '):start=int(line[9:])
  if line and not line.startswith('#'):
   xs=line.split()
   if len(xs)!=5:return None,None
   q,b,w,d,z=xs
   try:T[int(q),int(b)]=(int(w),1 if d=='R' else -1,int(z))
   except:return None,None
 return start,T

def possible(T,inc,start,q,cells,depth,cache):
 key=q,tuple(sorted(cells.items())),depth
 if key in cache:return cache[key]
 if q==start or depth==0:return True
 for (p,b),(w,d,z) in inc[q]:
  if -d in cells and cells[-d]!=w:continue
  old={i+d:v for i,v in cells.items() if i!=-d};old[0]=b
  if possible(T,inc,start,p,old,depth-1,cache):cache[key]=True;return True
 cache[key]=False;return False

def block(T,r,m,bit,end=1,limit=50):
 cells={-1:m,0:bit};original=dict(cells);h=-1;q=r;seen=set();rows=[]
 for k in range(limit):
  if h==end:return(q,k,tuple(rows)) if cells==original else None
  if h not in cells or(q,cells[h])not in T:return None
  cfg=q,h,tuple(cells.items())
  if cfg in seen:return None
  seen.add(cfg)
  key=q,cells[h];w,d,q=T[key];cells[h]=w;h+=d;rows.append(key)
 return None

def scan(p,depth=6):
 start,T=parse(p)
 if T is None:return []
 states=sorted(set(q for q,b in T))
 if len(states)not in(215,216,217):return []
 inc=defaultdict(list)
 for k,v in T.items():inc[v[2]].append((k,v))
 cache={};markers={}
 for q in states:
  for b in (0,1):
   markers[q,b]=[m for m in(0,1) if possible(T,inc,start,q,{-1:m,0:b},depth,cache)]
 found=[];almost=[]
 for bit in (0,1):
  pairs=defaultdict(list)
  for q in states:
   if q==start:continue
   if T[q,bit][:2]==(bit,1) and len(markers[q,bit])==1:
    pairs[T[q,1-bit]].append(q)
  for group in pairs.values():
   for idx,a in enumerate(group):
    for b in group[idx+1:]:
     if markers[a,bit]==markers[b,bit] or T[a,bit]==T[b,bit]:continue
     ends={markers[a,bit][0]:T[a,bit][2],markers[b,bit][0]:T[b,bit][2]}
     almost.append((a,b,bit,ends))
     for r in states:
      if r in(a,b):continue
      N={k:(w,d,a if z==b else z) for k,(w,d,z) in T.items() if k[0]!=b}
      N[a,bit]=(bit,-1,r)
      blocks={m:block(N,r,m,bit) for m in (0,1)}
      if all(blocks[m] and blocks[m][0]==(a if ends[m]==b else ends[m]) for m in (0,1)):
       found.append(dict(a=a,b=b,r=r,bit=bit,ends=ends,blocks=blocks,depth=depth))
 if almost:print(json.dumps({'file':str(p),'pairs':almost,'found':found}),flush=True)
 return found

if __name__=='__main__':
 paths=[Path(x) for x in sys.argv[1:]]
 for p in paths:scan(p)
