# Axiom-emission order and parameter-exchange census

This is a source-sharing experiment, separate from the accepted NW215 proof.
It considers seven closed emission blocks in the fixed 29-hole AX scaffold.
The block names in the script are `G,r6,r5,r4,r3,r2,r1`; `G` is the retained
combined row block. It does not mean that every gated theory-bundle operation
is freely movable.

The combined census covers all 7! block orders and all 2^7 declared row-local
B/C exchanges: 645,120 recipes. The minimum DAG count under maximum zero run
at most 6 remains 202, attained by four already known recipes, all in the
original block order. The order-only census covers 5,040 recipes; only the
original order reaches 202 and the next admissible count is 204.

These are counts within one fixed source scaffold. They are not a lower bound
for equiconsistent formalisms, a physical-state count, or a proof that every
recipe is semantically valid. Any successful new source would still need its
compiler and binary runtime proof.

From the packet root, with a new output directory:

```bash
python3 -B research/formalism/row_order_with_parameters.py \
  --source baseline/sites215.json --source-module code/vendor \
  --out ../nw215-row-order-census
```

`combined-result.json` and `order-only-result.json` are the actual recorded
results. The portable combined replay took about 34 seconds here and uses
only Python 3.10+ and the standard library.
