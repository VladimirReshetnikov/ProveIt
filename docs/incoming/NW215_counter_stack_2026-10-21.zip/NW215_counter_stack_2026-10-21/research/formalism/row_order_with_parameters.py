#!/usr/bin/env python3
import sys,json,itertools,time,hashlib,argparse
from pathlib import Path
from functools import lru_cache
ap=argparse.ArgumentParser(description='Exhaustive7! times2^7 whole-row order and B/C-register-swap census in the pinned29-hole K215 source scaffold.')
ap.add_argument('--source',type=Path,required=True)
ap.add_argument('--source-module',type=Path,required=True,help='Directory containing the inherited source_language.py')
ap.add_argument('--out',type=Path,required=True)
args=ap.parse_args()
sys.path.insert(0,str(args.source_module));import source_language as s
raw=args.source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
rows=json.loads(raw);root=s.tree(rows)
spans=[(479,888),(888,1171),(1171,1467),(1467,1766),(1766,2062),(2062,2412),(2412,2643)]
names=['G','r6','r5','r4','r3','r2','r1']
ids={};nodes=[];closure=[];stats=[]
def intern(n):
 if n not in ids:
  i=len(nodes);ids[n]=i;nodes.append(n)
  if isinstance(n[0],str):closure.append(1<<i);stats.append((0,0,0,1))
  else:
   a,b=n;closure.append(closure[a]|closure[b]|1<<i)
   la,za,da,sa=stats[a];lb,zb,db,sb=stats[b]
   stats.append((la+1,max(la+1,za,zb),max(da,db)+1,sa+sb))
 return ids[n]
@lru_cache(None)
def code(t):return intern(t if s.leaf(t) else (code(t[0]),code(t[1])))
rootid=code(root)
@lru_cache(None)
def size(t):return 1 if s.leaf(t) else size(t[0])+size(t[1])
skel=[];groups=[[] for _ in spans];holes=[]
def walk(t,lo=0):
 hi=lo+size(t)
 for j,(a,b)in enumerate(spans):
  if a<=lo and hi<=b:
   assert s.boundary(t)==(0,0,False),(lo,hi,s.boundary(t))
   groups[j].append(code(t));skel.append(('v',len(holes)));holes.append((lo,hi));return len(skel)-1
 if all(hi<=a or lo>=b for a,b in spans):
  skel.append(('c',code(t)));return len(skel)-1
 assert not s.leaf(t)
 a=walk(t[0],lo);b=walk(t[1],lo+size(t[0]));skel.append(('b',a,b));return len(skel)-1
walk(root)

@lru_cache(None)
def ren(i,k):
 n=nodes[i]
 if isinstance(n[0],str):
  op,r=n
  if k and op in ('CI','CD') and r in (3,5):r=8-r
  return intern((op,r))
 return intern((ren(n[0],k),ren(n[1],k)))
opts=[[tuple(ren(i,k) for i in g) for k in range(2)] for g in groups]
baseN=len(nodes); fixed=0
for st in skel:
 if st[0]=='c':fixed|=closure[st[1]]
varmasks=[[0,0] for g in groups]
for j in range(7):
 for k in range(2):
  for x in opts[j][k]:varmasks[j][k]|=closure[x]
print('skeleton',len(skel),'holes',len(holes),'baseN',baseN,'fixed',fixed.bit_count(),flush=True)
best=202;hits=[];hist={};tic=time.monotonic();count=0
for p in itertools.permutations(range(7)):
 for choices in itertools.product(range(2),repeat=7):
  count+=1
  mask=fixed;v=[]
  for j in p:
   k=choices[j];mask|=varmasks[j][k];v.extend(opts[j][k])
  if mask.bit_count()>best:continue
  vs=[];local={};ln=[];ls=[]
  for st in skel:
   if st[0]=='v':x=v[st[1]]
   elif st[0]=='c':x=st[1]
   else:
    a,b=vs[st[1]],vs[st[2]];n=(a,b)
    if a>=0 and b>=0 and n in ids:
     x=ids[n];mask|=1<<x
    elif n in local:x=local[n]
    else:
     x=-1-len(ln);local[n]=x;ln.append(n)
     la,za,da,sa=stats[a]if a>=0 else ls[-1-a]
     lb,zb,db,sb=stats[b]if b>=0 else ls[-1-b]
     ls.append((la+1,max(la+1,za,zb),max(da,db)+1,sa+sb))
   vs.append(x)
  t=vs[-1];cost=mask.bit_count()+len(ln);lz,zmax,depth,n=stats[t]if t>=0 else ls[-1-t]
  hist[cost,zmax]=hist.get((cost,zmax),0)+1
  if cost<=best and zmax<=6:
   if cost<best:best=cost;hits=[];print('best',cost,p,choices,depth,flush=True)
   hits.append((p,choices,t,ln,depth));print('hit',cost,p,choices,depth,flush=True)
 if count%64000==0:print('count',count,'seconds',time.monotonic()-tic,flush=True)
print('best',best,'hits',len(hits),'seconds',time.monotonic()-tic,flush=True)
@lru_cache(None)
def thaw(i):return nodes[i]if isinstance(nodes[i][0],str)else tuple(map(thaw,nodes[i]))
out=args.out;out.mkdir(parents=True,exist_ok=False)
res={'input_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Fixed29-hole scaffold, seven complete emitted axiom rows, seven independent B/C swaps; no allocation or global source lower bound.','best':best,'histogram':{str(k):v for k,v in sorted(hist.items())},'hits':[],'count':count,'seconds':time.monotonic()-tic}
for j,(p,choices,t,ln,dep)in enumerate(hits[:100]):
 @lru_cache(None)
 def unpack(i):return thaw(i) if i>=0 else tuple(unpack(x)for x in ln[-1-i])
 tr=unpack(t);rr=s.sites(tr);assert s.metrics(tr)['dag_nodes']==best
 raw=s.compact(rr);fn=f'row_order_{j:03}.json';(out/fn).write_bytes(raw)
 g=s.graph_intervals(rr);assert g==s.graph_arithmetic(rr)[0]
 res['hits'].append({'order':[names[k]for k in p],'parameters':choices,'file':fn,'sha256':hashlib.sha256(raw).hexdigest(),'metrics':s.metrics(tr)})
(out/'result.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
