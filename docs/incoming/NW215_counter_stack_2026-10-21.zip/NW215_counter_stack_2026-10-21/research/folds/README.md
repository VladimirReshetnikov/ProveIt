# Scoped two-action fold search on NW215

This is a completed negative search in a specified local proof family. It is
not a lower bound on physical states, and failure of the local proof filter
is not a counterexample to semantic equivalence.

The script examines the 202 unordered pairs of working states that share at
least one literal action. It removes the larger label, redirects incoming
edges to the smaller one, and synthesizes both outgoing actions independently.
For each pair each action has 2 write bits, 2 directions and 215 destinations
(214 surviving working states plus halt), giving 739,600 complete assignments
per pair, or 149,399,200 assignments in the declared family.

Demand-driven instantiation prunes all completions when a local diagram fails
before reaching an unassigned action. The actual run used 2,186,322 partial
checks. All 202 pairs completed and no assignment passed. The local filter
uses an all-initial-tape window overapproximation of radius 5 and searches for
positive common endpoints with a limit of 97 steps. Other invariants, larger
diagrams, different pairs, or simultaneous changes are outside this result.

`result.json` contains the complete pair list, per-pair counts, input identity,
and timing. It is a reproducible research record, not a saved rejection proof
for every assignment. The full search took approximately 129 seconds here.

`partial_filter.py` is the inherited demand-driven mechanism extracted from
ProveIt's `k219-two-row-synthesis/search.py`; `check_joint_fold.py` is the
inherited independent local relation checker. The root licenses and upstream
notices apply. `search_register_folds.py` supplies this NW215 experiment.

From the packet root, use a fresh output directory outside it:

```bash
python3 -B research/folds/search_register_folds.py \
  --table machine/nw215.native.tm --out ../nw215-fold-search \
  --radius 5 --seconds 3600
```

The generous time limit is only a run guard. Check that all 202 entries have
`status: COMPLETE` before drawing the recorded finite conclusion. Do not pass
`--all`, which selects a larger, unreported pair family. Only the Python
standard library is needed. Keep assertions enabled.
