# Demand-driven fold filter adapted unchanged from ProveIt k219-two-row-synthesis/search.py.
# Original attribution and licenses are retained in this packet.
import time
class Deadline(Exception): pass

class PartialFilter:
    def __init__(self, old, inv, keep, drop, radius, fuel):
        self.old, self.keep, self.drop, self.radius, self.fuel = old, keep, drop, radius, fuel
        self.phi = lambda q: keep if q == drop else q
        self.new = {(q,b):(w,d,self.phi(z)) for (q,b),(w,d,z) in old.items() if q != drop}
        self.new[keep,0] = self.new[keep,1] = None
        self.cache = {}
        self.patterns = {}
        for q in (keep, drop):
            for b in (0,1):
                a = sorted(m for m in inv[q] if ((m >> radius) & 1) == b)
                self.patterns[q,b] = [a[0],a[-1],*a[1:-1]] if len(a)>2 else a

    def check(self):
        old, new, phi, r, f, keep = self.old,self.new,self.phi,self.radius,self.fuel,self.keep
        for q in (keep,self.drop):
            for b in (0,1):
                w,d,z = old[q,b]
                if new[keep,b] == (w,d,phi(z)): continue
                for word in self.patterns[q,b]:
                    key = (q,word)
                    if key not in self.cache:
                        oq,oh,om = q,0,word; goals=set(); old_halts=False
                        for tick in range(f):
                            if oq==254 or not -r<=oh<=r: break
                            ob=(om>>(oh+r))&1; ow,od,oq=old[oq,ob]
                            om=(om&~(1<<(oh+r)))|(ow<<(oh+r)); oh+=od
                            goals.add((phi(oq),oh,om)); old_halts |= oq==254
                        self.cache[key] = goals,old_halts
                    goals,old_halts=self.cache[key]
                    nq,nh,nm=keep,0,word; visited=set(); joined=False
                    reason='no_join_within_filter_fuel'
                    for tick in range(f):
                        if nq==254 or not -r<=nh<=r:
                            reason='new_exits_window_before_join'; break
                        conf=(nq,nh,nm)
                        if conf in visited: reason='new_repeats_before_join'; break
                        visited.add(conf)
                        nb=(nm>>(nh+r))&1; action=new[nq,nb]
                        if action is None:
                            assert nq==keep
                            return 'need',nb
                        nw,nd,nq=action
                        nm=(nm&~(1<<(nh+r)))|(nw<<(nh+r)); nh+=nd
                        if nq==254:
                            joined=old_halts; reason='new_halt_without_old_halt'; break
                        if (nq,nh,nm) in goals: joined=True; break
                    if not joined:
                        return 'reject',{'old_row':[q,b], 'window':word, 'reason':reason}
        return 'pass',None

def synthesize(pf, actions, deadline, reject, accept):
    stat={'partial_checks':0,'rejection_leaves':0,'covered_rejections':0,'survivors':0,
          'pruned_by_assigned_count':{'0':0,'1':0,'2':0},'expected_complete_tables':len(actions)**2}
    def walk():
        if time.monotonic()>=deadline: raise Deadline()
        stat['partial_checks']+=1
        outcome, data=pf.check()
        assigned=[pf.new[pf.keep,b] for b in (0,1)]
        depth=sum(a is not None for a in assigned)
        if outcome=='reject':
            n=len(actions)**(2-depth)
            stat['rejection_leaves']+=1; stat['covered_rejections']+=n
            stat['pruned_by_assigned_count'][str(depth)]+=1
            reject({'rows':assigned,'completions':n,'failure':data}); return
        if outcome=='pass':
            # If a branch is never needed, enumerate its concrete completions.
            pending=next((b for b in (0,1) if assigned[b] is None),None)
            if pending is None:
                stat['survivors']+=1; accept(pf.new.copy()); return
            data=pending
        assert data in (0,1) and pf.new[pf.keep,data] is None
        for a in actions:
            pf.new[pf.keep,data]=a; walk()
        pf.new[pf.keep,data]=None
    try:
        walk(); stat['status']='COMPLETE'
        assert stat['covered_rejections']+stat['survivors']==stat['expected_complete_tables']
    except Deadline: stat['status']='INCOMPLETE_DEADLINE'
    return stat

