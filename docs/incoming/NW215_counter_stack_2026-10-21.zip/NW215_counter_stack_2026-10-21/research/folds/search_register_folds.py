"""Broadened two-action state-fold experiment, not an optimality proof.

Uses the predecessor's exact demand-driven action enumeration and independent
all-tape window checker. Only actually accepted diagrams establish equivalence.
"""
from pathlib import Path
import argparse, importlib.util, itertools, json, time, hashlib
from partial_filter import PartialFilter, synthesize

CHECKER = Path(__file__).with_name('check_joint_fold.py')
sp=importlib.util.spec_from_file_location('joint',CHECKER)
c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)

def encode(t,start):
    return '#! start '+str(start)+'\n'+''.join(f'{q} {b} {w} {"R" if d==1 else "L"} {z}\n' for (q,b),(w,d,z) in sorted(t.items()))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--table',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--seconds',type=int,default=240);ap.add_argument('--radius',type=int,default=5)
    ap.add_argument('--pairs',default='');ap.add_argument('--all',action='store_true');a=ap.parse_args()
    a.out.mkdir(exist_ok=False,parents=True)
    old,start=c.read(a.table);Q=sorted({q for q,b in old})
    print('invariant',a.table,flush=True);inv=c.domain(old,start,a.radius)
    if a.pairs:pairs=[tuple(map(int,p.split(':'))) for p in a.pairs.split(',')]
    else:
        pairs=[(u,v) for u,v in itertools.combinations(Q,2) if v!=start and (a.all or any(old[u,b]==old[v,b] for b in (0,1)))]
    # Register entry roles affected by the candidate are most promising.
    priority={8,127,43,72,14,56,52,176,164,201,69,213}
    pairs.sort(key=lambda p:-len(priority.intersection(p)))
    t0=time.monotonic();deadline=t0+a.seconds;results=[];hits=[]
    for keep,drop in pairs:
        pf=PartialFilter(old,inv,keep,drop,a.radius,97)
        actions=list(itertools.product((0,1),(-1,1),sorted({q for q,b in pf.new}|{254})))
        rejects=0
        def reject(record):
            nonlocal rejects
            rejects+=1
        def accept(n):
            ns=keep if start==drop else start
            try:proof=c.check(old,n,start,ns,keep,drop,a.radius,97,inv)
            except ValueError as e:proof={'status':'REJECTED','reason':str(e)}
            name=f'fold-{keep}-{drop}-{len(hits)}'
            (a.out/(name+'.tm')).write_text(encode(n,ns))
            (a.out/(name+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
            hits.append({'pair':[keep,drop],'rows':[n[keep,0],n[keep,1]],'proof':proof,'file':name+'.tm'})
            print('HIT',keep,drop,proof['status'],flush=True)
        stat=synthesize(pf,actions,deadline,reject,accept)
        stat.update(keep=keep,drop=drop)
        results.append(stat)
        if len(results)%25==0:print('progress',len(results),'of',len(pairs),'seconds',round(time.monotonic()-t0,1),flush=True)
        if stat['status']!='COMPLETE':break
    receipt={'table':str(a.table),'sha256':hashlib.sha256(a.table.read_bytes()).hexdigest(),'states':len(Q),'radius':a.radius,'fuel':97,'declared_pairs':len(pairs),'results':results,'hits':hits,'seconds':time.monotonic()-t0,'scope':'Only stated pairs and positive local diagrams. Rejection is not a semantic counterexample.'}
    (a.out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('DONE',len(results),'of',len(pairs),'hits',len(hits),flush=True)

if __name__=='__main__':main()
