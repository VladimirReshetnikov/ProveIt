#!/usr/bin/env python3
"""Small graph-separation witness and changed-row startup-use certificate.

The graph word is an abstract sequence of edge labels. No claim is made
that it is realizable as the read sequence of a blank-tape computation.
This checker uses only literal table rows, not the runtime proof engine.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path

WORD = '00000010010000000010100100'


def table(path):
    result = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, direction, z = line.split()
        key = (int(q), int(b))
        assert key not in result
        result[key] = (int(w), direction, int(z))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path,
                        default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    baseline_path = args.packet / 'baseline/k215.native.tm'
    candidate_path = args.packet / 'machine/nw215.native.tm'
    old, new = table(baseline_path), table(candidate_path)
    left = right = 0
    rows = []
    for position, symbol in enumerate(WORD):
        read = int(symbol)
        a, b = old[left, read], new[right, read]
        rows.append({'position': position, 'read': read,
                     'baseline_state': left, 'candidate_state': right,
                     'baseline_action': a, 'candidate_action': b})
        assert (a[:2] == b[:2]) == (position < len(WORD) - 1)
        left, right = a[2], b[2]
    assert len(WORD) == 26
    assert rows[-1]['baseline_state'] == 33
    assert rows[-1]['candidate_state'] == 16
    assert rows[-1]['baseline_action'] == (0, 'R', 32)
    assert rows[-1]['candidate_action'] == (1, 'L', 1)

    changed = {key for key in new if new[key] != old[key]}
    visits = collections.Counter()
    ones = set()
    q = head = 0
    for _ in range(96242):
        read = int(head in ones)
        if (q, read) in changed:
            visits[q, read] += 1
        write, direction, target = new[q, read]
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head += 1 if direction == 'R' else -1
        q = target
    assert (q, head, len(ones)) == (84, -8, 95)
    assert visits == {(8, 0): 30, (43, 0): 15, (72, 0): 12, (127, 0): 30}
    result = {
        'status': 'GRAPH_WORD_AND_CHANGED_ROW_USE_PASS',
        'baseline_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
        'candidate_sha256': hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
        'word': WORD,
        'word_length': len(WORD),
        'word_scope': 'Abstract rooted graph edge labels; not asserted to be a realizable blank-tape read sequence.',
        'path': rows,
        'changed_row_visits_in_blank_prefix': [
            {'state': q, 'read': b, 'visits': visits[q, b]}
            for q, b in sorted(changed)
        ],
        'total_changed_row_visits': sum(visits.values()),
        'blank_prefix_steps': 96242,
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    assert __debug__, 'Run without -O or PYTHONOPTIMIZE'
    main()
