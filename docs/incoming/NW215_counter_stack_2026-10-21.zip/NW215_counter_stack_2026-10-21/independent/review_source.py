#!/usr/bin/env python3
"""Independent finite audit of the N/W register-transposed K215 candidate.

This program independently reconstructs the full blank tape and validates
source conjugacy. It audits saved quantified-runtime metadata; it does not
pretend those metadata are a substitute for deriving the universal cases.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,collections

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def table(p):
 t={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  assert (q,b)not in t and b in(0,1)and w in(0,1)and d in('L','R')
  t[q,b]=(w,1 if d=='R'else -1,z)
 return t

def source_graphs(rows):
 # Prefix-arithmetic and interval-ancestor resolvers, independent of the
 # submitted source-language utility. No operand value affects a target.
 n=len(rows);leaves={p:i for i,(p,op,arg)in enumerate(rows)}
 assert len(leaves)==n and sorted(leaves)==[p for p,_,_ in rows]
 intervals={}
 for i,(p,op,arg)in enumerate(rows):
  assert p and set(p)<={'0','1'}
  for k in range(len(p)+1):
   pref=p[:k]
   if pref not in intervals:intervals[pref]=[i,i+1]
   else:intervals[pref][1]=i+1
 for pref in intervals:
  if pref not in leaves:assert pref+'0'in intervals and pref+'1'in intervals
 depth=max(map(len,leaves))
 def leftmost(p):
  expanded=p+'0'*(depth+1)
  for k in range(1,len(expanded)+1):
   if expanded[:k]in leaves:
    assert '1'not in p[k:]
    return leaves[expanded[:k]]
  raise AssertionError('no successor')
 def inc(p):return format((int(p,2)+1)%2**len(p),f'0{len(p)}b')if p else''
 def prefixcut(p,bit,count):
  positions=[i for i,x in enumerate(p)if x==bit]
  return p[:positions[-count]]if len(positions)>=count else''
 def intervalcut(p,bit,count):
  for j in range(len(p)-1,-1,-1):
   if p[j]==bit:
    count-=1
    if count==0:return intervals[p[:j]][1 if bit=='0'else 0]%n
  return 0
 a=[];b=[]
 for i,(p,op,arg)in enumerate(rows):
  if op=='CI':aa=[leftmost(inc(p))];bb=[(i+1)%n]
  elif op=='CD':aa=[leftmost(inc(prefixcut(p,'0',1))),leftmost(inc(p))];bb=[intervalcut(p,'0',1),(i+1)%n]
  elif op=='CB':aa=[leftmost(inc(prefixcut(p,'0',arg)))];bb=[intervalcut(p,'0',arg)]
  elif op=='CC':aa=[leftmost(prefixcut(p,'1',arg))];bb=[intervalcut(p,'1',arg)]
  else:assert op=='CH';aa=[];bb=[]
  a.append(aa);b.append(bb)
 assert a==b
 return a

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--packet',type=Path,default=Path(__file__).resolve().parents[1])
 ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 baseline=a.packet/'baseline';native=a.packet/'machine/nw215.native.tm'
 source=a.packet/'source/sites.json';evidence=a.packet/'evidence'
 legacy_map=a.packet/'code/vendor/native-to-legacy.json'
 old=table(baseline/'k215.native.tm');new=table(native)
 assert set(old)==set(new)and len(new)==430
 changes=[{'state':q,'read':b,'before':old[q,b],'after':new[q,b]}for q,b in sorted(new)if old[q,b]!=new[q,b]]
 assert [(x['state'],x['read'])for x in changes]==[(8,0),(43,0),(72,0),(127,0)]
 for x in changes:
  assert x['before'][:2]==x['after'][:2]==(0,1)
  assert {x['before'][2],x['after'][2]}=={14,56}
 oldrows=json.loads((baseline/'sites215.json').read_text());rows=json.loads(source.read_text())
 perm=[2,1,0,3,4,5,6,7,8]
 assert rows==[[p,op,perm[r]if op in('CI','CD')else r]for p,op,r in oldrows]
 og=source_graphs(oldrows);ng=source_graphs(rows);assert og==ng
 changed_operands=sum(x!=y for x,y in zip(oldrows,rows))
 # Replay every literal transition, retaining a dictionary with explicit
 # written zeros. The candidate author's startup reader uses a set of ones.
 state=0;head=0;cells={};trace=hashlib.sha256();steps=96242
 for tick in range(steps):
  read=cells.get(head,0);w,d,z=new[state,read]
  trace.update(f'{tick} {state} {head} {read} {w} {d} {z}\n'.encode())
  cells[head]=w;head+=d;state=z
 assert state==84 and head==-8
 ones=sorted(p for p,v in cells.items()if v)
 # Construct the target independently, using the fixed physical block order
 # r2,r8,r1,r4,r3,r7,r0,r5,r6. No decoding of the observed tape is used here.
 logical=[0,0,4,0,0,0,0,0,0];order=[2,8,1,4,3,7,0,5,6]
 gap=1;header=head+64+gap;expected={head-1,header};p=header+1
 for value in [logical[j]for j in order]+[1]*40:
  p+=1
  expected.update(range(p,p+value+1));p+=value+1
 assert ones==sorted(expected)
 record=json.loads((evidence/'startup.json').read_text())
 for k,v in [('steps',steps),('head',head),('state',state),('registers',logical),('one_cells',ones),('spares',[1]*40)]:assert record[k]==v
 recovered=[logical[perm[i]]for i in range(9)];assert recovered==[4,0,0,0,0,0,0,0,0]
 # The exact graph is total over the215 working states, with separate halt.
 states={q for q,b in new};assert len(states)==215 and 254 not in states
 assert set(new)=={(q,b)for q in states for b in(0,1)}
 seen={0};todo=[0]
 for q in todo:
  for b in(0,1):
   z=new[q,b][2];assert z==254 or z in states
   if z!=254 and z not in seen:seen.add(z);todo.append(z)
 assert seen==states
 runtime=json.loads((evidence/'runtime.json').read_text());cases=json.load(gzip.open(evidence/'runtime_cases.json.gz','rt'))
 assert runtime['status']=='PASS'and runtime['full']is True and runtime['failures']==[]
 assert runtime['table_sha256']==sha(native)and runtime['source_sha256']==sha(source)
 expected_cases=[(i,b)for i,(_,op,_)in enumerate(rows)for b in([False,True]if op=='CD'else[False])]
 assert [(c['site_index'],c['positive'])for c in cases]==expected_cases
 assert len(cases)==runtime['cases']==runtime['expected_cases']==6176
 mapping={int(k):int(v)for k,v in json.loads(legacy_map.read_text()).items()}
 for q in sorted(states|{z for w,d,z in new.values()}):
  if q not in mapping:mapping[q]=max(mapping.values())+1
 assert len(set(mapping.values()))==len(mapping)and mapping[84]==96 and mapping[254]==254
 mapped={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in new.items()}
 used={tuple(r)for c in cases for r in c['rows']};assert used==set(mapped)and len(used)==430
 for c in cases:
  assert len(c['duration'])==len(c['motion'])==13
  assert c['duration'][0]>0 and all(type(x)is int and x>=0 for x in c['duration'])
  assert sum(c['kinds'].values())==c['symbolic_steps']and set(c['kinds'])<={'literal','unary','list'}
 assert min(c['duration'][0]for c in cases)==runtime['min_duration']==6
 assert sum(c['symbolic_steps']for c in cases)==runtime['symbolic_rules']==1726978
 result={'status':'INDEPENDENT_FINITE_REVIEW_PASS','scope':'Independent literal blank replay, complete target tape construction, two source control-flow resolvers, source-register conjugacy and audit of saved universal runtime metadata. Universal cases are not rederived by this review.',
 'native_sha256':sha(native),'source_sha256':sha(source),'legacy_map_sha256':sha(legacy_map),
 'working_states':215,'literal_rows':430,'all_states_graph_reachable':True,'changes':changes,
 'source_leaves':len(rows),'changed_source_operands':changed_operands,'guarded_edges':sum(map(len,ng)),
 'permutation':perm,'blank_steps':steps,'blank_state':state,'blank_head':head,'header':header,'gap':gap,
 'logical_registers':logical,'recovered_baseline_registers':recovered,'spare_blocks':40,'one_cells':len(ones),
 'full_zero_exterior':True,'trace_sha256':trace.hexdigest(),'final_one_positions':ones,
 'runtime_cases_audited':len(cases),'runtime_rows_audited':len(used),'symbolic_rule_applications':runtime['symbolic_rules'],'minimum_positive_duration_constant':6}
 (a.out/'independent_review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
 assert __debug__, 'Run without -O or PYTHONOPTIMIZE'
 main()
