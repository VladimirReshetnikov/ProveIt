#!/usr/bin/env python3
"""Independent finite NW215 review; does not import construction/runtime code."""
from pathlib import Path
from collections import deque, Counter
import json, gzip, hashlib, sys


def read_table(path):
    t = {}
    starts = []
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        if not line or line.startswith('#'):
            continue
        q, b, w, d, n = line.split()
        key = int(q), int(b)
        assert key not in t and b in ('0', '1') and w in ('0', '1') and d in ('L', 'R')
        t[key] = int(w), (1 if d == 'R' else -1), int(n)
    assert len(starts) == 1
    states = {q for q, b in t}
    assert set(t) == {(q, b) for q in states for b in (0, 1)}
    return starts[0], t


def replay(t, start, count):
    q, h, ones = start, 0, set()
    used = Counter()
    for step in range(count):
        bit = int(h in ones)
        used[q, bit] += 1
        w, d, q = t[q, bit]
        if w:
            ones.add(h)
        else:
            ones.discard(h)
        h += d
    return q, h, ones, used


def same_graph(t, u, start_t, start_u, reflect=False):
    st, su = {q for q, b in t}, {q for q, b in u}
    pairs, back = {start_t: start_u}, {start_u: start_t}
    todo = deque([(start_t, start_u)])
    while todo:
        q, r = todo.popleft()
        for bit in (0, 1):
            w, d, z = t[q, bit]
            w1, d1, z1 = u[r, bit]
            if w != w1 or d != (-d1 if reflect else d1) or (z in st) != (z1 in su):
                return False
            if z not in st:
                continue
            if z in pairs:
                if pairs[z] != z1:
                    return False
            elif z1 in back:
                return False
            else:
                pairs[z], back[z1] = z1, z
                todo.append((z, z1))
    return len(pairs) == len(st) == len(su)


def strip(pc, bit, n):
    for i in range(len(pc) - 1, -1, -1):
        if pc[i] == bit:
            n -= 1
            if n == 0:
                return pc[:i]
    return ''


def main(packet):
    root = Path(packet)
    bstart, baseline = read_table(root / 'baseline/k215.native.tm')
    nstart, native = read_table(root / 'machine/nw215.native.tm')
    dstart, dense = read_table(root / 'machine/nw215.tm')
    assert bstart == nstart == dstart == 0
    assert set(native) == set(baseline) and len(native) == len(dense) == 430
    differences = {key: [baseline[key], native[key]] for key in baseline if baseline[key] != native[key]}
    assert differences == {
        (8, 0): [(0, 1, 14), (0, 1, 56)],
        (43, 0): [(0, 1, 56), (0, 1, 14)],
        (72, 0): [(0, 1, 56), (0, 1, 14)],
        (127, 0): [(0, 1, 14), (0, 1, 56)],
    }
    assert same_graph(native, dense, 0, 0)
    # The concrete source equality is an exhaustive certificate for conjugacy.
    old = json.loads((root / 'baseline/sites215.json').read_text())
    new = json.loads((root / 'source/sites.json').read_text())
    assert len(old) == len(new) == 4751
    changed = 0
    for before, after in zip(old, new):
        pc, op, arg = before
        expected_arg = {0: 2, 2: 0}.get(arg, arg) if op in ('CI', 'CD') else arg
        assert after == [pc, op, expected_arg]
        changed += before != after
    assert changed == 352
    # Parse the terminal frame from the independently replayed whole tape.
    q, h, ones, used = replay(native, 0, 96242)
    assert q == 84 and h == -8 and len(ones) == 95
    ordered = sorted(ones)
    assert ordered[0] == -9 and ordered[1] == 57
    header, p, values = ordered[1], ordered[1] + 1, []
    while p <= max(ones):
        assert p not in ones and p + 1 in ones
        p += 1
        length = 0
        while p in ones:
            p += 1
            length += 1
        values.append(length - 1)
    assert values == [4] + [0] * 8 + [1] * 40
    assert header - h - 64 == 1
    assert [values[i] for i in (6, 2, 0, 4, 3, 7, 8, 5, 1)] == [0, 0, 4, 0, 0, 0, 0, 0, 0]
    qd, hd, onesd, _ = replay(dense, 0, 96242)
    assert qd == 83 and hd == h and onesd == ones
    # Audit the complete saved case inventory, guard coverage, and motion law.
    records = json.load(gzip.open(root / 'evidence/runtime_cases.json.gz', 'rt'))
    wanted = [(i, positive) for i, (_, op, _) in enumerate(new)
              for positive in ((False, True) if op == 'CD' else (False,))]
    assert [(r['site_index'], r['positive']) for r in records] == wanted
    assert len(records) == 6176
    motion_cases = 0
    for record in records:
        pc, op, arg = new[record['site_index']]
        duration = record['duration']
        assert len(duration) == 13 and duration[0] >= 6 and all(x >= 0 for x in duration)
        if op == 'CH':
            continue
        if op == 'CC':
            overflow = 0
        else:
            prefix = pc if op == 'CI' or (op == 'CD' and record['positive']) else strip(pc, '0', arg if op == 'CB' else 1)
            overflow = int((int(prefix, 2) if prefix else 0) + 1 == 2 ** len(prefix))
        assert record['motion'] == [-overflow] + [0] * 12
        motion_cases += 1
    # Explicit paired-graph traversal, independent of the builder's hash method.
    index = json.loads((root / 'evidence/comparison/index.json').read_text())
    assert len(index['representatives']) == 87
    for item in index['representatives']:
        path = root / 'evidence/comparison' / item['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
        _, other = read_table(path)
        for reflect in (False, True):
            assert not same_graph(native, other, 0, item['start'], reflect)
    result = {
        'status': 'INDEPENDENT_FINITE_NW215_REVIEW_PASS',
        'working_states': 215,
        'changed_rows': [{'state': q, 'read': b, 'before': a, 'after': z} for (q, b), (a, z) in differences.items()],
        'source_occurrences': 4751,
        'changed_register_operands': 352,
        'native_dense_graph_bijection': True,
        'blank_steps': 96242,
        'head': h,
        'header': header,
        'gap': 1,
        'native_logical_registers': [0, 0, 4, 0, 0, 0, 0, 0, 0],
        'permuted_old_logical_registers': [4, 0, 0, 0, 0, 0, 0, 0, 0],
        'spares': 40,
        'spare_value': 1,
        'one_cells': 95,
        'modified_rows_executed_during_startup': {str(q) + '/' + str(b): used[q, b] for q, b in differences},
        'saved_case_inventory': 6176,
        'nonhalting_primitive_motion_cases': motion_cases,
        'distinct_comparison_representatives': 87,
        'explicit_graph_and_reflection_comparisons': 174,
        'scope': 'Independent finite literal/source/frame/motion/graph audits. This is not a second unbounded runtime proof algorithm, a kernel proof, or a proof of Con(ZFC).'
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    assert __debug__, 'Assertions required'
    main(sys.argv[1])
