# NW215: exchanging the candidate counter and proof stack

**Result: a materially different 215-working-state binary Turing machine, with a complete ordinary mathematical proof of the blank-tape consistency equivalence. No 214-state construction is claimed.**

Using the explicitly inherited primary K215 calibration, this packet establishes

    ZFC proves: not Halt(NW215, blank) iff Con(ZFC).

The new machine exchanges the physical roles of the enumeration counter N and encoded proof stack W. Its source is exactly conjugate to the accepted K215 source by the register permutation 0 <-> 2. Its literal transition graph is different: the rooted graph is not a state renaming or global tape reflection of any of 87 graph classes represented by 682 well-formed 215-state table files in the inspected comparison corpus.

Start with [report.pdf](report.pdf) for the full report, including the construction, proof, evidence boundaries, independent review, and searches toward 214 states. The editable source is [report.tex](report.tex), with its included material under `sections/`. [proof.md](proof.md) gives the candidate-specific proof in plain text.

## Exact machine and four-row recipe

The convention is one two-way infinite tape, alphabet {0,1}, blank symbol 0, initial head coordinate 0, and only L/R moves. Initialization is included in the 215 working states; the separate halt is excluded. Each table row is `state read write direction next`.

| Presentation | Working labels | Start | Dispatcher | Halt |
|---|---|---:|---:|---:|
| [Native table](machine/nw215.native.tm) | Preserved K215 labels | 0 | 84 | 254 |
| [Dense table](machine/nw215.tm) | 0 through 214 | 0 | 83 | 215 |

There are exactly 430 transition rows. All 215 working states are reachable in the finite transition graph; this does not assert that all occur on the blank run.

The native table differs from primary K215 in exactly these rows:

| State/read | Primary K215 | NW215 |
|---|---|---|
| 8/0 | 0 R 14 | 0 R 56 |
| 43/0 | 0 R 56 | 0 R 14 |
| 72/0 | 0 R 56 | 0 R 14 |
| 127/0 | 0 R 14 | 0 R 56 |

In the complete source, exchange register operands 0 and 2 in every CI/CD instruction. Exactly 352 operands change: 175 CD2, 175 CI2, one CD0, and one CI0. Paths, opcodes, and control-depth operands are unchanged. The source retains 202 distinct subtrees, 4,751 primitive occurrences, maximum address depth 47, and maximum zero run 6. The literal recipe and complete native/dense bijection are in [machine/recipe.json](machine/recipe.json) and [machine/canonicalization.json](machine/canonicalization.json).

## Proof and actual verification

The source conjugacy preserves every natural-valued register-machine step after exchanging the two coordinates. Two independent source resolvers check all 6,175 guarded nonhalting edges. The fresh binary runtime proof then connects the changed table to that source on complete tape frames.

| Obligation | Obtained result |
|---|---:|
| Arbitrary-value guarded primitive cases | 6,176 / 6,176 passed |
| Transition-row coverage | 430 / 430 |
| Symbolic inference steps | 1,726,978 |
| Minimum positive duration constant | 6 |
| Exact blank initialization | 96,242 transitions |
| Fresh portable universal replay | Every ordered case equals its saved certificate |
| Finite graph comparison | No match in 87 included rooted graph classes, also allowing tape reflection |

The runtime contracts quantify arbitrary natural primary-register values subject only to the selected guard, arbitrary natural gap, an arbitrary nonempty finite list of natural spare values, and the entire zero exterior. Their inference rules are literal transitions, induction on unary scan lengths, and finite-list induction after proving four one-block schemas from the actual table. All thirteen affine duration coefficients in every case are nonnegative, and every constant term is strictly positive. This is ordinary executable mathematical proof machinery, not a proof-assistant kernel.

The complete blank run reaches native dispatcher 84, head -8, header 57, gap 1, root PC, logical registers `[0,0,4,0,0,0,0,0,0]`, forty unit spares, and exactly 95 one-cells. Every other tape cell is zero. Under the inverse register exchange this is precisely the accepted K215 seed `[4,0,0,0,0,0,0,0,0]`. The complete startup transition trace is included, and native and dense traces are replayed independently.

The numerical-calculus/ZFC calibration is inherited from primary K215. The new source conjugacy, all-natural binary runtime, and exact startup transfer that calibration to NW215. **The packet does not contain a newly compiled Lean or Rocq endpoint for the changed table.** It does not establish unconditional nonhalting, an internal PA endpoint, or a minimum-state bound. The existing exact-table proof-assistant endpoint for primary K215 is a distinct result.

After conjugating register coefficients, primitive duration polynomials are identical in 3,028 cases, coefficientwise no larger in 3, coefficientwise no smaller in 525, and input-dependent in 2,620. All head-motion polynomials agree. This is an exact comparison of the verified certificates, not a whole-run speedup claim.

## Standalone reproduction

Python 3.10 or newer and its standard library suffice for the supported machine-verification routes. Keep assertions enabled. Run from the extracted packet root; choose a fresh output directory **outside the packet**, absent before the command.

Preferred packet entry point:

```sh
python3 -B verify.py --output /tmp/nw215-finite-new
python3 -B verify.py --runtime --output /tmp/nw215-full-new
```

The core verifier can also be invoked directly:

```sh
python3 -B code/verify_nw215.py --output /tmp/nw215-core-finite-new
python3 -B code/verify_nw215.py --runtime --output /tmp/nw215-core-full-new
```

The finite core route reconstructs the exact source and both tables, checks source conjugacy, replays the full startup in both numberings, audits every saved runtime case and its code/input pins, freshly proves the four block schemas, repeats the comparison against the 87 included tables, and recomputes the duration comparison. The `--runtime` route additionally rederives every arbitrary-value primitive contract and requires exact agreement with every saved case. Allow several minutes; the recorded portable full replay took approximately 135 seconds on the preparation machine.

No optimizer, network access, or external checkout is required for these routes. Historical exploratory scripts are separate from the supported portable entry points; some retain original research paths or optional solver dependencies. Consult the per-folder documentation before running research material. A successful finite metadata audit is not presented as a new universal runtime derivation.

To compile the report with a normal TeX Live installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Exact identities

| Artifact | SHA-256 |
|---|---|
| Native table | `3ab305e015df72b6b3a44d86de6c35006fafbd81c472e65f2fd5ba1be83505d1` |
| Dense table | `ddbc476b5adf4cb3e6e80185def895cac01434435ebffc397076ca0c9f0a38a9` |
| Complete source | `5ce313153081f56d02148ebb1a500e2257daed53b9cef4ebe7287cd0a3b27d39` |
| Startup certificate JSON | `ee3aad64c45c7e27ddde38975242a29f41a531982b192529ac19df921454f271` |
| Compressed startup trace | `7e373170e0dd629a16b38090c82c718e6056c9f5035bd024f4436507f837202d` |
| Uncompressed canonical startup JSON Lines | `77d7b81a4aee7a4431882a7a583722a13036415b6f2e7aedf541f76d654dbf1e` |

The repository checkout is pinned to [`a10b2c302cad2b3f3d0a4ce51022eb1ed5995acb`](https://github.com/VladimirReshetnikov/ProveIt/commit/a10b2c302cad2b3f3d0a4ce51022eb1ed5995acb). The latest ZFC-path commit inspected there is [`2cfbb19346b234857e0cd8c8832ea1a9884c38c0`](https://github.com/VladimirReshetnikov/ProveIt/commit/2cfbb19346b234857e0cd8c8832ea1a9884c38c0). [provenance/UPSTREAM.json](provenance/UPSTREAM.json) records exact inherited file identities and pinned URLs. The finite graph-novelty statement is limited to the inspected corpus, not a global priority claim.

## Packet map

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf`, `sections/` | Full mathematical report and editable source |
| `machine/` | Native/dense tables, exact patch recipe, reversible state map |
| `source/` | All 4,751 primitive source occurrences |
| `code/` | Portable core verifier and attributed unchanged proof helpers |
| `evidence/` | Runtime receipts, compressed cases, full startup trace, timing comparison, 87 comparison-table representatives |
| `independent/` | Separate source and binary audits and their review records |
| `baseline/` | Exact primary K215 inputs and baseline duration certificates |
| `research/` | Scoped source/formalism/encoding investigations, including searches toward 214 |
| `provenance/`, `licenses/`, `NOTICE.md` | Input pins, inherited explanations, attribution and license terms |

`evidence/portable-full.json` records the completed fresh core run with `FULL_REPLAY_PASS`. `CORE_SHA256.json` pins the core as delivered before the report and later independent-review additions; its scope is the core, not the subsequently assembled whole packet.

The source theory, compiler ancestry, partial selectors, earlier marker reductions, binary architecture, frame interface and induction engine remain attributed to their upstream contributors. The new contribution is the exact counter/stack layout change and its candidate-specific proof, verification and research evidence. See [NOTICE.md](NOTICE.md) and the retained licenses.
