from pathlib import Path
import sys,json,gzip,time,hashlib,argparse
p=argparse.ArgumentParser();p.add_argument('candidate',type=Path);p.add_argument('--limit',type=int);a=p.parse_args();root=a.candidate
K=Path('/workspace/scratch/41cbfd1a2266/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215/alternatives/direct-transfer')
sys.path.insert(0,str(K/'checks'));import symbolic_runtime as sy,independent_runtime as ir
T=ir.table(root/'candidate.native.tm');S=json.loads((root/'sites.json').read_text());mp={int(k):int(v)for k,v in json.loads((K/'inputs/native-to-legacy.json').read_text()).items()}
for q in sorted({q for q,b in T}|{z for w,d,z in T.values()}):
 if q not in mp:mp[q]=max(mp.values())+1
assert len(set(mp.values()))==len(mp)and mp[84]==96 and mp[254]==254
U={(mp[q],b):(w,d,mp[z])for(q,b),(w,d,z)in T.items()};lemmas,blocks=sy.prove_blocks(U)
rows=set();cases=[];failure=[];start=time.monotonic()
for i,site in enumerate(S):
 for pos in([False,True]if site[1]=='CD'else[False]):
  try:ans=sy.case(U,lemmas,site,pos,append=1)
  except Exception as e:
   failure.append({'i':i,'site':site,'positive':pos,'exception':str(e)});print('FAIL',failure[-1],flush=True);break
  rows.update(ans['rows']);ans['rows']=sorted(ans['rows']);ans.pop('trace');cases.append({'site_index':i,'positive':pos,**ans})
 if failure or(a.limit and i>=a.limit):break
 if i%500==0:print('progress',i,len(cases),time.monotonic()-start,flush=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
res={'status':'PASS'if not failure else'FAIL','full':not a.limit,'cases':len(cases),'expected_cases':sum(2 if op=='CD'else 1 for p,op,v in S),'sourceleaves':len(S),'states':len(T)//2,'rows_covered':len(rows),'symbolic_rules':sum(x['symbolic_steps']for x in cases),'min_duration':min([x['duration'][0]for x in cases]or[0]),'seconds':time.monotonic()-start,'table_sha256':sha(root/'candidate.native.tm'),'source_sha256':sha(root/'sites.json'),'blocks':blocks,'failures':failure}
(root/'runtime.json').write_text(json.dumps(res,indent=2)+'\n')
if not failure:
 with gzip.open(root/'runtime_cases.json.gz','wt')as f:json.dump(cases,f)
print(json.dumps({k:v for k,v in res.items()if k!='blocks'},indent=2),flush=True)
