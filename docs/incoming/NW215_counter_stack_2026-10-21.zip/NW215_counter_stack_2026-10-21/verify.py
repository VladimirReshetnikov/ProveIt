#!/usr/bin/env python3
"""Verify packet integrity, the candidate, and separately authored reviews.

Use --runtime to rederive all 6,176 universal primitive contracts. Without
that flag the saved universal case summaries are audited, not rederived.
Only Python 3.10+ and the standard library are required. Output must be a
new directory outside the packet so verification leaves the packet intact.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integrity():
    count = 0
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = ROOT / name
        assert path.resolve().is_relative_to(ROOT)
        assert digest(path) == expected, ('packet hash mismatch', name)
        count += 1
    core = json.loads((ROOT / 'CORE_SHA256.json').read_text())
    for name, expected in core.items():
        assert digest(ROOT / name) == expected, ('core hash mismatch', name)
    return {'packet_files_checked': count, 'core_files_checked': len(core)}


def run(output, label, command):
    print(label, flush=True)
    completed = subprocess.run(command, cwd=ROOT, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (output / (label + '.stdout.txt')).write_text(completed.stdout)
    (output / (label + '.stderr.txt')).write_text(completed.stderr)
    if completed.returncode:
        raise RuntimeError(f'{label} failed; see {output}')
    return completed.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output == ROOT or output.is_relative_to(ROOT):
        parser.error('--output must be outside the packet directory')
    output.mkdir(parents=True, exist_ok=False)
    hashes = integrity()
    python = [sys.executable, '-B']
    core_command = python + [str(ROOT / 'code/verify_nw215.py'),
                             '--output', str(output / 'core')]
    if args.runtime:
        core_command.append('--runtime')
    run(output, 'core', core_command)
    core = json.loads((output / 'core/verification.json').read_text())
    assert core['status'] == ('FULL_REPLAY_PASS' if args.runtime else 'FINITE_REPLAY_PASS')
    run(output, 'source_review', python + [str(ROOT / 'independent/review_source.py'),
        '--packet', str(ROOT), '--out', str(output / 'source')])
    source = json.loads((output / 'source/independent_review.json').read_text())
    binary = json.loads(run(output, 'binary_review',
        python + [str(ROOT / 'independent/review_binary.py'), str(ROOT)]))
    graph = json.loads(run(output, 'graph_witness',
        python + [str(ROOT / 'independent/review_graph_witness.py'), '--packet', str(ROOT)]))
    result = {
        'status': 'PACKET_FULL_REPLAY_PASS' if args.runtime else 'PACKET_FINITE_REPLAY_PASS',
        'integrity': hashes,
        'core_status': core['status'],
        'source_review_status': source['status'],
        'binary_review_status': binary['status'],
        'graph_witness_status': graph['status'],
        'fresh_universal_runtime': args.runtime,
        'scope': 'Ordinary executable proof and independent finite reviews; no new Lean or Rocq endpoint is claimed.',
    }
    (output / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError('Assertions must be enabled; do not use -O or PYTHONOPTIMIZE')
    main()
