#!/usr/bin/env python3
"""Portable NW215 reconstruction, finite audits, and optional universal replay.

Python 3.10+, standard library only. Run without -O. The default audits saved
universal-case metadata and replays all startup transitions. --runtime rederives
all quantified contracts using the separately attributed induction engine.
"""
from pathlib import Path
import argparse,collections,gzip,hashlib,json,re,sys,time
if not __debug__ or sys.flags.optimize:raise RuntimeError('Assertions must be enabled')
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code/vendor'))
import source_language as sl
import symbolic_runtime as sy
import independent_runtime as ir
SHA=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PIN_TABLE='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
PIN_SOURCE='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
CAND_TABLE='3ab305e015df72b6b3a44d86de6c35006fafbd81c472e65f2fd5ba1be83505d1'
CAND_SOURCE='5ce313153081f56d02148ebb1a500e2257daed53b9cef4ebe7287cd0a3b27d39'
SWAP={0:2,2:0}
PATCH=[(8,0,0,1,14,56),(43,0,0,1,56,14),(72,0,0,1,56,14),(127,0,0,1,14,56)]

def encoded(t):
 return ('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(t.items()))).encode('ascii')
def normalized(obj):return json.loads(json.dumps(obj))
def write_json(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def graph_hash(t,start=0,reflect=False):
 states={q for q,b in t};seen={start:0};todo=[start];rows=[]
 for q in todo:
  for b in(0,1):
   w,d,z=t[q,b]
   if z not in states:zi=-1
   else:
    if z not in seen:seen[z]=len(seen);todo.append(z)
    zi=seen[z]
   direction='R'if(d==1)^reflect else'L';rows.append([seen[q],b,w,direction,zi])
 return hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest(),len(seen)

def reconstruct():
 assert SHA(ROOT/'baseline/k215.native.tm')==PIN_TABLE
 assert SHA(ROOT/'baseline/sites215.json')==PIN_SOURCE
 t=ir.table(ROOT/'baseline/k215.native.tm');u=dict(t)
 for q,b,w,d,old,new in PATCH:
  assert t[q,b]==(w,d,old);u[q,b]=(w,d,new)
 assert encoded(u)==(ROOT/'machine/nw215.native.tm').read_bytes()
 assert SHA(ROOT/'machine/nw215.native.tm')==CAND_TABLE
 old=json.loads((ROOT/'baseline/sites215.json').read_text())
 new=[[p,op,SWAP.get(arg,arg)if op in('CI','CD')else arg]for p,op,arg in old]
 assert sl.compact(new)==(ROOT/'source/sites.json').read_bytes()
 assert SHA(ROOT/'source/sites.json')==CAND_SOURCE
 oldtree,newtree=sl.tree(old),sl.tree(new)
 assert sl.metrics(oldtree)==sl.metrics(newtree)=={'dag_nodes':202,'leaf_occurrences':4751,'maximum_depth':47,'maximum_zero_run':6}
 g0=sl.graph_intervals(old);g1=sl.graph_intervals(new)
 assert g0==sl.graph_arithmetic(old)[0]and g1==sl.graph_arithmetic(new)[0]
 for (effect,targets),(neffect,ntargets)in zip(g0,g1):
  want=effect[:]
  if len(want)==2:want[1]=SWAP.get(want[1],want[1])
  assert neffect==want and ntargets==targets
 assert sum(a!=b for a,b in zip(old,new))==352
 states=sorted({q for q,b in u});assert len(states)==215 and len(u)==430
 assert all((q,b)in u for q in states for b in(0,1))
 assert {z for w,d,z in u.values()}-set(states)=={254}
 m={q:i for i,q in enumerate(states)};m[254]=215
 dense={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in u.items()}
 assert encoded(dense)==(ROOT/'machine/nw215.tm').read_bytes()
 assert json.loads((ROOT/'machine/canonicalization.json').read_text())['native_to_dense']=={str(q):v for q,v in m.items()}
 g,reach=graph_hash(u);assert reach==215 and graph_hash(dense)==(g,215)
 return u,dense,new,{'status':'EXACT_SOURCE_CONJUGACY_AND_TABLE_RECONSTRUCTION_PASS','working_states':215,'rows':430,'changed_native_rows':4,'changed_primitive_occurrences':352,'source_metrics':sl.metrics(newtree),'guarded_edges':sum(len(z[1])for z in g1),'native_sha256':CAND_TABLE,'dense_sha256':SHA(ROOT/'machine/nw215.tm'),'source_sha256':CAND_SOURCE,'rooted_graph_sha256':g}

def startup(t,expected_state,expected_head,expected_ones,trace_rows=None):
 q=0;head=0;ones=set();digest=hashlib.sha256();changes=[]
 for tick in range(96242):
  b=int(head in ones);w,d,z=t[q,b];row=[q,head,b,w,d,z]
  if trace_rows is not None:assert row==trace_rows[tick],('startup trace',tick)
  digest.update((json.dumps(row,separators=(',',':'))+'\n').encode())
  if w:ones.add(head)
  else:ones.discard(head)
  q=z;head+=d
 assert(q,head,ones)==(expected_state,expected_head,expected_ones)
 return {'steps':96242,'state':q,'head':head,'one_cells':sorted(ones),'trace_sha256':digest.hexdigest()}

def audit_startup(native,dense):
 certificate=json.loads((ROOT/'evidence/startup.json').read_text())
 with gzip.open(ROOT/'evidence/startup-trace.jsonl.gz','rt')as f:trace=[json.loads(l)for l in f]
 assert len(trace)==96242
 regs=[0,0,4,0,0,0,0,0,0];spares=[1]*40
 expected={x-8 for x in ir.frame('',regs,spares,gap=1)}
 assert len(expected)==95
 a=startup(native,84,-8,expected,trace)
 m=json.loads((ROOT/'machine/canonicalization.json').read_text())['native_to_dense']
 b=startup(dense,m['84'],-8,expected)
 for k in('steps','state','head','one_cells','trace_sha256'):assert a[k]==certificate[k]
 assert certificate['registers']==regs and certificate['spares']==spares and certificate['gap']==1
 assert certificate['header']==57 and certificate['inverse_permuted_registers']==[4,0,0,0,0,0,0,0,0]
 return {'status':'EXACT_NATIVE_AND_DENSE_BLANK_PREFIX_PASS','steps':96242,'native_state':84,'dense_state':m['84'],'head':-8,'header':57,'gap':1,'registers':regs,'unit_spares':40,'one_cells':95,'trace_sha256':a['trace_sha256']}

def inputs_runtime(native):
 m={int(k):int(v)for k,v in json.loads((ROOT/'code/vendor/native-to-legacy.json').read_text()).items()}
 for q in sorted({q for q,b in native}|{z for w,d,z in native.values()}):
  if q not in m:m[q]=max(m.values())+1
 assert len(set(m.values()))==len(m)and m[84]==96 and m[254]==254
 return {(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in native.items()}

def audit_runtime(t,source):
 report=json.loads((ROOT/'evidence/runtime.json').read_text())
 cases=json.load(gzip.open(ROOT/'evidence/runtime_cases.json.gz','rt'))
 assert report['status']=='PASS'and report['full']is True and not report['failures']
 assert report['table_sha256']==CAND_TABLE and report['source_sha256']==CAND_SOURCE
 expected=[(i,p)for i,site in enumerate(source)for p in([False,True]if site[1]=='CD'else[False])]
 assert [(c['site_index'],c['positive'])for c in cases]==expected
 assert len(cases)==report['cases']==report['expected_cases']==6176
 assert report['states']==215 and report['sourceleaves']==4751
 used={tuple(r)for c in cases for r in c['rows']};assert used==set(t)and len(used)==report['rows_covered']==430
 assert sum(c['symbolic_steps']for c in cases)==report['symbolic_rules']==1726978
 assert min(c['duration'][0]for c in cases)==report['min_duration']==6
 for c in cases:
  assert len(c['duration'])==len(c['motion'])==13
  assert c['duration'][0]>0 and all(v>=0 for v in c['duration'])
  assert sum(c['kinds'].values())==c['symbolic_steps']
  assert set(c['kinds'])<={'literal','unary','list'}
 lemmas,blocks=sy.prove_blocks(t);assert normalized(blocks)==report['blocks']
 pins=json.loads((ROOT/'evidence/runtime-code-pins.json').read_text())
 for path,h in pins['files'].items():assert SHA(ROOT/path)==h,(path,'runtime code pin')
 return cases,lemmas,{'status':'SAVED_CASE_INVENTORY_AND_FOUR_BLOCK_SCHEMA_AUDIT_PASS','cases':6176,'rows_covered':430,'symbolic_rules':1726978,'minimum_positive_duration_constant':6,'all_duration_coefficients_nonnegative':True,'scope':'Case metadata and code identity audit; four block schemas freshly reproved. Full primitive derivations are rerun only with --runtime.'}

def novelty(t):
 idx=json.loads((ROOT/'evidence/comparison/index.json').read_text());want,reach=graph_hash(t);seen=set()
 for row in idx['representatives']:
  p=ROOT/'evidence/comparison'/row['file'];assert SHA(p)==row['sha256']
  v=ir.table(p);h,n=graph_hash(v,row['start']);hr,_=graph_hash(v,row['start'],True)
  assert h==row['graph_sha256']and hr==row['reflection_sha256']
  assert want not in(h,hr);seen.add(h)
 assert len(seen)==len(idx['representatives'])==87
 return {'status':'ROOTED_GRAPH_AND_REFLECTION_NO_MATCH','candidate_reachable_states':reach,'files_in_original_corpus':idx['valid215_files'],'distinct_rooted_graphs':87,'candidate_rooted_graph_sha256':want,'scope':'Exact finite comparison with the included87 representative tables; no priority claim outside the inspected corpus.'}

def timing_comparison(newcases):
 oldcases=json.load(gzip.open(ROOT/'baseline/runtime_cases.json.gz','rt'))
 assert len(oldcases)==len(newcases)==6176
 hist=collections.Counter();const=collections.Counter();sums=[0]*13;mins=[10**9]*13;maxs=[-10**9]*13;motions=True
 for a,b in zip(oldcases,newcases):
  assert(a['site_index'],a['positive'])==(b['site_index'],b['positive'])
  bd=b['duration'][:];bd[2],bd[4]=bd[4],bd[2];d=[x-y for x,y in zip(bd,a['duration'])]
  bm=b['motion'][:];bm[2],bm[4]=bm[4],bm[2];motions&=bm==a['motion']
  tag='equal'if not any(d)else'weakly_faster_all_values'if all(x<=0 for x in d)else'weakly_slower_all_values'if all(x>=0 for x in d)else'value_dependent';hist[tag]+=1
  const['decreased'if d[0]<0 else'increased'if d[0]>0 else'unchanged']+=1
  sums=[x+y for x,y in zip(sums,d)];mins=[min(x,y)for x,y in zip(mins,d)];maxs=[max(x,y)for x,y in zip(maxs,d)]
 saved=json.loads((ROOT/'evidence/duration-comparison.json').read_text())
 assert dict(hist)==saved['coefficientwise_case_classes']and dict(const)==saved['constant_term_classes']
 assert sums==saved['unweighted_sum_of_duration_coefficient_differences']and mins==saved['minimum_per_slot']and maxs==saved['maximum_per_slot']
 assert motions is True and saved['all_head_motion_polynomials_agree_under_swap']is True
 return saved

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 n,d,s,source_record=reconstruct();boot=audit_startup(n,d);rt=inputs_runtime(n);cases,lemmas,audit=audit_runtime(rt,s);nov=novelty(n);timing=timing_comparison(cases)
 result={'status':'FINITE_REPLAY_PASS','reconstruction':source_record,'startup':boot,'runtime_metadata':audit,'novelty':nov,'duration_comparison':timing}
 if a.runtime:
  tic=time.monotonic();fresh=[]
  for i,site in enumerate(s):
   for positive in([False,True]if site[1]=='CD'else[False]):
    ans=sy.case(rt,lemmas,site,positive,append=1);ans['rows']=sorted(ans['rows']);ans.pop('trace');fresh.append({'site_index':i,'positive':positive,**ans})
   if i%500==0:print('Runtime',i,len(fresh),flush=True)
  assert normalized(fresh)==cases,'Fresh ordered universal certificates differ'
  result['fresh_runtime']={'status':'FRESH_UNIVERSAL_RUNTIME_PASS','cases':len(fresh),'every_case_equals_saved':True,'seconds':time.monotonic()-tic}
  result['status']='FULL_REPLAY_PASS'
 write_json(a.output/'verification.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
