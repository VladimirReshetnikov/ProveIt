#!/usr/bin/env python3
"""Regenerate the two data appendices from the literal delivered artifacts."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    rows = {}
    for line in (ROOT / 'machine/nw215.tm').read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, direction, z = line.split()
        rows[int(q), int(b)] = w + direction + ('H' if z == '215' else z)
    assert set(rows) == {(q, b) for q in range(215) for b in (0, 1)}
    result = [r'''\begingroup
\small
\setlength{\tabcolsep}{5pt}
\begin{longtable}{@{}rll@{\hspace{0.6cm}}rll@{\hspace{0.6cm}}rll@{}}
\toprule
State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1 \\
\midrule
\endfirsthead
\toprule
State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1 \\
\midrule
\endhead
\midrule
\multicolumn{9}{r}{\small Continued on next page} \\
\endfoot
\bottomrule
\endlastfoot
''']
    for q in range(72):
        cells = []
        for offset in (0, 72, 144):
            p = q + offset
            if p < 215:
                cells.extend([str(p), r'\code{' + rows[p, 0] + '}', r'\code{' + rows[p, 1] + '}'])
            else:
                cells.extend(['', '', ''])
        result.append(' & '.join(cells) + r' \\' + '\n')
    result.append('\\end{longtable}\n\\endgroup\n')
    (ROOT / 'sections/transition_table.tex').write_text(''.join(result))

    identities = [r'''The following identities bind the mathematical text to the delivered bytes.
The packet-wide \code{SHA256SUMS} also covers the report and supplementary
files; \code{CORE\_SHA256.json} retains the original core identities.
''']
    for name in ['machine/nw215.native.tm', 'machine/nw215.tm',
                 'source/sites.json', 'baseline/k215.native.tm',
                 'baseline/sites215.json']:
        identities.append('\n\\textbf{' + name.replace('_', '\\_') + '}\n')
        identities.append('\\begin{quote}\\small\\ttfamily\n\\nolinkurl{' + sha(ROOT / name) + '}\n\\end{quote}\n')
    full = json.loads((ROOT / 'evidence/portable-full.json').read_text())
    startup = json.loads((ROOT / 'evidence/startup.json').read_text())
    assert full['status'] == 'FULL_REPLAY_PASS'
    assert full['fresh_runtime']['cases'] == 6176
    identities.append(r'''
\textbf{Recorded full replay.}
\code{evidence/portable-full.json} has status \code{FULL\_REPLAY\_PASS}.
It regenerated all 6,176 ordered universal case summaries, with every case
identical to the saved certificate. Finite independent checks are recorded
separately. The source-review trace uses a different serialization from the
core trace, so their trace digests are not expected to coincide.

\textbf{Exact terminal one-cell positions.}
After 96,242 blank transitions the head is at $-8$ and the native state is 84.
The following are all positions with symbol 1; every other tape cell is zero.
\begin{lstlisting}
''')
    positions = startup['one_cells']
    assert len(positions) == 95
    for i in range(0, len(positions), 14):
        identities.append(', '.join(str(x) for x in positions[i:i+14]) + '\n')
    identities.append('\\end{lstlisting}\n')
    (ROOT / 'sections/identities.tex').write_text(''.join(identities))


if __name__ == '__main__':
    assert __debug__, 'Assertions must be enabled'
    main()
