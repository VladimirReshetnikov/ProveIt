# Attribution and scope

NW215 is derived from Vladimir Reshetnikov's ProveIt K215 construction at the exact repository checkout recorded in provenance/UPSTREAM.json. The underlying numerical calculus, equiconsistency calibration, proof-search compiler, binary architecture, partial selectors, earlier marker reductions, source utilities, physical frame and induction engine are inherited. Original notices and licenses are retained in provenance/ and licenses/.

This contribution adds the concrete N/W physical register exchange, its four-row table recipe, exact source conjugacy, candidate-specific complete runtime replay, exact 96,242-step blank prefix, portable verifier, timing comparison, finite graph-novelty corpus and research records. It does not claim a new logical axiom system or a 214-state machine. It does not claim authorship of the inherited induction checker or proof-assistant endpoint.

The two vendor Python files symbolic_runtime.py and independent_runtime.py are byte-identical to the direct-transfer alternative's corresponding files. Their original headers are inherited historical descriptions, not claims that all packet code was newly written here. source_language.py is byte-identical to the primary K215 copy. Upstream notices credit, within their respective scopes, ProveIt and its contributors, Elliot Glazer, Jeff's busy-beaver/Rocq reference, Andrew James Wade, BusyCoq, and the Coq Library of Undecidability. The included source notices and licenses are authoritative for the inherited components.

New material follows the repository's MIT No Attribution terms. No external human endorsement, independent research-team endorsement, or global priority claim is implied by internal review and the finite comparison corpus.
