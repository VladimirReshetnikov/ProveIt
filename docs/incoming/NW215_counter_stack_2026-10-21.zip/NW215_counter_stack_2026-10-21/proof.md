# NW215: counter and stack exchange

## Result and evidence boundary

NW215 is a deterministic one-tape, two-symbol Turing machine with 215 working states, start state 0, all-zero initial tape, and a separate halt. At the same ordinary mathematical proof level as the pinned accepted K215, the construction establishes

    ZFC proves: not Halt(NW215, blank) iff Con(ZFC).

The new work establishes a source conjugacy, the exact blank startup, and a full arbitrary-value binary primitive simulation. The numerical-calculus/ZFC calibration is inherited from K215. No new Lean or Rocq endpoint and no 214-state machine are claimed. The existing proof-assistant endpoint for K215 is not silently treated as an endpoint for these changed bytes.

## Exact construction

Use the native K215 table with SHA-256

    9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2.

Replace exactly four rows:

| State/read | Old | New |
|---|---|---|
| 8/0 | 0 R 14 | 0 R 56 |
| 43/0 | 0 R 56 | 0 R 14 |
| 72/0 | 0 R 56 | 0 R 14 |
| 127/0 | 0 R 14 | 0 R 56 |

No working label is added or removed. All 215 working states are reachable in the finite transition graph from the declared start. This is graph reachability, not a claim that all occur on the blank run.

The source registers are numbered (N,T,W,A,D,H,X,Y,L)=(0,1,2,3,4,5,6,7,8). Let pi exchange 0 and 2 and fix the other seven registers. In all CI/CD leaves of the full source, replace register k by pi(k). This changes exactly 352 operands: 175 CD2 and 175 CI2 occurrences, plus one CD0 and one CI0. Paths, opcodes, and CB/CC depth arguments are unchanged. The source still has 202 distinct subtrees, 4,751 primitive occurrences, maximum address depth 47, and maximum zero-run length 6.

In the inherited physical frame, logical register k is stored at physical slot

    (6,2,0,4,3,7,8,5,1)[k].

Consequently the candidate counter is in physical slot 0 and its encoded stack is in slot 6. The baseline has those two physical roles reversed. The formula calculus and proof-search algorithm are unchanged up to this register permutation; the binary transition graph and tape layout are changed.

## Lemma 1: exact source conjugacy

For a nine-tuple r of naturals define sigma(r)_j = r_pi(j). Since pi is an involution, sigma(sigma(r))=r. Let P be the literal primary source and P' the renamed source. Source states consist of a primitive ordinal i and the nine-tuple r.

For every nonhalting primitive step,

    (i,r) -->_P (j,s) iff (i,sigma(r)) -->_P' (j,sigma(s)).

Proof. For CI_k, incrementing coordinate k and then applying sigma is identical to applying sigma and incrementing coordinate pi(k). For CD_k, both guards inspect equal natural values r_k = sigma(r)_pi(k); the zero branch agrees, and on the positive branch the decrement commutes with sigma. CB and CC do not change register values. Their source paths and depth arguments are unchanged, so their target ordinals agree. CH is unchanged. These five cases exhaust the instruction set.

The portable checker verifies the complete finite hypotheses with two independent target resolvers: binary-address arithmetic and subtree-interval/ancestor traversal. Both resolve all 6,175 guarded nonhalting edges and produce identical target ordinals. The effect operands differ exactly by pi. Induction on the length of a finite trace therefore gives a bijection of source traces, preserving their primitive length and halting. The same step correspondence also preserves infinite traces.

This lemma concerns all nine-tuples of natural numbers, without well-formedness tests or restrictions on formula codes.

## Lemma 2: all-natural binary primitive simulation

The changed table realizes P' on the inherited complete whole-tape frame. The fresh induction checker proves every one of the 6,176 guarded cases (one for each non-CD leaf and two for each CD leaf). A case quantifies arbitrary natural primary-register values subject only to the selected CD guard, arbitrary natural gap, an arbitrary nonempty finite list of natural spare values, and the entire zero exterior.

The checker performs literal transitions from the exact table. Its only acceleration rules are unary-run induction for actual self-loop scans and finite-list induction after checking the four one-block schemas on the actual rows. It records the exact affine duration, head motion, row coverage, and rule counts for every case. Each duration has thirteen coefficients, all nonnegative, and a strictly positive constant term; the smallest constant is 6. The candidate uses append-one spares.

Actual results:

- 6,176 of 6,176 cases passed, in canonical source/guard order.
- All 430 transition rows are covered.
- 1,726,978 symbolic inference steps are recorded.
- All complete tapes, dispatcher returns, register updates, and halt outcomes match the source contracts.

The complete ordered case receipts are included, and `--runtime` regenerates every case and compares the resulting mathematical data with them. The default replay only audits the saved case inventory, code pins, clocks, coverage, and input identities, and freshly proves the four one-block schemas. This metadata audit is not misrepresented as a second implementation of the whole induction engine.

Each source instruction has a finite positive binary realization. Thus a finite source halt yields a finite binary halt. Conversely an infinite source trace yields an infinite sequence of finite positive binary realizations, with no spurious halt between source boundaries. This supplies the halting and nonhalting transfer required below.

## Lemma 3: exact blank prefix

Starting in state 0 at head coordinate 0 on an all-zero tape, NW215 takes exactly 96,242 transitions to reach:

    native dispatcher = 84        dense dispatcher = 83
    head = -8                     header = 57
    gap = 1                       PC = the root
    registers = [0,0,4,0,0,0,0,0,0]
    spares = forty copies of 1
    total one-cells = 95.

The certificate gives every one-valued cell; every other cell is zero. The complete transition trace is included as compressed JSON Lines. The checker replays that trace and independently checks its last tape against the frame constructor; it also replays the dense table independently.

Applying sigma to these logical registers gives exactly [4,0,0,0,0,0,0,0,0], the accepted primary K215 source seed. In particular, the candidate value 4 is its counter, not a hidden theorem or a buried false formula. There is no change in the initial semantic store. This startup fact is essential: a global source permutation and a successful interpreter runtime proof alone need not calibrate a blank-tape machine. The N/L exchange in the predecessor research is a documented counterexample to that shortcut.

## Theorem: transfer of the consistency statement

The pinned K215 calibration identifies source halting from ordinal 0 and registers [4,0,0,0,0,0,0,0,0] with a finite ZFC refutation. Lemma 1 identifies exactly those source traces with the renamed source traces from the NW215 seed. Lemma 2 identifies their halting with the binary machine started from that complete frame. Lemma 3 supplies the finite blank prefix to the frame. Therefore

    Halt(NW215, blank) iff Halt(K215, blank).

Combining this with the accepted K215 calibration gives

    ZFC proves: not Halt(NW215, blank) iff Con(ZFC).

The proof is a combination of finite arithmetic checks and natural-number/list induction, and is formalizable in ZFC. It does not assume that ZFC is consistent. It does not prove unconditional nonhalting. Its inherited calibration boundary and the absence of a newly compiled exact-table proof-assistant endpoint are explicit.

## Material difference and timing

The rooted, action-preserving transition graph of NW215 is not isomorphic to any of 87 distinct rooted graph classes represented among 682 well-formed 215-state table files found in the two inspected ProveIt checkouts. Global tape reflection (simultaneously exchanging L and R) was allowed in this comparison. One literal representative of each class is included, and the comparison is independently rerun by the portable verifier. This is a finite corpus claim, not a global priority claim.

After conjugating the register coefficients, 3,028 primitive duration polynomials are identical to the primary, 3 are coefficientwise no larger, 525 are coefficientwise no smaller, and 2,620 have input-dependent differences. Constant terms decrease in 3 cases, increase in 525, and remain equal in 5,648. All head-motion polynomials agree under the same conjugacy. These exact certificate comparisons show that the new tape layout changes real execution costs; they do not imply a whole-run speedup.

## Reproduction and inherited material

From this packet root, with Python 3.10 or newer and assertions enabled:

    python3 -B code/verify_nw215.py --output /fresh/finite-check
    python3 -B code/verify_nw215.py --runtime --output /fresh/full-check

Each output directory must be absent before the command. No solver, network, repository checkout, or third-party Python package is required. The source and table recipes are literal; reproduction does not repeat the discovery search.

`provenance/UPSTREAM.json` pins the exact source checkout and inherited files. The source reader, frame constructor and symbolic engine remain unchanged and retain their notices. `provenance/original-runtime-driver.py` is an historical copy of the initial actual-run driver; its original absolute research paths are not a portable entry point. The command above is the supported standalone replay route.
