# A Relative Asymptotic for Adjacency-Bounded 132-Avoiders

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

The seven-page manuscript proves

    a_n^(m) ~ (n/m^2) r_m^(-n),
    p_n(m) ~ sqrt(pi) n^(5/2)/m^2 * exp(-n t_m/m),

where K_m(r_m)=1, K_m(x)=sum_{k=1}^m C_{k-1}x^k and t_m=m log(4r_m),
under BOTH conditions

    n/[m(log m)^2] -> infinity,
    n(log m)^2/m^2 -> 0.

The complete scalar root is retained in the exponent. Its first few
inverse-logarithmic terms cannot simply be substituted in this equivalent.
The scalar squared-renewal envelope equivalent itself needs only the first
condition. The second condition makes the retained-class root shift
negligible. No full fixed-m prefactor or equivalent outside this band is
claimed.

Contents:
- relative_avoider_asymptotic.pdf: complete manuscript
- relative_avoider_asymptotic.tex: editable source
- build.sh: ordinary pdflatex build, three passes
- checks/: exact primary grammar checks, independent replay, and results
- SOURCES.md: pinned source and companion attribution
- validation.json: completed validation record
- latex-build.log: final compiler transcript
- SHA256SUMS: hashes of all other package files

Run bash build.sh with a standard TeX installation containing Latin Modern,
geometry, amsmath/amssymb/amsthm, mathtools, microtype, booktabs, hyperref,
and xurl. Run both Python checks as described in checks/README.md; they
need only the standard library. External papers and third-party libraries
are not redistributed.

This is ordinary mathematical research, not formally verified or externally
refereed. Exact finite checks complement the proof and are not extrapolated
to asymptotic claims. All inherited enumerative/root inputs are credited.
