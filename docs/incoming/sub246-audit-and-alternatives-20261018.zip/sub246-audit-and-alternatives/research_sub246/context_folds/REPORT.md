# Contextual detector research against ProveIt 246

Status: complete for this research branch. No sub-246 construction established. Every launched job has reached a terminal outcome or was explicitly interrupted; no search remains active.

Pin: ProveIt `7ba1598461c6e485c5aeb8f673c0b1d571f8012b`. Baseline old-label table SHA256 `303911c554284c49ce09042d8127feba4da260baae766e32260034aa3bdb82ee`. All work is in this directory; the shared source checkout was read only.

## New positive control: a different 246-state detector

`reuse_control8.tm` has SHA256 `40136b784bc8facb44b17b9383f775d454ad86d1681d9050669c7c85271eefe7`. It replaces the eight states 6,9,13,19,29,41,58,74 by a newly synthesized tape-restoring detector, retaining every other transition.

Independent literal replay verifies all nine finite input cylinders, without reading their unspecified exterior. All 8,391 arbitrary-parameter affine instruction contracts pass, using 3,084,738 symbolic rules. All 42 protected register-induction support rows are unchanged. Blank initialization independently reaches the same complete safe root in 411,243 moves: old dispatch 96, head -5, header 176, logical primaries (3,0,0,0,3,0,0,0,0), and 167 value-one spares. The exact whole-tape endpoint is retained in `reuse_control8.bootstrap.json`.

This is a same-count control, not a smaller consistency machine. Its runtime proof transports the inherited ordinary proof through a finite, exterior-independent local substitution. It is not a new exact-machine Lean endpoint.

Reproduce its core evidence with:

- `python replay_detector.py reuse_control8.json`
- `ZFC246_BASE=$PWD/recovered/63 ZFC246_TABLE=$PWD/reuse_control8.tm python recovered/64/experiments/decoder/check_detector_bootstrap.py --output fresh-bootstrap.json`
- `python check_reuse_control.py` repeats all 8,391 symbolic instruction contracts, checks the 42 unchanged macro-support rows, and independently performs a dense literal startup whose entire tape is compared against the baseline safe root.

## New stronger caller invariant

`verify_deeper_entry_guard.py` freshly checks all 8,391 symbolic instruction cases, including 191,434 entries into state 6. It retains the existing universal partition:

- The right-hand cells +1,+2 are 0,1.
- Either the first leftward one is at distance k in 0..7, or cells -8..0 are all zero.

The new assertion-checked refinement is:

- k=6 implies cells +3..+12 are all one.
- k=7 implies cells +3..+13 are all one.
- The long case implies at least one zero in cells +3..+13.

There are 92 k6 entries, 36 k7 entries, and 21,316 long entries. The proof is symbolic over arbitrary numerical register parameters, with the inherited unary/list macro-induction dependencies. It is not inferred from the unique blank computation or finite register samples. `deeper_entry_guard.json` contains the new certificate summary and patterns. `fresh_entry_cylinders.json` independently replays the inherited partition.

The fixed 96→111→130→150→172→204→113→132→125→147 chain can inspect the long right-one runs, but its last two writes clear two ones. Merely using it does not preserve the scanner contract; any successful use must repair those writes or justify a different complete simulation interface.

## New contextual repair families

Delete 74, and replace 58/read0 by 0L84 or 0R84. Then allow one arbitrary additional row mutation among rows encountered during a 5,000-rule symbolic rejection trace of the critical decrement case `111010010010000000`, retaining the 42 protected macro rows. Each action ranges over both bits, both moves, and 245 retained targets. A candidate reaching the complete existing instruction target would be checked against all 8,391 cases.

- L84 family: 67 eligible rows ×980 actions =65,660 recipes;66,609 checks; zero survivors. Rejections: 9,743 fuel,55,639 unsupported affine operations,278 missing actions. Runtime 77.74seconds.
- R84 family: 64 rows ×980 actions =62,720 recipes;62,826 checks; zero survivors. Rejections: 9,526 fuel,52,288 unsupported,906 missing. Runtime 75.92seconds.

`repair_short_scanner.py` and `repair_short_scanner_right.py` reproduce them. JSON summaries and full rejection journals are retained. A row not encountered in the rejecting prefix cannot alter that prefix. Nevertheless, a cutoff or unsupported operation is only a failure of this explicitly bounded proof search, not a semantic impossibility result. The two families overlap, so their recipe counts are not a distinct-table census. A second worker also replayed the R84 family; that is the same family, not another research contribution.

## New SAT synthesis workflow

`synthesize_detector_cnf.py` is a direct one-hot CNF encoding, rather than the previously used bit-vector multiplexing SMT encoding. It supports 7 free suffix states, fixed existing helpers, arbitrary restored borrowed bits, exact spatial footprints, and a literal macro time bound. `replay_cnf_detector.py` independently replays successful models and can install their free transitions into the unchanged baseline.

Dependencies installed under `vendor/`: python-sat 1.9.dev16, z3-solver 5.3.1.0. Typical invocation:

`PYTHONPATH=vendor python synthesize_detector_cnf.py --states 7 --steps 16 --helpers 4,2,20,10,14,7,48,63 --borrow-left 1 --borrow-right 2 --solver kissat404 --output result.json`

The JSON `options` records preserve the exact family parameters.

Positive controls with 8 free states pass independent literal replay, including all 36 assignments of two arbitrary borrowed-right bits. A 7-state 8-step control is UNSAT. A larger 7-state template, with 8 fixed helpers and all 68 inputs covering two arbitrary right bits and one arbitrary left bit, is UNSAT at 12 steps in 25.68 seconds (Kissat). This is a solver result for that finite template, not a proof of a global lower bound. Longer generic jobs produced no candidate; interrupted and timed-out jobs are UNKNOWN, never UNSAT. All are now terminal.

`synthesize_contextual_detector.py` additionally uses the stronger source-specific invariant. Its 19 cylinders are: six short cases whose right exterior remains unread; k6 and k7 with their guaranteed right-one runs; and 11 long cases partitioned by the first rightward zero. Existing 84 may be used internally in a short case while remaining a valid long return, and the 96 one-chain is available as unchanged helpers. Out-of-family helper branches are rejected, not changed in the actual machine. Its 8-state control passes all 19 literal cylinders. The no-prefix 7-state 64-step job timed out after 1,200 seconds with UNKNOWN. The first-zero-write-one variant timed out after 800 seconds with UNKNOWN. The first-four-states-fixed variant is UNSAT in 100.89 seconds. Both use the first-return discipline described below.

## Obligations before claiming a 245-state consistency machine

1. Obtain a complete total binary table on 245 working states, preserving the separate halt convention.
2. Independently replay every finite local cylinder, checking all borrowed assignments, exact tape restoration, and no exterior reads. Fixed helper transitions must remain the literal baseline rows; rejected unused helper branches are not replacements for them.
3. Compose the local substitution with the checked universal caller invariant and unchanged register/selector contracts. A complete source-level simulation is required; a finite blank trace is not a substitute.
4. Find and verify a new blank startup into a calibrated safe root, checking the entire tape. The old initializer cannot be assumed to survive a runtime transformation.
5. State the actual ordinary proof, formalization base, and exact-table theorem status. The requested equivalence is nonhalting iff Con(ZFC), provable in ZFC. No unconditional nonhalting, Con(ZFC), or completed Lean/PA endpoint is claimed here.


## Restoration-aware refinement and source-path helpers

The initial CNF templates freeze at the first matching return state/head and then require exact tape restoration. Positive models are sound, but their UNSAT results cover this first-return discipline only. `synthesize_contextual_restoring.py` instead defines termination by the entire required configuration, so a dirty intermediate visit to state 84 may continue and be repaired. Its eight-state control passes independent literal replay of all 19 cylinders. With seven free states, the first four scanner states fixed, 19 existing helpers, and 64 literal moves, the broadened family is also UNSAT (111.79 seconds; 2,832,496 clauses).

A second source path may be useful for future constructive designs: entering old84 at the hard k7 leftmost one follows 96,110,33,47,27,32,45,21,30,42, fills cells -3 through +1 with ones, then returns through 2,4 and the free scanner states. The unmodified scanner reaches its correct short exit with five dirty cells, so this is not a valid replacement by itself. `synthesize_contextual_sourcehelpers.py` exposes these nine additional existing states and uses constant-specialized helper clauses. The positive eight-state control passes independent replay. The seven-state, 64-step, first-five-states-fixed template is UNSAT in 8.16 seconds. The first-four-fixed variant is also UNSAT in 129.00 seconds (2,128,037 clauses).

## Exact fixed-prefix, arbitrary-last-state search

`search_last_detector_state_cycles.cpp` and `search_last_detector_state_wide.cpp` delete 74, preserve the first six scanner states, and replace both rows of 58 by any action targeting any of the 245 retained working states. There are 980 actions per row and 960,400 ordered row pairs. Unlike the bounded SAT helpers, every existing state is available. Exact repeated configurations are rejected; all completed runs below had zero fuel cutoffs. They are finite-window local impossibility results for this narrowly fixed-prefix family, not global state lower bounds.

The affected inputs are k6, k7, and 11 long cylinders. The other six short cases return before reaching the modified state. Arbitrary extra cells on both sides are universally quantified and must be restored, while reads outside the specified finite window are rejected.

- No borrowed cells: 968,424 checks; 959,377 exterior-read, 19 missing-state, and 1,004 exact-cycle rejections.
- Two cells on each side, all 208 cylinders: 1,088,795 checks; 956,075 exterior-read, 1,040 missing-state, and 3,285 exact-cycle rejections.
- Four cells on each side, all 3,328 cylinders: 3,014,555 checks; 951,797 exterior-read, 1,226 missing-state, and 7,377 exact-cycle rejections.

There are zero survivors in every family. The Python implementation `check_last_state_search.py` independently repeats the complete two-cell family without any fuel bound, obtaining exactly the same rejection counts; maximum observed execution is 695 moves. Its different input ordering gives 1,088,828 checks. The four-cell independent Python replay also obtains exactly the same rejection counts, with 3,014,720 checks and maximum observed execution 761 moves. Neither Python replay uses a fuel bound.

These runs overlap heavily: they are successive broadenings of the same 960,400 recipes, not 2,881,200 distinct machines.


## Folds against the new same-count control

`search_reuse_control.py` applies the inherited protected-row fold harness to the newly synthesized, fully validated `reuse_control8.tm`, not the original or source64 alternate table. All 42 induction-support rows remain fixed. The 1,000-rule symbolic proof-search cap is explicit:

- Uniform: 54,390 recipes and 122,810 case checks; zero survivors.
- Mixed: 49,702 recipes and 579,399 case checks; zero survivors.

Both families completed in 122.58 seconds in total. `reuse_control_fold_search.json` records all per-group counts and rejection classes. As with the inherited harness, unsupported affine operations and fuel failures are not mathematical impossibility results.
