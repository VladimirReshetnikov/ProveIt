# Pinned predecessor material

Repository: [VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt)

Commit: `75716498437bfc7291d5900cab2983a11fd54bac`

The following copied exposition is unchanged. Relative links inside it retain their upstream meaning and may require the pinned repository tree.

| Local file | Pinned upstream file |
|---|---|
| `README-upstream.md` | [candidate-k215/README.md](https://github.com/VladimirReshetnikov/ProveIt/blob/75716498437bfc7291d5900cab2983a11fd54bac/Computability/BusyBeaver/Research/ZFC/candidate-k215/README.md) |
| `proof-upstream.md` | [candidate-k215/proof.md](https://github.com/VladimirReshetnikov/ProveIt/blob/75716498437bfc7291d5900cab2983a11fd54bac/Computability/BusyBeaver/Research/ZFC/candidate-k215/proof.md) |
| `command-calibration-upstream.md` | [candidate-k216/alternatives/permuted/proof.md](https://github.com/VladimirReshetnikov/ProveIt/blob/75716498437bfc7291d5900cab2983a11fd54bac/Computability/BusyBeaver/Research/ZFC/candidate-k216/alternatives/permuted/proof.md) |
| `dominated-calibration-upstream.md` | [candidate-k218/alternatives/dominated/proof.md](https://github.com/VladimirReshetnikov/ProveIt/blob/75716498437bfc7291d5900cab2983a11fd54bac/Computability/BusyBeaver/Research/ZFC/candidate-k218/alternatives/dominated/proof.md) |

The main source and table are copied from `candidate-k215/sites215.json` and `candidate-k215/k215.native.tm`. The comparison tables come from `candidate-k215/alternatives/commands120/` and `candidate-k215/alternatives/composed/`. Their exact identities are recorded in the independent review and main manifest. The compressed baseline runtime-case data is used only for the explicit duration comparison.

The packet is self-contained for the new construction, binary runtime derivation, and finite independent review. It cites, rather than reproducing in full, the predecessor compact-calculus consistency development. The main claim adopts that already accepted ordinary calibration theorem explicitly.
