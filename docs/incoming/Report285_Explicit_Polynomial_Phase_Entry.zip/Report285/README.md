# Report 285 Explicit Entry for Polynomial Phase Endpoint Stability

This report answers the numerical-entry and singly-exponential-radius question `q:entry` in upstream source 55. It quantitatively implements the Eisner–Tao near-extremizer method and retains source 55's sharp parity-sensitive coefficients.

For d >= 2, q = 2^d, every nontrivial finite abelian group G, and |f| <= 1, let epsilon = 1 - ||f||_(U^d)^q. If epsilon <= 10^(-d), then

D_d(f) <= (2/q) epsilon + b_d(G) epsilon^2 + 3q^3 epsilon^3,

where D_d is squared normalized L2 distance to degree-at-most d-1 circle-valued phase polynomials (including nonclassical phases), and b_d(G) is (3^d-1)/(2q^2) in odd order or (1-q^(-2))/3 in even order. The exact smaller cubic constant is in the article. The local certificate radius is at least q^(-5/2).

## Contents and mathematical status

- `article.tex` and `Report285.pdf`: complete proofs, attribution, limitations, and further questions
- `companion/exact_checks.py`: exact reproducible diagnostics, deterministic JSON
- `tests/test_companion.py`: mathematical/API/provenance regression tests
- `build.py` and `tests/test_build.py`: bounded offline compilation and deterministic packaging with regression tests
- `provenance/source_manifest.json`: immutable source identities and archive provenance
- `provenance/sources/source55_article.tex`: byte-exact upstream article, retained as source evidence
- `provenance/sources/source55_audit.md`: byte-exact historical upstream source audit
- `SOURCES.md`: source roles and provenance explanations
- `MANIFEST.sha256`: SHA-256 manifest covering every public file except itself

The quartic census, bounded-complex fifth cancellation, sharp first two coefficients, local absorption/inversion scheme, and sharpness examples are imported from source 55 and reproved. The refinements are the explicit correlation-preserving entry argument and convex interpolation remainder. The result is not a new qualitative inverse theorem, not a global Szemeredi improvement, and not Lean-verified. No publication-priority claim is made. Finite diagnostics do not replace the arbitrary-degree and arbitrary-group proofs.

## Reproduce

Use Linux, Python 3.11 or newer, and a TeX Live installation providing pdfTeX, Latin Modern fonts, geometry, amsmath, amssymb, amsthm, mathtools, aliascnt, microtype, booktabs, array, longtable, xcolor, enumitem, fancyhdr, hyperref, and cleveref. Python code uses only the standard library. It requires Linux no-follow file handles and `/proc/self/fd`; unsupported platforms fail closed rather than weakening source/output guards.

From this directory:

    python3 -I -B -X int_max_str_digits=640 build.py verify
    python3 -I -B -X int_max_str_digits=640 companion/exact_checks.py
    python3 -I -B -X int_max_str_digits=640 tests/test_companion.py
    python3 -I -B -X int_max_str_digits=640 tests/test_build.py
    python3 -I -B -X int_max_str_digits=640 build.py reproduce --output /tmp/report285-fresh-build

The output directory must be fresh, empty, outside the source tree, and not an ancestor of it. Do not put logs, bytecode, temporary files, or extra source files in this distribution: its exact inventory is checked. The build performs all checks normally and under `-O`, requires byte-identical stdout, stages immutable snapshots, compiles three TeX passes with shell escape disabled, and creates a deterministic ZIP and detached SHA-256 pin. `--no-zip` skips only ZIP creation. `package` requires an already manifest-pinned distribution.

PDF bytes can depend on the TeX toolchain. The distributed toolchain output is pinned; a mismatch is reported rather than silently repinned. PDF and ZIP reproducibility were verified in two fresh directories with the same toolchain. Source hashes are checked before and after every check and build stage.

The no-follow checks, file and output caps, safe output handling, environment allowlist, and disabled shell escape are defense in depth, not a general sandbox for arbitrary hostile TeX. Compile only trusted pinned source in an appropriately isolated runtime.

## Diagnostic interpretation

The fixed diagnostic suite checks:

- Final constants for d = 2 through 30, with exact low-degree radius exceptions and golden values
- All 5,580 three-vertex configurations in binary cubes of dimensions 2 through 5, using explicit unimodular minors, plus the four-vertex circuit census
- All 280 triple joint laws in dimension 3 across Z/2, Z/3, Z/4, (Z/2)^2, and Z/2 x Z/3
- Six exact cocycle integrations, including nonclassical quadratic and cubic phases on Z/2, with wrong-sign correction controls
- Six good-direction completion examples and six polar-reduction cases including zero amplitudes
- Seven exact convex-interpolation examples with genuinely nonzero fifth and sixth terms, and all 32 conjugation patterns in a fifth-moment witness
- Exact Fourier/near-extremizer witnesses and the two pinned source snapshots

All mathematical checks are exact within their declared finite domains. JSON records the actual ranges, cases, and outcomes. Such checks can expose transcription, constant, conjugation, and implementation errors. They cannot establish an inequality for every finite abelian group, substitute for the small-cocycle proof, or certify publication novelty.
