# Depths five and six for OEIS A290268

This report completes two previously open strata of the coefficient nonvanishing problem for derivatives of x^(x²), and improves the general fixed-depth cutoff.

## Proven results

For d=5 or 6, k≥0 and M≥d, the coefficient gamma(k,d,M)=[w^M](2+w)^k((1+w)^2 log(1+w))^d is zero exactly when M=k+4d+1 and k+d is even. The separate structural zeros M<d remain explicit.

- Depth 5: practical cutoffs R=410,Q=839, leaving 343151 finite cells and 204 prescribed symmetry holes
- Depth 6: practical cutoffs R=1571,Q=3048, leaving 4785360 cells and 785 prescribed holes
- Every depth d≥3: a global affine minorant gives positivity whenever the relevant mean exceeds the largest residual root
- General cutoffs Q_d=ceil((2d+1)e^d),K_d=2Q_d reduce each fixed depth to O(d²e^(2d)) finite obligations. The fully integer alternative is Q_d=(2d+1)3^d,K_d=2Q_d

The current ProveIt source already supplies the quadratic Jensen criteria and a finite certificate through derivative order 3000. This note credits those inputs. Its contribution is the certified practical cutoffs, exact mean seeds, completion of the two infinite strata, and sharper general reduction. The full conjecture and the remaining finite obligations at depths 7 and above are not solved.

## Contents

- `article.pdf` and `article.tex`: complete research report and editable source
- `verify_depth5.py`, `depth5_certificate.json`: centered recurrence over exact integers
- `independent_pascal_depth5.py`, corresponding JSON: distinct Pascal modular verification, including independent exact moment seeds
- `verify_depth6_columns.cpp`, `depth6_column_certificate.json`: centered recurrence modulo 1000003 and 1000033
- `independent_pascal_depth6.py`, corresponding JSON: distinct Pascal modular verification and exact moment seeds
- `build_local.sh`: PDF build wrapper

The mathematical proof, including both analytic reductions, has received an independent mathematical check. Every PDF page has been rendered and visually inspected. The report is not formally verified in Lean or externally refereed. Its scope and source-relative contribution are explicit.

## Reproduce

The Python scripts use only the standard library and raise errors on failed checks. Run from the extracted folder:

```
python verify_depth5.py
python independent_pascal_depth5.py
python independent_pascal_depth6.py
g++ -O2 -std=c++17 verify_depth6_columns.cpp -o verify_depth6_columns
./verify_depth6_columns
```

The Python scripts rewrite their own JSON verification outputs; retain a copy if comparing results. The depth-five integer report includes runtime, which varies between machines. The digests and exact rational seeds are deterministic.

Compile `article.tex` twice with pdfLaTeX on a standard TeX distribution. `build_local.sh` additionally handles the local format/map setup used during preparation.

## Source anchor

The precise inspected report is Part 3 of “Term counts in the derivatives of power towers,” commit ca81647a9f679e96d49ffdbc54b0c0ab13d10a36. Its Section 3.24 Questions 1–3 provide the exact context for this continuation. Source links appear in the PDF bibliography. Literature checking was targeted, not exhaustive; no worldwide priority claim is made.
