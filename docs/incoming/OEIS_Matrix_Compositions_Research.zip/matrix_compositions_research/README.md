# Matrix compositions: finite spectra, uniform asymptotics, and two Poisson limits

Research report prepared for Vladimir Reshetnikov, 3 October 2026.

## Main files

- `matrix_compositions.pdf`: the complete article.
- `matrix_compositions.tex`: the editable LaTeX source.
- `scripts/verify.py`: offline exact, symbolic, and high-precision verification.
- `results/verification.json`: actual verification results and computed constants.
- `results/a261784_exact.txt`: independently computed terms a(0) through a(200).
- `results/*.csv`: numerical comparison data, including both Poisson regimes.
- `provenance/SOURCES.md`: attribution, inspected sources, and limits of the priority audit.
- `OEIS_updates_draft.txt`: draft mathematical suggestions, NOT submitted.

## Mathematical contents

The report proves the two statements explicitly labeled conjectures in the inspected
OEIS A261781 entry: minimal eventual constant-coefficient recurrence order k(k+1)/2
and the limit of successive growth-constant differences. It strengthens the latter
with strict monotonicity. The proof uses the already published rational generating
functions; those foundations are not claimed as new.

The principal additional development is a uniformly controlled finite Stirling
kernel. It leads to all fixed algebraic orders on compact rays n/k in (1,infinity),
a Poisson limit for an auxiliary transform defect, and an exact expression for the
prefactor in the posted A261784 asymptotic. A separate argument proves the zero-row
Poisson transition at n/k = log k + O(1), including a first correction and a finite
all-orders prescription. Smooth inverse models and integer threshold brackets are
kept distinct.

The leading A261784 growth rate and decimal prefactor were already in OEIS. The
report supplies proofs, a closed prefactor, and higher corrections. Priority for
all additional uniform results is NOT established by the bounded literature search;
in particular a related paper by Louchard was identified but not retrieved.

## Reproduce the calculations

The scripts were tested with Python 3.13. Install the packages in `requirements.txt`,
then run from this directory:

```sh
python scripts/verify.py --max-m 200
python scripts/make_tables.py
python scripts/make_figures.py
```

`verify.py` uses no network access and can be launched from any working directory.
The default computation took approximately 16 seconds in the preparation environment;
runtime elsewhere can differ. The checks include all triangle entries 0 <= k <= n <= 40
against an independent generating-function computation, eight reduced-denominator
checks, the exact kernel recurrence through n=80, and exact symbolic kernel coefficients.
It compares against eight displayed OEIS triangle rows and fifteen displayed diagonal
terms. It does NOT claim a full comparison of all 201 computed terms against the OEIS
b-file. Numerical evaluations use 90 decimal digits but are not interval enclosures.

`make_tables.py` expects verification through at least m=200 to rebuild the article's
selected tables. The article and supplied tables can be used without rerunning any
Python code.

## Build the PDF

Use a TeX installation providing `newtx`, `amsmath`, `amsthm`, `mathtools`, `microtype`,
`geometry`, `booktabs`, `hyperref`, `bookmark`, `fancyhdr`, and `enumitem`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error matrix_compositions.tex
pdflatex -interaction=nonstopmode -halt-on-error matrix_compositions.tex
```

Run a third pass when cross-references change after edits. All local input files and
the figure PDF are supplied. No external full-text articles or font files are included.

## Proof status and boundaries

The manuscript contains human-readable mathematical proofs, not a Lean formalization
or a peer-reviewed publication. Exact finite tests support the proofs but do not replace
them. All-orders expansions mean every fixed truncation order, not a convergent infinite
series or a complete exponentially small transseries. Compact-ray results do not silently
extend to n/k near 1 or infinity. The transform defect is an auxiliary random variable,
not an asserted intrinsic statistic on unadorned matrices.

No repository files were changed and no OEIS edits were submitted.

An optional additional check is `python scripts/ray_spotchecks.py`. It regenerates
`results/ray_spot_checks.csv`, testing the general saddle formula at ratios 3/2,
3 and 5. This is separate from the main verification JSON and uses 75-digit working
precision.
