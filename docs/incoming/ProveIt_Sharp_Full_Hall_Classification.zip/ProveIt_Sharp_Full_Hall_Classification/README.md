# A sharp weighted classification of full Hall bottleneck graphs

Research report dated 1 October 2026, prepared for Vladimir Reshetnikov.

## The result

A full Hall graph has complete edges between its two core blocks, complete edges from each exterior block to the opposite core, and no exterior-to-exterior edges. For this precise family:

- If either core has at most two vertices, every assignment of positive vertex activities gives matching-rank-normalized ultra-log-concavity
- If both cores have at least three vertices, explicit finite exterior populations and a common positive integer core activity violate the last normalized inequality
- In the genuine two-by-s rank regime, every inequality is strict

The positive proof is uniform in s. It covers independently weighted vertices, not just constant block activities. The report includes exact finite counterexample parameters for every large-core shape and a rank-five example with nonreal roots but strictly positive normalized margins.

This does not classify arbitrary graphs with a two-plus-s cover. General weighted rank five, the unit-weight question, and the one-shore-only question remain open here. No global priority or Lean-certification claim is made.

## Proof and files

The positive argument compares with the core-deleted disjoint bicliques. Twelve possible coefficient families exhaust the difference of the Newton margins. A readable proof of every case is printed in `article.pdf` and its editable source `article.tex`.

- `increment_families.py`: independently extracts the twelve formulas from support-coefficient products
- `verify_formulas.py`: checks all printed formulas and key exact identities
- `prove_families.py`: an independent symbolic sign proof using Newton bounds and multilinear-box corners, including denominator and boundary checks
- `compare_finite_tables.py`: confirms that the generic formulas recover all 49 rank-five and 80 rank-six finite orbit coefficients
- `regression_rank5_orbits.json`, `regression_rank6_orbits.json`: those exact finite regression tables
- `verify_negative.py`: checks the explicit construction on all 324 core-size pairs from 3 through 20, using the original support coefficient formula
- `verify_separation.py`: reconstructs the positive-ULC/nonreal-root example, its exact discriminant and its four margins
- `*_verification.json`: recorded exact check results
- `requirements.txt`: the symbolic algebra dependency
- `build_local.sh`: optional TeX Live fallback wrapper; a normal installation can run `pdflatex article.tex` twice

## Reproduce

Run, from this directory:

    python3 verify_formulas.py
    python3 prove_families.py
    python3 compare_finite_tables.py
    python3 verify_negative.py
    python3 verify_separation.py

All checks use exact integers, rational functions or rational arithmetic. The uniform theorem follows from the written proof, not from finite sampling. The scripts audit its algebra and boundary bookkeeping.

No repository changes, publication, or external sharing are included in this package.
