# Marked-Tree Stability
## Complete apex-neighborhood classification, exact enumeration, and optimal repair

Research prepared for Vladimir Reshetnikov, 30 September 2026.
Mathematical development and exposition with ChatGPT.

## Contents

- `article.pdf`: the 24-page research article.
- `article.tex`: complete LaTeX source, including bibliography and TikZ diagram.
- `code/marked_trees.py`: exact recognition, weighted enumeration, maximum-weight selection, and nearest-neighborhood repair.
- `code/verify.py`: reproducible exact finite checks.
- `results/verification.json`: machine-readable results from the delivered run.
- `results/run.log`: the corresponding console output.
- `SOURCE_AUDIT.md`: source pin, inspected sections, and the prior/new-result boundary.
- `requirements.txt`, `build.sh`: dependencies and build instructions.
- `SHA256SUMS.txt`: checksums of the delivered files other than the checksum list itself.

## Main results

Let T be a finite nonempty tree and S an arbitrary subset of its vertices.
Construct the bipartite incidence graph of T, and add one apex adjacent exactly to S.
The Boolean matching-support polynomial counts a feasible endpoint set once, not once
per matching witness.

For nonempty S, let K be the minimal subtree spanning S. Stability holds exactly when
every vertex of degree at least three **in K** belongs to S, and the tree H on S obtained
by suppressing K's unmarked degree-two vertices is a finite or affine ADE tree.
The empty marking is stable. The matrix criterion is I - A_H/2 positive semidefinite.
Unmarked fringe outside K is irrelevant to this structural criterion.

The article proves an exact connected-set covariance existence/uniqueness theorem,
a host-level determinant--adjugate identity, and explicit rational Rayleigh failure
certificates. The at-most-four-leaf structure of stable hulls yields a disjoint weighted
endpoint formula, exact O(n^5) arithmetic algorithms for enumeration and signed-score
optimization, and exact minimum-cost apex-edge repair.

If alpha_st(T) is the maximum number of marks in a stable neighborhood, then

    diameter(T) + 1 <= alpha_st(T) <= min(n, diameter(T) + 3).

The polynomial Z_T(t) counting **stable neighborhoods by their cardinality** is real-rooted
if and only if T is a path. This must not be confused with the support polynomial of one
fixed neighborhood. Even log-concavity and unimodality of Z_T can fail, as proved on stars.

## Status and scope

This is an unrefereed, AI-assisted research article, not a Lean/Rocq formalization.
The all-size claims rest on the written proofs. Finite tests are supporting evidence
and implementation checks, not substitutes for those proofs. Worldwide priority is
not certified. The prior full-apex ADE theorem, terminal-subdivision theorem, and odd-theta
obstruction are explicitly credited to the pinned ProveIt report. The arbitrary-marking
completion, endpoint counting and optimization, diameter window, and neighborhood-polynomial
classification are the continuation developed here.

The article does not classify all stable bipartite graphs, and does not settle the separate
question of real-rootedness of every individual full-apex tree support diagonal.
Eight further research questions distinguish these directions.

## Reproduce the computation

The delivered run used Python 3.13.5, NetworkX 3.6.1, and SymPy 1.14.0.
The pinned NetworkX version requires Python >= 3.11, excluding Python 3.14.1.
A Python 3.13 environment matches the delivered interpreter family.

```sh
python -m pip install -r requirements.txt
python code/verify.py --max-n 9 --output results/verification.json
```

The verifier itself makes no network calls. The seed for integer test weights and signed
scores is 20260930. The recorded run covers 31,886 marked instances on 95 unlabelled tree
representatives of sizes one through nine. Markings related by an automorphism of a tree
are intentionally counted separately: the enumerator counts subsets, not marked-tree
isomorphism classes.

Highlights of the executed checks:

- 21,237 exact PSD comparisons and 10,649 explicit unmarked-branch witnesses.
- 133 complete small-order determinant identities, comprising 24,534 exact minor coefficients.
- 190 exact endpoint-enumerator comparisons with exhaustive stable-subset sums.
- 285 signed-score optimization comparisons and 95 nearest-repair comparisons.
- Two rational rank-one-adjugate certificates, including a subdivided tree with fringe.

The counting and optimization reference enumerations use the structural classification.
They do not constitute independent analytic stability tests. The incidence-cofactor checks
independently enumerate matching supports in the stated small orders.

## Use the algorithms

Run from the package root:

```python
import sys
from fractions import Fraction
import networkx as nx

sys.path.insert(0, "code")
from marked_trees import (
    recognize,
    stable_polynomial,
    maximum_weight_stable,
    nearest_stable,
)

T = nx.star_graph(5)           # center 0; leaves 1 through 5
initial = {1, 2, 3, 4, 5}

print(recognize(T, initial).stable)   # False: an unmarked hull branch
print(stable_polynomial(T))          # [1, 6, 15, 10, 10, 5, 0]
print(nearest_stable(T, initial))     # minimum distance 2, and one optimizer

scores = {v: Fraction(v - 2, 3) for v in T}
value, selected = maximum_weight_stable(T, scores)
assert recognize(T, selected).stable
```

`stable_polynomial` returns coefficients in increasing degree order, always as a vector
of length n+1; trailing zero coefficients are retained. Optional weights are a mapping
with exactly one integer or `fractions.Fraction` value per vertex. The optimizer accepts
signed integer or rational scores. Floating-point weights/scores are rejected to preserve
exactness. Tree validation rejects directed graphs, multigraphs, disconnected graphs,
cycles, and empty hosts. Public functions accept NetworkX-compatible vertex labels.

The implementation is a clear reference prototype, not a heavily optimized large-instance
solver. Its conservative polynomial bound does not make enumeration of all quadruples
practical for arbitrarily large n. Ties between optimizers are resolved by traversal order.

## Rebuild the article

A TeX installation with pdfLaTeX and the standard packages named in `article.tex` is needed.
No bibliography download or external image asset is required.

```sh
sh build.sh
```

The script uses a local `build/` directory and copies the finished PDF to `article.pdf`.
Rebuilding changes PDF timestamps; it is not intended to reproduce the original PDF bytes.
The delivered PDF was rendered and visually inspected, with no unresolved references or
LaTeX box warnings in the final build. No font files or third-party paper PDFs are included.
No GitHub repository file was modified.
