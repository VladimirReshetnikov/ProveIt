# K219: a 219-state ZFC consistency machine

This packet constructs an explicit **219-working-state, two-symbol, one-tape
Turing machine** whose blank-tape nonhalting is provably equivalent in ZFC to
`Con(ZFC)`. The complete proof and transition table are in
[report/report.pdf](report/report.pdf); editable LaTeX starts at
[report/report.tex](report/report.tex).

The machine uses a two-way infinite tape, blank symbol 0, only L/R moves,
and a separate terminal outcome. Its **canonical working states are 0–218,
start is 0, dispatch is 23, and halt is 219**. The canonical table has exactly
438 transition rows. Initialization is included in those 219 working states.
The native table retains inherited labels: start 0, dispatch 84, halt 254.

## The breakthrough

The successful construction preserves the calibrated calculus and replaces
its generic equality routine. It shares an **open subtree** between
counter cancellation and cleanup. Its continue has a useful meaning in both
surrounding contexts. The complete source shrinks from 208 to 206 distinct
DAG nodes, while retaining 4,744 primitive occurrences.

Write `D_i = CD(i)`, `C_j = CC(j)`, `B = CB(1)`, and `(X,Y)` for a source
pair. The replacement is the following shared program:

```text
P = (D_6, C_2)
U = (P, B)
A = (D_5, U)
L = (A, D_6)
Z = (D_5, C_1)
R = (Z, U)
E = (L, R)
```

The report proves, for every pair of natural values and every surrounding
register state, that both the original routine and `E` terminate, clear
registers 5 and 6, preserve all other registers, and return normally exactly
when the original values were equal. Otherwise they return one break. All
four equality occurrences are replaced; the rest of the source is identical.

Two machine-level ideas make the source saving usable:

* State 108 shares its old `CB1` leaves, whose codes end in `001`, with the
  new `CC2` leaves, whose codes end in `101`. Its new read-one action toggles
  the distinguishing earlier bit. The direct decrement entry is already
  present in state 21.
* A single new return state handles the zero guard of a decrement in a right
  child, and the new routine's break exits. An exact three-transition bypass
  preserves the increment return and its original spare-one convention.

The count is `220 - 3 + 2 = 219`: delete states 102, 120, and 121; add 301
and 302. Exactly eight retained rows change:

| Native state / read | K220 action | K219 action |
| --- | --- | --- |
| 87 / 0 | `0 R 21` | `0 R 301` |
| 87 / 1 | `1 R 102` | `1 R 21` |
| 88 / 0 | `0 R 45` | `0 R 122` |
| 103 / 0 | `0 R 122` | `0 R 108` |
| 103 / 1 | `0 L 162` | `0 L 302` |
| 108 / 1 | `0 L 40` | `0 L 10` |
| 113 / 0 | `0 L 40` | `0 L 302` |
| 198 / 0 | `1 L 198` | `1 L 40` |

The added rows are `301: (0 R 45, 1 R 103)` and
`302: (0 L 4, 0 L 302)`, with the two actions ordered by read bit.

## Proof and verification

The correctness argument has four components:

1. **Source theorem:** an all-natural proof of both equality routines' exact
   open-tree contracts, followed by terminating contextual substitution.
2. **Literal runtime:** all **6,167 guarded primitive interfaces** were freshly
   proved for the exact table with the unchanged pinned symbolic engine.
   The derivation uses **1,515,040 symbolic rules**, with a minimum constant
   duration of 13 machine steps. It quantifies arbitrary primary register
   values, extra gap, first spare value, and remaining finite spare list.
3. **Blank startup:** independent sparse and dense simulations verify the
   complete tape at **312,617 transitions**, with dispatch 84 / canonical 23,
   head −5, header 139, gap 80, original logical seed
   `[3,0,0,0,3,0,0,0,0]`, and 130 spares all equal to one. There are exactly
   277 one cells; all other cells are zero.
4. **Logical calibration:** the pinned K220 construction and its recursive
   predecessors connect the unchanged source search to finite ZFC refutations.

These compose to give, internally in ZFC,

```text
Halt(K219, blank) <-> Halt(K220, blank) <-> not Con(ZFC).
```

The new endpoint is an **ordinary mathematical proof with executable symbolic
certificates**, formalizable in ZFC. It is not a newly compiled Rocq or Lean
theorem for the exact K219 bytes. The argument does not assume `Con(ZFC)`;
it does not prove unconditional nonhalting or claim that 219 is minimal.
The macro proof is supplied in writing; the source builder verifies its exact
literal substitution and does not pretend to kernel-check that theorem.

All 438 rows occur in the symbolic usage receipt, and all 219 working states
are reachable in the transition graph. Neither statement asserts that every
row or state occurs on the single blank run. The startup endpoint is the
certified blank-PC program entry, not the first intermediate redispatch.

## Reproduce offline

Use Python 3.10 or newer with the standard library, keeping assertions enabled.
From this extracted directory:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k219-replay
```

The output directory must initially be empty. The default command replays the
pinned predecessor's construction and calibration, reconstructs the source
and literal table, checks canonicalization and the whole blank initialization,
freshly proves every final symbolic interface, and independently audits its
receipt. It requires no network, repository clone, optimizer, or proof assistant.
The successful endpoint is **`FULL_K219_REPLAY_PASS`**.

The default uses authenticated, audited runtime certificates for predecessor
machines. Add `--full-baseline` to rederive those inherited runtimes recursively.
For an audit of the stored final runtime instead of a fresh derivation, use
`--quick`; its endpoint is `QUICK_K219_REPLAY_PASS`.
The stored `cases.json` is a compact guard/duration/rule-count receipt, not a
complete standalone proof trace. Default mode regenerates the derivations.

Build the PDF with a conventional TeX Live installation:

```sh
bash report/build.sh
```

The full canonical table appendix is generated directly from `machine/k219.tm`.
PDF metadata and pagination can vary with TeX versions; the machine bytes are
pinned independently.

## Packet contents

| Path | Contents |
| --- | --- |
| `machine/k219.tm` | Complete canonical 438-row table |
| `machine/k219.native.tm` | Same machine in inherited native labels |
| `machine/sites219.json` | Exact source tree as ordered primitive leaf paths |
| `machine/canonicalization.json` | Label bijection and complete blank tape support |
| `machine/decoder_allocation.json` | Source roles, shared states, and all source prefixes |
| `portable/` | Deterministic construction, runtime proof, audit, and replay |
| `portable/vendor/` | Exact K220 predecessor archive, including its predecessors |
| `portable/reference_results/` | Fresh final runtime receipt and all guarded case summaries |
| `verification/` | Construction, independent development audits, and release replay evidence |
| `report/` | Main PDF, editable LaTeX, sections, table generator, build script |
| `research/theory/` | Formalism/codec report and full four-valued HC countermodel |
| `research/experiments/` | Portable bounded calculus/codec experiments and original receipts |
| `research/encoding/` | Equality discovery code, finite diagnostics, and independent startup audit |

A noncomment machine row is `state read_bit write_bit L_or_R next_state`.
`#! start 0` identifies the start. The halt label has no outgoing rows.

## What the formalism search established

The research appendix attacks the logical side as well as the machine side.
It gives a four-valued model over the hereditarily countable sets for a family
of restricted fourth-parameter versions of the propositional single axiom,
while retaining the full native seed-K schema and support clause. ZFC proves
consistency of these weakened systems, even with identity, ex-falso, and the
K combinator added. Thus, assuming ZFC is consistent, those restricted systems
cannot have the requested ZFC-provable consistency equivalence.

The archive also records safe existence/equality-helper fusion, nested
fourth-field input encoding, alternate complete propositional bases, binder
arithmetic, constructor tags, and Cantor-field orientations. Their bounded
measurements did not improve the certified machine. The reports distinguish
logical theorems, source measurements, raw compiler outcomes, and validated
machine interfaces. They do not turn failed searches into lower bounds.

## Exact identities and provenance

The immediate parent is `docs/incoming/K220_Construction_2026-10-20.zip`
from ProveIt revision `5c5d7611a93bf043402d5f740af24f2f00f2edee`.
The newer K220 alternatives at `bf01dd349a0e2a4cef109cb911ce228c81639aa9`
were inspected as well. The accepted construction uses the exact parent
archive, not a moving branch or an older tracked candidate directory.

| Artifact | SHA-256 |
| --- | --- |
| Pinned K220 archive | `132cbb326fcbf6e54957a03095c5f790e207f4ed8ebfb6ceb6e272f329e4ee00` |
| Native K219 table | `b255f8ee341d394c303d67a7fca7f8288ed9d4c40f075899fa64b13085aaca26` |
| Canonical K219 table | `02079501e6255951cbc1c31d2c3cab076574d3d61c892f0e5a541cd1789442ec` |
| Source sites | `0f6d9d991e36dda1a7449edab72a799bb2d8c3de3ff853a26178b89bd1bc8789` |
| Guarded-case summaries | `91298163a933b10d57fb5a5ecd0b76b60db6e76fcd85282d730ab52b93d0efb4` |

`MANIFEST.sha256` covers the packet files other than itself. The portable
subdirectory also has an exact-inventory JSON manifest checked before replay.
