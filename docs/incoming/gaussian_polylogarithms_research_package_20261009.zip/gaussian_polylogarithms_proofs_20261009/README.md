# Gaussian polylogarithms: proofs, reductions, and exact certificates

Research companion for the ProveIt manuscript, dated 9 October 2026.

**Read the article:** `gaussian_polylogarithms_proofs.pdf`.

**Source baseline:** `VladimirReshetnikov/ProveIt` commit
`09812e81e578c3f13f54b2d0c46a95a0e0665b19`, under
`Analysis/Polylogarithms/docs/manuscript`.

## Main results

- All five displayed Gaussian weight-six double identities are proved, with their original coefficients unchanged. Two exact derivations are included: the depth-two parity functional equation and an independent differential recurrence with exact double-zeta boundary data.
- All seven corresponding Gaussian weight-eight imaginary double identities are given and proved. A rational Bernoulli coefficient formula handles every even weight.
- All three displayed Gaussian weight-four triple identities are proved. A general classical formula handles every position of one index 2 among indices 1, at every weight. Together with the all-ones formula, it reduces the top two possible series-depth layers.
- The highest-weight half-Gaussian coefficient in that family is the signed binomial coefficient `(-1)^(N+a) binomial(N-1,a)`. This proves an upper bound of one imaginary direction modulo the specified lower-weight products.
- At the primitive sixth roots, the transformed argument is the same root. The complete one-2 family therefore reduces to single values at that root; its real component at even weight, or imaginary component at odd weight, is a rational multiple of `pi^N`.
- All four proposed Gaussian/Eisenstein mixed-root directions reduce exactly to existing single-value constants. They do not justify the source's claimed new numerical directions.
- A Hölder decomposition gives exact rational certificates with an explicit complex-modulus error bound. Its guaranteed cutoff is linear in requested precision plus weight. A separate finite-nested-sum implementation replays the centers and radii exactly.
- The article proves a nonzero mixed-color diagonal antisymmetry, supplies the correct `Li_{3,3}(i,i)`, and corrects a reversed shifted-polygamma parity comment and the missing order-one exceptions.

The general parity theorem, classical height-one reducibility, and Hölder
convolution are established prior work and are credited in the article.
The contributions are proof upgrades, explicit extensions, mathematical
audit results, and reproducible certificates relative to the pinned source.
No assertion of numerical independence or global bibliographic priority is
made for the remaining constants or the individual displayed identities.

## Package contents

| Path | Purpose |
|---|---|
| `gaussian_polylogarithms_proofs.tex`, `sections/`, `references.tex` | Complete modular article source |
| `gaussian_polylogarithms_proofs.pdf` | Compiled article |
| `code/holder.py` | Standard-library exact arithmetic in `Q(i)`, Taylor recurrence, tail bounds, rational intervals |
| `code/identities.py` | Exact symbolic formulas and checks of the eight original rows |
| `code/verify.py` | Regenerates the main coefficient tables and rational enclosure evidence |
| `code/replay_certificates.py` | Replays every saved rational center by an independent finite nested sum |
| `code/run_independent.py`, `code/independent/` | Independent symbolic derivations, moment quadratures, direct series, and source correction checks |
| `results/` | Exact coefficient data, certificates, rigorous residual bounds, and numerical-check receipts |
| `figures/`, `code/make_figure.py` | Branch-path and permitted-alphabet diagram and its source |
| `corrections/proposed_corrections.diff` | Reviewable patch against the pinned two manuscript chapters |
| `INTEGRATION.md`, `CLAIM_STATUS.md` | Integration pointers and logical status of each result |
| `provenance.json`, `SHA256SUMS.txt` | Pinned input hashes, runtime versions, literature, and artifact checksums |

## Reproduce the results

Python 3.12.14 was used for the recorded run. The exact certificate and
replay modules use the Python standard library; symbolic checks also need
SymPy. The independent numerical scripts use mpmath. Tested versions are
listed in `requirements.txt`.

```sh
python3 -m pip install -r requirements.txt
python3 -B code/verify.py --bits 384
python3 -B code/replay_certificates.py
python3 -B code/run_independent.py --quick
python3 -B code/run_independent.py
```

The core run checks 58 formula comparisons: 28 double parity components,
28 one-2 imaginary components, and the two Gaussian mixed corrections.
At 384-bit atom precision the largest certified absolute residual bound
is at most `3.6465827e-114`. All 75 named certificate records have been
independently replayed exactly. The strict positivity of the mixed
antisymmetry and both components of the diagonal stuffle example are
checked separately.

The full independent runner checks all 24 real/imaginary one-2 rows at
weights 4–6, all 12 displayed parity rows, all four mixed corrections,
112 moment comparisons, 30 direct-series comparisons, five separately
transcribed formulas, 15 shifted-polygamma checks, and 160 exact cases
of the uniform radius prescription. The original independent JSON
results are preserved under `results/independent/*/reference/`.

The separate sixth-root extension can be reproduced with:

```sh
python3 -B code/independent/one_two/sixth_root.py
```

All scripts locate their input and output paths relative to their own
files, work from other current directories, and require no network
connection once the dependencies are installed.

### Build the PDF

A TeX Live installation with pdfLaTeX, latexmk, Latin Modern, AMS packages,
mathtools, mathrsfs, microtype, geometry, booktabs, enumitem, fancyhdr,
xcolor, xurl, and hyperref is sufficient. The figure PDF is already
included. No BibTeX or external bibliography service is needed.

```sh
make pdf
```

To regenerate the diagram as well, install `requirements-figures.txt` and
run `make figures`. The build products go in `build/`; the final PDF is
copied to the package root. `make all` builds the article and runs the
core verifier and replay. `make independent` runs the full independent
cross-checks; `make quick` runs the shorter exact checks.

## Certificate interpretation

Each record certifies

`abs(prefactor * G(word; 1) - center) <= radius`.

Here `prefactor` is exactly `1` or `-1`, `center` is a pair of rational
real/imaginary coordinates, and `radius` is an exact rational number.
The center already includes the prefactor. The GPL convention is
outermost letter first with kernel `dt/(t-a)`. The MPL series uses
decreasing indices and prefix-product letters. The article defines
the conversion precisely.

The atom labels `G` and `beta_n` name the imaginary coordinate used from
a certificate for the full complex `Li_n(i)`. A half-Gaussian certificate
similarly supplies both `mu_n` and `lambda_n`. The exact word is the
authoritative target definition. Decimal displays are for convenience;
all authoritative bounds and coefficients are rational strings.

An interval containing zero does not prove a transcendental identity.
The written functional identities prove equality; exact coefficient
checks and independent enclosures verify the implementation and the
displayed coefficients. Numerical quadrature residuals in the independent
directory are cross-checks, not rigorous quadrature error bounds.

## Integration

The proposed companion location is a new report directory under
`Analysis/Polylogarithms/docs/reports/`. The package root can be copied
there intact. `INTEGRATION.md` lists theorem labels and the source
correction locations. Check the patch before applying it:

```sh
python3 code/check_source_patch.py /path/to/ProveIt
```

This command checks pinned file hashes and patch applicability. Applying
the patch is a separate action described in `INTEGRATION.md`. No remote
repository changes were made while preparing this package. The remaining
formal relation matrices and claimed dimension counts require their own
exact recomputation; the article proposes a detailed sequence for that work.
