LOCAL GEOMETRIC CODES AND TOPOLOGICAL ARITHMETIC
Partial exponentiation, interval discontinuities, and a canonical
countable arithmetic core

Research manuscript prepared with ChatGPT

OVERVIEW

This package develops a local refinement of Elliot Glazer's topological
Tennenbaum argument, motivated by the arithmetic-coding and Polish-model
research in Vladimir Reshetnikov's ProveIt repository.

The main theorem assumes a model M of bounded induction (I Delta_0) with
a Polish carrier and Borel addition and multiplication. A single fixed
pair of internal parameters is assumed to code a geometric progression
E(0) = 1, E(i+1) = q E(i), for q >= 2 and indices through C. Every
externally uncountable arithmetic interval [b,d] contained in [0,C]
then contains an a for which multiplication by E(a), as a map on the
whole carrier, is discontinuous. Total exponentiation is not assumed.

The article also identifies a canonical countable initial submodel:
N_M consists of the elements with externally countable predecessor
intervals. Classical results on Borel orders show that N_M is countable;
bounded arithmetic shows that it is a Delta_0-elementary initial model
of I Delta_0. If multiplication is separately continuous, every length
of every internally coded geometric progression, across all bases
q >= 2, belongs to this same core. Further conclusions concern fixed-base
endpoint graphs, Borel code certificates, convex sets of continuous
multipliers, and the distinction between local and total exponentiation.

The manuscript contains complete conventional proofs, a construction of
models with an externally long local code but without total exponentiation,
a discussion of an ATR_0 upper bound for the local argument with explicit
coding interfaces, and a proposed research agenda. Global Borel-order
consequences are treated in ordinary ZFC, separately from that upper bound.

FILES

  local_geometric_codes.tex
      Complete, editable LaTeX manuscript with an inline bibliography.

  local_geometric_codes.pdf
      Typeset article.

  README.txt
      This introduction and reproduction instructions.

  SOURCE_AUDIT.txt
      Source provenance, the pinned repository snapshot, the prior
      project question, and the scope of the novelty search.

  PROOF_STATUS.txt
      Mathematical status, verification performed, and unresolved limits.

  verify_local_arithmetic.py
      Reproducible finite diagnostics for explicit arithmetic identities
      and integer bounds used in the proof.

  local_arithmetic_diagnostics.json
      Recorded output from the diagnostic script.

BUILD THE PDF

From the directory containing the TeX file, run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error local_geometric_codes.tex

Alternatively, run this command three times to resolve the table of
contents and cross-references:

  pdflatex -interaction=nonstopmode -halt-on-error local_geometric_codes.tex

A normal TeX Live or MiKTeX installation with the packages named in the
source preamble is sufficient. The manuscript has an inline bibliography
and no external graphics. It needs no bibliography database, network
access, or shell-escape operation to compile.

REPRODUCE THE FINITE DIAGNOSTICS

With Python 3.10 or later, run:

  python3 verify_local_arithmetic.py rerun_local_arithmetic_diagnostics.json

The script uses only the Python standard library. The optional output
argument above preserves the supplied diagnostic record. The recorded
run used seed 20261004 and passed 14,953 assertions. Its scale cases use
c near 2^512, 2^1024, 2^2048, and 2^4096; those exponents are generation
parameters, not the exact bit lengths of c.

READING AND STATUS

Begin with the introduction, main results, and arithmetic-code definitions.
The proof then isolates bounded arithmetic, descriptive set theory, the
complete-metric fusion, and the Baire-category contradiction. The later
sections explain consequences, boundaries, metatheory, and open questions.

The contribution is a proposed research result with written proofs and
in-session independent reviews. Bibliographic priority has not been
established, and there has been no external peer review or Lean/Rocq
certification. The local theorem answers an explicit-code direction of a
prior ProveIt question; it does not settle the existence of an uncountable
Borel Polish I Delta_0 model with separately continuous multiplication.
It also does not identify the coded domain with every ordinary definition
of partial exponentiation. See the two accompanying status notes for the
precise distinctions.
