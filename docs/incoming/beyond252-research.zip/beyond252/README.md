# Beyond 252

Research prepared for the ProveIt project, 17 October 2026.

**No machine with fewer than 252 working states is established in this packet.**
The report gives two positive mathematical ideas, two concrete alternative
255-state tables, and reproducible searches and audits. It does not claim a
new Lean/Coq endpoint or a serialized proof in the object-level ZFC calculus.

Read [report.pdf](report.pdf) for the complete argument. Its editable sources
are [report.tex](report.tex), [seed_section.tex](seed_section.tex), and
[negation_proof.tex](negation_proof.tex).

## Positive results

1. **Relatively consistent seeds.** If S is the original native SIR theory and
   Γ contains the universal closures of all initially retained formulas,
   including every stack head, then

       Con(S + Γ)  =>  Nonhalt(initial enumerator root)  =>  Con(S).

   A ZFC proof of Con(ZFC) => Con(S + Γ) suffices for the desired equivalence
   after the exact binary startup and simulation obligations are proved.
   This admits more initial data than native theoremhood. Extensionality is
   a strictness witness, via the report's full two-atom SIR model.

2. **An exact negation rewrite.** For the original dual-Cantor pair,
   P(t,1) = P(0,t) + 2. Prefilling output scratch Y by two and using the
   existing additive pair-and-scale tail implements the same formula code,
   preserving every other register and the entire arbitrary formula stack.
   The proof uses clean scratch X = Y = 0 and explicit natural-counter
   invariants and termination ranks.

3. **Concrete altered runtimes.** The prefilled rewrite reduces the unfolded
   source from 6,460 to 5,590 leaves and from 8,391 to 7,221 guarded cases.
   Shared decoder size remains 203. Contextual emission and six checked
   folds give 255 working states, not a sub252 record. A second direct-transfer
   table also has 255 states and 7,311 checked source cases. Both reach
   exactly the baseline root frame in 82,552 actual blank-tape steps.

4. **Stronger reusable verification.** Four finite difference-bound invariants
   have independent exact-postimage checks. A composable register-box oracle
   carries net register displacements through repeated excursions and permits
   arbitrary valid disposable spare suffixes.

The report does not claim historical priority for the classical
model-theoretic method or elementary pairing identity. Its contribution is
their explicit application to this pinned construction, the exact source
substitution, and the accompanying executable investigation.

## Exact baseline and table conventions

ProveIt pin:

    a2bf288dead95b653919b86608e3f2cca47552f7

The canonical baseline is data/zfc_permutation252.tm:

    252 working states, 504 transitions, start 0, halt 252
    SHA256 8dae0c2359aa8bf87d32543b9e53e1f87fe4716c016a4e2fd174bfe09e520797

The altered tables in data/prefill255.tm and data/direct255.tm use inherited
nonconsecutive labels. Each has 255 working states and 510 transitions.
Their start is 64, dispatch is 96, and separate halt label is 254.
Some working-state labels exceed 254: count row-source labels, not the
largest label. These are fully specified single-tape, two-symbol tables with
left/right moves and blank input.

| Table | SHA-256 |
|---|---|
| prefill255.tm | 463067a5a42476c8efeacb296d83df69b7366b0d1894a4e11f418840e79fb0fb |
| direct255.tm | 120fb2885194f45b08c8586161683bab103e506d3d3db6f71a3634a024e2ebc8 |

The alternate tables are research controls. Keep the existing 252-state
benchmark as the reference until a smaller exact table and its requested
proof endpoint are established.

## Quick reproduction

Requirements: Python 3.10 or newer, standard library only. No network access,
ProveIt checkout, proof assistant, or third-party Python package is needed
for these checks. Assertions must be enabled; do not use -O or -OO.

From this directory:

    python3 -B code/verify_all.py

The integration check uses temporary outputs and leaves the frozen evidence
unchanged. It verifies the manifest when present, exact baseline and altered
blank prefixes, source-control serialization, all four relational invariants,
semantic seed diagnostics, all arithmetic macro controls, both changed
runtime case families, complete ledger coverage, and the phase follow-up.
Component verifiers print their precise scope and record their own hashes.
The full original synthesis trace is not replayed by a coverage check.

The new runtime checks use the unchanged source27 affine executor and four
explicit imported register-box contracts. All 55 supporting rows are fixed.
Their universal symbolic cases are stronger than finite register sampling,
but they are executable certificates, not new kernel proofs.

Useful individual commands:

    python3 -B code/verify_baseline.py
    python3 -B code/semantic_seeds.py --audit
    python3 -B code/semantic_seeds.py --formula 19364
    python3 -B code/verify_zones.py --graph data/program_cases.json --zone data/zones8.txt
    python3 -B negation/verify.py
    python3 -B negation/verify_runtime.py
    python3 -B fusion/verify_coverage.py --output /tmp/fusion-coverage.json
    python3 -B fusion/phase_followup.py --output /tmp/fusion-phase.json
    python3 -B fusion/verify_runtime.py --output /tmp/direct255-runtime.json
    python3 -B fusion/verify_direct_coverage.py --output /tmp/direct255-coverage.json
    python3 -B exploratory/verify_layouts.py --output /tmp/layout-recheck.json

## Full searches and certificate generation

Rebuild and run the relational generator with a C++17 compiler:

    g++ -std=c++17 -O2 code/relational_zones.cpp -o /tmp/bb-zones
    /tmp/bb-zones data/program_graph.txt 8 /tmp/zones8.txt
    python3 -B code/verify_zones.py --graph data/program_cases.json --zone /tmp/zones8.txt

Rerun the 55,471 composable-box uniform folds:

    python3 -B code/compound_fold.py --zones data/zones8.txt --output /tmp/compound-replay.json --seconds 600

The delivered run is complete: 127,788 case checks, no survivor. A complete
portable replay reproduced every recipe and outcome. The cap is 8 and symbolic
fuel is 1,000. A host reaching the time limit reports a partial result.

The independent synthesized-action family on the original 252 table covers
266,112 recipes and 340,724 case checks, with no survivor. Its full JSONL
ledger is in fusion/evidence/fusion-clean.jsonl. The new family permits an
arbitrary conflicting transition when the other transition agrees after
state identification. See [fusion/README.md](fusion/README.md) for the full
search command and the exact eligibility constraints.

The final prefill255 neighborhoods cover 56,896 uniform proposals and 50,799
mixed-row proposals, with no further deletion. The direct255 synthesized-action
family was completed through an audited-prefix continuation: 280,500 recipes,
no survivor. Search failures mean that the stated sufficient certificate
failed. They do not establish a state-count lower bound or semantic failure
of every tested machine.

## Archive layout

| Directory or file | Role |
|---|---|
| report.tex, report.pdf, TeX fragments | Complete exposition and proofs |
| code/ | New portable audits, semantic recognizer, relational generator, composable oracle |
| data/ | Frozen tables, literal source, source graph, four zone certificates |
| results/ | Complete measurements, fold ledger, independent mathematical and contract review |
| negation/ | Source rewrites, 281-state full compiler controls, 255-state prefilled runtime |
| fusion/ | Synthesized transition family, full ledgers, direct255 runtime checker |
| exploratory/ | Recorded scanner-layout experiments and portable replay of saved layouts |
| vendor/ | Unchanged attributed strict affine executor |
| provenance.json | Source pins and the principal artifact hashes |
| THIRD_PARTY_NOTICES.txt | Authorship and license boundaries |
| SHA256SUMS | Integrity manifest, excluding itself |

Historical logs may contain the original development paths. They are
provenance, not runtime dependencies. Some attributed original search drivers
are retained only to identify exactly what produced a ledger; use the
documented portable wrapper for reproduction.

The exploratory quick check replays the 238 initial rotations and all four
saved short-zero histories, and checks the twelve combined layouts. The
30,564-layout beam search and contextual pricing outcomes are historical
recorded measurements; their original drivers are provided with exact
full-checkout dependency guidance. The quick check does not claim to rerun
those two experiments.

## Build the PDF

A standard TeX Live installation with latexmk and the packages declared in
report.tex is sufficient:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The delivered PDF was compiled and all pages were rendered and visually
reviewed. Rebuilding may change PDF metadata and therefore its hash; a
manifest mismatch after an intentional rebuild is expected.

## Integration and attribution

This directory is intended to be incorporated as a new research packet,
for example under Computability/BusyBeaver/Research/ZFC/beyond252.
The supplied .v files are literal input data and attributed reference source.
No newly compiled Lean or Coq module is claimed.

Mira-Cult designed the 254-state machine; Jeff Ketchersid supplied the
referenced verification; Andrew James Wade supplied the public compiler;
mira-emmy supplied the public 253-state reduction; the 252 permutation and
existing verification infrastructure are ProveIt prior work.
See THIRD_PARTY_NOTICES.txt and the nested provenance files.
