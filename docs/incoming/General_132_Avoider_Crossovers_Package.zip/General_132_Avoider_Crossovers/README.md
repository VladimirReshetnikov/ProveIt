# Exact Phase Amplitudes and Reciprocal Crossovers for 132-Avoiders

This eight-page report determines the leading amplitude in every fixed macroscopic cap phase and the exact limiting crossover at every fixed reciprocal threshold. It also proves the conditional macroscopic-piece density, the uniform endpoint-channel law, and the reciprocal-window mixture with uniform-simplex deficits.

At the first new reciprocal threshold, the explicit result is

    n^(3/2) P(M_n <= floor(n/3 + t*n^(3/4)))
        -> 5/sqrt(2*pi) + 729*sqrt(3)/(4*pi) * max(t,0)^2.

The one-third background constant follows from an ordinary pair-convolution evaluation of I4(1/3)=8*sqrt(2)*pi. No finite-part distributions are needed.

The source already proves the two-piece phase above one half, the three-piece phase below one half, and the half-size crossover. Those cases are credited and recovered; new amplitudes start at four pieces and new reciprocal windows at one third. The report answers the current source's higher-constant, higher-window and conditioned-geometry questions. All indices are fixed: there is no uniform result as the reciprocal index grows and no effective convergence rate.

## Contents and reproduction

- `general_avoider_crossovers.pdf`: complete report
- `general_avoider_crossovers.tex`: editable LaTeX source
- `build.sh`: ordinary three-pass TeX Live build
- `checks/model.py`: credited endpoint recurrence, copied byte-identically from the prior Polynomial Rarity package
- `checks/verify.py`: standard-library exact endpoint/channel checks and integer regression counts
- `checks/results.json` and CSV files: exact counts, Catalan denominators and rounded displays
- `checks/verify_integral.py`: optional SymPy check of the integral algebra and constants
- `checks/README.md`: complete computation scope and provenance
- `SOURCES.md`, `validation.json`, `SHA256SUMS`: source pin and artifact verification

Run `python3 checks/verify.py` for all finite checks, or add `--quick` for only the small exhaustive checks. Run `python3 checks/verify_integral.py` for the optional symbolic calculation. Run `bash build.sh` to rebuild the PDF.

The exact finite values converge slowly and do not establish the asymptotics. The manuscript supplies the complete mathematical argument, including the terminal-small and mesoscopic-word bounds. This is an ordinary mathematical proof, not formal verification or external peer review, and no worldwide priority claim is made.
