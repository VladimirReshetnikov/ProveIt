# Rectangular Schur Structure and Sharp Recurrences for Cigler's Hankel Polynomials

A research proof draft prepared for Vladimir Reshetnikov, 29 September 2026.

## Main result

The article proves the explicitly experimental rectangular-Schur formula in
Section 10 of ProveIt's `cigler-conjecture-16-parity/article.tex`:

    H_k(n;t) = s_(n^a)(1 repeated a times, t, t^2 repeated b times),
    a = floor(k/2), b = floor((k-1)/2).

Here H is the sign-adjusted, power-of-t-normalized Hankel determinant defined
in Section 1 of the article. The identity is polynomial and includes t=0.

The exact generic recurrence has roots t^q, q=0,...,k-1, with multiplicities

    e_(k,q) = 1 + floor(q(k-1-q)/2).

A general confluent leading-coefficient theorem proves minimality, rather
than just providing an annihilator. Other results determine the generating
numerator degree and reciprocity, correct a printed sign in Cigler's
Conjecture 18, prove a sharp convergence equivalent for fixed 0<t<1, and
classify the reduced denominators at every real parameter.

## Files

- `article.pdf`: compiled article with proofs, examples, and research questions.
- `article.tex`: complete self-contained LaTeX source; bibliography is inline.
- `code/verify.py`: exact integer, rational, and polynomial verification.
- `data/verification.json`: actual execution record and complete test ranges.
- `data/verification.log`: console transcript.
- `data/sample_polynomials.json`: exact coefficient arrays for tested polynomials.
- `STATUS.md`: claims and verification boundaries.
- `sources.md`: repository pin, primary literature, and bounded source audit.
- `requirements.txt`, `Makefile`: reproduction support.

## Reproduce

Use Python 3.10 or later, SymPy, and a TeX Live/MiKTeX installation with
latexmk, pdflatex, Latin Modern, AMS packages, mathrsfs, microtype, geometry,
booktabs, enumitem, fancyhdr, and hyperref.

```sh
python -m pip install -r requirements.txt
python code/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `make verify` and `make pdf`.

All supplied checks passed under Python 3.13.5 and SymPy 1.14.0. No
floating-point inference, numerical interpolation, or guessed recurrence is
used to establish an all-index theorem. Finite checks are supplementary.

## Status

This is an unrefereed mathematical proof draft, not a Lean or Rocq
formalization. The general Schur identities, character theory, recurrence
background, and confluent bialternants are classical. Historical priority of
every specialized formula has not been exhaustively certified. The literal
whole of the printed Conjecture 18 is not claimed: the article demonstrates
a false sign and proves corrected formulas. The full Conjecture 17 and the
complex root-of-unity cancellation problem are left outside the conclusions.
