# Surreal Universality Without Choice
## Exact coding strength, set-sized universal fields, and finite-transcendence collapse

Research manuscript prepared for Vladimir Reshetnikov, October 3, 2026.

## Contents

- `article.pdf`: the typeset research article.
- `article.tex`: standalone LaTeX source, with an inline bibliography.
- `verify_finite.py`: deterministic, standard-library-only finite verification.
- `verification_results.json`: the supplied run's output (20,595 assertions passed).
- `SOURCES_AND_STATUS.md`: source provenance, novelty limits, and proof boundaries.

## Main results

For a set X, the following are equivalent over ZF: X injects into the powerset
of an ordinal; X injects into the surreal numbers; the free integer polynomial
ring on X embeds into the omnific integers; the free real rational-function
field on X embeds into the surreals. The construction sends an injective surreal
label j(x) to the double Conway monomial omega^(omega^j(x)). These values are
algebraically independent over the reals. Universally quantified over sets X,
these assertions have exactly the strength of the first Kinna-Wagner principle.

For each infinite initial ordinal kappa, the article constructs a set-sized
real-closed surreal subfield U_kappa equinumerous with P(kappa), realizing exactly
the free fields whose variable sets have that coding capacity. Canonical reduced
fractions and minimal-polynomial/root-index codes establish the upper cardinal
bound without choosing quotient representatives.

For polynomial representations into pure surreals in finite-support permutation
models, stabilizer orbits give sharp upper bounds on the transcendence degree of
the image field. A support of s atoms gives bounds s+1 in the basic Fraenkel
model and 2s+1 in the ordered Mostowski model. The latter contains an internal
ordered field with no surreal embedding even though every finite coordinate
subfield has an ordered embedding. The failure of a coherent family of local
maps is explicitly distinguished from finite-stage existence.

The article also proves a convex-resolution characterization of order embeddings,
provides a proposed formalization architecture, and develops twelve research
questions with concrete initial approaches.

## Status and limitations

This is an AI-generated, unrefereed research manuscript. It supplies proofs of
its deductions from stated classical background. It is not a Lean- or
Rocq-checked formalization, and the historical novelty of its exact formulations
has not been established. It does not claim a solution of Glazer and Yao's
reflection questions or another named published open problem.

The atom-model counterexample is a result in ZFA, not a claimed pure-ZF
counterexample. Coordinate universality is separated from universality for
prescribed orders. No sharp explicit birthday bound for U_kappa is claimed.

The script checks finite encodings and algebraic interfaces only. It does not
validate arbitrary-ordinal theorems, construct infinite symmetric models, or
prove independence. In particular, it does not confuse finite ordered sets,
whose order automorphisms are trivial, with the dense ordered atom model.

## Reproduce

Requirements: Python 3.10+ for the finite checks; a standard TeX Live installation
with pdfLaTeX, newtx, amsthm, mathtools, enumitem, hyperref, cleveref, and the other
packages named in the source for the PDF.

```sh
python3 verify_finite.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

No network access or third-party Python package is needed by the verification
script. BibTeX is not needed. Font files are not included in this archive.
