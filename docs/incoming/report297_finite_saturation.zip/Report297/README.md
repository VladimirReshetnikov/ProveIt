# Report 297

Unique Optimal Splits and Spectral Saturation
The seventy-seven finite orders

Prepared for Vladimir Reshetnikov, 7 October 2026.

## Results

- The exact integer comparator W(n,m)=m(n-m)(n-2m)^4 preserves the complete ordering of the fourth-norm reflection branches
- Adjacent branches never tie, proving a unique optimal multiplicity for every n>=3; equality vectors still vary by scaling and permutation
- Exactly 77 finite abelian group orders n>=3 attain the point-spike spectral bound, with largest order 583; the same list applies to subgroup indices
- The complete point-spike equality family is subgroup-supported, with the explicit origin-to-other-point ratio t_q
- Rational or indicator spectral equality is possible only at order/index 4 among n>=3; the rational infimum nevertheless equals the real-weight infimum

The main classification is n=q*m with the following ranges: q=3,...,7 and m=1; q=8 and 1<=m<=2; q=9 and 1<=m<=3; q=10 and 1<=m<=6; q=11 and 1<=m<=53; q=12 and 1<=m<=4; q=13 and 1<=m<=2; q=14,15 and m=1.

Orders/indices 1 and 2 are separate isometric exceptions. The energy is ordered, includes repeated entries, and concerns an order-two point or subgroup spike. The report computes no nonsaturating minimum, claims no complete equality classification for nontrivial subgroup kernels, and makes no global Ramsey/Szemeredi or novelty claim. Reports 1–296 are unchanged.

## Contents

The distribution has twelve source files, Report297.pdf and MANIFEST.sha256. It includes the TeX manuscript, the unchanged independently audited integer classifier, two exact certificates, a read-only verification wrapper, 14 companion regression tests, and the guarded offline builder with its own regression suite. SOURCES.md records the exact inventory and provenance. REPRODUCING.md records the commands and limitations.

The compact proof needs 27 nontrivial integer comparisons. The independent exhaustive route checks 1,184 orders and 351,648 branches after an analytic cutoff, without trusting the candidate reducer to choose the winner. All mathematical decisions in the classifier use integers. The unrestricted no-tie, candidate, cutoff and saturation arguments are written proofs, not extrapolations from finite testing.

## Quick use

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B build.py reproduce --output /tmp/report297-replay

Use a fresh absolute output directory outside this tree. The builder requires Linux no-follow directory descriptors, /proc/self/fd, and the documented TeX executables. The mathematical companion needs only Python's standard library and can be run without TeX or network access.

The manifest and external ZIP SHA-256 pin provide integrity checks, not digital signatures. Byte-identical PDF/ZIP replay requires the same Python, zlib, TeX and font toolchains.
