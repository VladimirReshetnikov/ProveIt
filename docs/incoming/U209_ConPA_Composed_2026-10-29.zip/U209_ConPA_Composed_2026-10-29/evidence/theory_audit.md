# Independent mathematical audit

Scope: ordinary proof review of the unary theory, numerical-calculus bridge,
and inherited source compiler/scheduler. This is an independent assistant
pass within this collaboration, not an external human review or a newly
compiled proof-assistant endpoint.

## Verdict

No substantive mathematical defect was found in the portions reviewed:

- the unary lower interpretation's induction-before-successor ordering;
- parameter elimination through globally least failing numerical tuples;
- the canonical-history construction, including restrictions of old histories;
- the PA bit-membership upper interpretation and its formula-specific induction;
- the U214 role-reassigned emitter's source/output collision case;
- the native truth/falsity alias handling and the W+IR calibration cycle;
- the direct-transfer strong compiler, including its raw-zero exceptions;
- the all-natural protected-tail credit argument.

This verdict does not replace formalization of the complete chain. There is
no newly exported PA derivation, Lean, Rocq, or MM0 endpoint for any U211
machine in the three inspected archives. Some inherited `.v` templates are
included, but they are not an end-to-end certificate for the changed table.

## Sources inspected

The full unary manuscript is at:

`inputs/pa_unary_power_cover/pa_unary_power_cover/sections/`

I read `unary_core.tex`, `unary_arithmetic.tex`, `upper_transport.tex`,
`positive_interface.tex`, `stream.tex`, `unary_separation.tex`, and
`overview.tex`, checking the proof dependencies below.

The three U211 reports explicitly distinguish their native calculus from
the unary manuscript's positive reference stream:

- Contextual: `report.tex`, section “Logical calibration and inherited proof obligations”.
- Research: `paper/calibration.tex` and `paper/research_reproduction.tex`.
- Rotated: `report.tex`, section “Logical calibration and the boundary of the result”.

The compact U212 ancestry was extracted to:

`work/theory/combined/u212_combined_2026-10-29/`

Relevant reviewed retained files are:

- `baseline/u214/proofs/role_emitter.tex`
- `baseline/u214/paper/report.tex`
- `baseline/u218/paper/report.tex`
- `baseline/primary_u213/proofs/compiler.tex`
- `baseline/primary_u213/proofs/startup_suffix.tex`
- `baseline/primary_u213/proofs/source_compiler_review.txt`
- `baseline/primary_u213/references/ST215/protected_credit.md`

The complete original U222 packet was recovered losslessly from Contextual's
nested ancestry. Its extracted root is:

`work/theory/full_u222/u222_consistency_machine/`

The key source is `paper/report.tex`, sections “Native formula codes and the
new axiom emitter” and “The numerical calculus and its consistency
calibration”, together with `references/logic/README.md` and its cited `.v`
logical proof templates.

## Detailed checks

### Unary interpretation

1. Coextensionality is an equivalence relation and is automatically a
   congruence in the containing-object coordinate. Saturation is explicitly
   required where membership in the tested-object coordinate is used.
2. A numerical object has a predecessor when nonempty, independently of
   successor existence. Numericality is hereditary to members.
3. The unary induction proof properly handles the case where an alleged
   counterexample has no failing member: use its own predecessor. It does not
   appeal to a successor of the counterexample.
4. For an arbitrary parameterized formula theta, the unary predicate
   `forall p (base_and_step(theta,p) -> theta(v,p))` has provable base and
   step. This is the correct parameter-internalization trick; it introduces
   no free source or graph parameter into a cover matrix.
5. Comparison and minimization use that derived induction, so they do not
   presuppose total successor. Lexicographic least tuples are selected one
   coordinate at a time using already allowed parameters in induction.
6. The least-failure predicate is a finite formula formed from a fixed
   target profile. It is not a truth predicate or a self-referential schema.
   The proof uses invariance in numerical parameters to identify all least
   tuples, and a separately supplied support source to obtain exactness.
7. Successor and numerical power targets are genuinely supported at their
   numerical source. No global powers, global extensionality, or arbitrary
   ambient parameter separation is silently used.
8. Saturated Kuratowski pairs have unique decoding modulo coextensionality.
   The graph bound is a numerical power; selected pair codes are subsets of
   this bound, rather than presumed numerical objects themselves.
9. Canonical history extension and restriction quantify over earlier
   histories. Pointwise uniqueness is established before those constructions.
   The graph witness is not inserted as an illicit free matrix parameter.
10. The upper interpretation uses a separate finite-comprehension induction
    instance for each translated formula. PA proves its needed exponential
    bounds. It makes no claim to evaluate arbitrary formulas uniformly.

### Native calculus

The actual machine target is code 1. The unary positive reference stream's
target is code 0; its syntax and completeness theorem cannot be directly
substituted for the native numerical calculus.

The native extension W allows source and other parameters and adds global
irreflexivity. This is legitimate: PA interprets W+IR by bit membership;
W includes U; and U interprets PA. The corresponding finite refutation
maps establish the consistency cycle inside PA.

Code 0 is a truth alias (`I(0,0)=0`), code 1 is diagonal membership
normalized to false under IR. It would be incorrect to assume code 1 is
false in every structure independently of IR. Conversely, the numerical
identity at 1 quotes diagonal negation; generalization recovers IR in the
numerical presentation. The retained logical templates include the
equality-indiscernibility translation needed for equality-free completeness.

For role-reassigned U214, output label a is fresh in decoded matrix a by
the self-freshness lemma; code 0 is closed. The gate excludes test label c
from both a and source b. When a=b, the captured subset guard becomes
emptiness under IR. An empty source exists, and a cover at that source
proves the exceptional bundle. This removes the tempting but invalid need
to assume source/output distinctness without a runtime test.

### Compiler and scheduler

The direct selection command tests incoming cache, not incoming top. The
derived H block tests incoming top only after resetting old cache. The
compiler preserves this distinction. PUSH forces MP failure by a quantifier
tag; DISCARD forces failure by a positive implication code. `J(0)` is empty,
because `MP(0)` from zero top/cache succeeds owing to the raw-zero alias.

The strong compiler quantifies over arbitrary incoming numerical top and
stack and resets only counter/cache. Its refutation suffix can therefore
run above the startup's opaque tail. Successful candidate indices are
cofinal; each failed candidate terminates by descent of continuation code.

The startup carries cache 1 as a selector. The suffix reads change the
parameter to 2 before producing nine theorem heads. Tail 4 is unsafe if
exposed and is correctly handled by a ghost-list invariant, not by declaring
all its decoded heads theorem-valued.

For the scheduler's debt proof, the right Cantor projection enumerates
blocks `[0]`, `[0,1]`, `[0,1,2]`, ... . Applying the initial-partial-sum
lemma twice to `q(r)=g(r)+1` gives the AX contribution bound. All values
needed on diagonal s refer to earlier candidates, so the joint induction
is not circular. Each diagonal s>=2 has nonnegative relative prefix weight;
the only initial debt from candidate 1 is two selections. Nine heads leave
a margin of seven. The equality `unpair(P(x,v))=(x,v)` holds even when
`P(0,0)=0`, so the ghost list need not have an injectively encoded length.

## Packaging omission and remedy

The Research and Rotated packets retain the compact combined U212 archive
with SHA256 `993a97dd787144f7c9fcc7303f33032a392e866ba66ad15eb2aa2ebb1e48f56b`.
Its `baseline/u222` directory contains only three machine/source data files.
The complete U222 logical calibration and its referenced logical templates
are omitted, even though an embedded old U218 report still says the complete
U222 archive is included. This is a documentation/ancestry omission, not a
counterexample to the theory or the reduction.

Contextual retains the complete ancestry in `baseline/selected_U212.zip`:
10,243,682 bytes, SHA256
`b5a5d19531f49b05aaad4e1b0f86d6f0de96c37b40a3617522b0d920cf83d6c6`.

A compact remedy is to retain the combined U212 packet plus the original
U222 archive recovered here:

`work/theory/U222_ConU_2026-10-28.zip`

It has 2,231,763 bytes and SHA256
`d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652`,
exactly the hash named in the retained U218 report. Full nested member
provenance and hashes are recorded in `work/theory/ancestry_chain.json`.

## New proof versus inherited proof

For a sub-211 candidate, the new proof can preserve the entire inherited
logical chain. It must establish the final literal table, valid source
reassociation, complete primitive runtime on the new source addresses,
and exact blank entry. The local predecessor-tag fold may have an all-tape
simulation theorem, but a source-address reassociation does not inherit
that stronger scope automatically. A finite startup match or a source
checksum alone is insufficient to establish unbounded simulation.

The correctly qualified conclusion is a conventional PA-formalizable
machine-equivalence theorem composed with the inherited PA-formalizable
calibration, supported by reproducible exact finite and symbolic checks.
It is not a newly kernel-checked arithmetic endpoint.

The calibration fragment for inclusion in the final report is
`work/theory/calibration_audit.tex`. It intentionally calls the final
machine M so that the final state count can be substituted by the parent.
