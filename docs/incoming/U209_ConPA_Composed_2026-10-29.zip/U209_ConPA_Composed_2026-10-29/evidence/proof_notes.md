# U209: simultaneous guarded deletions after continuation transport

All state names below are native labels; the halt state is 254. Let R denote
`rotated212.native.tm`, the final 212-state intermediate after the combined
source transformations and engine-entry repair. Let C denote `u209.native.tm`.

## Structural certificate

The only removed states are 180, 181 and 218. Set

    f(180)=163, f(181)=220, f(218)=157, f(q)=q otherwise.

The final literal table is obtained by mapping every target through f,
removing the six rows with source 180, 181 or 218, and changing

    (163,0) -> (0,L,211),
    (220,0) -> (0,L,217).

Every other retained row is exactly the target-renamed R row. In R the complete
incoming inventories are:

| State | Incoming source/read pairs | Previously written bit |
|---|---|---|
| 163 | 216/0 | 0 |
| 180 | 132/1, 199/1 | 1 |
| 220 | 214/0 | 0 |
| 181 | 185/1 | 1 |
| 218 | 158/0, 211/0, 215/0, 220/0 | 0 |

All these edges move right and none of these five states is initial. Therefore
on every R run starting in state zero, each visit to one of these states has
the displayed bit in the cell immediately left of the head. This argument
holds on every initial binary tape; the marker is written by the incoming
transition and is not an assumption about blankness.

## Exhaustive two-cell identities

Write h for the initial head coordinate and b for the current bit. All paths
below leave the complete tape unchanged, read only cells h-1 and h, and end
with head h+1. Unspecified exterior cells are never read or written.

| Old state | Marker | b | R next state | C path (including initial and endpoint states) | C steps |
|---|---:|---:|---:|---|---:|
|163|0|0|90|163,211,157,67,151,90|5|
|163|0|1|211|163,211|1|
|180|1|0|152|163,211,184,152|3|
|180|1|1|211|163,211|1|
|220|0|0|218|220,217,158,157|3|
|220|0|1|176|220,176|1|
|181|1|0|147|220,217,129,147|3|
|181|1|1|176|220,176|1|
|218|0|0|90|157,67,151,90|3|
|218|0|1|86|157,148,186,86|3|

The endpoint in each C path is f of the corresponding R endpoint. In the
220/0 case the new endpoint 157 represents old 218, and the old scanned zero
has become its required predecessor zero. The other endpoint states do not
need a new guard.

Relate an R configuration (q,h,T) to the C configuration (f(q),h,T), imposing
the displayed marker predicate at the five exceptional R states. Ordinary
steps commute with f. The ten listed cases provide positive finite blocks at
the exceptional states, with lengths one, three or five. No block visits halt
internally. Induction on the finite R trace constructs an equal-endpoint C
trace. Conversely, if C halted after n steps while R had not halted within n
steps, the first n positive R-block simulations would force C to continue
through at least n steps without an earlier halt, a contradiction. This is a
finite bounded-trace argument expressible in PA, and proves halting equivalence
on all common initial tapes from state zero for R and C.

If both runs halt, write N5 for the number of R transitions from state163/read0
and N3 for the number of transitions covered by the five three-step rows of
the table. (There are five such guarded cases: 180/0,220/0,181/0,218/0,218/1.)
Then exactly

    time(C) = time(R) + 4*N5 + 2*N3,
    time(R) <= time(C) <= 5*time(R).

This clock comparison is only for the final three deletions, not for the
source-address rearrangements.

## Why the three proposals can be combined

Directly stacking the incoming patches fails because they expect different
source trees and donor-state roles. The new common layout moves the fixed
78-primitive closed continuation rooted at native116 through the right spine
of the joint Research/Contextual layout. Twelve right reassociations suffice.
The final exposed spine contains

    217=(158,129), 129=(147,204),
    216=(163,215), 215=(218,116).

Consequently the Research selector moves from native129 to native217: the
zero-marker route is 217 -> 158 -> 218, and the one-marker route is
217 -> 129 -> 147. At the same time every entry into218 writes zero and the
Contextual keeper163 retains its zero-marker entry. Replacing218 by157 changes
the Contextual zero-marker micro-path from three steps to five, which is why
that interaction must be checked on the combined final table.

The portable builder reconstructs this layout from the common U212 parent with
30 checked closed-factor rotations and one five-state label permutation. It
checks ordered primitives and two complete guarded-successor algorithms after
every rotation. All the eight factors of the intermediate reassociation are
closed, and it has a verified six-rotation decomposition. These facts establish
identity on the 3,909 primitive ordinals and their register effects/control
successors; they do not alone establish correctness of the modified literal
address decoder. The complete symbolic primitive-runtime derivation is a
separate gate.

The engine-entry repair is 171/0 -> 0 L 205. For a scanned zero and left cell0,
the old path171,7,86 and new path171,205,86 have identical whole-tape endpoints.
For left cell1 the old path171,7,205,164 and new path171,205,206,164 have identical
whole-tape endpoints. Both cases read only the same two specified cells.

## Initial configuration and runtime boundary

The exact 48,140-step blank prefix agrees on the whole finite-support tape
with original U212, reaching native84, head -2, header54, source ordinal136,
logical registers (1,0,13,0,0,1,0,0,1), and43 spare registers of value1. There
are120 one-cells and every exterior cell is zero. The modified retained rows
are absent from this prefix. A141-step source bridge from ordinal106 and
registers(1,0,4,0,0,1,0,0,1) reaches the same ordinal/register configuration.

The runtime engine uses literal transitions, unary self-loop induction and
finite-list induction. Each of its four generic block lemmas is rederived from
the literal candidate. The final primitive contracts use arbitrary nine
natural primary registers, arbitrary natural extra gap and an arbitrary
nonempty finite spare list, including a natural first-spare value and arbitrary
finite tail. Endpoint equality includes the entire tape and displacement.

These ordinary mathematical arguments and executable finite/symbolic
certificates are formalizable in PA. They are not a newly checked Lean, Rocq
or MM0 proof object. Transferring Con(PA) still requires the inherited U212
numerical proof-calculus completeness/soundness, nonzero-start calibration and
Theory U/PA equiconsistency proofs. No consistency or nonhalting assertion is
made unconditionally.
