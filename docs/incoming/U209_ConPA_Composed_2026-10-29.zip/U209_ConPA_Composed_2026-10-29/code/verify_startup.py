#!/usr/bin/env python3
"""Independent source ordinal semantics and exact blank-prefix audit."""
from pathlib import Path
import hashlib
import json

import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--baseline-table', type=Path, required=True)
parser.add_argument('--baseline-source', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--output', type=Path)
args=parser.parse_args()
NEW = args.candidate
OUT = args.output or NEW / 'startup.json'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def graph(rows):
    names = [p for p, _, _ in rows]
    require(len(names) == len(set(names)), 'Repeated source address')
    require(names == sorted(names), 'Source ordinals not lexicographic')
    index = {p: i for i, p in enumerate(names)}
    prefixes = {p[:k] for p in names for k in range(len(p))}
    require(not prefixes.intersection(index), 'Source leaf-prefix overlap')
    for p in prefixes:
        require(all(p+b in prefixes or p+b in index for b in '01'), 'Nonfull tree')
    intervals = {}
    for i, p in enumerate(names):
        for k in range(len(p)+1):
            pre = p[:k]
            if pre not in intervals:
                intervals[pre] = [i, i+1]
            else:
                require(intervals[pre][1] == i, 'Noncontiguous subtree')
                intervals[pre][1] = i+1
    out = []
    for i, (p, op, arg) in enumerate(rows):
        if op == 'CI':
            target = [(i+1) % len(rows)]
        elif op == 'CH':
            require(arg is None, 'Bad halt argument')
            target = []
        else:
            require(op in ('CD', 'CB', 'CC'), 'Unknown operation')
            symbol = '1' if op == 'CC' else '0'
            debt = 1 if op == 'CD' else arg
            require(isinstance(debt, int) and debt > 0, 'Bad control debt')
            positions = [j for j, b in enumerate(p) if b == symbol]
            require(debt <= len(positions), 'Escaping source jump')
            pre = p[:positions[-debt]]
            destination = intervals[pre][0 if symbol == '1' else 1] % len(rows)
            target = [destination, (i+1) % len(rows)] if op == 'CD' else [destination]
        out.append([op, arg, target])
    return out

def parse_table(path):
    result = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        key = (int(q), int(b))
        require(key not in result, 'Repeated literal transition')
        require(b in '01' and w in '01' and d in ('L', 'R'), 'Bad action')
        result[key] = (int(w), -1 if d == 'L' else 1, int(z))
    states = {q for q, b in result}
    require(all((q, b) in result for q in states for b in (0, 1)), 'Incomplete table')
    require(all(z in states or z == 254 for w, d, z in result.values()), 'Open target')
    return result

def prefix(table, ticks):
    q = h = 0
    ones = set()
    visited = set()
    for tick in range(ticks):
        require(q != 254, ('Early halt', tick))
        key = q, int(h in ones)
        visited.add(key)
        w, d, q = table[key]
        if w:
            ones.add(h)
        else:
            ones.discard(h)
        h += d
    return q, h, ones, visited

old_source = args.baseline_source
new_source = NEW / 'sites.json'
old_rows, new_rows = [json.loads(p.read_text()) for p in (old_source, new_source)]
old_graph, new_graph = graph(old_rows), graph(new_rows)
require(old_graph == new_graph, 'Ordered primitive effects/control successors differ')
require(len(old_rows) == len(new_rows) == 3909, 'Wrong primitive count')
require(old_rows[136] == new_rows[136] == ['001100110101010', 'CI', 1], 'Startup ordinal drift')
regs = [1,0,4,0,0,1,0,0,1]
ip = 106
for tick in range(141):
    op, arg, targets = new_graph[ip]
    if op == 'CI':
        regs[arg] += 1
        ip = targets[0]
    elif op == 'CD':
        positive = regs[arg] > 0
        regs[arg] -= int(positive)
        ip = targets[int(positive)]
    elif op in ('CB', 'CC'):
        ip = targets[0]
    else:
        raise ValueError('Premature source halt')
require((ip, regs) == (136, [1,0,13,0,0,1,0,0,1]), 'Wrong source bridge')

old_table = parse_table(args.baseline_table)
new_table = parse_table(NEW / 'u209.native.tm')
old_state, old_head, old_ones, old_used = prefix(old_table, 48140)
state, head, ones, used = prefix(new_table, 48140)
require((state,head,ones) == (old_state,old_head,old_ones), 'Blank prefix endpoint changed')
require((state,head,len(ones)) == (84,-2,120), 'Wrong blank frame census')
# Build the complete prescribed unary/list frame directly, independently of a decoder.
physical_permutation = (6,2,0,4,3,7,8,5,1)
physical = [None] * 9
for r, p in enumerate(physical_permutation):
    physical[p] = regs[r]
expected = {head-1, head+56}
for j, bit in enumerate(new_rows[136][0]):
    if bit == '1':
        expected.add(head+j)
position = head+57
for value in physical + [1]*43:
    position += 1
    expected.update(range(position,position+value+1))
    position += value+1
require(expected == ones, 'Full tape differs from prescribed symbolic frame')
changed = [list(key) for key in new_table if old_table.get(key) != new_table[key]]
require(not set(map(tuple,changed)).intersection(used), 'A retained edited row occurs during startup')
report = {
    'status': 'SOURCE_AND_STARTUP_TRANSPORT_PASS',
    'source_old_sha256': sha(old_source), 'source_new_sha256': sha(new_source),
    'table_new_sha256': sha(NEW/'u209.native.tm'),
    'working_states': len({q for q,b in new_table}),
    'primitive_occurrences': len(new_rows),
    'ordered_effects_and_every_successor_equal': True,
    'source_cases': sum(2 if op=='CD' else 1 for p,op,a in new_rows),
    'changed_addresses': sum(a[0]!=b[0] for a,b in zip(old_rows,new_rows)),
    'startup': {'ticks':48140,'state':state,'head':head,'header':head+56,
                'ordinal':136,'address':new_rows[136][0],'registers':regs,
                'spares':[1]*43,'one_cells':len(ones),'complete_tape_equal':True,
                'no_edited_retained_rows_used':True},
    'source_bridge':{'initial_ordinal':106,'initial_registers':[1,0,4,0,0,1,0,0,1],
                    'steps':141,'final_ordinal':ip,'final_registers':regs},
    'proof_scope':'Source ordered-primitive bisimulation and exact initialization. '
        'Complete literal/source runtime and guarded local fold are separate obligations.'
}
OUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
