"""Independent finite checker for the combined U209 three guarded deletions.

Requires only the delivered prefold/native/source tables and original U212.
No compiler or symbolic runtime engine is imported; checks stay active under -O.
"""
from pathlib import Path
import json,hashlib,argparse

def require(b,msg):
 if not b:raise ValueError(msg)
def table(p,halt=254):
 d={};starts=[]
 for line in Path(p).read_text().splitlines():
  if line.startswith('#! start'):starts.append(line)
  if not line or line.startswith('#'):continue
  q,b,w,m,z=line.split();q,b,w,z=map(int,[q,b,w,z])
  require(b in (0,1) and w in (0,1) and m in ('L','R'),'row syntax')
  require((q,b) not in d,'duplicate');d[q,b]=w,1 if m=='R' else -1,z
 require(starts==['#! start 0'],'initial state')
 states={q for q,b in d}
 require(set(d)=={(q,b) for q in states for b in (0,1)},'totality')
 require({z for w,m,z in d.values()}-states=={halt},'halt closure')
 return d
def incoming(t,q):return [(s,b,w,m) for (s,b),(w,m,z) in sorted(t.items()) if z==q]
def run(t,q,h,c,n):
 c=dict(c);log=[]
 for _ in range(n):
  require(q!=254 and h in c,'opaque exterior or halt read')
  b=c[h];w,m,z=t[q,b];log.append([q,h,b,w,m,z]);c[h]=w;h+=m;q=z
 return(q,h,c),log
def prefix(t,n):
 q=h=0;ones=set();used=set()
 for _ in range(n):
  b=int(h in ones);used.add((q,b));w,m,q=t[q,b]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=m
 return q,h,ones,used
def fold_check(a,b):
 require(len(a)==424 and len(b)==418,'state count')
 require(set(a)-set(b)=={(q,x) for q in (180,181,218) for x in (0,1)},'deleted rows')
 require(not set(b)-set(a),'new rows')
 require(incoming(a,220)==[(214,0,0,1)],'220 zero tag')
 require(incoming(a,181)==[(185,1,1,1)],'181 one tag')
 require(incoming(a,218)==[(158,0,0,1),(211,0,0,1),(215,0,0,1),(220,0,0,1)],'218 zero tag')
 require(incoming(a,163)==[(216,0,0,1)],'163 zero tag')
 require(incoming(a,180)==[(132,1,1,1),(199,1,1,1)],'180 one tag')
 f=lambda q:{180:163,181:220,218:157}.get(q,q)
 exceptional={180,181,218,220,163}
 for (q,x),(w,m,z) in a.items():
  if q not in exceptional:require(b[q,x]==(w,m,f(z)),f'ordinary row {q}/{x}')
 records=[]
 for q,tag in [(163,0),(180,1),(220,0),(181,1),(218,0)]:
  for x in (0,1):
   c={-1:tag,0:x}
   ae,al=run(a,q,0,c,1)
   n=5 if q==163 and x==0 else 3 if q==218 or x==0 else 1
   be,bl=run(b,f(q),0,c,n)
   require(be==(f(ae[0]),ae[1],ae[2]),'local identity')
   require(ae[2]==c and be[2]==c,'whole tape unchanged')
   if ae[0] in (180,181,218,220,163):
    req={180:1,181:1,218:0,220:0,163:0}[ae[0]]
    require(ae[2][ae[1]-1]==req,'new invariant')
   records.append(dict(old_state=q,tag=tag,bit=x,old_trace=al,new_trace=bl,new_steps=n))
 return records

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent/'u209');p.add_argument('--baseline-table',type=Path);p.add_argument('--output',type=Path);args=p.parse_args();r=args.root
 a=table(r/'rotated212.native.tm');b=table(r/'u209.native.tm')
 cases=fold_check(a,b)
 native_states=sorted({q for q,x in b});rename={q:i for i,q in enumerate(native_states)};rename[254]=209
 dense=table(r/'u209.tm',209)
 require(dense=={(rename[q],x):(w,m,rename[z]) for (q,x),(w,m,z) in b.items()},'dense renaming')
 seen={0};todo=[0]
 for q in todo:
  for x in (0,1):
   z=dense[q,x][2]
   if z!=209 and z not in seen:seen.add(z);todo.append(z)
 require(seen==set(range(209)),'graph reachability')
 repair=[]
 if args.baseline_table:
  base=table(args.baseline_table)
  for bit in (0,1):
   cells={-1:bit,0:0};n=2+bit
   be,bl=run(base,171,0,cells,n);ae,al=run(a,171,0,cells,n)
   require(ae==be,'repair endpoint')
   require(be==((86,0,cells) if bit==0 else (164,1,cells)),'repair expected endpoint')
   repair.append(dict(left=bit,old_trace=bl,new_trace=al,steps=n,whole_tape_equal=True))
 mutations=[]
 for name,key,action in [('helper write',(217,0),(1,1,158)),('zero-tag premise',(214,0),(1,1,220)),('bad folded target',(158,0),(0,1,147)),('218 donor direction',(157,0),(0,1,67))]:
  aa,bb=dict(a),dict(b)
  bb[key]=action
  if name=='zero-tag premise':aa[key]=action
  try:fold_check(aa,bb)
  except ValueError:mutations.append(name)
  else:raise ValueError('negative control accepted')
 source=json.loads((r/'sites.json').read_text())
 expected_rows={tuple(z[:2]) for z in cases[0]['new_trace']}
 result=dict(status='COMBINED_LOCAL_FOLD_PASS',old_states=212,new_states=209,new_rows=418,cases=cases,incoming={str(q):incoming(a,q) for q in (180,181,218,220,163)},negative_controls_rejected=mutations,dense_renaming=True,all_states_graph_reachable=True,engine_repair=repair,
  block_lengths=[1,3,5],proof_scope='All common initial binary tapes from state0 for the three deletions from the supplied rotated212 table. Source rotations and runtime require their own checks.',
  native_sha256=hashlib.sha256((r/'u209.native.tm').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((r/'sites.json').read_bytes()).hexdigest())
 (args.output or r/'local_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
