"""Independent table-level audit of the U209 simultaneous guarded fold.

No candidate builder, local checker, or symbolic runtime is imported.
The check derives the first synchronizing path of each exceptional old row.
"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1] / "rotated" / "u209"
OUT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load_table(path):
    rows = {}
    starts = []
    for line in path.read_text().splitlines():
        if line.startswith("#! start"):
            starts.append(line)
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        require(len(fields) == 5, "bad row width")
        q, bit, write, direction, target = fields
        q, bit, write, target = map(int, (q, bit, write, target))
        require(bit in (0, 1) and write in (0, 1), "bad alphabet")
        require(direction in ("L", "R"), "bad direction")
        require((q, bit) not in rows, "duplicate source row")
        rows[q, bit] = (write, 1 if direction == "R" else -1, target)
    require(starts == ["#! start 0"], "wrong initial state")
    states = {q for q, _ in rows}
    require(set(rows) == {(q, b) for q in states for b in (0, 1)}, "partial table")
    require({z for _, _, z in rows.values()} - states == {254}, "wrong external target")
    return rows


def mapped(q):
    return {180: 163, 181: 220, 218: 157}.get(q, q)


def predecessors(rows, target):
    return [(q, b, w, d) for (q, b), (w, d, z) in sorted(rows.items()) if z == target]


def step(rows, config):
    q, h, cells = config
    require(q != 254, "interior halt")
    require(h in cells, "path inspected opaque exterior")
    cells = dict(cells)
    bit = cells[h]
    w, d, z = rows[q, bit]
    cells[h] = w
    return (z, h + d, cells), (q, h, bit, w, d, z)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=OUT / "u209_independent_fold_review.json")
    args = parser.parse_args()
    old_path = args.root / "rotated212.native.tm"
    new_path = args.root / "u209.native.tm"
    old, new = load_table(old_path), load_table(new_path)
    require(len(old) == 424 and len(new) == 418, "wrong state counts")
    require(set(old) - set(new) == {(q, b) for q in (180, 181, 218) for b in (0, 1)}, "wrong deletions")
    require(not set(new) - set(old), "new state introduced")
    tags = {163: 0, 180: 1, 220: 0, 181: 1, 218: 0}
    expected_predecessors = {
        163: [(216, 0, 0, 1)],
        180: [(132, 1, 1, 1), (199, 1, 1, 1)],
        220: [(214, 0, 0, 1)],
        181: [(185, 1, 1, 1)],
        218: [(158, 0, 0, 1), (211, 0, 0, 1), (215, 0, 0, 1), (220, 0, 0, 1)],
    }
    for q, tag in tags.items():
        inc = predecessors(old, q)
        require(inc == expected_predecessors[q], f"incorrect predecessor inventory for {q}")
        require(all(w == tag and d == 1 for _, _, w, d in inc), "tag not established")
    ordinary = 0
    for (q, bit), (write, move, target) in old.items():
        if q not in tags:
            require(new[q, bit] == (write, move, mapped(target)), f"ordinary row mismatch {q}/{bit}")
            ordinary += 1
    records = []
    for q, tag in tags.items():
        for bit in (0, 1):
            cells = {-1: tag, 0: bit}
            old_end, old_step = step(old, (q, 0, cells))
            expected = (mapped(old_end[0]), old_end[1], old_end[2])
            current = (mapped(q), 0, cells)
            path = []
            for duration in range(1, 6):
                current, edge = step(new, current)
                path.append(edge)
                if current == expected:
                    break
            else:
                raise RuntimeError(f"no synchronization in five steps: {q}/{bit}")
            require(current[2] == cells, "an exceptional path modifies the tape")
            if old_end[0] in tags:
                require(old_end[2][old_end[1] - 1] == tags[old_end[0]], "endpoint fails next tag")
            records.append({"old_state": q, "read": bit, "left_tag": tag,
                            "duration": duration, "new_states": [edge[0] for edge in path] + [current[0]],
                            "old_target": old_end[0], "new_target": current[0]})
    duration_classes = {
        str(length): [[r["old_state"], r["read"]] for r in records if r["duration"] == length]
        for length in (1, 3, 5)
    }
    require(duration_classes["5"] == [[163, 0]], "wrong five-step class")
    require(sorted(duration_classes["3"]) == sorted([[180, 0], [220, 0], [181, 0], [218, 0], [218, 1]]), "wrong three-step class")
    result = {
        "status": "INDEPENDENT_SIMULTANEOUS_FOLD_AUDIT_PASS",
        "old_sha256": hashlib.sha256(old_path.read_bytes()).hexdigest(),
        "new_sha256": hashlib.sha256(new_path.read_bytes()).hexdigest(),
        "ordinary_rows": ordinary,
        "exceptional_cases": records,
        "duration_classes": duration_classes,
        "donor_157_rows_unchanged": all(old[157, b] == new[157, b] for b in (0, 1)),
        "donor_157_old_predecessors": predecessors(old, 157),
        "scope": "Final simultaneous 212-to-209 fold, any common initial binary tape at native state 0.",
        "step_formula": "Tnew = Tpre + 2*n3 + 4*n5; Tpre <= Tnew <= 5*Tpre",
        "formalization_status": "Exact table/path checks plus separate written mathematical proof; no proof-assistant endpoint.",
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
