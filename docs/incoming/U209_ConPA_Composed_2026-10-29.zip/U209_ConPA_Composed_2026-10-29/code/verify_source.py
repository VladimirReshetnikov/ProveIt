#!/usr/bin/env python3
"""Independent source CFG and literal-prefix check; no builder imports."""
from pathlib import Path
import hashlib
import json
from source_audit_utils import require, read_table, source_info, prefix_binding

ROOT = Path(__file__).resolve().parents[1]

def main():
    old_path = ROOT / 'inputs/u212.sites.json'
    new_path = ROOT / 'machine/sites.json'
    old = json.loads(old_path.read_text())
    new = json.loads(new_path.read_text())
    _, _, old_cfg, old_metrics = source_info(old)
    branches, _, new_cfg, metrics = source_info(new)
    require(old_cfg == new_cfg, 'Ordered effects or ordinal control successors changed')
    require(len(old_cfg) == 3909, 'Source size')
    require(sum(2 if row[1] == 'CD' else 1 for row in new) == 5084, 'Guarded case count')
    require(metrics['maximum_zero_run'] <= 6 and metrics['maximum_depth'] <= 56,
            'Source violates origin-detector or header constraint')
    prefixes = {}
    for name in ('rotated212.native.tm', 'u209.native.tm'):
        table = read_table(ROOT / 'machine' / name)
        binding, maximum = prefix_binding(table, branches)
        require(len(binding) == 3908, 'Incomplete prefix audit')
        prefixes[name] = {'internal_prefixes': len(binding), 'maximum_steps': maximum}
    result = {'status': 'INDEPENDENT_SOURCE_AND_PREFIX_PASS',
              'primitive_occurrences': len(old_cfg), 'guarded_cases': 5084,
              'ordinal_cfg_equal': True, 'old_metrics': old_metrics, 'metrics': metrics,
              'changed_addresses': sum(a[0] != b[0] for a, b in zip(old, new)),
              'literal_prefix_audits': prefixes,
              'parent_source_sha256': hashlib.sha256(old_path.read_bytes()).hexdigest(),
              'source_sha256': hashlib.sha256(new_path.read_bytes()).hexdigest(),
              'scope': 'Exact source CFG equality and prefix traces. Primitive runtime and startup are separately checked.'}
    (ROOT / 'evidence/source.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
