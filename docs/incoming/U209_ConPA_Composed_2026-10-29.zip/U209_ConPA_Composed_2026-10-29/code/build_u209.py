#!/usr/bin/env python3
"""Reconstruct U209 from the pinned common U212 table and source.

Thirty explicit closed-factor rotations, a pure-decoder label permutation,
local arithmetic-entry repair, and three guarded folds. Standard library only.
The source/CFG and literal finite-table checks do not replace the separate
universal runtime and logical-calibration proofs.
"""
from pathlib import Path
import argparse, hashlib, json, sys
import source_language as L

PARENT_TABLE_SHA='386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
PARENT_SOURCE_SHA='7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'
EXPECTED_NATIVE_SHA='8e058789f2f11a448db7212bf2e32317fbd5027c6043cfd0e7791532bc3256cb'
RESEARCH=[(215,204,1),(217,181,1),(185,217,0),(174,185,1),(129,158,0),(217,215,1),(204,214,0),(215,129,0),(216,220,1)]
REASSOCIATE=[(217,215,0),(215,129,0),(129,204,0),(204,214,0),(214,216,0),(216,163,1)]
RETAG=[(206,199,1),(205,206,1),(7,205,1)]
CARRY=[(162,203,0),(203,223,0),(223,188,0),(188,177,0),(177,89,0),(89,174,0),(174,217,0),(217,129,0),(129,204,0),(204,214,0),(214,216,0),(216,215,0)]
PERMUTATION={215:129,129:204,204:214,214:216,216:215}

def need(c,m):
    if not c: raise ValueError(m)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
    table={};starts=[]
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need((q,b) not in table and b in(0,1) and w in(0,1) and d in('L','R'),'Invalid transition syntax')
        table[q,b]=(w,d,z)
    need(starts==[0],'Initial state convention');return table
def encode(table):
    return ('#! start 0\n'+''.join(f'{q} {b} {w} {d} {z}\n' for(q,b),(w,d,z)in sorted(table.items()))).encode('ascii')
def census(table,n,halt=254):
    states={q for q,b in table}
    need(len(states)==n and set(table)=={(q,b)for q in states for b in(0,1)},'Working-state census')
    need(0 in states and halt not in states and {z for w,d,z in table.values()}-states=={halt},'Target closure')
    seen={0};todo=[0]
    for q in todo:
        for b in(0,1):
            z=table[q,b][2]
            if z!=halt and z not in seen:seen.add(z);todo.append(z)
    need(seen==states,'Directed graph reachability');return states
def occurrences(root,table,target):
    found=[]
    def visit(node,q,path):
        if q==target:found.append((path,node));return
        if L.leaf(node):return
        for b in(0,1):
            w,d,z=table[q,b]
            if(w,d)==(b,'R'):visit(node[b],z,path+str(b))
    visit(root,84,'');return found
def size(node):return 1 if L.leaf(node) else size(node[0])+size(node[1])
def incoming(table,q):return [[r,b,w,d]for(r,b),(w,d,z)in sorted(table.items())if z==q]
def write_json(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')

def build(parent_table,parent_source,output):
    need(__debug__ and not sys.flags.optimize,'Run without Python -O; inherited source utilities use checked invariants')
    raw=Path(parent_table).read_bytes();source_raw=Path(parent_source).read_bytes()
    need(sha(raw)==PARENT_TABLE_SHA,'Pinned U212 table differs')
    need(sha(source_raw)==PARENT_SOURCE_SHA,'Pinned U212 source differs')
    table=parse(raw);census(table,212);original=table.copy()
    original_rows=json.loads(source_raw);root=L.tree(original_rows)
    graph=L.graph_intervals(original_rows)
    need(graph==L.graph_arithmetic(original_rows)[0],'Initial independent CFG disagreement')
    ledger=[];stages=[]
    def rotate(phase,p,q,side):
        nonlocal root
        places=occurrences(root,table,p)
        need(places and len({node for path,node in places})==1,'Missing or different outer source occurrences')
        need(table[p,side]==(side,'R',q),'Wrong rotation edge')
        need(incoming(table,q)==[[p,side,side,'R']],'Inner decoder has another entry')
        need(all(table[x,b][:2]==(b,'R')for x in(p,q)for b in(0,1)),'Rotation is not pure decoding')
        node=places[0][1]
        if side==0:
            A,B=node[0];C=node[1];replacement=(A,(B,C))
            a,b,c=table[q,0][2],table[q,1][2],table[p,1][2]
            table[p,0],table[p,1]=(0,'R',a),(1,'R',q)
            table[q,0],table[q,1]=(0,'R',b),(1,'R',c)
        else:
            A=node[0];B,C=node[1];replacement=((A,B),C)
            a,b,c=table[p,0][2],table[q,0][2],table[q,1][2]
            table[p,0],table[p,1]=(0,'R',q),(1,'R',c)
            table[q,0],table[q,1]=(0,'R',a),(1,'R',b)
        need(all(L.boundary(x)==(0,0,False)for x in(A,B,C)),'Nonclosed or halting factor')
        for path,node in places:root=L.replace(root,path,replacement)
        rows=L.sites(root)
        need([r[1:]for r in rows]==[r[1:]for r in original_rows],'Primitive word changed')
        need(L.graph_intervals(rows)==graph==L.graph_arithmetic(rows)[0],'Source CFG changed')
        ledger.append(dict(number=len(ledger)+1,phase=phase,outer=p,inner=q,side=side,
                           paths=[path for path,node in places],factor_labels=[a,b,c],
                           factor_sizes=[size(x)for x in(A,B,C)],closed=True,both_cfg_resolvers_pass=True))
    def checkpoint(name):
        stages.append(dict(stage=name,table_sha256=sha(encode(table)),source_sha256=sha((json.dumps(L.sites(root),separators=(',',':'))+'\n').encode('ascii'))))
    for p,q,s in RESEARCH:rotate('research',p,q,s)
    checkpoint('research_prefold_212')
    for p,q,s in REASSOCIATE:rotate('new_emitter_association',p,q,s)
    f=lambda q:PERMUTATION.get(q,q)
    need(set(PERMUTATION)==set(PERMUTATION.values()) and 0 not in PERMUTATION and 254 not in PERMUTATION,'Invalid label permutation')
    before_permutation=table
    table={(f(q),b):(w,d,f(z))for(q,b),(w,d,z)in table.items()}
    inverse={v:k for k,v in PERMUTATION.items()};g=lambda q:inverse.get(q,q)
    need({(g(q),b):(w,d,g(z))for(q,b),(w,d,z)in table.items()}==before_permutation,'Label isomorphism')
    checkpoint('new_emitter_shape')
    for p,q,s in RETAG:rotate('contextual_entry_tags',p,q,s)
    need(table[171,0]==(0,'L',7),'Arithmetic-entry repair premise')
    table[171,0]=(0,'L',205)
    checkpoint('two_fold_prefold_212')
    for p,q,s in CARRY:rotate('continuation_transport',p,q,s)
    census(table,212);prefold=table.copy();checkpoint('three_fold_prefold_212')
    for q,tag in [(163,0),(180,1),(220,0),(181,1),(218,0)]:
        ins=incoming(table,q)
        need(ins and all((w,d)==(tag,'R')for r,b,w,d in ins),'Missing predecessor-tag invariant')
    need(table[163,0]==(0,'R',90) and table[180,0]==(0,'R',152),'Contextual branches')
    need(table[163,1]==table[180,1]==(1,'R',211),'Contextual common branch')
    need(table[220,0]==(0,'R',218) and table[181,0]==(0,'R',147),'Research branches')
    need(table[220,1]==table[181,1]==(1,'R',176),'Research common branch')
    need(table[217,0]==(0,'R',158) and table[217,1]==(1,'R',129),'Relocated selector')
    need(table[158,0]==(0,'R',218) and table[129,0]==(0,'R',147),'Relocated selector continuations')
    quotient={180:163,181:220,218:157};m=lambda q:quotient.get(q,q)
    table={(q,b):(w,d,m(z))for(q,b),(w,d,z)in table.items()if q not in quotient}
    table[220,0]=(0,'L',217);table[163,0]=(0,'L',211)
    states=census(table,209);native=encode(table)
    need(sha(native)==EXPECTED_NATIVE_SHA,'Final U209 literal identity')
    renaming={q:i for i,q in enumerate(sorted(states))};renaming[254]=209
    dense={(renaming[q],b):(w,d,renaming[z])for(q,b),(w,d,z)in table.items()};census(dense,209,209)
    reverse={v:k for k,v in renaming.items()}
    need({(reverse[q],b):(w,d,reverse[z])for(q,b),(w,d,z)in dense.items()}==table,'Dense table isomorphism')
    rows=L.sites(root);source=(json.dumps(rows,separators=(',',':'))+'\n').encode('ascii')
    metrics=L.metrics(root)
    need(metrics==dict(dag_nodes=197,leaf_occurrences=3909,maximum_depth=42,maximum_zero_run=6),'Final source metrics')
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    for name,data in [('u209.native.tm',native),('u209.tm',encode(dense)),('rotated212.native.tm',encode(prefold)),('sites.json',source)]:
        (output/name).write_bytes(data)
    write_json(output/'state_map.json',{'native_to_dense':renaming,'dense_to_native':reverse})
    report=dict(status='EXACT_CONSTRUCTION_AND_SOURCE_PASS',working_states=209,transition_rows=418,
                start=0,blank=0,native_halt=254,dense_halt=209,rotations=30,rotation_ledger=ledger,
                label_permutation=PERMUTATION,arithmetic_entry_repair=[171,0,0,'L',205],
                quotient=quotient,changed_fold_rows=[[220,0,0,'L',217],[163,0,0,'L',211]],
                fold_incoming={q:incoming(prefold,q)for q in[163,180,220,181,218]},
                metrics=metrics,primitive_cases=5084,source_control_edges=sum(len(x[1])for x in graph),
                parent_table_sha256=sha(raw),parent_source_sha256=sha(source_raw),
                prefold_native_sha256=sha(encode(prefold)),native_sha256=sha(native),dense_sha256=sha(encode(dense)),source_sha256=sha(source),
                changed_retained_rows=[{'key':list(k),'old':list(original[k]),'new':list(v)}for k,v in sorted(table.items())if original[k]!=v],
                stages=stages,scope='Exact deterministic table reconstruction, closed source rotations, complete CFG equality, and finite census. Local fold proofs, all-natural runtime, startup, and consistency calibration are separate obligations.')
    write_json(output/'construction.json',report)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--parent-table',type=Path,required=True)
    p.add_argument('--parent-source',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();r=build(a.parent_table,a.parent_source,a.output)
    print(json.dumps({k:r[k]for k in['status','working_states','transition_rows','rotations','metrics','native_sha256','dense_sha256','source_sha256']},indent=2))
