from pathlib import Path
import importlib.util,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
import source_audit_utils as A
recipe=[(215,204,1),(217,181,1),(185,217,0),(174,185,1),(129,158,0),(217,215,1),(204,214,0),(215,129,0),(216,220,1),(217,215,0),(215,129,0),(129,204,0),(204,214,0),(214,216,0),(216,163,1),(206,199,1),(205,206,1),(7,205,1),(162,203,0),(203,223,0),(223,188,0),(188,177,0),(177,89,0),(89,174,0),(174,217,0),(217,129,0),(129,204,0),(204,214,0),(214,216,0),(216,215,0)]
table=A.read_table(ROOT/'inputs/u212.native.tm');rows=json.loads((ROOT/'inputs/u212.sites.json').read_text())
_,_,original_cfg,base_metrics=A.source_info(rows)
records=[]
for step,(p,q,side)in enumerate(recipe,1):
 branches,bd,cfg,metrics=A.source_info(rows)
 if step==18:
  roots=['0011001110101011001']
  binding,max_steps=A.prefix_binding(table,[roots[0],roots[0]+'1'])
  A.require(binding[roots[0]]==p,'literal outer prefix at grouped retag repair')
 else:
  binding,max_steps=A.prefix_binding(table,branches)
  roots=sorted(x for x,v in binding.items()if v==p)
 A.require(roots,'no actual source occurrence')
 A.require(all(not a.startswith(b)for a in roots for b in roots if a!=b),'nested occurrences')
 A.require(all(table[x,b][:2]==(b,1)for x in(p,q)for b in(0,1)),'nonpure decoder')
 A.require(table[p,side][2]==q,'inner edge')
 A.require({key for key,act in table.items()if act[2]==q}=={(p,side)},'inner entry')
 for word in roots:
  A.require(binding[word+str(side)]==q,'inner prefix binding')
  factors=[word+'00',word+'01',word+'1']if side==0 else[word+'0',word+'10',word+'11']
  A.require(all(bd[a]==(0,0,False)for a in factors),'closure')
 if side==0:
  a,b,c=table[q,0][2],table[q,1][2],table[p,1][2]
  edits={(p,0):(0,1,a),(p,1):(1,1,q),(q,0):(0,1,b),(q,1):(1,1,c)}
 else:
  a,b,c=table[p,0][2],table[q,0][2],table[q,1][2]
  edits={(p,0):(0,1,q),(p,1):(1,1,c),(q,0):(0,1,a),(q,1):(1,1,b)}
 table.update(edits);rows=A.rotate_addresses(rows,roots,side)
 if step==15:
  perm={215:129,129:204,204:214,214:216,216:215};f=lambda q:perm.get(q,q)
  table={(f(q),bit):(w,d,f(z))for(q,bit),(w,d,z)in table.items()}
 if step==18:
  A.require(table[171,0]==(0,-1,7),'entry repair');table[171,0]=(0,-1,205)
 new_br,new_bd,new_cfg,new_metrics=A.source_info(rows)
 A.require(new_cfg==original_cfg,'CFG changed')
 if step==17:
  try:A.prefix_binding(table,new_br)
  except ValueError as error:
   new_binding={};newmax=None
   records.append(dict(step=step,outer=p,inner=q,side=side,paths=roots,source_cfg_and_closure=True,literal_prefix_status='TRANSITIONAL_TABLE_NOT_ADMISSIBLE',observed_failure=str(error),metrics=new_metrics))
  else:raise ValueError('Expected construction-stage inadmissibility not reproduced')
  print('Grouped retag intermediate',step,'source CFG PASS; literal implementation deferred',flush=True)
 else:
  new_binding,newmax=A.prefix_binding(table,new_br)
  records.append(dict(step=step,outer=p,inner=q,side=side,paths=roots,internal_prefixes=len(new_binding),maximum_prefix_steps=newmax,metrics=new_metrics))
  print('Independent prefix audit',step,'PASS',len(new_binding),flush=True)
final=ROOT/'machine'
A.require(table==A.read_table(final/'rotated212.native.tm'),'prefold literal table disagreement')
A.require(rows==json.loads((final/'sites.json').read_text()),'final source disagreement')
result=dict(status='INDEPENDENT_GROUPED_SOURCE_PREFIX_AUDIT_PASS',rotations=30,final_prefixes=3908,base_metrics=base_metrics,final_metrics=new_metrics,records=records,
            source_sha256=hashlib.sha256((final/'sites.json').read_bytes()).hexdigest(),scope='Complete CFG/closure after every rotation; all actual literal prefix bindings after every completed phase. Retag stage17 is a deliberately transient inadmissible table until stage18 and entry repair; distinct from whole-runtime proof.')
(ROOT/'evidence/grouped_source_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='records'},indent=2))
