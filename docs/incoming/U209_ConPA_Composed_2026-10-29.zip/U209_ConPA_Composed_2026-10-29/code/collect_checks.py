#!/usr/bin/env python3
"""Bind runtime certificates to the exact final table and check row coverage."""
from pathlib import Path
import hashlib
import json
from source_audit_utils import read_table, require

ROOT = Path(__file__).resolve().parents[1]

def main():
    report = json.loads((ROOT / 'evidence/runtime.json').read_text())
    cases = json.loads((ROOT / 'evidence/runtime.cases.json').read_text())
    table_path = ROOT / 'machine/u209.native.tm'
    source_path = ROOT / 'machine/sites.json'
    table = read_table(table_path)
    require(report['table_sha256'] == hashlib.sha256(table_path.read_bytes()).hexdigest(), 'Runtime table identity')
    require(report['sites_sha256'] == hashlib.sha256(source_path.read_bytes()).hexdigest(), 'Runtime source identity')
    require(report['status'] == 'NATIVE_UNIVERSAL_MATHEMATICAL_PASS', 'Runtime did not pass')
    require(report['cases'] == len(cases) == 5084, 'Runtime case count')
    used = {tuple(row) for case in cases for row in case['rows']}
    for block in report['blocks']:
        used.update(tuple(event[1][:2]) for event in block['trace'])
    require(used == set(table), 'Literal row coverage')
    require(len(table) == 418, 'Final row count')
    for case in cases:
        require(all(x >= 0 for x in case['duration']) and case['duration'][0] > 0,
                'A contract lacks positive finite duration')
    result = {'status': 'ALL_FINAL_RUNTIME_OBLIGATIONS_PASS', 'working_states': 209,
              'transition_rows': 418, 'literal_rows_covered': len(used),
              'primitive_occurrences': 3909, 'guarded_cases': len(cases),
              'symbolic_steps': sum(c['symbolic_steps'] for c in cases),
              'minimum_duration_constant': min(c['duration'][0] for c in cases),
              'native_sha256': report['table_sha256'], 'source_sha256': report['sites_sha256'],
              'proof_status': 'Executable symbolic induction supporting an ordinary mathematical proof; no exported PA kernel certificate.'}
    (ROOT / 'evidence/verification_summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
