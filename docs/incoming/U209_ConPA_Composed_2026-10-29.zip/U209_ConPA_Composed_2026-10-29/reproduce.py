#!/usr/bin/env python3
"""Offline deterministic rebuild and verification of the U209 candidate."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent

def run(*args):
    print('>>> ' + ' '.join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), cwd=ROOT, check=True,
                   env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick', action='store_true', help='Explicitly omit the unbounded symbolic-runtime replay')
    parser.add_argument('--pdf', action='store_true', help='Also compile the report with pdflatex')
    args = parser.parse_args()
    if not __debug__ or sys.flags.optimize or os.getenv('PYTHONOPTIMIZE'):
        raise RuntimeError('Reproduction requires enabled assertions; do not use -O or PYTHONOPTIMIZE.')
    started = time.monotonic()
    count = 0
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Frozen input changed: ' + name)
        count += 1
    print(f'Frozen hashes passed: {count} files', flush=True)
    py = sys.executable
    run(py, 'code/build_u209.py', '--parent-table', 'inputs/u212.native.tm',
        '--parent-source', 'inputs/u212.sites.json', '--output', 'machine')
    run(py, 'code/verify_source.py')
    run(py, 'code/verify_grouped_source.py')
    run(py, 'code/verify_fold.py', '--root', 'machine', '--baseline-table', 'inputs/u212.native.tm', '--output', 'evidence/fold.json')
    run(py, '-O', 'code/verify_fold.py', '--root', 'machine', '--baseline-table', 'inputs/u212.native.tm', '--output', 'evidence/fold.json')
    run(py, 'code/verify_fold_independent.py', '--root', 'machine', '--output', 'evidence/independent_fold.json')
    run(py, 'code/verify_startup.py', '--baseline-table', 'inputs/u212.native.tm',
        '--baseline-source', 'inputs/u212.sites.json', '--candidate', 'machine', '--output', 'evidence/startup.json')
    if not args.quick:
        run(py, 'code/runtime/check_runtime.py', '--table', 'machine/u209.native.tm',
            '--sites', 'machine/sites.json', '--output', 'evidence/runtime.json')
        run(py, 'code/collect_checks.py')
    if args.pdf:
        for _ in range(2):
            run('pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex')
    result = {'status': 'QUICK_PASS_RUNTIME_SKIPPED' if args.quick else 'FULL_REPRODUCTION_PASS',
              'runtime_replayed_this_run': not args.quick, 'frozen_hashes_checked': count,
              'seconds': round(time.monotonic() - started, 3),
              'scope': 'Construction, source, local fold, startup, and (unless --quick) symbolic runtime. Inherited arithmetic calibration is retained mathematical evidence, not rechecked in a proof-assistant kernel.'}
    (ROOT / 'evidence/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
