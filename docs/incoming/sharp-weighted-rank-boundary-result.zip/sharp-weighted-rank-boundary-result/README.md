# Weighted matching-rank boundaries: independent verification and refinements

## Attribution comes first

The pinned ProveIt intake manuscript **Weighted Rank Five and Covers with a Two Vertex Shore** already contains the sharp weighted rank-five threshold, the complete-block scalar counterexamples at rank six and every higher rank, and the rank-compression graph lift. The scalar part of this package is an independent reconstruction and extra exact verification of those results. It is not claimed as new to the intake. See `INTAKE_COMPARISON.md` for the exact source, commit, hashes and scope comparison.

The incoming source programs are not executed. The intake is a user-repository research manuscript, not a peer-reviewed reference. No global priority claim is made.

## Mathematical contents

1. Complete-block support counting gives exact weighted ULC failures at every actual rank at least six. The primary displayed example has 86 vertices, positive core activity 10000 and exterior activity 1. Its rescaled coefficient sequence is [1, 90240, 907219080, 1024191381360, 161879846800, 6130238400, 97614400], and its last degree-six gap is -1722535205514240000. A 72-vertex variant is also checked. These constructions already occur in the cited intake.
2. The unchanged ordinary theorem through actual rank five is included as a small frozen dependency and readable PDF. Together, these establish the sharp universal weighted rank threshold. The examples are also vertex-weighted height-two orders. No minimum-vertex or unweighted-counterexample claim is made here.
3. Separate small exact examples obstruct the natural three-distinguished-element transform, the selected-tail 3+3 graph homogenization and its three-variable specialization. Their own scalar polynomials are strictly rank-six ULC. The abstract nontransversal seed is lifted through an explicit transversal contraction; the graph failure is independently verified directly.
4. An ordinary Gram-matrix and random-partition proof establishes a first-layer PSD inequality for any number of tails. Combining it with Wagner's published rank-three Rayleigh theorem supplies an ordinary certificate-free proof of the full selected-tail cubic already stated in the intake's three-vertex marginal paper.
5. An appendix extends the intake's two-slot rank-compression lift to every finite matroid via matroid union. It supplies a short proof of the previously delivered unrestricted two-element theorem, without a representation, old-spanning hypothesis or low-rank induction. The six-case construction is explicitly credited to the intake.

Endpoint supports are pairs of matchable endpoint sets, each counted once regardless of matching witnesses. All comparisons distinguish cover-order homogenization from normalization by actual surviving degree. No physical tail/head collision merge is inferred.

## Files

- `article/sharp-weighted-rank-boundary.pdf` and `.tex`: integrated paper and editable source
- `INTAKE_COMPARISON.md`: source attribution and bounded comparison
- `proof-notes/`: unchanged approved detailed derivations, including their historical status wording
- `audits/`: source-bound mathematical approvals and final integrated review
- `reproducibility/`: exact checkers and deterministic receipts for the new material
- `dependencies/two-element-matroid-lorentzian-result.zip`: unchanged, previously approved ordinary rank-five proof package
- `dependencies/rank-five-proof.pdf`: byte-identical readable PDF from that dependency
- `qa/visual-qa.json`: final all-page PDF inspection record

Historical submitted-status sentences are superseded by the included approvals. The scalar note records the independent derivation before intake comparison; the integrated paper and `INTAKE_COMPARISON.md` provide the current attribution. Historical absolute paths identify source originals; the replay resolves packaged copies by exact hashes. Explicitly historical previous-source hashes are preserved as provenance, not claimed as current packaged sources.

## Full replay

Use Python 3.11 or newer and SymPy 1.14.0, then run:

    python verify.py

The new checkers use only the standard library; SymPy is needed by the unchanged older proof dependency. The driver verifies exact manifest coverage, every current approval/dependency pin, the PDF QA hash, safe extraction and complete nested replay of the prior package, and all current checkers. Every deterministic receipt field must match; only elapsed timings are excluded. Python `-O` is rejected. All checkers run from temporary copies, and no released file is changed. No network, numerical optimizer or incoming manuscript code is used.

Independent scalar verification checks all 78 quota Hall cases, both seven-term sequences and the symbolic parameter factorization. The direct-union appendix is corroborated by 1,672 specialization identities over 337,428 candidate bases, including 352 exact zero-parameter interpolation checks. Independent graph obstruction recounts test 1,716 endpoint candidates and find 397 supports at each of two activity choices; an abstract union recount finds 109 bases among 210 candidates. The all-rank matrix proof is corroborated by 2,800 weighted cases and 8,400 exact PSD tests; a separate three-tail check runs 6,602 cases and 46,214 principal-minor checks. The ordinary proofs, including the all-higher-ranks existence argument, do not depend on random search.

To rebuild the supplied PDF with a standard TeX Live installation, run `sh build.sh`. Byte-identical recompilation is not promised because TeX metadata may vary. No proof-assistant formalization or external publication is asserted. All earlier released packages remain unchanged.
