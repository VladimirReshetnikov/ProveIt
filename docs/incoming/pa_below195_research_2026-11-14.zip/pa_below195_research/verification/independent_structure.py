#!/usr/bin/env python3
"""Independent finite audits for an AX-reader allocation.

This deliberately does not import the searcher, compiler, or symbolic runtime.
It cannot replace the complete symbolic-runtime replay: source path scanner
constraints are independent of source instruction/control-flow identity.
"""
from pathlib import Path
import argparse, json, re, hashlib, collections

MACROS={'node65':90,'node55':98,'node58':12,'node70':166,
        'node49':19,'node72':69,'node75':213,'node142':194,'node150':221,
        ('leaf','inc',1):61,'node60':99,'node61':190}
I=('leaf','inc',1)
MACROS[I,I]=99
MACROS[(I,I),(I,I)]=190
TOKEN={'node49':'push','node55':'copyD','node58':'copyH','node70':'copyA',
       'node65':'cons','node72':'readH','node75':'readDCons',
       'node142':'copyGuard','node150':'compareGuard',
       I:'incT',('leaf','breakTo',1):'close'}

def check(p,why):
    if not p:raise ValueError(why)

def read_table(path):
    out={}
    for line in path.read_text().splitlines():
        if not line.strip() or line.startswith('#'):continue
        q,b,w,d,n=line.split();q,b,w,n=map(int,(q,b,w,n))
        check((q,b)not in out,'duplicate table key')
        check(b in (0,1) and w in (0,1) and d in ('L','R'),'binary table syntax')
        out[q,b]=(w,d,n)
    check(all((q,1-b)in out for q,b in out),'missing read branch')
    return out

def grammar(path):
    d=json.loads(path.read_text());done={};active=set()
    def get(x):
        if isinstance(x,list):
            check(len(x)==3 and x[0]=='leaf','bad primitive leaf')
            return tuple(x)
        if x not in d['rules']:return x
        check(x not in active,'cyclic grammar')
        if x in done:return done[x]
        active.add(x);children=d['rules'][x]
        check(len(children)==2,'nonbinary grammar')
        y=tuple(get(z)for z in children);active.remove(x);done[x]=y
        return y
    return get(d['root'])

def is_node(x):return isinstance(x,tuple)and len(x)==2

def tokenword(t):
    if t=='node60':return ['incT']*2
    if t=='node61':return ['incT']*4
    if is_node(t):return tokenword(t[0])+tokenword(t[1])
    return [TOKEN[t]]

def macro_entry_screen(t):
    rows=[]
    def visit(x,path):
        if x in ('node72','node142'):
            expected=0 if x=='node72'else 1
            rows.append({'macro':x,'path':''.join(map(str,path)),
                         'required_last_bit':expected,
                         'ok':bool(path)and path[-1]==expected})
        if is_node(x):visit(x[0],path+(0,));visit(x[1],path+(1,))
    visit(t,())
    check({x['macro']for x in rows}=={'node72','node142'},'missing constrained macro')
    return rows

def rebuild(t,baseline_raw):
    rows={k:v for k,v in baseline_raw.items()if k[0]<1300};states={}
    def visit(x):
        if x in MACROS:return MACROS[x]
        check(is_node(x),'unknown macro')
        if x in states:return states[x]
        q=2000+len(states);states[x]=q
        for bit,y in enumerate(x):
            rows[q,bit]=(0,'L',302)if y==('leaf','breakTo',1)else(bit,'R',visit(y))
        return q
    rows[101,1]=(1,'R',visit(t))
    return rows,states

def read_program(path):
    nodes={}
    for line in path.read_text().splitlines():
        match=re.fullmatch(r'def (\w+) : Tree := \.node (.*)',line)
        if not match:continue
        expr=match[2]
        # The checked fixture uses only named children or literal leaves.
        terms=[];pos=0
        while pos<len(expr):
            if expr[pos].isspace():pos+=1;continue
            leaf=re.match(r'\(\.leaf \(\.(inc|dec|breakTo|continueTo|halt)(?: (\d+))?\)\)',expr[pos:])
            if leaf:
                terms.append(('leaf',leaf[1],int(leaf[2])if leaf[2]is not None else None));pos+=leaf.end();continue
            name=re.match(r'(node\d+|x\d+)',expr[pos:])
            check(name is not None,'unparsed source term')
            terms.append(name[1]);pos+=name.end()
        check(len(terms)==2,'nonbinary source node');nodes[match[1]]=tuple(terms)
    return nodes

def source(t,nodes):
    leaves=[];spans={}
    def expand(x,path):
        if isinstance(x,str):return expand(t if x=='x67'else nodes[x],path)
        start=len(leaves)
        if len(x)==3:
            check(x[0]=='leaf','bad source leaf');leaves.append((path,x[1],x[2]))
        else:
            expand(x[0],path+(0,));expand(x[1],path+(1,))
        spans[path]=(start,len(leaves))
    expand('node172',())
    code=[];count=len(leaves)
    for i,(p,op,arg)in enumerate(leaves):
        def ancestor(edge,k):
            for j in range(len(p)-1,-1,-1):
                if p[j]==edge:
                    k-=1
                    if k==0:return spans[p[:j]]
            raise ValueError('missing lexical ancestor')
        after=(i+1)%count
        if op=='inc':ins=['inc',arg,after]
        elif op=='dec':ins=['dec',arg,ancestor(0,1)[1]%count,after]
        elif op=='breakTo':ins=['jump',ancestor(0,arg)[1]%count]
        elif op=='continueTo':ins=['jump',ancestor(1,arg)[0]]
        else:check(op=='halt','unknown operation');ins=['halt']
        code.append(ins)
    return leaves,code

def fold_audit(raw,folds):
    delete={};keepers={};history={}
    for a,b,aa in folds:
        check(a not in history and b not in history and a!=b,'overlapping folds')
        delete[a]=b;history[a]=0;history[b]=1
        keepers[b]=[(w,'R'if d else'L',n)for w,d,n in aa]
    check(not{74,254}&history.keys(),'start or terminal folded')
    out={}
    for (q,bit),act in raw.items():
        if q in delete:continue
        w,d,n=keepers[q][bit]if q in keepers else act
        out[q,bit]=(w,d,delete.get(n,n))
    incoming=[]
    for key,(w,d,n)in raw.items():
        if n in history:
            check(d=='R'and w==history[n],'entry-history mismatch')
            incoming.append([*key,w,d,n,history[n]])
    check(set(history)=={x[4]for x in incoming},'unentered folded role')
    for key,(w,d,n)in raw.items():
        if key[0]not in history:
            check(out[key]==(w,d,delete.get(n,n)),'untouched row mismatch')
    traces=[]
    for q,leftbit in sorted(history.items()):
        for bit in (0,1):
            w,d,n=raw[q,bit]
            desired=(delete.get(n,n),1 if d=='R'else-1,{ -1:leftbit,0:w})
            state=delete.get(q,q);head=0;tape={-1:leftbit,0:bit};steps=[]
            while True:
                if steps and (state,head,tape)==desired:break
                check(len(steps)<64,'nonterminating local trace')
                check(head in (-1,0),'read outside two-cell window')
                rd=tape[head];ww,dd,nn=out[state,rd]
                steps.append([state,head,rd,ww,dd,nn])
                tape[head]=ww;head+=1 if dd=='R'else-1;state=nn
            traces.append({'role':q,'history':leftbit,'read':bit,'steps':steps})
    return out,incoming,traces

def concrete_seed(dense,labels,expected,source_path):
    check(expected['native_state']==84,'startup is not a source frame')
    physical=expected['physical_register_file'];gap=expected['header_gap']
    check(physical[:9]==[0,0,0,0,0,0,2,0,0]and len(physical)>=10,
          'startup logical registers differ')
    check(all(isinstance(v,int)and v>=0 for v in physical),'negative register')
    check(gap>=48 and gap>=len(source_path),'startup gap too short')
    anchor=expected['absolute_head']
    frame_ones={anchor-1,anchor+gap}
    frame_ones.update(anchor+i for i,bit in enumerate(source_path)if bit)
    cursor=anchor+gap+1
    for value in physical:
        cursor+=1;frame_ones.update(range(cursor,cursor+value+1));cursor+=value+1
    check(set(expected['complete_one_positions'])==frame_ones,
          'startup certificate is not the whole required source frame')
    state=0;head=0;ones=set()
    steps=expected['literal_steps']
    for tick in range(steps):
        check((state,int(head in ones))in dense,'premature startup halt')
        w,d,state=dense[state,int(head in ones)]
        if w:ones.add(head)
        else:ones.discard(head)
        head+=1 if d=='R'else-1
    check(labels[state]==expected['native_state'],'startup control mismatch')
    check(head==expected['absolute_head'],'startup head mismatch')
    check(ones==set(expected['complete_one_positions']),'startup whole-tape mismatch')
    return {'literal_steps':steps,'native_state':labels[state],
            'absolute_head':head,'complete_one_positions':sorted(ones),
            'outside_tape_all_zero':True}

def standard_presentation(native,dense,labels):
    n=len(native)//2
    check(len(labels)==n+1 and len(set(labels))==n+1,'bad label bijection')
    check(labels[0]==74 and labels[n]==254,'start or terminal label mismatch')
    check(set(dense)=={(q,b)for q in range(n)for b in (0,1)},'dense working-state domain')
    check(all(0<=x[2]<=n for x in dense.values()),'unknown dense transition target')
    check({(labels[q],b):(w,d,labels[r])for(q,b),(w,d,r)in dense.items()}==native,
          'dense/native table mismatch')
    seen={0};pending=[0]
    for q in pending:
        for bit in (0,1):
            r=dense[q,bit][2]
            if r<n and r not in seen:seen.add(r);pending.append(r)
    check(seen==set(range(n)),'advertised state not graph reachable')
    return n

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('grammar',type=Path);ap.add_argument('folds',type=Path)
    ap.add_argument('--reference',type=Path,default=Path(__file__).resolve().parents[1]/'reference/pa195')
    ap.add_argument('--native',type=Path)
    ap.add_argument('--raw',type=Path)
    ap.add_argument('--dense',type=Path)
    ap.add_argument('--labels',type=Path)
    ap.add_argument('--startup',type=Path)
    ap.add_argument('--candidate-source',type=Path)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args();ref=args.reference
    t=grammar(args.grammar);raw,states=rebuild(t,read_table(ref/'unfolded202.native.tm'))
    folds=json.loads(args.folds.read_text());out,incoming,traces=fold_audit(raw,folds)
    if args.native:check(out==read_table(args.native),'literal candidate/native mismatch')
    if args.raw:check(raw==read_table(args.raw),'literal unfolded table mismatch')
    word=tokenword(t);check(word==json.loads((ref/'emitter_tokens.json').read_text()),'emitter word changed')
    sites,code=source(t,read_program(ref/'vendor/reference/PA196/Program.lean'))
    expected=json.loads((ref/'source.json').read_text())
    check(len(sites)==len(expected),'source length changed')
    check(all((op,arg)==(e['op'],e['arg'])for(_,op,arg),e in zip(sites,expected)),'instruction word changed')
    check(code==[e['instruction']for e in expected],'source control-flow changed')
    if args.candidate_source:
        written=json.loads(args.candidate_source.read_text())
        check(written==[{'ordinal':i,'path':''.join(map(str,p)),'op':op,'arg':arg,
                        'instruction':code[i]}for i,(p,op,arg)in enumerate(sites)],
              'candidate expanded source artifact mismatch')
    longest=max(len(p)for p,op,arg in sites)
    zero=max(len(z)for p,op,arg in sites for z in re.findall('0+',''.join(map(str,p)))or[''])
    entries=macro_entry_screen(t)
    receipt={'raw_working_states':len(raw)//2,'reader_nodes':len(states),'folds':len(folds),
      'working_states':len(out)//2,'incoming_history_rows':len(incoming),
      'local_cases':len(traces),'durations':dict(collections.Counter(len(x['steps'])for x in traces)),
      'primitive_sites':len(sites),'emitter_tokens':len(word),'ordered_word_equal':True,
      'all_ordinal_successors_equal':True,'maximum_path_length':longest,'maximum_zero_run':zero,
      'scanner_screen':longest<=48 and zero<=6,'macro_entry_conditions':entries,
      'macro_entry_screen':all(x['ok']for x in entries),'full_runtime_still_required':True,
      'grammar_sha256':hashlib.sha256(args.grammar.read_bytes()).hexdigest()}
    if args.dense or args.labels:
        check(args.dense is not None and args.labels is not None,'dense table requires labels')
        dense=read_table(args.dense);labels=json.loads(args.labels.read_text())
        receipt['graph_reachable_working_states']=standard_presentation(out,dense,labels)
        expected_seed=json.loads((args.startup or ref/'startup_certificate.json').read_text())
        receipt['startup']=concrete_seed(dense,labels,expected_seed,sites[25][0])
        receipt['literal_sha256']=hashlib.sha256(args.dense.read_bytes()).hexdigest()
    if args.output:args.output.write_text(json.dumps({'receipt':receipt,'incoming':incoming,'traces':traces},indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
