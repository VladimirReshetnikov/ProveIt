# An audited search below PA195

**The strict target is unmet: this archive does not contain a verified machine
with fewer than 195 working states whose nonhalting is PA-provably equivalent
to Con(PA).** The strongest retained construction is the supplied PA195.
The 194-state table under `construction/rejected194/` is an explicitly rejected
proof candidate, included to reproduce an instructive failure.

## Main deliverable

Read `report/pa_below195_research_report.pdf`. Its complete TeX source and
appendices are in the same directory. The report provides:

- a comparison of 31 incoming archives at the pinned ProveIt revision;
- a fresh full PA195 finite verification and an independent structural,
  control-flow, local-fold, and whole-tape startup checker;
- a locally certified 194-state allocation whose intended source refinement
  fails, together with a literal 103-transition counterexample;
- explicit counterinterpretations ruling out direct deletion of logical
  heads 1, 3, 4, and 5 from the specified remaining numerical calculus;
- completed, precisely restricted negative search results, programs, exact
  inputs, and receipts;
- an audit separating PA's internal consistency biconditional from finite
  executable checks and from the narrower imported Lean endpoint.

No global lower bound is claimed. Failure of the 194-state candidate's proposed
primitive refinement does not, by itself, refute its arithmetic equivalence to
consistency. No new Lean or Rocq theorem was compiled.

## Verification

From the extracted archive root, using Python 3 without `-O`:

```sh
python3 verify.py
```

Only the Python standard library is needed. The default command runs both
complete PA195 symbolic contract lists (4,815 branches each), all structural
checks, exact blank startup, the 31 designated 196-state graph classifications,
both negative symbolic checks, and the independent
literal 103-transition counterexample. It does not require a solver, network
access, or a proof-assistant installation. Progress goes to standard error and
the JSON receipt goes to standard output. The expected overall status is:

```text
AUDIT PASSED; THE SUB-195 CONSTRUCTION GOAL REMAINS UNMET
```

This status means that the positive reference checks succeeded **and** the
negative control failed at exactly the documented obligation. It does not
mean that a new sub-195 consistency machine was found.

`python3 verify.py --quick` omits the two long positive runtime lists; it is
not the full verification. `python3 verify.py --manifest-only` checks the
finalized SHA-256 file manifest. The fresh full result is recorded in
`verification/packaged_verification.json`.

For the rejected table, the native start label is 74 and the halt label is 254.
The canonical dense table has start 0, working labels 0 through 193, and halt
194. For the retained PA195, working labels are 0 through 194 and halt is 195.
Rows have the form `current read write L-or-R next`. The halt label is distinct
and is not counted as a working state.

## Optional searches

`reproduce_searches.py --help` documents portable wrappers for the final grammar
search and the strongest coupled-row synthesis. The latter requires `g++`
with C++17 support; the grammar wrapper uses the Python standard library.
The wrappers stage files in an isolated workspace and leave the supplied
input files unchanged. Logs and results default to a new directory under
`./reproduced_searches/`; `--output-dir` selects another destination. Search outputs are research specimens, never automatically accepted
as consistency machines.

The final grammar program evolved during exploration. Its fixed witnesses and
their verifiers are deterministic; an old random seed and iteration count are
not a promise to recreate an earlier development version's exact trajectory.
Historical logs are observations from the runs described, not certificates of
global optimality. Counts of iterations include repeated and screened-out
proposals. The 66 helper-search inputs and 61 coupled-search inputs are
structurally screened search tables, not 66 or 61 newly proved PA machines.

Additional exploratory programs and their logs are preserved under `search/`.
Some use the original `work/` research layout or optional packages such as
`z3-solver`; they are not dependencies of `verify.py`. The explicit two-helper
enumerator imports Z3 through shared setup even though it invokes no solver.
Re-running the full corpus inventory additionally requires the 31 upstream
ZIP archives identified in `comparison/current_archives.json`; the normalized
selected tables are included and independently checked by `verify.py`.
Each search receipt is limited to the family specified in its accompanying
audit. SAT timeouts mean UNKNOWN, never UNSAT.

## Contents

| Path | Purpose |
| --- | --- |
| `report/` | New report, TeX appendices, PDF, and audited-source hashes |
| `reference/pa195/` | Supplied 195-state table, grammar, complete builder, and vendored inputs |
| `reference/original_pa195_report/` | Unmodified supplied PA195 article and its TeX sections |
| `reference/reference_sources/` | Pinned Lean source excerpts used in the calibration audit |
| `construction/rejected194/` | Rejected 194-state table, grammar, folds, and local certificate |
| `verification/` | Independent verifier and positive/negative receipts |
| `comparison/` | Archive inventory, designated literal tables, graph classifications, provenance checks |
| `search/` | Search programs, exact inputs, and bounded-family receipts |
| `verify.py` | Portable positive and negative audit entry point |
| `reproduce_searches.py` | Portable optional search entry point |
| `SHA256SUMS` | Digests of the finalized delivered files |

## Sources and attribution

The ProveIt source snapshot is commit
`5be8b9236df6a6d308195e62a906a173dc70d00a`:

- <https://github.com/VladimirReshetnikov/ProveIt/tree/5be8b9236df6a6d308195e62a906a173dc70d00a/Computability/BusyBeaver/Research/PA>
- <https://github.com/VladimirReshetnikov/ProveIt/tree/5be8b9236df6a6d308195e62a906a173dc70d00a/docs/incoming>
- <https://github.com/VladimirReshetnikov/ProveIt/tree/5be8b9236df6a6d308195e62a906a173dc70d00a/Computability/BusyBeaver/Research/ZFC>
- <https://github.com/VladimirReshetnikov/ProveIt/tree/5be8b9236df6a6d308195e62a906a173dc70d00a/Logic/PrimitiveRecursiveArithmetic/ConciseIPRA>

The inspected James Chang development is commit
`407cdc356f6b586635e71ac92be394255f4bfea4` of
<https://github.com/jamesyc/BusyBeaver>.

The retained literal PA195 table has SHA-256:

```text
5c6afd87f7c4f24d9ad8e9e302cc21df14b6f2e3715d03322a75463a431d8455
```

Original license notices are retained in `reference/pa195/vendor/`. Original
PA195 materials are reference inputs, not newly authored results of this
investigation. The new report is dated 14 November 2026; dates embedded in
upstream filenames remain their original source identifiers.

To compile the new report with a standard TeX installation:

```sh
cd report
pdflatex -interaction=nonstopmode -halt-on-error pa_below195_research_report.tex
pdflatex -interaction=nonstopmode -halt-on-error pa_below195_research_report.tex
```
