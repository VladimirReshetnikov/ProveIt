#!/usr/bin/env python3
"""Replay the positive PA195 audit and the rejected 194-state negative control.

Python 3 standard library only. Run without -O. The default replays both
complete PA195 symbolic contract lists; --quick omits those lists only.
This is a finite executable audit, not a proof-assistant kernel theorem.
No file in this archive is modified. JSON goes to stdout; progress to stderr.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REF = ROOT / "reference" / "pa195"
NEG = ROOT / "construction" / "rejected194"
AUDIT = ROOT / "verification" / "independent_structure.py"
EXPECTED_SHA = "5c6afd87f7c4f24d9ad8e9e302cc21df14b6f2e3715d03322a75463a431d8455"
sys.dont_write_bytecode = True


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text())


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run_json(args):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    result = subprocess.run([sys.executable, "-B", *map(str, args)],
                            cwd=ROOT, env=env, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError("Command failed: " + " ".join(map(str, args)) +
                           "\n" + result.stdout + result.stderr)
    return json.loads(result.stdout)


def check_manifest():
    manifest = ROOT / "SHA256SUMS"
    if not manifest.exists():
        return {"present": False, "explanation": "Manifest added when package is finalized."}
    count = 0
    for line in manifest.read_text().splitlines():
        digest, name = line.split("  ", 1)
        path = (ROOT / name).resolve()
        need(ROOT in path.parents and path.is_file(), "Invalid manifest path: " + name)
        need(hashlib.sha256(path.read_bytes()).hexdigest() == digest,
             "Manifest digest mismatch: " + name)
        count += 1
    return {"present": True, "all_recorded_digests_match": True, "files": count}


def frame(path, registers, gap=48):
    need(len(path) <= gap, "Path does not fit the frame")
    ones = {-1, gap}
    ones.update(i for i, bit in enumerate(path) if bit)
    cursor = gap + 1
    for value in registers:
        need(isinstance(value, int) and value >= 0, "Invalid register value")
        cursor += 1
        ones.update(range(cursor, cursor + value + 1))
        cursor += value + 1
    return ones


def literal_negative_control(audit):
    fixture = read_json(ROOT / "verification" / "rejected194_concrete_frame.json")
    tree = audit.grammar(NEG / "grammar.json")
    nodes = audit.read_program(REF / "vendor/reference/PA196/Program.lean")
    sites, code = audit.source(tree, nodes)
    need(code[131] == ["dec", 8, 139, 132], "Wrong source-131 operation")
    path = sites[131][0]
    target_path = sites[139][0]
    need("".join(map(str, path)) == "101010010100000000", "Wrong initial address")
    need("".join(map(str, target_path)) == "101010010100000010", "Wrong target address")
    registers = [0] * 35
    initial = frame(path, registers)
    expected = frame(target_path, registers)
    need(initial == set(fixture["initial_ones"]), "Initial frame does not match fixture")
    need(expected == set(fixture["expected_ones"]), "Expected frame does not match fixture")
    need(registers == fixture["physical_register_file"], "Wrong physical registers")
    rows = audit.read_table(NEG / "rejected194.native.tm")
    dense = audit.read_table(NEG / "rejected194.tm")
    labels = read_json(NEG / "labels.json")
    reachable = audit.standard_presentation(rows, dense, labels)
    need(reachable == 194, "Wrong rejected-candidate graph census")
    state, head, ones = 84, 0, set(initial)
    trace = []
    for step in range(1, 104):
        bit = int(head in ones)
        write, direction, target = rows[state, bit]
        trace.append([state, head, bit, write, direction, target])
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head += 1 if direction == "R" else -1
        state = target
        if step < 103:
            need(state != 84, "An earlier return to native control 84 occurred")
    need((state, head) == (84, 19), "Wrong 103-step endpoint")
    need(ones == set(fixture["actual_ones"]), "Wrong actual full tape")
    need((state, head, ones) != (84, 0, expected), "Negative control unexpectedly passed")
    trace_digest = hashlib.sha256(json.dumps(trace, separators=(",", ":")).encode()).hexdigest()
    return {"graph_reachable_working_states": reachable,
            "site": 131, "branch": "zero", "logical_register": 8,
            "first_return_literal_steps": 103,
            "expected_native_state": 84, "actual_native_state": state,
            "expected_head": 0, "actual_head": head,
            "expected_and_actual_full_tapes_differ": ones != expected,
            "trace_sha256": trace_digest,
            "claimed_primitive_refinement_refuted": True,
            "arithmetic_equivalence_refuted": False}


def symbolic_negative_control():
    # This uses the supplied symbolic runtime; the literal replay above does not.
    builder = load_module("pa195_reference_builder", REF / "build_verify.py")
    compiler = builder.c
    tree = compiler.read_grammar(NEG / "grammar.json")
    _, _, contracts = compiler.source(tree)
    results = {}
    for key, filename in [("unfolded", "unfolded202.native.tm"),
                          ("folded", "rejected194.native.tm")]:
        result = compiler.validate(builder.table(NEG / filename), contracts)
        need(result["ok"] is False and result["failed"] == (131, (1, True))
             and result["completed"] == 175,
             "Rejected candidate did not fail at the expected symbolic contract")
        results[key] = result
    return results


def selected_designs_check(audit):
    designs = read_json(ROOT / "comparison" / "selected_designs.json")
    classes = set()
    selected196 = 0
    for design in designs:
        path = ROOT / design["packaged_path"]
        need(hashlib.sha256(path.read_bytes()).hexdigest() == design["sha256"],
             "Designated comparison table hash differs: " + design["name"])
        rows = audit.read_table(path)
        n = design["states"]
        need(set(rows) == {(q, b) for q in range(n) for b in (0, 1)},
             "Comparison table is not the stated dense presentation")
        halts = {target for write, direction, target in rows.values()} - set(range(n))
        need(len(halts) == 1, "Comparison table lacks a unique terminal label")
        halt = halts.pop()
        ids, queue, canonical = {0: 0}, [0], []
        for state in queue:
            for bit in (0, 1):
                write, direction, target = rows[state, bit]
                if target == halt:
                    target = -1
                else:
                    if target not in ids:
                        ids[target] = len(ids)
                        queue.append(target)
                    target = ids[target]
                canonical.append([ids[state], bit, write, direction, target])
        need(len(ids) == n, "Comparison table has an unreachable working state")
        digest = hashlib.sha256(json.dumps(canonical, separators=(",", ":")).encode()).hexdigest()
        need(digest == design["rooted_hash"], "Rooted comparison hash differs")
        need(digest not in classes, "Duplicate designated rooted graph")
        classes.add(digest)
        selected196 += n == 196
    need(selected196 == 31 and len(designs) == 32, "Wrong designated-table census")
    return {"selected196_tables": selected196, "selected196_graph_classes": 31,
            "additional_pa195_reference": 1, "all_literal_and_rooted_hashes_match": True,
            "all_working_states_graph_reachable": True,
            "new_arithmetic_calibration_claim": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick", action="store_true",
                        help="omit the two full PA195 symbolic contract lists")
    parser.add_argument("--manifest-only", action="store_true",
                        help="check the finalized SHA-256 manifest only")
    args = parser.parse_args()
    need(__debug__ and not sys.flags.optimize, "Run Python without -O")
    manifest = check_manifest()
    if args.manifest_only:
        need(manifest["present"], "No finalized manifest")
        print(json.dumps(manifest, indent=2))
        return

    print("Replaying supplied PA195 verifier...", file=sys.stderr, flush=True)
    baseline = run_json([REF / "build_verify.py", *(["--quick"] if args.quick else [])])
    need(baseline["working_states"] == 195 and baseline["literal_sha256"] == EXPECTED_SHA,
         "Unexpected PA195 table")
    if not args.quick:
        need(all(baseline[k]["ok"] and baseline[k]["contracts"] == 4815
                 for k in ("unfolded_runtime", "folded_runtime")),
             "Incomplete positive symbolic replay")
    print("Replaying independent structural and blank-start audit...", file=sys.stderr, flush=True)
    positive = run_json([AUDIT, REF / "grammar.json", REF / "folds.json",
                         "--reference", REF, "--raw", REF / "unfolded202.native.tm",
                         "--native", REF / "pa195.native.tm", "--dense", REF / "pa195.tm",
                         "--labels", REF / "labels.json", "--startup", REF / "startup_certificate.json",
                         "--candidate-source", REF / "source.json"])
    need(positive["working_states"] == 195 and positive["local_cases"] == 28
         and positive["scanner_screen"] and positive["macro_entry_screen"],
         "Positive independent audit failed")
    need(positive["startup"]["literal_steps"] == 58154, "Wrong blank startup")
    print("Replaying rejected 194-state negative control...", file=sys.stderr, flush=True)
    negative = run_json([AUDIT, NEG / "grammar.json", NEG / "folds.json",
                         "--reference", REF, "--raw", NEG / "unfolded202.native.tm",
                         "--native", NEG / "rejected194.native.tm"])
    need(negative["working_states"] == 194 and negative["local_cases"] == 32
         and negative["ordered_word_equal"] and negative["all_ordinal_successors_equal"]
         and negative["scanner_screen"] is False and negative["maximum_zero_run"] == 8,
         "Wrong structural outcome for the rejected 194-state candidate")
    audit = load_module("independent_structure_audit", AUDIT)
    concrete = literal_negative_control(audit)
    symbolic = symbolic_negative_control()
    comparison = selected_designs_check(audit)
    output = {
        "status": "AUDIT PASSED; THE SUB-195 CONSTRUCTION GOAL REMAINS UNMET",
        "quick": args.quick,
        "manifest": manifest,
        "positive_baseline": baseline,
        "independent_positive": positive,
        "rejected194_structure": negative,
        "rejected194_symbolic_failure": symbolic,
        "rejected194_literal_failure": concrete,
        "designated_comparison_tables": comparison,
        "new_sub195_consistency_machine": False,
        "new_kernel_checked_theorem": False,
        "global_minimality_claim": False,
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
