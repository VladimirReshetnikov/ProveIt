#!/usr/bin/env python3
"""Exhaust all helper pairs after a proved matching-count prefilter."""
source=__import__('pathlib').Path(__file__).with_name('two_helpers.py').read_text().split('solver=z3.Solver()')[0]
exec(compile(source,__file__,'exec'))
base=[];single=collections.defaultdict(set);joint=collections.defaultdict(set)
for i,(a,z,old,opts)in enumerate(folds):
 missing=[b for b in(0,1)if not old[b]]
 if not missing:base.append(i)
 elif len(missing)==1:
  for h in opts[missing[0]]:single[h].add(i)
 else:
  for h,j in itertools.product(opts[0],opts[1]):
   if h==j:single[h].add(i)
   else:joint[min(h,j),max(h,j)].add(i)
baseops=[(folds[i][0],folds[i][1],None)for i in base];m0=len(c.max_matching(baseops));need=len(raw)//2+2-194;required_new=need-m0
print('MODEL',{'raw':len(raw)//2,'helpers':len(keys),'folds':len(folds),'base_max_matching':m0,'need_matching':need,'new_edge_necessary':required_new,'single_helper_enabled':len(single),'joint_pairs':len(joint)},flush=True)
start=time.monotonic();allpairs=0;survivors=0;matching_survivors=0;exact=0;best=999;records=[];empty=frozenset();single=[single.get(i,empty)for i in range(len(keys))]
for h,j in itertools.combinations(range(len(keys)),2):
 allpairs+=1;new=single[h]|single[j]|joint.get((h,j),empty)
 if len(new)<required_new:continue
 survivors+=1
 ops0=baseops+[(folds[i][0],folds[i][1],None)for i in new]
 bound=len(c.max_matching(ops0))
 if bound<need:continue
 matching_survivors+=1;rr=dict(raw);hs=[h,j];labels=[2900,2901]
 for label,k in zip(labels,hs):
  u0,u1=keys[k];rr[label,0]=(0,True,u0);rr[label,1]=(1,True,u1)
 ops=c.opportunities_fast(rr,eligible,ignore_incoming=frozenset(labels));assert len(c.max_matching(ops))==bound
 chosen=opt.compatible_folds(rr,ops);cost=len(rr)//2-len(chosen);exact+=1;best=min(best,cost)
 rec={'helpers':[keys[h],keys[j]],'optimistic_matching':bound,'compatible_folds':len(chosen),'states':cost};records.append(rec)
 if matching_survivors<15 or matching_survivors%100==0:print('EXACT',rec,'pairs',allpairs,'secs',time.monotonic()-start,flush=True)
 if cost<=194:
  folded,aliases=b.quotient(rr,chosen)
  try:cert=b.quotient_certificate(raw,folded,chosen,aliases)
  except Exception as exc:rec['local_certificate_error']=str(exc);print('CERT_REJECT',str(exc),flush=True)
  else:
   ss,ins,cs=c.source(T);res=c.validate(folded,cs);print('RUNTIME',res,flush=True);rec['runtime']=res
   if res['ok']:
    labs=[74]+sorted({q for q,bit in folded}-{74})+[254];inv={q:i for i,q in enumerate(labs)}
    dense={(inv[q],bit):(w,d,inv[n])for(q,bit),(w,d,n)in folded.items()};startup=b.startup(dense,labs);binding=b.source_binding(T,ss,ins);emission=b.emitter(T)
    for name,rows in [('machine.native.tm',folded),('machine.tm',dense)]:
     (OUT/name).write_text(''.join(f'{q} {bit} {w} {"R"if d else"L"} {n}\n'for(q,bit),(w,d,n)in sorted(rows.items())))
    (OUT/'winner.json').write_text(json.dumps({'states':cost,'helpers':[[l,*keys[k]]for l,k in zip(labels,hs)],'folds':chosen,'local_certificate':cert,'runtime':res,'source_binding':binding,'emitter':emission,'startup':startup,'labels':labs},indent=2)+'\n');opt.save(T,OUT/'grammar.json');print('FULL_WINNER',cost,OUT,flush=True);break
else:print('EXHAUSTED',flush=True)
rec={'input':str(P),'raw_states':len(raw)//2,'helpers':len(keys),'total_helper_pairs':allpairs,'new_edge_count_survivors':survivors,'matching_survivors':matching_survivors,'exact_compatible_checks':exact,'best_checked_states':best if exact else None,'seconds':time.monotonic()-start,'base_max_matching':m0,'required_matching':need,'scope':'Exhaustive unordered pairs of fresh pure-right helper states whose targets are old working controls; folds have exact old incoming left-symbol guards. Cardinality/matching prefilters are necessary conditions; full local replay and runtime are separate gates.'}
(OUT/'enumeration_receipt.json').write_text(json.dumps(rec,indent=2)+'\n');(OUT/'enumeration_candidates.json').write_text(json.dumps(records,indent=2)+'\n');print('DONE',rec,flush=True)
