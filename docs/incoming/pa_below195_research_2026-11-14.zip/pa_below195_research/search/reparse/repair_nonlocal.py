from reparse import *
seed=int(sys.argv[1])if len(sys.argv)>1 else 8901
rng=random.Random(seed);t0=time.monotonic();tries=0;safehits=0;best=99
inputs=[c.read_grammar(ROOT/'work/search/winner_1337_925.json'),c.read_grammar(ROOT/'work/search/winner_2026_204529.json')]
basefrontier=frontier

def forcefrontier(x,rng,goal):
 parts=[x]
 def unsafe(a):
  at=s.attrs(a);return at[0]>40 or at[2]>6 or at[3]>6
 for _ in range(80):
  bad=[i for i,a in enumerate(parts)if c.isnode(a)and unsafe(a)]
  if not bad:break
  k=rng.choice(bad);parts[k:k+1]=parts[k]
 while len(parts)<goal:
  inds=[i for i,a in enumerate(parts)if c.isnode(a)]
  if not inds:break
  k=rng.choices(inds,weights=[len(word(parts[i]))**.5 for i in inds])[0]
  parts[k:k+1]=parts[k]
 return parts
# Override the function global used by imported parse.
parse.__globals__['frontier']=forcefrontier
pool=inputs[:];evaluations=0
for step in range(4000):
 t=rng.choice(pool);xs=[a for a in nodes(t)if not s.grammar_safe(a) and len(word(a))>=3]
 if not xs:continue
 # Most often repair the smallest unsafe ancestor; occasionally reparse larger contexts.
 if step%3:xs=sorted(xs,key=lambda a:len(word(a)))[:5]
 x=rng.choice(xs)
 for y in parse(t,x,rng,goal=rng.randint(7,22),width=3):
  nt=s.replace(t,x,y);tries+=1
  if nt==t:continue
  at=s.attrs(nt)
  if not s.grammar_safe(nt):
   if at[2]<s.attrs(t)[2]and at[0]<=40 and nt not in pool and len(pool)<100:pool.append(nt)
   continue
  safehits+=1;score=s.evaluate(nt);evaluations+=1
  if score[0]<best:
   best=score[0];s.save(nt,OUT/f'repair_best{best}_{seed}_{step}.json');print('SAFE BEST',step,score,'secs',time.monotonic()-t0,flush=True)
  if score[0]<=60 and qualify(nt,f'repair_winner_{seed}_{step}'):sys.exit(0)
 if step%100==0:
  rec={'step':step,'tries':tries,'safehits':safehits,'evaluations':evaluations,'best':best,'pool':len(pool),'seconds':time.monotonic()-t0}
  (OUT/f'repair_progress{seed}.json').write_text(json.dumps(rec,indent=2)+'\n');print('PROGRESS',rec,flush=True)
 if step%200==0:word.cache_clear();nodes.cache_clear();safe_join.cache_clear();s.attrs.cache_clear()
rec={'tries':tries,'safehits':safehits,'evaluations':evaluations,'best':best,'pool':len(pool),'seconds':time.monotonic()-t0}
(OUT/f'repair_receipt{seed}.json').write_text(json.dumps(rec,indent=2)+'\n');print('DONE',rec,flush=True)
