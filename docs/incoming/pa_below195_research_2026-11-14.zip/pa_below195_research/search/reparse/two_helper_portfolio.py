from pathlib import Path
import sys,json,subprocess,time,concurrent.futures
sys.path.insert(0,str(Path('work/search').resolve()));import search as s
c=s.c;v=s.v
baseword=v.word(s.BASE);paths=[s.P/'grammar.json']+list(Path('work/search').glob('plateau*.json'))+list(Path('work/reparse').glob('tie*.json'))
seen=set();inputs=[]
for p in paths:
 t=c.read_grammar(p)
 if t in seen or not s.grammar_safe(t)or v.word(t)!=baseword:continue
 seen.add(t);score=s.evaluate(t)
 if score[0]<=61:inputs.append((p,score))
inputs.sort(key=lambda x:(x[1][1],str(x[0])))
out=Path('work/reparse/two_helpers_portfolio');out.mkdir(exist_ok=True)
(out/'inputs.json').write_text(json.dumps([{'path':str(p),'score':score}for p,score in inputs],indent=2)+'\n')
print('INPUTS',len(inputs),flush=True);start=time.monotonic();results=[]
def run(item):
 p,score=item;dest=out/p.stem
 with(out/(p.stem+'.log')).open('w')as log:
  proc=subprocess.run([sys.executable,'work/reparse/two_helpers_enumerate.py',str(p),str(dest)],stdout=log,stderr=subprocess.STDOUT)
 rec=json.loads((dest/'enumeration_receipt.json').read_text())if(dest/'enumeration_receipt.json').exists()else {'error':proc.returncode,'input':str(p)}
 rec['winner']=(dest/'winner.json').exists();return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as executor:
 futures=[executor.submit(run,item)for item in inputs]
 for fut in concurrent.futures.as_completed(futures):
  rec=fut.result();results.append(rec);print('RESULT',len(results),rec,flush=True)
  (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  if rec['winner']:
   for f in futures:f.cancel()
   print('WINNER_NOTIFY',rec['input'],flush=True);break
summary={'grammars_completed':len(results),'total_helper_pairs':sum(x.get('total_helper_pairs',0)for x in results),'matching_survivors':sum(x.get('matching_survivors',0)for x in results),'winners':[x['input']for x in results if x['winner']],'elapsed':time.monotonic()-start}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('SUMMARY',summary,flush=True)
