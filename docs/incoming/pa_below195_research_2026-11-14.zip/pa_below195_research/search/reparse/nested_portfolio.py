from pathlib import Path
import sys,json,subprocess,time,concurrent.futures
inputs=json.loads(Path('work/reparse/two_helpers_portfolio/inputs.json').read_text())
out=Path('work/reparse/nested_portfolio');out.mkdir(exist_ok=True)
print('INPUTS',len(inputs),flush=True);start=time.monotonic();results=[]
def run(item):
 p=Path(item['path']);dest=out/p.stem
 with(out/(p.stem+'.log')).open('w')as log:
  proc=subprocess.run([sys.executable,'work/reparse/nested_helpers.py',str(p),str(dest)],stdout=log,stderr=subprocess.STDOUT)
 rec=json.loads((dest/'receipt.json').read_text())if(dest/'receipt.json').exists()else {'error':proc.returncode,'input':str(p),'winner':False}
 return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as executor:
 fs=[executor.submit(run,item)for item in inputs]
 for f in concurrent.futures.as_completed(fs):
  rec=f.result();results.append(rec);print('RESULT',len(results),rec,flush=True)
  (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  if rec['winner']:
   for ff in fs:ff.cancel()
   print('WINNER_NOTIFY',rec['input'],flush=True);break
summary={'grammars_completed':len(results),'total_configurations':sum(x.get('total_configurations',0)for x in results),'matching_survivors':sum(x.get('matching_survivors',0)for x in results),'winners':[x['input']for x in results if x['winner']],'elapsed':time.monotonic()-start}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('SUMMARY',summary,flush=True)
