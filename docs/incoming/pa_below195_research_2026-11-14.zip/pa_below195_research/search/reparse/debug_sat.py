import sys,time
sys.path.insert(0,'work/reparse')
text=open('work/reparse/factor_lns.py').read().split('# Verify exact known67')[0]
exec(compile(text,'work/reparse/factor_lns.py','exec'))
known=min(pool,key=lambda t:len(c.build(t)[2]));br=used(known);kt={}
def walk(t):
 w=word(t)
 if w in kt:return
 kt[w]=t
 if w not in fixed:walk(t[0]);walk(t[1])
walk(known)
sub=[]
for i,w in enumerate(ww):
 sub.append((U[i],z3.BoolVal(w in kt)))
 at=s.attrs(kt.get(w,fixed.get(w,inc)))
 sub.extend([(L[i],z3.BitVecVal(at[1],3)),(H[i],z3.BitVecVal(at[0],6))])
for rv,(i,k,ia,ib)in zip(R,rules):sub.append((rv,z3.BoolVal(ww[i]in br and br[ww[i]]==k)))
print('model',len(ww),len(R),'known',len(br),len(kt),flush=True)
fails=[];st=time.monotonic()
for n,a in enumerate(solver.assertions()):
 aa=z3.simplify(z3.substitute(a,*sub))
 if not z3.is_true(aa):fails.append((n,str(a),str(aa)))
print('fails',len(fails),fails[:10],'secs',time.monotonic()-st,flush=True)
solver.add(*[var==val for var,val in sub]);solver.set(timeout=2000);st=time.monotonic();print('res',solver.check(),solver.reason_unknown(),time.monotonic()-st,flush=True)
