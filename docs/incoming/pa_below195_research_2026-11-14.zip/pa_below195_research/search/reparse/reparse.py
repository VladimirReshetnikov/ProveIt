#!/usr/bin/env python3
"""Nonlocal interval parsing of large grammar frontiers; heuristic discovery only."""
from pathlib import Path
import sys,json,time,random,math,itertools
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/search'))
import search as s
c=s.c;v=s.v
OUT=Path(__file__).resolve().parent

@lru_cache(maxsize=30000)
def word(t):
 if c.isnode(t):return word(t[0])+word(t[1])
 return(t,)

@lru_cache(maxsize=30000)
def nodes(t):
 if not c.isnode(t):return frozenset()
 return nodes(t[0])|nodes(t[1])|{t}

@lru_cache(maxsize=30000)
def safe_join(t):
 return s.grammar_safe(t)

def frontier(x,rng,goal):
 parts=[x]
 for _ in range(goal-1):
  indices=[i for i,t in enumerate(parts)if c.isnode(t)]
  if not indices:break
  k=rng.choices(indices,weights=[len(word(parts[i]))**.4 for i in indices])[0]
  parts[k:k+1]=parts[k]
 return parts

def parse(t,x,rng,goal=15,width=3):
 parts=frontier(x,rng,goal);n=len(parts)
 if n<3:return[]
 available=nodes(t)-{x}
 # Existing words may be reused without introducing a reader.
 dictionary={}
 for a in available:
  dictionary.setdefault(word(a),[]).append(a)
 for atom in parts:
  dictionary.setdefault(word(atom),[]).append(atom)
 ww=[word(a)for a in parts]
 chunk={}
 for i in range(n):
  q=()
  for j in range(i+1,n+1):q+=ww[j-1];chunk[i,j]=q
 chart={};noise={}
 def cost(item):
  a,new=item
  if a not in noise:noise[a]=rng.random()
  at=s.attrs(a)
  return len(new)+.07*noise[a]+.0002*at[0]
 for ln in range(1,n+1):
  for i in range(n-ln+1):
   j=i+ln;cands={}
   for a in dictionary.get(chunk[i,j],[]):
    if a==x:continue
    if s.grammar_safe(a):cands[a]=frozenset()
   if ln==1:cands[parts[i]]=frozenset()
   for k in range(i+1,j):
    for a,na in chart[i,k]:
     for b,nb in chart[k,j]:
      z=(a,b)
      if not safe_join(z):continue
      fresh=na|nb
      if z not in available and z not in c.MACROS:fresh=fresh|{z}
      if z not in cands or len(fresh)<len(cands[z]):cands[z]=fresh
   # Keep multiple possible left-prefix lengths as scanner-sensitive state.
   groups={}
   for item in sorted(cands.items(),key=cost):
    at=s.attrs(item[0]);key=(at[1],at[4])
    groups.setdefault(key,[])
    if len(groups[key])<width:groups[key].append(item)
   selected=[item for group in groups.values()for item in group]
   chart[i,j]=sorted(selected,key=cost)[:max(width,7)]
 return [a for a,_ in chart[0,n]if a!=x]

def qualify(t,tag):
 out=OUT/tag;out.mkdir(exist_ok=True)
 rows,idx,shape=c.build(t);ops=c.opportunities_fast(rows,shape);folds=s.compatible_folds(rows,ops)
 folded,aliases=v.quotient(rows,folds)
 if len(folded)//2>194:return False
 s.save(t,out/'grammar.json');(out/'folds.json').write_text(json.dumps(folds,indent=2)+'\n')
 cert=v.quotient_certificate(rows,folded,folds,aliases)
 (out/'quotient_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
 ss,ins,cs=c.source(t);binding=v.source_binding(t,ss,ins);emission=v.emitter(t)
 checks={}
 for label,m in [('raw',rows),('folded',folded)]:
  checks[label]=c.validate(m,cs)
  if not checks[label]['ok']:
   (out/'failed_runtime.json').write_text(json.dumps(checks,indent=2)+'\n');print('RUNTIME FAILED',tag,label,checks[label],flush=True);return False
 labels=[74]+sorted({q for q,b in folded}-{74})+[254];inv={q:i for i,q in enumerate(labels)}
 dense={(inv[q],b):(w,d,inv[n])for(q,b),(w,d,n)in folded.items()}
 startup=v.startup(dense,labels)
 for name,m in [('machine.native.tm',folded),('machine.tm',dense)]:
  (out/name).write_text(''.join(f'{q} {b} {w} {"R"if d else"L"} {n}\n'for(q,b),(w,d,n)in sorted(m.items())))
 rec={'states':len(folded)//2,'readers':len(shape),'folds':len(folds),'source':binding,'emitter':emission,'runtime':checks,'startup':startup}
 (out/'verification.json').write_text(json.dumps(rec,indent=2)+'\n');print('FULLY CHECKED',str(out),len(folded)//2,flush=True);return True

def main():
 seed=int(sys.argv[1])if len(sys.argv)>1 else 414141
 limit=int(sys.argv[2])if len(sys.argv)>2 else 3000
 rng=random.Random(seed);t=s.BASE;score=s.evaluate(t);best=score[0];pool=[t];seen={t};start=time.monotonic();evaluations=0;accepted=0;bestreader=68
 for f in sorted((ROOT/'work/search').glob('plateau*.json')):
  q=c.read_grammar(f)
  if s.grammar_safe(q)and q not in seen:pool.append(q);seen.add(q)
 for step in range(limit):
  if step%100==0:t=rng.choice(pool);score=s.evaluate(t)
  # Large target, chosen nonlocally. A dictionary parser restructures 5-22 parts.
  xs=[a for a in nodes(t)if len(word(a))>=6]
  x=rng.choices(xs,weights=[min(45,len(word(a)))for a in xs])[0]
  candidates=parse(t,x,rng,goal=rng.randint(6,20),width=2)
  options=[]
  for y in candidates:
   nt=s.replace(t,x,y)
   if nt==t or not s.grammar_safe(nt):continue
   ns=s.evaluate(nt);evaluations+=1;options.append((ns,nt))
   if ns[0]<best:
    best=ns[0];s.save(nt,OUT/f'best{best}_{seed}_{step}.json');print('BEST',seed,step,ns,'seconds',time.monotonic()-start,flush=True)
    if best<=60 and qualify(nt,f'winner_{seed}_{step}'):return
   if ns[0]<=61 and nt not in seen:
    seen.add(nt)
    if len(pool)<200:pool.append(nt)
    if len(seen)%25==0:s.save(nt,OUT/f'tie{seed}_{len(seen)}.json')
  if options:
   ns,nt=min(options,key=lambda z:z[0][0]+.008*z[0][1]+.1*rng.random())
   delta=ns[0]-score[0]+.008*(ns[1]-score[1]);temp=.10+.15*((step//100)%3)
   if delta<=0 or rng.random()<math.exp(-delta/temp):t,score=nt,ns;accepted+=1
  if step%100==0:
   rec={'seed':seed,'step':step,'evaluations':evaluations,'accepted':accepted,'best':best,'pool':len(pool),'score':score,'seconds':time.monotonic()-start}
   (OUT/f'progress{seed}.json').write_text(json.dumps(rec,indent=2)+'\n');print('PROGRESS',rec,flush=True)
  if step%200==0:word.cache_clear();nodes.cache_clear();safe_join.cache_clear();s.attrs.cache_clear()
 rec={'seed':seed,'attempts':limit,'evaluations':evaluations,'accepted':accepted,'best':best,'pool':len(pool),'seconds':time.monotonic()-start}
 (OUT/f'receipt{seed}.json').write_text(json.dumps(rec,indent=2)+'\n');print('DONE',rec,flush=True)
if __name__=='__main__':main()
