#!/usr/bin/env python3
"""Finite-dictionary grammar factorization using Z3; state claims require runtime checks."""
from reparse import *
from collections import Counter,defaultdict
import z3
rng=random.Random(61775);w0=word(s.BASE);freq=Counter()
for i in range(len(w0)):
 for j in range(i+2,len(w0)+1):freq[w0[i:j]]+=1
vocab={w for w,n in freq.items()if n>=2 or len(w)<=7};observed=defaultdict(set)
paths=[ROOT/'work/pa195/pa195_conpa/pa195/grammar.json']+list((ROOT/'work/search').glob('plateau*.json'))+list(OUT.glob('tie*.json'))
for f in paths:
 t=c.read_grammar(f)
 if word(t)!=w0 or not s.grammar_safe(t):continue
 for x in nodes(t):
  w=word(x);vocab.add(w);observed[w].add(len(word(x[0])))
for a in w0:vocab.add((a,))
inc=('leaf','inc',1);pair=(inc,inc);quad=pair+pair
vocab.update([pair,quad]);ww=sorted(vocab,key=lambda w:(len(w),repr(w)));idx={w:i for i,w in enumerate(ww)}
U=[z3.Bool(f'u{i}')for i in range(len(ww))];L=[z3.Int(f'l{i}')for i in range(len(ww))];H=[z3.Int(f'h{i}')for i in range(len(ww))]
fixed={}
for w in ww:
 if len(w)==1:fixed[w]=w[0]
 elif w==pair:fixed[w]=(inc,inc)
 elif w==quad:fixed[w]=((inc,inc),(inc,inc))
solver=z3.Solver();solver.set(timeout=30000,random_seed=61775)
choices={};R=[];rules=[];weighted=[]
for i,w in enumerate(ww):
 solver.add(z3.Implies(U[i],z3.And(L[i]>=0,L[i]<=6,H[i]>=0,H[i]<=40)))
 if w in fixed:
  a=s.attrs(fixed[w]);solver.add(L[i]==a[1],H[i]==a[0]);continue
 weighted.append((U[i],1));rs=[]
 for k in range(1,len(w)):
  a,b=w[:k],w[k:]
  if a not in idx or b not in idx:continue
  if a==('node142',)or b==('node72',):continue
  # A fixed macro violating internal maxzero is never admissible.
  if any(x in fixed and s.attrs(fixed[x])[2]>6 for x in(a,b)):continue
  ri=z3.Bool(f'r{len(R)}');ia,ib=idx[a],idx[b];R.append(ri);rules.append((i,k,ia,ib))
  solver.add(z3.Implies(ri,z3.And(U[i],U[ia],U[ib],L[i]==L[ia]+1,H[i]>=H[ia]+1,H[i]>=H[ib]+1)))
  rs.append(ri)
 if rs:solver.add(z3.Implies(U[i],z3.PbEq([(r,1)for r in rs],1)))
 else:solver.add(z3.Not(U[i]))
 choices[i]=rs
solver.add(U[idx[w0]])
print('MODEL',len(ww),'words',len(R),'rules',len(paths),'grammars',flush=True)
(OUT/'factor_model.json').write_text(json.dumps({'dictionary_words':len(ww),'binary_rules':len(R),'grammar_inputs':len(paths),'restriction':'At most one parse for each subword in finite observed+short+repeated dictionary; scanner-prefix at most6; height at most40.'},indent=2)+'\n')
start=time.monotonic();results=[]
for bound in [65,66,67]:
 solver.push();solver.add(z3.PbLe(weighted,bound))
 for attempt in range(200):
  st=time.monotonic();result=solver.check();rec={'bound':bound,'attempt':attempt,'solver':str(result),'seconds':time.monotonic()-st};print('CHECK',rec,flush=True)
  if result!=z3.sat:results.append(rec);break
  m=solver.model();selected={};lits=[]
  for rv,(i,k,ia,ib)in zip(R,rules):
   if z3.is_true(m[rv]):selected[i]=(ia,ib);lits.append(rv)
  memo={}
  def rebuild(i):
   if i in memo:return memo[i]
   w=ww[i]
   if w in fixed:ans=fixed[w]
   else:
    a,b=selected[i];ans=rebuild(a),rebuild(b)
   memo[i]=ans;return ans
  t=rebuild(idx[w0]);assert word(t)==w0
  if not s.grammar_safe(t):raise ValueError(('solver safety discrepancy',s.attrs(t)))
  score=s.evaluate(t);rec.update(score=score,used_variables=sum(z3.is_true(m[u])for u,_ in weighted));results.append(rec)
  s.save(t,OUT/f'factor_b{bound}_{attempt}.json');print('SCORE',score,flush=True)
  if score[0]<=60 and qualify(t,f'factor_winner_b{bound}_{attempt}'):sys.exit(0)
  solver.add(z3.Not(z3.And(lits)))
  (OUT/'factor_results.json').write_text(json.dumps(results,indent=2)+'\n')
 solver.pop()
(OUT/'factor_results.json').write_text(json.dumps(results,indent=2)+'\n')
print('DONE',time.monotonic()-start,flush=True)
