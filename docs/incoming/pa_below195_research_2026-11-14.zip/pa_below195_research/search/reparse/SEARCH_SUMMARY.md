# Additional nonlocal grammar and auxiliary-control searches

No machine with fewer than 195 working states was established by these searches.
No result here is a lower bound on arbitrary binary Turing machines.

The input baseline is the supplied PA195 construction, with literal table
SHA-256 `5c6afd87f7c4f24d9ad8e9e302cc21df14b6f2e3715d03322a75463a431d8455`.
Its unfolded table has 202 controls. A successful new allocation must use
at most 194 controls after counting every newly introduced helper.

## Nonlocal interval reparsing

`reparse.py` cuts a chosen source subtree into 6--20 ordered pieces and
reparses all intervals using reusable subwords from the current grammar.
The parser keeps several left-prefix profiles to account for scanner depth.
It performs global subtree replacements and evaluates the exact compatible
fold score on complete candidate transition tables. This differs from
applying a single local associativity rotation.

The completed run with seed 414141 made 3,000 reparsing proposals and
11,873 complete safe-table score evaluations. It accepted 1,185 moves and
retained a pool of 200 grammars. Its best score remained 195 states. Several
new seeds use 67 AX readers and six compatible folds, whereas the supplied
PA195 uses 68 readers and seven folds. These are search seeds; their complete
symbolic runtime was not individually replayed.

An additional exact reader-set-cost parser and a repair search starting from
scanner-invalid 194-state quotient witnesses were interrupted after their
recorded progress checkpoints when the work moved to more focused helper
families. Their partial progress logs are not completed exhaustive searches.
The broad finite-dictionary grammar SAT queries at reader bounds 65, 66 and
67 each returned UNKNOWN after the 30-second timeout. They do not establish
UNSAT or a grammar lower bound. The exploratory large-neighborhood SAT and
its failed positive-control attempts are not claimed as mathematical results.

## Two independent fresh pure-right helpers

`two_helpers_enumerate.py` considers two new controls, each with rows
`0 -> (0,R,u0)` and `1 -> (1,R,u1)`, where both targets are old working
controls. Candidate folds identify a left-context-zero role with a
left-context-one role. A differing read branch is allowed an existing
provider or either new provider. In particular, this includes folds whose
two branches require two different fresh providers.

The enumerator forms the exact newly enabled fold-edge set for every
unordered helper pair. If the old matching number is m and the target
requires n folds, at least n-m new edges are necessary. This is a sound
cardinality filter. Every surviving pair then receives a maximum bipartite
matching computation; exact simultaneous local replay would follow if the
matching target were reached.

For the baseline there are 1,884 helpers and 1,773,786 unordered pairs.
The 5,307 cardinality survivors all fail the matching target of ten folds.
Across the 66 scanner-compatible 195-state search seeds in
`two_helpers_portfolio/inputs.json`, 135,012,574 helper pairs were examined.
None reached its necessary matching target. No runtime claim is inferred
from these negative combinatorial checks.

## A nested pair with a synthetic action state

`nested_helpers.py` permits a fresh pure-right helper H to have children
(K,v) or (v,K), with v old and K fresh. The zero and one rows of K are
chosen independently from the actions appearing in the corresponding read
columns of the original table. This allows a pair of actions that no old
state combines. If K itself is pure-right, its own provider opportunities
are also included; they are not discarded by the model.

Action masks compute exactly which old-state fold edges become possible.
For each grammar, 50 independently reconstructed literal-provider controls
check agreement with the mask calculation. The matching filter precedes
exact simultaneous local replay.

Across all 66 search seeds, 519,820,990 configurations were examined.
Five configurations on five 67-reader seeds reach the optimistic matching
number nine. Exact simultaneous replay permits only seven folds for each,
so each costs 196 states after counting both new controls. No 194-state
candidate survives. All other configurations fail the necessary matching
bound.

## One helper with arbitrary left/right actions in a four-cell window

`wide_helper.py` extends the preceding-cell helper family by allowing each
helper row to write either bit, move either left or right, and enter an old
state. Each possible branch action is simulated for both current bits and
all four assignments of the two outside cells in the window [-2,-1,0,+1].
The discovery screen records the first occurrence of each admissible exact
endpoint, limits traces to 64 steps, and excludes visits to the proposed
folded roles. Those restrictions are conservative and are part of the
search family; failure is not an impossibility result for other detours.

The simultaneous verifier checks the complete four-cell tape and head
against the projected original transition. It permits no read outside the
window and requires a positive number of steps. The supplied seven-fold
PA195 certificate passes this wider verifier in all 112 local cases,
recorded in `wide_helper_positive_control.json`.

The baseline yields 342 helper tables, of which 17 have enough newly enabled
edges to warrant the matching check. None reaches the needed nine folds.
Across the same 66 search seeds, 21,841 helper tables are generated, and
none reaches its matching target. Consequently no new complete runtime
candidate arises in this family.

## Evidence files

- `receipt414141.json`: completed nonlocal reparsing run.
- `two_helpers_portfolio/summary.json` and `results.json`: complete two-helper
  portfolio counts and per-input scope.
- `nested_portfolio/summary.json`, `results.json`, and each input's
  `candidates.json`: nested-helper results and the five incompatible matches.
- `wide_portfolio/summary.json` and `results.json`: four-cell helper results.
- `wide_helper_positive_control.json`: independent positive control.
- `factor_results.json`: actual UNKNOWN statuses of broad grammar SAT queries.

The source scripts import the parent investigation's `work/search/search.py`
and the frozen PA195 verifier at `work/pa195/pa195_conpa/pa195`. They use
Python's standard library for the nested and four-cell enumerators. The
SAT scripts require Z3. The explicit two-helper enumerator also imports
Z3 through its shared setup, although it invokes no solver. None of the
completed enumeration results relies on a SAT timeout.
