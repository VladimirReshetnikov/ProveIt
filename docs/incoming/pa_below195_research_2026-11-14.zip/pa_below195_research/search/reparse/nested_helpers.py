#!/usr/bin/env python3
"""Nested H/K helper synthesis, with exact action-mask prefilter and replay."""
from pathlib import Path
import sys,json,itertools,collections,time,hashlib,random
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
b=opt.v;c=b.c
P=Path(sys.argv[1])if len(sys.argv)>1 else opt.P/'grammar.json'
OUT=Path(sys.argv[2])if len(sys.argv)>2 else Path('work/reparse/nested_helpers_baseline');OUT.mkdir(exist_ok=True,parents=True)
T=c.read_grammar(P);assert opt.grammar_safe(T)
raw,idx,shape=c.build(T);states=sorted({q for q,bit in raw});H=2900;K=2901
inc=collections.defaultdict(set)
for(q,bit),(w,d,n)in raw.items():inc[n].add((w,d))
eligible={q:q for q in states if q!=74 and q not in c.BOXSTATES and inc[q]in[{(0,True)},{(1,True)}]}
zero=[q for q in eligible if inc[q]=={(0,True)}];one=[q for q in eligible if inc[q]=={(1,True)}]
pairs=list(itertools.product(zero,one));pairidx={p:i for i,p in enumerate(pairs)}
matrix=[collections.defaultdict(int),collections.defaultdict(int)];ep=collections.defaultdict(int);equal=[0,0]
for i,(a,z)in enumerate(pairs):
 bitmask=1<<i;ep[a]|=bitmask;ep[z]|=bitmask
 for bit in(0,1):
  matrix[bit][raw[a,bit],raw[z,bit]]|=bitmask
  if raw[a,bit]==raw[z,bit]:equal[bit]|=bitmask
base=equal[:]
for h in states:
 w0,d0,u0=raw[h,0];w1,d1,u1=raw[h,1]
 if w0==0 and w1==1 and d0 and d1:
  for bit in(0,1):
   if(u0,bit)in raw and(u1,bit)in raw:base[bit]|=matrix[bit][raw[u0,bit],raw[u1,bit]]&~(ep[h]|ep[u0]|ep[u1])
actions=[sorted({raw[q,bit]for q in states})for bit in(0,1)];actionids=[{x:i for i,x in enumerate(aa)}for aa in actions]
configs=[]
for i,a0 in enumerate(actions[0]):
 for j,a1 in enumerate(actions[1]):
  kbase=base[:]
  # K can also be used directly as an independent old-target pure-R helper.
  if a0[0]==0 and a1[0]==1 and a0[1]and a1[1]:
   u0,u1=a0[2],a1[2]
   for bit in(0,1):
    if(u0,bit)in raw and(u1,bit)in raw:kbase[bit]|=matrix[bit][raw[u0,bit],raw[u1,bit]]&~(ep[u0]|ep[u1])
  configs.append((i,j,kbase[0],kbase[1]))

def helper_masks(v,side):
 hm=[]
 for bit in(0,1):
  ar=raw[v,bit];bad=ep[v]
  hm.append([matrix[bit][(a,ar)if side==0 else(ar,a)]&~bad for a in actions[bit]])
 return hm

def rows(v,side,i,j):
 rr=dict(raw);rr[K,0]=actions[0][i];rr[K,1]=actions[1][j]
 rr[H,0]=(0,True,K if side==0 else v);rr[H,1]=(1,True,v if side==0 else K)
 return rr

def actualmask(ops):
 return sum(1<<pairidx[a,z]for a,z,choices in ops)
# Positive equivalence controls: bit-mask filter equals the literal provider enumeration.
rng=random.Random(18432)
for _ in range(50):
 v=rng.choice(states);side=rng.randrange(2);i,j,k0,k1=rng.choice(configs);hm=helper_masks(v,side)
 rr=rows(v,side,i,j);ops=c.opportunities_fast(rr,eligible,ignore_incoming={H,K})
 assert actualmask(ops)==(k0|hm[0][i])&(k1|hm[1][j]),'action-mask/provider discrepancy'
need=len(raw)//2+2-194
summary={'input':str(P),'input_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'raw_states':len(raw)//2,'reader_nodes':len(shape),'old_controls':len(states),'synthetic_K_rows0':len(actions[0]),'synthetic_K_rows1':len(actions[1]),'K_configurations':len(configs),'side_choices':2,'required_matching':need,'mask_equivalence_controls':50,'family':'H is pure R with children(K,v) or(v,K); v old; K0 and K1 independently chosen from old actions on the corresponding read symbol. K may also serve as an independent pure-R helper. All folds are disjoint old-state folds with old incoming-history guards.'}
print('MODEL',summary,flush=True);(OUT/'model.json').write_text(json.dumps(summary,indent=2)+'\n')
start=time.monotonic();total=0;cardinality=0;matching=0;exact=0;best=999;records=[];found=False
for side in(0,1):
 for vi,v in enumerate(states):
  hm0,hm1=helper_masks(v,side)
  for i,j,k0,k1 in configs:
   total+=1;mask=(k0|hm0[i])&(k1|hm1[j])
   if mask.bit_count()<need:continue
   cardinality+=1;oo=[];mm=mask
   while mm:
    lb=mm&-mm;n=lb.bit_length()-1;mm-=lb;a,z=pairs[n];oo.append((a,z,None))
   bound=len(c.max_matching(oo))
   if bound<need:continue
   matching+=1;rr=rows(v,side,i,j);ops=c.opportunities_fast(rr,eligible,ignore_incoming={H,K});assert actualmask(ops)==mask
   chosen=opt.compatible_folds(rr,ops);cost=len(rr)//2-len(chosen);exact+=1;best=min(best,cost)
   rec={'side':side,'old_child':v,'K0':actions[0][i],'K1':actions[1][j],'potential_matching':bound,'compatible_folds':len(chosen),'states':cost};records.append(rec)
   if matching<12 or matching%100==0:print('EXACT',rec,'secs',time.monotonic()-start,flush=True)
   if cost<=194:
    folded,aliases=b.quotient(rr,chosen)
    try:cert=b.quotient_certificate(raw,folded,chosen,aliases)
    except Exception as exc:rec['certificate_error']=str(exc);print('CERT_REJECT',str(exc),flush=True);continue
    ss,ins,cs=c.source(T);runtime=c.validate(folded,cs);rec['runtime']=runtime;print('RUNTIME',runtime,flush=True)
    if not runtime['ok']:continue
    labs=[74]+sorted({q for q,bit in folded}-{74})+[254];inv={q:i for i,q in enumerate(labs)}
    dense={(inv[q],bit):(w,d,inv[n])for(q,bit),(w,d,n)in folded.items()};startup=b.startup(dense,labs);binding=b.source_binding(T,ss,ins);emitter=b.emitter(T)
    for name,table in [('machine.native.tm',folded),('machine.tm',dense)]:
     (OUT/name).write_text(''.join(f'{q} {bit} {w} {"R"if d else"L"} {n}\n'for(q,bit),(w,d,n)in sorted(table.items())))
    (OUT/'winner.json').write_text(json.dumps({'states':cost,'H':{'label':H,'rows':[rr[H,0],rr[H,1]]},'K':{'label':K,'rows':[rr[K,0],rr[K,1]]},'folds':chosen,'local_certificate':cert,'runtime':runtime,'source_binding':binding,'emitter':emitter,'startup':startup,'labels':labs},indent=2)+'\n');opt.save(T,OUT/'grammar.json');found=True;print('FULL_WINNER',cost,OUT,flush=True);break
  if found:break
  if vi%50==0:print('PROGRESS',side,vi,'total',total,'cardinality',cardinality,'matching',matching,'secs',time.monotonic()-start,flush=True)
 if found:break
summary.update(total_configurations=total,cardinality_survivors=cardinality,matching_survivors=matching,exact_compatible_checks=exact,best_checked_states=best if exact else None,elapsed=time.monotonic()-start,winner=found)
(OUT/'receipt.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'candidates.json').write_text(json.dumps(records,indent=2)+'\n');print('DONE',summary,flush=True)
