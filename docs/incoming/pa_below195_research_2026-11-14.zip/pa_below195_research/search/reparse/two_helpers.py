#!/usr/bin/env python3
"""Finite two-pure-right-helper allocation model with exact simultaneous replay."""
from pathlib import Path
import sys,json,itertools,collections,time,hashlib
import z3
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
b=opt.v;c=b.c
P=Path(sys.argv[1])if len(sys.argv)>1 else opt.P/'grammar.json'
OUT=Path(sys.argv[2])if len(sys.argv)>2 else Path('work/reparse/two_helpers_baseline');OUT.mkdir(exist_ok=True,parents=True)
T=c.read_grammar(P);assert opt.grammar_safe(T)
raw,idx,shape=c.build(T);states=sorted({q for q,bit in raw})
inc=collections.defaultdict(set)
for(q,bit),(w,d,n)in raw.items():inc[n].add((w,d))
eligible={q:q for q in states if q!=74 and q not in c.BOXSTATES and inc[q]in[{(0,True)},{(1,True)}]}
zero=[q for q in eligible if inc[q]=={(0,True)}];one=[q for q in eligible if inc[q]=={(1,True)}]
byrow=[collections.defaultdict(list),collections.defaultdict(list)]
providers=[collections.defaultdict(list),collections.defaultdict(list)]
for q in states:
 for bit in(0,1):byrow[bit][raw[q,bit]].append(q)
 w0,d0,u0=raw[q,0];w1,d1,u1=raw[q,1]
 if w0==0 and w1==1 and d0 and d1:
  for bit in(0,1):
   if(u0,bit)in raw and(u1,bit)in raw:providers[bit][raw[u0,bit],raw[u1,bit]].append((q,u0,u1))
folds=[];helpers={};served=collections.defaultdict(set)
for a,z in itertools.product(zero,one):
 existing=[];options=[]
 for bit in(0,1):
  eq=raw[a,bit]==raw[z,bit]
  old=eq or any(not {a,z}&set(k)for k in providers[bit][raw[a,bit],raw[z,bit]])
  hh=[]
  if not eq:
   for u0,u1 in itertools.product(byrow[bit][raw[a,bit]],byrow[bit][raw[z,bit]]):
    if {a,z}&{u0,u1}:continue
    key=(u0,u1)
    if key not in helpers:helpers[key]=len(helpers)
    hh.append(helpers[key])
  existing.append(old);options.append(hh)
 if all(existing[i]or options[i]for i in(0,1)):
  n=len(folds);folds.append((a,z,existing,options))
  for hh in options:
   for h in hh:served[h].add(n)
# Discard helper keys which cannot occur in any potentially enabled fold.
keep=sorted(served);remap={a:i for i,a in enumerate(keep)};keys=[None]*len(keep)
for k,i in helpers.items():
 if i in remap:keys[remap[i]]=k
folds=[(a,z,old,[[remap[h]for h in hh if h in remap]for hh in opts])for a,z,old,opts in folds]
solver=z3.Solver();solver.set(timeout=30000,random_seed=90317)
F=[z3.Bool(f'f{i}')for i in range(len(folds))];H=[z3.Bool(f'h{i}')for i in range(len(keys))]
if len(H)<2:raise ValueError('not enough helper candidates')
solver.add(z3.PbEq([(h,1)for h in H],2))
endpoints=collections.defaultdict(list);uses=collections.defaultdict(list)
for i,(a,z,old,opts)in enumerate(folds):
 endpoints[a].append(F[i]);endpoints[z].append(F[i])
 for bit in(0,1):
  if not old[bit]:solver.add(z3.Implies(F[i],z3.Or([H[h]for h in opts[bit]])))
  for h in opts[bit]:uses[h].append(F[i])
for fs in endpoints.values():
 if len(fs)>1:solver.add(z3.AtMost(*fs,1))
for h in range(len(H)):solver.add(z3.Implies(H[h],z3.Or(uses[h])))
need=len(raw)//2+2-194
solver.add(z3.PbGe([(f,1)for f in F],need))
summary={'input':str(P),'input_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'raw_states':len(raw)//2,'reader_nodes':len(shape),'eligible_zero':len(zero),'eligible_one':len(one),'potential_fold_pairs':len(folds),'helper_controls':len(keys),'needed_folds':need,'new_helpers':2,'scope':'Pure R helpers with both targets in old working states; disjoint incoming-history folds; exact replay rejects interaction failures.'}
print('MODEL',summary,flush=True);(OUT/'model.json').write_text(json.dumps(summary,indent=2)+'\n')
start=time.monotonic();records=[];best=len(raw)//2;baselineops=c.opportunities_fast(raw,eligible)
for attempt in range(200000):
 if time.monotonic()-start>600:print('TIME_LIMIT',flush=True);break
 st=time.monotonic();result=solver.check()
 if result!=z3.sat:
  rec={'result':str(result),'reason':solver.reason_unknown(),'seconds':time.monotonic()-st};records.append(rec);print('SOLVER',rec,flush=True);break
 m=solver.model();hs=[i for i,h in enumerate(H)if z3.is_true(m[h])];fs=[i for i,f in enumerate(F)if z3.is_true(m[f])];assert len(hs)==2 and len(fs)>=need
 rr=dict(raw);labels=[2900,2901]
 for label,h in zip(labels,hs):
  u0,u1=keys[h];rr[label,0]=(0,True,u0);rr[label,1]=(1,True,u1)
 ops=c.opportunities_fast(rr,eligible,ignore_incoming=frozenset(labels));bound=len(c.max_matching(ops));assert bound>=len(fs)
 chosen=opt.compatible_folds(rr,ops);cost=len(rr)//2-len(chosen);best=min(best,cost)
 rec={'attempt':attempt,'helpers':[keys[h]for h in hs],'model_fold_pairs':[(folds[i][0],folds[i][1])for i in fs],'compatible_folds':len(chosen),'states':cost,'seconds':time.monotonic()-st};records.append(rec)
 if attempt<10 or attempt%100==0:print('PAIR',rec,'elapsed',time.monotonic()-start,flush=True)
 if cost<=194:
  folded,aliases=b.quotient(rr,chosen)
  try:cert=b.quotient_certificate(raw,folded,chosen,aliases)
  except Exception as exc:rec['local_certificate_error']=str(exc);print('CERT_REJECT',str(exc),flush=True)
  else:
   ss,ins,cs=c.source(T);res=c.validate(folded,cs);print('RUNTIME',res,flush=True);rec['runtime']=res
   if res['ok']:
    labs=[74]+sorted({q for q,bit in folded}-{74})+[254];inv={q:i for i,q in enumerate(labs)}
    dense={(inv[q],bit):(w,d,inv[n])for(q,bit),(w,d,n)in folded.items()};startup=b.startup(dense,labs)
    binding=b.source_binding(T,ss,ins);emission=b.emitter(T)
    for name,rows in [('machine.native.tm',folded),('machine.tm',dense)]:
     (OUT/name).write_text(''.join(f'{q} {bit} {w} {"R"if d else"L"} {n}\n'for(q,bit),(w,d,n)in sorted(rows.items())))
    (OUT/'winner.json').write_text(json.dumps({'states':cost,'helpers':[[l,*keys[h]]for l,h in zip(labels,hs)],'folds':chosen,'local_certificate':cert,'runtime':res,'source_binding':binding,'emitter':emission,'startup':startup,'labels':labs},indent=2)+'\n');opt.save(T,OUT/'grammar.json');print('FULL_WINNER',cost,OUT,flush=True);break
 solver.add(z3.Not(z3.And([H[h]for h in hs])))
 if attempt%20==0:(OUT/'attempts.json').write_text(json.dumps(records,indent=2)+'\n')
(OUT/'attempts.json').write_text(json.dumps(records,indent=2)+'\n');summary.update(attempts=len(records),best_checked_states=best,elapsed=time.monotonic()-start);(OUT/'receipt.json').write_text(json.dumps(summary,indent=2)+'\n');print('DONE',summary,flush=True)
