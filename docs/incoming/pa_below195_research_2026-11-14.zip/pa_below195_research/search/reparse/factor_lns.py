#!/usr/bin/env python3
from reparse import *
from collections import Counter,defaultdict
import z3
seed=int(sys.argv[1])if len(sys.argv)>1 else 70419
rng=random.Random(seed);w0=word(s.BASE);freq=Counter()
for i in range(len(w0)):
 for j in range(i+2,len(w0)+1):freq[w0[i:j]]+=1
vocab={w for w,n in freq.items()if n>=2 or len(w)<=7}
paths=[ROOT/'work/pa195/pa195_conpa/pa195/grammar.json']+list((ROOT/'work/search').glob('plateau*.json'))+list(OUT.glob('tie*.json'))
pool=[]
for f in paths:
 t=c.read_grammar(f)
 if word(t)!=w0 or not s.grammar_safe(t):continue
 vocab.update(word(x)for x in nodes(t));pool.append(t)
for a in w0:vocab.add((a,))
inc=('leaf','inc',1);pair=(inc,inc);quad=pair+pair;vocab.update([pair,quad])
ww=sorted(vocab,key=lambda w:(len(w),repr(w)));idx={w:i for i,w in enumerate(ww)}
U=[z3.Bool(f'u{i}')for i in range(len(ww))];L=[z3.BitVec(f'l{i}',3)for i in range(len(ww))];H=[z3.BitVec(f'h{i}',6)for i in range(len(ww))]
fixed={w:w[0]for w in ww if len(w)==1};fixed[pair]=(inc,inc);fixed[quad]=((inc,inc),(inc,inc))
solver=z3.Solver();solver.set(timeout=1800,random_seed=seed)
R=[];rules=[];weighted=[];parents=defaultdict(list);byrule={}
for i,w in enumerate(ww):
 solver.add(z3.Implies(U[i],z3.And(z3.ULE(L[i],6),z3.ULE(H[i],40))))
 if w in fixed:
  a=s.attrs(fixed[w]);solver.add(L[i]==a[1],H[i]==a[0]);continue
 weighted.append((U[i],1));rs=[]
 for k in range(1,len(w)):
  a,b=w[:k],w[k:]
  if a not in idx or b not in idx or a==('node142',)or b==('node72',):continue
  if any(x in fixed and s.attrs(fixed[x])[2]>6 for x in(a,b)):continue
  ri=z3.Bool(f'r{len(R)}');ia,ib=idx[a],idx[b];R.append(ri);rules.append((i,k,ia,ib));byrule[w,k]=ri
  parents[ia].append(ri);parents[ib].append(ri)
  solver.add(z3.Implies(ri,z3.And(U[i],U[ia],U[ib],L[i]==L[ia]+1,z3.UGT(H[i],H[ia]),z3.UGT(H[i],H[ib]))));rs.append(ri)
 if rs:solver.add(z3.Implies(U[i],z3.PbEq([(r,1)for r in rs],1)))
 else:solver.add(z3.Not(U[i]))
solver.add(U[idx[w0]])
for i in range(len(ww)):
 if i!=idx[w0]:solver.add(z3.Implies(U[i],z3.Or(parents[i])))

def used(t):
 return {word(x):len(word(x[0]))for x in nodes(t)if word(x)not in fixed}
# Verify exact known67 grammar is admissible in this finite solver model.
known=min(pool,key=lambda t:len(c.build(t)[2]));baserules=used(known)
solver.push()
ktrees={}
def known_walk(t):
 w=word(t)
 if w in ktrees:return
 ktrees[w]=t
 if w not in fixed:
  known_walk(t[0]);known_walk(t[1])
known_walk(known)
for i,w in enumerate(ww):
 solver.add(U[i]==(w in ktrees))
 if w in ktrees:
  at=s.attrs(ktrees[w]);solver.add(L[i]==at[1],H[i]==at[0])
for rv,(i,k,ia,ib)in zip(R,rules):solver.add(rv==(ww[i]in baserules and k==baserules[ww[i]]))
solver.add(z3.PbLe(weighted,len(c.build(known)[2])));solver.set(timeout=30000);res=solver.check();solver.pop();solver.set(timeout=1800)
print('POSITIVE_CONTROL',len(c.build(known)[2]),str(res),'vocab',len(ww),'rules',len(R),flush=True)
assert res==z3.sat
pool=[t for t in pool if len(c.build(t)[2])<=68];seen=set(pool);best=61;results=[];begin=time.monotonic();rounds=0
for attempt in range(2000):
 if time.monotonic()-begin>240:break
 t=rng.choice(pool);br=used(t);n=len(c.build(t)[2]);frac=rng.choice([.55,.68,.78,.88,.94]);keep=rng.sample(list(br.items()),int(len(br)*frac))
 bound=n-(1 if rng.random()<.18 else 0)
 solver.push();solver.add(z3.PbLe(weighted,bound));solver.add(*[byrule[w,k]for w,k in keep]);solver.add(z3.Not(z3.And([byrule[w,k]for w,k in br.items()])))
 st=time.monotonic();res=solver.check();rec={'attempt':attempt,'bound':bound,'fixed_rules':len(keep),'result':str(res),'seconds':time.monotonic()-st}
 if res==z3.sat:
  m=solver.model();selected={i:(ia,ib)for rv,(i,k,ia,ib)in zip(R,rules)if z3.is_true(m[rv])};memo={}
  def rebuild(i):
   if i in memo:return memo[i]
   if ww[i]in fixed:ans=fixed[ww[i]]
   else:
    a,b=selected[i];ans=rebuild(a),rebuild(b)
   memo[i]=ans;return ans
  nt=rebuild(idx[w0]);assert word(nt)==w0 and s.grammar_safe(nt)
  score=s.evaluate(nt);rec['score']=score
  if score[0]<best:
   best=score[0];s.save(nt,OUT/f'lns_best{best}_{seed}_{attempt}.json');print('BEST',score,attempt,flush=True)
  if score[0]<=61 and nt not in seen:
   seen.add(nt)
   if len(pool)>=400:pool.pop(rng.randrange(len(pool)))
   pool.append(nt)
   s.save(nt,OUT/f'lns_tie{seed}_{attempt}.json')
  if score[0]<=60 and qualify(nt,f'lns_winner_{seed}_{attempt}'):sys.exit(0)
 solver.pop();results.append(rec);rounds+=1
 if attempt%20==0:
  data={'attempts':rounds,'best':best,'pool':len(pool),'elapsed':time.monotonic()-begin,'statuses':dict(Counter(x['result']for x in results)),'last':rec}
  (OUT/f'lns_progress{seed}.json').write_text(json.dumps(data,indent=2)+'\n');print('PROGRESS',data,flush=True)
(OUT/f'lns_results{seed}.json').write_text(json.dumps(results,indent=2)+'\n');print('DONE',len(results),best,time.monotonic()-begin,flush=True)
