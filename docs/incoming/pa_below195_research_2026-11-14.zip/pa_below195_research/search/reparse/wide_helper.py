#!/usr/bin/env python3
"""One new arbitrary L/R helper, universal four-cell local replay."""
from pathlib import Path
import sys,json,itertools,collections,time,hashlib
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
b=opt.v;c=b.c
P=Path(sys.argv[1])if len(sys.argv)>1 else opt.P/'grammar.json'
OUT=Path(sys.argv[2])if len(sys.argv)>2 else Path('work/reparse/wide_helper_baseline');OUT.mkdir(exist_ok=True,parents=True)
T=c.read_grammar(P);assert opt.grammar_safe(T)
raw,idx,shape=c.build(T);states=sorted({q for q,bit in raw});H=2900
inc=collections.defaultdict(set)
for(q,bit),(w,d,n)in raw.items():inc[n].add((w,d))
eligible={q:q for q in states if q!=74 and q not in c.BOXSTATES and inc[q]in[{(0,True)},{(1,True)}]}
zero=[q for q in eligible if inc[q]=={(0,True)}];one=[q for q in eligible if inc[q]=={(1,True)}]
baseops=c.opportunities_fast(raw,eligible);basepairs={(a,z):o for a,z,o in baseops}
providers=[collections.defaultdict(list),collections.defaultdict(list)]
for h in states:
 w0,d0,u0=raw[h,0];w1,d1,u1=raw[h,1]
 if w0==0 and w1==1 and d0 and d1:
  for bit in(0,1):
   if(u0,bit)in raw and(u1,bit)in raw:providers[bit][raw[u0,bit],raw[u1,bit]].append((h,u0,u1))
basepair={}
for a,z in itertools.product(zero,one):
 opts=[]
 for bit in(0,1):
  aa=[raw[a,bit]]if raw[a,bit]==raw[z,bit]else[]
  aa.extend((bit,False,h)for h,u0,u1 in providers[bit][raw[a,bit],raw[z,bit]]if not{a,z}&{h,u0,u1});opts.append(aa)
 basepair[a,z]=opts
reverse=[collections.defaultdict(list),collections.defaultdict(list)]
for q in zero+one:
 for bit in(0,1):
  w,d,n=raw[q,bit];reverse[bit][n,1 if d else -1,w].append(q)
accepted=collections.defaultdict(dict);start=time.monotonic();branch_actions=0;endpoint_records=0
for p,bit in itertools.product((0,1),repeat=2):
 roles=set(zero if p==0 else one)
 for w,d,n in itertools.product((0,1),(False,True),states):
  act=(w,d,n);traces=[]
  for farleft,farright in itertools.product((0,1),repeat=2):
   tape={-2:farleft,-1:w,0:bit,1:farright};pos=0 if d else -2;now=n;visited=set();seen=set();endpoints={}
   for tick in range(1,65):
    if tape[-2]==farleft and tape[1]==farright and tape[-1]==p and pos in(-1,1):
     key=(now,pos,tape[0]);endpoints.setdefault(key,frozenset(visited))
    config=(now,pos,tuple(tape.items()))
    if pos not in tape or config in seen or(now,tape[pos])not in raw:break
    seen.add(config);visited.add(now);ww,dd,now=raw[now,tape[pos]];tape[pos]=ww;pos+=1 if dd else-1
   traces.append(endpoints)
  common=set(traces[0])
  for tr in traces[1:]:common.intersection_update(tr)
  for key in common:
   vs=frozenset().union(*(tr[key]for tr in traces))
   for q in reverse[bit].get(key,()):
    if q in roles:accepted[q,bit][act]=vs;endpoint_records+=1
  branch_actions+=1
print('BRANCHES',branch_actions,'accepted',endpoint_records,'seconds',time.monotonic()-start,flush=True)
helpers=collections.defaultdict(set)
for(a,z),oo in basepair.items():
 missing=[bit for bit in(0,1)if not oo[bit]]
 if not missing:continue
 sets=[]
 for q in(a,z):
  common=None
  for bit in missing:
   valid={act for act,vs in accepted[q,bit].items()if not vs&{a,z}}
   common=valid if common is None else common&valid
  sets.append(common)
 for aa,zz in itertools.product(*sets):helpers[aa,zz].add((a,z))

def wide_local(rows,folds,certificate=False):
 alias={a:z for a,z,acts in folds};acts={z:aa for a,z,aa in folds};records=[]
 for a,z,aa in folds:
  for q,p in((a,0),(z,1)):
   for bit,u,v in itertools.product((0,1),repeat=3):
    w,d,n=rows[q,bit];target=alias.get(n,n);wantpos=1 if d else-1
    expected={-2:u,-1:p,0:w,1:v};tape={-2:u,-1:p,0:bit,1:v};now=alias.get(q,q);pos=0;steps=[]
    for tick in range(65):
     if tick and now==target and pos==wantpos and tape==expected:break
     if pos not in tape:return False
     read=tape[pos]
     if now in acts:ww,dd,nn=acts[now][read]
     else:
      tr=rows.get((now,read))
      if tr is None:return False
      ww,dd,nn=tr
     steps.append([now,pos,read,ww,'R'if dd else'L',alias.get(nn,nn)]);tape[pos]=ww;pos+=1 if dd else-1;now=alias.get(nn,nn)
    else:return False
    if certificate:records.append({'source_state':q,'left_history':p,'read':bit,'far_left':u,'far_right':v,'raw_transition':[w,'R'if d else'L',n],'projected_target':target,'duration':len(steps),'steps':steps,'whole_tape_equal_at_boundary':True})
 return records if certificate else True
opt.local_ok=lambda rows,folds:wide_local(rows,folds)
need=len(raw)//2+1-194;basebound=len(c.max_matching(baseops));needednew=need-basebound
print('HELPERS',len(helpers),'atleastneedednew',sum(len(v)>=needednew for v in helpers.values()),'targetfolds',need,flush=True)
tried=0;matching=0;exact=0;best=999;records=[];found=False
for actions,pairs in sorted(helpers.items(),key=lambda kv:-len(kv[1])):
 if len(pairs)<needednew:continue
 tried+=1;rr=dict(raw);rr[H,0]=actions[0];rr[H,1]=actions[1];ops=[]
 for(a,z),bo in basepair.items():
  opts=[list(x)for x in bo]
  for bit in(0,1):
   va=accepted[a,bit].get(actions[0]);vz=accepted[z,bit].get(actions[1])
   if va is not None and vz is not None and not(va|vz)&{a,z}:opts[bit].append((bit,False,H))
  if all(opts):ops.append((a,z,opts))
 bound=len(c.max_matching(ops))
 if bound<need:continue
 matching+=1;chosen=opt.compatible_folds(rr,ops);cost=len(rr)//2-len(chosen);exact+=1;best=min(best,cost)
 rec={'helper_rows':actions,'potential_matching':bound,'compatible_folds':len(chosen),'states':cost};records.append(rec);print('EXACT',rec,flush=True)
 if cost>194:continue
 folded,alias=b.quotient(rr,chosen);cert=wide_local(rr,chosen,certificate=True);assert cert
 # Independently audit incoming guards against the original machine.
 for a,z,aa in chosen:
  for q,p in((a,0),(z,1)):
   assert q!=74
   incoming=[(src,bit,tr)for(src,bit),tr in raw.items()if tr[2]==q]
   assert incoming and all(tr[:2]==(p,True)for src,bit,tr in incoming)
 for(q,bit),(w,d,n)in raw.items():
  if q not in alias and q not in {z for a,z,aa in chosen}:assert folded[q,bit]==(w,d,alias.get(n,n))
 ss,ins,cs=c.source(T);runtime=c.validate(folded,cs);rec['runtime']=runtime;print('RUNTIME',runtime,flush=True)
 if not runtime['ok']:continue
 labs=[74]+sorted({q for q,bit in folded}-{74})+[254];inv={q:i for i,q in enumerate(labs)}
 dense={(inv[q],bit):(w,d,inv[n])for(q,bit),(w,d,n)in folded.items()};startup=b.startup(dense,labs);binding=b.source_binding(T,ss,ins);emitter=b.emitter(T)
 for name,table in [('machine.native.tm',folded),('machine.tm',dense)]:
  (OUT/name).write_text(''.join(f'{q} {bit} {w} {"R"if d else"L"} {n}\n'for(q,bit),(w,d,n)in sorted(table.items())))
 (OUT/'winner.json').write_text(json.dumps({'states':cost,'helper_label':H,'helper_rows':actions,'folds':chosen,'local_window_certificate':cert,'runtime':runtime,'source_binding':binding,'emitter':emitter,'startup':startup,'labels':labs},indent=2)+'\n');opt.save(T,OUT/'grammar.json');found=True;print('FULL_WINNER',cost,OUT,flush=True);break
summary={'input':str(P),'raw_states':len(raw)//2,'new_helper_controls':1,'branch_actions_screened':branch_actions,'accepted_role_bit_actions':endpoint_records,'helper_tables':len(helpers),'new_edge_prefilter_survivors':tried,'matching_survivors':matching,'exact_compatible_checks':exact,'best_checked_states':best if exact else None,'elapsed':time.monotonic()-start,'winner':found,'scope':'One new H with arbitrary write and L/R movement to an old state; merged reader steps enterH after movingL; H continuations universally simulated over[-2,-1,0,+1]for64steps. First endpoint occurrence used, visited folded roles excluded during discovery; final compatible folds use exact global replay.'}
(OUT/'receipt.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'candidates.json').write_text(json.dumps(records,indent=2)+'\n');print('DONE',summary,flush=True)
