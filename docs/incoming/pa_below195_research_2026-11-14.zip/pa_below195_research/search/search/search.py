#!/usr/bin/env python3
"""Search only; retained witnesses are independently verified by baseline checker."""
import sys, json, random, math, time, os, itertools
from pathlib import Path
from functools import lru_cache
P=Path(__file__).resolve().parents[1]/'pa195/pa195_conpa/pa195'
sys.path.insert(0,str(P))
import build_verify as v
c=v.c
old=c.machine();c.machine=lambda:old
BASE=c.read_grammar(P/'grammar.json')
OUT=Path(__file__).resolve().parent
RAW=c.raw_nodes()

@lru_cache(maxsize=30000)
def attrs(t):
    if isinstance(t,str):return attrs(RAW[t])
    if not c.isnode(t):return (0,0,0,0,t[:2]==('leaf','inc'))
    a,b=map(attrs,t)
    return (1+max(a[0],b[0]),a[1]+1,max(a[1]+1,a[2],b[2]),
            max(a[3],b[3],1+a[1] if a[4] else 0),a[4])

def grammar_safe(t):
    a=attrs(t)
    if a[0]>40 or a[2]>6 or a[3]>6:return False
    def good(x,b=None):
        if x=='node142' and b!=1:return False
        if x=='node72' and b!=0:return False
        return not c.isnode(x) or good(x[0],0) and good(x[1],1)
    return good(t)

@lru_cache(maxsize=30000)
def nonjump_runs(t):
    if isinstance(t,str):return nonjump_runs(RAW[t])
    if not c.isnode(t):
        yes=t[1] not in ('breakTo','continueTo')
        return (0 if yes else -1,0,yes)
    a,b=map(nonjump_runs,t)
    lz=max(1+a[0] if a[2] else -1,0 if b[2] else -1)
    return lz,max(lz,a[1],b[1]),a[2] or b[2]

def grammar_relaxed(t):
    a=attrs(t)
    if a[0]>40 or a[2]>8 or nonjump_runs(t)[1]>6:return False
    def good(x,b=None):
        if x=='node142' and b!=1:return False
        if x=='node72' and b!=0:return False
        return not c.isnode(x) or good(x[0],0) and good(x[1],1)
    return good(t)

def save(t,path):
    rules={}; names={}
    def rec(x):
        if not c.isnode(x):return x
        if x not in names:
            a,b=map(rec,x);n='g'+str(len(names));names[x]=n;rules[n]=[a,b]
        return names[x]
    root=rec(t);path.write_text(json.dumps({'root':root,'rules':rules},indent=2)+'\n')

def replace(t,a,b):
    if t==a:return b
    if c.isnode(t):return replace(t[0],a,b),replace(t[1],a,b)
    return t

def local_replace(t,p,new):
    if not p:return new
    if p[0]==0:return local_replace(t[0],p[1:],new),t[1]
    return t[0],local_replace(t[1],p[1:],new)

def paths(t):
    pp=[]
    def visit(x,p):
        if c.isnode(x):
            pp.append((p,x));visit(x[0],p+(0,));visit(x[1],p+(1,))
    visit(t,());return pp

def rotations(t):
    if c.isnode(t[0]):yield t[0][0],(t[0][1],t[1])
    if c.isnode(t[1]):yield (t[0],t[1][0]),t[1][1]

def regroup(x,rng):
    parts=[x]
    for _ in range(rng.randrange(2,7)):
        candidates=[i for i,a in enumerate(parts) if c.isnode(a)]
        if not candidates:break
        i=rng.choice(candidates);parts[i:i+1]=parts[i]
    def rec(pp):
        if len(pp)==1:return pp[0]
        k=rng.randrange(1,len(pp));return rec(pp[:k]),rec(pp[k:])
    return rec(parts)

def evaluate(t):
    rows,index,shape=c.build(t)
    ops=c.opportunities_fast(rows,shape)
    mm=c.max_matching(ops)
    if len(shape)-len(mm)<=63:
        folds=compatible_folds(rows,ops)
        if len(shape)-len(mm)<=60 and len(shape)-len(folds)>60:
            rescue=simultaneous_folds(rows,ops,len(shape)-60)
            if rescue is not None:folds=rescue
        return len(shape)-len(folds),len(shape),len(ops)
    return len(shape)-len(mm),len(shape),len(ops)

def simultaneous_folds(rows,ops,need):
    options=[(a,b,aa) for a,b,o in ops for aa in itertools.product(*o)]
    tested=0
    def go(start,chosen,used):
        nonlocal tested
        if tested>=100000:return None
        if len(chosen)==need:
            tested+=1
            return chosen if local_ok(rows,chosen) else None
        if len(chosen)+len(options)-start<need:return None
        for i in range(start,len(options)):
            a,b,aa=options[i]
            if a not in used and b not in used:
                result=go(i+1,chosen+[(a,b,aa)],used|{a,b})
                if result is not None:return result
        return None
    return go(0,[],set())

def local_ok(rows,folds):
    aliases={a:b for a,b,acts in folds}
    acts={b:aa for a,b,aa in folds}
    for a,b,aa in folds:
        for q,p in ((a,0),(b,1)):
            for bit in (0,1):
                w,d,n=rows[q,bit]
                target=(aliases.get(n,n),1 if d else -1,p,w)
                now=aliases.get(q,q);pos=0;left=p;right=bit
                for k in range(64):
                    if k and (now,pos,left,right)==target:break
                    if pos not in (-1,0):return False
                    read=left if pos==-1 else right
                    ww,dd,nn=acts[now][read] if now in acts else rows[now,read]
                    if pos==-1:left=ww
                    else:right=ww
                    pos+=1 if dd else -1;now=aliases.get(nn,nn)
                else:return False
    return True

def compatible_folds(rows,ops):
    options=[(a,b,aa) for a,b,o in ops for aa in itertools.product(*o)]
    n=len(options)
    conflicts=[1<<i for i in range(n)]
    for i in range(n):
        a,b,_=options[i]
        for j in range(i):
            x,y,_=options[j]
            if {a,b}&{x,y} or not local_ok(rows,[options[i],options[j]]):
                conflicts[i]|=1<<j;conflicts[j]|=1<<i
    best=[]
    def go(mask,chosen):
        nonlocal best
        if len(chosen)+mask.bit_count()<=len(best):return
        if not mask:
            fs=[options[i] for i in chosen]
            if local_ok(rows,fs):best=chosen
            return
        i=max((j for j in range(n) if mask>>j&1),key=lambda j:(conflicts[j]&mask).bit_count())
        go(mask&~conflicts[i],chosen+[i])
        go(mask&~(1<<i),chosen)
    go((1<<n)-1,[])
    return [options[i] for i in best]

def verify_winner(t,tag):
    rows,index,shape=c.build(t);ops=c.opportunities_fast(rows,shape);mm=c.max_matching(ops)
    exact=compatible_folds(rows,ops)
    if len(shape)-len(exact)>60:
        exact=simultaneous_folds(rows,ops,len(shape)-60)
        if exact is None:return False
    opt={(a,b):o for a,b,o in ops}
    save(t,OUT/(tag+'_raw.json'))
    needed=len(shape)-60
    options=[]
    for a,b,o in ops:
        for acts in itertools.product(*o):options.append((a,b,acts))
    trials=0; cert=None
    def selections(start,left,chosen,used):
        if left==0:
            yield chosen;return
        if len(options)-start<left:return
        for i in range(start,len(options)-left+1):
            a,b,acts=options[i]
            if not {a,b}&used:
                yield from selections(i+1,left-1,chosen+[(a,b,acts)],used|{a,b})
    for folds in itertools.chain([exact],selections(0,needed,[],set())):
        trials+=1
        f,alias=v.quotient(rows,folds)
        try:cert=v.quotient_certificate(rows,f,folds,alias);break
        except ValueError:pass
        if trials>=100000:break
    if cert is None:
        if trials:print('BAD_LOCAL',tag,'matching_trials',trials,flush=True)
        return False
    save(t,OUT/(tag+'.json'));(OUT/(tag+'_folds.json')).write_text(json.dumps(folds,indent=2)+'\n')
    (OUT/(tag+'_certificate.json')).write_text(json.dumps(cert,indent=2)+'\n')
    print('VERIFIED_WINNER',tag,len(f)//2,flush=True)
    return True

def exhaustive():
    seen={BASE};best=evaluate(BASE);print('BASE',best,flush=True)
    found=0
    for p,x in paths(BASE):
        for y in rotations(x):
            for t in (replace(BASE,x,y),local_replace(BASE,p,y)):
                if t in seen:continue
                seen.add(t);score=evaluate(t)
                if score[0]<best[0]:
                    print('IMPROVEMENT',score,flush=True)
                    if verify_winner(t,'single_best'):return t
                if score[0]<=best[0]:
                    save(t,OUT/f'plateau{found}.json');found+=1
    print('SINGLE_EXHAUSTIVE',len(seen),'plateaus',found,flush=True)

def run(seed,steps):
    rng=random.Random(seed);start=time.time();best=61;t=BASE;score=evaluate(t);saved=0
    pool=[BASE];evcache={BASE:score}
    for i in range(steps):
        if i%10000==0:
            t=rng.choice(pool);score=evaluate(t)
        pp=paths(t);p,x=rng.choice(pp)
        ro=list(rotations(x))
        if not ro:continue
        y=regroup(x,rng) if rng.random()<0.3 else rng.choice(ro)
        new=replace(t,x,y) if rng.random()<0.75 else local_replace(t,p,y)
        if new==t:continue
        if not grammar_safe(new):continue
        ss=evcache.get(new)
        if ss is None:
            ss=evaluate(new);evcache[new]=ss
            if len(evcache)>12000:evcache={}
        temp=[0.10,0.16,0.22,0.30,0.40][(i//10000)%5]
        delta=ss[0]-score[0]+0.008*(ss[1]-score[1])
        if delta<=0 or rng.random()<math.exp(-delta/temp):
            t,score=new,ss
            if ss[0]<=best:
                if ss[0]<best:
                    print('NEWBEST',seed,i,ss,'seconds',round(time.time()-start,1),flush=True)
                    if verify_winner(t,f'winner_{seed}_{i}'):
                        best=ss[0]
                        if best<61:return
                if rng.random()<0.05:
                    if len(pool)>150:pool.pop(rng.randrange(len(pool)))
                    pool.append(t)
        if i%5000==0:
            print('PROGRESS',seed,i,score,'best',best,'seconds',round(time.time()-start,1),flush=True)
    print('DONE',seed,steps,best,flush=True)

if __name__=='__main__':
    if len(sys.argv)==1:exhaustive()
    else:run(int(sys.argv[1]),int(sys.argv[2]))
