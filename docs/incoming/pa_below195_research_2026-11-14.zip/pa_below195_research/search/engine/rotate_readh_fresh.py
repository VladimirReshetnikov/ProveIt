from pathlib import Path
import sys,json,random,time
P=Path('work/pa195/pa195_conpa/pa195').resolve();sys.path.insert(0,str(P));import build_verify as b
c=b.c
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
ORAW=c.raw_nodes
old=c.source(c.read_grammar(P/'grammar.json'))[1]
def raw_nodes():
 d=ORAW();d['node72']=('node29',('node31','node19'));return d
c.raw_nodes=raw_nodes
out=Path('work/engine/readh_fresh');out.mkdir(exist_ok=True)
files=[Path('work/engine/zero7/candidate1.json'),Path('work/engine/zero7/candidate2.json')]
files=[p for p in files if not p.stem.endswith('_folds')]
c.MACROS['node72']=1201
seen=set();best=999
for f in files:
 try:t=c.read_grammar(f)
 except Exception:continue
 if t in seen:continue
 seen.add(t);rows,idx,shape=c.build(t)
 rows[1201,0]=(0,True,123);rows[1201,1]=(1,True,1200);rows[1200,0]=(0,True,124);rows[1200,1]=(1,True,31)
 inc={q:set() for q,bit in rows}
 for(q,bit),(w,d,n)in rows.items():
  if n in inc:inc[n].add((w,d))
 eligible={q:q for q,hist in inc.items() if q not in c.BOXSTATES and q!=74 and hist in[{(0,True)},{(1,True)}]}
 ops=c.opportunities_fast(rows,eligible);bound=len(rows)//2-len(c.max_matching(ops))
 if bound<best:best=bound;print('BOUND',f,bound,len(rows)//2,len(ops),flush=True)
 if bound<=194 or f==files[0]:
  folds=opt.compatible_folds(rows,ops);folded,alias=b.quotient(rows,folds);print('EXACT',f,len(folded)//2,len(folds),flush=True)
  if len(folded)//2<=194 or f==files[0]:
   ss,ins,cs=c.source(t);print('CFG',ins==old,flush=True)
   check=c.validate(folded,cs);print('RUNTIME',check,flush=True)
   if check['ok'] and len(folded)//2<=194:
    cert=b.quotient_certificate(rows,folded,folds,alias);opt.save(t,out/'winner_grammar.json');(out/'winner.json').write_text(json.dumps({'folds':folds,'raw':[[q,bit,*a]for(q,bit),a in rows.items()],'folded':[[q,bit,*a]for(q,bit),a in folded.items()],'local_certificate':cert,'runtime':check,'source_cfg_equal':ins==old},indent=2));break
else:print('DONE',len(seen),'bestbound',best,flush=True)
