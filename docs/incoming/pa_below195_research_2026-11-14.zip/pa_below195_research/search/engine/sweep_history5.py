from pathlib import Path
import sys,json,subprocess,hashlib,time,random
sys.path.insert(0,str(Path('work/search').resolve()));import search as s
c=s.c;v=s.v
out=Path('work/engine/coupled_history5_sweep');out.mkdir(exist_ok=True)
files=list(Path('work/reparse').glob('tie*.json'));random.Random(724).shuffle(files)
seen=set();count=0;start=time.time()
for f in files:
 try:t=c.read_grammar(f)
 except Exception:continue
 if t in seen or not s.grammar_safe(t):continue
 seen.add(t);raw,idx,shape=c.build(t);ops=c.opportunities_fast(raw,shape)
 if len(raw)//2-len(c.max_matching(ops))>195:continue
 folds=s.compatible_folds(raw,ops);rows,alias=v.quotient(raw,folds)
 if len(rows)//2>195:continue
 count+=1;(out/'input.tm').write_bytes(v.table_bytes(rows))
 r=subprocess.run(['work/engine/coupled_history5',str(out/'input.tm'),str(out/'candidate.tm')],capture_output=True,text=True)
 if 'FOUND ' in r.stdout:
  print('FOUND',f,r.stdout,flush=True)
  (out/'parent.tm').write_bytes(v.table_bytes(rows));s.save(t,out/'parent_grammar.json');(out/'parent_folds.json').write_text(json.dumps(folds,indent=2));(out/'search.log').write_text(r.stdout)
  ss,ins,cs=c.source(t);print('PARENT_RUNTIME',c.validate(rows,cs),flush=True)
  break
 if count%5==0:print('PROGRESS',count,'seed',f.name,'seconds',time.time()-start,flush=True)
else:print('DONE',count,'seen',len(seen),'seconds',time.time()-start,flush=True)
