exec(open('work/engine/search_runtime.py').read().split("print('fixed'")[0])
t=c.read_grammar(P/'grammar.json');sites,cfg,cs=c.source(t)
rr={}
for (q,b),(w,d,n) in rows.items():
 if q==34:continue
 rr[q,b]=(w,d,75 if n==34 else n)
fails=[]
for cc in cs:
 v=c.run(rr,cc)
 if v is None:fails.append(cc[:2])
print('fail count',len(fails));print('fails first',fails[:60])
Path('work/engine/scanner_fails.json').write_text(json.dumps([{'site':i,'branch':br,'path':sites[i][0],'op':sites[i][1:],'cfg':cfg[i]} for i,br in fails],indent=2))
Path('work/engine/scan194.tm').write_bytes(b.table_bytes(rr))
