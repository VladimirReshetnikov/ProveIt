from pathlib import Path
import sys,json,itertools,collections,time,random
P=Path('work/pa195/pa195_conpa/pa195').resolve();sys.path.insert(0,str(P));import build_verify as b
c=b.c
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
ENGINE={0,1,2,3,4,5,6,9,10,15,16,22,23,24,25,32,33,34,35,36,40,48,49,51,54,55,60,64,66,74,75,94,97,113,198,302}
t=c.read_grammar(P/'grammar.json');raw,idx,shape=c.build(t);oldphy=c.PHYSICAL;out=Path('work/engine/direct_register');out.mkdir(exist_ok=True)
entry=[(k,a)for k,a in raw.items() if k[0] not in ENGINE and a[2] in c.SK]
inc=collections.defaultdict(set)
for(q,bit),(w,d,n)in raw.items():inc[n].add((w,d))
eligible={q:q for q in{q for q,bit in raw}if q!=74 and q not in c.BOXSTATES and inc[q] in [{(0,True)},{(1,True)}]}
start=time.time();hist=collections.Counter();best=999
perms=list(itertools.permutations([i for i in range(9) if i!=6]));random.Random(194).shuffle(perms)
for count,tail in enumerate(perms):
 physical=(6,)+tail;mapping={c.SK[oldphy[i]]:c.SK[physical[i]] for i in range(9)}
 rr=dict(raw)
 for k,(w,d,n)in entry:rr[k]=w,d,mapping[n]
 ops=c.opportunities_fast(rr,eligible);score=len(rr)//2-len(c.max_matching(ops));hist[score]+=1
 if score<best:best=score;print('BEST',count,score,physical,'sec',time.time()-start,flush=True)
 if score<195:
  folds=opt.compatible_folds(rr,ops);print('EXACT',count,202-len(folds),flush=True)
  if 202-len(folds)<195:
   folded,alias=b.quotient(rr,folds);cert=b.quotient_certificate(rr,folded,folds,alias)
   c.PHYSICAL=physical;ss,ins,cs=c.source(t);check=c.validate(folded,cs);print('CHECK',check,flush=True)
   if check['ok']:
    (out/'winner.json').write_text(json.dumps({'physical':physical,'folds':folds,'raw':[[q,bit,*a]for(q,bit),a in rr.items()],'folded':[[q,bit,*a]for(q,bit),a in folded.items()],'local_certificate':cert,'runtime':check},indent=2));break
 if count%5000==0:print('PROGRESS',count,best,time.time()-start,flush=True)
else:
 (out/'receipt.json').write_text(json.dumps({'permutations':len(perms),'best':best,'histogram':hist,'seconds':time.time()-start},indent=2))
 print('DONE',len(perms),best,hist,flush=True)
