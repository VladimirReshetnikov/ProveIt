#include <bits/stdc++.h>
using namespace std;
struct Act{int w,d,n;};
int main(int argc,char**argv){
 ifstream f(argv[1]);map<int,array<Act,2>> rows;int q,b,w,n;char d;
 while(f>>q>>b>>w>>d>>n)rows[q][b]={w,d=='R'?1:-1,n};
 rows[66][0].n=54;rows.erase(198);
 long long bound=argc>2?stoll(argv[2]):1000000;
 int tries=0;
 for(auto [start,unused]:rows){
  unordered_set<int> ones;int state=start,head=0;long long step=0;int frames=0;
  for(;step<=bound;step++){
   if(state==84 && ones.size()>=13 && ones.count(head-1)&&ones.count(head)){
    vector<int> v(ones.begin(),ones.end());sort(v.begin(),v.end());
    if(v[0]==head-1 && v[1]==head && v[2]-head>=48){
     vector<int> regs;int last=v[2],run=0;bool ok=true;
     for(size_t i=3;i<v.size();i++){
      if(!run){if(v[i]!=last+2){ok=false;break;}run=1;last=v[i];}
      else if(v[i]==last+1){run++;last=v[i];}
      else if(v[i]==last+2){regs.push_back(run-1);run=1;last=v[i];}
      else {ok=false;break;}
     }
     if(run)regs.push_back(run-1);
     if(ok&&regs.size()>=10){
      frames++;
      bool seed=true;
      for(int i=0;i<9;i++)if(regs[i]!=(i==6?2:0))seed=false;
      if(seed){cout<<"FOUND "<<start<<" steps "<<step<<" head "<<head<<" gap "<<v[2]-head<<" regs ";for(int z:regs)cout<<z<<",";cout<<endl;return 0;}
      if(frames<=2){cout<<"FRAME start "<<start<<" step "<<step<<" gap "<<v[2]-head<<" first ";for(int i=0;i<min(12,(int)regs.size());i++)cout<<regs[i]<<",";cout<<endl;}
     }
    }
   }
   auto it=rows.find(state);if(it==rows.end())break;
   auto a=it->second[ones.count(head)?1:0];if(a.w)ones.insert(head);else ones.erase(head);head+=a.d;state=a.n;
  }
  tries++;cout<<"DONE "<<start<<" steps "<<step<<" end "<<state<<" frames "<<frames<<endl;
 }
 cout<<"ALL "<<tries<<endl;
}
