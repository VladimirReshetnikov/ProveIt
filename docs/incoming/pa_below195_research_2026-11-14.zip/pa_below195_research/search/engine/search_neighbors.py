exec(open('work/engine/search_runtime.py').read().split("print('fixed'")[0])
fixed={q:next(iter(x)) for q,x in hist.items() if len(x)==1 and q!=74}
print('hist-fixed',len(fixed))
found=[]
for a,z in itertools.combinations(fixed,2):
 pa,da=fixed[a];pb,db=fixed[z]
 if pa==pb or da!=db or {a,z}&c.BOXSTATES:continue
 opts=[]
 for bit in [0,1]:
  aa=rows[a,bit];ab=rows[z,bit]
  oo=[aa] if aa==ab else []
  for h in incoming:
   if h in [a,z]:continue
   wa,dha,ua=rows[h,pa];wb,dhb,ub=rows[h,pb]
   if wa!=pa or wb!=pb or dha!=da or dhb!=db or {ua,ub}&{a,z}:continue
   if rows.get((ua,bit))==aa and rows.get((ub,bit))==ab:oo.append((bit,not da,h))
  opts.append(oo)
 if all(opts):found.append((a,z,opts))
print('found',found)
