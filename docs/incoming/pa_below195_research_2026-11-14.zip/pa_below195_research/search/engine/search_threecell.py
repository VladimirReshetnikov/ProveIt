from pathlib import Path
import sys,json,itertools,collections,time
P=Path('work/pa195/pa195_conpa/pa195').resolve();sys.path.insert(0,str(P));import build_verify as b
c=b.c
rows=b.table(P/'pa195.native.tm') if len(sys.argv)<2 or sys.argv[1]=='folded' else c.build(c.read_grammar(P/'grammar.json'))[0]
inc=collections.defaultdict(set)
for(q,bit),(w,d,n)in rows.items():inc[n].add((w,d))
eligible={q:p for q in{q for q,bit in rows}for p in[0,1]if q!=74 and q not in c.BOXSTATES and inc[q]=={(p,True)}}
states=list({q for q,bit in rows});opts=collections.defaultdict(dict)
start=time.time()
for p,bit,rb in itertools.product([0,1],repeat=3):
 endpoint=collections.defaultdict(dict)
 for w,d,n in itertools.product([0,1],[False,True],states):
  act=(w,d,n);tape={-1:p,0:w,1:rb};pos=1 if d else -1;q=n;visited=set();seen=set()
  for tick in range(1,81):
   ep=(q,pos,tape[-1],tape[0],tape[1])
   # Save smallest set only; final candidate is rechecked literally.
   endpoint[ep][act]=frozenset(visited)
   if pos not in tape or ep in seen:break
   seen.add(ep);visited.add(q)
   if(q,tape[pos])not in rows:break
   ww,dd,q=rows[q,tape[pos]];tape[pos]=ww;pos+=1 if dd else -1
 for q,hp in eligible.items():
  if hp!=p:continue
  w,d,n=rows[q,bit];data=endpoint[n,1 if d else -1,p,w,rb]
  if rb==0:opts[q,bit]=data
  else:opts[q,bit]={act:visited|data[act] for act,visited in opts[q,bit].items() if act in data}
found=[]
for a,z in itertools.combinations(eligible,2):
 if eligible[a]==eligible[z]:continue
 choices=[]
 for bit in[0,1]:
  aa={act for act,v in opts[a,bit].items() if not v&{a,z}}
  zz={act for act,v in opts[z,bit].items() if not v&{a,z}}
  choices.append(aa&zz)
 if all(choices):found.append((a,z,[list(x)for x in choices]))
print('FOUND',len(rows)//2,len(found),found,'seconds',time.time()-start,flush=True)
Path(f'work/engine/threecell_{len(rows)//2}.json').write_text(json.dumps(found,indent=2))
