exec(open('work/engine/raw_setup.py').read().split("print('fixed'")[0])
from collections import defaultdict
from functools import lru_cache
K=int(sys.argv[1]) if len(sys.argv)>1 else 3
states=list(incoming)
@lru_cache(None)
def gethist(q,k):
 if not k:return {()}
 if q==74:return None
 poss=set()
 for pre,rb,w,d in incoming[q]:
  if not d:return None
  prehist=gethist(pre,k-1)
  if prehist is None:return None
  poss|={t+(w,) for t in prehist}
 return poss
histk={q:gethist(q,K) for q in states if gethist(q,K)}
print('histk',K,len(histk),flush=True)
options={}
for ctx in itertools.product([0,1],repeat=K):
 for bit in [0,1]:
  traces=defaultdict(list)
  for w,h in itertools.product([0,1],states):
   act=(w,False,h);tape=dict(zip(range(-K,0),ctx));tape[0]=w;pos=-1;q=h;visited=set();seen=set()
   for tick in range(1,81):
    ep=(q,pos,tuple(tape[i] for i in range(-K,1)))
    traces[ep].append((act,frozenset(visited),tick))
    if pos not in tape or ep in seen:break
    seen.add(ep);visited.add(q)
    if(q,tape[pos])not in rows:break
    ww,dd,q=rows[q,tape[pos]];tape[pos]=ww;pos+=1 if dd else -1
  for src,ps in histk.items():
   if ctx not in ps:continue
   ow,od,on=rows[src,bit];ep=(on,1 if od else -1,ctx+(ow,))
   options[src,ctx,bit]=[(rows[src,bit],frozenset(),1)]+traces[ep]
found=[]
for a,z in itertools.combinations(histk,2):
 if histk[a]&histk[z] or {a,z}&c.BOXSTATES:continue
 opts=[]
 for bit in [0,1]:
  common=None
  for src in [a,z]:
   for ctx in histk[src]:
    oo={act for act,v,ticks in options[src,ctx,bit] if not v&{a,z}}
    common=oo if common is None else common&oo
  opts.append(common)
 if all(opts):found.append((a,z,[list(o) for o in opts]))
print('found',found,flush=True)
Path(f'work/engine/history{K}_raw_found.json').write_text(json.dumps(found,indent=2))
