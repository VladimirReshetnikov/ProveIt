# Interpreter and local state-reduction audit

## Outcome

No new machine with fewer than 195 states passed the required verification gates in this workstream. The 195-state supplied machine remains the accepted reference. Several numerically 194-state tables were examined; their local quotient identities did not suffice to establish a valid source interpreter.

The strongest completed search is a coupled synthesis of both rows of a merged state. It allows the merged control to re-enter itself, allows temporary changes to tape bits, and examines all literal write/move/next-control choices. A five-bit entry-history invariant supports a six-cell window consisting of the current cell and its five left neighbors. Exact cycle detection, rather than a step cutoff, makes the search exhaustive **within this specified local simulation family**. This is not a lower bound for arbitrary Turing machines, alternate encodings, longer or differently shaped simulation relations, or alternative consistency calculi.

## Concrete rejected 194-state construction

The grammar `work/search/winner_1337_925.json` expands to 68 new AX reader controls. Together with 134 inherited controls it gives an unfolded 202-state table. Its eight proposed identifications pass all 32 local quotient cases, with durations 1, 3, and 5. The ordered primitive source word and complete ordinal control-flow graph also agree with PA195.

Nevertheless, the unfolded and folded tables both fail the complete symbolic runtime check at source site 131, zero branch of physical register 1 (logical decrement register 8), after 175 preceding contracts. Its source path is

```
101010010100000000
```

and ends in eight zeros. The inherited return scanner treats this internal zero run as a header boundary. The failure occurs in the `readH` macro: its new entry has five trailing zeros, and its internal left path adds three more. The original PA195 has maximum zero-run length six. Thus a locally valid quotient and identical source CFG do not alone justify a reassociated physical interpreter.

The two one-rotation repairs saved under `work/engine/zero7/` reduce the maximum run to seven while retaining 194 states. Both still fail site 131's zero branch.

## Completed search families

| Family | Scope | Result |
|---|---|---|
| Strong action-preserving bisimulation | Supplied raw202/folded195 and rejected raw202/folded194 | No unconditional state identifications |
| One-neighbor detours | Both possible entry directions; all writes and existing next controls; up to 64-step local detours | No new fold on PA195 |
| Larger one-sided entry histories without merged-state re-entry | Up to four history bits | Only the seven known raw-parent folds |
| Coupled two-cell synthesis | 2,887 distinguishable pairs; both replacement rows synthesized together | 35 partial survivors; no fold |
| Coupled three-cell synthesis, including blank start | 2,939 pairs; arbitrary extra-neighbor bit | 38 partial survivors; no fold |
| Coupled two-bit-history synthesis | 4,019 pairs | 877 partial survivors; no fold |
| Coupled four-bit-history synthesis | 4,640 pairs | 1,907 partial survivors; no fold |
| Coupled five-bit-history synthesis | 4,699 pairs | 2,054 partial survivors; no fold |
| Three-cell coupled sweep | 61 distinct structurally screened 195-state reparse tables | No fold |
| Four-bit-history coupled sweep | Same 61-table pool | No fold |
| Five-bit-history coupled sweep without a fuel cutoff | Same 61-table pool | No fold |
| Native physical-register permutations | All 40,320 permutations fixing logical register 0 at physical position 6 | Every simple-history matching bound remains 195 |
| One added pure-right helper | 320 baseline helper candidates; 17 can enable at least two fresh pair edges | No matching bound below 195 |
| One helper with temporary history-bit changes | 288 baseline candidate helper row pairs; 17 multiservice cases | No matching bound below 195 |
| One-helper tests of four 67-reader reparse grammars | Six baseline folds, plus one helper | No bound below 195 |
| Targeted AX-only repair beam | 131,899 distinct visited grammars, through 12 beam levels | No fully verified machine below 195 |
| Targeted repair with all strict-history endpoints | 131,899 distinct visited grammars, through 12 beam levels | No fully verified machine below 195 |

The final five-bit-history sweep completed all 61 tables in 110.03 seconds; no witness was found. Its exact input tables and manifest are retained in `coupled_inputs/`, with `ENGINE_RECEIPT.json` holding the consolidated receipt. The search scripts and logs retain the exact numerical scope; a table listed as structurally screened was not promoted to a positive consistency-machine claim merely because it passed syntactic screens.

## Coupled synthesis proof boundary

For a proposed pair of old controls, the entry-history computation overapproximates the possible last five written bits by walking incoming transitions. A left-moving incoming edge supplies all possible left histories. At native start 74 the blank history is also included. Distinct roles are considered only when these history sets are disjoint.

For each role, each allowed history, and both currently read symbols, the proposed merged state must simulate the original single transition. The endpoint comparison requires the correct projected control, head displacement, and exact full six-cell tape; every other tape cell is unvisited. The simulations may revisit the merged state and therefore use both of its newly synthesized rows. Every block has positive length.

Every possible pair of binary TM rows is considered, with targets drawn from the existing retained controls and the existing halt control. Partial-row screening discards an assignment only if a role case fails or cycles before the still-unknown other row is first consulted. The surviving row pairs receive the full checks. With no step cutoff, a repeated complete local configuration is exactly a deterministic cycle, so rejecting it loses no terminating local block.

A successful witness would give a PA-formalizable positive-block simulation, and deterministic halting reflection would follow. None was found. The search says nothing about simulations whose boundaries shift the head, alter a persistent tape representation, use different history invariants, or inspect more cells.

## Findings about other avenues

### Generic register decoder reconstruction

The older `register_permutations.py` reconstruction in `conpa_tm_comparison_and_search.zip` did not successfully enumerate its intended permutations. Its saved baseline JSON reports a 213-state raw interpreter failure at source site 33. The shared source subtree `(dec 6; continueTo 2)` is represented by context-specific jump rows `0 L 10` and `0 L 16`. Choosing `0 L 10` uniformly fails site 33; choosing `0 L 16` uniformly fails site 2. Neither failed reconstruction establishes a negative state bound for a valid generic decoder.

The new **direct native** permutation experiment is separate: it preserves the inherited optimized engine and only retargets the register-selection entry rows. All 40,320 permutations were evaluated against the local fold matching objective. No permutation reduced that objective below 195. This does not assert that every permutation has the correct blank initialization.

### Internal rotation of `readH`

The reassociation

```
node72 = ((node29, node31), node19)
       -> (node29, (node31, node19))
```

preserves the full source CFG and reduces the macro's leading zero depth. It cannot be implemented by freely rewriting native state 69: that control also implements an outside-AX role at source prefix `01`, reached with history bit 1. The direct rewrite fails source site 11's zero branch. Allocating a separate rotated root and inner join avoids that direct overwrite but costs two controls; the best tested repaired grammar has 196 states and fails a later inherited macro shortcut at source site 141. This attempt is not a valid new consistency machine.

### Append-zero tail experiment

Deleting native state 198 and retargeting 66/0 to 54 was rejected as a semantic reduction: native 198/1 is also essential to the zero-decrement protocol, not just blank initialization. Its exploratory blank-start scan therefore does not constitute a valid candidate or a meaningful general lower bound.

## Principal files

- `coupled_history5.cpp`: strongest finite local synthesis engine; cycle detection without a fuel cutoff.
- `sweep_history5.py`: reconstructs the structurally screened parent tables and invokes the synthesis engine.
- `direct_register_search.py` and `direct_register/receipt.json`: the completed 40,320-permutation experiment.
- `helper_search.py`, `helper_general.py`: finite one-helper experiments.
- `trace_winner.py`, `zero7.log`: diagnostics of the rejected 194-state grammar.
- `rotate_readh.py`, `rotate_readh_fresh.py`: internal-macro experiments and their failure logs.

All these files are research and audit artifacts. No new Lean or Rocq kernel theorem is claimed.
