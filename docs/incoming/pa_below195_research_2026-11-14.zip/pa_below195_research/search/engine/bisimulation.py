from pathlib import Path
import sys,json,collections
P=Path('work/pa195/pa195_conpa/pa195').resolve();sys.path.insert(0,str(P));import build_verify as b
c=b.c

def quotient(rows):
 states=sorted({q for q,bit in rows}|{n for w,d,n in rows.values()});groups={q:int((q,0)in rows) for q in states}
 while True:
  keys={};ng={}
  for q in states:
   k=tuple((w,d,groups[n])for bit in [0,1] for w,d,n in [rows[q,bit]]) if(q,0)in rows else ('halt',)
   if k not in keys:keys[k]=len(keys)
   ng[q]=keys[k]
  if all((groups[a]==groups[z])==(ng[a]==ng[z]) for a in states for z in states):break
  groups=ng
 classes=collections.defaultdict(list)
 for q,g in ng.items():classes[g].append(q)
 return [v for v in classes.values() if len(v)>1]
for f in [P/'grammar.json',Path('work/search/winner_1337_925.json')]:
 rr,idx,sh=c.build(c.read_grammar(f));print(f.name,'raw',len(rr)//2,'merges',quotient(rr),flush=True)
 fs=Path(str(f).replace('.json','_folds.json'))
 if f==P/'grammar.json':fs=P/'folds.json'
 fo,_=b.quotient(rr,json.loads(fs.read_text()));print('folded',len(fo)//2,'merges',quotient(fo),flush=True)
# All fixed physically identical rows target macros become compiler extra rules.
fixed,_=c.machine();fixed={k:v for k,v in fixed.items() if k[0]<1300}
print('fixeddirect',{q:[x for x in {i for i,b in fixed} if x!=q and all(fixed[x,bit]==fixed[q,bit] for bit in [0,1])] for q in c.MACROS.values()},flush=True)
