import sys
from pathlib import Path
from collections import defaultdict
sys.path.insert(0,str(Path('work/search').resolve()));import search as s
c=s.c;original_op=c.opportunities_fast

def allops(rows,shape,ignore_incoming=frozenset()):
 inc=defaultdict(set)
 for (q,bit),(w,d,n) in rows.items():inc[n].add((w,d))
 eligible={q:q for q in {q for q,bit in rows} if q!=74 and q not in c.BOXSTATES and inc[q] in [{(0,True)},{(1,True)}]}
 return original_op(rows,eligible,ignore_incoming)
c.opportunities_fast=allops
src=Path('work/engine/repair_diverse.py').read_text().replace('repair_diverse\');','repair_allcontrols\');').replace("out=Path('work/engine/repair_diverse')","out=Path('work/engine/repair_allcontrols')")
exec(compile(src,'repair_allcontrols_dynamic','exec'))
