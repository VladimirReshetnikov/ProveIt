#include <bits/stdc++.h>
using namespace std;
struct Act {int w,d,n;bool operator<(const Act&o)const{return tie(w,d,n)<tie(o.w,o.d,o.n);} };
const int MAXQ=7000;
Act table[MAXQ][2];bool active[MAXQ];unsigned seen[MAXQ*8];unsigned stamp=0;
vector<int> states;
int a,b,side;
int aliasq(int q){return q==a?b:q;}
bool sim(int role,int p,int bit,const Act &A0,const Act &A1,int known=-1){
 auto target=table[role][bit];int targetq=aliasq(target.n),targetpos=target.d,wanttape=(p<<1)|target.w;
 int q=b,pos=0,tape=(p<<1)|bit;stamp++;
 for(int steps=0;steps<2048;steps++){
  if(steps && q==targetq && pos==targetpos && tape==wanttape)return true;
  if(pos!=0&&pos!=side)return false;
  if(!active[q])return false;
  int idx=pos==0?0:1,read=(tape>>idx)&1;
  if(q==b && known>=0 && read!=known)return true;
  unsigned key=q*8+idx*4+tape;if(seen[key]==stamp)return false;seen[key]=stamp;
  Act ac=q==b?(read?A1:A0):table[q][read];
  tape=(tape&~(1<<idx))|(ac.w<<idx);pos+=ac.d;q=aliasq(ac.n);
 }
 return false;
}
int main(int argc,char**argv){
 ifstream f(argv[1]);int q,bit,w,n;char d;
 while(f>>q>>bit>>w>>d>>n){table[q][bit]={w,d=='R'?1:-1,n};active[q]=true;}
 for(int i=0;i<MAXQ;i++)if(active[i])states.push_back(i);
 map<int,set<pair<int,int>>> incoming;
 for(int q:states)for(int bit=0;bit<2;bit++){auto t=table[q][bit];incoming[t.n].insert({t.w,t.d});}
 vector<tuple<int,int,int>> fixed;
 for(int q:states)if(incoming[q].size()==1){auto [p,d]=*incoming[q].begin();fixed.push_back({q,p,-d});}
 int pairs=0,partials=0;auto start=chrono::steady_clock::now();
 for(auto [qa,pa,sa]:fixed)for(auto [qb,pb,sb]:fixed){
  if(pa!=0||pb!=1||sa!=sb)continue;
  a=qa;b=qb;side=sa;pairs++;
  vector<Act> cand[2];set<Act> pool;
  for(int w=0;w<2;w++)for(int d:{-1,1}){for(int q:states)pool.insert({w,d,aliasq(q)});pool.insert({w,d,254});}
  Act dummy={0,1,0};
  for(int bit=0;bit<2;bit++)for(Act act:pool){
   Act x=bit?dummy:act,y=bit?act:dummy;
   if(sim(a,0,bit,x,y,bit)&&sim(b,1,bit,x,y,bit))cand[bit].push_back(act);
  }
  if(cand[0].empty()||cand[1].empty())continue;
  partials++;cout<<"PARTIAL "<<a<<" "<<b<<" side "<<side<<" options "<<cand[0].size()<<" "<<cand[1].size()<<endl;
  for(Act A0:cand[0])for(Act A1:cand[1]){
   bool ok=true;for(int p=0;p<2&&ok;p++)for(int bit=0;bit<2;bit++)if(!sim(p?b:a,p,bit,A0,A1)) {ok=false;break;}
   if(!ok)continue;
   cout<<"FOUND "<<a<<" "<<b<<" "<<side<<" "<<A0.w<<" "<<A0.d<<" "<<A0.n<<" "<<A1.w<<" "<<A1.d<<" "<<A1.n<<endl;
   ofstream out(argv[2]);for(int q:states)if(q!=a)for(int bit=0;bit<2;bit++){Act ac=q==b?(bit?A1:A0):table[q][bit];out<<q<<" "<<bit<<" "<<ac.w<<" "<<(ac.d==1?'R':'L')<<" "<<aliasq(ac.n)<<"\n";}
   ofstream receipt(string(argv[2])+".json");receipt<<"{\"removed\":"<<a<<",\"retained\":"<<b<<",\"context_side\":"<<side<<",\"actions\":[["<<A0.w<<","<<(A0.d==1?"true":"false")<<","<<A0.n<<"],["<<A1.w<<","<<(A1.d==1?"true":"false")<<","<<A1.n<<"]]}\n";
   return 0;
  }
 }
 cout<<"DONE pairs "<<pairs<<" partials "<<partials<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
}
