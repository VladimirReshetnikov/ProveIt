from pathlib import Path
import sys,json,itertools
P=Path('work/pa195/pa195_conpa/pa195').resolve()
sys.path.insert(0,str(P)); import build_verify as b
c=b.c
rows=b.table(P/'pa195.native.tm')
incoming={q:[] for q,_ in rows}
for (q,bit),(w,d,n) in rows.items():
 if n in incoming:incoming[n].append((q,bit,w,d))
hist={q:set((w,d) for _,_,w,d in inc) for q,inc in incoming.items()}
fixed={q:next(iter(x))[0] for q,x in hist.items() if len(x)==1 and next(iter(x))[1] and q!=74}
sh={q:q for q in fixed}
print('fixed',len(fixed))
ops=c.opportunities_fast(rows,sh)
ops=[(a,z,opts) for a,z,opts in ops if fixed[a]==0 and fixed[z]==1 and not ({a,z}&c.BOXSTATES)]
print('ops',len(ops),ops)
for a,z,opts in ops:
 for acts in itertools.product(*opts):
  fold=[(a,z,acts)]
  out,aliases=b.quotient(rows,fold)
  try:cert=b.quotient_certificate(rows,out,fold,aliases)
  except Exception:continue
  print('FOUND',a,z,acts)
  Path(f'work/engine/fold_{a}_{z}.json').write_text(json.dumps(fold,indent=2))
  Path(f'work/engine/fold_{a}_{z}.tm').write_bytes(b.table_bytes(out))
