from pathlib import Path
import sys,json,itertools,collections,time,random
from functools import lru_cache
P=Path('work/pa195/pa195_conpa/pa195').resolve();sys.path.insert(0,str(P));import build_verify as b
c=b.c
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
ENGINE={0,1,2,3,4,5,6,9,10,15,16,22,23,24,25,32,33,34,35,36,40,48,49,51,54,55,60,64,66,74,75,94,97,113,198,302}
ax=c.read_grammar(P/'grammar.json');nodes=c.raw_nodes()
@lru_cache(None)
def expand(t):
 if isinstance(t,str):return expand(ax if t=='x67' else nodes[t])
 return tuple(map(expand,t)) if c.isnode(t) else t
TREE=expand('node172');OLD,_,_=c.build(ax);sites,ins,cs=c.source(ax)
CAT={tuple(k):set(map(tuple,v)) for k,v in json.loads(Path('work/engine/swap_reference/conpa_tm_study/research_ipra/newsearch/leaf_actions.json').read_text())}
INDEX={};SHAPE={}
def intern(t):
 if not c.isnode(t):return None
 if t in INDEX:return INDEX[t]
 for x in t:intern(x)
 q=84 if t==TREE else 3000+len(INDEX);INDEX[t]=q;SHAPE[q]=t;return q
intern(TREE)
byq=collections.defaultdict(set)
def interfaces(t,p=()):
 if not c.isnode(t):return
 q=84;h=0
 for _ in range(500):
  if h==len(p):byq[q].add(t);break
  if not 0<=h<len(p):break
  bit=p[h];w,d,q=OLD[q,bit]
  if w!=bit:break
  h+=1 if d else -1
 interfaces(t[0],p+(0,));interfaces(t[1],p+(1,))
interfaces(TREE)
HELPER={q:INDEX[next(iter(ts))] for q,ts in byq.items() if len(ts)==1}
HELPER.update({108:INDEX[expand('node0')],42:INDEX[expand('node9')]})
JUMPS=collections.defaultdict(set)
for p,op,arg in sites:
 if op in ('inc','dec'):continue
 q,h=84,0
 for _ in range(500):
  bit=p[h];act=OLD[q,bit]
  if h==len(p)-1 and act in CAT[op,arg,bit]:break
  q=act[2];h+=1 if act[1] else -1
 else:raise ValueError((p,op,arg))
 par=TREE
 for bit in p[:-1]:par=par[bit]
 w,d,n=act
 if n not in ENGINE|{254}:n=HELPER[n]
 JUMPS[INDEX[par],p[-1]].add((w,d,n))
print('nodes',len(INDEX),'ambiguous jumps',[(k,v) for k,v in JUMPS.items() if len(v)>1],flush=True)
def build(physical):
 rows={(q,bit):OLD[q,bit] for q in ENGINE for bit in [0,1]};shape=dict(SHAPE)
 for kind in ['inc','dec']:
  for r in range(9):
   q=4000+(kind=='dec')*9+r
   rows[q,0]=0,True,49 if kind=='inc' else 24
   rows[q,1]=0,True,c.SK[physical[r]]
   shape[q]=('router',kind,r)
 for t,q in INDEX.items():
  for bit,x in enumerate(t):
   if c.isnode(x):act=bit,True,INDEX[x]
   else:
    _,op,arg=x
    if op in ['inc','dec']:act=bit,True,4000+(op=='dec')*9+arg
    else:act=max(JUMPS[q,bit])
   rows[q,bit]=act
 return rows,shape

def contracts(physical):
 out=[]
 for i,code in enumerate(ins):
  st=c.frame(sites[i][0])
  if code[0]=='inc':
   _,r,n=code;out.append((i,None,st,c.canonical(c.frame(sites[n][0],0,('x','inc',physical[r])))))
  elif code[0]=='dec':
   _,r,z,p=code
   out.append((i,(physical[r],True),st,c.canonical(c.frame(sites[z][0]))))
   out.append((i,(physical[r],False),st,c.canonical(c.frame(sites[p][0],1,('x','dec',physical[r])))))
  elif code[0]=='jump':out.append((i,None,st,c.canonical(c.frame(sites[code[1]][0]))))
  else:out.append((i,None,st,None))
 return out

def main():
 rows,shape=build(c.PHYSICAL);check=c.validate(rows,contracts(c.PHYSICAL));print('RAW',len(rows)//2,check,flush=True);assert check['ok']
 ops=c.opportunities_fast(rows,shape);print('BASE',len(ops),len(c.max_matching(ops)),flush=True)
 out=Path('work/engine/register_search');out.mkdir(exist_ok=True)
 (out/'baseline.json').write_text(json.dumps({'rows':[[q,bit,*act] for(q,bit),act in rows.items()],'shapes':len(shape),'raw_validation':check,'max_matching':len(c.max_matching(ops))},indent=2))
 perms=list(itertools.permutations([i for i in range(9) if i!=6]));random.Random(194).shuffle(perms)
 best=999;hist=collections.Counter();start=time.time()
 for num,tail in enumerate(perms):
  physical=(6,)+tail;rr,sh=build(physical);ops=c.opportunities_fast(rr,sh);bound=len(c.max_matching(ops));score=len(rr)//2-bound;hist[score]+=1
  if score<best:
   best=score;print('BEST',num,score,physical,'ops',len(ops),'sec',time.time()-start,flush=True)
  if score<=194:
   folds=opt.compatible_folds(rr,ops)
   print('EXACT',num,len(rr)//2-len(folds),physical,flush=True)
   if len(rr)//2-len(folds)<=194:
    rows,aliases=b.quotient(rr,folds);cert=b.quotient_certificate(rr,rows,folds,aliases);cc=contracts(physical);res=c.validate(rows,cc)
    print('CHECK',res,flush=True)
    if res['ok']:
     (out/'winner.json').write_text(json.dumps({'physical':physical,'folds':folds,'raw':[[q,bit,*a] for(q,bit),a in rr.items()],'folded':[[q,bit,*a] for(q,bit),a in rows.items()],'certificate':cert,'runtime':res},indent=2));return
  if num%1000==0:print('PROGRESS',num,best,time.time()-start,flush=True)
 (out/'search_receipt.json').write_text(json.dumps({'permutations':len(perms),'best':best,'histogram':hist,'seconds':time.time()-start},indent=2))
if __name__=='__main__':main()
