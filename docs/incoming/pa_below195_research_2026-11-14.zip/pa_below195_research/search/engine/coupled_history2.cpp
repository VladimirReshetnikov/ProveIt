#include <bits/stdc++.h>
using namespace std;
struct Act {int w,d,n;bool operator<(const Act&o)const{return tie(w,d,n)<tie(o.w,o.d,o.n);} };
const int MAXQ=7000;Act table[MAXQ][2];bool active[MAXQ];unsigned seen[MAXQ*24];unsigned stamp=0;vector<int> states;int a,b;
int aliasq(int q){return q==a?b:q;}
bool sim(int role,int ctx,int bit,const Act&A0,const Act&A1,int known=-1){
 auto target=table[role][bit];int targetq=aliasq(target.n),targetpos=target.d,wanttape=(ctx<<1)|target.w;
 int q=b,pos=0,tape=(ctx<<1)|bit;stamp++;
 for(int steps=0;steps<8000;steps++){
  if(steps&&q==targetq&&pos==targetpos&&tape==wanttape)return true;
  if(pos>0||pos < -2||!active[q])return false;
  int idx=-pos,read=(tape>>idx)&1;
  if(q==b&&known>=0&&read!=known)return true;
  unsigned key=q*24+idx*8+tape;if(seen[key]==stamp)return false;seen[key]=stamp;
  Act ac=q==b?(read?A1:A0):table[q][read];tape=(tape&~(1<<idx))|(ac.w<<idx);pos+=ac.d;q=aliasq(ac.n);
 }
 return false;
}
int main(int argc,char**argv){
 ifstream f(argv[1]);int q,bit,w,n;char d;
 vector<pair<int,Act>> inc[MAXQ];
 while(f>>q>>bit>>w>>d>>n){table[q][bit]={w,d=='R'?1:-1,n};active[q]=true;inc[n].push_back({q,table[q][bit]});}
 for(int i=0;i<MAXQ;i++)if(active[i])states.push_back(i);
 int hist[MAXQ][3];for(int q:states)hist[q][0]=1;
 for(int k=1;k<=2;k++)for(int q:states){
  int mask=q==74?1:0;
  for(auto [pre,ac]:inc[q]){
   if(ac.d==-1){mask=(1<<(1<<k))-1;break;}
   for(int j=0;j<(1<<(k-1));j++)if(hist[pre][k-1]&(1<<j))mask|=1<<(j*2+ac.w);
  }
  hist[q][k]=mask;
 }
 int pairs=0,partials=0;auto start=chrono::steady_clock::now();
 for(int aa=0;aa<(int)states.size();aa++)for(int bb=aa+1;bb<(int)states.size();bb++){
  a=states[aa];b=states[bb];int ha=hist[a][2],hb=hist[b][2];if(!ha||!hb||(ha&hb))continue;pairs++;
  vector<Act> cand[2];set<Act> pool;
  for(int w=0;w<2;w++)for(int d:{-1,1}){for(int q:states)pool.insert({w,d,aliasq(q)});pool.insert({w,d,254});}
  Act dummy={0,1,0};
  for(int bit=0;bit<2;bit++)for(Act act:pool){
   Act x=bit?dummy:act,y=bit?act:dummy;bool ok=true;
   for(int role:{a,b})for(int ctx=0;ctx<4;ctx++)if(hist[role][2]&(1<<ctx))if(!sim(role,ctx,bit,x,y,bit))ok=false;
   if(ok)cand[bit].push_back(act);
  }
  if(cand[0].empty()||cand[1].empty())continue;partials++;
  cout<<"PARTIAL "<<a<<" "<<b<<" histories "<<ha<<" "<<hb<<" options "<<cand[0].size()<<" "<<cand[1].size()<<endl;
  for(Act A0:cand[0])for(Act A1:cand[1]){
   bool ok=true;
   for(int role:{a,b})for(int ctx=0;ctx<4;ctx++)if(hist[role][2]&(1<<ctx))for(int bit=0;bit<2;bit++)if(!sim(role,ctx,bit,A0,A1))ok=false;
   if(!ok)continue;
   cout<<"FOUND "<<a<<" "<<b<<" "<<ha<<" "<<hb<<" "<<A0.w<<" "<<A0.d<<" "<<A0.n<<" "<<A1.w<<" "<<A1.d<<" "<<A1.n<<endl;
   ofstream out(argv[2]);for(int q:states)if(q!=a)for(int bit=0;bit<2;bit++){Act ac=q==b?(bit?A1:A0):table[q][bit];out<<q<<" "<<bit<<" "<<ac.w<<" "<<(ac.d==1?'R':'L')<<" "<<aliasq(ac.n)<<"\n";}
   ofstream receipt(string(argv[2])+".json");receipt<<"{\"removed\":"<<a<<",\"retained\":"<<b<<",\"histories\":["<<ha<<","<<hb<<"],\"actions\":[["<<A0.w<<","<<(A0.d==1?"true":"false")<<","<<A0.n<<"],["<<A1.w<<","<<(A1.d==1?"true":"false")<<","<<A1.n<<"]]}\n";return 0;
  }
 }
 cout<<"DONE pairs "<<pairs<<" partials "<<partials<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
}
