from pathlib import Path
import sys,json,time,random,math
from functools import lru_cache
sys.path.insert(0,str(Path('work/search').resolve()));import search as s
c=s.c;raw=c.raw_nodes();rng=random.Random(4051)
@lru_cache(None)
def attrs(t):
 if isinstance(t,str):return attrs(raw[t])
 if not c.isnode(t):return 0,0,0,1
 a,b=map(attrs,t);return 1+max(a[0],b[0]),a[1]+1,max(1+a[1],a[2],b[2]),a[3]+b[3]
@lru_cache(None)
def violations(t,tail):
 if tail>=7:return attrs(t)[3]
 if isinstance(t,str):return violations(raw[t],tail)
 if not c.isnode(t):return 0
 return violations(t[0],tail+1)+violations(t[1],0)
def guard(t,bit=None):
 if (t=='node72' and bit!=0) or (t=='node142' and bit!=1):return False
 return not c.isnode(t) or guard(t[0],0) and guard(t[1],1)
T=c.read_grammar(Path('work/search/winner_1337_925.json'));seen={T};beam=[T];out=Path('work/engine/repair_diverse');out.mkdir(exist_ok=True)
start=time.time();checks=0;best=999
for depth in range(12):
 cand=[]
 for t in beam:
  for p,x in s.paths(t):
   ys=list(s.rotations(x))
   if depth%3==2:ys+=[s.regroup(x,rng)]
   for y in ys:
    for nt in (s.replace(t,x,y),s.local_replace(t,p,y)):
     if nt in seen:continue
     seen.add(nt)
     if not guard(nt):continue
     nz=attrs(nt)[2]
     if nz>8:continue
     ns=s.evaluate(nt)
     if ns[0]>62:continue
     nv=violations(nt,0)
     cand.append((ns[0]+max(0,nz-6)*1.05+nv*0.0001,ns[0],nz,nv,nt))
     if ns[0]<=60 and nz<=6:
      rr,idx,sh=c.build(nt);folds=s.compatible_folds(rr,c.opportunities_fast(rr,sh));fo,ali=s.v.quotient(rr,folds)
      ss,ins,cs=c.source(nt);check=c.validate(fo,cs);print('CANDIDATE',depth,ns,nz,check,flush=True);checks+=1
      s.save(nt,out/f'candidate{checks}.json');(out/f'candidate{checks}_folds.json').write_text(json.dumps(folds,indent=2))
      if check['ok']:
       s.save(nt,out/'winner.json');(out/'winner_folds.json').write_text(json.dumps(folds,indent=2));print('WINNER',flush=True);raise SystemExit()
 cand.sort(key=lambda z:z[:4])
 # Keep progress both on valid195 and invalid194 frontier, with randomized ties.
 groups={}
 for item in cand:groups.setdefault(item[1:4],[]).append(item)
 beam=[]
 for key in sorted(groups,key=lambda z:z[0]+max(0,z[1]-6)*1.05+z[2]*.0001):
  group=groups[key];rng.shuffle(group)
  beam.extend(z[-1] for z in group[:8])
  if len(beam)>=48:break
 print('DEPTH',depth,'candidates',len(cand),'beam',len(beam),'seen',len(seen),'best',[(a,b,c,d) for a,b,c,d,t in cand[:5]],'seconds',time.time()-start,flush=True)
 if not beam:break
