from pathlib import Path
import sys,json,hashlib,random,re
sys.path.insert(0,str(Path('work/search').resolve()));import search as s
c=s.c;v=s.v
out=Path('work/engine/coupled_inputs');out.mkdir(exist_ok=True)
files=list(Path('work/reparse').glob('tie*.json'));random.Random(724).shuffle(files)
seen=set();entries=[]
for f in files:
 t=c.read_grammar(f)
 if t in seen or not s.grammar_safe(t):continue
 seen.add(t);raw,idx,shape=c.build(t);ops=c.opportunities_fast(raw,shape)
 if len(raw)//2-len(c.max_matching(ops))>195:continue
 folds=s.compatible_folds(raw,ops);rows,alias=v.quotient(raw,folds)
 if len(rows)//2>195:continue
 i=len(entries)+1;data=v.table_bytes(rows);name=f'parent_{i:03d}.tm';(out/name).write_bytes(data)
 s.save(t,out/f'grammar_{i:03d}.json')
 entries.append({'index':i,'source_seed':str(f),'table':name,'table_sha256':hashlib.sha256(data).hexdigest(),'states':len(rows)//2,'raw_states':len(raw)//2,'folds':folds})
baseline=Path('work/pa195/pa195_conpa/pa195/pa195.native.tm')
(out/'baseline_pa195.native.tm').write_bytes(baseline.read_bytes())
receipts={'status':'No verified machine below 195 states found','baseline_dense_sha256':'5c6afd87f7c4f24d9ad8e9e302cc21df14b6f2e3715d03322a75463a431d8455','baseline_native_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'coupled_history5':{'left_history_bits':5,'window_positions':[-5,-4,-3,-2,-1,0],'cycle_detection':True,'fuel_cutoff':None,'blank_start_included':True,'baseline_pairs':4699,'baseline_partial_survivors':2054,'baseline_witnesses':0,'reparse_tables':len(entries),'distinct_literal_table_hashes':len({x['table_sha256']for x in entries}),'reparse_witnesses':0,'sweep_seconds':110.02677488327026},'direct_physical_register_permutations':json.loads(Path('work/engine/direct_register/receipt.json').read_text()),'pure_helper':json.loads(Path('work/engine/helper/receipt.json').read_text()),'general_helper':json.loads(Path('work/engine/helper_general/receipt.json').read_text()),'inputs':entries}
(out/'manifest.json').write_text(json.dumps(entries,indent=2)+'\n');Path('work/engine/ENGINE_RECEIPT.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps({k:x for k,x in receipts.items()if k!='inputs'},indent=2))
p=Path('work/engine/ENGINE_AUDIT.md');text=p.read_text().replace('| Four-bit-history coupled sweep | Same 61-table pool | No fold |','| Four-bit-history coupled sweep | Same 61-table pool | No fold |\n| Five-bit-history coupled sweep without a fuel cutoff | Same 61-table pool | No fold |').replace('The five-bit-history sweep receipt is recorded separately when its final process finishes.','The final five-bit-history sweep completed all 61 tables in 110.03 seconds; no witness was found. Its exact input tables and manifest are retained in `coupled_inputs/`, with `ENGINE_RECEIPT.json` holding the consolidated receipt.')
p.write_text(text)
