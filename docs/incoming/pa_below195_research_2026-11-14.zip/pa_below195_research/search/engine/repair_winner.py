from pathlib import Path
import sys,json,time,random,math
from functools import lru_cache
sys.path.insert(0,str(Path('work/search').resolve()));import search as s
c=s.c
raw=c.raw_nodes()
@lru_cache(None)
def attrs(t):
 if isinstance(t,str):return attrs(raw[t])
 if not c.isnode(t):return 0,0,0
 a,b=map(attrs,t);return 1+max(a[0],b[0]),a[1]+1,max(1+a[1],a[2],b[2])
def guard(t,bit=None):
 if (t=='node72' and bit!=0) or (t=='node142' and bit!=1):return False
 return not c.isnode(t) or guard(t[0],0) and guard(t[1],1)
T=c.read_grammar(Path('work/search/winner_1337_925.json'));seen={T};beam=[T];out=Path('work/engine/repair');out.mkdir(exist_ok=True)
start=time.time()
for depth in range(8):
 cand=[]
 for t in beam:
  score=s.evaluate(t)[0];az=attrs(t)[2]
  for p,x in s.paths(t):
   for y in s.rotations(x):
    for nt in (s.replace(t,x,y),s.local_replace(t,p,y)):
     if nt in seen:continue
     seen.add(nt)
     if not guard(nt):continue
     nz=attrs(nt)[2]
     if nz>8:continue
     ns=s.evaluate(nt)
     if ns[0]>63:continue
     cand.append((ns[0]+max(0,nz-6)*0.5,ns[0],nz,nt))
     if ns[0]<=60 and nz<=6:
      rr,idx,sh=c.build(nt);folds=s.compatible_folds(rr,c.opportunities_fast(rr,sh));fo,ali=s.v.quotient(rr,folds)
      ss,ins,cs=c.source(nt);check=c.validate(fo,cs);print('CANDIDATE',depth,ns,nz,check,flush=True)
      if check['ok']:
       s.save(nt,out/'winner.json');(out/'folds.json').write_text(json.dumps(folds,indent=2));print('WINNER',flush=True);raise SystemExit()
 cand.sort(key=lambda z:z[:3]);beam=[z[3] for z in cand[:25]]
 print('DEPTH',depth,'candidates',len(cand),'seen',len(seen),'best',[(a,b,c) for a,b,c,t in cand[:5]],'seconds',time.time()-start,flush=True)
 if not beam:break
