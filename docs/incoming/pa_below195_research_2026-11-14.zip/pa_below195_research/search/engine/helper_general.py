from pathlib import Path
import sys,json,itertools,collections,time
P=Path('work/pa195/pa195_conpa/pa195').resolve();sys.path.insert(0,str(P));import build_verify as b
c=b.c
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
T=c.read_grammar(Path(sys.argv[1]) if len(sys.argv)>1 else P/'grammar.json');raw,idx,shape=c.build(T);H=2900
out=Path(sys.argv[2]) if len(sys.argv)>2 else Path('work/engine/helper_general');out.mkdir(exist_ok=True,parents=True)
inc=collections.defaultdict(set)
for(q,bit),(w,d,n)in raw.items():inc[n].add((w,d))
eligible={q:q for q in{q for q,bit in raw}if q!=74 and q not in c.BOXSTATES and inc[q] in [{(0,True)},{(1,True)}]}
baseops=c.opportunities_fast(raw,eligible);states=sorted({q for q,bit in raw})
zero=[q for q in eligible if inc[q]=={(0,True)}];one=[q for q in eligible if inc[q]=={(1,True)}]
# Original incomplete options (same branch or an existing pureR provider).
providers=[collections.defaultdict(list),collections.defaultdict(list)]
for h in states:
 w0,d0,u0=raw[h,0];w1,d1,u1=raw[h,1]
 if w0 or w1!=1 or not d0 or not d1:continue
 for bit in [0,1]:
  if(u0,bit)in raw and(u1,bit)in raw:providers[bit][raw[u0,bit],raw[u1,bit]].append((h,u0,u1))
basepair={}
for a,z in itertools.product(zero,one):
 opts=[]
 for bit in [0,1]:
  oo=[raw[a,bit]] if raw[a,bit]==raw[z,bit] else []
  oo += [(bit,False,h) for h,u0,u1 in providers[bit][raw[a,bit],raw[z,bit]] if not {a,z}&{h,u0,u1}]
  opts.append(oo)
 basepair[a,z]=opts
# For each old role/current bit, all helperbranch actions yielding old one-step result.
accepted=collections.defaultdict(dict)
for p,bit in itertools.product([0,1],repeat=2):
 traces=collections.defaultdict(dict)
 for ww,n in itertools.product([0,1],states):
  act=(ww,True,n);tape={-1:ww,0:bit};pos=0;q=n;visited=set();seen=set()
  for tick in range(1,64):
   ep=(q,pos,tape[-1],tape[0])
   traces[ep][act]=frozenset(visited)
   if pos not in tape or ep in seen:break
   seen.add(ep);visited.add(q)
   if(q,tape[pos])not in raw:break
   w,d,q=raw[q,tape[pos]];tape[pos]=w;pos+=1 if d else -1
 for q in zero if p==0 else one:
  w,d,n=raw[q,bit];accepted[q,bit]=traces[n,1 if d else -1,p,w]
helpers=collections.defaultdict(set)
for(a,z),oo in basepair.items():
 missing=[bit for bit in [0,1] if not oo[bit]]
 if not missing:continue
 sets=[]
 for q in [a,z]:
  common=None
  for bit in missing:
   valid={act for act,visited in accepted[q,bit].items() if not visited&{a,z}}
   common=valid if common is None else common&valid
  sets.append(common)
 for aa,zz in itertools.product(*sets):helpers[aa,zz].add((a,z))
print('HELPERS',len(helpers),'multinew',sum(len(v)>=2 for v in helpers.values()),flush=True)
start=time.time();best=195;tried=0
for acts,pairs in sorted(helpers.items(),key=lambda kv:-len(kv[1])):
 if len(pairs)<2:continue
 tried+=1;rr=dict(raw);rr[H,0]=acts[0];rr[H,1]=acts[1];ops=[]
 for(a,z),bo in basepair.items():
  opts=[list(x) for x in bo]
  for bit in [0,1]:
   va=accepted[a,bit].get(acts[0]);vz=accepted[z,bit].get(acts[1])
   if va is not None and vz is not None and not (va|vz)&{a,z}:opts[bit].append((bit,False,H))
  if all(opts):ops.append((a,z,opts))
 score=len(rr)//2-len(c.max_matching(ops))
 if score<best:best=score;print('BOUND',tried,score,acts,'ops',len(ops),flush=True)
 if score<=194:
  folds=opt.compatible_folds(rr,ops);cost=len(rr)//2-len(folds);print('EXACT',tried,cost,acts,flush=True)
  if cost<=194:
   folded,alias=b.quotient(rr,folds)
   try:cert=b.quotient_certificate(raw,folded,folds,alias)
   except Exception as e:print('BAD',str(e),flush=True);continue
   ss,ins,cs=c.source(T);res=c.validate(folded,cs);print('RUNTIME',res,flush=True)
   if res['ok']:
    (out/'winner.json').write_text(json.dumps({'helper':[H,*acts],'folds':folds,'raw':[[q,bit,*a]for(q,bit),a in raw.items()],'folded':[[q,bit,*a]for(q,bit),a in folded.items()],'certificate':cert,'runtime':res},indent=2));print('WINNER',cost,flush=True);break
else:
 (out/'receipt.json').write_text(json.dumps({'helpers':len(helpers),'tried_multi':tried,'bestbound':best,'seconds':time.time()-start},indent=2));print('DONE',tried,best,time.time()-start,flush=True)
