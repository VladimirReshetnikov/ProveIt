exec(open('work/engine/raw_setup.py').read().split("print('fixed'")[0])
from collections import defaultdict
states=list(incoming)
# Sound possible last-two-written-bit histories; only roles with two R entries.
hist2={}
for q in states:
 if q==74:continue
 poss=set();bad=False
 for pre,rb,w,d in incoming[q]:
  if not d or pre==74:bad=True;break
  for prepre,rrb,ww,dd in incoming[pre]:
   if not dd:bad=True;break
   poss.add((ww,w))
  if bad:break
 if not bad and poss:hist2[q]=poss
print('hist2',len(hist2),flush=True)
# Candidate representative action move left into existing code; three known cells.
options={}
for ctx in itertools.product([0,1],repeat=2):
 for bit in [0,1]:
  traces=defaultdict(list)
  for w,h in itertools.product([0,1],states):
   act=(w,False,h);tape={-2:ctx[0],-1:ctx[1],0:w};pos=-1;q=h;visited=set();seen=set()
   for tick in range(1,81):
    ep=(q,pos,tape[-2],tape[-1],tape[0])
    traces[ep].append((act,frozenset(visited),tick))
    if pos not in tape or ep in seen:break
    seen.add(ep);visited.add(q)
    if(q,tape[pos])not in rows:break
    ww,dd,q=rows[q,tape[pos]];tape[pos]=ww;pos+=1 if dd else -1
  for src,ps in hist2.items():
   if ctx not in ps:continue
   ow,od,on=rows[src,bit];ep=(on,1 if od else -1,*ctx,ow)
   options[src,ctx,bit]=[(rows[src,bit],frozenset(),1)]+traces[ep]
found=[]
for a,z in itertools.combinations(hist2,2):
 if hist2[a]&hist2[z] or {a,z}&c.BOXSTATES:continue
 opts=[]
 for bit in [0,1]:
  common=None
  for src in [a,z]:
   for ctx in hist2[src]:
    oo={act for act,v,ticks in options[src,ctx,bit] if not v&{a,z}}
    common=oo if common is None else common&oo
  opts.append(common)
 if all(opts):found.append((a,z,[list(o) for o in opts]))
print('found',found,flush=True)
Path('work/engine/history2_raw_found.json').write_text(json.dumps(found,indent=2))
