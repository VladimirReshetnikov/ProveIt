from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('work/search').resolve()));import search as s
c=s.c
T=c.read_grammar(Path('work/search/winner_1337_925.json'));seen=set();out=Path('work/engine/zero7');out.mkdir(exist_ok=True)
count=0
for p,x in s.paths(T):
 for y in s.rotations(x):
  for nt in [s.replace(T,x,y),s.local_replace(T,p,y)]:
   if nt in seen:continue
   seen.add(nt)
   if s.attrs(nt)[2]!=7:continue
   rr,idx,sh=c.build(nt);ops=c.opportunities_fast(rr,sh);fo=s.compatible_folds(rr,ops)
   if len(rr)//2-len(fo)>194:continue
   count+=1
   print('TRY',count,p,'states',len(rr)//2-len(fo),flush=True)
   folded,ali=s.v.quotient(rr,fo);ss,cfg,cs=c.source(nt);res=c.validate(folded,cs);print('RESULT',res,flush=True)
   s.save(nt,out/f'candidate{count}.json');(out/f'candidate{count}_folds.json').write_text(json.dumps(fo,indent=2))
   if res['ok']:print('WINNER',count,flush=True);raise SystemExit()
print('DONE',count)
