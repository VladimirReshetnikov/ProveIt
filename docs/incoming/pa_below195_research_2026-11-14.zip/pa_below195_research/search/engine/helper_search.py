from pathlib import Path
import sys,json,itertools,collections,time
P=Path('work/pa195/pa195_conpa/pa195').resolve();sys.path.insert(0,str(P));import build_verify as b
c=b.c
sys.path.insert(0,str(Path('work/search').resolve()));import search as opt
T=c.read_grammar(Path(sys.argv[1]) if len(sys.argv)>1 else P/'grammar.json');raw,idx,shape=c.build(T);H=2900
inc=collections.defaultdict(set)
for(q,bit),(w,d,n)in raw.items():inc[n].add((w,d))
eligible={q:q for q in{q for q,bit in raw}if q!=74 and q not in c.BOXSTATES and inc[q] in [{(0,True)},{(1,True)}]}
baseops=c.opportunities_fast(raw,eligible);states=sorted({q for q,bit in raw});out=Path(sys.argv[2]) if len(sys.argv)>2 else Path('work/engine/helper');out.mkdir(exist_ok=True,parents=True)
# Existing macros expose equal one-branch behaviors, allowing cheap focused helper candidates.
zero=[q for q in eligible if inc[q]=={(0,True)}];one=[q for q in eligible if inc[q]=={(1,True)}]
byrow=[collections.defaultdict(list),collections.defaultdict(list)]
for q in states:
 for bit in [0,1]:byrow[bit][raw[q,bit]].append(q)
providers=[collections.defaultdict(list),collections.defaultdict(list)]
for h in states:
 w0,d0,u0=raw[h,0];w1,d1,u1=raw[h,1]
 if w0 or w1!=1 or not d0 or not d1:continue
 for bit in [0,1]:
  if(u0,bit)in raw and(u1,bit)in raw:providers[bit][raw[u0,bit],raw[u1,bit]].append((h,u0,u1))
helpers=collections.defaultdict(set)
for a,z in itertools.product(zero,one):
 for bit in [0,1]:
  if raw[a,bit]==raw[z,bit]:continue
  other=1-bit
  if raw[a,other]!=raw[z,other] and not any(not {a,z}&set(t) for t in providers[other][raw[a,other],raw[z,other]]):continue
  for u0,u1 in itertools.product(byrow[bit][raw[a,bit]],byrow[bit][raw[z,bit]]):
   if {u0,u1}&{a,z}:continue
   helpers[u0,u1].add((a,z))
print('RAW',len(raw)//2,'baseops',len(baseops),'matching',len(c.max_matching(baseops)),'helpers',len(helpers),'multi',sum(len(x)>1 for x in helpers.values()),flush=True)
start=time.time();best=195;count=0
# A helper enabling >=2 freshedges can save a state beyond its ownallocation.
basepairs={(a,z)for a,z,o in baseops}
for (u0,u1),newpairs in sorted(helpers.items(),key=lambda kv:-len(kv[1])):
 if len(newpairs-basepairs)<2:continue
 count+=1;rr=dict(raw);rr[H,0]=(0,True,u0);rr[H,1]=(1,True,u1)
 ops=c.opportunities_fast(rr,eligible,ignore_incoming={H});bound=len(c.max_matching(ops));score=len(rr)//2-bound
 if score<best:best=score;print('BOUND',count,score,(u0,u1),'ops',len(ops),'newpairs',len(newpairs),'sec',time.time()-start,flush=True)
 if score<=194:
  folds=opt.compatible_folds(rr,ops);cost=len(rr)//2-len(folds);print('EXACT',count,cost,(u0,u1),flush=True)
  if cost<=194:
   folded,aliases=b.quotient(rr,folds)
   try:cert=b.quotient_certificate(raw,folded,folds,aliases)
   except Exception as e:print('INVALID',str(e),flush=True);continue
   ss,ins,cs=c.source(T);res=c.validate(folded,cs);print('RUNTIME',res,flush=True)
   if res['ok']:
    (out/'winner.json').write_text(json.dumps({'helper':[H,u0,u1],'folds':folds,'raw':[[q,bit,*a]for(q,bit),a in raw.items()],'folded':[[q,bit,*a]for(q,bit),a in folded.items()],'local_certificate':cert,'runtime':res},indent=2));print('WINNER',cost,flush=True);break
else:
 print('DONE',count,'bestbound',best,'seconds',time.time()-start,flush=True)
 (out/'receipt.json').write_text(json.dumps({'tested':count,'total_helpers':len(helpers),'bestbound':best,'seconds':time.time()-start},indent=2))
