"""Independent audit of PA194 root winner, preserving source/runtime scope."""
from pathlib import Path
import sys,json,hashlib,collections
P=Path('work/pa195/pa195_conpa/pa195').resolve()
sys.path.insert(0,str(P));import build_verify as ref
c=ref.c
T=Path(sys.argv[1]) if len(sys.argv)>1 else Path('work/search/winner_1337_925.json');F=T.with_name(T.stem+'_folds.json')
t=c.read_grammar(T)
raw,idx,shape=c.build(t)
folds=json.loads(F.read_text())
rows,aliases=ref.quotient(raw,folds)
print('census',len(raw)//2,len(shape),len(folds),len(rows)//2,flush=True)
cert=ref.quotient_certificate(raw,rows,folds,aliases)
print('local',len(cert['local_traces']),cert['durations'],flush=True)
ss,cfg,cs=c.source(t)
oldsites,oldcfg,oldcs=c.source(c.read_grammar(P/'grammar.json'))
assert [x[1:] for x in ss]==[x[1:] for x in oldsites]
assert cfg==oldcfg
assert ref.word(t)==ref.word(c.read_grammar(P/'grammar.json'))
assert cfg==ref.interval_cfg(ss)
print('source cfg',len(ss),len(cs),'identical',flush=True)
check=c.validate(rows,cs)
print('runtime',check,flush=True)
assert check['ok']
# Dense standard presentation, followed by exact known seed.
labels=[74]+sorted({q for q,_ in rows}-{74})+[254];inv={q:i for i,q in enumerate(labels)}
dense={(inv[q],bit):(w,d,inv[n]) for (q,bit),(w,d,n) in rows.items()}
seed=ref.startup(dense,labels)
print('startup',seed['literal_steps'],seed['native_state'],seed['absolute_head'],flush=True)
old,_=c.machine()
assert all(rows[q,bit]==old[q,bit] for q in c.BOXSTATES for bit in [0,1])
reach={74};todo=[74]
for q in todo:
 for bit in [0,1]:
  n=rows[q,bit][2]
  assert n==254 or n in reach or (n,0) in rows
  if n!=254 and n not in reach:reach.add(n);todo.append(n)
assert len(reach)==194
out=Path('work/engine/pa194_audit');out.mkdir(exist_ok=True)
(out/'machine.native.tm').write_bytes(ref.table_bytes(rows))
(out/'machine.tm').write_bytes(ref.table_bytes(dense))
(out/'labels.json').write_text(json.dumps(labels,indent=2)+'\n')
(out/'fold_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
(out/'startup.json').write_text(json.dumps(seed,indent=2)+'\n')
result={'working_states':194,'graph_reachable':len(reach),'raw_states':len(raw)//2,'reader_states':len(shape),'folds':len(folds),'local_cases':len(cert['local_traces']),'durations':cert['durations'],'source_sites':len(ss),'source_cfg_equal_to_PA195':True,'source_words_equal_to_PA195':True,'independent_interval_cfg_equal':True,'runtime':check,'oracle46rows_preserved':True,'startup':seed,'sha256':hashlib.sha256(ref.table_bytes(dense)).hexdigest()}
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
