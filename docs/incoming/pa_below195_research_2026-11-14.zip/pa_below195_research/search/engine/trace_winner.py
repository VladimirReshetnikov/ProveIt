exec(open('work/engine/search_runtime.py').read().split("print('fixed'")[0])
t=c.read_grammar(Path('work/search/winner_1337_925.json'));raw,idx,shape=c.build(t)
ss,cfg,cs=c.source(t);cc=next(x for x in cs if x[0]==131 and x[1][1]);trace=[]
v=c.run(raw,cc,observe=lambda s:trace.append(s));print('raw',v,'site',ss[131],'cfg',cfg[131],'target',cc[3]);print('last',json.dumps(trace[-20:],indent=1))
# Identify leaf-level macro enclosing index131 path.
nodes=c.raw_nodes();sites=[]
def walk(t,p,names):
 if isinstance(t,str):
  if t=='x67':return walk(ax,p,names+[(t,p)])
  return walk(nodes[t],p,names+[(t,p)])
 if t[0]=='leaf':sites.append((p,names));return
 walk(t[0],p+(0,),names);walk(t[1],p+(1,),names)
ax=t;walk('node172',(),[])
print('macro ancestors',sites[131])
