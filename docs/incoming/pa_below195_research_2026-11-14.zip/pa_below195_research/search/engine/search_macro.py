exec(open('work/engine/search_runtime.py').read().split("print('fixed'")[0])
from collections import defaultdict
fixed={q:next(iter(x)) for q,x in hist.items() if len(x)==1 and q!=74}
options={}
for side in [-1,1]:
 for p in [0,1]:
  for bit in [0,1]:
   key=side,p,bit
   traces=defaultdict(list)
   for w,h in itertools.product([0,1],incoming):
    act=(w,side==1,h)
    tape={side:p,0:w};pos=side;q=h;states=set();seen=set()
    for tick in range(1,65):
     endpoint=(q,pos,tape[side],tape[0])
     traces[endpoint].append((act,frozenset(states),tick))
     if pos not in tape or endpoint in seen:break
     seen.add(endpoint);states.add(q)
     if (q,tape[pos]) not in rows:break
     ww,dd,qq=rows[q,tape[pos]]
     tape[pos]=ww;pos+=1 if dd else -1;q=qq
   for src,(hp,hd) in fixed.items():
    if hp!=p or (1 if hd else -1)!=-side:continue
    ow,od,on=rows[src,bit];ep=(on,1 if od else -1,p,ow)
    options[src,bit]=[(rows[src,bit],frozenset(),1)]+traces[ep]
found=[]
for a,z in itertools.combinations(fixed,2):
 pa,da=fixed[a];pb,db=fixed[z]
 if pa==pb or da!=db or {a,z}&c.BOXSTATES:continue
 opts=[]
 for bit in [0,1]:
  left={act:(states,ticks) for act,states,ticks in options[a,bit] if not states&{a,z}}
  right={act:(states,ticks) for act,states,ticks in options[z,bit] if not states&{a,z}}
  opts.append(set(left)&set(right))
 if all(opts):found.append((a,z,[list(o) for o in opts]))
print('found',found)
Path('work/engine/macro_found.json').write_text(json.dumps(found,indent=2))
