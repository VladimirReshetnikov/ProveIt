exec(open('work/engine/search_runtime.py').read().split("print('fixed'")[0])
from collections import defaultdict
T=c.read_grammar(P/'grammar.json');sites,cfg,cs=c.source(T)
used=defaultdict(set)
def obs(s):
 q,onl,l,r=s
 if onl:
  if l and l[0][0]=='r':
   x=l[0];act=rows.get((q,x[1]))
   if act is not None and not act[1] and act[2]==q:used[q].add(x[1])
 else:
  if r:
   x=r[0]
   if x[0] in ['b','r']:used[q].add(x[1])
   elif x[0]=='x' and c.oracle(q,None,x) is None and rows.get((q,0),[None])[0]==0:used[q].add(0)
print(c.validate(rows,cs,observe=obs),flush=True)
q=74;head=0;ones=set()
for _ in range(58154):
 bit=int(head in ones);used[q].add(bit);w,d,q=rows[q,bit];(ones.add if w else ones.discard)(head);head+=1 if d else -1
for q in c.BOXSTATES:used[q]={0,1}
print('partial',[(q,sorted(used[q]),rows[q,0],rows[q,1]) for q,_ in rows if _==0 and len(used[q])<2],flush=True)
ops=[]
for a,z in itertools.combinations(incoming,2):
 if 74 in [a,z] or {a,z}&c.BOXSTATES:continue
 def alias(x):return z if x==a else x
 def row(q,bit):
  w,d,n=rows[q,bit];return w,d,alias(n)
 if any(row(a,bit)!=row(z,bit) for bit in used[a]&used[z]):continue
 acts=[row(a,bit) if bit in used[a] else row(z,bit) for bit in [0,1]]
 ops.append([a,z,acts])
print('ops',ops,flush=True)
Path('work/engine/context_ops.json').write_text(json.dumps(ops,indent=2))
