#!/usr/bin/env python3
"""Portable entry point for two packaged search families (Python 3.10+).

Examples, run from any working directory:

  python3 /path/to/reproduce_searches.py --family coupled --tables baseline
  python3 /path/to/reproduce_searches.py --family coupled --tables all61
  python3 /path/to/reproduce_searches.py --family coupled --tables both --dry-run
  python3 /path/to/reproduce_searches.py --family grammar --seed 1337 --iterations 10000
  python3 /path/to/reproduce_searches.py --family grammar --historical-budgets
  python3 /path/to/reproduce_searches.py --family grammar --iterations 0

The last command is a staging/import smoke check. Coupled searches additionally
require a GNU-compatible C++17 compiler, normally g++ (override with --cxx).

The five recorded grammar budgets are 1337/600000, 2026/600000, 901/600000,
314159/400000, and 714/500000. --historical-budgets applies those seeds and
budgets to the FINAL packaged search.py. Earlier runs used evolving search
versions, including different screens, so historical logs need not reproduce
byte-for-byte. Timings and environment-dependent details also vary. Fixed
input tables and fixed certificate/witness checks are deterministic; this
runner verifies the recorded hashes of the coupled input tables.

The grammar searcher's label VERIFIED_WINNER means local quotient acceptance.
It is not, by itself, a complete interpreter or Con(PA) equivalence proof.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
HISTORICAL_BUDGETS = (
    (1337, 600000),
    (2026, 600000),
    (901, 600000),
    (314159, 400000),
    (714, 500000),
)
REPRODUCIBILITY_NOTE = (
    "Grammar reruns use the final packaged search.py, not every earlier evolving "
    "version. Historical logs need not reproduce byte-for-byte; timings and "
    "environment-dependent details vary. Fixed input tables and fixed witness "
    "checks are deterministic. Grammar VERIFIED_WINNER denotes a local quotient "
    "candidate, not a complete runtime or Con(PA) equivalence theorem."
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def required_file(path: Path) -> Path:
    if not path.is_file():
        raise FileNotFoundError(f"Required packaged file is missing: {path}")
    return path


def coupled_inputs(selection: str) -> list[dict]:
    directory = ROOT / "search/engine/coupled_inputs"
    chosen = []
    if selection in ("baseline", "both"):
        baseline = required_file(directory / "baseline_pa195.native.tm")
        receipt = json.loads(
            required_file(ROOT / "search/engine/ENGINE_RECEIPT.json").read_text()
        )
        chosen.append(
            {
                "name": "baseline_pa195",
                "path": baseline,
                "sha256": receipt["baseline_native_sha256"],
            }
        )
    if selection in ("all61", "both"):
        manifest = json.loads(required_file(directory / "manifest.json").read_text())
        if len(manifest) != 61:
            raise ValueError(f"Expected 61 recorded reparse tables; found {len(manifest)}")
        for item in manifest:
            # The frozen archive names these native-label tables parent_NNN.tm.
            # Use the manifest, rather than assuming a *.native.tm filename glob.
            filename = item["table"]
            if Path(filename).name != filename:
                raise ValueError(f"Unexpected nonlocal table name in manifest: {filename}")
            path = required_file(directory / filename)
            chosen.append(
                {"name": path.stem, "path": path, "sha256": item["table_sha256"]}
            )
    if len({item["name"] for item in chosen}) != len(chosen):
        raise ValueError("Duplicate selected table names")
    for item in chosen:
        if sha256(item["path"]) != item["sha256"]:
            raise ValueError(f"Recorded SHA-256 does not match {item['path']}")
    return chosen


def stage_grammar(parent: Path) -> Path:
    """Restore the relative layout expected by the unmodified final searcher."""
    reference = ROOT / "reference/pa195"
    for name in ("build_verify.py", "grammar.json", "vendor/compiler.py"):
        required_file(reference / name)
    source = required_file(ROOT / "search/search/search.py")
    destination = parent / "work/pa195/pa195_conpa/pa195"
    shutil.copytree(
        reference, destination, ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
    )
    search = parent / "work/search/search.py"
    search.parent.mkdir(parents=True)
    shutil.copy2(source, search)
    return search


def run_logged(command: list[str], cwd: Path, log: Path) -> int:
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONHASHSEED"] = "0"
    with log.open("w", encoding="utf-8") as stream:
        result = subprocess.run(
            command,
            cwd=cwd,
            env=environment,
            stdout=stream,
            stderr=subprocess.STDOUT,
            check=False,
        )
    return result.returncode


def write_summary(directory: Path, summary: dict) -> None:
    (directory / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def run_coupled(args: argparse.Namespace, output: Path | None) -> int:
    source = required_file(ROOT / "search/engine/coupled_history5.cpp")
    inputs = coupled_inputs(args.tables)
    compiler = shutil.which(args.cxx)
    if compiler is None:
        raise FileNotFoundError(
            f"C++ compiler {args.cxx!r} was not found; install g++ or supply --cxx PATH"
        )
    with tempfile.TemporaryDirectory(prefix="pa195-coupled-") as temporary:
        stage = Path(temporary)
        executable = stage / ("coupled_history5.exe" if os.name == "nt" else "coupled_history5")
        build = [compiler, "-O3", "-std=c++17", str(source), "-o", str(executable)]
        if args.dry_run:
            print(f"Validated {len(inputs)} recorded table hashes.")
            print("Compile command:", shlex.join(build))
            print("Selected tables:", ", ".join(item["name"] for item in inputs))
            print("No compiler or search was run.")
            return 0
        assert output is not None
        summary = {
            "family": "coupled",
            "selection": args.tables,
            "source_sha256": sha256(source),
            "reproducibility": REPRODUCIBILITY_NOTE,
            "status": "running",
            "results": [],
        }
        write_summary(output, summary)
        build_log = output / "compiler.log"
        if run_logged(build, stage, build_log):
            summary["status"] = "compiler_failed"
            write_summary(output, summary)
            print(f"Compilation failed; see {build_log}", file=sys.stderr)
            return 1
        for index, item in enumerate(inputs, 1):
            name = item["name"]
            log = output / f"{name}.log"
            candidate = output / f"{name}_candidate.tm"
            command = [str(executable), str(item["path"]), str(candidate)]
            code = run_logged(command, stage, log)
            text = log.read_text(encoding="utf-8", errors="replace")
            found = re.search(r"^FOUND .+$", text, flags=re.MULTILINE)
            done = re.search(
                r"^DONE pairs (\d+) partials (\d+) seconds ([\d.eE+-]+)$",
                text,
                flags=re.MULTILINE,
            )
            result = {
                "table": item["path"].name,
                "table_sha256": item["sha256"],
                "returncode": code,
                "log": log.name,
            }
            if code or (found is None and done is None):
                result["status"] = "failed"
                summary["results"].append(result)
                summary["status"] = "failed"
                write_summary(output, summary)
                print(f"Search failed or returned unrecognized output; see {log}", file=sys.stderr)
                return code or 1
            if found is not None:
                result.update(status="local_fold_found", witness=found.group(0))
                result["candidate_table"] = candidate.name
            else:
                assert done is not None
                result.update(
                    status="no_local_fold",
                    pairs=int(done.group(1)),
                    partial_survivors=int(done.group(2)),
                    seconds=float(done.group(3)),
                )
            summary["results"].append(result)
            write_summary(output, summary)
            print(f"[{index}/{len(inputs)}] {name}: {result['status']}", flush=True)
        summary["status"] = "complete"
        write_summary(output, summary)
    print(f"Results: {output}")
    return 0


def run_grammar(args: argparse.Namespace, output: Path | None) -> int:
    runs = (
        list(HISTORICAL_BUDGETS)
        if args.historical_budgets
        else [(args.seed if args.seed is not None else 1337,
               args.iterations if args.iterations is not None else 10000)]
    )
    source = required_file(ROOT / "search/search/search.py")
    summary = {
        "family": "grammar",
        "source_sha256": sha256(source),
        "python_version": sys.version,
        "python_hash_seed": 0,
        "reproducibility": REPRODUCIBILITY_NOTE,
        "status": "running",
        "results": [],
    }
    print(REPRODUCIBILITY_NOTE, flush=True)
    if output is not None:
        write_summary(output, summary)
    for seed, iterations in runs:
        with tempfile.TemporaryDirectory(prefix="pa195-grammar-") as temporary:
            stage = Path(temporary)
            search = stage_grammar(stage)
            command = [sys.executable, "-u", str(search), str(seed), str(iterations)]
            if args.dry_run:
                print("Staged expected work/{pa195/pa195_conpa/pa195,search/search.py} layout.")
                print("Search command:", shlex.join(command))
                continue
            assert output is not None
            run_dir = output / f"seed_{seed}_iterations_{iterations}"
            run_dir.mkdir()
            log = run_dir / "search.log"
            print(f"Running final grammar search: seed={seed}, iterations={iterations}", flush=True)
            code = run_logged(command, stage, log)
            generated = []
            for path in sorted(search.parent.iterdir()):
                if path.is_file() and path.name != "search.py":
                    target = run_dir / path.name
                    shutil.copy2(path, target)
                    generated.append(target.name)
            text = log.read_text(encoding="utf-8", errors="replace")
            result = {
                "seed": seed,
                "proposed_iterations": iterations,
                "returncode": code,
                "status": "complete" if code == 0 else "failed",
                "log": str(log.relative_to(output)),
                "generated_files": generated,
                "local_candidate_messages": re.findall(
                    r"^VERIFIED_WINNER .+$", text, flags=re.MULTILINE
                ),
            }
            summary["results"].append(result)
            summary["status"] = "failed" if code else "running"
            write_summary(output, summary)
            if code:
                print(f"Grammar search failed; see {log}", file=sys.stderr)
                return code
            print(f"Completed seed {seed}; log: {log}", flush=True)
    if args.dry_run:
        print("No grammar search was run; temporary staging was removed.")
    else:
        assert output is not None
        summary["status"] = "complete"
        write_summary(output, summary)
        print(f"Results: {output}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--family", choices=("coupled", "grammar"), required=True)
    parser.add_argument("--output-dir", type=Path, help="new or empty results directory")
    parser.add_argument(
        "--dry-run", action="store_true",
        help="validate inputs and grammar staging, print commands, and run no search/compiler",
    )
    coupled = parser.add_argument_group("coupled synthesis")
    coupled.add_argument(
        "--tables", choices=("baseline", "all61", "both"), default="baseline",
        help="baseline, the 61 recorded reparse tables, or all 62 (default: baseline)",
    )
    coupled.add_argument("--cxx", default="g++", help="GNU-compatible C++17 compiler (default: g++)")
    grammar = parser.add_argument_group("grammar search")
    grammar.add_argument("--seed", type=int, help="random seed (default: 1337)")
    grammar.add_argument(
        "--iterations", type=int,
        help="proposed iteration budget; 0 performs a staging/import smoke check (default: 10000)",
    )
    grammar.add_argument(
        "--historical-budgets", action="store_true",
        help="run all five recorded seeds/budgets using the final script, totaling 2,700,000 proposals",
    )
    args = parser.parse_args()
    if args.iterations is not None and args.iterations < 0:
        parser.error("--iterations must be nonnegative")
    if args.historical_budgets and (args.seed is not None or args.iterations is not None):
        parser.error("--historical-budgets cannot be combined with --seed or --iterations")
    if sys.version_info < (3, 10):
        parser.error("Python 3.10 or newer is required by the packaged grammar search")
    output = None
    if not args.dry_run:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        output = (
            args.output_dir if args.output_dir is not None
            else Path.cwd() / "reproduced_searches" / f"{args.family}_{stamp}"
        ).expanduser().resolve()
        if output.exists() and (not output.is_dir() or any(output.iterdir())):
            parser.error(f"Results directory must be new or empty: {output}")
        output.mkdir(parents=True, exist_ok=True)
    try:
        return run_coupled(args, output) if args.family == "coupled" else run_grammar(args, output)
    except (OSError, ValueError, KeyError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
