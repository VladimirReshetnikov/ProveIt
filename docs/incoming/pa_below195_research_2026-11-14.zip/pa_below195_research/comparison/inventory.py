#!/usr/bin/env python3
from pathlib import Path
from collections import deque,Counter
import json,hashlib,zipfile,io,re
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]/'sources/ProveIt'
OLD=json.loads((HERE/'pa195_conpa/comparison/archive_inventory.json').read_text())
known={x['archive']:x for x in OLD}
archives=[];tables=[]

def sha(d):return hashlib.sha256(d).hexdigest()
def parse(d):
 try:s=d.decode();rows={};start=None
 except UnicodeDecodeError:return
 for line in s.splitlines():
  line=line.strip()
  if not line:continue
  if line.startswith('#'):
   m=re.search(r'\bstart\s+(\d+)\b',line)
   if m:start=int(m[1])
   continue
  p=line.split()
  if len(p)!=5 or p[3]not in('L','R')or any(not p[i].isdigit()for i in(0,1,2,4)):return
  q,b,w,n=map(int,(p[0],p[1],p[2],p[4]))
  if b not in(0,1)or w not in(0,1)or(q,b)in rows:return
  rows[q,b]=(w,p[3],n)
 qs={q for q,b in rows}
 if not qs or set(rows)!={(q,b)for q in qs for b in(0,1)}:return
 hs={n for w,d,n in rows.values()}-qs
 if len(hs)!=1:return
 if start is None and qs==set(range(len(qs))):start=0
 return rows,start,hs.pop()

def canon(rows,start,halt):
 if start is None:return None
 ids={start:0};queue=[start];out=[]
 for q in queue:
  for b in(0,1):
   w,d,n=rows[q,b]
   if n==halt:n=-1
   else:
    if n not in ids:ids[n]=len(ids);queue.append(n)
    n=ids[n]
   out.append([ids[q],b,w,d,n])
 return sha(json.dumps(out,separators=(',',':')).encode()),len(ids)

def visit(z,prefix,depth):
 for f in z.infolist():
  if f.is_dir():continue
  if f.filename.lower().endswith(('.tm','.txt')):
   d=z.read(f);p=parse(d)
   if p:
    rows,start,halt=p;c=canon(*p)
    tables.append({'member':prefix+'!'+f.filename,'bytes':len(d),'sha256':sha(d),'states':len(rows)//2,'start':start,'halt':halt,'rooted_hash':c[0]if c else None,'reachable':c[1]if c else None})
  if depth<2 and f.filename.lower().endswith('.zip'):
   try:visit(zipfile.ZipFile(io.BytesIO(z.read(f))),prefix+'!'+f.filename,depth+1)
   except zipfile.BadZipFile:pass
for f in sorted((REPO/'docs/incoming').glob('*.zip')):
 d=f.read_bytes();z=zipfile.ZipFile(io.BytesIO(d));h=sha(d)
 rec={'archive':f.name,'bytes':len(d),'sha256':h,'outer_file_members':sum(not x.is_dir()for x in z.infolist()),'present_in_pa195_audit':f.name in known}
 if f.name in known:
  assert h==known[f.name]['sha256'],f.name
  rec['unchanged_since_pa195_audit']=True
 archives.append(rec);visit(z,f.name,0)
sel=[]
for f in sorted((HERE/'pa195_conpa/comparison/prior196').glob('*.tm')):
 p=parse(f.read_bytes());c=canon(*p);assert len(p[0])==392 and c[1]==196
 sel.append({'name':f.stem,'path':str(f.relative_to(HERE)),'states':196,'sha256':sha(f.read_bytes()),'rooted_hash':c[0],'status':'prior_audit_supported_196'})
for group,base,dirs in[
 ('cross',HERE/'new/pa_consistency_cross_archive/pa_consistency_cross_archive/machines',['diagonal_combined','separate_combined','diagonal_combined_zerojump','separate_combined_zerojump']),
 ('mp_h',HERE/'new/pa_consistency_reduction_audit_2026-11-14/pa_consistency_reduction_audit/reduction_agent/combination_study/results',['diagonal_mp_h','separate_mp_h']),
]:
 for n in dirs:
  f=base/n/'machine.tm';p=parse(f.read_bytes());c=canon(*p);assert len(p[0])==392 and c[1]==196
  sel.append({'name':n,'path':str(f.relative_to(HERE)),'states':196,'sha256':sha(f.read_bytes()),'rooted_hash':c[0],'status':'additional_reported_complete_physical_contracts'})
f=HERE/'pa195_conpa/pa195/pa195.tm';p=parse(f.read_bytes());c=canon(*p)
sel.append({'name':'pa195','path':str(f.relative_to(HERE)),'states':195,'sha256':sha(f.read_bytes()),'rooted_hash':c[0],'status':'supplied_195_baseline'})
assert len({x['rooted_hash']for x in sel})==len(sel)
summary={'repository_revision':'5be8b9236df6a6d308195e62a906a173dc70d00a','archive_count':len(archives),'archive_bytes':sum(x['bytes']for x in archives),'unchanged_archives_from_pa195_audit':len(known),'new_archives':[x['archive']for x in archives if not x['present_in_pa195_audit']],'recognition':'Complete numeric five-column binary .tm or .txt members, nested ZIP depth at most 2; starts inferred only for dense 0..N-1 tables or explicit directive. Counts include duplicates/ancestors/rejected controls.','table_occurrences':len(tables),'literal_bytestrings':len({x['sha256']for x in tables}),'selected196_count':sum(x['states']==196 for x in sel),'selected196_graph_classes':len({x['rooted_hash']for x in sel if x['states']==196}),'pa195_sha256':sha(f.read_bytes())}
for name,obj in [('current_archives.json',archives),('current_table_inventory.json',tables),('selected_designs.json',sel),('comparison_summary.json',summary)]:
 (HERE/name).write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps(summary,indent=2))
