# PA design comparison at the pinned source snapshot

Source revision: `5be8b9236df6a6d308195e62a906a173dc70d00a` (ProveIt).
This comparison uses the exact repository contents, not the mutable branch name.
The current incoming directory contains 31 ZIPs, totaling 233,712,151 bytes.
All 27 input ZIPs indexed by the supplied PA195 archive retain exactly the
SHA-256 digests in that archive's prior inventory. Four ZIPs were subsequently
added: PA195 itself, the cross-archive composition packet, the 14-November
reduction audit, and the 14-November NEG18 packet. The dates here are the
artifacts' own names; the report's date is 14 November 2026.

## Independently recomputed structural comparison

`inventory.py` recursively examines ZIP members to depth two and recognizes
complete numeric five-column binary tables in `.tm` and `.txt` files. It finds
2,127 such occurrences representing 565 literal byte strings. These figures
are diagnostic inventory counts, not counts of valid consistency machines.
They include duplicates, ancestors, rejected trials and small test controls.
Different earlier inventories used different recognized extensions and nested
ZIP conventions, so their raw totals should not be compared as theorem counts.

The PA195 packet identifies 25 supported prior 196-state designs. Here all 25
original archive members were re-read, their exact hashes checked, and every
row of their supplied dense relabeling checked against the original table.
Start and halt labels are preserved. This is recorded in
`prior196_binding_check.json`. The new cross-archive packet contributes four
additional 196-state tables; the new reduction audit contributes two 196-state
MP-in-H tables. The 31 selected tables all have 392 rows, all 196 working
states graph reachable, and pairwise different rooted, read-symbol/action-
preserving transition graphs. Those structural checks do not certify their
arithmetic calibration. Their complete symbolic-runtime support is an inherited
reported result, except wherever the main investigation explicitly replays it.

The one supplied 195-state table has SHA-256
`5c6afd87f7c4f24d9ad8e9e302cc21df14b6f2e3715d03322a75463a431d8455`.
It is distinct from these 31 tables and is the benchmark for the strict target.

## Main design families

| Family | Working states | Source sites | Distinct contribution | Evidence qualification |
|---|---:|---:|---|---|
| James Chang PA209 | 209 | 3,948 | Direct predecessor to the published PA196 construction | Imported Lean project; stated internal endpoint is Nonhalt -> Con(PA) |
| U208 family | 208 | 3,909 in the calibrated source family | History-sensitive fold of a distinct U209 parent; twenty designated nonisomorphic helper variants | Local halting-preservation proof and source/calculus calibration; no new full kernel endpoint in packets |
| Published PA196 | 196 | 3,812 | Transposed quantifier pairing, removal of equality head rho7, guarded equality vacuity, six contextual reader folds | Imported Lean physical/calculus development and internal Nonhalt -> Con(PA) |
| Head-order / reassociation / scanner / register-swap PA196 variants | 196 | Usually 3,812 | Improve reader sharing, path depth, address geometry or register routing | Full symbolic contracts and exact startup reported for designated supported tables |
| H-only Shift | 196 | 3,811 | Accept using h=1, with proof-completion padding | Command/proof compilation changes are required |
| Combined196 | 196 | 3,788 | H-only Shift and MP result held in h | 4,928 symbolic contracts; startup 57,922 |
| Diagonal196 | 196 | 3,700 | Replace general equality-vacuity construction by formula-code diagonal vacuity; 191 AX items | Nine pushed entries; numerical-calculus calibration changes |
| Separate196 | 196 | 3,673 | Remove one `cons` item from the diagonal emitter; 190 AX items | Ten pushed entries, requiring a changed proof-command compiler |
| Zerojump and closing-register variants | 196 | Usually 3,812 or 3,700 | Exploit source invariants to change one physical continuation | Invariant-specialized symbolic contracts; not unrestricted row equality |
| Cross diagonal + Combined | 196 | 3,676 | Compose diagonal calculus with both command changes | 4,784 runtime cases; startup 57,922 |
| Cross separate + Combined | 196 | 3,649 | Compose separate calculus with both command changes | 4,749 runtime cases; startup 57,922 |
| Cross versions plus Zerojump | 196 | 3,676 / 3,649 | Add source-zero conditional routing to the preceding compositions | 4,785 / 4,750 cases; startup 58,168 |
| Diagonal / separate MP-in-H | 196 | 3,677 / 3,650 | MP change without H-only Shift | 4,785 / 4,750 cases; startup 58,154; audit does not certify a new PA endpoint |
| NEG18 separate emitter | 197 | 3,441 | Two increments of scratch register 7 followed by inherited node64; eight shorter negations | Uniform arithmetic macro proof, inductive scratch-zero certificate, 4,468 runtime cases, startup 58,154 |
| Supplied PA195 | 195 | 3,700 | Same diagonal 191-item emitter, 68-reader grammar, seven compatible contextual folds | 4,815 contracts, startup 58,154; ordinary PA-internalization proof, no new Lean/Rocq kernel theorem |

The published PA196 control allocation is 36 engine controls + 13 leaf routers
+ 147 readers. Its six folds are already reflected in the count 196. PA195
keeps 134 controls outside the new AX reader block, adds 68 raw AX controls,
and identifies seven compatible pairs: 134 + 68 - 7 = 195. Source occurrences,
distinct source-DAG nodes, grammar rules and physical states measure different
objects. A reduction in any one of the first three need not reduce the last.

## Important failures and nonadditivity

The original U208 reduction folds native controls 211 and 172 using incoming
history. Both controls are already absent from the PA196 native table, and the
literal mixed-entry motif does not occur there. Its one-state saving cannot be
subtracted a second time.

The prior 27-archive audit records six distinct diagnostic 195-state proposals,
with 14 file occurrences and eight literal byte strings. Their failures include
wrong source successors, a missing decoder helper, failed uniform contracts,
and a source-frame loop. These do not refute all possible 195-state machines.
Two rejected 196-state Shift layouts are stronger negative controls: they halt
on blank tape at step 43,563. Their finite halts are checked in the repository.

A direct substitution of the small ConciseIPRA checker does not provide the
same target. The relevant PA calibration uses finite bit comprehension for an
arbitrary arithmetic formula, supplied as a PA induction instance. A changed
underlying calculus needs explicit PA-verifiable refutation translations in
both directions.

The imported PA196 declaration proves only the internal implication
Nonhalt -> Con(PA); the external standard-model soundness proof alone does not
supply the internal converse. The supplied PA195 report goes further with an
ordinary proof based on primitive-recursive proof suppliers, a parallel
proof-store invariant, exact positive macro contracts and finite deterministic
trace comparison. This distinction between a written mathematical proof and
a newly kernel-checked theorem should be retained in any descendant report.

## Fresh combination experiments

`../search/combine/screen_results.json` records direct recombination of the PA195
reader grammar with MP-in-H and NEG20/NEG18. MP-in-H alone keeps seven folds
and 195 states. Either uniform short-negation substitution loses one fold and
uses 196 states, with or without MP-in-H. Thus the source shortening is not an
additive physical saving.

`../search/combine/mixed_negations.json` exhausts all 3^8 = 6,561 choices among
original, NEG20 and NEG18 at the eight negation occurrences of the fixed
PA195 grammar. The unchanged source is the only assignment with physical
lower bound 195; two all-short configurations have lower bound 196. No
assignment reaches the requested bound 194. This negative result concerns
only that fixed grammar and that fold template.

Deleting the single `node65` token at position 184 (zero based) of the PA195
AX word produces exactly the existing separate190 word. Pruning that leaf
from the PA195 syntax tree retains 68 readers and seven locally compatible
folds: a 195-state separate-calculus seed. Its grammar is
`../search/combine/separate_pruned/grammar.json`. At the time of this note it is a
structural search seed, not a separately verified consistency machine.

## Files and reproducibility

- `current_archives.json`: exact hashes and sizes of all 31 current archives.
- `current_table_inventory.json`: recognized table occurrences and literal hashes.
- `selected_designs.json`: 31 selected 196-state tables plus supplied PA195,
  including independently computed rooted canonical graph hashes.
- `prior196_binding_check.json`: every-row conjugacy checks of all 25 prior
  selected normalized tables against their original archive members.
- `comparison_summary.json`: compact current census and scope.
- `original_pa195_audit/archive_notes.txt`: inherited detailed comparison of
  each of the 27 unchanged earlier archives.

All search failures here are bounded-family failures. None is a lower bound
on the size of a binary Turing machine with the required PA equivalence.

The normalized selected tables are included under `tables/`; each entry in
`selected_designs.json` records its delivered `packaged_path`. The root
`verify.py` recomputes their literal hashes, complete graph reachability, and
rooted canonical graph hashes. Re-running the full `inventory.py` additionally
requires the original 31 ZIP archives and its original research layout; those
233 MB of upstream archive inputs are identified by hash but are not duplicated
in this deliverable.
