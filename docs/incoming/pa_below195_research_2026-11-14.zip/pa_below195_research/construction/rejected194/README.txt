REJECTED PROOF CANDIDATE: NOT A CERTIFIED CONSISTENCY MACHINE

This 194-state table passes its local quotient but fails the intended
source-to-physical refinement at source site 131, zero branch.
The exact 103-step instruction-frame counterexample is in
verification/rejected194_concrete_frame.json at the archive root.
A failed refinement does not itself decide this table's arithmetic
halting equivalence. No such equivalence is claimed here.
