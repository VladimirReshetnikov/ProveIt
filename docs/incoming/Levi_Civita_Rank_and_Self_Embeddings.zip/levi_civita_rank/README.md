# Rational Rank and Self-Embeddings of Levi-Civita Fields

**A sharp co-Hopfian dichotomy, proper immediate self-copies, and integer-part obstructions**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 4 October 2026.

## Main theorem and exact hypotheses

Let k be the field of real algebraic numbers and let Gamma be a nonzero
Q-vector subspace of the ordinary real numbers. Let L_Gamma be the field of
formal series over k whose supports have finite intersection with every
left half-line. Then every unital field self-embedding of L_Gamma is
surjective if and only if Gamma has finite dimension over Q.

No measurability, continuity, coefficient-fixing, or valuation-preserving
hypothesis is imposed on the field embedding. Coefficient fixing and a
positive scalar action on the natural valuation are proved. The topology
is Polish exactly when Gamma is countable. This is a left-finite series
field with algebraic real coefficients, not the full Hahn field or the
usual field with all real coefficients.

The infinite-rank case supplies proper isometric self-embeddings with
closed immediate elementary images. Further results include continuum
many such self-copies in the countable case, an exact unattained distance
to an image, a scalar classification of embeddings between different
exponent groups, and an integer-part criterion for surjectivity.

Section 10 gives an explicit counterexample to the one-sided summability
criterion in Lemma 4.2.4 of arXiv:2107.03362v3, with a corrected substitution
monoid formulation. This is a version-specific statement; the final
journal text has not been independently audited.

## Contents

- `article.pdf`: 20-page typeset manuscript, including 12 proposed research questions.
- `article.tex`: complete LaTeX source, with an embedded bibliography.
- `code/check_identities.py`: reproducible standard-library exact-arithmetic checks.
- `audit/checks.json`: output of the recorded successful run, 2,931 finite checks.
- `audit/sources.json`: source versions, repository revision, and provenance.
- `audit/proof-audit.md`: mathematical dependencies, essential hypotheses, and limitations.
- `audit/build-summary.json`: build and PDF inspection information.
- `Makefile`: PDF and exact-check targets.
- `SHA256SUMS`: checksums of the delivered files other than the checksum file itself.

## Build

A normal TeX Live installation with pdfLaTeX, latexmk, NewTX, amsmath,
amsthm, mathtools, microtype, tcolorbox, xurl, hyperref, cleveref, fancyhdr,
titlesec, booktabs, tabularx, array, and enumitem is sufficient.
No external figures or bibliography database are required.

```sh
make pdf
make check
```

Without make:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build article.tex
cp build/article.pdf article.pdf
python3 code/check_identities.py > audit/checks.json
```

Python 3.9 or later is required; no third-party Python packages are needed.
The checks take roughly tens of seconds, depending on the machine. Output
is deterministic and uses exact `fractions.Fraction` arithmetic.

## Status and limits

This is an AI-assisted, unrefereed mathematical manuscript. Proofs are
supplied for the stated contributions, but independent mathematical review
and historical priority remain outstanding. No Lean or Rocq verification
of the new results is claimed, and the ProveIt repository was not rebuilt.
The exact finite checks do not prove completeness, real closedness,
independence of the selected real exponents, or the infinite-rank
non-surjectivity theorem. Those assertions depend on the written proofs
and identified classical inputs.

No newly resolved printed question of Glazer, no theorem about arbitrary
real coefficient fields, no automatic extension to a full Hahn field, and
no proper-class self-embedding of all surreal numbers is claimed.

The package contains no redistributed source papers or standalone font files.
