A ONE-SCHEMA ROUTE TO Con(ZFC)
Research report on the ProveIt project, 16 October 2026

READ FIRST

article.pdf is the complete report. article.tex and sections/*.tex are its
complete editable source. The bibliography is included as LaTeX source.

The mathematical proposal is the equality-free, subset-seeded positive closure
schema (PSC) alone. The report proves an interpretation of extensional PSC on
a definable hereditary saturated domain, calibrates it to foundation-free ZF,
and explains why ZFC proves Con(PSC) iff Con(ZFC). These are ordinary
mathematical proofs, not a newly exported Lean/Coq proof object.

The concrete compiler experiment preserves the EXISTING recovered program,
not the newly proposed PSC theory. It improves the same public backend's
281-state output to 269 working states. It does not beat 254. A complete finite
register-operation certificate is independently checked. The binary compiler's
unbounded-tape simulation is a separate obligation and is not newly proved here.

FILES

  article.pdf, article.tex, sections/
      Full report, proof, implementation proposal, review of sources, and plan.

  reproduce.py
      One-command reproduction using Python 3.10+ and its standard library.
      No network, source checkout, proof assistant, or external package needed.

  machine/rebracket_axioms.py
      Rebuilds the axiom-word grammar and compiles the 207-node decision graph.
  machine/verify_rm_certificate.py
      Independent finite verifier; does not import the generator or backend.
  machine/inputs/source_dag.json
      Exact numeric extraction of the published 219-node source program.
  machine/inputs/backend/
      Pinned Wade backend, copied unchanged with its original MIT-0 license.
  machine/results/rebracketed_wade_total.tm
      Literal binary table: states 0..268, start 0, terminal label 269,
      all-zero tape, 538 transitions. Five fields per row:
      current_state read_symbol write_symbol direction target_state.
  machine/results/rebracketed_wade.tm
      Named, partial-transition version; 537 rows and one implicit halt.
  machine/results/rebracketed_dag.json
      Candidate 207-node source program.
  machine/results/rm_bisimulation.json
      All 4,533 related exposed-operation pairs, including both decrement exits.
  machine/results/state_names.json
      Exact table-state renaming, with the terminal label recorded separately.
  machine/results/rebracketing_evidence.json
      Counts, hashes, grammar parameters, and verification boundaries.
  machine/README.md
      Detailed independent reproduction and provenance.

  proof_checker/
      Complete binary certificate specification, iterative reference checker,
      12 tests, recorded validation, source provenance, and identity.cert.
      identity.cert proves Mem(0,1) -> Mem(0,1); it is NOT a refutation.
      Only a valid derivation ending in literal Bottom is a refutation.
      See this directory's README.md for the exact grammar and CLI.

  code/finite_saturation.py
      Exhausts 530 small membership graphs to check relational definitions and
      necessary constant-PSC consequences. Not a consistency test.
  data/finite_saturation_results.json
      Stable results of that relational audit.
  data/formula_metrics.json
      Compact extraction of the pinned template metric: CG+PSC 71 nodes,
      PSC alone 52 in the same Bottom/Imp/All basis. These are NOT TM states.
  data/provenance.json
      Exact requested commits, their metadata, and changed-file inventories.
  data/upstream_verification.json
      Inspected public CI metadata for the upstream 254-machine verification.
  data/pdf_quality.json
      PDF compilation, embedded-font, reference, and visual-layout checks.
  data/reproduction_report.json
      This report's successful preparation-time reproduction, including the
      optional six-instance exact comparison with the pinned PSC generator.
  SHA256SUMS.txt
      SHA-256 manifest for all delivered files other than the manifest itself.
  NOTICE.txt
      Attribution and license boundaries.

REPRODUCE THE EXPERIMENTS

From this directory:

  python3 reproduce.py

Run Python normally. Do not use -O: the finite audit scripts use assertions.
The driver checks the manifest and generates temporary files. It does not
overwrite the supplied reference data. An optional record can be requested:

  python3 reproduce.py --output /path/to/reproduction.json

The optional pinned schema-generator comparison is supported when its source
has been separately obtained from the recorded ProveIt commit:

  python3 reproduce.py --upstream-kernel /path/to/kernel_metrics.py

BUILD THE REPORT

A standard TeX Live installation with the packages listed in article.tex is
sufficient. No external bibliography tool or network connection is required.

  pdflatex -interaction=nonstopmode -halt-on-error article.tex
  pdflatex -interaction=nonstopmode -halt-on-error article.tex

Rebuilding may change PDF metadata and therefore the PDF hash. The manifest
identifies the exact delivered version; it is not a promise of byte-identical
PDF output from every TeX installation. Python results are checked separately.

MAIN BOUNDARIES

One schema is an infinite effective family of axioms, not one finite sentence.
An equivalence to Con(ZFC) is not a proof of Con(ZFC).
Small finite tests are regressions, not consistency or infinite-run evidence.
The 269-state table is a compiler experiment, not a new record or new formal
end-to-end machine-to-ZFC theorem. New theory compilation and formal proof
transport remain the next tasks proposed by the report.
