# A Uniform Logarithmic Bridge for Adjacency-Bounded 132-Avoiders

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

The eight-page manuscript proves, for every fixed c0>0 and uniformly on
n >= c0 m log m as m tends to infinity,

    log p_n(m) = -(n/m)t_m + O_c0(n(log m)^2/m^2 + log n),

where K_m(r_m)=1, K_m(x)=sum_{k=1}^m C_{k-1}x^k, and t_m=m log(4r_m).
The same error permits n log(alpha_m/4), with alpha_m the fixed-cap growth
rate. Consequently the normalized rate has constant (1/2)log(pi) whenever
n/(m log m) tends to infinity. No uniform probability equivalent or leading
polynomial prefactor is claimed.

Contents:
- uniform_avoider_spectral_bridge.pdf: complete manuscript
- uniform_avoider_spectral_bridge.tex: editable LaTeX source
- build.sh: ordinary three-pass pdflatex build
- checks/: exact integer regressions and optional floating-point diagnostics
- SOURCES.md: pinned repository inputs, attribution, and scope
- validation.json: completed validation record
- SHA256SUMS: hashes of all other package files

Build with bash build.sh using a TeX installation containing Latin Modern,
amsmath/amssymb/amsthm, geometry, mathtools, microtype, booktabs, hyperref,
and xurl. No source-network access or external paper download is needed.
The exact checks use only Python's standard library. The optional diagnostics
require NumPy and SciPy. See checks/README.md for commands and limitations.

This is ordinary mathematical research, not a formally verified or externally
refereed result. The contribution answers the pinned source's joint-growth
question; the established source estimates and classical analytic tools are
credited. Finite regressions do not replace the mathematical proof.
