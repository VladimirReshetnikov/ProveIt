# Shifted pairing: portable source companion

## Bottom line

The shifted bijection **E(a,b) = 2^a(2b+1) - 1** is mathematically viable at the abstract calculus and proof-enumerator level. The direct register-source replacement costs more: **219 → 234 distinct source-DAG binary nodes**, or **232** for the best of the 200 tested local shapes. Expanded primitive occurrences grow **6,460 → 7,788**. This bounded search is not a lower bound on all implementations.

**These are source-DAG costs, not binary Turing-machine state counts. No shifted binary machine, state reduction, or sub-245 result is claimed.** The already delivered 14-page continuation report is unchanged; this archive is a separate compact source companion and contains no new PDF.

## What is established, and what is still missing

The independent review gives a **QUALIFIED PASS** for:

- The abstract generic native-theory/calculus transfer and shifted finite proof coding
- Both abstract enumerator halting directions at the actual logical seed `(N,T,W,A,D,H,X,Y,L)=(3,0,0,0,3,0,0,0,0)`
- Exact replacement-only source binding at original nodes 115, 116 and 162
- Whole-source inductive clean-entry invariants and total clean helper contracts bound to the exact helper control-flow graphs

The generic semantic theorem assumes both inverse laws, `p(0,0)=0`, and both field bounds `a,b ≤ p(a,b)`. Computable pairing/inverse functions are additionally required for the effective checker and enumerator claims; primitive-recursive functions are required for the stronger primitive-recursive coding claims. The concrete shifted functions satisfy these requirements. The code-as-variable-label issue is handled by fresh native matrices, not a direct recoding of old numerical proof fields.

**Still separate obligations:** a complete changed-source/enumerator composition theorem; an emitted literal binary table and its actual state count; the exact blank bootstrap; and a complete-frame, positive-time runtime proof. There is no new kernel-checked development. The final abstract ZFC endpoint uses the inherited NativeAx/SIR/ZFC comparison, which this review does not independently re-prove. Existing Cantor machine certificates do not transfer automatically.

## Clean and dirty macro contracts

The new pair has clean contract `(X,T,Y)=(a,b,0) → (0,0,E(a,b))`. Its actual dirty-output result, for initial `Y=c`, is `E(a,b)+2^a c`.

The inverse from source register `S=L` or `S=W` has clean contract `S=n,X=Y=0 → S=0,(X,Y)=unE(n)`. For arbitrary initial `(X,Y,S)=(x,y,s)`, its actual dirty result is `(X,Y)=unE(E(x,y)+2^x s)`, with `S=0`. Both helpers preserve every other register. These dirty contracts differ from the original Cantor macros; the old dirty contracts must not be silently reused.

Every one of the 120 external inverse calls has `X=Y=0`; all 242 external pair calls have `Y=0`. The changed-source zero/positive fixed point has 625,868 abstract states at 7,788 instruction sites. This is an inductive overapproximation from the actual seed's support, with internal loopbacks excluded from external call entry. It is not a finite concrete trace. Large abstract-state dumps are omitted: the code recomputes the fixed points and checks the recorded results and hashes.

## Contents

- `REPORT.md`: concrete helpers, exact costs, dirty contracts and bounded search
- `proof/REPORT.md`: ordinary mathematical transfer, effective qualifications and precise remaining obligations
- `helpers.json`, `best-helpers.json`: exact new helper DAGs, with every primitive and binary node charged
- `SOURCE_REPLACEMENTS.json`: exact replacement map and identities
- `independent-review/REVIEW.md`, `verdict.json`, `checks.json`, `helper_cfgs.json`: qualified review and retained evidence
- `code/shifted_source.py`, `code/search_shapes.py`: independently authored generator, interpreter, costs, clean-entry analysis and 200-shape search
- `proof/check_shifted_pairing.py`: finite pairing, decoded-label and command-pack checks
- `independent-review/check.py`: separately authored continuation-stack CFG audit; it does not import either generator/checker
- `EXPECTED_OUTPUTS.json`: byte counts and hashes of every deterministic output, including full changed-source DAGs generated locally
- `INPUTS.json`, `code/fetch_inputs.py`: pinned, allowlisted data-only input recovery
- `PROVENANCE.json`: exact original/adapted script hashes, source identities and attribution

The reports and historical audit records are preserved byte-for-byte. Paths in the original reports refer to their research layout; use the commands below for portable reproduction. In particular, full changed-source JSON files are reconstructed under `generated/`, not redistributed. `PROVENANCE.json` records the small path/assertion-guard adaptations to the executable scripts; the historical audit verdict's original `check.py` hash remains the original identity.

## Reproduce on a fresh extraction

Requirements: Python 3.10 or newer, standard library only, assertions enabled. The tested interpreter was CPython 3.12. No compiler, Lean/Coq, repository checkout, installed package or old workspace path is needed. Run commands from this archive's top-level directory.

1. Verify the included files:

   `python3 -B code/verify_manifest.py`

2. Recover the single required original data file from the exact original proof packet:

   `python3 -B code/fetch_inputs.py --archive-dir /path/to/archive-directory`

   That directory must contain `source245.zip` with the pinned 2,846,575-byte identity in `INPUTS.json`. Alternatively, `python3 -B code/fetch_inputs.py` fetches its pinned public URL. Network availability is required only for this optional download route. The local-archive route was tested in a fresh extraction.

   Recovery verifies archive SHA-256, Git blob SHA-1, member name, byte count and SHA-256 before writing `inputs/Dag254.v`. It reads the Coq source strictly as inert mathematical DAG data. No downloaded source is imported, compiled or executed.

3. Run all supported reproduction checks:

   `python3 -B code/reproduce.py`

   This regenerates both sources and exact helpers, the 200-shape scan, all clean-entry fixed points, mathematical finite checks and the independent CFG audit. It compares all twelve generated artifacts byte-for-byte by SHA-256 against `EXPECTED_OUTPUTS.json`. Results and logs are written only under `generated/`; included reports and retained evidence are unchanged.

   To run only the pairing/label/command finite checks without original data, use `python3 -B proof/check_shifted_pairing.py`. This narrower run does not validate source reconstruction, costs or clean-entry invariants.

The full run checks 108 direct clean pair cases, 4,098 direct inverse cases, 80 selected-best pair cases, 2,050 selected-best inverse cases and 470 dirty-contract cases. The independent audit separately checks 16,658 helper executions, 65,536 inverse inputs, 8,481 forward pairs, literal CFG normal forms and both changed-source fixed points. The proof checker covers 65,536 inverse/decoder inputs, 32,800 forward pairs and 17,152 command-pack round trips. The ordinary all-natural-number arguments remain in the reports; finite tests alone are not their proof.

## Source boundary

This archive includes independently authored research, helpers and checkers. It excludes incoming archives, inherited source files/tables, the full changed-source DAGs (which incorporate inherited structure), and copied native adapter texts. Required original DAG data is recovered from the exact pinned packet. Public native source links remain in the proof report, and hashes of inspected texts remain in `PROVENANCE.json`. No license is imposed on third-party work.
