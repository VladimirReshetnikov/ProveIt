# Shifted binary pairing: concrete register-source experiment

## Result and scope

The exact shifted pairing

    E(a,b) = 2^a (2b+1) - 1

has been implemented using only the existing nine logical registers and the existing increment, decrement-and-test, break, and continue primitives. The new helpers meet the source's actual clean-scratch call contracts. This is a genuinely different encoding from the earlier archived unshifted 2-adic experiment.

This direct replacement is not a source-size improvement. In a matched, structurally hash-consed binary-DAG comparison, the original 219-node source becomes 234 nodes. A bounded exact scan of 200 legal local parenthesizations lowers that to 232, still 13 nodes larger. Expanded instruction occurrences grow 6,460 to 7,788. This is a bounded result about the concrete implementations and search family recorded here, not a lower bound on all shifted pairing implementations.

No binary Turing machine was generated. No sub-245 result, blank-start equivalence, or proof-assistant endpoint is claimed. The 219/232 counts are source decision-DAG node counts, not the 128-state grammar or 245-state full-table counts of the optimized prior machine. New helpers would require fresh atomization, routing, physical-state accounting, runtime simulation, and boot verification before any full-table claim.

## Prior-attempt check

The supplied source-search packet contains

    sources/ProveIt/Computability/BusyBeaver/Research/ZFC/pairing_backend_experiment.py

It implements the unshifted expression `2^a(2b+1)`, handles zero separately in its inverse, and changes the falsity target from 1 to 5. The script explicitly disclaims proof-search calibration. It is not this shifted bijection, and none of its Python was imported or executed.

This experiment reads `reference/source/Dag254.v` from the original proof packet as a finite mathematical table. Its SHA-256 is `538ddaddd932058c2b319011126579d77783231f54331772377c05848a0599e3`. All executable code in this directory was independently authored. No downloaded repository script was executed, imported, compiled, or modified.

## Registers and exact primitive semantics

Registers remain `(N,T,W,A,D,H,X,Y,L)` in original numerical order `0..8`.

- `I(r)` increments register r
- `D(r)` decrements a positive register and returns normally; at zero it returns break level 1
- In a binary node `(left,right)`, a break from the left skips the right, consuming one level; a continue from the right restarts that node, consuming one level
- All other control results propagate

Every primitive and every binary node is explicitly represented in `helpers.json` and `best-helpers.json`. Arithmetic notation in the proofs below is specification, not an uncharged primitive.

## Pair implementation and contract

Pseudocode, with every transfer/doubling expanded into unary loops by the generator:

    while T > 0:
        T -= 1
        Y += 1
        Y += 1
    while X > 0:
        X -= 1
        while Y > 0:
            Y -= 1
            T += 1
            T += 1
        while T > 0:
            T -= 1
            Y += 1
        Y += 1

Clean contract:

    (X,T,Y)=(a,b,0)  ->  (X,T,Y)=(0,0,E(a,b))

All six other registers are unchanged. The first loop produces `2b`; each outer iteration maps `Y` to `2Y+1`. Induction gives `Y=2^a(2b+1)-1`. Every unary loop terminates; the outer loop consumes a.

The fully general dirty-output contract is:

    final Y = E(a,b) + 2^a c, where initial Y=c

This differs from the original Cantor helper's additive dirty-output contract. No preservation of the old dirty-output contract is asserted.

The direct helper has 14 primitive occurrences and 13 distinct binary nodes; the best sharing-aware tree has 14 occurrences and 12 nodes. The original helper has 10 occurrences and 9 nodes.

## Unpair implementation and contract

Use source S=L or S=W. The same program is instantiated twice; X and Y are the output registers.

    repeat outer:
        repeat half:
            if S = 0: return from outer
            S -= 1
            if S = 0: leave half
            S -= 1
            Y += 1
        X += 1
        while Y > 0:
            Y -= 1
            S += 1

The half loop's first failed decrement detects an even original S and returns with its half in Y. The second failed decrement detects odd original S, increments X, and repeats with its quotient. Thus X counts trailing one bits, equivalently `v2(n+1)`. No separate nonzero guard and no `S += 1` adjustment are used.

Clean contract:

    S=n, X=Y=0
      -> S=0, X=v2(n+1), Y=((n+1)/2^X-1)/2

All six other registers are unchanged. At the start of each clean outer round,

    n = 2^X (S+1) - 1, Y=0

The inner loop consumes two units from S per increment of Y. If S began even, return establishes `n=E(X,Y)`. If it began odd, incrementing X and moving Y into S preserves the outer invariant. The next S is floor(old S/2), strictly smaller on every odd positive round, so all rounds terminate. Zero naturally returns `(0,0)`.

The general dirty-scratch contract is:

    final (X,Y) = unE(E(x,y) + 2^x s)

for initial `(X,Y,S)=(x,y,s)`, with S cleared. This differs from the original Cantor inverse's additive dirty-scratch contract. Clean scratch is sufficient at every actual source call.

Each shifted inverse has 11 primitive occurrences and 10 binary nodes, versus 8 and 7 for the original inverse.

## Whole-source clean-call invariant

A self-authored finite abstract interpreter tracks exact zero/nonzero status of all nine registers at every instruction site. Increment sets a register positive. A positive decrement splits into zero and positive successors. A zero decrement takes the exact break edge. Root completion loops back to the root. Consequently its reachable set overapproximates every concrete run.

It begins with the actual seed `(N,T,W,A,D,H,X,Y,L)=(3,0,0,0,3,0,0,0,0)` and reaches a fixed point:

- Original source: 473,448 abstract states at 6,460 instruction sites
- Direct shifted source: 625,868 abstract states at 7,788 sites
- Best shifted tree: 625,868 abstract states at 7,788 sites

For all 120 external inverse calls, X=Y=0 at entry. For all 242 external pair calls, Y=0 at entry. Internal loop-back edges are correctly distinguished from external helper invocation; scratch need not remain clean on internal iteration.

These are complete finite abstract-interpretation fixed points, rather than a finite concrete execution prefix. `shifted-clean-entry-audit.json` and `best-clean-entry-audit.json` record the entry masks and result. The implementation and transition semantics remain subject to ordinary independent code review; this is not a proof-assistant certificate.

## Exact cost comparison and bounded shape search

Original whole source:

- 6,460 primitive occurrences
- 219 structurally distinct ordered binary nodes
- Expanded maximum depth 96
- Expanded maximum zero-run 7

Direct matched shifted replacement:

- 7,788 primitive occurrences, an increase of 1,328
- 234 structurally distinct ordered binary nodes
- Expanded maximum depth 96
- Expanded maximum zero-run 9

Best in the 200-shape scan:

- 7,788 primitive occurrences
- 232 structurally distinct ordered binary nodes
- Expanded maximum depth 97
- Expanded maximum zero-run 9
- Pair shape `(0,1,2)`, inverse shape `(0,0)` in the reproducible enumeration

The leaf increase is exactly `242*(14-10) + 120*(11-8) = 1328`.

The scan enumerates 20 legal parenthesizations of the direct pair's closed loop bodies and 10 matched parenthesizations for both inverse instances. It preserves guard exits and resolves every labeled continue/break to its actual level after restructuring. Costs are counts of the complete changed source after structural sharing, not a sum of isolated helper costs. The distribution is 10 candidates at 232 nodes, 80 at 233, 90 at 234, and 20 at 235.

Even the best form introduces break level 2 and increases the expanded zero-run requirement. Those effects cannot be treated as free in a physical compiler. A new compressed grammar search could conceivably find an advantage, but no concrete such sharing advantage is established here. Following the bounded outcome, no noncompetitive full backend was built.

## Tests and remaining theorem obligations

`shifted_source.py` passes 108 clean pair tests and 4,098 clean inverse tests, with unrelated registers initialized to nonzero sentinels. The largest test took 82,149 structured-interpreter visits. `search_shapes.py` additionally checks the selected best tree on 80 pair cases and 2,050 inverse cases. A further 470 dirty-contract tests check the generalized formulas above.

E is a bijection and the inverse agrees with Cantor at codes 0,1,2,3. Thus the zero pair and falsity tag 1 are preserved. The separate generic-pairing mathematical argument is now recorded in `proof/REPORT.md`, including the required native-model adapters for the bundle gate. In particular, changing code values that are also variable indices cannot be justified by a naive recursive renaming alone. This report supplies executable register helpers and costs; the companion proof report supplies the ordinary mathematical logic transfer. Neither report supplies a new Lean/Coq kernel build or a full binary-machine theorem.

## Reproduction and deliverables

Run only the independently authored scripts here:

    python shifted_source.py
    python search_shapes.py

- `shifted_source.py`: source-data reader, new helpers, interpreter, cost counter, clean-entry abstract analysis
- `search_shapes.py`: bounded legal local-tree search
- `helpers.json`, `best-helpers.json`: exact helper instruction DAGs
- `shifted-source.json`, `best-shifted-source.json`: exact whole register-source DAGs
- `shifted-source-results.json`: direct costs and tests
- `shape-search-results.json`: all 200 shape results
- `shifted-clean-entry-audit.json`, `best-clean-entry-audit.json`: changed-source call-contract evidence
- `best-cost-details.json`: best-tree costs, clean entry summary, and dirty-contract test count
