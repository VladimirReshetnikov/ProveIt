#!/bin/sh
# Portable build: requires a normal TeX Live or MiKTeX installation with pdflatex.
set -eu
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build role-cover.tex > build/pass1.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build role-cover.tex > build/pass2.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build role-cover.tex > build/pass3.log
cp build/role-cover.pdf role-cover.pdf
printf '%s\n' 'Built role-cover.pdf'
