# Real stable monomers under a two by two role cover

This package proves an ordinary structural theorem for finite loopless directed relations. If there are physical vertex sets P,Q, each of size at most two, such that every arc has its tail in P or its head in Q, the signed physical monomer polynomial is real stable for arbitrary nonnegative independent tail and head activities. P and Q may overlap. The support polynomial has negative real roots and is ultra-log-concave at its actual surviving degree.

A support is an ordered pair of disjoint endpoint sets admitting a directed matching. It is counted once, regardless of its number of witnessing matchings. The theorem includes all balanced core-edge subsets and internal arcs within either core side. The article also proves a rank-two matroid free-product corollary and the elementary transfer to h(t)=(1+t)^N Gamma(t/(1+t)^2) for any integer N at least twice the actual degree.

## Contents

- `role-cover.pdf`: standalone article
- `role-cover.tex`: editable LaTeX source
- `build.sh`: portable PDF build script
- `verify.py`: portable exact supplementary-check entrypoint
- `proofs/`: unchanged approved ordinary proof notes, scoped independent review records, and exact checker sources
- `verification-receipt.json`: record of the packaged checks run during assembly
- `SHA256SUMS`: checksums of the shipped fixed files

No unfinished degree-four census is a dependency of this package. No claim is made that all directed relations or all degree-four preorder support polynomials are real-rooted. No literature-wide priority or proof-assistant formalization is claimed.

## Rebuild the article

Use a normal TeX Live or MiKTeX installation with `pdflatex` and the standard packages listed in the source (including Latin Modern, microtype, geometry, fancyhdr, xurl and hyperref). On a POSIX shell:

    sh build.sh

The PDF is written to `role-cover.pdf`; temporary TeX files and logs go under `build/`. On systems without a POSIX shell, run pdflatex three times on `role-cover.tex` directly. The delivered script contains no machine-specific TeX paths.

## Run the exact supplementary checks

Requirements: Python 3.9 or newer, SymPy, and GCC with C++17 support. The C++ sources use the GCC-compatible `bits/stdc++.h` header. Install SymPy in your preferred environment if necessary, then run:

    python3 verify.py

Do not use `python -O`: the entrypoint explicitly rejects disabled assertions. C++ checks are compiled with assertions enabled into a temporary directory; the archive includes no executable binaries. The verifier first checks the unchanged proof, audit and source hashes, then runs all twelve aggregate-variable polynomial identities and four independent Hall-based monomer checkers. Each Hall checker covers all 4,845 exterior-type multisets through four exterior vertices, including isolates, under three activity assignments (unit, positive and with zeros): 14,535 weighted identities per core pattern and 58,140 in total.

These finite tests supplement the ordinary proof. Arbitrary population size and arbitrary numbers of parallel classes follow from the displayed algebraic identities, stability-preserver theorems and exact support bijections, not from extrapolating the tests. The verification receipt is regenerated on each run. It is excluded from SHA256SUMS because its elapsed time changes. Rebuilding the PDF may change PDF metadata and therefore its checksum; verify the delivered manifest before rebuilding.

## Audit provenance and source paths

The approved proof notes and review records are preserved byte for byte. Some historical receipts mention their original absolute research paths. The portable correspondence is:

    /workspace/shared/balanced-core-gamma-research/  ->  proofs/

The verifier applies this translation and does not access the original research workspace. Receipt references to a classification template are provenance labels only; no census file is required. Mathematical dependencies are cited in the article. The independent review records document internal research checks, not journal peer review or a formal proof-assistant certificate.
