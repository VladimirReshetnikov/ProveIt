# A positive Airy amplitude for relaxed binary trees

Research article and reproducible source package, 2 October 2026.

## Contents

- `relaxed_tree_amplitude.pdf`: the complete 24-page article
- `relaxed_tree_amplitude.tex`: a genuinely standalone LaTeX source, with no external input files or bibliography needed
- `build.sh`: deterministic-date PDF build, with checks for overfull boxes and unresolved references
- `checks/`: fail-closed exact rational/symbolic verification package and recorded normal/optimized/corruption-test logs
- `numerics/`: optional numerical diagnostic producers and recorded spectral outputs, clearly separate from exact verification
- `PROVENANCE.json`: primary-source links, inspected-source hashes, and claim boundaries
- `RELEASE_VALIDATION.json`: page-by-page visual review and fresh-extraction validation record
- `SHA256SUMS`: hashes of the source/archive contents, excluding itself

## Mathematical result

For relaxed binary-tree counts r_n (OEIS A082161) and the largest Airy zero a_1, the article proves a positive amplitude gamma_r and a full Poincare expansion to every fixed algebraic order:

r_n = gamma_r n! 4^n exp(3 a_1 n^(1/3)) n exp(sum_{j=1}^J b_j n^(-j/3)) [1+O(n^(-(J+1)/3))].

The same positive gamma_r is used at every order. The article gives a convergent finite-Jacobi representation, the complete analytic proof, a triangular polynomial-Airy coefficient algorithm, six explicit log corrections, normalized ratio coefficients through n^(-3), and all-order inverse estimates with a quantified finite Newton algorithm.

The compacted-tree sequence A254789 is included for formal comparison and for an unconditional inverse using its known Theta bounds. This report does not prove its positive amplitude or transfer its formal coefficients to actual all-order asymptotics. No exponentially small sectors, full transseries, closed-form amplitude, certified amplitude digits, or effective inverse cutoff are claimed. Earlier numerical amplitude estimates are attributed to the original paper. No worldwide priority claim is made.

## Build and exact replay

A TeX Live installation with pdfTeX and standard AMS/Latin Modern/geometry/microtype/hyperref/fancyhdr packages is required for the article. The exact suite uses Python 3.12 and SymPy 1.14.0 in the recorded environment. It needs no network and no external research folder. Install dependencies in an appropriate environment if not already available; the replay scripts do not install anything automatically.

From the extracted package root:

    sha256sum -c SHA256SUMS
    bash build.sh
    bash replay.sh

`replay.sh` runs the complete exact suite and deliberate-error regressions in both normal and optimized Python. It preserves explicit exception checks under `-O`; a successful corruption test means the deliberately invalid case was rejected for the expected reason. See `checks/README.md` for complete coverage and commands for individual modes.

The optional numerical workflow is documented in `numerics/README.md`. The numerical checkpoints named `exact_dp_3000.json` contain decimal diagnostics computed from exact integers in memory; they do not archive the exact integer array and are not certified intervals. Their expensive original computation is not part of default replay.

## Inverse qualification

Nearest-integer recovery is proved for sufficiently large exact inputs y=r_n (and for compacted exact values using the known Theta result). For an arbitrary threshold, rounding only supplies two candidates; one exact or certified count comparison is needed. The no-amplitude formula still misses nearest-integer recovery at n=3000. The all-order relaxed inverse uses the mathematically defined gamma_r; substituting an uncertified decimal does not give a certified implementation.

## Scope of validation

Finite exact checks corroborate matrix algebra, startup conventions, polynomial coefficient identities, and endpoint conversions. They are not substitutes for the article's analytic proof. Normal and optimized runs, deliberate corruption cases, clean PDF compilation, every rendered page, and fresh-unzip replay were checked before delivery, as recorded in `RELEASE_VALIDATION.json`.

No primary-author PDF or Maple supplement is redistributed, and this package performs no publication or repository modification. Sources are linked in the article and provenance record.
