# Growing macro counts for bounded gap 132 avoiders

This package contains the complete research note, editable LaTeX proof, reproducible checks and build information.

The first theorem gives a single relative Gamma equivalent when 1 << n/m << log m and the fractional part of (n-1)/m stays a fixed distance from both zero and one.

The second theorem treats the shrinking transition immediately below an integer. It keeps two adjacent Gamma contributions whenever their exact ratio stays in a fixed compact positive interval. The exact transition center tau solves an explicit equation, its width is tau/ell, and the normalized ratio tends to exp(-x) at s = tau exp(x/(ell-1)).

The proof controls all small runs together using the exact Catalan-power law and a three-range weighted-tail estimate. It does not extrapolate fixed compact tilts from the preceding m log m theorem.

## Files

- sublogarithmic_avoider_counts.pdf: reader-facing report
- sublogarithmic_avoider_counts.tex: exact editable proof
- build.sh: ordinary three-pass pdfLaTeX build
- checks/verify_exact_identities.py: standard-library exact checks
- checks/exact_identity_results.json: results of 610 Catalan-power/probability rows and 40 adjacent-Gamma rows
- checks/scalar_diagnostics.py: optional finite scalar-coefficient comparisons
- checks/scalar_diagnostics.json: twenty diagnostic rows
- checks/README.md: instructions and the limits of these diagnostics
- SOURCES.md: source pin and attribution
- validation.json: package checks
- latex-build.log: clean final compiler log
- SHA256SUMS: packaged-file checksums

Run bash build.sh with a normal TeX Live installation containing pdfLaTeX, Latin Modern, geometry, amsmath, amssymb, amsthm, mathtools, microtype, hyperref and xurl.

The exact checker uses Python's standard library and remains active with python -O. The optional diagnostics require NumPy and SciPy.

The proof is not formally verified or externally refereed. Theorems retain their stated phase restrictions; this is not an all-phase theorem for the entire lower growing-count regime.

