# Every Logarithmic Scale Contributes

**Critical moment crossover and endpoint corrections for the largest jump of a 132-avoiding permutation**

AI-assisted research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.

Open `article.pdf` to read the manuscript. `article.tex` is the complete editable source.
The package also contains exact counting checks, symbolic checks, numerical regressions,
all figures and their generating programs, and a provenance/proof-status ledger.

## Mathematical contribution

Let D_n = n minus the largest adjacent absolute difference of a uniform 132-avoider.
The manuscript builds on three explicitly identified results in a pinned ProveIt report:
the algebraic limiting law and its tail, an O(n^(-1/2)) total-variation estimate,
and the macroscopic tail profile. From these it proves:

- E sqrt(D_n) = (3/(2 sqrt(pi))) log n + c_star + o(1), with an exact convergent
  constant definition and numerical approximation c_star = -0.942121413999402… .
- The first correction to E D_n^p for every fixed 0 < p < 1/2, given by a
  regularized incomplete beta function; the correction coefficient is negative.
- A locally uniform complex-moment transfer theorem and a two-term crossover for
  p = 1/2 + lambda/log n.
- A uniform logarithmic-scale law under square-root bias, with a two-endpoint signed
  correction in dual bounded-Lipschitz norm; exponentially tilted laws and all fixed
  logarithm-weighted critical moments follow.
- A counterexample showing why the uniform tail error is essential, and a stability
  theorem for smaller perturbations.

The abstract theorems have complete proofs in the manuscript. The permutation application
inherits the status of the three repository inputs. Neither the new arguments nor those
inputs have been checked here by Lean or Rocq. No external peer review or exhaustive
publication-priority certification is claimed. The numerical decimals are not interval
certificates. See `PROOF_STATUS.md` for the exact scope.

## Reproduction

Python 3.11 or later is suitable. The versions used for the optional scientific packages
are recorded in `requirements.txt`.

```sh
python -m pip install -r requirements.txt
python code/exact_counts.py --max-n 64 --pgf-terms 128
python code/verify_symbolic.py
python code/numerics.py
python code/figures.py
./build.sh
```

The build requires a reasonably complete TeX Live installation, including newtx fonts,
amsmath/amsthm, mathtools, microtype, hyperref, cleveref, listings, fancyhdr, enumitem,
titlesec, and aliascnt. The delivered vector figures are sufficient to rebuild the PDF without
rerunning Python. `build.sh` runs pdfLaTeX three times to stabilize the contents and
cross-references. On Windows, run the three `pdflatex` commands manually or use a TeX editor.

`exact_counts.py` deliberately uses a transparent memoized endpoint recurrence rather
than an optimized large-n implementation. Its default range is the range actually
recorded and checked, n <= 64. Runtime and memory increase rapidly when this range grows.
The asymptotic proofs do not depend on computation at larger sizes.

## Recorded verification

- 625 avoiders at sizes 1–7 checked against direct pattern testing of all permutations.
- 23,713 generated avoiders at sizes 1–10 checked against the exact deficit histograms.
- 784 endpoint-state equalities checked independently by enumeration.
- Exact integer distributions for every size 1–64, with Catalan totals.
- 129 rational PGF coefficients checked through degree 128.
- Five symbolic algebraic identity checks.
- Quadrature at 40 and 70 decimal working precision, agreeing beyond 29 decimal places;
  separate integral and removable-limit checks for the constants.

The numerical figures illustrate slow convergence. They are not fits and do not prove
any asymptotic assertion. In particular, the square-root-biased mean logarithmic scale
moves away from its limiting value over the small sizes displayed in the article.

## Files

`data/exact_distributions.json` stores unnormalized integer counts, indexed first by n,
then by d; index d=0 has count zero. `data/pgf_coefficients.json` stores exact rational
coefficients as strings. `data/constants.json` records non-certified quadrature results.
`data/finite_moments.csv` records rounded moments computed from the exact integer counts.

`SHA256SUMS` covers all delivered files other than itself. Reproduction overwrites some
outputs, so its hashes describe the delivered package, not every possible rebuild.
