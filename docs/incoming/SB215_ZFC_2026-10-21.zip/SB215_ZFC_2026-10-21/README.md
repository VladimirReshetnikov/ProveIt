# SB215-AB: a calibrated adaptive ZFC proof search

This packet supplies **SB215-AB**, a new literal **215-working-state,
two-symbol, blank-tape Turing machine**, and the independently checked
calibration of its archived predecessor **SB215**. Initialization is included
in the 215 states; the halt state is separate. For each delivered table, the
ordinary mathematical proof, using the explicitly identified inherited
numerical-calculus/ZFC calibration, establishes

\[
\mathrm{ZFC}\vdash
\bigl(\text{the machine does not halt on blank tape}\bigr)
\longleftrightarrow\operatorname{Con}(\mathrm{ZFC}).
\]

**No 214-state construction is claimed. No new Lean/Rocq or other
proof-assistant kernel endpoint is claimed.** The new argument is an
all-natural mathematical proof formalizable in ZFC, supported by exact source,
whole-tape runtime, and blank-start certificates. It does not assert
unconditional nonhalting or independently prove the inherited set-theoretic
calibration.

Read [report/report.pdf](report/report.pdf) for the complete argument and
transition-table appendix. The editable LaTeX source is
[report/report.tex](report/report.tex).

## What is new

The main breakthrough closes an explicitly open experiment. The earlier
scratch-biased machine already had a valid physical implementation, but its
parser changed behavior after different commands and its counter skipped
some candidate numbers. Ordinary cofinal padding did not establish that it
would actually visit a successful proof.

The new **four-state scanner theorem** proves exactly that. The word `11011`
synchronizes the scanner; Cantor-diagonal identities then choose between
the harmless prefixes `S` and `MP(0);MP(2)` to obtain a visited candidate.
An outer AX prefix preserves its visited state while making its code
arbitrarily large. A compatible encoder puts the successor only after S.
This proves completeness for the actual adaptive schedule, including its
one-candidate delay.

Soundness has a short exact initialization argument: the seed stack is
`3=P(2,0)`, and its first head `2=Q_0(0)` is a theorem by generalization of
truth 0; all later heads are truth 0. The inherited command invariant
therefore applies directly. A stronger gap-one/two credit theorem is included
as optional research; primary soundness does not depend on it.

SB215 preserves the archived prototype's bytes and adds this completed
calibration. **SB215-AB is the new literal composition**: it combines that
now-calibrated scheduler with the known sampler `rho6(A,B)` in place of
`rho6(A,C)`. The native table changes exactly these two rows:

| Row | SB215 | SB215-AB |
|---|---|---|
| `199/1` | `1 R 166` | `1 R 12` |
| `206/0` | `0 R 186` | `0 R 76` |

The sampler itself is inherited from Source 163 and existing secondary K215
work. The source permutation census and paired rho4/rho2 minima rediscovered
during this investigation were already recorded in Source 165; they are not
claimed as new results here.

## Exact machines and verification

The primary table is [machine/sb215_ab.tm](machine/sb215_ab.tm); the calibrated
control table is [machine/sb215.tm](machine/sb215.tm). Both dense tables start
at state 0, use working states 0 through 214, and halt at 215. Native tables
start at 74, use dispatcher 84, and halt at 254. The adjacent canonicalization
files give the complete state bijections. The convention is one two-way
infinite tape, initially all zero, head initially at position zero, and L/R
moves only.

| Verified quantity | SB215-AB | SB215 |
|---|---:|---:|
| Working states / transition rows | 215 / 430 | 215 / 430 |
| Distinct source subtrees / primitive occurrences | 201 / 4,733 | 201 / 4,733 |
| Arbitrary-natural guarded runtime cases | 6,152 | 6,152 |
| Symbolic proof-rule applications in fresh replay | 1,618,717 | 1,617,669 |
| Covered transition rows / minimum duration constant | 430 / 6 | 430 / 6 |
| Complete blank prefix to matched frame | 69,744 | 69,744 |
| Matching synthetic partial-AX primitive steps | 172 | 172 |

The primitive proof quantifies over arbitrary natural register values,
arbitrary extra gap, every nonempty finite spare list, and the entire tape.
Its finite proof-construction limits are not bounds on those quantified
inputs. Blank startup is checked separately as an exact finite computation.

The scoped novelty census covers 319 complete 215-state `.tm` files in the
recorded corpus, with 77 byte hashes and 44 rooted graphs. SB215-AB matches
none under state renaming or global tape reflection. SB215 intentionally
matches the old open prototype. These are corpus-specific comparisons, not
a universal historical-novelty or semantic-inequivalence theorem.

## Reproduce

Use Python 3.10 or later, its standard library, and enabled assertions. From
this packet's root:

```sh
python3 -B verify.py
python3 -B verify.py --runtime --out /absolute/path/to/a/new-verification-directory
```

The default route checks the frozen inputs and reconstruction, mathematical
certificates, stored binary evidence, exact blank startup, and native/dense
correspondence. The optional runtime route derives the quantified primitive
cases afresh. Use a fresh output directory; verification does not rewrite
the archived evidence.

Build the report with a standard TeX Live installation:

```sh
cd report
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

An additional pass may be needed for the table of contents. The PDF is also
supplied, so TeX is not needed to verify the machines.

## Contents and provenance

- `machine/` contains both native/dense tables, exact sources, and bijections.
- `proofs/`, `report/`, and `reviews/` contain the mathematical arguments and
  independent reviews; `evidence/` contains the frozen check receipts.
- `reference/scratch-prototype/` preserves the old experiment and its
  reconstruction. Its **OPEN** labels are unchanged historical statements
  about what was proved in that earlier packet. This packet closes the
  identified logical gap; it does not rewrite that history.
- `reference/transfer-parent/` preserves the strong compiler, numerical
  calibration dependencies, runtime framework, notices, and licenses.
- [STATUS.json](STATUS.json) separates new results, inherited dependencies,
  verification facts, and unclaimed work. [NOTICE.md](NOTICE.md) records
  attribution and the MIT No Attribution terms for new material.

The repository audit is pinned to ProveIt commit
`29e2cc4c557c04d3358e41e566bd7c582844ff4e`. The archived inputs and table census
have separately recorded byte/Git-blob pins. The principal inherited physical
object is the scratch-biased experiment from `T215_Transfer_2026-10-20`;
the new work is its scheduler calibration, the SB215-AB composition, and the
fresh verification and independent audits supplied here.
