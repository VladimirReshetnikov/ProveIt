# Cofinal dyadic proof search

This note is an ordinary mathematical proof about the command compiler used by
the accepted K215 machine. It is not a claim that an allocated binary machine
or its blank startup has been checked. The companion `research/dyadic/sites_step2.json` changes
the source scheduler from unit stride to stride two.

## Pinned predecessor and explicit interface

The predecessor is ProveIt commit
`29e2cc4c557c04d3358e41e566bd7c582844ff4e`,
`Computability/BusyBeaver/Research/ZFC/candidate-k215`.
The ordinary source interface and its numerical-calculus calibration are in
the proofs of `candidate-k215` and `candidate-k216/alternatives/permuted`.

Write P(a,b)=(a+b)(a+b+1)/2+b, T(s)=s(s+1)/2. For the accepted 210 command
order, an AX command has raw fields [c+3,y,x]. If R encodes a fixed remaining
command word as a continuation, the first-candidate number for AX followed
by that word is

    n = P(c+3,P(y,P(x,R))).

There is no successor around this first-candidate code. Continuation words
have the inherited extra successor before a nonempty field list.

The inherited strong compiler has the following exact contract. For every
numerically derivable code z it supplies a fixed command word B_z which,
from every (t,w,0,0), halts earlier or returns (z,w,0,0). Here the tuple is
(top,stack,counter,cache). If t and each decoded head of w are theorems,
earlier halting is sound as well. AX(c;x,y) maps every sound incoming tuple
to a sound tuple with counter and cache zero, for all c,x,y in N. These
are the only logical properties used below; no general substitution closure
or syntactic injectivity at numerical truth is assumed.

## Lemma 1: triangular numbers permute a dyadic residue system

For k>=0, the map s -> T(s) mod 2^k is a permutation on
0<=s<2^k. For k=0 the assertion is immediate. If
T(s)=T(t) mod 2^k, then

    2^(k+1) divides (s-t)(s+t+1).

The two factors have opposite parity. Therefore the even factor is divisible
by 2^(k+1). If s!=t, then 0<|s-t|<2^k and
0<s+t+1<2^(k+1), so neither even factor can be divisible by 2^(k+1).
This contradiction proves injectivity, hence bijectivity on the finite set.

Also T(s+2m)-T(s)=m(2s+2m+1), so adding 2m preserves T(s) modulo m.

## Theorem 2: every dyadic progression has cofinally many successful codes

Fix a continuation code R, k>=0, m=2^k, a residue a mod m, and any lower
bound B. Put b=P(0,P(0,R)). By Lemma 1 choose t with
T(t)+b=a mod m. Choose s=t+2mj large enough that
s>=b+3 and s>=B. Set x=y=0 and c=s-b-3. Then c>=0 and

    P(c+3,P(0,P(0,R))) = T(s)+b = a (mod m).

The code is at least B. Taking larger j makes it arbitrarily large. Every
member thus constructed encodes an AX prefix followed by the exact fixed
continuation R, and the prefix is a sound reset for every incoming sound
tuple. All candidate fields are explicit natural numbers.

If numerical falsity 1 is derivable, choose R to encode
B_1; DROP; NIP; NIP. The last suffix halts after returning top 1, unless
the strong block has already halted. Hence every residue class modulo
2^k contains arbitrarily large successful candidate codes. The same proof
works with any additional fixed reset before B_1, if an implementation
prefers that interface.

For stride two the entire residue argument reduces to
T(s)=0 mod2 for s=0 mod4, and T(s)=1 mod2 for s=1 mod4.
Neither Gauss's theorem nor an analytic density argument is needed.

## Theorem 3: dyadic-stride scheduling preserves consistency calibration

Replace the outer candidate counter update N:=N+1 by N:=N+2^k,
leaving all command equations, continuation decoding, and source scratch
cleanup unchanged. Start at any calibrated sound root with natural counter
N0. The modified source halts exactly when ZFC has a finite refutation.

Soundness is the unchanged theorem/Good-stack invariant: every command
preserves it until NIP tests numerical falsity. Candidate order is irrelevant
to this implication. For completeness, every candidate that fails to halt
finishes in finite time. Indeed, each nonempty continuation is decremented
before decoding, each field decoder returns a tail at most its input, and
each arithmetic macro terminates. Therefore the outer loop visits every
N0+j*2^k in increasing order. Theorem 2 supplies a successful member at or
above N0 in that residue class; it is eventually reached unless an earlier
candidate already halts. The inherited numerical-calculus calibration
identifies derivability of 1 with a finite ZFC refutation. All this is
ordinary finitary arithmetic reasoning formalizable in ZFC.

This is a consistency compiler for a restricted proof search. The restricted
enumerator need not represent all proofs or even all raw candidate codes.

All literal source files named below are included in `research/dyadic/`.

## Literal stride-two source

The accepted source prefix is

    (G,(F,H))
    G=(CD8,CB1)
    F=(CD0,(CI8,(CI6,CC3)))
    H=(CI0,(CD6,CC2)).

At a root with proof-tail register L=R8 equal to zero and scratch X=R6 zero,
F copies N=R0 to L and X while clearing N. H restores N from X and adds one.
The continuation on the right is the unchanged command decoder.

Replace the closed subtree H at exact address 011 by (H,CI0). H is closed:
both boundary-control demands are zero, including its internal CC2 loop.
The added CI0 is reached exactly once after H terminates. Thus the prefix
maps

    [N,t,w,0,d,h,0,0,0]
       to [N+2,t,w,0,d,h,0,0,N]

at the first leaf of the unchanged command decoder. If L was positive,
the G branch takes the same decrement and bypasses F and H completely;
the continuation convention is therefore unchanged.

The new exact source has 203 distinct subtrees, 4752 leaf occurrences,
maximum depth 47, and maximum zero run 6. The two independent inherited
CFG resolvers agree on every edge. A finite scheduler regression covers
N=0..63 and residual tails 0..8, but the all-natural scheduler claim follows from the two unary
loops just described. Source counts are not binary state counts.

## Transfer-language specializations

The same argument applies to the separately calibrated three-command transfer
language, whose commands are S, MP, and AX. Its native AX fields are
[c+2,y,x], and its strong refutation suffix is B_1;H, where H is the
top-falsity-guarded macro AX(0;0,0);S^11. Therefore replace b+3 by b+2
and c=s-b-3 by c=s-b-2 in Theorem 2. The residue lemma and scheduler proof
are unchanged. This applies both to the original order S=0,MP=1 and to
the later order MP=0,S=1. No assertion about their stack-credit theorems
is needed when the actual initial tuple has a safe theorem stack. A dirty
startup requires its own protected-tail/credit proof.

The current MP-first transfer source has 201 distinct subtrees, 4775 leaves,
depth44 and maximum zero run6. Its initial scheduler subtree is literally
the K215 subtree. Both `sites_transfer_step2.json` (N advances by2) and
`sites_transfer_even_copy.json` (L receives2N and N advances by1) have
202 distinct subtrees and4776 leaves, still depth44 and zero run6.
For the latter, replace the original F-body
(CI8,(CI6,CC3)) by ((CI8,CI8),(CI6,CC3)); its CC3 control depth is unchanged.
The copy loop maps N to L=2N and X=N, after which the existing restoration
loop gives N+1. Theorem2 with residue0 proves completeness.

The exact original S-first transfer source and table can be recovered by
inverting `mp-first-transfer/machine/recipe.json`. Its source transformation
swaps the two closed subtrees at111 and110101, hence is its own inverse.
The eight table edits have explicit old and new actions. The recovered
parent bytes have the published SHA-256 values

    transfer201.sites.json:
      05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922
    transfer215.native.tm:
      1f8194fa49a638857ecf5b4f69b1ae92cb47d11d1a74e952bbb91049c893a836

The analogous parent variants are `sites_original_transfer_step2.json`
and `sites_original_transfer_even_copy.json`, with the same202/4776/44/6
source metrics. Matching predecessor hashes is provenance evidence, not
a replacement for checking a new allocated binary table.
