# Fairness of the original scratch-biased 215-state scheduler

## Status, provenance, and exact object

This note proves the missing completeness/fairness property of the already
physically verified `scratch-biased` experiment in the archived
`T215_Transfer_2026-10-20/research/short-transfer` package. It does not change a
source primitive or transition row. The archived source SHA-256 is
`2407f815551b4aba335c9bf041e15e8ce3cfb9ad830d89539f3bcf123462371a`.
The native table SHA-256 is
`f08bed9e62b9f43237b65c465d2f1bfc17474637b4b02785ca7f1813827bb0ce`.
The source has 201 distinct subtrees and 4,733 primitive occurrences; the
table has 215 working states. Its all-natural primitive runtime certificate
and 69,744-transition blank startup were already supplied by the archive.
Those facts and the short transfer command are inherited, not new claims.

The new result here is an all-natural fairness theorem for its actual
state-dependent candidate sequence, with an explicit compatible word encoder.
It uses synchronization of a four-state scanning automaton and a choice of
two harmless prefix words. Ordinary arithmetic-progression cofinality alone
does not prove this theorem.

## 1. Exact stateful proof language

Let

    T(s)=s(s+1)/2,     P(a,b)=T(a+b)+b,

and let f(n) be the right component of the Cantor inverse. In a diagonal
n=T(s)+y, 0<=y<=s, the left component is x=s-y and f(n)=y.

Commands have fields S:[0], MP(x):[1,x], AX(c;x,y):[c+2,y,x]. The inherited
work-tuple meanings are unchanged: S is the short single-cache-test transfer,
and MP and AX are the inherited theorem-producing operations. After S,
scratch X=0; after MP or AX, X=1. At a positive residual L, the next first
field is read from L-1+X. At an empty residual, the counter is increased by
1+X before the new candidate is executed, and that fresh candidate is read
without bias.

For a fresh candidate n, write W(n) for its finite syntactic command word,
ignoring a possible semantic halt. If unpair(n)=(x,y), then

* x=0: W(n)=S if y=0, and W(n)=S;W(y-1) if y>0;
* x=1: read unpair(y)=(a,r), then W(n)=MP(a), followed by W(r) if r>0;
* x>=2: read unpair(y)=(b,z) and unpair(z)=(a,r), then
  W(n)=AX(x-2;a,b), followed by W(r) if r>0.

Every recursive argument is strictly smaller than n. This proves termination
of each syntactic candidate by induction. In particular W(0)=S.

Let e(n) be 0 if the last command of W(n) is S, and 1 otherwise. Introduce
the auxiliary sequence u(0)=1 and u(n)=e(n) for n>0. Then

    g(n)=u(f(n)),       h(n)=u(f(f(n))).

The exact terminal-type labels in diagonal s>=2 are

    h(0), h(1), ..., h(s-2), g(s-1), e(s-1).

The final two labels belong to the MP and S candidates. The auxiliary value
u(0)=1 expresses the fact that a zero residual ends MP/AX rather than
executing a fresh S.

### Explicit compatible encoder

Given a positive code R for a nonempty suffix, define

    S[R]       = P(0,R+1),
    M_x[R]     = P(1,P(x,R)),
    A_c,x,y[R] = P(c+2,P(y,P(x,R))).

These encode exactly S, MP(x), or AX(c;x,y), followed by that suffix. The
extra successor appears only after S. To encode an arbitrary finite
semantically halting word, append a dummy MP(0) after its halt. The dummy's
fresh code is 1. Encode backwards using the three formulas. Every suffix
code is positive, so no intended suffix is mistaken for an empty residual.
The dummy is never reached on the intended halting execution.

## 2. The actual candidate schedule as a four-state scanner

The exact blank startup completes a partial AX, so its first fresh candidate
is 1, with a counter step of 2 already scheduled. More generally, if the
current fresh candidate is n and its already determined step is d in{1,2},
then its successor state, conditional on no earlier halt, is

    (n,d) -> (n+d,1+e(n)).

The lag matters: e(n) determines the step after the next candidate, not the
step just taken from n.

Scan integers in increasing order using four states V0,V1,K0,K1. V means
the current integer is visited; K means it is skipped. The bit records the
step to be used at the next visit (step1 for bit0 and step2 for bit1).
Reading the terminal type a=e(n) applies the transition t_a:

| Incoming state | State after reading a |
|---|---|
| V0 | V_a |
| V1 | K_a |
| K0 | V0 |
| K1 | V1 |

The physical schedule starts in state V1 at integer1. A direct induction
on the four cases proves that this scanner marks exactly its visited
candidates. In particular t_a sends both K states to V states, independently
of a.

The five-letter word 11011 synchronizes all four states to V1. This is a
finite identity of the displayed transition functions and can be checked
by four five-step substitutions.

## 3. Three synchronized auxiliary scanners

For a binary sequence a, let Scan_a(n) be the state before reading a(n),
after reading positions0 through n-1 from initial state V0. Define

    E(n)=Scan_u(n),   G(n)=Scan_g(n),   H(n)=Scan_h(n).

The following occurrences of 11011 are literal small arithmetic facts:

* u at indices0 through4;
* g at indices3 through7;
* h at indices18 through22;
* e at indices7 through11 (an additional, unused synchronization fact).

Thus the corresponding prefix products lose all dependence on their input
state at lengths5,8,23, and12, respectively. In fact the actual schedule's
scanner state equals E(n) for every n>=1: the canonical E scanner starts
with V0 at0 and u(0)=1, hence E(1)=V1, exactly the actual initial state.
All later labels agree because u(n)=e(n) for n>=1.

### Diagonal lifting lemma

The following identities hold for all natural a,b satisfying the indicated
bounds:

    G(P(a,b)) = E(b)                 if b>=5,
    H(P(a,b)) = G(b)                 if b>=8,
    E(P(a,b)) = H(b)                 if a>=2 and b>=23.

For the first identity, the part of the g diagonal preceding P(a,b) is
exactly u(0),...,u(b-1). Because b>=5, this prefix synchronizes and gives
the same state as the canonical E scanner, whatever state entered the
diagonal. The second identity is the same argument using the g prefix and
its length8 synchronization. In the third identity, P(a,b) is an AX position;
all preceding positions in its diagonal are AX positions and their labels
are h(0),...,h(b-1). The length23 synchronization gives H(b). All relevant
global indices are positive, so the canonical E scanner is the actual one.

This proof does not bound any candidate code or source register. The fixed
constants5,8,23 refer only to synchronization words.

## 4. A prefix that forces a visited successful code

Fix R>=23. First, for every x>=0,

    E(M_x[R]) = G(R).

Indeed M_x[R]=P(1,P(x,R)) is an MP position. Its preceding AX prefix has
length P(x,R)>=23, so its scanner state is H(P(x,R))=G(R).

Applying this identity twice, with the inner MP parameter equal to2, gives

    E(M_0[M_2[R]]) = G(M_2[R])
                   = E(P(2,R))
                   = H(R).

The middle identity is the first diagonal lifting formula, and the last
uses the fact that left component2 is an AX position. All side conditions
follow from R>=23.

For a single S prefix, S[R]=P(0,R+1). This is the last position of diagonal
R+1. Before it, there are R AX positions with labels h(0),...,h(R-1),
followed by the MP position with label g(R). Consequently

    E(S[R]) = t_g(R)(H(R)).

We can therefore choose a visited prefix by inspecting only H(R):

* If H(R) is V0 or V1, use M_0[M_2[R]].
* If H(R) is K0 or K1, use S[R].

In the second case the transition from either K state is always a V state.
Hence at least one of these two explicitly encoded prefix words is a
candidate that the actual adaptive schedule visits.

This statement holds for every R>=23, independently of its semantic
meaning. It is the step that an arithmetic-progression argument cannot
supply.

## 5. Cofinal padding preserves the visited state

For every R>=23 and c,x,y>=0, three applications of diagonal lifting give

    E(A_c,x,y[R])
      = H(P(y,P(x,R)))
      = G(P(x,R))
      = E(R).

In particular A_c,0,0[R] has exactly the same visited/skipped scanner state
as R, and its value tends to infinity with c. The lower bounds on intermediate
right components follow from P(a,b)>=b.

Combining Sections4 and5 yields the fairness theorem:

> For every positive suffix code R>=23, there are cofinally many visited
> candidate codes whose decoded word contains W(R) as a suffix, preceded
> either by AX;S or by AX;MP(0);MP(2).

The AX parameters in this theorem vary with c; their actual values are
unrestricted natural numbers. The theorem is constructive: compute H(R),
choose one of the two prefixes, and then vary c in the outer AX padding.

## 6. Applying fairness to refutations

The inherited strong command compiler supplies a finite word that, from
any work tuple with counter and cache zero, derives native falsity and
halts, or halts earlier. Prefix one AX to reset the counter/cache from
an arbitrary retained tuple, and append the dummy MP(0) used by the encoder.
Choose a sufficiently large first AX tag if necessary to make its code
R>=23. This word halts from every input work tuple: any earlier halt is
already success, and otherwise the reset establishes the compiler's exact
premise. No theoremhood of an arbitrary intervening top or stack is needed
for this completeness argument.

Prepending S or two MP commands cannot defeat such a universally successful
suffix: either the prefix itself halts, or it reaches the suffix in some
work tuple. The additional AX padding has the same property. The fairness
theorem therefore gives cofinally many actual visited candidates that halt
whenever a finite native refutation exists. Each nonhalting candidate is
finite, and the candidate counter increases by1 or2, so the physical run
must reach one of them unless it already halted.

This proves completeness for the exact archived scratch-biased scheduler.

## 7. Soundness from the exact seed

The archive's abstract bridge begins at AX entry with register tuple

    (N,T,W,A,D,H,X,Y,L)=(1,0,3,0,0,0,0,0,0).

This seed already has a fully theorem-safe stack. Indeed

    3=P(2,0),    2=Q_0(0).

Native truth0 is a theorem, and the native GEN rule derives Q_0(0)=2 from
it. Decoding stack3 therefore yields the theorem2 followed by tail0; every
subsequent head of tail0 is native truth0. The top and cache are also0.
Consequently the ordinary theorem/Good-stack invariant holds at the start
of the synthetic AX bridge and continues through its completion.

Every complete short S, MP, and AX is sound from that invariant, regardless
of the sequence of commands selected by the biased parser. The halt in S
tests a theorem-valued cache for native falsity1. Hence every actual halt
supplies a native refutation. No protected-tail credit estimate is needed
for this particular numerical seed. The stronger arbitrary-tail result in
`alternative_research/adaptive_credit_proof.md` is useful additional research,
but is not a dependency of this calibration.

The fairness theorem, this exact-seed soundness argument, the inherited
numerical-calculus/ZFC calibration, and the archived universal runtime and
blank-prefix certificates together imply that this exact215-state binary
table is nonhalting iff Con(ZFC), in ordinary arithmetic reasoning
formalizable in ZFC. A proof-assistant kernel formalization is not claimed.

## 8. Reproducible finite checks

Run the standard-library-only checker as follows:

    python scratch_biased_fairness_check.py --out a_fresh_result.json

The frozen `scratch_biased_fairness_result.json` records direct expansion of
all labels and scanner states through integer500,500 inclusive, agreement
with274,976 direct candidate visits, 1,463,838 diagonal-lift checks, and
1,498,500 comparisons against an independently structured recursive scanner
evaluator. It also checks500 positive-code word roundtrips and292 much larger
suffix cases, covering all four possible H states. The largest padded
witness uses30,594 bits. These finite checks support the exact identities;
the preceding induction and synchronization argument supplies their
all-natural proof.
