# A common scratch increment and a successor-free proof language

## Construction and exact source scope

The pinned S-first transfer source has 201 distinct DAG nodes and 4,775
primitive occurrences. Its 78-occurrence transfer body at address `111` is
`(DROP;NIP);NIP`. Replace this body by

`CLEAR(T);COPY(H,T);NIP`,

where the clear has 2 occurrences, the copy has 7, and the inherited NIP has
26. Both associations of these three closed blocks have 201 DAG nodes and
4,732 occurrences. Finally prefix the entire source by the primitive `CI6`,
an increment of scratch X. The complete new source has **202 DAG nodes**,
**4,733 primitive occurrences**, maximum depth 45 and maximum zero run 6.
These are source counts, not binary state counts.

The builder emits both associations and both prefix/postlude cyclic
presentations. All four have the stated counts. Each is checked by both
independent complete source-CFG resolvers. In the shorter parent source there
are exactly two guarded edges to the command root: the common CB1 after AX/MP,
and the zero exit of the final CD6 in NIP. The new prefix presentation changes
exactly these two edges to enter the single CI6, which then enters the old
root. All other edges are identical after shifting old ordinals by one.

The prefix presentation is the primary mathematical version below. A physical
table and its complete blank-start proof remain separate obligations. The
current fixed-role allocator has not supplied a 215-state physical realization.

## 1. The 35-occurrence transfer contract

Assume scratch X=Y=0. The clear block is literally `(CD1,CC1)`, which repeatedly
decrements T until it is zero. The copy block is inherited unchanged from
DROP:

`((CD5,(CI1,(CI6,CC3))),(CD6,(CI5,CC2)))`.

Its first loop transfers the old H into T and X; its second loop transfers X
back into H. It therefore establishes `T=H_old`, restores H, and clears X.
Y, the formula stack, the additive counter, and scheduler registers are
unchanged. This argument is by ordinary unary-loop induction for every
natural input, not by a numerical test bound.

The inherited NIP halts if its incoming cache H is 1; otherwise it pops the
encoded formula stack into H and leaves T unchanged. Therefore the new
35-occurrence transfer is exactly the original single-guard Source-166 S:

* If incoming H=1, halt.
* Otherwise, with `unpair(W)=(x,v)`, return `(T,W,D,H)=(H_old,v,D_old,x)`.

Its nonhalting exits have X=Y=0. Unlike the 78-occurrence composite S, it does
not test the incoming T for equality to 1. This is intentional: the original
Source-166 strong compiler is already proved for precisely the single-guard
command. Its soundness uses theoremhood of H, and its completeness macros are
unchanged. No theorem-equivalence claim between the two guard sets is needed.

The retained AX and MP contracts also return X=Y=0. Thus the single common
CI6 makes X=1 immediately before every execution of the inherited main reader.

## 2. A shifted Cantor-unpairing lemma

Consider the inherited unpairing loop with remaining input L, scratch X,
and scratch Y initially zero. At each iteration it consumes one unit of L.
If X was positive, it replaces `(X,Y)` by `(X-1,Y+1)`. If X was zero, it
replaces `(0,Y)` by `(Y+1,0)` using the finite inner transfer loop.

Both changes increase `P(X,Y)` by exactly one:

`P(X-1,Y+1)=P(X,Y)+1` for X>0,

`P(Y+1,0)=P(0,Y)+1` for X=0.

After n iterations, therefore, `P(X,Y)=n+P(X_initial,0)`. In particular,
starting with X=1 computes the exact unpairing of `n+1`. The subsequent
inherited transfer places the right component into L, and the tag transfer
clears the left-component scratch into the command selector. All loops
terminate by unary descent.

At a positive proof pointer p, the main root first decrements p. Starting
the reader with X=1 consequently decodes `unpair(p)`, since
`(p-1)+P(1,0)=p`. Subsequent command fields still use the ordinary X=0 reader.
Thus the new within-candidate command language has **no outer successor**.

At an empty pointer, the refill starts with X=1, copies the stored candidate
N into both L and X, and restores N from X with the inherited extra increment.
Consequently it sets `L=N_old`, `N=N_old+2`, and `X=0`. The first field is the
ordinary unpairing of `N_old`. Every later refill repeats the same operation.
Hence the exact fetched candidates form a fixed arithmetic progression of
stride two. This uniform invariant is what the earlier state-dependent
scratch-biased variant lacked.

## 3. Successor-free wire compiler

Keep the original fields

`S:[0]`, `MP(x):[1,x]`, `AX(c;x,y):[c+2,y,x]`.

For field list fs and tail r, write F(fs,r) for right-nested Cantor pairing.
Define a new command-word code by

`C(empty)=0`,

`C(k::word)=F(fields(k),C(word))`.

There is no added successor at a command boundary. To avoid a terminal
zero-coded S, append a dummy `MP(0)` after the successful refutation word
from the inherited compiler. This appended command is never needed for
success, since the preceding refutation word already halts. Its code is
positive, and every preceding nonempty suffix therefore has positive code.
The uniform main reader consequently decodes the entire prescribed word
exactly, with no premature empty-list refill.

Let R be this positive successful suffix code. A first command
`AX(c;0,0)` followed by the suffix has candidate code

`n=P(c+2,P(0,P(0,R)))`.

The AX resets additive counter and cache, so the strong refutation compiler
applies from every retained top/stack pair. Varying c supplies cofinally many
such successful n in either parity: if `B=P(0,P(0,R))`, then
`n=T(c+2+B)+B`, and triangular values attain both parities periodically.
The separately written dyadic-padding lemma proves this in full detail.
Therefore either positive parity progression eventually reaches a successful
candidate if a native refutation exists, unless a sound halt occurred earlier.

## 4. Soundness and protected credit

For positive n, let W(n) be the command word parsed from n, and set W(0) to
the empty continuation. For a Cantor diagonal n=T(s)+y, the recurrences are

`W(n)=S;W(y)` if the tag is zero,

`W(n)=MP;W(f(y))` if the tag is one,

`W(n)=AX;W(f(f(y)))` if the tag is at least two.

Every positive right-projection continuation is strictly smaller than n, so
these words terminate. The same parity-pullback induction as in the main
parity-credit proof applies with `g=b` and `q=b+1`. The base is

`W(0)=empty`, `W(1)=MP`, `W(2)=S;MP`.

Each selected parity part of every Cantor diagonal s>=2 is prefix-safe.
The global even and odd conservative credits are respectively 1 and 0.
In particular, an odd schedule beginning at N=1 requires no protected heads
above an arbitrary tail, provided top and cache are theorems. An even schedule
beginning at N=4 also requires zero credit. The abstract W(0)=empty convention
is only for continuations: an actual freshly fetched candidate zero would
execute S, so no claim about a zero-start physical seed follows from it.

With these credits, the existing theorem-head wrapper invariant guarantees
that no unsafe tail head is loaded into top/cache. The short S, AX, and MP
preserve theoremhood, and every halt proves native falsity. The original
numerical-calculus calibration then gives the usual Con(ZFC) equivalence for
any correctly initialized physical implementation of this source.

## 5. Scope and remaining obligation

The source transformation, exact full CFG, original S contract, shifted reader,
fixed-stride enumeration, successor-free strong compiler, cofinality, and
protected-tail theorem are mathematical source-level results. None by itself
counts as a new binary consistency machine. A complete physical allocation,
all-natural source-to-TM runtime proof, and literal blank prefix reaching the
required source invariant are still required before asserting a 215- or
214-state construction.
