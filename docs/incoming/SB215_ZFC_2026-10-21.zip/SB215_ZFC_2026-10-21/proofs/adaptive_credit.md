# Protected-tail credit for the scratch-biased short-transfer machine

## Result and scope

The physically verified `scratch-biased` short-transfer source in the
accepted MP-first-transfer research archive leaves scratch X=0 after S and
X=1 after MP or AX. Its candidate counter advances by one or two, depending
on this scratch bit. This note proves its previously open protected-tail
soundness obligation. The proof covers a larger class: **every increasing
candidate schedule with successive gaps at most two**.

For its exact mixed parser, every such schedule starting at candidate 0 or 1
requires at most four protected theorem heads. The actual blank-start schedule
requires **zero** additional heads: its first candidates are 1,3,5,7, and all
later complete selected Cantor diagonals are safe. The physical startup
already supplies ten protected heads, so it retains at least ten at every
subsequent command boundary in the conservative accounting used here.

This proves soundness for arbitrary protected tails; cofinal
successful-candidate visitation is a separate obligation. The ordinary
command compiler and the physical runtime/bootstrap certificates remain
inherited dependencies. No unconditional nonhalting claim is made by this
note alone.

For the actual physical seed an even shorter soundness argument is available.
Its tail is 3, and P(2,0)=3. The decoded first head 2 is Q_0(0), which is a
native theorem by theorem-only generalization of truth 0. Every later decoded
head is 0, since unpair(0)=(0,0). Thus the complete stack encoded by 3 is
already theorem-safe. Ordinary command soundness alone handles that exact
seed; the stronger gap-two credit theorem below is not required to make its
arbitrary tail safe. It remains useful for other initializations and gives
an independent conservative bound.

The exact parent is the archived `T215_Transfer_2026-10-20` packet, directory
`research/short-transfer/candidates/scratch-biased/`. Its README records a
215-state physical table, 6,152 quantified primitive cases, 1,617,669 symbolic
rules, and a complete 69,744-transition blank prefix matching a 172-step
synthetic partial AX execution. Those counts are identified inherited facts,
not replaced by the finite abstract check supplied here.

## 1. Exact mixed parser and candidate schedule

Write P(a,b)=T(a+b)+b, where T(s)=s(s+1)/2, and let f be the right projection
of Cantor unpairing. Let W(n) denote the command word of a freshly fetched
candidate n, ignoring possible semantic halts. At n=T(s)+y, 0<=y<=s, the tag
is s-y. Put V(0)=empty and V(r)=W(r) for r>0. Then

    W(T(s)+y) = S ; (empty if y=0, otherwise W(y-1)),  when s-y=0;
                 MP ; V(f(y)),                       when s-y=1;
                 AX ; V(f(f(y))),                    when s-y>=2.

The asymmetry is essential. After S, the next positive residual is decremented
before unpairing and scratch is zero. After MP/AX, scratch is one, so the
decrement and biased unpairing cancel. Later command fields are ordinary
unpairings. A newly fetched candidate is decoded without this bias.

Every nonempty recursive suffix has index strictly smaller than n. Thus W(n)
is finite and has at most n+1 commands, including W(0)=S. Every prefix of W(r)
therefore has conservative balance at least -(r+1).

Let epsilon(n) be zero if the final command in W(n) is S, and one otherwise.
At each fetch the next-candidate counter was already advanced by the previous
fetch. Consequently the exact scheduler has a one-candidate lag:

    (n,d) -> (n+d, 1+epsilon(n)),     d in {1,2}.

The partial startup AX ends with N=1 and scratch one, hence the first state is
(n,d)=(1,2). All fresh candidates are strictly increasing, with gaps one or
two. The credit theorem below deliberately uses only this gap property.

## 2. Conservative balances

Assign S balance -1, MP balance zero, and AX balance +10. A successful MP's
additional truth head is ignored; that can only make the estimate more
conservative. Write b(n) for the total balance of W(n), and put

    u(0)=0,     u(r)=b(r) for r>0,     q(r)=u(r)+2.

The AX candidates in diagonal s have positions 0<=y<=s-2 and total balances
10+u(f(f(y))). The final MP candidate has total u(f(s-1)); the final S has
total -1+b(s-1), for s>=1.

A finite *gap-two prefix* means an increasing list whose first index is 0 or
1 and whose successive differences belong to {1,2}. The empty list is also
allowed. Its final index is unrestricted. The same definition is used for
positions within a diagonal.

## 3. Gap-two pullback lemma

**Lemma.** If q has nonnegative sum on every gap-two prefix, then q composed
with f has the same property, as does q composed with f composed with f.

**Proof.** In increasing argument order, f lists the blocks

    [0], [0,1], [0,1,2], [0,1,2,3], ... .

Restrict any gap-two prefix of input indices to one of these blocks. Its
nonempty selected local positions begin at 0 or 1 and have successive gaps
one or two. A later first position would leave two consecutive omitted input
indices at the block boundary, contradicting the gap bound. Thus the selected
values in each block form a gap-two prefix of q. Every completed selected
block and the final selected partial block have nonnegative sum. Add these
inequalities, then apply the same lemma a second time. Only the finitely many
q-prefix conditions needed for the chosen input bound enter the argument.

This is stronger than the parity pullback lemma: the selected parity may
change arbitrarily whenever a gap of one occurs.

## 4. Joint diagonal induction

We prove simultaneously:

1. Every command prefix obtained by concatenating W(n) along any gap-two
   prefix of candidate indices has balance at least -4.
2. Every gap-two prefix sum of q is nonnegative.
3. For each complete Cantor diagonal s>=3, every gap-two selected prefix of
   that diagonal has nonnegative balance at **every command prefix** relative
   to the start of that selected diagonal.

### Base

The exact words for candidates 0 through 5 are

    S, MP, SS, AX, MP, S MP.

There are only four S commands in their entire concatenation, so every
selected command prefix has balance at least -4. The bound is attained by
the gap-two selection 0,2,4,5. For any selection of k>=2 candidates, its q sum
equals its b sum plus 2k, and additionally plus one if candidate 0 is selected,
because u(0)=b(0)+1. Hence this q sum is at least -4+2k>=0. A one-term
gap-two prefix selects 0 or 1, and q(0)=q(1)=2. This establishes assertions
1 and 2 through diagonal 2.

Diagonal 3 contains the words

    AX, AX, MP MP, SSS.

Every nonempty selected prefix begins with one of the first two AX words.
Thereafter its only negative contribution is at most three S commands, so
it is safe. Diagonal 4 contains

    AX, AX, AX, MP, S AX.

Again its first selected word is AX, and its only later negative contribution
is one S. This proves assertion 3 for these two diagonals and preserves the
first two assertions by the same q-sum calculation.

### Induction step, s>=5

Fix a gap-two selection of positions within diagonal s. Suppose k selected
AX words have completed. By the double pullback lemma, their total balance is

    10k + sum u(f(f(y)))
       = 8k + sum q(f(f(y))) >= 8k.

The selection of these AX positions starts at 0 or 1 and has gaps at most two,
as required. All q arguments used lie at most s-2<T(s), in earlier diagonals,
so the induction is well founded.

If another selected AX begins at position y, then y<=2k+1. Its empty prefix
has the already proved balance at least 8k. After its initial AX, every
remaining command prefix has balance at least

    8k + 10 - (f(f(y))+1)
      >= 8k + 10 - (y+1)
      >= 6k + 8 > 0.

This uses the finite-word length bound from Section 1 and also covers the
empty direct continuation at zero. Thus all selected AX prefixes are safe.

Only the final MP at y=s-1 and S at y=s remain. If either is selected, the
gap condition implies k>=floor((s-1)/2). Every prefix of the MP word loses at
most s, since its suffix index is f(s-1)<=s-1. Every prefix of the S word
loses at most s+1. Even allowing both worst losses together gives the lower
bound

    8 floor((s-1)/2) - 2s - 1.

For s=2d>=6 this is 4d-9>=3; for s=2d+1>=5 it is 4d-3>=5. Consequently every
remaining selected prefix is safe, including when only one final word occurs.
This proves assertion 3.

An arbitrary global gap-two prefix decomposes into the finite base and safe
selected diagonal pieces: at each crossed boundary its next selected local
position is again 0 or 1. Its global balance therefore remains at least -4,
which proves assertion 1 at the new bound. To recover assertion 2, a q sum
with k>=2 terms is at least -4+2k>=0, with the same harmless correction at
zero. For k=1 use q(0)=q(1)=2. This closes the induction for all natural s.

The universal credit four is exact in this larger schedule class, attained
by 0,2,4,5. It is not claimed to be necessary for the actual adaptive run.

## 5. Actual blank-start schedule requires zero credit

The first fresh candidate is 1 and the pending step is 2. Its word is MP and
its terminal scratch bit is one. Candidate 3 is therefore next; its word is
AX and its terminal bit is one. Candidate 5 is next; its word is S MP and its
terminal bit is again one. Candidate 7 is next.

The finite initial concatenation W(1);W(3);W(5) has weights

    0, +10, -1, 0.

Its minimum prefix balance is zero and its total is nine. Candidate 7 lies
at local position one in diagonal 3. From there on, every selected diagonal
piece is one of the safe pieces established above, because the actual gaps
are always one or two. The entire actual command stream consequently has
minimum prefix balance zero. If a semantic halt occurs earlier, there is no
need to continue the syntactic schedule.

## 6. Protected-tail interpretation and soundness

Track an explicit finite list of theorem heads above the original arbitrary
tail. AX pushes ten theorem heads; S removes exactly one; MP preserves this
list or pushes theorem zero. Top and cache are native theorems initially and
remain so. Since the actual conservative balance never drops below zero, the
ten heads supplied by the startup AX never run out. Just before any S, there
is at least one protected head available, so S never exposes the arbitrary
tail to top or cache.

This is a wrapper invariant rather than an inference of list length from
its natural-number encoding. In particular, P(0,0)=0 is harmless:
unpair(P(a,w))=(a,w) remains exact. Every possible S halt tests a theorem code
equal to falsity 1, and therefore certifies an ordinary native refutation.

The source-level soundness gap in the old scratch-biased experiment is thus
closed for arbitrary natural tail values, including its actual tail 3.
Combining this result with a separate completeness/fairness theorem and the
already identified exact physical certificates supplies the desired full
calibration; soundness alone is not that equivalence.

## 7. Finite reproducibility check

Run

    python3 adaptive_credit.py --diagonals 1000 --out adaptive_credit_result.json

The independent standard-library program checks 500,500 candidate words,
all 997 safe complete diagonals from s=3 onward, the q and two pullback
conditions, and the universal credit four by exact dynamic programming over
all gap-one/two selections in the checked range. It independently expands
1,000 command words and follows 274,975 actual adaptive candidates, obtaining
actual credit zero. These finite results corroborate the formulas; the
unbounded conclusion follows from the induction in Sections 3-5.
