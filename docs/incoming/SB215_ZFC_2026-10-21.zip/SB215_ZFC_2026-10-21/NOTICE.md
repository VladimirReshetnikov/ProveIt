# Attribution, provenance, and license

Prepared on 21 October 2026 for Vladimir Reshetnikov's ProveIt project by a
ChatGPT-assisted research collaboration, with separate construction,
mathematical review, physical verification, and provenance-audit work.

## Present contribution

This packet proves the previously missing fairness theorem for the archived
scratch-biased 215-state proof search. The proof uses a four-state scanner,
the synchronizing word `11011`, Cantor-diagonal lifting, a visited-prefix
choice, and a compatible stateful proof-word encoder. It also identifies
the exact `Good(3)` initialization argument, proves a stronger optional
gap-one/two credit theorem, constructs the new SB215-AB composition, and
supplies fresh binary replays, independent audits, reproducibility tools,
and the accompanying report.

The original SB215 source and table are unchanged inherited bytes. Their
new contribution is completed logical calibration. SB215-AB composes those
bytes with the already known rho6(A,B) sampler through two literal row
changes. Neither that sampler nor the short transfer macro is newly invented
here. No 214-state construction or new proof-assistant kernel endpoint is
claimed.

## Inherited work

The immediate physical source is the `scratch-biased` experiment in the
`T215_Transfer_2026-10-20/research/short-transfer` archive. Its source,
reconstruction, runtime framework, earlier certificates, and historical
README are preserved under `reference/scratch-prototype/`. Its earlier
**OPEN** labels describe that packet's proof status and have intentionally
not been edited. The new fairness and soundness arguments are separate.

The numerical calculus, gated set-theory bundle, comparison with ZFC
consistency, all-natural macro library, transfer language, strong compiler,
binary architecture, and symbolic runtime-induction engine are inherited
from ProveIt and the referenced predecessor packets. The known rho6 sampler
comes from Source 163 and existing secondary K215 work. Source 165 already
recorded the independent row-permutation census and paired rho4/rho2 minima
rediscovered during this investigation; their discovery is not claimed here.

The retained notices credit Elliot Glazer, Mira, Jeff's busy-beaver
development, Andrew James Wade, BusyCoq, the Coq Library of Undecidability,
and ProveIt's accumulated contributions, within their original stated
scopes. Those notices remain authoritative for inherited authorship. See
`reference/transfer-archive-NOTICE.md`,
`reference/transfer-parent/provenance/`, and the retained license files.
Historical notices may refer to their original packet layout.

The current repository audit is pinned to
`29e2cc4c557c04d3358e41e566bd7c582844ff4e`. Input and archive pins, including
the scoped table-comparison corpus, are recorded with the evidence. A finite
corpus comparison is not presented as universal historical novelty.

## License

New code and text in this packet are supplied for the ProveIt project under
the **MIT No Attribution** terms in `licenses/LICENSE.ProveIt`. Existing
third-party material retains its own applicable terms and attribution;
this notice does not relicense it or reassign inherited authorship. The
original notices and licenses have been retained in `licenses/` and the
reference material.
