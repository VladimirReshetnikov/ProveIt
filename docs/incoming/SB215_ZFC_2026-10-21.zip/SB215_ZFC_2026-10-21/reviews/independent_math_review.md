# Independent mathematical review: scratch-biased 215-state calibration

## Verdict

The all-natural fairness argument in
`proofs/fairness.md` passes independent review. Paths in this review are
relative to the packet root unless stated otherwise.
Together with ordinary native-command soundness from the exact seed and the
identified inherited physical certificates, it supplies the missing logical
calibration of the archived scratch-biased 215-state machine.

The machine bytes are inherited from the explicitly open experiment in
`T215_Transfer_2026-10-20/research/short-transfer/candidates/scratch-biased/`:

* source SHA-256:
  `2407f815551b4aba335c9bf041e15e8ce3cfb9ad830d89539f3bcf123462371a`;
* native table SHA-256:
  `f08bed9e62b9f43237b65c465d2f1bfc17474637b4b02785ca7f1813827bb0ce`.

The new contribution is the proof closing its previously stated scheduler
obligation. The construction must not be described as newly discovered table
bytes, a new short-transfer macro, or a 214-state result.

## Exact seed soundness

The archived blank-prefix certificate matches a partial AX execution from
top 0, cache 0, additive counter 0, and stack 3. In the exact numerical coding,

    P(2,0)=3,       Q_0(0)=4P(0,0)+2=2,       P(0,0)=0.

Truth 0 is a native theorem. Theorem-only generalization at binder 0 therefore
proves 2. The stack 3 decodes first to head 2 and tail 0, and thereafter to
head 0 and tail 0 forever. Every decoded head is consequently a theorem.
There is no zero-code, alias, or partial-decoding caveat: the argument uses
literal pairing identities and the native unrestricted numerical GEN rule.

The retained short S, MP, and AX equations preserve the condition that top,
cache, and all decoded stack heads are theorems. The scratch bias changes
only which finite commands are read, not those equations. An S halt tests
native falsity 1. This establishes soundness from the actual seed directly.
It avoids making the stronger arbitrary-tail credit theorem a necessary
dependency of the primary calibration.

An independent stronger result is nevertheless available in
`proofs/adaptive_credit.md`: for the same mixed parser, every candidate
schedule beginning at 0 or 1 with gaps one or two has conservative credit at
most four; the actual schedule has credit zero. Its joint diagonal induction
and generalized pullback lemma support alternative arbitrary-tail seeds.

## Fairness review

The following potentially delicate points were checked individually.

1. **One-step lag.** A candidate's final scratch bit chooses the advance made
   at the next fetch, so the exact recurrence is
   `(n,d)->(n+d,1+e(n))`, not `(n,1+e(n))`. The four scanner states correctly
   retain the pending step across a skipped integer.

2. **Zero continuation.** The auxiliary type u(0)=1 is required: zero ends an
   MP/AX word, whereas a freshly fetched zero is the S word. Keeping e(0)=0
   while setting u(0)=1 handles this distinction consistently in both the
   language and the scanner identities.

3. **Synchronization.** The word 11011 sends each of V0,V1,K0,K1 to V1.
   Its stated occurrences in u, g, h and e are exact finite identities.
   Synchronization of e at positions 7 through 11 independently proves
   equality of the actual and canonical scanners from index 12. The final
   proof sharpens this to equality from index 1: u(0)=1 sends V0 to V1,
   which is precisely the actual initial state, and u(n)=e(n) for n>0.

4. **Diagonal lifting.** The G and H identities use whole Cantor prefix
   blocks; the E identity is used only at AX positions with left component
   at least two. The right-component bounds 5, 8 and 23 cover the complete
   synchronizing prefixes. All intermediate arguments in the composed
   identities meet these bounds when the suffix code R is at least 23.

5. **The MP position.** The identity `E(M_x[R])=G(R)` is valid even though
   its outer left component is one: its preceding positions are all AX
   positions and form exactly the synchronized h-prefix. It is not an
   invalid direct application of the AX-only E lifting formula.

6. **Visited-prefix choice.** The state before `MP(0);MP(2);W(R)` equals
   H(R). The state before `S;W(R)` is `t_g(R)(H(R))`. If H(R) is skipped,
   either transition sends it to a visited state. Thus one of those two
   prefixes always gives a visited candidate, without an unproved density
   or parity assumption.

7. **Cofinal padding.** An outer AX prefix preserves E(R) by three valid
   diagonal lifts. Varying its free tag makes the candidate codes unbounded.
   Cofinality therefore applies to actual visited integers, not merely to
   an externally chosen arithmetic progression.

8. **Wire encoding.** The extra successor belongs only to a suffix following
   S. Appending a dummy MP(0) after the intended halt gives positive codes to
   all nonempty suffixes, so the MP/AX direct continuation never mistakes a
   nonempty suffix for the end marker zero.

9. **Semantic wrappers.** Prefixing a reset AX to the inherited strong
   refutation block makes the suffix successful from every retained work
   tuple. The optional S or two MP commands therefore cannot defeat it:
   they either halt already or reach that universally successful suffix.
   The additional cofinal AX prefix has the same property.

Each nonhalting candidate terminates because every recursive suffix index
strictly decreases. The candidate counter increases by one or two. Thus the
cofinally visited successful candidates really are eventually executed unless
an earlier halt has already occurred. These statements concern all natural
codes; no tested numerical bound enters the proof.

## Independent finite corroboration

`code/independent_scanner_audit.py` uses the independently written mixed-word
recurrence in `code/adaptive_credit.py`, rather than the fairness proof's own
checker. At 1,000 Cantor diagonals it computes 500,500 terminal types and
checks:

* all four states synchronize under 11011;
* all four literal synchronization intervals;
* exact agreement of the scanner and adaptive candidate recurrence;
* actual/canonical scanner agreement from index 12;
* 495,510 applicable G diagonal identities;
* 492,528 applicable H diagonal identities;
* 475,800 applicable E diagonal identities.

The finite checks passed and their JSON receipt is included. They corroborate
the symbolic formulas; they do not substitute for the reviewed unbounded
argument. Full physical runtime, startup, and canonicalization evidence must
still be bound to the literal source/table hashes in the final candidate
packet. No new proof-assistant kernel endpoint is asserted by this review.

## Scoped novelty-census audit

The root census algorithm was reviewed and its 319 complete 215-state tables
were independently parsed and canonicalized under rooted state renaming and
global tape reflection. All recorded source-byte hashes, reachable-state
counts, canonical hashes, and reflected hashes agreed. The corpus contains
77 distinct byte hashes and 44 distinct rooted graphs. The other 42 `.tm`
files were excluded because they were not complete 215-state tables; no file
was excluded for unsupported table syntax.

All eleven downloaded archive lengths and Git blob SHA-1 pins were separately
recomputed from the ZIP bytes and matched. The SB215-AB table has 215
graph-reachable working states and matches none of the 319 recorded tables,
even after reflection. Its rooted graph SHA-256 under the recorded canonical
serialization is
`92572e2dc203d0aabafd4f864d3e81bc6de8a1299723039c4c4af7c753d312f9`.

This is a scoped comparison against the recorded downloaded corpus, not a
universal historical-novelty theorem or a semantic inequivalence theorem.
The original SB215 prototype is intentionally present in the old corpus;
its new contribution is completed calibration. The accompanying
`reviews/census_independent_review.json` records this audit.
