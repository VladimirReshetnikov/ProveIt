#!/usr/bin/env python3
"""Portable exact-table and mathematical-evidence replay for SB215 and SB215-AB.

Default: reconstruct bytes, verify dense/native equivalence and complete blank
startup, audit the stored universal primitive census, and rerun the finite
fairness/credit checks. --runtime additionally derives every arbitrary-natural
primitive case afresh for both machines and compares each ordered case with
the supplied certificate. The unbounded logical proof is in the report; no
proof-assistant kernel formalization is claimed by this executable checker.

All generated files go to a fresh directory outside this packet. Inherited
reference files and delivered evidence are never modified.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / 'reference' / 'scratch-prototype'
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def read_cases(path):
    return json.loads(gzip.decompress(Path(path).read_bytes()))


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def check_manifest():
    path = ROOT / 'MANIFEST.json'
    if not path.exists():
        return {'status': 'NOT_PRESENT', 'note': 'Manifest is optional during packet construction.'}
    document = read_json(path)
    entries = document['files']
    if isinstance(entries, dict):
        entries = [dict({'path': name}, **({'sha256': item} if isinstance(item, str) else item))
                   for name, item in entries.items()]
    require(isinstance(entries, list), 'Unsupported manifest file list')
    seen = set()
    for item in entries:
        name = item['path']
        relative = Path(name)
        require(not relative.is_absolute() and '..' not in relative.parts and name not in seen,
                'Unsafe or duplicate manifest path')
        seen.add(name)
        target = ROOT / relative
        require(target.is_file(), 'Missing manifest file: ' + name)
        require(sha(target) == item['sha256'], 'Manifest hash mismatch: ' + name)
        if 'bytes' in item:
            require(target.stat().st_size == item['bytes'], 'Manifest size mismatch: ' + name)
    return {'status': 'MANIFEST_HASHES_PASS', 'files': len(entries), 'manifest_sha256': sha(path)}


def run_check(out, name, script, arguments):
    command = [sys.executable, '-B', str(script), *map(str, arguments)]
    log = out / (name + '.log')
    started = time.monotonic()
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    require(result.returncode == 0, name + ' failed; see ' + str(log))
    return {'status': 'PASS', 'script': str(script.relative_to(ROOT)),
            'script_sha256': sha(script), 'log': log.name,
            'seconds': time.monotonic() - started}


def prototype_module():
    path = REFERENCE / 'reproduce.py'
    spec = importlib.util.spec_from_file_location('sb215_prototype_reproduce', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_census(name, prototype, out):
    prefix = 'sb215' if name == 'base' else 'sb215_ab'
    source = ROOT / 'machine' / (prefix + '.sites.json')
    machine = ROOT / 'machine' / (prefix + '.native.tm')
    report_path = ROOT / 'evidence' / ('scratch-biased-runtime.json' if name == 'base' else 'ab-runtime.json')
    cases_path = ROOT / 'evidence' / ('scratch-biased-ordered-cases.json.gz' if name == 'base' else 'ab-ordered-cases.json.gz')
    report = read_json(report_path)
    cases = read_cases(cases_path)
    sites = read_json(source)
    expected = [(i, positive) for i, site in enumerate(sites)
                for positive in ((False, True) if site[1] == 'CD' else (False,))]
    require(len(sites) == 4733 and len(expected) == len(cases) == 6152, 'Primitive census size')
    require([(case['site_index'], case['positive']) for case in cases] == expected,
            'Ordered census does not match all source guards')
    require(report['status'] == 'ALL_NATURAL_RUNTIME_PASS', 'Stored runtime status')
    require(report['source_sha256'] == sha(source), 'Runtime/source hash mismatch')
    require(report.get('table_sha256', report.get('machine_sha256')) == sha(machine),
            'Runtime/table hash mismatch')
    require(report.get('append', report.get('append_value')) == 0, 'Expected zero-valued appended spares')
    require(report['cases'] == len(cases), 'Stored case count')
    for case in cases:
        duration, motion = case['duration'], case['motion']
        require(len(duration) == len(motion) == 13, 'Affine-vector arity')
        require(all(type(value) is int and value >= 0 for value in duration)
                and duration[0] > 0, 'Nonpositive affine duration')
        require(all(type(value) is int for value in motion), 'Malformed motion vector')
        require(sum(case['kinds'].values()) == case['symbolic_steps'], 'Symbolic rule count')
    rule_count = sum(case['symbolic_steps'] for case in cases)
    minimum = min(case['duration'][0] for case in cases)
    require(rule_count == report['symbolic_rules'], 'Total symbolic rules')
    require(minimum == report.get('minimum_duration', report.get('minimum_duration_constant')) == 6,
            'Minimum duration constant')
    table = prototype.legacy_table(machine)
    require(len(table) == 430 and len({q for q, bit in table}) == 215, 'Legacy bijection census')
    covered = {tuple(row) for row in report['covered_rows']}
    require(covered == set(table), 'Stored coverage is not the exact set of all transition rows')
    require(report.get('row_coverage', report.get('covered_row_count')) == 430, 'Coverage count')
    if name == 'ab':
        case_coverage = {tuple(row) for case in cases for row in case['rows']}
        require(case_coverage == covered, 'Per-case row coverage does not match the report')
    require(report['checker_sha256'] == sha(REFERENCE / 'checks' / 'symbolic_runtime.py'),
            'Primitive checker hash')
    if 'helper_sha256' in report:
        require(report['helper_sha256'] == sha(REFERENCE / 'checks' / 'independent_runtime.py'),
                'Primitive helper hash')
    # This is a fresh replay of the finite unary/list block induction schemas,
    # not a rederivation of the 6,152 full cases unless --runtime is requested.
    _, blocks = prototype.S.prove_blocks(table)
    require(json.loads(json.dumps(blocks)) == report['blocks'], 'Fresh block induction mismatch')
    result = {'status': 'STORED_UNIVERSAL_CENSUS_AUDIT_PASS', 'candidate': prefix,
              'source_sha256': sha(source), 'native_sha256': sha(machine),
              'cases': len(cases), 'symbolic_rules': rule_count, 'minimum_duration_constant': minimum,
              'covered_rows': len(covered), 'fresh_block_inductions': len(blocks),
              'ordered_cases_sha256': sha(cases_path), 'report_sha256': sha(report_path),
              'scope': 'All ordered guards and supplied affine certificates audited; full fresh case derivation is optional --runtime.'}
    dump(out / (name + '-census.json'), result)
    return result


def main():
    require(__debug__ and not sys.flags.optimize, 'Run Python with assertions enabled; do not use -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', action='store_true', help='Rederive all 6,152 arbitrary-natural cases for each machine')
    parser.add_argument('--out', type=Path, help='A new output directory outside this packet; default is a fresh temporary directory')
    args = parser.parse_args()
    if args.out is None:
        out = Path(tempfile.mkdtemp(prefix='sb215-replay-'))
    else:
        out = args.out.resolve()
        require(out != ROOT and ROOT not in out.parents, 'Output directory must be outside the immutable packet')
        out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    summary = {'status': 'PENDING', 'output_directory': str(out), 'runtime_requested': args.runtime,
               'python_version': sys.version, 'assertions_enabled': __debug__,
               'verify_sha256': sha(Path(__file__)), 'manifest': check_manifest(), 'checks': {}}
    prototype = prototype_module()
    reconstruction = {'status': 'ARCHIVED_RECONSTRUCTION_AND_BOOTSTRAP_PASS',
                      'candidates': prototype.rebuild(),
                      'rejected_runtime_witnesses': prototype.replay_failures(),
                      'bootstrap': prototype.bootstrap()}
    dump(out / 'prototype-replay.json', reconstruction)
    summary['checks']['prototype'] = reconstruction
    for suffix, file in [('native.tm', 'machine.native.tm'), ('sites.json', 'source.sites.json')]:
        require((ROOT / 'machine' / ('sb215.' + suffix)).read_bytes() ==
                (REFERENCE / 'candidates' / 'scratch-biased' / file).read_bytes(),
                'Control machine/source differs from archived prototype')

    summary['checks']['ab_rebuild'] = run_check(out, 'ab-rebuild', ROOT / 'code' / 'rebuild_ab.py', [
        '--parent-machine', ROOT / 'machine' / 'sb215.native.tm',
        '--parent-source', ROOT / 'machine' / 'sb215.sites.json', '--out', out / 'ab-rebuilt'])
    for suffix in ['native.tm', 'sites.json']:
        require((out / 'ab-rebuilt' / ('sb215_ab.' + suffix)).read_bytes() ==
                (ROOT / 'machine' / ('sb215_ab.' + suffix)).read_bytes(), 'AB reconstruction differs')

    summary['checks']['canonicalization'] = run_check(out, 'canonicalization', ROOT / 'code' / 'canonicalize.py', [
        '--base-machine', ROOT / 'machine' / 'sb215.native.tm', '--base-source', ROOT / 'machine' / 'sb215.sites.json',
        '--ab-machine', ROOT / 'machine' / 'sb215_ab.native.tm', '--ab-source', ROOT / 'machine' / 'sb215_ab.sites.json',
        '--out', out / 'canonicalization'])
    for name in ['sb215', 'sb215_ab']:
        for suffix in ['tm', 'native.tm', 'sites.json']:
            require((out / 'canonicalization' / (name + '.' + suffix)).read_bytes() ==
                    (ROOT / 'machine' / (name + '.' + suffix)).read_bytes(), 'Canonical reconstruction differs')
        require(read_json(out / 'canonicalization' / (name + '.canonicalization.json')) ==
                read_json(ROOT / 'machine' / (name + '.canonicalization.json')), 'Canonicalization receipt differs')

    for name, prefix in [('base', 'sb215'), ('ab', 'sb215_ab')]:
        summary['checks'][name + '_independent_binary'] = run_check(out, name + '-independent-binary',
            ROOT / 'code' / ('check_' + name + '_binary.py'), [
                '--packet', REFERENCE, '--machine', ROOT / 'machine' / (prefix + '.native.tm'),
                '--source', ROOT / 'machine' / (prefix + '.sites.json'), '--output', out / (name + '-independent-binary.json')])
        require(read_json(out / (name + '-independent-binary.json')) ==
                read_json(ROOT / 'evidence' / (name + '_independent_binary.json')), 'Independent binary receipt differs')
        summary['checks'][name + '_stored_runtime'] = check_census(name, prototype, out)

    math_checks = [
        ('fairness', 'check_fairness.py', ['--bound', 500500]),
        ('adaptive_credit', 'check_adaptive_credit.py', ['--diagonals', 1000]),
        ('independent_scanner', 'independent_scanner_audit.py', ['--diagonals', 1000])]
    for name, script, arguments in math_checks:
        destination = out / (name + '.json')
        summary['checks'][name] = run_check(out, name, ROOT / 'code' / script, arguments + ['--out', destination])
        require(read_json(destination) == read_json(ROOT / 'evidence' / (name + '.json')),
                name + ' fresh finite certificate differs from supplied certificate')

    if args.runtime:
        print('Re-deriving 6,152 arbitrary-natural cases for the control machine...', flush=True)
        summary['checks']['base_fresh_runtime'] = run_check(out, 'base-fresh-runtime', REFERENCE / 'reproduce.py', [
            '--runtime', 'scratch-biased', '--out', out / 'runtime-base'])
        require(read_cases(out / 'runtime-base' / 'scratch-biased-ordered-cases.json.gz') ==
                read_cases(ROOT / 'evidence' / 'scratch-biased-ordered-cases.json.gz'), 'Fresh control ordered cases differ')
        print('Re-deriving 6,152 arbitrary-natural cases for SB215-AB...', flush=True)
        summary['checks']['ab_fresh_runtime'] = run_check(out, 'ab-fresh-runtime', ROOT / 'code' / 'replay_ab_runtime.py', [
            '--packet', REFERENCE, '--machine', ROOT / 'machine' / 'sb215_ab.native.tm',
            '--source', ROOT / 'machine' / 'sb215_ab.sites.json', '--out', out / 'runtime-ab'])
        require(read_cases(out / 'runtime-ab' / 'ordered-cases.json.gz') ==
                read_cases(ROOT / 'evidence' / 'ab-ordered-cases.json.gz'), 'Fresh AB ordered cases differ')
        summary['fresh_runtime_cases_compared'] = 2 * 6152
    summary.update(status='FULL_RUNTIME_REPLAY_PASS' if args.runtime else 'DEFAULT_REPLAY_PASS',
                   seconds=time.monotonic() - started,
                   inherited_status_note='Unchanged archived receipts may say logical calibration OPEN. That records their historical scope; the new unbounded logical proof is supplied separately in this packet.',
                   scope='Exact byte reconstruction, dense row bijection and blank lockstep, independent full startup/AX connection, runtime certificate audit, and finite mathematical checks. --runtime additionally rederives all primitive cases. The report supplies the unbounded fairness/calibration proof; no proof-assistant kernel result is claimed.')
    dump(out / 'summary.json', summary)
    print(json.dumps(summary, indent=2))
    print('Replay output: ' + str(out), flush=True)


if __name__ == '__main__':
    main()
