#!/usr/bin/env python3
"""Construct uniform-scratch/direct-tail source from the pinned transfer tree.

This constructs source only; it does not claim a binary allocation or startup.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
import source_language as s
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--parent', type=Path, default=ROOT/'reference/transfer-parent/source/transfer201.sites.json')
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert __debug__ and not sys.flags.optimize
HERE = args.out
HERE.mkdir(parents=True, exist_ok=False)
parent_path = args.parent
assert hashlib.sha256(parent_path.read_bytes()).hexdigest() == '05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922'
parent_rows = json.loads(parent_path.read_text())
parent = s.tree(parent_rows)
assert s.metrics(parent) == {
    'dag_nodes': 201, 'leaf_occurrences': 4775,
    'maximum_depth': 44, 'maximum_zero_run': 6,
}
long_s = s.subtree(parent, '111')
drop, first_nip = long_s[0]
second_nip = long_s[1]
assert first_nip == second_nip
assert len(s.sites(drop)) == len(s.sites(second_nip)) == 26
copy_cache_to_top = drop[1]
assert len(s.sites(copy_cache_to_top)) == 7
assert s.boundary(copy_cache_to_top) == (0, 0, False)
clear_top = (('CD', 1), ('CC', 1))
assert s.boundary(clear_top) == (0, 0, False)
increment_scratch = ('CI', 6)
receipts = []
for association, short_s in [
    ('left', ((clear_top, copy_cache_to_top), second_nip)),
    ('right', (clear_top, (copy_cache_to_top, second_nip))),
]:
    assert len(s.sites(short_s)) == 35
    assert s.boundary(short_s) == (0, 0, True)
    short = s.replace(parent, '111', short_s)
    short_rows = s.sites(short)
    graph = s.graph_intervals(short_rows)
    assert graph == s.graph_arithmetic(short_rows)[0]
    assert s.metrics(short)['dag_nodes'] == 201
    name = f'short_transfer_{association}_sites.json'
    raw = (json.dumps(short_rows, separators=(',', ':')) + '\n').encode()
    (HERE / name).write_bytes(raw)
    returns = [(i, short_rows[i], targets) for i, (_, targets) in enumerate(graph) if 0 in targets]
    assert len(returns) == 2
    assert [x[1][1:] for x in returns] == [['CB', 1], ['CD', 6]]
    for location, uniform in [
        ('prefix', (increment_scratch, short)),
        ('postlude', (short, increment_scratch)),
    ]:
        rows = s.sites(uniform)
        new_graph = s.graph_intervals(rows)
        assert new_graph == s.graph_arithmetic(rows)[0]
        offset = int(location == 'prefix')
        inc_ordinal = 0 if offset else len(short_rows)
        for i, (effect, targets) in enumerate(graph):
            expected = [effect, [inc_ordinal if t == 0 else t + offset for t in targets]]
            assert new_graph[i + offset] == expected, (association, location, i)
        assert new_graph[inc_ordinal] == [['increment', 6], [offset]]
        assert s.metrics(uniform)['dag_nodes'] == 202
        name = f'uniform_scratch_{association}_{location}_sites.json'
        raw = (json.dumps(rows, separators=(',', ':')) + '\n').encode()
        (HERE / name).write_bytes(raw)
        receipts.append({
            'file': name, 'sha256': hashlib.sha256(raw).hexdigest(),
            'metrics': s.metrics(uniform), 'increment_ordinal': inc_ordinal,
            'short_source_returns_to_root': returns,
            'graph_statement': 'All old source edges are unchanged up to ordinal translation except the two command returns, which enter the single scratch increment; that increment then enters the old command root.',
        })
receipt = {
    'status': 'SOURCE_CONSTRUCTION_AND_EXACT_CFG_PASS',
    'scope': 'No binary machine, primitive-runtime or blank-start claim.',
    'parent': str(parent_path), 'parent_sha256': hashlib.sha256(parent_path.read_bytes()).hexdigest(),
    'short_s_source': '(clear top; copy cache to top; inherited NIP)',
    'short_s_occurrences': 35,
    'short_s_contract': 'With X=Y=0, halt iff incoming cache=1; otherwise (t,w,d,h)->(h,tail(w),d,head(w)), X=Y=0.',
    'uniform_contract': 'On each complete command return, X=0; the single common increment makes X=1 before the inherited main reader. Positive residuals decode directly, and an empty residual advances the candidate counter by 2.',
    'variants': receipts,
}
(HERE / 'uniform_scratch_source_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
