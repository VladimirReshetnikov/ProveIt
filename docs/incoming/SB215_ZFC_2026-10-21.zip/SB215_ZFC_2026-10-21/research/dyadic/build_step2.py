#!/usr/bin/env python3
"""Reproduce and audit the source-level stride-two scheduler.

This does not allocate or verify a binary Turing machine. Only the standard
library and the pinned, vendored source_language.py are used.
"""
from pathlib import Path
import argparse
import hashlib
import json
import source_language as src


def one_step(rows, graph, pc, registers):
    op, arg = rows[pc][1:]
    destinations = graph[pc][1]
    if op == "CI":
        registers[arg] += 1
        return destinations[0]
    if op == "CD":
        positive = registers[arg] > 0
        registers[arg] -= positive
        return destinations[int(positive)]
    if op in ("CB", "CC"):
        return destinations[0]
    raise AssertionError("Unexpected halt in the scheduler")


def audit_scheduler(rows, graph):
    count = 0
    for n in range(64):
        for tail in range(9):
            registers = [n, 5, 9, 0, 7, 11, 0, 0, tail]
            pc = steps = 0
            while rows[pc][0].startswith("0"):
                pc = one_step(rows, graph, pc, registers)
                steps += 1
                assert steps < 10000
            expected = [n, 5, 9, 0, 7, 11, 0, 0, tail - 1] if tail else \
                [n + 2, 5, 9, 0, 7, 11, 0, 0, n]
            assert registers == expected, (n, tail, registers, expected)
            count += 1
    return count


def pair(a, b):
    return (a + b) * (a + b + 1) // 2 + b


def witness(suffix, modulus, residue, cutoff):
    assert modulus > 0 and modulus & (modulus - 1) == 0
    b = pair(0, pair(0, suffix))
    t = next(t for t in range(modulus)
             if (t * (t + 1) // 2 + b) % modulus == residue % modulus)
    s = t
    minimum = max(b + 3, cutoff)
    if s < minimum:
        s += ((minimum - s + 2 * modulus - 1) // (2 * modulus)) * (2 * modulus)
    c = s - b - 3
    code = pair(c + 3, b)
    assert code >= cutoff and code % modulus == residue % modulus
    return {"candidate": code, "c": c, "x": 0, "y": 0}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", type=Path, default=Path(__file__).with_name("sites215.json"))
    ap.add_argument("--output", type=Path, default=Path(__file__).with_name("sites_step2.json"))
    ap.add_argument("--receipt", type=Path)
    args = ap.parse_args()
    baseline = args.baseline.read_bytes()
    root = src.tree(json.loads(baseline))
    h = src.subtree(root, "011")
    assert h == (("CI", 0), (("CD", 6), ("CC", 2)))
    assert src.boundary(h) == (0, 0, False)
    changed = src.replace(root, "011", (h, ("CI", 0)))
    rows = src.sites(changed)
    graph, _ = src.graph_arithmetic(rows)
    assert graph == src.graph_intervals(rows)
    assert src.subtree(changed, "1") == src.subtree(root, "1")
    body_before = src.sites(src.subtree(root, "1"))
    body_after = src.sites(src.subtree(changed, "1"))
    assert body_before == body_after
    finite_cases = audit_scheduler(rows, graph)
    residue_cases = 0
    for suffix in range(11):
        for k in range(8):
            modulus = 1 << k
            for residue in range(modulus):
                w = witness(suffix, modulus, residue, 1000)
                c = w["c"]
                assert w["candidate"] == pair(c + 3, pair(0, pair(0, suffix)))
                residue_cases += 1
    raw = src.compact(rows)
    args.output.write_bytes(raw)
    receipt = {
        "scope": "source construction and finite regressions only; no binary allocation",
        "baseline_sha256": hashlib.sha256(baseline).hexdigest(),
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "metrics": src.metrics(changed),
        "cfg_resolvers_agree": True,
        "unchanged_command_body": True,
        "scheduler_regression_cases": finite_cases,
        "residue_witness_regression_cases": residue_cases,
    }
    if args.receipt:
        args.receipt.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
