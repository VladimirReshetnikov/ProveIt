#!/usr/bin/env python3
"""Replay four valid-frame counterexamples to local machine shortcuts.

These are primitive-runtime rejections. They are not blank-start experiments,
accepted consistency candidates, or a general 214-state impossibility result.
"""
from pathlib import Path
import argparse,hashlib,json,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'reference/scratch-prototype/checks'))
import independent_runtime as r
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,required=True)
a=parser.parse_args();assert __debug__ and not sys.flags.optimize
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def mapped(table):
    labels={q:q+1000 for q,b in table};labels[84]=96;labels[254]=254
    assert len({labels[q]for q,b in table})==len(table)//2
    return {(labels[q],bit):(w,d,labels[z])for(q,bit),(w,d,z)in table.items()}
append_fixture=HERE/'append_fixture.native.tm'
assert sha(append_fixture)=='57a451f419505c0c457e29397741180314aec87d7e2de6e4618442d9084259c3'
T=r.table(append_fixture);old=mapped(T);records=[]
for item in json.loads((HERE/'append214_bypass_counterexamples.json').read_text())['records']:
    action=tuple(item['action66_0']);U=dict(T);U[66,0]=action;U={key:value for key,value in U.items()if key[0]!=198}
    assert len(U)==428 and len({q for q,b in U})==214
    site=item['source_site'];regs=item['registers'];spares=item['spares']
    want,detail=r.expected(site,regs,spares)
    parent,parent_steps,_=r.run(old,site[0],regs,spares)
    actual,steps,_=r.run(mapped(U),site[0],regs,spares)
    assert parent==want and actual!=want
    assert (steps,parent_steps)==(item['steps'],item['parent_steps'])
    assert r.describe(want)==item['expected'] and r.describe(actual)==item['actual']
    records.append({'family':'append-state198 bypass','action66_0':action,'states':214,'source_site':site,'steps':steps,'parent_steps':parent_steps,'status':'FINITE_COUNTEREXAMPLE_REPRODUCED'})
ci6_fixture=HERE/'ci6_fixture.native.tm'
assert sha(ci6_fixture)=='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
T=r.table(ci6_fixture);U=dict(T);U[38,0]=(0,1,108);U[42,0]=(0,1,108)
c=json.loads((HERE/'ci6_alias_counterexample.json').read_text());site=c['site'];regs=c['registers'];spares=c['spares'];gap=c['gap']
want,detail=r.expected(site,regs,spares,gap)
parent,parent_steps,_=r.run(mapped(T),site[0],regs,spares,gap)
actual,steps,_=r.run(mapped(U),site[0],regs,spares,gap)
assert parent==want and actual!=want and(parent_steps,steps)==(c['baseline_steps'],c['candidate_steps'])
assert want[1]==c['expected_head']and actual[1]==c['actual_head']
assert sorted(want[2])==c['expected_ones']and sorted(actual[2])==c['actual_ones']
records.append({'family':'CI6 contextual-entry alias','source_site':site,'steps':steps,'parent_steps':parent_steps,'status':'FINITE_COUNTEREXAMPLE_REPRODUCED'})
report={'status':'FOUR_SCOPED_REJECTIONS_REPRODUCED','scope':__doc__,'records':records,'fixture_hashes':{'append':sha(append_fixture),'CI6':sha(ci6_fixture)},'script_sha256':sha(Path(__file__))}
a.out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
