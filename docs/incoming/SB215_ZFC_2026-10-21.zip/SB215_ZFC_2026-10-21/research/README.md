# Optional source alternatives and rejected shortcuts

The calibrated machines in this packet are `machine/sb215.native.tm` and
`machine/sb215_ab.native.tm`. The material in this directory records other
routes investigated during the construction. It does **not** supply another
calibrated binary consistency machine or a 214-state result.

## Uniform scratch alternatives

`uniform-scratch/` contains four exact, complete source trees with **202 DAG
nodes, 4,733 primitive occurrences, maximum depth 45, and maximum zero run 6**.
They replace the 78-occurrence composite transfer by a 35-occurrence short
transfer and arrange one shared scratch increment at every command boundary.
Two associations of the short transfer and two cyclic placements of the
increment give the four variants.

The source proposal and exact control-flow transformations are documented in
`uniform-scratch/source_proposal.md`. A portable deterministic builder, the
literal source files, and a construction receipt are included. Two 201-node
short-transfer trees are intermediate source objects. The `.allocation.json`
files record infeasibility in the particular fixed-role synthesis model used
in the investigation. They are historical search receipts, not mathematical
lower bounds; their old workspace paths are provenance labels. The complete
optimizer environment is not included or required by the portable source
builder.

**No physical allocation, arbitrary-natural TM runtime theorem, or blank-start
connection has been supplied for these four alternatives.** In contrast, the
main candidate preserves the irregular scratch behavior and closes its
scheduler with the new synchronization theorem.

From the packet root, rebuild the exact source objects into a fresh directory:

```sh
python3 -B research/uniform-scratch/rebuild.py --out /tmp/new-uniform-sources
```

The builder uses the pinned transfer source already included under `reference/`.
It checks both independent control-flow resolvers and verifies that only the
two command-return edges are intercepted by the shared increment.

## Dyadic candidate progressions

`dyadic/` contains the five exact source variants discussed in
`proofs/dyadic_progressions.md`, together with the pinned K215 baseline, the
source helper, and the first stride-two builder and receipt. These change a
fixed candidate progression; they are source objects without new physical
allocations. The all-natural padding argument is the self-contained dyadic
proof in that note and in report section 7.1.

Rebuild the K215 stride-two example into new files with:

```sh
python3 -B research/dyadic/build_step2.py \
  --output /tmp/new-dyadic-source.json \
  --receipt /tmp/new-dyadic-receipt.json
```

The other four literal transfer sources use the local subtree substitutions
spelled out in the proof. This optional builder is not part of `verify.py`.

## Exact rejected shortcut witnesses

`rejected-shortcuts/` contains finite valid-frame counterexamples for:

- Three proposed append-writer bypasses, each of which deletes state 198 and
  leaves 214 working states, but fails the CD8 zero-guard primitive contract.
- A proposed contextual CI6 entry alias through state 108, which returns the
  wrong frame despite the attractive decoder-prefix relation.

The two `.native.tm` files in that directory are **reference fixtures for
these counterexamples**, not additional calibrated candidates in this packet.
The row replacements, exact expected and actual configurations, and a portable
replayer are included. The replayer confirmed all four failures:

```sh
python3 -B research/rejected-shortcuts/check.py --out /tmp/rejected-shortcuts.json
```

These are primitive-runtime counterexamples, not claims about the corresponding
blank computations and not an impossibility proof for 214 states. Additional
scope notes appear in `rejected_machine_routes.md`.

## Rechecking the historical table corpus

The portable `code/census_tables.py` retains the original census's table
parser and rooted-graph canonicalization. Its input directories and candidates
are explicit. The large historical archives are deliberately omitted; their
pins are recorded in `evidence/corpus_pins.json` and
`evidence/corpus_archives.json`.

After obtaining and extracting that corpus, run, for example:

```sh
python3 -B code/census_tables.py \
  --root /path/to/extracted/pinned/archives \
  --root /path/to/extracted/transfer/archive \
  --root /path/to/ProveIt/Computability/BusyBeaver/Research/ZFC/candidate-k215 \
  --candidate machine/sb215.native.tm \
  --candidate machine/sb215_ab.native.tm \
  --out /tmp/table-census.json
```

Each root is scanned recursively for complete five-column `.tm` tables with
215 working states. State renaming and global left/right reflection are
compared separately. Duplicate physical input paths are scanned only once.
Output paths are labelled by their supplied root index, so the new receipt
need not be byte-identical to the historical receipt's workspace paths.
The historical 319-table census is retained unchanged in
`evidence/table_census.json`. A no-match result is always relative to the
supplied corpus.

The main `verify.py` does not rerun these optional research explorations.
