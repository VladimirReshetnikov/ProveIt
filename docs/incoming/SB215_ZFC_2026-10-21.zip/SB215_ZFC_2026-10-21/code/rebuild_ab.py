#!/usr/bin/env python3
"""Rebuild SB215-AB deterministically from the pinned scratch-biased prototype.

Standard library only. Input files are inert data. This reconstruction is not
an arbitrary-natural runtime theorem or the scheduler calibration proof.
"""
from pathlib import Path
import argparse,hashlib,json
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--parent-machine',type=Path,required=True)
ap.add_argument('--parent-source',type=Path,required=True)
ap.add_argument('--out',type=Path,required=True)
a=ap.parse_args();assert __debug__;a.out.mkdir(parents=True,exist_ok=False)
sha=lambda x:hashlib.sha256(x).hexdigest()
raw=a.parent_machine.read_bytes();source_raw=a.parent_source.read_bytes()
assert sha(raw)=='f08bed9e62b9f43237b65c465d2f1bfc17474637b4b02785ca7f1813827bb0ce'
assert sha(source_raw)=='2407f815551b4aba335c9bf041e15e8ce3cfb9ad830d89539f3bcf123462371a'
for old,new in[(b'199 1 1 R 166\n',b'199 1 1 R 12\n'),(b'206 0 0 R 186\n',b'206 0 0 R 76\n')]:
 assert raw.count(old)==1;raw=raw.replace(old,new)
source=json.loads(source_raw)
changes=[(958,'1001001110101011000111001100','CD'),(963,'10010011101010110001110011110','CI'),(1136,'100100111010101100011111100','CD'),(1141,'1001001110101011000111111110','CI')]
for i,path,opcode in changes:
 assert source[i]==[path,opcode,3];source[i][2]=5
source_raw=(json.dumps(source,separators=(',',':'))+'\n').encode()
assert sha(raw)=='2155e318d049ab0c6f578012a0751bc2f445950615a7f035347888e77f7be883'
assert sha(source_raw)=='5369d888be0675221b18fd7bb0df3018213e966265604f9506a6be2c9deff5ba'
(a.out/'sb215_ab.native.tm').write_bytes(raw);(a.out/'sb215_ab.sites.json').write_bytes(source_raw)
report={'status':'EXACT_REBUILD_PASS','native_sha256':sha(raw),'source_sha256':sha(source_raw),'source_primitive_changes':len(changes),'transition_changes':2,'scope':'Deterministic literal reconstruction only.'}
(a.out/'rebuild.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
