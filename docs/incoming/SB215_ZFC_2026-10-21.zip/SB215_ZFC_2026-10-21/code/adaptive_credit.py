#!/usr/bin/env python3
"""Finite independent checks for the adaptive short-transfer credit theorem.

The unbounded theorem is proved in adaptive_credit_proof.md. This program
imports no repository checker and uses only Python's standard library.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def values(diagonals):
    limit = diagonals * (diagonals + 1) // 2
    right = [0] * limit
    tag = [0] * limit
    for s in range(diagonals):
        t = s * (s + 1) // 2
        for y in range(s + 1):
            right[t+y], tag[t+y] = y, s-y
    balance, credit, epsilon = [0]*limit, [0]*limit, [0]*limit
    for n in range(limit):
        y = right[n]
        if tag[n] == 0:
            r = y - 1
            balance[n] = -1 + (balance[r] if r >= 0 else 0)
            credit[n] = 1 + (credit[r] if r >= 0 else 0)
            epsilon[n] = epsilon[r] if r >= 0 else 0
        else:
            r = right[y] if tag[n] == 1 else right[right[y]]
            weight = 0 if tag[n] == 1 else 10
            balance[n] = weight + (balance[r] if r > 0 else 0)
            credit[n] = max(0, (credit[r] if r > 0 else 0) - weight)
            epsilon[n] = epsilon[r] if r > 0 else 1
    return right, tag, balance, credit, epsilon


def all_gap_prefix_min(weights, deficits=None):
    """Min over every finite path starting at 0/1, with steps in {1,2}."""
    if deficits is None:
        deficits = [max(0, -w) for w in weights]
    best = []
    minimum = 0
    for i, (w, loss) in enumerate(zip(weights, deficits)):
        incoming = ([] if i > 1 else [0])
        if i >= 1: incoming.append(best[-1])
        if i >= 2: incoming.append(best[-2])
        before = min(incoming)
        minimum = min(minimum, before-loss)
        best.append(before+w)
    return minimum, best


def direct_word(n, right, tag):
    answer = []
    while True:
        y = right[n]
        if tag[n] == 0:
            answer.append(-1)
            if y == 0: return answer
            n = y - 1
        else:
            answer.append(0 if tag[n] == 1 else 10)
            n = right[y] if tag[n] == 1 else right[right[y]]
            if n == 0: return answer


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--diagonals", type=int, default=1000)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    assert a.diagonals >= 6
    right, tag, bal, loss, eps = values(a.diagonals)
    assert [direct_word(i, right, tag) for i in range(15)] == [
        [-1], [0], [-1,-1], [10], [0], [-1,0],
        [10], [10], [0,0], [-1,-1,-1],
        [10], [10], [10], [0], [-1,10]]
    q = [2] + [b+2 for b in bal[1:]]
    q_min, _ = all_gap_prefix_min(q)
    fq = [q[x] for x in right]
    ffq = [q[right[x]] for x in right]
    fq_min, _ = all_gap_prefix_min(fq)
    ffq_min, _ = all_gap_prefix_min(ffq)
    assert min(q_min, fq_min, ffq_min) >= 0
    universal_min, _ = all_gap_prefix_min(bal, loss)
    assert universal_min == -4
    safe_diags = 0
    for s in range(3, a.diagonals):
        lo = s*(s+1)//2
        hi = lo+s+1
        minimum, _ = all_gap_prefix_min(bal[lo:hi], loss[lo:hi])
        assert minimum == 0, (s, minimum)
        safe_diags += 1
    checked_words = min(1000, len(bal))
    for n in range(checked_words):
        word = direct_word(n, right, tag)
        total, minimum = 0, 0
        for weight in word:
            total += weight
            minimum = min(minimum, total)
        assert total == bal[n] and -minimum == loss[n]
        assert len(word) <= n+1
        assert eps[n] == (word[-1] != -1)
    n, step, total, minimum, count = 1, 2, 0, 0, 0
    initial = []
    while n < len(bal):
        if len(initial) < 20: initial.append(n)
        minimum = min(minimum, total-loss[n])
        total += bal[n]
        n, step = n+step, 1+eps[n]
        count += 1
    assert minimum == 0
    assert initial[:4] == [1,3,5,7]
    out = {"candidates": len(bal), "diagonals": a.diagonals,
           "all_gap_schedule_credit": -universal_min,
           "all_gap_safe_diagonals_checked": safe_diags,
           "q_prefix_minimum": q_min, "pullback_prefix_minimum": fq_min,
           "double_pullback_prefix_minimum": ffq_min,
           "independently_expanded_words": checked_words,
           "actual_adaptive_schedule_candidates": count,
           "actual_adaptive_schedule_credit": -minimum,
           "actual_adaptive_initial_candidates": initial,
           "actual_adaptive_final_balance": total,
           "scope": "Finite corroboration; unbounded proof is in adaptive_credit_proof.md."}
    a.out.write_text(json.dumps(out, indent=2)+"\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__": main()
