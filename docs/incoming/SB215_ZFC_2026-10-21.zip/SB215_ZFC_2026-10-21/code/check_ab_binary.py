"""Independent finite startup/source audit for the archived scratch-biased215 table.
No arbitrary-natural primitive theorem or semantic calibration is claimed here.
"""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet',type=Path,default=P.parent/'formalism_research/transfer_archive/T215_Transfer_2026-10-20/research/short-transfer')
parser.add_argument('--machine',type=Path)
parser.add_argument('--source',type=Path)
parser.add_argument('--output',type=Path,default=P/'scratch_biased_ab_independent_audit.json')
args=parser.parse_args();A=args.packet
M=args.machine or P/'scratch_biased_ab.native.tm';S=args.source or P/'scratch_biased_ab.sites.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(M)=='2155e318d049ab0c6f578012a0751bc2f445950615a7f035347888e77f7be883'
assert sha(S)=='5369d888be0675221b18fd7bb0df3018213e966265604f9506a6be2c9deff5ba'
T={}
for line in M.read_text().splitlines():
 if not line or line.startswith('#'):continue
 q,b,w,d,z=line.split();key=int(q),int(b);assert key not in T
 T[key]=int(w),1 if d=='R'else -1,int(z)
assert '#! start 74' in M.read_text()
states={q for q,b in T};assert len(states)==215 and len(T)==430
assert all((q,b)in T for q in states for b in[0,1])
assert all(z in states or z==254 for w,d,z in T.values())
reachable={74};todo=[74]
for q in todo:
 for b in[0,1]:
  z=T[q,b][2]
  if z!=254 and z not in reachable:reachable.add(z);todo.append(z)
assert reachable==states
sites=json.loads(S.read_text());assert len(sites)==4733
leftmost={}
for i,(pc,op,arg)in enumerate(sites):
 for k in range(len(pc)+1):leftmost.setdefault(pc[:k],i)
assert len({x[0] for x in sites})==len(sites)
def advance(pc):
 if not pc:return ''
 value=int(pc,2)+1
 return '' if value==2**len(pc) else format(value,'0'+str(len(pc))+'b')
def strip(pc,bit,count):
 if not count:return pc
 for i in range(len(pc)-1,-1,-1):
  if pc[i]==bit:
   count-=1
   if not count:return pc[:i]
 return ''
def target(pc,op,arg,positive):
 if op=='CI' or op=='CD'and positive:nxt=advance(pc)
 elif op in['CD','CB']:nxt=advance(strip(pc,'0',1 if op=='CD'else arg))
 elif op=='CC':nxt=strip(pc,'1',arg)
 else:return None
 leaf_index={p:i for i,(p,op,arg)in enumerate(sites)}
 word=nxt+'0'*48
 for length in range(1,49):
  if word[:length] in leaf_index:
   assert '1' not in nxt[length:]
   return leaf_index[word[:length]]
 raise AssertionError('No target leaf')
# Independent sparse-set and fixed-array native simulations, compared at every step.
ones=set();array=bytearray(8192);offset=2048;h=0;q=74;h2=0;q2=74;used=set();minimum=0;maximum=0
for tick in range(69744):
 b=int(h in ones);w,d,z=T[q,b];used.add((q,b))
 if w:ones.add(h)
 else:ones.discard(h)
 h+=d;q=z
 b2=array[h2+offset];w2,d2,z2=T[q2,b2];array[h2+offset]=w2;h2+=d2;q2=z2
 assert (q,h)==(q2,h2)
 minimum=min(minimum,h);maximum=max(maximum,h)
assert (q,h)==(84,-2)
assert ones=={i-offset for i,v in enumerate(array)if v}
# Parse the exact address/header/unary cells, with no imported frame encoder.
header=min(x for x in ones if x>=h+52);assert header==62
pc=sites[64][0];assert pc=='10010010010110110110'
assert h-1 in ones and not any(x<h-1 for x in ones)
assert {x for x in ones if h<=x<header}=={h+i for i,b in enumerate(pc)if b=='1'}
values=[];cursor=header+1;last=max(ones)
while cursor<=last:
 assert cursor not in ones and cursor+1 in ones
 cursor+=1;start=cursor
 while cursor in ones:cursor+=1
 values.append(cursor-start-1)
assert cursor==last+1
phy=[6,2,0,4,3,7,8,5,1];logical=[values[j]for j in phy];spares=values[9:]
assert logical==[1,4,0,0,0,0,3,10,0]
assert len(spares)==65 and set(spares)=={0,1}
# Independent ordinal CFG replay of the entire 172-instruction synthetic AX prefix.
ordinal=25;regs=[1,0,3,0,0,0,0,0,0];trace=[]
for tick in range(172):
 pc,op,arg=sites[ordinal];positive=False
 if op=='CI':regs[arg]+=1
 elif op=='CD':positive=bool(regs[arg]);regs[arg]-=int(positive)
 else:assert op in['CB','CC']
 trace.append([ordinal,list(regs)])
 ordinal=target(pc,op,arg,positive)
assert ordinal==64 and regs==logical
# Complete binary prefix traversal, preserving every known code cell.
prefixes=sorted(set(leftmost)-{x[0]for x in sites},key=lambda x:(len(x),x));assert len(prefixes)==4732
binding={};allrows=set()
for p in prefixes:
 tape={-1:1,**{i:int(v)for i,v in enumerate(p)}};original=dict(tape);head=0;state=84
 for step in range(10000):
  if head==len(p):break
  assert head in tape
  key=state,tape[head];allrows.add(key);w,d,state=T[key];tape[head]=w;head+=d
 else:raise AssertionError('Decoder prefix limit')
 assert head==len(p)and tape==original
 binding[p]=state
report={'status':'INDEPENDENT_FINITE_AUDIT_PASS','scope':'Exact state graph, complete literal prefix traversal, dual-representation blank replay, whole finite frame, independent abstract AX prefix. Semantic primitive meanings and logical consistency calibration require separate proofs.','machine_sha256':sha(M),'source_sha256':sha(S),'working_states':215,'rows':430,'reachable_working_states':len(reachable),'start':74,'halt':254,'source_occurrences':len(sites),'source_opcode_counts':dict(Counter(x[1]for x in sites)),'internal_prefixes':len(prefixes),'blank_steps':69744,'blank_head_minimum':minimum,'blank_head_maximum':maximum,'blank_used_row_count':len(used),'blank_one_cells':sorted(ones),'blank_final_state':q,'blank_final_head':h,'header':header,'address':sites[64][0],'source_ordinal':64,'logical':logical,'spares':spares,'source_AX_entry':25,'source_AX_seed':[1,0,3,0,0,0,0,0,0],'AX_prefix_steps':172,'script_sha256':sha(Path(__file__))}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items()if k not in['blank_one_cells','spares']})
