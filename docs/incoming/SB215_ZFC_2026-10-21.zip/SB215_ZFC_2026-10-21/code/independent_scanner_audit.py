#!/usr/bin/env python3
"""Independent finite audit of the scratch-biased scanner fairness identities.

The proof is unbounded; this script checks its base identities and every
applicable bounded diagonal identity using explicit scanner executions.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from adaptive_credit import values


# 0=V0, 1=V1, 2=K0, 3=K1.
def step(state, bit):
    if state == 0: return bit
    if state == 1: return 2+bit
    return state-2


def scan(bits, state=0):
    out = []
    for bit in bits:
        out.append(state)
        state = step(state, bit)
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--diagonals", type=int, default=1000)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    assert a.diagonals >= 10
    f, tag, _, _, e = values(a.diagonals)
    u = [1] + e[1:]
    g = [u[i] for i in f]
    h = [u[f[i]] for i in f]
    word = [1,1,0,1,1]
    for initial in range(4):
        state = initial
        for bit in word: state = step(state, bit)
        assert state == 1
    assert u[0:5] == g[3:8] == h[18:23] == e[7:12] == word
    E, G, H = scan(u), scan(g), scan(h)
    actual_scan = [None] + scan(e[1:], state=1)
    assert actual_scan[12:] == E[12:]
    counts = [0,0,0]
    for n, b in enumerate(f):
        if b >= 5:
            assert G[n] == E[b], ("G lift", n)
            counts[0] += 1
        if b >= 8:
            assert H[n] == G[b], ("H lift", n)
            counts[1] += 1
        if tag[n] >= 2 and b >= 23:
            assert E[n] == H[b], ("E lift", n)
            counts[2] += 1
    n, pending = 1, 2
    visited = set()
    while n < len(e):
        visited.add(n)
        n, pending = n+pending, 1+e[n]
    assert all((actual_scan[n] < 2) == (n in visited) for n in range(1, len(e)))
    # The last two algebraic alternatives depend only on these four cases.
    for state in range(4):
        if state < 2:
            assert state in (0,1)
        else:
            assert step(state,0) < 2 and step(state,1) < 2
    result = {"candidate_bound_exclusive": len(e), "synchronizing_word": "11011",
              "synchronized_initial_states": 4,
              "synchronizing_intervals": {"u": [0,5], "g": [3,8], "h": [18,23], "e": [7,12]},
              "scanner_matches_actual_visits": True,
              "actual_matches_canonical_from": 12,
              "explicit_G_diagonal_identities": counts[0],
              "explicit_H_diagonal_identities": counts[1],
              "explicit_E_diagonal_identities": counts[2],
              "scope": "Finite independent corroboration of the unbounded fairness proof."}
    a.out.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__": main()
