"""Canonical state numbering and literal native/dense blank lockstep for SB215 variants."""
from pathlib import Path
import argparse,json,hashlib,shutil
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--base-machine',type=Path,default=P.parent/'formalism_research/transfer_archive/T215_Transfer_2026-10-20/research/short-transfer/candidates/scratch-biased/machine.native.tm')
ap.add_argument('--base-source',type=Path,default=P.parent/'formalism_research/transfer_archive/T215_Transfer_2026-10-20/research/short-transfer/candidates/scratch-biased/source.sites.json')
ap.add_argument('--ab-machine',type=Path,default=P/'scratch_biased_ab.native.tm')
ap.add_argument('--ab-source',type=Path,default=P/'scratch_biased_ab.sites.json')
ap.add_argument('--out',type=Path,default=P/'final_machines')
a=ap.parse_args();assert __debug__;a.out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 t={};start=None
 for line in p.read_text().splitlines():
  if line.startswith('#! start '):start=int(line.split()[-1])
  elif line and not line.startswith('#'):
   q,b,w,d,z=line.split();key=int(q),int(b);assert key not in t;t[key]=int(w),1 if d=='R'else -1,int(z)
 assert start==74;return t,start
all_reports=[]
for name,machine,source in[('sb215',a.base_machine,a.base_source),('sb215_ab',a.ab_machine,a.ab_source)]:
 native,start=read(machine);working={q for q,b in native};assert len(working)==215 and len(native)==430
 order=[start];mapping={start:0}
 for q in order:
  for bit in[0,1]:
   z=native[q,bit][2]
   if z!=254 and z not in mapping:mapping[z]=len(order);order.append(z)
 assert set(mapping)==working;mapping[254]=215
 dense={(mapping[q],bit):(w,d,mapping[z])for(q,bit),(w,d,z)in native.items()}
 assert set(q for q,b in dense)==set(range(215))
 assert all(dense[mapping[q],bit]==(w,d,mapping[z])for(q,bit),(w,d,z)in native.items())
 out_machine=a.out/(name+'.tm');out_native=a.out/(name+'.native.tm');out_source=a.out/(name+'.sites.json')
 out_machine.write_text('#! start 0\n'+''.join(f'{q} {bit} {w} {"R" if d==1 else "L"} {z}\n'for(q,bit),(w,d,z)in sorted(dense.items())))
 shutil.copyfile(machine,out_native);shutil.copyfile(source,out_source)
 q=start;h=0;ones=set();r=0;j=0;bits=set()
 for step in range(69744):
  assert mapping[q]==r and h==j and ones==bits
  w,d,q=native[q,int(h in ones)]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
  w,d,r=dense[r,int(j in bits)]
  if w:bits.add(j)
  else:bits.discard(j)
  j+=d
 assert q==84 and r==mapping[84] and h==j==-2 and ones==bits
 report={'status':'CANONICALIZATION_AND_LITERAL_LOCKSTEP_PASS','name':name,'native_start':74,'dense_start':0,'working_states':215,'rows':430,'native_dispatcher':84,'dense_dispatcher':mapping[84],'native_halt':254,'dense_halt':215,'numbering':'Deterministic breadth-first discovery from declared start, read0 edge before read1 edge; halt excluded from discovery.','native_to_dense':dict(sorted(mapping.items())),'row_bijections_checked':430,'blank_lockstep_steps':69744,'native_sha256':sha(out_native),'dense_sha256':sha(out_machine),'source_sha256':sha(out_source),'code_sha256':sha(Path(__file__))}
 (a.out/(name+'.canonicalization.json')).write_text(json.dumps(report,indent=2)+'\n');all_reports.append(report)
print([{k:v for k,v in r.items()if k not in['native_to_dense']}for r in all_reports])
