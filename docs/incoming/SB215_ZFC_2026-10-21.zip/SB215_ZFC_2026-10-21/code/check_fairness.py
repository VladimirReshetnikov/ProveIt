#!/usr/bin/env python3
"""Independent finite checks for the scratch-biased scheduler fairness proof.

The mathematical proof is scratch_biased_fairness.md. This script is not a
substitute for its all-natural argument or the archived physical certificate.
It uses Python's standard library only and does not modify archived evidence.
"""
from array import array
from functools import lru_cache
from math import isqrt
from pathlib import Path
import argparse
import hashlib
import json
import random


def pair(a, b):
    s = a + b
    return s * (s + 1) // 2 + b


def unpair(n):
    s = (isqrt(8 * n + 1) - 1) // 2
    b = n - s * (s + 1) // 2
    return s - b, b


def right(n):
    return unpair(n)[1]


# V0, V1, K0, K1. Rows are t_0 and t_1, respectively.
TRANSITION = ((0, 2, 0, 1), (1, 3, 0, 1))
LABELS = ('V0', 'V1', 'K0', 'K1')


def apply_word(state, letters):
    for bit in letters:
        state = TRANSITION[bit][state]
    return state


def decode_word(n):
    out = []
    while True:
        tag, y = unpair(n)
        if tag == 0:
            out.append(('S',))
            if y == 0:
                return out
            n = y - 1
        elif tag == 1:
            x, n = unpair(y)
            out.append(('MP', x))
            if n == 0:
                return out
        else:
            y, z = unpair(y)
            x, n = unpair(z)
            out.append(('AX', tag - 2, x, y))
            if n == 0:
                return out


def encode_positive_word(word):
    """The last command must be non-S, making every suffix positive."""
    assert word and word[-1][0] != 'S'
    n = 0
    for command in reversed(word):
        if command[0] == 'S':
            assert n > 0
            n = pair(0, n + 1)
        elif command[0] == 'MP':
            n = pair(1, pair(command[1], n))
        else:
            _, c, x, y = command
            n = pair(c + 2, pair(y, pair(x, n)))
        assert n > 0
    return n


def s_prefix(r):
    return pair(0, r + 1)


def m_prefix(x, r):
    return pair(1, pair(x, r))


def a_prefix(c, x, y, r):
    return pair(c + 2, pair(y, pair(x, r)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bound', type=int, default=500500)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    bound = args.bound
    assert bound >= 1000
    f = array('I')
    e = bytearray()
    u = bytearray()
    g = bytearray()
    h = bytearray()
    scans = [bytearray([0]), bytearray([0]), bytearray([0])]
    for n in range(bound + 1):
        tag, y = unpair(n)
        f.append(y)
        if tag == 0:
            bit = 0 if y == 0 else e[y - 1]
        else:
            r = f[y] if tag == 1 else f[f[y]]
            bit = 1 if r == 0 else e[r]
        e.append(bit)
        u.append(1 if n == 0 else bit)
        g.append(u[f[n]])
        h.append(u[f[f[n]]])
        for states, letters in zip(scans, (u, g, h)):
            states.append(TRANSITION[letters[n]][states[-1]])

    assert list(u[:5]) == [1, 1, 0, 1, 1]
    assert list(g[3:8]) == [1, 1, 0, 1, 1]
    assert list(h[18:23]) == [1, 1, 0, 1, 1]
    assert list(e[7:12]) == [1, 1, 0, 1, 1]
    assert {apply_word(s, (1, 1, 0, 1, 1)) for s in range(4)} == {1}

    # Direct candidate stepping, separately from the integer-scanning model.
    visited = bytearray(bound + 1)
    n, d = 1, 2
    first_candidates = []
    while n <= bound:
        visited[n] = 1
        if len(first_candidates) < 30:
            first_candidates.append(n)
        n, d = n + d, 1 + e[n]
    assert all(bool(visited[n]) == (scans[0][n] < 2)
               for n in range(1, bound + 1))

    # Check the local lift identities directly against fully expanded arrays.
    lift_counts = [0, 0, 0]
    for n in range(bound + 1):
        a, b = unpair(n)
        if b >= 5:
            assert scans[1][n] == scans[0][b]
            lift_counts[0] += 1
        if b >= 8:
            assert scans[2][n] == scans[1][b]
            lift_counts[1] += 1
        if a >= 2 and b >= 23:
            assert scans[0][n] == scans[2][b]
            lift_counts[2] += 1

    @lru_cache(None)
    def terminal(n):
        if n <= bound:
            return e[n]
        tag, y = unpair(n)
        if tag == 0:
            return 0 if y == 0 else terminal(y - 1)
        r = right(y) if tag == 1 else right(right(y))
        return 1 if r == 0 else terminal(r)

    def auxiliary(n):
        return 1 if n == 0 else terminal(n)

    def label_g(n):
        return auxiliary(right(n))

    # A fast evaluator uses a single previous diagonal if the current prefix
    # is shorter than the synchronization bound. All recursive arguments are
    # strictly smaller, permitting enormous exact integer witnesses.
    base = 1000

    @lru_cache(None)
    def state_e(n):
        if n <= base:
            return scans[0][n]
        a, b = unpair(n)
        diagonal = a + b
        if a == 0:
            assert b - 1 >= 23
            return TRANSITION[label_g(b - 1)][state_h(b - 1)]
        if a == 1:
            assert b >= 23
            return state_h(b)
        if b >= 23:
            return state_h(b)
        # Finish the preceding diagonal: its AX prefix, then MP and S.
        k = diagonal - 2
        assert k >= 23
        state = state_h(k)
        state = TRANSITION[label_g(k)][state]
        state = TRANSITION[terminal(k)][state]
        return apply_word(state, h[:b])

    @lru_cache(None)
    def state_g(n):
        if n <= base:
            return scans[1][n]
        a, b = unpair(n)
        if b >= 5:
            return state_e(b)
        assert a + b >= 5
        return apply_word(state_e(a + b), u[:b])

    @lru_cache(None)
    def state_h(n):
        if n <= base:
            return scans[2][n]
        a, b = unpair(n)
        if b >= 8:
            return state_g(b)
        assert a + b >= 8
        return apply_word(state_g(a + b), g[:b])

    # Compare recursive evaluation with literal scanning, including the
    # unsynchronized starts and the two exceptional positions of every row.
    for n in range(base + 1, bound + 1):
        assert state_e(n) == scans[0][n]
        assert state_g(n) == scans[1][n]
        assert state_h(n) == scans[2][n]

    rng = random.Random(20261021)
    word_checks = 0
    for _ in range(500):
        word = []
        # Length is limited only to keep exact codes conveniently printable.
        for _ in range(rng.randrange(1, 7)):
            op = rng.randrange(3)
            if op == 0:
                word.append(('S',))
            elif op == 1:
                word.append(('MP', rng.randrange(4)))
            else:
                word.append(('AX', rng.randrange(4), rng.randrange(4), rng.randrange(4)))
        word.append(('MP', 0))
        code = encode_positive_word(word)
        assert decode_word(code) == word
        assert terminal(code) == int(word[-1][0] != 'S')
        word_checks += 1

    sample_r = list(range(23, 100))
    sample_r += [rng.randrange(23, 2**32) for _ in range(200)]
    sample_r += [2**k + k for k in range(32, 257, 16)]
    witness_rows = []
    observed_h_states = set()
    maximum_bits = 0
    for r in sample_r:
        hs = state_h(r)
        observed_h_states.add(hs)
        double_mp = m_prefix(0, m_prefix(2, r))
        single_s = s_prefix(r)
        assert state_e(double_mp) == hs
        assert state_e(single_s) == TRANSITION[label_g(r)][hs]
        chosen = double_mp if hs < 2 else single_s
        assert state_e(chosen) < 2
        for c in (0, 1, 2, 10, 1000):
            padded = a_prefix(c, 0, 0, chosen)
            assert state_e(padded) == state_e(chosen)
            assert state_e(a_prefix(c, 2, 3, r)) == state_e(r)
            maximum_bits = max(maximum_bits, padded.bit_length())
        if len(witness_rows) < 8 or hs not in {row['h_state_index'] for row in witness_rows}:
            witness_rows.append({
                'suffix': r, 'h_state': LABELS[hs], 'h_state_index': hs,
                'chosen_prefix': 'MP(0);MP(2)' if hs < 2 else 'S',
                'visited_code': str(chosen),
                'padded_code_c0': str(a_prefix(0, 0, 0, chosen)),
                'scanner_state': LABELS[state_e(chosen)],
            })
    assert observed_h_states == set(range(4))

    result = {
        'status': 'ALL_FINITE_CHECKS_PASS',
        'scope': 'Finite independent checks of the all-natural fairness proof; not a physical-runtime or proof-assistant certificate.',
        'literal_scanner_bound': bound,
        'literal_actual_visits': sum(visited),
        'first_candidates': first_candidates,
        'synchronizing_word': '11011',
        'synchronization_prefix_lengths': {'u': 5, 'g': 8, 'h': 23},
        'diagonal_lift_checks': lift_counts,
        'recursive_scanner_comparisons': 3 * (bound - base),
        'wire_roundtrips': word_checks,
        'huge_suffix_cases': len(sample_r),
        'maximum_padded_witness_bits': maximum_bits,
        'all_four_H_states_exercised': True,
        'sample_witnesses': witness_rows,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    raw = json.dumps(result, indent=2) + '\n'
    if args.out:
        args.out.write_text(raw)
    print(raw, end='')


if __name__ == '__main__':
    main()
