#!/usr/bin/env python3
"""Regenerate the two complete dense transition tables in the LaTeX report."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def table(path):
    rows = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        q, read, write, move, target = line.split()
        key = int(q), int(read)
        assert key not in rows
        rows[key] = f"{write}{move}{'H' if int(target) == 215 else target}"
    assert set(rows) == {(q, b) for q in range(215) for b in (0, 1)}
    return rows

parts = [
    r"\clearpage",
    r"\section{Complete dense transition tables}",
    r"\label{app:tables}",
    r"Both tables start at state $0$, with head at cell $0$ on the entirely zero tape. Working states are $0,\ldots,214$; $H$ denotes halt state $215$. An action such as \texttt{1L37} means write $1$, move left and enter state $37$. Each three-column panel is read downward. These are complete tables: two actions for each of the 215 working states. The native tables and canonicalization bijections are supplied separately.",
]
for name, title in [
    ("sb215_ab", "SB215-AB: the new literal candidate"),
    ("sb215", "SB215: the newly calibrated predecessor"),
]:
    if name == "sb215":
        parts.append(r"\clearpage")
    parts.extend([
        r"\subsection{" + title + "}",
        r"{\footnotesize\ttfamily",
        r"\setlength{\tabcolsep}{3pt}",
        r"\renewcommand{\arraystretch}{1.0}",
        r"\begin{longtable}{@{}rll@{\hspace{6mm}}rll@{\hspace{6mm}}rll@{\hspace{6mm}}rll@{\hspace{6mm}}rll@{}}",
        r"\toprule",
        " & ".join([r"$q$ & $0$ & $1$"] * 5) + r"\\",
        r"\midrule",
        r"\endfirsthead",
        r"\toprule",
        " & ".join([r"$q$ & $0$ & $1$"] * 5) + r"\\",
        r"\midrule",
        r"\endhead",
        r"\bottomrule",
        r"\endfoot",
    ])
    rows = table(ROOT / "machine" / f"{name}.tm")
    for i in range(43):
        cells = []
        for j in range(5):
            q = i + 43 * j
            cells.extend([str(q), rows[q, 0], rows[q, 1]])
        parts.append(" & ".join(cells) + r"\\")
    parts.extend([r"\end{longtable}", "}"])
target = ROOT / "report/sections/transitions.tex"
target.write_text("\n".join(parts) + "\n")
print(target)

