"""Fresh all-natural primitive replay for the new scratch-biased AB composition."""
from pathlib import Path
import gzip,json,sys,time,hashlib,argparse
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet',type=Path,default=P.parent/'formalism_research/transfer_archive/T215_Transfer_2026-10-20/research/short-transfer')
parser.add_argument('--machine',type=Path,default=P/'scratch_biased_ab.native.tm')
parser.add_argument('--source',type=Path,default=P/'scratch_biased_ab.sites.json')
parser.add_argument('--out',type=Path,default=P/'scratch_biased_ab_fresh')
a=parser.parse_args();assert __debug__ and not sys.flags.optimize
sys.path.insert(0,str(a.packet));import reproduce as archived
S=archived.S;U=archived.U;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(a.machine)=='2155e318d049ab0c6f578012a0751bc2f445950615a7f035347888e77f7be883'
assert sha(a.source)=='5369d888be0675221b18fd7bb0df3018213e966265604f9506a6be2c9deff5ba'
a.out.mkdir(parents=True,exist_ok=False)
N=archived.legacy_table(a.machine);sites=json.loads(a.source.read_text());lemmas,blocks=S.prove_blocks(N);cases=[];rows=set();begun=time.monotonic()
for i,site in enumerate(sites):
 for positive in((False,True)if site[1]=='CD'else(False,)):
  answer=S.case(N,lemmas,site,positive,append=0);rows.update(answer['rows']);answer['rows']=sorted(answer['rows']);answer.pop('trace');cases.append({'site_index':i,'positive':positive,**answer})
 if i%1000==0:print('proved',i,len(cases),round(time.monotonic()-begun,2),flush=True)
assert len(cases)==6152 and len(rows)==430 and len(N)==430
report={'status':'ALL_NATURAL_RUNTIME_PASS','cases':len(cases),'working_states':len(N)//2,'rows':len(N),'append_value':0,'symbolic_rules':sum(c['symbolic_steps']for c in cases),'minimum_duration_constant':min(c['duration'][0]for c in cases),'covered_rows':sorted(rows),'covered_row_count':len(rows),'blocks':blocks,'source_sha256':sha(a.source),'machine_sha256':sha(a.machine),'checker_sha256':sha(Path(S.__file__)),'helper_sha256':sha(Path(archived.I.__file__)),'wrapper_sha256':sha(Path(__file__)),'seconds':time.monotonic()-begun,'scope':'All natural primary register values, natural extra gap, nonempty finite spare list of natural values, entire tape and blank exterior. Executable unary/list induction certificate, not a proof-assistant kernel artifact. Source calibration is a separate theorem.'}
(a.out/'runtime.json').write_text(json.dumps(report,indent=2)+'\n')
with gzip.GzipFile(a.out/'ordered-cases.json.gz','wb',mtime=0)as f:f.write((json.dumps(cases,separators=(',',':'))+'\n').encode())
print({k:v for k,v in report.items()if k not in['blocks','covered_rows']},flush=True)
