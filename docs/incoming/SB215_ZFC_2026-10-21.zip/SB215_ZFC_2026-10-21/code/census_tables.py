#!/usr/bin/env python3
"""Recheck the scoped 215-state rooted-table census using explicit local inputs.

Supply the extracted pinned corpus directories with repeated --root arguments
and the candidate tables with repeated --candidate arguments. No downloads are
performed. This uses the original census's parsing and canonicalization rules:
complete five-column two-symbol .tm tables, 215 working states, declared start
(or zero if omitted), breadth-first numbering with read0 before read1, and all
nonworking targets identified as halt. Reflection reverses every tape move.

A no-match result is relative to the supplied corpus, not a universal novelty
or machine-optimality theorem. The bulk historical archives are not included
in this packet; their acquisition pins are in evidence/corpus_*.json.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re


def read(path):
    table = {}
    start = 0
    for line in path.read_text().splitlines():
        if not line.strip():
            continue
        if line.lstrip().startswith('#'):
            match = re.search(r'\bstart(?:ing)?(?:[_ ]state)?\s*[:=]?\s*(\d+)', line, re.I)
            if match:
                start = int(match[1])
            continue
        fields = line.split()
        if len(fields) != 5:
            raise ValueError('unsupported table syntax')
        q, bit, write, direction, target = fields
        q, bit, write, target = map(int, (q, bit, write, target))
        if bit not in (0, 1) or write not in (0, 1) or direction not in ('L', 'R') or (q, bit) in table:
            raise ValueError('invalid row')
        table[q, bit] = write, (-1 if direction == 'L' else 1), target
    states = {q for q, bit in table}
    if len(states) != 215 or len(table) != 430 or any((q, bit) not in table for q in states for bit in (0, 1)):
        raise ValueError('not complete 215')
    if start not in states:
        raise ValueError('start absent')
    return table, start


def canon(table, start, mirror=False):
    mapping = {start: 0}
    order = [start]
    output = []
    for q in order:
        row = []
        for bit in (0, 1):
            write, direction, target = table[q, bit]
            if (target, 0) not in table:
                canonical_target = -1
            else:
                if target not in mapping:
                    mapping[target] = len(order)
                    order.append(target)
                canonical_target = mapping[target]
            row.append((write, -direction if mirror else direction, canonical_target))
        output.append(row)
    raw = json.dumps(output, separators=(',', ':')).encode()
    return hashlib.sha256(raw).hexdigest(), len(order)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, action='append', required=True,
                        help='A corpus directory (recursively scans *.tm), or one table; repeat as needed')
    parser.add_argument('--candidate', type=Path, action='append', required=True,
                        help='Candidate table to compare with the corpus; repeat as needed')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    records = []
    exclusions = []
    seen = set()
    roots = []
    for index, original in enumerate(args.root):
        base = original.resolve()
        if not base.exists():
            raise FileNotFoundError(base)
        roots.append(str(base))
        files = [base] if base.is_file() else sorted(base.rglob('*.tm'))
        anchor = base.parent if base.is_file() else base
        for path in files:
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            label = f'root[{index}]/' + path.relative_to(anchor).as_posix()
            try:
                table, start = read(path)
            except (ValueError, UnicodeError, OSError) as error:
                exclusions.append({'path': label, 'reason': str(error)})
                continue
            graph, reachable = canon(table, start)
            reflected, _ = canon(table, start, mirror=True)
            records.append({'path': label, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                            'start': start, 'reachable_working_states': reachable,
                            'rooted_graph_sha256': graph, 'reflected_graph_sha256': reflected})
    candidates = []
    for original in args.candidate:
        path = original.resolve()
        table, start = read(path)
        graph, reachable = canon(table, start)
        candidates.append({'path': str(original), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                           'start': start, 'rooted_graph_sha256': graph, 'reachable_working_states': reachable,
                           'equal_graph_paths': [row['path'] for row in records if row['rooted_graph_sha256'] == graph],
                           'equal_reflected_graph_paths': [row['path'] for row in records if row['reflected_graph_sha256'] == graph]})
    result = {'status': 'CENSUS_COMPLETE',
              'scope': 'All parsable complete five-column 215-working-state .tm files in the explicitly supplied local corpus; a scoped novelty comparison, not a universal novelty or optimality theorem.',
              'roots': roots, 'tables': len(records),
              'distinct_byte_hashes': len({row['sha256'] for row in records}),
              'distinct_rooted_graphs': len({row['rooted_graph_sha256'] for row in records}),
              'candidates': candidates, 'records': records, 'excluded': exclusions,
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('records', 'excluded')}, indent=2))


if __name__ == '__main__':
    main()
