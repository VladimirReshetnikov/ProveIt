# The Exponent-Group Threshold for Polish Omnific Arithmetic

**Separated grids, an induction-free root obstruction, and finite-support surreal semirings**  
Prepared for Vladimir Reshetnikov with ChatGPT, 4 October 2026.

## Main results

For an additive subgroup Gamma of the real line, let A_Gamma consist of finite
sums with positive exponents in Gamma, real coefficients, and an integer
constant term. Order these sums by their greatest nonzero term and write
P_Gamma for the nonnegative cone.

The manuscript proves that P_Gamma admits a Polish topology with continuous
addition and Borel multiplication if and only if Gamma is zero or cyclic
discrete. In the positive cases there is a locally compact, sigma-compact
Polish topology with both operations continuous.

A separate theorem excludes continuous addition under full Euclidean division
and the existence of integer kth roots for a single fixed k >= 2. These
arithmetic assumptions are strictly weaker than open induction, as witnessed
by the dyadic-exponent model. The abstract grid criterion also gives cofinally
many discontinuous translations in the corresponding Borel presentations.

The article proves full division for every real exponent subgroup, identifies
the exact integer-root spectrum Gamma = k Gamma, and obtains the transition
from finite root extensions to their infinite union. It includes twelve
research questions and a formalization plan.

## Files

- `article.pdf`: the compiled 23-page article.
- `article.tex`: standalone LaTeX source with an internal bibliography.
- `verify.py`: standard-library-only exact finite diagnostics.
- `verification_results.json`: recorded successful diagnostic run.
- `build.sh`: reproducible, location-independent build script.
- `PROOF_AUDIT.md`: proof dependencies, limitations, and review points.
- `SOURCES.md`: source snapshot and inspection scope.
- `SHA256SUMS`: hashes of the distributed files other than the hash file itself.

## Rebuild

With Python 3.10+ and a reasonably complete TeX Live installation:

```bash
bash build.sh
```

The script runs the diagnostics and three pdfLaTeX passes. It uses a temporary
build directory and leaves only the final PDF and diagnostic JSON beside the
source. There are no external figures, font files, bibliography tools, network
requests, or Python package dependencies. The TeX source uses standard TeX Live
packages including newtx, mathtools, microtype, enumitem, tcolorbox and hyperref.

To run only the algebraic checks:

```bash
python3 verify.py
```

The included run passed **13,034 exact assertions**, with seed 20261004.
The tests use integers and `fractions.Fraction`, not floating-point arithmetic.

## Evidence and attribution

This is an unrefereed research manuscript. It is not kernel-verified, and
independent correctness review and publication priority are not established.
The finite checks do not prove the infinite descriptive-set-theoretic results.

Glazer's Cantor-fusion and zero-one-law method is credited. The positive
polynomial-cone topology already appears in ProveIt and is not claimed as new.
The principal proposed extensions are the full real-subgroup threshold and
the explicit one-root weakening. No claim is made to resolve Glazer's full
reverse-mathematical question, to classify multiplication-only continuous
presentations, or to define a Polish topology on the proper class of all
surreal or omnific numbers.

No repository files were modified or uploaded.
