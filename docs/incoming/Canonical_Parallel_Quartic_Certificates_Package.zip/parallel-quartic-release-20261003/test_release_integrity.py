"""Disposable tamper tests for required inventory and pre-execution source pins."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,copy,json,os,shutil,subprocess,tempfile
from verify_release import ROOT,need,inventory,same

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-dir',type=Path,required=True)
 out=parser.parse_args().output_dir.resolve()
 need(out!=ROOT and ROOT not in out.parents,'tamper output must be outside the release')
 need(not out.exists()or(out.is_dir()and not any(out.iterdir())),'tamper output must be fresh or empty')
 out.mkdir(parents=True,exist_ok=True);before=inventory(ROOT);results=[]
 cases=('omit_pdf','omit_proof','omit_scientific_test','alter_inner_checker','forge_both_expected_receipts','omit_evidence','alter_unlisted_core_receipt')
 for optimized in(False,True):
  for case in cases:
   with tempfile.TemporaryDirectory(prefix='tamper-',dir=out)as work:
    release=Path(work)/'release';shutil.copytree(ROOT,release)
    if case.startswith('omit_'):
     target={'omit_pdf':'report28.pdf','omit_proof':'research/PROOF.md','omit_scientific_test':'research/test_certificate.py','omit_evidence':'evidence/verifier-binding-audit.md'}[case]
     (release/target).unlink()
    elif case=='alter_inner_checker':
     (release/'research/verify_bundle.py').write_text("from pathlib import Path\nPath(__file__).with_name('tamper-executed').write_text('EXECUTED')\nprint('{}')\n")
    elif case=='forge_both_expected_receipts':
     for mode,suffix in(('normal',''),('optimized','-optimized')):
      p=release/'expected'/mode/('receipt'+suffix+'.json');r=json.loads(p.read_text());r['counts']['full_endpoint_equalities']+=1;p.write_text(json.dumps(r)+'\n')
    elif case=='alter_unlisted_core_receipt':
     p=release/'research/bundle-verification.json';r=json.loads(p.read_text());r['manifest_files']+=1;p.write_text(json.dumps(r)+'\n')
    mode_args=['-O']if optimized else[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    seal=subprocess.run([sys.executable,'-B',*mode_args,str(release/'write_manifest.py')],cwd=out,env=env,capture_output=True,text=True)
    need(seal.returncode==0,'disposable reseal failed')
    check=subprocess.run([sys.executable,'-B',*mode_args,str(release/'verify_release.py')],cwd=out,env=env,capture_output=True,text=True)
    need(check.returncode!=0,'tampered resealed release was accepted: '+case)
    need(not(release/'research/tamper-executed').exists(),'altered inner checker was executed')
    # Store only stable case labels and the final error, never temporary paths.
    final=check.stderr.strip().splitlines()[-1]if check.stderr.strip()else'nonzero exit'
    results.append({'case':case,'optimized':optimized,'rejected':True,'inner_tamper_canary_absent':True,'reason':final})
 same(inventory(ROOT),before,'original release unchanged during tamper tests')
 receipt={'status':'PASS','negative_cases_per_mode':len(cases),'modes':['normal','optimized'],'original_release_inventory_bytes_modes_mtimes_unchanged':True,'all_resealed_tampers_rejected':True,'altered_inner_checker_never_executed':True,'results':results}
 (out/'tamper-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='results'},sort_keys=True))
if __name__=='__main__':main()
