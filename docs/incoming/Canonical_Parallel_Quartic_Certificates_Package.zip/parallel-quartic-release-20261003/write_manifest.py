"""Maintainer-only resealing helper; this changes the manifest, not scientific source."""
from pathlib import Path
import json,hashlib,stat
ROOT=Path(__file__).resolve().parent
files={};directories={}
for p in sorted(ROOT.rglob('*')):
 name=p.relative_to(ROOT).as_posix();s=p.lstat()
 if stat.S_ISLNK(s.st_mode):raise ValueError('symlink forbidden')
 if p.is_dir():directories[name]=stat.S_IMODE(s.st_mode)
 elif p.is_file():
  if name in('RELEASE-MANIFEST.json','RELEASE-SHA256SUMS'):continue
  b=p.read_bytes();files[name]={'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'sha256':hashlib.sha256(b).hexdigest()}
 else:raise ValueError('nonregular entry')
m={'schema':'report28-exact-release-v1','release_id':'parallel-quartic-release-20261003','source_manifest_sha256':'9f369b0a250b773c33f73213ec2e77e7c047118e9538e16c33cd84dfc625a31b','original_source_manifest_sha256':'dc2106553312d36cbcd655e5e3551e52771682de0a1f7f27e91798561ecf90a0','files':files,'directories':directories}
p=ROOT/'RELEASE-MANIFEST.json';p.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
sums={name:v['sha256']for name,v in files.items()};sums[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'RELEASE-SHA256SUMS').write_text(''.join(h+'  '+name+'\n'for name,h in sorted(sums.items())))
print(json.dumps({'files':len(files)+2,'manifest_sha256':sums[p.name]},sort_keys=True))
