"""Read-only manifest, pin, receipt-consistency, and concrete-example integrity."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
m=json.loads((R/'MANIFEST.json').read_text())
def check(ok,*why):
    if not ok:raise RuntimeError(why)
for path,record in m['files'].items():
    b=(R/path).read_bytes();check(len(b)==record['bytes']and hashlib.sha256(b).hexdigest()==record['sha256'],'file mismatch',path)
for name in('receipt','supplement-receipt','multisource-receipt','example-validation-receipt'):
    a=json.loads((R/(name+'.json')).read_text());b=json.loads((R/(name+'-optimized.json')).read_text())
    check(a['status']==b['status']=='PASS','failed tests',name)
    for key in('counts','ledgers','details','endpoint_equalities','sources','fixture_sha256','input_fixture_sha256','negative_cases','rejected_cases','verifier_sha256'):
        check(a.get(key)==b.get(key),'normal/-O difference',name,key)
for name in('example-verification','audit-emitter-receipt'):
    check(json.loads((R/(name+'.json')).read_text())==json.loads((R/(name+'-optimized.json')).read_text()),'normal/-O difference',name)
for name in('example-validation-receipt','example-validation-receipt-optimized'):
    record=json.loads((R/(name+'.json')).read_text())
    check(record['verifier_sha256']==hashlib.sha256((R/'verify_example.py').read_bytes()).hexdigest(),'stale standalone verifier tests',name)
for name,sha in json.loads((R/'audit-emitter-receipt.json').read_text())['file_hashes'].items():
    check(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha,'stale audit',name)
bind=json.loads((R/'fixture-provenance-rebind.json').read_text())
f=json.loads((R/'fixtures.json').read_text());payload=json.dumps({k:v for k,v in f.items()if k!='provenance'},sort_keys=True,separators=(',',':')).encode()
check(hashlib.sha256(payload).hexdigest()==bind['canonical_nonprovenance_payload_sha256'],'fixture payload changed')
check(hashlib.sha256((R/'fixtures.json').read_bytes()).hexdigest()==bind['portable_fixture_sha256'],'fixture rebind')
for name in('receipt','receipt-optimized','supplement-receipt','supplement-receipt-optimized'):
    r=json.loads((R/(name+'.json')).read_text());h=r.get('input_fixture_sha256',r.get('fixture_sha256'))
    check(h in (bind['tested_fixture_sha256'],bind['portable_fixture_sha256']),'unknown tested fixture',name)
p=json.loads((R/'PROVENANCE.json').read_text())
for name,record in p['copies'].items():check(hashlib.sha256((R/name).read_bytes()).hexdigest()==record['sha256'],'pin',name)
print(json.dumps(dict(status='PASS',manifest_files=len(m['files']),pinned_copies=len(p['copies']),normal_optimized_consistency=True),sort_keys=True))
