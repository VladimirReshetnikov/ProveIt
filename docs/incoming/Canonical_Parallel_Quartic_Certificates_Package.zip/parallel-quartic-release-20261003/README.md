# Report 28 A fixed horizon quartic compiler for the parallel particle rule

The theorem fixes a validated finite source, mass n, horizon T, and direction.
The resulting ordinary integer polynomial has degree at most four, with exactly
one complete natural witness for a canonical, strictly sorted exact endpoint
pair of the new parallel rule, and no witness otherwise. Coordinates are unbounded.
This is not a fixed-arity unbounded-time or real-witness uniqueness claim.

## Read and reproduce

- report28.pdf: standalone article with explicit endpoint geometry, compiler
  binding, quadratic gadget proofs, complete-witness uniqueness, and paid costs
- report28.tex and build.sh: editable LaTeX and a portable PDF build helper
- research/: the frozen 65-file cache-free scientific packet, all mandatory
  fixtures, independent audits, source/proof dependencies, source pins and ledgers
- expected/normal and expected/optimized: fresh scientific receipts from the
  final core author replay, used by strict typed replay comparisons
- evidence/: author output-routing/verifier audits and external replay summary,
  plus an independent scientific review summary
- verify_release.py: exact inventory, modes, byte hashes, pinned-source and typed
  reference validation, followed by the scientific packet's own verifier
- replay_release.py: all 14 bounded normal/optimized core commands plus two independent probe and two complete-witness-height audit runs,
  external-only outputs, exact source inventory/bytes/modes/mtime checks
- RELEASE-MANIFEST.json and RELEASE-SHA256SUMS: exact release inventory and pins

Run on Linux with Python 3.10+ using only the standard library:

    python3 -B verify_release.py
    python3 -B -O verify_release.py
    python3 -B replay_release.py --output-dir ../report28-fresh-replay

The replay directory must be empty or nonexistent and outside this release.
The same helper runs every suite and the 31-case independent verifier probe once normally and once with -O. It emits fresh
receipts/logs and a summary outside the sealed release. Normal/optimized mode
flags and elapsed seconds are validated but excluded from scientific equality;
all other fields and their exact JSON types, including complete ledgers, are
compared. Every emitted pair-polynomial/SOS file must remain byte-identical.

No network or package installation is required. The bounded suites previously
took about 7.4 minutes sequentially in the author environment; independent
replay timings can differ. Large residual systems need available memory.
The original baseline/supplement/multisource receipts under research/ are
historical, and research/bundle-verification*.json predate final outer-release
replay. They are retained as lineage, not mislabeled as fresh release results.
Use expected/ for the final source revision's comparison references.

To rebuild the article with an installed TeX distribution, run `sh build.sh`.
It uses a temporary build directory, then replaces report28.pdf. This intentionally
changes a sealed artifact; review the rebuilt PDF and reseal before distribution.
write_manifest.py is a maintainer helper, not a scientific verification step.

## Concrete results and explicit limits

For the one-increment source, n=2,T=1 has 1,494 witnesses, 1,502 quadratic
residuals, and a fully expanded 12,595-monomial quartic with 29,413 total
coefficient-magnitude bits and 220,969 serialized JSON bytes. The independent
artifact verifier checks exact schemas/arities, natural assignments, coordinate
metadata binding, SOS expansion identity, and every upward witness-coordinate
mutation. It does not independently reconstruct arbitrary source/CA semantics
or ledger/variable-name meanings; those depend on the audited compiler and pins.

The malformed five-particle cascade is fixed under the new rule; its old ordered
image is rejected. The actually emitted n=5,T=1 residual system has 784,928
witnesses and 784,951 rows. Mass-five T=2/T=3 fixture answers exist, but their
certificate runs were not completed. No universal-source polynomial or larger
fully expanded polynomial is claimed. Counts are current costs, not improvements
over differently scoped historical certificates.

## Provenance

Prior releases report26 (parallel-involution-release-20261003) and report27
(sparse-parallel-release-20261003) remain unchanged. The original core manifest
was dc2106553312d36cbcd655e5e3551e52771682de0a1f7f27e91798561ecf90a0.
The final core manifest is
9f369b0a250b773c33f73213ec2e77e7c047118e9538e16c33cd84dfc625a31b.
The four original runners changed only to route outputs. A separately recorded
standalone verifier repair adds exact schema/type and endpoint-prefix binding;
its 37 bundled and 31 additional independent negative probes pass in both modes.
Compiler, circuit, polynomial and mathematical-fixture content are unchanged.
All scientific dependencies needed for the stated finite-horizon theorem are
included; cache files are excluded from the release. Stable relative paths and
report/release IDs are used throughout provenance.

The independent probe script is retained byte-identically under evidence/verifier-audit/.
Because its historical output path is adjacent to its script, replay executes an
identical external copy with an explicit --source-dir. No sealed file is written.

## Complete witness height companion

The byte-identical 12-file bitbound/ companion proves the explicit source/mass
constant C(s,n) with every accepted auxiliary <= C(s,n)(A+T+1). It includes
inactive/rejected scratch and both target/input order scans. Its normal/-O
66-block, 332-block-assignment, 72-endpoint audits are mandatory replay steps,
including the cascade via --include-cascade. The main article gives the constants
and proof. The companion manifest pin is
02a03b79322cdc838fe4824415ccdaa70052c214b063702b2038e62026bb2b5d.

## Horizon encoding and packaging integrity

Linear growth in T refers to the numerical, explicitly unrolled horizon. It is
not a polynomial-size claim in the bitlength of a binary-encoded horizon.
The summed witness component-bit bound excludes circuit and JSON serialization
overhead.

The release verifier hardcodes its complete required filename/directory set
and exact immutable identities of all scientific, expected-result, evidence,
and deliverable files. Before executing the inner scientific verifier, it
independently checks every byte/size entry of the byte-pinned core manifest and
pins the four files outside that inner table. Resealing the mutable outer
manifest cannot waive a required file or authorize altered scientific evidence.
A deliberate reviewed change of pinned artifacts requires updating the trusted
checker constants as well as the outer manifest; write_manifest.py alone does
not redefine the accepted release.

Disposable resealed-tamper regressions run without altering the release:

    python3 -B test_release_integrity.py --output-dir ../report28-tamper-checks

They test missing PDF/proof/scientific-test/evidence files, an altered inner
checker with an execution canary, forged paired expected receipts, and an
altered historical core receipt. Every case is tested normally and with -O.
