"""Sequential normal/-O scientific replay with external output and exact source invariance."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,hashlib,json,subprocess,time,os,shutil
from verify_release import ROOT,BASES,load,need,same,semantic,receipt_name,compare_receipt,inventory,verify

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--output-dir',type=Path,required=True)
 args=parser.parse_args();out=args.output_dir.resolve()
 need(out!=ROOT and ROOT not in out.parents,'output directory must be outside release')
 need(not out.exists()or(out.is_dir()and not any(out.iterdir())),'output directory must be fresh or empty')
 out.mkdir(parents=True,exist_ok=True);verify();before=inventory(ROOT)
 (out/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
 source=ROOT/'research';results=[];started=time.perf_counter();receipts={}
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
 scripts=('test_certificate.py','test_supplement.py','test_multisource.py','audit_emitter.py','test_example_validation.py','verify_example.py','verify_bundle.py')
 for optimized in(False,True):
  mode='optimized'if optimized else'normal';dest=out/mode;dest.mkdir();receipts[mode]={}
  for script in scripts:
   cmd=[sys.executable,'-B']+(['-O']if optimized else[])+[str(source/script)]
   if script.startswith('test_')or script=='audit_emitter.py':cmd+=['--output-dir',str(dest)]
   start=time.perf_counter();log=dest/(script[:-3]+'.log')
   with log.open('w')as h:run=subprocess.run(cmd,cwd=out,env=env,stdout=h,stderr=subprocess.STDOUT)
   row={'script':script,'mode':mode,'returncode':run.returncode,'wall_seconds':time.perf_counter()-start,'log':log.relative_to(out).as_posix()}
   results.append(row);(out/'progress.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
   need(run.returncode==0,'scientific replay failed; see external log '+row['log'])
   same(inventory(ROOT),before,'source bytes modes mtimes inventory')
   print(json.dumps(row,sort_keys=True),flush=True)
  # The historical audit writes adjacent to itself; execute a byte-identical
  # external copy rather than changing or running it at its sealed location.
  probe=dest/'probe_binding.py';shutil.copy2(ROOT/'evidence'/'verifier-audit'/'probe_binding.py',probe)
  cmd=[sys.executable,'-B']+(['-O']if optimized else[])+[str(probe),'--source-dir',str(source)]
  start=time.perf_counter();log=dest/'independent-probes.log'
  with log.open('w')as h:run=subprocess.run(cmd,cwd=out,env=env,stdout=h,stderr=subprocess.STDOUT)
  results.append({'script':'probe_binding.py','mode':mode,'returncode':run.returncode,'wall_seconds':time.perf_counter()-start,'log':log.relative_to(out).as_posix()})
  need(run.returncode==0,'independent verifier probes failed');same(inventory(ROOT),before,'source invariance after independent probes')
  cmd=[sys.executable,'-B']+(['-O']if optimized else[])+[str(ROOT/'bitbound'/'audit_bounds.py'),'--packet',str(source),'--include-cascade','--output',str(dest/receipt_name('bitbound-audit',optimized))]
  start=time.perf_counter();log=dest/'bitbound-audit.log'
  with log.open('w')as h:run=subprocess.run(cmd,cwd=out,env=env,stdout=h,stderr=subprocess.STDOUT)
  results.append({'script':'audit_bounds.py','mode':mode,'returncode':run.returncode,'wall_seconds':time.perf_counter()-start,'log':log.relative_to(out).as_posix()})
  need(run.returncode==0,'complete witness height audit failed');same(inventory(ROOT),before,'source invariance after height audit')
  for base in BASES:
   name=receipt_name(base,optimized)
   if base in('verify_example','verify_bundle'):
    actual=load(dest/(base+'.log'));(dest/name).write_text(json.dumps(actual,indent=2,sort_keys=True)+'\n')
   else:actual=load(dest/name)
   compare_receipt(actual,base,optimized);receipts[mode][base]=actual
  for name in('example-pair-quartic.json','example-pair-sos.json'):
   need((dest/name).read_bytes()==(source/name).read_bytes(),'regenerated artifact byte mismatch: '+name)
 for base in BASES:same(semantic(receipts['normal'][base],False),semantic(receipts['optimized'][base],True),'fresh normal/-O '+base)
 verify();after=inventory(ROOT);same(after,before,'final source invariance')
 (out/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
 final={'status':'PASS','release_id':'parallel-quartic-release-20261003','release_manifest_sha256':hashlib.sha256((ROOT/'RELEASE-MANIFEST.json').read_bytes()).hexdigest(),'commands':results,'wall_seconds':time.perf_counter()-started,'source_entries_unchanged':len(before),'unchanged_fields':['inventory','bytes','modes','mtime_ns'],'typed_receipts_match_fresh_references':True,'normal_optimized_match':True,'regenerated_artifacts_byte_identical':True}
 (out/'replay-receipt.json').write_text(json.dumps(final,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:v for k,v in final.items()if k!='commands'},sort_keys=True))
if __name__=='__main__':main()
