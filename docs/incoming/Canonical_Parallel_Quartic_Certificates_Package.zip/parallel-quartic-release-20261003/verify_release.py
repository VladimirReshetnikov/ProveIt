"""Read-only exact inventory, pinned-science and typed-reference validation."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path, PurePosixPath
import hashlib, json, math, stat, subprocess, os
ROOT = Path(__file__).resolve().parent
CORE_PIN = '9f369b0a250b773c33f73213ec2e77e7c047118e9538e16c33cd84dfc625a31b'
PINS = {
 'research/compiler.py':'133d811972b6332ddc2fadfa8a7e34f3076b4712affa7c757d60e90d3ea2f5aa',
 'research/circuit.py':'dca31e8c2de8f6f4c1ae3bd17b8fbe614d67a92debd3b6b782f2d75704c83066',
 'research/verify_example.py':'d94aaee61d794f0c8ff8febc9334675f23f6c238df43eb88609982ae3026a9bd',
 'research/example-pair-quartic.json':'ddd6973f1285d60c2ae663b6b47cd933827e9e86c332cb69148c1ef45c27dca1',
 'research/MANIFEST.json':CORE_PIN,
 'bitbound/MANIFEST.json':'02a03b79322cdc838fe4824415ccdaa70052c214b063702b2038e62026bb2b5d',
}
# Trusted checker constants. The outer manifest cannot waive required files or
# redefine scientific, evidence, expected-output, or deliverable identities.
REQUIRED_FILES = frozenset(('README.md',
 'RELEASE-MANIFEST.json',
 'RELEASE-SHA256SUMS',
 'bitbound/MANIFEST.json',
 'bitbound/PROOF.md',
 'bitbound/README.md',
 'bitbound/audit-optimized.log',
 'bitbound/audit-receipt-optimized.json',
 'bitbound/audit-receipt.json',
 'bitbound/audit.log',
 'bitbound/audit_bounds.py',
 'bitbound/check_portability.py',
 'bitbound/independent-review.md',
 'bitbound/plumbing-receipt.json',
 'bitbound/portability-receipt.json',
 'build.sh',
 'delivery-provenance.json',
 'evidence/REPLAY_RESULTS.md',
 'evidence/independent-scientific-QA.json',
 'evidence/output-routing-audit.md',
 'evidence/packaging-tamper-receipt.json',
 'evidence/verifier-audit/independent-probes-optimized.json',
 'evidence/verifier-audit/independent-probes.json',
 'evidence/verifier-audit/probe_binding.py',
 'evidence/verifier-binding-audit.md',
 'expected/normal/audit-emitter-receipt.json',
 'expected/normal/bitbound-audit.json',
 'expected/normal/example-validation-receipt.json',
 'expected/normal/independent-probes.json',
 'expected/normal/multisource-receipt.json',
 'expected/normal/receipt.json',
 'expected/normal/supplement-receipt.json',
 'expected/normal/verify_bundle.json',
 'expected/normal/verify_example.json',
 'expected/optimized/audit-emitter-receipt-optimized.json',
 'expected/optimized/bitbound-audit-optimized.json',
 'expected/optimized/example-validation-receipt-optimized.json',
 'expected/optimized/independent-probes-optimized.json',
 'expected/optimized/multisource-receipt-optimized.json',
 'expected/optimized/receipt-optimized.json',
 'expected/optimized/supplement-receipt-optimized.json',
 'expected/optimized/verify_bundle.json',
 'expected/optimized/verify_example.json',
 'replay_release.py',
 'report28-qa.json',
 'report28.pdf',
 'report28.tex',
 'research/MANIFEST.json',
 'research/PROOF.md',
 'research/PROVENANCE.json',
 'research/README.md',
 'research/REPLAY.md',
 'research/RESULTS.md',
 'research/SHA256SUMS',
 'research/audit-design.md',
 'research/audit-emitter-optimized.log',
 'research/audit-emitter-receipt-optimized.json',
 'research/audit-emitter-receipt.json',
 'research/audit-emitter-test.log',
 'research/audit-emitter.md',
 'research/audit_emitter.py',
 'research/bundle-verification-optimized.json',
 'research/bundle-verification.json',
 'research/check_portability.py',
 'research/circuit.py',
 'research/compiler.py',
 'research/example-pair-quartic.json',
 'research/example-pair-sos.json',
 'research/example-pair-witness.json',
 'research/example-source.json',
 'research/example-validation-receipt-optimized.json',
 'research/example-validation-receipt.json',
 'research/example-verification-optimized.json',
 'research/example-verification.json',
 'research/fixture-provenance-rebind.json',
 'research/fixtures.json',
 'research/freeze_metadata.py',
 'research/frozen_lazy_source.py',
 'research/frozen_reversible_binary.py',
 'research/lineage/v1-MANIFEST.json',
 'research/multisource-optimized.log',
 'research/multisource-receipt-optimized.json',
 'research/multisource-receipt.json',
 'research/multisource.log',
 'research/parallel_particles.py',
 'research/portability-receipt.json',
 'research/prepare_test_oracle.py',
 'research/receipt-optimized.json',
 'research/receipt.json',
 'research/references/COMPILER_PROOF.md',
 'research/references/PARALLEL_LEMMA_AUDIT.md',
 'research/references/PARALLEL_PRESERVATION_AUDIT.md',
 'research/references/PARALLEL_RULE_PROOF.md',
 'research/references/PROOF.md',
 'research/references/SOURCE_SCHEMA.md',
 'research/references/test_sparse_parallel.py',
 'research/resource-ledger.json',
 'research/sparse_parallel.py',
 'research/supplement-optimized.log',
 'research/supplement-receipt-optimized.json',
 'research/supplement-receipt.json',
 'research/supplement.log',
 'research/test-optimized.log',
 'research/test-oracle-receipt.json',
 'research/test-oracle-report.md',
 'research/test.log',
 'research/test_certificate.py',
 'research/test_example_validation.py',
 'research/test_multisource.py',
 'research/test_supplement.py',
 'research/verify_bundle.py',
 'research/verify_example.py',
 'test_release_integrity.py',
 'verify_release.py',
 'write_manifest.py'))
REQUIRED_DIRECTORIES = frozenset(('bitbound',
 'evidence',
 'evidence/verifier-audit',
 'expected',
 'expected/normal',
 'expected/optimized',
 'research',
 'research/lineage',
 'research/references'))
IMMUTABLE_PINS = {'README.md': '76b87b52d1d77c06dbe81ad1dda003b8afda0d62894abe0405a695bd6db8d72f',
 'bitbound/MANIFEST.json': '02a03b79322cdc838fe4824415ccdaa70052c214b063702b2038e62026bb2b5d',
 'bitbound/PROOF.md': 'b3a4c0644c318d31832faea626b45ba3077f15a5c4164baed1d0da0adfc810a1',
 'bitbound/README.md': 'eba8e536dcb98a43d6947e68cc4dcd868563267932f902ad29aed46ee1626c3d',
 'bitbound/audit-optimized.log': 'f52acb5c4cdc28f51b9d3f1b029bd1cb1be4a6d1aa4b702dc843bdee5d70c9c9',
 'bitbound/audit-receipt-optimized.json': 'e684e58139c0efb9d44b82628100bea9391acdeea34712f312b174e33296de33',
 'bitbound/audit-receipt.json': 'aab0e73af814219828f74227207c0925e0d1b77785f8e1758ebc5b82968d60f6',
 'bitbound/audit.log': 'f52acb5c4cdc28f51b9d3f1b029bd1cb1be4a6d1aa4b702dc843bdee5d70c9c9',
 'bitbound/audit_bounds.py': '852a23c1098b98fdcdb9202fbda918261f9a5882eabfe724c341dfa144e52f66',
 'bitbound/check_portability.py': '7abc9cbc04fa15449a8fbe15caa3ec352ee164b69b9d88a6c6ae7284257f5924',
 'bitbound/independent-review.md': 'b33f454b25bf3a769788c350ff373ca7ee97d5ef33b6298ef56956f984b95ab5',
 'bitbound/plumbing-receipt.json': '50cb07db5117147bd510cd29d70618c09241776bccc66d184b0b785e33e8d945',
 'bitbound/portability-receipt.json': 'c315c6cb5f74387d6e79112c3aa32da990aee3109be25e67bb4f4a6d726f7415',
 'build.sh': '61f35a32ca751325fc00b98aaca9e9ea2e8fd9dbfeb4c8701a575bb4a1a8e1b3',
 'delivery-provenance.json': 'c14a328bdba10b75600fbfd61efbd53d02e1f5022f31a1aa935d15a5521991a2',
 'evidence/REPLAY_RESULTS.md': '524944df8201954e84c88ea8c335835aaa29727f27fd805320e23485707f526d',
 'evidence/independent-scientific-QA.json': 'dff366a914801ed4b2a394819067400cea2ad9be26b976c9bc4deef2e809e495',
 'evidence/output-routing-audit.md': 'a49525dc1b6958c95aeea6d8663eb3f3de453f01e4468b2468996b5c22046b80',
 'evidence/packaging-tamper-receipt.json': '1837690a1ec6aba0664bc5b60e5f2155ef64133c327f66aa22d22bf53e6030e2',
 'evidence/verifier-audit/independent-probes-optimized.json': '7a796c5ab33a9ecc92c93d32626d05be7333adff22f55fda73cba7bbc0dc89d2',
 'evidence/verifier-audit/independent-probes.json': 'b8cfaf864edc79971d838c2cc03a84376b0db3682d15b2b45b84e1fe92592f8e',
 'evidence/verifier-audit/probe_binding.py': 'bc94f777a3d2179bc70c6ba9d1a9ffe3c0ed3a6ada6f28bf6b5e16f63ac81242',
 'evidence/verifier-binding-audit.md': '45474a249c133e03ba9ac91a0c93bdae1670b921224215f4ee1f994884725ec4',
 'expected/normal/audit-emitter-receipt.json': '190b9d3087ccfbab169306ee405b90981d2945aa847dd7ef5b4c4acd8891dd94',
 'expected/normal/bitbound-audit.json': 'aab0e73af814219828f74227207c0925e0d1b77785f8e1758ebc5b82968d60f6',
 'expected/normal/example-validation-receipt.json': '3e2ea48bf32d3d2ff7df2c929de5a1d8f1f9f8225584830077c01ef38c028633',
 'expected/normal/independent-probes.json': 'b8cfaf864edc79971d838c2cc03a84376b0db3682d15b2b45b84e1fe92592f8e',
 'expected/normal/multisource-receipt.json': 'cd7d30bb1415adaa652dab0d6b80b26d01df7afe9fb1a538ba1f9d440ce0aba0',
 'expected/normal/receipt.json': '44b9ae895b563e82758b301d35eaafe931c6d6f9ebeb13938b75c256e4e81b83',
 'expected/normal/supplement-receipt.json': '31859ed91f579b3eb82237b55d98424877f17c51a600259a8e681e8e92e8a513',
 'expected/normal/verify_bundle.json': 'b8d903b066f426e6ad1c5832b69d661ed2b37826bad2a74e11a56d9be2dbeb2c',
 'expected/normal/verify_example.json': 'e5dc710346d209e8b369239fdcab68e85f8867e2d35c22749761e737c9945aea',
 'expected/optimized/audit-emitter-receipt-optimized.json': '190b9d3087ccfbab169306ee405b90981d2945aa847dd7ef5b4c4acd8891dd94',
 'expected/optimized/bitbound-audit-optimized.json': 'e684e58139c0efb9d44b82628100bea9391acdeea34712f312b174e33296de33',
 'expected/optimized/example-validation-receipt-optimized.json': '28c1eb014b154832ca61438bbfe02eb20a67240b9297807270c4272f87682125',
 'expected/optimized/independent-probes-optimized.json': '7a796c5ab33a9ecc92c93d32626d05be7333adff22f55fda73cba7bbc0dc89d2',
 'expected/optimized/multisource-receipt-optimized.json': 'c676332c923bcf72d71f0013bc2f1ef89be04a822a3b1b12793dfaf97d924e78',
 'expected/optimized/receipt-optimized.json': '8ad1ebfe18aa8942365d322c56b0c1021891926eb81a7961cbef8741d51fae55',
 'expected/optimized/supplement-receipt-optimized.json': 'b5d5f1a7ee1132216d9e76156b275f4ed92c77b74dc0d635acb81660ae85cdf9',
 'expected/optimized/verify_bundle.json': 'b8d903b066f426e6ad1c5832b69d661ed2b37826bad2a74e11a56d9be2dbeb2c',
 'expected/optimized/verify_example.json': 'e5dc710346d209e8b369239fdcab68e85f8867e2d35c22749761e737c9945aea',
 'replay_release.py': '3603e5aa8b5250320727ec3c42a24ec7840692ecc4b35cd5b2316437c2602fec',
 'report28-qa.json': '170a30e8c117001cc3f4afe61fbffc0e98e1908a9b22e0b70f64df6dea3bdf7b',
 'report28.pdf': 'e3d33f289909866434664cb656adb2a87254a42a3c94da050ba9e71223c5c7fb',
 'report28.tex': 'f04db398809193539d747ee2e8fbd5ae18818c2742c8647362f758d84211c7cd',
 'research/MANIFEST.json': '9f369b0a250b773c33f73213ec2e77e7c047118e9538e16c33cd84dfc625a31b',
 'research/PROOF.md': 'f10aea96e218475e2ceab30c5fff2a9454fb6e13295662ca18ff842a87f35636',
 'research/PROVENANCE.json': 'b52ba03d4b6989cf96c75a3401ff6167053978bfeb152797adf8dbfde2606d4e',
 'research/README.md': 'c47980d8c95716553891f3a856844c7857d651a3f0aee6caa241c1053d37a3e0',
 'research/REPLAY.md': '3e059d3e1e2e2c6c5dbe38abf635a671f6daafd3c27d21cbc2c31ba541d534f4',
 'research/RESULTS.md': 'a024044b1f4166f0a75d546104d93c4b02681e6e42ed095214739ee071725d4f',
 'research/SHA256SUMS': 'd17a5754eba8dd4ee15b7b9b4a8f6f4bc4247e00b3ba76530144e13dfb2b2493',
 'research/audit-design.md': 'a8e1108aac89d5ebead2a1fa6842d4df721110be60d853baad33870de8878f47',
 'research/audit-emitter-optimized.log': '64f32b6d6e69ffb3b44dae197787e4d6345430777888bee485f716261f6ab778',
 'research/audit-emitter-receipt-optimized.json': '190b9d3087ccfbab169306ee405b90981d2945aa847dd7ef5b4c4acd8891dd94',
 'research/audit-emitter-receipt.json': '190b9d3087ccfbab169306ee405b90981d2945aa847dd7ef5b4c4acd8891dd94',
 'research/audit-emitter-test.log': '64f32b6d6e69ffb3b44dae197787e4d6345430777888bee485f716261f6ab778',
 'research/audit-emitter.md': '98a785a8e6e02a0dee23881f749c402703a4961d80b1d42ef6c2007bb91207ec',
 'research/audit_emitter.py': '27b1c293865e8317c271b57286e9faf7e07e5e6535eb5ccb44b75d92a6938f2e',
 'research/bundle-verification-optimized.json': '98eae60438432382bc19af33a8c59a5368b7e84fca33cae67d79b77a112604d6',
 'research/bundle-verification.json': '98eae60438432382bc19af33a8c59a5368b7e84fca33cae67d79b77a112604d6',
 'research/check_portability.py': '58a534330b17b684a71d133e591f2047527b3e17e21bcb1ec2efe16618cb9271',
 'research/circuit.py': 'dca31e8c2de8f6f4c1ae3bd17b8fbe614d67a92debd3b6b782f2d75704c83066',
 'research/compiler.py': '133d811972b6332ddc2fadfa8a7e34f3076b4712affa7c757d60e90d3ea2f5aa',
 'research/example-pair-quartic.json': 'ddd6973f1285d60c2ae663b6b47cd933827e9e86c332cb69148c1ef45c27dca1',
 'research/example-pair-sos.json': '96715e468c3af4b489a1ce881ea0c09cdae7bffa0efca762d8e5a308c2ddbae0',
 'research/example-pair-witness.json': 'ef49bb8c56731827374123e215c608dd0d1468c8ee5fe234c2dd32524d0c2095',
 'research/example-source.json': '224fb8a1329103ed48c7fe40b1b26706198a0f1f1a8ecb7759cafb8132551874',
 'research/example-validation-receipt-optimized.json': 'afc70819e4027e8171e91892ecb58c30959be3060debeeccf200416d2803e6cd',
 'research/example-validation-receipt.json': '68065d44822da153f32c48adfd8c9b196b3cb390c0253bc59ed469829be4a40f',
 'research/example-verification-optimized.json': '060be8979bfd642e4a36d669dd031f88a8f2c8ebd35b59ca3894e2ab72f41ad6',
 'research/example-verification.json': '060be8979bfd642e4a36d669dd031f88a8f2c8ebd35b59ca3894e2ab72f41ad6',
 'research/fixture-provenance-rebind.json': '8ce160ae54f8d42a4134dcef28dd5ad1cb18d2413f535aba7cd35a0ef0fb7dec',
 'research/fixtures.json': '0b4b406e96bc495d59c67a5351d0be81466b0d2c6a5ab4f2458656b96a621239',
 'research/freeze_metadata.py': '653c14d29a1a002de708cd80ad88059e0ead31410b367204c339c15540221257',
 'research/frozen_lazy_source.py': '42e8aa65c05fcf373a03a02be51ebb89a4fdcb1f1070ad776ffe1e8e99049c61',
 'research/frozen_reversible_binary.py': 'f95a6028c9d3cc6f8b0b497cfc0cad68104da6d70e55205df04ad234e5d0c76f',
 'research/lineage/v1-MANIFEST.json': 'dc2106553312d36cbcd655e5e3551e52771682de0a1f7f27e91798561ecf90a0',
 'research/multisource-optimized.log': '0c24ec02e40c47f4ff958acb0e5659375b3e556982e55b8173bbdf5cd5502588',
 'research/multisource-receipt-optimized.json': '3977607303c2db13e00e55c3810309a081fa9e7507726db798026e2c40ac3eba',
 'research/multisource-receipt.json': '79da4237e135db046337cb511ddf5fab3000355a83717a8d37b3b0807dd2de40',
 'research/multisource.log': '55c9c7c4b25ac36fb1793ba980ce9a7c9ef4ffda9a1df8ade6428bbe99799210',
 'research/parallel_particles.py': '2c8b639646a587a51bddeaac16e46d2dbd8c4e8138ac67a2601025334d4a64cd',
 'research/portability-receipt.json': '6d1bd9ce874149ec5f06177c108658b66517eaafeb63782009367cf631a7996e',
 'research/prepare_test_oracle.py': 'c123d4ac794009057a225c9867712d971351d04c65d976d6125666e7eb6f254e',
 'research/receipt-optimized.json': '98402f9289cf9ca56465bfeb2484492d49f8900ff07d530dae7812f2f8760e58',
 'research/receipt.json': 'f91be87b9fc802433d408da5e62265bed4ccd2358878b11fbe8e92d0a9106aea',
 'research/references/COMPILER_PROOF.md': '55ecb9c26bf0c2ce929c97187013171f8b8ec52ee30cb9a8703b41b1d106a4e8',
 'research/references/PARALLEL_LEMMA_AUDIT.md': '435b547d2476230f9d532cc7ed7f5a52f779b6e5f241aaacb1d316c10e117dc1',
 'research/references/PARALLEL_PRESERVATION_AUDIT.md': 'c474f1fa73d4ced47b554fb73d91e020e834612dab00c5f8f8f7ce6afebe2e8b',
 'research/references/PARALLEL_RULE_PROOF.md': 'fe809adaa74418bcddafc61cc5ff70102724256c310ae53fd396c2fe34ef65c9',
 'research/references/PROOF.md': '28d5bdf44273790591f0043454c0f71644afbfec880eb980eee429e70fb4ae1c',
 'research/references/SOURCE_SCHEMA.md': '4929b248dcf3f604694d3abf7d9efbf4649f6a5f8219661f01fc3469e900dcd3',
 'research/references/test_sparse_parallel.py': '21b49ccd2730536b511aeca7ded6f466abca2d3ee89d7217cfb290a4a30ce45f',
 'research/resource-ledger.json': '1b03a28417554a3c9c42bb79e97991405653fb7fc768797a31d255c9f3af8d1b',
 'research/sparse_parallel.py': '785082d121622f8fc755ed7039ee6efe719964296eec7d76ad44495dc5c6c2c1',
 'research/supplement-optimized.log': 'd766b01a9f5c12fe67f517999dac786458391fa0c8b41d5e33b4357c00900e3f',
 'research/supplement-receipt-optimized.json': '3b526246cb04913e8092bf273abfbf86098f8eab9356fee10ed54d9b2b8cdae6',
 'research/supplement-receipt.json': '392d8821b8018ee15a577c1926d85121031e033420622f172293681e7afee401',
 'research/supplement.log': 'edef31f0b2e3f00b77ee6d8bc49c98cc228878ddc37735b97082218541118f89',
 'research/test-optimized.log': '1dfb1d4485b5d4a262e81387b81285eaf5b9593fea979c276128a9c666361b32',
 'research/test-oracle-receipt.json': '5fd34e8c39491563e3199f90e0de4fc5d1ed4b6907e05d569161b20e608777b1',
 'research/test-oracle-report.md': '09ebbe014816840b8557108afe33c4c4c858f272e7c138c2069e8fa8f217b855',
 'research/test.log': 'eb407b642234c3fadd074e0886859ce85ef2426d796bf0e32a059c5cc4e1748d',
 'research/test_certificate.py': '84f335db791f01c3f31a5e9d2a583d16b973a944caa2f456a2a4e99f5ab3b4ad',
 'research/test_example_validation.py': 'a7717135b8ad46880770cfc71050f66c88906f180c937f1a4f072fcd932b607f',
 'research/test_multisource.py': 'dad437dc85e7036070932c1a193e263b387f7c7220142506cdd923d560a8c655',
 'research/test_supplement.py': '00acdc256b92b6306b1a4609cf67ee17ce54042a4ec397fc86f3dbd96d10cc34',
 'research/verify_bundle.py': '0b092aec60f21c0603e080ffc7a1a6c390387dbae8be88b86dd486324cb15d66',
 'research/verify_example.py': 'd94aaee61d794f0c8ff8febc9334675f23f6c238df43eb88609982ae3026a9bd',
 'test_release_integrity.py': '62469d2816c1c7f9c433023239aad987bde59d3c0864c370978c269c9353052e',
 'write_manifest.py': '6b2a30d73b7bd9021c0f36c0b59ee7bbe5206e84cede40486e1ae60ec897d153'}
BASES = ('receipt','supplement-receipt','multisource-receipt','audit-emitter-receipt','example-validation-receipt','verify_example','verify_bundle','independent-probes','bitbound-audit')
def need(ok, message):
 if not ok: raise ValueError(message)
def pairs(items):
 result={}
 for key,value in items:
  need(key not in result, 'duplicate JSON key: '+key);result[key]=value
 return result
def reject_constant(value): raise ValueError('nonfinite JSON constant: '+value)
def load(path): return json.loads(Path(path).read_text(),object_pairs_hook=pairs,parse_constant=reject_constant)
def same(a,b,where='receipt'):
 need(type(a)is type(b),where+': type mismatch')
 if type(a)is dict:
  need(set(a)==set(b),where+': field-set mismatch')
  for k in a:same(a[k],b[k],where+'.'+k)
 elif type(a)is list:
  need(len(a)==len(b),where+': list length mismatch')
  for i,(x,y)in enumerate(zip(a,b)):same(x,y,where+'['+str(i)+']')
 else:need(a==b,where+': value mismatch')
def semantic(receipt,optimized):
 need(type(receipt)is dict,'receipt object required')
 result=dict(receipt)
 if 'seconds'in result:
  value=result.pop('seconds');need(type(value)in(int,float)and math.isfinite(value)and value>=0,'invalid elapsed seconds')
 for field in ('optimized','optimized_python'):
  if field in result:
   need(type(result[field])is bool and result[field]is optimized,'invalid optimized mode');result.pop(field)
 return result
def receipt_name(base,optimized):
 return base+('-optimized'if optimized and base not in('verify_example','verify_bundle')else'')+'.json'
def compare_receipt(actual,base,optimized):
 ref=load(ROOT/'expected'/('optimized'if optimized else'normal')/receipt_name(base,optimized))
 need(type(actual)is dict and set(actual)==set(ref),'receipt field-set mismatch: '+base)
 same(semantic(actual,optimized),semantic(ref,optimized),base)
def inventory(root):
 out={}
 for p in [root]+sorted(root.rglob('*')):
  name='.'if p==root else p.relative_to(root).as_posix();s=p.lstat()
  need(not stat.S_ISLNK(s.st_mode),'symlink forbidden: '+name)
  row={'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns}
  if stat.S_ISDIR(s.st_mode):row['kind']='directory'
  elif stat.S_ISREG(s.st_mode):row.update(kind='file',bytes=s.st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
  else:raise ValueError('nonregular entry: '+name)
  out[name]=row
 return out
def verify():
 manifest=load(ROOT/'RELEASE-MANIFEST.json')
 need(set(manifest)=={'schema','release_id','source_manifest_sha256','original_source_manifest_sha256','files','directories'},'manifest schema')
 need(manifest['schema']=='report28-exact-release-v1','manifest format')
 need(manifest['release_id']=='parallel-quartic-release-20261003','release identity')
 need(manifest['source_manifest_sha256']==CORE_PIN,'core manifest binding')
 need(manifest['original_source_manifest_sha256']=='dc2106553312d36cbcd655e5e3551e52771682de0a1f7f27e91798561ecf90a0','lineage binding')
 files=manifest['files'];dirs=manifest['directories'];need(type(files)is dict and type(dirs)is dict,'manifest inventories')
 state=inventory(ROOT);actual_files={k for k,v in state.items()if v['kind']=='file'};actual_dirs={k for k,v in state.items()if v['kind']=='directory'}
 need(actual_files==REQUIRED_FILES,'hardcoded required file inventory mismatch')
 need(actual_dirs==REQUIRED_DIRECTORIES|{'.'},'hardcoded required directory inventory mismatch')
 need(actual_files==set(files)|{'RELEASE-MANIFEST.json','RELEASE-SHA256SUMS'},'exact file inventory mismatch')
 need(actual_dirs==set(dirs)|{'.'},'exact directory inventory mismatch')
 for name in ('RELEASE-MANIFEST.json','RELEASE-SHA256SUMS'):need(state[name]['mode']==0o644,'metadata mode mismatch: '+name)
 for name,row in files.items():
  path=PurePosixPath(name);need(not path.is_absolute()and '..'not in path.parts and str(path)==name,'unsafe manifest path')
  need(type(row)is dict and set(row)=={'bytes','mode','sha256'},'file record schema')
  need(type(row['bytes'])is int and row['bytes']>=0 and type(row['mode'])is int,'file record types')
  same({k:state[name][k]for k in row},row,name)
 for name,mode in dirs.items():need(type(mode)is int and state[name]['mode']==mode,'directory mode mismatch')
 for name,pin in PINS.items():need(state[name]['sha256']==pin,'pinned scientific source mismatch: '+name)
 for name,pin in IMMUTABLE_PINS.items():need(state[name]['sha256']==pin,'immutable required file mismatch: '+name)
 # Independently verify every entry of the already byte-pinned core manifest.
 # This occurs before any subprocess, including the inner bundle verifier.
 core=load(ROOT/'research'/'MANIFEST.json');need(type(core['files'])is dict,'core file table schema')
 extra_core={'MANIFEST.json','SHA256SUMS','bundle-verification.json','bundle-verification-optimized.json'}
 actual_core={k[len('research/'):]for k in actual_files if k.startswith('research/')}
 need(actual_core==set(core['files'])|extra_core,'core inventory mismatch')
 for name,record in core['files'].items():
  path=PurePosixPath(name);need(not path.is_absolute()and '..'not in path.parts and str(path)==name,'unsafe core manifest path')
  need(type(record)is dict and set(record)=={'bytes','sha256'},'core record schema')
  need(type(record['bytes'])is int and record['bytes']>=0 and type(record['sha256'])is str,'core record types')
  same({k:state['research/'+name][k]for k in record},record,'pinned core manifest entry '+name)
 for name in extra_core:need(state['research/'+name]['sha256']==IMMUTABLE_PINS['research/'+name],'extra core file pin mismatch')
 expected_sums={name:state[name]['sha256']for name in files};expected_sums['RELEASE-MANIFEST.json']=state['RELEASE-MANIFEST.json']['sha256']
 supplied={}
 for line in(ROOT/'RELEASE-SHA256SUMS').read_text().splitlines():
  digest,sep,name=line.partition('  ');need(bool(sep)and name not in supplied,'checksum record schema');supplied[name]=digest
 same(supplied,expected_sums,'checksum list')
 for base in BASES:
  a=load(ROOT/'expected'/'normal'/receipt_name(base,False));b=load(ROOT/'expected'/'optimized'/receipt_name(base,True))
  need(set(a)==set(b),'reference mode schema mismatch '+base)
  same(semantic(a,False),semantic(b,True),'reference modes '+base)
 companion=load(ROOT/'bitbound'/'MANIFEST.json')
 for name,pin in companion['files_sha256'].items():need(state['bitbound/'+name]['sha256']==pin,'companion file pin mismatch')
 for name,pin in companion['source_inputs_sha256'].items():need(state['research/'+name]['sha256']==pin,'companion source input mismatch')
 command=[sys.executable,'-B']+(['-O']if not __debug__ else[])+[str(ROOT/'research'/'verify_bundle.py')]
 run=subprocess.run(command,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True)
 need(run.returncode==0,'inner scientific bundle verification failed: '+run.stderr)
 compare_receipt(json.loads(run.stdout,object_pairs_hook=pairs),'verify_bundle',not __debug__)
 return {'status':'PASS','files':len(actual_files),'directories':len(actual_dirs),'source_manifest_sha256':CORE_PIN,'typed_mode_references':True,'strict_inventory':True,'hardcoded_required_inventory':True,'preexecution_core_pins':True,'immutable_expected_evidence_deliverables':True}
if __name__=='__main__':print(json.dumps(verify(),sort_keys=True))
