# Report 175 — Planar maximum density kings

3 October 2026

This is a complete offline source-and-certificate package for the accompanying report. It proves, for maximum placements on ordinary 2h × 2w boards, the reduced-denominator bounds

    factor degree d <= floor(h/2)+1
    factor exponent e <= h-2d+3

The proof holds entrywise for the full transfer resolvent. It proves the assertion recorded as Kotěšovec's page-83 Conjecture 4, without claiming historical first priority or all-height degree attainment. It also gives the exact eventual fixed-height exponential-polynomial expansion, Wilf's dominant linear term, a Lambert W real inverse, its first explicit exponentially small correction, and a two-ceiling integer threshold bracket. Nothing here is uniform in growing height.

## Read and verify

- `Report175.pdf` is the compiled report
- `report.tex` is its complete standalone LaTeX source
- `SOURCES.md` contains attribution and primary-source URLs
- `README_CODE.md` documents the arithmetic and the certificate schema
- `data/certificates.json` holds exact coefficient arrays and certificates through h=6
- `verify.py` uses only the Python standard library
- `regenerate.py` optionally rebuilds the data using an installed SymPy

From an extracted archive:

    python3 -B verify_manifest.py
    python3 -B verify.py
    python3 -B guard_tests.py

The default checks heights 1 through 4 and six widths per height. Explicit extended verification checks all six heights:

    python3 -B verify.py --extended
    python3 -B -O verify.py --extended
    python3 -B guard_tests.py --extended

Normal and optimized results must agree. All mathematical validation uses active exceptions, not removable assertions. Guard tests exercise arithmetic, nilpotent transients, intentionally corrupted data, and the extended-scope opt-in. The archived extended receipts are in `data/verified_results.json` and `data/guard_results.json`; build-generated receipts describe the scope of that particular build.

The verifier independently constructs physical states and transfers, checks Gram/resolvent identities, compares a separate physical-row all-cardinality dynamic program, and certifies the complete rational generating functions using N consecutive exact recurrence residuals plus polynomial coprimality. This is an all-width Cayley–Hamilton certificate, not fitted-prefix extrapolation. The optional regeneration uses the product of full block characteristic determinants and an N-slot adjugate numerator, so it likewise does not require a fitted recurrence.

## Rebuild the PDF and complete archive

Prerequisites: Python 3.10 or later and a local TeX installation with pdfLaTeX, Latin Modern, AMS math, mathtools, array, microtype, geometry, hyperref, xcolor, enumitem, booktabs, and fancyhdr. No network access, package installation, shell escape, or external code downloads are used.

Choose a new directory whose parent already exists:

    python3 -B build.py --output ../fresh-report175

This runs exact verification and corruption guards in ordinary and optimized Python, validates build guards, compiles stable TeX references, rejects overfull boxes and missing characters, and creates:

    Report175.pdf
    Report175.tex
    Report175.zip
    ARTIFACTS.json

For an extended build, append `--extended`. The source tree remains unchanged. Existing output directories, including symlinks, are rejected before work begins. The builder copies only an explicit allowlist to an isolated temporary tree. If the local TeX format is missing, it initializes a temporary format from installed TeX files and never modifies a global TeX cache.

The archive has fixed timestamps and file modes, sorted entries, and a SHA-256 manifest. Two builds from identical sources using the same Python/TeX stack should have identical PDF and ZIP bytes. Byte identity across different TeX versions is not promised. Run `python3 -B verify_manifest.py` before modifying an extracted source tree: it intentionally rejects added files, including unrequested bytecode caches, as well as missing or changed files. Use `-B` for ordinary verification commands.

## Scope and limits

All conclusions about asymptotics and inverses are fixed-height statements. The integer threshold bracket eventually spans zero or one integer; the real uncertainty before taking ceilings is exponentially small. The big-O constants are not a finite numerical certificate for a chosen threshold. Degree attainment at every height, sharper low-degree multiplicities, cancellation criteria, height-uniform estimates, and effective large-threshold certificates remain separate questions.

Primary PDFs, books, third-party source code, and internal research notes are not included. Follow the cited URLs for the original literature.
