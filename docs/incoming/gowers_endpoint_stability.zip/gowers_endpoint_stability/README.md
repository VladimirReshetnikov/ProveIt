# Sharp second-order stability at the polynomial-phase endpoint of Gowers norms

A research manuscript prepared for integration into the ProveIt Ramsey collection.

## Main statement

Let `d >= 2`, `q = 2^d`, `G` be a nontrivial finite abelian group, and `|f| <= 1`.
All averages are normalized. Define

- `epsilon = 1 - ||f||_{U^d(G)}^q`;
- `D_d(f) = min_P E |f-P|^2`, over unit-modulus phase polynomials of degree at most
  `d-1` in the multiplicative-difference sense, including nonclassical phases.

The article proves, uniformly in `G` as `epsilon -> 0`,

```text
D_d(f) <= (2/q) epsilon + b_d(G) epsilon^2 + O_d(epsilon^3),

b_d(G) = (3^d - 1)/(2*4^d)  if |G| is odd,
         (1 - 4^(-d))/3      if |G| is even.
```

Both coefficients are attained asymptotically on every fixed nontrivial group
of the indicated parity. The optimal stability modulus has the corresponding
expansion with a uniform cubic error. The article also proves a continuous
two-torsion Fourier profile, a fifth-order real-part cancellation, and a tangent
classification for second-order extremizers.

For `d=3`, the second coefficients are `13/64` in odd order and `21/64` in even
order. A candidate quadratic phase with correlation at least `1 - 1/88` admits
a fully explicit local certificate. The exact optimal even-group `U^2` modulus
on cubical defects in `[0,1/2]` is included as an elementary calibration.

## Files

- `article.tex`: standalone LaTeX source, with an internal bibliography.
- `article.pdf`: compiled article.
- `build.sh`: LaTeX build command.
- `code/verify.py`: reproducible integer, rational, floating, and high-precision checks.
- `data/verification_results.json`: executed verification output.
- `data/document_validation.json`: build and PDF-layout validation summary.
- `requirements.txt`: computational dependencies.
- `SOURCE_AUDIT.md`: primary sources, repository scope, and priority limitations.
- `FORMALIZATION_PLAN.md`: a modular formalization plan; no unverified Lean code.
- `PROOF_CHECKLIST.md`: important proof obligations and how they are discharged.

## Build and run

With a reasonably complete TeX Live installation:

```sh
./build.sh
```

The source uses `newtxtext`, `newtxmath`, `amsmath`, `amsthm`, `mathtools`,
`microtype`, `booktabs`, `enumitem`, `fancyhdr`, `hyperref`, `aliascnt`, and `cleveref`.
No external figures or bibliography database are required. No font files are
included in this package.

For the computational diagnostics:

```sh
python -m pip install -r requirements.txt
python code/verify.py --output data/verification_results.json
```

The script has no network dependency and uses seed `20261006` (with a separate
`20261008` stream for the full-interval U^2 diagnostics). It fails with an
assertion error on any failed check. Running Python with `-O` would disable these
assertions and must not be used for verification.

## Status and scope

This is an AI-assisted research draft, not a refereed publication. The proofs
are presented in full except for the explicitly imported Eisner–Tao qualitative
entry theorem. The local theorem and its explicit constants do not need that
entry theorem once a phase candidate satisfying the stated correlation condition
has been supplied.

The global small-defect threshold is asserted to exist uniformly by the published
entry theorem; a numerical value is **not** extracted here. In contrast, the local
radius and cubic upper constant are displayed explicitly. The sharpness concerns
the first two coefficients, not the displayed cubic upper constant or local radius.

The finite diagnostics are **not** proof-assistant verification. No Lean proof is
included or claimed. No new global Szemerédi bound or resolution of the repository's
open general inverse/integration statements is claimed. Publication priority of
the refined endpoint statements remains unestablished.

## Suggested integration

Suggested new directory:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/polynomial-phase-endpoint-stability/
```

Alternatively, integrate thematically with label prefixes. Do not replace a
Prop-valued catalogue declaration with a reference to this article as though a
Lean theorem had been supplied. The current package changes no repository files.
