RESEARCH PACKAGE FOR PROVEIT
Spectral transfer and hereditary third-energy rigidity
Prepared 7 October 2026

This package contains two independent research papers, their complete LaTeX
sources, compiled PDFs, and reproducible verification programs. It was prepared
in response to a request for research near the intersection of openai/math and
ProveIt. SOURCE_REVIEW.txt records the exact repository snapshots, source
locations, selection rationale, and limits of the source review.

CONTENTS

  spectral_transfer/spectral_transfer.tex
  spectral_transfer/spectral_transfer.pdf
  spectral_transfer/code/spectral_checks.py
  spectral_transfer/data/spectral_validation.json

  third_energy/third_energy.tex
  third_energy/third_energy.pdf
  third_energy/small_cyclic_m3.py
  third_energy/small_cyclic_m3.json
  third_energy/verify_third_energy.py

  README.txt
  SOURCE_REVIEW.txt
  MANIFEST.sha256

The papers are self-contained and can be integrated separately. Neither paper
depends on the other. No copies of third-party manuscripts or source archives
are included.

1. SPECTRAL TRANSFER FOR FINITE-FIELD CONSTRAINTS AND COMPRESSED
   REFLECTION-POSITIVE LAWS

The starting point is the finite-field graph and tuple construction in
openai/math's square-difference manuscript, within Family 182. Its original
whole-list mixing estimate is (32m)^(1/4) p^(-1/8) for m constraints. The new
paper proves a replacement estimate at the single-edge spectral scale.

For a simple bipartite constraint graph, independent coordinate measures,
kernels satisfying |W_e| <= 1, constants 0 <= d_e <= 1, and single-edge
operator errors ||W_e-d_e|| <= epsilon_e, the whole-list operator error is at
most

  sum_j epsilon_{pi(j)} product_{i<j} d_{pi(i)}.

The tests may be arbitrary L2 functions of each complete side of the graph.
The paper proves the optimal ordering for this bound. Repeated constraints
on the same endpoint pair are outside this theorem's simple-graph hypothesis.

For nonzero square differences over an odd prime field, the bound becomes
2(1-2^(-m)) Delta_p, where

  Delta_p = (sqrt(p)+1)/(2p)  if p = 1 mod 4,
  Delta_p = sqrt(p+1)/(2p)    if p = 3 mod 4.

Thus the list estimate has order p^(-1/2), and a single-edge example shows
that this exponent is optimal uniformly over all such patterns. A fixed-index
multiplicative-subgroup version is also proved.

The paper then reconstructs and reparameterizes the source's permutation-block
tuple architecture. Choosing marking weight A p^(-1/2), with an explicit fixed
positive A large enough, reduces its 161 blocks to 17 while retaining the
required reflection positivity, uniform one-coordinate marginals, designated
pair law, and exceptional-mass target at most p^(-4), for sufficiently large p.
The new exceptional mass is asymptotic to a positive constant times p^(-9/2).
The conditional L2 norm is Theta(p^(-1/4)); matching upper and lower bounds
are proved. The lower bound detects triple collisions in the marked mixture.
This sharpness statement concerns the constructed family, rather than every
possible reflection-positive coupling.

All results in this paper have analytic or finite algebraic proofs. Its code
provides supporting checks and numerical diagnostics; no theorem relies on
floating-point computation. The source's global theorem about integer sets is
not an assumption, and a new global integer square-difference exponent is not
claimed. Propagating these finite improvements through the remaining arithmetic
argument is explicitly left open.

2. SHARP THIRD-ENERGY RIGIDITY AND HIGHER-ENERGY FINGERPRINTS
   OF INDEX-TWO DEFECTS

For a full-domain map a:G -> H between arbitrary abelian groups, let r_m(a)
be the infimum, over nonzero finitely supported nonnegative weights, of the
fraction of ordered additive 2m-tuples whose equality of sums is respected by
a. Repetitions are allowed. The indicator version restricts to finite nonempty
sets with their indicator weights.

The main theorem proves

  a is affine  <=>  r_3(a) > 5/8  <=>  r_{3,ind}(a) > 5/8.

The threshold is sharp. For integer parity, the infimum is exactly 5/8 even
though every individual finite-weight ratio is strictly larger. The infimum
quantifier, or equivalently a uniform positive margin above the threshold,
cannot be replaced by separate strict inequalities for each finite test.

The paper develops an index-two family with defect
eta = 2u - psi(2t), defined without dividing by two or extending a subgroup
homomorphism. For a nonzero defect of order d it proves the exact values

  r_m = r_{m,ind} = 1/2 + 2^(-m)            when d = 2;
  r_m = r_{m,ind} = 2^(1-2m) binom(2m,m)  when d > m/2,

including infinite order in the second case. At order four these give 9/16
for order-two defects and 35/64 for all other nonzero defects. A further theorem
gives the sharp bound 1/2 + 2^(1-2m) for nonaffine maps that are affine on every
coset of every cyclic subgroup. An exact interval formula quantifies the
approach of integer parity to the third-energy endpoint.

The universal third-energy theorem includes a computer-assisted finite lemma.
The manuscript reduces all abelian targets, including infinite targets, to an
explicit finite integer and finite-field incidence calculation for cyclic
domains of orders at most five. The supplied generator performs that complete
calculation. This is not a search limited to a chosen list of target groups.
The arbitrary-group reduction is proved in the paper. The higher-energy
index-two formulas and the cyclic-coset theorem have separate analytic and
algebraic proofs independent of this finite enumeration.

The general threshold r_m <= 1/2+2^(-m) for all nonaffine maps at m >= 4,
the complete third-energy endpoint classification, and the remaining finite
defect-order cases d >= 3 with m >= 2d are open in this package.

3. BUILDING THE PAPERS

Use a TeX installation providing the packages declared in each source file.
The bibliographies are included in the TeX files; no bibliography download or
external repository checkout is needed. From the extracted package root:

  cd spectral_transfer
  latexmk -pdf -interaction=nonstopmode -halt-on-error spectral_transfer.tex

Separately, from the package root:

  cd third_energy
  latexmk -pdf -interaction=nonstopmode -halt-on-error third_energy.tex

If latexmk is unavailable, run pdflatex with the same options until references
and the table of contents settle. No shell-escape option is needed.

4. REPLAYING THE VERIFICATION

Run Python normally; do not use python -O, since the verifiers use assertions.

Third-energy verification needs Python 3 and its standard library only. From
third_energy/ run:

  python3 small_cyclic_m3.py
  python3 verify_third_energy.py

Keep the two Python files and the JSON certificate beside one another. The
first command regenerates the certificate on standard output. The second
regenerates it, compares it with the stored certificate, independently counts
ordered triples, checks the small-cycle attaining examples, and performs exact
bounded checks of the four-point identity, wrapped denominators, interval
formula, and additional higher-energy examples. Its four PASS lines describe
these checks. The finite census and its mathematical completeness argument
have a proof role; the additional bounded examples are supplementary checks,
not proofs of their infinite families.

Spectral verification additionally needs NumPy. From spectral_transfer/ run:

  python3 code/spectral_checks.py --output data/spectral_validation.json

This regenerates the supplied record. The program labels exact rational checks
separately from floating-point diagnostics, uses a fixed random seed, and
records runtime versions. Floating-point entries can vary slightly across
NumPy and platform versions. These tests check small instances and identities;
they do not enumerate the enormous 24-symbol tuple construction. Its proof is
the finite matrix and symmetry argument in the manuscript.

5. RESEARCH AND INTEGRATION STATUS

These are OpenAI-assisted research reports with explicit proofs, source
attribution, and reproducible checks. They are not presented as externally
peer-reviewed publications or proof-assistant-certified developments. No Lean
formalization is included. Repository formalizations mentioned in the source
review concern their own selected statements, not the new results here.

Proposed contributions are distinguished from inherited constructions in each
paper. Priority beyond the sources reviewed has not been exhaustively checked.
Before publication, further independent mathematical review would be valuable,
especially for the characteristic reduction in the companion's finite lemma
and the conditional-norm lower bound in the main paper.

The papers contain detailed research agendas: sharper positivity constants,
alternative couplings avoiding the collision obstruction, smaller block
designs, complete arithmetic propagation, higher-energy thresholds, endpoint
classification, finite-weight stability, and optimal witness complexity.
Their natural ProveIt integration area is the existing
Combinatorics/Ramsey/Research/GowersSzemeredi research collection. Preserve the
source/dependency ledgers and keep computer-assisted claims distinguished from
supporting diagnostics when incorporating the results.

INTEGRITY

MANIFEST.sha256 records the SHA-256 digest of each supplied source, PDF,
program, data file, and note. From the extracted package root, systems with
sha256sum can check the files with:

  sha256sum -c MANIFEST.sha256
