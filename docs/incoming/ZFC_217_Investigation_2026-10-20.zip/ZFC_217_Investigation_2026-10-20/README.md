# ZFC consistency machines: self-vacuity and the 217-state boundary

**Outcome: no valid blank-tape machine with 217 working states or fewer was obtained.**

This is a research-continuation packet for Vladimir Reshetnikov's ProveIt repository, pinned to commit `9adcaff0a72486ecc81242e0eca86e428c74879e`. It contains the LaTeX article `report.tex`, its compiled `report.pdf`, reproducible mathematical certificates, explicit countermodels, machine/source search code, exact input tables, and scoped search results.

The 217-state table in `core217/` is **not a consistency candidate**. Its complete initialized runtime is proved, but its blank run enters an unconditional infinite ray after 85 transitions. This failed initialization is supplied as a proved obstruction, not an omitted obligation.

## Principal results

### A calibrated one-parameter replacement for the classical row

Keep the exact native C222 calculus except for unrestricted rho8, and replace rho8 by K, S and

```text
SV(A) = A → Q_A A.
```

The formula's own numerical code is a fresh binder by the inherited `D_fr_self` property. The new contribution is using this fact to recover unrestricted classicality from a one-parameter row. Its double-negated version also suffices. Both replacement calculi have consistency provably equivalent to Con(ZFC) in ZFC.

The lower proof recovers DNE and every unrestricted rho8 instance. A 1,110-node Hilbert certificate replays the finite derivations. The upper proof extends the inherited decoded-theory interpretation, using its exact decoder and its implication equivalence **in the irreflexive comparison theory**. No new Lean/Rocq endpoint is claimed; equality of the old and new native theorem sets is not claimed.

The measured direct encodings have 212 and 214 distinct source subtrees, compared with K218's 205. They are calibrated alternatives, but no machine-size improvement follows from these measurements.

### A verified initialized 217-state core with a proved blank-start failure

Delete public K218 state 301 and change three retained rows:

| Row | Old | New |
|---|---|---|
| 87/0 | 0R301 | 0R88 |
| 88/0 | 0R122 | 0L51 |
| 51/0 | 0R16 | 0R122 |

The exact core has 217 working states and 434 transitions. Its full symbolic replay proves all 6,167 guarded primitive cases, using 1,515,310 symbolic rules and all 434 rows, with arbitrary natural registers, extra gap, first spare and finite spare tail. A negative dispatch-to-halt control is rejected.

On blank input, it reaches state 35, head 7 and one-cells `{-3,-2}` after 85 steps. Row `35/0 = 1R35` then gives a direct induction proving nonhalting. A separate positive control reproduces public K218's entire 312,909-step initialization and complete tape.

### Larger searches, explicit obstructions and corrected diagnostics

- Every pair of working states, with both replacement rows arbitrary: **17,985,362,752 complete assignments covered** in each of two separately specified domains, zero survivors. Coverage uses partial-assignment pruning; it is not that many separately simulated tables.
- A complemented predecessor-marker relation: **3,715,236,224 assignments covered**, zero survivors, with a separate checked synthetic example demonstrating the method.
- Shared source dictionaries, open reassociations and register-independent commutations did not improve the 205-node source. The largest dictionary run recorded **1,543,294** dictionaries.
- 1,190 new 205-node source layouts were allocated; 353 passed decoder-prefix checks, 837 failed, and the best physical count remained 218. These allocations have not been promoted to verified machines.
- A four-valued model validates the complete native calculus with rho8 restricted to `B=C`, proving that weakening consistent. A different diagnostic for `B=0` has only propositional scope. A 16-element Heyting algebra refutes a proposed logical-fragment induction shortcut.
- A first-dispatcher discovery filter was corrected to recognize the complete runtime frame. All reported accepted results use the appropriate stronger obligations.

Negative bounded-filter results are not semantic counterexamples or state lower bounds. Search families overlap and are not summed as distinct machine coverage.

## Layout

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf` | Main mathematical report, explicit definitions and proofs, experiment scope |
| `formalism/` | Self-vacuity proof, exact source measurements, countermodels, standalone replay scripts |
| `core217/` | Exact initialized core, pinned symbolic engine, construction/runtime/blank-failure evidence |
| `baseline218/` | Accepted public K218 table/source and inherited attribution |
| `machine-search/` | Two-action and complemented-marker synthesis, masks, controls, checked incoming 218 alternate |
| `source-search/` | Source grammars, beam/dictionary search, allocation census and exploratory examples |
| `root-search/` | Complete-frame discovery and initializer experiments, with corrected diagnostic |
| `references/` | Pinned primary decoder/soundness sources and independent audit |
| `results/` | Original root experiment receipts; historical paths are provenance, not commands |
| `SHA256SUMS` | Manifest of delivered file bytes |

## Quick verification

Python 3.11 or later is sufficient for the quick checks; keep assertions enabled. No network or installed ProveIt checkout is needed for these commands:

```sh
python3 -B verify_packet.py
```

This checks the delivered manifest, replays the finite formalism certificates, reconstructs the core, proves its blank-start ray, replays the accepted startup control, and validates the finite source-grammar inputs. It also checks the recorded complete runtime census. It does **not** replace the full symbolic runtime replay.

To reprove all unbounded primitive contracts:

```sh
python3 -B core217/check_core.py --runtime --output /tmp/core217-fresh
```

The delivered replay completed in about two minutes. Wall time depends on the host. The source measurement takes about a minute:

```sh
python3 -B formalism/measure_self_vacuity.py --output /tmp/self-vacuity-measurement
```

For longer transition and source searches, follow the corresponding subdirectory README. C++17 is needed for the fast search engines. Some optional machine searches take `--repo /path/to/ProveIt` and verify or identify their exact repository inputs. Search time bounds, compiler/library dependence of seeded shuffles, incomplete proof filters and all remaining obligations are stated there.

Build the PDF with a standard LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Attribution and proof level

The original calculus, source compiler, binary engines, prior reductions and existing formal verification remain credited to their authors. See the retained attribution notices and MIT No Attribution license. The new material comprises the self-vacuity replacement analysis, explicit diagnostics, expanded source/table searches, initialized-core composition and replay, and this report, prepared with parallel ChatGPT-assisted analysis and independent review.

The requested 217-state blank-tape construction remains open in this packet. There is no claim of a newly checked proof-assistant theorem or an internal PA equivalence for the new initialized core.
