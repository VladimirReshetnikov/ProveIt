# Report144

## Asymptotics and a computable exponential rate for a proportional placement game

The report proves the full leading equivalent W_n ~ r_* sqrt(2πn) r_*^n and convergence W_(n+1)/W_n → r_* for the exact proportional-policy winning probabilities associated with OEIS A398540. The positive rate r_* is computable, and the finite rational certificate gives 527/1000 < r_* < 79/125. The report does not certify the posted OEIS decimal expansion.

Self-contained proofs cover the probability recurrence, balanced merging, uniform beta-bin kernel expansion and strict lower bound, the real-axis pole and logarithmic second term, cumulative laws, a subpower induction, a positive Riccati defect, and uniform complex modulus control for Cauchy coefficient extraction. The report also gives a logarithmically refined generating-function inverse and a Lambert-W first-passage inverse with vanishing uncertainty inside integer ceilings.

Higher pointwise correction terms, monotonicity of the consecutive ratios, additional certified digits and policy optimality are not established. Eventual decrease of W_n itself follows from the proved ratio limit; it is distinct from monotonicity of the ratios.

## Contents

- `Report144.pdf`: the article
- `Report144.tex`: editable LaTeX source
- `SOURCES.md`: primary source links and bibliographic details
- `companion/`: exact standard-library Python verifier, full rational fixture, adversarial tests, schema and methods
- `bundle.py`: integrity verification, deterministic PDF rebuild and deterministic ZIP creation
- `manifest.json`: closed file list with SHA-256 digests

No primary-source PDFs, private notes, build caches, or external report dependencies are included.

## Exact verification

From the extracted `Report144` directory, using a trusted Python 3.9 or later:

```sh
python3 -I bundle.py verify
python3 -I companion/verify_certificate.py
python3 -I -O companion/verify_certificate.py
python3 -I companion/test_verifier.py
python3 -I -O companion/test_verifier.py
```

The companion recomputes all W_0 through W_100 by two independent exact representations of the beta-bin weights, checks every rational probability, and proves the finite certificate inequalities with exact integers and fractions. No floating arithmetic, tolerance, timing measurement or extrapolation supplies any certificate comparison. Each verifier invocation reruns both mathematical routes; hashes alone are not accepted as semantic evidence.

The fixture validator uses a closed typed schema, explicit checks preserved by optimization, canonical hexadecimal rational encodings, and duplicate-key rejection. The supplied adversarial suite has 130 tests covering malformed data, numerical mutations with updated hashes, startup isolation and output containment. See `companion/README.md` for details and optional secure output commands.

The finite certificate depends on the analytic rate, global kernel upper bound and Catalan-majorant theorems in the article. Running the code does not machine-check those proofs or establish any coefficient asymptotic theorem.

## Rebuilding the PDF

The supplied build was tested with pdfTeX 1.40.26, TeX Live 2025/dev/Debian, and the standard `article`, `geometry`, `fontenc`, `lmodern`, `microtype`, `amsmath`, `amssymb`, `amsthm`, `booktabs` and `hyperref` packages. The build script uses the standard Debian TeX trees `/usr/share/texlive/texmf-dist` and `/usr/share/texmf`. Other TeX distributions may require adaptation and may produce different PDF bytes without changing the mathematics.

Choose a new output directory outside the package whose parent already exists. For example, if the package is `/tmp/Report144`:

```sh
cd /tmp/Report144
python3 -I bundle.py build-pdf --output-dir /tmp/report144-build-one
python3 -I -O bundle.py build-pdf --output-dir /tmp/report144-build-two
cmp /tmp/report144-build-one/Report144.pdf /tmp/report144-build-two/Report144.pdf
```

The script refuses an existing output directory, source-tree/ancestor outputs, parent-traversal components, and symlink components. It copies the source into the new directory, generates a fresh LaTeX format there, supplies explicit font maps, disables shell escape, sanitizes the TeX environment, and compiles twice. All build caches and logs are inside the output directory. It fixes the source date and suppresses volatile PDF metadata. `build-result.json` reports the resulting PDF digest and whether the bytes match the supplied PDF. Reproducibility across different TeX installations is not promised.

The path checks protect against existing unsafe paths and source overwrite. They assume no hostile same-user process concurrently renames the chosen output tree during the TeX build. A trusted Python interpreter, system standard library and TeX installation remain part of the trusted base. The companion's optional certificate-file writer has the stronger descriptor-relative no-follow/exclusive-create boundary documented separately.

## Repacking the ZIP

```sh
python3 -I bundle.py pack --output-dir /tmp/report144-pack-one
python3 -I -O bundle.py pack --output-dir /tmp/report144-pack-two
cmp /tmp/report144-pack-one/Report144.zip /tmp/report144-pack-two/Report144.zip
```

Again, both output directories must be new, outside the package, with existing parents. The ZIP contains only the manifest's explicit members plus the manifest, under a `Report144/` prefix. Sorted members, fixed timestamps, fixed permissions and uncompressed storage make repacking deterministic without a compression-library-version dependency. Build or test output folders are never implicitly included.

The manifest detects changed package bytes, but it is not a signature: an adversary able to change the manifest can also replace hashes. Authenticate the artifact hash through a trusted channel when provenance matters. The exact fixture verifier still independently recomputes all numerical semantics even if the fixture's own hashes are changed.
