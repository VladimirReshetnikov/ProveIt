# Beyond Split Fibers

**Exact Local Certificates and a T log T Law for Integral Hasse Failures**

AI-assisted research draft prepared for Vladimir Reshetnikov, September 30, 2026.

## Read

- `article.pdf`: the complete research article.
- `article.tex`: self-contained LaTeX source with its bibliography.
- `STATUS.md`: mathematical, novelty, and verification boundaries.
- `SOURCES.md`: pinned repository and primary-source attribution ledger.

The article continues ProveIt's arithmetic-local-global-fibers report at
commit `6d04e1e385f2fe7d1cfbdbd8fd8d4e45bd6b6c72`. It gives a complete
local-integral certificate, including the rational-plus-irreducible-quadratic
case left open there, and proves a leading asymptotic for this previously
uncounted sector on C=2.

## Main results

For F defined in the article and integer target (A,B,C), define

    H(S) = S^3 - 2S^2 + BC S - 2AC^2
    G = gcd(3BC - 4, 27AC^2 - 4).

The target is in F(Z_p^3) at every prime precisely when H has an integer
root, G is a power of two, and the explicit dyadic table in the article holds.
The rational-root condition must not be omitted.

On C=2 all locally integral targets are parametrized by

    A = r^3 - r^2 + rb,  B = 2b,  gcd(3r-1,3b-1) = 1.

Both all and nonsplit integral Hasse failures in |A|,|B| <= T have count

    (27/(2*pi^2)) T log T + O(T).

The entire global integral image on C=2 consists of two polynomial
parametrizations with disjoint integer images. Its target count is

    2^(5/3) T^(1/3) + O(1).

The article also gives a number-field and S-integer extension and nine
further research questions. All assertions have the precise hypotheses
and proofs in the article; this README is only a guide.

## Reproduce the computations

Python >= 3.10. The exact counting and finite verification use only the
standard library. The classifier and symbolic identities additionally use
SymPy; the recorded run used SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/verify.py
python code/symbolic.py
python code/count.py
python code/classify.py 0 4 2
```

The last command certifies the nonsplit integral Hasse failure (0,4,2),
whose unique rational preimage is (1/2,-2,4). A classifier rejection need
not identify a specific obstructing prime when the rational-root gate fails.

To use other heights without replacing the delivered table:

```sh
python code/count.py --heights 1000000 --output data/counts_large.json
```

The split enumerator uses O(T) candidates; large heights may take time.
All membership tests and counts use exact integer/rational arithmetic.
Only the displayed asymptotic ratios use floating point.

## Rebuild the article

A TeX installation with `latexmk`, `newtx`, and the standard packages
listed in the preamble is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Or use `make pdf`. Run `make verify` to replay the recorded checks.
The PDF was compiled and its pages visually inspected. No Lean or Rocq
build was run for this article; the new results are not machine formalized.

## Files and integrity

`data/verification.json`, `data/symbolic.json`, `data/counts.json`, and
`data/classification_example.json` contain actual execution outputs.
`data/build_review.json` records the PDF build and layout checks.
`SHA256SUMS` hashes the delivered files, excluding itself. Re-running the
programs may update recorded outputs; rebuilding TeX can change PDF metadata.
Use `sha256sum -c SHA256SUMS` before rebuilding to check the delivered files.

No third-party font files or copied prior manuscripts are bundled.
