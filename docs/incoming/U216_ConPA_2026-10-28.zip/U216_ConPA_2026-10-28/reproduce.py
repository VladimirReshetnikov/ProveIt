#!/usr/bin/env python3
"""Reproduce the U216 primary result and the one-row U217 alternative.

The default audit is offline and uses Python's standard library only. It
checks exact reconstruction, source control flow, local induction proofs,
negative controls, dense relabeling, and literal blank initialization.
--full also rederives all three 5,060-case symbolic runtime certificates.
No proof-assistant kernel certification is asserted by a PASS result.
"""

import argparse
import gzip
import json
import shutil
import sys
import tempfile
import time
from pathlib import Path

import reproduce_u217 as common

sys.dont_write_bytecode = True
sys.path.insert(0, str(common.ROOT / "code"))
import build_u216
from check_local import read_table, validate

ROOT = common.ROOT
need, digest, load = common.require, common.digest, common.load
NATIVE216 = "fed7640bdc4f5ba0807aa55786245137172022c6fb54252ad7d3603a8894d188"
DENSE216 = "03cc105b832d1faf2dbde2b54ea7e59626264ddbfbeda73478cd7d6636651c2b"
SOURCE216 = "9bbb7fac728a5c82b32daeb55d9cf59976307ce2bc588c318f3e68785448e50e"


def runtime_audit(receipt, cases, source_path, grandparent):
    need(receipt["status"] == "UNIVERSAL_MATHEMATICAL_PASS", "U216 runtime failed")
    need(receipt["table_sha256"] == NATIVE216, "Runtime uses another table")
    need(receipt["sites_sha256"] == SOURCE216, "Runtime uses another source")
    need(receipt["working_states"] == 216, "Runtime state census differs")
    need(receipt["expected_cases"] == receipt["proved_cases"] == 5060,
         "Incomplete runtime proof")
    need(not receipt["failures"] and len(receipt["blocks"]) == 4,
         "Runtime failures or missing traversal schemas")
    need(receipt["startup_status"] == "CALIBRATED_DIRTY_ROOT_SEED",
         "Runtime did not reach the calibrated frame")
    source = load(source_path)
    need(len(source) == receipt["site_count"] == 3891, "Wrong source census")
    expected = {(i, positive) for i, row in enumerate(source)
                for positive in ((False, True) if row[1] == "CD" else (False,))}
    actual = {(case["site_index"], case["positive"]) for case in cases}
    need(len(cases) == 5060 and actual == expected, "Incomplete case inventory")
    for key, name in [("checker_sha256", "symbolic_runtime.py"),
                      ("helper_sha256", "independent_runtime.py")]:
        need(receipt[key] == digest(grandparent / "code/runtime" / name),
             "Runtime checker binding differs")


def dense_audit(folder):
    native, dense = read_table(folder / "u216.native.tm"), read_table(folder / "u216.tm")
    states = validate(native, 216)
    validate(dense, 216, halt=216)
    mapping = load(folder / "state_map.json")
    forward = {int(q): z for q, z in mapping["native_to_dense"].items()}
    backward = {int(q): z for q, z in mapping["dense_to_native"].items()}
    need(forward == {**{q: i for i, q in enumerate(sorted(states))}, 254: 216},
         "Unexpected dense state ordering")
    need(backward == {z: q for q, z in forward.items()}, "Wrong inverse bijection")
    need(dense == {(forward[q], b): (w, d, forward[z])
                   for (q, b), (w, d, z) in native.items()}, "Dense rows differ")
    need(digest(folder / "u216.tm") == DENSE216, "Dense bytes differ")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    need(not sys.flags.optimize, "Run this driver without -O; local checkers test -O themselves")
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="u216-replay-") as name:
        work = Path(name)
        u217_receipt = work / "u217.json"
        flags = ["--full"] if args.full else []
        common.command(ROOT / "reproduce_u217.py", [*flags, "--report", u217_receipt],
                       "U217 alternative and release integrity")
        alternative = load(u217_receipt)
        need(alternative["status"] in ("U217_EXACT_LOCAL_AUDIT_PASS", "U217_FULL_REPLAY_PASS"),
             "Alternative audit failed")
        parent = common.extract(ROOT / "inputs/U218_ConPA_2026-10-28.zip", work,
                                common.PARENT_ARCHIVE_HASH, "U218_ConPA_2026-10-28")
        grandparent = common.extract(parent / "inputs/U222_ConU_2026-10-28.zip", work,
                                     common.GRANDPARENT_HASH, "u222_consistency_machine")
        generated = work / "machine216"
        built = build_u216.build(parent / "machine/u218.native.tm",
                                 parent / "machine/sites.json", generated)
        final_dir = ROOT / "machine/u216"
        for filename in ("u216.native.tm", "u216.tm", "sites.json", "state_map.json",
                         "rotated218.native.tm", "u217s.native.tm", "construction.json"):
            need((generated / filename).read_bytes() == (final_dir / filename).read_bytes(),
                 "U216 reconstruction differs: " + filename)
        dense_audit(generated)
        # This is fixed, hash-covered input to a separate reconstruction audit.
        shutil.copyfile(final_dir / "rotations.json", generated / "rotations.json")
        for optimized in (False, True):
            proof = work / ("independent216_O.json" if optimized else "independent216.json")
            common.command(ROOT / "code/check_u216_independent.py",
                           [parent / "machine/u218.native.tm", parent / "machine/sites.json",
                            generated, parent / "evidence/startup.json", "--report", proof],
                           "Independent U216 source, folds and startup" + (" with -O" if optimized else ""),
                           optimized)
            need(load(proof) == load(ROOT / "evidence/u216/independent_receipt.json"),
                 "Independent U216 certificate differs")
            composed = work / ("composed_O.json" if optimized else "composed.json")
            pretag = work / ("pretag_O.native.tm" if optimized else "pretag.native.tm")
            common.command(ROOT / "code/check_composed_folds.py",
                           [generated / "rotated218.native.tm", generated / "u216.native.tm",
                            "--pretag-output", pretag, "--report", composed],
                           "Independent fold composition" + (" with -O" if optimized else ""),
                           optimized)
            need(load(composed) == load(ROOT / "evidence/u216/composition_receipt.json"),
                 "Composed local certificate differs")
            need(pretag.read_bytes() == (final_dir / "pretag217.native.tm").read_bytes(),
                 "Alternate fold-order intermediate differs")
        native_parent = read_table(parent / "machine/u218.native.tm")
        native_final = read_table(generated / "u216.native.tm")
        delta = {
            "changed_rows": [{"key": list(k), "old": list(native_parent[k]),
                              "new": list(native_final[k])}
                             for k in sorted(native_parent.keys() & native_final.keys())
                             if native_parent[k] != native_final[k]],
            "removed_rows": [[*k, *native_parent[k]]
                             for k in sorted(native_parent.keys() - native_final.keys())],
        }
        need(len(delta["changed_rows"]) == 14 and len(delta["removed_rows"]) == 4,
             "Unexpected net table delta")
        need(load(final_dir / "final_delta.json") == delta, "Recorded table delta differs")
        saved = load(ROOT / "evidence/u216/runtime.json")
        cases = json.loads(gzip.decompress((ROOT / "evidence/u216/runtime_cases.json.gz").read_bytes()))
        runtime_audit(saved, cases, generated / "sites.json", grandparent)
        concrete_controls = [
            ("secondary_decoder", ROOT / "research/rejected/secondary_decoder/native.tm",
             ROOT / "research/rejected/secondary_decoder/sites.json", 26, "fail",
             ROOT / "research/rejected/secondary_decoder/counterexample.json"),
            ("seven_zero", ROOT / "research/rejected/seven_zero/native.tm",
             ROOT / "research/rejected/seven_zero/sites.json", 2931, "fail",
             ROOT / "research/rejected/seven_zero/counterexample.json"),
            ("repaired_positive", generated / "u216.native.tm", generated / "sites.json",
             2931, "pass", ROOT / "evidence/u216/concrete_positive_control.json"),
        ]
        for label, table, source, index, outcome, expected_report in concrete_controls:
            report = work / (label + ".json")
            common.command(ROOT / "code/check_rejected_runtime.py",
                           ["--table", table, "--source", source, "--site", index,
                            "--expect", outcome, "--output", report],
                           "Concrete primitive control: " + label)
            need(load(report) == load(expected_report), "Concrete trace control differs")
        if args.full:
            fresh_dir = work / "runtime216"
            common.command(grandparent / "code/validate_native.py",
                           [generated / "u216.native.tm", generated / "sites.json", fresh_dir],
                           "Fresh U216 arbitrary-register symbolic verification")
            fresh = load(fresh_dir / "runtime.json")
            fresh_cases = load(fresh_dir / "runtime_cases.json")
            runtime_audit(fresh, fresh_cases, generated / "sites.json", grandparent)
            need(fresh_cases == cases and fresh["blocks"] == saved["blocks"],
                 "Fresh U216 symbolic derivations differ")
            need((fresh_dir / "startup.json").read_bytes()
                 == (parent / "evidence/startup.json").read_bytes(), "Fresh startup differs")
        result = {
            "status": "U216_AND_U217_FULL_REPLAY_PASS" if args.full else "U216_AND_U217_EXACT_AUDIT_PASS",
            "primary_working_states": 216, "primary_transition_rows": 432,
            "alternative_working_states": 217, "alternative_transition_rows": 434,
            "u217_audit": alternative,
            "u216_source_primitive_occurrences": 3891,
            "u216_guarded_source_outcomes": 5060,
            "u216_source_actual_successor_edges": 5059,
            "changed_source_addresses": 645,
            "closed_rotations": 5, "source_dag_nodes": 202,
            "changed_retained_rows": 14, "deleted_states": [112, 188],
            "u216_local_invariant_frames": [6944, 6928],
            "u216_composition_mutations_rejected": 17,
            "concrete_primitive_controls": ["598-step rejection", "666-step rejection",
                                             "548-step repaired acceptance"],
            "identical_blank_startup_steps": 95726,
            "all_saved_symbolic_cases_checked": [5060, 5060],
            "all_symbolic_cases_freshly_rederived": args.full,
            "u216_native_sha256": NATIVE216, "u216_dense_sha256": DENSE216,
            "u216_source_sha256": SOURCE216,
            "seconds": round(time.monotonic() - started, 3),
            "scope": "Exact mathematical audit, source/CFG proof and local induction certificates. "
                     "The report gives the PA transport proof; inherited consistency calibration "
                     "is explicit. No new proof-assistant kernel endpoint.",
        }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
