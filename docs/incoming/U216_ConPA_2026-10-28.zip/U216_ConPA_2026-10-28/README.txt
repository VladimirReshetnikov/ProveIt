U216: reducing the primary PA consistency machine
================================================
Research prepared for Vladimir Reshetnikov, 28 October 2026.

MAIN RESULT
-----------
The primary deliverable has 216 working states and 432 binary transitions:
two fewer states than the supplied primary U218. It uses one two-way infinite
tape, one head, alphabet {0,1}, blank symbol 0, and only left/right moves.
The dense table starts in state 0 with its head at position 0 on an all-zero
tape. Working states are 0,...,215; halt is the separate label 216.
Every initialization state is included.

  machine/u216/u216.tm            Complete dense U216 transition table.
  machine/u216/u216.native.tm     Same machine in inherited native names.
  machine/u216/sites.json         Reassociated but equivalent register source.
  machine/u216/state_map.json     Checked renaming in both directions.
  machine/u216/final_delta.json   All 14 changed retained rows and 4 deleted rows.

In native names, delete states 112 and 188. The five closed source rotations
and two local folds change no primitive instruction, register argument,
axiom formula, freshness gate, or ordinal control-flow outcome.
They change 645 binary source addresses but retain 3,891 primitives and
202 distinct subtrees, depth 45 and maximum zero run 6.

The report proves the new blank-halting equivalence

  PA |- Halt(U216, blank) <-> Halt(U218, blank).

Using the supplied U218 logical calibration, with its inherited U222 and
unary-power-covering interpretation arguments, this gives

  PA |- not Halt(U216, blank) <-> Con(U) <-> Con(PA).

This is an ordinary mathematical proof formalizable in PA, supported by exact
finite certificates and complete symbolic runtime derivations. It is not a
newly exported PA, MM0, Lean or Rocq kernel certificate for the full endpoint.
The K215 MM0 theorem certifies K215's own fixed ZFC machine; it does not
automatically certify this modified PA machine.

No actual non-halting, unconditional consistency, global minimality, or
external priority is asserted.

THE ONE-ROW U217 ALTERNATIVE
--------------------------
For a particularly small direct proof, the archive also contains U217:

  machine/u217.tm                Dense working states 0,...,216, halt 217.
  machine/u217.native.tm         Complete native table, halt 254.
  machine/u217_sites.json        Byte-identical to the U218 source.
  machine/state_map.json         U217 renaming in both directions.

Change just one retained native row in U218:

  172 0 0 L 112   becomes   172 0 0 L 134

and delete the two outgoing rows of native state 112. Every other retained
row is identical. This is valid because entering 112 guarantees a zero
immediately right of the head. On the guarded configurations, existing state 134
matches the old behavior in positive blocks of lengths 1:3 or 5:3; ordinary
rows match 1:1. The full tape and head agree at boundaries.

This separate theorem applies to arbitrary initial binary tapes in state 0.
It does not depend on the correctness of the theory U or its interpretation.
If old and new first-halting times are T and S, then S <= 3T and 3T <= 5S.

For U216, the two local folds have analogous all-tape theorems relative to
the rotated 218 intermediate. The overall U216-to-U218 equivalence uses
source correspondence and runtime calibration. Do not assert arbitrary-tape
equivalence or a complete running-time bound between U216 and unrotated U218.

PROOFS AND VERIFICATION
----------------------
paper/report.pdf and paper/report.tex contain the complete report, including
the full dense U216 table. The extra TeX fragments contain further detailed
proofs of source correspondence and the two commuting state folds.

Fresh complete checks were conducted separately for primary U218, final
U217, and final U216. All three passed all 5,060 arbitrary-register cases.
These are symbolic induction obligations for arbitrary natural register
values, gaps and nonempty finite spare tails, not bounded small-value tests.
The complete case derivations for both new machines are saved as gzip JSON.
The four generic traversal schemas are included in each runtime receipt.

All delivered machines and construction intermediates execute exactly the
same 95,726-step blank initialization trace. Its endpoint is native state 84,
head -8, gap 1, logical registers (4,0,0,0,0,0,0,0,0), forty spare registers equal to 1,
95 nonzero tape cells, and the zero exterior.

Independent finite checks include:

  U217: 434 ordinary row identities; 4 three-cell cases; 6,960 inductive
        five-cell frames; two separate sets of 13 and 12 rejected mutations.
  U216: all 5 closed rotations, all 3,891 ordered primitives, all 5,060 guarded
        outcomes; 6,944 and 6,928 local invariant frames; both fold orders;
        430 combined ordinary rows, 8 special cases, 17 rejected mutations.

There are 5,059 actual source successor edges plus one halt outcome.
Local checkers were also run under Python -O with identical receipts.
The final fast packaged audit rechecks the saved symbolic coverage and
hash bindings; its "freshly_rederived:false" flag correctly records that
this fast audit does not repeat the separately completed full runtime runs.

REPRODUCE OFFLINE
----------------
Python 3.10 or later, standard library only. No network, solver or package
installation is needed. Run from this directory:

  python3 -B reproduce.py
  python3 -B reproduce.py --full
  python3 -B reproduce.py --report /chosen/path/audit.json

The default checks the release manifest, reconstructs both exact machines,
checks their dense bijections, reconstructs and checks source control flow,
replays the independent local certificates and mutation controls, executes
blank startup, validates the saved runtime derivations' coverage/bindings,
and reproduces two concrete rejected primitive contracts plus a repaired
positive control. It took about 11 seconds in the research environment.

--full additionally rederives all symbolic runtime cases for the inherited
U218 and both final machines. Allow several minutes. Temporary generated
work is automatically removed; --report is the optional persistent output.
The full driver requires assertions enabled because the inherited runtime
checker uses them. Its small local sub-checkers separately exercise -O.

For just the U217 alternative:

  python3 -B reproduce_u217.py
  python3 -B reproduce_u217.py --full

For the optional bounded discovery search (not needed for reconstruction):

  python3 -B research/synthesize_folds.py inputs/u218.native.tm

To rebuild the PDF, run pdfLaTeX twice in paper/:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

PDF bytes may vary with TeX versions and timestamps. Preserve the supplied
release for exact-byte audits; modifying any release file changes its
SHA256SUMS entry.

REJECTED CONSTRUCTIONS
----------------------
research/rejected/ contains two explicitly rejected table/source pairs.
They are diagnostic controls, not candidate results:

  secondary_decoder/: valid primitive frame 26 fails after 598 steps.
  seven_zero/:        valid primitive frame 2931 fails after 666 steps.

The corresponding repaired U216 frame 2931 succeeds after 548 steps. All three
traces replay independently. The counterexamples concern valid primitive
inputs, not asserted reachability from blank. Source equivalence alone does
not excuse a failed physical primitive contract.

PROVENANCE AND IDENTITIES
-------------------------
All nine inspected incoming archives were pinned to ProveIt commit

  1dd14d95976856bfabe06ab7294e78508556e0d1

and checked against their Git blob identities. PROVENANCE.json records the
exact input URLs, byte sizes, Git hashes and SHA-256 hashes.
The complete primary U218 archive is retained under inputs/, with its U222
and theory dependencies and original license/attribution files.
The comparison ledger records every nonprimary archive and how its ideas
were used, already incorporated, or not transferred.

SHA-256 of final dense U216:
  03cc105b832d1faf2dbde2b54ea7e59626264ddbfbeda73478cd7d6636651c2b
SHA-256 of final native U216:
  fed7640bdc4f5ba0807aa55786245137172022c6fb54252ad7d3603a8894d188
SHA-256 of U216 source:
  9bbb7fac728a5c82b32daeb55d9cf59976307ce2bc588c318f3e68785448e50e
SHA-256 of the simple dense U217 alternative:
  639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6

Each transition row is:

  state read_symbol write_symbol direction next_state

The "#! start 0" header gives the initial state. There are exactly two rows per working state and no
outgoing halt row. Native label 218 is a working state, not the native halt;
native halt is 254. Dense halt labels differ between the two machines.

Independent auditors here were members of the same assistant research
collaboration, not external human reviewers. Original contributions retain
their original attribution and license terms; see NOTICE.txt and licenses/.
