#!/usr/bin/env python3
"""Bounded local fold synthesis over a finite-window reachable overapproximation.

Research heuristic, not a minimality proof. Final candidates require an
independent invariant/matching-block certificate. Defaults reproduce the
112/134 discovery in the supplied U218 table in a few seconds.
"""
from pathlib import Path
from collections import deque
import argparse,hashlib,json,time


def table(path):
    d={}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,dr,t=line.split();d[int(q),int(b)]=(int(w),1 if dr=='R'else-1,int(t))
    return d


def reachable_frames(d,left,right):
    """Forward closure, with either bit admitted on a newly exposed cell."""
    width=left+right+1;size=1<<width;mask=size-1;center=1<<left
    states=sorted({q for q,b in d});seen={q:bytearray(size)for q in states}
    seen[0]=bytearray([1])*size;todo=deque((0,m)for m in range(size))
    while todo:
        q,m=todo.popleft();w,dr,t=d[q,(m>>left)&1]
        if t not in seen:continue
        v=(m&~center)|(w<<left)
        nxt=(v>>1,(v>>1)|(size>>1))if dr==1 else((v<<1)&mask,((v<<1)&mask)|1)
        for n in nxt:
            if not seen[t][n]:seen[t][n]=1;todo.append((t,n))
    return{q:[m for m,yes in enumerate(bits)if yes]for q,bits in seen.items()}


def search(d,left,right,limit):
    frames=reachable_frames(d,left,right);states=sorted(frames);center=1<<left
    traces={}
    for q in states:
        for m in frames[q]:
            v=m;h=0;t=q;record={}
            for step in range(1,limit+1):
                if h < -left or h>right or(t,0)not in d:break
                w,dr,t=d[t,(v>>(h+left))&1]
                v=(v&~(1<<(h+left)))|(w<<(h+left));h+=dr
                record[v,h,t]=step
            traces[q,m]=record

    def matching(q,b,action):
        used=set();max_old=max_new=0
        for m in frames[q]:
            if(m>>left)&1!=b:continue
            old=traces[q,m];w,h,t=action;v=(m&~center)|(w<<left);steps=1
            while(v,h,t)not in old:
                if h < -left or h>right or(t,0)not in d or steps>=limit:return None
                used.add(t);w,dr,t=d[t,(v>>(h+left))&1]
                v=(v&~(1<<(h+left)))|(w<<(h+left));h+=dr;steps+=1
            max_old=max(max_old,old[v,h,t]);max_new=max(max_new,steps)
        return used,max_old,max_new

    alternatives={}
    for q in states:
        for b in(0,1):
            opts={}
            for w in(b,1-b):
                for dr in(-1,1):
                    for t in states:
                        act=(w,dr,t);ans=matching(q,b,act)
                        if ans is not None:opts[act]=ans
            alternatives[q,b]=opts
    candidates=[]
    for i,q in enumerate(states):
        if q==0:continue
        for r in states[:i]:
            if r==0:continue
            options=[]
            for b in(0,1):
                opts=[]
                for act in sorted(alternatives[q,b].keys()&alternatives[r,b].keys()):
                    aq=alternatives[q,b][act];ar=alternatives[r,b][act]
                    if(aq[0]|ar[0])&{q,r}:continue
                    opts.append(dict(action=act,max_parent_steps=max(aq[1],ar[1]),
                                     max_child_steps=max(aq[2],ar[2])))
                options.append(opts)
            if all(options):candidates.append(dict(pair=[q,r],read0=options[0],read1=options[1]))
    return dict(working_states=len(states),left_radius=left,right_radius=right,
        maximum_path_steps=limit,abstract_reachable_frames=sum(map(len,frames.values())),
        candidates=candidates,scope='Bounded synthesis under a sound local-context '
        'overapproximation. No claim of completeness or global minimality. '
        'The independent certificate establishes the final result.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('table',type=Path);p.add_argument('--left',type=int,default=4)
    p.add_argument('--right',type=int,default=4);p.add_argument('--max-steps',type=int,default=10)
    p.add_argument('--output',type=Path)
    a=p.parse_args();start=time.monotonic()
    out=search(table(a.table),a.left,a.right,a.max_steps)
    out['table_sha256']=hashlib.sha256(a.table.read_bytes()).hexdigest()
    out['seconds']=round(time.monotonic()-start,3)
    if a.output:a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
