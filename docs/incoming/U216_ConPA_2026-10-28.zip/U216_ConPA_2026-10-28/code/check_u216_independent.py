#!/usr/bin/env python3
"""Independent source, table, local-fold and blank-prefix audit for repaired U216.

Only Python's standard library is used. This program imports no production
builder, source-language implementation, runtime engine, or fold checker.
"""

import argparse
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path


PARENT_TABLE = "366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30"
PARENT_SOURCE = "bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f"
ROTATIONS = [(18, 220, 1), (101, 174, 1), (220, 78, 1), (119, 101, 0), (215, 18, 1)]
HALT = 254


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_table(path):
    out = {}
    for line in path.read_text().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        q, bit, write, direction, target = line.split()
        q, bit, write, target = map(int, (q, bit, write, target))
        need(direction in ("L", "R") and bit in (0, 1) and write in (0, 1), "Bad row")
        need((q, bit) not in out, "Duplicate row")
        out[q, bit] = write, -1 if direction == "L" else 1, target
    states = {q for q, _ in out}
    need(set(out) == {(q, b) for q in states for b in (0, 1)}, "Incomplete table")
    need(0 in states and HALT not in states, "Wrong start or halt")
    need({z for _, _, z in out.values()} - states == {HALT}, "Wrong external target")
    return out


def source_tree(rows):
    leaves = {}
    for p, op, arg in rows:
        need(isinstance(p, str) and set(p) <= {"0", "1"}, "Bad address")
        need(p not in leaves, "Duplicate source address")
        need(op in ("CI", "CD", "CC", "CB", "CH"), "Unknown instruction")
        if op in ("CI", "CD"):
            need(type(arg) is int and 0 <= arg < 9, "Bad register")
        elif op in ("CC", "CB"):
            need(type(arg) is int and arg > 0, "Bad branch index")
        else:
            need(arg is None, "Bad halt operand")
        leaves[p] = (op, arg)
    prefixes = {p[:i] for p in leaves for i in range(len(p))}
    need(not prefixes.intersection(leaves), "Leaf is an internal prefix")
    need(all(p + b in prefixes or p + b in leaves for p in prefixes for b in "01"),
         "Incomplete binary source tree")

    def visit(p):
        return leaves[p] if p in leaves else (visit(p + "0"), visit(p + "1"))

    tree = visit("")
    need(enumerate_source(tree) == rows, "Noncanonical leaf order")
    return tree


def leaf(tree):
    return isinstance(tree[0], str)


def enumerate_source(tree, path=""):
    if leaf(tree):
        return [[path, tree[0], tree[1]]]
    return enumerate_source(tree[0], path + "0") + enumerate_source(tree[1], path + "1")


def lookup(tree, path):
    for c in path:
        need(not leaf(tree), "Rotation descends through a leaf")
        tree = tree[int(c)]
    return tree


def replace(tree, path, subtree):
    if not path:
        return subtree
    bit = int(path[0])
    children = list(tree)
    children[bit] = replace(children[bit], path[1:], subtree)
    return tuple(children)


def closed(tree):
    # A branch must be bound by an ancestor inside this factor. The empty
    # fallthrough context is permitted; a halt is not a closed macro factor.
    for p, op, arg in enumerate_source(tree):
        if op == "CH":
            return False
        if op == "CD" and p.count("0") < 1:
            return False
        if op == "CB" and p.count("0") < arg:
            return False
        if op == "CC" and p.count("1") < arg:
            return False
    return True


def control_graph(tree):
    """Resolve using structured ancestor stacks, not address suffix arithmetic."""
    edges = []

    def size(t):
        return 1 if leaf(t) else size(t[0]) + size(t[1])

    def walk(t, start, breaks, continues):
        if not leaf(t):
            left_size, whole_size = size(t[0]), size(t)
            walk(t[0], start, breaks + [start + whole_size], continues)
            walk(t[1], start + left_size, breaks, continues + [start])
            return
        op, arg = t
        if op == "CI":
            successors = [["always", start + 1]]
        elif op == "CD":
            need(breaks, "Unbound decrement branch")
            successors = [["zero", breaks[-1]], ["positive", start + 1]]
        elif op == "CB":
            need(len(breaks) >= arg, "Unbound break")
            successors = [["always", breaks[-arg]]]
        elif op == "CC":
            need(len(continues) >= arg, "Unbound continue")
            successors = [["always", continues[-arg]]]
        else:
            successors = [["halt", None]]
        edges.append([op, arg, successors])

    walk(tree, 0, [], [])
    return edges


def metrics(tree):
    nodes = set()

    def visit(t):
        nodes.add(t)
        if not leaf(t):
            visit(t[0])
            visit(t[1])

    visit(tree)
    rows = enumerate_source(tree)
    return {"subtrees": len(nodes), "leaves": len(rows),
            "depth": max(len(p) for p, _, _ in rows),
            "zero_run": max(len(s) for p, _, _ in rows for s in p.split("1"))}


def prefix_state(table, path):
    original = {-1: 1, **dict(enumerate(map(int, path)))}
    tape, q, head = dict(original), 84, 0
    for _ in range(512):
        if head not in tape:
            return q if head == len(path) and tape == original else None
        write, direction, target = table[q, tape[head]]
        tape[head], head, q = write, head + direction, target
    raise ValueError("Prefix proof does not terminate within its finite check")


def audit_rotations(parent, original_tree, folder):
    tree, table, records = original_tree, dict(parent), []
    recipe = json.loads((folder / "rotations.json").read_text())
    need([tuple(r["states_and_side"]) for r in recipe] == ROTATIONS, "Wrong five rotations")
    old_graph = control_graph(tree)
    for item, (q, r, side) in zip(recipe, ROTATIONS):
        need(all(table[s, b][:2] == (b, 1) for s in (q, r) for b in (0, 1)),
             "Selected decoder row is not read-preserving right move")
        need(table[q, side][2] == r, "Wrong decoder child")
        need([k for k, a in table.items() if a[2] == r] == [(q, side)], "Unexpected child entry")
        rows = enumerate_source(tree)
        prefixes = {p[:i] for p, _, _ in rows for i in range(len(p) + 1)}
        paths = sorted(p for p in prefixes if prefix_state(table, p) == q)
        need(paths == sorted(item["paths"]), "Missing or extra source occurrence of decoder state")
        before = [[s, b, *table[s, b]] for s in (q, r) for b in (0, 1)]
        need(before == item["before_rows"], "Rotation before-rows mismatch")
        factors = []
        for path in paths:
            subtree = lookup(tree, path)
            need(not leaf(subtree) and not leaf(subtree[side]), "Wrong rotation shape")
            if side:
                a, (b, c) = subtree
                target = ((a, b), c)
            else:
                (a, b), c = subtree
                target = (a, (b, c))
            need(all(closed(t) for t in (a, b, c)), "Rotation factor is not closed")
            factors.append({"path": path, "factor_leaves": [len(enumerate_source(t)) for t in (a, b, c)]})
            tree = replace(tree, path, target)
        if side:
            a, b, c = table[q, 0][2], table[r, 0][2], table[r, 1][2]
            updates = {(q, 0): (0, 1, r), (q, 1): (1, 1, c),
                       (r, 0): (0, 1, a), (r, 1): (1, 1, b)}
        else:
            a, b, c = table[r, 0][2], table[r, 1][2], table[q, 1][2]
            updates = {(q, 0): (0, 1, a), (q, 1): (1, 1, r),
                       (r, 0): (0, 1, b), (r, 1): (1, 1, c)}
        table.update(updates)
        need([[s, b, *table[s, b]] for s in (q, r) for b in (0, 1)] == item["after_rows"],
             "Rotation after-rows mismatch")
        need(control_graph(tree) == old_graph, "Rotation changes guarded source semantics")
        records.append({"states_and_side": [q, r, side], "factors": factors, "metrics": metrics(tree)})
    new_rows = json.loads((folder / "sites.json").read_text())
    need(enumerate_source(tree) == new_rows, "Final source is not the five-rotation result")
    need(table == read_table(folder / "rotated218.native.tm"), "Final rotated table mismatch")
    need(control_graph(source_tree(new_rows)) == old_graph, "Delivered source graph mismatch")
    need(metrics(tree) == {"subtrees": 202, "leaves": 3891, "depth": 45, "zero_run": 6},
         "Final source metrics mismatch")
    old_rows = enumerate_source(original_tree)
    return table, {"rotations": records, "primitive_occurrences": len(old_graph),
                   "guarded_outcomes_including_halt": sum(len(e[2]) for e in old_graph),
                   "changed_addresses": sum(a[0] != b[0] for a, b in zip(old_rows, new_rows)),
                   "source_sha256": sha(folder / "sites.json"), "metrics": metrics(tree)}


def run(table, q, tape, steps):
    tape, head = dict(tape), 0
    for i in range(steps):
        need(q != HALT and head in tape, "Interior halt or exterior read")
        write, direction, q = table[q, tape[head]]
        tape[head] = write
        head += direction
        if i + 1 < steps:
            need(q != HALT, "Interior halt")
    return q, head, tape


def audit_fold(parent, child, kind):
    if kind == "tag":
        rename = lambda q: 78 if q == 188 else q
        need([(k, a) for k, a in parent.items() if a[2] == 78] == [((220, 0), (0, 1, 78))], "Wrong zero-tag entry")
        need([(k, a) for k, a in parent.items() if a[2] == 188] ==
             [((174, 1), (1, 1, 188)), ((204, 1), (1, 1, 188))], "Wrong one-tag entries")
        expected = {k: (w, d, rename(z)) for k, (w, d, z) in parent.items() if k[0] != 188}
        expected[78, 1] = 1, -1, 143
        inv = lambda q, h, t: (q != 78 or t[h - 1] == 0) and (q != 188 or t[h - 1] == 1)
        lengths = lambda q, t: (1, 3 if q in (78, 188) and t[0] == 1 else 1)
        expected_census = {"1:1": 6928, "1:3": 16}
    else:
        rename = lambda q: 134 if q == 112 else q
        need([(k, a) for k, a in parent.items() if a[2] == 112] == [((172, 0), (0, -1, 112))], "Wrong right-zero entry")
        expected = {k: (w, d, rename(z)) for k, (w, d, z) in parent.items() if k[0] != 112}
        inv = lambda q, h, t: q != 112 or t[h + 1] == 0
        lengths = lambda q, t: ((1 if t[0] == 0 else 5), 3) if q == 112 else (1, 1)
        expected_census = {"1:1": 6912, "1:3": 8, "5:3": 8}
    need(child == expected, "Unexpected table changes in local fold")
    census = Counter()
    for q in sorted({q for q, _ in parent}):
        for bits in itertools.product((0, 1), repeat=5):
            tape = dict(zip(range(-2, 3), bits))
            if not inv(q, 0, tape):
                continue
            step_q, step_h, step_t = run(parent, q, tape, 1)
            need(inv(step_q, step_h, step_t), "Local invariant is not inductive")
            a, b = lengths(q, tape)
            old_q, old_h, old_t = run(parent, q, tape, a)
            new_q, new_h, new_t = run(child, rename(q), tape, b)
            need((rename(old_q), old_h, old_t) == (new_q, new_h, new_t), "Local block mismatch")
            need((old_q == HALT) == (new_q == HALT), "Halting not reflected")
            census[f"{a}:{b}"] += 1
    need(dict(census) == expected_census, "Unexpected frame census")
    return {"kind": kind, "admissible_frames": sum(census.values()), "block_counts": dict(census)}


def audit_startup(table, baseline_record):
    q, head, ones = 0, 0, set()
    changed = set()
    for expected in baseline_record["trace"]:
        symbol = int(head in ones)
        write, direction, target = table[q, symbol]
        observed = [q, head, symbol, write, direction, target]
        need(observed == expected, "Blank trace differs from the primary U218 trace")
        changed.add((q, symbol))
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head, q = head + direction, target
    need(len(baseline_record["trace"]) == 95726 and q == 84 and head == -8, "Wrong blank endpoint")
    # Reconstruct the entire calibrated frame independently from its definition.
    expected = {-9, 57}
    physical_values = [0, 0, 0, 0, 0, 0, 4, 0, 0] + [1] * 40
    pos = 58
    for value in physical_values:
        expected.update(range(pos + 1, pos + value + 2))
        pos += value + 2
    need(ones == expected == set(baseline_record["one_cells"]), "Whole startup frame mismatch")
    return {"steps": 95726, "state": 84, "head": -8, "gap": 1,
            "registers": [4, 0, 0, 0, 0, 0, 0, 0, 0], "spares": [1] * 40,
            "one_cells": sorted(ones), "identical_primary_trace": True,
            "distinct_rows_used": len(changed)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent_table", type=Path)
    parser.add_argument("parent_source", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("baseline_startup", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    need(sha(args.parent_table) == PARENT_TABLE, "Wrong primary U218 table")
    need(sha(args.parent_source) == PARENT_SOURCE, "Wrong primary U218 source")
    parent = read_table(args.parent_table)
    original = source_tree(json.loads(args.parent_source.read_text()))
    rotated, source_audit = audit_rotations(parent, original, args.candidate)
    tagged = read_table(args.candidate / "u217s.native.tm")
    final = read_table(args.candidate / "u216.native.tm")
    need([len(t) // 2 for t in (parent, rotated, tagged, final)] == [218, 218, 217, 216], "State counts")
    folds = [audit_fold(rotated, tagged, "tag"), audit_fold(tagged, final, "right_zero")]
    startup = json.loads(args.baseline_startup.read_text())
    prefixes = {name: audit_startup(t, startup) for name, t in
                [("primary218", parent), ("rotated218", rotated), ("tagged217", tagged), ("final216", final)]}
    receipt = {"status": "PASS", "parent_table_sha256": PARENT_TABLE,
               "parent_source_sha256": PARENT_SOURCE,
               "final_table_sha256": sha(args.candidate / "u216.native.tm"),
               "source": source_audit, "folds": folds, "startup": prefixes,
               "scope": "Exact source/CFG and literal table construction; local induction certificates; exact blank prefix. Final universal primitive runtime is a separate obligation."}
    encoded = json.dumps(receipt, indent=2) + "\n"
    if args.report:
        args.report.write_text(encoded)
    print(encoded, end="")


if __name__ == "__main__":
    main()
