#!/usr/bin/env python3
"""Independent finite local certificate for the literal U218 -> U217 fold.

This script imports no compiler, upstream runtime, or other project checker.
Its finite checks support the accompanying ordinary induction argument.
They are not a proof-assistant kernel certificate.
"""

import argparse
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path


PARENT_SHA256 = "366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30"
START, HALT = 0, 254
REMOVED, REPRESENTATIVE = 112, 134
OFFSETS = tuple(range(-2, 3))


def require(test, message):
    if not test:
        raise ValueError(message)


def parse(path):
    raw = path.read_bytes()
    table = {}
    for number, line in enumerate(raw.decode("ascii").splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        fields = stripped.split()
        require(len(fields) == 5, f"Malformed row {number}")
        q, symbol, write, direction, target = fields
        q, symbol, write, target = map(int, (q, symbol, write, target))
        require(q >= 0 and target >= 0, "Negative state label")
        require(symbol in (0, 1) and write in (0, 1), "Nonbinary row")
        require(direction in ("L", "R"), "Invalid movement")
        require((q, symbol) not in table, "Duplicate row")
        table[q, symbol] = (write, -1 if direction == "L" else 1, target)
    states = {q for q, _ in table}
    require(len(table) == 2 * len(states), "Incomplete binary state table")
    require(START in states and HALT not in states, "Invalid start/halt")
    require({q for _, _, q in table.values()} - states == {HALT}, "Wrong halt target")
    return table, states, hashlib.sha256(raw).hexdigest()


def rename(q):
    return REPRESENTATIVE if q == REMOVED else q


def run_block(table, q, head, tape, length):
    tape = dict(tape)
    path = []
    for i in range(length):
        require(q != HALT, "Interior halt")
        require(head in tape, "Block reads outside the complete finite window")
        symbol = tape[head]
        path.append((q, head, symbol))
        write, direction, target = table[q, symbol]
        tape[head] = write
        head += direction
        q = target
        if i + 1 < length:
            require(q != HALT, "Interior halt")
    return q, head, tape, path


def invariant(q, head, tape):
    if q != REMOVED:
        return True
    require(head + 1 in tape, "Unrepresented invariant observation")
    return tape[head + 1] == 0


def certify(parent, child):
    parent_states = {q for q, _ in parent}
    child_states = {q for q, _ in child}
    require(len(parent_states) == 218 and len(child_states) == 217, "Wrong state count")
    require(child_states == parent_states - {REMOVED}, "Wrong state deletion")
    incoming = [(q, s, w, d) for (q, s), (w, d, r) in parent.items() if r == REMOVED]
    require(incoming == [(172, 0, 0, -1)], "Unique zero-writing predecessor fails")
    expected = {
        (q, s): (w, d, rename(r))
        for (q, s), (w, d, r) in parent.items()
        if q != REMOVED
    }
    require(child == expected, "Child is not the claimed exact quotient table")
    census = Counter()
    accepted = 0
    path_census = {}
    for q in sorted(parent_states):
        for word in itertools.product((0, 1), repeat=5):
            tape = dict(zip(OFFSETS, word))
            if not invariant(q, 0, tape):
                continue
            accepted += 1
            sq, sh, st, _ = run_block(parent, q, 0, tape, 1)
            require(invariant(sq, sh, st), "Invariant is not inductive")
            if q == REMOVED:
                old_length = 1 if tape[0] == 0 else 5
                new_length = 3
            else:
                old_length = new_length = 1
            oq, oh, ot, op = run_block(parent, q, 0, tape, old_length)
            nq, nh, nt, np = run_block(child, rename(q), 0, tape, new_length)
            require((rename(oq), oh, ot) == (nq, nh, nt), "Whole-tape block mismatch")
            require((oq == HALT) == (nq == HALT), "Halt is not reflected")
            require(new_length <= 3 * old_length, "Forward time inequality fails")
            require(3 * old_length <= 5 * new_length, "Reverse time inequality fails")
            census[f"{old_length}:{new_length}"] += 1
            if q == REMOVED:
                key = str(tape[0]) if tape[0] == 0 else f"1,{tape[2]}"
                path_census[key] = {"old": op, "new": np, "state": nq, "head": nh}
    require(accepted == 6960, "Wrong admissible frame census")
    require(dict(census) == {"1:1": 6944, "1:3": 8, "5:3": 8}, "Wrong block census")
    return {"admissible_frames": accepted, "all_frames": 218 * 32,
            "blocks": dict(census), "paths": path_census}


def controls(parent, child):
    tests = []
    # Simultaneously alter both tables so table-comparison alone cannot catch it.
    p, c = dict(parent), dict(child)
    p[172, 0] = (1, -1, REMOVED)
    c[172, 0] = (1, -1, REPRESENTATIVE)
    tests.append(("destroy_right_zero_predecessor", p, c))
    # Alter helper equations simultaneously: invariance is still true, but blocks fail.
    for q, symbol in [(182, 0), (209, 0), (158, 0), (218, 0), (218, 1),
                      (157, 0), (157, 1), (67, 0), (151, 0), (148, 0), (186, 1)]:
        p, c = dict(parent), dict(child)
        write, direction, target = p[q, symbol]
        p[q, symbol] = c[q, symbol] = (1 - write, direction, target)
        tests.append((f"flip_shared_helper_{q}_{symbol}", p, c))
    rejected = []
    for name, p, c in tests:
        try:
            certify(p, c)
        except (ValueError, KeyError) as error:
            rejected.append({"name": name, "reason": str(error)})
        else:
            raise ValueError(f"Negative control accepted: {name}")
    return rejected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent", type=Path)
    parser.add_argument("child", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    parent, _, parent_hash = parse(args.parent)
    child, _, child_hash = parse(args.child)
    require(parent_hash == PARENT_SHA256, "Parent byte identity is not the supplied U218")
    result = {"status": "PASS", "parent_sha256": parent_hash,
              "child_sha256": child_hash, **certify(parent, child),
              "negative_controls": controls(parent, child),
              "scope": "Exhaustive finite local induction obligations; ordinary PA-formalizable proof"}
    text = json.dumps(result, indent=2) + "\n"
    if args.report:
        args.report.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
