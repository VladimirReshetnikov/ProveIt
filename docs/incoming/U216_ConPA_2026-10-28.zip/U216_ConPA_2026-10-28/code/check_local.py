#!/usr/bin/env python3
"""Independent exact local certificate: delete112 by guarded134 reuse.

Only the parent and candidate literal binary transition tables are inputs.
No source/compiler/runtime-checker module is imported. Standard library only.
The local identities quantify over arbitrary tape exterior, because no local
path reads or writes outside the three supplied cells.
"""
from pathlib import Path
import argparse, hashlib, json


def require(test,message):
    if not test:raise ValueError(message)


def read_table(path):
    d={};start=[]
    for line in Path(path).read_text(encoding='ascii').splitlines():
        if line.startswith('#! start '):start.append(int(line[9:]))
        if not line or line.startswith('#'):continue
        fields=line.split();require(len(fields)==5,'Expected five fields')
        q,b,w,dr,t=fields;q,b,w,t=map(int,(q,b,w,t))
        require((q,b) not in d,'Repeated row')
        require(b in(0,1) and w in(0,1) and dr in('L','R'),'Invalid row')
        d[q,b]=(w,1 if dr=='R' else -1,t)
    require(start==[0],'Expected unique start0 declaration')
    return d


def validate(d,count,halt=254):
    states={q for q,b in d}
    require(len(states)==count,'Incorrect state count')
    require(set(d)=={(q,b) for q in states for b in(0,1)},'Missing row')
    require(0 in states and halt not in states,'Invalid initial/halt states')
    require({t for w,dr,t in d.values()}-states=={halt},'Unexpected undefined target')
    reached={0};todo=[0]
    for q in todo:
        for b in (0,1):
            t=d[q,b][2]
            if t in states and t not in reached:reached.add(t);todo.append(t)
    require(reached==states,'Unreachable counted state')
    return states


def fold(d):
    return {(q,b):(w,dr,134 if t==112 else t)
            for (q,b),(w,dr,t) in d.items() if q!=112}


def write_table(path,d):
    content='#! start 0\n'+''.join(f'{q} {b} {w} {"R" if dr==1 else "L"} {t}\n'
                         for (q,b),(w,dr,t) in sorted(d.items()))
    Path(path).write_text(content,encoding='ascii')


def run(d,q,frame,n):
    tape=dict(frame);h=0;trace=[]
    for k in range(n):
        require(q!=254,'Strict interior halt')
        require(h in tape,'Read outside local quantified frame')
        b=tape[h];w,dr,t=d[q,b]
        trace.append(dict(state=q,head=h,read=b,write=w,direction=dr,target=t))
        tape[h]=w;h+=dr;q=t
    return q,h,tape,trace


def verify(parent,child):
    validate(parent,218);validate(child,217)
    require(child==fold(parent),'Extra/missing transition changes')
    incoming=sorted((q,b,w,dr) for(q,b),(w,dr,t)in parent.items() if t==112)
    require(incoming==[(172,0,0,-1)],'Parent112 right-zero guard is not established')
    require(parent[134,0]==(0,1,182) and parent[134,1]==(1,1,158),
            'Unexpected retained134 rows')
    cases=[]
    for b in(0,1):
        for c in(0,1):
            frame={0:b,1:0,2:c}
            np=1 if b==0 else 5;nc=3
            old=run(parent,112,frame,np);new=run(child,134,frame,nc)
            require(old[:3]==new[:3],'Local matching-path identity failed')
            require(old[0] not in(112,134,254),'Unexpected endpoint')
            cases.append(dict(read=b,right=0,second_right=c,
                parent_steps=np,child_steps=nc,endpoint_state=old[0],
                endpoint_head=old[1],final_frame=old[2],
                parent_trace=old[3],child_trace=new[3]))
    # Every ordinary row commutes with the state projection. Only112 needs
    # matching paths; original134 steps continue to use their original rows.
    projection=lambda q:134 if q==112 else q
    ordinary=0
    for(q,b),(w,dr,t)in parent.items():
        if q==112:continue
        require(child[projection(q),b]==(w,dr,projection(t)),
                'Ordinary transition does not commute')
        ordinary+=1
    require(ordinary==434,'Wrong ordinary-row count')
    return dict(status='U217_LOCAL_EQUIVALENCE_VERIFIED',parent_states=218,
        child_states=217,deleted_state=112,representative=134,
        changed_retained_row=[172,0,0,-1,134],
        exact_parent_incoming_112=incoming,ordinary_rows_checked=ordinary,
        local_cases=cases,local_tape_offsets=[0,1,2],
        max_parent_block=5,max_child_block=3,
        theorem='For every initial binary tape and head, from state0, '
                'parent218 halts iff child217 halts. The tape and head agree '
                'at all comparison points. Parent-to-child time bound3T; '
                'child-to-parent time bound3T<=5S. Formalizable in PA by finite '
                'trace induction; no new proof-assistant certificate claimed.')


def controls(parent,child):
    results=[]
    def reject(name,p,c):
        try:verify(p,c)
        except (ValueError,KeyError) as e:
            results.append(dict(name=name,status='REJECTED',reason=str(e)));return
        raise ValueError('Accepted mutation: '+name)
    p=dict(parent);p[172,0]=(1,-1,112)
    reject('wrong_incoming_written_symbol',p,fold(p))
    p=dict(parent);p[172,0]=(0,1,112)
    reject('wrong_incoming_direction',p,fold(p))
    p=dict(parent);p[0,1]=(1,1,112)
    reject('unguarded_additional_entrance',p,fold(p))
    c=dict(child);c[172,0]=(0,-1,133)
    reject('wrong_redirect_target',parent,c)
    c=dict(child);c[134,0]=(0,1,157)
    reject('restored_old_read_zero_behavior',parent,c)
    c=dict(child);c[134,1]=(1,1,209)
    reject('restored_old_read_one_behavior',parent,c)
    # Mutate identical support rows in both tables so exact structural
    # projection still holds; the local path checker must detect the error.
    for q,b in ((182,0),(209,0),(158,0),(218,0),(218,1),(157,0),(157,1)):
        p=dict(parent);w,dr,t=p[q,b];p[q,b]=(1-w,dr,t)
        reject(f'support_row_{q}_{b}_wrong_write',p,fold(p))
    return results


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('parent',type=Path)
    parser.add_argument('candidate',type=Path)
    parser.add_argument('--report',type=Path)
    parser.add_argument('--build',action='store_true')
    args=parser.parse_args()
    p=read_table(args.parent)
    if args.build:write_table(args.candidate,fold(p))
    c=read_table(args.candidate);result=verify(p,c)
    result['negative_controls']=controls(p,c)
    result['sha256']={name:hashlib.sha256(path.read_bytes()).hexdigest()
                      for name,path in [('parent',args.parent),('candidate',args.candidate)]}
    if args.report:args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','parent_states','child_states',
                      'ordinary_rows_checked','sha256']},indent=2))
    print('Local cases:',len(result['local_cases']),'; rejected controls:',
          len(result['negative_controls']))

if __name__=='__main__':main()
