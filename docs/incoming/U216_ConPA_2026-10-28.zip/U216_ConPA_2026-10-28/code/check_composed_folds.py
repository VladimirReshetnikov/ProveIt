#!/usr/bin/env python3
"""Independent two-fold certificate for the repaired rotated U216 candidate.

No allocator, source compiler, or source-agent checker is imported. Verify the
112->134 return fold and 188->78 predecessor-tag fold in both orders, including
exact equality of the two resulting literal tables. Only local transition
identities and complete incoming-edge inventories are proof premises.
"""
from pathlib import Path
import argparse,hashlib,json


def need(c,m):
    if not c:raise ValueError(m)


def read(path):
    t={};starts=[]
    for l in Path(path).read_text(encoding='ascii').splitlines():
        if l.startswith('#! start '):starts.append(int(l[9:]))
        if not l or l.startswith('#'):continue
        f=l.split();need(len(f)==5,'five transition fields required')
        q,b,w,d,z=f;q,b,w,z=map(int,(q,b,w,z))
        need((q,b)not in t,'duplicate transition')
        need(b in(0,1)and w in(0,1)and d in('L','R'),'invalid transition')
        t[q,b]=(w,1 if d=='R'else-1,z)
    need(starts==[0],'unique initial state0 declaration required')
    return t


def write(path,t):
    Path(path).write_text('#! start 0\n'+''.join(
        f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'
        for(q,b),(w,d,z)in sorted(t.items())),encoding='ascii')


def census(t,n):
    states={q for q,b in t}
    need(len(states)==n,'working-state count differs')
    need(0 in states and 254 not in states,'invalid start/halt')
    need(set(t)=={(q,b)for q in states for b in(0,1)},'incomplete binary table')
    need({z for w,d,z in t.values()}-states=={254},'unexpected undefined target')
    reached={0};todo=[0]
    for q in todo:
        for b in(0,1):
            z=t[q,b][2]
            if z in states and z not in reached:reached.add(z);todo.append(z)
    need(reached==states,'graph-unreachable counted working state')


def incoming(t,q):
    return sorted([s,b,w,d]for(s,b),(w,d,z)in t.items()if z==q)


def return_fold(t):
    return{(q,b):(w,d,134 if z==112 else z)
           for(q,b),(w,d,z)in t.items()if q!=112}


def tag_fold(t):
    a={(q,b):(w,d,78 if z==188 else z)
        for(q,b),(w,d,z)in t.items()if q!=188}
    a[78,1]=(1,-1,143)
    return a


def run(t,q,cells,n):
    tape=dict(cells);head=0;trace=[]
    for k in range(n):
        need(q!=254,'interior halt')
        need(head in tape,'local proof read an unknown exterior cell')
        b=tape[head];w,d,z=t[q,b]
        trace.append([q,head,b,w,d,z]);tape[head]=w;head+=d;q=z
    return(q,head,tape),trace


def check_return(old,new,n):
    census(old,n);census(new,n-1)
    need(new==return_fold(old),'return fold delta differs')
    need(incoming(old,112)==[[172,0,0,-1]],'right-zero guard missing')
    cases=[]
    for b in(0,1):
        for c in(0,1):
            tape={0:b,1:0,2:c};on=1 if b==0 else 5;nn=3
            out,ot=run(old,112,tape,on);nxt,nt=run(new,134,tape,nn)
            need(out==nxt,'return matching paths differ')
            cases.append(dict(read=b,right=0,second_right=c,
                old_steps=on,new_steps=nn,endpoint=list(out[:2]),
                old_trace=ot,new_trace=nt))
    ordinary=0
    for(q,b),(w,d,z)in old.items():
        if q==112:continue
        need(new[q,b]==(w,d,134 if z==112 else z),'return ordinary row differs')
        ordinary+=1
    return dict(status='RETURN_FOLD_VERIFIED',old_states=n,new_states=n-1,
        incoming112=incoming(old,112),ordinary_rows=ordinary,cases=cases,
        cells=[0,1,2],halting_time_bounds=['new<=3*old','3*old<=5*new'])


def check_tag(old,new,n):
    census(old,n);census(new,n-1)
    need(new==tag_fold(old),'tag fold delta differs')
    need(incoming(old,78)==[[220,0,0,1]],'complete marker-zero inventory differs')
    need(incoming(old,188)==[[174,1,1,1],[204,1,1,1]],
         'complete marker-one inventory differs')
    need(old[78,0]==old[188,0]==(0,1,182),'zero branches differ')
    need(old[78,1]==(1,1,90)and old[188,1]==(1,1,166),'one branches differ')
    cases=[]
    for origin,tag in((78,0),(188,1)):
        for b in(0,1):
            tape={-1:tag,0:b};nn=1 if b==0 else 3
            out,ot=run(old,origin,tape,1);nxt,nt=run(new,78,tape,nn)
            q,h,f=out;out=(78 if q==188 else q,h,f)
            need(out==nxt,'tag matching paths differ')
            cases.append(dict(origin=origin,left_tag=tag,read=b,
                old_steps=1,new_steps=nn,endpoint=list(out[:2]),
                old_trace=ot,new_trace=nt))
    ordinary=0
    for(q,b),(w,d,z)in old.items():
        if q in(78,188):continue
        need(new[q,b]==(w,d,78 if z==188 else z),'tag ordinary row differs')
        ordinary+=1
    return dict(status='PREDECESSOR_TAG_FOLD_VERIFIED',old_states=n,new_states=n-1,
        incoming78=incoming(old,78),incoming188=incoming(old,188),
        ordinary_rows=ordinary,cases=cases,cells=[-1,0],
        halting_time_bounds=['old<=new','new<=3*old'])


def check_direct(old,new):
    """A single comparison relation preserves the sharper time bounds."""
    project=lambda q:134 if q==112 else 78 if q==188 else q
    cases=[]
    for b in(0,1):
        for c in(0,1):
            cells={0:b,1:0,2:c};on=1 if b==0 else 5
            out,ot=run(old,112,cells,on);nxt,nt=run(new,134,cells,3)
            q,h,tape=out
            need((project(q),h,tape)==nxt,'direct return block differs')
            cases.append(dict(kind='return',origin=112,cells=cells,
                old_steps=on,new_steps=3,old_trace=ot,new_trace=nt))
    for q,tag in((78,0),(188,1)):
        for b in(0,1):
            cells={-1:tag,0:b};nn=1 if b==0 else 3
            out,ot=run(old,q,cells,1);nxt,nt=run(new,78,cells,nn)
            z,h,tape=out
            need((project(z),h,tape)==nxt,'direct tag block differs')
            cases.append(dict(kind='tag',origin=q,cells=cells,
                old_steps=1,new_steps=nn,old_trace=ot,new_trace=nt))
    ordinary=0
    for(q,b),(w,d,z)in old.items():
        if q in(112,78,188):continue
        need(new[q,b]==(w,d,project(z)),'direct ordinary row differs')
        ordinary+=1
    for case in cases:
        a,b=case['old_steps'],case['new_steps']
        need(b<=3*a and 3*a<=5*b,'combined time inequality failed')
    return dict(status='DIRECT_COMBINED_BLOCKS_VERIFIED',ordinary_rows=ordinary,
        local_cases=cases,halting_time_bounds=['final<=3*rotated',
        '3*rotated<=5*final'],scope='Bounds compare the rotated218 table with '
        'final216. They are not asserted for the original unrotated U218.')


def verify(rotated,final):
    census(rotated,218);census(final,216)
    after_return=return_fold(rotated);after_tag=tag_fold(rotated)
    rt=tag_fold(after_return);tr=return_fold(after_tag)
    need(rt==tr==final,'the two fold orders or supplied final table differ')
    proof={
        'return_then_tag':[
            check_return(rotated,after_return,218),check_tag(after_return,final,217)],
        'tag_then_return':[
            check_tag(rotated,after_tag,218),check_return(after_tag,final,217)]}
    return dict(status='COMPOSED_LOCAL_FOLDS_VERIFIED_BOTH_ORDERS',
        working_states=[218,217,216],deleted_states=[112,188],
        representatives={'112':134,'188':78},orders_agree=True,
        proof=proof,direct=check_direct(rotated,final),scope='Exact finite calculations and incoming-edge invariants. '
        'By positive matching-block induction, the supplied rotated218 and '
        'final216 halt equivalently on every binary tape started in state0. '
        'The source reassociation and correctness of the rotated source are '
        'separate obligations. No proof-assistant kernel certificate is claimed.')


def controls(rotated):
    results=[]
    def reject(name,t):
        candidate=tag_fold(return_fold(t))
        try:verify(t,candidate)
        except(ValueError,KeyError)as e:
            results.append(dict(name=name,status='REJECTED',reason=str(e)));return
        raise ValueError('mutation control accepted: '+name)
    for name,key,action in[
        ('wrong_zero_tag',(220,0),(1,1,78)),
        ('wrong_one_tag',(174,1),(0,1,188)),
        ('extra_unguarded_78_entrance',(0,1),(1,1,78)),
        ('extra_unguarded_188_entrance',(0,1),(1,1,188)),
        ('wrong_return_guard',(172,0),(1,-1,112)),
        ('extra_unguarded_112_entrance',(0,1),(1,1,112))]:
        t=dict(rotated);t[key]=action;reject(name,t)
    # These edits are present on both sides and satisfy the exact fold delta;
    # their rejection therefore exercises local trace identities themselves.
    for q,b in((143,0),(143,1),(213,1),(147,1),(182,0),(209,0),
                (158,0),(218,0),(218,1),(157,0),(157,1)):
        t=dict(rotated);w,d,z=t[q,b];t[q,b]=(1-w,d,z)
        reject(f'shared_support_{q}_{b}_wrong_write',t)
    return results


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('rotated218',type=Path);p.add_argument('final216',type=Path)
    p.add_argument('--pretag-output',type=Path);p.add_argument('--report',type=Path)
    a=p.parse_args();old=read(a.rotated218);new=read(a.final216)
    result=verify(old,new);result['negative_controls']=controls(old)
    result['sha256']={name:hashlib.sha256(path.read_bytes()).hexdigest()
                     for name,path in [('rotated218',a.rotated218),('final216',a.final216)]}
    if a.pretag_output:
        write(a.pretag_output,return_fold(old))
        result['pretag217_sha256']=hashlib.sha256(a.pretag_output.read_bytes()).hexdigest()
    if a.report:a.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in('proof','direct')},indent=2))
if __name__=='__main__':main()
