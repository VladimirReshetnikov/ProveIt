#!/usr/bin/env python3
"""Reconstruct both literal U217 tables from the exact supplied U218 table."""

import argparse
import hashlib
import json
from pathlib import Path

from check_local import read_table, require, validate, write_table


PARENT_HASH = "366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30"
NATIVE_HASH = "fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f"
DENSE_HASH = "639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6"
SOURCE_HASH = "bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(parent_path, output):
    require(digest(parent_path) == PARENT_HASH, "Unexpected parent bytes")
    parent = read_table(parent_path)
    validate(parent, 218)
    require(parent[172, 0] == (0, -1, 112), "Unexpected old transition")
    incoming = [key for key, action in parent.items() if action[2] == 112]
    require(incoming == [(172, 0)], "Removed state has an extra entrance")

    child = dict(parent)
    child[172, 0] = (0, -1, 134)
    del child[112, 0]
    del child[112, 1]
    states = sorted(validate(child, 217))
    rename = {q: i for i, q in enumerate(states)}
    rename[254] = 217
    inverse = {i: q for q, i in rename.items()}
    dense = {
        (rename[q], b): (w, d, rename[z])
        for (q, b), (w, d, z) in child.items()
    }
    validate(dense, 217, halt=217)
    recovered = {
        (inverse[q], b): (w, d, inverse[z])
        for (q, b), (w, d, z) in dense.items()
    }
    require(recovered == child, "Dense bijection does not preserve transitions")

    output.mkdir(parents=True, exist_ok=True)
    native_path, dense_path = output / "u217.native.tm", output / "u217.tm"
    write_table(native_path, child)
    write_table(dense_path, dense)
    require(digest(native_path) == NATIVE_HASH, "Unexpected native output hash")
    require(digest(dense_path) == DENSE_HASH, "Unexpected dense output hash")
    mapping = {
        "native_to_dense": {str(q): i for q, i in sorted(rename.items())},
        "dense_to_native": {str(i): q for i, q in sorted(inverse.items())},
        "initial_state": 0,
        "native_halt": 254,
        "dense_halt": 217,
        "deleted_native_state": 112,
        "parent_projection": {"112": 134, "all_other_states": "identity"},
    }
    (output / "state_map.json").write_text(json.dumps(mapping, indent=2) + "\n")
    summary = {
        "status": "EXACT_U217_RECONSTRUCTION_PASS",
        "working_states": 217,
        "transition_rows": 434,
        "graph_reachable_working_states": 217,
        "alphabet": [0, 1],
        "tapes": 1,
        "heads": 1,
        "moves": ["L", "R"],
        "initial_state": 0,
        "blank_symbol": 0,
        "native_halt": 254,
        "dense_halt": 217,
        "changed_retained_rows": [
            {"key": [172, 0], "old": [0, -1, 112], "new": [0, -1, 134]}
        ],
        "deleted_rows": [[112, b, *parent[112, b]] for b in (0, 1)],
        "parent_native_sha256": PARENT_HASH,
        "native_sha256": NATIVE_HASH,
        "dense_sha256": DENSE_HASH,
        "unchanged_sites_sha256": SOURCE_HASH,
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.parent, args.output), indent=2))
