#!/usr/bin/env python3
"""Replay one concrete primitive frame; independent of the symbolic checker.

Native labels are used. A mismatch at first redispatch disproves the claimed
primitive contract on that valid input. It says nothing about the blank run.
"""
from pathlib import Path
import argparse, hashlib, json
PHY=(6,2,0,4,3,7,8,5,1)
def need(p,m):
 if not p:raise ValueError(m)
def read_table(p):
 t={}
 for line in p.read_text().splitlines():
  if line and not line.startswith('#'):
   q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in t,'duplicate row');t[q,b]=w,(1 if d=='R'else-1),z
 return t
def frame(pc,registers,spares,gap):
 physical=[0]*9
 for i,j in enumerate(PHY):physical[j]=registers[i]
 ones={-1,64+gap}|{i for i,b in enumerate(pc)if b=='1'};p=65+gap
 for v in physical+spares:p+=1;ones.update(range(p,p+v+1));p+=v+1
 return ones
def inc(pc):
 n=len(pc);v=(int(pc,2)if pc else 0)+1
 return(format(v%2**n,'0'+str(n)+'b')if n else''),int(v==2**n)
def strip(pc,b,k):
 for i in range(len(pc)-1,-1,-1):
  if pc[i]==b:
   k-=1
   if not k:return pc[:i]
 raise ValueError('source branch escapes')
def expected(site,registers,spares,gap):
 pc,op,arg=site;r=list(registers);sp=list(spares);delta=0
 if op=='CI':r[arg]+=1;sp.append(1);nxt,shift=inc(pc)
 elif op=='CD'and r[arg]>0:r[arg]-=1;delta=1;nxt,shift=inc(pc)
 elif op in('CD','CB'):nxt,shift=inc(strip(pc,'0',arg if op=='CB'else 1))
 elif op=='CC':nxt=strip(pc,'1',arg);shift=0
 else:raise ValueError('halt case unsupported')
 return 84,-shift,{v-shift for v in frame(nxt,r,sp,gap+delta+shift)}
def clean(q,h,ones):
 if q!=84 or h-1 not in ones or any(x<h-1 for x in ones):return False
 right=sorted(x for x in ones if x>=h+52)
 if not right or right[0]<h+64:return False
 p=right[0]+1;last=max(ones);n=0
 while p<last:
  if p in ones or p+1 not in ones:return False
  p+=1
  while p in ones:p+=1
  n+=1
 return p==last+1 and n>=10
def replay(tp,sp,index,output,wanted):
 T=read_table(tp);site=json.loads(sp.read_text())[index];regs=[0]*9;spares=[0];gap=1
 want=expected(site,regs,spares,gap);ones=frame(site[0],regs,spares,gap);initial=sorted(ones);q=84;h=0;trace=[]
 for tick in range(100001):
  if tick and clean(q,h,ones):break
  need(tick<100000 and(q,int(h in ones))in T,'no complete redispatch within proof construction bound')
  b=int(h in ones);w,d,z=T[q,b];trace.append([q,h,b,w,d,z])
  if w:ones.add(h)
  else:ones.discard(h)
  q=z;h+=d
 matches=(q,h,ones)==want;need(matches==(wanted=='pass'),'unexpected control outcome')
 def conf(c):return{'state':c[0],'head':c[1],'one_cells':sorted(c[2])}
 report={'status':'CONCRETE_PRIMITIVE_CONTRACT_PASS'if matches else'CONCRETE_PRIMITIVE_CONTRACT_COUNTEREXAMPLE','scope':'One valid macro input, not a claim about blank-tape reachability.','table_sha256':hashlib.sha256(tp.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(sp.read_bytes()).hexdigest(),'site_index':index,'site':site,'logical_registers':regs,'spares':spares,'gap':gap,'initial_one_cells':initial,'steps_to_first_clean_redispatch':tick,'actual':conf((q,h,ones)),'expected':conf(want),'trace':trace}
 output.write_text(json.dumps(report,indent=2)+'\n');return{k:v for k,v in report.items()if k not in('actual','expected','trace','initial_one_cells')}
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--table',type=Path,required=True);ap.add_argument('--source',type=Path,required=True);ap.add_argument('--site',type=int,required=True);ap.add_argument('--expect',choices=['pass','fail'],required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();print(json.dumps(replay(a.table,a.source,a.site,a.output,a.expect),indent=2))
