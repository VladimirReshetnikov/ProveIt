#!/usr/bin/env python3
"""Offline reconstruction, local proofs, and optional full symbolic replay.

Python 3.10+, standard library only. No network and no synthesis solver.
The default replay checks the exact delivered bytes and new local proof
obligations. --full additionally rederives both runtime certificates.
The ordinary mathematical PA transport proof is in paper/report.pdf.
"""

import argparse
import gzip
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "code"))
from build_u217 import build, digest, NATIVE_HASH, DENSE_HASH, SOURCE_HASH
from check_local import read_table, require


PARENT_ARCHIVE_HASH = "73c7d0774d955c9b003eec0e9e0876e280f028f653a127c7518d132b914c8bc9"
GRANDPARENT_HASH = "d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652"


def load(path):
    return json.loads(path.read_text())


def check_manifest(directory):
    seen = set()
    for line in (directory / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        rel = PurePosixPath(name)
        require(not rel.is_absolute() and ".." not in rel.parts, "Unsafe manifest")
        require("\\" not in name and name not in seen, "Ambiguous manifest path")
        seen.add(name)
        require(digest(directory / name) == expected, "Hash mismatch: " + name)
    return len(seen)


def extract(archive, output, expected_hash, root_name):
    require(digest(archive) == expected_hash, "Unexpected archive identity")
    seen = set()
    with zipfile.ZipFile(archive) as source:
        for member in source.infolist():
            rel = PurePosixPath(member.filename)
            require(not rel.is_absolute() and ".." not in rel.parts, "Unsafe member")
            require(rel.parts and rel.parts[0] == root_name, "Wrong archive root")
            require("\\" not in member.filename, "Ambiguous archive member")
            require(member.filename not in seen, "Duplicate archive member")
            require(not stat.S_ISLNK(member.external_attr >> 16), "Archive symlink")
            seen.add(member.filename)
            path = output.joinpath(*rel.parts)
            if member.is_dir():
                path.mkdir(parents=True, exist_ok=True)
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                with source.open(member) as src, path.open("wb") as dst:
                    while data := src.read(1048576):
                        dst.write(data)
    return output / root_name


def command(script, arguments, label, optimized=False):
    print(label + " ...", flush=True)
    flags = ["-O"] if optimized else []
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    run = subprocess.run(
        [sys.executable, "-B", *flags, str(script), *map(str, arguments)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env,
    )
    if run.returncode:
        print(run.stdout, end="")
        raise RuntimeError(label + " failed")
    print(label + ": PASS", flush=True)


def replay_startup(table_path, parent):
    expected = load(parent / "evidence/startup.json")
    require(expected["steps"] == 95726, "Unexpected startup length")
    require(expected["state"] == 84 and expected["head"] == -8, "Wrong endpoint")
    require(expected["gap"] == 1, "Wrong startup gap")
    require(expected["registers"] == [4] + [0] * 8, "Wrong register seed")
    require(expected["spares"] == [1] * 40, "Wrong spare seed")
    table = read_table(table_path)
    q, head, ones = 0, 0, set()
    require(len(expected["trace"]) == expected["steps"], "Incomplete startup trace")
    for index, row in enumerate(expected["trace"]):
        bit = int(head in ones)
        write, direction, target = table[q, bit]
        actual = [q, head, bit, write, direction, target]
        require(actual == row, "Startup trace differs at step " + str(index))
        require(q != 112 and (q, bit) != (172, 0), "Changed row used during startup")
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        q, head = target, head + direction
    require(q == expected["state"] and head == expected["head"], "Endpoint mismatch")
    require(sorted(ones) == expected["one_cells"], "Complete startup tape mismatch")
    return {
        "status": "EXACT_PARENT_TRACE_AND_COMPLETE_TAPE_PASS",
        "steps": 95726, "state": q, "head": head, "gap": 1,
        "registers": expected["registers"], "spares": expected["spares"],
        "parent_startup_json_sha256": digest(parent / "evidence/startup.json"),
        "changed_row_and_removed_state_absent": True,
    }


def validate_runtime(receipt, cases, grandparent):
    require(receipt["status"] == "UNIVERSAL_MATHEMATICAL_PASS", "Runtime not proved")
    require(receipt["table_sha256"] == NATIVE_HASH, "Runtime table mismatch")
    require(receipt["sites_sha256"] == SOURCE_HASH, "Runtime source mismatch")
    require(receipt["working_states"] == 217, "Runtime state census mismatch")
    require(receipt["expected_cases"] == receipt["proved_cases"] == 5060,
            "Runtime case census mismatch")
    require(not receipt["failures"] and len(receipt["blocks"]) == 4,
            "Runtime block proof failure")
    require(receipt["startup_status"] == "CALIBRATED_DIRTY_ROOT_SEED",
            "Runtime startup is not calibrated")
    source = load(ROOT / "machine/u217_sites.json")
    expected = {(i, b) for i, site in enumerate(source)
                for b in ((False, True) if site[1] == "CD" else (False,))}
    actual = {(case["site_index"], case["positive"]) for case in cases}
    require(len(source) == receipt["site_count"] == 3891, "Source census mismatch")
    require(len(cases) == len(expected) == 5060 and actual == expected,
            "Saved symbolic case coverage incomplete")
    for key, filename in [("checker_sha256", "symbolic_runtime.py"),
                          ("helper_sha256", "independent_runtime.py")]:
        require(receipt[key] == digest(grandparent / "code/runtime" / filename),
                "Runtime implementation binding differs")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    require(not sys.flags.optimize, "Run the full driver with assertions enabled")
    began = time.monotonic()
    files_checked = check_manifest(ROOT)
    with tempfile.TemporaryDirectory(prefix="u217-replay-") as temp:
        work = Path(temp)
        parent = extract(ROOT / "inputs/U218_ConPA_2026-10-28.zip", work,
                         PARENT_ARCHIVE_HASH, "U218_ConPA_2026-10-28")
        parent_files = check_manifest(parent)
        require((parent / "machine/u218.native.tm").read_bytes()
                == (ROOT / "inputs/u218.native.tm").read_bytes(), "Wrong parent table")
        require((parent / "machine/sites.json").read_bytes()
                == (ROOT / "machine/u217_sites.json").read_bytes(), "Source changed")
        grandparent = extract(parent / "inputs/U222_ConU_2026-10-28.zip", work,
                              GRANDPARENT_HASH, "u222_consistency_machine")
        rebuilt = work / "rebuilt"
        build(ROOT / "inputs/u218.native.tm", rebuilt)
        for name in ("u217.native.tm", "u217.tm", "state_map.json", "summary.json"):
            require((rebuilt / name).read_bytes() == (ROOT / "machine" / name).read_bytes(),
                    "Reconstruction differs: " + name)
        for script, evidence in [("check_local.py", "local_certificate.json"),
                                 ("check_independent.py", "independent_certificate.json")]:
            for optimized in (False, True):
                result_path = work / (script + str(optimized) + ".json")
                command(ROOT / "code" / script,
                        [ROOT / "inputs/u218.native.tm", rebuilt / "u217.native.tm",
                         "--report", result_path],
                        script + (" with -O" if optimized else ""), optimized)
                require(load(result_path) == load(ROOT / "evidence" / evidence),
                        "Local certificate differs from recorded exact result")
        startup = replay_startup(rebuilt / "u217.native.tm", parent)
        receipt = load(ROOT / "evidence/runtime.json")
        cases = json.loads(gzip.decompress((ROOT / "evidence/runtime_cases.json.gz").read_bytes()))
        validate_runtime(receipt, cases, grandparent)
        prior = load(ROOT / "evidence/parent_full_replay.json")
        require(prior["status"] == "U218_FULL_REPRODUCTION_PASS"
                and prior["symbolic_cases_rerun"]
                and prior["native_sha256"] == digest(ROOT / "inputs/u218.native.tm"),
                "Saved parent full replay is not bound to this machine")
        if args.full:
            parent_report = work / "parent_full.json"
            command(parent / "reproduce.py", ["--full", "--report", parent_report],
                    "Fresh inherited U218 full reproduction")
            require(load(parent_report)["status"] == "U218_FULL_REPRODUCTION_PASS",
                    "Parent fresh full replay failed")
            runtime = work / "runtime"
            command(grandparent / "code/validate_native.py",
                    [rebuilt / "u217.native.tm", ROOT / "machine/u217_sites.json", runtime],
                    "Fresh U217 arbitrary-register symbolic verification")
            fresh = load(runtime / "runtime.json")
            fresh_cases = load(runtime / "runtime_cases.json")
            validate_runtime(fresh, fresh_cases, grandparent)
            require(fresh_cases == cases, "Fresh symbolic case derivations differ")
            require(fresh["blocks"] == receipt["blocks"], "Block schemas differ")
            require((runtime / "startup.json").read_bytes()
                    == (parent / "evidence/startup.json").read_bytes(),
                    "Fresh full startup record differs")
        result = {
            "status": "U217_FULL_REPLAY_PASS" if args.full else "U217_EXACT_LOCAL_AUDIT_PASS",
            "release_files_checked": files_checked,
            "parent_files_checked": parent_files,
            "working_states": 217, "transition_rows": 434,
            "exact_reconstruction_and_dense_bijection": True,
            "source_byte_identical_to_U218": True,
            "ordinary_rows_checked": 434, "three_cell_cases": 4,
            "inductive_five_cell_frames": 6960,
            "local_negative_controls": [13, 12],
            "local_certificates_unchanged_under_python_optimization": True,
            "startup": startup, "saved_symbolic_cases_checked": 5060,
            "all_symbolic_cases_freshly_rederived": args.full,
            "native_sha256": NATIVE_HASH, "dense_sha256": DENSE_HASH,
            "source_sha256": SOURCE_HASH, "parent_archive_sha256": PARENT_ARCHIVE_HASH,
            "seconds": round(time.monotonic() - began, 3),
            "scope": "Exact executable mathematical audit; PA proof in report. "
                     "No new proof-assistant kernel endpoint.",
        }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
