# A 232-state binary Turing machine for Con(U)

This packet supplies an explicit deterministic Turing machine with **232 working states**, six fewer than the 238-state reference in the request. Its mathematical correctness statement is

```text
PA proves: M does not halt from its blank initial tape  <->  Con(U).
```

Here `Con(U)` is the ordinary syntactic consistency assertion for the exact equality-free unary power-covering theory in the supplied research packet. The construction uses a PA refutation searcher together with the PA-provable equivalence `Con(PA) <-> Con(U)`. It does not enumerate U directly.

**Scope:** this is a concrete upper bound, not a proof of absolute state minimality. The new proof is a conventional mathematical proof with exact executable certificates. This archive does **not** contain a new kernel-checked Rocq, Lean, MM0, or literal PA proof object. The upstream PA238 formalization is pinned and its relevant source files are included; its complete kernel build was not rerun in this work.

## Start here

- `report.pdf` is the complete write-up, including the exact theory U, the PA consistency calibration, the source transformation, the unbounded tape proof, and the full transition table.
- `report.tex`, `results.tex`, `theory/u_consistency_section.tex`, and `machine/transition_table.tex` are its LaTeX sources.
- `machine/machine.tm` is the definitive dense transition table.
- `verification/reproduce.py` reproduces the finite certificates and runtime checks using Python's standard library.
- `PROVENANCE.json` identifies the pinned source revisions, logical dependencies, and key input hashes.
- `SHA256SUMS` records the packaged file digests. The separate final ZIP digest, if supplied with the download, identifies the archive as a whole.

## Machine convention

| Item | Convention |
|---|---|
| Working states | `0` through `231` inclusive |
| Halt destination | `232`, with no outgoing transitions |
| Initial state | `0` |
| Tape alphabet | `{0,1}` |
| Initial tape | All `0`, with no input or prewritten marks |
| Initial head position | `0` |
| Tape | One tape, infinite in both directions |
| Moves | Exactly one cell left or right at every transition |
| Transition rows | `464`, one for each working-state/read-symbol pair |
| Row format | `state read write direction next` |

Initialization is included in the state count. The separate halt destination is excluded, as in the usual binary busy-beaver convention. The leading `#! start 0` line is a comment identifying the initial state.

The native table has nonconsecutive working-state labels and halt label `254`. It is the same machine under the exact bijection in `machine/renaming_certificate.json`; the dense table is the recommended simulation input. Native dispatcher `84` corresponds to dense dispatcher `83`.

## Run the verification

Use Python 3.10 or later with assertions enabled. No numerical optimizer, external Python package, network access, theorem prover, or repository checkout is needed for this packet's verification.

From the unpacked packet directory:

```sh
python3 verification/reproduce.py
```

To retain fresh reports in a chosen output directory:

```sh
python3 verification/reproduce.py --output /absolute/path/to/fresh-verification
```

The script can also be invoked by its absolute path from another working directory. Do not pass `-O` or `-OO`, and do not set `PYTHONOPTIMIZE`: the symbolic mathematical guards deliberately reject optimized execution. A complete run takes a few minutes on the machine used to prepare this packet; timing depends on the host.

The reproduction path checks the **fixed published construction**. It does not rerun the search that selected the allocation. In particular, it:

1. Validates complete dense and native tables, their encodings, and the exact state bijection.
2. Expands the original PA source from the pinned `Prog238.v` node definitions and compares it with the separately supplied original source inventory.
3. Checks both independent source control-flow resolvers and the exact offset bisimulation from the original PA source to the selected new source.
4. Reconstructs the native table from the pinned K runtime and the explicit transition patch.
5. Proves all symbolic instruction cases using the selected literal rows, regenerates the four spare-block induction lemmas, and replays the complete blank initialization.
6. Runs a separately implemented literal simulator over four concrete valuations of every guarded source case and checks the whole tape, head, registers, spare list, and predicted duration.

It also checks `SHA256SUMS` when that manifest is present. A process exit code or a partially successful case count alone is not the acceptance criterion: all expected success statuses, hashes, cases, and seed conditions must hold.

## What was checked

| Obligation | Result and scope |
|---|---|
| Complete machine | 232 working states; 464 defined transition rows |
| Dense/native identity | All 464 rows agree under an explicit bijective state renaming |
| Selected source | 4,409 primitive occurrences; 207 distinct shared nodes; maximum depth 34 |
| Source equivalence | 2,646 exact product nodes; old/new entry-register difference `(1,0,0,0,0,0,0,0,0)` |
| Universal runtime | All 5,732 guarded instruction cases pass for arbitrary natural registers and gaps, and arbitrary nonempty finite spare lists |
| Block induction | Four one-block traversal lemmas rederived from the exact selected table |
| Blank initialization | 370,864 literal transitions to the exact complete root frame |
| Independent finite regression | 22,928 cases; 17,278,002 literal transitions; every affine duration prediction exact |
| Independent blank replay | The same 370,864-step computation and entire terminal tape |

The 5,732 universal cases are **not** 5,732 sampled executions. They keep register values, gaps, and spare lengths symbolic, with explicit natural-number and finite-list induction rules. The 22,928 literal cases are a complementary finite regression and are not substituted for that universal argument.

The clean initialization seed has logical registers

```text
(N,T,W,C,D,H,X,Y,P) = (2,0,0,0,3,0,0,0,0),
```

head position `-4`, gap `110`, and 160 spare blocks of value `1`. The source bisimulation relates it to the original PA source with next-candidate counter `3`. This satisfies the upstream enumeration completeness bound `next <= 32`; the retained-formula invariant also holds, while numeric parameter `D = 3` is allowed.

## Why the machine is smaller

The original PA search program is retained through an exact source equivalence, then implemented using the compact K-family binary tape runtime. The new source shares closed helpers, changes its binary instruction layout, and moves two increments under a checked register-offset relation. The source checks compare the final program directly with the original PA program, so correctness does not depend on trusting an optimizer's sequence of edits.

The decisive allocation change releases the inherited decoder role of native state `108`. Keeping that role had forced additional helper transitions to remain protected. Reassigning it reduces the protected helper closure and permits the final 232-state allocation. This is a reallocation with a fresh whole-tape proof, not deletion of a state justified by limited tests.

The proof chain is:

```text
M halts from blank
  <-> the selected new register source halts from its exact seed
  <-> the original PA source halts from the related seed
  <-> PA has a finite refutation
  <-> U has a finite refutation.
```

Each implication is justified by finite syntactic transformations and inductions available in PA. Classical negation gives the displayed nonhalting equivalence. No assumption that PA is consistent is used to establish that equivalence. The metamathematical conclusion that the machine actually does not halt follows if PA is consistent.

## Exact theory U

The object language is classical first-order logic over a nonempty domain, with one binary relation `∈` and no equality, constants, or function symbols. Write

```text
Sub(x,a) := forall t (t ∈ x -> t ∈ a).
```

For every formula `phi` whose free variables are contained in `{x}`, the sole nonlogical schema is

```text
forall a exists b [
  forall x (x ∈ b -> phi(x))
  and
  forall x (Sub(x,a) -> (phi(x) -> x ∈ b))
].
```

Binders are freshened before substitution. In particular, `a` is not permitted as a free parameter of `phi`. The report explains the two finite-proof translations underlying `PA proves Con(U) <-> Con(PA)`, including the parameter issue in the lower arithmetic interpretation. The original supplied packet is retained as `upstream/pa_unary_power_cover.zip`.

## Files and proof dependencies

| Path | Purpose |
|---|---|
| `machine/` | Dense and native tables, CSV/JSON encodings, source occurrences, state-renaming certificate, printable table |
| `construction/` | Exact fixed patch and reconstruction/export scripts; selected allocation and prefix map |
| `verification/` | Portable exact checkers and the original PA source inventory |
| `verification/runtime/` | Symbolic tape engine and supporting runtime representation |
| `verification/evidence/` | Recorded complete verification results and case certificates |
| `upstream/pa238/` | Selected original PA238 proof sources, source table, and upstream README |
| `upstream/k215/` | Pinned native K runtime, upstream README, and retained Wade license notice |
| `upstream/pa_unary_power_cover.zip` | Unmodified input packet defining and analyzing U |

The selected Coq files are included for precise reference and inspection. They are **not** the full upstream dependency closure, and are not a standalone Coq project. To rebuild the original PA238 formalization, obtain the full pinned busy-beaver repository and follow its `PA/m238/README.md`. That upstream rebuild checks the original PA238 endpoint; it does not automatically certify the newly supplied 232-state table. This packet's new mathematical and executable certificates supply the connecting argument.

## Build the report

From this directory, with a LaTeX installation containing the packages used by `report.tex`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The report sources are supplied independently of the verification programs. The machine-readable tables, rather than typeset text extraction, are the inputs to verification and simulation.

To regenerate the printable transition table and hash macros from the packaged machine before compiling, run:

```sh
python3 build_report_assets.py
```

## Key SHA-256 identities

```text
5524abf13e26347b56163b9b6a7779bc61fc65c50ae77bf206d40e672e448843  machine/machine.tm
b0f54f62904ff10d0d27a0116ee946976f99b4c9c4d6290a96147a4b53d65eb2  machine/machine.native.tm
05f39fbbf229152766c61e24071a8ec56e7212439a50249d18dfe214d21ba619  machine/source_sites.json
```

The provenance and notices distinguish the original PA construction, its formalization, the K runtime and checker ancestry, and the new reconstruction. No claim of absolute minimality or proof-assistant certification of the new table should be inferred from the state count.
