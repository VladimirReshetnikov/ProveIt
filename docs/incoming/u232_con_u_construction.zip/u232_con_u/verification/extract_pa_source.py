#!/usr/bin/env python3
"""Independently compare the frozen Coq node DAG and its leaf inventory.

The .v file is read as data. No Rocq source is executed. Both descriptions
must also match the separately serialized source used by the bisimulation.
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

OPS = {"EInc": "CI", "EDecnz": "CD", "EBreak": "CB",
       "EContinue": "CC", "EHalt": "CH"}


def extract(source, expected):
    raw = source.read_bytes()
    text = raw.decode("utf-8")
    body = text.split("Definition nodes238 (n : nat) : edge * edge :=", 1)[1]
    body = body.split("end.", 1)[0]
    edge_pattern = r"(?:ENode|EInc|EDecnz|EBreak|EContinue)\s+\d+|EHalt"
    node_pattern = (r"\|\s*(\d+)\s*=>\s*\((" + edge_pattern
                    + r"),\s*(" + edge_pattern + r")\)")
    rows = re.findall(node_pattern, body)
    nodes = {int(n): (a, b) for n, a, b in rows}
    assert len(nodes) == len(rows) == 185 and set(nodes) == set(range(185))

    def primitive(edge):
        fields = edge.split()
        return OPS[fields[0]], int(fields[1]) if len(fields) == 2 else None

    leaves = []

    def walk(edge, prefix, active):
        if edge.startswith("ENode "):
            n = int(edge.split()[1])
            assert n not in active, "cyclic instruction DAG"
            a, b = nodes[n]
            walk(a, prefix + "0", active | {n})
            walk(b, prefix + "1", active | {n})
        else:
            leaves.append([prefix, *primitive(edge)])

    walk("ENode 0", "", set())
    inventory_text = text.split("Definition path_inventory238", 1)[1]
    inventory_text = inventory_text.split(":[", 1)[-1] if ":[" in inventory_text else inventory_text
    inventory_text = inventory_text.split("];", 1)[0].split("].", 1)[0]
    inventory = []
    for path, edge in re.findall(r"\((\d+)%positive,\s*(" + edge_pattern + r")\)", inventory_text):
        assert not edge.startswith("ENode")
        inventory.append([bin(int(path))[3:], *primitive(edge)])
    serialized = json.loads(expected.read_text())
    assert len(leaves) == 4409
    assert leaves == sorted(leaves) == inventory == serialized
    return {"status": "PASS", "definition": "nodes238", "node_definitions": 185,
            "leaf_occurrences": len(leaves), "source_inventory_equal": True,
            "maximum_depth": max(len(p) for p, _, _ in leaves),
            "file_sha256": hashlib.sha256(raw).hexdigest(),
            "source_sites_sha256": hashlib.sha256(expected.read_bytes()).hexdigest()}


def main():
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError("Assertions must be enabled: do not use -O")
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("expected", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = extract(args.source, args.expected)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
