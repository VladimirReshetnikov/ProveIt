#!/usr/bin/env python3
"""Independent literal regression and bootstrap replay for the K-runtime table.

This program imports no symbolic checker or runtime helper. Instruction
successors come from subtree intervals, not binary carry/strip routines.
Finite tests supplement the universal certificate; they do not replace it.
"""
from pathlib import Path
import argparse,hashlib,json,time
PHY=(6,2,0,4,3,7,8,5,1)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read_table(path):
    result={}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        assert(q,b)not in result and b in(0,1)and w in(0,1)and d in('L','R')
        result[q,b]=(w,1 if d=='R'else-1,z)
    states={q for q,b in result}
    assert set(result)=={(q,b)for q in states for b in(0,1)}
    terminal={z for w,d,z in result.values()}-states
    assert len(terminal)==1
    return result,terminal.pop()

def intervals(rows):
    leaf={p:i for i,(p,op,k)in enumerate(rows)};bounds={};n=len(rows)
    assert len(leaf)==n and rows==sorted(rows)
    def walk(p):
        if p in leaf:lo,hi=leaf[p],leaf[p]+1
        else:
            a=walk(p+'0');b=walk(p+'1');assert a[1]==b[0];lo,hi=a[0],b[1]
        bounds[p]=(lo,hi);return lo,hi
    assert walk('')==(0,n)
    def unwind(p,bit,k):
        while p:
            final,p=p[-1],p[:-1]
            if final==bit:
                k-=1
                if k==0:return bounds[p][1]%n if bit=='0'else bounds[p][0]
        return 0
    successors=[]
    for i,(pc,op,k)in enumerate(rows):
        after=(i+1)%n
        if op=='CI':targets=[after]
        elif op=='CD':targets=[unwind(pc,'0',1),after]
        elif op=='CB':targets=[unwind(pc,'0',k)]
        elif op=='CC':targets=[unwind(pc,'1',k)]
        elif op=='CH':targets=[]
        else:raise ValueError(op)
        successors.append(targets)
    return successors

def frame(pc,logical,spares,gap):
    values=[0]*9
    for r,slot in enumerate(PHY):values[slot]=logical[r]
    ones={-1,64+gap}|{i for i,b in enumerate(pc)if b=='1'};at=65+gap
    for value in values+list(spares):
        assert value>=0
        ones.update(range(at+1,at+value+2));at+=value+2
    return ones

def main():
    ap=argparse.ArgumentParser();ap.add_argument('table',type=Path);ap.add_argument('sites',type=Path)
    ap.add_argument('runtime_directory',type=Path);ap.add_argument('output',type=Path)
    ap.add_argument('--dispatch',type=int,default=84);args=ap.parse_args()
    T,halt=read_table(args.table);sites=json.loads(args.sites.read_text());succ=intervals(sites)
    report=json.loads((args.runtime_directory/'runtime.json').read_text())
    assert report['status']=='UNIVERSAL_RUNTIME_AND_STRICT_BOOTSTRAP_PASS'
    assert report['table_sha256']==sha(args.table)and report['sites_sha256']==sha(args.sites)
    recorded=json.loads((args.runtime_directory/'runtime_cases.json').read_text())
    durations={(x['site_index'],x['positive']):x['duration']for x in recorded}
    boot=json.loads((args.runtime_directory/'bootstrap.json').read_text())
    q=h=0;ones=set()
    for tick in range(boot['steps']):
        w,d,q=T[q,int(h in ones)]
        if w:ones.add(h)
        else:ones.discard(h)
        h+=d
    assert(q,h,ones)==(boot['state'],boot['head'],set(boot['one_cells']))
    assert ones=={p+h for p in frame('',boot['logical_registers'],boot['spares'],boot['gap'])}
    assert q==args.dispatch
    scenarios=[([0]*9,[0],0),
               (list(range(9)),[4,0,2],0),
               ([3]*9,[0,1,7,0,3],11),
               ([6,0,9,1,0,5,2,0,4],[0]*17+[6],137)]
    count=total=maximum=0;started=time.monotonic()
    for scenario,(base,spares,gap)in enumerate(scenarios):
        for i,(pc,op,k)in enumerate(sites):
            for positive in((False,True)if op=='CD'else(False,)):
                regs=base.copy()
                if op=='CD':regs[k]=base[k]+1 if positive else 0
                output_regs=regs.copy();output_spares=spares.copy();delta=0
                if op=='CI':output_regs[k]+=1;output_spares.append(1)
                elif op=='CD'and positive:output_regs[k]-=1;delta=1
                target=succ[i][int(positive)]if op=='CD'else(succ[i][0]if succ[i]else None)
                overflow=int(target==0 and op!='CC')if target is not None else 0
                expected=None if target is None else{p-overflow for p in frame(sites[target][0],output_regs,output_spares,gap+delta+overflow)}
                # Affine certificate variables: constant,gap,9 registers,
                # first spare, and total width of remaining spare blocks.
                variables=[1,gap]+base+[spares[0],sum(x+2 for x in spares[1:])]
                duration=sum(a*b for a,b in zip(durations[i,positive],variables))
                ones=frame(pc,regs,spares,gap);q=args.dispatch;h=0
                for tick in range(duration+1):
                    if tick and((target is None and q==halt)or(target is not None and q==args.dispatch and h==-overflow and ones==expected)):break
                    assert tick<duration,('target not reached at certified duration',scenario,i,positive,duration,q,h)
                    assert(q,int(h in ones))in T,('unexpected halt',scenario,i,positive,q,h)
                    w,d,q=T[q,int(h in ones)]
                    if w:ones.add(h)
                    else:ones.discard(h)
                    h+=d
                assert tick==duration,('duration mismatch',scenario,i,positive,tick,duration)
                count+=1;total+=tick;maximum=max(maximum,tick)
        print('SCENARIO',scenario+1,'CASES',count,'LITERAL_STEPS',total,'SECONDS',round(time.monotonic()-started,2),flush=True)
    out={'status':'INDEPENDENT_LITERAL_REGRESSION_AND_BOOTSTRAP_PASS','table_sha256':sha(args.table),
         'sites_sha256':sha(args.sites),'checker_sha256':sha(__file__),'working_states':len(T)//2,
         'source_scenarios':scenarios,'cases':count,'literal_steps':total,'maximum_case_steps':maximum,
         'all_affine_duration_predictions_exact':True,'bootstrap_steps':boot['steps'],
         'entire_bootstrap_tape_equal':True,'successor_method':'independent subtree intervals',
         'seconds':time.monotonic()-started,'scope':'finite cross-check of the separate universal symbolic certificate'}
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)

if __name__=='__main__':main()
