#!/usr/bin/env python3
"""Replay whole-tape symbolic semantics for a new K-runtime U source.

The generic induction engine is the inspected upstream symbolic_runtime.py.
It proves its four arbitrary-block lemmas directly from the selected table;
no old table or source assertion is accepted. This wrapper checks exact
input domains, all new source leaves, both decrement branches, and a strict
literal blank bootstrap with zero formula and scratch registers.

This is executable mathematical verification, not a proof-assistant kernel
certificate. Logical calibration of the source is a separate obligation.
"""
from pathlib import Path
import argparse,hashlib,json,sys,time

BASE=Path(__file__).resolve().parents[1]
RUNTIME=BASE/'verification/runtime'
sys.path.insert(0,str(RUNTIME))
import symbolic_runtime as s

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def checked_inputs(table_path,sites_path):
    text=Path(table_path).read_text();starts=[x for x in text.splitlines() if x.startswith('#! start ')]
    assert starts==['#! start 0'],'literal start must be0'
    T=s.r.table(table_path);states={q for q,b in T}
    assert {0,84}.issubset(states) and 254 not in states
    assert set(T)=={(q,b) for q in states for b in (0,1)}
    assert {q for w,d,q in T.values()}-states=={254}
    sites=json.loads(Path(sites_path).read_text())
    leaves=set();prefixes=set()
    for pc,op,arg in sites:
        assert isinstance(pc,str) and 0<len(pc)<=64 and set(pc)<={'0','1'}
        assert pc not in leaves
        assert op in ('CI','CD','CB','CC','CH')
        if op=='CH':assert arg is None
        elif op in ('CI','CD'):assert type(arg)is int and 0<=arg<9
        else:assert type(arg)is int and arg>=1
        leaves.add(pc);prefixes.update(pc[:i] for i in range(len(pc)))
    assert not leaves&prefixes
    assert all(p+b in leaves|prefixes for p in prefixes for b in ('0','1'))
    assert len(prefixes)==len(leaves)-1
    m={int(k):int(v) for k,v in json.loads((BASE/'verification/legacy_mapping.json').read_text()).items()}
    for q in states|{254}:
        if q not in m:m[q]=1000+q
    assert len({m[q] for q in states|{254}})==len(states)+1
    assert m[84]==96 and m[254]==254
    L={(m[q],b):(w,d,m[z]) for(q,b),(w,d,z) in T.items()}
    return T,L,sites,m

def strict_bootstrap(T,limit):
    q=h=0;ones=set();used=set()
    for clock in range(limit+1):
        if q==84 and ones and min(ones)==h-1:
            rights=sorted(x for x in ones if x>h-1)
            if rights and rights[0]>=h+64:
                header=rights[0];p=header+1;last=max(ones);values=[];good=True
                while p<=last:
                    if p in ones or p+1 not in ones:good=False;break
                    p+=1;n=0
                    while p in ones:n+=1;p+=1
                    values.append(n-1)
                if good and len(values)>=10:
                    logical=[values[j] for j in s.r.PHY]
                    # T,W,H theorem registers and ac,scratch1,scratch2 are0.
                    if all(logical[j]==0 for j in (1,2,3,5,6,7,8)) and logical[0]+1<=32:
                        expected=s.r.frame('',logical,values[9:],header-h-64)
                        assert ones=={x+h for x in expected}
                        return {'status':'STRICT_CLEAN_ROOT_SEED','steps':clock,
                                'state':q,'head':h,'gap':header-h-64,
                                'logical_registers':logical,'spares':values[9:],
                                'one_cells':sorted(ones),'used_rows':sorted(used),
                                'entire_tape_equal_to_reconstructed_frame':True}
        if clock==limit:return {'status':'BOOTSTRAP_BOUND_EXHAUSTED','steps':clock,'state':q,'head':h}
        b=int(h in ones)
        if(q,b) not in T:return {'status':'EARLY_HALT','steps':clock,'state':q,'head':h}
        used.add((q,b));w,d,q=T[q,b]
        if w:ones.add(h)
        else:ones.discard(h)
        h+=d

def main():
    if not __debug__ or sys.flags.optimize:raise RuntimeError('assertions must be enabled')
    ap=argparse.ArgumentParser();ap.add_argument('table',type=Path);ap.add_argument('sites',type=Path)
    ap.add_argument('output',type=Path);ap.add_argument('--bootstrap-limit',type=int,default=3000000)
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    T,L,sites,m=checked_inputs(args.table,args.sites)
    report={'table_sha256':digest(args.table),'sites_sha256':digest(args.sites),
            'wrapper_sha256':digest(__file__),'induction_engine_sha256':digest(s.__file__),
            'induction_helper_sha256':digest(s.r.__file__),
            'working_states':len(T)//2,'source_leaves':len(sites),
            'maximum_source_depth':max(len(x[0]) for x in sites),
            'formal_kernel_checked':False,
            'source_logic_calibration':'separate obligation'}
    begun=time.monotonic();boot=strict_bootstrap(T,args.bootstrap_limit)
    (args.output/'bootstrap.json').write_text(json.dumps(boot,indent=2)+'\n')
    print('BOOTSTRAP',boot['status'],boot['steps'],flush=True)
    cases=[];failures=[];rows=set()
    try:lemmas,blocks=s.prove_blocks(L)
    except Exception as exc:failures.append({'block_failure':str(exc)});blocks=[]
    if not failures:
        for i,site in enumerate(sites):
            for positive in ((False,True) if site[1]=='CD' else (False,)):
                try:ans=s.case(L,lemmas,site,positive)
                except Exception as exc:
                    failures.append({'site_index':i,'site':site,'positive':positive,'error':str(exc)});break
                rows.update(ans.pop('rows'));ans.pop('trace')
                cases.append({'site_index':i,'positive':positive,**ans})
            if failures:break
            if(i+1)%500==0:print('SITES',i+1,'CASES',len(cases),'SECONDS',round(time.monotonic()-begun,2),flush=True)
    expected=sum(2 if x[1]=='CD' else 1 for x in sites)
    passed=not failures and len(cases)==expected and boot['status']=='STRICT_CLEAN_ROOT_SEED'
    report.update(status='UNIVERSAL_RUNTIME_AND_STRICT_BOOTSTRAP_PASS' if passed else 'NOT_ESTABLISHED',
                  expected_cases=expected,checked_cases=len(cases),blocks=blocks,failures=failures,
                  bootstrap_status=boot['status'],bootstrap_steps=boot['steps'],
                  used_literal_rows=sorted(rows),elapsed_seconds=time.monotonic()-begun,
                  quantified_scope='all nine natural primary values satisfying each branch guard; arbitrary natural extra gap; arbitrary nonempty finite spare list; complete blank exterior')
    (args.output/'runtime_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
    report['cases_sha256']=digest(args.output/'runtime_cases.json')
    (args.output/'runtime.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('blocks','used_literal_rows')},indent=2),flush=True)

if __name__=='__main__':main()
