"""Register-graph bisimulation with exact integral offset potentials.

At a pair of control points delta records R_before-R_after. Finite
unconditional increment clusters update it exactly. Every tested decrement
must have zero offset, so its zero/positive branch is identical. The finite
closed product graph therefore proves both halting directions for all natural
entry states satisfying the specified relation.
"""
import argparse,hashlib,json
from pathlib import Path
from verify_program_equivalence import resolve
from verify_closed_reuse import collapse

def verify(before,after,initial):
    a,b=resolve(before),resolve(after);todo=[(0,0,tuple(initial))];seen=set();records=[]
    while todo:
        i,j,delta=todo.pop()
        if (i,j,delta) in seen:continue
        if len(seen)>100000:raise ValueError('Unbounded candidate potential graph')
        seen.add((i,j,delta))
        va,ka,ea,sa=collapse(a,i);vb,kb,eb,sb=collapse(b,j)
        now=tuple(d+x-y for d,x,y in zip(delta,va,vb))
        if ka!=kb:raise ValueError(('Different operation',i,j,ka,kb))
        if ka[0]=='decrement' and now[ka[1]]!=0:raise ValueError(('Unequal tested register',i,j,ka,now))
        if len(ea)!=len(eb):raise ValueError('Different branch count')
        nexts=[(x,y,now) for x,y in zip(ea,eb)];todo.extend(nexts)
        records.append(dict(before=i,after=j,entry_offset=delta,before_increments=va,after_increments=vb,
                            operation=ka,exit_offset=now,successors=nexts,skipped_steps=[sa,sb]))
    return dict(status='PASS',before=str(before),after=str(after),initial_offset=initial,
                before_sha256=hashlib.sha256(before.read_bytes()).hexdigest(),after_sha256=hashlib.sha256(after.read_bytes()).hexdigest(),
                product_graph_pairs=len(records),scope='Every pair of natural nine-register entry vectors with R_before-R_after=initial_offset; halting equivalence and divergence',
                formal_kernel_check=False,certificates=records)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('before',type=Path);p.add_argument('after',type=Path);p.add_argument('output',type=Path);p.add_argument('--next-offset',type=int,default=0);a=p.parse_args()
    r=verify(a.before,a.after,[a.next_offset]+[0]*8);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='certificates'}))
