#!/usr/bin/env python3
"""Recheck the explicit 232-state construction using Python's standard library.

Run with Python 3.10+ and enabled assertions. No network, numerical optimizer,
proof assistant, or third-party Python dependency is needed. Output defaults
to a fresh temporary directory; the packaged evidence is never overwritten.
This is executable mathematical verification, not a proof-assistant proof.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
CHECK = ROOT / "verification"
PINNED = {
    "machine/machine.tm": "5524abf13e26347b56163b9b6a7779bc61fc65c50ae77bf206d40e672e448843",
    "machine/machine.native.tm": "b0f54f62904ff10d0d27a0116ee946976f99b4c9c4d6290a96147a4b53d65eb2",
    "machine/source_sites.json": "05f39fbbf229152766c61e24071a8ec56e7212439a50249d18dfe214d21ba619",
    "verification/original_pa_source_sites.json": "44b0476ee9b2743e9835aee47742f9ca0fed6ae701d2e4cb7a7c15f3bcd037f6",
    "upstream/pa238/coq/tm/Prog238.v": "fc88ecc4ab9962617886c6a508d667d95b6729d6aa0e8f85a21123787aa74334",
    "verification/runtime/symbolic_runtime.py": "53fa6147c91443393b76ff54dbe892e79f5b7540dd6858051518f67f5af1c4c7",
    "verification/runtime/independent_runtime.py": "778c664303eae892df7f5ba01b74c5def5d3a8c32936772ea984aeee091e4b5d",
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def table(path):
    result = {}
    lines = path.read_text().splitlines()
    assert [x for x in lines if x.startswith("#! start ")] == ["#! start 0"]
    for line in lines:
        if not line or line.startswith("#"):
            continue
        q, b, w, d, z = line.split()
        q, b, w, z = map(int, (q, b, w, z))
        assert (q, b) not in result and b in (0, 1) and w in (0, 1) and d in ("L", "R")
        result[q, b] = (w, d, z)
    return result


def load(path):
    return json.loads(Path(path).read_text())


def run(script, *args):
    print("RUN", str(script.relative_to(ROOT)), flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    subprocess.run([sys.executable, "-B", str(script), *map(str, args)],
                   check=True, cwd=ROOT, env=env)


def input_check():
    for relative, expected in PINNED.items():
        assert sha(ROOT / relative) == expected, ("input hash mismatch", relative)
    checksum_file = ROOT / "SHA256SUMS"
    checked = 0
    if checksum_file.exists():
        for line in checksum_file.read_text().splitlines():
            if not line.strip():
                continue
            expected, relative = line.split(maxsplit=1)
            relative = relative.lstrip("*")
            path = (ROOT / relative).resolve()
            assert path.is_relative_to(ROOT) and path.is_file()
            assert sha(path) == expected, ("manifest hash mismatch", relative)
            checked += 1

    dense = table(ROOT / "machine/machine.tm")
    native = table(ROOT / "machine/machine.native.tm")
    assert set(dense) == {(q, b) for q in range(232) for b in (0, 1)}
    native_states = {q for q, b in native}
    assert len(native_states) == 232
    assert set(native) == {(q, b) for q in native_states for b in (0, 1)}
    assert {z for w, d, z in dense.values()} - set(range(232)) == {232}
    assert {z for w, d, z in native.values()} - native_states == {254}
    cert = load(ROOT / "machine/renaming_certificate.json")
    pi = {int(k): v for k, v in cert["native_to_dense"].items()}
    assert set(pi) == native_states | {254} and set(pi.values()) == set(range(233))
    assert len(pi) == 233 and pi[0] == 0 and pi[84] == 83 and pi[254] == 232
    assert all(dense[pi[q], b] == (w, d, pi[z]) for (q, b), (w, d, z) in native.items())
    assert cert["dense_sha256"] == sha(ROOT / "machine/machine.tm")
    assert cert["native_sha256"] == sha(ROOT / "machine/machine.native.tm")
    spec = load(ROOT / "machine/machine.json")
    assert spec["working_states"] == 232 and spec["alphabet"] == [0, 1]
    assert spec["blank_symbol"] == spec["start_state"] == spec["initial_head"] == 0
    assert spec["initial_tape"] == "all0" and spec["halt_state"] == 232
    assert spec["halting_state_counted"] is False and len(spec["transitions"]) == 464
    assert {(r["state"], r["read"]): (r["write"], r["move"], r["next"])
            for r in spec["transitions"]} == dense
    def action(t):
        w, d, z = t
        return f"{w}{d}" + ("H" if z == 232 else str(z))
    with (ROOT / "machine/machine.csv").open(newline="") as handle:
        csv_rows = list(csv.reader(handle))
    assert csv_rows == [["state", "read0", "read1"]] + [
        [str(q), action(dense[q, 0]), action(dense[q, 1])] for q in range(232)]
    return {"status": "EXACT_INPUTS_AND_RENAMING_PASS", "working_states": 232,
            "transition_rows": 464, "manifest_files_checked": checked}


def main():
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError("Verification requires enabled assertions: remove -O/PYTHONOPTIMIZE")
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 or newer is required")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="new output directory (default: temporary directory)")
    args = parser.parse_args()
    out = args.output.resolve() if args.output else Path(tempfile.mkdtemp(prefix="u232-verification-"))
    out.mkdir(parents=True, exist_ok=True)
    assert out != CHECK / "evidence", "Do not overwrite packaged evidence"
    started = time.monotonic()
    inputs = input_check()
    print(json.dumps(inputs), flush=True)
    run(CHECK / "extract_pa_source.py", ROOT / "upstream/pa238/coq/tm/Prog238.v",
        CHECK / "original_pa_source_sites.json", out / "source_extraction.json")
    run(CHECK / "verify_offset_equivalence.py", CHECK / "original_pa_source_sites.json",
        ROOT / "machine/source_sites.json", out / "source_equivalence.json", "--next-offset", 1)
    source = load(out / "source_equivalence.json")
    assert source["status"] == "PASS" and source["product_graph_pairs"] == 2646
    assert source["initial_offset"] == [1] + [0] * 8
    run(ROOT / "construction/construct_fixed.py", ROOT / "upstream/k215/k215.native.tm",
        ROOT / "construction/construction_patch.json", out / "reconstructed.native.tm")
    assert (out / "reconstructed.native.tm").read_bytes() == (ROOT / "machine/machine.native.tm").read_bytes()
    run(ROOT / "construction/export_machine.py", out / "reconstructed.native.tm", out / "dense_export")
    assert (out / "dense_export/u232.tm").read_bytes() == (ROOT / "machine/machine.tm").read_bytes()
    run(CHECK / "runtime_check.py", ROOT / "machine/machine.native.tm",
        ROOT / "machine/source_sites.json", out / "runtime")
    runtime = load(out / "runtime/runtime.json")
    boot = load(out / "runtime/bootstrap.json")
    cases = load(out / "runtime/runtime_cases.json")
    sites = load(ROOT / "machine/source_sites.json")
    assert runtime["status"] == "UNIVERSAL_RUNTIME_AND_STRICT_BOOTSTRAP_PASS"
    assert runtime["working_states"] == 232 and not runtime["failures"]
    assert runtime["expected_cases"] == runtime["checked_cases"] == len(cases) == 5732
    expected_guards = {(i, p) for i, row in enumerate(sites)
                       for p in ((False, True) if row[1] == "CD" else (False,))}
    assert {(r["site_index"], r["positive"]) for r in cases} == expected_guards
    assert boot["status"] == "STRICT_CLEAN_ROOT_SEED" and boot["steps"] == 370864
    assert boot["logical_registers"] == [2, 0, 0, 0, 3, 0, 0, 0, 0]
    assert boot["state"] == 84 and boot["head"] == -4 and boot["gap"] == 110
    assert boot["spares"] == [1] * 160 and boot["entire_tape_equal_to_reconstructed_frame"]
    run(CHECK / "independent_literal_regression.py", ROOT / "machine/machine.native.tm",
        ROOT / "machine/source_sites.json", out / "runtime", out / "independent_regression.json")
    independent = load(out / "independent_regression.json")
    assert independent["status"] == "INDEPENDENT_LITERAL_REGRESSION_AND_BOOTSTRAP_PASS"
    assert independent["cases"] == 22928 and independent["literal_steps"] == 17278002
    summary = {"status": "ALL_EXECUTABLE_OBLIGATIONS_PASS", "working_states": 232,
               "transition_rows": 464, "source_product_pairs": 2646,
               "universal_runtime_cases": 5732, "bootstrap_steps": 370864,
               "independent_finite_cases": 22928, "independent_literal_steps": 17278002,
               "dense_sha256": sha(ROOT / "machine/machine.tm"),
               "formal_kernel_checked": False,
               "logical_calibration": "Mathematical PA proof in report; upstream PA238 proof is pinned, not rebuilt by this script",
               "output_directory": str(out), "elapsed_seconds": time.monotonic() - started}
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
