# Final targeted mathematical audit

## Conclusion and scope

No blocking mathematical flaw was found in the selected 232-working-state
construction, its register-program transformation, its seed calibration, or
the supplied unary power-covering interpretation. The result is an explicit
upper bound for a binary one-tape machine with blank input whose nonhalting
is provably equivalent in PA to Con(U).

This conclusion concerns a conventional mathematical proof whose finite
certificates and induction arguments are formalizable in PA. The archive
contains exact executable checkers for the new finite obligations. It does
not contain a newly generated Rocq, Lean, MM0, or literal PA proof object.
The upstream PA238 formal development is pinned and cited; its full kernel
build was not rerun here. Absolute state minimality is not claimed.

The report has incorporated the final 232-state metadata, the zero-padding
composition argument, and the corrected proof-chain display. No mathematical
correction remains outstanding from this targeted audit.

## Exact selected inputs and checked receipts

The following SHA-256 digests were recomputed from the selected files and
matched against the completed universal-runtime receipt:

| Artifact | SHA-256 |
|---|---|
| Native transition table | `b0f54f62904ff10d0d27a0116ee946976f99b4c9c4d6290a96147a4b53d65eb2` |
| Selected source sites | `05f39fbbf229152766c61e24071a8ec56e7212439a50249d18dfe214d21ba619` |

The dense public transition table is the exact bijective renaming of this
native table, as checked separately by the packaged renaming verification.
Its SHA-256 is
`5524abf13e26347b56163b9b6a7779bc61fc65c50ae77bf206d40e672e448843`.

The selected receipt records 232 working states, 4,409 source leaves,
maximum source depth 34, all 5,732 expected guarded instruction cases
checked, and no failures. Its status is
`UNIVERSAL_RUNTIME_AND_STRICT_BOOTSTRAP_PASS`.

This audit did not rerun the entire symbolic runtime. It checked the
completed receipt and its exact input identities, reviewed the mathematical
inference rules using the prior runtime audit, and independently reran the
final source-offset comparison. The portable packaged reproduction performs
the complete runtime check again.

## Final register-offset certificate

The exact comparison of the original PA source with the selected final
source was rerun successfully. It has 2,646 product nodes and initial offset

    R_old - R_new = (1,0,0,0,0,0,0,0,0).

Only three entry-offset vectors occur: zero, e_0, and e_0-e_5. Each product
node contracts only a finite sequence of register-independent jumps and
increments. An unconditional cycle is rejected. The two increment vectors
update the offset exactly. At the next conditional operation both programs
must test the same register and its updated offset must be zero. They
therefore select the same zero or positive branch; a matched positive
decrement subtracts one on both sides and preserves the offset. Halt matches
halt, and all successor pairs close in the finite relation.

Induction over the matched conditional operations gives finite halting in
both directions for all paired natural entry vectors satisfying the initial
offset. No infinite execution can remain within a contracted prefix, and
every continuing matched block includes an actual conditional operation.
Thus divergence is preserved as well. Temporary negative offsets do not
assert negative register values: both actual register vectors remain natural,
and the offset is their integer difference.

Both independent graph resolvers agree on the complete original and final
source graphs. The resolver now calls `source_language.tree` itself, so
valid opcodes, operand bounds, full prefix-free trees, and canonical leaf
ordering are explicit preconditions enforced by the checker. This closes
the generic-interface omission noted in the earlier audit.

## Exact blank seed and original PA enumerator premises

The strict bootstrap receipt gives an exact whole-tape root frame after
370,864 literal transitions from the all-zero tape. It records:

| Quantity | Value |
|---|---|
| Native dispatcher state | 84 |
| Head position | -4 |
| Additional header gap | 110 |
| Logical registers `(N,T,W,C,D,H,X,Y,P)` | `(2,0,0,0,3,0,0,0,0)` |
| Spare blocks | 160, all of value 1 |
| Entire tape equals reconstructed frame | true |

The source-offset certificate relates this seed to the original PA source
with next counter 3 and retained numeric tuple `(0,0,3,0)`. This is not the
old machine's particular blank checkpoint; the general source theorems are
what justify the new seed.

In the pinned upstream `Enum238.v`,
`enum_compiler_complete_from next q` assumes only `next <= 32` and numeric
derivability of the refutation code. It permits an arbitrary tuple `q`.
Thus it applies at `next = 3` and `q = (0,0,3,0)`. The pending candidate is
zero, as required for this enumerator boundary.

For soundness, `enum_halt_sound` requires the retained-formula invariant.
The pinned `SoundCommands238.v` explicitly defines

    retained (t,w,d,h) := derivable t /\ derivable h /\ safe_stack w

and proves

    Lemma retained_zero d : retained (0,0,d,0).

Consequently `d = 3` is permitted without any additional premise. The file
was independently fetched at busy-beaver revision
`05c050f8f60037929008c4d7c7ad5231adb032bf`; its exact bytes reproduce Git
blob `bbb5301f2c5bc9497fb1250e9bafcefa3d9a0d8a` (4,819 bytes). It is
included among the selected upstream sources.

`L2Root238.enc` places the enumerator data in precisely the nine logical
registers used here, with selector and scratch registers zero.
`iter_halts_enum`, `rm_halts_iff_iter`, and `p238_source_dag238` provide
the source-to-enumerator connection for this general register state.
The named ordinary-PA/numeric-refutation transports then supply both
logical directions without requiring the old physical transition table.

## Whole-tape runtime and composition

The prior symbolic-runtime audit established the soundness of its literal
transition rule, unary self-loop induction, and four arbitrary-block
traversal lemmas extended by induction to finite spare lists. The selected
table regenerated those four block proofs and passed every guarded source
case. Decrement zero and positive cases cover every natural value. All
other registers, the additional gap, and the nonempty finite spare list
remain arbitrary. The list-width variable denotes the width of the same
list at each occurrence. The proofs compare entire tapes with blank
exteriors, not just decoded register values or a bounded tape window.

Every accepted nonhalting case returns the prescribed frame with a strictly
positive affine duration. Literal steps and the traversal rules cannot pass
through a missing transition. Therefore the cases compose into a genuine
deterministic tape execution, and an infinite source execution cannot be
compressed into finitely many tape steps. A finite tape halt can conversely
be read back into finitely many source operations.

The source semantics in the pinned `RM238.v` explicitly use implicit trailing
zero bits and the instruction path actually read. A returned counter word
may be shorter than its next leaf, or longer with a zero suffix. The
arithmetic resolver's no-stray-one check guarantees that the returned word
and selected leaf produce the identical tape after zero padding to the
header. This closes the composition between successive universal runtime
cases, including the initial empty root word. The independent subtree
interval resolver confirms the selected successor leaf separately.

The separate independent literal regression reports 22,928 concrete cases,
17,278,002 literal instruction-case steps, exact agreement with affine
duration predictions, and a separate complete replay of the 370,864-step
blank bootstrap. These are valuable finite cross-checks and are not
substituted for the universal symbolic argument.

## Calibration of U

The supplied unary power-covering theory is equality-free classical
first-order logic over nonempty domains, with one binary relation and only
the schema whose matrix has at most its tested object free. The source
parameter cannot occur freely in that matrix.

The lower interpretation retains the delicate dependency order verified in
the independent U audit:

1. Numerical objects, predecessors, and existing successors are analyzed
   without assuming total successor.
2. Full induction, including arbitrary ambient parameters, is proved before
   successor totality.
3. A least-failure formula binds the numerical parameters inside the unary
   matrix. Neither a free source parameter nor a truth predicate is added.
4. Bounded numerical comprehension then supplies successors, numerical
   powers, saturated pair codes, and bounded graph comprehension.
5. Histories use independently bounded values. Old graph witnesses are
   existentially bound inside canonical extension formulas, so no forbidden
   free graph parameter enters a matrix.
6. Total functional addition and multiplication on numerical classes give
   the ordinary PA interpretation, including full parameter induction.

Saturated profiles are maintained throughout; global extensionality is not
assumed. In the upper interpretation, binary membership in PA bounds every
represented subset by its source code. Full PA induction proves finite
comprehension for each fixed translated formula. This does not claim an
algorithm deciding arbitrary arithmetic formula truth.

Both interpretations give uniform finite syntax constructions. Freshening,
substitution, fixed relational graph translations, and finite proof
concatenation are primitive recursive. Their correctness is proved by PA
induction on syntax and finite derivations. This gives internally in PA

    Con(U) <-> Con(PA).

The result is stronger than merely asserting external equiconsistency.
No consistency or reflection premise is used. A complete executable
translator for arbitrary PA/U proofs and a new proof-assistant certificate
of this interpretation are not part of the delivered formalization scope.

## Final internal theorem

The checked initialization, universal runtime, source-offset relation,
general-seed enumerator theorems, ordinary-PA proof transports, and U
interpretations establish, by the stated PA-inductive constructions,

    Halt(M) <-> existence of a finite PA refutation
            <-> existence of a finite U refutation.

Classical negation inside PA yields `Nonhalt(M) <-> Con(U)`. The machine
need not enumerate U's axioms directly. The theorem concerns the exact
232-state table and exact blank initialization identified above; it does not
transfer merely from the known Con(ZFC) calibration of K215.
