"""Independent all-register check of closed source-block replacements.

Resolve control using source-language binary paths and independently using
subtree intervals. Check a finite product-graph bisimulation after collecting
commuting increments. The checker does not use the producer's normalizer.
"""
import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import source_language as s

def cfg(rows):
    tree=s.tree(rows)
    if s.boundary(tree)!=(0,0,False):raise ValueError('Replacement is not closed')
    # A distinct explicit terminal node prevents wraparound at block return.
    wrapped=[['0'+p,op,n] for p,op,n in rows]+[['1','CH',None]]
    arithmetic,_=s.graph_arithmetic(wrapped)
    intervals=s.graph_intervals(wrapped)
    if arithmetic!=intervals:raise ValueError('Independent control resolvers disagree')
    return arithmetic

def collapse(g,i):
    added=[0]*9;visited=set();steps=0
    while True:
        effect,targets=g[i]
        if effect[0] not in ('increment','identity'):
            return tuple(added),effect,targets,steps
        if i in visited:raise ValueError('Unconditional cycle cannot be compressed')
        visited.add(i);steps+=1
        if effect[0]=='increment':added[effect[1]]+=1
        i=targets[0]

def check(before,after):
    a,b=cfg(before),cfg(after);todo=[(0,0)];seen=set();pairs=[]
    while todo:
        i,j=todo.pop()
        if (i,j) in seen:continue
        seen.add((i,j))
        va,ka,ea,sa=collapse(a,i);vb,kb,eb,sb=collapse(b,j)
        if va!=vb or ka!=kb:raise ValueError(('Different register operation',i,j,va,vb,ka,kb))
        if len(ea)!=len(eb):raise ValueError('Branch mismatch')
        todo.extend(zip(ea,eb))
        pairs.append(dict(before=i,after=j,increments=va,operation=ka,
                          successors=list(zip(ea,eb)),skipped_steps=[sa,sb]))
    return pairs

# The portable entry point uses collapse; no optimization or synthesis is run.
