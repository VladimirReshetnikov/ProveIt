# Reproduce the executable obligations

From the archive root, run:

```sh
python3 verification/reproduce.py
```

Python 3.10 or newer, its standard library, and enabled assertions are the
only requirements. Do not use `-O` or `PYTHONOPTIMIZE`. The driver refuses
optimized mode. It does not use the network, Rocq, Lean, a numerical solver,
or third-party Python packages. A full run takes several minutes on an
ordinary CPU; this is proof construction time rather than a bound on the
machine's execution.

By default, the driver writes fresh certificates into a temporary directory
and prints its path. To select the output directory:

```sh
python3 verification/reproduce.py --output /tmp/u232-check
```

The packaged `evidence/` is a record of an actual successful replay. The
driver recomputes these obligations rather than trusting that record:

1. Exact machine and source hashes; complete transition domains; agreement
   among the TM, JSON, and CSV representations; all 464 rows of the native
   to dense state bijection. If the archive's `SHA256SUMS` is present, every
   listed file is checked as well.
2. Independent expansion of the 185 node definitions in the pinned
   `Prog238.v`, agreement with its separately listed path inventory, and
   agreement with all 4,409 serialized original source leaves.
3. An exact finite register-offset bisimulation, resolving both control-flow
   graphs in two ways. The resulting 2,646 product states establish both
   halting directions for all natural register vectors with old `N = new N + 1`
   and all other initial registers equal.
4. Exact native table reconstruction from the pinned K table and a fixed
   replacement-row recipe, followed by deterministic dense renaming.
5. Four generic one-block induction schemas, followed by all 5,732 source
   instruction/branch cases on the entire symbolic tape. Register values,
   extra gap length, and a nonempty finite list of spare blocks are arbitrary.
6. A literal run of 370,864 transitions from the completely blank tape, with
   exact equality to the complete clean source-entry frame. The calibrated
   registers are `[2,0,0,0,3,0,0,0,0]`, the head is at -4, the gap is 110,
   and there are 160 one-valued spare blocks. The wrapper additionally checks
   the PA source's required zero registers and original `N <= 32` condition.
7. An independent literal simulator, which imports no primary runtime or
   source checker, repeats the full blank run and checks four diverse finite
   valuations of every guard: 22,928 cases and 17,278,002 instruction-replay
   transitions. This finite cross-check supplements the quantified proof.

The final `summary.json` must report `ALL_EXECUTABLE_OBLIGATIONS_PASS`.
Each subprocess is checked, and a missing or failing obligation terminates
the driver without that status.

## What these programs establish

The programs are exact executable mathematical verifiers. In particular,
the symbolic checker uses induction over unary runs and finite lists; it is
not merely a sample of small register values. Its 4,000-step internal search
limit bounds symbolic proof search, not register values or literal runtime.

They do not create a new proof-assistant kernel certificate, a literal PA
proof string, or a proof of the logical calibration by themselves. The report
supplies the mathematical PA-internal consistency argument and identifies
the pinned upstream PA238 source theorems. The selected upstream Rocq files
are evidence for inspection, not the complete dependency closure needed to
rebuild that development.

`runtime/symbolic_runtime.py` and `runtime/independent_runtime.py` retain their
original bytes and generic proof rules. Their historical direct-command
entry points expect earlier packet inputs; use the portable driver or
`runtime_check.py` here. `source_language.py` retains the source attribution
of its pinned K packet excerpt. No optimizer or state-minimization search is
performed by this verification package.
