"""Independent product-graph certificate for two complete register programs.

Both binary-path arithmetic and subtree-interval resolvers must agree. The
product check only contracts finite sequences of unconditional jumps and
increments; it never reorders a decrement, conditional branch, or halt.
The resulting finite bisimulation applies to every natural register vector.
"""
import argparse,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import source_language as s
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_closed_reuse import collapse

def resolve(path):
    rows=json.loads(path.read_text());s.tree(rows)
    a,_=s.graph_arithmetic(rows);b=s.graph_intervals(rows)
    if a!=b:raise ValueError('Independent source resolvers disagree')
    return a

def verify(before,after):
    a,b=resolve(before),resolve(after);todo=[(0,0)];seen=set();records=[]
    while todo:
        i,j=todo.pop()
        if (i,j) in seen:continue
        seen.add((i,j))
        va,ka,ea,sa=collapse(a,i);vb,kb,eb,sb=collapse(b,j)
        if va!=vb or ka!=kb:raise ValueError(('Different operation',i,j,va,vb,ka,kb))
        if len(ea)!=len(eb):raise ValueError('Different branch counts')
        todo.extend(zip(ea,eb))
        records.append(dict(before=i,after=j,increments=va,operation=ka,
                            successors=list(zip(ea,eb)),skipped_steps=[sa,sb]))
    return dict(status='PASS',before=str(before),after=str(after),
        before_sha256=hashlib.sha256(before.read_bytes()).hexdigest(),
        after_sha256=hashlib.sha256(after.read_bytes()).hexdigest(),
        product_graph_pairs=len(records),
        scope='Every natural nine-register vector; halting, divergence, and matching decrement branch choices',
        formal_kernel_check=False,certificates=records)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('before',type=Path);p.add_argument('after',type=Path);p.add_argument('output',type=Path);x=p.parse_args()
    r=verify(x.before,x.after);x.output.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k!='certificates'}))
