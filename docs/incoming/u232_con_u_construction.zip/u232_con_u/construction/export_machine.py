#!/usr/bin/env python3
"""Export a dense two-symbol TM and an exact state-renaming certificate."""
from pathlib import Path
import argparse,csv,hashlib,json

def table(path):
    T={}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,bit,w,d,z=line.split();q,bit,w,z=map(int,(q,bit,w,z))
        assert (q,bit)not in T and bit in(0,1)and w in(0,1)and d in('L','R')
        T[q,bit]=w,d,z
    return T

def encoded(T):
    return ('#! start 0\n'+''.join(f'{q} {bit} {w} {d} {z}\n'for(q,bit),(w,d,z)in sorted(T.items()))).encode('ascii')
def sha(raw):return hashlib.sha256(raw).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('native',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    raw=a.native.read_bytes();T=table(a.native);states=sorted({q for q,bit in T});N=len(states)
    assert states[0]==0 and set(T)=={(q,bit)for q in states for bit in(0,1)}
    assert {z for w,d,z in T.values()}-set(states)=={254} and 254 not in states
    pi={q:i for i,q in enumerate(states)};pi[254]=N
    D={(pi[q],bit):(w,d,pi[z])for(q,bit),(w,d,z)in T.items()}
    assert set(D)=={(q,bit)for q in range(N)for bit in(0,1)}
    assert len(pi)==N+1 and set(pi.values())==set(range(N+1))
    assert all(D[pi[q],bit]==(w,d,pi[z])for(q,bit),(w,d,z)in T.items())
    dense=encoded(D);name=f'u{N}'
    (a.output/(name+'.tm')).write_bytes(dense)
    spec={'model':'deterministic binary Turing machine on a two-way infinite tape','working_states':N,'alphabet':[0,1],'blank_symbol':0,'start_state':0,'initial_head':0,'initial_tape':'all0','halt_state':N,'halting_state_counted':False,'transitions':[{'state':q,'read':bit,'write':w,'move':d,'next':z}for(q,bit),(w,d,z)in sorted(D.items())]}
    (a.output/(name+'.json')).write_text(json.dumps(spec,indent=2)+'\n')
    action=lambda t:f'{t[0]}{t[1]}'+('H'if t[2]==N else str(t[2]))
    with(a.output/(name+'.csv')).open('w',newline='')as f:
        wr=csv.writer(f);wr.writerow(['state','read0','read1'])
        for q in range(N):wr.writerow([q,action(D[q,0]),action(D[q,1])])
    tex=['% Generated exact transition table. H is the uncounted halting state.',r'\begin{longtable}{rll}',r'\caption{Complete transition table for $M_{'+str(N)+r'}$.}\\',r'\toprule State & Read $0$ & Read $1$ \\',r'\midrule\endfirsthead',r'\toprule State & Read $0$ & Read $1$ \\',r'\midrule\endhead',r'\bottomrule\endfoot']
    for q in range(N):tex.append(str(q)+' & '+r'\texttt{'+action(D[q,0])+'} & '+r'\texttt{'+action(D[q,1])+r'} \\')
    tex.append(r'\end{longtable}');(a.output/(name+'_table.tex')).write_text('\n'.join(tex)+'\n')
    certificate={'status':'EXACT_BIJECTIVE_STATE_RENAMING','working_states':N,'transition_rows':2*N,'native_sha256':sha(raw),'dense_sha256':sha(dense),'native_start':0,'dense_start':0,'native_halt':254,'dense_halt':N,'native_to_dense':pi,'verified_rows':len(D),'assertion':'For every native row(q,b)=(w,d,r), the dense row(pi(q),b) is exactly(w,d,pi(r)). Tape contents, head position, and step count are unchanged on every configuration.'}
    (a.output/'renaming_certificate.json').write_text(json.dumps(certificate,indent=2)+'\n')
    print(json.dumps({k:v for k,v in certificate.items()if k!='native_to_dense'},indent=2))

if __name__=='__main__':main()
