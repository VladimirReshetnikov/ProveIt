#!/usr/bin/env python3
"""Reconstruct the selected native table from pinned upstream bytes and a patch.

No optimizer or solver is run. This is a deterministic reproduction step;
the separate all-input runtime proof certifies the resulting literal table.
"""
from pathlib import Path
import argparse,hashlib,json

def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
    T={}
    for line in raw.decode('ascii').splitlines():
        if not line or line.startswith('#'):continue
        q,bit,w,d,z=line.split();q,bit,w,z=map(int,(q,bit,w,z))
        assert(q,bit)not in T and bit in(0,1)and w in(0,1)and d in('L','R')
        T[q,bit]=(w,d,z)
    return T
def encode(T):return ('#! start 0\n'+''.join(f'{q} {bit} {w} {d} {z}\n'for(q,bit),(w,d,z)in sorted(T.items()))).encode('ascii')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('upstream',type=Path);ap.add_argument('patch',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
    P=json.loads(a.patch.read_text());raw=a.upstream.read_bytes().rstrip(b'\n')+b'\n'
    assert sha(raw)==P['upstream_canonical_sha256']
    T=parse(raw);deleted=set(P['delete_states']);T={k:v for k,v in T.items()if k[0]not in deleted}
    for q,bit,w,d,z in P['replace_rows']:T[q,bit]=(w,d,z)
    states={q for q,bit in T}
    assert set(T)=={(q,bit)for q in states for bit in(0,1)}
    assert {z for w,d,z in T.values()}-states=={254}
    assert len(states)==P['working_states'] and 0 in states
    result=encode(T);assert sha(result)==P['result_sha256'];a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(result)
    print(json.dumps({'status':'EXACT_FIXED_CONSTRUCTION_PASS','working_states':len(states),'rows':len(T),'sha256':sha(result)},indent=2))

if __name__=='__main__':main()
