# Pinned source material

These files are supplied for review and reproducibility. Their original
headers and notices are retained. No new license grant for upstream material
is asserted by this archive.

* `pa238/` contains selected files from `PA/m238` in
  [jeff87654/busy-beaver](https://github.com/jeff87654/busy-beaver/tree/05c050f8f60037929008c4d7c7ad5231adb032bf/PA/m238),
  commit `05c050f8f60037929008c4d7c7ad5231adb032bf`.
  This is **not a complete Rocq build closure**. The original README records
  the upstream formal verification. No upstream kernel build was rerun as
  part of this construction. The new reproduction driver reads `Prog238.v`
  as data and does not execute the selected Rocq or upstream Python files.
* `k215/k215.native.tm` is the source table used by the fixed construction.
  Its canonical SHA-256 (one terminal newline) is
  `9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2`.
  The K215 material was retrieved from
  [VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt/tree/94c354631b5a4c91619894b803c6e66dd8a57257/Computability/BusyBeaver/Research/ZFC),
  commit `94c354631b5a4c91619894b803c6e66dd8a57257`.
  The copied README describes that upstream machine, not the new 232-state
  table. `LICENSE.wade` is the retained upstream notice.
* `pa_unary_power_cover.zip` is the user's U theory packet, retrieved from
  `docs/incoming/pa_unary_power_cover.zip` in the same pinned ProveIt commit.
  Its original Git blob is `ee798b6ae9921965b2a4738bfe3b9bb3c3ca08f4`.

The mathematical endpoint for the new machine is proved by composing the
PA source calibration, the exact source bisimulation, the universal tape
simulation, the exact blank initialization, and the U/PA consistency
interpretations. An existing theorem about an older physical table is not
used in place of checking the new literal transition rows.
