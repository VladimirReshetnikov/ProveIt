# Attribution and upstream notices

This packet combines a new 232-state allocation and its connecting mathematical certificates with existing PA and K source material. Existing authorship and license notices are retained. This notice does not grant a new license over upstream material or change its terms.

## PA source and PA238 formalization

The original 238-state PA machine is the Mira construction identified in the request. The selected proof sources are from `jeff87654/busy-beaver`, commit `05c050f8f60037929008c4d7c7ad5231adb032bf`, directory `PA/m238`. The upstream README credits its original machine/source pin `6f7f0c2f97703839e56a705bbf5da5a0e5c132cf` in `mm0-bb`, and generic proof infrastructure adapted from Jeffrey's `ZF/m254` development at commit `c132d7eae8158cd3a9850ea3eb7251158c3dd821`.

The upstream development also uses the Coq Library of Undecidability (MPL-2.0) and BusyCoq (MIT and MIT-X11), as identified in its retained README. Those complete vendor trees are not included here. The selected Coq sources preserve their original headers, and the full dependency and license notices remain available in the pinned upstream repository. This packet does not represent its selected excerpts as the full independently buildable PA238 development.

## K runtime, source infrastructure, and mathematical checking

The compact runtime and symbolic-checking ancestry come from the K215/K225-family material in `VladimirReshetnikov/ProveIt`, pinned to commit `94c354631b5a4c91619894b803c6e66dd8a57257`. The retained K215 README records the prior source transformations, numerical-calculus calibration, compiler ancestry, composition/allocation work, and independent reviews. Its history names the `opening_encoder` and `review_upstream_reflection` contributions; this packet does not reattribute those contributions to the new construction.

The Wade compiler ancestry carries the MIT No Attribution notice, copyright 2025 Andrew James Wade. That notice is retained at `upstream/k215/LICENSE.wade`. The source-language utility header also preserves its excerpt provenance. The runtime engines retain their existing explanatory headers; the portable wrappers and connecting source certificates in this packet are separate new work.

The PA-internal K215 proof repository `elliotglazer/k215-pa`, commit `992b76d60d1a138d84e184cd8b6796243646a984`, is part of the comparison and proof context. Its PA endpoint is not silently substituted for the verification of this new PA/U machine.

## Unary power-covering packet

The input archive `pa_unary_power_cover.zip` is preserved unmodified from `VladimirReshetnikov/ProveIt` at the pinned revision. Its own sources, authorship, claims, and any terms remain as provided. The new report develops the consistency bridge needed for this construction and identifies the input packet explicitly.

## New work and verification scope

The new contribution is the selected PA source transformation, the exact offset-bisimulation certificate, the 232-state runtime allocation and fixed reconstruction patch, the fresh whole-tape runtime and initialization certificates, the independent literal replay, and the explanatory report and packaging. These are an explicit upper-bound construction with a conventional mathematical proof and reproducible checks. No new proof-assistant kernel certificate, unconditional nonhalting theorem, or absolute minimum-state claim is included.
