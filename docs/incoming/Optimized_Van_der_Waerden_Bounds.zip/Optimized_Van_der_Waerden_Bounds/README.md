# Optimized Superexponential van der Waerden Bounds and Robust Colorings

Research report prepared for Vladimir Reshetnikov and the ProveIt project, 7 October 2026. Developed with ChatGPT.

## Main result

For absolute constants C, b > 0 and all sufficiently large integers k, the article proves

    log W_2(k) >= (k/24)(log k - 5 log log k) - Ck.

It constructs a cyclic binary coloring, and an interval coloring obtained from it, in which every k-term progression has at least

    floor(b k^(2/3) (log k)^(5/3))

positions of each color. Logarithms are natural.

The article also proves a ternary primitive with leading coefficient 1/18; an exact binary–ternary product formula uniform in the number of colors; a general robust perturbation theorem; a subpower description bound; prescribed-interval inverse bounds; and a fixed-power robustness tradeoff. For three or more colors, robustness means distance from every constant word, not that every color must occur.

## Mathematical status and attribution

These are ordinary mathematical proofs. The strengthened results have not been checked in Lean or Rocq. The finite computations are reproducible checks of specific identities and probability estimates, not a certificate of the asymptotic existence theorem.

The cyclic embedding, adaptive mesh, anchored counting, local-lemma structure, and norm-indexed perturbation build on OpenAI Math family 160, *Quantitative Superexponential Bounds for van der Waerden Numbers*. The article reconstructs the necessary proof with its modified hypotheses. It credits the existing periodic extension factor to Campos–Fox–Schildkraut.

The main new quantitative steps are the multiplicity-two norm-band argument, residual-light-set balance tests, economical short-period dilation, joint entropy optimization, and robust binary–ternary assembly. The article distinguishes improvement over the inspected sources from a global priority claim. It gives no optimized numerical onset and makes no claim to the strongest bound in every growing-palette regime.

## Files

| File | Purpose |
| --- | --- |
| paper.pdf | Complete article |
| paper.tex | Main LaTeX file |
| sections/01-results.tex | Results, repository review, source comparison, and scope |
| sections/02-geometry.tex | Cyclic geometry, dilation, meshes, and rational returns |
| sections/03-outer.tex | Global and local pattern counts and the residual-test local lemma |
| sections/04-perturbation.tex | Abstract robust perturbation, multiplicity two, and the endpoint |
| sections/05-consequences.tex | Mixed-radix products, palette optimization, inversion, and tradeoffs |
| sections/06-research.tex | Claim audit, integration route, and ten research questions |
| references.bib | Bibliography with pinned repository links |
| paper.bbl | Generated bibliography supplied for convenience |
| figures/parameter_region.pdf | Vector figure of the sufficient exponent region |
| figures/make_parameter_region.py | Reproducible figure source |
| verify.py | Exact finite algebraic and combinatorial verification |
| verification_results.json | Results and tested ranges from the included verification program |
| requirements.txt | Python dependencies for checks and figure regeneration |
| SOURCE_PROVENANCE.json | Full repository commit identifiers, source paths, and proof-status boundaries |
| Makefile | Optional build and verification commands |
| SHA256SUMS | Checksums of the package's deliverable files |

## Build the article

A standard TeX Live installation with pdfLaTeX, BibTeX, and latexmk is sufficient. The vector figure is supplied, so Python is not needed just to compile the article.

From this directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex

Alternatively:

    pdflatex -interaction=nonstopmode -halt-on-error paper.tex
    bibtex paper
    pdflatex -interaction=nonstopmode -halt-on-error paper.tex
    pdflatex -interaction=nonstopmode -halt-on-error paper.tex

The supplied bibliography can also be used directly by pdfLaTeX when no citations are being changed.

## Reproduce the finite checks and figure

With Python 3.10 or newer:

    python3 -m pip install -r requirements.txt
    python3 verify.py
    python3 figures/make_parameter_region.py

The verification program exits unsuccessfully if a check fails. It records its scope and case counts in verification_results.json. No network access, repository credentials, Lean installation, or large coloring search is required.

The supplied run passed all eight groups. It checks 9,999 palette sizes,
74,834 mixed-radix sample identities, 18,760 actual cyclic product
progressions, 46,900 periodic interval progressions, 31,324 dilation
denominators, and 71,517 exact shared-key probability cases, in addition to
symbolic reversion, endpoint cancellations, and rational norm-band cases.
Complete ranges and witnesses are in the JSON report. The article was
built with TeX Live 2023/pdfTeX and latexmk 4.83; the companion run used
Python 3.12.14 and SymPy 1.14.0. The figure was generated with Matplotlib
3.10.8.

Optional Make targets:

    make all
    make verify
    make figure

## Integration into ProveIt

A suggested destination is:

    Combinatorics/Ramsey/Research/Optimized_Van_der_Waerden_Bounds/

This is a standalone lower-bound research package. It is not an exact replacement for one of the 120 Gowers statements in the existing formalization ledger. The article proposes a staged formalization through the norm-band lemma, the finite perturbation theorem, the mixed-radix transfer, the mesh and arrangement lemmas, the residual event family, and the asymptotic parameter assembly.

The work reviewed the following checkpoints:

- openai/math: adc7f1241b42e322a6451854ab7e4b4c146bf78a
- VladimirReshetnikov/ProveIt: bbde2b873b2dc7b48af1730926452bdda18bf9c8

The full source inventory is in SOURCE_PROVENANCE.json. No repository files were modified or published as part of preparing this package.

