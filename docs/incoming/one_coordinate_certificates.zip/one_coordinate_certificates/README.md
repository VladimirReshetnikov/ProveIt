# The Price of One Coordinate
## Self-sizing quadratic certificates for universal computation

Research report prepared for Vladimir Reshetnikov, 2 October 2026.

## Main results

The report answers a specific further-research question from *Unique Histories
from Linear Equations*. A universal affine-linear compiler over N[X] cannot
guarantee computably bounded coefficients for even one full solution per
accepted input. For a system with n polynomial unknowns, matrix degree d,
right-hand degree at most M, and coefficient bound B, a finite-state solver
has (B+1)^(n*d) memory states; a solution exists only if one exists through
degree M+(B+1)^(n*d).

A replacement compiler uses 11 identities of unknown-degree at most two on
s^3+s+7 unknown polynomials. Every nonlinear monomial contains the same
stride variable S. The equations S+E=X+X*E and S*B=X*D force S=X^W and
W=m+2*h+2, where h is the accepting time recovered from the certificate.
The complete witness is unique and automatically Boolean-coefficient for a
first singleton accepting evolution. No horizon or degree cutoff is an
argument to the compiler.

The article includes complete proofs, an exact full-witness correspondence
with the earlier two-coordinate compiler, a single-quartic version, degree
and support formulas, a bounded ordinary scalar construction, a labelled
branching theorem, counterexamples, and nine further research directions.

## Files

- `one_coordinate_certificates.pdf`: the 30-page rendered article.
- `one_coordinate_certificates.tex`: self-contained LaTeX source and bibliography.
- `code/compiler.py`: exact sparse polynomial compiler, checked witness interface,
  injective-feature variants, and separate candidate construction.
- `code/bounded_linear.py`: finite-state bounded-coefficient linear solver.
- `code/verify.py`: seven finite test suites and deterministic JSON receipts.
- `code/export_example.py`: all equations, all witness coordinates, and the
  fully expanded worked quartic.
- `results/`: complete exports, test receipts, and SHA-256 export hashes.

## Reproduce

Python 3.10 or later is sufficient; no third-party Python packages are used.
From the package directory:

```text
python code/verify.py
python code/export_example.py
```

A single suite can be run with, for example:

```text
python code/verify.py --part bounded_linear
```

The remaining suite names are `binary`, `multistate`, `ray_geometry`,
`independent_tiles`, `mutations`, and `interfaces`.

To rebuild the PDF with a TeX distribution containing the packages in the
preamble:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error one_coordinate_certificates.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error
one_coordinate_certificates.tex` three times, so the two-page contents and
cross-references stabilize. The source needs no external files or network
access. Font binaries are not included.

## Executed checks

All seven suites passed. The receipts record:

- 7,168 binary rule/input/horizon candidates; 768 admitted.
- 576 multistate candidates and 576 additional binary-feature checks; 59 admitted.
- 6,561 stride-prefix candidates and 432 clock-parameter tuples.
- 4,096 independently assigned source tableaux; exactly 8 structurally admitted.
- 178 coefficient deletions/doublings and 75 off-region insertions, all rejected.
- Wrong-horizon, excess-stride, and a literal zero-stride-ghost test.
- 729 scalar linear systems compared with exhaustive degree-six Boolean search,
  plus four solver edge cases.
- 12 invalid input rejection tests, source-table ownership and template checks.

The worked four-symbol example has input length 5, acceptance time 4,
stride 15, 75 polynomial unknowns, 11 equations, maximum witness degree 74,
and 89 nonzero witness coefficients. Its expanded quartic has 12,376 terms,
or 7,455 unknown monomials after grouping coordinate-polynomial coefficients.
Four exact expanded-polynomial evaluations match direct residual-square sums.

## Export schemas

In `example_system.json` and `example_quartic.json`, a term is represented as:

```json
{"x_power": 2, "variables": ["q", "stride"], "coefficient": -1}
```

This denotes `-X^2 * q * stride`. Variable names can repeat in the quartic;
repetition denotes an ordinary product, not an idempotent or Boolean product.
All equations are identities equal to zero in Z[X] after substitution of
natural-coefficient witness polynomials.

In `example_witness.json`, each component is a list of `[exponent, coefficient]`
pairs; an empty list is the zero polynomial. Omitted coefficients are zero.
The full variable interface is recorded in `example_system.json`.

The scalar degree-cutoff theorem is proved in the article. The example receipt
reports its scalar dimensions; the package does not emit the much larger
5,625-variable scalar quartic. The supplied expanded quartic is the complete
75-polynomial-variable equation over N[X]. The labelled nondeterministic
extension and generic Turing-machine bridge are proved in the article, not
implemented as additional source-language frontends in this code.

## Scope and trust

This is an unrefereed manuscript with written proofs and exact finite tests.
It is not a Lean/Rocq formalization, and no proof-assistant kernel was run.
Historical priority for the combined normal form is not established.

The source theorem applies to deterministic radius-one cellular automata with
a total quiescent rule, a nonempty input word, and first singleton acceptance.
An arbitrary first event containing several accepting cells is intentionally
not accepted. The one-head Turing-machine simulation has singleton acceptance
automatically. The worked rule is not claimed to be universal, and a particular
numerical universal machine table has not been instantiated in the exports.

Polynomial unknowns contain unbounded finite data. These results are not
ordinary fixed-variable single-fold Diophantine representations over N and do
not change the ProveIt 75-operation/87-operation natural-arithmetic bounds.
General *unrestricted* univariate linear polynomial-semiring systems remain
outside the bounded-coefficient decision theorem.

Repository inspection was tied to commit
`44983ed7ebfd545de55bfdb50e040c82f3d24295`, principally the root and
Hilbert-tenth overview. This is not an audit of the entire repository.
