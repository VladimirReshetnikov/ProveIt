# A rank-six cubic sector with a complete core

This report proves the two strict shifted ULC6 inequalities for the sector that selects all three right-core vertices in a genuine 3+3-cover graph with a complete core. Both exterior neighborhood systems are arbitrary. Left activities are one and right activities are arbitrary positive real numbers.

It also proves eventual strict ULC6 under common scaling of the three right-core activities, with a computable field-dependent bound. It does not prove the finite-activity rank-six conjecture or a theorem for noncomplete cores.

## Files

- `article.pdf` and `article.tex`: five-page report and editable source
- `code/verify_complete_core.py`: exact symbolic identities and 120 direct conditional-support enumerations
- `data/verification.json`: the recorded verification result
- `build_local.sh`: the local TeX build helper

## Reproduce the checks

Use Python 3 with SymPy installed:

```sh
python code/verify_complete_core.py
```

The code checks all three Hessian identities, the six-coefficient expansion, and positivity of each coefficient in the cone n,p,q≥1 and p²≥nq. It then directly enumerates 120 conditioned support polynomials with arbitrary exterior neighborhoods and positive integer right activities. All arithmetic is exact. These tests support the proof; the real-activity and unbounded-population quantifiers follow from the mathematical argument.

The matroid independence-count input is normalized by the ground-set size, not by matching rank. The report only uses its weaker consequence p²≥nq.

For a standard TeX installation, run `pdflatex article.tex` twice. The included helper supports the research environment's existing TeX setup.
