# Lexicographic ordering of all well-orderings of the real line

Research article prepared for Vladimir Reshetnikov, October 2, 2026.

## Contents

- `article.pdf`: the typeset article, with complete written proofs, summary tables,
  bibliography, and seven further research questions.
- `article.tex`: self-contained LaTeX source; the bibliography is embedded.
- `finite_checks.py`: reproducible standard-library Python sanity checks.
- `finite_checks_results.json`: the recorded successful run.
- `research_audit.md`: conventions, source provenance, proof status, and limitations.
- `build.sh`: a minimal PDF build script.

## The order being studied

An element is a bijective ordinal enumeration of the entire real line, or,
equivalently, a well-ordering relation on the labeled set of real numbers.
Two different enumerations are compared at their first unequal coordinate,
using the **ordinary real order**. They cannot be proper prefixes of one another.
This is not an ordering of ordinal isomorphism types and is not an arbitrary
lexicographic coding of binary relations.

The article assumes ZFC and writes kappa = c = |R|, as an initial ordinal.
The symbol kappa^+ denotes the successor cardinal, not ordinal addition by one.

## Principal conclusions

The full order has cardinality 2^c. Its ordinal embedding spectrum, and its
reverse-ordinal spectrum, consists exactly of all alpha < c^+. Every linear
order of size at most c embeds even into any prescribed enumeration-length
slice whose length has cardinality c.

Jumps come exactly from finite final permutation blocks. A maximal finite
convex class has n! elements. Isolated points form a dense subset of size 2^c;
the nonisolated remainder is perfect and nowhere dense, also of size 2^c.

The proper Dedekind-gap cofinality pairs are exactly (omega, rho) and
(rho, omega), for infinite regular rho <= c. There are exactly 2^c such gaps,
and Dedekind completion does not enlarge the cardinality. In contrast,
points can have equal uncountable cofinalities on both sides; the article
classifies the entire point-character spectrum.

The minimal-length slice is dense, has density/cellularity/weight 2^{<c},
and has constant two-sided point character cf(c) > omega. It contains a
copy of every order of size at most c inside every nonempty open interval.
Longer enumerations replace certain balanced gaps of that slice with entire
residual permutation orders. The article gives an exact lexicographic-sum
representation of the full order.

Collapsing maximal finite convex classes produces an equimorphic dense order,
whose completion is a connected linear continuum of size 2^c. The bounded
surreal sign orders S_{<theta} embed for every theta < c^+, whereas
S_{<c^+} itself does not, despite having the same cardinality as the target.

## Reproduce the finite checks

Requires Python 3.10 or later, with no third-party packages:

```sh
python finite_checks.py --output finite_checks_results.json
```

Do not run with `python -O`, which disables assertions. The script rejects
optimized execution explicitly.

The recorded run passed:

- 511 pair encodings and 43,435 first-disagreement comparisons;
- 16,072 prefix-cone checks;
- 46,225 neighbor checks through permutation size 8;
- 266,272 all-pair jump-criterion checks through permutation size 6;
- initial-segment coding for 5,914 finite linear orders through size 7.

These tests do **not** prove any statement about uncountable orders. The
transfinite arguments are written proofs in the article, not machine-checked
formalizations.

## Rebuild the PDF

A standard TeX Live installation with pdfLaTeX and the packages named in the
preamble is sufficient. No external images, fonts, bibliography files, network
access, or shell-escape are required.

```sh
sh build.sh
```

Equivalently, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times, to settle the table of contents, theorem references, and links.

## Research status

No historical-priority claim is made. The standard binary initial-segment
encoding is explicitly attributed. The particular structural analysis is
proved in the article, but has not been independently refereed or checked in
Lean. No changes were made to the ProveIt repository.

The repository audit is pinned to commit:
`6ea60e3677bd847a00baf023c3c532c83884530e`.

The unconditional comparison between the full order and its minimal slice
is **not** settled here: the nonembedding result assumes
2^{<c} < 2^c. The questions section explicitly retains the other cases and
other unresolved classification problems.
