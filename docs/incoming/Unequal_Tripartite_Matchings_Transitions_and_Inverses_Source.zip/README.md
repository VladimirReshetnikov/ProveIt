# Report178: maximal matchings at a tripartite triangle boundary

This package accompanies the mathematical report on maximal matchings of
`K_(2n+d,n,n)`. It contains the manuscript, exact finite coefficient and integer
checks, an offline reproducible builder, and optional arbitrary-precision
numerical diagnostics. It is not an OEIS submission, a universal novelty claim,
or a certified numerical inverse calculator.

## Quick verification

Use Python 3.10 or newer. The core uses only the Python standard library.
Run these commands from the extracted package directory:

```
python -B code/verify.py
python -B -O code/verify.py
python -B guard_tests.py
python -B -O guard_tests.py
python -B test_build.py
python -B -O test_build.py
python -B verify_manifest.py
```

The last command applies to the complete ZIP package, which contains
`SHA256SUMS.json`. The authoring source directory is not itself a finalized ZIP
package and has no manifest. Every check uses explicit runtime validation;
Python optimization does not disable it. None of these commands changes the
manuscript, reference data, or package files.

Recompute the exact data into a new file outside the package:

```
python -B code/regenerate.py --compare data/certificates.json --output ../new-certificate.json
```

An existing output file is refused. The generated file must be byte-identical to
`data/certificates.json`. See `README_CODE.md` for the finite scope of each check.

## Rebuild the complete deliverables

A working TeX installation providing pdfTeX, pdfLaTeX, kpsewhich and the packages
used by `Report178.tex` is required. The build does not install dependencies,
access the network, or enable TeX shell escape. Use a new sibling output directory:

```
python -B build.py --output ../rebuild-one
python -B -O build.py --output ../rebuild-two
```

The output must be outside the source package, including under resolved path aliases. The source inventory must match the explicit list; an extracted release must also pass its manifest check. The output parent must already exist. The output directory itself must not exist,
including as a dangling symlink. Each successful build publishes exactly:

- `Report178.tex`
- `Report178.pdf`
- `Report178.zip`
- `ARTIFACTS.json`, containing byte counts and SHA-256 digests for the three files

The builder runs the exact verifier, corruption guards and build guards in both
normal and optimized modes. It compares their results, compiles until TeX
auxiliary files stabilize, rejects unresolved references, overfull boxes and
missing characters, checks a complete SHA-256 inventory, and creates a ZIP with
fixed entry timestamps, order and permissions. Existing output is never replaced.
Private temporary TeX caches isolate the build from user TeX/Python overrides.
PDF and ZIP bytes are deterministic for the same sources and installed Python/TeX
stack; byte identity across different software versions is not promised.

The manifest detects missing, modified and unexpected files, empty directories,
cache artifacts, symlinks, special files and malformed path/JSON entries. It is an
integrity check, not a digital signature: an adversary can replace both a file and
its manifest entry. The builder refuses symlinked path components and uses
exclusive publication. It is not a general hostile-process sandbox or a defense
against an attacker concurrently modifying directory inodes under the build.

## Mathematical and numerical scope

The exact core independently compares a distinguished-vertex graph recursion
with full three-branch factorial sums for 143 `(n,d)` pairs, covering both parities
and the boundary-adjacent values `d=-1,0,1`. It extends the boundary prefix through
`n=15` and validates the literal displayed prefix through `n=10` in the manuscript.
It derives phase coefficients over `Q(a)`, `a^3=1/4`, reproduces the four displayed
count/log/moment corrections, and checks two further orders. Moving-window
rational formulas are checked at eight positive rational points and exactly at
the algebraic boundary. Exterior finite-product and Poisson-moment coefficients
are checked at six positive rational ratios.

These are finite exact checks. They do not prove a rational identity from a
finite sample, prove uniform asymptotic remainders, certify an explicit numerical
starting threshold, or establish prior-art priority. Those analytic arguments
and their limitations are stated in the report. In particular, the compact
moving-window theorem does not claim an overlap theorem for unbounded scaled
imbalance.

`optional/` contains standalone SymPy/mpmath audit programs and recorded output.
They are not needed by the core or builder. Their numerical tail bounds are
analytic estimates evaluated at ordinary arbitrary precision, not outward-rounded
certificates of total numerical error. See `optional/README.md`.

`SOURCE_AUDIT.md` records the scope of source comparison and novelty limitations.
