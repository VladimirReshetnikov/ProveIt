# Exact-fiber hulls for PA-calibrated ZFC-inconsistency search

Research memorandum for Vladimir Reshetnikov — 15 October 2026.

**Read:** `article/exact_fiber_hulls.pdf` (19 pages).  
**Source:** `article/exact_fiber_hulls.tex` (standalone, embedded bibliography).

## Main result

Extensionality plus the exact-fiber hull schema is deductively equivalent
to ZF with Foundation omitted, using ordinary functional Replacement and
without Choice. A definable binary relation is subset-bounded when, for
each input, all its outputs are subsets of some set. The schema gives a
transitive set containing any requested seed and containing, as an element,
the exact output fiber of each of its members.

The paper proves the two directions, reconstructs the linked MathOverflow
closure proposal, and proves a subset-bounded rooted-closure intermediate
result. It gives a direct equality-free interpretation using one
profile-congruence axiom. Uniform proof translations, combined with the
standard effective Foundation/Choice bridge, give PA-provable
equiconsistency with ordinary ZFC at the paper-proof level.

The equality-free extensional control uses **65 expanded template nodes**,
versus **78** for the comparable prior container–collection control. The
nonextensional prior kernel remains smaller at **61** in this metric.
These totals omit the logical engine, encoding, initialization, schema
handling, and TM backend. They are **not machine-state estimates**.

## Status boundaries

Mathematical proofs and executed syntax/finite-semantics experiments are
included. No proof-producing set-theory compiler, serialized PA derivation,
new Turing-machine transition table, or machine-state improvement is
claimed. The external 254-state Coq project is discussed as a reported
source result; it was not rebuilt here. Historical novelty and global
minimality have not been established.

`notes/PA_OBLIGATIONS.md` gives the exact missing formalization interfaces.
`notes/RESEARCH_DELTA.md` distinguishes these contributions from the supplied
archive and records why two apparent simplifications fail.

## Reproduce the experiments

Python 3.10 or later; standard library only. From this directory:

```sh
python code/hull_templates.py
python code/finite_hulls.py
python code/test_templates.py
```

The run checks all **262,404** pairs of a membership relation and a matrix
relation on domains of sizes 1–3. Independent symbolic/bitset checks perform
**5,600** formula comparisons; four test methods pass. These are regression
tests and countermodel diagnostics, not a formal proof of the main theorem.

Outputs are under `results/`. The delivered transcripts are actual runs.
Repeated runs overwrite the corresponding result files.

## Rebuild the PDF

Install `pdflatex` with the packages named at the top of the TeX file,
including AMS mathematics, Latin Modern, microtype, booktabs, tabularx,
enumitem, fancyhdr, xurl, and hyperref. Then run:

```sh
python build.py
```

This runs three LaTeX passes, checks for compilation errors and unresolved
references, and writes `article/exact_fiber_hulls.pdf`. To rerun the
experiments as well:

```sh
python build.py --tests
```

Temporary TeX output goes to `.build/`, which is not part of the delivered
ZIP. The helper does not install software or access the network. Tests can
be run independently without a TeX installation.

## Provenance

The attachment `zfc-consistency.zip` contains three prior reports, all
reviewed through their TeX sources. The `syntax.py` utility is reused
unchanged from report 1. The axiom constructors in `prior_templates.py`
are adapted from report 1 by removing its obsolete standalone driver.
Other Python files are specific to this follow-up.

`provenance/input_manifest.json` records input hashes and reuse.
`provenance/sources.json` records the external sources and verification
limitations. `results/qa.json` records build and rendering checks.
`SHA256SUMS` identifies the delivered files. The original ZIP and the
third-party source repositories are not bundled.
