# Ordinal Heights and Uniquely Restricted Matchings

**NP-completeness, priority layers, and exact certificates**  
Prepared for Vladimir Reshetnikov, 29 September 2026.

## Read the article

`article.pdf` is the compiled manuscript. Its full source is `article.tex`, with
an included bibliography in `references.tex`. `references.bib` contains reusable
BibTeX entries but is not needed to build the document.

The target is the explicit complexity question in Section 37 of ProveIt's
*Cofinal strata and ordinal absorption* report. The inspected source is pinned to
commit `9754e83603e223811b7515eb892f22c847144593`; its article blob is
`c48fb7fea57f8efd4c705d858c33e58bdbd9a867`. See `SOURCES.md`.

## Main results

For a finite nonempty height-at-most-two skeleton Q, incidence graph G, and
uniform fibre alpha = omega^rho, rho > 0, the manuscript proves

    h(K(lexicographic sum over Q of alpha)) = alpha * (nu_ur(G) + 1).

Here K denotes the finitely generated downsets, including the empty downset,
and nu_ur is the maximum uniquely restricted matching number. The proof includes
an explicit increasing ordinal ranking and an attaining chain. Combined with the
published NP-completeness of bipartite uniquely restricted matching, it resolves
the repository's height-computation complexity question already with every fibre
omega.

For nonuniform pure priorities the manuscript proves an exact finite
ordered-matching formula and a residual priority-layer recurrence. The leading
coefficient is the matching number of the highest-priority rows; the lower
coefficients must be optimized across residuals of all maximum high matchings.
Other results include a maximal-frontier closure correspondence, weighted safe
twin compression, structural fixed-parameter algorithms, and Bellman certificates.

## Proof status and novelty

This is an AI-assisted, unrefereed research manuscript, not a Lean or Rocq
formalization. No historic priority claim is made. The unweighted matching and
covering-sequence notions are classical and credited.

The **uniform transfinite height theorem is proved independently** here. The
finite weighted theorems are also proved independently. Their **interpretation
as nonuniform transfinite heights** invokes the repository's stated pure-fibre
height-two scheduling theorem (its Theorem 35.1). That dependency is not hidden
behind the finite tests. See `PROOF_AUDIT.md` for the complete boundary.

## Build

A TeX installation with the usual AMS packages, Latin Modern, microtype,
mathrsfs, TikZ, listings, tabularx, and hyperref is sufficient.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. No bibliography processor, external figures, font downloads, or
network access is required. The Makefile provides `make pdf`, `make verify`, and
`make clean` (clean retains the PDF).

## Exact solver and certificates

Python 3.10 or newer is required; there are no third-party Python dependencies.

```sh
python code/ordinal_matchings.py solve examples/tie_requires_lookahead.json \
  --output certificate.json
python code/ordinal_matchings.py check examples/tie_requires_lookahead.json \
  certificate.json
python code/verify.py
```

The solver returns the exact CNF as decreasing `[exponent, coefficient]` pairs,
a maximizing upper order, its retirement groups, and a full Bellman table.
An empty CNF list is zero. Exponents and terminal priorities must be positive
integers; **zero means an empty group internally, not omega^0**. This is a
pure-positive-priority solver, not an implementation for finite/successor fibres.
The terminal priority remains fixed when residual graphs or twin quotients are
formed. Empty lower/upper lists with a terminal represent a nonempty terminal
antichain, not the empty skeleton.

The checker checks every Bellman inequality and an attaining predecessor for
each subset, rather than merely replaying a good schedule. It does not call the
optimizer, but shares exact arithmetic and input routines. It certifies the
finite optimum, not the transfinite interpretation.

The default guard is 22 upper vertices. The method is exponential in the number
of upper vertices, and the full JSON certificate can be large. The guard is not
a performance guarantee. The API function `compress_twins` applies equality-only
weighted compression; the CLI does not silently transform inputs.

The value-only API `solve_by_covered_rows` uses covered lower-row sets instead
of used upper-column sets. After lower-twin compression, this gives an algorithm
with 2^a states when a is the number of distinct upper-neighbour sets of lower
rows. Its value is checked against the production optimizer.

## Executed validation

The recorded Python 3.13.5 run passes **275,633 assertions**:

- 31,755 exhaustive weighted instances with at most three rows and columns,
  nonzero lower rows, priorities 1–3, and each terminal priority 1–3;
- all 50,625 nonzero-row 4-by-4 incidence matrices at uniform priority;
- 120 seeded weighted cases, including binary priorities as large as 10^12;
- nine documented examples and their full certificates.

Comparisons include all upper permutations, the dual covered-row DP, all admissibly ordered matchings,
the priority-layer recurrence, closure heights, twin invariance, and corruption
rejection. Not every category is run on every family; the exact counts and
coverage are in Section 13 of the article and `data/verification.json`.
The tests are finite implementation checks, not proofs of transfinite statements
or evidence of historical novelty. `verify.py` regenerates its own examples and
ledgers in this directory. `data/quality_assurance.json` records final build and
artifact checks.

## Further research

The article gives nine concrete next directions, including weighted forests,
weighted decomposition-width algorithms, residual-family compression, binary
Cantor coefficients without block expansion, higher skeletons, nonpure WPO
components, short upper certificates, counting/stability, and formal integration.

No files were committed to or changed in the user's GitHub repository.
