# Moving-Gap Permutation Avoidance

**Uniform local expansions, sharp short-path effects, and a hierarchy of finite-size boundaries**

A research manuscript prepared for Vladimir Reshetnikov, dated 4 October 2026.

## Main results

The manuscript continues the ProveIt report on A189281 and A110128, addressing its questions about growing gaps and the first effect of a fixed short path. It does not present the existing fixed-gap expansion or the report's directed integrality theorem as new.

1. A uniform all-orders expansion of the complete violation distribution for **every pair of path forests on n vertices**. The coefficient at order n^(-M) depends only on normalized counts of subpaths with at most M+1 edges. No lower bound on component length or edge density is required.
2. A sharp longest-path sensitivity identity, proving that the locality cutoff is genuinely necessary even among actual forests with identical shorter-subpath counts.
3. An explicit first absolute-model shape correction for one fixed short path of L vertices: the avoidance-probability difference is -2 exp(-2) n^(-L-1) + O(n^(-L-2)). The leading order cancels in the directed model; with one directed target path the whole law is exactly shape-independent.
4. For proportional gaps, a hierarchy of reciprocal-integer correction boundaries and an exact directed cancellation at target ratio sqrt(2)-1. Floor effects and critical windows are retained explicitly.
5. Exact coefficient generation, rational Bonferroni certificates, and all-orders index reconstruction along rational gap rays.

**Status:** AI-assisted, unrefereed, and not Lean/Rocq formalized. The infinite results rest on the written proofs. Finite checks support those proofs but do not replace them. Historical priority is not established by the limited source audit. This is an all-orders algebraic asymptotic sector, not a claim of a complete resurgent transseries. No repository files were changed and no OEIS edit was submitted.

## Files

- `article.tex`, `article.pdf`: complete source and compiled manuscript; the bibliography is internal.
- `SOURCES.md`: inspected revision, external sources, and contribution boundary.
- `code/local_expansions.py`: exact standard-library coefficient engine, independent finite tiling counts, and special-case moment formulas.
- `code/verify.py`: 3,209 exact assertions and coefficient/certificate generation.
- `code/symbolic_checks.py`: optional SymPy verification of the first two general correction polynomials.
- `code/inverse_demo.py`: optional 100-digit mpmath inverse diagnostics from exact integer inputs.
- `data/`: exact coefficients, rational endpoints, outward-rounded decimal intervals, and recorded outputs.
- `Makefile`: build and verification shortcuts.
- `requirements-optional.txt`: exact versions of the two optional packages used in this run.

No external images, bibliography file, downloaded sequence b-file, or bundled font is required.

## Reproduce the checks

Use Python 3.10 or newer. From this directory:

```sh
python code/verify.py
```

This command needs only the Python standard library. It reruns exhaustive permutation checks for n=2,...,7 and every positive offset pair below n, checks finite forest tilings, generates the exact expansion coefficients, and regenerates the rational probability certificates.

Optional symbolic and numerical checks:

```sh
python -m pip install -r requirements-optional.txt
python code/symbolic_checks.py
python code/inverse_demo.py
```

The inverse decimals are **not interval certificates**. The probability enclosures, including the short-path sign checks, use exact rational arithmetic and outward decimal rounding. Abstract rational vectors used in polynomial-identity tests need not be realizable as forest densities; the probability theorems apply to actual forests.

The verification duration is not reproducible across machines, but the exact mathematical output is deterministic. The pseudo-random rational tests use the fixed seed 20261004.

## Build the PDF

A standard TeX installation with pdfLaTeX and latexmk suffices:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex article.tex` repeatedly until references settle. The document uses standard packages including Latin Modern, AMS mathematics, mathrsfs, booktabs, microtype, fancyhdr, hyperref, and cleveref.

`make verify`, `make symbolic`, `make inverse`, `make pdf`, and `make clean` are provided. `make clean` removes intermediate TeX files, not the PDF or recorded data.

## Small API example

```python
from fractions import Fraction
import sys
sys.path.insert(0, "code")
from local_expansions import corrections, eval_poly

# r=s=n/2, so only the one-edge density is nonzero.
a = [Fraction(1, 2)]
B = corrections(a, a, theta=1, M=6)
c = [eval_poly(polynomial, -1) for polynomial in B]
print([str(v) for v in c])
# ['1', '-1/4', '-5/32', '11/128', '1299/2048', '12289/8192', '60271/65536']
```

Each `B[j]` is an increasing-power coefficient list for the polynomial B_j(u). Densities are indexed by **edge length**, so list entry zero means S_1/n. Omitted densities are treated as zero; supply all relevant densities for the intended forest. For actual offset forests, `offset_lengths(n, r)` and `densities(lengths, K)` produce the exact rational inputs.

## Further questions

The article proposes eight concrete directions: the next directed short-path term, cancellation loci and their next layer, a growing locality scale, large-order growth, simultaneous colored gaps and cycles, growing observed counts, explicit certified inversion thresholds, and a small Lean verification target.
