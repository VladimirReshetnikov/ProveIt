# Frozen rank four dependency

The ZIP is a byte-for-byte copy of the previously released `matching-rank-four-package.zip`.

SHA-256: 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66

Theorem 1.1 of its article proves actual-degree ULC for arbitrary nonnegative vertex weights on every bipartite graph of matching number at most four. The new complete-block result applies that theorem to the positive-activity induced graph whenever its surviving degree is less than five. The general order-five proof is supplied in the new paper, not imported from the dependency's earlier constant-block theorem.

The outer verification driver safely extracts the dependency into temporary storage, checks its own manifest, replays all four delivered checkers, and independently regenerates the former rank-five certificate. The archive and all original release files remain unchanged.
