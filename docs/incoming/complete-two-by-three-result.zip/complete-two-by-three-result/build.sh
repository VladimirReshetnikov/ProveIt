#!/bin/sh
set -eu
cd "$(dirname "$0")/article"
pdflatex -interaction=nonstopmode -halt-on-error complete-two-by-three.tex
pdflatex -interaction=nonstopmode -halt-on-error complete-two-by-three.tex
