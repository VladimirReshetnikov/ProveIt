#!/usr/bin/env python3
"""Independent symbolic identities and literal Hall-support checks. No producer imports."""
if not __debug__:
    raise SystemExit('Run without -O: exact checks require assertions.')
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
import argparse, hashlib, json, random, time
import sympy as s

started=time.monotonic()
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-note',type=Path,default=Path('/workspace/shared/full-two-by-three-independent/FULL_COMPLETE_BLOCK_ULC.md'))
parser.add_argument('--degree-drop-source',type=Path,default=Path('/workspace/shared/matching-rank-four-result/matching-rank-four.tex'))
parser.add_argument('--output-dir',type=Path,default=Path(__file__).parent)
args=parser.parse_args()
a,c,t,q,v,w,r,z=s.symbols('a c t q v w r z')
A,B,C,D,E,L,M,N,R,S=s.symbols('A B C D E L M N R S')
blocks=[[1,A,B],[1,L,M,N],[1,C,D,E],[1,R,S]]
g=[0]*6
for ip,ix,iq,iy in product(range(3),range(4),range(4),range(3)):
    k=ip+ix
    if k==iq+iy and ix<=iq and iy<=ip:
        g[k]+=blocks[0][ip]*blocks[1][ix]*blocks[2][iq]*blocks[3][iy]
g=list(map(s.expand,g))
claimed=[1,A*C+A*R+C*L,A*C*L*R+A*D*L+B*C*R+B*D+B*S+D*M,
 A*D*M*R+A*E*M+B*C*L*S+B*D*L*R+B*E*L+E*N,
 A*E*N*R+B*D*M*S+B*E*M*R,B*E*N*S]
assert all(s.expand(x-y)==0 for x,y in zip(g,claimed))
sub={A:a,B:a*a*t/4,C:c,D:c*c*q/3,E:c**3*q*q*r/27,L:1,M:v/2,N:v*v*z/6,R:1,S:w/2}
G=[s.expand(f.subs(sub)) for f in g]
res2=s.Poly(s.expand(1296*(G[2]**2-2*G[1]*G[3].subs({r:1,z:1}))-8*q*q*v*v*c*c*(a-c)**2),a,c)
res3=s.Poly(s.expand(419904*(G[3]**2-2*G[2]*G[4])-324*a*a*c*c*(a*t*w-c*q*q*r*v*v*z)**2),a,c)
want2={(4,4):9*q*q*t*t,(4,3):54*q*t*t,(4,2):27*t*t*(q*w+3),
 (4,1):81*t*t*w,(4,0):s.Rational(81,4)*t*t*w*w,(3,4):48*q*q*t,
 (3,3):24*q*t*(9-q),(3,2):108*t*(3-q)*(2-w),
 (2,4):12*q*q*(3*t*v-2*t-4*v+12),
 (2,3):12*q*(72-4*q*v+9*t*v-18*t-36*v),
 (2,2):1296-432*q*v-324*t*w+54*q*t*v*w-8*q*q*v*v,
 (1,4):16*q*q*v*(6-v),(0,4):12*q*q*v*v}
want3={(4,6):36*q**4*r*r*t*t,(4,5):324*q**3*r*t*t*(2-v),
 (4,4):486*q*q*t*t*(6-2*r*v+2*r*w-3*v*w),
 (4,3):486*q*t*t*w*(18-q*r*v-9*v),(4,2):t*t*w*w*(6237-2187*q*v),
 (3,6):144*q**4*r*r*t*v,(3,5):432*q**3*r*t*v*(3-v*z),
 (3,4):648*q*q*t*v*(18-2*r*v*z+3*r*w-6*r-9*w),
 (2,6):48*q**4*r*r*v*v*(t*z+3),(2,5):216*q**3*r*v*v*(4-t)*(3-2*z),
 (2,4):324*q*q*v*v*(36+2*r*t*w*z-16*r*z-9*t*w-q*q*r*r*v*v*z*z),
 (1,6):96*q**4*r*r*v**3*z,(0,6):16*q**4*r*r*v**4*z*z}
for actual,wanted in [(res2,want2),(res3,want3)]:
    assert set(actual.monoms())==set(wanted)
    for ij,expr in wanted.items(): assert s.expand(actual.coeff_monomial(ij)-expr)==0
# Bound a polynomial on [0,1]^6 by replacing each negative monomial by its coefficient,
# and discarding each positive nonconstant monomial. This is an exact universal bound.
brackets=[(3*t*v-2*t-4*v+12,6),(72-4*q*v+9*t*v-18*t-36*v,14),
 (1296-432*q*v-324*t*w+54*q*t*v*w-8*q*q*v*v,532),
 (6-2*r*v+2*r*w-3*v*w,1),(18-q*r*v-9*v,8),(6237-2187*q*v,4050),
 (18-2*r*v*z+3*r*w-6*r-9*w,1),(36+2*r*t*w*z-16*r*z-9*t*w-q*q*r*r*v*v*z*z,10)]
bounds=[]
for expr,expected in brackets:
    p=s.Poly(expr,t,q,v,w,r,z)
    lower=sum(k for exp,k in p.terms() if not any(exp) or k<0)
    assert lower==expected
    bounds.append(int(lower))
x,y,bb,cc,hh,ss=s.symbols('x y b c h s')
last=4*(x+y+1)**2-10*(x*y+x*ss+cc*hh*y*y+hh*y+hh*ss+bb*ss*x*x)
ratios={x:A*N/(B*M),y:D*S/(E*R),bb:B/A**2,cc:C*E/D**2,hh:L*N/M**2,ss:S/R**2}
assert s.cancel(last.subs(ratios)*B**2*E**2*M**2*R**2-(4*g[4]**2-10*g[3]*g[5]))==0
low=(x-y)**2+s.Rational(7,4)*x*x+s.Rational(7,9)*y*y+3*x+s.Rational(4,3)*y+s.Rational(2,3)
assert s.expand(last.subs({bb:s.Rational(1,4),cc:s.Rational(1,3),hh:s.Rational(2,3),ss:s.Rational(1,2)})-low)==0
# Check the general elementary-symmetric identity by generic variables of sizes 0..7.
for size in range(8):
    zz=s.symbols('x:'+str(size))
    def esp(k):return sum(s.prod(h) for h in combinations(zz,k))
    rhs=2*sum(u*u*vv*vv for u,vv in combinations(zz,2))+sum(u*vv*ww*(u+vv+ww) for u,vv,ww in combinations(zz,3))
    assert s.expand(2*esp(2)**2-3*esp(1)*esp(3)-rhs)==0

def prod(xs):
    out=1
    for xx in xs:out*=xx
    return out
def elementary(xs,top):
    out=[1]+[0]*top
    for xx in xs:
        for j in range(top,0,-1):out[j]+=xx*out[j-1]
    return out
hall_pairs=0
@lru_cache(None)
def supports(nx,ny):
    global hall_pairs
    nl,nr=2+nx,3+ny
    rows=[(1<<nr)-1]*2+[(1<<3)-1]*nx
    result=[[] for _ in range(6)]
    for k in range(min(5,nl,nr)+1):
        for tails in combinations(range(nl),k):
            for heads in combinations(range(nr),k):
                hall_pairs+=1
                mask=sum(1<<j for j in heads)
                feasible=True
                for submask in range(1,1<<k):
                    nb=0
                    for j in range(k):
                        if submask>>j&1:nb|=rows[tails[j]]&mask
                    if nb.bit_count()<submask.bit_count():feasible=False;break
                if feasible:result[k].append((tails,heads))
    return result
degree_counts=Counter(); tested=0; support_evaluations=0; strict_five=0
def check_case(pp,qq,xx,yy):
    global tested,support_evaluations,strict_five
    left=list(pp)+list(xx);right=list(qq)+list(yy)
    actual=[]
    for pairs in supports(len(xx),len(yy)):
        val=0
        for tails,heads in pairs:
            val+=prod(left[j] for j in tails)*prod(right[j] for j in heads)
        actual.append(val);support_evaluations+=len(pairs)
    ep,eq,ex,ey=elementary(pp,2),elementary(qq,3),elementary(xx,3),elementary(yy,2)
    expected=[0]*6
    for ip,ix,iq,iy in product(range(3),range(4),range(4),range(3)):
        k=ip+ix
        if k==iq+iy and ix<=iq and iy<=ip:
            expected[k]+=ep[ip]*ex[ix]*eq[iq]*ey[iy]
    assert actual==expected
    d=max(j for j,value in enumerate(actual) if value)
    degree_counts[d]+=1
    for k in range(1,d):
        gap=k*(d-k)*actual[k]**2-(k+1)*(d-k+1)*actual[k-1]*actual[k+1]
        assert gap>=0
        if d==5:assert gap>0
    if d==5:strict_five+=1
    tested+=1
profiles_x=[(),(1,),(1,2),(1,2,3),(0,1,2,3)]
profiles_y=[(),(1,),(1,2),(0,2,3)]
for core in product(range(3),repeat=5):
    for xx,yy in product(profiles_x,profiles_y):check_case(core[:2],core[2:],xx,yy)
rng=random.Random(261001)
for _ in range(160):
    nx,ny=rng.randrange(3,7),rng.randrange(2,6)
    vals=[F(rng.randrange(1,8),rng.randrange(1,8)) for __ in range(5+nx+ny)]
    if _%3==0:vals[rng.randrange(len(vals))]=F(0)
    check_case(vals[:2],vals[2:5],vals[5:5+nx],vals[5+nx:])
root=args.output_dir
root.mkdir(parents=True,exist_ok=True)
note=args.source_note
dep=args.degree_drop_source
receipt={'verdict':'PASS','source_sha256':hashlib.sha256(note.read_bytes()).hexdigest(),
 'degree_drop_source_sha256':hashlib.sha256(dep.read_bytes()).hexdigest(),
 'symbolic_support_coefficients':6,'independent_middle_residuals':[len(want2),len(want3)],
 'last_gap_identity':True,'unit_cube_exact_lower_bounds':bounds,
 'weighted_cases':tested,'degree_counts':dict(sorted(degree_counts.items())),
 'strict_degree_five_cases':strict_five,'literal_Hall_pairs_checked':hall_pairs,
 'weighted_support_evaluations':support_evaluations,'distinct_population_shapes':supports.cache_info().currsize,
 'elapsed_seconds':round(time.monotonic()-started,3),'supplementary_checks_not_finite_proof':True}
(root/'independent_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
