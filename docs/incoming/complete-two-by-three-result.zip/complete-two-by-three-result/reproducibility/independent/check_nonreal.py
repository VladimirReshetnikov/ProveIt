#!/usr/bin/env python3
"""Reconstruct the exact complete-block nonreal example, not producer code."""
if not __debug__: raise SystemExit('Run without -O.')
import argparse, hashlib, json
from pathlib import Path
import sympy as s
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-note',type=Path,default=Path('/workspace/shared/full-two-by-three-independent/NONREAL_SCOPE_EXAMPLE.md'))
parser.add_argument('--output-dir',type=Path,default=Path(__file__).parent)
args=parser.parse_args()
g=[0]*6
for i in range(3):
 for j in range(11):
  for k in range(4):
   ell=i+j-k
   if 0<=ell<=10 and j<=k and ell<=i:
    g[i+j]+=int(s.binomial(2,i)*s.binomial(10,j)*s.binomial(3,k)*s.binomial(10,ell)*100**(i+k))
x=s.symbols('x'); h=s.Poly(sum(s.Rational(a,100**i)*x**i for i,a in enumerate(g)),x)
disc=int(s.discriminant(h.as_expr(),x))
negative=int(h.count_roots(-s.oo,0));nonnegative=int(h.count_roots(0,s.oo))
assert disc==-251488224963149496162478560000000
assert negative==3 and nonnegative==0
result={'verdict':'PASS','gamma':g,'scaled_gamma_ascending':[int(h.nth(i)) for i in range(6)],
 'scaling':'H(t)=Gamma(t/100)','discriminant':disc,'negative_real_roots':negative,
 'nonnegative_real_roots':nonnegative,'nonreal_roots':2,
 'source_sha256':hashlib.sha256(args.source_note.read_bytes()).hexdigest()}
args.output_dir.mkdir(parents=True,exist_ok=True)
(args.output_dir/'nonreal_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
