#!/usr/bin/env python3
"""Exact symbolic replay of the two small ordinary algebra certificates."""
import sympy as S
from pathlib import Path
import json
A,C,t,q,v,w,r,z=S.symbols('a c t q v w r z')
B=A*A*t/4;D=C*C*q/3;E=C**3*q*q*r/27;M=v/2;N=v*v*z/6;H=w/2
G1=A*C+A+C
G2=A*C+A*D+B*C+B*D+B*H+D*M
G3=A*D*M+A*E*M+B*C*H+B*D+B*E+E*N
G4=A*E*N+B*D*M*H+B*E*M
G5=B*E*N*H
P2={(4,4):9*q*q*t*t,(4,3):54*q*t*t,(4,2):27*t*t*(q*w+3),
 (4,1):81*t*t*w,(4,0):S.Rational(81,4)*t*t*w*w,
 (3,4):48*q*q*t,(3,3):24*q*t*(9-q),(3,2):108*t*(3-q)*(2-w),
 (2,4):12*q*q*(3*t*v-2*t-4*v+12),
 (2,3):12*q*(72-4*q*v+9*t*v-18*t-36*v),
 (2,2):1296-432*q*v-324*t*w+54*q*t*v*w-8*q*q*v*v,
 (1,4):16*q*q*v*(6-v),(0,4):12*q*q*v*v}
P3={(4,6):36*q**4*r*r*t*t,(4,5):324*q**3*r*t*t*(2-v),
 (4,4):486*q*q*t*t*(6-2*r*v+2*r*w-3*v*w),
 (4,3):486*q*t*t*w*(18-q*r*v-9*v),
 (4,2):t*t*w*w*(6237-2187*q*v),
 (3,6):144*q**4*r*r*t*v,(3,5):432*q**3*r*t*v*(3-v*z),
 (3,4):648*q*q*t*v*(18-2*r*v*z+3*r*w-6*r-9*w),
 (2,6):48*q**4*r*r*v*v*(t*z+3),
 (2,5):216*q**3*r*v*v*(4-t)*(3-2*z),
 (2,4):324*q*q*v*v*(36+2*r*t*w*z-16*r*z-9*t*w-q*q*r*r*v*v*z*z),
 (1,6):96*q**4*r*r*v**3*z,(0,6):16*q**4*r*r*v**4*z*z}
T2=sum(f*A**i*C**j for (i,j),f in P2.items())+8*q*q*v*v*C*C*(A-C)**2
T3=sum(f*A**i*C**j for (i,j),f in P3.items())+324*A*A*C*C*(A*t*w-C*q*q*r*v*v*z)**2
assert S.expand(1296*(G2*G2-2*G1*G3.subs({r:1,z:1}))-T2)==0
assert S.expand(419904*(G3*G3-2*G2*G4)-T3)==0
# Support formula is independently reconstructed by all selected block sizes.
basic=S.symbols('A B C D E L M N R S')
aa,bb,cc,dd,ee,ll,mm,nn,rr,ss=basic
p=[1,aa,bb];qq=[1,cc,dd,ee];xx=[1,ll,mm,nn];yy=[1,rr,ss]
g=[S.expand(sum(p[i]*qq[j]*xx[k-i]*yy[k-j]for i in range(3)for j in range(4)if i+j>=k and 0<=k-i<4 and 0<=k-j<3))for k in range(6)]
formula=[1,aa*cc+aa*rr+cc*ll,aa*cc*ll*rr+aa*dd*ll+bb*cc*rr+bb*dd+bb*ss+dd*mm,
 aa*dd*mm*rr+aa*ee*mm+bb*cc*ll*ss+bb*dd*ll*rr+bb*ee*ll+ee*nn,
 aa*ee*nn*rr+bb*dd*mm*ss+bb*ee*mm*rr,bb*ee*nn*ss]
assert all(S.expand(a-b)==0 for a,b in zip(g,formula))
x,y,b,c,h,s=S.symbols('x y b c h s')
last=4*(x+y+1)**2-10*(x*y+x*s+c*h*y*y+h*y+h*s+b*s*x*x)
low=(x-y)**2+S.Rational(7,4)*x*x+S.Rational(7,9)*y*y+3*x+S.Rational(4,3)*y+S.Rational(2,3)
assert S.expand(last.subs({b:S.Rational(1,4),c:S.Rational(1,3),h:S.Rational(2,3),s:S.Rational(1,2)})-low)==0
# Normalized last-gap identity.
den=bb**2*ee**2*mm**2*rr**2
sub={x:aa*nn/(bb*mm),y:dd*ss/(ee*rr),b:bb/aa**2,c:cc*ee/dd**2,h:ll*nn/mm**2,s:ss/rr**2}
assert S.cancel(den*last.subs(sub)-(4*g[4]**2-10*g[3]*g[5]))==0
receipt={'verdict':'PASS','support_formulas':6,'middle2_residual_coefficients':len(P2),'middle3_residual_coefficients':len(P3),'middle2_identity':True,'middle3_identity':True,'last_gap_identity':True,'sympy_version':S.__version__}
Path(__file__).with_name('complete_block_identity_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
