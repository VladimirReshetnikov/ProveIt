#!/usr/bin/env python3
from math import comb
from pathlib import Path
import json,sympy as s
x=s.Symbol('t')
g=[sum(comb(2,i)*comb(3,j)*comb(10,k-i)*comb(10,k-j)*100**(i+j) for i in range(3)for j in range(4)if i+j>=k and 0<=k-i<=10 and 0<=k-j<=10)for k in range(6)]
h=[c//100**k for k,c in enumerate(g)]
assert all(c%100**k==0 for k,c in enumerate(g))
assert h==[1,650,39780,143170,53475,5400]
f=s.Poly(sum(c*x**k for k,c in enumerate(h)),x)
d=s.discriminant(f.as_expr(),x)
assert d==-251488224963149496162478560000000
real=int(f.count_roots(-s.oo,s.oo));negative=int(f.count_roots(-s.oo,0))
assert real==negative==3
receipt={'verdict':'PASS','exterior_populations':[10,10],'core_activity':100,'exterior_activity':1,'gamma':g,'scaled_polynomial':h,'scaling':'H(t)=Gamma(t/100)','discriminant':str(d),'real_roots':real,'negative_real_roots':negative,'nonreal_conjugate_pairs':1,'arithmetic':'exact integers and rational Sturm arithmetic','sympy_version':s.__version__}
Path(__file__).with_name('nonreal_example_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
