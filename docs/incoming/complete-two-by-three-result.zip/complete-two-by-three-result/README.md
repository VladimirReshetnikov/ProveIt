# Independent weights on a complete two plus three matching core

This package proves actual-degree rank ultra log concavity for the bipartite graph with shores P union X and Q union Y, where |P|=2, |Q|=3, and the edges are exactly P×Q, P×Y and X×Q. Every vertex has its own independent nonnegative activity; X and Y are arbitrary finite populations. Each feasible endpoint support is counted once. All four degree-five Newton inequalities are strict.

The result removes the equal-activity restrictions from the earlier complete-block rank-five theorem. It does not cover missing edges in the three complete blocks, arbitrary directed orientations, or general rank-five graphs.

## Proof and files

The new degree-five proof is ordinary: exact support counting, elementary moment bounds, a strict first-gap witness argument, and one-square/thirteen-residual identities for both middle gaps. The last gap has a direct two-variable square lower bound. Activity-induced degree drops use the earlier arbitrary-weight bipartite rank-four theorem.

- `article/complete-two-by-three.pdf` and `.tex`: the standalone proof and editable source
- `proof-notes/`: approved theorem and nonreal example source snapshots
- `reproducibility/producer/`: exact symbolic identity and discriminant checkers
- `reproducibility/independent/`: independently reconstructed identity, Hall-support, and nonreal checkers
- `audits/`: hash-bound independent source and integrated reviews
- `dependency/matching-rank-four-package.zip`: the complete, byte-preserved previously released rank-four package
- `dependency/matching-rank-four.pdf`: a convenient readable copy of its manuscript
- `qa/visual-qa.json`: every-page final PDF inspection record

The historical “pending” lines in approved source snapshots are preserved to retain their reviewed hashes. The later approval receipts state the final review status.

The independent Hall checker covers 5,020 weighted instances, including 258 strict degree-five instances, with 44,676 literal Hall support tests and 678,543 weighted support evaluations. These finite tests corroborate the displayed all-size proof; no theorem is inferred from a random or finite population search.

The example with ten vertices in each exterior block, core activities 100 and exterior activities 1 has a nonreal conjugate pair. The discriminant and Sturm checks are exact. Thus the theorem is not a blanket real-rootedness statement.

## Replay

Python 3.10 or later and SymPy 1.14.0 are required; the package was tested with Python 3.12.14. Run with assertions enabled:

    PYTHONDONTWRITEBYTECODE=1 python3 verify.py

The driver checks every release hash, safely extracts the frozen dependency into a temporary directory, replays all four of its checkers, regenerates its earlier rank-five certificate exactly, and runs temporary copies of all four new checkers. Every deterministic receipt field must match; elapsed timings are excluded. No released receipt or other frozen file is overwritten.

The nested dependency has SHA-256 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66. Its Theorem 1.1 supplies the only lower-degree input; its Section 8 records the now-strengthened constant-block family. Its additional earlier results are included unchanged and do not become assumptions in the new degree-five algebra.

Rebuild the PDF using a normal TeX Live or MiKTeX installation:

    sh build.sh

Use a copy when rebuilding, since PDF metadata and hashes may change. No proof-assistant formalization, literature-wide priority claim, or external publication is asserted. Earlier frozen releases remain unchanged.
