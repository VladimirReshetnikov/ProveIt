# Independent audit: complete two-plus-three support family

Verdict: **APPROVED** on October 1, 2026. The main proof is ordinary algebra and support counting, with the previously approved bipartite matching-rank-at-most-four theorem as the degree-drop dependency. The exact checks below corroborate it; they are not a finite-population substitute for the proof.

## Exact scope

The physical shores are disjoint `P union X` and `Q union Y`, with `|P|=2`, `|Q|=3`, and exactly the edges `P×Q`, `P×Y`, `X×Q`. All blocks may have unequal independent nonnegative vertex activities; X and Y are arbitrary finite sets. The assertion is actual-degree ULC, with all four order-five inequalities strict when the actual degree is five. This does not establish arbitrary missing-block-edge 2+3 covers, arbitrary directed orientations of this graph, or real-rootedness.

## Support formulas

A size-k shore support with i selected P vertices and j selected Q vertices needs k-i selected X vertices and k-j selected Y vertices. Feasibility requires `k-i<=j` and `k-j<=i`, equivalently `i+j>=k`. These conditions suffice: match X into Q and Y into P first; the remaining selected P and Q subsets have equal sizes and lie in the complete core. Thus each chosen endpoint set has a Boolean feasibility indicator, independent of its witness count. Summing products of four block elementary-symmetric functions reconstructs every coefficient in equation (1).

The independent checker reconstructs these block sums separately and compares them with the six displayed formulas. A second implementation enumerates literal shore subsets and checks every Hall subset directly, without using the block-feasibility shortcut; its weighted sums agree.

## Moment inequalities and positive domains

For the two P activities, `A^2-4B=(p1-p2)^2`. For three Q activities, `C^2-3D` is half the sum of squared pairwise differences, and `D^2-3CE` is half the sum of squared pairwise differences of the three pair-products. For arbitrary exterior lists, `2e2<=e1^2`. In `2e2^2-3e1e3`, four-distinct-index monomials cancel; a two-index squared-pair monomial has coefficient two and a three-index monomial with one doubled exponent has coefficient one. This proves the displayed all-size identity and `3e1e3<=2e2^2`.

Actual degree five is equivalent to `B E N S>0`. It implies all required A,B,C,D,E,L,M,N,R,S are positive. Hence every quotient and normalization in the proof is legitimate, even if some individual exterior activities vanish. The six middle ratios are in `(0,1]`; no unjustified independence or simultaneous attainability of ratios is needed, since proving the inequalities on the larger unit cube suffices.

## Four strict order-five inequalities

The required constants are `gamma1^2>(5/2)gamma2`, `gamma2^2>2gamma1 gamma3`, `gamma3^2>2gamma2 gamma4`, and `4gamma4^2>10gamma3 gamma5`.

For the first, the positive-edge compatibility graph has clique number five. The stated nonadjacent-mass merge argument preserves total weight and never decreases the weighted compatibility-edge sum, giving the Motzkin–Straus/Cauchy bound `W<=2 gamma1^2/5`. Each feasible size-two endpoint support is counted by at least one disjoint-edge witness in W. Since all P and Q core activities are positive, a P-by-two-Q support has two positive matching witnesses. Therefore `gamma2<W`, which proves strictness without confusing the support enumerator with a witness enumerator.

For the last, independent expansion verifies equation (3), including each of its six bracket terms. Its coefficient of every ratio b,c,h,s is nonpositive when x,y and the other ratios are nonnegative. Replacing these four ratios by their upper bounds is therefore a valid lower bound. The resulting expression is exactly equation (4), whose positive constant `2/3` makes the gap strictly positive.

For the first middle gap, g1 and g2 do not use e or n, whereas every occurrence of e and n in g3 has a nonnegative coefficient. Replacing r,z by one raises g3 and lowers the gap. Independent coefficient extraction in a,c confirms the single displayed square and all thirteen P residual expressions. The three nontrivial exact unit-cube lower bounds are 6,14,532; they follow by dropping positive nonconstant monomials and bounding each negative monomial by its coefficient. All other factorizations are nonnegative. The positive `(4,4)` residual yields strictness.

For the second middle gap, no ratio is replaced. Independent symbolic expansion verifies the displayed square and all thirteen Q residual expressions. The five nontrivial unit-cube lower bounds are exactly 1,8,4050,1,10 by the same elementary argument. The `(4,6)` coefficient is strictly positive in the degree-five domain. No sign assumptions on a-c or the other squared binomial are needed.

## Zero activities and actual degree

When degree drops below five, delete every zero-activity vertex. This preserves all support coefficients, and the remaining positive-weight bipartite graph has matching number exactly the actual support degree d. The approved theorem in `matching-rank-four-result/matching-rank-four.tex`, Theorem 1.1, applies to every bipartite graph of matching number at most four with arbitrary nonnegative two-shore vertex activities. It therefore applies directly to this active graph. There is no division by a vanished moment, no cancellation of a homogenizing variable, and no attempt to infer stronger lower-degree normalization from order-five inequalities. Degrees zero and one are vacuous; positive submatchings prevent internal zeros.

## Independent exact replay

`independent_check.py` imports no producer code. It reconstructs the support sums, residual identities and ratio bounds symbolically, then enumerates physical shore supports with Hall's condition. The current receipt records 5,020 integer/rational weighted cases, all actual degrees zero through five, 44,676 literal Hall pairs across 32 population shapes, and 678,543 weighted support evaluations. All 258 degree-five cases have four strict gaps. These are supplementary consistency checks; the proof covers arbitrary populations by its formulas and inequalities.

Run with Python 3 and SymPy, without `-O`. For portable use, supply `--source-note`, `--degree-drop-source` and `--output-dir` paths. The receipt pins the exact source and degree-drop theorem. No frozen prior package was modified, no proof-assistant formalization is claimed, and no priority claim is made.

## Separately approved nonreal example

`NONREAL_SCOPE_EXAMPLE.md` is also independently approved. With ten vertices in each exterior block, core activities 100 and exterior activities one, direct block-selection reconstruction gives the displayed Gamma. For `H(t)=Gamma(t/100)`, the exact discriminant is `-251488224963149496162478560000000`. Independent exact Sturm counts give three negative real roots and zero nonnegative real roots. The other two roots are a nonreal conjugate pair. This is a boundary to real-rootedness, not to the proved strict ULC result. `check_nonreal.py` and `nonreal_receipt.json` provide the separate replay. No minimality claim is made.
