#!/usr/bin/env python3
"""Read-only exact replay, including the complete frozen rank-four dependency."""
if not __debug__:raise SystemExit('Run without -O; assertions are required.')
from pathlib import Path,PurePosixPath
import hashlib,json,os,shutil,stat,subprocess,sys,tempfile,time,zipfile
ROOT=Path(__file__).resolve().parent
DEP_SHA='9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(v):
 if isinstance(v,dict):return{k:canonical(x)for k,x in v.items()if k not in {'seconds','elapsed_seconds'}}
 if isinstance(v,list):return[canonical(x)for x in v]
 return v
def manifest(root):
 records={}
 for line in (root/'SHA256SUMS').read_text().splitlines():
  sha,name=line.split('  ',1);name=name.removeprefix('./')
  assert name not in records;assert digest(root/name)==sha,name;records[name]=sha
 return records
def run(path,cwd,args=()):
 p=subprocess.run([sys.executable,str(path),*map(str,args)],cwd=cwd,text=True,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 if p.returncode:
  print(p.stdout);print(p.stderr,file=sys.stderr);raise AssertionError(f'Failed checker {path.name}')
 return json.loads(p.stdout)
def equal(actual,expected,name):
 assert canonical(actual)==canonical(expected),f'Receipt differs: {name}'
 print(f'PASS: {name}; every deterministic receipt field matches',flush=True)
def main():
 start=time.monotonic();outer=manifest(ROOT)
 print(f'PASS: {len(outer)} release hashes',flush=True)
 dep=ROOT/'dependency/matching-rank-four-package.zip';assert digest(dep)==DEP_SHA
 results=[]
 with tempfile.TemporaryDirectory(prefix='complete-two-by-three-replay-')as temp:
  base=Path(temp);nested=base/'rank-four';nested.mkdir()
  with zipfile.ZipFile(dep)as archive:
   names=archive.namelist();assert len(names)==len(set(names));assert archive.testzip()is None
   for info in archive.infolist():
    p=PurePosixPath(info.filename)
    assert not p.is_absolute() and '..'not in p.parts
    assert not stat.S_ISLNK(info.external_attr>>16)
   archive.extractall(nested)
  before=manifest(nested)
  for script,receipt in [('check_weighted_rank_four.py','verification.json'),('check_rank_three_minimum.py','rank-three-minimum-verification.json'),('check_rank_three_bijections.py','rank-three-bijections-verification.json'),('check_rank_five_certificate.py','rank-five-verification.json')]:
   actual=run(nested/script,nested);equal(actual,json.loads((nested/receipt).read_text()),'dependency/'+script);results.append(script)
  generated=base/'regenerated-rank-five.json'
  actual=run(nested/'generate_rank_five_certificate.py',nested,['--output',generated])
  equal(actual,json.loads((nested/'rank-five-generation.json').read_text()),'dependency/certificate-generation')
  assert generated.read_bytes()==(nested/'rank-five-certificate.json').read_bytes()
  assert manifest(nested)==before
  results.append('dependency-certificate-regeneration')
  for script,receipt in [('verify_complete_block_identities.py','complete_block_identity_receipt.json'),('check_nonreal_example.py','nonreal_example_receipt.json')]:
   target=base/script.removesuffix('.py');target.mkdir();source=ROOT/'reproducibility/producer'/script
   copied=target/script;shutil.copyfile(source,copied);actual=run(copied,target)
   equal(actual,json.loads(source.with_name(receipt).read_text()),'producer/'+script);results.append(script)
  for script,receipt,note,extra in [('independent_check.py','independent_receipt.json','FULL_COMPLETE_BLOCK_ULC.md',['--degree-drop-source',nested/'matching-rank-four.tex']),('check_nonreal.py','nonreal_receipt.json','NONREAL_SCOPE_EXAMPLE.md',[])]:
   target=base/('independent-'+script.removesuffix('.py'));target.mkdir();source=ROOT/'reproducibility/independent'/script
   copied=target/script;shutil.copyfile(source,copied)
   args=['--source-note',ROOT/'proof-notes'/note,'--output-dir',target,*extra]
   actual=run(copied,target,args);equal(actual,json.loads(source.with_name(receipt).read_text()),'independent/'+script);results.append(script)
 assert manifest(ROOT)==outer
 print(json.dumps({'verdict':'PASS','manifest_files':len(outer),'checks':results,'elapsed_seconds':round(time.monotonic()-start,3)},indent=2))
if __name__=='__main__':main()
