# A non-real-rooted member of the complete-block family

Status: exact example prepared for independent review; separate from the pending ULC proof.

Take |P|=2, |Q|=3, |X|=|Y|=10, with complete edge blocks P x Q, P x Y, X x Q. Give every core vertex activity 100 and every exterior vertex activity 1. The support formula gives

 Gamma(t)=1+65000t+397800000t^2+143170000000t^3
          +5347500000000t^4+54000000000000t^5.

The positive variable scaling H(t)=Gamma(t/100) gives the smaller integer polynomial

 H(t)=1+650t+39780t^2+143170t^3+53475t^4+5400t^5.

Its exact discriminant is

    -251488224963149496162478560000000 < 0.

For a real quintic with nonzero discriminant, the sign is (-1)^p, where p is its number of nonreal conjugate pairs. A quintic has at most two such pairs. Thus a negative discriminant forces exactly one conjugate pair and three distinct real roots. Positive coefficients exclude nonnegative real roots, so its three real roots are negative.

This confirms that the complete-block ULC theorem cannot generally be strengthened to real-rootedness, even with activities constant within each block. It is not a ULC counterexample.

The small exact producer calculation used SymPy 1.14.0: the discriminant and exact Sturm count both agree, and count_roots(-oo,0)=count_roots(-oo,oo)=3. The independent reviewer should reconstruct the support coefficients and discriminant rather than accepting these numerical statements as evidence.
