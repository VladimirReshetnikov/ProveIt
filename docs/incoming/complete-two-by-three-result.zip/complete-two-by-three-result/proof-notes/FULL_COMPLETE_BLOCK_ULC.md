# Independent weights on the complete two-plus-three three-block family

Status: proposed ordinary theorem, independent review pending. October 1, 2026. No frozen package is modified.

## Theorem and scope

Let a bipartite graph have disjoint shores P union X and Q union Y, with |P|=2 and |Q|=3. Its edges are exactly

    P x Q, P x Y, X x Q.

The exterior populations X and Y are arbitrary finite sets. Give EVERY vertex an independent nonnegative activity. Count each feasible pair of equally sized shore subsets once, weighting it by the product of its selected vertex activities. Its support polynomial is ULC at its actual surviving degree. If that degree is five, all four Newton inequalities are strict.

The result allows unequal activities within each of the four blocks. It strengthens the previously approved four-constant-block rank-five family. It does not allow missing edges inside the three displayed complete blocks, and it is not a theorem about arbitrary 2+3 role covers or arbitrary orientations of this physical graph.

## Exact support coefficients

Use elementary symmetric sums within the four blocks:

    P: A=e_1(P), B=e_2(P);
    Q: C=e_1(Q), D=e_2(Q), E=e_3(Q);
    X: L=e_1(X), M=e_2(X), N=e_3(X);
    Y: R=e_1(Y), S=e_2(Y).

A support of size k selecting i vertices of P and j of Q is feasible exactly when i+j>=k. Necessity follows by matching its exterior vertices to the opposite core. For sufficiency, first match exterior vertices to the selected opposite core and then match the equal-sized remaining core subsets using P x Q. Consequently the sum of products of the four elementary sums, over these block selection sizes, gives

 gamma_0=1,
 gamma_1=AC+AR+CL,
 gamma_2=ACLR+ADL+BCR+BD+BS+DM,
 gamma_3=ADMR+AEM+BCLS+BDLR+BEL+EN,
 gamma_4=AENR+BDMS+BEMR,
 gamma_5=BENS.                                                   (1)

Each endpoint pair is counted once. No matching-witness multiplicity enters (1).

The physical vertex cover P union Q has size five. If the actual degree drops below five, the previously approved arbitrary-vertex-weight bipartite matching-rank-at-most-four theorem applies directly to the active graph. Thus only actual degree five remains. In this case B,E,N,S>0, so all divisions below have positive denominators.

## Elementary moment bounds

The following bounds hold:

    B/A^2 <= 1/4,     D/C^2 <= 1/3,     CE/D^2 <= 1/3,
    M/L^2 <= 1/2,     LN/M^2 <= 2/3,    S/R^2 <= 1/2.              (2)

For P, A^2-4B is the squared difference of its two activities. For Q, C^2-3D is half the sum of squared pairwise activity differences, and D^2-3CE is half the sum of squared pairwise differences between its three pair-products. The two exterior second-moment bounds follow by dropping the sum of squares in e_1^2=2e_2+sum x_i^2. Finally, for any finite nonnegative list x,

 2e_2(x)^2-3e_1(x)e_3(x)
 =2 sum_(i<j) x_i^2 x_j^2
   +sum_(i<j<k) x_i x_j x_k(x_i+x_j+x_k) >=0.

This proves the remaining bound in (2) without a population assumption.

## The first and last Newton inequalities

The universal first-gap inequality at actual matching degree five is

    gamma_1^2 >= (5/2) gamma_2.

For completeness, form the graph whose vertices are positive-weight edges and whose adjacency means disjointness. It has clique number five. Giving an edge its product endpoint weight, successive mass merges between nonadjacent vertices never decrease the weighted edge sum; they terminate on a clique of size at most five. Cauchy gives weighted edge sum at most (2/5)gamma_1^2. Every size-two endpoint support has at least one matching witness represented in this sum. Here the P x Q block contains a positive K_(2,2), so at least one support has two positive witnesses. Hence gamma_2 is strictly less than that edge sum. Therefore the first order-five inequality is strict.

For the last one, put

    x=AN/(BM), y=DS/(ER),
    b=B/A^2, c=CE/D^2, h=LN/M^2, s=S/R^2.

Direct substitution of (1) gives

 [4 gamma_4^2-10 gamma_3 gamma_5]/(B^2 E^2 M^2 R^2)
 =4(x+y+1)^2-10[xy+xs+ch y^2+hy+hs+bs x^2].                    (3)

Every ratio in the bracket is nonnegative. Replacing b,c,h,s by their upper bounds 1/4,1/3,2/3,1/2 gives the lower bound

    (x-y)^2 + (7/4)x^2 + (7/9)y^2 + 3x + (4/3)y + 2/3 > 0.      (4)

Thus the last Newton inequality is strict for all independent activities at degree five.

## Normalization for the two middle inequalities

Divide every left-shore activity by L and every right-shore activity by R. Then g_k=gamma_k/(LR)^k, so all Newton signs are unchanged. Write

    a=A/L, b=B/L^2, c=C/R, d=D/R^2, e=E/R^3,
    m=M/L^2, n=N/L^3, s=S/R^2.

Formula (1) becomes

 g_1=ac+a+c,
 g_2=ac+ad+bc+bd+bs+dm,
 g_3=adm+aem+bcs+bd+be+en,
 g_4=aen+bdms+bem,
 g_5=bens.                                                     (5)

Introduce six moment ratios in (0,1]:

 t=4b/a^2, q=3d/c^2, v=2m, w=2s,
 r=3ce/d^2, z=3n/(2m^2).

Thus

 b=a^2 t/4, d=c^2 q/3, e=c^3 q^2 r/27,
 m=v/2, s=w/2, n=v^2 z/6.                                     (6)

The bounds follow exactly from (2). The letter t in (6) is a moment ratio, not the support-polynomial indeterminate.

### First middle inequality

The desired order-five condition is g_2^2>=2g_1g_3. In (5), g_1 and g_2 are independent of e,n, while g_3 is nondecreasing in both. Let bar(g_3) be obtained by replacing r=z=1 in (6). Then g_3<=bar(g_3).

Here is an exact identity with just one square and thirteen residual terms:

 1296 [g_2^2-2g_1 bar(g_3)]
   =8q^2 v^2 c^2(a-c)^2 + sum_(i,j) P_ij a^i c^j.              (7)

The nonzero P_ij are:

 (4,4): 9q^2 t^2
 (4,3): 54q t^2
 (4,2): 27t^2(qw+3)
 (4,1): 81t^2 w
 (4,0): (81/4)t^2 w^2
 (3,4): 48q^2 t
 (3,3): 24qt(9-q)
 (3,2): 108t(3-q)(2-w)
 (2,4): 12q^2(3tv-2t-4v+12)
 (2,3): 12q(72-4qv+9tv-18t-36v)
 (2,2): 1296-432qv-324tw+54qtvw-8q^2v^2
 (1,4): 16q^2v(6-v)
 (0,4): 12q^2v^2.

All are nonnegative on the unit cube. For the three less immediate lines, their bracket or full expression is bounded below, respectively, by 6, 14, and 532, simply by dropping positive terms and bounding each negative product by one. Every other line is displayed as a product of nonnegative factors. Since a,c,q,t>0, the (4,4) term is strictly positive. This proves the strict first middle inequality.

### Second middle inequality

The remaining condition is g_3^2>=2g_2g_4. Substitute all six ratios (6), without changing r or z. The exact identity is

 419904 [g_3^2-2g_2g_4]
  =324a^2 c^2(a t w-c q^2 r v^2 z)^2
    +sum_(i,j) Q_ij a^i c^j.                                 (8)

The thirteen nonzero residual coefficients are:

 (4,6): 36q^4 r^2 t^2
 (4,5): 324q^3 r t^2(2-v)
 (4,4): 486q^2 t^2(6-2rv+2rw-3vw)
 (4,3): 486q t^2 w(18-qrv-9v)
 (4,2): t^2 w^2(6237-2187qv)
 (3,6): 144q^4 r^2 t v
 (3,5): 432q^3 r t v(3-vz)
 (3,4): 648q^2 t v(18-2rvz+3rw-6r-9w)
 (2,6): 48q^4 r^2 v^2(tz+3)
 (2,5): 216q^3 r v^2(4-t)(3-2z)
 (2,4): 324q^2 v^2(36+2rtwz-16rz-9tw-q^2r^2v^2z^2)
 (1,6): 96q^4 r^2 v^3 z
 (0,6): 16q^4 r^2 v^4 z^2.

Again all are nonnegative. The bracket/full-expression bounds for the five nontrivial lines (4,4),(4,3),(4,2),(3,4),(2,4) are respectively 1,8,4050,1,10. These follow directly from 0<=t,q,v,w,r,z<=1. All other factors are visibly nonnegative. The (4,6) term is strictly positive since a,c,q,r,t>0. This proves the strict second middle inequality.

Together (3)--(8) and the first-gap argument prove all four strict order-five inequalities. The positive matching gives positive submatching supports of every size. Lower surviving degrees are settled by the already approved bipartite rank-four theorem, completing the actual-degree assertion including zero weights.

## Exact algebra replay and dependency

The small producer checker `verify_complete_block_identities.py` independently reconstructs (1) by feasible block selection sizes, checks (3),(4), and verifies (7),(8) by exact symbolic expansion. Its receipt is `complete_block_identity_receipt.json`. The displayed identities and elementary nonnegative-factor arguments constitute an ordinary proof; there is no population cutoff, coefficient search assumption, or randomized proof input.

The degree-drop dependency is the approved theorem in `/workspace/shared/matching-rank-four-result/matching-rank-four.tex`, with its previously frozen package. No part of that release is changed. This note and its new exact checker are pending independent review.
