# Beyond Nine Bits
## Exact Alphabet-Size Criteria and the Shannon Boundary for Product Entropy

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 29 September 2026.

The main deliverable is `article.pdf` (24 A4 pages). Its editable source is
`article.tex`. The bibliography is embedded in the TeX source; the two figures
are included in `figures/`.

## Research target

This extends the categorical-simplex part of question Q7 in Section 23 of the
ProveIt report *Nine Bits, Ten Bits*, incorporated as Part II of the report at:

`SetTheory/Cardinals/docs/reports/log-concavity-and-unimodality/bernoulli-entropy-quasiconcavity/`

Repository snapshot: `1085b506d65e207a05b7e9c861bb1fe88432fe38`.
The prior report gives a block-product curvature criterion but explicitly does
not evaluate its supremum for arbitrary categorical simplices. The present
article evaluates that supremum and supplies the resulting exact criteria.

## Principal results

- Theorem 3.1: the global maximum of `S_(1-alpha) S_(1+alpha)` on a finite
  probability simplex has one large coordinate and all other coordinates equal;
  its scalar optimizer is unique.
- Theorem 4.3: exact mixed-alphabet Tsallis concavity below order one, with
  strong-concavity and equality geometry in Corollary 4.4.
- Theorem 5.1 and Proposition 5.2: the sharp seventeen/eighteen-symbol transition
  for three factors at order one half, with a sum-of-squares positivity identity
  and rational marginal endpoints giving a certified finite Jensen violation.
- Theorem 6.1: an exact real-algebraic decision procedure at rational orders.
  Only the half-order certificate branch is implemented in the supplied code.
- Theorems 7.1 and 7.2: convergent fixed-order large-alphabet expansions and the
  sharp alphabet-independent range `n q <= 1`.
- Theorem 8.1: a uniform Shannon-window expansion at
  `q = 1 - lambda / log(k-1)^2`, including the first correction; Corollary 8.2
  gives the local lower boundary through fourth inverse-logarithmic order.
- Theorem 9.2: an exact compression-matrix criterion above order one for unequal
  alphabets; Proposition 9.3 treats the remaining orders.
- Theorem 10.1: the same classifications for affine density-matrix parameters
  of quantum product states.

There are nine further research questions and a staged Lean formalization plan.

## Scope

The entropy is that of the independent **joint vector**. Concavity is in the
marginal probability vectors, not arbitrary affine mixing of joint laws, and
not the entropy of their ordinary sum. The quantum statement concerns a
Cartesian product of marginal density-matrix domains, not an entanglement
threshold. Local Shannon-window uniqueness is not global profile unimodality.

The manuscript contains conventional mathematical proofs. It is unrefereed,
not Lean-verified, and does not establish global bibliographic priority.
See `CLAIM_LEDGER.md` and `SOURCES.md` for detailed boundaries and provenance.

## Reproduce the checks

The exact certificate script needs Python 3.10 or later and only the standard
library. The tested environment used Python 3.13.5.

```sh
python code/verify_exact.py
```

For the other checks and figures, install the tested dependencies in a virtual
environment:

```sh
python -m pip install -r requirements.txt
python code/verify_symbolic.py
python code/verify_numerical.py
python code/make_figures.py
```

Completed results:

- 70 exact integer/rational assertions, including fourteen half-order table
  entries and the finite midpoint gap.
- Seven symbolic identities.
- 4,595 numerical assertions, including 2,880 random extremal comparisons and
  twelve spectral finite-difference checks.

The exact midpoint certificate proves

`88119833628 / 10^18 < Delta < 88119833629 / 10^18`

at marginal displacement `h = 1/1000`. The sign of this gap uses no
floating-point computation. The analytic theorems are proved in the article;
finite tests do not replace those proofs.

## Compile the article

With a TeX installation providing `newtx`, `amsmath`, `amsthm`, `mathtools`,
`microtype`, `geometry`, `enumitem`, `booktabs`, `fancyhdr`, `xurl`, `hyperref`,
and `cleveref`:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex` three times. A `Makefile` is included.
The final build has no undefined references or overfull boxes. Every page was
rendered and inspected; theorem-heavy and figure pages were also checked at
larger size. This is a layout check, not an independent mathematical referee
review.

## Files

`verification/` includes exact root intervals, the finite certificate, symbolic
results, numerical diagnostics, build log, and the verification environment.
`data/` contains the profile data used by the first figure. `SHA256SUMS` records
hashes of the delivered files, excluding the hash file itself.

No repository files were modified and no new Lean proof is claimed.
