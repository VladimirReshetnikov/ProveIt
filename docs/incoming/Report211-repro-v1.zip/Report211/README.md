# Report211 Harmonic Lambert decoration and OEIS A330498

This local package contains the detailed PDF and editable TeX source, exact
checks, two symbolic coefficient implementations, and portable numerical
diagnostics for the four displayed correction polynomials P0 through P3.

## Mathematical result

The report proves the log(2) leading constant labelled conjectural in the
inspected OEIS A330498 record and an all-fixed-order oscillatory expansion
beginning at relative order n^(-1/4), with half-power increments. It gives a
fixed analytic decoration theorem, signed error subsequences, eventual
positivity/increase/log-convexity, and shrinking two-ceiling inverse envelopes.

All asymptotic constants and starting indices are existential. Neither the
finite tables nor their precision checks are certified interval bounds or
proofs of a numerical onset. There is no globally first-proof, growing-order,
optimal-truncation, global-transseries, or single-ceiling-at-jumps claim.

## Reproduce

Required: Python 3.10 or later, SymPy 1.14.0, mpmath 1.3.0, and pdfLaTeX with
standard AMS, Latin Modern, geometry, microtype, hyperref and enumitem packages.
The authored checks used Python 3.12.14 and TeX Live 2025/dev/Debian. Python
requirements are listed in repro/requirements.txt. No program installs
software or accesses the network.

Run from the unpacked package directory:

    python verify_package.py
    python -O verify_package.py

Both use explicit checks, not assertions. Each verifies the actual inventory
and manifest, replays all saved exact/symbolic/numerical outputs, checks the
actual numeric TeX table fields, and rebuilds the PDF in private temporary
storage. In this build environment the PDF must match byte for byte. A TeX
version or font change can legitimately change PDF bytes; mathematical outputs
must still match. The scripts never overwrite a requested build output.

Individual commands:

    python repro/verify_exact.py
    python repro/verify_coefficients.py
    python repro/derive_coefficients.py --order 4
    python repro/diagnostics.py
    python repro/build_tables.py --check
    python build_pdf.py --output /a/new/path/Report211.pdf

The exact checker compares every official b-file entry n=0..400 and a separate
rational nested-logarithm expansion through degree 24. The diagnostics use a
second exact weighted-Stirling recurrence through 2000. Every coefficient,
scaled-error and inverse-offset scalar is recomputed at 80 digits/40 modes and
100 digits/60 modes, with an explicit 1e-68 agreement guard. The inverse solver
also checks its log-level residual below 1e-65. These are stability diagnostics,
not interval arithmetic. No NumPy or machine long-double precision is required.

## Archive identity

MANIFEST.json pins every other package file. The separate release receipt pins
the whole ZIP and every actual member, including the manifest. Given the ZIP
and its sibling receipt, run:

    python verify_zip.py Report211-repro-v1.zip Report211-repro-v1.receipt.json
    python -O verify_zip.py Report211-repro-v1.zip Report211-repro-v1.receipt.json

Use the matching version names if a later immutable release is supplied. The
receipt is deliberately outside the ZIP, avoiding a self-referential hash. The
verifier reads the archive without extracting it and rejects unsafe names,
duplicate entries, unexpected members, symlinks, and byte mismatches. A hash
receipt is an integrity aid, not a digital signature or an independent proof.

## Sources and redistribution scope

The exact 401-term fixture repro/b330498.txt is from Vaclav Kotesovec's official
OEIS b-file, https://oeis.org/A330498/b330498.txt, retrieved 4 October 2026.
Attribution and applicable OEIS terms: https://oeis.org/LICENSE. Its bytes are
preserved and pinned by the manifest. No OEIS article full text or third-party
paper full text is redistributed. See the report's bibliography and source
section for primary mathematical inputs and access limitations.

The source comparison is bounded. The inspected saved A330498 export is
revision 13 of 17 December 2019; a report-writing re-open of the live entry
failed, so no claim is made about a freshly observed newer revision. The
original Hejhal full text was not accessible; the used compact-support theorem
was inspected in Egger--Steiner, Theorem 1.1. Classical Voronoi, Hankel and
renewal ideas are credited. Report185 treats a distinct nonharmonic kernel.

All files here are authored report/reproduction material except the attributed
numerical fixture. Private review notes and third-party full texts are excluded.
