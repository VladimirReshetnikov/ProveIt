# Proportional depth asymptotics of iterated Bell numbers

The standalone mathematical addendum is `proportional-depth.pdf`; its editable source is `proportional-depth.tex`. The result is conditional on the explicitly stated fixed-contour foundation, included unchanged in `dependencies/foundation/`. Prellberg's 2002 bivariate leading formula and parabolic-coordinate method are credited explicitly. No novelty claim is made for them or for earlier formal corrections.

## Contents

- Compact-uniform all-finite-order transfer for positive slopes and bounded shifts
- Analytic/combinatorial strict positivity of the amplitude at every positive parameter
- Exact coefficient generator, first correction, floor phase, and smooth inverse recursion
- Discrete threshold limitations and scoped literature comparison
- Corrected foundation PDF/TeX, original certificate and reviews, and exact replay scripts
- Frozen independent proportional audit, source notes, verified Prellberg primary-source links, and bounded OEIS search evidence

The failed Nagaev–Vakhtel downloads are deliberately omitted. That reference is cited through its official MathNet record and DOI; the research comparison identifies the primary theorem range.

## Build the PDF

Install a standard TeX distribution with pdfLaTeX, Latin Modern, microtype, amsmath, amsthm, mathtools, enumitem, fancyhdr, geometry and hyperref. From this directory:

    bash build.sh

The script uses a writable local format/font-map fallback if necessary. It sets SOURCE_DATE_EPOCH and UTC for reproducibility. Build scratch files are written to `.build/`.

## Exact checks

With Python 3 and SymPy installed:

    python3 verification/replay.py

This regenerates order-three orbit polynomials using the unchanged foundation generator, compares the exact JSON with the saved output, generates the general-beta polynomials and checks that output, and runs the independent low-order checks. Work occurs in a temporary directory. The replay does not overwrite saved results or frozen source/audit files.

The unchanged general-beta producer expects `orbit-coefficients.json` beside it; use the replay entry point, which arranges that input automatically. `check_coefficients_portable.py` differs from the independently audited original only in its documented argument parsing/input/output paths. The original remains verbatim in the audit folder.

For optional exploratory numerical checks, also install NumPy, SciPy, and mpmath:

    python3 verification/replay.py --diagnostics

These diagnostics use exact integer recurrence values and non-interval contour quadrature. They include odd-index floor-phase cases. They do not establish amplitude positivity, error bounds, or threshold certificates. The saved output is `results/diagnostics.json`.

## Foundation certificate

The original outward-rounded amplitude seed, its exact runtime assumptions, and replay instructions are preserved in `dependencies/foundation/README.md`, `VERIFICATION.md`, and `review/interval-certificate.md`. Only its positive seed is used by the all-parameter positivity proof. The present package's default exact replay does not rerun that interval certificate.

## Verification scope

All fixed-contour mathematical inputs are restated with provenance. The accompanying mathematical reviews are not proof-assistant verification. Finite symbolic checks supplement the analytic all-orders proof. No endpoint slope uniformity, certified amplitude values away from beta=1, target-specific numerical remainder constants, canonical fractional-depth interpolation, or unique integer rounding rule is asserted.

The package manifest identifies file roles and SHA256 hashes. `QA.md` records final compilation, all-page visual inspection, and exact replay checks.
