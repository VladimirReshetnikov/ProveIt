# Below 246 states: research contribution — 18 October 2026

**The requested complete machine with fewer than 246 states was not obtained.**
This archive contains proved partial reductions, an exact obstruction to a
common branch-recovery design, an alternate **246-state** implementation,
and reproducible research artifacts. Neither the 245-state nor the 244-state
experimental table is a claimed ZFC-consistency machine.

Read `report.pdf` for the complete mathematical account; `report.tex` is its
editable source. The exact supplied Context246 research package remains
unchanged in `baseline/context246/`, including its original notices and
checksum manifest.

## What is established

| Contribution | Exact status |
| --- | --- |
| Supplied 246-state baseline | Its full nine-stage suite, exact blank bootstrap, and source identities were freshly checked. This is inherited work. |
| Partial 245-state runtime | Deleting state 255 and replacing `75/0` by `0L112` preserves positive and zero decrement universally. Increment fails on an explicit smallest local input. |
| Partial 244-state forward carry | Two row changes remove states 112 and 131. Increment, positive decrement, and a shifted zero-preserving operation have universal tape proofs. |
| Branch-information collision | Selected zero with suffix `S` and selected one with suffix `S+[1]` reach an identical full configuration. A common deterministic return rule cannot recover which branch was taken. This also holds when all spares are one. |
| Alternate 246-state detector | All 8,391 universal instruction cases and 42 induction-support rows pass; blank initialization reaches the same safe root after 409,449 steps. This saves no states. |
| Synthesis and search | Exact recipe families, fixtures, budgets, failures, and solver answers are recorded. None is a general state-count lower bound. |

The collision conclusion is deliberately qualified: a common future run
could visit different frames at different times, so the collision alone
does not disprove every existential many-step simulation. The report states
the precise common-return-event theorem and its limits.

## Reproduce the established results

Python 3 and its standard library suffice:

```sh
python3 verify.py --full
```

The wrapper checks `SHA256SUMS`, makes a temporary copy of the baseline and
experiments, and replays the full baseline suite, both partial macro proofs,
exact counterexamples, universal detector-entry partition, both SAT-model
replays, alternate-table support, all 8,391 alternate instruction contracts,
and the complete alternate blank prefix. It does not change this archive.

Without `--full`, the wrapper omits the long baseline regression suite while
still proving its macro dependencies and replaying the new results. Optional
`--output /path/to/run.json` saves a run summary. The supplied fresh complete
replay is in `results/final-verification.json`.

The research searches are separate. They need a C++17 compiler for the
large literal families and optional `z3-solver==5.3.1.0` for synthesis. See
the experiment READMEs for exact commands and scopes. Solver timeouts may
differ by machine; the reported unknown results are not impossibility claims.

```sh
export ZFC246_BASE="$PWD/baseline/context246"
python3 experiments/runtime/runtime_searches.py --family all
python3 experiments/runtime/run_single_entry.py
python3 experiments/decoder/fold_search246.py --family both --seconds 600
```

Install the optional solver in an isolated environment if rerunning synthesis:

```sh
python3 -m venv /tmp/zfc246-synthesis-env
/tmp/zfc246-synthesis-env/bin/python -m pip install -r requirements-synthesis.txt
/tmp/zfc246-synthesis-env/bin/python experiments/counter/synthesize_detector.py --states 7 --steps 16 --seconds 180 --long-min-read -7 --long-min-exit -8 --long-exit-head -8
```

The 12-run synthesis ledger is `experiments/decoder/run-ledger.json`: nine
unknown results, two eight-state SAT controls, and one seven-state UNSAT
control limited to an exact eight-step interface. The elementary proof of
that narrow lower bound is in the report; slower detectors remain open.

## Layout

- `baseline/context246/`: pristine supplied machine, complete source selection,
  baseline PDF/TeX, ordinary proof checkers, provenance, and notices.
- `experiments/tail/`: partial 245-state table, universal decrement proof, exact
  increment failure, tail searches, and universal detector-entry audit.
- `experiments/forward/`: partial 244-state table, universal arithmetic proof, exact
  collision theorem witnesses, and independent literal simulator.
- `experiments/decoder/`: alternate 246-state table, support and bootstrap checks,
  complete fold-search records, caller census, and synthesis ledger.
- `experiments/counter/`: two SMT specifications and all 12 solver results.
- `experiments/runtime/`: predecessor-action screen over 139 states, 8,808 directed
  runtime recipes, fixtures, rejection records, and exact context witness.
- `audit/`: independent theory review and pinned-source provenance.
- `results/`: compact findings and fresh delivery verification.

## State numbering and proof boundary

All new tables retain old Context246 labels. The baseline starts at 95, uses
dispatcher 96, and has separate halt label 254. Its 246 working labels are not
a contiguous interval; the maximum label, 255, is not a state count.

The local proofs are ordinary mathematical inductions whose literal and
structural steps are checked by the supplied small Python verifier. No
Lean or Rocq kernel build was performed here, and no serialized first-order
ZFC proof is supplied. The inspected selection of inherited Lean dependencies
is byte-identical to the pinned repository. A conventional internal-ZFC
interpretation argument is explained in the report and independent audit.

## Sources and integration

ProveIt is pinned to commit
`8cdc55ff9281b0aaba49bf74b0b225d57f12b893`; upstream busy-beaver/zf-254 is
pinned to `c132d7eae8158cd3a9850ea3eb7251158c3dd821`. The source paths and
hashes are in `audit/provenance.json` and the report bibliography.

This package is suitable for an incoming or research directory. Preserve
the incomplete labels on the 244- and 245-state tables and the existing
source attributions. It should not replace a certified machine or support
a claimed new sub-246 endpoint. The remote repository was left unchanged.

To rebuild the document, use a standard TeX distribution with the packages
listed at the beginning of `report.tex`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```
