# Research Report 43

Structural obstructions and nonnative inner families for the free-coefficient 83 candidate

4 October 2026

## Result and limits

- Every genuine full positive candidate zero has auxiliary factor z² > 0, with z² dividing Delta and z = gcd(|V|, y)
- On the additional squarefree-Delta slice, main = input = auxiliary = 1
- An explicit infinite power-of-17 family satisfies the intended inner factors, retained index, main projection, and compatible ordinary-input loading with p different from R
- The genuine prescribed-R, transport-1 completion is equivalent to the report's exact packing, transport and positivity tests in j and N
- No genuine completion at a rejected ordinary input is supplied. Ordinary-input language soundness remains OPEN
- The verified universal-construction baseline remains 84 = 47M + 37A, 18 positive witnesses, exact degree 187

Research_Report43.pdf is the readable report. report43.tex is the full editable LaTeX source. The original power-of-11 proof and its independent review are preserved, alongside the separate power-of-17 review. The earlier native-alias precursor is explicitly credited. No priority claim is made.

## Evidence structure

source/structure contains the structural author notes, including the superseded f=1-only note for chronology. source/inner contains the original and simple-family proofs. source/audits contains the distinct core, optional squarefree addendum, original inner, simple inner, and established84 independent reviews. The source/audits files are original review documents: relative paths inside those historical documents describe their original packets and are not report replay commands.

source/immutable contains the exact candidate, its immediate source/proof dependencies, compiler recipe, and attributed precursor. SOURCE_INVENTORY.json records the origin and SHA256 of every source file, including the two frozen component-manifest identities. source/receipts preserves their manifest snapshots and independent check receipts. Some preserved historical manifests describe files outside this curated selection; MANIFEST.json is the authoritative exact inventory of this report archive.

The arithmetic candidate source is pinned to commit 0d9d1e0174df30d82d80d758e9ba8e793203126e. Its JSON SHA256 is 682d37d4cedcd3c4a086ed3a2e55f272892670edb0424fc0fd8242337f1bf016. The source-array hash and Git blob identity are independently checked as inert data. The degree111 candidate claim is inherited source data and is not a newly re-proved degree theorem in this report.

## Authenticated mathematical replay

Use Python 3.11 or later. No third-party Python packages are needed. Obtain the trusted MANIFEST.json SHA256 from the accompanying delivery checksum, not by trusting an unverified modified archive.

    python3 -I -B verify_release.py --manifest-sha256 TRUSTED_SHA256
    python3 -I -B -O verify_release.py --manifest-sha256 TRUSTED_SHA256

Add --verify-only to authenticate without numerical replay. The verifier rejects missing files, extra files, symlinks, malformed paths and changed contents. It runs only check_math.py after authentication and compares its output with checks/MATH.normal.json. The optimized receipt must be identical.

The new report checker authenticates the source as data, compares the exact 84-to-83 one-row deletion, checks the live graph and 83-operation ledger, and evaluates independently written elementary formulas and Pell recurrences. It never executes a saved arithmetic schedule or imports upstream Python. Synthetic interface probes test only algebraic rewrites; they are not genuine compiler programs or full witnesses. The smallest 17-family fixture has a 1429-bit main coefficient and is explicitly excluded by the genuine scale constraint. Huge auxiliary values are not materialized.

## PDF reproduction

Requirements: a local TeX Live pdfTeX installation with standard LaTeX, Latin Modern, amsmath, amsthm, geometry, microtype, enumitem, hyperref and booktabs packages. All commands are offline and shell escape is disabled.

    python3 -I -B build_pdf.py --output /absolute/new/external/build --check-packaged

The build directory must be external and new or empty. The script creates a private format/font-map cache, compiles three times with fixed UTC metadata, and compares the PDF bytes. Exact equality requires the recorded pdfTeX toolchain. checks/PDF_BUILD.json records the build identity. The release PDF was rendered page by page and visually reviewed; QA images and format caches are deliberately excluded from this compact archive.

## ZIP reproduction

After authenticating the release, run the following from the extracted directory. This script imports only the newly written local verifier, so do not use Python's -I mode here; -B avoids cache files inside the exact inventory.

    python3 -B archive_release.py --manifest-sha256 TRUSTED_SHA256 --output /absolute/external/Research_Report43.zip

Paths are sorted, all member timestamps are 4 October 2026 at 00:00 UTC, and file modes and compression settings are fixed. The resulting archive can be compared against the accompanying ZIP SHA256. An isolated extraction/replay and a second PDF/ZIP build are required before delivery.

No original frozen packet was edited. No upstream Python, saved schedule, compiler builder, historical verifier, upload, publication or public repository write was performed by this report build.
