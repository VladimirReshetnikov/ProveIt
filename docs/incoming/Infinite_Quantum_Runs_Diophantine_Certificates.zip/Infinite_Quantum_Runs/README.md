# Infinite Quantum Runs, Finite Diophantine Certificates

**Canonical group inverses, all stopping-time moments, and geometric clocks with undecidable supports**

Prepared for Vladimir Reshetnikov on October 2, 2026.
Mathematical development, exposition, and code: ChatGPT.

## Read first

`article.pdf` is the complete article; `article.tex` is its standalone LaTeX source.
It contains proofs, four exact quantum examples, a literature/repository audit,
and eight proposed research directions.

The main construction certifies the unique group inverse G=(I-T)# and projection P
with four quadratic matrix equations. These determine stopping probabilities,
stopped outputs, all finite-path factorial moments, and a finite recurrence for
all moment orders. Canonical reduced rational wires produce one quartic equation
with a unique natural witness. The complete all-orders interface certifies the
finite recurrence, not a new single-fold polynomial graph for a variable moment
index.

A separate reduction preserves undecidable forbidden-record existence after
adding a rational clock that makes every runtime law exactly geometric. The
15-dimensional, nine-continuation-outcome undecidability input is the published
Eisert–Müller–Gogolin theorem. The new wrapper adds one terminating outcome.

The weak-clock theorem gives a convergent Laurent expansion, an exponential
mixture scaling limit, and inverse calibration coefficients. The manuscript also
clarifies a published generalized-inverse rationality conjecture and proves a
negative boundary theorem for computably scheduled one-dimensional loops.

## Scope and proof status

This is an AI-assisted, unrefereed research manuscript. General correctness
rests on its mathematical proofs; finite tests are supplementary. No Lean
formalization or repository build was performed. Historical priority for the
assembled construction is not established. Generalized inverse methods,
finite-dimensional quantum expected-runtime theory, Cayley–Hamilton, and MRDP
are credited as existing mathematics.

The main probabilistic interpretation assumes completely positive,
trace-nonincreasing rational maps, a finite-dimensional state space, and
*time-homogeneous* evolution. Physical validity is a promise to the arithmetic
compiler. Unbounded classical memory and arbitrary computable schedules are
not silently included. Nothing here resolves general single-fold or finite-fold
MRDP or improves the repository's universal operation-count bounds.

## Contents

- `article.tex`, `article.pdf`: source and compiled article.
- `code/quantum_loops.py`: exact rational quantum-loop analysis (SymPy).
- `code/quartic.py`: canonical wires and sparse quartic certificate compiler.
- `code/verify_certificate.py`: independent standard-library checker.
- `code/run_checks.py`: reproducible exact tests and artifact generator.
- `examples/*_certificate.json`: four fully explicit quartic polynomials in
  sum-of-squares form, natural witnesses, and decoded interface metadata.
- `examples/exact_results.json`: exact matrices, generating functions, and moments.
- `verification/results.json`, `verification/results.txt`: recorded test results.
- `SOURCE_AUDIT.md`: repository pin, external sources, and claim boundaries.
- `requirements.txt`, `Makefile`: dependencies and build commands.
- `MANIFEST.sha256`: file hashes, excluding the manifest itself.

## Run

Python 3.11 or newer is intended; the recorded run used Python 3.13.5 and
SymPy 1.14.0. A typical environment setup is:

```sh
python -m venv .venv
# Activate the environment using the command appropriate for your operating system.
python -m pip install -r requirements.txt
python code/run_checks.py
python code/verify_certificate.py examples/coherent_qubit_all_moments_certificate.json
```

The independent checker needs no third-party package. The test runner recreates
its example JSON files and verification reports. It performs no network access.

To build the PDF, use a TeX installation with pdfLaTeX and standard packages
including `lmodern`, `mathrsfs`, and `hyperref`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

`make pdf`, `make check`, and `make clean` are equivalent convenience targets.

## Recorded evidence

The run passed **33,708 exact assertions**, including **31,892 one-coordinate
mutation rejections** across the four exported witnesses. These are not 33,708
different quantum devices. The checker evaluates every quadratic residual and
independently checks decoded inverse and moment identities.

| Certificate | Natural variables | Quadratic residuals |
| --- | ---: | ---: |
| Scalar geometric, orders 0–3 | 262 | 213 |
| Partial qubit, orders 0–3 | 8,686 | 7,089 |
| Coherent qubit, orders 0–3 | 8,686 | 7,089 |
| Coherent qubit, all moments by recurrence | 14,258 | 11,657 |

Each polynomial is exactly the sum of the squares of the listed residuals.
Not expanding the sum is a storage choice, not a missing construction.
The checker checks a supplied polynomial and witness, not the general theorem
that the generator always constructs the right polynomial. That theorem is
proved in the article.
