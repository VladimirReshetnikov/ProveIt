# The Leading Asymptotic of OEIS A290268

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

## Proved result

For the number a(N) of nonzero monomials in the Nth derivative of x^(x²), after removing its common factor,

    a(N) = N²/2 + o(N²).

Only o(N²) of the outside-bulk tail candidates cancel. The proof uses explicit contours throughout the physical parameter cone: horizontal contours for high complex saddles, circles in z=tanh(t/2) for all low complex saddles, and the same mapped circles for the smaller real saddle. Uniform local asymptotics, analytic phase curvature and an integer-triangle estimate are combined through compact exhaustion. The derivative recurrence gives the matching upper bound.

This settles the leading-asymptotic question in the inspected repository. It does not prove exact noncancellation, the proposed exact term-count formula, or the proposed generating function. There is no numerical error rate or order threshold, and no global uniform power-saving remainder is asserted.

## Files

- `article.pdf`: complete 11-page proof
- `article.tex`, `tanh_sections.tex`: complete LaTeX sources
- `build_local.sh`: local build wrapper
- `verify_tanh_identity.py`, `tanh_identity_checks.json`: 432 independent exact coefficient comparisons, including 16 zero cases
- `verify_curvature_seed.py`, `curvature_seed.json`: exact rational Taylor inequalities for the nontrivial phase-curvature seed
- `verify_derivative_counts.py`, `derivative_counts.json`: independent exact derivative-recurrence regression through N=200

All verification scripts use the Python standard library. Run them directly with Python. The finite recurrence check verifies the support envelope, bulk counts and known reflection holes on those finite rows; it is not a proof of exact noncancellation or a substitute for the analytic theorem.

On a standard LaTeX installation, run `pdflatex article.tex` twice. The wrapper supplies local format and font-map setup for the research environment.

## Source status and review

A bounded primary-source check on 1 October 2026 confirmed that the live OEIS A290268 entry still labels its exact formula and generating function conjectural. The repository report's Question 6 asks for the leading asymptotic proved here, and commit ca81647a9f679e96d49ffdbc54b0c0ab13d10a36 remains the latest commit touching that source article. This is not an exhaustive priority search.

The complete argument and final transcription received independent mathematical review, including a fresh full-cone audit. Every PDF page was visually checked; the build is clean. The result is not Lean-formalized or externally refereed. The exact source model, established bulk input, and classical partial fractions are cited in the paper.
