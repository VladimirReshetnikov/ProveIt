LEXICOGRAPHIC WELL-ORDERS OF THE SURREAL NUMBERS
Cuts, canonical class blocks, and changes of interpretation
Prepared for Vladimir Reshetnikov, 3 October 2026

CONTENTS

surreal_lexicographic_orders_further_study.pdf
    The complete 53-page article, including proofs, an interpretation map,
    a formalization plan, twelve research questions, and references.

surreal_lexicographic_orders_further_study.tex
    Self-contained LaTeX source. The bibliography is embedded; no external
    graphics, source fragments, or BibTeX database are needed.

build.sh
    A convenience script for rebuilding the PDF with latexmk.

BUILD

Install a TeX distribution with pdfLaTeX, latexmk, Latin Modern, AMS math,
mathtools, mathrsfs, geometry, booktabs, longtable, array, tabularx,
enumitem, microtype, xcolor, titlesec, fancyhdr, needspace, hyperref,
and bookmark. These are standard TeX Live / MiKTeX packages.

In the extracted directory, run:

    sh build.sh

Equivalently:

    latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_lexicographic_orders_further_study.tex

If latexmk is unavailable, run pdfLaTeX three times on the .tex file so
that the contents and cross-references stabilize.

REPOSITORY BASIS AND STATUS

Repository: https://github.com/VladimirReshetnikov/ProveIt
Inspected revision: 83befe707f2840c2b53e0606701d8a2b28598e47

The article distinguishes results already present in the inspected
repository from extensions developed in this manuscript. Its mathematical
validation consists of conventional proofs and independent AI-assisted
proof review. It does not claim literature priority, peer review, or a
machine-checked formalization. No Lean build or complete imported-axiom
audit was performed.

All cited sources, foundational assumptions, and proposed Lean reuse
points are documented inside the article. The PDF was compiled from the
included source and its rendered pages were visually inspected.

The archive contains only the deliverable and build instructions, without
LaTeX auxiliary files or intermediate research fragments.
