# Saturation and Single-Fold Diophantine Compilation of Concurrent Counter Programs

**Research article prepared for Vladimir Reshetnikov — September 30, 2026.**

The package contains a 30-page article, its self-contained LaTeX source, an exact-integer Python compiler, polynomial certificates, executable witnesses, and reproducible verification reports.

## Start here

Read `article.pdf`. Rebuild it from `article.tex` with:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The source has an embedded bibliography and no external image dependencies. It uses standard TeX packages including newtx, amsmath, amsthm, microtype, hyperref, and cleveref. Two or more `pdflatex` passes also work. No font files are distributed.

## Main results and scope

The article proves an exact resource-summary algebra for token-consuming/producing transitions, a compact Boolean signature for lexicographic trace normality, and the signature identity S^2 = S^3. As a consequence, normality of any fixed nested repetition expression depends on each parameter only through the cases 0, 1, and at least 2.

It constructs a degree-at-most-four polynomial with O((p+q)N) auxiliary variables for a schedule with N syntax nodes, p counters, and q labels. For fixed endpoints and **all repetition parameters fixed**, the polynomial has exactly one natural auxiliary solution precisely on accepted executions. Optional canonicality means the specified expansion must already be lexicographically least; it does not normalize an arbitrary restricted schedule family.

A separate theorem gives a root/trace-class bijection for all words of a fixed length. Its dedicated polynomial-export frontend is not implemented here. The normality tests do independently construct bounded trace classes by adjacent swaps.

Further results give Presburger definability at repetition depth one, universality for globally shared-parameter multi-counter schedules at depth two, an exact degree/depth correspondence for separated one-counter schedules, and finite-fold/single-fold representation equivalences at depth four. This is universality of **existential schedule parameterization**, not undecidability of ordinary unrestricted one-counter or Petri-net reachability.

The proofs are mathematical proofs in the article. The software is an independently testable prototype, not kernel-verified code. The classical ingredients are credited, and historical priority for the combined formulations is not established. The article does not claim to solve the general finite-fold or single-fold Diophantine conjectures.

## Files

- `article.tex`, `article.pdf`: full article, twelve proposed research questions, proof/status ledger, bibliography.
- `code/compiler.py`: expression syntax, resource and normality summaries, and the single-fold quartic compiler.
- `code/test_compiler.py`: 49,402 exact finite checks, including exhaustive small cases and fixed-seed expression tests.
- `code/substrates.py`: solution-preserving polynomial/circuit-to-separated-schedule frontend, with 320 additional checks.
- `code/verify_export.py`: independent evaluator for exported polynomial residuals; does not import the compiler or execute witness recipes.
- `examples/multiplication_certificate.json`, `examples/multiplication_witness.json`: resource-only polynomial and its valid 79-witness assignment.
- `examples/canonical_multiplication_certificate.json`, `examples/canonical_huge_witness.json`: canonical polynomial and a valid 309-witness assignment for an execution whose length has 221 decimal digits.
- `verification/`: the two test-suite reports, two independent exported-certificate checks, and PDF quality metadata.
- `repository_context.md`: repository snapshot, inspected scope, and integration boundaries.
- `SHA256SUMS.txt`: integrity hashes for the package files other than the hash manifest itself.

## Run the checks

Python 3.10 or newer; standard library only; no network access needed.

```sh
python code/test_compiler.py
python code/substrates.py
python code/verify_export.py examples/multiplication_certificate.json examples/multiplication_witness.json
python code/verify_export.py examples/canonical_multiplication_certificate.json examples/canonical_huge_witness.json
```

The two suites pass 49,722 checks in total; the last two commands additionally validate the exported files independently. Test counts refer to tested predicates/identities, not to independent theorems. Execution times depend on the machine. The seed of the main suite is 20260930.

The huge example uses x=10^100, y=10^120, and z=2xy+3 in the expression `((++)^x)^y +++ (-)^z`, starting and ending at zero. Its word length is 2z. No expansion of that word is performed.

## Minimal compiler example

Run this from the package directory:

```python
import sys
sys.path.insert(0, "code")
from compiler import Compiler, multiplication_example

net, expression = multiplication_example()
builder = Compiler(net, canonical=True).compile(expression)
inputs = {"k:x": 3, "k:y": 4, "k:z": 27, "m:0": 0, "n:0": 0}
assignment = builder.construct(inputs)
assert builder.energy(assignment) == 0
builder.export("example.json")
```

Use a fresh `Compiler` for each compilation. Parameters are named `k:<name>` in the polynomial; endpoint coordinates are `m:<index>` and `n:<index>`. All coefficients are integers and all inputs/witnesses are nonnegative integers. Labels are ordered by Python string order unless the desired order is encoded into the label names.

`construct` computes the canonical internal values for supplied parameters. For an invalid endpoint or nonnormal word it still produces an assignment, but `energy` is positive. This is not a solver for unknown repetition parameters.

## Certificate format

Each residual is a list of integer-coefficient monomials. A monomial is a list of variable names, with repetitions denoting powers. The represented ordinary polynomial is exactly the **sum of the squares of all residuals**. Every residual has degree at most two.

Witness recipes are optional executable constructors, not extra operations in the polynomial language. The independent verifier ignores them. Read JSON using an exact-integer implementation; JavaScript's ordinary floating-point number representation cannot preserve the large examples.

## Limitations

The prototype uses syntax trees and transparent allocations, not DAG sharing, aggressive constant propagation, or optimized witness counts. The separated-scheme frontend expands coefficients in unary. The tests do not constitute a proof of unrestricted uniqueness; the article's structural proof supplies that claim. No Lean files, proof-assistant builds, or formal verification of this new compiler are claimed.
