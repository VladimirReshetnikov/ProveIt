# Binary Insertion Spectra from a Single Unary Word

**Arbitrary finite profiles and a sharp quadratic witness bound**  
Research draft prepared with ChatGPT for Vladimir Reshetnikov, 28 September 2026.

## Main results

The paper resolves the fixed-binary finite-spectrum question explicitly left open
in ProveIt's `insertion-degree-spectra` report. Every finite set of positive
integers containing 1 is the insertion-degree spectrum of finite binary
languages, even with the inserted language consisting of the single word a^m.
More strongly, any finite list of degrees between 2 and m is realized by distinct
exceptional outputs, with every other output having degree 1. The full shuffle
is an entire binary fixed-letter-count class.

In the full-coverage class, an isolated degree-m output with inserted word a^m
has length at least m^2 for m >= 3. This bound is attained for every m >= 6.
**This lower bound is not asserted for arbitrary binary spectra without full
coverage.**

The singleton unary-source no-gap theorem was already proved by Hughes,
Theorem 9 of arXiv:2608.27755v1. The contribution here is the arbitrary binary
profile obtained by minimizing over a target language, not that earlier theorem.
The unrestricted both-singleton conjecture is not resolved.

## Contents

- `article.pdf`: the compiled research article.
- `article.tex`: self-contained LaTeX source with embedded bibliography.
- `code/verify.py`: standard-library exact verifier and construction routines.
- `data/verification.json`: executed machine-readable receipt.
- `data/profile_checks.csv`: all 26 exhaustively checked parameter profiles.
- `data/worked_targets.csv`: all 46 target words in the degree-three example.
- `data/worked_outputs.csv`: all 91 output words and their minimum degrees.
- `CLAIMS_AND_VALIDATION.md`: precise claim and validation boundaries.
- `SOURCES.md`: repository snapshot, primary source, and search boundary.
- `Makefile`: rebuilding and verification commands.
- `SHA256SUMS.txt`: hashes of the packaged files, excluding the hash file itself.

## Reproduce

The verifier requires Python 3.10 or later and no third-party packages:

```sh
python code/verify.py
```

It uses explicit exceptions, not removable `assert` statements. It rewrites the
CSV and JSON results. To preserve the shipped receipts while testing:

```sh
python code/verify.py --out reproduced-data
```

The article compiles with a conventional TeX Live or MiKTeX installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. The bibliography is embedded; there is no BibTeX step. Fonts are
provided by the user's TeX installation, not bundled in this archive.

## Executed checks

All checks passed with Python 3.13.5:

- 26 complete profiles and 493,704 output/profile comparisons;
- 207,694 direct-versus-interval target-membership comparisons;
- 16,744 literal masks and 4,186 independent dynamic-program comparisons in the
  worked example;
- 56 exact singleton histograms and 819 exact polynomial coefficients;
- 316 large-parameter hypothesis checks and 12,640 explicitly nonexhaustive,
  seeded output samples, up to m = 80;
- 315 capped-composition levels and 15 literal dynamic-program boundary checks.

The all-parameter results have written proofs independent of the finite tests.
No Lean verification or independent peer review is claimed. The novelty claim
is bounded by the repository and literature inspection described in SOURCES.md.
