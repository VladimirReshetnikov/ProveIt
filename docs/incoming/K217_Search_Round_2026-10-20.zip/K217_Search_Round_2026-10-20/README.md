# Search toward a blank-started machine with at most 217 states

Completed investigation snapshot, 20 October 2026. **Target unmet:** this archive contains no verified blank-started consistency-search machine with 217 or fewer working states. It is not an impossibility or exhausted-search claim.

Read report.pdf for the full account and report.tex for editable source. File paths in the report are relative to this archive root.

## Positive results and boundaries

- Two exact 217-state initialized cores each pass all 6,167 arbitrary-natural primitive guards. The crossover core has a proved four-bit scanner distinction. Both still fail the required blank initialization; the exact crossover table reaches a provable outward ray after 85 steps.
- A clean copy replayed the crossover core's complete runtime/tag proof and reproduced its ordered case receipt byte-for-byte. Six short owned source/certificate/invariant checks also passed. See replay_results/REPLAY_RESULT.json.
- The H/PW native-calculus equivalence and three-field enumerator bridge are proved at the ordinary mathematical/source-contract level. Their tested source templates are too large.
- Exact pairing-codec transport, macro arithmetic and new-source scratch guards are proved, but the concrete macro substitution does not yield an accepted machine allocation.
- New and independently reviewed negative results are confined to the stated restricted calculi and finite machine/source families. No minimum-state theorem follows.

## Do not confuse these artifacts

- Published 218-state input tables are prior constructions, not claimed as newly constructed here. Their separately delivered full audit is not duplicated.
- initialized217.native.tm files are initialized-runtime artifacts, not valid blank-started solutions.
- crossover30/crossover652 raw218 allocations have the exact stated prefix/selector proof boundaries, not automatic runtime or startup acceptance.
- Shared-equality provisional223 and H/PW provisional231 counts describe unaccepted allocations, not verified machines.
- 205/207/209/217 source-DAG counts and seven-constructor formula DAGs are not physical-state counts.

## Stopping scope and contents

The approved machine/source families are closed at the explicit caps/thresholds recorded in the report, while the construction goal remains open. Detailed upstream summaries are pinned at d4e6b1269db24fd3379bd219d90d4ed6f11f131b; the final freshness check reports head 4dd2619ab547b23c3fe7951f9d321e922d7fbab5 without a blank217 claim. The final bounded U=B plus R(b,c) pilot has stopped; its fixed identity and scoped search receipt are supplementary evidence outside the seven-command clean replay profile, while calibration remains open; no received programs were executed and no priority claim is made for overlapping results.

Selected evidence, exact tables/sources, owned analysis code and inert received definitions are included. Bulk redundant expansions of 717 neutral sources are omitted; inventories, tested receipts, exact hashes, reconstruction recipes and selected sources are retained. Some exploratory scripts require regeneration of such omitted material. The verified replay profile in REPRODUCE.md is self-contained; it is not a promise that every exploratory file is independently runnable without regenerated data.

Historical receipts preserve the claims made at their production stage. Later bridge, row-order, scratch-invariant and independent-review results are reconciled in report.pdf, rather than silently rewriting old receipts.

Run python3 -B verify_manifest.py before editing. It checks distributed bytes only, not mathematical correctness. Work in a separate extracted copy when rerunning scripts, since many write fresh receipts.
