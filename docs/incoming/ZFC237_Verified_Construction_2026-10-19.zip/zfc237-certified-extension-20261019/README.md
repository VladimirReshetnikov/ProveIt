# Verified 237-state endpoint and 238-state research companion

The final machine has **237 working states**, **474 rows**, one binary tape,
and a fully charged all-zero initializer. The separate halt outcome adds one
control label, giving 238 labels in total. The required strict bound is met.

The ordinary mathematical result, using the explicitly identified inherited
ProveIt source calibration, is

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{237},0^{\mathbb Z})
\longleftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

**Proof level:** a complete ordinary mathematical proof supported by fresh
executable certificates. No newly compiled Lean/Rocq theorem for the exact
237 table, ancestor-library rebuild, or serialized internal PA proof is
claimed. Actual nonhalting follows if ZFC is consistent; the biconditional
itself requires no consistency assumption.

## What is in this delivery

- `full_report.pdf`: the combined 28-page report, with the 237-state
  supplement first and the complete 238-state companion second.
- `report237.pdf` and `report237.tex`: the final endpoint, attribution, exact
  four-row patch, full all-initial-tape simulation proof, evidence scope, and
  complete 237-state transition table.
- `composition238/report.pdf` and its editable sources: the full 21-page
  independently prepared 238-state construction, source/calibration proof,
  unbounded runtime analysis, initialization, formalism comparison, and the
  six-valued K/S obstruction. The entire earlier package is preserved.
- `machines/`: both final labelings and their exact bijection.
- `verification/`: new independent finite-transfer and startup checkers.
- `evidence/`: actual fresh receipts and packaged replay.
- `reference/prior237_source.json`: the previously existing report that
  supplied the extra reduction, identified precisely.

## Provenance: the extra reduction was already reported

The 238-state construction was completed independently by composing two
distinct incoming 239-state reductions. A late read-only source check then
identified the user's existing `ZFC_237_State_Construction_2026-10-19.pdf`
(22 pages, created 2026-10-19 at 16:34:01 UTC). It uses the exact same 238
machine as an intermediate and adds a `235 -> 98` reduction.

This delivery **credits that report for the additional reduction**. The new
work here is an independent certificate for it, a fresh startup comparison,
and a complete connection to the independently checked 238-state proof.
The original 238 report's novelty comparisons concern the inspected incoming
archives before that later source comparison; they are not a claim of
priority over the pre-existing 237 report. Neither a global minimum nor a
new discovery of the 237 machine is asserted.

The existing report also asserts a direct unbounded 237 runtime verification.
Its original checkers were not imported or executed here. Our final theorem
uses a complete independent all-tape simulation from the freshly verified
238 machine, which suffices without another direct runtime replay.

## Exact identities

| Item | Value |
|---|---|
| Final table | `machines/zfc_extended237.tm` |
| Working labels | `0…236` |
| Canonical start / dispatcher / halt | `0 / 84 / 237` |
| Inherited start / dispatcher / halt | `95 / 96 / 254` |
| Tape | One binary tape indexed by the integers |
| Initial tape / head | All zero / 0 |
| Moves | L or R, one cell per transition |

Canonical SHA-256:

```text
7eda1da1fcda629cae86d22b01d3faf419552cf04ed4179f0c045ad0adf2c1a6
```

Inherited-label SHA-256:

```text
a3c4407f30e2e2139af87c6a91948c518134855841a28eb85b1d81bcfd026c9a
```

## The final reduction

Delete inherited state `235` and change four retained rows of the exact 238
table. Every other retained row stays literally identical.

| Row | 238 predecessor | 237 final |
|---|---|---|
| `98/0` | `0R113` | `0L240` |
| `139/1` | `1R235` | `1R98` |
| `156/1` | `1R235` | `1R98` |
| `240/1` | `1R99` | `1L87` |

The deleted rows are `235/0 = 0R231` and `235/1 = 1R16`; retained `98/1`
is also `1R16`. There are 470 literally unchanged retained rows. In the
relational proof, 473 old rows are ordinary identities after applying
`phi(235)=98`; the three exceptional old rows expand to blocks of lengths
3, 5 and 3, with identical whole tapes and head displacement +1.

The old predecessor invariant says: at 98 or 240, the immediate-left bit is
zero; at 139 or 156, it is one; and at 235, both preceding bits are one.
All eight incoming rows preserve this invariant, and it is vacuous at start
95 on every binary tape. Thus no additional source-frame guard is needed.
This invariant and the positive block identities prove all-initial-tape
halting equivalence with the 238 machine, using ordinary induction.

The startup has no exceptional-row visits. A fresh mapped two-table check
therefore reaches the same complete frame after exactly **409,835** steps:
351 one cells, all other cells zero, dispatcher 84, head -5, marker -6,
header 176, logical registers `(3,0,0,0,3,0,0,0,0)`, and 167 spare ones.

## Reproduce

Use Python 3.10 or later, its standard library, and assertions enabled. The
output directory must be new or empty and outside the extracted package.

```bash
python3 -B reproduce.py --output /tmp/zfc237-replay
```

The default replays the complete **238** unbounded runtime and then proves
the **237** endpoint through the finite all-tape transfer. The recorded
first 238 runtime proof took about 222 seconds. All three extra blocks and
the final startup are freshly checked by this driver. Its receipt explicitly
distinguishes these obligations from a fresh direct 237 runtime run.

```bash
python3 -B reproduce.py --quick --output /tmp/zfc237-quick
```

Quick mode omits the fresh unbounded 238 runtime execution, binds its
archived result to exact source/table/engine hashes, and still replays source
control, calibrated source-data identity, local proofs, both startups and
the finite logical obstruction. Add `--with-guard` to replay the independent
boundary239 selector proof as well.

No network, solver or proof-assistant installation is needed. The manifest
binds delivered bytes and is not a digital signature. Compile `report237.tex`
in a separate working copy with two passes of `pdflatex`; the companion has
its own editable source and compilation instructions.

To assemble the combined PDF after compiling both components, install
PyMuPDF in the document-build environment and run:

```bash
python3 -B assemble_pdf.py --output /tmp/zfc237-full-report.pdf
```

PyMuPDF and LaTeX are needed only to rebuild documents, not to replay the
mathematical certificates. Internal links and section outlines from the
238-state companion are preserved in the combined PDF.

For incorporation, preserve the original reductions, their attribution, and
the proof-level metadata. A future exact-table proof-assistant endpoint can
port the finite simulation and its structural invariant. The inherited
licenses and notices remain in `composition238/licenses/`.
