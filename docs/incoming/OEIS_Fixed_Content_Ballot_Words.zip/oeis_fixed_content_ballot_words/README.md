# Fixed-Content Ballot Words

## Article

**A proof of the A215570 recurrence, a fixed-row asymptotic theorem, and all-orders inversion.**

Prepared for Vladimir Reshetnikov, October 1, 2026.

The 22-page article contains:

1. A conventional proof of Kauers–Koutschan Conjecture 15 (2023), the normalized order-three recurrence for OEIS A215570. Its complete rational telescoping certificate is printed in Appendix A.
2. A proof of the fixed-row asymptotic conjecture in OEIS A215561 for every fixed alphabet size r >= 2, with algebraic leading constants and a conservative O(n^(-1/5)) relative error.
3. A positive exact coefficient formula for A215570 and a proof of an all-orders dominant inverse-power asymptotic expansion. An exact coefficient algorithm computes as many corrections as requested.
4. D-finiteness of every fixed row, a limit law for primitive factor counts, rounded asymptotic inverse formulas, and further research questions.

The explicit recurrence for the four-symbol row A215562 is not obtained. The growing-alphabet regime and exponentially small transseries sectors are not resolved. These results are not claimed to be Lean-verified or independently peer-reviewed. The literature check is targeted, not an exhaustive priority certification.

## Files

- `article.tex`: self-contained LaTeX source, including the full certificate and bibliography.
- `article.pdf`: compiled article.
- `verify.py`: deterministic exact checks, independent enumeration, and numerical illustrations.
- `certificate_data.py`: complete integer arrays specifying the certificate.
- `verification_log.txt`: output of the executed checker.
- `verification_results.json`: exact asymptotic coefficients, tested ranges, small-row data, and numerical errors.
- `a215570_terms.csv`: exact C_n and A215570(n) for n = 0,...,103.

## Reproduce the checks

Python 3.10 or later, SymPy, and mpmath are required. The recorded run used Python 3.13.5, SymPy 1.14.0, and mpmath 1.3.0.

```sh
python -m pip install sympy mpmath
python verify.py
```

The checker:
- verifies the generic quartic pair-product resolvent and marked sextic;
- reduces both rational telescoping residuals identically to zero over Q(n,t);
- checks normalization factors and the recurrence's exact linear solution;
- evaluates the saddle Hessian and first Gaussian correction exactly;
- compares recurrence-generated coefficients to the independent positive formula for n=0,...,103;
- verifies low-order counts independently by content-state dynamic programming;
- computes coefficients through n=1000 and asymptotic corrections d_0,...,d_8;
- rewrites the log-independent JSON and CSV results beside the script.

Numerical errors in the JSON are high-precision illustrations, not interval enclosures. The analytic proofs in the article, not the tables, establish the asymptotic results.

## Build the PDF

A standard TeX installation with pdfLaTeX and the packages named in the preamble is sufficient.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

A third pass is useful after substantial pagination changes. No external bibliography database, shell escape, internet access, or font files are needed.

## Research provenance and trust boundary

Sources include the current OEIS entries, Kauers and Koutschan (2023), Banderier and Flajolet (2002), and Lipshitz (1988). ProveIt was read at commit `29aca108ed25d714f31b1316512777fbbdc8e006`. The article uses the repository as research context; it does not claim that existing repository code formalizes these new proofs.

The exact certificate checks are finite symbolic calculations. They do not replace the semantic derivation from words to the coefficient formula, which is proved in the article. No external repositories or OEIS entries were modified.
