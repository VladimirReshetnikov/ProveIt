# Sharp Symmetry Certification for Gowers Derivative Spectra

**Alternating-rank bounds, lossless polarization, and robust finite-field inverse steps**  
Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and ProveIt.  
6 October 2026.

## Main result

For an odd prime p, V = F_p^n, a 1-bounded function f, and a multilinear
frequency selector sigma : V^k -> V*, let A_f(sigma) be the average squared
normalized Fourier coefficient of the k-fold derivative at sigma(h).
If the associated (k+1)-linear form T(h,y) = sigma(h)(y) is nonsymmetric, then

    A_f(sigma) <= 1 - (1 - 1/p)^k.

The bound is attained for every n >= 2, including selectors symmetric in
all k derivative inputs. A stronger bound averages p^(-r) over the half-ranks
of alternating bilinear slices, retaining frozen-derivative amplitudes.

When T is symmetric and p > k+1, the explicit polynomial

    P(x) = T(x,...,x)/(k+1)!

satisfies the exact identity

    A_f(sigma) = || f e_p(-P) ||_(U^(k+1))^(2^(k+1)).

There is a pointwise identity before averaging over the increments.
This gives an equality-form refinement of the global scalar phase extraction
in the corrected Proposition 17.2 and a sharp vector-space certification
criterion. It does not improve the scalar coefficient one, prove the local-box
Proposition 17.7, or improve an end-to-end Szemeredi bound.

## Files

- `sharp_symmetry.tex` and `sharp_symmetry.pdf`: complete article, proofs,
  examples, limitations, twelve research questions, bibliography, integration plan.
- `checks/verify.py`, `checks/results.json`: reproducible exact and numerical
  finite checks, with the supplied run results.
- `SOURCE_AUDIT.md`: source versions, repository snapshot, novelty limits.
- `FORMALIZATION_PLAN.md`: definitions and dependency-level proof obligations.
- `claims.json`: machine-readable claim map; not a formal proof-status ledger.
- `Makefile`, `requirements.txt`: build and check entry points.

## Build

A standard LaTeX installation with `latexmk`, `pdflatex`, Latin Modern, amsmath,
amsthm, microtype, hyperref, geometry, booktabs, fancyhdr, and enumitem suffices.
There is no external bibliography file or figure dependency.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error sharp_symmetry.tex
```

Without latexmk, run `pdflatex -interaction=nonstopmode -halt-on-error
sharp_symmetry.tex` twice (a third pass may be needed after edits to references).

The checks require Python >= 3.10 and NumPy. They were run using Python 3.13.5
and NumPy 2.3.5.

```sh
python checks/verify.py --output checks/results.json
```

Alternatively, `make all` runs the checks and builds the PDF. `make clean`
removes auxiliary LaTeX output while keeping the PDF. Timing and floating-point
roundoff can vary between runs; exact integer census results should not.

## Verification summary

All supplied checks passed. The two principal exhaustive checks are exact:

* All 6,561 trilinear tensors on F_3^2 were examined with f = 1. Among
  nonsymmetric tensors the maximum zero-frequency count was 45/81 = 5/9,
  attained by 120 tensors. Both slice-profile bounds passed for every tensor.
* All 19,683 functions F_3^2 -> {1, omega, omega^2}, for omega^3 = 1,
  were examined at B(h,x) = h_1 x_2. The maximum was 1/3, attained by
  324 functions. Squared moduli were computed using the exact integer identity
  |a+b omega+c omega^2|^2 = a^2+b^2+c^2-ab-ac-bc.

Other checks cover all 81 two-dimensional bilinear matrices, rank-four examples,
372 mixed tests, 256 nonconstant-function tensor profiles, 18,432 exact sampled
polarization tuples, 12 complete F_5^2 pointwise energy identities, 256
multiaffine selectors, examples over F_9, and the characteristic-three obstruction.
Random samples and floating-point checks are labelled as such. They supplement,
not replace, the mathematical proofs.

## Integration

Suggested destination:

    Combinatorics/Ramsey/Research/GowersSzemeredi/sharp-symmetry-certification/

Snapshot used:

    6c2e2172bab8a0af4aed6b62d53ae7cde9252e8d

All LaTeX labels and bibliography keys use prefix `ssc:`. The corrected source
already has degree k+1 and the characteristic condition in Proposition 17.2;
this delivery does not rediscover those repairs. Do not overwrite the existing
merged local-quantitative-refinements article or update checked Lean counts
merely because this manuscript is integrated.

## Status and limits

The manuscript supplies self-contained proofs and a scoped literature comparison.
The sharp threshold/rank-profile formulation is the proposed contribution;
standard finite Heisenberg orthogonality and polarization are not claimed as
new mathematics. Literature priority has not been established. This is an
unrefereed AI-assisted research draft, not independently reviewed or
proof-assistant verified. No Lean code is claimed to compile. No repository
writes were performed. No third-party papers or font files are redistributed.
