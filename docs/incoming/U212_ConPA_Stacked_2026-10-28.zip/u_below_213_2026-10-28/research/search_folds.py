"""Discover bounded local folds with an inductive finite-window invariant.

The abstract reachability starts state0 with every radius-R pattern and
introduces either fresh boundary bit after every transition, so it is a sound
overapproximation for all initial tapes. Candidate fold checks use actual
modified transition targets, never an unmodified helper path.
"""
from pathlib import Path
from collections import deque
import json,time,sys,random,hashlib,argparse

def table(path):
    return {tuple(map(int,a[:2])):(int(a[2]),1 if a[3]=='R' else -1,int(a[4]))
            for line in Path(path).read_text().splitlines()
            if line and not line.startswith('#') for a in [line.split()]}

def abstract(T,R):
    W=2*R+1; F=(1<<W)-1; Q={q for q,b in T}; seen={q:set() for q in Q}; queue=deque()
    for m in range(1<<W):seen[0].add(m);queue.append((0,m))
    while queue:
        q,m=queue.popleft();b=(m>>R)&1;w,d,z=T[q,b]
        if z not in Q:continue
        m=(m&~(1<<R))|(w<<R)
        if d==1:base=m>>1;added=1<<(W-1)
        else:base=(m<<1)&F;added=1
        for n in (base,base|added):
            if n not in seen[z]:seen[z].add(n);queue.append((z,n))
    return seen

def path(T,q,m,R,limit,fold=None):
    h=0;out={}
    for i in range(1,limit+1):
        if not -R<=h<=R or (q,(m>>(h+R))&1) not in T:break
        b=(m>>(h+R))&1;w,d,z=T[q,b];m=(m&~(1<<(h+R)))|(w<<(h+R))
        q=fold[1] if fold and z==fold[0] else z;h+=d
        key=(q,h,m)
        if key in out:break
        out[key]=i
    return out

def compare(T,q,r,pattern,R,limit,oldpath=None):
    old=oldpath or path(T,q,pattern,R,limit)
    new=path(T,r,pattern,R,limit,(q,r))
    common=old.keys()&new.keys()
    if not common:return None
    key=min(common,key=lambda k:old[k]+new[k])
    return (old[key],new[key],key)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('table');ap.add_argument('--radius',type=int,default=5)
    ap.add_argument('--limit',type=int,default=63);ap.add_argument('--output',default='work/novel/fold_search.json')
    a=ap.parse_args();T=table(a.table);start=time.monotonic();seen=abstract(T,a.radius)
    print('abstract',sum(map(len,seen.values())), 'seconds',time.monotonic()-start,flush=True)
    survivors=[];rng=random.Random(0);total=0
    for q in sorted(seen):
        if q==0:continue
        patterns=sorted(seen[q]);rng.shuffle(patterns)
        if not patterns:continue
        old=[path(T,q,m,a.radius,a.limit) for m in patterns]
        for r in sorted(seen):
            if q==r:continue
            total+=1;matches=[]
            for m,p in zip(patterns,old):
                c=compare(T,q,r,m,a.radius,a.limit,p)
                if c is None:break
                matches.append((m,*c))
            else:
                x={'removed':q,'representative':r,'cases':len(patterns),'max_old':max(c[1] for c in matches),'max_new':max(c[2] for c in matches)}
                print(json.dumps(x),flush=True);survivors.append(x)
        if q%30==0:print('state',q,'seconds',time.monotonic()-start,flush=True)
    result={'table_sha256':hashlib.sha256(Path(a.table).read_bytes()).hexdigest(),'radius':a.radius,'limit':a.limit,'abstract_frames':sum(map(len,seen.values())),'pairs':total,'candidates':survivors,'seconds':time.monotonic()-start}
    Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
