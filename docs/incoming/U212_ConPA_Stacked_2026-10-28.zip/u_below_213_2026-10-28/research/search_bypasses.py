from search_folds import table,abstract,path
from pathlib import Path
import json,time,random,hashlib,collections

def redirects(T,seen,R=5,limit=63):
    rng=random.Random(1);states=sorted(seen)
    incoming=collections.Counter(v[2] for v in T.values())
    result=[]
    for (p,b),(w,d,q) in sorted(T.items()):
        if q not in seen or incoming[q]<2:continue
        patterns=set()
        for m in seen[p]:
            if (m>>R)&1 != b:continue
            m=(m&~(1<<R))|(w<<R)
            if d==1:base=m>>1;new=1<<(2*R)
            else:base=(m<<1)&((1<<(2*R+1))-1);new=1
            patterns.add(base);patterns.add(base|new)
        patterns=sorted(patterns);rng.shuffle(patterns)
        if not patterns:continue
        old=[path(T,q,m,R,limit) for m in patterns]
        for r in states:
            if r==q:continue
            newT=T.copy();newT[p,b]=(w,d,r)
            mxold=mxnew=0
            for m,oldp in zip(patterns,old):
                newp=path(newT,r,m,R,limit)
                common=oldp.keys()&newp.keys()
                if not common:break
                k=min(common,key=lambda k:oldp[k]+newp[k])
                mxold=max(mxold,oldp[k]);mxnew=max(mxnew,newp[k])
            else:
                item={'row':[p,b],'from':q,'to':r,'cases':len(patterns),'max_old':mxold,'max_new':mxnew}
                result.append(item)
    return result

if __name__=='__main__':
    P=Path('work/stack/u212.native.tm');T=table(P);start=time.monotonic();seen=abstract(T,5)
    found=redirects(T,seen)
    Path('work/novel/bypass_search.json').write_text(json.dumps({'table_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'radius':5,'limit':63,'candidates':found,'seconds':time.monotonic()-start},indent=2)+'\n')
    print(json.dumps(found,indent=2));print('seconds',time.monotonic()-start)
