import pathlib, json, sys, time, concurrent.futures
BASE=pathlib.Path('/workspace/scratch/a55d4f493aec')
ENG=BASE/'sources/source_00/U213_ConPA_2026-10-28'
sys.path.insert(0,str(ENG/'code'))
import symbolic_runtime as s
import build_table as bt
def check(i):
    d=next((BASE/f'sources/source_{i:02}').iterdir())
    T=bt.parse((d/'machine/u213.native.tm').read_bytes())
    rows=json.loads((d/'machine/sites.json').read_text())
    assert T[34,0]==(0,-1,50)
    T[34,0]=(0,-1,75)
    del T[50,0]; del T[50,1]
    Q={q for q,b in T}
    m={int(k):int(v) for k,v in json.loads((ENG/'inputs/legacy_mapping.json').read_text()).items()}
    for q in Q|{254}:m.setdefault(q,q+1000)
    L={(m[q],b):(w,d,m[z]) for (q,b),(w,d,z) in T.items()}
    lemmas,blocks=s.prove_blocks(L)
    start=time.monotonic(); cases=[]
    for j,row in enumerate(rows):
        for pos in ((False,True) if row[1]=='CD' else (False,)):
            try:ans=s.case(L,lemmas,row,pos)
            except Exception as e:
                return {'source':i,'result':'FAIL','site':j,'row':row,'positive':pos,'error':str(e)[:300],'seconds':time.monotonic()-start}
            ans['rows']=sorted(ans['rows']); ans.pop('trace'); cases.append({'site_index':j,'positive':pos,**ans})
    out=BASE/f'work/novel/scanner_source_{i:02}'
    out.mkdir(exist_ok=True)
    (out/'u212.native.tm').write_bytes(bt.encode(T))
    (out/'runtime_cases.json').write_text(json.dumps(cases))
    return {'source':i,'result':'PASS','cases':len(cases),'seconds':time.monotonic()-start}
if __name__=='__main__':
    with concurrent.futures.ProcessPoolExecutor(max_workers=3) as ex:
        for r in ex.map(check,range(1,7)):
            print(json.dumps(r),flush=True)
