from search_folds import table,abstract,path,compare
from pathlib import Path
import json,time,random,concurrent.futures

P=Path('work/stack/u212.native.tm')
BASE=table(P)
J=json.loads(Path('work/novel/bypass_search.json').read_text())['candidates']

def find(index):
    rec=J[index];T=BASE.copy();p,b=rec['row'];w,d,z=T[p,b];T[p,b]=(w,d,rec['to'])
    seen=abstract(T,5);states=sorted(seen);rng=random.Random(0);found=[]
    # The bypass can strengthen any propagated invariant, so examine every state.
    for q in states:
        if q==0:continue
        patterns=sorted(seen[q]);rng.shuffle(patterns)
        if not patterns:
            found.append({'removed':q,'reason':'unreachable abstract state'});continue
        old=[path(T,q,m,5,63) for m in patterns]
        for r in states:
            if q==r:continue
            matches=[]
            for m,op in zip(patterns,old):
                c=compare(T,q,r,m,5,63,op)
                if c is None:break
                matches.append(c)
            else:
                found.append({'removed':q,'representative':r,'cases':len(patterns),'max_old':max(c[0] for c in matches),'max_new':max(c[1] for c in matches)})
    return {'bypass_index':index,'bypass':rec,'folds':found}

if __name__=='__main__':
    start=time.monotonic();res=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=3) as ex:
        for i,r in enumerate(ex.map(find,range(len(J)))):
            res.append(r)
            if r['folds']:print(json.dumps(r),flush=True)
            elif i%10==0:print('checked',i,'seconds',time.monotonic()-start,flush=True)
    Path('work/novel/refine_bypasses.json').write_text(json.dumps(res,indent=2)+'\n')
    print('done',len(res),'seconds',time.monotonic()-start,flush=True)
