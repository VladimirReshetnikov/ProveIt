Comparison snapshots
====================

comparison_ledger.json maps A through H to the eight original archive names,
exact hashes, source metrics, and compatibility observations. P00..P06 and
P09 correspond to source_00..source_06 and source_09 in that ledger.

Selected README, native/dense tables, source sites, and main report text are
verbatim extracts. Their report.tex files are source evidence and can refer
to other files in the original archives; they are not standalone compilable
reports. The new complete paper is ../paper/report.tex.

The two full archives used for the accepted composition are retained under
../inputs. Other archives are pinned by public URL, Git blob SHA-1, and
SHA-256. Offline replay checks the frozen source/table snapshots and their
ledger identities without downloading those other archives.
