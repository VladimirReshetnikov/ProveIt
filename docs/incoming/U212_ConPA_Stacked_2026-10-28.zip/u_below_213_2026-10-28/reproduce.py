#!/usr/bin/env python3
"""Offline reconstruction and optional fresh universal verification of U212."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PARENT_NAME = 'direct_transfer_U213.zip'
PARENT_PIN = '09e869763555e19d73f1b7900eee7305105ee02219196dcc88bb6854f34d7f29'
BYPASS_PIN = 'a63e88d7b7b82be64d70528f2df68b8543e9f099008f7547e4faf7c2f241ed0c'
PARENT_FOLDER = 'U213_ConPA_2026-10-28'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def verify_manifest():
    names = []
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = (ROOT / name).resolve()
        require(path.is_relative_to(ROOT), 'Unsafe manifest path')
        require(path.is_file() and sha(path) == digest, 'Manifest mismatch: ' + name)
        names.append(name)
    require(len(set(names)) == len(names), 'Repeated manifest name')
    require('reproduce.py' in names and 'paper/report.pdf' in names, 'Incomplete manifest')
    return len(names)


def run(args, optimized=False):
    command = [sys.executable, '-B']
    if optimized:
        command.append('-O')
    command.extend(map(str, args))
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError('Command failed:\n' + ' '.join(command) + '\n' +
                           result.stdout + '\n' + result.stderr)
    return result.stdout


def parent_member(archive, name):
    return archive.read(PARENT_FOLDER + '/' + name)


def audit_saved_runtime(parent_archive):
    summary = read_json(ROOT / 'evidence/runtime.json')
    raw = gzip.decompress((ROOT / 'evidence/runtime_cases.json.gz').read_bytes())
    require(hashlib.sha256(raw).hexdigest() == summary['uncompressed_cases_sha256'],
            'Saved case-record digest')
    cases = json.loads(raw)
    sites = read_json(ROOT / 'machine/sites.json')
    require((ROOT / 'machine/sites.json').read_bytes() ==
            parent_member(parent_archive, 'machine/sites.json'), 'Source changed')
    require((ROOT / 'inputs/base213.native.tm').read_bytes() ==
            parent_member(parent_archive, 'machine/u213.native.tm'), 'Parent table differs')
    expected = [(i, p) for i, row in enumerate(sites)
                for p in ((False, True) if row[1] == 'CD' else (False,))]
    require([(c['site_index'], c['positive']) for c in cases] == expected,
            'Guarded case inventory')
    require(len(cases) == 5084 and len(sites) == 3909, 'Source/case count')
    require(summary['table_sha256'] == sha(ROOT / 'machine/u212.native.tm'),
            'Runtime table pin')
    require(summary['source_sha256'] == sha(ROOT / 'machine/sites.json'),
            'Runtime source pin')
    for field, member in [('engine_sha256', 'code/symbolic_runtime.py'),
                          ('helper_sha256', 'code/independent_runtime.py')]:
        require(hashlib.sha256(parent_member(parent_archive, member)).hexdigest() ==
                summary[field], 'Runtime inference-rule identity')
    mapping = {int(k): int(v) for k, v in json.loads(
        parent_member(parent_archive, 'inputs/legacy_mapping.json')).items()}
    table = {}
    for line in (ROOT / 'machine/u212.native.tm').read_text().splitlines():
        if line and not line.startswith('#'):
            q, bit, write, direction, target = line.split()
            table[int(q), int(bit)] = int(write), direction, int(target)
    states = {q for q, _ in table}
    for q in states | {254}:
        mapping.setdefault(q, q+1000)
    require(len({mapping[q] for q in states | {254}}) == 213, 'Runtime relabeling')
    used = {tuple(row) for case in cases for row in case['rows']}
    for block in summary['blocks']:
        for event in block['trace']:
            used.add(tuple(event[1][:2]))
    require(used == {(mapping[q], b) for q, b in table}, 'Literal row coverage')
    old = json.loads(parent_member(parent_archive, 'evidence/runtime_cases.json'))
    improved = 0
    for before, after in zip(old, cases):
        duration = after['duration']
        require(len(duration) == 13 and duration[0] > 0 and min(duration) >= 0,
                'Nonpositive or malformed primitive duration')
        require(len(after['motion']) == 13 and after['motion'] == before['motion'],
                'Head-motion formula')
        require(all(a >= b and 3*a <= 7*b for a,b in zip(before['duration'], duration)),
                'Primitive time comparison')
        improved += before['duration'] != duration
    require(improved == summary['primitive_duration_formulas_improved'] == 179,
            'Improved-case count')
    require(sum(c['symbolic_steps'] for c in cases) ==
            summary['symbolic_inference_steps'] == 1275761, 'Inference count')
    require(summary['working_states'] == 212 and summary['literal_rows_covered'] == 424,
            'Runtime table census')
    return {'cases': len(cases), 'literal_rows_covered': len(used),
            'inference_steps': summary['symbolic_inference_steps'],
            'scope': 'Saved record and input binding audit; --full reconstructs proofs.'}


def extract_parent(archive, destination):
    for info in archive.infolist():
        target = (destination / info.filename).resolve()
        require(target.is_relative_to(destination.resolve()), 'Unsafe archive member')
    archive.extractall(destination)
    return destination / PARENT_FOLDER


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--parent-full', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.full or args.parent_full:
        require(__debug__ and not sys.flags.optimize,
                'Full symbolic verification requires enabled assertions; do not use -O.')
    started = time.monotonic()
    manifest_count = verify_manifest()
    parent_path = ROOT / 'inputs' / PARENT_NAME
    require(sha(parent_path) == PARENT_PIN, 'Selected parent archive pin')
    require(sha(ROOT / 'inputs/entry_bypass_U213.zip') == BYPASS_PIN, 'Bypass archive pin')
    with tempfile.TemporaryDirectory(prefix='u212-replay-') as td:
        work = Path(td)
        build = work / 'build'
        run([ROOT / 'code/build_candidate.py', '--out', build])
        for name in ('u212.native.tm', 'u212.tm', 'state_map.json'):
            require((build / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
                    'Reconstruction mismatch: ' + name)
        certificate = read_json(build / 'stack212_certificate.json')
        require(certificate == read_json(ROOT / 'evidence/local_certificate.json'),
                'Local certificate differs')
        run([ROOT / 'code/build_candidate.py', '--out', work / 'optimized'],
            optimized=True)
        require(read_json(work / 'optimized/stack212_certificate.json') == certificate,
                'Builder changes under -O')
        command = [
            ROOT / 'code/check_local_independent.py',
            ROOT / 'inputs/base213.native.tm', ROOT / 'machine/u212.native.tm',
            ROOT / 'machine/u212.tm', ROOT / 'machine/state_map.json',
            '--output', work / 'independent.json',
        ]
        run(command)
        independent = read_json(work / 'independent.json')
        require(independent == read_json(ROOT / 'evidence/independent_local.json'),
                'Independent certificate differs')
        command[-1] = work / 'independent_optimized.json'
        run(command, optimized=True)
        require(read_json(command[-1]) == independent, 'Independent checker changes under -O')
        comparison = json.loads(run([ROOT / 'code/verify_comparison.py']))
        run([ROOT / 'code/build_document_data.py', '--check'])
        with zipfile.ZipFile(parent_path) as archive:
            saved = audit_saved_runtime(archive)
            baseline = extract_parent(archive, work / 'parent') if (
                args.full or args.parent_full) else None
        fresh = None
        if args.full:
            print('Rederiving all 5,084 final primitive contracts...', flush=True)
            log = run([ROOT / 'code/verify_candidate_runtime.py',
                       '--table', ROOT / 'machine/u212.native.tm',
                       '--baseline', baseline, '--out', work / 'runtime'])
            fresh = read_json(work / 'runtime/runtime.json')
            old_summary = read_json(ROOT / 'evidence/runtime.json')
            require({k:v for k,v in fresh.items() if k != 'seconds'} ==
                    {k:v for k,v in old_summary.items() if k != 'seconds'},
                    'Fresh runtime summary differs')
            require(gzip.decompress((work / 'runtime/runtime_cases.json.gz').read_bytes()) ==
                    gzip.decompress((ROOT / 'evidence/runtime_cases.json.gz').read_bytes()),
                    'Fresh complete runtime records differ')
        parent = None
        if args.parent_full:
            print('Replaying the selected U213 parent in full...', flush=True)
            run([baseline / 'reproduce.py', '--full', '--report', work / 'parent.json'])
            parent = read_json(work / 'parent.json')
            require(parent['status'] == 'U213_FULL_REPLAY_PASS', 'Parent full replay')
        require(verify_manifest() == manifest_count, 'Release changed during checking')
        result = {
            'status': 'U212_FULL_REPLAY_PASS' if args.full else 'U212_FINITE_REPLAY_PASS',
            'manifest_files': manifest_count, 'working_states': 212, 'literal_rows': 424,
            'native_sha256': sha(ROOT / 'machine/u212.native.tm'),
            'dense_sha256': sha(ROOT / 'machine/u212.tm'),
            'source_sha256': sha(ROOT / 'machine/sites.json'),
            'local_partial_tape_identities': len(certificate['cases']),
            'builder_mutations_rejected': certificate['helper_mutations_rejected'],
            'independent_local_frames': independent['total_local_frames'],
            'independent_mutations_rejected': independent['semantic_mutations_rejected'],
            'startup_steps': independent['startup']['steps'],
            'startup_trace_text_sha256': independent['startup']['trace_text_sha256'],
            'optimized_local_checkers': 'IDENTICAL_RESULTS',
            'comparison': comparison, 'saved_runtime_audit': saved,
            'fresh_final_cases': 5084 if args.full else 0,
            'fresh_parent_cases': 5084 if args.parent_full else 0,
            'parent_status': parent['status'] if parent else None,
            'seconds': round(time.monotonic()-started, 3),
            'scope': ('Literal reconstruction, local whole-tape equivalence, complete '
                      'initialization, source/table comparison, and optional fresh universal '
                      'primitive proofs. Inherited source/logical interpretations remain '
                      'conventional mathematical dependencies; no newly compiled complete '
                      'Lean/Rocq/MM0/PA endpoint certificate.')
        }
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
