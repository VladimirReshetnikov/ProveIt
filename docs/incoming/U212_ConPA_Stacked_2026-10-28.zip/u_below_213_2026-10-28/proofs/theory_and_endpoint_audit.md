# Audit of Theory U and the inherited consistency endpoint

Audit date: 2026-10-28 (client date). This is a mathematical review of the
supplied sources, not a new proof-assistant verification.

## Finding

No mathematical defect was found in the inspected unary-U interpretation,
the U214 role-emitter argument, the source02 source/runtime reduction, or
the source00 interior-bootstrap and protected-stack argument. This finding
does not replace the outstanding task of compiling a complete formal
endpoint for the selected new literal machine.

The strongest useful separation is:

1. A new local literal-table reduction can prove, independently of all
   consistency theory, halting equivalence with an exact supplied U213.
2. The supplied U213-to-Con(PA) calibration is an ordinary mathematical
   chain of proof/run translations, not a kernel-checked endpoint.
3. Composing (1) with that inherited chain gives the PA-provable
   consistency equivalence at the same conventional mathematical proof
   level. It must not be described as inheriting the different K215/ZFC
   formal endpoint.

## Exact source distinctions

The unary theory U is equality-free first-order logic with one binary
relation and the weak-cover schema

    forall a exists b [forall x (x in b -> phi(x)) and
      forall x (Sub(x,a) -> (phi(x) -> x in b))],

where phi has no free variable besides x. In particular the source a is
not permitted as a free matrix parameter. The machine-facing theory W+IR
used by the U213 packets permits arbitrary matrix parameters and adds
global irreflexivity. The native numerical machine calculus proves target
code 1. It is not the separate positive dyadic-code theorem stream and
target 0 in the standalone unary-theory archive.

The consistency route is justified as follows. U is a subtheory of W.
The bit-membership interpretation in PA validates every parameterized W
instance, genuine logical equality if present, and IR. The lower U
interpretation recovers PA. Thus the three theories have mutually
transportable finite refutations. No ambient extensionality or equality
axiom is required in the lower U proof.

## Unary-U lower interpretation

Inspected sources:

- sources/source_08/pa_unary_power_cover/sections/unary_core.tex
- sources/source_08/pa_unary_power_cover/sections/unary_arithmetic.tex
- sources/source_08/pa_unary_power_cover/sections/upper_transport.tex
- sources/source_08/pa_unary_power_cover/sections/positive_interface.tex

The potentially circular part is handled correctly. Numericality is
defined through saturated/transitive linearly ordered member profiles
whose represented intersections have endpoints. Local predecessor and
successor-preservation facts do not presume successor totality.
Parameter-free induction uses a weak cover of the failure predicate at
the alleged counterexample number itself. If no earlier failure exists,
that number's already-existing predecessor suffices. Arbitrary parameters
are internalized in a universally quantified base-and-step premise.

Global comparison and least numerical tuples then follow from this
induction. Given a bounded, invariant numerical-parameter construction,
the first missing tuple is described inside a unary matrix; it is not a
free source parameter. This yields exactly the needed comprehension.
Successors and numerical powers follow only afterward. Saturated
Kuratowski codes, numerical graph comprehension, and deterministic
histories produce addition and multiplication. The history definitions
are fixed formulas before their existence proofs, and the old graph is
bound inside the canonical extension/restriction predicate; no forbidden
free graph parameter is inserted into a filter matrix.

I checked these dependency points and found no circular successor,
extensionality, parameter-scope, or graph-existence assumption. The
primitive-recursive proof translations are described through conventional
uniform proof templates rather than implemented for arbitrary PA proofs.
That is the material formalization boundary.

## Native logical calibration

Inspected sources:

- sources/source_07/U214_ConPA_Reduction_2026-10-28/proofs/role_emitter.tex
- sources/source_07/U214_ConPA_Reduction_2026-10-28/proofs/source198.tex
- sources/source_06/U213_ConU_2026-10-28/proofs/INHERITED_LOGIC_REVIEW.md
- work/audit/u222/u222_consistency_machine/references/theory_bridge_notes.txt
- work/audit/u222/u222_consistency_machine/references/enumerator_proof_notes.txt
- work/audit/u222/u222_consistency_machine/references/exceptional_codes.txt
- work/audit/u222/u222_consistency_machine/references/logic/README.md

The last five files were extracted, without modification, from the pinned
U222 ZIP nested inside source09/baseline/u218/inputs. They expose the
actual inherited dependencies.

The U214 emitter identifies the first selector a with both formula code
and output-variable label. Positive codes have all effective formula
labels smaller than the code; code 0 is a closed truth alias. Therefore
the output variable is fresh in the decoded matrix. The retained gate
c!=a,b separates test from source/output. The case a=b must not be
silently treated as a subset guard: the local a-binder captures the
source, giving an emptiness guard under IR. A false-filter instance
supplies an empty source and a second filter supplies exactly the
required weak cover. Small codes 0 and 1 are explicitly handled.

Completeness quotes a double-negated matrix at code n>1 and chooses
(a,b,c)=(n,0,1), then uses the retained logical renaming templates.
Atomic membership vacuity is preserved by propositional projection from
the bundled axiom. This matters because the equality interpretation
uses two-sided membership indiscernibility and requires the full
vacuity interface. Deleting it or selecting a deterministic fresh test
variable is not justified by these proofs; the packets contain concrete
counterinterpretations to those shortcuts.

The native zero alias and falsity code 1 are intentional. Numeric
identity I(1,1), interpreted as the negation of diagonal membership,
and generalization give IR. Propositional and first-order translations
are inherited generic templates whose premises are checked for the
changed bundle, not an invocation of the K215 final theorem.

The fair enumerator proof is explicit: positive residual candidate
pointers decrease, the fresh candidate counter rises, and compiled
refutations occur at cofinally large candidate codes. The seed-4 cutoff
therefore loses no proof. Soundness maintains theorem-valued current,
cache, and stack entries. Arbitrary retained data is only a completeness
premise, never an unrestricted soundness premise.

## source02: source and runtime reduction

Inspected sources:

- sources/source_02/U213_ConPA_2026-10-28/paper/report.tex
- sources/source_02/U213_ConPA_2026-10-28/code/validate_native.py
- sources/source_02/U213_ConPA_2026-10-28/code/runtime/symbolic_runtime.py
- sources/source_02/U213_ConPA_2026-10-28/code/runtime/independent_runtime.py
- sources/source_02/U213_ConPA_2026-10-28/evidence/u213/runtime.json

The source proof preserves every opcode/operand and every resolved
guarded ordinal successor, not merely the flattened word. This is
sufficient for source bisimulation by step induction. Its whole-tape
checker uses only literal transitions, self-loop traversal by induction
on unary length, and finite-list traversal after proving a generic
single-block schema from the actual table. I inspected the small engine
and its tape normalization identities. No unsound execution shortcut
was found. Its assertion checks remain enabled; its run limits constrain
proof search only. The exact 95,726-step initialization reaches the old
seed-4 root frame. The new table's end-to-end mathematical equivalence
therefore requires this checker soundness, exact source binding, finite
startup, and the retained logical chain.

However, native labels have been reallocated. In source02, native112
implements (0,R,90)/(1,R,89), and native172 implements
(0,R,171)/(1,R,201). Its old112 detour is already absent. The source09
112-deletion recipe cannot be stacked on source02 by copying labels,
even though source02 already has180/1 ->167. This is a concrete reason
to prefer a semantically checked combination over simply adding state
savings reported by different packets.

## source00: interior bootstrap and protected tail

Inspected sources:

- sources/source_00/U213_ConPA_2026-10-28/proofs/startup_suffix.tex
- sources/source_00/U213_ConPA_2026-10-28/proofs/source_transport.tex
- sources/source_00/U213_ConPA_2026-10-28/proofs/command_semantics.tex

The source00 table uses a three-command direct-transfer engine and a
different initializer. Its 48,140-step blank trace reaches an interior
AX frame, not the ordinary seed-4 root. The supplied argument explicitly
accounts for this distinction. A synthetic source entry reaches the
observed frame after141 source steps. Its terminating AX suffix produces
nine explicit theorem heads above the arbitrary tail4, clears the cache,
and begins enumeration at candidate1. The prior cache1 is used as an
arithmetic parameter and is not asserted to be a theorem.

The unsafe tail4 would expose false code1 if popped. The supplied
Cantor-diagonal credit proof is therefore essential. Conservative weights
are transfer=-1, MP=0, AX=10; successful MP's extra truth push is ignored.
The command recurrences decrease their candidate index. The proof shows
that diagonals from s=2 onward have nonnegative relative prefix balance,
while the candidate1 start has maximum initial deficit2. Thus at least
seven of the nine explicit theorem heads remain above the arbitrary
tail. The ghost prefix length is valid despite zero pairing aliases,
because unpair(P(x,y))=(x,y) still holds. I checked the diagonal bounds
and the bootstrap field assignment; no missing startup soundness case
was found.

For a candidate built by a locally proved reduction of this exact table,
this more elaborate bootstrap is inherited unchanged. The report should
state that dependence instead of claiming the candidate starts at the
ordinary seed-4 root.

## Recommended endpoint wording

For an exact new candidate M with a checked local reduction to source00
table A, a precise assertion is:

    The displayed local transition proof establishes, formalizably in PA,
    Halt(M, blank) iff Halt(A, blank). Combining it with the retained
    conventional U213/U214/U218/U222 and unary-U proof translations gives
    PA proves Nonhalt(M, blank) iff Con(U) iff Con(PA).

Then immediately state that the new local proof has independently
executable finite certificates, while no new complete Lean, Rocq, MM0,
or exported PA proof certificate is included. This does not weaken the
mathematical local theorem or confuse it with bounded simulation tests.
