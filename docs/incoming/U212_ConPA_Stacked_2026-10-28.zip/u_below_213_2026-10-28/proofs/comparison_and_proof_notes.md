# Comparison of the eight U213 proposals and the certified stack

The exact source snapshot is ProveIt commit
`6b3145c0bbbf7563bd7bce44c974b4515656a5b0`. The original archive names,
Git blob hashes, SHA-256 hashes, table hashes, source hashes, machine census,
source metrics, and source/control-flow comparisons are in
`comparison_ledger.json`; `compare_proposals.py` reconstructs this ledger.
The labels below refer to that ledger and avoid confusing multiple archives
whose extracted directory names coincide.

| Label | Original archive | Main change | Primitive occurrences / distinct subtrees |
|---|---|---|---|
| A | `U213_ConPA_2026-10-28 (1).zip` | U214 emitter in ST215 direct-transfer source; repaired contextual entry; seven-zero origin detector | 3909 / 197 |
| B | `U213_ConPA_2026-10-28 (2).zip` | Emitter reassociation and reallocation; repair; delete167 by preceding-one reuse of172 | 3928 / 198 |
| C | `U213_ConPA_2026-10-28 (3).zip` | One closed reassociation and decoder reallocation; retained-parent child repair; delete215 | 3928 / 198 |
| D | `U213_ConPA_2026-10-28.zip` | Exchange two implication antecedents, change allocation, retain return helper | 3928 / 198 |
| E | `U213_ConPA_Reduction_2026-10-28 (1).zip` | Six closed rotations, then opposite preceding-bit selector reuse via155 | 3928 / 199 |
| F | `U213_ConPA_Reduction_2026-10-28.zip` | Emitter reassociation and reallocation; repair; delete167 by preceding-one reuse of172 | 3928 / 198 |
| G | `U213_ConU_2026-10-28.zip` | Eight closed rotations, then opposite preceding-bit selector reuse via155 | 3928 / 199 |
| H | `u213_from_u214_2026-10-28.zip` | Unchanged source; bypass180/1, then delete112 under strengthened entry invariant | 3928 / 198 |

All eight tables have 213 working states, 426 binary transition rows,
and a separate halt label. The physical state count is not the source DAG
node count: E and G use 199 source subtrees, one more than ordinary U214,
while still removing a physical state.

## Which ideas are independent?

B and F perform the same final semantic fold with different source
associations and different predecessor labels. Their old state167 reads
the next bit, going to218 on0 and184 on1. They replace it with172, using
the invariant that its predecessor wrote1. This removes precisely the
direct decoder that H needs to bypass172's one-tagged entrance. Applying
the two one-state savings in sequence cannot simply count twice: one
transformation deliberately identifies roles that the other separates.

E and G likewise fold the same pair of semantic decoder roles:
`(0,R,98)/(1,R,218)` and `(0,R,90)/(1,R,218)`. Selector155 distinguishes
their preceding tags and uses helpers85 and150. E calls the pair214/211;
G calls it214/115. Their rotation recipes overlap the same emitter subtree.
They are two presentations of the same kind of saving, not two disjoint
deletions that can be unioned by their numeric state names.

C already repairs180/1 to enter167. Its states112 and172 have meanwhile
been reused for different decoder roles:112 goes to90/89 and172 to171/201.
H's old112 behavior is absent. A patch saying merely "delete112" would
delete a different computation.

D changes the constructor word through a proved antecedent exchange;
its source CFG is not the same raw ordinal CFG as U214. It does not retain
H's112/172 network in the required form. The source count alone therefore
does not establish a transferable local edit.

A is the useful independent partner. Its seven-zero detector and changed
direct-transfer source leave H's local112/172 network intact. The needed
direct decoder survives under native label211 instead of167. The complete
incoming-row census also matches H's premises. Thus H's local proof can be
transported to A by replacing the proof's helper name167 with211.

These observations exclude only naive concatenation of the indicated
certificates. They are not impossibility results for more extensive
reallocation or additional source transformations.

## Exact new212-state machine

Start from A's `machine/u213.native.tm`, SHA-256
`bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7`.
Make exactly these edits:

| Row | Before | After |
|---|---|---|
|180/read1|(1,R,172)|(1,R,211)|
|172/read0|(0,L,112)|(0,L,67)|
|112/read0|(0,R,157)|deleted|
|112/read1|(1,R,209)|deleted|

The resulting table has212 working states and424 rows; its native halt
remains254. Dense labels0 through211 have separate halt212.

* Native SHA-256: `386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4`.
* Dense SHA-256: `c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e`.
* Exact source remains A's source, SHA-256
  `7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00`.

`build_stack212.py` reconstructs both tables, checks all target closures
and the dense relabeling, verifies the four local path identities below,
and rejects12 deliberately corrupted common-helper writes. The proof
certificate is `stack212_certificate.json`. The checks do not use Python
assertions and remain active under `python3 -O`.

## Local theorem independent of the logical calibration

Let A be the supplied213-state table, B the same table after only the180/1
bypass, and C the final212-state table. At a visit to180 scanning1, write
b for the next tape cell, and c for the cell after that when b=0.

| Next bits | Old state path | New state path | Steps A/B |
|---|---|---|---|
|1|180,172,184|180,211,184|2/2|
|00|180,172,112,209,157,67,151,90|180,211,218,90|7/3|
|01|180,172,112,209,157,148,186,86|180,211,218,86|7/3|

Every write preserves the already present tape bit, both paths have the
same head and state at the endpoint, and no unspecified exterior cell is
read. All other retained A/B rows agree. Hence finite positive blocks
translate runs in both directions.

The complete incoming-row list for172 in B is now exactly116/read0,
which writes0 and moves right. Therefore any run starting in state0 enters172
with0 immediately to its left. The only incoming row for112 is172/read0,
which moves left after preserving the current0. At112 both the scanned
cell and the cell on its right are therefore0.

On those two zeros, the old path112,157,67,151 (three steps) and new
path67,151 (one step) have the same entire tape, final head, and state.
Equivalently, start one step earlier at172/read0: the old four-step and
new two-step paths both end at151 at the original head coordinate. This
is the fourth checked opaque-exterior identity. The final table changes
only172/read0 and deletes112's two rows.

Induction on a finite execution trace proves that A and C halt
equivalently from state0 on every common initial tape. This theorem does
not presuppose U's consistency, the source compiler, or a blank-tape
invariant. Coding the finite traces and the local path identities yields
the corresponding PA-provable equivalence. The consistency endpoint for C
is then inherited through A's stated numerical-calculus and U/PA calibration.

For a halting execution, each new block is no longer than its old block.
Using equal-state checkpoints, the ratios are1,7/3, and2. Therefore

`T_C <= T_A <= (7/3) T_C`.

This is a conditional halting-time comparison. It makes no assertion that
the blank machine actually halts, and it is not a computational comparison
between unrelated proposals' full proof-search runs.

## Independent review of A's unusual startup bridge

A reaches a source interior rather than U214's clean seed. This must be
retained explicitly in the new report. The literal startup frame is
native84, head-2, header54, address001100110101010, source ordinal136,
registers `(1,0,13,0,0,1,0,0,1)`, and43 spare registers equal to1.
It arises after48140 literal transitions. The parent's independent run
has confirmed the new212 table has exactly the same complete startup trace.

The supplied all-natural suffix theorem starts at ordinal106 with
`(N,T,W,A,D,H,X,Y,L)=(1,0,4,0,0,1,0,0,1)`. Its141-step source prefix
reaches the observed ordinal136 frame. Crucially this is an interior AX
suffix: it does not execute the ordinary preamble that would generalize
the unsafe cache1. The retained input top is truth0.

With Cantor pairing `P(x,y)=(x+y)(x+y+1)/2+y`, the two residual reads take
`L=P(1,P(0,0))=1` to0, set `a=0` and `b=2`, and leave `c=0`. The gate
therefore discards its computed covering bundle because `c=a`. The normal
scheduler boundary has next candidate1, residual pointer0, zero top/cache,
and nine explicit theorem heads above the opaque numerical tail4:
seven logical axioms, the dominated row at parameters `(0,2,0,0)`, and truth0.
The old cache1 is a parameter of this suffix, not a retained theorem head.

I checked the protected-credit argument in `proofs/startup_suffix.tex`.
The recurrence agrees with the actual scheduler: for unpair(n)=(a,y),
`W(n)=S;R(y)` when a=0, `MP;R(f(y))` when a=1, and
`AX;R(f(f(y)))` otherwise; `R(r)=W(r-1)` for positive r. With weights
S=-1, MP=0, AX=10, the first candidates are S,MP,SS. Starting at
candidate1 therefore incurs debt2. On Cantor diagonal s>=2 the first
s-1 candidates begin withAX. The pullback of nonnegative partial sums
along the right projection gives at least9k credit after its first k AX
candidates; every prefix inside candidate y has balance at least8y+10.
The remaining MP and S candidates leave balance at least7s-9>0. These
bounds use only earlier candidate inequalities, so the diagonal induction
is not circular. Nine heads thus leave a permanent conservative margin7.

The strong compiler also handles arbitrary initial top/stack after a reset
AX. Its padding candidates `P(2,P(z,P(1,R)))` are cofinal, so starting the
ordinary enumeration at1 does not lose completeness. I checked the key
PUSH, DISCARD, axiom-selection, generalization, and ordinary-MP command
counts in the supplied `proofs/compiler.tex`; their stack counts agree
with the stated ten-head AX and direct-transfer contracts. The zero-code
pairing alias is explicitly handled by ghost head lengths and the empty
J(0) compiler case.

No gap was found in that reviewed suffix/credit argument. This review is
an ordinary mathematical inspection within the assistant collaboration;
it is not a new Lean/Rocq/MM0 check. The new local212-state theorem is much
smaller and has a separate exact finite certificate. The full consistency
endpoint continues to rely on A's inherited numerical/theory calibration.
