U212: combining two U213 constructions for Con(PA)
=================================================
Research prepared for Vladimir Reshetnikov -- 28 October 2026.

RESULT
------
machine/u212.tm is a complete deterministic Turing machine with 212 working
states, 424 transition rows, two symbols, one two-way infinite tape, and a
separate halt label. Initialization from the all-zero tape is included.
Working states are 0..211; start state is 0, initial head coordinate is 0,
and halt is 212. Every transition moves exactly one cell L or R.

The candidate combines:
  A. U213_ConPA_2026-10-28 (1).zip
     Direct-transfer source and shortened seven-zero origin detector.
  H. u213_from_u214_2026-10-28.zip
     An entry bypass that strengthens an invariant and permits a deletion.

In A's native labeling, H's required direct decoder is 211, not 167.
The ENTIRE retained-row patch is:

  180/read1: (1,R,172) -> (1,R,211)
  172/read0: (0,L,112) -> (0,L,67)
  Delete both rows of native state 112.

No source instruction or theory axiom is changed in this new step.

MATHEMATICAL SCOPE
------------------
Four universal whole-tape path identities and complete incoming-edge lists
prove, formalizably in PA, that the exact U212 and selected U213 parent halt
equivalently from state 0 on every common initial tape.

Combining this local theorem with the explicitly retained conventional
U213/U214/U218/U222 numerical-calculus and unary-theory calibration gives:

  PA proves: not Halt(U212, blank) <-> Con(U) <-> Con(PA).

The archive contains ordinary mathematical proofs and exact executable
verification. It does not contain a newly compiled Lean, Rocq, MM0, or
exported PA certificate of the complete consistency endpoint. The separate
K215/ZFC endpoint does not certify this changed PA machine.

If both machines halt on a common initial tape, their literal times satisfy:

  T_U212 <= T_parent <= (7/3) T_U212.

This is a conditional time comparison, not a claim that the blank machine
halts. No unconditional consistency, minimum-size, or global priority claim
is made. No 211-state candidate is claimed.

READ FIRST
----------
paper/report.pdf               17-page paper, comparison, proof, full table.
paper/report.tex               Editable main LaTeX source.
proofs/local_reduction.tex      Complete new local mathematical proof.
machine/u212.tm                Primary dense literal table.
machine/u212.native.tm         Identical machine in inherited labels.
machine/state_map.json         Canonical dense/native bijection.
machine/sites.json             Unchanged 3,909-primitive source.
comparison/comparison_ledger.json
                               Exact eight-proposal census and provenance.

REPRODUCE OFFLINE
----------------
Python 3.10+ and its standard library suffice; no network or optimizer.
Exact-byte replay was tested on Linux; use Linux or WSL.
From a fresh extraction:

  python3 -B reproduce.py
  python3 -B reproduce.py --full --report /tmp/u212-replay.json
  python3 -B reproduce.py --full --parent-full --report /tmp/u212-all.json

Default:
  Integrity manifest and exact reconstruction; both independent local
  checks; mutation controls; normal/-O comparison; complete blank startup;
  eight-proposal snapshot census; generated-paper data; saved runtime
  coverage and bindings.

--full:
  Rederives all 5,084 universal primitive contracts from the final table,
  compares every complete result record with the saved records, and checks
  the affine time inequalities against the selected parent.

--parent-full:
  Reruns the selected parent's complete supported checker as well.
  That parent in turn runs finite U214/U218 dependency audits, not every
  ancestor's full universal or proof-assistant build.

Temporary products are removed. Only an explicitly requested report persists.
Choose a report path outside this release so its sealed files stay unchanged.
The symbolic inference engine requires enabled assertions: do not use -O
or PYTHONOPTIMIZE for full checking. The finite local checks separately run
under -O and have identical results.

Full replay time depends on hardware. The standalone final primitive pass
took about 135 seconds in the preparation environment.

PDF REBUILD
-----------
From paper/, with a standard pdfLaTeX installation:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

The source includes ../proofs/local_reduction.tex, results.tex, and
transition_table.tex. Use a separate copy if retaining the original manifest
matters; PDF timestamps and TeX versions can change its digest.

COMPLETED EVIDENCE
------------------
212 working states; 424 rows; exact dense/native renaming.
All 212 states reachable in the transition graph.
Four opaque-exterior local path identities.
128 exhaustive independent radius-three frames.
12 builder and 36 independent helper mutations rejected.
Exact parent/new startup agreement for all 48,140 steps and all tape cells.
5,084 freshly rederived final primitive contracts over arbitrary naturals,
gap, and nonempty finite spare list.
All 424 final literal rows covered.
1,275,761 symbolic inference steps; minimum constant duration 5.
179 primitive duration formulas improve; all obey new <= old <= 7*new/3.
Selected U213 parent's full 5,084-case replay also passed.

Symbolic records use the inherited engine's state-name map. They are records
of universal unary/list induction derivations, not sampled numerical tests.
The full replay reconstructs the proofs; saved records are not a kernel
certificate.

STARTUP DETAIL
--------------
The exact initial frame is an interior AX source frame at ordinal 136,
native state 84, head -2, header 54, address 001100110101010, registers
(N,T,W,A,D,H,X,Y,L)=(1,0,13,0,0,1,0,0,1), and 43 spares all equal to 1.
It has 120 one-cells with complete zero exterior.

The parent's suffix argument and protected-stack credit theorem are retained:
nine theorem heads protect unsafe tail 4; the maximum conservative deficit
from candidate 1 is two. This is not the ordinary U214 seed-4 root.

IDENTITIES
----------
Dense table SHA-256:
c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e

Native table SHA-256:
386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4

Unchanged source SHA-256:
7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00

All inputs were pinned to ProveIt commit:
6b3145c0bbbf7563bd7bce44c974b4515656a5b0

See NOTICE.txt for attribution. research/ contains explicitly bounded
further-search evidence; those scripts assume the original comparison
workspace layout and are not required by the portable release verifier.
