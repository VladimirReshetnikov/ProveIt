#!/usr/bin/env python3
"""Stack source_09's entry bypass on source_00's 213-state machine.

No optimization or search occurs here. Four opaque-exterior path identities,
the complete incoming-edge census, and the exact two-edit/deletion relation
are checked before output is written. All checks survive Python -O.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = ROOT / "inputs/base213.native.tm"
PIN = "bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7"


def require(test, message):
    if not test:
        raise ValueError(message)


def parse(raw):
    table = {}
    for line in raw.decode().splitlines():
        if not line or line.startswith("#"):
            continue
        q, b, w, d, r = line.split()
        require(d in ("L", "R"), "bad direction")
        key = int(q), int(b)
        require(key not in table, "duplicate row")
        table[key] = int(w), -1 if d == "L" else 1, int(r)
    return table


def encode(table):
    return ("#! start 0\n" + "".join(
        f"{q} {b} {w} {'R' if d == 1 else 'L'} {r}\n"
        for (q, b), (w, d, r) in sorted(table.items())
    )).encode()


def incoming(table, q):
    return sorted(k for k, v in table.items() if v[2] == q)


def run_partial(table, state, cells, steps):
    tape = dict(cells)
    head = 0
    trace = []
    for _ in range(steps):
        require(head in tape, "opaque exterior read")
        bit = tape[head]
        trace.append([state, head, bit])
        write, move, target = table[state, bit]
        tape[head] = write
        head += move
        state = target
        require(state != 254, "halt inside matching block")
    return (state, head, tape), trace


def certify(a, b, c):
    require(len(a) == 426, "baseline row count")
    require(set(a) == set(b), "bypass unexpectedly changes domains")
    require({k for k in a if a[k] != b[k]} == {(180, 1)}, "bypass delta")
    require(a[180, 1] == (1, 1, 172), "old entry")
    require(b[180, 1] == (1, 1, 211), "new entry")
    require(incoming(b, 172) == [(116, 0)], "remaining entries to172")
    require(b[116, 0] == (0, 1, 172), "preceding-zero marker")
    require(incoming(b, 112) == [(172, 0)], "entries to112")
    require(b[172, 0] == (0, -1, 112), "two-zero transfer")
    require(set(b) - set(c) == {(112, 0), (112, 1)}, "deleted domain")
    require(not set(c) - set(b), "new rows")
    require({k for k in c if b[k] != c[k]} == {(172, 0)}, "fold delta")
    require(c[172, 0] == (0, -1, 67), "fold destination")
    states = {q for q, _ in c}
    require(len(states) == 212 and len(c) == 424, "candidate size")
    require(set(c) == set(itertools.product(states, [0, 1])), "totality")
    require(all(w in [0, 1] and r in states | {254}
                for w, d, r in c.values()), "symbols and target closure")
    records = []
    # Every unread exterior cell is universally quantified. An accidental
    # read beyond these exact domains makes the checker fail.
    for cells, n, m, end in [
        ({0: 1, 1: 1}, 2, 2, (184, 2)),
        ({0: 1, 1: 0, 2: 0}, 7, 3, (90, 3)),
        ({0: 1, 1: 0, 2: 1}, 7, 3, (86, 3)),
    ]:
        old, old_trace = run_partial(a, 180, cells, n)
        new, new_trace = run_partial(b, 180, cells, m)
        require(old == new and old[:2] == end and old[2] == cells,
                "bypass path identity")
        records.append({"stage": "bypass", "cells": cells,
                        "old_trace": old_trace, "new_trace": new_trace,
                        "endpoint": end, "old_steps": n, "new_steps": m})
    cells = {-1: 0, 0: 0}
    old, old_trace = run_partial(b, 172, cells, 4)
    new, new_trace = run_partial(c, 172, cells, 2)
    require(old == new and old[:2] == (151, 0) and old[2] == cells,
            "two-zero fold identity")
    records.append({"stage": "fold", "cells": cells,
                    "old_trace": old_trace, "new_trace": new_trace,
                    "endpoint": (151, 0), "old_steps": 4, "new_steps": 2})
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    raw = BASE.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == PIN, "baseline pin")
    a = parse(raw)
    b = dict(a)
    b[180, 1] = (1, 1, 211)
    c = dict(b)
    c[172, 0] = (0, -1, 67)
    del c[112, 0], c[112, 1]
    cases = certify(a, b, c)
    mutations_rejected = 0
    # Changing helpers identically in all stages preserves the nominal
    # patch relation. Their rejection exercises path identities themselves.
    used = set()
    for case in cases:
        for q, _, bit in case["old_trace"] + case["new_trace"]:
            used.add((q, bit))
    for row in sorted(used - {(180, 1), (172, 0), (112, 0), (112, 1)}):
        aa, bb, cc = dict(a), dict(b), dict(c)
        for table in [aa, bb, cc]:
            if row in table:
                w, d, r = table[row]
                table[row] = (1 - w, d, r)
        try:
            certify(aa, bb, cc)
        except ValueError:
            mutations_rejected += 1
        else:
            raise ValueError(f"undetected helper mutation {row}")
    mapping = {q: i for i, q in enumerate(sorted({q for q, _ in c}))}
    mapping[254] = 212
    dense = {(mapping[q], bit): (w, d, mapping[r])
             for (q, bit), (w, d, r) in c.items()}
    native_raw, dense_raw = encode(c), encode(dense)
    (out / "u212.native.tm").write_bytes(native_raw)
    (out / "u212.tm").write_bytes(dense_raw)
    (out / "state_map.json").write_text(json.dumps(mapping, indent=2) + "\n")
    result = {
        "status": "PASS", "working_states": 212, "rows": 424,
        "baseline_native_sha256": PIN,
        "native_sha256": hashlib.sha256(native_raw).hexdigest(),
        "dense_sha256": hashlib.sha256(dense_raw).hexdigest(),
        "source_unchanged": "machine/sites.json",
        "cases": cases, "helper_mutations_rejected": mutations_rejected,
        "proof_scope": "Universal local blocks with opaque exteriors and complete incoming-edge invariants; PA formalizable finite-trace induction. No new proof-assistant endpoint."
    }
    (out / "stack212_certificate.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "cases"}, indent=2))


if __name__ == "__main__":
    main()
