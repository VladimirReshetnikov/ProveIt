#!/usr/bin/env python3
"""Independent exact check of the stacked U212 reduction.

Usage:
  python3 check_local212_independent.py PARENT NATIVE DENSE STATE_MAP
      [--startup-reference JSON] [--output JSON]

No builder or inherited simulator is imported. Local tapes are seven-bit
integers; an attempted read outside their radius-three window is rejected.
All checks use explicit exceptions and remain active under Python -O.
The local certificates are universal over their uninspected tape exteriors.
This program is executable mathematical evidence, not a proof-assistant kernel.
"""

import argparse
import hashlib
import json
from pathlib import Path


PARENT_SHA256 = "bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7"
NATIVE_SHA256 = "386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4"
DENSE_SHA256 = "c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e"
STARTUP_TRACE_SHA256 = "41e9a165abae389c3b182ebbf8d8fd1c260d3d36d4f7ebb6d60e235bac40f19a"
HALT = 254


def check(condition, message):
    if not condition:
        raise ValueError(message)


def read_table(path, expected_hash):
    raw = path.read_bytes()
    check(hashlib.sha256(raw).hexdigest() == expected_hash, f"Hash mismatch: {path}")
    result = {}
    for lineno, line in enumerate(raw.decode("ascii").splitlines(), 1):
        if not line.strip() or line.startswith("#"):
            continue
        fields = line.split()
        check(len(fields) == 5, f"Malformed transition at {lineno}")
        state, read, write, direction, target = fields
        state, read, write, target = map(int, (state, read, write, target))
        check(min(state, target) >= 0, "Negative state")
        check(read in (0, 1) and write in (0, 1), "Nonbinary transition")
        check(direction in ("L", "R"), "Invalid direction")
        check((state, read) not in result, "Duplicate transition")
        result[state, read] = write, (-1 if direction == "L" else 1), target
    return result


def table_shape(table, count, halt):
    states = {q for q, _ in table}
    check(len(states) == count and len(table) == 2 * count, "Wrong table size")
    check(0 in states and halt not in states, "Start or halt convention")
    check(all((q, bit) in table for q in states for bit in (0, 1)), "Missing row")
    check({target for _, _, target in table.values()} - states == {halt},
          "Target closure or missing halt")
    reached, pending = {0}, [0]
    while pending:
        q = pending.pop()
        for bit in (0, 1):
            target = table[q, bit][2]
            if target != halt and target not in reached:
                reached.add(target)
                pending.append(target)
    check(reached == states, "Graph-unreachable working state")
    return states


def incoming(table, state):
    return {edge for edge, effect in table.items() if effect[2] == state}


def intermediate_and_invariants(parent, candidate):
    # Define only the first stage; the candidate itself is read independently.
    middle = dict(parent)
    check(parent[180, 1] == (1, 1, 172), "Wrong first-stage parent entry")
    middle[180, 1] = (1, 1, 211)
    check(set(parent) - set(candidate) == {(112, 0), (112, 1)}, "Wrong deletion")
    check(not set(candidate) - set(parent), "Unexpected new row")
    changed = {key for key in candidate if candidate[key] != parent[key]}
    check(changed == {(180, 1), (172, 0)}, "Unexpected transition changes")
    check(candidate[180, 1] == (1, 1, 211), "Wrong bypass")
    check(candidate[172, 0] == (0, -1, 67), "Wrong detour deletion")
    check(incoming(middle, 172) == {(116, 0)}, "Extra entry to tagged state172")
    check(middle[116, 0] == (0, 1, 172), "Missing preceding-zero marker")
    check(incoming(middle, 112) == {(172, 0)}, "Extra entry to deleted state112")
    check(middle[172, 0] == (0, -1, 112), "Missing two-zero entry")
    check(incoming(candidate, 172) == {(116, 0)}, "Candidate tag-entry census")
    check(incoming(candidate, 112) == set(), "Candidate still enters112")
    # The quotient map sends only112 to67. Every other row commutes exactly.
    for (state, bit), (write, move, target) in middle.items():
        if state != 112:
            translated = write, move, (67 if target == 112 else target)
            check(candidate[state, bit] == translated, "Noncommuting ordinary row")
    return middle


def local_run(table, state, mask, steps):
    """Run inside coordinates -3..3, rejecting every outside read."""
    head, seen = 0, set()
    for _ in range(steps):
        check(-3 <= head <= 3, "Attempted read of opaque exterior")
        bit = (mask >> (head + 3)) & 1
        check((state, bit) in table, "Missing local transition")
        seen.add((state, bit))
        write, movement, target = table[state, bit]
        mask = (mask & ~(1 << (head + 3))) | (write << (head + 3))
        head += movement
        state = target
        check(state != HALT, "Halt inside local matching block")
    return (state, head, mask), seen


def local_identities(parent, middle, candidate):
    counts = {"bypass": 0, "fold_at172": 0, "quotient_at112": 0}
    used = set()
    for mask in range(128):
        # The full seven-bit window is compared, including every untouched cell.
        bit0 = (mask >> 3) & 1
        bit1 = (mask >> 4) & 1
        bit2 = (mask >> 5) & 1
        if bit0 == 1:
            old_steps, new_steps = (2, 2) if bit1 else (7, 3)
            end = (184, 2) if bit1 else ((86 if bit2 else 90), 3)
            old, old_used = local_run(parent, 180, mask, old_steps)
            new, new_used = local_run(middle, 180, mask, new_steps)
            check(old == new == (*end, mask), "Bypass identity failed")
            counts["bypass"] += 1
            used.update(old_used | new_used)
        if bit0 == 0 and ((mask >> 2) & 1) == 0:
            old, old_used = local_run(middle, 172, mask, 4)
            new, new_used = local_run(candidate, 172, mask, 2)
            check(old == new == (151, 0, mask), "Fold-at172 identity failed")
            counts["fold_at172"] += 1
            used.update(old_used | new_used)
        if bit0 == 0 and bit1 == 0:
            old, old_used = local_run(middle, 112, mask, 3)
            new, new_used = local_run(candidate, 67, mask, 1)
            check(old == new == (151, 1, mask), "Quotient-at112 identity failed")
            counts["quotient_at112"] += 1
            used.update(old_used | new_used)
    check(counts == {"bypass": 64, "fold_at172": 32, "quotient_at112": 32},
          "Incomplete radius-three frame census")
    return counts, used


def mutation_controls(parent, middle, candidate, used):
    # Alter common helpers in all three tables, so delta checking alone would
    # not detect them. The local semantic comparisons must reject each mutant.
    keys = sorted(used - {(180, 1), (172, 0), (112, 0), (112, 1)})
    rejected = []
    for key in keys:
        for kind in ("write", "direction", "halt_target"):
            copies = [dict(table) for table in (parent, middle, candidate)]
            for table in copies:
                if key in table:
                    write, direction, target = table[key]
                    if kind == "write":
                        write = 1 - write
                    elif kind == "direction":
                        direction = -direction
                    else:
                        target = HALT
                    table[key] = write, direction, target
            try:
                local_identities(*copies)
            except ValueError:
                rejected.append([*key, kind])
            else:
                raise ValueError(f"Undetected semantic mutation: {key}, {kind}")
    # Demonstrate that the local evaluator cannot silently pad the exterior.
    escape = {(0, 0): (0, 1, 0), (0, 1): (1, 1, 0)}
    try:
        local_run(escape, 0, 0, 5)
    except ValueError as error:
        check(str(error) == "Attempted read of opaque exterior", "Wrong escape rejection")
    else:
        raise ValueError("Opaque exterior read was not rejected")
    return rejected


def blank_prefix(table):
    state, head, ones, seen = 0, 0, set(), set()
    trace_digest = hashlib.sha256()
    for tick in range(48140):
        bit = int(head in ones)
        check((state, bit) in table, "Premature blank-run halt")
        write, direction, target = table[state, bit]
        seen.add((state, bit))
        line = f"{tick} {state} {head} {bit} {write} {direction} {target}\n"
        trace_digest.update(line.encode("ascii"))
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head += direction
        state = target
    check((state, head) == (84, -2), "Wrong blank-prefix endpoint")
    check(not seen & {(180, 1), (172, 0), (112, 0), (112, 1)},
          "New local patch unexpectedly visited during initialization")
    check(trace_digest.hexdigest() == STARTUP_TRACE_SHA256, "Changed startup trace")
    return {
        "steps": 48140,
        "state": state,
        "head": head,
        "one_cells": sorted(ones),
        "trace_text_sha256": trace_digest.hexdigest(),
        "used_rows": sorted(seen),
    }


def expected_seed_support():
    logical = (1, 0, 13, 0, 0, 1, 0, 0, 1)
    physical_order = (6, 2, 0, 4, 3, 7, 8, 5, 1)
    physical = [None] * 9
    for value, position in zip(logical, physical_order):
        physical[position] = value
    pc, head, header = "001100110101010", -2, 54
    support = {head - 1, header}
    support.update(head + i for i, bit in enumerate(pc) if bit == "1")
    separator = header + 1
    for value in physical + [1] * 43:
        support.update(range(separator + 1, separator + value + 2))
        separator += value + 2
    check(len(support) == 120, "Seed support construction")
    return sorted(support)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent", type=Path)
    parser.add_argument("native", type=Path)
    parser.add_argument("dense", type=Path)
    parser.add_argument("state_map", type=Path)
    parser.add_argument("--startup-reference", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    parent = read_table(args.parent, PARENT_SHA256)
    candidate = read_table(args.native, NATIVE_SHA256)
    dense = read_table(args.dense, DENSE_SHA256)
    table_shape(parent, 213, HALT)
    states = table_shape(candidate, 212, HALT)
    table_shape(dense, 212, 212)
    mapping = {int(key): value for key, value in json.loads(args.state_map.read_text()).items()}
    expected_map = {q: i for i, q in enumerate(sorted(states))}
    expected_map[HALT] = 212
    check(mapping == expected_map and mapping[0] == 0, "Noncanonical state map")
    renamed = {(mapping[q], bit): (w, d, mapping[z])
               for (q, bit), (w, d, z) in candidate.items()}
    check(renamed == dense, "Dense/native renaming mismatch")
    middle = intermediate_and_invariants(parent, candidate)
    counts, used = local_identities(parent, middle, candidate)
    mutations = mutation_controls(parent, middle, candidate, used)
    old_start, new_start = blank_prefix(parent), blank_prefix(candidate)
    check(old_start == new_start, "Whole startup traces or tapes differ")
    check(new_start["one_cells"] == expected_seed_support(), "Incorrect whole-tape seed")
    if args.startup_reference:
        reference = json.loads(args.startup_reference.read_text())
        check(reference["one_cells"] == new_start["one_cells"], "Archived seed mismatch")
        check(reference["blank_trace_text_sha256"] == new_start["trace_text_sha256"],
              "Archived trace hash mismatch")
    result = {
        "status": "INDEPENDENT_U212_LOCAL_AND_STARTUP_PASS",
        "parent_native_sha256": PARENT_SHA256,
        "candidate_native_sha256": NATIVE_SHA256,
        "candidate_dense_sha256": DENSE_SHA256,
        "working_states": 212,
        "transition_rows": 424,
        "native_halt": HALT,
        "dense_halt": 212,
        "dense_native_bijection": True,
        "all_working_states_graph_reachable": True,
        "complete_incoming_edge_sets": {
            "middle_172": sorted(incoming(middle, 172)),
            "middle_112": sorted(incoming(middle, 112)),
            "candidate_172": sorted(incoming(candidate, 172)),
            "candidate_112": sorted(incoming(candidate, 112)),
        },
        "ordinary_quotient_rows_checked": len(candidate),
        "radius_three_frames": counts,
        "total_local_frames": sum(counts.values()),
        "outside_read_rejection_control": True,
        "semantic_mutations_rejected": len(mutations),
        "semantic_mutations": mutations,
        "startup": new_start,
        "scope": "Local whole-tape identities plus complete incoming-edge invariants; "
                 "fixed blank startup; no source/theory or proof-assistant endpoint claim.",
    }
    output = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output)
    print(output, end="")


if __name__ == "__main__":
    main()
