#!/usr/bin/env python3
"""Rederive every universal primitive contract for a literal candidate table.

The inference rules are imported unchanged from the hash-pinned source00
archive. This driver introduces no new acceleration rule.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--table', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(__debug__ and not sys.flags.optimize, 'Assertions must be enabled')
    baseline = args.baseline.resolve()
    sys.path.insert(0, str(baseline / 'code'))
    import symbolic_runtime as engine
    import source_language
    import build_table

    source = baseline / 'machine/sites.json'
    require(digest(source) ==
            '7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00',
            'Wrong source')
    sites = json.loads(source.read_text())
    source_language.tree(sites)
    graph, count = source_language.graph_arithmetic(sites)
    require(graph == source_language.graph_intervals(sites), 'Source CFG')
    require(count == 5084 and len(sites) == 3909, 'Source count')
    table = build_table.parse(args.table.read_bytes())
    states = {q for q, bit in table}
    build_table.validate(table, len(states))
    mapping = {int(q): int(r) for q, r in json.loads(
        (baseline / 'inputs/legacy_mapping.json').read_text()).items()}
    for q in states | {254}:
        mapping.setdefault(q, q + 1000)
    require(len({mapping[q] for q in states | {254}}) == len(states) + 1,
            'Noninjective runtime naming map')
    require(mapping[84] == 96 and mapping[254] == 254, 'Runtime interface')
    literal = {(mapping[q], bit): (w, d, mapping[r])
               for (q, bit), (w, d, r) in table.items()}
    require(engine.HEADER_BASE == 56, 'Wrong header')
    require(engine.r.PHY == (6, 2, 0, 4, 3, 7, 8, 5, 1), 'Register map')
    started = time.monotonic()
    lemmas, blocks = engine.prove_blocks(literal)
    cases, used = [], set()
    for ordinal, site in enumerate(sites):
        for positive in ((False, True) if site[1] == 'CD' else (False,)):
            answer = engine.case(literal, lemmas, site, positive)
            used.update(answer['rows'])
            answer['rows'] = sorted(answer['rows'])
            answer.pop('trace')
            cases.append({'site_index': ordinal, 'positive': positive, **answer})
        if (ordinal + 1) % 1000 == 0:
            print('Proved', len(cases), 'universal cases', flush=True)
    for block in blocks:
        for event in block['trace']:
            used.add(tuple(event[1][:2]))
    require(used == set(literal), 'Not every literal row is covered')
    old_cases = json.loads((baseline / 'evidence/runtime_cases.json').read_text())
    require(len(old_cases) == len(cases) == count, 'Wrong case count')
    improved = 0
    for old, new in zip(old_cases, cases):
        require((old['site_index'], old['positive']) ==
                (new['site_index'], new['positive']), 'Case order')
        require(old['motion'] == list(new['motion']), 'Different head motion')
        require(all(a >= b for a, b in zip(old['duration'], new['duration'])),
                'Primitive duration increased')
        require(all(7*b >= 3*a for a, b in zip(old['duration'], new['duration'])),
                'Primitive time ratio exceeds 7/3')
        improved += old['duration'] != list(new['duration'])
    args.out.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(cases, separators=(',', ':')) + '\n').encode()
    (args.out / 'runtime_cases.json.gz').write_bytes(gzip.compress(raw, mtime=0))
    summary = {
        'status': 'ALL_UNIVERSAL_PRIMITIVE_CONTRACTS_REDERIVED',
        'working_states': len(states), 'literal_rows': len(table),
        'literal_rows_covered': len(used), 'source_primitives': len(sites),
        'cases': len(cases), 'source_subtrees': 197, 'header_base': 56,
        'decrement_guards': 'Both zero and positive cases',
        'symbolic_inference_steps': sum(c['symbolic_steps'] for c in cases),
        'minimum_duration_constant': min(c['duration'][0] for c in cases),
        'primitive_duration_formulas_improved': improved,
        'primitive_time_ratio': 'new <= old <= (7/3)*new, coefficientwise',
        'table_sha256': digest(args.table), 'source_sha256': digest(source),
        'engine_sha256': digest(Path(engine.__file__)),
        'helper_sha256': digest(Path(engine.r.__file__)),
        'uncompressed_cases_sha256': hashlib.sha256(raw).hexdigest(),
        'blocks': blocks, 'seconds': time.monotonic() - started,
        'scope': ('Arbitrary natural primary registers and gap; arbitrary nonempty '
                  'finite spare list; complete zero exterior. Unary/list induction '
                  'in ordinary Python. No proof-assistant endpoint certificate.')
    }
    (args.out / 'runtime.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k != 'blocks'}, indent=2))


if __name__ == '__main__':
    main()
