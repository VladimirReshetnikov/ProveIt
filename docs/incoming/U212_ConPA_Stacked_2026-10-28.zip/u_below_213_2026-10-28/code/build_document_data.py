#!/usr/bin/env python3
"""Generate the paper's exact table and quantitative result macros."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def documents():
    table = {}
    raw = (ROOT / 'machine/u212.tm').read_bytes()
    for line in raw.decode().splitlines():
        if line and not line.startswith('#'):
            q, b, w, d, r = line.split()
            table[int(q), int(b)] = (int(w), d, int(r))
    if set(table) != {(q, b) for q in range(212) for b in (0, 1)}:
        raise ValueError('Incorrect dense table domain')
    lines = [
        r'\begin{longtable}{rll}',
        r'\toprule State & On symbol 0 & On symbol 1\\',
        r'\midrule\endfirsthead',
        r'\toprule State & On symbol 0 & On symbol 1\\',
        r'\midrule\endhead',
        r'\midrule\multicolumn{3}{r}{Continued on the next page}\\\endfoot',
        r'\bottomrule\endlastfoot',
    ]
    for q in range(212):
        a, b = table[q, 0], table[q, 1]
        lines.append(f'{q} & $({a[0]},{a[1]},{a[2]})$ & '
                     f'$({b[0]},{b[1]},{b[2]})$' + r'\\')
    lines.append(r'\end{longtable}')
    runtime = json.loads((ROOT / 'evidence/runtime.json').read_text())
    metrics = [
        ('RuntimeInferenceCount', runtime['symbolic_inference_steps']),
        ('MinimumDuration', runtime['minimum_duration_constant']),
        ('ImprovedPrimitiveCount', runtime['primitive_duration_formulas_improved']),
    ]
    macros = '\n'.join('\\newcommand{\\' + name + '}{' + f'{value:,}' + '}'
                       for name, value in metrics) + '\n'
    return {'transition_table.tex': '\n'.join(lines) + '\n', 'results.tex': macros}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    for name, text in documents().items():
        path = ROOT / 'paper' / name
        if args.check:
            if path.read_text() != text:
                raise ValueError('Stale generated document: ' + name)
        else:
            path.write_text(text)
    print('Exact table and result macros ' + ('checked.' if args.check else 'generated.'))


if __name__ == '__main__':
    main()
