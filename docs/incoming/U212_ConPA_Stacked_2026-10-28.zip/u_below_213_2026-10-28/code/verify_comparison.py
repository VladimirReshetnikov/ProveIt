#!/usr/bin/env python3
"""Recheck all eight frozen source/table snapshots against the comparison ledger.

The two full input archives are checked by reproduce.py. The other archives'
published origins are recorded, not downloaded during this offline check.
"""
from functools import lru_cache
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table(path):
    result = {}
    for line in path.read_text().splitlines():
        if line and not line.startswith('#'):
            q, b, w, d, r = line.split()
            key = int(q), int(b)
            require(key not in result, 'Duplicate row')
            result[key] = int(w), d, int(r)
    return result


def metrics(rows):
    leaves = {p: (op, arg) for p, op, arg in rows}
    seen = set()

    def rec(prefix):
        node = leaves[prefix] if prefix in leaves else (rec(prefix+'0'), rec(prefix+'1'))
        seen.add(node)
        return node

    rec('')
    return {
        'primitive_occurrences': len(rows), 'distinct_subtrees': len(seen),
        'maximum_address_length': max(len(p) for p, _, _ in rows),
        'maximum_consecutive_zeros': max(len(run) for p, _, _ in rows
                                          for run in p.split('1')),
        'guarded_primitive_cases': len(rows) + sum(op == 'CD' for _, op, _ in rows)
    }


def cfg(rows):
    intervals = {}
    for i, (path, _, _) in enumerate(rows):
        for length in range(len(path) + 1):
            prefix = path[:length]
            intervals[prefix] = (intervals.get(prefix, (i,))[0], i+1)
    output = []
    for i, (path, op, arg) in enumerate(rows):
        if op == 'CI':
            targets = [i+1]
        elif op == 'CH':
            targets = []
        else:
            bit = '1' if op == 'CC' else '0'
            depth = 1 if op == 'CD' else arg
            positions = [j for j, value in enumerate(path) if value == bit]
            ancestor = path[:positions[-depth]]
            target = intervals[ancestor][0 if op == 'CC' else 1]
            targets = [target, i+1] if op == 'CD' else [target]
        output.append([op, arg, targets])
    return output


def main():
    ledger = json.loads((ROOT / 'comparison/comparison_ledger.json').read_text())
    manifest = json.loads((ROOT / 'comparison/source_manifest.json').read_text())
    require(ledger['commit'] == manifest['commit'], 'Repository snapshot mismatch')
    baseline_table = table(ROOT / 'inputs/u214.native.tm')
    baseline_source = json.loads((ROOT / 'inputs/u214.sites.json').read_text())
    baseline_cfg = cfg(baseline_source)
    for entry in ledger['proposals']:
        index = int(entry['source_directory'].split('_')[-1])
        folder = ROOT / 'comparison' / f'P{index:02d}'
        origin = manifest['files'][index]
        require(entry['original_archive_name'] == origin['name'], 'Archive name')
        require(entry['archive_git_blob_sha1'] == origin['sha'], 'Archive blob hash')
        for name, field in [('u213.native.tm', 'native_table_sha256'),
                            ('u213.tm', 'dense_table_sha256'),
                            ('sites.json', 'source_sha256')]:
            require(sha(folder / name) == entry[field], 'Snapshot digest: '+name)
        current = table(folder / 'u213.native.tm')
        rows = json.loads((folder / 'sites.json').read_text())
        states = {q for q, _ in current}
        require(len(states) == entry['working_states'] == 213, 'State count')
        require(len(current) == entry['rows'] == 426, 'Row count')
        require(set(current) == {(q,b) for q in states for b in (0,1)}, 'Totality')
        require(all(r in states | {254} for w,d,r in current.values()), 'Targets')
        require(metrics(rows) == entry['source_metrics'], 'Source metrics')
        same_word = [r[1:] for r in rows] == [r[1:] for r in baseline_source]
        require(same_word == entry['same_primitive_word_as_U214'], 'Primitive word')
        require((cfg(rows) == baseline_cfg) == entry['same_ordinal_guarded_CFG_as_U214'],
                'Ordinal control graph')
        if same_word:
            changes = sum(a[0] != b[0] for a,b in zip(rows, baseline_source))
            require(changes == entry['changed_addresses_as_U214'], 'Address count')
        difference = sum(current[k] != baseline_table[k]
                         for k in current.keys() & baseline_table.keys())
        require(difference == entry['retained_row_changes_from_U214'], 'Table delta')
        helpers = [q for q in sorted(states) if current[q,0] == (0,'R',218)
                   and current[q,1] == (1,'R',184)]
        require(helpers == entry['direct_bypass_helpers'], 'Bypass helper roles')
    print(json.dumps({'status':'EIGHT_COMPARISON_SNAPSHOTS_VERIFIED',
                      'proposals':len(ledger['proposals']), 'commit':ledger['commit']}))


if __name__ == '__main__':
    main()
