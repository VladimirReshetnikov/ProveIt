# Ratio asymptotics for ascent sequences avoiding 000

Mathematical sequel and reproducibility archive, 2 October 2026.

## Main results

For A202058, set T = 3*pi^2/8, mu = 8/(3*pi^2), and c_n = a_n*T^n/n!.
The report proves:

- a_(n+1)/((n+1)*a_n) = mu + O(n^(-1/4)*(log n)^(3/4))
- -C*sqrt(n)*(log n)^(3/2) <= log c_n <= C'*(log n)^2
- If N_a(y) is the first n with log a_n >= y and x = y/W(y/(e*T)), then
  x - O(log x) <= N_a(y) <= x + O(sqrt(x*log x))

The ratio limit already follows from the earlier root estimate and the exact slow-decrease inequality. The new lower enclosure improves the rate. The full individual statement log c_n ~ (2/3)*(log n)^2, eventual normalized log-concavity, a full equivalent and an amplitude remain open. No effective values of the asymptotic constants are claimed.

## Contents

- `a202058-ratio.pdf`: the 14-page sequel
- `a202058-ratio.tex`: editable, standalone LaTeX source
- `prior/`: unchanged PDF and TeX of the preceding research report
- `build.sh`: rebuilds the sequel with pdfLaTeX
- `replay.sh`: standard-library exact checks and optional complete finite scans
- `scripts/`: portable Python 3 verification programs
- `results/`: frozen exact outputs and finite-domain metadata
- `PROVENANCE.md`: source attribution and unchanged predecessor fingerprints
- `SHA256SUMS`: hashes of all frozen package files except the manifest itself

No third-party full paper, private audit, intermediate image or working correspondence is included.

## Replay without TeX

Extract the ZIP, enter its `a202058-ratio-report` directory, and run:

    bash replay.sh core

Python 3.9 or newer and Bash are sufficient; no external Python packages, network access or credentials are needed. Executable permissions are not required. The command first verifies the frozen manifest, then checks:

- 15,625 exact state-transition identities for H = s + 2u <= 50
- 21 exact forward moment identities and root counts through a_20
- agreement of the two frozen root arrays through a_180
- factorial-normalized root log-concavity through center index 179
- 45 exact coefficients, through degree 14 at three starting states, of the tilted square identity
- the independently memoized reachable-state childwise counterexample

The square identity is a polynomial identity with signed coefficients; the script does not assert coefficientwise positivity.

To regenerate the full scans, run:

    bash replay.sh full

This also checks both candidate statewise log-concavity inequalities on all valid states with 1 <= r <= 179 and H+r+1 <= 200, 48,510,450 inequalities per scan. Both regenerated root arrays and both violation lists must match the frozen results. The initial verification took about one minute per scan in the validation environment; performance varies. These scans provide finite evidence only and do not prove an infinite or asymptotic claim.

Generated replay output is separate from frozen results, under `build/replay`. Set `A202058_REPLAY_OUT` to an absolute path to use another destination.

## Rebuild the PDF

Run:

    bash build.sh

This needs a standard pdfLaTeX installation with article, geometry, fontenc, lmodern, microtype, amsmath, amssymb, amsthm, mathtools, enumitem, booktabs and hyperref. The build script uses three passes and fails if cross-references do not stabilize. It places intermediate files under `build/tex` and the finished PDF at the package root. It accommodates installations that require a writable local format cache.

The fixed source date is 2 October 2026 UTC. Identical TeX engine and package versions produce a deterministic PDF; different TeX distributions may produce a different PDF hash without changing the mathematics. For a fresh integrity check after a different rebuild, keep or re-extract the original frozen package rather than rewriting its manifest.

## Mathematical verification boundary

The analytic proof, rather than finite computation, establishes the ratio theorem and improved enclosures. Exact tests check implementations and concrete identities. Independent analytical review checked the proof and its expanded characteristic inputs; this is not a formal proof-assistant certificate or a claim of exhaustive worldwide novelty.

The predecessor's statement that the ratio limit was open is preserved in its unchanged PDF and TeX. The sequel supersedes that statement. Its full pointwise logarithmic-square question remains open in both reports.
