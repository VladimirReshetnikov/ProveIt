# Sharp Depth Reduction at the Critical Degree

**Optimal classicalization, sparse phase lists, and stability in Gowers-type inverse arguments**  
Research manuscript, 7 October 2026.

## Main result

Let p be prime, a >= 1, and d = 1 + a(p-1). For a function on F_p^n, let
C_{d,a} be its maximum absolute normalized correlation with a circle-valued
polynomial of additive degree at most d and depth at most a. The article proves

    c_{p,a} C_{d,a}(f) <= C_{d,a-1}(f) <= C_{d,a}(f),
    c_{p,a} = sin(pi/p^a) / (p sin(pi/p^{a+1})).

The first constant is optimal in every positive dimension. The same transfer
holds under any probability measure and uses an explicit list of p candidates.
No smaller list fixed before the input function is seen admits any positive
uniform transfer factor. All phase-endpoint extremizers are classified.

Further results include a sharp atomic norm, a diagonal score identity,
quantitative stability with the optimal square-root exponent, simultaneous
aggregate-energy transfer, and a one-pass selection algorithm.

At a = 1 the candidates are classical degree-p phases. The conversion constant
improves the p^(-1/2) factor in Section 3 of Berger–Sah–Sawhney–Tidor (2022),
strictly for odd p. Their qualitative inverse theorem is prior work. The
article does not improve the inverse theorem's input dependence on the Gowers
norm or establish a new global Szemerédi bound.

## Contents

- `article.tex`, `article.pdf`: self-contained article, proofs, references,
  examples, and twelve proposed further research questions.
- `code/depth_reduction.py`: standard-library selector and phase-residue output.
- `code/verify.py`: exact finite-algebra checks and numerical diagnostics.
- `data/verification.json`: actual output of the archived deterministic run.
- `FORMALIZATION.md`: suggested definitions, dependency order, and proof obligations.
- `SOURCE_AUDIT.md`: source provenance, comparison with the repository, and limits.
- `REVIEW_NOTES.md`: focused mathematical audit and verification distinctions.
- `Makefile`, `requirements-checks.txt`: reproduction helpers.
- `SHA256SUMS`: checksums of the delivered files, excluding the checksum file itself.

## Reproduction

From this directory:

```sh
python code/depth_reduction.py
python code/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Or use `make verify` and `make pdf`. The manuscript's references are embedded in
`article.tex`; no external bibliography or image files are required.

The selector needs Python 3.10 or later and the standard library. SymPy is
optional for the verifier's symbolic cyclotomic checks:

```sh
python -m pip install -r requirements-checks.txt
```

Without SymPy, the verifier explicitly records those checks as skipped. The
archived run did execute them. The seed is 20261007. Do not run the verifier
with `python -O`, since it uses assertions as test conditions.

The numerical code uses ordinary double precision, not interval arithmetic or
arbitrary-precision roots of unity. Extremely large moduli and extreme input
scales require a high-precision implementation; rounding-level differences
between tied candidate scores are expected.

## Selector example

```python
import sys
sys.path.insert(0, "code")
from depth_reduction import digit_phase, reduce_samples

p, a = 3, 1
f = digit_phase(p, a)
# A residue r means P(x) = r / p**(a+1) modulo 1.
result = reduce_samples(((r, f[r], 1.0) for r in range(p)), p, a)
print(result.theoretical_factor)          # 0.844029628745985...
print(abs(result.original_correlation)) # 1.0
print(abs(result.selected_correlation)) # 0.844029628745985...
# The returned phase residue now has denominator p**a.
print([result.phase_residue(r) for r in range(p)])
```

The selector assumes the supplied phase has already been normalized by
subtracting its value at the origin. Its degree hypothesis is a mathematical
precondition, not a numerical certification. The pointwise score identity
works even for arbitrary residues, but those residues need not produce
polynomial candidates.

## Repository integration and status

Suggested new directory:

    Combinatorics/Ramsey/Research/GowersSzemeredi/sharp-depth-reduction/

The audited formal interface is pinned to commit
`b9760ed931282087ee57cb1ffb66dc66e40ee47b`.
No files were committed to the repository and no formalization ledger was
changed. This is a separate research contribution, not a replacement for
`proposition_17_2` under that predicate's different hypotheses.

The proofs are written out, but the manuscript is unrefereed and no new theorem
has been Lean-kernel checked. The computational checks are not substitutes for
proof. Publication priority has not been established by the limited source
audit. The author field deliberately does not assign this draft to the user.
