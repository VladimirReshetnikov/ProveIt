# No Ghost Wires
## Loop-Exact Quartic Certificates for Interaction Combinators

Research draft prepared for Vladimir Reshetnikov, October 2, 2026.

**Read `article.pdf` first.** `article.tex` is its complete, self-contained LaTeX
source. No external figures or bibliography database are required.

## Main result

For each externally specified, finite, syntactically valid lifetime schedule of
Lafont's interaction combinators, the exporter constructs quadratic integer
residuals. Their sum of squares has total degree at most four, counting both
endpoint parameters and witnesses. For fixed natural endpoint data, it has
exactly one natural witness if the scheduled computation has the exact stated
endpoint, including port-free cyclic wires, and no witness otherwise.

The reusable core is a unique-witness permutation-orbit certificate and a
path/cycle dictionary for the product of two involutions. All six ordered-port
rules are implemented. This resolves the **finite-horizon** version of the
repository's topology-aware wiring-compiler gap. It is not a fixed-arity
universal equation or a resolution of finite-fold MRDP. Historical priority
for the arithmetic formulation has not been established. The new proofs are
not Lean-formalized.

## Files

- `article.pdf`, `article.tex`: full article, proofs, exact resource ledger,
  worked examples, implementation account, and eight research directions.
- `code/loop_exact.py`: net semantics, rule templates, sparse integer polynomial
  type, parametric scheduled compiler, and witness generation.
- `code/verify.py`: exact finite checks; regenerates the data files below.
- `code/check_export.py`: independently evaluates the exported JSON polynomial
  without importing the compiler or its polynomial type.
- `data/quartic_A_schedule.json`: all 169 quadratic residuals defining the
  worked-example quartic, with 68 endpoint parameters and 126 witnesses.
- `data/witness_A.json`: complete endpoint-and-witness assignment.
- `data/endpoints.json`: the repository's two distinguishing nets and target.
- `data/verification.json`, `data/verification.txt`: finite test receipts,
  algorithm comparison, example statistics, periodic net, and source-code hashes.
- `CLAIMS.md`: mathematical claims and limits.
- `PROVENANCE.md`: repository revision, sources inspected, and attribution.
- `build.sh`: three-pass PDF build.

## Run the checks

Python 3.10 or newer is sufficient; all Python code uses only the standard
library. Run from the extracted directory, without Python's `-O` option (the
test suite intentionally uses assertions):

```sh
python3 code/verify.py
python3 code/check_export.py
```

The first command regenerates local data and receipts; it does not write to
ProveIt, access the network, or mutate an external repository. Runtime in the
authoring container was approximately four seconds, not a performance guarantee.
The second command checks the saved JSON directly. Its expected output is:

```text
PASS: 68 parameters, 126 witnesses, 169 residuals, energy 0
```

The test run covers 46,234 permutations, 81,393 matching/involution gluing
instances, 412 local contexts spanning all six rules, all 10,395 closed
four-delta matchings, the repository's distinguishing example, and a four-step
net that repeats up to renaming. These checks support but do not replace the
unbounded mathematical proofs in the article.

## Build the article

A TeX Live installation with pdfLaTeX, New PX, AMS packages, TikZ, microtype,
listings, fancyhdr, hyperref, and cleveref is required. These are ordinary TeX
packages; no font files are included in this archive.

```sh
sh build.sh
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times, allowing the two-page contents table and references to settle.

## Calling the compiler

```python
import sys
sys.path.insert(0, "code")
from loop_exact import Net, compile_schedule, obstruction_examples

initial, other = obstruction_examples()
target = Net({}, (), 2)  # No agents, but exactly two cyclic wires.
compiled = compile_schedule(initial.cells, (), ((0, 1), (2, 3)))
assignment = compiled.witness(initial, target)
assert compiled.system.energy(assignment) == 0
assert len(compiled.system.variables) == 126
assert len(compiled.system.residuals) == 169
```

`compile_schedule` reads types, free-port labels, and the lifetime schedule,
not either endpoint matching. Witness construction is a separate operation.
Passing the other distinguishing net to `compiled.witness` raises `ValueError`,
since the second scheduled active pair is absent. The theorem, not that one
failed witness-construction call, establishes nonexistence of all alternative
natural witnesses.

The implementation exports fixed schedules. The finite disjunction over
schedules and the separately quadratic variant are proved in the article but
are not implemented as additional exporters.
