# Non-holonomicity of 3AP-Free Permutation Counts

**Finite-window rigidity, arithmetic sections, and stable obstructions to polynomial recurrences**

Research article prepared for Vladimir Reshetnikov, 29 September 2026.

## Main results

Let theta(n) count permutations of {1,...,n} with no three-term arithmetic progression as a subsequence, in either direction (OEIS A003407). The article proves:

1. `theta(n)` is not P-recursive over the complex numbers. Its ordinary and exponential generating functions are not D-finite.
2. Every arithmetic section `theta(q*n+r)`, for integers `q >= 1`, `r >= 0`, is non-P-recursive.
3. No eventually positive integer P-recursive sequence can satisfy `log v(n) = d log theta(q*n+r) + o(n)` for any real `d > 0`. A version for rational coefficients requires an exponential bound on their common denominators.
4. Positive polynomial expressions in n and finitely many fixed shifts of one arithmetic section are non-P-recursive whenever they depend on at least one count. This includes positive powers, products, and positive polynomially weighted sums. Rounded real powers are covered too.

The article also gives a general logarithmic-profile obstruction, a result for perturbed linear sampling, and a leading-Nilsson-layer obstruction. It proposes nine further research topics and a staged formalization plan.

## What the proof uses

A polynomial recurrence for these exponentially bounded integer coefficients would make their generating function a G-function. Published arithmetic regularity theorems then supply a nonzero leading Nilsson layer. An elementary Vandermonde argument shows that the maximum in some fixed-length coefficient window has a single exponential growth rate. Deleting the largest permutation entry gives

    theta(n+j) <= (n+j)^j theta(n),

so theta(n) itself would have that rate. This contradicts Boon Suan Ho's published 2026 growth-nonconvergence theorem.

Nonconvergence of nth roots alone is not enough: the article explicitly gives a positive integer sequence with rational generating function and two different subsequential root limits. The local-growth condition and finite-window noncancellation are essential steps.

## Status and novelty boundary

This is an AI-assisted, unrefereed mathematical article, not a Lean or Rocq formalization. The new application was not found in the primary sources and repository material inspected. Exhaustive priority is not certified.

The article continues the non-D-finiteness issue left outside the conclusions of the repository's report `a003407-dyadic-scaling-rigidity`. It does not claim novelty for Ho's nonconvergence theorem, G-function regularity, or the continuous periodic-profile construction. No repository files were modified.

Natural boundaries, differential transcendence, monotonicity, and sharper profile regularity are not proved here. See `SOURCE_AND_PROOF_AUDIT.md` for exact dependencies and verification limits.

## Package contents

- `article.tex`: standalone source, including the bibliography; no external figures or bibliography database are needed.
- `article.pdf`: compiled article.
- `build.sh`: working-directory-independent pdfLaTeX build script.
- `code/verify.py`: exact standard-library Python verifier.
- `code/test_verify.py`: independent unit tests for enumeration, the integer determinant implementation, and input boundaries.
- `data/verification.json`: output of the full executed verification through n=32.
- `data/unit-tests.txt`: recorded unit-test output.
- `SOURCE_AND_PROOF_AUDIT.md`: source, novelty, and claim-status ledger.

## Rebuild the PDF

A standard TeX Live installation with pdfLaTeX, Latin Modern, AMS packages, microtype, booktabs, hyperref, bookmark, and xurl suffices. From the package directory:

    sh build.sh

On Windows, run the following command three times in that directory:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex

The three passes resolve the contents and cross-references. Rebuilding creates ordinary LaTeX auxiliary files.

## Reproduce the exact checks

Python 3.10 or later; no third-party packages or network access are required.

    python3 code/verify.py
    python3 -m unittest discover -s code -p 'test_*.py' -v

The full verifier recomputes all counts through n=32 by a subset-state dynamic program and compares them with direct permutation enumeration through n=8. In the construction environment it took about eleven seconds; this is not a performance guarantee. A shorter run is:

    python3 code/verify.py --max-n 12 --brute-n 7 --output data/quick-check.json

By default the full run overwrites `data/verification.json`. Use `--output` to retain the delivered record. Timings in a regenerated file will differ.

## Computational trust boundary

The counts at n=64 and n=75 are published inputs, not independently recomputed here. The verifier checks the exact integer comparison

    (2*theta(64))^75 > (21*theta(75))^64

and two rational root brackets. Diagnostic decimals are not used as proof.

The finite nonsingular recurrence matrices exclude only their specified order/degree rectangles on the specified rows. They are not the proof of non-P-recursiveness. The analytic argument rules out all orders, degrees, and eventual starting indices.
