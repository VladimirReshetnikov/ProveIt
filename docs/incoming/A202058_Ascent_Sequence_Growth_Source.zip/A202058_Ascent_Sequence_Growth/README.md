# The exponential growth constant for 000 avoiding ascent sequences

This package contains a self-contained mathematical report for OEIS A202058, its editable LaTeX source, and reproducible coefficient checks.

## Main result

The report proves

lim (c_n / n!)^(1/n) = 8 / (3 pi^2).

The report also proves c_(n+1)/((n+1)c_n) tends to the same constant and gives exponentially concentrated singleton, distinct-value and ascent proportions. The proof uses the published exact compact-state model, an elementary finite positive-matrix upper bound, and a constructive Eulerian-block lower bound. The Lambert inverse consequence uses the argument mu*Y/e, where Y=log y. The logarithmic-square subexponential correction is explicitly conjectural.

## Files

- `article.pdf`: the complete report
- `article.tex` and the section `.tex` files: editable source
- `article_standalone.tex`: the same report with all section inputs expanded
- `checks/compute_exact.cpp`: positive GMP-integer enumeration
- `checks/exact_coefficients_395.txt`: exact coefficients for n=0..395
- `checks/oeis_b202058.txt`: downloaded Conway comparison data for n=0..176
- `checks/compute_distribution.cpp`: normalized floating diagnostic enumeration
- `checks/normalized_transfer_cut120.txt` and `checks/normalized_transfer_cut200.txt`: diagnostic runs through n=1200
- `checks/verify.py`: exact-data and independent small-word checks
- `checks/test_verify.py`: fail-closed parser and verifier regression tests
- `PROVENANCE.json`: source URLs, checks and file hashes

## Build the PDF

A standard TeX Live installation with amsmath, amsthm, mathtools, lmodern, microtype, geometry, hyperref, xurl and booktabs can compile `article.tex` with pdfLaTeX. Run it three times to settle cross-references and contents. The supplied `build_local.sh` additionally supports a local format/font-map setup used for the verified build. The standalone source requires no section files.

## Replay the exact checks

Requirements: C++17 compiler, GMP C++ development library, and Python 3. No network access is needed for replay.

Run `./run_checks.sh 176` to rebuild the whole published OEIS range and execute the checks. Use `./run_checks.sh 395` to rebuild the longer exact table. The longer run uses substantially more time and memory. The script writes temporary compiler output under `checks/build`. It accepts maximum indices from 1 through 395, passes the chosen maximum explicitly to the verifier, and requires exactly one exact row for every index from 0 through that maximum. Duplicate, missing, malformed, negative or noninteger entries are rejected. The archived numerical tables must have exactly one row for each index 1 through 1200, with finite entries and positive ratios. All acceptance checks use explicit exceptions, so Python optimization cannot disable them. Regression tests exercise empty, truncated, gapped, duplicate, malformed and incorrect input in normal and optimized (`-O`) Python; `run_checks.sh` runs these tests automatically.

## Numerical diagnostics

The floating program accepts a maximum n and a state-group mass cutoff. The recorded runs used cutoffs 1e-120 and 1e-200. Both produced identical displayed 20-digit ratios through n=1200 in the recorded environment. Long-double arithmetic is platform-dependent; this comparison is not an interval certificate. A cutoff as large as 1e-30 is inadequate at later levels because rare states can grow strongly in subsequent extensions.

The exact growth proof does not depend on the numerical diagnostics. A coefficient equivalent, amplitude, and logarithmic-square correction require further work.

## Sources and scope

Primary sources are the final 2022 paper by Conway, Conway, Elvey Price and Guttmann (DOI 10.37236/11266) and OEIS A202058. The report distinguishes its proved statements from its formal calculations. The bibliographic search was bounded and makes no exhaustive priority claim. No external publication or repository submission is part of this package.
