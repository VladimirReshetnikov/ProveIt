# A 218-state blank-tape candidate for Con(ZFC)

This package constructs a deterministic binary, single-tape Turing machine
with **218 working states**, a separate halt state, and **436 transitions**.
It starts in state 0 at cell 0 on an entirely zero, two-way infinite tape.
Its ordinary mathematical proof, combined with the pinned ProveIt K219
calculus-to-ZFC calibration, is formalizable in ZFC and establishes

\[
\neg\operatorname{Halts}_{\mathrm{blank}}(M_{218})
\quad\Longleftrightarrow\quad\operatorname{Con}(\mathrm{ZFC}).
\]

Read **k218_dominated_rho8.pdf** for the construction and proof.
The matching **k218_dominated_rho8.tex** includes the complete transition
table and all new logical/source arguments. The final theorem is an
ordinary mathematical proof with executable certificates; **no newly
compiled exact-K218 Lean/Rocq endpoint or internal PA equivalence is
claimed**. This matches the ordinary-proof level of the accepted K219
construction, whose inherited dependency is identified precisely.

## The breakthrough

Write \(I(a,b)=4P(a,b)\), where
\(P(a,b)=(a+b)(a+b+1)/2+b\). The inherited fourth-parameter row is

\[
L(A,B,C,U)=((C\to U)\to A)\to((A\to C)\to(B\to C)).
\]

Restricting it to the **numerical inequality \(U\le A\)** preserves every
derivable natural-number code, not just consistency. The decisive new
fragment puts \(U\) three implication levels inside \(A\). It closes the
previous cd59 gap; the full 3,728-node finite certificate derives the
unrestricted row. The native zero alias \(I(0,0)=0\) and arbitrary junk
codes are covered.

The selected implementation preserves the old common field and all
non-AX source addresses. AX reads wire fields \((c,z,y,x)\) and uses

\[
U=D+z,\quad A=U+x,\quad B=H+y,\quad C=c.
\]

It generalizes the cached theorem with binder \(U\), places \(U\) in the
partially built row, and only then reads the increment making \(A\).
This permits new subtree sharing while keeping the successful bootstrap.

## Exact machine identities

| Artifact | SHA-256 |
|---|---|
| binary/machine/k218.native.tm | 9c8505bf3731212192b83ee61dbc569085b4675ae9e0539843ae57d43ad9e886 |
| binary/machine/k218.compact.tm | 60cd61b3972bf4854be1e14327f873bdd75a6a40ee022ec778898b4d29399f76 |
| source/sites218.json | 264fba90229974a53c2c5c943cf5fe8924327b6bbc31bd47e64d7f5c670b7495 |
| Full logical certificate | 3cf18a5fe9f187b50b79d97b84535ce9bf776305728b0cdfe17285e94f028452 |

The compact table uses working labels 0–217 and halt 218. It is a
bijection of the native table, whose halt label is 254. Native label
400 does not increase the number of distinct working states.

## Verified results

| Check | Result |
|---|---|
| Finite restricted-to-unrestricted axiom proof | 3,728 proof nodes; 5,160 term nodes; two independent forward checks |
| Source construction | Three closed splices of the pinned baseline |
| Source semantics | Exact guarded ordinal CFG equality; all-register primitive-step bisimulation |
| Final source size | 203 DAG nodes; 4,751 leaves; 23 primitive types |
| Address constraints | Maximum depth 45; maximum zero run 6 |
| Bootstrap-facing source | All 186 primitive paths outside AX remain literal |
| Concrete machine | 218 working states; 436 rows; all states graph reachable |
| Complete quantified runtime | 6,176/6,176 cases pass, with arbitrary natural registers, gap, and nonempty finite spare list |
| Blank initialization | 312,605 steps to complete safe root frame |
| Independent blank replay | Every one-cell, zero exterior, head, and reference transition checked |
| Portable isolated replay | All runtime cases and the full startup trace reproduced byte for byte |

The blank boundary is native dispatcher 84, head −5, gap 80, and

~~~text
[N,T,W,A,D,H,X,Y,L] = [3,0,0,0,3,0,0,0,0].
~~~

There are 130 spare blocks, each with value 1, and exactly 277 one-cells.
The source theorem permits the nonzero initial N and D.

The 246 startup rows preserved during allocation belong to the included
**unfolded 221-state reference**. That reference and the final candidate
both take 312,605 steps. The original raw K219 table takes 312,617 steps
to the same complete boundary.

## Reproduce

Use Python 3.10 or later with assertions enabled:

~~~sh
python verify_all.py
python verify_all.py --runtime
~~~

The first command authenticates all packaged files and repeats the finite
logic, source, relabeling, reconstruction, and exact blank-tape checks. It
also audits the stored runtime-case inventory. The second additionally
recomputes every quantified runtime derivation, normally in a few minutes.
The scripts use only the standard library and write outputs to temporary
directories. No network, optimizer, theorem prover, or package installation
is required.

The paper can be rebuilt with a standard LaTeX installation:

~~~sh
pdflatex -interaction=nonstopmode -halt-on-error k218_dominated_rho8.tex
pdflatex -interaction=nonstopmode -halt-on-error k218_dominated_rho8.tex
~~~

A further LaTeX pass may be needed after changing pagination.

## Package organization

- **theory/**: finite proof and its reconstruction, standalone theory paper,
  final common-input calibration, and pinned macro/calculus evidence.
- **source/**: exact baseline, source constructor, reference and final trees,
  guarded control graph, and independent receipt.
- **binary/**: both transition tables, deterministic delta recipe, complete
  table LaTeX, portable quantified runtime checker, and complete receipts.
- **audits/**: separately written logical, control-graph, label-bijection, and
  blank-tape checks.
- **experiments/**: proved dirty-unpairing alternative and finite supplements.
- **provenance/** and **licenses/**: predecessor README, credits, and notices.

Only the selected, fully calibrated candidate appears as the final table.
The paper explains why earlier 218-state initialized cores were rejected
and why fewer flat instructions did not always improve the state budget.

## Provenance and integration

Pinned repository:
https://github.com/VladimirReshetnikov/ProveIt

Commit:
f8ec6158f3bdc885139ee395ae34fe44c3251b9f

Immediate predecessor:
Computability/BusyBeaver/Research/ZFC/candidate-k219/

The new material consists of the dominated-row proof and finite
certificate, command calibration, source schedule and rebracketing,
218-state table, reconstruction, audits, and report. Inherited calculus,
macro, runtime, and ZFC-calibration contributions retain their notices.
The next kernel-integration work is explicit in the paper; it is separate
from the delivered ordinary mathematical construction.

No unconditional nonhalting, minimality, or priority claim is made.

