# Sharp Codimension Thresholds and Uniform Amplification on the Boolean Cube

**Research manuscript, 7 October 2026.** Prepared with ChatGPT (GPT-6 Astra Pro) in response to Vladimir Reshetnikov's request for research inspired by the openai/math and ProveIt repositories.

The package contains the complete article in LaTeX and PDF, exact computational certificates, their generating code, figures, and source provenance. It is intended to be integrated as a self-contained report directory.

## Principal results

Let H_N be the sum of N independent uniform signs. For a finite observation F, let D(F) be the largest Fourier degree of a cell indicator and let v(F) be the variance of the conditional mean of H_N.

1. **Sharp codimension threshold.** If every cell has degree at most N−k, for k=1,2,3, then every conditional sum variance is at least k and v(F)≤N−k. Equality holds exactly for translated k-sign-sum distributions. The first possible failure is k=4.
2. **Quantitative distributional stability.** Near equality forces each conditional sum law close in total variation to a translated binomial law. Averaging gives a joint-law stability theorem, with constants 1/4, 1/4, 3/8 in the conditional-variance normalization. Sharp local moduli are proved for the associated alternating-moment class.
3. **An exact twenty-bit witness.** The construction has 622 cells, each of exact degree 16, and retained variance 16+9/34816. Its exceptional cell has 8704 points and conditional variance 1147/289=4−9/289.
4. **Exact score law and tensor consequences.** The complete score law is a four-atom signed perturbation of the sixteen-bit sum. Tensor products give an unbounded additive variance–degree gap. A concave asymptotic retention profile exists and is strictly above the coordinate-revelation baseline at every interior degree density.
5. **Scoped twenty-bit minimality.** Exact exhaustion of 1,731,542 configurations excludes smaller examples within the explicitly defined equal-binomial-block, sum-level-test reporting family. This is not a minimum-dimension theorem for all cube observations.
6. **Uniform quantitative amplification.** Explicit normal-transfer estimates and a fourth-moment invariant make one fixed averaging count work at every stage. Rational parameters give a fully specified positive power exponent, though an extremely small one, and explicit degree/dimension bounds.

The article also proves that the abstract fourth alternating-moment relaxation has variance infimum 3/4, not attained, and lists thirteen further research questions.

## Relationship to previous work

The finite-observation framework, exceptional-report cancellation mechanism, qualitative Gaussian gain, and arbitrary-factor Fourier square-root violations originate in the inspected OpenAI manuscript, *Unbounded Violations of the Square-Root Degree Bound* (result family 192). They are attributed in the article.

The existence of a positive power separation already follows from that prior arbitrary-factor result and balanced Boolean composition. The article includes that deduction and does not present bare positive-power existence as a new result. The quantitative contribution is a fixed explicit schedule and explicit constants.

The twenty-bit observation is a variance–degree counterexample. Its own sign readout has actual degree 16 and singleton sum equal to the sixteen-bit majority benchmark, so that particular Boolean function is not a square-root counterexample. The symmetrized readout likewise has degree 17 and the seventeen-bit benchmark. Both statements are exactly checked.

Priority claims are limited to the inspected sources and the stated literature comparison. The new mathematical arguments are complete proofs; they have not been formalized or checked by Lean. The article separates analytic proofs, finite computation, and proposed formalization tasks.

## Contents

| Path | Purpose |
|---|---|
| fourier_codimension.pdf | Complete compiled article |
| fourier_codimension.tex | Main LaTeX source |
| sections/ | All article sections and the inline bibliography |
| figures/ | Publication figures in PDF and PNG |
| code/verify_witness.py | Exact full grouped-cube certificate |
| code/verify_constants.py | Exact rational checks of Gaussian estimates |
| code/run_verification.py | Witness check and optional full minimality run |
| code/enumerate_reporters.py | Exact finite optimization |
| code/enumerate_two_leaf_integer.py | Independent integer implementation of the largest two-leaf case |
| code/make_figures.py | Regenerates figures from exact data/formulas |
| data/ | Generated exact certificates |
| provenance.json | Reviewed repository revisions and source identities |
| verification_summary.json | Verification scope and outcomes |
| SHA256SUMS | Hashes of the included deliverable files |

## Build the article

From this directory, with a standard TeX Live or equivalent installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error fourier_codimension.tex

Alternatively, run pdflatex on the main file three times to resolve the contents and references. No BibTeX invocation is required. Keep the sections and figures directories beside the main file.

The supplied figure PDFs are sufficient to build the article. Regenerating the figures requires Python, NumPy, and Matplotlib:

    python3 code/make_figures.py

## Reproduce the exact checks

Python 3.10 or later is sufficient for the certificates. They use only the standard library.

    python3 code/run_verification.py
    python3 code/verify_constants.py

The first command accounts for all 2^20 sign strings through 3125 block-sum tuples. It verifies every cell's moments, the complete score law, and its exact degree. Block symmetry reduces the high-degree check to 56 profiles for each of 622 cells, giving 34,832 exact zero checks; all Fourier coefficients above degree 16 are covered. A degree-16 coefficient is nonzero for each cell. Separate coefficients certify the sign-readout degrees.

The second command verifies 35 exact rational comparisons used in the Gaussian proof. The enormous dyadic constants are stored symbolically by their exponents. The script neither constructs the final iterated Boolean function nor approximates the Gaussian interval probabilities.

To rerun all four finite minimality cases:

    python3 code/run_verification.py --exhaustive

This enumerates every distinct nonempty proper test family and every onto selector remaining after the mathematical reductions. The included certificate records all counts, exact maxima, and one maximizing configuration for each case. Empty/full tests, duplicate tests, and unused leaves are handled by proved reductions in the article.

To rerun the independently implemented largest two-leaf check:

    python3 code/enumerate_two_leaf_integer.py --block-size 6 --output data/minimality_n6_independent_integer.json

The supplied independent certificate reproduces all 992,250 configurations in the n=6, m=2 row and the maximum −1293/33152. Both implementations were run during preparation of this package.

## Repository integration

Copy the complete directory into the desired report location. The article's paths are relative to its own directory. No existing ProveIt file must be modified to build or verify it.

The inspected ProveIt connections are its *Noisy parity cubes* report and its finite Thue–Morse/Walsh Lean declarations. The article proposes a staged formalization roadmap beginning with finite Walsh support complementation and the interlacing-lattice lemma. The proposed new modules are not represented as existing or Lean-verified work.

The accompanying provenance file records the exact reviewed commits and source paths. Original third-party manuscript sources are referenced, not duplicated in this package.
