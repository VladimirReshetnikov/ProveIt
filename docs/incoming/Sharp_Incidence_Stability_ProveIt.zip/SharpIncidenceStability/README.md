# Sharp Stability Constants for Fractional Covers and Incidence Spans

**Ramsey density, equality structure, and singular Lagrangian counts**  
Research memorandum for ProveIt, October 7, 2026, version 1.0.

The package contains a 23-page article with full mathematical proofs, its
self-contained LaTeX source, a standard-library Python verifier, exact finite
certificates, source provenance, and integration notes.

## Main results

For a fractional cover `(S_j, gamma_j)` of a finite ground set `E`, define

- `R(f) = sum_e f({e}) - f(E)`;
- `G_gamma(f) = sum_j gamma_j f(S_j) - f(E)`;
- `c_gamma(F) = sum_{j: S_j intersects F} gamma_j - 1`.

When `c_gamma(F) > 0` for every `|F| >= 2`, the exact best constant in
`R(f) <= K_gamma G_gamma(f)` is

`K_gamma = max_{|F| >= 2} (|F|-1) / c_gamma(F)`.

This holds for normalized monotone submodular functions. For fractional
partitions it holds without monotonicity. The article proves the result using
unit contractions of integral polymatroids, rational approximation, and modular
invariance. It gives sharp entropy and determinant consequences and an optimal
lower-gap analogue.

For subspaces on edges of a simple a-uniform hypergraph, this specializes to

`R <= mu_a(H) Delta`,

where `R` is total relation dimension and `Delta` is the local incidence-span
excess. The coefficient is sharp; for graphs it is the standard 2-density
`m_2(G)`. Equality is classified for strictly balanced hypergraphs, and the
minimum dimension cost of repairing to a direct sum is exactly `R`.

The exterior-algebra counting theorem then improves the nondirect residual
estimate in the reviewed OpenAI Sidorenko manuscript:

- at even `D >= 364`: `O_D(q^(-D+224))`, replacing `O_D(q^(-D+1641))`;
- at `D = 310`: the residual estimate alone is `O_D(q^(-7))`.

**The full construction is not proved valid at D = 310 or D = 364.** Its earlier
residue-reduction and transverse-analysis thresholds remain in force. The
source-specific application explicitly imports the residual gain bound; the
main submodularity and span theorems are independent of the source's claimed
counterexample.

## Files

| File | Purpose |
| --- | --- |
| `article.pdf` | Compiled 23-page article |
| `article.tex` | Self-contained LaTeX source with bibliography |
| `code/verify.py` | Exact finite checks; Python standard library only |
| `certificates/verification_results.json` | Machine-readable results of the recorded run |
| `certificates/verification_run.txt` | Recorded verifier output |
| `certificates/graph_certificate.json` | Faces, edges, and planar rotation system |
| `certificates/pdf_qa.json` | PDF build and rendering checks |
| `provenance.json` | Pinned repository commits and source identifiers |
| `INTEGRATION.md` | Proposed repository placement and formalization interfaces |
| `Makefile` | Verification, compilation, and cleanup commands |

## Reproduce

From this directory:

```sh
python3 code/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `make verify` and `make pdf`.

The Python program uses exact integer, rational, and prime-field arithmetic. Its
randomized checks use fixed seed 20261007. It overwrites only the JSON verifier
result in `certificates/`; the provided `verification_run.txt` records the
original successful run. LaTeX requires a reasonably complete TeX Live
installation, including `newpxtext`, `newpxmath`, and `tocloft`.

## Verification status and scope

The mathematical results have written proofs. Supplementary checks include
1,200 subspace arrangements, all 15,750 assignments of subspaces of F_2^2 to K_3
and K_4, 320 polymatroid-cover tests, 702 unit contractions, 163 exterior-rank
checks, exact small-field symplectic counts, and the complete 64-case residual
exponent optimization. All checks passed.

No Lean proof or independent build of the upstream repositories is claimed.
Finite experiments do not establish the general theorems. Priority beyond the
explicit comparisons in the article remains to be established. Classical
fractional-subadditivity and zero-gap independence results are acknowledged as
prior work, not presented as new.

The original source manuscripts are not bundled. Their finite graph data are
reproduced with attribution; exact source paths and commits appear in the
article and `provenance.json`.
