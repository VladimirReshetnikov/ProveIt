"""Verify every delivered byte, exact inventory, and mandatory local dependencies.

This is a consistency checker, not an external digital signature. Trust a separately
obtained archive digest when authenticity matters. Standard library only.
"""
from hashlib import sha256
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).absolute().parent
MANIFEST = 'release-manifest.json'
DIGEST = MANIFEST + '.sha256'
MAX_FILES = 512
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TREE_BYTES = 128 * 1024 * 1024
PINS = {'canonical-height/MANIFEST.json': 'e3afbd40f79840fa21d0a87f8c35a7039c894af5d7f66d921211434f6a2e74b3', 'canonical-height/README.md': '7d8ff722a844a2f9aff2137a24750a693fcb86878fc7ded9a80b63b8123b7915', 'canonical-height/THEOREM.md': '6d48066a8384c055ed1cffef087b520ce55a73475ea8f42654e726837c11c66e', 'canonical-height/audit/CANONICAL-HEIGHT-CIRCUIT-AUDIT.md': '2b52cb8cf65ff027e151eae8b475536a4a2291415897b90e4e45368bd59ed6f2', 'canonical-height/audit/CANONICAL-HEIGHT-PROOF-AUDIT.md': '2d3e44a9d1a96233a27990e50981414cd849df7d1aa328f20749db45aa0c1703', 'canonical-height/audit/canonical_height_proof_checks.json': 'bba854177258c19bc82995c0bcdf8703beb6b5fc8140c1eeef9161b175e10a54', 'canonical-height/audit/check_canonical_height.py': '00df0bd853c94d396a6dce1824bfa90068fa11d3f248523a704f8b73b8d6b6b6', 'canonical-height/audit/check_canonical_height_proof.py': 'ad17747e419c6724cb728414c3131e0b55c0354bfc0f81de4dc19bea59a1058a', 'canonical-height/audit/frozen-before.json': '00faac59c7c829236ee5b7ea124af164b03e9b814a3f54b00925c29cdba3d819', 'canonical-height/audit/independent-canonical-height-audit.json': 'd70d2f9fff7025cd31da7c2a15899b92934325c37513475d8698f14922abfb2b', 'canonical-height/circuits/incdec-native-canonical.dag.txt': '03dc1e38083bcb7631b7c44d7c76ee8b3965ef4427f4fb8dbf1949e206fdc040', 'canonical-height/circuits/incdec-native-canonical.json': '32406c31c0cac175fc0e67c1552306e6e87138feeda26c797d27bfb89baa8d9e', 'canonical-height/circuits/incdec-phase4-canonical.dag.txt': 'e3c41aa81aa2b32154b19a567ea896bf15a019f28daff3ab7b9ec28ac8e7e31c', 'canonical-height/circuits/incdec-phase4-canonical.json': '5a1894dd1b26dd972d04018649400787719635d728d6665a8f7d19b36ee34ae4', 'canonical-height/circuits/nop-native-canonical.dag.txt': 'b4cae5c3de036c2c392f0a6d0781367d7e1e68d1caa4014aefb7e536199a8c18', 'canonical-height/circuits/nop-native-canonical.json': '4b1c0b9cdeb9f7261ce1299f613b014552073c3f2f04c556b30acb139cc328f7', 'canonical-height/circuits/nop-phase4-canonical.dag.txt': '866a35d0b34b9eef7682ced4e3bc57ff7c90dc1f517c80c45abf500857e22e7f', 'canonical-height/circuits/nop-phase4-canonical.json': 'ed84347267b98822fbc9df993a34ea97f92fb5105a27c7571ad7341ffdfb3356', 'canonical-height/circuits/positive3-native-canonical.dag.txt': '7804a5ead36ee7566050916151cd6d3c5a660a08fa46121994d0059c65c23d66', 'canonical-height/circuits/positive3-native-canonical.json': 'b2690022cb8234d740f0d1d75f2a41b1e7cf5bac0aed829b324be32f45c2b1f5', 'canonical-height/circuits/positive3-phase4-canonical.dag.txt': 'c064853117e6842c54ea234aa6767d900d04f9674587e1f393c5bca4afa6e40e', 'canonical-height/circuits/positive3-phase4-canonical.json': '9b160c9c3e39da47078e3d24270e12bb8cd77cf23175fdfa2cbaa7239deca717', 'canonical-height/circuits/zero-step-native.json': '55635db65b7f25cffe1dad353d328ec6673451f135b7aa937cbfbbb81bba0160', 'canonical-height/circuits/zero-step-phase4.json': 'e27901298554353187f8f77c84c72b6b9b5418513da91322479c2652602c1af5', 'canonical-height/circuits/zero3-native-canonical.dag.txt': 'b2988bbcd6b2c6915804cf6d85067e7df67c8cd1b58752deaf28f0dd37fa84f2', 'canonical-height/circuits/zero3-native-canonical.json': 'c57aecc8d755565ba5ea0020cefeee053bc51d1d17b2a8775542571c362e8662', 'canonical-height/circuits/zero3-phase4-canonical.dag.txt': 'adb60a20abf654beb5dfdaae729ae425a4f189d3b9088ac7189590988de3d5c6', 'canonical-height/circuits/zero3-phase4-canonical.json': 'befccf38a1d9463c0758432c189060481edacef8c840b0e5480fea5680201207', 'canonical-height/emit_canonical_clocks.py': '645e9f230b3e912d7c35a0b0e03f78953d0c393db7e71bf2c13bdd87b694c324', 'canonical-height/original-MANIFEST.json': '3546ec269df10808a2067cea9df325709df11966b346857271e66ab4855cadce', 'canonical-height/receipts/emission.json': 'd3df3ae8f53dfa3e1c3ec14527792c99f0aa3d1283047bb39b423cd8aa287706', 'canonical-height/reference/base/MANIFEST.json': '1bf1225aa950ad1d4f842c8bf098e1935925cd1d52c90453b7696c1321648f95', 'canonical-height/reference/base/THEOREM.md': '93bf673898816aed526ef943160a9d3dfb950cedc3bf0f59d6ae4d78c7add11d', 'canonical-height/reference/base/audit/EMITTED-CIRCUIT-AUDIT.md': '6b49b28fdc4f80b91d48bfbb9874ddf6e8891035fd0d689e2fec651f5f10acd3', 'canonical-height/reference/base/audit/PROOF-AUDIT.md': 'ec2e89c5e6a23a25b4c1c7e85fb3625082b40f2e9bc4aeaceb04e22656912151', 'canonical-height/reference/base/circuits/zero-step-native.json': '55635db65b7f25cffe1dad353d328ec6673451f135b7aa937cbfbbb81bba0160', 'canonical-height/reference/base/circuits/zero-step-phase4.json': 'e27901298554353187f8f77c84c72b6b9b5418513da91322479c2652602c1af5', 'canonical-height/reference/base/source/inherited_clean_target_theorem.md': '3d85f8cde66837d8916fb3273c2c57cc1a91ce37de1f3d6c6fe28a4db9103168', 'canonical-height/reference/base/source/residue_affine_packed_history.md': '0b6c533e8ef6c26b3ed5419dbb2baa44bc1509255c4bcf5226e5f85d37683882', 'canonical-height/reference/base/source/three_mass_unbounded_interface.md': 'd336c8c12d3328eb4b6857ee382f91b2c9363f50effba5a7b1bf75308f25df45', 'canonical-height/reference/folded/ADDENDUM.md': '1ce912386db479f63eed0d05f2a7d79649b4d8a03b91bf2080338f1cafaafde8', 'canonical-height/reference/folded/MANIFEST.json': '774a4498984ebccf8216897e21bf597084e70b148557ba4fa12b597bba44ba91', 'canonical-height/reference/folded/circuits/incdec-native-folded.json': '016763e884341dce3c6f4edf5526503672cc36d963b37dcad92dad45b4fc87f6', 'canonical-height/reference/folded/circuits/incdec-phase4-folded.json': 'f4e7874b92d083a139f4583819f46c4ee7ebb987455dc645f5e857acf5d90f48', 'canonical-height/reference/folded/circuits/nop-native-folded.json': '04725936d07fea801d05a2467e3f8648679f59f95d72b30853731ddc02261f2c', 'canonical-height/reference/folded/circuits/nop-phase4-folded.json': 'f7f819da91f55e0e9d535b8bca6184ac15a7304390e6774c04dfb1af03e9d03f', 'canonical-height/reference/folded/circuits/positive3-native-folded.json': 'a2981542883cb85385d96592c20c469fb719a3d8ff09c1cc94133813455b6284', 'canonical-height/reference/folded/circuits/positive3-phase4-folded.json': '7d08a3005d444b2e7b8c07e1e11a64a1c2472451d3e72182e3a95d0b0aa2c9be', 'canonical-height/reference/folded/circuits/zero3-native-folded.json': '1c1a072c8a60d7b84e4acdb79e67609a14bcfe7568de6aa0d920cf1d56d3da16', 'canonical-height/reference/folded/circuits/zero3-phase4-folded.json': 'cd23cb3f29d51336f6cab68f99eb8cd926cf166bef143894b43fff404f1df988', 'canonical-height/verify_manifest.py': '843a2408564a16700c9fcae55d6e3bc474555dc89d3f50b91151d735d9fccb98', 'check_combined_fibers.py': '371eda9bfd0713ff47694d5e7c3f0aab7233e933c6082ad6b6b32dd9aeb21c7b', 'check_privacy.py': '556871f9e3b6cf66282830726136d9b1667433d0bb601357e944abd9617c3b42', 'check_provenance.py': 'b3ba8dd500676e367aca242ac4ac43072e50fd0eb4dcfa60968e555e7f558afa', 'combined-checks.json': '4f79581bb28dd5e003954d39db7184383984afb8cdbae67e1a1aadfb48828aa4', 'delivery-provenance.json': 'c1f4280269942302bd9ffc19a449a34f2753e4f7a5a025b764e7a03659aca0c2', 'inherited-source/five_gate_folding_audit.md': '67a6c3c4ed67b3b11ee735598ff84f242428be948633f0c0186c9dc2ab6cb1d9', 'inherited-source/inherited_clean_target_theorem.md': '3d85f8cde66837d8916fb3273c2c57cc1a91ce37de1f3d6c6fe28a4db9103168', 'inherited-source/provenance.json': '9b38ad3411c8286003aa7a7f3237f2c4a9818d950d049305750229628d767b1a', 'inherited-source/residue_affine_packed_history.md': '0b6c533e8ef6c26b3ed5419dbb2baa44bc1509255c4bcf5226e5f85d37683882', 'inherited-source/review_three_mass_unbounded_interface.json': '3d30d2399401861fdd7400914f12eda6a33afea0e5575088300dfd27f9534212', 'inherited-source/review_three_mass_unbounded_interface.md': '401c354e49441c09a1e11068a07ee9d27b75f961dc61fd72039c4914ce2094fe', 'inherited-source/three_mass_unbounded_interface.json': 'fe69f0504c8f68c4130c4b21fed5c817596ab5c0e2fdf9621b0bf5f45c12ac0e', 'inherited-source/three_mass_unbounded_interface.md': 'd336c8c12d3328eb4b6857ee382f91b2c9363f50effba5a7b1bf75308f25df45', 'native-fibers/CHECK-RECEIPT.json': '866fdb0f67465a6648ead2274984416e1a67983266a10f6507a968946e093688', 'native-fibers/MANIFEST.json': 'dbb2a3e314c4f9330777a270e0fe4a6d1a1b446e50b3b3bb00135faf7a00fe37', 'native-fibers/README.md': 'a576063c0cdb7afcfeb97f8962d8ef992520921a149591daae3366acb307fbf3', 'native-fibers/REVIEW.md': '6a5ffed01c0fa496d13249507d42bc8c70694fc948f08bf0f4e0b672b694d8b3', 'native-fibers/THEOREM.md': 'ac0ce327330d36c55916ec188b2f80903606018239eaddc49d34636782a70aae', 'native-fibers/check_native_fibers.py': '380e5726b40e849a5d51e6b90eab857170ee3e82d6453ae59a7138d6419e2750', 'native-fibers/original-MANIFEST.json': 'd716d6dc668547ee5d64dfe77620b66f93ab839f95e0261250c2a387b5338dca', 'native-fibers/source/EXPLORATION_FIXED_MINUS_INDEX_PARITY.md': '47a2c5b69f3c87b7a1ddc61ef84757023de291b63d1330e2c8dc9b40e811ab8b', 'native-fibers/source/EXPLORATION_ODD_INDEX_PELL_SIGNS.md': '4a257fe64194dc187cc9775899ca737f5ee15f185c088a33ac947c12afa66ccc', 'native-fibers/source/native_binary_masked_selection63.md': 'c2e08f2d9fdaaf2e17880d7a131254492afd7ef21b035985714734cbc158c53e', 'native-fibers/source/native_blocks.json': 'a3ef38c5a449040a817384d564da90a5b7a440d426997df8ae6acecc4d55d74f', 'native-fibers/source/native_controller_binary_selector56.md': '97fcdc7188f968f2ac3e315249b0e0a15dcc787c10451924ad3f2551c8bb376c', 'native-fibers/source/provenance.json': '11e6ed1e74c61dabfabb3d45cb88ead6f677ab451bac47275fcd30269f8f2590'}


def require(ok, detail):
    if not ok:
        raise ValueError(detail)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def load_json(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def relative_name(name):
    require(type(name) is str and name and '\\' not in name and ':' not in name,
            'invalid relative path')
    path = Path(name)
    require(not path.is_absolute() and all(p not in ('', '.', '..') for p in name.split('/')),
            'invalid relative path: ' + name)
    require(path.as_posix() == name, 'noncanonical path: ' + name)
    return name


def inventory(root):
    root = Path(root).absolute()
    require(not root.is_symlink() and root.is_dir(), 'root must be an ordinary directory')
    files, directories = {}, set()
    total = 0
    for base, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs + names):
            path = Path(base) / name
            rel = relative_name(path.relative_to(root).as_posix())
            mode = path.lstat().st_mode
            require(not stat.S_ISLNK(mode), 'symlink rejected: ' + rel)
            if stat.S_ISDIR(mode):
                directories.add(rel)
            else:
                require(stat.S_ISREG(mode), 'nonregular file rejected: ' + rel)
                size = path.stat().st_size
                require(size <= MAX_FILE_BYTES, 'file size limit: ' + rel)
                total += size
                require(total <= MAX_TREE_BYTES, 'tree size limit')
                files[rel] = path
                require(len(files) <= MAX_FILES, 'inventory entry limit')
    return files, directories


def check_pins(root):
    root = Path(root)
    for name in ('report22.tex','report22.pdf','report22-math-review.md','report22-qa.json','README.md','replay.py','release_checks.py','write_manifest.py','delivery-provenance.json','combined-checks.json'):
        require((root/name).is_file() and not (root/name).is_symlink(), 'missing mandatory release file: ' + name)
    for name, expected in PINS.items():
        path = root / name
        require(path.is_file() and not path.is_symlink(), 'missing ordinary pinned dependency: ' + name)
        require(sha256(path.read_bytes()).hexdigest() == expected, 'dependency pin mismatch: ' + name)
    return dict(frozen_files=len(PINS), canonical_original_manifest_sha256='3546ec269df10808a2067cea9df325709df11966b346857271e66ab4855cadce', native_original_manifest_sha256=PINS.get('native-fibers/original-MANIFEST.json'), inherited_receipt_sha256=PINS.get('inherited-source/three_mass_unbounded_interface.json'))


def verify(root=ROOT):
    root = Path(root).absolute()
    observed, directories = inventory(root)
    require(MANIFEST in observed and DIGEST in observed, 'missing release manifest or its digest')
    raw = observed[MANIFEST].read_bytes()
    require(len(raw) <= 1024 * 1024, 'manifest size limit')
    expected_digest = sha256(raw).hexdigest() + '  ' + MANIFEST + '\n'
    require(observed[DIGEST].read_text() == expected_digest, 'manifest digest mismatch')
    manifest = load_json(raw)
    require(type(manifest) is dict and set(manifest) == {'schema', 'files'}, 'manifest shape')
    require(manifest['schema'] == 'report22-exact-inventory-v1', 'manifest schema')
    entries = manifest['files']
    require(type(entries) is dict and 1 <= len(entries) <= MAX_FILES - 2, 'manifest file map')
    for name, entry in entries.items():
        relative_name(name)
        require(name not in (MANIFEST, DIGEST), 'self-referential manifest entry')
        require(type(entry) is dict and set(entry) == {'bytes', 'sha256'}, 'manifest entry shape: ' + name)
        require(type(entry['bytes']) is int and 0 <= entry['bytes'] <= MAX_FILE_BYTES, 'manifest byte count')
        require(type(entry['sha256']) is str and len(entry['sha256']) == 64 and
                all(c in '0123456789abcdef' for c in entry['sha256']), 'manifest digest syntax')
    expected = set(entries) | {MANIFEST, DIGEST}
    require(set(observed) == expected, 'inventory mismatch: extra=' + str(sorted(set(observed) - expected)) +
            ' missing=' + str(sorted(expected - set(observed))))
    wanted_dirs = {p.as_posix() for name in expected for p in Path(name).parents if p != Path('.')}
    require(directories == wanted_dirs, 'directory inventory mismatch: extra=' +
            str(sorted(directories - wanted_dirs)) + ' missing=' + str(sorted(wanted_dirs - directories)))
    for name, entry in entries.items():
        raw = observed[name].read_bytes()
        require(len(raw) == entry['bytes'] and sha256(raw).hexdigest() == entry['sha256'],
                'file content mismatch: ' + name)
    pins = check_pins(root)
    return dict(status='passed', files_verified=len(entries), **pins)


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
