"""Integrity attacks against external disposable copies; normal and -O safe."""
import sys
sys.dont_write_bytecode = True
import json
from hashlib import sha256
from pathlib import Path
import shutil
import tempfile
from verify_release import ROOT, MANIFEST, DIGEST, verify, require
from replay import prepare_output


def seal_untrusted(p, data=None):
    if data is None:
        entries={}
        for f in sorted(p.rglob('*')):
            if f.is_file() and f.name not in (MANIFEST,DIGEST):
                raw=f.read_bytes(); entries[f.relative_to(p).as_posix()]=dict(bytes=len(raw),sha256=sha256(raw).hexdigest())
        data=dict(schema='report22-exact-inventory-v1',files=entries)
    raw=(json.dumps(data,indent=2)+'\n').encode()
    (p/MANIFEST).write_bytes(raw); (p/DIGEST).write_text(sha256(raw).hexdigest()+'  '+MANIFEST+'\n')


def must_reject(function,label):
    try: function()
    except (ValueError,FileNotFoundError,NotADirectoryError): return
    raise RuntimeError('accepted attack: '+label)


def main():
    verify(ROOT); names=[]
    with tempfile.TemporaryDirectory(prefix='report22-integrity-') as tmp:
        parent=Path(tmp)
        def trial(label,mutate):
            target=parent/label; shutil.copytree(ROOT,target); mutate(target)
            must_reject(lambda:verify(target),label); names.append(label); shutil.rmtree(target)
        target='canonical-height/circuits/nop-native-canonical.json'
        trial('changed-circuit',lambda p:(p/target).write_text('{}\n'))
        trial('missing-circuit',lambda p:(p/target).unlink())
        trial('extra-file',lambda p:(p/'extra.txt').write_text('unlisted'))
        trial('extra-hidden-file',lambda p:(p/'.extra').write_text('unlisted'))
        trial('extra-empty-directory',lambda p:(p/'unexpected').mkdir())
        trial('extra-bytecode',lambda p:((p/'__pycache__').mkdir(),(p/'__pycache__/bad.pyc').write_bytes(b'bad')))
        trial('file-symlink',lambda p:((p/target).unlink(),(p/target).symlink_to(ROOT/target)))
        trial('directory-symlink',lambda p:(p/'linked').symlink_to(p/'canonical-height',target_is_directory=True))
        trial('dangling-symlink',lambda p:(p/'dangling').symlink_to('missing'))
        trial('manifest-digest',lambda p:(p/DIGEST).write_text('0'*64+'  '+MANIFEST+'\n'))
        def traversal(p):
            d=json.loads((p/MANIFEST).read_text());d['files']['../escape']=dict(bytes=0,sha256=sha256(b'').hexdigest());seal_untrusted(p,d)
        trial('manifest-traversal',traversal)
        def duplicate(p):
            raw=(p/MANIFEST).read_text().replace('"schema":','"schema": "evil", "schema":',1).encode()
            (p/MANIFEST).write_bytes(raw);(p/DIGEST).write_text(sha256(raw).hexdigest()+'  '+MANIFEST+'\n')
        trial('duplicate-key',duplicate)
        def resealed(p):
            path=p/target;path.write_bytes(path.read_bytes()+b'\n');seal_untrusted(p)
        trial('resealed-circuit-pin',resealed)
        def resealed_missing(p):
            (p/target).unlink();seal_untrusted(p)
        trial('resealed-missing-pin',resealed_missing)
        def resealed_missing_report(p):
            (p/'report22.pdf').unlink();seal_untrusted(p)
        trial('resealed-missing-article',resealed_missing_report)
        must_reject(lambda:prepare_output(ROOT/'inside',ROOT),'internal-output');names.append('internal-output')
        existing=parent/'existing';existing.mkdir()
        must_reject(lambda:prepare_output(existing,ROOT),'existing-output');names.append('existing-output')
        link=parent/'link';link.symlink_to(existing,target_is_directory=True)
        must_reject(lambda:prepare_output(link/'new',ROOT),'symlink-output');names.append('symlink-output')
    verify(ROOT)
    print(json.dumps(dict(status='passed',optimized=not __debug__,checks=len(names),attacks_rejected=names,
                          release_unchanged=True),indent=2))

if __name__=='__main__': main()
