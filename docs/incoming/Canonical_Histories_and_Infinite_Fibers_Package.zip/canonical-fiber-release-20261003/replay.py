"""Read-only sealed Report22 replay; writes only to a new external output folder.

Usage: python3 -B replay.py --output /tmp/new-report22-replay
An explicit --unsealed-payload mode is preliminary only and cannot validate a
final release seal. Standard-library local code only; no network or checkout.
"""
import sys
sys.dont_write_bytecode = True
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from verify_release import ROOT, verify, require, inventory, check_pins

COMMANDS = (
    ('check_provenance.py',),
    ('check_privacy.py',),
    ('canonical-height/verify_manifest.py',),
    ('canonical-height/emit_canonical_clocks.py','--check'),
    ('canonical-height/audit/check_canonical_height_proof.py','--expect','canonical-height/audit/canonical_height_proof_checks.json'),
    ('canonical-height/audit/check_canonical_height.py','--expect','canonical-height/audit/independent-canonical-height-audit.json'),
    ('native-fibers/check_native_fibers.py','--check'),
    ('check_combined_fibers.py','--expect','combined-checks.json'),
    ('canonical-height/verify_manifest.py',),
)
BOOTSTRAP = r'''
import sys, runpy
from pathlib import Path
sys.dont_write_bytecode = True
try:
    import resource
except ImportError:
    resource = None
if resource is not None:
    resource.setrlimit(resource.RLIMIT_CPU, (240, 240))
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
script = Path(sys.argv[1]).resolve()
sys.argv = [str(script)] + sys.argv[2:]
sys.path.insert(0, str(script.parent))
runpy.run_path(str(script), run_name='__main__')
'''


def prepare_output(output, root=ROOT):
    root=Path(root).resolve()
    if output is None:
        parent=Path(tempfile.gettempdir()).resolve()
        require(parent != root and root not in parent.parents,'temporary directory is inside release')
        return Path(tempfile.mkdtemp(prefix='report22-replay-'))
    path=Path(output).expanduser().absolute()
    for ancestor in (path,)+tuple(path.parents):
        require(not ancestor.is_symlink(),'symlink output path rejected')
    actual=path.resolve()
    require(actual != root and root not in actual.parents,'replay output must be outside the release')
    require(not path.exists(),'replay output already exists; choose a new directory')
    require(path.parent.is_dir(),'output parent must already exist')
    path.mkdir()
    return path


def bytes_inventory(directory):
    files,dirs=inventory(directory)
    return {n:(p.stat().st_size,sha256(p.read_bytes()).hexdigest()) for n,p in files.items()},dirs


def run_command(directory,arguments,optimized,log):
    command=[sys.executable,'-I','-S','-B']+(['-O'] if optimized else [])
    command+=['-c',BOOTSTRAP,str(directory/arguments[0])]+list(arguments[1:])
    env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON')}
    # Ensure integrity-test scratch copies also remain outside the release.
    env['TMPDIR']=str(Path(log).parent)
    started=time.monotonic()
    with Path(log).open('wb') as stream:
        done=subprocess.run(command,cwd=directory,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=300)
    require(done.returncode==0,'replay failed: '+arguments[0]+'; see external log '+str(log))
    return {'command':list(arguments),'optimized':optimized,'returncode':done.returncode,'seconds':round(time.monotonic()-started,3),'checks_use_explicit_errors':True}


def replay(output=None,root=ROOT,unsealed=False):
    root=Path(root).absolute()
    # The complete tree, including prose, PDF, tools and manifest, is snapshotted.
    baseline=bytes_inventory(root)
    integrity=check_pins(root) if unsealed else verify(root)
    output=prepare_output(output,root)
    all_runs=[]
    for optimized in (False,True):
        mode='optimized' if optimized else 'normal'
        copied=output/mode
        shutil.copytree(root,copied)
        logs=output/(mode+'-logs');logs.mkdir()
        require(bytes_inventory(copied)==baseline,'initial whole-release copy differs')
        commands=COMMANDS if unsealed else (('verify_release.py',),)+COMMANDS+(('release_checks.py',),('verify_release.py',))
        for i,args in enumerate(commands):
            all_runs.append(run_command(copied,args,optimized,logs/(str(i).zfill(2)+'.log')))
            require(bytes_inventory(copied)==baseline,'replay changed whole copied release inventory or bytes')
            require(bytes_inventory(root)==baseline,'replay changed whole source release inventory or bytes')
    require(bytes_inventory(root)==baseline,'source release changed')
    if not unsealed:verify(root)
    else:check_pins(root)
    result={'status':'passed','scope':'preliminary unsealed payload only' if unsealed else 'complete sealed release','python':sys.version.split()[0],'source_release_unchanged':True,'whole_release_inventory_and_bytes_unchanged':True,'modes':['normal','optimized'],'scripts':all_runs,'integrity':integrity,'checks_under_optimization':'All executed checkers use explicit errors; normal and -O execute the same substantive checks.','inventory_negative_tests':'not run in preliminary unsealed mode' if unsealed else 'passed in normal and optimized modes','third_party_python_executed':False,'positive_native_pell_tuple_materialized':False,'limits':{'wall_seconds_per_script':300,'unix_cpu_seconds_per_script':240,'unix_address_space_bytes':2*1024**3}}
    (output/'replay-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output')
    parser.add_argument('--unsealed-payload',action='store_true',help='Preliminary checks only; does not validate a final release seal')
    args=parser.parse_args()
    print(json.dumps(replay(args.output,unsealed=args.unsealed_payload),indent=2))
