# Report 22: Canonical outer histories and infinite native fibers

Read `report22.pdf` for the combined theorem and `report22.tex` for its editable source.

At fixed accepted nonempty input ports, the outer history tuple is unique after canonicalizing its height to the least power of two strictly above S. The full positive witness fiber is nevertheless infinite: a norm-preserving matrix recurrence varies only native j, o, and y_aux while the other nineteen native coordinates and all outer coordinates stay fixed. No full positive native Pell tuple is numerically materialized. The finite recurrence examples are auxiliary-only. The separate four-gate, no-witness initial-halt circuits are outside the nonempty-fiber theorem.

The complete canonical circuits have operation totals 608, 483, 481, and 484 for INC2;DEC2, ZERO3, NOP, and POSITIVE3, respectively, in both native and phase-four modes. They have 61, 59, 59, and 59 positive supplied coordinates and exact degrees 2344, 1192, 1192, and 1192.

## Contents and provenance

- `canonical-height/`: frozen canonical circuits and independent checks, with precisely documented portable packaging adaptations
- `native-fibers/`: fixed-scale infinitude proof, independent review, pinned source text, and a portable read-only checker
- `inherited-source/`: the authenticated full arithmetic JSON and proof context; all inherited material is inert data or text
- `check_combined_fibers.py` and `combined-checks.json`: independent exact gate/coordinate-order, dependency, symbolic identity, and corruption checks connecting the two proofs
- `delivery-provenance.json`: every copied or adapted file's source-relative name, original and delivered SHA-256 hashes, byte counts, and explanation; omitted duplicate logs are explicitly recorded
- `check_provenance.py`: checks original source-manifest authentication, every delivered copy/adaptation, and both portable payload manifests
- `report22-math-review.md` and `report22-qa.json`: independent mathematical review and final document visual/text QA

Original frozen manifests remain as each payload's `original-MANIFEST.json`. New payload manifests describe delivered files. All circuit JSON and textual DAG bytes are unchanged. One canonical proof receipt changes only its count of authenticated reference files because a historical audit text has been relocated and its example path sanitized. Historical canonical prose and circuit metadata say native multiplicity was unresolved at that stage; Report22 and the subsequent native proof resolve it without editing those frozen claims. The adapted native checker replaces twenty optimization-removable assertions with explicit checks, uses a portable sibling data path, and compares its unchanged expected outputs without writing them.

The original source provenance contains entries for upstream Python files from the broader historical snapshot. Those Python files are neither included nor executed here. No source repository is needed, modified, imported, or contacted during replay.

## Complete offline replay

From the release root, with Python 3 and its standard library:

    python3 -B verify_release.py
    python3 -B replay.py --output ../new-report22-replay

The output directory must not already exist and must be outside the release. The runner authenticates the entire release, copies the entire tree into fresh normal and optimized work areas, and executes the same substantive checks in both modes. Every checker uses explicit errors; no check is silently removed by Python's `-O` option. It checks the complete source and copied release inventory and every byte after every command. Logs, scratch copies, and replay receipts are written only outside the release.

The release verifier rejects extra, missing, changed, hidden, and bytecode files; empty directories; file, directory, and dangling symlinks; malformed paths and duplicate JSON keys; changed manifest digests; and resealed changes to pinned dependencies. `release_checks.py` tests those attacks in disposable external copies, including forbidden internal, existing, and symlink output paths. SHA-256 manifests provide consistency rather than external authenticity; obtain the final archive digest through a trusted channel.

A release author may run `python3 -B replay.py --unsealed-payload --output ../new-preliminary-replay` before sealing. Its receipt explicitly says preliminary, omits final-seal and inventory-attack claims, and cannot substitute for the full sealed replay above.

## Rebuilding and resealing

Use `sh build.sh` to rebuild the PDF; build intermediates stay outside the release. An intentional PDF or other file change invalidates the release seal. Only after completing the article, review, and QA, run:

    python3 -B write_manifest.py
    python3 -B verify_release.py

Then run the complete replay on a freshly extracted archive. Re-sealing an edited copy does not establish that it is an authentic publication.

## Scope

The claim concerns the retained fixed-source positive-integer circuits, instantiated on four short sources. It establishes no general finite-fold MRDP result, universal ordinary-input loader, universal numerical operation bound, minimality, rational/real zero-set theorem, or later target recurrence. Deterministic computation supplies uniqueness of the semantic outer history; it does not supply uniqueness of native arithmetic witnesses.
