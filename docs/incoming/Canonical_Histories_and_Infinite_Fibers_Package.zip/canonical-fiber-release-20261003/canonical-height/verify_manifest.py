#!/usr/bin/env python3
"""Read-only verification of this packet's manifest (standard library only)."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'MANIFEST.json').read_bytes())
for name,spec in m['files'].items():
 p=ROOT/name
 if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('unsafe manifest path')
 b=p.read_bytes()
 if len(b)!=spec['bytes'] or hashlib.sha256(b).hexdigest()!=spec['sha256']:raise ValueError('mismatch: '+name)
print(json.dumps({'status':'PASS','files':len(m['files']),'manifest_sha256':hashlib.sha256((ROOT/'MANIFEST.json').read_bytes()).hexdigest()},sort_keys=True))
