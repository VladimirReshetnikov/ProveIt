"""Exact bounded diagnostics for Report288; not a proof-assistant certificate."""
