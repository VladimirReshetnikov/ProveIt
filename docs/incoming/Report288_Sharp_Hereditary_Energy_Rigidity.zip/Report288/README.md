# Report 288

## Sharp Hereditary Energy Rigidity on Arbitrary Abelian Groups

Prepared for Vladimir Reshetnikov, 7 October 2026.

For arbitrary abelian groups G and H, this report proves that a map a:G→H is affine whenever its respected additive-energy ratio has a uniform margin above 3/4 on every nonempty finite indicator. The corresponding weighted hypothesis also suffices. The constant is sharp, including for the integer-valued parity map on Z.

The distinction between a uniform margin and separately strict inequalities is essential: the parity map has ratio strictly above 3/4 for every nonzero nonnegative finite-support weight, but both hereditary infima equal 3/4. If a map is affine on every cyclic coset but nonaffine globally, the sharp conditional bound is 5/8. No global classification of endpoint maps is asserted.

The report also provides a uniform indicator witness of support at most max{6, 2 ceil(3/sqrt(32 epsilon))}; the exponent 1/2 is sharp for indicators. Binomial weights yield support at most max{6, 2m+1} and excess at most (1/2)4^(-m). The weighted support bound is not claimed to be optimal.

This is an AI-assisted mathematical research manuscript. It is not a refereed publication, a publication-priority claim, or a Lean kernel certificate. The written proof supplies the arbitrary-group and arbitrary-parameter statements; the companion is a bounded exact diagnostic.

## Contents

- `Report288.pdf`: standalone article
- `Report288.tex`: editable LaTeX source
- `companion/exact_checks.py`: bounded standard-library exact checks
- `companion/README.md`: computational scope, cases and API bounds
- `tests/test_companion.py`: independent counts, formulas and input validation
- `tests/test_build.py`: build, inventory, process, archive and refusal regressions
- `build.py`: guarded offline reproduction and deterministic packaging
- `REPRODUCING.md`: commands, toolchain and reproducibility boundaries
- `SOURCES.md`: public source inventory and attribution
- `MANIFEST.sha256`: distribution byte inventory, excluding itself

Only these authored files and the empty-package initializer are included. Earlier reports remain separate. There are no raw Lean snapshots, upstream archives, private reviews, generated logs or reproduction receipts in the public ZIP.

## Run the exact checks

From the extracted `Report288` directory:

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B tests/test_companion.py
    python3 -I -B tests/test_build.py

The companion uses only Python's standard library and exact integers and fractions. It requires no network access or third-party packages. The diagnostic takes no command-line arguments and prints deterministic JSON. Runtime checks use explicit exceptions, so they remain active under `python3 -O`.

## Reproduce

Choose a fresh absolute directory outside the extracted source tree:

    python3 -I -B build.py reproduce --output /tmp/report288-replay

This runs both test suites and the exact diagnostics in normal and optimized modes, builds the PDF, and writes a deterministic ZIP, a manifest, a ZIP SHA-256 pin and a reproduction receipt. The builder installs nothing and never executes upstream source code. See `REPRODUCING.md` for requirements and failure behavior.

Checksums establish byte identity only. They do not establish mathematical truth, authorship, publication priority or formal verification.
