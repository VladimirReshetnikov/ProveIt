# Hermite limits and finite cancellation on every fixed defect

This research note studies coefficients on a fixed factor-defect diagonal in derivatives of x^(sqrt(x)).

## Proved results

- An exact residual polynomial converges, after the stated normalization, to the probabilists' Hermite polynomial
- Its first correction and all root shifts are explicit; all roots are eventually real and simple
- Every odd defect has the exact central factor k + 2(r-1)
- For each fixed defect r >= 2, at most O_r(sqrt(X)) cancellation cells occur through derivative order X
- The square-root order is attained for defects 2 and 3, with the stated exact constants
- For every fixed defect r >= 4, Schur irreducibility and Siegel's theorem prove only finitely many cancellations and eventual noncancellation; explicit genus-one quartics handle defects 4 and 5

The last statement gives no effective numerical threshold or complete list of integral points. A verified birational elliptic model is included for defect 4, with its integrality and admissibility conditions preserved. The finite-versus-infinite distinction is complete on every fixed defect. The higher-defect finite exceptional lists remain open.

## Files

- `article.pdf`: complete eight-page report
- `article.tex`: editable LaTeX source
- `verify_hermite.py`, `hermite_checks.json`: exact symbolic checks through defect 10, including the weighted Laguerre formulas
- `check_bell_normalization.py`, `check_bell_normalization.json`: 11,935 independent Bell-normalization checks using only the Python standard library
- `check_quartics.py`, `check_quartics.json`: exact completion-of-square and squarefreeness checks
- `birational_model.py`, `birational_model.json`: both elliptic maps and exceptional-point checks
- `build_local.sh`: build helper for the preparation environment

## Reproduction

With Python 3 and SymPy installed, run `python verify_hermite.py`, `python check_quartics.py`, and `python birational_model.py`. The Bell checker needs only Python 3: `python check_bell_normalization.py`.

The report builds with a standard LaTeX installation by running `pdflatex article.tex` twice. Packages used are listed in the source. The supplied build helper includes environment-specific font-map setup and is optional elsewhere.

The finite checks supplement the written proofs; they do not establish infinite nonvanishing, supply a complete integral-point enumeration, or constitute proof-assistant formalization. The Hermite, Schur and Siegel results used as inputs are classical and cited in the report. Source comparison is relative to the pinned ProveIt manuscript, without an exhaustive priority claim.

All rendered pages were inspected. The final build has no overfull boxes, unresolved references or LaTeX warnings. The proofs and final transcription were independently reviewed before sealing.
