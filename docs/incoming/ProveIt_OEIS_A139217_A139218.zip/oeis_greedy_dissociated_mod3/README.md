# Boundary-Defect Rigidity for OEIS A139217 and A139218

This package contains an unrefereed research draft resolving the recurrence
conjectures recorded in OEIS A139217 and A139218.

## Main results

- A139217 has the exact closed form
  `a(n)=3*2^(n-2)+1` for `n = 0,1 (mod 3)` and
  `a(n)=3*2^(n-2)-2` for `n = 2 (mod 3)`, valid from `n=3`.
- Its order-three recurrence begins at `n=6`, not at every `n>4`; the displayed
  OEIS range fails at `n=5`.
- A139218 has an exact dyadic-plus-periodic closed form from `n=4`, proving its
  conjectured recurrence for `n>=7`.
- Both results follow from exact signed-difference-set invariants with a fixed
  finite set of boundary defects.
- The paper also gives rational generating functions, exact counting functions,
  and convergent all-orders inverse expansions on each residue branch.

## Files

- `article.tex` - editable LaTeX source.
- `article.pdf` - compiled paper.
- `verify.py` - exact standard-library verification code.
- `verification_output.txt` - output of a successful verification run.
- `OEIS_update_draft.txt` - proposed OEIS comments and formulas.

## Reproduce the checks

```bash
python verify.py
```

The program uses exact integer and rational arithmetic. It generates the greedy
sequences directly, checks the boundary-defect identities on finite prefixes,
verifies the closed forms and recurrence ranges, and checks the exact counting
functions.

## Rebuild the PDF

A standard TeX Live installation with `latexmk` or `pdflatex` is sufficient.
For example:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

## Status

The proof is intended to be independently checkable, but the draft has not yet
been peer reviewed or formalized in Lean. The computational script is a
reproducibility aid, not the proof of the infinite statements.
