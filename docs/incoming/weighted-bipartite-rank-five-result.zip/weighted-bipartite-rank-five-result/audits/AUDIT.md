# Independent mathematical audit: general two-tail Lorentzian theorem

Review date: 2026-10-01. Reviewer reconstructed the proof after its production, did not participate in deriving its principal-line construction or PSD identity, and imported no producer code.

## Verdict

**MATHEMATICAL APPROVAL.** The proposed all-q theorem and the actual-rank-at-most-five bipartite corollary are correct as stated for finite bipartite graphs with physically disjoint shores and independent nonnegative vertex activities. The proof is ordinary and has no finite-certificate dependency. The exact corroborating tests accompanying this review are not proof premises.

Final approved source:
`/workspace/shared/general-two-tail-lorentzian-proof/GENERAL_TWO_TAIL_THEOREM.md`
SHA256 `ca214800b80472a5790ac5f95042dfdfab44d13fa8acd189f83f1680eb6fc4b3`.

Final source reviewed after two revisions: scalar entries were renamed to avoid collision with the old-basis polynomial; the one-tail operator was replaced by exact head aggregation. The final aggregation explicitly discards isolated Y heads before summing activity. This last clarification was required and was verified before final approval. The initial source hash was 0495044454e94172641d4fa4459cb2dca9b4ae91f98ce50de10455ab3f769fe5; the intermediate revision b12665b34dc93206ad83fe07090a6e6b279f10eff7e3ec6d883712c12f2852bd lacked that isolated-head clarification.

## Precisely approved statements

Let the shores be P∪X and Q∪Y, |P|=2, |Q|=q, with no X–Y edge. Count each feasible equally-sized endpoint pair once. With independent nonnegative vertex activities, the polynomial

F(t,z,z_Q)=Σ_(S,T feasible) u_S v_T t^|S| z^(2−|T∩Y|) ∏_(j∈Q\T)z_j

is homogeneous of degree q+2 and Lorentzian for every q≥0. Thus its ordinary support coefficients are ULC with order q+2 after identifying all monomers. This alone is not a rule for lowering that normalization after a rank drop.

For an arbitrary finite bipartite graph, remove zero-activity vertices and choose a minimum vertex cover of the resulting active graph. If some minimum cover has at most two vertices on one shore, the support coefficients are ULC at their actual degree. In particular this holds whenever the actual matching rank is at most five.

No conclusion about directed relations with physically overlapping tail/head copies, arbitrary rank-six graphs, real-rootedness, stability, or strict inequalities follows.

## 1. Primary-source dependencies checked

Checked against Brändén–Huh, *Lorentzian polynomials*, primary author manuscript https://arxiv.org/pdf/1902.03719 (v8, July 17, 2024):

- Theorem 2.10: nonnegative linear substitutions
- Corollary 2.11: nonnegative directional derivatives
- Theorem 2.25: closedness and the M-convex-support/quadratic-derivative characterization
- Corollary 2.32: products
- Theorem 3.10: matroid basis polynomials
- Example 2.26: bivariate Lorentzian polynomials and binomial-normalized ULC

The finite-capacity operator theorem (Theorem 3.2) was checked during review of the initial version but is not a dependency of the final proof. All uses preserve homogeneous degree and involve nonnegative substitutions. No stable-matroid or half-plane-property hypothesis is used.

## 2. Independent endpoint-to-basis reconstruction

For a finite head set R, add one dummy d_j adjacent only to each head j. The transversal matroid on actual tails plus those dummies has rank |R| because all dummies form a basis. An endpoint support (S,T) corresponds bijectively to the matroid basis

S ∪ {d_j:j∈R\T}.

Conversely each basis determines exactly that S and T; Boolean feasibility, rather than witness multiplicity, is precisely matroid basis membership. Substituting u_i t for a real tail variable and z_j/v_j for dummy j, then multiplying by ∏_R v_j, gives the desired support weight. Initially v_j>0; coefficientwise limits handle zeros without any undefined final expression.

Applying this construction to all Q∪Y heads gives a Lorentzian G0 whose z exponent is |Y|−|T∩Y|. Its support is translated by the fixed amount 2−|Y| to get supp(F). M-convexity is invariant under this translation by direct inspection of its exchange axiom, even when the translation is negative, since the resulting support is still nonnegative. No claim that Lorentzianity survives monomial division is used.

Differentiating F in a Q-monomer deletes that head and yields exactly the smaller-q endpoint polynomial. This equality includes weights and all zero-activity cases.

## 3. Principal-line seed checked independently

A transversal matroid is represented over a characteristic-zero rational-function field by a generic incidence matrix. Each permitted incidence has a distinct algebraically independent entry. A maximal minor is nonzero exactly when its determinant has a matching permutation; distinct permutations give distinct monomials, so they cannot cancel.

Let A,B be the two distinguished columns and add C_i=α_iA+β_iB with new generic coefficients. For an old (q−1)-set I, det(I,C_i)=α_i det(I,A)+β_i det(I,B), hence its extension family is the Boolean union. For an old (q−2)-set, every pair of distinguished columns extends it exactly when A,B do. Three distinguished columns are dependent. Therefore the stated basis polynomial has exactly the claimed five Boolean families and contains no hidden witness multiplicities.

After setting every clone variable h_i=y/m, their linear sum becomes y and their pair sum becomes (m−1)y²/(2m). Closedness gives the precise y²/2 coefficient. This remains true when either A or B is a loop or when they are dependent: the corresponding determinant terms simply vanish.

After positive head-weight specialization, the intersection mass I=A0+B0−U0 satisfies 0≤I≤min(A0,B0) because U0 counts the union and I counts the intersection, with identical nonnegative weights on the old sets.

## 4. Seed Hessian and its q=1 boundary

For q≥2, the t^(q−2) derivative of the seed, divided by (q−2)!, has t-Hessian pivot q(q−1)c, cross vector (q−1)(ell',L), and remaining Hessian block [[Hq,D'],[D'^T,eJ]]. The positive-pivot Schur complement is equivalent to

E_q=(q−1)(ell',L)(ell',L)^T−qc[[Hq,D'],[D'^T,eJ]] ≥0.

All factorials and the J_33=1 entry agree with the y²/2 seed coefficient.

At q=1, the seed is linear. Hq,D',e are all zero, and q−1=0; thus E_1=0 directly. No derivative of negative order is used. A rank-zero clone seed is not needed, because q=0 has its own direct quadratic proof.

## 5. Interface PSD proof checked independently

With v=(a,b,0), w=Jv, β=ab, the first interface matrix is exactly

ww^T/(2β)−J = (b,−a,b−a)(b,−a,b−a)^T/(2β)+e_3e_3^T.

For the second, substituting U0=A0+B0−I produces exactly the two embedded 2×2 blocks stated in the source. Their determinants both simplify to 2A0B0−I². Since I²≤A0B0 and all their diagonal entries are nonnegative, both blocks are PSD, including every boundary case. Thus cR1+R2 is PSD. No abstract Lorentz-cone closure or unproved matrix inequality remains.

## 6. Endpoint decomposition checked independently

Partition supports by the number of selected Y heads.

- Zero Y heads: the selected P subset is empty, {p0}, {p1}, or both, giving U0, atUA, btUB, or abt²V
- One Y head and one P tail: its activity contributes the applicable a or b and the old Q support lies in U0
- One Y head and both P tails: a private Y head forces which P tail remains for Q; a shared Y head permits either extension and contributes the Boolean union U, exactly once
- Two Y heads: both P tails must be selected and matched to those heads; the remaining Q matching uses only X. Feasible pairs have mass L0L1+H(L0+L1)+e₂(common activities)

This proves the three-layer expression without double counting. It also shows 0≤M≤Mmax because 2e₂(common activities)≤H². The highest three t-coefficients in the source follow directly.

## 7. Top quadratic and all-q identity

Writing the top coefficients as F=f_(q+2)t^(q+2)+f_(q+1)t^(q+1)+f_qt^q+…, the q-th t derivative, divided by q!, is

[(q+2)(q+1)/2] f_(q+2)t²+(q+1)f_(q+1)t+f_q.

Its positive-pivot Schur complement is precisely

(q+1)∇f_(q+1)∇f_(q+1)^T−(q+2)f_(q+2)Hess(f_q) ≥0.

The x congruence factor is 1/(βM). Under it, only the z-diagonal depends on M, with negative coefficient −2(q+2)βcg. Replacing M by Mmax is therefore valid in the claimed direction. Compression by the fixed mass vector m gives exactly the matrix in the source.

I re-expanded the three summands of identity (10) independently. The resulting coefficients are:

- x outer product: q+1
- x–L cross product: (q+1)β
- x–w cross product: −c
- x–D block: −(q+2)βc
- LL^T: (q+1)β²
- Lw^T+wL^T: (q+1)βc
- ww^T: (q+1)c²
- J: −(q+2)βc(c+L^Tv+βe)

They agree exactly with the target matrix. Every summand is PSD by the seed and interface arguments. The scalar factors (q+2)/q and 2/q are positive for every q≥1; q=1 is included directly.

## 8. First-layer quadratic and induction

I independently calculated the first-layer quadratic as

q(q+1)ht²/2+2qgtz+qtd+2zell+D2.

Its (t,z) block has one positive and one negative eigenvalue when g>0. The Schur complement on x is exactly −N/(qg²), with N as stated in the source. This N is linear in each Y-type activity mass, because g and ell are Y-independent while h,d,D2 are linear in those masses. One unit Y head of any type gives z times an ordinary transversal-matroid basis specialization. Therefore its derivative is Lorentzian and its N is PSD. Summing these PSD matrices proves the arbitrary-mass case; the proof does not incorrectly assume that arbitrary sums of Lorentzian polynomials are Lorentzian.

For induction, every derivative of total order q either contains a Q-monomer derivative, which reduces to a previously proved graph, or uses only t,z. The latter possibilities have z order zero, one, two, or at least three, and are handled respectively by the top matrix, first-layer lemma, no-Y matroid derivative, or zero. These are all cases. M-convex support plus the quadratic-derivative characterization therefore proves Lorentzianity.

At q=0, the discriminant is exactly the displayed square plus 4ab(H²−S), nonnegative. This is a complete quadratic base case.

## 9. Degenerate parameters and activity limits

Adding q private X tails of activity epsilon creates a positive full X-to-Q matching. Adding two shared Y heads of activity epsilon makes M>0. Perturbing zero P and Q activities upward makes β>0 and allows the temporary division by Q activities. The graph class is preserved. After activity specialization, the polynomials still have only the same q+2 formal variables t,z,z_Q, so coefficientwise convergence occurs in a fixed finite-dimensional homogeneous polynomial space. Terms using added vertices vanish as epsilon→0. The final support polynomial is polynomial in all original activities and is recovered exactly. Both the relevant matrix signature condition and Lorentzianity are closed.

The first-layer g=0 case is treated by the same private-X/Q perturbation. No zero vertex is deleted inside a role-overlap model, because no such model is being claimed.

## 10. Actual-degree assembly and a simpler r=1 proof

After removing zero-activity vertices, every remaining feasible support has positive weight. Its largest rank is exactly the graph's maximum matching size d; deleting matching edges supplies every lower positive rank. The standard alternating-path construction from a maximum matching gives a vertex cover of cardinality d, and the source includes its construction. Swap shores so the cover's smaller side has r≤floor(d/2) vertices. When d≤5, r≤2 and there is no edge between the two exterior sets.

For r=0, the standard dummy-basis specialization has order d.

For r=1, every nonisolated exterior head has the same sole neighbor p. At most one of these heads can occur in a feasible support. Thus they can be replaced exactly by a single head y* of activity R equal to the sum of their activities. The graph now has q+1 head vertices, and its standard dummy-basis specialization is exactly the required order-(q+1) homogenization. This argument handles arbitrary q and R≥0 by continuity and removes any need for a finite-capacity operator theorem or an earlier pendant-head result.

For r=2, the proved theorem has order q+2=d. Hence the normalization in every case equals the actual degree; no monomial cancellation or padded normalization is used.

## 11. Independent exact corroboration

`check.py` imports no producer code. It verifies the two interface identities, the first-layer Schur complement, the generic-q three-term decomposition, the q=0 discriminant and q=1 zero-block convention symbolically. The x-block dimension is two and q remains symbolic; this contains every diagonal, off-diagonal and cross-entry type needed for the arbitrary-dimension entrywise identity.

It also independently constructs support sets by a Boolean subset-DP matching oracle and compares them to the endpoint partition, checking multiplicity one. It covers all graphs for (q,|X|,|Y|)=(0,0,3),(1,2,2),(2,1,2), and additional seeded cases through q=5. The recorded run checks 53,026 feasible supports. A further 168 exhaustive one-tail graphs verify the weighted aggregation, including isolated Y heads. These tests are corroboration, not the reason the all-q theorem holds.

All checks passed. There are no unresolved mathematical blockers.
