# Integrated paper and package review

Date: 2026-10-01
Verdict: APPROVED FOR ARCHIVE FREEZE; final frozen-archive extraction/replay will receive a separate receipt.

## Scope

This review checks the six-page paper, final approved source note, README, replay driver, all four checkers and receipts, the exact nonreal example, and the PDF rendering. It supplements the independently reconstructed ordinary-proof audit in AUDIT.md and approval.json.

The approved source note is SHA256 ca214800b80472a5790ac5f95042dfdfab44d13fa8acd189f83f1680eb6fc4b3. The final article accurately transcribes its all-q theorem and minimum-cover actual-degree corollary. There are no unresolved mathematical corrections.

## Mathematical transcription

- Endpoint pairs are Boolean support objects and are counted once; the polynomial is not a matching-witness generating function
- Independent nonnegative vertex activities and physically disjoint bipartite shores are specified
- The transversal-basis specialization and support-only translation argument are retained; there is no unsupported Lorentzian monomial-division claim
- The first-layer lemma includes its full indefinite-pivot Schur-complement calculation and the justified linearity of the PSD matrix in three head masses
- The principal-line seed correctly uses generic incidence determinants, handles dependent or loop columns, and obtains the exact one-half clone coefficient in a fixed variable space
- All matrix entries and factorial constants in the seed Hessian, two interface certificates, and three-term generic-q decomposition agree with the independently approved proof
- Sections 3–5 are explicitly scoped to q≥1; q=1 is handled by the zero seed block and q=0 by the direct quadratic discriminant
- The perturbation arguments preserve the graph class and converge in fixed polynomial variables
- The derivative induction exhausts every quadratic derivative class
- The minimum-cover argument applies after deleting zero-activity vertices, so the normalization is the actual surviving degree
- The one-tail aggregation discards isolated Y heads before summing activity, including the corrected boundary case
- The wider any-rank minimum-cover corollary is stated accurately; overlapping directed roles and the balanced rank-six case are not claimed

The Brändén–Huh results cited in the article were checked against the primary manuscript in the underlying independent audit. No finite certificate, prior rank-four archive, operator-preserver theorem, or stable-matroid hypothesis is a proof premise.

## Nonreal example

I independently reconstructed its coefficients from all four endpoint population counts, without importing any packaged checker. The complete-block feasibility conditions are x≤q and y≤p, with p+x=q+y. This produces 20 feasible quota classes and the unscaled vector

[1, 65000, 397800000, 143170000000, 5347500000000, 54000000000000].

At t/100 this is exactly [1,650,39780,143170,53475,5400]. The discriminant was independently recomputed as

−251488224963149496162478560000000.

Exact rational root counting independently gives three negative roots, no positive roots, and one nonreal conjugate pair. This is a nonreal example, not a ULC counterexample. The text and contributor receipt use that distinction correctly.

## Replay and receipts

All four packaged checkers were copied into new temporary subdirectories and run from those copies. Every deterministic receipt field matched its packaged receipt, and every optimization-mode invocation was rejected. The new record is integrated-replay.json.

The paper and README accurately distinguish the independent 53,026 feasible supports on 1,564 graph configurations from whole-polynomial identities, and separately report 168 one-tail aggregation graphs. The producer's 1,704 weighted graph cases, including 1,664 ranks at most five and 40 higher full-degree cases, match its receipt. Contributor checks are identified as contributor corroboration, not independent review.

The replay driver was inspected: it requires exact manifest coverage, checks approval and QA pins, copies checkers into temporary directories, compares all deterministic fields, rejects optimization mode, and checks that released files remain unchanged. Its full packaged execution must occur after the producer writes the final manifest and freezes the archive. SHA checking alone is not being treated as mathematical verification.

## PDF inspection

I independently rendered and visually inspected each of pages 1–6 of the final PDF. All equations, matrices, coefficient strings, section transitions and references are readable, with no clipping, overlap or missing content. The compact six-page layout preserves the full proof. The recorded PDF hash matches the visually inspected document and the producer's QA record.

## Hashes and release boundary

Final TeX: f97a6cccc6ff4a28f7d549006a3848a36ff435916bf4138fc55f439f7d546047

Final PDF: 30796fc79b81694f35964845269f910b83de645384a70d73eed60dfb493dc8ff

Replay driver: fa9a85202d4299e694a875222184595291c1e193db018fab95281f420d94f50e

The corresponding integrated-approval.json binds all reviewed substantive files by relative-path SHA256 values. This approval allows the archive to be frozen; it does not substitute for the subsequent safe-extraction replay of the exact frozen bytes.
