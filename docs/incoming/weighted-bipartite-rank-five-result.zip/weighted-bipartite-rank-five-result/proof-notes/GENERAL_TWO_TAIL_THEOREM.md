# A general two-tail Lorentzian theorem and weighted bipartite rank five

Status: proposed ordinary theorem, awaiting independent final review. October 1, 2026. The principal-line seed and PSD decomposition were developed jointly with the independent balanced-core researcher; a separate final review is required. All earlier frozen releases remain unchanged.

## 1. Statements and normalization

Let G be a finite bipartite graph with physically disjoint shores P union X and Q union Y, where P={p0,p1}, |Q|=q>=0, and X×Y has no edges. The internal P×Q graph and BOTH exterior blocks are completely arbitrary. Give each vertex its own independent nonnegative activity, u on the left and v on the right. A feasible endpoint support is a pair (S,T) of equally large shore subsets admitting a perfect matching. Count each pair once, with weight equal to the product of its selected activities.

**Proposed Theorem A.** The polynomial

  F_G(t,z,z_Q)=sum_(S,T feasible) wt(S,T)t^|S|
                  z^(2-|T intersect Y|) product_(j in Q minus T) z_j

is Lorentzian, homogeneous of degree q+2. Thus Gamma_G(t)=sum_k gamma_k t^k is ultra-log-concave with normalization order q+2. If its surviving degree is q+2, this is actual-degree ULC. No general cancellation of the homogenizing variable is asserted.

**Proposed Theorem B.** Every weighted bipartite endpoint-support polynomial of actual matching rank at most five is ULC normalized by its actual surviving degree, for arbitrary independent nonnegative vertex activities.

The proof of A is ordinary for all q and all finite populations. The proof of B chooses a minimum cover at the actual degree d<=5, whose smaller shore has at most two vertices. It then uses A, the one-tail exterior-head aggregation, or a one-shore matroid basis specialization. Thus no earlier finite rank-four theorem is needed. These statements concern physically disjoint bipartite shores, not directed role covers with physical collisions. Real-rootedness and blanket strictness are not claimed.

## 2. Lorentzian facts and automatic derivatives

The primary inputs are Brändén–Huh, Lorentzian polynomials, Annals of Mathematics 192 (2020), 821–891: nonnegative linear substitutions, closedness and the M-convex/quadratic-derivative characterization, products, and matroid-basis Lorentzianity. The source manuscript is https://arxiv.org/pdf/1902.03719.

For every graph in the stated class, F_G has M-convex support. Indeed, the usual transversal matroid on all left vertices and private dummies for all Q union Y heads has rank q+|Y|. Its basis specialization gives

  G0=sum_support wt t^|S| z^(|Y|-|T intersect Y|)
                      product_(unused Q) z_j.

This is Lorentzian (including zero activities by limits). Since at most two Y heads can be selected, the supports of G0 and F_G differ by a fixed translation in the z-coordinate. Such translation preserves the M-convex exchange axiom. No Lorentzian monomial-division rule is used.

Also partial_(z_j)F_G=F_(G-j). The coefficient of z² is the degree-q matroid basis specialization B(t,z_Q) for supports using no Y head. Consequently partial_t^(q-2) partial_z² F_G is Lorentzian whenever q>=2; derivatives with three z differentiations vanish.

A previously checked ordinary first-layer lemma supplies the other automatic derivative:

  partial_t^(q-1) partial_z F_G

has at most one positive Hessian eigenvalue for every q>=1 and every graph in this class. Here is its full argument. Write F_G=z²B+zt C+t²D and

  B=g t^q+e(x)t^(q-1)+...,
  C=h t^q+d(x)t^(q-1)+D2(x)t^(q-2)+...,

where x=z_Q; for q=1 put D2=0. The one-Y layer C is linear in the masses L0,L1,H of the three nonempty Y-neighborhood types {p0},{p1},P. The quantities g,e are independent of Y.

After division by (q-1)!, the quadratic derivative is

  [q(q+1)/2]h t²+2qg tz+q t d+2z e+D2.

For g>0 its (t,z) Hessian block has determinant -4q²g². Its Schur complement on x is -N/(qg²), where

  N=qg[d' e'^T+e' d'^T]-qg² Hess(D2)-(q+1)h e'e'^T.

Here primes mean gradients in x. Thus the signature condition is equivalent to N positive semidefinite. This N is linear in L0,L1,H. For one Y head of a fixed type and unit weight, F=z times an ordinary rank-(q+1) matroid basis specialization, so F is Lorentzian and N is positive semidefinite. Nonnegative linear combinations prove the general case. If g=0, add q private X tails of activity epsilon and perturb zero Q activities; then pass to the limit. This proves the lemma, with no restriction on core rows or exterior-head types.

It remains to control the top quadratic partial_t^q F_G. That is the new content below.

## 3. A principal-line clone seed

Let M be the rank-q transversal matroid on old elements X and private Q dummies, together with two additional elements A,B having the original core neighborhoods J0,J1. Its rank is q because the dummy set is a basis. Write the old-subset polynomials as

  U0: old q-element bases;
  UA, UB: old (q-1)-sets extendable by A or by B, respectively;
  U: old (q-1)-sets extendable by at least one of A,B;
  V: old (q-2)-sets extendable by both distinct elements A,B.

Every coefficient is Boolean feasibility, not matching multiplicity. In particular U is the extension polynomial for a tail with neighborhood J0 union J1.

We construct a Lorentzian seed which contains all five polynomials with the correct half-factor. Represent the transversal matroid by the generic incidence matrix over a rational-function field: every permitted incidence has its own algebraically independent entry. A minor is nonzero exactly when its determinant has a perfect-matching monomial, because distinct permutations use distinct monomials and cannot cancel.

Add columns C_i=alpha_i A+beta_i B, where all alpha_i,beta_i are algebraically independent over that field. For an old (q-1)-set I,

  det(I,C_i)=alpha_i det(I,A)+beta_i det(I,B),

so I+C_i is a basis exactly when either extension works. For an old (q-2)-set I,

  det(I,C_i,C_j)=(alpha_i beta_j-beta_i alpha_j)det(I,A,B),

and the A+C_i and B+C_i determinants are likewise nonzero exactly when I+A+B is a basis. Any three of A,B,C_i are dependent. These statements include loops or dependent A,B because the relevant minors simply vanish.

The resulting rank-q matroid basis polynomial is therefore

  U0+xA UA+xB UB+(sum_i h_i)U
    +[xA xB+(xA+xB)sum_i h_i+sum_(i<j)h_i h_j]V.

Set h_i=y/m for m new columns and pass to m→infinity. Matroid-basis Lorentzianity, nonnegative linear substitution and closedness give the homogeneous Lorentzian seed

  S=U0+xA UA+xB UB+yU+[xA xB+xA y+xB y+y²/2]V.          (1)

This is a representable-matroid construction, not an HPP assumption. The factor 1/2 is the exact limit binom(m,2)/m².

## 4. Side coefficients and the rank-three interface matrix

Assume temporarily positive P and Q activities and a positive full X-to-Q matching. Make the standard old-variable specialization: each X variable is its activity times t, each private Q dummy is its monomer divided by its head activity, and multiply by the product of Q activities. Keep xA,xB,y as independent variables. All U polynomials then remain homogeneous of the displayed degrees and the seed remains Lorentzian.

Put a=u_p0, b=u_p1, beta=ab>0. Write the highest t coefficients as

  U0=c t^q+ell(x)t^(q-1)+Q2(x)t^(q-2)+...,
  (UA,UB,U)^T=L t^(q-1)+D(x)t^(q-2)+...,
  V=e t^(q-2)+...,

where c>0, ell and the three components of D are linear, and Q2 is quadratic. For q=1, terms with negative t powers are absent, and set Q2=0,D=0,e=0. Let ell' be the gradient of ell, Hq=Hess(Q2), and let the columns of the q×3 matrix D' be the gradients of the three components of D. Define

  J=[[0,1,1],[1,0,1],[1,1,1]].

For q>=2, differentiate (1) q-2 times in t and divide by (q-2)!. The positive t-Hessian pivot is q(q-1)c, and its cross row is (q-1)[ell';L]^T. The Schur-complement criterion for the Lorentzian quadratic gives

  E_q=(q-1)[ell';L][ell';L]^T
                -q c [[Hq,D'],[D'^T,eJ]] >=0.             (2)

For q=1 the displayed block Hq,D',eJ is zero, so E_1=0 and (2) still holds directly.

The entries L=(lambda_A,lambda_B,lambda_U)^T are nonnegative. Since the third old-set family is exactly the union of the first two, if I=lambda_A+lambda_B-lambda_U then

  0<=I<=min(lambda_A,lambda_B).                                      (3)

These inequalities hold after arbitrary nonnegative activity specialization and will provide the only extra cone condition.

## 5. Two explicit positive semidefinite interface matrices

Set v=(a,b,0)^T, w=Jv, and beta=ab>0. The following matrices are positive semidefinite whenever L=(lambda_A,lambda_B,lambda_U)^T satisfies (3):

  R1=ww^T/(2beta)-J,
  R2=wL^T+Lw^T-(L^T v)J.                                 (4)

Here are ordinary explicit certificates. First, with r=(b,-a,b-a)^T and e3=(0,0,1)^T,

  R1=rr^T/(2beta)+e3e3^T.

Second, write I=lambda_A+lambda_B-lambda_U. Then R2 is the sum of a times the matrix supported on coordinates {1,2} with block

  [[2lambda_B, 2lambda_B-I], [2lambda_B-I, lambda_A+2lambda_B-2I]],

and b times the matrix supported on coordinates {0,2} with block

  [[2lambda_A, 2lambda_A-I], [2lambda_A-I, 2lambda_A+lambda_B-2I]].

Every displayed diagonal is nonnegative because 0<=I<=min(lambda_A,lambda_B). Both 2×2 determinants equal 2lambda_A lambda_B-I²>=0. Therefore both embedded blocks, and R2, are positive semidefinite. No abstract cone theorem is needed. Consequently

  R=c R1+R2>=0.                                          (5)

## 6. Exact top-block decomposition

Let L0,L1,H be the two private and shared Y activity masses and S=e2(common Y activities). Put

  m=(L1,L0,H)^T,
  M=L0L1+H(L0+L1)+S,
  Mmax=(m^T Jm)/2=L0L1+H(L0+L1)+H²/2.

Thus 0<=M<=Mmax. The full-degree case has M>0. The exact endpoint decomposition is

  F_G=z²[U0+t(aUA+bUB)+beta t²V]
       +zt[(w^T m)U0+beta t (m0 UA+m1 UB+m2 U)]
       +beta M t² U0.                                    (6)

For the one-shared-head term, both P tails are selected and feasibility of the remaining Q tail is exactly membership in the union family U. This is why no matching witness is double-counted.

Write F_G=sum_k t^k f_k(z,x), and let

  g=c+L^T v+beta e,
  h=(beta L+c w)^T m,
  d(x)=(w^T m)ell(x)+beta D(x)^T m.

The highest three coefficients are exactly

  f_(q+2)=beta M c,
  f_(q+1)=z h+beta M ell,
  f_q=z²g+z d+beta M Q2.                                 (7)

The top quadratic partial_t^q F_G has at most one positive Hessian eigenvalue precisely when

  (q+1) gradient(f_(q+1))gradient(f_(q+1))^T
                   -(q+2) f_(q+2) Hess(f_q) >=0,          (8)

by its positive t pivot. Gradients in (8) use (z,x).

After congruence scaling the x coordinates by 1/(beta M), (8) has x block

  K=(q+1)ell'ell'^T-(q+2)c Hq,

cross column [(q+1)beta ell'L^T-c ell'w^T-(q+2)beta c D']m,
and z diagonal (q+1)h²-2(q+2)beta M c g. Increasing M to Mmax only decreases this z diagonal, so it suffices to prove the worst bound.

Consider the following (q+3)×(q+3) block matrix on x and the three mass coordinates:

  A=[[K, (q+1)beta ell'L^T-c ell'w^T-(q+2)beta cD'],
     [transpose, (q+1)(beta L+c w)(beta L+c w)^T
                                      -(q+2)beta c g J]].             (9)

The required worst-bound matrix is a compression of A by the chosen mass vector m. Thus A>=0 is sufficient. In fact the following exact identity proves it:

  A=((q+2)/q) diag(I_q,beta I_3) E_q diag(I_q,beta I_3)
       +(2/q)[ell'; beta L-(q c/2)w][ell'; beta L-(q c/2)w]^T
       +blockdiag(0_(q×q),(q+2)beta c R).                  (10)

Every term is positive semidefinite by (2) and (5). The identity is checked blockwise: the x block and cross block match immediately; the mass block combines to

  (q+1)beta²LL^T+(q+1)beta c(Lw^T+wL^T)+(q+1)c²ww^T
                  -(q+2)beta c(c+L^Tv+beta e)J,

exactly the lower block in (9). This proves the top quadratic signature condition for every q>=1 under the temporary positive/full-rank assumptions.

Remove those assumptions by adding q private X tails and two shared Y heads of activity epsilon, and perturbing zero P/Q activities upward. Then beta,M,c>0, while the resulting endpoint polynomials converge to the original polynomial. The signature condition is closed, so the top quadratic assertion holds for all original graphs and all nonnegative activities.

## 7. Induction and proof of Theorem A

At q=0 the endpoint polynomial is the quadratic

  z²+Czt+abMt²,
  C=a(L0+H)+b(L1+H),
  M=L0L1+H(L0+L1)+S.

It is Lorentzian because

  C²-4abM=[a(L0+H)-b(L1+H)]²+4ab(H²-S)>=0.

Induct on q. The support is M-convex by Section 2. Any derivative of order q involving a Q monomer is a derivative of the smaller-head polynomial F_(G-j), which is Lorentzian by induction. Repeated Q-monomer derivatives give zero. Among derivatives using only t,z, those with at least three z derivatives are zero; the z² derivative is the no-Y matroid derivative when q>=2; the z derivative is controlled by the first-layer lemma; and the t-only derivative is controlled by (10). Therefore every quadratic derivative has at most one positive eigenvalue, and F_G is Lorentzian.

The empty support has coefficient one, so the output never vanishes. Identifying all monomers gives sum_k gamma_k t^k z^(q+2-k), establishing order-(q+2) ULC. This completes the proposed ordinary proof of A.

## 8. Actual weighted matching rank at most five

Delete every zero-activity vertex from an arbitrary weighted bipartite graph. Supports containing such a vertex have zero weight, so this changes no coefficient. The surviving degree is the maximum matching size d of this active graph: every maximum matching gives a positive support, and every feasible support has that matching size. Deleting matching edges also gives positive supports at every smaller size.

If d=0 then Gamma=1. Otherwise choose a minimum vertex cover of size d. For clarity, the standard alternating-path construction supplies it: from a maximum matching, take vertices reachable by alternating paths from unmatched left vertices; the union of unreachable left vertices and reachable right vertices is a cover containing exactly one endpoint of each matched edge, hence has size d.

After exchanging the two shores if necessary, the cover consists of r<=floor(d/2)<=2 left vertices P and q=d-r right vertices Q. Put all other vertices in X,Y. There are no X×Y edges because P union Q is a cover.

- r=0: every usable head lies in Q. The degree-d support homogenization is the rank-d transversal basis specialization with private Q dummies, hence Lorentzian.
- r=1: every nonisolated Y head is private to the unique P tail, so at most one Y endpoint can be selected. Discard isolated Y heads, which never belong to a support, and replace the remaining Y heads by one head of activity R=sum_(y in Y adjacent to p)v_y with the same sole neighbor. Feasibility of every remaining endpoint choice is unchanged, and the weights of its possible Y endpoints sum exactly to R. Thus the support polynomial is unchanged. The new right shore has q+1=d heads, so the ordinary rank-(q+1) transversal matroid with private head dummies gives its Lorentzian homogenization directly. If R=0, retaining the new head at zero activity or taking R down to zero gives the same coefficients. If q=0, the polynomial is simply 1+u_p R t.
- r=2: Theorem A gives order q+2=d.

In all cases the cover order equals the actual surviving degree. The coefficient sequence is unchanged by swapping shores. This proves B by an ordinary argument, with no earlier finite rank-four input.

The same argument also gives actual-degree ULC whenever the active graph has a minimum vertex cover with at most two vertices on one shore, in any rank. It does not imply arbitrary surviving-degree renormalization for a nonminimum supplied cover.

## 9. Proof status and boundaries

The exact generic-q decomposition (10), the principal-line determinant identities, the two explicit interface-matrix identities, all zero/rank limits, and the minimum-cover assembly require final independent review before this theorem is promoted. No finite random search is a proof premise. The previously observed 3,000 PSD mass matrices were diagnostic only.

The one-tail aggregation proof is included above. No earlier theorem package, finite rank-four dependency, stability-preserving operator theorem, stable-monomer theorem, or HPP assumption is needed in the all-q proof and rank-five assembly.

General directed relations with overlapping physical role copies are outside this proof. The balanced three-by-three minimum-cover case at rank six is also outside the global corollary. No literature-wide priority, formal proof-assistant verification, external publication, real-rootedness, or blanket strictness claim is made.
