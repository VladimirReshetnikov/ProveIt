# Weighted bipartite matching supports through rank five

## Results

This release gives a complete ordinary proof of both statements:

1. A finite bipartite graph with a supplied cover of two vertices on one shore and q on the other has the explicitly defined Lorentzian support homogenization of degree q+2. All internal and exterior edges are arbitrary, and all vertex activities are independent and nonnegative.
2. Every finite weighted bipartite endpoint-support polynomial of actual matching rank at most five is ultra-log-concave normalized by its actual surviving degree. More generally, the conclusion holds in any rank when an active minimum cover has at most two vertices on one shore.

A support is a matchable pair of equally sized endpoint subsets and is counted once, regardless of how many matchings witness it. Weights are products of selected vertex activities, not arbitrary matching-witness edge weights.

The all-q proof uses a principal-line matroid seed, explicit positive semidefinite identities, and induction. The actual-degree corollary uses a minimum cover of the positive-activity graph and a simple one-head aggregation when one cover shore has size one. No earlier finite rank-four theorem, large certificate archive, stable-monomer theorem, or operator-preserver theorem is a proof dependency.

The result does not enforce physical collisions between tail and head copies of a general directed relation. The first minimum-cover distribution not settled by the argument is 3+3 at actual rank six. General degree renormalization for a nonminimum supplied cover, real-rootedness and blanket strictness are not asserted. An exact degree-five nonreal example is included.

## Contents

- `article/weighted-bipartite-rank-five.pdf`: six-page comprehensive paper
- `article/weighted-bipartite-rank-five.tex`: editable TeX source
- `proof-notes/GENERAL_TWO_TAIL_THEOREM.md`: independently approved detailed derivation
- `audits/`: independent mathematical approval and integrated paper review
- `reproducibility/independent/`: an independently reconstructed checker and exact receipt
- `reproducibility/contributor/`: symbolic identities, principal-line determinants and a standalone nonreal-example checker
- `reproducibility/producer/`: exact weighted coefficients, minimum-cover normalization and higher-order corroboration
- `qa/visual-qa.json`: final all-page visual inspection record

The preserved proof note retains its historical proposed-status language; the included later final approval supersedes that status without changing the approved source bytes. Historical absolute paths in audit metadata identify the originals; the replay driver checks the packaged copies by exact hashes.

## Replay

Use Python 3.11 or newer and SymPy 1.14.0, then run:

    python verify.py

The driver verifies exact manifest coverage, every approval pin, the final PDF QA hash, and all four checkers. Each checker runs from a temporary directory; every deterministic receipt field must match. No package file is rewritten. Python optimization mode (`-O`) is rejected because the checkers use assertions. No network, numerical optimizer or old release archive is required.

The independent checker verifies 53,026 feasible supports across 1,564 graph configurations, plus 168 separate one-tail aggregation graphs. These are not 53,026 full-polynomial identities. The producer checker verifies 1,704 weighted graph cases, including 1,664 of actual rank at most five, 40 higher full-cover-degree cases, and 783 zero-activity cases. The contributor algebra checker treats the rank parameter symbolically and records 15 principal-line determinant identities; its separate nonreal checker reconstructs endpoint quotas and uses exact Sturm signs and a discriminant.

These finite checks corroborate the ordinary proof. No theorem is inferred from random search, and no population bound is a proof premise.

To rebuild the PDF in a normal TeX Live installation, run `sh build.sh`. The ready-to-read PDF is supplied; byte-identical recompilation is not promised because TeX metadata can vary.

No proof-assistant formalization, literature-wide priority claim or external publication is asserted. Earlier released packages are unchanged.
