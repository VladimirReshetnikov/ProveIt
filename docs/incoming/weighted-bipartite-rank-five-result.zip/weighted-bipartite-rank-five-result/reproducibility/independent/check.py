#!/usr/bin/env python3
"""Independent exact corroboration; imports no producer code.
The ordinary proof, not these finite graph checks, establishes all-q scope.
"""
import argparse, hashlib, itertools, json, random, sys, time
from pathlib import Path
import sympy as s
if not __debug__:
 raise SystemExit('Refusing to run with -O: exact verification requires assertions.')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-note',type=Path,default=Path('/workspace/shared/general-two-tail-lorentzian-proof/GENERAL_TWO_TAIL_THEOREM.md'),help='Path to the exact theorem note being audited')
parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent,help='Directory for receipt.json')
args=parser.parse_args()
ROOT=args.output_dir.resolve(); ROOT.mkdir(parents=True,exist_ok=True)
SOURCE=args.source_note.resolve()
if not SOURCE.is_file():
 raise SystemExit('Source note does not exist: '+str(SOURCE))
start=time.time()
q,a,b,c,e=s.symbols('q a b c e', nonzero=True)
A,B,U=s.symbols('A B U'); beta=a*b
L=s.Matrix([A,B,U]); v=s.Matrix([a,b,0]); J=s.Matrix([[0,1,1],[1,0,1],[1,1,1]]); w=J*v
r=s.Matrix([b,-a,b-a]); ez=s.Matrix([0,0,1]); I=A+B-U
R1=w*w.T/(2*beta)-J
assert (R1-r*r.T/(2*beta)-ez*ez.T).applyfunc(s.factor)==s.zeros(3)
R2=w*L.T+L*w.T-(L.dot(v))*J
Ra=s.zeros(3); Rb=s.zeros(3)
for idx,block,out in [([1,2],s.Matrix([[2*B,2*B-I],[2*B-I,A+2*B-2*I]]),Ra),([0,2],s.Matrix([[2*A,2*A-I],[2*A-I,2*A+B-2*I]]),Rb)]:
 for i in range(2):
  for j in range(2):out[idx[i],idx[j]]=block[i,j]
 assert s.factor(block.det()-(2*A*B-I**2))==0
assert (R2-a*Ra-b*Rb).applyfunc(s.factor)==s.zeros(3)
# Generic x dimension two exhibits every block-entry type; q remains symbolic.
ell=s.Matrix(s.symbols('l0:2')); H=s.Matrix([[s.Symbol('h00'),s.Symbol('h01')],[s.Symbol('h01'),s.Symbol('h11')]])
D=s.Matrix(2,3,s.symbols('d0:6')); V=ell.col_join(L)
HB=H.row_join(D).col_join(D.T.row_join(e*J))
Eq=(q-1)*V*V.T-q*c*HB
K=(q+1)*ell*ell.T-(q+2)*c*H
C=(q+1)*beta*ell*L.T-c*ell*w.T-(q+2)*beta*c*D
g=c+L.dot(v)+beta*e
AA=K.row_join(C).col_join(C.T.row_join((q+1)*(beta*L+c*w)*(beta*L+c*w).T-(q+2)*beta*c*g*J))
T=s.diag(1,1,beta,beta,beta); vv=ell.col_join(beta*L-q*c*w/2)
RR=s.zeros(5); RR[2:5,2:5]=(q+2)*beta*c*(c*R1+R2)
assert (AA-(q+2)/q*T*Eq*T-2/q*vv*vv.T-RR).applyfunc(s.factor)==s.zeros(5)
# Independent first-layer Schur complement.
g0,h0=s.symbols('g0 h0',nonzero=True); ee=s.Matrix(s.symbols('ee0:2')); dd=s.Matrix(s.symbols('dd0:2'))
P=s.Matrix([[q*(q+1)*h0,2*q*g0],[2*q*g0,0]])
Z=s.Matrix.hstack(q*dd,2*ee)
NN=q*g0*(dd*ee.T+ee*dd.T)-q*g0*g0*H-(q+1)*h0*ee*ee.T
assert (H-Z*P.inv()*Z.T+NN/(q*g0*g0)).applyfunc(s.factor)==s.zeros(2)
# q=0 discriminant and q=1 conventions.
L0,L1,Hm,S=s.symbols('L0 L1 Hm S'); Cm=a*(L0+Hm)+b*(L1+Hm); Mm=L0*L1+Hm*(L0+L1)+S
assert s.factor(Cm**2-4*a*b*Mm-(a*(L0+Hm)-b*(L1+Hm))**2-4*a*b*(Hm**2-S))==0
assert Eq.subs({q:1,e:0,**{z:0 for z in list(H)+list(D)}})==s.zeros(5)

def feasible(rows,S,T):
 """Boolean subset DP, left selected S onto exactly selected right T."""
 if S.bit_count()!=T.bit_count():return False
 reached={0}
 for i in range(len(rows)):
  if S>>i&1:
   reached={used|(1<<j) for used in reached for j in range(T.bit_length()) if T>>j&1 and not used>>j&1 and rows[i]>>j&1}
   if not reached:return False
 return T in reached

def powers(n):return range(1<<n)

def compare(q,nx,ny,mask):
 nl=2+nx; nr=q+ny
 edges=[(i,j) for i in range(nl) for j in range(nr) if i<2 or j<q]
 rows=[0]*nl
 for k,(i,j) in enumerate(edges):
  if mask>>k&1:rows[i]|=1<<j
 direct={(S,T) for S in powers(nl) for T in powers(nr) if feasible(rows,S,T)}
 # Partition by selected Y heads, derive each endpoint support exactly once.
 out={}; qmask=(1<<q)-1
 def add(S,T):out[(S,T)]=out.get((S,T),0)+1
 for SX in powers(nx):
  X=SX<<2
  for TQ in powers(q):
   # No Y: enumerate which P tails belong to support, Boolean old extension.
   for PP in range(4):
    if feasible(rows,X|PP,TQ):add(X|PP,TQ)
   for y in range(q,q+ny):
    adj=[i for i in (0,1) if rows[i]>>y&1]
    for i in adj:
     if feasible(rows,X,TQ):add(X|(1<<i),TQ|(1<<y))
    # Both P selected; union of the possible leftover P extensions.
    if any(feasible(rows,X|(1<<(1-i)),TQ) for i in adj):add(X|3,TQ|(1<<y))
   for y,z in itertools.combinations(range(q,q+ny),2):
    cover=((rows[0]>>y&1) and (rows[1]>>z&1)) or ((rows[0]>>z&1) and (rows[1]>>y&1))
    if cover and feasible(rows,X,TQ):add(X|3,TQ|(1<<y)|(1<<z))
 assert set(out)==direct,(q,nx,ny,mask,'support mismatch')
 assert set(out.values())=={1},(q,nx,ny,mask,'multiplicity mismatch')
 return len(direct)
counts=[]; supports=0
for q0,nx,ny in [(0,0,3),(1,2,2),(2,1,2)]:
 bits=2*(q0+ny)+nx*q0
 for mask in range(1<<bits):supports+=compare(q0,nx,ny,mask)
 counts.append({'q':q0,'x':nx,'y':ny,'graphs':1<<bits,'exhaustive':True})
rng=random.Random(547281)
for q0,nx,ny,n in [(3,3,4,120),(4,4,4,50),(1,0,3,20),(5,2,3,30)]:
 bits=2*(q0+ny)+nx*q0
 for _ in range(n):supports+=compare(q0,nx,ny,rng.randrange(1<<bits))
 counts.append({'q':q0,'x':nx,'y':ny,'graphs':n,'exhaustive':False})
# One-tail aggregation must ignore isolated exterior heads.
def gamma_weighted(rows,ul,vr):
 out=[0]*(min(len(ul),len(vr))+1)
 for SS in powers(len(ul)):
  lu=1
  for i,u in enumerate(ul):
   if SS>>i&1:lu*=u
  for TT in powers(len(vr)):
   if feasible(rows,SS,TT):
    vv=1
    for j,vv0 in enumerate(vr):
     if TT>>j&1:vv*=vv0
    out[SS.bit_count()]+=lu*vv
 return tuple(out)
aggregation_graphs=0
for q0,nx,ny in [(0,1,3),(1,1,3),(2,1,3)]:
 edges=[(i,j) for i in range(1+nx) for j in range(q0+ny) if i==0 or j<q0]
 for mask in range(1<<len(edges)):
  rows=[0]*(1+nx)
  for k,(i,j) in enumerate(edges):
   if mask>>k&1:rows[i]|=1<<j
  ul=list(range(2,3+nx)); vr=list(range(3,3+q0+ny))
  R=sum(vr[j] for j in range(q0,q0+ny) if rows[0]>>j&1)
  rr=[rows[0]&((1<<q0)-1)|(1<<q0)]+[row&((1<<q0)-1) for row in rows[1:]]
  old=gamma_weighted(rows,ul,vr); new=gamma_weighted(rr,ul,vr[:q0]+[R])
  old=old+(0,)*max(0,len(new)-len(old)); new=new+(0,)*max(0,len(old)-len(new))
  assert old==new,(q0,nx,ny,mask,'one-tail aggregation')
  aggregation_graphs+=1
receipt={'status':'PASS','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'symbolic_all_q_block_identity':True,'symbolic_interface_identities':True,'symbolic_first_layer_schur':True,'q0_discriminant':True,'q1_E_zero':True,'support_bijection_graphs':counts,'feasible_supports_checked':supports,'one_tail_aggregation_graphs':aggregation_graphs,'seconds':time.time()-start,'dependency_note':'Finite tests corroborate the independent ordinary proof; they are not premises of the all-q theorem.'}
(ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
