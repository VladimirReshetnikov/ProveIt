#!/usr/bin/env python3
if not __debug__:raise SystemExit('Run without -O.')
import sympy as s,json,argparse,time
from pathlib import Path
p=argparse.ArgumentParser(description="Contributor corroboration of the ordinary all-q block proof.");p.add_argument("--output-dir",type=Path,default=Path(__file__).parent);args=p.parse_args();started=time.monotonic()
a,b,c,A,B,U,e,I,n=s.symbols('a b c A B U e I n');beta=a*b
J=s.Matrix([[0,1,1],[1,0,1],[1,1,1]]);v=s.Matrix([a,b,0]);w=J*v;L=s.Matrix([A,B,U]);ell=s.Matrix(s.symbols('l0:3'));H=s.Matrix(3,3,lambda i,j:s.Symbol(f'H{min(i,j)}{max(i,j)}'));D=s.Matrix(3,3,lambda i,j:s.Symbol(f'D{i}{j}'))
g=c+(L.T*v)[0]+beta*e
K=(n+1)*ell*ell.T-(n+2)*c*H
cross=ell*(-c*w+(n+1)*beta*L).T-(n+2)*beta*c*D
mass=(n+1)*(c*w+beta*L)*(c*w+beta*L).T-(n+2)*beta*c*g*J
Target=K.row_join(cross).col_join(cross.T.row_join(mass))
z=ell.col_join(L);E=(n-1)*z*z.T-n*c*(H.row_join(D).col_join(D.T.row_join(e*J)))
S=s.diag(1,1,1,beta,beta,beta);u=ell.col_join(beta*L-n*c*w/2)
R1=w*w.T/(2*beta)-J
R2=w*L.T+L*w.T-(L.T*v)[0]*J
Residual=s.zeros(6);Residual[3:,3:]=(n+2)*beta*c*(c*R1+R2)
assert (Target-((n+2)/n)*S*E*S-(2/n)*u*u.T-Residual).applyfunc(s.expand)==s.zeros(6)
k=s.Matrix([b,-a,b-a]);unit=s.Matrix([0,0,1]);assert (R1-k*k.T/(2*beta)-unit*unit.T).applyfunc(s.simplify)==s.zeros(3)
Ra=s.Matrix([[0,0,0],[0,2*B,2*B-I],[0,2*B-I,A+2*B-2*I]])
Rb=s.Matrix([[2*A,0,2*A-I],[0,0,0],[2*A-I,0,2*A+B-2*I]])
assert (R2.subs(U,A+B-I)-a*Ra-b*Rb).applyfunc(s.expand)==s.zeros(3)
assert s.expand(Ra[1:,1:].det()-(2*A*B-I*I))==0
assert s.expand(Rb.extract([0,2],[0,2]).det()-(2*A*B-I*I))==0
assert s.expand((L.T*J.inv()*L)[0].subs(U,A+B-I)-(2*A*B-I*I))==0
# Generic first-layer indefinite pivot and Schur identity.
h,g=s.symbols('h g',positive=True);qrank=s.symbols('q',positive=True)
dd=s.Matrix(s.symbols('d0:3'));ee=s.Matrix(s.symbols('E0:3'));HH=s.Matrix(3,3,lambda i,j:s.Symbol(f'Q{min(i,j)}{max(i,j)}'))
pivot=s.Matrix([[qrank*(qrank+1)*h,2*qrank*g],[2*qrank*g,0]])
assert (pivot.inv()-s.Matrix([[0,1/(2*qrank*g)],[1/(2*qrank*g),-(qrank+1)*h/(4*qrank*g*g)]])).applyfunc(s.simplify)==s.zeros(2)
cross=s.Matrix.vstack(qrank*dd.T,2*ee.T)
N=qrank*g*(dd*ee.T+ee*dd.T)-qrank*g*g*HH-(qrank+1)*h*ee*ee.T
assert (HH-cross.T*pivot.inv()*cross+N/(qrank*g*g)).applyfunc(s.simplify)==s.zeros(3)
# Literal symbolic determinants of generic incidence-representation columns.
alphas=s.symbols('alpha0:3');betas=s.symbols('beta0:3');det_checks=0
for dimension in [1,2,3,4]:
 Av=s.Matrix(s.symbols(f'A{dimension}_0:{dimension}'));Bv=s.Matrix(s.symbols(f'B{dimension}_0:{dimension}'))
 columns=[s.Matrix(s.symbols(f'X{dimension}_{j}_0:{dimension}'))for j in range(max(0,dimension-1))]
 clones=[alphas[i]*Av+betas[i]*Bv for i in range(3)]
 determinant=lambda cols:s.det(s.Matrix.hstack(*cols))
 old=columns[:dimension-1]
 assert s.expand(determinant(old+[clones[0]])-alphas[0]*determinant(old+[Av])-betas[0]*determinant(old+[Bv]))==0;det_checks+=1
 if dimension>=2:
  old=columns[:dimension-2];base=determinant(old+[Av,Bv])
  assert s.expand(determinant(old+[clones[0],clones[1]])-(alphas[0]*betas[1]-betas[0]*alphas[1])*base)==0;det_checks+=1
  assert s.expand(determinant(old+[Av,clones[0]])-betas[0]*base)==0;det_checks+=1
  assert s.expand(determinant(old+[Bv,clones[0]])+alphas[0]*base)==0;det_checks+=1
 if dimension>=3:
  old=columns[:dimension-3]
  assert s.expand(determinant(old+clones))==0;det_checks+=1
m=s.symbols('m',positive=True)
assert s.limit(m/m,m,s.oo)==1
assert s.limit(m*(m-1)/(2*m*m),m,s.oo)==s.Rational(1,2)
# The q=1 convention really makes the seed PSD input identically zero.
assert E.subs(n,1).subs({c:1,**{entry:0 for entry in list(H)+list(D)},e:0})==s.zeros(6)
# Direct q=0 quadratic discriminant and the common-head moment identity.
L0,L1,H0,S0=s.symbols('L0 L1 H0 S0');C0=a*(L0+H0)+b*(L1+H0);M0=L0*L1+H0*(L0+L1)+S0
assert s.expand(C0*C0-4*a*b*M0-(a*(L0+H0)-b*(L1+H0))**2-4*a*b*(H0*H0-S0))==0
r={'status':'PASS','role':'Contributor exact corroboration; independent mathematical approval is supplied separately','symbolic_rank_parameter_block_decomposition':True,'R1_two_square_identity':True,'R2_two_principal_blocks':True,'both_R2_determinants':'2AB-I^2','union_coefficient_range_needed':'0<=I<=min(A,B)','generic_first_layer_inverse_and_Schur':True,'generic_principal_line_determinant_identities':det_checks,'determinant_dimensions':[1,2,3,4],'clone_limit_coefficients':['1','1/2'],'q1_seed_PSD_zero':True,'q0_base_discriminant':True,'finite_checks_are_supplementary':True,'elapsed_seconds':round(time.monotonic()-started,3)}
args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
