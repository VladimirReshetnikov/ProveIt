#!/usr/bin/env python3
"""Exact support-once reconstruction and Sturm proof of the nonreal boundary example."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
from math import comb
import argparse,json,time
import sympy as s
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path,default=Path(__file__).parent);args=p.parse_args();started=time.monotonic()
# Complete blocks P2-Q3, P2-Y10, X10-Q3. Each core activity is100; every exterior activity is1.
# A support with counts p,x,q,y is feasible iff x<=q and y<=p, with p+x=q+y.
gamma=[];quota_tests=feasible_quotas=0
for k in range(6):
 value=0
 for pp in range(3):
  xx=k-pp
  if not 0<=xx<=10:continue
  for qq in range(4):
   yy=k-qq
   if not 0<=yy<=10:continue
   quota_tests+=1
   if xx<=qq and yy<=pp:
    feasible_quotas+=1;value+=comb(2,pp)*comb(10,xx)*comb(3,qq)*comb(10,yy)*100**(pp+qq)
 gamma.append(value)
assert gamma==[1,65000,397800000,143170000000,5347500000000,54000000000000]
scaled=[]
for k,a in enumerate(gamma):assert a%100**k==0;scaled.append(a//100**k)
assert scaled==[1,650,39780,143170,53475,5400]
t=s.symbols('t');H=sum(a*t**k for k,a in enumerate(scaled));disc=int(s.discriminant(H,t));assert disc==-251488224963149496162478560000000
assert s.gcd(s.Poly(H,t),s.Poly(s.diff(H,t),t)).degree()==0
sturm=[s.Poly(p,t,domain=s.QQ)for p in s.sturm(H,t)]
sgn=lambda x:int(s.sign(x))
negative=[sgn(p.LC())*(-1)**p.degree()for p in sturm];zero=[sgn(p.eval(0))for p in sturm];positive=[sgn(p.LC())for p in sturm]
def variations(signs):
 a=[v for v in signs if v];return sum(x!=y for x,y in zip(a,a[1:]))
vm,vz,vp=map(variations,[negative,zero,positive]);assert (vm-vz,vz-vp)==(3,0)
assert H.subs(t,0)!=0
gaps=[k*(5-k)*scaled[k]**2-(k+1)*(6-k)*scaled[k-1]*scaled[k+1]for k in range(1,5)];assert all(g>0 for g in gaps)
r={'status':'PASS','scope':'Exact nonreal example; not a ULC counterexample','core_shores':[2,3],'exterior_shores':[10,10],'core_activity':100,'exterior_activity':1,'support_quota_tests':quota_tests,'feasible_quotas_counted_once':feasible_quotas,'gamma':gamma,'gamma_t_over_100':scaled,'discriminant':str(disc),'square_free':True,'Sturm_degrees':[p.degree()for p in sturm],'Sturm_signs_minus_infinity':negative,'Sturm_signs_zero':zero,'Sturm_signs_plus_infinity':positive,'Sturm_variations':[vm,vz,vp],'negative_real_roots':3,'positive_real_roots':0,'nonreal_conjugate_pairs':1,'actual_degree':5,'strict_rank_five_ULC_gaps':gaps,'proof_assistant_formalization':False,'elapsed_seconds':round(time.monotonic()-started,3)}
args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'nonreal_verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
