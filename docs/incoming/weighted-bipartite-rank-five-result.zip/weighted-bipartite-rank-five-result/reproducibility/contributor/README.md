# Contributor corroboration checks

These are exact symbolic and endpoint-support checks accompanying an ordinary proof. Their authors contributed to the proof; the separate independent mathematical approval is not replaced by these programs. No finite search is a theorem premise.

Requirements: Python3.11 or newer and SymPy1.14.0. No numerical solver or previous archive is needed. Run:

    python check.py --output-dir /path/to/temporary-output
    python check_nonreal.py --output-dir /path/to/temporary-output

`check.py` checks the block-PSD decomposition with a symbolic rank parameter, both interface-matrix identities, the generic first-layer inverse and Schur complement, generic principal-line determinant identities in dimensions1–4, the clone limit coefficients1 and1/2, the q1 zero-block convention and the q0 discriminant. The block identity is formal algebra, not a claim that sample ranks prove the general theorem.

`check_nonreal.py` reconstructs the complete-block example by endpoint support quotas, counting supports once rather than matching witnesses. It proves the displayed quintic has exactly three negative real roots and one nonreal conjugate pair by an exact rational Sturm sequence, and checks all rank-five ULC inequalities. It requires no earlier verification package.

Both programs reject Python optimization mode. Their receipts contain a nondeterministic elapsed time; every other field is deterministic. Default output is beside the script, so use `--output-dir` when replaying a frozen package.
