#!/usr/bin/env python3
"""Exact weighted corroboration; no finite search is a proof premise."""
if not __debug__:raise SystemExit('Run without -O: assertions are required.')
import argparse,itertools,json,math,pathlib,random,time
from collections import Counter,deque

def gamma(rows,u,v):
 nl=len(u);nr=len(v);vw=[1]*(1<<nr)
 for m in range(1,1<<nr):
  b=m&-m;vw[m]=vw[m^b]*v[b.bit_length()-1]
 ans=[0]*(min(nl,nr)+1)
 for S in range(1<<nl):
  k=S.bit_count()
  if k>=len(ans):continue
  sw=math.prod(u[i] for i in range(nl) if S>>i&1)
  if not sw:continue
  reach={0}
  for i,row in enumerate(rows):
   if not S>>i&1:continue
   nxt=set()
   for used in reach:
    choices=row&~used
    while choices:
     b=choices&-choices;choices-=b;nxt.add(used|b)
   reach=nxt
  ans[k]+=sw*sum(vw[T] for T in reach)
 while len(ans)>1 and ans[-1]==0:ans.pop()
 return ans

def active(rows,u,v):
 left=[i for i,a in enumerate(u) if a];right=[j for j,a in enumerate(v) if a]
 return [sum(1<<k for k,j in enumerate(right) if rows[i]>>j&1) for i in left],[u[i] for i in left],[v[j] for j in right]

def cover(rows,nr):
 mateR=[-1]*nr
 def augment(i,seen):
  for j in range(nr):
   if rows[i]>>j&1 and j not in seen:
    seen.add(j)
    if mateR[j]<0 or augment(mateR[j],seen):mateR[j]=i;return True
  return False
 for i in range(len(rows)):augment(i,set())
 mateL=[-1]*len(rows)
 for j,i in enumerate(mateR):
  if i>=0:mateL[i]=j
 zl={i for i,j in enumerate(mateL) if j<0};zr=set();queue=deque(zl)
 while queue:
  i=queue.popleft()
  for j in range(nr):
   if rows[i]>>j&1 and j!=mateL[i] and j not in zr:
    zr.add(j)
    if mateR[j]>=0 and mateR[j] not in zl:zl.add(mateR[j]);queue.append(mateR[j])
 cl=set(range(len(rows)))-zl;cr=zr;d=sum(j>=0 for j in mateL)
 assert len(cl)+len(cr)==d
 assert all(i in cl or j in cr for i,row in enumerate(rows) for j in range(nr) if row>>j&1)
 return d,min(len(cl),len(cr))

def ulc(g,D):
 assert g[0]==1 and all(x>0 for x in g)
 padded=g+[0]*(D+1-len(g));assert len(padded)==D+1
 for k in range(1,D):assert k*(D-k)*padded[k]**2>=(k+1)*(D+1-k)*padded[k-1]*padded[k+1]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir',type=pathlib.Path,default=pathlib.Path(__file__).parent);args=ap.parse_args();start=time.monotonic();rng=random.Random(1952601)
 counts=Counter();degrees=Counter();branches=Counter()
 def test(rows,u,v,upper=None):
  g=gamma(rows,u,v);ar,au,av=active(rows,u,v);assert g==gamma(ar,au,av)
  d,r=cover(ar,len(av));assert d==len(g)-1
  counts['weighted_graph_cases']+=1;degrees[str(d)]+=1
  counts['zero_activity_cases']+=any(a==0 for a in u+v)
  if upper is None:
   assert d<=5;ulc(g,d);branches[str(r)]+=1;assert r<=2
   counts['actual_rank_at_most_five_cases']+=1
  else:
   ulc(g,upper);counts['higher_cover_order_cases']+=1;counts['higher_full_degree_cases']+=d==upper
 for mask in range(512):
  rows=[(mask>>(3*i))&7 for i in range(3)]
  test(rows,[1,1,1],[1,1,1]);test(rows,[0,2,3],[1,0,4])
 for _ in range(300):
  rows=[rng.randrange(32) for _ in range(5)];test(rows,[rng.randrange(5) for _ in range(5)],[rng.randrange(5) for _ in range(5)])
 for _ in range(200):
  rows=[rng.randrange(32)|(1<<i) for i in range(5)];test(rows,[rng.randrange(1,6) for _ in range(5)],[rng.randrange(1,6) for _ in range(5)])
 # Mixed minimum-cover cases on shores larger than five.
 for r,q,number in ((2,3,80),(1,4,60)):
  nx=q+1;ny=3
  for _ in range(number):
   rows=[rng.randrange(1<<q)|sum(1<<(q+y) for y in range(ny) if rng.randrange(2) or y==p) for p in range(r)]
   rows += [1<<j for j in range(q)]+[rng.randrange(1<<q)]
   test(rows,[rng.randrange(1,6) for _ in rows],[rng.randrange(1,6) for _ in range(q+ny)])
 for q in (4,5):
  for _ in range(20):
   rows=[rng.randrange(1<<q)|(1<<(q+p))|((1<<(q+2)) if rng.randrange(2) else 0) for p in range(2)]+[1<<j for j in range(q)]
   test(rows,[rng.randrange(1,6) for _ in rows],[rng.randrange(1,6) for _ in range(q+3)],q+2)
 receipt={'status':'PASS','scope':'Exact finite corroboration of ordinary all-size theorems; not a proof dependency','counts':dict(sorted(counts.items())),'actual_degree_counts':dict(sorted(degrees.items())),'minimum_cover_smaller_shore_counts':dict(sorted(branches.items())),'active_graph_coefficients_unchanged':True,'maximum_matching_equals_actual_degree':True,'minimum_cover_edges_and_cardinality_checked':True,'all_requested_ULC_normalizations':'PASS','seconds':round(time.monotonic()-start,3)}
 args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'weighted_rank_five_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
