#!/bin/sh
set -eu
cd "$(dirname "$0")/article"
pdflatex -interaction=nonstopmode -halt-on-error weighted-bipartite-rank-five.tex
pdflatex -interaction=nonstopmode -halt-on-error weighted-bipartite-rank-five.tex
