# Two-Endpoint Statistics of Catalan Partitions

**OEIS A033552 — number of parts, phase-dependent extremes, conditioning
corrections, an exact spectral law, and inverse upper quantiles.**

Prepared for Vladimir Reshetnikov, October 4, 2026.

## Read the article

`article.pdf` is the compiled research article. `article.tex` is a standalone
LaTeX source: it does not depend on external figures, separate table inputs,
or a BibTeX database. The bibliography is included in the source.

The article extends the Catalan-partition report in ProveIt, inspected at
commit `0f93381e8932d3aee3d5c2abfb5c98d128d49b9c`. The precise source path,
source audit, and references appear in the article. No repository files were
modified and no results were submitted to OEIS.

## Main results

For a uniform partition of n into the distinct sizes 1, 2, 5, 14, 42, ...,
let L_n be its number of parts and J_n its largest occupied Catalan index.
At the exact coefficient saddle t_n and cutoff coordinate m_n:

- The scaled length t_n L_n tends to W = sum E_k/C_k for independent
  mean-one exponential E_k. Its transform has the first correction
  `L(s) - s^2 L''(s)/(2 m_n)`, and a finite Gaussian operator produces every
  fixed higher order. The mean has no 1/m_n term.
- Finite cutoff multiplicities have explicit joint first corrections.
  Length and the phase-centered maximum are asymptotically independent,
  with an explicit first nonzero dependence.
- A growing-offset maximum estimate and uniform two-sided tails justify
  convergence of all centered maximum moments.
- The limiting survival function is an absolutely convergent sum
  `sum d_j exp(-C_j x)`, with explicit product coefficients and remainder
  bounds. In z = exp(-x), it has a smooth natural boundary. Its upper
  quantiles have a convergent inverse expansion, displayed through the
  fourth power of the tail probability.

The article separates these statements from the old report's counting
asymptotics and fixed-offset leading maximum law. Nine further research
directions are proposed, including uniform finite-size quantile inversion,
small deviations, wider cutoff windows, and certified computation.

## Reproduce the numerical and symbolic checks

The executed environment was Python 3.13.5, mpmath 1.3.0, and SymPy 1.14.0.
The programs do not use the network. Install dependencies once in a virtual
environment, then run from the package directory:

```sh
python -m pip install -r requirements.txt
python code/verify.py --max-n 1000000 --dps 60 --output rerun
python code/verify_cutoff.py --max-n 1000000 --dps 60 --output rerun
```

`--output rerun` preserves the shipped data. Omitting `--output` writes to
this package's `data/` directory. A quicker, smaller run can use
`--max-n 10000`; the exact arrays require memory proportional to the upper
bound. The main audit requires at least 60 working decimal digits because
several assertions test agreement at 40–50 digits.

`code/catalan_statistics.py` contains the exact dynamic program, saddle
solver, multi-index operator, phase functions, and spectral/quantile
calculations. `code/verify.py` runs the main audit and writes its tables.
`code/verify_cutoff.py` independently evaluates exact cutoff-cylinder
probabilities by inclusion–exclusion and compares their first corrections.

Executed exact checks include 301 count-recurrence comparisons, 61 exhaustive
count/length/second-moment checks, 549 cutoff-cylinder checks, 15 symbolic
gamma-benchmark checks, an eight-rate rational partial-fraction identity,
four inverse coefficients, and the generic first joint-operator identity.
Exact count and raw-length arrays were computed through n = 1,000,000.
Only the smaller stated ranges were independently cross-checked.

`data/verification.json` and `data/cutoff_verification.json` record the actual
checks, environment, scope, and numerical constants. The CSV files preserve
all tested cases, including poor or nonmonotone approximation behavior.
The weighted Laplace-transform dynamic program uses ordinary double
precision; unweighted counts and raw length sums use exact integers.

## Rebuild the PDF

With a standard TeX Live or MiKTeX installation containing the packages in
the preamble:

```sh
./build.sh
```

The script resolves its own directory and can also be invoked from another
working directory. On Windows, run the following in the package directory:

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Three passes stabilize the contents and references when starting clean.

## Status and limits

This is an AI-assisted, unrefereed research manuscript with conventional
proofs, not a Lean formalization. The tests are finite checks and
floating-point diagnostics, not machine proofs of analytic remainder
estimates. Decimal values are not interval-certified. Hadamard's classical
gap theorem is explicitly credited as the external input to the natural
boundary argument; the original relevant pages were inspected.

The results resolve specific extensions asked in the inspected repository.
No exhaustive publication-priority claim is made. The report does not solve
Pak's exact counting-complexity problem, include all exponentially small
sectors of a complete transseries, or prove a uniform finite-n quantile
formula when the tail probability tends to zero with n.
