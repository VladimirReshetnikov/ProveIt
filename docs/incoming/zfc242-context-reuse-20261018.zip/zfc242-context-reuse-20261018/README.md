# A 242-state ZFC consistency machine

This package supplies a concrete binary, single-tape machine with **242 working states**, including initialization, and one separate halt state. It starts at state 0, head 0, on an all-zero two-way infinite tape. Every transition moves left or right.

The ordinary mathematical proof gives

**ZFC proves: nonhalting of this exact machine if and only if Con(ZFC).**

The new part is an explicit whole-tape halting equivalence with the pinned `candidate-combined243` machine, valid from inherited state 95 at every head position and on every initial binary tape. Its consistency calibration composes with the supplied ordinary 243-state calibration. No new Lean/Rocq endpoint or full internal PA calibration is claimed.

## Exact reduction

Use inherited labels, not either machine's canonical labels. Delete state 15 and change only:

| Row | Combined243 | This machine |
| --- | --- | --- |
| 11 / 0 | 0 R 15 | 0 R 27 |
| 27 / 1 | 1 R 39 | 1 R 22 |

The other 482 retained rows are unchanged. All old arrivals at states 18, 47, and 65 write zero and move right; their zero branches enter 27 moving left. Hence old state 27 can only read zero. The reused one-branch implements the deleted state's one-branch. Its zero-branch takes the detour `11 -> 27 -> 32 -> 45 -> 21`, matching the old `11 -> 15 -> 21` endpoint with the entire tape unchanged. Five local identities and 478 ordinary rows establish the positive-block equivalence.

The QT source rotation is what made the relevant entry to state 18 write zero, exposing this additional saving.

## Files to inspect first

- `report.pdf` and `report.tex`: complete report, ordinary proof, executed checks, alternative-formalism research, and the full canonical table.
- `machine/zfc_context242.tm`: canonical 484-row table; working states 0–241, start 0, dispatcher 86, halt 242.
- `machine/zfc_context242_old.tm`: identical machine in inherited labels; start 95, dispatcher 96, halt 254.
- `machine/renumbering.json`: exact bijection.
- `code/construct.py` and `code/verify_local.py`: deterministic construction and independent finite-context proof checker.
- `evidence/`: actual local, blank, affine, literal, and expanded replay records.
- `research/`: independent second checker, discovery search, scoped negative screens, and acceptance-predicate research.
- `reference/`: pinned 243-state tables and the selected 291-file inherited reference bundle, with original notices.

Canonical SHA-256:

```text
64ddeb2c01c3e9c7feffaffaad87266a270716c9307892a0445bf869b988984d
```

Inherited-label SHA-256:

```text
6b700aa713418cfe347a6ff2d0a92de7c31810d1cf69814b4684c7fb463876a0
```

## Actual verification results

| Check | Result |
| --- | --- |
| Independent local proof | Five exact whole-tape cases and 478 ordinary rows pass. |
| Blank initialization | 407,979 actual transitions; identical complete frame to combined243 at 407,967. |
| Affine runtime | All 8,390 source/guard cases pass. |
| Literal runtime fixtures | All 8,390 cases pass in 6,473,406 transitions; all 484 rows exercised. |
| Expanded symbolic runtime | All 8,390 cases pass; 2,314,880 symbolic rules; all 484 rows covered. |

The blank endpoint has inherited state 96, head -5, marker -6, header 176, logical registers `(3,0,0,0,3,0,0,0,0)`, 167 value-one spare blocks, and exactly 351 one-cells. Both sparse and dense representations and both state numberings are checked. The expanded replay took 365.276 seconds in the producing environment.

The mathematical relative proof does not depend on the finite runtime fixtures or the search engine. The expanded checker is an ordinary symbolic-induction replay, distinct from a proof-assistant kernel theorem. Its source, table and exact reference bindings are retained.

## Reproduction

The archive contains `SHA256SUMS` for every delivered file except the manifest itself. Before running any scripts, check it from the extracted package root:

```sh
sha256sum -c SHA256SUMS
```

Use Python 3.12 with assertions enabled. Run from the extracted package root:

```sh
python3 -B code/construct.py
python3 -B code/verify_local.py
python3 -B code/verify_blank.py
python3 -B code/verify_all.py
```

To rerun the expanded symbolic stage as well:

```sh
python3 -B code/verify_all.py --expanded
```

To check a previously generated expanded record while rerunning the quick stages, use `--reuse-expanded`; that mode explicitly does not claim to have executed a fresh expanded replay. This is how the final packaging check incorporates the separate actual complete expanded run recorded in `expanded.stdout.log` and `expanded-runtime.json`.

The quick/expanded paths use the standard library and included files. No network access or proof assistant is required. Each quick stage has a 120-second limit in the driver; expanded has 900 seconds. A failed or unfinished stage raises an error and is not reported as a proof.

The optional research checks are:

```sh
python3 -B research/acceptance_residues.py
python3 -B research/mod4_trees.py
python3 -B research/source_screen.py --sites machine/sites_logical.json --mod4 research/mod4_trees.json --output research/source_screen.json
python3 -B research/verify_reuse_independently.py reference/zfc_combined243_old.tm machine/zfc_context242_old.tm --output research/independent_local_verification.json
```

`research/SEARCH.md` documents the optional C++17 discovery search and its bounded follow-ups. The two alternative 242-state tables there spend the same unused branch and are not simultaneous state savings. They are retained as research artifacts; the selected table is the delete-15 construction.

To rebuild the report after replay:

```sh
python3 -B code/write_report_data.py
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Secondary research

The 162-layout source census checks all combinations of four additional transfer-loop rotations and two QT associations, including universal loop blocks and surrounding control-flow correspondence. Its minimum is 202 distinct decoder nodes, equal to the baseline. The best simultaneous rotation reduces source leaves from 6,459 to 6,455 without lowering that measure.

For the full inherited numerical calculus, the report also proves that acceptance of a derived code `h` satisfying `h` odd and `h mod 16 != 3` is equivalent to refutation. This predicate is maximal among unions of residue classes modulo any power of two at least 16. It has no new binary implementation here. The 19 synthesized seven-leaf modulo-four testers cost 205 or 206 decoder nodes when embedded in the actual QT context, versus 202 in the baseline.

The alternative-formalism comparison covers the calibrated native theory, equality-free closure with restricted parameter interfaces, and finite assignment/class kernels with a quotient-based certificate frontend. Uncompiled alternatives receive no invented Turing-machine state counts.

## Provenance and qualification

The pinned ProveIt revision is `e58338db7545909907e07a7603e8eb88625c527a`. `PROVENANCE.json` records its paths and hashes. The exact source71 archive was recovered with SHA-256 `2609ff9ff0c6c0a2ba7619bcfad7e7480f3d9052dd32c161149e6a721c25a54a`; only the 291 reference files selected by the maintained reproduction index are bundled as the runtime reference.

Original calculus/program credit remains with Mira-Cult, public verification with Jeff Ketchersid, and compiler framework with Andrew James Wade. The preceding ProveIt reductions, QT rotation, and compensated fold retain their original attribution. See `ATTRIBUTION.md` and preserved inherited notices.

No absolute consistency, unconditional nonhalting, two-sided independence from mere consistency, global record, or minimum-state claim is made.
