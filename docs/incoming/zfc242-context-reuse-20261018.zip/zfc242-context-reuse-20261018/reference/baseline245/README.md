# A 245-state Turing machine for Con(ZFC)

This archive supplies a concrete **245-state, two-symbol, single-tape Turing machine** and an ordinary mathematical proof in ZFC that

\[
\neg\operatorname{Halt}(M_{245},0^{\mathbb Z})\quad\longleftrightarrow\quad\operatorname{Con}(\mathrm{ZFC}).
\]

The tape is two-way infinite and initially all zero. All initialization states are included in the count. The separate halt state is excluded from the working-state count. Every transition moves left or right.

**Read `report.pdf` for the proof and full transition table.** Its LaTeX source is `report.tex`, with the accompanying `.tex` fragments. The mathematical result uses explicit finite computations and universal induction certificates. A newly compiled Lean/Rocq endpoint or serialized PA/ZFC proof object for this exact table is **not** included.

## Exact machine

| Object | Value |
|---|---|
| Canonical machine | `machine/zfc245.tm` |
| Working states | 0 through 244, inclusive |
| Initial state | 0 |
| Dispatcher | 88 |
| Separate halt state | 245 |
| Defined transition rows | 490 |
| Blank symbol | 0 |
| Original-label equivalent | `machine/zfc245_old.tm` |
| Original start / dispatcher / halt | 95 / 96 / 254 |
| Renumbering | `machine/renumbering.json` |
| Successful source grammar | `grammar.json` |

Canonical-table SHA-256:

```text
17f4d430747c4a0cd580dc2cc13ea06a74ce7f51f12be4c2d12f6a646691dd13
```

Original-label-table SHA-256:

```text
f8dbeacdad5fd89c57e3f240781324b09110be8e0ccdb838a9c710fb28d2a267
```

Successful-grammar SHA-256:

```text
724ad366bb56206a3aac233932e6a8bfc10a49192f5a4d6689c873c5c1d6a278
```

Each noncomment `.tm` line is `state read write direction next_state`. The first line declares the initial state. There is no outgoing row for the halt state. The files in `certificate/` are byte-identical copies used by the reconstruction checker.

## What makes the reduction work

The reference prefix246 machine has 119 fixed framework roles and 127 shared source-grammar roles. The new construction moves the special role of state 177 into the charged grammar and shortens the scanner, leaving **117 framework roles plus 128 grammar roles: 245 states**.

The program, special decoder entry routes, and scanner are optimized together. The final program has maximum zero run **6** and maximum source-path depth **51**, while preserving all **6,460 ordered instruction operations and arguments**. It preserves the original proof-search calculus, including all eight axiom-construction rows, equality, freshness tests, CP, and GIC.

A concrete part of the repair is:

```text
58/0  -> 0 L 84
74    -> (0 R 132, 1 R 16)
98    -> (0 R 23,  1 R 74)
178   -> (0 R 16,  1 R 206)
218/0 -> 0 L 86
```

Numeric state 74 is now a grammar helper. The old attempted rotation at 178 broke the route from 218/0. Rerouting that entry through 86 and reassociating 98 repairs both required predecessor-bit cases. The helper also allows the scanner-compatible program association. These rows are an explanation of the larger construction; applying only this excerpt to the baseline is not the delivered machine.

Numeric labels are reused. In the final old-label table the working-label set is the baseline set minus label 247; labels 74, 177, and 208 have new semantic roles. Count roles in the complete delivered table rather than interpreting a removed old grammar word as a permanently forbidden numeric label.

## Reproduce the verification

Run from a clean extracted archive with **Python 3.10 or newer**:

```sh
python3 -B code/verify_all.py
```

This default has no network, third-party Python-package, compiler, solver, or proof-assistant requirement. It checks all delivered hashes, reconstructs both exact machines, reparses the original source, regenerates and checks the register bisimulation, checks all universally guarded affine instruction cases, independently derives the register macro contracts on the actual table, checks all residual pointers and bootstrap locks, verifies the scanner contractions, and runs independent blank-tape simulators. The fresh result directory is printed. Assertions must remain enabled: do not use Python `-O`.

For **all** the independent checks, including the expanded whole-frame proof and regeneration/replay of the finite literal fixtures:

```sh
python3 -B code/verify_all.py --whole-frame --literal
```

The whole-frame proof takes several minutes. The `--literal` option needs `g++` or `clang++` with C++17 support. It regenerates the fixtures from the pinned original program and interval metadata, compares them byte-for-byte with the frozen fixtures, and exercises every transition rule. Both options are optional for using the core universal macro certificate, and both have been run successfully for this delivery.

To choose an output location, pass `--output /path/to/new-empty-directory`. Frozen certificate files are not overwritten. Equivalent make targets are `make verify`, `make verify-full`, and `make verify-literal`.

The narrower runtime/source replay supplied by the logical-audit lane is also available:

```sh
python3 -B code/verify.py
python3 -B code/verify.py --whole-frame
```

It is documented in `reviews/runtime245-README.md`. `manifest.json` covers its curated inputs and code. `SHA256SUMS` covers the complete delivered archive contents except itself.

## Evidence and scope

| Check | Recorded result |
|---|---|
| Grammar/orientation/special entries | 128 rules; all 22 local cases pass |
| State count and canonical renumbering | 245 working states; all 490 rows agree |
| Fresh original-source identity | 6,460 ordered instruction leaves agree |
| Register-program bisimulation | 3,013 pairs, 6,024 edges, one halt pair |
| Universal macro induction | Four block lemmas, three arithmetic macros, nine selectors |
| Named guards and single effects | 342 oracle checks pass |
| Complete-pointer affine proof | All 8,391 guarded instruction cases pass |
| Independent expanded whole-frame proof | All 8,391 cases; 2,312,645 symbolic rules; every table row covered |
| Exact head motion and progress | Displacement equals minus pointer overflow; minimum 13 steps |
| New-tree residual-pointer normalization | All 8,390 nonhalting successors pass |
| Bootstrap row equations | All 54 pass |
| Guarded scanner contractions | 1,410 exact three-zero contractions |
| Blank initialization | 407,915 transitions; sparse and dense interpreters agree on all 351 one-cells |
| Independent literal regressions | 8,385 passing fixtures; all 490 rows exercised; maximum 2,686 steps |
| Padding adaptation | Exact source equality after only declared parameter/import changes |

The universal proofs quantify every primary register value, every header distance `64+n` for `n >= 0`, and every finite nonempty spare suffix. The whole-frame run uses nine independent arbitrary natural variables and expands the register boxes. The 8,385 literal fixtures are additional finite checks, not universal premises.

The actual initializer reaches the empty-pointer frame with old dispatcher 96, head -5, marker -6, header 176, and header distance 181. Its logical vector is

```text
(N,T,W,A,D,H,X,Y,L) = (3,0,0,0,3,0,0,0,0)
```

There are 167 spare blocks, all of value one. With `Delta = 64+n`, the initial parameter is 117. Each instruction changes it by `positive_decrement + pointer_overflow`, so the margin never decreases. Increment appends a spare; no instruction exhausts the suffix.

The source calibration specializes `DirtyProgram254.six_nonformula_path_iff 3 0 3 0 0 0`, uses the exact original proof search, and retains the Foundation and Choice consistency adapters. No consistency assumption is needed to prove the equivalence. Assuming consistency afterward gives actual nonhalting and its unprovability in ZFC. The stronger assertion of two-sided independence also needs an appropriate soundness assumption.

## Contents

- `report.tex`, `report.pdf`, and `.tex` fragments: main proof, mechanisms, verification scope, and complete transition table.
- `machine/`: canonical table, original-label table, renumbering, and generated table fragment.
- `grammar.json`, `inputs/`: immutable successful grammar and source constraints.
- `certificate/`: source paths, finite bisimulation, allocation, full boot frame, universal proof records, and audit summaries.
- `code/`: portable construction, runtime proof checkers, composition verifier, and combined replay driver.
- `results/`: independent corroborating records and clearly identified historical experiments.
- `proof/`, `reviews/`, `report/`: independent mathematical notes and detailed construction explanations.
- `reference/context246/`: frozen attributed baseline proof, code, machine, source snapshots, and its own provenance.
- `reference/state_reduction/STATE_REDUCTION_REPRODUCE.md`: exact discovery and supporting experiment commands.
- `research/architecture/`: optional independently checked axiom-layout and finite-field resource research. These analyses concern the old program and are not premises of the successful 245-state proof.
- `research/propositional/`: small matrix obstructions to certain restricted propositional bases; no claim that every associated modified set theory is nonequiconsistent with ZFC.
- `PROVENANCE.json`, `provenance.json`, `NOTICE.txt`, licenses, and hash inventories: source identity and attribution.

The rejected seven-zero grammar is retained only as a historical failed verification attempt. Its failed affine obligation and bounded unresolved literal replay are not claimed to prove eventual inequivalence. The final zero6 grammar has complete passing universal certificates.

The initial local-routing audit records zero bootstrap-lock checks because that optional gate was not requested during construction. The separate `results/independent/frame245-composition-check.json` and replayed composition checker explicitly verify all 54 equations; the exact blank replay is independently checked as well.

## Rediscovery and further work

Verification does not depend on rerunning search. The exact successful heuristic is included with seed 129177, the fixed source and route constraints, the 54 bootstrap equations, and the 129-rule resume object. The recorded run found the 128-rule solution after 7,040,505 proposals in approximately 173 seconds. See the state-reduction reproduction notes for the compiler and run command. Runtime-dependent proposal counts do not claim exhaustive coverage or minimality.

To rebuild the report:

```sh
make pdf
```

To regenerate or check its transition table:

```sh
make table
make check-table
```

A suggested ProveIt location is `Computability/BusyBeaver/Research/ZFC/candidate-routing245/`. The direct proof-assistant continuation is to specialize the existing binary-runtime layer to the new table, grammar, padding parameter, and finite initialization, while retaining the original logical-calibration modules. This archive does not modify or publish the repository.
