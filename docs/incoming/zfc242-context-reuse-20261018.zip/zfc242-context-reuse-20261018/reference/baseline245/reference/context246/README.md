# A 246-state blank-tape machine for Con(ZFC)

This package supplies an explicit binary, single-tape Turing machine with **246 working states**, including initialization from the all-zero tape, and a conventional mathematical proof of

\[
\mathrm{ZFC}\vdash\bigl(\neg\operatorname{Halt}(M_{246},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The proof and its computational certificates are in **`report.pdf`** and **`report.tex`**. The complete canonical transition table is both a machine-readable file and an appendix to the report. This contribution was prepared for incorporation into ProveIt on 18 October 2026.

**Proof status:** the new 246-state result has an ordinary mathematical proof, exact finite bootstrap evidence, universal register-operation induction checks, and exhaustive symbolic instruction certificates. It does **not** yet have a newly compiled Lean/Rocq endpoint for this exact table or a serialized first-order ZFC/PA derivation. The selected inherited Lean source interfaces are pinned and audited, but their dependency closure was not rebuilt here. See report Sections 7 and 8 for the mathematical consistency calibration and this formalization boundary.

## The construction

Starting from the supplied incoming prefix250 machine in its original numbering:

1. Delete working states **0, 1, 3, and 97**.
2. Replace `60 0 0 R 0` with `60 0 0 R 20`.
3. Replace `255 0 1 L 97` with `255 0 1 L 255`.
4. Start directly in old state **95** on the completely blank tape.

All other retained rows stay unchanged. The halt label in this numbering is 254. Renumbering old 95 first and then the other working labels in increasing order gives canonical start 0, working labels 0–245, and separate halt label 246. All 246 working states are reachable in the finite control graph. The alphabet remains `{0,1}`; every transition moves left or right. There are no uncounted bootstrap states or preloaded tape symbols.

The saving comes from two identifications justified by known read symbols. The register block `B(v) = 0 1^(v+1)` always has a first one, even at value zero. State 0 therefore uses its read-one row during valid marking, and that row already exists at state 20. Redirecting the marking entry also disconnects the old startup states 1 and 3. In the carry pulse, the machine writes the very one that old state 97 subsequently reads. Its read-one row already exists at state 255, which can perform the same pulse with a self-return. The report proves these facts for the whole recurrent domain, rather than inferring them from a sampled execution.

Deleting the old bootstrap requires a new blank initialization. Exactly **410,735** steps from old state 95 reach dispatcher 96, head −5, marker −6, header 176, an empty program counter, nine physical primary values `[0,0,0,3,0,0,3,0,0]`, and 167 spare blocks of value 1. The complete tape has 351 one-cells and is zero elsewhere. Its logical root is `(N,T,W,A,D,H,X,Y,L) = (3,0,0,0,3,0,0,0,0)`, admitted by the existing six-nonformula-field theorem.

## Verify offline

Requirements for the main verification are **Python 3.10 or later** and its standard library. No package installation or network access is required.

From this directory, first verify the delivered bytes, then run the checks:

```sh
python3 -B code/check_hashes.py
python3 -B code/verify_all.py
```

Assertions are part of the proof checks: do not run Python with `-O` or `-OO`. The main driver rejects optimized execution. Successful completion prints `ALL PREFIX246 CHECKS PASS`. It refreshes result files, including timing-bearing summaries, so run the release-integrity check **before** the verification suite. A subsequent mismatch in a refreshed result file is not evidence that the frozen machine changed.

The suite checks both reconstruction routes, the canonical table and its TeX appendix, 494 restricted commuting pairs, all 32 reference-source hashes, four arbitrary-length block inductions, three full register-macro inductions, all nine marking cases, all **8,391** guarded instruction cases, and **342** missing/mismatched-register guard checks. It checks the full source parse and successor program counters, including carry overflow and trailing zeros.

It also replays the exact blank prefix with original and canonical labels and a separately implemented dense canonical tape. Secondary literal regressions cover **33,564** instruction cases with **14,197,744** individual transitions, exercising all 492 state/read pairs; **16,200** exact-time macro cases; and **3,600** additional box cases. These finite regressions corroborate the universal proof. They are not used to infer nonhalting.

An additional audit with a separately packaged copy of the prior250 checker can be run with:

```sh
python3 -B reviews/audit246.py reviews/prior250
```

See `reviews/README.md` for its independence and scope. The optional bounded discovery search is documented separately in `search/README.md`; it is not part of the proof gate.

## Build the PDF

The delivered PDF is ready to read. To regenerate it, install a TeX distribution providing pdfLaTeX and the packages listed in the preamble, including Latin Modern, AMS mathematics, `booktabs`, `longtable`, `microtype`, `fancyhdr`, `enumitem`, `xurl`, and `hyperref`, then run:

```sh
make pdf
```

This compiles twice under `build/` and copies the result to `report.pdf`. The full table appendix comes from `machine/transition-table.tex`; `python3 -B code/render_table.py --check` verifies its identity against the canonical machine. `make verify` runs the main proof checks, and `make independent` runs the separate audit.

## Files

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf` | Main mathematical report, reproduction instructions, references, and full canonical table. |
| `machine/zfc_prefix246.tm` | Exact canonical machine, start 0, halt 246. |
| `machine/zfc_prefix246_old.tm` | Same machine with original labels, start 95, halt 254. |
| `machine/renumbering.json` | State mapping and construction metadata. |
| `code/` | Portable reconstruction, symbolic proof checks, literal audits, and table rendering. |
| `results/` | Recorded successful checks, bootstrap tape, source identities, and audit summaries. |
| `reviews/` | Independent mathematical reviews and a separate reproducible audit. |
| `sources/` | Frozen program, 252/250 baselines, inherited checker, selected Lean source interfaces, and attribution. |
| `search/` | Optional bounded search that discovered the existing-state blank initializer. |
| `PROVENANCE.json`, `SHA256SUMS` | Source pins, input identities, and integrity manifest. |

Canonical machine SHA-256:

```text
89cda615b3ea9fcac07ad6b08e0351faa34841a56935b6f5846d3920f13bc0fc
```

Original-label machine SHA-256:

```text
303911c554284c49ce09042d8127feba4da260baae766e32260034aa3bdb82ee
```

## Logical calibration and repository integration

The original decoder and proof-search calculus are retained. The proof composes the new binary simulation with the exact safe-root theorem, the numerical-to-native-refutation comparison, and the native/ZF/ZFC calibration. The source interfaces are `Bisim254.prog254_halts_iff`, `DirtyProgram254.six_nonformula_path_iff`, `NativeTheory254.c254_refutation_iff`, `WFTheory.native_refutation_iff_zf`, and `ChoiceCalibration254.zf_refutation_iff_zfc`. Report Section 7 explains why their mathematical interpretation argument can be carried out in ZFC using set-coded syntax and models.

Consistency is not assumed to prove the displayed equivalence. Under the additional hypothesis Con(ZFC), the machine does not halt and ZFC cannot prove that nonhalting statement. The package does not infer full two-sided independence from mere consistency; excluding a proof of the false existential halting statement needs an additional soundness hypothesis.

A suggested destination is `Computability/BusyBeaver/Research/ZFC/candidate-context246/`. The focused remaining formalization task is to turn the two forced-symbol identifications and the exact new bootstrap into a closed kernel endpoint, preserving the whole-frame invariant, nonempty spare suffix, complete program-counter rebasing, and precise dirty-root specialization. No remote repository changes are needed to inspect or reproduce this package.

The inspected ProveIt revision is [`e0b512a63e2c1ca6a1698fa437b8568f1643ff6b`](https://github.com/VladimirReshetnikov/ProveIt/tree/e0b512a63e2c1ca6a1698fa437b8568f1643ff6b). The inspected upstream `zf-254` revision is [`c132d7eae8158cd3a9850ea3eb7251158c3dd821`](https://github.com/jeff87654/busy-beaver/tree/c132d7eae8158cd3a9850ea3eb7251158c3dd821/ZF/m254). `PROVENANCE.json` distinguishes those pins from ProveIt's historical upstream import. Attribution and license boundaries are in `NOTICE.txt`.
