# One-stage Fejer selection for Gowers arrangements

A self-contained local refinement of Section 15 of W. T. Gowers,
*A new proof of Szemeredi's theorem* (2001), prepared for ProveIt on
2026-10-06.

## Files

- `fejer-arrangement-selection.tex`: complete, standalone article source.
- `fejer-arrangement-selection.pdf`: compiled 20-page article.
- `verify_fejer_selection.py`: deterministic exact finite checks, Python standard library only.
- `verification-results.json`: output of the supplied verification program.
- `PROOF_AUDIT.md`: assumptions, proof dependencies, and limits of the conclusions.
- `Makefile`: PDF build, verification, and cleanup commands.

## Main result

For ordered d-arrangements of k-dimensional cubes, put

    s = 2*d*2^k
    M = (2*d+1)*k + 2*d - 1
    L = ceil(2*(s+1)/(alpha*eta)).

Let B have density beta in F_q^(k+1), and suppose a map phi on B respects
at least alpha*beta^(2*d-1)*q^M arrangements. If

    char(F_q) > 2*(L-1)
    q >= (k+1)*beta^(-(2*d-1))
         * [18*(s+1)^2/(alpha*eta)^2]^s,

then a subset B' contains at least

    Gamma * beta^(2*d-1) * q^M
    Gamma = alpha^s * eta^(s-1) / [3^(s-1)*(s+1)^s]

respected arrangements. At least a proportion 1/(1+eta), and therefore
at least 1-eta, of all its arrangements are respected. Its point density
is at least beta*Gamma^(1/(2*d-1)).

The theorem titled "Exact one-stage Fejer selection" gives a sharper
exact-bandwidth statement.
For a prime field, the displayed size condition implies the characteristic
condition. For an extension field, they must both be checked.

For d=8, the result replaces the original local retention power
s*2^(s-1) by powers s and s-1, and improves the sufficient field-size
threshold. This is **not** a new global bound for Szemeredi's theorem.

## Other results

The feature F(y,r) = r*product(y_i) has exactly the intended universal
relation. A polynomial zero-count controls all other bounded-coefficient
relations. The article also proves dimension-free vector-target
extensions, an exact target-torsion survival formula, and a sharp
exponent trade-off within a precisely defined homogeneous
nonnegative-Fourier kernel class, including independent repeated stages.

## Verification status

The article contains complete mathematical proofs. The finite checks pass:
6,651 cube coefficient vectors, every one of 512 small subsets, 625
small-field arrangement cases, 156 kernel cases, 27 parameter cases, and
four exact regular-arrangement Fourier sums. The small-field exceptional
count test has a vacuous numerical bound, and the article explicitly says
so. No Lean formalization, independent referee certification, or
established priority is claimed. The result should be reviewed before it
is treated as a trusted dependency of later research.

## Build

Requirements: Python 3.10 or newer for the tests; a standard LaTeX installation
with `latexmk`, `pdflatex`, Latin Modern, AMS packages, `microtype`, `geometry`,
`hyperref`, `fancyhdr`, `booktabs`, and `enumitem` for the PDF.

```sh
make check
make pdf
```

Without Make:

```sh
python3 verify_fejer_selection.py --output verification-results.json
latexmk -pdf -interaction=nonstopmode -halt-on-error fejer-arrangement-selection.tex
```

The bibliography is included in the TeX source; BibTeX and external figures
are not required. No third-party paper, fonts, or vendored packages are
included in this bundle.

## Suggested integration

Add this directory as:

    Combinatorics/Ramsey/Research/GowersSzemeredi/
      local-quantitative-refinements/fejer-arrangement-selection/

Suggested index entry:

> **One-stage Fejer arrangement selection.** Replaces the repeated
> degree-one selection in Gowers' Lemma 15.5 by one high-bandwidth Fejer
> kernel. Proves single-monomial relation isolation, explicit polynomial
> parameter losses, finite-field and vector-target extensions, exact
> torsion dependence, and a positive-Fourier exponent barrier. Includes
> complete proofs and exact finite checks; not Lean-verified and not a
> claimed global improvement to Szemeredi bounds.

Keep the original paper transcription unchanged. Downstream parameter
propagation and formalization should be separate reviewed changes.
The package does not modify or commit anything to GitHub.

## Sources and scope

The inspected source is
`Combinatorics/Ramsey/Papers/sz-thm-gowers-proof/sz-thm-gowers-proof.tex`,
especially Section 15, together with the existing local-refinements index.
Repository inspection was dated 2026-10-06; no commit-pinned, repository-wide
novelty audit is claimed. Full bibliographic references appear in the article.
