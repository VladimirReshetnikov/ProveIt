Report213 The full sparse graph moment equivalent
4 October 2026

RESULT AND SCOPE
The article proves M_(2k) ~ 2 B_(k+1), using the explicitly credited
Bauer-Golinelli coefficientwise comparison as its essential external theorem.
Every required Bell estimate and the full-tree dominant-window proof are
included. The non-dominant complement and weighted middle-return sum are
smaller than B_(k+1) times every fixed negative power of k. The error in the
full relative equivalent is only o(1) here. The inverse enclosure is
existential; there is no effective onset, full-moment correction, all-order
expansion, or worldwide priority claim.

READING
Report213.pdf is the 20-page article; Report213.tex is editable source.
SOURCES.txt gives public links, exact credited results, and bounded later-source
inspection. No earlier report or private file is required.

FULL REPRODUCTION
Extract the archive. In the extracted Report213 directory run:
  python3 -B reproduce.py --out /absolute/new/output-directory \
    --reference-zip /absolute/path/Report213-reproducibility.zip
Use a new output directory outside the source tree, with an existing parent.
The reference ZIP option compares the complete rebuilt file, not just hashes
stored in a manifest. It is optional when the original archive is unavailable;
without it, every actual member and the rebuilt archive inventory are still
verified, but no original whole-ZIP comparison is claimed.

The driver verifies the source manifest before running, freshly regenerates all
finite outputs, runs normal/-O positive and deliberate-failure checks, rebuilds
the PDF to stable bytes using a private format and explicit installed font maps,
and writes an actual archive with fixed metadata. SOURCE_FILES.txt lists the
public source/data members; MANIFEST.json pins their bytes and the PDF. The
manifest excludes itself to avoid a self-reference. The ZIP includes it.

Run the same full command with `python3 -B -O` and a different output directory
to check the outer driver under optimization too. Same-toolchain reproduction
must yield identical PDF, manifest, actual member bytes and whole ZIP bytes.
It does not require internet access or files adjacent to the extracted package.
See requirements.txt for dependencies and the checked toolchain.

FINITE CHECKS ONLY
  python3 -B code/reproduce.py --out /absolute/new/finite-output-directory
This needs only the Python standard library. See code/README.md for the exact
independence and failure-test scope. It freshly generates the recurrence through
k=32 and directly enumerates all normalized walks through k=8. Compact results
are in code/results/. The article table is identical to results/table.tex.
No large extended row arrays, binary executables, or third-party texts ship.

GUARDS AND OUTPUT SAFETY
All guards use explicit checks, retained under -O. The finite harness tests
mathematical guard injections, actual result mutations, malformed JSON, source
inventory drift and output-safety conditions in both modes. A root-driver
pre-write failure can be checked by adding --self-test-failure; it must exit
nonzero and create no output directory. Changing an inventoried source byte
without updating the manifest must also fail before creating output.
Do not use --initialize for ordinary reproduction; it is an authoring option
for establishing a fresh PDF/manifest baseline, not a validation shortcut.

LIMITATIONS
Finite enumeration validates identities and encodings at its stated indices.
Regenerating the recurrence is not an independent algorithm at every higher
index. Neither computation nor a successful build certifies an asymptotic
threshold. Those conclusions rest on the article's all-index proof.
PDF byte identity is scoped to the same installed TeX/font toolchain; exact
integer and rational outputs do not depend on the display rounding.
