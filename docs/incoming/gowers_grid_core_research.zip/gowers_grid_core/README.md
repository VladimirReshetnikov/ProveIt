# Finite-grid formulae and exact core-avoidance laws for Gowers arrangements

AI-assisted research manuscript prepared for Vladimir Reshetnikov and the
ProveIt repository, 6 October 2026.

## Main results

The article targets the all-squarefree-moments degeneracy definition in
Gowers's Lemma 15.4 and the matching ProveIt interface. It builds on, rather
than reclaims, the earlier first-order and second-order classification drafts.

* A fixed nine-point-grid double count evaluates the second Whitney coefficient
  `b2(d)` in O(d^3) exact arithmetic operations and O(d^2) memory. The constants
  in these bounds do not depend on d; these are arithmetic, not unit-bit-cost,
  bounds. The result answers the earlier draft's explicit algorithm question.
* A complete finite rational certificate compresses that answer to eight
  lattice-walk energies. This compression is optional: the general grid theorem
  and its proof are independent of the finite certificate.
* The previously unspecified eight-arrangement invariant is
  `b2(8) = 3,280,234,631,541`. The exact second coefficient in the degeneracy
  proportion is `binom(k,2) - 2,519,909*k - 3,280,234,631,541`.
* Rank-two incidences are stable in characteristic `p > max(2*d,16)`.
  In particular the eight-arrangement formula needs only `p > 16`, independently
  of k, in a fixed-k asymptotic.
* Every characteristic p >= 5 has the same core profile families. Conditional
  on regular cross-sections and nonzero sides, exact core avoidance is
  `product(1 - (2^(2*d)-1+2*i)/q^2, i=0..k-1)`.
  For p = 2 or 3 it is
  `product(1 - p^(2*d-1+i)/q^2, i=0..k-1)`.
* The pair-overlap deficit has the proved asymptotic
  `7*49^d/(96*pi*sqrt(3)*d) * (1 - 5/(24*d) + O(d^-2))`.
  This proof does not use the eight-shape certificate.

The article also gives a characteristic-uniform cubic remainder, exact
small-characteristic cross-section counts, universal dimension obstructions,
growing-dimension limits for the classified obstructions, and nine further
research questions.

## Status and boundaries

Conventional mathematical proofs with a separately identified finite
computer-assisted component for the eight-shape compression. All supplied
exact checks passed. No independent referee review, literature-priority
certification, or proof-assistant verification is claimed.

Core avoidance is **not** full nondegeneracy. The remaining coefficient
families are bounded explicitly but not classified completely. The
fixed-dimension asymptotics are not asserted uniformly in growing k.
No improved final Szemeredi or van der Waerden bound is claimed.
No repository changes or formalization-ledger updates were made.

## Files

- `article.tex`, `article.pdf`: complete article and compiled PDF.
- `code/verify.py`: Python 3.10+ standard-library exact verifier.
- `data/grid_certificate.json`: all spanning templates and the universal
  compact-formula coefficient certificate.
- `data/verification.json`: exact values through d=10, independent checks,
  and separately labelled floating-point asymptotic diagnostics.
- `data/normals_d2.json`, `normals_d3.json`, `normals_d4.json`: independent
  rational normal lists for pair-span checking.
- `data/run_output.txt`: verifier's recorded console summary.
- `SOURCE_AUDIT.md`: sources, snapshot identifiers, and novelty boundaries.
- `FORMALIZATION.md`: proposed Lean dependency plan, not completed code.
- `Makefile`: PDF build and verification targets.

## Reproduction

From this directory:

```sh
python3 code/verify.py --max-d 10
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Or use `make verify` and `make pdf`. The verifier rejects Python's `-O` mode
because assertions are part of its exact checks. It makes no network calls.
The numerical `--max-d` controls the grid recurrence; the other independent
checks, including the walk asymptotic diagnostics through d=64, still run.

The PDF uses ordinary LaTeX packages and an embedded bibliography. No shell
escape, external bibliography database, images, or external fonts are needed.
A `pdflatex` fallback is provided as `make pdf-pdflatex`.

## Suggested integration

`Combinatorics/Ramsey/Research/GowersSzemeredi/finite-grid-core-avoidance/`

Source pin:
`8c12c906e4ab5a00001a65de3c882f935a15661a`.
The source and prior research comparisons are documented in `SOURCE_AUDIT.md`.
