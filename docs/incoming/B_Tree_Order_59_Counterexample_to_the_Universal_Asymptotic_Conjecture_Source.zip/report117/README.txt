REPORT 117
A counterexample to the universal B-tree-history conjecture
A cyclic-sign obstruction at B-tree order 59
2 October 2026

START HERE

Read report117.pdf. The standalone editable mathematical source is
report117.tex. The report disproves the m=29 instance of Conjecture 1
in Burghart and Wagner, On the histories of B-trees (2026), and hence
its universal formulation. The derivative order is d=30 and the B-tree
order is 59. These three numbers should not be interchanged.

For H^(30)=H^2 with H^(j)(0)=1 (0<=j<30), the report rules out
H(x) ~ (59!/29!)(rho-x)^(-30) at any finite positive rho. The published
coefficient claim implies that excluded real behavior by an elementary
Abelian argument. Instability alone would not establish this result:
the initial-data-specific closed cyclic-sign cone and the exclusion
of the entire stable subspace, followed by stable-manifold tangency,
rule out convergence of this particular all-ones orbit.

The central spectral input is seven exact integer/rational inequalities.
The main proof derives the complete spectral ordering and signs from
those inequalities without numerical root-finding or the Routh theorem.
An independent rational Routh reconstruction is included as a cross-check.
All exact arithmetic needs only the Python standard library.

The report connects the family to the smaller-order sequences A333497
(d=3, B-tree order5) and A336009 (d=4, B-tree order7). It does not assign
an OEIS identifier to the order59 member. It does not prove a replacement
coefficient law, a periodic attractor, or a global classification of
orders, and makes no claim of literature priority or external peer review.
The compact certificate certifies d=30, not a first integer transition.

FILES

report117.tex                  Standalone mathematical source
report117.pdf                  Rendered report
build.py                       Two clean, byte-identical PDF builds
pack.py                        Deterministic verified ZIP generation
CHECKSUMS.sha256                Closed package SHA-256 inventory
checks/                        Portable exact checks and fixtures
verification_results.json      Machine-readable validation results

The package contains no source-paper PDFs, private research notes,
rendering intermediates, or machine-specific source paths.

DEPENDENCIES

Exact checking, manifest validation and mutation replay: Python 3.10+
standard library only; tested with Python 3.12. No installation or
network access is needed for those checks.
PDF build: pdfTeX/pdflatex and the standard LaTeX packages geometry,
fontenc, lmodern, amsmath, amssymb, amsthm, mathtools, booktabs, microtype,
hyperref and enumitem. Tested with pdfTeX 1.40.26.

The supplied build uses the available TeX distribution and creates its
format in an isolated temporary directory. Different TeX/font versions
can produce different PDF bytes without changing the mathematics.
ZIP byte identity also assumes the same Python/zlib compression toolchain.
A fresh-directory replay is not a newly provisioned operating system.
No script installs software or accesses the network.

INTEGRITY AND EXACT CHECKS

Run from the report117 directory after extracting the ZIP:

  python3 -B checks/check_manifest.py .
  python3 -B checks/check.py
  python3 -B -O checks/check.py
  python3 -B checks/validate_bundle.py --output /tmp/report117-validation.json

The delivered verification_results.json records the successful replay.
The harness compares ordinary and optimized checks, replays both in a
fresh directory, and requires unchanged source hashes. It mutates all
132 fixture leaf values, tests all seven strict inequality boundaries,
and applies additional schema and integrity mutations. In total it runs
170 named suite mutations in normal and optimized modes (340 negative
runs), plus ten package-manifest mutations in both modes (20 more runs).
Every mutation must fail with its specific expected diagnostic; an
unexpected exception is not a successful negative test.

Every guard is explicit and remains enabled under -O. Exact checks cover
the seven inequalities, two independent Gaussian-product calculations,
the matrix characteristic polynomial, eigenvector polynomial identities,
real roots and signs, coefficient normalization and the rational Routh
count. Full scope and limitations are in checks/README.md. These finite
checks support the arithmetic and algebra; they do not prove the infinite
or analytic claims by sampling. The report gives those arguments.

The inventory is closed: missing, changed and unexpected files fail.
Use -B so Python does not add a bytecode cache to the package. Keep all
new validation outputs outside the extracted package directory.
Do not use --write to validate a received package: it replaces the
checksum inventory and is intended only for deliberate repackaging.
Checksums are modification detectors, not authenticated signatures.

REBUILD THE PDF

  python3 -B build.py
  python3 -B checks/check_manifest.py .

build.py compiles in two independent clean temporary directories, fixes
timestamps and metadata, rejects overfull boxes and unresolved references,
requires byte equality, and writes report117.pdf. It does not alter the
TeX source. The final PDF was rendered and every page visually inspected
for clipping, overlap, legibility and broken references.

RECREATE THE ZIP

  python3 -B pack.py /tmp/report117-reproducibility.zip

The output must be outside the package. pack.py first checks the strict
inventory, then writes all files beneath report117/ with sorted paths,
fixed timestamps and fixed modes. The delivered archive was freshly
extracted, its PDF rebuilt, its checks replayed, and its ZIP reproduced
byte for byte in the tested toolchain.
