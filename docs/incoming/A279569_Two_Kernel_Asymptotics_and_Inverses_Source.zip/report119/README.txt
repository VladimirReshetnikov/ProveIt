REPORT 119
Inversion sequence asymptotics from two kernel roots
A279569 and class 1953A
2 October 2026

START HERE

Read report119.pdf. The complete editable mathematical source is
report119.tex. The report proves the leading law stated numerically
for class 1953A in Britt and Beaton, Completing the enumeration of
inversion sequences avoiding triples of relations, arXiv:2512.21943v3
(29 September 2026), Sections 3.7 and 4.2. It also proves every fixed
algebraic correction and a count-index inverse theorem.

The sequence is the ordinary count of length-n inversion sequences
avoiding 110, 120 and 210, indexed from n=0. Its exponential growth is
27/4 and its power exponent is -3/2. The positive leading amplitude is
C = 0.01116841071267033797867998293487861864... . The relative 1/n and
1/n^2 corrections are about 26.94860677861165 and 53.39335656811587,
respectively. All three constants have exact outward interval
certificates, including every digit bracket displayed in the report.
The numerical amplitude was recorded by Vaclav Kotesovec in the OEIS
on 7 October 2021. The report supplies a proof and certificates, not
a claim to have discovered those digits.

This is a self-contained companion to report118. Both small cubic
kernel roots feed contracting Mobius orbits. An exact cancellation
removes the apparent orbit denominator at z=0, and the even quotient
identifies the counting germ. Joint holomorphy holds on an explicit
product domain. A real determinant gap and Pringsheim's theorem put
the radius at least at 4/27. Absolute boundary convergence and
meromorphic continuation then remove every other possible boundary
pole. This differs from the uniform complex denominator majorant
used for class1509 in report118. An exact positive-amplitude
certificate finally rules out cancellation at the critical point.

The local square-root expansion converges. The large-index expansion
is proved to every fixed order; no convergence as its order increases
is asserted. The first two corrections use finite rational Taylor
jets, a uniform complex rectangle calculation and Cauchy error bounds.

The inverse takes a target count to the least index meeting it.
Its leading real approximation uses the W_-1 branch of Lambert W.
Shrinking two-ceiling brackets retain the possible ambiguity near an
exact integer threshold. The error constants and starting thresholds
are existential. This is not a certified finite-target inverse
routine. No nonalgebraicity, non-D-finiteness, complete exponentially
improved expansion, literature-priority or external peer-review claim
is made.

FILES

report119.tex                  Standalone mathematical source
report119.pdf                  Rendered report
build.py                       Two clean byte-identical PDF builds
build-environment.txt          Tested Python and PDF toolchain
pack.py                        Deterministic verified ZIP generation
integrity.py                   Closed outer SHA-256 inventory check
CHECKSUMS.sha256                Closed package inventory
checks/                        Independent exact checks and fixtures
checks/MANIFEST.json            Closed inner checker inventory
test_integrity.py              Negative tests for outer inventory
verification_results.json      Successful checker validation summary

The package contains no source-paper PDFs, private research notes,
rendering intermediates, or private machine-specific source paths.

DEPENDENCIES

All exact checks, schema and integrity checks, and negative tests need
only Python 3.10+ standard library; tested with Python 3.12. No network
or installation is needed.

PDF build: pdfTeX/pdflatex and the standard LaTeX packages geometry,
fontenc, lmodern, amsmath, amssymb, amsthm, mathtools, booktabs, microtype,
hyperref and enumitem. Tested with pdfTeX 1.40.26.

The build creates its TeX format in an isolated temporary directory.
Different TeX/font versions may produce different PDF bytes without
changing the mathematics. ZIP byte identity likewise assumes the same
Python/zlib compression toolchain. A fresh-directory replay is not a
newly provisioned operating system. No script installs software or
accesses the network.

CHECK THE RECEIVED PACKAGE

Run from the report119 directory after extracting the ZIP:

  python3 -B integrity.py .
  python3 -B checks/run_checks.py
  python3 -B -O checks/run_checks.py
  python3 -B checks/mutation_tests.py --output /tmp/report119-checks.json
  python3 -B test_integrity.py

Use -B to prevent Python from adding bytecode-cache files to the closed
package. Put new validation outputs outside the extracted package.
Do not use integrity.py --write when validating a received package: it
replaces the inventory and is intended only for deliberate repackaging.
The inventory rejects missing, changed and unexpected files. Checksums
are modification detectors, not authenticated signatures.

The exact checker distinguishes the 26 displayed OEIS terms through
n=25 from 61 coefficients n=0,...,60 generated internally. Independent
state dynamic programming and orbit-series reconstruction agree at all
61 indices. Exhaustive counting from the original inversion-sequence
definition agrees at n=0,...,8. Scalar-functional-equation coefficients
are verified through degree16 at two rational catalytic arguments.

Exact certificates include rational normal-convergence inequalities,
the N=256 critical derivative recurrence and its Cauchy tail, Machin
arctangent intervals and integer square roots, independent exact kernel
jets in Q(sqrt(3)), N=400 interval jets, uniform complex rectangle
denominator bounds, and outward Cauchy coefficient-error widening.
Gamma-ratio coefficients are reconstructed by two independent methods;
the first inverse-correction identities are checked symbolically.
Every executable guard remains active under Python -O. The proofs of
infinite convergence and continuation are in the report; finite
checking does not replace them.

The checker README describes the closed fixture schema and complete
mutation scope. The successful campaign individually mutates all 232
fixture leaves and tests 345 named cases in normal and optimized modes,
for 690 negative runs with exact expected diagnostics. It also tests
normal and optimized
baselines, fresh-directory replay, invalid fixtures and inventory
mutations, requiring each failure to match its expected diagnostic.
The aggregate summary is saved as verification_results.json.
test_integrity.py adds ten named outer-inventory mutations in normal
and optimized modes (20 negative runs), all in fresh temporary folders.

REBUILD THE PDF

  python3 -B build.py
  python3 -B integrity.py .

The build fixes timestamps and metadata, compiles three passes in each
of two independent temporary directories, rejects overfull boxes and
unresolved references, and requires the two PDFs to be byte-identical.
Each format-generation subprocess is limited to 120 seconds and each
LaTeX pass to 180 seconds, failing closed on a timeout. It writes
report119.pdf without changing report119.tex. Every page of
the final PDF was rendered and visually checked for clipping, overlap,
legibility and broken references.

RECREATE THE ZIP

  python3 -B pack.py /tmp/report119-reproducibility.zip

The output must be outside the package. The archive script first checks
the complete inventory, then writes sorted files under report119/ with
fixed timestamps and modes. The delivered archive is freshly extracted,
its PDF rebuilt, its checks replayed, and its ZIP reproduced byte for
byte in the tested toolchain.

SOURCES

Primary paper: https://arxiv.org/html/2512.21943v3
Sequence definition and previously posted numerical amplitude:
https://oeis.org/A279569
Full mathematical references are in report119.pdf and report119.tex.
