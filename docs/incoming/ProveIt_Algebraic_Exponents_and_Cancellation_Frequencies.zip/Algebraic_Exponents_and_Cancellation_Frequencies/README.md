# Algebraic degrees and exact cancellation frequencies

This four-page continuation proves two fixed-defect results for derivatives of x^(x^a).

1. If a is positive algebraic, a != 1, and D is its degree over Q, every fixed defect r >= 4D+2 has only finitely many nonreflection cancellation cells. For irrational a no physical reflection cell exists, so every such defect is eventually entirely nonzero. The threshold is sufficient and is not claimed optimal or effective in derivative order.
2. For reduced rational 1/2 < a=p/q < 1, the nonreflection counts on defects two and three have explicit square-root constants determined by finite congruence counts. Combining these with the rational fixed-defect finiteness theorem yields the exact linear-plus-square-root cumulative count in every fixed edge window.

The global support-density problem and the persistent-line structure at a=1 are not resolved by this note.

## Contents

- `article.pdf`, `article.tex`: the new report and editable source
- `replay_low_counts.py`, `replay_low_counts.json`: independent standard-library checks of 102 parameter/defect cases
- `rational_companion.pdf`: the preceding six-page rational-exponent theorem used in the fixed-window count
- `rational_companion_source.zip`: its unchanged complete source and exact certificates
- `build_local.sh`: optional preparation-environment build helper

The algebraic theorem is proved directly by field-degree bounds, grouping of weighted polynomial factors, distinct infinity branches, and Siegel's theorem. It does not depend on a numerical scan or a conjectured geometric genus.

## Reproduction and scope

Run `python replay_low_counts.py` with Python 3. No third-party package is needed. The companion archive includes its own exact verifiers and instructions.

With a standard LaTeX installation, run `pdflatex article.tex` twice. The build helper includes environment-specific font-map settings and is optional elsewhere.

All thresholds may depend on the fixed exponent and defect. The report gives no complete finite exceptional list or bound uniform when the defect grows. Classical Schur and Siegel theorems are explicitly credited. This is a conventional mathematical research note, not a proof-assistant formalization or externally refereed publication.

The full proof and final transcription were independently reviewed. All four rendered pages were visually inspected, and the final build has no LaTeX warnings or unresolved references.
