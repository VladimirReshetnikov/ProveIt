# Report279 An obstruction and a repair for Section 13 square geometry

This package contains a mathematical article with self-contained proofs of the obstruction and geometric repair, an explicitly imported analytic coefficient theorem, editable TeX, curated Lean-source provenance, and a reproducible bounded exact companion.

The main theorem constructs data for every sufficiently large prime N with density alpha=floor(N/8)/N in [1/16,1/8]. They satisfy a genuine Section13Context, the complete Stage 13.4–13.9 predicates, all six explicit budgets of the pinned bilinear-extraction theorem, and |R|<=|Q|. Yet the chosen S×U has no proper common-step square of side two, hence no Corollary1310Grid.

The logical scope is universal retained-data-to-grid nonimplication. This does not refute existential extraction, any particular proof-term witnesses, Corollary 13.10, or Szemerédi's theorem. The function is globally zero, so other good output squares exist. The moving density is handled by uniform estimates, not by an unjustified invocation of a fixed-density asymptotic theorem.

A constructive counterpart preserves the short R used in the actual Stage 13.6 construction, partitions Q into balanced aligned parents with lengths ceil(L/2) through L, applies the existing all-scale coefficient theorem at unchanged density, and rectifies its new output inside a short parent. Taking square side |U|-1 gives density 2^-137 alpha^704 and side at least L^(2^-285 alpha^1408)-1, hence (c N^beta)^(2^-385 alpha^1856)-1. It keeps the original phase and original domain. This is existential re-selection that bypasses the unchanged Stage 13.9 encoding, not a grid implication for arbitrary already retained witnesses. No new formal implementation is claimed.

The main source pin is aad4789fcab0cc1d045d3247988596abfd4f5c2c. Commit 330102ae0f0128b5569033a63166278f56179e3b already adds a conditional quarter-density covering theorem under an explicit integer fit. Commit 2548e7fffc64de1a05eadae81b9247d9b9042c3b adds conditional aligned short-parent selection under an additional parent-size and large-scale premise. Commit 38e74b4f0a3ef56fc2402bdff5339b9d398e68d5 already weakens the parent-size premise to a linear-span condition, retaining a large-scale premise; the source status is updated further by the complete-square theorem below. These existing source results are credited and are consistent with the counterexample. Source inspection and byte verification are not Lean compilation or an axiom audit.

The earlier complete-square source is **77f7d8c1f7506254c0b2a49ce9f80ffca8d3675c**. Its `section13_complete_square_extraction_all_densities` already constructs a complete common-step square for every fixed exact density 0<alpha<=1 and sufficiently large prime N, with a subset of original A, density 2^-137 alpha^704, and side at least N^gamma, where gamma=2^-386 alpha^1856/2^(13 section13Q(alpha)). The article does not portray actual-chain square geometry as missing from this source. Its own finite-budget bound is c^(fg/2)*N^(2 gamma)-1 on the original alpha<=1/6 range, which implies the same clean N^gamma bound after enlarging a fixed-alpha threshold. The current source covers the full alpha<=1 range. A single threshold uniform over varying actual densities above a positive lower bound is not supplied by that older quantifier order; it is supplied by the later source theorem below. More precisely, for fixed irrational alpha the exact cardinality alpha*N^2 is never integral; for fixed reduced rational alpha=a/b in (0,1), integrality forces b|N^2, so no context exists for sufficiently large prime N. The pointwise statement is therefore eventually vacuous at each fixed alpha<1, without making the theorem false or its construction invalid. The article states this limitation explicitly; its own moving-density full-budget family is nonvacuous. The arbitrary-retained-witness counterexample is unaffected; its stage/grid/budget files were re-fetched at that 77f7 pin and match the primary bytes exactly.

The final source comparison is frozen at **4f8cd11982e6037060b594a3da4296260d26f715**. Its `section13_complete_square_extraction_uniform_density` has the correct order: for every fixed lower bound rho>0 there is one N0(rho), valid for every prime N>=N0 and every context with actual alpha>=rho. It constructs a proper equal-length common-step square, a bilinear subset of original A, side at least N^gamma(rho), and density at least 2^-137 rho^704. This resolves the basic uniformity limitation described for the older exact-density API. No current uniformity gap, stronger actual-density output, new explicit threshold, or new Lean verification is claimed here. The scoped v3 amendment changes source/status commentary and provenance, leaving the obstruction and direct-repair proofs unchanged.

## Contents

- `Report279.pdf`: the article
- `article.tex`: complete editable mathematical source
- `companion/exact_checks.py`: bounded exact diagnostics with deterministic JSON output
- `tests/test_companion.py`: mathematical, input-validation and CLI regressions
- `tests/test_build.py`: inventory, filesystem, subprocess, mutation and archive regressions
- `build.py`: offline reproducible builder and deterministic packager
- `SOURCES.md`: pinned source map, hashes and scope
- `provenance/`: relevant frozen Lean source snapshots and a curated source-hash inventory
- `MANIFEST.sha256`: digest inventory for the public files other than the manifest itself

Public provenance contains only the mathematically relevant Lean snapshots and curated rows recording repository path, commit, byte length, SHA-256, Git blob and pinned URL. It contains no raw retrieval responses, failed-fetch logs, private notes, status inventories or third-party paper copies; see SOURCES.md.

## Bounded checks

From the extracted `Report279` directory, using Python 3.11 or later:

    python3 -I -B -X int_max_str_digits=640 companion/exact_checks.py
    python3 -I -B -X int_max_str_digits=640 -O companion/exact_checks.py
    python3 -I -B -X int_max_str_digits=640 tests/test_companion.py
    python3 -I -B -X int_max_str_digits=640 tests/test_build.py

The package has 37 builder tests and 26 companion tests. The companion has one fixed bounded profile, no unbounded search mode, and uses the Python standard library only. Its normal and optimized JSON must agree. Checks include exact finite exponent arithmetic, the F47 geometric illustration, bounded separated-difference examples, endpoint-contained residue-chain covers, weighted product-cover averaging, square-root rounding, the fixed-step four-corner example, small convolution arrangement counts, exact cyclotomic Fourier normalization, short-carrier rectification, balanced aligned-parent partitions, their weighted density preservation, final side-|U|-1 fit, phase reversal, and source-byte inventory checks.

The fixed profile checks 45 separated-difference cases in addition to the F47 example (all 46 nonzero F47 steps are scanned), 2,080 interval-cover cases, 1,724 residue-cover cases, 10,344 weighted product-cover cases, four-corner examples for M=3 through 128, and square-root rounding for M=2 through 8192. It also checks 36 small strip-arrangement cases and 594 exact cyclotomic Fourier coefficients. The test suite separately checks all 70,144 subsets across three specified toy grids of areas 9, 12 and 16, including empty and full subsets. These are exact descriptions of bounded checks, not claims about exhaustive full-budget data.

The constructive diagnostics add 31,670 short progression prefixes, 7,824 balanced aligned-parent partitions, 23,472 weighted density-retention checks, 1,605 side-(M-1) square covers, 336 original-coordinate and reversal phase cases, 124 short-cell budget cases, and ceil(L/2)^2>=L for L=3 through 8192. The rectification scan uses primes through 43; aligned-parent height lengths are at most 64 and final constructive cover lengths at most 32. These checks import no numerical version of the analytic coefficient theorem.

Important computation limits include modulus 8192 for designated geometric and rounding helpers, geometric length 64, interval-cover diagnostic length 64, residue-cover diagnostic length 32, convolution prime modulus 31, and convolution order 8. Helpers can impose tighter caps. The only evaluator for a power of two has exponent at most 30. The listed astronomical constants are opaque expression strings; finite exponent identities are evaluated as small integers.

In particular, no command constructs a full-budget numerical witness. It does not evaluate 2^9437184, 2^(2^...), a denominator 2^7995833, the enormous graph family, or an astronomical prime. It does not use floating-point underflow to stand in for a positive exponent. Real-power monotonicity, the sine estimate, and the sufficiently-large-prime existence argument are proved in the article, not certified by the finite computation. Passing the finite checks is not a proof of the universal mathematics.

## Verify and reproduce offline

The builder requires Linux, Python 3.11 or later, `/proc/self/fd`, and a trusted system TeX installation with `/usr/bin/pdftex`, `/usr/bin/pdflatex`, lmodern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, longtable, array, xcolor and hyperref. It uses no network and no third-party Python package.

Check an exact source-only inventory or a manifest-pinned extracted distribution:

    python3 -I -B build.py verify

Run the fixed diagnostics and both test suites in normal and optimized modes, compile the article, and build the deterministic ZIP in a fresh external directory:

    python3 -I -B build.py reproduce --output /tmp/report279-rebuild

The output must be an absent or empty ordinary absolute directory outside the source, not an ancestor of the source and not a protected system location. Existing outputs are never overwritten. The original and staged source inventories and bytes are checked throughout the operation, including after subprocesses. Tests are additional verification for the trusted source workflow, not a hostile-code sandbox.

The output directory contains `Report279.pdf`, `report279_section13_geometry.zip`, its `.sha256` sidecar, `MANIFEST.sha256`, `reproduction_receipt.json`, and staging/log files. Staging and logs are excluded from the public archive. The receipt records success, report number, PDF/ZIP/manifest digests, unchanged-source status, normal/optimized checks and stdout agreement, the child integer digit limit, Python version, and scope. Starting from a manifest-pinned distribution requires rebuilt PDF bytes to match the pinned PDF exactly. Reproduction depends on installed TeX engine/package/font/compression versions; a mismatch is reported rather than silently accepted.

To package an already checked manifest-pinned distribution without compiling:

    python3 -I -B build.py package --output /tmp/report279-package

Archive member order, timestamps (7 October 2026 at 00:00 UTC), and permissions are fixed; comments and extra fields are empty. The builder checks CRCs, every member's bytes, and the exact member inventory. The external SHA-256 sidecar pins the actual ZIP. Test-runner elapsed times on stderr need not agree, but deterministic diagnostic stdout must agree between normal and optimized Python.

## Trust boundary

The builder is for the supplied trusted Python/TeX and installed trusted tools. It uses bounded reads, exact inventory allowlists, no-follow file and directory descriptors, single-link regular-file checks, exclusive output creation, bounded subprocess time/output, a minimal child environment, and disabled TeX shell escape. It rejects extra source files/directories and linked or changed staged content.

These measures do not sandbox arbitrary hostile Python or TeX, and do not protect against every action of a malicious concurrent filesystem owner. The compiler and installed resources remain trusted. A manifest checks agreement with a supplied digest list; it does not establish authorship, literature priority, mathematical truth, or source theorem correctness. The article's proof establishes the full-scale claim. No upstream repository edits, new Lean proof, compilation, whole-project audit, or new global quantitative Szemerédi bound are claimed.
