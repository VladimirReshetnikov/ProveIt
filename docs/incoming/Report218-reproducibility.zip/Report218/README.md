# Report 218

Deficit asymptotics for partitions with divisible extreme parts

The article proves the all-fixed-order expansion for D(n)=p(n)-A117086(n),
including its leading term pi*p(n)/(2*sqrt(6*n)). It includes exact Fourier
reduction, finite-n rational bounds, a stretched-exponential reciprocal-minimum
comparison with an explicit bound for every n>=90, and Lambert-branch inverse
brackets. The elementary a(n)~p(n) is background.

## Files

- Report218.pdf: complete article
- report218.tex: editable LaTeX source
- code/reproduce.py: exact standard-library calculations and validation
- code/uniform_certificates.py: exact endpoint certificates for the n>=90 bound
- code/test_reproduce.py: boundary, domain, and regression tests
- code/README.md: detailed algorithms, interfaces, checks, and scope
- generated/: regenerated CSV, semantic JSON receipt, and LaTeX tables
- rebuild.py: offline nondestructive full rebuild and ZIP creation
- MANIFEST.json and SHA256SUMS: checksums of the public payload

No private research notes, review reports, or source papers are included.
Public primary-source links and access limitations are in the article.
The checksums provide integrity checking, not authentication or a signature.

## Exact reproduction

Python 3.10 or newer is recommended. No third-party Python packages are needed.
Use a fresh destination to keep the supplied example outputs unchanged:

    python code/reproduce.py --N 1000 --output ../report218-exact
    python -O code/reproduce.py --N 1000 --output ../report218-optimized

These two runs regenerate identical semantic outputs. All guards remain active
under optimization. The program does not read saved receipts or CSV values as
arithmetic inputs. A larger original count can be requested with --N 4000;
the independent conjugate check remains through 220. See code/README.md for the
full ranges and certificate algorithm.

## Full nondestructive rebuild

The full build additionally requires an installed TeX distribution with pdfTeX,
LaTeX, Latin Modern, amsmath, amsthm, microtype, geometry, hyperref, xcolor,
booktabs, mathtools, and enumitem. No network access or package installation is
performed by the script. Run from the extracted Report218 directory:

    python rebuild.py --out ../report218-rebuilt
    python -O rebuild.py --out ../report218-rebuilt-optimized

The output directory must be new or empty. The input bundle is never overwritten.
The script verifies an existing input manifest, regenerates all exact outputs,
compares them to the bundled examples, creates a private TeX format/font map,
and compiles until consecutive PDF passes have identical bytes. It rejects
overfull boxes and unresolved references. It writes a fresh Report218 folder,
Report218-reproducibility.zip, and REBUILD_RECEIPT.json. The latter is an external
execution receipt; unlike the semantic arithmetic receipt, its mode field
intentionally distinguishes normal and optimized execution.

Use --skip-pdf for exact-only validation when TeX is unavailable. That mode does
not create a misleading incomplete ZIP. An extended count can be regenerated
separately with the exact script; the article's fixed default tables remain
at N=1000. All ZIP entry timestamps and PDF dates are fixed. Exact data and
archive ordering are deterministic; PDF bytes can differ across TeX versions.
The SHA256SUMS file includes MANIFEST.json but cannot include its own digest.

## Mathematical limits

The forward asymptotic orders, minimum, and modulus are fixed. No convergence,
growing-order expansion uniformity, or global deficit monotonicity is asserted.
The separate stretched-exponential reciprocal-minimum comparison uses a growing
auxiliary cutoff only through exact uniform inequalities. It neither establishes
an exp(-c*sqrt(n)) rate nor an asymptotic formula for the actual error. Its leading
constant is optimal only for the specific two-term majorant analyzed in the text. Smooth inverse brackets
have ineffective constants/onset and are not a universal rounding rule. The
worked n=1000 bound is certified with rational arithmetic only. Exact two-index
threshold selection and the rational enclosure offer an independent finite
threshold decision procedure. No floating computation certifies a remainder.
