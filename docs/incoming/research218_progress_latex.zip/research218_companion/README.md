# Research toward a 218 state machine

This is a progress companion, not a completed <=218-state construction.

Start with companion.pdf. Its editable source is companion.tex. The PDF includes:
- The independently reviewed full cofinal seed-K countermodel, including raw code zero, nested rebinding, coincident labels, and internal ZFC consistency.
- Exact collided-core obstructions and a carefully scoped core-only tail argument.
- The all-natural shared-cancellation equality proof and exact four-occurrence source replacement.
- The correct NOT_PROVED status of the provisional 220-state binary graph, not a claim that it was behaviorally refuted.
- The baseline unbounded invariant and a concise dominated-row certificate appendix.

Reproduce the standalone checks with Python 3:

    python3 checks/recheck.py
    python3 checks/dominated/check_dag.py
    python3 checks/dominated/audit_fragment_leaves.py
    python3 checks/dominated/derive_lr_peirce.py
    python3 checks/dominated/audit_cd59_conditional_replay.py
    python3 checks/dominated/audit_cd59_and_B_conditional_replay.py

The last two commands keep cd59 as an explicit unproved assumption. They do not complete the dominated basis. The first source checker reads all supplied code/table objects as inert data and never executes them. The dominated checks execute only the newly authored checking programs, not the received formal project or optimizer.

Rebuild with a normal TeX Live installation including Latin Modern and standard AMS/geometry/hyperref/microtype packages:

    pdflatex -interaction=nonstopmode -halt-on-error companion.tex
    pdflatex -interaction=nonstopmode -halt-on-error companion.tex

No remote resources are needed. The inert Rocq files are exact source/provenance inputs, not a complete Rocq project. No proof-assistant compilation is claimed.

PROVENANCE.json pins the supplied technical inputs and upstream mathematical source versions. SHA256SUMS.txt covers the final deliverable contents. CHECK_RESULTS.json is the result of the standalone source and invariant checks. Focused compiler pilot receipts are included as recorded evidence, not silently replayed or enlarged to full coverage.

The PDF and LaTeX archive are deliberately separate from ongoing research. Nothing in this package claims unconditional nonhalting, global minimality, an exact-219 kernel theorem, or a verified <=218-state machine.
