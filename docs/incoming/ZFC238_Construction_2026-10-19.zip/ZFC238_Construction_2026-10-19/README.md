# A 238-state binary Turing machine for ZFC consistency

**The strict target of fewer than 239 working states is achieved.** The exact machine in `machines/zfc238.tm` has 238 working states and 476 transitions, starts on an entirely blank binary tape, and includes its initialization. The report supplies an ordinary mathematical proof, formalizable in ZFC, that

\[
\mathrm{ZFC}\vdash\bigl(\neg\operatorname{Halt}(M_{238},0^{\mathbb Z})\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The mathematical calibration is inherited from the pinned ProveIt development. This package contributes the exact composition of two earlier reductions, fresh unbounded runtime and guard proofs, exact initialization, independent audits, and supplementary research. It does **not** claim a newly compiled Lean or Rocq theorem for the 238-state table, or a completed internal PA proof of the equivalence.

## Read first

- `report.pdf`: the complete report, including the exact transition table.
- `report.tex`, `sections/`, and the included research `.tex` files: editable LaTeX.
- `machines/zfc238.tm`: canonical table, working states 0–237, start 0, dispatcher 84, and separate halt outcome 238.
- `machines/zfc238_old.tm`: the same table in inherited labels, start 95, dispatcher 96, halt 254.
- `provenance.json` and `file_provenance.json`: precise source pins and file origins.
- `SHA256SUMS`: the archive's file integrity manifest; it is not a digital signature.

Canonical table SHA-256:

```text
909f29c493e0ccc5d6a481fd7a20a9a82eb934ab2aa7df17b5ec3789255a8c08
```

Inherited-label table SHA-256:

```text
069942be27db9736875ea042320e51ac3b1eac7116cbe01cdce520fa6056f78c
```

The table format is `state read write direction next_state`. Lines beginning with `#` are metadata; the first line records the start state. Every ordinary transition moves exactly one cell left or right. There are no stationary moves, prewritten input, or uncounted initialization states. The tape extends in both directions.

## The construction

Start with the boundary239 predecessor from `ZFC_239_State_Construction_2026-10-19.zip`, not the original rotation240 table. In inherited labels, change these three rows and delete both rows of state 169:

| State | Read | Previous action | New action |
|---:|---:|---|---|
| 147 | 0 | `0 R 169` | `0 R 80` |
| 80 | 0 | `0 R 25` | `0 L 106` |
| 91 | 1 | `0 L 50` | `1 L 167` |

The boundary predecessor has already eliminated state 218. Temporarily retaining a tape bit permits state 80 and existing helpers to serve the role formerly assigned to 169. The new result is the verified composition of the boundary and delayed-erasure transformations. Their individual 239-state reductions are inherited and credited in `ATTRIBUTION.md`.

The source-sensitive condition needed by delayed erasure was rechecked on the **changed boundary source**. Disjoint edited rows alone would not establish correctness. A separate complete instruction proof directly checks the literal final 238-state table.

## What was verified

| Check | Result |
|---|---|
| Exact table reconstruction and canonical bijection | 238 working states; 476 complete binary rows |
| Full unbounded final-table runtime | 8,386 guarded cases; 2,255,513 symbolic rules; all 476 rows used |
| Positive instruction durations | Affine expressions for all cases; minimum constant term 13 |
| Complete blank initialization | 409,835 transitions; independent sparse and dense interpreters and canonical-table replay |
| Final initialized tape | Exact whole configuration; 351 one-cells; logical seed `(3,0,0,0,3,0,0,0,0)` |
| Exact source equivalence | 13 stages, 25 local rotations; every ordered instruction and guarded successor checked |
| Independent local composition | 12 distinct block identities, 24 replays; complete tapes and incoming invariants |
| Fresh boundary selector guard | All 8,386 unbounded cases and complete predecessor startup; minimum positive one-run `G + 23` |
| Current source/seed compatibility | Exact static data and Git blob identities checked at the current ProveIt checkpoint |

The universal runtime proof quantifies over arbitrary natural primary registers, arbitrary nonnegative extra gap, an arbitrary first spare, and an arbitrary finite spare tail. It is an inductive proof using literal transitions and unary/list identities, not a finite sample of register values. The Python proof engine is not a proof-assistant kernel. Its exact bytes and fresh receipts are preserved for review.

## Reproduce

Python 3.10 or later and the standard library suffice. Keep assertions enabled: do not use `-O` or `-OO`, and leave `PYTHONOPTIMIZE` unset. No network connection is required.

```bash
python3 -B reproduce.py --output /tmp/zfc238-replay
```

This checks integrity, reconstructs the exact machine and complete startup, replays the source and local certificates, checks the supplementary finite results, and runs the full unbounded final-table runtime proof. Select a new or empty output directory. The delivered files are preserved; fresh work happens in a temporary copy.

To additionally replay the independent unbounded selector guard:

```bash
python3 -B reproduce.py --with-guard --output /tmp/zfc238-guard
```

To run only the packaging, reconstruction, finite-certificate and stored-evidence checks:

```bash
python3 -B reproduce.py --quick --output /tmp/zfc238-quick
```

The quick result is explicitly labeled `QUICK_CHECKS_PASS_UNBOUNDED_REPLAY_OMITTED`. It is not a replacement for the complete runtime proof. The original full runs and the assembled-package replay have separate receipts. In the preparation environment, the direct runtime proof took about 220 seconds and the separate guard proof about 302 seconds.

## Further research included

1. **A broader source associativity criterion.** The middle chunk may be arbitrary. Reassociation is valid when the first chunk has no escaping break and the third has no escaping continue. The exact before/after control graph, including all 8,386 guarded targets, is preserved.
2. **A source of depth 39.** A bounded search reduced maximum path depth from 48 to 39 while retaining 224 distinct subtrees, 6,455 instruction occurrences and maximum zero-run length 6. This source is a separate research artifact; it is not substituted into the certified 238-state runtime. No 223-node source was found in that bounded search.
3. **An obstruction to eliminating the fourth logical input.** Two finite matrices cover every finite implication term in the other three inputs, falsity and truth, with no term-depth bound. The logical subsystem cannot recover Peirce under any such replacement. A colored expansion of a set model of ZFC conditionally extends the obstruction to the complete CP/GIC bundle for all compound terms and the leaves `b`, `c`, falsity and truth. Bare `a` remains open at the full-theory level. These are nonderivability results for the stated formulas, not inequiconsistency results or state lower bounds.
4. **Alternative formalism comparison.** The report separates the existing CP/GIC theory, the route without IR, finite class-theory presentations and alternate proof languages, with the complete coding and calibration costs that a state claim must include.

## Build the report

With a normal TeX Live installation:

```bash
python3 -B verification/render_transition_table.py --check
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The PDF is compiled from the supplied sources. The transition appendix is generated from the canonical machine table. Rebuilding the PDF may change its timestamp and therefore its manifest digest; perform integrity verification before rebuilding.

## Integration

Suggested location: `Computability/BusyBeaver/Research/ZFC/candidate-composition238/`.

The pinned ProveIt checkpoint is `ce192939372ac7944fe2a0208c68a96d49fb5e3b`; the incoming archives were added in commit `83fd3585484e5dffb37992f91f7dd4d3e70c437a`. Existing source/seed data from their older pin were checked against the current checkpoint. The current rotation240 external binary theorem is acknowledged; older vendor status prose is historical.

No assertion of actual ZFC consistency, unconditional nonhalting, two-sided independence from bare consistency, a minimum possible state count, or a new kernel-checked 238-state endpoint is made.
