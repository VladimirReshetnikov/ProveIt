# Beyond Real-Rootedness
## Ultra-Log-Concavity and Approximate Counting for Preorder Support Polynomials

A September 29, 2026 research continuation of Vladimir Reshetnikov's ProveIt.
The complete mathematical article is `article.pdf`; editable source is
`article.tex`. No files in the repository were modified.

## Main result

For a finite bipartite graph H=(X,Y,E), let a_k count the nonnegative integer
vectors c on Y satisfying c(S) <= |N_H(S)| for every S, with exactly k positive
coordinates. For r=min(|X|,|Y|), the sequence a_k/binomial(r,k) is log-concave,
with positive indices exactly 0,...,nu(H). The result permits positive
vertex-product weights on matchable support pairs.

This gives the unimodality component of Dai–Hou–Liu–Thawinrak–Wang's
Problem 5.3 for every bipartite graph, and a stronger inequality than
unimodality. Every finite preorder support polynomial has ultra-log-concave
ordinary coefficients; height-two preorder gamma polynomials have
ultra-log-concave coefficients as well. General-preorder gamma
log-concavity is NOT proved here.

The article also proves complete log-concavity of the multivariate support
polynomial, conditioned and externally weighted covariance inequalities,
same-mean binomial moment domination, capacity/dilation extensions, and
FPRAS reductions for partition functions and individual ordinary coefficients.
Nine proposed research questions close the article.

## Mathematical and software status

The private-copy transversal-matroid construction is classical, not a new
construction. The support-counting bridge, Lorentzian matroid theorem, and
basis-walk theorem are imported published inputs. See `SOURCES.md` and the
article for precise attribution. These application results are unrefereed;
no worldwide priority claim or Lean verification is made.

The Python verifier checks finite instances; it does not prove infinite
statements. The package implements a reference support sampler, NOT a
production implementation of the full coefficient FPRAS. The full FPRAS is
proved as a reduction in Section 7. The sampler returns supports, not actual
integer vectors. Seeded experiments are reproducible pseudorandom tests,
not certificates of total-variation convergence.

## Contents

- `article.tex`, `article.pdf`: complete article and source.
- `build.sh`: LaTeX build command.
- `code/verify.py`: independent exact-arithmetic enumerations and inequalities.
- `code/support_sampler.py`: rational-weight basis-walk support sampler.
- `code/test_sampler.py`: interface, feasibility, and tilting-mass unit tests.
- `results/verification.json`, `.log`: completed exact run and its transcript.
- `results/sampler_smoke.json`, `.log`: 100-sample seeded demonstration.
- `results/sampler_tests.log`: seven passing tests.
- `SOURCES.md`: research provenance, imported theorem boundary, and non-claims.
- `SHA256SUMS.txt`: integrity hashes for the package contents except that file.

## Rebuild the PDF

A reasonably complete TeX Live installation with pdfLaTeX is required.
The article uses standard packages including newtx, amsthm, mathtools,
tcolorbox, TikZ, hyperref, xurl, and booktabs. It has no external figures
and no separate BibTeX step.

```sh
sh build.sh
```

On Windows, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
twice (a third run may be needed after substantial edits). No font files
are distributed.

## Reproduce the exact finite verification

Python 3.10+; standard library only. The recorded run used Python 3.13.5.
Run from the extracted package root:

```sh
python code/verify.py --max-preorder 5 --output results/rerun.json
python code/test_sampler.py
```

The completed exhaustive graph families contain 689 graphs with both shores
of size at most three and 4,096 graphs on fixed shores (3,4), for 4,785
exhaustive graph cases. The record also includes all 7,332 labeled preorders
through five elements, 75 seeded larger graph cases, 14,021 nonempty
conditioning events, 685 exact covariance tests, and 64 capacity examples.
All checks passed. The known eight-element Theta_3 example is independently
counted by original preorder ideal inequalities and has 1,281 lattice points.
The seven sampler tests include a finite audit of the tilting-mass lemma
on all 512 (3,3) bipartite graphs at five rational activities.

For a shorter run, use the default preorder size four; `--skip-3x4` omits
the largest exhaustive graph family. Exhaustive preorder sizes above five
are deliberately not accepted. Running time grows exponentially with the
explicit enumeration scopes, as expected for a verification program.

## Run the reference sampler

Each donor neighborhood is a bit mask over receiver labels 0,...,n-1.
For Theta_3 the donor rows are 14,3,5,9, with four receivers:

```sh
python code/support_sampler.py --rows 14,3,5,9 --receivers 4 \
  --samples 100 --epsilon 1/100 --seed 20260929 \
  --output results/new_samples.json
```

For external fields, add `--weights 1,2,3/2,5`. Omit `--seed` to use the
operating-system random source rather than a seeded test generator.
Each sample uses an independent restart with a conservative mixing budget.
The epsilon parameter is budgeted over the entire requested sample batch.
The theoretical bound assumes independent random bits and the cited mixing
theorem; a numerical histogram is not a proof of the bound.

## Repository snapshot

Repository: https://github.com/VladimirReshetnikov/ProveIt

Commit: `e9a57d735db2177a8cca6aaecd95a3d53a0ba678`

Target report:
`SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes/article.tex`

Article blob: `d52a2633b58e74aa653e967eb56adc1aa41bc8ae`.

The review covered the current index, target report README, relevant results,
and research questions; it was not a complete audit of every ProveIt report.
