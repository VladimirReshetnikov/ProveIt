#!/usr/bin/env python3
"""Independent, standard-library audit of the exact source-preserving U213 release.

Checks source syntax, both resolved CFGs, the one closed-factor reassociation,
transition-table structure/delta, optional dense renaming and receipt bindings,
and independently replays the exact blank initialization. This is mathematical
executable verification, not a proof-assistant kernel or a replacement for the
all-natural literal runtime derivations. All checks remain active with Python -O.
"""
from pathlib import Path
from functools import cache
from collections import Counter
import argparse, hashlib, json

OLD_SOURCE='9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083'
NEW_SOURCE='91f1a7a6c80c4ccefe4cb30716b1631493951647fca0d97d57bb0ad5b21ee032'
OLD_TABLE='5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8'
NEW_TABLE='94081dc08a8c47bd0cb5694e84333539126566106363259f62043d598c8d1bcc'
ROTATION='11010010011101010111'
PHYSICAL=(6,2,0,4,3,7,8,5,1)


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def leaf(t):return isinstance(t[0],str)


@cache
def size(t):return 1 if leaf(t)else size(t[0])+size(t[1])


@cache
def boundary(t):
    if leaf(t):
        op,a=t
        return (1 if op=='CD' else a if op=='CB' else 0,
                a if op=='CC' else 0,op=='CH')
    a,b=map(boundary,t)
    return max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2]


def source(path):
    rows=json.loads(path.read_text());by_path={};trie={}
    require(isinstance(rows,list),'Source is not a list')
    for row in rows:
        require(isinstance(row,list)and len(row)==3,'Malformed source row')
        p,op,a=row
        require(isinstance(p,str)and p and set(p)<=set('01'),'Invalid address')
        require(p not in by_path,'Duplicate source address')
        require(op in('CI','CD','CB','CC','CH'),'Invalid primitive')
        require((op=='CH'and a is None)or(op!='CH'and type(a)is int),'Bad operand')
        if op in('CI','CD'):require(0<=a<9,'Bad register')
        if op in('CB','CC'):require(a>=1,'Bad branch depth')
        by_path[p]=(op,a)
        node=trie
        for bit in p:
            require('value'not in node,'A source leaf prefixes another')
            node=node.setdefault(bit,{})
        require(not node,'A source address prefixes an existing leaf')
        node['value']=(op,a)
    order=[];bounds={}
    def visit(node,p):
        lo=len(order)
        if 'value'in node:
            require(len(node)==1,'Leaf has children');order.append([p,*node['value']])
            out=node['value']
        else:
            require(set(node)=={'0','1'},'Source tree is not full')
            out=visit(node['0'],p+'0'),visit(node['1'],p+'1')
        bounds[p]=(lo,len(order));return out
    tree=visit(trie,'')
    require(order==rows,'Source rows are not in canonical ordinal order')
    return rows,tree,bounds


def metrics(rows,t):
    seen=set()
    def walk(n):
        if n in seen:return
        seen.add(n)
        if not leaf(n):walk(n[0]);walk(n[1])
    walk(t)
    return {'dag_nodes':len(seen),'primitive_occurrences':len(rows),
            'maximum_depth':max(len(p)for p,_,_ in rows),
            'maximum_zero_run':max(len(w)for p,_,_ in rows for w in p.split('1'))}


def interval_cfg(rows,bounds):
    result=[];n=len(rows)
    for i,(p,op,a)in enumerate(rows):
        if op=='CH':targets=[]
        elif op=='CI':targets=[(i+1)%n]
        else:
            bit='1'if op=='CC'else'0';k=a if op!='CD'else 1
            ancestors=[j for j,c in enumerate(p)if c==bit]
            require(len(ancestors)>=k,'Source branch escapes its enclosing scope')
            scope=p[:ancestors[-k]]
            dest=bounds[scope][0 if op=='CC'else 1]%n
            targets=[dest,(i+1)%n]if op=='CD'else[dest]
        result.append([op,a,targets])
    return result


def counter_cfg(rows):
    lookup={p:i for i,(p,_,_)in enumerate(rows)};depth=max(map(len,lookup))
    def resolve(p):
        padded=p+'0'*depth
        for k in range(1,depth+1):
            if padded[:k]in lookup:
                require('1'not in p[k:],'Stray one beyond resolved source leaf')
                return lookup[padded[:k]]
        raise ValueError('Counter has no resolved instruction')
    def inc(p):
        return format((int(p,2)+1)%(1<<len(p)),f'0{len(p)}b')if p else''
    def cut(p,b,k):
        positions=[i for i,x in enumerate(p)if x==b]
        require(len(positions)>=k,'Counter cut escapes source')
        return p[:positions[-k]]
    out=[]
    for p,op,a in rows:
        if op=='CH':dest=[]
        elif op=='CI':dest=[resolve(inc(p))]
        elif op=='CD':dest=[resolve(inc(cut(p,'0',1))),resolve(inc(p))]
        elif op=='CB':dest=[resolve(inc(cut(p,'0',a)))]
        else:dest=[resolve(cut(p,'1',a))]
        out.append([op,a,dest])
    require(resolve('')==0,'Wrong source root')
    return out


def locate(t,p):
    for b in p:
        require(not leaf(t),'Rotation path crosses a leaf');t=t[int(b)]
    return t


def replace(t,p,new):
    if not p:return new
    k=int(p[0]);r=list(t);r[k]=replace(t[k],p[1:],new);return tuple(r)


def count_occurrences(t,target):
    return int(t==target)+(0 if leaf(t)else sum(count_occurrences(c,target)for c in t))


def table(path,halt):
    data={}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):continue
        fields=line.split();require(len(fields)==5,'Malformed transition row')
        q,b,w,d,z=fields;q,b,w,z=map(int,(q,b,w,z))
        require(q>=0 and z>=0 and b in(0,1)and w in(0,1)and d in('L','R'),
                'Invalid transition')
        require((q,b)not in data,'Duplicate transition');data[q,b]=(w,d,z)
    states={q for q,b in data}
    require(0 in states and halt not in states,'Start or halt convention failed')
    require(len(data)==2*len(states),'Wrong transition census')
    require(all((q,b)in data for q in states for b in(0,1)),'Incomplete table')
    require({z for w,d,z in data.values()}-states=={halt},'Invalid target closure')
    return data,states


def clean_frame(q,h,ones):
    if q!=84 or not ones or min(ones)!=h-1:return None
    rights=sorted(x for x in ones if x>h-1)
    if not rights or rights[0]<h+64:return None
    header=rights[0];pos=header+1;last=max(ones);values=[]
    while pos<=last:
        if pos in ones or pos+1 not in ones:return None
        pos+=1;start=pos
        while pos in ones:pos+=1
        values.append(pos-start-1)
    if len(values)<10:return None
    logical=[values[j]for j in PHYSICAL]
    if any(logical[j]for j in(1,2,8)):return None
    return {'state':q,'head':h,'gap':header-h-64,
            'registers':logical,'spares':values[9:],'one_cells':sorted(ones)}


def startup(T):
    q=h=0;ones=set()
    for tick in range(95727):
        parsed=clean_frame(q,h,ones)
        if parsed is not None:
            require(tick==95726,'Unexpected earlier calibrated root')
            require(parsed['state']==84 and parsed['head']==-8 and parsed['gap']==1,
                    'Wrong initialization position')
            require(parsed['registers']==[4]+[0]*8,'Wrong initial registers')
            require(parsed['spares']==[1]*40,'Wrong spare-register seed')
            return {'status':'EXACT_BLANK_START_PASS','steps':tick,**parsed}
        require(tick<95726,'Expected initialization checkpoint not reached')
        require((q,int(h in ones))in T,'Unexpected halt during initialization')
        w,d,z=T[q,int(h in ones)]
        if w:ones.add(h)
        else:ones.discard(h)
        h+=1 if d=='R'else-1;q=z
    raise ValueError('Initialization did not terminate')


def audit(args):
    for path,expected in[(args.old_source,OLD_SOURCE),(args.new_source,NEW_SOURCE),
                          (args.old_table,OLD_TABLE),(args.new_table,NEW_TABLE)]:
        require(sha(path)==expected,'Pinned input digest mismatch: '+path.name)
    old,ot,ob=source(args.old_source);new,nt,nb=source(args.new_source)
    require([r[1:]for r in old]==[r[1:]for r in new],'Primitive word changed')
    require(len(old)==3928,'Unexpected primitive count')
    oc=interval_cfg(old,ob);nc=interval_cfg(new,nb)
    require(oc==nc==counter_cfg(old)==counter_cfg(new),'Resolved CFG changed')
    factor=locate(ot,ROTATION)
    require(not leaf(factor)and not leaf(factor[0]),'Not a right-rotation site')
    (A,B),C=factor
    require([size(A),size(B),size(C)]==[27,47,4],'Wrong factor sizes')
    require(all(boundary(t)==(0,0,False)for t in(A,B,C)),'Open rotation factor')
    require(count_occurrences(ot,factor)==1,'Rotation factor is not unique')
    require(replace(ot,ROTATION,(A,(B,C)))==nt,'New tree is not the claimed rotation')
    require(ob[ROTATION]==nb[ROTATION]==(3659,3737),'Wrong rotation interval')
    changed_addresses=[i for i,(a,b)in enumerate(zip(old,new))if a[0]!=b[0]]
    require(changed_addresses==list(range(3659,3737)),'Unexpected address changes')
    om,nm=metrics(old,ot),metrics(new,nt)
    require(om==nm=={'dag_nodes':198,'primitive_occurrences':3928,
                      'maximum_depth':45,'maximum_zero_run':6},'Unexpected metrics')
    O,os=table(args.old_table,254);N,ns=table(args.new_table,254)
    require(len(os)==214 and len(ns)==213,'Wrong working-state count')
    require(os-ns=={215}and not ns-os,'Wrong state deletion')
    delta=[{'state':q,'read':b,'old':list(O[q,b]),'new':list(N[q,b])}
           for q,b in sorted(N)if O[q,b]!=N[q,b]]
    require(len(delta)==36,'Wrong retained-row delta')
    require(O[180,1]==(1,'R',172)and N[180,1]==(1,'R',167),'Wrong context repair')
    require(not any(z==215 for w,d,z in N.values()),'Deleted state is still targeted')
    renaming={q:i for i,q in enumerate(sorted(ns))};renaming[254]=213
    dense_hash=None
    if args.dense:
        D,ds=table(args.dense,213)
        require(ds==set(range(213)),'Dense working labels are not consecutive')
        expected={(renaming[q],b):(w,d,renaming[z])for(q,b),(w,d,z)in N.items()}
        require(D==expected,'Dense table is not the exact bijective renaming')
        dense_hash=sha(args.dense)
    if args.state_map:
        supplied={int(k):v for k,v in json.loads(args.state_map.read_text()).items()}
        require(supplied==renaming,'Supplied state map differs')
    repair=None
    if args.unrepaired:
        U,us=table(args.unrepaired,254);require(us==ns,'Unrepaired state set differs')
        changed=[key for key in N if U[key]!=N[key]]
        require(changed==[(180,1)],'Repair is not exactly one changed transition')
        require(U[180,1]==(1,'R',172),'Unrepaired transition differs')
        repair={'only_changed_row':[180,1],'old':[1,'R',172],'new':[1,'R',167],
                'unrepaired_sha256':sha(args.unrepaired)}
    seed_new=startup(N);seed_old=startup(O)
    require(seed_new==seed_old,'Old and new calibrated seeds differ')
    runtime_binding=None
    if args.runtime:
        rt=json.loads(args.runtime.read_text())
        require(rt['status']=='UNIVERSAL_MATHEMATICAL_PASS','Runtime receipt did not pass')
        require(rt['table_sha256']==NEW_TABLE and rt['sites_sha256']==NEW_SOURCE,
                'Runtime receipt is bound to different inputs')
        require(rt['working_states']==213 and rt['site_count']==3928 and
                rt['expected_cases']==rt['proved_cases']==5109 and rt['failures']==[],
                'Runtime receipt census differs')
        require(len(rt['blocks'])==4,'Wrong one-block schema count')
        runtime_binding={'status':'EXACT_RECEIPT_BINDING_PASS','cases':5109,
                         'rederived_by_this_audit':False,'sha256':sha(args.runtime)}
    if args.runtime_cases:
        cases=json.loads(args.runtime_cases.read_text())
        expected={(i,p)for i,(_,op,_)in enumerate(new)
                  for p in((False,True)if op=='CD'else(False,))}
        actual=[(c['site_index'],c['positive'])for c in cases]
        require(len(actual)==len(set(actual))==5109 and set(actual)==expected,
                'Individual runtime-case coverage is not exact')
        for c in cases:
            require(type(c['positive'])is bool and c['symbolic_steps']>0,
                    'Invalid case metadata')
            require(c['duration'][0]>0 and all(x>=0 for x in c['duration']),
                    'Case has no positive natural duration')
    return {'status':'INDEPENDENT_U213_AUDIT_PASS','old_source_sha256':OLD_SOURCE,
            'new_source_sha256':NEW_SOURCE,'old_native_table_sha256':OLD_TABLE,
            'new_native_table_sha256':NEW_TABLE,'dense_table_sha256':dense_hash,
            'source':{'exact_primitive_word_preserved':True,
                      'independent_interval_and_counter_CFGs_equal':True,
                      'rotation_path':ROTATION,'rotation_rule':'((A,B),C) -> (A,(B,C))',
                      'rotation_interval':[3659,3737],'factor_sizes':[27,47,4],
                      'all_factors_closed':True,'factor_occurrences':1,
                      'changed_instruction_addresses':78,'metrics':nm},
            'machine':{'working_states':213,'transition_rows':426,'start':0,
                       'native_halt':254,'dense_halt':213,'deleted_native_states':[215],
                       'added_native_states':[],'changed_retained_rows':36,'delta':delta,
                       'dense_renaming_checked':args.dense is not None,
                       'context_repair_against_unrepaired_candidate':repair},
            'independent_blank_start':seed_new,'runtime_receipt_binding':runtime_binding,
            'individual_runtime_coverage_checked':args.runtime_cases is not None,
            'scope':'Independent exact-source/CFG/rotation, literal-table structure and '
                    'renaming, and full blank initialization audit. Runtime receipts '
                    'are bound and their coverage checked when supplied; this script '
                    'does not rederive their arbitrary-natural runtime proofs. No '
                    'proof-assistant kernel certificate is claimed.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in('old-source','new-source','old-table','new-table'):
        p.add_argument('--'+name,type=Path,required=True)
    for name in('dense','state-map','unrepaired','runtime','runtime-cases','output'):
        p.add_argument('--'+name,type=Path)
    args=p.parse_args();result=audit(args)
    text=json.dumps(result,indent=2)+'\n'
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text)
    print(json.dumps({'status':result['status'],'source':result['source'],
                      'states':result['machine']['working_states'],
                      'rows':result['machine']['transition_rows'],
                      'startup_steps':result['independent_blank_start']['steps'],
                      'new_native_table_sha256':NEW_TABLE},indent=2))


if __name__=='__main__':main()
