#!/usr/bin/env python3
"""Deterministic, standard-library-only U214 -> U213 construction and audit.

This program does not optimize or call a solver. It checks the literal recipe,
two source CFG resolvers, every decoder prefix and every primitive entry row.
The quantified arithmetic/runtime proof and startup proof are separate checks.
"""
from __future__ import annotations
from collections import defaultdict
from functools import cache
from pathlib import Path
import argparse
import hashlib
import json


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def compact(data):
    return (json.dumps(data, separators=(',', ':')) + '\n').encode('ascii')


def leaf(node):
    return isinstance(node[0], str)


def source_tree(rows):
    instructions = {p: (op, arg) for p, op, arg in rows}
    need(len(instructions) == len(rows), 'Duplicate source path')
    prefixes = {p[:i] for p in instructions for i in range(len(p))}
    need(not prefixes.intersection(instructions), 'Source prefix collision')
    need(all(p+b in instructions or p+b in prefixes
             for p in prefixes for b in '01'), 'Incomplete source tree')

    def visit(p):
        if p in instructions:
            op, arg = instructions[p]
            need(op in ('CI', 'CD', 'CB', 'CC', 'CH'), 'Unknown primitive')
            need((op == 'CH' and arg is None) or
                 (op != 'CH' and type(arg) is int and arg >= 0), 'Bad operand')
            return op, arg
        return visit(p+'0'), visit(p+'1')

    tree = visit('')
    need(sites(tree) == rows, 'Noncanonical primitive ordering')
    return tree


def sites(node, p=''):
    if leaf(node):
        return [[p, *node]]
    return sites(node[0], p+'0') + sites(node[1], p+'1')


def internal(node, p=''):
    if leaf(node):
        return
    yield p, node
    yield from internal(node[0], p+'0')
    yield from internal(node[1], p+'1')


def subtree(node, path):
    for bit in path:
        need(not leaf(node), 'Path goes below a leaf')
        node = node[int(bit)]
    return node


@cache
def size(node):
    return 1 if leaf(node) else size(node[0])+size(node[1])


@cache
def boundary(node):
    if leaf(node):
        op, arg = node
        return (1 if op == 'CD' else arg if op == 'CB' else 0,
                arg if op == 'CC' else 0, op == 'CH')
    a, b = boundary(node[0]), boundary(node[1])
    return max(a[0]-1, b[0], 0), max(a[1], b[1]-1, 0), a[2] or b[2]


def metrics(tree):
    seen = set()

    def visit(n):
        if n in seen:
            return
        seen.add(n)
        if not leaf(n):
            visit(n[0])
            visit(n[1])

    visit(tree)
    rows = sites(tree)
    return {'dag_nodes': len(seen), 'leaf_occurrences': len(rows),
            'maximum_depth': max(len(p) for p, _, _ in rows),
            'maximum_zero_run': max(len(x) for p, _, _ in rows
                                    for x in p.split('1'))}


def graph_arithmetic(rows):
    leaves = {p: i for i, (p, _, _) in enumerate(rows)}
    depth = max(map(len, leaves))
    checks = 0

    def locate(prefix):
        nonlocal checks
        word = prefix+'0'*depth
        for length in range(1, depth+1):
            if word[:length] in leaves:
                need('1' not in prefix[length:], 'Stray one past successor leaf')
                checks += 1
                return leaves[word[:length]]
        raise ValueError('No successor leaf')

    def increment(path):
        if not path:
            return ''
        return format((int(path, 2)+1) % (1 << len(path)), '0'+str(len(path))+'b')

    def cut(path, edge, level):
        positions = [i for i, bit in enumerate(path) if bit == edge]
        return path[:positions[-level]] if len(positions) >= level else ''

    graph = []
    for p, op, arg in rows:
        if op == 'CI':
            effect, targets = ['increment', arg], [locate(increment(p))]
        elif op == 'CD':
            effect = ['decrement', arg]
            targets = [locate(increment(cut(p, '0', 1))), locate(increment(p))]
        elif op == 'CB':
            effect, targets = ['identity'], [locate(increment(cut(p, '0', arg)))]
        elif op == 'CC':
            effect, targets = ['identity'], [locate(cut(p, '1', arg))]
        else:
            effect, targets = ['halt'], []
        graph.append([effect, targets])
    need(locate('') == 0, 'Root does not enter primitive zero')
    return graph, checks


def graph_intervals(rows):
    indices = {p: i for i, (p, _, _) in enumerate(rows)}
    intervals = {}

    def visit(p):
        if p in indices:
            answer = indices[p], indices[p]+1
        else:
            a, b = visit(p+'0'), visit(p+'1')
            need(a[1] == b[0], 'Noncontiguous source intervals')
            answer = a[0], b[1]
        intervals[p] = answer
        return answer

    need(visit('') == (0, len(rows)), 'Source interval census')

    def unwind(p, edge, count):
        while p:
            last, p = p[-1], p[:-1]
            if last == edge:
                count -= 1
                if count == 0:
                    return intervals[p][1] % len(rows) if edge == '0' else intervals[p][0]
        return 0

    graph = []
    for i, (p, op, arg) in enumerate(rows):
        after = (i+1) % len(rows)
        if op == 'CI':
            effect, targets = ['increment', arg], [after]
        elif op == 'CD':
            effect, targets = ['decrement', arg], [unwind(p, '0', 1), after]
        elif op == 'CB':
            effect, targets = ['identity'], [unwind(p, '0', arg)]
        elif op == 'CC':
            effect, targets = ['identity'], [unwind(p, '1', arg)]
        else:
            effect, targets = ['halt'], []
        graph.append([effect, targets])
    return graph


def read_table(raw):
    table, starts = {}, []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q, b, w, d, z = line.split()
            q, b, w, z = map(int, (q, b, w, z))
            need((q, b) not in table and b in (0, 1) and w in (0, 1)
                 and d in ('L', 'R'), 'Malformed or duplicate transition')
            table[q, b] = w, 1 if d == 'R' else -1, z
    need(starts == [0], 'Wrong start header')
    return table


def table_bytes(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(table.items()))).encode('ascii')


def validate_table(table, count):
    states = {q for q, _ in table}
    need(len(states) == count and 0 in states and 254 not in states, 'State census')
    need(set(table) == {(q, b) for q in states for b in (0, 1)}, 'Incomplete table')
    need({z for _, _, z in table.values()}-states == {254}, 'Target closure')
    reached, todo = {0}, [0]
    for q in todo:
        for b in (0, 1):
            z = table[q, b][2]
            if z != 254 and z not in reached:
                reached.add(z)
                todo.append(z)
    need(reached == states, 'Graph-unreachable working state')
    return states


def prefix(table, path):
    tape = {-1: 1, **{i: int(bit) for i, bit in enumerate(path)}}
    original = dict(tape)
    q, head, steps = 84, 0, 0
    while head != len(path):
        need(steps < 10000, 'Prefix interpreter did not terminate')
        need(head in tape, 'Decoder inspected an unknown tape cell')
        need((q, tape[head]) in table, 'Decoder entered halt')
        w, direction, q = table[q, tape[head]]
        tape[head] = w
        head += direction
        steps += 1
    need(tape == original, 'Decoder changed the known prefix')
    return q, steps


def audit_decoder(old_table, old_tree, table, tree, assignments):
    old_roles, old_entries = defaultdict(set), defaultdict(list)
    for p, node in internal(old_tree):
        q, _ = prefix(old_table, p)
        old_roles[node].add(q)
        for bit, child in enumerate(node):
            if leaf(child):
                old_entries[(child, bit, old_table[q, bit])].append((p, q))
    need(len(assignments) == 22, 'New decoder-role census')
    selected = {}
    for row in assignments:
        node = subtree(tree, row['path'])
        need(not leaf(node) and node not in selected, 'Duplicate new source role')
        selected[node] = row['q']
    records, entries = [], []
    for p, node in internal(tree):
        q, steps = prefix(table, p)
        new_role = selected.get(node) == q
        inherited_role = q in old_roles.get(node, ())
        need(new_role or inherited_role, 'Decoder reached an unrelated source role')
        records.append({'path': p, 'state': q, 'steps': steps,
                        'new_role': new_role, 'inherited_role': inherited_role})
        for bit, child in enumerate(node):
            if not leaf(child):
                continue
            action = table[q, bit]
            matches = old_entries.get((child, bit, action), [])
            need(bool(matches), 'Primitive action is not a retained exact interface')
            # The compressed control leaf at108 inspects the preceding selector.
            if q == 108 and bit == 1:
                required = {'CC': '101', 'CB': '001'}.get(child[0])
                need(required is None or ('1'+p+'1').endswith(required),
                     'Invalid compressed-control predecessor context')
            entries.append({'path': p+str(bit), 'primitive': list(child),
                            'state': q, 'read': bit, 'action': list(action),
                            'inherited_example': list(matches[0])})
    need(len(records) == 3927 and len(entries) == 3928, 'Decoder coverage census')
    return records, entries


def build(baseline_table, baseline_sites, recipe_path, output):
    recipe = json.loads(Path(recipe_path).read_text())
    table_raw, sites_raw = Path(baseline_table).read_bytes(), Path(baseline_sites).read_bytes()
    need(sha(table_raw) == recipe['baseline_table_sha256'], 'Wrong U214 table')
    need(sha(sites_raw) == recipe['baseline_source_sha256'], 'Wrong U214 source')
    old_table, old_tree = read_table(table_raw), source_tree(json.loads(sites_raw))
    validate_table(old_table, 214)
    rotation = recipe['source_rotation']
    need(rotation['direction'] == 'right', 'Unknown source transformation')
    old_node = subtree(old_tree, rotation['path'])
    need(not leaf(old_node) and not leaf(old_node[0]), 'Expected ((A,B),C)')
    (a, b), c = old_node
    need([size(a), size(b), size(c)] == rotation['closed_factor_sizes'] == [27, 47, 4],
         'Closed factor sizes changed')
    need(all(boundary(x) == (0, 0, False) for x in (a, b, c)), 'Factor is not closed')
    replacement, occurrences = (a, (b, c)), []

    def replace(node, p='', start=0):
        if node == old_node:
            occurrences.append((p, start, start+size(node)))
            return replacement
        if leaf(node):
            return node
        return (replace(node[0], p+'0', start),
                replace(node[1], p+'1', start+size(node[0])))

    tree = replace(old_tree)
    need(occurrences == [(rotation['path'], *rotation['source_interval'])],
         'Rotation occurrence or ordinal interval changed')
    need(rotation['global_occurrences'] == 1, 'Wrong occurrence count')
    rows, old_rows = sites(tree), sites(old_tree)
    need([r[1:] for r in rows] == [r[1:] for r in old_rows], 'Primitive word changed')
    old_graph, old_checks = graph_arithmetic(old_rows)
    graph, checks = graph_arithmetic(rows)
    need(old_graph == graph == graph_intervals(rows) == graph_intervals(old_rows),
         'Source CFG changed')
    need(metrics(tree) == recipe['expected_metrics'], 'Source metric mismatch')
    source_bytes = compact(rows)
    need(sha(source_bytes) == recipe['expected_source_sha256'], 'Source digest mismatch')
    changes = recipe['changed_rows']
    need(len(changes) == 36 and len({tuple(r[:2]) for r in changes}) == 36,
         'Wrong transition patch census')
    need(recipe['removed_states'] == [215], 'Wrong removed state')
    table = {k: v for k, v in old_table.items() if k[0] != 215}
    for q, bit, w, direction, z in changes:
        need((q, bit) in table and old_table[q, bit] != (w, direction, z),
             'Patch is absent or vacuous')
        need(bit in (0, 1) and w in (0, 1) and direction in (-1, 1), 'Invalid patch')
        table[q, bit] = w, direction, z
    need(old_table[180, 1] == (1, 1, 172) and table[180, 1] == (1, 1, 167),
         'Canonical representative repair missing')
    validate_table(table, 213)
    native = table_bytes(table)
    need(sha(native) == recipe['expected_native_sha256'], 'Native table digest mismatch')
    prefixes, entries = audit_decoder(old_table, old_tree, table, tree,
                                      recipe['new_decoder_roles'])
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    (output/'u213.native.tm').write_bytes(native)
    (output/'sites.json').write_bytes(source_bytes)
    (output/'prefix_bindings.json').write_text(json.dumps(prefixes, indent=2)+'\n')
    (output/'primitive_entry_bindings.json').write_text(json.dumps(entries, indent=2)+'\n')
    result = {'status': 'SOURCE_TABLE_PREFIX_AUDIT_PASS', 'working_states': 213,
              'transition_rows': 426, 'changed_retained_rows': 36,
              'removed_states': [215], 'source_metrics': metrics(tree),
              'rotation_occurrences': occurrences, 'closed_factor_sizes': [27, 47, 4],
              'primitive_word_equal': True, 'two_independent_CFG_resolvers_equal': True,
              'source_successor_checks': checks, 'baseline_successor_checks': old_checks,
              'decoder_prefixes_checked': len(prefixes),
              'primitive_entry_bindings_checked': len(entries),
              'source_sha256': sha(source_bytes), 'native_sha256': sha(native),
              'maximum_decoder_prefix_steps': max(r['steps'] for r in prefixes),
              'scope': 'Exact source semantics, literal reconstruction, and finite decoder '
                       'interface binding. Arbitrary-natural arithmetic execution and blank '
                       'startup require the separate runtime certificates.'}
    (output/'construction_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('baseline_table', type=Path)
    p.add_argument('baseline_sites', type=Path)
    p.add_argument('recipe', type=Path)
    p.add_argument('output', type=Path)
    args = p.parse_args()
    print(json.dumps(build(args.baseline_table, args.baseline_sites,
                           args.recipe, args.output), indent=2))


if __name__ == '__main__':
    main()
