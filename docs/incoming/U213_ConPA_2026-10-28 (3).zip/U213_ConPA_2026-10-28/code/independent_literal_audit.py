#!/usr/bin/env python3
"""Independent literal census, renaming and blank-bootstrap audit for U213.

Standard library only. Does not import the compiler, allocator, or symbolic
runtime. This checks a finite bootstrap and the literal representations;
the arbitrary-register runtime and source semantics are separate obligations.
"""
import argparse
import hashlib
import json
from pathlib import Path


class AuditError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise AuditError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_text(text, halt):
    rows = {}
    starts = []
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
            continue
        if line.startswith('#'):
            continue
        fields = line.split()
        require(len(fields) == 5, f'row {number}: incorrect field count')
        state, scanned, written, direction, target = fields
        state, scanned, written, target = map(int, (state, scanned, written, target))
        require(scanned in (0, 1) and written in (0, 1), 'nonbinary symbol')
        require(direction in ('L', 'R'), 'nonunit movement')
        require((state, scanned) not in rows, 'duplicate transition')
        rows[state, scanned] = written, -1 if direction == 'L' else 1, target
    require(starts in ([], [0]), 'unexpected start declaration')
    states = {state for state, scanned in rows}
    require(0 in states and halt not in states, 'incorrect start or halt')
    require(set(rows) == {(state, scanned) for state in states for scanned in (0, 1)},
            'incomplete transition table')
    require({target for written, direction, target in rows.values()} - states == {halt},
            'incorrect target closure')
    return rows


def graph_census(rows, halt):
    states = {state for state, scanned in rows}
    reachable = {0}
    pending = [0]
    while pending:
        state = pending.pop()
        if state == halt:
            continue
        for scanned in (0, 1):
            target = rows[state, scanned][2]
            if target not in reachable:
                reachable.add(target)
                pending.append(target)
    return {
        'working_states': len(states),
        'transition_rows': len(rows),
        'start': 0,
        'halt': halt,
        'complete_binary_table': True,
        'all_moves_unit_left_or_right': True,
        'graph_reachable_working_states': len(reachable - {halt}),
        'graph_reachable_halt': halt in reachable,
        'unreachable_working_labels': sorted(states - reachable),
        'graph_scope': 'Directed transition graph only; not tape-realizable reachability.',
    }


def decode_empty_pc_root(ones, head):
    positions = sorted(ones)
    if len(positions) < 2 or positions[0] != head - 1:
        return None
    header = positions[1]
    if header < head + 64:
        return None
    cursor = header + 1
    last = positions[-1]
    physical = []
    while cursor <= last:
        if cursor in ones or cursor + 1 not in ones:
            return None
        cursor += 1
        width = 0
        while cursor in ones:
            cursor += 1
            width += 1
        physical.append(width - 1)
    if len(physical) < 10:
        return None
    # Independent spelling of the documented logical-to-physical permutation.
    logical = [physical[i] for i in (6, 2, 0, 4, 3, 7, 8, 5, 1)]
    return {
        'gap': header - head - 64,
        'physical_primary_registers': physical[:9],
        'logical_registers': logical,
        'spare_registers': physical[9:],
        'one_cells': positions,
    }


def bootstrap(rows, dense_rows, mapping, limit=1000000):
    state = dense_state = head = dense_head = 0
    ones, dense_ones = set(), set()
    trace_hash = hashlib.sha256()
    for tick in range(limit + 1):
        require(state != 254, 'unexpected halt during blank bootstrap')
        require(mapping[state] == dense_state and head == dense_head and ones == dense_ones,
                'native and dense blank computations disagree')
        decoded = decode_empty_pc_root(ones, head) if state == 84 else None
        if decoded is not None:
            # The calibrated formula registers T, W, H are zero.
            if all(decoded['physical_primary_registers'][i] == 0 for i in (0, 2, 7)):
                return {
                    'steps': tick, 'native_state': state, 'dense_state': dense_state,
                    'head': head, 'native_dense_lockstep': True,
                    'trace_sha256': trace_hash.hexdigest(), **decoded,
                }
        require(tick < limit, 'bootstrap bound exhausted')
        scanned, dense_scanned = int(head in ones), int(dense_head in dense_ones)
        written, direction, target = rows[state, scanned]
        dense_written, dense_direction, dense_target = dense_rows[dense_state, dense_scanned]
        trace_hash.update(f'{tick} {state} {head} {scanned} {written} {direction} {target}\n'.encode())
        if written:
            ones.add(head)
        else:
            ones.discard(head)
        if dense_written:
            dense_ones.add(dense_head)
        else:
            dense_ones.discard(dense_head)
        head += direction
        dense_head += dense_direction
        state, dense_state = target, dense_target
    raise AuditError('unreachable bootstrap exit')


def audit(package):
    native_path = package / 'machine/u213.native.tm'
    dense_path = package / 'machine/u213.tm'
    map_path = package / 'machine/state_map.json'
    old_path = package / 'inputs/u214.native.tm'
    native = parse_text(native_path.read_text(), 254)
    dense = parse_text(dense_path.read_text(), 213)
    old = parse_text(old_path.read_text(), 254)
    states = {q for q, b in native}
    require(len(states) == 213 and len(native) == 426, 'incorrect native census')
    require({q for q, b in dense} == set(range(213)), 'dense labels are not 0 through 212')
    mapping = {int(k): int(v) for k, v in json.loads(map_path.read_text()).items()}
    require(set(mapping) == states | {254}, 'renaming domain differs from literal labels')
    require(set(mapping.values()) == set(range(214)), 'renaming is not a bijection')
    require(mapping[0] == 0 and mapping[254] == 213, 'renaming changes start or halt')
    renamed = {(mapping[q], b): (w, d, mapping[z]) for (q, b), (w, d, z) in native.items()}
    require(renamed == dense, 'dense table is not the exact conjugate of native table')
    start = bootstrap(native, dense, mapping)
    require(start['steps'] == 95726 and start['head'] == -8, 'unexpected bootstrap duration/head')
    require(start['gap'] == 1, 'unexpected root gap')
    require(start['logical_registers'] == [4] + [0] * 8, 'unexpected logical root registers')
    require(start['spare_registers'] == [1] * 40, 'unexpected spare-register file')
    old_states = {q for q, b in old}
    changed = [
        {'state': q, 'read': b, 'old': list(old[q, b]), 'new': list(native[q, b])}
        for q, b in sorted(set(old) & set(native)) if old[q, b] != native[q, b]
    ]
    # Parser and renaming sensitivity controls. These are deliberately invalid inputs.
    controls = []
    for label, text in (
        ('duplicate row', native_path.read_text() + '0 0 1 R 94\n'),
        ('missing row', '\n'.join(line for line in native_path.read_text().splitlines()
                                  if not line.startswith('0 0 ')) + '\n'),
    ):
        try:
            parse_text(text, 254)
        except AuditError as error:
            controls.append({'control': label, 'rejected': True, 'reason': str(error)})
        else:
            raise AuditError('negative parser control was accepted')
    wrong_dense = dict(dense)
    w, d, z = wrong_dense[0, 0]
    wrong_dense[0, 0] = (1 - w, d, z)
    require(wrong_dense != renamed, 'negative renaming control was accepted')
    controls.append({'control': 'one incorrect dense write', 'rejected': True})
    return {
        'status': 'INDEPENDENT_LITERAL_AUDIT_PASS',
        'implementation': 'Independent parser and sparse-set simulator; Python standard library only.',
        'native_sha256': sha(native_path), 'dense_sha256': sha(dense_path),
        'state_map_sha256': sha(map_path), 'baseline_native_sha256': sha(old_path),
        'native_census': graph_census(native, 254), 'dense_census': graph_census(dense, 213),
        'renaming': 'Exact transition-table conjugacy; start0 and halt labels preserved.',
        'bootstrap': start,
        'baseline_diff': {
            'removed_native_labels': sorted(old_states - states),
            'added_native_labels': sorted(states - old_states),
            'changed_retained_rows_count': len(changed), 'changed_retained_rows': changed,
        },
        'negative_controls': controls,
        'scope': 'Literal census, exact native/dense identity, and finite blank initialization only. '
                 'This audit does not by itself certify arbitrary-register execution, source '
                 'semantics, consistency calibration, or nonhalting.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path, help='U213 package root')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = audit(args.package)
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({
        'status': result['status'],
        'native_sha256': result['native_sha256'], 'dense_sha256': result['dense_sha256'],
        'working_states': result['native_census']['working_states'],
        'rows': result['native_census']['transition_rows'],
        'graph_reachable_working_states': result['native_census']['graph_reachable_working_states'],
        'steps': result['bootstrap']['steps'], 'head': result['bootstrap']['head'],
        'logical_registers': result['bootstrap']['logical_registers'],
        'gap': result['bootstrap']['gap'], 'spare_count': len(result['bootstrap']['spare_registers']),
        'removed_native_labels': result['baseline_diff']['removed_native_labels'],
        'changed_retained_rows_count': result['baseline_diff']['changed_retained_rows_count'],
    }, indent=2))


if __name__ == '__main__':
    main()
