Supplementary research: separate from the accepted U213 construction
==================================================================

The primary reduction preserves U214's entire register instruction word.
It does not depend on any file in this research/ directory.

NEGATION
--------
negation/special_negation_review.txt proves uniform counter-loop contracts
for specialized 18-, 20-, and 24-primitive implementations of

  N(t) = 4 P(t,1) = 2 t^2 + 6 t + 8,
  P(x,y) = (x+y)(x+y+1)/2 + y.

All replace a 47-primitive macro while preserving all other registers,
given zero scratch registers X and Y. The four required external-entry
preconditions are certified by an inductive zero/positive abstract
invariant. The independent audit checks the invariant, entry edges,
absence of external jumps into macro interiors, exact K215 primitive
bindings, and every unchanged exterior instruction and control target.

There are twelve exact parenthesized source variants. The selected 20-site
variant shared20_0_n199_z6 has 199 distinct subtrees and 3,820 whole-program
primitive sites. Its 214-state literal compilation passes all 4,965
arbitrary-natural runtime cases. It is included under
negation/selected20_compilation with its literal table and receipts.
It did not improve on the primary U213 state count.

To rerun the independent source/invariant audit:

  python3 -B research/negation/audit_special_negation.py \
      --output /tmp/negation-audit.json

To rederive the selected 214-state runtime proof:

  python3 -B code/validate_native.py \
      research/negation/selected20_compilation/candidate214.native.tm \
      research/negation/shared20_0_n199_z6.sites.json \
      /tmp/negation-runtime

The selected macro's input assumptions are stronger than the generic
runtime frame: its zero-scratch entry invariant is an additional source
obligation, supplied by the mathematical note and independent audit.
Its actual blank seed has N=4 and all other primary registers zero.

REJECTED DETECTOR SHORTCUT
--------------------------
detector7_counterexamples.json records legal primitive frames where
redirecting native 34/read0 to (0,L,75) and deleting native50 corrupts
the program counter. The source's maximum zero-run length of six does
not control intermediate counter rewrites.

The recorded state96 is the inherited runtime checker's dispatcher
label, corresponding to native84, not dense96 of U213.
These are primitive-frame counterexamples, not claims that the blank
run reaches the listed frames. The invalid shortcut is not applied
to either delivered accepted table.

SOURCE LENGTH VERSUS STATES
----------------------------
The source-saving negation variants did not give the smallest accepted
physical table; the winning U213 retains 198 distinct subtrees and all
3,928 primitive sites. Optimizing compiled state reuse is a distinct
objective from minimizing either expanded source length or subtree count.

A bounded follow-up checked 44,732 plain state folds of U213 with radius8
and at most80steps per side, using complete primitive-phase contexts. No
additional fold was accepted. See local_search_summary.json; this is a
limited discovery search, not a lower bound or a U212 result.
