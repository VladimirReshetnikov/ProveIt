"""Independent splice and inductive-invariant audit of specialized negation sources.
No construction script or its CFG utilities are imported.
"""
from pathlib import Path
import json,hashlib,argparse
if not __debug__:
    raise RuntimeError("Audit requires enabled assertions; do not use Python -O.")
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'inputs'
DATA=Path(__file__).resolve().parent
INTERVALS=[(1071,1118),(2596,2643),(3556,3603),(3686,3733)]

def cfg(rows,wrap=True):
    bounds={}
    for i,(p,op,a) in enumerate(rows):
        for k in range(len(p)+1):
            pre=p[:k]
            if pre not in bounds:bounds[pre]=[i,i+1]
            else:bounds[pre][1]=i+1
    n=len(rows);out=[]
    for i,(p,op,a) in enumerate(rows):
        if op=='CH':targets=[]
        elif op=='CI':targets=[i+1]
        else:
            b='1' if op=='CC' else '0';k=a if op!='CD' else 1
            scopes=[j for j,c in enumerate(p) if c==b]
            assert len(scopes)>=k,(i,op,a)
            pre=p[:scopes[-k]]
            target=bounds[pre][0 if op=='CC' else 1]
            targets=[target,i+1] if op=='CD'else[target]
        if wrap:targets=[j%n for j in targets]
        out.append((op,a,targets))
    return out

def transfer(row,v):
    op,r,targets=row
    if op=='CI':
        w=list(v);w[r]=2;return[(targets[0],w)]
    if op=='CD':
        ans=[]
        if v[r]&1:
            w=list(v);w[r]=1;ans.append((targets[0],w))
        if v[r]&2:
            w=list(v);w[r]=3;ans.append((targets[1],w))
        return ans
    return[(j,v)for j in targets]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    old=json.loads((BASE/'u214_sites.json').read_text());oldcfg=cfg(old)
    absvals=json.loads((DATA/'abstract_registers.json').read_text())
    assert len(absvals)==len(old)
    assert all(v is None or (len(v)==9 and all(b in(1,2,3)for b in v)) for v in absvals)
    init=[2,1,1,1,1,1,1,1,1]
    assert all(x&~y==0 for x,y in zip(init,absvals[0]))
    induction_edges=0
    for i,v in enumerate(absvals):
        if v is None:continue
        for j,w in transfer(oldcfg[i],v):
            assert absvals[j] is not None and all(x&~y==0 for x,y in zip(w,absvals[j]))
            induction_edges+=1
    entries=[]
    for lo,hi in INTERVALS:
        found=[]
        for i,row in enumerate(oldcfg):
            if lo<=i<hi:continue
            assert all(not lo<j<hi for j in row[2]),(i,lo,hi,row)
            if absvals[i] is None:continue
            for j,w in transfer(row,absvals[i]):
                if j==lo:
                    assert w[6]==w[7]==1;found.append(i)
        assert found;entries.append({'interval':[lo,hi],'external_entry_predecessors':found,'X_zero':True,'Y_zero':True})
    K=json.loads((BASE/'k215_sites.json').read_text());kc=cfg(K)
    def chunk(lo,hi,start):
        out=[]
        for op,r,targets in kc[lo:hi]:
            assert all(lo<=j<=hi for j in targets),(lo,hi,op,r,targets)
            out.append((op,r,[start+j-lo for j in targets]))
        return out
    def word(parts):
        out=[]
        for part in parts:
            if isinstance(part,int):out.append(('CI',part,[len(out)+1]))
            else:out+=chunk(*part,len(out))
        return out
    formulas={
      'shared20':word([(26,29),1,(32,42),(99,105)]),
      'shared18':word([(32,42),7,7,(99,105)]),
      'shared24':word([(89,105),(100,104),(100,104)])}
    legacy=chunk(995,1042,0)
    for lo,hi in INTERVALS:
        got=[(op,r,[j-lo for j in ts])for op,r,ts in oldcfg[lo:hi]]
        assert got==legacy
    audited=[]
    for macrofile in sorted(DATA.glob('*.macro.json')):
        name=macrofile.name[:-len('.macro.json')];family=name.split('_')[0]
        macro=json.loads(macrofile.read_text());mc=cfg(macro,False)
        assert mc==formulas[family],name
        n=len(macro);newfile=DATA/(name+'.sites.json');new=json.loads(newfile.read_text());nc=cfg(new)
        assert len(new)==len(old)-4*(47-n)
        def shift(j):
            assert not any(lo<j<hi for lo,hi in INTERVALS)
            return j-sum(47-n for lo,hi in INTERVALS if hi<=j)
        exterior=0
        for i,row in enumerate(oldcfg):
            if any(lo<=i<hi for lo,hi in INTERVALS):continue
            op,r,targets=row
            assert nc[shift(i)]==(op,r,[shift(j)for j in targets]),(name,i)
            exterior+=1
        for lo,hi in INTERVALS:
            at=shift(lo)
            expected=[(op,r,[at+j for j in ts])for op,r,ts in mc]
            assert nc[at:at+n]==expected,(name,lo)
        audited.append({'name':name,'family':family,'macro_primitives':n,'whole_source_primitives':len(new),'source_sha256':hashlib.sha256(newfile.read_bytes()).hexdigest(),'unchanged_exterior_primitives':exterior,'exact_CFG_splices':4,'exact_K215_chunk_bindings':True})
    result={'status':'INDEPENDENT_SPECIAL_NEGATION_SOURCE_AUDIT_PASS','original_source_sha256':hashlib.sha256((BASE/'u214_sites.json').read_bytes()).hexdigest(),'checked_inductive_abstract_edges':induction_edges,'abstract_initialization_covers_N_positive_all_other_registers_zero':True,'external_entry_preconditions':entries,'variants':audited,'scope':'Independent finite inductive-invariant and exact-source-splice audit. Uniform arithmetic contracts are proved mathematically by the loop invariants in special_negation_review.txt. No proof-assistant kernel certificate or literal TM verification is claimed here.'}
    dest=args.output;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'variants':len(audited),'inductive_edges':induction_edges,'entries':entries},indent=2))
if __name__=='__main__':main()
