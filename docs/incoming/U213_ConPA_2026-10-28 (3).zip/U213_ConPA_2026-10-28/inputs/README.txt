Pinned construction inputs
==========================
The U214 ZIP is the exact supplied predecessor, with its original nested
dependencies and notices. u214.native.tm and u214_sites.json are exact
copies of its primary machine files. recipe213.json freezes the accepted
source rotation and 36-row patch.

rejected_unrepaired213.native.tm is an INVALID intermediate retained only
to audit the essential 180/read1 representative repair. It is NOT the
primary machine and must not be used as a Con(PA) candidate. The accepted
machine is ../machine/u213.tm.

k215_sites.json is the exact inherited source used to bind the optional
negation research macros. None of that optional research changes U213.
