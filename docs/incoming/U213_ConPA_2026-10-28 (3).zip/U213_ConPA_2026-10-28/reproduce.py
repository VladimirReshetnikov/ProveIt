#!/usr/bin/env python3
"""Offline U213 reconstruction, independent audits, and optional full runtime proof.

Python 3.10+, standard library only. The archive's ordinary mathematical
calibration is stated in paper/report.pdf; this is not a proof-assistant kernel.
Manifest/extraction orchestration is adapted from the supplied U214 replay.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def same(a, b):
    need(Path(a).read_bytes() == Path(b).read_bytes(),
         "Reconstructed bytes differ: " + Path(b).name)


def manifest():
    seen = set()
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        p = PurePosixPath(name)
        need(not p.is_absolute() and ".." not in p.parts and "\\" not in name,
             "Unsafe manifest path")
        need(name not in seen, "Duplicate manifest member")
        seen.add(name)
        need((ROOT / name).is_file() and not (ROOT / name).is_symlink(),
             "Missing file or symlink: " + name)
        need(sha(ROOT / name) == digest, "Digest mismatch: " + name)
    required = {
        "paper/report.tex", "paper/report.pdf",
        "machine/u213.tm", "machine/u213.native.tm", "machine/sites.json",
        "machine/state_map.json", "code/build213.py",
        "code/audit213_independent.py", "code/independent_literal_audit.py",
        "code/runtime/symbolic_runtime.py", "code/runtime/independent_runtime.py",
        "inputs/recipe213.json", "reproduce.py",
        "inputs/U214_ConPA_Reduction_2026-10-28.zip",
        "evidence/u213/runtime.json", "evidence/u213/runtime_cases.json",
        "evidence/u213/startup.json",
    }
    need(required <= seen, "Principal files omitted from manifest")
    return len(seen)


def command(script, args, work, label):
    print(label + " ...", flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    env.pop("PYTHONOPTIMIZE", None)
    proc = subprocess.run(
        [sys.executable, "-B", str(script), *map(str, args)],
        cwd=work, env=env, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True,
    )
    if proc.returncode:
        print(proc.stdout, end="")
        raise RuntimeError(label + " failed")
    print(label + ": PASS", flush=True)


def safe_extract(archive, destination):
    with zipfile.ZipFile(archive) as z:
        seen = set()
        for item in z.infolist():
            p = PurePosixPath(item.filename)
            need(not p.is_absolute() and ".." not in p.parts and
                 "\\" not in item.filename, "Unsafe archive member")
            need(item.filename not in seen, "Duplicate archive member")
            need(not stat.S_ISLNK((item.external_attr >> 16) & 0xffff),
                 "Archive contains symlink")
            seen.add(item.filename)
            target = destination.joinpath(*p.parts)
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(item) as src, target.open("wb") as dst:
                while True:
                    chunk = src.read(1048576)
                    if not chunk:
                        break
                    dst.write(chunk)


def dense_reconstruction(native, output):
    rows = []
    for line in native.read_text().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        q, b, w, d, z = line.split()
        rows.append((int(q), int(b), int(w), d, int(z)))
    states = sorted({q for q, b, w, d, z in rows})
    need(len(states) == 213 and states[0] == 0, "Incorrect native count/start")
    mapping = {q: i for i, q in enumerate(states)}
    mapping[254] = 213
    dense = "".join(f"{mapping[q]} {b} {w} {d} {mapping[z]}\n"
                    for q, b, w, d, z in rows)
    (output / "u213.tm").write_text(dense)
    (output / "state_map.json").write_text(
        json.dumps({str(k): v for k, v in sorted(mapping.items())}, indent=2) + "\n")
    same(output / "u213.tm", ROOT / "machine/u213.tm")
    same(output / "state_map.json", ROOT / "machine/state_map.json")


def runtime_audit(folder, table, source):
    summary = load(folder / "runtime.json")
    cases = load(folder / "runtime_cases.json")
    sites = load(source)
    need(summary["status"] == "UNIVERSAL_MATHEMATICAL_PASS" and
         not summary["failures"], "Runtime not proved")
    need(summary["working_states"] == 213 and
         summary["table_sha256"] == sha(table) and
         summary["sites_sha256"] == sha(source), "Runtime input binding differs")
    need(summary["checker_sha256"] == sha(ROOT / "code/runtime/symbolic_runtime.py")
         and summary["helper_sha256"] ==
         sha(ROOT / "code/runtime/independent_runtime.py"), "Runtime checker differs")
    need(summary["site_count"] == len(sites) == 3928 and
         summary["proved_cases"] == summary["expected_cases"] == len(cases) == 5109,
         "Runtime case census differs")
    expected = {(i, positive) for i, row in enumerate(sites)
                for positive in ((False, True) if row[1] == "CD" else (False,))}
    actual = [(c["site_index"], c["positive"]) for c in cases]
    need(len(actual) == len(set(actual)) == 5109 and set(actual) == expected,
         "Missing or repeated runtime case")
    need(len(summary["blocks"]) == 4, "Wrong list-induction block census")
    need(summary["startup_status"] == "CALIBRATED_DIRTY_ROOT_SEED",
         "Missing calibrated startup")
    for c in cases:
        need(type(c["positive"]) is bool and c["symbolic_steps"] > 0 and
             len(c["duration"]) == 13 and c["duration"][0] > 0 and
             all(type(x) is int and x >= 0 for x in c["duration"]),
             "Invalid symbolic case metadata")
    return summary


def main():
    need(__debug__ and not sys.flags.optimize,
         "Replay requires assertions: disable -O and PYTHONOPTIMIZE")
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--report", type=Path)
    ap.add_argument("--manifest-only", action="store_true")
    args = ap.parse_args()
    started = time.monotonic()
    files = manifest()
    if args.manifest_only:
        print(json.dumps({"status": "MANIFEST_PASS", "files": files}, indent=2))
        return
    with tempfile.TemporaryDirectory(prefix="u213-replay-") as name:
        temp = Path(name)
        out = temp / "build"
        command(ROOT / "code/build213.py",
                [ROOT / "inputs/u214.native.tm", ROOT / "inputs/u214_sites.json",
                 ROOT / "inputs/recipe213.json", out],
                temp, "Frozen source/table reconstruction and full decoder audit")
        for name in ("u213.native.tm", "sites.json"):
            same(out / name, ROOT / "machine" / name)
        for name in ("construction_audit.json", "prefix_bindings.json",
                     "primitive_entry_bindings.json"):
            same(out / name, ROOT / "evidence" / name)
        construction = load(out / "construction_audit.json")
        dense_reconstruction(out / "u213.native.tm", out)
        saved_runtime = runtime_audit(ROOT / "evidence/u213",
                                     out / "u213.native.tm", out / "sites.json")
        independent_args = [
            "--old-source", ROOT / "inputs/u214_sites.json",
            "--new-source", out / "sites.json",
            "--old-table", ROOT / "inputs/u214.native.tm",
            "--new-table", out / "u213.native.tm",
            "--dense", out / "u213.tm", "--state-map", out / "state_map.json",
            "--unrepaired", ROOT / "inputs/rejected_unrepaired213.native.tm",
            "--runtime", ROOT / "evidence/u213/runtime.json",
            "--runtime-cases", ROOT / "evidence/u213/runtime_cases.json",
            "--output", temp / "source_audit.json",
        ]
        command(ROOT / "code/audit213_independent.py", independent_args,
                temp, "Independent source/CFG/rotation/table audit")
        same(temp / "source_audit.json", ROOT / "evidence/source_independent_audit.json")
        command(ROOT / "code/independent_literal_audit.py",
                [ROOT, "--output", temp / "literal_audit.json"],
                temp, "Independent native/dense lockstep and blank initialization")
        same(temp / "literal_audit.json", ROOT / "evidence/independent_literal_audit.json")
        command(ROOT / "code/review_native_bootstrap.py", [
            "--table", out / "u213.native.tm", "--sites", out / "sites.json",
            "--startup", ROOT / "evidence/u213/startup.json",
            "--out", temp / "startup_audit.json"],
            temp, "Every startup trace row and complete tape")
        same(temp / "startup_audit.json", ROOT / "evidence/startup_trace_audit.json")
        if args.full:
            fresh = temp / "runtime"
            command(ROOT / "code/validate_native.py",
                    [out / "u213.native.tm", out / "sites.json", fresh],
                    temp, "Rederive all 5109 arbitrary-natural U213 cases")
            actual = runtime_audit(fresh, out / "u213.native.tm", out / "sites.json")
            need(actual["blocks"] == saved_runtime["blocks"], "Block certificates differ")
            for name in ("runtime_cases.json", "startup.json"):
                same(fresh / name, ROOT / "evidence/u213" / name)
        archive = ROOT / "inputs/U214_ConPA_Reduction_2026-10-28.zip"
        need(sha(archive) ==
             "b3a520e2181b739fec7257a7935b979acb00400f8d8147b5a2c212fd53a38d2c",
             "Predecessor archive differs")
        safe_extract(archive, temp / "parent")
        parent = temp / "parent/U214_ConPA_Reduction_2026-10-28"
        same(parent / "machine/u214.native.tm", ROOT / "inputs/u214.native.tm")
        same(parent / "machine/sites.json", ROOT / "inputs/u214_sites.json")
        command(parent / "reproduce.py", ["--report", temp / "parent_replay.json"],
                parent, "Inherited U214 reconstruction and proof audit")
        parent_result = load(temp / "parent_replay.json")
        need(parent_result["status"] == "U214_RECONSTRUCTION_AND_PROOF_AUDIT_PASS",
             "Predecessor replay failed")
        report = {
            "status": "U213_FULL_REPRODUCTION_PASS" if args.full
                      else "U213_RECONSTRUCTION_AND_PROOF_AUDIT_PASS",
            "manifest_files": files, "construction": construction,
            "native_sha256": sha(ROOT / "machine/u213.native.tm"),
            "dense_sha256": sha(ROOT / "machine/u213.tm"),
            "source_sha256": sha(ROOT / "machine/sites.json"),
            "working_states": 213, "transition_rows": 426,
            "independent_source_and_literal_audits": True,
            "startup_steps": 95726, "startup_registers": [4] + [0] * 8,
            "startup_gap": 1, "startup_spares": [1] * 40,
            "symbolic_cases": 5109,
            "symbolic_cases_rederived": 5109 if args.full else 0,
            "all_runtime_case_records_reproduced": bool(args.full),
            "inherited_U214_audit": True,
            "seconds": round(time.monotonic() - started, 3),
            "scope": "Exact construction, source equivalence, complete finite startup, "
                     "and whole-tape mathematical unary/list-inductive verification. "
                     "The paper states inherited U/W/PA consistency-calibration dependencies. "
                     "No newly compiled proof-assistant endpoint certificate.",
        }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
