# Toward a 218-state ZFC-consistency machine

**The requested bound was not achieved. This packet contains no validated machine with 218 or fewer working states.** Its two fully checked transition tables each have **219 working states**, two tape symbols, a blank start, and a separate halt outcome. Smaller source grammars in the research directory are explicitly conditional and are not solutions to the consistency-equivalence problem.

Prepared for Vladimir Reshetnikov's ProveIt project on 20 October 2026, against commit `26d5de6d21fa354d50e0b84fe851c289925b8d72`.

## Results

1. **An exact-theory two-row variant of K219.** The ungated rho6 row changes from `D(a,c)` to `D(a,b)`, where `D(i,A) = (Ex_i Q_i A) -> A`. Both parameterizations have exactly the same range of numerical axiom codes. The native table changes only `(199,1): 1 R 166 -> 1 R 12` and `(206,0): 0 R 186 -> 0 R 76`. All 6,167 unbounded primitive interfaces pass, with 1,516,088 symbolic rules. This is a new 219-state compiler seed, not a state-count improvement.

2. **A second verified 219-state seed.** The six-leaf inert insertion from the K220 alternatives composes with the K219 equality optimization. A fresh finite inductive invariant proves that only two zero guards of the inserted code execute, and exact graph contraction preserves the old source behavior. All 6,175 unbounded primitive interfaces pass, with 1,508,163 symbolic rules.

3. **A new consistency-strength obstruction.** Replacing only `(Ex_i Q_i A) -> A` by `Q_i A -> A` makes the exact remaining native calculus provably consistent in ZFC. The report constructs a two-world model on hereditarily countable sets, validates every remaining row and the complete support-bearing K bundle, and handles coincident labels and exceptional codes. Thus, assuming ZFC is consistent, that replacement cannot satisfy the requested ZFC-provable equivalence with `Con(ZFC)`.

4. **A broader fourth-parameter obstruction.** The inherited four-valued HC construction validates every restricted propositional row whose fourth input has outer constructor implication, quantification, or equality. This rules out an entire family of seemingly economical replacements. Membership-headed inputs lie outside this obstruction, but their reverse consistency calibration remains unproved.

5. **Positive formalism reductions with unfavorable encodings.** Fixing the public K variables preserves consistency strength when full membership vacuity remains available. The measured source grammars are larger. Direct formula length and compiled state count are different objectives.

6. **Reproducible negative encoding searches.** Local state deletion, synthesized incoming bypasses, relaxed auxiliary tape frames, control-flow bisimulation, liveness, expanded equality grammars, physical rotations, and occurrence-local source reassociation produced no validated 218-state table. Each count has a stated search scope; none is a minimality theorem.

## Main files

| Path | Purpose |
|---|---|
| `report/report.pdf` | Complete mathematical report and both canonical transition tables |
| `report/report.tex`, `report/theory.tex`, `report/nop.tex`, `report/halt_specialization.tex` | Editable LaTeX sources |
| `machines/rho6_219/` | Two-row exact-theory variant: native table, canonical table, source, state map |
| `machines/nop219/` | Inert-insertion variant with the same files |
| `machines/manifest.json` | Counts, hashes, exact native patches, numbering conventions |
| `verification/replay.py` | Portable offline reconstruction and full runtime replay |
| `verification/check_source_closure.py` | Independent exact closed-subtree audit for the rho6 replacement |
| `verification/recorded/` | Fresh full-replay receipts and case records |
| `research/` | Detailed theory notes, standalone finite checkers, conditional sources, encoding searches |
| `vendor/K219_Construction_2026-10-20.zip` | Unchanged pinned predecessor, recursively containing its dependencies |
| `provenance.json`, `SHA256SUMS` | Input identity and final file integrity |

## Reproduce the new machine checks

Use Python 3.10 or newer, with assertions enabled. The standard library suffices. From this packet's root, choose a new output directory outside the packet:

```bash
python3 -B verification/replay.py --output-dir ../fresh-replay
python3 -B verification/check_source_closure.py
```

The output directory for `replay.py` must not already exist. No network access is required. The driver verifies and extracts the pinned K219/K220/K221 archives, checks the imported dependency hashes, reconstructs the two exact patches, validates source syntax and control graphs, checks decoder binding and canonical table relabeling, simulates the complete blank prefix twice, and freshly proves all guarded primitive interfaces.

The full run in this investigation passed for both machines. The two runtime phases took approximately 318 and 121 seconds on the available shared machine; these are observed durations, not performance guarantees. Complete receipts are under `verification/recorded/`.

For only one variant:

```bash
python3 -B verification/replay.py --variant rho6_219 --output-dir ../rho6-replay
```

The optional fast audit omits unbounded runtime proof construction and says so in its receipt:

```bash
python3 -B verification/replay.py --quick --output-dir ../quick-replay
```

Do not report a quick audit as a complete verification.

## Check the finite theory identities

```bash
python3 -B research/check_outer_head_obstruction.py
python3 -B research/check_t_replacement_countermodel.py
```

These scripts exhaust the finite algebra described in the report. They do not, by themselves, prove the infinite HC model theorem. That argument is supplied as ordinary mathematics, including the countable witness closure needed for the full K bundle.

## Build the PDF

With `pdflatex` installed:

```bash
sh report/build.sh
```

The build script regenerates both exact table appendices directly from the delivered canonical `.tm` files. Machine rows have the format `state read write direction next_state`. The canonical tables use working states 0–218, start 0, dispatcher 23, and terminal 219. Native tables retain the predecessor's sparse state labels, start 0, dispatcher 84, and terminal 254.

## Verification boundary

The new machine theorem composes the pinned predecessor's ZFC calibration with new ordinary source proofs, exact finite construction audits, and unbounded symbolic simulation. The symbolic rules induct over arbitrary unary lengths and finite spare lists; their finite proof-search limit does not bound the represented counter values or Turing-machine runtime.

No newly compiled Lean or Rocq theorem for these exact tables is claimed. No unconditional non-halting claim is made independently of `Con(ZFC)`. The unsuccessful discovery screens are not proofs that 218 states are impossible. The `conditional_membership` sources have only the upper consistency direction established and are not calibrated Turing-machine candidates.

The original licenses and notices remain in the unchanged vendored archive. New material is supplied under the same MIT No Attribution license; see `LICENSE` and `ATTRIBUTION.md`.
