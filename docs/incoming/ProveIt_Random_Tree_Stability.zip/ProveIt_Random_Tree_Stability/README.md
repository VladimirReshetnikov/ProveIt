# Rare Stable Markings on Random Trees

**Exact enumeration, sparse transitions, conditioned geometry, and annealed–quenched separation**

Prepared for Vladimir Reshetnikov, 30 September 2026. Mathematical development and computation: ChatGPT.

## Article

`article.pdf` is the 23-page compiled article. `article.tex` is its complete,
self-contained LaTeX source. No external figures or bibliography database are
needed. The paper includes ten further research questions, explicit proofs,
numerical tables, and a dependency audit.

The question comes from Part VIII of ProveIt's preorder-root-polytope report,
source label `mts:q:random`: determine stable-marking probabilities for specified
random-tree models and marking laws. This article uses the uniform labelled
Cayley tree and independent Bernoulli marking. It imports the repository's
branch-complete/ADE-skeleton stability classification, and derives the
probability and geometry results from that criterion.

Pinned ProveIt commit:
`b8b0fa2184a044d46ce9ed0f25f88d7bb60fa042`

Source file:
`SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes/article.tex`

Source blob:
`ba1cc4a6c99abd5ff808aae97df75efe434833e9`

## Main results

For a random labelled tree on n vertices, mark each vertex independently with
probability p, and let pi_n(p) be the probability of matching-support stability.

* Throughout p*sqrt(n) -> infinity,
  pi_n(p) ~ (9/8)*sqrt(2*pi)*p^3*n^(5/2)*exp(-n*p).
* At p*sqrt(n) -> lambda > 0, pi_n(p) ~ n*(1-p)^n*Psi(lambda), with an
  explicit entire crossover function and limiting mark-count/chi-hull mixture.
* Below that window, the probability is asymptotically the probability of at
  most two marks.
* For fixed 0 < p < 1, stability conditioning gives np^2 marks, a hull of size
  np, and diameter np to first order, with a proved joint Gaussian law.
* For every fixed host tree, its diameter determines the stable-marking
  probability up to a polynomial factor. A typical Cayley host has logarithmic
  probability rate log(1-p), whereas the tree-averaged rate is -p.

The paper also proves exact joint counts, a finite-correction Poisson identity,
constant-order conditional cumulants, a conditional diameter estimate, and a
constant-tail skeleton universality theorem.

## Verification and trust boundary

`code/verify.py` enumerated 18,249 labelled trees of orders 1–7 and all
2,238,526 marked-tree pairs. All 70 exact joint counting bins agreed with the
formula. It also performed 306 high-precision probability/moment comparisons
against exact rational histograms.

`code/extra_checks.py` performed 170 exact rational Poisson-identity checks,
435 nonisomorphic-tree comparisons of the shape list with an exact spectral
PSD test, inverse-automorphism coefficient checks through order 11, and ten
symbolic cumulant-derivative checks.

These checks were executed. They are not proof-assistant certificates and do
not independently prove the imported all-size stable-polynomial classification.
The mathematical proofs are ordinary proofs, not Lean or Rocq formalizations.
Independent refereeing and global publication priority are not established.
No remote repository was changed.

## Reproduce

Python 3.11 or later is required for the pinned dependency versions. The core
verifier source is also compatible with Python 3.10 and compatible library
versions. The pinned versions used in the completed run
are in `requirements.txt`; the full environment is in `data/environment.json`.

```sh
python -m pip install -r requirements.txt
python code/verify.py --max-n 7 --tables
python code/extra_checks.py
```

The `--tables` flag runs the finite checks and then generates the asymptotic
comparison tables. Exhaustive enumeration grows very rapidly with `--max-n`;
seven is the completed bound. No internet access is used by the scripts.

Compile the article with a TeX installation containing newpx, amsmath,
mathtools, microtype, booktabs, tabularx, tcolorbox, titlesec, and hyperref:

```sh
sh build.sh
```

## Package contents

`article.tex`, `article.pdf`: source and compiled article.

`code/`: executable enumeration, numerical evaluation, and independent checks.

`data/`: recorded exact checks, high-precision CSV tables, run logs, and environment.

`PROOF_STATUS.md`, `SOURCE_AUDIT.md`: contribution/dependency boundary and sources.

`SHA256SUMS.txt`: checksums of the delivered files, excluding the checksum list itself.
