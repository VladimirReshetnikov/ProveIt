# Sharp Boolean Phase Integration from Gowers Derivative Spectra

**Exact cubic obstruction ranks, repeated-variable certification, finite-abelian orthogonality, and a quartic reduction**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and the ProveIt project, 6 October 2026.

## Main results

The 26-page article contains full mathematical proofs, constructions attaining the sharp bounds, and ten further research questions. Its energy is the normalized mean squared selected Fourier coefficient of the multiplicative derivatives of one bounded function. The tensor includes the frequency-evaluation variable.

- **Exact cubic obstruction and repair (Theorem 7.4).** For a symmetric trilinear tensor over F_2, the maximum tested energy is `2^(-rank(Omega_T)/2)`, where `Omega_T(a,b) = T(a,a,b) + T(a,b,b)`. Half this alternating rank is also the minimum codimension of a subspace on which the tensor integrates. Both assertions are sharp, in all dimensions.
- **Sharp Boolean certification (Theorem 6.4).** For a d-linear tensor, energy greater than `1 - 2^(1-d)` certifies a nonclassical degree-d primitive and gives exact, lossless phase removal. Symmetry need not be assumed. An amplitude-sensitive repeated-variable rank profile supplies the additional low-characteristic identities.
- **Finite-abelian orthogonality (Theorem 3.2).** A sharp mixed estimate is proved without division by two, with coefficient the reciprocal square root of the index of the alternating radical. This includes characteristic two and composite moduli. Section 4 obtains a sharp group-dependent symmetry threshold.
- **Related published local estimates (Theorems 8.1 and 8.3).** The eighth power in Tidor's Lemma 4.1 is replaced by the optimal fourth power. Under the same seven-function hypotheses as Tidor's Proposition 4.6, the codimension bound is reduced from `8 log_2(1/delta)` to `floor(2 log_2(1/delta))`. The coefficient two in this mixed repair bound is not claimed optimal.
- **Quartic extremizers (Theorems 9.2 and 9.3; Corollary 9.4).** The symmetric nonintegrable quartic maximum on F_2^2 is exactly `11/16`, for all complex functions in the unit disc, not just a phase grid. In every dimension, the remaining universal extremal problem reduces to one explicit two-coordinate tensor. Whether unused ambient coordinates can raise its maximum above `11/16` remains open here.

Known nonclassical integration and finite Heisenberg algebra are explicitly credited as background. The proposed contributions are the spectral refinements, exact extremal and repair laws, and their applications. Publication priority is not established by the targeted source search.

## Contents

| File | Purpose |
|---|---|
| `boolean_phase_integration.tex` | Self-contained LaTeX manuscript, including bibliography |
| `boolean_phase_integration.pdf` | Compiled article |
| `checks/verify.py` | Exact finite supplementary checks; Python standard library only |
| `data/verification.json` | Generated check results, finite scopes, and quartic monomial certificate |
| `data/source_audit.json` | Pinned repository comparison, literature references, and claim boundaries |
| `data/build_report.json` | Compilation, rendering, and package validation record |
| `FORMALIZATION.md` | Proposed definitions, dependencies, and proof obligations |
| `Makefile` | Local build, check, and clean targets |

## Reproduce

Python 3.10 or later is sufficient for the checks. No external Python packages or network access are required. Assertions are part of the checker; running Python with `-O` is explicitly rejected.

```sh
python3 checks/verify.py
```

The checker writes `data/verification.json` relative to its own location and may be invoked from another working directory. All mathematical comparisons use integers, rational arithmetic, or exact arithmetic in Q(sqrt(2)); the runtime measurement alone is a floating-point number. The deterministic seed is 20261006, with a separate sampled test using seed plus one.

Build the article with a LaTeX installation containing `amsmath`, `amssymb`, `amsthm`, `mathtools`, `mathrsfs`, `lmodern`, `microtype`, `geometry`, `booktabs`, `array`, `longtable`, `enumitem`, `xcolor`, `hyperref`, and `fancyhdr`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error boolean_phase_integration.tex
pdflatex -interaction=nonstopmode -halt-on-error boolean_phase_integration.tex
```

Alternatively, run `make all check`. There are no external bibliography, image, font-file, or shell-escape dependencies.

The exact checks include 8,192 symmetric cubic energies; 15,360 nonsymmetric cubic energies; 217,600 primitive derivative identities; 15,360 pointwise shear identities with nonunit amplitudes and zeros; 93 composite-modulus cases; 1,024 sampled seven-function cases; a complete 1,024-term quartic cube expansion; and a 4,096-function sixteenth-root phase grid. Canonical cubic blocks, optimal isotropic restrictions, and general endpoint constructions are also checked. These checks supplement the proofs; they do not establish the arbitrary-dimensional theorems or the continuous quartic maximum by enumeration.

## Repository integration

Suggested new directory:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/boolean-phase-integration/
```

This is a suggested placement, not a repository modification. The article's labels and bibliography keys use the prefix `bpi:`. Keep the package's relative paths intact so its checks and Makefile continue to work. The source comparison is pinned to commit `797aa3cfe967349322b806692a500f677f7047cf`; the aggregate research README was inspected separately at its recorded blob.

**Important interface distinction:** the existing Lean predicate `IsMultilinear` in the compared `Definitions.lean` permits a constant term and all lower-order terms; it is multiaffine in the terminology of this article. The new tensor theorems concern homogeneous multiadditive tensors. They are not drop-in replacements for that full predicate. Section 10 and `FORMALIZATION.md` explain the separate ambient-group, phase-value-group, and normalization interfaces.

No new statement in this package is Lean-verified. Do not add these statements to the formal project's verified theorem count or mark an existing obligation closed on the basis of this manuscript alone. No new end-to-end Szemeredi or Ramsey bound is claimed. The manuscript has not been independently refereed.
