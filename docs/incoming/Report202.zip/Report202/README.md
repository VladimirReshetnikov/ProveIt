# Report 202: First relative corrections for power weighted Dyck moments

Release date: 4 October 2026. Start with `Report202.pdf`; its complete source is
`Report202.tex`. The article covers three relative correction regimes, local
occupation below the arch top, cumulative perturbations, exact-base relative
inverses, and unconditional quadratic/quartic polynomial consequences.

No new unconditional general-p absolute first correction, next nonzero term
after cancellation, effective onset, first-proof, or exhaustive-literature
claim is made. The stronger Freud source implication remains conditional.
Finite computation does not replace the article's mathematical proofs.

## Reproduce the complete extracted release

Requirements:

- Python 3.10 or newer; the recorded replay used Python 3.12.14
- mpmath 1.3.0, the only nonstandard Python dependency
- A pdfTeX/LaTeX installation providing the article's packages and fonts
  (`amsmath`, `amssymb`, `amsthm`, `mathtools`, `lmodern`, `microtype`, `geometry`,
  `booktabs`, `array`, `xcolor`, `enumitem`, `fancyhdr`, and `hyperref`)
- `pdflatex` and `kpsewhich`; if a system pdflatex format is absent, `pdftex`
  initializes a private format from the already installed TeX distribution

No network or private source directory is needed. If mpmath is not installed,
install the pinned dependency in your own chosen environment using
`python -m pip install -r requirements.txt` before the offline replay.

From the extracted `Report202` directory, choose fresh, nonnested destinations:

    python build.py --validate-only
    python build.py --output ../replay-normal --archive ../replay-normal.zip
    python -O build.py --output ../replay-optimized --archive ../replay-optimized.zip

A normal build validates the entire input package, copies only declared
sources to a temporary directory, reruns exact checks and numerical
diagnostics, runs both guard suites, compiles the PDF to a stable fixed point,
and checks every regenerated public member byte-for-byte against the input.
It then writes a ZIP with a sorted inventory, fixed timestamps, permissions,
and uncompressed member bytes. The two replay ZIPs must be identical to one
another and to the original release ZIP. ZIP members retain the fixed top-level
name `Report202/`, irrespective of the output directory name.

Use the same recorded TeX distribution/packages/fonts for PDF and whole-ZIP
byte identity. The source manifest pins the pdfTeX banner; this is a useful
check, not a complete fingerprint of every TeX package. An altered toolchain
can produce different bytes and the normal build will reject the mismatch.
Cross-distribution PDF byte identity is not promised. TeX runs without shell
escape and in a private HOME, cache, font, and temporary environment. The
builder makes no system-wide format, font-map, or configuration changes.

The source manifest and package manifest cover all declared files except their
unavoidable self-reference: the source manifest lists source files, and the
package manifest lists every member except itself. Together with the fixed
inventory, they detect missing, extra, reordered, renamed, and altered files.
They are reproducibility/integrity records, not authenticity signatures. Do
not treat an unsigned archive from an untrusted party as authenticated code.

`--validate-only` checks inventory, canonical manifests, lengths and hashes. It
does not run mathematical checks, validate TeX, or establish byte reproduction.
The complete build commands above do those additional steps.

## Finite checks and diagnostics

At the release settings, reproduction performs:

- 4,549 exact finite predicates (4,421 equalities and 128 positivity predicates)
- 268 separately labeled multiprecision predicates
- 110 reproduction guard checks, including malformed/rehashed-data rejection
  and explicit checks under optimized Python
- 72 package/manifest/ZIP guard checks

Convergence and inverse rows are diagnostics, not proofs or certified error
enclosures. See `repro/README.md` for the complete inventory, model definitions,
scales, fixture provenance, and standalone commands. The exact mode uses only
Python's standard library; mpmath is imported only for numerical work.

## Complete public inventory

Maintained source files (11):

    README.md
    Report202.tex
    build.py
    test_guards.py
    requirements.txt
    repro/README.md
    repro/check.py
    repro/diagnostics.py
    repro/test_guards.py
    repro/requirements.txt
    repro/data/fixtures.json

Generated reproduction files (4):

    repro/generated/exact_checks.json
    repro/generated/exact_data.json
    repro/generated/numerical_diagnostics.json
    repro/generated/manifest.json

Other generated members (3):

    Report202.pdf
    manifests/source_manifest.json
    manifests/package_manifest.json

There are exactly 18 public members. Raw research receipts, private paths,
audit scratch files, downloaded third-party source PDFs, bytecode, LaTeX logs,
and temporary build files are not public members.

## Maintainer initialization

A new release must be initialized from the 11 maintained source files in a
staging directory. This authoring-only command is intentionally different from
normal frozen-release verification:

    python build.py --initialize --output ../new-release --archive ../new-release.zip

It generates the data, PDF, and manifests rather than asserting equality to an
existing frozen release. It neither audits nor publishes the resulting
package. After initialization, perform a normal rebuild from a real ZIP
extraction and any independent article/package audits before release. Never
use `--initialize` to mask an unexpected normal-replay mismatch.
