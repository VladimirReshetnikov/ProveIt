# Sharp Pumping Bounds and Canonical Diophantine Certificates

**Priority Arithmetic Computation: FRACTRAN, ordered multiset rewriting,
and finitely certified nontermination**

Research manuscript dated 30 September 2026. Start with `article.pdf`;
`article.tex` is the complete, editable LaTeX source, including its bibliography.

## Main results

For an ordered multiset program, let H be the largest coordinate of any
consumption vector (the largest prime exponent in a reduced FRACTRAN
denominator). For every fixed nonempty instruction word:

* Its exact repetition capacity, allowing the initial state to vary, is
  computed by a closed least-seed and two-sided collision-window formula.
* A finite capacity is at most 2H. Thus execution of 2H+1 copies from some
  state implies execution of arbitrarily many finite copies from suitable
  states. A three-fraction family attains capacity 2H.
* A fixed-word endpoint relation has an explicit uniform quartic polynomial
  with exactly one natural auxiliary witness for every true instance.
  The number of variables does not depend on the repetition count.

The paper also proves an exact infinite-periodic-tail criterion, a
computably-enumerable completeness theorem for eventual instruction
periodicity even for one fixed squarefree-denominator program, and soundness of a broader affine macro certificate class.
A six-fraction doubling program separates that class from periodic tails.

**The quantifiers matter:** arbitrary finite repetition from suitable states
is not necessarily infinite repetition from one state. **The interface
matters:** words are fixed schemas and states are supplied as exponent
vectors, not implicitly converted from raw integers at no cost.

## Status

The proofs are in the article. They are unrefereed and have not been
formalized or checked in Lean/Rocq. Literature-wide priority for these exact
formulations is not established. The finite tests do not prove the theorems.
No new universality theorem, universal single-fold MRDP result, complete
nontermination decision procedure, or improved universal operation count is
claimed. The source audit and its limits are recorded in `provenance.md`.

## Files

- `article.tex`, `article.pdf`: full article, proofs, examples, research
  questions, formalization roadmap, and claims/non-claims ledger.
- `code/priority_certificates.py`: exact sparse-polynomial compiler,
  canonical witness constructor, simulators, interval checker, capacity,
  least-seed, infinite-period, and maximal-copy algorithms.
- `code/test_priority_certificates.py`: reproducible finite tests.
- `code/generate_instances.py`: generates two explicit polynomial/witness pairs.
- `code/verify_export.py`: independent JSON polynomial evaluator. It does
  not import or invoke the compiler.
- `results/verification.json`, `results/test_output.txt`: the recorded test
  report, including 114,875 counted finite checks and exact circuit sizes.
- `results/example_certificate.json`, `results/example_instance.json`:
  a uniform two-rule/two-coordinate polynomial plus a concrete witness for
  two applications of rule 2 in `(1/72, 3/2)`, taking 32 to 72.
- `results/large_maximal_certificate.json`, `results/large_maximal_instance.json`:
  exact maximality certificate for 10^1000 repetitions of `(3/2)`, using
  the exponent-vector interface. It has 184 auxiliaries and 212 residuals.
- `results/independent_*_check.json`: independently evaluated zero certificates.

No third-party paper PDFs, third-party repository source, or font files are
redistributed. The original sources are linked in the bibliography and
provenance file.

## Run the code

Python 3.10 or later; standard library only. From this directory:

```sh
python code/test_priority_certificates.py
python code/priority_certificates.py --export results/example_certificate.json
python code/generate_instances.py
python code/verify_export.py results/example_certificate.json results/example_instance.json
python code/verify_export.py results/large_maximal_certificate.json results/large_maximal_instance.json
```

The tests rewrite the structured report and print it. Their random seed is
20260930; elapsed time is the only intentionally machine-dependent field.
Run with ordinary Python, **not** `python -O`, because the test suite uses
assertions.

The JSON representation defines a polynomial as the sum of squares of all
listed residuals. Each residual is a sum of monomials, each represented by
an integer coefficient and a list of variable indices. Repeated indices
represent repeated factors. The free-input names and complete variable
order are explicit. A witness file supplies that complete value vector and
its claimed free-input values. The independent verifier checks both their
agreement and the exact polynomial value.

The independent verifier establishes the exported polynomial's value at the
supplied tuple, not the semantics-to-polynomial theorem. That latter claim
is proved in the article and is not machine-formalized here.

## API conventions

```python
from priority_certificates import compile_block, as_inputs, from_fractions

primes, A, B = from_fractions([(1, 72), (3, 2)])
circuit = compile_block(2, 2, [1], endpoint=True)
inputs = as_inputs(A, B, [5, 0], 2, [3, 2])
values = circuit.witness(inputs)
assert circuit.value(values) == 0
```

Place `code/` on the Python import path when using this snippet elsewhere.
Instruction indices in code are **zero-based**; the article uses one-based
indices. Program matrices and states use nonnegative integers, words must
be nonempty, and their indices must be in range.

`compile_block(..., maximal=True)` verifies exactly the largest number of
complete copies. `compile_block(..., reject=True, endpoint=False)` verifies
failure of the word, without an endpoint condition. `reduced=True` appends
constraints enforcing coordinatewise disjoint production and consumption.
A `None` capacity means arbitrary finite repetition from suitable seeds;
a `None` maximal-copy count means infinite repetition from the supplied seed.

The small trial-division helper is for examples. No efficient factorization
claim for arbitrary large raw FRACTRAN integers is made. The giant-horizon
test does not construct 2^(10^1000) or simulate 10^1000 steps.

## Build the PDF

A standard TeX Live installation with pdfLaTeX and latexmk is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The bibliography is internal. No BibTeX, shell escape, network downloads,
or nonstandard font installation is needed. The delivered PDF was compiled
and visually inspected after rendering.
