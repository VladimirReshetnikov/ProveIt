# Report 65

## Exact instruction clocks and native gap halting certificates

4 October 2026. This release combines two independently audited continuations of Report 64. Read `Report65.pdf` for the complete argument. `Report65.tex` is an editable, flattened LaTeX source; the modular authoring sources are in `manuscript/`.

The clocked compiler uses the same five live signals and restores one ordered full section after every source instruction. Each instruction lasts exactly 30D, with at most 54 binary contacts (including identity crossings), using a common sufficient set of 39 rational speeds. A particular program may use a subset of that set. First halt after k instructions is at time 30kD; optional three-crossing escape occurs afterward.

The native-gap polynomial takes three external positive integer gaps. It internally pays for powers-of-two decoding with two fully displayed 15-residual POWER modules, then enforces a finite counter trace. At a fixed horizon T its literal ledger is T(E+2)+54 positive witnesses, T(E+Z+4)+33 residual slots, and joint total degree 12. E includes split conditional edges and a virtual halt loop; Z counts zero edges. The formulas include T=0. Exact halt at T>=1 adds one residual and no witnesses. Decoding and trace projection are unique, but all nonempty full fibers are infinite. Primitive normalization, the exact gcd and minimum integer scale, and the bit-height cost are proved.

The predicate includes being encoded; it does not classify arbitrary unencoded physical halting. The horizon indexes a growing-arity family, not one fixed-arity unbounded-halting formula. There is no free exponential initialization. Five-live-signal counter computation and bouncing delay mechanisms are credited as prior work. No novelty, priority, optimality, gate-count or efficient-Pell-witness claim is made.

The earlier source packet named `bounded-horizon-diophantine65-20261004` was already part of Report 64. Its historical directory suffix is not a previous Report 65 and its trace result is not counted as a new result here.

## What is included

- `Report65.pdf`: the complete 20-page article with exact statements, all 30 POWER residuals, all trace equations, resource ledgers, a vector analytic diagram, proofs, references and future questions
- `Report65.tex`: flattened editable source matching the modular sources after the documented deterministic metadata additions
- `manuscript/`: five readable LaTeX source files
- `science/clock/`: unchanged clock continuation, original static checker text and saved evidence
- `science/native-gaps/`: unchanged native-gap continuation, original static checker text and saved evidence, plus inherited physical/trace/POWER proofs and the licensed pinned Pell source
- `audits/clock/`: the accepted independent clock audit and its independently authored checker/evidence
- `audits/native-gaps/`: the accepted independent native audit and its independently authored checker/evidence
- `audits/manuscript/`: the accepted model-performed mathematical/transcription/visual review with all20 final page renders and the superseded candidate renders
- `audits/release-tools/`: the compact accepted model-performed release-tool review and99-outcome regression evidence; raw adversarial fixtures are excluded
- `INPUT_PINS.json`: exact source origins, copy paths, byte hashes and recorded original file metadata
- `qa/`: report assembly, build, preservation and visual-review records
- `tools/build_report65.py`: fresh report-owned static LaTeX builder
- `tools/release65.py`: fresh report-owned manifest, verification and deterministic ZIP tool
- `tools/BUILD_DEPENDENCIES_LOCK.json`: exact binaries and 266 system TeX/font inputs used by the build
- `MANIFEST.json`: final release file hashes, modes and original modification times; its digest is published separately to avoid self-reference

The supplied research and audit programs are inert evidence. None is imported or run by report release tools. No physical simulator, next-collision search, saved accepting schedule, native machine interpreter, author/upstream mathematical software or Lean execution is performed. The analytic figure uses displayed formulas, not a simulation.

## Independent mathematical review

The native-gap audit accepts the displayed construction without mathematical correction. It checks the complete positive adapters against the actual pinned theorem statements, exact accounting, exponent-zero/exponent-one fixtures, trace uniqueness, T=0/exact-halt semantics, degree 12, infinite complete fibers, and primitive normalization. Its relocated replay agrees after excluding only filesystem-dependent directory sizes; raw receipts are not claimed byte-identical.

The constant-clock audit accepts the output-coordinate costs, all seven primitive words, 136 instantiated local padding rules, real +1 entry, full ordered padding guard, phase joins, exact 30D/54/39 ledgers and halt qualifications. Its portable replay evidence is byte-identical. Neither audit constitutes a new Lean build or a fresh independent formalization of the entire inherited compiler.

## Verify a received copy

Use Python 3.9 or newer. First inspect `tools/release65.py` as ordinary text. Substitute the externally supplied final manifest digest for `EXPECTED_MANIFEST_SHA256`; do not infer trust merely by hashing a manifest supplied inside an untrusted archive.

```sh
python3 -I tools/release65.py verify \
  --root /absolute/path/to/Report65 \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

This checks the exact file and directory set, regular files (rejecting symlinks and special files), bytes, hashes, modes, and inert input pins. It does not execute science files. By default modification times are not compared, because standard ZIP extraction resets them to the canonical archive timestamp. On the original release tree, `--metadata` also checks original file modification times. `--origins` additionally checks original source paths' bytes, modes, modification times and change times; it is useful only in the original workspace where those absolute paths exist.

Verify the ZIP without extracting or executing any member:

```sh
python3 -I tools/release65.py archive-check \
  --archive /absolute/path/to/Report65-source-evidence-20261004.zip \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

This rejects unexpected or duplicate members, unsafe paths, encrypted entries, nonregular members, changed byte content, changed modes, noncanonical ZIP extra fields/comments and unexpected timestamps. The manifest itself must have canonical mode 0644 in the filesystem and ZIP. Its manifest pin must be supplied externally.

## Rebuild the article in a new external directory

Inspect `tools/build_report65.py` before execution. The locked environment uses system TeX Live 2025 pdfTeX 1.40.26 and the system tools recorded in the lock. A sealed rebuild requires both the external release manifest digest and the exact dependency-lock digest below. It writes only to a newly created external output directory and refuses one already present or overlapping the release. It creates a fresh TeX format and font map in that directory, clears inherited TeX configuration through an allowlisted environment, disables shell escape, checks recorded external inputs, compiles three passes, and verifies source files and directory metadata did not change. It checks the exact sealed directory set, verifies the flattened source against the sealed artifact before compiling, and requires the rebuilt PDF to equal the sealed PDF hash.

```sh
python3 -I tools/build_report65.py \
  --root /absolute/path/to/Report65 \
  --output /absolute/path/to/new-report65-build \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256 \
  --dependency-lock /absolute/path/to/Report65/tools/BUILD_DEPENDENCIES_LOCK.json \
  --dependency-lock-sha256 655822c2dee2f0f4d1a0a8d00208579e4a53d558ce8ca385557e1d88c5e614e2
```

The output includes the rebuilt PDF, flattened TeX, extracted layout text, TeX log, recorder files, a build receipt and the observed dependency lock. The PDF omits variable dates and trailer IDs; fixed SOURCE_DATE_EPOCH is used. A different TeX distribution is expected to fail the dependency preflight rather than being described as an identical rebuild. A draft authoring mode exists only for an unsealed tree and must be selected explicitly with `--draft`; it refuses a tree with a final manifest.

The all-exponent POWER equivalence still depends on the named constructive mathlib theorem pair. Building the article does not formally verify its mathematics. Likewise finite exact arithmetic receipts are supporting evidence, not exhaustive proofs over all programs, horizons or native inputs.

## Deterministic archive creation

After successful verification, a new ZIP can be created in a fresh external path:

```sh
python3 -I tools/release65.py archive \
  --root /absolute/path/to/Report65 \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256 \
  --output /absolute/path/to/new-report65.zip
```

Entries are sorted under the fixed `Report65/` prefix, use one fixed timestamp, retain manifest modes and use deterministic deflate settings. The tool checks the completed ZIP against the manifest and verifies the source did not change. Repeated creation in the same Python/zlib environment is expected to be byte-identical. Extracted copies preserve content and modes, while ordinary extraction may not preserve nanosecond timestamps; default verification intentionally handles that distinction.

`seal` is an authoring command, not a recovery or trust-establishing command. It refuses to replace an existing manifest. Never reseal a changed release to make a failed verification disappear.

## Attribution

The retained `pell-source.lean` is from mathlib4 commit `ac77769fabe23cb237559e7f56578dbead91499f`, authored by Mario Carneiro and contributors and distributed under Apache License 2.0. Its unchanged license, notice and source header are included in `science/native-gaps/dependencies/`. The report cites the exact source location and the two theorem names. Prior research source copies are preserved as provenance, not represented as newly authored code.
