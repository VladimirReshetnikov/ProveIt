# Transfer-pop with zero-valued spare blocks

The fresh complete primitive runtime census passes all 6,209 guarded cases. No 214-state claim.

## Literal table and startup

Start with public transfer215.native.tm (SHA256 1f8194fa49a638857ecf5b4f69b1ae92cb47d11d1a74e952bbb91049c893a836), change only native 198/read 0 from 1L40 to 0L40, and change designated initial state from 0 to 74. There remain 215 working states and 430 rows, halt 254. Source transfer201.sites.json is unchanged: 201 DAG nodes, 4,775 primitive occurrences, and 6,209 guarded cases.

Independent native/dense lockstep blank execution reaches dispatcher 84 after 73,172 transitions at head -2. Its full tape equals the canonical source frame for ordinal 119 (PC 11010011000110110110), logical registers(N,T,W,A,D,H,X,Y,L)=(0,6,0,0,1,1,10,1,0) , gap 0, and 65 spare blocks. Exact sparse tape and every transition are recorded. There is no externally supplied tape.

A separate exact source CFG simulation starts at AX entry ordinal 25 with registers (0,0,0,0,1,1,0,0,0) and reaches this exact ordinal 119/register tuple after 177 primitive transitions. Thus startup is inside a genuine AX, not a fabricated zero-PC root. The symbolic source/runtime simulation transports its remaining suffix.

## Why the dirty cache is safe

The virtual AX entry has next enumerator cutoff N=0, proof pointer L=0, old top T=0, stack W=0, selector A=0, additive counter D=1 and cached value H=1. The three remaining AX fields are all zero. Hence the completed AX has U=A=B=1,C=0. It returns the accepted full enabled bundle as top, clears counter/cache, and pushes

[r1,...,r7,L(1,1,0,1),Q_1(1),0;0].

The first eight heads are numerical-calculus theorems: the seven unchanged logical rows and the dominated rho8 instance with U=A=1. The bundle is a theorem, and the reset cache 0 is truth. It would be WRONG to assert that Q_1(1) is a theorem. Instead regard the tail beginning at that ninth head as an arbitrary protected tail.

The inherited all-natural transfer credit theorem applies to any fixed arbitrary tail below sufficiently many theorem heads. At cutoff N=0 and empty proof pointer, the exceptional candidates are W(0)=S, W(1)=MP, W(2)=SS. Their cumulative conservative minimum is -3. Every subsequent Cantor diagonal, starting with diagonal 2, has nonnegative relative prefix balance by the existing unbounded diagonal-induction theorem. Therefore debt 3 is sufficient for every later command prefix. Eight theorem heads are available, so at least five remain above the arbitrary tail forever. The unsafe Q_1(1) is never popped into the active top/cache.

Actual S is composite old DROP; old NIP; old NIP and tests both incoming top and cache for 1. The protected_credit theorem explicitly covers this composite's internal pops. Its extra temporary push does not expose a deeper old head than its net one-head pop. Therefore every possible halt certifies a genuine theorem 1; no theoremhood is assumed of the buried tail.

## Completeness

The existing transfer strong compiler works over arbitrary retained tails and constructs cofinally many successful candidate encodings past any finite cutoff. Starting at N=0 does not lose any candidate. The prefix credit invariant supplies actual-run soundness; the strong compiler supplies refutation-search completeness. In conjunction with the inherited numerical-calculus calibration, ordinary mathematics formalizable in ZFC gives blank nonhalting iff Con(ZFC).

## Physical semantics and novelty

The changed 198/0 row appends B(0)=01 rather than B(1)=011 on every source increment. The full primitive proof uses append=0 and covers all 6,209 guards, arbitrary natural primary registers, arbitrary natural gap, arbitrary nonempty finite natural spare list, and complete zero exterior. The source simulation composes because both appended lists remain nonempty wellformed natural lists. The source and credit proofs do not depend on spare values.

This composition combines the changed three-command language of transfer-pop with zero-spare allocation and a new dirty-cache bootstrap proof. It is not merely a new state numbering or an initial-state change of the old unit-spare construction. Relative to unit-spare transfer, one fewer one-writing row is a state-renaming invariant. Relative to public zero-spare Z215, source command language and corresponding physical dispatch graph differ. The supplied graph audit rules out rooted state-renaming and global tape-reflection equivalence against 45 distinct public 215-state tables in the inspected archives. This is a precisely bounded comparison, not a global novelty claim.

No new Lean/Rocq endpoint, unconditional nonhalting theorem, or 214-state result is asserted.
