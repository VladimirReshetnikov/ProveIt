# Zero-spare transfer-pop: a new 215-state composition

This candidate composes the public three-command transfer-pop source with zero-valued spare allocation and a newly checked dirty-cache blank bootstrap. It has 215 working states, 430 binary rows, a separate halt, and an initially blank two-way infinite tape. No 214-state result is claimed.

The exact change to the included public transfer machine is native 198/read 0: 1L40 becomes 0L40, with initial state 74 instead 0. Each source increment now appends 01 rather than 011. The unchanged source has 201 DAG nodes, 4,775 primitive occurrences, and 6,209 guarded cases. This is not a new numerical calculus or new command language; both components are attributed to their public predecessors.

## New startup and proof

Blank execution reaches a complete source frame after 73,172 steps, at source ordinal 119, inside AX. Its registers are (0,6,0,0,1,1,10,1,0), head −2, gap 0, and 65 spares. A separate 177-step exact source trace matches AX entry 25 with seed (0,0,0,0,1,1,0,0,0).

The incoming cached 1 is not assumed to be a theorem. AX returns eight genuine theorem heads above an arbitrary tail containing Q_1(1). The existing all-natural transfer credit theorem gives debt 3 for cutoff N=0, so at least five theorem heads always protect that unsafe tail. The composite S command's top-and-cache halt tests and internal temporary pop are covered. See PROOF.md and independent_review/REVIEW.md.

Combined with the explicitly inherited numerical-calculus calibration and strong proof compiler, the ordinary mathematical argument establishes, formalizably in ZFC, blank nonhalting iff Con(ZFC). It is not an unconditional nonhalting theorem or a new exact-byte Lean/Rocq endpoint.

## Reproduction

Python 3.10 or later, standard library only, with assertions enabled:

    python3 verify.py

Fast verification reconstructs the table from the exact included public parent, checks the dense bijection, replays all 73,172 blank transitions in two labelings, reconstructs the entire terminal frame, replays all 177 source transitions, checks the exact 6,209 guarded-case census and positive symbolic durations, and independently rejects rooted state-renaming and tape-reflection equivalence against 45 different 215-state comparison tables. It audits saved quantified proof certificates but does not rederive every symbolic primitive proof.

For a complete fresh arbitrary-natural runtime derivation:

    python3 verify.py --runtime --work /tmp/new-transfer-zero-check

Choose a nonexistent output directory. The full replay must match every saved case and all fresh block certificates. It can take several minutes. Generated receipts go only to the fresh directory, never into this packet. The mathematical credit/compiler arguments are written proofs, not proof-assistant programs invoked by these commands.

The original parent subpacket is preserved under parent/, including its licenses, provenance, source, runtime verifier, complete original proof and exact counterexamples. Its original files are not rewritten. Its statements about its old unit-spare table do not describe this new table. New source files and wrappers here are attributed as the present composition and audit, not as the source of inherited machinery.
