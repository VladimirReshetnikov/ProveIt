from pathlib import Path
import json,hashlib,math
W=Path(__file__).resolve().parent
D=W.parent/'transfer_zero'
R=next((W.parent/'intake').glob('**/Transfer_Pop*/original_report'))
def read(p):
 t={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));assert (q,b)not in t and b in (0,1)and w in(0,1)and d in('L','R');t[q,b]=(w,1 if d=='R'else-1,z)
 assert all((q,b)in t for q,_ in t for b in (0,1))
 return t
nt=read(D/'candidate.native.tm');ct=read(D/'candidate.tm');ot=read(R/'machine/transfer215.native.tm')
assert len(nt)==len(ct)==430
assert set(q for q,b in ct)==set(range(215))
assert set(z for w,d,z in ct.values())-set(range(215))=={215}
assert [(k,ot[k],nt[k])for k in nt if nt[k]!=ot[k]]==[((198,0),(1,-1,40),(0,-1,40))]
def run(t,q):
 h=0;ones=set()
 for i in range(73172):
  w,d,q=t[q,int(h in ones)]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 return q,h,ones
q,h,ones=run(nt,74);cq,ch,cones=run(ct,0)
assert (q,h)==(84,-2) and h==ch and ones==cones
sites=json.loads((R/'source/transfer201.sites.json').read_text())
phy=[6,2,0,4,3,7,8,5,1]
# Decode unary register delimiters directly from exact resulting tape.
header=min(x for x in ones if x>=h+52);p=header+1;values=[]
while p<=max(ones):
 assert p not in ones and p+1 in ones;p+=1;n=0
 while p in ones:n+=1;p+=1
 values.append(n-1)
regs=[values[i]for i in phy];spares=values[9:]
assert regs==[0,6,0,0,1,1,10,1,0]and len(spares)==65
# Build full expected frame independently, including absence of stray tape ones.
frame={h-1,header};frame|={h+i for i,b in enumerate(sites[119][0])if b=='1'}
p=header+1
for v in values:
 p+=1;frame.update(range(p,p+v+1));p+=v+1
assert frame==ones and header-h==64
# Derive structured branch targets by path subtree extents.
paths=[s[0]for s in sites]
def interval(prefix):
 ix=[j for j,p in enumerate(paths)if p.startswith(prefix)];return min(ix),(max(ix)+1)%len(sites)
def step(pc,r):
 path,op,arg=sites[pc]
 if op=='CI':r[arg]+=1;return (pc+1)%len(sites)
 if op=='CD'and r[arg]:r[arg]-=1;return (pc+1)%len(sites)
 if op=='CH':raise AssertionError('halt')
 choices=[path[:j]for j,b in enumerate(path)if b==('1'if op=='CC'else'0')]
 depth=1 if op=='CD'else arg
 if len(choices)<depth:return 0
 return interval(choices[-depth])[0 if op=='CC'else 1]
pc=25;r=[0,0,0,0,1,1,0,0,0];trace=[]
for i in range(177):trace.append([pc,r.copy()]);pc=step(pc,r)
assert pc==119 and r==regs
# AX source identity, ignoring relocated path prefix.
b=json.loads((R/'inputs/baseline215.sites.json').read_text());needle=[x[1:]for x in sites[25:4590]]
hits=[i for i in range(len(b)-len(needle)+1)if [x[1:]for x in b[i:i+len(needle)]]==needle]
assert len(hits)==1
j=hits[0];ap='1101001';bp=b[j][0][:-6]
assert [x[0][len(ap):]for x in sites[25:4590]]==[x[0][len(bp):]for x in b[j:j+4565]]
# Independent finite scheduler check; each balance includes every command prefix.
def right(n):
 s=(math.isqrt(8*n+1)-1)//2;return n-s*(s+1)//2
B=[];M=[];cumulative=0;minimum=0
for n in range(200000):
 y=right(n);s=(math.isqrt(8*n+1)-1)//2;a=s-y
 cost=-1 if a==0 else 0 if a==1 else 10
 rest=y if a==0 else right(y)if a==1 else right(right(y))
 bb=cost+(B[rest-1]if rest else 0);mm=min(0,cost+(M[rest-1]if rest else 0))
 B.append(bb);M.append(mm);minimum=min(minimum,cumulative+mm);cumulative+=bb
assert minimum==-3
out={'status':'PASS','working_states':215,'transition_rows':430,'native_change':[[198,0,1,0,'L',40]],'blank_steps':73172,'native_state':q,'canonical_state':cq,'head':h,'ones':sorted(ones),'registers':regs,'spares':spares,'source_prefix_steps':177,'source_exit':pc,'ax_identical_baseline_start':j,'ax_length':4565,'finite_credit_candidates':200000,'finite_global_minimum':minimum,'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in[D/'candidate.tm',D/'candidate.native.tm',R/'source/transfer201.sites.json']}}
(W/'receipt.json').write_text(json.dumps(out,indent=2)+'\n');(W/'source_trace.json').write_text(json.dumps(trace)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in('ones','spares','hashes')},indent=2))
