# Independent review: zero-spare transfer-pop seed

## Verdict and scope

PASS for the literal 215-state count, blank replay, exact partial-source bridge, AX-source identity, and the mathematical dirty-tail soundness/completeness bridge. This review independently reads the transition tables and source sites as inert data; its own `audit.py` imports only the standard library. It does not invoke the candidate worker's replay/checker.

The fresh quantified binary runtime proof for append=0 is a separate obligation. This review does not certify that obligation merely from finite replay. Its receipt was still running when this report was written. Numerical-calculus calibration and the established unchanged AX arithmetic contract remain inherited premises, not newly reconstructed foundations.

## Literal replay and count

`audit.py` verifies 430 distinct rows, both symbols present at each of exactly 215 working states. Canonical state labels are exactly 0 through 214, with only target 215 outside that set. Against the prior native transfer215, the sole changed transition is (198,0): (1,L,40) becomes (0,L,40). The native designated start is 74 rather than 0.

Separate native and canonical blank simulations each execute exactly 73,172 transitions from an empty set of nonzero tape cells. Both yield the same head and complete tape; native state is 84, canonical state is 81, and head is -2. The complete tape, not merely selected register cells, is checked against the frame at source ordinal119 with PC11010011000110110110, gap0, logical store

(N,T,W,A,D,H,X,Y,L)=(0,6,0,0,1,1,10,1,0).

There are 65 spare blocks; their complete values and all nonzero tape cells are recorded in `receipt.json`. In particular the spare list is not claimed to consist entirely of zeros: the third spare has value1. Zero-spare describes the revised appended block, not every bootstrap spare.

The source control-flow replay independently derives branch/continue targets from structured path extents. Beginning at ordinal25 with store (0,0,0,0,1,1,0,0,0), exactly177 primitive transitions reach ordinal119 and the same complete logical store. This is an exact finite computational certificate. It is not a literal run to the final command boundary, whose huge arithmetic is justified by the unchanged terminating AX contract.

## Exact AX reuse, restoration, and gate

The 4,565 AX leaves at new source ordinals25 through4589 agree, operation by operation, with baseline ordinals26 through4590. Their relative subtree paths also agree. Thus reuse is not merely a match of macro names: both literal operations and internal structured control flow are unchanged.

At virtual AX entry, T=W=A=X=Y=L=N=0, D=H=1. A is the selector residue/private label, not the final AX parameter A used in its mathematical interface. The empty pointer L=0 supplies zero payload fields. The inherited AX interface therefore has old top t=0, stack w=0, U=d=1, parameter A=d+0=1, parameter B=h+0=1, and label C=0.

At normal completion it restores scratch registers, leaves N=0 and L=0, clears D=H=0, and yields

 top = K(1,1,0),
 stack = [rho1(1,1,0), ..., rho7(1,1,0), rho8(1,1,0,1), Q_1(1), 0; 0].

The gate is ENABLED: C=0 differs from A=B=1. It must not be described as top0. K is precisely the retained full gated bundle, not a weakened replacement. Its theoremhood is available from the inherited axiom interface at this enabled instance.

The first seven heads are retained native logical axiom instances. The eighth is a permitted dominated-rho8 instance because U=A=1. None requires the incoming cache1 to be a theorem. Hence all eight are theorems. The ninth head Q_1(1)=18 is not justified by GEN because its premise is the incoming falsity code1. Treat that head and everything below it as a completely arbitrary fixed tail J. Numerically J=P(18,P(0,0))=171. No soundness claim is made about any decoded head of J.

AX has no intermediate falsity halt; its primitive arithmetic terminates by its established contract. Therefore the dirty pre-AX cache does not itself trigger a halt before the protected completed boundary is reached.

## All-natural scheduler bound, independently checked

Write f(n) for Cantor right projection, R(0)=empty, and R(r)=W(r-1) for r>0. At freshly fetched candidate n with unpair(n)=(a,y), the actual 1/2/3-field scheduler gives

 W(n)=S;R(y) if a=0,
 W(n)=MP;R(f(y)) if a=1,
 W(n)=AX;R(f(f(y))) if a>=2.

Assign conservative balances -1,0,+10. Subsequent safe AX commands supply ten theorem heads, not merely eight: unlike the exceptional bootstrap, their incoming top/cache are theorems. Successful MP's extra truth head can be ignored.

Every continuation R(r) has at most r commands, since each positive residual descends to a candidate index at most r-1. Thus its balance at every prefix is at least -r. Let b(n) be total balance, B(k)=sum(n<k)b(n), g(0)=0, and g(r)=b(r-1) for r>0. For q(r)=g(r)+1, its first k terms sum to 1+B(k-1)+(k-1). Whenever earlier B(j)+j>=0, these sums are nonnegative.

Cantor right projections enumerate [0],[0,1],[0,1,2],... . A sequence with nonnegative prefix sums retains that property when indexed by f, and again by f composed with f. On diagonal s>=2, the first s-1 candidates begin with AX. The first k complete such candidates have total at least9k. Inside its y-th AX candidate the bound is9y+10-y>=0. After all AX candidates the balance is at least9(s-1); throughout the MP candidate it remains at least8(s-1); throughout the final S candidate it remains at least8(s-1)-1-s=7s-9>=0. All suffix indices used here are from earlier diagonals, so this is not circular.

The exceptional candidates are W(0)=S, W(1)=MP, W(2)=SS. Their minimum balance is -3, and B(k)+k>=0 through k=3. The diagonal argument inductively extends this inequality, and every later diagonal is prefix-nonnegative. Therefore the entire infinite schedule from N=0 has conservative debt exactly3. Independent finite corroboration through200,000 candidates also gives minimum -3, but the induction, not the finite bound, is the proof.

Starting with eight safe explicit heads, every command boundary retains at least8-3=5 safe heads above J. This is a wrapper-list invariant, not an assertion that Cantor numeric code uniquely determines list length. It remains valid when P(0,0)=0.

## Actual composite guard and internal pops

The real S is oldDROP;oldNIP;oldNIP. For unpair(w)=(x,v), its nonhalting effect is

 (t,w,d,h) -> (h,v,d,x).

It halts if incoming h=1 OR incoming t=1. To see the internal safety explicitly: DROP pushes t and sets top=h; first NIP checks h then pops that newly pushed theorem t into cache; second NIP checks t then pops exactly one old explicit head x. The temporary push/pop does not reach deeper into the original stack. Both possible guards test theorem-valued formulas in the invariant, so either halt witnesses a native refutation.

MP preserves theoremhood by its equality test and its failure/reset behavior. Safe AX has theorem-valued top/cache and produces ten safe heads. S pops only a safe explicit head by the credit bound. Hence J is never loaded into cache or top, either at boundaries or during the composite's internal operations. In particular Q_1(1) cannot invalidate soundness later.

## Completeness

The inherited strong compiler constructs, for each theorem X, a finite block that from arbitrary top/stack and reset counter/cache either halts or returns (X, original stack,0,0). This stronger arbitrary-stack premise is exactly what the protected-tail application needs. The composite S has the same nonhalting map as the cache-only S, with an additional possible early halt; thus all such halt-or-return contracts survive unchanged.

The cofinal padding candidates begin with AX to reset counter/cache and then run the refutation block and its halting suffix. If a native refutation exists, some such candidate lies beyond any current cutoff. Strict residual descent and monotone candidate enumeration reach it unless a halt occurs earlier. Starting with N=0 does not remove any candidate.

Consequently, conditional on the newly checked complete append=0 primitive runtime and the inherited calculus calibration, this blank machine halts exactly when the native calculus has a refutation, hence exactly when ZFC has a finite refutation. No unconditional nonhalting, new foundational formalization, or 214-state result is asserted.
