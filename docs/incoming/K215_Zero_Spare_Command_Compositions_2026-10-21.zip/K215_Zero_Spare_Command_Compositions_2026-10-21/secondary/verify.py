#!/usr/bin/env python3
"""Portable zero-spare transfer verification; optional complete symbolic proof."""
from pathlib import Path
import argparse,collections,gzip,hashlib,json,sys,tempfile
if not __debug__ or sys.flags.optimize:
 raise RuntimeError('Verification requires assertions; do not use -O or PYTHONOPTIMIZE')
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'parent/checks'))
import independent_runtime as I,source_utils as B
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def graph_compare(sa,A,sb,B,reflect=False):
 mp={sa:sb};inv={sb:sa};todo=collections.deque([(sa,sb,'')])
 while todo:
  x,y,path=todo.popleft()
  for r in(0,1):
   aa=A.get((x,r));bb=B.get((y,r))
   if aa is None or bb is None:
    if aa!=bb:return True
    continue
   wa,da,za=aa;wb,db,zb=bb
   if reflect:db=-db
   if(wa,da)!=(wb,db):return True
   if za in mp and mp[za]!=zb:return True
   if zb in inv and inv[zb]!=za:return True
   if za not in mp:mp[za]=zb;inv[zb]=za;todo.append((za,zb,path+str(r)))
 return False
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--runtime',action='store_true');ap.add_argument('--work',type=Path);a=ap.parse_args()
 if a.work:a.work.mkdir(parents=True,exist_ok=False)
 W=a.work or Path(tempfile.mkdtemp(prefix='transfer-zero-'))
 inventory=read(R/'manifest.json')['files']
 assert {x['path']for x in inventory}=={str(p.relative_to(R))for p in R.rglob('*')if p.is_file()and p.name!='manifest.json'},'Unexpected or missing packet files'
 for x in inventory:assert H(R/x['path'])==x['sha256'],x['path']
 original=I.table(R/'parent/machine/transfer215.native.tm');assert H(R/'parent/machine/transfer215.native.tm')=='1f8194fa49a638857ecf5b4f69b1ae92cb47d11d1a74e952bbb91049c893a836'
 assert original[198,0]==(1,-1,40);T=original.copy();T[198,0]=(0,-1,40)
 raw='#! start 74\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))
 assert raw==(R/'candidate.native.tm').read_text()
 qs=sorted({q for q,b in T});assert len(qs)==215 and len(T)==430 and 254 not in qs
 reach={74};todo=[74]
 for q in todo:
  for b in(0,1):
   z=T[q,b][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 assert reach==set(qs)
 m={int(k):v for k,v in read(R/'canonicalization.json').items()};assert m[74]==0 and m[254]==215 and set(m.values())==set(range(216));inv={v:k for k,v in m.items()}
 K=I.table(R/'candidate.tm');assert K=={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}
 ss=read(R/'sites.json');assert (R/'sites.json').read_bytes()==(R/'parent/source/transfer201.sites.json').read_bytes();assert len(ss)==4775
 # Two differently labelled interpreters replay every stored transition.
 st=json.loads(gzip.decompress((R/'startup.json.gz').read_bytes()));assert st['start']==74 and st['steps']==73172 and len(st['trace'])==73172
 q=74;h=0;cq=ch=0;one=set();con=set()
 for event in st['trace']:
  b=int(h in one);w,d,z=T[q,b];assert event==[q,h,b,w,d,z]
  one.add(h)if w else one.discard(h);q=z;h+=d
  cb=int(ch in con);cw,cd,cz=K[cq,cb];con.add(ch)if cw else con.discard(ch);cq=cz;ch+=cd
  assert(q,h,one)==(inv[cq],ch,con)
 assert(q,h)==(84,-2) and sorted(one)==st['one_cells']
 assert st['ordinal']==119 and st['pc']==ss[119][0] and st['registers']==[0,6,0,0,1,1,10,1,0] and st['gap']==0 and len(st['spares'])==65
 assert one=={x+h for x in I.frame(st['pc'],st['registers'],st['spares'],st['gap'])}
 # Source prefix: no inference from numerical credit checks.
 src=read(R/'source_prefix.json');g=B.cfg(ss);pc=25;reg=[0,0,0,0,1,1,0,0,0];assert src['seed']==reg and src['steps']==177
 trace=[]
 for tick in range(177):
  trace.append([pc,reg.copy()]);op,k,e=g[pc]
  if op=='CI':reg[k]+=1;pc=e[0]
  elif op=='CD':
   if reg[k]:reg[k]-=1;pc=e[1]
   else:pc=e[0]
  else:assert op in('CB','CC');pc=e[0]
 assert(pc,reg)==(119,st['registers']) and trace==src['trace']
 # Exact credit prefix; the unbounded extension is the cited diagonal theorem.
 def unpair(n):
  from math import isqrt
  s=(isqrt(8*n+1)-1)//2;y=n-s*(s+1)//2;return s-y,y
 def word(n):
  a,y=unpair(n)
  if a==0:k='S';r=y
  elif a==1:k='MP';r=unpair(y)[1]
  else:k='AX';r=unpair(unpair(y)[1])[1]
  return[k]+(word(r-1)if r else[])
 assert[word(n)for n in range(3)]==[['S'],['MP'],['S','S']]
 # Saved universal certificates are audited, not freshly rederived here.
 cases=json.loads(gzip.decompress((R/'runtime_cases.json.gz').read_bytes()));expect=[(i,pos)for i,s in enumerate(ss)for pos in((False,True)if s[1]=='CD'else(False,))]
 assert[(c['index'],c['positive'])for c in cases]==expect and len(cases)==6209
 rr=read(R/'runtime.json');assert rr['status']=='ALL_NATURAL_RUNTIME_PASS'and rr['cases']==6209 and rr['row_coverage']==430
 assert sum(c['symbolic_steps']for c in cases)==rr['symbolic_rules']
 assert min(c['duration'][0]for c in cases)==rr['minimum_duration']>0
 assert all(all(v>=0 for v in c['duration'])for c in cases)
 novelty=read(R/'novelty.json');assert novelty['candidate_sha256']==H(R/'candidate.native.tm')
 for row in novelty['results']:
  p=R/row['path'];assert H(p)==row['sha256'];start=0
  for line in p.read_text().splitlines():
   if line.startswith('#! start'):start=int(line.split()[-1])
  U=I.table(p);assert len(U)==430
  assert graph_compare(74,T,start,U)and graph_compare(74,T,start,U,True)
 out=dict(status='FAST_AUDIT_PASS',states=215,rows=430,startup_steps=73172,source_prefix_steps=177,cases=6209,comparison_tables=len(novelty['results']),new_proof_assistant_endpoint=False)
 print(json.dumps(out),flush=True)
 if a.runtime:
  import symbolic_runtime as S
  lm={int(k):int(v)for k,v in read(R/'parent/inputs/NATIVE_TO_LEGACY.json').items()}
  for q in sorted(set(qs)|{254}):
   if q not in lm:lm[q]=max(lm.values())+1
  U={(lm[q],b):(w,d,lm[z])for(q,b),(w,d,z)in T.items()};lemmas,blocks=S.prove_blocks(U);fresh=[];rows=set()
  for i,site in enumerate(ss):
   for pos in((False,True)if site[1]=='CD'else(False,)):
    c=S.case(U,lemmas,site,pos,append=0);rows.update(c.pop('rows'));c.pop('trace');fresh.append(dict(index=i,positive=pos,**c))
   if i%500==0:print('Fresh cases',len(fresh),flush=True)
  assert json.loads(json.dumps(fresh))==cases and len(rows)==430 and json.loads(json.dumps(blocks))==rr['blocks']
  (W/'runtime_cases.json.gz').write_bytes(gzip.compress(json.dumps(fresh).encode(),mtime=0));out['status']='FULL_RUNTIME_PASS'
 (W/'verification.json').write_text(json.dumps(out,indent=2));print('Receipts:',W)
if __name__=='__main__':main()
