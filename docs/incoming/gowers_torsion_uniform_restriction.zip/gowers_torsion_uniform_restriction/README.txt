POLYNOMIAL RESTRICTION ON EVERY CYCLIC GROUP
A torsion-sensitive refinement of Gowers's Lemma 9.3
and an optimal exponent for positive Fourier filtering

Prepared for the ProveIt project, 7 October 2026.

MAIN RESULTS

1. For B in Z/NZ, every N, and a map phi from B to any abelian group,
   suppose G_16(B,phi) >= alpha*|B|^15 and
   |B| >= (4/(alpha*eta))^54, with 0 < alpha,eta <= 1.
   There is B' subset B with at least a 1-eta respected proportion and
   T_16(B') >= (alpha*eta/4)^54*|B|^15.
   All counts are ordered and include repetitions.

2. A general finite-abelian-domain expectation theorem controls small
   torsion and repeated entries. Its nonprincipal error is
   tau_G(2D)*(R_m^k-P^k)*|B|^(m-2), and its collision error is
   binom(m,2)*R_2^k*|B|^(m-2).

3. In the normalized nonnegative Fourier-filter class, for fixed
   discrepancy order a >= 2, the optimal principal retention exponent is
   m*log(m)/(2*log(a)) + O_a(m*log(log(m))). The proof includes a lower
   bound over every finite degree and an explicit attaining family.
   Independent heterogeneous layers obey the same barrier.

The article gives complete proofs, ten further research questions, a
comparison with previous project contributions, and precise interfaces
with the existing Lean statements. Its numerical exponent is a local
all-modulus improvement to Gowers's printed/formal bound 2^19, not a claim
to improve the already stronger prime-field exponents in sources 04/17.
No global Szemeredi bound, global priority claim, or Lean certification of
the new results is asserted.

CONTENTS

gowers_torsion_uniform_restriction.tex   Complete article source
gowers_torsion_uniform_restriction.pdf   Compiled article
SOURCE_AUDIT.txt                        Source scope and contribution audit
Makefile                               Build and verification targets
code/verify_constants.py               Exact integer certificates for 54
code/verify_expectations.py            Exact small-group survival checks
code/explore_kernels.py                Numerical search and figure generator
data/exact_constants.json              Exact certificate output
data/expectation_checks.json           Small-group audit output
data/cosine_exploration.csv            All 1,524 numerical candidates
data/cosine_best_sampled.csv           Best within the tested degree ranges
data/cosine_m16_profile.csv            Sixteen-variable degree profile
data/exploration_metadata.json         Scope of the numerical search
data/source_provenance.json            Pinned repository and primary sources
figures/kernel_exponents.pdf           Vector figure used by the article
figures/kernel_exponents.png           Convenient raster preview
MANIFEST.sha256                        Checksums of the package files

BUILD

From this directory:

  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    gowers_torsion_uniform_restriction.tex

Alternatively use "make pdf". A standard TeX Live installation with the
packages named in the preamble is sufficient. The supplied figure PDF is
already included, so compilation does not require Python or Matplotlib.
The bibliography is embedded; no external .bib file is needed.

EXACT VERIFICATION

  python3 code/verify_constants.py
  python3 code/verify_expectations.py

Alternatively use "make check". Both scripts require only the Python
standard library and write deterministic JSON summaries to data/.
Use ordinary Python execution without -O, so assertions remain enabled.

The first script checks five integer inequalities and the final symbolic
constant comparisons. The article proves the parameter inequalities for
every allowed alpha and eta, rather than inferring them from samples.

The second script checks 1,512 small-group cases and 6,048 main inequality
assertions with fractions.Fraction arithmetic. It also includes explicit
repeated-point regressions. These finite checks supplement, rather than
replace, the general written proof.

NUMERICAL EXPLORATION

  python3 code/explore_kernels.py --no-figure

This uses the standard library. To also regenerate the figure:

  python3 code/explore_kernels.py

Plotting requires Matplotlib and NumPy. The finite search covers
m = 4,8,16,32,64,128,256 and every integer degree 1 <= q <= 3m.
It is not a certificate of the best filter or the globally best degree.
The exact exponent-54 theorem does not rely on floating-point search.

INTEGRATION

The source comparison is pinned to VladimirReshetnikov/ProveIt commit
5d4718772d1a7dd4c48e1f49c8f92390c73b7ff1.

Intended thematic destination:
Combinatorics/Ramsey/Research/GowersSzemeredi/

The report can be integrated as an independent contribution or into the
existing local-quantitative-refinements collection. Preserve source 04's
powered-cosine and weighted-Fourier credits, source 17's prime-field
restriction and signed objective, source 40's principal torsion spectra,
and the Gowers/Shkredov ancestry. See SOURCE_AUDIT.txt for exact scope.

No remote repository was changed. The article maps the new statements to
additiveTupleCount, phiAdditiveTupleCount, and GammaHomOfOrder, but the
package includes no placeholder Lean proofs.

PROVENANCE AND REVIEW STATUS

Prepared with OpenAI ChatGPT, including independent parallel mathematical
reviews and exact computational checks. No human authorship is assigned
by this package. The work has not been externally peer reviewed or
formalized in Lean. The article distinguishes established predecessor
ingredients, the results proved here, and questions still open.

The PDF was compiled with resolved references and visually inspected.
Regenerated PDF metadata may differ even when its mathematical content
is identical. MANIFEST.sha256 describes the delivered version; rebuilding
files naturally requires refreshing those checksums if exact byte-level
comparisons are wanted.
