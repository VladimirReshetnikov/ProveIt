LEXICOGRAPHIC ORDERS OF SURREAL WELL-ORDERS
Residual spectra, decorated completions, and model invariants
Research manuscript prepared for Vladimir Reshetnikov
3 October 2026

CONTENTS
  surreal_lexicographic_orders_continuation.pdf  Complete article
  surreal_lexicographic_orders_continuation.tex  Standalone LaTeX source
  build.sh                                     PDF build script
  check_restrictions.py                         Finite verification program
  restriction_checks.json                      Recorded verification results
  source_status.txt                            Sources, assumptions, proof status
  README.txt                                   This file

BUILD
Run:
  sh build.sh

The script uses latexmk when available, otherwise three pdflatex passes.
A reasonably complete TeX Live or MiKTeX installation is required. The
source uses standard packages, has its bibliography built in, and requires
no downloaded images, external data, BibTeX, or shell escape.

FINITE CHECK
Run:
  python3 check_restrictions.py

This uses only the Python standard library. It checks the exact
restriction-monotonicity classification for every subset of each carrier
with zero through seven labels, considering every adjacent pair in its
lexicographic permutation order. The recorded run checks 695,228 adjacent
comparisons, all agreeing with the theorem. It is finite evidence, not a
verification of the transfinite results.

READING GUIDE
The opening sections distinguish the interpretations of the question and
state the necessary baseline results. The fixed-type section proves the
weighted residual spectrum and identifies the remaining coding problem.
The middle sections treat restriction maps, bounded completions, global
residual fibers, and automorphisms. The model section classifies countable
realizations and their common first-order theory. The closing sections
provide a size-sensitive formalization plan, further research questions,
and a result-by-result assumptions and verification ledger.

PROOF STATUS
This is an AI-assisted research manuscript with conventional mathematical
proofs and independent checks during preparation. It is not a refereed
publication or a machine-checked proof certificate. Repository results,
earlier project manuscripts, new arguments in this continuation, and
remaining questions are explicitly distinguished. No claim of historical
priority is made. No new Lean theorem was compiled.
