# One Shared Fallback

**Conservative Reaction Computation, Unique Quartic Certificates, and a
Canonical Fuel Form of the Finite-Fold Problem**

Research article and executable companion, 30 September 2026.
Prepared for the ProveIt research program with ChatGPT.

## Start here

Read `article.pdf` for the full statements, proofs, source provenance, and
research agenda. `article.tex` is the complete, self-contained LaTeX source;
its bibliography is inline, so BibTeX is not required.

The package constructs an exact compiler from deterministic register machines
to abstract priority reaction networks. All reactions in the closed version
are two-to-two and molecule-conserving. Exactly one rule has low priority:

    A + Z -> B + Z

The compiled universal instance has 61 species and 62 reactions. The least
initial storage reserve is exactly the maximum increase in total source
register population during the halting computation.

The compiler also generates quadratic residual equations whose sum of squares
is a quartic polynomial, with a unique natural-number witness for each valid
bounded deterministic trace. A two-trace construction certifies the least
reserve at any fixed resource cutoff.

The article proves that a **fixed, global finite-fold polynomial** for the
least-reserve relation of this one network would imply finite-fold
representations for every computably enumerable set, and conversely.
There is an analogous single-fold equivalence. The article also gives a
priority-erasure obstruction and a Pareto-resource extension.

## Essential semantic and assurance distinctions

* A fixed closed finite-reservoir instance is finite-state and decidable.
  Universality of the 61-species system is existential in the initial reserve.
  The related 60-species open-reservoir variant is conventionally
  Turing-complete but is not conservative.
* "Fuel" is reusable storage, not energy spent monotonically over time.
* Priority is an ideal discrete execution rule. Finite stochastic rate
  separation alone does not implement the exact zero test.
* All polynomial variables range over nonnegative integers. Equations and
  polynomial evaluation use signed integer arithmetic.
* Every fixed-horizon or fixed-cutoff polynomial has a fixed finite variable
  list. Letting the cutoff vary does not by itself give one fixed polynomial.
* The package does **not** resolve the global finite-fold or single-fold
  conjecture. It does not supply an expanded fixed-arity global MRDP polynomial.
* New mathematical results are proved in the article. Python tests are finite
  implementation checks, not substitutes for those proofs or for the inherited
  universality theorem. No new Lean formalization or Lean build is claimed.
* The constructions are not claimed record-small, and exhaustive historical
  novelty has not been established. The article is not independently refereed.

## Reproduce the artifacts and tests

Use Python 3.10 or later. Only the Python standard library is required.
Run these commands from this directory:

```sh
python code/reaction_compiler.py --output examples
python code/verify.py --output verification/results.json
```

The generator writes the fixed universal reaction system and a worked
8-step example. The verifier uses seed `20260930`, checks source/reaction
correspondence, exact fuel thresholds, uniqueness-gadget cases, witness
mutations, and a false zero branch that must violate a priority residual.
It exits unsuccessfully if an assertion fails. Do not use Python's `-O` flag,
which disables assertions.

Recorded successful checks include 67,943 reaction microsteps, 1,000 random
source/input cases, 600 exhaustive local cases, 125 universal-machine prefixes,
420 rejected one-coordinate witness mutations, and 20 bounded minimum-fuel
cases including zero fuel. Full counts are in `verification/results.json`.

With a TeX distribution providing the packages in the article preamble:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The third pass stabilizes the table of contents and cross-references after a
clean build. No external images or bibliography database are needed.

## Contents

- `article.tex`, `article.pdf`: full article.
- `code/reaction_compiler.py`: typed compiler, simulator, exact sparse integer
  polynomial arithmetic, trace generator, and minimum-resource generator.
- `code/verify.py`: reproducible finite verification suite.
- `examples/universal_reactions.txt`: the complete 62-rule list with priorities.
- `examples/universal_61_species_62_reactions.json`: machine-readable system.
- `examples/doubling_T8_residuals.json`: 781 quadratic residuals.
- `examples/doubling_T8_quartic.json`: their expanded sum of squares, with
  3,202 nonzero monomials and 420 witness variables.
- `examples/doubling_T8_witness.json`: a full satisfying assignment for `n=f=1`.
- `examples/example_summary.json`: generated counts and degree checks.
- `verification/results.json`: executed test output.

The doubling source program repeatedly consumes one unit in its first register
and produces two in its second. Starting from `(n,0)`, it halts at `(0,2n)`;
its exact minimum reserve is `n`. The supplied polynomial is for horizon 8,
not for arbitrary unbounded running time.

## Polynomial JSON format

The quartic JSON object contains `parameters`, `witnesses`, `semantics`, and
`terms`. The `terms` field is a list of records containing an integer
`coefficient` and a list of `variables`. Repeated variable names encode powers: the list
`["x", "x", "y"]` represents the monomial `coefficient * x**2 * y`.
An empty variable list represents a constant. The residual file keeps the
quadratic equations separate; the quartic file combines their squared sum.
The residual representation is preferable for large certificates.

The public generator functions include `compile_machine`, `trace_certificate`,
`trace_assignment`, `initial_polynomials`, and `minimum_certificate`; their
signatures and exact data structures are in the source. The universal cutoff
bound is `62 * binomial(L + 8, 8)`. Large cutoffs generate extremely large
certificates; they are mathematical constructions, not scalable general
Diophantine solvers.

## Provenance and inherited result

The article builds conceptually on ProveIt's MRDP guide and its
`DiophantineTrace.lean` interfaces (`exactIter_dioph`,
`existsExactIter_dioph`, and bounded-universal closure). The trace source was
inspected at commit `4e128356d0ef75308be8ed405d89aea2ffdb8a57`.
A later main-branch read returned `ccfb084adaa2f32e8d2738a25f82a00377fb3a8c`.
This is a targeted source review, not an exhaustive audit of incoming reports.

The universal register machine is inherited from Korec's construction as
presented in the flowchart of Alhazov and Verlan, arXiv:1009.2706. Appendix A
lists all source instructions and the relabeling. The inspected arXiv figure
and adjacent table disagree on the zero successor of source label q27. This
package follows the figure, routing through q29; the discrepancy is explicitly
explained in the article. The universality claim is a literature dependency,
not something established by bounded tests.

Full bibliographic details, including prior work on witness multiplicity,
are in the article. No third-party paper PDFs or font files are redistributed.
