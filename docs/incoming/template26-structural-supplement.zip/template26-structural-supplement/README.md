# A smaller proof of the last gap for template 26

This supplement proves 3 gamma_3^2 >= 8 gamma_2 gamma_4 for the explicitly described four-core preorder family and every nonnegative integer population of its eleven exterior types. Every endpoint support is counted once, using disjoint tail and head subsets of the same physical ground set.

The proof replaces the large local sextic certificate with a deletion-mixture argument and ten five-variable quartic identities, containing 196 positive rational square terms and 846 positive binomial remainder terms. It uses the already approved vertex-weighted degree-at-most-three theorem as an additional dependency. It is a computer-assisted simplification, not a certificate-free proof, a general weighted degree-four theorem, or a real-rootedness claim. The original degree-four article and frozen certificate archive are unchanged.

## Read and reproduce

The article is in `article/template26-last-gap.pdf`, with editable LaTeX source alongside it.

Run with Python 3.11 or later, with assertions enabled:

    python verify.py

This hashes all distributed files, checks the exact approval/dependency pins, and freshly runs two independent standard-library checkers in temporary storage:

- A Hall-support recount of all 56 three-core quotas, followed by exact reconstruction and replay of all ten quartic identities
- A direct ordered disjoint-support Hall recount of all 1,365 four-core quotas and 6,825 scalar entries, checking the support decomposition Gamma = Q_plus + t R

The ordinary convex-hull, activity-specialization, Rayleigh, injection and final-square arguments are given in the article and independently reviewed in the pinned receipts. The executable checkers do not formalize those arguments.

To also extract and replay the complete included vertex-weighted degree-three dependency:

    python verify.py --verify-dependency

This longer mode requires GNU g++ (C++17) in addition to standard-library Python. It invokes the dependency's own portable verifier. Default mode includes and hash-pins this approved dependency but does not rerun it.

A successful run writes `local-replay.json`. Historical receipts are kept as provenance; local algebra success is determined only by newly generated temporary receipts. Python optimization and PYTHONOPTIMIZE are rejected because the independent checkers use assertions. No numerical optimizer or nonstandard Python package is needed.

## Contents

- `article/`: LaTeX source and PDF
- `sources/`: frozen mathematical notes, the ten exact certificates, audited kernel data, independent checker source, and scoped audit receipts
- `dependencies/weighted-degree-three-package.zip`: approved vertex-weighted degree-three article and complete portable proof/checker dependency
- `verify.py`: fresh replay entrypoint
- `SHA256SUMS`: exact file manifest

The original source-directory names and absolute paths in frozen provenance receipts are retained for hash transparency. The wrapper maps those paths into temporary storage and changes only executable path prefixes. It does not need the original workspace. The old deletion-mixture source note includes an earlier status paragraph and an optional first-gap discussion; the pinned approval and this supplement rely only on its last order-three inequality.

## Build the article

With a standard LaTeX installation:

    cd article
    pdflatex -interaction=nonstopmode -halt-on-error template26-last-gap.tex
    pdflatex -interaction=nonstopmode -halt-on-error template26-last-gap.tex

The final claim has unit activities and integer populations. Lower-degree cases are handled explicitly in the proof. This supplement does not replace the separate middle-gap or universal first-gap results needed for full rank-four ultra-log-concavity.
