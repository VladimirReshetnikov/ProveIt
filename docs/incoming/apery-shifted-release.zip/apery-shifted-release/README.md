# Proportionally shifted Apéry Hankel determinants

A standalone mathematical article with a reproducible numerical and symbolic
release, dated 2 October 2026.

## Main result

For the Apéry numbers

A_k = sum_{j=0}^k binom(k,j)^2 binom(k+j,j)^2,

let H_N(r) = det(A_{r+i+j}) for 0 <= i,j < N. Here N is the matrix order.
Uniformly for s = r/N in any fixed compact subset of

(s*, infinity), where s* = 3 sqrt(2)/4 - 1 = 0.0606601717798212866...,

the article proves the full equivalent

H_N(r) = M(s) N^(-1/24) exp(N^2 A(s) + N B(s))
         [1 + c_full(s)/N + O(N^(-2))].

All factors A, B, M and c_full are explicitly specified. The alternative
normalization retains an exact Selberg product, with correction c_rel. The
first correction simplifies to a cubic expression in the first two endpoint
derivatives of a single arcsine integral. The proof includes the endpoint-energy
identity, quantitative logarithmic-confinement bounds and a finite-order
potential-derivative argument. It does not differentiate an asymptotic remainder.

The article also keeps bounded floor phases, proves eventual monotonicity,
and gives rational-residue inverse thresholds with a quantified error inside
the ceiling. The first correction supplies one additional smooth inverse term.
The constants and errors are uniform only on fixed compact subsets above s*.

## Relation to previous work

This continues the targeted ProveIt report *Apéry Hankel growth: a proof, sharp
Szegő asymptotics, and reproducible computations*. Its existing unshifted
quadratic law, Szegő constant, fixed-shift results and inverse correction are
credited in the article and are not presented as new.

The full prefactor of the original unshifted sequence A228143, the cusp
collision, and the critical transition remain unresolved here. The release
computes the first inverse-N correction only. It explains a continuation method
for further fixed orders but does not supply an all-orders coefficient recursion.
No universal priority, peer-review or proof-assistant formalization claim is made.

## Files

- `article.pdf`: the 17-page mathematical article
- `article.tex`: editable standalone LaTeX source with an internal bibliography
- `build.sh`: deterministic three-pass pdfLaTeX build, with a fallback for a
  minimal Debian TeX installation
- `Makefile`: convenience targets for the PDF, replay and integrity verification
- `verify_manifest.py` and `SHA256SUMS`: release-file integrity check
- `replay/README.md`: detailed numerical conventions, precision limits,
  provenance and commands
- `replay/`: a small attributed density module; exact integer moment generation;
  high-precision determinant elimination; constant and first-correction
  quadrature; symbolic checks; unit tests; expected and recorded results

The archive deliberately contains no prior repository snapshot, source-paper
PDFs, private review reports, temporary build files or machine-specific paths.

## Build the article

With pdfLaTeX, Latin Modern fonts, AMS packages, geometry, microtype, booktabs,
fancyhdr, xurl and hyperref installed:

```sh
./build.sh
```

Equivalently, run `make pdf`. The script builds in `.build/` and writes
`article.pdf`. The source includes all bibliography entries; BibTeX and network
access are unnecessary. The supplied PDF is already compiled.

## Replay the computations

Python 3.12 is recommended. Install the small scientific-Python dependency set
if it is not already available:

```sh
python3 -m pip install -r replay/requirements.txt
```

Then run the full offline replay:

```sh
cd replay
python3 run_replay.py --stability
```

The replay preserves `expected/` and `recorded/`, and writes fresh output to
`generated/`. It includes all three displayed determinant examples, exact
symbolic first-correction checks for logarithmic and linear perturbations,
the direct coefficient at two grids, corrected residuals, and numerical
stability comparisons. See `replay/README.md` for individual commands and
precision controls. No script downloads dependencies automatically or contacts
an external service during computation.

## Verify the original release

Before changing or rebuilding any release file:

```sh
python3 verify_manifest.py
```

Generated outputs and local build products are excluded from the manifest.
The manifest establishes file integrity, not mathematical correctness.

## Numerical status

Apéry moment generation is exact integer arithmetic. Determinant elimination
uses high-precision floating point. The midpoint quadrature and cosine
transforms use binary64 after high-precision density evaluation, so long
printed decimal strings are not claims of that many correct digits.
Grid doubling and increased-precision replays are empirical stability checks.
No computation in this release is interval-certified, and none replaces the
analytic proof.

## Attribution

The positive moment density and its hypergeometric formulas are due to
G. A. Edgar, arXiv:2005.10733v2. The small density module follows the branch
prescription in the targeted public ProveIt Part II density script, with a
pinned source link in its documentation. The analytic method is credited to
Charlier–Gharakhloo and Charlier. The exact trace-cumulant check uses the
Schur/Selberg average recorded by Albion–Rains–Warnaar. Full references and
precise locations appear in the article and replay README.
