#!/usr/bin/env python3
"""Verify the original release's SHA-256 checksums, without network access."""
from hashlib import sha256
from pathlib import Path

root = Path(__file__).resolve().parent
count = 0
for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
    digest, rel = line.split("  ", 1)
    path = (root / rel).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise SystemExit(f"Missing or invalid release file: {rel}")
    actual = sha256(path.read_bytes()).hexdigest()
    if actual != digest:
        raise SystemExit(f"Checksum mismatch: {rel}")
    count += 1
print(f"PASS: {count} release files match SHA256SUMS")
