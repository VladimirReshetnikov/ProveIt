# Report 18 Cellular clocks for a literal reversible source

This is a separate report and release. Reports 16 and 17 and their frozen sources remain unchanged. Report18 uses exactly the Report17 scientific source bytes.

## Main result

The fixed history-orientation class has a common compiler constant `lambda = 36,684,691`. Exact whole-prime macro clocks and a recorder embedding prove:

- The optimized source reaches every corresponding clean-run normalized boundary no later in CA microedges than its predecessor, strictly earlier by the first TM cut and thereafter
- On any supplied finite enabled normalized trace, orienting each pair's first encountered edge to zero minimizes every boundary arrival time at once
- Exactly `2^227` static assignments attain the complete clean-startup minimum for every original promised loader input
- For clean initial scratch T=0, an exact quadratic/floor formula gives the minimum, including 1,394,018,396 CA microedges at empty input

The clock comparison is theorem-derived. The saved continuous universal-source prefix actually executes 348 literal rows: startup plus exactly one TM transition. Separate bounded macro tests execute many other literal rows. No CA orbit, giant factor array, completed universal computation, or unrestricted optimality is claimed.

## Files

- `report18.pdf`: 13-page report, including complete proofs, exact clocks, evidence limits, and the inherited fixed-horizon Diophantine timing connection
- `report18.tex`: editable LaTeX source, with a native vector diagram
- `build.sh`: PDF rebuild using TeX Live
- `reproducibility/`: exact source and traces, pinned dependencies, mandatory regenerated predecessor, portable producer checks, independent audit, and all manifests and receipts
- `report18-qa.json`: report review, rendering and bounded trace-verification receipt
- `release-manifest.json`: byte size and SHA-256 of every shipped file except itself and its detached checksum
- `release-manifest.json.sha256`: detached manifest hash
- `verify_release.py`: verifies the manifest and the exact shipped inventory without writing

## Verify and replay

From a fresh extraction:

    python3 -B verify_release.py
    cd reproducibility
    python3 -B run_checks.py

The aggregate checker runs all stages in fresh normal and optimized Python copies, with mandatory local pins and no optional sibling-source dependencies. It leaves delivered files unchanged. The scientific replay requires Python3 and its standard library, not a network connection. See the reproducibility README and PORTABILITY notes for individual commands and exact adaptation provenance.

To rebuild the PDF with TeX Live:

    sh build.sh

This writes `.build/` and replaces `report18.pdf`. Remove `.build/` before an exact-inventory recheck. The manifest verifies the shipped PDF; another TeX distribution may produce an equivalent PDF with different bytes.

## Scientific byte identities

Report17 source:
`fa61d06178d718511232a80a05e02192d940fde3c273f0c202f0623253b2ade3`

Mandatory regenerated predecessor source:
`38c586706fa1069442d3e5103151adb156448b7d7c783f5c46d9d507b87fe73a`

Independently reviewed cellular-clock proof:
`f7385dc48b48fb4f3f95ca082477f36184d6b9cd83f8a97962e9edcc75f94c4c`

The source universality and strict CA compiler remain inherited mathematical dependencies. The bundled certificate reference is proof-only; this release does not rerun the separate certificate implementation or emit a universal polynomial. Portability changes affect path, manifest, and receipt plumbing and are documented independently of the scientific bytes. No private absolute research path, developer log, cache, or third-party full paper is shipped.
