#!/usr/bin/env python3
"""Independent literal/source/bootstrap/corpus audit of ST215-Rho6.

Run with --parent pointing at the extracted ST215 Direct Transfer parent.
No files are changed unless --output is given.  The output must be external
when called by the packet's verify.py.  This audit freshly executes the full
70,506-step blank prefix and 177-primitive AX bridge, decodes the whole tape,
and independently compares literal canonical tuples with all 128 included
comparison tables.  It does not replace the universal runtime proof or the
inherited all-natural calculus and macro proofs.
"""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import json
import sys

TABLE_HASH='fac930e9bc89fed41b631de2f12ef4e48e1c8625ef31ef093d4f14b340f113ad'
SOURCE_HASH='74d21758da7e932de766bee079adf11a7917c03a1957b1111abc6463d70eb332'
PARENT_TABLE_HASH='d5237504325eee96b0040d4d9574731a1caf4bcda3d6a49e94827d9532a664e1'
PARENT_SOURCE_HASH='212cf0ffde43c1cc22c183dd8bf0b3a699396f96c9942ee92a7cc372cd273ca9'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def table(p):
 d={};start=0
 for line in p.read_text().splitlines():
  if line.startswith('#! start '):start=int(line.split()[2])
  if not line or line.startswith('#'):continue
  a,b,w,di,c=line.split();a,b,w,c=map(int,(a,b,w,c));assert b in (0,1)and w in(0,1)and di in('L','R')
  assert(a,b)not in d;d[a,b]=(w,-1 if di=='L'else 1,c)
 qs={q for q,b in d};assert len(d)==430 and len(qs)==215 and set(d)=={(q,b)for q in qs for b in(0,1)}
 hs={z for w,di,z in d.values()}-qs;assert len(hs)==1 and start in qs
 return d,start,next(iter(hs))

def cfg(rows):
 paths=[r[0]for r in rows];assert paths==sorted(paths)and len(paths)==len(set(paths))
 ints={}
 for i,p in enumerate(paths):
  for k in range(len(p)+1):
   q=p[:k]
   if q not in ints:ints[q]=[i,i+1]
   else:ints[q][1]=i+1
 leaf=set(paths)
 for q in ints:
  if q in leaf:assert not(q+'0'in ints or q+'1'in ints)
  else:assert q+'0'in ints and q+'1'in ints
 def jump(p,char,depth,back):
  hits=[i for i,c in enumerate(p)if c==char]
  q=p[:hits[-depth]]if len(hits)>=depth else ''
  return ints[q][0 if back else 1]%len(rows)
 out=[]
 for i,(p,o,a)in enumerate(rows):
  n=(i+1)%len(rows)
  if o=='CI':out.append((n,))
  elif o=='CD':out.append((jump(p,'0',1,False),n))
  elif o=='CB':out.append((jump(p,'0',a,False),))
  elif o=='CC':out.append((jump(p,'1',a,True),))
  elif o=='CH':out.append(())
  else:assert False
 return out

def literal_canon(tab,start,halt):
 # Distinct traversal order from the main comparison script: read1 before read0.
 ids={start:0};queue=[start];result=[]
 for q in queue:
  out=[]
  for b in(1,0):
   w,di,z=tab[q,b]
   if z==halt:target=-1
   else:
    if z not in ids:ids[z]=len(ids);queue.append(z)
    target=ids[z]
   out.append((w,di,target))
  result.append(tuple(out))
 assert len(ids)==215
 return result


def run(packet, parent):
 if not __debug__ or sys.flags.optimize:
  raise RuntimeError('Assertions must be enabled; do not use -O.')
 packet,parent=Path(packet),Path(parent)
 for path,digest in [(packet/'machine/ST215-Rho6.native.tm',TABLE_HASH),
                     (packet/'source/sites.json',SOURCE_HASH),
                     (parent/'machine/st215.native.tm',PARENT_TABLE_HASH),
                     (parent/'source/st215.sites.json',PARENT_SOURCE_HASH)]:
  assert sha(path)==digest, ('Pinned input differs',str(path))
 T,start,halt=table(packet/'machine/ST215-Rho6.native.tm');Old,ostart,ohalt=table(parent/'machine/st215.native.tm');assert(start,halt)==(0,254)==(ostart,ohalt)
 diff=[{'state':q,'read':b,'old':Old[q,b],'new':T[q,b]}for q,b in sorted(T)if T[q,b]!=Old[q,b]]
 assert {(x['state'],x['read'])for x in diff}=={(199,1),(206,0)}
 new=json.loads((packet/'source/sites.json').read_text());old=json.loads((parent/'source/st215.sites.json').read_text());assert len(new)==len(old)==4732
 sdiff=[{'ordinal':i,'old':a,'new':b}for i,(a,b)in enumerate(zip(old,new))if a!=b]
 assert [x['ordinal']for x in sdiff]==[958,963,1136,1141]
 for x in sdiff:assert x['old'][:2]==x['new'][:2]and x['old'][2]==3 and x['new'][2]==5
 ng,og=cfg(new),cfg(old);assert ng==og
 # This is a closed CFG interval, not a source-tree subtree.  Its entire
 # register code is conjugated by 3<->5; all other arguments and edges agree.
 for i in range(887,1170):
  expected=list(old[i])
  if expected[1] in ('CI','CD') and expected[2] in (3,5):
   expected[2]=8-expected[2]
  assert new[i]==expected
 region=set(range(887,1170))
 entries=[(i,j)for i,targets in enumerate(ng)if i not in region for j in targets if j in region]
 exits=[(i,j)for i in region for j in ng[i]if j not in region]
 assert entries==[(881,887)] and {j for i,j in exits}=={1170}
 # Count unique literal leaves and ordered-pair subtrees independently.
 leafmap={p:(o,a)for p,o,a in new};seen=set()
 def subtree(p):
  node=leafmap[p]if p in leafmap else(subtree(p+'0'),subtree(p+'1'))
  seen.add(node)
  return node
 subtree('')
 metrics={'dag_nodes':len(seen),'leaf_occurrences':len(new),
          'maximum_depth':max(len(p)for p,o,a in new),
          'maximum_zero_run':max(len(s)for p,o,a in new for s in p.split('1'))}
 assert metrics=={'dag_nodes':201,'leaf_occurrences':4732,'maximum_depth':44,'maximum_zero_run':6}
 for start_i in(958,1136):
  assert [r[1:]for r in old[start_i:start_i+7]]==[['CD',3],['CI',1],['CI',6],['CC',3],['CD',6],['CI',3],['CC',2]]
  assert [r[1:]for r in new[start_i:start_i+7]]==[['CD',5],['CI',1],['CI',6],['CC',3],['CD',6],['CI',5],['CC',2]]
  # Both are exact additive COPY register->T via X, including restoration.
  assert ng[start_i]==(start_i+4,start_i+1) and ng[start_i+3]==(start_i,)
  assert ng[start_i+4]==(start_i+7,start_i+5)and ng[start_i+6]==(start_i+4,)

 # Fresh execution of the new literal table, then compare the saved old delta trace.
 q=head=0;ones=set();events=[];changed_visits=[]
 for tick in range(70506):
  read=int(head in ones);w,di,z=T[q,read];events.append([tick,q,head,read,w,di,z])
  if any(q==x['state']and read==x['read']for x in diff):changed_visits.append(tick)
  if w:ones.add(head)
  else:ones.discard(head)
  q=z;head+=di
 assert (q,head)==(84,-2)and not changed_visits
 with gzip.open(parent/'evidence/blank-delta.jsonl.gz','rt')as f:
  for k,line in enumerate(f):assert json.loads(line)==events[k]
 assert k+1==len(events)
 # Check the complete stored bijection, then independently execute the dense
 # literal table from blank.  Compare every dense event to its renamed native
 # event, and compare the whole final tape rather than only the dispatcher.
 Dense,dstart,dhalt=table(packet/'machine/ST215-Rho6.tm')
 canon=json.loads((packet/'machine/canonicalization.json').read_text())
 names={int(k):v for k,v in canon['native_to_dense'].items()}
 assert set(names)=={q for q,b in T}|{halt}
 assert set(names.values())==set(range(216)) and len(names)==216
 assert set(Dense)=={(q,b)for q in range(215)for b in(0,1)}
 assert (dstart,dhalt,names[start],names[halt],names[84])==(0,215,0,215,23)
 assert canon['native_sha256']==sha(packet/'machine/ST215-Rho6.native.tm')
 assert canon['dense_sha256']==sha(packet/'machine/ST215-Rho6.tm')
 assert canon['dense_sha256']=='24956a9a07d41ca20ebcd7ac20d90a88a6da3bca24d7859b6f22f5b8f4215ef9'
 for (nq,bit),(w,di,z)in T.items():
  assert Dense[names[nq],bit]==(w,di,names[z])
 dq=dstart;dh=0;dones=set()
 for tick,nq,nh,nb,nw,ndi,nz in events:
  db=int(dh in dones);dw,ddi,dz=Dense[dq,db]
  assert (dq,dh,db,dw,ddi,dz)==(names[nq],nh,nb,nw,ndi,names[nz])
  if dw:dones.add(dh)
  else:dones.discard(dh)
  dq=dz;dh+=ddi
 assert (dq,dh)==(23,-2)and dones==ones
 dense_replay={'steps':70506,'start':dstart,'halt':dhalt,
               'dispatcher':dq,'head':dh,'one_cells':len(dones),
               'entire_tape_equals_native':True,
               'every_event_equals_renamed_native_event':True,
               'full_bijection_checked':True,
               'dense_table_sha256':sha(packet/'machine/ST215-Rho6.tm')}
 meta=json.loads((packet/'evidence/bootstrap.json').read_text());assert sorted(ones)==meta['one_cells']
 assert meta['native_table_sha256']==sha(packet/'machine/ST215-Rho6.native.tm')
 assert meta['source_sha256']==sha(packet/'source/sites.json')
 pc=meta['source_address'];header=head+64;assert header==meta['header']==62
 prefix={head-1,header}|{head+i for i,b in enumerate(pc)if b=='1'}
 assert all((head+i in ones)==(i<len(pc)and pc[i]=='1')for i in range(64))
 # Decode every actual unary file block, rather than copying expected lengths.
 vals=[];p=header+1
 while p<=max(ones):
  assert p not in ones;p+=1;a=p
  while p in ones:p+=1
  assert p>a;vals.append(p-a-1)
 assert len(vals)==72 and vals[9:]==[0]*63
 PHY=(6,2,0,4,3,7,8,5,1);logical=[vals[j]for j in PHY]
 assert logical==[1,0,0,0,0,0,0,18,0]==meta['logical_registers']
 reconstructed=set(prefix);p=header+1
 for v in vals:p+=1;reconstructed.update(range(p,p+v+1));p+=v+1
 assert reconstructed==ones

 # Execute the AX bridge afresh and compare all 177 old trace records.
 regs=[1,0,2,0,0,0,0,0,0];pc_i=25
 axtrace=json.loads((parent/'evidence/AX-prefix.json').read_text());assert len(axtrace)==177
 for step,rec in enumerate(axtrace):
  assert rec['step']==step and rec['ordinal']==pc_i and rec['before']==regs and rec['site']==new[pc_i]==old[pc_i]
  p,o,a=new[pc_i]
  if o=='CI':regs[a]+=1;ni=ng[pc_i][0]
  elif o=='CD':
   positive=regs[a]>0
   if positive:regs[a]-=1
   ni=ng[pc_i][int(positive)]
  elif o in('CB','CC'):ni=ng[pc_i][0]
  else:assert False
  assert rec['after']==regs and rec['next_ordinal']==ni;pc_i=ni
 assert pc_i==58 and new[pc_i][0]==meta['source_address']and regs==logical

 # Independently compare exact canonical tuples against every listed corpus table.
 nov=json.loads((packet/'comparison/comparison.json').read_text());can=literal_canon(T,start,halt);corpus=[]
 for rec in nov['comparisons']:
  rel=PurePosixPath(rec['path']);assert not rel.is_absolute() and '..' not in rel.parts
  p=packet/rel;assert sha(p)==rec['sha256'];tab,s,h=table(p);cc=literal_canon(tab,s,h);assert can!=cc
  first=next(i for i,(a,b)in enumerate(zip(can,cc))if a!=b)
  corpus.append({'path':rec['path'],'sha256':rec['sha256'],'first_literal_canonical_difference':first})
 assert len(corpus)==128 and len({r['sha256'] for r in corpus})==128
 # Explicit different AX packet at A=0,B=1,C=0.
 def P(a,b):return(a+b)*(a+b+1)//2+b
 def I(a,b):return 4*P(a,b)
 def Q(i,a):return 4*P(i,a)+2
 def rho6(a,b):return I(I(Q(a,I(Q(a,b),1)),1),b)
 witness={'A':0,'B':1,'C':0,'old_rho6_AC':rho6(0,0),'new_rho6_AB':rho6(0,1)}
 assert witness['old_rho6_AC']!=witness['new_rho6_AB']
 res={'status':'INDEPENDENT_LITERAL_SOURCE_BOOTSTRAP_AND_CORPUS_AUDIT_PASS','table_sha256':sha(packet/'machine/ST215-Rho6.native.tm'),'source_sha256':sha(packet/'source/sites.json'),'working_states':215,'rows':430,'halt':254,'start':0,'table_diff':diff,'source_diff':sdiff,'source_metrics':metrics,'complete_successor_graphs_identical':True,'rho6_register_conjugacy_interval':[887,1170],'rho6_external_entries':entries,'rho6_exit_ordinal':1170,'two_exact_COPY_C_to_T_changed_to_COPY_B_to_T':True,'fresh_blank_steps':70506,'fresh_dense_blank_replay':dense_replay,'changed_row_visits':changed_visits,'saved_delta_trace_matches_fresh_execution':True,'complete_frame_decoded':{'dispatcher':q,'head':head,'header':header,'source_ordinal':58,'source_address':meta['source_address'],'logical_registers':logical,'spare_count':63,'one_cells':len(ones),'spares_all_zero':True,'no_unrepresented_one_cells':True},'fresh_AX_bridge_steps':177,'AX_packet_semantic_witness':witness,'exact_literal_corpus_comparisons':128,'nonisomorphic_to_all_listed_tables':True,'corpus_comparisons':corpus,'scope':'Exact literal/source/whole-tape startup and graph audit; inherited all-natural command/calculus proofs and the separate newly executed universal mathematical runtime checker remain explicit dependencies. Graph nonisomorphism is not semantic inequivalence.'}

 return res


def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--packet',type=Path,default=Path(__file__).resolve().parent.parent)
 parser.add_argument('--parent',type=Path,required=True,help='Extracted ST215 parent package root')
 parser.add_argument('--output',type=Path,help='Optional JSON receipt; default is stdout only')
 args=parser.parse_args()
 result=run(args.packet,args.parent)
 if args.output:
  args.output.parent.mkdir(parents=True,exist_ok=True)
  args.output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k!='corpus_comparisons'},indent=2))


if __name__=='__main__':
 main()
