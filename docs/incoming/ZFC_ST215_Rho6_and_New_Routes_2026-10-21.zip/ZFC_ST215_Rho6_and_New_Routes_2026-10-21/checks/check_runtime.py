#!/usr/bin/env python3
"""Audit or rederive the exact ST215-Rho6 whole-tape primitive contracts.

The imported parent proof engine derives finite unary and finite-list induction
schemas from the supplied literal table. This is mathematical verification in
Python, not a proof-assistant kernel certificate. The default CLI operation is a
fresh derivation of all 6,151 cases; --audit only audits saved case metadata and
rederives the four block schemas.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
import sys
import time

TABLE = Path('machine/ST215-Rho6.native.tm')
SOURCE = Path('source/sites.json')
REPORT = Path('evidence/runtime.json')
CASES = Path('evidence/runtime_cases.json.gz')
TABLE_HASH = 'fac930e9bc89fed41b631de2f12ef4e48e1c8625ef31ef093d4f14b340f113ad'
SOURCE_HASH = '74d21758da7e932de766bee079adf11a7917c03a1957b1111abc6463d70eb332'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalized(value):
    return json.loads(json.dumps(value))


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inputs(packet, parent):
    """Load the named parent files, without relying on global import order."""
    assert __debug__ and not sys.flags.optimize, 'Assertions must be enabled'
    packet, parent = Path(packet), Path(parent)
    helper_path = parent / 'checks/independent_runtime.py'
    checker_path = parent / 'checks/symbolic_runtime.py'
    mapping_path = parent / 'inputs/native-to-legacy.json'
    helper = load_module('_st215_rho6_independent_runtime', helper_path)
    previous = sys.modules.get('independent_runtime')
    sys.modules['independent_runtime'] = helper
    try:
        engine = load_module('_st215_rho6_symbolic_runtime', checker_path)
    finally:
        if previous is None:
            sys.modules.pop('independent_runtime', None)
        else:
            sys.modules['independent_runtime'] = previous
    assert engine.r is helper
    assert sha(packet / TABLE) == TABLE_HASH
    assert sha(packet / SOURCE) == SOURCE_HASH
    table = helper.table(packet / TABLE)
    states = {q for q, bit in table}
    assert len(states) == 215 and len(table) == 430
    assert set(table) == {(q, bit) for q in states for bit in (0, 1)}
    assert {z for w, d, z in table.values()} - states == {254}
    source = json.loads((packet / SOURCE).read_text())
    assert len(source) == 4732
    leaves, prefixes = set(), set()
    for pc, op, arg in source:
        assert pc not in leaves and 0 < len(pc) <= 64 and set(pc) <= {'0', '1'}
        leaves.add(pc)
        prefixes.update(pc[:i] for i in range(len(pc)))
        assert op in ('CI', 'CD', 'CB', 'CC', 'CH')
        if op in ('CI', 'CD'):
            assert type(arg) is int and 0 <= arg < 9
        elif op in ('CB', 'CC'):
            assert type(arg) is int and arg >= 1
        else:
            assert arg is None
    assert not leaves.intersection(prefixes)
    assert all(p + bit in leaves | prefixes for p in prefixes for bit in ('0', '1'))
    assert len(prefixes) == len(leaves) - 1
    mapping = {int(k): int(v) for k, v in json.loads(mapping_path.read_text()).items()}
    for q in states | {254}:
        mapping.setdefault(q, q + 1000)
    restricted = {q: mapping[q] for q in states | {254}}
    assert len(set(restricted.values())) == 216
    assert mapping[84] == 96 and mapping[254] == 254
    inverse = {v: q for q, v in restricted.items()}
    mapped = {(mapping[q], bit): (w, d, mapping[z])
              for (q, bit), (w, d, z) in table.items()}
    bindings = {
        'table_sha256': sha(packet / TABLE),
        'source_sha256': sha(packet / SOURCE),
        'checker_sha256': sha(checker_path),
        'helper_sha256': sha(helper_path),
        'mapping_sha256': sha(mapping_path),
    }
    return engine, table, mapped, source, inverse, bindings


def audit(packet, parent, work):
    """Check saved metadata and bindings; do not claim fresh case derivation."""
    packet, work = Path(packet), Path(work)
    engine, table, mapped, source, inverse, bindings = inputs(packet, parent)
    report = json.loads((packet / REPORT).read_text())
    packed = (packet / CASES).read_bytes()
    raw = gzip.decompress(packed)
    cases = json.loads(raw)
    assert report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS'
    for key, value in bindings.items():
        assert report[key] == value, ('Binding mismatch', key)
    assert hashlib.sha256(packed).hexdigest() == report['case_file_sha256']
    assert hashlib.sha256(raw).hexdigest() == report['case_uncompressed_sha256']
    expected = [(i, positive) for i, site in enumerate(source)
                for positive in ((False, True) if site[1] == 'CD' else (False,))]
    assert [(c['site_index'], c['positive']) for c in cases] == expected
    assert len(cases) == report['cases'] == report['expected_cases'] == 6151
    rows = set()
    for case in cases:
        assert case['site'] == source[case['site_index']]
        assert len(case['duration']) == len(case['motion']) == 13
        assert all(type(x) is int for x in case['duration'] + case['motion'])
        assert case['duration'][0] > 0 and all(x >= 0 for x in case['duration'])
        assert set(case['kinds']) <= {'literal', 'unary', 'list'}
        assert all(type(n) is int and n > 0 for n in case['kinds'].values())
        assert sum(case['kinds'].values()) == case['symbolic_steps']
        assert 0 < case['symbolic_steps'] < 4000
        assert case['native_rows'] == sorted(map(list, {tuple(r) for r in case['native_rows']}))
        rows.update(map(tuple, case['native_rows']))
    assert rows == set(table)
    assert sorted(map(list, rows)) == report['directly_used_native_rows']
    assert len(rows) == report['rows'] == 430
    assert sum(c['symbolic_steps'] for c in cases) == report['symbolic_steps'] == 1618678
    assert min(c['duration'][0] for c in cases) == report['minimum_actual_steps'] == 5
    assert report['working_states'] == 215 and report['leaf_occurrences'] == 4732
    assert report['append_value'] == 0
    assert report['all_duration_coefficients_nonnegative'] is True
    assert report['proof_construction_bound'] == 4000
    _, blocks = engine.prove_blocks(mapped)
    assert normalized(blocks) == report['blocks']
    result = {
        'status': 'SAVED_CERTIFICATE_AUDIT_PASS',
        'cases': len(cases), 'rows': len(rows), 'symbolic_rules': 1618678,
        'minimum_actual_steps': 5, 'four_block_schemas_reproved': True,
        **bindings,
        'scope': 'All case metadata and input bindings audited. Only the four block schemas were rederived; call run or the default CLI for a fresh derivation of every case.',
    }
    dump(work / 'runtime_audit.json', result)
    return result


def derive(packet, parent, report_path, cases_path):
    packet = Path(packet)
    report_path, cases_path = Path(report_path), Path(cases_path)
    engine, table, mapped, source, inverse, bindings = inputs(packet, parent)
    started = time.monotonic()
    lemmas, blocks = engine.prove_blocks(mapped)
    expected = sum(2 if site[1] == 'CD' else 1 for site in source)
    assert expected == 6151
    cases, rows = [], set()
    for i, site in enumerate(source):
        for positive in ((False, True) if site[1] == 'CD' else (False,)):
            answer = engine.case(mapped, lemmas, site, positive, append=0)
            native_rows = sorted([inverse[q], bit] for q, bit in answer.pop('rows'))
            answer.pop('trace')
            assert all(x >= 0 for x in answer['duration']) and answer['duration'][0] > 0
            rows.update(map(tuple, native_rows))
            cases.append({'site_index': i, 'site': site, 'positive': positive,
                          **answer, 'native_rows': native_rows})
            if len(cases) % 1000 == 0:
                print(f'Runtime: {len(cases)} cases, {time.monotonic()-started:.2f} seconds', flush=True)
    assert len(cases) == expected and rows == set(table)
    rules = sum(case['symbolic_steps'] for case in cases)
    minimum = min(case['duration'][0] for case in cases)
    assert rules == 1618678 and minimum == 5
    raw = (json.dumps(cases, separators=(',', ':')) + '\n').encode()
    packed = gzip.compress(raw, mtime=0)
    if (packet / CASES).exists():
        assert json.loads(gzip.decompress((packet / CASES).read_bytes())) == normalized(cases), 'Fresh cases differ from saved receipts'
    if (packet / REPORT).exists():
        saved_report = json.loads((packet / REPORT).read_text())
        assert saved_report['blocks'] == normalized(blocks)
    cases_path.parent.mkdir(parents=True, exist_ok=True)
    cases_path.write_bytes(packed)
    report = {
        'status': 'UNIVERSAL_MATHEMATICAL_PASS', **bindings,
        'working_states': 215, 'rows': 430, 'leaf_occurrences': len(source),
        'cases': len(cases), 'expected_cases': expected,
        'symbolic_steps': rules, 'minimum_actual_steps': minimum,
        'directly_used_native_rows': sorted(map(list, rows)),
        'blocks': blocks, 'append_value': 0,
        'seconds': time.monotonic() - started,
        'case_file': cases_path.name,
        'case_file_sha256': hashlib.sha256(packed).hexdigest(),
        'case_uncompressed_sha256': hashlib.sha256(raw).hexdigest(),
        'all_duration_coefficients_nonnegative': True,
        'scope': 'Each source primitive and both decrement guards; arbitrary independent natural primary registers, arbitrary natural additional gap, arbitrary first spare value and arbitrary finite remaining spare list, entire zero exterior. Unary-run and finite-list induction, not bounded-register testing.',
        'proof_construction_bound': 4000,
        'proof_construction_bound_scope': 'Bound on symbolic proof rules per case; not a bound on actual machine runtime, register values, gap, or spare-list length.',
        'execution': {'python_version': sys.version, 'optimization': sys.flags.optimize,
                      'debug_enabled': __debug__, 'PYTHONOPTIMIZE': os.environ.get('PYTHONOPTIMIZE')},
    }
    dump(report_path, report)
    return report


def run(packet, parent, work):
    """Freshly derive every case, compare saved receipts, and write new receipts."""
    work = Path(work)
    report = derive(packet, parent, work / 'runtime_fresh.json', work / 'runtime_cases_fresh.json.gz')
    return {'status': 'FRESH_UNIVERSAL_RUNTIME_PASS', 'cases': report['cases'],
            'rows_covered': report['rows'], 'symbolic_rules': report['symbolic_steps'],
            'min_duration': report['minimum_actual_steps'], 'append': report['append_value'],
            'every_case_equals_saved': True, 'seconds': report['seconds'],
            **{key: value for key, value in report.items() if key.endswith('_sha256')}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--parent', type=Path, required=True, help='Extracted ST215 parent package root')
    parser.add_argument('--output', type=Path, required=True, help='JSON report output file')
    parser.add_argument('--cases-output', type=Path, help='Compressed case output file; defaults beside report')
    parser.add_argument('--audit', action='store_true')
    args = parser.parse_args()
    if args.audit:
        result = audit(args.packet, args.parent, args.output.parent)
        dump(args.output, result)
    else:
        cases_output = args.cases_output or args.output.with_name('runtime_cases.json.gz')
        result = derive(args.packet, args.parent, args.output, cases_output)
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('blocks', 'directly_used_native_rows', 'execution')}, indent=2))


if __name__ == '__main__':
    main()
