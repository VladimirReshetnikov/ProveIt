# Exact finite search over AX parameter permutations

Run from any directory with Python 3.10 or newer and its standard library:

```sh
python3 -I /path/to/packet/research/parameter-search/search.py --output /tmp/st215-parameter-search-new
```

The output directory must not already exist. The script reads the local,
frozen `parent_sites.json`; it needs no repository checkout, network,
third-party package, or pre-existing scratch directory. It writes its
receipt and three nonidentity minimum witnesses into the requested new
directory. The supplied `source_language.py` is the same attributed
source-tree/CFG utility used in the pinned parent lineage. Upstream
licenses and notices are retained under the packet's `licenses/`.

## Exact family

Source associations, instruction order, control instructions, row order,
and every instruction outside the seven row intervals are fixed. In each
row independently, permute the three parameter register names `(4,5,3)`
in every `CI` and `CD` instruction. All six permutations are considered in
each row, giving `6**7 = 279936` source assignments. The row intervals in
zero-based ordinal notation are:

| Row | Interval |
|---|---|
| rho7 | [478,887) |
| rho6 | [887,1170) |
| rho5 | [1170,1466) |
| rho4 | [1466,1765) |
| rho3 | [1765,2061) |
| rho2 | [2061,2411) |
| rho1 | [2411,2642) |

For each assignment the objective is exactly the number of distinct
binary subtrees, including primitive leaves. It is not a TM state count.

## Why the optimized count is exact

All original subtrees and all subtrees depending on a single row's
permutation are structurally interned in advance. Their transitive
subtree sets are stored as bitsets. Constant subtrees and the selected
single-row alternatives give the initial bitset union for each assignment.

The remaining 36 joins involve two or more rows. Evaluate them in
bottom-up order. A join already interned in the static table contributes
its node if not present; its children and descendants have already been
evaluated. A new join is interned within this assignment and contributes
one node, with repeated joins sharing its identifier. The union of the
static bits, extra static joins, and new joins is therefore exactly the
root's distinct-subtree set. No pruning, lower-bound approximation, or
heuristic search is used. Every retained minimum witness is also rebuilt
as a full 4,732-leaf tree and independently counted by `metrics`.

## Result and witnesses

The minimum is 201 distinct subtrees. Exactly four assignments reach it,
including the identity. The three nonidentity witnesses are:

| Witness | Parameter swaps |
|---|---|
| `rename-exact-0-201.json` | swap B and C in rows rho2 and rho4 |
| `rename-exact-1-201.json` | swap B and C in row rho6 |
| `rename-exact-2-201.json` | swap B and C in rows rho2, rho4 and rho6 |

The second is the source of the delivered ST215-Rho6 machine. The other
two are source witnesses, without certified 215-state physical allocations.
The frozen receipt records the complete cost histogram and exact
permutation indices. Elapsed time naturally differs on a new run;
the histogram, minimum and witness bytes are deterministic.

This exhaustive finite result does not establish a lower bound over
other source associations, changed macro boundaries, different arithmetic,
row orders, command languages, or physical state-sharing schemes. Those
questions lie outside the enumerated family.

