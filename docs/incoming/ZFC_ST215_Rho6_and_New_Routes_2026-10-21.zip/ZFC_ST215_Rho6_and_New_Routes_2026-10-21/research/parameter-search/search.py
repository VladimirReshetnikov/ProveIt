#!/usr/bin/env python3
from pathlib import Path
from itertools import permutations,product
from functools import cache
import json,sys,time,argparse,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));import source_language as s
parser=argparse.ArgumentParser(description='Exact enumeration of all 6^7 fixed-association AX parameter permutations')
parser.add_argument('--output',type=Path,required=True,help='new output directory; the frozen packet is not modified')
args=parser.parse_args();OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=False)
raw=(HERE/'parent_sites.json').read_bytes()
rows=json.loads(raw);root=s.tree(rows)
assert s.metrics(root)['dag_nodes']==201 and len(rows)==4732
spans=[(478,887,7),(887,1170,6),(1170,1466,5),(1466,1765,4),(1765,2061,3),(2061,2411,2),(2411,2642,1)]
perms=list(permutations([4,5,3]));sub={};nodes=[]
def intern(k):
 n=sub.get(k)
 if n is None:n=len(nodes);nodes.append(k);sub[k]=n
 return n
@cache
def old(t):
 return intern(t if s.leaf(t) else (old(t[0]),old(t[1])))
old(root)
exprs=[];exprlookup={}; masks={};cursor=0

def ex(e,mask):
 n=exprlookup.get(e)
 if n is None:n=len(exprs);exprlookup[e]=n;exprs.append(e)
 masks[-n-1]=mask
 return -n-1

def choices(ref,row):
 if ref>=0:return (ref,)*6
 e=exprs[-ref-1];assert e[0]=='C' and e[1]==row
 return e[2]

def build(t):
 global cursor
 if s.leaf(t):
  i=cursor;cursor+=1
  row=next((j for j,(a,b,k)in enumerate(spans)if a<=i<b),None)
  if row is None or t[0]not in('CI','CD')or t[1]not in(4,5,3):return old(t),0
  vals=tuple(intern((t[0],p[(4,5,3).index(t[1])]))for p in perms)
  return ex(('C',row,vals),1<<row),1<<row
 a,am=build(t[0]);b,bm=build(t[1]);mask=am|bm
 if not mask:return intern((a,b)),0
 if mask&(mask-1)==0:
  r=mask.bit_length()-1
  vals=tuple(intern(k)for k in zip(choices(a,r),choices(b,r)))
  if len(set(vals))==1:return vals[0],0
  return ex(('C',r,vals),mask),mask
 return ex(('J',a,b),mask),mask
rref,mask=build(root);assert cursor==len(rows)
# Retain only expressions reachable from the root. Intermediate single-row
# choices were folded into root choice vectors and need not be evaluated.
used=set();consts=set();choicesets=[set()for _ in range(7)]
def visit(ref):
 if ref>=0:consts.add(ref);return
 e=exprs[-ref-1]
 if ref in used:return
 used.add(ref)
 if e[0]=='C':choicesets[e[1]].add(e[2])
 else:visit(e[1]);visit(e[2])
visit(rref)
@cache
def closure(n):
 k=nodes[n]
 return frozenset([n]) if isinstance(k[0],str) else frozenset([n])|closure(k[0])|closure(k[1])
constset=set().union(*(closure(n)for n in consts))
rowsets=[[set().union(*(closure(v[c])for v in choicesets[r]))for c in range(6)]for r in range(7)]
maskbits=lambda ids:sum(1<<x for x in ids)
constbits=maskbits(constset);rowbits=[[maskbits(v)for v in opts]for opts in rowsets]
ordered=sorted((-ref-1 for ref in used))
ops=[(i,exprs[i])for i in ordered]
staticn=len(nodes)
start=time.monotonic();best=201;records=[];counts={}
print('PREP',{'static_nodes':staticn,'live_expressions':len(ops),'joins':sum(e[0]=='J'for i,e in ops),'seconds':0},flush=True)

def make(c):
 rr=[list(r)for r in rows]
 for j,(lo,hi,k)in enumerate(spans):
  mp=dict(zip([4,5,3],perms[c[j]]))
  if c[j]:
   for i in range(lo,hi):
    if rr[i][1]in('CI','CD'):rr[i][2]=mp.get(rr[i][2],rr[i][2])
 return rr

for count,c in enumerate(product(range(6),repeat=7),1):
 bits=constbits
 for j,k in enumerate(c):bits |= rowbits[j][k]
 vals=[0]*len(exprs);local={};extras=set()
 for i,e in ops:
  if e[0]=='C':vals[i]=e[2][c[e[1]]];continue
  a=e[1] if e[1]>=0 else vals[-e[1]-1]
  b=e[2] if e[2]>=0 else vals[-e[2]-1]
  key=(a,b)
  n=sub.get(key)if a<staticn and b<staticn else None
  if n is None:
   n=local.get(key)
   if n is None:n=staticn+len(local);local[key]=n
  elif not ((bits>>n)&1):extras.add(n)
  vals[i]=n
 cost=bits.bit_count()+len(local)+len(extras)
 counts[cost]=counts.get(cost,0)+1
 if cost<=best:
  if cost<best:best=cost;print('BEST',best,c,'at',count,'seconds',round(time.monotonic()-start,2),flush=True)
  if c!=(0,)*7:
   fname=f'rename-exact-{len(records)}-{cost}.json'
   rr=make(c);actual=s.metrics(s.tree(rr))['dag_nodes'];assert actual==cost,(actual,cost,c)
   (OUT/fname).write_text(json.dumps(rr,separators=(',',':'))+'\n')
   records.append({'file':fname,'choices':c,'nodes':cost})
 if count%20000==0:print('PROGRESS',count,'best',best,'records',len(records),'seconds',round(time.monotonic()-start,2),flush=True)
(OUT/'search.json').write_text(json.dumps({'source_sha256':hashlib.sha256(raw).hexdigest(),'examined':count,'best':best,'counts':counts,'records':records,'permutations':perms,'row_order':[x[2]for x in spans],'seconds':time.monotonic()-start},indent=2)+'\n')
print('DONE',count,best,len(records),time.monotonic()-start,flush=True)
