#!/usr/bin/env python3
"""Independent literal finite-matrix audit; imports no search implementation."""
from pathlib import Path
from itertools import product
import json,hashlib,argparse,sys

def run(path):
 m=json.loads(path.read_text());carrier=range(5);designated={4};truth=4;falsity=0
 assert m['n']==5 and m['nd']==1 and m['T']==truth and m['F']==falsity
 for key in ('I','R','E','Q'):
  assert len(m[key])==25 and all(x in carrier for x in m[key])
 def i(a,b):return m['I'][5*a+b]
 def r(a,b):return m['R'][5*a+b]
 def e(a,b):return m['E'][5*a+b]
 def q(a,b):return m['Q'][5*a+b]
 def n(a):return i(a,falsity)
 def ex(a,b):return n(q(a,n(b)))
 def req(b,k,matrix):
  inside=i(matrix,n(r(b,k)))
  return q(b,i(matrix,n(q(b,inside))))
 def clos(a,b,k,matrix):
  subset=q(k,i(r(k,a),r(k,b)))
  reflection=i(subset,req(b,k,matrix))
  twice=q(a,reflection)
  once=q(a,i(matrix,n(twice)))
  return q(b,i(r(b,k),n(once)))
 def bundle(a,b,c):
  left=i(r(a,b),q(c,r(a,b)))
  right=q(c,i(clos(a,b,c,c),n(req(b,c,c))))
  return n(i(left,right))
 def L(a,b,c,u):return i(i(i(c,u),a),i(i(a,c),i(b,c)))
 counts={}
 def check(name,values):
  vals=list(values);bad=[x for x in vals if x not in designated]
  assert not bad,(name,bad[:5]);counts[name]=len(vals)
 assert truth in designated and falsity not in designated
 assert i(truth,truth)==truth and r(truth,truth)==falsity
 assert all(b in designated for a,b in product(carrier,repeat=2) if a in designated and i(a,b) in designated)
 assert all(q(a,b) in designated for a,b in product(carrier,repeat=2) if b in designated)
 check('rho1',(ex(a,e(a,b)) for a,b in product(carrier,repeat=2)))
 check('rho2',(i(q(a,i(b,c)),i(q(a,b),q(a,c))) for a,b,c in product(carrier,repeat=3)))
 check('rho3',(i(e(a,b),i(r(c,a),r(c,b))) for a,b,c in product(carrier,repeat=3)))
 check('rho4',(i(q(a,q(b,c)),q(b,q(a,c))) for a,b,c in product(carrier,repeat=3)))
 check('rho5',(i(e(c,a),i(r(c,b),r(a,b))) for a,b,c in product(carrier,repeat=3)))
 check('rho6',(i(ex(a,q(a,b)),b) for a,b in product(carrier,repeat=2)))
 check('merged_G',(i(e(c,a),i(e(c,b),q(r(a,b),e(a,b)))) for a,b,c in product(carrier,repeat=3)))
 check('literal_ungated_bundle',(bundle(a,b,c) for a,b,c in product(carrier,repeat=3)))
 check('K',(i(a,i(b,a)) for a,b in product(carrier,repeat=2)))
 check('identities',(i(a,a) for a in carrier))
 check('ex_falso',(i(falsity,a) for a in carrier))
 check('implication_to_truth',(i(a,truth) for a in carrier))
 for name,u in [('membership_AB',lambda a,b,c:r(a,b)),('B',lambda a,b,c:b),('A',lambda a,b,c:a),('C',lambda a,b,c:c),('truth',lambda a,b,c:truth)]:
  check('rho8_'+name,(L(a,b,c,u(a,b,c)) for a,b,c in product(carrier,repeat=3)))
 failures=[list(x)+[L(*x)] for x in product(carrier,repeat=4) if x[3] in set(m['R']) and L(*x) not in designated]
 assert len(failures)==6
 out={'status':'INDEPENDENT_LITERAL_MATRIX_PASS','model_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'designated':[4],'truth':4,'falsity':0,'constructor_aliases_checked':['I(0,0)=0','M(0,0)=1'],'modus_ponens':True,'generalization':True,'exhaustive_schema_counts':counts,'arbitrary_membership_fourth_fails':failures,'scope':'Validates the exact supplied matrix and stated finite identities. Native-code recursion and induction on derivations supply the separate all-natural consistency theorem.'}

 return out

def main():
 if not __debug__ or sys.flags.optimize:
  raise RuntimeError('Assertions must be enabled; do not use -O.')
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--model',type=Path,default=Path(__file__).with_name('model.json'))
 parser.add_argument('--output',type=Path,help='Optional JSON receipt; default is stdout only')
 args=parser.parse_args()
 result=run(args.model)
 if args.output:
  args.output.parent.mkdir(parents=True,exist_ok=True)
  args.output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
