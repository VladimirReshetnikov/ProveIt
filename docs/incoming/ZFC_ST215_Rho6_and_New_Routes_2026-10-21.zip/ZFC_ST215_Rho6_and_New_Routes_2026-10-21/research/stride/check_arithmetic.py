#!/usr/bin/env python3
"""Finite independent corroboration; the all-natural proof is ../../proofs/dyadic_enumeration.md."""
from math import isqrt
from pathlib import Path
import json,argparse,sys

def pair(a,b):return (a+b)*(a+b+1)//2+b

def unpair(n):
 s=(isqrt(8*n+1)-1)//2;y=n-s*(s+1)//2
 return s-y,y

def v2(n):
 assert n
 return (n&-n).bit_length()-1

def fixed_prefix(fs,r):
 for a,successor in reversed(fs):r=pair(a,r)+successor
 return r

def run():
 limit=1_000_000
 b=[0]*limit;m=[0]*limit
 balances=[0,0];mins=[0,0]
 diag_s=0;diag_base=[0,0];diagonal_min=[0,0];checked_diagonals=0
 for n in range(limit):
  a,y=unpair(n)
  if a==0:weight,res=-1,y
  elif a==1:weight,res=0,unpair(y)[1]
  else:weight,res=10,unpair(unpair(y)[1])[1]
  b[n]=weight+(b[res-1] if res else 0)
  m[n]=min(0,weight+(m[res-1] if res else 0))
  parity=n%2
  mins[parity]=min(mins[parity],balances[parity]+m[n])
  diagonal_min[parity]=min(diagonal_min[parity],balances[parity]+m[n]-diag_base[parity])
  balances[parity]+=b[n]
  count=(n-parity)//2+1
  assert balances[parity]+2*count>=0
  if n+1==(diag_s+1)*(diag_s+2)//2:
   if diag_s>=2:
    assert diagonal_min==[0,0],(diag_s,diagonal_min)
    checked_diagonals+=1
   diag_s+=1;diag_base=balances[:];diagonal_min=[0,0]
 assert mins==[-3,0]
 lift_tests=0
 for depth in range(1,10):
  for pattern in range(32):
   fs=[((pattern*7+j*j)%11,(pattern>>j)%2) for j in range(depth)]
   for r in range(25):
    for k in range(6):
     delta=fixed_prefix(fs,r+(1<<(depth+k)))-fixed_prefix(fs,r)
     assert v2(delta)==k
     lift_tests+=1
 result={'status':'FINITE_ARITHMETIC_CORROBORATION_PASS','candidate_count':limit,'parity_minima':mins,'complete_diagonals_checked':checked_diagonals,'pairing_valuation_tests':lift_tests,'proof':'See proofs/dyadic_enumeration.md; finite observations do not establish the universal result.'}
 return result

def main():
 if not __debug__ or sys.flags.optimize:
  raise RuntimeError('Assertions must be enabled; do not use -O.')
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--output',type=Path,help='Optional JSON receipt; default is stdout only')
 args=parser.parse_args()
 result=run()
 if args.output:
  args.output.parent.mkdir(parents=True,exist_ok=True)
  args.output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
