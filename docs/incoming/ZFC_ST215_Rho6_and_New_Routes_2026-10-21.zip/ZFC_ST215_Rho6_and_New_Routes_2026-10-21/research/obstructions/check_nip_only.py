#!/usr/bin/env python3
"""Finite corroboration for the all-natural proof in proofs/nip_only_obstruction.md."""
from functools import cache
from itertools import product
from math import isqrt
from pathlib import Path
import json,argparse,sys

def P(a,b):return (a+b)*(a+b+1)//2+b
def unpair(n):
 s=(isqrt(8*n+1)-1)//2;b=n-s*(s+1)//2;return s-b,b
def I(a,b):return 4*P(a,b)
def M(a,b):return 4*P(a,b)+1
def Q(i,a):return 4*P(i,a)+2
def E(a,b):return 4*P(a,b)+3
def neg(a):return I(a,1)
def exists(i,a):return neg(Q(i,neg(a)))
def L(a,b,c,u):return I(I(I(c,u),a),I(I(a,c),I(b,c)))
@cache
def val(n):
 if n==0:return True
 raw,tag=divmod(n,4);a,b=unpair(raw)
 if tag==0:return (not val(a)) or val(b)
 if tag in (1,3):return False
 if b%4!=0:return False
 left,right=unpair(b//4)
 return right==1 and left%4==2 and unpair(left//4)[0]==a

def subset(a,b,k):return Q(k,I(M(k,a),M(k,b)))
def req(b,k,z):return Q(b,I(z,neg(Q(b,I(z,neg(M(b,k)))))))
def closed(a,b,k,z):return Q(b,I(M(b,k),neg(Q(a,I(z,neg(Q(a,I(subset(a,b,k),req(b,k,z)))))))))
def nks(a,b,c):return Q(c,I(closed(a,b,c,c),neg(req(b,c,c))))
def vrel(a,b,c):return I(M(a,b),Q(c,M(a,b)))
def bundle(a,b,c):return neg(I(vrel(a,b,c),nks(a,b,c)))
rows=[
 lambda a,b,c:exists(a,E(a,b)),
 lambda a,b,c:I(Q(a,I(b,c)),I(Q(a,b),Q(a,c))),
 lambda a,b,c:I(E(a,b),I(M(c,a),M(c,b))),
 lambda a,b,c:I(Q(a,Q(b,c)),Q(b,Q(a,c))),
 lambda a,b,c:I(E(c,a),I(M(c,b),M(a,b))),
 lambda a,b,c:I(exists(a,Q(a,b)),b),
 lambda a,b,c:I(E(c,a),I(E(c,b),Q(M(a,b),E(a,b)))),
 bundle,
]
def run():
 # Include raw true-Q and false-Q shapes rather than testing only small labels.
 params=list(range(10))+[Q(i,b)for i in range(3)for b in range(3)]+[I(Q(i,b),1)for i in range(2)for b in range(2)]
 params=sorted(set(params));receipts={}
 for j,row in enumerate(rows):
  cases=0
  for a,b,c in product(params if j<7 else range(4),repeat=3):
   assert val(row(a,b,c)),(j,a,b,c);cases+=1
  receipts['rho'+str(j+1)if j<7 else 'full_bundle_without_gate']=cases
 for a,b,c,u in product(range(6),repeat=4):assert val(L(a,b,c,u))
 imp=lambda x,y:(not x)or y
 for a,b,c,u in product([False,True],repeat=4):
  assert imp(imp(imp(c,u),a),imp(imp(a,c),imp(b,c)))
 assert val(0) and not val(1) and I(0,0)==0 and M(0,0)==1
 for i,b in product(range(20),repeat=2):assert val(Q(i,I(Q(i,b),1)))
 for i in range(100):assert not val(Q(i,0))
 res={'status':'PASS','native_parameter_count':len(params),'schema_instance_checks':receipts,'unrestricted_L_native_cases':6**4,'unrestricted_L_Boolean_truth_table_cases':16,'true_Q_pattern_cases':400,'failed_GEN_examples':100,'zero_aliases_checked':True,'scope':'Finite corroboration only; all-natural soundness of the operational invariant is in proofs/nip_only_obstruction.md. This is deliberately not a model validating GEN.'}

 return res

def main():
 if not __debug__ or sys.flags.optimize:
  raise RuntimeError('Assertions must be enabled; do not use -O.')
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--output',type=Path,help='Optional JSON receipt; default is stdout only')
 args=parser.parse_args()
 result=run()
 if args.output:
  args.output.parent.mkdir(parents=True,exist_ok=True)
  args.output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
