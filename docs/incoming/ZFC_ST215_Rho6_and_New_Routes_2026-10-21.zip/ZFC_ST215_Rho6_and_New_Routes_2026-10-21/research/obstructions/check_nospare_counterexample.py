#!/usr/bin/env python3
"""Exact finite rejection of a tempting 214-state no-spare patch.
This checks one counterexample to the intended primitive contract; it does not
make a claim about the patch's blank consistency equivalence by some other proof.
"""
import argparse, hashlib, json
from pathlib import Path
PHY=(6,2,0,4,3,7,8,5,1)
PIN='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
def table(p):
 out={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();out[int(q),int(b)]=(int(w),1 if d=='R'else-1,int(z))
 return out

def frame():
 ones={-1,64};p=65
 for v in [0]*9+[1,1,1]:
  p+=1;ones.update(range(p,p+v+1));p+=v+1
 return ones

def decode(q,h,ones):
 if q!=84 or min(ones)!=h-1:return None
 high=sorted(x for x in ones if x>=h)
 if not high:return None
 header=next((x for x in high if x>=h+64),None)
 if header is None:return None
 # A valid dispatch boundary has no intervening marker in the gap beyond PC.
 # Here the candidate comparison allows arbitrary PC, but our observed code
 # ends at or before address7; a later one beforeheader would obstruct decoding.
 if any(h+7<=x<header for x in ones):return None
 p=header+1;vs=[]
 while p<=max(ones):
  if p in ones or p+1 not in ones:return None
  p+=1;v=0
  while p in ones:v+=1;p+=1
  vs.append(v-1)
 if len(vs)<10:return None
 return {'state':q,'head':h,'header':header,'pc_prefix7':''.join(str(int(h+i in ones))for i in range(7)),
         'logical_registers':[vs[j]for j in PHY],'spares':vs[9:],'one_cells':sorted(ones)}

def run(T):
 q=84;h=0;ones=frame()
 for n in range(2001):
  if n:
   r=decode(q,h,ones)
   if r is not None:return {'steps':n,**r}
  w,d,q=T[q,int(h in ones)]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 raise AssertionError('Bound exhausted')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--table',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 assert hashlib.sha256(a.table.read_bytes()).hexdigest()==PIN
 T=table(a.table);assert T[66,0]==(1,1,198)
 U={k:v for k,v in T.items()if k[0]!=198};U[66,0]=(0,-1,54)
 assert len(U)==428 and all(z!=198 for w,d,z in U.values())
 old=run(T);new=run(U)
 assert(old['steps'],old['header'],old['pc_prefix7'],old['logical_registers'],old['spares'])==(602,64,'0100000',[0]*9,[1,1,1])
 assert(new['steps'],new['header'],new['pc_prefix7'],new['logical_registers'],new['spares'])==(1408,66,'1000100',[0,0,0,0,0,0,1,0,1],[1,1])
 out={'status':'EXACT_CONTRACT_COUNTEREXAMPLE','baseline_sha256':PIN,'patch':[66,0,0,'L',54],
      'deleted_state':198,'working_states_after_deletion':214,'fixture':{'pc':'000','operation':['CD',8],'logical_registers':[0]*9,'spares':[1,1,1],'gap':0},
      'baseline':old,'mutant':new,'conclusion':'The proposed fixed-spare primitive simulation is false.'}
 a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ('baseline','mutant')},indent=2))
if __name__=='__main__':main()
