# Research artifacts and exact scope

The only accepted physical candidate in this packet is `../machine/ST215-Rho6.native.tm`. The files here are mathematical alternatives, exact source experiments, obstructions, and bounded search records. **A source DAG node is not a Turing-machine state.**

`source_metrics.json` records the exact full-tree measurements and agreement of two independent source-control resolvers for the six principal experiments. `verify.py --research` reproduces those measurements.

| Directory | Meaning and status |
|---|---|
| `stride/` | Odd-only Cantor proof enumeration: 202 distinct source subtrees, 4,733 primitive leaves. Complete dyadic continuation and parity-credit proofs; no accepted 215-state allocation. `check_arithmetic.py` is finite corroboration, not the proof of the all-natural theorem. |
| `topguard/` | Corrected 23-leaf transfer testing old top before loading cache: 203 subtrees, 4,720 leaves. Its guard uses `CB1`; a superficially similar `CB2` interface is different. The complete total compiler is in the report and `proofs/top_guarded_transfer.md`. |
| `creation-guard/` | Unconditional transfer plus successful-MP falsity guard and cached conclusion: 206 subtrees, 4,718 leaves. `body.json` is the nine-leaf guarded move of counter to cache. |
| `positive-mp/` | Positive-conclusion MP with predecessor-coded field and actual conclusion returned in cache register 5: 210 subtrees, 4,718 leaves. Conclusion zero is supplied by truth. |
| `pairing/` | Sixteen-leaf Cantor PAIR, its exact global replacement source and the 32-variant measurement receipt. 206 subtrees, 4,456 leaves, zero run 7. The source cannot inherit the current maximum-six-zero decoder proof. |
| `finite-matrix/` | Five-value model for the precise simultaneous choices `U∈{M(A,B),A,B,C,0}`. All retained rows, literal ungated bundle, MP, GEN and stated extra schemas pass. Arbitrary membership-valued `U` and constant falsity are expressly outside the result. |
| `obstructions/` | The 199-subtree NIP-only source is rejected by an all-natural operational invariant. The no-spare 214-state mutation is rejected by an exact finite primitive-contract counterexample. Neither is a positive consistency-machine candidate. |
| `packed-mp-tag/` | A 205-subtree source experiment with a changed command tag/field encoding; see `proofs/packed_mp_tag.md`. Its proof applies from a clean theorem frame. It has no physical allocation or transported opaque-tail initialization. |
| `parameter-search/` | Complete portable enumeration of all `6^7=279936` independent parameter permutations with fixed source associations, plus the three nonidentity 201-subtree witnesses and exact-count justification. |
| `searches/` | Original aggregate source and bounded pair-fold receipts. Original execution paths are provenance only. The pair-fold screens' negative results are incomplete proof-search failures, not semantic counterexamples or lower bounds. |

`physical_allocation_summary.json` records fourteen final constrained allocation attempts, across seven stride variants and two physical backends. Infeasibility applies only to the stated protected-row/alias models. It is not a theorem that the source requires more than 215 states.

The shifted dyadic formula-code transport is a theorem, not a supplied physical implementation. Changing pairing must be done consistently in constructors, readers and stacks. Its formula-code bijection is not a conjugacy of raw stack states or the actual blank initialization. The report treats its numerical domination side condition separately.

## Individual replays

Use Python 3.10 or newer, with assertions enabled. These commands write only to the explicitly named external output:

```bash
python3 -I research/finite-matrix/check_model.py --output /tmp/matrix-review.json
python3 -I research/obstructions/check_nip_only.py --output /tmp/nip-review.json
python3 -I research/stride/check_arithmetic.py --output /tmp/dyadic-review.json
python3 -I research/parameter-search/search.py --output /tmp/new-parameter-search
```

The parameter-search output directory must be new. The other checkers default to stdout if `--output` is omitted. The complete finite no-spare counterexample is also rerun by `verify.py --research`, using the pinned K215 table already included in the comparison corpus.

The corpus and source-family receipts do not assert global priority or universal minimality. The report and `proofs/` contain the actual mathematical arguments; a finite test inventory is not substituted for induction over all natural parameters or derivations.
