#!/usr/bin/env python3
"""Offline verification of ST215-Rho6 and the accompanying research.

Python 3 standard library; do not use -O. Default checks literal reconstruction,
complete blank startup, source CFG and AX bridge, dense renaming, the inherited
fixed logical certificate, universal-runtime receipt metadata, and comparison.
--runtime freshly rederives all 6,151 universal symbolic cases.
--research also reruns the finite algebra and enumeration checks.

All output goes into a new external work directory. The packet is not modified.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import time
import zipfile

if not __debug__ or sys.flags.optimize:
    raise RuntimeError('Assertions must be enabled; do not use -O.')
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def manifest():
    data = json.loads((ROOT / 'MANIFEST.json').read_text())
    actual = set()
    for item in data['files']:
        rel = PurePosixPath(item['path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        path = ROOT / rel
        assert path.is_file() and not path.is_symlink(), str(rel)
        assert path.stat().st_size == item['bytes'], str(rel)
        assert sha(path) == item['sha256'], str(rel)
        assert str(rel) not in actual
        actual.add(str(rel))
    expected = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*')
                if p.is_file() and p.name not in ('MANIFEST.json', 'SHA256SUMS')
                and '__pycache__' not in p.parts}
    assert actual == expected, {'unlisted': sorted(expected - actual),
                                'missing': sorted(actual - expected)}
    return {'status': 'PASS', 'files': len(actual)}


def extract_parent(work):
    archive = ROOT / 'reference/ST215_Direct_Transfer_2026-10-21.zip'
    target = work / 'reference'
    target.mkdir()
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            path = PurePosixPath(item.filename)
            assert not path.is_absolute() and '..' not in path.parts
            assert (item.external_attr >> 16) & 0o170000 != 0o120000, 'symlink'
        z.extractall(target)
    candidates = [p.parent for p in target.rglob('verify.py')
                  if (p.parent / 'machine/st215.native.tm').is_file()
                  and (p.parent / 'checks/symbolic_runtime.py').is_file()]
    assert len(candidates) == 1
    parent = candidates[0]
    data = json.loads((parent / 'MANIFEST.json').read_text())
    for item in data['files']:
        path = parent / item['path']
        assert path.stat().st_size == item['bytes']
        assert sha(path) == item['sha256']
    return parent, {'status': 'PARENT_HASHES_PASS', 'archive_sha256': sha(archive),
                    'manifest_files': len(data['files'])}


def research_sources(parent):
    language = module('str6_research_source_language', parent / 'checks/source_language.py')
    expected = {
        'research/stride/sites.json': (202, 4733),
        'research/topguard/sites.json': (203, 4720),
        'research/creation-guard/sites.json': (206, 4718),
        'research/positive-mp/sites.json': (210, 4718),
        'research/pairing/sites16.json': (206, 4456),
        'research/obstructions/nip_only_source.json': (199, 4723),
    }
    records = []
    for path, counts in expected.items():
        source = json.loads((ROOT / path).read_text())
        metrics = language.metrics(language.tree(source))
        assert (metrics['dag_nodes'], metrics['leaf_occurrences']) == counts, path
        assert language.graph_arithmetic(source)[0] == language.graph_intervals(source), path
        records.append({'path': path, 'sha256': sha(ROOT / path), **metrics,
                        'two_source_CFG_resolvers_agree': True})
    assert next(x for x in records if '/pairing/' in x['path'])['maximum_zero_run'] == 7
    return {'status': 'SOURCE_METRICS_AND_CFG_PASS', 'sources': records,
            'scope': 'Syntactic source pricing; no physical allocation or semantic claim follows from these metrics.'}


def candidate_source_graphs(parent):
    language = module('str6_candidate_source_language', parent / 'checks/source_language.py')
    independent = module('str6_independent_source_cfg', ROOT / 'checks/audit_candidate.py')
    current = json.loads((ROOT / 'source/sites.json').read_text())
    previous = json.loads((parent / 'source/st215.sites.json').read_text())
    targets = []
    for source in (previous, current):
        language.tree(source)
        arithmetic, count = language.graph_arithmetic(source)
        intervals = language.graph_intervals(source)
        assert arithmetic == intervals
        successors = [tuple(entry[1]) for entry in arithmetic]
        assert successors == independent.cfg(source)
        targets.append(successors)
    assert targets[0] == targets[1]
    return {'status': 'THREE_SOURCE_CFG_RESOLVERS_AGREE', 'source_occurrences': 4732,
            'guarded_cases': sum(len(x) if x else 1 for x in targets[1]),
            'parent_and_candidate_successors_identical': True,
            'methods': ['binary address arithmetic', 'subtree interval ancestor walk',
                        'independent prefix interval enumeration']}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--runtime', action='store_true')
    ap.add_argument('--research', action='store_true')
    ap.add_argument('--work', type=Path)
    ap.add_argument('--no-manifest', action='store_true',
                    help='Development only, before final manifest creation')
    args = ap.parse_args()
    if args.work:
        work = args.work.resolve()
        assert work != ROOT and ROOT not in work.parents
        work.mkdir(parents=True, exist_ok=False)
    else:
        work = Path(tempfile.mkdtemp(prefix='st215-rho6-replay-'))
    start = time.monotonic()
    result = {'runtime_requested': args.runtime, 'research_requested': args.research,
              'manifest_checked': not args.no_manifest,
              'work': str(work)}
    if not args.no_manifest:
        result['manifest'] = manifest()
    parent, result['parent'] = extract_parent(work)
    sys.path.insert(0, str(parent / 'checks'))
    # The standalone CLI provides a stable interface for the independent audit.
    receipt = work / 'independent_audit.json'
    subprocess.run([sys.executable, '-I', str(ROOT / 'checks/audit_candidate.py'),
                    '--packet', str(ROOT), '--parent', str(parent),
                    '--output', str(receipt)], check=True)
    result['candidate'] = json.loads(receipt.read_text())
    result['source_control'] = candidate_source_graphs(parent)
    presentation = module('str6_presentation', ROOT / 'checks/presentation.py')
    result['presentation'] = presentation.run(ROOT)
    fixed = module('str6_fixed_certificate', parent / 'checks/check_fixed_certificate.py')
    cert = fixed.verify(fixed.read_json(parent / 'inputs/dominated_rho8_full_certificate.json'), True)[0]
    assert cert['proof_nodes'] == 3728 and cert['term_table_nodes'] == 5160
    (work / 'logical_certificate.json').write_text(json.dumps(cert, indent=2) + '\n')
    result['logical_certificate'] = {
        'status': 'PASS', 'proof_nodes': 3728, 'term_table_nodes': 5160,
        'scope': 'Dominated-to-unrestricted propositional recovery, not the entire ZFC calibration'}
    runtime = module('str6_runtime', ROOT / 'checks/check_runtime.py')
    result['runtime_audit'] = runtime.audit(ROOT, parent, work)
    if args.runtime:
        result['runtime_fresh'] = runtime.run(ROOT, parent, work)
    if args.research:
        result['research'] = {'source_metrics': research_sources(parent)}
        for name, script in [
            ('finite_matrix', 'research/finite-matrix/check_model.py'),
            ('nip_obstruction', 'research/obstructions/check_nip_only.py'),
            ('dyadic_arithmetic', 'research/stride/check_arithmetic.py'),
        ]:
            output = work / (name + '.json')
            subprocess.run([sys.executable, '-I', str(ROOT / script),
                            '--output', str(output)], check=True)
            result['research'][name] = json.loads(output.read_text())
        output = work / 'nospare_counterexample.json'
        subprocess.run([sys.executable, '-I',
                        str(ROOT / 'research/obstructions/check_nospare_counterexample.py'),
                        '--table', str(ROOT / 'comparison/tables/9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2.tm'),
                        '--output', str(output)], check=True)
        result['research']['refill_counterexample'] = json.loads(output.read_text())
    result['status'] = 'FULL_REPLAY_PASS' if args.runtime else 'FINITE_REPLAY_PASS'
    result['seconds'] = time.monotonic() - start
    result['scope'] = ('Ordinary mathematical verification, with inherited native-calculus '
                       'calibration and source macro contracts; no new proof-assistant endpoint.')
    (work / 'replay.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in (
        'status', 'work', 'seconds', 'runtime_requested', 'research_requested')}, indent=2))


if __name__ == '__main__':
    main()
