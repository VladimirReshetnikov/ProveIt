# Why deleting the cache-to-top move destroys refutation completeness

## The proposed shortcut

Retain ST215's exact AX and MP commands and replace transfer by

    C(t,P(x,w),d,h) = HALT if t=1;
                     (0,w,d,x) otherwise.

The 23-leaf top-guarded transfer body becomes 20 leaves if its three-leaf H-to-T move is deleted. C clears the old top and loads one stack head into cache, without transferring the old cache to top. The following proof applies to this command system from its clean zero frame, for every numerical candidate word. It proves a universal invariant, not a bounded search failure.

## Two small numerical families

Use native implication I(a,b)=4P(a,b). Define

    F0 = { I(b,0) : b is natural },
    F1 = { I(0,I(b,0)) : b is natural }.

Both contain truth 0 and neither contains falsity 1, because all implication codes have tag 0. Let G be the set containing 0 and all literal full-bundle outputs of AX (one may even include disabled triples). Every nonzero g in G has the form I(s,1), with s!=0: its antecedent s is I(vrel,nks), and nks is Q-headed, hence nonzero. In particular no nonzero g in G has antecedent 0.

Let A be the union of all possible seven retained AX rows, all dominated L rows, and all Q-headed codes. Let

    S = A union G union F0 union F1,
    T = G union F0 union F1.

All these definitions are numerical code predicates; no theoremhood assumption is required. T excludes code 1. Zero belongs to S and T.

## Truth-antecedent lemma

For every z in S, if z=I(0,y), then y belongs to F0 union F1.

For the seven retained rows, the outer antecedents are respectively Q-headed, Q-headed, E-headed, Q-headed, E-headed, an existential code ending in implication to falsity, and E-headed. Each antecedent is strictly positive, so none can equal I(0,y).

For a dominated row,

    L(A,B,C,U)=I(I(I(C,U),A), I(I(A,C),I(B,C))),

a zero antecedent forces I(C,U)=0 and A=0. By Cantor pairing injectivity this forces C=U=0. Its consequent is then

    I(I(0,0),I(B,0)) = I(0,I(B,0)),

which belongs to F1. The order condition U<=A is satisfied automatically in this exceptional case and adds no escape.

A Q-headed code cannot be an implication. A nonzero full-bundle output cannot have antecedent zero by the Q-headed nks observation above. If the gate instead gives zero, then I(0,y)=0 forces y=0. For z=I(b,0) in F0, injectivity forces b=y=0. For z=I(0,I(b,0)) in F1, its consequent I(b,0) belongs to F0. These cases prove the lemma, including all zero-code aliases.

## Global invariant

At every command boundary maintain:

1. t belongs to T;
2. h belongs to S;
3. every iterated decoded stack head belongs to S;
4. h!=0 implies t=0.

The clean zero frame satisfies this invariant. Cantor unpairing of stack zero returns (0,0), so the convention also covers its infinite zero tail.

AX resets h to zero and makes its top a gate output in G. It pushes nine generated rows in A and the old top, already in T subset S. Thus AX preserves all four clauses.

C cannot halt because t belongs to T and T excludes 1. Its successful branch sets top to zero and obtains a new cache from a stack head in S, preserving the remaining tail. Hence it preserves the invariant.

For MP, let y=d+x. A failed test clears both top and cache, preserving the stack. If MP succeeds with h=0, the equation I(t,y)=0 implies t=y=0; the output is truth and the pushed stack head is zero. If MP succeeds with h!=0, clause 4 gives t=0. Its cache is therefore I(0,y) in S. The truth-antecedent lemma gives y in F0 union F1, so the output top is in T. MP clears h and pushes only zero. Thus every successful MP also preserves the invariant, independently of the counter and numerical parameter x.

Every finite raw command sequence consequently preserves the invariant and never halts. The proof is formalizable in PA. It covers malformed proof candidates as well as deliberately compiled ones because every numerical command parameter was unrestricted.

## Consequence

The cache-to-top transfer is semantically essential to this particular AX/MP interface. Without it, every nonzero-cache MP is forced to use truth as its minor premise. The only new accessible consequences are I(0,I(b,0)) and I(b,0), which never include falsity. The 20-leaf shortcut therefore cannot supply the desired equivalence with ZFC consistency, even though its simple theorem-preservation invariant is sound.

The same obstruction also covers a conditional variant that, for t>=2, merely clears t and returns without popping: this extra branch preserves all four invariant clauses. It does not rescue completeness.

This lemma is about the proposed command-interface deletion. It is not a lower bound for arbitrary three-command calculi, alternate AX generators, alternative proof formalisms, or all 20-leaf source bodies.
