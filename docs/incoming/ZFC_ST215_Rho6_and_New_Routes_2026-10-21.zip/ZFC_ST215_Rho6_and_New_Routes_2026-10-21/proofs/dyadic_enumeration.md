# Odd-candidate proof search and a dyadic extension theorem

Date: 2026-10-21. New source-level result; physical allocation and initialization must be checked separately. The inherited numerical calculus, direct-transfer command contracts, and strong proof compiler are those in the ST215 packet at ProveIt commit34b63b3b197b0a5f285a229d91bc163fcc42ab93. This note does not claim a binary state count.

## 1. The concrete change

The ST215 command language has three tags: S=0, MP=1, AX>=2. Its candidate fetch drains N into proof pointer L and scratch X, then restores N using the loop

    CI N; CD X; CC2

which executes its increment one more time than X's incoming value. Thus it advances N by one. At source path000011 replace that entire restoration subtree by its sequential composition with one additional CI N:

    restore -> (restore, CI N).

The old loop's target and the conditional candidate-fetch skip are unchanged. The inserted increment executes once after restoration, only on fresh candidate fetch. Thus a fetch copies oldN into L and returns N=oldN+2. It does not affect any noninitial command or any arithmetic command body.

The exact new source is stride2.sites.json, SHA-256281dae77694e2b48453a870ae3b5cdc8053fa6467d606029573e9ab94f8b82ac. It has202 distinct source subtrees,4733 primitive occurrences, maximum depth44, and maximum zero run6. The two independent CFG resolvers agree. Under old-to-new ordinal map mu(i)=i for i<9 and i+1 otherwise, every edge is unchanged except oldCDX atordinal7: its zero branch now visits newordinal9=CI N before oldordinal9, now10. The source hash and count are not substitutes for a physical runtime theorem.

## 2. General cofinal dyadic extension theorem

Let

    P(a,r)=(a+r)(a+r+1)/2+r.

Write v2(z) for the exponent of2 dividing a nonzero integerz. For fixeda and positive even delta,

    P(a,r+delta)-P(a,r)=delta*(2a+2r+delta+3)/2.

The parenthesized factor is odd. Therefore

    v2(P(a,r+delta)-P(a,r))=v2(delta)-1.                 (1)

Consider any compositionF of exactlym>=1 maps of the formr->P(a,r), with any fixed nonnegative integer additions interspersed. These additions include the successor before each subsequent encoded command. Repeated application of(1) gives, for everyr>=0 and everyk>=0,

    v2(F(r+2^(m+k))-F(r))=k.                          (2)

Each use of(1) is legitimate: before the last of them the input difference remains even. Formula(2) proves a stronger completeness fact than parity alone.

**Dyadic extension theorem.** For every fixed command prefix, everypower2^k, every residuea modulo2^k, and everyboundB, there is a raw continuation tailr such that its candidate encodingF(r)>B andF(r)=a mod2^k.

Proof. Start withr>B. Adjustr successively, forj=0,...,k-1, by either0 or2^(m+j). By(2), the nonzero adjustment toggles bitj ofF while preserving all lower bits. Exactly one choice makes bitj agree witha. After these finitely many choicesF(r)=a mod2^k. Pairing domination givesF(r)>=r>B. This construction is primitive recursive. No decoding condition is imposed onr. Equivalently, arbitrarily large startingr give arbitrarily large witnesses. For k=1 it suffices to compareF(r) andF(r+2^m), whose parities differ.

Apply this to the fixed command word

    AX(0;0,0); B_1; H,

whereB_1 is the inherited strong compiler of a finite native refutation andH is the inherited top-falsity guard. The firstAX resets counter and cache tozero. Its top and stack may be arbitrary; the strong compiler is quantified over all such values. The remaining fixed word therefore halts before it consumes the arbitrary continuation tail. Thus successful candidates occur cofinally in *each* residue class modulo *every* power of2. Searching only odd candidate numbers preserves refutation completeness.

This theorem uses the exact distinction between first-candidate encoding, which lacks an outer successor, and later-command encoding, which includes one. Both are compositions covered by(2). No assertion is made that every dyadic residue contains a syntactically terminated proof encoding; the machine needs only a halting prefix, and the arbitrary suffix is never executed.

## 3. Syntactic credit for the parity schedules

This is needed because the actual ST215 startup has ten theorem heads above an opaque numerical tail. Changing the scheduler invalidates a direct appeal to the old full-enumeration credit theorem. We prove a new one.

Letf be the right Cantor projection andT_s=s(s+1)/2. Thenf(T_s+y)=y for0<=y<=s. LetW(n) be the finite command word decoded from fresh candidaten, ignoring semantic halts. LetR(0) be empty andR(r)=W(r-1) whenr>0, accounting for the decrement before each later command. Ifunpair(n)=(a,y), then

    W(n)=S;R(y)             ifa=0,
    W(n)=MP;R(f(y))         ifa=1,
    W(n)=AX;R(f(f(y)))      ifa>=2.

Assign conservative balancesS=-1, MP=0, AX=10. SuccessfulMP adds an extra theoremzero, safely ignored. Defineb(n) as the total balance ofW(n), andm(n) as its minimum command-prefix balance, including the empty prefix. EveryR(r) has at mostr commands, so every prefix ofR(r) has balance at least-r. This follows by induction because each recursive residual is at most its input and then is decremented.

Putg(0)=0 andg(r)=b(r-1) forr>0. For parityepsilon in{0,1} define

    B_epsilon(k)=sum_(0<=j<k) b(epsilon+2j).

We will prove, at every finite command prefix,

    even schedule W(0);W(2);... has balance >=-3;
    odd schedule W(1);W(3);... has balance >=0.       (3)

In particular the odd schedule needs no initial conservative stack credit.

### Parity prefix-pullback lemma

Supposeq has nonnegative initial partial sums on both parity subsequences:

    sum_(0<=j<k) q(epsilon+2j)>=0

for everyk andepsilon. Thenq composed withf has the same property. Indeed, traverse the Cantor diagonals while taking only input indices of a fixed parity. On diagonal s, the selectedvaluesf(T_s+y)=y form the prefix0,2,... or1,3,... of one of the parity subsequences ofq, according to the parity ofepsilon-T_s. A global prefix is a concatenation of complete such prefixes and one final partial prefix. Every block contributes nonnegatively. Repeating the argument gives the same conclusion forq composed withf composed withf.

The lemma also holds in its finite truncated form. Onlyq arguments no larger than the input bound are used.

### Joint induction over Cantor diagonals

Prove simultaneously:

1. B_epsilon(k)+2k>=0 for every completed parity candidate prefix;
2. B_0(k)>=-3 andB_1(k)>=0;
3. every diagonal s>=2, restricted to either parity of candidate index, has nonnegative command-prefix balance relative to that diagonal's start.

The exceptional words areW(0)=[S], W(1)=[MP], W(2)=[S,S]. Thus the even schedule begins with balances-1,-3 and the odd schedule begins at0. All three assertions required before diagonal2 hold.

Setq(r)=g(r)+2. Its odd-index prefix sums are

    sum_(j<k) q(1+2j)=B_0(k)+2k>=0.

For k>=1 its even-index prefix sums are

    sum_(j<k) q(2j)=B_1(k-1)+2k>=0,

and the empty prefix iszero. Hence the parity pullback lemma applies toq∘f².

Fix diagonal s>=3 and one candidate parity. Its AX candidates have positionsy=alpha,alpha+2,..., withalpha in{0,1}, up to s-2. The balance of the firstk such complete candidates is

    10k + sum_(j<k) g(f(f(alpha+2j))) >= 8k.          (4)

This application uses only previously established induction hypotheses: all relevant arguments are at mosts-2<T_s and the correspondingb indices are even smaller.

Before AX numberj, its previous complete candidates contribute at least8j. Its AX instruction contributes10, and every prefix of the continuation loses at mostf²(y)<=y=alpha+2j. Hence its nonempty prefixes have relative balance at least

    8j+10-(alpha+2j) >=6j+9>0.

Empty prefixes have balance at least8j. This proves prefix safety through the AX portion.

The diagonal's two remaining positions are y=s-1 (MP) andy=s (S). Exactly one of them is in the chosen parity. IfMP is selected, its continuation loses at mosts-1. IfS is selected, its own instruction and continuation together lose at mosts+1. There were at leastfloor((s-1)/2) AX candidates. By(4), throughout this final candidate the balance is at least

    8 floor((s-1)/2)-(s+1) >=3                       (s>=3).

Thus the entire restricted diagonal is prefix-safe. Diagonal2 is checked symbolically: W(3)=[AX], W(4)=[MP], W(5)=[S,MP]. Its even restriction is[MP], and its odd restriction is[AX,S,MP], both prefix-safe.

Consequently no diagonal from2 onward lowers either parity's previous minimum. The global bounds in(3) follow. They imply B_epsilon(k)+2k>=0 for all new prefixes: for odd parity it is immediate; for even parityk>=2 gives-3+2k>=1, while the earlierk=0,1 cases were checked. This closes the induction without circularity.

## 4. Protected-tail soundness and source equivalence

At a command boundary represent the stack as a finite list of explicit theorem heads above an arbitrary fixed tailJ. The list length is a logical accounting device, not a claimed uniquely recoverable numerical length;P(0,0)=0 causes no difficulty becauseunpair(P(x,w))=(x,w) holds for allx,w.

AX prepends ten theorem heads. MP preserves theoremhood and either preserves the stack or prepends theoremzero. A returningS pops one theorem head, moves the incoming theorem-valued cache to top, and loads the popped theorem into cache. Since the odd schedule's conservative balance never becomes negative, ten initial explicit heads remain at leastten throughout. Before everyS there is an explicit head available, soJ is never exposed. The only halt guard sees theorem1 and therefore implies a native refutation. Intermediate behavior inside each arithmetic command uses the inherited exact command contract and the new candidate's separately required primitive runtime proof.

The ST215 bootstrap is matched to a partialAX that finishes withN=1, empty proof pointer, theorem-valued top/cache, and ten theorem heads above opaque tail2. Our source edit is entirely in the candidate-restoration block and leaves that AX source and its later return unchanged. If a binary implementation has the same matched bootstrap, it therefore starts the odd schedule with the required safe protected frame. Such a match must be proved for the new exact binary table; source similarity alone does not prove it.

For completeness, every candidate's finite proof list drains strictly, because each subsequent command starts by decrementing it and returns a right projection no larger than the decremented value. Every arithmetic macro terminates on natural inputs. The scheduler advancesN by2, so it reaches every sufficiently large odd number. The dyadic extension theorem supplies a successful odd candidate above any finite cutoff whenever a native refutation exists. Thus the edited source halts from that protected seed iff the inherited native calculus refutes1. Applying the inherited numerical-calculus calibration yields its ZFC consistency equivalence.

## 5. Verification boundary

check_stride2_arithmetic.py checks one million syntactic candidates,1411 complete nonexceptional diagonals, and43200 exact pairing-valuation instances. It corroborates the definitions and indexing; the proofs above establish the arbitrary-natural statements. build_stride2.py establishes the literal source and both complete CFG identities. A215-state (or214-state) claim additionally needs an exact binary table, an arbitrary-natural runtime derivation, and its actual blank initialization. Those physical obligations are intentionally not inferred from these source results.
