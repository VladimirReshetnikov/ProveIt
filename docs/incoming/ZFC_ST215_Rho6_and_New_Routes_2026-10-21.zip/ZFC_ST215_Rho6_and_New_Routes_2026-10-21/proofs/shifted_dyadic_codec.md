# Transport to a shifted dyadic pairing

## Pairing and exact inverse

Define

    P_2(a,b)=2^a(2b+1)-1.

This is a bijection from N^2 to N. Given n, factor n+1 uniquely as 2^a times an odd number 2b+1. Thus

    a=the exponent of 2 dividing n+1,
    b=((n+1)/2^a-1)/2.

All operations are primitive recursive. The shift by -1 gives P_2(0,0)=0, matching the native empty-stack alias. Moreover

    P_2(a,b)=(2^a-1)+2^(a+1)b >= a,b.

Here 2^a-1>=a for all a>=0, and the second summand dominates b. These facts are enough for well-founded constructor decoding and the existing proof-list draining argument.

## Native constructors and the all-code bijection

Let P_C be Cantor pairing and define old constructors I_C=4P_C, M_C=4P_C+1, Q_C=4P_C+2, E_C=4P_C+3. Define new constructors by the same tag offsets with P_2.

There is a unique recursively defined map f:N->N with f(0)=0 and, for n>0 with n=4P_C(a,b)+tag,

    f(n)=4P_2(f(a),f(b))+tag.

The recursive inputs a,b are smaller than n because P_C dominates both arguments. Conversely define g(0)=0 and, for n>0 decoded using P_2, apply the old constructor to g of its two arguments. P_2 domination again makes the recursion well-founded. Both maps are primitive recursive by course-of-values recursion.

Strong induction proves g(f(n))=n and f(g(n))=n. The exceptional zero case is explicit: both pairings have P(0,0)=0, so both implication constructors satisfy I(0,0)=0 and the constructor-commutation identity at (0,0) agrees with f(0)=0. All positive cases follow by unique decoding and the induction hypotheses. Thus f is a bijection and commutes with every constructor on every numerical argument pair.

In particular f(0)=0, f(1)=1, and the two systems have the same literal truth and falsity codes. This differs from the repository's earlier unshifted dyadic experiment, which used 2^a(2b+1) and changed the low-code aliases.

## Calibration of the unrestricted native calculus

Axioms rho1 through rho8 and the literal full bundle are expressions built from the four constructors, fixed truth/falsity, and numerical parameters. Applying f therefore sends every old unrestricted axiom instance to the new instance at the f-images of its parameters. Every new instance arises this way because f is onto.

The full bundle's private formula-code coupling is preserved, rather than bypassed. A numerical code used as an atomic variable label or binder label is sent to the same f-image as its occurrence as a formula parameter. For example, a coupled membership occurrence M_C(A,B) maps literally to M_2(f(A),f(B)). No arbitrary renaming or substitution principle inside a native proof is assumed.

The gate tests equality or inequality of parameter codes. Since f is injective, c!=a and c!=b hold exactly when f(c)!=f(a) and f(c)!=f(b). Hence the literal enabled/disabled gate cases correspond too.

If an old MP uses A and I_C(A,B), their images are f(A) and I_2(f(A),f(B)), so the new MP gives f(B). GEN similarly commutes with f. Induction on finite proofs yields exact theorem correspondence for the unrestricted calculi, and in particular refutation equivalence because falsity 1 is fixed. The inverse map supplies the converse proof transformation.

## The dominated restriction needs a separate argument

The numerical order condition U<=A is not transported merely by f. There is no monotonicity claim about this recursively defined code bijection.

Instead apply the existing dominated-rho8 recovery certificate separately in the new codec. Its primitive admitted families use U=0 or U occurring as an implication subterm of A. The proof of each numerical bound uses only that an implication constructor dominates both arguments. The new constructor I_2(a,b)=4P_2(a,b) has this property, including its zero alias. The same fixed 3,728-node propositional certificate therefore derives unrestricted rho8 from the new dominated fragment.

The new dominated calculus and its unrestricted version derive the same native codes. The old dominated calculus similarly agrees with its unrestricted version by the inherited certificate. Combining these two recoveries with the all-code bijection yields refutation equivalence between the old and new dominated calculi. This is a certificate-parametric ordinary proof; a publication should retain/check the certificate and its exact stated leaf conditions.

## Command compiler and candidate scheduling

All stack identities used by the strong compiler depend only on pair/unpair being inverse, including unpair(0)=(0,0). The new P_2 satisfies these identities. Counter arithmetic and the AX condition U<=A are unchanged, and the new constructors retain their tags and non-falsity properties. The same command-level proof compiler therefore applies with P_2 throughout.

Cofinal candidate codes remain cofinal because P_2(a,b)>=a,b. A residual obtained by unpairing pred(p) is at most pred(p)<p. Thus every nonhalting positive proof list drains, and the candidate scheduler eventually reaches a successful encoded refutation beyond every finite cutoff.

For soundness of the new search, start in a clean theorem frame with top and cache zero and stack zero. Repeated dyadic unpairing of zero yields only zero heads, so all decoded stack heads are native theorems and the usual global theoremhood invariant applies without a protected-credit estimate. More generally, an initial stack whose every decoded head is a theorem is safe. This establishes the clean-initialized search calibration.

No Cantor-specific protected-credit theorem, candidate order, or instruction-interior blank bootstrap is transported by this argument. In particular, an initialization above an opaque unsafe stack tail would need a fresh credit/safety theorem for the dyadic scheduler and verification of its actual cutpoint. The bijection f preserves tagged formula constructors; it is not asserted to preserve raw stack pairings or to conjugate arithmetic search states.

## Implementation boundary and prior work

The repository already contains an unshifted dyadic backend experiment, with a larger reported source than its then-current Cantor baseline. The shifted variant above preserves the useful zero aliases, but this logical transport theorem does not establish a state-count saving.

Every formula constructor, stack push/pop and field reader must consistently use the new pairing. A hybrid replacement is not covered. A successful machine construction also requires an exact source for the new arithmetic, source allocation, complete-tape runtime proof, and blank-start verification. The result here certifies an admissible alternative codec and the private-code-coupled logical transport; it is not a 214- or 215-state candidate by itself.
