# An all-natural obstruction to deleting the cache-to-top transfer

Date: 2026-10-21. This is an operational invariant for the native AX/MP interface. It is not a model of the whole native logical calculus: its valuation deliberately does not validate theorem generalization.

## The tempting 199-node source

In the composite-transfer parent of ST215, replace the command subtree at source path `111` by its existing NIP child. The resulting `niponly.json` has 199 distinct source DAG nodes, 4723 primitive leaf occurrences, depth 44, and maximum zero run 6. The proposed command keeps the old top and merely advances the cache:

    N(t,P(x,w),d,h) = HALT if h=1;
                       (t,w,d,x) otherwise.

Keep the literal ST215 AX and MP commands, including all seven retained logical axiom rows, dominated row L, the exact gated full bundle, and successful-MP pushes of zero. The following proof shows that no finite command word halts from the clean zero frame. Thus allocating this appealing source cannot yield the desired refutation enumerator.

The same obstruction allows *unrestricted* L parameters and the full bundle even when its usual gate is disabled. It does not depend on the dominance restriction U<=A or on the gate.

## A syntactic Boolean valuation

Use the actual native constructors

    I(a,b)=4P(a,b), M(a,b)=4P(a,b)+1,
    Q_i a=4P(i,a)+2, E(a,b)=4P(a,b)+3.

Here native truth is 0 and falsity is 1=M(0,0). Define a Boolean value v on all natural native codes by:

1. v(0)=true.
2. On a nonzero implication code, v(I(a,b)) is material implication v(a)=>v(b).
3. Every membership-headed or equality-headed code has value false.
4. `v(Q_i x)=true` exactly when there is a natural b with the **literal numerical identity** `x=I(Q_i b,1)`; otherwise it is false.

Clause 4 examines native syntax and the exact numerical binder index, rather than merely the Boolean value of x. It is decidable by two Cantor unpairings and constructor-tag checks. Each nonzero implication's arguments are smaller than the implication code. Thus these clauses define a primitive recursive valuation by ordinary course-of-values recursion. The zero alias causes no inconsistency: material implication gives `v(I(0,0))=true=>true=true=v(0)`. Falsity 1 has value false, and every Q-headed code has tag 2, so no Q-headed code is falsity or an implication.

Write `neg(x)=I(x,1)` and `Exists_i(x)=neg(Q_i neg(x))`.

## Every native AX row has value true

These claims hold for arbitrary natural parameters, including all aliases.

### Row 1: Exists_A(E(A,B))

The inner quantified argument is `I(E(A,B),1)`. Its antecedent has equality tag 3, so it cannot be `Q_A b`, which has tag 2. The quantified code therefore has value false, and its negation has value true.

### Row 2: I(Q_A I(B,C), I(Q_A B,Q_A C))

If the outer antecedent has value false, the row is true. Otherwise the Q definition forces the literal identities `B=Q_A b` for some b and `C=1`. But `Q_A B=Q_A(Q_A b)` has value false, because its matrix B has tag 2 and therefore is not an implication `I(Q_A d,1)`. The consequent implication is true, and hence the whole row is true.

### Rows 3, 5, and 7

Their outer antecedents are equality-headed codes. Those have value false, so all three implications have value true.

### Row 4: I(Q_A(Q_B C), Q_B(Q_A C))

The outer antecedent has value false: its matrix `Q_B C` has tag 2, whereas the special true-Q matrix must have implication tag 0. Hence this row is true.

### Row 6: I(Exists_A(Q_A B), B)

By definition, `v(Q_A I(Q_A B,1))=true`. Therefore `Exists_A(Q_A B)` has value false, and row 6 has value true for every B.

### The unrestricted propositional row

The literal row is

    L(A,B,C,U)=I(I(I(C,U),A), I(I(A,C),I(B,C))).

Material implication validates this formula for every Boolean assignment to A,B,C,U. If C is true, its final consequent is true. If C is false and A is true, `I(A,C)` is false, so the consequent of the outer implication is true. If both C and A are false, then `I(C,U)` is true and `I(I(C,U),A)` is false, so the outer implication is true. This covers all cases, independently of U<=A.

## The exact full bundle has value true

Use the unchanged literal definitions from ST215:

    vrel(A,B,C) = I(M(A,B), Q_C M(A,B)),
    nks(A,B,C)  = Q_C I(closed(A,B,C,C), neg(req(B,C,C))),
    bundle(A,B,C) = neg(I(vrel(A,B,C), nks(A,B,C))).

The complete inner req and closed terms are retained. Their detailed values are unnecessary here because the displayed outer syntax suffices. Since every membership code has value false, vrel has value true. For nks to have value true, its matrix would have to equal `I(Q_C b,1)`. This is impossible: its matrix's consequent is the negation `I(req(B,C,C),1)`, which has implication tag 0 and cannot be the literal code 1. Therefore nks has value false, and the full bundle is the negation of a false implication, hence true. If the gate disables the bundle, it returns native truth 0, also valued true.

This argument validates the **entire** bundle as emitted, with no deletion of conjuncts or relaxation of its syntax.

## The operational invariant

Call a native code *cache-admissible* if it either has value true or has Q tag 2. At every command boundary maintain:

- the top t has value true;
- the cache h is cache-admissible;
- every iterated decoded stack head is cache-admissible.

The clean frame `(0,0,0,0)` satisfies this invariant; the decoded zero tail is the infinite sequence of zeros, each valued true. The numeric counter d is unrestricted.

AX gives a true gate top and cache zero. Its first eight stack heads are the seven native rows and L, all valued true. Its ninth head `Q_d h` is Q-headed, hence cache-admissible without requiring its Boolean value to be true. Its tenth head is the old top, valued true. The older stack is unchanged. Thus AX preserves the invariant, even for unrestricted L and unrestricted full-bundle emission.

A nonhalting N leaves the true top unchanged and obtains its next cache from an admissible stack head. It preserves the invariant. It cannot take its halt branch: native code 1 is false and has membership tag 1, so it is not cache-admissible.

For MP(x), write y=d+x. Failure clears top and cache to zero and preserves the stack, so the invariant remains true. On success the exact equality `h=I(t,y)` implies that h is implication-headed. It therefore cannot be admissible merely by being Q-headed: it must have Boolean value true. Since t also has value true, material implication forces v(y)=true. Successful MP sets top to y, cache to zero, and pushes zero; again the invariant is preserved. This includes the alias `I(0,0)=0`.

Induction on any finite raw command word proves that the machine never halts from its clean frame. This is a PA-formalizable nonhalting argument independent of Con(ZFC).

## Why theorem generalization matters here

The valuation does not validate generalization: native truth 0 has value true, but `Q_i 0` has value false for every i. The original source can produce that Q-headed theorem in its cache and transfer it into the top. Removing the cache-to-top move prevents such a false-valued Q code from ever serving as the current minor premise. It remains confined to the cache/stack, where its tag prevents its use as an implication major.

This identifies a precise obstruction to the proposed source compression. The physical move from cache into top realizes a logical capability that the other instructions cannot reconstruct. Merely keeping the old top while selecting cache majors does not restore that capability.

The invariant also survives commands that clear the top to zero, clear the cache to zero, push the current top or zero, or pop only into the cache. It consequently rules out a wider family of AX/MP/pop variants that never load cached codes into the top. It does not rule out different axiom encodings, altered command interfaces that expose quantified values as current theorems, or entirely different proof formalisms.

## Evidence and scope

`check_nip_only_obstruction.py` independently checks the Boolean L truth table, native constructor aliases, and thousands of exact native-code row and full-bundle instances. Those bounded checks corroborate the symbolic proof above; they are not the proof of its universal claims. The syntax-based argument and operational induction establish the all-natural result.
