# A five-value obstruction for the formerly open mixed fourth-parameter union

## Result and scope

Let C_mix retain the native numerical constructors, truth, MP, theorem GEN, all seven rows rho1 through rho7, and the exact full gated bundle used by the accepted dominated calculus. Replace the four-variable row

    L(A,B,C,U) = ((C -> U) -> A) -> ((A -> C) -> (B -> C))

by the union of the five families with

    U in { M(A,B), A, B, C, truth }.

One may additionally include every numerical instance of K, identity, explosion, and A -> truth. The resulting calculus cannot derive native falsity code 1. Its consistency is provable in PA by the explicit numerical valuation below.

The essential new case is the simultaneous union U=M(A,B) and U=B. At repository commit 34b63b3b197b0a5f285a229d91bc163fcc42ab93, `k219-fourth-parameter/finite-matrix/mixed-union/u-b/README.md` explicitly reports that case as unresolved. The three additional U=A,C,truth families and the propositional extras are simultaneous extensions verified by the same model.

This does not show consistency for arbitrary membership-valued U. The dependency M(A,B) on the same A and B is essential. Nor does it include U=falsity. These overextensions fail in the displayed model.

## Finite algebra

The carrier is V={0,1,2,3,4}, with sole designated value 4. Native truth code 0 receives value 4; native falsity code 1 receives value 0. Lowercase carrier values must not be confused with native codes. Rows and columns of every table below are ordered 0,1,2,3,4.

Implication:

| I |0|1|2|3|4|
|---|---|---|---|---|---|
|0|4|4|4|4|4|
|1|4|4|4|4|4|
|2|3|4|4|4|4|
|3|2|4|4|4|4|
|4|1|1|1|2|4|

Membership:

| M |0|1|2|3|4|
|---|---|---|---|---|---|
|0|1|1|1|3|2|
|1|3|1|2|3|3|
|2|2|0|2|1|2|
|3|1|1|1|2|1|
|4|0|3|0|0|0|

Equality constructor:

| E |0|1|2|3|4|
|---|---|---|---|---|---|
|0|4|3|4|3|3|
|1|2|4|2|2|3|
|2|4|3|4|3|2|
|3|3|3|3|3|3|
|4|3|3|3|3|3|

Universal constructor, including its numerical binder parameter:

| Q |0|1|2|3|4|
|---|---|---|---|---|---|
|0|0|1|1|1|4|
|1|0|1|1|1|4|
|2|0|1|1|1|4|
|3|1|2|1|2|4|
|4|1|2|1|2|4|

These are constructor tables on numerical codes. E and Q need not be the equality and universal-quantifier semantics of a conventional first-order structure. Soundness requires precisely the retained code schemas and inference rules, checked below. In particular no arbitrary theorem-substitution rule is presumed.

## Exact finite facts

Let neg(a)=I(a,0) and Exists(i,a)=neg(Q(i,neg(a))). The independently written checker `check_union_model.py` spells out all seven native rows and every subexpression of the original full bundle. It checks the bundle for all carrier triples without imposing its gate, a stronger requirement than the actual enabled instances.

Every one of the 1,465 listed schema evaluations has value 4: 675 evaluations for the seven retained rows, 125 for the literal bundle, 625 for the five simultaneous fourth-parameter families, 25 for K, and five each for identity, explosion and consequence-truth. Additionally, all 25 MP pairs and all 25 generalization pairs preserve designatedness. The arithmetic alias checks are

    I(4,4)=4,       M(4,4)=0.

The first is necessary for the native alias I(0,0)=0. The second gives the native falsity alias M(0,0)=1 its required undesignated value.

The entire unrestricted L failure set admits a short description:

    L(a,b,c,u) != 4
    iff u=0, b=4, a in {1,2,3}, c in {2,3}.

There are exactly six such quadruples. This explains the restricted-family validity directly. For U=A, B, C, or truth, at least one failure condition contradicts the chosen value of U. For U=M(A,B), a failing tuple would require b=4 and a in {1,2,3}; but the membership column gives M(1,4)=3, M(2,4)=2 and M(3,4)=1, never zero. The precise shared A,B dependency blocks all six failures.

This failure description also prevents accidental overclaims. Arbitrary membership terms can have value zero, as M(4,4)=0. An actual native dominated instance not covered by the new union has A=8, B=0, C=5 and U=1. Their values are respectively 1,4,2,0; U<=A; and its L value is undesignated. Thus the model separates the restricted union from the complete dominated row family at actual numerical codes, not only at unrealized abstract carrier values.

## Total valuation of all native codes

Let

    P(a,b)=(a+b)(a+b+1)/2+b,
    I_code(a,b)=4P(a,b), M_code(a,b)=4P(a,b)+1,
    Q_code(a,b)=4P(a,b)+2, E_code(a,b)=4P(a,b)+3.

Define v(0)=4. For n>0 write n=4P(a,b)+tag, where tag is 0,1,2 or 3. Cantor pairing is injective and both a and b are strictly less than n. Define v(n) by applying the corresponding displayed table to v(a),v(b).

This course-of-values definition is total and primitive recursive. It is a valuation of every numerical code, not just of conventional well-formed first-order formulas. Binder and variable-label parameters are valued recursively too. For positive constructor outputs, the four constructor identities hold by definition. The only zero constructor output is I_code(0,0)=0, and its identity holds because the table gives I(v(0),v(0))=I(4,4)=4=v(0). Therefore all four constructor identities hold for every natural pair a,b.

It follows inductively through each concrete schema expression that its numerical-code value equals its finite table evaluation at the values of its numerical parameters. Every retained row and full bundle instance consequently receives value 4, including every enabled native bundle triple. All five restricted fourth families receive value 4 by the finite facts above. Truth has value 4, and the propositional extras have value 4.

If v(A)=v(I_code(A,B))=4, the MP table condition gives v(B)=4. If v(A)=4, then for every numerical binder i the generalization condition gives v(Q_code(i,A))=Q(v(i),4)=4. Induction on any finite native derivation therefore shows that its final code has value 4.

Finally, v(1)=M(v(0),v(0))=M(4,4)=0, which is not designated. Hence no derivation ends at falsity 1.

All definitions are primitive recursive and the proof uses elementary finite table identities plus induction on natural-number codes and finite derivations. This argument is formalizable in PA. The delivered Python checker verifies the finite table facts; it is not a Lean or Rocq kernel formalization of the all-natural induction.

## Consequence for the ZFC consistency search

Under the usual assumption that ZFC is consistent, this restricted calculus cannot supply the requested ZFC-provable equivalence between its consistency and Con(ZFC). PA, and therefore ZFC, proves its consistency; such an equivalence would make ZFC prove Con(ZFC), contrary to the second incompleteness theorem. Thus recycling the second parameter B together with the same-argument membership constructor M(A,B) does not recover the essential freedom of the dominated fourth parameter. This closes a concrete previously open simplification route; it is not itself a smaller ZFC consistency machine.

## Reproduction and provenance

Run `python3 -I research/finite-matrix/check_model.py --output /tmp/matrix-check.json` from the packet root. The checker loads adjacent `model.json` and records its SHA-256, all 1,465 schema case evaluations, MP/GEN and alias checks, and the six failures for arbitrary membership-valued fourth arguments. The native-code recursion and derivation induction above establish the all-natural result; the finite checker does not replace those arguments.
