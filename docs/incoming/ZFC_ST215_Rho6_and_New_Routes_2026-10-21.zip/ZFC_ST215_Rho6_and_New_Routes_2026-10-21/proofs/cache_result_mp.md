# Creation-guarded MP with a cached result

## Exact command interface

Retain the dominated numerical calculus and literal AX contract. Use unconditional transfer

    S(t,P(x,w),d,h) = (h,w,d,x).

For the new command MPc(z), set y=d+z and use three branches:

    I(t,y)!=h:       (0,w,y,0);
    I(t,y)=h,y=1:    HALT;
    I(t,y)=h,y!=1:   (0,P(0,w),0,y).

Unlike old MP, a successful MPc clears its counter and stores the result in cache. Its top is zero, and it still pushes the deliberate zero onto the stack. Its failed branch is unchanged. Only a successful candidate y=1 halts: the value y=1 on a failed equality test is harmless.

AX(c;x,y) remains exactly

    U=d, A=d+x, B=h+y, C=c;
    (G(A,B,c),[r1,...,r7,L(A,B,c,U),Q_U h,t;w],0,0).

Its gate G is zero or the literal full bundle. All gate and logical-row codes have tag 0, and Q_U h has tag 2, so no new AX output equals native falsity 1. Zero unpairs as (0,0); I(0,0)=0 remains a deliberate native alias.

## Soundness

At safe command boundaries, top, cache and all decoded stack heads are native theorems. AX preserves the inherited theorem invariant. S transfers theorem values without a test. A failed MPc puts truth in top and cache. A successful MPc has theorem premises t and I(t,y)=h; hence y is a theorem. For y!=1 it stores that theorem in cache, puts truth in top, and pushes truth on the stack. For y=1 it halts on a certified native refutation. Counter values play no role in this invariant.

## Structural macros, all-natural contracts

Put D=AX(0;0,0) and H=D;S^11. Independently of any guard, the AX stack has exactly nine generated heads followed by saved top. Thus

    H(t,P(x,w),d,h) = (t,w,0,x)

for every natural t,w,d,h,x. In particular H preserves even an arbitrary incoming top and consumes precisely one preexisting stack head.

Put PUSH=D;S^9;MPc(0). After the AX and nine transfers, cache is Q_d h, with tag 2, whereas the implication tested by MPc has tag 0. Equality therefore fails, so the changed successful-MP branch is never used. Consequently

    PUSH(t,w,d,h) = (0,P(t,w),0,0)

for every natural tuple. The entire macro is total.

When top, cache and counter are zero, use J(0)=empty and J(u)=MPc(u) for u>0. Every positive u fails against cache zero because I(0,u)>0. Hence J(u) returns (0,w,u,0). The empty zero case avoids a successful zero-alias inference.

Finally define

    DISCARD=MPc(1);AX(1;0,0);S^10;MPc(0).

The first MPc fails because I(t,1)>0 while cache is zero; it does not halt merely because its candidate equals 1. AX has A=c=1, hence zero gate. After ten transfers the tuple is (Q_1 0,w,0,0). The final MPc again fails because I(Q_1 0,0)>0. DISCARD is therefore total and sends every (t,w,0,0) to (0,w,0,0).

These are all MP calls made by the auxiliary macros. They are guaranteed failures, so their contracts survive the changed successful-MP state exactly.

## Strong compilation

For every native theorem X construct a finite block B_X such that, for all natural t,w, it either halts or returns exactly (X,w,0,0) from (t,w,0,0). An arbitrary incoming stack tail need not consist of theorems for this completeness contract. Actual-run soundness is the separate invariant above.

Truth uses DISCARD. For a retained logical row j, 1<=j<=7, at requested parameters (a,b,c), use

    DISCARD;AX(c;a,b);S^(j+1);H^(9-j).

The direct transfers put row j on top. Each H consumes one of the remaining generated entries while preserving the selected top; the last consumed entry is saved zero. This returns precisely (row_j,w,0,0).

For the dominated row L(a,b,c,u), u<=a, use

    DISCARD;J(u);AX(c;a-u,b);S^9;H.

For an enabled literal full bundle use

    DISCARD;AX(c;a,b);H^10.

These exact selector identities are unchanged. All auxiliary MPc invocations are the failures already checked, so the blocks are total.

For generalization, retain

    B_(Q_i X)=B_X;PUSH;J(i);S;AX(i;0,0);S^10.

If B_X returns, the next three stages give (0,[X;w],0,0), then (0,[X;w],i,0), then (0,w,i,X). AX has U=A=c=i and zero gate. Its ninth head is Q_i X followed by saved zero, so ten transfers give (Q_i X,w,0,0). If the premise block instead halts, the new block has already met its alternative contract.

For modus ponens from A and I(A,B), use the shorter block

    B_B=B_I(A,B);PUSH;B_A;PUSH;S;S;MPc(B);S.

Ignoring allowed earlier halts, the first four stages give (0,[A,I(A,B);w],0,0). Two transfers yield (A,w,0,I(A,B)). The MPc candidate is exactly B and its equality test succeeds. If B=1 the command halts. If B!=1 its exact output is (0,[0;w],0,B). The final single transfer then gives

    (B,w,0,0).

This uses and removes exactly the deliberate successful-MP zero. The calculation includes A=B=0 and I(0,0)=0: MPc returns (0,[0;w],0,0), and one transfer restores the original stack w. No AX cleanup or counter reset is needed after success because the new command already resets its counter.

Induction on a finite native derivation proves the strong block theorem.

## Every native refutation causes a halt

Truth is code 0, primitive axiom outputs have tag 0, and GEN conclusions have tag 2. Therefore a finite proof of native falsity 1 must end with MP. In its compiled final block, either a premise block already halts or the explicit MPc(1) executes with tuple (A,w,0,I(A,1)). It succeeds with candidate 1 and halts. Thus B_1 always halts from every (t,w,0,0), and no final falsity-test suffix is required.

## Candidate scheduling and calibration

Keep the wire fields S=[0], MPc(z)=[1,z], AX(c;x,y)=[c+2,y,x]. Let R be the predecessor-adjusted continuation encoding tail(B_1). For every natural Y, candidate

    N_Y=P(2,P(Y,P(1,R)))

starts with AX(0;1,Y), resetting counter and cache from an arbitrary retained tuple. The universal B_1 then halts. Since N_Y>=Y, successful candidates are cofinal. The unchanged positive-list scheduler consumes one to three fields from pred(p), so each nonhalting next residual is smaller than p and every unsuccessful finite candidate drains.

Combining safe-run soundness, strong compilation, cofinality and the inherited dominated-calculus/ZFC calibration gives halting exactly when ZFC is syntactically inconsistent. With the remaining source/runtime and blank-initializer obligations established, the machine's non-halting is provably equivalent in ZFC to Con(ZFC).

This proof certifies the command interface. Its source implementation must preserve all three MPc branches, especially failed candidate 1, successful candidate 0, and the successful result's placement in cache with counter zero. A numerical source-node count alone does not establish the transition-table or blank-start claims.
