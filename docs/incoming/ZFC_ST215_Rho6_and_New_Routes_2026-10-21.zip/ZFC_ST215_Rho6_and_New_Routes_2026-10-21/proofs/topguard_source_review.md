# Independent review of top-guarded transfer

Date: 2026-10-21. This note audits the all-natural command semantics and source replacement. It does not assert that a new physical transition table has been allocated or that its blank bootstrap has been checked.

## Corrected 23-leaf source

The reviewed source is `topguard23fixed.json`, with the command subtree at path `111`. Its body is `topguard23fixed-body.json`. Relative to `root-work/topguard23-body.json`, the sole edit is `CB 2` to `CB 1` at body-relative path `01011`. The original `CB 2` leaves the whole command after clearing a top greater than one; the corrected `CB 1` skips only the halt branch and proceeds to the cache move and stack pop.

The full corrected source has 203 distinct DAG nodes, 4720 leaf occurrences, maximum source depth 44 and maximum consecutive-zero depth 6. Its command body has 23 leaf occurrences. The complete interval and binary-arithmetic control-flow resolvers agree. Its closure bound is `(0,0,True)`: it has no outward break or continue, and contains a halt.

Write registers as `N,T,W,A,D,H,X,Y,L`, with scratch precondition `X=Y=0`. The body first executes the six-leaf guard, then drains H into T, and finally unpairs W into H and W. Registers N,A,D,L are never changed. Numbering the body's source leaves from zero gives this exact control flow:

| PC | Instruction | Zero successor | Positive or ordinary successor |
|---:|:---|---:|---:|
| 0 | CD T | 6 | 1 |
| 1 | CD T | 5 | 2 |
| 2 | CD T | 4 | 3 |
| 3 | CC 1 | | 2 |
| 4 | CB 1 | | 6 |
| 5 | CH | | halt |
| 6 | CD H | 9 | 7 |
| 7 | CI T | | 8 |
| 8 | CC 2 | | 6 |
| 9 | CD W | 17 | 10 |
| 10 | CI Y | | 11 |
| 11 | CD X | 13 | 12 |
| 12 | CB 1 | | 16 |
| 13 | CD Y | 16 | 14 |
| 14 | CI X | | 15 |
| 15 | CC 2 | | 13 |
| 16 | CC 3 | | 9 |
| 17 | CD Y | 20 | 18 |
| 18 | CI W | | 19 |
| 19 | CC 2 | | 17 |
| 20 | CD X | return | 21 |
| 21 | CI H | | 22 |
| 22 | CC 2 | | 20 |

Here a positive CD also decrements its named register. A zero CD does not alter it. The return is the ordinary successor after this closed command body; in the full source, the next main dispatch cycle follows.

### Guard proof

If the incoming T is zero, PC0 immediately goes to PC6 with T=0. If T=1, PC0 decrements it and PC1 takes its zero successor PC5, halting. If T>=2, the first two CD instructions consume two units and reach PC2; the PC2/PC3 loop clears the remainder, and PC4 goes to PC6. This is a finite loop with T as descending measure. Consequently every nonhalting case reaches PC6 with T=0, and the only halt occurs exactly when the incoming top was 1. No scratch or other register has yet changed.

### Cache move proof

PC6--PC8 is the standard destructive transfer H into T. Starting with T=0, after H iterations it yields T=old H and H=0. All other registers are preserved. This loop terminates by decrease of H.

### Cantor unpair proof

Let `P(a,b)=(a+b)(a+b+1)/2+b`, and let the incoming W be w. At every visit to PC9, the invariant is

    W + P(X,Y) = w.

Initially it holds with X=Y=0. If W>0, one iteration consumes one unit of W and increments Y. If the old X was positive, the loop decrements X and keeps the incremented Y. Since

    P(X-1,Y+1)=P(X,Y)+1,

the invariant is preserved. If the old X was zero, PC13--PC15 transfers all Y into X, leaving `(X,Y)=(old Y+1,0)`. The identity

    P(old Y+1,0)=P(0,old Y)+1

again preserves the invariant. Each inner transfer terminates by decrease of Y, and the outer loop terminates by decrease of W. At its exit, W=0 and `P(X,Y)=w`, so X and Y are exactly the Cantor projections of w. PC17--PC19 drains Y into W, and PC20--PC22 drains X into the previously cleared H. Thus the result is H=left(w), W=right(w), X=Y=0. This proof includes w=0.

Combining the three stages proves, for every natural tuple and scratch-zero input,

    (t,P(x,v),d,h) -> HALT iff t=1;
                       (h,v,d,x) otherwise.

This is exactly the top-guarded transfer V used in `proofs/top_guarded_transfer.md`.

## Independent compiler review

The strong compiler is valid at the command level. The critical issue is that a directly executed V tests its *incoming* top; a proof-derived falsity must therefore be loaded only after the final guard of each total structural block.

For `D=AX(0;0,0)`, after ten transfers the top is `Q_d h`, the cache is the old top t, and the stack is unchanged. Since Q has residue 2 modulo 4, the eleventh transfer does not halt and loads t only after its guard. Hence `D;V^11` preserves any old top, including 1, and pops one stack head. The intermediate direct guards see only gate, zero, or the eight generated implication-tagged rows. Thus H is genuinely total over arbitrary natural tuples, independently of theoremhood.

For `PUSH=D;V^9;MP(0)`, the cache before MP has residue 2 modulo 4 and cannot equal an implication code. The MP fails even at the native zero alias and gives exactly `(0,[t;w],0,0)`. This block is also total.

For DISCARD, the first MP(1) fails against cache zero because `I(t,1)>0`; the reset AX is disabled by A=C=1; ten transfers end at nonzero quantified code `Q_1 0` with cache zero; and the final MP(0) fails. It returns `(0,w,0,0)` on arbitrary t,w. The special empty J(0) is necessary and correctly avoids the success of MP(0) at the zero implication alias.

The retained-row, L, and gate blocks have exactly the stated numbers of remaining stack heads. Their cleanup uses total H and hence never tests the preserved target. The generalization block executes its only pre-AX V with top zero; after AX all tested tops are generated non-falsity codes. It therefore works even when the input theorem X is 1.

For modus ponens, after two PUSH operations the stack is `[A,I(A,B);w]` and top and cache are both zero. The two subsequent transfers each test top zero and prepare `(A,w,0,I(A,B))`. Successful MP(B) yields `(B,[0;w],B,0)`. The reset AX hides B in its tenth stack position. Its eleventh subsequent transfer tests `Q_B 0`, loads B only after this guard, and pops the successful-MP zero. The result is exactly `(B,w,0,0)`, including the cases A=B=0 and B=1. Induction on a finite native derivation therefore gives the advertised total B_X, not merely a return-or-halt block.

The cofinality argument is sound: an initial AX always resets counter and cache, regardless of incoming top and cache. The strong compiler is independent of the resulting top and stack. The code family `P(2,P(Y,P(1,R)))` with the correctly successor-delimited later-command tail R is unbounded. Every finite nonhalting list drains because each positive list step replaces its value by a residual bounded by its predecessor. Thus a universal refutation block will eventually be tried by the sequential scheduler, irrespective of a finite initial cutoff.

## Protected initialization when the old top is dirty

The safe-tail condition is weaker than requiring the entire decoded stack to consist of theorems. Suppose one AX completes on an arbitrary incoming tuple. Its gate is a theorem, its cache is zero, and its first eight stack heads are the seven native axiom rows and L. Treat the remainder

    [Q_d h,t;w]

as an opaque protected suffix. Neither the old top t nor old cache h must be assumed to be a theorem. The generated quantified code is included in the protected suffix if the old cache is untrusted.

The existing ST215 scheduler-credit proof uses balance -1 for transfer, 0 for MP, and +10 for AX. The new V has exactly the same nonhalting stack balance as old S. It can halt earlier only on an already exposed top; while safe credit remains positive, that top and cache are theorems by direct induction. At each further AX, the current top and cache are now safe, so all ten emitted stack heads are theorems and the same +10 credit is valid. MP can only increase the actual number of safe stack heads relative to its conservative zero balance.

Consequently an initial completed AX supplies eight safe heads even if both old top and old cache were dirty. For the inherited ST215 schedule beginning at candidate 1, its proved conservative debt of at most 2 leaves at least six safe heads above the opaque suffix at every prefix. Thus the suffix is never popped and no dirty value is tested. This reasoning is conditional on establishing the stated actual initialization cutpoint: empty list pointer, next candidate 1, scratch zero, and one completed AX. A concrete modified physical machine still needs its own exact blank-startup trace or a byte-for-byte inherited trace to that cutpoint.

## Scope

This review establishes the source command contract, validates the mathematical strong compiler, and explains the safe-tail initialization obligation. It does not replace the physical source allocator, complete-tape machine simulation, or exact blank-startup check. A state-count claim may only be made after those separate certificates are supplied.
