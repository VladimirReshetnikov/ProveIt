# Packing the MP increment into the command tag

This is a complete alternate wire encoding of the unchanged ST commands.
The source experiment is negative at the desired size: the direct closed
switch has 206 distinct subtrees, and the common-continuation form has 205,
compared with the parent source's 201. No physical state improvement is claimed.

## Encoding and exact command effects

Use the field lists

    AX(c;x,y): [0,c,y,x]
    S:         [1]
    MP(x):     [x+2].

The scheduler's existing 14-leaf field reader loads the first tag into
register A3. Two conditional decrements implement the three-way decision.
Tag zero takes AX with A3 still zero; one takes S after consuming its one;
tags at least two take MP with A3 holding the desired increment x.

AX first invokes the identical 14-leaf field reader again to read c into
A3. It then executes the old AX body, including the same y and x readers,
the dominated fourth parameter, all seven rows and the full gated bundle.
The original terminal control-only CB1 is removed in the closed-branch
form. The changed command therefore has exactly the old AX contract.

The old MP body begins with WALK_L (11 leaves), MOVE_X_D (3), and LOAD_D
(26). Replace these forty leaves by MOVE_A_D (3) and the identical LOAD_D
(26). The move consumes A3=x and adds it to the old counter D4=d, leaving
A3 zero. The old MP arithmetic thus receives exactly the same d+x that
its field reader formerly produced. Its comparison, success and failure
contracts are unchanged. This includes x=0 and I(0,0)=0.

S enters with A3 zero and is the same 35-leaf closed direct transfer.
All three commands restore the selector and scratches under their old
contracts. The maximum zero run remains six in the common-continuation
source, and its two independent complete CFG resolvers agree.

## Equiconsistency and the actual enumeration

The command-level strong proof compiler is unchanged. Replace the field
list of each compiled command by its new field list. For later commands
use tail([])=0 and tail(k::L)=1+F(fields(k),tail(L)), where F right-folds
Cantor pairing. A fresh candidate's first command is read directly,
without the successor used on continuations.

With R=tail(B_1;H), the resetting first command AX(0;1,Y) now has code

    P(0,P(0,P(Y,P(1,R)))).

It still resets counter and cache from an arbitrary retained store. The
strong suffix accepts the resulting arbitrary top and stack and halts.
Cantor domination gives candidate>=Y, so successful candidates are
cofinal. Every nonhalting positive residual reads one, or four, fields
from its predecessor; each tail is at most that predecessor. Hence the
next residual is strictly smaller and every unsuccessful finite candidate
drains.

From a clean theorem frame with top/cache/stack zero, every decoded
stack head is a theorem, so the ordinary theoremhood invariant proves
soundness for all raw words in the new encoding. Strong completeness and
draining then give the calibrated refutation equivalence for that
clean-initialized source search. The old command balances alone do not
transport the old scheduler's protected-credit theorem: field counts and
tag assignments have changed. An opaque-tail initialization or an actual
blank bootstrap would need its own credit/safety argument and cutpoint
verification.

## Exact artifacts and size limitation

`build_packed_tag.py` constructs `packed-tag-source.json` directly from
`st215.sites.json`; it also emits the closed command bodies for AX, MP
and S. The original source has 4,732 primitive occurrences. The closed
two-test source has 4,736 occurrences, 206 distinct subtrees, depth 41,
and maximum zero run 6. `packed-tag-tailAX.json` shares the main loop
continuation and uses 4,735 occurrences, 205 distinct subtrees, depth
39, and zero run 6. Alternative branch layouts were no smaller.

The change removes an MP field read in every execution but does not
remove the underlying unpair arithmetic from the shared source DAG:
AX and the scheduler still use that arithmetic. It also adds a new
parameter-register-to-counter move and changes several shared control
contexts. This explains why the executable field saving does not give
the hoped-for physical state saving in the measured source.

