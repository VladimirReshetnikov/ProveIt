# Top-guarded transfer: a total strong proof compiler

Date: 2026-10-21. This is an all-natural command-level proof. Source implementation, physical allocation, complete-tape runtime, and blank initialization are separate obligations.

## Commands and numerical calculus

Retain the calibrated dominated numerical calculus used by ST215: truth 0, falsity 1, MP, theorem GEN, seven native rows, dominated row L(A,B,C,U) with U<=A, and the literal full gated bundle. Write P(a,b) for Cantor pairing, I(a,b)=4P(a,b), and Q_i a=4P(i,a)+2. Zero unpairs as (0,0).

Keep MP and AX exactly as in ST215. At command boundaries the tuple is (t,w,d,h), representing top, stack, counter and cache. The new primitive transfer V is

    V(t,P(x,v),d,h) = HALT if t=1;
                     (h,v,d,x) otherwise.

ST215 tested h instead of t. The new command tests the old top, then consumes that top, moves its cache to top, and pops one stack head into cache. This changes the meaning of raw command streams.

The MP(x) contract is: set y=d+x; if I(t,y)=h return (y,P(0,w),y,0), otherwise return (0,w,y,0).

The AX(c;x,y) contract is: set U=d,A=d+x,B=h+y,C=c; return

    (G(A,B,c), [r1,...,r7,L(A,B,c,U),Q_U h,t;w], 0, 0).

G is the unchanged full bundle when c differs from A and B, and 0 otherwise. The seven rj and L have tag 0; Q_U h has tag 2; G has tag 0. Thus every new generated top/row is different from falsity 1, independently of its parameters. The saved old top, which is the tenth stack entry, may be any natural.

## Exact structural operations

Put D=AX(0;0,0), H=D;V^11, and PUSH=D;V^9;MP(0).

**Pop preserving the top.** From (t,[x;w],d,h), after D and ten transfers the tuple is (Q_d h,[x;w],0,t). Every tested top so far was the generated gate, zero, or one of the first eight generated rows, hence was not 1. The eleventh transfer tests Q_d h, also not 1, and returns exactly

    H(t,[x;w],d,h) = (t,w,0,x).

Consequently H is total for every natural input tuple, including t=1 and h=1. The preserved incoming top is loaded after the last test. This is the essential difference from ST215's derived H, which tested the preserved top at its final cached-falsity guard.

**Save and reset.** After D;V^9 the tuple is (L(A,B,0,d),[t;w],0,Q_d h). All tested tops were generated non-falsity rows or zero. Since the cache has tag 2 while I(top,0) has tag 0, MP(0) fails and gives exactly

    PUSH(t,w,d,h) = (0,[t;w],0,0).

PUSH is total for all naturals, including the zero implication alias.

## Strong invariant

For every native theorem X there is a finite block B_X such that, for every natural t,w,

    B_X(t,w,0,0) = (X,w,0,0),

and B_X does not halt. This is stronger than the usual return-or-halt contract. It does not assume theoremhood of the incoming t or decoded stack w.

Define

    DISCARD = MP(1);AX(1;0,0);V^10;MP(0).

Because I(t,1)>0, the initial MP fails against h=0, yielding (0,w,1,0). AX has A=c=1, so its gate is zero, and saves top zero. Its tenth transfer gives (Q_1 0,w,0,0); the tested tops are all non-falsity generated codes. The last MP fails because Q_1 0>0 and I(Q_1 0,0)>0. Hence DISCARD is total and returns (0,w,0,0), proving the truth case.

When top, counter and cache are zero, define J(0) as the empty block and J(u)=MP(u) for u>0. It returns (0,w,u,0). The empty zero case is necessary: MP(0) would succeed at the alias I(0,0)=0 and push an unwanted zero.

## Axiom instances

For a retained row j in {1,...,7}, requested at parameters (a,b,c), use

    B_rj = DISCARD;AX(c;a,b);V^(j+1);H^(9-j).

After the transfers row j is top, row j+1 is cache, and exactly 9-j entries remain above w, ending with saved zero. Each H preserves the selected top and pops one head. The last pop restores cache zero and original stack w. Every direct transfer tests a generated non-falsity top or zero, and H is total.

For L(a,b,c,u) with u<=a use

    B_L = DISCARD;J(u);AX(c;a-u,b);V^9;H.

The ninth transfer puts L on top and Q_u 0 in cache, leaving saved zero above w. H removes it. For an enabled full bundle at (a,b,c), use

    B_G = DISCARD;AX(c;a,b);H^10.

The bundle is the AX top; ten H operations remove exactly the ten generated stack entries and preserve the literal bundle. No conjunct or support condition is deleted.

## Generalization

Given B_X, define

    B_(Q_i X) = B_X;PUSH;J(i);V;AX(i;0,0);V^10.

The intermediate tuples are

    (X,w,0,0),
    (0,[X;w],0,0),
    (0,[X;w],i,0),
    (0,w,i,X).

The single V tests top zero, irrespective of X. AX then has U=A=c=i, hence zero gate, and places Q_i X ninth, followed by saved zero. Ten transfers yield (Q_i X,w,0,0). All direct V tests are on zero or generated non-falsity codes, so this block is total even when X=1.

## Modus ponens

Given B_A and B_(I(A,B)), define

    B_B = B_(I(A,B));PUSH;B_A;PUSH;V;V;
          MP(B);AX(B;0,0);V^11.

The first four operations yield (0,[A,I(A,B);w],0,0). Two transfers then yield (A,w,0,I(A,B)); both transfers test top zero. MP(B) succeeds by literal equality, producing (B,[0;w],B,0). The reset AX has A=c=B, zero gate, and saves B over this successful-MP zero. Ten transfers put B in cache with [0;w] still on the stack. The eleventh transfer tests the generated Q_B 0 (tag 2), loads B into top, and removes the successful-MP zero. Its output is exactly (B,w,0,0).

This calculation includes A=B=0, I(0,0)=0, and B=1. In particular the transfer immediately after computing B does not test B: the final transfer loads it only after testing the preceding generated Q-code. Thus no early halt occurs, and induction on a finite proof gives the stated total strong compiler.

## Refutation and cofinality

If the native calculus derives 1, B_1 returns (1,w,0,0) for every initial (t,w,0,0). The single next command V halts. Thus B_1;V is a universal refutation block.

The wire fields are unchanged from ST215:

    fields(V)=[0]; fields(MP(x))=[1,x]; fields(AX(c;x,y))=[c+2,y,x].

For a list of fields fs and residual r, F(fs,r) is their right-nested pairing above r. Encode later commands by tail([])=0 and tail(k::L)=1+F(fields(k),tail(L)), accounting for the scheduler's decrement at positive proof-list boundaries. Put R=tail(B_1;V). For every Y the initial command AX(0;1,Y) has candidate code

    N_Y=P(2,P(Y,P(1,R))).

It resets counter and cache to zero from every retained tuple. The universal strong block then succeeds. Since N_Y>=Y, successful candidates occur beyond every finite startup cutoff. Each nonhalting command consumes one to three fields from pred(p), so the next residual is at most pred(p)<p. Every finite unsuccessful proof list drains, and sequential candidate enumeration eventually reaches a successful candidate.

## Soundness and calibrated conclusion

At every safe command boundary let top, cache and all iterated decoded stack heads be native theorems. MP and AX preserve this inherited invariant. When V returns, it moves the old cached theorem to top and the old stack-head theorem to cache; when V halts, its old top is the theorem 1. Hence every actual halt implies a native refutation. The converse follows from the total strong compiler and cofinality.

Under the retained source-runtime, safe-initialization and dominated-calculus calibration hypotheses, the modified enumerator halts exactly when ZFC has a finite refutation. Equivalently, its non-halting is equivalent to Con(ZFC). These logical hypotheses do not by themselves certify a particular transition table; the source replacement, allocation, runtime simulation and blank bootstrap must be checked separately.
