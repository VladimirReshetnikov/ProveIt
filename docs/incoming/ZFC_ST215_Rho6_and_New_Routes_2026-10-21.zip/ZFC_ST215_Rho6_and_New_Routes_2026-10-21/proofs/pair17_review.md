# Independent review of the 17-leaf one-scratch Cantor pair

The proposed macro `research/pairing/body17.json` replaces the old 19-leaf PAIR(T,W) macro. The intended entry is `(T,W,X,Y)=(a,b,0,0)`; other registers are arbitrary and preserved.

First COPY(W->T via X) copies W additively into T while restoring W and clearing X. Its exact result is `(a+b,b,0,0)`.

The outer loop then decrements T once, increments W once, copies the remaining T additively into W via X, and repeats. If its incoming T is k>0, the iteration adds `1+(k-1)=k` to W and leaves T=k-1 and X=0. The loop therefore terminates after a+b iterations and gives

    T=0, W=b+sum_{k=1}^{a+b} k=P(a,b), X=0, Y=0.

The inner copy loops terminate by descending source registers and restore their source exactly. Y is never touched, so the new macro actually preserves arbitrary Y and therefore satisfies the old macro's stronger scratch-zero postcondition whenever Y was zero at entry. This argument includes a=b=0 and either individual zero.

The source-level command structure is

    COPY(W->T via X);
    while T>0: decrement T; increment W; COPY(T->W via X).

The provided structured source encodes exactly this control flow with the enclosing continue at depth 3. Each zero test exits its intended copy or outer loop, and each normal return reaches the next enclosing source instruction. Its source closure bounds are zero outward breaks and zero outward continues.

Replacing every exact old PAIR subtree is therefore justified at every entry satisfying its inherited arithmetic interface, independently of surrounding numeric values. The parent source contains 92 occurrences of the old subtree. Such replacement does not by itself justify a partial blank bootstrap that enters in the middle of a replaced macro; that startup cutpoint needs a separate exact trace or a new symbolic match. The published generated source currently has maximum consecutive-zero depth 7, so a physical certificate proved only for depth at most 6 cannot simply be inherited.

An alternative 17-leaf tree is `research/pairing/body17-trisum.json`. It begins with the same COPY(W->T), then uses the old ten-leaf triangular-sum core with its accumulator changed from Y to W. In that core, one phase transfers T into W and X; the following phase consumes one X, increments W, and moves the remaining X into T. The phase boundary invariant gives the same triangular sum, with X decreasing by one per cycle and T=X=0 on return. Its corresponding global replacement is `research/pairing/sites17-trisum.json`.

Both tested global source variants have 207 DAG nodes, 4548 leaf occurrences, and maximum zero run 7. Their shorter expanded source has not yet yielded a physical state saving. This note establishes the arithmetic contract; the numbers are measured source counts, not a machine-state or optimality claim.
