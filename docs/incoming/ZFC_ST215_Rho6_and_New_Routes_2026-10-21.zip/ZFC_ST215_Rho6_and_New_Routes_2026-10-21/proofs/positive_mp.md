# Positive-conclusion MP with a predecessor-coded parameter

## Command equations

Use the unchanged AX command and unconditional transfer S(t,P(x,w),d,h)=(h,w,d,x). For MP+(z), set s=d+z and y=s+1. Its exact branches are

    I(t,y)!=h:       (0,w,s,0);
    I(t,y)=h,s=0:    HALT;
    I(t,y)=h,s>0:    (0,P(0,w),0,s+1).

The equality comparison uses y=d+z+1, while a failed command retains the predecessor s=d+z in the counter. A successful positive result is stored in cache, the counter and top become zero, and a deliberate zero is pushed. Success with predecessor zero means result 1 and halts.

This is a changed command language and parameter codec. It checks only positive-conclusion MP instances. The ordinary theorem code 0 remains available as primitive truth, so no derivation needs MP to produce 0.

## Refutation strength of positive-only MP

Retain every native axiom, truth, and GEN. Restrict the native MP rule to conclusions different from 0. The restricted calculus derives exactly the same numerical codes as the unrestricted one: each omitted MP step has conclusion 0, which can instead refer to the truth axiom. Replace such lines one by one in any finite derivation. Conversely each retained inference was already an ordinary MP inference.

This is a direct proof transformation on numerical derivations. It uses no theorem substitution and no semantic property of formula codes. In particular refutations of native falsity 1 correspond exactly.

## Soundness of commands

At a safe boundary, top, cache and all stack heads are native theorems. AX and transfer preserve the inherited theorem invariant. A failed MP+ sets top/cache to truth. On success, its premises are t and h=I(t,s+1), so s+1 is a theorem by positive-only MP. If s=0 the command halts on theorem 1. Otherwise it stores the theorem s+1 in cache and truth in top and on the stack, preserving soundness.

The guard must occur only after the premise comparison succeeds. Candidate y=1 on a failed comparison is not a refutation.

## Auxiliary operations are unchanged

Let D=AX(0;0,0) and H=D;S^11. The exact ten-entry AX stack gives

    H(t,P(x,w),d,h)=(t,w,0,x)

for all natural inputs.

Let PUSH=D;S^9;MP+(0). Before MP+, cache is Q_d h and therefore has tag 2. The compared formula I(top,1) has tag 0, so the comparison fails. The counter before MP+ is zero and remains zero on failure. Consequently PUSH is total and returns

    (0,P(t,w),0,0).

Define DISCARD=MP+(1);AX(1;0,0);S^10;MP+(0), with initial counter/cache zero. The first comparison is I(t,2)=0, which fails because I(t,2)>0; it returns top/cache zero and counter 1. AX has A=c=1 and zero gate. Ten transfers return (Q_1 0,w,0,0). The final comparison I(Q_1 0,1)=0 also fails, leaving exactly (0,w,0,0). DISCARD is total for every incoming top and stack.

From top/counter/cache zero, MP+(u) always fails because I(0,u+1)>0. Its exact output is (0,w,u,0). Thus J(u)=MP+(u) works for every u>=0. For compatibility one may also keep J(0)=empty and J(u)=MP+(u) for u>0. The positive-conclusion codec removes the old successful-MP(0) alias in this auxiliary use.

## Strong proof compiler

For every native theorem X, compile a block B_X that, from any (t,w,0,0), either halts or returns (X,w,0,0). For X=0 choose DISCARD, irrespective of the last inference in the supplied proof. This explicitly eliminates every zero-conclusion MP case.

All axiom selectors remain the same as in the unconditional-transfer compiler:

    retained row j: DISCARD;AX(c;a,b);S^(j+1);H^(9-j),  1<=j<=7;
    dominated L:   DISCARD;J(u);AX(c;a-u,b);S^9;H,     u<=a;
    enabled bundle:DISCARD;AX(c;a,b);H^10.

They use only the total auxiliary contracts just proved, and preserve the arbitrary incoming stack tail. The final popped saved zero restores cache zero. The full literal bundle and its exact gate are retained.

For GEN use

    B_(Q_i X)=B_X;PUSH;J(i);S;AX(i;0,0);S^10.

After the premise and first four suffix operations, the tuple is (0,w,i,X). AX has U=A=c=i, so its gate is zero and its ninth generated head is Q_i X, followed by saved zero. Ten transfers return (Q_i X,w,0,0), unless the premise block had already halted. This includes X=0 and i=0.

For MP with a positive conclusion B, use

    B_B=B_I(A,B);PUSH;B_A;PUSH;S;S;MP+(B-1);S.

If the premise blocks return, their outputs and the two saved heads give exactly (A,w,0,I(A,B)) before MP+. Its predecessor is 0+(B-1), so its compared conclusion is B. The equality therefore succeeds. If B=1 the predecessor is zero and MP+ halts. If B>1 it returns (0,[0;w],0,B), and the final transfer returns (B,w,0,0).

These blocks prove the strong compiler by induction on finite derivations, with the X=0 shortcut used whenever the final conclusion is truth. No subtraction is performed at run time to form B-1: it is a concrete nonnegative parameter computed by the proof compiler for the positive B case.

## Refutations and cofinality

A proof of 1 cannot end in truth, an implication-coded primitive axiom, or GEN with tag 2. Its final inference is a positive MP step. The compiled block either halts in a premise or reaches the explicit successful MP+(0) with tuple (A,w,0,I(A,1)). It then halts. Hence B_1 succeeds universally from every input with zero counter and cache, with no final test suffix.

The fields remain S=[0], MP+(z)=[1,z], and AX(c;x,y)=[c+2,y,x]. For R=tail(B_1), the candidate

    P(2,P(Y,P(1,R)))

starts with AX(0;1,Y), resetting counter and cache from any retained tuple. The following B_1 halts. Pairing domination makes these candidates cofinal in Y. Every unsuccessful finite list drains under the unchanged predecessor/read scheduler.

Thus the command system has exactly the native refutation strength, and by the inherited calibration its non-halting corresponds to Con(ZFC). Exact source, physical-table, runtime, and blank-start obligations remain separate. In particular the implementation must compare I(t,d+z+1), retain d+z on failure, and distinguish successful predecessor zero from failed predecessor zero.
