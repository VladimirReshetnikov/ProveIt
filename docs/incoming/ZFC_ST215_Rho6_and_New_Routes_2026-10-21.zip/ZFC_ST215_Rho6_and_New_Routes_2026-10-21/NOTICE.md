# Attribution, dependencies and research status

This packet was prepared for Vladimir Reshetnikov's ProveIt project with ChatGPT assistance on 21 October 2026. It builds on the repository snapshot `34b63b3b197b0a5f285a229d91bc163fcc42ab93`, particularly its incoming ST215 direct-transfer packet and prior sixth-row parameter-reassignment work.

The exact direct-parent archive is preserved byte-for-byte in `reference/ST215_Direct_Transfer_2026-10-21.zip`. Its authorship notices, source pins, licenses, original proof arguments and calibration dependencies remain authoritative for inherited material. Copies of the parent's supplied licenses and notices are also in `licenses/`. Retain those notices if incorporating or redistributing the inherited material.

The direct transfer, contextual reassociation used by ST215, append-zero runtime, protected-credit proof, numerical calculus, core arithmetic macros, fixed logical certificate, and symbolic-runtime infrastructure are inherited. The `rho6(A,B)` sampler is also a prior idea. This packet does not claim their invention.

Candidate-specific additions comprise the exact composition, its source and transition changes, universal-case replay, complete startup transfer, independent audit and explicit comparison corpus. New research arguments include the dyadic continuation and parity-credit theorems, complete alternative guard languages, mixed-parameter finite matrix, NIP quarantine obstruction, and alternative pairing dataflow. Their claims and limits are specified in the report and proofs.

The literal candidate is a 215-state machine. No valid 214-state machine or new exact-table Lean/Rocq kernel endpoint is claimed. Smaller source DAGs in rejected experiments are not smaller consistency machines. Constrained allocation failures and bounded search records are not global lower bounds.

The proof of the consistency equivalence uses the identified inherited native-calculus calibration and all-natural arithmetic macro contracts. The new Python symbolic proof engine replay is ordinary mathematical verification with explicit induction rules, not a proof-assistant kernel. The default verifier audits saved case metadata; `--runtime` rederives every universal primitive case.

The 128 comparison tables are inert research inputs, copied from the inspected repository and incoming packets. `comparison/comparison.json` preserves their original paths and hashes. Rooted graph nonisomorphism is not semantic inequivalence, and the corpus comparison is not a global priority claim.
