# ST215-Rho6 and new routes toward 214

**A new, fully specified 215-state composition, with an ordinary blank-tape consistency-equivalence proof. No valid 214-state machine was obtained.**

The machine has 215 working states, two symbols, one bi-infinite tape, a separate halt, and an all-zero initial tape. Building on the identified ProveIt native-calculus calibration and arithmetic macro contracts, the report proves

```text
ZFC ⊢ (ST215-Rho6 does not halt on blank tape ↔ Con(ZFC)).
```

The exact table combines the existing direct-transfer implementation with the existing sixth-row sampler `rho6(A,B)` instead of `rho6(A,C)`. The combination has a different raw command effect and is not isomorphic, preserving the distinguished start/halt and tape actions, to any of the 128 distinct 215-state tables supplied in the comparison corpus. Its two individual ingredients are prior work. The packet makes no global priority claim and contains no new compiled Lean/Rocq endpoint.

## Read the report

The main deliverable is [ZFC_ST215_Rho6_and_New_Routes.pdf](report/ZFC_ST215_Rho6_and_New_Routes.pdf), with its [complete TeX source](report/ZFC_ST215_Rho6_and_New_Routes.tex) and included sections. It states the proof dependencies, new all-natural arguments, complete transition table, search boundaries, and next targets.

## Concrete construction

Exactly two native transitions change from the direct parent:

| State/read | Parent | ST215-Rho6 |
|---|---|---|
| `199 / 1` | `1 R 166` | `1 R 12` |
| `206 / 0` | `0 R 186` | `0 R 76` |

Exactly four source operands change from register 3 to register 5, at zero-based ordinals `958, 963, 1136, 1141`. Source paths, opcodes and the complete guarded successor graph are unchanged. The sixth emitter is a closed control-flow interval `[887,1170)`, with sole entry 887 and sole exit 1170; it is not asserted to be a single source subtree. The proof is a register-conjugacy argument plus an explicit new selector for every requested sixth-row axiom instance.

| Obligation | Result |
|---|---:|
| Working states / transition rows | 215 / 430 |
| Source distinct subtrees / primitive occurrences | 201 / 4,732 |
| Maximum source depth / zero run | 44 / 6 |
| Universal primitive cases | 6,151 of 6,151 |
| Symbolic proof rules | 1,618,678 |
| Literal rows covered | 430 of 430 |
| Minimum positive affine duration constant | 5 |
| Exact blank-tape startup | 70,506 transitions |
| Exact matched AX source prefix | 177 transitions |
| Compared distinct literal 215-state tables | 128; no rooted isomorphism |

The universal runtime checker handles arbitrary independent natural logical registers, an arbitrary additional gap, arbitrary spare values and an arbitrary finite spare list. It uses induction on unary lengths and lists; it is not a bounded-register experiment. A limit on symbolic proof construction is not a limit on actual machine runtime or input values.

### Initialization matters

The physical blank run reaches an instruction *inside* the first AX, not a clean source root. At 70,506 steps, native dispatcher 84 has head −2, header 62, gap zero, source ordinal 58, address `00110010010110010`, registers `(N,T,W,A,D,H,X,Y,L)=(1,0,0,0,0,0,0,18,0)`, and **63 zero spare blocks**. The entire tape has exactly 100 one-cells. Neither changed row has yet been visited.

The 177-step source bridge begins at AX entry 25 with the synthetic tuple `(1,0,2,0,0,0,0,0,0)`. Its completion supplies ten theorem heads over opaque tail 2. The inherited schedule from candidate 1 has conservative debt at most two, leaving eight protected heads. This protects buried falsity in the opaque tail and is part of the soundness argument.

## New structural results

1. **Dyadic continuation theorem and odd-only search.** Every fixed halting prefix has cofinally many encodings in every residue class modulo `2^k`. A separate parity-credit proof shows that the odd-candidate schedule `1,3,5,…` never incurs conservative stack debt. The literal odd-only source has 202 distinct subtrees; no 215-state allocation was obtained.
2. **Top-guarded transfer.** Test the old top, then load cache and pop. The 23-leaf macro admits a *total* strong proof compiler, even for a theorem whose code is falsity 1. The whole source has 203 distinct subtrees. Its semantic proof is complete; its physical allocation remains open.
3. **Inference-time falsity detection.** Successful MP can test for falsity and return a cached result with cleared counter, allowing unconditional 19-leaf transfer. A positive-conclusion variant encodes the predecessor of the MP conclusion; conclusion zero is supplied directly as truth. Concrete sources have 206 and 210 distinct subtrees, respectively.
4. **A five-value mixed-parameter obstruction.** All seven retained rows, the full literal bundle, MP, GEN, and the union `U∈{M(A,B),A,B,C,0}` for the fourth propositional parameter have a finite model, even with K, identity, explosion and implication-to-truth added. Their consistency is provable in PA. This closes the stated mixed-membership/second-parameter simplification route. The restriction to the *same* `A,B` in `M(A,B)` is essential; arbitrary membership-valued parameters are not covered.
5. **A NIP-only obstruction.** The tempting 199-subtree source is provably nonhalting from its clean frame. A Boolean operational invariant quarantines exceptional GEN outputs. This is not a Boolean model of GEN and is not a valid small consistency machine.
6. **Sixteen-leaf Cantor pairing.** A new all-natural accumulator loop shortens the 19-leaf arithmetic macro, but the full source grows to 206 distinct subtrees and maximum zero run 7. The report explains why this does not immediately fit the inherited decoder. A separate shifted-dyadic encoding theorem provides an exact all-code transport while keeping the numerical domination side condition distinct.

The packet also preserves a clear-and-pop obstruction, exact refill-deletion counterexample, source permutation receipts and scoped physical allocation results. Failed local filters and frozen-row allocations are not lower bounds on Turing-machine size.

## Offline verification

Use Python 3.10 or newer with the standard library, with assertions enabled. No network, repository checkout, solver or proof assistant is required for the supplied replay.

```bash
python3 -I verify.py --work /tmp/st215-rho6-finite
python3 -I verify.py --runtime --research --work /tmp/st215-rho6-full
```

The work directory must be new and outside the packet. Omitting `--work` creates a temporary directory and prints its location. Verification does not modify the packet.

The default command checks the manifest, extracts and checks the exact parent, reconstructs the source/table changes, replays the complete blank prefix and source bridge, verifies source metrics and control flow, checks the dense presentation and generated transition appendix, verifies the 3,728-node logical certificate, audits all saved runtime cases and rederives the four block schemas, and compares the 128 tables. It writes `FINITE_REPLAY_PASS`.

`--runtime` additionally rederives all 6,151 arbitrary-natural primitive cases and compares every resulting record with the saved evidence. `--research` also checks source metrics and control flow, the finite matrix, NIP valuation, dyadic arithmetic and the rejected refill deletion. Full preparation replay took a few minutes; runtime is not guaranteed. It writes `FULL_REPLAY_PASS`.

The executable checks do not by themselves reprove the complete native-calculus-to-ZFC comparison or every inherited arithmetic macro. The report identifies those mathematical dependencies and gives the new transfer proofs explicitly. The finite logical certificate concerns dominated-to-unrestricted propositional recovery only.

## Files

| Path | Content |
|---|---|
| `machine/ST215-Rho6.native.tm` | Exact sparse-label table; start 0, dispatcher 84, halt 254 |
| `machine/ST215-Rho6.tm` | Exact dense table; states 0–214, start 0, dispatcher 23, halt 215 |
| `machine/canonicalization.json` | Full native/dense bijection |
| `source/sites.json` | Exact 4,732 source occurrences |
| `evidence/runtime.json`, `runtime_cases.json.gz` | All universal cases and exact input/helper hashes |
| `evidence/bootstrap.json`, `independent_audit.json` | Complete startup frame and independently replayed audit |
| `checks/` | Portable verification modules |
| `proofs/` | Complete supplementary arguments and independent reviews |
| `research/` | New source designs, finite model, corroborators, negative controls and search records |
| `comparison/` | Inert comparison tables and original provenance |
| `reference/ST215_Direct_Transfer_2026-10-21.zip` | Unchanged direct parent, with all inherited dependencies |
| `licenses/`, `NOTICE.md` | Preserved licenses and attribution |

Search receipts preserve original execution paths as provenance strings. They do not require those paths for the portable verification. Some exploratory summaries are not complete replays of every search; they are labeled accordingly. The parent ZIP is intentionally preserved unchanged, including its own older provenance and records.

## Exact identity and provenance

Native table SHA-256:

```text
fac930e9bc89fed41b631de2f12ef4e48e1c8625ef31ef093d4f14b340f113ad
```

Dense table SHA-256:

```text
24956a9a07d41ca20ebcd7ac20d90a88a6da3bca24d7859b6f22f5b8f4215ef9
```

Source SHA-256:

```text
74d21758da7e932de766bee079adf11a7917c03a1957b1111abc6463d70eb332
```

Inspected ProveIt snapshot: [`34b63b3b197b0a5f285a229d91bc163fcc42ab93`](https://github.com/VladimirReshetnikov/ProveIt/tree/34b63b3b197b0a5f285a229d91bc163fcc42ab93/Computability/BusyBeaver/Research/ZFC/). The parent packet has its own earlier pins and authorship notices, which remain intact.

## Rebuild the PDF

With a standard TeX Live installation:

```bash
python3 -I checks/presentation.py --write
cd report
pdflatex -halt-on-error ZFC_ST215_Rho6_and_New_Routes.tex
pdflatex -halt-on-error ZFC_ST215_Rho6_and_New_Routes.tex
```

The transition appendix is generated directly from the dense table. Rebuilding a PDF under a different TeX environment may change its bytes and therefore its manifest hash; do not silently replace the frozen manifest when verifying the distributed packet.
