# The Quadratic Barrier in Arithmetic-Progression Counting

**All lengths, prime cyclic groups, and circuit-partition asymptotics**  
Research manuscript prepared for Vladimir Reshetnikov, 7 October 2026.

## Main result

For every fixed progression length `k >= 3` and target density `0 < delta < 1`,
there are actual indicator sets in every sufficiently large prime cyclic group
whose balanced `U^(k-1)` norm tends to zero but whose progression-count discrepancy
is asymptotic to a nonzero constant times the square of that norm. Either sign
of the discrepancy is possible. The sets have exactly `floor(delta * Q)` points.

Consequently, the uniform quadratic counting error cannot be replaced by
`o(u^2)` or by `O(u^(2+epsilon))` for any positive epsilon, even on prime cyclic
groups. The same construction works on powers of any fixed prime field with
characteristic larger than the progression length.

This resolves the two sharpness extensions left unclaimed in ProveIt's source 20,
*Quadratic Counting Errors and Sharp Directional Bounds in Gowers's Szemerédi
Argument*: lengths at least four, and prime cyclic groups. Source 20 had a
three-term example over powers of F29.

The manuscript also gives a general first-dependent-subset partition formula,
explicit leading constants, a divisor-sum improvement to the attainable cyclic
coefficient, and a sequence that works simultaneously for every **fixed**
progression length and norm order.

## What the result does not claim

- No new global upper or lower bound for `r_k(N)` is claimed.
- The all-length quasipolynomial bound in the OpenAI repository is reviewed as
  a source claim, not independently certified or used as a theorem here.
- The proposed results have written proofs, not new Lean kernel verification.
- The constants attained by these examples are not claimed to be globally optimal.
- Worldwide priority for every formulation has not been established. The specific
  advancement relative to the identified ProveIt source is explicit.

The manuscript was developed with ChatGPT and should undergo independent
mathematical review before being integrated as an established research result.

## Contents

| File | Purpose |
| --- | --- |
| `article.pdf` | Complete research manuscript |
| `article.tex` | Self-contained LaTeX source, including bibliography |
| `Makefile` | PDF build and verification commands |
| `verification/verify.py` | Exact finite checks; optional high-precision checks |
| `data/verification.json` | Recorded successful verification output |
| `INTEGRATION.md` | Suggested repository placement and formalization modules |
| `THEOREM_STATUS.md` | Statement-by-statement proof and validation status |
| `sources.json` | Pinned repositories, inspected paths, and review scope |
| `BUILD_STATUS.json` | PDF build, rendering, and rerun status |
| `requirements-numerical.txt` | Versions used by the optional numerical suite |
| `SHA256SUMS.txt` | Checksums for package files other than this checksum file |

No external image assets, font files, or bibliography database are needed to
compile the article. Fonts in the PDF are standard TeX-embedded fonts.

## Build the PDF

A conventional TeX Live installation containing `latexmk`, `pdflatex`, Latin
Modern, AMS packages, `microtype`, `geometry`, `hyperref`, `xurl`, `fancyhdr`,
`booktabs`, and `enumitem` is sufficient:

```sh
make pdf
```

Without latexmk:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

## Reproduce the checks

Python's standard library is sufficient for the default suite:

```sh
make check
# or:
python3 verification/verify.py
```

The recorded suite passed **8,916 exact checks** covering cube ranks, local
moments, progression triples, and signed-radix arithmetic. It also computes the
circuit-partition constants `P_2 = 1`, `P_3 = 6`, `P_4 = 635` by an exact recurrence.

The optional numerical suite requires NumPy and mpmath:

```sh
python3 -m pip install -r requirements-numerical.txt
make numerical
```

It uses 90 decimal digits and finite characteristic-function sums, not Monte
Carlo, to check the predicted asymptotics at `n = 16, 64, 256, 1024, 4096`.
The output goes to `data/verification-rerun.json`, preserving the original record.
These are high-precision sanity checks, not interval-certified computations.

The recorded environment used Python 3.13.5, NumPy 2.3.5, and mpmath 1.3.0.
The scripts are written for Python 3.10 or newer; that wider version range has
not been exhaustively tested.

## Proof route

1. Binary cube slots have no three-point affine dependencies; their four-point
   dependencies are exactly parallelograms.
2. A centered sine of a normalized sum of independent coordinate observables
   admits a finite cumulant expansion. Exact centering kills every term that
   misses a slot. The leading all-slot terms are partitions into first dependencies.
3. Progression triples give discrepancy of order `n^(-1/2)`. Cube circuit
   partitions give `U^d` norms of order `n^(-1/4)` for every fixed `d >= 2`.
4. A bounded-Fourier signed-radix map preserves the required torus moments in
   prime cyclic groups. Explicit Taylor truncation gives
   `n ~ log(Q) / log(log(Q))` for each fixed list of systems.
5. Independent rounding plus a cardinality adjustment yields genuine sets without
   disturbing the leading terms.

## Integration

Suggested new directory:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/quadratic-barrier/
```

Alternatively, include the manuscript as a new source in the existing
`local-quantitative-refinements` report. Do not silently upgrade any formalization
ledger or mark a proposed Lean interface as proved. See `INTEGRATION.md`.

This package does not modify either repository. The repository snapshots and
source claims used in the review are pinned in `sources.json`.
