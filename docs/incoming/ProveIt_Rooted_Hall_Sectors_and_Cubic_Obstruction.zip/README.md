# Rooted Lorentzian Hall Sectors and an Unrooted Cubic Obstruction

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October2026.

Read **article.pdf** for the theorem, exact graph and proof. **article.tex** is the source.

## The two results

For a genuine a+q bipartite cover, forcing every right-core vertex and any matchable q−2 exterior-left vertices leaves a degree-a Lorentzian exterior-right marginal. All activities on both shores may be positive real numbers. The proof explicitly uses the established weighted Hall-slack kernel compression and rank-two exterior-block matrix lift; the intermediate object need not be an ordinary graph.

Removing the roots does not preserve that conclusion. A connected25-vertex rank-six graph with unit left activities and a unique3+3 minimum cover has an all-right-core cubic that fails both ULC3 inequalities. Its shifted ULC6 inequalities remain positive. Its full polynomial is strictly ULC6 for every common right-core activity, with the other activities fixed as displayed.

This is not a counterexample to rank-six ULC. The general finite-activity rank-six one-shore problem remains open. No minimum-vertex or global-priority claim is made.

## Reproduce all checks

Python3 with the standard library suffices:

```sh
python3 code/verify_base_dynamic.py
python3 code/verify_connected.py
python3 code/verify_common_field.py
python3 code/verify_rooted_hessians.py
python3 code/independent_full_field.py
```

- The base checker uses endpoint-state dynamic enumeration on the24-vertex predecessor
- The connected checker uses an independent Hall-subset test, verifies every hybrid coefficient, exact negative ULC3 gaps, positive shifted ULC6 gaps, connectedness and the unique minimum cover through all2048 left masks
- The common-field checker rebuilds all seven full coefficient polynomials and verifies the three positive quadratic certificates and remaining nonnegative coefficients
- The separate full-field reconstruction uses actual endpoint subsets and dynamic matching states, independently checking the full coefficient table and all Newton polynomials
- The rooted checker directly enumerates the rooted marginal and verifies all12 quadratic derivative Hessians by exact rational Schur elimination, along with the two positive scalar ULC3 gaps

Every script raises an explicit exception on failure and writes a JSON summary beside its source. Reference results are in **data/**. No numerical optimizer or nonstandard library is required.

The normalized cubic in the main counterexample is five times the actual conditioned cubic; the factor is explicitly recorded. This positive scaling preserves all sign conclusions.

## Build and integrity

Compile **article.tex** twice with pdflatex. The source names its required LaTeX packages. **build_local.sh** supplies the TeX paths used in preparation and writes temporary files under **build/**.

Run `sha256sum -c SHA256SUMS` to verify all shipped files. The package excludes exploratory searches, superseded larger witnesses and raw internal review correspondence.
