POLISH PRESBURGER ARITHMETIC BEYOND THE SPLIT CONSTRUCTION
Nonsplit models, exact continuity, and optimal computation from streams

Research report prepared with ChatGPT — 4 October 2026

CONTENTS

article.pdf                 Complete research article, including proofs,
                            nine further research questions, and references.
article.tex                 Standalone LaTeX source of the complete article.
Makefile                    Optional local build and diagnostic commands.
verify.py                   Exact finite diagnostic program.
verification_results.json   Actual output of the diagnostic program.
provenance.json             Source identities and contribution-status ledger.

READING GUIDE

Sections 1–2 establish the research intersection and arithmetic models.
Sections 3–6 develop nonsplit Polish examples, automatic topological
splitting, and applications of the repository's existing omnific criterion.
Sections 7–9 give the exact continuity and target-valued Baire classifications.
Section 10 proves the rank bound and exact optimal truth-revision theorem,
and explains why arbitrary fixed parameters obstruct uniform optimization.
Section 11 proves the complete-metric obstruction.
Sections 12–13 discuss consequences, formalization, and further questions.
Appendices A–B provide the source audit and reproduction information.

RESEARCH STATUS

The initial affirmative construction answering Glazer's Question 2 was
already present in the inspected ProveIt incoming manuscripts. The general
omnific embedding criterion and nonsplit countable-core family also have
explicit prior counterparts in the repository. These are credited in the
article and are not claimed as new here.

The article develops additional results with conventional mathematical
proofs. It does not claim independently established global priority,
refereeing, or new Lean/Rocq kernel verification. The diagnostic program
does not implement the entire continuity compiler or certify infinitary
theorems. The proof and computation boundaries are stated in the article.

BUILD THE PDF

A LaTeX installation with the packages named in article.tex is required,
including lmodern, microtype, xurl, hyperref, and cleveref. No external
figures, bibliography database, repository checkout, or network connection
is needed. From this directory, run:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

The repeated passes resolve the table of contents, references, and links.
Alternatively, run "make pdf" or use latexmk -pdf article.tex.

REPRODUCIBLE FINITE DIAGNOSTICS

The accompanying article contains the mathematical arguments. This directory
also contains verify.py and its actual output verification_results.json.
The script uses Python 3.9 or later and only the Python standard library.

Run from any directory:

    python3 /path/to/polish_presburger_frontiers/verify.py

The script writes verification_results.json beside itself. All checks use
exact fractions; there is no floating-point tolerance, random sampling,
network dependency, or execution of code from previous research archives.
Its explicit require() checks remain active under python -O.

WHAT IS CHECKED

1. Rational local sign feasibility.
   Exact Fourier–Motzkin elimination checks homogeneous rational equalities,
   weak inequalities, and strict inequalities. A common positive scaling
   converts homogeneous strict positive requirements to quantities >= 1.
   The implementation does not apply this transformation to inhomogeneous
   strict systems. It checks both accessible monus branches on the zero
   face, inconsistent dependent signs, and other named cases. All 81 sign
   profiles of x, y, x-y, x+y are compared with an independent small-grid
   witness enumeration, which realizes the arrangement's 17 possible
   profiles (eight open sectors, eight rays, and the origin).

2. The nonsplit rational group.
   For K = Z_(2) x Z[1/2], with unit (1,1) and lexicographic order by
   (v-u,u), exact CRT residues are used to compute quotient and remainder
   by positive standard integers. The script checks rational membership,
   remainder range, both division identities, preservation of the positive
   cone, and uniqueness by a separate exhaustive scan of all candidate
   remainders on every tested instance. It also checks a finite range of
   divisibility powers for the adjacent positive witnesses (-1,0) and (0,1).

3. Rank-controlled streamed truth.
   An example with 34 affine tests and coefficient rank two changes truth
   exactly twice. XOR examples in dimensions one through eight change
   truth exactly as many times as their dimension. Exact Gaussian
   elimination verifies that every observed truth change occurs at an
   increase of restricted coordinate-row rank. Prefix length s means
   coordinates 0,...,s-1 have been read. All secondary integer coordinates
   in these diagnostics are zero.

4. Exact finite alternation examples.
   Dynamic programming on the subset lattice of resolved nonzero coordinate
   signs computes the largest number of truth-label alternations. For
   dimensions one through eight, parity has height equal to the dimension,
   whereas the conjunction that every stream is zero has height one. This
   is an exact calculation in these finite sign posets, and illustrates why
   coefficient rank is an upper bound which need not be the formula's exact
   truth-alternation complexity.

LIMIT OF THESE CHECKS

Finite checks cannot prove the general model characterization, nonsplitting,
the full continuity compiler, the infinitary Baire statements, the optimal
rank theorem, or the metric obstruction. They provide reproducible tests of
finite algorithms and examples used in the proofs. No new Lean or Rocq
kernel certification is asserted by the presence of these files.
