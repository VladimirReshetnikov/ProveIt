# Report 145

## Pointwise corrections for the proportional placement game

The report proves the expansion

W_n / (A sqrt(n) r_*^n) = 1 + 1/(4n) - (7/540) log(n)/n^2 + B_2/n^2 + o(n^-2),

where A = r_* sqrt(2 pi), and B_2 is given by absolutely convergent series.
It also proves eventual strict decrease of consecutive ratios, an obstruction
to a pure-power ratio expansion through n^-3, and a refined Lambert-W inverse
with o(x_0^-2) uncertainty before integer rounding.

The proof does not establish all-index ratio monotonicity, a full expansion,
effective correction errors, or certified decimal values of B_2 or new digits
of r_*. Its criticism of the inspected Richardson premise does not assert
that the numerically extrapolated digits are wrong.

## Contents

- `Report145.pdf`: the 21-page article
- `Report145.tex`: editable LaTeX source
- `companion/`: a new exact-algebra verifier, typed fixture, adversarial tests,
  and deterministic receipts
- `foundation/Report144.pdf` and `.tex`: unchanged proofs of the leading law
  and first uniform kernel bounds used in this article
- `build_pdf.py`: deterministic clean TeX build
- `build_archive.py`: deterministic allowlisted archive creation
- `toolchain.json`: reproduction tool versions
- `SHA256SUMS`: hashes of all other archive members

No primary copyrighted manuscript PDF, prior computational archive, private
research notes, or development intermediates are included.

## Verify the archive

From the extracted `Report145` directory:

```sh
sha256sum -c SHA256SUMS
```

## Run the exact companion

Python 3.9 or later and its standard library suffice. No network, floating-point
recurrence approximation, or external Python package is used.

```sh
python3 -I companion/checks.py
python3 -I -O companion/checks.py
python3 -I companion/test_checks.py
python3 -I -O companion/test_checks.py
```

The isolated normal and optimized suites each pass 1,142 cases, including
80 semantic mutations, 1,044 structural rejections, 12 output-guard cases,
four CLI cases, and two positive cases. Normal and optimized exact algebra
receipts are identical. See `companion/README.md` for the mathematical scope,
analytic inputs, JSON schema policy, and optional receipt-output commands.

These finite exact checks validate algebra and parsing behavior. They do not
certify the analytic asymptotic theorem, uniform remainder estimates, decimal
values of the constants, an effective onset, or an integer threshold.

## Rebuild the PDF

The reference build uses the TeX Live 2025/dev Debian installation in
`toolchain.json`, including pdfTeX, LaTeX, Latin Modern, AMS packages,
geometry, microtype, booktabs, and hyperref. The script deliberately uses the
Debian TeX resource directories recorded in its source. It needs `pdftex` and
`pdflatex` on PATH and installed font maps; it never downloads packages.

```sh
python3 -I build_pdf.py --output-dir rebuilt-one
python3 -I build_pdf.py --output-dir rebuilt-two
cmp rebuilt-one/Report145.pdf rebuilt-two/Report145.pdf
cmp Report145.pdf rebuilt-one/Report145.pdf
```

Both output directories must be new, with existing nonsymlink parents.
The script creates a clean local HOME and TeX configuration, generates its
own format, disables shell escape, fixes time/locale, and runs until references
stabilize. It fails if any LaTeX warning or overfull/underfull box remains.
It does not overwrite the distributed PDF or modify the foundation files.
Reproduction on a materially different TeX/font version can change PDF bytes
without changing the mathematical content.

For visual inspection with Poppler:

```sh
pdftoppm -png rebuilt-one/Report145.pdf rendered-page
```

Every page of the delivered PDF was rendered and inspected for clipping,
legibility, spacing, page numbers, and equation/reference layout.

## Rebuild the ZIP

From the extracted directory, write to a new path:

```sh
python3 -I build_archive.py --output rebuilt-Report145.zip
```

The new ZIP may be written inside the extracted directory: its filename is
not in the fixed allowlist, so it is excluded from the archive. The builder
includes only its fixed list of 15 payload files, then generates
`SHA256SUMS`. It fixes path order, timestamps (2026-10-03 00:00:00), Unix
permissions, and ZIP_STORED compression, and refuses existing targets or
symlink output parents. Archive regeneration from unchanged extracted files
reproduces the distributed ZIP byte-for-byte. The ZIP itself is not included
in its own manifest. The foundation source and PDF are archival dependencies;
only the new Report145 PDF is rebuilt by `build_pdf.py`.
