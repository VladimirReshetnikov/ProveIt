SHARP GUMBEL ERRORS AND OPTIMAL CONTINUOUS CALIBRATION
FOR RANDOM ASSEMBLIES

Research manuscript prepared for Vladimir Reshetnikov
8 October 2026

PURPOSE
-------
This package develops quantitative largest-component asymptotics for
random assemblies whose nonnegative component weights satisfy

    p_k = c + O(1/k), c > 0.

Its main application is the uniform nested-cycle partition counted by
OEIS A308338. Its largest outer component is different from the longest
individual cycle. A second application is a labelled forest of paths.

The principal results are complete conventional proofs of:

  1. A sharp ordinary Gumbel error of order (log n)^2 / sqrt(n),
     including its signed profile and exact leading constant.
  2. A positive minimax constant showing that affine centering and
     scaling cannot remove that order of error.
  3. An explicit increasing nonlinear calibration with error
     tau/(2e) + O(tau/L), asymptotically optimal among ALL continuous
     distribution functions. Here tau is the exact saddle and
     L = log(c/tau).
  4. A lattice formula with uniform error O(tau/L), and, under
     p_k = c + a_*/k + O(log(k+1)/k^2), an exponential-integral
     correction with error O(tau^(3/2) L^3).
  5. Integer quantiles with bounded error and an explicit two-term
     saddle for nested-cycle partitions.

RESEARCH STATUS
---------------
The first-order Gumbel limits and the component coefficient asymptotics
are prior work and are credited in the article. The quantitative
refinements are proposed new contributions, with complete proofs in
this manuscript. A directed literature audit did not identify these
particular formulas, but it does not establish worldwide priority.

This is an AI-assisted, unrefereed manuscript. Separate agent derivations
and mathematical audits were used during preparation. These checks are
not human peer review, and there is no Lean, Rocq, or other formal proof
certificate. The calculations check finite arithmetic and numerical
coefficient ratios; the mathematical proof does not depend on their
agreement. PROVENANCE.txt records sources and repository snapshots.

No repository files were changed remotely and no pull request was
created. The package is ready for the requested later integration.

CONTENTS
--------
article.pdf                 Complete article, proofs, references, figures.
article.tex                 Master LaTeX source.
sections_fourier.tex        Common Fourier estimate and paired difference.
sections_optimal.tex        Atoms, continuous minimax result, quantiles.
numerical_tables.tex        Tables generated from the retained CSV files.
references.bib              Bibliography, including repository provenance.
Makefile                    Short build targets.
requirements.txt            Python dependency versions used for the results.
PROVENANCE.txt              Prior-work comparison and source identifiers.
VERIFICATION.txt            Verification record and its scope.
MANIFEST.sha256             SHA-256 hashes of every other packaged file.

code/nested_numerics.py     Exact counts, rational checks, numerical CDFs.
code/forest_numerics.py     Independent rational-EGF Fourier calculation.
code/make_figures.py        Regenerate figures and TeX tables from CSV data.

data/nested_errors.csv      Numerical errors for n = 10^3, 10^4, 10^5.
data/nested_profile.csv     Lattice-point error profiles for n = 10^5.
data/verification.json      Exact fractions and nested-cycle check results.
data/forest_errors.csv      Path-forest runs, n = 10^4 through 10^12.
data/forest_verification.txt
                           Log of quadrature and coefficient checks.

figures/error_profiles.pdf, .png
figures/forest_convergence.pdf, .png
                           Vector publication figures and raster previews.

BUILD THE ARTICLE
-----------------
From the package directory, with a standard TeX Live installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

The bibliography uses BibTeX. latexmk invokes it as needed. All figures
and generated tables are already included, so no Python execution or
network access is needed just to compile the paper.

The Makefile provides:

    make paper       Compile the included article.
    make figures     Rebuild plots and tables from the included CSV files.
    make numerics    Rerun both numerical experiments and their checks.
    make all         Rerun calculations, regenerate figures, compile.
    make clean       Remove ordinary TeX auxiliary files, retaining the PDF.

REPRODUCE THE NUMERICAL RESULTS
------------------------------
Python 3.12.14 was used; the scripts require Python >= 3.10.
The tested NumPy, SciPy, and Matplotlib versions are pinned in
requirements.txt. To reproduce in an environment containing them:

    python3 code/nested_numerics.py
    python3 code/forest_numerics.py --recurrence-check
    python3 code/make_figures.py

If dependencies need installation:

    python3 -m pip install -r requirements.txt

The default nested-cycle calculation forms finite-product coefficients
through degree 18,992 and uses ordinary double precision for its larger
Fourier integrations. Exact integer and rational arithmetic is used in
the separate small-size checks. The path-forest script uses a rational
component generating function and also checks a sparse coefficient
recurrence using 60-digit decimal arithmetic.

Continuous CDF error comparisons examine both ends of each sampled
lattice step. For the largest path-forest sizes, threshold sampling is
used; the recorded maxima are not certified global suprema. Changing
quadrature node counts is a numerical convergence check, not a rigorous
roundoff bound. Read VERIFICATION.txt and the article for details.

INTEGRATION INTO PROVEIT
-----------------------
The existing background report inspected for this work is:

  SetTheory/Cardinals/docs/reports/
  generating-functions-and-asymptotics/oeis-sequence-asymptotics/
  a308338-nested-cycle-assemblies/article.tex

Suggested location for this complete directory, as a separate report:

  SetTheory/Cardinals/docs/reports/
  generating-functions-and-asymptotics/oeis-sequence-asymptotics/
  a308338-sharp-largest-components/

The source uses only relative paths, so moving the directory does not
require path edits. A repository index entry can link article.pdf and
article.tex. The prior nested-cycle report remains a separately credited
source. The proofs here concern largest component size; the existing
report primarily studies enumeration and component-count fluctuations.

Theorem labels provide stable integration targets:

  thm:tailmoment       Uniform paired-Fourier tail-moment approximation.
  thm:lattice          Explicit universal lattice law.
  prop:kappa           Sharp ordinary Gumbel constant.
  thm:affine           Best affine normalization and positive obstruction.
  thm:atom             Largest atom and exact continuous minimax identity.
  thm:optimal          Explicit optimal continuous calibration.
  cor:central-quantiles
                      Integer quantiles with bounded error.
  thm:e1               Component-sensitive exponential-integral correction.
  cor:nested           Sharp error scales for nested-cycle maxima.
  prop:explicit-saddle
                      Two-term elementary saddle.

The final research section proposes eleven concrete directions,
including a next continuous-error term, higher Fourier corrections,
the affine minimax constant, joint upper order statistics, general
expansive weights, arithmetic supports, explicit finite constants,
periodic component corrections, moving quantiles, and formalization.
