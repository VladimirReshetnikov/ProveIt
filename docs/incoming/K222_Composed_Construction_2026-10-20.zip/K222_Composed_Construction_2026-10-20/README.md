# K222: a composed binary consistency machine

This packet constructs an explicit **222-state, two-symbol, one-tape Turing machine** whose blank-tape non-halting is provably equivalent in ZFC to `Con(ZFC)` by the ordinary mathematical argument in the report. It improves the three 223-state candidates inspected in the pinned ProveIt snapshot.

The new construction combines the equality/helper merger from the incoming G223 packet with the repeated witness-request presentation from the incoming Seed223 packet. The equality change preserves the entire native theorem set; the seed presentation inherits its finite-proof consistency reductions to ZFC. The source is compiled against G223's compatible decoder contexts.

**No new end-to-end Rocq or Lean theorem for these 222-state bytes was compiled.** The report explains the inherited set-theoretic calibration and the exact remaining kernel integration. The source, logic, decoder, complete initialization and unbounded runtime certificates are included and reproducible offline.

## Start here

- `report/main.pdf`: complete mathematical report, proof boundaries and all 444 transition rows.
- `portable/machine/candidate222.tm`: authoritative canonical machine.
- `portable/reproduce.py`: fresh offline replay of the new construction and proofs.
- `portable/machine/binary_delta222.json`: deletion and exact 24 retained-row changes.
- `portable/theory/seed_g_proofs.json`: combined 318-node finite proof DAG.
- `PROVENANCE.json` and `NOTICE.md`: exact inputs, attribution and license scope.

## Exact machine

| Property | Value |
|---|---|
| Working states | 0 through 221 |
| Initial state / head | 0 / integer position 0 |
| Separate terminal | 222, with no outgoing transitions |
| Tape and alphabet | One two-way infinite tape; symbols 0 and 1 |
| Initial tape | All zeros |
| Transitions | 444; each writes a bit and moves one cell L or R |
| Canonical dispatcher | 22 |
| Preloaded data | None; initialization is included in the 222 states |

Each row is `state read write direction next_state`; `#! start 0` declares the initial state. Entering the unique terminal state halts.

Canonical SHA-256:

```text
01fb8d9813824ebf67b0f8b7f420c7719ae83d21217fde16eae7ab6c78ec2e26
```

The historical K-label table is the same machine under the explicit bijection in `canonical_map.json`. Its labels above 222 do not represent extra states. It starts at K0, dispatches at K84, and uses K254 as terminal.

## What saves the state

Let `d_ab = Eq(a,b)`, `Q_i` be the native universal constructor, and `kappa(a,b) = RelCode(a,b) = 4*P(a,b)+1`. The old equality row and its separate helper are replaced by

```text
G(a,b,c) = d_ca -> (d_cb -> Q_kappa(a,b) d_ab).
```

The helper is then removed from the seed bundle. Writing `T = Q(c,I(H,N(W)))`, its exact numerical expression changes from

```text
B  = N(I(V,I(E_helper,T)))
```

to

```text
B' = N(I(V,T)).
```

The repeated request `W`, the hereditary closure `H`, membership vacuity `V`, native private-code convention and bundle gate remain as in the seed source. The report proves that G recovers reflexivity, the exact helper and the literal old equality row without circular premises or generalization under open assumptions. Three additional tautology roots handle the seed bundle's actual grouping.

The resulting source has **4,744 primitive occurrences, 208 distinct subtrees and 185 distinct interior subtrees**. A closed right rotation restores maximum zero run 6 without changing the primitive instruction word or guarded control-flow graph. Maximum address depth is 36.

The final count is

```text
49 engine states + 185 interior decoder roles - 12 shared roles = 222.
```

Relative to G223, the machine deletes **K305**, adds no states and changes **24 retained transition rows**. All **49 engine states and their 98 rows remain exactly unchanged**. The deleted state had represented a unique 125-instruction subtree; the combined source no longer requires it.

## Verification completed

| Layer | Result |
|---|---|
| Exact source/emitter | Nine all-register macro bisimulations; symbolic arithmetic expressions for all natural parameters |
| Independent formula audit | Four old/new row and bundle ASTs; uniform decoder side conditions |
| Native logic | 318 proof nodes, 293 formulas, 36 roots; independent checker and truth-table tautology checks |
| Source structure | Complete guarded graphs agree under two independent resolvers; independent 15-factor closed reference |
| Decoder | 4,743 interior prefix occurrences; all 4,742 compound edges reach intended subtrees without changing their prefixes |
| Literal table | 222 graph-reachable states; 444 complete binary rows; canonical bijection verified |
| Blank startup | Exact complete tape after 409,835 transitions; 351 one-cells; no earlier halt |
| Unbounded final runtime | **6,167 of 6,167** guarded cases; **444 of 444** rows; **1,488,930** symbolic rule applications |
| Progress | Every instruction has positive finite duration; minimum constant term is 13 steps |
| Fresh packaged replay | `FULL_K222_REPLAY_PASS`; rebuilt source, machine, logic and every runtime case match the frozen artifacts |
| Printed PDF appendix | All 222 printed state rows and 444 actions independently extracted and matched to the canonical table |

The runtime proof quantifies over nine independent natural registers, arbitrary natural extra gap and first spare value, and an arbitrary finite remaining spare list. Its 4,000-rule proof-construction fuel is not a bound on concrete register values, list length or running time. The four arbitrary-list traversal schemas are rederived from the exact final table.

The verified startup frame has canonical dispatcher state 22, head -5, logical registers `(3,0,0,0,3,0,0,0,0)`, extra gap 117, and 167 spare blocks each encoding one. The receipt records the full finite support of the tape. This endpoint need not be the first dispatcher visit during initialization.

## Offline reproduction

Use Python 3.10 or later with assertions enabled. From this packet's top directory, choose an initially empty output directory outside the packet:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k222-replay
```

The default freshly reconstructs the source and table, regenerates and independently checks the logical certificate, checks the native expression interface, executes complete blank initialization and rederives all final runtime cases. It compares regenerated source/table/case bytes with the frozen artifacts and returns `FULL_K222_REPLAY_PASS`.

Both original 223-state predecessor ZIPs are preserved unchanged. The default checks their exact hashes and uses their pinned sources and proof components; it does not rerun every ancestral runtime or compile a proof assistant. The optional `--replay-parents` mode invokes the unchanged parent drivers with their documented scopes. See the receipt for exactly which phases ran.

To compile the report and regenerate its transition appendix:

```sh
python3 -B report/build_report.py --output-dir /tmp/k222-report
```

This requires a standard pdfLaTeX installation. The already compiled PDF is included. PDF metadata can differ between builds; the machine/source hashes are fixed.

## Incorporation and research limits

The packet is self-contained and intended for incorporation as a new candidate, such as `candidate-composed222`, without overwriting older candidates. No repository push is part of this packet. Retain `portable/manifest.json`, its exact inputs, the notices and original vendor archives together.

The report distinguishes native theorem-set equivalence, ordinary-theory equiconsistency, source-program semantics, exact binary simulation and proof-assistant integration. It includes the measured EqCode-binder alternative and the scope of the local fold searches. No minimality, global priority or completed 221-state construction is claimed.
