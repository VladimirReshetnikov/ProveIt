# Report58

## Explicit Diophantine certificate for five-signal infinite validity

4 October 2026 UTC

`Report58.pdf` is the readable report. `Report58.tex` is its complete editable LaTeX source. The report supplies an explicit positive-integer existential polynomial certificate for the actual infinite complete-macro validity predicate of the fixed five-live-signal machine audited in Report57.

### Main results

| Source | Ordinary positive inputs | Positive witnesses | Equations | Multiplications | Additions | Subtractions | Binary gates | Exact degree | Expanded terms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Native linear | 3 | 81 | 44 | 136 | 110 | 98 | 344 | 12 | 772 |
| Paid one-input linear | 1 | 85 | 46 | 144 | 118 | 105 | 367 | 12 | 802 |
| Native quartic, optional | 3 | 80 | 44 | 139 | 109 | 102 | 350 | 12 | 775 |
| Paid one-input quartic, optional | 1 | 84 | 46 | 147 | 117 | 109 | 373 | 12 | 805 |

The primary native polynomial is the sum of squares of 14 outer residuals and two fully displayed 15-equation POWER systems. All natural/signed-to-positive adapters are charged. The one-input version uses the fully paid nested Cantor decoder; it represents the transported predicate on every positive code, with no separate validity promise. The optional quartic version saves one witness and costs six more gates. No optimality claim is made.

The exact degree-twelve homogeneous component is

`power5.w^8 * power5.g^4 + power_complex.w^8 * power_complex.g^4`.

The report proves primitive joint denominator recovery, Bézout soundness and completeness, exact 5-adic valuation, bounded Gaussian remainder extraction, both directions of the final validity equivalence, all positive-domain specializations of the two constructive Pell theorems, and exponent zero. It includes the optional elementary impossibility of a finite univariate polynomial-sign classifier for the paid encoding. That finite-sign obstruction is compatible with the explicit existential integer representation.

## Package layout

- `Report58.pdf`, `Report58.tex`: final report and editable source
- `science/`: the full 33-file frozen arithmetic science packet, including all four inert DAGs, the original proof, source pins, author receipts, and exact inherited physical and Pell dependencies
- `independent_audit/`: the full 11-file frozen root independent audit, with mathematical reviews, three independent checker sources, exact receipts, and twelve complete positive exponent-zero witness assignments
- `portable_replay/`: authenticated portable replay adapter, tests, independent portability review, and pin manifests
- `tools/`: new release-only build, full-inventory verification, deterministic ZIP, and fixture guard-test tools
- `verification/`: release-copy replay receipt, rendering and build evidence, final page inventory, and release-tool test results
- `manuscript_review/`: independent final-manuscript review evidence
- `MANIFEST.json`: exact complete release file and directory inventory, excluding the manifest itself

No original scientific file was rewritten. The original absolute paths visible in frozen receipts are historical provenance. The portable replay does not require access to those original paths.

## Verify the delivered release

From any working directory, using the actual absolute release path:

```sh
python3 -I -S -B /absolute/path/Report58/tools/release.py verify
```

This checks exact file bytes, sizes, the complete directory inventory, and canonical manifest serialization. Added or missing files/directories, symlinks, hard links, nonregular entries, or changed bytes fail verification. SHA-256 is an integrity mechanism, not an external digital signature.

The `seal` action is for the release producer and creates the manifest exactly once. Do not reseal a changed packet to make a failed verification appear successful. The authoritative external release hash identifies the delivered manifest/ZIP.

## Replay the independent mathematical source and arithmetic checks

This needs CPython 3.9 or newer on a POSIX filesystem and no third-party Python packages. The tested interpreter is CPython 3.12.14 on Linux.

```sh
python3 -I -S -B /absolute/path/Report58/portable_replay/replay_report58.py \
  --packet-dir /absolute/path/Report58/science \
  --audit-dir /absolute/path/Report58/independent_audit \
  --output-dir /absolute/path/new-external-replay
```

All paths must be explicit canonical absolute paths without symlink components. The output must not exist; its parent must exist. Keep outputs outside the release so its sealed inventory stays pristine.

The adapter authenticates the complete science/audit file inventories, runs only three pinned independent checkers with unchanged source bytes, and compares all four regenerated JSON receipt/witness files and the arithmetic stdout byte-for-byte with the frozen references. Assertions stay enabled. Python optimization, nonisolated startup, source alteration, unexpected inventory entries, and unsafe paths are refused. The release-copy replay passed; see `verification/REPLAY_RECEIPT.json`.

Read `portable_replay/REPLAY_README.md` for the exact logical-path adapter, 33-case portability test, read-only input preservation, and limits. In particular, the historical external physical-audit lookup is redirected to the already authenticated included copy. Replay therefore depends on its frozen hash and the original root audit's established identity; it does not perform a fresh physical-proof audit or remote dependency authentication.

Only these scientific checker sources are executed by portable replay:

- `independent_audit/audit_exact_source.py`
- `independent_audit/check_power_dag_independent.py`
- `independent_audit/audit_arithmetic.py`

The author emitter, author semantic checker, author internal source checker, source-freezing program, prior saved code, physical simulator, trajectory replay, and Lean are never executed by the replay or release tools. Their presence in `science/` is inert archival provenance.

## Clean PDF rebuild

The supported build profile is Linux with the installed system TeX tree under `/usr/share/texlive/texmf-dist` and `/usr/share/texmf`, PDFTeX, Latin Modern, the LaTeX packages named in the source, and Poppler. No package installation is performed.

```sh
python3 -I -S -B /absolute/path/Report58/tools/build_report.py \
  --output-dir /absolute/path/new-external-build
```

The tool checks the manuscript's fixed reviewed SHA-256, builds a fresh PDFLaTeX format in a private temporary directory, uses a minimal environment and system-only TeX inputs, disables shell escape and automatic font generation, and compiles three times with a fixed source date. It refuses overfull boxes or unresolved reference/citation warnings. It verifies the rebuilt PDF is byte-identical to the packaged PDF, then extracts text and renders every page at 120 dpi. Temporary TeX caches are deleted. Output contains the full page PNG inventory, build log, and installed-input/executable SHA-256 inventory.

The `--draft` flag permits rendering a newly pinned manuscript before replacing the packaged PDF, while preserving all source and output-path checks. It is for reviewed release preparation, not a claim of equality with an existing PDF. Final builds omit it.

Identical output has been checked across clean builds in this installed environment. A different TeX/Poppler version or font installation may produce different bytes; cross-installation byte identity is not promised. `verification/BUILD_DEPENDENCIES.json` identifies the tested installed TeX inputs and executable files, not dynamically linked libraries or an entire operating-system image.

## Deterministic archive

```sh
python3 -I -S -B /absolute/path/Report58/tools/release.py zip \
  --output /absolute/path/new-external-Report58.zip
```

The tool verifies the sealed inventory, writes sorted file and directory entries with fixed 2026-10-04 timestamps, fixed permission modes, and `ZIP_STORED`, then rechecks all archived bytes and the source inventory. Existing, overlapping, noncanonical, or symlinked outputs are refused. Directory entries preserve empty directories. Archive bytes are independent of source file timestamps and the chosen external output name. The ZIP digest is delivered separately so no self-hash cycle is introduced.

Run release-only fixture tests with:

```sh
python3 -I -S -B /absolute/path/Report58/tools/test_release.py \
  --receipt /absolute/path/new-external-tool-test-receipt.json
```

These tests mutate fresh disposable fixtures only and never execute scientific code. They cover complete-inventory mutations, output reuse/overlap/path aliases, symlink and hard-link rejection, nonregular entries, build-input tampering, clean invocation flags, and deterministic ZIP bytes. The separate portable replay test suite additionally tests exact science/checker/receipt authentication and relocated read-only replay.

## Proof and test scope

The geometric equivalence is inherited from the exact physical proof and independent audit copied into `science/sources/`. The POWER systems specialize `Pell.matiyasevic` and `Pell.eq_pow_of_pell` from the pinned mathlib source identified in the report. This is a conventional mathematical specialization and exact inert-source audit, not a new proof-assistant build or a new authentication of the remote mathlib commit.

The independent audit matches every residual exactly against all four DAGs, checks the literal sum-of-squares topology, graph and algebraic liveness, exact degree and top form, and all printed counts. Its finite tests include 15,625 gap-box inputs, 606 oriented/scaled orbit cases, 820 rational-circle cases, 12,500 denominator/Bézout cases, exhaustive bounded coefficient extraction through `P=125`, and 28,000 Cantor round trips.

Twelve complete exponent-zero positive witness assignments were evaluated on the raw DAGs, with a largest witness of 78 decimal digits. Other nonzero-exponent outer tests use directly calculated ordinary power outputs; general full Pell witness existence comes from the constructive theorem proof. All tests support the all-input proofs rather than replace them.

No generic MRDP black-box final representation, comparison oracle, hidden variable-length array, physical simulation, finite-fold/unique-witness claim, real-witness equivalence, optimality claim, or new physical threshold is asserted. The infinitely many signed-pair lifts rule out finite-foldness for this particular displayed representation.

## Key frozen pins

- Arithmetic proof: `b55f301d2b1531f348163f026b3c1f7f827669d266afb77d854eef7ceb21c482`
- Native linear DAG: `707721d1a8dca21b29acda57df8df6e763a1df89761f513122bec5edd9261ccc`
- Paid one-input linear DAG: `b64a268cc03033c13c020abc0cb12c1c81f9ba630aa75812ac84b08e2971efc3`
- Root independent audit: `e790c49af8d56190740520637af65d436e75f7af2a30856590646f3bf6372dbd`
- Physical proof: `1bea81f8f2e6693d4b7958fb44763eb644663d208fe70c577e0137184e17a725`
- Physical audit: `b119df1c0be8685078b011c14e3c71decabce343f9ba9041ee6f97b4c58a5226`
- Pell source: `993760c797ad0ff66fa77064a616fce779550bc745cbf6c44e04f392fd0bed0a`

The full release inventory and exact manuscript/PDF pins are in `MANIFEST.json`; dependency and replay manifests give the underlying byte-level provenance. The included mathlib source retains its Apache 2.0 license and notice.

## Final review and verification status

- The full manuscript, all 19 rendered pages, both equation directions, all four raw DAGs, every printed ledger, all sixteen selected source pins, and twelve complete positive witness assignments passed fresh independent manuscript review
- An independent direct TeX build matched the final PDF byte-for-byte; repeated clean release builds also matched all 19 page PNGs
- The independent portable checker replay passed exact receipt/witness/stdout comparisons and its 33-case portability suite
- The exact final release tools passed 65 independent adversarial checks and their 38-case fixture suite, including unsafe paths, optimized startup, full inventories, deterministic archives, extraction roundtrips, and fresh-format build provenance
- The 33-file science and 11-file root-audit trees remain byte-identical to their frozen originals

The review documents and receipts are included. Post-seal archive verification results and the final archive SHA-256 are supplied separately with the delivery; they are deliberately not inserted into the already sealed archive.
