# Balanced Smirnov uniform remainder repair

This package proves a compact-complex-uniform all-orders remainder for fixed multiplicity k and separately proves the factorial-cumulant degree cancellation. It verifies the pinned manuscript's third-order formulas and qualifies the inverse approximation. Read balanced-smirnov-repair.pdf first; the editable source is balanced-smirnov-repair.tex.

## Included

- Standalone TeX and 10-page PDF report
- scripts/check_operator.py: complete operator calculation through third order
- scripts/check_independent.py: independent exact multiset enumeration, rational inequality checks and symbolic verification
- results/: exact outputs, clean replay record and PDF build log
- review/: mathematical audit, integrated report review and all-page visual QA
- provenance/sources.json: exact source pin, inspected-file hashes and primary literature links
- requirements.txt: SymPy 1.14.0
- scripts/replay.sh and scripts/build_pdf.sh: clean checks and PDF rebuild

The archive contains no full third-party paper or original manuscript. No external repository was edited or publication submitted. Existing exact combinatorial machinery and displayed coefficients are credited in the report. This is AI-assisted, cross-checked work, not a peer-reviewed publication or formalized theorem, and no historical novelty is asserted.

## Replay

Requirements: Python 3 with SymPy 1.14.0; a LaTeX installation providing pdflatex, amsmath, amsthm, mathtools, lmodern, microtype, geometry, hyperref, enumitem and booktabs; Poppler pdfinfo. Install the Python dependency in your own virtual environment with `python -m pip install -r requirements.txt` if necessary. The replay itself does not install packages or use the network.

From the unpacked package run:

    bash scripts/replay.sh /tmp/smirnov-clean-replay

The destination should be a new empty directory. The script reruns both exact checks, compares their outputs byte-for-byte with the recorded results, builds the PDF twice and checks for layout/reference warnings. The output directory is printed on success. An existing normally configured TeX installation is used directly. On minimal Debian images lacking generated formats/maps, build_pdf.sh constructs the needed cache only inside the output directory, using installed TeX sources and fonts. It never writes to a system directory.

To build only the PDF:

    bash scripts/build_pdf.sh /tmp/smirnov-pdf-build

The build disables shell escape. One expected epstopdf warning about this security setting is exempted; unresolved references, other LaTeX/package warnings, overfull boxes and build errors fail the check. Underfull boxes should be assessed visually; the delivered build has none. The document dates are fixed via SOURCE_DATE_EPOCH, but byte-identical PDF output across TeX versions is not promised.

To reproduce visual QA, render all pages with:

    pdftoppm -r 100 -png /tmp/smirnov-pdf-build/balanced-smirnov-repair.pdf /tmp/smirnov-page

The reported proof is analytic; finite enumerations and numerical/symbolic checks are supporting validation, not the reason its uniform asymptotics hold. All asymptotics fix k. The main count/inverse formulas use labeled shuffles B; the distinct multiset count S and its altered inverse carrier are explicitly explained.
