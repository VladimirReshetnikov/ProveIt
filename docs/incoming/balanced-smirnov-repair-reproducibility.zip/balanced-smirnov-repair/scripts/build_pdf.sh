#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${1:-"$ROOT/build"}
mkdir -p "$OUT"
OUT=$(cd "$OUT" && pwd)
# Reproducible document dates. No network or package installation is performed.
export SOURCE_DATE_EPOCH=1790899200
export FORCE_SOURCE_DATE=1
# Some minimal Debian images contain TeX sources but no generated format or font maps.
# Recover only inside OUT; a normally configured TeX installation needs no fallback.
if ! kpsewhich pdflatex.fmt >/dev/null 2>&1 || ! kpsewhich pdftex.map >/dev/null 2>&1; then
  if [[ -f /usr/share/texlive/texmf-dist/tex/latex/base/latex.ltx && -f /usr/share/texmf/fonts/map/dvips/lm/lm.map ]]; then
    CACHE="$OUT/tex-cache"
    mkdir -p "$CACHE"
    export TEXMF='{/usr/share/texlive/texmf-dist,/usr/share/texmf}'
    export TEXMFVAR="$CACHE"
    export TEXFORMATS="$CACHE:"
    export TEXFONTMAPS="$CACHE:"
    (cd "$CACHE" && pdftex -ini -interaction=nonstopmode -halt-on-error -jobname=pdflatex -progname=pdflatex '*pdflatex.ini' > format-build.log 2>&1)
    cat /usr/share/texmf/fonts/map/dvips/lm/lm.map \
      /usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts/{cm,cmextra,symbols,latxfont}.map > "$CACHE/pdftex.map"
  fi
fi
for PASS in 1 2; do
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error \
    -output-directory="$OUT" "$ROOT/balanced-smirnov-repair.tex" > "$OUT/pass-$PASS.txt" 2>&1
done
# epstopdf emits a harmless warning because shell escape is deliberately disabled.
if grep -E 'Overfull|LaTeX Warning|Package .* Warning|^!' "$OUT/balanced-smirnov-repair.log" | grep -vF 'Package epstopdf Warning: Shell escape feature is not enabled.' >/dev/null; then
  echo 'Build has warnings or errors; inspect the log.' >&2
  exit 1
fi
pdfinfo "$OUT/balanced-smirnov-repair.pdf" > "$OUT/pdfinfo.txt"
echo "PDF build passed: $OUT/balanced-smirnov-repair.pdf"
