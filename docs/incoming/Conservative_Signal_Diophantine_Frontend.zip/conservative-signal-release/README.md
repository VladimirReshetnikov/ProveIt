# Conservative signal machines as Diophantine frontends

This release gives a literal universal conservative signal machine and a direct exact-arithmetic description of its finite collision histories.

## Results

- Literal machine: 114 meta-signals, 445 explicit injective 2-to-2 rules, exactly 18 live signals on every encoded input
- Source: Morita's 15-state, 6-symbol reversible universal Turing machine, through the Durand-Lose stack compiler
- Integer frontend: 17 gap coordinates plus one finite-mode coordinate; the gap matrices have rank 16, at most 32 nonzero entries, and coefficients of absolute value at most 24
- Preferred lift: N_j = c_j I - c e_j^T, with N_j^2 = c_j N_j; the canonical pivot speed supplies the integer scale
- Optional exact time: one more coordinate with p' = c_j p + h_j
- Diophantine certificate: 80,501 event branches in a closed 49,700-mode family; exactly 4,196,998 auxiliaries, 2,762,961 squared affine residuals and 80,501 complementarity products for the step polynomial
- Smaller bound: ten live signals and ten integer coordinates by a binary reversible-TM existence compiler; that universal binary table is not instantiated here

The mode-coordinate row contains large fixed mode codes; the bound 24 applies to the gap block, not the entire 18-dimensional matrix.

## Read first

`conservative-signal-diophantine.pdf` is the full proof article. Its editable source is `paper/conservative-signal-diophantine.tex`; `paper/morita-table.tex` contains the complete source TM transition table.

The complete literal signal machine is `data/MORITA_18_SIGNAL_MACHINE.json`. It includes every label, speed and collision rule, exact mode codes and label orders, the preferred integer lift, and separate accepting and nonaccepting terminal labels. The initial tape/program loader is implemented in `code/instantiate_morita.py` and derived in the article.

Only `(q1,b)` is accepting. `(q2,$)` is nonaccepting null termination. Other undefined TM instructions and unlisted collisions are forbidden. The table must not be completed with unspecified identity collisions.

## Reproduce

Requirements: Python 3.10 or later, standard library only. Run without Python's `-O` flag because assertions are the exact checks.

```
./run-replay.sh
```

The script regenerates mathematical data and receipts in place. The independent all-pairs replay includes large cumulative integers and can be slower than the primary replay. The compact polynomial exporter is checked exhaustively, and all five literal runs are also matched to its numeric branch guards. Tests are finite corroboration; universality relies on the cited source theorem and the article's general simulation proof.

To rebuild the article, use TeX Live with the usual AMS, Latin Modern, geometry, microtype, booktabs, enumitem and hyperref packages:

```
./build.sh
```

Build intermediates remain in `.build/`. The script includes a local-format fallback for minimal TeX configuration. It does not download or install anything.

## Files

- `code/conservative_signal.py`: exact stack gadget, reversible-TM compiler, complete simultaneous-event engine and integer lifts
- `code/instantiate_morita.py`: literal universal table generation, finite CTAG loader, source-tape differential replay, exact mode codes and timed lift
- `code/MORITA_15_6_audit.py`: independent source-table transcription and finite CTAG/TM comparisons
- `code/quadratic_packet.py`: generic lazy event-branch enumeration, canonical packet witnesses and exact polynomial evaluation; its default complete example is deliberately small
- `code/independent_checks.py`: all-pairs event engine, generic tie/germ checks, two-half loaders and cumulative uniform scaling
- `code/initial_side_checks.py`: left- and right-entry two-half tape regression suite
- `code/pivot_scale_checks.py`: cumulative pivot-scaled integer replay and fixed-span geometry/time decoding
- `numeric/`: complete compact mode/event closure, polynomial circuit, exact coefficient exporter, standalone mathematical specification and verification scripts; verbose branch and residual files can be regenerated
- `receipts/`: regenerated machine-readable exact-check results
- `data/`: complete mathematical machine data, all 185 source-example configurations, and primary-source provenance
- `SHA256SUMS`: checksums of the released files, excluding itself

## Important boundaries

The fixed-population bound is uniform in program size, data size and runtime; the input is encoded in two rational distances. Loading is effective and its digit/base-conversion costs are explicit. Encoded runs do not use Zeno acceleration.

The step polynomial is quadratic and has a unique natural witness. Its exact 4,196,998-variable auxiliary constant is large. The finite mode graph is a mode-only overapproximation and is not a bound on universal runtime; blocked sinks and null outcomes are not accepting. An externally fixed horizon K gives a family with size linear in K. No fixed-arity Diophantine polynomial for an unknown unbounded computation, optimized dimension, or new universality mechanism is claimed.

This release includes no copyrighted source PDFs, source-page screenshots, private review reports, or third-party software. See `SOURCE-PROVENANCE.md` for primary links and the documented source typo.

## Full numeric polynomial export

The compact release stores every mode and every event branch, with fixed numeric data sufficient to reconstruct all coefficients. To create the larger human/machine-readable sparse branch and residual-row files:

```
python3 numeric/compile_packet.py build --residuals
```

This writes the verbose exports under `numeric/`; they are intentionally not prebundled. The exporter also supports individual expanded polynomial coefficient queries as documented by its help and the circuit JSON. The shared selector sum is an expression, not an additional quantified variable.

To verify the shipped compact records without producing the large exports, run `python3 numeric/compile_packet.py verify`. The ordinary replay script already performs this check. Avoid the `expanded` command unless you deliberately want more than a trillion monomials; it requires an explicit additional flag.

During preparation, the full sparse affine-residual export was generated and independently checked. The trillion-term monomial expansion was not emitted. Its exact support count and coefficient-height derivation are in `numeric/PROOF_AND_LEDGER.md`.
