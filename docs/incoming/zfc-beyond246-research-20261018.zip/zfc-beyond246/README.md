# Beyond 246: verified obstructions and synthesis experiments

**No machine with fewer than 246 working states is established here.** This is
a research packet for the ProveIt project, prepared on 18 October 2026 UTC.
The included 246-state machine is an attributed reference from the incoming
archive already present at the pinned repository revision.

The requested target remains:

\[
\mathsf{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M,\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathsf{ZFC})\bigr),
\qquad |Q_M|\le245.
\]

The convention is one doubly infinite tape, two symbols, blank zero, only
left/right moves, and a separately counted halt label. The working-state count
includes the initial state. A prepared tape is not a blank initializer.

## Read the result

- `report.pdf`: the complete research note.
- `report.tex` and `sections/main.tex`: editable LaTeX source.
- `PROVENANCE.json`, `NOTICE.md`, and `LICENSE`: source identities, attribution,
  result status, and repository-compatible license.
- `SHA256SUMS`: integrity manifest of the delivered packet.

The main new results are exact local counterexamples, independently verified
inductive source invariants, and reproducible bounded search boundaries. The
report does not convert a finite test failure, unsupported symbolic rule, or
solver timeout into a semantic state lower bound.

## Main findings

1. Shortening the nine-zero return scanner gives apparent 245/244-state
   machines, but temporary program-counter words contain `1 0^8 1` and
   `1 0^7 1`. The shortened scanner returns through the wrong origin. This
   persists at distance 181 with 167 spare blocks of value 1, the stronger
   resources of the actual bootstrap. It refutes the inherited return-origin
   contract; it does not prove the mutants' eventual blank behavior.
2. Deleting old state 204 and replacing 172/read 1 by `(1,R,252)` can halt from a
   valid original proof-search phase with theorem-valued formula registers.
   The complete literal traces take 12,808 moves for a small prepared frame
   and 10,232 for the frame with bootstrap-scale resources. These are prepared
   source-phase obstructions, not claimed blank-run halts.
3. A product invariant for `T=W=H=0` with all six numerical registers arbitrary,
   and a full-vector invariant with 7,725,633 abstract configurations containing
   the actual root, both exclude the same six known source guards. The latter
   certificate has 8,669,994 independently checked abstract edges. These six
   exclusions free no additional literal transition row.
4. The completed search families below have no survivor of their stated gates.
   The family counts overlap and are counts of transition-edit recipes.

| Family | Complete recipe domain | Gate |
|---|---:|---|
| All pair merges, independent provider for each read row |120,540|8,391 concrete fixtures,20,000 moves each|
| Same merges with an inferred register bijection |120,540|Same full finite fixture requirement|
| Delete a state with one external incoming row |130,872|1,200-rule affine checker;42 macro-proof rows protected|
| Delete a state with two external incoming rows |44,539,776|2,000-move affected-fixture screen|
| Independent affine two-incoming search |13,555,584 complete, plus one partial domain|14 complete deleted-state domains;600-second overall limit|
| Delete pulse255, four controller rows free |100,000,000 per sampled suffix condition|48 macro fixtures; endpoint checks at ticks1 through249|

Lazy search partitions full assignment domains; it does not separately run
every complete table. The report and branch READMEs explain the pruning rule.
The single-incoming journal was completely replayed. Of its first failures,
26,780 are symbolic-fuel exhaustion; the remaining 104,092 are other checker
rejections. Neither category supplies an unrestricted impossibility theorem.

5. The new scanner SMT encoding allows temporary writes and two-way movement,
   while preserving the shared marking rows and restoring the entire window.
   Nine states/horizon 9 gives an independently replayed SAT control. Eight
   states/horizons 11 and 13 are solver-reported UNSAT; horizons 17 and 32 are
   UNKNOWN because of timeout. The exact finite graph-reachable-state
   template, window and horizons are part of the result. No eight-state
   solution is supplied.

## Verify without a network connection

From this directory, with Python 3.10 or later and assertions enabled:

```sh
python3 -B code/verify.py --replay-ledger --output /tmp/zfc-beyond246-check
```

This was run successfully on the delivered material. It took about 130 seconds
in the recorded environment. The resulting records are included under
`verification/`.

The command checks identities and available manifests, replays every one of
the 130,872 recorded first-failure cases, replays both families of binary
counterexamples using complete tape comparisons, checks the full source
invariant certificates, replays the nine-state SMT control, checks all recorded
recipe-domain arithmetic, and reruns the complete inherited 246 verification
suite. The latter runs in a disposable copy so the frozen reference is not
modified. It includes the literal blank bootstrap, all 8,391 affine instruction
cases, all four universal block/list induction proofs, and literal regressions.

To skip only the expensive single-incoming journal replay, omit
`--replay-ledger`. To skip the inherited reference suite, add
`--skip-reference`. The independent relational-invariant verifier still runs.
No Z3, C++ compiler, Lean, Rocq, or LaTeX installation is needed for this
verification command.

The default verification does not rerun every long search, prove the leastness
of an abstract invariant, or independently certify Z3 UNSAT proofs. Source
invariant closure is checked independently of the worklist generators.

Never run the Python proof checks with `-O` or `-OO`. Assertions carry part of
the verification logic.

## Reproduce the searches

The following commands refresh experiment results. Use a working copy if you
want to preserve the delivered integrity manifest.

```sh
python3 -B code/search_actions.py --seconds 180
python3 -B code/search_two_actions.py --seconds 600
```

`context/SCOPE.md` gives the complete Python/C++17 commands for the pair,
register-bijection and two-incoming literal searches. It also documents the
additional 671 uniform-fold and 980 targeted state 2-repair experiments.

```sh
cd context
python3 -B make_merge_cases.py
g++ -O3 -std=c++17 merge_search.cpp -o /tmp/zfc-merge-search
/tmp/zfc-merge-search merge-cases.txt
python3 -B make_conjugacy_cases.py
g++ -O3 -std=c++17 conjugacy_search.cpp -o /tmp/zfc-conjugacy-search
/tmp/zfc-conjugacy-search conjugacy-cases.txt
python3 -B make_twoaction_states.py
g++ -O3 -std=c++17 twoaction_search.cpp -o /tmp/zfc-twoaction-search
/tmp/zfc-twoaction-search merge-cases.txt twoaction-states.txt
cd ..
```

For the invariant and pulse branch:

```sh
cd alternative
python3 -B verify_invariant.py --relational
python3 -B search_pulse.py --baseline-only
python3 -B search_pulse.py
python3 -B search_pulse.py --arbitrary-spares
cd ..
```

The standalone invariant command refreshes its local result JSON; the
top-level verifier instead calls the independent check functions and writes
fresh records to the selected output directory. `alternative/generators/`
contains the original product, full-vector and refined-product generators with
separate output locations. Its README explains the exact scopes and commands.

The precise state-204 source-phase and strengthened scanner witnesses can be replayed with:

```sh
python3 -B audit/verify_audit.py --output /tmp/zfc-witness-replay
```

The flexible-spare sources and the eight-family, 7,683,200-recipe result are in
`audit/`. Its text result describes the C++ auxiliary-row search; the adjacent
JSON describes the separate 980-recipe preliminary search. They should not be
confused.

## Rerun scanner synthesis

Only this optional experiment needs Z3. Install the recorded version in an
isolated environment:

```sh
python3 -m venv /tmp/zfc-scanner-venv
/tmp/zfc-scanner-venv/bin/python -m pip install -r requirements-synthesis.txt
/tmp/zfc-scanner-venv/bin/python -B code/synthesize_detector.py --states 9 --steps 9 --seconds 30
/tmp/zfc-scanner-venv/bin/python -B code/synthesize_detector.py --states 8 --steps 13 --seconds 90
```

Use `--steps 17 --seconds 120` or `--steps 32 --seconds 90` to recreate
the longer recorded requests. A solver's
elapsed time and UNKNOWN/SAT outcome can vary across machines and versions.
The recorded Z3 version is 5.3.1. No solver runtime is bundled in this archive.

The allowed graph-reachability labeling, fixed marking rows, tape window,
outside-context restriction and endpoint absorption are reviewed in
`context/DETECTOR_AUDIT.md`. A future SAT result still requires unbounded
composition, a full source audit, and a valid blank initializer before it can
support a consistency-machine claim.

## Build the report

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

The PDF was rendered and visually reviewed. Build and quality records are
under `verification/`. Intermediate LaTeX build files are not needed for the
archive and are omitted from the final package.

## Source pin and integration

Repository:
<https://github.com/VladimirReshetnikov/ProveIt>

Revision:
`8cdc55ff9281b0aaba49bf74b0b225d57f12b893`

Reference incoming path:
`docs/incoming/zfc-context246-20261018.zip`

The original archive is extracted unchanged under
`baseline246/zfc-context246/`. `context/baseline/` retains a second copy needed
by that branch's independently portable scripts. The duplicated reference is
intentional and attributed; neither copy is a new record.

This directory can be retained as a research packet or the ZIP placed in
`docs/incoming`. No remote repository change is part of this deliverable.
No proposed 245/244-state mutation should replace the current canonical
machine on the strength of this packet.

An ordinary proof inside ZFC can use the specific set-coded completeness,
internal well-founded quotient and constructible-model arguments described in
the report. An external Lean theorem alone is not a generic translation into
ZFC, and no new kernel endpoint or PA proof-code internalization is claimed.

