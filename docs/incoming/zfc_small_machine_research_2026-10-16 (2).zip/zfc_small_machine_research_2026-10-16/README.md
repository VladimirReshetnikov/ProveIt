# Toward a Smaller Con(ZFC) Machine

Research report for incorporation in ProveIt, dated 16 October 2026.

**No new sub-253 consistency machine is claimed.** The main new contribution
is a rigorous ordinary proof separating one-parameter EPSC from Pairing and
two-parameter EPSC in the exact interface used by the existing reports.
The archive also contains a reachable obstruction to a proposed scanner
state deletion and measured complete-program compiler controls.

## Read the report

- `article.pdf`: complete report, proofs, proposal, limitations, and references.
- `article.tex` and `sections/*.tex`: editable LaTeX sources.
- `PROVENANCE.json`: source URLs, commits, Git blob identities, and SHA-256
  hashes for the included reproduction inputs.
- `CHECKSUMS.sha256`: hashes for the complete distributable bundle.
- `reproduction/RUN_RESULTS.json`: results of the final replay from this
  bundled directory layout, including the extended searches.

## Results and their exact status

| Result | Status |
| --- | --- |
| Three-component EPSC1 interpretation | Ordinary arbitrary-formula proof in the report; not formalized in Lean/Coq. |
| Pairing and an EPSC2 instance fail | Relative to Con(ZFC), a deductive separation. No strict consistency-strength separation is asserted. |
| Further axioms in the interpretation | Extensionality, irreflexivity, Empty Set, Union, Power Set, Infinity, full Separation, set-indexed Choice, and parameter-free Replacement. One-parameter Replacement fails. |
| Existing hereditary-saturation domain | H is the entire counterinterpretation and D is actual equality; this particular quotient still lacks Pairing. Other interpretations remain open. |
| Public253 scanner edit | A critical frame is reached after 1,011,713 literal blank-tape steps. The original table reaches the expected successor in 476 steps; the edited scanner reaches a wrong successor in 556 steps. This refutes the advertised instruction simulation, not ultimate halting equivalence. |
| Radius-6 local search | 335,369 abstract configurations; 63,756 ordered state pairs; no certified deletion. This is a bounded search, not a lower bound. |
| Outgoing-equality compiler | 432 recipes actually compiled; best complete-row control has 290 working states. Numerical payload transport and the full consistency endpoint remain unproved. |
| Original-logic grammar controls | The prior 268-state control is reproduced. New row-permutation family: 12,002 grammar evaluations, minimum 270. Three million reassociation proposals retain 268. |

The finite support diagnostic explicitly checks that its 7-, 20-, and
760-object truncations **are not models of full EPSC1**. The unbounded
class construction in the mathematical proof supplies that theorem.

## Reproduce the finite results

The archive is self-contained for these computations. No network or git
checkout is needed. Use Python 3.12 with assertions enabled; the extended
grammar search additionally uses `g++` or `clang++` with C++17 support.
The Python programs otherwise use the standard library and the included,
unchanged, attributed compiler sources.

From the archive root:

```sh
python3 reproduction/reproduce.py --verify-only
python3 reproduction/reproduce.py --output /tmp/zfc-report-replay
```

The default replay checks source identities, the model-coding diagnostics,
the actual scanner witness, radius-6 and radius-5 projection results, the
prior 268-state control and its 4,533-pair register certificate with six
rejected corruptions, and every recipe in the 432-build equality experiment.

To repeat the larger negative compression searches as well:

```sh
python3 reproduction/reproduce.py --extended --output /tmp/zfc-report-full
```

Outputs and logs are placed in the requested directory. Without `--output`,
the driver creates a temporary directory and prints its location. Runtime
is machine dependent; no search timeout is treated as a successful result.
Do not run with `python -O`, which would disable assertions.

Each individual script has `--help` and can also be run separately:

```sh
python3 reproduction/zf_audit/scanner_boundary.py \
  reproduction/zf_audit/zfc_253.tm \
  reproduction/zf_audit/upstream/Prog254.v \
  --output /tmp/scanner_boundary.json

python3 reproduction/proveit_audit/eout_emitter_experiment.py \
  --repo reproduction/sources/proveit \
  --output /tmp/equality-controls --search
```

The C++ search accepts positional arguments; its preparation and independent
retained-grammar check are called by `reproduce.py --extended`.

## Build the PDF

A conventional TeX Live installation with `latexmk` and the packages listed
at the top of `article.tex` is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The delivered PDF was compiled and visually inspected. Rebuilding it may
change PDF metadata and hashes; regenerate `CHECKSUMS.sha256` if distributing
a modified bundle. The report uses a self-contained bibliography and has no
external image dependencies.

## Pinned source snapshots and attribution

- [ProveIt](https://github.com/VladimirReshetnikov/ProveIt/tree/2c74914bdfc98920ddcc3ff7c092cce10db4d709):
  `2c74914bdfc98920ddcc3ff7c092cce10db4d709`.
- [Jeffrey's upstream ZF tree](https://github.com/jeff87654/busy-beaver/tree/297ab8df7e5de329605c3875b4934643b371a5e3/ZF):
  `297ab8df7e5de329605c3875b4934643b371a5e3`.
- [mira-emmy's public253 PR head](https://github.com/mira-emmy/busy-beaver/tree/0d544f2a2e3c18f12278441a74b7879f31cbe856/ZF/m253):
  `0d544f2a2e3c18f12278441a74b7879f31cbe856`.

The public253 machine is prior work, derived from Mira-Cult's construction
with mira-emmy's reduction and Jeffrey's verification. The reconstructed
compiler controls use Andrew James Wade's backend. ProveIt's retained-full-word
268-state result is also prior work. See `THIRD_PARTY.md` and the retained
license notices. The full external Coq build and ProveIt Lean build were
not rerun for this report.

## Suggested integration

Keep this report and its reproduction subtree together as one new research
contribution. The LaTeX separation proof is suitable for a later formal port;
the report proposes the first precise module interfaces. The three supplied
classes of machine tables have different status: `zfc_253.tm` is attributed
public prior work, `baseline268/candidate.tm` is a reproduced prior compiler
control, and the outgoing-equality `.tm` files are new compiler controls.
The rejected shortened scanner is constructed inside its diagnostic and is
not supplied under a name suggesting a valid consistency machine.
