# Color-Coded Affine Partitions

**Exact Boundary Saturation and a Two-Term Growth Law**  
Research manuscript prepared for the ProveIt project — October 7, 2026.

## Main result

Let `C_{s,q}` be the union of the `s` coordinate lines in `F_q^s`, and let `P_{s,n}(q)` be the minimum number of whole-field affine cells in a disjoint partition of `C_{s,q}^n`. For each fixed prime power `q > 2`, put `t = q-1` and `gamma_q = log(t)/log(1+1/t)`. The manuscript proves

```text
rho_s(q) = lim_{n -> infinity} P_{s,n}(q)^(1/n)
         = t*s - gamma_q + O_{q,epsilon}(s^(-1+epsilon))
```

for every positive epsilon. The positive error after the two displayed terms has logarithmic exponent `-1`. A sharper explicit upper error is `C_q*(K_s+3)/s`, where `log K_s ~ log s/log log s` and `K_s` is defined by integer factorial and perfect-hash bounds in the article.

The construction exactly attains

```text
P_{s,m}(q) = t*(s*t)^m - (t-1)*(1+s*t)^m
```

whenever `m/s + binom(m,2)/s^2 <= 1`, and in a substantially larger region certified by the color-coded residue budget. The endpoint of exact attainment is within `s^(o(1))` of `t*log(1+1/t)*s`, uniformly in `q > 2`.

Exact examples include `P_{3,2}(q) = 3*q^2-q-1` and `P_{4,3}(q) = 16*q^3-12*q^2-13*q+10`.

## Read and reproduce

`article.pdf` is the complete article. `article.tex` is self-contained LaTeX, including its bibliography. `references.bib` is supplied separately for integration convenience, but is not needed to compile the article.

From this directory:

```sh
python3 code/verify.py
python3 -m pip install -r requirements.txt
python3 code/asymptotic_bounds.py
make pdf
```

The first command requires only the Python standard library. It checks field arithmetic, common-invariant fiber packings, eight full partition constructions, all 115 nonzero final-block slices of those constructions, exact polynomial identities, and rejection of invalid certificates. It regenerates the two archived explicit certificates and the finite verification report.

The second mathematical script uses `mpmath` for 90-digit evaluations. Its routing-budget checks use exact integers and rational numbers. Its displayed decimal endpoints are approximations, not directed interval bounds.

## Contents

- `article.tex`, `article.pdf`, `references.bib`: manuscript and references.
- `code/`: exact finite-field constructions, independent certificate expansion, rational routing-budget checks.
- `certificates/`: two explicit line certificates, with implicit torus-singleton complements.
- `results/`: full exact-check results, rational budget certificates, approximate rate intervals, build/environment metadata.
- `THEOREM_STATUS.json`, `PROOF_AUDIT.md`: result-by-result verification boundaries and proof audit.
- `SOURCE_AUDIT.md`, `INTEGRATION.md`, `FORMALIZATION_PLAN.md`: provenance and repository guidance.
- `SHA256SUMS`: integrity checks for the delivered files.

## Status

This is an AI-assisted research manuscript with ordinary mathematical proofs and exact finite corroboration. It has not been independently refereed or verified by Lean/Rocq. Novelty is claimed relative to the inspected project baseline; historical priority was not established exhaustively.

The point–torus defect and Jensen lower bound are predecessor tools, explicitly credited and reproved. The new contributions are the geometric packing construction, exact regions and threshold, and the many-arm growth law. No global result from `openai/math` is a theorem dependency.

The outer asymptotic variable is the number of arms `s`, with `q` fixed. This does not eliminate the earlier logarithmic loss in the distinct fixed-`s`, large-`q` regime. It does not determine `rho_2(q)` or `P_{2,3}(q)`, and it does not claim a new integer Szemerédi bound or a faster unknot-recognition algorithm.
