#!/usr/bin/env python3
"""Check every file named by SHA256SUMS, rejecting unsafe manifest paths."""
from pathlib import Path,PurePosixPath
import hashlib
ROOT=Path(__file__).resolve().parents[1]

def main():
    count=0;seen=set()
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        p=PurePosixPath(name)
        if p.is_absolute() or '..' in p.parts or name in seen:raise ValueError('Unsafe or repeated manifest path')
        if len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):raise ValueError('Bad digest')
        target=ROOT.joinpath(*p.parts)
        if target.is_symlink() or not target.is_file():raise ValueError('Missing or linked manifest entry: '+name)
        if hashlib.sha256(target.read_bytes()).hexdigest()!=digest:raise ValueError('Hash mismatch: '+name)
        seen.add(name);count+=1
    print(f'PASS: {count} manifest files')
if __name__=='__main__':main()
