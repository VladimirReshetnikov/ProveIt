#!/usr/bin/env python3
"""Create a deterministic ZIP and SHA-256 manifest of the curated release."""
from pathlib import Path
import hashlib, json, zipfile
ROOT=Path(__file__).resolve().parents[1]

def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink()
                  and not any(part.startswith('.') or part=='__pycache__' for part in p.relative_to(ROOT).parts)
                  and p.suffix!='.pyc' and p.name!='SHA256SUMS')

def main():
    entries=files()
    manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in entries)
    (ROOT/'SHA256SUMS').write_text(manifest)
    out=ROOT.parent/'sparse-lattice-research.zip'
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in sorted(entries+[ROOT/'SHA256SUMS']):
            name=ROOT.name+'/'+p.relative_to(ROOT).as_posix()
            info=zipfile.ZipInfo(name,date_time=(2026,10,2,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=(0o755 if p.suffix=='.sh' else 0o644)<<16
            archive.writestr(info,p.read_bytes(),compresslevel=9)
    with zipfile.ZipFile(out) as archive:
        assert archive.testzip() is None
        for member in archive.infolist():
            assert not member.filename.startswith('/') and '..' not in Path(member.filename).parts
    print(json.dumps({'archive':out.name,'bytes':out.stat().st_size,
                      'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                      'manifest_files':len(entries)},indent=2))
if __name__=='__main__':main()
