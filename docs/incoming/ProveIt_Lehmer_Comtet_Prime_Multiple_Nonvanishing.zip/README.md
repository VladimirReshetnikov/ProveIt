# Complete nonvanishing on prime-multiple offsets

This research note proves:

- Every positive-column Lehmer–Comtet entry on offset 2(p−1) or 4(p−1) is nonzero for every prime p
- Every positive-column entry on offset 3(p−1) is nonzero for every odd prime p
- For each fixed multiplier m, the full offset m(p−1) is nonzero for all sufficiently large primes p, under explicit conditions
- The universal positivity bound T_r(Y)>0 for integer Y≥4r
- A precise limitation of a fixed finite-modulus p-power sieve at prime-square offsets

In the derivative of x^x, the structural Y=0/top-logarithm cancellation remains on every positive defect. The complete global integer-zero classification is still open. The note does not claim real-rootedness of all polynomials T_r.

Files:

- article.pdf and article.tex: self-contained proof and source references
- verify.py and checks.json: exact rational polynomial construction, independent integer-triangle comparison, complete-family/cone checks, congruences and small certificates
- replay_convolution.py and replay_convolution.json: a separate exact direct-convolution and finite-difference replay
- build_local.sh: the local TeX build wrapper; standard pdflatex also works with the listed packages

Run the checks with ordinary Python 3 (standard library only):

    python verify.py
    python replay_convolution.py

The first checker records 14,000 complete-family checks, 15,880 positivity-cone checks, 29,456 localization checks, 3,132 coefficient identities, 64 stronger lifts, and four prime-square congruences. The independent checker records 1,320 double-family checks, 3,000 localization checks, 56 lifts and 1,176 derivative identities. These are finite reproducibility checks; the manuscript proves the uniform results.

The inspected ProveIt source was unchanged at its relevant blob on 1 October 2026. The paper distinguishes its conclusions from the existing prime-offset and offset-through-16 results, credits the classical derivative barrier and multinomial method, and makes no exhaustive priority claim. This is a conventional mathematical proof with independent review and exact checks, not a formal proof-assistant development.
