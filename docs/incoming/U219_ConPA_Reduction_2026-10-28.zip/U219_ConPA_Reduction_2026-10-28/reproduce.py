#!/usr/bin/env python3
"""Rebuild and audit the delivered reductions; --full repeats universal runtime proofs.

Python 3.10+, standard library only. No network, optimizer, external checkout,
or proof assistant is used. Reports distinguish fresh symbolic replay from
validation of previously generated symbolic evidence.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
CODE = ROOT / 'code'
BASE = ROOT / 'baseline/u222'
sys.path.insert(0, str(CODE))
import audit_transport as audit
from certify_u221 import certificate, read


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(script, arguments, cwd):
    result = subprocess.run([sys.executable, '-B', str(script), *map(str, arguments)],
                            cwd=cwd, text=True, capture_output=True,
                            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    if result.returncode:
        raise RuntimeError(str(script) + '\n' + result.stdout[-6000:] + result.stderr[-6000:])
    return result.stdout


def manifest():
    names = set()
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        if not line:
            continue
        expected, name = line.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts, 'Unsafe manifest path')
        require(name not in names, 'Duplicate manifest path')
        names.add(name)
        require(sha(ROOT / p) == expected, 'Artifact hash mismatch: ' + name)
    require({'machine/u219.tm', 'machine/u219.native.tm', 'machine/u219.sites.json',
             'paper/report.tex', 'paper/report.pdf', 'reproduce.py'} <= names,
            'A principal deliverable is absent from manifest')
    return len(names)


def check_dense(name):
    native_path = ROOT / ('machine/' + name + '.native.tm')
    native = audit.table(native_path)
    states = sorted({q for q, _ in native})
    renaming = {q: i for i, q in enumerate(states)}
    renaming[254] = len(states)
    expected = '#! start 0\n' + ''.join(
        f'{renaming[q]} {b} {w} {d} {renaming[t]}\n'
        for (q, b), (w, d, t) in sorted(native.items()))
    require((ROOT / ('machine/' + name + '.tm')).read_text() == expected,
            name + ': dense table is not the exact state renaming')
    return len(states), len(native)


def check_runtime(name, report, cases):
    source = ROOT / ('machine/' + name + '.sites.json')
    native = ROOT / ('machine/' + name + '.native.tm')
    rows = json.loads(source.read_text())
    total = sum(2 if op == 'CD' else 1 for p, op, arg in rows)
    state_count, transitions = check_dense(name)
    require(report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS', name + ': runtime failed')
    require(report['table_sha256'] == sha(native), name + ': wrong table in runtime receipt')
    require(report['sites_sha256'] == sha(source), name + ': wrong source in runtime receipt')
    require(report['checker_sha256'] == sha(CODE / 'runtime/symbolic_runtime.py'), 'Wrong symbolic checker')
    require(report['helper_sha256'] == sha(CODE / 'runtime/independent_runtime.py'), 'Wrong symbolic helper')
    require(report['working_states'] == state_count, 'Wrong runtime state count')
    require(report['site_count'] == len(rows) == 3891, 'Wrong source count')
    require(report['expected_cases'] == report['proved_cases'] == total == 5060, 'Incomplete case coverage')
    require(not report['failures'], 'Runtime has failed cases')
    require(report['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED', 'Uncalibrated startup')
    expected_cases = [(i, p) for i, (_, op, _) in enumerate(rows)
                      for p in ((False, True) if op == 'CD' else (False,))]
    require([(r['site_index'], r['positive']) for r in cases] == expected_cases,
            'Wrong individual case coverage')
    require(all(r['duration'][0] > 0 and all(c >= 0 for c in r['duration']) for r in cases),
            'Missing positive-duration witness')
    return {'working_states': state_count, 'transitions': transitions,
            'primitive_occurrences': len(rows), 'guarded_cases': total,
            'native_sha256': sha(native),
            'dense_sha256': sha(ROOT / ('machine/' + name + '.tm')),
            'source_sha256': sha(source)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--full', action='store_true', help='Repeat all 5,060 symbolic cases of U219')
    ap.add_argument('--report', type=Path, help='Write an optional receipt outside the frozen release')
    args = ap.parse_args()
    require(__debug__ and not sys.flags.optimize, 'Run with assertions enabled; do not use Python -O')
    started = time.monotonic()
    nfiles = manifest()
    with tempfile.TemporaryDirectory(prefix='u-reduction-') as folder:
        tmp = Path(folder)
        print('Replaying the exact U222 source, table, and calibration-source audit.', flush=True)
        run(BASE / 'reproduce.py', ['--report', tmp / 'baseline.json'], tmp)
        baseline = json.loads((tmp / 'baseline.json').read_text())
        require(baseline['status'] == 'U222_RECONSTRUCTION_AUDIT_PASS', 'Baseline reconstruction failed')
        print('Rebuilding U221 and U220 and checking both local invariant proofs.', flush=True)
        run(CODE / 'build_u220.py', [BASE, tmp / 'rebuilt'], tmp)
        for name in ['u221.native.tm', 'u220.native.tm', 'u220.tm', 'u220.prefold.native.tm']:
            require((tmp / 'rebuilt' / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
                    'Reconstruction changed ' + name)
        require((tmp / 'rebuilt/sites.json').read_bytes() == (ROOT / 'machine/u220.sites.json').read_bytes(),
                'Reconstruction changed U220 source')
        print('Rebuilding the compact source, its 221-state parent, and U219.', flush=True)
        run(CODE / 'build_u219.py', [BASE, tmp / 'rebuilt219'], tmp)
        for name in ['c221.native.tm', 'c220.native.tm', 'u219.native.tm', 'u219.tm']:
            require((tmp / 'rebuilt219' / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
                    'Compact reconstruction changed ' + name)
        require((tmp / 'rebuilt219/sites.json').read_bytes() == (ROOT / 'machine/u219.sites.json').read_bytes(),
                'Reconstruction changed U219 source')
        run(CODE / 'audit_u220_independent.py', [BASE, tmp / 'rebuilt',
            '--output', tmp / 'independent_u220.json'], tmp)
        run(CODE / 'audit_tag_fold_independent.py',
            [ROOT / 'machine/c220.native.tm', ROOT / 'machine/u219.native.tm',
             '--parent', ROOT / 'machine/c221.native.tm',
             '--keep', 182, '--drop', 215, '--keep-tag', 1, '--drop-tag', 0,
             '--split-bit', 0, '--max-steps', 5, '--output', tmp / 'independent_u219.json'], tmp)
        zero = certificate(read(BASE / 'machine/u.native.tm'), read(ROOT / 'machine/u221.native.tm'))
        run(CODE / 'certify_u221.py', [BASE / 'machine/u.native.tm', ROOT / 'machine/u221.native.tm',
                                      tmp / 'zero_certificate.json'], tmp)
        source_checks = {}
        machine_checks = {}
        for name in ['u221', 'u220', 'c221', 'u219']:
            native = ROOT / ('machine/' + name + '.native.tm')
            source = ROOT / ('machine/' + name + '.sites.json')
            evidence = ROOT / 'evidence' / name
            source_checks[name] = audit.check_source_pair(BASE / 'machine/sites.json', source)
            run(CODE / 'check_source_independent.py', [BASE / 'machine/sites.json', source], tmp)
            report = json.loads((evidence / 'runtime.json').read_text())
            cases = json.loads((evidence / 'runtime_cases.json').read_text())
            machine_checks[name] = check_runtime(name, report, cases)
            run(CODE / 'review_native_bootstrap.py', ['--table', native, '--sites', source,
                '--startup', evidence / 'startup.json', '--out', tmp / (name + '_bootstrap.json')], tmp)
            boot = json.loads((tmp / (name + '_bootstrap.json')).read_text())
            require(boot['status'] == 'INDEPENDENT_LITERAL_STARTUP_PASS', 'Independent bootstrap failed')
            require(boot['startup_steps'] == boot['first_calibrated_root'] == 95714, 'Wrong startup time')
            require(boot['startup_registers'] == [4, 0, 0, 0, 0, 0, 0, 0, 0], 'Wrong logical seed')
            require(boot['spare_count'] == 40 and boot['spare_values'] == {'1': 40}, 'Wrong spare seed')
            require(boot['startup_gap'] == 1 and boot['startup_head'] == -8 and boot['startup_state'] == 84,
                    'Wrong calibrated frame')
            machine_checks[name]['independent_startup_steps'] = boot['startup_steps']
        if args.full:
            print('Re-deriving all 5,060 U219 cases over arbitrary registers, gaps, and spare lists.', flush=True)
            run(CODE / 'validate_native.py', [ROOT / 'machine/u219.native.tm', ROOT / 'machine/u219.sites.json',
                                             tmp / 'runtime'], tmp)
            generated = json.loads((tmp / 'runtime/runtime.json').read_text())
            generated_cases = json.loads((tmp / 'runtime/runtime_cases.json').read_text())
            check_runtime('u219', generated, generated_cases)
            require(generated_cases == json.loads((ROOT / 'evidence/u219/runtime_cases.json').read_text()),
                    'Regenerated symbolic case summaries differ')
            require(json.loads((tmp / 'runtime/startup.json').read_text()) ==
                    json.loads((ROOT / 'evidence/u219/startup.json').read_text()), 'Regenerated startup differs')
        report = {'status': 'U219_FULL_REPRODUCTION_PASS' if args.full else 'U219_REBUILD_AUDIT_PASS',
                  'manifest_files_checked': nfiles, 'fresh_symbolic_replay': args.full,
                  'symbolic_cases_freshly_replayed': 5060 if args.full else 0,
                  'saved_evidence_validated': ['u221', 'u220', 'c221', 'u219'],
                  'independent_u220_local_audit': json.loads((tmp / 'independent_u220.json').read_text())['status'],
                  'independent_u219_local_audit': json.loads((tmp / 'independent_u219.json').read_text())['status'],
                  'zero_merge': zero, 'source_transport': source_checks,
                  'machines': machine_checks, 'seconds': round(time.monotonic() - started, 3),
                  'python': sys.version,
                  'scope': 'Executable mathematical certificates and independent finite audits. The Con(PA) calibration is inherited from the included U222 mathematical report; no new proof-assistant kernel endpoint.'}
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
