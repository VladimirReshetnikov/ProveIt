# Independent review of accepted U220

Audited files: `work/machine_reductions/build_u220.py` and the complete `u220_release` tables/source. The reviewed native machine has SHA-256 `7aa87660ee072b7a82b63d48e555ea4567d19b8cedbaab76617c6ba4e4e48a1b`; the source has SHA-256 `232307837f575ee79ffa43a9f8ec1eaf94978d8cd1fe544ed4f6fb64a170fd12`.

## Result

The independent finite checks pass. The construction removes native states200 and145, leaving220 working states and440 binary transitions. I found no defect in the predecessor-tag fold or its composition with the stated source transport and canonical runtime proof.

Fresh receipts:

- `u220_local_independent.json`: independently parsed exact stages, all predecessor entries, complete projected table equality, every helper row, all4 local contexts, exact source rotation, and direct closed-factor tests.
- `u220_transport_independent.json`: independent ordinal-interval CFG resolution and recursive zero-extension checks on all3891 source occurrences/5060 cases.

The new local auditor `audit_u220_independent.py` imports no builder, optimizer, runtime checker, or proof checker. It compares literal table/source data only. The separate source transport auditor computes its graph independently and compares to the root auditor's result.

## Source rotation

At path `11010010011101010110111111100`, the old source has A,(B,C), and the new source has(A,B),C. The three factors have19,28,56 primitive occurrences. My check derives new addresses directly by three prefix substitutions, without constructing or importing the builder's tree:

P0u -> P00u;
P10u -> P01u;
P11u -> P1u.

Exactly103 addresses change. The factor closure check is independent of the builder's recursively computed boundary triple: each decrement has a local enclosing zero edge; each Break(k) has at least k local zero edges; each Continue(k) has at least k local one edges; no factor contains Halt. Thus none exports a break, continue, or halt to its surrounding reassociation context.

The full independently resolved guarded CFG matches U222 exactly, not only the ordered primitive word. The new source has405 longer target words, all with zero suffixes (maximum length7),3308 shorter target words, and1346 equal-length nonterminal targets. Its sole halt case makes the total5060. These establish the canonical address closure needed by the individual literal runtime proofs.

The physical rotation alters four rows before folding. Its abstract source proof and final complete runtime proof apply to canonical program frames and the blank initialization. They do not establish that the physical rotation preserves behavior on arbitrary binary input tapes.

## Exact predecessor-tag premises

In the rotated221-state prefold table V, the full incoming census is:

- state134:156/1 writes1 and movesR;210/1 writes1 and movesR;
- state145:506/0 writes0 and movesR.

Neither state is initial. Consequently every V-run from state0, on every binary tape, satisfies

q=134 -> tape(head-1)=1;
q=145 -> tape(head-1)=0.

This is a one-step last-write invariant, with a vacuous initial case. It does not depend on program syntax, a canonical frame, consistency, or an observed blank-run prefix.

The old rows are

134/0 =0R203,145/0 =0R19,
134/1 =145/1 =1R215.

The helper rows are unchanged in V and U220:

507/0 =0R166;507/1 =1R163;
166/0 =0R19;163/0 =0R203.

The builder's expected-table equality and the independent auditor both confirm that the only change beyond identifying145 with134 is replacing134/0 with0L507. This equality protects natural entries into helper507,163,and166 as well as the newly introduced detour.

## Local simulations and arbitrary exterior tape

Let f identify145 with134 and fix every other state. For all reachable V-configurations c, with identical full tape/head in f(c):

- if c is at134 or145 reading1, one U220 step equals f(one V step);
- if c is at134 reading0, the three U220 steps are
  134/0 ->507 at head-1 ->163 at head ->203 at head+1;
- if c is at145 reading0, the three U220 steps are
  134/0 ->507 at head-1 ->166 at head ->19 at head+1;
- every other V-step is one U220-step under f.

The two three-step paths read only the current zero and the known preceding tag. Their writes preserve both. No other tape cell is read or changed, so arbitrary exterior tape is preserved. The intermediate states507,163,166 and terminal successors203,19 are all working states; no inserted segment can halt internally.

Induction on V steps gives a strictly increasing U220 boundary time, with increments1 or3, and exact full-configuration equality under f at every boundary. This proves forward halting simulation. For reflection, a U220 halt cannot occur inside a three-step detour, and deterministic execution agrees with the simulated V run. If V has not halted by t+1 steps, the simulation supplies at least t+1 U220 nonhalting steps, contradicting a halt by time t. This is a finite arithmetic argument available in PA.

The scope is therefore **every binary tape from state0 of the rotated prefold machine**. It is not an unrestricted relation between all configurations in which state134 or145 could have an incorrect preceding tag. It also does not upgrade the whole U222-to-U220 construction to all-tape equivalence, because the intervening source rotation has the canonical-frame scope described above.

## End-to-end use

The safe proof chain is:

1. The200->112 quotient preserves all state0 executions of U222 exactly in time.
2. The new source has the same ordered register CFG as the old source.
3. The final220-state table passes every symbolic primitive case for that exact source and separately reaches the admissible root seed from blank.
4. Thus both literal machines have the same blank halting predicate, provably in PA by the finite-source and unary/list induction arguments.
5. Compose with the inherited mathematical U222 calibration to Con(U) and Con(PA).

The independent134/145 fold theorem gives an additional local explanation and transport certificate. It is not used as a substitute for the final symbolic check after source reassociation.

No new kernel-checked PA endpoint, literal PA proof object, unconditional consistency assertion, or global minimality theorem follows from these audits.
