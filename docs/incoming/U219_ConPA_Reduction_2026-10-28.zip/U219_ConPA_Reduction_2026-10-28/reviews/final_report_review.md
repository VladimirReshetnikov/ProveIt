# Final report and integrated reproduction review

Reviewed the final mathematical text in `paper/compact.tex`, the updated main theorem, theory-boundary and source/runtime sections in `paper/report.tex`, and the delivered `code/build_u219.py`, `code/reduce_source203.py`, `code/rebuild_source203.py`, and `reproduce.py`.

## Mathematical and numerical conclusions

No concrete mathematical or factual error found in the reviewed text.

Independently counted the archived `construction.json` macro word: it has28 tokens. The separately written postfix string

c 1 c c 1 R c 0 R I Q c 1 c R I I Q 1 1 c R c I Q N I Q

also has28 tokens, not31. The report's28-token count is correct.

The recorded source rotation's factor sizes are162,375,362, and the latter two total737 emitter primitives. Exactly899 final leaf addresses differ from U222; every primitive opcode and argument is retained. The source and CFG counts in the report match the independent receipts.

Literal comparison independently confirms:

- U222->C221 changes68 retained rows, removes507, and adds no state.
- C221->U219 changes3 retained rows and removes200,215.
- U222->U219 changes71 retained rows, removes200,215,507, and adds no state.
- The final native/dense tables each have438 rows; C221 has442.
- The delivered U219 reduction receipt contains8 rejected corrupt-table controls, matching the text.

The primary theorem is correctly stated as the PA-provable blank-halting equivalence with the fixed U222 table, then composed with its supplied mathematical calibration. The proof does not treat Con(PA) as a premise. The compact fold's all-input statement is confined to C221->U219; the U222 correspondence separately uses source/canonical-frame verification and startup. The1/3/5-step simulation, no-intermediate-halt property, and positive boundary times justify both directions of finite halting equivalence. The reported proof status appropriately excludes a new kernel certificate.

## Integrated reproduction gates

No missing gate affecting the claimed construction was found.

`build_u219.py` pins the original U222 table, deterministically rebuilds the compact parent, pins its digest, reconstructs and pins the exact compact source, and invokes the separately pinned two-fold constructor. That constructor validates total binary rows and labels, complete predecessor premises, all nonexceptional commuting rows, exact finite detours, state count, dense renaming, and the8 controls.

The integrated driver then compares regenerated final bytes with the delivered native/dense tables and source. For U221,U220,C221,U219 it checks the exact old/new CFG and zero-suffix closure with both resolvers, total graph-reachable native table and dense row renaming, exact table/source/checker/helper hashes in runtime receipts,3891 sites,5060 expected and proved cases, ordered individual case coverage, positive durations, no reported failures, and successful startup status.

Independent literal bootstrap replay additionally checks the entire trace/support and requires95714 steps, the expected first calibrated root, register seed, gap, head, dispatcher state, and40 spare values equal to1. The `--full` path actually rederives all5060 U219 cases and compares their summaries and complete startup trace. The default honestly identifies its checks as saved-evidence validation rather than fresh symbolic replay. Optimized Python is explicitly rejected where assertions carry obligations.

## Packaging observation communicated to the parent

At the time of this review, the release contained `audit_u220_independent.py` but had not yet copied the new U219 generic no-import auditor or its independent receipts. The parent was notified to include `audit_tag_fold_independent.py`, `u219_local_independent.json`, `u219_negative_controls.json`, and `u219_transport_independent.json`, matching the compact section's statement that a separate no-import auditor checks the primary fold. This is a reproducibility/packaging item, not a defect in the already executed mathematical audit or main construction gates.

Resolution: the parent subsequently copied the generic U219 auditor and independent receipts into the release and added its fresh invocation to `reproduce.py`, using C220 as old table, U219 as new table, and C221 as the parent for the zero fold. The subprocess must exit successfully, and its returned status is recorded. The packaging observation is resolved.
