# Independent semantic audit and comparison of incoming constructions

Audit date: 2026-10-28. Primary source: extracted `sources/u222/u222_consistency_machine`. Other archive paths refer to the current frozen source downloads. This is a mathematical/source review, not a fresh kernel compilation or replay of every competing proposal.

## 1. The exact inherited endpoint and its proof boundary

`paper/report.tex`, Theorem `thm:main`, explicitly claims

PA proves Nonhalt(U222, blank) iff Con(U), and hence iff Con(PA).

The claim is an ordinary mathematical proof whose finite-syntax and finite-run transformations are argued formalizable in PA. The abstract, README, and subsection `Formal status` expressly state that no new Lean, Rocq, or MM0 certificate proves this new literal-table endpoint. The inherited K215 MM0 theorem is about another table and another nonlogical theory. New reductions may preserve U222's mathematical endpoint, but must not claim automatically to inherit K215's kernel certificate.

The strongest clean statement for a new reduction is first a PA-provable finite-run equivalence with the exact U222 table, established without a consistency assumption. Composing with the baseline calibration then gives the requested Con(PA) endpoint with precisely its inherited mathematical proof dependency.

## 2. Which theory the machine actually enumerates

The supplied U is equality-free unary weak power covering. For every formula phi(x) with no other free variables it has

forall a exists b [forall x (E(x,b) -> phi(x)) and forall x (Sub(x,a) -> (phi(x) -> E(x,b)))],

where Sub(x,a) abbreviates forall t (E(t,x)->E(t,a)). Arbitrary bound variables are legal; the source a cannot be free in the U matrix.

U222 emits the unrestricted version W, with arbitrary parameters, plus the retained logical interface. Soundness is calibrated through W+IR, where IR is forall x not E(x,x). Its intermediate native signature includes equality. There is no runtime unary free-variable checker. This is intentional and justified by uniform refutation translations:

Con(U) iff Con(PA) iff Con(W+IR), provably in PA.

The upper interpretation interprets E(x,a) as binary bit membership and primitive equality as arithmetic equality. PA proves Sub(x,a)->x<=a. Formula-specific bounded bit selection produces the desired cover; there is no uniform arithmetic truth predicate. U is a subtheory of W, and the supplied lower interpretation translates PA refutations into U refutations.

## 3. Review of the lower interpretation in the supplied U report

Reviewed `references/theory_U/sections/unary_core.tex` and `unary_arithmetic.tex`. The critical dependency order is internally coherent:

1. Define numerical representatives by saturation, transitivity, linearity modulo coextensionality, and endpoint conditions for intersections with existing objects.
2. Establish empty objects, hereditary numericality, and predecessors of nonempty numbers without assuming total successors.
3. Obtain unary induction using the weak cover of failures over a numerical source. If there is a failure below the source, choose its least class; otherwise use the source itself as the least failure. This avoids the successor-existence circle.
4. Absorb arbitrary parameters into the unary formula Q(v)=forall p (A_theta(p)->theta(v,p)), where A_theta is the conjunction of induction hypotheses.
5. Derive comparison and global minimization for invariant numerical tuples.
6. For bounded numerical comprehension, bind a least failing parameter tuple inside the unary matrix. The support source is chosen externally in the proof and does not become an illegal free source variable in that matrix.
7. Derive successors, powers of numerical objects, saturated Kuratowski pair codes, and numerically parameterized graph comprehension.
8. Canonical history extension quantifies over prior history graphs instead of using an arbitrary graph as a free filter parameter. Pointwise uniqueness of histories is proved before this existential union is used.
9. Obtain arithmetic operations and translated induction.

I found no concrete new counterexample or logical contradiction in these reviewed steps. This review is not a replacement for a complete proof-assistant formalization. In particular, the final finite-run reduction should retain this proof as an inherited dependency rather than strengthen its status.

## 4. Emitter details that must remain fixed

The final U222 source uses selector n=c, simultaneously a matrix code and output-variable label. For positive code n, constructor growth puts every variable label in its decoding below n. Source and tested roles are fixed to labels0 and1. The local guard quantifies the dynamic label n, shadowing the output binder only inside the guard, where the output is not referenced. The old outer vacuity gate c!=a,b is unchanged.

Both small cases n=0 and n=1 are treated in the final paper. At n=0 the local binder shadowing turns the guard into emptiness under IR. The shell asks for an object containing all empty objects, which follows by true-covering an empty source. At n=1 the matrix is false under IR and the remaining upper clause is harmless. These facts permit deleting a runtime increment of the selector.

The historical note `references/theory_bridge_notes.txt` describes an earlier n=c+1 variant and says n=0 must not be admitted. That warning is superseded by the final paper's explicit local-binder calculation. Do not use that note as the authoritative final emitter definition.

For preserving the current source, the exact postfix word is:

c 1 c c 1 R c 0 R I Q c 1 c R I I Q 1 1 c R c I Q N I Q.

The full numerical equality logic and membership vacuity are retained. Removing equality machinery merely because U itself is equality-free would need a new completeness argument. The source-role/test-role guard cannot be applied to the whole vacuity bundle, because diagonal membership vacuity is still needed.

## 5. Comparison of the other incoming proposals

| Package | Primary method | Reusable point for U222 | Limits of direct transfer |
|---|---|---|---|
| `U222_ConU_2026-10-28.zip` | Short fixed-role W emitter in K215 runtime, n=c self-fresh binder, exceptional cases handled | Best starting source:3891 occurrences,204 subtrees; baseline runtime uses5060 symbolic cases | Strong deterministic state bisimulation gives222 singleton classes; contextual reductions still possible |
| `u228_pa_consistency_2026-10-28.zip` | Fixed roles1/0, k>1 gate,229-state parent then identical-row quotient | Scan for identical complete rows before harder optimization; precise all-tape quotient theorem | Its native26 and310 have identical rows(0R37,1R38); U222 lacks this duplicate. Source has3950 leaves and retains the extra gate |
| `u232_con_u_construction.zip` | PA source adapted to K runtime;26 closed helper replacements; rotations; moved increments; role reallocation | Finite register-offset bisimulation validates commuting increments and candidate-counter shifts; freeing an overly constraining retained role can save more than local DAG minimization | Its source, seed, and table differ. Native108 is reassigned, not blindly deleted |
| `PA236_Unary_Power_Covering_2026-10-28.zip` | Six source reassociations and two predecessor-bit selector folds on PA238 | A previously written address bit is free context storage; an existing helper can inspect it in a3-step detour and share a selector | First rotation alone creates a7-zero address at ordinal460 and breaks the primitive audit. Valid local fold is not enough; all source round trips must pass |
| `U237_ConU_2026-10-28.zip` | Deletes old PA238state1, fuses initializer/runtime behavior with4 changed rows | Initializer can reuse a runtime state when both branches are justified | Uses PA runtime labels/seed; no direct U222 row substitution |
| `u237_construction.zip` | Seven-node destructive equality helper, shared continuation, one-node/source-state saving | A loop may repeat a now-trivial successful equality check to share Continue2; total helper contracts justify source replacement | Requires new helper semantics and literal contexts; cannot infer state count from source DAG alone |
| `u237_research_package.zip` | Deletes old PA238state1, changes zero-decrement return and initializer | Known-written zero cells and control phases can license context-limited row sharing | Must check every physical register including register0 and complete canonical startup |

Specific U232 data: its direct old/new source certificate has2646 product nodes and tracks integer register offsets. Moving candidate increment changes the initial potential to(1,0,...,0); the zero-test side condition requires offset0 in the tested register. Commuting increment of R5 past transfer R6->R5 creates temporary offset in R5 that is never tested and cancels at exit. Its decisive allocator change stopped retaining native108's decoder role: protected rows205->181, retained logical roles77->52, retained physical states73->50, helper rows91->46. Final source still has4409 occurrences; it is not the U222 emitter.

Specific PA236 folds: after rotations, native200 and208 have different preceding bit tags and a shared read-one row; the read-zero split is recovered by a3-step detour through helper230. The second fold uses222 and180, splitting on read-one via helper203. Both have ordinary finite-stuttering proofs and no intermediate halt. A second source rotation is essential to restore maximum zero-run6.

Specific U237 equality helper: with x=R6,y=R5, a7-node tree clears both registers and returns Normal iff x=y, otherwise Break1. Replacing a subsequent clear loop's Continue1 by Continue2 repeats the whole equality+clear conditional; after initial success the equality operands are0,0, so the repeat remains successful and terminates by the decremented target register. This demonstrates source-level semantic sharing beyond parenthesization.

## 6. Proof obligations for the new reduction

A native merge based on an entry invariant needs a proof for every possible predecessor, not just for the observed blank run. If state200 is merged into112, use the original-machine invariant and a relation mapping the two states; do not assume the original112 right-neighbor invariant remains literally true for every merged-state occurrence.

A closed-source reassociation should check both the primitive word and all resolved guarded CFG destinations. Break and continue counts refer to tree ancestors, so identical leaf words alone do not suffice. The primary source auditor already has an independent interval-based CFG resolver.

For a new table implementing a reassociated source, prove every primitive case over complete canonical tapes: arbitrary natural register values and gap; arbitrary first spare and finite spare tail; exact head, state, all tape cells, and a positive finite duration. The initial blank computation must be separately replayed to an admissible seed. Marker motion and appended spares must remain in the endpoint frame.

Formal PA transport uses elementary coding and induction: each local finite derivation, unary scan induction, and finite-list block induction is arithmetizable; finite concatenation translates source runs into literal runs. Positive local durations and absence of intermediate halt give the converse finite-run direction. A deterministic source CFG equivalence then identifies the two halting predicates. This argument does not assert Con(PA).

## 7. Further research directions worth retaining

- Export the new finite table transformation and entry invariants into a small PA/MM0 proof certificate, separate from the still-unmechanized U calibration.
- Add proof-producing predecessor-tag analysis to the allocator instead of treating such folds as ad hoc postprocessing.
- Optimize source DAG and physical context sharing jointly; the smaller DAG need not admit the smaller correct physical table.
- Investigate seven-node destructive equality/helper replacements against U222's current core, with all-natural contracts and full source binding, rather than transplanting PA238 states by label.
- Mechanize the unary U interpretation, especially least-failure comprehension and canonical history extension, to close the largest inherited proof boundary.
