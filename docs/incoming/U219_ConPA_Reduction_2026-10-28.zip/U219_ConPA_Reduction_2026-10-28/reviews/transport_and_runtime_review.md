# Source transport and symbolic runtime audit

Scope: independent inspection of `work/root_review/audit_transport.py`, `references/logic/RM.v`, and the full U222 `code/runtime/symbolic_runtime.py` plus its helper and native wrapper. No proof assistant was run. The review uses source-level proofs of the checker rules rather than treating packaged success reports as a kernel certificate.

## Source CFG transport

The root auditor's `carry`, `erase_suffix`, and `resolve` agree with the inherited RM.v path semantics:

- RM.bit supplies zero after the stored address ends.
- RM.walk follows that zero extension until a leaf.
- RM.rm_step truncates or zero-extends the stored word to the number of actually consumed bits before applying an instruction.
- CI and positive CD use binary increment at that consumed depth.
- Zero CD and CB remove the suffix through the required zero and increment the remaining prefix.
- CC removes the suffix through the required one.
- CH is terminal, and has no successor register configuration.

For all-ones carry, RM.inc_rev deliberately discards the final overflow: the resulting address is all zeros. The physical frame may shift left and its gap increase, but the decoded logical successor is the first leaf. Empty-address carry likewise returns the empty word and resolves the first leaf. Exhausted strip returns the empty word. The generic path theorem therefore does not need a separate source-closedness assumption, although closed source factors are one convenient way to obtain equivalent graphs.

A finite full prefix-free binary tree has an all-zero first leaf. Thus the empty starting address decodes leaf ordinal0, which is preserved when the two ordered CFGs agree. A matching ordered operation/argument list and every guarded successor ordinal gives a lockstep register-machine bisimulation on (leaf ordinal, register tuple). Induction on finite executions preserves halting both ways, with no theory consistency premise. This proof is primitive-recursive and PA-formalizable.

### Physical canonical-frame closure

The first version of resolve discarded the unused suffix after reaching a leaf without checking it. That is sound for RM.rm_step, which explicitly truncates there. A literal-frame composition additionally needs any unused stored bits to be zero, because individual runtime proofs start from the leaf word followed by zero padding. I reported this distinction immediately. The parent added an explicit zero-suffix check; it now returns closure facts with the CFG certificate.

For the exact baseline and preliminary rotbest_203_6 source, the independent check found no failure. Each has406 successor words longer than the selected leaf and every extra bit is0, with maximum extra suffix length7. The baseline has3307 shorter words, and the rotated candidate3311; zero-extending them gives exactly the full leaf word and the same complete tape. Equal-length nonterminal targets are1346 and1342 respectively. Together these account for5059 nonhalting primitive cases; the sole CH case makes5060.

The independent resolver in `check_source_independent.py` uses subtree ordinal intervals: CI advances to i+1 modulo the leaf count; break exits at the selected enclosing subtree's end; continue enters its start. It imports the root code only to compare outputs, not to resolve its own graph. A second recursive target-word implementation follows RM.v directly and checks canonical closure. Both agree on all3891 leaves of the baseline and the preliminary rotated source; all5060 guarded cases and all operation arguments match. The candidate changes740 leaf addresses. Receipt: `rotbest_transport_independent.json`.

The root theorem is about these exact source bytes. It says nothing by itself about whether a new physical decoder implements them. That remains the separate all-primitive runtime audit.

## Zero-cell merge audit

The root merge check enumerates every incoming edge of native112 and200. The exact premises are:

172/0 -> write0, moveL,112;
112/1 -> write1, moveR,200;
112/0 = 200/0 = write0, moveR,157.

From any initial tape in state0, every original visit to112 has tape(head+1)=0, because its sole predecessor just wrote that cell. Therefore every original visit to200 reads0. Mapping original200 to112 preserves every permitted literal step, tape, head and exact time. The equality check for all other projected rows prevents unrelated mutations. The induction is on the original machine; one must not demand the original112 right-neighbor invariant at every occurrence of the merged state. The check and its stated all-binary-input scope are correct.

## Symbolic runtime rule soundness

### Representation and exact steps

A State has two near-to-far tape sides and a direction identifying which side contains the current cell. On a direction-preserving move, one current cell is transferred to the opposite side. On a direction reversal, the written cell is put back on the same side and the newly selected side supplies the new current cell. This correctly models head motion, including successive reversals. `motion` separately tracks absolute displacement, and nonhalting closure checks it against the expected sentinel shift.

A run length is an affine expression in13 nonnegative integer slots: constant, gap,9 primary values, first-spare value, and remaining-list width. `normal` refuses any negative coefficient. A literal step is permitted only with a positive constant term, so the read cell exists for every valuation. This is a sufficient condition, not an unsafe assumption about a possibly empty symbolic run.

### Unary scan induction

If the exact table transition returns to the same state and moves in the currently represented direction, traversing a homogeneous run of length n is proved by induction on n. The write symbol may differ from the read symbol: monotone motion guarantees that subsequent reads encounter the original unvisited run. The n=0 case is identity. Time and motion add exactly n and +/-n. This rule does not sample a register bound.

### Finite-list traversal

`prove_blocks` establishes all4 one-block contracts from the supplied table itself. It uses a symbolic arbitrary value v, arbitrary opaque left and right contexts, and only literal and unary-scan steps. No opaque context may be entered. Every proof returns to the same entry state/direction with precisely the transformed complete block and has duration v+2. Iterating it over an arbitrary finite list is justified by list induction, with the empty-list identity as base.

The single tail variable always refers to the same spare list, with width sum(v+2) over its blocks. Families B(v)=0 1^(v+1) and C(v)=1 0 1^v have equal width, so each transform preserves that parameter. Treating width as an independent nonnegative number strengthens the affine equality conditions; it does not narrow the quantified tape domain. The atom's reverse flag is correctly flipped when traversed to the other side. Native table labels are bijectively mapped to the legacy checker labels; for example the checker block entry112 is native97, not the native112 involved in the zero-cell merge.

### Normalization identities

Combining adjacent runs and dropping zero-length runs are literal word identities. A finite zero run adjoining the represented infinite blank exterior can be absorbed without changing the tape.

For every finite value list A,

C(A)1 = 1B(A).

Proof by list induction: empty gives1=1; for A=v::A', substitute the induction hypothesis into 1 0 1^v C(A')1 to obtain1 0 1^(v+1)B(A')=1B(A). Reversal gives the other normalization identity. The code requires a positive constant before removing the distinguished1. Its rewrites therefore remain valid for every valuation, including the empty spare tail.

### Primitive closure and halt

Each case starts from a complete canonical tape with blank exteriors and matches a complete target State, including gap, every primary register, spare data and sentinel translation. Positive CD is parametrized by1+v, zero CD by0; other register values remain independent. The arbitrary first spare guarantees a nonempty full spare list while the tail may be empty.

For CH, reaching the unique terminal state is sufficient. For other primitives, an internal halt causes the following literal lookup to fail; no successful nonhalting proof can silently cross it. A successful case requires an affine duration with positive constant and nonnegative coefficients, excluding zero-time or negative-time macro progress. The finite proof-search limit bounds derivation construction only.

I found no unsound rule in the inspected symbolic engine. Its PA-formalizability follows from elementary finite-string/list coding, natural-number induction for runs, and list-length induction for traversals. A successful finite derivation could in principle be emitted as a PA proof; this implementation does not export one.

## Wrapper and trust boundary

The inherited native wrapper deliberately bypasses an obsolete source pin in the generic checker's historical CLI. Correct use therefore requires separate exact-source/table/hash checks, total binary table validation, the corrected source/CFG audit, and independent bootstrap validation. Its runtime PASS flag alone does not imply startup success: the final reproduction driver must require the accepted calibrated startup status as a separate gate. The baseline release driver already does this; the new driver must retain it.

This review supports calling the checks unbounded symbolic mathematical verification. It does not support calling the new machine kernel-verified, proving actual nonhalting, or asserting global state minimality.
