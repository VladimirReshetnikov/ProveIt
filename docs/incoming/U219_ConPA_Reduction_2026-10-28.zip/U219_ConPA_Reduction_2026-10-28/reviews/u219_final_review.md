# Independent review of U219 compact-source construction

Reviewed the complete `reduce_source203.py` and `source203_native/reduction_certificate.json`, then independently checked the native tables without importing either builder or the runtime engine.

## Exact identities and result

- Compact221-state parent: SHA-256 `4d50d9be985b17128b6ef4e2b7ead6cbf558d6ee7220319bb5104fdc8fc7d7bf`.
- After200->112:220-state native table `f1e95bf939bb3724377fad20d517608aa4e4e75b739f7264ba524b25dde7dc0e`.
- Final219-state native table: `db4336efc76cdbce6963ae3a54832264d1c01f72cf14fadc423664475467fd6b`.
- Compact source: `dcda0584455a2cbfed0f374c8159f844b43d86b59087a6916487846764f7624f`.

All independent local premises and source-transport checks pass. The final machine has219 working states and438 rows. The complete final runtime receipt is present and reports5060 proved cases, no failures, and calibrated blank startup, with the identities above.

The new reusable independent tool is `audit_tag_fold_independent.py`. It accepts old/new native table paths and keep/drop/tag parameters; it imports no optimizer, constructor, or symbolic proof engine. Optional `--parent` also checks the preceding200->112 zero-cell quotient. Results are in `u219_local_independent.json`. Its three deliberately corrupted controls are rejected, including a corruption applied consistently to both tables so that row-projection checks alone would not catch it; see `u219_negative_controls.json`.

## The215->182 fold

In the220-state prefold machine, the complete incoming census is:

-182 has exactly one incoming edge:173/1 writes1 and movesR.
-215 has exactly one incoming edge:129/0 writes0 and movesR.

Neither is state0. Hence every execution from state0, on arbitrary binary tape, satisfies the last-write invariants

q=182 -> tape(head-1)=1;
q=215 -> tape(head-1)=0.

Their original transitions are:

182/0 =0R76;215/0 =0R90;
182/1 =215/1 =1R61.

The final table identifies215 with182 and replaces182/0 by0L209. Every other surviving row is exactly the projected old row. The following helper rows are literally unchanged:

209/1 =1R133;133/0 =0R76;
209/0 =0R157;157/0 =0L67;67/0 =0R151;151/0 =0R90.

These are existing transitions; no helper states are added. Natural old uses of those helpers remain unchanged.

### All4 local cases

The independent auditor checks both old states and both scanned bits, using only two initialized cells and refusing to read any other cell.

1. Old182,preceding1,current0: new182 at h moves through209 at h-1,133 at h,and ends76 at h+1 after3 steps.
2. Old215,preceding0,current0: new182 at h moves through209 at h-1,157 at h,67 at h-1,151 at h,and ends90 at h+1 after5 steps.
3. Old182,preceding1,current1: unchanged1-step transition to61 at h+1.
4. Old215,preceding0,current1: the same1-step transition to61 at h+1.

Every path restores both known cell values exactly. No other tape position is read or written, so the full arbitrary exterior tape agrees. None of209,133,157,67,151 is the halt state254, and the inserted paths cannot halt internally.

The finite checks do not assume that state182 in the reduced machine always has preceding1. It represents both original tagged cases. The invariant belongs to the original prefold execution, and the simulation relation records its original state before applying the collapse.

### Universal statement and reflection

Map old215 to182 and fix every other state. For every old run from state0 and any binary initial tape, each original step has an exact mapped simulation of1,3,or5 new steps, with identical tape and head at the end. Induction constructs increasing boundary times; all increments are positive. Halting is preserved. Reflection follows because no extra halt occurs inside an inserted segment, and determinism identifies the new run with these concatenated segments. Equivalently, a new halt by time t and an old run avoiding halt for t+1 steps would conflict with the existence of at least t+1 simulated nonhalting steps.

All the reasoning is elementary finite syntax, integer displacement, and induction on finite executions. It is formalizable in PA. The equivalence is valid on all tapes starting in state0 of the compact prefold machine; no blanket relation is asserted on wrong-tag configurations supplied directly in182 or215.

## Preceding zero-cell quotient

The compact221-state parent still has exactly the entry premises required for200->112:

172/0 writes0 and movesL to112;
112/1 writes1 and movesR to200;
112/0 =200/0 =0R157.

The independent auditor checks the full incoming census and every projected row. This stage preserves tape/head at every literal time from state0 on every binary tape, as in the baseline U221 proof. It composes with the positive-stuttering tag fold to yield the compact parent-to-U219 all-tape equivalence.

## Compact source transport and canonical closure

The independent interval-based CFG and separate recursive address checker pass on the compact source versus U222:

-3891 primitive occurrences;
-5060 guarded cases;
-every opcode,argument,and successor ordinal identical;
-405 longer successor words,all residual bits zero,max length6;
-3308 shorter successor words,completed by zeros;
-1346 equal-length nonterminal successor words;
-one halt case.

Receipt: `u219_transport_independent.json`. This check is not a source-DAG metric alone: it verifies all conditional destinations and the zero-extension property required for whole-tape runtime composition.

The parent-to-U219 native folds have all-input-tape scope. The preceding conversion from U222 to the compact physical parent uses source transport and canonical-frame implementation, not an arbitrary-tape equivalence. The final end-to-end statement therefore uses complete symbolic runtime simulation plus calibrated blank initialization and then the inherited U222 mathematical consistency calibration.

## Proof status

No defect found in the inspected fold or source transport. The final symbolic runtime evidence has been inspected and its hashes agree, but this audit is not a fresh proof-assistant compilation. The new machine inherits U222's mathematical PA-provability/Con(PA) calibration, including the supplied unary U interpretation. It does not inherit K215's kernel certificate for a different table.
