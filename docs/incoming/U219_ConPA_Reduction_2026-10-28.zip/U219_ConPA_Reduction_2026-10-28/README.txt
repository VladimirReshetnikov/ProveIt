U219: REDUCING THE PRIMARY U222 PA CONSISTENCY MACHINE
28 October 2026

RESULT
======

The primary table machine/u219.tm has 219 working states and 438 transition
rows, two symbols, one two-way infinite tape, one head, blank input, and
left/right moves only. Initialization is counted. The start is state 0;
the separate halt label is 219. This is three working states below U222
and nineteen below the user's 238-state reference.

The new mathematical reduction is

  PA proves Halt(U219, blank) <-> Halt(U222, blank).

Composing with the supplied U222 calibration gives

  PA proves Nonhalt(U219, blank) <-> Con(U) <-> Con(PA).

The release supplies ordinary mathematical proofs, a PA-formalizability
argument, and fresh executable symbolic verification. It does not supply
a newly compiled Lean, Rocq, or MM0 kernel certificate for this endpoint.
The supplied U222 mathematical calibration remains an explicit dependency.
The K215 certificate is about a different machine and theory. No global
minimality or unconditional consistency/nonhalting claim is made.

START HERE
==========

  paper/report.pdf             Complete report, proofs, and 438-row table
  paper/report.tex             Editable LaTeX source
  paper/compact.tex            Detailed primary U219 construction
  machine/u219.tm              Exact dense-label primary machine
  machine/u219.native.tm       Same machine with original compiler labels
  machine/u219.sites.json      Exact register-program source addresses
  machine/u219_state_map.json  Native/dense bijection
  machine/u219_summary.json    Counts and SHA-256 identities
  reproduce.py                Integrated portable reconstruction and audit
  evidence/u219/              Full symbolic cases, startup, local certificate
  reviews/                    Independent mathematical and source audits

The archive also retains a particularly simple U221 reduction and a U220
variant with only four retained transition-row changes relative to U222.
U220 and the compact intermediate C220 are different tables; filenames
distinguish them explicitly. The unchanged U222 input release, including
its theory U paper and original manifest, is under baseline/u222/.

HOW THE THREE STATES ARE SAVED
==============================

1. Reparenthesize the same closed emitter factors and perform one closed
   source rotation. The source has 203 distinct subtrees rather than 204,
   but the same 3,891 primitive occurrences and all 5,060 guarded CFG cases.
   A verified allocation yields the 221-state compact parent C221, removing
   native state 507. Its exact table is machine/c221.native.tm.

2. Collapse native state 200 into 112. Every entry to 112 leaves a zero
   immediately right of the head; its read-one transition moves onto that
   zero in state 200. The two states have identical read-zero actions.

3. Collapse native 215 into 182. Their preceding tape bits identify the
   old state (0 versus 1). An existing helper beginning at 209 reproduces
   the distinct zero branches in five or three steps. Their one branches
   already agree. All inspected cells and the head endpoint are preserved.

The two folds alone preserve arbitrary binary initial tapes of C221 from
state 0. The whole U222-to-U219 equivalence additionally uses the verified
source correspondence and canonical blank initialization. It is not an
arbitrary-input equivalence between the differently encoded source layouts.

VALIDATION
==========

Each of U221, U220, C221, and U219 passed all 5,060 symbolic cases over the
3,891 instruction occurrences. Registers, the extra code-field gap, and
the spare-register list are unbounded symbolic data. The proof rules are
literal stepping, natural-number induction over unary runs, and finite-list
induction over exactly checked block schemas. These are executable
mathematical derivations, not a proof-assistant kernel check.

Every machine independently replays 95,714 literal steps from blank to:
native dispatcher 84, head -8, gap 1, logical registers [4,0,0,0,0,0,0,0,0],
and 40 spare registers each equal to 1. The whole tape is compared.

Independent audits compare all opcodes, arguments, and branch destinations;
check that unused successor-address suffixes are zero; validate complete
incoming-state invariants; replay the short selector detours; and check
the complete native/dense state renaming. Negative controls corrupt
markers, entry tags, helper branches, and return targets and are rejected.

REPRODUCE
=========

Python 3.10+ and its standard library suffice. Use an ordinary interpreter
without -O. No network, solver, third-party Python package, external
checkout, or proof-assistant installation is needed.

  python3 reproduce.py

This reconstructs every accepted table and source, checks the original U222
release and all local/independent audits, validates saved symbolic evidence,
and independently replays startup. Its receipt explicitly says that the
symbolic cases were not freshly repeated.

  python3 reproduce.py --full

This additionally rederives all 5,060 universal cases for the primary U219
and compares the new case summaries and startup to the saved evidence.
It ordinarily takes a few minutes. Temporary outputs go outside the release.
An optional --report /absolute/path/receipt.json writes a chosen receipt.

To regenerate the paper's metadata and transition appendix:

  python3 code/build_document_data.py

To compile the PDF, run twice from paper/:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex

Regenerating PDF bytes or modifying files invalidates the published
SHA256SUMS manifest; keep an unchanged copy for artifact-integrity audits.
PDF timestamps and TeX versions do not change the machine identity.

PRIMARY BYTE IDENTITIES (SHA-256)
===============================

Dense U219 table:
9e4b8470ed24d8cc70bba24008835e62a373c302946b1661cf5c37afe1d06ca3

Native U219 table:
db4336efc76cdbce6963ae3a54832264d1c01f72cf14fadc423664475467fd6b

U219 source-site file:
dcda0584455a2cbfed0f374c8159f844b43d86b59087a6916487846764f7624f

PROVENANCE AND ATTRIBUTION
==========================

PROVENANCE.json records the pinned public repositories and every inspected
incoming archive's SHA-256. The complete original U222 input and its theory
report are retained, as are their upstream notices. licenses/ includes the
ProveIt, K215, Mira-Cult/Mira architecture, and Wade-related attribution
supplied with the baseline. New reduction code, local proof checks, report,
and integration were prepared for this request. Historical path strings
inside evidence describe provenance; they are not runtime dependencies.

Further research questions and the rejected arithmetic-entry allocation
are discussed in the report. The rejection is retained separately and is
not included among accepted candidate tables.
