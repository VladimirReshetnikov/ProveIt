#!/usr/bin/env python3
"""Reconstruct the accepted compact source and literal U219, without a solver."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
from certify_u221 import read, need
from build_u220 import encode

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    recipe = json.loads((HERE / 'compact221_table_recipe.json').read_text())
    baseline = args.baseline / 'machine/u.native.tm'
    need(sha(baseline) == recipe['baseline_sha256'], 'Baseline table digest')
    original = read(baseline)
    table = dict(original)
    for q, b, w, d, target in recipe['changed_rows']:
        need((q, b) in table, 'Unexpected new allocation row')
        table[q, b] = w, d, target
    for q in recipe['removed_states']:
        del table[q, 0]
        del table[q, 1]
    parent = args.output / 'c221.native.tm'
    parent.write_bytes(encode(table))
    need(sha(parent) == recipe['native_sha256'], 'Compact parent digest')
    subprocess.run([sys.executable, '-B', str(HERE / 'rebuild_source203.py'),
                    str(args.baseline), str(args.output / 'sites.json')], check=True)
    need(sha(args.output / 'sites.json') == recipe['source_sha256'], 'Compact source digest')
    subprocess.run([sys.executable, '-B', str(HERE / 'reduce_source203.py'),
                    str(parent), str(args.output / 'folds')], check=True)
    for name in ['u219.native.tm', 'u219.tm', 'reduction_certificate.json']:
        (args.output / name).write_bytes((args.output / 'folds' / name).read_bytes())
    (args.output / 'c220.native.tm').write_bytes((args.output / 'folds/u220.native.tm').read_bytes())
    print(json.dumps({'status': 'U219_DETERMINISTIC_REBUILD_PASS',
                      'source_sha256': sha(args.output / 'sites.json'),
                      'parent_sha256': sha(parent),
                      'native_sha256': sha(args.output / 'u219.native.tm'),
                      'dense_sha256': sha(args.output / 'u219.tm')}, indent=2))


if __name__ == '__main__':
    main()
