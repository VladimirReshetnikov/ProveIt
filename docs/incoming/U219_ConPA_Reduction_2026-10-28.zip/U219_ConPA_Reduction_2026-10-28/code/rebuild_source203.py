#!/usr/bin/env python3
"""Deterministic reconstruction of the 203-node source, with no search/solver.
Uses U222's archived source-tree functions; consistency calibration is inherited.
The independent ordinal-CFG equality check is deliberately separate.
"""
from pathlib import Path
import sys,json,hashlib,argparse
if not __debug__ or sys.flags.optimize:raise RuntimeError('Assertions must be enabled for source replay')
HERE=Path(__file__).resolve().parent

def run(bundle,output):
 sys.path.insert(0,str(bundle/'code'))
 import build_source as b
 baseline=bundle/'inputs/k215_sites.json'
 recipe=json.loads((HERE/'source203_recipe_before_rotation.json').read_text())
 before=b.build(baseline,recipe)
 info=json.loads((HERE/'source203_rotation.json').read_text())
 t=b.parse(json.loads(before));rotation=info['rotation']
 assert rotation['direction']=='left' and rotation['paths']==['1101001001110101011011111']
 path=rotation['paths'][0]
 def replace(t,p):
  if not p:
   A,bc=t;B,C=bc
   assert all(b.boundary(x)==(0,0,False)for x in(A,B,C))
   assert json.loads(json.dumps(t))==rotation['old']
   z=((A,B),C)
   assert json.loads(json.dumps(z))==rotation['new']
   return z
  bit=int(p[0]);return (replace(t[0],p[1:]),t[1])if bit==0 else(t[0],replace(t[1],p[1:]))
 t=replace(t,path);raw=(json.dumps(b.sites(t),separators=(',',':'))+'\n').encode()
 assert hashlib.sha256(raw).hexdigest()=='dcda0584455a2cbfed0f374c8159f844b43d86b59087a6916487846764f7624f'
 assert b.metrics(t)=={'dag_nodes':203,'leaf_occurrences':3891,'maximum_depth':45,'maximum_zero_run':6}
 output.write_bytes(raw)
 return {'status':'PASS','source_sha256':hashlib.sha256(raw).hexdigest(),'metrics':b.metrics(t),'rotation_path':path,'all_three_factors_closed':True}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('bundle',type=Path);p.add_argument('output',type=Path);a=p.parse_args();print(json.dumps(run(a.bundle,a.output),indent=2))
