#!/usr/bin/env python3
"""221 -> 219 native-state reductions with explicit finite invariant checks."""
from pathlib import Path
import argparse,json,hashlib

def need(condition,message):
    if not condition:raise ValueError(message)

def read(path):
    table={};starts=[]
    for line in path.read_text('ascii').splitlines():
        if line.startswith('#! start '):starts.append(int(line[9:]))
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need(d in('L','R')and (q,b)not in table,'malformed transition')
        table[q,b]=(w,1 if d=='R'else -1,z)
    need(starts==[0],'start state')
    states={q for q,b in table}
    need(set(table)=={(q,b)for q in states for b in(0,1)},'total binary rows')
    need(0 in states and 254 not in states,'start/halt labels')
    need(all(w in(0,1)and d in(-1,1)and z in states|{254}for w,d,z in table.values()),'invalid transition')
    return table

def encode(table):
    return ('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(table.items()))).encode('ascii')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def zero_fold(T):
    need([(q,b)for(q,b),v in sorted(T.items())if v[2]==112]==[(172,0)],'112 sole predecessor')
    need(T[172,0]==(0,-1,112),'right neighbor zero')
    need([(q,b)for(q,b),v in sorted(T.items())if v[2]==200]==[(112,1)],'200 sole predecessor')
    need(T[112,1]==(1,1,200),'zero marker return')
    need(T[200,0]==T[112,0]==(0,1,157),'common zero action')
    f=lambda q:112 if q==200 else q
    R={(q,b):(w,d,f(z))for(q,b),(w,d,z)in T.items()if q!=200}
    for(q,b),(w,d,z)in T.items():
        if q==200 and b==1:continue
        need(R[f(q),b]==(w,d,f(z)),'step correspondence')
    return R

def tag_fold(T):
    # In the original machine every entry to182 writes1 immediately left;
    # every entry to215 writes0 immediately left. Neither is the start state.
    incoming={}
    for q,tag in[(182,1),(215,0)]:
        es=[(p,b,w,d)for(p,b),(w,d,z)in sorted(T.items())if z==q]
        need(es and all(w==tag and d==1 for p,b,w,d in es),'constant previous-cell tag')
        incoming[q]=es
    need(T[182,1]==T[215,1]==(1,1,61),'common one branch')
    need(T[182,0]==(0,1,76)and T[215,0]==(0,1,90),'old zero branches')
    f=lambda q:182 if q==215 else q
    R={(q,b):(w,d,f(z))for(q,b),(w,d,z)in T.items()if q!=215}
    R[182,0]=(0,-1,209)
    # Unchanged contexts commute literally. Zero branches use finite traces.
    for(q,b),(w,d,z)in T.items():
        if q in(182,215)and b==0:continue
        need(R[f(q),b]==(w,d,f(z)),'literal nonexceptional transition')
    traces=[]
    for old,tag,target,steps in[(182,1,76,3),(215,0,90,5)]:
        tape={-1:tag,0:0};before=tape.copy();q,h=182,0;trace=[]
        for tick in range(steps):
            need(h in tape,'context path reads unknown tape')
            w,d,z=R[q,tape[h]];trace.append([q,h,tape[h],w,d,z]);tape[h]=w;h+=d;q=z
        need(tape==before and h==1 and q==target,'finite-stutter target')
        traces.append({'old_state':old,'previous_bit':tag,'steps':steps,'trace':trace})
    return R,{'incoming':incoming,'traces':traces,'scope':'any binary tape initially in state0; at each old step the reduced machine takes1,3,or5 steps and restores exact tape/head after state collapse'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('input',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    need(sha(a.input)=='4d50d9be985b17128b6ef4e2b7ead6cbf558d6ee7220319bb5104fdc8fc7d7bf','source203 table pin')
    T=read(a.input);S=zero_fold(T);U,cert=tag_fold(S)
    qs=sorted({q for q,b in U});need(len(qs)==219 and len(U)==438,'state census')
    ren={q:i for i,q in enumerate(qs)};ren[254]=219;D={(ren[q],b):(w,d,ren[z])for(q,b),(w,d,z)in U.items()}
    for name,M in [('u220.native.tm',S),('u219.native.tm',U),('u219.tm',D)]: (a.output/name).write_bytes(encode(M))
    controls=[]
    for name,mut in [('corrupt zero-marker write',{(172,0):(1,-1,112)}),('extra unguarded entrance112',{(0,0):(1,1,112)}),('extra unguarded entrance200',{(0,0):(1,1,200)}),('corrupt merged zero row',{(200,0):(1,1,157)})]:
        try:zero_fold(T|mut)
        except ValueError as e:controls.append({'name':name,'status':'REJECTED','reason':str(e)})
        else:raise ValueError('negative control accepted')
    for name,mut in [('corrupt old182 tag',{(173,1):(0,1,182)}),('corrupt old215 tag',{(129,0):(1,1,215)}),('corrupt helper209 branch',{(209,1):(1,1,157)}),('corrupt five-step return',{(151,0):(0,1,19)})]:
        try:tag_fold(S|mut)
        except ValueError as e:controls.append({'name':name,'status':'REJECTED','reason':str(e)})
        else:raise ValueError('negative control accepted')
    report={'status':'U219_TWO_INVARIANT_REDUCTIONS_PASS','input_sha256':sha(a.input),'native_sha256':sha(a.output/'u219.native.tm'),'dense_sha256':sha(a.output/'u219.tm'),'working_states':219,'rows':438,'native_to_dense':ren,'deleted_native_states':[200,215],'zero_fold_invariant':['q112 => tape[h+1]=0','q200 => tape[h]=0'],'tag_fold':cert,'negative_controls':controls,'required_original_rows':[[q,b,*T[q,b]]for q in[67,112,129,133,151,157,172,173,182,200,209,215]for b in(0,1)],'changed_retained_rows':[[q,b,*T[q,b],*U[q,b]]for q,b in U if T[q,b]!=U[q,b]],'source_boundary':'This certificate preserves its compact221 input table on any initial tape in state0. Equivalence to original U222 additionally uses the separately checked source reassociation and canonical runtime frames.'}
    (a.output/'reduction_certificate.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='native_to_dense'},indent=2))
if __name__=='__main__':main()
