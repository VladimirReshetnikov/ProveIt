#!/usr/bin/env python3
"""Deterministic U222 -> U221 -> U220 construction; standard library only.

Source boundary and CFG conventions follow the attributed K215/U222 source
language. The physical patch and both local invariant certificates are new.
This supplies executable mathematical checks, not a proof-assistant artifact.
"""
import argparse,hashlib,json
from pathlib import Path
from functools import cache
from certify_u221 import read,certificate,need
P='11010010011101010110111111100'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(T):return ('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode('ascii')
def compact(obj):return(json.dumps(obj,separators=(',',':'))+'\n').encode('ascii')
def leaf(t):return isinstance(t[0],str)
def tree(rows):
    D={p:(op,arg)for p,op,arg in rows}
    def rec(p):return D[p]if p in D else(rec(p+'0'),rec(p+'1'))
    T=rec('');need(sites(T)==rows,'canonical binary source');return T
def sites(t,p=''):return [[p,*t]]if leaf(t)else sites(t[0],p+'0')+sites(t[1],p+'1')
@cache
def boundary(t):
    if leaf(t):
        op,k=t;return (1 if op=='CD'else k if op=='CB'else 0,k if op=='CC'else 0,op=='CH')
    a,b=map(boundary,t);return(max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2])
def at(t,p):
    for b in p:t=t[int(b)]
    return t
def replace(t,p,n):
    if not p:return n
    c=list(t);b=int(p[0]);c[b]=replace(c[b],p[1:],n);return tuple(c)
def graph(rows):
    # Arithmetic counter resolver. Reject unused one bits past the target leaf.
    D={p:i for i,(p,_,_)in enumerate(rows)};depth=max(map(len,D))
    def locate(p):
        word=p+'0'*depth
        for k in range(1,depth+1):
            if word[:k]in D:
                need('1'not in p[k:],'noncanonical successor residue');return D[word[:k]]
        raise ValueError('missing successor')
    def inc(p):return format((int(p,2)+1)%(1<<len(p)),'0'+str(len(p))+'b')if p else''
    def cut(p,b,k):
        ix=[j for j,c in enumerate(p)if c==b];return p[:ix[-k]]if len(ix)>=k else''
    G=[]
    for p,op,k in rows:
        if op=='CI':succ=[locate(inc(p))]
        elif op=='CD':succ=[locate(inc(cut(p,'0',1))),locate(inc(p))]
        elif op=='CB':succ=[locate(inc(cut(p,'0',k)))]
        elif op=='CC':succ=[locate(cut(p,'1',k))]
        else:succ=[]
        G.append([op,k,succ])
    return G

def decoder_paths(T,t):
    # For each internal source node, follow each consumed prefix on its known
    # tape bits. Every finite detour must restore the prefix exactly.
    paths={}
    def visit(n,p,q):
        if leaf(n):return
        paths.setdefault(q,[]).append(p)
        for b in(0,1):
            if leaf(n[b]):continue
            tape={i:int(c)for i,c in enumerate(p+str(b))};tape[-1]=1
            before=tape.copy();h=len(p);state=q
            for step in range(100):
                if h==len(p)+1:break
                need(h in tape,'decoder read beyond known prefix')
                w,d,state=T[state,tape[h]];tape[h]=w;h+=d
            else:raise ValueError('decoder does not advance')
            need(tape==before,'decoder changed prefix')
            visit(n[b],p+str(b),state)
    visit(t,'',84);return paths

def fold_certificate(T,R):
    # In T, q134 implies previous1, q145 implies previous0, by last write.
    for q,tag in [(134,1),(145,0)]:
        incoming=[(p,b,w,d)for(p,b),(w,d,z)in T.items()if z==q]
        need(incoming and all(w==tag and d==1 for p,b,w,d in incoming),'predecessor tag')
    need(T[134,1]==T[145,1]==(1,1,215),'shared one branch')
    need(T[134,0]==(0,1,203)and T[145,0]==(0,1,19),'old zero branches')
    need(T[507,0]==(0,1,166)and T[507,1]==(1,1,163),'helper tag dispatch')
    need(T[166,0]==(0,1,19)and T[163,0]==(0,1,203),'return branches')
    f=lambda q:134 if q==145 else q
    expected={(q,b):(w,d,f(z))for(q,b),(w,d,z)in T.items()if q!=145}
    expected[134,0]=(0,-1,507)
    need(R==expected,'exact contextual fold')
    traces=[]
    for old,tag,target in [(134,1,203),(145,0,19)]:
        tape={-1:tag,0:0};saved=tape.copy();q,h=134,0;trace=[]
        for j in range(3):
            w,d,z=R[q,tape[h]];trace.append([q,h,tape[h],w,d,z]);tape[h]=w;h+=d;q=z
        need(tape==saved and h==1 and q==target,'three-step context path')
        traces.append({'old_state':old,'tag':tag,'trace':trace})
    return {'status':'PREDECESSOR_TAG_AND_THREE_STEP_FOLD_PASS','keep':134,'drop':145,'helper':507,'traces':traces,'scope':'all tapes from state0 of the rotated prefold machine;1 or3 steps preserve tape/head at every simulated boundary'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('baseline',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=True)
    raw=(a.baseline/'machine/u.native.tm').read_bytes();sr=(a.baseline/'machine/sites.json').read_bytes()
    need(sha(raw)=='88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427','baseline TM hash')
    need(sha(sr)=='1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072','baseline source hash')
    T=read(a.baseline/'machine/u.native.tm');rows=json.loads(sr);root=tree(rows)
    f=lambda q:112 if q==200 else q
    S={(q,b):(w,d,f(z))for(q,b),(w,d,z)in T.items()if q!=200};cert1=certificate(T,S)
    dp=decoder_paths(S,root)
    need(dp[506]==[P]and dp[145]==[P+'1'],'exact physical rotation positions')
    A,(B,C)=at(root,P)
    need(all(boundary(x)==(0,0,False)for x in(A,B,C)),'three factors closed')
    newroot=replace(root,P,((A,B),C));newrows=sites(newroot)
    need([r[1:]for r in rows]==[r[1:]for r in newrows],'identical primitive word')
    need(graph(rows)==graph(newrows),'identical guarded CFG')
    need(S[506,0]==(0,1,19)and S[506,1]==(1,1,145),'rotation parent')
    need(S[145,0]==(0,1,215)and S[145,1]==(1,1,504),'rotation child')
    V=S|{(506,0):(0,1,145),(506,1):(1,1,504),(145,0):(0,1,19),(145,1):(1,1,215)}
    g=lambda q:134 if q==145 else q
    U={(q,b):(w,d,g(z))for(q,b),(w,d,z)in V.items()if q!=145};U[134,0]=(0,-1,507)
    cert2=fold_certificate(V,U)
    qs=sorted({q for q,b in U});need(len(qs)==220,'220 states');need(len(U)==440,'440 transitions');ren={q:i for i,q in enumerate(qs)};ren[254]=220
    D={(ren[q],b):(w,d,ren[z])for(q,b),(w,d,z)in U.items()}
    native=encode(U);dense=encode(D);source=compact(newrows)
    need(sha(native)=='7aa87660ee072b7a82b63d48e555ea4567d19b8cedbaab76617c6ba4e4e48a1b','U220 native digest')
    need(sha(source)=='232307837f575ee79ffa43a9f8ec1eaf94978d8cd1fe544ed4f6fb64a170fd12','U220 source digest')
    for name,data in [('u221.native.tm',encode(S)),('u220.prefold.native.tm',encode(V)),('u220.native.tm',native),('u220.tm',dense),('sites.json',source)]: (out/name).write_bytes(data)
    negative=[]
    for name,mut in [('wrong tag entrance',{(506,0):(1,1,145)}),('wrong helper branch',{(507,1):(1,1,166)}),('wrong return target',{(163,0):(0,1,19)})]:
        try:fold_certificate(V|mut,U)
        except ValueError as e:negative.append({'name':name,'status':'REJECTED','reason':str(e)})
        else:raise ValueError('negative control accepted')
    report={'status':'U220_DETERMINISTIC_BUILD_AND_LOCAL_PROOFS_PASS','working_states':220,'transitions':440,'native_sha256':sha(native),'dense_sha256':sha(dense),'source_sha256':sha(source),'native_to_dense':ren,'u221_certificate':cert1,'rotation':{'source_path':P,'source_interval':[3057,3160],'factor_lengths':[len(sites(x))for x in(A,B,C)],'factor_boundaries':[boundary(x)for x in(A,B,C)],'primitive_word_equal':True,'guarded_CFG_equal':True,'parent':506,'child':145,'direction':'A,(B,C) -> (A,B),C'},'fold_certificate':cert2,'changed_retained_rows':[[q,b,*T[q,b],*U[q,b]]for q,b in U if T[q,b]!=U[q,b]],'removed_native_states':[145,200],'negative_controls':negative}
    (out/'construction.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='native_to_dense'},indent=2))
if __name__=='__main__':main()
