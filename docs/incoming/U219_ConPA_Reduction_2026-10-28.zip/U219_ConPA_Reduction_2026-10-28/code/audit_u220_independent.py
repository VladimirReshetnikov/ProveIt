#!/usr/bin/env python3
"""Independent literal premises for the U220 staged construction.

No builder, optimizer, symbolic engine, or proof-checking module is imported.
The accompanying review proves the universal local simulation lemmas.
"""
import argparse
import hashlib
import json
from pathlib import Path

P='11010010011101010110111111100'

def need(c,msg):
    if not c: raise ValueError(msg)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    rows={};start=[]
    for line in Path(p).read_text().splitlines():
        if line.startswith('#! start '):start.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
            need((q,b)not in rows,'duplicate row');need(b in(0,1)and w in(0,1)and d in('L','R'),'bad row')
            rows[q,b]=(w,d,z)
    need(start==[0],'bad start')
    working={q for q,b in rows};need(set(rows)=={(q,b)for q in working for b in(0,1)},'partial table')
    need(0 in working and 254 not in working,'bad initial or halt state')
    need({z for w,d,z in rows.values()}-working=={254},'unexpected halt')
    return rows

def incoming(table,state):
    return sorted([q,b,w,d]for(q,b),(w,d,z)in table.items()if z==state)

def quotient(table,drop,keep):
    return {(q,b):(w,d,keep if z==drop else z)for(q,b),(w,d,z)in table.items()if q!=drop}

def audit(baseline,release):
    T=read(baseline/'machine/u.native.tm');S=read(release/'u221.native.tm')
    V=read(release/'u220.prefold.native.tm');U=read(release/'u220.native.tm')
    need(incoming(T,112)==[[172,0,0,'L']],'112 predecessor')
    need(incoming(T,200)==[[112,1,1,'R']],'200 predecessor')
    need(T[112,0]==T[200,0]==(0,'R',157),'zero branch')
    need(S==quotient(T,200,112),'zero collapse exactness')
    need(len(S)==442,'U221 count')
    changes={(506,0):(0,'R',145),(506,1):(1,'R',504),(145,0):(0,'R',19),(145,1):(1,'R',215)}
    need(V==S|changes,'rotation delta')
    need(incoming(V,134)==[[156,1,1,'R'],[210,1,1,'R']],'all 134 entries')
    need(incoming(V,145)==[[506,0,0,'R']],'all 145 entries')
    need(V[134,1]==V[145,1]==(1,'R',215),'one branches')
    need(V[134,0]==(0,'R',203)and V[145,0]==(0,'R',19),'zero branches')
    helper={(507,0):(0,'R',166),(507,1):(1,'R',163),(166,0):(0,'R',19),(163,0):(0,'R',203)}
    need(all(V[k]==U[k]==v for k,v in helper.items()),'untouched helper rows')
    expected=quotient(V,145,134);expected[134,0]=(0,'L',507)
    need(U==expected,'fold delta includes unrelated change')
    checked=[]
    for q,tag,dest in[(134,1,203),(145,0,19)]:
        for scanned in(0,1):
            tape={-1:tag,0:scanned};original=tape.copy();st=134;head=0
            duration=3 if scanned==0 else 1;trace=[]
            for i in range(duration):
                need(st!=254,'intermediate halt')
                need(head in tape,'read outside two-cell context')
                w,d,z=U[st,tape[head]];trace.append([st,head,tape[head],w,d,z])
                tape[head]=w;head+=1 if d=='R'else-1;st=z
            target=dest if scanned==0 else 215
            need(tape==original and head==1 and st==target,'local step mismatch')
            checked.append({'original_state':q,'preceding_tag':tag,'scanned':scanned,'duration':duration,'trace':trace})
    need(len(U)==440 and len({q for q,b in U})==220,'U220 count')
    old=json.loads((baseline/'machine/sites.json').read_text());new=json.loads((release/'sites.json').read_text())
    expected=[];factors=[[],[],[]]
    for p,op,k in old:
        if p.startswith(P+'0'):local=p[len(P)+1:];newp=P+'00'+local;factors[0].append([local,op,k])
        elif p.startswith(P+'10'):local=p[len(P)+2:];newp=P+'01'+local;factors[1].append([local,op,k])
        elif p.startswith(P+'11'):local=p[len(P)+2:];newp=P+'1'+local;factors[2].append([local,op,k])
        else:newp=p
        expected.append([newp,op,k])
    need(new==expected,'source rotation differs')
    for factor in factors:
        need(bool(factor),'empty factor')
        for path,op,k in factor:
            need(op!='CH','halt in factor')
            if op=='CD':need(path.count('0')>=1,'open decrement')
            if op=='CB':need(path.count('0')>=k,'open break')
            if op=='CC':need(path.count('1')>=k,'open continue')
    need([len(f)for f in factors]==[19,28,56],'factor sizes')
    return {'status':'INDEPENDENT_U220_LOCAL_AND_SOURCE_PREMISES_PASS',
      'native_sha256':sha(release/'u220.native.tm'),'source_sha256':sha(release/'sites.json'),
      'working_states':220,'rows':440,'removed':[145,200],
      'source_rotation_path':P,'closed_factor_sizes':[19,28,56],
      'changed_source_addresses':sum(a[0]!=b[0]for a,b in zip(old,new)),
      'prefold_incoming_134':incoming(V,134),'prefold_incoming_145':incoming(V,145),
      'helper_rows_unchanged':True,'all_other_rows_exact_projection':True,
      'local_context_cases':checked,'arbitrary_unread_context_preserved':True,
      'scope':{'zero_merge':'all binary tapes from state0; exact stepwise simulation',
               'selector_fold':'all binary tapes from state0 of rotated prefold table;1-or3-step simulation',
               'source_rotation':'register CFG and canonical source frames; not an all-tape equivalence of U222 and U220'}}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('baseline',type=Path);ap.add_argument('release',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    r=audit(a.baseline,a.release);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

if __name__=='__main__':main()
