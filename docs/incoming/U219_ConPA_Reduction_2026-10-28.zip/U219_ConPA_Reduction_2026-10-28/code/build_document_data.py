#!/usr/bin/env python3
"""Generate paper metadata and the exact U219 transition appendix from the tables."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse(path):
    result = {}
    for line in path.read_text().splitlines():
        if line and not line.startswith('#'):
            q, b, w, d, t = line.split()
            result[int(q), int(b)] = int(w), d, int(t)
    return result


def main():
    name = 'u219'
    dense_path = ROOT / 'machine' / (name + '.tm')
    native_path = ROOT / 'machine' / (name + '.native.tm')
    source_path = ROOT / 'machine' / (name + '.sites.json')
    dense = parse(dense_path)
    count = len({q for q, b in dense})
    if count != 219 or set(dense) != {(q, b) for q in range(count) for b in (0, 1)}:
        raise ValueError('Unexpected primary state census')
    values = {'BestStates': count, 'BestRows': 2*count, 'BestLast': count-1,
              'BestFile': name, 'BestMachine': 'U219',
              'BestDenseHash': sha(dense_path), 'BestNativeHash': sha(native_path),
              'BestSourceHash': sha(source_path)}
    (ROOT / 'paper/metadata.tex').write_text(''.join(
        '\\newcommand{\\' + k + '}{' + str(v) + '}\n' for k, v in values.items()))
    (ROOT / 'paper/results_table.tex').write_text(r'''\begin{center}\small
\begin{tabular}{lrrrr}
\toprule
Machine & Working states & Source subtrees & Changed addresses & Startup steps\\\midrule
U222 (input) & 222 & 204 & 0 & 95,714\\
U221 (direct fold) & 221 & 204 & 0 & 95,714\\
U220 (short patch) & 220 & 204 & 103 & 95,714\\
C221 (compact parent) & 221 & 203 & 899 & 95,714\\
\textbf{U219 (primary)} & \textbf{219} & \textbf{203} & \textbf{899} & \textbf{95,714}\\
\bottomrule
\end{tabular}
\end{center}
\noindent Changed addresses are measured against U222. All variants have
3,891 primitive occurrences and 5,060 guarded cases. The source tree and
all guarded successors of U221 are unchanged; the other source changes
are verified by both independent CFG algorithms.
''')
    lines = [r'\small', r'\begin{longtable}{rll@{\hspace{2em}}rll}',
             r'\toprule', r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
             r'\midrule', r'\endfirsthead', r'\toprule',
             r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
             r'\midrule', r'\endhead', r'\bottomrule', r'\endfoot']
    split = (count+1)//2
    for first in range(split):
        fields = []
        for q in [first, first+split]:
            if q >= count:
                fields.extend(['', '', ''])
            else:
                fields.append(str(q))
                for b in (0, 1):
                    w, d, t = dense[q, b]
                    fields.append(r'\texttt{' + f'{w} {d} {t}' + '}')
        lines.append(' & '.join(fields) + r'\\')
    lines += [r'\end{longtable}', r'\normalsize']
    (ROOT / 'paper/transition_table.tex').write_text('\n'.join(lines)+'\n')
    native = parse(native_path)
    states = sorted({q for q, b in native})
    ren = {q: i for i, q in enumerate(states)}
    ren[254] = count
    summary = {'primary': 'U219', 'working_states': count, 'rows': len(dense),
               'source_occurrences': 3891, 'guarded_cases': 5060, 'source_subtrees': 203,
               'start': 0, 'dense_halt': count, 'native_halt': 254,
               'native_sha256': sha(native_path), 'dense_sha256': sha(dense_path),
               'source_sha256': sha(source_path), 'blank_startup_steps': 95714}
    (ROOT / 'machine/u219_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    (ROOT / 'machine/u219_state_map.json').write_text(json.dumps({'native_to_dense': ren}, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
