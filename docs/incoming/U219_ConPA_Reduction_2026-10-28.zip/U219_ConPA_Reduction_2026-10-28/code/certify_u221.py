#!/usr/bin/env python3
"""Small standalone finite verifier for the U222->U221 invariant collapse.

The certificate is a proof schema, not a proof-assistant kernel proof. P(q,t,h):
(q=112 -> t(h+1)=0) and (q=200 -> t(h)=0). The checks prove P initially,
prove preservation by exhaustive incoming-row inspection, and prove commuting
transitions on every P-allowed row under f(200)=112. Determinism then gives
identical head/tape trajectories and equal halting time from q=0 on any tape.
"""
import argparse,hashlib,json
from pathlib import Path

def read(path):
    T={};start=[]
    for row in path.read_text('ascii').splitlines():
        if row.startswith('#! start '):start.append(int(row[9:]))
        if not row or row[0]=='#':continue
        q,b,w,d,z=row.split();q,b,w,z=map(int,(q,b,w,z))
        if d not in ('L','R')or(q,b)in T:raise ValueError('malformed row')
        T[q,b]=(w,1 if d=='R'else-1,z)
    if start!=[0]:raise ValueError('start')
    return T

def need(x,message):
    if not x:raise ValueError(message)

def f(q):return 112 if q==200 else q

def certificate(T,R):
    qs={q for q,b in T};rs={q for q,b in R}
    need(len(qs)==222 and len(rs)==221,'state counts')
    need(rs==qs-{200},'exact state deletion')
    for M,S in [(T,qs),(R,rs)]:
        need(set(M)=={(q,b)for q in S for b in(0,1)},'total binary table')
        need(all(w in(0,1)and d in(-1,1)and z in S|{254}for w,d,z in M.values()),'legal transitions')
    need(0 not in [112,200] and 254 not in qs|rs,'start/halting condition')
    need([(q,b)for(q,b),v in sorted(T.items())if v[2]==112]==[(172,0)],'112 predecessor')
    need(T[172,0]==(0,-1,112),'right-neighbor zero creation')
    need([(q,b)for(q,b),v in sorted(T.items())if v[2]==200]==[(112,1)],'200 predecessor')
    need(T[112,1]==(1,1,200),'return to zero marker')
    checked=[]
    for(q,b),(w,d,z)in sorted(T.items()):
        if q==200 and b==1:continue # P forbids this row.
        need(R[f(q),b]==(w,d,f(z)),f'commuting transition {q}/{b}')
        checked.append([q,b])
    return {'status':'INVARIANT_AND_STEP_COMMUTATION_PASS','allowed_rows_checked':len(checked),'forbidden_rows':[[200,1]],'invariant':['q=112 => tape[h+1]=0','q=200 => tape[h]=0'],'initial_scope':'any binary tape, head0, state0','collapse':{'200':112},'conclusion':'exact same head/tape sequence and halting time after state collapse'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('original',type=Path);ap.add_argument('reduced',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
    T=read(a.original);R=read(a.reduced);report=certificate(T,R)
    controls=[]
    def reject(name,X,Y):
        try:certificate(X,Y)
        except ValueError as e:controls.append({'name':name,'status':'REJECTED','reason':str(e)})
        else:raise ValueError('negative control accepted: '+name)
    X=T.copy();X[172,0]=(1,-1,112);reject('corrupt zero-marker write',X,R)
    X=T.copy();X[0,0]=(1,1,112);reject('extra unguarded entrance to112',X,R)
    X=T.copy();X[0,0]=(1,1,200);reject('extra unguarded entrance to200',X,R)
    X=R.copy();X[112,0]=(1,1,157);reject('corrupt retained common row',T,X)
    X=R.copy();X[112,1]=(1,1,119);reject('wrong redirected target',T,X)
    report['negative_controls']=controls
    report['sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(a.original,a.reduced,Path(__file__))}
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
