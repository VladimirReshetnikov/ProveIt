#!/usr/bin/env python3
"""Second CFG resolution using tree intervals, not bit arithmetic.

It checks the root transport auditor on exact source files and verifies the
separate zero-extension closure needed to compose literal frame proofs.
"""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('audit_transport', ROOT/'audit_transport.py')
root = importlib.util.module_from_spec(spec)
spec.loader.exec_module(root)


def interval_graph(sites):
    n = len(sites)
    spans = {}
    for i, (p, _, _) in enumerate(sites):
        for k in range(len(p)+1):
            pre = p[:k]
            if pre not in spans:
                spans[pre] = [i, i+1]
            else:
                spans[pre][1] = i+1
    def outward(p, b, k, side):
        positions = [j for j, c in enumerate(p) if c == b]
        if len(positions) < k:
            return 0
        return spans[p[:positions[-k]]][side] % n
    result = []
    for i, (p, op, arg) in enumerate(sites):
        nxt = (i+1) % n
        if op == 'CI': targets = [nxt]
        elif op == 'CD': targets = [outward(p,'0',1,1), nxt]
        elif op == 'CB': targets = [outward(p,'0',arg,1)]
        elif op == 'CC': targets = [outward(p,'1',arg,0)]
        elif op == 'CH': targets = [-1]
        else: raise ValueError(op)
        result.append([op,arg,targets])
    return result


def target_words(sites):
    # This recursive implementation follows RM.v literally, with LSB-first
    # path recursion, and does not import either runtime helper.
    def inc_rev(bits):
        if not bits: return []
        if bits[0] == '0': return ['1'] + bits[1:]
        return ['0'] + inc_rev(bits[1:])
    def strip_rev(b,k,bits):
        if not k or not bits: return bits
        return strip_rev(b,k-int(bits[0] == b),bits[1:])
    def inc(p): return ''.join(reversed(inc_rev(list(reversed(p)))))
    def strip(p,b,k): return ''.join(reversed(strip_rev(b,k,list(reversed(p)))) )
    for p,op,arg in sites:
        if op in ('CI','CD'): yield p,inc(p)
        if op in ('CB','CD'): yield p,inc(strip(p,'0',arg if op=='CB' else 1))
        if op == 'CC': yield p,strip(p,'1',arg)


def inspect(path):
    sites,graph,cases,*_ = root.source_graph(path)
    alt = interval_graph(sites)
    if graph != alt:
        raise ValueError(('interval graph mismatch', path, next(i for i,(a,b) in enumerate(zip(graph,alt)) if a != b)))
    leaves={p for p,_,_ in sites}
    longer=shorter=equal=0
    max_extra=0
    for source,address in target_words(sites):
        pref='';i=0
        while pref not in leaves:
            pref += address[i] if i<len(address) else'0';i+=1
        residual=address[len(pref):]
        if '1' in residual:
            raise ValueError(('nonzero undeclared target suffix',source,address,pref))
        if len(address)>len(pref):longer+=1;max_extra=max(max_extra,len(residual))
        elif len(address)<len(pref):shorter+=1
        else:equal+=1
    return {'path':str(path),'leaves':len(sites),'cases':cases,
            'interval_resolver_agrees':True,
            'canonical_zero_extension_closed':True,
            'longer_target_words':longer,'shorter_target_words':shorter,
            'equal_length_target_words':equal,'maximum_extra_zero_suffix':max_extra},graph


def main():
    if len(sys.argv)<3: raise SystemExit('usage: check_source_independent.py OLD NEW [NEW...]')
    base_result,base=inspect(Path(sys.argv[1]));results=[base_result]
    for p in sys.argv[2:]:
        result,graph=inspect(Path(p))
        if graph!=base: raise ValueError(('candidate CFG differs',p))
        result['same_exact_register_CFG_as_baseline']=True
        results.append(result)
    print(json.dumps({'status':'INDEPENDENT_SOURCE_TRANSPORT_PASS','sources':results},indent=2))

if __name__=='__main__':main()
