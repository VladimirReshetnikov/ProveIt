#!/usr/bin/env python3
"""Verify a predecessor-tag fold directly from two literal binary tables.

No compiler, optimizer, or runtime checker is imported. The checked theorem
relates executions from a common start state, on arbitrary binary tapes.
Each exceptional step must be simulated inside the two known tape cells.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path


def need(c,message):
    if not c: raise ValueError(message)


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def read(p,halt=254):
    rows={};starts=[]
    for line in Path(p).read_text().splitlines():
        if line.startswith('#! start '): starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
            need((q,b)not in rows,'duplicate transition')
            need(b in(0,1)and w in(0,1)and d in('L','R'),'bad transition')
            rows[q,b]=(w,1 if d=='R'else-1,z)
    need(starts==[0],'bad initial state')
    validate(rows,halt)
    return rows


def validate(rows,halt):
    states={q for q,b in rows}
    need(0 in states and halt not in states,'invalid start/halt')
    need(set(rows)=={(q,b)for q in states for b in(0,1)},'incomplete binary table')
    need({z for w,d,z in rows.values()}-states=={halt},'unexpected halt destination')
    need(all(w in(0,1)and d in(-1,1)for w,d,z in rows.values()),'invalid write/move')


def verify(old,new,keep,drop,keep_tag,drop_tag,split_bit,max_steps,halt=254):
    validate(old,halt);validate(new,halt)
    need(keep!=drop and 0 not in(keep,drop),'bad collapsed states')
    need(keep_tag in(0,1)and drop_tag==1-keep_tag,'tags must distinguish contexts')
    incoming={q:sorted([p,b,w,d]for(p,b),(w,d,z)in old.items()if z==q)for q in(keep,drop)}
    for q,tag in[(keep,keep_tag),(drop,drop_tag)]:
        need(incoming[q]and all(w==tag and d==1 for p,b,w,d in incoming[q]),'all entries must establish preceding-cell tag')
    f=lambda q:keep if q==drop else q
    projected={(q,b):(w,d,f(z))for(q,b),(w,d,z)in old.items()if q!=drop}
    projected[keep,split_bit]=new[keep,split_bit]
    need(new==projected,'unrelated table change')
    for(q,b),(w,d,z)in old.items():
        if q in(keep,drop)and b==split_bit:continue
        need(new[f(q),b]==(w,d,f(z)),'ordinary step does not commute')
    cases=[];helpers=set()
    for oldq,tag in[(keep,keep_tag),(drop,drop_tag)]:
        for scanned in(0,1):
            tape={-1:tag,0:scanned}
            wanted=dict(tape);w,d,z=old[oldq,scanned];wanted[0]=w
            target=(f(z),d,wanted)
            q,h=keep,0;trace=[]
            for elapsed in range(1,max_steps+1):
                need(q!=halt,'intermediate halt')
                need(h in tape,'read beyond known two-cell context')
                b=tape[h];w,d,z=new[q,b]
                if(q,b)!=(keep,split_bit):
                    need((q,b)in old and old[q,b]==new[q,b],'helper row changed')
                    helpers.add((q,b))
                trace.append([q,h,b,w,d,z]);tape[h]=w;h+=d;q=z
                if(q,h,tape)==target:break
            else:raise ValueError('local simulation did not match original action')
            cases.append({'original_state':oldq,'preceding_tag':tag,'scanned':scanned,'steps':elapsed,'trace':trace})
    need(len(new)==len(old)-2,'not exactly one state removed')
    return {'status':'INDEPENDENT_PREDECESSOR_TAG_FOLD_PASS','keep':keep,'drop':drop,
        'old_states':len(old)//2,'new_states':len(new)//2,'incoming':incoming,
        'split_symbol':split_bit,'case_durations':sorted({x['steps']for x in cases}),
        'complete_row_projection_checked':True,'helper_rows_unchanged':sorted(helpers),
        'two_cell_contexts':cases,'unknown_exterior_not_read_or_changed':True,
        'no_intermediate_halt':True,
        'scope':'All binary tapes from state0 of the input table, via positive finite stuttering; no assertion about unreachable wrong-tag configurations.'}


def zero_verify(old,new):
    es=lambda q:sorted([p,b,w,d]for(p,b),(w,d,z)in old.items()if z==q)
    need(es(112)==[[172,0,0,-1]],'right-zero entry premise')
    need(es(200)==[[112,1,1,1]],'zero-return entry premise')
    need(old[112,0]==old[200,0]==(0,1,157),'common allowed action')
    f=lambda q:112 if q==200 else q
    need(new=={(q,b):(w,d,f(z))for(q,b),(w,d,z)in old.items()if q!=200},'zero fold exact projection')
    return {'status':'INDEPENDENT_ZERO_CELL_FOLD_PASS','removed':200,'kept':112,
        'old_states':len(old)//2,'new_states':len(new)//2,'all_input_state0_stepwise_equivalence':True}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('old',type=Path);ap.add_argument('new',type=Path)
    ap.add_argument('--parent',type=Path,help='Optional input before the200->112 fold.')
    ap.add_argument('--keep',type=int,required=True);ap.add_argument('--drop',type=int,required=True)
    ap.add_argument('--keep-tag',type=int,required=True);ap.add_argument('--drop-tag',type=int,required=True)
    ap.add_argument('--split-bit',type=int,default=0);ap.add_argument('--max-steps',type=int,default=5)
    ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    old,new=read(a.old),read(a.new)
    report=verify(old,new,a.keep,a.drop,a.keep_tag,a.drop_tag,a.split_bit,a.max_steps)
    report['old_sha256']=sha(a.old);report['new_sha256']=sha(a.new)
    if a.parent:
        report['prior_zero_fold']=zero_verify(read(a.parent),old);report['parent_sha256']=sha(a.parent)
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
