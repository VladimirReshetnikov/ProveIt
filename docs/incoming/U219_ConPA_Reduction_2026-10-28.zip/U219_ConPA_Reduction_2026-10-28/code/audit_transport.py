#!/usr/bin/env python3
"""Independent finite certificates for source transport and a zero-cell merge.

This file imports no compiler, optimizer, or inherited runtime checker. It
checks finite premises of the mathematical simulation lemmas in the report;
it is not a proof-assistant kernel certificate.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def table(path):
    transitions = {}
    starts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q, b, w, d, t = line.split()
            q, b, w, t = map(int, (q, b, w, t))
            require((q, b) not in transitions, 'Duplicate table row')
            require(b in (0, 1) and w in (0, 1) and d in ('L', 'R'), 'Bad action')
            transitions[q, b] = w, d, t
    require(starts == [0], 'Bad start declaration')
    working = {q for q, b in transitions}
    require(0 in working, 'Missing start')
    require(set(transitions) == {(q, b) for q in working for b in (0, 1)}, 'Partial table')
    targets = {t for w, d, t in transitions.values()}
    require(targets - working == {254}, 'Unexpected halt target')
    reached, todo = {0}, [0]
    for q in todo:
        for b in (0, 1):
            target = transitions[q, b][2]
            if target != 254 and target not in reached:
                reached.add(target)
                todo.append(target)
    require(reached == working, 'Graph-unreachable working state')
    return transitions


def source_graph(path):
    sites = json.loads(Path(path).read_text())
    leaves = {p: i for i, (p, op, arg) in enumerate(sites)}
    require(len(leaves) == len(sites), 'Repeated source address')
    require(list(leaves) == sorted(leaves), 'Source not in leaf order')
    prefixes = {p[:i] for p in leaves for i in range(len(p))}
    require(not set(leaves) & prefixes, 'Non-prefix-free source')
    require('' in prefixes, 'Missing root')
    for p in prefixes:
        require(all(p + b in prefixes or p + b in leaves for b in '01'), 'Incomplete source tree')
    require(max(map(len, leaves)) <= 64, 'Address field overflow')

    closure = {'longer_successor_words': 0, 'maximum_zero_suffix': 0,
               'shorter_successor_words': 0}

    def resolve(address):
        # The physical dispatcher sees the stored address followed by zeros.
        # Select the unique leaf prefix of that infinite zero extension.
        p = ''
        cursor = 0
        while p in prefixes:
            p += address[cursor] if cursor < len(address) else '0'
            cursor += 1
        require(p in leaves, 'No decoded leaf')
        # The source semantics discards unused suffix bits, whereas the
        # physical tape retains them. Composition of the canonical-frame
        # primitive theorems therefore needs the retained suffix to be zero.
        suffix = address[cursor:]
        require(set(suffix) <= {'0'}, 'Nonzero suffix beyond decoded leaf')
        if suffix:
            closure['longer_successor_words'] += 1
            closure['maximum_zero_suffix'] = max(closure['maximum_zero_suffix'], len(suffix))
        elif cursor > len(address):
            closure['shorter_successor_words'] += 1
        return leaves[p]

    def carry(address):
        # Binary increment modulo the current address length; an overflow
        # shifts the tape frame, but leaves the logical successor unchanged.
        chars = list(address)
        k = len(chars) - 1
        while k >= 0 and chars[k] == '1':
            chars[k] = '0'
            k -= 1
        if k >= 0:
            chars[k] = '1'
        return ''.join(chars)

    def erase_suffix(address, bit, count):
        require(type(count) is int and count >= 1, 'Bad structured jump count')
        seen = 0
        for k in range(len(address) - 1, -1, -1):
            if address[k] == bit:
                seen += 1
                if seen == count:
                    return address[:k]
        return ''

    graph = []
    cases = 0
    for p, op, arg in sites:
        require(set(p) <= {'0', '1'}, 'Nonbinary source path')
        if op in ('CI', 'CD'):
            require(type(arg) is int and 0 <= arg < 9, 'Bad register')
        if op == 'CI':
            successors = [resolve(carry(p))]
        elif op == 'CD':
            successors = [resolve(carry(erase_suffix(p, '0', 1))), resolve(carry(p))]
        elif op == 'CB':
            successors = [resolve(carry(erase_suffix(p, '0', arg)))]
        elif op == 'CC':
            successors = [resolve(erase_suffix(p, '1', arg))]
        elif op == 'CH':
            require(arg is None, 'Bad halt argument')
            successors = [-1]
        else:
            raise ValueError('Unknown primitive: ' + str(op))
        graph.append([op, arg, successors])
        cases += 2 if op == 'CD' else 1
    return sites, graph, cases, closure


def check_source_pair(old_path, new_path):
    old_sites, old, cases, old_closure = source_graph(old_path)
    new_sites, new, new_cases, new_closure = source_graph(new_path)
    require(old == new, 'Register control-flow graphs differ')
    require(cases == new_cases, 'Case count differs')
    changed = sum(a[0] != b[0] for a, b in zip(old_sites, new_sites))
    return {'status': 'EXACT_ORDERED_REGISTER_CFG_PASS',
            'baseline_source_sha256': digest(old_path),
            'candidate_source_sha256': digest(new_path),
            'primitive_occurrences': len(old), 'branch_cases': cases,
            'changed_addresses': changed,
            'initial_leaf': 0,
            'baseline_canonical_frame_closure': old_closure,
            'candidate_canonical_frame_closure': new_closure,
            'every_unconsumed_successor_suffix_is_zero': True,
            'every_operation_argument_and_successor_preserved': True}


def check_zero_merge(old_path, new_path):
    old, new = table(old_path), table(new_path)
    incoming = lambda q: sorted([s, b, w, d] for (s, b), (w, d, t) in old.items() if t == q)
    require(incoming(112) == [[172, 0, 0, 'L']], 'Right-zero invariant has another entry')
    require(incoming(200) == [[112, 1, 1, 'R']], 'Read-zero invariant has another entry')
    require(old[112, 0] == old[200, 0] == (0, 'R', 157), 'Unequal permitted action')
    require(0 not in (112, 200), 'Invariant needs nontrivial base case')
    rename = lambda q: 112 if q == 200 else q
    projected = {(q, b): (w, d, rename(t))
                 for (q, b), (w, d, t) in old.items() if q != 200}
    require(new == projected, 'Candidate contains unrelated mutations')
    require(len(old) == len(new) + 2, 'Not exactly one deleted state')
    return {'status': 'ZERO_CELL_COLLAPSE_PREMISES_PASS',
            'baseline_sha256': digest(old_path), 'candidate_sha256': digest(new_path),
            'old_states': len(old) // 2, 'new_states': len(new) // 2,
            'map': {'200': 112}, 'incoming_112': incoming(112), 'incoming_200': incoming(200),
            'all_other_rows_match_projection': True,
            'invariants': ['q=112 implies tape(head+1)=0', 'q=200 implies tape(head)=0'],
            'scope': 'Finite premises of exact one-step simulation on every binary input tape from state 0.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-source', type=Path)
    parser.add_argument('--candidate-source', type=Path)
    parser.add_argument('--baseline-table', type=Path)
    parser.add_argument('--merged-table', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = {}
    if args.baseline_source and args.candidate_source:
        result['source'] = check_source_pair(args.baseline_source, args.candidate_source)
    if args.baseline_table and args.merged_table:
        result['zero_merge'] = check_zero_merge(args.baseline_table, args.merged_table)
    require(result, 'No audit requested')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
