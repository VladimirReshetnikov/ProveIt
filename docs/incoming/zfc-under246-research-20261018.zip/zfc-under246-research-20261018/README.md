# Toward fewer than 246 states

**No verified machine with fewer than 246 working states is claimed in this packet.**
The requested endpoint is

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M,\mathrm{blank})\leftrightarrow
\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

This research supplies a certified reduction of the shared source decoder
from 203 to **201 nodes**, a complete mathematical certificate for an
alternative **246-state binary machine**, and reproducible compilation and
state-reduction investigations. Source decoder nodes and binary working
states are different quantities.

## Start here

- `report.pdf` — complete mathematical report, results, attribution, and limitations.
- `report.tex` — main LaTeX source; included proof sections remain in the `research` tree.
- `machines/zfc_rotated246.tm` — canonical checked machine: start 0, working states 0–245, separate halt 246.
- `machines/zfc_rotated246_old.tm` — the same machine in inherited labels, start 95 and halt 254.
- `research/agent_logic/rotated246/verification.json` — exact machine certificate and proof support.
- `research/agent_audit/layout_search/sparse201.json` — compact source transformation using original node labels.
- `research/agent_logic/reassociation_proof.tex` — independent proof of source equivalence.
- `STATUS.json` — machine-readable claim boundary.

The canonical machine's SHA-256 is
`15254535ae4bed3755944a3d11666df60b8e3b36c3b101ef8869ece28db38cc2`.
It has 492 complete binary transition rows. Its exact 410,735-step blank
prefix reaches the calibrated root with logical registers
`(3,0,0,0,3,0,0,0,0)`, 167 spare registers all equal to 1, and 351 one-cells.

The certificate checks every one of the 8,391 guarded source instructions
for arbitrary register values and all supported gap lengths. It separately
replays the register macro inductions and checks all 42 transition rows
used by those induction templates. All 492 binary rows are covered by
literal instruction rules or the macro proofs. The source bisimulation and
positive finite binary segments transport the inherited internal-ZFC
calibration to this exact table.

This is an **ordinary mathematical proof with executable certificates and
pinned formal components**. A new exact-table Lean or Rocq end-to-end build
was not performed. Consistency is not an external premise of the displayed
equivalence; it is needed to infer actual nonhalting. Two-sided independence
requires additional soundness beyond consistency alone.

## Reproduce the principal results

Use Python 3.10 or later with assertions enabled. The core checks require
only the standard library:

```sh
python3 verify.py
```

To also reproduce the entire unchanged incoming prefix246 verification suite:

```sh
python3 verify.py --full --output verification-run.json
```

The driver first checks every delivered file in `manifest.json`, then runs
the checks in a disposable copy. It expands the compressed large search
ledger there and leaves the delivered certificates unchanged. Extra files
created by a later replay are not part of the original manifest.

The full replay completed successfully before delivery. Its immutable
delivery record is under `certificates/fresh-replay.json`. A pass verifies
the stated certificate families; it is not a proof that every smaller
machine is impossible.

Build the report with a standard TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

## The useful new source result

All following node labels are those of the original shared 203-node source.
Introduce `J = (N48, N79)` and replace:

| Node | New children |
|---|---|
| 99 | `(N43, J)` |
| 59 | `(N99, I1)` |
| 74 | `(N48, N63)` |
| 83 | `(N63, J)` |

Remove now-unused nodes 49, 73, and 82. Adding one and removing three leaves
201 source nodes. The independent checker proves equality of the complete
closed-sequence normal forms and the entire guarded leaf control graph:
6,460 leaf instructions, 8,391 guarded cases, and 8,390 successor edges.
This establishes one-source-instruction bisimulation for every register
valuation. It does not require the closed components to terminate.

The first attempt to compile this saving directly does not preserve existing
contextual decoder folds. In particular, some shared states read a preceding
address bit and jump back into another subtree. Reassociation changes the
meaning of that jump. The report exhibits an exact failed first-frame
contract and explains how restoring one distinction yields the checked
246-state control.

## Search records and what they mean

`research/agent_state/` contains the directed-state, mixed-row, incoming-action,
macro, and compensating-rewrite searches. The compressed large incoming-action
ledger covers 42,486,984 complete assignments in four specified families;
its independent partition checker verifies disjointness and complete coverage.
The `rebracket` subdirectory records subsequent searches on changed source
layouts, including the complete three-row family and explicitly capped
incomplete searches. Read its summary for exact scopes and limits.

`research/agent_audit/` contains complete symbolic decoder-episode searches.
Its `layout_search` subdirectory includes ordered-grammar optimization,
actual entry-state pricing, zero-depth constraints, and the further prototype
that permits disjoint closed computations to commute. An optimizer's node
count is never treated as a verified binary-state count. Solver timeouts
remain timeouts, even when they produce a useful incumbent.

`research/agent_logic/` contains the independent source and machine checkers,
dirty-root abstract interpretations, and a three-valued countermodel to one
tempting but incomplete propositional-axiom specialization. The six source
exclusions are explicitly attributed to prior repository work; they are not
claimed as a new discovery.

`research/root_search/` is **experimental**. Its files with names such as
`rebracket245_first.tm`, `rebracket201_first.tm`, and `repaired201.tm` are
rejected compilation attempts, not claimed consistency machines. They are
retained to reproduce the failures. The only primary delivered record is
the checked 246-state control under `machines/`.

The Python core remains solver-independent. Re-running discovery searches
may need SciPy/NumPy, a C++ compiler, or Z3; see `requirements-search.txt`
and the relevant directory's README. Installed solver libraries and compiled
binaries are not included. Discovery drivers should be run from this packet's
root unless their own README gives another command.

## Provenance and repository incorporation

The inspected ProveIt commit is
`8cdc55ff9281b0aaba49bf74b0b225d57f12b893`. The immediate baseline was
`docs/incoming/zfc-context246-20261018.zip`, not merely the older
`candidate-permutation252` folder. The upstream `zf-254` branch was inspected
at `c132d7eae8158cd3a9850ea3eb7251158c3dd821`.

The unchanged prefix246 verification packet is included under
`research/sources/context246/zfc-context246/`. Selected attributed source and
compiler metadata from `beyond252` and the repository research notes are
included at their recorded relative paths. Their original notices and license
boundaries are retained; see `NOTICE.txt` and `prior_sources.json`.

The original 254/253/252/246 constructions and the known phase exclusions are
prior work. The 202-node single rotation was among earlier source moves;
the present integration and certificate do not claim invention of that
rotation. The 201-node sharing result is a result found and independently
verified in this investigation, without a claim of historical priority over
uninspected work.

The archive is suitable for an incoming research packet. It should not be
merged as a claimed sub-246 record. Its completed source transformation,
alternative 246-state control, and negative search certificates can each
be reviewed separately.
