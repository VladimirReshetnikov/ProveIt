# Precision Is Memory
## Quadratic Diophantine Certificates for Neural Computation and the Rational-Synthesis Frontier

Research draft prepared for the ProveIt project, September 30, 2026.

## Read the article

`article.pdf` is the typeset article; `article.tex` is its complete editable
LaTeX source, including the bibliography. No external figures or bibliography
database are needed.

The article proves:

1. A canonical natural-number quadratic certificate for a fixed rational
   saturated-linear network: four witnesses per neuron per time step,
   unique even at the clipping thresholds. First-hit conditions are explicit.
2. A projective quadratic certificate for finite-time reachability under
   fixed rational weights and rational affine specifications. A real
   satisfying trajectory has a rational one, with a determinant bound.
3. Computable many-one equivalence between Hilbert's tenth problem over Q
   and a precisely specified four-layer rational synthesis problem with
   bounded tied weights, one zero output, and one positive output.
4. A direct degree-at-most-four natural-number synthesis certificate.
5. Decidability of rational synthesis when all target requirements are
   strict polynomial inequalities and the free parameter domain is a cube.
6. Denominator-prime-sensitive first-hit bounds and a proof that no
   computable accepting-run precision ceiling exists for a universal fixed
   rational network.

The synthesis equivalence is NOT a proof that H10(Q) is undecidable or
decidable. The four-layer restriction does NOT mean fixed width, and tied
parameters are an explicit hypothesis. The finite-trace uniqueness result
is NOT a fixed-arity single-fold representation of unbounded halting.

## Status and provenance

The proofs in the article are the primary mathematical arguments. The Python
checks validate finite examples and implementations; they are not a substitute
for the proofs. The new results were not formalized or checked in Lean, nor
independently refereed. Priority for the proposed refinements and restricted
synthesis reduction has not been established. Classical neural universality,
complementarity encodings, and real algebraic decision procedures are credited
in the article.

ProveIt documentation was inspected at commit:

    526c2557f2c6173054794f873a9624ebef616510

The repository was not modified, and its Lean build was not executed.
The exact source references are recorded in `source_manifest.json` and the
article bibliography. The package does not redistribute third-party papers.

## Reproduce the checks

Python 3.10 or newer, standard library only:

    python code/test_certificates.py

The command works from any current directory. It rewrites the three example
JSON files and `verification_report.txt`. The delivered run used Python 3.13.5
and completed 53,472 exact-arithmetic assertions with seed 20260930.

`code/neural_certificates.py` implements:

- sparse integer polynomials and structured natural-number certificates;
- saturated scalar witnesses and fixed-input trajectory compilation;
- the seven-variable projective reachability example;
- arithmetic-circuit compactification and four-layer neural realization;
- the quartic compiler for fixed rational or named-parameter edge weights;
- the binary stack encoding and exact rational network evaluation.

The article's general affine-parameter edge formula includes this implemented
fixed-or-single-parameter subset. The generic projective compiler, real
quantifier elimination, and the full universal neural network are not
implemented here. Their mathematical roles and dependencies are stated in
the article.

## Example files

`examples/fixed_trace.json`:
  x' = clip((6x-1)/4), x(0)=3/5, first hit of 1 at time 4;
  20 natural witnesses, a quadratic polynomial, and its unique zero.

`examples/projective_trace.json`:
  x' = clip(2x-1/2), terminal target 1/3, initial state 5/12;
  seven natural witnesses at common scale Q=12.

`examples/rational_synthesis.json`:
  a circuit for xy-2, the compactified rational solution, the 25-neuron
  four-layer construction, and its 114-coordinate quartic lift at Q=32.

Each example includes the structured residuals, unsquared nonnegative
complementarity products, the expanded polynomial, and a complete witness.
A coefficient term is serialized as its integer coefficient and a sorted
list of variable names, with repetition encoding powers. An empty monomial
list denotes a constant.

## Build the article

A standard TeX Live or MiKTeX installation suffices:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Shell escape is not required. Build logs and temporary files are excluded
from the distributed ZIP. The PDF was rendered and visually inspected.
