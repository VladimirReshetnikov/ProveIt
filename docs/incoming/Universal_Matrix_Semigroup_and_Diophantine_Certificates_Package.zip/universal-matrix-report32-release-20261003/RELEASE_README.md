# Report32 portable release

The article is `report32.pdf`, with source `report32.tex`. The accompanying
`core/` packet gives the fixed numerical matrix semigroup and its finite-tape
encoder; `paired/` gives the fixed-inner-word-length Diophantine companion.
`fiber/` gives the exact accepting-target factorization-count supplement.
The source proofs, audits, exact numerical data, and complete r=94 witness
are included. See `SANITIZED_PROVENANCE.md` for the narrowly documented
human-document adaptations and omitted research-only caches.

## Verify before running copied code

Use Python 3.10 or later, standard library only. From any working directory,
point Python at this release's verifier. From inside this directory:

    python3 -I -B verify_release.py --verify-only
    python3 -I -B verify_release.py --replay > ../report32-replay.json
    python3 -I -B tamper_regression.py > ../report32-tamper.json

`sh rebuild_release.sh` is the full numerical replay shortcut. The verifier
checks the exact file and directory inventory, rejects symlinks and special
paths, authenticates the manifest against its embedded digest, checks every
payload file (including maintenance helpers and the verifier's normalized
body), checks the complete checksum list, and pins the common semigroup,
transition table, and accepting witness. It also rejects Python assertion
statements and private absolute workspace paths in text artifacts.

No copied scientific module is imported before the gate passes. Each normal
and optimized replay gets a separate fresh temporary copy, and that complete
copy is identity checked again before execution. The two source trees stay
unchanged. Execution uses isolated Python mode and disables bytecode writes.
The source tests may rebuild certificates or evidence only inside those
copies. The gate cannot protect against concurrent hostile filesystem writes;
run verification on a quiescent extraction owned by you.

Keep generated receipts and TeX build outputs outside the release directory.
An extra file or even an extra empty directory is intentionally rejected.

## What full replay establishes

- Core compiler reconstruction of semigroup JSON, ledger, and plain matrix
  list, plus reconstructed accepting witness, with byte-exact equality
- Complete authored tests in ordinary Python and `python -O`
- Independent JSON-only core audit and independent JSON-only paired literal
  matrix audit in both modes, without importing either compiler
- Independent JSON-only reconstruction of every coefficient and monomial in
  all six small SOS exports, 14 independently built roots, the complete
  r=94 auxiliary assignment, and the two named collision roots
- Independent paired interface, residual, arithmetic-instrumentation,
  canonical-encoding, and invalid-input audit in both modes
- Regeneration of all six r=0,1,2 signed/natural SOS exports and the complete
  r=94 certificate, with byte-exact equality
- Exact zero checks on the r=94 signed-target and r=0 natural-target certificates
- Strict recursive receipt checks for exact keys, types, list lengths, values,
  and named counts; booleans cannot substitute for integer 0 or 1
- Normal/optimized semantic equality, allowing only the two explicitly
  checked optimization-mode booleans to differ
- Both independent JSON-only fiber checks, including 33,544 bounded stutter
  witnesses, 12 matrix/SOS samples, and 31,366 coefficient comparisons
  across 226 independently checked fixtures
- Preservation of original release bytes, modes, and modification times

The finite coverage and test counts are reported in the replay JSON. No
finite test suite proves the general universal or fixed-r equivalence theorem;
those claims depend on the accompanying proofs and cited results.

## Content identity and bootstrap trust

`MANIFEST.json` inventories every release payload file except itself and
`SHA256SUMS`. For `verify_release.py` only, its single manifest-digest assignment
is normalized to 64 zeros before hashing; the file size stays unchanged.
All other listed hashes are ordinary byte hashes. The actual manifest hash is
then inserted in that one assignment. `SHA256SUMS` records ordinary byte hashes
of all files except itself, including the final verifier and manifest. This
avoids a circular self-hash while identity-checking the complete verifier body.

The manifest pin prevents an edited public checksum list or manifest from
silently blessing a changed payload under an unchanged verifier. It is not a
signature: an adversary replacing the verifier and all accompanying files can
create a different internally consistent release. Obtain the archive SHA-256
and, where needed, the verifier SHA-256 from the trusted delivery record before
running anything. Internal validation is a consistency/corruption check with
that external trust bootstrap, not code sandboxing or publisher authentication.

## Adversarial regressions

`tamper_regression.py` first verifies the original release. On disposable
copies it requests full replay after changing the manifest, both manifest and
public checksums, a maintenance helper not ordinarily executed by scientific
replay, an integer receipt field to a boolean, the required path set, or the
checksum-list format. It checks rejection at the identity gate in normal and
optimized modes. Separate strict-semantic tests reject boolean/integer and
float/integer substitution, missing/extra keys, wrong list sizes, duplicate
JSON keys, and nonfinite JSON constants. Tampered scientific programs are
never run.

## Article rebuild and archive replay

With TeX Live, pdfTeX, and the article packages installed:

    sh build_report.sh ../report32-fresh-pdf

The output directory must be absent or empty. The script identity-checks
first, copies sources into a disposable directory, bootstraps missing TeX
formats/fontmaps in private build caches, disables shell escape, and performs
three passes. It rejects overfull boxes and unresolved references/citations.
Numerical/compiler reconstruction is byte-exact; PDF output bytes may depend
on the installed TeX toolchain and PDF metadata.

`archive_release.py --create DESTINATION.zip` creates a sorted, timestamp-fixed
ZIP only from a verified final tree and refuses an existing destination.
To verify an archive against this already verified tree and run a fresh, moved
extraction under both normal and optimized verifier processes:

    python3 -I -B archive_release.py --check ARCHIVE.zip --sha256 TRUSTED_DIGEST --replay

Every ZIP entry is checked for a single safe root, duplicate names, exact
regular-file identity and size before its bytes are written. Symlinks, extra
paths, traversal names, encrypted members, and directories are rejected.
No general-purpose extract-all operation is used.

## Maintainer-only sealing

`build_release_inventory.py` is an authoring tool, not a verification tool.
It intentionally authorizes a new content identity. Do not run it merely to
make a downloaded release pass validation. After deliberate reviewed changes,
run it to seal a new release and publish new external checksums. Its `--draft`
option explicitly labels an incomplete engineering preview; a final seal
requires both article files. A normal reader never needs this command.
