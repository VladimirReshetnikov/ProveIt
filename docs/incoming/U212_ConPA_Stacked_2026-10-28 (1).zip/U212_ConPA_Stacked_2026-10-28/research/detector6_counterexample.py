#!/usr/bin/env python3
"""Concrete origin-return mismatch for the naive six-zero detector.

This diagnoses failure of an inherited subroutine contract; it does not
prove a different blank-tape halting equivalence or exclude later recovery.
"""
from pathlib import Path
import argparse
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'code'))
from check_local_independent import parse, require


def execute(table, ones, target=None):
    state, head = 84, 0
    tape = set(ones)
    returns = []
    for step in range(1, 100001):
        bit = int(head in tape)
        w, d, state = table[state, bit]
        if w:
            tape.add(head)
        else:
            tape.discard(head)
        head += d
        if target is not None and (state, head, tape) == target:
            return {'steps': step, 'state': state, 'head': head, 'one_cells': sorted(tape)}
        if state == 84:
            returns.append({'steps': step, 'state': state, 'head': head, 'one_cells': sorted(tape)})
            if target is None and len(returns) == 2:
                return returns
        if state == 254:
            raise ValueError('unexpected halt')
    raise ValueError('No finite dispatcher/halt endpoint within the stated experiment')


def check():
    original = parse(ROOT/'machine/u212.native.tm')
    require(original[23, 0] == (0, -1, 34), 'detector entrance')
    mutant = dict(original)
    mutant[23, 0] = 0, -1, 75
    del mutant[34, 0]
    del mutant[34, 1]
    # Header distance56, source address000000, all primary registers0,
    # a single spare value1, gap0, and zero exterior.
    ones = {-1, 56}
    cursor = 57
    for value in [0]*9 + [1]:
        ones.update(range(cursor+1, cursor+value+2))
        cursor += value + 2
    old = execute(original, ones)
    new = execute(mutant, ones)
    expected = sorted(ones | {4})  # zero CD8 exits to address00001
    goal = execute(original, ones, (84, 0, set(expected)))
    require(goal['steps'] == 510, 'reference primitive duration')
    require(old[0]['state'] == new[0]['state'] == 84 and old[0]['head'] == new[0]['head'] == 0,
            'first synchronization state/head')
    require(old[0]['one_cells'] == new[0]['one_cells'], 'first synchronization tape')
    require(old[1]['one_cells'] == new[1]['one_cells'], 'second return tape')
    require(old[1]['head'] == 0 and new[1]['head'] == 8, 'origin-return mismatch')
    return {'status': 'ORIGIN_RETURN_MISMATCH_REPRODUCED',
            'source_site': ['000000', 'CD', 8], 'positive': False,
            'header_distance': 56, 'extra_gap': 0, 'primary_registers': [0]*9,
            'spare_registers': [1], 'initial_one_cells': sorted(ones),
            'expected_successor_address': '00001', 'expected_one_cells': expected,
            'accepted_U212_dispatcher_returns': old,
            'rejected_211_state_mutant_dispatcher_returns': new,
            'accepted_U212_complete_primitive': goal,
            'scope': 'After a shared intermediate configuration arising from a legal primitive frame, '
                     'the next decoder return has head displacement8 instead of0. This refutes the '
                     'unchanged origin-return contract used by the inherited proof. It does not '
                     'establish eventual behavior of the mutant or reachability from blank.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = check()
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
