U212 by stacking compatible reductions
=====================================
Prepared for Vladimir Reshetnikov, 28 October 2026.

RESULT
------
machine/u212.tm has 212 working states (0..211), separate halt label 212,
424 transitions, one binary tape and one head. Every move is L or R.
Start in state 0, head 0, on a completely blank all-zero, two-way tape.
Initialization is included. Native table halt is 254; native labels are
inherited names, not state counts.

The successful stack combines:
  B: U213_ConPA_2026-10-28 (1).zip
     direct-transfer source and seven-zero origin detector;
  H: u213_from_u214_2026-10-28.zip
     entry bypass and strengthened invariant, adapted to B's helper 211.

Relative to B's exact native table:
  180 1 1 R 172  ->  180 1 1 R 211
  172 0 0 L 112  ->  172 0 0 L 67
Delete both rows of native 112. No other retained row changes.

WHAT IS PROVED
--------------
The report supplies a complete local whole-tape block proof that this
literal U212 and the selected U213 parent halt equivalently from state 0.
The semantic proof applies to any initial tape; its PA formalization is
uniform for encoded finite-support initial tapes, including blank.
On halting runs, T(U212) <= T(parent) <= 7*T(U212)/3.

Composing this new reduction with the preserved mathematical parent
calibration and unary theory interpretations yields
  PA |- not Halt(U212,blank) <-> Con(U) <-> Con(PA).
No new compiled Lean/Rocq/MM0/exported PA endpoint is claimed. No consistency
assumption is needed for the biconditional. Actual non-halting follows if
PA is consistent. No absolute minimality or priority claim is made.

CHECKS
------
- Two independently written local checkers, four universal pattern cases,
  complete predecessor inventories, and seven rejected semantic mutations.
- All 5,084 symbolic arbitrary-natural primitive cases freshly rederived;
  all 424 transition rows covered; 1,275,761 symbolic inference applications.
- Complete 48,140-step blank startup, copied exactly from parent; neither
  edited row occurs. Native state 84, head -2, source ordinal 136, header distance 56,
  registers (1,0,13,0,0,1,0,0,1), 43 spares each 1, and 120 one-cells.
- Fresh parent reconstruction and inherited U214/U218 audit.
- Exact eight-way comparison of source/table differences, preserved hashes,
  and state-renaming-independent rooted graph identities.

These runtime cases use unary and finite-list induction implemented in
Python, not bounded samples of register values. Their conventional
mathematical proof rules are retained verbatim from the parent. They are
not proof-assistant kernel certificates.

REPRODUCE OFFLINE
-----------------
Python 3.10+; standard library only; no network or solver.
  python3 -B reproduce.py
  python3 -B reproduce.py --full --report /tmp/u212-replay.json
The default checks finite reconstruction, local proofs, startup, comparison,
saved runtime binding, and the exact parent's full default audit.
--full additionally rederives all 5,084 symbolic cases. Do not run Python -O.
Use an external receipt path so the immutable package's manifest stays valid.

BUILD PDF
---------
  cd paper
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
PDF bytes may depend on the local TeX installation; literal table hashes do not.

KEY FILES
---------
paper/report.tex and report.pdf       Report and complete dense table.
machine/u212.tm and u212.native.tm    Dense/native literal machines.
machine/sites.json                   Exact unchanged 3,909-primitive source.
machine/state_map.json               Native/dense bijection.
machine/summary.json                 Counts and identities.
code/                               Deterministic build and verification.
evidence/                           Actual successful receipts.
inputs/U213_parent.zip               Exact original parent, nested dependencies.
comparison/                         Eight candidate table/source slices and hashes.
research/                           Rejected detector shortcut and further search.
licenses/                           Preserved inherited notices.

PROVENANCE AND HASHES
--------------------
ProveIt snapshot: 6b3145c0bbbf7563bd7bce44c974b4515656a5b0.
Exact parent archive (original name U213_ConPA_2026-10-28 (1).zip):
09e869763555e19d73f1b7900eee7305105ee02219196dcc88bb6854f34d7f29
Dense U212:
c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e
Native U212:
386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4
Unchanged source:
7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00

The report includes Further research questions. The explored alternate 212
rotation route has not been validated as a second endpoint; it is recorded
only to explain why it does not give a justified 211-state stack.
