#!/usr/bin/env python3
"""Independent opaque-exterior proof checker for the U213 -> U212 reduction.

Standard library only. Reads exact literal tables; imports no builder or
simulation engine. An unmentioned tape cell is opaque, not zero. Reading
one fails the check. Thus the four constant path identities cover every
completion of their indicated cells, not sampled finite tapes.
"""
from pathlib import Path
import argparse
import hashlib
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def parse(path):
    table = {}
    starts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q, b, w, d, z = line.split()
            q, b, w, z = map(int, (q, b, w, z))
            require(b in (0, 1) and w in (0, 1) and d in ('L', 'R'), 'malformed row')
            require((q, b) not in table, 'duplicate row')
            table[q, b] = w, 1 if d == 'R' else -1, z
    require(starts == [0], 'start convention')
    return table


def census(table, count, halt):
    states = {q for q, _ in table}
    require(len(states) == count and len(table) == count * 2, 'wrong state count')
    require(set(table) == {(q, b) for q in states for b in (0, 1)}, 'table not total')
    require(0 in states and halt not in states, 'start/halt')
    require({z for _, _, z in table.values()} - states == {halt}, 'unclosed targets')
    reached, pending = {0}, [0]
    for q in pending:
        for b in (0, 1):
            z = table[q, b][2]
            if z != halt and z not in reached:
                reached.add(z)
                pending.append(z)
    require(reached == states, 'unreachable state in directed transition graph')
    return states


def incoming(table, target):
    return sorted([q, b, *value] for (q, b), value in table.items() if value[2] == target)


def path(table, state, cells, count):
    tape = dict(cells)
    head = 0
    trace = []
    for _ in range(count):
        require(state != 254, 'interior halt')
        require(head in tape, 'read of opaque exterior')
        read = tape[head]
        write, direction, nxt = table[state, read]
        trace.append([state, head, read, write, direction, nxt])
        tape[head] = write
        state, head = nxt, head + direction
    return (state, head, tape), trace


def identity(old, new, q, cells, old_length, new_length, endpoint):
    x, xt = path(old, q, cells, old_length)
    y, yt = path(new, q, cells, new_length)
    require(x == y, 'path configurations disagree')
    require(x[:2] == endpoint and x[2] == cells, 'incorrect endpoint or tape write')
    return {'initial_state': q, 'specified_cells': sorted(cells.items()),
            'old_steps': old_length, 'new_steps': new_length,
            'endpoint': list(endpoint), 'old_trace': xt, 'new_trace': yt,
            'opaque_exterior_unread': True, 'entire_tape_unchanged': True}


def proof_obligations(parent, candidate):
    intermediate = dict(parent)
    intermediate[180, 1] = candidate[180, 1]
    bypass = [
        identity(parent, intermediate, 180, {0: 1, 1: 1}, 2, 2, (184, 2)),
        identity(parent, intermediate, 180, {0: 1, 1: 0, 2: 0}, 7, 3, (90, 3)),
        identity(parent, intermediate, 180, {0: 1, 1: 0, 2: 1}, 7, 3, (86, 3)),
    ]
    require(incoming(parent, 172) == [[116, 0, 0, 1, 172], [180, 1, 1, 1, 172]],
            'parent predecessor inventory')
    require(incoming(intermediate, 172) == [[116, 0, 0, 1, 172]], '172 guard')
    require(incoming(intermediate, 112) == [[172, 0, 0, -1, 112]], '112 guard')
    require(incoming(candidate, 172) == [[116, 0, 0, 1, 172]], 'candidate 172 guard')
    require(incoming(candidate, 112) == [], 'remaining edge to deleted state')
    deletion = identity(intermediate, candidate, 172, {-1: 0, 0: 0}, 4, 2, (151, 0))
    return {'bypass_blocks': bypass, 'guarded_deletion_block': deletion,
            'parent_incoming_172': incoming(parent, 172),
            'intermediate_incoming_172': incoming(intermediate, 172),
            'intermediate_incoming_112': incoming(intermediate, 112)}


def check(parent_path, candidate_path):
    parent, candidate = parse(parent_path), parse(candidate_path)
    census(parent, 213, 254)
    census(candidate, 212, 254)
    require(set(parent) - set(candidate) == {(112, 0), (112, 1)}, 'deleted rows')
    require(not (set(candidate) - set(parent)), 'added rows')
    delta = {key: value for key, value in candidate.items() if value != parent[key]}
    require(delta == {(180, 1): (1, 1, 211), (172, 0): (0, -1, 67)}, 'retained-row delta')
    certificate = proof_obligations(parent, candidate)
    controls = []
    for name, edits in [
        ('wrong inherited helper label 167', {(180, 1): (1, 1, 167)}),
        ('wrong target for the guarded deletion', {(172, 0): (0, -1, 151)}),
        ('wrong bit in the bypass entry', {(180, 1): (0, 1, 211)}),
    ]:
        mutant = dict(candidate)
        mutant.update(edits)
        try:
            proof_obligations(parent, mutant)
        except (ValueError, KeyError) as error:
            controls.append({'name': name, 'rejected': True, 'reason': str(error)})
        else:
            raise ValueError('negative control accepted: ' + name)
    return {'status': 'OPAQUE_EXTERIOR_LOCAL_PROOF_PASS', 'working_states': 212,
            'transition_rows': 424, 'retained_row_edits': 2, 'deleted_state': 112,
            'parent_native_sha256': hashlib.sha256(Path(parent_path).read_bytes()).hexdigest(),
            'candidate_native_sha256': hashlib.sha256(Path(candidate_path).read_bytes()).hexdigest(),
            **certificate, 'negative_controls': controls,
            'scope': 'Four universal finite path identities and complete incoming-edge inventories. '
                     'The accompanying induction proves halting equivalence from state 0 on any initial tape. '
                     'PA formalization is a written mathematical argument, not a kernel-checked certificate.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('parent', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = check(args.parent, args.candidate)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'working_states', 'transition_rows', 'retained_row_edits', 'deleted_state')}, indent=2))
