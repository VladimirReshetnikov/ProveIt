#!/usr/bin/env python3
"""Reconstruct U212 deterministically from the exact pinned U213 parent."""
from pathlib import Path
import argparse
import hashlib
import json
from check_local_independent import parse, census, require

PARENT_SHA256 = 'bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7'
SOURCE_SHA256 = '7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'


def serialize(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(table.items()))).encode('ascii')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def build(parent, source, output):
    parent, source, output = Path(parent), Path(source), Path(output)
    require(sha(parent.read_bytes()) == PARENT_SHA256, 'unpinned parent table')
    require(sha(source.read_bytes()) == SOURCE_SHA256, 'unpinned source')
    table = parse(parent)
    census(table, 213, 254)
    require(table[180, 1] == (1, 1, 172) and table[172, 0] == (0, -1, 112), 'old rows')
    table[180, 1] = 1, 1, 211
    table[172, 0] = 0, -1, 67
    del table[112, 0]
    del table[112, 1]
    states = census(table, 212, 254)
    mapping = {q: i for i, q in enumerate(sorted(states))}
    mapping[254] = 212
    dense = {(mapping[q], b): (w, d, mapping[z]) for (q, b), (w, d, z) in table.items()}
    census(dense, 212, 212)
    output.mkdir(parents=True, exist_ok=True)
    native_bytes, dense_bytes = serialize(table), serialize(dense)
    (output/'u212.native.tm').write_bytes(native_bytes)
    (output/'u212.tm').write_bytes(dense_bytes)
    (output/'sites.json').write_bytes(source.read_bytes())
    maps = {'native_to_dense': {str(q): z for q, z in mapping.items()},
            'dense_to_native': {str(z): q for q, z in mapping.items()}}
    (output/'state_map.json').write_text(json.dumps(maps, indent=2) + '\n')
    result = {'working_states': 212, 'transition_rows': 424, 'start_state': 0,
              'dense_halt': 212, 'native_halt': 254, 'alphabet': [0, 1],
              'tapes': 1, 'directions': ['L', 'R'], 'blank_symbol': 0,
              'parent_native_sha256': PARENT_SHA256,
              'native_sha256': sha(native_bytes), 'dense_sha256': sha(dense_bytes),
              'source_sha256': SOURCE_SHA256, 'retained_row_edits': 2,
              'deleted_native_state': 112, 'graph_reachable_working_states': len(states),
              'source_primitive_occurrences': 3909, 'source_distinct_subtrees': 197}
    (output/'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('parent', type=Path)
    p.add_argument('source', type=Path)
    p.add_argument('output', type=Path)
    a = p.parse_args()
    print(json.dumps(build(a.parent, a.source, a.output), indent=2))
