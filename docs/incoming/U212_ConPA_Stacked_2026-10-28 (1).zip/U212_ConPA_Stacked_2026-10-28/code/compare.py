#!/usr/bin/env python3
"""Recompute the eight-way table/source comparison from frozen input slices."""
from pathlib import Path
import argparse
import hashlib
import json
from check_local_independent import parse, census, require


def digest(data):
    return hashlib.sha256(data).hexdigest()


def tree_metrics(rows):
    leaves = {p: (op, arg) for p, op, arg in rows}
    require(len(leaves) == len(rows), 'repeated source address')
    prefixes = {p[:j] for p in leaves for j in range(len(p))}
    require(not prefixes.intersection(leaves), 'prefix collision')
    visited = set()
    def tree(p):
        if p in leaves:
            node = leaves[p]
        else:
            require(p in prefixes and all(p+b in prefixes or p+b in leaves for b in '01'), 'incomplete tree')
            node = tree(p+'0'), tree(p+'1')
        visited.add(node)
        return node
    tree('')
    return {'dag_nodes': len(visited), 'leaf_occurrences': len(rows),
            'maximum_depth': max(len(p) for p in leaves),
            'maximum_zero_run': max(len(z) for p in leaves for z in p.split('1'))}


def canonical(table):
    names, order, encoded = {0: 0}, [0], []
    for q in order:
        row = []
        for bit in (0, 1):
            w, d, z = table[q, bit]
            if z == 254:
                target = 'HALT'
            else:
                if z not in names:
                    names[z] = len(order)
                    order.append(z)
                target = names[z]
            row.append([w, d, target])
        encoded.append(row)
    require(set(names) == {q for q, _ in table}, 'not every state graph-reachable')
    return digest(json.dumps(encoded, separators=(',', ':')).encode())


def check(root):
    root = Path(root)
    entries = json.loads((root/'comparison/comparison.json').read_text())
    baseline = parse(root/'comparison/u214.native.tm')
    base_source = json.loads((root/'comparison/u214.sites.json').read_text())
    census(baseline, 214, 254)
    results = []
    for entry in entries:
        folder = root/'comparison'/entry['id']
        native, source = folder/'native.tm', folder/'sites.json'
        require(digest(native.read_bytes()) == entry['native_sha256'], 'native binding')
        require(digest(source.read_bytes()) == entry['source_sha256'], 'source binding')
        table, rows = parse(native), json.loads(source.read_text())
        states = census(table, 213, 254)
        before = {q for q, _ in baseline}
        deleted, added = sorted(before-states), sorted(states-before)
        changes = sum(table[k] != baseline[k] for k in table.keys() & baseline.keys())
        require((deleted, added, changes) == (entry['deleted'], entry['added'], entry['changed_retained_rows']), 'delta comparison')
        require(len(rows) == entry['primitive_count'], 'primitive census')
        same_ops = [r[1:] for r in rows] == [r[1:] for r in base_source]
        require(same_ops == entry['same_opcode_operand_sequence'], 'opcode comparison')
        addresses = sum(a[0] != b[0] for a, b in zip(rows, base_source)) if len(rows) == len(base_source) else None
        require(addresses == entry['address_changes'], 'address comparison')
        results.append({'id': entry['id'], 'archive': entry['archive'],
                        'working_states': len(states), 'metrics': tree_metrics(rows),
                        'retained_row_changes': changes, 'deleted': deleted, 'added': added,
                        'canonical_transition_graph_sha256': canonical(table)})
    require(len({r['canonical_transition_graph_sha256'] for r in results}) == 8, 'duplicate rooted graph')
    require((root/'machine/sites.json').read_bytes() == (root/'comparison/B/sites.json').read_bytes(), 'new source differs from B')
    return {'status': 'EIGHT_WAY_COMPARISON_PASS', 'pairwise_nonisomorphic_rooted_tables': True,
            'candidates': results, 'new_source_exactly_B': True,
            'scope': 'Native transition deltas, complete source metrics and rooted ordered graph identities. '
                     'Graph reachability is not blank-run reachability; this is not a semantic inequivalence claim.'}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('root', type=Path)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    result = check(a.root)
    if a.output:
        a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
