#!/usr/bin/env python3
"""Independent finite, complete-tape blank startup and dense/native check."""
from pathlib import Path
import argparse
import hashlib
import json


def need(ok, msg):
    if not ok:
        raise ValueError(msg)


def read(path):
    table = {}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        need(d in ('L', 'R'), 'direction')
        key = int(q), int(b)
        need(key not in table and key[1] in (0, 1) and int(w) in (0, 1), 'transition')
        table[key] = int(w), (1 if d == 'R' else -1), int(z)
    return table


def run(table, bound):
    q, head, ones = 0, 0, set()
    visited = set()
    trace_hash = hashlib.sha256()
    for step in range(bound):
        bit = int(head in ones)
        visited.add((q, bit))
        w, d, z = table[q, bit]
        trace_hash.update(f'{step} {q} {head} {bit} {w} {d} {z}\n'.encode())
        if w:
            ones.add(head)
        else:
            ones.discard(head)
        q, head = z, head + d
    return q, head, ones, visited, trace_hash.hexdigest()


def check(root):
    root = Path(root)
    parent = read(root/'inputs/u213_parent.native.tm')
    native = read(root/'machine/u212.native.tm')
    dense = read(root/'machine/u212.tm')
    states = sorted({q for q, _ in native})
    m = {q: i for i, q in enumerate(states)}
    m[254] = len(states)
    need(dense == {(m[q], b): (w, d, m[z]) for (q, b), (w, d, z) in native.items()}, 'dense/native relation')
    bound = 48140
    a, c, d = (run(t, bound) for t in (parent, native, dense))
    need(a == c, 'native startup differs from parent')
    need(not ({(180, 1), (172, 0)} & c[3]), 'edited row visited during unchanged startup')
    need(d[:3] == (m[c[0]], c[1], c[2]), 'dense startup mismatch')
    need(c[:2] == (84, -2), 'startup state/head')
    address = '001100110101010'
    rows = json.loads((root/'machine/sites.json').read_text())
    need(rows[136][0] == address, 'source address')
    logical = [1, 0, 13, 0, 0, 1, 0, 0, 1]
    physical = [0]*9
    for i, j in enumerate((6, 2, 0, 4, 3, 7, 8, 5, 1)):
        physical[j] = logical[i]
    expected = {-3, 54}
    expected.update(-2+i for i, bit in enumerate(address) if bit == '1')
    cursor = 55
    for value in physical + [1]*43:
        expected.update(range(cursor+1, cursor+value+2))
        cursor += value + 2
    need(c[2] == expected and len(expected) == 120, 'complete frame including all zero exterior')
    return {'status': 'INDEPENDENT_COMPLETE_STARTUP_PASS', 'literal_steps': bound,
            'native_state': 84, 'dense_state': m[84], 'head': -2,
            'source_ordinal': 136, 'source_address': address,
            'header_coordinate': 54, 'header_distance': 56, 'additional_gap': 0,
            'logical_registers': logical, 'spare_registers': [1]*43,
            'one_cells': sorted(expected), 'native_trace_sha256': c[4],
            'dense_trace_sha256': d[4], 'edited_rows_visited': 0,
            'scope': 'Exactly 48140 finite steps from the completely blank tape; exact endpoint and zero exterior. '
                     'This startup check alone is not an argument for non-halting.'}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('root', type=Path)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    result = check(a.root)
    if a.output:
        a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('one_cells', 'spare_registers')}, indent=2))
