#!/usr/bin/env python3
"""Independent finite premises of the U213 -> U212 local proof.

This uses no received project module. Unknown tape cells are opaque and
cause failure if read. A successful finite trace is consequently uniform
over every binary completion of the specified cells.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def parse(path):
    rows = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        require(len(parts) == 5, 'malformed row')
        state, read, write, direction, target = parts
        key = (int(state), int(read))
        require(key not in rows, 'duplicate row')
        require(int(read) in (0, 1) and int(write) in (0, 1), 'nonbinary row')
        require(direction in ('L', 'R'), 'nonmoving row')
        rows[key] = (int(write), direction, int(target))
    states = {s for s, _ in rows}
    require(set(rows) == {(s, bit) for s in states for bit in (0, 1)},
            'missing transition')
    require(254 not in states, 'halt has outgoing rows')
    require(all(t in states or t == 254 for _, _, t in rows.values()),
            'undefined target')
    return rows


def run(rows, state, known_cells, steps):
    tape = dict(known_cells)
    head = 0
    trace = [[state, head]]
    reads = []
    for _ in range(steps):
        require(state != 254, 'premature halt')
        require(head in tape, 'read of opaque exterior')
        reads.append(head)
        write, direction, state = rows[state, tape[head]]
        tape[head] = write
        head += 1 if direction == 'R' else -1
        trace.append([state, head])
    return (state, head, tape), {'trace': trace, 'read_cells': reads}


def check(parent, child):
    require(len(parent) == 426 and len(child) == 424, 'wrong state counts')
    middle = dict(parent)
    require(middle[180, 1] == (1, 'R', 172), 'wrong parent patch row')
    require(middle[172, 0] == (0, 'L', 112), 'wrong detour entrance')
    middle[180, 1] = (1, 'R', 211)
    expected = dict(middle)
    expected[172, 0] = (0, 'L', 67)
    del expected[112, 0]
    del expected[112, 1]
    require(child == expected, 'not exactly the prescribed two-row patch')

    case_results = []
    for cells, old_steps, new_steps, goal in [
        ({0: 1, 1: 1}, 2, 2, (184, 2)),
        ({0: 1, 1: 0, 2: 0}, 7, 3, (90, 3)),
        ({0: 1, 1: 0, 2: 1}, 7, 3, (86, 3)),
    ]:
        old, old_trace = run(parent, 180, cells, old_steps)
        new, new_trace = run(middle, 180, cells, new_steps)
        require(old == new, 'retiming endpoint disagreement')
        require(old[:2] == goal and old[2] == cells, 'wrong retiming endpoint')
        case_results.append({'cells': cells, 'old_steps': old_steps,
                             'new_steps': new_steps, 'old': old_trace,
                             'new': new_trace, 'goal': goal})

    incoming172 = sorted(k for k, v in middle.items() if v[2] == 172)
    incoming112 = sorted(k for k, v in middle.items() if v[2] == 112)
    require(incoming172 == [(116, 0)], 'unprotected entry to state172')
    require(middle[116, 0] == (0, 'R', 172), 'entry does not write preceding0')
    require(incoming112 == [(172, 0)], 'unprotected entry to state112')

    def phi(state):
        return 67 if state == 112 else state

    for (s, bit), (w, d, target) in middle.items():
        if s != 112:
            require(child[s, bit] == (w, d, phi(target)), 'noncommuting row')

    old, old_trace = run(middle, 112, {0: 0, 1: 0}, 3)
    new, new_trace = run(child, 67, {0: 0, 1: 0}, 1)
    require(old == new == (151, 1, {0: 0, 1: 0}), 'detour endpoint mismatch')
    return {'status': 'PASS', 'working_states': [213, 213, 212],
            'retiming_cases': case_results,
            'incoming172': incoming172, 'incoming112': incoming112,
            'commuting_rows': 424,
            'detour': {'old_steps': 3, 'new_steps': 1,
                       'old': old_trace, 'new': new_trace},
            'proof_scope': 'Finite premises of the separate two-stage mathematical block-simulation proof.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('parent', type=Path)
    parser.add_argument('child', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    parent, child = parse(args.parent), parse(args.child)
    result = check(parent, child)
    result['parent_sha256'] = hashlib.sha256(args.parent.read_bytes()).hexdigest()
    result['child_sha256'] = hashlib.sha256(args.child.read_bytes()).hexdigest()
    controls = []
    # Mutate both tables consistently so rejection must come from the local
    # semantic or predecessor-premise check, not the exact patch comparison.
    for name, key, value in [
        ('bad_shared_decoder', (211, 0), (0, 'R', 86)),
        ('extra_unprotected_entry', (1, 0), (0, 'L', 172)),
        ('wrong_zero_helper', (157, 0), (1, 'L', 67)),
        ('changed_entry_write', (116, 0), (1, 'R', 172)),
    ]:
        mutant_parent, mutant_child = dict(parent), dict(child)
        mutant_parent[key] = value
        mutant_child[key] = value
        try:
            check(mutant_parent, mutant_child)
        except ValueError as error:
            controls.append({'name': name, 'rejected': True, 'reason': str(error)})
        else:
            raise ValueError('negative control accepted: ' + name)
    result['negative_controls'] = controls
    data = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(data)
    print(data)


if __name__ == '__main__':
    main()
