#!/usr/bin/env python3
"""Fresh unary/list-inductive replay of all exact U212 primitive contracts."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time
import symbolic_runtime as s
from check_local_independent import parse, census, require
from build import SOURCE_SHA256


def replay(root, output):
    require(__debug__ and not sys.flags.optimize, 'Disable -O and PYTHONOPTIMIZE for the inherited checker')
    root, output = Path(root), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    source = root/'machine/sites.json'
    table_path = root/'machine/u212.native.tm'
    require(hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_SHA256, 'source changed')
    table = parse(table_path)
    states = census(table, 212, 254)
    sites = json.loads(source.read_text())
    require(len(sites) == 3909, 'source count')
    mapping = {int(k): int(v) for k, v in json.loads((root/'inputs/legacy_mapping.json').read_text()).items()}
    for q in states | {254}:
        mapping.setdefault(q, q + 1000)
    require(len({mapping[q] for q in states | {254}}) == len(states) + 1, 'state mapping collision')
    require(mapping[84] == 96 and mapping[254] == 254 and s.HEADER_BASE == 56, 'runtime conventions')
    literal = {(mapping[q], b): (w, d, mapping[z]) for (q, b), (w, d, z) in table.items()}
    lemmas, blocks = s.prove_blocks(literal)
    cases, used = [], set()
    begun = time.monotonic()
    for index, site in enumerate(sites):
        for positive in ((False, True) if site[1] == 'CD' else (False,)):
            answer = s.case(literal, lemmas, site, positive)
            used.update(answer['rows'])
            answer['rows'] = sorted(answer['rows'])
            answer.pop('trace')
            cases.append({'site_index': index, 'positive': positive, **answer})
        if (index + 1) % 1000 == 0:
            print(f'Proved {len(cases)} primitive cases', flush=True)
    for block in blocks:
        for event in block['trace']:
            used.add(tuple(event[1][:2]))
    require(len(cases) == 5084, 'case coverage')
    require(used == set(literal), 'literal transition coverage')
    result = {'status': 'UNIVERSAL_MATHEMATICAL_PASS',
              'table_sha256': hashlib.sha256(table_path.read_bytes()).hexdigest(),
              'source_sha256': SOURCE_SHA256, 'working_states': 212,
              'site_count': 3909, 'proved_cases': len(cases), 'header_base': 56,
              'literal_rows_covered': len(used),
              'symbolic_steps': sum(c['symbolic_steps'] for c in cases),
              'minimum_duration_constant': min(c['duration'][0] for c in cases),
              'blocks': blocks, 'seconds': time.monotonic() - begun,
              'scope': 'Inherited unary/list induction rules on arbitrary natural registers, '
                       'nonnegative gap and nonempty finite spare list with full zero exterior. '
                       'No proof-assistant endpoint certificate.'}
    (output/'runtime.json').write_text(json.dumps(result, indent=2) + '\n')
    (output/'runtime_cases.json').write_text(json.dumps(cases, separators=(',', ':')) + '\n')
    return result, cases


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('root', type=Path)
    p.add_argument('output', type=Path)
    a = p.parse_args()
    result, _ = replay(a.root, a.output)
    print(json.dumps({k: v for k, v in result.items() if k != 'blocks'}, indent=2))
