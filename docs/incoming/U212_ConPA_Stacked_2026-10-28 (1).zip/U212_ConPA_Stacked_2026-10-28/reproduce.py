#!/usr/bin/env python3
"""Offline reconstruction, proof premises, startup, comparison and runtime replay."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import time
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'code'))
from build import build
from check_local_independent import check as check_local, require
from check_startup import check as check_startup
from compare import check as check_comparison

PARENT_ARCHIVE_SHA256 = '09e869763555e19d73f1b7900eee7305105ee02219196dcc88bb6854f34d7f29'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(args, cwd):
    result = subprocess.run([sys.executable, '-B', *map(str, args)],
                            cwd=cwd, text=True, capture_output=True)
    require(result.returncode == 0, result.stdout+'\n'+result.stderr)
    return result.stdout


def verify_manifest():
    names = []
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        checksum, relative = line.split('  ', 1)
        path = (ROOT/relative).resolve()
        require(path.is_relative_to(ROOT) and path.is_file(), 'manifest path')
        require(sha(path) == checksum, 'manifest mismatch: '+relative)
        names.append(relative)
    require(len(names) == len(set(names)), 'duplicate manifest entry')
    return len(names)


def parent_replay(work):
    archive = ROOT/'inputs/U213_parent.zip'
    require(sha(archive) == PARENT_ARCHIVE_SHA256, 'parent archive changed')
    dest = work/'parent'
    dest.mkdir()
    with zipfile.ZipFile(archive) as z:
        for member in z.infolist():
            require((dest/member.filename).resolve().is_relative_to(dest.resolve()), 'unsafe parent archive path')
        z.extractall(dest)
    parent = dest/'U213_ConPA_2026-10-28'
    require((parent/'machine/u213.native.tm').read_bytes() == (ROOT/'inputs/u213_parent.native.tm').read_bytes(), 'parent table binding')
    require((parent/'machine/sites.json').read_bytes() == (ROOT/'machine/sites.json').read_bytes(), 'source binding')
    for name in ('symbolic_runtime.py', 'independent_runtime.py'):
        require((parent/'code'/name).read_bytes() == (ROOT/'code'/name).read_bytes(), 'inherited induction rule changed: '+name)
    command([parent/'reproduce.py', '--report', work/'parent.json'], parent)
    report = json.loads((work/'parent.json').read_text())
    require(report['status'] == 'U213_FINITE_REPLAY_PASS', 'parent replay failed')
    return {'status': report['status'], 'parent_archive_sha256': PARENT_ARCHIVE_SHA256,
            'parent_manifest_files': report['manifest_files'],
            'inherited_U214_status': report['parent']['status'],
            'inherited_U218_audit': report['parent']['inherited_U218_audit'],
            'parent_runtime_cases_freshly_rederived': report['runtime_cases_rederived'],
            'induction_modules_copied_verbatim': True}


def frozen_runtime():
    report = json.loads((ROOT/'evidence/runtime.json').read_text())
    cases = json.loads((ROOT/'evidence/runtime_cases.json').read_text())
    sites = json.loads((ROOT/'machine/sites.json').read_text())
    expected = [(i, p) for i, site in enumerate(sites)
                for p in ((False, True) if site[1] == 'CD' else (False,))]
    require([(c['site_index'], c['positive']) for c in cases] == expected, 'frozen case inventory')
    require(report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS' and len(cases) == report['proved_cases'] == 5084, 'frozen count/status')
    require(report['table_sha256'] == sha(ROOT/'machine/u212.native.tm'), 'runtime table binding')
    require(report['source_sha256'] == sha(ROOT/'machine/sites.json'), 'runtime source binding')
    require(report['working_states'] == 212 and report['literal_rows_covered'] == 424, 'runtime table census')
    for case in cases:
        require(len(case['duration']) == 13 and all(n >= 0 for n in case['duration'])
                and case['duration'][0] > 0, 'invalid duration coefficients')
    require(sum(c['symbolic_steps'] for c in cases) == 1275761, 'symbolic inference count')
    return report, cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true', help='freshly rederive all 5084 symbolic primitive cases')
    parser.add_argument('--report', type=Path, help='write a JSON receipt outside the immutable package')
    args = parser.parse_args()
    require(__debug__ and not sys.flags.optimize, 'Run without -O or PYTHONOPTIMIZE')
    started = time.monotonic()
    manifest_count = verify_manifest()
    with tempfile.TemporaryDirectory(prefix='u212-replay-') as directory:
        work = Path(directory)
        construction = build(ROOT/'inputs/u213_parent.native.tm', ROOT/'machine/sites.json', work/'machine')
        for name in ('u212.native.tm', 'u212.tm', 'sites.json', 'state_map.json', 'summary.json'):
            require((work/'machine'/name).read_bytes() == (ROOT/'machine'/name).read_bytes(), 'reconstruction differs: '+name)
        local = json.loads(json.dumps(check_local(ROOT/'inputs/u213_parent.native.tm', ROOT/'machine/u212.native.tm')))
        require(local == json.loads((ROOT/'evidence/local_proof.json').read_text()), 'local proof receipt changed')
        startup = check_startup(ROOT)
        require(startup == json.loads((ROOT/'evidence/startup.json').read_text()), 'startup receipt changed')
        comparison = check_comparison(ROOT)
        require(comparison == json.loads((ROOT/'evidence/comparison.json').read_text()), 'comparison receipt changed')
        command([ROOT/'code/check_local_second.py', ROOT/'inputs/u213_parent.native.tm',
                 ROOT/'machine/u212.native.tm', '--output', work/'second.json'], ROOT)
        require(json.loads((work/'second.json').read_text()) == json.loads((ROOT/'evidence/local_second.json').read_text()), 'second proof receipt changed')
        command([ROOT/'research/detector6_counterexample.py', '--output', work/'detector.json'], ROOT)
        require(json.loads((work/'detector.json').read_text()) == json.loads((ROOT/'research/detector6_counterexample.json').read_text()), 'detector diagnostic changed')
        inherited = parent_replay(work)
        frozen, old_cases = frozen_runtime()
        fresh = None
        if args.full:
            from check_runtime import replay
            fresh, new_cases = replay(ROOT, work/'runtime')
            require(json.loads(json.dumps(new_cases)) == old_cases, 'fresh runtime derivations differ from recorded ones')
            for key in ('table_sha256', 'source_sha256', 'working_states', 'proved_cases',
                        'header_base', 'literal_rows_covered', 'symbolic_steps', 'minimum_duration_constant'):
                require(fresh[key] == frozen[key], 'fresh runtime metric differs: '+key)
        result = {'status': 'U212_FULL_REPLAY_PASS' if args.full else 'U212_FINITE_REPLAY_PASS',
                  'manifest_files': manifest_count, 'construction': construction,
                  'independent_local_checks': 2, 'local_path_cases': 4,
                  'local_semantic_negative_controls_rejected': 7,
                  'complete_startup_steps': startup['literal_steps'],
                  'startup_source_ordinal': startup['source_ordinal'],
                  'startup_edited_rows_visited': startup['edited_rows_visited'],
                  'comparison_candidates': len(comparison['candidates']),
                  'parent': inherited, 'symbolic_cases_freshly_rederived': 5084 if fresh else 0,
                  'literal_rows_covered': 424, 'symbolic_inferences': 1275761,
                  'minimum_duration_constant': 5,
                  'six_zero_detector_diagnostic': 'ORIGIN_RETURN_MISMATCH_REPRODUCED',
                  'seconds': round(time.monotonic()-started, 3),
                  'scope': 'Exact reconstruction, two independent local proof-premise checks, complete startup, '
                           'eight-way comparison and inherited parent audit. --full rederives all symbolic '
                           'natural-number/list contracts. The written PA-formalizable proof and retained '
                           'U/PA interpretations are mathematical dependencies; no new proof-assistant endpoint.'}
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
