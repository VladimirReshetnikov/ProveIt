# Cauchy Limits, Arithmetic Atoms, and Edge Laws for Matrix-Composition Hankel Zeros

Research article prepared October 5, 2026.

The article answers the explicit question about the limiting zero distribution
in ProveIt's matrix-composition report associated with OEIS A261781. It credits
the existing determinant factorization and develops its arithmetic and
asymptotic zero theory.

## Contents

- `a261781_hankel_zero_laws.pdf`: the complete article, with proofs, four figures,
  exact-check tables, source attribution, and nine further research questions.
- `a261781_hankel_zero_laws.tex`: the complete LaTeX source, with bibliography.
- `figures/`: four vector PDF figures and matching 300-dpi PNGs.
- `code/reproduce.py`: the independent verification and figure-generation program.
- `code/README.txt`: detailed computation and data documentation.
- `data/`: exact rational data, numerical illustrations, and verification records.
- `PROVENANCE.md`: source snapshot and contribution boundary.
- `requirements.txt`: Python package versions used for reproduction.
- `build.sh`: a simple PDF rebuild command.

## Principal results

Write

    R_k(u) = product_{1 <= i < j <= k}
      ((1+u)^q - u^q)^(2g),
    g = gcd(i,j), q = (j-i)/g.

This is the factor remaining after removing the powers at 0 and -1
and the nonzero constant from the maximal Hankel determinant.
Its normalized zero measure is defined for k >= 3.

1. The zeros converge to the law of -1/2 + iY, where Y is Cauchy with
   scale 1/2.
2. The Kolmogorov distance is asymptotic to
   (9/pi^2) log(k)/k. The article proves the exact constant, including
   the required moving-endpoint control.
3. Each primitive order-m zero has multiplicity
   k^2 log(k)/(zeta(2) psi(m)) + O(k^2), where psi is Dedekind's psi
   function. The absolute error constant is uniform in m.
4. Smooth statistics have an explicit first correction, while rational
   CDF endpoints retain arithmetic corrections.
5. At height kx, the one-sided rare-tail limit is

       Xi(x) = (3/zeta(2)) sum_{n >= 1}
                 sigma_{-1}(n) (1 - 2 pi n x)_+^2.

   The sum is finite. The article gives the edge density, its cutoff,
   a small-x expansion with its constant, and a uniform transition
   to every mesoscopic height y -> infinity with y = o(k).
6. Absolute moments converge for 0 < p < 1, grow logarithmically at
   p = 1, and grow as explicit constants times k^(p-1) for p > 1.
   The critical first moment includes its exact constant term.
7. The full-degree zero measure depends on the limiting shift s/k^2.
   For a fixed shift it has equal limiting masses at 0, at -1,
   and on the Cauchy component.

The article provides conventional mathematical proofs. It is unrefereed and
is not a proof-assistant formalization. The finite computations are checks,
not proofs of the limiting statements. The existing determinant factorization
is explicitly attributed to ProveIt; no exhaustive historical-priority claim
or OEIS submission is made.

## Rebuild

With Python 3 and the packages in `requirements.txt`:

    python3 code/reproduce.py

This recreates the data and figures without network access.

With a standard TeX Live installation and latexmk:

    sh build.sh

The figures are already included, so the article can be compiled without
running Python. No external bibliography database is needed.

## Verification scope

The recorded run passed 12 complete symbolic determinant identities,
96 rational specializations, 3 exact nonreal algebraic-root checks,
91 degree and primitive-multiplicity checks, 18 independent root/CDF merges,
20 independent tail counts, 78 high-precision cotangent identities, and
2 independent high-precision first-moment checks. Complete-support CDF
maxima were evaluated exactly for 18 values of k through k = 2048.

All CDF maxima are exact rational finite-support computations.
Transcendental tail thresholds and displayed asymptotic ratios use numerical
arithmetic, with the limitations described in `data/verification_summary.txt`.
The observed scaled CDF distances remain well below their proved limiting
constant at the tested sizes, a limitation explicitly discussed in the article.
