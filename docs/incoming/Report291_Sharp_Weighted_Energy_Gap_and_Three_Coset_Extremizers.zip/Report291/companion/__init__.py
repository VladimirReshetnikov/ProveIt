"""Report291 bounded exact diagnostics; not a proof-assistant certificate."""
