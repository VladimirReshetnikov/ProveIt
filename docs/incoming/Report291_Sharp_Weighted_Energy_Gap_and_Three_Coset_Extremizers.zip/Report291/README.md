# Report 291

## The Sharp Weighted Energy Gap and Three-Coset Extremizers

Prepared for Vladimir Reshetnikov, 7 October 2026.

For a full-domain map a:G→H between arbitrary abelian groups, let r(a) be the infimum of respected additive energy divided by ordinary additive energy over nonzero finitely supported nonnegative real weights. Quadruples are ordered; repetitions are included.

Exactly three alternatives occur:

1. The map is affine and r=1
2. The map belongs to the nonzero-defect division-free index-two family and r=3/4
3. The map is in neither family and r≤rho, where rho=(sqrt(6)−1)/(sqrt(6)−1+sqrt(sqrt(6)−2))=0.683744248426277…

The third-class constant is optimal. The representative map C3→Z has exact infimum rho and unique minimizing weights, up to positive scaling, (1,sqrt(sqrt(6)−2),1). This improves the indicator cutoff 19/27 of Report290 for the weighted problem.

The paper proves the complete weighted cyclic reduction, including C3–C9, arbitrary-target wrap certificates for seven branches, propagation to a three-step staircase, an injective target pushout, exact finite quotient lifting and justified infinite interval lifting. It imports precisely the classification under the all-direction two-periodic-increment equation from frozen Report290; the source identity is in SOURCES.md.

The second theorem treats translated index-three affine cuts:

a(x0+k+rt)=β+ψ(k)+ru, for k∈K, r∈{0,1,2}, [G:K]=3, t∉K,

where ψ:K→H is a homomorphism and η=3u−ψ(3t)≠0. Every such cut has r=rho. A finite nonnegative real weight attains rho exactly when some finite-order element of G lies outside K. Three convolution identities characterize each individual finite minimizing weight.

In particular a(j)=floor(j/3) on Z has infimum rho, but every finite nonzero weight has ratio strictly greater than rho. Explicit weights on 3M consecutive integers have excess exactly 3rho(1−rho)/(2M²−2+3rho). A sharp complex quartic, equivalently a three-node degree-two fourth-power Marcinkiewicz–Zygmund sampling inequality, supplies the lower bound and equality analysis.

## Contents

- `Report291.pdf`: prepared article
- `Report291.tex`: complete editable native TeX source
- `companion/exact_checks.py`: exact standard-library mathematical diagnostics
- `companion/README.md`: checks, interfaces, bounds and proof limitations
- `tests/test_companion.py`: mathematical and malformed-input regressions
- `tests/test_build.py`: guarded-builder regressions
- `build.py`: offline bounded builder and deterministic packager
- `REPRODUCING.md`: commands, reference toolchain and archive contract
- `SOURCES.md`: provenance, imported theorem and literature-inspection boundaries
- `MANIFEST.sha256`: generated public-member hashes in the distribution

There are twelve archive members under `Report291/`: ten authored sources, the PDF and manifest. The ZIP hash pin identifies the actual final archive bytes and is supplied separately. The archive excludes logs, review images, working proofs, audit reports, exploratory searches and external papers.

## Reproduce

From the extracted report directory, using a fresh absolute output directory outside the source tree:

    python3 -I -B build.py reproduce --output /tmp/report291-replay

This verifies the manifest, runs normal and optimized tests with matching deterministic output, compiles the PDF, requires exact PDF-byte reproduction under the reference toolchain, and creates the deterministic ZIP. It never installs dependencies or overwrites a nonempty destination. The builder requires Linux; see REPRODUCING.md.

For mathematics alone:

    python3 -I -B companion/exact_checks.py

The diagnostic prints deterministic exact JSON containing all seventy branch histograms and their complete target-pattern evaluations. It neither reads external sources nor writes files.

## Scope

The universal theorem is an infimum statement; it does not promise a finite test with ratio at most rho. The paper gives a complete finite-attainment result for the displayed index-three family, not a classification of every map with r=rho. Equality of r and the indicator infimum is not claimed below the index-two class. Rational-valued finite weights cannot attain irrational rho, though they give the same infimum by continuity.

No publication-priority, partial-domain, nonabelian, signed/complex-weight or proof-assistant certification claim is made. Gowers's earlier product property already uses universal nonnegative-weight testing, with a different normalization. The sharp quartic belongs to an existing sampling framework. Complete references and the bounded search scope are in SOURCES.md. Reports1–290 remain unchanged.
