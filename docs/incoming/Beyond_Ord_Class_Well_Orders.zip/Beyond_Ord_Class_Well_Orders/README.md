# Beyond Ord
## Definable Class Well-Orders, Arithmetic, Condensation, and Definability Heights

Research manuscript prepared for Vladimir Reshetnikov, 4 October 2026.

## Contents

- `article.pdf`: the 30-page compiled research article.
- `article.tex`: self-contained LaTeX source, including its bibliography.
- `build.sh`: a three-pass pdfLaTeX build script.
- `finite_checks.py`: finite checks of positional coding conventions.
- `verification_results.json`: the actual deterministic test result.
- `BUILD_REPORT.json`: compilation, rendering, and validation results.
- `PROOF_STATUS.md`: theorem scope, assumptions, and verification boundaries.
- `SOURCE_AUDIT.md`: sources inspected and limits of the repository review.
- `MANIFEST.sha256`: SHA-256 checksums for the packaged files other than itself.

## Main results

The article distinguishes the class order Omega = (Ord, membership) from a set
ordinal. Its principal results are:

1. Canonical division of any class well-order W as Omega * Q + alpha, using
   set-interval blocks, where alpha is a set ordinal.
2. Explicit finite-support ordinal arithmetic and coherent fixed-point
   constructions beyond finite towers of Omega powers.
3. A finite-digit embedding W -> Omega^Gamma from a supplied, uniformly coded,
   exhausting condensation tower. Existence of an arbitrary such tower is a
   separate recursion issue.
4. A uniform-family diagonal, with an application to every fixed finite
   definability-complexity level. Relative to a fixed named global well-order,
   set-parameter-free presentations are externally cofinal among presentations
   with arbitrary set parameters; no definable uniform family can realize that
   cofinality in the same language.
5. At an inaccessible rank model V_kappa, the full-class well-order spectrum is
   exactly the external ordinals below kappa^+. The definable spectrum has an
   unattained supremum delta_G strictly between kappa and kappa^+, of external
   cofinality omega. This ceiling is closed under ordinal arithmetic and is an
   epsilon number. Adding truth strictly raises the definability height.

The article includes fourteen research questions and a formalization plan
covering definable-class schemas, GB/GBC/NBG, ETR, KM, unrolling, inaccessible
rank models, and Lean universes. The proposed module directory is a suggestion;
no repository files were changed.

## Building

A recent TeX Live distribution with standard packages, including newtx,
tcolorbox, cleveref, and hyperref, is sufficient:

```sh
bash build.sh
```

The build uses no network calls, shell escape, external figures, or BibTeX.
The output is `article.pdf`; auxiliary files remain in `.build/`.
No font files are distributed in this package.

## Running the finite checks

Python 3.10 or later and its standard library are sufficient:

```sh
python3 finite_checks.py --output verification_results.json
```

The delivered run passed **155,530 assertions**. The assertions test only
finite order/coding conventions: greatest-difference comparison, exponent
splitting, nested-power flattening, zero extension, and truncation fibers.
They do not prove the proper-class results. In particular, the truncation
checks are not a finite simulation of set-interval condensation.

## Research and verification status

This is an AI-assisted, unrefereed manuscript with complete written arguments
for its stated theorems and explicitly conditional recursion results. No
historical priority is claimed. No Lean or Rocq proof was created or checked
for this delivery. The package does not claim to resolve the published general
class-comparison-versus-ETR problem.

The repository audit was targeted. It reviewed the repository README and
relevant report guides, not every page of the existing 860-page merged surreal
well-orders report. Existing long-condensation work is acknowledged rather than
presented as a new discovery.
