DEFINABLE SURREALS AND OMNIFIC ARITHMETIC
Parameter hierarchies, absolute normal forms, uniform coding,
and an interpretation of set theory

Prepared for Vladimir Reshetnikov — 4 October 2026

CONTENTS
  definable_surreal_operations.pdf  Complete 41-page article
  definable_surreal_operations.tex  Standalone LaTeX source
  PROOF_STATUS.txt                  Scope, main results, and verification status
  README.txt                       This file

BUILD
  latexmk -pdf -interaction=nonstopmode -halt-on-error definable_surreal_operations.tex

Alternatively run pdflatex three times to settle the contents and references.
Use a standard TeX Live or MiKTeX installation with the packages listed in the
preamble. The bibliography is internal; no .bib file, external image,
downloaded source, or network connection is required for compilation.

READING GUIDE
  Sections 2–3: foundations and precise parameter conventions.
  Section 4: real-parameter consolidation and uniform coding criteria.
  Section 5: normal-form absoluteness and logical complexity.
  Section 6: language dependence and the native omnific ring.
  Sections 7–8: support calculus and the quotient interpretation of set theory.
  Sections 9–11: summation, derivations, product rings, and further consequences.
  Sections 12–14: first omissions, twelve research questions, and proof ledger.

REPOSITORY SNAPSHOT
  https://github.com/VladimirReshetnikov/ProveIt
  Commit: 1404038dfb1cad09eb8a42e38b95f193e5fa54ba
  The bibliography links to the exact repository files used for comparison.

STATUS
This is an AI-assisted research article containing conventional mathematical
proofs, with independent AI proof reviews during preparation. It has not
been peer reviewed or verified in a proof assistant. Results already present
in the repository and classical literature are distinguished from extensions.
Historical priority is not certified. See PROOF_STATUS.txt and Section 14.
