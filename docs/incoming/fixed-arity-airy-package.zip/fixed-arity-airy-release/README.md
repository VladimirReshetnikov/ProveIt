# Fixed arity Airy expansions for trees and automata

This package proves positive amplitudes and expansions to every fixed finite order for relaxed k-ary trees, compacted k-ary trees and the specified minimal finite-language DFA source arrays, for every fixed integer k≥3.

The unified report is `report/fixed-arity-airy-expansions.pdf`, with editable TeX source alongside it. It contains two explicit general correction coefficients, the first compacted/relaxed and DFA/relaxed logarithmic defects, their cancellation, eventual strict decrease, and inversion with lattice interpolation.

## Proof and review map

- `fixed-arity-proof.md`: leading relaxed amplitude, exact harmonic weight, confinement, singular Airy compactness, evolving profile and tracking
- `algebra-audit.md` and `independent-analytic-audit/`: independent leading algebra and analysis
- `all-orders-proof.md`: relaxed polynomial recursion, arbitrary-order remainder and common-amplitude transfer, with c1 and c2
- `independent-all-orders-audit/`: independent analytic and symbolic review
- `signed-extensions/general-signed-all-orders.md`: exact compacted/DFA seeds, positive completed runs, global delay bound, finite-memory transfer and first ratio terms
- `signed-extensions/independent-audit/`: independent signed-model review and checks
- `cancellation/`: proved cancellation corollary with separate independent review

Run `bash replay.sh` for exact checks or `bash replay.sh --pdf` to include the PDF rebuild. See REPRODUCIBILITY.md for dependencies and details. A release includes SHA256SUMS; the replay verifies it and keeps generated outputs separate from supplied inputs.

Amplitudes are strictly positive but have not been explicitly evaluated. Every estimate is for fixed k, with constants allowed to depend on k and the requested finite order. No convergence of the infinite formal series, exponentially accurate completion, or growing-k uniformity is asserted. The primary article is linked, not bundled.
