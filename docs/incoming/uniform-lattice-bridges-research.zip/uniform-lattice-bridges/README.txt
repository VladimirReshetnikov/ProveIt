UNIFORM LATTICE-BRIDGE ASYMPTOTICS
A Gaussian bound disproved, a sharp dimension threshold, and sparse Poisson laws
Research manuscript prepared for Vladimir Reshetnikov, 7 October 2026.

CONTENTS
article.pdf                 Complete article with proofs and bibliography.
article.tex                 Main LaTeX source.
sections/                   All constituent TeX sections.
figures/                    Standalone vector PDF figures and PNG previews.
data/verification.json      Exact and numerical verification results.
data/numerical_tables.tex   Reproducibly generated tables used by the article.
code/walks.py               Exact counts and uniform saddle expansions.
code/verify_lyons.py        Standalone exact counterexample certificate.
code/verify_endpoints.py     Exact prescribed-endpoint verification.
code/reproduce.py            Complete reproducibility run.
requirements.txt            Numerical and plotting dependencies.
source_provenance.json       Repository snapshots and literature locators.

MAIN RESULTS
1. Exact dimension-16, 26-step counterexample to the universal Gaussian
   return bound proposed in Felker--Lyons (2003) and attributed to Russ
   Lyons in the available Ball--Sterbenz preprint associated with the
   2005 journal article. The certificate uses exact integer/rational
   arithmetic, including a proof that pi > 333/106.
2. A scalar saddle expansion uniform in all dimensions and all
   nonnegative directional and idle activities, to every fixed order.
   The decisive variance bounds are m/2 <= B <= m. An explicit leading
   relative error is at most 24/m for N=2m+epsilon. A direct
   prescribed-endpoint extension uses m=floor((N-|x|_1)/2) and is
   uniform in the endpoint coordinates as well.
3. A sharp Gaussian threshold N much larger than D^(3/2) in the dense
   isotropic regime, with critical factor exp(1/(48 s^2)). The
   period-corrected Gaussian ratio is unbounded for nonlazy even walks
   with N asymptotic to D^(4/3), so no universal finite constant repairs
   the original Gaussian bound. The last-failure thresholds are
   asymptotic to D^2/12 (nonlazy) and D^2/9 (unit-idle lazy).
4. A joint sparse Poisson law for repeated axes and parity-conditioned
   idle counts, with error O(1/m) in exponentially weighted l1; a first
   counting correction; and the first triple-occupancy term.

BUILD THE PDF
From this directory, using a standard TeX Live installation:
    latexmk -pdf article.tex
Alternatively run pdflatex article.tex twice (a third pass can be needed
if the table of contents changes). The bibliography is embedded; BibTeX
and network access are not required. The supplied figure PDFs and table
file permit compilation without running Python.

VERIFY THE FINITE COUNTEREXAMPLE
    python code/verify_lyons.py
This requires only Python's standard library. It computes the count by
two independent exact coefficient methods and verifies the strict
rational inequality. No floating-point approximation of pi is used in
the decision.

VERIFY THE PRESCRIBED-ENDPOINT FORMULA
    python code/verify_endpoints.py
This standard-library-only script performs 1,303 additional exact
comparisons covering rational asymmetric and one-sided activities,
zero idle activity, and the full range of endpoint boundary cases.

REPRODUCE ALL SUPPORTING COMPUTATION
Install requirements.txt in an environment of your choice, then run:
    python code/reproduce.py
The saved run used Python 3.12.14 and mpmath 1.3.0, at 60 decimal digits.
It passed 444 exact finite comparisons, 84 finite saddle cases
(66 nonzero and 18 zero boundaries), 24 large-dimension saddle
illustrations, and eight sparse exact normalized-count comparisons.
The dimension-16 counterexample is also independently checked here.
Two further numerical checks rescale all directional and idle activities
by 10^(-120) and 10^120. The saddle bracket starts from the first Taylor
coefficient, so its accuracy follows the scale of the activities.
The script overwrites the generated tables, figures, and JSON data.
The large-dimension dense table is computed from the saddle expansion;
it is not an exact enumeration at those large lengths. All numerical
work is distinguished from interval arithmetic in the article and data.

INTEGRATION INTO PROVEIT
The archive is self-contained and uses relative paths throughout.
A suitable sibling directory to the predecessor report is:
SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/
oeis-sequence-asymptotics/a328716-uniform-lattice-bridges/
The user can choose the final name and catalogue identifier. No repository
files, indexes, commits, or pull requests were modified.
The article records both inspected commit IDs and the predecessor's
scope, so it can be integrated without depending on a moving branch.

MATHEMATICAL AND HISTORICAL STATUS
The article gives conventional proofs and separate reproducible checks.
It has not been externally peer reviewed or formalized in Lean. A bounded
primary-literature audit found no earlier counterexample to the printed
Gaussian conjecture; it does not establish historical priority or a
minimum dimension. The real-zero/Bernoulli correspondence and local
Edgeworth methods are classical and are credited in the bibliography.
The manuscript separates its proved results, source reports, and proposed
future questions. It does not rely on the unverified claims reviewed in
the two repositories as assumptions.
