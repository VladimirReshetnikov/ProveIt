# Audited three-register source and input contract

Source interface and all-input macro proof, 2 October 2026. The source data are pinned in the package manifest.

## 2. Source table, input and credit

The source is Table 16 of T. Neary and D. Woods, *Four Small Universal Turing Machines*, Fundamenta Informaticae 91(1), 123–144 (2009): https://dna.hamilton.ie/assets/dw/NearyWoods-FI09.pdf . The literal binary serialization is https://github.com/Iijil1/MTGPrograms/blob/main/Examples/UniversalTM15x2.tm.txt and is included as `source/UniversalTM15x2.tm.txt`, SHA-256

    ba70ab2c04c68d7ec2d31db4c007d7542c3854d1e02b79a4a5ce07f42fb278ae.

The primary table has u15,b -> b,R,u14, and its unique undefined entry is u10,b. With c=0,b=1 and u1=A,...,u15=O, this is the undefined state-symbol pair J1. The conflicting later halting prose saying u10,c is not used. The two-half-tape interface and primary-source table are detailed in the accompanying report. No third-party PDF or image is redistributed here.

The scanned symbol is stored in finite control. L,R are natural integers whose binary digits, nearest to the head first, are read least-significant bit first. Unrepresented high digits are blank 0. The universal initial control is A0. The paper's finite effective encoding of a source program and its input can use both half tapes; varying only one side would not establish this universality interface.

## 3. Literal simulation using L,R and scratch T

`virtual3.txt` and `virtual3.json` contain every ADD/SUB instruction with all aliases resolved. ADD r q increments register r and continues at q. SUB r q z decrements and chooses q when positive; at zero it preserves zero and chooses z. HALT has no row. The scratch register is named T in these files; the external instruction horizon is denoted h in this proof.

The initial instruction clears T:

    init_clear_T: SUB T init_clear_T tm_A0_pop0.

Our loader already sets T=0, so this is one failed SUB. It is retained to use exactly the already audited 528-row program. At all subsequent TM cuts T=0.

For a defined transition (q,s)->(w,D,q'), let X be the half tape in direction D and Y the other half. Write X=2Q+r, with r in {0,1}. The following fixed graph is separately instantiated at each of the 29 source rows.

Pop pairs and remember parity:

    pop0: SUB X pop1 back0
    pop1: SUB X pair back1
    pair: ADD T pop0.

After k complete pair loops, X=2(Q-k)+r,T=k. The nonnegative rank Q-k decreases. At k=Q the first failed test chooses the parity branch, leaving X=0,T=Q. Transfer T back to X using `SUB T ...` followed by `ADD X ...`, ending at X=Q,T=0. This entire stage takes 5Q+r+2 instructions.

In the parity branch, drain Y to T, adding two to T per successful decrement of Y. After k iterations Y=Y_old-k,T=2k. The rank Y_old-k decreases; the exit is Y=0,T=2Y_old. Transfer T to Y one-for-one, preserving Y+T=2Y_old and decreasing T. Finally add one to Y if w=1. This costs 7Y_old+2+w instructions and ends at

    X=Q, Y=2Y_old+w, T=0, control=(q',r).

The complete exact instruction count for one TM step is

    5Q+r+7Y_old+w+4.

All loops terminate for every natural input. The only terminal control is J1. These identities prove exact TM simulation by induction, without an appeal to a separate universal counter-machine existence theorem.

A label alone is not a TM cut: a pop loop revisits its entry while scratch T is positive. A TM cut requires the appropriate control label **and T=0**. The checker enforces that condition.

`verify_source.py` checks 437 affine paths on arbitrary nonnegative symbolic inputs, covering every one of the 528 literal rows. Every tested SUB on a path is either identically zero or has nonnegative affine coefficients with constant at least one. The displayed loop invariants and ranks extend those body checks to all iteration counts. Additional literal replay covers 4,698 TM macro cases. Finite tests supplement, rather than replace, the all-input proof.

