# Independent shared-reset-arc checks

Run from the packet root:

    python3 shared-checks/audit_shared.py
    python3 shared-checks/audit_prime_macros.py

Both scripts use only the Python 3 standard library and read JSON inputs without importing the construction or certificate implementations. Their default packet root is the parent of their own directory; an optional --base argument supplies another packet root. They write only receipts and the independent macro summary beside the scripts. All receipt file paths are relative to the packet root.

The first checker independently reconstructs every literal transition in both shared variants, verifies algebraic control/marker/resource invariants, exercises adversarial routing and early exits, replays the complete 446-step example and nearby lengths, and checks every canonical witness term. The second reconstructs all 8408 physical prime-source rows, checks small physical shared-net executions, and recomputes the exact large example by macro formulas. Neither enumerates the enormous raw_A=64 physical run.

The report proves the all-input routing and inverse-decoder statements. These independent tests provide finite exact corroboration.
