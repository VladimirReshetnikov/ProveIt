# Independent executable checks

Run from the packet root with Python 3, without optimization flags:

    python3 checks/audit.py
    python3 checks/audit_generated_families.py
    python3 checks/audit_padding_and_generic_peak.py

Only the Python standard library is required. Each script accepts an optional packet-root path; otherwise it uses the parent of its own directory. The environment variable RESET_NET_PACKET_ROOT also selects a root, with an explicit argument taking precedence.

- audit.py reconstructs the net, coefficient maps, complete example traces, and sparse witnesses from JSON alone, without importing project implementations. It verifies the source table against its pinned SHA-256
- audit_generated_families.py imports the local compilers and independently checks generated coefficients and exact rational evaluations, including weighted reset overlaps
- audit_padding_and_generic_peak.py checks natural padding, the exact half-integer parity counterexample, full N390 sparse witness, and generic two-counter/constant-bearing initial maps

Receipts are written beside each script. No source, net, compiler, or witness is modified. The report contains the mathematical proofs; these tests provide finite exact corroboration.
