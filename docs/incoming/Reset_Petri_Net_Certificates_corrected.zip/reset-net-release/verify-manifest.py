#!/usr/bin/env python3
"""Verify every SHA-256 entry of the shipped packet; standard library only."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
count=0
for line in (ROOT/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    path=(ROOT/name).resolve()
    if not path.is_relative_to(ROOT):raise ValueError('Unsafe manifest path')
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual!=digest:raise SystemExit('Hash mismatch: '+name)
    count+=1
print('PASS:',count,'file digests verified')
