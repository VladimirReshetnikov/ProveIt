# Zariski-Dense Integral Hasse Failures for the ProveIt Keller Map

**Complete split-fiber criteria and sharp target-height asymptotics**

Research draft prepared for Vladimir Reshetnikov, September 29, 2026.
Repository snapshot: `1085b506d65e207a05b7e9c861bb1fe88432fe38`.

## Main deliverables

- `article.pdf`: the complete, proof-focused article.
- `article.tex`: self-contained LaTeX source, with an embedded bibliography.
- `code/split_fibres.py`: exact rational fibers, all-prime local tests,
  complete enumeration of integral split exceptions, a dense family, and
  constructive solutions modulo any prescribed positive integer.
- `code/verify_results.py`: twelve groups of exact symbolic and finite checks.
- `code/count_heights.py`: exact target counts and numerical display of the
  theoretical asymptotic constants.
- `data/`: retained verification output, the small example, and height counts.
- `SOURCES.md`: source and attribution ledger.
- `STATUS.md`: precise proof, novelty, and computation boundaries.

## What the article proves

For the fixed polynomial map used by ProveIt's Jacobian-conjecture project,
let an integral Hasse failure mean an integral target with a source point
in `Z_p^3` for every prime `p`, but no source point in `Z^3`. The constructed
fibers all have three rational points, so real solubility is automatic.

1. Such failures are Zariski dense in **every** target plane `C=c` with
   nonzero integer `c`, and hence in the full three-dimensional target space.
   This answers Section 12.4 of the prior repository arithmetic report.
   The plane `C=0` is different: every integral target there has an integral
   source point. Density persists after any prescribed finite set of primes
   is inverted.
2. Every distinct completely split fiber has an exhaustive integer-numerator
   parametrization. The article classifies its local integrality, including
   the exceptional dyadic cases, and proves that only finitely many such
   fibers in a fixed nonzero slice meet `Z^3`.
3. If `H_c^sp(T)` counts these failures with `|A|,|B| <= T`, then
   `#H_c^sp(T) ~ kappa(c) T^(2/3)`. The positive constant is explicit. For
   `c=2`, it is `27 Gamma(1/3)^2 / (8 pi^2 Gamma(2/3))`, approximately
   `1.81235403362934`.

The counting result concerns **all completely split rational fibers**,
not just a previously selected integer-root family. It does not count
fibers with a rational point and a nonrational quadratic pair.

## A small exact example

The target `(-3,-5,1)` has the complete fiber

```
(-1/3,       4,        81)
( 1/5,      -2,       -45)
( 2/15,  -19/2,    -765/8)
```

None is integral. The first point is integral at all primes other than
3, and the second at all primes other than 5. Together they supply a
local point at every prime. The program below constructs an actual
solution for any finite modulus.

## Reproduce

The core utility uses Python's standard library only. The other scripts
were run using Python 3.13.5, SymPy 1.14.0, NumPy 2.3.5, and mpmath 1.3.0.

```sh
python -m pip install -r requirements.txt
python code/verify_results.py
python code/split_fibres.py 1 1 3 --modulus 18144000
python code/count_heights.py
```

The three positional arguments to `split_fibres.py` are `c`, `a`, and `b`:
the third numerator root is `2-a-b`. They are **not** target coordinates.
Repeated roots and nonintegral targets are treated explicitly, not silently
rounded. The CLI prints fractions as strings to preserve exact values.

To run a smaller counting table:

```sh
python code/count_heights.py --c 1 2 --heights 1000 10000
```

That command overwrites the default `data/height_counts.json` and `.txt`;
use `--output /path/to/my_counts.json` to retain the supplied table.
The enumerator has integer overflow and root-bound guards. It is a
reference implementation, not a high-performance large-height solver.

Build the PDF with a LaTeX distribution containing `newtx`, `amsmath`,
`amsthm`, `microtype`, `booktabs`, `longtable`, `hyperref`, `xurl`,
`enumitem`, `fancyhdr`, `needspace`, and `listings`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

A third pass is useful after the first build to stabilize the contents
and cross-references. `latexmk -pdf article.tex` is an alternative.

## Important boundaries

The universal theorems rest on the written proofs, not on the finite tests.
The new results are **not** Lean/Rocq formalizations, and the repository's
existing formal development was not recompiled for this package. The draft
is unrefereed and AI-assisted. The source review supports a contribution
relative to the inspected repository material; it does not certify worldwide
priority. No claim is made to the original map, inverse cubic, or previous
`C=2` split-plane density. This package makes no changes to the repository.
