A ONE-SCHEMA ROUTE TO SMALL ZFC CONSISTENCY MACHINES
Research report for Vladimir Reshetnikov, 16 October 2026

Read report.pdf, or rebuild it from report.tex and sections/ with:

    python3 build.py

The mathematical recommendation is equality-free subset-seeded PSC alone,
with a genuine falsity constant and a complete classical proof calculus.
The report independently audits the predecessor's ZFC consistency calibration.

NEW EXECUTABLE RESULTS

  250 working states: exact-word compression of the original-rho6 C/G/V program.
  251 working states: that program with a genuine-Bottom three-tag formula codec.
  252 working states: PSC-only component with the same genuine-Bottom codec.

These are experimental tables. NO supplied sub-254 table has a proved
equivalence between nonhalting and Con(ZFC). NO new Busy Beaver bound is claimed.
The PSC-only emitted calculus has a concrete logical obstruction explained
and checked here. The C/G/V programs retain other calibration/compiler gaps.

The complete reference checker in reference_checker/ is a SEPARATE correctness
specification; it has not been compiled into those three tables.

REPRODUCE FIXED CHECKS

    python3 reproduce_all.py

Python 3.10+ and the standard library suffice; no network, Lean, or Coq is needed.
Do not use Python -O, which disables checks. No unbounded proof search is run.
Results are written in reproduced/ by default; --output-dir selects another
dedicated directory.

The optional, much more expensive search commands are documented in
machine/README.md. The fixed replay uses the winning seeds directly.

CONTENTS

  report.tex, sections/, report.pdf  Complete report and compiled PDF
  reference_checker/               Independent complete Hilbert checker
  code/                            Codec and algebraic/semantic audits
  machine/                         Portable experiment and exact input subset
  machine/tables/                   Named and total numeric machine tables
  machine/evidence/                 Search results and machine diagnostics
  data/                            Source provenance and executed check reports
  MANIFEST.sha256                   Hashes of the packaged deliverables

SOURCE BOUNDARY

Main ProveIt review pin:
  96836f9eea3540e96322c3d28c7127a582aae223
Imported Jeff/Mira-Cult source pin:
  297ab8df7e5de329605c3875b4934643b371a5e3

The source08 PSC theorem predates this report and is credited accordingly.
Mira-Cult designed the published machine; Jeff supplied its Coq verification;
Andrew James Wade supplied the public backend. Relevant provenance and license
notices are preserved under machine/notices/. No blanket license is asserted
for third-party material whose upstream repository has none.

For each delivered numeric n-state machine:
  tape alphabet = {0,1}; initial tape = all 0;
  start state = 0; halt target = n;
  both read-bit actions are explicit for every working state;
  the halt target is excluded from the working-state count.

The report explains the outstanding logical, enumeration, initialization,
and compiler simulation proofs necessary before claiming a state bound.
