# Persistent Frontiers and Exact Heights
## Finitary powersets of nonuniform lexicographic sums

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT, September 2026.

### Main result

Let `K(P)` be the finitely generated downsets of a poset P, including the empty
downset, ordered by inclusion. Let Q be a finite nonempty poset. Replace each
q by a WPO P_q such that `h(K(P_q)) = omega^(rho_q)`, with `rho_q > 0`.
The article proves an exact finite formula for `h(K(sum_Q P_q))`.

Along a linear extension, record the current support ideal I and its maximal
vertices. An enlargement I -> J receives the largest weight of a vertex that
ceases to be maximal. Empty retirement sets receive zero. Add these weights
with **ordinary ordinal addition in chronological order**, then add the largest
weight of a maximal vertex of Q. The greatest resulting value is the height.

An equivalent smaller dynamic program uses inclusion-maximal antichains under
Hoare domination, charging max(alpha_q : q in A minus B) for A < B.
The article gives a chain realizing each schedule and a separate upper bound.
A finite CNF expansion extends the calculation to arbitrary nonzero limit
ordinal fibers. Exponents can be arbitrary ordinals, including uncountable
ones; the finite calculation uses only their given order/equality pattern.

### Relation to ProveIt

Snapshot: `e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`.

The baseline package is:

`SetTheory/Cardinals/docs/reports/ordinals-and-order-types/wqo-powersets-and-statures/cofinal-strata-of-finitary-powersets/`

Its README and PROOF_AUDIT explicitly leave a nonuniform height formula outside
their scope. The present proof resolves that extension under the hypotheses
above, recovers the uniform formula independently, and does not assume the
baseline's unrefereed maximal-order-type theorems. See SOURCES.md.

### Files

- `article.pdf`: the complete typeset article.
- `article.tex`: standalone editable source with an embedded bibliography and native TikZ figure.
- `code/frontier_heights.py`: exact arithmetic, two dynamic programs, limit-fiber expansion, and certificate checker.
- `code/verify.py`: deterministic finite verification suite.
- `examples/*.json`: pure-weight, symbolic-exponent, and limit-fiber inputs.
- `data/*_certificate.json`: complete support-state certificates.
- `data/examples_summary.json`: convenient summary of examples.
- `data/verification.json`: actual run counts and scope.
- `PROOF_AUDIT.md`: assumptions, proof dependencies, and boundaries.
- `SOURCES.md`: source and priority-search notes.
- `build.py` and `Makefile`: optional build helpers.

### Run

Python 3.10 or later, standard library only. The recorded execution used Python
3.13.5. From this directory:

```sh
python code/verify.py
python code/frontier_heights.py examples/persistent_large_coordinate.json
python code/frontier_heights.py examples/nonuniform_N.json --output data/rebuilt_N_certificate.json
python code/frontier_heights.py data/rebuilt_N_certificate.json --check
python code/frontier_heights.py examples/limit_fibers.json
python code/frontier_heights.py examples/transfinite_exponent_labels.json
```

Replace `python` with `python3` or `py` as appropriate for your system.
The verifier writes its own results and regenerated sample inputs/certificates
inside `data/` and `examples/`. It does not access the network or a repository.

### Input and ordinal notation

A pure instance:

```json
{"n": 3, "edges": [[1, 2]], "priorities": [2, 1, 1]}
```

Vertices are 0,...,n-1. An edge [a,b] means a < b. Transitive closure is computed;
cycles and self-loops are rejected. One positive integer priority is required
per vertex. Larger priorities mean larger **positive ordinal exponents**.
Without labels, a priority p is displayed as the finite exponent p.

Optional `exponent_labels` map priority strings to display labels. For example,
`{"1":"omega", "2":"omega+1", "3":"epsilon_0"}` labels three increasing
exponents. The program does **not** decide or prove the denotation/order of
arbitrary strings. Its result is conditional on those input comparisons.
This is not a universal ordinal-notation equality algorithm.

CNFs use `[priority, positive_coefficient]` pairs in strictly decreasing order.
Zero is `[]`. In certificates only, priority zero represents a finite term;
the empty skeleton has answer `[[0,1]]`. Pure fiber priorities must be positive.

A limit-fiber instance replaces `priorities` by one nonempty CNF per fiber:

```json
{"n": 2, "edges": [], "fiber_cnfs": [[[2,1],[1,1]], [[1,2]]]}
```

This represents the disjoint union of omega^2+omega and omega*2. The result is
omega^2+omega*2, not either the maximum or natural sum of the two input heights.
Coefficients are expanded literally into finite chains. The safety guard is
22 vertices after expansion; the algorithm remains exponential in the worst
case. The theorem has no such vertex limit.

### Checks and their limits

The recorded run passed 167,920 finite checks. It includes 15,131 weighted
instances, 249,057 independently valued linear extensions, and every naturally
labeled poset through six vertices for uniform checks. A naturally labeled
poset is a transitive subrelation of 0<1<...<n-1, not an unlabeled-poset count.
Both finite algorithms agree on the tested cases. Complete certificates verify.

These are finite structural, arithmetic, and implementation checks. They are
not computations of infinite heights by truncation and not a Lean proof.
The transfinite proof is in the article. Classical inputs are WPO closure and
Wolk's height-attaining-chain theorem. Arbitrary WPO component heights must be
supplied by separate mathematics. The certificate checker validates a finite
computation relative to those mathematical inputs and shares arithmetic code
with the optimizer; it is not a formally verified kernel.

### Build the article

A standard TeX Live or comparable installation with pdfLaTeX, New PX, AMS,
TikZ, tcolorbox, microtype, xurl, listings, and the other packages named in the
preamble is sufficient. Font files are provided by that TeX installation and
are not included in this archive. The bibliography is embedded; no BibTeX run
or network access is required.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times, or use `python build.py --verify`.

### Research status

The article supplies complete written proofs of its stated results. It is not
independently refereed or proof-assistant checked. It addresses a concrete gap
in the inspected repository, but priority in the wider literature is not
established. It does not claim a formula for arbitrary successor fibers,
unrestricted iteration of K, arbitrary infinite skeletons, ordinal width, or
maximal linear-extension type. Twelve proposed research directions are included.
