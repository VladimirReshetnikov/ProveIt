# Closure-Word Duality for Open-Query Games

**Universal finite models, optimal topological compression, finite-budget certificates, and an exact product law**

Prepared for Vladimir Reshetnikov, 30 September 2026.

## Read the article

`article.pdf` is the 25-page article. `article.tex` is its self-contained LaTeX source, including its bibliography. No external figures or bibliography files are required.

The main theorem associates a finite-alphabet coloring of any topological space with the reduced words detected by nested color closures. A proposed layer word is admissible precisely when it contains every detected word as a subsequence. A rejected word of length m always has a rejected detected constraint of length at most m.

Consequences proved in the paper include:

- A classification of finite-depth admissibility profiles by finite downsets of reduced words, with exact finite-poset and compact countable metrizable representatives.
- An optimal-height theorem: the maximum detected word length is the least Cantor–Bendixson height of a Hausdorff representative with the same admissibility profile.
- The exact formula L = q + tau(G) for every specified coloring of a Hausdorff space with empty second derivative, without requiring the first derivative to be finite.
- Finite-budget models and actual finite-poset obstructions with at most m*q*(q-1)^(m-1) vertices.
- The exact independent-product rank formula rho(X times Y) = rho(X) + rho(Y) - 1.
- Two colorings of the same compact space that agree on every pattern of length at most three and on every derivative's color cardinalities, but require three versus four questions.

The article includes nine further research questions, a dependency/claim audit, and worked certificates.

## Build and verification

Compile with a conventional TeX Live or MiKTeX installation providing the packages named in the source:

```sh
make pdf
```

Equivalently, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times. The source has an internal bibliography; BibTeX and network access are unnecessary.

Run the finite verifier with Python 3.10 or newer; the delivered run used Python 3.13.5:

```sh
python3 code/verify.py --output results/rerun.json
```

The default parameters are `--max-n 4 --q 3`. The specified output path preserves the delivered `results/verification.json`. Do not use `python -O`: assertions are verification conditions and the script rejects optimized execution. No third-party Python dependencies or network access are needed.

The delivered run passed 3,481,578 candidate-word comparisons over all 389 labeled topologies on one through four points and all 29,577 three-colorings. It also checked 256 ordered products, 9,856 rectangular-closure identities, all 4,165 loopless digraphs on one through four vertices, and the stated extremal word families. The full record contains the explicit hard/soft example words.

## Files

| File | Purpose |
|---|---|
| `article.tex` | Complete mathematical article and bibliography |
| `article.pdf` | Compiled article |
| `code/verify.py` | Independent finite checks and finite word algorithms |
| `results/verification.json` | Actual recorded verification run |
| `results/validation.json` | PDF/build/package validation information |
| `README.md` | This guide |
| `SOURCES.md` | Repository pin, consulted sources, novelty and evidence boundaries |
| `Makefile` | PDF build, verification, and auxiliary-file cleanup |

## Status

The article is an AI-assisted, unrefereed research manuscript. Its theorems are supported by written mathematical proofs; the delivered finite computations are tests, not proofs of the infinite-space results. No Lean or Rocq formalization was performed or is included.

The inherited normal form, fixed-word elimination test, compact single-word model, and universal-word constant are explicitly credited to the inspected ProveIt report. Historical priority of the extensions has not been independently certified. The paper resolves the fixed-coloring profile question and gives the stated consequences; it does not claim to solve the uniform realizability problem for colorings of each prescribed space or the general transfinite games.
