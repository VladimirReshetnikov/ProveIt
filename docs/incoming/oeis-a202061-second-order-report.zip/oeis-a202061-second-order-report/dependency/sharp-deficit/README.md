# The leading logarithmic deficit of 120 avoiding ascent sequences

This is a standalone reproducibility package for the sharp first logarithmic deficit of OEIS A202061. The unchanged foundational report is included under `foundation/`.

## Proved results

Let a_n count classical 120-avoiding ascent sequences and let mu be the largest root of mu^3-8mu^2+5mu+1=0. Then

n log(mu)-log(a_n) ~ C n^(1/3)(log n)^(2/3),
C=(3 pi^2 alpha^2/(2v))^(1/3)=2.232625307612844922....

Here z is the smallest positive root of z^3-5z^2+6z-1=0,
alpha=(8z^2-29z+9)/7, and v=(2z^2-7z+2)/2.

The companion also proves the finite-height radius shift
log(rho_H/rho) ~ (alpha/2) log(H)/H,
and the exact first inverse correction, with coefficient
C/(log mu)^(4/3)=0.893568257650894909....

These are logarithmic asymptotics. No multiplicative amplitude, second-order deficit coefficient, all-orders transseries, exact integer inverse rounding, or finite-data crossover threshold is claimed.

## Read first

- `a202061-sharp-deficit.pdf` and editable `.tex`: the integrated companion
- `audit/`: independent mathematical review and an independently assembled exact certificate
- `foundation/a202061-report.pdf`: exact positive representation and the earlier two-sided order result
- `source_scope.md`: bounded prior-art checks and their limitations

The original derivation notes remain as research provenance. The integrated report uses only local positive lower bounds, uniform square-root transfer, and exact identities. Stronger global equivalents discussed in `kernel/kernel-asymptotics.md` are not needed for its principal theorem.

## Reproduce

Python 3 with SymPy and mpmath is sufficient for all mathematical diagnostics:

    python -m pip install -r requirements.txt
    bash verify_all.sh

The shell script validates hashes when the release manifest is present, runs both new exact certificates, verifies the unchanged foundation manifest, and replays the original author and independent checks.

For the PDF, install a standard LaTeX distribution with AMS packages, geometry, hyperref, microtype and Latin Modern fonts, then run:

    bash build.sh

The build uses a local `.build` cache and a fixed source date. The PDF is inspected page by page; verification details are recorded in `verification.md`.

The audits are independent research checks, not journal peer review or Lean/Rocq certification. The source comparison does not establish comprehensive publication priority. No external repository or OEIS entry was modified.
