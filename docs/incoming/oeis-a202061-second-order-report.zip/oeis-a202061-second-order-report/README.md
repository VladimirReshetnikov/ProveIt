# The second logarithmic deficit of A202061

A proof and reproducible research companion, 2 October 2026.

## Proved results

For the number a_n of classical 120-avoiding ascent sequences, write

F=n^(1/3)(log n)^(2/3), C=(3 pi^2 alpha^2/(2v))^(1/3)=2.232625307612844922... .

The matching independently reviewed arguments establish

n log(mu)-log a_n
 =C F [1+(7/3)loglog n/log n+O(1/log n)].

The report also proves the corresponding inverse correction and the separately reviewed finite-height expansion

log(rho_H/rho)=alpha/H [(1/2)log H+loglog H+c_*+o(1)],
c_*=0.866796245805539952988634807649337371... .

The exact algebraic definitions of mu, alpha and v, and the explicit amplitude formula defining c_*, appear in the report. The coefficient result holds for every sufficiently large integer n, without interpolation from a subsequence.

## Files

- `a202061-second-order.pdf`: complete article, with both main proofs, inverse consequence, and explicit finite-height constant
- `a202061-second-order.tex`, `proofs/*section.tex`: editable article sources
- `proofs/conjectural-outlook.tex`: explicitly conditional research outlook, outside the proved theorem scope
- `proofs/*.md`: the source proof notes reviewed independently before integration
- `audit/`: independent mathematical reviews, source hashes, and the independent amplitude certificate
- `checks/`: deterministic symbolic and finite diagnostics for the new arguments and pinned dependency hashes
- `dependency/sharp-deficit/`: the unchanged previous sharp-constant package, including the unchanged positive-walk foundation, source, checks, and audits
- `producer-replay.txt`: captured successful verification run
- `SHA256SUMS`: exact released payload set and all SHA-256 digests

## Reproduction

Use Python 3 with SymPy installed (`requirements.txt`), Bash, and standard SHA-256 utilities. Run

    bash verify_all.sh

This verifies the release manifest when present, pins every byte of the frozen dependency, performs the new symbolic/finite checks, replays the independent finite-height amplitude certificate, and runs all imported exact and finite mathematical diagnostics. These checks complement the proofs and independent audits; finite computations do not replace the asymptotic arguments.

To rebuild the article, install pdfLaTeX with the listed standard packages and run

    bash build.sh

The build fixes its PDF timestamp and fails on overfull boxes or unresolved references/citations. Local `.build/`, `.qa/`, and Python caches are excluded from the release payload. The PDF has also been rendered and visually inspected.

## Audit and scope

The main two-sided expansion, the finite-height constant, and the final integrated article are reviewed separately. The package's release generator refuses to package article sources without hash-bound integrated signoff. The frozen dependency manifest is pinned to SHA256 `be1c77323ab96fc1deee4eee7c23c37b52ed480c17a8ef2d9b267ebffc4cf5c8`.

The global remainder is O(F/log n), so it still diverges in the logarithm. This is not a multiplicative equivalent for a_n, a polynomial prefactor, an exact integer inverse rule, or an all-orders transseries. The finite-height constant does not establish the next global constant. A short conjectural outlook proposes a candidate for that further constant and explicitly identifies the missing o(F/log n) global transfer. The conjecture is not part of the proved results or their stated error bounds.

The audits are mathematical research verification, not journal peer review or formal proof-assistant certification. Existing source-comparison and priority qualifications are retained in the unchanged dependencies. No additional literature-priority claim is made here.
