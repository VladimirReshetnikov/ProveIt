"""Report290 bounded exact diagnostics; not a proof-assistant certificate."""
