# Report 290

## The Sharp Hereditary Indicator Gap and Complete Endpoint Classification

Prepared for Vladimir Reshetnikov, 7 October 2026.

For a full-domain map a:G→H between arbitrary abelian groups, let r and r_ind be the infima of the fraction of respected ordered additive quadruples, over nonnegative nonzero finitely supported weights and finite nonempty indicators. Repetitions are included.

Exactly one of three alternatives holds:

1. The map is affine; r=r_ind=1
2. It has one common homomorphism on the two cosets of an index-two subgroup, with nonzero division-free defect; r=r_ind=3/4
3. A finite nonempty indicator has ratio at most 19/27, hence r≤r_ind≤19/27

The index-two family is exactly a(k)=β+ψ(k), a(t+k)=β+u+ψ(k) for k∈K, [G:K]=2, t∉K, a homomorphism ψ:K→H, and η=2u−ψ(2t)≠0. No extension of ψ into the original target is assumed. Its subgroup is intrinsic and unique: K={x:a(2x)−2a(x)+a(0)=0}; the expression equals −η off K.

Under the all-direction equation (P), a(x+3h)−a(x+2h)−a(x+h)+a(x)=0, every map outside those two families has r_ind≤5/8, sharply. The proof retains a genuine order-four torsion obstruction, supplies explicit finite-box balanced-translation and quotient-pattern counts, uses an injective pushout, transfers quotient planes to genuine original-group indicators, and descends to the original target.

The paper includes the complete cyclic argument: the sharp full-indicator C5 bound 17/25, arbitrary-target C7–C9 histogram proofs, and an at-most-ten-point branch certificate for larger orders. It prints all eight no-wrap histograms, all 31 nonzero positive-wrap polynomials and all 72 cyclic wrap bounds. The three collision cases (target obstruction order 2, 3, or at least 4/infinite) cover every abelian target, with the cyclic slope v=Nd retained explicitly. It also applies Report289's convolution and torsion-spectral criteria to every hereditary endpoint map, rather than only a pre-specified family.

## Read and reproduce

- `Report290.pdf`: the prepared article
- `Report290.tex`: complete editable article source
- `companion/exact_checks.py`: exact standard-library diagnostics
- `tests/`: companion and guarded-builder regression suites
- `REPRODUCING.md`: commands, toolchain, runtime limits and archive contract
- `SOURCES.md`: source inventory, provenance and literature-inspection scope
- `MANIFEST.sha256`: generated public-member hashes in a distribution

Run the complete offline replay from an extracted distribution:

    python3 -I -B build.py reproduce --output /tmp/report290-replay

Choose a fresh absolute directory outside the source tree. A distribution replay checks the manifest, runs normal and optimized tests, recompiles and requires the included PDF's exact bytes under the reference toolchain, then builds the deterministic ZIP. It never overwrites a nonempty destination or installs dependencies. The builder is Linux-specific; see REPRODUCING.md.

For mathematical diagnostics alone:

    python3 -I -B companion/exact_checks.py

The public archive has twelve members under `Report290/`: ten authored source files, the PDF and manifest. The separate ZIP pin identifies the actual archive bytes. Logs, review images, research drafts, external papers and internal review files are excluded.

## Precise limitations

The value 19/27 is the optimal universal outside-family INDICATOR bound: the representative map C3→Z has indicator infimum exactly 19/27. No weighted-optimality claim is made. Indeed that map with weights (1,2/3,1) has ratio 467/683, strictly below 19/27. The 5/8 proof may yield a limiting infimum rather than a finite attaining indicator. Equality of r and r_ind is asserted in the affine and endpoint classes, not generally below the gap. A single weight of ratio 3/4 does not by itself imply that the map's hereditary infimum is 3/4.

The printed symbolic certificate is exhaustive for its arbitrary-target collision patterns; its exact recomputation is separate from the bounded finite-map diagnostics. Those bounded map checks supplement the written proofs. No publication-priority, partial-domain, nonabelian, global Ramsey, Lean or other proof-assistant certification claim is made. Reports288 and 289 remain unchanged; their source files and external literature are not needed to run the companion.
