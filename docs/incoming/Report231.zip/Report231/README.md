# Report 231

## A proof of the height four shifted rectangle conjecture

This report proves the specific order-two recurrence for OEIS A181198 and the
finite sum printed as Kauers–Koutschan (2023), Conjecture 18, for the full array
count. It also provides recurrence-based all-fixed-order rational asymptotics,
effective remainder constructions, and qualified finite-model index inverses.

The leading asymptotic and existence of all-order expansions were already proved
in the prior fixed-height report and are credited in the manuscript. Height five
and Conjecture 19 remain outside this result. Historical priority is not certified.
The source review is bounded, and this is an AI-assisted research manuscript,
not a peer-reviewed or proof-assistant formalization.

## Contents

- `Report231.pdf`: complete standalone manuscript
- `article.tex`, `sections/`: editable LaTeX source
- `code/`: standard-library exact certificate verifier and deterministic receipt
- `SOURCES.md`: source and attribution record
- `build.py`: frozen inventory checks and isolated PDF/ZIP replay
- `MANIFEST.sha256`: SHA-256 of every other package member

No third-party papers or private review reports are redistributed.

## Exact certificate only

Python 3.9 or later is sufficient, with no external packages:

    python -B code/verify_report231.py --self-test

This prints the deterministic JSON receipt. Compare it with `code/receipt.json`.
To request a receipt file, pass `--receipt /path/to/a/new-file.json`; an existing
file is rejected. All guards remain active with `-O`:

    python -B -O code/verify_report231.py --self-test

The 31 symbolic checks are exact identities, not a collection of evaluations at
selected parameter values. The additional finite checks compare independent
prefix-state and direct-integral counts through width 20, and evaluate the actual
printed sum and both recurrences. Six rational relative asymptotic corrections
are independently checked by finite formal arithmetic.

The manuscript proves the transfer/Pfaffian identities and analytic remainders.
The program verifies the algebraic certificates and stated coefficient outputs.
It does not automatically compute every effective bound from Sections 6–7, and
it does not infer their proofs from finite tests.

## Verify the frozen package

    python -B build.py --verify-only

The manifest rejects changed, missing, or extra files, symlinks, and unexpected
directories. Do not let editors or Python add caches inside the frozen package.
Make a separate working copy for edits and re-freeze its manifest deliberately.

## Rebuild the manuscript and archive

Use a new output directory outside the package:

    python -B build.py --output /absolute/path/to/new-output

The script checks the inventory, reruns the exact verifier, compiles the article
three times with shell escape disabled in a private TeX directory, verifies that
the PDF equals the frozen copy, confirms that the source inventory is unchanged,
and produces `Report231.pdf`, `Report231.zip`, logs, and `build_checks.json`.
Every Python child argv explicitly includes `-B`, including optimized runs.
Existing output paths and live or dangling symlink ancestors are rejected.

The PDF build requires TeX Live with article, AMS math/theorems, geometry,
Latin Modern, microtype, booktabs, longtable, array, enumitem, fancyhdr, and
hyperref. The recorded build used pdfTeX 3.141592653-2.6-1.40.26, TeX Live
2025/dev/Debian, and Python 3.12. PDF/ZIP metadata is fixed to October 5, 2026;
the archive uses stored members and fixed permissions/timestamps. The build does
not need network access. Another TeX/font version may alter PDF bytes even when
mathematical output is equivalent; a changed rendering needs fresh inspection.

Normal and optimized builds from fresh extractions of the actual final archive
must agree on the PDF, archive, exact receipt, and manifest pins. Public digests
are recorded outside the self-contained archive to avoid a circular hash claim.

## Index scope

The first-order inhomogeneous identity holds for n >= 1, but its leading
coefficient vanishes at n=1, so a1=a2=1 are checked separately. The order-two
recurrence holds for n >= 1, and the printed finite sum for n > 1. The optional
empty-array convention a0=1 does not extend the order-two operator: its n=0
residual is -2160. No code silently uses that invalid extension.

## Inverse scope

Inverse models are finite smooth functions with specified remainders. The true
integer threshold is enclosed by a two-ceiling interval. Near an integer the
bounds can leave adjacent possibilities, resolved by exact recurrence values.
There is no unconditional nearest-integer rounding assertion and no canonical
complete exponentially small transseries claim.
