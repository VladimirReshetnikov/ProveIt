GRADED FOURIER SELECTION AND TWO FURTHER REFINEMENTS OF GOWERS' ARGUMENT
====================================================================

Research manuscript prepared for Vladimir Reshetnikov and the ProveIt
repository, 6 October 2026.

The package contains a self-contained LaTeX article, its compiled PDF, exact
verification programs and recorded results, a source audit, and a Makefile.
The PDF has 40 pages including its cover, contents and references.

SOURCE SNAPSHOT
---------------

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit:     12da356730b12cb73c276a258aaadf3223e3662b
Programme:  Combinatorics/Ramsey

The comparison includes the corrected Gowers transcription, the merged
research collection, earlier placed source archives, and the incoming Fejer,
norm-moment, and higher-uniformity reports at this snapshot. SOURCE_AUDIT.txt
identifies the principal comparison sources and their roles.

PRINCIPAL RESULTS
-----------------

1. Degree-weighted arrangement selection (Theorem 2.2, Corollary 2.3).

   For m=2d>=4, s=m*2^k, the sufficient field-size exponent is

       E_(k,m) = max_t [m*sum_(i=0)^t binom(k,i)-binom(k,t)]/(t+1).

   At fixed m it is asymptotic to 2s/k. The retained-arrangement guarantee
   has parameter powers alpha^s * eta^(s-1). The proof includes exact
   degree-one and repeated-physical-vertex corrections and a characteristic
   condition. For k=2 and d=8, the exponent is 23. The article distinguishes
   this from both the prior one-monomial Fejer exponent 128 and the weighted
   unstratified comparison 63/2 proved in the article.

2. A stronger real centered U4/U2 norm comparison (Theorem 6.1).

       ||f||_(U4)^16 >= 5 ||f||_(U2)^16

   for real mean-zero functions on finite abelian groups of odd order,
   strictly for nonzero f. The strongest inspected previous coefficient
   was 35/8. The new Fourier progression energy inequality is Theorem 6.2.
   Higher-dimensional central-binomial estimates already in the source
   collection are retained when they are stronger.

3. Exact polynomial divisibility and partition obstructions
   (Theorems 7.2 and 7.4; Proposition 7.5; Corollary 7.6).

   Explicit rational polynomial phases of degrees d_i force every flat
   progression of length at least L to have step divisible by

       D asymp L^[sum_i d_i(d_i+1)/2] * product_i eps_i^(-d_i).

   For permitted lengths S with conductor C(S), the exact eventual complete
   partition threshold of these constructed phases is D*C(S). An exact
   uncovered-mass formula is also proved. The all-target-lengths necessary
   exponent bound at equal degree k is

       [nu*k*(k+1)/2+2]*a + k*nu*b <= 1.

   The quantifier and modulus restrictions are explicit in the article.

Section 9 develops fourteen research questions with concrete first targets.
Section 8 distinguishes new and inherited ingredients, documents verification,
and gives a formalization route.

BUILD THE ARTICLE
-----------------

From this directory, with a standard TeX Live or MiKTeX installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_graded_refinements.tex

Alternatively, run pdflatex on the same file repeatedly until references
stabilize (normally three runs after a clean build). No BibTeX or Biber
invocation is needed: the bibliography is embedded.

The article uses standard packages, including amsmath, amssymb, amsthm,
mathtools, lmodern, geometry, microtype, booktabs, tabularx, enumitem, fancyhdr,
xurl, hyperref and bookmark. It has no external figures, data dependencies,
custom fonts, shell-escape requirement, or dependency on a local ProveIt
checkout. The Makefile supplies equivalent 'make' and 'make verify' targets.

RUN THE EXACT CHECKS
-------------------

Use Python 3.10 or later; no third-party Python packages are required:

    python3 verification/verify_all.py

On Windows the corresponding launcher is normally:

    py verification/verify_all.py

The runner works from any current directory when called through its full
path. It regenerates results in a temporary directory and compares their
parsed JSON with the recorded files. The delivered evidence is not changed.
Individual suites accept --help and --output PATH. Their default invocations
print a summary without rewriting the recorded evidence.

The delivered checks cover complete finite examples and auxiliary arithmetic.
The general theorems are proved in the article; exhaustive finite checks do
not replace those proofs.

REPOSITORY INTEGRATION
----------------------

The intended programme is Combinatorics/Ramsey/Research/GowersSzemeredi.
This delivery does not change the repository, its ledger, or any Lean source.
The article is standalone; the section and lemma numbers are local to it.
The labels for the three mathematical parts use the prefixes sel:, ng:, po:;
the integration editor can namespace all labels and bibliography keys in the
usual way when merging the manuscript.

New results are claimed relative to the inspected source statements, with
full proofs supplied for review. The manuscript is AI-assisted and unrefereed.
No Lean kernel verification, external refereeing, exhaustive literature
priority search, optimal selection exponent, optimal U4 constant, matching
general higher-degree partition theorem, or new global Szemeredi bound is
claimed. The higher-degree divisibility construction question from the
inspected source 23 is answered in the stated finite setting.

FILES
-----

gowers_graded_refinements.tex
gowers_graded_refinements.pdf
README.txt
SOURCE_AUDIT.txt
Makefile
verification/README.txt
verification/verify_all.py
verification/verify_graded_selection.py
verification/graded_selection_checks.json
verification/verify_norm_gap.py
verification/norm_gap_checks.json
verification/verify_polynomial_obstruction.py
verification/polynomial_obstruction_results.json

The original Gowers transcription and earlier research archives are not
redistributed in this package. TeX auxiliary files, temporary renderings, and
working proof notes are not part of the delivery.
