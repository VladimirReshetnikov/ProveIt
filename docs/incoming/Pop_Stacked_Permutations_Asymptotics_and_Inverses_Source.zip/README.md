# Report161 — Factorial exponential growth of pop stacked permutations

This self-contained report proves the leading factorial-exponential equivalent for OEIS A307030, the number p_n of pop-stacked permutations, with p_0=1 for the empty permutation:

    p_n = C n! rho^(-n) (1 + O(q^n)),  rho > 1, C > 0, 0 < q < 1.

The constants are exactly specified by a compact integral operator on the disjoint measure space (0,1) plus {(a,b):0<a<b<1}. A singleton has one-dimensional measure and weight z; a nonsingleton run has two-dimensional measure and weight z^2 exp(z(b-a)). Two strict cross inequalities enforce both maximality and the overlap condition. The construction must not be read as requiring a positive-length intersection between singleton intervals.

The article proves the labelled-simplex normalization, an elementary self-adjoint Perron lemma, the finite-rank analytic Fredholm continuation, a unique monotone positive crossing, its derivative and positive amplitude, strict complex domination and a uniform singularity-free annulus. It includes a self-contained proof of the known pop-stack image characterization. The bounds (24/23)^(1/4) <= rho <= 2 are rigorous; the published approximate rho=1.113439... and C=0.695688... remain noncertifying context.

## Consequences and inverse

All fixed algebraic orders in log p_n are exactly the ordinary Stirling expansion shifted by -n log rho + log C; the sequence-specific correction is exponentially small. The article also gives the multiplicative Stirling expansion and the ratio p_(n+1)/p_n=((n+1)/rho)(1+O(q^n)).

Let H(x)=log Gamma(x+1)-x log rho+log C and let x solve H(x)=log y on its eventually increasing branch. If |log p_n-H(n)|<=M q^n for all n>=n_0, x-2>=n_0, H'(x-2)>0, and delta=2M q^(x-2)/H'(x-2)<1, then

    ceil(x-delta) <= min{n>=0:p_n>=y} <= ceil(x+delta).

This is an exact mathematical implication, not a certified finite-input numerical algorithm: effective certified values of rho,C,M,q,n_0 are not provided here. If the two ceilings differ, exact counting or tighter certified bounds are required. The companion's threshold command instead searches actual integer counts in a bounded prefix.

The Lambert initializer x_0=L/W(L/(e rho)), L=log y, solves the leading equation exactly. The actual continuous Gamma root obeys

    x = x_0 - [0.5 log(2 pi x_0)+log C]/log(x_0/rho) + O(1/(x_0 log x_0)),

so x-x_0 tends to -1/2. Directly rounding x_0 is not justified. A rational-function recurrence in the article supplies every fixed inverse order with error O(x_0^(-m-1)/log x_0). Those are continuous-root expansions; no finite truncation is an exact integer rounding rule.

## Attribution and scope

The overlap characterization and polynomial-time enumeration are prior results of Asinowski and collaborators and Claesson, Gudmundsson and Pantone. The 2019/2021 counting papers present the sharper factorial-exponential law as an experimental prediction. Ehrenborg, Kitaev and Perry (2011) are credited for the established spectral-operator methodology. The sequence-specific variable-run resolvent and dominant-pole proof are the contribution here.

A bounded source and catalogue check found no earlier proof of this total-count equivalent in the works inspected. The current official OEIS entry, 2019 image paper, 2019/2021 counting papers, and the relevant Semidistrim Lattices section were checked. This is not exhaustive scholarly priority clearance. SOURCE_PROVENANCE.json records source URLs, inspected scopes and preserved-source hashes. Full third-party papers, full OEIS entry prose and private working records are not redistributed.

No decimal digits of rho or C, conjectured additional poles, non-D-finiteness, or finite-input asymptotic threshold certificate are proved. No part of the analytic proof depends on numerical discretization or curve fitting.

## Package contents

- Report161.pdf: 13-page article
- Report161.tex: self-contained editable LaTeX source
- companion/pop_stacked.py: bounded standard-library exact computations
- companion/test_pop_stacked.py and companion/README.md: tests and complete command/API documentation
- data/counts.json: exact counts through n=70
- data/finite_checks.json: deterministic finite verification results
- data/source_data.json: attributed 25-term OEIS and 45-term primary-paper integer fixtures
- SOURCE_PROVENANCE.json: source and attribution record
- build_pdf.py and release_tools.py: exclusive clean PDF builder and local I/O helpers
- make_zip.py and test_release.py: fixed-allowlist deterministic packaging and release tests
- SHA256SUMS: sorted manifest of allowlisted payload, excluding itself

The ZIP includes the manifest but not itself recursively. Unlisted files, intermediate builds, render images, audits and test logs are excluded.

## Companion replay

Python 3.10 or later is required. The companion is standard-library-only, performs no network requests and prints deterministic JSON to stdout. Its code does not write files. The finite workload limits and exact validation behavior are documented in companion/README.md. Checks stay active under -O.

From an extracted package, choose a fresh output directory:

```sh
mkdir reproduction
set -C
python3 -B companion/pop_stacked.py counts > reproduction/counts.json
python3 -B companion/pop_stacked.py verify > reproduction/finite_checks.json
python3 -B companion/pop_stacked.py sources > reproduction/source_data.json
cmp data/counts.json reproduction/counts.json
cmp data/finite_checks.json reproduction/finite_checks.json
cmp data/source_data.json reproduction/source_data.json
python3 -B -m unittest discover -s companion -p 'test_pop_stacked.py' -v
python3 -O -B -m unittest discover -s companion -p 'test_pop_stacked.py' -v
python3 -B companion/pop_stacked.py threshold --value 1000000 --max-n 70
```

The finite evidence includes recurrence counts through 70, all 25 displayed OEIS terms and 45 paper-table terms, full literal image/predicate set equality through 9, canonical preimages and append-largest injections, every composition through 10 for independent poset normalization, and refined direct-sum recurrence comparison through 12. These are exact finite validations of definitions and implementation, not proof by numerical extrapolation.

The threshold includes n=0, so value one has threshold zero. An unreached threshold remains explicitly unreached. No approximate constants are silently substituted into an exact computation.

## Clean PDF replay

Recorded release toolchain: Python 3.12.14; pdfTeX 1.40.26, TeX Live 2025/dev/Debian. The builder requires pdftex and pdflatex, fontenc, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, booktabs, array, microtype and hyperref. Poppler is used for visual QA, not by the builder.

```sh
python3 -B build_pdf.py --output-dir /tmp/report161-build-one
python3 -B build_pdf.py --output-dir /tmp/report161-build-two
cmp /tmp/report161-build-one/Report161.pdf /tmp/report161-build-two/Report161.pdf
cmp Report161.pdf /tmp/report161-build-one/Report161.pdf
```

Use new directories with existing parents. The builder exclusively creates the destination, makes fresh LaTeX formats and isolated caches, fixes epoch and metadata, disables shell escape, and repeats until references stabilize. The settled log must contain no warnings, missing characters, overfull or underfull boxes. The TeX file is the sole authoring input. Byte equality is expected within the recorded toolchain, not across TeX versions, fonts or operating systems.

## Manifest and archive replay

```sh
sha256sum -c SHA256SUMS
python3 -B -m unittest -v test_release
python3 -O -B -m unittest -v test_release
python3 -B make_zip.py --output /tmp/Report161-rebuilt-one.zip
python3 -B make_zip.py --output /tmp/Report161-rebuilt-two.zip
cmp /tmp/Report161-rebuilt-one.zip /tmp/Report161-rebuilt-two.zip
cmp Report161_Source.zip /tmp/Report161-rebuilt-one.zip
```

The final comparison applies if the source ZIP is retained alongside the extracted package. Packaging checks the exact sorted allowlist and every payload hash; order, timestamps, permissions and ZIP_STORED compression are fixed. Unlisted files are excluded. An edited payload fails the original manifest and requires a deliberately regenerated release manifest.

Release file outputs are exclusive and refuse existing files, symlinks, directories, FIFOs and other special targets. Parent traversal and symlink parent components are rejected. POSIX O_NOFOLLOW/O_DIRECTORY and directory-relative operations are required. Source trees and output parents must be trusted and nonadversarial. Descriptor pinning reduces accidental substitution; the mkdir-then-open interval is not claimed to defeat a malicious same-user actor. A failed output write may leave a newly created incomplete file; inspect it before retrying. Disabling shell escape does not sandbox arbitrary modified TeX.

No command uploads, publishes, contacts an author, edits OEIS or modifies an external repository.
