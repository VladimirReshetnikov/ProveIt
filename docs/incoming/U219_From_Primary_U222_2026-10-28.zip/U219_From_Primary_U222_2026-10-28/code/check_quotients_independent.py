"""Fresh fixed-point computation, independent of builder and supplied checker."""
from pathlib import Path
from collections import deque
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]/'machine'
def need(v,m):
 if not v:raise ValueError(m)
def read(p):
 rows=p.read_text().splitlines();need(rows[0]=='#! start 0','start')
 T={}
 for line in rows[1:]:
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in T,'duplicate');need(b in(0,1)and w in(0,1)and d in('L','R'),'alphabet');T[q,b]=(w,1 if d=='R'else -1,z)
 need(all((q,b)in T for q,s in T for b in(0,1)),'total')
 return T
def verify(folder,oldname,newname,densename,certname):
 C=json.loads((folder/certname).read_text());T=read(folder/oldname);U=read(folder/newname);D=read(folder/densename)
 oldstates={q for q,b in T};newstates={q for q,b in U};halt=254;r=2;mask=31
 seen={(0,0)};todo=deque(seen)
 while todo:
  q,tape=todo.popleft()
  if q==halt:continue
  w,delta,z=T[q,(tape>>r)&1];changed=(tape&~(1<<r))|(w<<r)
  raw=changed>>1 if delta==1 else (changed<<1)&mask
  bit=(1<<4)if delta==1 else 1
  for nt in(raw,raw|bit):
   c=z,nt
   if c not in seen:seen.add(c);todo.append(c)
 supplied={(int(q),x)for q,m in C['masks'].items()for x in range(32)if(m>>x)&1}
 need(seen==supplied,'supplied invariant differs from independent least fixed point')
 drop,keep=C['drop'],C['keep'];rename=lambda q:keep if q==drop else q
 need(newstates==oldstates-{drop},'working states');need(drop!=halt and keep!=halt,'halt collapse')
 allowed=0
 for q,x in seen:
  if q==halt:continue
  b=(x>>r)&1;w,d,z=T[q,b];need(U[rename(q),b]==(w,d,rename(z)),'quotient transition');allowed+=1
 need(U=={(q,b):(w,d,rename(z))for(q,b),(w,d,z)in T.items()if q!=drop},'unexpected table change')
 ren={q:i for i,q in enumerate(sorted(newstates))};ren[halt]=len(newstates)
 need({(ren[q],b):(w,d,ren[z])for(q,b),(w,d,z)in U.items()}==D,'dense renaming')
 hashes={label:hashlib.sha256((folder/name).read_bytes()).hexdigest()for label,name in [('input_sha256',oldname),('native_sha256',newname),('dense_sha256',densename)]}
 need(all(C[k]==v for k,v in hashes.items()),'hash')
 return {'working_states':len(newstates),'least_fixed_point_configurations':len(seen),'nonhalt_quotient_cases':allowed,'drop_read_bits':sorted({(x>>r)&1 for q,x in seen if q==drop}),**hashes}
results=[verify(ROOT/'direct221','u222.native.tm','u221.native.tm','u221.tm','certificate221.json'),verify(ROOT/'final220','input221.native.tm','u220.native.tm','u220.tm','certificate220.json'),verify(ROOT/'final219','input220.native.tm','u219.native.tm','u219.tm','certificate219.json')]
(ROOT.parent/'evidence/independent_quotients.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
