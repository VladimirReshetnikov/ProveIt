import argparse,json,time,hashlib
from pathlib import Path
import u_symbolic as p
def validate_sites(S):
 if not isinstance(S,list)or not S:raise ValueError('empty source')
 leaves=set();prefixes=set()
 for row in S:
  if not isinstance(row,list)or len(row)!=3:raise ValueError('site arity')
  pc,op,arg=row
  if not isinstance(pc,str)or not pc or len(pc)>64 or set(pc)-{'0','1'} or pc in leaves:raise ValueError('site path')
  if op not in ('CI','CD','CB','CC','CH'):raise ValueError('opcode')
  if op=='CH':
   if arg is not None:raise ValueError('halt operand')
  elif type(arg)!=int or (op in ('CI','CD')and not 0<=arg<9)or(op in ('CB','CC')and arg<1):raise ValueError('operand')
  leaves.add(pc);prefixes.update(pc[:i]for i in range(len(pc)))
 if leaves&prefixes or any(x+b not in leaves|prefixes for x in prefixes for b in '01'):raise ValueError('incomplete binary tree')
 if sum(x[1]=='CH'for x in S)!=1:raise ValueError('halt count')

ap=argparse.ArgumentParser();ap.add_argument('--table',type=Path,required=True);ap.add_argument('--sites',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
raw=a.table.read_bytes();src=a.sites.read_bytes();T=p.read_table(a.table);S=json.loads(src);validate_sites(S);engine=Path(p.__file__).read_bytes();wrapper=Path(__file__).read_bytes();L,C=p.find_blocks(T);start=time.monotonic();results=[]
for i,s in enumerate(S):
 for b in ((False,True)if s[1]=='CD'else(False,)):
  try:r=p.case(T,L,s,b,True)
  except Exception as e:
   a.output.write_text(json.dumps({'status':'NOT_PROVED','site_index':i,'site':s,'positive':b,'reason':repr(e)},indent=2)+'\n');raise
  r['site_index']=i;r['positive']=b;results.append(r)
 if i%500==0:print(i,len(results),round(time.monotonic()-start,2),flush=True)
if a.table.read_bytes()!=raw or a.sites.read_bytes()!=src or Path(p.__file__).read_bytes()!=engine or Path(__file__).read_bytes()!=wrapper:raise ValueError('inputs changed')
out={'checker_sha256':hashlib.sha256(wrapper).hexdigest(),'engine_sha256':hashlib.sha256(engine).hexdigest(),'status':'INDEPENDENT_UNIVERSAL_PASS','cases':len(results),'sites':len(S),'table_sha256':hashlib.sha256(raw).hexdigest(),'source_sha256':hashlib.sha256(src).hexdigest(),'seconds':time.monotonic()-start,'minimum_steps':min(x['duration'][0]for x in results),'block_certificates':C,'scope':'Every natural register vector at each decrement guard, arbitrary natural extra gap, nonempty arbitrary finite spare list, full tape. Ordinary symbolic induction checker, not kernel certificate.'}
a.output.write_text(json.dumps(out,indent=2)+'\n');a.output.with_suffix('.cases.json').write_text(json.dumps(results)+'\n');print(out['status'],out['cases'])
