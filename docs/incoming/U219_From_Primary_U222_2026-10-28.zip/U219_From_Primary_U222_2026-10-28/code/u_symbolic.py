"""Self-authored universal mathematical checker of literal binary TM tables.

Only the Python standard library is used. Adapted from our earlier symbolic runtime checker.
Downloaded code is not imported or executed. Supplied tables/AST/JSON are data.
Sound rules: literal steps; induction over a natural unary length when a row
is a self-loop in the scan direction; structural induction over a finite list
of blocks after independently proving its one-block schema on the actual table.
This is executable mathematical evidence, not a proof-assistant kernel check.
"""
from pathlib import Path
import json,hashlib,time,argparse,os,sys
if not __debug__ or sys.flags.optimize:
    raise RuntimeError("Universal checking requires enabled assertions; disable -O and PYTHONOPTIMIZE.")


# Thirteen affine slots: constant, gap, nine independent primary values,
# first-spare value, and remaining spare-list width. The separate generic
# one-block proof reuses slot 2 for its arbitrary natural block value.
NV=13
ZERO=(0,)*NV

def num(n):return (n,)+(0,)*(NV-1)
def var(i):return tuple(int(j==i) for j in range(NV))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def neg(a):return tuple(-x for x in a)
def minus1(a):return (a[0]-1,)+a[1:]
def nonnegative(a):return all(x>=0 for x in a)
def run(bit,n):return ('run',bit,n if isinstance(n,tuple) else num(n))
def bit(b):return run(b,1)
def block(value,family='B'):
    # B(v)=0 1^(v+1), C(v)=1 0 1^v, D(v)=1^(v+1) 0.
    return [bit(0),run(1,add(value,num(1)))] if family=='B' else ([run(1,add(value,num(1))),bit(0)] if family=='D' else [bit(1),bit(0),run(1,value)])
def tail(family='B',reverse=False):return ('list',family,'spare_tail',reverse)
BLANK=('blank',)
def rev(atoms):
    return [a if a[0]!='list' else (a[0],a[1],a[2],not a[3]) for a in reversed(atoms)]

def normal(atoms):
    out=[]
    for a in atoms:
        if a[0]=='run':
            assert a[1] in (0,1) and nonnegative(a[2]),('negative run',a)
            if a[2]==ZERO:continue
            if out and out[-1][0]=='run' and out[-1][1]==a[1]:
                a=run(a[1],add(out.pop()[2],a[2]))
        out.append(a)
    # An infinite zero exterior absorbs any finite adjacent zero run.
    if len(out)>1 and out[-1]==BLANK and out[-2][0]=='run' and out[-2][1]==0:out.pop(-2)
    # Finite-list word identity, proved by base/cons algebra independently below:
    # C(A) 1 = 1 B(A), and its reversal 1 rev(C(A)) = rev(B(A)) 1.
    for i in range(len(out)-1):
        a,b=out[i:i+2]
        if a[:2]==('run',0) and a[2][0]>=1 and b[:2]==('list','D') and not b[3]:
            return normal(out[:i]+[run(0,minus1(a[2])),('list','B',b[2],False),bit(0)]+out[i+2:])
        if a[:2]==('list','D') and a[3] and b[:2]==('run',0) and b[2][0]>=1:
            return normal(out[:i]+[bit(0),('list','B',a[2],True),run(0,minus1(b[2]))]+out[i+2:])
        if a[:2]==('list','C') and not a[3] and b[:2]==('run',1) and b[2][0]>=1:
            return normal(out[:i]+[bit(1),('list','B',a[2],False),run(1,minus1(b[2]))]+out[i+2:])
        if a[:2]==('run',1) and a[2][0]>=1 and b[:2]==('list','C') and b[3]:
            return normal(out[:i]+[run(1,minus1(a[2])),('list','B',b[2],True),bit(1)]+out[i+2:])
    return out

class State:
    def __init__(self,q,left,right,direction=1):self.q=q;self.left=list(left);self.right=list(right);self.direction=direction
    def key(self):
        self.left=normal(self.left);self.right=normal(self.right)
        return self.q,self.direction,self.left,self.right
    def step(self,table,lemmas,clock,motion):
        self.key()
        src,dst=(self.right,self.left) if self.direction==1 else (self.left,self.right)
        if not src:raise AssertionError('Unrepresented tape exterior')
        a=src[0]
        if a==BLANK:src.insert(0,bit(0));a=src[0]
        if a[0]=='list':
            key=(self.q,self.direction,a[1],a[3])
            if key not in lemmas and a[1]=='B' and a[3] and len(src)>1 and src[1][:2]==('run',1) and src[1][2][0]>=1:
                # rev(B(A)) 1 = 1 rev(C(A)); consume the exposed one literally.
                z=src[1];src[:2]=[bit(1),('list','C',a[2],True),run(1,minus1(z[2]))]
                w,d,q=table[self.q,1]
                src.pop(0)
                if d==self.direction:dst.insert(0,bit(w))
                else:src.insert(0,bit(w));self.direction=d
                self.q=q
                return add(clock,num(1)),add(motion,num(d)),('literal',(key[0],1,w,d,q))
            assert key in lemmas,('No checked list traversal',key)
            src.pop(0);dst.insert(0,('list',lemmas[key],a[2],not a[3]))
            width=var(12)
            return add(clock,width),add(motion,width if self.direction==1 else neg(width)),('list',key)
        assert a[0]=='run',('Opaque context reached',self.q,self.direction,a)
        w,d,q=table[self.q,a[1]]
        row=(self.q,a[1],w,d,q)
        if q==self.q and d==self.direction:
            src.pop(0);dst.insert(0,run(w,a[2]))
            return add(clock,a[2]),add(motion,a[2] if d==1 else neg(a[2])),('unary',row,a[2])
        assert a[2][0]>=1,('Unknown run may be empty',row,a)
        src[0]=run(a[1],minus1(a[2]))
        if d==self.direction:dst.insert(0,bit(w))
        else:src.insert(0,bit(w));self.direction=d
        self.q=q
        return add(clock,num(1)),add(motion,num(d)),('literal',row)



def read_table(path):
 table={}
 for line in Path(path).read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,t=line.split();q,b,w,t=map(int,(q,b,w,t))
  if (q,b) in table or b not in (0,1) or w not in (0,1) or d not in ('L','R') or min(q,t)<0:raise ValueError('invalid table row')
  table[q,b]=(w,1 if d=='R' else -1,t)
 states={q for q,b in table}
 if 84 not in states or 254 in states or set(table)!={(q,b)for q in states for b in(0,1)} or {r for w,d,r in table.values()}-states!={254}:raise ValueError('invalid table domain')
 return table

def find_blocks(table):
 lemmas={};certs=[];v=var(2)
 for q in sorted({q for q,b in table}):
  for d in (1,-1):
   for before in ('B','C','D'):
    for after in ('B','C','D'):
     L=('opaque','left');R=('opaque','right')
     if d==1:
      state=State(q,[L],block(v,before)+[R]);target=State(q,rev(block(v,after))+[L],[R])
     else:
      state=State(q,rev(block(v,before))+[L],[R],-1);target=State(q,[L],block(v,after)+[R],-1)
     steps=ZERO;motion=ZERO;trace=[]
     try:
      for tick in range(50):
       if tick and state.key()==target.key():break
       steps,motion,event=state.step(table,{},steps,motion);trace.append(event)
      else:continue
     except (AssertionError,KeyError):continue
     if steps!=add(v,num(2)) or motion!=(steps if d==1 else neg(steps)):continue
     key=q,d,before,d==-1
     if key in lemmas and lemmas[key]!=after:raise ValueError('ambiguous block')
     lemmas[key]=after;certs.append({'entry':q,'direction':d,'before':before,'after':after,'trace':trace})
 return lemmas,certs
PHY=[6,2,0,4,3,7,8,5,1]
def inc(pc):
 if '0' not in pc:return '',1
 i=pc.rfind('0');return pc[:i]+'1'+'0'*(len(pc)-i-1),0
def strip(pc,b,n):
 for _ in range(n):
  i=pc.rfind(b)
  if i<0:return ''
  pc=pc[:i]
 return pc

def file_bits(values,spares=True,append=None):
 atoms=[]
 for v in values:atoms+=block(v)
 if spares:atoms+=block(var(11))+[tail()]
 if append is not None:atoms+=block(num(append))
 return atoms+[BLANK]

def case(table,lemmas,site,positive,spares=True):
 pc,op,arg=site;values=[var(2+i) for i in range(9)]
 if op=='CD':values[arg]=add(num(1),values[arg]) if positive else ZERO
 physical=[None]*9
 for i,j in enumerate(PHY):physical[j]=values[i]
 result=physical.copy();overflow=0;extra=None;delta=0
 if op=='CI':result[PHY[arg]]=add(result[PHY[arg]],num(1));successor,overflow=inc(pc);extra=1
 elif op=='CD' and positive:result[PHY[arg]]=minus1(result[PHY[arg]]);successor,overflow=inc(pc);delta=1
 elif op in ('CD','CB'):successor,overflow=inc(strip(pc,'0',arg if op=='CB' else 1))
 elif op=='CC':successor=strip(pc,'1',arg)
 elif op=='CH':successor=''
 else:raise ValueError(site)
 state=State(84,[bit(1),BLANK],[bit(int(b)) for b in pc]+[run(0,add(var(1),num(64-len(pc)))),bit(1)]+file_bits(physical,spares))
 target=State(84,[bit(1),BLANK],[bit(int(b)) for b in successor]+[run(0,add(var(1),num(64+delta+overflow-len(successor)))),bit(1)]+file_bits(result,spares,extra))
 target_key=target.key();clock=ZERO;motion=ZERO;rows=set()
 for count in range(4000):
  key=state.key()
  if count and ((op=='CH' and state.q==254) or (op!='CH' and key==target_key)):
   if not (nonnegative(clock) and clock[0]>0):raise ValueError('no positive progress')
   if op!='CH' and motion!=num(-overflow):raise ValueError(('wrong motion',motion,overflow))
   return {'symbolic_steps':count,'duration':clock,'rows':sorted(rows)}
  clock,motion,event=state.step(table,lemmas,clock,motion)
  if event[0]!='list':rows.add(event[1][:2])
 raise AssertionError(('case did not close',site,positive,state.key(),target_key))
