"""Owned, deterministic five-rotation/selector-fold U221-to-U220 construction."""
import json,hashlib,argparse
from pathlib import Path

def need(x,m):
 if not x:raise ValueError(m)
def parse(raw):
 T={}
 for l in raw.decode().splitlines():
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();k=int(q),int(b);need(k not in T,'duplicate');T[k]=int(w),d,int(z)
 return T
def render(T,r=None):
 if r is None:r={q:q for q,b in T};r[254]=254
 return ('#! start 0\n'+''.join(f'{r[q]} {b} {w} {d} {r[z]}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode()
def construct(raw):
 need(hashlib.sha256(raw).hexdigest()=='49d2675c04d9ec692e7d030b18f2d39b6502a65018c5fea10423f6c68f359a6e','baseline SHA');T=parse(raw)
 for q,r,side,ends in [(503, 174, 1, (90, 174, 504, 216)), (156, 503, 0, (503, 145, 174, 216)), (177, 211, 0, (211, 129, 166, 216)), (52, 154, 0, (154, 150, 166, 12)), (211, 129, 1, (216, 129, 215, 166))]:
  need([T[q,0],T[q,1],T[r,0],T[r,1]]==[(b,'R',v)for b,v in zip((0,1,0,1),ends)],'rotation rows')
  need(sorted(k for k,v in T.items()if v[2]==r)==[(q,side)],'unique inner entrance')
  U=T.copy()
  if side==0:
   U[q,0]=(0,'R',T[r,0][2]);U[q,1]=(1,'R',r);U[r,0]=(0,'R',T[r,1][2]);U[r,1]=(1,'R',T[q,1][2])
  else:
   U[q,0]=(0,'R',r);U[q,1]=(1,'R',T[r,1][2]);U[r,0]=(0,'R',T[q,0][2]);U[r,1]=(1,'R',T[r,0][2])
  T=U
 pre=T.copy();need(T[216,1]==T[215,1]==(1,'R',61),'common branch')
 need(sorted(k for k,v in T.items()if v[2]==216)==[(129,0),(203,0),(503,0)],'tag0 entrances')
 need(all(T[q,0]==(0,'R',216)for q in(129,203,503)),'tag0 writes')
 need(sorted(k for k,v in T.items()if v[2]==215)==[(129,1),(145,1)],'tag1 entrances')
 need(all(T[q,1]==(1,'R',215)for q in(129,145)),'tag1 writes')
 need(T[154,0]==(0,'R',12)and T[154,1]==(1,'R',150),'selector rows')
 need(T[12,0]==T[216,0]and T[150,0]==T[215,0],'branch replay')
 T[216,0]=(0,'L',154);T={(q,b):(w,d,216 if z==215 else z)for(q,b),(w,d,z)in T.items()if q!=215}
 states=sorted({q for q,b in T});need(len(states)==220 and set(T)=={(q,b)for q in states for b in(0,1)},'state totality');need({v[2]for v in T.values()}-set(states)=={254},'halt')
 ren={q:i for i,q in enumerate(states)};ren[254]=220;return pre,T,ren
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('output',type=Path);a=p.parse_args();pre,T,r=construct(a.baseline.read_bytes());a.output.mkdir(parents=True,exist_ok=True)
 for n,raw in [('rotated221.tm',render(pre)),('u220.native.tm',render(T)),('u220.tm',render(T,r)),('renaming.json',(json.dumps(r,indent=2)+'\n').encode())]:(a.output/n).write_bytes(raw)
 print(json.dumps({'working_states':220,'transition_rows':440,'native_sha256':hashlib.sha256(render(T)).hexdigest(),'dense_sha256':hashlib.sha256(render(T,r)).hexdigest()},sort_keys=True))
