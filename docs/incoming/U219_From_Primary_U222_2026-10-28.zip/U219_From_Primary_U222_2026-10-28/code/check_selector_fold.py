"""Owned exact local selector-fold certificate checker; no generator imports."""
import argparse,json
from pathlib import Path

def need(x,m):
 if not x:raise ValueError(m)
def read(p):
 T={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();k=int(q),int(b);need(k not in T,'duplicate');T[k]=int(w),d,int(z)
 return T
def check(P,F,a,c,h,b):
 need(len({a,c,h,0,254})==5,'distinct states')
 need(P[a,1-b]==P[c,1-b],'common branch')
 entrances={}
 for tag,q in enumerate((a,c)):
  ins=[(r,bit)for(r,bit),v in P.items()if v[2]==q];need(bool(ins),'unreachable fold state')
  need(all(P[k][:2]==(tag,'R')for k in ins),'predecessor tag not established');entrances[q]=ins
  need(P[q,b][:2]==(b,'R'),'branch must preserve current symbol and advance')
  wr,d,z=P[h,tag];need((wr,d)==(tag,'R')and z not in(a,c,h,254),'selector route')
  need(P[z,b]==P[q,b],'replayed branch')
 expected=P.copy();expected[a,b]=(b,'L',h)
 expected={(q,i):(wr,d,a if z==c else z)for(q,i),(wr,d,z)in expected.items()if q!=c}
 need(F==expected,'entire-table fold correspondence')
 traces=[]
 for tag,oldq in enumerate((a,c)):
  for symbol in(0,1):
   old={-1:tag,0:symbol};new=old.copy();w,d,oq=P[oldq,symbol];old[0]=w;oh=1 if d=='R'else -1
   q=a;head=0;steps=3 if symbol==b else 1
   for i in range(steps):
    need(head in new,'macro touches arbitrary outside context');w,d,q=F[q,new[head]];new[head]=w;head+=1 if d=='R'else -1
    need(q!=254 or i==steps-1,'premature halt')
   need(new==old and head==oh and q==(a if oq==c else oq),'local whole-tape correspondence')
   traces.append({'tag':tag,'read':symbol,'old_steps':1,'new_steps':steps,'exit':q})
 return {'status':'pass','working_states_before':len(P)//2,'working_states_after':len(F)//2,'entrances':entrances,'four_local_cases':traces,'unchanged_outside_two_cells':True,'positive_finite_simulation':True}
def negatives(P,F,a,c,h,b):
 controls=[]
 for name,mut in [('helper corruption',(h,0)),('common branch corruption',(a,1-b)),('fold excursion corruption',(a,b))]:
  U=F.copy();w,d,z=U[mut];U[mut]=(1-w,d,z)
  try:check(P,U,a,c,h,b)
  except ValueError:controls.append(name)
  else:raise ValueError('negative control accepted')
 U=F.copy();U[c,0]=P[c,0]
 try:check(P,U,a,c,h,b)
 except ValueError:controls.append('deleted state restored')
 else:raise ValueError('negative state accepted')
 return controls
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('before',type=Path);p.add_argument('after',type=Path);p.add_argument('keep',type=int);p.add_argument('removed',type=int);p.add_argument('helper',type=int);p.add_argument('branch',type=int);a=p.parse_args();P=read(a.before);F=read(a.after);r=check(P,F,a.keep,a.removed,a.helper,a.branch);r['negative_controls_rejected']=negatives(P,F,a.keep,a.removed,a.helper,a.branch);print(json.dumps(r,sort_keys=True))
