from pathlib import Path
import json,itertools,hashlib
H=Path(__file__).resolve().parents[1]/'machine';P=H/'source220'
def req(v,m):
 if not v:raise ValueError(m)
def table(path):
 T={}
 for l in path.read_text().splitlines()[1:]:
  q,b,w,d,z=l.split();T[int(q),int(b)]=(int(w),1 if d=='R'else -1,int(z))
 return T
T=table(P/'rotated221.tm');U=table(P/'u220.native.tm');keep,drop=216,215
for bit,state in enumerate((keep,drop)):
 incoming=[(q,b,w,d)for(q,b),(w,d,z)in T.items()if z==state]
 req(bool(incoming),'empty tag proof');req(state!=0,'initial-tag exception')
 req(all(w==bit and d==1 for q,b,w,d in incoming),'tag incoming')
# Arbitrary bits on both sides plus the certified tag; no external reads.
cases=0
for tag,state in enumerate((keep,drop)):
 for bits in itertools.product((0,1),repeat=4):
  tape={-2:bits[0],-1:tag,0:bits[1],1:bits[2],2:bits[3]};orig=tape.copy()
  w,d,z=T[state,tape[0]];orig[0]=w;expected=(keep if z==drop else z,d,orig)
  q=keep;head=0
  for tick in range(3 if tape[0]==0 else 1):
   req(head in tape,'unknown read');w,d,q=U[q,tape[head]];tape[head]=w;head+=d
  req((q,head,tape)==expected,'macro semantics');cases+=1
req(U=={(q,b):((0,-1,154)if(q,b)==(keep,0)else(w,d,keep if z==drop else z))for(q,b),(w,d,z)in T.items()if q!=drop},'table exact')
def cfg(rows):
 spans={}
 for i,(p,op,a)in enumerate(rows):
  for n in range(len(p)+1):
   key=p[:n]
   if key not in spans:spans[key]=[i,i+1]
   else:spans[key][1]=i+1
 out=[]
 for i,(p,op,a)in enumerate(rows):
  if op=='CH':dest=()
  elif op=='CI':dest=(i+1,)
  else:
   symbol='1'if op=='CC'else'0';count=1 if op=='CD'else a
   ancestors=[p[:j]for j in reversed(range(len(p)))if p[j]==symbol]
   req(0<count<=len(ancestors),'escaping control');jump=spans[ancestors[count-1]][0 if symbol=='1'else 1]
   dest=(jump,i+1)if op=='CD'else(jump,)
  out.append((op,a,dest))
 return out
before=json.loads((H/'source221/sites.json').read_text());after=json.loads((P/'sites.json').read_text())
req(cfg(before)==cfg(after),'source CFG mismatch');req(max(len(z)for p,_,_ in after for z in p.split('1'))<=6,'zero delimiter')
result={'macro_cases':cases,'source_primitive_occurrences':len(after),'resolved_cfg_equal':True,'state_count':len({q for q,b in U}),'native_sha256':hashlib.sha256((P/'u220.native.tm').read_bytes()).hexdigest()}
(H.parent/'evidence/independent_source220.json').write_text(json.dumps(result,indent=2));print(result)
