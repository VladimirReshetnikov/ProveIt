"""Reject malformed inputs and assertion-disabled symbolic verification."""
import argparse,json,subprocess,sys,tempfile
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--table',required=True,type=Path);ap.add_argument('--sites',required=True,type=Path);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args();root=Path(__file__).resolve().parent
raw=a.table.read_text();sites=json.loads(a.sites.read_text());results=[]
with tempfile.TemporaryDirectory() as d:
 d=Path(d)
 tests=[('duplicate_transition',raw+next(x for x in raw.splitlines()if x and not x.startswith('#'))+'\n',sites),('missing_transition','\n'.join(raw.splitlines()[:-1])+'\n',sites),('incomplete_source',raw,sites[:-1]),('duplicate_source',raw,sites+[sites[0]])]
 for name,t,s in tests:
  (d/'machine.tm').write_text(t);(d/'sites.json').write_text(json.dumps(s))
  p=subprocess.run([sys.executable,str(root/'check_independent.py'),'--table',str(d/'machine.tm'),'--sites',str(d/'sites.json'),'--output',str(d/'output.json')],capture_output=True,text=True)
  if p.returncode==0:raise ValueError('negative input accepted: '+name)
  results.append({'test':name,'rejected':True})
 p=subprocess.run([sys.executable,'-O',str(root/'u_symbolic.py')],capture_output=True,text=True)
 if p.returncode==0 or 'Universal checking requires enabled assertions' not in p.stderr:raise ValueError('optimized guard failed')
 results.append({'test':'optimized_python','rejected':True})
a.output.write_text(json.dumps({'status':'PASS','tests':results},indent=2)+'\n');print('PASS',len(results),'negative controls')
