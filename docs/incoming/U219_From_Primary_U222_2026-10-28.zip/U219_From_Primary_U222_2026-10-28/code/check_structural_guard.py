"""Tiny independent two-clause inductive guard proof checker."""
from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent

def require(p,m):
 if not p:raise ValueError(m)
def check_raw(raw):
 lines=raw.decode().splitlines();require(lines[0]=='#! start 0','initial state');T={}
 for l in lines[1:]:
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));require((q,b)not in T,'duplicate');T[q,b]=(w,d,z)
 require({(q,b)for(q,b),(w,d,z)in T.items()if z==112}=={(172,0)},'incoming 112')
 require(T[172,0]==(0,'L',112),'establish right zero')
 require({(q,b)for(q,b),(w,d,z)in T.items()if z==200}=={(112,1)},'incoming 200')
 require(T[112,1]==(1,'R',200),'transfer right zero')
 require(T[200,0]==T[209,0]==(0,'R',157),'merge live row')
 require(0 not in(112,200),'initial invariant')
 return {'status':'PASS_TWO_CLAUSE_INDUCTIVE_GUARD','input_sha256':hashlib.sha256(raw).hexdigest(),'clauses':[{'state':112,'offset':1,'bit':0},{'state':200,'offset':0,'bit':0}],'incoming_rows':[[172,0,0,'L',112],[112,1,1,'R',200]],'matching_rows':[[200,0,0,'R',157],[209,0,0,'R',157]]}
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('tables',nargs='+',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 out=[]
 for path in args.tables:
  raw=path.read_bytes();result=check_raw(raw);negative=[]
  cases={
   'extra incoming':raw.replace(b'0 1 1 R 0',b'0 1 1 R 112'),
   'wrong write':raw.replace(b'172 0 0 L 112',b'172 0 1 L 112'),
   'wrong direction':raw.replace(b'112 1 1 R 200',b'112 1 1 L 200'),
   'wrong matching row':raw.replace(b'209 0 0 R 157',b'209 0 1 R 157'),
   'wrong initial':raw.replace(b'#! start 0',b'#! start 112')}
  for name,bad in cases.items():
   require(bad!=raw,'ineffective negative control')
   try:check_raw(bad)
   except ValueError as e:negative.append({'mutation':name,'status':'REJECTED','reason':str(e)})
   else:raise ValueError('accepted mutation')
  result['negative_controls']=negative;out.append(result)
 args.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
