"""Owned, deterministic one-rotation/selector-fold U222-to-U221 construction."""
import json,hashlib,argparse
from pathlib import Path

def need(x,m):
 if not x:raise ValueError(m)
def parse(raw):
 T={}
 for l in raw.decode().splitlines():
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();k=int(q),int(b);need(k not in T,'duplicate');T[k]=int(w),d,int(z)
 return T
def render(T,r=None):
 if r is None:r={q:q for q,b in T};r[254]=254
 return ('#! start 0\n'+''.join(f'{r[q]} {b} {w} {d} {r[z]}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode()
def construct(raw):
 need(hashlib.sha256(raw).hexdigest()=='88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427','baseline SHA');T=parse(raw)
 need([T[q,b]for q,b in((506,0),(506,1),(145,0),(145,1))]==[(0,'R',19),(1,'R',145),(0,'R',215),(1,'R',504)],'rotation rows')
 need(sorted(k for k,v in T.items()if v[2]==145)==[(506,1)],'rotation unique inner entrance')
 T.update({(506,0):(0,'R',145),(506,1):(1,'R',504),(145,0):(0,'R',19),(145,1):(1,'R',215)})
 pre=T.copy();need(T[145,1]==T[134,1]==(1,'R',215),'common branch')
 need(sorted(k for k,v in T.items()if v[2]==145)==[(506,0)],'tag0 entrance');need(T[506,0]==(0,'R',145),'tag0 write')
 need(sorted(k for k,v in T.items()if v[2]==134)==[(156,1),(210,1)],'tag1 entrances');need(T[156,1]==T[210,1]==(1,'R',134),'tag1 writes')
 need(T[507,0]==(0,'R',166)and T[507,1]==(1,'R',163),'selector rows');need(T[166,0]==T[145,0]and T[163,0]==T[134,0],'branch replay')
 T[145,0]=(0,'L',507);T={(q,b):(w,d,145 if z==134 else z)for(q,b),(w,d,z)in T.items()if q!=134}
 states=sorted({q for q,b in T});need(len(states)==221 and set(T)=={(q,b)for q in states for b in(0,1)},'state totality');need({v[2]for v in T.values()}-set(states)=={254},'halt')
 ren={q:i for i,q in enumerate(states)};ren[254]=221;need(ren[0]==0,'initial state');return pre,T,ren
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('output',type=Path);a=p.parse_args();pre,T,r=construct(a.baseline.read_bytes());a.output.mkdir(parents=True,exist_ok=True)
 for n,raw in [('rotated222.tm',render(pre)),('u221.native.tm',render(T)),('u221.tm',render(T,r)),('renaming.json',(json.dumps(r,indent=2)+'\n').encode())]:(a.output/n).write_bytes(raw)
 print(json.dumps({'working_states':221,'transition_rows':442,'native_sha256':hashlib.sha256(render(T)).hexdigest(),'dense_sha256':hashlib.sha256(render(T,r)).hexdigest()},sort_keys=True))
