"""Owned interval and numeric successor CFG checker, reused from this investigation's PA236 construction."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def need(x,m):
 if not x:raise ValueError(m)
def cfg(rows):
 """Resolve control flow by intervals of source prefixes, not numeric PC arithmetic."""
 span={}
 for i,(p,op,arg) in enumerate(rows):
  for k in range(len(p)+1):
   key=p[:k]
   if key not in span:span[key]=[i,i+1]
   else:span[key][1]=i+1
 result=[]
 for i,(p,op,arg) in enumerate(rows):
  following=(i+1)%len(rows)
  def jump(bit,count):
   places=[j for j,b in enumerate(p)if b==bit]
   if len(places)<count:return 0
   lo,hi=span[p[:places[-count]]]
   return (hi%len(rows)) if bit=='0'else lo
  if op=='CI':v=['increment',arg,[following]]
  elif op=='CD':v=['decrement',arg,[jump('0',1),following]]
  elif op=='CB':v=['identity',None,[jump('0',arg)]]
  elif op=='CC':v=['identity',None,[jump('1',arg)]]
  else:need(op=='CH','opcode');v=['halt',None,[]]
  result.append(v)
 return result
def graph_numeric(rows):
 labels={p:i for i,(p,op,a)in enumerate(rows)};size=len(rows)
 def locate(p):
  choices=[(k,i)for k,i in labels.items()if p.startswith(k)or k.startswith(p)]
  need(bool(choices),'missing successor')
  k,i=min(choices,key=lambda x:x[0])
  if p.startswith(k):need('1'not in p[len(k):],'stray successor bits')
  else:need('1'not in k[len(p):],'not leftmost')
  return i
 def increment(p):
  if not p:return ''
  return format((int(p,2)+1)%(1<<len(p)),f'0{len(p)}b')
 out=[]
 for p,op,a in rows:
  def cut(bit,n):
   positions=[j for j,v in enumerate(p)if v==bit]
   return p[:positions[-n]]if len(positions)>=n else ''
  nxt=locate(increment(p))
  if op=='CI':v=['increment',a,[nxt]]
  elif op=='CD':v=['decrement',a,[locate(increment(cut('0',1))),nxt]]
  elif op=='CB':v=['identity',None,[locate(increment(cut('0',a)))]]
  elif op=='CC':v=['identity',None,[locate(cut('1',a))]]
  else:v=['halt',None,[]]
  out.append(v)
 return out

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);a=p.parse_args()
 x=json.loads(a.baseline.read_text());y=json.loads(a.candidate.read_text())
 for r in(x,y):
  ps=[v[0]for v in r];need(len(ps)==len(set(ps)),'duplicate leaf');need(ps==sorted(ps),'source order')
  prefixes={p[:i]for p in ps for i in range(len(p))};need(not set(ps)&prefixes,'leaf prefix overlap')
  need(all(p+b in prefixes or p+b in ps for p in prefixes for b in '01'),'incomplete binary source')
 need([v[1:]for v in x]==[v[1:]for v in y],'primitive order')
 need(cfg(x)==cfg(y)==graph_numeric(x)==graph_numeric(y),'four graphs differ')
 print(json.dumps({'status':'pass','original_sites':len(x),'candidate_sites':len(y),'four_control_graphs_identical':True,'candidate_maximum_depth':max(len(v[0])for v in y),'candidate_maximum_zero_run':max(len(z)for p,op,arg in y for z in p.split('1'))},sort_keys=True))
