"""Negative controls for the independent source CFG checker; no generator imports."""
import argparse, copy, json, subprocess, sys, tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('checker',type=Path);p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);a=p.parse_args()
rows=json.loads(a.candidate.read_text())
variants={}
x=copy.deepcopy(rows);x.append(x[-1]);variants['duplicate leaf']=x
x=copy.deepcopy(rows);x.pop();variants['missing leaf']=x
x=copy.deepcopy(rows);x[0][1]='CH' if x[0][1]!='CH' else 'CI';variants['changed primitive']=x
x=copy.deepcopy(rows);x[0][0]=x[0][0][:-1];variants['prefix collision']=x
# Preserve the multiset/order of operations but alter their binary grouping.
# A nonclosed reassociation must be detected through graph inequality.
def parse(rs):
 d={}
 for path,op,arg in rs:
  t=d
  for b in path:t=t.setdefault(b,{})
  t['leaf']=(op,arg)
 def rec(t):return t['leaf'] if 'leaf' in t else(rec(t['0']),rec(t['1']))
 return rec(d)
def leaf(t):return isinstance(t[0],str)
def emit(t,p=''):
 return [[p,*t]] if leaf(t) else emit(t[0],p+'0')+emit(t[1],p+'1')
tree=parse(rows)
# Deterministic root reassociation keeps primitive ordering but is not asserted
# a priori to be unsafe; only count the control if the checker rejects it.
if not leaf(tree[0]):variants['root nonclosed reassociation']=emit((tree[0][0],(tree[0][1],tree[1])))
rejected=[]
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'bad.json'
 for name,x in variants.items():
  f.write_text(json.dumps(x));r=subprocess.run([sys.executable,*(['-O'] if not __debug__ else []),str(a.checker),str(a.baseline),str(f)],capture_output=True,text=True)
  if r.returncode==0:raise ValueError('mutation accepted: '+name)
  rejected.append(name)
print(json.dumps({'status':'pass','negative_controls_rejected':rejected},sort_keys=True))
