"""Regenerate every source/table and bind all intermediate proofs to one chain."""
from pathlib import Path
import subprocess,sys,tempfile,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def need(p,m):
 if not p:raise ValueError(m)
def run(script,*args):
 cmd=[sys.executable]+(['-O']if sys.flags.optimize else[])+[str(ROOT/script),*map(str,args)]
 subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
def equal(a,b):need(a.read_bytes()==b.read_bytes(),f'byte mismatch {a.name} vs {b}')
with tempfile.TemporaryDirectory(prefix='u-reconstruction-') as d:
 tmp=Path(d);base=ROOT/'machine/direct221/u222.native.tm';sites=ROOT/'machine/sites222.json'
 run('code/build221.py',base,tmp/'source221')
 run('code/build_source221.py',sites,tmp/'source221')
 for f in ['u221.native.tm','u221.tm','rotated222.tm','renaming.json','sites.json']:equal(tmp/'source221'/f,ROOT/'machine/source221'/f)
 run('code/build_source220_table.py',tmp/'source221/u221.native.tm',tmp/'source220')
 run('code/build_source220_sites.py',tmp/'source221/sites.json',tmp/'source220')
 for f in ['u220.native.tm','u220.tm','rotated221.tm','renaming.json','sites.json']:equal(tmp/'source220'/f,ROOT/'machine/source220'/f)
 for folder,script,n in [('direct221','build_direct221.py',221),('final220','build220.py',220),('final219','build219.py',219)]:
  a=ROOT/'machine'/folder
  frozen={p.name:p.read_bytes()for p in a.iterdir()if p.suffix in('.tm','.json')and not p.name.startswith(('check','local','bit'))}
  run(Path('machine')/folder/script)
  need(all((a/k).read_bytes()==v for k,v in frozen.items()),'quotient regeneration mismatch')
 equal(ROOT/'machine/source221/u221.native.tm',ROOT/'machine/final220/input221.native.tm')
 equal(ROOT/'machine/source220/u220.native.tm',ROOT/'machine/final219/input220.native.tm')
 equal(ROOT/'machine/final219/u219.tm',ROOT/'machine/final.tm')
 print(json.dumps({'status':'PASS','final_states':219,'final_rows':438,'final_sha256':hashlib.sha256((ROOT/'machine/final.tm').read_bytes()).hexdigest(),'all_intermediates_byte_exact':True},sort_keys=True))
