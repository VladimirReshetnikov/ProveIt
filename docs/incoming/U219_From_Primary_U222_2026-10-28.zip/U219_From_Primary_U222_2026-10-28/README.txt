U219 FROM THE PRIMARY U222 CONSISTENCY MACHINE
28 October 2026

RESULT
The exact machine/final.tm has 219 working states, 438 binary transition rows,
a separate halt 219, a blank two-way infinite tape, and only L/R moves.
Start state 0, head 0; blank initialization is INCLUDED.

Ordinary mathematical theorem, formalizable in PA:
  PA proves Nonhalt(U219, blank) iff Con(U).
The precise unary weak power-covering theory U is unchanged.

This is three states below the user's PRIMARY U222, not merely an improvement
of the previous PA236 package. The construction retains U222's logical emitter.
Six closed decoder-DAG rotations (eight unfolded occurrences), two predecessor-
bit folds, and a guarded state quotient remove native states 134, 215, 200.

PROOF STATUS
The inherited U222 consistency calibration is an ordinary mathematical proof,
not the formal endpoint for the different K215 machine. New source/runtime and
quotient arguments are given here with executable finite certificates. No new
Lean/Rocq/MM0/PA kernel derivation is supplied. No global minimality and no
unconditional nonhalting/consistency claim are made.

READ
report.pdf / report.tex       Main theorem, proofs, prior-work comparison, full table
machine/final.tm             Definitive dense table (start0, halt 219)
machine/final219/            Native table, exact quotient certificate and checker
machine/source220/           Last universally simulated source/runtime intermediate
machine/source221/           First source-fold intermediate
machine/direct221/           Simple independent221-state alternative
machine/final220/            Earlier combined220-state alternative
proofs/                     Detailed new proofs and audits
code/                       Builders and symbolic/finite checks
upstream/U222_ConU_2026-10-28.zip  Exact unchanged primary input and its dependencies
prior/                      Compared TeX snapshots and archive hash ledger
manifest.json               Closed sealed-file SHA256 inventory

REPLAY
  python3 reproduce.py --report /absolute/path/receipt.json
Python 3.10+, standard library only; no network or external solver. Full replay
has33 stages and4 integrity negative controls. Runtime checks take several minutes.
All mutable verification data are in a disposable copy. The original sealed
release is authenticated before and after. '--quick' is only a shorter check.

Construction, CFG, fold and quotient checks pass normal and optimized Python.
The assertion-based universal engine deliberately rejects -O; its rejection is
checked. Do not describe this as an optimized-mode universal runtime pass.

The final 219 table is only claimed equivalent on the blank run. Its universal
source-runtime predecessor has 220 states and passes all 5,060 symbolic cases across
3,891 source leaves. A separately proved inductive guard transports blank behavior
step-for-step from that source-220 table to final 219.

Final dense table SHA256:
00ffc9d3d854c631efcba22018d17ac82d1a93f2ec8f47758493c67dd6b4dda0

BUILD PDF
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
Run twice. TeX version can change PDF bytes, not the definitive machine table.
