# A five-cell invariant and a one-step state quotient

## Scope and exact tables

The direct221-state construction starts from the supplied U222 native table SHA25688a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427. It deletes native state200 and redirects every transition into200 to209. Its dense table has221 working states and halt221.

The composed220-state construction performs the same deletion on the separately generated source-optimized221-state table SHA25649d2675c04d9ec692e7d030b18f2d39b6502a65018c5fea10423f6c68f359a6e. The source optimization requires its own proof. The deletion below is independently established for that exact input table.

## Finite inductive invariant

For an actual configuration with controlq and headh, encode the five tape cells at h−2,...,h+2 as x=Σ tape(h+i−2)2^i for i=0,...,4. Its center symbol is bit2 ofx. Each certificate gives a finite setS(q)⊆{0,...,31}, stored as a32-bit mask.

The independent verifier checks:

1. State0 and window0 belong toS, as required by the blank initial tape.
2. For each(q,x)∈S withq nonterminal, write the literal transition's bit at position2. Shift the window by the transition's direction. For EACH choice0or1 of the newly exposed outside cell, the resulting(q',x')belongs toS.
3. Every x∈S(200)has center bit0.

The second condition is a finite closedness assertion. Actual executions satisfyS by induction on the number of steps: the unknown outside cell must have one of the two checked values. No assumption about consistency or nonhalting enters this induction. The direct221certificate has3082 abstract configurations and6148 successor checks. The composed220certificate has3110 configurations and6204 successor checks.

Therefore every actual entry into state200 reads0. No claim is made that all abstract configurations are concretely reachable.

## Exact quotient

Letf(200)=209 andf(q)=q otherwise, includingf(254)=254. The literal rows of both inputs satisfy

  δ(200,0) = (0,R,157) = δ(209,0).

Delete200 and replace each transition targetz byf(z). For every configuration of the original machine satisfyingS, the new machine at controlf(q), with identical tape and head, performs exactly the corresponding transition: it writes the same symbol, moves in the same direction, and reaches controlf(q'). The verifier checks this identity for every abstract configuration, not only for the two displayed rows.

Thus the original and quotient blank executions have identical tapes and head positions after every step, with control related byf. Their halting times are equal whenever finite. Nonhalting is equivalent as well: f maps no working state to the halt state, and the two deterministic executions correspond step for step. The construction neither hides initialization nor changes the tape alphabet, movement model, or blank input.

The dense relabeling is a separately checked bijection of all working states and the halt state, fixing the initial state's label0.

## PA formalization and trust boundary

The invariant has finite control/window domains. Every closure and quotient check can be expanded into a finite elementary-arithmetic proof. The global argument uses induction on execution length, available in PA. Consequently PA proves the two literal machines have equivalent blank halting statements. Composing this theorem with the supplied consistency calibration transfers Con(U) to the smaller table.

The supplied Python verifier uses explicit failures, not removable Python assertions. Normal and optimizedPython runs agree. Negative controls separately reject a missing initial state, an added false guard case, a changed live transition, and a changed dense initial-state header. These checks provide executable mathematical evidence; no new Lean/Rocq kernel artifact is asserted.

## Shorter primary proof: two local facts suffice

The larger five-cell certificate is independent supporting evidence; the key guard has this much shorter proof.

Inspection of every row in either input table establishes:

- The sole transition entering112 is172,0→0,L,112.
- The sole transition entering200 is112,1→1,R,200.

Use the two-clause invariant: when control is112, the cell immediately to the right of the head is0; when control is200, the currently scanned cell is0. It holds initially because the initial control is0. On any entry into112, the preceding step wrote0 and moved left, so the cell now to the right is0. On any entry into200, the preceding control was112, and its right cell was0 by induction; the transition writes at the current cell and moves right onto that known0. These are all ways to enter the two constrained states. Other states impose no condition. This proves the invariant by a single elementary induction on time, with only two nontrivial cases.

The guard at200 now follows, and the exact quotient argument above applies unchanged. check_local_guard.py independently verifies the two unique-incoming assertions and the two matching live rows for both input tables. This short structural proof is preferable for the main exposition and future kernel formalization.

## Final composed219 candidate

The same argument is checked independently for the source-based220-state input SHA256659a03e03186922b8bba6317bc335b6268b6ae4860dbed3829bff9221ff93737. It has the same two unique incoming transitions and matching live rows, so deleting200 into209 gives219 states. The independent window certificate has3102 abstract configurations and6188 successor checks. The resulting native table SHA256 iscc3eb62c58f676f6425ee25b7a8608bb397ae6ec2bcd36f7f94c7ab41c57701d; the dense table SHA256 is00ffc9d3d854c631efcba22018d17ac82d1a93f2ec8f47758493c67dd6b4dda0. Its inherited source-based220 input must pass its separate runtime and consistency calibration checks.
