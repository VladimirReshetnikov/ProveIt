# U221: source reassociation and predecessor-tag fold

Start from the supplied U222 native table, SHA256 88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427, with dispatcher 84 and terminal 254. Initialization is included and unchanged.

At physical source path 11010010011101010110111111100, outer state 506 and its unique inner successor 145 represent A,(B,C), with 19, 28, and 56 primitive instructions respectively. Each factor has boundary(0,0,false): no escaping break, continue, or halt. Replace this by(A,B),C. The ordered primitive instruction list and ordinal guarded control-flow graph are unchanged. Maximum zero run remains 6. Literal decoder rows change from506:(19,145),145:(215,504) to506:(145,504),145:(19,215), with every edge preserving its read bit and movingR.

After reassociation, state 145 has0->(0,R,19),1->(1,R,215). State 134 has0->(0,R,203),1->(1,R,215). The only entrance to 145 is506/read0; the only entrances to 134 are156/read1 and210/read1. These edges write the indicated tag and moveR. Neither state is initial, so every visit has the appropriate known predecessor symbol.

The existing selector 507 has0->(0,R,166),1->(1,R,163). The 166/read0 transition exactly matches145/read0, and 163/read0 exactly matches134/read0.

Redirect all entrances to 134 to 145, delete134, and replace145/read0 by(0,L,507). Read 1 still follows the identical common transition. Read 0 preserves the current cell, moves left to the predecessor tag, returns through 507, and replays the old transition using 166 or 163. This introduces two additional steps, reproducing exactly the old tape, head, and control successor. The local all-tape simulation is reversible under the proven entrance-tag invariant. It does not rely on a finite trace.

The result has 221 working states and 442 transition rows. Dense labels are 0..220, with separate halt 221. Native labels retain terminal 254. The source reassociation still requires full symbolic primitive-runtime verification, since arithmetic program equivalence alone does not validate a specialized bit-level interpreter. That independent gate is separate from the finite deterministic construction checks.

build221.py andbuild_source221.py are newly authored standard-library-only deterministic builders. They pin the baseline inputs, check all row and source-factor prerequisites, and reproduce the exact frozen candidate in normal and optimized Python. Neither builder searches or executes incoming archive code. The general ideas of closed source reassociation and tagged state sharing are inherited; this particular composition is new to this iteration.

This construction is disjoint at the table-row level from the separate proposed 200->209 guarded fold. Composition requires rechecking the latter's invariant on this new table; row disjointness alone is not a proof.
