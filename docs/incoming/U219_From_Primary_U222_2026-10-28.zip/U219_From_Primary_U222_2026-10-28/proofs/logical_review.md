# U222 logic audit and variable-role alternative

Inspected report sections on codec, emitter, calculus and calibration; theory_bridge_notes.txt, exceptional_codes.txt, enumerator_proof_notes.txt, and source-generation/checker code as text. Incoming code not executed.

## Calibration

No specific fatal logical gap found. The exception correction is essential: dynamic guard at n=0 binds its source variable and becomes Emp(test) under global irreflexivity. The resulting all-empty-object cover is supplied by W. A fixed guard with the same unshifted selector is not interchangeable. At n=1, matrix falsity and the output/test collision are harmless under IR. Regular self-fresh cases give W.

The delivered claim uses ordinary mathematical proof templates for PA-provable refutation transformations, not a compiled new K215 certificate. Soundness decodes numerical target1 under W+IR and Bit into PA inconsistency, then into U inconsistency. Completeness uses U included in W, inherited pure logical templates, atomic vacuity projection, indiscernibility interpretation of equality, and padded matrix quotation. It is not an inference from bare external equiconsistency. These remain mathematical dependencies even if the literal table is separately verified.

Naively exchanging source0 and test1 is unsound at matrix0: when tested role0 coincides with dynamic guard/output0, the guard becomes tautological under IR and the lower clause demands diagonal membership. Do not adopt that permutation without excluding zero or changing its proof.

## New variable-role candidate using existing gate

Keep the existing vacuity V(a,b,c)=I(R(a,b),Q(c,R(a,b))) and its gate c!=a and c!=b. Change only the cover component as follows:

- matrix code and output label n=b;
- source label a;
- tested label c;
- guard S=Q(b,I(R(b,c),R(b,a)));
- upper U=Q(c,I(R(c,b),b));
- lower L=Q(c,I(S,I(b,R(c,b))));
- H=Q(b,I(L,I(U,1))), or exchange U/L;
- bundle N(I(V,H)) as before.

This is sound in W+IR for every enabled input. If a!=b, gate ensures all three roles are distinct. For b>0 every matrix label is<b; at b=0 the matrix is closed truth. Thus output b is fresh in the matrix, and the shell is the usual W instance with arbitrary source a and tested c.

If a=b, the guard's local binder b captures both occurrences of source/output b and becomes forall b(E(b,c)->E(b,b)), equivalently Emp(c) under IR. The matrix has no free b, including the closed truth case b=0. Hence the shell is an exact upper/lower weak cover of the selected empty representatives. Choose an empty source e using W, then filter at e with this matrix: Sub(x,e) iff Emp(x). This supplies precisely the exceptional shell. No unique empty object or extensionality is used.

The problematic output/test collision is impossible because the inherited gate requires c!=b. The gate also requires c!=a, preventing source/test collapse. Thus neither an increment nor an extra distinctness test is needed.

Every desired W instance is recovered by choosing a=0,c=1,b=n after padding the matrix to n>1 and normalizing roles0/1. Both gate tests hold, and the usual quotation/renaming proof applies. Every original atomic-vacuity instance remains available because its gate and bundle are unchanged. Consequently this alternative has the same PA calibration to Con(U).

This candidate is an equiconsistent machine-facing extension of literal unary U, not literal U schema enumeration. It may help source DAG sharing through existing copies of a,b,c; no state-count improvement is claimed until compiled and independently checked.

## Independent one-step quotient audit

A new verifier, check_quotients.py, does not import the supplied builder/checker. It independently computes the least reachable radius-two window closure from (state0,00000). Windows are encoded left-to-right in increasing bit positions. A physical right move shifts the window right numerically, admits either bit at its high end, and a left move shifts left and admits either bit at its low end. Halting state254 contributes no successors. This checks every possible unknown exterior bit, not just blank outside the window.

The independently calculated sets equal the supplied masks exactly: 3082 configurations for U222 and 3110 for the source-optimized U221. Every admitted nonhalting configuration satisfies exact quotient-transition equality (3074 and3102 cases respectively). State200 appears only with read0; it is redirected to209. The map fixes state254, and no working state maps to254. Candidate rows equal the source rows with precisely the removed state and remapped destinations. Dense renaming and all three recorded hashes are checked.

For a general proof, let S be the certified finite abstract invariant and f the state map. The initial blank configuration lies in S. Both-bit closure proves by PA induction that every old reachable configuration has abstraction in S. For every such configuration C, the complete tapes and heads are unchanged by f, and the checked transition equation yields step_new(f(C))=f(step_old(C)). Induction on run length therefore proves exact same-time configuration correspondence. Since f neither loses nor creates the distinguished halt state, halting in either machine at any finite time is equivalent. This establishes both directions without an assumption of infinite execution or model consistency. The certificate is finite arithmetic; verification and the induction can be formalized in PA. This is not itself a delivered PA proof-assistant certificate.

Normal and optimized Python both pass. The direct221 dense hash is c40abea4044f003fea96ff63ae89052e53d33aee154da74c156163deab06979e. The composed220 dense hash is 8a3cf3b99feeeea15c0f23d89f660cd44cbc75b30f8f769297eb7b294ac6c0d6. This audit establishes each one-step quotient relative to its exact pinned input table. The source-level optimization preceding the second quotient is a separate dependency.
