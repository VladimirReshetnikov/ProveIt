# Source-based U220: second selector fold

## Exact construction

Start from the independently checked source-based U221 native table, SHA256 49d2675c04d9ec692e7d030b18f2d39b6502a65018c5fea10423f6c68f359a6e. Apply five closed-factor rotations, in this order:

1. States 503/174, right-child rotation, path 1101001001110101011011111110110, factor sizes 27, 56, 20.
2. States 156/503, left-child rotation, path 110100100111010101101111111011, factor sizes 83, 20, 74.
3. States 177/211, left-child rotation, path 11010010011101010110111111011, factor sizes 26, 20, 54.
4. States 52/154, left-child rotation, at paths 1101001001110101010111, 11010010011101010110100111, and 110100100111010101101110001011; factor sizes 26, 26, 28 each.
5. States 211/129, right-child rotation, path 110100100111010101101111110111, factor sizes 20, 28, 26.

For every rotation, each of the three factors has boundary (0,0,false). The inner physical state has exactly one incoming edge from the indicated outer state. Consequently the source reassociation is valid at every represented occurrence. The complete ordered primitive program and ordinal control-flow graph are preserved. The final source still has 3,891 primitive sites, maximum depth 45, and maximum zero run six.

The deterministic builders encode these exact transformations, without a search. Their successful execution does not replace the separate full symbolic runtime audit of the changed instruction-pointer contexts.

## Local all-tape fold proof

After the rotations, state 216 has transitions (0,R,19) and (1,R,61), while state 215 has (0,R,90) and (1,R,61). All entrances to state 216 are 129/read0, 203/read0, and 503/read0. All entrances to state 215 are 129/read1 and 145/read1. Each entrance writes its indicated read bit and moves right. Neither state is initial. Every reachable visit therefore has predecessor tag zero at state 216 and one at state 215.

State 154 has transitions (0,R,12) and (1,R,150). State 12/read0 exactly matches state 216/read0; state 150/read0 exactly matches state 215/read0.

Redirect every entrance to state 215 to state 216, delete state 215, and replace state 216/read0 by (0,L,154). The common read1 transition is unchanged. On read0, the merged state writes the same zero and moves left; state 154 reads and preserves the predecessor tag and returns right; state 12 or 150 then performs the appropriate original read0 transition. The resulting tape, head, and successor control state are exactly those of the old machine after one transition, modulo the state renaming. Only the current and predecessor cells are inspected, and both are restored to the corresponding old values. All other tape cells are arbitrary and unchanged.

The replacement takes three transitions rather than one on read0, and one transition on read1. Every replacement duration is positive and finite. Intermediate states are nonhalting. Each ordinary old transition is simulated either directly or by this finite macro. Conversely the entrance-tag invariant forces every reachable macro to choose the appropriate old branch; there is no extra reachable behavior. Hence finite halting is preserved and reflected, rather than merely one-way simulated. A finite old run corresponds to a finite new run, with at most three new steps per old step for this fold. This local statement is independent of the arithmetic interpretation.

## Checks and scope

The standalone check_selector_fold.py reads the pre-fold and post-fold tables independently of the builders. It checks the entire table correspondence, enumerates all incoming transitions, verifies both selector routes, and checks all four combinations of predecessor tag and current symbol. Its two-cell scope check justifies arbitrary surrounding tape, rather than assuming a finite blank window. Four negative controls corrupt the helper, common branch, excursion, or deleted-state inventory and must fail. Normal and optimized Python checks agree.

The source checker verifies complete prefix-free binary source coverage, primitive order, and equality of the old/new guarded control-flow graphs under two independent resolvers. Builders pin the baseline table/source bytes and retain all checks under optimized Python.

The resulting source-based U220 has 220 working states, 440 transitions, and a separate halt. Native labels retain terminal 254; dense labels are 0 through 219 with terminal 220. Initialization is unchanged. The separate guarded 200-to-209 fold may yield U219, but that requires its independently re-established invariant on this candidate.

No global minimality or new proof-assistant kernel verification is claimed. The all-natural symbolic runtime audit is a distinct gate and must pass before this source-based construction is presented as validated.
