from pathlib import Path
from collections import deque
import json,hashlib
H=Path(__file__).resolve().parent;P=H/'u222.native.tm';raw=P.read_bytes();T={}
for l in raw.decode().splitlines()[1:]:
 q,s,w,d,n=l.split();T[int(q),int(s)]=(int(w),1 if d=='R'else-1,int(n))
W=sorted({q for q,b in T});r=2;k=5;mask=31;seen={(0,0)};queue=deque(seen)
while queue:
 q,x=queue.popleft()
 if q==254:continue
 w,d,n=T[q,x>>r&1];y=x&~(1<<r)|w<<r
 a=y>>1 if d==1 else y<<1&mask;bb=a|1<<(k-1)if d==1 else a|1
 for z in(a,bb):
  if(n,z)not in seen:seen.add((n,z));queue.append((n,z))
S={q:0 for q in W+[254]}
for q,x in seen:S[q]|=1<<x
if any(q==200 and x>>r&1 for q,x in seen):raise ValueError('guard')
if T[200,0]!=T[209,0]:raise ValueError('row')
def ren(q):return 209 if q==200 else q
U={(q,b):(w,d,ren(z))for(q,b),(w,d,z)in T.items()if q!=200}
def encode(T):return('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode()
N=encode(U);qs=sorted({q for q,b in U});ids={q:i for i,q in enumerate(qs)};ids[254]=221;dense={(ids[q],b):(w,d,ids[z])for(q,b),(w,d,z)in U.items()};D=encode(dense)
(H/'u222.native.tm').write_bytes(raw);(H/'u221.native.tm').write_bytes(N);(H/'u221.tm').write_bytes(D)
cert={'radius':r,'center_index':r,'masks':S,'abstract_configurations':len(seen),'input_sha256':hashlib.sha256(raw).hexdigest(),'drop':200,'keep':209,'required_read':0,'native_sha256':hashlib.sha256(N).hexdigest(),'dense_sha256':hashlib.sha256(D).hexdigest(),'working_states':len(qs),'renaming':ids}
(H/'certificate221.json').write_text(json.dumps(cert,indent=2)+'\n');print({k:v for k,v in cert.items()if k not in('masks','renaming')})
