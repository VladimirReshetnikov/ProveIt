"""Independent finite invariant and one-step quotient checker; no search imported."""
from pathlib import Path
import json,hashlib,copy
H=Path(__file__).resolve().parent
PIN='659a03e03186922b8bba6317bc335b6268b6ae4860dbed3829bff9221ff93737'
def require(x,message):
 if not x:raise ValueError(message)
def read(raw):
 lines=raw.decode('ascii').splitlines();require(lines[0]=='#! start 0','initial header');T={}
 for line in lines[1:]:
  row=line.split();require(len(row)==5,'row length');q,b,w,d,n=row;q,b,w,n=map(int,(q,b,w,n));require(b in(0,1)and w in(0,1)and d in('L','R'),'alphabet');require((q,b)not in T,'duplicate');T[q,b]=(w,d,n)
 W={q for q,b in T};require(set(T)=={(q,b)for q in W for b in(0,1)},'totality');return T,W

def verify(C,old,new,dense):
 require(hashlib.sha256(old).hexdigest()==PIN==C['input_sha256'],'input binding')
 T,W=read(old);U,V=read(new);D,A=read(dense)
 require(C['radius']==C['center_index']==2,'window specification')
 S={int(q):v for q,v in C['masks'].items()};require(set(S)==W|{254},'mask domain');require(all(type(m)is int and 0<=m<2**32 for m in S.values()),'masks')
 require(S[0]&1,'initial configuration');checks=0;cases=0
 for q,m in S.items():
  for x in range(32):
   if not(m>>x&1):continue
   cases+=1
   if q==254:continue
   bits=[(x>>i)&1 for i in range(5)];w,d,z=T[q,bits[2]];bits[2]=w
   for outside in(0,1):
    nxt=bits[1:]+[outside]if d=='R'else[outside]+bits[:-1];y=sum(b<<i for i,b in enumerate(nxt));require(S[z]>>y&1,'abstract transition closure');checks+=1
 require(cases==C['abstract_configurations'],'abstract census')
 require(C['drop']==200 and C['keep']==209 and C['required_read']==0,'fold specification')
 require(all(not(S[200]>>x&1)for x in range(32)if(x>>2)&1),'guard')
 f=lambda q:209 if q==200 else q
 require(V==W-{200}and len(V)==219,'native working states');require(254 not in V,'halt distinct')
 for q,m in S.items():
  if q==254:continue
  for x in range(32):
   if m>>x&1:
    b=x>>2&1;w,d,z=T[q,b];require(U[f(q),b]==(w,d,f(z)),'one-step quotient')
 # Also verify unaltered rows off the invariant, so table reconstruction is exact.
 require(U=={(q,b):(w,d,f(z))for(q,b),(w,d,z)in T.items()if q!=200},'exact native reconstruction')
 ids={int(q):v for q,v in C['renaming'].items()};require(ids=={**{q:i for i,q in enumerate(sorted(V))},254:219},'dense bijection');require(A==set(range(219)),'dense state domain')
 require(D=={(ids[q],b):(w,d,ids[z])for(q,b),(w,d,z)in U.items()},'dense table')
 require(hashlib.sha256(new).hexdigest()==C['native_sha256']and hashlib.sha256(dense).hexdigest()==C['dense_sha256'],'output bindings')
 return {'status':'PASS_UNIVERSAL_BLANK_REACHABLE_QUOTIENT','invariant_configurations':cases,'closure_successors':checks,'working_states':219,'input_sha256':PIN,'native_sha256':C['native_sha256'],'dense_sha256':C['dense_sha256']}
if __name__=='__main__':
 C=json.loads((H/'certificate219.json').read_text());old=(H/'input220.native.tm').read_bytes();new=(H/'u219.native.tm').read_bytes();dense=(H/'u219.tm').read_bytes();out=verify(C,old,new,dense);negative=[]
 for kind in('missing initial','false guard','wrong candidate','wrong dense'):
  c=copy.deepcopy(C);n=new;d=dense
  if kind=='missing initial':c['masks']['0']&=~1
  elif kind=='false guard':
   c['masks']['200']|=1<<4;c['abstract_configurations']+=1
  elif kind=='wrong candidate':n=n.replace(b'209 0 0 R 157',b'209 0 1 R 157')
  else:d=d.replace(b'#! start 0',b'#! start 1')
  try:verify(c,old,n,d)
  except ValueError as e:negative.append({'control':kind,'status':'REJECTED','reason':str(e)})
  else:raise ValueError('negative control accepted: '+kind)
 out['negative_controls']=negative;(H/'check219_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
