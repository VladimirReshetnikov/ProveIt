#!/usr/bin/env python3
"""Offline replay; sealed release files are never altered. Python standard library only."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,stat,subprocess,sys,tempfile,time,zipfile
ROOT=Path(__file__).resolve().parent

def need(x,m):
 if not x:raise ValueError(m)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(root):
 manifest=json.loads((root/'manifest.json').read_text());need(type(manifest)is dict and bool(manifest),'empty manifest')
 actual={str(p.relative_to(root))for p in root.rglob('*')if p.is_file()and p!=root/'manifest.json'}
 need(actual==set(manifest),'manifest file inventory mismatch')
 for name,h in manifest.items():
  p=Path(name);need(not p.is_absolute()and '..'not in p.parts,'unsafe manifest path')
  need(digest(root/p)==h,'integrity failure: '+name)
 return len(manifest)
def negative_integrity(tmp):
 controls=[]
 for kind in ['changed','missing','extra','empty manifest']:
  d=tmp/kind;d.mkdir();(d/'a').write_text('original');(d/'manifest.json').write_text(json.dumps({'a':digest(d/'a')}))
  if kind=='changed':(d/'a').write_text('changed')
  elif kind=='missing':(d/'a').unlink()
  elif kind=='extra':(d/'b').write_text('extra')
  else:(d/'manifest.json').write_text('{}')
  try:verify(d)
  except ValueError:controls.append({'mutation':kind,'rejected':True})
  else:raise ValueError('integrity mutation accepted')
 return controls

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--report',type=Path);ap.add_argument('--quick',action='store_true',help='omit inherited full runtime and three fresh full runtime checks');a=ap.parse_args()
 sealed=verify(ROOT);stages=[];start=time.monotonic()
 with tempfile.TemporaryDirectory(prefix='u219-replay-')as name:
  tmp=Path(name);work=tmp/'work';shutil.copytree(ROOT,work);up=tmp/'upstream';up.mkdir()
  archive=work/'upstream/U222_ConU_2026-10-28.zip'
  need(digest(archive)=='d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652','primary archive identity')
  with zipfile.ZipFile(archive)as z:
   for info in z.infolist():
    p=Path(info.filename);need(not p.is_absolute()and '..'not in p.parts,'unsafe archive path')
    need(not stat.S_ISLNK(info.external_attr>>16),'archive symlink')
   z.extractall(up)
  base=up/'u222_consistency_machine'
  need((base/'machine/u.native.tm').read_bytes()==(work/'machine/direct221/u222.native.tm').read_bytes(),'primary table binding')
  need((base/'machine/sites.json').read_bytes()==(work/'machine/sites222.json').read_bytes(),'primary source binding')
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
  def run(label,script,args=(),optimized=False):
   command=[sys.executable,'-B']+(['-O']if optimized else[])+[str(script),*map(str,args)]
   result=subprocess.run(command,cwd=work,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   print(label+': '+('PASS'if result.returncode==0 else'FAIL'),flush=True)
   stages.append({'name':label,'status':'PASS'if result.returncode==0 else'FAIL','output':result.stdout})
   need(result.returncode==0,label+' failed:\n'+result.stdout)
  fixed=[('reconstruction','code/check_reconstruction.py',[]),
   ('source221 CFG','code/check_source.py',['machine/sites222.json','machine/source221/sites.json']),
   ('source220 CFG','code/check_source.py',['machine/sites222.json','machine/source220/sites.json']),
   ('source negative controls','code/check_source_negative.py',['code/check_source.py','machine/sites222.json','machine/source220/sites.json']),
   ('first selector fold','code/check_selector_fold.py',['machine/source221/rotated222.tm','machine/source221/u221.native.tm','145','134','507','0']),
   ('second selector fold','code/check_selector_fold.py',['machine/source220/rotated221.tm','machine/source220/u220.native.tm','216','215','154','0']),
   ('direct221 quotient','machine/direct221/check221.py',[]),
   ('composed220 quotient','machine/final220/check220.py',[]),
   ('final219 quotient','machine/final219/check219.py',[]),
   ('independent quotients','code/check_quotients_independent.py',[]),
   ('structural guards','code/check_structural_guard.py',['machine/direct221/u222.native.tm','machine/final220/input221.native.tm','machine/final219/input220.native.tm','--output','evidence/replay_structural.json']),
   ('independent second fold and CFG','code/check_source220_independent.py',[])]
  for opt in (False,True):
   for label,script,args in fixed:run(label+(' optimized'if opt else' normal'),work/script,args,opt)
  run('runtime negative controls',work/'code/check_negative.py',['--table','machine/source220/u220.native.tm','--sites','machine/source220/sites.json','--output','evidence/replay_negative.json'])
  for label,table,sites in [('baseline222','machine/direct221/u222.native.tm','machine/sites222.json'),('source221','machine/source221/u221.native.tm','machine/source221/sites.json'),('source220','machine/source220/u220.native.tm','machine/source220/sites.json'),('final219','machine/final219/u219.native.tm','machine/source220/sites.json')]:
   run(label+' exact startup',work/'code/check_startup.py',['--table',table,'--sites',sites,'--startup',base/'evidence/startup.json','--output','evidence/replay_startup_'+label+'.json'])
  run('inherited U222 replay',base/'reproduce.py',([]if a.quick else['--full']))
  if not a.quick:
   for label,table,sites in [('baseline222','machine/direct221/u222.native.tm','machine/sites222.json'),('source221','machine/source221/u221.native.tm','machine/source221/sites.json'),('source220','machine/source220/u220.native.tm','machine/source220/sites.json')]:
    run(label+' universal runtime',work/'code/check_independent.py',['--table',table,'--sites',sites,'--output','evidence/replay_runtime_'+label+'.json'])
  controls=negative_integrity(tmp)
 need(verify(ROOT)==sealed,'release changed')
 receipt={'status':'PASS','scope':'quick'if a.quick else'full','sealed_files':sealed,'stages':stages,'integrity_negative_controls':controls,'seconds':time.monotonic()-start,'final_states':219,'final_sha256':digest(ROOT/'machine/final.tm')}
 if a.report:a.report.write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items()if k not in('stages','integrity_negative_controls')},sort_keys=True))
if __name__=='__main__':main()
