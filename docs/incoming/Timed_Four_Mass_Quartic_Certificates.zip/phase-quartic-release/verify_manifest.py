#!/usr/bin/env python3
"""Verify every regular release payload and reject extra files or symlinks."""
from pathlib import Path, PurePosixPath
import hashlib
import re

root = Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS'
expected = {}
for line in manifest.read_text(encoding='ascii').splitlines():
    digest, name = line.split('  ', 1)
    path = PurePosixPath(name)
    if not re.fullmatch('[0-9a-f]{64}', digest):
        raise SystemExit('Invalid digest')
    if path.is_absolute() or '..' in path.parts or str(path) != name or name in expected:
        raise SystemExit('Unsafe or duplicate manifest path')
    expected[name] = digest
actual = set()
for file in root.rglob('*'):
    if file.is_symlink():
        raise SystemExit('Symlink rejected: ' + file.relative_to(root).as_posix())
    if file.is_file() and file != manifest:
        actual.add(file.relative_to(root).as_posix())
if actual != set(expected):
    raise SystemExit('Manifest inventory mismatch: ' + str(sorted(actual ^ set(expected))))
for name, digest in expected.items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        raise SystemExit('Digest mismatch: ' + name)
print('Manifest PASS: ' + str(len(expected)) + ' files')
