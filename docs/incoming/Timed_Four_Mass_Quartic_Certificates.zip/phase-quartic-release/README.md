# Canonical quartic certificates for timed four mass orbits

Research addendum 13, 3 October 2026

The standalone PDF and editable LaTeX prove a complete fixed-input timed-orbit certificate, conditional on the effective normal form of the separate companion report 12, *Four mass units and exact reachability*. Both a product-gated quartic and a literal sum-of-squares quartic are costed exactly. The explicit binary shuttle has a four-natural-witness, seven-square SOS certificate, uniformly in the natural initial gap parameter x = d - 7. The report retains the eight-witness generic baseline and also proves a generic SOS selector-elimination refinement.

## Start here

- `fixed-input-timed-quartics.pdf`: the report
- `fixed-input-timed-quartics.tex`: standalone source with bibliography
- `code/phase/exact_phase_quartic.py`: exact chart compiler and binary specializations
- `code/phase/compact_binary_quartic.py`: four-witness binary specialization
- `code/phase/selector_elimination.py`: generic SOS-only removal of the last selector
- `code/phase/binary-uniform-four-witness-sos.json`: expanded compact uniform-gap certificate
- `code/phase/binary-uniform-seven-witness-sos.json`: expanded selector-eliminated uniform-gap baseline
- `code/phase/binary-d7-full-orbit-quartics.json`: fixed-gap and uniform-gap expanded polynomials, both gate formats
- `verification/independent-audit.md`: mathematical review, correction, and verification scope
- `verification/source-freeze.json`: exact preserved code and fixture provenance
- `SHA256SUMS`: release payload integrity manifest

The complete report 12 normal-form proof is an explicitly identified mathematical dependency, not duplicated in this addendum. No prior report or release was edited. Primary literature is linked in the bibliography; copyrighted source PDFs and working notes are not included.

## Reproduce the exact checks

Use Python 3.10 or newer and a POSIX shell. No third-party Python package or network access is needed.

    ./run-tests.sh

This verifies every file against the manifest, runs the binary-rule suite, runs the baseline quartic suite and both refinement suites, and verifies the manifest again. The eight generated JSON files must match the distributed bytes exactly. Python bytecode creation is disabled for the replay. The retained directory layout lets the quartic tests import the component step function from `code/test_binary_expanding_shuttle.py`; there are no out-of-bundle imports.

The binary suite checks all 8192 local conservation-potential identities and its larger trajectory regressions. The quartic suite checks both gate formats, complete natural-witness cubes, rational coefficients, strict sorting, original-frame shifts, canonical external signed pairs, uniform-gap specialization, invalid inputs, immutability, and a false witness admitted when gates are removed. Finite tests supplement the mathematical arguments and do not prove the imported normal form or decide global chart injectivity.

## Rebuild the PDF

Use a TeX Live installation containing pdfLaTeX, Latin Modern, AMS packages, microtype, booktabs, enumitem, needspace, xcolor, and hyperref.

    ./build.sh

The build runs twice for cross-references, checks for overfull boxes and unresolved references, and keeps intermediate files in a temporary directory. A minimal TeX Live installation may need the listed packages installed first. The supplied PDF was rendered and every page visually inspected; a rebuilt PDF should be inspected again after edits.

## Exact certificate data format

The JSON `forms` map contains `products` and `sos` certificates at fixed gap d = 7. `uniform_gap_forms` contains the corresponding certificates with natural external x = d - 7. Each term has an integer coefficient and a list of nonnegative exponents. Variable order is the listed external coordinates followed by the listed witnesses. Coefficients are fully expanded, not decimal approximations.

The generic compiler deliberately treats chart disjointness and parameter uniqueness as caller-proved hypotheses. It checks syntax, arities, exact coefficient types, and degrees. The report supplies the missing semantic proof for the stated orbit charts.

## Scope

The general result fixes both the CA and the initial configuration. The generic certificates use natural witnesses. The generic SOS compiler makes no real or rational witness exactness claim. For the four-witness binary specialization, integer external coordinates force real zeros to have integer witnesses, so nonnegative real witnesses give the same singleton fibers as natural witnesses. Unrestricted real witnesses can give spurious zeros. Omitting external time can lose uniqueness. The four-witness complete-orbit specialization and eight-witness baseline differ from the companion report's one-witness return-hit relation. No general uniform-input arity bound, MRDP single-fold result, novelty claim, or current literature-status claim is made.
