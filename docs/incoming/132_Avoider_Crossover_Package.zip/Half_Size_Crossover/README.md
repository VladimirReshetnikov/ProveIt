# Exact half size crossover

Main result: n P(M_n <= floor(n/2+t sqrt(n))) converges locally uniformly to 6+12 max(t,0)/sqrt(pi). The first sub-half-size phase also has the exact equivalent I_3(theta)/(2 pi n), for 1/3<theta<=1/2.

## Files

- half_size_crossover.pdf: full manuscript
- half_size_crossover.tex: editable mathematical source
- model.py: exact endpoint model from the credited incoming Polynomial Rarity package
- verify.py: independent finite Catalan generation, parser checks, word identities, and exact-count table
- finite_checks.csv and verification.json: recorded finite outputs
- SOURCES.md: source boundary, attribution, and novelty scope
- build.sh: standard LaTeX reproduction

## Reproduce

Run `python verify.py` for the default exact checks through n=128 in the table. Run `python verify.py --max-n 256` for the longer table. Python 3.11+ and its standard library suffice. The larger run can take several minutes.

Run `bash build.sh` in a standard LaTeX installation containing the packages named by the TeX source. This rebuilds the PDF. The PDF was compiled and every page visually checked in the preparation environment.

## Status

The manuscript gives ordinary mathematical proofs with explicit error bounds and a derivation of all finite interfaces used. It has been checked by direct derivation, but has not been externally refereed or formalized in Lean or Rocq. The finite tests do not prove its analytic limits. Decimal table entries are rounded, not interval-certified. Novelty is asserted only relative to the inspected report and incoming addition07 manuscript, not as exhaustive publication priority.

The work is a separate research contribution. No repository file was modified or committed during its preparation.
