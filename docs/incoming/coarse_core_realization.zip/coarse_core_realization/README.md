# Every Countable Turing Ideal Is a Coarse Core

**Layered realization, exact pairs, and order embeddings with fixed common information**

Research manuscript prepared for Vladimir Reshetnikov, 28 September 2026.

## Files

- `article.pdf`: the complete 22-page article.
- `article.tex`: standalone LaTeX source, with an internal bibliography.
- `proof_audit.md`: proof dependencies, quantifier checks, and limits of verification.
- `sources.md`: the pinned repository snapshot and the primary literature consulted.
- `checks/check_finite.py`: reproducible finite arithmetic/combinatorial checks.
- `checks/results.json`: the actual output of those checks.
- `build.sh`: PDF build command.

No font files, third-party papers, or repository copies are included.

## Principal results

Theorem 1.1 / Section 4: the possible coarse cores are exactly the countable
Turing ideals. The carrier places robust codes for a cofinal ideal presentation
on positive-density columns with vanishing tail density.

Theorem 5.4: a rising-ideal version of protected-region fusion constructs a
perfect family of pairwise exact descriptions. This provides an independent proof
of core realization, without using the published cone-avoiding compactness theorem.

Theorem 6.1: adjoining a dyadic code R(B) to the carrier preserves its core while
intersecting its spectrum with the jump cone determined by B.

Theorem 7.1: on the parameter cone above Z', where Z is a presentation oracle,
the construction is an upper-semilattice embedding into both the uniform and
nonuniform coarse degrees, all with the same core.

Theorem 8.2: every countable Turing ideal is the core of continuum many distinct
coarse degrees having no least Turing-degree representative.

Theorem 9.1 and Proposition 9.3: quantitative recovery bounds and explicit
presentation sensitivity, respectively.

## Research scope and status

The core-realization question is explicitly left unsettled in the inspected
ProveIt synthesis. The results here address that question and strengthen the
fixed-core structural picture. Published priority in the broader literature has
not been established. The manuscript is not independently refereed or Lean-checked.

The full classification of description spectra and the absence of *minimal*
elements in a spectrum are not claimed. The paper distinguishes minimal from least,
individual reductions from a uniform infinite join, and a computable splitting
system from an oracle computing all of its uncountably many paths.

## Build

Use a TeX installation with `latexmk`, pdfLaTeX, `newpx`, `newtx`, and the standard
packages named in the preamble (including `mathtools`, `microtype`, `titlesec`,
`fancyhdr`, `enumitem`, `tabularx`, `xurl`, and `hyperref`).

```sh
./build.sh
```

Equivalently:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The bibliography is included directly; no `.bib` download or separate bibliography
processor is required. The PDF was compiled with pdfTeX 1.40.26. Build timestamps
may make binary output differ even when the typeset content is identical.

## Reproduce finite checks

Python 3.10 or later; standard library only:

```sh
python3 checks/check_finite.py --output checks/results.json
```

The supplied run passed all 8 groups, totaling 616,836 finite cases. These are
finite bookkeeping checks, **not formal verification of the infinite theorems**.

## Repository snapshot

`VladimirReshetnikov/ProveIt` at
`1a1396d4d3a2ac6812692df520517d86ba3a4785`.

The repository itself was read, not modified. See `sources.md` for precise paths.
