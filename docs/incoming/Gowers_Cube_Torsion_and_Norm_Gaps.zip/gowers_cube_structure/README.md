# Prime torsion and norm gaps in Gowers's cube framework

This research package contains a self-contained article on the arithmetic and analytic structure of Boolean cube moments in Gowers's proof of Szemerédi's theorem. It is prepared for integration into the ProveIt repository. The proofs are in [gowers_cube_structure.tex](gowers_cube_structure.tex), with a compiled reading copy in [gowers_cube_structure.pdf](gowers_cube_structure.pdf). Exact verification programs and their reports accompany the article.

The comparison baseline is the repository at commit [`12da356730b12cb73c276a258aaadf3223e3662b`](https://github.com/VladimirReshetnikov/ProveIt/tree/12da356730b12cb73c276a258aaadf3223e3662b), including the merged reports 01–10 and the separately archived moment and weighted-spectrum manuscripts identified in [source_ledger.json](source_ledger.json).

## Main results

### Exact onset of prime torsion

For a Boolean support, form the integer matrix whose columns are its vertices with an additional leading coordinate equal to one. Its row-lattice quotient records the arithmetic constraints in the Fourier expansion of the associated cube moment. The article distinguishes two minima:

- `h(p)`: the least number of affinely independent Boolean vertices admitting prime-`p` torsion and a mod-`p` relation with no zero coordinate;
- `h_cyc(m)`: for any integer `m>=2`, the least number of affinely independent Boolean vertices with row-lattice quotient exactly the cyclic group of order `m` and a faithful coordinate vector with no zero entry.

Let `D_div(p)` be the least order of a nonsingular square zero-one matrix with determinant divisible by `p`. The article proves

\[
h(p)=D_{\mathrm{div}}(p)+1.
\]

This equivalence includes the full-support condition on the relation. It also identifies the minimum rational augmented rank for prime-`p` Smith torsion among arbitrary Boolean supports and the minimum ambient cube dimension, which is `h(p)-1`. These statements concern the onset of Smith torsion; other forms of characteristic-dependent cancellation must be considered separately.

Exact certificates give

| Prime `p` | 2 | 3 | 5 | 7 | 11 | 13 | 17 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `h(p)` | 4 | 5 | 6 | 7 | 8 | 8 | 8 |

The values through `p=5` are part of the prior local cube theory. The certificates at `p=7,11,13,17` sharpen that comparison. In each displayed case a determinant of absolute value `p` also realizes the isolated cyclic quotient at the same support size.

### Efficient cyclic realizations and asymptotics

The article reconstructs a determinant construction from unimodular anti-Hadamard matrices, with Alon–Vu's published theorem as its deep input and Shitov's determinant-range construction as a direct antecedent. For all sufficiently large `n`, every integer

\[
1\le q\le\left\lfloor\exp\!\left(\tfrac12 n\log n-n\log\log n-4n\right)\right\rfloor
\]

is the determinant of an `n` by `n` zero-one matrix with a unit cofactor and cyclic cokernel. A refined parameter choice replaces `4` by any constant greater than

\[
C_* = 2\log 2+\tfrac12\log\!\frac{3}{2\log 2}+\tfrac12
      =2.272283375464805\ldots.
\]

The support transfer gives

\[
h(p)\sim h_{\mathrm{cyc}}(p)\sim\frac{2\log p}{\log\log p},
\qquad
h_{\mathrm{cyc}}(m)\sim\frac{2\log m}{\log\log m},
\]

where the first limit runs through primes and the second through all integers.

The article includes explicit eventual bounds, their inversion, and the remaining gap in the second-order term. A separate elementary construction gives a positive Fourier detector for every cyclic modulus `q` using `2 ceil(log2 q)+2` Boolean vertices. That construction does not require the asymptotic anti-Hadamard input.

### The exact asymptotic cost of positivity

For an affinely independent Boolean configuration with cyclic quotient of order `m` and a faithful full-support coordinate vector `c`, the article characterizes when its Fourier moment is nonnegative for every real centered function on every finite abelian group: **the multiset of coordinates of `c` must split into inverse pairs**. A self-inverse coordinate must occur with even multiplicity. This equivalence holds for composite and even `m` as well as primes; testing all real centered functions on the single group `Z/mZ` already suffices.

Let `h_pos(m)` be the minimum support size under this universal positivity requirement. A paired configuration with `2t` vertices yields a nonsingular ternary matrix with determinant divisible by `m`, so `m <= t^(t/2)`. Conversely, a cyclic presentation can be paired by doubling its support. These facts and the cyclic realization theorem give

\[
h_{\mathrm{pos}}(m)\sim\frac{4\log m}{\log\log m},
\qquad
\frac{h_{\mathrm{pos}}(m)}{h_{\mathrm{cyc}}(m)}\longrightarrow2.
\]

Thus universal positivity has an exact asymptotic factor-two cost in vertices. The first values are `h_pos(2),...,h_pos(8) = 4,6,6,8,8,8,8`. The sharp norm constant and the finer second-order support terms remain open.

### A stronger odd-order norm gap

For every finite abelian group of odd order and every real-valued centered function `f`,

\[
\|f\|_{U^2}^{4}\le\frac23\|f\|_{U^4}^{4}.
\]

The same inequality holds with `U^4` replaced by `U^d` for any `d>=4`. Define `c_4^odd` as the supremum of `||f||_(U^2)^4 / ||f||_(U^4)^4` over these groups and nonzero functions. An explicit two-harmonic example on the cyclic group of order 29 proves

\[
\frac{4804}{5465198316262956^{1/4}}
 =0.558729390985151710\ldots
 \le c_4^{\mathrm{odd}}\le\frac23.
\]

This example also shows that a single Fourier pair is not globally extremal. The upper bound combines a positive pair-mass moment expansion, an exact fourth dual function, and positive third- and fifth-harmonic terms. Small odd character orders are included in the proof. The earlier incoming moment manuscript already proves the upper bound `(8/35)^(1/4)=0.6914415...`; the claimed improvement here is to `2/3`. The article also gives a general pair-mass profile and further bounds in dimensions five through eight.

### Transport-dependent rigidity

An appendix proves the sharp defect threshold

\[
\delta<\frac{1}{2+(2k-2)\kappa}
\]

in the stated general finite-fibre transport model. The hypotheses and sharpness example are part of that model. No replacement with arbitrary `kappa` at Gowers's original prime-order interface is asserted without verifying the additional transport assumptions there.

## Status and attribution

This is an unrefereed research manuscript containing complete mathematical arguments and reproducible finite certificates. The novelty claims are bounded by the named repository snapshot and the literature discussed in the article. The determinant method builds directly on Alon–Vu and Shitov; the odd-order norm comparison starts from the prior local cube theory and the stronger incoming moment report. Known background results and previous local refinements are credited separately from the new conclusions.

No new Lean formalization, independently checked proof-assistant certificate, improvement of the global quantitative Szemerédi bound, or solution of the full sharp norm-constant problem is claimed. The source ledger records an existing Lean companion to Gowers's Lemma 3.10 as repository context; it is not a formal verification of the new results. The research questions in the article distinguish resolved local questions from questions left open.

## Contents

| Path | Purpose |
| --- | --- |
| `gowers_cube_structure.tex` | Complete article, including proofs, bibliography, and further research questions |
| `gowers_cube_structure.pdf` | Compiled article |
| `code/verify_torsion.py` | Exact small-prime, nonexistence, cyclic-detector, and spatial-moment checks |
| `code/verify_determinant_gadgets.py` | Exact determinant, row-encoding, Smith-form, and unit-cofactor checks |
| `code/verify_odd_fourth_gap.py` | Exact dual counts, rational inequalities, harmonic polynomial, and norm certificates |
| `data/` | Explicit matrices, negative certificates, and verification reports |
| `source_ledger.json` | Pinned source paths, blob identifiers, archive hashes, references, and claim status |
| `requirements.txt` | Python dependency used by the determinant verifier |
| `Makefile` | PDF build and verification commands |
| `SHA256SUMS` | File integrity manifest for the delivered package |

The negative torsion certificates cover all projective residue-multiset classes required for the seven-vertex exclusions: 104 classes modulo 11 and 204 classes modulo 13. The verifier checks the rational obstruction against every relevant Boolean mask for each class. Supplied rank annotations are not accepted as proof by themselves.

## Build the article

Use a standard TeX installation providing pdfLaTeX and the packages named in the source. No external source downloads, shell escape, or bibliography service are required.

```sh
make pdf
```

The build uses `latexmk` if available and otherwise runs `pdflatex` twice. The equivalent manual build is:

```sh
pdflatex -interaction=nonstopmode -halt-on-error gowers_cube_structure.tex
pdflatex -interaction=nonstopmode -halt-on-error gowers_cube_structure.tex
```

`make clean` removes auxiliary TeX files and preserves the article PDF, source, and certificates.

## Reproduce the exact checks

Use Python 3.10 or later. The programs were exercised with Python 3.12.14. The torsion and norm programs use the Python standard library; the determinant program uses SymPy 1.14.0. Install that dependency if needed:

```sh
python3 -m pip install -r requirements.txt
```

Then run:

```sh
make verify
```

The individual commands are:

```sh
python3 code/verify_torsion.py
python3 code/verify_determinant_gadgets.py > data/determinant_gadget_verification.json
python3 code/verify_odd_fourth_gap.py
```

Do not pass Python's `-O` option: exact assertions are part of the verification. All arithmetic decisions underlying the finite certificates use integers or rational numbers. Decimal displays are supplementary. The verification programs require no network access once their dependencies are installed.

The shipped negative torsion certificates can be rebuilt from their complete finite search spaces with:

```sh
make regenerate-torsion
```

The determinant suite checks 144 row encodings and 92 composition instances. The torsion suite checks the small-prime matrices, both nonexistence certificates, 36 cyclic-detector moduli, and direct spatial moments at moduli two and three. The norm suite recomputes the dual-function counts, the rational `2/3` certificate, the two-harmonic polynomial, and the exceptional order-three calculation.

These checks support concrete finite identities and certificates. The all-parameter determinant, transfer, transport, and norm theorems rely on the proofs in the article; finite testing alone is not presented as a proof of them.

## Repository integration

A suggested destination is:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/prime-torsion-norm-gaps/
```

Keep `code/` and `data/` under the article directory so the verification programs find their certificates. The package is self-contained for reading and building. Source archives are identified and cited, rather than duplicated into the package. Integration into a merged report should preserve the distinctions among `h(p)`, `h_cyc(m)`, and `h_pos(m)`, the finite-fibre scope of the transport appendix, and the explicit status of the open sharp-constant and second-order questions.
