# Sharp Three-Term Progression Bounds with Torsion

**Exact constants, spectral decomposition, and optimal stability exponents**  
Research contribution for ProveIt, 7 October 2026.

The main deliverable is `article.pdf` (20 pages); `article.tex` is its complete,
self-contained LaTeX source. All general theorems have deductive proofs in the
article. The numerical code supplements those proofs, rather than replacing them.

## Mathematical contents

For finite abelian groups G,D and arbitrary homomorphisms A,B:D -> G, define

    Lambda(f0,f1,f2) = E_{x in G,d in D} f0(x) f1(x+Ad) f2(x+Bd).
    u = [G:A(D)], v = [G:B(D)], ell = [G:A(D)+B(D)], k = uv/ell.

The exact coefficient of ||hat f0||_p ||f1||_2 ||f2||_2 is

    C_p = ell^(1-1/p)                     for 1 <= p <= 2,
    C_p = sqrt(u*v) * k^(-1/p)            for 2 <= p <= infinity.

In particular C_4 = (u*v*ell)^(1/4), and ||hat f0||_4 = ||f0||_{U^2}.
All physical-space norms and averages are normalized; Fourier sequence norms
use counting measure. Subgroup indicator triples attain the sharp constants.

The article also proves a complete singular-spectrum decomposition, classifies
all normalized complex extremizers for 2 < p < infinity, and proves the following
stability statement at p=4. A normalized (1-epsilon)-extremizing triple, with
epsilon <= 1/64, admits an exact normalized extremizing triple within
4*epsilon^(1/4) in the marked U^2 norm and 7*sqrt(epsilon) in each of the other
two L^2 norms. Both exponents are optimal, even on the fixed group Z/5Z.

Ordinary progressions have explicit endpoint and middle control seminorms.
A three-set counting theorem uses the correct quotient main term for groups
with 2-torsion, with within-coset variance factors and a correction for repeated
vertices. Section 10 develops eight further research directions.

## Files

- `article.tex`, `article.pdf`: manuscript and compiled article.
- `code/verify.py`: exact finite fiber/witness checks and independent numerical
  Fourier, full-spectrum, stability-repair, and counting diagnostics.
- `data/verification.json`: output of the full packaged run, including every
  exact test system and the individual near-extremizer diagnostics.
- `data/source_audit.json`, `SOURCE_AUDIT.md`: pinned sources and attribution.
- `data/validation.json`: build, test, and PDF inspection record.
- `INTEGRATION.md`: repository destination, normalization, and theorem interfaces.
- `Makefile`, `requirements.txt`: build and verification commands.
- `SHA256SUMS`: checksums of package files, excluding the checksum file itself.

## Build and verify

A standard LaTeX installation with pdfLaTeX and latexmk is sufficient. The
bibliography is embedded; no BibTeX run or network access is needed.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
python -m pip install -r requirements.txt
python code/verify.py
```

Alternatively use `make pdf`, `make verify`, or `make quick`. The verification
code requires Python 3.10 or newer and NumPy. The supplied run used Python 3.13.5
and NumPy 2.3.5. Run without `-O` or `-OO`: the verifier deliberately refuses
execution when assertions are disabled. The default output location is resolved
relative to the script, so the command need not be run from the package root.

For a smaller diagnostic run without overwriting the full report:

```sh
python code/verify.py --quick --output data/verification_quick.json
```

The full packaged run passed 750 exact system checks, numerical checks on 193
systems, 140 stability cases, and 108 indicator counting cases. Floating-point
last digits can vary by platform. A numerical singular-value calculation is not
a proof certificate for a general theorem.

## Scope and attribution

The general sharp-constant principle is already part of Christ's finite-group
Holder--Brascamp--Lieb theorem; this paper gives a direct closed-form calculation
for the present family, followed by structural and stability proofs. The familiar
ordinary-progression endpoint factor |G[2]|^(1/4) also occurs in prior project
work. These are explicitly credited, not presented as new general principles.

The structural and stability formulations are proved here, but an exhaustive
literature-priority determination has not been made. This is a research manuscript
for review, not a claim of peer-reviewed priority. No improved global Szemeredi
bound is claimed. The repair theorem concerns complex normalized functions and
does not assert preservation of indicators, real-valuedness, or a pointwise bound.

No Lean implementation or Lean build is supplied. The remote ProveIt repository
was read but not modified. See `INTEGRATION.md` before merging into another paper.
