#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p results build
python3 code/enumerate_rows.py > results/exact-replay.txt
python3 code/check_algebra.py > results/algebra-replay.txt
python3 code/numerics.py > results/numerical-replay.txt
bash build_pdf.sh
printf 'Exact enumeration, symbolic checks, high-precision checks, and PDF rebuild passed.\n'
