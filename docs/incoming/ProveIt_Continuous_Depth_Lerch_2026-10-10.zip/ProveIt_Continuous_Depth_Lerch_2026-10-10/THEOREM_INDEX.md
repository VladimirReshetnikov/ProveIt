# Theorem and claim map

Labels below are stable even if pagination changes.

| Label | Result | Status and relation to prior work |
|---|---|---|
| cdl:thm:kernel | Explicit complex-depth Gamma kernel and convolution semigroup | Proved; classical Ramanujan/Meixner input, normalized for the source problem |
| cdl:thm:spectral | Joint holomorphy and entire spectral extension | Proved continuation on Re(depth), Re(shift)>0 |
| cdl:thm:addition | Addition of both depths and spectral orders; all mixed jets | Proved continuous-depth extension |
| cdl:thm:shift | Finite continuous-depth two-step and arbitrary even-step shifts | Proved; integer central-factorial formulas recovered |
| cdl:prop:Z | Entire centered Pochhammer-Hurwitz family, negative values | Proved by Mellin subtraction |
| cdl:thm:reflection | Centered Fourier–Mellin reflection, with explicit resonances | Proved, using a justified Abel regulator |
| cdl:thm:oddZ | All odd centered Z-values as Gamma/Hurwitz coefficients | Proved beta-integral consequence |
| cdl:cor:polylog | Continuous Gamma-weighted odd-polylogarithm integrals | Proved exact family |
| cdl:thm:harmonicmaster | All-order absolutely convergent harmonic Gamma-quotient master | Proved; coefficient computations terminate; priority not claimed globally |
| cdl:eq:harmonicquadratic | Explicit quadratic harmonic identity | Proved master coefficient |
| cdl:eq:harmoniccubic | Explicit cubic harmonic identity | Proved master coefficient |
| cdl:thm:moments | Every mixed logarithmic moment by finite recurrence | Proved continuous-depth algorithm |
| cdl:thm:stieltjes | Continuous-split Stieltjes products | Proved extension; symmetric integer case attributed to preceding report |
| cdl:cor:Jmoments | All first and second logarithmic Stieltjes moments | Proved including asymmetric coefficients |
| cdl:thm:depthjets | Polygamma Gamma convolutions and balanced depth null identities | Proved by holomorphic parameter differentiation |
| cdl:thm:primitives | All shift derivatives and anchored primitives, resonances removed | Proved; includes argument primitives after stated weight |
| cdl:thm:obstruction | Noninteger-depth/log-depth obstruction in the named meromorphic transform class | Proved local monodromy theorem; no arithmetic-independence conclusion |

## Explicitly not proved or claimed

- Full continuation through zero or negative real depth as ordinary functions.
- Resolution of Gaussian S6 or S8 candidates.
- General finite-zeta reduction of arbitrary alternating Euler sums.
- Historical novelty of the Ramanujan transform, Meixner semigroup, or all special cases.
- Independent arithmetic status of isolated central values.
- Exhaustive audit of all manuscript chapters or incoming archives.
- Formal proof-assistant verification or rigorous numerical enclosures.
