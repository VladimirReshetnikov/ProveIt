# Sharp Local Refinements of Gowers's Szemerédi Argument

**Density transfer, carry-pattern entropy, and formalization interfaces**  
Research report prepared for Vladimir Reshetnikov, 6 October 2026.

## Start here

- `gowers_refinements.pdf`: the 31-page article, with complete local proofs,
  explicit hypotheses, equality constructions, source references, a Lean
  integration plan, and ten further research questions.
- `gowers_refinements.tex`: self-contained LaTeX source; the bibliography is
  included in the file, so no BibTeX database or downloaded paper is needed.
- `certificates/carry.json`: exact rational certificates for the exhaustive
  carry-pattern counts C_1 = 1, C_2 = 2, C_3 = 10, C_4 = 154.
- `code/carry_certificates.py`: numerical certificate generator and exact
  rational verifier. Verification itself needs only the Python standard library.
- `code/check_refinements.py`: symbolic identities, deterministic stress tests,
  concrete progression partitions, and the article's numerical tables.
- `code/check_certificate_rejection.py`: rejection tests for corrupted certificates.
- `results/`: verification output, numerical results, and the tested environment.

## Mathematical results

The article proves a sharp finite weighted correlation-to-density-tail theorem,
including explicit extremizers. It derives an occupied-mass exceptional-set
estimate, the optimal forced maximum cell density, and a sharper Fourier
density increment on an integer-exact progression partition. The hypotheses
allow bounded weights and arbitrary real frequencies, and do not require a
prime modulus.

On the counting side it proves the exact coefficient-range identity

    #floor patterns in product_i (-r_i,r_i) = product_i (2 r_i) * C_k

for positive integral ranges, with

    2^floor(k^2/4) <= C_k <= sum_{j=0}^k binomial(H_k,j),
    H_k = (k-2) * 2^(k-1) + 1.

A proved reduction to classical linear threshold-function enumeration yields
log_2 C_k ~ k^2. An affine translation-orbit bound is independent of the
modulus. A polynomial-feature generalization gives matching leading entropy
for fixed degree, using the explicitly cited Baldi–Vershynin theorem.

## Verification

From this directory:

```sh
python code/carry_certificates.py verify certificates/carry.json
python code/check_certificate_rejection.py
```

These commands use only the standard library. The positive verifier checks
all rational inequalities and dual identities, both branches of every feasible
nonterminal node, the absence of unreachable records, and the leaf counts.
It does not trust a floating-point optimizer or use numerical tolerances.
The file contains 1, 3, 49, and 2061 certificate records for dimensions 1–4.

To reproduce the additional symbolic/numerical checks or regenerate certificates:

```sh
python -m pip install -r requirements.txt
python code/check_refinements.py
python code/carry_certificates.py generate --max-k 4 --out certificates/carry.json
```

The tested environment is recorded in `results/environment.json`.
Certificate regeneration uses SciPy only to propose witnesses; each accepted
proposal is then verified with `fractions.Fraction`. The exact verification
argument and its trust boundary are explained in Section 13 of the article.
The finite certificates are proof evidence for the finite counts. Randomized
and floating-point stress tests are only supplementary error checks.

## Build the PDF

A TeX Live installation with the packages named in the preamble is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_refinements.tex
```

Alternatively, run `pdflatex` three times. The Makefile provides `pdf`, `verify`,
`checks`, `regenerate`, and `clean` targets. Regenerating the PDF may change its
byte-level metadata without changing the article.

## Source snapshot

Selected source files were inspected at ProveIt commit:

    3a25020a654d196f7f1aa2e37649752c000d0e65

The two requested repository locations were the paper assets under
`Combinatorics/Ramsey/Papers/sz-thm-gowers-proof` and the Lean development under
`Combinatorics/Ramsey/Lean/GowersSzemeredi`. The article identifies exactly which
Lean modules and normalizations were inspected. No repository changes were made.
The relevant pages of the original Gowers paper were checked through the public
PDF mirror cited in the article.

## Status and limitations

This is a research manuscript, not a refereed publication. Its local theorems
are supported by conventional mathematical proofs. The leading threshold-count
asymptotics are explicitly credited external inputs, not new proofs of those
classical results. Sharpness of density transfer is proved for the stated finite
weighted model, not for every prescribed arithmetic-character realization.

No improvement to the best global bound for Szemerédi's theorem is claimed.
The source dependency warning around Corollary 16.11 is reported, not silently
assumed repaired. No Lean or Lake executable was available, and no new Lean
proof was compiled; the formalization section is an implementation plan.
Priority for every formulation has not been established by an exhaustive
literature search. These limitations do not affect the stated self-contained
local proofs.

No source-paper PDFs, repository copies, or font files are redistributed.
