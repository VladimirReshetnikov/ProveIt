# Research Report 37: the exact negative-index obstruction

Research_Report37.tex and Research_Report37.pdf present an exact
necessary-and-sufficient obstruction criterion for the frozen Raw29/positive21
compiler system, with positive reconstruction of the omitted witnesses.
A full positivity theorem and a full negative compiler zero remain unresolved.

The computational evidence consists of exact finite corroborations and necessary
window exclusions. In particular, the 3,536-point relaxed scale grid is not a
search of full compiler zeros. Auxiliary-only materialized tuples are not full
zeros. The accompanying article and proof state the hypotheses and the boundary
between prior reductions and the new reconstruction results.

## Package map

- Research_Report37.tex / Research_Report37.pdf: the standalone article
- evidence/: the complete frozen obstruction packet, copied byte for byte;
  25 payloads plus its MANIFEST.sha256
- evidence/EXACT-OBSTRUCTION.md: the frozen proof
- evidence/sources/: inert upstream context; its Python source is never imported,
  interpreted, or executed by the release tools
- verification/source-lineage.json: the original/packaged identity of all 26 files
- verification/expected-receipts.json: three recursively typed frozen receipts
- verification/replay-plan.json: the exact three-script replay allowlist
- verify_release.py: authenticated exact inventory and isolated-copy replay
- tamper_regression.py: malformed receipt and changed-release rejection tests
- archive_release.py / archive_regression.py: deterministic ZIP creation,
  safe inventory validation, moved extraction replay, and hostile ZIP tests
- build_pdf.py: external local pdfLaTeX build with shell escape disabled
- seal_release.py: maintainer utility, never a way to validate received evidence

## Authenticate and replay

Before executing any packaged program, hash the ZIP with a trusted external
hash tool and compare it with the ZIP SHA256 obtained independently from the
sender. For example, run sha256sum on the ZIP using your operating system's
trusted tool. A packaged verifier cannot establish its own authenticity.

If only an enclosing MANIFEST.json digest is supplied, a trusted external
implementation must first authenticate that manifest and verify its payload
hashes, including the normalized verifier hash described in INTEGRITY.md.
Checking the manifest digest alone is insufficient before executing its verifier.
The tools use Python 3.9 or later and the standard library only; they install
nothing.
From the release directory run:

    python -I -B verify_release.py --verify-only
    python -I -B -O verify_release.py --verify-only
    python -I -B verify_release.py --self-test-types
    python -I -B verify_release.py --replay
    python -I -B -O verify_release.py --replay
    python -I -B tamper_regression.py

Each full replay creates two fresh external copies and executes exactly these
three authored mathematical programs, once normally and once with Python -O:

1. evidence/check_exact_obstruction.py
2. evidence/independent/audit_exact_obstruction.py
3. evidence/independent/audit_log_windows.py

The programs freshly print deterministic receipts. Each receipt must match
both its frozen bytes and its exact recursive JSON types and values. The copied
source and original release must retain every byte, file/directory mode, and
modification time. The full identity gate runs before any mathematical program
executes and after each program. No program in evidence/sources/ executes, and
no upstream arithmetic schedule is evaluated. Allow a few minutes for replay.

## PDF and ZIP

An installed local TeX Live/pdfLaTeX is needed to rebuild the article. Outputs
must be outside the release; each PDF output directory must be new or empty.
Replace OUTPUT_DIR below with an external directory of your choice.

    python -I -B build_pdf.py --output OUTPUT_DIR/pdf --check-packaged
    python -I -B archive_release.py --create OUTPUT_DIR/Research_Report37.zip
    python -I -B archive_release.py --check OUTPUT_DIR/Research_Report37.zip --sha256 INDEPENDENT_ZIP_SHA256 --replay
    python -I -B archive_regression.py --archive OUTPUT_DIR/Research_Report37.zip --sha256 INDEPENDENT_ZIP_SHA256

PDF byte reproducibility assumes the same installed TeX packages and fonts.
The builder uses three passes, a fixed epoch, UTC, suppressed PDF timestamps and
trailer identifiers, and explicit no-shell-escape. With --check-packaged, it
first verifies the sealed tree and fails unless the rebuilt PDF is byte-identical.

ZIP validation compares an independently authenticated local release with the
supplied archive. Exact names, counts, regular-file modes, sizes and all bytes
must match before safe extraction. It rejects unsafe or duplicate member names.
The moved extraction is then checked with and without -O; --replay runs the full
mathematical replay under both verifier modes. All logs and test outputs remain
external. See INTEGRITY.md for the trust boundary and maintainer procedure.
