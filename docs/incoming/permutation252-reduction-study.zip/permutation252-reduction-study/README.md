# Research toward a ZFC-consistency machine below 252 states

**No machine below 252 states is established by this package.** It supplies
new complete finite searches, explicitly partial larger searches, compiler
controls, proof arguments, and a reproducible record of their limits. The
252-state reference remains the selected ProveIt candidate. The new optimized
tag-swap table has 254 working states and is a runtime control with separate
blank-bootstrap and consistency-calibration obligations.

Read [report.pdf](report.pdf) for the complete study; [report.tex](report.tex)
and `sections/` contain its editable LaTeX source. `RESULTS.json` identifies
the principal results, and `SHA256SUMS.txt` records the delivered file bytes.

## Main results and scope

| Investigation | Result |
|---|---|
| Two incoming rows, targets only | Complete: 2,898,046 assignments screened; no survivor |
| Two incoming rows, full actions | Complete: 46,738,944 assignments screened; no survivor |
| Three incoming rows, targets only | Complete: 300,451,769 assignments screened; no survivor |
| Higher-degree targets and degree-three full actions | Timed partial runs, with exact retained frontiers |
| Full affine constructor census, multipliers at most 12 | 5,432 assignments; minimum remains 281 states in the public Wade backend |
| Move acceptance to successful MP | Complete source controls cost 284 or 285 states |
| Deterministic inverse MP | Complete source controls cost 302 or 305 states |
| Optimized universal/equality tag swap | 254 states; 8,408 conditional instruction guards pass |
| Uniform folds of that runtime | Complete: 56,419 diagnostics; no survivor |
| Natural-value abstraction | All 25 analyses pass closure checks; no additional guard exclusion |

The search rows overlap in their action domains and must not be added as
disjoint regions. A failed affine diagnostic may mean an unsupported symbolic
operation or fuel exhaustion. These results are not lower bounds on Turing
machine size. Costs from the reconstructed 281-state Wade backend cannot be
subtracted from the separately optimized 252-state reference.

## Layout and provenance

- `upstream/`: an unchanged subset of ProveIt, retaining original paths.
- `machine_search/`: independent C++ executors, preparation and partition
  audit scripts, case data, summaries, and explicit frontiers.
- `codecs/`: formula-code census, optimized tag-swap experiment, tables,
  finite certificates, pinned compiler inputs, and a delivery manifest.
- `semantics/`: MP controls, total tables, DAGs, proof-audit notes, pinned
  dependencies, and a delivery manifest.
- `analysis/`: the stronger numeric analysis, independent sampled failure
  replay, and the completed Python lazy-search evidence.
- `ledgers/`: lossless packed event ledgers, metadata, and their codec.

The ProveIt pin is
[`43026ff42f0939f09b9e95495248cfadcad38e38`](https://github.com/VladimirReshetnikov/ProveIt/tree/43026ff42f0939f09b9e95495248cfadcad38e38).
The original program and Wade compiler pin is
[`jeff87654/busy-beaver@297ab8df7e5de329605c3875b4934643b371a5e3`](https://github.com/jeff87654/busy-beaver/tree/297ab8df7e5de329605c3875b4934643b371a5e3).
The vendored Wade license is retained in each compiler directory; other
inherited attribution is retained with its source. This subset does not
install the full Lean dependency closure.

## Reproduce the standard finite evidence

Requirements: Python 3.10 or later, using only its standard library.
`searches` and `variant` also require `g++` with C++17 support. Assertions
must remain enabled. The generalized C++ search uses GCC's unsigned
128-bit integer support for its exact family sizes. No command installs
dependencies, uses a network connection, or invokes Git, Lean, or Coq.

From the unpacked package directory:

```sh
python3 reproduce.py verify
python3 reproduce.py baseline --out /tmp/proveit252-rerun
python3 reproduce.py searches --out /tmp/proveit252-rerun
python3 reproduce.py codecs --out /tmp/proveit252-rerun
python3 reproduce.py semantics --out /tmp/proveit252-rerun
python3 reproduce.py phase --out /tmp/proveit252-rerun
python3 reproduce.py variant --out /tmp/proveit252-rerun
```

Each experiment creates a command-named subdirectory below `--out`, which
must lie outside the package. Nonempty command directories are rejected;
use a fresh output parent when repeating a command. Fixed-output codec and
semantic drivers run from copied directories. Subprocess output goes to
`logs/`, and `reproduction.json` records commands and successful comparisons.
Use `--dry-run` to inspect commands without creating output.

`verify` checks the file hashes. `baseline` regenerates and audits the frozen
table, its 82,552-step blank prefix, productive instruction replays, and all
8,391 affine cases under the four inherited box contracts. That unchanged
finite-audit driver retains historical `remaining_obligations` strings;
the report's current endpoint audit supersedes those historical labels.
This reproduction does not rebuild the current external Lean endpoint.

`searches` reruns the three **completed** families in the table, compares
their deterministic ledger hashes, and reruns the partition audits. It
compares the target-only two-row ledger with all 185,033 saved Python
journal entries and independently replays the specified 1,472 full-action
failure samples. Sample replay is not exhaustive failure replay.

The default allowance is 600 seconds per family. An incomplete run fails
the completed-reproduction check. On a slower host, increase `--seconds`
and use a fresh output directory. To run a subset:

```sh
python3 reproduce.py searches --families target2 target3 --seconds 1800 --out /tmp/proveit252-selected
```

`codecs`, `semantics`, and `phase` compare regenerated data with delivered
data, excluding only the documented timing or relocated input-path
metadata. Table and DAG byte comparisons remain exact. `variant` repeats
the tag-swap runtime's 8,408 conditional guard checks and 56,419 folds; it
does not supply a blank-start proof for that changed table.

## Larger searches: explicit opt-in

The wrapper does not rerun the large timed partial families. The stable
lower-level CLIs are:

```text
action_search DATA PREFIX SECONDS FIRST_GROUP GROUP_COUNT TARGET_ONLY
action_search_multi DATA PREFIX SECONDS MIN_DEGREE MAX_DEGREE TARGET_ONLY
```

`TARGET_ONLY=1` retains each incoming row's write and movement and gives
251 working-state targets. `TARGET_ONLY=0` gives 1,008 write/move/target
actions, including the halt target. Outputs are `PREFIX.ledger.tsv`,
`.summary.tsv`, `.frontier.tsv`, and `.survivors.tsv`.

For example, after preparing `multi_data` with the standard search command,
the following commands use an external existing output directory. Replace
the illustrative absolute paths with your output paths:

```sh
g++ -O3 -std=c++17 machine_search/action_search_multi.cpp -o /tmp/proveit252-rerun/searches/bin/action_search_multi
/tmp/proveit252-rerun/searches/bin/action_search_multi /tmp/proveit252-rerun/searches/multi_data /tmp/proveit252-rerun/searches/new_target4plus 600 4 9 1
g++ -O3 -std=c++17 machine_search/action_search_multi_restart.cpp -o /tmp/proveit252-rerun/searches/bin/action_search_multi_restart
/tmp/proveit252-rerun/searches/bin/action_search_multi_restart /tmp/proveit252-rerun/searches/multi_data /tmp/proveit252-rerun/searches/new_action3 600 3 3 0
```

The first source reuses completed cases before the next interrupted case.
The `_restart` source reruns earlier cases and is the exact source used for
the recorded partial degree-three full-action experiment. Keeping those
sources distinct matters when comparing check counts. A 600-second run on
another host generally stops at a different frontier. Audit the new
partition with `machine_search/audit_multi_partition.py --help`; use
`--actions 251` or `1008`, matching degree bounds, and the actual source.
Retain the generated frontiers and treat `remaining > 0` as unfinished.

## Lossless ledger restoration

The `ledgers/packed_ledgers/*.ledger.gz` files use a packed DFS-event format inside gzip.
Ordinary gzip decompression alone does **not** reconstruct their TSVs.
Read the header and `--help` of `ledgers/ledger_codec.py` for its commands:

```text
python3 ledgers/ledger_codec.py verify PATH.ledger.gz
python3 ledgers/ledger_codec.py unpack PATH.ledger.gz /external/output/restored.ledger.tsv
python3 ledgers/ledger_codec.py pack /external/input/raw.ledger.tsv /external/output/new.ledger.gz --choices 251
```

This optional codec additionally requires a C++17 compiler, **zlib and
OpenSSL development headers/libraries**, with linker flags `-lz -lcrypto`.
Its helper is built in a temporary directory. These are not dependencies
of `reproduce.py`'s standard commands. `verify` reconstructs the complete
original TSV stream into SHA-256 without writing the multi-gigabyte TSV;
`unpack` writes and hashes the restored bytes. Check the accompanying
metadata before allocating space for restoration. The saved
`analysis/lazy-nodes.jsonl.gz` is ordinary gzip, decoded by Python alone.

Lossless restoration checks the record, and partition auditing checks its
accounting. Neither establishes that a rejected candidate is semantically
incorrect or that 252 states are necessary.
