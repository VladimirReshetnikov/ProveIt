# Total Quadratic Semantics for Irreversible Computation

**Exclusive sites, timed self-assembly, and Horn closure without execution histories.**
Research prepared for Vladimir Reshetnikov with ChatGPT, 2 October 2026.

Read `article.pdf` for the complete mathematical development; `article.tex`
is self-contained LaTeX source with an embedded bibliography.

## Main result

For each fixed finite catalogue of irreversible exclusive-site rules, one
quadratic polynomial has exactly one complete natural-number zero for every
positive integer delay assignment. The zero records the final label and
first activation time at every site, including a canonical sentinel for sites
that never activate. No execution history is quantified.

With m nonseed sites, q labels, D distinct used nonseed prerequisite literals,
L prerequisite incidences, R0 empty-body rules and R total rules, the timed
compiler uses exactly m(2q+3)+3D+3(L+R0)+R natural witnesses. The optimized
one-label Horn compiler uses m+3(L+R0)+R. Unit-delay variants omit the R prefix
witnesses. Delay values change the parameter assignment, not the polynomial.

The article also proves a finite polyhedral timing decomposition, an exponential
lower bound for explicit constant-outcome lists, a fixed-candidate tile bound
of 38m witnesses, a four-tile counterexample to occupancy-free relaxation,
and the impossibility of existentially certifying permanent nonhalting in
the unbounded universal Horn substrate.

## Reproduce

Requires Python 3.10 or newer, standard library only:

```sh
python code/test_compiler.py
python code/verify_exports.py
```

The first command regenerates test receipts and the four example polynomials.
The second independently re-expands the penalty descriptions, checks exact
identity with the monomial exports, and verifies the supplied natural zeros.
It does not import the compiler.

To compile the paper with an ordinary LaTeX installation:

```sh
sh build.sh
```

On Windows, the equivalent is three runs of:

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

## Minimal Python example

```python
import sys
sys.path.insert(0, 'code')
from quadratic_compiler import Network, Rule, Compiled

network = Network(
    sites=3,
    labels=2,
    seeds=((0, 1),),
    rules=(Rule((1, 1), ((0, 1),)),
           Rule((2, 1), ((1, 1),)),
           Rule((1, 2), ((2, 1),))))
compiler = Compiled(network, timed=True)
values, labels, times = compiler.witness([1, 1, 1])
assert labels == [1, 1, 1]
assert times == [0, 1, 2]
assert compiler.c.evaluate(values) == 0
explicit_polynomial = compiler.c.export(values)
```

## Exact exported examples

| File in `results/` | Witnesses | Expanded monomials | Degree |
|---|---:|---:|---:|
| `locking_counterexample.json` | 29 | 126 | 2 |
| `literal_four_tile_example.json` | 58 | 302 | 2 |
| `timed_race.json` | 85 | 435 | 2 |
| `huge_delay_chain.json` | 45 | 206 | 2 |

Each includes every parameter and witness name, full natural zero assignment,
affine residual, nonnegative product, and expanded monomial. The large-delay
example has delays around 10^30 and a largest witness of 103 bits.

## Scope and provenance

The repository audit is pinned to
`db3b377f0ae3ab8cb585df4eb4b859cbee5ba3c5`.
The existing first-arrival self-assembly compiler is explicitly credited.
The relevant merged report's README was read; its full large TeX source was
not available through the connector. See `SOURCE_AUDIT.md`.

The paper's proofs are ordinary mathematical proofs with finite regression
tests, not a Lean formalization. The work does not claim a new smallest
universal polynomial, a resolution of the general single-fold or finite-fold
Diophantine problem, an exhaustive literature audit, or certified historical
priority. The timed model is a specified deterministic mathematical semantics,
not a model of stochastic molecular attachment rates.
