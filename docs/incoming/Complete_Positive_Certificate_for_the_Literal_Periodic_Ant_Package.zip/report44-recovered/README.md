# Research Report 44: complete positive literal-ant certificate, recovered edition

This is a reconstructed edition following the pre-delivery filesystem reset. Its manuscript, implementation files, PDF, inventory and archive receive fresh hashes and fresh verification. Historical old QA receipts under verification/historical describe prior lost bytes only; they do not authenticate this edition. Matching full arithmetic-stream hashes establish source-stream identity, not identical Python or PDF bytes. Earlier authenticated Reports 40/42 remain unchanged.

## Result and files

Research_Report44.pdf is the article, with editable Research_Report44.tex. The certificate/ directory contains the recovered arithmetic packet, source receipts, explicit positive-coordinate ledger, inherited contracts, fixed coefficient recipe data and fresh audits. The five positive parent parameters are quantified. Two raw positive inputs use 465 positive witnesses, 285 residuals and one final equation: 2,307,457 operations = 1,153,586M + 1,153,871A. Exact degree 2,304,000, leading homogeneous part 2·History:W^2304000. Paid positive Cantor pairing yields one raw input, 467 witnesses, 286 residuals and 2,307,467 operations. Strict literal 1/3 totals: 554,386,261,710,212,588 and 554,386,261,710,212,598. The huge coefficient grammar is never expanded or executed.

The source language is pinned U15 raw-pair J1 halting through the initialized literal-ant accepting observable. The ant continues moving. Empty-right specialization is unsupported by the two-sided primary initialization. History/base-three/Pell, recoder and literal-interface theorems remain explicit dependencies; this is not an operation record or single-fold theorem. The corrected initializer factor h_x is (3^(au)-1)/(3^u-1), not a.

## Authenticate before invoking bundled code

Obtain the new manifest and ZIP SHA256 from the trusted delivery, not solely from this directory. Check the entire ZIP with a trusted SHA256 implementation before extraction. Safe members have unique ordinary relative filenames below report44-recovered/, with no traversal segments or symlinks.

For a separately supplied directory, use this external standard-library bootstrap before any bundled tool. Replace ROOT and TRUSTED with the actual directory and new trusted manifest hash. Failed authentication is a blocker; do not replace TRUSTED by a hash of changed content and call that recovery.

```python
from pathlib import Path, PurePosixPath
import hashlib, json, stat
root = Path(ROOT).resolve()
def need(ok):
    if not ok: raise RuntimeError('Authentication failed')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def obj(pairs):
    d = {}
    for k,v in pairs:
        need(k not in d); d[k] = v
    return d
p = root / 'MANIFEST.json'
need(p.is_file() and not p.is_symlink() and sha(p) == TRUSTED)
m = json.loads(p.read_text(), object_pairs_hook=obj)
need(set(m) == {'schema','files'} and m['schema'] == 'report44-recovered-inventory-v1')
files, dirs = set(), {'.'}
for p in root.rglob('*'):
    s = p.lstat().st_mode
    need(stat.S_ISREG(s) or stat.S_ISDIR(s))
    (files if stat.S_ISREG(s) else dirs).add(p.relative_to(root).as_posix())
need(files == set(m['files']) | {'MANIFEST.json'})
expected_dirs = {'.'}
for name,e in m['files'].items():
    q = PurePosixPath(name)
    need(not q.is_absolute() and all(x not in ('.','..') for x in q.parts) and q.as_posix() == name)
    need(set(e) == {'sha256','bytes','mode'} and type(e['bytes']) is int and type(e['mode']) is int)
    p = root / name; s = p.stat()
    need(sha(p) == e['sha256'] and s.st_size == e['bytes'] and stat.S_IMODE(s.st_mode) == e['mode'])
    expected_dirs.update(x.as_posix() for x in q.parents)
need(dirs == expected_dirs)
print('Authenticated inventory')
```

This is consistency checking with an external trusted hash, not a digital signature.

## Isolated replay

Requires Python 3.11+ and SymPy for exact history identities. After authentication and code inspection, from any working directory:

```
python -I -B /path/to/verify_release.py --manifest-sha256 TRUSTED --output /fresh/existing-parent/replay
python -I -B -O /path/to/verify_release.py --manifest-sha256 TRUSTED --verify-only
```

Outputs must be fresh and external to the release. The verifier copies certificate/ into disposable external storage, runs the two complete source variants and output guards, checks the three intended optimized-mode rejections, and reconstructs/audits history in separate normal and optimized copies. Generated history174.json, verification.json and audit_receipt.json must match the packaged references byte-for-byte. Original release bytes, modes and modification times must remain unchanged.

The complete generator, verify_packet.py and check_output_boundaries.py intentionally reject -O before scientific work. These are successful guard tests, not optimized scientific passes. The history reconstruction and finite-history checker use explicit exceptions and must pass normal and -O. Release tooling also uses explicit checks.

Only inspected newly written reconstruction/audit code is executed. Nothing under history/source, dependencies/mathlib or dependencies/recipe_assets is imported or executed. Small own arithmetic JSON specifications are data for the new generator. No upstream Python/Lean, saved upstream schedule, physical ant program or coefficient recipe runs. Complete replay generates and checks the approximately 2.3 million-gate arithmetic stream; it does not instantiate enormous numerical witnesses.

To emit the full free-coefficient source after authentication:

```
python -I -B certificate/merged_source.py --output /fresh/two.json --emit /fresh/source.jsonl
python -I -B certificate/merged_source.py --arity 1 --output /fresh/one.json
```

Both output paths must be fresh and outside the resolved certificate source tree. Both are validated before either is opened. Default replay omits the large JSONL file while generating, validating, hashing and degree-checking every gate. Fresh independent audit details and their exact limits are in the certificate packet; historical audit summaries are labeled separately.

## Deterministic rebuilds

Requires a local TeX Live/pdfLaTeX installation; no network or package installation is performed. External TeX caches and no shell escape are mandatory:

```
python -I -B build_pdf.py --output /fresh/pdf-build --check-packaged --manifest-sha256 TRUSTED
python -I -B archive_release.py --manifest-sha256 TRUSTED --output /fresh/report44.zip
```

The PDF uses three passes and UTC epoch 1791072000 with dates/trailer ID suppressed. The ZIP uses sorted files, fixed 2026-10-04 timestamps, ordinary 644 modes and fixed compression. Existing outputs cannot be overwritten. Fresh builds must match their packaged reference bytes on the recorded toolchain; no promise covers arbitrary future TeX/zlib versions. Logs and visual renders remain outside the sealed release.
