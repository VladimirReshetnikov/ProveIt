# Fixed-Height Shifted Strips: All-Orders Asymptotics and Inversion

The seven-page article proves the fixed-height asymptotic expansion for the array counts in OEIS A181196, including A181198 and A181199. At height five it proves the displayed conjectured leading equivalent and gives two explicit corrections. It also provides an exact finite rule for every coefficient and an inverse expansion with a precise integer-ceiling qualification.

The proof does not assume the conjectured recurrence. It treats each fixed height and the dominant exponential sector; growing-height uniformity and a complete classification of smaller exponential sectors remain research questions.

## Contents

- `article.pdf` and `article.tex`: complete article and source
- `code/check_midpoint.py`:60 exact small rectangles,30 displayed OEIS terms and121 interior hook identities
- `code/gaussian_corrections.py`: symbolic matrix-entry Wick derivation of both corrections for general height
- `code/ward_corrections.py`: separate symbolic integration-by-parts derivation, including a check against Sun's proved height-three recurrence
- `code/check_gaussian_integrals.py`: independently written direct Gaussian-integral checks at heights2,3,4
- `code/check_inverse.py`: exact formal inverse substitution
- `code/generate_expansion.py`: coefficient generator from the article's finite formal recipe
- JSON records: outputs of the exact checks
- `SHA256.json` and `check_integrity.py`: release integrity manifest and checker

## Verification

Python3.10 or later and SymPy suffice. No network, floating-point optimization or conjectured recurrence is needed. In a writable extracted copy, run:

```
python -O check_integrity.py
python -O verify.py
```

The mathematical programs refresh their result JSON files, so check release hashes before running them. The finite computations check the displayed identities and constants; the uniform all-orders error estimate is proved in the article.

To generate further coefficients, for example:

```
python -O code/generate_expansion.py --order 4 --height 5
python -O code/generate_expansion.py --order 3
```

Omitting `--height` retains a symbolic height parameter. The work increases with the requested order. Coefficients are exact rationals or rational functions. This computes the dominant-sector Poincare coefficients, not every exponentially smaller contribution.

## PDF build

A standard TeX installation can build with `pdflatex article.tex` twice. The included `build_local.sh` supplies the explicit font and TeX paths used in the original environment.

## Source status

The live OEIS entries and primary papers were checked on1October2026. The article states the bounded literature search and distinguishes the proved asymptotic statements from the still-unused recurrence conjectures. No exhaustive novelty, external-referee or proof-assistant certification is claimed.
