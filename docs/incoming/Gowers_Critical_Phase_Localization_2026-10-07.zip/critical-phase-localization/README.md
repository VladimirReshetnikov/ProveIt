# Lossless Local Phase Removal in Small Characteristic

**Exact Frobenius obstructions, optimal subspace repair, sharp quotient moments,
and higher-degree extensions**

17-page research manuscript prepared for Vladimir Reshetnikov, 7 October 2026.
Mathematical development and computational checks with ChatGPT.

## Main result

Let `V = F_p^n`, let `d = p + 1`, and let `T: V^d -> F_p` be symmetric and
multilinear in all slots. Its Frobenius defect is the alternating bilinear form

```text
D_T(x,y) = T(x,...,x,y) - T(x,y,...,y),
```

with `p` copies of the repeated argument in each term. If `rank D_T = 2r`,
the maximum dimension of a subspace on which `T` has a nonclassical polynomial
primitive is exactly `n-r`.

For any such repair subspace `H`, choose one primitive `P_H`. Define the local
energy on each coset by

```text
L(c) = || f(c+.) exp(-2 pi i P_H) ||_(U^d(H))^(2^d).
```

The main localization theorem proves

```text
E_T(f) <= (average_c L(c)^(1/(d+1)))^(d+1)
       <= average_c L(c)
       <= max_c L(c).
```

Thus at least one coset preserves the entire normalized selected-derivative
energy. The first constant and the moment exponent are sharp, with exact
single-coset extremizers. The primitive is common to all cosets. The article
also proves a mixed-function version and a higher-degree version under common
isotropy of a pencil of alternating Frobenius defects.

The algebraic side includes an explicit critical-degree primitive, a canonical
block decomposition modulo integrable tensors, the exact correction-support
cost `2r`, exact counts of all repair subspaces, and a rank-exact diagonal-query
acceptance law. A small ternary experiment is kept separate from the general
proofs and from the conjecture it motivates.

## Status and scope

This is an unrefereed research draft with written proofs and exact finite
regression checks. There is no Lean implementation, Lean build, or claim of
independent peer review. The known general nonclassical integration criterion
is credited to Tidor, building on Tao and Ziegler; the characteristic-two
antecedents in the repository are acknowledged. Priority for the combined
localization theorem has not been established by an exhaustive literature search.

No improvement of a global Szemeredi bound, a Ramsey-number bound, or the
repository's formalization status is claimed. In particular, the article does
not bound the obstruction rank from the selected energy. That missing estimate
is a principal research target, not an implicit input to a purported complete
inverse theorem. The finite-vector-space setting does not automatically supply
a corresponding long progression in a cyclic group.

## Files

- `critical_phase_removal.tex` and `critical_phase_removal.pdf`: the article.
- `SOURCE_AUDIT.md`: primary sources, repository provenance, and prior-work distinctions.
- `PROOF_AUDIT.md`: proof obligations, edge cases, normalization and scope checks.
- `FORMALIZATION.md`: proposed dependency order and interfaces, not Lean stubs.
- `data/dependencies.json`: machine-readable theorem dependency description.
- `code/verify.py`: deterministic finite checker using integer and rational arithmetic.
- `data/verification.json`: the actual generated results of that checker.
- `requirements.txt`, `Makefile`, `BUILD.md`: reproduction instructions.

## Reproduction

From this directory, run:

```sh
python -m pip install -r requirements.txt
python code/verify.py --output data/verification.json
latexmk -pdf -interaction=nonstopmode -halt-on-error critical_phase_removal.tex
```

The Python checks require Python 3.10 or later and NumPy. They were run with
Python 3.13.5 and NumPy 2.3.5. The TeX source uses standard LaTeX packages and
an internal bibliography; no bibliography database or external images are needed.
Neither the checker nor the document build requires network access once their
dependencies have been installed.

## Recorded checks

The included report records 297 primitive instances and 87,787 exact
basis-difference equations, with exhaustive coefficient censuses on `F_2^2`,
`F_2^3`, and `F_3^2`, plus 40 deterministically sampled integrable tensors on
each of `F_3^3` and `F_5^2`. All top-symbol identities and all order-`d+1`
basis-direction differences are checked at every base point for each primitive.

The rank distributions exhaust all 16,418 alternating matrices in dimension four
across characteristics 2, 3, and 5. The isotropic-space counts enumerate all
subspaces in those three vector spaces, for every possible alternating rank.
The analytic regression suite checks 24 root-of-unity/zero-valued ternary
functions against exact rational lower certificates for the fractional moment,
plus the exact single-coset equality. A ninth-root gauge is checked on all
59,049 ambient cubes and its lower-degree coset differences on 729 local cubes.
The separate 81-tensor ternary census has
maximum bias `11/27`; it does not optimize over arbitrary bounded functions.

## Suggested integration

A self-contained placement is

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/critical-phase-localization/
```

Alternatively, the manuscript may be incorporated as a new source in the
existing local-quantitative-refinements collection. No source number is assigned
here, to avoid a collision with concurrent submissions. Preserve the distinction
between the general face-integration theorem, the rank-exact critical-degree
corollary, and the all-degree extension. Do not promote the experimental
canonical-block conjecture or an unimplemented formalization plan to theorem
status. No repository files were modified by this delivery.
