#!/usr/bin/env python3
"""Audit the released 215-state construction. Python standard library only.

--full reruns the all-natural primitive proof on the alternative table.
--spares reruns the relaxed-spare checker on the baseline. A PASS does not
assert a 214-state result. See the ordinary calibration proof in the report.
"""
from pathlib import Path
import argparse, gzip, hashlib, json, os, subprocess, sys, tempfile
sys.dont_write_bytecode=True
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
if not __debug__:raise RuntimeError("Run without -O; assertions are part of the checks.")
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'baseline/candidate-k215'
MACHINE=ROOT/'machine215-rho6'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def data(path):return json.loads(path.read_text())
def put(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def run(args):subprocess.run([sys.executable,*map(str,args)],check=True,cwd=ROOT)
def table(path):
    rows={};start=None
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            assert start is None;start=int(line.split()[2]);continue
        if not line.strip() or line.lstrip().startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        assert b in(0,1) and w in(0,1) and d in('L','R') and(q,b)not in rows
        rows[q,b]=(w,d,z)
    states={q for q,b in rows}
    assert len(rows)==2*len(states) and all((q,b)in rows for q in states for b in(0,1))
    assert start in states
    return start,rows,states
def audit_manifest():
    checked=0
    for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
        digest,relative=line.split('  ',1);p=ROOT/relative
        assert p.is_file() and p.resolve().is_relative_to(ROOT),relative
        assert sha(p)==digest,('manifest mismatch',relative)
        checked+=1
    return checked

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--full',action='store_true');p.add_argument('--spares',action='store_true')
    p.add_argument('--output',type=Path,help='Regenerated evidence; default is a new temporary directory.')
    p.add_argument('--skip-manifest',action='store_true',help='Development only; release checks should verify it.')
    a=p.parse_args();out=a.output.resolve()if a.output else Path(tempfile.mkdtemp(prefix='zfc214-reproduction-'))
    out.mkdir(parents=True,exist_ok=True)
    manifest_count=None if a.skip_manifest else audit_manifest()
    run([MACHINE/'reconstruct_rho6.py','--candidate',BASE,'--output',out/'reconstruction'])
    for f in ['sites215-rho6.json','k215-rho6.native.tm']:
        assert (out/'reconstruction'/f).read_bytes()==(MACHINE/f).read_bytes(),f
    start,T,states=table(MACHINE/'k215-rho6.native.tm')
    ds,DT,dstates=table(MACHINE/'k215-rho6.tm')
    mapping={q:i for i,q in enumerate(sorted(states))};mapping[254]=215
    assert len(states)==215 and set(dstates)==set(range(215)) and start==ds==0
    assert {(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in T.items()}==DT
    C=data(MACHINE/'canonicalization.json')
    assert C['native_to_dense']=={str(k):v for k,v in mapping.items()}
    assert C['native_sha256']==sha(MACHINE/'k215-rho6.native.tm') and C['dense_sha256']==sha(MACHINE/'k215-rho6.tm')
    sys.path.insert(0,str(BASE/'code'));import source_language as s
    old=data(BASE/'sites215.json');new=data(MACHINE/'sites215-rho6.json')
    g=s.graph_intervals(old);ng=s.graph_intervals(new)
    assert g==s.graph_arithmetic(old)[0] and ng==s.graph_arithmetic(new)[0]
    assert [x[1]for x in g]==[x[1]for x in ng]
    assert [(x[0],x[1])for x in old]==[(x[0],x[1])for x in new]
    changed=[i for i,(x,y)in enumerate(zip(old,new))if x!=y]
    assert changed==[959,964,1137,1142]
    for i in changed:assert old[i][2]==3 and new[i][2]==5
    met=s.metrics(s.tree(new));assert met['dag_nodes']==202 and len(new)==4751
    _,oldtable,_=table(BASE/'k215.native.tm')
    edits=[key for key in T if T[key]!=oldtable[key]];assert len(edits)==42
    R=data(MACHINE/'verification/runtime.json')
    cases=json.loads(gzip.decompress((MACHINE/'verification/runtime_cases.json.gz').read_bytes()))
    expected=[(i,v)for i,(_,op,arg)in enumerate(new)for v in((False,True)if op=='CD'else(False,))]
    assert [(c['site_index'],c['positive'])for c in cases]==expected
    assert R['status']=='UNIVERSAL_MATHEMATICAL_PASS' and R['proved_cases']==R['expected_cases']==len(cases)==6176
    assert R['table_sha256']==sha(MACHINE/'k215-rho6.native.tm') and R['sites_sha256']==sha(MACHINE/'sites215-rho6.json')
    sr=BASE/'code/runtime-inputs/runtime/symbolic_runtime.py';ir=BASE/'code/runtime-inputs/runtime/independent_runtime.py'
    assert R['checker_sha256']==sha(sr) and R['helper_sha256']==sha(ir)
    m={int(k):v for k,v in data(BASE/'code/runtime-inputs/inputs/legacy_mapping.json').items()}
    for q in states|{254}:
        if q not in m:m[q]=q+1000
    reverse={m[q]:q for q in states|{254}};used=set()
    for c in cases:
        assert c['duration'][0]>0 and all(v>=0 for v in c['duration'])
        assert c['symbolic_steps']==sum(c['kinds'].values())
        used.update((reverse[q],b)for q,b in c['rows'])
    for block in R['blocks']:
        for event in block['trace']:used.add((reverse[event[1][0]],event[1][1]))
    assert used==set(T),('row coverage',len(used),len(T))
    aggregate={'status':'STRUCTURAL_AND_CERTIFICATE_METADATA_PASS','working_states':len(states),'rows':len(T),'source_occurrences':len(new),'source_nodes':met['dag_nodes'],'source_operand_edits':changed,'native_row_edits':len(edits),'guarded_cases':len(cases),'symbolic_rules':sum(c['symbolic_steps']for c in cases),'minimum_duration_constant':min(c['duration'][0]for c in cases),'native_rows_covered_including_block_lemmas':len(used),'table_sha256':sha(MACHINE/'k215-rho6.native.tm'),'dense_table_sha256':sha(MACHINE/'k215-rho6.tm'),'source_sha256':sha(MACHINE/'sites215-rho6.json'),'scope':'Metadata and source/renaming audit. Use --full to regenerate the unbounded primitive proof; metadata does not independently replay that proof.'}
    put(out/'aggregate.json',aggregate)
    startup=out/'startup.json';startup.write_bytes(gzip.decompress((MACHINE/'verification/startup.json.gz').read_bytes()))
    run([MACHINE/'independent_startup.py',MACHINE/'k215-rho6.native.tm',startup,'--output',out/'independent-startup.json'])
    independent=data(out/'independent-startup.json');assert independent==data(MACHINE/'independent-startup.json')
    assert independent['steps']==95726 and independent['registers']==[4,0,0,0,0,0,0,0,0]
    inv=ROOT/'research/invariants'
    run([inv/'audit_invariant215.py','--base',BASE,'--certificate',inv/'invariant215.json','--output',out/'invariant215-audit.json'])
    run([inv/'audit_affine215.py','--base',BASE,'--certificate',inv/'affine215.json','--output',out/'affine'])
    assert data(out/'invariant215-audit.json')==data(inv/'invariant215-audit.json')
    assert data(out/'affine/affine215-audit.json')==data(inv/'affine215-audit.json')
    assert (out/'affine/affine215-equations.json').read_bytes()==(inv/'affine215-equations.json').read_bytes()
    run([ROOT/'research/source/reproduce_source_variants.py','--candidate',BASE,'--output',out/'source-variants'])
    drop=ROOT/'research/source/increment-drop'
    run([drop/'reconstruct_increment_drop.py','--candidate',BASE,'--output',out/'increment-drop'])
    assert data(out/'increment-drop/source-recipe-receipt.json')==data(drop/'source-recipe-receipt.json')
    run([drop/'check_increment_drop_contracts.py','--output',out/'increment-drop/compiler-contracts.json'])
    assert data(out/'increment-drop/compiler-contracts.json')==data(drop/'compiler-contracts.json')
    if a.full:
        run([BASE/'code/runtime-inputs/validate_native.py',MACHINE/'k215-rho6.native.tm',MACHINE/'sites215-rho6.json',out/'full-runtime'])
        full=data(out/'full-runtime/runtime.json')
        assert full['status']=='UNIVERSAL_MATHEMATICAL_PASS' and full['proved_cases']==6176
        assert data(out/'full-runtime/startup.json')==data(startup)
        assert data(out/'full-runtime/runtime_cases.json')==cases
    if a.spares:
        run([ROOT/'research/spares/spare_runtime.py',BASE/'k215.native.tm','--sites',BASE/'sites215.json','--output',out/'spare-runtime'])
        spare=data(out/'spare-runtime/result.json')
        assert spare['status']=='UNIVERSAL_MATHEMATICAL_PASS' and spare['proved_cases']==6176
        assert spare['startup']['status']=='CALIBRATED_DIRTY_ROOT_SEED'
        assert spare['startup']['registers']==[4,0,0,0,0,0,0,0,0]
    summary={'status':'PASS','target_214_achieved':False,'released_working_states':215,'manifest_files_checked':manifest_count,'output_directory':str(out),'full_quantified_runtime_regenerated':a.full,'spare_runtime_regenerated':a.spares,'aggregate':aggregate}
    put(out/'reproduction.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
