#!/usr/bin/env python3
"""Unproved calculus price: swap A/B only in rho8's actual formula operands.
The independent numeric U=D then satisfies U<=the row's NEW B. No proof claimed.
"""
from pathlib import Path
import sys,json,hashlib
b=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(b));import source_language as s
r=s.tree(json.loads((b/'sites215.json').read_text()));ranges=[(214,240),(267,293),(346,372)];cur=0;changes=[]
def change(t):
 global cur
 if s.leaf(t):
  i=cur;cur+=1;op,k=t
  if any(a<=i<bb for a,bb in ranges)and op in ('CI','CD')and k in(4,5):changes.append(i);return(op,9-k)
  return t
 return change(t[0]),change(t[1])
nr=change(r);rr=s.sites(nr);assert s.graph_intervals(rr)==s.graph_arithmetic(rr)[0];payload=json.dumps(rr,separators=(',',':'))+'\n';Path('hypothetical_rho8_swap_a_b_sites.json').write_text(payload)
rec={'status':'HYPOTHETICAL CALCULUS: NO EQUICONSISTENCY PROOF','new_row':'L(oldB,oldA,C,U), with U=old D <= oldA = new row B','changed_intervals':ranges,'changed_primitives':changes,'metrics':s.metrics(nr),'sha256':hashlib.sha256(payload.encode()).hexdigest()};Path('hypothetical_rho8_swap_a_b_receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
