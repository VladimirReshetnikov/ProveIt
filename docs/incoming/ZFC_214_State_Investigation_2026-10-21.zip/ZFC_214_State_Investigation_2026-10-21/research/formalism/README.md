# Formalism and exact-source research

This directory contains ordinary mathematical proofs and finite source experiments against the pinned K215 baseline. It contains **no claimed 214-state Turing machine** and no newly compiled Lean theorem.

## Positive mathematical results

- formalism_reductions.tex states the inherited global-validity invariant, reproduces Source 154's all-tag inverse-detachment proof with attribution, derives the atomic stopping criterion, and explains a candidate-boundary stopping criterion.
- residual_dominated.tex gives a new strong compiler for parameter-free MP while retaining the additive dominated AX interface A=d+x, B=h+y, U=d. AX retains the comparison residual max(C−A−1,0). The preliminary zeroing setter, exact protected-stack contracts, cofinal enumeration encoding, and literal source linkage are proved. Its exact source is 207DAG, not 207 working TM states.
- additional_searches.tex includes the ordinary all-natural guarded-decrement NIP equivalence, the deferred-cleanup comparator proof, exact finite source censuses, and carefully labelled unproved schema experiments.
- AtomicHalt.lean is an **UNCOMPILED PROPOSED SUPPLEMENT**. It is supplied for review only; the ordinary atomic-refutation proof is in the TeX and atomic_halt.md.

The newer increment-DROP parameter-free interface, when included in this deliverable, is documented by the source research package separately.

## Deterministic replay

Run these from the archive root; Python3 and its standard library suffice:

    python research/formalism/check_residual215.py
    python research/formalism/replay_final_censuses.py --out verification/formalism

The first command checks 1600 literal changed-gate cases and 250 full MP cases and both source control-flow resolvers. These finite checks supplement the ordinary all-natural proof; they are not a binary runtime certificate.

The second command repeats all 279936 schema parameter choices, both 5040 row-order censuses, and 2560 guarded-NIP cases. It writes separate outputs and accepts --baseline for another copy of the same pinned source. Its script enforces the expected minima and tie count for the parameter census. The row receipts state exact fixed association scaffolds.

To regenerate the source-only residual variants:

    python research/formalism/residual215_probe.py

That search emits additional JSON sources explicitly labelled by calibration status in residual215_receipt.json; some are **unproved research prices**. Only the new proved dominated x-residual source is retained in the archive. Do not treat every emitted variant as a calibrated consistency machine.

## Computed-selector check

fresh_selector.tex proves that the exact choices C=A+B+1 and C=max(A,B)+1 collapse the seed matrix to a unary relation; HF models all resulting bundles, so they lose the required consistency strength. Bundle-only fixed roles (0,1), C>=2, or the lower bound C>=A+B+1 retain the semantic seed strength. Their numerical-calculus calibration remains open because unrestricted membership-vacuity derivations are missing. fresh_selector_review.json records scope and pinned inputs.

seed_output_one.tex proves a calibrated alternative: specialize only the seed output role to1 while retaining the original membership-vacuity component and gate. The c1 exception is valid by irreflexivity; all required vacuity and fixed-role seed instances remain available. Fully fixing seed roles to0,1 without guarding c0 is explicitly rejected because the shadowing calculation fails at the empty set.

## Remaining experiments

The NIP and MP-tail synthesis scripts enumerate finite grammar families and apply bounded natural-input tests. A passing finite test is not an all-natural contract. The two suffix-retag scripts are time bounded and their exact number of visited roots may depend on execution speed. The row and parameter censuses are exhaustive only over their displayed finite families.

The comparator and NOP-padding sources did not obtain a smaller binary allocation. Source-node counts, primitive-occurrence counts, and physical working-state counts are distinct. The hypothetical_* scripts explore changes to the eighth row without claiming equiconsistency. The simple H-load variant only supplies theorem-valued fourth parameters.

Most search scripts write generated source JSONs beside the script; the older isolated probes write to the current directory. Run optional probes in a separate working copy if preserving frozen receipts matters. No script changes the packaged baseline.

## Dependencies and provenance

All Python source/CFG utilities are taken from baseline/candidate-k215; the research scripts default there by a relative path. The baseline source SHA256 is recorded in PROVENANCE.json. Two inherited comparator input datasets and prior Source 154/164 proof documents are preserved with exact attribution in that file and prior/. The main archive's LICENSE and NOTICE also apply. No third-party package or network fetch is required by these replay commands.
