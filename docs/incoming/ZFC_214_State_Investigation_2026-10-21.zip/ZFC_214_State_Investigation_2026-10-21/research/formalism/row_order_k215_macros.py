#!/usr/bin/env python3
"""All7! schema row orders in the exact K215 closed-atom source scaffold.
Each moved atom is closed; source pricing is not binary certification.
"""
from pathlib import Path
from functools import cache
import argparse,itertools,json,sys,time,hashlib
ap=argparse.ArgumentParser();ap.add_argument('--baseline',type=Path,default=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215'));ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'row_order_k215_macros');a=ap.parse_args();sys.path.insert(0,str(a.baseline));import source_language as s
rows=json.loads((a.baseline/'sites215.json').read_text());root=s.tree(rows)
ranges=[('G',479,888),('rho6',888,1171),('rho5',1171,1467),('rho4',1467,1766),('rho3',1766,2062),('rho2',2062,2412),('rho1',2412,2643)]
@cache
def size(t):return 1 if s.leaf(t)else size(t[0])+size(t[1])
@cache
def boundary(t):return s.boundary(t)
macros=set()
def collect(t,lo=0):
 hi=lo+size(t)
 if 479<=lo and hi<=2643 and size(t) in (20,26,27) and boundary(t)==(0,0,False):macros.add(t)
 if not s.leaf(t):collect(t[0],lo);collect(t[1],lo+size(t[0]))
collect(root);macros.add(('CI',1));assert len(macros)==6
pos=[]
def record(t,lo=0,p=''):
 hi=lo+size(t)
 if hi<=479 or lo>=2643:return
 inside=any(x<=lo and hi<=y for _,x,y in ranges)
 closed=boundary(t)==(0,0,False)
 splitclosed=not s.leaf(t) and boundary(t[0])==boundary(t[1])==(0,0,False)
 if inside and t in macros:pos.append((p,t,lo,hi));return
 if s.leaf(t):raise ValueError((p,t,lo,hi,boundary(t)))
 record(t[0],lo,p+'0');record(t[1],lo+size(t[0]),p+'1')
record(root);words=[]
for name,lo,hi in ranges:
 w=[t for _,t,l,h in pos if lo<=l and h<=hi];assert sum(map(size,w))==hi-lo;words.append(w)
print('closed atoms',len(pos),'per row',list(map(len,words)),flush=True)
bnodes=[];bid={}
def base(t):
 key=t if s.leaf(t) else(base(t[0]),base(t[1]))
 if key not in bid:bid[key]=len(bnodes);bnodes.append(key)
 return bid[key]
broot=base(root);B=len(bnodes);pm={p:i for i,(p,*_)in enumerate(pos)}
def template(t,p=''):
 if p in pm:return('var',pm[p])
 if s.leaf(t):return('const',base(t))
 aa,bb=template(t[0],p+'0'),template(t[1],p+'1')
 if aa[0]==bb[0]=='const':return('const',bid[(aa[1],bb[1])])
 return('pair',aa,bb)
tr=template(root);wid=[[base(t)for t in w]for w in words];assert len(bnodes)==B

def evaluate(word):
 ns=list(bnodes);idx=dict(bid)
 def ins(k):
  if k not in idx:idx[k]=len(ns);ns.append(k)
  return idx[k]
 def realize(t):
  if t[0]=='const':return t[1]
  if t[0]=='var':return word[t[1]]
  return ins((realize(t[1]),realize(t[2])))
 n=realize(tr);seen=set();todo=[n]
 while todo:
  k=todo.pop()
  if k in seen:continue
  seen.add(k);v=ns[k]
  if isinstance(v[0],int):todo.extend(v)
 @cache
 def decode(k):
  v=ns[k];return v if isinstance(v[0],str)else(decode(v[0]),decode(v[1]))
 return len(seen),lambda:decode(n)
assert evaluate(sum(wid,[]))[0]==202
a.out.mkdir(parents=True,exist_ok=True);best=999;hist={};records=[];start=time.monotonic()
for trial,perm in enumerate(itertools.permutations(range(7)),1):
 score,decode=evaluate(sum((wid[k]for k in perm),[]));hist[score]=hist.get(score,0)+1
 if score<best:best=score;records=[]
 if score==best:
  t=decode();met=s.metrics(t);assert met['dag_nodes']==score;rr=s.sites(t);assert s.graph_arithmetic(rr)[0]==s.graph_intervals(rr)
  rec={'trial':trial,'permutation':perm,'row_order':[ranges[k][0]for k in perm],'metrics':met};records.append(rec)
  if score<=201 or len(records)<=10:(a.out/f'candidate{trial:05d}.json').write_text(json.dumps(rr,separators=(',',':'))+'\n')
  print('MIN',rec,flush=True)
result={'trials':trial,'best':best,'histogram':hist,'minimum_records':records,'seconds':time.monotonic()-start,'row_intervals':ranges,'closed_atom_counts':list(map(len,words)),'baseline_sha256':hashlib.sha256((a.baseline/'sites215.json').read_bytes()).hexdigest(),'scope':'All7! row orders in exact K215 inherited closed-macro scaffold; same complete axiom schemas, different stack order. No physical runtime or startup.'}
(a.out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('DONE',trial,best,result['seconds'],flush=True)
