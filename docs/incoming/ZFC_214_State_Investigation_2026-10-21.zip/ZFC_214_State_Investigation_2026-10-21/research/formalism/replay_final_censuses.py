#!/usr/bin/env python3
"""Portable replay of the exact K215 parameter/row censuses and guarded NIP.

Use --baseline /path/to/candidate-k215 from the pinned ProveIt revision.
No third-party Python package is needed. Finite time-bounded comparator
searches are separate and are not included in this deterministic replay.
"""
import argparse,importlib.util,json,runpy,sys
from pathlib import Path
here=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--baseline',type=Path,default=here.parents[1]/'baseline/candidate-k215')
ap.add_argument('--out',type=Path,default=here/'replay')
args=ap.parse_args();args.baseline=args.baseline.resolve();args.out.mkdir(parents=True,exist_ok=True)
for name in ('sites215.json','source_language.py'):
 if not(args.baseline/name).is_file():raise FileNotFoundError(args.baseline/name)
spec=importlib.util.spec_from_file_location('parameter_search',here/'parameter_search_k215.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
r=mod.search(args.baseline/'sites215.json');assert(r['trials'],r['best_dag_nodes'],len(r['minimum_choices']))==(279936,202,4)
(args.out/'parameter_search_k215_result.json').write_text(json.dumps(r,indent=2)+'\n')
for script,outdir in [('row_order_k215.py','row_order_k215'),('row_order_k215_macros.py','row_order_k215_macros'),('nip_decrement_generic.py','nip')]:
 sys.argv=[str(here/script),'--baseline',str(args.baseline),'--out',str(args.out/outdir)]
 runpy.run_path(str(here/script),run_name='__main__')
print('REPLAY COMPLETE: both exhaustive row-order censuses and all parameter choices remain at202 source nodes.')
