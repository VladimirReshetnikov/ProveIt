import sys,json
from pathlib import Path
b=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(b));import source_language as s
r=s.tree(json.loads((b/'sites215.json').read_text()));n=s.subtree(r,'111');pop=n[1][1]
clear=(('CD',5),('CC',1));test=(n[0],n[1][0]);r=s.replace(r,'111',(clear,pop));f=s.subtree(r,'01')
print('base',s.metrics(r));print('test',s.metrics(test),s.boundary(test))
for name,q in [('prefix',(test,f)),('suffix',(f,test)),('middle',((f[0],test),f[1])),('middle2',(f[0],(test,f[1]))),('prefix2',((test,f[0]),f[1]))]:
 rr=s.replace(r,'01',q);print(name,s.metrics(rr),s.boundary(q));Path(f'boundary_halt_{name}.json').write_text(json.dumps(s.sites(rr),separators=(',',':'))+'\n')
