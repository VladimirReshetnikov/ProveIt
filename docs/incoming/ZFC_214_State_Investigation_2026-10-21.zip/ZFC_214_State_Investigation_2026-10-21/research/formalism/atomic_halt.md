# Halting on any native membership atom

## Exact calibration theorem

Let C be the accepted unrestricted C222 native numerical calculus, with
Cantor pairing P(a,b), R(a,b)=4P(a,b)+1, falsum F=1=R(0,0),
and truth 0. Let D be the accepted dominated-rho8 calculus used by K215.
The accepted finite rho8 certificate establishes D(n) iff C(n) for every
natural n. Then, by ordinary reasoning formalizable in ZFC,

    (exists n, D(n) and n mod 4 = 1) iff D(1)
                                      iff ZFC is syntactically inconsistent.

No decoding or well-formedness assumption about n is needed. The residue
condition itself gives n=4q+1; bijectivity of Cantor pairing gives unique
natural a,b with q=P(a,b), hence n=R(a,b).

## Direct native proof through the existing completeness interface

For any fixed natural a,b suppose C(R(a,b)). Apply the repository theorem
`KEind222.c222_complete` with the singleton named theory

    T(f) :<=> f = NF.rel a b.

Its interpreted-code premise holds because KEind222.th fixes relation
atoms, and Code254.enc(NF.rel a b)=R(a,b). To discharge its no-model
premise, take any carrier D0, relation mem, irreflexivity proof, and
valuation e:N->D0. If T holds under all valuations, apply its unique
relation axiom at the constant valuation e0(n)=e(0). This says
mem(e(0),e(0)), contradicting irreflexivity. The supplied valuation is
also the explicit nonemptiness witness, so this proof does not misuse
empty-domain semantics.

Thus C(R(a,b)) implies C(F). The reverse is also available: the accepted
`KCode222.c222_efq` derives I(F,R(a,b)), and one MP with C(F) derives
C(R(a,b)). Only the forward direction is needed for the modified halting
test. Both directions quantify over all natural a,b, including a=b.

This route avoids a blanket syntactic renaming or substitution rule,
which would be unsafe to assume in the private-code-coupled native bundle.
It uses the exact, already proved equality interpretation and completeness
interface; relation atoms are unchanged by that interpretation.

## Source-machine consequence

Change only the NIP halt condition from h=1 to h mod 4=1. Every other
command and every formula value remains unchanged. The accepted soundness
invariant still shows that the cache h is a native theorem whenever the
halt condition is tested. The lemma above turns any new early halt into a
native refutation and then into a ZFC refutation.

For completeness, take the accepted finite program compiling a derivation
of F. Follow its execution in the modified interpreter until it either
halts earlier or reaches its old final test. Before any new early halt,
all command effects agree with the original interpreter. An early halt is
already successful; otherwise the old final cache is F=1, which satisfies
the new residue test. Thus every compiled refutation still halts. All
arithmetic termination, proof-pointer draining and cofinal padding facts
are inherited, provided the new destructive NIP routine has the exact
nonhalting postcondition of clearing the old cache and performing its
ordinary stack pop. Its binary runtime and blank initialization require
separate certificates.

The finite compiler's ordinary return-or-halt contracts therefore survive
without revising its selection counts, reset blocks, or command packing.
In fact each newly generated AX entry has residue 0 (logical row or bundle)
or 2 (generalization), so the standard cleanup sequences cannot acquire a
new halt on an axiom batch. Premise blocks may now halt earlier on a native
membership theorem; that is justified by the same lemma.

## Source references

- `Computability/BusyBeaver/Lean/BusyBeaver/ZFC/KEind222.lean`,
  theorem `c222_complete`, exact singleton-theory interface.
- `Computability/BusyBeaver/Lean/BusyBeaver/ZFC/KCode222.lean`,
  theorem `c222_efq` and the definition of C222.
- `Computability/BusyBeaver/Research/ZFC/candidate-k218/alternatives/dominated/proof.md`,
  all-natural equality of dominated and unrestricted theorem sets.
- `Computability/BusyBeaver/Research/ZFC/candidate-k215/proof.md`,
  command/source/runtime calibration of the unchanged parent.

Inspected repository pin: c8029f50d324910a36694c39a1e62f5720c36f4c.
This file contains an ordinary mathematical proof. The adjacent proposed
Lean lemma has not yet been compiled in this research session.
