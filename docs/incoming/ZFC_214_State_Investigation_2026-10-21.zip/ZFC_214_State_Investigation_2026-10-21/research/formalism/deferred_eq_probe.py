#!/usr/bin/env python3
"""Delay destructive equality cleanup until its scratch-neutral consequent returns."""
import sys,json,functools
from pathlib import Path
P=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(P));import source_language as s
out=Path(__file__).resolve().parent;root=s.tree(json.loads((P/'sites215.json').read_text()));eq=s.subtree(root,'111')[1][0][0]
D=lambda r:('CD',r);I=lambda r:('CI',r);CC=lambda k:('CC',k);CB=('CB',1)
@functools.cache
def shapes(n):
 if n==1:return[None]
 return[(a,b)for k in range(1,n)for a in shapes(k)for b in shapes(n-k)]
def fill(sh,atoms):
 it=iter(atoms)
 def f(t):return next(it)if t is None else(f(t[0]),f(t[1]))
 return f(sh)
def change(t,swap,mode,sh):
 if s.leaf(t):return t
 if t[0]==eq:
  h,x=(6,5)if swap else(5,6)
  A=(D(h),((D(x),CC(2)),I(x)))
  G=((D(x),CB),change(t[1],swap,mode,sh))
  hclear=(D(h),CC(1));xclear=(D(x),CC(1))
  if mode==0:blocks=[A,G,hclear,xclear]
  if mode==1:blocks=[A,G,xclear,hclear]
  if mode==2:blocks=[A,G,(hclear,(D(x),CC(2)))]
  if mode==3:blocks=[A,G,(xclear,(D(h),CC(2)))]
  if mode==4:blocks=[A,G,(A,(D(x),CC(2)))]
  return fill(sh,blocks)
 return tuple(change(z,swap,mode,sh)for z in t)
rows=[]
for swap in(False,True):
 for mode in range(5):
  for i,sh in enumerate(shapes(4 if mode<2 else 3)):
   new=change(root,swap,mode,sh);ss=s.sites(new);assert s.graph_intervals(ss)==s.graph_arithmetic(ss)[0]
   bad=[(j,p,o,a)for j,(p,o,a)in enumerate(ss)if(o=='CD'and p.endswith('1'))or(o=='CB'and a==1 and p.endswith('11'))]
   r={'swap':swap,'mode':mode,'shape':i,'metrics':s.metrics(new),'bad':bad};rows.append(r)
   if r['metrics']['dag_nodes']<=206:
    fn=f'deferred_eq_{int(swap)}_{mode}_{i}.json';(out/fn).write_text(json.dumps(ss,separators=(',',':'))+'\n');r['source']=fn
receipt={'minimum':min(r['metrics']['dag_nodes']for r in rows),'results':rows,'status':'ORDINARY_ALL_NATURAL_CALLER_CONTRACT_IN_additional_searches.tex; NO_BINARY_RUNTIME'}
(out/'deferred_eq_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for r in sorted(rows,key=lambda r:(r['metrics']['dag_nodes'],len(r['bad']))):
 print(r['swap'],r['mode'],r['shape'],r['metrics'],'bad',len(r['bad']),r.get('source'))
