# Guarding the generic comparator by decrementing the cache

The old K215 NIP is `CI6; if EQ(6,5) then HALT; POP`, where register6
initially vanishes. The ten-leaf inherited comparator clears both operands,
continues into its consequent exactly on equality, and skips that consequent
otherwise. POP assumes the cache and scratches are zero and returns the
head of the theorem stack in cache5.

Replace it at source path `111` by

```
((CD5, (EQ(6,5), CH)), POP).
```

More precisely, if `old` is the old NIP tree, the new tree is
`((('CD',5),old[1][0]),old[1][1])`.
The outer decrement's zero exit skips the entire comparator-and-halt block.

This has exactly the same NIP function for all natural register inputs at
a clean command boundary:

* If H=0, the decrement takes its zero exit. Cache5 and scratch6 are already
  zero, so POP has exactly its original clean input and returns normally.
* If H=1, the decrement leaves cache5=0. The inherited comparator compares
  zero with zero and enters CH. Both implementations halt.
* If H>=2, the decrement leaves a positive cache5. The inherited comparator
  compares it with zero, clears5 and6, and skips CH. POP again has exactly
  its original clean input.

The top, stack, counter and proof-pointer behavior is thus identical, and
no new command compiler or numerical-calculus argument is needed. This is
an ordinary all-natural macro proof using the inherited comparator and pop
contracts. It does not assert a new physical implementation.

The full source remains at202 distinct subtrees,4751 primitive occurrences,
maximum depth47, and maximum zero run6. The companion script regenerates the
source, checks equality of two complete source-graph resolvers, and compares
old and new NIP behavior on2560 finite inputs. That replay supplements the
ordinary proof and is not an unbounded binary-runtime certificate.
