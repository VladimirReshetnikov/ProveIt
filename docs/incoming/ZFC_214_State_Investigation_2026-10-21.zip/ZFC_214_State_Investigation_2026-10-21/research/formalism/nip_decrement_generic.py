#!/usr/bin/env python3
"""Exact-one NIP via a guarded decrement and the inherited zero-scratch comparator.

The all-natural proof is in nip_decrement_generic.md. This finite replay is a
regression check, not an independent unbounded primitive or binary certificate.
"""
import argparse,hashlib,json,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--baseline',type=Path,default=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215'));ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args();sys.path.insert(0,str(a.baseline));import source_language as s
rows=json.loads((a.baseline/'sites215.json').read_text());root=s.tree(rows);old=s.subtree(root,'111')
assert old[0]==('CI',6) and old[1][0][1]==('CH',None)
new=((('CD',5),old[1][0]),old[1][1]);changed=s.replace(root,'111',new);newrows=s.sites(changed)
assert s.graph_intervals(newrows)==s.graph_arithmetic(newrows)[0]
def run(t,rr):
 n=len(s.sites(t));g=s.graph_intervals(s.sites((t,('CH',None))));pc=0;r=list(rr)
 for _ in range(1000000):
  if pc==n:return 'return',r
  (op,*ar),js=g[pc]
  if op=='halt':return 'halt',None
  if op=='increment':r[ar[0]]+=1;pc=js[0]
  elif op=='decrement':
   nz=r[ar[0]]>0
   if nz:r[ar[0]]-=1
   pc=js[nz]
  else:pc=js[0]
 raise RuntimeError('finite replay cap')
checked=0
for h in range(40):
 for w in range(64):
  r=[3,17,w,0,13,h,0,0,21]
  x,y=run(old,r),run(new,r)
  assert x==y,(r,x,y);checked+=1
payload=json.dumps(newrows,separators=(',',':'))+'\n';a.out.mkdir(parents=True,exist_ok=True);(a.out/'decrement_generic_sites.json').write_text(payload)
receipt={'source_metrics':s.metrics(changed),'compared_nip_inputs':checked,'two_graph_resolvers_agree':True,'sha256':hashlib.sha256(payload.encode()).hexdigest(),'status':'ALL_NATURAL_ORDINARY_NIP_EQUIVALENCE; FINITE_SOURCE_REPLAY; NO_NEW_BINARY_RUNTIME'}
(a.out/'nip_decrement_generic_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
