import sys,json
from pathlib import Path
b=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(b));import source_language as s
r=s.tree(json.loads((b/'sites215.json').read_text()));n=s.subtree(r,'111');pop=n[1][1];unp=pop[0]
clear=(('CD',5),('CC',1));D=('CD',6);I=('CI',5);B=('CB',1);H=('CH',None);C=('CC',2);transfer=(D,(I,C))
tails={'firsttest':(D,((D,((I,I),(transfer,B))),H)), 'interleave':(D,(I,((D,(I,(transfer,B))),H)))}
for name,tail in tails.items():
 for j,nn in enumerate([(clear,(unp,tail)),((clear,unp),tail)]):
  rr=s.replace(r,'111',nn);print(name,j,s.metrics(rr),s.boundary(nn));Path(f'pop_halt_{name}{j}.json').write_text(json.dumps(s.sites(rr),separators=(',',':'))+'\n')
