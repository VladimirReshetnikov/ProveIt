#!/usr/bin/env python3
import sys,json,itertools
from pathlib import Path
p=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(p));import source_language as s
out=Path(__file__).resolve().parent
root=s.tree(json.loads((p/'sites215.json').read_text())); old=s.subtree(root,'111')[1][0][0]
def tt(t):return tuple(tt(x) if isinstance(x,list) else x for x in t)
def swap(n):
 if s.leaf(n):return(n[0],11-n[1]) if n[0] in ('CD','CI') and n[1] in (5,6) else n
 return tuple(map(swap,n))
def replace(n,a,b):
 if n==a:return b
 if s.leaf(n):return n
 return tuple(replace(x,a,b) for x in n)
def bad(t):
 return [(i,p,op,arg) for i,(p,op,arg) in enumerate(s.sites(t)) if (op=='CD' and not p.endswith('0')) or(op=='CB' and arg==1 and not p.endswith('01'))]
h={}
for name in ['eq_clean_hits.json','eq_dag6_hits.trees.json']:
 for i,v in enumerate(json.loads((out/name).read_text())):
  t=tt(v)
  for swapped in (False,True):
   if swapped:t=swap(t)
   h.setdefault(t,(name,i,swapped))
rr=[]
for t,(name,i,swapped) in h.items():
 new=replace(root,old,t)
 row={'name':name,'index':i,'swap':swapped,'metrics':s.metrics(new),'bad':bad(new),'eqbad':bad(t)}
 rr.append(row)
 if row['metrics']['dag_nodes']<=204 or len(row['bad'])<=7:
  fn=f'eq_suffix_{name.split(".")[0]}_{i}_{int(swapped)}.json'
  (out/fn).write_text(json.dumps(s.sites(new),separators=(',',':'))+'\n')
  row['source']=fn
(out/'eq_suffix_old_variants_receipt.json').write_text(json.dumps(rr,indent=2)+'\n')
for r in sorted(rr,key=lambda x:(len(x['bad']),x['metrics']['dag_nodes'])):
 print(r['name'],r['index'],r['swap'],r['metrics'], 'bad',len(r['bad']), 'eqbad',r['eqbad'])
