#!/usr/bin/env python3
"""All-CD-left Boolean comparator; every candidate is source-level only."""
import sys,json,functools
from pathlib import Path
p=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(p));import source_language as s
out=Path(__file__).resolve().parent;root=s.tree(json.loads((p/'sites215.json').read_text()));eq=s.subtree(root,'111')[1][0][0]
D=lambda r:('CD',r);I=lambda r:('CI',r);CC=lambda n:('CC',n)
a=(D(5),((D(6),CC(2)),I(5)))
transfer=(D(6),(I(5),CC(2)))
clear=(D(5),CC(1))
b=(D(5),(D(6),clear))
blocks=[a,transfer,I(6),b]
@functools.cache
def shapes(n):
 if n==1:return [None]
 return [(x,y)for k in range(1,n)for x in shapes(k)for y in shapes(n-k)]
def fill(sh,leaves):
 it=iter(leaves)
 def f(t):return next(it)if t is None else(f(t[0]),f(t[1]))
 return f(sh)
def change(t,sh):
 if s.leaf(t):return t
 if t[0]==eq:return fill(sh,blocks+[(D(6),change(t[1],sh))])
 return tuple(change(x,sh)for x in t)
def run(t,h,x):
 rr=[0]*9;rr[5]=h;rr[6]=x
 tt=(t,(('CI',3),('CH',None)));gg=s.graph_intervals(s.sites(tt));pc=0
 for step in range(10000):
  (o,*args),js=gg[pc]
  if o=='halt':return rr
  if o=='increment':rr[args[0]]+=1;pc=js[0]
  elif o=='decrement':
   nz=rr[args[0]]>0
   if nz:rr[args[0]]-=1
   pc=js[nz]
  else:pc=js[0]
 raise ValueError('cap')
pre=fill(shapes(4)[0],blocks)
for h in range(40):
 for x in range(40):
  rr=run(pre,h,x);assert rr[5]==0 and rr[6]==int(h==x),(h,x,rr)
rows=[]
for i,sh in enumerate(shapes(5)):
 new=change(root,sh);ss=s.sites(new)
 assert s.graph_intervals(ss)==s.graph_arithmetic(ss)[0]
 bad=[(j,p,o,a)for j,(p,o,a)in enumerate(ss)if(o=='CD'and not p.endswith('0'))or(o=='CB'and a==1 and not p.endswith('01'))]
 r={'shape':i,'metrics':s.metrics(new),'bad_suffixes':bad};rows.append(r)
 if r['metrics']['dag_nodes']<=205:
  fn=f'boolean_eq_{i}_sites.json';(out/fn).write_text(json.dumps(ss,separators=(',',':'))+'\n');r['source']=fn
receipt={'checked_inputs':1600,'status':'ORDINARY_BOOLEAN_COMPARATOR_CONTRACT_PLUS_FINITE_SOURCE_REPLAY_NO_BINARY_CERTIFICATE','candidates':rows}
(out/'boolean_eq_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'minimum':min(r['metrics']['dag_nodes']for r in rows),'candidates':[(r['shape'],r['metrics']['dag_nodes'],len(r['bad_suffixes']))for r in rows]},indent=2))
