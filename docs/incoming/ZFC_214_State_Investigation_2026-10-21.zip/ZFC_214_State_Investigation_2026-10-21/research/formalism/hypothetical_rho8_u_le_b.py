#!/usr/bin/env python3
"""Source price ONLY. No equivalence proof for the proposed U<=B calculus."""
from pathlib import Path
import sys,json,hashlib
b=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(b));import source_language as s
r=s.tree(json.loads((b/'sites215.json').read_text()));p='1101001001101';load=s.subtree(r,p);assert len(s.sites(load))==26
changed=[]
def rename(t):
 if s.leaf(t):
  op,k=t
  if op in ('CI','CD') and k==4:changed.append((op,k));return(op,5)
  return t
 return rename(t[0]),rename(t[1])
nr=s.replace(r,p,rename(load));rr=s.sites(nr);assert s.graph_arithmetic(rr)[0]==s.graph_intervals(rr)
payload=json.dumps(rr,separators=(',',':'))+'\n';Path('hypothetical_rho8_u_le_b_sites.json').write_text(payload)
rec={'status':'HYPOTHETICAL FORMALISM ONLY: NO EQUICONSISTENCY PROOF','old_U':'old counter D; U<=A','new_U':'old theorem cache H; U<=B','modified_source_path':p,'modified_interval':[133,159],'changed_primitives':changed,'metrics':s.metrics(nr),'sha256':hashlib.sha256(payload.encode()).hexdigest()};Path('hypothetical_rho8_u_le_b_receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
