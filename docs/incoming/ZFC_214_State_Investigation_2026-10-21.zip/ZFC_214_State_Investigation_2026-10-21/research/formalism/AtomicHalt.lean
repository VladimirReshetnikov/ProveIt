-- UNCOMPILED PROPOSED SUPPLEMENT: not a proof-assistant certificate.
import BusyBeaver.ZFC.KEind222

/-!
An atomic-membership halting criterion for the numerical C222 calculus.
The proof uses the existing equality-interpretation completeness theorem;
it assumes no arbitrary substitution operation on native theorem codes.
This new file is a proposed small formalization, not yet compiled here.
-/

namespace SetTheory.BusyBeaver.ZFC.AtomicHalt

open Tarski Code254 KCode222 KEind222

 theorem falsum_of_membership {a b : Nat} (h : C222 (wel a b)) : C222 F := by
  apply c222_complete (fun f => f = NF.rel a b)
  · intro f hf
    subst f
    simpa [th, enc] using h
  · intro D mem hirr hT e
    have hself := hT (NF.rel a b) rfl (fun _ => e 0)
    exact hirr (e 0) hself

 theorem membership_iff_falsum (a b : Nat) : C222 (wel a b) ↔ C222 F := by
  constructor
  · exact falsum_of_membership
  · intro h
    exact C222.mp h (c222_efq (wel a b))

#print axioms falsum_of_membership
#print axioms membership_iff_falsum

end SetTheory.BusyBeaver.ZFC.AtomicHalt
