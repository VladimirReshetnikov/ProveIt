#!/usr/bin/env python3
"""Bounded exact-CFG rotations targeting the state-302 entry suffix."""
import json,sys,time,random,functools
from pathlib import Path
P=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(P));import source_language as s
out=Path(__file__).resolve().parent
orig=s.tree(json.loads((out/'eq_suffix_eq_dag6_hits_9_0.json').read_text()))
N=[];lookup={}
def intern(a,b=None):
 key=a if b is None else(a,b)
 if key not in lookup:lookup[key]=len(N);N.append(key)
 return lookup[key]
def lf(n):return isinstance(N[n][0],str)
def toid(t):return intern(t) if s.leaf(t) else intern(toid(t[0]),toid(t[1]))
root0=toid(orig)
@functools.cache
def totr(n):return N[n] if lf(n) else tuple(map(totr,N[n]))
@functools.cache
def size(n):return 1 if lf(n) else sum(map(size,N[n]))
@functools.cache
def sem(n):
 out=[]
 def go(q,i,zs,os):
  if lf(q):
   o,a=N[q]
   if o in('CD','CB'):
    aa=1 if o=='CD' else a;v=zs[-aa] if aa<=len(zs) else('ext',aa-len(zs))
   elif o=='CC':v=os[-a] if a<=len(os) else('ext',a-len(os))
   else:v=None
   out.append((o,a,v));return
  a,c=N[q];go(a,i,zs+[i+size(q)],os);go(c,i+size(a),zs,os+[i])
 go(n,0,[],[]);return tuple(out)
@functools.cache
def rotate(n,d):
 a,c=N[n]
 if d=='L':
  if lf(c):return None
  bb,cc=N[c];r=intern(intern(a,bb),cc)
 else:
  if lf(a):return None
  aa,bb=N[a];r=intern(aa,intern(bb,c))
 old=sem(n)
 def go(q,i,zs,os):
  if lf(q):
   o,a,v=old[i]
   if o in('CD','CB','CC'):
    ar=zs if o in('CD','CB')else os
    if isinstance(v,tuple):aa=len(ar)+v[1]
    else:
     if v not in ar:raise ValueError
     aa=1+ar[::-1].index(v)
    if o=='CD':
     actual=ar[-1]if ar else('ext',1)
     if actual!=v:raise ValueError
    else:
     if o=='CB'and aa!=1:raise ValueError
     if o=='CC'and aa>3:raise ValueError
     a=aa
   return intern((o,a))
  a,c=N[q];return intern(go(a,i,zs+[i+size(q)],os),go(c,i+size(a),zs,os+[i]))
 try:return go(r,0,[],[])
 except ValueError:return None
def replace(r,old,new):
 @functools.cache
 def go(n):
  if n==old:return new
  if lf(n):return n
  return intern(*map(go,N[n]))
 return go(r)
def infos(r):
 reach=set()
 def go(n):
  if n in reach:return
  reach.add(n)
  if not lf(n):
   for c in N[n]:go(c)
 go(r);return reach
@functools.cache
def suffixbad(n,p=''):
 if lf(n):
  o,a=N[n];return int((o=='CD' and not p.endswith('0')) or(o=='CB' and a==1 and not p.endswith('01')))
 return suffixbad(N[n][0],(p+'0')[-2:])+suffixbad(N[n][1],(p+'1')[-2:])
start=time.monotonic();duration=45;rng=random.Random(30240);root=root0;seen={root};step=0
best=(suffixbad(root),len(infos(root)));bestroot=root0;observed=[];basecfg=s.graph_intervals(s.sites(orig))
while time.monotonic()-start<duration:
 cand=[]
 for n in infos(root):
  if lf(n):continue
  for d in('L','R'):
   nn=rotate(n,d)
   if nn is None:continue
   rr=replace(root,n,nn)
   if rr in seen:continue
   seen.add(rr);cost=len(infos(rr))
   if cost>205:continue
   bad=suffixbad(rr);cand.append((bad,cost,rr,n,d))
 if not cand:root=root0;seen={root};continue
 b=min((x[0],x[1])for x in cand)
 if b<best:
  best=b;bestroot=next(x[2]for x in cand if(x[0],x[1])==b)
  t=totr(bestroot);ss=s.sites(t);assert s.graph_intervals(ss)==basecfg==s.graph_arithmetic(ss)[0]
  observed.append({'bad':b[0],'dag':b[1],'step':step,'seconds':time.monotonic()-start})
  (out/f'suffix_retag_{b[0]}bad_{b[1]}dag.json').write_text(json.dumps(ss,separators=(',',':'))+'\n')
  print('BEST',observed[-1],flush=True)
 scores=[x for x in cand if x[0]<=b[0]+(1 if rng.random()<.15 else 0) and x[1]<=b[1]+1]
 choice=rng.choice(scores);root=choice[2];step+=1
 if step%100==0:print('step',step,'best',best,'elapsed',time.monotonic()-start,flush=True)
receipt={'best_bad_suffixes':best[0],'best_dag_nodes':best[1],'duration_seconds':time.monotonic()-start,'steps':step,'visited_roots':len(seen),'observations':observed,'status':'FINITE_ROTATION_SEARCH_NOT_IMPOSSIBILITY'}
(out/'suffix_retag_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
