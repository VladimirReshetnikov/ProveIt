#!/usr/bin/env python3
"""Transplant Source164's proved residual-parameter command interface into K215."""
import sys,json,functools,hashlib
from pathlib import Path
P=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(P));import source_language as s
out=Path(__file__).resolve().parent;root=s.tree(json.loads((P/'sites215.json').read_text()))
D=lambda r:('CD',r);I=lambda r:('CI',r);CC=lambda k:('CC',k)
transfer=lambda a,b:(D(a),(I(b),CC(2)))
@functools.cache
def size(t):return 1 if s.leaf(t)else size(t[0])+size(t[1])
intervals={}
def scan(t,p='',lo=0):
 intervals[lo,lo+size(t)]=p
 if not s.leaf(t):scan(t[0],p+'0',lo);scan(t[1],p+'1',lo+size(t[0]))
scan(root)
up='1101001001101';eqp='110100100111100';mpp='110100101000'
u=s.subtree(root,up);eq=s.subtree(root,eqp);mppre=s.subtree(root,mpp)
assert size(u)==26 and size(mppre)==40 and mppre[1][1]==u
ar=intervals[200,240];aread=s.subtree(root,ar);assert s.boundary(aread)==(0,0,False)
def residual(t,which):
 if which=='h':return s.replace(t,eqp+'10',transfer(5,4))
 if which=='x':return s.replace(t,eqp+'110',transfer(6,4))
 if which=='both':
  return s.replace(s.replace(t,eqp+'10',transfer(5,4)),eqp+'110',transfer(6,4))
def compile(which,absolute):
 t=root;t=s.replace(t,mpp,u);t=residual(t,which)
 if absolute=='consume':t=s.replace(t,up,(u[0],transfer(4,1)))
 elif absolute=='clear_before_read':t=s.replace(t,ar,((D(4),CC(1)),aread))
 elif absolute=='clear_after_U':t=s.replace(t,up,(u,(D(4),CC(1))))
 elif absolute=='clear_after_walk':t=s.replace(t,ar,(aread[0],((D(4),CC(1)),aread[1])))
 return t
records=[]
for which in('h','x','both'):
 for absolute in('keep_dominated','consume','clear_before_read','clear_after_U','clear_after_walk'):
  t=compile(which,absolute);ss=s.sites(t);assert s.graph_intervals(ss)==s.graph_arithmetic(ss)[0]
  fn=f'residual215_{which}_{absolute}.json';(out/fn).write_text(json.dumps(ss,separators=(',',':'))+'\n')
  calibration=('NEW_DOMINATED_COMPILER_IN_residual_dominated.tex' if which=='x' and absolute=='keep_dominated' else 'INHERITED_SOURCE164_ABSOLUTE_A_COMPILER' if which in ('h','x') and absolute!='keep_dominated' else 'UNPROVED_RESEARCH_PRICE_ONLY')
  r={'residual':which,'absolute_A':absolute,'source':fn,'metrics':s.metrics(t),'calibration':calibration};records.append(r);print(r,flush=True)
receipt={'source164_attribution':'K215_Construction_and_Research_2026-10-21/theory/residual_parameter_compiler.tex','mp_prefix_path':mpp,'U_load_path':up,'second_EQ_path':eqp,'A_read_path':ar,'baseline_sha256':hashlib.sha256((P/'sites215.json').read_bytes()).hexdigest(),'results':records,'status':'SOURCE164_INTERFACE_TRANSPLANTS_AND_NEW_DOMINATED_X_INTERFACE; SEE_PER_VARIANT_CALIBRATION; NO_BINARY_RUNTIME'}
(out/'residual215_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
