#!/usr/bin/env python3
"""Hash-consed NOP insertion census; all padding junk is verified unreachable."""
import sys,json,functools,itertools,time
from pathlib import Path
P=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(P));import source_language as s
out=Path(__file__).resolve().parent
N=[];index={}
def intern(a,b=None):
 key=a if b is None else(a,b)
 if key not in index:index[key]=len(N);N.append(key)
 return index[key]
def lf(n):return isinstance(N[n][0],str)
def toid(t):return intern(t)if s.leaf(t)else intern(toid(t[0]),toid(t[1]))
@functools.cache
def totr(n):return N[n]if lf(n)else tuple(map(totr,N[n]))
@functools.cache
def boundary(n):
 if lf(n):
  op,a=N[n]
  return(1,0,False)if op=='CD'else(a,0,False)if op=='CB'else(0,a,False)if op=='CC'else(0,0,op=='CH')
 a,b=map(boundary,N[n]);return(max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2])
def closed(n):return boundary(n)==(0,0,False)
def replace(r,old,new):
 @functools.cache
 def f(n):
  if n==old:return new
  if lf(n):return n
  return intern(*map(f,N[n]))
 return f(r)
def reach(n):
 seen=set();todo=[n]
 while todo:
  q=todo.pop()
  if q in seen:continue
  seen.add(q)
  if not lf(q):todo.extend(N[q])
 return seen
def forest(n,limit=5):
 if lf(n):return[n]
 a,b=N[n]
 if closed(a)and closed(b):
  aa,bb=forest(a),forest(b)
  if len(aa)+len(bb)<=limit:return aa+bb
 return[n]
@functools.cache
def shapes(n):
 if n==1:return[None]
 return[(a,b)for k in range(1,n)for a in shapes(k)for b in shapes(n-k)]
def fill(sh,atoms):
 it=iter(atoms)
 def f(t):return next(it)if t is None else intern(f(t[0]),f(t[1]))
 return f(sh)
NOP=toid((('CB',1),('CH',None)))
def safe(n):
 t=totr(n);rows=s.sites(t);g=s.graph_intervals(rows);assert g==s.graph_arithmetic(rows)[0]
 seen=set();todo=[0]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(g[i][1])
 bad=[i for i,(p,op,a)in enumerate(rows)if i in seen and((op=='CD'and p.endswith('1'))or(op=='CB'and a==1 and p.endswith('11')))]
 junk=[]
 def f(n,p=''):
  if n==NOP:junk.append(p+'1');return
  if not lf(n):
   f(N[n][0],p+'0');f(N[n][1],p+'1')
 f(n);ids={p:i for i,(p,*_)in enumerate(rows)}
 assert all(ids[p]not in seen for p in junk)
 return rows,len(bad),len(junk)
roots={'baseline':toid(s.tree(json.loads((P/'sites215.json').read_text()))),'comparator9':toid(s.tree(json.loads((out/'eq_suffix_eq_dag6_hits_9_0.json').read_text())))}
records=[];stored=set();start=time.monotonic();summaries=[]
for name,root in roots.items():
 best=999;tested=0
 for n in reach(root):
  if not closed(n):continue
  ff=forest(n)
  for j in range(len(ff)+1):
   atoms=ff[:j]+[NOP]+ff[j:]
   for sh in shapes(len(atoms)):
    rr=replace(root,n,fill(sh,atoms))
    if rr in stored:continue
    stored.add(rr);tested+=1;cost=len(reach(rr))
    if cost<=best:
     if cost<best:best=cost;print('NEW',name,best,'trial',tested,flush=True)
     if cost<=203 or (cost==204 and sum(r['base']==name for r in records)<20):
      ss,bad,occ=safe(rr);fn=f'nop_padding_{name}_{len(records)}_{cost}.json'
      (out/fn).write_text(json.dumps(ss,separators=(',',':'))+'\n')
      records.append({'source':fn,'base':name,'metrics':s.metrics(totr(rr)),'bad_suffixes':bad,'nop_occurrences':occ,'right_junk_cfg_unreachable':True})
 summaries.append({'base':name,'minimum_dag_nodes':best,'trials':tested});print('DONE',summaries[-1],'seconds',time.monotonic()-start,flush=True)
r={'trials_distinct':len(stored),'summaries':summaries,'records':records,'seconds':time.monotonic()-start,'status':'EXACT_CLOSED_ATOM_INSERTION_PLUS_UNREACHABLE_RIGHT_NOP; SOURCE_ONLY_NO_NEW_BINARY_RUNTIME'}
(out/'nop_padding_receipt.json').write_text(json.dumps(r,indent=2)+'\n')
