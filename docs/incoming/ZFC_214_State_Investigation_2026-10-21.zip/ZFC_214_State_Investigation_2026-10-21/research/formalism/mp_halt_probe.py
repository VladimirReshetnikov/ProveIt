import sys,json
from pathlib import Path
base=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')
sys.path.insert(0,str(base));import source_language as s
root=s.tree(json.loads((base/'sites215.json').read_text()));nip=s.subtree(root,'111');pop=nip[1][1]
clear=(('CD',5),('CC',1)); nr=s.replace(root,'111',(clear,pop))
old=s.subtree(nr,'11010010111')
D=('CD',4);I=('CI',5);B=('CB',1);H=('CH',None);C=('CC',2)
transfer=(D,(I,C))
test1=(D,((D,((I,I),(transfer,B))),H))
test2=(D,(I,((D,(I,(transfer,B))),H)))
print('oldsuccess',s.metrics(old));print('removeNIP',s.metrics(nr))
for label,test in [('firsttest',test1),('interleave',test2)]:
 changed=s.replace(nr,'11010010111',test)
 print(label,s.metrics(changed),s.boundary(test),test)
 p=Path(__file__).resolve().parent/f'mp_halt_{label}.json';p.write_text(json.dumps(s.sites(changed),separators=(',',':'))+'\n')
