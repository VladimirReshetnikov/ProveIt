#!/usr/bin/env python3
"""Price only: swap A/B register roles after fourth-parameter capture.
U is old numeric D; A is old H+x; B is old D+y, so U<=B. No calibration proved.
"""
from pathlib import Path
import json,sys,hashlib
b=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(b));import source_language as s
r=s.tree(json.loads((b/'sites215.json').read_text()));cur=0;changes=[]
def change(t):
 global cur
 if s.leaf(t):
  i=cur;cur+=1;op,k=t
  if 159<=i<4590 and op in ('CI','CD') and k in (4,5):changes.append(i);return(op,9-k)
  return t
 return change(t[0]),change(t[1])
nr=change(r);rr=s.sites(nr);assert s.graph_intervals(rr)==s.graph_arithmetic(rr)[0]
payload=json.dumps(rr,separators=(',',':'))+'\n';Path('hypothetical_rho8_u_le_b_numeric_sites.json').write_text(payload)
rec={'status':'HYPOTHETICAL FORMALISM: NO EQUICONSISTENCY PROOF','numeric_relation':'U=old D; A=old H+x; B=old D+y; U<=B','interval':[159,4590],'changed_primitive_count':len(changes),'metrics':s.metrics(nr),'sha256':hashlib.sha256(payload.encode()).hexdigest()};Path('hypothetical_rho8_u_le_b_numeric_receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
