from functools import cache
from pathlib import Path
import sys,json,itertools
b=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(b));import source_language as s
r=s.tree(json.loads((b/'sites215.json').read_text()));n=s.subtree(r,'111');pop=n[1][1];clear=(('CD',5),('CC',1));r=s.replace(r,'111',(clear,pop));f=s.subtree(r,'0');guard=f[0];copy,restore=f[1];inc=n[0];cond=n[1][0]
@cache
def shapes(xs):
 if len(xs)==1:return (xs[0],)
 return tuple((a,b) for i in range(1,len(xs)) for a in shapes(xs[:i]) for b in shapes(xs[i:]))
best=999;records=[]
for word in [(guard,inc,cond,copy,restore),(guard,copy,restore,inc,cond)]:
 ref=(guard,((inc,cond),(copy,restore))) if word[1]==inc else (guard,((copy,restore),(inc,cond)))
 refs=s.sites((ref,('CH',None)));refg=s.graph_intervals(refs)
 for k,t in enumerate(shapes(word)):
  if s.boundary(t)!=(0,0,True):continue
  if s.graph_intervals(s.sites((t,('CH',None))))!=refg:continue
  rr=s.replace(r,'0',t);m=s.metrics(rr);records.append({'shape':k,'order':word[1]==inc,'metrics':m})
  if m['dag_nodes']<=best:
   best=m['dag_nodes'];print('BEST',records[-1],flush=True);Path(f'boundary_halt_assoc_{len(records)}.json').write_text(json.dumps(s.sites(rr),separators=(',',':'))+'\n')
Path('boundary_halt_association_result.json').write_text(json.dumps({'minimum':best,'passing_associations':len(records),'records':records},indent=2)+'\n')
