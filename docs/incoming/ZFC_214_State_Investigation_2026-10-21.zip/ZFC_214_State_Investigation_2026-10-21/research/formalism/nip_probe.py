import sys,json
from pathlib import Path
base=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')
sys.path.insert(0,str(base)); import source_language as s
root=s.tree(json.loads((base/'sites215.json').read_text()))
old=s.subtree(root,'111')
print('old subtree',old)
print('old metrics',s.metrics(root)); print('old local metrics',s.metrics(old))
# clean stack pop is original final subexpression, inspect
print('local sites',s.sites(old))
D=('CD',5); B=('CB',1); C=('CC',1); H=('CH',None)
clear=(D,C); test=(D,((D,(clear,B)),H))
# preserve exact original pop continuation (root right)
print('old children',[(s.metrics(x),s.boundary(x))for x in old])
pop=old[1][1] if old[0]==('CI',6) else None
print('pop',pop)
if pop:
 new=(test,pop)
 changed=s.replace(root,'111',new)
 print('new metrics',s.metrics(changed));print('test graph',s.graph_intervals(s.sites(new)))
 (Path(__file__).resolve().parent/'nip_specialized_sites.json').write_text(json.dumps(s.sites(changed),separators=(',',':'))+'\n')
