import sys,json,itertools,time
from pathlib import Path
from functools import cache
base=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')
sys.path.insert(0,str(base));import source_language as s
root=s.tree(json.loads((base/'sites215.json').read_text()));nip=s.subtree(root,'111');pop=nip[1][1]
root=s.replace(root,'111',((('CD',5),('CC',1)),pop))
D=('CD',4);I=('CI',5);H=('CH',None);T=(D,(I,('CC',2)));E=('CI',0)
def nodes(t,ans=None):
 if ans is None:ans=set()
 if t in ans:return ans
 ans.add(t)
 if not s.leaf(t):nodes(t[0],ans);nodes(t[1],ans)
 return ans
@cache
def trees(xs):
 if len(xs)==1:return (xs[0],)
 return tuple((a,b)for i in range(1,len(xs))for a in trees(xs[:i])for b in trees(xs[i:]))
def run(g,n):
 pc=0;steps=0;h=0
 while steps<1000:
  if pc==9:return ('normal',n,h)
  eff,tar=g[pc]
  if eff[0]=='halt':return ('halt',)
  if eff[0]=='decrement':
   assert eff[1]==4
   if n:n-=1;pc=tar[1]
   else:pc=tar[0]
  elif eff[0]=='increment':
   assert eff[1]==5;h+=1;pc=tar[0]
  elif eff[0]=='identity':pc=tar[0]
  else:raise RuntimeError(eff)
  steps+=1
 return ('loop',)
start=time.monotonic();tested=0;closed=0;passed=0;best=999;survivors=[]
for bl in range(1,5):
 B=('CB',bl)
 for seq0 in set(itertools.permutations((D,I,I,T,B,H))):
  seq=(D,)+seq0
  for test in trees(seq):
   tested+=1
   if s.boundary(test)[:2]!=(0,0):continue
   closed+=1
   g=s.graph_intervals(s.sites((test,E)))
   if any(run(g,n)!=(('halt',)if n==1 else('normal',0,n))for n in range(10)):continue
   passed+=1;new=s.replace(root,'11010010111',test);cost=len(nodes(new))
   if cost<best:best=cost;survivors=[];print('NEW',cost,test,flush=True)
   if cost==best:survivors.append(test)
report={'tested':tested,'closed':closed,'bounded_pass':passed,'best_DAG':best,'survivors':survivors,'seconds':time.monotonic()-start,'scope':'bounded screening only until explicit all-natural proof'}
out=Path(__file__).resolve().parent
(out/'mp_tail_synthesis_result.json').write_text(json.dumps(report,indent=2)+'\n')
for i,test in enumerate(survivors[:40]):(out/f'mp_tail_synth_{i}.json').write_text(json.dumps(s.sites(s.replace(root,'11010010111',test)),separators=(',',':'))+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='survivors'}),flush=True)
