#!/usr/bin/env python3
"""Independent deferred-comparison associations at all four audited callers."""
from pathlib import Path
import sys,json,functools,itertools,time
P=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(P));import source_language as s
out=Path(__file__).resolve().parent;scope={'__file__':str(out/'deferred_eq_probe.py')};exec((out/'deferred_eq_probe.py').read_text().split('rows=[]')[0],scope)
root,eq,change,shapes=map(scope.get,('root','eq','change','shapes'))
N=[];index={}
def intern(a,b=None):
 key=a if b is None else(a,b)
 if key not in index:index[key]=len(N);N.append(key)
 return index[key]
def lf(n):return isinstance(N[n][0],str)
def toid(t):return intern(t)if s.leaf(t)else intern(toid(t[0]),toid(t[1]))
@functools.cache
def totr(n):return N[n]if lf(n)else tuple(map(totr,N[n]))
def cost(r):
 seen=set();todo=[r]
 while todo:
  q=todo.pop()
  if q in seen:continue
  seen.add(q)
  if not lf(q):todo.extend(N[q])
 return len(seen)
choices=[(False,m,i,sh)for m in range(5)for i,sh in enumerate(shapes(4 if m<2 else 3))]
paths=[];options=[]
def template(t,p=''):
 if s.leaf(t):return('const',toid(t))
 if t[0]==eq:
  k=len(paths);paths.append(p);options.append([toid(change(t,swap,m,sh))for swap,m,i,sh in choices]);return('var',k)
 a,b=template(t[0],p+'0'),template(t[1],p+'1')
 return('const',intern(a[1],b[1]))if a[0]==b[0]=='const'else('pair',a,b)
templ=template(root)
def assemble(t,v):
 if t[0]=='const':return t[1]
 if t[0]=='var':return options[t[1]][v[t[1]]]
 return intern(assemble(t[1],v),assemble(t[2],v))
start=time.monotonic();best=999;ties=[];hist={}
for trial,v in enumerate(itertools.product(range(len(choices)),repeat=4),1):
 rr=assemble(templ,v);cc=cost(rr);hist[cc]=hist.get(cc,0)+1
 if cc<best:best=cc;ties=[];print('MIN',best,v,'trial',trial,flush=True)
 if cc==best:ties.append(v)
for i,v in enumerate(ties[:10]):
 t=totr(assemble(templ,v));ss=s.sites(t);assert s.graph_intervals(ss)==s.graph_arithmetic(ss)[0]
 (out/f'deferred_eq_independent_{i}_{best}.json').write_text(json.dumps(ss,separators=(',',':'))+'\n')
r={'trials':trial,'minimum':best,'tie_count':len(ties),'first_ties':ties[:100],'choices':[(a,b,c)for a,b,c,_ in choices],'paths':paths,'histogram':hist,'seconds':time.monotonic()-start,'status':'EXACT_SOURCE_CENSUS_WITH_AUDITED_SCRATCH_NEUTRAL_CALLERS; NO_BINARY_RUNTIME'}
(out/'deferred_eq_independent_receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
