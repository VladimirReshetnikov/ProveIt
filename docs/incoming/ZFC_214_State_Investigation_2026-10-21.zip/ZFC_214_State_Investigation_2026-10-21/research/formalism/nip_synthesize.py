import sys,json,itertools,time
from pathlib import Path
from functools import cache
base=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')
sys.path.insert(0,str(base));import source_language as s
root=s.tree(json.loads((base/'sites215.json').read_text()));old=s.subtree(root,'111');pop=old[1][1]
D=('CD',5);H=('CH',None);E=('CI',0)
def nodes(t,ans=None):
 if ans is None:ans=set()
 if t in ans:return ans
 ans.add(t)
 if not s.leaf(t):nodes(t[0],ans);nodes(t[1],ans)
 return ans
@cache
def trees(xs):
 if len(xs)==1:return (xs[0],)
 return tuple((a,b)for i in range(1,len(xs))for a in trees(xs[:i])for b in trees(xs[i:]))
@cache
def bound(t):return s.boundary(t)
def run(g,n):
 pc=0;steps=0
 while steps<1000:
  if pc==6:return ('normal',n)
  eff,tar=g[pc]
  if eff[0]=='halt':return ('halt',n)
  if eff[0]=='decrement':
   if n:n-=1;pc=tar[1]
   else:pc=tar[0]
  elif eff[0]=='identity':pc=tar[0]
  else:raise RuntimeError(eff)
  steps+=1
 return ('loop',n)
start=time.monotonic();tested=0;closed=0;passed=0;best=999;survivors=[]
for bc in itertools.product(range(1,5),repeat=2):
 B=('CB',bc[0]);C=('CC',bc[1])
 for seq in set(itertools.permutations((D,D,D,B,C,H))):
  for test in trees(seq):
   tested+=1
   if bound(test)[:2]!=(0,0):continue
   closed+=1
   g=s.graph_intervals(s.sites((test,E)))
   if any(run(g,n)!=(('halt',0)if n==1 else('normal',0))for n in range(10)):continue
   passed+=1
   new=s.replace(root,'111',(test,pop));cost=len(nodes(new))
   if cost<best:best=cost;survivors=[];print('NEW',cost,test,flush=True)
   if cost==best:survivors.append(test)
report={'tested':tested,'closed':closed,'bounded_pass':passed,'best_DAG':best,'survivors':survivors,'seconds':time.monotonic()-start,'scope':'bounded screening only until explicit all-natural proof'}
out=Path(__file__).resolve().parent
(out/'nip_synthesis_result.json').write_text(json.dumps(report,indent=2)+'\n')
for i,test in enumerate(survivors[:20]):(out/f'nip_synth_{i}.json').write_text(json.dumps(s.sites(s.replace(root,'111',(test,pop))),separators=(',',':'))+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='survivors'}),flush=True)
