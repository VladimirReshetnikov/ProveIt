#!/usr/bin/env python3
"""Finite source-level regressions for the dominated residual compiler.

The all-natural proof is residual_dominated.tex. This replays the literal
second gate and complete MP source, not a binary table or a Lean proof.
"""
import argparse,hashlib,json,sys
from pathlib import Path
here=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--baseline',type=Path,default=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215'))
ap.add_argument('--source',type=Path,default=here/'residual215_x_keep_dominated.json')
ap.add_argument('--out',type=Path,default=here/'residual215_finite_check.json')
a=ap.parse_args();sys.path.insert(0,str(a.baseline));import source_language as s
raw=a.source.read_bytes();root=s.tree(json.loads(raw));rows=s.sites(root)
assert s.graph_intervals(rows)==s.graph_arithmetic(rows)[0]
def runner(t):
 n=len(s.sites(t));g=s.graph_intervals(s.sites((t,('CH',None))))
 def go(rr):
  r=list(rr);pc=0
  for step in range(1000000):
   if pc==n:return r,step
   (op,*args),js=g[pc]
   if op=='halt':return None,step
   if op=='increment':r[args[0]]+=1;pc=js[0]
   elif op=='decrement':
    nz=r[args[0]]>0
    if nz:r[args[0]]-=1
    pc=js[nz]
   else:pc=js[0]
  raise RuntimeError('Finite regression cap exceeded')
 return go
gate=runner(s.subtree(root,'11010010011110'));checks=0;maxsteps=0
for A in range(40):
 for C in range(40):
  rr=[3,17,11,23,0,A,C,0,19]
  actual,steps=gate(rr);expected=list(rr);expected[1]=0 if A==C else 17
  expected[4]=max(C-A-1,0);expected[5]=expected[6]=0
  assert actual==expected,(A,C,actual,expected)
  checks+=1;maxsteps=max(maxsteps,steps)
P=lambda x,y:(x+y)*(x+y+1)//2+y
mp=runner(s.subtree(root,'110100101'));mpchecks=0
for t in range(5):
 for d in range(5):
  for w in range(5):
   for correct in(False,True):
    h=4*P(t,d)+(0 if correct else 1)
    rr=[3,t,w,0,d,h,0,0,17]
    actual,steps=mp(rr);expected=[3,d if correct else 0,P(0,w)if correct else w,0,d,0,0,0,17]
    assert actual==expected,(rr,actual,expected)
    mpchecks+=1;maxsteps=max(maxsteps,steps)
r={'source_sha256':hashlib.sha256(raw).hexdigest(),'source_metrics':s.metrics(root),'two_cfg_resolvers_agree':True,'literal_gate_cases':checks,'literal_MP_cases':mpchecks,'maximum_source_steps':maxsteps,'status':'FINITE_LITERAL_SOURCE_REPLAY; ordinary all-natural calibration in residual_dominated.tex; NO_BINARY_RUNTIME_OR_COMPILED_LEAN'}
a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
