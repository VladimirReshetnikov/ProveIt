#!/usr/bin/env python3
"""Independently check the finite inductive certificate (no fixed-point search)."""
import argparse, hashlib, json, sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,default=(Path(__file__).resolve().parents[2]/'baseline/candidate-k215'));p.add_argument('--certificate',type=Path,default=Path(__file__).with_name('invariant215.json'));p.add_argument('--output',type=Path,default=Path(__file__).with_name('invariant215-audit.json'));a=p.parse_args()
sys.path.insert(0,str(a.base/'code'));import source_language as lang
raw=(a.base/'sites215.json').read_bytes(); rows=json.loads(raw); C=json.loads(a.certificate.read_text()); M=C['masks']; G=lang.graph_intervals(rows)
assert G==lang.graph_arithmetic(rows)[0]
assert len(M)==len(rows)
for row in M:
 assert row is None or len(row)==9 and all(isinstance(x,int) and 0<x<512 for x in row)
seed=[4,0,0,0,0,0,0,0,0]
assert all(M[0][r]&(1<<v) for r,v in enumerate(seed))
def transfer(mask,delta):
 # Bucket 8 denotes all integers >=8; enumerate exact abstract images.
 out=0
 for b in range(9):
  if mask&(1<<b):
   if b==8:out|=(1<<8)|((1<<7) if delta==-1 else 0)
   elif b+delta>=0:out|=1<<min(8,b+delta)
 return out
edges=0
for i,((path,op,r),(effect,tg)) in enumerate(zip(rows,G)):
 if M[i] is None or op=='CH':continue
 src=M[i]
 cases=[]
 if op=='CI':
  dst=list(src);dst[r]=transfer(src[r],1);cases.append((tg[0],dst))
 elif op=='CD':
  if src[r]&1:
   dst=list(src);dst[r]=1;cases.append((tg[0],dst))
  if src[r]&510:
   dst=list(src);dst[r]=transfer(src[r]&510,-1);cases.append((tg[1],dst))
 else:cases.append((tg[0],src))
 for j,dst in cases:
  assert M[j] is not None,(i,j,'target absent')
  assert all(x&~y==0 for x,y in zip(dst,M[j])),(i,j,'not inductive')
  edges+=1
summary={'status':'PASS','source_sha256':hashlib.sha256(raw).hexdigest(),'certificate_sha256':hashlib.sha256(a.certificate.read_bytes()).hexdigest(),'primitive_occurrences':len(rows),'checked_abstract_edges':edges,'dead_ordinals':[i for i,m in enumerate(M) if m is None],'forced_zero_ordinals':[i for i,(_,op,r)in enumerate(rows)if op=='CD'and M[i]is not None and M[i][r]==1],'domain':'0,...,7 singleton;8 represents all integers >=8','seed':seed}
a.output.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
