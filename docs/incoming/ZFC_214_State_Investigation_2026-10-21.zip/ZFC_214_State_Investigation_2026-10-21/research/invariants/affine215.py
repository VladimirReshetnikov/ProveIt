#!/usr/bin/env python3
"""Exact rational affine-hull invariant, represented by primitive integer bases.
All joins are span unions; zero guards intersect an exact linear hyperplane.
Positive guards are overapproximated by their affine hull, never sampled.
"""
from pathlib import Path
from collections import deque
from functools import reduce
from math import gcd
import sys,json,time
B=(Path(__file__).resolve().parents[2]/'baseline/candidate-k215');sys.path.insert(0,str(B/'code'));import source_language as s
rows=json.loads((B/'sites215.json').read_text());G=s.graph_intervals(rows);assert G==s.graph_arithmetic(rows)[0]
def primitive(v):
 g=reduce(gcd,v,0)
 if g:v=[x//g for x in v]
 if next((x for x in v if x),1)<0:v=[-x for x in v]
 return tuple(v)
def insert(base,v):
 v=list(v)
 for b in base:
  p=next(i for i,x in enumerate(b)if x)
  if v[p]:
   k=v[p];v=list(primitive([b[p]*x-k*y for x,y in zip(v,b)]))
 if not any(v):return False
 v=primitive(v);p=next(i for i,x in enumerate(v)if x)
 j=0
 while j<len(base)and next(i for i,x in enumerate(base[j])if x)<p:j+=1
 base.insert(j,v);return True
def hyperplane(base,k):
 u=next((b for b in base if b[k]),None)
 if u is None:return base
 vv=[]
 for b in base:
  if b is u:continue
  v=[u[k]*x-b[k]*y for x,y in zip(b,u)];insert(vv,primitive(v))
 return vv if any(b[0]for b in vv)else []
def constant(base,k):
 b0=next((b for b in base if b[0]),None)
 if b0 is None:return None
 if all(b[k]*b0[0]==b[0]*b0[k]for b in base):return(b0[k],b0[0])
 return None
A=[[]for _ in rows];A[0]=[(1,4,0,0,0,0,0,0,0,0)];Q=deque([0]);pending={0};steps=0;beg=time.monotonic()
while Q:
 i=Q.popleft();pending.remove(i);base=A[i];path,op,r=rows[i];_,tg=G[i];outs=[]
 if op=='CH':continue
 if op in('CI','CD'):
  k=r+1
  if op=='CI':outs=[(tg[0],[primitive([x+(b[0]if j==k else 0)for j,x in enumerate(b)])for b in base])]
  else:
   z=hyperplane(base,k)
   if z:outs.append((tg[0],z))
   c=constant(base,k)
   if c is None or c[0]>0:outs.append((tg[1],[primitive([x-(b[0]if j==k else 0)for j,x in enumerate(b)])for b in base]))
 else:outs=[(tg[0],base)]
 for j,vs in outs:
  changed=False
  for v in vs:changed=insert(A[j],v)or changed
  if changed and j not in pending:Q.append(j);pending.add(j)
 steps+=1
 if steps%20000==0:print('STEPS',steps,'queue',len(Q),'seconds',round(time.monotonic()-beg,1),flush=True)
summary={'steps':steps,'seconds':time.monotonic()-beg,'dead':[i for i,b in enumerate(A)if not b],'forced_zero':[i for i,(p,op,r)in enumerate(rows)if op=='CD'and A[i]and constant(A[i],r+1)==(0,1)],'rank_histogram':{k:sum(len(b)==k for b in A)for k in range(11)},'constants':[{'i':i,'register':r,'value':c[0]//c[1]}for i,b in enumerate(A)if b for r in range(9)if(c:=constant(b,r+1))is not None and c[0]%c[1]==0]}
Path(__file__).with_name('affine215.json').write_text(json.dumps({'summary':summary,'bases':A}));print(json.dumps({k:v for k,v in summary.items()if k!='constants'},indent=2))
