from pathlib import Path
import sys,json,collections
BASE=(Path(__file__).resolve().parents[2]/'baseline/candidate-k215')
sys.path.insert(0,str(BASE/'code'))
import source_language as s
import build221 as b
rows=json.loads((BASE/'sites215.json').read_text());G=s.graph_intervals(rows);assert G==s.graph_arithmetic(rows)[0]
K=8; ALL=(1<<(K+1))-1
def inc(m):return ((m<<1)&ALL)|(m&(1<<K))
def dec(m):return (m>>1)|(m&(1<<K))
seed=[4,0,0,0,0,0,0,0,0]
S=[None]*len(rows);S[0]=[1<<min(v,K) for v in seed];Q=collections.deque([0]);inq={0};steps=0
while Q:
 i=Q.popleft();inq.remove(i);a=S[i];p,op,r=rows[i];eff,tgs=G[i];outs=[]
 if op=='CH':continue
 if op=='CI':z=a.copy();z[r]=inc(z[r]);outs=[(tgs[0],z)]
 elif op=='CD':
  if a[r]&1:z=a.copy();z[r]=1;outs.append((tgs[0],z))
  if a[r]&~1:z=a.copy();z[r]=dec(z[r]&~1);outs.append((tgs[1],z))
 else:outs=[(tgs[0],a)]
 for j,z in outs:
  old=S[j];new=z if old is None else [x|y for x,y in zip(old,z)]
  if old!=new:
   S[j]=new
   if j not in inq:Q.append(j);inq.add(j)
 steps+=1
zero=[i for i,(p,op,r) in enumerate(rows) if op=='CD' and S[i] is not None and S[i][r]==1]
dead=[i for i,z in enumerate(S) if z is None]
T=b.read_table((BASE/'k215.native.tm').read_bytes());tree=s.tree(rows);groups,paths=b.decoder_map(T,tree);pathq={p:q for q,ps in paths.items()for p in ps}
ans={'seed':seed,'steps':steps,'dead':dead,'forced_zero':[{'i':i,'site':rows[i],'reg_masks':S[i],'state':pathq.get(rows[i][0][:-1]),'targets':G[i][1]} for i in zero]}
print(json.dumps(ans,indent=2));Path(__file__).with_name('invariant215.json').write_text(json.dumps({'summary':ans,'masks':S}))
