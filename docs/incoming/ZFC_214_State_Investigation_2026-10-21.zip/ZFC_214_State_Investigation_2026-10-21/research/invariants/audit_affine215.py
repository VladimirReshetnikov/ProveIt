#!/usr/bin/env python3
"""Check affine certificate by exact Fraction reduction and emit nullspace equations."""
from pathlib import Path
from fractions import Fraction as F
from functools import reduce
from math import gcd,lcm
import json,sys,time,hashlib,argparse
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[2]/'baseline/candidate-k215');p.add_argument('--certificate',type=Path,default=Path(__file__).with_name('affine215.json'));p.add_argument('--output',type=Path,default=Path(__file__).parent);a=p.parse_args()
B=a.base;O=a.output;O.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(B/'code'));import source_language as s
raw=(B/'sites215.json').read_bytes();rows=json.loads(raw);G=s.graph_intervals(rows);assert G==s.graph_arithmetic(rows)[0];A=json.loads(a.certificate.read_text())['bases'];assert len(A)==len(rows)
def piv(b):return next(i for i,x in enumerate(b)if x)
def included(v,base):
 v=list(map(F,v))
 for b in base:
  k=piv(b);f=v[k]/b[k]
  if f:v=[x-f*y for x,y in zip(v,b)]
 return not any(v)
for base in A:
 assert all(len(b)==10 and any(b)and all(type(v)is int for v in b)for b in base)
 assert [piv(b)for b in base]==sorted(set(piv(b)for b in base))
 if base:assert piv(base[0])==0
assert included([1,4,0,0,0,0,0,0,0,0],A[0]);edges=0;vectors=0
for i,((_,op,r),(_,tg))in enumerate(zip(rows,G)):
 base=A[i]
 if not base or op=='CH':continue
 outs=[]
 if op=='CI':outs=[(tg[0],[[x+(b[0]if j==r+1 else 0)for j,x in enumerate(b)]for b in base])]
 elif op=='CD':
  k=r+1;u=next((b for b in base if b[k]),None)
  zeros=base if u is None else [[u[k]*x-b[k]*y for x,y in zip(b,u)]for b in base if b is not u]
  if any(b[0]for b in zeros):outs.append((tg[0],zeros))
  if any(b[k]for b in base):outs.append((tg[1],[[x-(b[0]if j==k else 0)for j,x in enumerate(b)]for b in base]))
 else:outs=[(tg[0],base)]
 for j,vs in outs:
  assert A[j]and all(included(v,A[j])for v in vs),(i,j,'not postfixed')
  edges+=1;vectors+=len(vs)
cache={}
def equations(base):
 key=tuple(tuple(b)for b in base)
 if key in cache:return cache[key]
 if not base:return [[1]+[0]*9]
 ps={piv(b)for b in base};ans=[]
 for free in range(10):
  if free in ps:continue
  z=[F(0)]*10;z[free]=F(1)
  for b in reversed(base):
   k=piv(b);z[k]=-sum((F(b[j])*z[j]for j in range(k+1,10)),F(0))/b[k]
  den=lcm(*(x.denominator for x in z));zz=[int(x*den)for x in z];gg=reduce(gcd,zz,0);zz=[x//gg for x in zz]
  if next(x for x in zz if x)<0:zz=[-x for x in zz]
  assert all(sum(x*y for x,y in zip(b,zz))==0 for b in base)
  ans.append(zz)
 cache[key]=ans;return ans
EE=[equations(b)for b in A];eqraw=json.dumps(EE).encode();(O/'affine215-equations.json').write_bytes(eqraw)
summary={'status':'PASS','source_sha256':hashlib.sha256(raw).hexdigest(),'certificate_sha256':hashlib.sha256(a.certificate.read_bytes()).hexdigest(),'equations_sha256':hashlib.sha256(eqraw).hexdigest(),'checked_guarded_edges':edges,'checked_basis_vectors':vectors,'equation_convention':'c[0] + sum(c[r+1]*register[r],r=0..8)=0; all equations hold at entry to source ordinal; [1,0,...,0] denotes unreachable.','nontrivial_relations':sum(any(sum(x!=0 for x in e[1:])>=2 for e in eqs)for eqs in EE)}
(O/'affine215-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
