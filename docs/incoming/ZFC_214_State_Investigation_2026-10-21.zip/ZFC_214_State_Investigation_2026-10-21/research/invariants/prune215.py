from pathlib import Path
import sys,json,itertools
BASE=(Path(__file__).resolve().parents[2]/'baseline/candidate-k215');sys.path.insert(0,str(BASE/'code'));import source_language as s
R=json.loads((BASE/'sites215.json').read_text());T=s.tree(R);G=s.graph_intervals(R)
variants={}
for a,b in itertools.product([False,True],repeat=2):
 t=T
 if a:t=s.replace(t,'110100101110',s.subtree(t,'110100101110')[1])
 if b:t=s.replace(t,'11110011',('CB',1))
 rr=s.sites(t);removed=set(([4671,4672,4673]if a else[])+([4733,4734]if b else[]));survive=[i for i in range(len(R))if i not in removed];inv={old:new for new,old in enumerate(survive)};gg=s.graph_intervals(rr)
 def resolve(i):
  while i in removed:i=G[i][1][0]
  return inv[i]
 valid=all(R[old][1:]==rr[new][1:] and [[G[old][0]],[list(map(resolve,G[old][1]))]]==[[gg[new][0]],[gg[new][1]]] for new,old in enumerate(survive))
 print(a,b,s.metrics(t),'graph remaining',valid)
 if a or b:
  f=Path(__file__).with_name('pruned'+str(int(a))+str(int(b))+'.json');f.write_bytes(s.compact(rr));variants[f.name]={'metrics':s.metrics(t),'graph_remaining':valid,'removed':sorted(removed)}
Path(__file__).with_name('pruned_summary.json').write_text(json.dumps(variants,indent=2))
