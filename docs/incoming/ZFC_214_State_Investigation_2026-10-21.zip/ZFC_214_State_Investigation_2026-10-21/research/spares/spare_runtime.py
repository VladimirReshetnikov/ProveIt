#!/usr/bin/env python3
"""Quantified primitive checker modulo an arbitrary nonempty spare suffix.
The first nine blocks and the complete source-control frame are exact.
Only the final spare list is quotiented by well-formedness, not observed values.
Mathematical symbolic evidence, not proof-assistant kernel checking.
"""
from pathlib import Path
import argparse, json, hashlib, sys, time, gzip
B=(Path(__file__).resolve().parents[2]/'baseline/candidate-k215')
sys.path.insert(0,str(B/'code/runtime-inputs/runtime'));import symbolic_runtime as s
sys.path.insert(0,str(B/'code/runtime-inputs'));import validate_native as v

def consume(actual, expected):
    """Exact prefix subtraction, with only proved nonnegative affine residuals."""
    aa=list(s.normal(actual));ee=list(s.normal(expected))
    while ee:
        if not aa:return None
        x,y=aa[0],ee[0]
        if x==y:aa.pop(0);ee.pop(0);continue
        if x[0]!='run' or y[0]!='run' or x[1]!=y[1]:return None
        d=s.add(x[2],s.neg(y[2]))
        if s.nonnegative(d):
            aa[0]=s.run(x[1],d);ee.pop(0)
            if d==s.ZERO:aa.pop(0)
        elif s.nonnegative(s.neg(d)):
            ee[0]=s.run(y[1],s.neg(d));aa.pop(0)
        else:return None
    return s.normal(aa)

def spare_word(atoms):
    """Recognize B* with at least one explicit B block, followed by zero exterior.
    A B-list atom may be empty. Every explicit block has one zero followed by
    an affine natural length whose constant is >=1; hence denotes B(v), v>=0.
    """
    aa=s.normal(atoms);explicit=0;i=0
    while i<len(aa)-1:
        x=aa[i]
        if x==('list','B','spare_tail',False):i+=1;continue
        # Appending ones to a known nonempty B-word only increases its last value.
        if x[0]=='run' and x[1]==1 and explicit>=1 and s.nonnegative(x[2]):i+=1;continue
        if x!=s.bit(0) or i+1>=len(aa):return False
        y=aa[i+1]
        if y[0]!='run' or y[1]!=1 or not s.nonnegative(y[2]) or y[2][0]<1:return False
        explicit+=1;i+=2
    return i==len(aa)-1 and aa[i]==s.BLANK and explicit>=1

def file_word(values):
    # Any nonempty spare list is uniquely a first value and possibly empty tail.
    out=[]
    for value in values:out+=s.block(value)
    return out+s.block(s.var(11))+[s.tail(),s.BLANK]

def case(table,lemmas,site,positive):
    pc,op,arg=site;values=[s.var(2+i)for i in range(9)]
    if op=='CD':values[arg]=s.add(s.num(1),values[arg])if positive else s.ZERO
    physical=[None]*9
    for i,j in enumerate(s.r.PHY):physical[j]=values[i]
    result=physical.copy();overflow=0;delta=0
    if op=='CI':result[s.r.PHY[arg]]=s.add(result[s.r.PHY[arg]],s.num(1));successor,overflow=s.r.inc(pc)
    elif op=='CD'and positive:result[s.r.PHY[arg]]=s.minus1(result[s.r.PHY[arg]]);successor,overflow=s.r.inc(pc);delta=1
    elif op in('CD','CB'):successor,overflow=s.r.inc(s.r.strip(pc,'0',arg if op=='CB'else 1))
    elif op=='CC':successor=s.r.strip(pc,'1',arg)
    elif op=='CH':successor=''
    else:raise AssertionError(site)
    st=s.State(96,[s.bit(1),s.BLANK],[s.bit(int(b))for b in pc]+[s.run(0,s.add(s.var(1),s.num(64-len(pc)))),s.bit(1)]+file_word(physical))
    prefix=[s.bit(int(b))for b in successor]+[s.run(0,s.add(s.var(1),s.num(64+delta+overflow-len(successor)))),s.bit(1)]
    for x in result:prefix+=s.block(x)
    left=s.normal([s.bit(1),s.BLANK]);clock=s.ZERO;motion=s.ZERO;rows=set();kinds={}
    for count in range(4000):
        key=st.key();suffix=None
        if count and op!='CH' and st.q==96 and st.direction==1 and st.left==left:
            suffix=consume(st.right,prefix)
        if count and ((op=='CH'and st.q==254)or(suffix is not None and spare_word(suffix))):
            assert s.nonnegative(clock)and clock[0]>0,('No positive progress',clock)
            if op!='CH':assert motion==s.num(-overflow),('Wrong head displacement',motion,overflow)
            return {'symbolic_steps':count,'duration':clock,'motion':motion,'rows':sorted(rows),'kinds':kinds,'spare_postcondition':suffix}
        clock,motion,event=st.step(table,lemmas,clock,motion);kinds[event[0]]=kinds.get(event[0],0)+1
        if event[0]!='list':rows.add(event[1][:2])
    raise AssertionError(('Symbolic proof did not close',site,positive,st.key()))

def main():
    p=argparse.ArgumentParser();p.add_argument('table',type=Path);p.add_argument('--sites',type=Path,default=B/'sites215.json');p.add_argument('--output',type=Path,required=True);p.add_argument('--limit',type=int);p.add_argument('--startup-limit',type=int,default=200000);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    raw=a.table.read_bytes();T=s.r.table(a.table);sites=json.loads(a.sites.read_text());states={q for q,b in T};assert len(T)==2*len(states)and all((q,b)in T for q in states for b in(0,1));assert {z for w,d,z in T.values()}-states=={254}
    m={int(k):int(vv)for k,vv in json.loads(v.MAPPATH.read_text()).items()}
    for q in states|{254}:
        if q not in m:m[q]=q+1000
    assert len({m[q]for q in states|{254}})==len(states)+1
    L={(m[q],bit):(w,d,m[z])for(q,bit),(w,d,z)in T.items()};beg=time.monotonic();lemmas,blocks=s.prove_blocks(L);answers=[];failure=None
    for i,site in enumerate(sites):
        for pos in((False,True)if site[1]=='CD'else(False,)):
            try:ans=case(L,lemmas,site,pos);answers.append({'site_index':i,'positive':pos,**ans})
            except Exception as e:failure={'site_index':i,'positive':pos,'reason':repr(e)};break
        if failure or(a.limit and len(answers)>=a.limit):break
        if(i+1)%1000==0:print('SITE',i+1,'CASES',len(answers),flush=True)
    total=sum(2 if row[1]=='CD'else 1 for row in sites);st=v.startup(T,a.startup_limit);trace=st.pop('trace',None)
    report={'status':'UNIVERSAL_MATHEMATICAL_PASS'if len(answers)==total and failure is None else'PARTIAL_OR_FAILURE','failure':failure,'working_states':len(states),'proved_cases':len(answers),'expected_cases':total,'table_sha256':hashlib.sha256(raw).hexdigest(),'sites_sha256':hashlib.sha256(a.sites.read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'symbolic_helper_sha256':hashlib.sha256(Path(s.__file__).read_bytes()).hexdigest(),'minimum_duration_constant':min((x['duration'][0]for x in answers),default=None),'symbolic_rules':sum(x['symbolic_steps']for x in answers),'seconds':time.monotonic()-beg,'scope':'All natural register values and gap; arbitrary finite nonempty spare list; full zero exterior. Exact source frame and register result, arbitrary well-formed nonempty spare suffix.','startup':st,'blocks':blocks}
    (a.output/'result.json').write_text(json.dumps(report,indent=2)+'\n');(a.output/'cases.json.gz').write_bytes(gzip.compress(json.dumps(answers).encode(),mtime=0));print(json.dumps({k:val for k,val in report.items()if k not in('blocks','startup')},indent=2),flush=True)
if __name__=='__main__':main()
