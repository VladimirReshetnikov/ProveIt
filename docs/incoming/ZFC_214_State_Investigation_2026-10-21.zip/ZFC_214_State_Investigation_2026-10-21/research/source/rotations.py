from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import sys,json,time
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')
sys.path[:0]=[str(K),str(K/'code')]
import source_language as s
import build221 as b
out=Path(__file__).resolve().parent
rows=json.loads((K/'sites215.json').read_text());old=s.tree(rows);T=b.read_table((K/'k215.native.tm').read_bytes());cfg=s.graph_intervals(rows)
occ=defaultdict(list)
def visit(n,p=''):
 occ[n].append(p)
 if not s.leaf(n):visit(n[0],p+'0');visit(n[1],p+'1')
visit(old)
print('metrics',s.metrics(old), 'unique',len(occ),flush=True)
def replace_all(n,a,z):
 if n==a:return z
 if s.leaf(n):return n
 return replace_all(n[0],a,z),replace_all(n[1],a,z)
res=[];counts=Counter()
for node,ps in list(occ.items()):
 if s.leaf(node):continue
 variants=[]
 if not s.leaf(node[0]):
  (A,B),C=node;variants.append(('right',(A,(B,C)),(A,B,C)))
 if not s.leaf(node[1]):
  A,(B,C)=node;variants.append(('left',((A,B),C),(A,B,C)))
 for direction,new,factors in variants:
  for mode in ['all']+(['single']if len(ps)>1 else []):
   for p in ps if mode=='single' else ps[:1]:
    tree=replace_all(old,node,new)if mode=='all' else s.replace(old,p,new)
    metr=s.metrics(tree);counts['total']+=1
    if metr['dag_nodes']>202:continue
    counts['node_ok']+=1
    nr=s.sites(tree)
    if s.graph_intervals(nr)!=cfg:continue
    try:
     if s.graph_arithmetic(nr)[0]!=cfg:continue
    except ValueError:continue
    counts['CFG_ok']+=1
    rec={'path':p,'direction':direction,'mode':mode,'metrics':metr,'closed':all(s.boundary(x)==(0,0,False)for x in factors)}
    res.append(rec)
    if metr['dag_nodes']<202:
     ix=len(res)-1;(out/f'rot-{ix:03}.json').write_bytes(s.compact(nr));print('SAVING',rec,flush=True)
(out/'rotations.json').write_text(json.dumps({'counts':counts,'results':res},indent=2)+'\n')
print('RESULT',counts,'best',min(x['metrics']['dag_nodes']for x in res)if res else None,flush=True)
