from pathlib import Path
import sys,json,importlib.util,contextlib,io,time
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path[:0]=[str(K),str(K/'code')];import source_language as s
O=Path(__file__).resolve().parent;D=O/'neutral-allocation';D.mkdir(exist_ok=True)
old=s.tree(json.loads((K/'sites215.json').read_text()))
def replace_all(n,a,z):
 if n==a:return z
 if s.leaf(n):return n
 return replace_all(n[0],a,z),replace_all(n[1],a,z)
spec=importlib.util.spec_from_file_location('alloc',O/'allocate215.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
items=json.loads((O/'rotations.json').read_text())['results'];records=[];started=time.monotonic()
for i,rec in enumerate(items):
 n=s.subtree(old,rec['path'])
 if rec['direction']=='right':(A,B),C=n;new=(A,(B,C))
 else:A,(B,C)=n;new=((A,B),C)
 trial=replace_all(old,n,new)if rec['mode']=='all'else s.replace(old,rec['path'],new)
 src=D/f'source{i:03}.json';src.write_bytes(s.compact(s.sites(trial)));out=D/f'trial{i:03}'
 sys.argv=['allocate215.py','--source',str(src),'--output',str(out),'--limit','2']
 try:
  with(out.with_suffix('.log')).open('w')as log,contextlib.redirect_stdout(log):a.main()
  r=json.loads((out/'allocation.json').read_text());brief={k:r.get(k)for k in ['status','states','new_nodes','fixed_nodes','protected_rows','removed','prefix_count']};brief['index']=i;records.append(brief)
  print(brief,flush=True)
  if r.get('status')=='PREFIX_PASS'and r.get('states',999)<=214:print('FOUND214',i,flush=True);break
 except Exception as e:records.append({'index':i,'error':str(e)});print('ERROR',i,type(e).__name__,str(e),flush=True)
(D/'results.json').write_text(json.dumps(records,indent=2)+'\n');print('DONE',len(records),time.monotonic()-started,flush=True)
