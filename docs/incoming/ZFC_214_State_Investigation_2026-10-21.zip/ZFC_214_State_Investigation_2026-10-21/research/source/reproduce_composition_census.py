#!/usr/bin/env python3
"""Recreate all 632 recorded source compositions, without rerunning MILP.

The default only writes a receipt. --emit-sources additionally materializes
80 neutral rotations, 280 selector/cache compositions and 352 NIP compositions
under --output. The sources and all-natural calibration are distinct from
physical TM acceptance; recorded allocation negatives are constrained results.
"""
import argparse,hashlib,json,sys
from pathlib import Path

def main():
    here=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--candidate',type=Path,default=here.parents[1]/'baseline/candidate-k215')
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--emit-sources',action='store_true')
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    sys.path[:0]=[str(args.candidate/'code'),str(args.candidate/'research/composition-allocation')]
    import source_language as s,source_splice as sp
    raw=(args.candidate/'sites215.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
    old=s.tree(json.loads(raw));oldcfg=s.graph_intervals(s.sites(old))
    def rep(n,a,b):
        if n==a:return b
        return n if s.leaf(n) else (rep(n[0],a,b),rep(n[1],a,b))
    neutral=[]
    for i,r in enumerate(json.loads((here/'recorded/rotations.json').read_text())['results']):
        n=s.subtree(old,r['path'])
        if r['direction']=='right':(a,b),c=n;new=(a,(b,c))
        else:a,(b,c)=n;new=((a,b),c)
        t=rep(old,n,new) if r['mode']=='all' else s.replace(old,r['path'],new)
        assert s.metrics(t)==r['metrics']
        assert s.graph_intervals(s.sites(t))==oldcfg==s.graph_arithmetic(s.sites(t))[0]
        neutral.append((f'neutral-allocation/source{i:03}.json',t))
    retags=[('retag-output/'+p.name,s.tree(json.loads(p.read_text())))for p in sorted((here/'retag-output').glob('*.json'))]
    commutes=[(f'commute-{i}.json',s.tree(json.loads((here/f'commute-{i}.json').read_text())))for i in range(2)]
    prefix=[('baseline/sites215.json',old)]+neutral+retags
    bases=prefix+commutes
    short=(('CD',4),(('CI',5),('CC',2)))
    compositions=[];comp_records=[];seen=set()
    def save(rel,t):
        rr=s.sites(t);assert s.graph_intervals(rr)==s.graph_arithmetic(rr)[0]
        data=s.compact(rr)
        if args.emit_sources:
            p=args.output/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        return hashlib.sha256(data).hexdigest()
    if args.emit_sources:
        for name,t in neutral:save(name,t)
    for label,t in bases:
        assert sp.size(t)==4751
        nodes=[]
        def walk(n,i=0,p=''):
            j=i+sp.size(n)
            if i==26 and s.boundary(n)==(0,0,False):nodes.append((j,n,p))
            if not s.leaf(n):walk(n[0],i,p+'0');walk(n[1],i+sp.size(n[0]),p+'1')
        walk(t)
        for selector in (False,True):
            try:transfer=sp.serial(sp.closed_forest(t,20,23))
            except AssertionError:continue
            for cache in (False,True):
                if not selector and not cache:continue
                for end,ax,axpath in (nodes if selector else [(0,None,'')]):
                    edits={}
                    if cache:edits[4671,4697]=short
                    if selector:edits[20,23]=None;edits[26,end]=(transfer,ax)
                    changed=t
                    if selector:
                        rows=s.sites(t)
                        for i in (23,24,25):
                            p,op,r=rows[i];assert(op,r)==('CD',3)
                            changed=s.replace(changed,p,('CD',6))
                    try:new=sp.apply_closed_splices(changed,edits)
                    except AssertionError:continue
                    metrics=s.metrics(new)
                    if metrics['dag_nodes']>202:continue
                    data=s.compact(s.sites(new));digest=hashlib.sha256(data).hexdigest()
                    if digest in seen:continue
                    seen.add(digest);name=f'composition{len(compositions):03}-dag{metrics["dag_nodes"]}.json'
                    assert save('compositions/'+name,new)==digest
                    compositions.append(('compositions/'+name,new))
                    comp_records.append(dict(file=name,base=label,selector=selector,cache=cache,ax_end=end,ax_path=axpath,metrics=metrics,sha256=digest))
    expected=json.loads((here/'recorded/compositions/compositions.json').read_text())
    assert [r['sha256']for r in comp_records]==[r['sha256']for r in expected]
    nip=s.subtree(old,'111');newnip=((('CD',5),nip[1][0]),nip[1][1])
    nip_records=[];seen=set()
    for label,t in prefix+compositions+commutes:
        start=sp.size(t)-26;used=[False]
        def go(n,i=0):
            j=i+sp.size(n)
            if j<=start:return n
            if i>=start:
                assert s.boundary(n)[:2]==(0,0)
                if i==start:used[0]=True;return newnip
                return None
            assert not s.leaf(n)
            a=go(n[0],i);b=go(n[1],i+sp.size(n[0]))
            if a is None:return b
            if b is None:assert s.boundary(a)[:2]==(0,0);return a
            return a,b
        try:new=go(t);assert used[0]
        except AssertionError:continue
        metrics=s.metrics(new)
        if metrics['dag_nodes']>202:continue
        digest=hashlib.sha256(s.compact(s.sites(new))).hexdigest()
        if digest in seen:continue
        seen.add(digest);name=f'nip-composition{len(nip_records):03}-dag{metrics["dag_nodes"]}.json'
        assert save('nip-compositions/'+name,new)==digest
        nip_records.append(dict(source=label,file=name,metrics=metrics,sha256=digest))
    expected=json.loads((here/'recorded/nip-compositions/records.json').read_text())
    assert [r['sha256']for r in nip_records]==[r['sha256']for r in expected]
    priced=json.loads((here/'recorded/composition-pricing/results.json').read_text())
    assert len(priced)==632 and all(r['status']=='NO_ALLOCATION'for r in priced)
    assert(len(bases),len(comp_records),len(nip_records))==(95,280,352)
    assert min(r['metrics']['dag_nodes']for r in comp_records+nip_records)==202
    receipt=dict(status='ALL_632_SOURCE_HASHES_REPRODUCED',baseline_sha256=hashlib.sha256(raw).hexdigest(),bases=len(bases),neutral_rotations=len(neutral),retag_snapshots=len(retags),selector_cache_compositions=comp_records,decrement_nip_compositions=nip_records,allocation_scope='The recorded632 fixed-role MILPs returned NO_ALLOCATION; this is not a lower bound over other source trees, allocations or compilers.')
    (args.output/'composition-census-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items()if k not in('selector_cache_compositions','decrement_nip_compositions')},indent=2))
if __name__=='__main__':main()
