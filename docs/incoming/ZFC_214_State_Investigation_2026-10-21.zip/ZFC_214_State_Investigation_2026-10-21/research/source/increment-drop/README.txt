INCREMENTED DROP / INPUT-FREE MP: ORDINARY COMPILER AND SOURCE203

This is a new command-calculus construction, not an accepted214-state binary
machine. DROP increases the existing unconstrained numeric parameter by1;
MP has no additional input field; AX is exactly the accepted dominated emitter.
Unary DROP repetitions both set a desired numeric parameter and push removable
padding. The ordinary proof gives explicit strong blocks for every native
calculus inference and therefore retains the ZFC refutation equivalence.

The two literal source edits give204DAG nodes/4738primitive occurrences.
retagged203.json has203DAG nodes/4738primitive occurrences and exactly the same
complete guarded ordinal graph. Its SHA256 is
2ed1a87bd3cd1b37c0be144bd1e5c69b5fc186f160b86dbf6a6d4bfd1897aa63.
Both source-graph resolvers verify all6157 guarded successor edges plus halt.

Run these fast standard-library checks from the packet root:

  python3 research/source/increment-drop/reconstruct_increment_drop.py \
    --output /tmp/zfc-increment-drop-source

  python3 research/source/increment-drop/check_increment_drop_contracts.py \
    --output /tmp/zfc-increment-drop-contracts.json

The second checks1808 finite exact integer cases. It instantiates native AX
rows by three safe ordered numeric families and uses HOLE only for the
induction hypothesis; it is not a native-emitter or binary-runtime check.
The universal compiler proof, including zero cases and protected-stack
restoration, is increment_drop_compiler.tex. An independent formalism agent
reviewed that argument before packaging.

Precise bounded searches:

* association_search.py prices924 DROP association/placement shapes and58786
  MP association shapes separately, then138 retained cross combinations.
  Minimum204; this is not an exhaustive54-million-pair census.
* retag_search.py 90 runs the exact-CFG randomized source search for90seconds.
  The recorded run finished317iterations and reached203.031, where the decimal
  tie-breaker counts long-zero addresses; it is not a fractional state count.
  Timing changes can change the search trajectory. The saved203source is
  independently hash-pinned and graph-checked, so its validity does not depend
  on reproducing the stochastic trajectory.
* compose_increment_drop.py --output DIR recreates48 distinct source
  compositions using four parameter profiles and selector/cache/NIP choices.
  It does not call MILP unless --allocate is supplied. Compare its compositions
  hashes with composition-family.json. Sixteen variants have203DAG nodes;
  the others have204,205,206 or207; none has fewer than203. The16minima all returned
  NO_ALLOCATION in the fixed-role partial allocator. Cached-success variants
  require replacing the old final MP;NIP cleanup by MPcache;DROP;NIP (or early
  halt); the source-family receipt does not assert a new physical runtime.

retag203-allocation.json and composition-allocations.json are constrained
synthesis negatives. They do not rule out a different physical allocation,
a stronger context-sensitive source compiler, or a214-state machine.
The original receipt paths are preserved as provenance labels only.
