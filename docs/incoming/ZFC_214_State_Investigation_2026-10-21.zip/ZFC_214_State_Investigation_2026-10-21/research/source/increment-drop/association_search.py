from pathlib import Path
import sys,json,functools,time
K=(Path(__file__).resolve().parents[3]/'baseline'/'candidate-k215');sys.path[:0]=[str(K)];import source_language as s
O=Path(__file__).resolve().parent/'association-work';O.mkdir(exist_ok=True)
N=[];lookup={}
def intern(a,b=None):
 key=a if b is None else(a,b)
 if key not in lookup:lookup[key]=len(N);N.append(key)
 return lookup[key]
def lf(n):return isinstance(N[n][0],str)
def toid(t):return intern(t)if s.leaf(t)else intern(toid(t[0]),toid(t[1]))
@functools.cache
def totr(n):return N[n]if lf(n)else tuple(map(totr,N[n]))
@functools.cache
def boundary(n):
 if lf(n):
  o,a=N[n];return(1,0,False)if o=='CD'else(a,0,False)if o=='CB'else(0,a,False)if o=='CC'else(0,0,o=='CH')
 a,b=map(boundary,N[n]);return(max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2])
def closed(n):return boundary(n)==(0,0,False)
def forest(n):
 if not lf(n)and all(closed(x)for x in N[n]):return forest(N[n][0])+forest(N[n][1])
 return[n]
@functools.cache
def assoc(atoms):
 if len(atoms)==1:return atoms
 return tuple(intern(a,b)for i in range(1,len(atoms))for a in assoc(atoms[:i])for b in assoc(atoms[i:]))
def reach(n):
 seen=set();todo=[n]
 while todo:
  q=todo.pop()
  if q in seen:continue
  seen.add(q)
  if not lf(q):todo.extend(N[q])
 return seen
def subtree(n,p):
 for b in p:n=N[n][int(b)]
 return n
def replace(n,p,new):
 if not p:return new
 a,b=N[n]
 return intern(replace(a,p[1:],new),b)if p[0]=='0'else intern(a,replace(b,p[1:],new))
old=s.tree(json.loads((K/'sites215.json').read_text()));base=s.replace(old,'110100101000',s.subtree(old,'1101001001101'));root=toid(base);drop=subtree(root,'110101');mp=subtree(root,'110100101');ci=toid(('CI',4));df=forest(drop);mf=forest(mp)
print('FORESTS',len(df),len(mf),flush=True)
drops=set()
for i in range(len(df)+1):drops.update(assoc(tuple(df[:i]+[ci]+df[i:])))
mps=assoc(tuple(mf));print('SHAPES',len(drops),len(mps),flush=True)
# Price each family separately before a bounded cross product.
d0=intern(ci,drop);ds=[];ms=[]
for d in drops:
 rr=replace(root,'110101',d);ds.append((len(reach(rr)),d))
print('DROP MIN',min(c for c,d in ds),flush=True)
for i,m in enumerate(mps):
 rr=replace(replace(root,'110101',d0),'110100101',m);ms.append((len(reach(rr)),m))
 if i%10000==0:print('MP PROGRESS',i,'MIN',min(c for c,m in ms),flush=True)
dmin=min(c for c,d in ds);mmin=min(c for c,m in ms)
ds=sorted(ds)[:512];ds=[(c,d)for c,d in ds if c<=dmin+1]
ms=sorted(ms)[:512];ms=[(c,m)for c,m in ms if c<=mmin+1]
print('RETAINED',len(ds),len(ms),'MIN',dmin,mmin,flush=True)
seen=set();best=999;records=[];trials=0
for dc,d in ds:
 for mc,m in ms:
  rr=replace(replace(root,'110101',d),'110100101',m)
  if rr in seen:continue
  seen.add(rr);trials+=1;cost=len(reach(rr))
  if cost<best:best=cost;print('BEST',best,'TRIAL',trials,flush=True)
  if cost<=202 or (cost==203 and sum(r['dag']==203 for r in records)<24):
   t=totr(rr);ss=s.sites(t);assert s.graph_intervals(ss)==s.graph_arithmetic(ss)[0]
   f=f'association{len(records):03}-dag{cost}.json';(O/f).write_bytes(s.compact(ss));records.append({'source':f,'dag':cost,'metrics':s.metrics(t)})
print('DONE',trials,best,flush=True)
(O/'association-census.json').write_text(json.dumps({'cross_trials':trials,'minimum':best,'drop_atom_count':len(df),'mp_atom_count':len(mf),'drop_shapes_priced':len(drops),'mp_shapes_priced':len(mps),'drop_individual_minimum':dmin,'mp_individual_minimum':mmin,'drop_retained':len(ds),'mp_retained':len(ms),'beam_limit_each':512,'records':records},indent=2)+'\n')
