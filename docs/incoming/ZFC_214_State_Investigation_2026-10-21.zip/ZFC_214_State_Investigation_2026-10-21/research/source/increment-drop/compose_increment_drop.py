from pathlib import Path
import sys,json,hashlib,itertools,functools,subprocess,concurrent.futures
K=(Path(__file__).resolve().parents[3]/'baseline'/'candidate-k215');S=Path(__file__).resolve().parent
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--allocate',action='store_true');args=ap.parse_args();O=args.output;O.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(K/'code'),str(K/'research/composition-allocation')];import source_language as s,source_splice as sp
base_rows=json.loads((S/'retagged203.json').read_text());original=s.tree(base_rows)
old=s.tree(json.loads((K/'sites215.json').read_text()));oldnip=s.subtree(old,'111');newnip=((('CD',5),oldnip[1][0]),oldnip[1][1]);short=(('CD',4),(('CI',5),('CC',2)))
recs=[];seen=set()
for rho6,joint in itertools.product((0,1),repeat=2):
 rows=[x.copy()for x in base_rows]
 for lo,hi in ([(888,1171)]if rho6 else[])+([(1467,1766),(2062,2412)]if joint else[]):
  for i in range(lo,hi):
   p,op,a=rows[i]
   if op in('CI','CD')and a in(3,5):rows[i][2]=8-a
 t=s.tree(rows);nodes=[]
 def walk(n,i=0,p=''):
  j=i+sp.size(n)
  if i==26 and s.boundary(n)==(0,0,False):nodes.append((j,n,p))
  if not s.leaf(n):walk(n[0],i,p+'0');walk(n[1],i+sp.size(n[0]),p+'1')
 walk(t)
 for selector,cache,nip in itertools.product((0,1),repeat=3):
  for end,ax,path in(nodes if selector else[(0,None,'')]):
   edits={};changed=t
   if selector:
    transfer=sp.serial(sp.closed_forest(t,20,23));edits[20,23]=None;edits[26,end]=(transfer,ax)
    for i in(23,24,25):
     p,op,a=rows[i];assert(op,a)==('CD',3);changed=s.replace(changed,p,('CD',6))
   if cache:edits[4657,4683]=short
   if nip:edits[len(rows)-26,len(rows)]=newnip
   try:new=sp.apply_closed_splices(changed,edits)if edits else changed
   except AssertionError:continue
   metrics=s.metrics(new);ss=s.sites(new);assert s.graph_intervals(ss)==s.graph_arithmetic(ss)[0]
   data=s.compact(ss);digest=hashlib.sha256(data).hexdigest()
   if digest in seen:continue
   seen.add(digest);name=f'variant{len(recs):03}-dag{metrics["dag_nodes"]}.json';(O/name).write_bytes(data)
   rec=dict(file=name,sha256=digest,rho6=rho6,joint_rho2_rho4=joint,selector_localized=selector,cache_return=cache,decrement_nip=nip,ax_end=end,ax_path=path,metrics=metrics);recs.append(rec)
print('GENERATED',len(recs),'MIN',min(r['metrics']['dag_nodes']for r in recs),flush=True)
(O/'compositions.json').write_text(json.dumps(recs,indent=2)+'\n')
if not args.allocate:sys.exit(0)
def price(r):
 f=O/r['file'];d=O/(f.stem+'-allocation');cp=subprocess.run(['python3',str(S.parent/'allocate215_partial.py'),'--source',str(f),'--output',str(d),'--limit','3'],capture_output=True,text=True)
 z=json.loads((d/'allocation.json').read_text())if(d/'allocation.json').exists()else{'status':'ERROR','error':cp.stderr}
 return dict(file=f.name,**{k:z.get(k)for k in('status','states','new_nodes','fixed_states')})
selected=[r for r in recs if r['metrics']['dag_nodes']<=203]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:priced=list(ex.map(price,selected))
(O/'allocations.json').write_text(json.dumps(priced,indent=2)+'\n');print('PRICED',json.dumps(priced),flush=True)
