#!/usr/bin/env python3
"""Finite exact-integer checks of the increment-DROP command compiler.

Checks pairing, stack arithmetic and command equations. As in Source164's
check_residual_contracts.py, AX row/bundle codes are instantiated by several
non-falsity families; this is not a native AX emitter or TM runtime replay.
HOLE represents a premise block's proved contract and is not a machine opcode.
The universal argument is in increment_drop_compiler.tex.
"""
from pathlib import Path
from itertools import product
from math import isqrt
from dataclasses import dataclass
import argparse,json

def pair(a,b):return (a+b)*(a+b+1)//2+b
def unpair(n):
    s=(isqrt(8*n+1)-1)//2;b=n-s*(s+1)//2;return s-b,b
def imp(a,b):return 4*pair(a,b)
def quant(i,a):return 4*pair(i,a)+2
def push(xs,S):
    for x in reversed(xs):S=pair(x,S)
    return S
@dataclass(frozen=True)
class State:
    t:int;S:int;d:int;h:int
N=('NIP',);D=('DROP',);M=('MP',)
def AX(c,x,y):return('AX',c,x,y)
def rows(mode,a,b,c,u):
    if mode==0:return(0,)*8
    if mode==1:return tuple(4*(j+1)for j in range(8))
    return tuple(4*(1+(j+1)*(a+2*b+3*c+5*u+1))for j in range(8))
def bundle(mode,a,b,c):return 0 if mode==0 else 4*(mode+a+2*b+3*c)
def step(k,w,mode):
    t,S,d,h=w.t,w.S,w.d,w.h
    if k==D:return State(h,pair(t,S),d+1,h)
    if k==N:
        if h==1:return None
        x,z=unpair(S);return State(t,z,d,x)
    if k==M:return State(d,pair(0,S),d,0)if imp(t,d)==h else State(0,S,d,0)
    if k[0]=='HOLE':return State(k[1],S,k[2],0)
    assert k[0]=='AX';_,c,x,y=k;a=d+x;b=h+y
    g=0 if c in(a,b)else bundle(mode,a,b,c)
    return State(g,push(rows(mode,a,b,c,d)+(quant(d,h),t),S),0,0)
def run(word,w,mode):
    for k in word:
        w=step(k,w,mode)
        if w is None:return None
    return w
def reset():return([AX(0,0,0)]+[N]*10)*3
def rowblock(j,a,b,c,u):return reset()+[D]*u+[AX(c,a-u,b)]+[N]*j+[D]+[N]*(11-j+u)
def gen(i,X,outparam):return[('HOLE',X,outparam),AX(0,0,0)]+[N]*10+[D]*i+[AX(i,0,0)]+[N]*9+[D]+[N]*(i+2)
def mp(A,B,paramA,paramI):
    if B==0:return reset()
    return[('HOLE',imp(A,B),paramI),D,('HOLE',A,paramA),AX(0,0,0)]+[N]*10+[D]*B+[N]*(B+1)+[M,N]
def pack(k,tail):
    if k==N:return pair(0,tail)
    if k==D:return pair(1,tail)
    if k==M:return pair(2,tail)
    _,c,x,y=k;return pair(c+3,pair(y,pair(x,tail)))
def read(raw):
    tag,tail=unpair(raw)
    if tag<3:return(N,D,M)[tag],tail
    y,tail=unpair(tail);x,tail=unpair(tail);return AX(tag-3,x,y),tail
def cursor(word):
    n=0
    for k in reversed(word):n=1+pack(k,n)
    return n
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    if not __debug__:raise RuntimeError('Run without -O; assertions are the checks.')
    stacks=(0,pair(1,0),push((7,1,0),0));counts={};cases=0
    for mode,t,d,h,S in product(range(3),(0,1,3),(0,2,5),(0,1,4),stacks):
        assert run(reset(),State(t,S,d,h),mode)==State(0,S,0,0);cases+=1
    counts['reset_arbitrary_input']=cases;cases=0
    params=((0,0,0,0),(2,3,1,2),(5,2,3,0),(3,2,2,1))
    for mode,S,j,(aa,b,c,u)in product(range(3),stacks,range(1,9),params):
        assert run(rowblock(j,aa,b,c,u),State(1,S,5,1),mode)==State(rows(mode,aa,b,c,u)[j-1],S,1,0);cases+=1
    counts['all_eight_rows_and_zero_padding']=cases;cases=0
    for mode,S,X,i,outparam in product(range(3),stacks,(0,1,2,7,12),range(5),(0,5)):
        result=run(gen(i,X,outparam),State(1,S,7,1),mode)
        assert result is None or result==State(quant(i,X),S,1,0)
        if X!=1:assert result is not None
        cases+=1
    counts['generalization_including_label_zero']=cases;cases=0
    for mode,S,A,B,paramA,paramI in product(range(3),stacks,(0,1,2,7),range(5),(0,5),(0,3)):
        result=run(mp(A,B,paramA,paramI),State(1,S,7,1),mode)
        expected=State(B,S,B if B else 0,0)
        assert result is None or result==expected
        if A!=1 or B==0:assert result==expected
        cases+=1
    counts['modus_ponens_including_consequent_zero']=cases;cases=0
    for mode,S,a0,b,c in product(range(3),stacks,range(2),range(2),(2,3)):
        result=run(reset()+[AX(c,a0,b)]+[N]*10,State(1,S,7,1),mode)
        assert result==State(bundle(mode,a0,b,c),S,0,0);cases+=1
    counts['bundle_and_protected_falsity_stack']=cases;cases=0
    commands=(N,D,M,AX(0,0,0),AX(1,2,3))
    for k,z in product(commands,range(5)):assert read(pack(k,z))==(k,z);cases+=1
    for word in((),(N,),(M,),(D,N,N),(AX(0,0,0),M,D,N)):
        n=cursor(word);got=[]
        while n:
            k,n=read(n-1);got.append(k)
        assert tuple(got)==word;cases+=1
    assert cursor((N,))==1 and pack(N,0)==0
    for v in range(5):
        word=(D,N,N,AX(v,0,0));raw=cursor(word)-1
        assert raw>=cursor((AX(v,0,0),));cases+=1
    counts['wire_fields_successor_cursor_zero_alias']=cases
    result=dict(status='PASS',cases=counts,total_cases=sum(counts.values()),
        scope='Finite exact integer command/stack interface checks, using three non-falsity AX row/bundle instantiations. HOLE is an induction-hypothesis test operation. Not native-emitter, binary-runtime, startup or proof-assistant verification.',
        ordinary_proof='increment_drop_compiler.tex',antecedent='Source164 theory/check_residual_contracts.py supplied the independently reviewed contract-testing style; the DROP increment and new compiler blocks are different.')
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
