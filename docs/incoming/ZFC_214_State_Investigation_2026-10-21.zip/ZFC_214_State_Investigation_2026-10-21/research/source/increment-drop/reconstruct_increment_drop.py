#!/usr/bin/env python3
"""Reconstruct the204-DAG source and verify the supplied exact-CFG203 retag.
Standard library only; no binary allocation/runtime conclusion is asserted.
"""
from pathlib import Path
import argparse,hashlib,json,sys

def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
    here=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--candidate',type=Path,default=here.parents[2]/'baseline/candidate-k215')
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    if not __debug__:raise RuntimeError('Run without -O; assertions are the checks.')
    sys.path.insert(0,str(args.candidate/'code'));import source_language as s
    raw=(args.candidate/'sites215.json').read_bytes()
    assert sha(raw)=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
    old=s.tree(json.loads(raw));mp_path='110100101000';load_path='1101001001101';drop_path='110101'
    oldprefix=s.subtree(old,mp_path);load=s.subtree(old,load_path);drop=s.subtree(old,drop_path)
    assert len(s.sites(oldprefix))==40 and len(s.sites(load))==26 and oldprefix[1][1]==load
    assert len(s.sites(drop))==26 and s.boundary(drop)==(0,0,False)
    assert not any(op in('CI','CD')and r==4 for p,op,r in s.sites(drop))
    assert [r[1:]for r in s.sites(oldprefix)][14:]==[r[1:]for r in s.sites(load)]
    base=s.replace(old,mp_path,load);records=[];sources={}
    for name,body in [('literal-prefix204.json',(('CI',4),drop)),('literal-suffix204.json',(drop,('CI',4)))]:
        t=s.replace(base,drop_path,body);rows=s.sites(t);data=s.compact(rows)
        assert data==(here/name).read_bytes()
        assert s.graph_intervals(rows)==s.graph_arithmetic(rows)[0]
        assert s.metrics(t)==dict(dag_nodes=204,leaf_occurrences=4738,maximum_depth=47,maximum_zero_run=6)
        (args.output/name).write_bytes(data);sources[name]=rows
        records.append(dict(file=name,sha256=sha(data),metrics=s.metrics(t)))
    raw=(here/'retagged203.json').read_bytes();rows=json.loads(raw);t=s.tree(rows)
    assert sha(raw)=='2ed1a87bd3cd1b37c0be144bd1e5c69b5fc186f160b86dbf6a6d4bfd1897aa63'
    assert s.graph_intervals(rows)==s.graph_arithmetic(rows)[0]==s.graph_intervals(sources['literal-prefix204.json'])
    assert s.metrics(t)==dict(dag_nodes=203,leaf_occurrences=4738,maximum_depth=46,maximum_zero_run=6)
    graph=s.graph_intervals(rows)
    records.append(dict(file='retagged203.json',sha256=sha(raw),metrics=s.metrics(t),exact_full_guarded_cfg_equal=True))
    receipt=dict(status='INCREMENTED_DROP_SOURCE_AND_RETAG_CHECKS_PASS',source_records=records,
        baseline_sha256='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba',
        edit=dict(mp_prefix_path=mp_path,existing_load_path=load_path,drop_path=drop_path,mp_input_leaves_removed=14,drop_increment_register=4),
        full_cfg_sha256=sha(s.compact(graph)),primitive_occurrences=len(rows),guarded_successor_edges=sum(len(r[1])for r in graph),
        scope='Exact local source recipe and full guarded-CFG equality of the retag. The ordinary command calibration is proved in increment_drop_compiler.tex. No new binary runtime, blank startup, proof-assistant endpoint or214-state machine is claimed.')
    (args.output/'source-recipe-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
