SOURCE-SIDE RESEARCH: REPRODUCTION AND SCOPE

No file in this directory establishes a 214-state machine. The accepted
215-state source and table are pinned in baseline/candidate-k215. The separately
verified rho6 alternative is documented in the main packet. Files here record
bounded source searches and reusable allocation tools.

QUICK STANDARD-LIBRARY REPRODUCTION

Run from the packet root:

  python3 research/source/reproduce_source_variants.py \
    --candidate baseline/candidate-k215 --output /tmp/zfc-source-variants

  python3 research/source/reproduce_composition_census.py \
    --output /tmp/zfc-composition-census

The first command recreates eight selector/cache/NIP variants and eight finite
source-level enumeration-swap prefixes. Seven of the eight swaps have a clean
calibrated endpoint; swapping N and W causes an early halt and is rejected.
The second command reconstructs every one of the 280 selector/cache compositions
and 352 decrement-first NIP compositions and compares all 632 source hashes with
the recorded receipts. It uses 80 exact-CFG rotation recipes, 12 saved retag
snapshots, two independent-register commutations, and the baseline. All 632 have
202 source-DAG nodes. This command does not run a TM or rerun MILP.

Add --emit-sources to the second command to materialize the generated source
JSON files. They are omitted from the archive because they are highly repetitive
and exactly reproducible. The twelve saved retag snapshots are included since
wall-clock-bounded stochastic search is not an exact replay method.

PHYSICAL ALLOCATION TOOLS

allocate215.py is the constrained allocator used for the historical 632 search.
It retains compatible old decoder roles and inherited protected engine rows,
then assigns distinct physical labels to the remaining internal nodes. It uses
NumPy and SciPy's HiGHS MILP solver. Its default baseline paths are relative to
this packet, and its source/table hashes are pinned. For example:

  python3 research/source/allocate215.py \
    --source /tmp/zfc-source-variants/selector1-cache0-nip0.json \
    --output /tmp/zfc-local-selector-allocation --limit 10

allocate215_partial.py additionally computes guarded-CFG reachability, excludes
unreachable leaf and child obligations, and permits several syntactically
separate CB1-left/dead-right nodes to share native 40. This is a direct use of
unreachable junk, rather than a requirement that every syntactic leaf decode.
It supports the independently proved CB1 suffix 0 entry 0L4 and CB2 suffix 00
entry 0L40. The latter is rejected at other reachable suffixes. With --merge302,
it requires every reachable CD to end0 and each reachable CB to have one of the
proved safe suffixes, then folds 302 into 40 for subsequent verification.

PREFIX_PASS means that every required decoder prefix reaches an allowed
internal role without changing the prefix tape. It does not establish primitive
runtime correctness, startup correctness, source calibration, or a 214-state
candidate. A source whose guarded graph has dead leaves still requires proof
that its active source behavior implements the intended calculus. The inherited
engine filter is a synthesis restriction, not a new current-runtime proof.
NO_ALLOCATION is only a negative result inside this fixed-role finite model;
it is not a lower bound over all assignments, source codes, or Turing machines.

LATEST FOCUSED CHECKS

The three inputs/forced-cb-*.json files retain every original PC and replace
one or both of source ordinals 4671 (CD1) and 4733 (CD6) by CB1. Their justification
is the parent packet's separately audited source invariant: the tested registers
are zero there on every calibrated execution. The immediately skipped right
branches become dead. They are not equivalent to the baseline on arbitrary
uncalibrated registers. Even with their one/two dead-right nodes bound to native 40,
all three constrained allocations were infeasible. Exact receipts are in
recorded/forced-cb/.

The 40 emitted minima of the formalism agent's 10,300 NOP-padding search also
returned NO_ALLOCATION with this partial allocator; see
recorded/nop-padding-pricing/results.json. These receipts do not rule out a
better global allocation or a different partial source graph.

RECORDED EVIDENCE

recorded/ preserves historical receipt bytes, including absolute paths and
script hashes from the research workspace. Those paths are provenance labels,
not external dependencies of the portable scripts. portable-script-provenance.json
maps the original script hashes to the packet copies; those copies change only
workspace paths into packet-relative paths.

The 28 register-swap summary at recorded/register-allocations-corrected.json is
the corrected run with the 146-row inherited engine filter, plus applicable
contextual helper protection. The earlier erroneous 419-row census and its
negative allocation run are deliberately excluded. register_layouts.py and
run_register_allocations.py regenerate this family and call the corrected
allocator.

rotations.py reproduces the 4,881 bounded single/global rotation census.
allocate_neutral.py reconstructs and prices the 80 exact-CFG neutral variants.
compose_variants.py and compose_nip.py are the original composition generators;
they expect the generated neutral source files and the included retag/commute
inputs in this directory. The new standalone composition reproducer above is the
compact default. price_compositions.py reruns the 632 MILPs after those sources
are materialized in the expected directories.

search_retag215.py, search_zero215.py and search_algebra.py are seeded,
wall-clock-bounded heuristic explorations. Their logs state the actual completed
budgets. The separate search_nip_retag.py run was terminated with exit 137 after
roughly 84 seconds and 300 reported steps; its log must not be read as a completed
180-second census. Every saved snapshot used in a claimed finite replay is
checked against both independent source-graph resolvers.

spare-runtime-review.txt is an independent review of the parent's symbolic
spare-tail contract. It does not substitute for a proof-assistant endpoint, and
specifically requires a genuinely calibrated blank startup or a certified finite
burn-in; T=W=H=0 alone does not suffice if scratch registers remain dirty.
