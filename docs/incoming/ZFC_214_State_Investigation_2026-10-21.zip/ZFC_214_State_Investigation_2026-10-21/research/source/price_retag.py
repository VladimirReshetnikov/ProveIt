import json,subprocess,time
from pathlib import Path
B=Path(__file__).resolve().parent
files=list((B/'retag-output').glob('*.json'))+[B/'commute-0.json',B/'commute-1.json']
out=B/'retag-pricing';out.mkdir(exist_ok=True)
records=[]
for i,source in enumerate(files):
 d=out/f'trial{i:03}';cp=subprocess.run(['python3',str(B/'allocate215.py'),'--source',str(source),'--output',str(d),'--limit','3'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/f'trial{i:03}.log').write_text(cp.stdout)
 r=json.loads((d/'allocation.json').read_text()) if (d/'allocation.json').exists()else{'status':'CRASH'}
 records.append({'source':str(source),'directory':str(d),'result':r});print(i,source.name,r.get('status'),r.get('states'),flush=True)
 (out/'results.json').write_text(json.dumps(records,indent=2))
