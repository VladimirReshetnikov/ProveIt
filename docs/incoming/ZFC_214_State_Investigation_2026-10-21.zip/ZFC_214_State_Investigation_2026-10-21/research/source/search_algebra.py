from pathlib import Path
from functools import cache
import sys,json,random,time
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path[:0]=[str(K),str(K/'code')]
import source_language as s,build221 as b
O=Path(__file__).resolve().parent
old=s.tree(json.loads((K/'sites215.json').read_text()))
N=[];L={}
def intern(k):
 if k not in L:L[k]=len(N);N.append(k)
 return L[k]
def toid(n):return intern(n)if s.leaf(n)else intern(tuple(map(toid,n)))
def leaf(n):return isinstance(N[n][0],str)
initial=toid(old)
@cache
def boundary(n):
 if leaf(n):return s.boundary(N[n])
 a,c=map(boundary,N[n]);return max(a[0]-1,c[0],0),max(a[1],c[1]-1,0),a[2]or c[2]
@cache
def effects(n):
 if leaf(n):return 1<<N[n][1]if N[n][0]in('CI','CD')else 0
 return effects(N[n][0])|effects(N[n][1])
@cache
def totree(n):return N[n]if leaf(n)else tuple(map(totree,N[n]))
def info(r):
 seen=set();depth={};zeros={};leftz={}
 def go(n):
  if n in seen:return
  seen.add(n)
  if leaf(n):depth[n]=zeros[n]=leftz[n]=0
  else:
   a,c=N[n];go(a);go(c);depth[n]=1+max(depth[a],depth[c]);leftz[n]=1+leftz[a];zeros[n]=max(leftz[n],zeros[a],zeros[c])
 go(r);return seen,depth[r],zeros[r]
def replace(r,old,new):
 @cache
 def go(n):
  if n==old:return new
  return n if leaf(n)else intern(tuple(map(go,N[n])))
 return go(r)
def moves(r,reach):
 for n in reach:
  if leaf(n):continue
  a,c=N[n]
  if boundary(a)==boundary(c)==(0,0,False)and not(effects(a)&effects(c)):yield n,intern((c,a)),'swap'
  if not leaf(c):
   bb,cc=N[c]
   if all(boundary(x)==(0,0,False)for x in(a,bb,cc)):yield n,intern((intern((a,bb)),cc)),'L'
  if not leaf(a):
   aa,bb=N[a]
   if all(boundary(x)==(0,0,False)for x in(aa,bb,c)):yield n,intern((aa,intern((bb,c)))),'R'
def path(r,n):
 def go(q,p):
  if q==n:return p
  if leaf(q):return None
  z=go(N[q][0],p+'0')
  return z if z is not None else go(N[q][1],p+'1')
 return go(r,'')
start=time.monotonic();duration=float(sys.argv[1])if len(sys.argv)>1 else 240
rng=random.Random(int(sys.argv[2])if len(sys.argv)>2 else 431214);root=initial;trail=[];best=202;seen={root};steps=0;rec=[]
while time.monotonic()-start<duration:
 reach,d,z=info(root);cs=[]
 for n,new,kind in moves(root,reach):
  rr=replace(root,n,new)
  if rr in seen:continue
  rrch,dd,zz=info(rr)
  if zz<=6 and dd<=60 and len(rrch)<=205:cs.append((len(rrch),rr,n,new,kind))
  seen.add(rr)
 if not cs:
  root=initial;trail=[];seen={root};continue
 m=min(x[0]for x in cs)
 opts=[x for x in cs if x[0]==m]if rng.random()<.88 else[x for x in cs if x[0]<=m+1]
 v=rng.choice(opts);cnt,rr,n,new,kind=v
 trail.append({'path':path(root,n),'kind':kind});root=rr;steps+=1
 if cnt<best:
  best=cnt;tr=totree(root);raw=s.compact(s.sites(tr));ix=len(rec);f=f'algebra-{sys.argv[2]if len(sys.argv)>2 else "431214"}-{best}.json';(O/f).write_bytes(raw)
  record={'states':cnt,'metrics':s.metrics(tr),'steps':steps,'seconds':time.monotonic()-start,'trail':trail.copy(),'source':f};rec.append(record);(O/(f+'.receipt.json')).write_text(json.dumps(record,indent=2)+'\n');print('NEW',cnt,'steps',steps,'time',time.monotonic()-start,'file',f,flush=True)
  if cnt<=200:break
 if steps%200==0:print('STATUS',steps,'current',cnt,'best',best,'time',time.monotonic()-start,flush=True)
 if steps%500==0:
  current=totree(root);initial=toid(old);N.clear();L.clear();boundary.cache_clear();effects.cache_clear();totree.cache_clear();initial=toid(old);root=toid(current);seen={root}
print('DONE',steps,'best',best,'seconds',time.monotonic()-start,flush=True)
