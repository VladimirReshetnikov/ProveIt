import sys,json,hashlib
from pathlib import Path
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path[:0]=[str(K/'code'),str(K/'research/composition-allocation')];import source_language as s,source_splice as sp
B=Path(__file__).resolve().parent;O=B/'nip-compositions';O.mkdir(exist_ok=True)
t=s.tree(json.loads((K/'sites215.json').read_text()));old=s.subtree(t,'111');newnip=((('CD',5),old[1][0]),old[1][1]);assert s.metrics(s.replace(t,'111',newnip))['dag_nodes']==202
paths=[K/'sites215.json']+sorted((B/'neutral-allocation').glob('source*.json'))+sorted((B/'retag-output').glob('*.json'))+sorted((B/'compositions').glob('composition*.json'))+[B/'commute-0.json',B/'commute-1.json']
recs=[];seen=set()
for src in paths:
 try:rows=json.loads(src.read_text());t=s.tree(rows)
 except Exception:continue
 start=sp.size(t)-26;end=sp.size(t);used=[False]
 def go(n,i=0):
  j=i+sp.size(n)
  if j<=start:return n
  if i>=start:
   assert s.boundary(n)[:2]==(0,0)
   if i==start:used[0]=True;return newnip
   return None
  assert not s.leaf(n)
  a=go(n[0],i);b=go(n[1],i+sp.size(n[0]))
  if a is None:return b
  if b is None:assert s.boundary(a)[:2]==(0,0);return a
  return a,b
 try:new=go(t);assert used[0]
 except AssertionError:continue
 m=s.metrics(new)
 if m['dag_nodes']>202:continue
 ss=s.sites(new);assert s.graph_intervals(ss)==s.graph_arithmetic(ss)[0];raw=s.compact(ss);sha=hashlib.sha256(raw).hexdigest()
 if sha in seen:continue
 seen.add(sha);i=len(recs);name=f'nip-composition{i:03}-dag{m["dag_nodes"]}.json';(O/name).write_bytes(raw);recs.append({'source':str(src),'file':name,'sha256':sha,'metrics':m})
 if m['dag_nodes']<202:print('NEW',recs[-1],flush=True)
(O/'records.json').write_text(json.dumps(recs,indent=2)+'\n');print('SOURCES',len(paths),'VARIANTS',len(recs),'BEST',min([r['metrics']['dag_nodes']for r in recs],default=None),flush=True)
