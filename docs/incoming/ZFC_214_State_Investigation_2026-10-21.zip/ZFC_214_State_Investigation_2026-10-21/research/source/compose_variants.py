import json,sys,hashlib,subprocess,time
from pathlib import Path
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path[:0]=[str(K/'code'),str(K/'research/composition-allocation')]
import source_language as s,source_splice as sp
B=Path(__file__).resolve().parent;O=B/'compositions';O.mkdir(exist_ok=True)
paths=[K/'sites215.json']+sorted((B/'neutral-allocation').glob('source*.json'))+sorted((B/'retag-output').glob('*.json'))+[B/'commute-0.json',B/'commute-1.json']
short=(('CD',4),(('CI',5),('CC',2)));records=[];seen=set();best=1000
for src in paths:
 t=s.tree(json.loads(src.read_text()));assert sp.size(t)==4751
 nodes=[]
 def walk(n,i=0,p=''):
  j=i+sp.size(n)
  if i==26 and s.boundary(n)==(0,0,False):nodes.append((j,n,p))
  if not s.leaf(n):walk(n[0],i,p+'0');walk(n[1],i+sp.size(n[0]),p+'1')
 walk(t)
 for selector in [False,True]:
  try:
   transfer=sp.serial(sp.closed_forest(t,20,23))
  except AssertionError:continue
  for cache in [False,True]:
   if not selector and not cache:continue
   for end,ax,ap in (nodes if selector else [(0,None,'')]):
    edits={}
    if cache:edits[4671,4697]=short
    if selector:edits[20,23]=None;edits[26,end]=(transfer,ax)
    changed=t
    if selector:
     ss=s.sites(t)
     for i in [23,24,25]:
      p,o,r=ss[i];assert(o,r)==('CD',3);changed=s.replace(changed,p,('CD',6))
    try:new=sp.apply_closed_splices(changed,edits)
    except AssertionError:continue
    metrics=s.metrics(new)
    if metrics['dag_nodes']>202:continue
    out=s.sites(new);assert s.graph_intervals(out)==s.graph_arithmetic(out)[0]
    raw=s.compact(out);sha=hashlib.sha256(raw).hexdigest()
    if sha in seen:continue
    seen.add(sha);i=len(records);name=f'composition{i:03}-dag{metrics["dag_nodes"]}.json';(O/name).write_bytes(raw)
    rec={'file':name,'base':str(src),'selector':selector,'cache':cache,'ax_end':end,'ax_path':ap,'metrics':metrics,'sha256':sha};records.append(rec)
    if metrics['dag_nodes']<best:best=metrics['dag_nodes'];print('NEW BEST',json.dumps(rec),flush=True)
(O/'compositions.json').write_text(json.dumps(records,indent=2)+'\n');print('SOURCES',len(paths),'RECORDS',len(records),'BEST',best,flush=True)
