from pathlib import Path
import sys,json
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path[:0]=[str(K),str(K/'research/composition-allocation')]
import source_language as s,source_splice as sp
O=Path(__file__).resolve().parent
old=s.tree(json.loads((K/'sites215.json').read_text()));read=s.subtree(old,'10');walker,transfer=read
print('read',sp.size(walker),sp.size(transfer),s.boundary(walker),s.boundary(transfer),transfer,flush=True)
for p in ['1101001001','11010010010','110100100100','1101001001000']:
 n=s.subtree(old,p);print('AX',p,sp.size(n),s.boundary(n),flush=True)
# Maximal closed AX body lies immediately below the final dispatch guard.
axp='11010010010';AX=s.subtree(old,axp);assert s.boundary(AX)==(0,0,False)
base=s.replace(old,'10',walker)
for p in ['1100','1101000','1101001000']:assert s.subtree(base,p)==('CD',3);base=s.replace(base,p,('CD',6))
new=s.replace(base,axp,(transfer,AX));raw=s.compact(s.sites(new));(O/'selector-localized.json').write_bytes(raw)
print('RESULT',s.metrics(new),len(s.graph_intervals(s.sites(new))),s.graph_intervals(s.sites(new))==s.graph_arithmetic(s.sites(new))[0],flush=True)
# Associate transfer into every initial closed partition of AX.
variants=[]
def go(n,p=''):
 if not s.leaf(n)and s.boundary(n[0])==(0,0,False):
  candidate=s.replace(base,axp,s.replace(AX,p, (transfer,n)))
  # Only initial leftmost spine entry lies before any original AX primitive.
  name='selector-localized-'+(p or'root')+'.json';(O/name).write_bytes(s.compact(s.sites(candidate)));variants.append({'path':p,'metrics':s.metrics(candidate),'file':name})
  go(n[0],p+'0')
go(AX)
(O/'selector-localized-receipt.json').write_text(json.dumps({'base':s.metrics(new),'variants':variants},indent=2)+'\n')
print('VARIANTS',variants,flush=True)
