#!/usr/bin/env python3
"""Reproduce eight K215 source variants and finite enumeration-swap prefixes.

Usage: python3 reproduce_source_variants.py --candidate /path/to/candidate-k215 --output out
Python 3 standard library only. This is a source-level research checker, not a
binary Turing-machine runtime certificate or a claim of a 214-state candidate.
"""
import argparse, hashlib, itertools, json, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--candidate',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(a.candidate/'code'))
    import source_language as s
    raw=(a.candidate/'sites215.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
    rows=json.loads(raw);old=s.tree(rows);cfg=s.graph_intervals(rows)
    assert cfg==s.graph_arithmetic(rows)[0]
    read=s.subtree(old,'10');walker,transfer=read
    assert s.boundary(walker)==s.boundary(transfer)==(0,0,False)
    axpath='11010010010';ax=s.subtree(old,axpath)
    assert s.boundary(ax)==(0,0,False)
    nip=s.subtree(old,'111');newnip=((('CD',5),nip[1][0]),nip[1][1])
    short=(('CD',4),(('CI',5),('CC',2)))
    records=[]
    for selector,cache,dec in itertools.product((False,True),repeat=3):
        new=old
        if selector:
            new=s.replace(new,'10',walker)
            for p in ['1100','1101000','1101001000']:
                assert s.subtree(new,p)==('CD',3)
                new=s.replace(new,p,('CD',6))
            new=s.replace(new,axpath,(transfer,ax))
        if cache:new=s.replace(new,'11010010111',short)
        if dec:new=s.replace(new,'111',newnip)
        outrows=s.sites(new)
        assert s.graph_intervals(outrows)==s.graph_arithmetic(outrows)[0]
        data=s.compact(outrows);name=f'selector{int(selector)}-cache{int(cache)}-nip{int(dec)}.json'
        (a.output/name).write_bytes(data)
        m=s.metrics(new);assert m['dag_nodes']==202
        records.append(dict(file=name,selector_localized=selector,cache_return=cache,decrement_nip=dec,
            metrics=m,sha256=hashlib.sha256(data).hexdigest()))
    swaps=[]
    for j in range(1,9):
        r=[0]*9;r[j]=4;pc=0;trace=[]
        for steps in range(1000000):
            if pc==0 and all(r[k]==0 for k in [1,2,3,5,6,7]):
                status='VALID_COMMAND_BOUNDARY_WITH_TRUE_REGISTERS';break
            if pc==26 and all(r[k]==0 for k in [1,2,4,5,6,7]):
                status='VALID_AXIOM_ENTRY_WITH_TRUE_REGISTERS';break
            _,op,arg=rows[pc];dest=cfg[pc][1];trace.append([pc,r.copy()])
            if op=='CH':status='EARLY_HALT';break
            if op=='CI':r[arg]+=1;pc=dest[0]
            elif op=='CD':
                if r[arg]:r[arg]-=1;pc=dest[1]
                else:pc=dest[0]
            else:pc=dest[0]
        else:raise AssertionError('Unexpected finite-prefix limit')
        data=s.compact(trace);tracefile=f'enum-swap0{j}-prefix.json';(a.output/tracefile).write_bytes(data)
        renamed=[[p,op,j if arg==0 else 0 if arg==j else arg]if op in('CI','CD')else[p,op,arg]for p,op,arg in rows]
        sourcefile=f'enum-swap0{j}.json';(a.output/sourcefile).write_bytes(s.compact(renamed))
        swaps.append(dict(swap=[0,j],status=status,source_steps=len(trace),endpoint_ordinal=pc,
            logical_registers=r,trace_file=tracefile,trace_sha256=hashlib.sha256(data).hexdigest(),source_file=sourcefile))
    assert [r['source_steps']for r in swaps]==[318,157,10,0,25,29,29,0]
    assert [r['swap'][1]for r in swaps if r['status']=='EARLY_HALT']==[2]
    receipt=dict(status='SOURCE_RESEARCH_CHECKS_PASS',baseline_sha256=hashlib.sha256(raw).hexdigest(),
        variants=records,enumeration_swaps=swaps,
        scope='Both CFG readers agree; eight source variants and eight finite source prefixes reproduced. No physical state saving, primitive-runtime proof, blank-startup proof, or proof-assistant endpoint claimed.')
    (a.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(status=receipt['status'],variants=len(records),enumeration_swaps=len(swaps)),indent=2))
if __name__=='__main__':main()
