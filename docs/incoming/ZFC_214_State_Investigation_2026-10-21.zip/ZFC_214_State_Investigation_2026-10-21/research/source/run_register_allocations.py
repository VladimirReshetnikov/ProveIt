from pathlib import Path
import subprocess,json,time
ROOT=Path(__file__).resolve().parent;ALLOC=ROOT/'allocate215.py';OUT=ROOT/'register-allocations-corrected';OUT.mkdir(exist_ok=True)
results=[]
for p in sorted((ROOT/'register-layouts').glob('*.json')):
 out=OUT/p.stem
 with (OUT/(p.stem+'.log')).open('w')as f:
  try:r=subprocess.run(['python3','-B',str(ALLOC),'--source',str(p),'--output',str(out),'--limit','5'],stdout=f,stderr=subprocess.STDOUT,timeout=25)
  except subprocess.TimeoutExpired:results.append({'layout':p.stem,'status':'PROCESS_TIMEOUT'});continue
 if(out/'allocation.json').exists():
  a=json.loads((out/'allocation.json').read_text());x={k:a.get(k)for k in ['status','states','new_nodes','fixed_nodes','fixed_states','pool','protected_rows','solver']};x['layout']=p.stem
 else:x={'layout':p.stem,'status':'SCRIPT_FAILURE','code':r.returncode}
 results.append(x);print(json.dumps(x),flush=True)
 (OUT/'summary.json').write_text(json.dumps(results,indent=2))
