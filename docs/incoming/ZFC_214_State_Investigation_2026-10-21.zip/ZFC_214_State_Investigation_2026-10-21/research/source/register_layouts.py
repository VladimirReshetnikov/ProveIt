from pathlib import Path
import itertools,json,sys
B=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(B/'code'));import source_language as s
R=json.loads((B/'sites215.json').read_text());G=s.graph_intervals(R);out=Path(__file__).parent/'register-layouts';out.mkdir(exist_ok=True)
for a,b in itertools.combinations(range(1,9),2):
 p=list(range(9));p[a],p[b]=p[b],p[a];r=[[path,op,p[k] if op in('CI','CD')else k]for path,op,k in R]
 assert s.metrics(s.tree(r))['dag_nodes']==202
 assert [x[1]for x in s.graph_intervals(r)]==[x[1]for x in G]
 (out/f'swap{a}{b}.json').write_bytes(s.compact(r))
print('Generated28 register transpositions, all fix N and preserve guarded successors.')
