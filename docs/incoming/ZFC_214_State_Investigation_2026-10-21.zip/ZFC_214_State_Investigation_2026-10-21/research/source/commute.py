from pathlib import Path
exec((Path(__file__).resolve().parent/'rotations.py').read_text().split('res=[];')[0])
# Unique closed subtrees that are only increments, or loops affecting disjoint sets.
@lru_cache(None)
def effects(n):
 if s.leaf(n):
  return frozenset([n[1]])if n[0] in ('CI','CD') else frozenset()
 return effects(n[0])|effects(n[1])
@lru_cache(None)
def nodes(n):
 if s.leaf(n):return frozenset([n])
 return frozenset([n])|nodes(n[0])|nodes(n[1])
@lru_cache(None)
def count(n):return 1 if s.leaf(n)else count(n[0])+count(n[1])
res=[]
for node,ps in list(occ.items()):
 if s.leaf(node):continue
 a,c=node
 if all(s.boundary(x)==(0,0,False)for x in node)and not(effects(a)&effects(c)):
  tr=replace_all(old,node,(c,a));metr=s.metrics(tr)
  if metr['dag_nodes']<=202:
   res.append({'path':ps[0],'effects':[sorted(effects(a)),sorted(effects(c))],'sizes':[count(a),count(c)],'metrics':metr});print('COMMUTE',res[-1],flush=True)
   (out/f'commute-{len(res)-1}.json').write_bytes(s.compact(s.sites(tr)))
# Shuffle contiguous pure-CI sequences in arbitrary subtree (all effects commute).
for node,ps in list(occ.items()):
 if s.leaf(node):continue
 ns=nodes(node)
 if all(not s.leaf(n) or n[0]=='CI'for n in ns):
  if count(node)>9:continue
  import itertools
  ls=[x[1:]for x in s.sites(node)]
  for perm in set(itertools.permutations([tuple(l)for l in ls])):
   it=iter(perm)
   def go(n):return next(it)if s.leaf(n)else(go(n[0]),go(n[1]))
   changed=go(node)
   if changed==node:continue
   tr=replace_all(old,node,changed);metr=s.metrics(tr)
   if metr['dag_nodes']<202:
    res.append({'path':ps[0],'mode':'pureCI','old':ls,'new':perm,'metrics':metr});print('PERMUTE',res[-1],flush=True)
    (out/f'commute-{len(res)-1}.json').write_bytes(s.compact(s.sites(tr)))
(out/'commute.json').write_text(json.dumps(res,indent=2)+'\n')
print('DONE',len(res),flush=True)
