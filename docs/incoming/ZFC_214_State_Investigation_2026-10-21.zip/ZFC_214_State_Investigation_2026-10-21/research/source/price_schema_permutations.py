import sys,json,hashlib,subprocess
from pathlib import Path
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(K/'code'));import source_language as s
B=Path(__file__).resolve().parent;O=B/'schema-permutations';O.mkdir(exist_ok=True)
ss=json.loads((K/'sites215.json').read_text());old=s.tree(ss);records=[]
for rho6,joint in [(False,False),(True,False),(False,True),(True,True)]:
 rows=[r.copy()for r in ss];intervals=([(888,1171)]if rho6 else[])+([(1467,1766),(2062,2412)]if joint else[]);edits=[]
 for lo,hi in intervals:
  for i in range(lo,hi):
   p,o,a=rows[i]
   if o in('CI','CD')and a in(3,5):rows[i][2]=8-a;edits.append([i,p,o,a,8-a])
 t=s.tree(rows);name=f'rho6{int(rho6)}-joint24{int(joint)}';source=O/(name+'.json');source.write_bytes(s.compact(rows));m=s.metrics(t);assert m['dag_nodes']==202;assert s.graph_intervals(rows)==s.graph_arithmetic(rows)[0]
 d=O/(name+'-allocation');cp=subprocess.run(['python3',str(B/'allocate215.py'),'--source',str(source),'--output',str(d),'--limit','10'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(O/(name+'.log')).write_text(cp.stdout)
 r=json.loads((d/'allocation.json').read_text())if(d/'allocation.json').exists()else{'status':'CRASH'}
 rec={'rho6':rho6,'joint_rho2_rho4':joint,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'metrics':m,'edits':edits,'allocation':{'status':r['status'],'states':r.get('states'),'new_nodes':r.get('new_nodes'),'fixed_states':r.get('fixed_states')}};records.append(rec);print(json.dumps(rec),flush=True)
 (O/'records.json').write_text(json.dumps(records,indent=2)+'\n')
