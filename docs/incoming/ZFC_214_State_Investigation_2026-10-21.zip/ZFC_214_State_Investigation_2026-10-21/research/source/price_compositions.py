import json,subprocess,time,os,concurrent.futures
from pathlib import Path
B=Path(__file__).resolve().parent;O=B/'composition-pricing';O.mkdir(exist_ok=True)
files=sorted((B/'nip-compositions').glob('nip-composition*.json'))+sorted((B/'compositions').glob('composition[0-9]*.json'))
start=time.monotonic();results=[]
def run(args):
 i,source=args;d=O/f'trial{i:03}'
 env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
 cp=subprocess.run(['python3',str(B/'allocate215.py'),'--source',str(source),'--output',str(d),'--limit','2'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env)
 (O/f'trial{i:03}.log').write_text(cp.stdout)
 r=json.loads((d/'allocation.json').read_text())if(d/'allocation.json').exists()else{'status':'CRASH'}
 return {'index':i,'source':str(source),'directory':str(d),'status':r.get('status'),'states':r.get('states'),'new_nodes':r.get('new_nodes'),'fixed_states':r.get('fixed_states'),'domain_sizes':r.get('domain_sizes')}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:
 for r in ex.map(run,enumerate(files)):
  results.append(r)
  if r['status']!='NO_ALLOCATION':print('RESULT',json.dumps(r),flush=True)
  if len(results)%25==0:print('PROGRESS',len(results),'/',len(files),'SECONDS',round(time.monotonic()-start,1),flush=True)
  (O/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print('DONE',len(results),'SECONDS',time.monotonic()-start,flush=True)
