import json,sys,hashlib,subprocess,time
from pathlib import Path
K=(Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215');sys.path.insert(0,str(K/'code'));import source_language as s
B=Path(__file__).resolve().parent;O=B/'enum-swaps';O.mkdir(exist_ok=True)
ss=json.loads((K/'sites215.json').read_text());cfg=s.graph_intervals(ss);records=[]
for j in range(1,9):
 r=[0]*9;r[j]=4;pc=0;trace=[];status='LIMIT'
 for steps in range(1000000):
  if pc==0 and all(r[k]==0 for k in [1,2,3,5,6,7]):status='VALID_COMMAND_BOUNDARY_WITH_TRUE_REGISTERS';break
  if pc==26 and all(r[k]==0 for k in [1,2,4,5,6,7]):status='VALID_AXIOM_ENTRY_WITH_TRUE_REGISTERS';break
  _,o,a=ss[pc];d=cfg[pc][1];trace.append([pc,r.copy()])
  if o=='CH':status='EARLY_HALT';break
  if o=='CI':r[a]+=1;pc=d[0]
  elif o=='CD':
   if r[a]:r[a]-=1;pc=d[1]
   else:pc=d[0]
  else:pc=d[0]
 new=[[p,o,j if a==0 else 0 if a==j else a]if o in('CI','CD') else[p,o,a] for p,o,a in ss]
 source=O/f'swap0{j}.json';source.write_bytes(s.compact(new))
 raw=s.compact(trace);(O/f'swap0{j}-burnin.json').write_bytes(raw)
 rec={'swap':[0,j],'status':status,'source_steps':len(trace),'endpoint_pc':pc,'logical_registers':r,'trace_sha256':hashlib.sha256(raw).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'proof_scope':'Literal finite source prefix. Boundary soundness uses the established K215 command theorem; no binary-machine compilation or blank-startup proof claimed.'}
 records.append(rec);print(json.dumps(rec),flush=True)
(O/'burnin-receipts.json').write_text(json.dumps(records,indent=2)+'\n')
for rec in records:
 if rec['status']=='EARLY_HALT':continue
 j=rec['swap'][1];source=O/f'swap0{j}.json';d=O/f'allocation0{j}'
 cp=subprocess.run(['python3',str(B/'allocate215.py'),'--source',str(source),'--output',str(d),'--limit','5'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (O/f'allocation0{j}.log').write_text(cp.stdout)
 rr=json.loads((d/'allocation.json').read_text())if(d/'allocation.json').exists()else{'status':'CRASH'}
 rec['allocation']={'status':rr['status'],'states':rr.get('states'),'fixed_nodes':rr.get('fixed_nodes'),'new_nodes':rr.get('new_nodes')};print('ALLOC',j,rec['allocation'],flush=True)
 (O/'burnin-receipts.json').write_text(json.dumps(records,indent=2)+'\n')
