#!/usr/bin/env python3
"""Exact bounded seed-only specializations; a source price, not a new TM.

Only scalar loads inside nks are replaced. Symbolic stack evaluation checks both
original and specialized bundle expressions. Raw 0/1 is known unsound at C=0;
no consistency claim is made for any source by this script.
"""
import argparse
from functools import cache
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
DEFAULT = HERE.parents[2] / 'baseline' / 'candidate-k215'
PIN = '17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline', type=Path, default=DEFAULT)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    sys.path.insert(0, str(args.baseline))
    import source_language as s
    original = (args.baseline / 'sites215.json').read_bytes()
    assert hashlib.sha256(original).hexdigest() == PIN
    tree = s.tree(json.loads(original))
    a = s.subtree(tree, '1101001001101')
    b = s.subtree(tree, '1101001001001')
    c = s.subtree(tree, '1101001001100')
    implication = s.subtree(tree, '1101001001010')
    zero = a[0]
    one = (zero, ('CI', 1))
    macros = {a: 'A', b: 'B', c: 'C', implication: 'I', zero: '0', one: '1'}

    @cache
    def size(t):
        return 1 if s.leaf(t) else size(t[0]) + size(t[1])

    word = []
    def scan(t, path='', lo=0):
        hi = lo + size(t)
        if hi <= 2643 or lo >= 4556:
            return
        if 2643 <= lo and hi <= 4556 and t in macros:
            word.append((lo, hi, path, macros[t]))
            return
        if s.leaf(t):
            assert t == ('CI', 1)
            word.append((lo, hi, path, '+'))
            return
        scan(t[0], path+'0', lo)
        scan(t[1], path+'1', lo+size(t[0]))
    scan(tree)

    def execute(tokens):
        stack = ['OLD']
        for lo, hi, path, token in tokens:
            if token in ('A', 'B', 'C'):
                stack.append(token)
            elif token in ('0', '1'):
                stack.append(int(token))
            elif token == 'I':
                right, left = stack.pop(), stack.pop()
                stack.append(('code', 0, left, right))
            else:
                assert token == '+' and stack[-1][0] == 'code'
                _, tag, left, right = stack.pop()
                assert tag < 3
                stack.append(('code', tag+1, left, right))
        return stack

    I = lambda x,y: ('code', 0, x, y)
    R = lambda x,y: ('code', 1, x, y)
    Q = lambda x,y: ('code', 2, x, y)
    N = lambda x: I(x, 1)
    def req(b,k,m):
        return Q(b,I(m,N(Q(b,I(m,N(R(b,k)))))))
    def clos(a,b,k,m):
        return Q(b,I(R(b,k),N(Q(a,I(m,N(Q(a,I(Q(k,I(R(k,a),R(k,b))),req(b,k,m)))))))))
    def nks(a,b,c):
        return Q(c,I(clos(a,b,c,c),N(req(b,c,c))))
    def vrel(a,b,c):
        return I(R(a,b),Q(c,R(a,b)))
    def formula(a,b):
        return N(I(vrel('A','B','C'), nks(a,b,'C')))
    assert execute(word) == ['OLD', formula('A','B')]
    profiles = [('01', {'A':0,'B':1}), ('10', {'A':1,'B':0}),
                ('B1', {'B':1}), ('A1', {'A':1}), ('B0', {'B':0})]
    records = []
    args.output.mkdir(parents=True, exist_ok=True)
    for name, values in profiles:
        result = tree
        changed = []
        tokens = []
        for lo,hi,path,token in word:
            replacement = token
            if 2885 <= lo < 4482 and token in values:
                value = values[token]
                result = s.replace(result, path, one if value else zero)
                replacement = str(value)
                changed.append({'interval':[lo,hi], 'path':path, 'old':token, 'new':value})
            tokens.append((lo,hi,path,replacement))
        assert execute(tokens) == ['OLD', formula(values.get('A','A'),values.get('B','B'))]
        rows = s.sites(result)
        assert s.graph_arithmetic(rows)[0] == s.graph_intervals(rows)
        raw = s.compact(rows)
        filename = 'fixed_seed'+name+'.json'
        (args.output / filename).write_bytes(raw)
        records.append({'profile':name,'source':filename,'source_sha256':hashlib.sha256(raw).hexdigest(),
                        'metrics':s.metrics(result),'changes':changed,'symbolic_bundle_exact':True})
    receipt = {'status':'EXACT_BOUNDED_SOURCE_PRICING', 'baseline_sha256':PIN,
               'bundle_interval':[2643,4556], 'vrel_interval':[2643,2885],
               'nks_interval':[2885,4482], 'gate_interval':[4556,4590],
               'source_profiles':records,
               'scope':'Literal scalar-load replacements only; logical rows, vrel and original gates unchanged. No physical allocation or runtime certification.',
               'calibration':'Raw fixed roles 0/1 are UNSOUND at C=0. Other profiles require separate mathematical arguments; this script claims only exact constructor expressions and source prices.'}
    (args.output / 'prices.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (args.output / 'bundle_macros.json').write_text(json.dumps(word,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'results':[{k:r[k] for k in ('profile','metrics','source_sha256')} for r in records]},indent=2))

if __name__ == '__main__':
    main()
