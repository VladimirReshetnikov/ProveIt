SEED-CORE ROLE SPECIALIZATIONS: EXACT BOUNDED SOURCE PRICES

Reproduce all five source files and this complete receipt with:
  python price_fixed_seed.py --output /tmp/zfc-fixed-seed-replay
The default baseline is the archive's pinned candidate-k215. Only Python's
standard library and the baseline source_language.py are used.

The script recovers the bundle's exact scalar-load/constructor word and checks
it symbolically against the inherited numerical definition. It replaces only
selected A/B loads inside nks. It leaves all logical rows, vrel(A,B,C), and both
original C!=A/B freshness gates unchanged. Exact independent arithmetic and
interval control-flow calculations agree for every generated source.

Profile     DAG nodes    Primitive occurrences
baseline        202               4751
A=0,B=1         209               4676
A=1,B=0         209               4670
B=1 only        206               4697
A=1 only        206               4733
B=0 only        206               4688

These are source costs, not physical state counts. No table was allocated.
The original arbitrary A/B macros remain needed elsewhere, so shorter constant
loads reduce expanded occurrence counts but worsen whole-program DAG sharing.

The unshifted A=0,B=1 specialization is mathematically UNSOUND at C=0: the
collision of the private binder with the input binder forces every object to
be nonempty. Its source is a rejected control, not a consistency machine.
B=1 alone is the positive formalism specialization analyzed separately in
the formalism notes; fixed_seedB1.json is included as its exact 206-DAG source.
The B=0 profiles also fail at C=0: their request becomes
forall 0 (truth -> exists 0 (truth and R(0,0))), which is false in
every nonempty irreflexive model, so the seed core is false. The A=1-only
profile requires its own full calibration; none of these controls is
presented as an accepted machine.
This source-price checker itself proves no consistency theorem.

Root follow-up: the bundled partial fixed-role allocator, with no fresh states,
reports NO_ALLOCATION for fixed_seedB1.json (1,544 variables,139 constraints;
solver reports the specified model infeasible). See allocation.json. No table
was emitted, and this is not a lower bound on other implementations.
