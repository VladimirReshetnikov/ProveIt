import sys,json,random,time,collections,functools
from pathlib import Path
OUT=(Path(__file__).resolve().parent/'zero-targeted')
OUT.mkdir(exist_ok=True)
lib=((Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')/'code')
sys.path.insert(0,str(lib));import source_language as s,build221 as b
SRC=((Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')/'sites215.json')
root0=s.tree(json.loads((Path(__file__).resolve().parent/'retag-zero-output/retag-source204.400.json').read_text())); T=b.read_table(((Path(__file__).resolve().parents[2]/'baseline'/'candidate-k215')/'k215.native.tm').read_bytes())
G,P=b.decoder_map(T,s.tree(json.loads(SRC.read_text())))
N=[];lookup={}
def intern(a,b=None):
 key=a if b is None else(a,b)
 if key not in lookup:lookup[key]=len(N);N.append(key)
 return lookup[key]
def toid(n):return intern(n) if s.leaf(n) else intern(toid(n[0]),toid(n[1]))
def lf(n):return isinstance(N[n][0],str)
root=toid(root0)
protected=set()
print('protected',protected,[(q,len(G[q]),P[q][:5])for q in(69,213,90,92)],flush=True)
@functools.cache
def closed(n):
 if lf(n):
  o,a=N[n];return (1,0,False)if o=='CD'else(a,0,False)if o=='CB'else(0,a,False)if o=='CC'else(0,0,o=='CH')
 l,r=map(closed,N[n]);return(max(l[0]-1,r[0],0),max(l[1],r[1]-1,0),l[2]or r[2])
@functools.cache
def totr(n):return N[n]if lf(n)else tuple(map(totr,N[n]))
def infos(r):
 reach=set();depth={};zeros={};leftz={}
 def go(n):
  if n in reach:return
  reach.add(n)
  if lf(n):depth[n]=zeros[n]=leftz[n]=0
  else:
   a,c=N[n];go(a);go(c);depth[n]=1+max(depth[a],depth[c]);leftz[n]=1+leftz[a];zeros[n]=max(leftz[n],zeros[a],zeros[c])
 go(r);return reach,depth[r],zeros[r]
def replace(r,old,new):
 cache={}
 def go(n):
  if n==old:return new
  if lf(n):return n
  if n in cache:return cache[n]
  a,c=N[n];aa,cc=go(a),go(c);cache[n]=intern(aa,cc);return cache[n]
 return go(r)
@functools.cache
def size(n):return 1 if lf(n) else sum(size(c)for c in N[n])
@functools.cache
def sem(n):
 out=[]
 def go(q,i,zs,os):
  if lf(q):
   o,a=N[q]
   if o in('CD','CB'):
    aa=1 if o=='CD'else a;v=zs[-aa]if aa<=len(zs)else('ext',aa-len(zs))
   elif o=='CC':v=os[-a]if a<=len(os)else('ext',a-len(os))
   else:v=None
   out.append((o,a,v));return
  a,c=N[q];go(a,i,zs+[i+size(q)],os);go(c,i+size(a),zs,os+[i])
 go(n,0,[],[]);return tuple(out)
@functools.cache
def rotate(n,d):
 a,c=N[n]
 if d=='L':
  if lf(c):return None
  bb,cc=N[c];r=intern(intern(a,bb),cc)
 else:
  if lf(a):return None
  aa,bb=N[a];r=intern(aa,intern(bb,c))
 old=sem(n)
 def go(q,i,zs,os):
  if lf(q):
   o,a,v=old[i]
   if o in('CD','CB','CC'):
    ar=zs if o in('CD','CB')else os
    if isinstance(v,tuple):aa=len(ar)+v[1]
    else:
     if v not in ar:raise ValueError
     aa=1+ar[::-1].index(v)
    if o=='CD':
     actual=ar[-1]if ar else('ext',1)
     if actual!=v:raise ValueError
    else:
     if o=='CB'and aa!=1:raise ValueError
     if o=='CC'and aa>3:raise ValueError
     a=aa
   return intern((o,a))
  a,c=N[q];return intern(go(a,i,zs+[i+size(q)],os),go(c,i+size(a),zs,os+[i]))
 try:return go(r,0,[],[])
 except ValueError:return None
@functools.cache
def badinfo(n):
 if lf(n):return ((1,0,0,0,0,0),0)
 lh,lb=badinfo(N[n][0]);rh,rb=badinfo(N[n][1]);return ((sum(rh),*lh[:5]),lb+rb+lh[5])
def moves(r,reach):
 for n in reach-protected:
  if lf(n):continue
  for d in('L','R'):
   rr=rotate(n,d)
   if rr is not None:yield n,rr,d

baseline=s.graph_intervals(s.sites(root0))
candidates=[]
for n,new,kind in moves(root,infos(root)[0]):
 rr=replace(root,n,new);rch,d,z=infos(rr);bad=badinfo(rr)[1]
 candidates.append((len(rch),bad,d,z,rr,n,new,kind))
for cost,bad,d,z,rr,n,new,kind in sorted(candidates)[:30]:
 print(cost,bad,d,z,size(n),kind)
for j,(cost,bad,d,z,rr,n,new,kind) in enumerate(sorted(candidates,key=lambda x:(x[1],x[0]))[:10]):
 out=s.sites(totr(rr));assert s.graph_intervals(out)==baseline
 (OUT/f'next{j:02}-dag{cost}-bad{bad}.json').write_bytes(s.compact(out))
 print('ZERO',cost,bad,d,z,size(n),kind)
