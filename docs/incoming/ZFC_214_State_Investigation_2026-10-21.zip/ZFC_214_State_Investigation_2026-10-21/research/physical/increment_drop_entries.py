#!/usr/bin/env python3
"""Narrow finite alias screen for new CB/CC decoder parents.

Each proposed entry must finish before any premature dispatcher re-entry and
may use only the protected engine rows. Two concrete register/gap frames are
checked. This is discovery, not a universal contract or a lower bound.
"""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
from types import SimpleNamespace
import argparse,sys,json,time,hashlib
ap=argparse.ArgumentParser()
ap.add_argument('--candidate',type=Path,required=True)
ap.add_argument('--source',type=Path,required=True)
ap.add_argument('--engine',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True)
args=ap.parse_args()
B=args.candidate.resolve()
sys.path[:0]=[str(B/'code'),str(B)]
import source_language as language
import build221 as builder

def paths(n,p=''):
 if language.leaf(n):return
 yield p,n
 yield from paths(n[0],p+'0')
 yield from paths(n[1],p+'1')

def edge(T,q,p,bit):
 tape={-1:1,**{i:int(v)for i,v in enumerate(p+str(bit))}}
 before=dict(tape);h=len(p);used=[]
 for _ in range(100):
  if h==len(p)+1:return(q if tape==before else None),used
  if h not in tape or(q,tape[h])not in T:return None,used
  k=(q,tape[h]);used.append(k);w,d,q=T[k];tape[h]=w;h+=d
 return None,used

a=SimpleNamespace(s=language,b=builder,paths=paths,edge=edge,ENGINE=args.engine)
T=builder.read_table((B/'k215.native.tm').read_bytes())
assert hashlib.sha256((B/'k215.native.tm').read_bytes()).hexdigest()=='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
old=language.tree(json.loads((B/'sites215.json').read_text()))
rows=json.loads(args.source.read_text());new=language.tree(rows)
groups,oldpaths=builder.decoder_map(T,old);oldstates=defaultdict(set)
for q,ns in groups.items():
 for n in ns:oldstates[n].add(q)
occ=defaultdict(list)
for p,n in a.paths(new):occ[n].append(p)
@lru_cache(None)
def compatible(n,p,q):
 if q not in oldstates.get(n,()):return False
 for bit,ch in enumerate(n):
  if a.s.leaf(ch):
   if q==108 and bit==1:
    required={'CC':'101','CB':'001'}.get(ch[0])
    if required is not None and not ('1'+p+'1').endswith(required):return False
   continue
  z,_=a.edge(T,q,p,bit)
  if z is None or not compatible(ch,p+str(bit),z):return False
 return True
fixed={n:{q for q in oldstates.get(n,())if all(compatible(n,p,q)for p in ps)}for n,ps in occ.items()}
newnodes=[n for n in occ if not fixed[n]]
leafacts=defaultdict(set)
for q,ns in groups.items():
 for n in ns:
  for bit,ch in enumerate(n):
   if a.s.leaf(ch):leafacts[ch,bit].add(T[q,bit])
Q=sorted({q for q,b in T});M={q:i for i,q in enumerate(Q)};M[254]=len(Q);E=[None]*(2*len(Q))
for(q,b),(w,d,z)in T.items():E[2*M[q]+b]=(w,d,M[z])
protected={tuple(k)for k in json.loads(a.ENGINE.read_text())['rows']};protected.discard((92,1));protected|={(81,0),(111,0),(111,1),(104,0),(128,0)}
phy=[6,2,0,4,3,7,8,5,1];mid=128

def frame(pc,mode,gap,shift,registers=None,spares=4):
 h=mid+shift;t=(1<<(h-1))
 for i,b in enumerate(pc):t|=int(b)<<(h+i)
 pos=h+64+gap;t|=1<<pos;pos+=1
 regs=([0]*9 if mode==0 else[2]*9)if registers is None else registers
 physical=[0]*9
 for r,v in enumerate(regs):physical[phy[r]]=v
 for v in physical+[1]*spares:pos+=1;t|=((1<<(v+1))-1)<<pos;pos+=v+1
 return t

def strip(pc,bit,n):
 for i in range(len(pc)-1,-1,-1):
  if pc[i]==bit:
   n-=1
   if not n:return pc[:i]
 return ''
def inc(pc):
 if not pc:return '',1
 v=int(pc,2)+1;return format(v%(1<<len(pc)),f'0{len(pc)}b'),int(v>=1<<len(pc))

def check(pc,op,r,act,mode):
 gap=1 if mode==0 else 3;initial=frame(pc,mode,gap,0)
 regs=[0]*9 if mode==0 else[2]*9;after=regs.copy();delta=0;spares=4
 if op=='CI':after[r]+=1;dest,ov=inc(pc);spares+=1
 elif op=='CD'and regs[r]>0:after[r]-=1;delta=1;dest,ov=inc(pc)
 elif op in('CB','CD'):dest,ov=inc(strip(pc,'0',r if op=='CB'else 1))
 else:dest,ov=strip(pc,'1',r),0
 target=frame(dest,mode,gap+delta+ov,-ov,after,spares);expectedhead=mid-ov
 w,d,z=act;h=mid+len(pc)-1;t=(initial&~(1<<h))|(w<<h);h+=d;q=M[z]
 for tick in range(5000):
  if q==M[84]and h==expectedhead and t==target:return True,tick+1
  if q==M[84]or q==len(Q)or not 0<=h<1024:return False,tick+1
  bit=(t>>h)&1
  if (Q[q],bit)not in protected:return False,tick+1
  w,d,q=E[2*q+bit];t=(t&~(1<<h))|(w<<h);h+=d
 return False,5001
start=time.monotonic();results=[];attempted=0
for idx,n in enumerate(newnodes):
 for bit,ch in enumerate(n):
  if not a.s.leaf(ch)or ch[0]not in('CB','CC'):continue
  pcs=[p+str(bit)for p in occ[n]];actions=sorted({v for(q,b),v in T.items()if b==bit and(q,b)in protected}-leafacts[ch,bit]);hits=[]
  for action in actions:
   attempted+=1;good=True
   for pc in sorted(pcs,key=lambda p:(len(p),p)):
    for mode in range(2):
     ok,_=check(pc,*ch,action,mode)
     if not ok:good=False;break
    if not good:break
   if good:hits.append(action)
  oldpasses=[]
  for action in sorted(leafacts[ch,bit]):
   if all(check(pc,*ch,action,mode)[0]for pc in pcs for mode in range(2)):oldpasses.append(action)
  rec={'canonical_control_passes':oldpasses,'newnode_index':idx,'node_path':occ[n][0],'leaf_bit':bit,'primitive':ch,'occurrences':pcs,'actions_tested':len(actions),'new_actions':hits,'old_actions':sorted(leafacts[ch,bit])};results.append(rec);print('NODE',idx,ch,'paths',len(pcs),'hits',hits,flush=True)
assert all(r['canonical_control_passes']for r in results),'canonical positive control failed'
out={'table_sha256':hashlib.sha256((B/'k215.native.tm').read_bytes()).hexdigest(),'engine_filter_sha256':hashlib.sha256(args.engine.read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'status':'FINITE_ENTRY_SCREEN','scope':'Extra entries for newly allocated CB/CC parents only; two concrete register/gap frames, four unit spares,5000-step bound. Continuation restricted to protected engine rows and must return directly to the exact target frame at its first dispatcher visit. Discovery only, not a lower bound or a universal primitive proof.','source_sha256':hashlib.sha256(args.source.read_bytes()).hexdigest(),'new_nodes':len(newnodes),'attempted_actions':attempted,'results':results,'seconds':time.monotonic()-start};args.output.write_text(json.dumps(out,indent=2)+'\n');print('DONE',attempted,sum(len(r['new_actions'])for r in results),out['seconds'])
