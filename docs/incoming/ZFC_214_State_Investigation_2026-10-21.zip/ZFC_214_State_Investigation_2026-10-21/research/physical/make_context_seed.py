#!/usr/bin/env python3
"""Portable finite-search seed builder; bucket invariant is also post-fixed-point checked.

Buckets0..7 are exact; bucket8 means >=8. The abstract state is a Cartesian
product of nine sets of buckets. This seed is for finite discovery, not a
certificate that any proposed machine is correct.
"""
from pathlib import Path
from collections import deque
import argparse,hashlib,json
from reachable_source_check import read_source,graph_arithmetic,graph_intervals,need

def main():
    p=argparse.ArgumentParser();p.add_argument('--table',type=Path,required=True);p.add_argument('--sites',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--initial',default='4,0,0,0,0,0,0,0,0');a=p.parse_args()
    source=read_source(a.sites);rows=source[0];G=graph_arithmetic(source);need(G==graph_intervals(source),'independent source CFG resolvers disagree')
    seed=[int(n)for n in a.initial.split(',')];need(len(seed)==9 and min(seed)>=0,'nine nonnegative initial registers required')
    inc=lambda m:((m<<1)&511)|(m&256)
    dec=lambda m:(m>>1)|(m&256)
    def transfer(i,v):
        _,op,r=rows[i];out=[]
        if op=='CH':return out
        if op=='CI':w=v.copy();w[r]=inc(w[r]);return[(G[i][0],w)]
        if op=='CD':
            if v[r]&1:w=v.copy();w[r]=1;out.append((G[i][0],w))
            if v[r]&510:w=v.copy();w[r]=dec(w[r]&510);out.append((G[i][1],w))
            return out
        return[(G[i][0],v)]
    masks=[None]*len(rows);masks[0]=[1<<min(n,8)for n in seed];todo=deque([0]);queued={0};steps=0
    while todo:
        i=todo.popleft();queued.remove(i);steps+=1
        for j,w in transfer(i,masks[i]):
            old=masks[j];new=w if old is None else[x|y for x,y in zip(old,w)]
            if old!=new:
                masks[j]=new
                if j not in queued:queued.add(j);todo.append(j)
    checked=0
    for i,v in enumerate(masks):
        if v is None:continue
        for j,w in transfer(i,v):
            need(masks[j]is not None and all(x&~y==0 for x,y in zip(w,masks[j])),'abstract edge is not inductive');checked+=1
    need(all((1<<min(x,8))&~y==0 for x,y in zip(seed,masks[0])),'initial state not enclosed')
    T={}
    for line in a.table.read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();need((int(q),int(b))not in T,'duplicate table row');T[int(q),int(b)]=(int(w),1 if d=='R'else-1,int(z))
    Q=sorted({q for q,b in T});index={q:i for i,q in enumerate(Q)};need(254 not in index,'halt may not be a working state');index[254]=len(Q)
    need(len(T)==2*len(Q)and all((q,b)in T for q in Q for b in(0,1)),'incomplete table')
    out=[str(len(Q)),' '.join(map(str,Q))]
    for q in Q:
        for b in(0,1):
            w,d,z=T[q,b];need(z in index,'undefined nonhalt target');out.append(f'{w} {d} {index[z]}')
    out.append(str(len(rows)))
    for(pc,op,arg),v in zip(rows,masks):
        out.append(f'{pc} {op} {-1 if arg is None else arg}')
        out.append(' '.join(map(str,v or[0]*9)))
    a.output.write_text('\n'.join(out)+'\n')
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    report={'status':'INDUCTIVE_BUCKET_SEED_FOR_FINITE_SEARCH','initial':seed,'source_sites':len(rows),'working_states':len(Q),'worklist_steps':steps,'checked_inductive_edges':checked,'dead_ordinals':[i for i,v in enumerate(masks)if v is None],'table_sha256':sha(a.table),'source_sha256':sha(a.sites),'seed_sha256':sha(a.output),'checker_sha256':sha(Path(__file__)),'scope':'Independent CFG resolvers agree; every abstract transfer is included in its target, and the initial register vector is enclosed. Seed supports finite counterexample discovery, not correctness of altered Turing tables.'}
    a.output.with_suffix('.receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
