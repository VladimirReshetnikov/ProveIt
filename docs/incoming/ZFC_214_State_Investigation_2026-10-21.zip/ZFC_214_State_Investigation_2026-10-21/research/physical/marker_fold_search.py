#!/usr/bin/env python3
"""Finite marker-aware state-fold discovery; every output needs full validation."""
from pathlib import Path
import argparse,hashlib,json,time
from inv_fold import load,invariant

def folds(T,st,R=12,fuel=25):
 I=invariant(T,st,R);Q=sorted(I);result=[];attempts=0
 for k in Q:
  for d in Q:
   if d==k or not any(o in I[d]and I[d][o]!=v for o,v in I[k].items()):continue
   red=lambda z:k if z==d else z
   same=[b for b in(0,1)if T[k,b][:2]==T[d,b][:2]and red(T[k,b][2])==red(T[d,b][2])]
   if not same:continue
   if len(same)==2:result.append((k,d,None,None));continue
   r=1-same[0];goals=[]
   for x in(k,d):
    if 0 in I[x]and I[x][0]!=r:continue
    w,di,z=T[x,r];tape=dict(I[x]);tape[0]=r;after=dict(tape);after[0]=w;goals.append((tape,(red(z),1 if di=='R'else-1,after)))
   for w in(0,1):
    for di in('L','R'):
     for z in Q:
      if z==d:continue
      act=(w,di,z);attempts+=1;okay=True;ns=[]
      for t,g in goals:
       q=k;h=0;t=dict(t);good=False
       for n in range(fuel+1):
        if(q,h,t)==g:good=True;ns.append(n);break
        if n==fuel or h not in t or(q,t[h])not in T:break
        nw,nd,nz=act if(q,t[h])==(k,r)else T[q,t[h]];t[h]=nw;h+=1 if nd=='R'else-1;q=red(nz)
       if not good:okay=False;break
      if okay:result.append((k,d,r,act,ns));break
     if result and result[-1][0:2]==(k,d):break
    if result and result[-1][0:2]==(k,d):break
 return result,attempts


def main():
    p=argparse.ArgumentParser();p.add_argument('--table',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--radius',type=int,default=12);p.add_argument('--fuel',type=int,default=25);a=p.parse_args()
    T,st=load(a.table);start=time.monotonic();hits,attempts=folds(T,st,a.radius,a.fuel)
    report={'status':'FINITE_DISCOVERY_COMPLETE','working_states':len(T)//2,'radius':a.radius,'fuel':a.fuel,'attempted_actions':attempts,'hits':hits,'seconds':time.monotonic()-start,'table_sha256':hashlib.sha256(a.table.read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Known-bit state invariant from an unconstrained initial tape; one equal quotient row, one marker-sensitive replacement row, bounded exact local joins. This is one restricted search family, not a lower bound or a final candidate proof.'}
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
