#include <bits/stdc++.h>
using namespace std;
struct Act{int w,d,z;};
int main(int argc,char**argv){
 ifstream in(argv[1]);int N;in>>N;vector<int>labels(N);unordered_map<int,int>ix;for(int i=0;i<N;i++){in>>labels[i];ix[labels[i]]=i;}vector<array<Act,2>>T(N);for(auto&r:T)for(auto&a:r)in>>a.w>>a.d>>a.z;
 int ns;in>>ns;vector<bitset<32768>>ctx(N);long long cases=0,steps=0;mt19937 rng(214);int phy[9]={6,2,0,4,3,7,8,5,1};
 for(int si=0;si<ns;si++){
  string pc,op;int arg;in>>pc>>op>>arg;array<int,9>masks;for(int&v:masks)in>>v;
  if(!masks[0]||op=="CI")continue;
  for(int mode=0;mode<5;mode++)for(int positive=0;positive<(op=="CD"?2:1);positive++){
   if(op=="CD"&&!(masks[arg]&(positive?510:1)))continue;
   array<int,9>reg;
   for(int r=0;r<9;r++){vector<int>opts;for(int k=0;k<13;k++)if(masks[r]&(1<<min(k,8)))opts.push_back(k);if(opts.empty())abort();reg[r]=opts[mode==0?0:mode==1?min(1,(int)opts.size()-1):mode==2?min(2,(int)opts.size()-1):rng()%opts.size()];}
   if(op=="CD"){if(!positive)reg[arg]=0;else if(!reg[arg]){for(int k=1;k<13;k++)if(masks[arg]&(1<<min(k,8))){reg[arg]=k;break;}}}
   int mid=1024,h=mid,q=ix.at(84),gap=(mode%2?3:1);
   auto frame=[&](string path,array<int,9>regs,int ngap,int shift,int spares){array<unsigned char,4096>x{};int mh=mid+shift;x[mh-1]=1;for(int k=0;k<(int)path.size();k++)x[mh+k]=path[k]=='1';int pos=mh+64+ngap;x[pos++]=1;array<int,9>phys;for(int r=0;r<9;r++)phys[phy[r]]=regs[r];for(int r=0;r<9+spares;r++){int v=r<9?phys[r]:1;pos++;for(int k=0;k<v+1;k++)x[pos++]=1;}return x;};
   auto inc=[](string p){bool carry=true;for(int k=(int)p.size()-1;k>=0;k--){if(p[k]=='0'){p[k]='1';carry=false;break;}p[k]='0';}return pair<string,int>(p,carry?1:0);};
   auto strip=[](string p,char b,int count){if(!count)return p;for(int k=(int)p.size()-1;k>=0;k--)if(p[k]==b&&!--count)return p.substr(0,k);return string("");};
   auto tape=frame(pc,reg,gap,0,40);auto after=reg;string next;int overflow=0,delta=0,spares=40;
   if(op=="CI"){after[arg]++;tie(next,overflow)=inc(pc);spares++;}
   else if(op=="CD"&&positive){after[arg]--;delta++;tie(next,overflow)=inc(pc);}
   else if(op=="CD"||op=="CB")tie(next,overflow)=inc(strip(pc,'0',op=="CD"?1:arg));
   else if(op=="CC")next=strip(pc,'1',arg);
   auto target=frame(next,after,gap+delta+overflow,-overflow,spares);
   bool done=false;for(int tick=0;tick<100000;tick++){
    if(tick&&op!="CH"&&q==ix.at(84)&&h==mid-overflow&&tape==target){done=true;break;}if(q==N){done=op=="CH";break;}if(h<8||h>4087)abort();int word=0;for(int o=-7;o<=7;o++)word|=tape[h+o]<<(o+7);ctx[q].set(word);auto a=T[q][tape[h]];tape[h]=a.w;h+=a.d;q=a.z;steps++;
   }
   if(!done){cerr<<"failed "<<si<<" "<<mode<<" "<<positive<<"\n";return 2;}cases++;
  }
 }
 ofstream out(argv[2]);out<<N<<"\n";for(int q:labels)out<<q<<" ";out<<"\n";for(auto&r:T)for(auto a:r)out<<a.w<<" "<<a.d<<" "<<a.z<<"\n";long long count=0;for(auto&b:ctx){out<<b.count();count+=b.count();for(int m=0;m<32768;m++)if(b[m])out<<" "<<m;out<<"\n";}cerr<<"cases "<<cases<<" steps "<<steps<<" contexts "<<count<<"\n";
}
