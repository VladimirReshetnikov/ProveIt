#!/usr/bin/env python3
"""Apply each supplied single-row variant, then search one marker fold."""
from pathlib import Path
import argparse,hashlib,json,time
from inv_fold import load
from marker_fold_search import folds

def main():
    p=argparse.ArgumentParser();p.add_argument('--table',type=Path,required=True);p.add_argument('--variants',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    T,st=load(a.table);V=json.loads(a.variants.read_text());n=0;hits=[];started=time.monotonic()
    for item in V:
        key=tuple(item['row']);old=tuple(item['old'])
        assert T[key]==(old[0],'R'if old[1]==1 else'L',old[2])
        for action in item['actions']:
            if tuple(action)==old:continue
            n+=1;N=T.copy();N[key]=(action[0],'R'if action[1]==1 else'L',action[2]);ans,attempts=folds(N,st)
            for hit in ans:hits.append({'variant':n,'change':[*key,*action],'fold':hit,'attempted_actions':attempts})
            if n%50==0:print('VARIANTS',n,'HITS',len(hits),flush=True)
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    report={'status':'FINITE_DISCOVERY_COMPLETE','variants':n,'hits':hits,'seconds':time.monotonic()-started,'table_sha256':sha(a.table),'variant_list_sha256':sha(a.variants),'checker_sha256':sha(Path(__file__)),'scope':'Each supplied row variant independently followed by one radius12/fuel25 marker fold. Zero hits is a restricted finite search result, not a lower bound.'}
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
