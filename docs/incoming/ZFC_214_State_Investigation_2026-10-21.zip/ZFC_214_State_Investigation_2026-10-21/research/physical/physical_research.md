# Physical reduction work: exact targets and bounded searches

## Status

This directory does **not** contain a validated Turing machine with 214 or fewer working states. It records a new source/runtime interface opportunity, a precise one-state elimination target, and reproducible negative searches. None of the finite negative results is a lower bound on the number of states needed for ZFC consistency.

The main reference is the accepted K215 at repository commit `c8029f50d324910a36694c39a1e62f5720c36f4c`:

- Native table SHA-256: `9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2`.
- Ordered source SHA-256: `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba`.
- 215 working states, 430 rows, 4,751 source leaves, 6,176 guarded runtime cases.
- Native start state 0, dispatcher 84, halt 254. Native labels are not dense.

The main archive includes this reference under `baseline/candidate-k215`. All claims below are ordinary mathematical or executable finite checks; no exact-table Lean/PA proof endpoint is asserted.

## 1. A precise one-state target: remove native 302

The relevant rows are

| State/read | Write | Move | Target |
|---|---:|:---:|---:|
| 302/0 | 0 | L | 4 |
| 302/1 | 0 | L | 302 |
| 40/0 | 0 | L | 4 |
| 40/1 | 1 | L | 54 |
| 4/0 | 1 | R | 6 |
| 4/1 | 0 | L | 4 |

State 302 erases a run of trailing program-counter ones, consumes the preceding zero, and passes the remaining prefix to the binary increment routine at state 4. Its zero row is identical to state 40's zero row. If all operational entrances to 302 read zero, every target 302 can be redirected to 40 and the two rows for 302 removed.

This is a sufficient local condition, not yet a construction. All incoming edges must be redirected, including decoder literal entries for `CB1`; the sole incoming edge is **not** 113/0.

The saved complete K215 runtime receipt reports 302/1 in exactly 15 of 6,176 guarded cases:

| Kind | Source ordinals |
|---|---|
| Zero branch of CD6, PC ending 1 | 4564, 4582, 4665, 4730 |
| CB1, PC ending 11 | 4563, 4569, 4581, 4587, 4590, 4664, 4670, 4697, 4724, 4729, 4735 |

The other 6,161 cases avoid that row. The predicate above agrees exactly with the saved row-use receipt; `audit_302_target.py` recomputes this statement and records hashes. No CC case in this reference receipt uses 302/1. The statement concerns this exact table and source, not arbitrary modified decoders.

The unchanged-source fold fails its first tested CB exception, ordinal 4563. It also fails the independent blank initialization test: the original startup executes 302/1 fourteen times, and the folded probe does not reach the required frame within one million steps. These failures are retained only as compact diagnostic data; the invalid 214-state probe is deliberately omitted from the archive.

A successful source rewrite must resolve the fifteen runtime exceptions **and** produce a correct decoder allocation **and** reestablish blank initialization. Runtime equivalence alone does not establish the startup obligation.

## 2. Additional literal control entries

The standard compiler's observed source did not use CB1 on a left leaf. That does not prevent such an entry from being valid. The following literal actions are available:

| Primitive | Required PC suffix | Native literal entry |
|---|---|---|
| CB1 | 0 | 0 L 4 |
| CB1 | 1, with a preceding zero | 0 L 302 |
| CB2 | 0, with another preceding zero | 0 L 302 |
| CB1 | 01 | 0 L 40 |
| CB2 | 00 | 0 L 40 |

A literal entry is the action used when decoding the final bit of a leaf address. The final-bit write clears that bit. For CB1 ending 0, the entry removes the last zero and sends the remaining prefix to the increment routine, exactly `inc(strip_1_zero(pc))`. For CB2 ending 00, the first step removes the final zero, 40/0 removes the preceding zero, and state 4 increments the remaining prefix. The analogous CB1 suffix01 case consumes its final one and then the preceding zero. These derivations require no inspection or alteration of logical register values.

`prove_cb_entries.py` supplies a quantified-register check of the five schemas over every applicable PC word of length at most six: **239 cases, all passed**. Each individual case quantifies arbitrary natural registers, arbitrary natural gap, and an arbitrary nonempty finite spare list, using the inherited inductive list-scan checker. Only the program-counter words are finitely enumerated. The enumeration by itself is not an all-PC theorem; the elementary prefix argument above explains the general schema, and any final proposed machine must still pass its full source-specific runtime check.

## 3. A free physical NOP with unreachable junk

Let a source tree node at prefix `p` have exactly these two leaves:

- `p0`: CB1;
- `p1`: CH, used as a marker for unreachable junk.

Entered from the left, CB1 removes the final zero and increments `p`. That jumps after the entire two-leaf node. It changes no logical register, so the node is a source NOP. The right leaf is never visited by this local execution.

The whole node may be assigned to existing physical state **40**, without a new working state:

- Its zero row is the CB1-on-left entry `0 L 4`.
- Its one row remains the engine's `1 L 54`; it need not implement CH because the marked right leaf must be proven globally unreachable.

This changes the compiler contract in a useful way. A total decoder for all syntactic leaves would reject that assignment. A decoder whose primitive contract is required only on source-reachable leaves can accept it after a separate reachability proof. It is directly suited to the user's permission to tolerate non-decodable junk, while retaining a precise halting-equivalence argument.

### Reachability and stuttering checker

`reachable_source_check.py` implements the required source proof rather than trusting a padding annotation. It checks:

1. Both source files are complete, prefix-free binary trees in lexical leaf order.
2. Two source successor implementations agree: arithmetic PC stripping/increment and an interval-based tree resolver.
3. Every marked NOP is exactly the sibling pair CB1/CH described above, and the CB1 successor skips the whole pair.
4. After removing marked NOP and junk leaves, active instruction order and register effects match the reference. CB/CC retags are allowed only when their actual successor targets correspond.
5. Each guarded edge corresponds after a finite chain of NOPs, and root entries correspond. NOP cycles and edges entering junk are rejected.
6. An independent graph traversal from the root confirms that no marked junk is reachable, considering both CD guards.

This is an exact guarded stuttering equivalence for all register valuations: matched active steps have the same register effect; inserted steps preserve registers and terminate; matching halts remain halts.

With `--table`, the same tool additionally rederives the four inherited list-scan block schemas and checks every graph-reachable primitive/guard against the proposed table with arbitrary natural registers, gap, and nonempty finite spare suffix. It requires every affine duration coefficient to be nonnegative and its constant to be strictly positive. It also runs blank startup and reports the resulting complete frame.

**Startup status is deliberately separate from source calibration.** The inherited startup detector accepts some dirty root frames. The wrapper reports `REACHABLE_RUNTIME_PASS_STARTUP_FRAME_FOUND`, records whether the exact accepted register vector `[4,0,0,0,0,0,0,0,0]` was obtained, and keeps `source_seed_calibration_separate=true`. Finding a frame alone is not a proof that it starts the intended consistency search.

Controls supplied in `receipts/` include a two-leaf program padded to four leaves, a corrupt padding instruction rejected by the checker, and the full baseline identity. The identity run checked all **6,176 cases / 1,698,790 symbolic rules**, minimum duration constant **6**, and found the exact accepted clean seed after **95,714** blank-tape steps. This is a control for the checker, not evidence for a smaller machine.

The collaborating source search enumerated 10,300 closed-association NOP placements, 5,150 each for the baseline and the all-CD-left comparator source. Its minimum was 204 distinct source subtrees. Forty concrete minima were passed to the partial decoder allocator; all returned `NO_ALLOCATION` in that allocator's restricted model. This is a negative result for that finite family, not a rejection of the NOP principle. No successful 214-state allocation of this NOP/junk idea had been obtained at the time of this report.

## 4. The spare-list specialization and why the obvious deletions fail

The accepted blank seed has forty spare blocks, all encoding one. A logical increment appends another one, while other source primitives preserve the spare values. This suggests replacing the universal spare-list contract with an invariant specialized to the actual run, or relaxing the output contract so spare values may change while the frame stays well formed.

The important caution is that states 66 and 198 are not just spare allocators. The accepted runtime uses 66/1 in every positive CD case and 198/1 in every zero CD case. Removing the apparent end-of-list suffix consequently changes decrement semantics as well.

The focused finite search therefore checks complete logical outputs, not merely a local tape pattern. It accepts arbitrary nonempty well-formed spare suffixes at output while requiring exact source PC, head, gap, all nine primary registers, and complete zero exterior. The primary corpus has 30,855 source-mask-compatible frames: five sample modes for every permitted guard, gaps one or three, and forty unit spares. It is a discovery corpus, not an unbounded correctness proof.

| Search family | Tested scope | Result |
|---|---:|---|
| Delete 198 by replacing 66/0, or delete 66 by replacing 94/0 | 1,720 action specifications | No complete-frame survivors |
| Replace only 198/0, keep all states | 864 actions | Seven finite survivors, none a state saving |
| Find 198 quotients on non-CI contexts, then validate complete primitive frames | 6,043 proposed quotients | No complete-frame survivors |

Three of the seven state-preserving actions append a zero-valued spare; four reproduce equivalent original spare behavior. This confirms that spare values have real freedom, but it did not yield a smaller valid machine. The short append-zero startup probe also fails, so those finite survivors are not presented as constructions.

The parent investigation includes a stronger symbolic spare-relaxed runtime checker. The finite programs here are intended to discover proposals for that checker, not replace it.

## 5. Bounded physical search census

A local-window search asks whether original and proposed executions reach an identical state/head/window endpoint within a fixed number of transitions, before leaving the window. A failed join does not prove the two full machines are inequivalent: an equivalent implementation can leave the window, require a longer join, or rely on a stronger reachability invariant.

The principal C++ quotient search uses radius seven (15 tape cells) and at most 97 original/proposed local steps. Its sample contexts are recorded only while the reference completes a full primitive correctly. In particular, returning to dispatcher 84 is **not** treated as a primitive boundary unless the exact required output frame has also been reached; 84 can occur inside a primitive.

| Search | Finite count | Result |
|---|---:|---|
| Primary K215 unit-spare corpus | 30,855 frames, 18,523,882 primitive transitions, 95,631 windows | Reference outputs all correct |
| Two-state quotient on that corpus | 23,005 unordered state pairs, 39,568,600 replacement-row specifications | Zero local fold survivors |
| Same quotient with relational or modular source sampling | Same pair/action family on stronger sample corpora | Zero local fold survivors |
| Four other incoming 215-state allocations | 30,855 frames and 39,568,600 row specifications each | Zero local fold survivors |
| Compose all incoming-row-avoiding alternatives for ten possible deleted states | 1,959,594 combinations | Zero bounded common-endpoint survivors |
| Each of 494 independent row variants, followed by one marker-sensitive fold | Radius12 known-bit invariant, fuel25 | Zero survivors |

The composition count includes 1,959,552 combinations for state 2 and only 42 for the other nine states. It does not represent two million independent broad architectural ideas.

The primary, relational, and modular corpora already exclude the bucket-proved dead sites and impossible positive guards. They do not impose the later exact affine equations. An equivalence restricted to that stronger affine invariant therefore remains outside these quotient screens.

The 494 single-row variants were obtained from an inductive all-tape window domain and positive local common endpoints, rather than from only the sampled source frames. Their individual equivalence does not automatically compose: one change can disrupt the intermediate path needed by another. The composition sweep therefore checks the combined changes, and finds no deletion within its local scope.

Additional negative experiments included single-entry bypasses, existing-selector reuse, a shared new selector, triple-state folds, shifts of the mapped head by up to two cells, and all-tape marker folds on neutral source reallocations. These remain restricted search families. The focused code and receipts in this archive preserve the searches most relevant to the current state302 and spare-list directions rather than every exploratory temporary file.

### Fresh upstream commands120 alternative

A later upstream commit, `8b41dd14f29d07edb09b9bb5ebf06ec58c9f884e`, added a distinct DROP/NIP/MP command-order alternative:

- Native SHA-256 `da83e8de52f4d9536cee2d5ed4af4311308bda51196d18891b96e4bc9ca6cb4f`.
- Source SHA-256 `d5c994e3d0c8fe26dd337aca48e5f25ff4f28fd18973f2c04c99589d6ba3f53d`.

A fresh source-specific bucket seed was computed and checked inductive. This was not a transplantation of the primary source's masks. Its 30,855 frames passed, totaling 18,524,267 primitive transitions and 95,774 windows. The quotient search again tested 23,005 pairs / 39,568,600 row specifications with no fold; the marker search tried 107,856 actions with no fold. Its fifteen syntactically exceptional state302 guards were checked symbolically and all still used 302/1. The command-order change does not by itself resolve the suffix obstruction.

### Increment-DROP source with 203 subtrees

The later increment-DROP proposal has an independently proved command-calculus compiler, but its 203-subtree retagged source still has four CD6 leaves ending in 1 and eleven CB1 leaves ending in 11. Thus it does not directly remove state 302. The exact source hash is `2ed1a87bd3cd1b37c0be144bd1e5c69b5fc186f160b86dbf6a6d4bfd1897aa63`.

A narrow additional screen examined the two newly allocated logical parents ending in CB/CC leaves: CB1 at PCs `11011` and `11010011`. It tried every additional entry action appearing on protected engine read1 rows, excluding already known literal entries. The continuation was required to stay in protected engine rows and reach the exact primitive output frame at its first dispatcher return. Across 110 actions, none passed both concrete controls (all registers zero with gap 1, and all registers two with gap 3; four unit spare blocks; 5,000-step bound). The canonical `0 L 302` entry passes both controls at both sites. These are finite counterexample/discovery checks, not an impossibility result for other entry schemes or coordinated decoder changes.

The portable `increment_drop_entries.py` and compact suffix/entry receipts preserve this last targeted experiment. From this directory:

```sh
python increment_drop_entries.py --candidate ../../baseline/candidate-k215 --source ../source/increment-drop/retagged203.json --engine ../source/engine-rows215.json --output increment-drop-entry-new.json
```

## 6. Reproduction

Run these commands from this directory after unpacking. Python 3 standard library and a C++17 compiler suffice for the physical searches. The quantified entry/runtime checks additionally import the accepted Python checker from the included baseline.

```sh
python audit_302_target.py ../../baseline/candidate-k215 --output audit302-new.json
python prove_cb_entries.py ../../baseline/candidate-k215 --output cb-entry-new.json --max-width 6
python reachable_source_check.py --old controls/nop-control-old.json --new controls/nop-control-new.json --padding controls/nop-control-padding.json --output nop-new.json
```

The corrupt control should fail with `padding left leaf is not CB1`:

```sh
python reachable_source_check.py --old controls/nop-control-old.json --new controls/nop-control-bad.json --padding controls/nop-control-padding.json --output rejected.json
```

For an actual padded proposal, replace the file arguments and provide the marker prefix list. Use the proven unpadded rewrite as `--old` if a separate source transformation has already changed the original program.

```sh
python reachable_source_check.py --old reference.json --new proposed.json --padding padding-prefixes.json --table proposed.native.tm --candidate ../../baseline/candidate-k215 --output proposed-review.json
```

To regenerate the primary finite-search seed and window corpus:

```sh
python make_context_seed.py --table ../../baseline/candidate-k215/k215.native.tm --sites ../../baseline/candidate-k215/sites215.json --output seed-new.txt
c++ -O3 -std=c++17 generate_contexts.cpp -o /tmp/zfc214-generate-contexts
c++ -O3 -std=c++17 quotient_search.cpp -o /tmp/zfc214-quotient-search
/tmp/zfc214-generate-contexts seed-new.txt contexts-new.txt
/tmp/zfc214-quotient-search contexts-new.txt
```

`make_context_seed.py` uses exact values 0 through 7 and a final bucket for values at least 8. It checks the root seed and all transfer inclusions after computing the abstract fixed point. The regenerated primary seed has exactly the same whitespace-separated tokens as the archived seed. The C++ programs use dense internal target indices; their outputs report native labels. Keep the seed/table/source combination together.

To reproduce the spare searches (the output directory is for any newly discovered, unvalidated probes):

```sh
mkdir -p probes
c++ -O3 -std=c++17 spare_relaxed_search.cpp -o /tmp/zfc214-spare-relaxed
c++ -O3 -std=c++17 spare_mutation_search.cpp -o /tmp/zfc214-spare-mutation
/tmp/zfc214-spare-relaxed seed-new.txt probes 5
/tmp/zfc214-spare-mutation seed-new.txt probes 5
c++ -O3 -std=c++17 generate_nonci_contexts.cpp -o /tmp/zfc214-generate-nonci
c++ -O3 -std=c++17 quotient_nonci_198_search.cpp -o /tmp/zfc214-nonci198
c++ -O3 -std=c++17 spare_fold_check.cpp -o /tmp/zfc214-spare-fold-check
/tmp/zfc214-generate-nonci seed-new.txt nonci-new.txt
/tmp/zfc214-nonci198 nonci-new.txt > nonci-hits-new.txt
/tmp/zfc214-spare-fold-check seed-new.txt probes 5 nonci-hits-new.txt
```

To reproduce the marker search and row-variant composition lane:

```sh
python marker_fold_search.py --table ../../baseline/candidate-k215/k215.native.tm --output marker-new.json
python neutral_rows_portable.py --table ../../baseline/candidate-k215/k215.native.tm --variants data/row-variants.json --output neutral-new.json
c++ -O3 -std=c++17 composition_search.cpp -o /tmp/zfc214-composition-search
/tmp/zfc214-composition-search data/modular_contexts.txt data/row-composition-input.txt
```

`search_row_variants.py` and `check_joint_fold.py` are included to regenerate the 494 alternatives rather than treating the saved action list as trusted. This is a substantially broader all-tape window calculation:

```sh
python search_row_variants.py --baseline ../../baseline/candidate-k215/k215.native.tm --output regenerated-rows
```

The saved receipts are evidence of precisely the checks described above. The remaining research goal is still a concrete ≤214-state table with correct blank initialization, source calibration, and a complete halting-equivalence proof.
