#!/usr/bin/env python3
"""Exact guarded-CFG quotient for zero-cost NOP/junk padding.

A padding node at p has CB1 at p0 and a deliberately unreachable CH code at p1.
Only after graph reachability and a guarded stuttering-bisimulation audit may
that junk leaf be omitted from the optional quantified binary runtime check.
This is executable ordinary mathematics, not proof-assistant verification.
"""
from pathlib import Path
from collections import deque
import argparse,hashlib,json,sys,time

def need(condition,message):
    if not condition:raise ValueError(message)

def read_source(path):
    rows=json.loads(path.read_text());seen={};prefixes=set();bounds={}
    for i,row in enumerate(rows):
        need(isinstance(row,list)and len(row)==3,'source row shape')
        pc,op,arg=row;need(isinstance(pc,str)and pc and set(pc)<={'0','1'},'source PC')
        need(pc not in seen,'duplicate source PC');seen[pc]=i
        need(op in('CI','CD','CB','CC','CH'),'unknown source opcode')
        need(arg is None if op=='CH' else type(arg)is int and(0<=arg<9 if op in('CI','CD')else arg>=1),'bad source argument')
        for k in range(len(pc)+1):
            p=pc[:k]
            if k<len(pc):prefixes.add(p)
            if p not in bounds:bounds[p]=[i,i+1]
            else:bounds[p][1]=i+1
    need([x[0]for x in rows]==sorted(seen),'source must be in lexical leaf order')
    need(not set(seen)&prefixes,'source is not prefix-free')
    need(all(p+b in seen or p+b in prefixes for p in prefixes for b in'01'),'source tree is not complete')
    need(len(prefixes)==len(rows)-1,'source tree node count')
    return rows,seen,prefixes,bounds

def inc(word):
    if not word:return ''
    return format((int(word,2)+1)%(1<<len(word)),'0'+str(len(word))+'b')

def strip(word,bit,count):
    for i in range(len(word)-1,-1,-1):
        if word[i]==bit:
            count-=1
            if count==0:return word[:i]
    return ''

def graph_arithmetic(source):
    rows,seen,prefixes,bounds=source
    def resolve(word):
        p='';i=0
        while p not in seen:
            p+=word[i]if i<len(word)else'0';i+=1
            need(p in prefixes or p in seen,'unresolved source address')
        return seen[p]
    out=[]
    for pc,op,arg in rows:
        if op=='CH':edges=[]
        elif op=='CD':edges=[resolve(inc(strip(pc,'0',1))),resolve(inc(pc))]
        elif op=='CI':edges=[resolve(inc(pc))]
        elif op=='CB':edges=[resolve(inc(strip(pc,'0',arg)))]
        else:edges=[resolve(strip(pc,'1',arg))]
        out.append(edges)
    return out

def graph_intervals(source):
    rows,seen,prefixes,bounds=source;n=len(rows);out=[]
    def ancestor(pc,bit,count):
        positions=[i for i,b in enumerate(pc)if b==bit]
        return pc[:positions[-count]]if len(positions)>=count else''
    def after(prefix):return bounds[prefix][1]%n
    for i,(pc,op,arg)in enumerate(rows):
        if op=='CH':edges=[]
        elif op=='CD':edges=[after(ancestor(pc,'0',1)),(i+1)%n]
        elif op=='CI':edges=[(i+1)%n]
        elif op=='CB':edges=[after(ancestor(pc,'0',arg))]
        else:edges=[bounds[ancestor(pc,'1',arg)][0]]
        out.append(edges)
    return out

def effect(row):
    pc,op,arg=row
    return(op,arg)if op in('CI','CD')else('halt',None)if op=='CH'else('control',None)

def source_audit(old,new,padding):
    O=read_source(old);N=read_source(new);og=graph_arithmetic(O);ng=graph_arithmetic(N)
    need(og==graph_intervals(O),'old independent CFG resolvers disagree')
    need(ng==graph_intervals(N),'new independent CFG resolvers disagree')
    pops=set();junk=set();records=[]
    for p in padding:
        need(p+'0'in N[1]and p+'1'in N[1],'padding is not a two-leaf node: '+p)
        left,right=N[1][p+'0'],N[1][p+'1']
        need(N[0][left][1:]==['CB',1],'padding left leaf is not CB1')
        need(N[0][right][1:]==['CH',None],'padding junk marker is not CH')
        need(left not in pops|junk and right not in pops|junk,'overlapping padding')
        need(ng[left]==[N[3][p][1]%len(N[0])],'padding CB1 fails to skip its whole node')
        pops.add(left);junk.add(right);records.append({'prefix':p,'nop_ordinal':left,'junk_ordinal':right})
    active=[i for i in range(len(N[0]))if i not in pops|junk]
    need(len(active)==len(O[0]),'active instruction counts differ')
    need([effect(r)for r in O[0]]==[effect(N[0][i])for i in active],'active primitive effects/order differ')
    mapping=dict(enumerate(active));inverse={v:k for k,v in mapping.items()};longest=0
    def collapse(i):
        nonlocal longest
        seen=set()
        while i in pops:
            need(i not in seen,'padding chain loops');seen.add(i);i=ng[i][0]
        need(i not in junk,'source edge enters junk leaf')
        longest=max(longest,len(seen));return i
    need(collapse(0)==mapping[0],'root entries do not correspond')
    checked=0
    for oldi,newi in mapping.items():
        need(len(og[oldi])==len(ng[newi]),'guard arity differs')
        for expected,actual in zip(og[oldi],ng[newi]):
            need(collapse(actual)==mapping[expected],f'guarded edge differs at old/new ordinal{oldi}/{newi}')
            checked+=1
    reachable={0};todo=deque([0])
    while todo:
        i=todo.popleft()
        for j in ng[i]:
            if j not in reachable:reachable.add(j);todo.append(j)
    need(not reachable&junk,'junk is graph-reachable from root')
    report={'status':'EXACT_GUARDED_STUTTERING_CFG_PASS','old_leaves':len(O[0]),'new_leaves':len(N[0]),'old_guarded_edges':sum(map(len,og)),'checked_guarded_edges':checked,'padding_nodes':records,'junk_ordinals':sorted(junk),'reachable_ordinals':sorted(reachable),'maximum_padding_chain':longest,'register_effects_unchanged':True,'independent_cfg_resolvers_agree':True,'junk_graph_unreachable':True,'proof_scope':'All register valuations and both decrement guards; every matched instruction has the same register effect and matched successor after a finite chain of register-preserving NOPs. Root and halting instructions correspond. The excluded junk has no reachable guarded-CFG path from the root.'}
    return report,N[0],reachable

def runtime_audit(tablepath,sites,reachable,candidate,startup_limit):
    sys.path.insert(0,str(candidate/'code/runtime-inputs'));import validate_native as v
    T=v.s.r.table(tablepath);Q={q for q,b in T};need(len(T)==2*len(Q),'partial native table')
    need(all((q,b)in T for q in Q for b in(0,1)),'missing native row')
    need({z for w,d,z in T.values()}-Q=={254},'undefined native target')
    M={int(k):int(val)for k,val in json.loads((candidate/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
    for q in Q|{254}:M.setdefault(q,q+1000)
    need(len({M[q]for q in Q|{254}})==len(Q)+1,'legacy state-map collision')
    L={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in T.items()}
    startup=v.startup(T,startup_limit);small={k:val for k,val in startup.items()if k not in('trace','one_cells')}
    lemmas,blocks=v.s.prove_blocks(L);cases=[];used=set();begun=time.monotonic()
    for i in sorted(reachable):
        site=sites[i]
        for positive in((False,True)if site[1]=='CD'else(False,)):
            answer=v.s.case(L,lemmas,site,positive)
            used.update(answer.pop('rows'));answer.pop('trace');cases.append({'site_index':i,'positive':positive,**answer})
        if len(cases)%1000==0:print('SYMBOLIC_CASES',len(cases),flush=True)
    need(all(case['duration'] and case['duration'][0]>0 and all(c>=0 for c in case['duration']) for case in cases),'nonpositive or negative-coefficient primitive duration')
    minimum=min(case['duration'][0]for case in cases)
    frame_found=small['status']=='CALIBRATED_DIRTY_ROOT_SEED'
    clean_seed=frame_found and small.get('registers')==[4,0,0,0,0,0,0,0,0]
    return{'status':'REACHABLE_RUNTIME_PASS_STARTUP_FRAME_FOUND'if frame_found else'REACHABLE_RUNTIME_PASS_STARTUP_FRAME_NOT_FOUND','source_seed_calibration_separate':True,'clean_accepted_seed_found':clean_seed,'all_duration_coefficients_nonnegative':True,'all_duration_constants_positive':True,'working_states':len(Q),'table_sha256':sha(tablepath),'startup':small,'guarded_cases':len(cases),'symbolic_steps':sum(case['symbolic_steps']for case in cases),'minimum_duration_constant':minimum,'blocks':blocks,'directly_used_rows':sorted(used),'seconds':time.monotonic()-begun,'scope':'All natural register values at every reachable source guard, arbitrary natural gap, arbitrary nonempty finite spare list, whole zero exterior. Junk is omitted only after the exact source-graph proof. Ordinary mathematical checker, not proof-assistant kernel checked.','checker_sha256':sha(Path(v.__file__)),'symbolic_checker_sha256':sha(Path(v.s.__file__)),'helper_sha256':sha(Path(v.s.r.__file__))},cases

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--old',type=Path,required=True);ap.add_argument('--new',type=Path,required=True);ap.add_argument('--padding',type=Path,required=True,help='JSON list of NOP-node binary prefixes');ap.add_argument('--output',type=Path,required=True);ap.add_argument('--table',type=Path);ap.add_argument('--candidate',type=Path,help='accepted candidate-k215 directory containing the inherited runtime checker');ap.add_argument('--startup-limit',type=int,default=10000000);a=ap.parse_args()
    padding=json.loads(a.padding.read_text());need(isinstance(padding,list)and all(isinstance(p,str)and set(p)<={'0','1'}for p in padding),'padding list shape');need(len(set(padding))==len(padding),'duplicate padding prefix')
    report,sites,reachable=source_audit(a.old,a.new,padding)
    report['input_sha256']={str(p):sha(p)for p in[a.old,a.new,a.padding]};report['checker_sha256']=sha(Path(__file__))
    if a.table:
        need(a.candidate is not None,'--candidate is required with --table')
        runtime,cases=runtime_audit(a.table,sites,reachable,a.candidate,a.startup_limit);report['runtime']=runtime;a.output.with_suffix('.runtime-cases.json').write_text(json.dumps(cases,indent=2)+'\n')
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in('reachable_ordinals','input_sha256','runtime')},indent=2))
    if'runtime'in report:print(json.dumps({k:v for k,v in report['runtime'].items()if k not in('blocks','directly_used_rows')},indent=2))
if __name__=='__main__':main()
