#!/usr/bin/env python3
"""Read-only audit of the K215 state302 suffix target.

Usage: python audit_302_target.py PATH/TO/candidate-k215 --output audit302.json
This does not certify a smaller machine. It audits the released quantified-case
row receipt and identifies a precise sufficient condition for a future fold.
"""
from pathlib import Path
import argparse,collections,gzip,hashlib,json

def read_table(path):
    table={}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();key=int(q),int(b)
        assert key not in table
        table[key]=int(w),d,int(z)
    return table

def main():
    ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();base=args.candidate
    tablepath=base/'k215.native.tm';sitepath=base/'sites215.json';receiptpath=base/'verification/root-run1/runtime/runtime_cases.json.gz';mappath=base/'code/runtime-inputs/inputs/legacy_mapping.json'
    T=read_table(tablepath);sites=json.loads(sitepath.read_text());M={int(k):int(v) for k,v in json.loads(mappath.read_text()).items()};cases=json.load(gzip.open(receiptpath,'rt'))
    assert len(T)==430 and len(sites)==4751 and len(cases)==6176
    assert T[302,0]==T[40,0]==(0,'L',4)
    assert T[302,1]==(0,'L',302)
    legacy302=M.get(302,1302)
    observed=[(case['site_index'],case['positive']) for case in cases if [legacy302,1] in case['rows']]
    predicted=[(i,False) for i,(pc,op,arg) in enumerate(sites) if (op=='CD' and pc.endswith('1')) or (op=='CB' and arg==1 and pc.endswith('11'))]
    assert observed==predicted
    assert all(arg==1 for pc,op,arg in sites if op=='CB')
    affected=[{'site_index':i,'positive':positive,'site':sites[i]} for i,positive in observed]
    incoming=[{'row':[q,b],'action':list(a)} for(q,b),a in sorted(T.items()) if a[2]==302]
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    report={'status':'AUDITED_SUFFIX_TARGET_ONLY','old_states':215,'candidate_states_if_fold_valid':214,'guarded_cases':len(cases),'affected_guarded_cases':len(affected),'unaffected_guarded_cases':len(cases)-len(affected),'affected':affected,'incoming_to_302':incoming,'row_identity':{'state302_read0':list(T[302,0]),'state40_read0':list(T[40,0])},'suffix_condition':{'CD':'PC ends in0, or the zero branch has a separately proved impossibility invariant','CB1':'PC ends in01 using entry0L302, or ends in0 using the additional canonical entry0L4','CC':'No additional condition identified in this exact baseline receipt'},'fold_recipe':'Redirect every target302 to40; remove rows302/0 and302/1; independently validate the changed source allocation and blank startup.','limitations':['This reads the released ordinary mathematical runtime receipt; it does not rerun its inductive checker.','Source equivalence, decoder allocation, and startup remain separate obligations.','The unchanged-source214 probe fails at source ordinal4563 and does not calibrate from blank within1000000steps. It is not a candidate construction.','Finite negative searches do not prove that no214-state machine exists.'],'input_sha256':{path.name:sha(path) for path in [tablepath,sitepath,receiptpath,mappath]},'checker_sha256':sha(Path(__file__))}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in('affected','incoming_to_302','input_sha256')},indent=2))
if __name__=='__main__':main()
