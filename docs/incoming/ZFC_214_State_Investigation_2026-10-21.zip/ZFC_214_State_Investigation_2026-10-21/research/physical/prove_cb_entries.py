#!/usr/bin/env python3
"""Quantified-register tests of additional literal CB entry actions.
Only program-counter words are finitely enumerated; the inherited symbolic
checker universally quantifies natural registers, gap and finite spare list.
This is ordinary mathematical checking, not proof-assistant verification.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,itertools,json,sys,time

def main():
    ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--max-width',type=int,default=6);a=ap.parse_args();b=a.candidate
    runtime=b/'code/runtime-inputs/runtime';sys.path.insert(0,str(runtime));import symbolic_runtime as s
    native=s.r.table(b/'k215.native.tm');M={int(k):int(v) for k,v in json.loads((b/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
    def legacy(q):return M.get(q,q+1000)
    checks=[];failures=[];started=time.monotonic()
    schemas=[(1,'0',(0,-1,4)),(1,'1',(0,-1,302)),(2,'0',(0,-1,302)),(1,'01',(0,-1,40)),(2,'00',(0,-1,40))]
    for count,last,entry in schemas:
        for width in range(len(last),a.max_width+1):
            for prefix in itertools.product('01',repeat=width-len(last)):
                pc=''.join(prefix)+last
                if pc.count('0')<count:continue
                T=native.copy();states=[84]+[10000+i for i in range(1,width)]
                for i,(q,bit) in enumerate(zip(states,pc)):
                    T[q,1-int(bit)]=(1-int(bit),1,254)
                    T[q,int(bit)]=entry if i==width-1 else(int(bit),1,states[i+1])
                L={(legacy(q),bit):(w,d,legacy(z))for(q,bit),(w,d,z)in T.items()}
                try:
                    lemmas,_=s.prove_blocks(L);answer=s.case(L,lemmas,[pc,'CB',count],False)
                    checks.append({'count':count,'pc':pc,'entry':entry,'symbolic_steps':answer['symbolic_steps'],'duration':answer['duration']})
                except Exception as e:failures.append({'count':count,'pc':pc,'entry':entry,'reason':str(e)})
    result={'status':'QUANTIFIED_REGISTERS_FINITE_PC_PASS'if not failures else'NOT_PROVED','program_counter_max_width':a.max_width,'cases':len(checks),'failures':failures,'schemas':[{'count':n,'required_suffix':bit,'native_entry':list(entry)} for n,bit,entry in schemas],'scope':'Every binary PC of the enumerated widths ending in the listed suffix and containing at least count zero bits; each case quantifies all independent natural registers, gap, first spare value and finite remaining spare list using the inherited ordinary mathematical checker.','limitations':'The finite PC enumeration is not a proof for all PC words. A final candidate still needs its complete source-specific quantified runtime check, decoder audit, source calibration and blank initialization.','seconds':time.monotonic()-started,'table_sha256':hashlib.sha256((b/'k215.native.tm').read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    a.output.write_text(json.dumps(result,indent=2)+'\n');a.output.with_suffix('.cases.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
