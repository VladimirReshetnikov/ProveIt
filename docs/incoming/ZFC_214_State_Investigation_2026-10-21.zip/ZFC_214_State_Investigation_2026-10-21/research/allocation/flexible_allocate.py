#!/usr/bin/env python3
"""Conditional freezing of contextual decoder helpers and global role allocation.
Synthesis only: any output still needs the independent quantified runtime proof.
"""
from pathlib import Path
from collections import defaultdict, Counter
import argparse, json, sys
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix
B=(Path(__file__).resolve().parents[2]/'baseline/candidate-k215')
sys.path.insert(0,str(B/'code'));import source_language as s;import build221 as b
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--limit',type=int,default=180);ap.add_argument('--maximum',type=int,default=214);ap.add_argument('--moves',type=int,default=999);a=ap.parse_args();a.out.mkdir(exist_ok=False)
T=b.read_table((B/'k215.native.tm').read_bytes());oldroot=s.tree(json.loads((B/'sites215.json').read_text()));root=s.tree(json.loads((a.source or B/'sites215.json').read_text()));states=sorted({q for q,bit in T});groups,oldpaths=b.decoder_map(T,oldroot)
P={tuple(x)for x in json.loads((Path(__file__).resolve().parents[1]/'source/engine-rows215.json').read_text())['rows']};P|={(81,0),(111,0),(111,1),(104,0),(128,0),(108,0),(108,1)}
occ=defaultdict(list)
def walk(n,p=''):
 if s.leaf(n):return
 occ[n].append(p)
 for bit,ch in enumerate(n):walk(ch,p+str(bit))
walk(root);nodes=list(occ);by=defaultdict(set)
for q,ns in groups.items():
 for n in ns:by[n].add(q)
leafacts=defaultdict(Counter)
for q,ns in groups.items():
 for n in ns:
  for bit,ch in enumerate(n):
   if s.leaf(ch):leafacts[ch,bit][T[q,bit]]+=1
D={}
for key,acts in leafacts.items():
 direct=[x for x in acts if x[:2]==(key[1],1)];D[key]=max(direct or acts,key=lambda x:acts[x])
for op,k,q in [('CC',1,1),('CC',2,16),('CB',1,302)]:
 if((op,k),1)in D:D[(op,k),1]=(0,-1,q);leafacts[(op,k),1][D[(op,k),1]]+=1
# A primitive reached by an ordinary right-moving dispatch edge has the same
# entry state for either scanned dispatch bit. New source associations can
# place an existing primitive on the previously unused side.
for (ch, bit), act in list(D.items()):
 if act[:2] == (bit, 1) and (ch, 1-bit) not in D:
  other=(1-bit, 1, act[2]);D[ch,1-bit]=other;leafacts[ch,1-bit][other]+=1
alias=(('CD',6),('CC',2))
def edge(q,p,bit):
 tape={-1:1,**{i:int(v)for i,v in enumerate(p+str(bit))}};old=tape.copy();h=len(p);trace=set()
 for _ in range(100):
  if h==len(p)+1:return(q,trace)if old==tape else(None,trace)
  if h not in tape or(q,tape[h])not in T:return None,trace
  k=(q,tape[h]);trace.add(k);w,d,q=T[k];tape[h]=w;h+=d
 return None,trace
# p mode = rewrite unprotected rows; f mode = retain both rows and freeze helpers.
options={};requirements={};freeze={}
for n in nodes:
 opts=[]
 for q in ([84]if n==root else states):
  for mode in ('p','f'):
   if mode=='p' and all((q,bit)in P for bit in(0,1)):continue
   req=[];fr=set();ok=True
   for bit,ch in enumerate(n):
    if mode=='p' and(q,bit)not in P:continue
    act=T[q,bit]
    if s.leaf(ch):
     if act not in leafacts[ch,bit]:ok=False;break
     if q==108 and bit==1:
      suffix={'CC':'101','CB':'001'}.get(ch[0])
      if suffix and any(not('1'+p+'1').endswith(suffix)for p in occ[n]):ok=False;break
    else:
     zs=set()
     for p in occ[n]:
      z,tr=edge(q,p,bit)
      if z is None:ok=False;break
      fr.update(qq for qq,bb in tr if(qq,bb)not in P)
      if ch==alias and z==108 and('1'+p+str(bit)).endswith('101'):continue
      zs.add(z)
     if not ok or len(zs)>1:ok=False;break
     if zs:req.append((ch,next(iter(zs))))
   if ok:
    if mode=='p' and q in fr:continue
    opts.append((q,mode));requirements[n,q,mode]=req;freeze[n,q,mode]=fr
  
 options[n]=opts
change=True
while change:
 change=False
 possible={n:{q for q,mode in opts}for n,opts in options.items()}
 for n in nodes:
  good=[(q,m)for q,m in options[n]if all(z in possible[ch]for ch,z in requirements[n,q,m])]
  if len(good)!=len(options[n]):options[n]=good;change=True
meta={'internal_nodes':len(nodes),'engine_rows':len(P),'empty_domains':[i for i,n in enumerate(nodes)if not options[n]],'program_options':sum(m=='p'for opts in options.values()for q,m in opts),'frozen_options':sum(m=='f'for opts in options.values()for q,m in opts)}
print('DOMAINS',json.dumps(meta),flush=True)
if meta['empty_domains']:
 (a.out/'result.json').write_text(json.dumps({'status':'EMPTY_DOMAIN',**meta},indent=2));sys.exit()
choices=[(n,q,mode)for n in nodes for q,mode in options[n]];ix={x:i for i,x in enumerate(choices)};uix={q:len(choices)+i for i,q in enumerate(states)};m=len(choices)+len(states)
prog=defaultdict(list);at=defaultdict(list)
for(n,q,mode),i in ix.items():
 at[n,q].append(i)
 if mode=='p':prog[q].append(i)
rr=[];cc=[];vv=[];lo=[];hi=[]
def add(row,l=-np.inf,h=0):
 k=len(lo);lo.append(l);hi.append(h)
 for j,v in row.items():
  if v:rr.append(k);cc.append(j);vv.append(v)
for n in nodes:add({ix[n,q,mode]:1 for q,mode in options[n]},1,1)
for q in states:
 add({i:1 for i in prog[q]},0,1)
 for bit in(0,1):
  z=T[q,bit][2]
  if z==254:continue
  row={uix[q]:1,uix[z]:-1}
  if(q,bit)not in P:
   for i in prog[q]:row[i]=-1
  add(row)
for(n,q,mode),i in ix.items():
 add({i:1,uix[q]:-1})
 for ch,z in requirements[n,q,mode]:
  row={i:1}
  for j in at[ch,z]:row[j]=row.get(j,0)-1
  add(row)
 fs=freeze[n,q,mode]|({q}if mode=='f'else set())
 for z in fs:
  if prog[z]:add({i:1,**{j:1 for j in prog[z]}},h=1)
 if mode=='p':
  for bit,ch in enumerate(n):
   if(q,bit)not in P and s.leaf(ch):
    z=D[ch,bit][2]
    if z!=254:add({i:1,uix[z]:-1})
add({uix[0]:1},1,1);add({uix[q]:1 for q in states},0,a.maximum)
add({i:1 for(n,q,mode),i in ix.items()if q not in by[n]},0,a.moves)
A=coo_matrix((vv,(rr,cc)),shape=(len(lo),m)).tocsc();cost=np.zeros(m)
for q,i in uix.items():cost[i]=1
for(n,q,mode),i in ix.items():cost[i]+=0.000001*(q not in by[n])+0.00000001*(mode=='p')
print('MODEL',m,'constraints',len(lo),'maxstates',a.maximum,flush=True)
ans=milp(cost,integrality=np.ones(m),bounds=Bounds(0,1),constraints=LinearConstraint(A,lo,hi),options={'time_limit':a.limit,'mip_rel_gap':0.0})
result={'status':{0:'SOLVER_FINISHED',1:'TIME_LIMIT',2:'MODEL_INFEASIBLE',3:'UNBOUNDED',4:'SOLVER_OTHER'}.get(int(ans.status),'SOLVER_OTHER'),'solver_status':int(ans.status),'solver':ans.message,'variables':m,'constraints':len(lo),**meta};print('SOLVER',ans.message,flush=True)
if ans.x is not None:
 maps={n:(q,mode)for(n,q,mode),i in ix.items()if ans.x[i]>.5};assert len(maps)==len(nodes)
 V=dict(T)
 for n,(q,mode)in maps.items():
  if mode!='p':continue
  for bit,ch in enumerate(n):
   if(q,bit)not in P:V[q,bit]=D[ch,bit]if s.leaf(ch)else(bit,1,maps[ch][0])
 reach={0};todo=[0]
 for q in todo:
  for bit in(0,1):
   z=V[q,bit][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 V={k:v for k,v in V.items()if k[0]in reach};result.update(status='TABLE',states=len(V)//2,removed=sorted(set(states)-reach),changed=[[*k,*v]for k,v in V.items()if T.get(k)!=v])
 (a.out/'candidate.native.tm').write_bytes(b.table_bytes(V));(a.out/'assignments.json').write_text(json.dumps([{'path':occ[n][0],'state':q,'mode':mode}for n,(q,mode)in maps.items()],indent=2))
 try:
  gg,pp=b.decoder_map(V,root);fails=[]
  for q,ps in pp.items():
   for p in ps:
    n=s.subtree(root,p)
    if q!=maps[n][0] and not(n==alias and q==108 and('1'+p).endswith('101')):fails.append([q,p,maps[n][0]])
  result.update(prefix_failures=fails,status='PREFIX_PASS'if not fails else'PREFIX_FAIL')
 except Exception as e:result.update(status='PREFIX_FAIL',error=repr(e))
print(json.dumps({k:v for k,v in result.items()if k!='changed'}),flush=True);(a.out/'result.json').write_text(json.dumps(result,indent=2))
