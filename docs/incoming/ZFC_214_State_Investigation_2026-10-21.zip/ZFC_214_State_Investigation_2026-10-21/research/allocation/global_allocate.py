#!/usr/bin/env python3
from pathlib import Path
from collections import defaultdict,Counter
import sys,json,argparse,time
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix
B=(Path(__file__).resolve().parents[2]/'baseline/candidate-k215')
sys.path.insert(0,str(B/'code'));import source_language as s;import build221 as b
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--limit',type=int,default=180);ap.add_argument('--maximum',type=int,default=214);ap.add_argument('--source',type=Path);ap.add_argument('--flex',action='store_true');a=ap.parse_args();a.out.mkdir(exist_ok=False)
T=b.read_table((B/'k215.native.tm').read_bytes());oldroot=s.tree(json.loads((B/'sites215.json').read_text()));root=s.tree(json.loads((a.source or B/'sites215.json').read_text()));states=sorted({q for q,bit in T});groups,oldpaths=b.decoder_map(T,oldroot);by=defaultdict(set);occ=defaultdict(list)
for q,ns in groups.items():
 for n in ns:by[n].add(q)
def walk(n,p=''):
 if s.leaf(n):return
 occ[n].append(p)
 for bit,ch in enumerate(n):walk(ch,p+str(bit))
walk(root)
nodes=list(occ);nid={n:i for i,n in enumerate(nodes)}
P={tuple(x)for x in json.loads((Path(__file__).resolve().parents[1]/'source/engine-rows215.json').read_text())['rows']}
P|={(81,0),(111,0),(111,1),(104,0),(128,0)}
# Retain contextual aliases; unique-node roles can all be reallocated.
fixed={};reserved=defaultdict(set)
for q,ns in groups.items():
 if len(ns)>1:
  for n in ns:
   if q==108 and n==(('CD',6),('CC',2)):continue
   if n in occ:fixed[n]=q;reserved[q].add(n)
P|={(q,bit)for q in reserved for bit in(0,1)}
def edge(q,p,bit):
 tape={-1:1,**{i:int(v)for i,v in enumerate(p+str(bit))}};old=tape.copy();h=len(p);trace=[]
 for _ in range(100):
  if h==len(p)+1:return (q,trace)if old==tape else(None,trace)
  if h not in tape or(q,tape[h])not in T:return None,trace
  k=(q,tape[h]);trace.append(k);w,d,q=T[k];tape[h]=w;h+=d
 return None,trace
for n,q in fixed.items():
 for p in occ[n]:
  # node108/CB1 is valid only its retained001 contexts.
  for bit,ch in enumerate(n):
   if not s.leaf(ch):
    z,tr=edge(q,p,bit)
    if z is None:raise ValueError(('fixed edge',q,p,bit))
    P.update(tr)
if a.flex:
 fixed={};reserved=defaultdict(set)
leafacts=defaultdict(Counter)
for q,ns in groups.items():
 for n in ns:
  for bit,ch in enumerate(n):
   if s.leaf(ch):leafacts[ch,bit][T[q,bit]]+=1
D={}
for key,acts in leafacts.items():
 direct=[x for x in acts if x[:2]==(key[1],1)];D[key]=max(direct or acts,key=lambda x:acts[x])
for op,k,q in [('CC',1,1),('CC',2,16),('CB',1,302)]:
 if((op,k),1)in D:D[(op,k),1]=(0,-1,q);leafacts[(op,k),1][D[(op,k),1]]+=1
alias=(('CD',6),('CC',2))
domains={};requires={};skipped={}
for n in nodes:
 opts={fixed[n]}if n in fixed else set(states)-set(reserved)
 if n==root:opts&={84}
 good=set()
 for q in opts:
  ok=True;req=[]
  for bit,ch in enumerate(n):
   if(q,bit)not in P:continue
   act=T[q,bit]
   if s.leaf(ch):
    if act not in leafacts[ch,bit]:ok=False;break
    # Only valid context for compressed leaf108/1.
    if q==108 and bit==1:
     suffix={'CC':'101','CB':'001'}.get(ch[0])
     if suffix and any(not('1'+p+'1').endswith(suffix)for p in occ[n]):ok=False;break
   elif act[:2]==(bit,1):
    z=act[2]
    if not(ch==alias and z==108 and all(('1'+p+str(bit)).endswith('101')for p in occ[n])):req.append((ch,z))
   else:
    zs=set()
    for p in occ[n]:
     z,tr=edge(q,p,bit)
     if z is None or any(k not in P for k in tr):ok=False;break
     if ch==alias and z==108 and ('1'+p+str(bit)).endswith('101'):continue
     zs.add(z)
    if not ok or len(zs)>1:ok=False;break
    if zs:req.append((ch,next(iter(zs))))
  if ok:good.add(q);requires[n,q]=req
 domains[n]=good
changed=True
while changed:
 changed=False
 for n in nodes:
  for q in list(domains[n]):
   if any(z not in domains[ch]for ch,z in requires[n,q]):domains[n].remove(q);changed=True
meta={'source_nodes':len(nodes),'fixed_contextual_nodes':len(fixed),'protected_rows':len(P),'domain_sizes':[len(domains[n])for n in nodes]}
print('DOMAINS',json.dumps({**meta,'empty':[nid[n]for n in nodes if not domains[n]]}),flush=True)
if any(not domains[n]for n in nodes):
 (a.out/'result.json').write_text(json.dumps({'status':'EMPTY_DOMAIN',**meta},indent=2));sys.exit()
choices=[(n,q)for n in nodes for q in sorted(domains[n])];idx={x:i for i,x in enumerate(choices)};uix={q:len(choices)+i for i,q in enumerate(states)};m=len(choices)+len(states);M=[];lo=[];hi=[]
def add(row,l,h):M.append(row);lo.append(l);hi.append(h)
for n in nodes:add({idx[n,q]:1 for q in domains[n]},1,1)
for q in states:
 xs=[idx[n,q]for n in nodes if q in domains[n]]
 if q not in reserved and not(a.flex and all((q,bit)in P for bit in(0,1))):add({i:1 for i in xs},0,1)
 for i in xs:add({i:1,uix[q]:-1},-np.inf,0)
 for bit in(0,1):
  z=T[q,bit][2]
  if z==254:continue
  rr={uix[q]:1,uix[z]:-1}
  if(q,bit)not in P:
   for i in xs:rr[i]=rr.get(i,0)-1
  add(rr,-np.inf,0)
for n,q in choices:
 for ch,z in requires[n,q]:add({idx[n,q]:1,idx[ch,z]:-1},-np.inf,0)
 for bit,ch in enumerate(n):
  if(q,bit)not in P and s.leaf(ch):
   z=D[ch,bit][2]
   if z!=254:add({idx[n,q]:1,uix[z]:-1},-np.inf,0)
add({uix[0]:1},1,1)
add({uix[q]:1 for q in states},0,a.maximum)
A=lil_matrix((len(M),m))
for i,row in enumerate(M):
 for j,v in row.items():A[i,j]=v
cost=np.zeros(m)
for q,i in uix.items():cost[i]=1
for(n,q),i in idx.items():cost[i]+=0.000001*(q not in by[n])
print('MODEL',m,'constraints',len(M),'statesmaximum',a.maximum,flush=True)
ans=milp(cost,integrality=np.ones(m),bounds=Bounds(0,1),constraints=LinearConstraint(A.tocsc(),lo,hi),options={'time_limit':a.limit,'mip_rel_gap':0.0})
result={'status':{0:'SOLVER_FINISHED',1:'TIME_LIMIT',2:'MODEL_INFEASIBLE',3:'UNBOUNDED',4:'SOLVER_OTHER'}.get(int(ans.status),'SOLVER_OTHER'),'solver_status':int(ans.status),'solver':ans.message,'variables':m,'constraints':len(M),**meta}
print('SOLVER',ans.message,flush=True)
if ans.x is not None:
 maps={n:q for(n,q),i in idx.items()if ans.x[i]>.5};assert len(maps)==len(nodes)
 V=dict(T)
 for n,q in maps.items():
  for bit,ch in enumerate(n):
   if(q,bit)in P:continue
   V[q,bit]=D[ch,bit]if s.leaf(ch)else(bit,1,maps[ch])
 reach={0};todo=[0]
 for q in todo:
  for bit in(0,1):
   z=V[q,bit][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 V={k:v for k,v in V.items()if k[0]in reach};result.update(status='TABLE',states=len(V)//2,removed=sorted(set(states)-reach),changed=[[*k,*v]for k,v in V.items()if T.get(k)!=v])
 (a.out/'candidate.native.tm').write_bytes(b.table_bytes(V));(a.out/'assignments.json').write_text(json.dumps([{'path':occ[n][0],'state':maps[n]}for n in nodes],indent=2))
 try:
  gg,pp=b.decoder_map(V,root);fails=[]
  for q,ps in pp.items():
   for p in ps:
    n=s.subtree(root,p)
    if q!=maps[n] and not(n==alias and q==108 and ('1'+p).endswith('101')):fails.append([q,p,maps[n]])
  result.update(prefix_failures=fails,status='PREFIX_PASS'if not fails else'PREFIX_FAIL')
 except Exception as e:result.update(status='PREFIX_FAIL',error=repr(e))
print(json.dumps({k:v for k,v in result.items()if k not in('domain_sizes','changed')}),flush=True)
(a.out/'result.json').write_text(json.dumps(result,indent=2))
