# Attribution and inherited terms

Prepared for Vladimir Reshetnikov's ProveIt project by this ChatGPT research collaboration. The source, physical-encoding, and formalism investigations were developed in parallel and checked together. No external human review, discovery priority, proof-assistant compilation, unconditional nonhalting, or minimum-state theorem is claimed.

The primary input is the accepted ProveIt candidate-k215 at commit c8029f50d324910a36694c39a1e62f5720c36f4c. A later read-only comparison used commit 8b41dd14f29d07edb09b9bb5ebf06ec58c9f884e. The exact source/table bytes used for completed checks are pinned in the machine recipes and manifest.

The rho6 parameter permutation comes from Source 163's K216 packet. The later repository intake also independently transplants that source change to K215. The present packet claims its exact allocation, full fresh quantified validation and independent complete blank-prefix replay, not priority for the sampler idea. All-tag inverse detachment and the semantic rationale for ignoring membership-tag decoding are prior Source 154 results. The included comparator examples retain their Source 140/146 attribution. Projection/residual interfaces, where discussed, retain Source 164 and its antecedents' attribution.

The numerical calculus, register program, source compiler, arithmetic engine, marker folds, command interfaces, and runtime induction checker retain their existing ProveIt and submitted-packet credits. See baseline/candidate-k215/NOTICE.md and its retained provenance and licenses. Those notices identify, within their respective scopes, Mira/ProveIt, Elliot Glazer, Jeff's busy-beaver/Rocq reference, Andrew James Wade, BusyCoq, and the Coq Library of Undecidability.

New repository material follows the project's MIT No Attribution terms, copied as LICENSE. This does not relicense inherited third-party components. Keep their original notices and licenses when incorporating this packet.
