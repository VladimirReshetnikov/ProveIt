# Investigation toward a 214-state ZFC consistency machine

**The requested 214-state bound has not been achieved.** The complete machine released in this packet has **215 working states**, including initialization. No failed 213- or 214-state mutation is presented as a consistency machine.

The packet records an exact, freshly validated alternative at 215 states and research aimed at removing the next state. Its ordinary mathematical argument, together with the inherited ProveIt calculus calibration, establishes the ZFC-provable equivalence

\[
\neg\operatorname{Halt}(M_{215,\rho_6},\mathrm{blank})
\quad\longleftrightarrow\quad
\operatorname{Con}(\mathrm{ZFC}).
\]

This is not an unconditional nonhalting claim or a newly compiled proof-assistant endpoint. The main report explains the calibration, proof boundaries, formalism changes, physical encodings, and rejected reductions.

## Read first

- `report/investigation.pdf`: the complete research report.
- `report/investigation.tex` and the other `.tex` files in that directory: its editable source.
- `STATUS.json`: machine-readable outcome and authoritative artifact hashes.
- `machine215-rho6/`: the fully checked alternative, source, reconstruction recipe, and fresh evidence.
- `MANIFEST.sha256`: hashes of every released file other than the manifest itself.

The baseline is the primary `candidate-k215` at ProveIt commit **c8029f50d324910a36694c39a1e62f5720c36f4c**. A later check at **8b41dd14f29d07edb09b9bb5ebf06ec58c9f884e** found that the primary source and table were unchanged. That update publishes additional 215-state allocations and records an independent transplant of the same rho6 source change with a prefix-valid allocation. The contribution claimed here is the released exact allocation, its complete fresh runtime proof, independent startup replay, and the additional research artifacts. There is no priority claim for the rho6 parameter permutation.

## Exact released machine

| Item | Value |
|---|---:|
| Working states | 215 |
| Tape symbols | 2 |
| Transition rows | 430 |
| Primitive source occurrences | 4,751 |
| Distinct source subtrees | 202 |
| Quantified guarded cases | 6,176 |
| Symbolic rules in the fresh primitive proof | 1,699,838 |
| Minimum constant of a primitive duration polynomial | 6 |
| Blank initialization transitions | 95,726 |

The machine has one two-way infinite tape, initially all zero, a head initially at position zero, and only left/right moves. The halting state has no outgoing rows and is excluded from the working-state count.

`machine215-rho6/k215-rho6.native.tm` uses native start 0, dispatcher 84, and halt 254. `machine215-rho6/k215-rho6.tm` is the reversible dense renaming: working labels 0–214, dispatcher 83, halt 215. The `.tm` format begins with `#! start 0`; every other noncomment row is `state read write direction target`.

Native SHA-256:

```text
5ae9559203b0eb54e2d417e6d58793a2a696d023d40e7969d7192771005db28e
```

Dense SHA-256:

```text
bdbb5889aab49d73cf528bb287c8fd5648964fadc917de39bf23ea3061005d5c
```

Source SHA-256:

```text
19da13e482ea0f3d57432aad852bdf2448093e58a6e3b3873ac744eae7440693
```

The source changes four register operands, at ordinals 959, 964, 1137, and 1142, from register 3 to register 5. It emits rho6(A,B) instead of rho6(A,C), restores the copied parameters, and preserves every source address and control-flow target. Its allocation changes 42 native rows. `rho6-recipe.json` and `reconstruct_rho6.py` reproduce the exact source and machine without a solver.

The full quantified runtime run is in `machine215-rho6/verification/`. The startup trace is compressed without discarding any event. A separate parser and dense-state interpreter compare all 95,726 literal events and the entire final tape support. The endpoint is dispatcher 84, head −8, header 57, gap 1, logical registers `(N,T,W,C,D,H,X,Y,P)=(4,0,0,0,0,0,0,0,0)`, forty unit spares, and 95 one-cells with zero exterior.

## Reproduce the completed checks

Use Python 3.10 or later. The core checks and symbolic proof require only the standard library; the included baseline modules supply the inherited checker. Run commands from the extracted top-level directory.

```bash
python3 reproduce.py --output /tmp/zfc214-check
```

This checks the manifest, reconstructs both exact artifacts, checks the dense/native bijection and source edits, audits the complete guarded-case census and duration/row metadata, independently replays the full blank initialization, checks both source invariant certificates, regenerates eight source variants and eight enumeration-swap prefixes, reconstructs the increment-DROP sources, and reruns its finite command-stack checks. The aggregate metadata audit is explicitly distinguished from rerunning the primitive proof.

To regenerate the all-natural primitive proof as well:

```bash
python3 reproduce.py --full --output /tmp/zfc214-full-check
```

To additionally regenerate the spare-insensitive control proof:

```bash
python3 reproduce.py --full --spares --output /tmp/zfc214-all-checks
```

Each symbolic census took roughly two to three minutes in the research environment; machine speed affects this. The script requires a successful complete census and checks the regenerated exact case data against the released data. Generated outputs go to the requested directory, or to a new temporary directory if `--output` is omitted. Reproduction does not require the optional mixed-integer solvers. The pinned baseline also retains historical research files. Its unused `research/composition-allocation/check_allocated-v2.py` has a pre-existing syntax error; it is preserved verbatim for provenance and is not invoked by any reproduction command above.

Compile the report with TeX Live and `latexmk`:

```bash
cd report
latexmk -pdf -interaction=nonstopmode -halt-on-error investigation.tex
```

## What the research adds

### Formalism and stopping criteria

The report proves that halting on any derived membership atom is equiconsistent with halting on the original falsity code. It gives a global-validity argument for membership-blind inverse detachment, with explicit attribution to prior Source 154. These arguments use only consistency preservation; they do not demand equality of theorem sets. They also explain why halting on every odd code is unsound when equality codes are retained.

Moving the contradiction test to the end of a finite candidate is sound with a suitable command compiler. However, the measured current-source costs do not improve the baseline: the moved exact-one test gives 203 distinct subtrees; specialized exact-one and modulo-four tests cost still more. The 199-node source obtained by deleting the test entirely never halts and is not a consistency construction.

The proposed `AtomicHalt.lean` application is **uncompiled**. The ordinary mathematical proof, not that file, is the completed claim. Selected maintained Lean source files are included only to identify the inherited interfaces and their provenance.

### Two calibrated commands with parameter-free MP

The retained-residual variant keeps the accepted dominated AX inputs `A=d+x`, `B=h+y`, `U=d`, while AX returns `max(C-A-1,0)` in the numeric parameter. A theorem-preserving zeroing block makes that residual into a general setter. The ordinary proof supplies RESET, strong proof compilation, exact protected-stack restoration, and cofinal candidate encodings. The literal source costs **207 distinct subtrees**.

The second variant leaves AX unchanged and makes **every DROP increment the numeric parameter**. Repeated DROPs can then set any desired MP consequent or GEN label; the compiler explicitly removes the added stack padding. This handles label zero, consequent zero, arbitrary incoming numeric states, and the zero pairing alias. The literal source has **204 distinct subtrees and 4,738 primitive occurrences**; an exactly checked control-flow rearrangement reaches **203 distinct subtrees**. The source and proof are in `research/source/increment-drop/`.

Both variants eliminate MP's extra input field and preserve the required refutation condition. Neither currently has a verified binary implementation with 214 states. The restricted global allocation models reject the tested 204- and 203-node sources at that cap; the broader conditional-helper model timed out on the 203-node source without an incumbent. These outcomes concern the tested encodings, not the possibility of a smaller implementation.

### Separating the logical and set-theoretic parts of the bundle

The seed bundle contains both a logical membership-vacuity axiom and a set-theoretic seed core. Fixing only the seed's output label to 1 preserves equiconsistency while leaving the full logical component available. The proof treats the exceptional matrix code 1 explicitly and connects the restricted seed family to the inherited full-seed comparison. Its exact source removes 54 primitive occurrences, but costs **206 distinct subtrees** because sharing is lost. The tested partial allocation model reports no allocation.

The more aggressive raw fixed-role `(0,1)` seed is unsound at matrix code 0: binder shadowing turns an inner condition into the requirement that every object be nonempty. Separately, exact computed selectors `C=A+B+1` and `C=max(A,B)+1` have an all-natural obstruction: their matrices cannot mention both seed roles, and the restricted calculus has a hereditarily finite model whose existence ZFC proves. These semantic results, including their limits, are in the report's final two appendices and `research/formalism/`. The exact safe seed source and constructor checks are in `research/source/fixed-seed/`.

### Independently checked source invariants

`research/invariants/` contains two certificates for the exact baseline source, plus separate checkers.

- The nine-bucket certificate proves that ordinals 4672, 4673, and 4734 are unreachable, and that the decrements at 4671 and 4733 take their zero branches. Its checker verifies 6,170 abstract guarded edges.
- The rational affine certificate proves exact register equations at all source sites. Its separate Fraction-based checker verifies 6,172 guarded edges and 53,107 basis-vector inclusions. It contains nontrivial relations involving multiple registers at 1,221 ordinals.

Both are unconditional inductive source invariants from the accepted seed. Neither proves the halting instruction unreachable or assumes Con(ZFC). Their pruning experiments show why removing dead instructions may increase the source DAG: sharing can be lost.

### A weaker, sufficient spare-block contract

`research/spares/spare_runtime.py` preserves the exact control frame, head displacement, nine primary registers, and zero exterior, while allowing the final spare list to be any finite nonempty list of well-formed unary blocks. A compositional simulation proof justifies that relaxation. It gives more room for backend changes than the previous exact-spare-update requirement.

The portable checker freshly proves all 6,176 baseline cases. Its reviewed core and original review are preserved; the portability change only relocates the baseline path. This is a verified acceptance contract, not a state reduction. Attempts to remove end-of-file states failed because those states also participate in decrement control and initialization.

### Source and physical searches

The packet preserves exact, bounded source families, solver models, and physical screening receipts. These cover schema parameter permutations, row orders, reassociations, register permutations, command changes, state quotients, helper sharing, caller retargeting, spare mutations, and a decoder that may omit proven-unreachable junk branches. The detailed files record their actual limits and counterexamples.

A solver's infeasibility result applies only to its explicit model. Some broader allocation runs ended at a time limit with no incumbent; they are not infeasibility proofs. `research/allocation/interpreted-results.json` makes that distinction explicit while retaining the original raw results. Finite physical screens nominate or reject mutations; they do not establish a final all-natural runtime theorem.

## Directory map

| Directory | Contents |
|---|---|
| `baseline/candidate-k215/` | Pinned reference construction, runtime modules, ordinary proof, provenance and licenses |
| `machine215-rho6/` | Authoritative new 215-state alternative and complete fresh evidence |
| `research/invariants/` | Bucket/affine generators, exact certificates, independent audits, pruning |
| `research/spares/` | Relaxed-spare checker, mathematical review, original and portable control runs |
| `research/source/` | Source transformations, allocation scripts, exact family receipts and proofs |
| `research/formalism/` | Equiconsistency arguments, stopping/command experiments, current-source censuses |
| `research/physical/` | Physical search code, bounded contexts, receipts, reachable-junk checker |
| `research/allocation/` | Broader role-allocation models and scoped solver outcomes |
| `references/` | Attributed source extracts and commit/path/hash provenance |
| `report/` | Main `.tex` files and compiled `.pdf` |

Optional allocation scripts require NumPy and SciPy with `scipy.optimize.milp`. Physical C++ searches use the compiler and commands described in their local research note. These optional searches are not part of the core reproduction gate.

## Proof and attribution boundaries

The numerical-calculus/ZFC calibration, native arithmetic engine, source language, marker folds, compiler ancestry, and original quantified runtime calculus are inherited. Their original notices and licenses are retained. This work supplies ordinary proofs and executable induction checks, not a new exact-table Lean/Rocq theorem. Independent reviews mentioned here are separate work inside this research collaboration, not external human endorsements.

The active result remains: **a fully checked 215-state alternative and research artifacts; no verified machine with 214 states or fewer.**
