#!/usr/bin/env python3
"""Independent dense, canonically relabeled blank-run comparison.

No candidate runtime or compiler module is imported. Every step is compared
with the separately generated native startup trace, then the full support of
the tape is compared with its claimed endpoint. The exterior is identically
zero: an N-step head never leaves [-N,N].
"""
import argparse,hashlib,json
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('table',type=Path);ap.add_argument('startup',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 raw=a.table.read_bytes();text=raw.decode('ascii');rows=[];start=None
 for line in text.splitlines():
  if line.startswith('#! start '):start=int(line.split()[2]);continue
  if not line.strip()or line.lstrip().startswith('#'):continue
  q,r,w,d,t=line.split();q,r,w,t=map(int,(q,r,w,t));assert r in(0,1)and w in(0,1)and d in('L','R');rows.append((q,r,w,(-1 if d=='L' else 1),t))
 labels=sorted({r[0]for r in rows});assert len(labels)==215 and len(rows)==430 and start==0
 numbering={q:i for i,q in enumerate(labels)};numbering[254]=215
 assert set(numbering)==set(labels)|{254}
 dense=[[None,None]for _ in labels]
 for q,r,w,d,t in rows:assert dense[numbering[q]][r]is None;dense[numbering[q]][r]=(w,d,numbering[t])
 assert all(all(x is not None for x in row)for row in dense)
 expected=json.loads(a.startup.read_text());N=expected['steps'];assert len(expected['trace'])==N
 cells=bytearray(2*N+1);head=N;q=numbering[start];sha=hashlib.sha256();reverse={v:k for k,v in numbering.items()}
 for i,row in enumerate(expected['trace']):
  assert q!=215,('early halt',i)
  read=cells[head];write,move,target=dense[q][read];actual=[reverse[q],head-N,read,write,move,reverse[target]]
  assert actual==row,('trace mismatch',i,actual,row)
  sha.update((','.join(map(str,actual))+'\n').encode());cells[head]=write;head+=move;q=target
 support=[i-N for i,v in enumerate(cells)if v]
 assert reverse[q]==expected['state']==84 and head-N==expected['head']==-8
 assert support==expected['one_cells']
 marker=head-N-1;assert min(support)==marker
 right=[x for x in support if x>marker];header=min(right);gap=header-(head-N)-64;assert gap==1
 assert all(cells[N+x]==0 for x in range(head-N,header))
 blocks=[];position=header+1
 while position<=max(support):
  assert cells[N+position]==0 and cells[N+position+1]==1
  position+=1;value=-1
  while cells[N+position]==1:value+=1;position+=1
  blocks.append(value)
 physical_order=(6,2,0,4,3,7,8,5,1);registers=[blocks[j]for j in physical_order]
 assert registers==[4,0,0,0,0,0,0,0,0] and blocks[9:]==[1]*40
 assert expected['registers']==registers and expected['spares']==blocks[9:]
 receipt=dict(status='INDEPENDENT_DENSE_STARTUP_PASS',table_sha256=hashlib.sha256(raw).hexdigest(),startup_file_sha256=hashlib.sha256(a.startup.read_bytes()).hexdigest(),steps=N,working_states=215,state=reverse[q],head=head-N,ones=len(support),gap=gap,registers=registers,spares=blocks[9:],one_cells=support,trace_sha256=sha.hexdigest(),scope='Independent text parser and dense canonical-state interpreter; every native startup trace step and complete endpoint support agrees. Entire exterior remains zero by the head-speed bound.')
 a.output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='one_cells'},indent=2))
if __name__=='__main__':main()
