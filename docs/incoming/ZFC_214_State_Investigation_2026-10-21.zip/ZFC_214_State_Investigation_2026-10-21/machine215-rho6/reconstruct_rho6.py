#!/usr/bin/env python3
"""Reconstruct the exact verified rho6-only K215 source and native table.
No optimizer or MILP solver is run. Literal row edits are in rho6-recipe.json.
"""
import argparse,hashlib,json,sys
from pathlib import Path

def sha(raw):return hashlib.sha256(raw).hexdigest()
def compact(x):return(json.dumps(x,separators=(',',':'))+'\n').encode('ascii')
def table(raw):
 result={}
 for line in raw.decode('ascii').splitlines():
  if not line.strip()or line.lstrip().startswith('#'):continue
  q,r,w,d,t=line.split();key=int(q),int(r);assert key not in result
  assert d in('L','R');result[key]=(int(w),-1 if d=='L' else 1,int(t))
 return result

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 recipe=json.loads(Path(__file__).with_name('rho6-recipe.json').read_text());sr=(a.candidate/'sites215.json').read_bytes();tr=(a.candidate/'k215.native.tm').read_bytes()
 assert sha(sr)==recipe['baseline_source_sha256']and sha(tr)==recipe['baseline_table_sha256']
 rows=json.loads(sr)
 for e in recipe['source_edits']:
  i=e['ordinal'];assert rows[i]==[e['path'],e['opcode'],e['old_operand']];rows[i][2]=e['new_operand']
 source=compact(rows);assert sha(source)==recipe['source_sha256']
 T=table(tr)
 for e in recipe['table_row_edits']:
  k=e['state'],e['read'];assert T[k]==tuple(e['old']);T[k]=tuple(e['new'])
 native=('#! start 0\n'+''.join(f'{q} {r} {w} '+('L'if d<0 else'R')+f' {t}\n'for(q,r),(w,d,t)in sorted(T.items()))).encode('ascii')
 assert sha(native)==recipe['table_sha256'];assert len(T)==430 and len({q for q,r in T})==215
 sys.path.insert(0,str(a.candidate/'code'));import source_language as s
 g=s.graph_intervals(rows);assert g==s.graph_arithmetic(rows)[0];assert s.metrics(s.tree(rows))==recipe['source_metrics']
 (a.output/'sites215-rho6.json').write_bytes(source);(a.output/'k215-rho6.native.tm').write_bytes(native)
 report=dict(status='EXACT_RHO6_RECONSTRUCTION_PASS',source_sha256=sha(source),table_sha256=sha(native),working_states=215,source_operand_edits=len(recipe['source_edits']),native_row_edits=len(recipe['table_row_edits']))
 (a.output/'reconstruction.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
