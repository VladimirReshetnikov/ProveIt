# A 235-state binary Turing machine calibrated to Con(ZFC)

**Result:** this package constructs a deterministic, binary, one-tape,
blank-start machine with **235 working states**, excluding its separate halt
outcome. The new proofs compose with the exact pinned ProveIt calibration to give

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halts}(M_{235},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

This improves the 236-state construction in commit
`0b5fec6980cc3a5ba7dd47b404f0cbbe9a451c02`. Read **report.pdf** for the construction,
mathematical proofs, alternative formalism, and complete transition table.
**report.tex**, `sections/`, and `formalisms/` rebuild that report.

## Exact machine

| Item | Value |
|---|---|
| Canonical table | `machines/zfc235.tm` |
| Working states | 0–234 |
| Initial state, head, tape | 0, coordinate 0, identically zero |
| Dispatcher | 84 |
| Separate halt outcome | 235 |
| Alphabet and tape | Binary, one two-sided tape |
| Moves and complete transition rows | L/R only, 470 rows |
| Exact blank initialization | 409,835 transitions |

Canonical table SHA-256, including its header and final newline:

```text
4a2c6b05e347522236dc6faf0bde5f71480aa6c6795faa6f20a11f1a1601895f
```

Inherited-label table SHA-256 (`machines/zfc235_old.tm`):

```text
d017abe46023a4154085a2fe2c04c8d66bbbec53b81d193d520ad697d171cbd4
```

The complete bijection is in `machines/renumbering235.json`. Inherited labels
have initial state 95, dispatcher 96, and halt outcome 254.

## What changes

Apply seven closed source rotations, in order:

| Stage | Outer state | Inner state | Direction |
|---:|---:|---:|---|
| 1 | 138 | 211 | Right |
| 2 | 116 | 134 | Left |
| 3 | 162 | 116 | Left |
| 4 | 199 | 227 | Left |
| 5 | 227 | 197 | Right |
| 6 | 197 | 115 | Right |
| 7 | 115 | 229 | Right |

Here left means `(A,(B,C)) → ((A,B),C)` and right is its inverse. All three
chunks at every stage have no escaping break/continue or halt. The exact source
certificate records all occurrence paths, boundaries, row edits and graph checks.
All 6,455 operations and 8,386 guarded successors are preserved. There are 2,524
changed source paths; the source DAG stays at 224 nodes and maximum depth falls
from 49 to 48. The final maximum zero run is six.

The first four rotations expose a state fold. The final three repair the tape
encoding without disturbing shared arithmetic contexts. The rotated 236-state
basis differs from the original in 17 rows. Some intermediate source trees have
seven-zero runs; only the final literal source/table pair is claimed to implement
the calibrated program.

In that final basis, old state 74 always has a 0 immediately left of its head;
old state 193 always has a 1 there. Delete 193, redirect `163/1` and `229/1` to 74,
and set:

```text
74 0 0 L 138
74 1 1 L 116
```

Four existing three-transition paths then reproduce the four old transitions,
preserving the entire tape and ending one cell right. The other 468 rows commute
in one transition. The fold proof holds on every initial binary tape and every
initial head position from common start state 95. The complete result changes
20 surviving rows relative to the pinned original and deletes both rows of 193.

This is a new exact composition of inherited techniques. It is not a claim that
source associativity or predecessor-bit state sharing was invented here, or that
235 is globally minimal.

## Verification and proof scope

| Check | Completed result |
|---|---|
| Source graph, every stage | 6,455 operations and 8,386 guarded cases identical |
| Independent source audit | Complete trie and ancestor-unwinding comparison |
| Independent local fold audits | 468 one-step blocks and four three-step blocks |
| Generic open-tape proof | All 472 old rows; inductive predecessor-bit invariant |
| Exact startup | 409,836 matching checkpoints, 409,835 transitions |
| Startup tape | 351 one-cells, complete support recorded and compared |
| Rotated basis runtime | 8,386 cases; 2,266,171 symbolic rule applications; all 472 rows |
| Final 235 runtime | 8,386 cases; 2,269,055 symbolic rule applications; all 470 rows |
| Minimum instruction duration | 13 literal transitions |

The runtime proofs quantify over all independent natural primary values, every
zero/positive decrement guard, arbitrary nonnegative extra gap, arbitrary first
spare value and every finite spare tail. The exact-table unary and list induction
rules prove whole-tape/head/source-successor contracts for nonhalt instructions,
and arrival at the halt outcome for halt instructions, with positive duration.
The 4,000-iteration budget limits construction of each symbolic proof, not actual
runtime, register sizes or list lengths. The largest successful proof uses 460
symbolic rules.

**These are ordinary mathematical proofs formalizable in ZFC, with exact
executable evidence.** The source-to-native-refutation, ZF and Choice/Foundation
calibration is inherited. The existing external 240-state Lean endpoint remains
the formal endpoint inherited here. No newly compiled Lean/Rocq endpoint for 235
and no completed internal PA proof-code endpoint are claimed.

The biconditional itself needs no consistency assumption. Assuming ZFC is
consistent then gives actual nonhalting and its unprovability in ZFC. Mere
consistency is not used to assert two-sided independence of the halting statement.

## Reproduce offline

Use Python 3.10 or newer on Linux, macOS or WSL, with assertions enabled,
from this directory:

```sh
python3 -B reproduce.py --output-dir replay
python3 -B reproduce.py --full --output-dir replay-full
```

Choose a new or empty output directory. The default replay verifies the manifest,
extracts the unchanged 236-state archive, reconstructs exact source/machine bytes,
reruns the finite proofs and startup, regenerates the equational packets, audits
the full delivered runtime evidence, replays the rejected concrete controls, and
runs the inherited 236-state quick suite. All outputs go to the chosen directory.

`--full` additionally reconstructs both unbounded runtime certificates in parallel
and compares the fresh case arrays byte for byte. The quick evidence audit is not
a substitute for that fresh symbolic proof construction. No network, third-party
Python packages, C++ compiler, Lean or Rocq are required for mathematical replay.
The C++ concrete filter in `discovery/` is optional discovery material.

To rebuild the PDF, use a LaTeX installation with the packages named in the
preamble:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

Run manifest verification on the delivered package before changing or rebuilding
its files. `make_appendices.py` regenerates the table and bit-string appendices
directly from the pinned machine and packet.

## Alternative formalism: E663

`formalisms/` supplies a **663-bit complete equational consistency packet**:
nine operation symbols, seven equations, 150 equation-term nodes, and the ground
query `Q(d)=d`. It has the inherited raw-EPSC/ZFC consistency calibration.

The new work first derives and removes E692's explicit truth equation, producing
the same-model E667 theory. It then replaces the Boolean collapse query `N(d,d)=d`
with `Q(d)=d`. Head and Tail show that this smaller query also collapses the whole
carrier to a singleton, so the two queries have identical derivability status.

The complete cost is 43 header bits + 608 axiom bits + 12 endpoint bits. This saves
29 bits relative to E692 and 25 relative to E688 in the unchanged codec. Packed
transport occupies 83 bytes, including one excluded padding bit. Its bit-character
SHA-256, excluding the text-file newline, is:

```text
6c3b72c39c81aa5bbf028e654c8056e7e86376cdeecdd56943e5c3e23de1a215
```

The packet is a separate formalism result. **The 235-state machine uses the
existing calibrated frontend.** E663 still needs a complete binary proof-search
interpreter and blank writer before any competing state count can be claimed.
The report also compares direct ZFC proof enumeration, the native calculus,
EPSC/PSC, a finite arithmetic presentation, and the incomplete finite-class route.

## Provenance and incorporation

`vendor/zfc236.zip` preserves the exact archive from commit
`0b5fec6980cc3a5ba7dd47b404f0cbbe9a451c02`, SHA-256
`540305f4e805165e818290e82c5a6cba5faed25b5abb946fd9c750f6c45db9f5`.
It includes its own manifest, earlier 237-state work and inherited theorem
sources. The supplied notices preserve Mira-Cult, Jeff Ketchersid, Andrew James
Wade and preceding ProveIt contributions. New material follows the retained
ProveIt license.

The package is suitable for a new research directory such as
`Computability/BusyBeaver/Research/ZFC/candidate-context235`, with its archive under
`docs/incoming/`. No repository modification or publication is performed by this
delivery. `SHA256SUMS` covers all delivered files except itself.
