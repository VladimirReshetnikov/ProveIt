# K215: a 215-state ZFC consistency machine

**The primary candidate has 215 working states and 430 binary transitions.**
This packet provides its exact native and canonical tables, complete source,
deterministic construction, ordinary mathematical proof, compiled report,
and executable evidence for

    ZFC ⊢ (the blank-start machine does not halt ↔ Con(ZFC)).

The new machine composes two public 216-state constructions that appeared
while this research was in progress. Their individual reductions are credited
to their original submissions. The new contribution is their compatible
source composition and constrained physical allocation, followed by a fresh
complete runtime and blank-start verification. It does not depend on the
additional new calculus results included in the same report.

## Exact primary machine

| Property | Value |
| --- | --- |
| Tape | One two-way infinite tape, two symbols, initially all zero |
| Moves | Left or right; deterministic total table on every working state |
| Working states / rows | 215 / 430 |
| Canonical working labels | 0–214; initial state 0; separate halt 215 |
| Native start / dispatcher / halt | 0 / 84 / 254 |
| Source primitive occurrences / distinct subtrees | 4,751 / 202 |
| Source depth / longest zero run | 47 / 6 |
| Universal guarded primitive cases proved | 6,176 / 6,176 |
| Symbolic proof rules in the fresh derivation | 1,698,790 |
| Transition rows used in certificates | 430 / 430 |
| Minimum positive affine duration constant | 6 |
| Complete blank prefix | 95,726 transitions |

The primary files are `candidate215/k215.tm`, `candidate215/k215.native.tm`,
and `candidate215/sites215.json`. SHA-256:

```text
canonical  6c0fff966c4409eb726e634d6d5753552e198da0f8c7bfe7fc39ec0151f1de7a
native     04b4dbb537306f40f8965ad6a0ee6034e9953f079c233153e9696acdf06c2712
source     17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba
```

The full blank tape reaches native dispatcher 84 at head −8, extra gap 1,
registers `(4,0,0,0,0,0,0,0,0)`, forty spare blocks of value 1, and exactly
95 one cells. All other cells are zero. The proof covers the initial finite
candidate cutoff using a cofinal family of compiled refutations.

## Why the composition saves a state

The Partial Selector parent supplies its source reassociation and the
164/183 marker fold. The Permuted Commands parent supplies the MP-only input
schedule, the reader/load association, command order 210, and the local
state-81 helper repair. A direct union of their row patches would conflict.

The composed source preserves 157 inherited internal subtree roles in 143
physical states and has 22 new internal nodes. A fixed constrained allocation
places those nodes in 22 members of a 23-state retired decoder pool, preserving
the arithmetic duties of shared states. With 50 remaining engine states,
this gives `143 + 22 + 50 = 215`. Native state 185 is removed; 36 retained
rows change relative to the Partial Selector 216 parent. Both inherited marker
folds remain valid. The released builder checks the fixed assignment directly;
no optimization solver is needed to reproduce it.

## Contents

| Path | Purpose |
| --- | --- |
| `report.tex`, `report.pdf` | Full construction, proof, research findings, and evidence limits |
| `candidate215/` | Exact new primary machine, source, builder, row recipe, pinned parents, proof fragments, and fresh runtime evidence |
| `candidate215/review/` | Independent source, complete blank-tape, local-fold, and runtime-inventory checks |
| `theory/` | Projection-basis theorem, inherited finite certificate, residual-command theorem, and exact checkers |
| `review/`, `results/` | Independent logical reviews and executed research receipts |
| `baseline/` | Exact accepted K217 predecessor and its notices, license, and provenance |
| `upstream216/` | Unchanged public Permuted Commands submission and fresh selected replay |
| `search/source/` | Portable source and allocation experiments, including unsuccessful layouts |
| `search/physical/` | Bounded physical-fold searches, domains, stopping limits, and results |
| `verify.py`, `MANIFEST.json` | Offline compact replay and release file integrity |

The optional `candidate215/secondary120/` contains a separately labeled
exploratory variant. Its source, allocation, and blank prefix were checked;
it has no full universal runtime certificate in this packet and is not the
principal machine.

## Reproduction

Use Python 3 without `-O` or `PYTHONOPTIMIZE`; assertions are part of the
checking code. Compact replay uses only the standard library, with no
network, external repository, solver, or proof-search software.

```bash
python3 -B verify.py --output /tmp/k215-check.json
```

This verifies release hashes, reconstructs the exact primary table/source,
checks every source guard, replays complete native and canonical blank
execution, proves the two local fold diagrams, and inventories every stored
universal runtime case. It also checks the new calculus certificates and
research results and replays selected checks on the credited parent.

To freshly derive all 6,176 arbitrary-natural primitive cases as well:

```bash
python3 -B verify.py --runtime --output /tmp/k215-full-check.json
```

The delivered `candidate215/fresh/runtime.json` and compressed ordered case
records already come from an actual complete fresh derivation for these exact
bytes. The `--runtime` option reproduces it using the unchanged pinned checker
inside the authenticated parent archive. The full derivation took about
136 seconds in the research environment; timing depends on the host.

For only the principal candidate, independently of the additional research:

```bash
python3 -B candidate215/replay.py --runtime --output /tmp/k215-primary-check
```

`--upstream-runtime` on the top-level verifier also rederives the public
216-state parent's cases. Large physical-search sweeps are separate explicit
commands documented under `search/physical/`; they are not needed to accept
the primary candidate. A C++17 compiler is needed for one optional sweep.

Build the report with an ordinary TeX Live installation:

```bash
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The supplied PDF was compiled and visually inspected. Rebuilding can change
PDF metadata and its hash; `--skip-manifest` permits intentional local edits
without disabling the mathematical checks.

## Additional formalism results

The report also establishes a three-input replacement for the fourth argument
of the classical numerical axiom: zero plus eight total projections of its
first argument preserve the full native numerical theorem set. Two checkers
replay the 3,728-node proof and all 1,260 axiom leaves. Exactly six minimum
nine-function supports cover that fixed certificate; one uses seven shared
projection evaluations. These operation counts are not state lower bounds.

A separate command-calculus theorem makes MP parameter-free by using an
axiom-gate residual and a stack-preserving setter. Its source encodings are
currently larger. The four-valued matrix obstruction is proved for its stated
total raw-code projection families, but excludes native generalization and
the full set-theoretic bundle. A scanner counterexample and unsuccessful
bounded searches are also retained with precise scope.

## Proof scope and attribution

The exact-table equivalence is an ordinary mathematical proof formalizable
in ZFC, using pinned inherited native-calculus/ZFC calibration. The runtime
engine proves contracts for arbitrary natural values by symbolic induction;
it is not a bounded test over small registers. No new Lean/Rocq kernel theorem,
unconditional nonhalting, proof of Con(ZFC), or global minimality is asserted.

Both public 216-state predecessors and the original K217 ancestry retain their
identities, notices, and licenses. See `NOTICE.md`, the candidate's source pins,
and the unchanged parent archives. The proposed new machine result is this
exact 215-state composition.
