# Rational Tubes, Integer Zeros

**Complete Diophantine Certificates for Polynomial Flows and Chemical Computation**

Research manuscript prepared for Vladimir Reshetnikov, September 30, 2026.

## Main files

- `article.pdf`: the 30-page article, with proofs, references, and eleven further research topics.
- `article.tex`: complete editable LaTeX source; the bibliography is embedded.
- `code/tubes.py`: exact integer certificate generation and checking.
- `code/quartic.py`: witness-carrying quadratic-residual / quartic sum-of-squares compiler and exact syntactic gate counter.
- `code/kinetic.py`: separate-rail and common-offset chemical lifts, reaction extraction, and symbolic checks.
- `code/run_checks.py`: reproducible test suite.
- `code/constant_example.py`: a completely specialized quartic with 17 natural witnesses and 15 residuals.
- `code/verify_json.py`: command-line checking of exported tube certificates.
- `results/verification_summary.json`: complete test results, counts, and software versions.
- `results/*_certificate.json`: eight accepted integer tubes, including a three-species chemical system.
- `results/*_quartic.json`: explicit parameterized quadratic residuals and complete natural witnesses.
- `results/specialized_constant_expanded.txt`: the expanded ordinary quartic for the specialized example.
- `results/*_reactions.json`: full reaction lists, including a four-species nonlinear common-offset lift.

## Mathematical results

For a rational polynomial ODE, rational initial point, and open rational
polyhedral target, finite reachability is equivalent to existence of a canonical
integer tube certificate. Every accepted certificate establishes existence up to
its terminal time and target inclusion, including optional bounded measurable
forcing and initial-state uncertainty. Every nominal finite open event admits
some strictly positive finite-horizon tolerance.

For a fixed source instance and mesh length N, the certificate becomes a sum of
squares of quadratic residuals. With d state coordinates, m target rows, and g
signed arithmetic gates, it uses

    natural witnesses = 2g + (6d+3)N + 2d + m + 3
    equations         = 2g + (5d+2)N + 2d + m + 3

The resulting polynomial has total degree at most four, including the free
parameters R, H, D. Its natural witness is unique once the source, N, noise units,
and R, H, D are fixed. N is an external unrolling index, not another variable in
one fixed-length polynomial.

For a d-dimensional source of degree at most k >= 1, two rational mass-action
normal forms preserve its entire forward orbit under positive changes of time,
with no finite-time explosion from the prescribed initialization:

    separate rails:  2d+1 species, degree <= Delta
    common offset:    d+2 species, degree <= Delta+3
    Delta = k+d+ceil((k+d)/2)+3

Both projections are linear, so open rational polyhedral targets remain in the
same class. The tradeoff bounds are not claimed optimal.

The complete checker is a front end to MRDP. Fixed-dimensional Diophantine
existence follows, but the explicit trace counts and local witness uniqueness
are not claims of a single-fold representation for arbitrary r.e. sets.

## Reproduce

Tested with Python 3.13.5 and SymPy 1.14.0. The code uses Python 3.10+ syntax.
The integer tube checker itself needs only the standard library.

    python -m pip install -r requirements.txt
    python code/run_checks.py
    python code/constant_example.py

Check one of the supplied certificates directly:

    python code/verify_json.py results/chemical_end_to_end_certificate.json

On a shell with glob expansion, check them all:

    python code/verify_json.py results/*_certificate.json

Build the PDF with a TeX Live installation containing the packages used by the
source, including New PX, tcolorbox, and cleveref:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Alternatively run `make all`. No font files are distributed.

## Reading the outputs

A `*_certificate.json` contains the source instance, integer trace, and a result
summary. Initial rational coordinates are numerator/denominator pairs. Target
rows `(a,b)` mean the strict inequality `dot(a,x) < b`.

A `*_quartic.json` lists residuals f_i. The single equation is exactly
`sum(f_i**2) = 0`, with every listed witness variable restricted to the natural
numbers. The listed R, H, D values instantiate otherwise free parameters. The
strings are transparent mathematical expressions, not instructions to execute
untrusted input. Do not use `eval` on arbitrary downloaded expressions.

The compiler's current public interface takes an accepted certificate and emits
its symbolic schema plus witness. The schema structure depends only on the
source, N, and fixed noise units, but a separate witness-free command-line
compiler is not supplied.

The long chemical certificate has 2,000 steps. Its full generic quartic was
counted (42,044 signed gates; 126,099 natural witnesses; 118,099 residuals) but not
materialized. A one-step instance for the same chemical field and a wider target
was fully emitted and checked: 162 witnesses and 158 residuals.

JSON numbers here include integers larger than 2^53. Python's standard JSON
parser preserves them exactly. Do not round-trip these files through software
that converts all JSON numbers to double-precision floating point.

## Verification scope

The suite checks eight accepted tube examples, six independently corrupted
certificates, two additional rejected candidates, 4,020 signed Euclidean division
cases, 4,020 ceiling division cases, five generic quartic compilations, one
specialized quartic, and both chemical normal forms on six source vector fields.
Every emitted reaction system is reconstructed symbolically and compared with
its polynomial field. The source-to-chemical-to-tube pipeline includes a direct
accepted three-species chemical certificate, not just identities of projections.

These are reproducible exact-arithmetic and symbolic checks, not a Lean
formalization, a proof of the implementation's correctness in a proof assistant,
or a numerical verification of the universal analytic assertions. The general
proofs are in the article. No world-first priority claim is established, and no
single-fold MRDP conjecture is claimed solved. The transfer from a Turing-machine
front end is stated under an explicit finite-event compiler contract rather than
silently identifying asymptotic computation with finite halting recognition.

The chemical systems are idealized deterministic mass-action networks, not
claims of laboratory implementation, stochastic robustness, conservation of
physical mass, or globally bounded concentrations. Global existence is proved
for the prescribed initialization on the stated invariant manifold, not every
arbitrary initial concentration vector.

## Repository provenance

The inspected ProveIt snapshot is
`6d04e1e385f2fe7d1cfbdbd8fd8d4e45bd6b6c72`.
The main existing interface consulted was
`Computability/HilbertTenthProblem/Lean/MRDP.md`.
No repository source files were changed and no Lean build was performed.
