# A Single Quadratic Phase Across All Translates

**Spectral extraction, offset rigidity, and sharp stability in Gowers's Section 8**  
Research manuscript prepared for the ProveIt project, 6 October 2026.

## Main mathematical output

Theorem 1.1 strengthens the input/output interface of Gowers's Proposition 8.1.
For a balanced indicator on an odd cyclic group, one global polynomial
`psi(z) = (lambda/2) z^2 + r z` works across all translates of an arbitrary
nonempty input subset P. Under the original unnormalized energy hypothesis,
the unweighted total correlation is at least

    beta N |P| / [delta(1-delta) max(delta,1-delta)] >= (27/4) beta N |P|.

The original cited conclusion has translate-dependent polynomials and coefficient
`1/sqrt(2)`. The common-polynomial assertion is an aggregate lower bound across
translates, not a lower bound on every individual translate. The constant `27/4`
is the best uniform consequence of the displayed amplitude estimate; it is not
claimed optimal over balanced indicators.

The other central results are the exact mixed weighted Fourier factorization
(Theorem 2.2), all-finite-abelian-group extension using quadratic refinements
(Section 4), complete single-offset energy/equality classification (Theorem 5.3),
and dimension-free recovery with optimal exponent `1/2` for character orders
at most four and `1/4` for orders at least five (Section 6). A four-frequency
construction proves the latter exponent is necessary. Several-offset bounds
are derived from the classical Motzkin–Straus theorem (Section 7).

## Contents

- `article.tex`, `article.pdf`: self-contained 20-page article, with full proofs,
  11 proposed research questions, source references, and limitations.
- `SOURCE_AUDIT.md`: inspected sources, exact repository pin, attribution and
  proof audit. Absence of a located earlier match is not a priority certificate.
- `FORMALIZATION.md`: statement-level integration plan and degenerate-case audit;
  no uncompiled Lean code is presented as verified.
- `code/verify.py`, `data/verification.json`: reproducible exact and numerical
  checks with explicit scope and recorded environment.
- `Makefile`, `requirements.txt`: build and verification entry points.
- `CHECKSUMS.sha256`: checksums for the packaged content.

## Reproduction

Use Python 3 with NumPy; the recorded run used Python 3.13.5 and NumPy 2.3.5.
`requirements.txt` pins the version used for that run. The LaTeX article requires
a normal TeX Live installation including the packages named in its preamble.
It contains its bibliography and has no external image or data dependencies.

```sh
python -m pip install -r requirements.txt
make verify
make pdf
```

The script runs from any working directory and writes `data/verification.json`
relative to its own location. It refuses optimized Python (`python -O`), since
its tests use assertions. Floating-point last digits may vary with platforms.
`make clean` removes only LaTeX intermediates, preserving the PDF and sources.

## Verification recorded

All checks pass. Exact arithmetic checks 31,030 rational graph distributions,
including 227 triangle-free equality cases, five rational four-frequency
obstructions, and 7,704 product-group polarization identities plus coordinate
periodicity. Numerical checks cover 2,016 mixed factorization cases, 2,540 global
offset cases, 402 weighted balanced cases, 1,440 long-cycle repairs, and 1,440
short-orbit repairs. The maximum recorded Fourier identity discrepancy is
`1.8407304395702437e-15`, against tolerance `1e-10`. Counts and details are in JSON.
These checks supplement, rather than establish, the general proofs.

## Repository integration

The corrected Section 8 interface is pinned to
`6a6d7961c3c261da7dc18def13fff30b12dd5c04` in
`VladimirReshetnikov/ProveIt`. A proposed destination is

    Combinatorics/Ramsey/Research/GowersSzemeredi/single-phase-offset-stability/

This is a proposed new folder, not a claim that it exists or was created.
No repository file, formal status ledger, or existing merged manuscript was
modified. Add the new result beside the old proposition and prove its implication
before replacing a downstream dependency. See `FORMALIZATION.md` for details.

## Research status

The results are presented with complete mathematical proofs and reproducible
self-checks. They have not been independently peer-reviewed or checked in Lean.
The named classical ingredients are credited; novelty of the proposed combined
local formulations and stability refinements remains subject to literature and
expert review. No improved end-to-end inverse theorem or Szemerédi bound is
claimed, and the recovered extremizer is not asserted to preserve a pointwise
cap, reality, or the balanced-indicator condition.
