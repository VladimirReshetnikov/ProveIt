# Unit-Dilation Restriction on Cyclic Groups

**Polynomial losses for Gowers' approximate homomorphisms and exact weighted degeneracy constants**

Research manuscript prepared with ChatGPT for the ProveIt Ramsey collection.
Research date: 6 October 2026.

## Main result

For an arbitrary map `phi : B -> Z/MZ`, with `B` a subset of `Z/NZ` of size
`beta N`, suppose at least `alpha |B|^15` ordered additive sixteen-tuples are
respected. If `0 < alpha,beta,eta <= 1` and

```
N >= 2^253 (alpha eta)^(-31) beta^(-15),
```

there is `B'` contained in `B` on which at least the proportion `1-eta` of
additive sixteen-tuples are respected, and at least

```
2^(-245) alpha^31 eta^30 |B|^15
```

respected tuples remain. Repetitions are included. Domain and target moduli
may be composite and need not agree. This completely elementary statement
is Corollary 7.2; the parameterized theorem is stronger.

For every fixed even tuple length `m >= 4`, a sharper choice gives retention
of order `alpha^m eta^(m-1) / loglog(e^e/(alpha eta))^(m-1)` times
`|B|^(m-1)`, with a polynomial size threshold. Only the logarithm-to-double-
logarithm refinement uses the classical Rosser-Schoenfeld totient estimate.

## Additional proved results

The manuscript provides the exact defect-order response, an exact weighted
gcd formula for the arithmetic error, a uniform error bound independent of
the filter length, and the limiting constant `zeta(m-2)/zeta(m-1)`. The limit
is not a uniform finite-length bound: an exact length-three example exceeds
it at `m=16`. A primorial construction proves that the primitive response of
this particular family of Fejer kernels has unbounded double-logarithmic
worst-case size. A bounded-fibre labelled-domain extension is also proved.

## Files

- `article.tex` and `article.pdf`: self-contained research manuscript.
- `code/verify.py`: standard-library exact finite checks.
- `data/verification.json`: recorded successful run.
- `SOURCE_AUDIT.md`: inspected sources, pinned repository revision, and
  limitations of the novelty comparison.
- `PROOF_AUDIT.md`: critical proof interfaces and error accounting.
- `FORMALIZATION.md`: suggested integration order and declaration crosswalk.
- `CLAIMS.json`: machine-readable claim and dependency index.
- `Makefile`: PDF build and verification targets.

## Reproduce

Requires Python 3.10 or newer for the verifier. No Python packages are needed.
The recorded run used Python 3.13.5. Use ordinary Python, not `python -O`,
since the verification checks use assertions.

```
make check
make pdf
```

Equivalently:

```
python3 code/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The LaTeX source uses standard AMS, Latin Modern, geometry, microtype,
hyperref, bookmark, enumitem, booktabs, and needspace packages. The bibliography
is embedded; no BibTeX or external figures are required.

The exact run checks 19,716 primitive profiles, 2,184 weighted-modulus cases,
22 independently enumerated coefficient cases, and six random-restriction
examples covering all 312 subset outcomes. It also checks 28 parameter cases,
small-length identities, and four primorial examples. These checks supplement
rather than replace the universal mathematical proofs.

## Integration and status

Suggested new directory (no existing files need to be replaced):

```
Combinatorics/Ramsey/Research/GowersSzemeredi/unit-dilation-restriction/
```

The inspected repository already has `lemma_9_3_holds`. This delivery is a
stronger local estimate and a new proof route, not a claim to have filled an
unproved old interface. No repository files, status ledger, or Lean modules
have been modified.

The manuscript is AI-assisted and has not undergone independent human peer
review or Lean-kernel verification. Its main statements have written proofs;
finite calculations have been executed. It makes no publication-priority
claim and does not assert a new global Szemeredi or Ramsey bound.
