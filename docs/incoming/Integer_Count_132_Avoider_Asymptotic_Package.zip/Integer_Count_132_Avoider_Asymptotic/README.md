# Integer-Count Transitions for 132-Avoiders at the m log m Scale

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

The eight-page manuscript proves a relative probability equivalent uniformly
when (n-1)/(m log m) stays in a fixed compact positive interval. Put v=n-1,
s_ell=ell-v/m and

 F(ell)=(ell+1) exp(3s_ell/2) s_ell^(ell-1)
          /[(2sqrt(pi m))^ell Gamma(ell)].

For a fixed finite deficit interval [a,b] chosen by the explicit rate margins
in the theorem,

 a_n^(m) ~ (4^n/m) sum_(a<=s_ell<=b) F(ell),
 p_n(m) ~ (sqrt(pi)n^(3/2)/m) sum_(a<=s_ell<=b) F(ell).

The leading integer-count cost is J_c(s)=s/2-c-c log(s/(2c)). The paper also
gives the exact adjacent-summand ratio, including the finer transition
beyond a leading-rate tie. No Gaussian approximation is extrapolated to
this lower scale.

Contents:
- integer_count_avoider_asymptotic.pdf: complete manuscript
- integer_count_avoider_asymptotic.tex: editable source
- build.sh: standard three-pass pdflatex build
- checks/: exact rational ratio checks, optional scalar diagnostics, and data
- SOURCES.md: source pin and inherited-input attribution
- validation.json, latex-build.log, SHA256SUMS: validation and hashes

Build with bash build.sh and a standard TeX installation containing Latin
Modern, geometry, amsmath/amssymb/amsthm, mathtools, microtype, booktabs,
hyperref, and xurl. The exact checker uses only the Python standard library.
Optional numerical diagnostics require NumPy and SciPy; no library is vendored.

The proof is ordinary mathematics, not formally verified or externally
refereed. It is uniform on each fixed compact positive c interval, with
no effective numerical threshold and no uniform assertion as c tends to
zero or infinity. The related Li full manuscript was not retrieved; overlap
beyond its public abstract is not excluded. Priority is source-relative.
