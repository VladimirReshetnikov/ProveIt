#!/usr/bin/env python3
"""Check immutable package-file hashes. Additional replay files are allowed."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PROVENANCE.json').read_text())
for item in manifest['files']:
 p=root/item['path']
 if not p.is_file(): raise RuntimeError('Missing file: '+item['path'])
 if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
  raise RuntimeError('Hash mismatch: '+item['path'])
print('All %d package files match recorded SHA-256 hashes.'%len(manifest['files']))
