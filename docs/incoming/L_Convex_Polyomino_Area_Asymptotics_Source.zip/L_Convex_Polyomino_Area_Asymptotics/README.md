# All Order Area Asymptotics for L Convex Polyominoes

The article proves the published leading area-counting conjecture for fixed L-convex polyominoes (OEIS A126764), extends the dominant coefficient expansion to every algebraic order, and derives exact-range and threshold inverse asymptotics.

## Main results

- Exact decomposition A(q)=1+M(q)h(q)^2+R(q), with explicit q-products, two effective multiplier formulas, and a positive exponentially smaller remainder on the real axis
- A complete real-axis singular expansion and a complete pointwise coefficient expansion, with the complex transfer justified by positivity, partition-factor minor-arc damping, and interpolation into the saddle window
- Explicit coefficient formulas and checks through the eighth correction
- All-order logarithmic inversion, corrected Lambert inversion, and eventual exact-range nearest-integer recovery from the leading Lambert model
- Threshold brackets for arbitrary values, with explicit distinction from exact-range inversion

The theorem does not claim a full exponentially small transseries, an effective finite inverse-rounding cutoff, or an exhaustive novelty search.

## Files

- `article.pdf`: the complete article
- `article.tex`, `transfer.tex`, `inverse.tex`, `diagnostics.tex`, `context.tex`, `references.tex`: editable LaTeX source
- `checks/multiplier/derive_multiplier.py`: exact rational real-axis multiplier expansion through t^8
- `checks/symbolic/check_inverse.py`: independent Gaussian-saddle and formal inverse-reversion checks
- `checks/exact/verify_exact.py`: exact recurrence coefficients through n=8000 and literal generating-function verification through n=400
- `checks/exact/check_diagnostics.py`: high-precision coefficient and inverse diagnostics
- `checks/exact/scan_lambert_rounding.py`: finite scan of the leading Lambert model
- `checks/exact/b126764_web.txt`: normalized published-data snapshot, n=0,...,2000
- `checks/exact/exact_coefficients_8000.json`: exact coefficients; terms beyond 2000 were generated, not independently checked against published data
- `PROVENANCE.json`: sources, file hashes, and verification scope
- `verify_package.py`: integrity verification

## Reproduce the mathematics

Requirements: Python 3 with SymPy and mpmath. From this directory run:

    ./run_checks.sh

The exact n8000 calculation takes on the order of tens of seconds on a typical modern machine; symbolic timing varies. No network access is needed. All assertions of correctness use explicit exception checks, so they remain active under `python -O`. Recorded ordinary and optimized-mode outputs are supplied. A longer scan can be rerun with:

    cd checks/exact
    python scan_lambert_rounding.py --max-n 8000

`run_checks.sh` intentionally writes replay results into separate JSON files. The symbolic check rewrites its deterministic formula JSON with the same content. The checks do not modify the article.

## Build the PDF

With a standard TeX Live installation, run `pdflatex article.tex` three times. The optional `build_local.sh` supports the bundled Linux TeX layout and creates a local format when the global TeX database is absent. No system-wide TeX installation is modified.

## Numerical interpretation

All 2001 published terms n=0,...,2000 agree exactly, and independent literal expansion agrees through n=400. Terms n=2001,...,8000 are newly generated. At n=8000, retaining corrections through z^-8 has relative prediction error approximately -2.51784e-12.

The leading Lambert model rounds correctly throughout the observed finite range n=556,...,8000. This is not a proof of a global cutoff at 556. The theorem proves eventual correct rounding without an effective onset. General real thresholds require the ceiling brackets in the article.

## Sources and status

The exact generating function is from Castiglione et al. (2007), DOI 10.1016/j.ejc.2006.06.020. The leading asymptotic conjecture is stated in Guttmann and Kotesovec (2023), arXiv:2109.09928v3, and OEIS A126764. The normalized snapshot hash and exact source URLs are recorded in PROVENANCE.json. The coefficient-transfer proof is included in full rather than inferred solely from a real-axis Tauberian heuristic.

This package is a mathematical research deliverable. It makes no claim of journal publication or exhaustive unpublished-literature coverage.

A separate unpublished 19-page manuscript, "L-convex polyominoes and a colored-partition comparison," prepared for Vladimir Reshetnikov with ChatGPT and dated 1 October 2026, already proves the leading equivalent and three coefficient corrections, with matching all-orders radial coefficients through t^8. It explicitly excludes an all-orders pointwise coefficient theorem. This article acknowledges that overlap and supplies the additional all-orders coefficient-transfer argument; it does not claim to be the first proof of the leading equivalent.
