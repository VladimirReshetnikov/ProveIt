# Sharp local stability for additive cubes

Research draft prepared for integration into `VladimirReshetnikov/ProveIt`, under:

`Combinatorics/Ramsey/Papers/sharp-cube-stability/`

## Main mathematical results

* A sharp subgroup-boundary inequality for every additive-cube dimension, with a complete equality classification.
* Exact local distance–deficit bounds in dimensions 2, 3, and every fixed dimension at least 4.
* A deletion-to-addition transition in the geometry of equality cases.
* An exact three-cube complement identity and a quotient-two-torsion formula.
* A sharp odd-order cubic asymptotic and nested-coset rigidity.

See `article.pdf` for all hypotheses, normalization conventions, proofs, and limitations. All cubes, including degenerate cubes, are counted. Distances are divided by the cardinality of the set, not by the subgroup or ambient cardinality.

## Status

The manuscript contains complete human-readable proofs, but is not independently refereed or proof-assistant checked. Historical novelty is **not certified**. The latest contents of both requested repositories could not be independently assessed from readable tool responses during drafting. The acquisition records are an inventory and error log, not an assertion that every recent result was reviewed or verified. No improved Szemerédi bound or resolution of a named longstanding conjecture is claimed.

## Files

* `article.tex`, `article.pdf`: manuscript source and compiled article.
* `verify.py`, `verification_results.json`: exact finite and symbolic checks and their actual execution results.
* `acquire_sources.py`, `source_audit.json`, `repository_snapshot.tex`, `audit/`: reproducible source-inventory attempt.
* `build.sh`: verification and LaTeX build.
* `formalization_plan.md`: proposed Lean dependency graph; not checked Lean code.
* `build_status.json`: generated compilation and artifact status.

## Build

Run `python3 verify.py`, then `pdflatex -interaction=nonstopmode -halt-on-error article.tex` twice. `./build.sh` combines these steps. Standard LaTeX packages used are listed in the preamble. The optional symbolic tests use SymPy; the finite tests use the Python standard library. Source acquisition requires network access and is not needed to rebuild the mathematics.

## Integration and review

Copy this directory into the path above. Review the proofs and existing literature before changing the provisional novelty status. Preserve the explicit thresholds and the distinction between exact universal profiles, equality at discrete feasible distances, and the still-open odd-order exact profile. Do not present the audit inventory as an exhaustive repository review.
