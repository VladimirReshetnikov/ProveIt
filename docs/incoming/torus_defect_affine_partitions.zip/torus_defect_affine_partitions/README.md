# Torus Defects and Sharp Affine Partition Laws

**Products of coordinate crosses, asymptotic rigidity, and simultaneous quadratic localization**  
Research manuscript prepared for the ProveIt project — October 7, 2026.

## Main results

Let `C_{s,q}` be the union of the `s` coordinate lines in `F_q^s`, and let
`P_{s,m}(q)` be the minimum number of nonempty, pairwise disjoint `F_q`-affine
subspaces partitioning `C_{s,q}^m`. All main theorems assume `q > 2`.
For fixed `s >= 2` and `m = r*s + ell`, `0 <= ell < s`, the manuscript proves

```text
P_{s,m}(q) = s^(m-1) * (s-ell) * q^(m-r) + O_{s,m}(q^(m-r-1)).
```

For ordinary two-arm crosses this is

```text
P_{2,m}(q) = 4^floor(m/2) * q^ceil(m/2) + O_m(q^(ceil(m/2)-1)).
```

It also proves an exact nonnegative defect identity, the optimal two-moment
linear-programming relaxation, a classification and enumeration of
torus-saturating flats, quantitative stability, and the regularized law

```text
rho_s(q) = lim_{m -> infinity} P_{s,m}(q)^(1/m)
         = s * q^(1-1/s) * (1 + O_s(log(q)/q)).
```

The two limit regimes are treated separately. For two arms the new bounds give
`rho_2(q) ~ 2*sqrt(q)`. For the simultaneous map `(x_i,y_i) -> (x_i*y_i)`,
the regularized full-map cost is `(q-1)^2 + rho_2(q)`.

## What remains open

The package does **not** assert an exact three-block answer. It proves

```text
4*q^2 - 5*q + 2 <= P_{2,3}(q) <= 4*q^2 - 3*q.
```

The exact fixed-field regularized rate, second-order coefficients, and global
edit-distance rigidity remain open here. No new integer Szemerédi bound is
claimed. The results concern exact whole-field affine cells, not a
length-preserving partition of integer progressions.

## Files

- `article.tex`, `article.pdf`: self-contained manuscript with full proofs,
  targeted repository review, nine further research questions, and references.
- `verify.py`, `verification_results.json`: standard-library-only exact checks.
- `theorem_status.json`: proof ledger, dependencies, and unresolved questions.
- `source_manifest.json`: source snapshots and provenance boundaries.
- `INTEGRATION.md`: proposed placement and formalization guidance.
- `Makefile`: verification and LaTeX build commands.
- `SHA256SUMS`: hashes of the delivered files other than itself.

## Reproduce

Requirements: Python 3.10+ and a standard TeX Live installation with `latexmk`
or `pdflatex`. The Python script has no third-party dependencies. Do not run
Python with `-O`, because the checker deliberately uses assertions.

```bash
python3 verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Or use `make all`. Without `latexmk`, run `pdflatex` three times with the same
`-interaction=nonstopmode -halt-on-error` options.

The delivered run passed checks on **7,713 distinct affine flats**, including
all flats in `F_4^3`; **2,535** dimension-weight cases; **540** finite-bound
parameter cases; **14** support matchings; and **9** actual point-set partitions.
The affine-flat checks include the capacity bound, equality classification,
quantitative gap, and Gaussian/Stirling enumeration formulas. These are finite
corroborations, not an exhaustive optimization over partitions.

## Status and provenance

The mathematical proofs are ordinary manuscript proofs. There is **no Lean
verification claim**, no new axiom, and no numerical-solver dependency.
The proposed contributions are new relative to the preceding project article
*Sharp Affine Localization for Quadratic Phases*. Historical priority has not
been established exhaustively, and the paper has not undergone peer review.

The targeted review distinguishes the recent OpenAI repository's announced
global results from independently checked inputs. None of those global claims
is a hypothesis of this paper. The ProveIt simultaneous-localization module was
read at a pinned revision but was not rebuilt as part of this package.

Neither GitHub repository was modified. The ZIP is ready for review and later
integration; see `INTEGRATION.md`.
