DEFINABLE SURREAL NUMBERS AND OMNIFIC INTEGERS
Real Parameters, Countable Closure, and Strong Symmetries
Research article prepared for Vladimir Reshetnikov
4 October 2026

CONTENTS

  definable_surreals.tex   Self-contained LaTeX source, with bibliography
  definable_surreals.pdf   Compiled article
  build.sh                Build using latexmk, or pdflatex as a fallback
  finite_code_check.py    Exact rational checks of the finite coding formulas
  README.txt              This guide

BUILD

Use a standard TeX Live or MiKTeX installation with pdfLaTeX. The source
uses standard packages: geometry, fontenc, inputenc, lmodern, microtype,
amsmath, amssymb, amsthm, mathtools, mathrsfs, booktabs, longtable, array,
enumitem, xcolor, fancyhdr, hyperref, and cleveref. No external images,
bibliography database, shell escape, or network access is required.

From this directory:

  sh build.sh

Or run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error definable_surreals.tex

If latexmk is unavailable, run pdflatex three times to resolve the
table of contents, cross-references, and citations. The included build
script writes auxiliary files in build/ and places the PDF next to the
source.

OPTIONAL FINITE CHECK

  python3 finite_code_check.py

This uses only the Python standard library and exact Fraction arithmetic.
It checks the rational-slot inequalities and inverse formula for an
explicit finite range of natural-number inputs, including large inputs.
It does not represent arbitrary ordinals or surreal normal forms. It is
not a proof of the theorems; the general arguments appear in the article.

RESEARCH STATUS

The article proves a real-parameter inclusion classification and a Choice
criterion for capture by one real; an exact equivalence between countable
ordinal coding, Hahn summation, and countable interpolation; explicit
Cohen, Namba, and Prikry examples; and the common fixed field of strong
automorphisms fixing all reals and ordinals, with or without omnific
preservation. It gives a proper-class algebraically independent family
of ordinal-definable omnific integers in a single bounded interval.

The strong stabilizer result answers the strong version of the question
labelled sse:sr:q:stabilizers in the repository snapshot below. The full
nonstrong stabilizer and the full intrinsic definable-closure problem
remain open here. Claims of extension are relative to the inspected
snapshot; no claim of literature-wide priority is made.

These are ordinary mathematical proofs. No Lean or Rocq formalization of
the new results is claimed. The article identifies the classical inputs,
the exact forcing variant used for Namba preservation, the limits of the
results, and a proposed sequence of formalization tasks.

REPOSITORY SNAPSHOT

  https://github.com/VladimirReshetnikov/ProveIt
  Commit: 3c25fbb5515748040decb853139ed39543885b90
  Observed: 4 October 2026

The article cites immutable links to the relevant research documents and
credits the predecessor's results and techniques. No repository files
were changed. No third-party papers are included in this package.

