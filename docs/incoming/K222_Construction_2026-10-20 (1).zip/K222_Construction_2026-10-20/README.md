# Two 222-state candidates for the consistency of ZFC

This packet constructs a **222-working-state, binary, single-tape Turing machine**, strictly improving the 223-state target in the supplied ProveIt baseline. A second, distinct 222-state construction is included as an alternative.

The primary machine combines the incoming seed-request K theory with the incoming merged equality rule G. Its source has **4,744 primitive instruction occurrences and 208 distinct subtrees**. A deterministic compiler first gives a new 224-state parent; two independently proved state identifications reduce it to 222.

The complete mathematical report, including the full canonical transition table and further research questions, is `report/main.pdf`. Editable LaTeX sources are in the same directory.

## Exact primary machine

The preferred file is `portable/machine/candidate222.tm`.

| Property | Value |
| --- | --- |
| Working states | 222, numbered 0 through 221 |
| Initial state | 0 |
| Separate terminal state | 222, excluded from the working-state count |
| Alphabet | 0 and 1 |
| Tape | One two-way infinite tape, initially all zero |
| Initial head position | 0 |
| Movements | One cell left or right at every transition |
| Transition rows | 444, exactly two per working state |
| Canonical dispatcher | 22 |

Each transition is `state read write direction next_state`. The first line declares `#! start 0`.

Canonical table SHA-256:

```text
3bcf4678c9c576ae99a108c32038f035b42204289267d05a34ba2b37b32b6476
```

Exact source SHA-256:

```text
cc1fbb3a16dd446af9c7cdb678317d31060082e6794b9c7074ce02b46584a75e
```

The table is also supplied in historical K labels, legacy runtime-checker labels, and CSV, with complete checked maps. All 222 declared states are reachable in the directed transition graph. That graph statement does not assert that every state occurs in the actual blank-tape execution.

## The mathematical construction

The seed-request presentation of K repeats the witness-request formula at the root and inside its closure clause, creating useful repeated compiler input. Independently, the merged equality rule replaces the two previous obligations

```text
Eq(c,a) -> (Eq(c,b) -> Eq(a,b))
Eq(a,b) -> All(kappa(a,b), Eq(a,b))
```

by

```text
Eq(c,a) -> (Eq(c,b) -> All(kappa(a,b), Eq(a,b)))
```

where `kappa(a,b) = 4*P(a,b)+1` is the native membership-code builder. The new rule recovers the literal old equality row and helper through closed finite derivations. With the exact reordered seed bundle, the two native calculi prove **the same formula codes**, including the distinguished refutation code 1.

The source composition changes only the equality row and theory-bundle emission, followed by one certified closed reassociation. The latter preserves every primitive and guarded control-flow edge and repairs a seven-zero address to the supported six-zero layout. The construction is deterministic and does not require rerunning an optimization search.

The resulting decoder has 173 states for 185 interior source nodes, retaining twelve contextual aliases. The remaining engine and initialization states number 49:

```text
49 + 185 - 12 = 222.
```

The two exact folds are simple. In the 224-state parent, K159 has a zero immediately right of the head, and K118 scans zero. K118's impossible old one branch can therefore implement K185's one branch. After merging K185 into K118, K174 and K159 have identical rows and can merge. Two independent checkers establish these simulations for **every initial binary tape** from start state 0.

## Verification and proof status

| Verification layer | Result |
| --- | --- |
| Uniform finite logic certificate | 33 closed roots, 298 proof nodes, 272 formulas; separately parsed and checked |
| Exact all-natural source/emitter binding | Nine macro contracts, symbolic formula identities, full primitive-word comparison, two complete guarded-CFG resolvers |
| Source metrics | 4,744 occurrences, 208 subtrees, maximum depth 36, maximum zero run 6 |
| All-tape state reductions | Two independently checked one-step folds |
| Negative controls | Three incorrect fold certificates rejected |
| Exact blank startup | 409,835 transitions; sparse and independent dense representations agree |
| Startup endpoint | Canonical state 22, head −5, 351 one-cells at the recorded positions, zero elsewhere |
| Full unbounded binary runtime | 6,167 guarded cases, 1,488,390 symbolic rule applications, all 444 rows |
| Minimum concrete instruction duration | 13 transitions |
| Clean integrated primary replay | Passed; regenerated case summaries equal the retained summaries byte for byte |

The runtime proofs quantify over arbitrary natural primary-register values, gap and first spare, an arbitrary finite remaining spare list, and the full zero exterior. They are symbolic induction arguments, not bounded tests over register values.

Composing the identified inherited calibration with the new transformations gives the ordinary mathematical proof, formalizable in ZFC, of

```text
Nonhalt(primary222, blank) <-> Con(ZFC).
```

**No new end-to-end Rocq or Lean theorem for these 222-state bytes has been compiled.** The packet contains an ordinary mathematical argument and executable exact/unbounded certificates, with explicitly pinned inherited logical and formal material. Its validation receipts distinguish fresh new checks, retained evidence, and optional predecessor replays. Runtime checks alone do not establish the theory calibration. No absolute consistency, unconditional non-halting, or minimality claim is made.

The code-zero/code-one cases, coincident active names, restricted equality interpretation, post-translation private-code selection, and nonzero proof-enumeration cutoff are addressed in the report and theory notes.

## Second 222-state candidate

`portable/alternative/results/candidate222.tm` combines the published conditional-K223 source with G absorption. It has a different source and table but the same machine conventions and 222-state count.

Canonical SHA-256:

```text
60e21a040e58e2a2840b0f3d58ad3ee0e6ef4d0d5cdf1372d5a69355f1198ca1
```

Its source has 4,581 occurrences, 209 subtrees, and thirteen contextual aliases. Its full fresh runtime passed **5,956 guarded cases, 1,443,614 symbolic rule applications, and all 444 rows**, with the same exact 409,835-step startup. Its additional inherited premise is the conditional-K interpretation; that premise is explicitly identified. The primary seed version uses the existing seed-to-K0 route directly.

## Offline reproduction

Python 3.10 or newer and its standard library suffice. Keep assertions enabled. Choose an initially empty output directory outside this packet.

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k222-quick

python3 -B portable/reproduce.py \
  --full --output-dir /tmp/k222-full

python3 -B portable/reproduce.py \
  --full --full-baseline --full-alternative \
  --output-dir /tmp/k222-all
```

The default reconstructs both candidates and checks the primary source, emitter, schematic logic, folds, startup, and negative controls, then audits retained runtime evidence. `--full` freshly derives all primary runtime cases. `--baseline` replays the unchanged K224 package's quick checks; `--full-baseline` also rederives its inherited runtimes. `--full-alternative` derives the alternative's runtime anew. `--skip-alternative` limits the driver to the primary construction.

Successful primary runs print `QUICK_K222_REPLAY_PASS` or `FULL_K222_REPLAY_PASS`. Each phase has its own log. The supplied packet is not modified. No replay mode downloads files or builds a new proof-assistant endpoint.

To regenerate the report:

```sh
python3 -B report/generate_table.py
cd report
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

## Provenance and repository integration

The fixed baseline is ProveIt commit `6ab3e41e4dcddfbd7f843bdf4be48ae5c7ba2430`. The underlying K230 development is pinned to `3142e4dd980f0be12f4abb636c4ae2528afc17eb`. `PROVENANCE.json` identifies the exact incoming archives and their hashes. The unchanged full K224 predecessor ZIP, its nested dependencies, and its notices remain included.

The new contribution is the concrete composition and its exact source/table validation. The seed theory and G rule are attributed to their existing developments. See `NOTICE.md` and the retained notices for the detailed lineage and license boundaries.

A suggested repository destination is `Computability/BusyBeaver/Research/ZFC/candidate-seed-g222/`; the report may enter the existing incoming/reports workflow. Keep the source, tables, proof notes, validation records, and reproduction entry point together. This packet is supplied for incorporation; it has not been pushed to the repository.

The report's further-research section identifies a concrete next target: retain thirteen decoder aliases in a 208-subtree source. That would suggest 221 states at the same engine cost, but requires a new literal table and complete verification.
