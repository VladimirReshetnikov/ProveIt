# Arithmetic Spectral Cancellation in Binary DFAO Reversal

**Exact minimal recurrences, a nineteen-output exception, and effective generating functions**

Research prepared for Vladimir Reshetnikov, 30 September 2026.

## Read first

`article.pdf` is the compiled 22-page article. `article.tex` is its standalone
LaTeX source, with an internal bibliography and all tables included inline.
The package continues Question 44.15 of ProveIt's binary-DFAO reversal report,
at commit `0744012ba29db0e345c44be953c6de3e000439e6`.

## Main results

The article proves exact integer factor-selection formulas for the minimal
recurrences of the explicit witness deficit, both at unit step and on each
residue modulo four. It gives a genuine cancellation at nineteen outputs:
product 12 disappears from the odd residues, reducing their orders from 60
to 59, but its four unit-step modes all remain. A polynomial argument proves
that this is the unique odd-moment cancellation for product 12 at every
admissible output count, and that product 12 always retains its full unit-step
spectrum. The three-output full recurrence has minimal order 9, improving an
order-12 annihilator in the repository. Parity-coherent classes cannot cancel;
all classes with product not divisible by four are covered. For each fixed
product, all exceptions form an effectively computable finite set. Recurrence
orders are k^(2-o(1)) but o(k^2), with Ford's theorem used for the latter bound.

Explicit rational tail numerators are provided, as is a terminating theoretical
algorithm for the unknown finite optimum correction. Eight further research
questions distinguish the remaining issues.

## Dependency and verification status

The mathematical proofs for the **explicit witness sequence** are self-contained,
except that the improved asymptotic upper bound cites Ford's multiplication-table
theorem. Transfer to the **actual reversal optimum** assumes the repository's
stated eventual-optimality theorem, including its bound N(k) <= 3 k^4 when used.
That repository theorem was not independently reproved or formally verified here.

This is an AI-assisted, unrefereed manuscript. No Lean/Rocq formalization is
included or claimed. The finite checks are reproducible arithmetic audits;
they do not prove the universal statements by enumeration. No global
classification of all cancellation pairs or full two-parameter optimum is claimed.
The expensive finite-prefix automaton enumeration in the article was **not run**
and is **not implemented** by the scripts in this package.

## Reproduce the computations

Python 3.10 or newer, standard library only:

```sh
python code/spectral.py 19
python code/spectral.py 3 --expanded
python code/verify.py
```

The last command regenerates `data/` using the default scan through k=200 and
recurrence reconstruction through k=30. Optional bounds:

```sh
python code/verify.py --scan 200 --bm-max 30
```

The run included here used Python 3.13.5. It passed 27 literal-coloring checks,
1,053 signed-versus-positive coloring identities, 280 modular recurrence
reconstructions, eight exact tail-numerator checks, and 282 product-12 polynomial
identities, plus the complete moment/support scan through k=200. Only T(19,12)
vanished among the three moments in that finite scan; no off-diagonal product
lost a unit-step mode. These last statements are finite observations, not
assertions about larger output counts.

Use `spectral.tail_numerator(k, start)` to generate a full witness-tail numerator
and its reduced denominator. All integer polynomial lists are in **ascending
coefficient order**. The scripts do not compute unknown true optimum values.

## Build the article

A normal TeX Live installation with pdfLaTeX and the packages named in the
preamble is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
until cross-references stabilize, normally three passes. `make pdf` and
`make check` are convenience targets. There are no external figures or bibliography
files. `data/orders.tex` records the generated numerical table; the corresponding
snapshot is already inline in `article.tex`.

## Files

- `article.tex`, `article.pdf`: source and compiled article.
- `code/spectral.py`: exact moments, minimal factors, positive coloring counts,
  witness values, and rational tail numerators.
- `code/verify.py`: independent counting/reconstruction audits and data generation.
- `data/audit.json`: actual run summary and the cancellation certificate.
- `data/spectra.json`: moments and factors for k=3,...,30.
- `data/tail_generating_functions.json`: explicit tails for k=3,...,10, starting at 7.
- `data/product12_polynomials.json`: exact finite values used in the all-integer proof.
- `data/orders.tex`: generated order table.
- `notes/SOURCES.md`: source pin, inspected scope, literature and novelty audit.
- `notes/PROOF_STATUS.md`: theorem-by-theorem dependencies and limits.
- `notes/BUILD_QA.md`: compilation and visual inspection record.
- `Makefile`: build/check convenience targets.

No repository files were modified by this work.
