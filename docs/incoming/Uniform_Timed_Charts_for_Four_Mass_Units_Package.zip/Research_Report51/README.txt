REPORT 51  Uniform timed charts for four mass units
4 October 2026

RESULT AND SCOPE
The manuscript proves the conditional uniform extension of the pinned
source-17 scattering mechanism and source-18 fixed-input charts. One finite
family works for every ordered initial coordinate tuple of mass at most four
for a fixed one-dimensional conservative rule with at most one unit label.
It uses at most two free evolution parameters on finite Presburger input cells;
a literal affine lift adds at most three uniquely input-determined gap quotients.
Stationary-frame positions are affine and time has joint total degree at most two.
The copied-input quartic has fixed finite natural-witness arity, with copies,
quotients, selectors and slacks all counted; its bound is not two or five.
No general rule-to-chart compiler implementation, formal proof assistant result,
published priority, or generic real/rational-witness exactness is claimed.

A credited consequence of Report49 shows original-frame untimed reachability
can be non-Presburger from one fixed four-particle input, even for a globally
reversible binary rule. Its stationary-frame orbit is explicitly Presburger.
The inherited binary lower-particle theorem makes four sharp for this fixed-
input failure, without changing the conditional scope of the uniform theorem.

CONTENTS
  report51.pdf                      final PDF
  manuscript/report51.tex           editable standalone TeX
  frozen/science/                   byte-preserved proof note and scoped review
  frozen/audit/                     separate adversarial audit and fresh checker
  frozen/manuscript-audit/           initial manuscript algebra and visual audit
  frozen/manuscript-audit-corollary/  final 21-page manuscript audit addendum
  frozen/report49/                   inert credited source for frame obstruction
  frozen/frame-obstruction/          separate deduction and literal-row check
  frozen/science/pinned/            inherited source and scope note, inert only
  evidence/                        release verification records
  code/replay.py                   safe isolated arithmetic replay
  code/build_pdf.py                isolated deterministic manuscript build
  code/verify_release.py           complete release hash verification
  code/archive_release.py          deterministic ZIP packaging
  MANIFEST.sha256                  every shipped file except the manifest itself

All frozen scientific files are retained exactly as received. The inherited
combined article is evidence, not an executed program or a build target.
Only the inspected checkers newly authored for these proof/audit packets run.
They use finite arithmetic fixtures, not a general CA compiler. The frame
obstruction checker implements the six literal guarded rows independently.
The original checkers use Python assertions. The replay runner invokes ordinary
Python with -I (isolated mode), never -O, and ignores PYTHONOPTIMIZE in the child.

PREREQUISITES
Python 3.12 or compatible Python 3 with SymPy available to that interpreter.
Installed pdfTeX/LaTeX plus article, fontenc, lmodern, microtype, geometry,
amsmath, amssymb, amsthm, mathtools, booktabs, array, enumitem, hyperref, xurl,
fancyhdr. Poppler is needed only for optional visual rerendering.
No downloads, package installations or network access are performed by helpers.
The replay covers all five shipped fresh checkers. The original 19-page audit
is preserved for its algebra checks; its addendum pins and reviews all 21 pages
of the final manuscript, including the new original-frame obstruction.
The recorded toolchain appears in evidence/toolchain.json.

VERIFY
From the extracted Research_Report51 directory:
  python3 -B code/verify_release.py
This checks the complete release manifest, both original frozen manifests and
all their entries, the science SHA256SUMS, both manuscript-audit SHA256SUMS, the
frame-obstruction manifest, and inert Report49 source. Hashes establish correspondence
to the inspected bytes, not authorship or a digital signature.

REPLAY THE ARITHMETIC
Choose a new or empty directory OUTSIDE the extracted release:
  python3 -B code/replay.py --output /tmp/report51-replay
The runner verifies frozen pins and copies only the inspected checker sources
to scratch. It
executes there, compares their deterministic JSON receipts byte-for-byte, then
rechecks the frozen pins. Output, logs and receipts remain in scratch. The run
should take tens of seconds on an ordinary machine. It has a 600-second timeout
per checker. Missing SymPy causes a clear checker error rather than installation.
To verify only the scientific pins:
  python3 -B code/replay.py --verify-only

REBUILD THE PDF
Choose another new or empty external directory:
  python3 -B code/build_pdf.py --output /tmp/report51-pdf
The resulting file is /tmp/report51-pdf/manuscript/report51.pdf. Only this TeX
manuscript is copied. The helper uses installed TeX with shell escape disabled,
fixed SOURCE_DATE_EPOCH=1791072000, omitted PDF dates and fixed trailer behavior.
It can create a missing pdfLaTeX format/font map in its own fresh cache using
installed TeX files; it never installs packages or executes the inherited article.
Under the recorded toolchain the rebuilt PDF is byte-identical. Across different
TeX/font versions, layout and byte identity may differ. Check the build receipt.
To rerender visually, run pdftoppm -png on the rebuilt PDF into a scratch directory.

RECREATE THE ZIP
Choose a nonexistent external file in an existing directory:
  python3 -B code/archive_release.py --output /tmp/Research_Report51.zip
The helper first verifies the complete release, then sorts members, fixes their
ZIP timestamps to 4 October 2026 at midnight and their permissions to read-only,
and uses DEFLATE level 9. With the recorded zlib, repeated archives are identical.
It refuses to overwrite an existing ZIP or to write inside the release. Archive
members have a single Research_Report51 top-level directory.

SAFETY AND PRESERVATION
All output helpers reject symlink targets. Replay and PDF builds require an
external new/empty scratch directory. No helper modifies frozen scientific data,
executes upstream source code, or runs saved schedules. Running code with -B also
prevents helper bytecode caches; verification ignores interpreter __pycache__
files if a caller omits -B. The release files themselves need not be writable.
