# The Third Newton Inequality at Rank Six

This package proves `9 p_3^2 >= 16 p_2 p_4` for every bipartite graph of matching rank six, with unit activities on the entire left shore and arbitrary positive right activities. For a genuine 3+3 minimum cover, it proves the stronger Lorentzian property of the selected-right quartic

`15 s^4 + 10 p_1 s^3 + 6 p_2 s^2 + 3 p_3 s + p_4`.

The article also proves a universal quadratic graph-marginal inequality. Its appendices explain the obstruction to extending that result to arbitrary regular-minor matrices and a partial reduction for the fourth scalar Newton gap. That fourth gap remains open. No proof-assistant certification or exhaustive novelty claim is made.

## Files

- `article.pdf`: complete 17-page report
- `article.tex` and seven included TeX sections: complete manuscript
- `code/`: exact reconstruction programs and computational records
- `prerequisites/`: unchanged earlier reports used in the proof; the second-gap archive includes the full small-cover proof
- `PORTABILITY.json`: the four limited portability/hardening changes to copied programs
- `SHA256.json`: hashes of every packaged file other than this hash manifest
- `verify.py`: top-level verification entry point

## Exact verification

Use Python 3.10 or later and SymPy. The complete large-array reconstruction also uses a C++17 compiler and GMP (`gmpxx` and `gmp`). All verification is exact integer or rational arithmetic. No optimization package, floating-point tolerance, downloaded executable, or network access is needed.

Run these commands in a writable extracted copy. First run `python check_integrity.py` to check the release file hashes. Some mathematical checkers refresh result JSON files with current runtimes, so the release integrity check should precede them.

```
python -O verify.py --mode receipts
python -O verify.py --mode certificates
python -O verify.py --mode full
```

- `receipts` checks the complete saved reconstruction records, their mathematical counts, all corresponding coefficient hashes, and the immutable inputs. It does not regenerate the large arrays.
- `certificates` (the default) additionally reconstructs all endpoint/matrix identities, every reduced Rayleigh/SOS certificate, the two nested profiles, the three symmetric cases, and all five final Bernstein regions. It then checks the full saved large-array records. Expect several minutes; symbolic matrix stages can take longer on a slower machine.
- `full` additionally rebuilds both complete large coefficient arrays from the independently written support and polynomial routines. It recompiles the supplied GMP helper. This can take substantially longer and use several gigabytes of memory. It does not skip a profile because a saved result exists.

The full exact arrays were separately reconstructed before release: the mixed-root case has 89 profiles, 4,539 translated polynomials, and 43,344,919 nonzero nonnegative coefficient entries. The ordinary two-core case has 64 profiles, 960 translated polynomials, and 43,891,306 such entries. Four further two-core profiles use 60 exact Rayleigh decompositions. The final nested profile has 365,114 Bernstein slots, of which 363,633 are positive and 1,481 are zero.

The reduced certificates are explicit equalities. Their checkers reconstruct the target polynomial, check every multiplier's sign, and verify equality exactly. The large arrays are represented by deterministic source generators and complete per-polynomial count/minimum/SHA-256 records; rerunning the generator regenerates the coefficients and compares all records. A hash comparison alone is not substituted for the original sign verification.

For parallel full replay, the independent BR program accepts a root mask `1`, `3`, or `7`; the BB reconstruction accepts `shard parts`. Run finalizers only after every shard is complete. The top-level full mode runs sequentially.

Additional standalone checks, not needed after the exact inverse identities, reproduce the BB determinant identities by 36,060 unisolvent integer evaluations:

```
python -O code/rank6_quartic_BB_audit/check_determinants.py
```

Two historical reduction drafts are preserved byte-for-byte because they belong to the immutable input snapshots. Their old “pending” status is superseded by the complete article and the final reconstruction records; they are not the current theorem statement.

The primary discovery generators and a second, slower final-region implementation are also included for comparison. Only the exact replay is a proof dependency; numerical searches and optimization logs are omitted.

## Building the PDF

On a conventional TeX installation, run `pdflatex article.tex` twice. `build_local.sh` supplies explicit TeX/font paths for the environment used to produce the report. It writes intermediate files to `build/` and copies the finished PDF to `article.pdf`.

## Mathematical scope

The retained-right quartic statement is asserted for genuine 3+3 covers. The scalar third-gap conclusion for all rank-six graphs uses the earlier all-field small-cover theorem for the other cover splits. Scalar ultra-log-concavity does not by itself imply a retained-variable Lorentzian statement in every cover orientation. The quintic counterexample in the article rules out the most direct stronger truncation route; it is not a counterexample to the remaining scalar fourth gap.
