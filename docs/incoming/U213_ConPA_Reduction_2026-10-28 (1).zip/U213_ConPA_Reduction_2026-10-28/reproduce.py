#!/usr/bin/env python3
"""Offline reconstruction and verification of the exact U213 release.

Python 3.10+, standard library only. --full rederives all 5,109 symbolic
primitive cases. No search, solver, network, or proof assistant is required.
The complete Con(PA) calibration is a mathematical proof, not a new kernel
certificate. See paper/report.pdf for the exact inherited dependencies.
"""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def command(script, args, work, label):
    print(label + ' ...', flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONOPTIMIZE', None)
    p = subprocess.run([sys.executable, '-B', str(script), *map(str, args)],
                       cwd=work, env=env, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if p.returncode:
        print(p.stdout, end='')
        raise RuntimeError(label + ' failed')
    print(label + ': PASS', flush=True)


def manifest():
    seen = set()
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        p = PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts and '\\' not in name,
             'unsafe manifest path')
        need(name not in seen, 'duplicate manifest member')
        seen.add(name)
        need(sha(ROOT / name) == digest, 'digest mismatch: ' + name)
    required = {'paper/report.pdf', 'paper/report.tex', 'machine/u213.tm',
                'machine/u213.native.tm', 'machine/sites.json', 'reproduce.py',
                'inputs/U214_ConPA_Reduction_2026-10-28.zip'}
    need(required <= seen, 'principal files missing from manifest')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
              if p.is_file() and p.name != 'SHA256SUMS'
              and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    need(seen <= actual, 'manifest includes nonexistent files')
    return len(seen)


def safe_extract(archive, destination):
    with zipfile.ZipFile(archive) as z:
        seen = set()
        for entry in z.infolist():
            p = PurePosixPath(entry.filename)
            need(not p.is_absolute() and '..' not in p.parts
                 and '\\' not in entry.filename, 'unsafe ZIP member')
            need(entry.filename not in seen, 'duplicate ZIP member')
            need(not stat.S_ISLNK((entry.external_attr >> 16) & 0xffff),
                 'ZIP symlink not allowed')
            seen.add(entry.filename)
            target = destination.joinpath(*p.parts)
            if entry.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(entry) as source, target.open('wb') as dest:
                    while data := source.read(1024 * 1024):
                        dest.write(data)


def runtime_audit(table, source, summary, cases):
    need(summary['status'] == 'UNIVERSAL_MATHEMATICAL_PASS'
         and summary['failures'] == [], 'runtime not proved')
    need(summary['working_states'] == 213 and summary['site_count'] == 3928,
         'wrong runtime census')
    need(summary['table_sha256'] == sha(table)
         and summary['sites_sha256'] == sha(source), 'wrong runtime binding')
    need(summary['checker_sha256'] == sha(ROOT / 'code/runtime/symbolic_runtime.py')
         and summary['helper_sha256'] == sha(ROOT / 'code/runtime/independent_runtime.py'),
         'runtime checker bytes differ')
    need(summary['expected_cases'] == summary['proved_cases'] == len(cases) == 5109,
         'incomplete runtime coverage')
    sites = load(source)
    wanted = {(i, b) for i, row in enumerate(sites)
              for b in ((False, True) if row[1] == 'CD' else (False,))}
    actual = {(c['site_index'], c['positive']) for c in cases}
    need(actual == wanted and len(actual) == len(cases),
         'missing or duplicated primitive case')
    for case in cases:
        need(case['duration'][0] > 0 and all(x >= 0 for x in case['duration']),
             'nonpositive symbolic duration')
    need(len(summary['blocks']) == 4, 'missing list induction schema')
    need(summary['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED',
         'unacceptable startup')


def main():
    need(__debug__ and not sys.flags.optimize,
         'disable Python -O and PYTHONOPTIMIZE')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    start = time.monotonic()
    files = manifest()
    with tempfile.TemporaryDirectory(prefix='u213-replay-') as directory:
        temp = Path(directory)
        out = temp / 'machine'
        command(ROOT / 'code/build_u213.py', [
            '--baseline-machine', ROOT / 'inputs/u214.native.tm',
            '--baseline-source', ROOT / 'inputs/u214_sites.json',
            '--output', out], temp, 'Exact six-rotation construction')
        for name in ['u213.tm', 'u213.native.tm', 'sites.json',
                     'rotated214.native.tm', 'state_map.json', 'construction.json']:
            need((out / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
                 'reconstruction differs: ' + name)
        command(ROOT / 'code/check_dense.py', [out, '--out', temp / 'dense.json'],
                temp, 'All 426 dense/native transition equations')
        need(load(temp / 'dense.json') == load(ROOT / 'evidence/dense_independent.json'),
             'dense receipt differs')
        command(ROOT / 'code/check_fold.py', [
            out / 'rotated214.native.tm', out / 'u213.native.tm',
            '--out', temp / 'fold.json'], temp,
            '1,704 opaque-exterior local frames and five negative controls')
        need(load(temp / 'fold.json') == load(ROOT / 'evidence/fold_independent.json'),
             'fold receipt differs')
        command(ROOT / 'code/review_source.py', [
            '--baseline-machine', ROOT / 'inputs/u214.native.tm',
            '--baseline-source', ROOT / 'inputs/u214_sites.json',
            '--rotations', ROOT / 'inputs/rotations.json',
            '--rotated', out / 'rotated214.native.tm',
            '--candidate', out / 'u213.native.tm', '--sites', out / 'sites.json',
            '--output', temp / 'source.json'], temp,
            'Independent source reconstruction, two CFG resolvers, and controls')
        need(load(temp / 'source.json') == load(ROOT / 'evidence/source_independent.json'),
             'independent source receipt differs')
        command(ROOT / 'code/check_rotations.py', [
            '--oldsites', ROOT / 'inputs/u214_sites.json',
            '--oldtm', ROOT / 'inputs/u214.native.tm',
            '--recipe', ROOT / 'inputs/rotations.json',
            '--newsites', out / 'sites.json',
            '--newtm', out / 'rotated214.native.tm',
            '--out', temp / 'rotations.json'], temp,
            'Independent direct-ancestry closure proof of all 18 factors')
        need(load(temp / 'rotations.json') == load(ROOT / 'evidence/rotations_independent.json'),
             'direct-ancestry receipt differs')
        rejected = ROOT / 'research/rejected_four_rotations'
        command(ROOT / 'code/check_seven_zero_counterexample.py', [
            '--rejected-table', rejected / 'fold0.native.tm',
            '--rejected-sites', rejected / 'sites.json',
            '--accepted-table', out / 'u213.native.tm',
            '--accepted-sites', out / 'sites.json',
            '--out', temp / 'seven-zero.json'], temp,
            'Rejected four-rotation counterexample and accepted positive control')
        need(load(temp / 'seven-zero.json') == load(rejected / 'counterexample.json'),
             'seven-zero counterexample differs')
        for name in ['startup.json', 'runtime_cases.json']:
            (temp / name).write_bytes(gzip.decompress(
                (ROOT / 'evidence' / (name + '.gz')).read_bytes()))
        saved = load(ROOT / 'evidence/runtime.json')
        cases = load(temp / 'runtime_cases.json')
        runtime_audit(out / 'u213.native.tm', out / 'sites.json', saved, cases)
        command(ROOT / 'code/review_native_bootstrap.py', [
            '--table', out / 'u213.native.tm', '--sites', out / 'sites.json',
            '--startup', temp / 'startup.json', '--out', temp / 'startup-review.json'],
            temp, 'Independent complete 95,726-step blank startup')
        boot = load(temp / 'startup-review.json')
        need(boot == load(ROOT / 'evidence/startup_independent.json'),
             'startup receipt differs')
        need(boot['startup_steps'] == 95726 and boot['startup_gap'] == 1
             and boot['startup_registers'] == [4, 0, 0, 0, 0, 0, 0, 0, 0]
             and boot['spare_count'] == 40, 'wrong seed')
        if args.full:
            fresh = temp / 'fresh'
            command(ROOT / 'code/validate_native.py', [
                out / 'u213.native.tm', out / 'sites.json', fresh], temp,
                'Rederive all 5,109 arbitrary-register symbolic cases')
            actual = load(fresh / 'runtime.json')
            fresh_cases = load(fresh / 'runtime_cases.json')
            runtime_audit(out / 'u213.native.tm', out / 'sites.json', actual, fresh_cases)
            need(actual['blocks'] == saved['blocks'], 'induction schemas differ')
            need(fresh_cases == cases, 'symbolic derivation records differ')
            need((fresh / 'startup.json').read_bytes() == (temp / 'startup.json').read_bytes(),
                 'fresh blank startup differs')
        parent_zip = ROOT / 'inputs/U214_ConPA_Reduction_2026-10-28.zip'
        safe_extract(parent_zip, temp / 'parent')
        parent = temp / 'parent/U214_ConPA_Reduction_2026-10-28'
        need((parent / 'machine/u214.native.tm').read_bytes()
             == (ROOT / 'inputs/u214.native.tm').read_bytes(), 'parent table differs')
        need((parent / 'machine/sites.json').read_bytes()
             == (ROOT / 'inputs/u214_sites.json').read_bytes(), 'parent source differs')
        command(parent / 'reproduce.py', ['--report', temp / 'parent.json'], parent,
                'Inherited U214 reconstruction and proof audit')
        need(load(temp / 'parent.json')['status'] == 'U214_RECONSTRUCTION_AND_PROOF_AUDIT_PASS',
             'parent audit failed')
        report = {
            'status': 'U213_FULL_REPRODUCTION_PASS' if args.full
                      else 'U213_RECONSTRUCTION_AND_PROOF_AUDIT_PASS',
            'working_states': 213, 'transition_rows': 426,
            'source_instructions': 3928, 'source_dag_nodes': 199,
            'source_addresses_changed': 430, 'closed_factors_checked': 18,
            'local_frames_checked': 1704, 'local_negative_controls_rejected': 5,
            'symbolic_cases_bound_to_exact_table': 5109,
            'symbolic_cases_rederived': 5109 if args.full else 0,
            'blank_startup_steps': 95726, 'dense_bijection_equations': 426,
            'manifest_files': files, 'inherited_u214_audit': True,
            'table_sha256': sha(out / 'u213.tm'),
            'seconds': round(time.monotonic() - start, 3),
            'scope': 'Exact reconstruction, independent finite proofs, full-tape symbolic mathematical verification, and literal blank startup. The unchanged U214/U/W/PA calibration is inherited. No new proof-assistant or exported PA endpoint certificate.'}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
