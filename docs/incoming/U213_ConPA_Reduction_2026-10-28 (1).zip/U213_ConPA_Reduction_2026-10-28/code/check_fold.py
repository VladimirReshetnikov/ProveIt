#!/usr/bin/env python3
"""Independent radius-one certificate for the source-search 214 -> 213 fold.

No construction or source modules are imported. A checked local equality on an
opaque exterior is a whole-tape equality, not a finite-tape approximation.
"""
from pathlib import Path
from itertools import product
import argparse,hashlib,json

def need(p,msg):
 if not p:raise ValueError(msg)
def read(path,count):
 T={};starts=[]
 for line in path.read_text().splitlines():
  if line.startswith('#! start '):starts.append(line)
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  need((q,b)not in T,'duplicate row');need(b in(0,1)and w in(0,1)and d in('L','R'),'invalid row')
  T[q,b]=(w,1 if d=='R'else-1,z)
 S={q for q,b in T};need(starts==['#! start 0'],'wrong start');need(len(S)==count,'wrong count')
 need(set(T)=={(q,b)for q in S for b in(0,1)},'incomplete table');need({z for w,d,z in T.values()}-S=={254},'wrong target closure')
 return T,S

def project(q):return 211 if q==214 else q

def invariant(q,h,t):
 if q==211:return t[h-1]==1
 if q==214:return t[h-1]==0
 return True

def compare_frames(old,new,states):
 counts={1:0,3:0};examples={};admitted=0
 for q in sorted(states):
  for bits in product((0,1),repeat=3):
   before=dict(zip((-1,0,1),bits))
   if not invariant(q,0,before):continue
   admitted+=1;b=before[0];w,d,z=old[q,b];old_after=dict(before);old_after[0]=w
   need(invariant(z,d,old_after),('guard not inductive',q,bits))
   ticks=3 if q in(211,214)and b==0 else 1
   nq=project(q);nh=0;after=dict(before);trace=[]
   for _ in range(ticks):
    need(nq!=254,'internal halt');need(nh in after,'read opaque exterior')
    nb=after[nh];nw,nd,nz=new[nq,nb]
    trace.append([nq,nh,nb,nw,nd,nz]);after[nh]=nw;nh+=nd;nq=nz
   need((nq,nh,after)==(project(z),d,old_after),('full-tape mismatch',q,bits,trace))
   counts[ticks]+=1
   if q in(211,214):examples.setdefault(f'{q}/{b}',{'old_state':q,'read':b,'left_tag':before[-1],'old_action':[w,d,z],'new_trace':trace})
 return {'admitted_frames':admitted,'one_step_blocks':counts[1],'three_step_blocks':counts[3],'examples':examples}

def verify(old,new,states,helper):
 need(helper in(155,186),'unknown helper')
 need(old[211,0]==(0,1,90)and old[211,1]==(1,1,218),'wrong retained rows')
 need(old[214,0]==(0,1,98)and old[214,1]==(1,1,218),'wrong deleted rows')
 incoming={q:sorted((p,b,w,d,z)for(p,b),(w,d,z)in old.items()if z==q)for q in(211,214)}
 need(incoming[211]==[(188,1,1,1,211)],'retained tag premise differs')
 need(incoming[214]==[(181,0,0,1,214)],'deleted tag premise differs')
 want={(q,b):(w,d,project(z))for(q,b),(w,d,z)in old.items()if q!=214};want[211,0]=(0,-1,helper)
 need(new==want,'unexpected table changes')
 proof=compare_frames(old,new,states)
 return {'status':'INDEPENDENT_U213_TAGGED_FOLD_PASS','old_states':214,'new_states':213,'removed':214,'representative':211,'helper':helper,'guard':'q=211 -> tape[h-1]=1; q=214 -> tape[h-1]=0','incoming':incoming,'initial_state':0,'initial_tapes':'all binary tapes','radius':1,'total_frames':len(states)*8,**proof,'exact_time_law':'new_time = old_time + 2*count(old state in {211,214} and scanned symbol 0)','per_block_bounds':[1,3],'halt_time_bounds':'n <= m <= 3*n; each candidate halting time m corresponds to an old halting time n <= m','proof':'The old invariant is true at initial state 0 and inductive. Every old step has a positive 1- or 3-step candidate simulation, with identical full tape, identical head, and projected state; no block contains an internal halt. Concatenation proves halting equivalence in both directions. Primitive recursive coding and induction suffice in PA.','kernel_checked':False}

def controls(old,new,states):
 rejected=[]
 tests=[]
 a=dict(old);b=dict(new);a[188,1]=(0,1,211);b[188,1]=(0,1,211);tests.append(('wrong retained tag',a,b))
 a=dict(old);b=dict(new);a[181,0]=(1,1,214);b[181,0]=(1,1,211);tests.append(('wrong removed tag',a,b))
 b=dict(new);b[211,0]=(1,-1,b[211,0][2]);tests.append(('wrong dispatcher write',old,b))
 b=dict(new);helper=b[211,0][2];w,d,z=b[helper,0];b[helper,0]=(1,d,z);tests.append(('helper corrupts tag',old,b))
 b=dict(new);helper=b[211,0][2];z=b[helper,0][2];w,d,k=b[z,0];b[z,0]=(w,d,90);tests.append(('wrong zero-tag exit',old,b))
 for name,a,b in tests:
  try:compare_frames(a,b,states)
  except (ValueError,KeyError)as e:rejected.append({'mutation':name,'status':'REJECTED','reason':str(e)[:300]})
  else:raise ValueError('negative control accepted: '+name)
 return rejected

def main():
 ap=argparse.ArgumentParser();ap.add_argument('old',type=Path);ap.add_argument('new',type=Path);ap.add_argument('--helper',type=int,default=155);ap.add_argument('--out',type=Path);a=ap.parse_args()
 old,S=read(a.old,214);new,_=read(a.new,213);r=verify(old,new,S,a.helper);r['negative_controls']=controls(old,new,S);r['sha256']={name:hashlib.sha256(p.read_bytes()).hexdigest()for name,p in [('old',a.old),('new',a.new)]}
 text=json.dumps(r,indent=2)+'\n'
 if a.out:a.out.write_text(text)
 print(text,end='')
if __name__=='__main__':main()
