#!/usr/bin/env python3
"""Independent leaf-ancestry and literal-table audit of six closed rotations.
No source compiler, allocator, or runtime module is imported. This audits source
semantics and construction identity; arbitrary-register literal execution is a
separate required check.
"""
from pathlib import Path
import argparse,collections,hashlib,json

def need(p,msg):
 if not p:raise ValueError(msg)
def table(p):
 T={}
 for l in p.read_text().splitlines():
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in T,'duplicate row');T[q,b]=(w,1 if d=='R'else-1,z)
 return T

def tree(rows):
 d={p:(o,a)for p,o,a in rows};need(len(d)==len(rows),'duplicate leaves');prefs={p[:i]for p in d for i in range(len(p))};need(not prefs&d.keys(),'prefix leaf collision')
 def rec(p):
  if p in d:return ('leaf',*d[p])
  need(p in prefs,'incomplete tree');return ('node',rec(p+'0'),rec(p+'1'))
 return rec('')

def leaves(t,p=''):
 if t[0]=='leaf':return [[p,t[1],t[2]]]
 return leaves(t[1],p+'0')+leaves(t[2],p+'1')

def subtree(t,p):
 for b in p:need(t[0]=='node','bad path');t=t[int(b)+1]
 return t

def put(t,p,u):
 if not p:return u
 j=int(p[0])+1;a=list(t);a[j]=put(a[j],p[1:],u);return tuple(a)

def closed(t):
 ls=leaves(t)
 for p,op,a in ls:
  need(op!='CH','halt in supposedly closed factor')
  if op=='CD':need(p.count('0')>=1,('decrement escapes factor',p))
  if op=='CB':need(p.count('0')>=a,('break escapes factor',p,a))
  if op=='CC':need(p.count('1')>=a,('continue escapes factor',p,a))
 return len(ls)

def prefix_map(T,R):
 mapping=collections.defaultdict(list);helpers=set()
 def walk(t,p,q):
  if t[0]=='leaf':return
  mapping[q].append(p)
  for b in(0,1):
   child=t[b+1]
   if child[0]=='leaf':continue
   tape={-1:1,**{i:int(v)for i,v in enumerate(p+str(b))}};before=dict(tape);h=len(p);state=q;trace=[]
   for _ in range(64):
    if h==len(p)+1:break
    need(h in tape,'opaque suffix read while mapping prefix');bit=tape[h];trace.append((state,bit));w,d,z=T[state,bit];tape[h]=w;h+=d;state=z
   need(h==len(p)+1 and tape==before,'bad prefix transition');helpers.update(trace[1:]);walk(child,p+str(b),state)
 walk(R,'',84)
 return mapping,helpers

def verify(oldsites,oldtm,recipe,newsites,newtm):
 initial=json.loads(oldsites.read_text());R=tree(initial);T=table(oldtm);proof=[]
 need(leaves(R)==initial,'noncanonical input')
 for i,(q,r,side,p)in enumerate(json.loads(recipe.read_text())):
  mp,helpers=prefix_map(T,R);need(mp[q]==[p] and mp[r]==[p+str(side)],('wrong unique source binding',i))
  need(all(T[z,b][:2]==(b,1)for z in(q,r)for b in(0,1)),'nonpure rotation state')
  need(all((z,b)not in helpers for z in(q,r)for b in(0,1)),'rotation mutates internal prefix helper')
  inc=[(z,b)for(z,b),(_,_,dest)in T.items()if dest==r];need(inc==[(q,side)],'child has another literal entrance')
  n=subtree(R,p);need(n[0]=='node'and n[side+1][0]=='node','not an association node')
  if side==0:
   A,B=n[1][1:];C=n[2];new=('node',A,('node',B,C));actions={(q,0):T[r,0],(q,1):(1,1,r),(r,0):T[r,1],(r,1):T[q,1]}
  else:
   A=n[1];B,C=n[2][1:];new=('node',('node',A,B),C);actions={(q,0):(0,1,r),(q,1):T[r,1],(r,0):T[q,0],(r,1):T[r,0]}
  # The copied child targets get the newly read bit as their unchanged write.
  actions={k:(k[1],1,a[2])for k,a in actions.items()}
  sizes=[closed(a)for a in(A,B,C)];oldleaves=[row[1:]for row in leaves(n)];newleaves=[row[1:]for row in leaves(new)];need(oldleaves==newleaves,'rotation reorders primitives')
  T.update(actions);R=put(R,p,new)
  proof.append({'step':i+1,'states':[q,r],'side':side,'prefix':p,'factor_leaf_counts':sizes,'primitive_order_unchanged':True,'all_control_jumps_internal_by_direct_leaf_ancestry':True})
 need(T==table(newtm),'rotated literal table differs');need(leaves(R)==json.loads(newsites.read_text()),'rotated source differs')
 return {'status':'INDEPENDENT_SIX_CLOSED_ROTATIONS_PASS','rotations':proof,'source_leaf_count':len(leaves(R)),'source_semantics':'Every A,B,C factor has no halt and no break/continue beyond its own ancestry. Consequently each association replaces (A;B);C with A;(B;C) or the reverse, preserving normal-return register relations and divergence by closed sequential associativity.','table_binding':'Every rotated state has a unique source-node role, each rotated child a unique literal entrance; all changed rows preserve the scanned symbol and move right. Whole-tape runtime correctness remains a separate obligation.','kernel_checked':False}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--oldsites',type=Path,required=True);ap.add_argument('--oldtm',type=Path,required=True);ap.add_argument('--recipe',type=Path,required=True);ap.add_argument('--newsites',type=Path,required=True);ap.add_argument('--newtm',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
 r=verify(a.oldsites,a.oldtm,a.recipe,a.newsites,a.newtm);r['sha256']={n:hashlib.sha256(getattr(a,n).read_bytes()).hexdigest()for n in('oldsites','oldtm','recipe','newsites','newtm')};a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
