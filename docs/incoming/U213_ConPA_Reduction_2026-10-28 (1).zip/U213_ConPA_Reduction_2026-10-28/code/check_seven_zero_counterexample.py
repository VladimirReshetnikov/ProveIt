#!/usr/bin/env python3
"""Concrete primitive-contract rejection of the four-rotation U213 attempt.

Independent literal simulator: no imports from any source compiler or symbolic
runtime. This valid primitive input is not asserted reachable from blank.
The accepted six-rotation U213 supplies a positive control at the same ordinal.
"""
from pathlib import Path
import argparse,json,hashlib

PINS={
 'rejected_table':'386c412145a94b534cfe88d94bc4098530d55565920e6544a74381b5d3dd5d75',
 'rejected_sites':'5ba7d89b1e127658ae80f3df11928dca81f712681041447eac978773124e1ee1',
 'accepted_table':'310364dec119bb64bf8201956c0c14cb37fa4b692fbb7012bfeb7f05e1f27259',
 'accepted_sites':'2780cc9b746d25bf462a607ef28abb3c5d8dd7c85b885af413f60db7507b916e'}
INDEX=3337

def need(ok,why):
 if not ok:raise ValueError(why)

def table(p):
 t={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  need((q,b)not in t and b in(0,1)and w in(0,1)and d in('L','R'),'bad row')
  t[q,b]=(w,1 if d=='R'else-1,z)
 return t

def frame(pc):
 # Nine primary registers and one spare, each zero: blocks 01.
 return {-1,64}|{j for j,b in enumerate(pc)if b=='1'}|set(range(66,85,2))

def clean_root(q,h,ones):
 if q!=84 or h-1 not in ones or any(x<h-1 for x in ones):return False
 right=sorted(x for x in ones if x>=h+52)
 if not right or right[0]<h+64:return False
 p=right[0]+1;last=max(ones);blocks=0
 while p<last:
  if p in ones or p+1 not in ones:return False
  p+=1
  while p in ones:p+=1
  blocks+=1
 return p==last+1 and blocks>=10

def run(t,pc):
 ones=frame(pc);q=84;h=0
 for count in range(20001):
  if count and clean_root(q,h,ones):return q,h,ones,count
  need((q,int(h in ones))in t,'premature halt')
  w,d,q=t[q,int(h in ones)]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 raise ValueError('concrete simulation bound exhausted')

def successor(pc):
 # The guarded zero-decrement leaves its nearest containing left branch,
 # then increments that ancestor's binary address.
 p=pc[:pc.rfind('0')];n=len(p)
 need(n>0,'unexpected root overflow')
 v=int(p,2)+1;need(v<(1<<n),'unexpected address overflow')
 return format(v,'0'+str(n)+'b')

def trial(table_path,sites_path):
 source=json.loads(sites_path.read_text());pc,op,arg=source[INDEX]
 need(op=='CD'and arg==2,'wrong primitive')
 nxt=successor(pc);expected=(84,0,frame(nxt));q,h,ones,steps=run(table(table_path),pc)
 return {'site_index':INDEX,'site':[pc,op,arg],'logical_registers':[0]*9,'spares':[0],
         'gap':0,'start_state':84,'start_head':0,'initial_one_cells':sorted(frame(pc)),
         'expected_pc':nxt,'steps_to_first_clean_root':steps,
         'expected':{'state':84,'head':0,'one_cells':sorted(expected[2])},
         'actual':{'state':q,'head':h,'one_cells':sorted(ones)},
         'unexpected_one_cells':sorted(ones-expected[2]),
         'missing_one_cells':sorted(expected[2]-ones),
         'matches_expected':(q,h,ones)==expected}

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in PINS:p.add_argument('--'+name.replace('_','-'),required=True,type=Path)
 p.add_argument('--out',type=Path);a=p.parse_args()
 for name,expected in PINS.items():need(hashlib.sha256(getattr(a,name).read_bytes()).hexdigest()==expected,'input digest: '+name)
 rejected=trial(a.rejected_table,a.rejected_sites);accepted=trial(a.accepted_table,a.accepted_sites)
 need(not rejected['matches_expected']and rejected['steps_to_first_clean_root']==1244,'rejection not reproduced')
 need(rejected['unexpected_one_cells']==[29]and rejected['missing_one_cells']==[],'different counterexample')
 need(accepted['matches_expected'],'positive control failed')
 r={'status':'SEVEN_ZERO_COUNTEREXAMPLE_REPRODUCED','input_sha256':PINS,
    'scope':'One valid zero-decrement primitive input with all primary registers and its single spare equal to zero; no blank-run reachability claim.',
    'rejected_four_rotations':rejected,'accepted_six_rotations_positive_control':accepted}
 raw=json.dumps(r,indent=2)+'\n'
 if a.out:a.out.write_text(raw)
 print(json.dumps({'status':r['status'],'rejected_steps':rejected['steps_to_first_clean_root'],
       'unexpected_one_cells':rejected['unexpected_one_cells'],'accepted_steps':accepted['steps_to_first_clean_root']},indent=2))
if __name__=='__main__':main()
