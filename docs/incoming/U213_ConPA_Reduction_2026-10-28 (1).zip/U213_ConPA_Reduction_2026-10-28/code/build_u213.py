#!/usr/bin/env python3
"""Fixed, solver-free U214 to U213 source/table construction.

Adapted from the supplied U216 construction by preserving its source-tree,
closed-rotation, prefix-binding, and ordinal CFG checker. Original source:
ProveIt/docs/incoming/U216_ConPA_2026-10-28.zip/code/build_u216.py.
The six-rotation recipe and 211/214 tag fold are new here.

The source consists of the same ordered primitives with identical guarded CFG.
Six closed binary reassociations expose a preceding-bit fold.
Native214 is identified with native211, reusing native155 as selector. Whole-tape
arbitrary-register runtime and blank initialization are separate obligations.
"""
from pathlib import Path
from functools import cache
import argparse, json, hashlib

BASE_NATIVE='5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8'
BASE_SOURCE='9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083'
FINAL_NATIVE='310364dec119bb64bf8201956c0c14cb37fa4b692fbb7012bfeb7f05e1f27259'
FINAL_SOURCE='2780cc9b746d25bf462a607ef28abb3c5d8dd7c85b885af413f60db7507b916e'
ROTATIONS=[[188, 167, 0, '11010010011101010110111111111'], [174, 188, 1, '1101001001110101011011111111'], [211, 115, 1, '110100100111010101101111111100'], [188, 211, 0, '11010010011101010110111111110'], [189, 174, 1, '110100100111010101101111111'], [174, 501, 0, '1101001001110101011011111110']]
def need(ok,why):
 if not ok:raise ValueError(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def table(raw):
 t={};starts=[]
 for line in raw.decode().splitlines():
  if line.startswith('#! start '):starts.append(int(line[9:]))
  elif line and not line.startswith('#'):
   q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
   need((q,b)not in t and b in(0,1)and w in(0,1)and d in('L','R'),'bad row')
   t[q,b]=w,(-1 if d=='L'else 1),z
 need(starts==[0],'wrong start');return t
def encode(t):return('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(t.items()))).encode()
def leaf(n):return isinstance(n[0],str)
def tree(rows):
 d={p:(op,arg)for p,op,arg in rows};need(len(d)==len(rows),'duplicate source')
 ps={p[:j]for p in d for j in range(len(p))}
 need(not ps&d.keys()and all(p+b in ps or p+b in d for p in ps for b in'01'),'nonbinary source')
 def rec(p):return d[p]if p in d else(rec(p+'0'),rec(p+'1'))
 t=rec('');need(sites(t)==rows,'source order');return t
def sites(t,p=''):
 return[[p,*t]]if leaf(t)else sites(t[0],p+'0')+sites(t[1],p+'1')
@cache
def bound(n):
 if leaf(n):
  op,a=n;return(1 if op=='CD'else a if op=='CB'else 0,a if op=='CC'else 0,op=='CH')
 a,b=bound(n[0]),bound(n[1]);return(max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2])
def at(t,p):
 for b in p:t=t[int(b)]
 return t
def replace(t,p,n):
 if not p:return n
 a=list(t);b=int(p[0]);a[b]=replace(a[b],p[1:],n);return tuple(a)
def cfg(rows):
 bounds={}
 for i,(p,op,a)in enumerate(rows):
  for j in range(len(p)+1):
   s=p[:j]
   if s not in bounds:bounds[s]=[i,i+1]
   else:bounds[s][1]=i+1
 out=[]
 for i,(p,op,a)in enumerate(rows):
  if op=='CI':ds=[i+1]
  elif op=='CH':ds=[]
  else:
   ch='1'if op=='CC'else'0';k=a if op!='CD'else 1
   ii=[j for j,b in enumerate(p)if b==ch];need(len(ii)>=k,'escaping branch')
   z=bounds[p[:ii[-k]]][0 if op=='CC'else 1]
   ds=[z,i+1]if op=='CD'else[z]
  out.append((op,a,ds))
 return out
def metrics(t):
 seen=set()
 def rec(n):
  if n in seen:return
  seen.add(n)
  if not leaf(n):rec(n[0]);rec(n[1])
 rec(t);r=sites(t)
 return dict(dag_nodes=len(seen),leaf_occurrences=len(r),maximum_depth=max(len(p)for p,op,a in r),maximum_zero_run=max(len(k)for p,op,a in r for k in p.split('1')))
def valid(t,halt,count):
 qs={q for q,b in t};need(len(qs)==count and set(t)=={(q,b)for q in qs for b in(0,1)},'state census')
 need(0 in qs and halt not in qs and{z for w,d,z in t.values()}-qs=={halt},'state targets')

def prefix_contexts(T,rows,q,r,side,path):
 """Audit every known code-prefix traversal, stopping at unknown tape."""
 counts={q:0,r:0};contexts=set()
 for pc,op,arg in rows:
  tape={-1:1,**{i:int(c)for i,c in enumerate(pc)}};state=84;head=0
  for tick in range(10000):
   if head not in tape:break
   if state in(q,r):
    expected=path if state==q else path+str(side)
    need(head==len(expected)and pc.startswith(expected),'secondary decoder context')
    need(all(tape[j]==int(c)for j,c in enumerate(pc)),'modified code at decoder entry')
    counts[state]+=1;contexts.add((state,head,expected))
   w,d,z=T[state,tape[head]];tape[head]=w;state=z;head+=d
  else:raise ValueError('code-prefix audit did not terminate')
 need(counts[q]>0 and counts[r]>0,'missing decoder occurrence')
 return {'source_prefixes_checked':len(rows),'row_state_visits':counts,
         'exact_entry_contexts':sorted(contexts),
         'scope':'Known source-prefix traversal only; arbitrary-register continuation is checked separately.'}

def build(native,source,out):
 raw=native.read_bytes();sr=source.read_bytes();need(sha(raw)==BASE_NATIVE,'wrong U214 table');need(sha(sr)==BASE_SOURCE,'wrong U214 source')
 T=table(raw);old=json.loads(sr);root=tree(old);evidence=[]
 for q,r,side,p in ROTATIONS:
  need(sorted(k for k,act in T.items()if act[2]==r)==[(q,side)],'inner entry not unique')
  need(all(T[z,b][:2]==(b,1)for z in(q,r)for b in(0,1)),'not pure decoder')
  n=at(root,p);need(not leaf(n)and not leaf(n[side]),'wrong subtree shape')
  if side==1:a,(b,c)=n;new=((a,b),c)
  else:(a,b),c=n;new=(a,(b,c))
  need(all(bound(x)==(0,0,False)for x in(a,b,c)),'factors are not closed')
  pc_audit=prefix_contexts(T,sites(root),q,r,side,p)
  rec={'prefix_context_audit':pc_audit,'outer':q,'inner':r,'side':side,'path':p,'factor_lengths':[len(sites(x))for x in(a,b,c)],'before_rows':[[z,b,*T[z,b]]for z in(q,r)for b in(0,1)]}
  U=dict(T)
  if side==1:
   U[q,0]=(0,1,r);U[q,1]=(1,1,T[r,1][2]);U[r,0]=(0,1,T[q,0][2]);U[r,1]=(1,1,T[r,0][2])
  else:
   U[q,0]=(0,1,T[r,0][2]);U[q,1]=(1,1,r);U[r,0]=(0,1,T[r,1][2]);U[r,1]=(1,1,T[q,1][2])
  root=replace(root,p,new);T=U;rec['after_rows']=[[z,b,*T[z,b]]for z in(q,r)for b in(0,1)];evidence.append(rec)
 rotated=dict(T);ns=sites(root);need(cfg(old)==cfg(ns),'guarded CFG changed')
 need([r[1:]for r in old]==[r[1:]for r in ns],'primitive sequence changed')
 need(metrics(root)=={'dag_nodes':199,'leaf_occurrences':3928,'maximum_depth':45,'maximum_zero_run':6},'source metric mismatch')
 need(sorted(k for k,act in T.items()if act[2]==211)==[(188,1)],'tag1 incoming inventory')
 need(T[188,1]==(1,1,211),'tag1 write')
 need(sorted(k for k,act in T.items()if act[2]==214)==[(181,0)],'tag0 incoming inventory')
 need(T[181,0]==(0,1,214),'tag0 write')
 need(T[211,1]==T[214,1]==(1,1,218),'common branch')
 need(T[211,0]==(0,1,90)and T[214,0]==(0,1,98),'old distinct branches')
 need(T[155,0]==(0,1,85)and T[155,1]==(1,1,150),'selector rows')
 need(T[85,0]==(0,1,98)and T[150,0]==(0,1,90),'helper rows')
 T={(q,b):(w,d,211 if z==214 else z)for(q,b),(w,d,z)in T.items()if q!=214};T[211,0]=(0,-1,155)
 valid(T,254,213)
 nr=encode(T);source_bytes=(json.dumps(ns,separators=(',',':'))+'\n').encode();need(sha(nr)==FINAL_NATIVE and sha(source_bytes)==FINAL_SOURCE,'final identity')
 states=sorted({q for q,b in T});rename={q:i for i,q in enumerate(states)};rename[254]=213
 dense={(rename[q],b):(w,d,rename[z])for(q,b),(w,d,z)in T.items()};valid(dense,213,213);dr=encode(dense)
 out.mkdir(parents=True,exist_ok=True)
 for fn,data in [('u213.native.tm',nr),('u213.tm',dr),('sites.json',source_bytes),('rotated214.native.tm',encode(rotated))]:(out/fn).write_bytes(data)
 report={'status':'EXACT_SOLVER_FREE_U213_RECONSTRUCTION','working_states':213,'transitions':426,'native_sha256':sha(nr),'dense_sha256':sha(dr),'source_sha256':sha(source_bytes),'source_metrics':metrics(root),'changed_source_addresses':sum(a[0]!=b[0]for a,b in zip(old,ns)),'rotations':evidence,'tag_fold':{'keep':211,'drop':214,'changed':[211,0,0,-1,155]},'scope':'Exact finite construction, prefix contexts and ordinal CFG identity; universal runtime and blank initialization remain separate.'}
 (out/'construction.json').write_text(json.dumps(report,indent=2)+'\n');(out/'state_map.json').write_text(json.dumps({'native_to_dense':rename,'dense_to_native':{v:k for k,v in rename.items()},'native_halt':254,'dense_halt':213,'start':0},indent=2)+'\n')

 return report
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--baseline-machine',type=Path,required=True);ap.add_argument('--baseline-source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();print(json.dumps(build(a.baseline_machine,a.baseline_source,a.output),indent=2))
