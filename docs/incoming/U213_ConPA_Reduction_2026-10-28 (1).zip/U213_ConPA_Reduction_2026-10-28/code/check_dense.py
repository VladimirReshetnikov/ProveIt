#!/usr/bin/env python3
"""Independent parse and complete dense/native renaming audit."""
from pathlib import Path
import argparse,json,hashlib

def need(ok,why):
 if not ok:raise ValueError(why)

def read(p):
 tab={};starts=[]
 for line in p.read_text().splitlines():
  if line.startswith('#! start '):starts.append(int(line[9:]));continue
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  need((q,b)not in tab and b in(0,1)and w in(0,1)and d in('L','R'),'row format')
  tab[q,b]=(w,d,z)
 need(starts==[0],'start');return tab

def check(folder):
 n=read(folder/'u213.native.tm');d=read(folder/'u213.tm')
 m=json.loads((folder/'state_map.json').read_text());f={int(k):v for k,v in m['native_to_dense'].items()};g={int(k):v for k,v in m['dense_to_native'].items()}
 need(len(n)==len(d)==426,'row count');need(len(f)==len(g)==214,'mapping size')
 need(set(g)==set(range(214))and set(f.values())==set(g),'mapping range')
 need(all(g[v]==k for k,v in f.items()),'bijection')
 need(f[0]==0 and f[254]==213,'special states')
 nq={q for q,b in n};dq={q for q,b in d};need(dq==set(range(213)),'dense working states')
 need(set(f)==nq|{254},'native mapping domain')
 for q in nq:
  for b in(0,1):
   need((q,b)in n and(f[q],b)in d,'totality')
   w,dr,z=n[q,b];need(d[f[q],b]==(w,dr,f[z]),'transition not preserved')
 need({z for w,dr,z in d.values()}-dq=={213},'target closure')
 reach={0};todo=[0]
 for q in todo:
  for b in(0,1):
   z=d[q,b][2]
   if z in dq and z not in reach:reach.add(z);todo.append(z)
 need(reach==dq,'unreachable working state')
 return {'status':'DENSE_RENAMING_PASS','working_states':213,'transition_rows':426,'mapping_equations_checked':426,'graph_reachable_working_states':213,'start':0,'halt':213,'dense_sha256':hashlib.sha256((folder/'u213.tm').read_bytes()).hexdigest(),'native_sha256':hashlib.sha256((folder/'u213.native.tm').read_bytes()).hexdigest()}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder',type=Path);p.add_argument('--out',type=Path);a=p.parse_args();r=check(a.folder);raw=json.dumps(r,indent=2)+'\n'
 if a.out:a.out.write_text(raw)
 print(raw,end='')
