#!/usr/bin/env python3
"""Independent finite proof-premise audit for U214 -> U213.

Uses only the Python standard library, and imports no construction/search,
source-language, or runtime-checker code. Physical realization of the audited
source is a separate all-natural symbolic-runtime obligation.
"""
from pathlib import Path
import argparse
import hashlib
import json

if not __debug__:
    raise SystemExit('Run without -O: this independent certificate uses assertions.')


def read_table(path):
    table = {}
    starts = []
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(line)
        if not line or line.startswith('#'):
            continue
        q, b, w, direction, target = line.split()
        q, b, w, target = map(int, (q, b, w, target))
        assert direction in ('L', 'R') and b in (0, 1) and w in (0, 1)
        assert (q, b) not in table and q >= 0 and target >= 0
        table[q, b] = w, (-1 if direction == 'L' else 1), target
    assert starts == ['#! start 0']
    return table


def census(table, expected):
    states = {q for q, b in table}
    assert len(states) == expected and 0 in states and 254 not in states
    assert set(table) == {(q, b) for q in states for b in (0, 1)}
    assert {target for w, d, target in table.values()} - states == {254}
    reached, todo = {0}, [0]
    for q in todo:
        for b in (0, 1):
            target = table[q, b][2]
            if target != 254 and target not in reached:
                reached.add(target)
                todo.append(target)
    assert reached == states
    return states


def leaf(tree):
    return isinstance(tree[0], str)


def parse(records):
    leaves = {path: (op, arg) for path, op, arg in records}
    assert len(leaves) == len(records)
    def get(path):
        return leaves[path] if path in leaves else (get(path + '0'), get(path + '1'))
    tree = get('')
    assert rows(tree) == records
    return tree


def rows(tree, path=''):
    return [[path, *tree]] if leaf(tree) else rows(tree[0], path + '0') + rows(tree[1], path + '1')


def at(tree, path):
    for bit in path:
        assert bit in '01' and not leaf(tree)
        tree = tree[int(bit)]
    return tree


def replace(tree, path, replacement):
    if not path:
        return replacement
    kids = list(tree)
    bit = int(path[0])
    kids[bit] = replace(kids[bit], path[1:], replacement)
    return tuple(kids)


def signature(tree):
    if leaf(tree):
        op, arg = tree
        assert op in ('CI', 'CD', 'CB', 'CC', 'CH')
        return (1 if op == 'CD' else arg if op == 'CB' else 0,
                arg if op == 'CC' else 0, op == 'CH')
    left, right = map(signature, tree)
    return (max(left[0] - 1, right[0], 0), max(left[1], right[1] - 1, 0),
            left[2] or right[2])


def interval_graph(tree):
    records = rows(tree)
    ranks = {path: i for i, (path, _, _) in enumerate(records)}
    spans = {}
    def go(node, path):
        if leaf(node):
            span = ranks[path], ranks[path] + 1
        else:
            left, right = go(node[0], path + '0'), go(node[1], path + '1')
            assert left[1] == right[0]
            span = left[0], right[1]
        spans[path] = span
        return span
    go(tree, '')
    count = len(records)
    result = []
    for index, (path, op, arg) in enumerate(records):
        def cut(edge, depth):
            hits = [i for i, bit in enumerate(path) if bit == edge]
            if len(hits) < depth:
                return 0
            prefix = path[:hits[-depth]]
            return spans[prefix][1] % count if edge == '0' else spans[prefix][0]
        after = (index + 1) % count
        targets = ([cut('0', 1), after] if op == 'CD' else [cut('0', arg)] if op == 'CB'
                   else [cut('1', arg)] if op == 'CC' else [] if op == 'CH' else [after])
        result.append([op, arg, targets])
    return result


def arithmetic_graph(tree):
    records = rows(tree)
    ranks = {path: i for i, (path, _, _) in enumerate(records)}
    checks = 0
    def first_under(prefix):
        nonlocal checks
        node, path, index = tree, '', 0
        while not leaf(node):
            bit = prefix[index] if index < len(prefix) else '0'
            index += 1
            path += bit
            node = node[int(bit)]
        assert '1' not in prefix[index:], 'A successor leaves a stray one beyond its leaf.'
        checks += 1
        return ranks[path]
    def add_one(path):
        digits = list(path)
        index = len(digits) - 1
        while index >= 0 and digits[index] == '1':
            digits[index] = '0'
            index -= 1
        if index >= 0:
            digits[index] = '1'
        return ''.join(digits)
    def up(path, bit, depth):
        for index in range(len(path) - 1, -1, -1):
            if path[index] == bit:
                depth -= 1
                if depth == 0:
                    return path[:index]
        return ''
    result = []
    for path, op, arg in records:
        targets = ([first_under(add_one(up(path, '0', 1))), first_under(add_one(path))]
                   if op == 'CD' else [first_under(add_one(up(path, '0', arg)))]
                   if op == 'CB' else [first_under(up(path, '1', arg))]
                   if op == 'CC' else [] if op == 'CH' else [first_under(add_one(path))])
        result.append([op, arg, targets])
    assert first_under('') == 0
    return result, checks


def prefix_state(table, prefix):
    tape = {-1: 1, **{index: int(bit) for index, bit in enumerate(prefix)}}
    initial = dict(tape)
    state, head = 84, 0
    for _ in range(10000):
        if head == len(prefix):
            assert tape == initial, 'Decoder prefix traversal changed the tape.'
            return state
        assert head in tape and (state, tape[head]) in table
        write, move, state = table[state, tape[head]]
        tape[head] = write
        head += move
    raise AssertionError('Decoder prefix traversal did not reach its endpoint.')


def rotation_step(table, source, descriptor):
    q, r, side, path = descriptor
    assert side in (0, 1)
    assert all(table[state, bit][:2] == (bit, 1) for state in (q, r) for bit in (0, 1))
    assert table[q, side][2] == r, 'The declared inner state is not the selected child.'
    assert [key for key, action in table.items() if action[2] == r] == [(q, side)]
    assert prefix_state(table, path) == q, 'Outer state does not bind this source path.'
    assert prefix_state(table, path + str(side)) == r, 'Inner state does not bind this source path.'
    node = at(source, path)
    if side == 1:
        a, (b, c) = node
        new_node = ((a, b), c)
        edits = {(q, 0): (0, 1, r), (q, 1): (1, 1, table[r, 1][2]),
                 (r, 0): (0, 1, table[q, 0][2]), (r, 1): (1, 1, table[r, 0][2])}
    else:
        (a, b), c = node
        new_node = (a, (b, c))
        edits = {(q, 0): (0, 1, table[r, 0][2]), (q, 1): (1, 1, r),
                 (r, 0): (0, 1, table[r, 1][2]), (r, 1): (1, 1, table[q, 1][2])}
    assert all(signature(factor) == (0, 0, False) for factor in (a, b, c))
    before = [[*key, *table[key]] for key in edits]
    updated = dict(table)
    updated.update(edits)
    return updated, replace(source, path, new_node), dict(
        outer=q, inner=r, side=side, path=path,
        factor_sizes=[len(rows(factor)) for factor in (a, b, c)],
        all_factors_closed=True, literal_prefix_binding=True, before=before, after=[[*key, *value] for key, value in edits.items()])


def tag_fold_check(table, final):
    representative, removed = 211, 214
    incoming = {str(q): [[*key, *action] for key, action in table.items() if action[2] == q]
                for q in (representative, removed)}
    assert incoming['211'] == [[188, 1, 1, 1, 211]], 'Wrong incoming tag for 211.'
    assert incoming['214'] == [[181, 0, 0, 1, 214]], 'Wrong incoming tag for 214.'
    assert table[211, 0] == (0, 1, 90) and table[214, 0] == (0, 1, 98)
    assert table[211, 1] == table[214, 1] == (1, 1, 218)
    assert table[155, 0] == (0, 1, 85) and table[155, 1] == (1, 1, 150)
    assert table[85, 0] == (0, 1, 98) and table[150, 0] == (0, 1, 90)
    renamed = lambda q: representative if q == removed else q
    expected = {(q, b): (w, d, renamed(target)) for (q, b), (w, d, target) in table.items()
                if q != removed}
    expected[211, 0] = 0, -1, 155
    assert final == expected, 'The candidate is not the specified fold.'
    cases = []
    for oldstate, tag in ((211, 1), (214, 0)):
        for bit in (0, 1):
            tape = {-1: tag, 0: bit}
            initial = dict(tape)
            state, head, trace = 211, 0, []
            steps = 3 if bit == 0 else 1
            for _ in range(steps):
                assert head in tape  # Every exterior cell is universally untouched.
                read = tape[head]
                write, move, target = final[state, read]
                trace.append([state, head, read, write, move, target])
                tape[head] = write
                head += move
                state = target
            write, move, target = table[oldstate, bit]
            intended = dict(initial)
            intended[0] = write
            assert tape == intended and (state, head) == (target, move)
            cases.append(dict(oldstate=oldstate, left_tag=tag, read=bit,
                              new_steps=steps, trace=trace, full_tape_equal=True))
    for (q, bit), (write, move, target) in table.items():
        if q in (211, 214) and bit == 0:
            continue
        assert final[renamed(q), bit] == (write, move, renamed(target))
    return incoming, cases


def rejected(action, description):
    try:
        action()
    except (AssertionError, ValueError, KeyError) as error:
        return dict(control=description, rejected=True, reason=str(error) or type(error).__name__)
    raise AssertionError('Invalid negative control was accepted: ' + description)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('baseline-machine', 'baseline-source', 'rotations', 'rotated', 'candidate', 'sites', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    old = read_table(args.baseline_machine)
    census(old, 214)
    source = parse(json.loads(args.baseline_source.read_text()))
    original_source = source
    original_rows = rows(source)
    graph = interval_graph(source)
    arithmetic, checks = arithmetic_graph(source)
    assert graph == arithmetic
    table, certificates = dict(old), []
    rotations = json.loads(args.rotations.read_text())
    assert len(rotations) == 6
    for descriptor in rotations:
        table, source, certificate = rotation_step(table, source, descriptor)
        assert [item[1:] for item in rows(source)] == [item[1:] for item in original_rows]
        assert interval_graph(source) == graph
        arithmetic, new_checks = arithmetic_graph(source)
        assert arithmetic == graph and new_checks == checks
        certificate.update(full_cfg_identical=True, binary_no_stray_checks=new_checks)
        certificates.append(certificate)
    assert table == read_table(args.rotated)
    assert rows(source) == json.loads(args.sites.read_text())
    census(table, 214)
    final = read_table(args.candidate)
    states = census(final, 213)
    incoming, cases = tag_fold_check(table, final)
    bad_rotation = list(rotations[0])
    bad_rotation[2] = 1 - bad_rotation[2]
    bad_tag = dict(table)
    bad_tag[181, 0] = 1, 1, 214
    controls = [rejected(lambda: rotation_step(old, original_source, bad_rotation), 'Flip first rotation side'),
                rejected(lambda: tag_fold_check(bad_tag, final), 'Flip incoming tag of state 214')]
    result = dict(
        status='INDEPENDENT_U213_FINITE_PREMISES_PASS',
        input_sha256=sha(args.baseline_machine), output_sha256=sha(args.candidate),
        baseline_source_sha256=sha(args.baseline_source), source_sha256=sha(args.sites),
        rotations=certificates, primitive_count=len(original_rows),
        guarded_primitive_cases=sum(len(item[2]) if item[0] != 'CH' else 1 for item in graph),
        independent_binary_no_stray_checks=checks,
        changed_source_addresses=sum(a[0] != b[0] for a, b in zip(original_rows, rows(source))),
        incoming_edge_inventory=incoming, fold_cases=cases,
        changed_retained_rows=[[*key, *old[key], *final[key]] for key in final if final[key] != old[key]],
        deleted_states=sorted({q for q, b in old} - states), working_states=len(states),
        transition_rows=len(final), graph_reachable_working_states=len(states),
        negative_controls=controls,
        physical_source_realization='Separate final-table all-natural symbolic runtime and blank-start certificates are required.')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('rotations', 'fold_cases', 'changed_retained_rows')}, indent=2))


if __name__ == '__main__':
    main()
