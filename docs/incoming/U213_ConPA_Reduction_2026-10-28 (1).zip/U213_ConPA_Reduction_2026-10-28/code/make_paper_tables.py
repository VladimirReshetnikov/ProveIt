#!/usr/bin/env python3
"""Render the exact release tables as LaTeX, using only the standard library."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent


def action(row, halt=None):
    w, d, z = row
    return r'\texttt{' + str(w) + d + ('H' if z == halt else str(z)) + '}'


def main():
    rows = {}
    for line in (ROOT / 'machine/u213.tm').read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        rows[int(q), int(b)] = int(w), d, int(z)
    if len(rows) != 426:
        raise ValueError('wrong dense row census')
    title = r'$q$ & $\delta(q,0)$ & $\delta(q,1)$'
    text = [r'{\small', r'\setlength{\tabcolsep}{5pt}',
            r'\begin{longtable}{rll@{\hspace{1.4em}}rll@{\hspace{1.4em}}rll}',
            r'\toprule', title + ' & ' + title + ' & ' + title + r'\\',
            r'\midrule\endfirsthead', r'\toprule',
            title + ' & ' + title + ' & ' + title + r'\\',
            r'\midrule\endhead', r'\bottomrule\endfoot']
    for i in range(71):
        groups = []
        for q in [i, i + 71, i + 142]:
            groups.append(f'{q} & {action(rows[q,0],213)} & {action(rows[q,1],213)}')
        text.append(' & '.join(groups) + r'\\')
    text += [r'\end{longtable}', '}']
    (ROOT / 'paper/transition_table.tex').write_text('\n'.join(text) + '\n')
    delta = json.loads((ROOT / 'machine/delta_from_u214.json').read_text())
    text = [r'\begin{center}', r'\begin{tabular}{rrll}', r'\toprule',
            r'State & Read & U214 action & U213 action\\', r'\midrule']
    for row in delta['changed_retained_rows']:
        text.append(f"{row['state']} & {row['read']} & {action(row['old'])} & {action(row['new'])}" + r'\\')
    text += [r'\midrule']
    for row in delta['deleted_rows']:
        text.append(f"{row['state']} & {row['read']} & {action(row['old'])} & deleted" + r'\\')
    text += [r'\bottomrule', r'\end{tabular}', r'\end{center}']
    (ROOT / 'paper/delta_table.tex').write_text('\n'.join(text) + '\n')


if __name__ == '__main__':
    main()
