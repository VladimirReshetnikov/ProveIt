Supplementary research; the accepted machine is ../machine/u213.tm.

bounded_search_summary.json records the exact scopes and counts of finite
local searches. Failure to find a candidate is not a lower bound.

emitter_search_summary.json and emitter_more_search_summary.json summarize
480 layouts from restricted logical-template families. They did not improve
the primary 198-subtree source within those families.

uncompiled197/ contains four 197-subtree transfer/cache programs using the
same U214 emitter. Their source-splice/control-flow audit is included. They
are research sources, not accepted binary Turing machines. The selected
U213 instead uses a 199-subtree source and succeeds through physical sharing.

context214.native.tm is a 214-state alternative with four K215-style return
rewrites, using ../inputs/u214_sites.json unchanged. All 5,109 symbolic cases
passed; context214_runtime.json records the result. Its blank initialization
takes 95,752 steps. The supported full checker can rederive this alternative
with code/validate_native.py, but this table is not the primary result.

rejected_reallocation_runtime.json records a different 214-state allocation
that passed source-prefix checks but failed to establish its contract at
source site 3256. Its table is deliberately not presented as a deliverable.

rejected31_81_counterexample.json contains a genuine concrete counterexample
to merging native31 into81 on original U214. The original table's correct
return takes654 steps; the rejected quotient takes616 and changes the tape.
No blank-reachability assertion is made for this supplied primitive frame.

rejected_four_rotations/ contains a four-rotation shortcut, explicitly
rejected. The separately implemented counterexample checker contrasts it
with the accepted final machine at source ordinal3337. Its seven-zero
address causes an erroneous one at tape cell29. The final two rotations
repair the layout; final U213 passes the same ordinal primitive and all
quantified contracts. See the report and its portable checker.

Historical absolute paths in saved exploration summaries identify their
construction environment; the accepted release reproducer uses only
relative package paths and needs none of those research environments.
