# Report159 — All orders asymptotics for subdiagonal partitions

This standalone report treats OEIS A238875, the number s(n) of weakly increasing partitions (lambda_1,...,lambda_k) of n with lambda_i <= i at every index. The empty partition contributes s(0)=1.

## Main results and precise scope

For beta=pi/sqrt(6n), the report proves a unique computable formal expansion

    s(n)/p(n) = sum_{j=0}^R c_j beta^j + O_R(beta^(R+1))

for every fixed integer R>=0, with c_j in Q[pi^(-2)]. The proved explicit coefficients are

    c_0 = 1/2
    c_1 = -1/8
    c_2 = -11/32 + 3/(4 pi^2)
    c_3 = -317/384 + 329/(64 pi^2) - 9/(8 pi^4)

The construction first bounds all omitted endpoint events uniformly, then reduces finitely many bottom/top patterns and their intersections to fixed shifted rank counts. A row/column insertion bijection includes both exceptional rectangle complements. Row insertion is allowed to change the boundary gap G_B; the subsequent column insertion establishes the required lower bounds. The exceptional counts are polynomially bounded, not necessarily polynomial functions.

The analytic input is Zhou's published complete fixed-rank expansion, specialized to k=2, m=0 and fixed j=abs(r), together with the classical Rademacher partition expansion. The article writes this source specialization explicitly and derives the cubic rank coefficient directly. It does not rely on an unproved general transfer from a local generating-function power series. Six small endpoint patterns give a compact independent explanation of the cubic correction.

The sequence is nondecreasing by adjoining a 1. For the ordinary threshold

    T(y) = min{n>=0 : s(n)>=y},

put c=pi/sqrt(6), F(x)=exp(2c sqrt(x))/(8 sqrt(3) x), and let x_0 be the large solution of F(x_0)=y. Explicitly,

    x_0 = c^(-2) W_{-1}(-c/sqrt(8 sqrt(3) y))^2.

There are computable smooth centers X_J=x_0+b_0+b_1 beta_0+...+b_(J-1) beta_0^(J-1), beta_0=c/sqrt(x_0), with

    ceil(X_J-C_J x_0^(-J/2)) <= T(y) <= ceil(X_J+C_J x_0^(-J/2))

for each fixed J>=1 and all sufficiently large y. In particular,

    X_2 = x_0 + 7/24 + 3/pi^2
          + (23/32 + 45/(2 pi^4)) pi/sqrt(6x_0),

has window radius O(1/x_0). The ceiling boundaries are essential: no unrounded T(y)=X_J+o(1) claim is made. The two ceilings eventually coincide or differ by one, but the theorem does not decide every adjacent-integer ambiguity.

The truncation order is fixed before the limit. No convergence, efficient general implementation, growing-order uniformity, numerically explicit error constants, onset, or finite-input asymptotic rounding certificate is supplied. The all-orders theorem is broader than the bounded software: coefficient extraction is implemented only through R=3, and no fourth coefficient is asserted.

## Antecedents and sources

Archibald, Blecher, Elizalde and Knopfmacher's 2025 paper formulated the half-proportion conjecture. Report156 proved that limit with elementary O(1/log n) error and a coarse inverse. Report159 is a separate refinement and credits both antecedents; no earlier report is changed or included in the source archive. Classical partition theory and the rank theorems of Liu–Zhou and Zhou are prior inputs, not claimed as new.

A bounded source/catalogue check found no duplicate of this exact all-orders refinement. This is not exhaustive scholarly priority clearance. The provenance file records identifiers, source hashes where available, inspection scopes, and limitations. Full third-party papers and full OEIS entry text are not redistributed.

## Package contents

- `Report159.pdf`: self-contained 17-page article
- `Report159.tex`: editable LaTeX source
- `companion.py`: bounded exact counts, finite combinatorial checks, and rational coefficient extraction
- `test_companion.py`: mathematical, validation, and output-safety tests
- `counts.json`: exact s(n) and p(n) for n=0,...,300
- `finite_checks.json`: finite verification results, coverage, and scope
- `endpoint_expansion.json`: R=3 result and all 201 shifted terms
- `data/oeis_prefix.json`: attributed 57-term A238875 numeric prefix
- `SOURCE_PROVENANCE.json`: source and attribution record
- `build_pdf.py`, `release_tools.py`: exclusive clean PDF build and local I/O helpers
- `make_zip.py`, `test_release.py`: fixed-allowlist deterministic packaging and release tests
- `SHA256SUMS`: sorted SHA-256 manifest of every allowlisted payload except itself

The ZIP includes the manifest; it does not include itself recursively. A separate digest identifies the archive. Working drafts, audit records, rendering images, unlisted files, and unrelated reports are excluded.

## Requirements and limits

The companion requires Python 3.10 or later and only the standard library. The recorded release toolchain is Python 3.12.14 and pdfTeX 1.40.26, TeX Live 2025/dev/Debian. File output requires POSIX directory-relative operations, O_NOFOLLOW/O_DIRECTORY, and hard-link support. No companion or release command accesses the network.

The PDF builder requires `pdftex` and `pdflatex`, plus fontenc, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, booktabs, longtable, array, microtype and hyperref. Poppler is used for visual QA, not by the build script.

The positive counting DP is indexed by length, weight and largest part, with a prefix-sum transition. It uses O(N^3) arithmetic operations and O(N^2) cells. Its workload cap is N<=300. Direct partition enumeration is capped at n<=32, with default verification through n=28. The endpoint cutoff is at most M=5, corresponding to extraction order R<=3. Marked vectors have length at most 5 and nonnegative entries at most 6; exact-value coordinates are at most 5 to allow the next lower-bound difference. Shifted analytic inputs are bounded by abs(r)<=32 and 0<=w<=100. Threshold values are integers from 1 to 10^1000.

Public integer arguments reject booleans and non-integer types. CLI integers must be canonical nonnegative ASCII decimals: no sign, spaces, leading zeroes (except zero), or non-ASCII digits. An explicitly supplied enumeration limit cannot exceed max_n; an omitted limit shrinks automatically to fit max_n.

## Companion replay

Run from the extracted package directory. Output defaults to stdout; use fresh `.json` names to save it:

```sh
python3 -B companion.py counts --max-n 300 --out replay_counts.json
python3 -B companion.py verify --max-n 300 --enumerate-to 28 --out replay_checks.json
python3 -B companion.py expansion --order 3 --out replay_expansion.json
cmp counts.json replay_counts.json
cmp finite_checks.json replay_checks.json
cmp endpoint_expansion.json replay_expansion.json
python3 -B companion.py threshold --value 1000000 --max-n 100
python3 -B -m unittest -v test_companion
python3 -O -B -m unittest -v test_companion
```

The threshold command searches actual counts beginning at n=0. In particular value=1 has first_n=0, including when max_n=0. If the chosen max_n is insufficient, reached is false and first_n is null; only T(value)>max_n has been established. No smooth-model value is substituted for an exact threshold.

The shipped verification enumerates 18,460 partitions through n=28 and performs:

- 29 direct subdiagonal/unrestricted count comparisons and all 57 supplied OEIS prefix terms
- 455,107 good forward maps and 455,107 good inverse maps, with weight/rank, commutation, collision, reconstruction and rectangle checks
- 80,997 mixed rank/weight identities across 49 vector pairs
- 4,466 pure-row exact/cumulative identities
- 35,616 first-failure union classifications and 21,736 unpadded endpoint equivalences
- 195 finite-difference box identities, including 52 with nonzero signed exceptions
- 28 exact baseline-minus-obstruction identities and 301 positive/subset count bounds
- 8,401 observed boundary-gap changes, confirming that the repaired map does not incorrectly demand invariance
- Exact rational extraction at each order 0,...,3, with the R=3 reduction yielding 22 bottom patterns, 64 top patterns, 1,408 intersections and 201 shifted terms

The unit tests also compute the six-pattern cubic cancellation without reusing the full shifted-term aggregation. Finite checks validate indexing, implementation and finite identities; they do not prove the analytic remainder or supply its numerical constants.

### Companion output safety

The companion never overwrites an existing target. It refuses symlink components, traversal, dot/empty components, trailing slashes, directories, FIFOs and other special-file targets. The output parent must already exist, be owned by the current user and have no group/world write bits. Output JSON is capped at 2 MiB. Prefix input is a regular file of at most 32 KiB, with strict schema, integer and duplicate-key checks.

Publication writes a complete private temporary file, flushes it, and links it exclusively to the new target name. Successful publication is atomic and no-clobber. A failure after that link, such as directory fsync failure, can leave the complete result present; inspect it rather than blindly retrying or deleting it. Temporary-name collisions are not removed as if they belonged to the current operation.

These safeguards assume a trusted environment without a malicious same-user actor concurrently changing ancestors or the source tree. Descriptor pinning reduces accidental path substitution; it is not a general operating-system sandbox.

## Clean PDF replay

Choose fresh build directories with existing trusted parents:

```sh
python3 -B build_pdf.py --output-dir /tmp/report159-build-one
python3 -B build_pdf.py --output-dir /tmp/report159-build-two
cmp /tmp/report159-build-one/Report159.pdf /tmp/report159-build-two/Report159.pdf
cmp Report159.pdf /tmp/report159-build-one/Report159.pdf
```

The builder creates the destination exclusively, isolates fresh LaTeX formats and caches, fixes epoch and PDF metadata, disables shell escape, and repeats compilation until references stabilize. The settled log must contain no warnings, missing characters, overfull boxes or underfull boxes. The `.tex` file is its only authoring input. Byte identity is expected within the recorded toolchain, not across different TeX versions, fonts or operating systems.

Existing destinations, static symlink components and parent traversal are refused. The parent must be trusted and free of adversarial replacement. The mkdir-then-open interval is not claimed to resist a malicious same-user process; subsequent operations are descriptor-pinned. Disabling shell escape does not make arbitrary modified TeX a sandboxed input.

## Manifest and archive replay

From the unchanged extracted package:

```sh
sha256sum -c SHA256SUMS
python3 -B -m unittest -v test_release
python3 -O -B -m unittest -v test_release
python3 -B make_zip.py --output /tmp/Report159_rebuild_one.zip
python3 -B make_zip.py --output /tmp/Report159_rebuild_two.zip
cmp /tmp/Report159_rebuild_one.zip /tmp/Report159_rebuild_two.zip
```

The packager checks every payload hash against the exact sorted allowlist and excludes unlisted files. It fixes ZIP timestamps, order, permissions and ZIP_STORED compression. Output is exclusive: no existing file, symlink, directory or special file is overwritten. The source tree and output parent must be trusted and nonadversarial. A failed output write can leave a new incomplete file; inspect it rather than blindly retrying or deleting it.

Changing a source file requires a new authoring/release action and a new manifest. A modified payload should fail the original manifest. Release tests check these refusals, allowlist enforcement, tamper detection and deterministic construction under normal and optimized Python.

No external publication, OEIS editing, author contact, public repository modification or upload is performed by this package.
