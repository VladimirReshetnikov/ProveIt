# Natural Boundaries at the Source Edge of Extensional Acyclic Digraphs

This research archive contains a self-contained article, its LaTeX source,
independent verification code, generated data, and two scientific figures.
The article answers Section 12.2, Question 1 of the earlier ProveIt report
*The source boundary of extensional acyclic digraphs*: every fixed-deficit
source-count generating function has a natural boundary. It also proves
dyadic radial limits, two-term logarithmic growth, growth of integral means
on every boundary arc, and natural boundaries for power-of-two residue
subsequences. The relevant OEIS entries are A182220, A182162, A001192, and
A182161. Attribution and the source snapshot are recorded in
[PROVENANCE.md](PROVENANCE.md).

## Contents

| File or directory | Purpose |
| --- | --- |
| `ead_natural_boundaries.pdf` | Complete article, including proofs and research questions |
| `ead_natural_boundaries.tex` | Main source, with embedded bibliography |
| `code/verify.py` | Exact combinatorial checks and high-precision numerical diagnostics |
| `code/make_article_tables.py` | Rebuilds the article's tables from `data/validation.json` |
| `data/` | Exact integer tables, numerical tables, validation report, run transcript, and generated LaTeX tables |
| `figures/` | Vector PDF figures and PNG previews |
| `requirements.txt` | Tested Python dependency versions |
| `Makefile` | PDF compilation and optional full regeneration |

## Rebuild the PDF

Run commands from this directory. The shipped figures and
`data/article_tables.tex` are sufficient; no Python run or repository
checkout is required to compile the article.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error ead_natural_boundaries.tex
```

Equivalently, run `make pdf`. A TeX installation providing pdfLaTeX and
latexmk is required, including the packages named in the source preamble
(in particular `lmodern`, `microtype`, `geometry`, the AMS packages,
`mathtools`, `booktabs`, `enumitem`, `fancyhdr`, `xurl`, and `hyperref`).
BibTeX and Biber are not required. The recorded build used latexmk 4.83
and pdfTeX 1.40.25, from TeX Live 2023/Debian.

## Regenerate computations, tables, figures, and PDF

The tested Python environment was Python 3.12.14, mpmath 1.3.0,
Matplotlib 3.10.8, and NumPy 2.3.5. The pinned dependencies require
Python 3.11 or later; Python 3.12 is recommended for matching the recorded
environment. Install them in a suitable Python environment, then run:

```bash
python -m pip install -r requirements.txt
python code/verify.py > data/run-output.txt
python code/make_article_tables.py
latexmk -pdf -interaction=nonstopmode -halt-on-error ead_natural_boundaries.tex
```

After installing the dependencies, `make regenerate` performs those last
three steps in order. To choose an interpreter, use for example
`make regenerate PYTHON=python3`. `make verify` regenerates computations and
figures only; `make tables` regenerates the small LaTeX tables only.
Verification ran in about 15 seconds in the recorded environment. The
scripts make no network requests and resolve their output directory from
their own file locations.

Use the default verification parameters to reproduce the shipped article:
64 triangle rows, exhaustive generation through size 7, profile blocks
5 through 11, radial blocks through 60, 128 retained terms per late block,
and 100 decimal working digits. `python code/verify.py --help` lists the
options. The article-table script and prose describe the default ranges;
changing parameters may require corresponding editorial changes.

## What the verification establishes

The exact checks use Python integers. Two separately implemented recurrences
agree on 2,080 source-triangle cells through size 64. Direct generation of
full sets as nested frozensets agrees through size 7, with 75,598 objects
at that size. The run also checks 2,080 source-support assertions, 2,080
covering inequalities, 242 finite-defect entries, 64 core bounds, and 112
direct binomial checks of the block implementation. `boundary_counts.csv`
contains 512 exact counts for sizes 1 through 128 and deficits 0 through 3.

The profile and radial tables use mpmath at 100 decimal working digits:
140 complex profile evaluations and 300 radial comparisons. Radial sums
include all finite-defect summands, with analytic bounds for omitted terms.
The largest recorded relative truncation bound is below `4e-58`; a
100-versus-140-digit endpoint comparison agrees within `2.5e-81`.
These floating-point evaluations do not enclose roundoff by interval
arithmetic. The finite checks and figures illustrate and test the
implementation; the article's mathematical proofs establish the infinite
statements. No proof-assistant verification is claimed.

`data/validation.json` is the machine-readable run report. Exact count files
are deterministic for the given parameters. Runtime fields and PDF metadata
can change between runs, so byte-for-byte identity of every artifact is not
an intended reproducibility criterion.
