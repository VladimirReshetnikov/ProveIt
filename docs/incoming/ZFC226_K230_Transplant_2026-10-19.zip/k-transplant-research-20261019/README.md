# A 226-state binary Turing machine calibrated to Con(ZFC)

**Result:** this package constructs a deterministic, one-tape, two-symbol Turing machine with **226 working states**, started on the all-zero tape, whose nonhalting is provably equivalent in ordinary ZFC to `Con(ZFC)`. It saves four states from Elliot Glazer's pinned K230 construction and nine from the ProveIt 235-state comparison point.

Read [report.pdf](report.pdf) for the mathematical proofs, construction, formalism comparison, and complete transition table. [report.tex](report.tex), [sections/](sections/), and the equational supplement contain its editable sources. The literal machine, deterministic builders, independent audits, and executable certificates are included here.

The new 226-state result has an **ordinary mathematical transport proof with executable certificates**. The smaller table has not been newly formalized or kernel-checked in Rocq. The pinned upstream 230-state endpoint has the separately identified Rocq build evidence described below. No minimality claim is made.

## Exact statement and conventions

Let `M226` denote exactly [machines/k226.tm](machines/k226.tm). With `Prf_ZFC(p, bottom)` the finite-proof predicate for the pinned ordinary first-order ZFC calculus, including Foundation and Choice, define

$$
\operatorname{Con}(\mathrm{ZFC})
:=\neg\exists p\,\operatorname{Prf}_{\mathrm{ZFC}}(p,\bot).
$$

The finite transformations and induction arguments in this package, composed with the pinned K230 finite-refutation calibration, establish

$$
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halts}(M_{226},\mathrm{blank})
\longleftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
$$

Proving this biconditional requires no consistency assumption. If ZFC is consistent, the machine actually never halts, and ZFC cannot prove that nonhalting by the second incompleteness theorem. Bare consistency alone is not used to claim that ZFC also cannot prove the false halting sentence; that further assertion needs an appropriate soundness hypothesis. This construction proves no unconditional consistency statement.

| Item | Value |
|---|---|
| Canonical table | [machines/k226.tm](machines/k226.tm) |
| Working states | `0` through `225` |
| Initial state and head coordinate | `0`, `0` |
| Initial tape | Identically `0` |
| Alphabet and tape | `{0,1}`, one two-sided tape |
| Permitted moves | `L` and `R`; no stationary moves |
| Complete transition rows | `452` |
| Separate halt state | `226`, with no outgoing transition rows |
| Runtime dispatcher | `82` |
| Exact blank initialization | `409,835` transitions |

Each table row is `state read write direction next_state`. The halt state is excluded from the working-state count. [machines/k226_old.tm](machines/k226_old.tm) retains the inherited K labels, with start `0`, dispatcher `84`, and halt `254`; [machines/renumbering226.json](machines/renumbering226.json) is the checked literal bijection to the canonical table. Renumbering changes no transition action or execution time.

The following SHA-256 digests include each file's actual header and final newline:

```text
machines/k226.tm
789e9d1cf04567223823bfdda7d0b4922d7018718fc0daf67c6f5b0c6b4c9b26

machines/k226_old.tm
0d6740bbc94a92c9696ed92732b1828bec89109f8ebb6859bbb9197e2076ec89

source/sites226.json
31aaece78d025fbc262e742411e75e24eef9435fe196c67e65b995e8b833fe61
```

## Reproduce the construction and checks

Run these commands from this directory with **Python 3.10 or newer and enabled assertions**. The new replay uses the standard library and requires no network access. Do not use Python's `-O` or `-OO` modes.

```bash
python3 -B reproduce.py --output-dir replay-quick
python3 -B reproduce.py --full --output-dir replay-full
```

Quick reproduction checks the pinned input bytes; rebuilds the source and literal machine; independently audits source equivalence; checks canonical renumbering; replays blank initialization with sparse and dense tape implementations; rechecks local folds and helper identities; validates the supplied runtime receipts and case-array pins; and rebuilds the optional E639 codec artifacts.

**Full reproduction additionally rederives every unbounded symbolic runtime case for both the original K230 machine and the final 226-state machine.** It constructs fresh case arrays and compares them with the delivered evidence. Quick mode's validation of stored receipts is not a fresh derivation of those cases. Elapsed wall times are informational and need not reproduce byte for byte. The delivered [full replay record](evidence/full_replay/replay.json) and [provenance note](evidence/full_replay/README.txt) identify the successful fresh execution and distinguish its input inventory from the final release manifest.

The delivered full checks cover:

| Check | Original K230 | Final machine |
|---|---:|---:|
| Working states | 230 | 226 |
| Source leaf occurrences | 5,125 | 5,121 |
| Guarded runtime cases | 6,660 | 6,656 |
| Symbolic rules used across all cases | 1,605,903 | 1,615,284 |
| Minimum proved instruction duration | 13 | 13 |

The final source has 211 distinct DAG nodes, maximum path depth 41, and maximum consecutive zero-run length 6. The runtime proof covers unbounded natural register values, the tape gap, and arbitrary finite spare tails under the precise frame preconditions in the report. It does not enumerate a bounded range of register values. Literal steps, unary-run inductions, and finite-list inductions establish exact successor frames. All 452 final transition rows are visited by the complete symbolic replay; the quantified endpoint checks, rather than row coverage alone, establish correctness.

To rebuild the PDF, use a LaTeX installation containing the packages named in `report.tex`:

```bash
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The original K230 Rocq build is a separate workflow requiring its pinned toolchain and upstream proof dependency. See [vendor/k230-rocq/README.md](vendor/k230-rocq/README.md); the Python replay above does not invoke Rocq.

## How the four states are saved

K230 already contains two early folds from the ProveIt 243-to-235 sequence. They cannot be counted again. Its shorter, changed source tree also alters the tape-bit conditions used by later folds, so the remaining savings require a new coordinated layout.

The construction first normalizes four closed transfer-plus-one loops. Both old and new forms send `(R5,R6)=(a,b)` to `(a+b+1,0)`, preserve the other registers, and terminate after exactly `3*b+2` primitive instructions for every natural `a,b`. The independent source audit verifies all 6,639 guarded outgoing edges of the 5,109 unchanged instructions, all macro entry and exit boundaries, and the initial root entry.

Thirteen subsequent source reassociations preserve all 5,121 opcode/operand pairs and all 6,655 guarded successor edges at every stage. Two rotations move a fused `CB1` leaf; the corresponding binary repair shares an existing clear-one helper chain. The final layout restores maximum zero-run length six, allowing the existing boundary scanner to remain sufficient. The exact subtree occurrence paths, decoder edits, and callback repairs are in [source/source_rotations.json](source/source_rotations.json).

The resulting literal folds remove original K labels `79`, `140`, `175`, and `65`. The construction retains context-dependent helper obligations explicitly and checks the final machine directly. Its halting calibration composes:

1. Exact blank initialization and universal runtime for the final machine.
2. Total-macro substitution and finite guarded-graph isomorphisms for the source.
3. Exact blank initialization and universal runtime for the original K230 machine.
4. K230's pinned equivalence between blank halting and a finite ordinary ZFC refutation.

These arguments use finite syntax, finite tables, natural-number induction, and finite-list induction available in ZFC. The internalization is specific to these constructions; it assumes no general ZFC soundness theorem for Rocq.

## Upstream proof status

The K230 input is pinned to commit [`3142e4dd980f0be12f4abb636c4ae2528afc17eb`](https://github.com/elliotglazer/k230-rocq/tree/3142e4dd980f0be12f4abb636c4ae2528afc17eb). Its literal table has SHA-256:

```text
e7ccbcec074534cfd955f0ab94d16f13594e81974074309dc2ce663b9dfd7ba8
```

The supplied [upstream CI records](evidence/upstream-ci/) come from [GitHub Actions run 39258562285](https://github.com/elliotglazer/k230-rocq/actions/runs/39258562285), artifact `k230-linux-verification` (`12192455062`), at that commit. They report **216 compiled sources**, **two endpoint declarations closed under the global context**, and a successful independent `coqchk` of `K230.Correct230` with exit code zero.

The local audit checks all 103 manifest-pinned K230 local files, compares all 460 machine rows with the literal Rocq `Table230.v`, and checks the CI manifest, machine, dependency, and kernel-log pins. These are retained upstream build records: Rocq was not installed for this research session, and the 226-state table has no new Rocq endpoint. The new source and machine transports are supplied as ordinary proofs and executable certificates.

## Separate formalism result: E639

[supplement/e639/](supplement/e639/) contains a separate **639-bit equational packet**: seven equations, nine operation symbols, four local variables, and the ground query `Q(d)=d`, all charged under the fixed codec. A descriptor-binding construction removes six term nodes from the inherited E663 packet, saving 24 bits. The packed file is 80 bytes with one trailing padding bit excluded from the logical count.

The report gives both model directions for its calibration relative to raw EPSC, with the inherited raw-EPSC/ZFC comparison stated explicitly. The relevant first-order theory is the equations **together with `Q(d) != d`**; the equations alone always have a singleton model.

**639 is a bit count, not a Turing-machine state count.** E639 is not the frontend of the delivered 226-state machine. A complete binary proof-search interpreter and blank writer for it remain to be implemented and counted. No global packet-size or machine-state minimum is claimed. Its standalone codec can be replayed with:

```bash
python3 -B supplement/e639/build_e639.py --out replay-e639
```

## Package map and incorporation

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf`, `sections/` | Main report, proofs, and generated table appendix |
| `machines/` | Final literal tables and state bijection |
| `source/` | Final and normalized source, loop and rotation certificates |
| `build_machine226.py`, `replay_k230_source.py`, `source_tools.py` | Deterministic portable builders |
| `verification/` | Independent audits, startup checks, runtime adapter, and unchanged inherited engine |
| `evidence/` | Runtime case arrays, receipts, source and table audits, upstream CI records |
| `construction/` | Rebuilt intermediates and local construction certificates |
| `comparison/` | Pinned predecessor data used for the transplant comparison |
| `vendor/k230-rocq/` | Pinned K230 sources, manifest, and original notices |
| `supplement/` | E639 and the attributed inherited equational work |

The package is intended for incorporation into a ProveIt research directory, with its archive optionally retained under `docs/incoming/`. Read [ATTRIBUTION.md](ATTRIBUTION.md) for exact predecessor pins, compiler and proof-library credit, and license scope. The inherited notices do not imply a blanket license for all bundled upstream custom proof sources.
