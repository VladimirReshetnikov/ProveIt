# Geometric enumeration counters for the ZFC machine

Research contribution for ProveIt, 17 October 2026.

**No machine below 252 working states is claimed.** The strongest assembled
artifact is a **253-state prepared-frame runtime**. Its inherited blank start
escapes right forever after a certified 102-step prefix, so it is not the
requested consistency-calibrated machine. The archive contributes checked
source transformations, a new literal geometric loader, reproducible binary
experiments, and a precise account of what remains open.

## Main results

1. The candidate counter can be represented by the existing tape gap. The
   final loader has seven new states and uses two previously unused rows of
   retained runtime states. On a valid input frame it realizes
   `(gap g, L=0, head h) -> (gap g+1, L=g+1, head h-g-2)`, returning with an
   empty source PC and leaving every other register and spare cell fixed.
   Its exact duration including dispatch is `2*g*g + 15*g + 40`.
2. A source loop reorganization removes the old counter's fetch/copy code.
   Complete structural sharing gives **203 -> 197 decision pairs**. The
   loader is charged separately in the actual binary count. The final
   runtime has **244 retained old states + 7 loader states + 2 shell states**.
3. `GapClock.lean` checks exact source scheduler refinements for both an
   increment-at-end design and the final increment-at-start design. The
   final observation is simply `logical N = physical gap` at command
   boundaries.
4. `ParityCandidates254.lean` proves that a derivable contradiction gives
   arbitrarily large uniformly halting candidate words in either parity
   class. `EnumParity254.lean` proves the full stride-two source enumerator
   halts iff falsity is derivable, from every state satisfying the original
   soundness invariant. This supports the earlier nine-state loader and
   remains available for future physical designs.
5. `EnumNoFiller254.lean` proves that omitting the truth-stack filler after
   successful MP preserves the complete enumerator's halting behavior.
   The full original calculus, equality, GEN and CP/GIC bundle are retained.
   The direct frozen-table edit changes only `(204,1)` target `113 -> 132`.
   Neither this edit alone nor its combination with the final gap runtime
   gives a state saving in the measured controls.

The report gives full mathematical arguments and explicitly distinguishes
source theorems, conditional binary instruction audits, finite checks,
prepared-frame runtime counts and blank-tape consistency endpoints.

## Start here

- `report.pdf`: the complete research report.
- `report.tex` and `sections/`: editable LaTeX source.
- `formal/`: four new Lean files, eleven pinned original dependencies,
  an offline fresh-build driver, source manifest, license and complete logs.
- `machine/`: the portable assembler, literal tables, label map, universal
  loader invariant, exact-tape harnesses, source pins and bootstrap escape.
- `experiments/no_filler_frozen/`: the one-row frozen-table edit, all 8,366
  instruction checks and the completed 55,471-recipe fold census.
- `experiments/no_filler_unit/`: the no-filler edit applied to the final
  253-state unit-stride runtime, with 8,356 instruction cases and 288 loader
  cases. All 506 rows remain required.
- `clock_schedule.py`: independent exact-integer schedule/coding replay.
- `gap_dag_audit.py`: source counts and path/return audit from `Prog254.v`.
- `data/`: the baseline audit and scoped supplementary search records.

The `*.tm` files in `machine/machines/` are **research runtime artifacts**.
The old-label and canonical complete tables have 253 working states. Their
start directives record the inherited start used for the negative bootstrap
certificate. Partial loader patches reference inherited states and are not
standalone machines. The separate no-filler tables likewise have no proved
new blank initialization.

## Reproduce the principal finite results

Python 3.10 or later is sufficient for these checks. No network, repository
checkout or third-party Python package is needed. From this directory:

```sh
python3 -B clock_schedule.py --candidates 100000 --output data/clock_schedule_results.json
python3 -B gap_dag_audit.py --source machine/inputs/Prog254.v --output gap-dag-audit.json
python3 -B machine/code/assemble_gap_runtime.py
python3 -B experiments/no_filler_unit/check_no_filler_unit253.py --runtime-root machine --output experiments/no_filler_unit/results
```

For the direct frozen no-filler edit and its full census:

```sh
python3 -B experiments/no_filler_frozen/nofiller_frozen_search.py --input-dir experiments/no_filler_frozen/inputs --output experiments/no_filler_frozen/replay
```

Use `--skip-folds` for only the 8,366-case audit and finite bootstrap check.
The complete census took about 28 seconds in the recorded environment;
that is an observation, not a runtime guarantee.

The affine audit is universally parameterized by its zero-gap and register
variables **conditional on the four inherited register-box contracts**.
The new complete binary simulation has not been serialized in Lean. The
loader's all-gap interval proof is in the report and the machine TeX note;
the finite loader suite supplements it.

## Reproduce all formal proofs from source

Install Lean **4.32.0**, commit
`8c9756b28d64dab099da31a4c09229a9e6a2ef35`, then run:

```sh
python3 formal/reproduce.py --lean /path/to/lean
```

All **15** bundled modules are rebuilt into a fresh temporary directory.
There are no bundled `.olean` files or dependency caches. The original
calculus dependencies and all four new proof modules passed the final
fresh build. The reported new endpoints have no admissions or custom axioms.
Their audits list only `propext`, `Classical.choice`, and `Quot.sound`;
the independent counter module uses only `propext` and `Quot.sound`.
See `formal/manifest.json` and `formal/verification/verification.json`.

## Build the report

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

The PDF uses standard TeX packages and no external images or network assets.
The supplied PDF was rendered and visually reviewed. `data/pdf_qa.json`
records the final layout check.

## Scope of supplementary files

The generic 281-state Wade control is retained under
`experiments/mp_no_filler_generic/`; its driver additionally requires the
pinned ProveIt checkout via `--repo`. The recorded tables, helper controls
and state counts are included. It is separate from the offline final
runtime assembler.

The supplementary loader-fold driver uses the bundled machine helpers.
The mixed-box driver additionally requires the pinned repository through
`--repo`. Their recorded JSON files state the bounded search scope. The
254-state start-label census concerns the included earlier intermediate
table, not all possible initializers of the final 253-state architecture.
None of these negative searches is a lower-bound proof. No hypothetical
251-state table is included.

## Source pins and attribution

Repository: <https://github.com/VladimirReshetnikov/ProveIt>

Inspected commit: `85633fd2f57b5dca16f87667699134d1b500ebc0`.

The original machine is attributed to Mira-Cult, its verification to Jeff,
the compiler framework to Wade, and the public 253-state reduction to
mira-emmy. The inherited upstream pin is
`297ab8df7e5de329605c3875b4934643b371a5e3`; the public reduction head is
`0d544f2a2e3c18f12278441a74b7879f31cbe856`.

The given 252-state canonical table has SHA-256
`8dae0c2359aa8bf87d32543b9e53e1f87fe4716c016a4e2fd174bfe09e520797`.
The new **runtime-only** tables have SHA-256:

- Old labels: `96647b74b9f457828445705a849670d53d1fe25c8312977557d3bc449988b822`.
- Canonical: `792c74314caa940e858d96ac70d3ab5bef6ed37baf6b7fc84e37185e4c3421af`.

Original license and attribution notices accompany the vendored sources.
`MANIFEST.json` and `SHA256SUMS` identify the delivered bytes. Verification
logs naturally change if a replay records new paths or timings; the
literal machine and proof source identities remain independently pinned.

The ordinary mathematical ZF/ZFC equiconsistency comparison is distinguished
in the report from its remaining serialization and arithmetic-base-theory
integration tasks in the repository. The user asked for provability in ZFC;
we do not silently replace that target by provability in PA, or claim that
an external Lean theorem alone proves its own internal-ZFC interpretation.
