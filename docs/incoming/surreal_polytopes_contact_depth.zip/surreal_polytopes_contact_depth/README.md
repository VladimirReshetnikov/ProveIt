# Exponential Contact Depth in Surreal Polytopes

**Face-lattice-forced arithmetic, rigid scale towers, and lower bounds for rational shadow realizations**

Research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.
AI-assisted; not independently refereed. No new Lean formalization is claimed.

## Main result

For every k >= 1, the article constructs a labeled polytope family with
8k+16 vertices in dimension 4k+10, and a prescribed rational labeled shadow.
All vertices and the dimension survive at the shadow. The minimum homogeneous
degree of a rational vertex arc preserving the labeled face lattice and
approaching that shadow lies between

    ceil(2^k / (16k+48))  and  2^k.

The labeled face lattice reconstructs intrinsic projective cross-ratios
satisfying x_(i+1) = x_i^2. Cofactor degree bounds for the reconstruction
make the lower bound apply to every competing rational arc, not merely to
the explicit coordinate construction.

The article also proves an addition-chain generalization, valuation identities,
and exact ramification divisibility after using the deepest observable as
the parameter. It includes ten further research questions and a staged
formalization plan.

The invariant concerns rational parametrization degree with a prescribed
labeled limit. It is not arithmetic-circuit length, valuation-group rank,
static bit complexity, or the size of a complete face-list input.

## Contents

- `surreal_polytopes_contact_depth.tex`: complete LaTeX source, embedded bibliography.
- `surreal_polytopes_contact_depth.pdf`: compiled 24-page article.
- `verify.py`: exact finite checks.
- `verification.json`: successful output for k=1,...,6 and one transformed reconstruction.
- `requirements.txt`: optional dependency for the reconstruction test.
- `build.sh`: PDF build command with a pdflatex fallback.

## Build the PDF

Use a normal TeX Live installation with the packages named in the source,
including `newpx`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `enumitem`,
`booktabs`, `longtable`, `fancyhdr`, `xurl`, and `hyperref`.

    sh build.sh

Or:

    latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_polytopes_contact_depth.tex

Without latexmk, run pdflatex twice (a third run can be used if cross-reference
warnings remain). No BibTeX database or external image is needed. Font files
are not included.

## Reproduce the finite checks

Python 3.9 or newer is recommended. For the optional SymPy reconstruction test:

    python -m pip install -r requirements.txt
    python verify.py --max-k 6 --output verification.json

The sparse-polynomial determinant tests use only the standard library:

    python verify.py --max-k 6 --skip-reconstruction --output verification_no_sympy.json

Run without Python's `-O` option; the program checks that assertions are enabled.
The program supports 1 <= max-k <= 12, with larger checks potentially expensive.
The mathematical theorem is not restricted to this finite testing range.

## What was checked

The supplied run checked 12,180 projective 3-by-3 minors across k=1,...,6,
all specified arithmetic incidences, the coefficient bound underlying the
uniform parameter interval 0<t<1/6, exact signs at t=1/7, and the survival
of rank three after each single-column deletion.

For k=1, an invertible constant projective transformation mixes the ambient
coordinates. The program recovers all twelve pair-complement facet normals,
then reconstructs the cross-ratios 1/7 and 1/49 by exact rational arithmetic.
SymPy 1.14.0 was used in the supplied run.

This is NOT a full face-lattice enumeration, a general proof in a theorem
prover, a test of all rational arcs, or an independent review of the proof.
The general arguments are in the manuscript.

## Provenance and scope

Repository tree observed at:

    6996fee43cc97b6c16351def7507d59a95bf62f0

Inspected source:

    Algebra/SurrealNumbers/Surreal/Algebra/Geometry.lean

The repository comparison is limited to that finite-coordinate-geometry
source and the surreal project guide. No repository-wide audit or new
repository build was performed.

The previous user-library manuscript *Finite-Scale Geometry of Surreal
Liftings* is cited for the fixed-real-base comparison; the current lower-bound
proofs do not depend on its results.

Projective arithmetic, oriented-matroid sign data, and Lawrence recovery are
classical. The proposed contribution is the explicit shadow-sensitive degree
theorem and its quantitative synthesis. Literature-wide priority of this
formulation has not been independently established. No solution of a named
published open conjecture is claimed.
