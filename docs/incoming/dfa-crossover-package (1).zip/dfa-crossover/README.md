# Finite crossover stabilization for deterministic automata

This package contains two results for complete binary DFAs:

1. Deciding finite constrained self-crossover stabilization is coNP-complete, for both the parallel and frozen-source clocks. Its complement is NP-complete. The membership proof also works over any explicitly given finite alphabet.
2. The maximum finite aligned-fragment rank has quadratic order. For every m >= 2, an explicit (m + 6)-state complete binary DFA has finite maximal rank R in the interval

       (m - 1)^2 + 2 <= R <= (m - 1)^2 + 4.

   Consequently, for s >= 8,

       (s - 7)^2 + 2 <= F_DFA(s) <= 2*(s - 1)^2 + 3.

The lower witness is not asserted to attain the constructed language's maximal rank. All state counts include the selector and rejecting sink.

## Files

- `dfa-crossover-stabilization.pdf`: ten-page article with complete arguments, source dependencies, scope, and limitations
- `dfa-crossover-stabilization.tex`: standalone editable LaTeX
- `check_stripes_exhaustive.py` and `stripes-exhaustive.json`: exhaustive small safe-core/stripe comparison
- `check_stripes_random.py` and `stripes-random.txt`: seeded larger safe-core/stripe comparison
- `check_rank_family.py` and `rank-family.json`: deterministic rank-family witnesses and literal seed enumeration
- `check_gate_completion.py` and `gate-completion.json`: independent gate-completion and rank-witness tests
- `build.sh`: standard two-pass PDF compilation
- `SHA256SUMS`: checksums

## Reproduce the tests

Use Python 3 with its standard library. Do not use `-O`; assertions implement the comparisons.

    python3 check_stripes_exhaustive.py > stripes-exhaustive-new.json
    diff -u stripes-exhaustive.json stripes-exhaustive-new.json
    python3 check_stripes_random.py > stripes-random-new.txt
    diff -u stripes-random.txt stripes-random-new.txt
    python3 check_rank_family.py > rank-family-new.json
    diff -u rank-family.json rank-family-new.json
    python3 check_gate_completion.py > gate-completion-new.json
    diff -u gate-completion.json gate-completion-new.json

The exhaustive stripe test covers all 5,898 labelled complete binary DFAs on one through three states, with fixed initial state and every final set, checking 26,881 live residues. The seeded test covers 1,519 complete binary DFAs on one through eight states (seed 153735).

The rank-family test checks 24 alternating witnesses through m = 25, with largest tested rank 578, and 14,308 literal seed words. Those 14,308 are seed-membership checks, not separate rank calculations. The independent completion checker verifies 1,829 gate-state cases for m = 2,...,60 and 19 alternating witnesses through m = 20.

The finite tests are implementation and consistency checks. They do not substitute for the proofs of the SCC-stripe theorem, all CRT reduction instances, the complexity result, or the asymptotic rank bounds. No proof-assistant formalization is supplied.

## Compile

A working pdfLaTeX distribution with amsmath, amssymb, amsthm, lmodern, geometry, booktabs, microtype, and hyperref is sufficient.

    sh build.sh

The delivered PDF has been compiled and every page visually inspected.

## Sources and attribution

Pinned ProveIt source:

https://github.com/VladimirReshetnikov/ProveIt/blob/1bd730779e8bc44c8976dcd9f38cad86a0d21c26/SetTheory/Cardinals/docs/reports/automata-and-formal-languages/constrained-crossover-closure/article.tex

The complexity result answers Part II, Question 24.1. It uses the source's periodic-interior, safe-core, and rank-clock results as credited prerequisites. The complete-DFA quadratic family also resolves the DFA rank-order question left in the earlier companion NFA note.

CRT prime-residue encoding and clause testers are explicitly credited to Stockmeyer and Meyer, STOC 1973, Theorem 6.1. Related selector-to-cycle DFA constructions are credited to Gawrychowski et al., “Existential length universality,” arXiv:1702.03961v5. The improved universal upper bound 2*(s - 1)^2 + 3 is imported from the companion rational-slope article's application of Schwarz's 1970 relation-power theorem.

The claimed additions are the polynomial SCC-stripe certificate, its coNP classification with the crossover-specific monochromatic/cylinder wrapper, and the deterministic quadratic-rank family. No exhaustive worldwide priority claim is made.

Prepared 1 October 2026 for Vladimir Reshetnikov.
