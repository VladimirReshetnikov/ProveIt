# A cyclic algebraic substrate for small ZFC-consistency machines

Research report prepared for Vladimir Reshetnikov / ProveIt, 17 October 2026.

**Main result:** an explicit nine-equation algebraic layer conservatively represents the usual three commuting complemented closures. Its basis has 75 expanded term nodes, compared with 112 for the direct basis after redundant idempotence equations are deleted. A term-equivalent eight-equation version uses three proper operators and 90 nodes.

**No new binary machine below 253 states is claimed.** The finite source, its coded-model wrapper, the algebraic bases, a complete reference rewrite checker, and phase-placement optimizers are supplied. The pairing-relative three-variable translation, the modal translation, their fully expanded ZFC-specific target, and the new binary backend are not supplied.

## Read first

- `article.pdf` — complete report with proofs, source audit, experiments, and implementation plan.
- `article.tex` — self-contained editable LaTeX source; bibliography is embedded.
- `data/target_contract.json` — machine-readable completion and non-claim ledger.
- `notes/finite_source_audit.txt` — exact source normalization and the repaired Collection-from-Capture argument.

The report is the authoritative synthesis. The other notes preserve the independent development and audit records; some commands and paths in those notes refer to the research workspace. Use the commands in this README for this archive.

## Reproduce all finite checks

Requirements: Python 3.10 or newer, standard library only. No network, Lean, Coq, or external repository checkout is required.

```sh
python3 reproduce.py
```

The runner makes a temporary copy of the code, runs the finite suites, and writes fresh results under `reproduced/`. It compares deterministic results with the reference snapshots under `data/`, ignoring elapsed-time fields. It leaves the recorded snapshots untouched. It also regenerates the finite 14-sentence source and its membership wrapper. Physical Python memory and stack limits are not a model of the ideal unbounded proof search.

The main checks are:

| Check | Reference evidence |
|---|---|
| Ground equation checker, codecs, rule matching, negative controls, E8 conversion | `data/rotation9_evidence.json` |
| Independent cyclic-product and closure diagnostics | `data/cyclic_audit_results.json` |
| Three-phase compiler and independent native enumeration | `data/phase_optimizer_results.json` |
| Six-phase compiler and independent native enumeration | `data/phase_optimizer8_results.json` |
| Finite source transcription on all 530 binary structures of sizes 1–3 | `data/finite_source_review_results.json` |
| Coded-model wrapper, arbitrary ambient relations, shadowing and input validation | `data/graph_wrapper_results.json` |
| Two attributed tables, hashes, rows, complete bootstrap tapes and heads | `data/public_baseline_audit.json` |

These finite checks support implementation correctness. The unrestricted mathematical statements are proved in the report; no local kernel compilation or formal TM refinement is claimed.

## Compile the PDF

Requirements: a standard TeX Live installation providing `latexmk`, `pdflatex`, Latin Modern, AMS packages, `microtype`, `geometry`, `booktabs`, `longtable`, `enumitem`, `fancyhdr`, `listings`, `xurl`, `hyperref`, and `bookmark`.

```sh
make pdf
```

Without `make`, run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The PDF has no external figures, bibliography database, or hidden source dependencies.

## Individual programs

All four optimizer/test modules must remain together under `code/`, because the six-phase implementation uses the three-phase utility module and its independent test model.

```sh
python3 code/test_phase_optimizer.py \
  --reference code/rotation9.py --output phase9.json
python3 code/test_phase_optimizer8.py --output phase8.json
python3 code/review_nbg14.py
python3 code/finite_nbg.py finite_source.json
python3 code/graph_wrapper.py finite_source.json packed_source.json
python3 code/audit_public_baselines.py \
  --machine254 benchmarks/zfc_254.tm \
  --machine253 benchmarks/zfc_253.tm --output baseline_check.json
```

`test_rotation9.py` and `cyclic_audit.py` write their result beside the script when run directly; the unified runner isolates those writes. The wrapper test also generates a small synthetic example; that example is expressly not a ZFC-strength theory.

## Exact artifacts

### Logical source and target pipeline

- `data/finite_nbg14.json`: fourteen closed formulas over native equality and one binary relation, obtained from the explicitly normalized Friedman NBG* presentation after definitional elimination of the set predicate. Total: 752 formula nodes; variable labels are excluded.
- `data/finite_nbg14_packed.json`: the fully expanded pure-membership coded-model sentence for that source, totaling 10,182 formula nodes. This is still a first-order sentence, not the final modal or algebraic target.
- `data/basis_payload.json`: exact direct controls and the nine- and eight-equation bases, plus node counts and prefix strings.
- `code/rotation9.py`: fixed contextual-rewrite kernel, total natural-number codecs, exhaustive ideal search interface, optional ground-only generator rule, and exact basis definitions.
- `code/phase_optimizer.py`, `code/phase_optimizer8.py`: linear-time phase-cost computation with expression reconstruction. Optimality is for the explicit local grammar, not every algebraically equivalent term.

The nine identities alone have small models and do not have ZFC consistency strength. Strength is carried by a **designated ground disequation** whose target is specified mathematically through the pairing/modal translations. Its final string is not supplied.

### Benchmarks

- `benchmarks/zfc_254.tm`: Mira-Cult's 254-state binary machine at upstream pin `297ab8df7e5de329605c3875b4934643b371a5e3`.
- `benchmarks/zfc_253.tm`: mira-emmy's public PR20 reduction at head `0d544f2a2e3c18f12278441a74b7879f31cbe856`, building on Mira-Cult and Jeff.

Both have a blank bi-infinite binary tape, start state 0, L/R moves only, and a separate halt state excluded from the count. They are unchanged attributed benchmark data, not newly constructed machines. See `NOTICE.txt` and `data/provenance.json` for attribution, exact hashes, and the upstream license boundary.

## Important source audit result

The report repairs an ambiguity in the source's Collection-from-Capture proof. The original code `{x,{x,y}}` can cover an input through its second member. A finite counterexample is supplied. The replacement `{x,{b,y}}`, with a set `b` outside the union of the input set, ensures that Capture covers the first component. It changes no axiom and needs neither Choice nor Foundation. Other local printed-formula and proof-text normalizations are listed explicitly.

The independent semantic review validates the intended axiom transcription on small structures; it is not a proof-assistant verification of the entire external NBG equivalence proof.

## Repository integration

The report is written against ProveIt pin `8cf840b8a26d002041e7a26dc9688ce7ce5fd751`, and discusses the three requested commits plus the newer completed L2 register-program layer. No repository files have been modified or remote commits created by this deliverable.

The exact files can be imported as a new source report. Keep the attribution notice with the two benchmark tables. `MANIFEST.sha256.json` records the delivered file contents. Build intermediates, downloaded source-paper PDFs, local clones, and the large exploratory trace are intentionally absent.
