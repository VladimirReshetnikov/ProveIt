EFFICIENT INTERPOLATION IN GOWERS' SZEMEREDI FRAMEWORK
Exact sampling losses, shared refinements, and simultaneous polynomial recurrence
Prepared for Vladimir Reshetnikov — 6 October 2026

CONTENTS

gowers_interpolation.tex
  Standalone article source with an embedded bibliography.
gowers_interpolation.pdf
  Compiled article.
figures/sampling_extrema.pdf and figures/sampling_extrema.png
  The publication figure and a raster copy.
verification/
  Reproducible finite diagnostics and numerical illustrations.
provenance/source-audit.json
  Pinned source identities, relevant statement statuses, and distinctions
  between the original publication and the edited repository transcription.

The article proves a finite common-sampling bound, an exact minimax
characterization, a deterministic conditional-expectation algorithm, and a
sharp Poisson asymptotic. It develops polynomial interpolation after one
shared refinement of the sampled slices, including weighted hypotheses and
explicit box synchronization conditions. A complementary part applies the
cited simultaneous recurrence theorem to polynomial phase partitions and
proves a degree-sensitive obstruction. The article also contains a source
audit, a practical Lean integration outline, and further research questions.

BUILD THE PDF

Run the following command from this unpacked directory:

  latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_interpolation.tex

Requirements: a LaTeX installation with pdfLaTeX, latexmk, and the packages
listed at the top of the source (including the AMS packages, Latin Modern,
microtype, geometry, hyperref, and cleveref). A normal full TeX Live or
MiKTeX installation is suitable. The bibliography is embedded; no BibTeX
run is needed. The supplied PDF figure is sufficient for compilation, so
regenerating figures is optional.

RERUN THE DIAGNOSTICS

From this directory, with Python 3:

  python3 verification/verify_sampling.py
  python3 verification/verify_polynomial.py

These two scripts require only Python's standard library. The sampling
script checks exact hypergeometric probabilities, finite minimax values,
conditional-expectation anchor selection, and finite-field interpolation.
The polynomial script checks determinants, finite Newton-lift identities,
and the explicit modular example.

The scripts write their results to:

  verification/sampling_results.json
  verification/polynomial_results.json

To regenerate the figure and the occupancy constants:

  python3 verification/make_figures.py

This script additionally requires Matplotlib. It writes:

  figures/sampling_extrema.pdf
  figures/sampling_extrema.png
  verification/poisson_constants.json

On systems where Python 3 is invoked as "python", replace "python3" in
these commands accordingly. The diagnostics are finite checks of the
written arguments; they are not substitutes for their general proofs.

SOURCE SNAPSHOT AND PROOF STATUS

Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: dca9f06383ccdfc2ed208ccb7c9882214fdb09ac

Primary repository paths:
  Combinatorics/Ramsey/Papers/sz-thm-gowers-proof/
  Combinatorics/Ramsey/Lean/GowersSzemeredi/

The original 2001 paper is distinguished from the repository's edited
transcription. Relevant file hashes and the source comparison are recorded
in provenance/source-audit.json.

At this commit, the repository ledger records 98 exact companion proofs
and 22 open numbered catalogue statements. Its checkpoint reports a build
of 169 reachable modules and an axiom audit of 1,658 public theorems.
These are reported repository results. No Lean build was run here, and
the new results in this article have not been checked by the Lean kernel.
An exact companion proves the current catalogue definition, which may
include documented repairs; a conditional theorem does not discharge its
hypotheses.

The contributions are local sampling, interpolation, and recurrence
refinements. The article does not claim a new global Szemeredi bound or a
completion of Lemma 16.10 or Theorems 18.1–18.2 in Lean. Its synchronized
box conclusions require the stated inherited-coordinate geometry, and its
polynomial partition consequences use the cited recurrence input. Historical
priority for the exact new formulations is not asserted.

