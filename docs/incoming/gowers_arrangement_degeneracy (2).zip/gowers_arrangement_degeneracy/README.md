# Sharp Degeneracy Bounds for Gowers Arrangements

**Hyperplane obstructions, second-order structure, and an exact finite-field count**  
AI-assisted research draft prepared for Vladimir Reshetnikov / ProveIt.  
6 October 2026.

## Main results

The target is **Gowers (2001), Lemma 15.4**, using its all-squarefree-moments
notion of degeneracy and labelled parameter tuples. Set
`n = 2d`, `m = n*2^k`, `D = (n+1)*k+n-1`, with `k >= 1, d >= 2`.
There are `q^D` ambient arrangements. Write `Delta` for the degenerate fraction.

For characteristic `p > m`, let `T_r` be the central trinomial coefficient and

- `L = (T_n - 2*binomial(n,n/2) + 1)/2`;
- `R = (T_m - 2*binomial(m,m/2) - 3^n + 2^(n+1))/2`;
- `S = k*(2^n-1) + k*(k-1)`.

The article proves

```
(k+L)/q - binomial(k+L,2)/q^2
    <= Delta
    <= (k+L)/q + S/q^2 + (R-S)/q^3.
```

Thus the first-order coefficient is sharp. The proof identifies its actual
hyperplanes and classifies all coefficient directions that can contribute at
second order outside those hyperplanes. It also gives exact characteristic-
dependent first-order constants in every finite-field characteristic and cubic
bounds in characteristics two and three.

For `d=2` and `p > 4*2^k`,

```
Delta = (k+4)/q + (k^2+21*k-6)/(2*q^2) + O_k(q^-3).
```

For `k=1,d=2`, a finite exact certificate gives, over **every finite field of
characteristic at least 11**,

```
Delta = 5/q + 8/q^2 + 40/q^3 - 367/q^4 + 563/q^5 - 248/q^6.
```

The general bounds and second-order formula have conventional proofs. The exact
last formula additionally uses the explicitly supplied rational line-incidence
enumeration. The article includes twelve further research questions.

## Scope and status

This is an unrefereed AI-assisted research draft. No priority, independent
mathematical review, Lean verification, new global record, or improvement to the
final bound in Szemeredi's theorem is claimed. The local exceptional-set budget
is genuinely strengthened; propagating it through the full proof is separate
work. The all-moments definition is essential. The `d=1` case has different rank
behavior and is treated separately in its smallest instance.

## Build

A standard LaTeX installation with the packages in `article.tex` suffices:

```sh
make pdf
```

The bibliography is embedded in the TeX file. No external images, font files,
network requests, shell escape, or Python execution are needed to build the PDF.

## Verify

The default verifier uses only Python's standard library:

```sh
make verify
# equivalently:
python3 code/verify.py
```

This reconstructs the rational certificate, compares it to the stored JSON,
checks the class counts and incidence data, proves preservation of the data
outside characteristics 2, 3, 5, 7 via exact minors and coordinate differences,
and checks the Boolean core identities.

For independent exhaustive subset-sum tests, NumPy is also required:

```sh
make verify-full
# regenerate the recorded report:
python3 code/verify.py --subset --write
```

An optional audit file listing each selected maximal-rank minor can be generated:

```sh
python3 code/verify.py --write --minors
```

The distributed `verification.json` records a successful full execution:
484 balanced coefficient classes, 459 non-parity classes, 15 core classes in the
eight-vertex case; 7296 exact matrix-rank checks; 15 exhaustive profile-count
checks; 170 constructed core-identity checks; and 212766 independent normalized
base-tuple checks across primes 5, 7, 11, 13, 17, 19. The predictions at 5 and 7
intentionally fail and are negative controls outside the theorem's range.

A finite Python certificate is not proof-assistant verification. The general
symbolic proofs do not depend on numerical testing.

## Files and integration

`article.tex`, `article.pdf`, `code/verify.py`, `code/exact_certificate.json`,
`verification.json`, `SOURCE_AUDIT.md`, `FORMALIZATION.md`, and `Makefile` are
included with this README. Suggested destination:

```
Combinatorics/Ramsey/Research/GowersSzemeredi/arrangement-degeneracy/
```

The original paper and existing Lean statements should not be silently replaced.
Add companion theorems and update the proof ledger only after actual verification.
No repository write has been performed by this delivery.
