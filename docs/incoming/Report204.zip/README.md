# Report 204: varying-power Dyck moments

This is a self-contained report and reproducible computation package. The
mathematical proofs are in `Report204.tex` and `Report204.pdf`. The recorded
leading equivalent for OEIS A291333 is prior work; the report explains that
attribution and the scope of the present results.

## Rebuild

Use Python 3.12.14, the pinned packages in `requirements.txt`, and pdfTeX
3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian) for the reference build.
A working LaTeX installation must provide the packages named by
`Report204.tex`. No network access or private files are used during a build.

From an extracted archive directory:

```sh
python -m pip install -r requirements.txt
python build.py
```

The command runs every exact test and numerical diagnostic, regenerates the
JSON and TeX tables, compiles the report with `pdflatex` until references stabilize (at least two
passes), verifies archive
contents, and writes `Report204.zip`. `python -O build.py` runs the same checks
and produces identical canonical files and ZIP bytes on the same toolchain.
Checks use explicit exceptions rather than optimization-disabled `assert`
statements. `python build.py --checks-only` runs the complete computation suite
and generates the tables without compiling or packaging the report.

A full run normally takes a few minutes. Results contain no wall-clock timings,
absolute paths, execution-mode flags, or environment-specific metadata. For
byte-identical PDFs across machines, use the same TeX engine, package versions,
and fonts as well as the same Python dependencies. Python dependency versions
alone do not make different TeX installations byte-identical.

## Files and interfaces

- `Report204.tex`, `Report204.pdf`: report source and compiled report
- `build.py`, `requirements.txt`: full build and pinned Python dependencies
- `code/exact_checks.py`: finite exact tests; `run(output_dir)` or direct CLI
- `code/coefficients.py`: geometric-multiplicity and independent row-box engines,
  normalized walk transfer, logarithmic coefficients, and cutoff majorants
- `code/inverse.py`: arbitrary fixed-order inverse coefficient recurrence and
  smooth-root evaluation
- `code/numerical_diagnostics.py`: complete numerical comparison suite;
  `run(output_dir)` or direct CLI
- `code/tables.py`, `tables.tex`: generated report table macros
- `code/manuscript_checks.py`: Decimal rounding guards for every printed
  computational decimal table cell, cutoff value, and TV prose prefix
- `code/results/manuscript_checks.json`: all 47 manuscript numerical guards
- `code/results/exact_checks.json`: exact test counts, initial integer sequence
  values, and exact integer-threshold boundary cases
- `code/results/numerical_diagnostics.json`: coefficients, forward remainders,
  inverse errors, total-variation diagnostics, general-parameter examples, and
  evaluations of analytic cutoff majorants
- `MANIFEST.sha256`: hashes for every public file except the manifest itself and
  the archive that contains it

Import the computational modules by putting `code/` on the Python module path.
`multiplicity_coefficients(J=200, order=4, tau=1, sigma=0)` evaluates the finite
largest-part-conditioned coefficients at the current `mpmath` precision. With
an explicit `fractions.Fraction` value of `q`, rational `tau` and `sigma` are
handled by exact rational arithmetic; this optional formal q need not equal
`exp(-tau)`. `row_box_coefficients(L=175, order=4, tau=1, sigma=0)` independently
sums only diagrams in an L-by-L square and divides by the Q-product approximation.
The latter's zeroth coefficient is therefore slightly less than one. These are
different finite truncations, with intentionally different normalizations.

The coefficient engine is generic at each positive fixed order. Runtime and
memory grow with the finite weighted-moment state space; the reference suite
computes the diagonal through order four and general parameters through order
three. `inverse_profile_coefficients(u, Q, ell, order)` implements the triangular
recurrence with `u=log(t)`. At orders zero and one, `ell=[]` is permitted.
For order >= 2, supply the indexed list `[0, ell_1, ..., ell_(order-1)]`;
additional higher entries are ignored.

## Exact checks versus numerical diagnostics

The exact suite enumerates Dyck paths through n=10, compares direct enumeration,
height transfer, and formal Stieltjes fractions, checks rational staircase and
cell identities, checks partition statistics through size 18, compares two
finite rational row-box constructions, verifies symbolic coefficient and
inverse identities, and checks the total-variation rational endpoint bounds.
Integer-only threshold checks verify neighboring values around exact a_n.
The numerical suite also compares normalized walk transfer to exact rational
small cases. Two further rational single-part tests independently check the implemented
multiplicity engine and its nonzero-sigma support. A rational formal-logarithm
check also guards against accidental conversion to floating-point arithmetic.

Numerical calculations use ordinary 85-decimal-digit mpmath arithmetic. The
diagonal multiplicity cutoff is J=200, the independent square-box cutoff is
L=175, and Q is evaluated using 1200 product factors. The two coefficient
engines are required to agree within an explicitly tested diagnostic tolerance;
the Lambert formula independently checks the first coefficient. Forward and
smooth inverse diagnostics use n=10,20,40,80,160. General-parameter row boxes
are separately finite and can visibly limit their accuracy, especially for
smaller tau.

The report proves an analytic bound for the exact largest-part cutoff error.
Its computed decimal evaluations do not bound floating-point roundoff. This
package provides no directed-rounding intervals and does not certify every
printed digit. Finite exact tests and numerical agreements supplement the
proofs; they do not themselves prove asymptotic theorems.

The inverse's two-ceiling constant is existential. Smooth numerical roots and
profile errors do not give a certified finite-Y integer threshold. The supplied
integer threshold examples use exact integer comparisons instead.

## Deterministic packaging

The build fixes `SOURCE_DATE_EPOCH` to 2026-10-04 00:00:00 UTC, sets UTC and the C
locale for TeX, omits PDF creation/modification dates and trailer identifiers,
and suppresses path-dependent pdfTeX information. It initializes a local
pdflatex format and font maps from the installed distribution, using isolated
writable TeX caches; EPS conversion is disabled because the report needs none. It assigns fixed archive
member timestamps, Unix permissions, sorted names, and uncompressed ZIP storage.
The ZIP contains every public source/result file and its hash manifest, excluding
itself and build intermediates. `.build/` holds LaTeX diagnostics and is excluded,
as are Python caches and standard LaTeX auxiliary files. No ZIP member is a
symbolic link. The manifest can be checked after extraction with:

```sh
sha256sum -c MANIFEST.sha256
```

To compare normal and optimized builds, extract the same source ZIP into two
fresh directories, run `python build.py` in one and `python -O build.py` in the
other, then compare the resulting `Report204.zip` files with `cmp`.
