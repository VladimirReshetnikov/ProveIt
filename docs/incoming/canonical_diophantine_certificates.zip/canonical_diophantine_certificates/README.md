# Canonical Diophantine Certificates for Polynomial Trajectories

Research manuscript and exact-arithmetic prototype, September 30, 2026.

## Main result

For each externally fixed degree bound d, the relation

    p(i) >= 0 for every integer i in {0,...,T}

has a single-fold ordinary integer-polynomial representation of degree at
most four, with O((d+1)^3) natural existential coordinates, independent of
T. Its primary sign-table coordinates number exactly (d+1)(2d+1).
The article supplies full proofs, including zero polynomials, degree drops,
zero horizons, unique padding, and uniqueness of every arithmetic witness.

The execution applications cover polynomially iterable maps, nonlinear
unitriangular updates, unipotent affine updates, and an explicitly certified
fixed-period affine extension. First-exit times can be projected because
they are unique. The article also proves specified-input nontermination
certificates and carefully separates this from global termination.

This is a restricted constructive result. Historical priority of the
particular construction has not been established. It is not a solution of
the general finite-fold or single-fold Diophantine representation problem.
No Lean or Coq verification of the new construction is claimed.

## Contents

- `article.tex`, `article.pdf`: full research manuscript and compiled PDF.
- `certificates.py`: exact sign-tower generator and local endpoint checker.
- `quartic_compiler.py`: compile a fixed-degree positivity relation to an
  explicit sum of squares of quadratic integer residuals.
- `verify_export.py`: separate sparse-polynomial assignment checker. It
  does not import the compiler.
- `run_tests.py`: deterministic regression tests (seed 20260930).
- `test_report.json`: actual output from the test suite.
- `independent_verification.json`: actual independent check of the exported
  example's satisfying assignment.
- `quartic_example.json`: exact quartic template and satisfying assignment
  for p(t)=t^2-4t+4, T=6.
- `interior_counterexample.json`: p(t)=t^2-6t+8, T=6, demonstrating why
  outer endpoint tests alone are not sufficient.
- `huge_horizon_certificate.json`: p(t)=(t-10^50)^2, T=10^100.
- `sources.md`: repository pin and bibliographic provenance.

## Reproduce the computations

Python 3.10 or later; standard library only. No network access is needed.
Run from this directory:

```sh
python run_tests.py
python verify_export.py quartic_example.json
python certificates.py --coefficients 8 -6 1 --horizon 6
python quartic_compiler.py --coefficients 4 -4 1 --horizon 6 --output quartic_example.json
```

Coefficient lists are in ascending power order. Thus `8 -6 1` means
8 - 6t + t^2. The horizon is nonnegative and the checked interval is closed.
The compiler's optional `--sign-table-only` switch omits the positivity
assertion while preserving the full, unique sign table.

For an independent assignment check, use:

```sh
python verify_export.py quartic_example.json --assignment my_assignment.json
```

The assignment must contain exactly the declared variable names, each with
an integer value. All witness variables and T must be nonnegative. Free
coefficient inputs may be signed. The exported polynomial is not specialized
to its sample assignment: the template depends only on nominal degree and
whether positivity is required.

## What the polynomial export means

If the residuals in the JSON file are Q_1,...,Q_N, the exact polynomial is

    P = Q_1^2 + ... + Q_N^2.

A term's variable-name list is its monomial; the empty list means a
constant, and repeated names mean powers. Every residual has degree at
most two. No uninterpreted predicate, variable exponent, floor operation,
or bounded universal quantifier remains in the export.

For the degree-two example there are 15 primary coordinates and 834
auxiliary coordinates: 849 natural witnesses in total, with 1,218 quadratic
residuals. These are intentionally unoptimized implementation counts, not
claims of minimality or universal-polynomial records.

The code implements the core polynomial sign-certificate construction. It
does not yet implement automatic source-code recognition, the full Boolean
program front end, or the fixed-period affine front end. Those extensions
are proved in the article but remain separate software tasks.

## Tests performed

The included run passed 1,620 random polynomial cases (degrees 0 through 8),
8 edge cases, an exhaustive test of 59,049 candidate sign towers across 27
small coefficient triples, 68 rejected tag mutations, 50 compiled polynomial
instances (33 negative positivity instances), and 2,500 nonlinear closed-form
state comparisons. The huge-horizon certificate used 832 distinct polynomial
evaluations and has six active sign runs across its three levels.

Finite tests are not a replacement for the mathematical proofs. The JSON
checker establishes arithmetic satisfaction of a concrete assignment, not
universal compiler correctness or uniqueness.

## Build the paper

A standard TeX Live installation with pdfLaTeX, AMS packages, Latin Modern,
geometry, microtype, enumitem, fancyhdr, float, listings, xurl, and hyperref suffices.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The bibliography is embedded in the TeX source. No BibTeX, external images,
font files, network access, or shell escape is required.
