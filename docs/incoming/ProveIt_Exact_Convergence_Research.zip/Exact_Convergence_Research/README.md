# Exact Convergence as Computation
## Diophantine Certificates for Uniformly Mixing Stochastic Games

Research manuscript prepared for Vladimir Reshetnikov, October 2, 2026.
Mathematical development and implementation: ChatGPT.

## Start here

`article.pdf` is the 24-page compiled article. `article.tex` is its standalone
LaTeX source, including its bibliography; no external figures or bibliography
database are needed. The article contains the complete proofs, repository and
literature comparison, worked examples, and a proposed research agenda.

The main theorem constructs a fixed finite two-player stochastic game with
at most two actions per state, strictly positive dyadic transition probabilities,
discount 1/2, common running reward 1/4, and the known value vector (1/2,...,1/2).
Its set of dyadic initial terminal-payoff vectors that reach that value in
finitely many exact Bellman iterations is computably enumerable complete.

This concerns arbitrary exact initialization and finite exact attainment,
not computing the limiting game value, ordinary iteration from zero, or a
single sampled random trajectory. The fixed-game theorem follows by applying
the specified compiler to a fixed universal counter program. The numerical
128-state examples supplied here are illustrative one-counter programs;
**they are not claimed to be universal games**.

## Files and data

| File | Contents |
|---|---|
| `code/bellman_diophantine.py` | Counter program, homogeneous circuit, layered paired-channel stochastic-game compiler; exact iteration; complete quadratic certificates; matrix/Skolem specialization |
| `code/run_checks.py` | Reproducible exact tests and regeneration of all example exports |
| `code/check_certificate.py` | Independent JSON polynomial and trajectory checker; does not import the generator |
| `artifacts/verification.json` | Full test counts and measured example resources |
| `artifacts/test_run.txt` | Recorded test output |
| `artifacts/small_game.json` | Two-state zero-reward example |
| `artifacts/small_certificate.json` | Complete 12-witness quadratic and its natural zero |
| `artifacts/small_expanded_quadratic.json` | The same polynomial fully expanded, with 45 monomials |
| `artifacts/countdown_game.json` | Complete 128-state absorbing-halt game, including reset and input |
| `artifacts/countdown_timeline.json` | Exact countdown timing and comparison gaps |
| `artifacts/countdown_certificate.json` | Complete horizon-17 scalar-equality quadratic: 2,584 witnesses |
| `artifacts/fixedpoint_game.json` | Complete 128-state erasing-halt game with common reward 1/4 |
| `artifacts/fixedpoint_certificate.json` | Complete horizon-30 full fixed-point quadratic: 4,440 witnesses |
| `PROOF_STATUS.md` | Established dependencies, new proof development, and precise limitations |
| `build.py` | Cross-platform test and PDF build driver |
| `artifacts/pdf_preflight.json` | PDF build and layout inspection record |

The large certificates are ordinary integer polynomials in factored form:
the sum of the squares of every listed integer linear form plus every listed
nonnegative product. Index -1 is the constant monomial. All other indices
refer to the complete variable-label array. There are no hidden min/max,
run, or exponentiation relations. The reset has been expanded into the
certificate coefficients. Every existential variable ranges over the
nonnegative integers. Products of complementary gaps are **not squared**.

The bounded certificate family depends on the externally specified horizon.
Its arity is (N+2b)T, where b is the number of binary-decision states. A true
endpoint has exactly one complete natural witness tuple. This does **not**
give one fixed quadratic polynomial or prove single-fold MRDP.

## Reproduce

Python 3.10 or later is required; the recorded run used Python 3.13.5.
Only the Python standard library is used. Run commands from this directory.
Do not enable Python's `-O` optimization flag: the independent checker uses
assertions for internal consistency checks.

```sh
python code/run_checks.py
python code/check_certificate.py artifacts/small_certificate.json --game artifacts/small_game.json
python code/check_certificate.py artifacts/countdown_certificate.json --game artifacts/countdown_game.json
python code/check_certificate.py artifacts/fixedpoint_certificate.json --game artifacts/fixedpoint_game.json
```

The expected suite result is **26,077 passing exact-arithmetic assertions**.
The random seed, used only for finite test cases, is 20261002. Arithmetic uses
integers and rational numbers, not floating-point approximations.

To rebuild the article, install pdfLaTeX with the packages listed in its
preamble, then run:

```sh
python build.py
```

`python build.py --skip-tests` rebuilds only the PDF. The build driver writes
LaTeX logs under `build_logs/`. TeX Live or MiKTeX with the usual AMS, Latin
Modern, microtype, xurl, hyperref, listings, and page-layout packages suffices.

The certificate exports occupy approximately 33 MB uncompressed because they
include all dense reset coefficients. They compress well. Regeneration
replaces the files under `artifacts/` intentionally.

## Verification and scope

The compiler, independent checker, and finite tests accompany mathematical
proofs; they are not a Lean/Rocq verification. No peer review or exhaustive
publication-priority search has taken place. The manuscript does not claim
a resolution of the general Skolem problem, the one-player Bellman frontier,
the single-fold/finite-fold MRDP conjectures, or an improvement to ProveIt's
fixed universal-polynomial operation bounds. Repository files were read but
not modified. See `PROOF_STATUS.md` and the article's source-audit appendix.
