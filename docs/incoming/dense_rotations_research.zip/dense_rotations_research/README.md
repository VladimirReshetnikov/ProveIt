# Dense Rotations, Undecidable Exactness

Research draft prepared for Vladimir Reshetnikov, 30 September 2026.

## Contents

- `dense_rotations.tex`: complete LaTeX source, with bibliography embedded.
- `dense_rotations.pdf`: compiled article.
- `verify.py`: standard-library exact-arithmetic verification and reusable compiler routines.
- `verification_results.json`: results from the supplied verification run.
- `example_gates.json`: all nine rational matrices for the concrete example.
- `build.sh`: verification and PDF build commands.

## Main results developed in the article

A finite presentation is compiled into rational matrices in SO(4, Z[1/5]).
Its quotient word problem becomes target membership in a finitely generated
rotation group. A nontrivial presentation kernel implies density. A classical
Higman-embedding construction supplies a fixed c.e.-complete example, and a
free-product commutator construction localizes completeness to every rational
open ball. The article also proves exact denominator growth and decoding,
a rational precision gap, a synthesis-depth function of halting degree, and
bounded quartic certificates in bijection with labeled gate words.

## Scope and verification status

The group-theoretic universality foundations are classical and attributed.
The article does not claim established historical priority for the package.
The universal specialization is an existence theorem: a small explicit
universal group presentation, its full gate list, and a fully expanded fixed
unbounded MRDP polynomial are **not** included. The presentation-to-gate
compiler and the bounded polynomial scheme are explicit.

The numerical example is `<x,y,t | x y x^-1 y^-1> = Z^2 * Z`. Its word
problem is decidable. It illustrates and tests the compiler; it is **not**
the universal presentation. The example gate group is dense, but density
alone does not imply undecidability.

Python tests are finite checks, not a Lean formalization. They do not prove
density, Higman's theorem, or undecidability. Proofs and dependencies are in
the article. No ProveIt Lean build was run for this draft.

## Reproduce

Python 3.10+ is sufficient for the tests; no third-party Python package is
required. A standard TeX Live installation with pdfLaTeX, amsmath, amsthm,
lmodern, microtype, hyperref, bookmark, xurl, enumitem, and listings builds
the article.

```sh
python3 verify.py --output verification_results.json
pdflatex -interaction=nonstopmode -halt-on-error dense_rotations.tex
pdflatex -interaction=nonstopmode -halt-on-error dense_rotations.tex
```

Alternatively run `sh build.sh`. Use normal Python execution, not `python -O`,
because the verification assertions must remain enabled.

The script checks every reduced word through length 8 (13,121 including the
empty word), 100 seeded Spin(4) examples, all 820 labeled words through
horizon 3 for the nine-gate example, and 3,277 deliberate corruptions. All
comparisons use integers and exact rational numbers, not floating point.

## Use the compiler on another finite presentation

Signed integers denote letters: `j` is x_j and `-j` is its inverse.
For example:

```python
import json
from verify import gates, encoded_matrix

rank = 3
relators = [(1, 2, -1, -2)]
matrices = gates(rank, relators)
with open("my_gates.json", "w", encoding="utf-8") as out:
    json.dump([encoded_matrix(m) for m in matrices], out, indent=2)
```

Label order: identity, positive diagonal generator gates, positive relator
gates, inverses of the diagonal gates, inverses of the relator gates.
This routine constructs matrices only; it does not decide the source word
problem or certify that an arbitrary supplied presentation is universal.

## Important equation

For an n-step scaled trace A_n = D^n W_n and target T/q, the endpoint is
`q A_n = D^n T`. The target numerator must carry the scale factor. This is
implemented in the residual checker and the displayed terminal equation in the compiled article.

## Repository baseline

Inspected ProveIt commit:
`e18718e837d43e162252f9a314e8cb797fbd1a1f`.
The consulted repository documents are the HilbertTenthProblem README and
`Computability/HilbertTenthProblem/Lean/MRDP.md`. Repository audit status is
attributed to those documents rather than represented as independently
rerun verification.
