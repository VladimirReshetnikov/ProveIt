# A 238 state binary Turing machine for ZFC consistency

**Result:** the exact one-tape, two-symbol machine in `machines/zfc238.tm` has **238 working states**, includes its blank-tape initialization, and has an ordinary mathematical proof formalizable in ZFC of

    ZFC proves: Nonhalt(M238, blank) if and only if Con(ZFC).

The proof does not assume Con(ZFC). The result meets the requested bound of fewer than 239 working states. This is not a minimality or global historical-priority claim. A new Lean/Rocq theorem for this exact 238-state table is **not** included; the earlier exact source/theory calibration remains an explicit inherited dependency.

## Read first

- `report.pdf`: the 17-page main report, including the full transition table and ordinary proof.
- `report.tex`, `sections/`: the editable LaTeX source.
- `machines/zfc238.tm`: canonical final table.
- `machines/zfc238_old.tm`: the same machine with inherited labels.
- `machines/renumbering.json`: the exact action-preserving bijection.
- `reproduce.py`: complete offline replay entry point.
- `boundary_audit/AUDIT.md`, `erasure_audit/TRANSFER_THEOREM.md`, `verification/parent_review.md`: detailed independent mathematical review and proof notes.

Prepared on 19 October 2026 against ProveIt commit `ce192939372ac7944fe2a0208c68a96d49fb5e3b`. The two supplied predecessor archives retain their earlier `13ec39ed43148b1807f51ed6e6528e1c84659562` pin and original notices. No remote repository write or pull request is part of this delivery.

## Exact model and identity

The tape is indexed by all integers; symbols are 0 and 1, initially all zero. The head starts at position 0 in state 0. Working states are 0 through 237, with a separate halt outcome 238 that has no outgoing rows. Every working state has both transitions, so there are 476 rows. Only one-cell left/right moves are used. The dispatcher is state 84.

A line `q b w D r` reads b in state q, writes w, moves in direction D and enters r. The file's first line is `#! start 0`. All initialization and control states are counted. No external input, free initialization or extra symbols are used.

Canonical SHA-256:

    909f29c493e0ccc5d6a481fd7a20a9a82eb934ab2aa7df17b5ec3789255a8c08

Inherited-label SHA-256:

    069942be27db9736875ea042320e51ac3b1eac7116cbe01cdce520fa6056f78c

The inherited start/dispatcher/halt are 95/96/254. All working states are transition-graph reachable; this does not say every state is reached by the actual blank run.

## The new composition

The inputs already contain two different 239-state results:

1. `combine/zfc239-research-20261019/`: source-boundary rotations and a context split deleting inherited state 218.
2. `combine/ZFC239_Companion_2026-10-19/`: delayed erasure deleting inherited state 169.

Apply the following three changes to the **boundary239** inherited table:

    147/0: 0 R 169 -> 0 R 80
    80/0:  0 R 25  -> 0 L 106
    91/1:  0 L 50  -> 1 L 167

Delete both rows of 169; every other row is preserved. The new contribution is exact compatible composition and its proof. Different deleted labels alone would not justify composition, because delayed erasure needs a representation guard. The new audit re-establishes that guard on the changed source, and the full direct runtime proof separately checks the final table.

## Evidence

- The direct final runtime proof covers all 8,386 guards of all 6,455 source leaves, using 2,255,513 symbolic rules, with minimum constant actual duration 13. All 476 rows occur in the proofs.
- Coverage includes every natural primary register value, arbitrary additional gap, arbitrary first spare and arbitrary finite spare tail. The rules are literal transitions, natural unary-run induction and finite-list induction with four one-block schemas freshly proved on the exact table. A limit of 4,000 bounds proof construction, not machine runtime or parameter values.
- Independent source audit checks all 13 stages and 25 rotations, all 8,385 nonhalting edges and the halt descriptor at each stage, ordered operands and exact zero-extended successor normalization.
- Exact sparse/dense startup reaches dispatcher 84, head -5, 351 one-cells, logical seed `(3,0,0,0,3,0,0,0,0)`, gap 117, and 167 spare values all 1 after 409,835 transitions. Every other cell is zero.
- A second machine-level proof checks six whole-tape local identities and the exact boundary239 selector guard. Its 8,386-case guard run uses 2,247,513 symbolic rules; its 32 positive state169 events see a right 1-run of length G+K, with G >= 0 and 23 <= K <= 59. Accelerations cannot hide any visit to 169.
- The independent boot-alignment checker compares whole tapes at all 409,685 matched local-block checkpoints, with exact old/new lengths 409,691/409,835.

The two unbounded routes reuse the same audited generic symbolic engine. They are complementary mathematical routes, not independent proof kernels. The independent finite local verifier and boot implementations are separate implementations. Saved receipts alone are not proofs; the report explains the universal soundness arguments and exact logical dependencies.

## Reproduce

Python 3.10 or later; standard library only. Assertions must be enabled. Do not use `-O`, `-OO`, or `PYTHONOPTIMIZE`.

From this directory:

    python3 -B reproduce.py --output /tmp/zfc238-full

Choose a new or empty directory outside this archive. This preserves delivered evidence, works in a temporary copy and saves fresh logs/receipts. It replays source identity and rotations, independent audits, construction/startup, local transfer and boot alignment, both packet921 encoders, the **full final runtime proof**, the **full boundary selector guard**, final endpoint binding and duration comparison. Both full symbolic checks take a few minutes each in the recorded environment.

A short replay deliberately omitting the two full unbounded runs:

    python3 -B reproduce.py --quick --output /tmp/zfc238-quick

It returns `QUICK_238_REPLAY_PASS`, not full proof replay. Final full success is `FULL_238_MATHEMATICAL_REPLAY_PASS`. The driver checks explicit receipt statuses and input identities, not only process exit codes.

For the smallest binary-only bundle, copy `combine/candidate238/` and run its own `reproduce.py`. That directory has every Python dependency and exact input needed for construction, boot and the full direct binary runtime interface. It does not independently redo source equivalence or the inherited set-theoretic calibration.

The manifest covers delivered bytes other than itself:

    sha256sum -c MANIFEST.sha256

This detects file changes; it is not a digital signature. The driver checks the manifest when present.

## Additional research

`formalisms/` gives a new same-model simplification from the supplied 946-bit equational packet to 921 bits: delete the explicit truth equation, which follows from retained Sh1, class-NAND and arbitrary-witness equations. The report includes the all-algebra proof. The unchanged codec emits 13 equations and 209 term nodes; an independent encoder/decoder confirms the exact 25-bit deletion and both hashes. **This is not a 921-bit machine or an additional state saving:** its complete binary interpreter and initializer are not implemented.

`encoding/` gives a displaced-head quotient search on the final 238-state machine. It permits a +/-2 head representation and two synthesized retained rows, within an eleven-cell window and 63/127 old/new step limits. It finds no survivor across 45,741 ordered state pairs in the two stated domains, and passes positive controls. These are scoped finite-family negatives, not lower bounds. Follow its README for optional C++17 reproduction; these searches are not premises of the main theorem or part of the default Python replay.

## Rebuild the PDF

With a standard TeX Live installation:

    pdflatex -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -interaction=nonstopmode -halt-on-error report.tex

The delivered PDF is rendered and visually inspected. It includes every transition, and the appendix was independently compared against the machine file.

## Proof assistant status and attribution

The current upstream exact240 external endpoint is closed in `BinaryRotation240.lean`. The packet includes inspected source and its references, not a fresh upstream build. Historical predecessor prose that names compensated244 as the latest closed endpoint remains historical. No new exact238 kernel endpoint or serialized internal PA theorem is claimed.

Mira-Cult retains credit for the original compact calculus, SIR theory, register source and 254-state construction; Jeff Ketchersid and contributors for upstream verification and consistency work; Andrew James Wade for the compiler framework; and ProveIt/earlier incoming research for all precursor reductions and calibration. Both 239-state results are credited as prior inputs. See `ATTRIBUTION.md`, `licenses/`, `provenance/input_archives.json`, and the unchanged original notices inside the two reference directories.
