# Finite Models and Real Degenerations of Surreal Mixed Volumes

**A research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.**

The article studies valuations of all mixed-volume coefficients of a finite
collection of polytopes over a set-sized real closed ordered field K containing
the real numbers. In particular, it applies to finite surreal-coordinate data.
The natural valuation may have arbitrary rank.

## Main results and reading route

- **Theorem 4.2 and Corollary 4.3:** simultaneous compression to parallelotopes
  preserves every mixed-volume coefficient valuation, with at most d segment
  generators per polytope in dimension d. The uniform total bound dm is sharp.
- **Theorems 5.1 and 5.2:** exact colored-minor and polarized-minor realization
  criteria. Generic integer mixing has an explicit bound depending only on d,m.
- **Theorem 6.2 and Corollary 7.4:** every normalized weighted initial polynomial
  is the volume polynomial of actual real polytopes. Its support is a
  real-linearly-representable polymatroid base set.
- **Theorem 8.2:** every finite-valued quadratic M-convex profile is realized
  by full-dimensional parallelograms over the given field, without a field
  extension or a multiplicative cross-section of the valuation.
- **Theorem 9.4 and Corollary 9.5:** an explicit strictly Lorentzian cubic in
  seven variables has 84 positive coefficients at just three valuation levels,
  but its profile has no polytope realization. Along with the quadratic theorem,
  this gives degree three as the first possible full-support M-convex obstruction
  over the non-Archimedean fields considered here.
- **Theorem 10.2:** a four-variable quadratic has a realizable valuation profile
  but impossible leading coefficients, separating support/valuation obstructions
  from coefficient obstructions.

The article has 28 PDF pages (an unnumbered title page plus 27 numbered pages),
14 sections, two appendices, ten proposed research questions, and an embedded
bibliography. Section 13 gives the research program. The appendices explain
finite real-closed-field transfer and reproducibility.

## Files

| File | Purpose |
| --- | --- |
| `article.pdf` | Typeset article with complete conventional proofs |
| `article.tex` | Self-contained LaTeX source; embedded bibliography |
| `verify.py` | Exact symbolic and finite-enumeration checks |
| `verification_results.json` | Results of the executed verification program |
| `SOURCE_AUDIT.md` | Repository scope, classical antecedents, and novelty limits |
| `requirements.txt` | SymPy version used for the executed checks |
| `Makefile` | Convenience targets for compilation and verification |

No external figure files, separate bibliography database, or private font files
are required.

## Reproduce the checks

Use Python 3.10 or newer and SymPy. The included run used Python 3.13.5 and
SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python verify.py --output verification_results.json
```

The output records all 84 Fano coefficient polynomials, all 12,047 M-exchange
obligations (from 7,056 ordered exponent pairs), seven symbolic Hessian
congruences and characteristic-polynomial checks, 23 rational sandwich
examples, the quadratic coefficient comparison, and 15 rank-two reconstructions
with 285 exact prescribed-minor checks. All passed in the included run.

These are finite certificates and reproducible checks, not a machine-checked
proof of the general theorems. The script uses exact integer, rational, and
symbolic polynomial arithmetic. It does not call an external service or a
numerical optimizer. Its seeded examples are deterministic.

## Compile the PDF

A normal TeX Live or MiKTeX installation with pdfLaTeX and the packages named
in the preamble suffices. With latexmk:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. No shell escape is needed. `make pdf` and `make verify` are
convenience targets.

## Scope and status

This is an AI-assisted research manuscript, not independently refereed and not
Lean-checked. It gives full conventional proofs of its stated results. Historical
priority has not been established. Classical mixed-volume identities,
maximum-determinant normalization, Lorentzian theory, real matroid obstructions,
and the rank-two tropical Grassmannian are explicitly credited rather than
claimed as new. The research questions answered here are formulated in the
manuscript; no previously named open conjecture is claimed solved.

The arbitrary-rank finite constructions and their consequences are developed
as the manuscript's contribution. They concern ordinary convex polytopes over
an ordered field, not max-plus tropical polytopes and not the distinct
projective volume-polynomial problem discussed by Huh.

The repository context is pinned to ProveIt commit
`b2b626d8537f7dea8f20393ee4714c7201a7001e`. Only the sources and ranges described
in `SOURCE_AUDIT.md` were used as repository context. No full repository audit,
review of all incoming archives, or Lean build was performed.
