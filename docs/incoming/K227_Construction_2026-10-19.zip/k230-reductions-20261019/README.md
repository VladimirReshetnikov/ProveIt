# K227: three further states removed from Elliot Glazer's K230

This package constructs **227 working states**, with a binary alphabet and a
blank initial tape. It removes **three states from K230** and has **eight fewer
states than the ProveIt 235-state candidate** at commit 0128d662fd.

The principal machine is [machines/k227.tm](machines/k227.tm). Its working states
are 0 through 226, its separate halt is 227, its initial state is 0, and its
blank symbol is 0. The head starts at coordinate 0 on a two-sided infinite tape.
Every transition moves L or R. The halt is not included in the working-state count.

**Canonical table SHA-256**

    f821e7fb73dde10ad1f8536b145b70933882737bca228ef6919b812e5a080c26

The [12-page report](report.pdf), its [LaTeX source](report.tex), and the complete
table appendix give the construction, mathematical proofs, limitations, and
research context. The report's ordinary mathematical conclusion is:

    ZFC proves: Nonhalt(K227, blank tape) iff Con(ZFC).

Consistency here is absence of a finite classical first-order ZFC refutation.
The biconditional has no premise asserting Con(ZFC).

## What is new

The construction starts from Elliot Glazer's K230 commit
3142e4dd980f0be12f4abb636c4ae2528afc17eb. It applies the earlier optimizations in
the shared interpreter, with a new adaptation for the last state.

1. At four closed source occurrences, replace
   ((CD6,(CI5,CC2)),CI5) by (CI5,(CD6,CC2)).
   Both take arbitrary (R6,R5)=(n,m) to (0,m+n+1) in exactly 3n+2 source steps.
   Change inherited decoder 142 and fold 90 into 72. Result: 229 states.
2. Transfer inherited arithmetic fold 169 into 80. Result: 228 states.
3. Reassociate one closed source subtree at inherited 184/181, then delete 218
   by splitting its two tagged entry contexts between existing 179 and 242.
   Result: 227 states, with no newly allocated state.

The third step uses the bit just written to the left by a predecessor.
After the rotation, original 179 entries have left 0; original 242 entries have
left 1. Old 218's left 0 context can occupy 242, and its left 1 context can occupy 179.
An independent eight-case proof checks exact local paths with arbitrary exterior
tape. This is more flexible than merging a pair into one host.

The deleted states in **original K230 numbering** are 79, 140, 175.
The named inherited labels are convenience labels only; the total map is in
[source/label_map.json](source/label_map.json). Canonical numbering retains
original K230 order after deletion.

The old 243→241 folds 27→15 and 39→17 are already embodied in K230. All eight
corresponding changed rows match its common interpreter. Therefore the entire
old 243→235 saving cannot be subtracted from 230 again. The later old 235 source
contexts also do not all survive the changed K recognizer.

## Verification status

The archive supplies **ordinary mathematical verification of the new table**.
It does **not** claim a new compiled Rocq theorem or an exported internal PA/ZFC
proof for K227. The frozen K230 repository supplies the existing Rocq endpoint.
Its clean builds are upstream-reported results; this investigation audited the
exact local sources and literal bindings without rerunning Rocq.

The complete proof chain is:

    Blank halting of K227
      iff halting of the delivered source from R0
      iff halting of the frozen K230 source from R0
      iff existence of a finite StandardZFC proof of contradiction.

R0 is the actual logical vector (3,0,0,0,3,0,0,0,0), not an all-zero register file.

Fresh checks completed for the final clean inherited table:

| Check | Result |
|---|---|
| Complete runtime | All 6,656 guarded cases over 5,121 leaves |
| Unbounded parameters | Nine independent natural values, arbitrary extra gap, arbitrary first spare and finite remaining spare list |
| Transition coverage | All 454 rows covered by runtime or list proofs |
| Proof construction | 1,615,133 symbolic applications; at most 409 per case |
| Progress | Minimum proved concrete duration 13 transitions |
| Exact startup | 409,835 transitions, checked with sparse and dense tapes |
| Final frame | Head −5, marker −6, header 176, gap 181, 167 spare blocks of value 1 |
| Source/table binding | All 5,125 upstream leaves and 460 upstream table rows independently parsed from Rocq literals |
| Closed rotation | Same ordered primitives and all 6,656 guarded successors |
| Final split fold | 450 ordinary rows and 8 exact two-cell macro cases, arbitrary exterior |
| Adversarial suite | One valid partial prefix and 16 expected rejections |

Each **nonhalting** instruction restores its exact required tape/frame and head
displacement. The halt instruction reaches the halt in positive time and need
not restore a frame. The symbolic engine's 4,000-application construction budget
is a bound on building each finite proof, not on runtime or data values.

The intermediate 169→80 local proof retains an explicit extra right-one guard.
The direct complete final-table runtime theorem establishes the candidate
without needing to infer that guard from finite discovery traces.

## Reproduce offline

Use Python 3.10+ with assertions enabled. From the extracted directory:

    python3 -B reproduce.py --output-dir /tmp/k227-quick-replay

Use a **new** output directory outside the package. Quick mode reconstructs the
tables and sources, proves state renumbering, reruns source and local checks,
replays exact startup, audits all stored runtime records and successor interfaces,
runs targeted rejection tests, and reproduces the optional source-only experiment.

Quick mode explicitly audits stored runtime evidence; it is not labeled a fresh
universal proof. To rederive all final K227 instruction contracts as well:

    python3 -B reproduce.py --full --output-dir /tmp/k227-full-replay

The complete packaged full replay took about 121 seconds in this investigation's environment.
Performance is environment dependent. No network, Rocq, or external Python
package is needed for these ordinary checks.

To regenerate just the construction:

    python3 -B build.py --output-dir /tmp/k227-rebuilt

To recompile the PDF, run twice:

    pdflatex -interaction=nonstopmode -halt-on-error report.tex

The upstream Rocq checkout and its original build instructions are preserved
under reference/k230-rocq. Its 115 pinned external proof dependencies and Rocq
toolchain are separate from the offline ordinary verification described here.

## Package layout

- **machines/**: canonical and inherited K229/K228/K227, exact rotated bases,
  and renumbering maps. The final machine is k227.tm.
- **source/**: frozen normalized source, exact posttest and final sources, loop
  occurrence certificate, and the total label map.
- **verification/**: portable construction support, independent source and
  local-fold checkers, exact startup, receipt/interface audit, adversarial harness,
  and the pinned unary/list induction engine.
- **evidence/**: full runtime case records, startup and local proof receipts,
  source audits, independent review, and finite discovery receipts.
- **reference/**: pinned K230 source checkout and preserved attribution/licenses;
  earlier 243/241 comparison tables and the transfer catalog.
- **discovery/**: search scope, C++ finite filter, exact rejected seven-zero
  prototype, and successful search hit with its exact isomorphism to the clean result.
- **alternatives/**: formalism assessment and a source-only canonical-vacuity
  experiment on the old 235 source. It has no new binary-machine endpoint and is
  not used in K227's proof.
- **manifest.json**: byte counts and SHA-256 digests for delivered files.

The failed prototype reduced source DAG size 212→211 but broke the pointer
encoding. The successful 227 keeps 212 DAG nodes and wins through entry-context
sharing. Additional bounded searches found no valid 226 table; this is not a
lower bound or a claim of optimality.

## Credits

Theory K and its Rocq consistency calibration are Elliot Glazer's work.
The inherited reductions and symbolic engine come from ProveIt research
maintained by Vladimir Reshetnikov. The lineage includes Mira-Cult, Jeff
Ketchersid, Andrew James Wade, and the projects acknowledged upstream.
This investigation adds the exact K230 transfers, the simplified 227 construction,
fresh universal checks, and independent audits. See THIRD_PARTY.md and the
preserved notices. No claim of global priority or minimality is made.

