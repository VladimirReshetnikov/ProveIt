# Uniform p-adic nonvanishing for Lehmer–Comtet coefficients

The report proves exact valuations for T_r(Y), the coefficient of z^r in ((1+z)log(1+z)/z)^Y, with Y a positive integer.

- For prime p and r=(p-1)m with m <= p^v_p(Y), the valuation is v_p(Y)-v_p(m)-m
- For odd prime p and r=(p-1)m+1 with m < p^v_p(Y) and p not dividing r, the valuation is v_p(Y)-m

These are infinite nonvanishing criteria. They extend the pinned source's prime-offset family to new divisibility progressions. The complete zero classification remains open.

The proof explicitly adapts the multinomial method in Donald Davis's 2011 paper about the related log series. It treats the different denominators j(j+1) directly and does not assume the extra factor (1+z)^Y preserves a valuation theorem.

## Files and reproduction

- `article.pdf`, `article.tex`: the four-page report and complete source
- `verify_padic.py`, `padic_checks.json`: integer-triangle replay, 7,749 principal and 2,299 shifted checks through row 360
- `check_rational_powers.py`, `rational_power_checks.json`: separate direct rational power recurrence, 3,073 principal and 437 shifted checks
- `replay_padic_powers.py`, `replay_padic_powers.json`: separate integer-scaled convolution, 2,421 principal and 463 shifted checks, including boundary and denominator checks
- `build_local.sh`: optional preparation-environment build helper

Every Python checker uses only the standard library. Run each with Python 3. The rational-power checker prints its JSON result to standard output; the other two also write their JSON files. Compile the report by running `pdflatex article.tex` twice on a standard LaTeX installation.

The mathematical proofs and final transcription received independent review. All rendered pages were visually inspected and the build has no unresolved references or LaTeX warnings. The finite checks supplement the written infinite-family proofs. No exhaustive priority claim, formal proof-assistant verification, or external-referee approval is asserted.
