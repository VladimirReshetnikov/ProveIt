#!/usr/bin/env python3
"""Exact corroboration of the ordinary twin-core theorem."""
import argparse, itertools, json, math, pathlib, random, time
import sympy as s
from check_connector import feasible, subsets, product, add
if not __debug__:raise SystemExit('Run without -O: checks use assertions.')

def symbolic():
 v,z,t,A,B,C,R,M=s.symbols('v z t A B C R M')
 K=v*v*z*z+C*v*v*z*t+B*M*v*v*t*t+2*A*v*z*z*t+2*B*R*v*z*t*t+2*B*z*z*t*t
 pure=(4*(4*B*M-C*C),16*(2*B-A*A),16*B*B*(2*M-R*R))
 for x,ix,ex in zip((v,z,t),((1,2),(0,2),(0,1)),pure):
  assert s.expand(s.hessian(s.diff(K,x,2),(v,z,t)).extract(ix,ix).det()-ex)==0
 for (x,xx),ex in zip(((v,z),(v,t),(z,t)),(64*(A*C-B*R),64*B*B*M*(C*R-A*M),128*B*B*(2*A*R-C))):
  assert s.expand(s.hessian(s.diff(K,x,xx),(v,z,t)).det()-ex)==0
 a,b,L0,L1,H,S=s.symbols('a b L0 L1 H S')
 A=a+b;B=a*b;R=L0+L1+H;M=L0*L1+H*(L0+L1)+S;C=a*(L0+H)+b*(L1+H)
 pairs=[(A*A-2*B,a*a+b*b),(R*R-2*M,L0*L0+L1*L1+H*H-2*S),
  (C*C-4*B*M,(a*(L0+H)-b*(L1+H))**2+4*B*(H*H-S)),
  (A*C-B*R,a*a*(L0+H)+b*b*(L1+H)+B*H),
  (C*R-A*M,a*(L0*L0+L0*H+H*H-S)+b*(L1*L1+L1*H+H*H-S)),
  (2*A*R-C,a*(L0+2*L1+H)+b*(2*L0+L1+H))]
 for x,y in pairs:assert s.expand(x-y)==0
 return {'hessian_determinants':6,'nonnegative_parameter_identities':6}

def case(q,nx,ny,xns,J,yns,wp,wx,wq,wy):
 fullq=(1<<q)-1
 leftns=[J|sum((1<<(q+y)) for y in range(ny) if yns[y]>>p&1) for p in range(2)]+list(xns)
 leftw=list(wp)+list(wx);rightw=list(wq)+list(wy);direct={}
 right_by_size={k:[] for k in range(q+ny+1)}
 for ht in subsets(q+ny):right_by_size[ht.bit_count()].append(ht)
 for st in subsets(nx+2):
  k=st.bit_count();ns=[leftns[i] for i in range(nx+2) if st>>i&1]
  sw=product(leftw[i] for i in range(nx+2) if st>>i&1)
  if not sw:continue
  for ht in right_by_size.get(k,[]):
   tw=product(rightw[j] for j in range(q+ny) if ht>>j&1)
   if tw and feasible(ns,ht):add(direct,(k,2-(ht>>q).bit_count(),fullq^(ht&fullq)),sw*tw)
 a,b=wp;A=a+b;B=a*b;R=sum(wy[y] for y in range(ny) if yns[y]);C=sum(wy[y]*sum(wp[p] for p in range(2) if yns[y]>>p&1) for y in range(ny))
 M=sum(wy[i]*wy[j] for i in range(ny) for j in range(i+1,ny) if (yns[i]&1 and yns[j]&2) or (yns[i]&2 and yns[j]&1))
 formula={};oldns=list(xns)+[1<<j for j in range(q)]
 for p,r,c in ((0,0,1),(1,0,A),(2,0,B),(1,1,C),(2,1,B*R),(2,2,B*M)):
  if not c:continue
  for im in subsets(nx+q):
   if im.bit_count()!=q-p+r:continue
   ns=[oldns[h] for h in range(nx+q) if im>>h&1]+[J]*(p-r)
   if not feasible(ns,fullq):continue
   xs=im&((1<<nx)-1);dm=im>>nx
   wt=c*product(wx[x] for x in range(nx) if xs>>x&1)*product(wq[j] for j in range(q) if not dm>>j&1)
   add(formula,(p+xs.bit_count(),2-r,dm),wt)
 assert formula==direct,(q,nx,ny,xns,J,yns,wp,wx,wq,wy,formula,direct)
 gamma=[0]*(q+3)
 for (k,z,dm),coef in direct.items():
  assert k+z+dm.bit_count()==q+2
  gamma[k]+=coef
 for k in range(1,q+2):assert gamma[k]**2*k*(q+2-k)>=gamma[k-1]*gamma[k+1]*(k+1)*(q+3-k)
 degree=max(k for k,a in enumerate(gamma) if a)
 if q==3:
  for k in range(1,degree):assert gamma[k]**2*k*(degree-k)>=gamma[k-1]*gamma[k+1]*(k+1)*(degree+1-k)
 return degree

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir',type=pathlib.Path,default=pathlib.Path(__file__).parent);args=ap.parse_args()
 start=time.monotonic();receipt={'status':'passed','scope':'exact ordinary-proof corroboration; not a finite proof premise','symbolic':symbolic()};counts={'cases':0,'full_degree':0,'zero_activity_cases':0,'nonuniversal_Y_cases':0}
 def run(q,nx,ny,xns,J,yns,wp,wx,wq,wy):
  d=case(q,nx,ny,xns,J,yns,wp,wx,wq,wy);counts['cases']+=1;counts['full_degree']+=d==q+2;counts['zero_activity_cases']+=any(w==0 for w in (*wp,*wx,*wq,*wy));counts['nonuniversal_Y_cases']+=any(ns!=3 for ns in yns)
 for q in (2,3):
  for flat in range(1<<(2*q)):
   xns=[flat&((1<<q)-1),flat>>q]
   for J in subsets(q):
    for yns in itertools.product((1,2,3),repeat=2):run(q,2,2,xns,J,yns,[1,2],[2,3],list(range(1,q+1)),[1,3])
 rng=random.Random(234708)
 for n in range(400):
  q=rng.randrange(2,6);nx=rng.randrange(0,6);ny=rng.randrange(0,5)
  xns=[rng.randrange(1<<q) for _ in range(nx)];J=rng.randrange(1<<q);yns=[rng.randrange(4) for _ in range(ny)]
  weights=[[rng.randrange(0,5) for _ in range(m)] for m in (2,nx,q,ny)]
  run(q,nx,ny,xns,J,yns,*weights)
 # Full-degree stress cases, with three Q-private X tails and two P-private Y heads.
 for n in range(100):
  q=3;nx=5;ny=4;xns=[1,2,4]+[rng.randrange(8) for _ in range(2)];J=rng.randrange(8);yns=[1,2,rng.randrange(4),rng.randrange(4)]
  weights=[[rng.randrange(1,6) for _ in range(m)] for m in (2,nx,q,ny)]
  run(q,nx,ny,xns,J,yns,*weights)
 receipt['finite']=counts;receipt['elapsed_seconds']=round(time.monotonic()-start,3)
 args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'arbitrary_exterior_verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
