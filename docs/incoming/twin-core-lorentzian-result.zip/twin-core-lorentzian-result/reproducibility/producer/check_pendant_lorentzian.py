#!/usr/bin/env python3
"""Exact support-formula checks for arbitrary-core pendant-head theorem."""
import argparse,itertools,json,pathlib,random,time
import sympy as s
from check_connector import feasible,product,add
if not __debug__:raise SystemExit('Run without -O: assertions are required.')
def case(r,q,nx,ny,core,xns,parents,wp,wx,wq,wy):
 ns=[core[p]|sum(1<<(q+y) for y in range(ny) if parents[y]==p) for p in range(r)]+xns
 wl=wp+wx;wr=wq+wy;direct={};fullq=(1<<q)-1;fullp=(1<<r)-1
 for st in range(1<<(r+nx)):
  k=st.bit_count();sw=product(wl[i] for i in range(r+nx) if st>>i&1)
  if not sw:continue
  for ht in range(1<<(q+ny)):
   if ht.bit_count()!=k:continue
   tw=product(wr[j] for j in range(q+ny) if ht>>j&1)
   if tw and feasible([ns[i] for i in range(r+nx) if st>>i&1],ht):
    usedp=sum(1<<parents[y] for y in range(ny) if ht>>(q+y)&1)
    add(direct,(k,fullp^usedp,fullq^(ht&fullq)),sw*tw)
 L=[sum(wy[y] for y in range(ny) if parents[y]==p) for p in range(r)]
 oldns=core+xns+[1<<j for j in range(q)];formula={}
 for im in range(1<<(r+nx+q)):
  if im.bit_count()!=q:continue
  if not feasible([oldns[i] for i in range(r+nx+q) if im>>i&1],fullq):continue
  pm=im&fullp;xm=(im>>r)&((1<<nx)-1);dm=im>>(r+nx)
  wt=product(wp[p] for p in range(r) if pm>>p&1)*product(wx[x] for x in range(nx) if xm>>x&1)*product(wq[j] for j in range(q) if not dm>>j&1)
  for attach in range(1<<r):
   if attach&pm:continue
   aw=product(wp[p]*L[p] for p in range(r) if attach>>p&1)
   add(formula,(pm.bit_count()+xm.bit_count()+attach.bit_count(),fullp^attach,dm),wt*aw)
 assert direct==formula,(r,q,core,xns,parents,wp,wx,wq,wy,direct,formula)
 gamma=[0]*(q+r+1)
 for (k,mp,mq),coef in direct.items():
  assert k+mp.bit_count()+mq.bit_count()==q+r;gamma[k]+=coef
 for k in range(1,q+r):assert gamma[k]**2*k*(q+r-k)>=gamma[k-1]*gamma[k+1]*(k+1)*(q+r+1-k)
 return max(k for k,a in enumerate(gamma) if a)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir',type=pathlib.Path,default=pathlib.Path(__file__).parent);args=ap.parse_args()
 start=time.monotonic();z,v,t,u,L=s.symbols('z v t u L');H=s.hessian(z*v+u*L*t*v+u*t*z,(z,v,t));assert s.expand(H.det()-2*u*u*L)==0
 counts={'cases':0,'full_degree':0,'zero_activity_cases':0,'distinct_core_rows_cases':0}
 def run(r,q,nx,ny,core,xns,parents,wp,wx,wq,wy):
  d=case(r,q,nx,ny,core,xns,parents,wp,wx,wq,wy);counts['cases']+=1;counts['full_degree']+=d==q+r;counts['zero_activity_cases']+=any(a==0 for a in wp+wx+wq+wy);counts['distinct_core_rows_cases']+=len(set(core))>1
 for flat in range(64):
  core=[flat&7,flat>>3]
  for xns in range(8):
   for parents in itertools.product(range(2),repeat=2):run(2,3,1,2,core,[xns],list(parents),[2,3],[2],[1,2,3],[1,3])
 rng=random.Random(620011)
 for n in range(300):
  r=rng.randrange(1,4);q=rng.randrange(1,5);nx=rng.randrange(0,4);ny=rng.randrange(0,5)
  core=[rng.randrange(1<<q) for _ in range(r)];xns=[rng.randrange(1<<q) for _ in range(nx)];parents=[rng.randrange(r) for _ in range(ny)]
  ws=[[rng.randrange(0,5) for _ in range(m)] for m in (r,nx,q,ny)];run(r,q,nx,ny,core,xns,parents,*ws)
 for n in range(100):
  core=[rng.randrange(8) for _ in range(2)];xns=[1,2,4];ws=[[rng.randrange(1,5) for _ in range(m)] for m in (2,3,3,2)]
  run(2,3,3,2,core,xns,[0,1],*ws)
 receipt={'status':'passed','scope':'corroboration of an ordinary proof','quadratic_symbol_determinant':'2*u^2*L','finite':counts,'elapsed_seconds':round(time.monotonic()-start,3)}
 args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'pendant_verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
