#!/usr/bin/env python3
"""Exact corroboration for the ordinary connector proof; no finite search premise."""
import argparse, hashlib, itertools, json, math, pathlib, random, time
import sympy as sp
if not __debug__:
    raise SystemExit('Run without -O: checks use assertions.')

def subsets(n):
    return range(1<<n)
def product(vals):
    return math.prod(vals)
def feasible(neighbors, heads):
    reached={0}
    for ns in neighbors:
        reached={m|(1<<h) for m in reached for h in range(heads.bit_length())
                 if (heads & ns & (1<<h)) and not (m & (1<<h))}
        if not reached:return False
    return heads in reached

def elementary(vals,k):
    return sum(product(a) for a in itertools.combinations(vals,k))
def add(d,k,v):
    if v:d[k]=d.get(k,0)+v

def case(q, nx, ny, xns, J, wp, wx, wq, wy):
    # Direct endpoint supports in the actual bipartite graph.
    leftns=[J|(((1<<ny)-1)<<q)]*2+list(xns)
    leftw=list(wp)+list(wx); rightw=list(wq)+list(wy)
    direct={}; fullq=(1<<q)-1
    right_by_size={k:[] for k in range(q+ny+1)}
    for ht in subsets(q+ny):right_by_size[ht.bit_count()].append(ht)
    for st in subsets(2+nx):
        k=st.bit_count()
        if k not in right_by_size:continue
        ns=[leftns[i] for i in range(2+nx) if st>>i&1]
        sw=product(leftw[i] for i in range(2+nx) if st>>i&1)
        for ht in right_by_size[k]:
            tw=product(rightw[j] for j in range(q+ny) if ht>>j&1)
            if sw*tw and feasible(ns,ht):
                r=(ht>>q).bit_count(); dummy=fullq^(ht&fullq)
                add(direct,(k,2-r,dummy),sw*tw)
    # Independent clone-seed formula, summed over selected old matroid sets.
    formula={}; oldns=list(xns)+[1<<j for j in range(q)]
    for p in range(3):
        ep=elementary(wp,p)
        for r in range(p+1):
            er=elementary(wy,r); i=p-r
            for im in subsets(nx+q):
                if im.bit_count()!=q-i:continue
                ns=[oldns[h] for h in range(nx+q) if im>>h&1]+[J]*i
                if not feasible(ns,fullq):continue
                xs=im&((1<<nx)-1); dm=im>>nx
                wt=ep*er*product(wx[x] for x in range(nx) if xs>>x&1)*product(wq[j] for j in range(q) if not(dm>>j&1))
                add(formula,(p+xs.bit_count(),2-r,dm),wt)
    assert direct==formula,(q,nx,ny,xns,J,wp,wx,wq,wy,direct,formula)
    gamma=[0]*(q+3)
    for (k,z,dm),coef in direct.items():
        assert k+z+dm.bit_count()==q+2
        gamma[k]+=coef
    for k in range(1,q+2):
        assert gamma[k]**2*k*(q+2-k)>=gamma[k-1]*gamma[k+1]*(k+1)*(q+3-k)
    return max(k for k,a in enumerate(gamma) if a), any(a==0 for a in (*wp,*wx,*wq,*wy))

def symbolic():
    v,z,t,A,B,R,S,y=sp.symbols('v z t A B R S y')
    Q0=z*z+A*R*z*t+B*S*t*t; Q1=t*(A*z*z+B*R*z*t); Q2=B*z*z*t*t
    K=v*v*z*z+A*R*v*v*z*t+B*S*v*v*t*t+2*A*v*z*z*t+2*B*R*v*z*t*t+2*B*z*z*t*t
    assert sp.expand(K-(Q0*v*v+2*Q1*v+2*Q2))==0
    variables=(v,z,t)
    pure_expected=(4*(4*B*S-A*A*R*R),16*(2*B-A*A),16*B*B*(2*S-R*R))
    pure_indices=((1,2),(0,2),(0,1))
    for x,inds,expected in zip(variables,pure_indices,pure_expected):
        H=sp.hessian(sp.diff(K,x,2),variables)
        assert sp.expand(H.extract(inds,inds).det()-expected)==0
    mixed_expected=(64*R*(A*A-B),64*A*B*B*S*(R*R-S),128*A*B*B*R)
    for (x,xx),ex in zip(((v,z),(v,t),(z,t)),mixed_expected):
        assert sp.expand(sp.hessian(sp.diff(K,x,xx),variables).det()-ex)==0
    i0,i1,i2=sp.symbols('i0 i1 i2')
    f=i0+y*i1+y*y*i2/2
    out=Q0*f.subs(y,0)+Q1*sp.diff(f,y).subs(y,0)+Q2*sp.diff(f,y,2).subs(y,0)
    assert sp.expand(out-(Q0*i0+Q1*i1+Q2*i2))==0
    return {'pure_hessian_determinants':3,'mixed_hessian_determinants':3,'factorial_symbol_and_action':2}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output-dir',type=pathlib.Path,default=pathlib.Path(__file__).parent);args=ap.parse_args()
    start=time.monotonic();counts={'cases':0,'full_degree':0,'zero_activity_cases':0,'universal_core_cases':0,'twin_nonuniversal_cases':0}
    sym=symbolic();rng=random.Random(618092)
    # All X-neighborhood masks and all twin core neighborhoods at q=2,3,nx=2.
    for q in (2,3):
        for flat in range(1<<(2*q)):
            xns=[flat&((1<<q)-1),flat>>q]
            for J in subsets(q):
                wp=[1,2];wx=[2,3];wq=list(range(1,q+1));wy=[1,3]
                d,zz=case(q,2,2,xns,J,wp,wx,wq,wy)
                counts['cases']+=1;counts['full_degree']+=d==q+2;counts['zero_activity_cases']+=zz
                counts['universal_core_cases']+=J==(1<<q)-1;counts['twin_nonuniversal_cases']+=J!=(1<<q)-1
    for n in range(240):
        q=rng.randrange(2,6);nx=rng.randrange(0,5);ny=rng.randrange(0,4)
        J=(1<<q)-1 if n%2==0 else rng.randrange(1<<q)
        xns=[rng.randrange(1<<q) for _ in range(nx)]
        weights=[[rng.randrange(0,5) for _ in range(m)] for m in (2,nx,q,ny)]
        d,zz=case(q,nx,ny,xns,J,*weights)
        counts['cases']+=1;counts['full_degree']+=d==q+2;counts['zero_activity_cases']+=zz
        counts['universal_core_cases']+=J==(1<<q)-1;counts['twin_nonuniversal_cases']+=J!=(1<<q)-1
    receipt={'status':'passed','scope':'exact symbolic and finite corroboration, not a proof premise','symbolic':sym,'finite':counts,'elapsed_seconds':round(time.monotonic()-start,3)}
    args.output_dir.mkdir(parents=True,exist_ok=True)
    (args.output_dir/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
