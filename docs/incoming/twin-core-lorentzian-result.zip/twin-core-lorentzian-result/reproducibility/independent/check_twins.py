#!/usr/bin/env python3
"""Independent generalized twin-core Hessians, clone bases and endpoint identity."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
from itertools import combinations,product
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict,Counter
from math import factorial
import argparse,hashlib,json,random,time
import sympy as s
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-note',type=Path,default=Path('/workspace/shared/two-universal-tail-lorentzian/TWIN_CORE_ARBITRARY_EXTERIORS.md'))
p.add_argument('--output-dir',type=Path,default=Path(__file__).parent)
args=p.parse_args();started=time.monotonic()
A,B,R,S,C,M,v,z,t=s.symbols('A B R S C M v z t')
Q0=z*z+C*z*t+B*M*t*t;Q1=t*(A*z*z+B*R*z*t);Q2=B*z*z*t*t
K=s.expand(Q0*v*v+2*Q1*v+2*Q2);vars=(v,z,t)
assert len(s.Poly(K,*vars).terms())==6
support=set(s.Poly(K,*vars).monoms())
assert support=={e for e in product(range(3),repeat=3)if sum(e)==4}
exchanges=0
for a in support:
 for b in support:
  for i in range(3):
   if a[i]>b[i]:
    assert any(tuple(a[h]-int(h==i)+int(h==j)for h in range(3))in support and tuple(b[h]+int(h==i)-int(h==j)for h in range(3))in support for j in range(3)if a[j]<b[j]);exchanges+=1
mixed_matrices=[s.Matrix([[0,4,2*C],[4,0,4*A],[2*C,4*A,4*B*R]]),s.Matrix([[0,2*C,4*B*M],[2*C,4*A,4*B*R],[4*B*M,4*B*R,0]]),s.Matrix([[2*C,4*A,4*B*R],[4*A,0,8*B],[4*B*R,8*B,0]])]
mixed_dets=[64*(A*C-B*R),64*B*B*M*(C*R-A*M),128*B*B*(2*A*R-C)]
mixed=[]
for (i,j),matrix,wanted in zip([(0,1),(0,2),(1,2)],mixed_matrices,mixed_dets):
 h=s.hessian(s.diff(K,vars[i],vars[j]),vars)
 assert h==matrix and s.factor(h.det()-wanted)==0
 mixed.append(str(s.factor(h.det())))
pure_dets=[]
for i,wanted in enumerate([4*(4*B*M-C*C),16*(2*B-A*A),16*B*B*(2*M-R*R)]):
 h=s.hessian(s.diff(K,vars[i],2),vars);indices=[j for j in range(3)if j!=i]
 det=h.extract(indices,indices).det();assert s.factor(det-wanted)==0
 pure_dets.append(str(s.factor(det)))
# Explicitly check factorial cancellation in the connector action.
Iq,Iq1,Iq2,y=s.symbols('Iq Iq1 Iq2 y');f=Iq+y*Iq1+y*y*Iq2/2
image=Q0*f.subs(y,0)+Q1*s.diff(f,y).subs(y,0)+Q2*s.diff(f,y,2).subs(y,0)
assert s.expand(image-(Q0*Iq+Q1*Iq1+Q2*Iq2))==0
n=s.symbols('n',positive=True)
for j in range(9):
 expr=s.Rational(1,factorial(j))*s.prod(n-i for i in range(j))
 assert s.limit(expr/n**j,n,s.oo)==s.Rational(1,factorial(j))

def multiply(xs):
 out=1
 for x in xs:out*=x
 return out
def selected_full_supports(q,rows,J,ymasks):
 ny=len(ymasks);nx=len(rows);nr=q+ny;leftrows=[J+sum(1<<(q+k)for k,mask in enumerate(ymasks)if mask>>p&1)for p in range(2)]+list(rows);out=[];tests=0
 for k in range(min(len(leftrows),nr)+1):
  for left in combinations(range(len(leftrows)),k):
   for right in combinations(range(nr),k):
    tests+=1;headmask=sum(1<<j for j in right);neighbors=tuple(leftrows[i]&headmask for i in left)
    @lru_cache(None)
    def matching(at,used):
     if at==len(neighbors):return True
     allowed=neighbors[at]&~used
     while allowed:
      bit=allowed&-allowed;allowed-=bit
      if matching(at+1,used|bit):return True
     return False
    if matching(0,0):out.append((left,right,k,ny-sum(j>=q for j in right),sum(1<<j for j in range(q)if j not in right)))
 return out,tests
def old_independent_sets(q,rows,J):
 nx=len(rows);ground=list(rows)+[1<<j for j in range(q)];out=[];tests=0
 for size in range(max(0,q-2),q+1):
  for selected in combinations(range(len(ground)),size):
   tests+=1;independent=True
   selected_neighbors=[ground[e]for e in selected]+[J]*(q-size)
   for sub in range(1,1<<q):
    union=0
    for i,neighbors in enumerate(selected_neighbors):
     if sub>>i&1:union|=neighbors
    if union.bit_count()<sub.bit_count():independent=False;break
   if independent:
    xs=tuple(i for i in selected if i<nx);dummies=sum(1<<(i-nx)for i in selected if i>=nx)
    out.append((xs,dummies,q-size))
 return out,tests
def check_case(q,rows,ymasks,weights,full,indep):
 ny=len(ymasks)
 nx=len(rows);up=weights[:2];ux=weights[2:2+nx];vq=weights[2+nx:2+nx+q];vy=weights[2+nx+q:]
 AA=sum(up);BB=multiply(up);RR=sum(vy);CC=sum(up[i]*vy[j]for i in range(2)for j,mask in enumerate(ymasks)if mask>>i&1);MM=sum(vy[i]*vy[j]for i,j in combinations(range(ny),2)if ymasks[i]|ymasks[j]==3)
 actual=defaultdict(F)
 for left,right,k,unused_y,unused_q in full:
  # F's global z exponent is2 minus the number of selected Y heads, not unused-Y count.
  selected_y=ny-unused_y
  value=multiply(weights[i]for i in left)*multiply((vq+vy)[j]for j in right)
  actual[(k,2-selected_y,unused_q)]+=value
 predicted=defaultdict(F)
 images={0:[(0,0,1),(1,1,CC),(2,2,BB*MM)],1:[(1,0,AA),(2,1,BB*RR)],2:[(2,0,2*BB)]}
 for xs,dummy,defect in indep:
  value=F(multiply(ux[i]for i in xs)*multiply(vq[j]for j in range(q)if not dummy>>j&1),factorial(defect))
  for selected_p,selected_y,coefficient in images[defect]:predicted[(len(xs)+selected_p,2-selected_y,dummy)]+=value*coefficient
 actual={key:value for key,value in actual.items()if value};predicted={key:value for key,value in predicted.items()if value}
 assert actual==predicted
 gamma=[F(0)]*(q+3)
 for (k,zz,dummy),value in actual.items():
  assert k+zz+dummy.bit_count()==q+2
  gamma[k]+=value
 assert gamma[0]==1
 degree=max(i for i,value in enumerate(gamma)if value)
 for k in range(1,q+2):assert k*(q+2-k)*gamma[k]**2>=(k+1)*(q+3-k)*gamma[k-1]*gamma[k+1]
 if q==3:
  for k in range(1,degree):assert k*(degree-k)*gamma[k]**2>=(k+1)*(degree-k+1)*gamma[k-1]*gamma[k+1]
 return degree
# Independent scalar identities using the actual private/common Y moments.
a,b,L0,L1,H,ss=s.symbols('a b L0 L1 H ss')
sub={A:a+b,B:a*b,R:L0+L1+H,M:L0*L1+H*(L0+L1)+ss,C:a*(L0+H)+b*(L1+H)}
scalar=[(A*A-2*B,a*a+b*b),(R*R-2*M,L0*L0+L1*L1+H*H-2*ss),(C*C-4*B*M,(a*(L0+H)-b*(L1+H))**2+4*a*b*(H*H-ss)),(A*C-B*R,a*a*(L0+H)+b*b*(L1+H)+a*b*H),(C*R-A*M,a*(L0*L0+L0*H+H*H-ss)+b*(L1*L1+L1*H+H*H-ss)),(2*A*R-C,a*(L0+2*L1+H)+b*(2*L0+L1+H))]
for left,right in scalar:assert s.expand(left.subs(sub)-right)==0

graphs=[]
for q in [2,3]:
 for rows in product(range(1<<q),repeat=2):
  for J in range(1<<q):
   for ymasks in product([1,2,3],repeat=2):graphs.append((q,rows,J,ymasks))
rng=random.Random(261001)
for q,number in [(3,150),(4,40),(5,12)]:
 for _ in range(number):graphs.append((q,tuple(rng.randrange(1<<q)for i in range(q)),rng.randrange(1<<q),tuple(rng.randrange(1,4)for i in range(3))))
counts=Counter();full_tests=independent_tests=cases=0;zero_cases=0
for q,rows,J,ymasks in graphs:
 full,nfull=selected_full_supports(q,rows,J,ymasks);indep,nindep=old_independent_sets(q,rows,J)
 full_tests+=nfull;independent_tests+=nindep
 nvertices=2+len(rows)+q+len(ymasks)
 for kind in range(4):
  weights=[1 if kind==0 else (i%4+1 if kind==1 else (0 if i%(3 if kind==2 else 4)==(0 if kind==2 else 3) else i%5+1))for i in range(nvertices)]
  degree=check_case(q,rows,ymasks,weights,full,indep);cases+=1;counts[f'q{q}/degree{degree}']+=1
  if kind>=2:zero_cases+=1
receipt={'verdict':'PASS','source_sha256':hashlib.sha256(args.source_note.read_bytes()).hexdigest(),'quartic_support_monomials':len(support),'symmetric_exchange_checks':exchanges,'pure_second_derivative_determinants':pure_dets,'mixed_hessian_determinants':mixed,'scalar_nonnegative_identity_checks':len(scalar),'factorial_limit_checks':9,'factorial_operator_identity':True,'side_graphs':len(graphs),'weighted_multivariate_support_identities':cases,'zero_weight_cases':zero_cases,'literal_endpoint_pairs_tested':full_tests,'clone_basis_Hall_tests':independent_tests,'degree_counts':dict(sorted(counts.items())),'all_outputs_homogeneous_order_q_plus_two':True,'order_q_plus_two_ULC_checks':'PASS','q3_actual_degree_checks':'PASS','population_or_rank_cutoff_is_not_a_proof_input':True,'elapsed_seconds':round(time.monotonic()-started,3)}
args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'independent_twin_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
