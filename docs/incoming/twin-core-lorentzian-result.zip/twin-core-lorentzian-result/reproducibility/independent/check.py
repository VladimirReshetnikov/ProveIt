#!/usr/bin/env python3
"""Independent connector Hessians, factorials, matroid/endpoint weighted identity."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
from itertools import combinations,product
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict,Counter
from math import factorial
import argparse,hashlib,json,random,time
import sympy as s
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-note',type=Path,default=Path('/workspace/shared/two-universal-tail-lorentzian/TWO_UNIVERSAL_TAIL_CONNECTOR.md'))
p.add_argument('--output-dir',type=Path,default=Path(__file__).parent)
args=p.parse_args();started=time.monotonic()
A,B,R,S,v,z,t=s.symbols('A B R S v z t')
Q0=z*z+A*R*z*t+B*S*t*t;Q1=t*(A*z*z+B*R*z*t);Q2=B*z*z*t*t
K=s.expand(Q0*v*v+2*Q1*v+2*Q2);vars=(v,z,t)
assert len(s.Poly(K,*vars).terms())==6
support=set(s.Poly(K,*vars).monoms())
assert support=={e for e in product(range(3),repeat=3)if sum(e)==4}
exchanges=0
for a in support:
 for b in support:
  for i in range(3):
   if a[i]>b[i]:
    assert any(tuple(a[h]-int(h==i)+int(h==j)for h in range(3))in support and tuple(b[h]+int(h==i)-int(h==j)for h in range(3))in support for j in range(3)if a[j]<b[j]);exchanges+=1
mixed_matrices=[s.Matrix([[0,4,2*A*R],[4,0,4*A],[2*A*R,4*A,4*B*R]]),s.Matrix([[0,2*A*R,4*B*S],[2*A*R,4*A,4*B*R],[4*B*S,4*B*R,0]]),s.Matrix([[2*A*R,4*A,4*B*R],[4*A,0,8*B],[4*B*R,8*B,0]])]
mixed_dets=[64*R*(A*A-B),64*A*B*B*S*(R*R-S),128*A*B*B*R]
mixed=[]
for (i,j),matrix,wanted in zip([(0,1),(0,2),(1,2)],mixed_matrices,mixed_dets):
 h=s.hessian(s.diff(K,vars[i],vars[j]),vars)
 assert h==matrix and s.factor(h.det()-wanted)==0
 mixed.append(str(s.factor(h.det())))
pure_dets=[]
for i,wanted in enumerate([4*(4*B*S-A*A*R*R),16*(2*B-A*A),16*B*B*(2*S-R*R)]):
 h=s.hessian(s.diff(K,vars[i],2),vars);indices=[j for j in range(3)if j!=i]
 det=h.extract(indices,indices).det();assert s.factor(det-wanted)==0
 pure_dets.append(str(s.factor(det)))
# Explicitly check factorial cancellation in the connector action.
Iq,Iq1,Iq2,y=s.symbols('Iq Iq1 Iq2 y');f=Iq+y*Iq1+y*y*Iq2/2
image=Q0*f.subs(y,0)+Q1*s.diff(f,y).subs(y,0)+Q2*s.diff(f,y,2).subs(y,0)
assert s.expand(image-(Q0*Iq+Q1*Iq1+Q2*Iq2))==0
n=s.symbols('n',positive=True)
for j in range(9):
 expr=s.Rational(1,factorial(j))*s.prod(n-i for i in range(j))
 assert s.limit(expr/n**j,n,s.oo)==s.Rational(1,factorial(j))

def multiply(xs):
 out=1
 for x in xs:out*=x
 return out
def selected_full_supports(q,rows,ny):
 nx=len(rows);nr=q+ny;leftrows=[(1<<nr)-1]*2+list(rows);out=[];tests=0
 for k in range(min(len(leftrows),nr)+1):
  for left in combinations(range(len(leftrows)),k):
   for right in combinations(range(nr),k):
    tests+=1;headmask=sum(1<<j for j in right);neighbors=tuple(leftrows[i]&headmask for i in left)
    @lru_cache(None)
    def matching(at,used):
     if at==len(neighbors):return True
     allowed=neighbors[at]&~used
     while allowed:
      bit=allowed&-allowed;allowed-=bit
      if matching(at+1,used|bit):return True
     return False
    if matching(0,0):out.append((left,right,k,ny-sum(j>=q for j in right),sum(1<<j for j in range(q)if j not in right)))
 return out,tests
def old_independent_sets(q,rows):
 nx=len(rows);ground=list(rows)+[1<<j for j in range(q)];out=[];tests=0
 for size in range(max(0,q-2),q+1):
  for selected in combinations(range(len(ground)),size):
   tests+=1;independent=True
   for sub in range(1,1<<size):
    union=0
    for i,e in enumerate(selected):
     if sub>>i&1:union|=ground[e]
    if union.bit_count()<sub.bit_count():independent=False;break
   if independent:
    xs=tuple(i for i in selected if i<nx);dummies=sum(1<<(i-nx)for i in selected if i>=nx)
    out.append((xs,dummies,q-size))
 return out,tests
def check_case(q,rows,ny,weights,full,indep):
 nx=len(rows);up=weights[:2];ux=weights[2:2+nx];vq=weights[2+nx:2+nx+q];vy=weights[2+nx+q:]
 AA=sum(up);BB=multiply(up);RR=sum(vy);SS=sum(a*b for a,b in combinations(vy,2))
 actual=defaultdict(F)
 for left,right,k,unused_y,unused_q in full:
  # F's global z exponent is2 minus the number of selected Y heads, not unused-Y count.
  selected_y=ny-unused_y
  value=multiply(weights[i]for i in left)*multiply((vq+vy)[j]for j in right)
  actual[(k,2-selected_y,unused_q)]+=value
 predicted=defaultdict(F)
 images={0:[(0,0,1),(1,1,AA*RR),(2,2,BB*SS)],1:[(1,0,AA),(2,1,BB*RR)],2:[(2,0,2*BB)]}
 for xs,dummy,defect in indep:
  value=F(multiply(ux[i]for i in xs)*multiply(vq[j]for j in range(q)if not dummy>>j&1),factorial(defect))
  for selected_p,selected_y,coefficient in images[defect]:predicted[(len(xs)+selected_p,2-selected_y,dummy)]+=value*coefficient
 actual={key:value for key,value in actual.items()if value};predicted={key:value for key,value in predicted.items()if value}
 assert actual==predicted
 gamma=[F(0)]*(q+3)
 for (k,zz,dummy),value in actual.items():
  assert k+zz+dummy.bit_count()==q+2
  gamma[k]+=value
 assert gamma[0]==1
 degree=max(i for i,value in enumerate(gamma)if value)
 for k in range(1,q+2):assert k*(q+2-k)*gamma[k]**2>=(k+1)*(q+3-k)*gamma[k-1]*gamma[k+1]
 if q==3:
  for k in range(1,degree):assert k*(degree-k)*gamma[k]**2>=(k+1)*(degree-k+1)*gamma[k-1]*gamma[k+1]
 return degree
graphs=[]
for q in [2,3]:
 for nx in range(3):
  for rows in product(range(1<<q),repeat=nx):
   for ny in [0,1,2]:graphs.append((q,rows,ny))
for rows in product(range(8),repeat=3):graphs.append((3,rows,2))
rng=random.Random(261001)
for q,number in [(4,40),(5,12)]:
 for _ in range(number):graphs.append((q,tuple(rng.randrange(1<<q)for i in range(q)),2))
counts=Counter();full_tests=independent_tests=cases=0;zero_cases=0
for q,rows,ny in graphs:
 full,nfull=selected_full_supports(q,rows,ny);indep,nindep=old_independent_sets(q,rows)
 full_tests+=nfull;independent_tests+=nindep
 nvertices=2+len(rows)+q+ny
 for kind in range(3):
  weights=[1 if kind==0 else (i%4+1 if kind==1 else (0 if i%3==0 else i%5+1))for i in range(nvertices)]
  degree=check_case(q,rows,ny,weights,full,indep);cases+=1;counts[f'q{q}/degree{degree}']+=1
  if kind==2:zero_cases+=1
receipt={'verdict':'PASS','source_sha256':hashlib.sha256(args.source_note.read_bytes()).hexdigest(),'quartic_support_monomials':len(support),'symmetric_exchange_checks':exchanges,'pure_second_derivative_determinants':pure_dets,'mixed_hessian_determinants':mixed,'factorial_limit_checks':9,'factorial_operator_identity':True,'side_graphs':len(graphs),'weighted_multivariate_support_identities':cases,'zero_weight_cases':zero_cases,'literal_endpoint_pairs_tested':full_tests,'matroid_independence_tests':independent_tests,'degree_counts':dict(sorted(counts.items())),'all_outputs_homogeneous_order_q_plus_two':True,'order_q_plus_two_ULC_checks':'PASS','q3_actual_degree_checks':'PASS','population_or_rank_cutoff_is_not_a_proof_input':True,'elapsed_seconds':round(time.monotonic()-started,3)}
args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'independent_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
