#!/usr/bin/env python3
"""Independent private-head Lorentzian operator and exact endpoint correspondence."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
from itertools import combinations,product
from functools import lru_cache
from collections import defaultdict,Counter
from math import prod
import argparse,json,hashlib,time,random
import sympy as s
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-note',type=Path,default=Path('/workspace/shared/two-universal-tail-lorentzian/PENDANT_HEAD_LORENTZIAN_EXTENSION.md'));p.add_argument('--output-dir',type=Path,default=Path(__file__).parent);args=p.parse_args();start=time.monotonic()
u,L,z,v,t=s.symbols('u L z v t');K=z*v+u*L*t*v+u*t*z;h=s.hessian(K,(z,v,t));assert h.det()==2*u*u*L

def matches(neighbors):
 @lru_cache(None)
 def f(i,used):
  if i==len(neighbors):return True
  allow=neighbors[i]&~used
  while allow:
   bit=allow&-allow;allow-=bit
   if f(i+1,used|bit):return True
  return False
 return f(0,0)
def supports(r,q,core,xrows,owners):
 ny=len(owners);left=[core[i]|sum(1<<(q+j)for j,owner in enumerate(owners)if owner==i)for i in range(r)]+list(xrows);ans=[];ntests=0
 for k in range(min(len(left),q+ny)+1):
  for tails in combinations(range(len(left)),k):
   for heads in combinations(range(q+ny),k):
    ntests+=1;mask=sum(1<<j for j in heads)
    if matches(tuple(left[i]&mask for i in tails)):
     selectedowners=[owners[j-q]for j in heads if j>=q];assert len(selectedowners)==len(set(selectedowners))
     zp=sum(1<<i for i in range(r)if i not in selectedowners);zq=sum(1<<j for j in range(q)if j not in heads)
     ans.append((tails,heads,k,zp,zq))
 return ans,ntests
def basis_sets(r,q,core,xrows):
 rows=list(core)+list(xrows)+[1<<j for j in range(q)];ans=[];ntests=0
 for selected in combinations(range(len(rows)),q):
  ntests+=1
  # Literal Hall, distinct from the full-support recursion.
  ok=True
  for mask in range(1,1<<q):
   union=0
   for i,j in enumerate(selected):
    if mask>>i&1:union|=rows[j]
   if union.bit_count()<mask.bit_count():ok=False;break
  if ok:ans.append(selected)
 return ans,ntests
def check(r,q,core,xrows,owners,weights,full,bases):
 nx=len(xrows);nl=r+nx;up=weights[:r];ux=weights[r:nl];vq=weights[nl:nl+q];vy=weights[nl+q:];Lp=[sum(vy[j]for j,owner in enumerate(owners)if owner==i)for i in range(r)]
 actual=defaultdict(int)
 for tails,heads,k,zp,zq in full:actual[(k,zp,zq)]+=prod(weights[i]for i in tails)*prod((vq+vy)[j]for j in heads)
 predicted=defaultdict(int)
 for selected in bases:
  selectedp=set(i for i in selected if i<r);selectedx=[i-r for i in selected if r<=i<nl];dummies=set(i-nl for i in selected if i>=nl)
  baseweight=prod(up[i]for i in selectedp)*prod(ux[i]for i in selectedx)*prod(vq[j]for j in range(q)if j not in dummies)
  absent=[i for i in range(r)if i not in selectedp]
  for mask in range(1<<len(absent)):
   usey=[i for j,i in enumerate(absent)if mask>>j&1]
   key=(len(selectedp)+len(selectedx)+len(usey),sum(1<<i for i in range(r)if i not in usey),sum(1<<j for j in dummies))
   predicted[key]+=baseweight*prod(up[i]*Lp[i]for i in usey)
 actual={k:v for k,v in actual.items()if v};predicted={k:v for k,v in predicted.items()if v};assert actual==predicted
 gamma=[0]*(q+r+1)
 for (k,zp,zq),value in actual.items():assert k+zp.bit_count()+zq.bit_count()==q+r;gamma[k]+=value
 assert gamma[0]==1
 for k in range(1,q+r):assert k*(q+r-k)*gamma[k]**2>=(k+1)*(q+r-k+1)*gamma[k-1]*gamma[k+1]
 degree=max(k for k,v in enumerate(gamma)if v)
 if (r,q)==(2,3):
  for k in range(1,degree):assert k*(degree-k)*gamma[k]**2>=(k+1)*(degree-k+1)*gamma[k-1]*gamma[k+1]
 return degree
cases=[]
for r,q in [(2,3),(3,2)]:
 for core in product(range(1<<q),repeat=r):
  for xmask in range(1<<q):
   for owners in [tuple(range(r)),tuple(range(r))+(0,)]:cases.append((r,q,core,(xmask,),owners))
rng=random.Random(1310)
for r,q in [(0,2),(2,0),(1,1),(2,3),(3,3),(4,2)]:
 for _ in range(12):cases.append((r,q,tuple(rng.randrange(1<<q)for i in range(r)),tuple(rng.randrange(1<<q)for i in range(max(3,q))),tuple(i for i in range(r)for j in range(rng.randrange(3)))))
counts=Counter();nf=nb=nweighted=0
for r,q,core,xrows,owners in cases:
 full,f=supports(r,q,core,xrows,owners);bases,b=basis_sets(r,q,core,xrows);nf+=f;nb+=b
 for kind in range(3):
  weights=[1 if kind==0 else i%4+1 if kind==1 else 0 if i%3==0 else i%5+1 for i in range(r+len(xrows)+q+len(owners))]
  d=check(r,q,core,xrows,owners,weights,full,bases);nweighted+=1;counts[f'{r}+{q}/degree{d}']+=1
receipt={'verdict':'PASS','source_sha256':hashlib.sha256(args.source_note.read_bytes()).hexdigest(),'quadratic_hessian_determinant':str(h.det()),'graphs':len(cases),'weighted_multivariate_support_identities':nweighted,'zero_weight_cases':len(cases),'literal_endpoint_pairs_tested':nf,'matroid_basis_Hall_tests':nb,'degree_counts':dict(sorted(counts.items())),'order_q_plus_r_checks':'PASS','r2_q3_actual_degree_checks':'PASS','finite_checks_are_supplementary':True,'elapsed_seconds':round(time.monotonic()-start,3)}
args.output_dir.mkdir(parents=True,exist_ok=True);(args.output_dir/'independent_private_head_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
