#!/bin/sh
set -eu
cd "$(dirname "$0")/article"
pdflatex -interaction=nonstopmode -halt-on-error twin-core-lorentzian.tex
pdflatex -interaction=nonstopmode -halt-on-error twin-core-lorentzian.tex
