# Lorentzian polynomials for twin core matching supports

This release gives two ordinary all-size weighted endpoint-support theorems.

1. Two covered tails have identical internal neighborhoods in q covered heads. Both exterior neighborhoods are arbitrary. The explicitly defined support homogenization is Lorentzian of degree q+2.
2. With r covered tails and q covered heads, arbitrary internal and exterior-tail edges are allowed when every exterior head has a private covered-tail neighbor. A second homogenization is Lorentzian of degree q+r, without any stable-seed assumption.

For two covered tails and three covered heads, both results give actual-degree ultra-log-concavity under all independent nonnegative activities, using the frozen rank-four theorem exactly when the surviving degree falls below five. For arbitrary q or r, the statements use the displayed cover order, not an unproved surviving-degree renormalization.

The graph shores are physically disjoint. Distinct internal rows together with shared exterior heads, and directed physical-role overlap, remain outside these theorems. No blanket strictness or real-rootedness is claimed.

## Read and replay

- `article/twin-core-lorentzian.pdf`: five-page paper with complete ordinary proofs
- `article/twin-core-lorentzian.tex`: editable source
- `proof-notes/`: four historically frozen, independently approved derivations
- `reproducibility/producer/`: three exact symbolic and endpoint-formula checkers
- `reproducibility/independent/`: three independently written checkers and receipts
- `audits/`: ordinary-proof approvals and integrated review
- `dependency/`: unchanged rank-four package, readable PDF and source note
- `qa/visual-qa.json`: page-by-page visual review record

Use Python 3.11 or newer with SymPy 1.14.0, then run `python verify.py`. The driver verifies exact manifest coverage, all approval pins, the nested dependency and its complete delivered replay, and all six new checkers. Every deterministic receipt field must match. Work is performed in temporary directories; the released files are not rewritten. Optimized Python execution with `-O` is rejected because the checkers use assertions. Runtime depends on the machine.

Use `sh build.sh` in a normal TeX Live environment to rebuild the paper. The PDF is supplied ready to read; byte-identical PDF rebuilds are not promised because TeX metadata may vary.

## Proof and verification status

The new theorems are ordinary proofs using the primary Brändén–Huh Lorentzian theory, an explicit coordinate-truncation argument, matroid clone limits, and exact endpoint-support bijections. Finite exact checks corroborate the formulas; they are not proof premises. The lower-degree input remains the previously approved rank-four result and is explicitly bundled and replayed.

The derivation notes preserve their historical “proposed” status lines to keep approved source hashes unchanged. Those status lines are superseded by the included later approvals. Absolute paths in those historical receipts identify the reviewed originals; the driver matches their exact bytes to the packaged copies.

No theorem is inferred from random search. No proof-assistant verification, literature-wide priority claim, or external publication is asserted. Earlier delivered releases are unchanged.
