# Weighted rank normalization through matching rank four

## Theorem

Let G=(L,R,E) be a finite bipartite graph of matching number at most four. Assign arbitrary nonnegative activities u_l to its left vertices and v_r to its right vertices. Let

p_G(t)=sum_k a_k t^k,

a_k=sum_{|I|=|J|=k, G[I,J] has a perfect matching} (product_{l in I}u_l)(product_{r in J}v_r).

Every vertex-support pair (I,J) is counted once, regardless of its number of perfect matchings. Let d=deg p_G. Then the sequence a_k/binom(d,k), 0≤k≤d, is log-concave, with no internal zeros. Equivalently, for 1≤k<d,

k(d−k)a_k² ≥ (k+1)(d−k+1)a_{k−1}a_{k+1}.

A stronger intermediate assertion holds: every graph admitting a cover split2+2 has a real-rooted support polynomial under these activities. Real-rootedness is NOT asserted for all graphs of matching number four.

## Imported theorem and source scope

The one imported enumerative theorem is the two-shore weighted ambient Lorentzian theorem: for an arbitrary bipartite graph, the same support sequence is ULC with parameter min(|L|,|R|), after zero padding. This is Theorem lor:thm:weightedULC in the pinned ProveIt source, proved there by a nonnegative specialization of a transversal-matroid basis polynomial. Its unweighted bimatroid form is consistent with Röhrle–Ulirsch, Logarithmic Concavity of Bimatroids (Theorem A). It does not by itself permit replacing shore size by matching rank.

The source checked here is article blob2b952dfcf443cdb014878c4bc0cd6adc1f8ef7e5 at repository pin d5e863bba6b40738af292b45005a0cf0495903e4. This note resolves its weighted-rank-three question mr:q:weighted, its unit-weight rank-four question mr:q:rankfour, and the rank-three and rank-four cases of hb:q:rank. It does not settle rank five or a general all-rank unit-weight conjecture.

## Proof of the combined theorem

Delete every vertex of activity zero and all isolated vertices. This preserves p_G, and the remaining positive-weight graph has matching number exactly d: a maximum matching supplies a positive support monomial, and no larger support is feasible. Also d≤4. If d≤1 there is no interior inequality.

By König's theorem choose a minimum vertex cover of size d and interchange shores if necessary. If its split is0+d, the smaller active shore has exactly d vertices, so the imported weighted ambient theorem gives the desired normalization.

If the split is1+(d−1), every nonisolated exterior vertex on the opposite shore has the sole neighborhood consisting of the singleton cover vertex. A matchable support uses at most one such vertex. Replace all of them by one pendant vertex whose activity is their sum; this preserves every coefficient and the matching number. The compressed shore has exactly d vertices, so the same ambient theorem applies. A complete weight-preserving argument appears in Part I below.

The only remaining cover split for d≤4 is2+2. Up to relabeling the two vertices in each cover part and exchanging shores, its induced core has six possibilities: no edges, one edge, two adjacent edges, two disjoint edges, three edges, or all four edges. In the no-edge case, the polynomial is a product of two degree-at-most-two real-rooted polynomials; their real-rootedness follows either from the two-vertex ambient theorem and the quadratic discriminant, or directly from the side formulas below. The one-edge and adjacent-two-edge cases have exact ordinary weighted-path realizations (Part II). The disjoint-two-edge and three-edge cases have exact Hermitian Gram determinant realizations (Part III). The full core has the PSD block determinant realization proved in Part IV. Each resulting polynomial has only negative real roots, so Newton's inequalities establish ULC at its actual degree d.

The zero-activity issue is resolved by the initial deletion, not by silently normalizing at the original graph's rank. For the mixed-cover real-rootedness assertions alone, coefficientwise limits of positive activities also suffice.

## Boundary: ULC does not mean real-rootedness for every rank-four graph

The source's theta(3,3,3) unit-weight example has support polynomial

1+9t+24t²+16t³+t⁴

and discriminant −5243; its two shores each have size four and its matching rank is four. It is not real-rooted. This is consistent with the theorem: the general conclusion is rank-ULC, whereas the additional real-rootedness statement is restricted to graphs admitting a split2+2 cover. The proof therefore makes no generic transfer from ordinary matching polynomials to support polynomials.


# Part I. Pendant compression

# Pendant compression and thin-cover rank normalization

Source checked: matching-normalization-article.tex at article blob 2b952dfcf443cdb014878c4bc0cd6adc1f8ef7e5 (repository source pin d5e863bba6b40738af292b45005a0cf0495903e4). Imported result: Theorem lor:thm:weightedULC, lines 8377 ff., two-shore weighted ambient ultra-log-concavity.

## Lemma: weighted pendant-twin compression

Let G=(L,R,E), with nonnegative vertex activities u_l and v_r. Suppose a nonempty set P⊆R consists of vertices with identical neighborhood {a}, for a∈L. Form G' by replacing P with one vertex p of neighborhood {a}. Give p activity W=Σ_{r∈P}v_r, and retain every other activity.

Then the weighted support polynomials are identical:
A_G(t;u,v)=A_G'(t;u,v').

Proof. A matchable support (U,S) contains at most one member of P because every selected member must be matched to a different neighbor, whereas their only neighbor is a. Supports using no P member correspond identically in G'. For each fixed U and S_0⊆R\P, either all pairs (U,S_0∪{r}), r∈P, are matchable or none are; they are matchable precisely when (U,S_0∪{p}) is matchable in G'. Their aggregate activity is u_U v_{S_0}Σ_{r∈P}v_r, exactly the compressed support activity. This is a bijection of support classes with total-weight preservation, not an enumeration of perfect matchings. Summing proves the identity. Matching number is also unchanged, since a matching uses at most one member of P and can replace its endpoint by p, and conversely.

## Theorem: minimum covers with at most one vertex on a shore

Suppose ν(G)=r and G has a minimum vertex cover C=C_L⊔C_R with |C_L|≤1 or |C_R|≤1. Then for arbitrary positive activities on BOTH shores the coefficient sequence a_k / binom(r,k) is log-concave. The nonnegative-activity version with normalization r follows by continuity.

Proof. Transpose so |C_L|≤1, and discard isolated vertices, which never occur in a positive-degree matchable support. If |C_L|=0, all nonisolated right vertices lie in C_R, whose size is r. Since a size-r matching exists, the smaller active shore has size exactly r. Apply the weighted ambient theorem.

If C_L={a}, then |C_R|=r−1, and every right vertex outside C_R is either isolated or has neighborhood {a}, since C is a cover. There must be a nonisolated right vertex outside C_R, or the right shore would have size at most r−1 and ν(G)<r. Compress all these pendant twins by the lemma. The resulting right shore has exactly r vertices; matching number remains r, so the smaller shore is r. Its weighted support coefficients equal the original coefficients. Apply the two-shore weighted ambient theorem at r.


# Part II. One-edge and adjacent-edge cores

# A real-rooted matching-support family: split2+2 with one core edge

## Statement

Let G have a minimum vertex cover of size four, split2+2 between its shores, with exactly one edge joining the two cover parts. For arbitrary positive vertex activities on both shores, its matching-support polynomial has only real negative roots. Therefore it is ultra-log-concave normalized by its actual matching rank four. Nonnegative activities follow by limits, and the real-rooted statement directly gives normalization by the surviving degree.

This settles four of the sixteen split2+2 core masks: 1,2,4,8. Core mask0 is a disjoint union of two rank≤2 components and is also real-rooted.

## Rooted rank-two component

Consider a bipartite component H with shore {a,b}, with a distinguished as root, and any other shore. Isolated vertices may be discarded. Let a,b have activities u,v. Let X,Y,Z be the sums of activities of other-shore vertices adjacent only to a, only to b, or to both, respectively. Let E be the sum of products of activities over unordered distinct pairs of the common-neighbor vertices (their second elementary symmetric function).

Define P=u(X+Z), Q=v(Y+Z), B=uv(XY+XZ+YZ+E). Then the SUPPORT polynomial and root-deletion support polynomial are

p_H(t)=1+(P+Q)t+B t²,
p_{H−a}(t)=1+Qt.

These formulas count each support once. In particular, two common neighbors contribute E, not 2E. Since Z²−E≥0, we have 0≤B≤PQ.

When P>0, form an ordinary weighted matching model on a four-vertex path rooted at its first endpoint, with the successive edge weights

P, Q−B/P, B/P.

They are nonnegative. Its matching generating polynomial is 1+(P+Q)t+B t² because the only pair of nonadjacent edges is the first and third. Deleting the root leaves a two-edge path with total edge weight Q and matching polynomial 1+Qt. Thus this path reproduces both p_H and p_{H−a} exactly. If P=0, then B=0 and an isolated root plus one edge of weight Q gives the same pair, or the conclusion follows by continuity.

## Bridge decomposition

Deleting the sole core edge e=ab from G leaves two pieces H_1,H_2: the two left cover vertices with exterior right vertices, and the two right cover vertices with exterior left vertices. Let a and b be the distinguished roots, respectively, and let c be the product of their original vertex activities. Write p_i for each support polynomial and q_i for its root-deletion support polynomial. Then

p_G(t)=p_1(t)p_2(t)+ct q_1(t)q_2(t).

Reason: a support admitting a matching without e is balanced separately in the two components and contributes to the first term. A support requiring e has an imbalance of one in each component, with opposite signs; after removing a and b it is a pair of balanced matchable root-deleted supports, and contributes exactly once to the second term. These classes cannot overlap, because crossing e changes the shore imbalance in each component. The bridge is the only intercomponent edge, so this exhausts all supports.

Replace H_1,H_2 by the rooted four-vertex path models above and join their roots by an edge of weight c. The ordinary weighted matching polynomial of this eight-vertex path obeys precisely the same bridge identity and hence equals p_G(t).

## Self-contained real-rootedness certificate

For a path with nonnegative edge weights h_1,...,h_{N−1}, let M be the real symmetric tridiagonal matrix whose diagonal entries are zero and whose adjacent off-diagonal entries are sqrt(h_i). The determinant recurrence gives

det(xI−M)=sum_k (−1)^k m_k x^{N−2k},

where m_k are its weighted matching coefficients. All roots of the characteristic polynomial are real because M is symmetric. Consequently every root of sum_k m_k t^k is real and negative: a nonzero root t would give x²=−1/t and a corresponding nonzero characteristic root x. Constant term1 excludes t=0. This establishes the asserted real-rootedness without transferring a theorem for individual matchings to arbitrary supports; the equality of the two polynomials was proved specifically for this family.

Newton's inequalities now give a_k/binom(d,k) log-concave, where d is the actual degree. For positive original activities and matching number four, d=4.

## Extension: two adjacent core edges (weighted)

The same conclusion holds when the core has two edges sharing a vertex. Up to transposing the shores, let their common endpoint a belong to H_1, and let both centers of H_2 be its neighbors. Let a have activity c_a. Use u,v,X,Y,Z,E for H_2 as above, and put N=X+Y+Z.

A support using a core edge has shore imbalance one between the pieces, so is disjoint from the product term. It includes a, and after deleting a its H_1 part is a balanced matchable support counted by q_1. Its H_2 part either selects one center and no exterior vertices (aggregate weight u+v), or both centers and one nonisolated exterior vertex (aggregate weight uvN). The latter is matchable exactly once as a support, regardless of whether that exterior vertex is adjacent to one or both centers. Thus

p_G=p_1p_2+c_a t q_1[(u+v)+uvN t]
    =p_1p_2+c_a(u+v)t q_1q_2^*,

where q_2^*=1+Qt and Q=uvN/(u+v).

Write p_2=1+At+Bt² as above and let θ=u/(u+v). Direct algebra gives

Q(A−Q)−B
=uv([θX−(1−θ)Y+(θ−1/2)Z]²+3Z²/4−E)≥0.

Indeed E=(Z²−sum_i z_i²)/2≤Z²/2 for the common-neighbor activity list (z_i). Also Q≤A, directly from A≥min(u,v)N and uv/(u+v)≤min(u,v). Consequently p_2 and q_2^* admit the rooted three-edge path realization, with P=A−Q, middle weight Q−B/P and last weight B/P (degenerate P=0 cases follow by limits). Piece H_1 has its previous rooted realization. Connecting the roots with bridge weight c_a(u+v) yields an eight-vertex weighted path whose ordinary matching polynomial is exactly p_G. The preceding determinant proof establishes real-rootedness.

The next two parts handle the other three core orbits: two disjoint edges, three edges, and the full core.

The unit-weight star identity obtained independently by the template worker is the specialization u=v=1 and E=binom(Z,2): the interlacing margin is ((X−Y)²+Z²+2Z)/4. This provides a useful cross-check of the weighted identity.

# Part III. Disjoint-edge and three-edge cores

## Data and compression gadget

Write the left cover as a1,a2, of activities α1,α2, and right cover as b1,b2, of activities β1,β2. Exterior left vertices have types {b1},{b2},{b1,b2}. Denote their activity sums by L1,L2,Z; write E for the elementary symmetric sum of degree two of the common type's activities. Thus 0≤E≤Z²/2. Exterior right types similarly have sums R1,R2,W and common-type e2 equal F.

Define c=√(Z²−E), d=√(W²−F). Then Z/√2≤c≤Z and W/√2≤d≤W. For unit activities, c=√(z(z+1)/2), d=√(w(w+1)/2).

Replace all exterior left vertices by one common leaf adjacent to both b-centers and two private leaves. In ordinary edge-weighted matching enumeration, give the common-leaf edges weights β1 c, β2 c, and the private edges weights β1(L1+Z−c), β2(L2+Z−c). All weights are nonnegative. The resulting component has the same support polynomial as the original two-center component:

 q_L(t)=1+[β1(L1+Z)+β2(L2+Z)]t
          +β1β2[L1L2+Z(L1+L2)+E]t².

Indeed its size-two matching coefficient is β1β2[(L1+Z)(L2+Z)−c²]. It also preserves the component polynomials after deleting either or both b-centers. Apply the analogous replacement on the right, using d and activities α1,α2. Restore each desired core edge a_i b_j with ordinary matching weight α_iβ_j. Let M(t) be the ordinary weighted matching polynomial of this surrogate graph.

All square roots below are amplitudes: if an ordinary matching edge has weight w≥0, the corresponding matrix entry has modulus √w. Phases do not change M.

## Determinant cycle identity

For a complex weighted bipartite biadjacency matrix B, det(I+tBB*) is the sum of squared absolute minors by Cauchy–Binet. Its diagonal terms are the ordinary matching polynomial M. If the graph has no two vertex-disjoint cycles, every off-diagonal pair of matchings differs on exactly one even cycle C of length 2h. That cycle contributes

  2(−1)^(h−1) Re(product of oriented amplitudes around C)
       · t^h · M_{graph−V(C)}(t).

This follows by pairing the two alternating matching choices on C; their determinant signs differ by an h-cycle, hence (−1)^(h−1). The matching outside C is identical in both terms. In the graphs used here, all cycles meet the four-center cover, and the relevant deleted complements are forests.

Consequently a C4 gives a negative interference term, while a C6 gives a positive one. The determinant has only negative real zeros, since BB* is positive semidefinite; zero eigenvalues contribute factors 1.

## Two disjoint core edges

Choose core a1b2,a2b1. The surrogate graph has exactly one cycle, a C6 through all four centers and the two common leaves. Removing it leaves isolated private leaves. Counting support multiplicities shows

  M(t)−p_G(t)=T ZW t³,  where T=α1α2β1β2.

The only duplicated support uses all four centers, one common exterior vertex on each shore, and one core edge; its two perfect matchings are counted once in p_G and twice in M. The component compression already handles all multiplicities within each separated two-center component.

The cycle amplitude has modulus Tcd. Choose its phase φ with

  cosφ=−ZW/(2cd),

which is possible because 2cd≥ZW. The C6 interference is then exactly −TZW t³, so det(I+tBB*)=p_G(t). This proves real-rootedness.

## Three core edges

Choose core a1b1,a1b2,a2b1, with a2b2 absent. The surrogate has three simple cycles: two C4s, one through a1 and both b-centers and the left common leaf, and one through b1 and both a-centers and the right common leaf; and one C6 through all four centers and both common leaves. These cycles intersect, so the cycle identity has no disjoint-cycle product terms.

Choose phases so that the two C4 cosines are cosθ and cosη. The C6 phase is θ−η (reversing one phase gives the alternative sign). Put

  x=2c cosθ, y=2d cosη,
  U=α1β1β2, V=α1α2β1, T=α1α2β1β2,
  b=R2+W, a=L2+Z.

The two C4 interference terms are

  −U x t²(1+α2 b t) and −V y t²(1+β2 a t),

and the C6 term is +2Tcd cos(θ−η)t³.

Direct support counting, or expansion of the supplied exact kernel, gives

  M(t)−p_G(t)=(U Z+V W)t²+T[Z b+W a]t³.

To match t² and t³, it therefore suffices to solve

  Ux+Vy=UZ+VW,
  2cd cos(θ−η)=(x−Z)b+(y−W)a,

with x=2c cosθ,y=2d cosη. All other coefficients already agree.

### Phase-existence lemma

Let A=2c,B=2d and let ℓ be the affine line Ux+Vy=UZ+VW. Its intersection with the rectangle [−A,A]×[−B,B] is a closed segment containing (Z,W) in its relative interior when all relevant activities are positive and the common types are nonempty. At each endpoint at least one rectangle coordinate saturates.

For a point (x,y) on this segment, the two possible values of 2cd cos(θ−η) are

  H_±(x,y)=[xy ± √((A²−x²)(B²−y²))]/2.

They are continuous and coincide at each segment endpoint. Define the affine target h(x,y)=(x−Z)b+(y−W)a; it vanishes at (Z,W).

At (Z,W), the two branches surround zero because

  (A²−Z²)(B²−W²) ≥ Z²W²,

equivalently A²B²−A²W²−B²Z²≥0. This follows from c²≥Z²/2,d²≥W²/2: writing c²=Z²/2+s and d²=W²/2+t gives the last difference 4sW²+4tZ²+16st≥0.

Move along the segment from (Z,W) to either endpoint. Initially H_−−h≤0≤H_+−h; at the endpoint the two differences are equal. If that common value is positive, H_−−h has a zero; if negative, H_+−h has a zero; if zero, the endpoint itself is a solution. This is the intermediate value theorem. Choose phases realizing that branch. Both determinant coefficients then agree with p_G, proving the theorem.

The formulas are continuous in activities. Zero activities or absent common types follow by adding auxiliary vertices of arbitrarily small positive activity if needed and taking limits; nonnegative real-rooted polynomials with constant term 1 form a closed set under coefficient convergence.


# Part IV. Full-core PSD block construction

## Side data and scalar boundary

For centers of positive activities u,v, let X,Y,Z denote exterior activity sums by singleton/singleton/common neighborhood and E=e2(common). Put U=u+v, a=uv,
A=u(X+Z)+v(Y+Z), B=a(XY+XZ+YZ+E), α=a(X+Y+Z)/U.
A concrete positive-semidefinite matrix with trace A and determinant B is
G=[[u(X+Z),sqrt(a(Z²−E))],[sqrt(a(Z²−E)),v(Y+Z)]].
Its diagonal entries and determinant are nonnegative. Let H=adj(G), which has the same trace and determinant.

Write θ=u/U, z=θ−1/2, h=a/U², L=Z²−E, T=θX−(1−θ)Y+zZ. Then
D=α(A−α)−B=a(T²+L−Z²/4),
Δ=A²−4B=U²[(T+zZ)²+4hL],
2D−hΔ=a[(T−zZ)²+(1+4z²)(L−Z²/2)]≥0.
Equivalently, the variance bound has the compact exact certificate

2U²[α(A−α)−B]−a(A²−4B)
=a[(uX−vY)²+(u²+v²)(Z²−2E)]≥0.

The last inequality uses E≤Z²/2. Consequently α lies between the eigenvalues of H, and, if Δ>0, probabilities (p,1−p) can realize expectation α with p(1−p)=D/Δ≥h/2.
If Δ=0, G is scalar. Its off-diagonal entry vanishes, forcing Z=0, and its diagonal equality says uX=vY. Thus α=A/2 is the repeated eigenvalue, and p=1/2 works freely.

Repeat on the other side, obtaining G',H', trace A', determinant B', mean β, total center activity V, product b, and probabilities (q,1−q) with q(1−q)≥b/(2V²).

## Full-core support identity

Let p_A=1+At+Bt² and p_B=1+A't+B't² be the support polynomials after deleting all core edges. By shore imbalance between those two pieces,
p_G=p_A p_B+c t(1+αt)(1+βt)+d t²,
where c=UV and d=ab.
The product is imbalance zero. Imbalance one uses exactly one core edge; its aggregate factor on one side is U+a(X+Y+Z)t=U(1+αt), since selecting both centers and one exterior vertex is counted once regardless of its possible matches. Imbalance two consists solely of the four core vertices, and contributes d t² once, not twice.

## Choice of coupling matrix

Work in eigenbases of H,H'. Choose a complex 2×2 matrix C with squared magnitudes
|C_ij|²=c p_i q_j, with (p_1,p_2)=(p,1−p), (q_1,q_2)=(q,1−q).
Then
tr(CC*)=c,
tr(H CC*)=cα,
tr(C H' C*)=cβ,
tr(H C H' C*)=cαβ.
Start all entries with nonnegative real phase, and vary the phase of C_22. Its squared determinant takes every value in
[0,4c²p(1−p)q(1−q)].
The upper endpoint is at least ab=d, by the two variance bounds. Thus choose phase making |det C|²=d.

## Exact block determinant

Set M=[[C,G^(1/2)],[G'^(1/2),0]], a complex 4×4 matrix. The Schur complement, first for positive real t and hence as a polynomial identity, gives

det(I+tMM*)
=det(I+tG)det(I+tG')
 +t tr(adj(I+tG) C adj(I+tG') C*)
 +t²|det C|².

For a 2×2 matrix, adj(I+tG)=I+t adj(G). Substitution of the four trace identities therefore gives

det(I+tMM*)=p_Ap_B+ct+c(α+β)t²+cαβt³+dt²=p_G.

Since MM* is positive semidefinite, this is a product of factors 1+λ_i t with λ_i≥0. Its nonconstant roots are negative real numbers, and Newton's inequalities give ultra-log-concavity at its actual degree. Positive original activities and matching rank four give degree four. Zero-activity statements follow either by continuity or directly from the real-rooted polynomial limit.


## Verification record

The full-core variance identities were independently checked symbolically, and the block determinant was derived independently by a Schur complement. The implementation audit_full_core_psd.py compared 5,000 weighted full-core kernels to the constructed determinant; all passed. The earlier path cases were independently audited, including2,048 exact weighted examples. The disjoint/three-edge determinant cases were independently audited, including512 exact weighted examples. These computations are cross-checks; the theorem follows from the identities and existence proofs above.

A bounded search of two million rational weighted populations per core mask6,7,15 found no negative Newton gap. That search is not used as proof. Its kernel was separately verified against labeled-support enumeration on60 rational weighted graphs.
