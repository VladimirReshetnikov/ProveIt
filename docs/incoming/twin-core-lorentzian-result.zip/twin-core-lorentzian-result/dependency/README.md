# Frozen lower degree dependency

The archive is the unchanged earlier `matching-rank-four-package.zip`.

SHA-256: 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66

Theorem 1.1 proves actual-degree ULC for arbitrary nonnegative vertex activities on every bipartite graph of matching number at most four. The new theorem applies it to the graph induced by positive-activity vertices whenever the surviving degree drops below five.

The outer driver checks this archive, its own manifest and readable PDF identity, then replays all its delivered checkers and regenerates the earlier rank-five certificate in temporary storage. No dependency file is modified.
