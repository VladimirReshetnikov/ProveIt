# Independent audit: twin core rows with arbitrary exterior neighborhoods

Verdict: approved, October 1, 2026. The proof is ordinary and all-size. Finite enumeration is supplementary.

Reviewed notes:
- TWIN_NEIGHBORHOOD_EXTENSION.md, SHA-256 9ed4e18d192eee9f27132bce2aba96d7d38f4db329dcaa773935013fd78a0cac
- TWIN_CORE_ARBITRARY_EXTERIORS.md, SHA-256 c4b320c1d8bc3587bc8e709e84383904d3197d46f4a885e5888edb70795c5b7d

The original connector review in AUDIT.md supplies the primary-source checks, upper-coordinate truncation proof and exact finite-capacity symbol theorem.

## Clone seed

The private dummies ensure rank q even for empty J and isolated X. For each m≥q, adjoining m identical-neighborhood but distinct clone elements yields a transversal matroid. A basis with i clones is determined by an i-element clone subset and an old (q-i)-subset whose union is matchable. This condition depends only on i, not clone labels or m. Thus its basis polynomial is exactly Σ e_i(h)U_i. The specialization h=y/m and coefficientwise limit give Σ y^i U_i/i!, including all zero U_i. The same upper truncation and connector apply. No assumption that arbitrary transversal matroids are stable is made.

## Arbitrary exterior-head neighborhoods

The generalized quartic replaces AR by C and S by M. Independently differentiating reproduces the three pure determinants 4(4BM-C²),16(2B-A²),16B²(2M-R²), and the three mixed determinants 64(AC-BR),64B²M(CR-AM),128B²(2AR-C).

All six scalar identities in the source were independently expanded. Their signs follow from nonnegative activities and H²−2S=Σv_y². With both P activities positive and two positive common heads, all coefficients and mixed determinants are positive, and each mixed matrix has a negative principal 2×2 minor. The Hessian argument is therefore valid. Adding two auxiliary common heads of epsilon activity and approximating zero P activities is a valid coefficientwise approximation to every boundary graph. No extra positive-weight endpoint survives that limit.

## Endpoint and weight correspondence

The six (p,r) support categories are exhaustive. In the (2,1) case the selected Y head may match either covered tail, but the remaining tail always has the same Q-neighborhood J. The clone condition therefore depends only on the endpoint set; BR is the correct coefficient, without a witness factor. In the (1,1) case C retains the selected P endpoint distinction. The (2,2) pair polynomial M counts common-common pairs once. These facts establish the weighted support bijection independently of any matching choice.

Positive Q activities permit the stated dummy substitution; zero Q activities are handled after cancellation in the explicit endpoint polynomial. All-unused support coefficient one excludes the zero polynomial. Homogeneity is q+2. The proof gives this normalization for arbitrary q and actual-degree normalization for q=3 using the approved active-bipartite rank-four fallback. It does not cover unequal core rows, physical role overlap, real stability or general actual-degree normalization.

## Supplementary independent replay

check_twins.py imports no producer code. Its physical endpoint checker uses recursive matching existence, while its clone-basis checker tests every Hall subset. Individual unused-Q monomer variables are retained, so it verifies a multivariate identity, not only the diagonal support counts.

All 21,544 weighted identities passed on 5,386 side graphs, including 10,772 zero-weight cases. The exhaustive portion covers all two-X masks, all J subsets and every ordered pair of nonempty Y-neighborhood types for q=2,3. Further seeded graphs have q up to five. The replay tested 836,088 proposed endpoint pairs and 140,830 clone-basis subsets, along with all six Hessians, all six scalar identities, factorial action and limit identities. Python optimization mode is rejected. These finite checks corroborate the ordinary proof and impose no size bound on the theorem.
