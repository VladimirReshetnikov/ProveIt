# Independent audit: the two-universal-tail Lorentzian connector

Verdict: approved, October 1, 2026. This is an ordinary all-size proof; the finite checks below are supplementary, not mathematical premises.

Reviewed source: `TWO_UNIVERSAL_TAIL_CONNECTOR.md`, SHA-256 `4478b6fdde999433806d8a0135d386eaba309b596fd07d12446e6672010109d4`.

## Ordinary proof review

1. The factorial matroid independence seed is the limit of basis polynomials of rank-q truncations of the direct sum with a free matroid. For each fixed j, binom(m,j)/m^j tends to 1/j!. The finite q bound is essential and is explicitly present.
2. Coordinate upper truncation preserves M-convex support. In every quadratic derivative, its effect is respectively no change, subtraction of a nonnegative diagonal Hessian entry, restriction to a principal submatrix, or zero. These preserve the bound of one positive eigenvalue. The lemma is valid without an unjustified division by a homogenizing monomial.
3. The finite-capacity operator symbol uses capacity two for y and capacity one for each old matroid variable. It is exactly K times the spectator factors (w_e+u_e). In particular T(y²)=2Q2 and the seed coefficient y²/2 cancels that factor. The degree shift is two; the output has degree q+2.
4. All six second-derivative Hessians and their determinants were reconstructed independently. Under A²≥2B and R²≥2S, the pure determinants are nonpositive. In the positive case each mixed Hessian has a negative principal minor and positive determinant, hence one positive eigenvalue. The proposed epsilon approximation preserves the parameter inequalities and proves all boundary cases by closedness.
5. The private-dummy construction gives an exact bijection of endpoint data. Its Boolean condition is independence of selected X elements plus unused-Q dummies. Selected P and Y subsets are recorded separately. The p=2,r=1 term has coefficient B, not 2B. Nothing counts matching witnesses.
6. The substitution and positive scalar factor cancel reciprocal Q activities. Zero activities follow by the explicit endpoint-polynomial limit. The empty-support coefficient remains one.
7. Diagonalization yields order-(q+2) ULC. Actual-degree normalization for arbitrary q is not inferred. For q=3 the cited independently approved arbitrary-weight bipartite matching-rank-at-most-four theorem applies to the positive-activity induced graph after degree drop. Its matching rank is exactly the surviving support degree. This fallback is valid.

## Primary source check

Brändén and Huh, *Lorentzian polynomials*, arXiv:1902.03719v8, https://arxiv.org/pdf/1902.03719, was checked directly: Theorem 2.25 (quadratic characterization and closedness), Theorem 2.10 (nonnegative substitutions), Corollary 2.32 (products), Theorem 3.10 (matroid bases), Theorem 3.2 (the exact binomial finite-capacity symbol), and Example 2.26 (bivariate normalization). The proof does not misapply the multiaffine-only Corollary 3.5 as arbitrary-degree truncation.

## Independent supplementary replay

`check.py` imports no producer code. It reconstructs all six Hessians and the support exchanges, the factorial action and nine limit checks. Literal endpoint matching is compared with a separate Hall-subset matroid test, retaining all individual unused-Q monomer variables.

The exact replay passed 2,538 weighted multivariate identities on 846 side graphs, including 846 zero-weight cases, 225,097 proposed endpoint pairs and 39,917 matroid subset tests. It checks order-(q+2) ULC throughout and actual-degree ULC only for q=3. The instances include exhaustive small q=2,3 neighborhood arrays and selected q=4,5 cases. This finite scope is not promoted into a proof of the infinite theorem.

The checker rejects Python optimization mode, and its source/output paths are portable command-line arguments.
