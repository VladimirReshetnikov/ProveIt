# Independent integrated article and package review

Approved October 1, 2026. The five-page article faithfully states and proves the two reviewed ordinary theorems: twin internal core rows with arbitrary exterior neighborhoods, and arbitrary core rows with private exterior heads.

I re-read the complete TeX and all four source notes, checking both stated homogenizations, the factorial clone limit, coordinate upper truncation, every quartic coefficient, all six Hessian determinants and scalar identities, the six endpoint categories, the private-head quadratic symbol and forced-edge bijection, and the nonnegative-activity boundary arguments. Their transcription agrees with the independently approved mathematics. The actual-degree corollary uses the bundled rank-four theorem only for the (2,3) cover case. General cover-order conclusions are not silently upgraded to arbitrary surviving rank. Unequal rows with shared heads and directed physical overlap remain explicitly outside the claims.

The primary Lorentzian references and finite-capacity normalization match the checked Brändén–Huh statements. The article distinguishes an ordinary proof from supplementary finite checks and makes no priority or proof-assistant claim. The independent checker totals are accurate.

I rendered and inspected every PDF page at 115 dpi. All five pages pass: no clipped text or formulas, overlapping elements, broken matrices, missing glyphs or layout defects. Headers, page numbers, the six-case table and references are legible and consistent.

The README accurately identifies the proof scope, rank-four dependency, historical source-status convention and Python/SymPy requirements. The build script is portable for a standard TeX installation. The read-only verification driver checks exact manifest coverage, all historical approval pins, nested rank-four checks and exact certificate regeneration, all six new checkers with deterministic receipt comparison, and release immutability. Optimized Python is rejected. Final fresh-archive replay and its checksum are recorded separately after freezing, outside the archive.
