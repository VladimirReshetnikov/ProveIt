# An unconditional Lorentzian theorem for private exterior heads

Status: proposed ordinary theorem, awaiting independent review. October 1, 2026.

## Statement and relation to the twin theorem

Let a physically bipartite graph have shores P union X and Q union Y, with |P|=r and |Q|=q. There are no X×Y edges. The internal P×Q graph and X×Q graph are arbitrary. Every nonisolated Y vertex has exactly one neighbor in P. Thus Y is partitioned into groups Y_p of heads private to p. Assign independent nonnegative vertex activities and count each feasible endpoint support once.

Then the polynomial

  F(t,z_P,z_Q)=sum_(S,T feasible) wt(S,T) t^|S|
                product_(p in P) z_p^(1-|T intersect Y_p|)
                product_(j in Q minus T) z_j

is Lorentzian, homogeneous of degree q+r. Each exponent 1-|T intersect Y_p| is nonnegative because at most one private head can be matched to p. Consequently the rank sequence is ULC with normalization order q+r; at full surviving degree q+r this is actual-degree ULC.

For (r,q)=(2,3), the previously approved arbitrary-weight bipartite rank-four theorem handles all degree drops and gives actual-degree ULC for every choice of nonnegative activities. Unlike the twin-core theorem, this result imposes no condition on the internal core rows. Unlike the previously proved stable-seed/private-head real-rootedness criterion, it needs no real-stability assumption on a matroid. Its conclusion is Lorentzianity at the stated cover order, not real stability.

## Matroid seed

Let M be the rank-q transversal matroid with slots Q and ground set P union X union {d_j:j in Q}. The original P and X tail elements have their graph neighborhoods in Q, and d_j has private neighborhood {j}. The dummy set is a basis, so M has rank q regardless of the other edges.

Its basis polynomial B_M(x_P,w_X,w_D) is Lorentzian by the primary Brändén–Huh matroid-basis theorem. All its variables are multi-affine. Let u_p be the activity of p, and let L_p=sum_(y in Y_p) v_y.

For each distinguished input variable x_p apply the local linear operator

  1 maps to z_p+u_p L_p t,
  x_p maps to u_p t z_p,

tensored with the identity in the other variables. The combined operator is homogeneous of degree increase r: every absent x_p gains degree one, and every present x_p changes from degree one to degree two.

## Exact finite-capacity symbol

At capacity one for every input variable, the combined symbol is

  product_(p in P) [z_p v_p+u_p L_p t v_p+u_p t z_p]
       times product_(e in X union D) (w_e+v_e).

Here all v symbols are independent dual variables; z_p and t are output variables. Each bracket is a nonnegative homogeneous quadratic. For u_p,L_p>0, its Hessian in (z_p,v_p,t) has zero diagonal and positive off-diagonal entries 1,u_p,u_p L_p. Its determinant is 2u_p²L_p>0, and a 2×2 principal determinant is negative. It therefore has exactly one positive and two negative eigenvalues, so it is Lorentzian. Zero parameters follow by coefficientwise limits; the term z_p v_p always remains. The spectator factors are nonnegative linear polynomials.

Products preserve Lorentzianity, so the full finite-capacity symbol is Lorentzian. The primary Brändén–Huh Theorem 3.2 then proves that the combined operator sends B_M to a Lorentzian polynomial, homogeneous of degree q+r.

All primary facts and their exact references are the same as in TWO_UNIVERSAL_TAIL_CONNECTOR.md. This proof uses neither a clone limit nor a factorial truncation.

## Endpoint-support bijection

Assume initially all Q activities v_j are positive; set w_x=u_x t and w_dj=z_j/v_j, and multiply by E=product_(j in Q) v_j.

In a basis term of B_M, a selected p is matched to Q. The operator contribution u_p t z_p records that selected tail and the fact that no Y_p head is selected. If p is absent from the basis, its contribution z_p+u_p L_p t records either that p and all its private heads are unused, or that p is selected together with exactly one of its private heads. The expansion of L_p sums the latter endpoint choices once each.

For every actual endpoint support, every selected private Y head forces its unique adjacent P tail to be matched to it. Delete those forced edges. The residual selected P and X tails, together with dummies for unused Q heads, form a matroid basis. Conversely a seed basis and each permitted local absent-p choice determine a feasible endpoint support. This is a bijection of endpoint data. If the residual Q matching has multiple witnesses, they remain ignored by the matroid basis coefficient one; no matching multiplicity is introduced.

Thus the specialized output is exactly F. Nonnegative linear substitution and positive scaling preserve Lorentzianity. Zero Q activities follow by a coefficientwise limit in the explicit endpoint polynomial. The all-unused support gives product_p z_p product_j z_j with coefficient one, excluding zero output. Every monomial has degree q+r by the matching balance. Setting all monomers equal to z yields sum_k gamma_k t^k z^(q+r-k), hence order-(q+r) ULC.

For r=2,q=3 and surviving degree below five, delete zero-activity vertices and use Theorem 1.1 of the frozen matching-rank-four-package.zip, SHA-256 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66. No general change from q+r to surviving-degree normalization is claimed for other parameters.
