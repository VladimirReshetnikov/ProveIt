# Twin core rows with arbitrary exterior neighborhoods

Status: proposed ordinary extension, awaiting independent review. October 1, 2026. The two earlier notes remain unchanged.

## Statement

Let a physically bipartite graph have shores P union X and Q union Y, with P={p0,p1}, |Q|=q>=2. There are no X×Y edges. The X×Q and P×Y edges are completely arbitrary. The internal core consists of P×J for an arbitrary J subset of Q: the two P vertices have identical Q-neighborhoods. Isolated Y vertices may be discarded.

Assign independent nonnegative activities to all vertices and count each matchable endpoint pair once. Then

  F(t,z,z_Q)=sum_(S,T feasible) wt(S,T) t^|S|
                    z^(2-|T intersect Y|) product_(j in Q minus T) z_j

is Lorentzian and homogeneous of degree q+2. Therefore the rank sequence is order-(q+2) ULC. For q=3, the already approved bipartite rank-four theorem handles degree drops, giving actual-degree ULC for all activities. This includes arbitrary missing exterior edges on both sides; only the twin-row internal-core condition remains.

The proof combines the clone seed in TWIN_NEIGHBORHOOD_EXTENSION.md with a slightly more general quartic symbol. All uses of primary Lorentzian theory, the coordinate truncation proof, factorial normalization, and degree-drop qualifications are exactly as in TWO_UNIVERSAL_TAIL_CONNECTOR.md.

## Exterior-head parameters

Partition the nonisolated Y vertices according to their P-neighborhood: Y0 has {p0}, Y1 has {p1}, and Y* has both. Let

  L0=sum_(y in Y0) v_y, L1=sum_(y in Y1) v_y,
  H=sum_(y in Y*) v_y, S=e2(v_(Y*)).

Set a=u_p0, b=u_p1 and

  A=a+b, B=ab,
  R=L0+L1+H,
  M=L0L1+H(L0+L1)+S,
  C=a(L0+H)+b(L1+H).

Here C counts weighted size-one supports between P and Y, R counts individual nonisolated Y endpoints, and M counts weighted Y endpoint pairs matchable to both P vertices. A pair of common-neighbor Y vertices contributes once to S, although it has two matching witnesses.

## Generalized quartic symbol

Use

  Q0=z²+Czt+BMt²,
  Q1=t(Az²+BRzt),
  Q2=Bz²t²,

and the same capacity-two operator T(f)=Q0 f(0)+Q1 f_y(0)+Q2 f_yy(0). Its y-symbol is

  K=v²z²+Cv²zt+BMv²t²+2Avz²t+2BRvzt²+2Bz²t².             (1)

The pure second derivatives have nontrivial Hessian determinants

  4(4BM-C²), 16(2B-A²), 16B²(2M-R²),

and the mixed second derivatives have Hessian determinants

  64(AC-BR), 64B²M(CR-AM), 128B²(2AR-C).                  (2)

All required signs follow from the following explicit identities:

  A²-2B = a²+b²,
  R²-2M = L0²+L1²+H²-2S,
  C²-4BM = [a(L0+H)-b(L1+H)]²+4B(H²-S),
  AC-BR = a²(L0+H)+b²(L1+H)+BH,
  CR-AM = a(L0²+L0H+H²-S)+b(L1²+L1H+H²-S),
  2AR-C = a(L0+2L1+H)+b(2L0+L1+H).                       (3)

The common-population moment satisfies H²-2S=sum_(y in Y*) v_y²>=0. Thus the pure determinants are nonpositive and the mixed determinants are nonnegative.

For a,b>0 and at least two positive common-neighbor Y activities, all six coefficients in (1) are positive, so its support is the same M-convex bounded degree-four simplex as in the original connector. Each mixed Hessian has a negative 2×2 principal minor (the zero diagonal entries and positive off-diagonal entries are unchanged), and its determinant is positive by (3). It therefore has exactly one positive eigenvalue. The pure Hessians have at most one positive eigenvalue. Hence K is Lorentzian.

Every boundary case is a coefficientwise limit of this case: increase zero P activities slightly and, if necessary, add two new common-neighbor Y vertices of activity epsilon. Their contribution disappears as epsilon tends to zero, so the limiting polynomial is exactly that of the original graph. This argument is allowed to use larger auxiliary finite graphs; no new positive-weight endpoint survives the limit. The primary closedness theorem proves Lorentzianity for all nonnegative activities and all original Y-neighborhood populations. Multiplying the symbol by the spectator factors and applying the bounded-degree operator theorem gives the same preservation statement as before.

## Clone seed and exact support formula

Use the rank-q transversal matroid on X, the q private head dummies, and m distinct clones with common neighborhood J. Write U_i(w) for the polynomial of old (q-i)-subsets that become a basis upon adjoining i clones. The already proved clone limit and truncation give the Lorentzian seed

  U_0+y U_1+(y²/2)U_2.

Applying T produces

  Q0 U_0+Q1 U_1+Q2 U_2.                                  (4)

To verify it counts endpoint supports, condition on p selected P vertices and r selected Y vertices:

  (p,r)=(0,0): z² U_0;
  (p,r)=(1,0): A t z² U_1;
  (p,r)=(2,0): B t² z² U_2;
  (p,r)=(1,1): C t z U_0;
  (p,r)=(2,1): BR t² z U_1;
  (p,r)=(2,2): BM t² U_0.

The nontrivial (2,1) case uses the twin condition: whichever selected P tail matches the selected Y vertex, the remaining tail has the same Q-neighborhood J. Hence feasibility of the residual Q matching is exactly U_1, with no dependence on which allowed Y matching witness is chosen. For (2,2), M already counts Y endpoint pairs once. The (1,1) weight C retains the distinction between which P endpoint was selected, as required.

In every case the old matroid subset consists of the selected X tails and the private dummies of unused Q heads. Adjoining p-r clones is equivalent to completing its matching, exactly as proved in the twin-neighborhood note. Thus the six terms enumerate endpoint supports without witness multiplicity.

Substitute w_x=u_x t and w_dj=z_j/v_j, and multiply by product_j v_j, initially for positive Q activities. Nonnegative specialization preserves Lorentzianity and gives exactly F. Zero Q activities follow from the explicit endpoint-polynomial limit. The empty-support monomial has coefficient one. Setting all z_j=z gives the degree-(q+2) homogenization of Gamma; the q=3 actual-degree fallback is unchanged.

## Scope

This is an ordinary proof, with no finite enumeration as a premise. It does not cover two distinct internal-core row neighborhoods, physical overlap of role copies, or general surviving-degree renormalization at arbitrary q. The previously submitted universal-head and universal-core notes are special cases. No claim of real stability or blanket strict Newton inequalities is made.
