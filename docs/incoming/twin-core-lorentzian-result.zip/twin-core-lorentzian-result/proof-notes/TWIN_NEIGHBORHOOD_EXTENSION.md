# Extension to two twin covered tails

Status: proposed ordinary extension, awaiting independent review. October 1, 2026. Depends on the connector lemma proved in TWO_UNIVERSAL_TAIL_CONNECTOR.md. This observation was suggested by the independent reviewer and is recorded separately from the initially submitted universal-core theorem.

## Statement

In the graph of the connector theorem, replace the complete core P×Q by P×J for an arbitrary subset J of Q. Thus the two covered tails have the same Q-neighborhood J; they are still both adjacent to every Y vertex. Keep X→Q completely arbitrary and X×Y empty. The polynomial

  F(t,z,z_Q)=sum_(S,T feasible) wt(S,T) t^|S|
                z^(2-|T intersect Y|) product_(j in Q minus T) z_j

is Lorentzian, homogeneous of degree q+2. Therefore its rank sequence is order-(q+2) ULC; for q=3 the approved rank-four fallback gives actual-degree ULC under arbitrary nonnegative activities. J may be empty, and no hypothesis of rank q in the X-side graph is made. The private head dummies below always force the auxiliary matroid to have rank q.

## Clone-seed construction

Start with the transversal matroid on old elements X union {d_j:j in Q}, where d_j has private neighborhood {j}. For each integer m>=q add m distinct new elements c_1,...,c_m, each with neighborhood J, to the same transversal presentation. This is a rank-q transversal matroid M_m because all q dummies form a basis.

For 0<=i<=q, define U_i(w) to sum products of old-element variables over old subsets I of size q-i such that I together with any i distinct J-clones is a basis. By symmetry of the clone neighborhoods the condition is independent of the choice of those i clones and independent of m>=q. It is a Boolean condition: a basis contributes coefficient one, not its number of transversals. Set U_i=0 if no such basis exists.

The exact basis polynomial of M_m is

  B_(M_m)(w,h)=sum_(i=0)^q e_i(h_1,...,h_m) U_i(w).

Set h_a=y/m and pass to the coefficientwise limit. The matroid-basis theorem, nonnegative linear specialization, and closedness imply that

  Z_J(y,w)=sum_(i=0)^q y^i U_i(w)/i!

is Lorentzian. By the proved upper-coordinate truncation lemma its y-degree-at-most-two part is Lorentzian. Apply exactly the same capacity-two connector operator, with the same Lorentzian quartic symbol, to obtain

  Q0 U_0(w)+Q1 U_1(w)+Q2 U_2(w).                         (1)

When J=Q, U_i is I_(q-i) of the old matroid, recovering the original theorem. When J is empty, U_i=0 for i>0, and the same argument still applies.

## Support bijection and activities

For any candidate endpoint support let p=|S intersect P| and r=|T intersect Y|. Necessarily 0<=r<=p<=2. Put

  I=(S intersect X) union {d_j:j in Q minus T}.

Then |I|=q-p+r. This endpoint support is feasible if and only if I together with p-r distinct J-clones is a basis of M_m. Forward, exactly r P tails are matched to Y and the other p-r P tails are matched to Q; replace those latter tails by clones and adjoin the private dummies. Reverse, replace those clones by any p-r selected P tails and match the remaining selected P tails to the r selected Y vertices. Every selected P tail has the same Q-neighborhood J and is adjacent to all Y, so the choice imposes no further feasibility condition.

For fixed chosen P and Y endpoint subsets this establishes a bijection of feasible endpoint data with the old sets counted by U_(p-r). It does not require, or choose, a canonical matching witness. Consequently the contribution is

  E e_p(u_P) e_r(v_Y) t^p z^(2-r) U_(p-r)(w),

under w_x=u_x t, w_dj=z_j/v_j, and E=product_j v_j. Summing p,r gives E times (1), with

  A=e1(u_P), B=e2(u_P), R=e1(v_Y), S=e2(v_Y).

All operator hypotheses hold, since A²>=4B and R²>=2S. This proves the polynomial is Lorentzian when Q activities are positive. Zero activities follow by the endpoint-polynomial limit, exactly as in the original theorem. The unused-support monomial has coefficient one. Diagonalizing the q+1 monomer variables gives order q+2, and only the separately stated q=3 rank-four fallback changes to surviving-degree normalization.

## Corroboration, not a proof premise

check_connector.py compares the Boolean endpoint and clone-seed formulas in 816 exact weighted cases: all 576 combinations of two X-neighborhood masks and twin-core neighborhoods at q=2,3, plus 240 seeded cases with q through five. These include 601 nonuniversal twin-core cases, 201 zero-activity cases, and 33 cases of full degree q+2. It also checks all six symbol Hessians and the factorial action. This finite check is only corroboration of the ordinary all-size argument.
