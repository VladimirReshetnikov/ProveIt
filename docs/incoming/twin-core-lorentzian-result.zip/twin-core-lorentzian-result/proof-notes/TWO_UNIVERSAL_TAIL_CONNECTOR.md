# A Lorentzian connector for two universal tails

Status: proposed ordinary theorem, awaiting independent review. October 1, 2026. All earlier delivered packages remain unchanged.

## 1. Graph, weights, and claims

Let a bipartite graph have left shore P disjoint union X and right shore Q disjoint union Y, where P={p0,p1} and |Q|=q>=2. Its edges are exactly all of P×Q, all of P×Y, and an arbitrary subset of X×Q. In particular there are no X×Y edges. All sets are finite and physically disjoint. Every vertex has an independent nonnegative activity: u_p for P, u_x for X, v_j for Q, and v_y for Y. A support is a pair (S,T) of equally large subsets of the two shores for which the induced bipartite graph has a perfect matching. Count each feasible endpoint pair once, irrespective of the number of matching witnesses; its weight is the product of its selected vertex activities.

Write Gamma(t)=sum_k gamma_k t^k. With separate unused-Q variables z_j and an additional variable z, define

  F(t,z,z_Q)=sum_(S,T feasible) wt(S,T) t^|S|
                    z^(2-|T intersect Y|) product_(j in Q minus T) z_j.       (1)

The exponent of z is nonnegative because every selected Y vertex must match into P. Every term has degree q+2.

**Proposed theorem.** F is Lorentzian for every choice of nonnegative activities. Consequently Gamma is ultra-log-concave with normalization order q+2: the sequence gamma_k/binom(q+2,k), padded through q+2, is log-concave and has no internal zeros. If the surviving degree is q+2, this is actual-degree ULC.

**Degree-five corollary.** For q=3, Gamma is ULC normalized by its actual surviving degree for every choice of nonnegative activities. Indeed the theorem handles actual degree five, and every smaller degree is covered by the previously approved arbitrary-weight bipartite matching-rank-at-most-four theorem on the active graph. Its frozen source is Theorem 1.1 in matching-rank-four-package.zip, SHA-256 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66.

The first claim is an ordinary all-q proof. Only the lower-degree corollary invokes that earlier theorem. Neither a general degree-renormalization principle nor real stability is claimed. Internal P×Q completeness and Y universality are required. Physical-role overlap, missing internal edges, and arbitrary Y neighborhoods are outside this statement.

## 2. Primary Lorentzian facts used

The primary reference is P. Brändén and J. Huh, *Lorentzian polynomials*, Annals of Mathematics 192 (2020), 821–891; the checked author manuscript is https://arxiv.org/pdf/1902.03719, version 8. We use: the M-convex-support/quadratic-Hessian characterization and closedness (Theorem 2.25), nonnegative linear substitution (Theorem 2.10), products (Corollary 2.32), matroid basis Lorentzianity (Theorem 3.10), and the finite-capacity symbol criterion (Theorem 3.2). Bivariate degree-d Lorentzianity is equivalent to order-d ULC with no internal zeros (Example 2.26). The operator's binomial normalization is written explicitly below. No general upper-coordinate truncation claim is inferred from Corollary 3.5; we prove the needed fact directly.

## 3. Upper-coordinate truncation lemma

If f is a nonnegative homogeneous Lorentzian polynomial, deleting every monomial whose exponent in a chosen variable y exceeds m produces a Lorentzian polynomial or zero.

Proof. Intersecting an M-convex support with the coordinate bound alpha_y<=m preserves the exchange axiom. For two retained exponent vectors, a simultaneous exchange can increase a y-coordinate only at the vector with strictly smaller y-coordinate, and thus cannot exceed the larger retained coordinate. All other coordinates have no new bound.

For degree d>=2, take a derivative partial^alpha of order d-2. If alpha_y<=m-2, its quadratic polynomial is unchanged by truncation. If alpha_y=m-1, only its y² term is removed, so its Hessian is decreased by a nonnegative diagonal matrix; the number of positive eigenvalues cannot increase. If alpha_y=m, its quadratic polynomial is restricted to y=0, giving a principal submatrix of the original Hessian and zero y row/column. If alpha_y>m, the result is zero. Thus every remaining quadratic derivative has at most one positive eigenvalue. The characterization proves the claim. Degrees zero and one are immediate. Empty support is handled as zero. QED.

## 4. Factorially homogenized matroid independence polynomial

For a rank-q matroid M on variables w=(w_e), let I_k(w) be its weighted independent-set polynomial of cardinality k, with I_k=0 outside 0<=k<=q. Then

  Z_M(y,w)=sum_(j=0)^q y^j I_(q-j)(w)/j!                         (2)

is Lorentzian and homogeneous of degree q.

Proof. Take the direct sum of M with a free matroid on m new elements and truncate it to rank q. Its basis polynomial is

  sum_j e_j(h_1,...,h_m) I_(q-j)(w).

This identity follows directly from the independent sets of a direct sum and truncation: an old independent set of size q-j can be joined to any j of the new elements. Set every h_i=y/m. The basis polynomial remains Lorentzian and converges coefficientwise, as m tends to infinity, to (2), since binom(m,j)/m^j tends to 1/j!. Closedness gives the result.

By the upper-coordinate truncation lemma,

  Zbar_M(y,w)=I_q(w)+y I_(q-1)(w)+(y²/2) I_(q-2)(w)              (3)

is Lorentzian. Each w_e is multi-affine; y has degree at most two.

## 5. The quartic connector symbol

Let A,B,R,S be nonnegative real numbers satisfying

  A²>=2B,                    R²>=2S.                            (4)

Define homogeneous polynomials

  Q0=z²+ARzt+BSt²,
  Q1=t(Az²+BRzt),
  Q2=Bz²t².

On polynomials of y-degree at most two, with multi-affine spectator variables w, define the homogeneous degree-increase-two operator

  T(f)=Q0 f|_(y=0)+Q1 (partial_y f)|_(y=0)
                         +Q2 (partial_y² f)|_(y=0).              (5)

It sends 1 to Q0, y to Q1, and y² to 2Q2. At capacity kappa_y=2 and kappa_w=1, its symbol is

  Sym_T=K(v,z,t) product_e(w_e+u_e),

  K=v²z²+ARv²zt+BSv²t²+2Avz²t+2BRvzt²+2Bz²t².                 (6)

Here v and u_e are independent dual variables. Indeed the finite symbol is sum_(alpha<=kappa) binom(kappa,alpha) T(y^alpha_y w^alpha_w) v^(2-alpha_y) u^(1-alpha_w). Thus the y contribution is Q0 v²+2Q1 v+2Q2. Both the input factorial 1/2 in (3) and the coefficient 2 multiplying Q2 in (6) are essential.

We prove K Lorentzian. First assume A,B,R,S>0. Its support is precisely the degree-four nonnegative exponent vectors in three variables, each coordinate at most two, an M-convex set (the exchange axiom is immediate from the equal-sum coordinate bounds). By the quadratic-derivative characterization it remains to check six Hessians, in variable order (v,z,t).

The three pure second derivatives are

  partial_v² K=2(z²+ARzt+BSt²),
  partial_z² K=2(v²+2Avt+2Bt²),
  partial_t² K=2B(Sv²+2Rvz+2z²).

Their nontrivial 2×2 Hessian determinants are, respectively,

  4(4BS-A²R²),   16(2B-A²),   16B²(2S-R²),

all nonpositive by (4). Each has at most one positive eigenvalue.

The mixed Hessians are

  Hess(partial_v partial_z K) = [[0,4,2AR],[4,0,4A],[2AR,4A,4BR]],
  Hess(partial_v partial_t K) = [[0,2AR,4BS],[2AR,4A,4BR],[4BS,4BR,0]],
  Hess(partial_z partial_t K) = [[2AR,4A,4BR],[4A,0,8B],[4BR,8B,0]].

Their determinants are respectively

  64R(A²-B),    64AB²S(R²-S),    128AB²R.                         (7)

Each determinant is strictly positive under the current positive-parameter assumptions and (4). Each matrix has a negative 2×2 principal minor, hence both a positive and a negative eigenvalue. A positive three-dimensional determinant then forces exactly one positive and two negative eigenvalues. Therefore K is Lorentzian. For arbitrary nonnegative parameters satisfying (4), approximate by A+2epsilon, B+epsilon², R+2epsilon, S+epsilon² and let epsilon decrease to zero. These preserve the inequalities and are positive, so closedness proves the boundary case.

The spectator factors in the symbol are nonnegative linear polynomials. Products preserve Lorentzianity; therefore Sym_T is Lorentzian. The primary finite-capacity operator theorem now proves that (5) sends every Lorentzian input within these capacities to a Lorentzian polynomial or zero. Applying it to (3) yields the degree-(q+2) Lorentzian polynomial

  H(t,z,w)=Q0 I_q(w)+Q1 I_(q-1)(w)+Q2 I_(q-2)(w).                (8)

This is an abstract matroid statement and does not require M to be transversal or stable.

## 6. Exact endpoint-support correspondence

Take M to be the transversal matroid on X together with private dummy elements d_j, j in Q. Its presenting slots are Q: each x is incident to its original neighbors in Q, and d_j is incident only to j. It has rank q because all private dummies form a basis.

For a proposed support, write p=|S intersect P|, r=|T intersect Y|, and s=|T intersect Q|. Feasibility forces 0<=r<=p<=2. Associate the matroid subset

  I=(S intersect X) union {d_j : j in Q minus T}.

Its size is q-p+r, since |S intersect X|=s+r-p. The endpoint support is feasible exactly when I is independent. Forward: restrict any matching to the X tails, then match every dummy to its own unused Q slot. Reverse: an independent-set matching sends all selected X tails into selected Q slots; there remain p-r selected Q slots, and the p selected P tails can match these together with the r selected Y vertices because P is universal to Q union Y.

This is a bijection of selected endpoint data once the selected P and Y subsets are recorded. It does not select a witness. Consequently every endpoint support is counted exactly once even when either matching has several witnesses.

Assume first all v_j>0. Put

  A=u_p0+u_p1,  B=u_p0 u_p1,  R=sum_(y in Y) v_y,  S=e2(v_Y),
  E=product_(j in Q) v_j,
  w_x=u_x t,                         w_dj=z_j/v_j.              (9)

Then A²>=4B and R²>=2S, as required by (4). For fixed p,r the endpoint bijection contributes

  E e_p(u_P) e_r(v_Y) t^p z^(2-r) I_(q-p+r)(w).                  (10)

Summing its six possible pairs 0<=r<=p<=2 gives exactly E times (8) under (9):

  r=0: z²[I_q+At I_(q-1)+Bt² I_(q-2)],
  r=1: Rzt[A I_q+Bt I_(q-1)],
  r=2: BSt² I_q.

This is precisely (1). In particular the p=2,r=1 term has coefficient B, not 2B: the two possible assignments of P tails are matching witnesses of the same endpoint support and are not counted separately.

Nonnegative linear substitution and positive scaling preserve Lorentzianity, so F is Lorentzian. If some v_j=0, approximate those activities by positive ones and pass to the coefficientwise limit in the endpoint formula (1); no reciprocal remains in the resulting polynomial. The empty support contributes z² product_j z_j with coefficient one, so the output never vanishes.

Finally set every z_j=z. Formula (1) becomes

  F(t,z,z,...,z)=sum_k gamma_k t^k z^(q+2-k),                    (11)

and the asserted order-(q+2) ULC follows. Positive-weight supports exist in every smaller size by deleting matched edges from a positive-weight matching, so there are no internal zeros independently of the Lorentzian conclusion. For q=3 and surviving degree at most four, delete zero-activity vertices and apply the frozen rank-four theorem to this active bipartite graph, whose matching rank equals the surviving support degree. This proves the actual-degree corollary.

## 7. Verification scope

The proof above is ordinary and covers arbitrary finite populations; no finite search is used as a proof premise. The accompanying checker expands the six derivative Hessians, symbol factorials and support formula, and independently compares endpoint enumeration with the matroid formula on weighted finite examples. These are corroboration and transcription checks only. Independent review and publication-priority questions remain separate.
