#!/usr/bin/env python3
"""Read-only full dependency, ordinary proof and exact support-formula replay."""
if not __debug__:raise SystemExit('Run without -O; assertions are required.')
from pathlib import Path,PurePosixPath
import hashlib,json,os,shutil,stat,subprocess,sys,tempfile,time,zipfile
ROOT=Path(__file__).resolve().parent
DEP_SHA='9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(v):
 if isinstance(v,dict):return{k:canonical(x)for k,x in v.items()if k not in {'seconds','elapsed_seconds'}}
 if isinstance(v,list):return[canonical(x)for x in v]
 return v
def manifest(p,exact=True):
 r={}
 for line in (p/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);n=n.removeprefix('./');assert n not in r and sha(p/n)==h,n;r[n]=h
 if exact:assert {q.relative_to(p).as_posix()for q in p.rglob('*')if q.is_file()and q.name!='SHA256SUMS'}==set(r),'Manifest coverage is not exact'
 return r
def run(script,cwd,args=()):
 p=subprocess.run([sys.executable,str(script),*map(str,args)],cwd=cwd,text=True,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 if p.returncode:
  print(p.stdout);print(p.stderr,file=sys.stderr);raise AssertionError(script.name)
 return p.stdout
def compare(actual,expected,label):
 assert canonical(actual)==canonical(expected),f'Receipt mismatch: {label}'
 print(f'PASS: {label}; every deterministic receipt field matches',flush=True)
def main():
 start=time.monotonic();original=manifest(ROOT);checks=[]
 print(f'PASS: {len(original)} release hashes and exact manifest coverage',flush=True)
 # Check every historical absolute-path proof pin against one exact packaged copy.
 for receipt_name in ('approval_receipt.json','twin_approval_receipt.json','private_head_approval_receipt.json'):
  receipt=json.loads((ROOT/'audits'/receipt_name).read_text())
  for old_path,h in receipt['files'].items():
   matches=[p for p in ROOT.rglob(Path(old_path).name) if p.is_file() and sha(p)==h]
   assert len(matches)==1,(receipt_name,old_path,h)
 print('PASS: all historical proof-approval pins match packaged bytes',flush=True)
 integrated=ROOT/'audits/integrated-approval.json'
 if integrated.exists():
  receipt=json.loads(integrated.read_text())
  for name,h in receipt.get('files',{}).items():
   candidate=Path(name) if Path(name).is_absolute() else ROOT/name
   if not candidate.is_relative_to(ROOT):
    matches=[p for p in ROOT.rglob(candidate.name) if p.is_file() and sha(p)==h];assert len(matches)==1,name
   else:assert sha(candidate)==h,name
  print('PASS: integrated paper approval pins',flush=True)
 archive=ROOT/'dependency/matching-rank-four-package.zip';assert sha(archive)==DEP_SHA
 with tempfile.TemporaryDirectory(prefix='twin-core-lorentzian-replay-')as temp:
  base=Path(temp);dep=base/'rank-four';dep.mkdir()
  with zipfile.ZipFile(archive)as z:
   names=z.namelist();assert len(names)==len(set(names));assert z.testzip()is None
   for info in z.infolist():
    p=PurePosixPath(info.filename);assert not p.is_absolute()and '..'not in p.parts
    assert not stat.S_ISLNK(info.external_attr>>16)
   z.extractall(dep)
  pins=manifest(dep)
  assert (dep/'matching-rank-four.pdf').read_bytes()==(ROOT/'dependency/matching-rank-four.pdf').read_bytes()
  for script,receipt in [('check_weighted_rank_four.py','verification.json'),('check_rank_three_minimum.py','rank-three-minimum-verification.json'),('check_rank_three_bijections.py','rank-three-bijections-verification.json'),('check_rank_five_certificate.py','rank-five-verification.json')]:
   actual=json.loads(run(dep/script,dep));compare(actual,json.loads((dep/receipt).read_text()),'dependency/'+script);checks.append(script)
  target=base/'regenerated-rank-five.json'
  actual=json.loads(run(dep/'generate_rank_five_certificate.py',dep,['--output',target]))
  compare(actual,json.loads((dep/'rank-five-generation.json').read_text()),'dependency/certificate-generation')
  assert target.read_bytes()==(dep/'rank-five-certificate.json').read_bytes();assert manifest(dep)==pins
  checks.append('dependency certificate regeneration')
  producer=base/'producer';producer.mkdir()
  for p in (ROOT/'reproducibility/producer').glob('*.py'):shutil.copyfile(p,producer/p.name)
  for script,receipt in [('check_connector.py','verification.json'),('check_arbitrary_exteriors.py','arbitrary_exterior_verification.json'),('check_pendant_lorentzian.py','pendant_verification.json')]:
   run(producer/script,producer,['--output-dir',producer])
   compare(json.loads((producer/receipt).read_text()),json.loads((ROOT/'reproducibility/producer'/receipt).read_text()),'producer/'+script);checks.append('producer/'+script)
  independent=base/'independent';independent.mkdir()
  for script,receipt,note in [('check.py','independent_receipt.json','TWO_UNIVERSAL_TAIL_CONNECTOR.md'),('check_twins.py','independent_twin_receipt.json','TWIN_CORE_ARBITRARY_EXTERIORS.md'),('check_private_heads.py','independent_private_head_receipt.json','PENDANT_HEAD_LORENTZIAN_EXTENSION.md')]:
   source=ROOT/'reproducibility/independent'/script;copied=independent/script;shutil.copyfile(source,copied)
   run(copied,independent,['--source-note',ROOT/'proof-notes'/note,'--output-dir',independent])
   compare(json.loads((independent/receipt).read_text()),json.loads(source.with_name(receipt).read_text()),'independent/'+script);checks.append('independent/'+script)
 assert manifest(ROOT)==original
 print(json.dumps({'verdict':'PASS','manifest_files':len(original),'checks':checks,'all_new_deterministic_receipts_match':True,'elapsed_seconds':round(time.monotonic()-start,3)},indent=2))
if __name__=='__main__':main()
