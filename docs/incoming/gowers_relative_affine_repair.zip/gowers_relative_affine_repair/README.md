# Nearly Sharp Relative Affine Repair on Fourier-Uniform Domains

Research manuscript prepared for the ProveIt Ramsey project, 6 October 2026.

## Main statement

Let G be a finite abelian group, H any abelian group, and w:G→[0,1] have
mean α>0. Put u=||w−α||_{U²(G)} and let ε be the fraction of violated
weighted ordered additive quadruples. If

    u⁴ ≤ α⁵/1024,     ε ≤ 1/1024,

then there is a unique affine map within relative weighted distance
13ε/50. The domain condition is independent of ε. An explicit profile
improves the coefficient to 1/4+o(1) as ε and u²/α^(5/2) tend to zero;
1/4 is optimal, including on domains with arbitrarily small fixed limiting
densities. A quadratic-level-set corollary uses matrix rank R with
p^(R−4r) ≥ 2^14, independently of ε.

The first coarse bootstrap gives ε/3; the final displayed estimate is stronger.
The main theorem and every corollary are proved in the manuscript.

## Files

- `article.tex`, `sections/*.tex`: complete LaTeX sources.
- `article.pdf`: compiled article.
- `code/repair.py`: exact rational modal decoder for explicit products of cyclic
  groups, with a finite abelian target. The theorem allows arbitrary abelian H.
- `code/verify.py`: exact-arithmetic finite diagnostics.
- `data/verification.json`: recorded results, 33,889 assertions passed.
- `data/source_manifest.json`: pinned sources and bibliography provenance.
- `data/build_validation.json`: compilation and layout-validation metadata.
- `SOURCE_AUDIT.md`: comparison, exclusions, and integration guidance.
- `Makefile`: reproducible verification and PDF build.

## Build and check

From this directory:

    python3 code/verify.py --output data/verification.json
    python3 code/repair.py
    make pdf

The Python code needs only the standard library. It was run with Python 3.
The PDF build uses pdfLaTeX with standard TeX Live packages: amsmath, amssymb,
amsthm, mathtools, geometry, microtype, lmodern, enumitem, hyperref, fancyhdr,
booktabs, array, and longtable. A second or third LaTeX pass resolves references.

The decoder is O(|G|²) in group/hash operations, not in bit complexity, and is
not a sublinear oracle algorithm. Its numerical-hypothesis flag is not a
proof-assistant certificate. For arbitrary data outside the theorem range,
the output may be non-affine; the returned `additive` field checks this.

## Normalizations

Quadruple masses use |G|^(-3), pair masses |G|^(-2), and the Fourier transform
uses |G|^(-1). Fourier sums over the dual group are unnormalized sums.
Ordered tuples include repeated vertices. The error is normalized by the
actual available quadruple mass Q(w), not by α³ or by |supp(w)|³.
A relative theorem on a subgroup/coset gives an affine map there; extension
to a larger ambient group is not automatic.

## Scope and research status

This is an AI-generated research draft, with complete mathematical proofs and
finite exact-arithmetic diagnostics. It is not externally refereed and is not
Lean-verified. Worldwide priority is not established. Linear affine repair
itself predates this manuscript: the text credits BLR self-correction and
Kazhdan–Ziegler polynomial splining, and compares the explicit statement with
Peluse's 2026 relative affine lemma.

No new global Szemerédi bound or global inverse-theorem bound is claimed.
The quadratic-domain corollary repairs affine labels; it is not a theorem
repairing approximately quadratic labels.

## Suggested repository location

    Combinatorics/Ramsey/Research/GowersSzemeredi/relative-affine-repair/

This package does not change existing files or any formalization-status ledger.
Its theorem names in the integration plan are proposals, not compiled declarations.
