# fastunknot 0.3.0: braid and structural certificates with optional shared backends

## Quadratic periodic scheduling and weighted disk components (2026-10-09)

The default interval merger scheduler is now `adaptive`. It preserves the
historical complete reduction trace, using a bounded restart-scan prelude and
then a generation-checked event queue when the scan allowance is exhausted.
Use `merger_scheduler='legacy'` or `'queue'` for controlled comparisons.
A closure with `k` rows uses at most `(k-1)**2` merger tests in queue mode;
adaptive mode adds at most `k*(k-1)//2` tests. The queue has quadratic worst-case
memory. Easy first-pair successes use a lazy fast path without queue setup.
These are per-closure bounds, not a quadratic bound for all AHT cycles.

`fastunknot.weighted_orbits.weighted_orbit_profile` computes compressed signed
vector sums per orbit. `replay_weighted_orbit_profile` reuses an independently
checked local trace. Equal vectors are grouped with binary multiplicities;
neither interval points nor components are expanded. Full-carrier range
transfer preserves a linear bound on active weight breakpoints. This is an
implementation of classical weighted Agol–Hass–Thurston theory.

`fastunknot.normal_component_profile.normal_component_profile` detects and
counts compressing-disk components in a supplied admissible normal vector,
including disconnected surfaces. Five integer weights recover component Euler
characteristic, polygon count, boundary vertices, and two torus-cycle
intersection counts. Set `record_certificate=True` and check the result with
`verify_normal_component_profile(triangulation, coordinates, certificate)`.
The old whole-surface `compressing_disk` flag is unchanged. A negative component
answer concerns only that vector and does not prove boundary incompressibility.
No correspondence with an input knot diagram is certified by this interface.

Run `python -m component_profile_research.demo` for a meridian-plus-vertex-link
example and a one-record certificate for `2**5000` parallel meridian disks.
The demo requires no Regina. Independent Regina oracles are in
`component_profile_research/oracles.py`. The accompanying research article,
raw paired measurements, standalone snapshot, and integration patch are titled
*Compressed Component Certificates and Quadratic Periodic Scheduling for
Unknot Recognition* (9 October 2026). They establish local improvements, not a
general quasi-polynomial unknot-recognition theorem.


Orbit queries can now return independent local proofs with
`count_orbits(..., record_certificate=True)`. Replay with
`fastunknot.interval_orbit_verify.verify_orbit_certificate(size, pairs, proof)`.
Version one preserves classical merging; version two permits the exact
Fine–Wilf threshold. Use `integer_codec.json_safe` for huge binary integers.
Incomplete queries return no count or certificate.

`fastunknot.interval_incidence.analyze_port_incidence` counts components meeting
each subset of supplied half-open marked intervals. It shares repeated unions
and stores each orbit proof once. All orbit queries share one `max_cycles`
allowance; the explicit default cap of 12 ports controls the dense `2**r`
histogram. Its independent verifier checks source binding, every distinct orbit
proof and forward subset sums. These signatures record set incidence, without
cyclic order, slopes or attaching maps. All 831 maintained tests pass with Regina.
Theory and measured gains/regressions are in
[`orbit_certificates.tex`](../synthesis/orbit_certificates.tex). Reproduce with
`python -B benchmark_orbit_certificates.py --output FILE`,
`python -B normal_orbit_research/benchmark_trace_cost.py --output FILE`, and
`python -B normal_orbit_research/audit_certificates.py --output FILE`.

`fastunknot.interval_orbits.count_orbits` now counts equivalence classes of
binary-encoded interval pairings without expanding their points. The default
uses the sharp Fine–Wilf periodic merger; `periodic_rule='aht'` retains the
classical threshold. `max_cycles` counts begun cycles, and exhaustion returns
no count. Optional callbacks provide cooperative cancellation.

`fastunknot.normal_surface_orbits.normal_surface_topology` validates a supplied
finite, compact, connected, orientable triangulation with one torus boundary
and admissible seven-coordinate normal surfaces. It returns component and
orientation counts, boundary count, total Euler characteristic, and whether a
connected supplied disc has essential boundary. All three orbit queries share
one allowance. It does not certify correspondence with an input knot diagram.
Ordinary recognition does not dispatch this interface. The theory and remaining
geometry obligations are in [`interval_orbits.tex`](../synthesis/interval_orbits.tex).
All 805 maintained tests pass with Regina. Reproduce the component measurements
with `python -B benchmark_orbits.py --output results/orbits.json`; the committed
run is `results/orbits_20261008.json`, with shuffled classical/sharp/A/A arms.

The existing normal-surface worker also stages UTF-8 request and result streams
in temporary files. This avoids losing partially written pipe input after a
timeout, while preserving cooperative deadlines and child/stream cleanup.

Explicit overlap search now skips donors whose lengths cannot exceed the
best guaranteed shortening already found, and stops a donor scan when its
upper bound is attained. This preserves the complete selected witness and
independent replay, while reducing work for repeated long donors. See
[`exposure_residual.tex`](../synthesis/exposure_residual.tex) for the proof,
controlled measurements, and an independently verified continuation of the
Whitehead report's stalled Gordian residual. The exposure handoff remains an
offline experiment: the existing search already recognizes that input faster.
Reproduce the pruning audit with
`python -B exposure_research/benchmark_bounds.py`.

Compressed substring queries also bound matches by the directed signed-letter
pairs shared by both words. This handles some expensive cases with identical
alphabets. Whole-donor search rejects impossible pair sets, including the
cyclic seam and inverse orientation, before allocating inverses or matching.
Uniform words reuse their exact metadata to avoid redundant pair extraction.
All 687 tests pass. The complete exact fallback and independent relator replay
remain in place; a general subexponential bound is still unproved. See
[`lcs_transitions.tex`](../synthesis/lcs_transitions.tex) for the proofs and
controlled results. Reproduce them with `benchmark_lcs_transitions.py` and
`benchmark_donor_pair_shortcut.py`, each taking `--output PATH`.

Compressed substring queries now use exact shared-alphabet run bounds and
process extension witnesses as soon as they are checked. Letters absent from
the other word act as barriers; once a witness reaches a proved global or local
bound, the remaining candidates are skipped. Same-alphabet queries retain the
complete fallback. All 687 tests pass, including exponentially long inputs
where tables are forbidden once optimality is already proved. See
[`lcs_bounds.tex`](../synthesis/lcs_bounds.tex) for the proof and scope.
Reproduce the isolated component audit with
`python -B benchmark_lcs_bounds.py --output results/lcs_bounds_local.json`.

When whole-donor search would stall, compressed group search now finds partial
cyclic overlaps over all donor rotations and both signs. The exact compressed
longest-common-substring primitive uses dyadic overlap progressions and at most
six periodic extension candidates per progression. Shared-letter counts give
safe pruning and early completion bounds. Existing independent relator replay
checks every emitted move. The integrated suite has 687 passing tests; the
local query has a polynomial bound, while general recognition remains unproved.
See [`compressed_lcs.tex`](../synthesis/compressed_lcs.tex) for proofs and limits.

Compressed whole-donor search now batches consecutive copies in a version-4
`relator_power` certificate. Both literal and compressed verifiers independently
check the entire removed prefix. Exact uniform-letter summaries make equality
and prefix queries on pure powers constant work, and ineligible donor pairs are
pruned before allocating inverses. On supplied pure-power presentations this
turns repeated subtraction into Euclidean division; the general recognition
bound remains unproved. The integrated suite has 687 passing tests with Regina,
including a genuine Gordian trace accepted by both verifiers, forged macro
rejection, and a compressed `2^500` replay without expansion.
The proof and limits are in [`relator_powers.tex`](../synthesis/relator_powers.tex).
Reproduce the component-controlled audit with
`python -B benchmark_relator_power.py --output results/relator_power_local.json`.

When compressed group search would stall above the explicit-letter cap,
`--group-relators` now enables exact whole-donor deletion without expansion.
A fully compressed substring matcher uses arithmetic-progression occurrence
tables and a safe first-letter probe. It searches every cyclic target position
for the donor's recorded spelling or inverse; arbitrary donor rotations and
partial overlaps are handled by the later complete cyclic fallback. Accepted moves use the existing
independent relator certificate replay. Work and storage limits remain
inconclusive, and no general subexponential bound is claimed.
See [`compressed_matching.tex`](../synthesis/compressed_matching.tex) for the
proof and boundaries. Reproduce the matched measurements with
`python -B benchmark_compressed_match.py --output results/compressed_match_local.json`.
The supplied exponential presentation family now completes in two moves;
existing knot-corpus paths and timings remain essentially unchanged.

Compressed group search now batches powers of a selected Whitehead automorphism
when the move repeats or expanded length exceeds four times allocated grammar
size. An exact weighted-median gap profile chooses the first minimizing power
without expanding the words. Version-3 certificates are checked independently
by compressed substitution or literal elementary replay. The explicit search
policy is unchanged. This removes exponential unit descent on a supplied
compact presentation family; a general subexponential recognition bound remains
unproved. See [`whitehead_powers.tex`](../synthesis/whitehead_powers.tex).
Reproduce the matched historical comparisons with
`python -B benchmark_whitehead_power.py --output results/whitehead_power_local.json`.
Use `--case survivor-02 --rounds 21 --queries-only` for a focused timing audit.
Saved primary and follow-up results retain all raw samples and censoring status;
no speedup on the current knot corpus is claimed.


This research continuation adds a linear signed Seifert-graph certificate before
the established recognition pipeline and three optional Khovanov backends.
The new front end completely decides homogeneous input diagrams after validation.
When inconclusive it continues the original stages. Disable it with `--no-seifert`
or `use_seifert=False` to retain the previous stage order.

If the initial Reidemeister I/II pass removes crossings but does not finish,
the pipeline repeats the structural check before matrix filters. Cancelling
pairs can expose homogeneity. Evidence under `seifert_after_reduction` describes
the reduced diagram: replay `reidemeister_trace` with `fastunknot.simplify.replay`
before passing that certificate to `verify_seifert_certificate`. An unchanged
diagram is not checked twice. The integrated suite now has 687 passing tests
with the optional Regina dependency installed.

`--group-adaptive` starts the optional group search with explicit words, then
switches once to SLPs before a substitution would exceed its letter allowance.
The switch preserves the current presentation, completed moves and remaining
work/time budget. It automatically uses compressed replay after a handoff;
without a handoff, replay stays explicit. `--group-switch-letters 4096` enables
an earlier optional threshold; Python callers use `use_group=True,
group_adaptive=True, group_switch_letters=4096`. Always-compressed search and
adaptive search are mutually exclusive.

The default switch threshold equals the hard letter cap. It preserves all
fifteen current corpus traces and their explicit representation. In 375 whole
queries its timing is near the explicit controls; earlier switching on Gordian
costs 1.641 seconds versus the explicit control's 1.251 seconds. With hard caps
of 64/60 letters on two small cases and 4096/8192 on Gordian, the adaptive stage
instead recovers verified certificates in all twenty measured probes where
explicit search exhausts the cap. Those exhaustion times are not speedups.
See [`results/adaptive_group_20261008.json`](results/adaptive_group_20261008.json)
and [`adaptive_group.tex`](../synthesis/adaptive_group.tex) for complete scopes,
the bounded explicit-prelude argument and the unresolved asymptotic limits.

```sh
python -B -m fastunknot recognize normal_research/gordian.json \
  --group-adaptive --group-relators --group-seconds 3 \
  --group-max-work 10000000 --seconds 5
python -B benchmark_adaptive_group.py --output results/adaptive_group_local.json
```

`--group-compressed-search` enables optional compressed group discovery and
replay. Exact generator counts, unique-occurrence masks and weighted Whitehead
graphs are computed from shared word grammars. Elimination and Whitehead moves
stay compressed; optional relator-overlap matching expands only when the total
length fits its 200,000-letter cap. Above that cap the overlap probe is skipped,
and failure to finish remains inconclusive. Python callers use
`use_group=True, group_compressed_search=True`; the standalone producer is
`fastunknot.compressed_search.compressed_certificate`.

The compressed word checker now indexes assertions by the symbols they mention.
It first tries a bounded 64-step DAG walk, then switches to the polynomial
split-and-compaction algorithm if unresolved. The cap preserves the polynomial
equality bound even when the represented words are exponentially long.
Standalone `WordArena(equality_probe_steps=0)` disables the direct probe.

Cancellation now uses a separate bounded prefix walk and reuses its proved
prefix in the polynomial fallback. Bisection compares only the still-unproved
interval. `WordArena(prefix_probe_steps=0)` disables this direct walk while
retaining the improved bisection rule; the default cap is 64 steps.

In the latest 375-query comparison, Gordian's compressed-search median drops
from 2.461 to 1.922 seconds with the prefix changes, including independent replay.
Fourteen smaller cases total 185.27 versus 245.18 ms in summed medians.
Explicit search remains faster at 1.259 seconds and 51.50 ms respectively.
The direct walk resolves 895 of Gordian's 971 prefix queries; equality calls
fall from 3,035 to 271. Some synthetic kernels still favor suffix-only bisection,
so this is not a uniform speedup. All measured queries complete successfully. Synthetic
summary and elimination operations handle lengths above 2^1024 with 3,077
allocated nodes, but this is not a hard-knot benchmark or a search-step bound.
Explicit search remains the default. To reproduce the optional experiment:

```sh
python -B -m fastunknot recognize normal_research/gordian.json \
  --group-relators --group-compressed-search --group-seconds 10 \
  --group-max-work 10000000 --seconds 12
python -B benchmark_compressed_search.py --output results/compressed_search_local.json
```

See [`results/compressed_prefix_20261008.json`](results/compressed_prefix_20261008.json)
for the current prefix comparison,
[`results/indexed_equality_20261008.json`](results/indexed_equality_20261008.json)
for the previous equality improvement, and
[`results/compressed_search_20261008.json`](results/compressed_search_20261008.json)
for the initial capacity experiment. The article gives the equality scheduling
and fallback invariants, DAG multiplicity proof and remaining global limits.
`python -B benchmark_compressed_prefix.py --output results/prefix_local.json`
reproduces the latest comparison using the recorded pre-change kernel from Git history.

`--group-compressed` enables only exact SLP-based replay of group certificates.
Its deterministic word kernel supports equality, slicing, inversion and free
reduction without expanding the represented strings. Recognition still searches
with explicit relators. The existing certificate formats remain unchanged;
Python callers select `group_compressed=True` together with `use_group=True`,
or call `verify_group_certificate(diagram, certificate, compressed=True)`.

This is an experimental capacity extension. In constructed proof traces, it
checks intermediate words with 90-bit lengths using 904 grammar nodes, while
the explicit checker exhausts its letter cap. On the present knot corpus it
costs more: Gordian's median whole query rises from 1.236 to 1.417 seconds.
Explicit replay remains the default. The node/assertion ceiling is 100,000;
standalone verification accepts `max_nodes`, `max_work`, and a `stats` dictionary.
In compressed mode `max_letters` bounds the initial presentation only.

```sh
python -B -m fastunknot recognize normal_research/gordian.json \
  --group-relators --group-compressed --group-seconds 2 \
  --group-max-work 10000000 --seconds 4
python -B benchmark_compressed_words.py --output results/compressed_local.json
```

See [`compressed_words.tex`](../synthesis/compressed_words.tex) for the
split-and-compaction equality proof, exact boundary cancellation, validation,
and the distinction between polynomial word operations and unbounded search
or grammar growth. Raw whole-query and constructed-capacity measurements are
in [`results/compressed_words_20261008.json`](results/compressed_words_20261008.json).

`--group-relators` adds exact relator-overlap substitutions to the group
certificate stage and enables it. It uses suffix automata to avoid expanding
all cyclic rotations. The search chooses Whitehead moves first at six or
fewer surviving generators and overlaps first at larger rank, with safe
fallback when either search stalls. This empirical dispatch rule preserves
all twelve original survivor traces and also certifies the two previously
stalled mirrors.

The 141-crossing Gordian example now has a **native, independently checked**
certificate with 140 generator eliminations and one overlap substitution.
In five paired runs it finishes at a median 1.212 seconds including replay,
versus 1.708 seconds through Regina. Older controls time out at four seconds.
It needs larger allowances than the default short probe:

```sh
python -B -m fastunknot recognize normal_research/gordian.json \
  --group-relators --group-seconds 2 --group-max-work 10000000 --seconds 4
```

Python callers use `use_group=True, group_relators=True, group_seconds=2,
group_max_work=10000000`. Replay a saved version-two certificate with
`verify_group_certificate(diagram, certificate, max_work=10000000)`.
Version-one certificates remain supported. This stage has no Regina dependency.
See [`relator_overlap.tex`](../synthesis/relator_overlap.tex) for the
normal-closure proof, suffix-automaton algorithm and conditional complexity
bound. The mode remains optional and does not establish general
sub-exponential recognition.

`--group` (Python: `use_group=True`) tries a bounded knot-group certificate
search after invariant filters. Exact generator eliminations and Whitehead
changes of basis reduce a full Wirtinger presentation; an independent checker
reconstructs and replays the trace before accepting a one-generator,
relation-free presentation. For a validated classical knot this proves
unknottedness. Stalling or local exhaustion falls back to the remaining
recognizers, and a global deadline still yields `UNKNOWN`.

```sh
python -B -m fastunknot recognize examples/hard_unknot_8.json --group
python -B benchmark_group.py --output results/group_local.json
```

Search and replay share `--group-seconds 0.05` per attempt. The standalone
`fastunknot.group_certificate.group_decide` also accepts `max_letters` (default
200,000) and `max_work` (default 2,000,000 per search/replay); `seconds=None`
removes only the wall cap. `group_certificate` produces a trace, and
`verify_group_certificate(diagram, certificate)` independently checks it.
Certificates contain the actual normalized PD used by that stage; when the
pipeline has reduced or factored the input, its earlier evidence supplies
the connection to the original diagram.

In seven paired whole-query rounds this stage certified all twelve maintained
Khovanov-only survivors. Ten improved, with the largest gains about 2.3x and
3.3x. The sum of their median costs fell from 60.8 to 39.2 ms, including replay.
Two survivors and the already cheap RIII examples regressed, so the stage is
**disabled by default**. No general sub-exponential bound is established:
word expansion and stalled searches remain obstacles. See
[`group_certificates.tex`](../synthesis/group_certificates.tex) for the theory,
new-preprint convention audit, benchmarks and limitations, and
[`results/group_20261008.json`](results/group_20261008.json) for raw measurements.

`--regina` (Python: `use_regina=True`) adds an optional complete external
normal-surface recognizer after cheap invariant filters, on undecided diagrams
with at least 32 crossings. Install the extra in the interpreter running the
recognizer:

```sh
python -m pip install '.[normal]'
python -B -m fastunknot recognize normal_research/gordian.json --regina --seconds 4
```

Each attempt runs in a fresh subprocess, with a default two-second local
allowance including native import and startup (`--regina-seconds`). Missing
dependencies, native failures and local timeouts are inconclusive and continue
the existing RIII/Khovanov pipeline. A global deadline yields `UNKNOWN`; every
interrupted worker is killed and reaped. `max_objects` bounds Khovanov, not
Regina's memory. Python's `regina_seconds=None` disables the local cap.
`fastunknot.normal_surface.regina_decide` offers the standalone query without
the pipeline's crossing threshold.

This is explicitly an **external-engine verdict**, not an independently
verified normal-surface certificate. Evidence records input digest, engine and
distribution versions, simplification and triangulation sizes, and elapsed
time. Serialized external verdicts do not inherit the built-in runtime bound.
The default remains dependency-free and does not call Regina.

In five paired runs, the portfolio decided Haken's 141-crossing Gordian unknot
every time (median 1.788 seconds including validation and child startup); both
default controls exhausted their four-second allowance every time. GST,
Monster and Conway stayed on the existing fast paths. These are censored
completion comparisons, not a general speedup or asymptotic theorem. See
[`normal_research/README.md`](normal_research/README.md),
[`normal_surface.tex`](../synthesis/normal_surface.tex), and
[`results/normal_surface_20261008.json`](results/normal_surface_20261008.json).

An optional complete test for **projection graphs of treewidth at most two**
is enabled by `--treewidth-two` or `use_treewidth_two=True`. It first certifies
that the crossing graph excludes a K4 minor, then computes the exact integer
determinant. On this class, the structural classification as connected sums
of two-strand torus knots makes determinant one sufficient for `UNKNOT`.
Arbitrary determinant-one knots do not pass this rule. No supplied braid or
rational-tangle presentation is required.

```sh
python -B -m fastunknot recognize examples/trefoil.json --treewidth-two --no-braid
```

The local allowance defaults to 0.1 seconds (`--treewidth-two-seconds`);
exhaustion continues the existing recognizer, while a global deadline yields
`UNKNOWN`. Python's `treewidth_two_seconds=None` removes the local cap.
`fastunknot.treewidth_two.treewidth_two_certificate` provides the uncapped
standalone producer, returning `None` outside the class.
`verify_treewidth_two_certificate` independently replays the graph order and
recomputes the determinant with Fox matrices and rational elimination.
The producer has polynomial bit cost on this class; it does not implement
the published linear-time generalized-diagram algorithm. A capped probe
followed by Khovanov fallback does not inherit the polynomial bound.

`benchmark_treewidth_two.py --output FILE` measures validation plus complete
recognition on fresh PD inputs with paired controls. The recorded run improves
three mixed-sign two-strand unknot cases by 1.085–1.142x, but slows several
cases already handled cheaply by Seifert certificates. It remains optional.
See [`treewidth_two.tex`](../synthesis/treewidth_two.tex) for the theory and
[`treewidth_two_20261008.json`](results/treewidth_two_20261008.json) for raw
measurements. The general subexponential recognition goal remains open.

New RIII trace entries include `triangle`, the three dart indices of the
chosen face in the original input diagram. Crossing indices alone can name
two different legal faces. Replay validates the specified face and accepts
older crossing-only RIII records only when the face is unambiguous. R1/R2
records retain their existing format.

The report 27 causal RIII search is available with `r3_search="clustered"`
or `--r3-search clustered`. It tracks the union of all touched darts and admits
up to `r3_births` independent starting moves (default 1). `r3_search="adaptive"`
first gives the historical search half the remaining trial allowance, then
switches to clustered search if stalled. Both share `r3_budget` trials per
input crossing (default 10); `None` disables the total cap in Python. The
maximum sequence length is `r3_depth` (default 4). For example:

```sh
python -m fastunknot recognize examples/hard_unknot_8.json --r3-search adaptive --r3-depth 6
```

Speculative branches roll back on interruption. Local trial exhaustion falls
back to exact recognition; a global deadline yields `UNKNOWN`. If an unfiltered
root search finds no legal RIII move, the simplifier skips further deepening
and switching because no RIII sequence can start. The default remains `last`:
the new modes did not improve crossing counts in the recorded random-diagram
audit and sometimes left more crossings under the same trial cap. Greater
depth helps two stored hard unknots independently of the clustered algorithm.
See `benchmark_causal_r3.py` for paired recognition/simplifier measurements
and its `--discovery` mode for reproducible search and exact legacy-trace checks.

The incoming radical-transfer report contributes exact binary prediction of
the objects surviving cancellation. `--reduction adaptive` (Python:
`reduction="adaptive"`) starts sparse cancellation and switches to that
prediction after its per-stage Schur-update allowance is exceeded. If the
survivors have no adjacent degrees, or the boundary is closed, their zero
differential is constructed directly. Otherwise cancellation resumes from
the saved partial complex. This works in both recognition and raw homology;
it requires the standard backend, minfill, bits, and race=1. It is distinct
from `--no-reduction`, which disables Reidemeister simplification.

`--reduction residue` predicts eagerly and is retained for comparison;
`--reduction standard` remains the default. The switch counters and ordinary
work counters are recorded in scan evidence. Dense two-term test complexes
benefit greatly, but eager prediction slows ordinary diagram scans, and no
general recognition or complexity improvement is claimed. See
[`../synthesis/radical.tex`](../synthesis/radical.tex) for the correctness proof,
the adaptive policy, and the incoming report's stronger hypotheses.
Run `python benchmark_residue.py --output results/residue_local.json` to
compare standard, eager, and adaptive modes with paired controls.

The later dense-algebra report adds a verified homogeneous multiplication path
inside component contraction. Inputs of a single dot degree use a binary subset
transform with a cardinality filter; products in the top degree use a packed
complementary-subset inner product. Mixed inputs retain the ranked transform.
The current scanner's erased quantum shifts were recovered and checked on 520
scans (196,928 entries). This also sharpens the article's sufficient sharing bound.
Use `benchmark_homogeneous.py` and `audit_grading.py`, each with `--output FILE`,
to reproduce the local measurements and checks. The same contraction options
apply; the default sparse engine is unchanged.

The mixed-degree synthetic matrices in the original adaptive benchmark cannot
be genuine scan differentials. `benchmark_adaptive_graded.py --output FILE`
adds dense scalar matrices satisfying the recovered grading constraint, with
local adaptive gains of 2.7–58.5×. These are still synthetic complexes, not a
claim that the current crossing order produces that density. Ordinary forced
component scans show mixed timing results, so these measurements do not justify
changing the default engine. Full proofs and results are in
[`../synthesis/homogeneous.tex`](../synthesis/homogeneous.tex).

Report 08 adds complete recognition for checked source braids on at most three
strands. `Diagram.from_braid` and braid JSON retain validated provenance, so the
pipeline uses a linear symbolic decision before the Seifert stage. The raw-word
API `braid_certificate(strands, word)` avoids PD construction. For more strands,
the initial stage supplies a writhe obstruction; optional checked endpoint
destabilization runs after the cheaper diagram and structural tests.
Use `--no-braid`, `--braid-backend matrix`, or `--no-braid-reduction` to control
these stages (API: `use_braid`, `braid_backend`, `use_braid_reduction`). A PD-only
input never acquires an unchecked source word. `to_json(preserve_braid=True)`
explicitly retains provenance; default JSON stays PD. The specialization does
not give a general quasi-polynomial algorithm.

`benchmark_braid.py` measures fresh diagram construction plus recognition
against the current Seifert-enabled pipeline with braid dispatch disabled.
The local nine-round data in `results/braid_integration_20261007.json` show
3.30–4.89× gains on five scrambled three-braid unknots with default RIII enabled,
1.23–1.35× on positive three-braids, and 6.14× on the hard eight-crossing fixture.
A 256-strand stabilization control is about 2.8% slower. Import/startup and JSON
parsing are excluded; the script also records separate raw-word scaling.

Report 09 adds checked Gauss-interlacement factorization as the default visible
sum decomposition, with `connected_sum_factorization` certificate evidence.
Use `factor_backend="legacy"` or `--legacy-factor` for the historical cut traces.
The modular Alexander filter uses sparse elimination at 256 crossings and above;
its low-level API retains explicit `backend="dense"` and `backend="sparse"` choices.
Preprocessing and factorization now share the cooperative `UNKNOWN` resource
handler. Run `benchmark_factor_sparse.py --output results/factor_sparse_local.json`
for isolated paired kernel measurements.

```bash
python3 -m fastunknot recognize examples/trefoil.json
python3 -m fastunknot khovanov examples/conway_sum_8.json --shared
python3 -m unittest discover -s tests -v
```

Recognition accepts `--backend standard|shared|saturated|euler|shadow|closure|twist`
(with the barcode and fitting options described below). The default is
`standard`: sharing incurs overhead on prime examples that stay connected.
`shared` retains exact ranks and raw homological-degree counts. `saturated`
retains the final unreduced rank capped at three. `euler` adds an optional exact
suffix-Euler lower bound, controlled by `--euler-max-states` (default 4096).
A capped count of three means “at least three”; it is never an exact rank.
An early Euler result uses `rank_lower_bound_capped`, distinct from final
`rank_capped`. Exhausting the optional inference budget continues complete
saturated scanning; object/time exhaustion returns `UNKNOWN`.
The Euler backend begins with direct linear-time closure walks. After four
distinct queries at a stage, it prepares strand and zero-smoothing boundary
path summaries when the boundary has no more darts than the suffix has
crossings. Subsequent queries walk only these boundary summaries, computing
the exact raw Euler value as `(-1)**(n+c+c0) * 2**c`. Preparation remains
within the existing deadline and query budget; interrupted summaries are not
published. The query budget counts completed matchings. `ClosureEuler` and
the original `SuffixEuler` recurrence remain independent references.
The low-level `AdaptiveClosureEuler(compression_after=0)` forces eager setup
for diagnostics; public recognition uses the adaptive policy.
`python -B benchmark_boundary.py --output results/boundary_local.json`
separates repeated-query timings from complete scans and recognition.
See `../synthesis/boundary_reuse.tex` for the proof and measured limitations.
`euler_stats.prepared_stages` records the number of prepared stages.
`python benchmark_euler_setup.py --output results/euler_setup_local.json`
measures this setup separately from full recognition, with allocation peaks
measured outside the timing samples.
`python benchmark_euler_connectivity.py --output results/euler_local.json`
compares the raw Euler-assisted scans with the earlier recurrence implementation.

`--backend shadow` adds report 26's marked residue-four continuation bound.
It completes whole relative components with the actual suffix, recovers their
relative quantum shifts, and uses signed Tait determinants to evaluate four
Euler residues. A reduced rank lower bound above one certifies knottedness;
an inconclusive bound continues the exact scan. Only proper prefixes are
observed. A partial observation never certifies the unknot.

```bash
python -B -m fastunknot recognize examples/conway.json --backend shadow --shadow-max-work 1000000
python -B benchmark_shadow.py --output results/shadow_local.json
```

The Euler and determinant caches share `--euler-max-states`. The additional
`--shadow-max-work` allowance counts geometry visits, matrix allocation and
integer arithmetic updates (API: `shadow_max_work=None` removes this local
cap). Exhausting marked work switches to Euler-only observations using the
same exact cache and remaining shared query allowance. These direct Euler
walks are separately counted in `euler_fallback_traversed_darts`; they do not
reset or consume the spent marked-work counter. Exhausting the query cap then
continues the same saturated scan without observations. Global exhaustion
remains `UNKNOWN`. Thus `--shadow-max-work 0` permits Euler fallback, while
`--euler-max-states 0` disables all new completion queries.
`shadow_stats.observer_mode` reports `shadow`, `euler`, or `scan`; the result
also distinguishes `shadow_exhausted` and `euler_exhausted`. Completed
determinant values alone are cached, so interruption cannot publish a partial result. Early evidence
uses `reduced_rank_lower_bound_capped`, `stage`, and `shadow_stats`; the final
rank still uses `rank_capped`. The existing backend restrictions apply.
`python -B benchmark_shadow_fallback.py --output results/shadow_fallback_local.json`
compares the schedulers on complete raw scans and recognition, including low
budgets and supplied-order controls. See `../synthesis/shadow_fallback.tex`
for the exact resource contract, transition proof, and measurements.

Larger completed Tait graphs now factor at articulation vertices before dense
matrix allocation. Parallel signed weights are combined first; cancelled edges
may give a zero tree sum. Bridge blocks contribute their weights, and other
blocks use the existing exact Bareiss determinant. The original crossing phase
is retained, including loops. Cofactors through size 16 keep direct evaluation.
`shadow_stats` distinguishes `max_unsplit_cofactor_size` from the largest actual
`max_cofactor_size` and reports `tait_blocks`, `tait_bridge_factors`,
`tait_block_determinants`, `tait_disconnected`, and `tait_zero_factors`.
All work remains interruptible and locally budgeted; partial products are never
cached. `python -B benchmark_tait_blocks.py --output results/tait_blocks_local.json`
records actual observer traces and separates initial queries, raw scans, and
complete recognition. See `../synthesis/tait_blocks.tex` for the signed product
proof, cutoff measurements, and remaining complexity limits.

The default stays `standard`: earlier filters already decide many examples
where the raw marked scanner improves substantially. The paired benchmark
separates complete recognition from raw scanner timings. The theory and
validation are in `../synthesis/determinant_continuations.tex`. The common
terminal graph producer in `determinant_research/terminal_geometry_audit.py`
is a checked research prototype; production computes each completion directly.
The newer `determinant_research/boundary_tait.py` uses cut-face fragments and
boundary-only gluing checks, reusing a signed terminal kernel and partition
cache. Its audit agrees on 4,503 actual completions and checks another 3,468
arbitrary pairings. It remains research code: it imports the delivered kernel
and lacks production deadline/work accounting. Isolated repeated-query gains
do not establish a complete-recognizer speedup.

`--backend closure` adds report 28's classical closure bounds and
single-survivor resets. For a whole radical component with one matching, it
reads the scalar first-jet matrices and checks the actual remaining closure.
Pure coefficients also support bounds valid for all classical link closures.
A certified rank above two rejects the knot. When the entire scan has one
component copy and first-jet multiplier one with a knot completion, it splices
that matching into the remaining PD and restarts with fewer crossings. This
preserves total rank; it is not an isotopy certificate or a graded-homology API.

```bash
python -B -m fastunknot recognize examples/conway.json --backend closure --closure-max-work 1000000
python -B benchmark_closure.py --output results/closure_local.json
```

The local work allowance counts optional observer traversal, polynomial
extraction, binary rank operations and completion geometry. Exhaustion disables
observations and continues the current exact capped scan; global exhaustion
still returns `UNKNOWN`. API `closure_max_work=None` removes this local cap.
Evidence records reset events, `segment_stats`, and `closure_stats`, including
the actual maximum segment length `max_gap`. A general polylogarithmic bound
on this gap is unproved. An expanded 624-scan search found singleton resets
but no nonsingleton eligible blocks; algebraic tests cover the broader formula.
See `../synthesis/closure_resets.tex` for proofs, source-audit qualifications,
and separate full-recognition and raw-backend measurements.

Shared backends require minimum-fill pivots, bit algebra, no tail contraction,
and no racing. Incompatible options are rejected. `khovanov --shared` cannot
be combined with `--factor`. Backend selection only matters after enabled
earlier stages have failed to decide; use the disabling flags in the companion
article to isolate a backend deliberately.

The new functions live in `fastunknot.seifert`, `fastunknot.component_scan`,
and `fastunknot.euler_scan`. The Seifert APIs are also exported from `fastunknot`.
Public PD scanner functions assume a validated classical one-component diagram.
The permissive `Diagram(pd)` constructor does not validate this promise; use
`Diagram.from_pd` or the command-line loader.

The maintained article is [`../synthesis/report.pdf`](../synthesis/report.pdf),
with source in `../synthesis/structural.tex`; the delivered report remains in
`../reports/07/paper/`. Run `python benchmark_structural.py --output results/local.json`
for paired recognition timings and exact scanner checks against the integrated code.
`python benchmark_reduction.py --output results/reduction_local.json` isolates
the post-reduction check against the first integrated revision.

The companion article proves exactness and a finite-type complexity bound in
frontier size and actual connected-component size. **There is no general
quasi-polynomial complexity guarantee.** All 69 unit tests passed in the
recorded environment. The research archive includes proofs, raw timing samples,
source provenance, and a patch against the pinned ProveIt baseline.

## Inherited documentation and performance history

The following version-0.2 documentation is retained as the record of the
previous pipeline and measurements. Stage-order descriptions below predate
the new optional and structural stages just described.

# fastunknot 0.2: exact unknot recognition with a scanning Khovanov backend

**Status: exact, complete, and exponential in the worst case. The `n^O(log n)`
bound announced in Lackenby's February 2021 talk is NOT achieved here**, for the
reasons documented in the synthesized report (`../synthesis/`): the accelerated
hierarchy operations in the talk's final flowchart have no published
algorithmic specification with cost bounds.

Version 0.2 integrates the ideas of the nine acceleration proposals in
`../proposals/` that gave a measurable speedup. The 36-crossing braid closure
that version 0.1 abandoned after 600 seconds now takes under a second; full
recognition of the Conway and Kinoshita–Terasaka knots went from about 60 ms to
about 1 ms; a connected sum of three Conway knots from 58 s to 2.5 ms. A Rust
port is in `../rust/`.

## Pipeline

1. **Validation.** One component, spherical rotation system. Inputs: PD code,
   braid word, or rectangular (grid) diagram.
2. **Reidemeister I/II reduction**, incremental: O(1) work per move on a
   mutable dart structure, one revalidation at the end. (A search for
   Reidemeister III moves that unlock further I/II moves runs later, between
   steps 7 and 8, when no filter has decided.)
3. **Descending-diagram test**, linear time; sufficient for `UNKNOT`.
4. **Visible connected sums.** Two edges bordering the same two faces cut the
   diagram into summands. A sum is trivial exactly when every summand is, so
   the summands are examined separately, smallest first.
5. **Modular Alexander test.** The first Alexander minor at t = −1 and at a
   generic element of F_p, p = 2^61 − 1. For the unknot it is ±t^k; anything
   else certifies `KNOTTED`. O(n³) field operations.
6. **Modular Jones test.** The Kauffman bracket at a generic A in F_p by a
   frontier scan that merges partial states with equal boundary matchings.
   Cost is bounded by all perfect matchings of the scan
   boundary, `(w-1)!!` (no multiplicity factor). A Catalan bound requires
   a certified common disk boundary, which the current order does not supply. Skipped above 4096 frontier
   states. Rejects knots with trivial Alexander polynomial such as the Conway
   knot.
7. **Exact Alexander polynomial** over Z[t] (fraction-free Bareiss).
8. **Reduced Khovanov rank over F2** by Bar-Natan scanning with delooping and
   Gaussian elimination: bit-packed morphisms, compiled gluing plans, min-fill
   (Markowitz) pivots, units treated as involutions. `UNKNOT` iff the reduced
   rank is 1 (Kronheimer–Mrowka plus universal coefficients).

Every verdict is exact. Filters 5–7 can only say `KNOTTED`; agreeing with the
unknot's value is never evidence of triviality, and an exhausted filter budget
just skips the filter. Optional ceilings (`--max-objects`, `--seconds`) turn an
expensive step 8 into `UNKNOWN`, never into a knot verdict.

## Run

Python 3.10+, standard library only. From this directory:

```sh
python -m fastunknot recognize examples/conway.json
python -m fastunknot recognize examples/conway_sum_3.json --no-jones
python -m fastunknot recognize examples/hard_unknot_8.json --check-d2
python -m fastunknot khovanov examples/stress_braid5_36.json
python -m fastunknot khovanov examples/conway_sum_8.json --factor
python -m fastunknot jones examples/kinoshita_terasaka.json
python -m fastunknot alexander examples/figure_eight.json
python -m unittest discover -s tests -v
python ablation.py        # about 40 minutes: the LIFO rows hit their 300 s caps
python crosscheck.py 400  # default scanner against the generic and the 0.1 scanners on random closures
python ab.py HEAD         # interleaved A/B timing of the working tree against a git revision
python perf.py label      # sequential best-of-N timing with a control loop; see the caveat below
python cli_ab.py HEAD     # whole-process timing of the command line against a git revision
python hard_unknots.py    # scrambled unknot braids that no filter decides (pipeline timing inputs)
```

Exit codes: 0 for either exact verdict, 2 for invalid input, 3 for `UNKNOWN`.

Switches of `recognize`: `--no-reduction`, `--no-descending`, `--no-factor`,
`--no-alexander` (both Alexander stages), `--no-modular` (only the modular
one), `--no-jones`, `--jones-max-states N`, `--pivot {minfill,lifo}`,
`--algebra {bits,sets}`, `--tail N`, `--max-objects N`, `--seconds S`,
`--check-d2`. `khovanov` takes `--factor`, `--pivot`, `--algebra`, `--tail`,
`--check-d2`. `--algebra sets --pivot lifo` reproduces the 0.1 scanner.

## Input

```json
{"pd": [[1,4,2,5], [3,6,4,1], [5,2,6,3]]}
{"braid": {"strands": 3, "word": [1, -2, 1, -2]}}
{"rows": [[0, 2], [1, 3], [2, 4], [0, 3], [1, 4]]}
```

PD crossings are counterclockwise `[a,b,c,d]` with the under-strand `a-c`
(either under-port may come first). Grid rows are listed bottom to top;
verticals pass over horizontals. `{"pd": []}` is one crossing-free circle.

## Complexity

* Steps 1–5 and 7: polynomial in the crossing number n.
* Step 6: at most n · (w-1)!! · poly(w) field operations for scan width w.
  The older unconditional Catalan claim was refuted by report 09; it requires
  a certified disk frontier.
* Step 4 with step 8: if the visible factors have n_1, …, n_k crossings, the
  cost is poly(n) + Σ 2^O(n_i). Polynomial when every factor has O(log n)
  crossings; this is a restricted-class statement, not a bound for all diagrams.
* Step 8 in general: 2^O(n). The size of the complex after elimination is
  (number of boundary matchings) × (a multiplicity that grows with the
  homology of the partial tangle); no subexponential bound is known or claimed.

## Test and benchmark status (last observed 18 September 2026)

* `python -m unittest discover -s tests`: 41 tests, OK (about 9 s; one test starts race processes), about 3 s (CPython
  3.14.4, Windows 11). 19 are the 0.1 tests (three expectations updated because
  a filter now decides before Khovanov does), 22 are new and compare every new
  code path with the 0.1 implementation.
* `results/benchmark_0.1.json` is the 0.1 benchmark, kept as a record; its
  36-crossing 5-strand row is the 600 s timeout that motivated 0.2.
* `results/ablation.json` is the per-idea ablation (see the report). It takes
  about 40 minutes because the LIFO configurations on the stress case run into
  the 300 s cap; shorten the list in `ablation.py` if that matters.
* `python crosscheck.py 400 7`: 400 random braid closures (2 to 5 strands),
  ranks by degree of the default scanner (with `tail` 0 to 2 and `check_d_squared`
  on every fourth) equal to those of the generic scanner, 0 mismatches.
* **Timing caveat, learnt the hard way on 18 September 2026.** On this desktop
  the speed of pure Python drifted by more than a factor of two inside a single
  one-minute run (background applications, clock throttling): a fixed control
  loop went from 5.3 ms to 12 ms. Sequential before/after runs of `perf.py` are
  therefore not evidence. `perf.py` times that control loop next to every case
  and marks a run `SUSPECT` when the control spreads by more than 10%; three
  rows of `results/perf_log.json` are flagged as contaminated. Use `ab.py`,
  which times old and new alternately in one process (`results/ab_log.json`).
  Its first criterion, "interquartile range of new/old entirely below 1", was
  too lenient and **gave false claims in both directions**: a change confined
  to order selection, which is 0.2 to 1.8% of the affected scans and was
  measured on its own as 32 to 58% faster with identical output, was reported
  as 14% slower on one input and 4% faster on another. `ab.py` now also times
  the old code twice per round (an A/A control; on mid-sized scans identical
  code differed by 20 to 30% between adjacent runs) and claims a difference
  only if the order-statistic 95% confidence interval of the median excludes 1
  and the median lies outside the A/A interquartile range. `python ab.py OLD
  NEW` compares two revisions; the earlier "7 to 13% on small scans" claim
  below was re-tested that way and holds (0.87 to 0.92, intervals within
  0.87..0.95; no claim on the large scans). Deterministic counters are immune to this, but each
  sees only part of the work: `stats["compositions"]` counts elimination work
  and `stats["entries"]` the differential entries written while adding
  crossings. Neither alone predicts time: on the 41-crossing 4-strand closure
  the scan order with the fewest compositions (1565 against 4164, equal peak
  size) was not the faster one.
* Measured and left unchanged (deterministic counters, ranks identical in every
  variant). Pivot rule: the product cost (out-1)(in-1) with last-in-first-out
  inside a cost bucket is best or within 2% on four inputs; first-in-first-out
  needs 64% more compositions on the stress case and the sum cost is worse on
  all four. Scan-order selection: scoring greedy orders by the sum of
  2^(boundary/2) selects the same start crossing as the current (maximum,
  total) rule on all four inputs. On the 31-crossing 6-strand closure another
  start needs a tenth of the compositions, but its boundary profile is worse
  than the selected one, so no boundary-based score can find it. On the stress
  case 16 of the 36 greedy starts finish within 4 s; starts 14 to 16 tie for the
  least work (23710 compositions) and the default, which scores every third
  start, selects 15. The score is a fragile predictor: start 0 has profile
  (8, 230) against the winners' (8, 226) and needs 895182 compositions, 38
  times more, with 2.6 times the peak size.
  Scoring all greedy starts instead of 12 was tried on 40 random closures (25 to
  39 crossings, 3 to 6 strands; work = entries + compositions): a different
  order in 18, of which 8 with equal work, 6 cheaper, 4 dearer, ratios from
  0.29 to 6.69, total 0.952. Not adopted: the total is carried by three inputs
  and would change sign without one of them. The weak point is the score, not
  the number of starts. A matchings-only simulation cannot replace it: the
  38-fold gap above occurs at equal boundary size (at most 14 matchings), so it
  is all multiplicity, i.e. homology of the partial tangle.
* Where the transfer work goes (four inputs): 74 to 83% of the differential
  entries are incident to a cancelled pair when it is cancelled (an
  overestimate, since fill-in entries are counted but not in the denominator).
  Only 30 to 53% of the cancellations are between the two smoothings of one old
  object, the kind that could be predicted before writing any entries; the rest
  are between different old objects.
* Outside the scanner (`ab.py`, strict criterion, against c9572d2): the modular
  Alexander filter now evaluates only the nonzero matrix entries, at most three
  per row (`recognize T(3,61)` 0.60, interval 0.53..0.67; `recognize conway`
  0.92); the boundary profile of a greedy scan order is tracked inside the
  greedy in O(1) per step and a candidate start is abandoned once it cannot
  win (`scan chain256` 0.78, interval 0.73..0.82). Both are output-preserving:
  same determinants, and identical greedy orders, profiles and selected orders
  on 600 random diagrams (19993 start orders, 34 diagrams with loop edges).
* The Jones frontier scan now uses the interned matchings and strand-following
  gluing of `planar.py` instead of a union-find over labels per transition:
  0.67 (interval 0.46..0.72, 10 rounds) on the 36-crossing closure, where the
  scan is a few milliseconds. **No measurable effect on any `recognize` case of
  the corpus**, including the Conway knot, which this filter decides: with 11
  crossings the filter is a small part of 0.6 ms. Output-preserving: identical
  return values on 500 random closures (350 witnesses with equal bracket, peak
  states and transitions; 122 inconclusive; 28 identical budget failures; 48
  diagrams with loop edges). `filters._glue` is kept as the reference.
* The Alexander matrix is now built by sparse rows (`alexander_rows`); the dense
  `alexander_matrix` of the exact path derives from it, and the modular filter
  fills a zero matrix directly, evaluating each distinct entry polynomial once:
  `recognize T(3,61)` 0.69 (interval 0.62..0.72) on top of the 0.60 above, no
  claim on the small diagrams. Output-preserving: dense matrices, filter
  results and exact polynomials identical on 500 random closures (35 with
  kinks, where entries of one row coincide and can cancel).
* **Cross-stage plan cache (`shape_cache`, on by default; a trade-off, not a free
  win).** Every crossing brings new edge labels, so a per-stage cache never
  hits across stages, yet a long braid compiles the same few pictures at every
  crossing (at boundary 6 there are 5 matchings, and about 35 transfer plans
  were compiled per crossing of T(3,n)). Transfer plans are now also cached
  under a label-independent key (matchings and crossing slots relabelled by
  rank). This is sound because relabelling by rank is monotone and the circle
  numbering is by minimal label whichever matching is walked first (tested on
  random matchings, and on 20000 pairs while developing). Reuse: 80% of the
  plans of T(3,11), 94% of T(3,31), 72% of T(4,9), 99% of the kink chain, 38%
  and 19% of the random 3- and 4-strand closures, but 1% of the stress closure
  and 0% of the Conway knot, Kinoshita-Terasaka and Conway#Conway. `ab.py`,
  three runs agreeing: `scan T(3,11)` 0.61 (interval 0.59..0.66), `scan
  chain256` 0.78, `scan braid3_40` 0.97; **`scan conway` 1.06 (interval
  1.04..1.07 with 301 pairs) and `recognize hard_unknot_8` 1.07, slower**; no
  claim on the large scans. The cost was decomposed by timing partial variants
  against HEAD (A/A 0.999): ranking the boundary each stage +1.5%, building the
  key and looking it up +3.0%, storing +1.3%. Two explanations I had offered
  first were wrong and are recorded as such: hashing of nested tuples
  (interning shapes as integers changed nothing) and the cyclic garbage
  collector (same ratio with it disabled). Inlining the lookup changed nothing
  either; `shape_cache=False` restores the old speed exactly (1.003).
  **Correction, same day.** I first wrote here that an automatic switch was
  impossible, having tested one predictor: an early hit count predicts the
  wrong way (inputs that profit get their first hit after 35 to 150 lookups,
  the stress closure gets 12 hits in its first 64 and then none). A different
  predictor works. A plan can only be reused in a stage whose picture (the
  position of the four crossing slots among the boundary points, up to monotone
  relabelling) occurred before, and that is known from the scan order alone:
  `ordering.repeated_stages` gives 0 for the Conway knot, Kinoshita-Terasaka
  and Conway#Conway, 1 of 36 for the stress closure, 4 of 31 and 11 of 41 for
  the 6- and 4-strand closures, 16 of 40 for the 3-strand closure, 16 of 22
  for T(3,11). `shape_cache=None`, now the default, turns the cache on when the
  diagram has at least 16 crossings and at least an eighth of them repeat.
  Transfer and composition *results* are shared across stages as well, but only
  after the first plan-shape hit of the scan, since before that a shared
  result cannot exist (ungated this cost a further 2.6%, intervals
  1.023..1.029). Against the code before any of this (1ca6a5d), 301 pairs:
  `scan T(3,11)` 0.505 (0.486..0.508), Conway 1.008 (1.005..1.010), hard
  unknot 1.007; `ab.py`: T(3,11) 0.51, `scan chain256` 0.81, nothing slower.
* **The exact Alexander polynomial is no longer computed after the modular test
  has passed** (`use_exact_alexander=None`; `True` or `--exact-alexander`
  restores it; with `use_modular=False` it still runs). It can only say
  `KNOTTED`, and only for a polynomial that is not a unit, which the modular
  test has just failed to see at two points; whatever it would have caught the
  exact scan decides anyway, so verdicts cannot change. The corpus had a single
  filter-undecided input, of 8 crossings, which hid this stage's cost:
  `hard_unknots.py` now generates scrambled unknot braids, about half of which
  survive R1/R2 with 15 to 27 crossings and pass every filter. On 26 of them
  the exact polynomial took a median 24% (up to 63%) of `recognize`. Over 720
  diagrams (600 random closures, 120 scrambled unknots) the two modes never
  disagree and the exact stage decided nothing once the modular test had
  passed. `recognize` on the 55 scan-decided scrambled unknots: faster on all
  55, median 0.81, range 0.53 to 0.93; `ab.py`: 0.62, 0.84, 0.85 on three of
  them, `hard_unknot_8` 0.86. The evidence record says "not computed" instead
  of giving the polynomial and the determinant.
* A caveat on `ab.py` even with the strict criterion: that run flagged
  `recognize conway` as 1.05 slower (interval 1.005..1.254), a path this change
  cannot reach. 301 pairs gave 1.006 (1.000..1.015). With some 15 comparisons
  per run at 95%, expect an occasional false flag on sub-millisecond cases and
  confirm a flag with a few hundred pairs before acting on it.
* Tried and reverted: computing the fill-in terms of a pivot once per kind of
  source. Between 5 and 52% of the sources of a pivot share matching and value
  with another source (52% on the stress closure), so their terms coincide.
  With 151 interleaved pairs it was slower on every input: 1.075 (scrambled
  unknot, 25 crossings), 1.031, 1.043, 1.019, and 1.026 on the stress closure,
  all intervals above 1. Building the lists costs more than the sharing saves.
* `recognize` computes the greedy scan order once and hands it to both the Jones
  scan and the Khovanov scan, which used to compute the same order twice.
  Results identical to the previous code on 400 diagrams, evidence records
  included. 151 pairs: 0.943 (0.923..0.964) and 0.945 (0.936..0.955) on two
  scrambled unknots of about 10 ms; on a 40 ms one 1.029 against an A/A of 1.019
  in the same run, i.e. no difference (the change removes about 0.7% there).
  That A/A reading is itself a lesson: the second run of the old code comes last
  in every round and can be biased by a percent or two, so compare a ratio with
  its own A/A, not with 1.
* Scan orders again, now on 81 diagrams (36 scrambled unknots, 45 random
  closures of 20 to 35 crossings) and with work = entries + compositions.
  The greedy rule breaks ties by crossing index. Breaking them towards the most
  recently touched crossing costs 1.09 (unknots) and 1.05 (random) of the
  current total; towards the longest-waiting one 1.52 and 1.57. Not adopted.
  Per diagram the ratios run from 0.01 to 28, better on about as many inputs
  as worse: the rules are incomparable, not ranked. A portfolio does not
  rescue this: the best of the three rules per diagram would need 0.31 of the
  work on the unknots and 0.74 overall, but running them interleaved until the
  first finishes costs three times the winner, 0.94 on the unknots and 2.2
  overall, because 8 of the 81 inputs carry 86% of the work and there the
  rules are within a factor two. Only a predictor would collect that prize.
* **Reidemeister III help for the reduction (`simplify(d, r3=True)`,
  `recognize(use_r3=True)`, `--no-r3`).** The scan is exponential in what the
  reduction leaves, and the reduction stopped wherever a Reidemeister III move
  was needed. A triangular face is a 3-cycle of the face walk through three
  crossings; it can be inverted iff some side is over at both ends; inverting
  it reverses the order in which each of the three strands meets the other two,
  a relinking of at most twelve darts that keeps every crossing's slots and the
  direction of both strands through it, hence its sign. When no I/II move is
  left, each such triangle is inverted on trial, kept if that creates a I/II
  move and undone otherwise (the move is an involution); triangles with no
  small face across a side are skipped, which never changes the result (2120
  diagrams, identical traces). Tested on its own: 150 random moves give valid
  spherical diagrams with the same Alexander polynomial, writhe and Khovanov
  ranks by degree, and a second move restores the dart structure exactly (300
  of 300). On 1500 random closures: never more crossings than I/II alone, no
  I/II move left, every trace replays, Alexander polynomial and Khovanov rank
  unchanged; 26% of the diagrams shrink further, 0.80 of the crossings remain.
  `hard_unknot_8` goes from 6 crossings to 0. Verdicts with and without it
  agree on 900 diagrams.
  *Placement matters.* Run with the first reduction it cost 58% on T(3,61), 20%
  on a random 5-strand closure and 4 to 6% on the Conway knot, inputs a filter
  decides a moment later. It now runs only after every filter has failed,
  just before the scan: no claim of any slowdown on those inputs, `recognize
  hard_unknot_8` 0.48, a scrambled unknot of 27 crossings 0.18.
  *Fewer crossings is not always less work.* One survivor was flagged 1.43
  slower, correctly: R3 help takes it from 22 to 20 crossings and its scan work
  from 2081 to 3277. Over the 54 of 117 survivors where crossings are removed
  (3.4 on average) the scan work is 0.43 of before, cheaper on 44 and dearer on
  10, per-diagram ratios 0.03 to 7.3; over all 117 it is 0.69.
* **Deeper III search, budgeted.** One move of lookahead left 117 unknot
  diagrams (of 40000 random closures) untouched; sequences of two moves, the
  second next to the first, reduce 97 of them to nothing, three moves 109, four
  moves 110, with no violation at any depth (no I/II move left, traces replay,
  Alexander polynomial and unknot rank preserved). A failing search is what
  costs: on T(3,61), full of triangles that lead nowhere, depths 1 to 4 take
  2, 10, 44 and 189 ms. Useful sequences are found early, so the search is
  introspective about its own cost: it deepens only while fewer than
  `r3_budget` trial moves per crossing have been made. Budgets of 5, 15, 40 and
  none give the same 97 / 109 / 110, while a budget of 5 caps the T(3,61) case
  at 10 ms. Defaults: depth 4, budget 10. With them only 15 of 60000 random
  closures are unknots that survive the reduction (largest: 16 crossings).
* **Introspective algorithm selection (the introsort idea), measured.** It
  works where a cheap signal separates the populations and switching is free,
  and three parts of the package now are of that kind: the shape cache chosen
  from the scan order, result sharing enabled by the first plan hit, and the
  budgeted deepening above. For scan *orders* it does not work with the rules
  at hand, in either form. (a) Run the default order under a work budget, on
  overrun restart with another tie-break rule, grow the budget: simulated
  exactly on the saved work of three rules on 81 diagrams, 27 policies, every
  one costs 1.4 to 4.8 times the default. Introsort can switch because heapsort
  has a guarantee and recursion depth signals degeneracy; here no rule has a
  guarantee, expensive is not degenerate (on the 8 inputs with 86% of the work
  all rules are within a factor two), and an abandoned scan is lost. (b) No
  restart: `add_crossing` does not mutate the previous stage, so tied greedy
  candidates can each be tried from the same state and the smallest real
  complex kept. With all trial work counted: 0.41 on the scrambled unknots
  (median per diagram 1.02, dearer on 21 of 36) but 1.44 to 1.52 on random
  closures, 1.40 to 1.47 overall. The size of the complex now does not predict
  the cost of the choice later.
* **Racing orders in parallel** is where that data does promise something: by
  wall clock on separate cores the race costs the winner's time, and the best
  of two rules is 0.75 of the default on the expensive inputs (single inputs
  0.07, 0.24, 0.30). Not in Python, though: a competitor must be a process, and
  starting one costs 30 ms bare, 76 ms with the package imported, 111 ms for a
  complete CLI scan of the trefoil, against scans that mostly finish within
  300 ms. So it was built in the Rust version (`../rust`, `--race N`), where a
  thread costs microseconds. Measured there on 40 random closures with single
  scans of 30 ms to 8 s: racing two orders takes 0.650 of the total time, three
  0.689; per input 0.05 to 1.68 (6.8 s becomes 0.34 s), faster on half and 10
  to 60% slower where the default order was best anyway. That premium is
  hardware contention, not the allocator: separate processes slow each other
  just as much as threads. Details in `../rust/README.md`.
* **A race in Python after all (`race=N`, `race_after=1.0`; `--race`,
  `--race-after`; off by default).** Dismissing it because a process costs 0.1 s
  to start compared that cost with the typical scan; but the race only matters
  on the heavy tail, where Python scans take seconds to minutes. So the default
  order runs alone for `race_after` seconds, and only then are other greedy
  orders (tie rules `oldest`, `recent`; `ordering.best_scan_order(ties=...)`)
  started as `python -m fastunknot _scan` processes with JSON over pipes (no
  `multiprocessing`, which on Windows imports the caller's main module again).
  The scanner polls them where it looks at the clock; the first to finish wins,
  the rest are killed, and rank and ranks by degree are the same whoever wins
  (tested, including a win of a competitor against a handicapped default order,
  and that no worker is left running).
  Measured on 26 random closures with single scans of 0.15 to 3.6 s, three
  interleaved rounds (`results/race_eval_python.json`): total 0.910 of single
  with two orders, 0.925 with three. What that total is made of: a competitor
  won on 2 inputs, 3.22 s to 1.74 s and 3.55 s to 1.56 s, in every round and
  under both settings; on scans of 1 to 3 s that the default order wins the
  race costs 10 to 20%, the hardware contention seen in Rust. The other
  per-input ratios are noise and the data shows it: 18 inputs finish inside the
  head start, where nothing is started and the ratio must be 1, and they read
  0.80 to 1.43. Measured properly (61 interleaved pairs on the 0.25 s stress
  scan) an armed race that starts nothing costs 1.010, interval 0.984..1.041,
  with the A/A control at 1.042: nothing. It is insurance against a bad order on
  long scans; use `race=2`.
* `hard_unknots.py`: the scrambled family turned out weak, since its rewriting
  consists of Reidemeister III moves and the helped reduction undoes all of
  it (120 of 120; 180 of 180 with heavier scrambling). `SURVIVORS` lists unknot
  diagrams of 11 to 16 crossings found by random search that survive I, II, the
  default III search and every filter; they are the honest scan-decided inputs.
* **Start-up: a whole command-line run takes 0.52 of the time** (`python cli_ab.py`,
  41 interleaved pairs of whole processes, `results/cli_ab_log.json`): `recognize
  conway.json` 115.5 to 60.9 ms (interval 0.510..0.541), `hard_unknot_8` 0.523,
  `unknot_braid40` 0.530, `khovanov trefoil` 0.523, and still 0.856 on the
  half-second stress scan. The bare interpreter is 29.5 ms of that, so the
  package's own start-up went from about 86 to about 31 ms; for a command-line
  user that is more than every scanner optimization above, which save well
  under a millisecond on such inputs. Where it went: `import fastunknot` took
  56 ms, 25 of them for `dataclasses` (it loads `inspect`, `re`, `dis`, `ast`,
  `tokenize`) used for five simple records, now written out by hand with the
  same constructors, equality, hashing, immutability and `repr` (and they
  pickle and deep-copy); 9 ms for `subprocess` and `json`, needed only when a
  race starts; 5 ms for `typing`, used only in annotations that are never
  evaluated; the 0.1 reference scanner, needed only by the ablation
  configurations, is imported on demand. Then `argparse`: 55 to 59 ms in Python
  3.14, where it loads `_colorize`, `dataclasses` again and `shutil`
  (`color=False` does not help). The options are now one table that feeds a
  small direct parser for the well-formed common case and, on demand, the real
  `argparse` parser for everything else (help, errors, abbreviated flags,
  `--flag=value`, values that look like flags), so messages and help are
  argparse's own; tests check that the two agree wherever the fast one
  accepts, and that start-up loads none of those modules.
  Two measurement notes. My first two whole-process comparisons showed "no
  difference" and were invalid: `python -m` puts the current directory first on
  `sys.path`, and both arms ran from the working tree, so the working tree was
  compared with itself; `cli_ab.py` runs each arm from its own directory and
  checks which package it imports. And the absolute milliseconds of different
  rows are not comparable: the same command read 61 ms and, ten minutes later,
  100 ms; only the paired ratio within a row is robust.
* Three small things found by profiling `recognize` on the Conway knot by
  cumulative time: the Jones filter's `Planar` paid for shape-cache bookkeeping
  it never uses (9% of the call); `simplify` rebuilt and revalidated the diagram
  even when no move applied (12%; an unreduced diagram now keeps its own edge
  labels, where the rebuild renamed them by first appearance, and `replay` does
  the same for an empty trace); `Diagram.alpha()` was recomputed seven times
  per recognition although the diagram is immutable (now cached with `faces`
  and `traversal`; callers get copies, the caches are not pickled and do not
  affect equality). `ab.py`, strict criterion, against 3a86e0c: `recognize`
  Conway 0.765 (0.733..0.794), T(3,61) 0.759, Conway#Conway#Conway 0.731,
  random 5-strand closure 0.865, hard unknot 0.896, scrambled unknot 0.906; no
  claim on the three scan-dominated survivors. Status, method, reduced size and
  rank identical to the previous code on 700 diagrams.
* The most common input, a reducible closure that the Alexander filter decides:
  `simplify` was half of `recognize` there, and half of that was
  `Diagram.from_pd` validating the rebuilt diagram from scratch. What the moves
  could break is the topology, so `rebuild` now checks that directly on the
  darts (one traversal through every crossing twice; the face walk closing into
  n + 2 faces) and builds the diagram from rows that are normalized by
  construction. Reduced diagrams and traces identical to the previous code on
  1500 diagrams in both modes; of 282 deliberately corrupted dart structures
  273 are rejected and the other 9 also pass the full validation (a random
  reconnection is sometimes a legitimate diagram). Also, the Alexander rows skip
  the polynomial addition when a slot is empty, the usual case. `ab.py`
  (strict): `recognize` random 5-strand closure 0.796 (0.772..0.831), hard
  unknot 0.913; no claim where nothing is reduced.
* Kept but not claimed: the face walk written out with bit operations in
  `move_at` (called 168 times in a typical recognition). Identical reduced
  diagrams and traces on 1500 diagrams; `ab.py` medians 0.98 to 0.99, every
  interval reaching 1.
* `tail` re-tested on the current scanner (41 interleaved pairs per input, 15 on the
  stress closure, ratio to `tail=0`, ranks by degree asserted equal): `tail=1`
  0.94 to 1.01 on eight inputs, the interval excluding 1 on two of them (Conway
  0.947, stress 0.971) and no A/A control behind it; `tail=2` 0.98 to 1.60;
  `tail=3` 1.03 to 3.04. The default stays 0, as after the 0.2 ablation.
* `seconds=` fidelity: the default scanner overshot a 1 s budget by up to
  0.24 s because a crossing was added without checking the clock; with a check
  every 512 objects the overshoot is at most 0.03 s on the same runs.
* Post-0.2 scanner work (commits 24b6111, 2e3fef7, e34c9e8), `perf.py` totals:
  1022 ms (0.2) to 602 ms (`FastScan`) to 412 ms (integer geometry). Those six
  runs predate the control loop; what supports them is that the one case the
  changes did not touch (`jones braid5_36`) stayed within 2.63 to 2.73 ms
  throughout. The later geometry refinements are 7 to 13% on small scans by
  `ab.py` and **not measurable on the large scans**. One idea was measured and
  rejected: queuing only the cheapest pivot candidate per source object cut
  queue traffic but raised compositions on the stress case from 29k to 42k.
* Same-machine comparison with the nine proposals:
  `../synthesis/data/proposals_bench*.json`.
* Pitfall for anyone writing random tests: a braid word of even length on an
  even number of strands induces an even permutation and never closes to a
  knot, so a "draw until one-component" loop with such parameters never ends.

## Layout

`fastunknot/diagram.py` (validation, braids, grids, signs), `simplify.py`
(incremental R1/R2, descending test, 0.1 versions as oracles), `ordering.py`
(heap-based greedy scan order), `factor.py` (visible connected sums),
`filters.py` (modular Alexander and Jones tests), `alexander.py` (exact
polynomial), `geometry.py` (matchings, gluing a crossing), `algebra.py`
(bit-packed cobordism algebra), `scan.py` (entry point `khovanov_rank` and the
generic scanner used by the ablation configurations), `scan_fast.py` (the
default scanner: list storage, interned matchings, bucket-queue min-fill),
`planar.py` (its integer geometry and compiled plans), `scan_reference.py` (the
0.1 scanner, unchanged), `recognize.py` (pipeline), `__main__.py` (CLI).
MIT-0, see the repository root.

The default planar algebra also short-circuits typed identities and scalar
squares over its square-free F2 ring. These identities agree with the original
cobordism evaluator; they do not apply to arbitrary morphisms or matrix blocks.
`benchmark_planar_shortcuts.py` records raw scan and separate scalar-kernel
timings. Ordinary scans showed negligible timing impact because most identities
are already removed by the scanner. Report 12's component contraction is now integrated as an opt-in production
option; the standard engine remains the default.

### Optional component contraction

Both `recognize` and `khovanov_rank` accept `composition="component"` (adaptive)
or `composition="component-dense"` (forced ranked subset convolution).
The CLI flag is `--composition`. This contracts morphisms through the connected
components of their compiled gluing plan without changing any differential.
On a boundary of `w` points the dense operation has `poly(w) * 2^(w/2)` bit cost;
the number of chain objects and operations still has no general quasi-polynomial
bound. Standard min-fill/bit scanning and `race=1` are required; shared backends
are not yet wired to this option.

```bash
python -m fastunknot khovanov examples/conway.json --composition component --check-d2
python -m fastunknot recognize examples/conway.json --composition component-dense
```

Earlier recognition filters still take priority. `composition_max_variables=18`
(CLI `--composition-max-variables`) caps component/output variables on selected
allocations. Recognition returns `UNKNOWN` if this limit is exceeded; the raw
Python rank API raises a resource exception. The CLI reports resource exhaustion
with exit code 3. `composition_stats` exposes actual use of the new method.
The advanced fresh-scanner installer is in `fastunknot.component_algebra`.

`benchmark_component_algebra.py` separates full raw scans from dense and sparse
kernel measurements. Local seven-round data show about 38× for independent dense
ten-variable products, 183× for nearly equal dense products using polarization,
and about 44× slowdown when a sparse ten-variable product is forced through the
dense method. None of the six ordinary scan cases selected an adaptive factored
call. Those results justify the explicit option, not a default switch. The raw
samples and A/A controls are in `results/component_algebra_20261007.json`.


### Optional twist compression

Report 11 is integrated through `--backend twist` or `backend="twist"`.
Existing cheap certificates and filters retain priority. After they fail, a
checked source braid is grouped into maximal equal signed runs and evaluated
using the exact reduced twist macro complex. Its complete uncapped bound is
`poly(n) * 2^O(t log(2+n/t))`, where `n` is the expanded crossing count and `t`
is the number of runs in the supplied word. This is quasi-polynomial for
`t = O(log n)`; there is no general conversion to such a presentation.

```bash
python -m fastunknot recognize examples/hard_unknot_8.json --backend twist
python -m fastunknot khovanov examples/trefoil.json --twist --check-d2
python -m fastunknot.twist examples/trefoil.json --mode estimate --profile
```

The direct Python rank entry point is
`fastunknot.twist_adapter.twist_khovanov_rank(diagram, budget=Budget(...))`,
with `Budget` from `fastunknot.twist`. Advanced signed-run homology and estimates
are available there too. Binary run exponents do not change the expanded-size
complexity convention. The main Diagram input still expects an explicit word.

PD and grid recognition fall back to the standard scanner when no checked
source braid exists. Proper connected-sum factors never inherit the original
source word: cheap factor tests run first, then unresolved factors defer to
one computation on the whole original braid. Such factors carry
`twist_deferred` evidence. The whole-knot rank is recorded only at the top level.
This preserves the restricted run-count bound for source-braid inputs.
The raw twist-rank API rejects missing provenance instead of falling back.

An exact Temperley–Lieb basis count precedes assembly. Recognition exposes
`twist_max_basis` (CLI `--twist-max-basis`, default one million); the raw `Budget`
also controls macro states, matrix bits, XORs, and time. Preflight and assembly
share a deadline. Exhaustion returns `UNKNOWN` in recognition and the CLI;
the production Python adapter raises `ScanLimit` or `MemoryError`. These
limits are separate from the ordinary scanner's object ceiling.

Raw degree output is converted to the original source braid's cube grading,
with `grading_diagram` and `source_crossings` identifying it explicitly. This
remains the original grading after whole-diagram simplification. Macro reduced
degrees are also retained. Assembly and degree-profile estimates report the
peak degree dimension, matrix-bit bound, and a degree-sensitive XOR-bit bound.

`benchmark_twist.py` compares raw homology against the production scanner,
including exact degree equality and A/A controls. The default recognition
pipeline often decides these inputs earlier; raw homology speedups are not
recognition speedups. The theory, restricted-family proof, integration details,
and benchmark limitations are maintained in `../synthesis/twist.tex`.

Local seven-round raw homology gains on two-strand twists are 31.6×, 134.7×,
and 574.4× at 51, 201, and 801 crossings. In a fixed four-strand context, a
single 801-letter block gives a 4.29× gain with peak degree dimension 177.
The alternating no-compression control is about 4.5× slower, and the Morton
four-strand unknot about 15.8× slower. Default recognition already decides the
long examples by the braid obstruction. Full inputs, degree counts, timing
boundaries, and A/A controls are recorded in `results/twist_integration_20261007.json`
and `results/twist_context_scaling_20261007.json`.

### Exact windows and bounded adaptive widening

Report 13's exact moving-window scanner is integrated. A window retains both
adjacent differential degrees and prunes irrelevant objects before allocation.
It can choose the mirror with the smaller proved object bound. The dedicated
command returns partial ranks, never an unknot verdict from a partial rank:

```sh
python -m fastunknot window examples/conway.json --lower 0 --upper 0 --normalized --auto-mirror
python -m fastunknot recognize examples/conway.json --window-radius 4 --window-seconds 0.1
```

Recognition's `--window-radius N` enables radii 0, 1, 2, 4, …, N before the
complete backend. Attempts share a per-factor time budget (default 0.1 seconds)
and object ceiling (`--window-max-objects`, default 20000), bounded by the
outer recognition limits. Widening restarts and reuses the last crossing order.
If less than twice the previous attempt's time remains, it proceeds to the
complete backend. Local resource limits also fall back; global exhaustion is
`UNKNOWN`. Any computed profile differing from the unknot proves knottedness.
Agreement remains inconclusive unless the window covers all raw degrees.

The Python API is `fastunknot.window_scan.khovanov_window(pd, lower, upper)`
or `fastunknot.window_bounds.khovanov_window_auto(diagram, lower, upper)`.
Endpoints and `by_degree` use raw cube degree. Normalized degree subtracts the
number of negative crossings in `Diagram.signs()`, not negative braid letters.
Both functions support `reduction='adaptive'` and the component algebra modes.
`recognize(..., window_radius=4, window_seconds=0.1)` enables the bounded probe.
The API's default `window_radius=None` leaves it disabled.

`benchmark_windows.py --output FILE` reproduces seven paired rounds with A/A
controls. The 36-crossing stress input drops from 17694 to 7692 peak objects;
a 10000-object limit changes `UNKNOWN` to certified `KNOTTED`. Widening on the
hard unknot is slower, so this policy remains optional. Earlier default
certificates already decide all six benchmark fixtures. Measurements are
fallback comparisons; the raw-window arm computes less than full homology.
The integrated suite passes 245 tests. Proofs, conditional query bounds, and
negative results are in [`../synthesis/windows.tex`](../synthesis/windows.tex).

### Interval normalization and graded scalar splitting

Report 14 adds optional exact-rank and capped-decision backends:

```sh
python -m fastunknot khovanov examples/conway.json --barcode
python -m fastunknot khovanov examples/conway.json --fitting
python -m fastunknot recognize examples/conway.json --backend fitting
```

`barcode` decomposes a whole component when it has one matching and one common
square-zero differential coefficient. `fitting` first searches for a bounded,
verified scalar change of basis exposing independent summands, then applies
interval normalization and sharing. By default its scalar blocks also preserve
recovered quantum shifts. Global budget exhaustion is `UNKNOWN`; local search
limits retain unresolved components. The standard backend remains the default.

The exact Python APIs are `barcode_khovanov_rank` in `fastunknot.barcode_scan`
and `fitting_khovanov_rank` in `fastunknot.scalar_split`. Their `_decide`
counterparts return rank capped at three, shortening whole intervals to length
two under the ordinary closure theorem. Decision output has no exact rank or
degree profile. A capped three means at least three, not exactly three. Exact
mode retains full lengths and degree counts. Both support `seconds`,
`max_objects`, supplied `order`, and `check_d_squared`; `fitting` additionally
supports `record_witnesses=True` and configurable local search limits.

These backends require min-fill pivots, bit algebra, no tail contraction, and
no racing. They are separate from `--reduction adaptive` and component kernels.
An exact window probe may fall back to them, but shortened decision models
cannot answer exact window queries. The explicit low-level comparison option
`preserve_grading=False` uses the archive's ungraded scalar search and does not
support the refined homogeneous checkpoint bound.

All 267 production tests pass. `benchmark_continuations.py --output FILE`
records paired timings, full-rank cross-checks, and replayable actual splits.
The five measured knot diagrams showed overhead and no nonsingleton interval
normalizations. A separately labeled graded synthetic component compresses
217 stored objects to seven in exact mode and two in decision mode. The
conditional checkpoint theorem no longer needs a bound on the original
connected component size; it still requires suitable frontier widths and
frequent pure stages. Proofs and limitations are in
[`../synthesis/continuations.tex`](../synthesis/continuations.tex).

### Verified rank-two braid preprocessing

`recognize(..., use_ranktwo=True)` or CLI `recognize FILE --ranktwo` enables
one deterministic AVL pass on a checked source braid, after cheap certificates
and before expensive descent and fallback. It replaces an optimal collection
of disjoint two-index subwords by equal empty or single-letter words. A separate
central-normal-form verifier replays the full transcript before its output is
used. These are context-safe braid equalities, not closed-braid equivalences.

Search and replay share `ranktwo_seconds` / `--ranktwo-seconds` (default 0.1).
A local limit skips the optional stage; a global limit remains `UNKNOWN`.
If the verified word beats the current diagram's crossing count, recognition
restarts with the shorter validated input, compression disabled, and the
remaining global budget. Other options are preserved. Evidence under
`before_ranktwo` and `after_ranktwo` records the distinct reduction branches.
The former includes the original source word and independently replayable
certificate. PD input without checked braid provenance bypasses the stage.

The low-level `fastunknot.ranktwo.compress` and `verify` functions also accept
explicit braid words. Recognition always uses one pass; the low-level default
`max_passes=None` instead iterates to saturation, with a weaker total bound.
The one-pass bound is deterministic `O(n log n)` word-RAM time, not a universal
quasi-polynomial knot-recognition guarantee. Flat rank-two inflations of small
cores do have a proved conditional recognition bound.

`benchmark_ranktwo.py --output FILE` reproduces seven paired end-to-end rounds,
including diagram construction and all existing certificates. Sleeve examples
improve by 3.4–33.8 times locally, while the stress five-braid slows down about
1.8 times. Default behavior is unchanged. The full suite passes 272 tests;
proofs, barriers, and measurements are in
[`../synthesis/ranktwo.tex`](../synthesis/ranktwo.tex).

### Minimal extremal windows and certified size bounds

The new optional strategy cancels the entire crossing extension before upper
truncation, including the temporary degree beyond the guard. This is distinct
from the default support strategy's pre-allocation pruning:

```sh
python -m fastunknot window examples/conway.json --lower 0 --upper 2 --minimal
python -m fastunknot recognize examples/conway.json --window-radius 2 --window-strategy minimal
```

The Python entry point is
`fastunknot.minimal_window.khovanov_minimal_window_auto(diagram, lower, upper)`.
It defaults to choosing the mirror with smaller raw upper depth. CLI mirror
selection requires `--auto-mirror`, as with other window queries. Results
always return original raw degree labels. `trace=True` records retained
matching/degree profiles. Ordinary, residue, and adaptive exhaustive reduction
and component composition are supported.

This strategy verifies a nice disc scan order: connected prefixes and suffixes,
consecutive attachments, no projection loop edges, and final closure. With no
supplied order it first checks the fast greedy order, then attempts a cubic
construction when needed. Failure withdraws the sharper complexity certificate;
the query still computes exact homology. All planning and temporary allocations
are covered by the query's resource limits.

A certified order of girth W gives retained degree-j counts at most binomial(t,j)
before closure, doubled at closure, and a uniform quasi-polynomial query bound
for raw upper depth O(log n) and W=O(log² n). Runtime checks verify these counts.
This bound does not apply to the existing support strategy, and a narrow interval
in the middle is not necessarily a shallow endpoint query. Partial agreement
still cannot certify an unknot. See
[`../synthesis/extremal.tex`](../synthesis/extremal.tex) for the domination proof,
cache accounting, external theorem attribution, and exact padding obstruction.

All 277 tests pass. `benchmark_minimal_windows.py --output FILE` compares exact
identical window queries on common supplied orders. Minimal mode is slower on
all six measured cases; it remains optional despite its stronger conditional
bound. These partial-query ratios are not end-to-end recognition speedups.

## Optional exact Potts Jones filters

`potts-faithful` decides whether the **entire normalized Jones polynomial is
one**, and can recover all its Laurent coefficients. It chooses
`q = 2^(4*n+2) + 2` from the crossing count, making the exact quadratic
specialization injective on the proved coefficient and degree bounds.
Canonical equality partitions avoid enumerating this large number of colors.
Combined with adaptive certified separator ordering, the uncapped query takes
`poly(n) * 2^O(sqrt(n)*log(n+1))` bit operations on every classical knot diagram.
This is a general subexponential **Jones computation**, not a general
subexponential recognition algorithm. Polynomial identity still yields
`INCONCLUSIVE` in the Jones filter and continues to independent recognition.

```sh
python -B -m fastunknot jones examples/conway.json --backend potts-faithful
python -B -m fastunknot recognize examples/conway.json --jones-backend potts-faithful
python -B benchmark_faithful_jones.py --output results/faithful_jones_local.json
```

The `jones` command also returns `jones_polynomial`, with variable `t=A^-4`
and sorted `[exponent, signed_hex_coefficient]` pairs. The Python API
`fastunknot.faithful_jones.faithful_potts_exact` returns `polynomial_identity`
and optionally reconstructs coefficients with `include_polynomial=True`.
Its default caps are 4096 states and 200000 transitions; pass `None` for both
to request uncapped work. The standalone `jones` command has no local caps
unless supplied. The color count is input-derived, so `--potts-colors`
does not override it. Shared budgets and global cancellation remain active
during ordering, evaluation and recovery. The shared policy's mode name
`polynomial-tail` has a quasi-polynomial tail bound for this growing `q`;
that still preserves the stated subexponential bound.

Raw exact results contain Python integers. JSON-safe obstruction witnesses
encode color counts above 256 bits in `q_hex`, use a symbolic ring description,
and retain hexadecimal quadratic coordinates. Small color counts retain `q`.
These conversions do not change Python's global decimal-conversion limit.
Full theory, validation and measured costs are in
[`../synthesis/faithful_jones.tex`](../synthesis/faithful_jones.tex).

Full recovery now returns polynomial one immediately after the faithful pair
comparison proves identity, avoiding redundant normalization and decoding.
Paired full-query measurements show a 1.96x improvement on the 254-crossing tree
medial, with little change on most other inputs. Recognition already requests
identity alone, so this does not imply a recognition speedup. Run
`benchmark_jones_identity_shortcut.py --output FILE` to reproduce the comparison
against the preserved earlier decoder.

The independent [residual-twist audit](jones_research/README.md) finds a concrete
contradiction to the combined uniform-degree and geometric-realization claims
used in arXiv:2606.22410v1. It does not disprove Jones unknot detection. That
preprint is not used to promote polynomial identity to an unknot certificate.

`potts-adaptive` defers separator preparation until actual scalar work reaches
`64*n` transitions. If at most `2*ceil(log2(n+1))` crossings remain then, it
finishes the current table under a proved polynomial tail bound. Otherwise it
builds a certified order: an unchanged order continues without repeating work;
an improved order restarts once with the **remaining original transition
allowance**. State-cap failure can also request the one preparation. Completed
order certificates survive later scalar exhaustion; global interruption never
publishes an unfinished scalar or partial certificate.

```sh
python -B -m fastunknot recognize examples/conway.json --jones-backend potts-adaptive
python -B -m fastunknot jones examples/conway.json --backend potts-adaptive
python -B benchmark_adaptive_potts.py --output results/adaptive_potts_local.json
```

The Python API is `fastunknot.adaptive_potts.adaptive_potts_exact`. Its uncapped,
fixed-color query retains `poly(n) 2^O(sqrt(n))` bit complexity, while easy
queries avoid separator construction entirely. Result `ordering_policy` records
the actual path, discarded work and total transitions. In ordinary or
polynomial-tail mode, the later homology fallback receives no separator-width
promise. This remains a one-sided scalar filter, not a complete subexponential
recognizer.

Measurements include all preparation and retain both the initial policy and
its source. The short-tail rule improves the initial policy 1.415x on the
100-crossing grid but regresses on a shuffled 16-crossing grid. Other supplied
orders finish after adaptation where ordinary/eager queries hit state caps;
those are censored comparisons, not timing speedups. Ordinary exact Potts
remains faster on some inputs, and no consistent full-recognition advantage
over it is established. See
[`../synthesis/adaptive_potts.tex`](../synthesis/adaptive_potts.tex).

`potts-separator` first constructs and verifies a balanced separator hierarchy,
then chooses the smaller frontier of its order and the existing greedy order.
For every closed classical projection it guarantees `O(sqrt(n))` crossing
frontier. At fixed color count, the uncapped exact scalar query therefore has
`poly(n) 2^O(sqrt(n))` bit complexity. This is a general subexponential **scalar
evaluation**, not a general subexponential unknot recognizer: equality is
inconclusive and the fallback's surviving homology objects remain uncontrolled.

```sh
python -B -m fastunknot jones examples/conway.json --backend potts-separator
python -B -m fastunknot recognize examples/conway.json --jones-backend potts-separator
python -B audit_separator_orders.py --output results/separator_orders_local.json
```

The Python API `fastunknot.separator_potts.separator_potts_exact` accepts
`max_states=None, max_transitions=None` for an uncapped query. Its
`order_certificate` is checked by
`fastunknot.separator_order.verify_width_bounded_order(diagram.pd, certificate)`.
The same certificate builder, `width_bounded_scan_order`, can supply an order
to any existing scanner. Verification uses graph partitions and frontier counts;
it does not call the planar-map constructor. It does not certify common-disk
prefixes. A completed certificate survives local scalar exhaustion; a later
crossing-changing reduction rebuilds it before homology. Preparation remains
subject to the global deadline.

This option adds ordering overhead and is not the default. The retained audit
checks 114 inputs with independent union-find logic. On tree-medial stress
diagrams, a 1,022-crossing frontier drops from 256 to 18; on the grid examples,
greedy remains better. A 62-crossing matching query improves 24.6x excluding
preparation, while exact Potts already handles those trees cheaply. No complete
recognition timing improvement is established. See
[`../synthesis/separator_orders.tex`](../synthesis/separator_orders.tex).

`recognize --jones-backend potts-exact` uses integer pairs in
`Z[x]/(x²−(q−2)x+1)`, with six colors by default. The
`potts-exact-factorized` option keeps processed Tait components separate until
an edge joins them. `potts5` supplies a modular five-color comparison; it
misses a proved infinite weaving family even without modular collisions.
The exact six-color filter detects that family. Equality at any chosen
specialization remains inconclusive and continues the complete fallback.
The existing `matching` filter remains the default.

Use `--potts-colors 7` to choose another exact color count (integer ≥5), and
`--jones-max-states` / `--jones-max-transitions` for local work limits.
A state limit counts represented keys, not total memory. Local exhaustion
falls through; the global recognition deadline returns UNKNOWN.
Standalone examples:

```sh
python -m fastunknot jones examples/conway.json --backend potts-exact
python -m fastunknot jones examples/conway.json --backend potts-exact-factorized
python -m fastunknot recognize examples/conway.json --jones-backend potts-exact
python -B check_potts_independent.py /tmp/potts-independent.json
python -B benchmark_potts.py --output results/potts_local.json
```

The standalone Jones command returns an inconclusive result and exits 3 on
resource exhaustion, 2 for invalid options, and 0 on a completed query.
Exact witness pairs use signed hexadecimal strings for large-integer JSON
safety. Raw evaluator APIs retain integer pairs.

The same-color benchmark measured a 23.6× factoring gain on a fixed fragmented
order (4,111→205 peak keys), but factoring slowed all six other kernel cases.
Normal recognition with the single-table exact option was about 1.14–1.15×
faster on Conway and Kinoshita–Terasaka in this small run; earlier certificates
bypassed the new filter in the other five cases. These observations do not
justify an automatic switch or a default change. See the complete theory,
limitations and measurements in [`../synthesis/potts.tex`](../synthesis/potts.tex).

## Adaptive transfer on certified disk frontiers

`--reduction disk-adaptive` adds a full finite radical transfer after sparse
cancellation pauses and the existing cheap residue shortcut declines. It keeps
nonzero maps between adjacent surviving degrees. Geometry is certified from
the actual processed rotation system and checked against live matching types.
A local work guard can decline the attempt; the unchanged partial complex then
resumes ordinary cancellation. Global deadlines still produce UNKNOWN.

This option works with full homology, recognition, either window strategy, and
component coefficient composition, under the existing adaptive scanner
restrictions. Evidence reports actual transfer calls, geometry declines, budget
fallbacks, and transfer work. The local allowance counts cooperative polls,
not elementary bit operations or total memory. It is an experimental policy,
not a competitive scheduling guarantee. `standard` remains the default.

```sh
python -m fastunknot khovanov examples/conway.json --reduction disk-adaptive
python -m fastunknot recognize examples/conway.json --reduction disk-adaptive
python -m fastunknot window examples/conway.json --upper 2 --reduction disk-adaptive
python -B check_disk_geometry.py /tmp/disk-audit
python -B benchmark_disk_transfer.py --output results/disk_local.json
```

Dense synthetic blocks gained up to 4.08× while retaining nonzero survivor maps;
the sparse control avoided transfer altogether. None of the four ordinary
diagram benchmarks made a full-transfer call, so no recognition speedup follows.
The [theory section](../synthesis/disk_transfer.tex) covers certificates, finite
perturbation, rollback, cost accounting, and explicit unknot diagrams whose raw
frontier is Ω(√n) in every order. The latter limit an order-only approach, not
recognition with simplification and structural certificates.

## Exact long-twist profiles and streamed homology

The additive RLE frontend `python -m fastunknot.twist.continuation input.json`
accepts `{"strands": 3, "runs": [[1, 1001], [2, -1], [1, 1], [2, -1]]}`.
It checks the original knot component count and evaluates structural
certificates directly on run counts. `--mode homology --method tail` computes
an exact reduced homological profile using a finite reference at run length
`W+2`, where `W` counts the fixed context crossings. Longer exponents produce
a constant interval plus finite exceptional degrees, without expansion.
The returned degrees are macro degrees; quantum grading is forgotten.

`--method streaming` instead retains two adjacent state layers and feeds
columns directly into elimination. It reduces storage but was slower in all
eight measured full-homology cases. In recognition it may stop when finalized
reduced homology already exceeds one, explicitly reporting an incomplete
homology and a rank lower bound. A partial rank-one result never proves UNKNOT.
`--method macro` retains full assembly. The existing main CLI and production
`backend="twist"` defaults are unchanged.

The ordinary recognizer has a separate opt-in `--braid-profile` flag
(`use_braid_profile=True`) for a checked source word. It specializes the
existing Seifert graph criteria, with the established PD/Artin sign conversion.
The original source remains distinct from any connected-sum factors.

The largest measured tail gain was 58.6× for exact homology; dominant-run knots
were already structurally decidable, so this is not a new recognition family.
The profile option gained 2.30–3.33× on selected fresh prebuilt homogeneous braid
diagrams. See [TWIST_CONTINUATION.md](TWIST_CONTINUATION.md) for schemas,
budgets and examples, and [the theory section](../synthesis/twist_continuation.tex)
for proofs, output-size limits, independent audits and timing scope.


## Checked rational and Montesinos presentations

`Diagram.from_rational(e, tangles)` now builds and validates a Montesinos
numerator closure, retaining checked source provenance. The recognizer uses
an exact arithmetic decision before the general diagram pipeline; disable it
with `use_rational=False` or `--no-rational`. JSON uses
`{"montesinos":{"e":0,"tangles":[[2,3],[-2,-2,-1,-2]]}}`.
The decision preserves each rational summand's denominator and handles
nontrivial determinant-one knots. Arbitrary PDs have no inferred source.

For binary coefficients too large to expand, `montesinos_certificate(e,tangles)`
provides a separate arithmetic-only API. The ordinary constructor and CLI
still build the actual PD, with a default 100,000-crossing expansion ceiling.

`recognize_with_subtangles` in `fastunknot.tangle_obstruction` optionally
searches a small literal-pattern catalogue in an arbitrary validated PD.
Each rejection verifies a four-port disk occurrence and its non-embeddability
in an unknot. No match falls back to the ordinary recognizer. This wrapper
was slower in all five measured cases and remains explicit.

See [RATIONAL.md](RATIONAL.md) for APIs, provenance and certificates,
[rational_research/README.md](rational_research/README.md) for reproducible
checks, and [the theory](../synthesis/rational.tex) for arithmetic bounds,
full-complex barriers and performance scope. These are polynomial procedures
on supplied presentations or fixed local patterns; general quasi-polynomial
recognition remains unproved.


## Quantum-ordered full transfer

`--reduction graded` and `--reduction graded-adaptive` are optional exact
policies for the standard scanner. The first computes the full differential
between scalar survivors using quantum-ordered transfer. The second retains
completed sparse pivots and switches only when the per-stage Schur-update
allowance is exhausted. Unlike a survivor-count shortcut, both retain nonzero
maps between adjacent surviving degrees. They do not require a common-disk
certificate. The standard policy remains the default.

The Python `khovanov_rank` and `recognize` APIs accept the same reduction names.
Bit coefficients, minimum-fill pivots, self-inverse cancellation and one scan
order are required. Component coefficient composition and tail finishing are
supported; homological windows and alternative scanners are rejected before
early recognition certificates. Global resource failure remains `UNKNOWN`
in recognition. The replacement graph is fully prepared before installation,
so transfer failure preserves the current differential.

See [graded_research/README.md](graded_research/README.md) for reproducible
checks and measurements and [the theory](../synthesis/graded_transfer.tex)
for the finite-transfer proof, cost accounting and unresolved multiplicity
bounds. The new full suite has 426 passing tests. The report's remaining proposals are reviewed in
[the symbolic continuation section](../synthesis/symbolic_runs.tex).


The run frontend now transports huge integer values and degree keys using exact
hexadecimal strings, accepts either signed runs or an explicit word, and
supports independent replay of serialized structural certificates. Use
`fastunknot.integer_codec.decode_degree_profile` after a JSON round trip.
The earlier total-rank law at context length plus one is documented and audited;
the full-profile computation keeps its context-length-plus-two reference.
All 431 maintained tests pass. See [TWIST_CONTINUATION.md](TWIST_CONTINUATION.md)
for the extended schema and [the theory](../synthesis/symbolic_runs.tex) for
succinct complexity and the conditional repair-DAG research target.


### Survivor corridors and bidirectional adaptive transfer

`--reduction corridor` preserves full graded transfer while pruning paths
that cannot reach an output survivor and choosing propagation direction per
component. `--reduction corridor-adaptive` first spends the existing sparse
Schur-update allowance and retains completed pivots before switching.
Both are optional; `standard` remains the default. The supported backend,
coefficient, tail and resource contracts match the graded full-transfer modes;
window combinations are rejected. Direct controls also expose sparse scalar
components and Boolean endpoint selection.

The 458-test maintained suite passes. Independent audits check 3,885 transfer
comparisons on 555 prefixes, all eight contraction identities at each prefix,
and entrywise equality of sparse versus packed scalar maps. The constructed
shared-suffix family proves a near-linear complete stage versus quadratic
forward propagation at fixed algebra size; it does not prove a knot-prefix
family or superiority to sparse cancellation. See
[corridor_research/README.md](corridor_research/README.md) for measurements,
commands and limitations, and [the article](../synthesis/corridor_transfer.tex)
for proofs and complete setup accounting.


## Certified cyclic Garside preprocessing

Report 25's exact source-braid compressor is available with `--garside` or
`recognize(diagram, use_garside=True)`. It shares exact Garside prefix states
across cyclic cuts, independently replays the proposed equalities, and restarts
recognition only when the candidate improves the current simplified diagram.
Cheap modular Alexander and structural obstructions run first; Jones follows
the probe. The optional probe has a local time/operation
allowance; exhausting it resumes the established exact pipeline under the
remaining global budget. Original source-branch evidence and PD reductions stay
separate, and backend/reduction options survive the restart.

The default radius is one; `--garside-radius 2` adds two-letter targets.
The default caps are `--garside-seconds 0.1`, `--garside-max-ticks 100000`, and
`--garside-max-targets 100000`. The probe is disabled by default. See
[`garside_research/README.md`](garside_research/README.md) for reproduction,
resource semantics and measurement scope. The theory article derives the
polynomial fixed-radius compressor bound and a conditional small-core theorem;
it does not claim a general sub-exponential unknot algorithm.


## Compressed surface-cover geometry

`fastunknot.surface_cover` maintains report 24's classifier for supplied
binary-encoded dihedral covers of bordered surfaces. `CoverIndex` provides
component and boundary-lift queries, exact signatures for ordered marked fibre
points, and evaluation of rooted equivariant maps. Classification uses at most
three unmarked family records; all arithmetic is polynomial in the input bit
length without expanding sheets. Hexadecimal JSON and cooperative cancellation
are supported. See [`cover_research/README.md`](cover_research/README.md) for
input examples, proofs, audits and separate geometric benchmarks.

This module is not called by knot recognition. Presentation extraction, full
external attachments and hierarchy search bounds remain unproved integration
steps. Even a one-type cyclic annulus cover has `W` inequivalent ordered pairs
of marked points, so efficient marked comparison alone does not bound the
number of possible hierarchy states. The theory is maintained in
[`../synthesis/surface_covers.tex`](../synthesis/surface_covers.tex).


### Binary-state faithful Jones backend (8 October 2026)

The optional `spin-faithful` backend uses one orientation bit per cut edge,
a checked integral turning cochain, and an injective integer encoding of the
full Jones polynomial. With its certified separator order and caps/deadlines
disabled, it computes the full polynomial in `2^O(sqrt(n))` deterministic
bit time. A polynomial different from one certifies knottedness; polynomial
one continues to the independent recognizer.

```sh
python -B -m fastunknot jones examples/trefoil.json --backend spin-faithful
python -B -m fastunknot recognize examples/conway.json --jones-backend spin-faithful
```

Python callers can use `spin_jones_exact(diagram, include_polynomial=True,
max_states=None, max_transitions=None)` from `fastunknot.spin_jones` for an
uncapped query. Default local caps are 4096 states and 200000 transitions;
cancellation callbacks remain available. The turning certificate validates
local geometric weights, not a claimed completed contraction. Serialized
large scalars and coefficients use hexadecimal strings.

This integrates the Jones component of `unknot_recognition_research_20261008.zip`
from commit `1be2abc8c`. Its historical benchmark data and ordering-policy
correction remain distinct from the maintained integration measurements.
See `spin_jones_research/README.md` for provenance and the synthesis article's
binary-tensor chapter for the proof. Measured regressions justify retaining
the existing default. The other newly delivered research components remain
under component-level review; the synthesis records their current status.


The spin backend now defaults to **valuation arithmetic**: each frontier integer
is stored as an odd signed mantissa and a separate power of two. This removes
monomial padding exactly, including signed cancellation and carries. Python
callers may pass `arithmetic="shifted"` to compare the original representation.
Both modes produce the same exact final scalars, polynomials, states and
transition counts. The existing `max_coefficient_bits` includes represented
full integers and final normalization; `max_frontier_mantissa_bits` and
`max_frontier_valuation` describe the compressed frontier representation.
The general Jones bound is `2^O(sqrt(n))`; its polynomial factor is absorbed.
For a separately supplied width `w`, retain `poly(n) 2^O(w)`.


### Adaptive faithful Jones queries

The optional `faithful-adaptive` backend gives faithful Potts at most `128*n`
transitions, then switches to binary spin if Potts reaches that work allowance
or its state cap. Both attempts share the caller's transition limit; discarded
Potts work, including internal reordering, is counted. A completed separator
order is reused. With caps/deadlines disabled, the default policy retains the
`2^O(sqrt(n))` general full-Jones bound.

```sh
python -B -m fastunknot jones examples/trefoil.json --backend faithful-adaptive
python -B -m fastunknot recognize examples/conway.json --jones-backend faithful-adaptive
```

The Python API is `adaptive_jones_exact` in `fastunknot.adaptive_jones`, with
`include_polynomial=True` for full recovery. `potts_trial_transitions=None`
selects the default trial; zero selects spin directly. A custom larger trial
has its own cost. Result `transitions` counts all attempts, `selected_backend`
identifies the winner, and `backend_policy` records the switch and discarded
work. Large witnesses use the backend-specific hexadecimal encoding. Polynomial
identity remains inconclusive for recognition and continues to Khovanov.
The overall default Jones backend remains unchanged.

### Polynomial scalar projectors and local-algebra stopping

The optional `primary` Khovanov backend extends Fitting splitting with exact
polynomial idempotents from Berlekamp's fixed algebra. It can split an invertible
candidate whose stable kernel is zero. Every accepted split checks the whole
typed differential and every transformed attachment.

```sh
python -B -m fastunknot recognize examples/trefoil.json --backend primary
python -B -m fastunknot khovanov examples/trefoil.json --primary
```

Python callers select `fitting_primary=True` in `fitting_khovanov_rank` or
`fitting_khovanov_decide`. The existing object, variable and candidate caps apply.
A failed candidate ordinarily leaves the component unchanged. If the candidate
has minimal-polynomial degree equal to the *complete* commutant dimension and
one-dimensional Frobenius fixed space, the entire scalar algebra is local.
Then no scalar idempotent exists and the remaining trials are safely skipped.
This says nothing about simplification by more general cobordism operations.

The experimental `fitting_reuse_commutant=True` option transports complete child
spaces inside one static compression pass. Canonical bases preserve the fresh
solver's candidate sequence. Reuse stops at a differential change and remains
off by default: measured transport overhead exceeds the saved child solves.

The local-algebra stop improves complete compression on the supplied algebraic
fixtures, but the five tested knot scans never invoke the primary path. The
main default backend is unchanged, and no general quasi-polynomial recognition
bound is claimed. Source-pinned measurements, negative results, proofs and the
748-test validation are in `../synthesis/primary_continuation.tex` and the PDF.

### Checked two-meridian recognition

`--two-meridian` enables a bounded exact stage after the invariant filters and
before optional group search or Khovanov. It derives all Wirtinger arcs from
one or two original meridians using signed crossing relations, then checks
**every original relation** by exact integer SU(2) arithmetic. Both `UNKNOT`
and `KNOTTED` answers include a replayed certificate. A failed seed search or
local limit is inconclusive and resumes the existing pipeline.

```sh
python -B -m fastunknot recognize examples/hard_unknot_8.json --two-meridian
python -B benchmark_two_meridian.py --output results/two_meridian_local.json
```

Python callers can use `recognize(diagram, use_two_meridian=True)` or the
standalone `two_meridian_decide` and `verify_two_meridian_certificate` from
`fastunknot.two_meridian`. The standalone function returns a dictionary;
pass its `certificate` to the verifier together with the same validated PD.
The certificate includes the PD hash, seed arcs, acyclic derivation, all
relator normal forms and the final gcd/parity calculation. Replay does not
repeat seed search; it shares the parser and integer arithmetic with the
producer. It cannot verify a factor's certificate against the original whole
connected sum.

The pipeline controls are `two_meridian_seconds=0.05`,
`two_meridian_max_work=2_000_000`, and `two_meridian_max_attempts=10_000`, with
corresponding hyphenated CLI options. In the standalone API those names are
`seconds`, `max_work`, and `max_attempts`. Preparation, all failed seed attempts,
arithmetic and replay share one local allowance. Global cancellation still
propagates. Weighted work is a cooperative metric, not a hard bit-time or
memory limit. Python callers can set all three caps to `None` for exhaustive
search over the at-most-two-seed class.

Uncapped, the standalone stage is a complete polynomial algorithm for **diagrams admitting
such a seed derivation**; the conservative bound is `O(n^4 log(n+2))`. It gives
no general quasi-polynomial recognition guarantee. The full pipeline must
also pay for its earlier invariant filters, including Jones; those costs are
outside this standalone bound. The report's multi-seed
formula compiler and minimum-degree propagation are not part of this stage.
The theory, proof obligations, validation and full-pipeline comparison with
the existing compressed-group incumbent are in
[`two_meridian.tex`](../synthesis/two_meridian.tex) and the updated article PDF.
The stage remains opt-in.

### Endpoint patterns and exact overlap cutoffs

The compressed-group word engine now tries short endpoint patterns after the
existing uniform, short-period, sparse-letter and two-largest-overlap shortcuts.
Patterns of lengths 1, 2, 4 and 8 can describe a complete arithmetic progression
of candidate suffix/prefix overlap lengths even when individual letters are
dense. An exact period check makes matching monotone along that progression;
backward doubling and bisection locate the last matching candidate. Short
exceptional overlaps are checked individually.

This handles binary-sized periods and multiplicities without expanding the
words. A failed structural check retains the complete occurrence-table matcher.
All attempts use the existing arena's work, node and cancellation controls;
exhaustion never means that no overlap exists. Only complete answers enter the
cache. New counters use `lcs_anchor_`; the previous shortcuts and their counters
remain intact. The public recognition defaults and certificate formats are
unchanged.

This improves a restricted class of exact compressed-word queries. It does not
bound the number of relator moves needed to recognize arbitrary knots. See
[`endpoint_clipping.tex`](../synthesis/endpoint_clipping.tex) for the proof,
validation and comparison against the previous maintained matcher.

Endpoint Markov descent now uses the original-position linked-list kernel from
report 34 for sufficiently large, connected-closure-sized inputs (at least 64
strands and 128 letters). Small inputs retain the version-1 path. Both paths
perform the same elementary moves; the new version-2 certificate records local
inverse cancellations and singleton endpoint deletions using original letter
indices. Its independent verifier replays those choices without endpoint search.
Old version-1 certificates remain supported.

On an explicit one-component braid with `n` letters and `m` strands, adaptive
descent takes `O(n+m)` word operations, including generation and replay of new
certificates. A deletion queues at most one newly exposed seam, every original
letter is removed at most once, and left renumbering uses a single offset.
Small-path work is also linear on this domain because its rank or length is
bounded by fixed dispatch thresholds. Sparse standalone link inputs retain the
legacy behavior and its `O(n*m)` upper bound. This changes neither the sufficient
endpoint criterion nor the general unknot complexity bound. The separate matrix
three-braid backend retains its quadratic bit-arithmetic term. See
[`braid_descent.tex`](../synthesis/braid_descent.tex) for proof and measurements.

### Compressed three-braids and singleton forests

`fastunknot.compressed_braid` accepts a binary Artin-word grammar:

```python
from fastunknot.compressed_braid import Builder, recognize, verify

b = Builder()
u = b.power(b.word([1, -2]), 1 << 512)
root = b.concat(b.concat(u, b.word([1, 2])), b.inverse(u))
data = b.data(root)
result = recognize(data)
assert result['status'] == 'UNKNOT' and result['verified']
assert verify(data, result['certificate']) == 'UNKNOT'
```

The general input has exactly `strands`, `rules`, and `root`. Rule zero is
`["e"]`; subsequent rules are `["g", signed_generator]` or `["c", left, right]`
with strictly earlier references. The represented object is that word's braid
closure. It is not a certificate of conversion from a separate PD diagram.
The builder shown above is for three strands; the general forest interface
also accepts directly supplied grammars with arbitrary strand count.

Given sufficient resources, the three-strand algorithm is complete and
polynomial in grammar bit size. It uses the maintained exact string kernel,
checks closure components and exponent sum, then reduces the quotient
`C2 * C3` without expansion. Independent replay checks source binding and
local reduction equalities without repeating prefix searches. General
strand counts first detect missing generators, then split singleton-generator
connected sums. Factors with at most three strands are completely decided without expansion.
Wider factors that pass the Bennequin bound now use a complete reduced F2
Khovanov cube when their binary expanded length is within
`fallback_max_crossings=12`. Larger residuals remain `INCONCLUSIVE`.
Version-two forest certificates bind the expanded word to the exact source
projection and replay checked XOR elimination traces without pivot discovery.
The Frobenius complex builder is shared by discovery and replay. Legacy
version-one proofs retain their original residual semantics.

Public `recognize` includes replay. `verify` independently returns the certified
status or raises. Defaults share 10,000,000 abstract work units and 100,000
cumulative string nodes across all factors and replay.
`fallback_max_generators=200_000` similarly counts all reduced cube generators
cumulatively, including replay; `resources["cube_generators"]` reports usage.
Set `fallback_max_crossings=0` to disable this fallback. Both fallback controls
have hyphenated CLI flags. Additional controls are
`max_input_rules=100_000`, `max_input_bytes=16_000_000`,
`max_certificate_bytes=64_000_000`, `seconds=None`, and a `check` callback.
Limits are cooperative, not hard process-memory or CPU limits. Exhaustion
returns `INCONCLUSIVE` without a partial proof. An unsupported wider forest
can instead return `INCONCLUSIVE` with a verified residual certificate;
`verified=True` alone never means unknot. External cancellation propagates.

```sh
python -B -m fastunknot.compressed_braid recognize input.json
python -B -m fastunknot.compressed_braid verify input.json --certificate proof.json
python -B compressed_braid_research/audit.py --output results/native_audit.json
python -B benchmark_compressed_braid.py --output results/native_benchmark.json
```

The CLI recognizer prints the complete result; pass its `certificate` member
to the verifier's proof file. CLI input files have byte limits before parsing.
The ordinary explicit braid API remains the default for explicit words.
On the measured conjugation sleeves at exponent `2**16`, compressed recognition
including replay is about 118 times faster for the unknot and 14 times faster
for the nontrivial knot. Small explicit controls remain substantially faster
with the explicit API. The source-bound theorem, proofs, measurements and
limitations are in [`compressed_braid.tex`](../synthesis/compressed_braid.tex).


With sufficiently large allowances, the complete grammar algorithm takes
`poly(g) + sum_i 2**O(kappa_i)`, where `g` is grammar bit size and `kappa_i`
is the minority-sign count only of unresolved wider singleton factors.
It therefore has a restricted quasi-polynomial guarantee when those counts are
`O(log(g)**2)`. This does not bound them on arbitrary diagrams. The proof,
certificate trust boundary and validation are in
[`exceptional_cube.tex`](../synthesis/exceptional_cube.tex). Reproduce the
cross-oracle audit and the splitting ablation with
`python -B compressed_braid_research/exceptional.py audit --output FILE` or
`benchmark --output FILE`. Whole-cube comparisons include proof construction
and replay; planar-scanner timings have no such certificate and are labeled
separately.


The forest now prepares finite leaf summaries and tries finite exponent tests
first, compressed three-braid decisions second, and wider fallbacks last.
It stops on the first proved nontrivial factor. A version-three
`knotted-factor` certificate binds that single witness to its exact source
interval and proves the whole connected sum nontrivial. An unknot still needs
all factor proofs in their original order. `factor_order` reports discovery
order; it is diagnostic metadata, not part of the mathematical proof.

For a small wider factor, the fallback first performs the existing verified
free/cyclic cancellation and endpoint Markov descent. A resulting three-braid
uses the compressed exact terminal; a still-wider residual uses its complete
cube. Progress is recorded in a source-bound `exceptional-reduction-v1` child.
No progress retains the direct cube. The explicit crossing preflight still
happens before expansion. Set `use_fallback_reduction=False` (CLI
`--no-fallback-reduction`) to disable only this pre-cube step; priority and
selective negative proofs remain enabled. Verification supports old and new
proofs irrespective of how the producer was configured.

This avoids cubes for reducible wider factors and avoids unfinished factors
after a complete negative witness. It retains the same exceptional-factor
asymptotic bound. See [`adaptive_forest.tex`](../synthesis/adaptive_forest.tex)
for soundness, proof compatibility, resource accounting and paired measurements.


### Sparse two-meridian seed discovery

The optional two-meridian stage now reuses generation-stamped closure arrays.
When the crossing rules have no productive unary implication, every generating
pair must be a productive binary prerequisite pair. Only those `O(n)` pairs
need examination. A proper failed closure also rules out every later candidate
pair it contains. Productive-unary systems retain complete pair enumeration.
Both paths preserve the first successful seeds and exact derivation trace;
the arithmetic, certificate schema and search-independent verifier are unchanged.

This improves seed discovery from cubic to quadratic word operations on the
checked trivial-singleton class, with linear search storage. It does not reduce
every term in the complete stage's conservative arithmetic bound. Exhaustive
seed failure remains `INCONCLUSIVE`, and the ordinary pipeline remains opt-in
through `use_two_meridian=True` or `--two-meridian`. New statistics describe the
search mode, candidate count, excluded pairs and visited closure incidences.
All preparation, attempts, arithmetic and replay share the original allowances.
See [`sparse_seeds.tex`](../synthesis/sparse_seeds.tex) for the proofs and native
measurements, and `two_meridian_research/README.md` for reproduction commands.

### Certificates for supplied normal surfaces

The native normal-surface adapter can now record source-bound topology proofs:

```python
from fastunknot.normal_surface_orbits import normal_surface_topology
from fastunknot.normal_surface_verify import verify_normal_surface_certificate

result = normal_surface_topology(triangulation, coordinates,
                                record_certificate=True, max_cycles=100000)
if result['status'] == 'COMPLETE':
    verified = verify_normal_surface_certificate(
        triangulation, coordinates, result['certificate'], max_operations=1000000)
```

Both calls reconstruct the finite connected orientable manifold with one torus
boundary and check the normal vector. Replay verifies three complete orbit
traces and a finite boundary-cohomology witness without rerunning either search.
It checks components, orientability, boundary curves, Euler characteristic,
connected-surface genus/crosscaps, and whether the supplied surface is a
compressing disc. These claims concern the supplied triangulation; the API
establishes no correspondence with an input knot diagram and performs no
normal-vector search.

The default remains count-only. `max_cycles` is shared across production
queries; incomplete production emits no certificate. Replay's `max_operations`
cap covers the sum of trace events; exceeding it returns `False` (unverified).
Malformed evidence returns `False`, malformed source geometry raises
`NormalOrbitError`, and external cancellation exceptions propagate. Use
`fastunknot.integer_codec.json_safe` before JSON serialization of huge integers.
See [`normal_certificates.tex`](../synthesis/normal_certificates.tex) for the
proof, scope, independent comparisons and performance measurements.

### Common normal-coordinate multiplicity

`normal_surface_topology` now defaults to `reduce_multiplicity=True`. After
validating the full source, it divides out the coordinate gcd and runs the
three orbit queries on that quotient. If its component counts are `O`
orientable and `N` nonorientable, scaling by `k` gives
`k*O + (k//2)*N` orientable components and `(k%2)*N` nonorientable components.
Boundary circles and Euler characteristic scale by `k`. This handles one-sided
components: doubling a Möbius band produces one annulus.

Every topology field still describes the original input. When reduction
occurs, `coordinate_divisor` identifies the scale and `queries` contains the
actual quotient-search statistics. The proof then uses
`normal-surface-topology-v2`; replay checks exact divisibility and reconstructs
the quotient queries without searching for a gcd. The boundary witness and
source digest remain tied to the full input. Version-one proofs remain valid.
Use `reduce_multiplicity=False` for the former direct queries and proof format;
empty and primitive inputs retain their prior output structure.

See [`normal_multiplicity.tex`](../synthesis/normal_multiplicity.tex) for the
sheet-cover argument, bit complexity, old/new proof compatibility and paired
measurements. The optimization reduces work on repeated surfaces; normal
vector discovery and knot-exterior provenance remain separate obligations.

### Prepare compressed forest factors on demand

Compressed-braid recognition now builds a cheap factor schedule from the source
DAG, then projects and summarizes each factor only when it is visited. It keeps
finite/exponent obstructions ahead of three-strand factors and wider fallbacks.
A child-span-intersection upper bound replaces actual projected grammar size as the secondary
scheduling key. This estimate changes discovery order, never proof validity.

Global source and knot-component checks still run first. A negative proof needs
one fully prepared, independently replayed summand; a positive proof still needs
all factors in original strand order. One-strand projections now return their
exact canonical empty grammar directly. Existing certificate formats are unchanged.
Set `use_lazy_factors=False` or use the compressed-braid CLI's `--eager-factors`
flag to retain eager preparation and its former ordering. All work remains under
the shared public allowances. See [`lazy_forest.tex`](../synthesis/lazy_forest.tex)
for the scheduling proof, cost limits, compatibility audit and complete-call
measurements, including positive controls that need every factor.

### Compact component permutations

Compressed forest validation now evaluates only root-reachable permutations.
For more than eight strands, it stores moved points sparsely and switches to
dense tuples when a product moves more than half the strands. Dense descendants
remain dense. Every supplied rule is still validated, including dead rules;
the missing-generator guard still runs before strand-sized allocations; the
exact global component check still precedes factor recognition.

This changes no public options or certificate fields. On 402 audited sources,
all public result fields match the pinned prior implementation, and certificates
replay in both versions. Complete recognition on the measured 64-factor forest
with a finite obstruction improves from 188.472 to 89.181 ms; its separately
measured root-summary peak traced allocation falls from 8,194,752 to 1,714,252
bytes. Small controls have no consistent gain. These are supplied-grammar
measurements, with no new general unknot complexity claim.

See [`compact_permutations.tex`](../synthesis/compact_permutations.tex) for the
composition proof, storage policy, dictionary-cost assumptions and limitations.
From this directory, reproduce the native comparisons with:

```sh
python -B compressed_braid_research/permutations.py audit --output ../synthesis/data/compact-permutations-audit.json
python -B compressed_braid_research/permutations.py benchmark --output results/compact_permutations_20261008.json
```

The benchmark pins the entire old compressed-braid package at `d0f0e37761b5`,
measures complete public calls with mandatory replay, includes identical A/A
controls and a dense-storage ablation, and records source hashes and raw inputs.
Memory measurements run separately from elapsed-time samples.

### Shared cyclic overlap search with a bounded prelude

Explicit relator-overlap search now defaults to an adaptive policy. It tries
long donors first, retaining the maintained donor-length and full-match cutoffs.
After `O(L log(L+1))` charged prelude work it switches to report 46's exact shared
capped suffix-link index. Here `L` is the total **explicit** relator length.
At most four nonempty slots retain the previous pairwise query. Local handoff
keeps the original global budget; global exhaustion and cancellation propagate.

The exact query bound improves from `O(s + m*L)` to `O(s + L log(L+1))` dictionary
operations for `s` original slots and `m` nonempty relators. This is a local bound
under the stated dictionary-cost model, with no general recognition theorem.
Tied maximum-gain witnesses may change. The existing explicit and compressed
certificate replayers remain unchanged and verify the complete source-bound trace.

The low-level `fastunknot.relator_overlap.overlap_move` accepts
`backend='adaptive'`, `'pairwise'`, or `'joint'`, and optional `stats={}`. Ordinary
recognition still uses the existing `use_group=True, group_relators=True`
opt-in, or `--group-relators` on the CLI. The new index is invoked only for explicit overlap queries reached by
that stage, including explicit fallback queries from compressed search.

The native study checks 1,140 complete recognition calls on nineteen diagrams.
Gordian has paired old/new ratios 1.238 with explicit search and 1.120 with
compressed search. Small and repeated-word queries can be slower; the joint
index alone is also slower on Gordian. See
[`joint_overlap.tex`](../synthesis/joint_overlap.tex) for the capped-tree proof,
pruning and budget argument, bit-cost qualifications, baseline reconciliation,
independent replay audits and all controls.

From this directory:

```sh
python -B cyclic_overlap_research/native.py audit --output ../synthesis/data/joint-overlap-audit.json
python -B cyclic_overlap_research/native.py kernels --output results/joint_overlap_kernels_20261008.json
python -B cyclic_overlap_research/native.py pipeline --output results/joint_overlap_pipeline_20261008.json
```

The driver loads the actual maintained baseline at `bec1afd07cd2` and the delivered
report in separate modules, verifies source hashes, and retains source words,
diagrams, certificates, work counts, warmups, shuffled raw samples and A/A controls.

### Optional boundary classification for normal surfaces

`normal_surface_topology(triangulation, coordinates, classify_boundary=True)`
now separates closed components from components with boundary and gives the
orientable and nonorientable counts in each class. Existing base counts can
eliminate zero, one, or both additional interval-cone queries. For an even
common coordinate factor, counting touched components of the doubled quotient
is enough; the unknown boundary partition of the primitive quotient is not
claimed. Every returned count concerns the original supplied vector.

With `record_certificate=True`, this option produces a source-bound
`normal-surface-topology-v3` proof. The independent verifier reconstructs
markings, replays every supplied cone and justifies omitted queries without
calling the search planner. Cycle and proof-event allowances cover all queries.
The default option is false and preserves the earlier result/proof formats.

The independent audit checks 548 surfaces against Regina and report 47, including
closed orientable and nonorientable components. This is a supplied-normal-vector
operation, with no new vector search, PD provenance, or general unknot bound.
It does not determine whether a disconnected surface contains a compressing disc.
See [`normal_boundary.tex`](../synthesis/normal_boundary.tex) for the covering,
coning, multiplicity and adaptive-query arguments and measured performance.

From this directory (the audit requires Regina):

```sh
python -B normal_orbit_research/boundary.py audit --output ../synthesis/data/normal-boundary-native-audit.json
python -B normal_orbit_research/boundary.py benchmark --output results/normal_boundary_20261008.json
```

The driver compares adaptive classification with the same implementation forced
to compute both cone counts, includes identical A/A controls and production plus
independent replay, and separately checks the smaller default feature against
the actual baseline at `ce180ce1e640`. Timed calls reconstruct all geometry.

### Source-bound compressed primitive-power terminals

The optional compressed group search now tests report 45's minimum Christoffel
width when it reaches two live generators. One shared prefix-height scan can
certify that a current relator is a power of a primitive free-group word.
The new version-five certificate retains the full source diagram and verified
move prefix and uses an explicit `terminal` field. Independent literal and
compressed checkers reconstruct that state before checking the arithmetic.
Knot-group torsion-freeness and abelianization then justify the positive verdict.
The arithmetic query alone is not a knot decision for an arbitrary presentation.

`compressed_certificate(..., primitive_power=False)` retains the old search and
rank-one terminal. Ordinary recognition reaches the new rule through the existing
`group_compressed_search=True` / `--group-compressed-search` opt-in. Explicit search
and its adaptive representation handoff retain their prior terminal contracts.

All 29,540 audited cyclically reduced words agree with the literal Whitehead/root
oracle and report 45; 844 are primitive powers. The 74-diagram audit produces 44
new terminal records, all exponent one, and solves no previously stalled diagram.
All 974 tests pass. Whole-recognition timings on nineteen diagrams are mostly
unchanged; Gordian's paired old/new ratio is 0.998 despite a small work reduction.
No proper-power activity, broad speedup, or general quasi-polynomial bound is claimed.

See [`primitive_power.tex`](../synthesis/primitive_power.tex) for the arithmetic
proof, source-bound topological implication, version contract, local cost and
complete measurements. From this directory:

```sh
python -B primitive_power_research/native.py audit --output ../synthesis/data/primitive-power-native-audit.json
python -B primitive_power_research/native.py benchmark --output results/primitive_power_pipeline_20261008.json
```

The timing driver loads the actual old group host, search and replay modules at
`cd77d1bee8fa`, includes full recognition and proof replay, and retains A/A controls,
exact certificates, work and node counts, raw samples and source hashes.


### Optional raw primitive-pair projections

`--group-primitive-projection` enables report 45's disjoint higher-rank
primitive-pair contractions. Each complete round substitutes quotient images
into every relator, retains original slots, and has independent literal and
compressed replay. Version-six certificates also support raw one-generator
zero-exponent endpoints. An explicit normalization move marks the handoff
back to legacy search when raw projection stalls.

Library options are `compressed_certificate(..., primitive_projection=True)`,
`group_decide(..., primitive_projection=True)`, and
`recognize(..., use_group=True, group_primitive_projection=True)`. The group
host enables compressed search and mandatory proof replay. The earlier
`group_adaptive` option is mutually exclusive with this mode. Defaults retain
the previous version-five policy.

The 981-test suite passes. A pinned 79-diagram audit finds 34 projected
certificates with 158 pair contractions, all passing both source replayers,
with no gained or lost positives. Raw balanced algebraic fixtures contract
255 pairs in eight rounds with normalization and expansion disabled; these
fixtures are not knot diagrams. A general short-depth producer is still
missing, so no general subexponential or quasipolynomial bound follows.

All 570 whole-recognition benchmark calls completed. Projection mode is about
5–8% slower on ordinary corpus unknots; Gordian has no reliable gain. It
therefore remains opt-in. See
[`primitive_projection.tex`](../synthesis/primitive_projection.tex) for the
quotient proof, raw-round bound, noisy controls, and full measurement scope.

```sh
python -B primitive_power_research/projections.py audit --output results/primitive_projection_audit_20261008.json
python -B primitive_power_research/projections.py benchmark --output results/primitive_projection_pipeline_20261008.json
```


### Optional unit-coordinate primitive forests

`--group-primitive-forest` extends the projection route with acyclic batches
whose primitive donor roots solve a chosen generator as an integer power of
another. Donors may share generators. The producer composes shared parent
power circuits, substitutes into every original relator slot and emits a
version-seven certificate. An independent checker validates the entire forest
before replay. Cycles, duplicate children/slots and non-unit children are
rejected; general overlapping primitive pairs do not justify this operation.

Use `compressed_certificate(..., primitive_forest=True)`,
`group_decide(..., primitive_forest=True)`, or
`recognize(..., use_group=True, group_primitive_forest=True)`. The option implies
compressed projections and mandatory independent replay. It defaults to false;
existing default and disjoint-only modes remain available. It is mutually
exclusive with the older `group_adaptive` representation-switching option.

All 988 tests pass. The 80-diagram audit preserves both old modes exactly and
verifies every forest-positive proof through literal and compressed replay.
No additional diagram was solved in this sample. Abstract star, chain and
balanced presentations contract in one raw batch; the star family proves that
disjoint matching alone can require linearly many rounds. A forest batch has
polynomial encoded cost independent of tree depth, but this does not bound
general discovery, normalization or total search.

The 760-call whole-recognition benchmark still shows ordinary-corpus overhead.
A separate 150-call actual-circle group-stage benchmark reaches a 2.81x
paired speedup over the old default and 1.52x over disjoint projections at
128 crossings, including proof replay. These stage timings bypass earlier
diagram simplification and are not whole-recognizer gains.

See [`primitive_forest.tex`](../synthesis/primitive_forest.tex) for the proof,
source-bound replay contract, complete timings and their limitations.

```sh
python -B primitive_power_research/forests.py audit --output results/primitive_forest_audit_20261008.json
python -B primitive_power_research/forests.py benchmark --output results/primitive_forest_pipeline_20261008.json
python -B primitive_power_research/forests.py stages --output results/primitive_forest_stages_20261008.json
```


### Shared primitive planning

Projection and forest search now share one current candidate list. Structural
word eligibility and normalized unit vectors are cached by immutable root;
original relation slots and live generator membership are rebuilt each time.
Forest setup is skipped when fewer than two candidate slots exist, which
cannot support the existing two-edge batch threshold. Forest graph entries
are allocated only for encountered candidate generators.

The change preserves all 240 certificates/nondecisions in an 80-diagram,
three-mode audit against the previous package; every positive passes both
independent replayers. Another 2,000 raw-state planner comparisons agree.
All 992 tests pass. Existing options, proof formats and checkers are unchanged;
finite budget outcomes can differ when accounting or execution cost changes.
See [`primitive_planner.tex`](../synthesis/primitive_planner.tex) for the
amortized accounting, whole-recognition timings and separate stage timings.
All 760 complete-recognition and 200 checked-stage measurements finish.
Whole-call differences are small relative to controls; at 128 crossings,
the checked circle stage has paired speed ratios 1.07x for projections and
1.13x for forests over their prior implementations. The smallest stage
regresses slightly, so this is not a universal speedup.

```sh
python -B primitive_power_research/planner.py audit --output results/primitive_planner_audit_20261008.json
python -B primitive_power_research/planner.py benchmark --output results/primitive_planner_pipeline_20261008.json
python -B primitive_power_research/planner.py stages --output results/primitive_planner_stages_20261008.json
```

### Bounded-run normalization

The existing projection/forest normalization boundary now tries exact
run-length arithmetic on long roots whose every intermediate reduces to at
most four generator-power runs. Exponents stay binary; short roots retain
the general reducer. An unsupported probe builds no word nodes and falls
back. Compressed proof replay uses a separate implementation, with the
same certificate schema and full source reconstruction.

All 998 tests pass. An 80-diagram audit preserves 240 three-mode results,
and 87,381 short words agree with independent literal normalization.
The article proves closure under monomial substitutions and includes these
normalizations in the conditional phase bound; general short-depth discovery
and a general quasipolynomial recognizer remain open.

All 760 whole-recognition, 200 checked-stage and 240 kernel/replay timing
calls complete. Whole-call changes are within the control variation.
Conjugate kernels improve, but supplied-proof replay and unsupported-word
fallback regress. The article retains all measurements and explains these
limits; projection and forest modes remain optional.
See [`syllable_normalization.tex`](../synthesis/syllable_normalization.tex).

```sh
python -B primitive_power_research/syllables.py audit --output results/syllable_normalization_audit_20261008.json
python -B primitive_power_research/syllables.py benchmark --output results/syllable_normalization_pipeline_20261008.json
python -B primitive_power_research/syllables.py stages --output results/syllable_normalization_stages_20261008.json
python -B primitive_power_research/syllables.py kernels --output results/syllable_normalization_kernels_20261008.json
```

The follow-up skips entire raw-uniform subtrees using exact arena metadata
and stops as soon as an unsupported descendant forces fallback. Producer
and independent replay preserve the previous probe domain. Guarded tests
verify that neither uniform descendants nor irrelevant siblings are read.
All 1,000 maintained tests pass; all 240 actual-diagram mode results and
87,381 previous/current bounded-probe decisions agree.

Against the first bounded evaluator, conjugate kernels improve by paired
ratios 1.91–2.17x, complete supplied-proof replay by 1.13–1.24x, and unsupported
fallbacks by about 1.29x. Source reconstruction and all proof operations are
included in the replay timings, but proof discovery is not. Fallback still
adds work versus calling the general reducer without a probe. See
[`syllable_frontier.tex`](../synthesis/syllable_frontier.tex) for the proof,
controls and whole-recognition follow-up. General quasipolynomial recognition
remains open; projection and forest modes remain optional.

```sh
python -B primitive_power_research/syllable_frontier.py audit --output results/syllable_frontier_audit_20261008.json
python -B primitive_power_research/syllable_frontier.py kernels --output results/syllable_frontier_kernels_20261008.json
python -B primitive_power_research/syllable_frontier.py benchmark --output results/syllable_frontier_pipeline_20261008.json
```

All 760 complete-recognition measurements also finish, but they do not
establish a broad whole-input speedup: Gordian saves only 60 charged work
units out of about 1.27 million and retains the same certificate.

### Acyclic elimination with general word images

`compressed_certificate(..., elimination_batch=True)` enables version-eight
batches of distinct singleton donors with acyclic dependencies. Their images
can be arbitrary words. One linked-circuit pass performs the simultaneous
substitution without expansion or repeated normalization. Independent compressed
replay uses Kahn evaluation; literal replay preflights all expanded images.
All 1,018 maintained tests pass, including random DAG word oracles, deep
nonmonomial images, strict forgery checks and complete source replay.

Use `group_decide(..., elimination_batch=True)`,
`recognize(..., use_group=True, group_elimination_batch=True)`, or
`--group-elimination-batch` for the adaptive host. It gives the new schedule
`max_work//4` total producer work units, with at most 50,000 additional work
units after presentation recovery. The total trial cap still applies. On
nondecision it restarts the established compressed policy from the original
source. Observed trial work is deducted from the fallback allowance; recovery
failure before complete accounting reserves the full trial quota. The wall
deadline is shared. Direct producers can opt into the extra continuation cap
with `post_recovery_work`; its default is `None`.
The option implies compressed search/replay, defaults to false, and is mutually
exclusive with the older explicit-to-compressed `group_adaptive` option.

The 80-diagram audit preserves all 240 results in the prior modes. Direct
batching loses one of 53 positives; capped fallback retains all 53. Whole-input
timings show both wins and substantial regressions, so this is an optional
alternative rather than a new default. The detailed
[`article section`](../synthesis/elimination_batch.tex) gives the Tietze proof,
polynomial encoded batch cost, conditional raw-phase bound, capacity checks,
and separate complete-recognition and checked-stage measurements. General
short-depth discovery and quasipolynomial recognition remain unproved.

```sh
python -B primitive_power_research/elimination.py audit --output results/elimination_batch_audit_20261008.json
python -B primitive_power_research/elimination.py benchmark --output results/elimination_batch_pipeline_20261008.json
python -B primitive_power_research/elimination.py stages --output results/elimination_batch_stages_20261008.json
```

The follow-up [`reachability analysis`](../synthesis/elimination_reach.tex)
maintains exact dependency reachability within each planning state, preserving
unconstrained greedy witnesses while avoiding repeated DFS scans. It retains
dense mask costs and a quadratic-bit storage bound; this is not a global
complexity improvement. The audit compares 2,250 planner states with both the
prior planner and an independent literal oracle. All 80 direct outcomes, including positive
certificate hashes, match the prior producer, and larger source trials complete at 128,
256 and 512 crossings without fallback. The recovery-aware trial can cost
more on unsuccessful candidates such as Gordian. Updated whole-input and
checked-stage measurements, including incomplete old outcomes, are separate
from the initial measurements above.

```sh
python -B primitive_power_research/elimination_reach.py audit --output results/elimination_reach_audit_20261008.json
python -B primitive_power_research/elimination_reach.py benchmark --output results/elimination_reach_pipeline_20261008.json
python -B primitive_power_research/elimination_reach.py stages --output results/elimination_reach_stages_20261008.json
```


### Exact word-cache frontiers

Inverse and free-reduction queries now stop source traversal at exact cached
results. This also handles certified reduced substrings whose intermediate
source concatenations have no individual cache entries. Discovery publishes
no partial results, and all existing work/node limits and cancellation apply.
No option or certificate format changes. The existing independent move
checkers use the updated shared word engine.

Across completed queries, each newly collected source node enters its cache
once. Traversal costs `O(q + U log(U+1))` identifier operations over `q` calls
and `U` newly visited nodes, separately for each cache. This excludes algebraic
operations, failed attempts, integer bit costs, and overall grammar growth.
See the [theory and measurements](../synthesis/word_cache_frontier.tex).

All 1,018 tests pass. Exhaustive short-word validation checks 21,845 words
against literal and prior-engine oracles. All 400 outcomes across five modes
on 80 diagrams match the prior package; every positive passes old/current
literal and compressed replay. Gordian retains its proof and 9,025 producer
nodes while default producer work drops from 1,215,145 to 1,154,597. Separate
kernel, supplied-proof and whole-recognition measurements retain A/A controls
and all incomplete outcomes; a kernel gain is not a proof-discovery bound.

```sh
python -B compressed_word_research/frontier.py audit --output results/word_cache_frontier_audit_20261008.json
python -B compressed_word_research/frontier.py kernels --output results/word_cache_frontier_kernels_20261008.json
python -B compressed_word_research/frontier.py benchmark --output results/word_cache_frontier_pipeline_20261008.json
```
