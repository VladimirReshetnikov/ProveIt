# Strictness and equality for weighted matching support polynomials

Companion to Weighted Rank Five and Covers with a Two Vertex Shore.

## Main conclusion

For a positively weighted bipartite graph with a minimum vertex cover meeting one shore in at most two vertices, equality in any one rank-normalized ULC inequality occurs exactly when the graph's nontrivial components are stars with equal weighted edge totals. Otherwise every gap is strict. This applies to all matching ranks at most five. The first-gap equality characterization also holds at every rank without the cover restriction.

The manuscript contains a direct arbitrary-real-weight proof of the matroid contraction criterion, the exact contraction witnesses, all boundary cases, and attribution to the known unweighted Chan-Pak theorem. No extension from rational strictness by continuity is used.

## Files

- strictness_equality.pdf: eight-page manuscript
- strictness_equality.tex: editable mathematical source
- verify.py and verification.json: complete enumeration of all 512 simple 3-by-3 graphs under three exact fields
- verify_witnesses.py and witness_verification.json: independent Boolean transversal contraction checks
- SOURCES.md: provenance and research boundary
- validation.json: build and visual QA record
- build.sh: standard LaTeX build command

## Reproduce

Run `python verify.py` and `python verify_witnesses.py`. Python 3.11+ and its standard library suffice. The first script rewrites verification.json, the second witness_verification.json. The second uses a recorded seed for its finite collection of regression graphs; it is not the source of the universal theorem.

Run `bash build.sh` with an ordinary LaTeX installation providing the listed packages. Three passes settle all references.

## Status

Full ordinary mathematical proofs are supplied and checked by direct derivation. The work is not externally refereed or formalized in a proof assistant. Finite computations are regression checks, not proofs of an infinite assertion. Novelty is relative to the accompanying rank-compression report; no exhaustive global priority claim is made. No existing report or repository file is modified by this companion.
