"""Validated classical one-component knot diagrams.

PD convention: a crossing is ``[a, b, c, d]`` in counterclockwise order with the
under-strand joining ``a`` to ``c`` and the over-strand joining ``b`` to ``d``.
Every edge label occurs exactly twice.  ``{"pd": []}`` is one crossing-free
circle.  Braid closures and rectangular (grid) diagrams are converted to PD
codes; grids use the convention of archive 01 (rows bottom to top, verticals
pass over horizontals).
"""
from __future__ import annotations

from collections import Counter, defaultdict
TYPE_CHECKING = False            # annotations only: importing typing costs 4.6 ms at start-up
if TYPE_CHECKING:
    from typing import Any, Iterable, Sequence


class DiagramError(ValueError):
    """The data do not describe a classical one-component knot diagram."""


class DisjointSet:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, x: int) -> int:
        root = x
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[x] != root:
            self.parent[x], x = root, self.parent[x]
        return root

    def union(self, a: int, b: int) -> None:
        a, b = self.find(a), self.find(b)
        if a != b:
            self.parent[a] = b


def cycles(permutation: Sequence[int]) -> list[tuple[int, ...]]:
    seen: set[int] = set()
    result = []
    for start in range(len(permutation)):
        if start in seen:
            continue
        cycle, x = [], start
        while x not in seen:
            seen.add(x)
            cycle.append(x)
            x = permutation[x]
        result.append(tuple(cycle))
    return result


class Diagram:
    """A normalized PD code (labels 0..2n-1) with cached face and strand data.

    An immutable record with value equality and hashing (written out by hand:
    importing ``dataclasses`` alone took 25 of the 56 ms of ``import fastunknot``).
    """

    def __init__(self, pd: tuple[tuple[int, int, int, int], ...]):
        if "pd" in self.__dict__:
            raise AttributeError("cannot reinitialize an immutable Diagram")
        object.__setattr__(self, "pd", pd)

    def __setattr__(self, name, value):
        raise AttributeError(f"cannot assign to field {name!r}: Diagram is immutable")

    def __delattr__(self, name):
        raise AttributeError(f"cannot delete field {name!r}: Diagram is immutable")

    def __eq__(self, other):
        return self.pd == other.pd if other.__class__ is self.__class__ else NotImplemented

    def __hash__(self):
        return hash((self.pd,))

    def __repr__(self):
        return f"Diagram(pd={self.pd!r})"

    @property
    def crossings(self) -> int:
        return len(self.pd)

    @property
    def braid_source(self):
        """Validated original braid, or None for a diagram supplied as PD/grid.

        This provenance is auxiliary: equality and hashing still depend only
        on PD.  It is attached only by checked conversion, never accepted as an
        unchecked second argument to the public Diagram constructor.
        """
        return self.__dict__.get("_braid_source")

    @property
    def rational_source(self):
        """Checked ``(e, continued_fractions)`` Montesinos source, or None.

        Attached only by actual tangle construction.  Equality and hashing
        still depend solely on PD, and a bare PD never acquires this promise.
        """
        return self.__dict__.get("_rational_source")

    @classmethod
    def from_pd(cls, data: Iterable[Iterable[int]]) -> "Diagram":
        try:
            rows = [tuple(row) for row in data]
        except TypeError as exc:
            raise DiagramError("PD must be a list of four-integer crossings") from exc
        for row in rows:
            if len(row) != 4 or any(type(x) is not int for x in row):
                raise DiagramError("each crossing must be four integer edge labels")
        if not rows:
            return cls(())
        counts = Counter(x for row in rows for x in row)
        if any(c != 2 for c in counts.values()):
            raise DiagramError("every edge label must occur exactly twice")
        relabel = {label: i for i, label in enumerate(sorted(counts))}
        pd = tuple(tuple(relabel[x] for x in row) for row in rows)
        n = len(pd)
        # darts 4i+j; alpha pairs the two darts of an edge
        where: dict[int, list[int]] = defaultdict(list)
        for i, row in enumerate(pd):
            for j, e in enumerate(row):
                where[e].append(4 * i + j)
        alpha = [0] * (4 * n)
        for a, b in where.values():
            alpha[a], alpha[b] = b, a
        strands = DisjointSet(4 * n)
        for a, b in where.values():
            strands.union(a, b)
        for i in range(n):
            strands.union(4 * i, 4 * i + 2)
            strands.union(4 * i + 1, 4 * i + 3)
        if len({strands.find(d) for d in range(4 * n)}) != 1:
            raise DiagramError("the diagram must have exactly one component")
        faces = cycles([4 * (alpha[d] // 4) + (alpha[d] + 1) % 4 for d in range(4 * n)])
        if len(faces) != n + 2:
            raise DiagramError("the rotation system is not spherical (virtual diagram)")
        return cls(pd)

    @classmethod
    def from_braid(cls, strands: int, word: Iterable[int]) -> "Diagram":
        """Closure of an Artin braid; generator +i puts strand i over strand i+1."""
        word = list(word)
        if type(strands) is not int or strands < 1:
            raise DiagramError("strands must be a positive integer")
        if any(type(g) is not int or not 1 <= abs(g) < strands for g in word):
            raise DiagramError("braid generators must satisfy 1 <= |g| < strands")
        if strands > len(word) + 1:
            raise DiagramError("too few crossings for a one-component closure")
        permutation = list(range(strands))
        for g in word:
            i = abs(g) - 1
            permutation[i], permutation[i + 1] = permutation[i + 1], permutation[i]
        if len(cycles(permutation)) != 1:
            raise DiagramError("the braid closure is a link, not a knot")
        if not word:
            result = cls(())
            object.__setattr__(result, "_braid_source", (strands, tuple(word)))
            return result
        current = list(range(strands))
        next_label = strands
        rows = []
        for g in word:
            i = abs(g) - 1
            left, right = current[i], current[i + 1]
            out_left, out_right = next_label, next_label + 1
            next_label += 2
            rows.append((right, left, out_left, out_right) if g > 0
                        else (left, out_left, out_right, right))
            current[i], current[i + 1] = out_left, out_right
        closure = DisjointSet(next_label)
        for top, bottom in enumerate(current):
            closure.union(top, bottom)
        result = cls.from_pd([[closure.find(x) for x in row] for row in rows])
        object.__setattr__(result, "_braid_source", (strands, tuple(word)))
        return result

    @classmethod
    def from_grid(cls, rows: Sequence[Sequence[int]]) -> "Diagram":
        """Rectangular diagram: two marked columns per row (rows bottom to top)."""
        rows = [tuple(sorted(r)) for r in rows]
        n = len(rows)
        if n < 2 or any(len(r) != 2 or r[0] == r[1] or not 0 <= r[0] < n or not 0 <= r[1] < n
                        for r in rows):
            raise DiagramError("a grid needs two distinct column indices in each row")
        cols: list[list[int]] = [[] for _ in range(n)]
        for r, (a, b) in enumerate(rows):
            cols[a].append(r)
            cols[b].append(r)
        if any(len(c) != 2 for c in cols):
            raise DiagramError("every column must contain exactly two corners")
        crossing_id: dict[tuple[int, int], int] = {}
        events = []
        r, c = 0, rows[0][0]
        start = (r, c)
        visited = 0
        while True:
            a, b = rows[r]
            d = b if c == a else a
            dx = 1 if d > c else -1
            for col in range(c + dx, d, dx):
                lo, hi = cols[col]
                if lo < r < hi:
                    key = (r, col)
                    crossing_id.setdefault(key, len(crossing_id))
                    events.append((crossing_id[key], False, dx))
            c = d
            lo, hi = cols[c]
            s = hi if r == lo else lo
            dy = 1 if s > r else -1
            for row in range(r + dy, s, dy):
                a2, b2 = rows[row]
                if a2 < c < b2:
                    key = (row, c)
                    crossing_id.setdefault(key, len(crossing_id))
                    events.append((crossing_id[key], True, dy))
            r = s
            visited += 1
            if (r, c) == start:
                break
        if visited != n:
            raise DiagramError("the grid has more than one component")
        m = len(events)
        if m == 0:
            return cls(())
        info: dict[int, dict[str, tuple[int, int, int]]] = {}
        for k, (cid, over, direction) in enumerate(events):
            info.setdefault(cid, {})['over' if over else 'under'] = ((k - 1) % m, k, direction)
        pd = []
        for cid in range(len(crossing_id)):
            u_in, u_out, dx = info[cid]['under']
            o_in, o_out, dy = info[cid]['over']
            south = o_in if dy == 1 else o_out
            north = o_out if dy == 1 else o_in
            pd.append([u_in, south, u_out, north] if dx == 1 else [u_in, north, u_out, south])
        return cls.from_pd(pd)

    @classmethod
    def from_rational(cls, e: int, tangles, *, max_crossings=100_000) -> "Diagram":
        """Numerator closure of integer e plus supplied rational tangles.

        Every tangle is an ordinary continued fraction.  Actual planar
        twists, reciprocals and horizontal gluing create the PD.  Its
        immutable source authorizes the Montesinos recognition theorem.
        The default crossing-expansion cap is independent of the arithmetic
        certificate API, which supports arbitrarily large binary coefficients.
        """
        from .rational import montesinos_pd
        pd, source = montesinos_pd(e, tangles, max_crossings=max_crossings)
        result = cls.from_pd(pd)
        object.__setattr__(result, "_rational_source", source)
        return result

    from_montesinos = from_rational

    @classmethod
    def from_json(cls, value: Any) -> "Diagram":
        if isinstance(value, list):
            return cls.from_pd(value)
        if not isinstance(value, dict):
            raise DiagramError("input must be a JSON object or a PD array")
        keys = [k for k in ("pd", "braid", "rows", "x", "montesinos") if k in value]
        if len(keys) != 1:
            raise DiagramError("specify exactly one of pd, braid, rows, x/o, or montesinos")
        key = keys[0]
        if key == "pd":
            return cls.from_pd(value["pd"])
        if key == "braid":
            braid = value["braid"]
            if not isinstance(braid, dict) or "strands" not in braid or "word" not in braid:
                raise DiagramError("braid must have strands and word")
            return cls.from_braid(braid["strands"], braid["word"])
        if key == "rows":
            return cls.from_grid(value["rows"])
        if key == "montesinos":
            source = value["montesinos"]
            if (not isinstance(source, dict) or "tangles" not in source
                    or set(source) - {"e", "tangles"}):
                raise DiagramError("montesinos must have tangles and an optional integer e")
            return cls.from_rational(source.get("e", 0), source["tangles"])
        x, o = value["x"], value.get("o")
        if not isinstance(x, list) or not isinstance(o, list) or len(x) != len(o):
            raise DiagramError("x and o must be equal-length arrays")
        return cls.from_grid(list(zip(x, o)))

    # ----- derived data -------------------------------------------------
    def _cached(self, name: str, compute):
        """Derived data of an immutable diagram, computed once (``recognize`` asked for ``alpha``
        seven times).  Stored beside ``pd`` without touching equality, hashing or pickling."""
        found = self.__dict__.get(name)
        if found is None:
            found = compute()
            object.__setattr__(self, name, found)
        return found

    def __getstate__(self):
        state = {"pd": self.pd}
        if self.braid_source is not None:
            state["braid_source"] = self.braid_source
        if self.rational_source is not None:
            state["rational_source"] = self.rational_source
        return state

    def __setstate__(self, state):
        # Preserve checked provenance across process/cache serialization.  A
        # mismatched PD/word pair must never authorize a specialized verdict.
        if "pd" in self.__dict__:
            raise AttributeError("cannot reinitialize an immutable Diagram")
        restored = Diagram.from_pd(state["pd"])
        if "braid_source" in state and "rational_source" in state:
            raise DiagramError("serialized diagram has multiple source presentations")
        source = state.get("braid_source")
        if source is not None:
            try:
                strands, word = source
            except (TypeError, ValueError) as exc:
                raise DiagramError("invalid serialized braid provenance") from exc
            braid = Diagram.from_braid(strands, word)
            # Mirroring a crossing can change the choice of its first under
            # port.  A half-turn of one PD row leaves that crossing unchanged.
            if (len(braid.pd) != len(restored.pd)
                    or any(a != b and a[2:] + a[:2] != b
                           for a, b in zip(braid.pd, restored.pd))):
                raise DiagramError("serialized braid provenance does not match PD")
            source = braid.braid_source
        object.__setattr__(self, "_braid_source", source)
        rational_source = state.get("rational_source")
        if rational_source is not None:
            from .rational import source_matches_pd
            rational_source = source_matches_pd(restored, rational_source)
            if rational_source is None:
                raise DiagramError("serialized Montesinos provenance does not match PD")
            object.__setattr__(self, "_rational_source", rational_source)
        object.__setattr__(self, "pd", restored.pd)

    def alpha(self) -> list[int]:
        """The dart involution; a fresh list on every call, because callers modify it."""
        return list(self._cached("_alpha", self._alpha))

    def _alpha(self) -> tuple:
        n = self.crossings
        where: dict[int, list[int]] = defaultdict(list)
        for i, row in enumerate(self.pd):
            for j, e in enumerate(row):
                where[e].append(4 * i + j)
        alpha = [0] * (4 * n)
        for a, b in where.values():
            alpha[a], alpha[b] = b, a
        return tuple(alpha)

    def faces(self) -> list[tuple[int, ...]]:
        return list(self._cached("_faces", self._faces))

    def _faces(self) -> tuple:
        alpha = self._cached("_alpha", self._alpha)
        return tuple(tuple(face) for face in cycles([4 * (alpha[d] // 4) + (alpha[d] + 1) % 4 for d in range(4 * self.crossings)]))

    def traversal(self) -> list[int]:
        """Incoming darts of an oriented traversal starting on the under-port of crossing 0."""
        return list(self._cached("_traversal", self._traversal))

    def _traversal(self) -> tuple:
        if not self.pd:
            return ()
        alpha = self._cached("_alpha", self._alpha)
        walk, current = [], 0
        for _ in range(2 * self.crossings):
            walk.append(current)
            opposite = 4 * (current // 4) + (current + 2) % 4
            current = alpha[opposite]
        if current != 0:
            raise DiagramError("internal traversal error")
        return tuple(walk)

    def incoming_slots(self) -> list[tuple[int, int]]:
        """(incoming under slot, incoming over slot) of every crossing for the traversal."""
        under = [0] * self.crossings
        over = [1] * self.crossings
        for dart in self.traversal():
            if dart % 2:
                over[dart // 4] = dart % 4
            else:
                under[dart // 4] = dart % 4
        return list(zip(under, over))

    def signs(self) -> list[int]:
        """Crossing signs (+1 right-handed) for the traversal orientation.

        Both incoming ports are used, so the result does not depend on which of
        the two under-ports a PD row happens to start with (0.1 assumed that the
        row starts at the incoming under-port, as its own converters guarantee).
        With slots counterclockwise, the crossing is positive exactly when the
        over-strand enters one slot clockwise of the incoming under-slot.
        """
        return [1 if (o - u) % 4 == 3 else -1 for u, o in self.incoming_slots()]

    def writhe(self) -> int:
        return sum(self.signs())

    def mirror(self) -> "Diagram":
        result = Diagram.from_pd([row[1:] + row[:1] for row in self.pd])
        if self.braid_source is not None:
            strands, word = self.braid_source
            object.__setattr__(result, "_braid_source", (strands, tuple(-g for g in word)))
        if self.rational_source is not None:
            e, tangles = self.rational_source
            object.__setattr__(result, "_rational_source",
                               (-e, tuple(tuple(-a for a in cf) for cf in tangles)))
        return result

    def to_json(self, *, preserve_braid: bool = False, preserve_rational: bool = False) -> dict[str, Any]:
        if preserve_braid and self.braid_source is not None:
            strands, word = self.braid_source
            return {"braid": {"strands": strands, "word": list(word)}}
        if preserve_rational and self.rational_source is not None:
            e, tangles = self.rational_source
            return {"montesinos": {"e": e, "tangles": [list(cf) for cf in tangles]}}
        return {"pd": [list(row) for row in self.pd]}
