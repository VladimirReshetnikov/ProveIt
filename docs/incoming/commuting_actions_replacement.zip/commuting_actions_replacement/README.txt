COMMUTING ACTIONS AND REPLACEMENT
Exact Cofinality Thresholds, Definable Kernels, and Uniform Naming
Research manuscript prepared with ChatGPT, 4 October 2026

CONTENTS

commuting_actions_replacement.pdf   Complete article with proofs and bibliography
commuting_actions_replacement.tex   Main LaTeX source; bibliography is included
figures/staircases.pdf              Vector figure used by the LaTeX source
figures/staircases.png              High-resolution figure preview
make_figure.py                      Reproducible integer-lattice figure generator
verify_examples.py                 Exact deterministic finite sanity checks
verification_output.txt            Recorded output of the checks (347,278 passed)
README.txt                         This guide

RESEARCH TARGET

The article connects Elliot Glazer and Bokai Yao's research on reflection,
Collection, and atom-kernel models with the ProveIt report Naming Elementary
Embeddings. It answers that report's Question 10.4 about finitely many commuting
named permutations, and addresses Question 10.1 in the commuting-permutation
setting. It also answers the fixed-action part of Question 10.10 when forcing
preserves the cutoff cardinal.

The inspected source revision is pinned:
  a9ab9a69872c2fb7464097af32fd7b76c75cb030

Source file:
  SetTheory/Cardinals/docs/reports/ordinals-and-order-types/
  naming-elementary-embeddings/article.tex

Pinned source URL:
https://github.com/VladimirReshetnikov/ProveIt/blob/a9ab9a69872c2fb7464097af32fd7b76c75cb030/SetTheory/Cardinals/docs/reports/ordinals-and-order-types/naming-elementary-embeddings/article.tex

Research anchor:
  Elliot Glazer and Bokai Yao, Reflection Principles in ZFU,
  arXiv:2602.21970v1, 25 February 2026.
  https://arxiv.org/abs/2602.21970

MAIN RESULTS

In the external-choice model M_kappa(A), which retains exactly the objects with
fewer than kappa atoms in their transitive closures:

1. Every fixed finite nonempty commuting-permutation signature universally
   preserves expanded Replacement exactly when cf(kappa) > omega.
2. For commuting signatures, at most one noninvertible injection direction
   gives the same threshold. At least two give cf(kappa) > 2^aleph_0.
3. Two commuting proper injections can individually preserve Replacement and
   have only pure fixed objects, while their joint expansion fails Replacement.
4. For commuting permutations, the atom kernel of definable closure is exactly
   the orbit saturation of the parameter kernels together with the union of all
   complete component-type blocks of size below kappa.
5. For a finitely generated group G and kappa > omega, the universal threshold
   is cf(kappa) > |Sub(G)/conjugacy|. At kappa = omega the criterion is G finite.
6. Countably many separately named involutions can preserve Replacement while
   a single amenable binary evaluator for the same action destroys it. The
   example uses only two-point orbits of the direct sum of countably many C_2.
7. For a fixed finite ground action, forcing which leaves the cutoff cardinal
   intact preserves the expanded-Replacement verdict in the rebuilt models.

The article also explains the inherited Collection/reflection criteria and
provides twelve further research questions, explicit negative schema instances,
formalization milestones, and a detailed provenance record.

BUILD THE PDF

Extract the full ZIP, preserving the figures subdirectory. Run in the directory
containing the main TEX file:

  latexmk -pdf -interaction=nonstopmode -halt-on-error commuting_actions_replacement.tex

Alternatively, run pdflatex on that TEX file until references and the table of
contents are stable (normally three passes from a clean directory).

The source uses standard LaTeX packages: lmodern, microtype, geometry, amsmath,
amssymb, amsthm, mathtools, enumitem, booktabs, longtable, array, graphicx, xcolor,
fancyhdr, url, hyperref, and cleveref. No BibTeX, external bibliography file,
network access, or Python execution is required to build the supplied article.

The build was checked with pdfTeX/TeX Live 2023 and latexmk 4.83. The full source
package is needed for compilation because the TEX file includes the supplied
vector figure from figures/staircases.pdf.

REPRODUCE THE FINITE CHECKS

With Python 3.10 or newer, using only the standard library:

  python3 verify_examples.py

To save the report:

  python3 verify_examples.py > verification_output.txt

The checks use exact integer and finite-set operations, with no random input.
They examine all 256 eight-bit staircase prefixes, finite translated boundary
windows, all 15 subgroups of (Z/4Z)^2, and the 31 nonzero characters of (F_2)^5.
They are finite sanity checks. They do not establish any infinite classification,
cardinal arithmetic assertion, forcing theorem, class-model theorem, or axiom
scheme. The mathematical arguments for these statements are in the manuscript.

REGENERATE THE FIGURE (OPTIONAL)

With Python and Matplotlib installed:

  python3 make_figure.py

The supplied figure was generated with Matplotlib 3.10.8. It depicts exact
integer-grid data in finite windows of the infinite staircase constructions.
The generator validates the rendered PDF and replaces output files atomically.
The ready-made PDF figure is included, so regeneration is unnecessary to build
the article.

STATUS AND PROVENANCE

This is a research manuscript, not a peer-reviewed publication. It claims a
resolution of the explicitly identified question in the inspected repository
report and supplies full mathematical proofs in a specified family of models.
It does not establish worldwide publication priority or claim to settle an open
problem expressly posed by Glazer and Yao. Their work is a research connection
and a credited source, not an endorsement or coauthorship.

The atom-kernel construction, component-profile theorem, standard coset-action
classification, and general Collection/reflection criteria are prior work and
are distinguished from the refinements developed in this article. The proofs
received independent review within preparation of the manuscript; this is not
external peer review. No machine-checked proof in Lean or another proof assistant
is included or claimed. The verification scripts supplement the proofs rather
than replace them.

The upstream repository was inspected; it was not modified by this work.
