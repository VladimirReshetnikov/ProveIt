# Report158 — Exact exponential growth of increasing superdiagonal partitions

This standalone report proves the exact exponential rate of OEIS A238873. A(n) counts weakly increasing positive-integer lists lambda_1 <= ... <= lambda_k with lambda_i >= i and total n. The empty partition gives A(0)=1. The decreasing-order convention is a different class.

## Results and precise scope

With natural logarithms, let

    C = pi²/12 + log² 2
    B = 2 sqrt(C) = sqrt(pi²/3 + 4 log² 2).

The report proves

    C/t - O(t^(-1/3)) <= log(sum A(n) exp(-tn)) <= C/t + O(1),
    B sqrt(n) - O(n^(1/3)) <= log A(n) <= B sqrt(n) + O(1).

In particular, log A(n)/sqrt(n) tends to B = 2.2829104645976064.... For real y tending to infinity, the threshold inverse satisfies

    (log(y)/B)² - O(log y)
       <= min{n >= 0 : A(n) >= y}
       <= (log(y)/B)² + O((log y)^(5/3)).

The errors have unspecified constants and onset. These are logarithmic asymptotics, not a multiplicative equivalent with an amplitude or power prefactor. No sharp second term, Airy correction, optimal error order, all-orders expansion, exact rounding rule, or certified finite-input inverse bracket is asserted.

The complete proof uses the cumulative multiplicity barrier, a matching exponential-tilt upper bound, a bounded-height Dyck prefix, an unrestricted geometric tail conditioned on survival, an exact all-height spectral inequality, and Chernoff bounds plus monotonicity to transfer to every coefficient. The explicit iid survival bound is 1-2p for geometric p<1/2. Its proof uses only finite-time martingale stopping. The growing-height argument never applies a fixed-height asymptotic outside its scope.

The 2025 paper by Archibald, Blecher, Elizalde and Knopfmacher is credited for the class, its generating functions and prior Dyck/ballot representations. Report156 is the antecedent lower-bound result with B_* = sqrt(pi²/3 + 2 log² 2), approximately 2.0617405660. Report158 is self-contained and does not modify Report156. A bounded primary-source search and current report-catalogue check found no equivalent exact-rate result; this is not exhaustive scholarly priority clearance.

## Package contents

- `Report158.pdf`: complete 13-page article
- `Report158.tex`: editable, self-contained LaTeX source
- `companion.py`: bounded exact counts, threshold searches and finite checks
- `test_companion.py`: mathematical, validation and output-safety regression tests
- `counts.json`: deterministic exact A(n) values for n=0,...,200
- `finite_checks.json`: finite verification results, rational values and coverage
- `data/oeis_prefixes.json`: attributed numerical prefix and official source URL
- `SOURCE_PROVENANCE.json`: source hashes, attribution, inspection scopes and limitations
- `build_pdf.py`, `release_tools.py`: exclusive clean PDF build and local I/O helpers
- `make_zip.py`, `test_release.py`: deterministic fixed-allowlist packaging and release tests
- `SHA256SUMS`: sorted SHA-256 manifest for every allowlisted payload except itself

The ZIP includes the manifest. A manifest cannot include its own digest without a self-reference cycle; the archive digest is supplied separately with the release. Full journal articles, full OEIS entry text, research drafts, review records, unrelated reports and all unlisted files are excluded.

## Requirements

The companion and release tools require Python 3.10 or later and only the standard library. Safe output publication requires POSIX directory-relative operations, O_NOFOLLOW/O_DIRECTORY and hard-link support. They make no network requests and execute no source data.

The PDF was built with Python 3.12.14 and pdfTeX 1.40.26 (TeX Live 2025/dev/Debian). Required executables are `pdftex` and `pdflatex`; packages/fonts include fontenc, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, booktabs, longtable, array, microtype and hyperref. Poppler's `pdfinfo` and `pdftoppm` support visual inspection but are not used by the PDF builder.

## Exact companion replay

Run from the extracted package root. Output defaults to stdout. To save JSON, choose a fresh `.json` filename in an existing trusted directory:

```sh
python3 -B companion.py counts --max-n 200 --out replay_counts.json
python3 -B companion.py verify --max-n 200 --enumerate-to 40 --prefix-to 10 --height-to 10 --survival-to 30 --out replay_checks.json
cmp counts.json replay_counts.json
cmp finite_checks.json replay_checks.json
python3 -B companion.py threshold --value 1000000 --max-n 200
python3 -B -m unittest -v test_companion
python3 -O -B -m unittest -v test_companion
```

For value 1000000 the exact first index is 84, with A(83)=899682 and A(84)=1002821. The search starts at n=0; value 1 therefore returns index 0. If a bound is too short, `reached` is false and `first_n` is null. That establishes only that the threshold exceeds `max_n`, and never substitutes an asymptotic guess.

The public integer API rejects booleans and non-integer types. CLI integers must be canonical nonnegative ASCII decimals, with no signs, whitespace or leading zeroes except zero itself. Counts and cutoff parameters are bounded by 200; independent partition enumeration is bounded by 40; prefix size and strip height are at most 10; finite survival horizons are at most 30; finite weighted products have largest part at most 30. Rational API parameters must be actual `Fraction` objects strictly between zero and one with denominator at most 100; the finite-horizon survival API accepts this whole range, while the positive infinite-survival lemma requires p<1/2. Threshold values range from 1 to 10^1000. Enumeration cannot exceed `max_n`; the omitted CLI enumeration limit shrinks to min(40,max_n). Prefix checks need not fit the weight bound: inequalities are tested only through `max_n`, and absent coefficients are zero.

The shipped verification uses all the displayed default bounds and performs:

- 61 official A238873 prefix comparisons
- 215,308 indexed/cumulative equivalence checks over every partition through weight 40, and 41 independent count comparisons
- 26,979 monotonicity injection and inverse checks, plus all 200 adjacent count comparisons
- 100 prefix/Dyck count comparisons and 160,357 exact prefix weight and bijection checks
- 20,100 prefix-tail coefficient inequalities through weight 200
- 93 rational survival-horizon bounds, three exact martingale normalizations, four tilted upper and four tail-product lower inequalities, and 40 rational prefix-tail inequalities

All finite mathematical decisions use integers or rational numbers. Recorded rational outputs are strings, not floating-point pass/fail evidence. The count recurrence uses fresh multiplicity layers, independently of direct partition and path enumeration. The shipped counts were also cross-checked against all 201 earlier Report156 values and the separate proof-audit table; those older reports and their data are not dependencies or included payloads.

The calculations support definitions, indexing and finite inequalities. They do not prove an asymptotic theorem, infinite-horizon survival, the size or onset of an asymptotic remainder, or novelty. The companion suite has 40 tests, and the release suite has 11 tests. Both test suites run normally and with Python optimization enabled.

### Companion output safety

No existing target of any kind is overwritten. Symlink components, dot/parent traversal, empty or trailing-slash components, directories, FIFOs and special-file destinations are refused. The output parent must already exist, belong to the current user, and not be group- or world-writable. JSON output is capped at 2 MiB; numerical prefix input must be a regular file of at most 32 KiB and is parsed with strict type and schema checks.

The companion fully writes and fsyncs a private temporary file, then links it exclusively to the chosen new name. Successful publication is atomic and no-clobber. A failure after publication, such as a directory fsync failure, may leave a complete result present; inspect it rather than blindly retrying or deleting it. A colliding temporary name is not removed by the operation that failed to create it.

These guarantees assume trusted ancestors and no malicious same-user process concurrently changing the parent or source tree. Descriptor pinning and validation reduce accidental path substitution; they are not a general operating-system sandbox.

## Clean PDF replay

Choose new build directories whose parents already exist:

```sh
python3 -B build_pdf.py --output-dir /tmp/report158-build-one
python3 -B build_pdf.py --output-dir /tmp/report158-build-two
cmp /tmp/report158-build-one/Report158.pdf /tmp/report158-build-two/Report158.pdf
cmp Report158.pdf /tmp/report158-build-one/Report158.pdf
```

The builder creates each directory exclusively, isolates a fresh LaTeX format and cache, disables shell escape, fixes the epoch and PDF metadata, and repeats LaTeX until references stabilize. It rejects warnings and layout diagnostics in the settled log. The `.tex` file is its only authoring input. Byte identity is expected within the recorded toolchain, not across TeX versions, fonts, operating systems or arbitrary platform changes.

The build destination must have a trusted parent and must not be subject to concurrent adversarial replacement. Existing paths, static symlinks and parent traversal are refused. The mkdir-then-open step is not claimed to resist a malicious same-user process replacing the just-created directory in that interval. Subsequent operations are descriptor-pinned. TeX is not a sandbox for arbitrarily modified source, even with shell escape disabled.

## Manifest and archive replay

From the unchanged extracted package root:

```sh
sha256sum -c SHA256SUMS
python3 -B -m unittest -v test_release
python3 -O -B -m unittest -v test_release
python3 -B make_zip.py --output /tmp/Report158_rebuild_one.zip
python3 -B make_zip.py --output /tmp/Report158_rebuild_two.zip
cmp /tmp/Report158_rebuild_one.zip /tmp/Report158_rebuild_two.zip
```

The packager verifies payload hashes against an exact sorted allowlist, excludes unlisted files, and fixes ZIP timestamps, member order, permissions and ZIP_STORED compression. Its output is exclusive and will not overwrite an existing file, symlink, directory or special file. A trusted parent and a nonadversarial source tree are required. A failed output write may leave a new incomplete file; inspect it instead of blindly retrying or deleting it. The archive does not include itself recursively.

Editing source and issuing a new checksum manifest is a separate authoring/release action. An edited package should fail verification against the original manifest. Release tests exercise refusals, descriptor pinning, allowlist verification, tamper detection and deterministic archive construction under ordinary and optimized Python.

No external publication, OEIS editing, author contact, or public repository change is part of this package.
