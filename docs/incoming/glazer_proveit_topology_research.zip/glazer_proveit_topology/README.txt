POLISH GROUP COMPLETIONS AND THE SIZE OF CLASS MANIFOLDS
An intrinsic cancellation criterion and a local rank approach to
Glazer's manifold question

Research manuscript prepared with AI assistance
4 October 2026 UTC

CONTENTS

polish_completions_class_manifolds.tex
    Complete standalone LaTeX source, including its bibliography.
polish_completions_class_manifolds.pdf
    Compiled article: 31 PDF pages.
PROOF_AUDIT.txt
    Exact scope, proof dependencies, and review record.
SOURCE_RECORD.txt
    Sources, repository pin, archive members, and source identifiers.
build.sh
    Rebuild script using latexmk or three runs of pdfLaTeX.
SHA256SUMS.txt
    Integrity checksums for the six files above.

MAIN RESULTS

1. A Hausdorff cancellative commutative topological monoid whose natural
   algebraic order is linear has an extending Hausdorff group topology
   on its formal differences exactly when partial subtraction is
   continuous. The extension is unique, with zero neighborhoods U-U.
   Polishness and local compactness are preserved when present.

2. Partial subtraction need only be tested at (x,x) and (x,0).
   Continuous homomorphisms and biadditive maps extend continuously.
   A topological semiring satisfying the criterion completes to a
   topological ring.

3. In the specified class theory with Foundation omitted, an exhausted,
   connected Hausdorff class space with bounded tightness on sets is
   a set. A specified set neighborhood operator can replace exhaustion.
   No Global Choice, unrestricted Collection, or class-length recursion
   is used.

4. Connected real class manifolds coded in, or decoded from, finite
   tuples of surreal sign sequences are sets. A compatible real-valued
   class metric is another sufficient condition.

SCOPE

The completion criterion resolves a question explicitly posed in the
inspected ProveIt research material. The unrestricted higher-dimensional
manifold question discussed by Elliot Glazer is not resolved.
Classical cardinal bounds and existing examples are credited.
Historical priority is not established.

The results have written proofs and independent AI-assisted review
passes. They have not been checked by a proof assistant or externally
refereed.

BUILD

Use a recent TeX Live or MacTeX installation with the standard packages
listed in the source. In this directory run:

    bash build.sh

No bibliography database, external figures, repository checkout,
or network access is needed. The bibliography is inside the source.

To verify the delivered files on a system with sha256sum:

    sha256sum -c SHA256SUMS.txt

