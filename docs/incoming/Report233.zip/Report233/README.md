# Report 233

## A complete exact formula for height five shifted rectangles

This manuscript proves the full height-five array count, the nested finite sum
printed as Kauers–Koutschan Conjecture 19, and the specific order-three,
degree-24 recurrence recorded in OEIS A181199, for every integer n >= 1.
The proof retains every boundary contribution. No recurrence fitting or
parameter interpolation is used.

Earlier fixed-height asymptotic work is credited in the article and SOURCES.md.
The new result here concerns the exact full count. Historical priority is not
certified. This is an AI-assisted research manuscript, not a peer-reviewed
publication or a proof-assistant formalization.

## Contents

- `Report233.pdf`: standalone manuscript
- `article.tex`, `sections/`: editable LaTeX source
- `code/exact_algebra.py`: small standard-library exact polynomial/rational ring
- `code/printed_coefficients.py`: literal finite-sum and OEIS coefficients
- `code/verify_certificate.py`: exact certificate and separate finite tests
- `code/asymptotic_certificate.py`: exact formal coefficients and effective bounds
- `code/receipt.json`: deterministic, reproducible certificate output
- `SOURCES.md`: public source and attribution record
- `build.py`: frozen-inventory checks and isolated PDF/ZIP reproduction
- `MANIFEST.sha256`: hashes of every other package file

No third-party papers or private review reports are redistributed.

## Exact certificate only

Python 3.9 or later is sufficient; there are no external Python dependencies:

    python -B code/verify_certificate.py
    python -B -O code/verify_certificate.py

Both commands print the same deterministic JSON as `code/receipt.json`.
The verifier writes no files. All essential guards use explicit exceptions and
remain active under optimization. Builds additionally impose the restrictive
`PYTHONINTMAXSTRDIGITS=640` limit on supporting Python versions.

The 58 named uniform certificates cover all contiguity coefficients, the general
integration-by-parts fluxes, every reduced moment, the exact full-count first
difference, gamma transport, the literal OEIS operator, its independent direct
period elimination, and strict positivity after shifting P and Q by one.
The JSON records every moment coefficient as integer polynomial numerator and
denominator arrays, in ascending powers of n, with state order (X,Z,1).

The program also enumerates all 225 terms in the two bordered Pfaffians and
checks their four sign classes (15,30,60,120). Separately labeled finite sanity
tests compare an independently constructed literal cell graph, direct
piecewise-polynomial kernel integrals, and the printed nested sum for n=1..20.
Three arbitrary-matrix tests check the two discrete Pfaffian identities.
These finite checks support transcription and normalization; they are not the
all-n proof. The manuscript supplies the array-to-integral derivation, endpoint
analysis, and uniqueness arguments.

The integrated asymptotic certificate also checks the all-fixed-order formal
coefficient construction, the first six normalized/count/logarithmic corrections,
inverse formal coefficients through order six, and exact rational residual and
induction constants for orders zero and six. Its finite error sanity tests are
separately labeled. Effective bounds and the ceiling qualification for integer
thresholds are proved in the manuscript, rather than inferred from those tests.

## Frozen inventory

    python -B build.py --verify-only

The manifest rejects changed, missing, and extra files, unexpected directories,
symlinks, and nonregular entries. Its purpose is reproducible inventory, not
third-party authentication. Do not let an editor or Python create cache files
inside the frozen package. Make a working copy for edits and re-freeze it
explicitly after review.

## Rebuild PDF and ZIP

Use an existing parent directory and a new output name outside the package:

    python -B build.py --output-dir /absolute/path/to/new-output

The builder verifies the inventory, reruns the exact verifier, requires byte
identity with the checked receipt, compiles the article three times in a private
TeX directory with shell escape disabled, requires byte identity with the frozen
PDF, and verifies that the source tree has not changed. It produces
`Report233.pdf`, `Report233.zip`, `exact_checks.json`, `build_checks.json`, and logs.
Output-directory creation is exclusive. Existing paths, live or dangling
symlink ancestors, dot components, and output paths inside the source package
are rejected. Every Python child explicitly receives `-B`; optimized builds
retain the selected optimization level.

The PDF build needs TeX Live with article, AMS mathematics/theorems, geometry,
Latin Modern, microtype, booktabs, longtable, array, enumitem, fancyhdr, and
hyperref. The recorded toolchain is included in each build receipt. Builds use
private TeX format/cache paths and require no network access. PDF/ZIP metadata
is fixed to October 5, 2026. ZIP members have fixed permissions, timestamps,
ordering, and stored compression. Different TeX or font versions can change
PDF bytes and require a freshly inspected rendering.

Fresh normal and optimized builds extracted from the actual final ZIP must
agree on the PDF, archive, exact receipt, manifest, and complete build receipt.
The ZIP contains its source and frozen PDF; the outer build receipt records its
hash without introducing a circular hash claim. Logs may contain temporary
paths and are diagnostic rather than byte-reproducible artifacts.

## Index scope

The theorem and recurrence hold for n >= 1, with a1=a2=1 and a3=16.
The empty-array convention a0=1 does not extend this operator to zero:
its residual at n=0 is 5621993879040000. The program checks this nonzero value
explicitly and never silently uses the invalid extension.
