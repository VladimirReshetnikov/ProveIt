# Fixed power weighted partition asymptotics

The eleven-page report proves the logarithmic OEIS conjectures for A022629, A092484 and A266891 as instances of one fixed-parameter family. It supplies a sharper thermal term, an exact-saddle relative expansion to arbitrary fixed order, real and integer inversion, and a constructive all-orders inverse-logarithmic hierarchy for A022629.

Read `article/fixed-power-partition-asymptotics.pdf`. Its editable LaTeX source is adjacent. `build.sh` rebuilds the PDF with an ordinary TeX Live installation and the standard packages named in the source.

## Reproduce the checks

Run `python verify.py` from any working directory. Python 3, SymPy and mpmath are needed for the producer checks; all three independent checkers use the Python standard library only. Verification checks the exact file manifest, proof-approval links, five complete checker replays, eighteen independently generated formal coefficients, and rejection of Python's `-O` mode. Every checker runs in a temporary directory; no bundled receipt is overwritten. Elapsed timing fields are excluded from deterministic comparisons.

The exact checks compare finite-product and logarithmic-derivative coefficient recurrences. The numerical comparisons use high precision and exact integer coefficients, but are not certified interval calculations. They corroborate the displayed ordinary analytic proofs and are not proof dependencies.

## What is established

- Fixed alpha > 0 and integer beta >= 0 for product (1+k^alpha q^k)^(k^beta)
- Exact-saddle expansion to each fixed algebraic order, with an ordinary integrated-remainder proof
- Explicit thermal and Lambert-W inverse corrections
- Every fixed inverse-logarithmic order for A022629, with exact coefficients through six orders included
- Eventual positive-real saddle inverses and controlled integer threshold brackets

The asymptotic constants depend on fixed parameters and truncation order. They have not been made effective. An exponentially complete transseries, convergence of a formal hierarchy, uniformity at zero tilt, proof-assistant verification and a literature-wide priority claim are not asserted.

## Review and provenance

The five files in `proofs/` are immutable mathematical source snapshots. Their historical “proposed” or “pending” status lines are superseded by the independent approvals in `audits/independent/`. The integrated report has its own review record. Current OEIS conjectures are credited to their stated author, and related fixed versus shrinking-tilt literature is discussed in Section 9. No external submission or publication was made as part of this work.

`checks/producer/` contains the producer's exact/numerical checks and symbolic generator. `audits/independent/` contains independently written standard-library checkers, mathematical reviews, and pinned receipts. `SHA256SUMS` covers every other packaged file.
