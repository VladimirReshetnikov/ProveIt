# The Largest Jump Is Almost Maximal
## An algebraic boundary law for random 132-avoiding permutations

Research report prepared for Vladimir Reshetnikov, September 29, 2026.

## Main results

For a uniform 132-avoiding permutation of size n, let M_n be the largest
absolute difference between adjacent entries and D_n = n - M_n.

The article proves a limiting positive-integer law D with an explicit
algebraic probability generating function. Writing s = sqrt(1-z) and
r = sqrt((1+s)/2), it is

    G(z) = (1-s)(4+8s+3s^2-s^2 r) / (4(1+2s)(1+s)^2).

The total-variation distance is Theta(n^(-1/2)), with an explicit finite
upper bound and asymptotic constant bounds 3/sqrt(pi) and
4 sqrt(2)/sqrt(pi). The limiting tail is P(D>k) ~ 3/sqrt(pi k),
P(D=1)=7/48, and the integer median is 9.

For d -> infinity with d=o(n), the number a_n^(n-d) of avoiders whose
jumps are at most n-d satisfies

    a_n^(n-d)/C_n ~ 3/sqrt(pi d),
    a_n^(n-d) ~ (3/pi) 4^n / (n^(3/2) sqrt(d)).

A uniform absolute estimate and second-order limiting tail expansion are
also proved. The finite deficit has convergent p-th moments for p<1/2,
E sqrt(D_n) = 3/(2 sqrt(pi)) log(n)+O(1), and E D_n^p = Theta(n^(p-1/2))
for p>1/2. In particular E D_n=Theta(sqrt(n)).

## Relation to ProveIt and status

The report extends the adjacency-bounded 132-avoiders topic under
SetTheory/Cardinals/docs/reports/enumerative-combinatorics/. Its existing
README expressly excludes a joint limit in n and m. This paper treats
the boundary and growing sublinear deficit regimes, not the entire
bulk or fixed-m spectral problem.

These are written research proofs with exact finite regression checks,
not Lean/Rocq-certified theorems. No claim of external peer review or
exhaustively verified publication priority is made. No theorem from an
unrefereed repository report is assumed as a black box. See SOURCES.md
and PROOF_STATUS.md.

## Files

- article.tex, article.pdf: complete article with embedded bibliography.
- build.sh: three-pass pdfLaTeX build with temporary auxiliary directory.
- code/model.py: exact Catalan, endpoint, skeleton, and rational-series code.
- code/verify.py: standard-library exact finite verifier.
- code/verify_symbolic.py: optional SymPy identity and expansion checks.
- code/make_data.py: regenerate rational coefficients and small exact counts.
- code/plot_results.py: optional Matplotlib figure regeneration.
- data/verification.json, data/verification.txt: recorded core test result.
- data/symbolic_verification.json: recorded exact symbolic result.
- data/limit_probabilities.csv: first 256 rational probabilities, with decimals.
- data/finite_histograms.csv: exact finite distributions for n=2 through 12.
- data/extreme_jump_exact.csv: exact first-mass checks at larger sizes.
- figures/: retained PDF and PNG figures.
- SOURCES.md, PROOF_STATUS.md, VALIDATION.md: provenance and audit.
- requirements-optional.txt: tested optional environment versions.

## Rebuild the PDF

A reasonably complete TeX Live or MiKTeX installation is needed, including
amsmath, amsthm, cleveref, tcolorbox, hyperref, lmodern, and microtype.
The Python packages are not needed to rebuild the PDF because figures
are retained.

    ./build.sh

Or run `pdflatex article.tex` three times in the package directory.
The shell script keeps intermediate files out of the package. A manual
build leaves .aux, .log, .out, and .toc files beside the article.

## Reproduce the computations

Python 3.10+; no third-party packages for the core tests or data generation:

    python code/verify.py
    python code/make_data.py

Do not run the verifier with `python -O`: it uses assertions. The run
regenerates data/verification.json; make_data.py overwrites its output CSVs.
The recorded text log can be refreshed with
`python code/verify.py > data/verification.txt`.

Optional:

    python -m pip install -r requirements-optional.txt
    python code/verify_symbolic.py
    python code/plot_results.py

Run on a copy to preserve the original recorded files. Enumeration is
exponential and is intentionally restricted to small n. Coefficients
are exact fractions; plots and decimal columns are illustrative, not
interval certificates.

## Finite verification scope

The recorded core suite passed: 31 independent clipping coefficient checks,
40 positive probability coefficients, the exact median, brute-force
agreement through n=8 (2,055 avoiders), and 269,402 reconstruction tests
across all 804 skeletons of costs 2 through 7. Cross-cost injectivity
and all asymptotic claims rely on the proofs, not finite testing.

The symbolic suite verifies the state/radical identity, an algebraic
certificate, six singular expansion coefficients, and the two refined
transfer constants. Both suites report PASS.
