"""Immutable-release, standard-library replay in normal and optimized Python.

Usage: python -B replay.py --output /tmp/new-report20-replay
Output must be a new directory outside this release. No dependency fallback.
"""
import sys
sys.dont_write_bytecode = True
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from verify_release import ROOT, verify, require

SCRIPTS = (
    'verify_provenance.py', 'independent_expansion.py', 'artifact_checks.py',
    'check_example.py', 'test_interface.py', 'test_schema.py', 'test_guards.py',
    'audit/independent_audit.py', 'universal_slots.py', 'independent_expansion.py',
    'verify_provenance.py',
)
SAMPLES = ('example-polynomial.json', 'example-witness.json', 'example-receipt.json')
# A fresh interpreter receives only the selected copy plus its standard library.
BOOTSTRAP = r'''
import sys, runpy
from pathlib import Path
sys.dont_write_bytecode = True
try:
    import resource
except ImportError:
    resource = None
if resource is not None:
    resource.setrlimit(resource.RLIMIT_CPU, (240, 240))
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
script = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(script.parent))
runpy.run_path(str(script), run_name='__main__')
'''


def prepare_output(output, root=ROOT):
    root = Path(root).resolve()
    if output is None:
        temporary_parent = Path(tempfile.gettempdir()).resolve()
        require(temporary_parent != root and root not in temporary_parent.parents,
                'system temporary directory must be outside the release')
        return Path(tempfile.mkdtemp(prefix='report20-replay-'))
    path = Path(output).expanduser().absolute()
    for ancestor in (path,) + tuple(path.parents):
        require(not ancestor.is_symlink(), 'symlink output path rejected')
    actual = path.resolve()
    require(actual != root and root not in actual.parents, 'replay output must be outside the release')
    require(not path.exists(), 'replay output already exists; choose a new directory')
    require(path.parent.is_dir(), 'output parent must already exist')
    path.mkdir()
    return path


def run_script(script, optimized, log):
    command = [sys.executable, '-I', '-S', '-B'] + (['-O'] if optimized else [])
    command += ['-c', BOOTSTRAP, str(script)]
    env = {k: v for k, v in os.environ.items() if not k.startswith('PYTHON') and k != 'LAZY_EVALUATOR_PATH'}
    started = time.monotonic()
    with Path(log).open('wb') as stream:
        completed = subprocess.run(command, cwd=script.parent, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, timeout=300)
    require(completed.returncode == 0, 'replay failed: ' + str(script) + '; see ' + str(log))
    return dict(script=script.name, optimized=optimized, seconds=round(time.monotonic() - started, 3))


def replay(output=None, root=ROOT):
    root = Path(root).absolute()
    integrity = verify(root)
    output = prepare_output(output, root)
    original = root / 'reproducibility'
    baseline = {name: (original / name).read_bytes() for name in SAMPLES}
    all_runs = []
    for optimized in (False, True):
        mode = 'optimized' if optimized else 'normal'
        copied = output / mode
        shutil.copytree(original, copied)
        logs = output / (mode + '-logs')
        logs.mkdir()
        for index, name in enumerate(SCRIPTS):
            result = run_script(copied / name, optimized, logs / (str(index).zfill(2) + '-' + Path(name).stem + '.log'))
            all_runs.append(result)
            for sample, expected in baseline.items():
                require((copied / sample).read_bytes() == expected, 'regenerated sample byte mismatch: ' + sample)
        require(not list(copied.rglob('__pycache__')), 'unexpected replay bytecode')
    for name in SAMPLES:
        require((output / 'normal' / name).read_bytes() == (output / 'optimized' / name).read_bytes(),
                'normal/optimized sample mismatch')
    # Integrity attacks are separate from the mathematical suites, both modes.
    for optimized in (False, True):
        mode = 'optimized' if optimized else 'normal'
        result = run_script(root / 'release_checks.py', optimized, output / (mode + '-release-checks.log'))
        all_runs.append(result)
    verify(root)
    result = dict(status='passed', python=sys.version.split()[0], output_directory=str(output),
                  source_release_unchanged=True, exact_regenerated_sample_bytes=True,
                  modes=['normal', 'optimized'], scripts=all_runs, integrity=integrity,
                  sample_sha256={name: sha256(raw).hexdigest() for name, raw in baseline.items()},
                  limits=dict(subprocess_wall_seconds=300, unix_cpu_seconds=240, unix_address_space_bytes=2 * 1024**3,
                              unix_output_file_bytes=64 * 1024**2))
    (output / 'replay-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', help='new external directory; default is a fresh OS temporary directory')
    args = parser.parse_args()
    print(json.dumps(replay(args.output), indent=2))
