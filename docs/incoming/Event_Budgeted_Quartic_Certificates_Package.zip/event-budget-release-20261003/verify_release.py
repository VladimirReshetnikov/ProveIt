"""Verify every delivered byte, exact inventory, and mandatory local dependencies.

This is a consistency checker, not an external digital signature. Trust a separately
obtained archive digest when authenticity matters. Standard library only.
"""
from hashlib import sha256
import gzip
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).absolute().parent
MANIFEST = 'release-manifest.json'
DIGEST = MANIFEST + '.sha256'
MAX_FILES = 512
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TREE_BYTES = 128 * 1024 * 1024
EVALUATOR = '42e8aa65c05fcf373a03a02be51ebb89a4fdcb1f1070ad776ffe1e8e99049c61'
COMPILER = 'f95a6028c9d3cc6f8b0b497cfc0cad68104da6d70e55205df04ad234e5d0c76f'
SOURCE = 'fa61d06178d718511232a80a05e02192d940fde3c273f0c202f0623253b2ade3'
SOURCE_GZIP = '2e21ed646509581a26503307e7af092076c95fca2125d683bd0a8775230e0757'
SOURCE_BYTES = 32034272
PINS = {
    'reproducibility/lazy_reversible.py': EVALUATOR,
    'reproducibility/frozen_reversible_binary.py': COMPILER,
    'reproducibility/source.json.gz': SOURCE_GZIP,
    'reproducibility/scheduler_reference.py': '2a9f4add4d527c58921c33291c4164767709b6d4570959edc2a895f8f35b76ea',
    'reproducibility/example_emitter.py': 'f40ebf03dfe8ff5fdad9cf86bde1c3c46c7679b64b344b5e2fea5d6040a3cedc',
    'reproducibility/check_example.py': '0229f30fac4e39bb03b4fcb878d5add6dae420776b2a7b5b80a4f564ecb3fd7a',
    'reproducibility/audit/independent_audit.py': '98be498e1a8e0ed3532583c798c36ca93dfa233a9769837666fb47f10b4ab226',
    'reproducibility/example-polynomial.json': 'd830421f1e0486896fd0f8377e681b5d91f66f1e1d0ed4e615aeef6387b1be71',
    'reproducibility/example-witness.json': 'ed4d3479ba826f944d37d4b1ed9e2160ae8e7f30c20d4c3d8085199cb20109c9',
    'reproducibility/PROOF.md': 'd74157254a36e53c1568cea383cdcc46dd73adca48a1a9a7eee4e46b51b73922',
    'reproducibility/dependencies/report19-proof.md': '3845793b205fe1cbf88d018472b3f740ff506fa391f89fb79ad37dad1f41fe18',
    'reproducibility/dependencies/report8-core.tex': '3a4c6b5fdd18d569fd50b36dd79652429c84773d02a819442ef32a020ba7639e',
    'reproducibility/dependencies/report8-semilinearity.tex': '9114ba954d8878772afd3f65837cfbc668ff8f03e3c26c921d48633dd52561b7',
    'reproducibility/provenance/producer-manifest.json': '552c2324d82013f925009b5a5d1fc65823d9ae712563073783e680f28f349564',
}


def require(ok, detail):
    if not ok:
        raise ValueError(detail)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def load_json(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def relative_name(name):
    require(type(name) is str and name and '\\' not in name and ':' not in name,
            'invalid relative path')
    path = Path(name)
    require(not path.is_absolute() and all(p not in ('', '.', '..') for p in name.split('/')),
            'invalid relative path: ' + name)
    require(path.as_posix() == name, 'noncanonical path: ' + name)
    return name


def inventory(root):
    root = Path(root).absolute()
    require(not root.is_symlink() and root.is_dir(), 'root must be an ordinary directory')
    files, directories = {}, set()
    total = 0
    for base, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs + names):
            path = Path(base) / name
            rel = relative_name(path.relative_to(root).as_posix())
            mode = path.lstat().st_mode
            require(not stat.S_ISLNK(mode), 'symlink rejected: ' + rel)
            if stat.S_ISDIR(mode):
                directories.add(rel)
            else:
                require(stat.S_ISREG(mode), 'nonregular file rejected: ' + rel)
                size = path.stat().st_size
                require(size <= MAX_FILE_BYTES, 'file size limit: ' + rel)
                total += size
                require(total <= MAX_TREE_BYTES, 'tree size limit')
                files[rel] = path
                require(len(files) <= MAX_FILES, 'inventory entry limit')
    return files, directories


def check_pins(root):
    root = Path(root)
    for name, expected in PINS.items():
        path = root / name
        require(path.is_file() and not path.is_symlink(), 'missing ordinary pinned dependency: ' + name)
        require(sha256(path.read_bytes()).hexdigest() == expected, 'dependency pin mismatch: ' + name)
    with gzip.open(root / 'reproducibility/source.json.gz', 'rb') as stream:
        raw = stream.read(SOURCE_BYTES + 1)
    require(len(raw) == SOURCE_BYTES and sha256(raw).hexdigest() == SOURCE,
            'uncompressed universal source pin mismatch')
    return dict(evaluator_sha256=EVALUATOR, compiler_sha256=COMPILER,
                universal_source_sha256=SOURCE, universal_source_bytes=SOURCE_BYTES)


def verify(root=ROOT):
    root = Path(root).absolute()
    observed, directories = inventory(root)
    require(MANIFEST in observed and DIGEST in observed, 'missing release manifest or its digest')
    raw = observed[MANIFEST].read_bytes()
    require(len(raw) <= 1024 * 1024, 'manifest size limit')
    expected_digest = sha256(raw).hexdigest() + '  ' + MANIFEST + '\n'
    require(observed[DIGEST].read_text() == expected_digest, 'manifest digest mismatch')
    manifest = load_json(raw)
    require(type(manifest) is dict and set(manifest) == {'schema', 'files'}, 'manifest shape')
    require(manifest['schema'] == 'report20-exact-inventory-v1', 'manifest schema')
    entries = manifest['files']
    require(type(entries) is dict and 1 <= len(entries) <= MAX_FILES - 2, 'manifest file map')
    for name, entry in entries.items():
        relative_name(name)
        require(name not in (MANIFEST, DIGEST), 'self-referential manifest entry')
        require(type(entry) is dict and set(entry) == {'bytes', 'sha256'}, 'manifest entry shape: ' + name)
        require(type(entry['bytes']) is int and 0 <= entry['bytes'] <= MAX_FILE_BYTES, 'manifest byte count')
        require(type(entry['sha256']) is str and len(entry['sha256']) == 64 and
                all(c in '0123456789abcdef' for c in entry['sha256']), 'manifest digest syntax')
    expected = set(entries) | {MANIFEST, DIGEST}
    require(set(observed) == expected, 'inventory mismatch: extra=' + str(sorted(set(observed) - expected)) +
            ' missing=' + str(sorted(expected - set(observed))))
    wanted_dirs = {p.as_posix() for name in expected for p in Path(name).parents if p != Path('.')}
    require(directories == wanted_dirs, 'directory inventory mismatch: extra=' +
            str(sorted(directories - wanted_dirs)) + ' missing=' + str(sorted(wanted_dirs - directories)))
    for name, entry in entries.items():
        raw = observed[name].read_bytes()
        require(len(raw) == entry['bytes'] and sha256(raw).hexdigest() == entry['sha256'],
                'file content mismatch: ' + name)
    pins = check_pins(root)
    return dict(status='passed', files_verified=len(entries), **pins)


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
