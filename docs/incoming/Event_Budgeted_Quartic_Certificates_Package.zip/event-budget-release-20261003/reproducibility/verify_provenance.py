"""Check frozen producer hashes and each documented local adaptation."""
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRODUCER_MANIFEST = '552c2324d82013f925009b5a5d1fc65823d9ae712563073783e680f28f349564'
PRODUCER_SUMS = 'edbe423e63cd6a55f827c5b641e61df7e00dcecaae48fe6eac5f009d2aa4aff1'
ADAPTED = {'PROOF.md', 'scheduler_reference.py', 'audit/reviewed-hashes.txt'}


def require(ok, detail):
    if not ok:
        raise ValueError(detail)


def main():
    p = HERE / 'provenance'
    raw = (p / 'producer-manifest.json').read_bytes()
    require(sha256(raw).hexdigest() == PRODUCER_MANIFEST, 'producer manifest pin')
    sums = (p / 'producer-SHA256SUMS').read_bytes()
    require(sha256(sums).hexdigest() == PRODUCER_SUMS, 'producer checksum-list pin')
    manifest = json.loads(raw)
    expected = {row['path']: row for row in manifest['files']}
    require(len(expected) == 33, 'producer manifest count')
    provenance = json.loads((HERE / 'PROVENANCE.json').read_text())
    require(set(provenance['files']) == set(expected) - {'README.md', 'verify_bundle.py'}, 'portable source inventory')
    changed = set()
    for name, row in provenance['files'].items():
        require(row['original_sha256'] == expected[name]['sha256'], 'original hash: ' + name)
        portable = (HERE / name).read_bytes()
        actual = sha256(portable).hexdigest()
        require(actual == row['portable_sha256'], 'portable hash: ' + name)
        require(row['adapted'] == (actual != row['original_sha256']), 'adaptation flag: ' + name)
        if row['adapted']:
            changed.add(name)
        else:
            require(len(portable) == expected[name]['bytes'], 'original byte count: ' + name)
    require(changed == ADAPTED, 'unexpected source adaptations')
    for name, row in provenance['dependencies'].items():
        require(sha256((HERE / name).read_bytes()).hexdigest() == row['sha256'], 'dependency provenance: ' + name)
    old = provenance['superseded_verifier']
    require(old['original_sha256'] == expected['verify_bundle.py']['sha256'], 'original verifier hash')
    require(sha256((HERE / old['carried_as']).read_bytes()).hexdigest() == old['original_sha256'], 'carried verifier source')
    readme = provenance['documentation']['README.md']
    require(readme['original_sha256'] == expected['README.md']['sha256'], 'original README hash')
    require(sha256((HERE / 'README.md').read_bytes()).hexdigest() == readme['portable_sha256'], 'portable README hash')
    result = dict(status='passed', original_manifest_files=len(expected),
                  carried_source_artifacts=len(provenance['files']),
                  byte_preserved_dependencies=len(provenance['dependencies']),
                  producer_manifest_sha256=PRODUCER_MANIFEST,
                  adapted_original_files=sorted(changed))
    (HERE / 'provenance-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
