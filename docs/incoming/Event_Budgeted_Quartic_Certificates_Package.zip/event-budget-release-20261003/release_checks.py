"""Reject tampering, extra files/directories, links, and dependency substitution.

Runs only on disposable external copies. Invoke with -B in both normal and -O.
"""
import sys
sys.dont_write_bytecode = True
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from verify_release import ROOT, MANIFEST, DIGEST, verify, require
from replay import prepare_output


def reseal_without_pins(root):
    # Adversarial helper: changing a self-declared manifest cannot defeat a pin.
    paths = sorted(p for p in root.rglob('*') if p.is_file() and p.name not in (MANIFEST, DIGEST))
    entries = {}
    for path in paths:
        raw = path.read_bytes()
        entries[path.relative_to(root).as_posix()] = dict(bytes=len(raw), sha256=sha256(raw).hexdigest())
    raw = (json.dumps(dict(schema='report20-exact-inventory-v1', files=entries), indent=2) + '\n').encode()
    (root / MANIFEST).write_bytes(raw)
    (root / DIGEST).write_text(sha256(raw).hexdigest() + '  ' + MANIFEST + '\n')


def must_reject(fn, label):
    try:
        fn()
    except (ValueError, FileNotFoundError, NotADirectoryError):
        return
    raise RuntimeError('accepted integrity attack: ' + label)


def main():
    verify(ROOT)
    names = []
    with tempfile.TemporaryDirectory(prefix='report20-integrity-') as temp:
        parent = Path(temp)
        def trial(label, mutate):
            target = parent / label
            shutil.copytree(ROOT, target)
            mutate(target)
            must_reject(lambda: verify(target), label)
            names.append(label)
            shutil.rmtree(target)
        trial('changed-sample', lambda p: (p / 'reproducibility/example-witness.json').write_text('[0]\n'))
        trial('missing-sample', lambda p: (p / 'reproducibility/example-polynomial.json').unlink())
        trial('extra-file', lambda p: (p / 'extra.txt').write_text('unlisted'))
        trial('extra-hidden-file', lambda p: (p / '.unlisted').write_text('unlisted'))
        trial('extra-empty-directory', lambda p: (p / 'unexpected-empty').mkdir())
        trial('extra-bytecode', lambda p: ((p / '__pycache__').mkdir(), (p / '__pycache__/rogue.pyc').write_bytes(b'bad')))
        trial('file-symlink', lambda p: ((p / 'reproducibility/example-witness.json').unlink(),
                                       (p / 'reproducibility/example-witness.json').symlink_to(ROOT / 'reproducibility/example-witness.json')))
        trial('directory-symlink', lambda p: (p / 'linked-directory').symlink_to(p / 'reproducibility', target_is_directory=True))
        trial('dangling-symlink', lambda p: (p / 'dangling').symlink_to('no-such-file'))
        trial('bad-manifest-digest', lambda p: (p / DIGEST).write_text('0' * 64 + '  ' + MANIFEST + '\n'))
        def bad_path(p):
            data = json.loads((p / MANIFEST).read_text())
            data['files']['../escape'] = dict(bytes=0, sha256=sha256(b'').hexdigest())
            raw = (json.dumps(data, indent=2) + '\n').encode()
            (p / MANIFEST).write_bytes(raw)
            (p / DIGEST).write_text(sha256(raw).hexdigest() + '  ' + MANIFEST + '\n')
        trial('manifest-traversal', bad_path)
        for name in ('lazy_reversible.py', 'frozen_reversible_binary.py', 'source.json.gz'):
            def corrupt(p, name=name):
                path = p / 'reproducibility' / name
                path.write_bytes(path.read_bytes() + b'\n')
                reseal_without_pins(p)
            trial('resealed-pin-' + name.replace('.', '-'), corrupt)
        def missing_pin(p):
            (p / 'reproducibility/lazy_reversible.py').unlink()
            reseal_without_pins(p)
        trial('resealed-missing-dependency', missing_pin)
        must_reject(lambda: prepare_output(ROOT / 'inside-output', ROOT), 'internal replay output')
        names.append('internal-output')
        existing = parent / 'existing'
        existing.mkdir()
        must_reject(lambda: prepare_output(existing, ROOT), 'existing replay output')
        names.append('existing-output')
        link = parent / 'link'
        link.symlink_to(parent / 'existing', target_is_directory=True)
        must_reject(lambda: prepare_output(link / 'new', ROOT), 'symlink replay output')
        names.append('symlink-output')
        # Import-time pins must reject changed dependencies before executing them,
        # without relying on the release manifest check or an environment override.
        for name, import_name in [('lazy_reversible.py', 'scheduler_reference'),
                                  ('frozen_reversible_binary.py', 'lazy_reversible')]:
            target = parent / ('import-' + import_name)
            shutil.copytree(ROOT / 'reproducibility', target)
            marker = parent / ('executed-' + name)
            (target / name).write_text('from pathlib import Path\nPath(' + repr(str(marker)) + ").write_text('BAD')\n")
            code = 'import sys; sys.path.insert(0,' + repr(str(target)) + '); import ' + import_name
            command = [sys.executable, '-I', '-S', '-B'] + ([] if __debug__ else ['-O']) + ['-c', code]
            done = subprocess.run(command, capture_output=True, timeout=30)
            require(done.returncode != 0 and not marker.exists(), 'dependency executed before hash rejection')
            names.append('import-time-pin-' + name)
        # A bogus external override cannot replace the mandatory adjacent module.
        command = [sys.executable, '-I', '-S', '-B'] + ([] if __debug__ else ['-O']) + ['-c',
                   'import sys; sys.path.insert(0,' + repr(str(ROOT / 'reproducibility')) + '); import scheduler_reference']
        env = dict(os.environ, LAZY_EVALUATOR_PATH=str(parent / 'missing-external.py'))
        done = subprocess.run(command, env=env, capture_output=True, timeout=30)
        require(done.returncode == 0, 'external override changed portable local dependency')
        names.append('external-override-ignored')
    verify(ROOT)
    result = dict(status='passed', optimized=not __debug__, checks=len(names), attacks_rejected=names,
                  release_unchanged=True)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
