# Report 20 Event budgeted quartic certificates

This release gives a finite-schema theorem for canonical natural witnesses of exact finite CA iteration, a general fixed-slot scheduler reference, and a complete mass-two sample polynomial exporter. The arbitrary-mass coefficient exporter is **not implemented**.

## Start here

- `report20.pdf`: mathematical report with the explicit primitive construction, complete-witness uniqueness proof, T+K scheduler, and fully charged source, guard-table, coefficient, expansion and bit costs
- `report20.tex`: editable LaTeX source
- `reproducibility/PROOF.md`: companion finite-schema proof
- `reproducibility/example-polynomial.json`: every sample residual coefficient and all 4573 collected expanded quartic monomials
- `reproducibility/example-witness.json`: all 612 natural auxiliary values
- `reproducibility/audit/INDEPENDENT_AUDIT.md`: independent mathematical and executable audit
- `report20-math-review.md`: independent review of the report itself, bound to its LaTeX hash
- `reproducibility/PROVENANCE.json`: original-versus-portable hash records and dependency identities

## Exact claim and limitations

For each fixed accepted source, exact mass n, horizon T, and total changing-factor budget K, the general construction is a sum of squares of quadratic integer residuals. For a fixed admissible sorted canonical input, its natural auxiliary fiber has exactly one point if the literal ordered CA product completes T steps within K changing factors and reaches an optional prescribed endpoint; otherwise it is empty.

The R=T+K rounds pay separately for changing factors and exactly T no-future-change completion checks. Later rounds are forced idle. Every hidden dummy circuit is still uniquely constrained. The source-sized candidate list avoids an F-factor-indexed witness/lookup array, but all source records, finite guard tables, multiplexer operations, and each entire candidate effect are paid.

The candidate-slot count is binom(n,2)[Delta+3+4 max(n-2,0)]. For the pinned universal source at mass five it is 170. That is 170 slots, **not** 170 variables, residuals, or operations. The bound with prefactor 10000 is a conservative mathematical construction bound, not a measured general emitter count. Preprocessing is not polynomial in log J.

The T=0 zero-witness specialization assumes canonical sorted input is externally promised. Enforcing arbitrary input ordering internally needs comparison auxiliaries. The sample exporter uses three natural anchor/gap coordinates, whereas the general theorem uses 2n external signed-pair coordinates. There is no real-witness, unknown-horizon/fixed-arity, finite-fold MRDP, mass-two universality, optimality or novelty claim.

## Replay without installations

Use CPython 3.10 or newer and its standard library on Linux/POSIX with an ordinary filesystem supporting symbolic links. Full replay is tested on that platform; the symlink attack suite also requires symlink creation permission on other systems. From the extracted release directory:

```sh
python3 -B verify_release.py
python3 -B replay.py --output /tmp/report20-replay
```

The output path must be new and outside the release. Omit `--output` to allocate a fresh operating-system temporary directory. Do not redirect logs into the release: its verifier intentionally rejects unlisted files and directories. `-B` prevents Python bytecode files in the sealed tree.

The replay verifies the exact inventory and mandatory dependency pins before execution. It copies reproducibility material to separate ordinary and optimized working directories, runs all suites in both Python modes, checks that regenerated sample files remain byte-for-byte identical, runs explicit integrity/tampering tests in both modes, and verifies the original release again. A successful run writes `replay-receipt.json` and per-script logs only under the chosen external output directory. It uses isolated Python subprocesses and no network access or optional external source paths.

The suites cover:

- all fixed candidate slots and exact scheduler behavior against the pinned literal/lazy factors, including empty/singleton supports, simultaneous occurrences, malformed cascades, underbudgets, padding and multiple steps
- actual finite guards, raw competitors, context rejection and type/interface boundaries
- regeneration binding of source, inputs, T/K, target, arity, variable order, residuals, expansion and decoded output
- an independent coefficient parser and exact residual-square convolution that imports neither emitter nor CA evaluator, and exact evaluation of every residual and the expanded quartic at the supplied witness
- independent factor-schema and scheduler tests over seven sources, including J=17 and interleaved original branch order
- the pinned universal source's 170 mass-five slots and three literal startup microsteps with total-budget scheduling; no eager universal factor array is built and these steps do not complete startup or a Turing transition
- extra/missing files and directories, changed bytes, symlinks, declaration/witness mutations, and missing or changed mandatory dependency pins

The sample input is {-10,-5}, T=1, K=2, target {-9,-4}. Factors 0 and 47 change the support, then a third round certifies absence/completion. Its exact counts are A=189, I=78, Dv=0, G=78, Q=4; V=612 auxiliaries; E=616 residuals; 2013 residual monomials; 9955 ordered-square term occurrences; and 4573 collected quartic monomials. Both exact evaluations are zero. These counts belong only to this small source and specialization.

## Practical safety limits

The independent sample checker limits each JSON file to 16 MiB, values/coefficient magnitudes to 4096 bits, total input-plus-witness arity to 10000, residual rows to 10000, aggregate residual terms to 200000, ordered convolution work to 1000000 term pairs, and T+K to 16. These are practical release-checker limits, not restrictions in the mathematical theorem. The pinned normal tests include 100-digit coordinates and the interface test includes 301-digit coordinates.

Each replay subprocess has a 300-second wall timeout. Where the standard-library Unix resource module is available, CPU time is capped at 240 seconds, address space at 2 GiB, and each output file at 64 MiB. Windows still has the subprocess wall timeout and explicit schema/encoding bounds, but not these Unix rlimits. The release inventory accepts at most 512 files, 64 MiB per file, and 128 MiB total. Universal-source decompression is bounded to its pinned 32034272-byte size plus one byte for overflow detection.

## Integrity and provenance

`release-manifest.json` records every ordinary delivered file except the manifest and its own digest; `release-manifest.json.sha256` binds the manifest. The verifier checks exact file and directory inventories, byte sizes, SHA-256 values, absence of symlinks/nonregular files, and mandatory code/source pins. It rejects unlisted build, log, and bytecode files. The manifest is an internal integrity record, not an external signature; use a separately obtained ZIP digest when provenance of the whole download matters.

The frozen evaluator is byte-identical to Report 19:

`42e8aa65c05fcf373a03a02be51ebb89a4fdcb1f1070ad776ffe1e8e99049c61`

The original frozen compiler is byte-identical:

`f95a6028c9d3cc6f8b0b497cfc0cad68104da6d70e55205df04ad234e5d0c76f`

The uncompressed universal source is pinned to:

`fa61d06178d718511232a80a05e02192d940fde3c273f0c202f0623253b2ade3`

Portable adaptations only replace research dependency resolution with mandatory local imports/references; provenance records distinguish original and adapted hashes. Original releases are not changed. Report 19's dependency proof and Report 8's comparison/division reference sources are included under `reproducibility/dependencies/`. These are local references, not additional files the replay expects elsewhere.

## Rebuild the report

A TeX Live installation with the packages named in the source is needed only for PDF building:

```sh
./build.sh
```

The build uses an external temporary directory, removes its intermediates, and replaces only `report20.pdf`. A different TeX environment may produce different PDF bytes even when the content is identical; that is a local modification and the original manifest will then correctly reject it. `write_manifest.py` is an authoring utility for deliberately creating a new local integrity manifest; running it does not recreate the externally published identity or undo a code/source pin mismatch. Preserve the untouched download for verification.

## Evidence boundaries

The deterministic primitive induction proves uniqueness of the full natural witness, including inactive branches and padding. Finite mutation and differential tests are corroborating implementation evidence. Neither the audit nor replay is proof-assistant verification. A future general coefficient exporter must implement every macro, report its actual primitive ledger, and receive its own independent binding checks.
