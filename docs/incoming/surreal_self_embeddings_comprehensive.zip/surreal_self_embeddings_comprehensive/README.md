# Self-Embeddings of the Surreal Numbers

**Order, simplicity, algebra, topology, exponential structure, and foundations**  
Prepared for Vladimir Reshetnikov — 3 October 2026

The article is a 39-page expanded mathematical study with full written proofs of
its stated deductions, a versioned literature/repository discussion, a
proof-dependency ledger, and 16 further research questions. It incorporates and
extends earlier working notes prepared for this project.

## Files

- `article.pdf`: compiled, searchable PDF with linked contents and references.
- `article.tex`: standalone LaTeX source; bibliography is embedded.
- `verification.py`: deterministic exact finite regression checks, standard library only.
- `verification.json`: recorded passing output, 146,914 assertions.
- `build.sh`: repeat the finite checks and rebuild the PDF.
- `SOURCE_AND_PROOF_AUDIT.md`: source boundaries and mathematical verification status.
- `BUILD_AUDIT.json`: build and layout checks for the delivered PDF.
- `SHA256SUMS.txt`: hashes of the other delivered files.

## Main material

The study distinguishes arbitrary injections; presentation-level maps; order,
birthday, and simplicity embeddings; additive and multiplicative group maps;
field embeddings; Hahn-sum and monomial conditions; valuation, exponential,
omega-map, and omnific constraints; elementary embeddings; internally definable
maps; differential variants; and higher-dimensional extensions.

The main constructive tool is the two-stage Hahn lift from arbitrary increasing
maps to strongly real-linear field embeddings. The article gives bounded and
cofinal proper copies, including a cofinal proper copy fixing every real and
ordinal, and calculates exact fixed fields in the strong weighted sector.

It also treats the continuity/cofinality dichotomy, the collapse of set-indexed
net convergence in the full surreal order topology, zero-derivative field
automorphisms, and an exact ordinary differentiability criterion. Separate
model-theoretic constructions give both bounded and cofinal proper elementary
exponential copies under explicit class-satisfaction and recursion assumptions.

## Proof status

This is an unrefereed research article. A written proof is not a claim of
historical priority, independent peer review, or proof-assistant verification.
The finite checks do not verify transfinite recursion, arbitrary Hahn
summability, full-class epsilon-delta limits, or the elementary-copy constructions.
No new Lean certificate is included, and no repository-wide Lean build was run.

The exponential valuation-rigidity argument and the omnific fraction-field
identity are credited to prior repository work and proved again in the article.
The generic Lean source was inspected separately from the pending concrete
surreal exponential/valuation instantiations.

## Build

With Python 3.10+ and a standard TeX Live installation including the packages in
the preamble:

```sh
bash build.sh
```

The PDF is built in `.build/` and copied to `article.pdf`. For checks alone:

```sh
python3 verification.py
```

An alternate output location and deterministic seed can be supplied:

```sh
python3 verification.py --seed 20261003 --output verification.json
```

The finite JSON output is deterministic for that seed. Byte-for-byte PDF
reproduction may depend on the TeX/font package versions and PDF timestamps.
No separate font files are included.

## Repository snapshot

`VladimirReshetnikov/ProveIt`  
`51b0a69d7385a786661e0169dc13ee7ab02b921c`

The repository was read through its connector. It was not modified.
