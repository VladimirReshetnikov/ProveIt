# The Macroscopic Jump Law

**Exact rare-event profiles and moment constants for random 132-avoiding permutations**

Research article prepared for Vladimir Reshetnikov, September 29, 2026.

## Main result

For a uniformly chosen 132-avoiding permutation of size n, let M_n be its
largest absolute adjacent difference and D_n = n - M_n. The article proves

    sqrt(n) P(D_n > u n) -> (3/sqrt(pi)) (1-2u)/sqrt(u(1-u))

for 0 < u < 1/2, and zero for 1/2 <= u <= 1. The convergence is uniform
on every interval bounded away from u = 0. It also determines a marked
rare-event measure that records the last entry.

Consequences include

    E D_n ~ (3/sqrt(pi)) sqrt(n)
    Var D_n ~ 3(4-pi)/(4 sqrt(pi)) n^(3/2)

and explicit leading constants for every moment of order p > 1/2.
When permutations are reweighted in proportion to D_n,
`sqrt(D_n/(n-D_n))` converges to Uniform[0,1]. This is a size-biased law,
not the ordinary uniform-permutation law.

A separate construction gives polynomial lower bounds at every fixed
proportional adjacency bound, including regimes below half size. Matching
bounds and exact equivalents in those smaller-jump regimes remain open.

## Relation to ProveIt

Repository commit: `1ee53d57de253d16cdaad79d1f54bbd95d76d682`.

Relevant directory:

    SetTheory/Cardinals/docs/reports/enumerative-combinatorics/
    adjacency-bounded-132-avoiders/

The combined report's Part III, *The Largest Jump Is Almost Maximal*, leaves
the bulk profile and exact supercritical moment constants open in Sections
32.1 and 32.2. This article answers those questions and credits the earlier
stopping-word construction. All finite ingredients used in the new proofs
are rederived; none of the earlier report's asymptotic claims is assumed.
See `SOURCES.md` and Appendix A for provenance and the limits of the literature check.

## Contents

- `article.tex`, `article.pdf`: complete article, proofs, ten research directions.
- `build.sh`: three-pass pdfLaTeX build using a temporary auxiliary directory.
- `code/verify.py`: exact finite checks; Python standard library only.
- `code/simulate.cpp`: C++17 uniform Catalan-tree sampler and statistic evaluator.
- `code/plot_results.py`: optional NumPy/Matplotlib figure regeneration.
- `data/verification.json`: recorded exact-check outcome.
- `data/exact_small_distributions.csv`: integer-count deficit distributions.
- `data/simulation.csv`: numerical illustrations, with sampling standard errors.
- `figures/`: retained vector figures and PNG previews.
- `SHA256SUMS`: checksums of shipped files, excluding itself.

## Build the article

From this directory, on a system with pdfLaTeX and the packages listed in
`article.tex`:

```sh
./build.sh
```

On systems without Bash, run `pdflatex article.tex` three times from this
directory. The retained figures mean that Python is not required for the
PDF build. Rebuilding is not promised to produce a byte-identical PDF:
TeX metadata and toolchain versions can change its bytes.

## Run the exact checks

```sh
python3 code/verify.py
```

Tested with Python 3.13.5 in the creation environment. The script uses only
standard-library modules and is intended for Python 3.10 or later. It checks
all 82,499 avoiders of sizes 1 through 11, independently filters all ordinary
permutations through size 8, verifies both endpoint formulas and the root
recursion, and checks the finite tail bound. It also checks 101 stopping-cost
tails and all 2,352 sampler degree words through size 6. It writes the JSON
report and exact CSV data. Do not interpret finite tests as a proof of an
infinite or asymptotic theorem.

## Reproduce the numerical illustrations

```sh
g++ -O3 -std=c++17 code/simulate.cpp -o simulate
./simulate > data/simulation.csv
python3 code/plot_results.py
```

The sampler uses a fixed seed and five hard-coded size/sample-count pairs.
The retained run comprises 675,000 pseudorandom samples. Standard-library
implementations of `std::shuffle` may produce different streams with the
same engine seed. Numerical values are illustrations, not interval
certificates. Error bars measure estimated sampling error, not finite-size
bias. The printed table in `article.tex` is tied to the shipped CSV; rerunning
samples does not automatically update that table. The plotting step needs
NumPy and Matplotlib; the exact verifier and PDF build do not.

## Research status

The theorems have written proofs and supporting exact finite checks. They
are not Lean- or Rocq-verified and have not been independently refereed.
The advances are stated relative to the inspected repository's explicit
scope, not as a certified claim of first publication. The critical centered
half-moment, exact total-variation constant, local lattice asymptotics,
reciprocal-threshold scaling, and the full lower-threshold hierarchy remain
research questions. No repository files were modified by this task.
