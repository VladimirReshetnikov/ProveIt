# Transport-sensitive rigidity in Gowers's approximate-homomorphism argument

Research draft, 6 October 2026.

## Read first

`transport_rigidity.pdf` is the article; `transport_rigidity.tex` is its complete
editable source, including its bibliography. The research focuses on Section 10
of Gowers's 2001 paper, especially the local exactification step in Lemma 10.9.

The comparison is pinned to ProveIt commit:

`ae0e895748209f0dd079c6b5ca6df6c6fc065a81`

## Main proved results

The article proves a coupled-path theorem with exact finite transport profiles.
For a uniform directional defect bound delta and fiber ratio at most kappa,
`2[1 + (k-1) kappa] delta < 1` forces Freiman order k. With additive
fiber-size variation tau, the criterion becomes
`[2k + tau k(k-1)] delta < 1`.

For constant fiber sizes, `delta < 1/(2k)` is sharp for arbitrary selected
direction sets, with an explicit family of cyclic counterexamples at equality.

At the hypotheses recorded for Lemma 10.9, the original parameter range gives
order five, rather than just order two. Retaining the full ambient invariance
from the original construction gives order nine. The article also proves
larger explicit local order-two allowances: `120^(-5)` at the factor-two
interface and `75^(-5)` with the additional ambient invariance. These compare
with the original sufficient threshold `360^(-5)`.

Further sections give a root-law optimization linear program, a normalized
collision-to-mode criterion, weighted and nonabelian extensions, and eight
proposed research questions.

## Status and limitations

* These are local structural results, not a new global Szemeredi bound.
* The sharp claim is about the directional defect statistic defined in the
  article, not an averaged multiplication test or the original eta parameter.
* Orders five and nine are guaranteed orders, not asserted maximal orders.
* Complete mathematical proofs are included, but the draft has not undergone
  independent peer review. Priority over all existing literature is not claimed.
* No Lean build, axiom audit, or new Lean formalization was executed. The
  formalization plan is prospective and contains no purported compiled code.
* The finite tests use cyclic groups. They are supporting checks, not proofs
  for all groups or a separate test of every weighted/nonabelian extension.
* The original paper and repository files are referenced, not redistributed.
  Nothing in the user's repository has been changed.

## Files

- `transport_rigidity.tex`, `transport_rigidity.pdf`: article source and PDF.
- `checks.py`: exact-arithmetic, standard-library verification script.
- `verification.json`: actual successful output from the supplied script.
- `FORMALIZATION.md`: proposed integration interface and proof obligations.
- `source_manifest.json`: inspected sources, exact commit, and source blob IDs.
- `Makefile`: PDF build and verification commands.

## Reproduce

Python 3.10 or later, with no external Python packages:

```sh
python3 checks.py --output verification.json
```

LaTeX with the packages listed in the preamble (including newtx, amsmath,
amsthm, mathtools, microtype, enumitem, TikZ, hyperref, and bookmark):

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error transport_rigidity.tex
```

The bibliography is embedded, so no BibTeX step is needed. `make check` and
`make pdf` invoke these commands. `make clean` removes LaTeX build intermediates
but preserves the PDF. Once dependencies are installed, neither command needs
network access.

## Verification coverage

The recorded run includes 419,904 exhaustive order-two relations across 6,561
function pairs, 24,200 additional relation/starting-law pairs on 220 fibered
instances, 16,472 exact primal-dual profile comparisons, 9,059 applicable
nested-agreement conversions, 1,936 collision bounds, 76 sharp examples, and
999 general-order endpoint checks. Assertions use integers and rational
fractions; floating point is used only to display one already exact ratio.
