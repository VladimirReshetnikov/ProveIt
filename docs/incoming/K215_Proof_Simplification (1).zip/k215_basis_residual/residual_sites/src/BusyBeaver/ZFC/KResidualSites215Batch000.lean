import BusyBeaver.ZFC.KSource215Program
import BusyBeaver.ZFC.KResidual215

/-! Residual K215 decoder sites, blocks 0 to 11 (319 leaves).
Partition inherited unchanged from generate_sites215_lean.py; checker changed by adapt_sites.py. -/

namespace SetTheory.BusyBeaver.ZFC.KResidualSites215

open RegisterPath RMBisim SiteCoverage KTableCore

/-- 9 leaves. -/
theorem block_0 :
    allSites (KResidual215.residualTest tm215) [false]
      (descend KSource215.t215 [false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 14 leaves. -/
theorem block_1 :
    allSites (KResidual215.residualTest tm215) [false, true]
      (descend KSource215.t215 [true, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 1 leaves. -/
theorem block_2 :
    allSites (KResidual215.residualTest tm215) [false, false, true, true]
      (descend KSource215.t215 [true, true, false, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 1 leaves. -/
theorem block_3 :
    allSites (KResidual215.residualTest tm215) [false, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 1 leaves. -/
theorem block_4 :
    allSites (KResidual215.residualTest tm215) [false, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 52 leaves. -/
theorem block_5 :
    allSites (KResidual215.residualTest tm215) [false, false, true, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, true, false, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 29 leaves. -/
theorem block_6 :
    allSites (KResidual215.residualTest tm215) [true, false, true, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, true, false, true]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 52 leaves. -/
theorem block_7 :
    allSites (KResidual215.residualTest tm215) [false, true, true, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, true, true, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 14 leaves. -/
theorem block_8 :
    allSites (KResidual215.residualTest tm215) [false, false, false, true, true, true, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, true, true, true, false, false, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 27 leaves. -/
theorem block_9 :
    allSites (KResidual215.residualTest tm215) [false, true, false, false, true, true, true, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, true, true, true, false, false, true, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 67 leaves. -/
theorem block_10 :
    allSites (KResidual215.residualTest tm215) [false, true, true, false, false, true, true, true, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, true, true, true, false, false, true, true, false]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

/-- 52 leaves. -/
theorem block_11 :
    allSites (KResidual215.residualTest tm215) [true, true, true, false, false, true, true, true, false, false, true, false, false, true, false, true, true]
      (descend KSource215.t215 [true, true, false, true, false, false, true, false, false, true, true, true, false, false, true, true, true]) = true := by
  exact KResidual215.allSites_of_fast (by decide +kernel)

end SetTheory.BusyBeaver.ZFC.KResidualSites215
