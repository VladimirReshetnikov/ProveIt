# A Catalan Law Behind Growing Shifts

**Three critical scales, an all-orders hierarchy, and uniform Hankel asymptotics**

AI-assisted research prepared for Vladimir Reshetnikov, 29 September 2026.
A continuation of the growing-shift question in ProveIt's Catalan-Hankel reports.

## Read first

`article.pdf` is the complete research article; `article.tex` is its editable,
self-contained LaTeX source. Two included vector figures are its only external
LaTeX inputs. The bibliography is inside the source, so no BibTeX run is needed.

The paper concerns

    D_N^(m)(a,1) = det(a C_(i+j+m) + C_(i+j+m+1)),  0 <= i,j < N,
    C_k = binomial(2k,k)/(k+1).

It normalizes this determinant by its value at a = 0 and studies joint limits
N,m -> infinity with unrestricted relative growth. It does not claim a solution
for arbitrary polynomial multipliers of growing degree.

## Main results and reading map

- **Theorems 5.1 and 7.2:** a uniform bound on the largest normalized inverse
  Jacobi zero, and a size-biased inverse-zero law equal to a shifted and scaled
  Catalan-moment / Marchenko–Pastur distribution in every aspect-ratio regime.
- **Corollary 6.2 and Theorem 8.1:** the sharp relative-exponential threshold
  and its Gaussian correction, followed by every fixed-order critical scale.
  The higher-level renormalizations use exact finite-parameter moments.
- **Theorems 9.1, 10.2, and 11.1:** an algebraic nonlinear free-energy limit,
  a distinct sharp total-variation transition relative to the nominal Poisson
  mean, and a multiplicative prefactor when m/N remains in a positive compact set.

Section 15 proposes ten further research directions, including sharper extreme
zeros, quantitative spectral corrections, multiple moving factors, both endpoint
exponents growing, and a staged Lean formalization.

## Status and scope

The article contains written all-parameter proofs, with classical inputs credited.
It is AI-assisted and unrefereed, and no Lean or Rocq verification is claimed.
The exact audit is finite; it is not a substitute for those proofs. Numerical
values and plots use ordinary floating-point arithmetic, not certified intervals.
The inspected repository states the growing-shift direction as unresolved there;
worldwide first-discovery priority for every formula has not been established.
See `SOURCES.md` and `PROOF_AUDIT.md` for the precise comparison and limitations.

## Reproduce

Use Python 3.10 or newer and a TeX Live installation containing newtx, amsmath,
amsthm, mathtools, microtype, geometry, booktabs, graphicx, xcolor, hyperref,
enumitem, and fancyhdr. The package does not include font files.

From this directory:

```sh
python -m pip install -r requirements.txt
python code/verify.py --output data
python code/make_figures.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, `make all` runs the audit, regenerates the figures, and builds the
PDF. The included figures are sufficient to compile the paper without installing
Python. All mathematical input data are generated locally; no data download or
repository clone is needed.

The exact arithmetic in `verify.py` uses Python's `Fraction`. The complete driver
also imports NumPy and SciPy for its numerical layer. The delivered environment
is recorded in `data/verification_summary.json`; the version constraints in
`requirements.txt` are intended compatibility ranges, not a matrix of tested
installations.

## Files

`code/verify.py` produces the audit summary and four CSV tables.
`code/make_figures.py` regenerates the two vector plots.
`data/critical_scales.csv` compares the two transition profiles.
`data/spectral_moments.csv` compares exact moment ratios with their limits.
`data/free_energy.csv` checks the nonlinear profile.
`data/saddle_prefactor.csv` checks the relative saddle error and N times that error.
`SOURCES.md` records the pinned repository and bounded literature audit.
`PROOF_AUDIT.md` records assumptions, delicate proof steps, and nonclaims.
`BUILD_CHECK.md` records the final compilation and layout checks.
`SHA256SUMS.txt` records checksums for the deliverable files.

The repository was inspected read-only and was not changed.
