# Eventual One Shore Scaling Through Rank Eight

The eight-page report proves eventual actual-rank ultra-log-concavity for every bipartite graph of matching rank at most eight, under common scaling of the right part of a fixed minimum cover. Activities on the entire left shore are one; the fixed right activity vector is arbitrary and strictly positive. The scaling threshold may depend on the graph, cover and field vector.

The proof closes the conditional middle gap for 4+4 covers. Its main new ingredients are rank-three minor-count growth, a parallel-class coefficient identity, and a complete hyperplane-incidence certificate. Combined with the unchanged supporting reports, the persistent-failure bracket is [9,38]. The finite-activity bracket remains [6,38]; general finite-activity ULC at ranks six through eight is not claimed.

Contents:
- Eventual_One_Shore_Scaling_Through_Rank_Eight.pdf: final report
- article.tex and build_local.sh: editable source and local TeX build helper
- code/primary/: complete 46,512-profile transition checker and deterministic certificate
- code/independent/: two fresh coordinate-injection replays and the 330-profile minor-support check
- data/: independent verification summaries
- companion/: unchanged reports77 and78 with their complete source archives and earlier prerequisites
- manifest.json: SHA256 checksums

Run every exact check with Python 3 using only its standard library:

    python -O code/replay_all.py

All mathematical checks use explicit failures and remain active under optimization. The primary checker regenerates its deterministic JSON. The independent replays compare every profile hash; add --save-certificate to refresh their output summaries.

The finite profile table is an exhaustive support reduction for arbitrarily many original rows, not a bounded population-grid test. The minor-growth, row-ordering and parallel-class arguments are ordinary mathematical proofs.

To rebuild the PDF where the standard TeX packages are available:

    bash build_local.sh
