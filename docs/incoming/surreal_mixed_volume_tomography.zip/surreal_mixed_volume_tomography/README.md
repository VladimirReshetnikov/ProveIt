# Mixed-Volume Tomography of Surreal Polytopes

**Determinant ideals, complete scale spectra, and an adaptive–nonadaptive dichotomy**

Research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.

## Contents

- `article.pdf`: the 24-page article.
- `article.tex`: standalone LaTeX source, including the bibliography.
- `code/verify.py`: exact finite checks in Q(t), ordered at positive infinitesimal t.
- `data/verification.json`: the successful run, including counts, seed, and examples.
- `data/build_report.json`: document and verification metadata.
- `SOURCE_AUDIT.md`: repository pin, primary references, and source-review scope.
- `PROOF_AUDIT.md`: assumptions, normalization checks, and non-claims.
- `requirements.txt`, `build.sh`, `build.ps1`: reproduction helpers.
- `SHA256SUMS.txt`: hashes of the delivered files.

## Main mathematical results

The central formula identifies a mixed-volume valuation with the minimum valuation of a determinant choosing one displacement from each input polytope. The proof compares each polytope with a displacement zonotope up to explicit ordinary integer factors.

The displacement module L(P) is the span of P-P over the natural valuation ring O. It is exactly the union of n(P-P) over ordinary positive integers n. The article classifies its one-body scale spectrum, proves a finite reference-dependent recognition theorem using d mixed-volume probes and one volume valuation, and proves that no fixed finite list of planar mixed-area valuation probes determines every module. The obstruction persists after supplying exact area, individual spectrum, real shadow, and the full residue flag.

For planar spectra (a1 <= a2) and (b1 <= b2), the attainable mixed-area valuations are exactly

    a1 + b1 <= mu <= min(a1 + b2, a2 + b1).

Every value in the interval is explicitly realized. Higher-dimensional interactions are reduced to compatible valuations of complementary matrix minors; their general realization problem is not claimed solved.

## Mathematical and verification status

This is an AI-assisted, unrefereed manuscript with complete written proofs of its 27 numbered results. It is not Lean-verified, and independent correctness review and historical priority are not certified. Standard ordered-field polyhedral theory, mixed-volume facts, valuation-ring elimination, and the prior singular-value connection are credited rather than presented as new discoveries. No named major open conjecture is claimed solved.

The finite checks completed **3,196 assertions** with seed **2026093017**. These include 100 independently computed convex-hull mixed areas, valuation-pivot and minor comparisons, 50 adaptive comparisons, 415 rank-two examples, and an 18-body fixed-probe counterexample family. Low-level assertions contribute to the total; it is not a count of independent theorems. These tests are not a proof of the arbitrary-rank statements.

The mathematical setting is finite polytopes over a set-sized real-closed ordered field containing R, with its natural valuation. The nonadaptive obstruction requires a non-Archimedean field. Every finite surreal input fits such a workspace. No proper-class volume measure or spherical-completeness assumption is used.

## Reproduce the checks

Python 3.10 or later is required. The delivered run used SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

The script uses exact rational-function arithmetic, not floating-point substitutions for t. It writes `data/verification.json` and prints the same report. Runtime depends on the machine; the hull and determinant checks are designed for correctness testing, not production performance.

## Compile the article

Use a standard TeX Live or MiKTeX installation with the packages listed in the source. No external figures or bibliography files are required.

```sh
./build.sh
```

On Windows with PowerShell:

```powershell
.\build.ps1
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times. The build helpers place intermediates in `build/` and copy the finished PDF to `article.pdf`.

## Repository context

The inspected ProveIt snapshot was:

    6996fee43cc97b6c16351def7507d59a95bf62f0

The inspection covered the root README, the surreal project and report-guide READMEs, and the Euclidean-three-space report README. No repository build or exhaustive statement-level audit was performed. The article does not depend on unreviewed research claims elsewhere in the repository. See the source audit and the bibliography for exact references.
