# Sharper local structure in Gowers's Szemerédi argument

A research article on explicit local refinements of Section 7 of W. T.
Gowers, *A new proof of Szemerédi's theorem*, and the corresponding
ProveIt development. Prepared 6 October 2026.

## Files

- `gowers_section7_refinements.pdf`: the complete article.
- `gowers_section7_refinements.tex`: self-contained LaTeX source, with embedded bibliography.
- `verify.py`: exact finite regression checks; standard-library Python only.
- `verification_results.json`: the recorded successful run.
- `PROVENANCE.md`: inspected repository snapshot and public primary sources.
- `build.sh`: a three-pass PDF build command.

## Principal results

The article proves a three-sample dense-intersection theorem with core size
at least 7 delta^3 n / (3 sqrt(6)), preserving Gowers's intersection threshold
and 90% good-pair conclusion. It identifies the optimal coefficient for the
associated scalar moment relaxation and the failure of its two-sample score.

The elementary energy reduction retains at least 2^(-3) kappa |A| points and
has relative doubling at most 2^17 kappa^(-6). A separate vertical-fibre
argument improves the order-k Freiman extraction denominator from
8 k C^(4k) to k C^(2k+1).

Together these yield an order-eight restriction of size at least
2^(-295) gamma^103 |B0|, in place of the specified source bound
2^(-1882) gamma^1164 |B0|. The general order-k guarantee is
2^(-(34k+20)) gamma^(12k+7) |B0| / k.

An explicitly marked corollary imports Reiher–Schoen's published theorem
and gives a further parameterized bound, including
3 * 2^(-872) gamma^(137/2) |B0| at order eight. Its stronger density exponent
comes with a worse explicit constant, so it does not uniformly dominate the
self-contained bound.

## Scope and verification

All general mathematical proofs for the elementary route appear in the
article. The classical Plünnecke–Ruzsa input is also proved, with attribution
to Petridis's minimal-growth method. The imported Reiher–Schoen theorem is
clearly separated from that self-contained route.

These are improvements to specified local inequalities, not a claim of a
new world-record Balog–Szemerédi–Gowers theorem or a new global quantitative
Szemerédi bound. Priority for the individual elementary refinements is not
asserted. The scalar sharpness theorem is not claimed to settle the
corresponding extremal problem for realizable codegree matrices.

No new Lean module was compiled, and no repository changes were made. The
article includes a detailed integration plan keyed to the inspected source.
The Python tests are finite regression checks, not general proofs or Lean
verification. The finite-field-vector hashing theorem is proved in the
article but is not included in the finite regression suite.

## Rebuild the article

Run `sh build.sh` from this directory. Alternatively run the following line
three times with a conventional LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error gowers_section7_refinements.tex
```

No BibTeX step is needed. Required packages are listed in the source preamble.

## Reproduce the exact finite checks

Python 3.10 or later is sufficient:

```sh
python3 verify.py --output verification_results.json
```

The test program uses exact integers and fractions, fixed seeds for its
nonexhaustive input families, and no network access. A failed check raises
an exception rather than silently producing a successful report.
