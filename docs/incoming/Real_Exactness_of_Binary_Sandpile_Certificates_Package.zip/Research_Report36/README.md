# Research Report 36: real-exact binary sandpile certificates

Research_Report36.tex and Research_Report36.pdf present the real-exact
strengthening of the earlier binary sandpile cubic. The archived evidence is a
complete byte-exact copy of the frozen real-strengthening review packet.

## Scope and attribution

The result is a proof about each externally fixed finite prism and binary
odometers. Its full nonnegative-real zero set equals the earlier full natural
zero set, possibly empty. The main merged presentation replaces f*g with
f*(g+k+c); the displayed summand count, variable count, degree, collected
monomial support, and collected coefficient height are preserved. The finite
checks corroborate the accompanying proofs; they do not prove the infinite
family theorem. No global novelty or formal Lean-verification claim is made.
See the report and evidence/real/PUBLIC_PRIOR_ART.md for public-source credit.

## Package map

- Research_Report36.tex / Research_Report36.pdf: the standalone article
- evidence/real/: exactly 18 files from the frozen real-strengthening packet,
  as determined by its MANIFEST.json and SHA256SUMS
- evidence/real/approved_base/: unchanged compiler/proof snapshots, selected
  predecessor context only; this is not the complete Report35 packet
- verification/expected-receipts.json: the exact four frozen JSON receipts
- verification/replay-plan.json: two independently implemented replay producers
- verification/source-lineage.json: exact identity and provenance of every
  copied evidence file
- verify_release.py: strict inventory, source-identity, JSON, and replay checker
- tamper_regression.py: external-copy adversarial identity/type regression
- archive_release.py / archive_regression.py: deterministic ZIP creation,
  safe exact-inventory checking, moved extraction replay, and hostile ZIP tests
- build_pdf.py: external deterministic local pdfLaTeX build with shell escape off
- seal_release.py: maintainer utility; never a way to validate received evidence

## Verification

Obtain the ZIP or manifest SHA256 independently from the sender before trusting
this package. The release checksum list cannot authenticate itself.
From the release directory, use Python 3 with bytecode writes disabled:

    python -I -B verify_release.py --verify-only
    python -I -B -O verify_release.py --verify-only
    python -I -B verify_release.py --self-test-types
    python -I -B verify_release.py --replay
    python -I -B -O verify_release.py --replay
    python -I -B tamper_regression.py

The compiler and packaging tools use only the Python standard library.
The main exact checker requires the already installed SymPy 1.14.0; the
independent coefficient/ledger checker uses the standard library. Full replay
enforces SymPy 1.14.0 and installs nothing. No network or upstream repository
code is used by these commands. The full exact branch checks can take minutes.

Every replay creates two fresh external copies. In each copy it removes and
regenerates the main exact receipt and the separate 54-case coefficient/ledger
receipt, in ordinary Python or Python -O. It requires exact recursive JSON
types and values, exact regenerated receipt bytes, equal producer stdout, and
unchanged original bytes, modes, and modification times. Source identities are
checked before any copied producer executes and rechecked between producers.
Finite branch rejections have no independently checked Farkas certificates;
only returned feasible points are independently verified by exact substitution.

## PDF and ZIP

The following outputs must be outside this release; output directories must be
new or empty. Python 3 and installed TeX Live/pdfLaTeX are required for PDF work.

    python -I -B build_pdf.py --output ../report36-pdf-rebuild
    python -I -B archive_release.py --create ../Research_Report36_release.zip
    python -I -B archive_release.py --check ../Research_Report36_release.zip --sha256 INDEPENDENT_ZIP_SHA256 --replay
    python -I -B archive_regression.py --archive ../Research_Report36_release.zip --sha256 INDEPENDENT_ZIP_SHA256

ZIP checking first authenticates the current unpacked tree, then requires the
supplied archive digest, exact inventory, regular-file modes and byte equality
before safe extraction into a new moved directory. The extracted verifier runs
in ordinary and optimized Python, with optional full replay in both modes.
This checks consistency with an independently authenticated local release.
No third-party PDF, browser screenshot, downloaded upstream program, build cache,
or private machine path is needed or included.
