# Rank Six Cores with Two Complete Columns

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

Read **article.pdf** for the theorem and proof; **article.tex** is the source.

## The conclusion

A genuine rank-six graph has a displayed three-plus-three cover, two complete core columns and an arbitrary third core column. Exterior neighborhoods are arbitrary. All left activities are one, and right activities are positive real numbers. For each fixed graph and set of activities, sufficiently large common scaling of the three right-core activities gives strict rank-six ULC.

The new arguments address core-column degrees one and zero. The previously established complete-core and matching-hole results supply degrees three and two. The proof uses the same unit-left convention throughout, so it is a separate extension from the earlier row theorem.

General rank-six ULC for arbitrary finite activities remains open. No uniform scaling threshold, global priority or formal proof-assistant verification is claimed.

## Exact checks

Run these with Python 3 and its standard library:

```sh
python3 code/verify_degree_one_certificate.py
python3 code/check_flag_algebra.py
python3 code/check_degree_one_counts.py
python3 code/check_zero_column_counts.py
```

The optional second implementation uses SymPy:

```sh
python3 code/independent_reconstruction.py
```

The first replay reconstructs all 25 rational polynomial identities from **data/degree_one_certificate.json**, with 1,134 nonnegative terms and strict remainder one. The independent implementation uses a different variable order and constructs neighborhood supports by direct slot assignments. Both raise an explicit exception if any identity or coverage check fails. Neither uses the numerical optimizer that discovered the certificates.

The flag checker verifies the left Hessian determinant, right Schur form and axis-mixture identity exactly. The two graph checkers enumerate endpoint supports directly on 100 deterministic graphs each. All twenty constraints are also checked on 66 coloop-free degree-one examples. These graph checks are regressions, not the proof for arbitrary populations.

Reference JSON outputs are in **data/**. Running a checker writes a new JSON summary beside its source.

## Build and integrity

Compile **article.tex** twice with pdflatex and the packages named in the source. **build_local.sh** supplies the TeX paths used during preparation and writes intermediate files to **build/**.

Run `sha256sum -c SHA256SUMS` to check every shipped file. The package contains no raw internal review correspondence or exploratory optimizer logs.
