# Small Turing machines for Con(ZFC)

Research prepared for Vladimir Reshetnikov and ProveIt, 16 October 2026.

**Start with `zfc_small_machine_research.pdf`.** The complete LaTeX source is
`zfc_small_machine_research.tex`. The report gives the detailed repository
audit, the finite theory and its proof, the machine engineering result, and
the remaining work needed for a state record.

## What this package establishes

1. The smallest publicly submitted and CI-checked construction found in the
   audited sources has **253 binary working states**. It is existing work,
   not a new result of this package. The pinned merged upstream baseline has
   254 states. The terminal state is excluded; all blank-tape initialization
   is included.
2. The finite assignment/class theory **K12 (FAK12 in the working notes)**
   has an ordinary ZFC-formalizable proof of equiconsistency with full ZFC.
   Its direct Skolem form has **28 universal clauses**, 62 literal
   occurrences, two constants, 15 proper function symbols, and two binary
   relations besides identity. The reference code specifies a complete
   equality-aware ground search; only its tiny diagnostic controls were run.
3. A new contiguous-counter initializer, shared cleanup, and exact state
   quotient improve the separate clean compiler controls as follows:

| Input DAG | Initial next-proof | Previous | New final |
|---|---:|---:|---:|
| Original 219 | 0 | 341 | 334 |
| Original 219 | 2 | 343 | 336 |
| Full-logic rebracketed 206 | 0 | 328 | 321 |
| Full-logic rebracketed 206 | 2 | 330 | 323 |
| Decoder 202 | 0 | 313 | 309 |
| Decoder 202 | 2 | 315 | 311 |

**No new machine below 253 states is claimed.** These compiler controls are
larger and retain the existing compiler's proof boundaries. A seven-state
saving in this backend cannot be subtracted from the public253 count.

## Reproduction

Python 3 with its standard library suffices for the new experiments. No
network connection is needed. Keep assertions enabled; do not use `-O`.

```sh
python3 -B verify_artifacts.py
python3 -B theory/finite_assignment_kernel.py --out /tmp/k12-check
python3 -B engineering/verify_saved.py
python3 -B engineering/reproduce.py --output /tmp/zfc-machine-controls
```

The bundle verifier checks the manifest, regenerates the finite clause
payload in a temporary directory and compares it with the delivered data,
then verifies all saved transition quotients and complete blank-tape boots.
The engineering reproducer additionally rebuilds all 18 raw controls from
the supplied vendor inputs, runs all 8,391 symbolic instruction cases per
control, and checks 432 standalone plus 432 shared initializer cases.

To rebuild the report with a conventional TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error zfc_small_machine_research.tex
```

The report reads `theory/data/finite_kernel_clauses.txt` for its complete
clause appendix. Keep that relative path when rebuilding. PDF metadata may
change between builds, so a newly rebuilt PDF need not match the originally
delivered byte hash. The manifest describes the delivered version.

## Contents and limits

- `theory/`: complete axiom/proof notes, clause generator, ideal exhaustive
  search specification, and exact payload/diagnostic data. No whole-kernel
  search was run, no low-state compiler for this payload was produced, and
  no Lean/Coq theorem for this new theory is claimed.
- `engineering/`: complete raw/quotient binary tables, exact state maps,
  initializer proof and formulas, regeneration code, finite verification
  code, and a minimal vendor snapshot with original notices.
- `audit/`: pinned record/source audit, an inspected public Coq CI excerpt,
  independent review of the finite theory, and a full-ZFC composition wrapper.
  `FullZFC253.v` is source-reviewed but was **not separately kernel-built**.
  Its checker prints the exact Coq commands needed after the pinned upstream
  development has been built.
- `artifact_manifest.json`: SHA-256 and byte size of each delivered file.
- `verification_summary.json`: actual checks executed for this delivery.

The generic quotient condition proves same-step preservation on every input
tape; it is independent of the symbolic register-box checker. The new
initializer has an ordinary invariant proof and exact finite replays. The
upstream Coq CI was inspected, but no local Coq executable was available for
an independent kernel rebuild.

## Pins

- ProveIt: `d74c63b0c8d4f35597f1bd5976d941b9f104f94e`
- Upstream merged main: `297ab8df7e5de329605c3875b4934643b371a5e3`
- Public PR20 head: `0d544f2a2e3c18f12278441a74b7879f31cbe856`
- PR20 CI merge: `26bd0b2beeed5c3dd88511e39acd604c235e2f1c`

The PR head and CI merge have the same tree. All claims are scoped to these
audited revisions, rather than an unbounded assertion about later work.

## Integration

Preserve this as a separate research intake. It does not replace the existing
public253 theorem, earlier control tables, or retained incoming manuscripts.
The mathematical and engineering components can be reused independently.
See `NOTICE.md` and `engineering/NOTICE.md` for attribution and source
boundaries.
