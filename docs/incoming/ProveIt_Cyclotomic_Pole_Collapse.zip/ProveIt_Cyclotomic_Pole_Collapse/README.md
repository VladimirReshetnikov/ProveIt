# Cyclotomic Pole Collapse and Exact Minimal Recurrences for Cigler's Hankel Polynomials

Research article prepared for Vladimir Reshetnikov, 30 September 2026.

## Main result

The article resolves the complex-root-of-unity spectral-cancellation question
left open in Section 21.2 of the inspected ProveIt Cigler/Hankel report. It
classifies the reduced generating denominator and minimal recurrence for the
normalized Hankel/rectangular-Schur sequence at every complex parameter.

At roots of unity of order at least three, the maximum-degree baseline can
require a correction in at most one residue class. An explicit parity test
determines whether that correction occurs. The usual loss is one pole order;
primitive fourth roots with k = 1 mod 4 have an exceptional three-order loss
(apart from the small case in which the entire factor disappears).

For example, at k=9 and t=i the reduced denominator is

    (1-z)^9 (1+z)^4 (1+z^2)^8.

Further results include a general first subleading coefficient formula for
confluent rectangular-Schur spectral modes, exact fourth-root product
quasipolynomials, and a quadratic recurrence-order law at fixed cyclotomic order.

## Files

- `article.pdf`: the 22-page compiled article, including complete proofs,
  nine further-research directions, appendices and references.
- `article.tex`: standalone LaTeX source; bibliography is included inline.
- `CLAIM_STATUS.md`: proof scope, dependencies and verification limitations.
- `SOURCES.md`: repository pin, source identifiers and bounded literature audit.
- `code/verify.py`, `code/modular.py`: reproducible exact checks.
- `data/verification.json`, `data/verification.log`: delivered verification run.
- `data/modular_checks.json`: all 240 finite-field test records.
- `data/pdf_checks.json`: final PDF build and inspection record.
- `requirements.txt`, `Makefile`: reproduction support.

## Reproduction

Use Python 3.10 or later and install the pinned dependency:

    python -m pip install -r requirements.txt
    python code/verify.py

The delivered run used Python 3.13.5 and SymPy 1.14.0. All checks passed:
54 Cigler modes, 22 additional general-cluster modes, 80 exact fourth-root
values, symbolic power-sum/Newton identities, 144 exact Hankel--Schur
comparisons, and 240 finite-field recurrence reconstructions.

The verifier writes its report atomically. On a failed check it returns a
nonzero exit status and records a failed status instead of a success report.
No network access is needed after the dependency has been installed.

To build the article with a standard TeX Live installation:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

Alternatively, `make pdf` builds it and `make check` runs the verifier.

## Scope

The mathematical arguments, not the finite tests, establish the all-index
claims. The Hankel--Schur identity is an explicit input from the pinned
repository report. These new results have not been formally verified in Lean
or independently refereed, and exhaustive historical priority is not asserted.
The article does not claim to resolve all of Cigler's Conjectures 17 or 18.
No repository files were modified by this task.
