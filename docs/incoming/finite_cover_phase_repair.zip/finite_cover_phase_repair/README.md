# Finite-cover polarization and optimal repair of multilinear phase obstructions

Research manuscript prepared for the ProveIt / Combinatorics / Ramsey project,
7 October 2026.

## Main results

For a symmetric `(p+1)`-linear tensor over `F_p`, let
`B_T(a,b) = T(a,...,a,b) - T(a,b,...,b)` (p repeated arguments).
If this alternating form has rank `2r`, the manuscript proves:

- Minimum codimension of an integrable restriction: exactly `r`.
- Minimum kernel size among **all finite abelian integrating covers**: exactly `p^r`.
- Minimum covers: `(Z/p^2)^r × (Z/p)^(n-r)`, classified over the original space
  by its maximum isotropic subspaces; there are `product_{j=1}^r (p^j+1)` classes.
- Exact restriction/covering tradeoff: codimension plus log-p kernel size is
  at least `r`, and every integer point on this boundary is attained.

For a family of tensors, replace `r` by the minimum codimension of a common
isotropic subspace of their alternating defects. The same minimum-kernel
formula, classification, and tradeoff hold. This is an exact variational
characterization, not an efficient algorithm for the common-isotropic optimum.

A separate all-degree theorem realizes symmetric twisted cube energy as a
Gowers norm on an explicit finite cover of any finite abelian group. It proves
a coefficient-one quotient-profile inequality and lossless mean energy
retention on cosets. Together with the obstruction normal form, it reduces
the largest nonintegrable first-obstruction energy in any dimension to the
canonical tensor on `F_p^2`.

For ternary quartics the exact certified interval is

```
11/27 <= m_(3,1) <= 1099/2187.
```

The upper bound is a finite integer/cyclotomic census followed by a triangle
inequality and a proved reduction from the whole unit polydisc to its phase
torus. **The assertion that the exact maximum is 11/27 is a conjecture.**

## Files

| File | Purpose |
|---|---|
| `article.tex` | Complete LaTeX manuscript with proofs, source comparison, and ten research questions |
| `article.pdf` | Compiled article |
| `verify_exact.py` | Standard-library-only exact checker; independently reconstructs the census |
| `data/ternary_quartic_certificate.json` | All 289 nonzero Laurent coefficients, including original root counts |
| `data/verification_report.json` | Exact finite-difference and selected-energy regression results |
| `explore_ternary.py` | Optional numerical phase search; not a proof |
| `data/ternary_numerical_experiment.json` | All 30 optimizer runs, including termination statuses |
| `SOURCE_AUDIT.md` | Provenance, scope, and novelty limitations |
| `FORMALIZATION_PLAN.md` | Proposed proof-assistant interfaces and validation obligations |
| `Makefile` | Build and verification commands |

## Reproduce

Use Python 3.10 or later for the supplied type-annotated checker:

```sh
python3 verify_exact.py
```

This reconstructs and compares the shipped certificates. To regenerate them:

```sh
python3 verify_exact.py --write
```

The verified counts are 59,049 ternary cubes, 289 retained monomials,
39 primitive cases, and 25,334 exact repeated-generator difference checks.
The checker includes zero and nonunit function amplitudes in a separate
selected-energy/subgroup regression.

Build the PDF with a conventional LaTeX installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The optional exploration requires NumPy and SciPy:

```sh
python3 explore_ternary.py --starts 30 --seed 1729
```

The exact checker does not depend on these numerical packages. Numerical
optimizer success, failure, or observed maxima do not certify global optimality.

## Integration and status

Suggested new directory:

```
Combinatorics/Ramsey/Research/GowersSzemeredi/finite-cover-phase-repair/
```

The package does not modify repository files or update the formal proof ledger.
No Lean implementation or completed Lean build is claimed. The nonclassical
integration criterion is known from Tidor's all-degree theorem; the manuscript
reproves the needed special case and does not claim that criterion as new.
The Boolean repair specialization overlaps existing repository research.
The main proposed contributions are the all-prime minimum-cover theorem,
simultaneous-cover formulation, joint optimal frontier, and all-degree twisted
quotient-profile comparison. Priority has not been exhaustively established.

The results require a homogeneous tensor symmetric in **all** cube slots.
They do not automatically handle the repository's multiaffine selector,
approximate symmetry, or progression-localized setting. No improved global
Szemerédi bound, complete inverse theorem, or solution of the sharp ternary
endpoint is claimed.
