# Square-Root Restricted Partitions
## Sharp envelopes, all-orders phase expansions, and quantized inversion

Research report prepared for Vladimir Reshetnikov, October 1, 2026.

Open `article.pdf` for the report; `article.tex` is its self-contained LaTeX source.
The report studies OEIS A097356 and companion sequences A206226, A206227,
A206240, and the exponential constant A258268.

### Main results

Let a(n) count partitions of n with largest part at most floor(sqrt(n)).
Let v be the unique positive solution of integral_0^v t/(exp(t)-1) dt = v^2,
s = 1-exp(-v), beta=-log(s), g=2v+beta, and C=v/(2*pi*sqrt(3*s-1)).

* The sharp normalized limiting constants are C and C*s. The latter is
  0.08815488379869711651692727829334..., matching the conjectured OEIS decimal.
* The constant C*s is NOT an eventual pointwise lower bound. In each sufficiently
  large square shell, exactly the final three terms fall below it.
* A uniform all-orders expansion has polynomial coefficients in the shell or
  fractional-square-root phase. A finite recurrence computes every coefficient.
* The normalized sequence has a log-uniform empirical limiting distribution.
* An explicit clipped-phase correction to a Lambert-W anchor inverts the sequence
  threshold with additive O(1) error, uniformly through the square jumps.

### Scope and provenance

The first-order envelope result follows from classical Szekeres–Canfield
restricted-partition theory. This report gives conventional proofs of the
sequence-specific refinements and inverse statements, not a claim of a new
foundational restricted-partition asymptotic theorem or of verified publication
priority. It is an unreviewed research report and should receive independent
mathematical review before publication or entry updates.

The infinite expansion is justified at every FIXED algebraic truncation order.
It is not asserted to converge or to include a complete exponentially small
saddle decomposition. No explicit universal starting index for the eventual
three-term defect or universal numerical constant for the inverse O(1) is certified.

No Lean/Rocq formalization was performed. Exact enumeration is distinct from
numerical asymptotic evaluation, and the exact rational interval certificate
certifies sign inequalities, not the entire contour proof. No repository or
OEIS edits were made.

See `SOURCES.md` and the report's bibliography for sources and repository scope.

### Contents

- `article.pdf`, `article.tex`: report and source.
- `verification/expansion.py`: high-precision coefficient recurrence, evaluation,
  and phase-aware inverse prediction.
- `verification/certify.py`: rational interval saddle/sign certificate, with
  explicit analytic series-tail bounds and outward rounding.
- `verification/symbolic_checks.py`: exact symbolic checks of closed coefficient
  identities and phase transformations.
- `verification/verify.py`: exact integer partition enumeration through n=20000,
  OEIS prefix comparisons, coefficient cross-checks, boundary and inverse tests.
- `data/`: recorded output, exact counts at sampled indices, and numerical tables.
- `requirements.txt`, `Makefile`: reproducibility support.

### Reproduction

Python 3.10 or later is recommended. The recorded run used Python 3.13.5,
mpmath 1.3.0, and SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python verification/certify.py
python verification/symbolic_checks.py
python verification/verify.py --max-n 20000
```

Run scripts without Python's `-O` flag: assertions are the check gates.
The verification program overwrites its CSV/JSON data outputs. The certificate
and symbolic programs print their results; `make verify` records all three logs.
The coefficient engine supports user-selected finite orders, but cost and loss
of numerical precision grow with the requested order. Published test outputs
cover through P4, not arbitrary orders.

A normal TeX Live or MiKTeX installation with the listed standard LaTeX packages
builds the report:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively use `make pdf` or `latexmk -pdf article.tex`. No external figures,
fonts, bibliography files, repository files, or network requests are needed.

### Reading the tables

`shell_errors.csv` uses **approximation / exact - 1**. Columns order0 through
order4 correspond to keeping P0 through the indicated Pj. Exact enumeration uses
Python arbitrary-precision integers. Decimal asymptotic errors are numerical,
not interval enclosures.

`boundary_defects.csv` reports R_(k^2-r)/(C*s)-1 and its rescaling by k.
`phase_checks.csv` compares the phase-normalized first correction to Q1.
`inverse_checks.csv` gives integer thresholds and the exact first index meeting
those thresholds, compared with the leading clipped-phase formula. Observed
error maxima are not claimed to be universal bounds.
