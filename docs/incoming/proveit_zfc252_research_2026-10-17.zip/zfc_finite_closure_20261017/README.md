# A 252-state ZFC consistency machine and a finite closure kernel

This report provides a **252-working-state binary blank-input Turing machine**
and supplies an ordinary mathematical argument, formalizable in ZFC, that
its nonhalting is equivalent to `Con(ZFC)`. It improves the inspected public
253-state benchmark by one state. The transition table is a previously
studied runtime fold; the new result is its exact blank-bootstrap analysis
and the global enumeration-order argument protecting its dirty initial stack.

The separate finite-theory proposal gives a calibrated universal clause
payload of **901 meaningful bits / 113 bytes**, compared with 1,609 bits for
the earlier FAK12 payload under the same reversible codec. A 917-bit variant
is preferable when equality axioms are stored explicitly. These input sizes
are not machine state counts; the 252-state table uses the existing calculus.

## Start here

- `report.pdf`: full report, proofs, prior-work audit, measured results and proposal.
- `report.tex` and `sections/`: complete LaTeX source.
- `machine/machines/runtime252.tm`: exact 252-state table.
- `machine/README.md`: physical certificate and independent machine replay.
- `formal/SCOPE.md`: scope of the new Lean components.

The exact table has working states 0 through 251, start state 0, terminal
state 252, symbols 0 and 1, and a doubly infinite all-zero initial tape.
SHA256 (including its two comment lines):

```
5919a993e3c539c91636cdeb1a43461e630ad43bd03e39faed141202a6945987
```

## Reproduce offline

Python 3.11 or newer, standard library only:

```sh
python3 verify.py --output /tmp/zfc-replay-results.json
```

The replay checks all generated clauses and binary payloads, both formula
coordinate modes, all reference-logic tests, the independent local closure
audits, 100,000 exact candidate codes, and the complete machine bootstrap
and universal runtime certificate. `--quick` skips only the three-object
EPSC census. Never use Python `-O`; assertions are certificate checks.

For the physical machine alone:

```sh
python3 machine/code/reproduce.py --output /tmp/zfc252-machine-replay
```

For the new standalone Lean files (Lean 4.32.0, `Std` only):

```sh
make lean LEAN=/path/to/lean
```

For the PDF (pdfLaTeX, latexmk, standard packages):

```sh
make pdf
```

## Exact proof status

The report supplies the ordinary ZFC-level proof: finite blank-prefix
transport, universal register-box/decoder simulation, the new protected-stack
soundness theorem, existing arbitrary-start completeness, and the inherited
full calculus/ZFC calibration. The new end-to-end theorem has **not** been
serialized as a single Lean or Rocq declaration.

Four included Lean modules check the two coordinate constructions, exact
Cantor marked-occurrence lowering and injectivity, and a generic prefix
count/stack-barrier theorem. Their dependencies are the usual Lean logical
axioms; there are no added axioms or admissions. The report explicitly states
which scheduling and runtime arguments remain ordinary mathematics.

The finite EPSC audits test only the six-clause closure transformation.
Their finite structures are not models of the whole finite theory, whose
assignment/NAND fragment forces an infinite domain. Bounded proof searches
are never presented as consistency proofs.

## Files and attribution

`data/` contains every clause set, exact binary payload and codec metric.
`code/` contains the generators, reversible codec, reference refuter and
independent checks. `evidence/` contains replay results and independent
reviews. `provenance/` records the inspected ProveIt sources and preserves
the old FAK12 generator for a faithful comparison.

`provenance/inherited_bridge/` preserves the universally quantified upstream
program theorems and their complete concrete bisimulation certificate.
`provenance/earlier_enumerator/` preserves the earlier command encoding,
arbitrary-start completeness and Cantor definitions used in this report.
Their manifests identify pinned sources and exact hashes. These selected
files document inherited results; they are not standalone upstream builds.

The machine package retains its own pinned source manifest, selected
upstream definitions and attribution. See `NOTICE.md`, `LICENSE` and
`machine/NOTICE.md`. The original Mira-Cult construction, mira-emmy's
public 253-state reduction, jeff87654's verification, Wade's framework,
Friedman's finite representation method and ProveIt's closure calibrations
are reused and credited.
