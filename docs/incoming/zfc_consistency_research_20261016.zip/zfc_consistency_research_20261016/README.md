# Toward a Smaller ZFC Consistency Machine

Research prepared for Vladimir Reshetnikov, 16 October 2026, for integration
into the ProveIt repository.

**This package does not establish a state-count record below the attributed
public 253-state machine.** It supplies a checked Lean model bridge, a
253-state literal-table shortcut with an inductive certificate, a seven-equation
algebraic proof-search proposal and reference checker, and reproducible
complete-logic grammar experiments.

The main article is `zfc_consistency_report.pdf`; its source is
`zfc_consistency_report.tex` together with `sections/`. The article distinguishes
the actual binary machine, its abstract proof enumerator, theory consistency,
and the desired arithmetic equivalence proved inside ZFC.

## Package layout

| Directory or file | Contents and scope |
| --- | --- |
| `formal/` | Three new Lean modules and 23 unchanged pinned source dependencies; integration patch, build script, and prior build/axiom-audit records |
| `experiments/public253/` | Attributed original253 table, new one-row variant, finite invariant, independent checker, all 178 endpoint one-cell positions, and negative search evidence |
| `experiments/equational/` | Seven-equation kernel, ground proof checker, finite and adversarial tests, basis data, and mathematical/literature notes |
| `experiments/grammar/` | Rotation search driver, its original script-relative inputs, three measured 268-state outputs, and independent register-program certificates |
| `verify.py` | Offline verification runner; writes `validation.json` |
| `provenance.json` | Exact source pins, attribution, license references, artifact hashes, commands, and limitations |
| `copy_manifest.json` | Byte-for-byte source/evidence copy record; no cache files or expendable mutation files |
| `licenses/` | Pinned ProveIt and Andrew James Wade MIT No Attribution license texts |

## Verify the supplied evidence

Python 3.10 or later is sufficient for the default checks; all Python code uses
the standard library. Run from the package root:

```sh
python -B verify.py
```

This checks the 23 original Lean source blob identities, then runs:

1. The public253 radius-two invariant, guarded shortcut, exact literal table
   hashes, and complete bootstrap comparison.
2. Eight focused public253 positive and corruption-rejection tests.
3. The algebraic finite-model, translation, malformed-certificate, integer-code,
   and deep-term tests.
4. All three delivered grammar certificates with 4,533 operation-site pairs
   each, plus six regenerated certificate-corruption controls.

It does not rerun the state-reduction or grammar searches, execute the binary
compiler, rebuild upstream Coq, or compile Lean by default. The algebra test
includes small bounded proof-search examples as unit checks. Default verification
does not claim that finite algebra tests prove the general algebraic theorem.

Some inherited finite checkers use Python assertions, so run without `-O`.
The runner rejects optimized execution. It suppresses bytecode caches and keeps
the grammar corruption files in a temporary directory. The report and source
files are not modified; the summary and complete subprocess outputs are written
to top-level `validation.json`.

### Rebuild the Lean proofs

Install Lean **4.32.0** and select its executable with `ZFC_LEAN`, or put that
version of `lean` on `PATH`:

```sh
ZFC_LEAN=/absolute/path/to/lean python -B verify.py --lean
```

For the Lean build alone:

```sh
ZFC_LEAN=/absolute/path/to/lean python -B formal/build.py
```

The existing build script validates the 23 original Git blob identities and
serially rebuilds all 26 source modules. It writes `formal/cache/`,
`formal/dependency-build.json`, and `formal/verification.json`. The source package
ships without the cache. A prior successful Lean 4.32.0 build is recorded in
those evidence files; `validation.json` states whether Lean was rebuilt in the
current runner invocation. A copied historical PASS is not presented as a new
build.

The new declarations use only the recorded standard Lean dependencies
`propext`, `Classical.choice`, and `Quot.sound`. Their result identifies model
classes on the same structure and characterizes the original abstract
enumerator. It is not a proof of literal binary dispatch, the entire machine
simulation, or the arithmetic endpoint inside ZFC.

### Individual Python checks

```sh
python -B experiments/public253/check_certificate.py
python -B experiments/public253/test_certificate.py
python -B experiments/equational/test_cyclic_algebra.py
python -B experiments/grammar/verify_certificates.py
```

The grammar wrapper uses the unchanged source-08 path engine through the existing
arbitrary-reference checker in `layout_grammar_experiment.py`. Its reference is
the reviewed **217-node source-19 DAG**. The source-08 verifier's original direct
CLI is pinned to the older 219-node Coq DAG and should not be substituted for this
wrapper. Reference JSON files have two serialization hashes but identical parsed
objects; both exact serializations and their semantic equality are checked.

## What was obtained

### Same-structure model bridge

The three new files are `ModelBridge254.lean`, `EnumModelBridge254.lean`, and
`ModelBridge254Checks.lean`. Under irreflexivity they equate the original decoded
bundle models, encodable bundle models, and native-equality CP/GIC models on the
same underlying structure. The abstract six-register enumerator halts precisely
when the resulting model theory has no nonempty irreflexive model. Original gates,
coincident nongated labels, and truth code zero are retained.

Apply `formal/model-bridge.patch` at the ProveIt repository root, or copy the
three new source files into `Computability/BusyBeaver/Lean/BusyBeaver/ZFC/`.
The other 23 source files are pinned dependencies for reproducibility; they
should not replace newer repository files.

### Public253 shortcut

The new table changes compact row `60/read0` from `0 L45` to `0 R51`. A
3,530-pair inductive window invariant, with 7,044 closure obligations, proves
the necessary left-zero guard for every source configuration reachable from
blank. One new step matches three old steps with the complete tape, head, and
state equal. This proves whole-run halting equivalence by positive progress.
The proof is a written argument supported by an independent executable finite
certificate; this package does not claim a new Coq or Lean formalization of it.

Both original and new tables have **253 working states**, **506 rows**, start state 0,
blank symbol 0, and a separate terminal label 253. The exact bootstrap is shortened
from **312,975** to **312,895** transitions by 40 uses, with the same state 33,
head −17, and all 178 one-cells, including all 158 spare blocks. The state count is
unchanged. The bounded broader deletion searches found no complete state
deletion; their failures are not lower bounds.

### Algebraic proposal and grammar searches

The algebraic material gives seven equations, with 88 symbol occurrences under
the specified counting convention, and a complete reference checker for finite
ground rewrite chains. The general identity-reflection argument is written out;
finite tests are supporting evidence. The ZFC-specific ground term and a binary
TM compiler are **not supplied**, so the seven equations are not a measured
state bound or a smaller finished consistency machine.

The two rotation experiments preserve the reviewed complete macro word. Their
50,193 and 68,784 evaluated rotations produced no improvement below the known
268-state Wade control. Each supplied candidate has 206 decision nodes and
62 framework states. The independent 4,533-pair certificate verifies its
register-program relation to the stated reference, including both decrement
branches. It does not verify the binary compiler or a ZFC endpoint.

## Build the report

Use a standard TeX distribution with the packages listed in the main source:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error zfc_consistency_report.tex
```

The delivered PDF contains 30 pages. `pdf_validation.json` records the document
checks; `SHA256SUMS` records every other final packaged file. After extracting,
`sha256sum -c SHA256SUMS` checks the delivered bytes. Verification runs regenerate
their result logs, so perform that integrity check before rerunning them.

## Pins, attribution, and licenses

- ProveIt snapshot: `426592ce97e52d309bfb8f0132411556650b7ac1`.
- Jeff/Mira-Cult ZFC254 source and Wade backend snapshot:
  `297ab8df7e5de329605c3875b4934643b371a5e3` in
  [jeff87654/busy-beaver](https://github.com/jeff87654/busy-beaver).
- Prior public253 reduction: `0d544f2a2e3c18f12278441a74b7879f31cbe856` in
  [mira-emmy/busy-beaver](https://github.com/mira-emmy/busy-beaver), associated
  with [upstream PR20](https://github.com/jeff87654/busy-beaver/pull/20).
- Public253 is attributed prior work by mira-emmy, derived from Mira-Cult's
  construction and Jeff's verification using Wade's framework. The new one-row
  shortcut does not claim their state reduction as a new contribution.
- The Boolean single axiom is due to McCune, Veroff, Fitelson, Harris, Feist, and
  Wos. The first-order-to-Df3 translation is due to Andréka and Németi. Their
  articles are cited in the report and algebraic notes; the publications are not
  redistributed as new work.

The pinned ProveIt root license is **MIT No Attribution**, copyright 2026 ProveIt
Contributors. Wade's backend has its own **MIT No Attribution** notice,
copyright 2025 Andrew James Wade. Both texts are preserved in `licenses/`, and
the backend copies retain their existing `LICENSE.wade`. All supplied source
headers and attributions are retained. No separate license notice was attached
to the retrieved public253 literal table; this package records its source and
attribution and does not invent an additional upstream license or reassign
upstream authorship.

Exact hashes and reproducible commands, including optional search reruns into
separate output directories, are in `provenance.json`. This package's new
research additions are supplied for integration into ProveIt without altering
the license notices of its dependencies.
