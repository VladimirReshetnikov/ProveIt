# Exact hulls and small Con(ZFC) machines

Research prepared for Vladimir Reshetnikov, 16 October 2026.

Start with **report.pdf**. The complete editable source is **report.tex**
with its eight files under **sections/**. The report audits the requested
ProveIt commits and subsequent material through the pinned snapshot
`de047657e193ec605e930eaf149a44a38031820b`.

## Results

The main proposal preserves the complete logical interface of the existing,
attributed 253-state construction and develops an explicit internal ZFC
endpoint. The full EPSC schema remains the most promising measured theory
frontend. We also derive an exact fixed-point normal form, EFPC, with the
same full-schema consequences and consistency strength.

The report supplies the EPSC-to-EFPC proof, a strengthened three-object
counterexample to replacing one universally closed axiom in isolation,
and Lean-checked local hull lemmas. A separate modal valuation certificate
identifies a missing reflexivity condition in an abbreviated printed
axiom list, without challenging that paper's main interpretation theorem.

The compiler experiment actually emits all 20,480 selected candidates while
retaining the complete equality engine. Its best EFPC control has **271
working states**, compared with the exactly reproduced **270-state EPSC
control**. This is a measured comparison, not a new minimum-state result.
The 148,368-candidate symbol-wise fusion experiment yields no candidate
passing its bounded instruction tests; fuel and abstraction-limit outcomes
remain unresolved.

**No new formally certified Con(ZFC) machine is claimed in this package.**
The distinction between ordinary mathematical calibration, the local Lean
theorems, finite register certificates, and the final machine/internal-ZFC
endpoint is explicit throughout.

## Reproduce the delivered results

Packaging checks used Python 3.12.
All Python dependencies are in the standard library or supplied source
subset. No network access is needed.

```sh
python3 reproduce.py --quick
```

This recomputes the full one-to-three-object relation census, checks the
axiom constructors and substitution semantics, reproduces syntax counts,
regenerates both selected machines byte for byte, checks their independent
operation certificates, reproduces the 253-state whole-tape bootstrap, and
checks the recorded fusion ledger. It also verifies artifact hashes if
the supplied manifest is present. All intermediates use temporary files.

For the formal theorems, use **Lean 4.32.0**, release commit
`8c9756b28d64dab099da31a4c09229a9e6a2ef35`:

```sh
python3 reproduce.py --quick --lean lean
```

Replace the final `lean` with an absolute executable path if needed.
There is no Mathlib dependency. The driver checks all thirteen reported
endpoints against their empty-axiom audit logs. Those endpoints concern
the precisely stated local resources and Boolean valuation, not the full
schema interpretation or a binary machine theorem.

The complete selected grammar search and bounded fusion search can also be
repeated:

```sh
python3 reproduce.py --full-search
python3 machine/reproduce.py --fusion
```

A full offline grammar replay passed during packaging, matching all
20,480 compilations, ten distributions, recipes and selected tables. The
full fusion search was performed during the research and its ledger
checked during packaging; it was not rerun in the final packaging pass.
See `machine/README.md` for the exact scope of each check.

To inspect a small valid non-refutation certificate:

```sh
python3 code/reference_kernel.py examples/valid_nonrefutation.json
python3 code/reference_kernel.py examples/valid_nonrefutation.json --kernel EPSC
```

To rebuild the PDF:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

The Makefile offers `pdf`, `check`, `formal`, `full-search`, and `fusion`
targets. The PDF's creation metadata may change on rebuilding; the report
does not require byte-identical PDF output across TeX installations.

## Artifact map

| Path | Contents |
|---|---|
| `formal/ExactHull.lean` | Monotone exact-hull theorem; seeded specialization; global-leastness extension and boundary example |
| `formal/ModalBasisAudit.lean` | Boolean countervaluation to the abbreviated modal list |
| `code/reference_kernel.py` | Complete equality-free Hilbert interface with selected EPSC/EFPC constructor |
| `code/check_reference.py` | Independent finite semantics, capture avoidance, invalid certificates, and universally closed counterexample |
| `code/finite_hulls.py` | Exhaustive finite resource diagnostics; these are not full-schema models |
| `code/wrapper_metrics.py` | Counts in explicitly distinguished logical bases |
| `data/` | Recomputed finite results, formal audit logs and packaging check record |
| `machine/baseline/` | Attributed 253-state table, provenance and exact finite bootstrap |
| `machine/fixedpoint/` | Selected tables, grammars, DAGs, operation certificates and aggregate search data |
| `machine/fusion/` | Search summary and compressed complete first-failure ledger |
| `machine/vendor/` | Minimal unchanged source subset for offline replay |
| `PROVENANCE.json` | Repository pins, machine hashes and proof-status declarations |
| `ARTIFACT_MANIFEST.json` | SHA-256/size inventory, excluding itself |

The machine files use a deterministic binary machine on a tape infinite in
both directions, initially all zero, with start state 0 and a separate,
uncounted terminal label. All initialization is included in the literal
working-state counts.

## Attribution

Read `NOTICE.txt` and `machine/ATTRIBUTION.md`. PSC/EPSC calibration and the
EPSC270 control are prior repository work. The 254-state construction is
Mira-Cult's; the 253-state reduction is mira-emmy's submitted upstream PR20,
with Jeff's verification lineage. Andrew James Wade's compiler and retained
research compressors/checkers are credited separately. This package did
not rebuild the complete external Coq proof project and does not relabel
its endpoint as a new internal ZFC theorem.
