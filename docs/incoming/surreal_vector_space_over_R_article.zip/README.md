# Surreal numbers as a vector space over R

This package contains the research article requested for the ProveIt surreal-number project.

## Files

- `surreal_vector_space_over_R.tex` — complete standalone LaTeX source.
- `surreal_vector_space_over_R.pdf` — compiled 28-page article.

## Central conclusion

The Conway monomials `omega^a` are the canonical coordinate directions of the surreal numbers. They are linearly independent over the reals, but their ordinary Hamel span contains only finite normal forms. Their natural role is instead as a Hahn or strong-summation basis: every surreal has a unique reverse-well-ordered, set-supported monomial expansion.

The article also develops exact Hamel dimensions for set-sized support slices, the leading-exponent associated graded algebra, support projections, convex-subspace and positive-diagonal-operator classifications, coefficientwise finite linear algebra, the natural-valuation closedness of the finite monomial span, a proposed Lean implementation plan, and a detailed research agenda.

## Build

A standard TeX Live installation with `pdflatex` is sufficient:

```sh
pdflatex surreal_vector_space_over_R.tex
pdflatex surreal_vector_space_over_R.tex
```

The delivered PDF was compiled without LaTeX warnings and rendered at 200 dpi for visual inspection.

## Research status

Classical inputs are cited in the bibliography. Results labeled “proved here” are supplied with proofs in the article but are not asserted to be priority-new and have not yet been machine-checked as a unit. Statements about a Hamel basis of the entire proper class are explicitly conditional on a suitable class theory with global choice and transfinite class recursion.
