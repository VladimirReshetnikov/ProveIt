#!/usr/bin/env python3
"""Exact additional rooted/reflected comparison with the later incoming ZC215.

The primary corpus is frozen at the earlier research snapshot. This check
records the subsequently published main table without changing that corpus.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys

if not __debug__:
    raise RuntimeError('Assertions must be enabled.')
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('independent_marker_auditor',
        ROOT / 'markers/independent/audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    provenance = json.loads((ROOT / 'late_comparison/PROVENANCE.json').read_text())
    for name, pin in provenance['files'].items():
        assert audit.digest(ROOT / 'late_comparison' / name) == pin['sha256']
    old_keys = []
    for name in ('zc215.native.tm','zc215.tm'):
        st, tab, halt = audit.read(ROOT / 'late_comparison' / name)
        assert len(tab) == 430
        old_keys.append(audit.canon(st, tab, halt))
    assert old_keys[0] == old_keys[1], 'ZC215 native/dense mismatch'
    paths = [ROOT / 'DR215/machine/dr215.native.tm']
    paths += sorted((ROOT / 'markers/marker_family').glob('*/machine.native.tm'))
    assert len(paths) == 5
    records = []
    for path in paths:
        st, tab, halt = audit.read(path)
        assert audit.canon(st, tab, halt) != old_keys[0]
        assert audit.canon(st, tab, halt, True) != old_keys[0]
        records.append({'candidate':str(path.relative_to(ROOT)),
                        'sha256':audit.digest(path),'matches':[],
                        'reflected_matches':[]})
    result = {'status':'LATE_ZC215_COMPARISON_PASS',
              'repository_head':provenance['head_commit'],
              'archive_sha256':provenance['archive_sha256'],
              'additional_graphs':1,'results':records,
              'scope':'Only the new incoming archive main ZC215 table; frozen original corpus is checked separately.'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'new_candidates':len(records)}))

if __name__ == '__main__':
    main()
