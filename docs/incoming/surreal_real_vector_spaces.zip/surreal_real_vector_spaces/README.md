# Surreal Numbers as a Real Vector Space

## Canonical Hahn Coordinates, Hamel Obstructions, and the Euler Quotient

Prepared for Vladimir Reshetnikov, October 1, 2026.

The package contains a 29-page article, its self-contained LaTeX source,
39 exact finite algebraic checks, and explicit proof/provenance boundaries.
The article includes 34 numbered theorem/proposition/lemma/corollary statements
(including two introductory summary theorems), ten research directions,
two audit appendices, and ten bibliography entries.

## Files

- `article.pdf`: typeset article, with linked contents and bibliography.
- `article.tex`: complete source; no external figures or bibliography file needed.
- `code/verify.py`: standard-library Python exact-arithmetic verification.
- `data/verification.json`: recorded results of the 39 passing checks.
- `audit/PROOF_AUDIT.md`: scope, dependencies, edge cases, and nonclaims.
- `audit/sources.json`: repository pin and primary-source reading record.

## Principal conclusions

Conway monomials are canonical Hahn coordinates, not a Hamel basis. On a
nontrivial set-sized Hahn slice H = R((t^Gamma)), the quotient by the finite
monomial span E has the same real dimension as H. Each finite-dimensional
subspace has a canonical reduced leading-coordinate basis, but the whole
space has no valuation-independent Hamel basis.

For a nonzero real exponent subgroup Gamma, the Euler operator
D(t^gamma) = gamma*t^gamma makes H/E canonically a vector space over R(X),
of dimension continuum. Every real-linear operator on H commuting with D
is automatically coefficientwise and strong. E has no D-invariant algebraic
complement, despite admitting ordinary real-linear complements.

The geometric quotient classes [(1-r*t^delta)^(-1)] are R(X)-independent,
but do NOT span. An explicit missed direction has coefficients n!.
The article proves independence of the larger factorial-exponential family
with coefficients (n!)^rho*r^n as well.

The completion and quotient-lifting sections distinguish left-finite
support, arbitrary Hahn support, strong maps, and merely continuous maps.
In particular, the kernel of the induced coefficient-multiplier action on
H/E consists of weights with reverse-well-ordered support, not just weights
with finite support.

## Build the PDF

Use a TeX Live or MiKTeX installation containing the usual AMS and Latin Modern
packages and the packages named in the preamble.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Without latexmk, run the following command three times (or until labels stop
changing):

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The supplied PDF was built with pdfTeX 1.40.26. Its final build had no undefined
references, missing citations, or overfull boxes. One harmless underfull-box
warning in the provenance table remains. All pages were rendered and reviewed
for layout.

## Reproduce the finite checks

Python 3.10 or newer; no third-party packages or network access are needed.
The script can be run from any working directory.

```sh
python code/verify.py
```

Expected output starts with:

```text
PASS: 39 exact finite checks
```

The script rewrites `data/verification.json`. All arithmetic is performed with
`fractions.Fraction`. Failure raises an exception, including when Python runs
with optimizations enabled.

## Mathematical and historical status

This is an AI-assisted, unrefereed research draft. The written proofs are the
evidence for the infinite-dimensional statements; finite computations do not
verify them. No Lean, Mizar, or other proof-assistant verification of this
article is supplied. Classical normal-form and Hahn-field foundations are
cited rather than reconstructed genetically.

The Euler-quotient, commutant, and nonsplitting package is presented as a
proposed research contribution. Its historical novelty is not certified, and
no named published open conjecture is claimed solved. The repository review
was targeted, not exhaustive. No changes were made to the repository.

All set-sized results are formulated in ZFC. The full surreal field is a
proper class; the class Hamel-basis existence statement separately assumes
Godel--Bernays class theory with global choice. No set-cardinal dimension is
assigned to the entire surreal class.
