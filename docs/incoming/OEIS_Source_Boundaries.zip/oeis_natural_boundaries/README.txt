NATURAL BOUNDARIES AT THE SOURCE EXTREMUM
Fixed deficits, dyadic radial limits, and local L^p growth
Research manuscript prepared with ChatGPT
5 October 2026 (UTC)

MAIN DELIVERABLE

article.pdf is the complete typeset research article.
article.tex is its complete LaTeX source. Its bibliography is embedded;
there is no separate .bib file or network dependency for compilation.
The figures and generated diagnostic tables are included in this package.

MATHEMATICAL RESULT

Let u(n,s) count isomorphism classes of extensional acyclic digraphs with
n vertices and s sources. Put q(n)=ceil(log_2 n), and let

  b_n^(d) = u(n,n-q(n)-d),

with b_n^(d)=0 when the requested source count is less than one.
For every fixed nonnegative integer d, define

  c=2^(d+1), a=c-1, R=a^a/c^c, B_d(z)=sum_(n>=1) b_n^(d) z^n.

The article proves that |z|=R is a natural boundary of B_d. It resolves
Section 12.2, Question 1 of the pinned ProveIt source-boundary report.
The theorem concerns the ordinary generating function of UNLABELED
counts, equivalently the exponential generating function of the
corresponding labeled A182162 counts.

The additional results are:

- For each fixed dyadic root of unity zeta,
  B_d(R exp(-t) zeta)/B_d(R exp(-t))
  = zeta (1-aR)/(1-aR zeta) + O(t).

- With L=log(1/t),
  log B_d(R exp(-t))
  = L^2/(2 log 2) + L log L/(log 2) + O(L).

- For every fixed p>0 and nonempty bounded open angular interval I,
  the integral over I of |B_d(R exp(-t+i theta))|^p is bounded above
  and below by positive constant multiples of B_d(R exp(-t))^p.

- The formal size-and-deficit series has no nontrivial bidisk of
  convergence. At each fixed real positive defect fugacity, its
  ordinary generating function in size has radius zero.

All constants in these asymptotic assertions may depend on the fixed
parameters explicitly specified in the article. No arbitrary-complex-
fugacity result or nonlinear differential-algebraicity result is claimed.

PROOF STATUS

This is an unrefereed mathematical research manuscript with conventional
self-contained proofs. Independent internal reviews checked the core
counting, quantitative block estimates, radial transfer, and moving-grid
local L^p argument. This is not external peer review or a Lean/Rocq
verification. Historical priority is not certified. The article clearly
separates results already in the starting report from the new continuation.

EXACT AND NUMERICAL VERIFICATION

Run from this directory:

  python3 verify.py --max-n 64 --brute-n 6

The script constructs the marked-source and source-deletion triangles
independently. It also enumerates all topologically ordered DAGs through
six vertices and deduplicates them by finite-set collapse. Exact integer
checks verify the covering bounds, finite-deficit formula, core bounds,
and additional coefficient identities. Data files record the actual
ranges and counts of tests.

The numerical calculations use 100-digit mpmath. Some large blocks use
the explicitly identified positive binomial proxy. Their omitted tails
and covering discrepancies have analytic majorants, but floating-point
roundoff is NOT interval-certified. The numerical files are diagnostics
and are not proofs of the infinite analytic statements.

The main block-profile table uses Q_q(z), normalized by the actual first
count b_(K+1). The article's proof uses P_q(z), normalized by the positive
binomial proxy U_m*C(cK-m,K+1-m). These differ by P_q(0), whose discrepancy
from 1 is exponentially small by the covering bound. Appendix correction
diagnostics explicitly use the proxy normalization.

The recorded environment was Python 3.12.14, mpmath 1.3.0, and
matplotlib 3.10.8. Install the Python dependencies if necessary with:

  python3 -m pip install -r requirements.txt

COMPILE THE ARTICLE

The source uses standard TeX Live packages and pdfLaTeX. Run:

  bash build.sh

This makes two passes, retains auxiliary files in build/, and writes
article.pdf beside article.tex. To reproduce the figures and tables too,
run verify.py before build.sh. No source retrieval or network call occurs
during verification or compilation.

PACKAGE CONTENTS

article.tex, article.pdf     Complete article and source.
verify.py                  Reproducible checks and scientific plots.
requirements.txt           Python dependency versions used in the run.
build.sh                   Two-pass PDF build.
SOURCE_NOTES.txt           Pinned repository and primary-source provenance.
data/                      Exact counts, check reports, and diagnostics.
figures/                   Vector PDF figures and PNG previews.

FURTHER WORK

The article proposes ten concrete directions, including the order-L
term and discrete saddle phase, nondyadic radial behavior, shrinking
angular windows, exact L^p constants, arithmetic sections, growing
deficits, complex fugacity, and formal verification.

The supplied repository and OEIS were read only. No repository commit,
OEIS submission, or message to another person was made.
