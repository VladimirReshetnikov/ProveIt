# Report 289

## Optimal Weighted Witness Size and Torsion at the Energy Endpoint

Prepared for Vladimir Reshetnikov, 7 October 2026.

This report settles the logarithmic order of worst-case weighted witness support and gives a complete finite-weight endpoint criterion within the specified nonzero-defect index-two family. For unrestricted sparse support, “optimal” refers to asymptotic order; a sharp leading constant is obtained only in the containing-interval model. It does not classify all maps whose energy infimum is 3/4.

Main results:

- Integer parity on Z forces excess at least 1/[4^s binom(2s−2,s−1)] for every nonnegative finite weight with s support points, without bounds on diameter or coefficient values
- Binomial weights give exact excess (1/4) binom(4h,2h)/binom(8h,4h), strictly below (1/2)16^(−h)
- Thus the minimum support needed for excess at most epsilon is Theta(log(1/epsilon)); the universal worst-case conclusion also uses the already established general upper theorem in Report288
- A finite weight in the index-two family attains 3/4 exactly when e*e=o*o, equivalently when the union of its torsion-fiber Fourier supports avoids its parity translate
- Some finite attaining weight exists exactly when the nontrivial parity coset contains a finite-order element; then a finite indicator also attains
- If parity is trivial on the torsion of the support-difference group, the support lower bound strengthens to the number of free-projection points, with no torsion-fiber multiplicity loss
- Classical cyclotomic factors improve the universal leading support upper coefficient to pi/(8 Catalan); their exact parity excess has a proved first-correction asymptotic
- For support constrained to a containing integer interval, Boyd’s factor-norm theorem gives the matching exponential rate and sharp leading interval-length coefficient pi/(8 Catalan)
- The exact three-point integer minimum is (9+sqrt(6))/15, attained precisely by odd-step progressions weighted proportionally to (1,6^(1/4),1)
- Explicit C6, C8, and two-fiber examples separate attainment from periodicity, element order, ambient torsion, and independent fiber tests

The sparse coefficient inequality is established prior work by Akhtari and Vaaler (2018), explicitly credited. The cyclotomic factor family is classical (Boyd and Borwein); the interval lower bound imports Boyd’s factor-norm theorem. Neither the factor family nor the imported theorems are presented as new. All new applications are proved in the article. No publication-priority, nonabelian, global Ramsey, or Lean-certification claim is made.

## Contents

- `Report289.pdf`: prepared article
- `Report289.tex`: editable standalone LaTeX source
- `companion/`: exact standard-library checks and usage notes
- `tests/`: validation, arithmetic, algebra, build, integrity, and archive regressions
- `build.py`: guarded offline reproduction and deterministic packaging
- `REPRODUCING.md`: toolchain and complete replay instructions
- `SOURCES.md`: source dependencies and provenance
- `MANIFEST.sha256`: hashes of all eleven other public files

The ZIP contains exactly twelve regular-file members under `Report289/`. Its separately supplied SHA-256 pin is outside the archive. Finite diagnostics support mistake detection, not universal proofs by numerical testing.

## Quick replay

    python3 -I -B build.py verify
    python3 -I -B build.py reproduce --output /tmp/report289-replay

Choose a new absolute output directory. The builder does not modify the source tree or overwrite a nonempty destination. Reproduction needs the already installed documented Linux Python and TeX toolchain; it performs no downloads or installations. See `REPRODUCING.md` for limitations and independent check commands.
