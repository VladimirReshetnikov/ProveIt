"""Report289 exact offline diagnostics; not a proof-assistant certificate."""
