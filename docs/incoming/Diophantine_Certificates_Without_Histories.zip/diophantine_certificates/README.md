# Diophantine Certificates Without Execution Histories

**Single-fold quartics for succinct routing, and a universal one-router boundary**  
Research article prepared for the ProveIt program — September 30, 2026.

## Main files

- `article.pdf`: the complete 26-page article, with full mathematical proofs,
  a research agenda, a formalization plan, and references.
- `article.tex`: self-contained LaTeX source, including its bibliography.
- `verify_certificates.py`: exact operational and arithmetic checkers and tests.
- `test_results.json`: reproducible results from those tests.
- `compile_quartic.py`: dependency-free sparse polynomial compiler for RLE routing.
- `example_quartic.json` and `.txt`: a fixed-length, 13-witness quartic (50 monomials).
- `parametric_quartic.json` and `.txt`: the same topology with both lengths free
  as natural parameters plus one (81 monomials).
- `SOURCES.md`: pinned repository and literature provenance.
- `Makefile`: optional convenience targets.
- `SHA256SUMS`: integrity hashes for the delivered files other than the hash list itself.

## Results and scope

Theorem 3.1 constructs a single-fold natural-witness polynomial of total degree
at most four for every fixed RLE routing topology, with initial chip counts and
all block lengths as parameters. It has exactly `4*n + 4*m + s` witness
coordinates and `6*n + 2*m + s` residuals of degree at most two. Its unique
root, when one exists, contains the exact firing counts and all sink outputs.

Theorem 4.1 gives a corresponding canonical construction for grammar-compressed
periods. The executable grammar component checks local prefix paths; the package
does not include a separate global symbolic grammar compiler.

Theorems 7.1 and 8.1 construct a universal clock with polynomial-time prefix ranks
and prove a conditional equivalence between multiplicity-preserving Diophantine
representations of its one fixed rank function and the corresponding principle
for all computably enumerable sets. They do NOT prove the unrestricted
single-fold or finite-fold representation principle.

The least-action and last-exit mechanisms are classical and are credited in the
article. Priority for the explicit refinements and boundary formulations has not
been established. The new results are mathematical paper proofs, not Lean-checked
proofs or independently peer-reviewed results. Finite Python tests do not replace
the proofs. The universal-clock tests use toy countdown and looping systems to
check the rank mechanism; they do not formally verify a universal Turing machine.

## Reproduce

Requires Python 3.10+ with only the standard library. Run from this directory:

```sh
python verify_certificates.py --output test_results.json
python compile_quartic.py --output example_quartic.json
python compile_quartic.py --variable-lengths --output parametric_quartic.json
```

The verification run checks 123,201 bounded odometer candidates, rejects 13,375
single-coordinate mutations of RLE certificates, checks grammar-prefix paths and
35,952 mutations, and validates an exact certificate for
`2^8192 + 2^4096` firings without simulating them.

The polynomial compiler also compares symbolic and direct residual evaluation
at 500 arbitrary natural assignments for each illustrative output.

Build the article with an ordinary LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The extra pass ensures that the contents and cross-references settle. No
external image assets or font files are needed. Alternatively, use `make all`.

## Use the compiler on another topology

```python
from verify_certificates import Network
from compile_quartic import compile_rle

# One active vertex (0), one sink (1), period: self, self, self, sink.
network = Network(periods=(((0, 3), (1, 1)),), sinks=1)
inputs, witnesses, residuals, polynomial = compile_rle(
    network, variable_lengths=True
)

assert polynomial.degree <= 4
assert len(witnesses) == 13
assert len(residuals) == 11

# Names lambda:0:0 and lambda:0:1 encode positive block lengths minus one.
print(inputs)
print(polynomial.serializable())
```

Destinations `0 .. n-1` are active; `n .. n+s-1` are sinks. Each block is a
`(destination, positive_length)` pair, and every period must be nonempty.
Adjacent blocks may have the same destination. `variable_lengths=False`
specializes the numeric lengths into coefficients. `variable_lengths=True`
keeps one natural parameter per block and interprets the length as parameter + 1.

Natural-number witness semantics are essential. The compiler returns integer
polynomials, but allowing arbitrary signed integer witnesses is not covered by
the uniqueness or soundness theorem. The compiler is not an equation solver.
Its output can be checked at a supplied assignment using `polynomial.evaluate`.

## Repository boundary

The inspected ProveIt snapshot is
`e18718e837d43e162252f9a314e8cb797fbd1a1f`. The article uses the documented MRDP
interface and inspects relevant project documentation. No new files have been
committed to ProveIt, and no claim is made that this work passed the repository's
Lean build or axiom audits.
