#!/usr/bin/env python3
"""Offline exact replay for the MP0/S1 transfer215 research contribution.
Python 3.10+, standard library. --runtime rederives all quantified cases.
The written ordinary proofs and inherited calculus calibration are separate.
"""
from pathlib import Path
import argparse, collections, gzip, hashlib, json, os, subprocess, sys, tempfile, time
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
import source_language as S
import independent_runtime as I

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def encode(T):return ('#! start 0\n'+''.join(f'{q} {b} {w} {"R" if d==1 else "L"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode()
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def mapping(T):
 m={int(q):int(z)for q,z in read(ROOT/'inputs/NATIVE_TO_LEGACY.json').items()}
 for q in sorted({q for q,b in T}|{254}):
  if q not in m:m[q]=q+1000
 assert len(set(m.values()))==len(m)
 return m,{(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}
def span(rows,p):
 ids=[i for i,x in enumerate(rows)if x[0].startswith(p)]
 assert ids==list(range(ids[0],ids[-1]+1));return ids[0],ids[-1]+1

def compare_graphs(A,B):
 """Isomorphism of rooted, read-labeled transition graphs preserving actions.
 A returned mismatch is graph-theoretic, not a realizable tape history.
 """
 f={0:0,254:254};g={0:0,254:254};todo=collections.deque([(0,0,'')]);seen=set()
 while todo:
  a,b,word=todo.popleft()
  if (a,b)in seen:continue
  seen.add((a,b))
  for bit in (0,1):
   x=A[a,bit];y=B[b,bit];w=word+str(bit)
   if x[:2]!=y[:2]:return {'isomorphic':False,'reason':'write/move mismatch','read_word':w,'left_action':x,'right_action':y}
   u,v=x[2],y[2]
   if (u in f and f[u]!=v)or(v in g and g[v]!=u):
    return {'isomorphic':False,'reason':'inconsistent state correspondence','read_word':w,'left_target':u,'right_target':v}
   f[u]=v;g[v]=u
   if u!=254:todo.append((u,v,w))
 return {'isomorphic':True,'matched_states_including_halt':len(f)}

def main():
 assert __debug__ and not sys.flags.optimize and not os.environ.get('PYTHONOPTIMIZE'),'Assertions must be enabled'
 ap=argparse.ArgumentParser();ap.add_argument('--runtime',action='store_true');ap.add_argument('--work',type=Path);args=ap.parse_args()
 work=args.work or Path(tempfile.mkdtemp(prefix='mp0-transfer215-'))
 work.mkdir(parents=True,exist_ok=True)
 start=time.monotonic();result={'status':'RUNNING','working_state_target_214_met':False}
 manifest=ROOT/'MANIFEST.json'
 if manifest.exists():
  for rec in read(manifest)['files']:
   p=ROOT/rec['path'];assert p.is_file()and p.stat().st_size==rec['bytes']and sha(p)==rec['sha256'],rec['path']
  result['manifest']={'status':'PASS','files':len(read(manifest)['files'])}
 # Source mutation and two independent complete guarded CFG resolvers.
 oldrows=read(ROOT/'inputs/parent-transfer201.sites.json');rows=read(ROOT/'source/mp0-transfer201.sites.json')
 old=S.tree(oldrows);new=S.tree(rows)
 expected=S.replace(S.replace(old,'110101',S.subtree(old,'111')),'111',S.subtree(old,'110101'))
 assert new==expected and S.compact(rows)==(ROOT/'source/mp0-transfer201.sites.json').read_bytes()
 assert S.metrics(new)=={'dag_nodes':201,'leaf_occurrences':4775,'maximum_depth':44,'maximum_zero_run':6}
 og=S.graph_intervals(oldrows);ng=S.graph_intervals(rows)
 assert og==S.graph_arithmetic(oldrows)[0]and ng==S.graph_arithmetic(rows)[0]
 bridges=[]
 for label,op,np in [('AX','1101001','1101001'),('MP','110101','111'),('S','111','110101')]:
  a,z=span(oldrows,op);b,y=span(rows,np)
  assert z-a==y-b and[x[1:]for x in oldrows[a:z]]==[x[1:]for x in rows[b:y]]
  def local(graph,lo,hi):
   return [[effect,[e-lo if lo<=e<hi else 'EXIT'for e in edges]]for effect,edges in graph[lo:hi]]
  assert local(og,a,z)==local(ng,b,y)
  oe=sorted({e for _,ed in og[a:z]for e in ed if not a<=e<z});ne=sorted({e for _,ed in ng[b:y]for e in ed if not b<=e<y})
  assert len(oe)==len(ne)==1
  if label!='AX':assert S.boundary(S.subtree(old,op))[:2]==(0,0)
  bridges.append({'command':label,'old_span':[a,z],'new_span':[b,y],'old_exit':oe,'new_exit':ne,'relative_CFG_equal':True})
 assert oldrows[:25]==rows[:25]
 assert rows[23][1:]==['CD',3]and rows[24][1:]==['CD',3]
 assert ng[23][1]==[span(rows,'111')[0],24]and ng[24][1]==[span(rows,'110101')[0],25]
 assert rows[4668][1:]==['CB',1]and ng[4668][1]==[0]
 result['source']={'status':'PASS',**S.metrics(new),'guarded_cases':sum(2 if op=='CD'else 1 for p,op,k in rows),'bridges':bridges,'wire_fields':{'MP(x)':[0,'x'],'S':[1],'AX(c;x,y)':['c+2','y','x']}}
 # Two literal row changes; no inferred decoder allocation.
 parent=I.table(ROOT/'inputs/parent-transfer215.native.tm');T=I.table(ROOT/'machine/mp0-transfer215.native.tm')
 assert sha(ROOT/'inputs/parent-transfer215.native.tm')=='1f8194fa49a638857ecf5b4f69b1ae92cb47d11d1a74e952bbb91049c893a836'
 assert parent[201,1]==(1,1,100)and parent[312,1]==(1,1,310)
 expectedT=dict(parent);expectedT[201,1]=(1,1,310);expectedT[312,1]=(1,1,100)
 assert expectedT==T and encode(T)==(ROOT/'machine/mp0-transfer215.native.tm').read_bytes()
 assert sha(ROOT/'machine/mp0-transfer215.native.tm')=='1534c93612398b0e2cd3d5699649ae786b02d75a264a80f9ae70fffff16965d6'
 qs={q for q,b in T};assert len(qs)==215 and len(T)==430 and 254 not in qs
 assert all((q,b)in T for q in qs for b in (0,1))and all(z in qs|{254}for w,d,z in T.values())
 cm={q:i for i,q in enumerate(sorted(qs))};cm[254]=215
 dense={(cm[q],b):(w,d,cm[z])for(q,b),(w,d,z)in T.items()}
 assert encode(dense)==(ROOT/'machine/mp0-transfer215.tm').read_bytes()
 reach={0};todo=[0]
 for q in todo:
  for bit in (0,1):
   z=T[q,bit][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 assert reach==qs
 result['machine']={'status':'PASS','working_states':215,'rows':430,'all_states_graph_reachable':True,'native_sha256':sha(ROOT/'machine/mp0-transfer215.native.tm'),'dense_sha256':sha(ROOT/'machine/mp0-transfer215.tm'),'changed_rows':[[201,1],[312,1]]}
 # Exact blank run, three presentations in lockstep, complete final exterior.
 startup=read(ROOT/'evidence/startup.json');frame=startup['frames'][0]
 assert frame['steps']==68442 and frame['head']==-2 and frame['logical']==[1,11,2,0,0,0,0,0,0]
 assert frame['spares']==[1]*59 and frame['gap']==0 and rows[55][0]==frame['pc']=='110100100101010'
 wanted={v-2 for v in I.frame(frame['pc'],frame['logical'],frame['spares'],0)}
 assert wanted==set(frame['one_cells'])
 q=h=dq=dh=bq=bh=0;ones=set();dones=set();left=bytearray(4096);right=bytearray(4096);used=set()
 for tick in range(68442):
  bit=int(h in ones);used.add((q,bit));w,d,q=T[q,bit]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d;w,d,dq=dense[dq,int(dh in dones)]
  if w:dones.add(dh)
  else:dones.discard(dh)
  dh+=d
  cells,j=(right,bh)if bh>=0 else(left,-1-bh);assert 0<=j<len(cells)
  w,d,bq=T[bq,cells[j]];cells[j]=w;bh+=d
  assert(q,h)==(bq,bh)and(dq,dh,dones)==(cm[q],h,ones)
 bset={i for i,b in enumerate(right)if b}|{-i-1 for i,b in enumerate(left)if b}
 assert(q,h)==(84,-2)and ones==bset==wanted and sorted(used)==[tuple(x)for x in startup['used_rows']]
 assert (201,1)not in used and(312,1)not in used
 result['blank_start']={'status':'PASS','steps':68442,'state':q,'head':h,'site_ordinal':55,'pc':frame['pc'],'logical':frame['logical'],'unit_spares':59,'one_cells':len(ones),'three_presentations_agree':True,'changed_rows_unused_before_frame':True}
 # Partial AX identification; not mistaken for a root frame.
 match=read(ROOT/'inputs/ax_bootstrap_match.json');pc=25;regs=[1,0,4,0,0,0,0,0,0];trace=[]
 for tick in range(174):
  trace.append([pc,regs.copy()]);effect,edges=ng[pc];op=effect[0]
  if op=='increment':regs[effect[1]]+=1;pc=edges[0]
  elif op=='decrement':
   k=effect[1]
   if regs[k]:regs[k]-=1;pc=edges[1]
   else:pc=edges[0]
  else:assert op=='identity';pc=edges[0]
 assert trace==match['trace']and(pc,regs)==(55,frame['logical'])
 result['AX_prefix']={'status':'PASS','steps':174,'entry_ordinal':25,'entry_registers':[1,0,4,0,0,0,0,0,0],'exit_ordinal':55,'completed_AXIOM_safe_heads':10,'arbitrary_tail':4,'next_candidate':1,'new_credit':1}
 # Fixed finite dominated-to-unrestricted calculus certificate.
 import check_fixed_certificate as C
 cert=C.verify(C.read_json(ROOT/'inputs/dominated_rho8_full_certificate.json'),True)[0]
 assert cert['verified']and cert['proof_nodes']==3728 and cert['term_table_nodes']==5160
 result['dominated_certificate']=cert
 # Independent finite corroboration of the separate infinite induction.
 subprocess.run([sys.executable,str(ROOT/'code/check_mp0_s1_credit.py'),'--output',str(work/'credit.json')],check=True,stdout=subprocess.DEVNULL)
 assert read(work/'credit.json')==read(ROOT/'evidence/mp0_s1_credit.json')
 result['finite_credit']=read(work/'credit.json')
 if (ROOT/'code/check_raw_seed.py').exists():
  subprocess.run([sys.executable,str(ROOT/'code/check_raw_seed.py'),'--output',str(work/'raw_seed.json')],check=True,stdout=subprocess.DEVNULL)
  assert read(work/'raw_seed.json')==read(ROOT/'evidence/raw_seed.json')
  result['finite_raw_seed']=read(work/'raw_seed.json')
 # Reject state renaming against every included selected comparator.
 comparisons=[]
 for p in sorted((ROOT/'inputs/comparison').glob('*.native.tm')):
  ans=compare_graphs(T,I.table(p));assert not ans['isomorphic'],p
  comparisons.append({'file':p.name,'sha256':sha(p),**ans})
 ans=compare_graphs(T,parent);assert not ans['isomorphic']
 comparisons.append({'file':'parent-transfer215.native.tm','sha256':sha(ROOT/'inputs/parent-transfer215.native.tm'),**ans})
 result['graph_distinction']={'status':'PASS','comparisons':comparisons,'scope':'Rejects pure state renaming for included pinned comparators; no exhaustive novelty or state minimality claim.'}
 print('PASS: exact construction, source graphs, 215-state table, three-way blank replay, AX prefix, finite certificates and graph distinctions',flush=True)
 # Re-derive every arbitrary-natural whole-tape primitive contract.
 if args.runtime:
  import symbolic_runtime as Q
  m,L=mapping(T);lemmas,blocks=Q.prove_blocks(L);records=[];coverage=set()
  for i,site in enumerate(rows):
   for positive in ((False,True)if site[1]=='CD'else(False,)):
    ans=Q.case(L,lemmas,site,positive);coverage.update(ans['rows']);ans['rows']=sorted(ans['rows']);ans.pop('trace')
    records.append({'site_index':i,'positive':positive,**ans})
   if(i+1)%1000==0:print('Runtime source leaves:',i+1,'cases:',len(records),flush=True)
  for block in blocks:
   for event in block['trace']:
    if event[0]!='list':coverage.add(tuple(event[1][:2]))
  reference=read(ROOT/'evidence/runtime.json')
  expected_records=json.loads(gzip.decompress((ROOT/'evidence/runtime_cases.json.gz').read_bytes()))
  assert json.loads(json.dumps(records))==expected_records
  assert json.loads(json.dumps(blocks))==reference['blocks']
  assert len(records)==6209 and sum(x['symbolic_steps']for x in records)==1610781
  assert min(x['duration'][0]for x in records)==10 and len(coverage)==430
  assert all(all(c>=0 for c in x['duration'])and x['duration'][0]>0 for x in records)
  assert sha(ROOT/'code/symbolic_runtime.py')==reference['checker_sha256']and sha(ROOT/'code/independent_runtime.py')==reference['helper_sha256']
  result['runtime']={'status':'ALL_NATURAL_PASS','cases':6209,'symbolic_rules':1610781,'minimum_affine_duration_constant':10,'rows_covered':430,'ordered_certificate_exact_match':True,'kernel_checked':False}
 result.update(status='FULL_REPLAY_PASS'if args.runtime else'FINITE_REPLAY_PASS',seconds=time.monotonic()-start)
 save(work/'replay.json',result);print(json.dumps({k:v for k,v in result.items()if k not in ('source','dominated_certificate','finite_credit','graph_distinction')},indent=2));print('Full receipt:',work/'replay.json')
if __name__=='__main__':main()
