# A self-sanitizing prefix for the MP-first three-command enumerator

## Result

Let E be the three-command source enumerator with tags MP=0, S=1, AX=c+2,
where S is the composite oldDROP;oldNIP;oldNIP. Start at a valid complete
source command boundary with next candidate N=0, empty proof pointer, zero
scratch registers, and arbitrary natural logical data (t,w,d,h). No initial
theoremhood or formula-decoding assumption is imposed on these four values.

Put I(a,b)=4P(a,b) for Cantor pairing P. The exact exceptional condition is

    Bad(t,w,d,h) :<=> d=1 and h=I(t,1).

The following ordinary theorem is formalizable in ZFC, relative to the
explicitly inherited numerical-calculus and source-macro calibrations:

    Halt(E; N=0,t,w,d,h)
      <=> Bad(t,w,d,h) OR the native calculus derives code 1
      <=> Bad(t,w,d,h) OR not Con(ZFC).                (Theorem)

Thus every raw initial tuple outside one explicitly decidable relation is
an equally calibrated consistency search. This is a statement about raw
register values in a valid source frame, not arbitrary unstructured tape
configurations. A physical machine using such a frame still requires its
own exact initializer and complete binary/source simulation proof.

In particular, **every initial counter d different from 1** permits arbitrary
raw top, cache and stack values. The simple requirement d=0 is a useful
special case for an initializer. When d=1, the exact necessary exclusion is
the displayed equality h=I(t,1); there are no further exceptional tuples.

For the especially useful family t=d=h=0, the entire encoded stack w can
be arbitrary, with ZERO explicitly protected theorem heads initially.
There is no exceptional w. The simpler proof of that family is given below,
but the full theorem permits arbitrary junk in all four logical registers
apart from the displayed Bad relation.

## 1. Four initial candidate words

The field lists are

    MP(x)=[0,x], S=[1], AX(c;x,y)=[c+2,y,x].

Fresh candidates are read without an outer successor. Positive continuation
pointers are decremented before reading their next command. Direct Cantor
unpairing gives the first four complete candidate words:

    W(0) = MP(0),
    W(1) = S,
    W(2) = MP(1),
    W(3) = AX(0;0,0).

All four have empty continuations. In particular unpair(2)=(0,1) and
unpair(1)=(1,0), so candidate 2 really is MP with payload 1, not payload 0.
After these four words the next-candidate counter is 4 and the proof
pointer is again zero.

The arithmetic source macros terminate on all natural inputs. MP and AX
have no halt. Thus before the completion of W(3), only W(1)=S can halt.

## 2. Exact first-S exception

MP(0) sets its comparison target to y=d. It always resets cache to 0 and
leaves counter d. If h=I(t,d), it returns top d and pushes theorem zero;
otherwise it returns top 0 and leaves the old stack unchanged.

S tests both incoming top and cache for code 1. Its incoming cache is now
0. Its incoming top is d exactly on successful MP, and otherwise 0.
Therefore S halts if and only if d=1 and h=I(t,1), exactly Bad.

If Bad is false, S finishes. Whatever stack head it pops, its output top is
the old cache 0. Denote its output stack by v and its newly loaded cache by
x. Both v and x may be completely arbitrary numerical values. The store is

    (0,v,d,x).

It is intentional that x need not be a theorem: the next command consumes
it before any further halt test or theorem generalization is performed.

## 3. The only possible junk conclusion is immediately buried

Candidate 2 is MP(1). Its comparison target is d+1 and its antecedent is
the current top 0. It returns

    (d+1,[0;v],d+1,0)      if x=I(0,d+1),
    (0,v,d+1,0)            otherwise.

Write its top as z and its stack as v'. Thus z is either d+1 or 0,
counter is d+1, and cache is 0. The value z may equal 1, and need not be a
native theorem. MP itself does not halt, and there is no S before candidate
3's AX. No theoremhood assertion is made about z at this intermediate point.

Candidate 3 is AX(0;0,0). Its exact parameters are

    U=A=d+1, B=0, C=0.

The dominated condition U<=A holds with equality. The bundle gate is zero
because B=C. AX returns top, counter and cache all zero and stack

    [r1,...,r7,L(d+1,0,0,d+1),Q_(d+1)(0),z;v'].

The first eight heads are native axiom instances, including the dominated
row with U=A. The ninth is a theorem generalization of truth 0. Hence the
first NINE heads are actual theorems, independently of every original raw
input. The last saved z is not counted as safe; combine it with v' into one
arbitrary tail J=[z;v'].

We have now reached a root with next candidate N=4, empty proof pointer,
zero top/cache/counter and nine explicit theorem heads over arbitrary J.
Every possibly invalid formula value has either been erased or buried below
those nine safe heads, before any instruction could test the suspect z for
falsity. This completes the finite self-sanitization argument.

## 4. Nine theorem heads remain sufficient forever

The independent all-natural diagonal theorem for the new tags is in
mp0_s1_credit_proof.md. It assigns conservative balances MP=0, S=-1, AX=10
and proves every full Cantor diagonal s>=2 prefix-safe. At arbitrary cutoff
N, the exact required credit d(N) is the minimum-prefix deficit of the finite
suffix through that cutoff's diagonal end, with the first small diagonals
handled explicitly.

Here the remaining words of diagonal 2 are

    W(4) = S;MP(0),
    W(5) = MP(0);MP(0).

Their concatenation has conservative minimum -1. Every later diagonal is
prefix-safe. Therefore d(4)=1 exactly. The nine safe heads created above
leave a permanent conservative margin of eight.

Every subsequent S loads a protected theorem head; every subsequent MP
acts on theorem-valued top/cache; every subsequent AX introduces only
native axioms, a permitted bundle, a valid generalization and a saved
theorem top. Consequently every subsequent halt gives a native refutation.
The arbitrary tail J, including suspect z, is never exposed.

As in the credit theorem, protected length is a maintained finite-list
witness, not a decoded property of the natural w. The identity
unpair(P(a,b))=(a,b) is valid even when a=b=0. Thus raw zero aliases do not
invalidate either the finite prologue or permanent protection.

## 5. Completeness and the exact input theorem

If Bad holds, the program halts during its first S, regardless of the
calculus. Suppose Bad is false. Sections 1-4 give the protected N=4 root
after a finite prefix without halting, and prove soundness from there.

For completeness, the inherited strong compiler produces a finite successful
block from every top/stack pair after an initial AX resets cache/counter.
Under the new tags, the padding candidate

    P(2,P(Y,P(1,r))) >= Y

still begins with AX(0;1,Y) and runs a fixed successful refutation suffix
encoded by r. Successful candidates are cofinal. Every preceding nonhalting
candidate drains strictly, so a native refutation forces a halt after any
finite initial cutoff, in particular N=4. This proves both implications in
(Theorem), including all arbitrary raw inputs and the exceptional branch.

No unconditional consistency or nonhalting statement follows. The theorem
is an exact conditional calibration of a recursively defined enumerator.

## 6. The clean zero-counter family needs no initial protected heads

For t=d=h=0, the first MP(0) succeeds by I(0,0)=0 and pushes a zero. Candidate
1's S pops precisely that newly pushed zero, giving

    (0,w,0,0) -- MP(0);S --> (0,w,0,0).

Candidate 2's MP(1) then fails, because I(0,1)=8 differs from cache 0, and
returns (0,w,1,0). The next counter is 3, a triangular cutoff with d(3)=0.
The diagonal theorem therefore applies immediately with zero protected
heads, without waiting for the more general nine-head argument.

This exact three-command prefix preserves the arbitrary original w and
never loads one of its heads. The natural t=0,h=0,d=0 hypothesis is only
needed for this particularly simple cancellation identity, not for the
stronger full theorem.

## 7. Direct h-only transfer removes even the exception

For the source-level direct transfer S(t,w,d,h), whose only halt guard is
h=1, the preceding proof strengthens further. MP(0) always sets h=0, so
the first S cannot halt even when d=1. Its normal return still sets top 0.
Sections 3-5 then apply without any Bad exception:

    Halt(E_direct;N=0,t,w,d,h) <=> not Con(ZFC)

for ALL raw natural t,w,d,h in a valid root frame.

This is an abstract command/source interface theorem. It does not assert
that a newly edited direct-transfer binary table has passed its physical
runtime proof. It identifies a concrete stronger bootstrap target for a
future 214-state allocation.

## Attribution and novelty boundary

The numerical calculus, its ZFC calibration, the original transfer command
compiler, and the protected-tail method are inherited. The MP=0/S=1 command
encoding changes the actual numerical enumeration. The new diagonal credit
calculation and the finite self-sanitizing prefix above are new interface
results for that encoding. Related arbitrary-tail results in earlier
four-command families are not claimed as new here.

The fixed candidate's current blank initializer enters a separately matched
partial AX at N=1; its published blank equivalence uses that exact trace and
the N=1 credit theorem. The uniform N=0 theorem is a stronger additional
startup interface for future allocation searches, not an assertion that the
current blank run visits N=0 or an already achieved 214-state saving.
