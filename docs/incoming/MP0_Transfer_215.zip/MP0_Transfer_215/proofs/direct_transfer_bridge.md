# Direct implementation of the transfer-pop command

## Exact all-natural source contract

The new subtree at source address 111 is

    ((CLEAR_T, COPY_H_TO_T_PRESERVING_H), oldNIP).

Its left child has 9 primitive occurrences and oldNIP has 26, giving 35
occurrences in total. The old composite oldDROP;oldNIP;oldNIP had 78.
The first two exact source expressions are:

    CLEAR_T = (CD1, CC1)
    COPY_H  = ((CD5,(CI1,(CI6,CC3))), (CD6,(CI5,CC2))).

Registers 1,5,6 are T,H,X. At a command boundary X=0 and the unchanged oldNIP
macro has its inherited all-natural contract. Other scratches required by
oldNIP are zero under the same boundary invariant.

CLEAR_T performs exactly t positive decrement/continue iterations and one
zero test, so terminates with T=0 in 2t+1 source steps. The first COPY_H loop
decrements H and increments both T and X. After h iterations its state is
T=h,H=0,X=h. The second loop restores H by transferring X back to it, leaving
T=h,H=h,X=0. These loops take (4h+1)+(3h+1) source steps. Thus the new prefix
has exact all-natural effect

    (t,w,d,h; X=0) -> (h,w,d,h; X=0)

in 2t+7h+3 source steps, preserving every other register. This argument is
unary induction, not testing a finite collection of register values. It
also establishes termination for t=0 or h=0.

Now oldNIP tests H=1, and otherwise unpairs W into new H and W while leaving
T,D unchanged and restoring its scratches. Therefore, writing
unpair(w)=(x,v), the complete direct command is EXACTLY

    S(t,w,d,h) = halt          if h=1;
               (h,v,d,x)      otherwise.

This is the original transfer command of the incoming transfer compiler
packet's proofs/transfer_compiler.md. The previous physically implemented
composite additionally tested t=1. The direct implementation intentionally
removes that additional early halt, but it retains the original proved
command contract. No claim of two-way behavioral equivalence between those
commands is needed; the original compiler applies directly.

## Completeness does not depend on the removed top test

In the original compiler the terminal macro H=AX(0;0,0);S^11 tests a saved
top through the cache. After ten shifts, its store is

    (Q_d(h), w, 0, t).

The eleventh shift sees cache t and halts if t=1. Thus H still detects a
refutation returned in top even though a single S no longer tests its
incoming top. All other structural macros and strong proof blocks in the
original transfer compiler were proved for this h-only guard.

In particular PUSH=AX(0;0,0);S^9;MP(0) fails its MP by disjoint tags, and
DISCARD=MP(1);AX(1;0,0);S^10;MP(0) uses only forced failures. Axioms,
generalization, and major-first modus ponens retain the exact original
strong contract: every native theorem X has a finite word that, from every
(t,w,0,0), halts or returns (X,w,0,0). Successful candidate codes remain
cofinal through the unchanged initial AX(0;1,Y) padding construction.

If the direct command is also combined with omitted-successful-push MP,
the modified MP proof in omit_transfer_proof.md applies without change.
That proof's exact nonhalting equations do not rely on the extra top=1
guard; removing it can only allow a previously permitted early-halt branch
to continue along the displayed equations. When A=1 the second premise
shift still tests A through cache, and when conclusion B=1 the final shift
still tests B through cache. The generic terminal H still tests top1.

## Soundness with the dirty initial tail

The protected-credit theorem was explicitly proved for both the original
h-only S and the composite with its extra top guard. Its syntactic scheduler
and balances remain S=-1, MP=0, AX=10. Since the direct prefix changes
neither W nor d and preserves H, it introduces no extra pop and no new
formula code. It changes T to an already theorem-valued H. OldNIP's halt
therefore tests a theorem-valued H, and its one pop loads the protected
theorem head guaranteed by the same balance inequality.

For cutoff N=1 and empty proof pointer, the conservative required credit is
exactly 2. Completing the matched initial AX gives ten theorem heads over
the arbitrary numerical tail 4, so at least eight protected heads remain
permanently. Tail 4 does contain falsity codes, but they are never loaded.
The direct implementation neither strengthens nor weakens this invariant.

This transfer requires the NEW physical blank run to be matched to the
stated partial AX frame (or another independently calibrated frame).
The command proof alone does not establish startup. Similarly, the new
35-leaf source and physical decoder must receive their own complete
primitive-runtime certificate; the old composite's certificate cannot be
relabelled as one for a changed source.

## Why consuming H before the old NIP does not work

The tempting cheaper prefix CLEAR_T;TRANSFER_H_TO_T destroys H. Immediately
after it H=0. If the unchanged oldNIP is then invoked, its only halt test
always sees zero. AX and MP do not halt. Consequently a command language
consisting of that modified transfer, AX and MP never reaches its semantic
halt, for any command word. It cannot implement a nontrivial consistency
search by the existing calibration.

An exact alternative is to test H=1 BEFORE consuming it, then run CLEAR_T;
TRANSFER_H_TO_T and only the pop suffix of oldNIP. That reordering has the
same S contract. It still needs a correctly identified split of oldNIP,
scratch restoration, an exact source CFG, physical allocation, startup and
runtime proof. It is an optimization suggestion, not a verified table.

## Status and attribution

The h-only command compiler and protected-credit theorem are inherited
ordinary mathematical results from the incoming transfer compiler packet.
This note independently checks their applicability to the new direct
35-primitive implementation, including termination, the removed early-halt
case, and dirty-tail safety. It does not claim a new theory of strength ZFC,
unconditional nonhalting, a compiled proof-assistant endpoint, or a machine
state count before literal verification.
