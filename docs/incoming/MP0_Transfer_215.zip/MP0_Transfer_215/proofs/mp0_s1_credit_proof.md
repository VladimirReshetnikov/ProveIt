# Protected-tail credit for MP tag 0 and transfer-pop tag 1

## Scope and theorem

This is a new all-natural scheduler proof for the command permutation

    MP(x): tag 0, fields [0,x];
    S:     tag 1, fields [1];
    AX(c;x,y): tag c+2, fields [c+2,y,x].

The command contracts, numerical calculus, strong proof blocks, and AX output
count are unchanged. S may be either the h-only direct transfer or the
already implemented composite oldDROP;oldNIP;oldNIP. Nonhalting S removes one
head and preserves theoremhood. MP conservatively changes zero heads (an
actual successful old MP adds a theorem zero). AX adds ten theorem heads.

**Theorem.** At the complete command root with next candidate N=1 and empty
proof pointer, one explicit theorem head above an arbitrary numerical stack
tail suffices to protect that tail forever, provided current top and cache
are theorems. This bound is exact for the conservative balance assignment.
The matched initial AX supplies ten heads, hence leaves a permanent
conservative margin of nine. This is an infinite-prefix theorem, not an
inference from finite simulations.

The proof below rederives the credit for these new tags. The earlier S=0,
MP=1 credit bound is not silently transferred across the permutation.

## 1. Exact syntactic word recurrence

Let P(a,b)=(a+b)(a+b+1)/2+b, let f(n) be its right projection, and let
T_s=s(s+1)/2. Then

    unpair(T_s+y)=(s-y,y), 0<=y<=s, and f(n)<=n.

Let W(n) be the entire finite command word decoded from freshly fetched
candidate n, ignoring semantic halts. A positive continuation pointer is
decremented before its next command; define R(0)=[] and R(r)=W(r-1) for r>0.

Writing unpair(n)=(a,y), the new recurrence is exactly

    W(n)=MP;R(f(y))       if a=0,
    W(n)=S;R(y)           if a=1,
    W(n)=AX;R(f(f(y)))    if a>=2.

MP consumes one further field, S consumes none, and AX consumes two. These
are precisely the arities [2,1,3] of the stated wire language. Each positive
residual r is at most n, so the recursive call has index r-1<n. Induction
proves that W(n) has at most n+1 commands. Therefore R(r) has at most r
commands and every prefix of R(r) has conservative balance at least -r.

Assign balances MP=0, S=-1, AX=10. Let b(n) be the total balance of W(n),
m(n) its minimum prefix balance including the empty prefix, and

    B(k)=sum_{0<=n<k} b(n).

Put g(0)=0 and g(r)=b(r-1) for r>0.

## 2. Prefix-pullback lemma

If q(0),q(1),... has nonnegative initial partial sums, so do q(f(0)),q(f(1)),...
and q(f(f(0))),q(f(f(1))),....

Proof: as n increases, the sequence f(n) concatenates

    [0], [0,1], [0,1,2], ... .

Every finite prefix consists of complete such blocks and one initial partial
block. Its q-sum is consequently a sum of nonnegative initial q-sums. Repeat
the argument for the double pullback. Only the finite initial sums used by
the chosen prefix are needed.

Use q(r)=g(r)+1. For k>=1,

    sum_{r<k}q(r)=1+B(k-1)+(k-1).

Thus previously proved inequalities B(j)+j>=0 give the required pullback
hypotheses. In particular this does not assume the false stronger statement
B(j)>=0.

## 3. Every diagonal s>=2 is prefix-safe

We prove jointly by induction on the Cantor diagonals:

1. B(k)+k>=0 at every completed candidate boundary;
2. B(T_s)>=-1 at every completed diagonal boundary;
3. each full diagonal s>=2, concatenating W(T_s) through
   W(T_(s+1)-1), has nonnegative balance at EVERY command prefix relative to
   that diagonal's start.

The exceptional first candidates are

    W(0)=[MP], W(1)=[S], W(2)=[MP].

Hence B(0),B(1),B(2),B(3)=0,0,-1,-1. This establishes the induction base
through the start of diagonal s=2, including B(k)+k>=0.

Fix s>=2. The diagonal's first s-1 candidates, positions y=0,...,s-2,
begin with AX. The penultimate candidate y=s-1 begins with S. The last
candidate y=s begins with MP. This order is a consequence of a=s-y and is
the reason the former tag proof cannot be copied without modification.

For the first k AX candidates their total balance is

    10k + sum_{y<k} g(f(f(y))) >= 9k.                 (1)

Indeed the double pullback applied to q=g+1 gives a nonnegative sum, then
subtract k. All required q-prefix indices are at most s-2, strictly less
than T_s, so the induction use is well founded and not circular.

Before AX candidate y, the accumulated relative balance is at least 9y.
After its first command the gain is another 10, while any prefix of its
continuation R(f(f(y))) loses at most f(f(y))<=y. Every such prefix therefore
has relative balance at least

    9y+10-f(f(y)) >= 8y+10 > 0.                     (2)

The candidate's empty prefix is also nonnegative. This proves prefix safety
through the entire AX portion and gives balance at least 9(s-1) afterward.

The penultimate S candidate contributes -1 immediately and then executes
R(s-1), whose prefixes lose at most s-1. Every prefix after that S, including
its final boundary, has balance at least

    9(s-1)-1-(s-1) = 8s-9.                         (3)

The last MP contributes zero and has continuation R(f(s)), whose prefixes
lose at most f(s)<=s. Hence every prefix of the last candidate has balance
at least

    8s-9-f(s) >= 7s-9 > 0,                         (4)

since s>=2. Statements (2)-(4) prove the entire diagonal prefix-safe; its
final balance is positive. Adding the inherited absolute bound
B(T_s)>=-1 gives B(k)>=-1 at every candidate boundary in this diagonal.
Those k are at least 3, so B(k)+k>=0, and the next diagonal boundary again
has B>=-1. This closes all three induction assertions.

Consequently the full infinite conservative schedule from candidate 0 has
minimum prefix balance exactly -1: the prefix through W(1) realizes -1,
and the induction proves that no later prefix is smaller.

## 4. Exact finite credit formula at arbitrary cutoffs

For cutoff N choose s with T_s<=N<T_(s+1), and put

    E(N)=max(3,T_(s+1)).

Let d(N) be the negative of the minimum prefix balance (including empty)
of the finite word W(N);...;W(E(N)-1). Every later complete diagonal is
prefix-safe and ends with nonnegative relative balance. Its start therefore
cannot lower the minimum already realized in that finite initial segment.
Thus d(N) is the exact conservative credit for the entire infinite schedule
from N. This is a finite formula for an infinite-prefix quantity, not a
truncation heuristic.

For N=1, E(1)=3 and the finite word is [S,MP]. Therefore

    d(1)=1.

One head is necessary in the conservative sense because the very first
command is S, and sufficient by the preceding proof. Also d(0)=1 and every
triangular cutoff T_s with s>=2 has d(T_s)=0.

If a nonempty initial proof pointer p must drain before fresh candidate N,
write b,m for the total/minimum of R(p). The corresponding exact sufficient
conservative credit is max(0,-m,d(N)-b), by concatenating that finite word
with the certified infinite tail.

## 5. Protected-tail invariant and zero aliases

Represent the stack as a finite explicit list of theorem heads over one
fixed arbitrary numerical tail J. No theoremhood or syntax hypothesis is
made about J. Let the initial list contain at least d(N) heads and let top
and cache initially be theorems.

The balance theorem ensures that immediately before every S there is at
least one explicitly represented theorem head: after its -1 cost the
conservative list length remains nonnegative. AX adds ten theorem heads.
MP leaves the conservative list unchanged and may actually push theorem 0.
S's single net pop therefore loads an explicit theorem head rather than
anything in J. Its old-cache-to-top transfer also moves a theorem. Both
possible composite-S halt guards test theorem values. Every actual halt
therefore exhibits native theorem 1.

The list length is an auxiliary witness, not recoverable from the encoded
natural. In particular [0;0]=P(0,0)=0 does not invalidate the reasoning:
unpair(P(x,v))=(x,v) is an exact identity for every x,v, including 0,0.
Explicit zero wrappers may be inserted and removed even when the integer
encoding stays unchanged. No disjoint nil/cons assumption is used.

For the actual matched initial AX, the completed store has next candidate
1, empty proof pointer, top/cache 0, and stack

    [R1(0,0,0),...,R7(0,0,0),L(0,0,0,0),Q_0(0),0;4].

All ten heads are native theorems. Tail 4 is intentionally arbitrary and is
not safe by itself: 4=P(1,1), and 1=P(1,0). The new credit requirement is
one, so the actual ten heads leave at least nine safe heads at every future
command boundary unless the machine has already halted soundly.

The physical blank trace, exact partial-AX source match, whole register
store, scheduler fields, and complete primitive simulation are separate
required premises. The credit theorem does not establish them by itself.

## 6. Completeness and changed wire encoding

The strong compiler's command words are unchanged; only their numeric tags
are permuted. With F(fields,r) equal to right-folded Cantor pairing, use
tail([])=0 and tail(k::L)=1+F(fields(k),tail(L)). The fresh initial candidate
is read without that outer successor. Each positive continuation strictly
decreases after its predecessor and field projections, so no nonhalting
candidate can block all later candidates.

If native code 1 is derivable, let r be the newly encoded tail of the fixed
successful block B_1;H. The initial padding command AX(0;1,Y) still has tag
2 and candidate code

    N_Y=P(2,P(Y,P(1,r))) >= Y.

It resets the counter and cache; the strong block works over every top and
stack, including a protected arbitrary suffix. Successful candidates remain
cofinal, so the permitted startup halts iff the native calculus derives 1.
The inherited native-calculus comparison then identifies this with finite
ZFC refutability.

This is ordinary mathematics formalizable in ZFC. A finite recurrence
checker is supplied only as corroboration of indexing and arithmetic; it
does not replace Sections 1-5 or imply a proof-assistant endpoint.
