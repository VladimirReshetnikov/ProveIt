# Transfer-pop with no successful-MP push

## Contribution and inherited boundary

This note supplies the ordinary all-natural command-calculus proof for combining
the incoming transfer-pop compiler with the earlier omitted-zero MP idea. The
combination itself changes the implemented enumerator: successful MP no longer
pushes a dummy theorem zero. It is not a state renaming or a claim that the
old and new command stores agree.

The numerical calculus is exactly the inherited dominated calculus. No axiom,
inference rule, tag, pairing, or gated set-theoretic bundle is weakened. Its
inherited theorem is that derivability of natural code 1 is equivalent to a
finite ZFC refutation. The new proof obligation is the command compiler below.
The exact binary runtime and blank-start obligations must be established for
the new physical table separately.

Let P(a,b)=(a+b)(a+b+1)/2+b, I(a,b)=4P(a,b), Q_i(a)=4P(i,a)+2.
Truth is 0 and falsity is 1. Use [x;w]=P(x,w) for a stack. All quantities below
are arbitrary natural numbers, including malformed formula codes and the
aliases I(0,0)=0 and [0;0]=0.

## New command contracts

At a boundary the store is (t,w,d,h), with current theorem t, stack w,
additive counter d, and cache h. If unpair(w)=(x,v), the transfer-pop command
is exactly the already constructed composite oldDROP;oldNIP;oldNIP:

    S(t,w,d,h) = halt                         if t=1 or h=1;
               (h,v,d,x)                     otherwise.

For y=d+x the modified numeric-input command is

    M(x)(t,w,d,h) = (y,w,y,0)                 if h=I(t,y);
                  (0,w,y,0)                  otherwise.

Thus BOTH outcomes leave w untouched. The old successful branch produced
[0;w]; this is the only changed high-level command equation.

AX(c;x,y) remains unchanged. Put U=d,A=d+x,B=h+y,C=c. Its output is

    (G(A,B,C), [r1,...,r7,L(A,B,C,U),Q_U(h),t;w], 0,0).

Here r1,...,r7 and L are the unchanged axiom rows, U<=A, and G is the full
original gated bundle. Every ri, L, and G is implication-coded and therefore
not 1; Q_U(h) is positive with tag 2 and therefore neither 0 nor 1. In
particular AX never itself halts. G is 0 whenever C=A or C=B.

## Soundness

If t,h and the stack heads that are read are native theorems, every new
command preserves that condition. On successful M, equality h=I(t,y) gives
theoremhood of y by native modus ponens. On failure M emits theorem 0.
No stack head is removed or introduced by M. AX introduces only retained
axioms, the permitted bundle, Q_U(h) by theorem generalization, and saved t.
S only moves theorem values and halts only on an existing theorem 1. These
facts do not depend on decoding numbers as syntax.

## Structural macros: all earlier failure uses stay exact

Write D=AX(0;0,0), and concatenate finite command words from left to right.

    H        = D; S^11
    PUSH     = D; S^9; M(0)
    DISCARD  = M(1); AX(1;0,0); S^10; M(0)
    J(0)     = empty
    J(u>0)   = M(u)

The following are numerical identities, not bounded tests.

1. For w=[x;v], H either halts when t=1, or returns (t,v,0,x).
   AX protects the old cache and top. After ten shifts it has reached
   (Q_d(h),w,0,t). The eleventh tests the saved top and pops one original head.
2. PUSH always returns (0,[t;w],0,0). Immediately before its M(0), top is L,
   stack is [t;w], counter is 0, and cache is Q_d(h). The test fails because
   I(L,0) has tag 0 and Q_d(h) has tag 2. Hence the changed success branch
   is not used. In particular PUSH works even for t=1, h=1, or w=0.
3. From (t,w,0,0), DISCARD returns (0,w,0,0). Its first M fails because
   I(t,1)>0. The following AX has A=C=1 and saved top 0. Ten shifts leave
   (Q_1(0),w,0,0); the last M fails because Q_1(0)>0. Neither call uses the
   changed success branch.
4. From (0,w,0,0), J(u) returns (0,w,u,0). For u>0,
   I(0,u)>0 makes M(u) fail. For u=0 the command is omitted. Executing M(0)
   here would be a successful command, although unlike the older semantics
   it now leaves the stack untouched. The omission remains convenient.

Each statement includes arbitrary w. Where an original head must be popped,
the statement explicitly writes w=[x;v]; no hidden safe-stack assumption is
used in the completeness compiler.

## Strong compilation theorem

For every native theorem X there is a finite word B_X such that, for ALL
natural t,w,

    (t,w,0,0) -- B_X --> halt, or (X,w,0,0).              (Strong)

The arbitrary tail need not contain theorems. This is a completeness contract;
actual-run soundness is the separate theorem above.

Truth uses B_0=DISCARD. The retained axiom and bundle blocks are unchanged:

    B_Rj(a,b,c) = DISCARD; AX(c;a,b); S^(j+1); H^(9-j), 1<=j<=7;
    B_L(a,b,c,u)= DISCARD; J(u); AX(c;a-u,b); S^9; H,     u<=a;
    B_G(a,b,c) = DISCARD; AX(c;a,b); H^10                (permitted bundle).

The chosen row is transferred to top, and H removes the remaining generated
heads while preserving that top. The last generated head is saved zero, so
the final cache is zero. AX also resets the counter. No original tail is read.

Given B_X, the unchanged generalization block is

    B_Qi(X) = B_X; PUSH; J(i); S; AX(i;0,0); S^10.

After PUSH and J(i), S takes (0,[X;w],i,0) to (0,w,i,X), without testing the
newly loaded X. AX has U=A=C=i and zero gate; ten shifts return Q_i(X) on
exactly w, with d=h=0. The only M used by PUSH or J is guaranteed to fail.

### The new modus ponens block

Let M0=I(A,B), and suppose (Strong) is available for M0 and A. Define

    B_B = DISCARD; PUSH;
          B_M0; PUSH; B_A; PUSH;
          S; S; M(B); AX(B;0,0); S^11.

The NEW prefix DISCARD;PUSH is essential. It prepares a dummy zero under
both premises before the successful inference, rather than making the machine
push that zero after every successful inference. This moves a bookkeeping
operation from the interpreter into a compiled proof word.

Ignoring permitted earlier halts, the exact stores are:

    after DISCARD;PUSH                (0,[0;w],0,0)
    after B_M0;PUSH                   (0,[M0,0;w],0,0)
    after B_A;PUSH                    (0,[A,M0,0;w],0,0)
    after the two S commands          (A,[0;w],0,M0)
    after successful M(B)             (B,[0;w],B,0)
    after AX(B;0,0)                   (0,[r1,...,r8,Q_B(0),B,0;w],0,0)
    after ten following S commands    (Q_B(0),[0;w],0,B)
    after the eleventh S              (B,w,0,0), or halt if B=1.

If A=1, one of the two premise-loading shifts may already halt, which is
permitted. If B=1, the last shift halts. If A=B=0 then M0=I(0,0)=0 and the
success is intentional. The preseeded [0;0]=0 alias does not invalidate the
proof: unpair(0)=(0,0), so popping its designated zero still returns the
original tail 0. Every displayed equation is an identity in Cantor pairing.

Induction on a finite native derivation, expanding shared derivations to a
finite proof tree when needed, proves (Strong). Premise order is major first,
then minor; no circular proof-block dependency appears.

## Fair enumeration and consistency equivalence

The wire encoding is unchanged from the transfer-pop machine:

    fields(S)=[0], fields(M(x))=[1,x], fields(AX(c;x,y))=[c+2,y,x].

For F(fields,r) equal to right-folded pairing, define tail([])=0 and
tail(k::L)=1+F(fields(k),tail(L)). Subsequent commands are read after a positive
proof pointer is decremented; each right projection is at most its input.
Thus every nonhalting candidate drains in finitely many arithmetic/source
steps. The modified M does not alter the proof pointer, scheduler, or fields.

If 1 is derivable, B_1;H halts from every (t,w,0,0). Let r=tail(B_1;H). The
candidate N_Y=P(2,P(Y,P(1,r))) begins with AX(0;1,Y), resets d=h=0, and then
runs this fixed successful suffix. N_Y>=Y, so successful candidates are
cofinal beyond every finite cutoff. Therefore any sound allowed startup
halts iff the native calculus derives 1. With the inherited calibration,
this is equivalent to a ZFC refutation.

## Transfer of the protected-credit theorem

For the transfer-pop scheduler the earlier all-natural credit proof assigned
balances S=-1, M=0, AX=10. It deliberately ignored the old successful M's
extra pushed zero. The new command's balance is EXACTLY 0 on both outcomes;
the same conservative proof therefore applies without changing a single
schedule word, balance, cutoff deficit, or axiom safety argument.

In particular, if the new exact binary blank prefix reaches the same partial
AX source frame as the delivered transfer machine (or another separately
identified frame meeting its hypotheses), completing that source prefix
supplies the same protected heads and the same cutoff-credit certificate.
This is a CONDITIONAL startup transfer until the new table's whole blank
trace is verified; command algebra alone does not establish its initializer.

Once the exact binary table is proved to simulate every source primitive in
positive finite time and its actual blank startup is calibrated, all the
above reasoning is ordinary mathematics formalizable in ZFC and yields

    ZFC proves: Halt(new_machine,blank) iff not Con(ZFC).

It does not assert an already checked proof-assistant endpoint, unconditional
nonhalting, a state lower bound, or any machine count before literal counting.

## Provenance of the composition

The transfer-pop command, structural macros, major-first compiler, encoding,
and protected-credit theorem are inherited from the incoming
Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21 packet and its follow-up.
Omitting the successful-MP push appeared earlier in
candidate-k218/alternatives/omit-zero/proof.md. The new step in this note is
the explicit zero-preseed compiler that makes those two changes compatible;
the simpler two-NIP compiler from the old four-command language is not
silently reused. The associated source deletes the transfer program's
19-primitive successful-PUSH branch while preserving its COPY branch.
