#!/usr/bin/env python3
"""Finite exact arithmetic checks for mp_first_self_sanitizing_theorem.md.

This verifies the finite raw-input prologue and its exceptional halt condition.
It does not verify native axiom soundness, a Turing machine, or the infinite
credit theorem; those are explicit mathematical premises/proofs in the note.
"""
from __future__ import annotations
from math import isqrt
from pathlib import Path
import argparse
import json


def P(a, b):
    return (a + b) * (a + b + 1) // 2 + b


def unpair(n):
    diagonal = (isqrt(8 * n + 1) - 1) // 2
    b = n - diagonal * (diagonal + 1) // 2
    return diagonal - b, b


def I(a, b):
    return 4 * P(a, b)


class Halt(Exception):
    pass


def mp(st, payload):
    t, w, d, h = st
    target = d + payload
    return ((target, P(0, w), target, 0) if h == I(t, target)
            else (0, w, target, 0))


def old_drop(st):
    t, w, d, h = st
    return h, P(t, w), d, h


def old_nip(st):
    t, w, d, h = st
    if h == 1:
        raise Halt
    x, v = unpair(w)
    return t, v, d, x


def composite_shift(st):
    return old_nip(old_nip(old_drop(st)))


def direct_shift(st):
    t, w, d, h = st
    if h == 1:
        raise Halt
    x, v = unpair(w)
    return h, v, d, x


def decode_word(n):
    answer = []
    while True:
        tag, rest = unpair(n)
        if tag == 0:
            payload, rest = unpair(rest)
            answer.append(["MP", payload])
        elif tag == 1:
            answer.append(["S"])
        else:
            y, rest = unpair(rest)
            x, rest = unpair(rest)
            answer.append(["AX", tag - 2, x, y])
        if not rest:
            return answer
        n = rest - 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    expected = [
        [["MP", 0]], [["S"]], [["MP", 1]], [["AX", 0, 0, 0]],
        [["S"], ["MP", 0]], [["MP", 0], ["MP", 0]],
    ]
    assert [decode_word(n) for n in range(6)] == expected
    checks = rejected = sanitized = 0
    counter_zero_checks = 0
    for top in range(8):
        for counter in range(6):
            # Include both exact equality triggers even when beyond the
            # small interval, so all branch patterns are deliberately tested.
            caches = sorted(set(range(64)) | {I(top, counter), I(top, 1)})
            for cache in caches:
                for stack in range(32):
                    checks += 1
                    initial = top, stack, counter, cache
                    bad = counter == 1 and cache == I(top, 1)
                    after_mp0 = mp(initial, 0)
                    try:
                        after_s = composite_shift(after_mp0)
                    except Halt:
                        assert bad, initial
                        rejected += 1
                        continue
                    assert not bad
                    assert after_s[0] == 0 and after_s[2] == counter
                    after_mp1 = mp(after_s, 1)
                    z, residual_stack, new_counter, new_cache = after_mp1
                    assert z in (0, counter + 1)
                    assert new_counter == counter + 1 and new_cache == 0
                    # Exact input parameters to candidate3 AX(0;0,0).
                    U = A = new_counter
                    B = new_cache
                    C = 0
                    assert U <= A and B == C == 0
                    # The saved possibly-junk top is deliberately assigned
                    # to the arbitrary suffix, not the nine safe heads.
                    arbitrary_suffix = P(z, residual_stack)
                    assert unpair(arbitrary_suffix) == (z, residual_stack)
                    sanitized += 1
                    if counter == 0:
                        counter_zero_checks += 1

    # The direct h-only command cannot hit the exceptional test, for any
    # initial data, because its incoming cache has just been reset by MP.
    direct_checks = 0
    for top in range(8):
        for counter in range(6):
            for cache in sorted(set(range(64)) | {I(top, counter), I(top, 1)}):
                for stack in range(32):
                    initial = top, stack, counter, cache
                    after_s = direct_shift(mp(initial, 0))
                    assert after_s[0] == 0 and after_s[2] == counter
                    z, v, d, h = mp(after_s, 1)
                    assert z in (0, counter + 1) and d == counter + 1 and h == 0
                    direct_checks += 1

    for stack in list(range(1000)) + [10**30, P(1, P(8, 4))]:
        initial = 0, stack, 0, 0
        after_two = composite_shift(mp(initial, 0))
        assert after_two == initial
        assert mp(after_two, 1) == (0, stack, 1, 0)
    assert rejected == 8 * 32
    assert sanitized + rejected == checks
    assert counter_zero_checks > 0
    report = {
        "status": "MP_FIRST_SANITIZER_FINITE_PASS",
        "composite_raw_tuples": checks,
        "exact_exceptional_early_halts": rejected,
        "sanitized_good_tuples": sanitized,
        "counter_zero_arbitrary_top_cache_stack_checks": counter_zero_checks,
        "direct_h_only_raw_tuples": direct_checks,
        "clean_zero_counter_stack_cancellation_checks": 1002,
        "first_six_decoded_words": expected,
        "post_AX_theorem_heads": 9,
        "next_candidate": 4,
        "credit_at_cutoff_4_from_written_theorem": 1,
        "permanent_margin": 8,
        "scope": "Finite exact raw arithmetic checks of the prologue and exceptional "
                 "condition. AX axiom validity, infinite prefix credit, source macros, "
                 "and consistency calibration are proved or inherited separately.",
    }
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
