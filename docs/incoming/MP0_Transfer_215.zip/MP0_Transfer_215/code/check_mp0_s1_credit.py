#!/usr/bin/env python3
"""Finite independent corroboration of mp0_s1_credit_proof.md.

No binary machine, native proof calculus, or inherited program is executed.
The infinite statement is established by the written induction. This script
checks exact finite recurrences, explicit words and complete diagonals.
"""
from __future__ import annotations
from functools import lru_cache
from math import isqrt
from pathlib import Path
import argparse
import json


def P(a, b):
    return (a + b) * (a + b + 1) // 2 + b


def unpair(n):
    s = (isqrt(8 * n + 1) - 1) // 2
    b = n - s * (s + 1) // 2
    return s - b, b


def f(n):
    return unpair(n)[1]


def triangular(s):
    return s * (s + 1) // 2


@lru_cache(None)
def word(n):
    # Literal one-command field parsing, independent of the tabulated
    # balance recurrence below.
    a, tail = unpair(n)
    if a == 0:
        payload, tail = unpair(tail)
        command = "MP"
    elif a == 1:
        command = "S"
    else:
        payload_y, tail = unpair(tail)
        payload_x, tail = unpair(tail)
        command = "AX"
    return (command,) + (word(tail - 1) if tail else ())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", type=int, default=500000)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    count = args.candidates
    assert count >= 1000
    balances, minima, lengths = [], [], []
    B = [0]
    global_minimum = 0
    for n in range(count):
        a, y = unpair(n)
        assert P(a, y) == n and 0 <= f(n) <= n
        if a == 0:
            delta, residual = 0, f(y)
        elif a == 1:
            delta, residual = -1, y
        else:
            delta, residual = 10, f(f(y))
        assert 0 <= residual <= n
        tail_balance = balances[residual - 1] if residual else 0
        tail_minimum = minima[residual - 1] if residual else 0
        tail_length = lengths[residual - 1] if residual else 0
        balances.append(delta + tail_balance)
        minima.append(min(0, delta + tail_minimum))
        lengths.append(1 + tail_length)
        assert lengths[-1] <= n + 1
        global_minimum = min(global_minimum, B[-1] + minima[-1])
        B.append(B[-1] + balances[-1])
        assert B[-1] + len(balances) >= 0
    assert global_minimum == -1
    assert [word(i) for i in range(3)] == [("MP",), ("S",), ("MP",)]
    assert B[:4] == [0, 0, -1, -1]

    delta = {"S": -1, "MP": 0, "AX": 10}
    for n in range(1000):
        partial, minimum = 0, 0
        explicit = word(n)
        for command in explicit:
            partial += delta[command]
            minimum = min(minimum, partial)
        assert (partial, minimum, len(explicit)) == (
            balances[n], minima[n], lengths[n])

    complete_diagonals = 0
    min_diagonal_balance = None
    for s in range(2, count):
        start, end = triangular(s), triangular(s + 1)
        if end > count:
            break
        total = 0
        for n in range(start, end):
            assert total + minima[n] >= 0
            total += balances[n]
        assert total >= 7 * s - 9 > 0
        assert B[start] >= -1
        complete_diagonals += 1
        min_diagonal_balance = total if min_diagonal_balance is None else min(
            min_diagonal_balance, total)

    def finite_credit(N):
        s = (isqrt(8 * N + 1) - 1) // 2
        end = max(3, triangular(s + 1))
        assert end <= count
        total = minimum = 0
        for n in range(N, end):
            minimum = min(minimum, total + minima[n])
            total += balances[n]
        return -minimum

    credits = [finite_credit(n) for n in range(30)]
    assert credits[0] == credits[1] == 1
    for s in range(2, 45):
        assert finite_credit(triangular(s)) == 0

    # The first successful padding command retains tag2 under permutation.
    def fold(fields, rest):
        for field in reversed(fields):
            rest = P(field, rest)
        return rest

    def command_fields(command):
        if command[0] == "MP":
            return [0, command[1]]
        if command[0] == "S":
            return [1]
        _, c, x, y = command
        return [c + 2, y, x]

    def decode_first(n):
        selector, rest = unpair(n)
        if selector == 0:
            x, rest = unpair(rest)
            return ("MP", x), rest
        if selector == 1:
            return ("S",), rest
        y, rest = unpair(rest)
        x, rest = unpair(rest)
        return ("AX", selector - 2, x, y), rest

    command_words = [
        [("MP", 0)], [("S",)], [("MP", 0), ("S",)],
        [("S",), ("MP", 0)], [("S",), ("S",), ("S",)],
        [("MP", 1), ("MP", 0)], [("AX", 0, 0, 0)],
        [("AX", 0, 1, 2), ("S",)],
        [("MP", 2), ("AX", 1, 0, 1)],
        [("AX", 1, 1, 0), ("MP", 0), ("S",)],
    ]
    for commands in command_words:
        continuation = 0
        for command in reversed(commands):
            continuation = 1 + fold(command_fields(command), continuation)
        for command in commands:
            previous = continuation
            decoded, continuation = decode_first(continuation - 1)
            assert decoded == command and continuation < previous
        assert continuation == 0

    for Y in range(1000):
        remainder = 7
        encoded = P(2, P(Y, P(1, remainder)))
        selector, rest = unpair(encoded)
        field_y, rest = unpair(rest)
        field_x, rest = unpair(rest)
        assert (selector, field_x, field_y, rest) == (2, 1, Y, remainder)
        assert encoded >= Y
        assert encoded == fold([2, Y, 1], remainder)

    report = {
        "status": "MP0_S1_CREDIT_FINITE_PASS",
        "candidate_count": count,
        "explicit_word_checks": 1000,
        "complete_diagonals_s_ge_2": complete_diagonals,
        "global_minimum_command_prefix_balance": global_minimum,
        "minimum_completed_diagonal_balance": min_diagonal_balance,
        "credit_at_cutoff_1": credits[1],
        "initial_theorem_heads": 10,
        "permanent_conservative_margin": 10 - credits[1],
        "credits_for_cutoffs_0_to_29": credits,
        "first_three_words": [list(word(i)) for i in range(3)],
        "first_four_cumulative_balances": B[:4],
        "padding_checks": 1000,
        "exact_field_roundtrip_words": len(command_words),
        "scope": "Finite corroboration only. The accompanying written diagonal "
                 "induction proves the infinite credit theorem for all natural candidates.",
    }
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
