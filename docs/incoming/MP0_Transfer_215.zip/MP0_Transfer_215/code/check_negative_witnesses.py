#!/usr/bin/env python3
"""Replay two rejected allocations to complete clean-frame counterexamples."""
from pathlib import Path
import json,sys,hashlib
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT));import verify as V
import independent_runtime as I

def check():
 P=I.table(ROOT/'inputs/parent-transfer215.native.tm');records=[]
 # MP-success push omission corrupts a shared AX role.
 T=dict(P);assert T[164,1]==(1,1,98);T[164,1]=(1,1,114)
 rec=V.read(ROOT/'research/omit_alias_counterexample.json')
 assert hashlib.sha256(V.encode(T)).hexdigest()==rec['table_sha256']
 m,L=V.mapping(T);_,LP=V.mapping(P)
 actual,steps,trace=I.run(L,rec['site'][0],rec['registers'],rec['spares'],rec['gap'],trace=True)
 expected=I.expected(rec['site'],rec['registers'],rec['spares'],rec['gap'])
 baseline,bsteps,_=I.run(LP,rec['site'][0],rec['registers'],rec['spares'],rec['gap'])
 assert steps==566 and bsteps==556 and baseline==expected[0]and actual!=expected[0]
 assert I.clean_dispatch(*actual)and I.describe(actual)==rec['actual']and I.describe(expected[0])==rec['expected']
 records.append({'name':'omit_success_push_alias','status':'REFUTED','steps':steps,'baseline_steps':bsteps,'first_endpoint_is_clean_frame':True,'trace':trace})
 # Decoder310 / engine26 collision. The record uses native labels.
 U=dict(P);U[26,0]=(0,1,311)
 for key,(w,d,z)in list(U.items()):
  if key[0]==310:del U[key]
  elif z==310:U[key]=(w,d,26)
 assert len(U)==428
 rec=V.read(ROOT/'research/merge310-counterexample.json');m,LU=V.mapping(U)
 actual,steps,trace=I.run(LU,rec['site'][0],rec['regs'],[0],0,trace=True)
 expected=I.expected(rec['site'],rec['regs'],[0],0)[0]
 assert steps==608 and actual!=expected and I.clean_dispatch(*actual)
 inv={v:k for k,v in m.items()}
 native_trace=[[inv[q],h,b,w,d,inv[z]]for tick,q,h,b,w,d,z in trace]
 assert native_trace==rec['trace']
 assert sorted(actual[2])==rec['actual_ones']and sorted(expected[2])==rec['expected_ones']
 records.append({'name':'merge310_into26','status':'REFUTED','steps':steps,'first_endpoint_is_clean_frame':True,'trace':native_trace})
 return {'status':'BOTH_NEGATIVE_WITNESSES_REPLAYED','records':records}
if __name__=='__main__':
 r=check()
 if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({**r,'records':[{k:v for k,v in x.items()if k!='trace'}for x in r['records']]},indent=2))
