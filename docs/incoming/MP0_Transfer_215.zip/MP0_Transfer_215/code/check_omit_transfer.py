#!/usr/bin/env python3
"""Corroborate the omitted-push transfer compiler's algebraic identities.

Owned standalone checker. This is NOT a binary runtime, proof-calculus
verification, or unbounded proof-assistant certificate. Formal AX rows are
opaque tag-0 theorem tokens. DERIVE nodes explicitly stand for induction
hypotheses. Unknown guards are handled on the no-early-halt branch; any
valuation violating a recorded guard has a permitted early halt instead.

The written proof establishes the all-natural theorem. These finite symbolic
instances make its composition and zero-alias bookkeeping independently
reviewable, including original stack 0 and the unsafe numerical tail 4.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from math import isqrt
import argparse
import json

TEST_TOP_GUARD = True
PUSH_ON_SUCCESS = False


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple


@dataclass(frozen=True)
class Cons:
    head: object
    tail: object


def variable(name):
    return Term("var", (name,))


def pair(a, b):
    return (a + b) * (a + b + 1) // 2 + b


def unpair(n):
    s = (isqrt(8 * n + 1) - 1) // 2
    b = n - s * (s + 1) // 2
    return s - b, b


def implication(a, b):
    if isinstance(a, int) and isinstance(b, int):
        return 4 * pair(a, b)
    return Term("I", (a, b))


def quantifier(a, b):
    if isinstance(a, int) and isinstance(b, int):
        return 4 * pair(a, b) + 2
    return Term("Q", (a, b))


def add(a, b):
    if a == 0:
        return b
    if b == 0:
        return a
    if isinstance(a, int) and isinstance(b, int):
        return a + b
    return Term("add", (a, b))


def push(x, w):
    # Preserve the raw pairing alias explicitly rather than assuming an
    # injective disjoint nil/cons representation.
    return 0 if x == 0 and w == 0 else Cons(x, w)


def pop(w):
    if isinstance(w, Cons):
        return w.head, w.tail
    if isinstance(w, int):
        return unpair(w)
    raise AssertionError(("A claimed strong block inspected its opaque tail", w))


def tag(x):
    if isinstance(x, int):
        return x % 4
    if isinstance(x, Term):
        if x.op in ("I", "row", "gate"):
            return 0
        if x.op == "Q":
            return 2
    return None


def nonzero(x):
    if isinstance(x, int):
        return x > 0
    if isinstance(x, Term) and x.op == "Q":
        return True
    if isinstance(x, Term) and x.op == "I":
        return any(nonzero(a) for a in x.args)
    return False


class EarlyHalt(Exception):
    pass


def axiom(st, c, x, y):
    t, w, d, h = st
    a, b = add(d, x), add(h, y)
    gate = 0 if c == a or c == b else Term("gate", (a, b, c))
    rows = [Term("row", (j, a, b, c)) for j in range(1, 8)]
    rows += [Term("row", (8, a, b, c, d)), quantifier(d, h), t]
    for row in reversed(rows):
        w = push(row, w)
    return gate, w, 0, 0


def shift(st, guards):
    t, w, d, h = st
    for value in ((h, t) if TEST_TOP_GUARD else (h,)):
        if value == 1:
            raise EarlyHalt
        if tag(value) is None:
            guards.add(repr(value) + " != 1")
    x, v = pop(w)
    return h, v, d, x


def detach(st, x):
    t, w, d, h = st
    y = add(d, x)
    target = implication(t, y)
    if target == h:
        return y, push(0, w) if PUSH_ON_SUCCESS else w, y, 0
    assert ((h == 0 and nonzero(target)) or
            (tag(target) is not None and tag(h) is not None and
             tag(target) != tag(h))), ("Undecided detachment comparison", target, h)
    return 0, w, y, 0


S = ("S",)


def M(x):
    return "M", x


def AX(c=0, x=0, y=0):
    return "AX", c, x, y


def IH(x):
    return "IH", x


H = [AX()] + [S] * 11
PUSH = [AX()] + [S] * 9 + [M(0)]
DISCARD = [M(1), AX(1)] + [S] * 10 + [M(0)]


def J(u):
    return [] if u == 0 else [M(u)]


def execute(st, word):
    guards = set()
    for count, command in enumerate(word, 1):
        try:
            if command[0] == "S":
                st = shift(st, guards)
            elif command[0] == "M":
                st = detach(st, command[1])
            elif command[0] == "AX":
                st = axiom(st, *command[1:])
            else:
                assert command[0] == "IH" and st[2:] == (0, 0)
                # This is an explicitly labelled induction-hypothesis
                # oracle, never a claim of executing an arbitrary proof.
                st = command[1], st[1], 0, 0
        except EarlyHalt:
            return "PERMITTED_EARLY_HALT", None, count, guards
    return "EXACT_RETURN", st, len(word), guards


def main():
    global TEST_TOP_GUARD, PUSH_ON_SUCCESS
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--guard", choices=("both", "cache-only"), default="both")
    parser.add_argument("--success-push", choices=("omitted", "present"), default="omitted")
    args = parser.parse_args()
    TEST_TOP_GUARD = args.guard == "both"
    PUSH_ON_SUCCESS = args.success_push == "present"
    records = []

    def check(name, st, word, wanted, must_return=False):
        status, result, commands, guards = execute(st, word)
        assert status != "EXACT_RETURN" or result == wanted, (name, result, wanted)
        assert not must_return or status == "EXACT_RETURN", name
        records.append({"name": name, "status": status, "commands": commands,
                        "no_early_halt_guards": sorted(guards)})

    t = variable("arbitrary top")
    d = variable("arbitrary counter")
    h = variable("arbitrary cache")
    x = variable("arbitrary protected head")
    tails = [variable("arbitrary stack tail"), 0, 4]
    for w in tails:
        label = repr(w)
        check("H arbitrary / " + label, (t, push(x, w), d, h), H,
              (t, w, 0, x))
        check("H top1 / " + label, (1, push(x, w), d, h), H, None)
        for top, cache in [(t, h), (1, h), (t, 1), (0, 0)]:
            check("PUSH / " + repr((top, cache, w)), (top, w, d, cache), PUSH,
                  (0, push(top, w), 0, 0), must_return=True)
        check("DISCARD / " + label, (t, w, 0, 0), DISCARD,
              (0, w, 0, 0), must_return=True)
        for a, b, c in [(0, 0, 0), (0, 1, 0), (2, 3, 4)]:
            for j in range(1, 8):
                word = DISCARD + [AX(c, a, b)] + [S] * (j + 1) + H * (9 - j)
                check("row / " + repr((j, a, b, c, w)), (t, w, 0, 0), word,
                      (Term("row", (j, a, b, c)), w, 0, 0), must_return=True)
        for a, b, c, u in [(0, 0, 0, 0), (2, 1, 0, 0), (2, 1, 3, 1), (2, 3, 4, 2)]:
            word = DISCARD + J(u) + [AX(c, a - u, b)] + [S] * 9 + H
            check("dominated / " + repr((a, b, c, u, w)), (t, w, 0, 0), word,
                  (Term("row", (8, a, b, c, u)), w, 0, 0), must_return=True)
        for a, b, c in [(2, 3, 4), (0, 0, 1)]:
            check("bundle / " + repr((a, b, c, w)), (t, w, 0, 0),
                  DISCARD + [AX(c, a, b)] + H * 10,
                  (Term("gate", (a, b, c)), w, 0, 0), must_return=True)
        for i in [0, 1, 3]:
            for theorem in [0, 1, implication(variable("p"), variable("q")),
                            quantifier(0, variable("p"))]:
                word = [IH(theorem)] + PUSH + J(i) + [S, AX(i)] + [S] * 10
                check("GEN / " + repr((i, theorem, w)), (t, w, 0, 0), word,
                      (quantifier(i, theorem), w, 0, 0), must_return=True)
        for minor, conclusion in [(0, 0), (0, 1), (1, 0), (1, 1),
                                  (variable("A"), variable("B")),
                                  (quantifier(0, variable("x")),
                                   implication(variable("p"), variable("q")))]:
            major = implication(minor, conclusion)
            seed = [] if PUSH_ON_SUCCESS else DISCARD + PUSH
            word = (seed + [IH(major)] + PUSH + [IH(minor)] + PUSH
                    + [S, S, M(conclusion), AX(conclusion)] + [S] * 11)
            check("new MP compiler / " + repr((minor, conclusion, w)),
                  (t, w, 0, 0), word, (conclusion, w, 0, 0))

    # Exact native zero-alias and unsafe-stack arithmetic, independently of
    # symbolic opaque AX formula tokens.
    assert implication(0, 0) == 0
    assert pair(0, 0) == 0 and unpair(0) == (0, 0)
    assert unpair(4) == (1, 1) and unpair(1) == (1, 0)
    assert detach((0, 4, 0, 0), 0) == (0, push(0, 4) if PUSH_ON_SUCCESS else 4, 0, 0)
    assert detach((0, 0, 0, 0), 0) == (0, 0, 0, 0)
    report = {
        "status": "OMIT_TRANSFER_COMPILER_ALGEBRA_PASS",
        "guard": args.guard,
        "success_push": args.success_push,
        "cases": len(records),
        "commands": sum(record["commands"] for record in records),
        "by_status": {key: sum(record["status"] == key for record in records)
                      for key in ("EXACT_RETURN", "PERMITTED_EARLY_HALT")},
        "scope": "Finite symbolic command identities with labelled induction-hypothesis "
                 "oracles and exact zero-alias checks; not a binary runtime or native "
                 "calculus verification. The accompanying written proof is all-natural.",
        "records": records,
    }
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
