# MP0-transfer215: modus ponens first

**Result:** a new, exactly specified 215-working-state binary blank-start consistency machine, with a new theorem allowing arbitrary initial numerical data. **No valid 214-state machine was obtained.**

Read `report.pdf` (15 pages), or compile `report.tex` with pdfLaTeX. The accepted tables are only the files in `machine/`. The second physical machine under `research/rotate-pop215/` has an open logical completeness obligation and must not be promoted as a calibrated consistency machine.

## Mathematical statement and inherited boundary

For `machine/mp0-transfer215.native.tm`, the ordinary proof establishes, using the pinned inherited native-calculus calibration,

    ZFC proves: Halt(M, blank) <=> there exists a finite ZFC refutation.

Thus ZFC proves `Nonhalt(M, blank) <=> Con(ZFC)`. The proof uses the inherited numerical calculus and arithmetic macro contracts, the complete transfer compiler, the new source bridge, a new enumeration-credit theorem, exact blank initialization, and all-natural symbolic primitive simulation. This is not an unconditional nonhalting proof, a state lower bound, or a newly compiled Lean/Rocq theorem.

The main new theorem concerns a complete represented source root, with next-candidate counter N=0, empty continuation pointer, and zero arithmetic scratches. For arbitrary raw top t, stack w, additive counter d and cache h,

    Halt(E; 0,t,w,d,h) <=> (d=1 and h=I(t,1)) or not Con(ZFC),
    where I(a,b)=4*((a+b)*(a+b+1)/2+b).

In particular, **any d other than 1 permits arbitrary raw t,w,h**. The useful initializer case d=0 requires no theoremhood or formula-decoding assumptions on those data. The first four candidates are MP(0), S, MP(1), AX(0;0,0). Outside the exact exceptional branch, they bury every suspect value below nine genuine theorem heads. The new diagonal induction proves permanent safety with required credit one.

This additional N=0 theorem does not describe the accepted table's actual blank trajectory. That trajectory reaches a separately matched partial AX at N=1; completing it gives ten theorem heads over arbitrary suffix 4, and the new exact credit d(1)=1 suffices.

## What changed

The immediate parent is the transfer215 table in the already committed incoming archive `Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21.zip`, at ProveIt commit:

    b74074eacb936164d85e0f1aea5a8254412ade48

The parent used S=0, MP=1, AX=c+2. This machine uses:

| Command | Fields |
|---|---|
| MP(x) | [0,x] |
| S | [1] |
| AX(c;x,y) | [c+2,y,x] |

The native construction changes exactly two rows:

| State/read | Parent | Candidate |
|---|---|---|
| 201/1 | 1 R 100 | 1 R 310 |
| 312/1 | 1 R 310 | 1 R 100 |

The source construction exchanges the complete subtrees at `110101` and `111`. MP and S are closed; AX has one external exit to the checked command-exit CB(1).

Compared with the immediate parent, this is an opcode permutation with a new numerical enumeration and a stronger proved initialization interface. The three-command architecture, numerical calculus, 201-node source count and original transfer compiler were already present. They are not claimed as new. Rooted transition-graph checks reject mere state renaming against the parent and twelve selected earlier tables; these checks are not an exhaustive novelty claim.

## Exact artifacts and verification

| Quantity | Value |
|---|---:|
| Working states | 215 |
| Binary transition rows | 430 |
| Source distinct subtrees | 201 |
| Source primitive occurrences | 4,775 |
| Quantified guarded primitive cases | 6,209 |
| Symbolic rules | 1,610,781 |
| Covered transition rows | 430 |
| Minimum affine duration constant | 10 |
| Blank steps to exact partial AX frame | 68,442 |
| Source steps matching AX prefix | 174 |
| Heads after completed AX / required credit | 10 / 1 |

Native labels: start 0, dispatcher 84, halt 254. Dense labels: working states 0..214, halt 215; see `machine/canonicalization.json` for the exact bijection. Halt is not counted as a working state.

Native table SHA-256:

    1534c93612398b0e2cd3d5699649ae786b02d75a264a80f9ae70fffff16965d6

Dense table SHA-256:

    59cfa5969b098adb68ea8bf6fe67aaa7a0f1d61e3c3adef30b72cf24021281c3

Source SHA-256:

    8ddb942f0f1d8e2e3b12ab7217c7232eb553cd288fca38dbf9b0eded73893dd5

The runtime domain includes arbitrary natural primary registers under each guard, arbitrary natural gap, an arbitrary nonempty finite list of natural spare values, and the complete zero exterior. The symbolic checker derives unary/list induction blocks; this is stronger than finite testing and remains outside a proof-assistant kernel.

The actual blank frame is dispatcher 84, head -2, PC `110100100101010`, source ordinal 55, gap 0, logical registers `[1,11,2,0,0,0,0,0,0]`, 59 unit spares, and exactly 150 one cells. The complete support appears in `evidence/startup.json`. Three tape presentations agree at every startup step.

## Reproduce offline

Python 3.10+ and its standard library suffice. Leave assertions enabled.

```sh
python3 verify.py
python3 verify.py --runtime
```

The default validates all pinned files, exact source/table construction, two source graph resolvers, state census, dense renaming, complete blank startup, AX prefix, the inherited 3,728-node dominated-row certificate, finite credit and raw-seed corroborations, and graph distinctions. The full option additionally rederives all 6,209 quantified runtime cases and compares the ordered compressed certificate exactly. It took about two minutes in the reference environment. `--work /absolute/path` chooses a receipt directory.

Additional replay commands are `python3 code/check_negative_witnesses.py` for the two concrete rejected allocations and `python3 research/rotate-pop215/verify.py --runtime` for the experimental physical machine (whose logical compiler remains open).

The finite corroborations do not substitute for the written infinite proofs. Their counts are 500,000 candidate recurrences for the credit check and 99,968 raw tuples for the initial prologue check, including exactly 256 deliberately exercised exceptional early halts.

Build the PDF:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The source uses standard TeX Live packages. The delivered PDF was rendered and visually reviewed on every page; the final compilation had no overfull boxes or unresolved references.

## Contents

- `report.tex`, `report.pdf`: full argument, actual table construction, proof boundaries, research outcomes, and alternative formalisms.
- `machine/`, `source/`: accepted candidate only.
- `verify.py`, `code/`: offline exact replay and inherited verified arithmetic/symbolic helpers, retaining attribution.
- `inputs/`: inert pinned parent, comparison tables, native/legacy mapping and dominated-calculus proof certificate.
- `evidence/`: exact startup support, ordered runtime cases, proof-check receipts and full replay receipt.
- `proofs/`: full new diagonal and raw-seed proofs, inherited compiler, and source-level alternative compiler proofs.
- `research/`: rejected allocations, restricted search results and clearly experimental rotating-pop machine.
- `provenance/`, `licenses/`: inherited source calibration, source identities, notices and reuse terms.

The report also examines finite GBC/NBG, a finite Kleene–Craig–Vaught conservative extension, ZF/constructibility, and an explicit equality-free universal Horn safety theory. Their consistency calibrations and implementation tradeoffs are stated separately; no unmeasured machine-size savings are claimed.

## Experimental work and failures

The direct h-only transfer has an exact 35-primitive source implementation and a compiler that removes even the exceptional raw-input relation. Its attempted 215-state reuse of contextual state 122 is invalid. The no-successful-MP-push compiler is also proved, but the naive state-164 redirect corrupts an AX role; an exact 566-step complete-frame counterexample is retained. Neither table is an accepted candidate.

The rotating-pop machine changes the transfer equation itself and passes 6,209 arbitrary-natural runtime cases, with 1,611,528 rules and the same finite blank frame. Its AX-row extraction and stack-cleanup proof is unresolved. Read its explicit open-status README before using it.

The 214-state repair searches are bounded and family-specific. Their finite screens and outward-ray witnesses do not establish a lower bound. The report identifies what was checked and what remains open.

## Integration and attribution

A suitable destination is a new alternative/research directory or incoming archive. No existing primary file should be silently replaced. `MANIFEST.json` and `SHA256SUMS` identify the delivered contents.

The retained numerical calculus, full seed bundle, ZFC comparison, dominated-row certificate, transfer compiler, source-language utilities, physical representation and symbolic induction engine are inherited from ProveIt and its cited predecessors, including Andrew James Wade. New work here consists of the MP-first enumeration and its exact runtime verification, new credit and raw-data initialization proofs, compiler variants and failed-allocation analysis, and reproducible integration glue. New material is supplied under the same MIT No Attribution terms as the included ProveIt notice; inherited third-party terms remain unchanged.
