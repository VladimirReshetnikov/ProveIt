# Research annex status

The only calibrated machine released by this packet is `../machine/mp0-transfer215.native.tm` and its dense equivalent.

- `rotate-pop215/`: a different command equation; source-to-binary runtime and blank prefix pass, but a complete logical compiler is missing. No ZFC equivalence is asserted.
- `omit_alias_counterexample.json`: rejects the naive successful-MP-push deletion via shared state 164; the actual endpoint is a complete clean frame at step 566, not merely a visit to dispatcher 84.
- `merge310-counterexample.json`: rejects a 214-state decoder/engine merge at a complete frame after 608 steps. The intermediate dispatcher visit at step 154 is not a valid proof endpoint.
- `source_search_summary.json`: bounded source reassociation searches, not a lower bound.
- `machine_research_review.md`: independent credit/raw-seed review and scope of low-level negative results.
- `rotate_pop_compiler_open.md`: known structural macros and the exact unproved cleanup obligation.

The direct-transfer and omitted-push proof notes under `../proofs/` concern their explicitly stated source-level languages. Some of those notes describe the parent S=0/MP=1 scheduling context with credit two; the accepted MP=0/S=1 enumeration instead uses the new credit theorem in `mp0_s1_credit_proof.md`. Do not transfer a runtime certificate or a credit bound between those languages without the corresponding proof.
