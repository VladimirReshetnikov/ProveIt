#!/usr/bin/env python3
"""Generate the finite primitive screen used by repair214.cpp.

This generator is standalone. Its frame/primitive equations are equivalent
to the pinned runtime helper's frame/expected functions. Finite regression
does not replace the all-natural symbolic runtime theorem.
"""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
PHY = (6, 2, 0, 4, 3, 7, 8, 5, 1)


def frame(pc, registers, spares, gap=0):
    physical = [0] * 9
    for logical, position in enumerate(PHY):
        physical[position] = registers[logical]
    ones = {-1, 64 + gap}
    ones.update(i for i, bit in enumerate(pc) if bit == "1")
    position = 65 + gap
    for value in physical + list(spares):
        position += 1
        ones.update(range(position, position + value + 1))
        position += value + 1
    return ones


def increment(pc):
    width = len(pc)
    value = (int(pc, 2) if pc else 0) + 1
    return (format(value % (2 ** width), "0" + str(width) + "b")
            if width else ""), int(value == 2 ** width)


def strip(pc, bit, count):
    if count == 0:
        return pc
    for i in range(len(pc) - 1, -1, -1):
        if pc[i] == bit:
            count -= 1
            if count == 0:
                return pc[:i]
    return ""


def expected(site, registers, spares):
    pc, op, register = site
    registers = list(registers)
    spares = list(spares)
    gap = shift = 0
    if op == "CH":
        return 254, 0, set()
    if op == "CI":
        registers[register] += 1
        spares.append(1)
        nxt, shift = increment(pc)
    elif op == "CD" and registers[register] > 0:
        registers[register] -= 1
        gap = 1
        nxt, shift = increment(pc)
    elif op in ("CD", "CB"):
        nxt, shift = increment(strip(pc, "0", register if op == "CB" else 1))
    elif op == "CC":
        nxt = strip(pc, "1", register)
    else:
        raise ValueError(site)
    ones = frame(nxt, registers, spares, gap + shift)
    return 84, -shift, {position - shift for position in ones}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sites", type=Path,
                        default=HERE / "inputs" / "baseline215.sites.json")
    parser.add_argument("--output", type=Path,
                        default=HERE / "reproduced" / "cases.tsv")
    args = parser.parse_args()
    sites = json.loads(args.sites.read_text())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with args.output.open("w") as out:
        for i, site in enumerate(sites):
            for positive in ((False, True) if site[1] == "CD" else (False,)):
                registers = [0] * 9
                if positive:
                    registers[site[2]] = 1
                initial = frame(site[0], registers, [0])
                state, head, want = expected(site, registers, [0])
                print(i, int(positive), state, head,
                      ",".join(map(str, sorted(initial))),
                      ",".join(map(str, sorted(want))) or "-",
                      file=out, sep="\t")
                count += 1
    print(json.dumps({
        "cases": count,
        "source_sha256": hashlib.sha256(args.sites.read_bytes()).hexdigest(),
        "cases_sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
        "output": str(args.output),
    }, indent=2))


if __name__ == "__main__":
    main()
