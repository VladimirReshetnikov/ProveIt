#include <array>
#include <vector>
#include <set>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <string>
#include <chrono>
using namespace std;
constexpr int NS=1024, SZ=2048, OFF=512;
struct Row{int w=-1,d=0,z=-1; bool operator==(const Row&o)const{return w==o.w&&d==o.d&&z==o.z;}};
using Table=array<Row,NS>;
struct Case{int site,pos,q,h;array<unsigned char,SZ> ini{},want{};};
bool clean(int q,int h,const array<unsigned char,SZ>&tape){
 if(q!=84||h<1||h+64>=SZ||!tape[h-1])return false;
 for(int p=0;p<h-1;p++)if(tape[p])return false;
 int first=h+52;while(first<SZ&&!tape[first])first++;
 if(first<h+64||first>=SZ)return false;
 int last=SZ-1;while(last>=0&&!tape[last])last--;
 int p=first+1,n=0;
 while(p<last){if(tape[p]||!tape[p+1])return false;p++;while(p<SZ&&tape[p])p++;n++;}
 return p==last+1&&n>=10;
}
void loadbits(array<unsigned char,SZ>&a,string s){replace(s.begin(),s.end(),',',' ');istringstream z(s);int x;while(z>>x)a[OFF+x]=1;}
bool run(const Table&T,const Case&c,set<int>*used=nullptr,int lim=5000){auto tape=c.ini;int q=84,h=OFF;
 for(int tick=0;tick<=lim;tick++){
  if(tick&&q==254)return c.q==254;
  if(tick&&clean(q,h,tape))return c.q==84&&h==OFF+c.h&&tape==c.want;
  if(h<1||h>=SZ-1||q<0||q>=NS/2)return false;
  int ix=2*q+tape[h];Row a=T[ix];if(a.w<0)return false;
  if(used)used->insert(ix);tape[h]=a.w;h+=a.d;q=a.z;
 }return false;
}
string startup(const Table&T,int &steps,int &q,int &head){array<unsigned char,SZ>tape{};q=0;int h=OFF;
 for(steps=0;steps<500000;steps++){
  if(h<1||h>=SZ-1){head=h-OFF;return"WINDOW";}
  if(q==84&&tape[h-1]){
   bool leftzero=true;for(int i=0;i<h-1;i++)if(tape[i]){leftzero=false;break;}
   if(leftzero){int p=h;while(p<SZ&&!tape[p])p++;if(p>=h+64&&p<SZ){int header=p++;vector<int>v;bool good=true;
    while(p<SZ){int last=SZ-1;while(last>=p&&!tape[last])last--;if(last<p)break;
     if(tape[p]||!tape[p+1]){good=false;break;}p++;int n=0;while(p<SZ&&tape[p]){p++;n++;}v.push_back(n-1);
    }if(good&&v.size()>=10&&v[0]==0&&v[2]==0&&v[7]==0){head=h-OFF;return"SEED";}
   }}
  }
  if(q==254){head=h-OFF;return"HALT";}
  if(q<0||q>=NS/2){head=h-OFF;return"UNKNOWN";}
  int bit=tape[h];Row a=T[2*q+bit];if(a.w<0){head=h-OFF;return"UNDEFINED";}
  if(bit==0&&a.z==q){bool ray=true;for(int p=h+a.d;p>0&&p<SZ-1;p+=a.d)if(tape[p]){ray=false;break;}
   if(ray){head=h-OFF;return"RAY";}}
  tape[h]=a.w;h+=a.d;q=a.z;
 }head=h-OFF;return"LIMIT";
}
int main(int argc,char**argv){
 if(argc<3||argc>4||(argc==4&&string(argv[3])!="--check-only")){cerr<<"usage: repair214 TABLE CASES [--check-only]"<<endl;return 64;}
 Table T;vector<int>states;{ifstream in(argv[1]);if(!in){cerr<<"cannot open table: "<<argv[1]<<endl;return 66;}string line;set<int>ss;while(getline(in,line)){if(line.empty()||line[0]=='#')continue;istringstream z(line);int q,b,w,n;char d;if(z>>q>>b>>w>>d>>n){T[2*q+b]={w,d=='R'?1:-1,n};ss.insert(q);}}states.assign(ss.begin(),ss.end());}
 vector<Case>cs;{ifstream in(argv[2]);if(!in){cerr<<"cannot open cases: "<<argv[2]<<endl;return 66;}string line;while(getline(in,line)){istringstream z(line);Case c;string a,b;z>>c.site>>c.pos>>c.q>>c.h>>a>>b;loadbits(c.ini,a);loadbits(c.want,b);cs.push_back(c);}}
 array<vector<int>,NS>users;for(int i=0;i<(int)cs.size();i++){set<int>used;if(!run(T,cs[i],&used)){cerr<<"BASELINE_FAIL "<<i<<endl;return 2;}for(int ix:used)users[ix].push_back(i);}
 cout<<"BASELINE_PASS "<<cs.size()<<endl;
 if(argc==4)return 0;
 set<int>bootrows;{array<unsigned char,SZ>t{};int q=0,h=OFF;for(int tick=0;tick<200;tick++){int ix=2*q+t[h];bootrows.insert(ix);Row a=T[ix];t[h]=a.w;h+=a.d;q=a.z;}}
 int attempts=0,survivors=0,seeds=0;auto began=chrono::steady_clock::now();
 for(int ix:bootrows){Row old=T[ix];int rowtries=0;
  for(int w=0;w<=1;w++)for(int d:{-1,1})for(int z:states){Row a{w,d,z};if(a==old)continue;attempts++;rowtries++;T[ix]=a;bool good=true;
   auto&v=users[ix];set<int>sample;if(!v.empty()){for(int k=0;k<12;k++)sample.insert(v[min((int)v.size()-1,k*((int)v.size()-1)/11)]);}
   for(int i:sample)if(!run(T,cs[i])){good=false;break;}
   if(good)for(int i:v)if(!sample.count(i)&&!run(T,cs[i])){good=false;break;}
   if(good){survivors++;int steps,q,h;string status=startup(T,steps,q,h);if(status=="SEED")seeds++;
    cout<<"SURVIVOR "<<ix/2<<' '<<ix%2<<" -> "<<w<<' '<<d<<' '<<z<<" START "<<status<<' '<<steps<<' '<<q<<' '<<h<<endl;
   }T[ix]=old;
  }
  cerr<<"ROW "<<ix/2<<' '<<ix%2<<" users "<<users[ix].size()<<" attempts "<<attempts<<" survivors "<<survivors<<endl;
 }
 cout<<"SUMMARY "<<attempts<<' '<<survivors<<' '<<seeds<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-began).count()<<endl;
}
