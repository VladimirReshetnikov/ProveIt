# Rotating-pop command: useful exact macros, unresolved completeness

Date: 2026-10-21. This is a research note, not a calibrated candidate claim.

Consider replacing the transfer command by

    R = oldNIP; oldDROP; oldNIP.

Writing `unpair(w)=(x,v)`, its command equation is

    R(t,w,d,h) = (x,v,d,t),

unless `h=1` or `x=1`, in which case it halts. The two cache tests are
exactly those in the two old NIP calls. Keep the existing MP and AX
equations from `transfer_compiler.md`.

## An all-natural PUSH macro

Let `D=AX(0;0,0)`. The following macro works for **every** natural incoming
`t,w,d,h`, with no assumption that the cache is zero or denotes a theorem:

    PUSH_R = D; R^9; MP(0).

The AX parameters are `U=A=d`, `B=h`, `C=0`. Its first nine entries are
seven retained implication axioms, the dominated implication axiom

    L = I(I(I(0,d),d), I(I(d,0),I(h,0))),

and `Q_d(h)`. None is 1. After nine R commands the state is

    (Q_d(h), [t;w], 0, L).

The last MP necessarily fails: its target is `I(Q_d(h),0)`, whose outer
antecedent has tag 2, whereas the outer antecedent of L has tag 0. Cantor
injectivity gives inequality, including the raw-zero alias. Thus the final
state is exactly

    (0,[t;w],0,0).

No step halts. This corrects the unnecessarily restrictive version of this
macro which assumed `d=h=0` or used a separately chosen large MP literal.

It follows that

    NORM_R = PUSH_R; R

halts exactly if the incoming top is 1, and otherwise returns

    (t,w,0,0).

It preserves the top and the entire original stack while resetting the
counter and cache. It does **not** remove an old stack head.

## A strong generalization construction, conditional on a strong premise

Suppose `B_X` already satisfies the strong contract

    (t,w,0,0) -> halt or (X,w,0,0).

Let `J(i)` be empty for `i=0`, and `MP(i)` for `i>0`, used only when top,
counter and cache are zero. Then the following block has the corresponding
strong contract for `Q_i(X)`:

    B_X; PUSH_R; J(i); R; R;
    AX(i;0,0); R^9; NORM_R.

After the first R, the state is `(X,w,i,0)`. Write `w=[x;v]`. The second R
either halts at a 1 head, which is allowed by the strong completeness
contract, or returns `(x,v,i,X)`. The AX gate is zero because `A=C=i`.
After nine further R calls the state is

    (Q_i(X),[x;v],0,L'),

which has exactly the original stack `w`. The final NORM resets the cache
without changing the top or stack, and `Q_i(X)` is not 1. This argument is
valid even when numerical zero-stack aliases occur.

## The unresolved point

These macros do not establish completeness. Selecting a retained AX row
with `R^j` leaves the later generated entries below that row. The known
normalizer preserves those entries; it does not delete them. In particular
`D;R^10` returns the original top and original stack with a new cache, so
it is not the top-preserving pop used by the transfer compiler.

With primitive MP, minor-first sequencing can arrange a desired major in
cache and its minor on top, but successful MP also pushes zero. Removing
that zero while preserving the conclusion is another instance of the same
missing operation. If the successful zero push were omitted, NORM would
repair the inference suffix, but selecting the AX rows would still leave
the original completeness gap.

The new normalizer and generalization block are therefore partial compiler
results only. No complete proof-tree compiler, alternative equiconsistency
argument, or obstruction theorem for this rotating-pop calculus has been
proved here. A physically validated 215-state implementation of R must not
be promoted to a ZFC-consistency candidate on the basis of these macros.
