#!/usr/bin/env python3
"""Reproduce the bounded two-row repair screen.

The input first-stage receipt is immutable; new outputs go to reproduced/.
Each subprocess repeats the concrete baseline check before mutation.
"""
from pathlib import Path
import argparse
import json
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
SURVIVOR = re.compile(r"SURVIVOR (\d+) (\d+) -> (\d+) (-?\d+) (\d+) START")


def read_table(path):
    table = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        q, bit, write, direction, target = line.split()
        key = int(q), int(bit)
        if key in table:
            raise ValueError(f"Duplicate transition: {key}")
        table[key] = int(write), direction, int(target)
    return table


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path,
                        default=HERE / "inputs" / "runtime-only214.native.tm")
    parser.add_argument("--first-results", type=Path,
                        default=HERE / "repair214-results.txt")
    parser.add_argument("--cases", type=Path,
                        default=HERE / "reproduced" / "cases.tsv")
    parser.add_argument("--executable", type=Path,
                        default=HERE / "reproduced" / "repair214")
    parser.add_argument("--output-dir", type=Path,
                        default=HERE / "reproduced" / "pairs")
    parser.add_argument("--summary", type=Path,
                        default=HERE / "reproduced" / "pair-repair-summary.json")
    args = parser.parse_args()
    for path in (args.baseline, args.first_results, args.cases, args.executable):
        if not path.is_file():
            parser.error(f"Required input is missing: {path}")
    table = read_table(args.baseline)
    firsts = []
    for line in args.first_results.read_text().splitlines():
        match = SURVIVOR.match(line)
        if match:
            firsts.append(tuple(map(int, match.groups())))
    if not firsts:
        parser.error("No first-stage SURVIVOR lines were found")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    results = []
    began = time.monotonic()
    for i, (q, bit, write, direction, target) in enumerate(firsts):
        altered = dict(table)
        altered[q, bit] = write, "R" if direction == 1 else "L", target
        table_path = args.output_dir / f"first{i:02}.tm"
        table_path.write_text("#! start 0\n" + "".join(
            f"{u} {v} {w} {d} {z}\n"
            for (u, v), (w, d, z) in sorted(altered.items())))
        log_path = args.output_dir / f"first{i:02}.out"
        error_path = args.output_dir / f"first{i:02}.err"
        with log_path.open("w") as log, error_path.open("w") as errors:
            result = subprocess.run(
                [str(args.executable.resolve()), str(table_path.resolve()),
                 str(args.cases.resolve())],
                stdout=log, stderr=errors)
        text = log_path.read_text()
        seeds = [line for line in text.splitlines() if "START SEED" in line]
        summaries = [line for line in text.splitlines()
                     if line.startswith("SUMMARY")]
        record = dict(index=i, first=[q, bit, write, direction, target],
                      returncode=result.returncode, seeds=seeds, summary=summaries)
        results.append(record)
        args.summary.write_text(json.dumps(results, indent=2) + "\n")
        print(json.dumps(record), flush=True)
        if result.returncode:
            raise SystemExit(f"Stage {i} failed; inspect {error_path}")
        if len(summaries) != 1:
            raise SystemExit(f"Stage {i} did not produce exactly one summary")
    print(json.dumps({"stages": len(results), "seconds": time.monotonic() - began}),
          flush=True)


if __name__ == "__main__":
    main()
