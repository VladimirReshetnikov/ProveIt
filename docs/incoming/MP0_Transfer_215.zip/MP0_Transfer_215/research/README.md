# Reproducing the bounded 214-state repair searches

These experiments search for a blank-tape initializer for an **existing
runtime-only 214-state fold**. They did not construct a valid 214-state
consistency machine. Every mutation surviving the finite primitive screen
enters a proved outward blank-tape ray.

The files `repair214-results.txt` and `pair-repair-summary.json` are the
original search receipts. Reproduction commands below write to
`research/reproduced/` and leave those receipts unchanged.

## Requirements and pinned inputs

Use Python 3.10 or newer, a C++17 compiler, and the standard libraries only.
No network access or external Python package is needed. Run the commands
from the package root.

Included inputs:

| File under research/inputs | Purpose | SHA-256 |
| --- | --- | --- |
| baseline215.sites.json | Original accepted source sites | 17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba |
| baseline215.native.tm | Original accepted K215, for provenance and optional positive control | 9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2 |
| runtime-only214.native.tm | Exact archived 88/301 runtime fold searched here | 06cdddee109e178fb1b398316a393ac2897b3763d5dcbce31968a5840c2e893a |

The primary input files are pinned to ProveIt commit
`b74074eacb936164d85e0f1aea5a8254412ade48`; their bytes are also the accepted
K215 inputs identified by the earlier fold packet. The fold is from
`zfc214-research/data/runtime-fold/k214-runtime-only.native.tm`, whose
packet records snapshot `c8029f50d324910a36694c39a1e62f5720c36f4c` and
accepted K215 commit `a61476422532a5d3b7dec11fc7a92751fe0d60f8`.
See `inputs/PROVENANCE.json` and the package's inherited notices/licenses.

## Generate the finite screen and compile

```sh
python research/generate_cases.py
c++ -O3 -std=c++17 research/repair214.cpp -o research/reproduced/repair214
research/reproduced/repair214 research/inputs/runtime-only214.native.tm research/reproduced/cases.tsv --check-only
```

Generation must report **6,176 cases** and this output SHA-256:

```text
9a63efdec6c56ced616c85831fa8d9f5594dcf0a5f5c99681ac245c404830d84
```

The final command must print `BASELINE_PASS 6176`. To check the original
215-state table with the same cases:

```sh
research/reproduced/repair214 research/inputs/baseline215.native.tm research/reproduced/cases.tsv --check-only
```

The generator is standalone. Its equations reproduce the pinned runtime
helper's frame and primitive contracts; it does not import that helper or
depend on any workspace path. Its generated output was byte-compared against
the original search input. The packaging replay is recorded in
`portability_check.json`.

## Reproduce the one-row screen

```sh
research/reproduced/repair214 research/inputs/runtime-only214.native.tm research/reproduced/cases.tsv > research/reproduced/repair214-results.txt 2> research/reproduced/repair214-progress.txt
```

Expected final line, apart from elapsed time:

```text
SUMMARY 36765 60 0 seconds ...
```

There are 43 physical state/symbol rows occurring in the first 200 blank
steps. For each row, the search tries two writes, two directions, and each
of the 214 working target states, omitting its original action:
43 x (4 x 214 - 1) = 36,765 specifications. Exactly 60 pass the affected
finite primitive cases. All 60 report `START RAY`; none reports
`START SEED`.

The first-stage receipt can be compared without the variable timing field:

```sh
python - <<'PY'
from pathlib import Path
def stable(path):
    return [line.split(" seconds ")[0]
            for line in Path(path).read_text().splitlines()]
assert stable("research/repair214-results.txt") == stable("research/reproduced/repair214-results.txt")
print("ONE_ROW_RECEIPT_MATCH")
PY
```

## Reproduce the two-row screen

The pair driver reads each of the 60 first-row survivors, applies it to the
pinned fold, and invokes the same bounded search on rows visited in that
variant's first 200 blank steps. It does not assume that every mutation
passes: the C++ process first rechecks all 6,176 baseline cases.

To use a freshly regenerated first-stage receipt:

```sh
python research/repair_pairs.py --first-results research/reproduced/repair214-results.txt
```

Alternatively, `python research/repair_pairs.py` uses the included original
first-stage receipt. Both commands default to the included fold, generated
`research/reproduced/cases.tsv`, compiled
`research/reproduced/repair214`, and new output files in
`research/reproduced/`. All these paths can be overridden; use
`python research/repair_pairs.py --help`.

The expected aggregate is **2,402,550 second-stage specifications**, including
repetitions and undoing the first mutation, and **4,235 finite survivors**.
Every survivor is an outward ray; there are zero seed survivors. Runtime
depends on the host; this stage took approximately 101 seconds in the
original experiment.

Check the regenerated aggregate and compare every stage's deterministic
result fields:

```sh
python - <<'PY'
from pathlib import Path
import json
old = json.loads(Path("research/pair-repair-summary.json").read_text())
new = json.loads(Path("research/reproduced/pair-repair-summary.json").read_text())
def stable(rows):
    return [{**r, "summary": [line.split(" seconds ")[0] for line in r["summary"]]}
            for r in rows]
assert stable(old) == stable(new)
totals = [0, 0, 0]
for row in new:
    assert row["returncode"] == 0 and not row["seeds"]
    fields = row["summary"][0].split()
    for i in range(3):
        totals[i] += int(fields[i + 1])
assert totals == [2402550, 4235, 0], totals
for log in Path("research/reproduced/pairs").glob("first*.out"):
    for line in log.read_text().splitlines():
        if line.startswith("SURVIVOR "):
            assert " START RAY " in line, (str(log), line)
print("TWO_ROW_RECEIPT_MATCH", totals)
PY
```

No compiled executables, regenerated case file, or pair logs are needed in
the source archive.

## Exact scope and limitations

Each source leaf is tested with all nine primary registers zero, except
that a positive CD case sets its target register to one. There is one
zero-valued spare and no initial gap. Primitive execution is bounded by
5,000 literal steps and judged at a **clean complete redispatch frame**,
including exact head and entire represented tape, or the halt state.
The historical first-visit-to-dispatcher endpoint bug was corrected before
these receipts were produced.

The tape window is 2,048 cells, with initial head at offset 512. Startup is
bounded by 500,000 steps. The initial mutation-row census uses 200 blank
steps. Bounds and the finite test family make this a restricted search,
not an all-natural correctness proof or an unrestricted impossibility
theorem. Mutations outside this family and mutants rejected by a bound
remain outside its conclusion.

For a survivor classified `RAY`, a transition reads an exterior zero,
moves outward, and returns to the same state, with no nonzero tape cells
ahead. The induction that it continues forever is exact even if it writes
ones behind itself. A hypothetical `SEED` would only be an initializer
candidate requiring complete calibration and universal validation; none
occurred here.

The portability changes add path arguments, standalone input generation,
input-open errors, and `--check-only`; they do not change the mutation
enumeration, primitive criterion, or startup classification.
