#!/usr/bin/env python3
"""Experimental R machine: verifies physical simulation, NOT consistency calibration."""
from pathlib import Path
import argparse,gzip,json,sys,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
sys.path.insert(0,str(ROOT/'code'))
import source_language as A
import independent_runtime as I

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--runtime',action='store_true');args=ap.parse_args()
 oldrows=json.loads((ROOT/'inputs/parent-transfer201.sites.json').read_text());old=A.tree(oldrows)
 rows=json.loads((HERE/'R.sites.json').read_text());new=A.tree(rows)
 assert new==A.replace(old,'1110',(A.subtree(old,'11101'),A.subtree(old,'11100')))
 assert A.graph_arithmetic(rows)[0]==A.graph_intervals(rows)
 assert A.metrics(new)['dag_nodes']==201 and len(rows)==4775
 P=I.table(ROOT/'inputs/parent-transfer215.native.tm');T=I.table(HERE/'R.native.tm')
 E=dict(P);E[311,0]=(0,1,38);E[311,1]=(1,1,12);assert T==E and len(T)==430
 r=json.loads((HERE/'startup.json').read_text());f=r['frames'][0]
 q=h=0;ones=set()
 for _ in range(f['steps']):
  w,d,q=T[q,int(h in ones)]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 assert(q,h)==(84,-2)and f['steps']==68442 and ones==set(f['one_cells'])
 assert ones=={x-2 for x in I.frame(rows[55][0],f['logical'],f['spares'],f['gap'])}
 out={'status':'PHYSICAL_FINITE_PASS','logical_calibration':'OPEN: AX row extraction and cleanup compiler missing','states':215,'source_nodes':201,'source_sites':4775,'blank_steps':68442}
 if args.runtime:
  import symbolic_runtime as S
  m={int(q):int(z)for q,z in json.loads((ROOT/'inputs/NATIVE_TO_LEGACY.json').read_text()).items()}
  for q in sorted({q for q,b in T}|{254}):
   if q not in m:m[q]=q+1000
  assert len(set(m.values()))==len(m)
  L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()};lemmas,blocks=S.prove_blocks(L);cases=[];coverage=set()
  for i,site in enumerate(rows):
   for positive in ((False,True)if site[1]=='CD'else(False,)):
    ans=S.case(L,lemmas,site,positive);coverage.update(ans['rows']);ans['rows']=sorted(ans['rows']);ans.pop('trace')
    cases.append({'site_index':i,'positive':positive,**ans})
   if(i+1)%1000==0:print('Experimental runtime leaves',i+1,flush=True)
  for block in blocks:
   for event in block['trace']:
    if event[0]!='list':coverage.add(tuple(event[1][:2]))
  reference=json.loads((HERE/'runtime/runtime.json').read_text())
  assert json.loads(json.dumps(cases))==json.loads(gzip.decompress((HERE/'runtime/runtime_cases.json.gz').read_bytes()))
  assert json.loads(json.dumps(blocks))==reference['blocks']
  assert len(cases)==6209 and sum(x['symbolic_steps']for x in cases)==1611528
  assert min(x['duration'][0]for x in cases)==7 and len(coverage)==430
  out.update(status='PHYSICAL_QUANTIFIED_PASS',cases=6209,symbolic_rules=1611528,rows=430)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
