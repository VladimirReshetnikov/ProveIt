# Experimental 215-state rotating-pop implementation

This is a physically validated implementation of a new command semantics. **It is not a calibrated ZFC-consistency candidate:** the completeness proof remains open. Its role is to make a distinct command interface concrete for further research, with no additional states.

Starting from the supplied transfer201/transfer215 source and table, replace the closed source subtree at address `111` from `((DROP,NIP),NIP)` to `((NIP,DROP),NIP)`. Exactly two physical transitions change:

- State311 reading0 becomes `0R38`.
- State311 reading1 becomes `1R12`.

The resulting command, writing `unpair(w)=(x,v)`, is

    R(t,w,d,h) = (x,v,d,t),

unless `h=1` or `x=1`, in which case it halts. The command order remains `R` at tag0, `MP(x)` at tag1, and `AX(c;x,y)` at tag `c+2`.

`R.native.tm` has 215 working states and 430 defined transition rows. `R.sites.json` has 4775 primitive occurrences, 201 distinct source subtrees, including primitive leaves, maximum depth44 and maximum zero run6. `runtime/runtime.json` and the compressed cases record all 6209 guarded primitive cases proved with the inherited all-natural unary/list-induction checker, covering arbitrary natural registers, gap, and nonempty finite spare lists with the complete zero exterior. All 430 transition rows are covered; the proof uses 1,611,528 compressed symbolic rules and every primitive has positive duration (minimum constant7). These are ordinary mathematical proof certificates, not a proof-assistant kernel endpoint.

`startup.json` records the exact 68,442-step blank run to the same complete encoded frame as the calibrated parent: native dispatcher84, head−2, header62, source ordinal55 at `110100100101010`, logical registers `[1,11,2,0,0,0,0,0,0]`, gap0 and 59 spare unary blocks all1. This verifies physical initialization; it does not establish logical completeness for R.

Useful command macros exist: `PUSH_R=AX(0;0,0);R^9;MP(0)` returns `(0,[t;w],0,0)` for every incoming natural tuple, and `NORM_R=PUSH_R;R` preserves top and stack while clearing counter/cache, or halts at top1. A conditional generalization block is known. However, no way to select an arbitrary AX row and delete its later generated stack heads while preserving that row has been proved. Successful MP's dummy zero causes a related deletion problem. See the accompanying formalism research note for the exact gap. Physical validation alone must not be described as an equiconsistency theorem.

Reproduce the finite source/table and blank checks with `python3 research/rotate-pop215/verify.py` from the package root. Add `--runtime` to rederive all 6,209 arbitrary-natural primitive cases and compare the complete ordered certificate. The exact table/source hashes are embedded in the original receipts. This replay does not resolve the open logical compiler obligation.
