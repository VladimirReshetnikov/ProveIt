# Independent machine-compression investigation and credit review

## Accepted contribution of this review

An independent mathematical review found no substantive gap in
`formalism_notes/mp0_s1_credit_proof.md`. Its new tag order is MP=0, S=1,
AX>=2, with field arities 2, 1, 3. The following details were checked against
the stated recurrence and the earlier transfer compiler's command contracts.

* Cantor right projection enumerates blocks `[0], [0,1], [0,1,2], ...`.
  Consequently a sequence with nonnegative initial sums retains that property
  after one or two right-projection pullbacks.
* With `g(0)=0`, `g(r)=b(r-1)` for positive r, the initial q-sum for
  `q=g+1` is `B(k-1)+k`, not `B(k-1)`. This distinction avoids assuming a
  false nonnegative cumulative balance: the first three candidate words are
  MP, S, MP and their cumulative balances are 0, -1, -1.
* On Cantor diagonal s>=2, the first s-1 commands begin AX, the next begins S,
  and the last begins MP. The complete AX portion has balance at least
  `9(s-1)`. During the S continuation it stays at least `8s-9`; during the
  final MP continuation it stays at least `7s-9`. These estimates apply to
  every command prefix, not just candidate endpoints.
* Every borrowed balance index is strictly earlier than the current
  diagonal start. The simultaneous induction is therefore well founded.
* Once the partial first diagonal is finished, later complete diagonals have
  nonnegative relative prefix balances. This proves the exact finite formula
  for the infinite credit at each cutoff. At cutoff N=1 the finite word is
  `[S,MP]`, so the exact conservative credit is one.
* For the composite S, old DROP first pushes the current top, and the two
  NIPs remove the temporary head and one original head. One protected
  original head suffices. Both halt guards inspect theorem values.
* The list representation need not have distinct nil/cons encodings.
  `P(0,0)=0` preserves the exact projection identity; explicit zero wrappers
  can be retained as a proof witness even if their numerical encoding is
  unchanged. An arbitrary buried numerical suffix is never inspected when
  the protected credit remains nonnegative.

This independently reviews the scheduler theorem. Exact machine simulation,
startup matching, source calibration and the inherited calculus/ZFC
comparison remain separate premises. No proof-assistant check is claimed.

### Stronger arbitrary-store startup theorem, independently reviewed

At the abstract complete command root, let the next candidate and continuation
pointer both be zero. Let `(t,w,d,h)` be arbitrary raw natural values. Assume
the separate physical source-boundary and scratch-register premises.

The first MP(0) returns top d on success and top 0 on failure, and always
resets cache to zero. Thus the following composite S halts in this initial
prefix exactly when `d=1 and h=I(t,1)` held initially. Outside this explicit
exception, S returns top 0, counter d and an arbitrary cache x. MP(1) then
returns cache 0, counter d+1 and top either 0 or d+1. No theoremhood of this
possibly suspect top is needed.

Candidate 3 is AX(0;0,0). Its parameters are U=A=d+1 and B=C=0, so its gate
is truth. It pushes eight genuine axiom instances and `Q_(d+1)(0)` above the
saved suspect top and the existing raw stack. These first nine heads are
theorems; everything below them is one arbitrary numerical suffix.

At the resulting root the next candidate is 4, the continuation pointer is
zero, and top, additive counter and cache are zero. The remaining words of
this diagonal are `W(4)=[S,MP(0)]` and `W(5)=[MP(0),MP(0)]`, so d(4)=1.
The nine heads therefore leave a permanent conservative margin of eight.

In particular, an initial additive counter d=0 permits arbitrary raw top,
stack and cache. The only theoremhood assumptions in the simpler startup
statement can be removed; the physical root/scratch premises cannot.
The same unrestricted raw-value corollary holds for every d other than 1.

The final independent proof sources are
`formalism_notes/mp0_s1_credit_proof.md` and
`formalism_notes/mp_first_self_sanitizing_theorem.md`. The finite
`check_mp_first_sanitizer.py` check is corroborating evidence; the argument
above does not infer the unbounded theorem from its finite samples.

## Material difference criterion

Compared with the primary repository K215, the transfer compiler uses a
different three-command interface. Compared with the immediately preceding
transfer215 construction, MP=0/S=1 is a command-tag permutation with changed
physical dispatch and changed candidate enumeration. Its additional proved
benefit is exact protected startup credit one instead of two, together with
the arbitrary-store startup theorem just proved. It should not
be described as a new calculus, a 214-state machine, or a fundamental
state-count breakthrough. A rooted transition graph comparison distinguishes
it from mere renaming of working states; the final accepted table should be
compared separately, not confused with the rejected direct-transfer table.

## Negative low-level results

### Marker macros on primary K215

The exact primary table was screened for state pairs sharing a branch and
distinguished by the preceding tape bit. Sixteen pairs meet the unconditional
incoming-edge condition; a finite concrete context census expands the set
to 24 pairs when differing writes and directions are allowed. Searches of
existing short tape-preserving helper macros found no usable fold. Apparent
helpers for pairs 8/127 and 44/105 recurse through rows the fold would change.
These are restricted construction searches, not a lower bound.

### Startup repairs of the existing 88/301 runtime-only 214 table

The baseline here is the prior incoming table with SHA-256
`06cdddee109e178fb1b398316a393ac2897b3763d5dcbce31968a5840c2e893a`.
Its unmodified 6,176 concrete primitive cases pass the local C++ checker.
Each case uses zero primary values except the tested positive decrement
register, which equals one; gap zero and one zero-valued spare are used.

The one-row screen tries all 855 changed actions (two writes, two directions,
214 working targets, excluding the original action) on each of 43 rows
visited during the initial blank prefix: 36,765 specifications in all.
Sixty pass every affected concrete case. Each still reaches a verified
outward zero ray from blank; none supplies an initializer.

For each of these 60 first-row survivors, a second arbitrary mutation is
screened on every row occurring in that variant's blank prefix. There are
2,402,550 second-stage specifications, including repetitions and undoing the
first mutation. Of them, 4,235 pass the concrete primitive tests. Every one
of those 4,235 enters an exact outward ray. No two-row seed survivor was found.

The primitive cap is 5,000 literal steps and the startup cap is 500,000;
the tape window is finite. Hence rejected/bounded cases do not establish an
unrestricted impossibility theorem. The ray classification of the finite
survivors is exact: a zero-reading self-loop moves away from all nonzero
cells, so induction proves it continues forever.

Reproduction inputs are `repair214.cpp`, `repair_pairs.py`, `generate_cases.py`,
the pinned source, and the pinned runtime-only table. Summaries are
`repair214-results.txt` and `pair-repair-summary.json`.

### Attempted merge of transfer decoder 310 into engine state 26

Replacing state 310 by 26, changing 26/0 to `0 R 311`, and redirecting
312/1 to 26 produces 214 working states, but is invalid. On the
first source leaf `000: CD8`, with all nine primary values zero, one zero
spare and gap zero, it reaches a clean full redispatch frame after exactly
608 steps with the wrong tape. The complete trace and both endpoint supports
are in `merge310-counterexample.json`.

An earlier 154-step first visit to dispatcher 84 was an intermediate malformed
frame and was not a valid counterexample endpoint. That claim is explicitly
withdrawn; the 608-step endpoint uses the complete clean-frame test.

### Shortening the zero-run scanner

A closed-reassociation beam search on the proposed direct-transfer source
examined 14,882 distinct sources with at most 201 DAG nodes. It reduced the
number of addresses containing six consecutive zero bits from 37 to 30,
but the maximum remained six. This does not justify deleting scanner state
50. The best finite source and bounded search transcript are retained in
`zero-best.sites.json` and `zero_greedy-progress.txt`.

The proposed direct-transfer machine itself was rejected by the main runtime
review because CLR(T)'s native state 122 interprets its zero branch using a
preceding-bit selector; the new context invokes a different register.
Its graph census is only a diagnostic, not an accepted machine claim.
