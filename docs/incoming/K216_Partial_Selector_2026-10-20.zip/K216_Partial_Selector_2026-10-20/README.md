# K216: a partial-selector construction

This packet contains a 216-working-state deterministic binary single-tape Turing machine. Its tape is two-way infinite, initially all zero; each step moves L or R. The separate halt state is not counted. With the inherited ZFC calibration and the checked bridges included here, blank-start nonhalting is equivalent to Con(ZFC). No unconditional consistency or nonhalting assertion is made.

The new idea is to reparse the proof-search source so that two *partial* continuation providers become siblings. Their unused branches remain free. A context-correct 217-state allocation then reuses this selector to merge states164 and183 by recovering their origin from the immediately-left tape marker. This produces216 without deleting or weakening the startup.

## Files and exact identities

- `machine/k216.native.tm`: official independently replayed native table,432 rows; SHA256 `2efb7adf9cfcbea58197a2bde2610b22f58b647f05385bc716b036242be6fa6c`. Start0, dispatcher84, halt254.
- `machine/k216.tm`: dense table, working labels0..215 and halt216; SHA256 `5536fcf48e76f56152cfa0a77cae19c09be7161d39514075522ecfe056cffc45`. Start0. `machine/canonicalization.json` is the exact reversible native/dense map.
- `source/sites216.json`: authoritative runtime source serialization (spaced JSON, no trailing newline), SHA256 `c865047ce7283521199e93ce74307821f3b3231742213329b7ac5e8a7ec0b6d2`.
- `source/sites216.compact.json`: identical parsed rows, compact JSON plus newline, SHA256 `7f9d4f321b7a7d56013056b1ad6be2723538c43ea2d73548bcd0e35f0381bde0`.
- `source/dag_recipe.json` and `source/table_recipe.json`: deterministic source-DAG recipe and20 explicit prefold row replacements relative to the pinned parent. The builder applies the origin-marker fold separately, and reproduces both native and dense bytes without allocation search, solver, or compiler search.
- `report.tex`, `report.pdf`, and `sections/`: mathematical explanation, full canonical transition table, proof boundaries, and reproduction instructions.
- `evidence/`: source bisimulation, arbitrary-tape fold certificate, complete exact startup trace,6176 unbounded symbolic primitive cases and row-coverage inventory.
- `code/`: portable standard-library reconstruction/audit scripts and original symbolic runtime engine, helper, driver, and legacy label map.
- `parent/K217_Dominated_Continuation_2026-10-20.zip`: exact pinned parent, SHA256 `4aa33f0c4844043d243fb7d01ef316d4b72de641864e5317525f7cfac7f5c809`. It retains the exact K218 dominated-rho8 archive, theory certificates, compiler/source bridges, proof-search calibration, licenses and attribution. No network retrieval is required.

The discovery allocator's normalized-native table had SHA256 `507e9342ac81bfdceb084179762577518cfc063951788491cbf4c1fa507293e1`. It is NOT the official native byte identity above. Native301/302 correspond to normalized79/102; the official composed dense map reconciles them. Source whitespace identities likewise must not be conflated.

## Reproduce

Use Python3.10 or newer with assertions enabled. No third-party Python packages, network, repository checkout, SMT solver, or TeX installation are needed for verification. Run from the extracted packet:

    python3 -B verify.py

The default checks the exact manifest and stored symbolic inventory; fully checks the pinned parent's default theory/source/table/blank/fold chain; reconstructs216 source and tables byte-for-byte; recomputes the all-natural source bisimulation, exact whole-tape startup, dense isomorphism, and arbitrary-tape marker fold. Default checking is substantial and may take several minutes. Stored primitive certificates are not freshly derived by the default command.

For a new full unbounded symbolic derivation of all6176 guarded primitive cases:

    python3 -B verify.py --runtime --work ../replay216

The work directory must not already exist and should be outside the packet. This additionally regenerates the symbolic cases from the exact literal native table and requires every ordered case receipt and whole startup trace to match. It may take several additional minutes. Preserve assertions; do not use `python -O` or `PYTHONOPTIMIZE`.

The exact blank run takes313133 steps to dispatcher84, head−5, nine registers `[3,0,0,0,3,0,0,0,0]`, gap80 and130 spare values each1. Its complete tape has277 one-cells and zero elsewhere. The symbolic proof covers arbitrary natural primary values and gap, arbitrary nonempty finite spare lists, and complete zero exterior. It has1709992 symbolic rules, positive affine duration constant at least13, and covers all432 transition rows.

To reconstruct only, first extract the pinned parent and run:

    python3 -B code/reconstruct216.py --parent /path/to/K217_Dominated_Continuation_2026-10-20 --out /path/to/new-output

To rebuild the PDF, install a standard TeX distribution with `pdflatex`, then follow `build.sh`. The supplied PDF is already compiled.

## Evidence boundary

These are ordinary mathematical proofs and executable, induction-based symbolic certificates, not bounded simulation alone. The source proof quantifies over every natural register store. The marker proof quantifies over every initial tape at state0. The startup proof fixes the entire tape, not merely a finite cropped window. The runtime checker uses unary and list induction with positive progress.

No newly compiled Lean/Rocq endpoint or internally formalized PA theorem is claimed for these exact216-state bytes. This packet inherits its foundational theorem from the pinned ancestry and supplies the new source, literal-table, runtime and startup bridges. No claim of minimality or universal discovery priority is made.

To re-create the archive with the same Python/zlib implementation and fixed metadata:

    python3 -B code/repack.py ../K216-repacked.zip

The manifest pins every delivered file except itself. The archive has sorted members, fixed2026-10-20 timestamps, regular-file0644 permissions and deflate level9.

Archive naming uses the user's UTC−07 local date2026-10-20; proof runs may carry UTC date2026-10-21.
