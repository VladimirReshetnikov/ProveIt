# Lexicographic Surreal Well-Orders
## Prefix homogeneity, invisible exhaustiveness, and label rigidity

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

Start with `article.pdf`. The standalone source is `article.tex`, with an
internal bibliography. The manuscript is a further investigation, not a
replacement for or certification of the previous ProveIt reports.

### Main contributions

Theorem 7.1 classifies uniformly set-indexed configurations of injective
ordinal-class words under order-and-cylinder-preserving automorphisms of
a chosen set-supported core. Core membership, pairwise first-disagreement
ordinals, and comparison directions are the complete invariants.

Theorems 8.1 and 8.2 show that exhaustiveness is not invariant, even with
all unranked prefix cylinders and any fixed set of core/node parameters.
Theorem 9.2 strengthens the existing automorphism-extension obstruction:
the counterexample preserves the entire cylinder family.

Theorems 10.1 and 10.3 show that equality of labels across extension edges
forces coordinatewise alphabet automorphisms, and that preserving the
supported core then forces identity. Section 11 proves regular-cardinal
set analogues and an exact automorphism-group cardinality. Section 12
isolates the cofinality obstruction and distinct singular support issues.

The article also separates interpretations, proves the supporting
embedding/comparison results, audits the foundational size levels,
proposes concrete Lean modules, and gives 11 further research questions.

### Files

- `article.pdf`: compiled article.
- `article.tex`: complete LaTeX source and bibliography.
- `build.sh`: run finite checks and compile the PDF.
- `code/finite_checks.py`: deterministic standard-library Python checks.
- `data/finite_checks.json`: recorded results and explicit exclusions.
- `RESEARCH_STATUS.md`: scope and verification status.
- `SOURCE_AUDIT.md`: inspected sources and provenance.
- `SHA256SUMS.txt`: checksums of the delivered files other than itself.

### Rebuild

Run `bash build.sh` with Python 3, latexmk, and a reasonably complete TeX
Live or MiKTeX installation. No external images or bibliography files are
needed. Fonts supplied by the installed TeX distribution are not included.
PDF bytes can differ across TeX versions and build timestamps.

### Verification status

All 269,329 finite assertions pass with the default seed 20261003.
They test finite rational-prefix mechanisms and finite permutation
completion, not transfinite proofs. No Lean build was performed, no new
Lean formalization is claimed, and the research manuscript is not
independently refereed. Historical priority is not established.

Repository snapshot: 7ff7736ecf3a0adc8536b2d083cf819e1ba39ace.
No remote repository files were modified.
