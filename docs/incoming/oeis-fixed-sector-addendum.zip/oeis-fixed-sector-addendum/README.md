# Fixed Taylor sectors for multiplicity cap growth constants

Standalone large-cap addendum dated 1 October 2026. Read `fixed-sector-addendum.pdf`; edit `fixed-sector-addendum.tex`. This package supplements the separately delivered bounded-multiplicity report, rather than duplicating its combinatorial proof or inverse theorems.

## Results and scope

- Exact strictly positive Taylor sectors A_(r,b), with T_b - pi^2/6 equal to their convergent sum for every integer b >= 2
- For each fixed K, a positive remainder asymptotic to the next exact sector, with its sharper relative error
- For each fixed r, a proved expansion to every fixed algebraic order, with rational coefficients and an executable coefficient algorithm
- The exact first sector, explicit three-correction formulas for r = 2 and r = 3, and a narrow reciprocal corollary for mu_b = 1/T_b
- Quadratic reciprocal terms are O(b^2 4^(-b)) and are below every fixed primary sector; the reciprocal remainder is asserted positive only eventually for each fixed K

Finite algebraic truncation in an earlier sector generally swamps later exponential sectors. No growing-r uniform theorem, optimal truncation, summability, justified sum of all asymptotic sector formulas, accumulation-scale result, or new inversion theorem is claimed. The identity with the combinatorial growth constant is inherited from the separate main report, whose source hashes are in `provenance.json`.

## Reproduce

Prerequisites: Python 3, SymPy 1.14.0, mpmath 1.3.0, and PDFLaTeX with the standard packages used by the source. Poppler is used only for visual QA. No network calls are made by the supplied scripts.

1. Check supplied-file integrity before rebuilding: `sha256sum -c SHA256SUMS`
2. If needed, install dependencies: `python3 -m pip install -r requirements.txt`
3. Run `./verify.sh`. It recomputes the complete author quadrature output, the independent discrete-geometric/exact-rational checks, the third Gamma-moment coefficient check, and the reciprocal algebra identity. Fresh results go in `checks/replay/`; deviations or failed assertions cause nonzero exit status
4. Run `./build.sh` to rebuild the PDF. The build fixes the metadata epoch; PDF bytes can nevertheless depend on the TeX installation

The full check may take several minutes. The exact symbolic/rational checks are distinct from the numerical quadratures, which are not interval-certified. The theorem rests on the mathematical proof, not on finite test coverage.

## Included files

- `fixed-sector-addendum.pdf` and `.tex`: integrated mathematical addendum
- `sources/`: unmodified derivation, author check and JSON, independent PASS audit and check/JSON, and separate Gamma-moment check
- `checks/`: expected third-check output, reciprocal identity check, and fresh replay outputs
- `audits/integrated-source-review.md`: fresh review of the assembled TeX and reciprocal corollary, with source hash
- `qa/visual-review.md`: page-by-page PDF inspection record
- `provenance.json`: original source hashes and hashes identifying the separate main report
- `verification-summary.json`: release verification and clean-unpack replay results
- `SHA256SUMS`: release payload hashes, excluding itself

No external upload was performed. The separately delivered main report is referenced but not bundled.
