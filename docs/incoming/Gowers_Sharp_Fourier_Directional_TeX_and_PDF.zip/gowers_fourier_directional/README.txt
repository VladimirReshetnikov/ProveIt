SHARP FOURIER DETECTION AND DIRECTIONAL RIGIDITY
IN GOWERS' SZEMEREDI FRAMEWORK
Research manuscript prepared with ChatGPT for Vladimir Reshetnikov
7 October 2026

CONTENTS

gowers_fourier_directional.tex  Complete manuscript source in one file
gowers_fourier_directional.pdf  Compiled article
figures/                       Two vector figures and PNG previews
code/                          Portable verification and figure scripts
data/                          Verification results and source provenance
requirements.txt               Python package versions used for verification
Makefile                       Optional build and verification commands
SHA256SUMS                     Integrity hashes for every other package file

MATHEMATICAL CONTENT

1. Complete seven-piece four-frequency missing-arc minimax profile,
   including the algebraic middle branch and all equality cases.
2. Exact maximal first continuation interval for every cutoff R >= 3,
   with its next Fourier moment, junction, and asymptotic width/height.
3. A sharp signed-moment positivity ceiling, globally unique at equality.
4. Exact finite-grid correction on the new branch; closed aligned
   semicircle formula and twelve residue-dependent all-order expansions.
5. Explicit transport stability with the optimal square-root exponent.
6. Sharp cyclic derivative comparison D <= (N+1)d_1/6 for N >= 12,
   with all equality cases and the additive graph-energy interpretation.
7. Thirteen proposed research questions, concrete integration guidance,
   source attribution, and a reproducibility appendix.

The proofs are in the article. Numerical checks do not replace proofs.
This is an AI-assisted research manuscript, not externally peer-reviewed
or proof-assistant-verified. Extensions are identified relative to the
audited project sources; external publication priority is not established.
No new global quantitative Szemeredi bound is claimed.

BUILD THE ARTICLE

Use a standard TeX Live or equivalent installation with pdfLaTeX and the
packages listed in the source preamble. Run from this directory:

  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    gowers_fourier_directional.tex

Alternatively, run pdfLaTeX three times to resolve cross-references:

  pdflatex -interaction=nonstopmode -halt-on-error gowers_fourier_directional.tex
  pdflatex -interaction=nonstopmode -halt-on-error gowers_fourier_directional.tex
  pdflatex -interaction=nonstopmode -halt-on-error gowers_fourier_directional.tex

The bibliography is included in the TeX file; no BibTeX run is needed.
The figure PDFs are provided, so Python is unnecessary merely to compile.
The source has no external manuscript-section dependencies.

REPRODUCE THE CHECKS

The verification environment used Python 3.12 and the versions recorded in
data/runtime_versions.json. For an isolated environment:

  python3 -m venv .venv
  . .venv/bin/activate
  python -m pip install -r requirements.txt

Run the independent families from this directory:

  python code/verify_frontiers.py --output data/verification_frontiers.json
  python code/verify_fourier_lp.py --output data/verification_fourier_lp.json
  python code/verify_directional.py > data/verification_directional.json

The first script checks exact symbolic identities, constructed measures,
general-cutoff transitions, and a finite discretization LP sweep.
The second independently formulates the continuum-discretization and
finite cyclic optimization problems and checks the exact grid gap.
The third uses only Python's standard library and exact integers/fractions
to check the cyclic windows, finite maps, proof gates, and equality cases.
Its exhaustive small-cycle searches do not establish an all-target
theorem below the article's N >= 12 range.

Regenerate the figures with:

  python code/make_figures.py

The plots evaluate the proved formulas; they do not fit solver output.
The two continuous/grid implementations are deliberately separate.
Saved results may differ in harmless floating-point last digits across
versions and platforms. Assertions in the scripts encode the tolerances.
There are no network, credential, or repository-write operations.

INTEGRATION INTO PROVEIT

The package is an additive research contribution. One natural location is

  Combinatorics/Ramsey/Research/GowersSzemeredi/
    sharp-fourier-directional/

Keep the figure directory beside the TeX file. If combining this source
with the existing integrated manuscript, rename or prefix its macros and
labels as required by that manuscript's conventions. The prose explicitly
credits the prior general first-window result (source 37), the prior
cutoff-three/last-window report, and the unequal-budget first-window report.

The audited repository revision and exact source hashes are recorded in
data/source_ledger.json. This package does not modify or push the repository.
The article and code retain clear hypotheses for weighted measures,
open-arc endpoints, finite-grid feasibility, full-domain cyclic functions,
abelian targets, and the N >= 12 proof range.

INTEGRITY

From this directory, on a system with sha256sum:

  sha256sum -c SHA256SUMS

Build metadata and the PDF inspection record are in
data/build_validation.json. Internal mathematical review observations
are in data/independent_review.md. The review is supplementary and does
not represent external referee endorsement.
