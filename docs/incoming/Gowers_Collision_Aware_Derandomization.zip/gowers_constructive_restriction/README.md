# Collision-aware derandomization of Gowers's restriction step

**Research manuscript · 6 October 2026 · prepared for ProveIt**

The article gives exact algorithms for the conditional expectations needed in
Gowers's restriction mechanism, including repeated entries. It answers the
ambient-size version of the efficient-certification question in the prior
manuscript `gowers_polynomial_restriction.tex`. The complete arguments are in
`article.tex` and `article.pdf`.

## Results and their scope

For an order-s additive energy on n labelled points and total ambient group
size D, the exact Bernoulli expectation and deterministic signed rounding take
O(s^4 n D) rational operations and O(s^2 D) rational storage. A local decision
uses only O(s^2) array probes per energy statistic. The algorithm treats
repeated occurrences of a label as one selection event.

Uniform prescribed-cardinality rounding uses a distinct-support variable of
degree at most 2s. Its cost is O(s^6 n D) and storage O(s^3 D), without a factor
of the requested subset size. This does NOT describe heterogeneous Bernoulli
sampling conditioned on its size. A proved extension preserves fixed quotas
in finitely many specified colour classes; a multicolour implementation is
not shipped.

For a fixed t-position system of linear equations, the generic engine costs
O(3^t n D) operations and O(2^t D) storage. Zero coefficients, nonunit
coefficients, composite moduli, and repeated entries are allowed. The paper
proves further compression by repeated column types; the balanced two-type
case is implemented by the energy engine.

The source-specific rational Fejer theorem preserves the prior companion's
retained-count bound under its explicit hypotheses. For a scalar prime-cyclic
graph, fixed-filter evaluation/rounding costs O_s(n p^2), but searching all
translated parameters costs O_s(n p^5). These costs exclude the separately
bounded rational-kernel precomputation. Do not describe the smaller bound as
an end-to-end bound. The arithmetic algorithms have polynomial bit complexity
in the explicit ambient representation, NOT in log(D).

These are local constructive results, not a new global Szemeredi bound.
Bibliographic priority has not been established. No new Lean proof was
compiled or kernel-checked, and no repository files were modified.

## Package contents

- `article.tex`, `article.pdf`: standalone manuscript with complete proofs,
  ten further research questions, and a claim ledger.
- `code/energy_inventory.py`: exact Bernoulli and prescribed-size engines.
- `code/system_inventory.py`: exact generic system engine and signed rounding.
- `code/fejer_search.py`: rationally certified Fejer tables and full finite
  parameter search; no floating-point trigonometry in the construction.
- `code/verify.py`: independent finite regression checks through energy order
  eight, including product groups and composite cyclic moduli.
- `examples/`: four runnable JSON inputs.
- `data/`: actual generated outputs and verification report.
- `FORMALIZATION.md`: prospective interfaces and proof dependencies.
- `SOURCE_AUDIT.md`: source provenance, comparisons, and verification limits.
- `THEOREM_INDEX.md`: navigational index of the principal article results.
- `Makefile`: builds, checks, and reproduces the examples.

## Run

Python 3.10 or newer is required; the standard library is sufficient. The
package was tested with Python 3.13.5 in the delivery environment. (The exact
version is also recorded in `data/build_validation.json`.)

```sh
python3 code/verify.py --output data/verification_results.json
python3 code/energy_inventory.py examples/bernoulli.json
python3 code/energy_inventory.py examples/fixed_size.json
python3 code/energy_inventory.py examples/affine_core.json
python3 code/fejer_search.py examples/fejer.json
```

Input probabilities and `eta` must be integers or rational strings such as
`"3/7"`; floating-point probability inputs are rejected. The energy CLI takes
`modulus`, distinct-residue `domain`, matching `values`, `order`, `eta`, and
either a probability list or a prescribed `size`. Outputs contain exact
rational objectives, selected indices/domain values, and a decision trace.

The Fejer CLI additionally takes `length`, `denominator`, and optionally
`translated` (default true). Its small demonstration is an exact-data
certificate below the sufficient worst-case analytic threshold. It is not a
large-modulus performance benchmark. The CLI accepts a supplied length and
precision denominator; it does not automatically verify the worst-case
analytic hypotheses involving alpha. A positive exact output surplus is a
valid instance-specific certificate regardless of that sufficient threshold.

The fixed-size example begins with uniform mean surplus -15/4 but returns
three points with surplus 39/4 and respected fraction 31/37. The fully searched
Fejer example returns a three-point subset with 19 respected additive
quadruples and no unrespected quadruples. Exact outputs are in `data/`.

### Python API

Put `code/` on the Python import path. `FiniteAbelianGroup((q1,...,qd))`
represents a product of cyclic groups. A group element is a tuple of d
residues. A signed energy model is `(group, label_images, coefficient)`; all
models share a label set and label order. Use `deterministic_round(models,
probabilities, order)` or `fixed_size_round(models, order, size)`.

For generic systems, a model is `(group, steps_by_label, coefficient)`, where
`steps_by_label[i][j]` is the increment when label i occupies position j.
Use `system_round(models, probabilities, positions)`. This count does not
require an injective map from labels to group elements.

### Rebuild the PDF

A standard LaTeX installation with `latexmk`, pdfLaTeX, Latin Modern,
`amsmath`, `amsthm`, `mathtools`, `microtype`, `booktabs`, `longtable`,
`enumitem`, `xurl`, `hyperref`, and `fancyhdr` suffices. No external images,
bibliography database, proprietary packages, or font files are required.

```sh
make pdf
make check
make examples
```

Suggested integration location:
`Combinatorics/Ramsey/Research/GowersSzemeredi/collision-aware-derandomization/`.
All article theorem labels have the prefix `gcr:`. Generated build auxiliaries
are not part of the delivery archive.
