# Sparse Diophantine certificates for finite mass lattice dynamics

Research report prepared for Vladimir, 2 October 2026

Corrected code release, 3 October 2026: direct `Poly(...)` construction now
requires immutable canonical terms with exact integer coefficients and indices.
Use `Poly.make(...)` to canonicalize exact terms. See `CORRECTION.md` for the
reproducer, validation, and unchanged-mathematics ledger. The PDF, LaTeX,
mathematical fixtures, and source tables are unchanged.

## Read the report

Open `sparse-lattice.pdf`. Editable LaTeX is in `paper/`. The full-table theorem uses the preferred single table-row selector:

- V = T [ M(q^3 + 14) + 5M(M-1) ]
- R = T [ 17M + 5M(M-1) ]
- The nonnegative-real exact variant adds 2MT residuals and no witnesses

The report also proves the paid uniform loader and exact first-pulse interface, audits the corrected Morita–Imai source construction, and gives full bounded-diameter and mass-at-most-two decidability proofs. The mass-two relation is further shown effectively semilinear in coordinates and exact time, yielding horizon-free canonical quartics with post-elimination rule-dependent arity.

## Reproduce

Required for the arithmetic and semantic replay: Python 3.10 or newer, standard library only, and a POSIX shell. No network access or third-party Python packages are needed.

    python3 replay/verify_manifest.py
    ./run-replay.sh

The runner copies the code and fixtures to a temporary directory below `.replay`, regenerates the generic fixtures, reruns the independent coefficient and dynamics audits, regenerates both finite Morita tables, checks the mass-two arithmetic, and replays every shipped certificate including both doubling pulses. It compares stable generated results and bytes with the release data; gzip exports are compared after decompression because their header timestamps may differ. The shipped files remain unchanged. The runner reports the directory containing fresh outputs.

The default runner also executes the standalone exact-polynomial regressions.
To run only these boundary and algebra checks:

    python3 replay/core/test_poly_exactness.py

If an unzip utility does not restore executable bits, use `sh run-replay.sh`
(and `sh build.sh` for the PDF build) instead of `./run-replay.sh`.

For a fresh construction of the two larger source certificates as well as the default validation:

    ./run-replay.sh --regenerate-source

The default already evaluates all their exported residuals and checks exact table/input/circuit binding. The extra option repeats their witness construction and compressed export too. Expect this to take longer than the small generic tests.

To rebuild the PDF with TeX Live and standard LaTeX packages:

    ./build.sh

The script writes build intermediates in `.build` and updates `sparse-lattice.pdf`. The supplied manifest is for the shipped files; rebuilding with a different TeX version can change PDF bytes without changing its mathematics. Python replay does not need TeX.

## Package contents

- `paper/`: complete LaTeX report
- `replay/core/`: coefficient-explicit compiler, tests, actual source-fixture generator, and fixtures
- `replay/independent/`: separately written dynamics and polynomial compilers plus coefficient cross-checks
- `replay/morita/`: independent corrected local-rule compiler and source tests
- `replay/two-mass/`: independent encounter/query arithmetic tests and a separate regression
- `replay/semilinearity/`: proof-component and independent actual-CA/Presburger arithmetic tests
- `tables/`: full 17,576-row doubling local permutation and full 9,261-row unsafe-source counterexample permutation
- `receipts/`: machine-readable results from the validated release
- `SOURCE-PROVENANCE.md`: attribution, scope, and packaging changes
- `SHA256SUMS`: content integrity hashes

The larger doubling fixture is about 4.4 MB compressed; its full coefficient list certifies the paper's n=2, T=41 example. It uses the declared 97-row simulation subset bound to the full 17,576-row table. The smaller n=0, T=7 fixture does the same. These are restricted-row certificates for a fully specified nonuniversal source, not claims of generic total-table lookup at cost 97.

## Important scope

Natural input parameters remain natural even when auxiliary witnesses use the nonnegative-real exact variant. Default natural simplex certificates have fractional nonnegative-real counterexamples. Time is externally fixed in the generic lattice compiler; its dimension grows with time. Unit expansion and cost are polynomial in numerical mass, not in the bit length of mass. The classical fixed safe universal source is an existence construction here, not a printed small universal source machine. Pulse detection is not global CA halting or exact-target undecidability. The small-mass theorem has no novelty or matching upper-bound claim. Its horizon-free fixed-arity corollary is for the decidable mass-at-most-two subclass, with 2I+6C+G auxiliary witnesses after quantifier elimination, not for general universal computation.

No third-party paper PDFs, screenshots, credentials, machine-specific paths, or package-manager environments are redistributed.
