# Sharp Boolean Phase Integration in Every Degree

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and the
ProveIt project, 6 October 2026.

## Main result

For every `d >= 3` and `V = F_2^n`, `n >= 2`, the largest normalized selected
Gowers derivative Fourier energy of a symmetric nonintegrable `d`-linear tensor is

    b_d = 1 - (d + 1)/2^d.

Moreover, a nonintegrable tensor has this maximum if and only if it is

    C_d(u,v) + S,    C_d(u,v) = sum_i v(h_i) product_{j != i} u(h_j),

where `u,v` are independent linear forms and `S` is an integrable tensor.
For `d >= 4`, every other nonintegrable tensor has energy at most

    1 - 3d/2^(d+1) = b_d - (d - 2)/2^(d+1).

A stronger bound retains the defect-radical codimension `r`:

    M(T) <= 1 - (1 - 2^(-r)) d/2^(d-1),    r >= 2.

The second bound is not claimed to be the optimal noncanonical maximum.

The new all-degree induction closes Research Questions 1 and 2 in the preceding
*Exact Boolean Obstruction Energies* manuscript and the tensor-classification
part of its Research Question 4. It does not classify all maximizing functions.
The previous canonical-family theorem is reproved and explicitly credited.

## Files

- `all_degree_boolean_integration.tex` — standalone source, embedded bibliography;
  all labels have the prefix `bsi:`.
- `all_degree_boolean_integration.pdf` — compiled 21-page article.
- `code/verify.py` — standard-library exact verifier and reusable tensor routines.
- `data/verification.json` — executed exact regression results.
- `data/theorem_manifest.json` — claim/dependency/status inventory.
- `SOURCE_AUDIT.md` — source comparison, exact repository revision and blobs.
- `PROOF_AUDIT.md` — critical logical checks and limitations of finite evidence.
- `FORMALIZATION.md` — suggested Lean theorem interfaces and dependency order.
- `Makefile` — build and regression targets.

## Reproduce

Python 3.10 or later, standard library only:

```sh
python3 code/verify.py
python3 -O code/verify.py --output data/verification_optimized.json
```

The two JSON records are identical. All checks use explicit exceptions rather
than assertions. There are no network requests, random floating-point searches,
or numerical optimization dependencies. The fixed seed is `20261006`.

Compile with a standard pdfLaTeX installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error all_degree_boolean_integration.tex
```

Alternatively, `make all` runs the verifier twice, compares its outputs, and
builds the PDF. `make clean` removes generated TeX auxiliaries and the redundant
optimized-verifier output, preserving the article PDF and the main JSON record.

## Verification scope

The executed census covers 38,044 tensors, including every symmetric tensor on
`F_2^2` in degrees 3–10 and every symmetric cubic and quartic on `F_2^3`.
It compares defect ranks against an independent support-coefficient integration
test, checks exact integrable-slice proportions, reconstructs every tested
codimension-one defect, and computes constant-function energies exactly.
Additional checks use exact Gaussian-rational functions, independently expanded
cube products, integer modular primitives, and rational recurrence identities.

These are finite regression checks, not optimization over every bounded function
and not a proof in all dimensions. Those conclusions are proved in the article.
No Lean proof, independent referee report, or repository-wide build is asserted.

## Suggested repository placement

A standalone sibling directory, for example:

    Combinatorics/Ramsey/Research/GowersSzemeredi/all-degree-boolean-obstructions/

is preferable to assigning a new number in the aggregate research source list
without coordinating with the maintainer. The article can also be integrated
into the aggregate manuscript using its unique label prefix. The bibliography
keys may need renaming when merging into an existing bibliography.

This package does not modify any existing repository file or theorem-status ledger.
It contains no prior manuscripts, third-party article PDFs, or font files.

## Status

Unrefereed mathematical research. The new contribution is the universal
all-degree closure and extremal rigidity, relative to the inspected project
manuscripts. Literature priority is not asserted. The result is a
characteristic-two local phase-integration theorem, not a new global bound for
Szemerédi's theorem and not a general low-energy inverse theorem.
