# A 238-state binary machine calibrated to Con(ZFC)

Research prepared for Vladimir Reshetnikov, 19 October 2026.

This package contains an explicit deterministic, single-tape, two-symbol Turing machine with **238 working states**, including blank-tape initialization. Its transition table is `machines/zfc238.tm`.

The main mathematical result is

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{238},0^{\mathbb Z})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

Equivalently, blank halting is provably equivalent to the existence of a finite ZFC refutation. The ordinary proof uses the explicitly identified, inherited ProveIt source/calculus/ZFC calibration. It does not assume Con(ZFC). Read `report.pdf` or its complete source, `report.tex`, for the proof, all compatibility obligations, the literal table, provenance, alternative formalisms, and further questions.

## Exact machine convention

| Item | Value |
|---|---|
| Working states | 0 through 237 |
| Separate halt outcome | 238, with no outgoing transitions |
| Initial state and head | State 0, head at position 0 |
| Tape | One tape indexed by the integers; initially all zero |
| Symbols | 0 and 1 |
| Moves | L or R, exactly one cell per transition |
| Rows | 476, exactly two per working state |
| Blank initializer | Included in the 238-state count |
| Canonical runtime dispatcher | 84 |

Each non-comment table line is `state read write direction next_state`; `#! start 0` declares the start. The working-state count excludes the separate halt outcome, as in the binary Busy Beaver convention used by the cited work.

Canonical table SHA-256:

```text
909f29c493e0ccc5d6a481fd7a20a9a82eb934ab2aa7df17b5ec3789255a8c08
```

The same machine in inherited labels is `machines/zfc238_old.tm`, with start 95, dispatcher 96, and halt 254. Those labels are not consecutive. Its SHA-256 is

```text
069942be27db9736875ea042320e51ac3b1eac7116cbe01cdce520fa6056f78c
```

## What is new

The incoming material contains two different 239-state constructions. Boundary239 shortens the source/decoder and removes inherited state 218, while retaining 169. Coordinated239 removes 169 using shared runtime states and a changed return, while retaining the original source. This package composes those reductions and proves compatibility on Boundary239's actual source.

Relative to `inputs/boundary239_old.tm`, only these retained rows change:

| State/read | Before | After |
|---|---|---|
| 80/0 | 0 R 25 | 0 L 106 |
| 91/1 | 0 L 50 | 1 L 167 |
| 147/0 | 0 R 169 | 0 R 80 |

The two rows of state 169 are deleted. All other retained rows are identical. Disjoint edits alone do not prove that the two reductions compose. The decisive additional premise is that, on the parent blank run and its valid instruction frames, state 169 reading 1 has another 1 immediately to its right. The full guard proof is rerun on the changed source and certifies a constant one-run length of at least 23, where only 2 is needed.

## Proof and verification scope

The ordinary proof is supported by the following reproducible certificates:

| Check | Result |
|---|---|
| Final unbounded runtime | 8,386 guarded cases; 2,255,513 symbolic rules; all 476 rows |
| Parent unbounded runtime and extra guard | 8,386 cases; 2,247,513 symbolic rules; all 478 parent rows |
| Explicit parent state-169/read-1 visits | 32 symbolic visits; minimum one-run constant 23 |
| Four replacement blocks | 22 admissible local tape assignments; exact tape/head/state agreement |
| Predecessor invariants | 121,024 local induction windows |
| Blank startup | 409,835 transitions; exact agreement of sparse, dense, and renumbered simulation |
| Parent/new startup checkpoints | All 409,692 parent checkpoints agree under the positive block clock |

The affine/list runtime proofs quantify over all nine register values, additional gap, the first spare value, and an arbitrary finite remaining spare list. They prove whole-tape endpoints and positive finite instruction durations. They are not finite register samples. The rule cap limits proof construction, not the natural-number parameters.

The direct and guard-transfer routes share the inherited affine/list reasoning core. The separate local checker and the sparse/dense startup interpreters provide complementary, independently written checks; this is not a claim of two independent proof-assistant kernels.

**No new compiled Lean/Rocq endpoint or serialized object-theory ZFC derivation for the 238-state table is included.** The report gives the ordinary proof and executable certificates, with inherited calibration precisely cited. The earlier 240-state table has a documented external Lean endpoint at the inspected repository snapshot; this package does not claim that endpoint already names the new table. No internal PA endpoint, unconditional nonhalting, absolute consistency, minimality, or exhaustive world-record claim is made.

## Reproduce

Python 3.10 or later and its standard library suffice. Keep assertions enabled: do not use `-O`, `-OO`, or `PYTHONOPTIMIZE`. No network access is needed. Use a fresh output directory for each replay.

From the unpacked package root:

```sh
# Exact construction, inherited source replay, local proof, blank startup,
# four equational packets, and independent equation/codec review:
python3 -B reproduce.py --output replay-quick

# The same checks, plus both complete unbounded runtime proofs:
python3 -B reproduce.py --full --output replay-full
```

Full replay takes several minutes on a typical current CPU. Its final status must be `FULL_238_CERTIFICATE_REPLAY_PASS`. The package manifest is checked before work; proof inputs are checked again afterward. The script preserves per-step logs and writes `replay_summary.json`. The direct and guarded runtime certificates are rederived and their complete case arrays compared with the included results.

The original Boundary239 archive is retained verbatim under `vendor/`. Replay extracts it into its output directory, checks its manifest and source interface, replays all source reassociations and the preceding local decoder proof, and then constructs the new table.

To rebuild only the final table and fixed initializer:

```sh
python3 -B build_machine.py --output rebuilt
```

To compile the report with a standard TeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The supplied PDF has already been compiled and visually reviewed. If the PDF is rebuilt before replay, its file digest will differ from the original manifest; replay the original package first or regenerate the manifest for the explicitly modified package.

## Separate 713-bit equational frontend

`foundations/` contains a second research result: a complete eight-equation packet over 12 operation symbols and four variable slots. Including the signature, all arities, all equations, and both ground endpoints, the packet has **713 bits**:

```text
52 header + 9 equation markers + 636 term-tree bits + 16 endpoints = 713
```

The designated target is `N(d,d) = d`. Subject to the explicitly cited ordinary raw-EPSC/ZFC calibration, the report proves in ZFC that its nonderivability is equivalent to Con(ZFC). Bare consistency of universally quantified equations would be insufficient, since every such packet has a one-element model; the separating ground disequality is essential.

The main new quantifier equation uses a selected complemented witness. It changes the constructor to existential negation; the old existential interface must be translated as `Q_old(a) = Q(P(a,a))` and its witness as `W_old(s,a) = W(s,P(a,a))`. The independent member-selector slice remains `W(x,d)`. The complete upper and lower model arguments are included.

| Packet | Equations | Equation term nodes | Complete bits |
|---|---:|---:|---:|
| Inspected baseline | 14 | 215 | 946 |
| Complemented witness | 13 | 208 | 917 |
| Factored closure with flag | 9 | 166 | 745 |
| Factored closure without flag | 8 | 159 | 713 |

The saving is 233 bits against the literally inspected 946-bit baseline. Original baseline bytes are retained in `inputs/E946_original.*` and compared during replay. No exhaustive priority claim is made. This packet has **not** been compiled into an additional binary Turing machine; its bit count is not a state count and contributes no hidden assumption to the 238-state result.

E713 bit-character SHA-256, excluding the final newline:

```text
3cd0c3d0fb8d8640cfef1f44e0c22d377dd930de88a94093a2ef7650e22c9e72
```

## Package map and integration

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf` | Complete research article and printable machine table |
| `sections/`, `tables/` | Included TeX sections and exact canonical table |
| `machines/` | Final table, inherited-label table, source, construction receipt, renumbering |
| `inputs/` | Exact parent tables, source, startup receipt, and inspected E946 baseline |
| `verification/` | Direct unbounded checker, independently written local checker, parent guard driver |
| `evidence/` | Full affine per-case certificates, guard visits, startup and review receipts |
| `foundations/` | Complete equational packets, constructor/codec, independent review, proof text |
| `references/` | Pinned source interfaces, endpoint status, inherited reports and logical reviews |
| `vendor/` | Original Boundary239 archive for offline source/calibration replay |
| `discovery/` | Supplementary bounded search and its explicit limitations |
| `licenses/`, `ATTRIBUTION.md`, `PROVENANCE.json` | Original notices, attribution, and source pins |
| `SHA256SUMS` | Exact package file manifest |

Suggested ProveIt destination: `Computability/BusyBeaver/Research/ZFC/candidate-composed238/`, with the ZIP or intake report under `docs/incoming/`. No remote repository mutation has been made. The construction uses the repository read snapshot `ce192939372ac7944fe2a0208c68a96d49fb5e3b`; the inherited source calibration is pinned separately to `13ec39ed43148b1807f51ed6e6528e1c84659562`.

The next formal integration task is a literal 238-state endpoint importing the already explicit source correspondence, frame invariant, positive block simulation, and state-169 right-neighbor guard. A subsequent optimization can investigate source/decoder improvements or a fully charged binary compiler for the equational frontend.
