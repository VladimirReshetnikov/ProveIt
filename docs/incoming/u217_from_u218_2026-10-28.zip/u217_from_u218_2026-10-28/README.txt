U217 by a single transition redirection
Prepared 28 October 2026

RESULT
217 working states, two symbols, one tape, one head, blank initialization.
The only retained-row edit from primary U218 changes native172/read0's
next state from112 to134. Delete state112. Native halt254; dense halt217.
PA-formalizable halting equivalence follows from one mandatory right-zero
marker and three exact partial-tape path identities. The inherited U218
logical/theory endpoint is an explicit mathematical dependency.
No global minimum, unconditional nonhalting, or new proof-assistant kernel
certificate is claimed.

START HERE
report.pdf and report.tex: proof, conventions, caveats, complete dense table.
machine/u217.tm: literal dense machine.
machine/u217.native.tm: literal native-label machine.
machine/dense_map.json: exact renaming, including halt.

REPLAY
Python3 standard library only:
  python3 checks/replay.py
This runs14 commands, including normal/optimized local checks, negative
controls, independent baseline data/fold audits, and the full5060-case
symbolic primitive-contract replay. It may take several minutes. Do not
run the full driver under-O: inherited symbolic engine assertions must
remain enabled; the wrapper explicitly refuses optimized execution.
Generated receipts are under evidence. Runtime timing/path strings are
not deterministic; mathematical status and pinned inputs are checked.

PDF
Run pdflatex twice on report.tex with a complete TeX Live installation.
build_local.sh also configures the read-only system layout used here.
It uses no shell escape and writes only local build output.

PROVENANCE
baseline/INPUTS.json pins the downloaded source archive set.
baseline/SELECTED_FILES.json identifies64 byte-identical preserved primary
files and all12 omitted files by original path, hash, and size. Large
original traces and redundant U221 ZIP are not shipped. The exact full
U222 archive is retained under baseline/u218/inputs, including its theory
and calibration dependencies. Original upstream code is read-only source
evidence; fresh portable execution uses checks/ instead.
baseline/ORIGINAL_U218_SHA256SUMS and evidence/ORIGINAL_INTAKE_AUDIT.json
record the separate full75-entry intake verification. The compact replay
reconstructs startup directly and does not replay an omitted trace file.
reviews/ records scope and inheritance. Licenses/notices are retained in
baseline/u218/licenses and the original U222 archive.

INTEGRITY
SHA256SUMS binds release files; mutable replay outputs may change paths or
timings when rerun. Verify the manifest before replay. ZIP CRC was tested.
