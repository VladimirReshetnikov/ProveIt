from pathlib import Path
import json,hashlib,sys
P=Path(sys.argv[1]); OLD=Path(sys.argv[2]); OUT=Path(__file__).resolve().parents[1]/'evidence'
def req(x,m):
 if not x:raise ValueError(m)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def table(p):
 d={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,m,r=line.split();k=(int(q),int(b));req(k not in d,'duplicate');d[k]=(int(w),1 if m=='R' else -1,int(r))
 return d
manifest=0 # Original full-archive audit is recorded separately.
T=table(P/'machine/u218.native.tm');D=table(P/'machine/u218.tm');M={int(k):v for k,v in json.loads((P/'machine/state_map.json').read_text())['native_to_dense'].items()};M[254]=218
states={q for q,b in T};req(len(states)==218 and len(T)==436,'count');req(all((q,b) in T for q in states for b in (0,1)),'total');req(all(r in states|{254} for w,m,r in T.values()),'target');req(len(D)==436 and all(D[M[q],b]==(w,m,M[r]) for (q,b),(w,m,r) in T.items()),'dense')
seen={0};todo=[0]
while todo:
 q=todo.pop()
 for b in (0,1):
  r=T[q,b][2]
  if r!=254 and r not in seen:seen.add(r);todo.append(r)
req(seen==states,'reachability')
# Reconstruct initialization directly; no omitted upstream trace is replayed here.
ones=set();q=x=0
for i in range(95726):
 b=int(x in ones);w,m,r=T[q,b];ones.discard(x)
 if w:ones.add(x)
 x+=m;q=r
req((q,x)==(84,-8),'startup endpoint')
phy=(6,2,0,4,3,7,8,5,1);logical=[4]+[0]*8;physical=[0]*9
for i,j in enumerate(phy):physical[j]=logical[i]
row=[0]*65+[1]
for v in physical+[1]*40:row += [0]+[1]*(v+1)
expect={i-8 for i,v in enumerate(row) if v}|{-9};req(ones==expect,'frame')
C=table(Path(__file__).resolve().parents[1]/'machine/u217.native.tm')
childones=set();cq=cx=0;redirect_visits=0
for _ in range(95726):
 cb=int(cx in childones);redirect_visits+=int((cq,cb)==(172,0));cw,cd,cz=C[cq,cb];childones.discard(cx)
 if cw:childones.add(cx)
 cx+=cd;cq=cz
req((cq,cx,childones,redirect_visits)==(84,-8,expect,0),'child initialization')

def tree(rows):
 d={p:(o,a) for p,o,a in rows};req(len(d)==len(rows),'duplicate source')
 def go(p):return d[p] if p in d else (go(p+'0'),go(p+'1'))
 return go('')
def leaf(t):return isinstance(t[0],str)
def count(t):return 1 if leaf(t) else count(t[0])+count(t[1])
def cfg(t):
 out=[]
 def go(t,k,br,co):
  if leaf(t):
   o,a=t;z=(k+1,) if o=='CI' else (br[0],k+1) if o=='CD' else (br[a-1],) if o=='CB' else (co[a-1],) if o=='CC' else ();out.append((o,a if o not in ('CB','CC') else None,z));return
  m=k+count(t[0]);e=m+count(t[1]);go(t[0],k,[e]+br,co);go(t[1],m,br,[k]+co)
 go(t,0,[],[]);return out
base=json.loads((OLD/'inputs/k215_sites.json').read_text());u222=json.loads((OLD/'machine/sites.json').read_text());new=json.loads((P/'machine/sites.json').read_text());bc=cfg(tree(base));uc=cfg(tree(u222));nc=cfg(tree(new));lo,hi=2885,4482;stop=3622
for i,(o,a,es) in enumerate(bc):
 if lo<=i<hi:continue
 def f(k):
  req(not lo<k<hi,'outside enters shell');return k if k<=lo else k-860
 req(nc[f(i)]==(o,a,tuple(f(e) for e in es)),('K215 exterior',i))
for i in list(range(lo))+list(range(stop,len(new))):req(nc[i]==uc[i],('U222 exterior',i))
recipe=json.loads((P/'inputs/source_recipe.json').read_text());word=[]
def flatten(e):
 if isinstance(e,str):word.append(e)
 else:
  req(len(e)==2,'recipe binary');flatten(e[0]);flatten(e[1])
flatten(recipe['replacement']);ranges={'m168':(107,133),'m171':(26,45),'m177':(995,1015),'m119':(78,105),'m180':(78,107),'m181':(695,723),'m218':(995,1042)};expect=[]
for m in word:
 a,b=ranges[m];offset=lo+len(expect)
 for o,r,es in bc[a:b]:
  req(o!='CH' and all(a<=e<=b for e in es),'macro closed');expect.append((o,r,tuple(e-a+offset for e in es)))
req(nc[lo:stop]==expect,'macro CFG')
TOK={'m168':'c','m171':0,'m177':1,'m119':'I','m180':'Q','m181':'R','m218':'N'};s=[]
for m in word:
 t=TOK[m]
 if t in ('c',0,1):s.append(t)
 elif t=='N':s.append(('I',s.pop(),'F'))
 else:
  b=s.pop();a=s.pop();s.append((t,a,b))
c='c';e=('R',1,c);g=('Q',c,('I',('R',c,1),('R',c,0)));u=('Q',1,('I',e,c));lp=('Q',1,('I',c,('I',g,e)));req(s==[('Q',c,('I',u,('I',lp,'F')))],'formula')
unique=set()
def collect(t):
 unique.add(t)
 if not leaf(t):collect(t[0]);collect(t[1])
collect(tree(new));req(len(unique)==202 and len(new)==3891,'metrics')
result={'status':'PASS','manifest_files':manifest,'manifest_scope':'Selected release manifest checked separately; full original intake audit retained as evidence','native_sha256':H(P/'machine/u218.native.tm'),'source_sha256':H(P/'machine/sites.json'),'states':218,'rows':436,'graph_reachable':218,'startup_steps':95726,'child_startup_steps':95726,'child_redirect_visits_in_startup':redirect_visits,'startup_frame':'N=4; other eight registers=0; forty spare runs of length2; gap1; dirty bit at -9','source_leaves':3891,'source_DAG_nodes':202,'unchanged_exterior_primitives':3154,'rewritten_shell_primitives':737,'closed_macro_instances':len(word),'scope':'Independent data, literal transitions, dense conjugacy, direct 95726-step startup reconstruction, source CFG and symbolic formula. Not a formal proof of inherited Con(U) endpoint.'}
OUT.mkdir(exist_ok=True);(OUT/'DATA_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
