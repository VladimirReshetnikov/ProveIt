"""Negative controls for the local path proof, independent of hash rejection."""
from pathlib import Path
import json
from certify_u217 import read,run
R=Path(__file__).resolve().parents[1];A=read(R/'baseline/u218/machine/u218.native.tm');B=read(R/'machine/u217.native.tm')
cases=[({0:0,1:0},1,3),({0:1,1:0,2:0},5,3),({0:1,1:0,2:1},5,3)]
def good(t):
 try:return all(run(A,112,c,n)[:3]==run(t,134,c,m)[:3] for c,n,m in cases)
 except (ValueError,KeyError):return False
def need(v,m):
 if not v:raise ValueError(m)
need(good(B),'baseline')
used=set()
for cells,n,m in cases:
 q=134;h=0;t=dict(cells)
 for _ in range(m):
  used.add((q,t[h]));w,d,z=B[q,t[h]];t[h]=w;h+=d;q=z
rejected=0
for row in sorted(used):
 w,d,z=B[row]
 for alt in [(1-w,d,z),(w,-d,z),(w,d,254)]:
  C=dict(B);C[row]=alt;need(not good(C),('accepted bad path',row,alt));rejected+=1
# Guard cannot be dropped: a concrete right-one tape fails the claimed zero case.
try:unguarded_equal=run(A,112,{0:0,1:1,2:0},1)[:3]==run(B,134,{0:0,1:1,2:0},3)[:3]
except (ValueError,KeyError):unguarded_equal=False
need(not unguarded_equal,'guard not essential')
out={'status':'PASS','mutations_rejected':rejected,'distinct_path_rows':len(used),'unguarded_counterexample_rejected':True,'scope':'Negative path controls only; universal theorem is the separate marker proof.'}
(R/'evidence/PATH_NEGATIVE_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
