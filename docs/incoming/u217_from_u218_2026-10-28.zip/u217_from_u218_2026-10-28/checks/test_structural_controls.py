"""Mutation tests of hash-independent structural premises of the reduction."""
from pathlib import Path
import json
from certify_u217 import read,run
R=Path(__file__).resolve().parents[1];A=read(R/'baseline/u218/machine/u218.native.tm');B=read(R/'machine/u217.native.tm');M={int(k):v for k,v in json.loads((R/'machine/dense_map.json').read_text()).items()}
def need(v,m):
 if not v:raise ValueError(m)
def verify(a,b,m):
 for t in(a,b):
  Q={q for q,x in t};need(0 in Q and 254 not in Q,'start/halt');need(set(t)=={(q,x)for q in Q for x in (0,1)},'totality');need(all(z in Q|{254}for w,d,z in t.values()),'closure')
 need([(q,x,w,d)for(q,x),(w,d,z)in a.items()if z==112]==[(172,0,0,-1)],'marker')
 phi=lambda q:134 if q==112 else q
 need({q for q,x in b}=={q for q,x in a}-{112},'state set')
 for(q,x),(w,d,z)in a.items():
  if q!=112:need(b[phi(q),x]==(w,d,phi(z)),'ordinary rows')
 for c,n,z,h in [({0:0,1:0},1,157,1),({0:1,1:0,2:0},5,90,3),({0:1,1:0,2:1},5,86,3)]:
  need(run(a,112,c,n)[:3]==run(b,134,c,3)[:3]==(z,h,c),'paths')
 Q={q for q,x in b};need(set(m)==Q|{254}and set(m.values())==set(range(218))and len(m)==len(set(m.values())),'bijection');need(m[0]==0 and m[254]==217,'start/halt map')
verify(A,B,M)
mutants=[]
def put(name,side,key,value):
 a,b,m=dict(A),dict(B),dict(M);t=a if side=='parent'else b;t[key]=value;mutants.append((name,a,b,m))
put('extra incoming112','parent',(0,0),(0,1,112));put('wrong marker write','parent',(172,0),(1,-1,112));put('wrong marker direction','parent',(172,0),(0,1,112));put('wrong redirect','child',(172,0),(0,-1,157));put('dangling target','child',(0,0),(0,1,999));put('bad local path','child',(134,0),(0,1,90))
a,b,m=dict(A),dict(B),dict(M);del b[134,0];mutants.append(('missing row',a,b,m))
a,b,m=dict(A),dict(B),dict(M);m[254]=216;mutants.append(('halt collision',a,b,m))
a,b,m=dict(A),dict(B),dict(M);m[0],m[254]=m[254],m[0];mutants.append(('start halt swap',a,b,m))
a,b,m=dict(A),dict(B),dict(M);del m[134];mutants.append(('missing dense label',a,b,m))
a,b,m=dict(A),dict(B),dict(M);b[254,0]=(0,1,254);b[254,1]=(1,1,254);mutants.append(('halt made working',a,b,m))
rejected=[]
for name,a,b,m in mutants:
 try:verify(a,b,m)
 except(ValueError,KeyError):rejected.append(name);continue
 raise ValueError('accepted '+name)
out={'status':'PASS','mutations_rejected':len(rejected),'controls':rejected,'hash_independent':True};(R/'evidence/STRUCTURAL_NEGATIVE_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
