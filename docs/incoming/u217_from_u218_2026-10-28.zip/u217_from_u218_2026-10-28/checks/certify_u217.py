"""Independent one-row U218 to U217 marker certificate, standard library only.
The proof applies to all initial tapes in state0, not bounded simulations.
"""
from pathlib import Path
from collections import deque
import argparse,json,hashlib
R=Path(__file__).resolve().parent
P=R.parent/'baseline/u218/machine/u218.native.tm'
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 T={};start=[]
 for l in p.read_text().splitlines():
  if l.startswith('#! start '):start.append(int(l[9:]));continue
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));need(d in('L','R')and b in(0,1)and w in(0,1),'syntax');need((q,b)not in T,'duplicate');T[q,b]=w,1 if d=='R'else-1,z
 need(start==[0],'start');Q={q for q,b in T};need(set(T)=={(q,b)for q in Q for b in(0,1)},'totality');need(0 in Q and 254 not in Q and{z for w,d,z in T.values()}-Q=={254},'targetclosure');return T

def encode(T):return '#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))
def run(T,q,cells,n):
 h=0;cells=dict(cells);trace=[]
 for i in range(n):
  need(q!=254 and h in cells,'interior halt or unknown read');b=cells[h];w,d,z=T[q,b];need(w==b,'local bit changed');cells[h]=w;h+=d;q=z;trace.append([q,h,dict(cells)])
 return q,h,cells,trace

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--parent',type=Path,default=P);ap.add_argument('--output',type=Path,default=R.parent/'evidence/u217_certificate');ap.add_argument('--windows',action='store_true');a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 need(sha(a.parent)=='366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30','parent identity');A=read(a.parent);need(len(A)==436,'parent census')
 incoming={(q,b)for(q,b),(w,d,z)in A.items()if z==112};need(incoming=={(172,0)}and A[172,0]==(0,-1,112),'marker invariant');need(0!=112,'initial marker')
 B={k:v for k,v in A.items()if k[0]!=112};B[172,0]=(0,-1,134);phi=lambda q:134 if q==112 else q
 need(len(B)==434,'child census');need(all(z!=112 for w,d,z in B.values()),'removed no incoming')
 ordinary=0
 for(q,b),(w,d,z)in A.items():
  if q==112:continue
  need(B[phi(q),b]==(w,d,phi(z)),f'ordinary commutation{q,b}');ordinary+=1
 cases=[({0:0,1:0},1,3,157,1),({0:1,1:0,2:0},5,3,90,3),({0:1,1:0,2:1},5,3,86,3)];records=[]
 for cells,oldn,newn,z,h in cases:
  old=run(A,112,cells,oldn);new=run(B,134,cells,newn);need(old[:3]==new[:3]==(z,h,cells),'path endpoint');records.append(dict(cells=cells,parent_steps=oldn,child_steps=newn,end_state=z,head_delta=h,parent_trace=old[3],child_trace=new[3]))
 need(phi(0)==0 and phi(254)==254 and all(phi(q)!=254 for q,b in A),'halting singleton')
 native=a.output/'u217.native.tm';native.write_text(encode(B));need(sha(native)=='fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f','child identity');read(native)
 Q=sorted({q for q,b in B});todo=[0];seen={0}
 for q in todo:
  for b in(0,1):
   z=B[q,b][2]
   if z!=254 and z not in seen:seen.add(z);todo.append(z)
 need(seen==set(Q),'graph census')
 m={q:i for i,q in enumerate(Q)};m[254]=217;need(m[0]==0 and len(set(m.values()))==218,'bijection')
 D={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in B.items()};dense=a.output/'u217.tm';dense.write_text(encode(D));need(sha(dense)=='639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6','dense identity')
 (a.output/'dense_map.json').write_text(json.dumps(m,indent=2)+'\n');(a.output/'local_traces.json').write_text(json.dumps(records,indent=2)+'\n')
 result=dict(status='ALL_INITIAL_TAPES_MARKER_STUTTER_PASS',parent_sha256=sha(a.parent),native_sha256=sha(native),dense_sha256=sha(dense),parent_states=218,child_states=217,edited_rows=[[172,0,0,-1,134]],deleted_states=[112],ordinary_commuting_rows=ordinary,partial_tape_cases=3,parent_durations=[1,5],child_durations=[1,3],max_parent_steps=5,max_child_steps=3,scope='PA-provable positive bounded stuttering on every tape initially in state0; no additional source assumptions and no speedup claim')
 if a.windows:
  W=11;K=5;mask=(1<<W)-1;reach={(0,x)for x in range(mask+1)};todo=deque(sorted(reach))
  while todo:
   q,x=todo.popleft()
   if q==254:continue
   w,d,z=A[q,(x>>K)&1];y=(x&~(1<<K))|(w<<K)
   for b in(0,1):
    v=(y>>1)|(b<<(W-1))if d==1 else((y<<1)&mask)|b
    if(z,v)not in reach:reach.add((z,v));todo.append((z,v))
  nontrivial=ordinary_windows=halt=0
  for q,x in sorted(reach):
   if q==254:halt+=1;continue
   if q!=112:ordinary_windows+=1;continue
   cells={i-K:(x>>i)&1 for i in range(W)};need(cells[1]==0,'closure violates marker');n=1 if cells[0]==0 else 5
   old=run(A,q,cells,n);new=run(B,phi(q),cells,3);need(old[:3]==new[:3],'window endpoint');nontrivial+=1
  result.update(window_width=W,window_closure=len(reach),window_halt=halt,ordinary_windows=ordinary_windows,nontrivial_windows=nontrivial)
 (a.output/'certificate.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
