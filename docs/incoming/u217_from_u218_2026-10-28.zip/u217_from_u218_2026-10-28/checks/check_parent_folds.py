from pathlib import Path
import json,sys,hashlib
P=Path(sys.argv[1]);OUT=Path(__file__).resolve().parents[1]/'evidence'
def req(c,m):
 if not c:raise ValueError(m)
def table(p):
 d={}
 for l in p.read_text().splitlines():
  if l and not l.startswith('#'):
   q,b,w,m,r=l.split();d[int(q),int(b)]=(int(w),1 if m=='R' else -1,int(r))
 return d
A=table(P/'inputs/repaired220.native.tm');B=table(P/'inputs/untagged219.native.tm');C=table(P/'machine/u218.native.tm')
def incoming(t,z):return sorted((q,b,w,d) for (q,b),(w,d,r) in t.items() if r==z)
req(incoming(A,112)==[(172,0,0,-1)],'112 marker');req(incoming(A,200)==[(112,1,1,1)],'200 marker');req(A[200,0]==A[209,0], 'zero behavior')
expect={k:v for k,v in A.items() if k[0]!=200};w,d,r=expect[112,1];expect[112,1]=(w,d,209);req(expect==B,'zero literal delta')
req(incoming(B,182)==[(173,1,1,1)],'tag one');req(incoming(B,507)==[(18,0,0,1),(134,0,0,1),(188,0,0,1)],'tag zero')
expect={k:(w,d,182 if r==507 else r) for k,(w,d,r) in B.items() if k[0]!=507};expect[182,0]=(0,-1,209);req(expect==C,'tag literal delta')
def run(t,q,tape,n):
 tape=dict(tape);h=0;trace=[]
 for _ in range(n):
  req(h in tape and q!=254,'unknown read/interior halt');v=tape[h];w,d,r=t[q,v];trace.append([q,h,v,w,d,r]);tape[h]=w;h+=d;q=r
 return (q,h,tape),trace
cases=[]
for q,tag in [(182,1),(507,0)]:
 for bit in [0,1]:
  tape={-1:tag,0:bit};n=1 if bit else (3 if tag else 5)
  a,ta=run(B,q,tape,1);b,tb=run(C,182,tape,n);req(a==b,'tag endpoint');cases.append(dict(parent_state=q,tag=tag,bit=bit,parent_trace=ta,child_trace=tb))
out={'status':'PASS','zero_fold':'one mandatory right-zero marker; all initial tapes state0; same-step simulation','tag_fold':'one mandatory left-tag marker per entry; four exact partial-tape paths; bounded positive stuttering','cases':cases,'scope':'Independent verification of literal U220->U219->U218 guarded reductions. Source generation and routing repair remain separate obligations.'};(OUT/'PARENT_FOLDS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='cases'},indent=2))
