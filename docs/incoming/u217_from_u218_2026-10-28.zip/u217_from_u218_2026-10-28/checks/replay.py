"""Portable offline replay. Full runtime check requires ordinary Python."""
from pathlib import Path
import sys,subprocess,json,time,hashlib,os
R=Path(__file__).resolve().parents[1];os.chdir(R)
if not __debug__ or sys.flags.optimize:raise RuntimeError('Run replay.py without -O; it tests safe optimized subcommands separately.')
steps=[['checks/check_artifact.py'],['checks/certify_u217.py','--windows'],['checks/verify_u217_independent.py'],['checks/test_local_paths.py'],['checks/test_structural_controls.py'],['-O','checks/certify_u217.py','--windows'],['-O','checks/verify_u217_independent.py'],['-O','checks/test_local_paths.py'],['-O','checks/test_structural_controls.py'],['checks/check_baseline_data.py','baseline/u218','baseline/u222'],['checks/check_parent_folds.py','baseline/u218'],['-O','checks/check_baseline_data.py','baseline/u218','baseline/u222'],['-O','checks/check_parent_folds.py','baseline/u218'],['checks/check_baseline_runtime.py','baseline/u218']]
records=[]
for cmd in steps:
 start=time.monotonic();p=subprocess.run([sys.executable]+cmd,text=True,capture_output=True)
 records.append({'command':[sys.executable]+cmd,'exit':p.returncode,'seconds':round(time.monotonic()-start,3),'stdout':p.stdout,'stderr':p.stderr})
 print('PASS'if p.returncode==0 else'FAIL',' '.join(cmd),flush=True)
 if p.returncode:print(p.stdout,p.stderr);break
status='PASS'if len(records)==len(steps)and all(x['exit']==0 for x in records)else'FAIL'
(R/'evidence/REPLAY.json').write_text(json.dumps({'status':status,'steps':records},indent=2)+'\n')
if status!='PASS':raise RuntimeError('Replay failed')
