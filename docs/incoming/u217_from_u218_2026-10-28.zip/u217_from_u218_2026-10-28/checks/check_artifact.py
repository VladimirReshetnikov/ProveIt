"""Check preserved source selection, literal appendix, dense map and ZIP CRC."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((R/'baseline/SELECTED_FILES.json').read_text())
for row in v['files']:
 p=R/row['bundled_path'];need(p.stat().st_size==row['bytes']and sha(p)==row['sha256'],('selected source',p))
p=R/'baseline/u218/inputs/U222_ConU_2026-10-28.zip'
need(sha(p)=='d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652','U222 identity')
with zipfile.ZipFile(p)as z:need(z.testzip()is None,'U222 crc')
T={}
for l in (R/'machine/u217.tm').read_text().splitlines():
 if not l or l.startswith('#'):continue
 q,b,w,d,z=l.split();T[int(q),int(b)]=w+d+('H'if z=='217'else z)
text=(R/'transition_table.tex').read_text();checked=0
for i in range(109):
 j=i+109;s=f'{i} & {T[i,0]} & {T[i,1]}'
 s+=f' & {j} & {T[j,0]} & {T[j,1]}'if j<217 else' & & &'
 need(s+'\\\\'in text,('appendix',i));checked+=1
print(json.dumps({'status':'PASS','selected_original_files':len(v['files']),'omitted_original_files':len(v['omitted_files']),'appendix_rows':checked,'U222_archive_crc':'PASS'}))
