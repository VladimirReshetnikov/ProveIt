"""Independent literal U218 to U217 certificate, using one marker and three paths."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
P=R/'baseline/u218/machine/u218.native.tm'
C=R/'machine/u217.native.tm'
def need(c,msg):
 if not c:raise ValueError(msg)
def read(p,sha):
 need(hashlib.sha256(p.read_bytes()).hexdigest()==sha,'identity')
 lines=p.read_text().splitlines();need(lines[0]=='#! start 0','start');t={}
 for l in lines:
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));need(d in ['L','R'] and b in [0,1] and w in [0,1],'syntax');need((q,b)not in t,'duplicate');t[q,b]=(w,-1 if d=='L' else 1,z)
 s={q for q,b in t};need(set(t)=={(q,b)for q in s for b in [0,1]},'total');need(254 not in s and all(z in s|{254}for w,d,z in t.values()),'targets');return t,s
A,SA=read(P,'366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30')
B,SB=read(C,'fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f')
need(len(SA)==218 and len(SB)==217 and SB==SA-{112},'states')
need([(q,b,w,d)for(q,b),(w,d,z)in A.items()if z==112]==[(172,0,0,-1)],'unique incoming marker')
phi=lambda q:134 if q==112 else q
for(q,b),(w,d,z)in A.items():
 if q!=112:need(B[phi(q),b]==(w,d,phi(z)),'ordinary commutation')
def run(t,q,cells,n):
 h=0;v=dict(cells);trace=[]
 for _ in range(n):
  need(q!=254 and h in v,'halt or unknown read');w,d,z=t[q,v[h]];trace.append([q,h,v[h],w,d,z]);v[h]=w;q=z;h+=d
 return q,h,v,trace
cases=[({0:0,1:0},1,3,157,1),({0:1,1:0,2:0},5,3,90,3),({0:1,1:0,2:1},5,3,86,3)]
logs=[]
for cells,n,m,z,h in cases:
 a=run(A,112,cells,n);b=run(B,134,cells,m);need(a[:3]==b[:3]==(z,h,cells),'endpoint');logs.append(dict(cells=cells,parent_steps=n,child_steps=m,parent_trace=a[3],child_trace=b[3]))
out=dict(status='PASS',parent_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),child_sha256=hashlib.sha256(C.read_bytes()).hexdigest(),working_states=217,ordinary_rows_checked=434,marker_invariants=1,partial_tape_cases=3,scope='All tapes initially in state0; positive bounded stuttering, no finite-run extrapolation',cases=logs)
(R/'evidence/U217_INDEPENDENT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='cases'},indent=2))
