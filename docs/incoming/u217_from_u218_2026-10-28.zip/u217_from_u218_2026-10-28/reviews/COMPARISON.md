# Comparison of pinned U218 intake

Reviewed at repository commit `1dd14d95976856bfabe06ab7294e78508556e0d1`. This is a source/report/table review, not execution or independent certification of supplied code. Native numeric labels are allocator-dependent and cannot be carried between source layouts without checking literal rows.

## Packet ledger

| Packet | Main mechanism | Relation to U218 |
|---|---|---|
| U218_ConPA_2026-10-28 | Reorders two implication antecedent pairs in the U emitter; 202 distinct subtrees, 3891 primitive occurrences. Repairs four wrong arithmetic contexts using state507, then folds200→209 and507→182. | Primary baseline,218states. |
| U219_ConPA_Reduction_2026-10-28 | Same original U222 formula; emitter reparenthesization plus closed rotation gives203subtrees. Compact221 parent;200→112;215→182 via helper209. | Helper209 mechanism already represented in U218's507→182 fold. Different allocation, so its215 is not U218's215. |
| U219_From_Primary_U222_2026-10-28 | Same original formula; six decoder-DAG rotations at eight unfolded occurrences, followed by134→145,215→216,200→209. | Source rotations could inspire a new search, but literal patches do not transfer. Its216/215 helper154 uses old rows not the current ones. |
| U220_ConPA_Reduction_2026-10-28 (without suffix) |200 zero fold and one closed rotation with factor sizes19,28,56, enabling134/145 tag fold through507. | U218's134 and145 do not have a common branch and507 has already been removed. |
| U220_ConPA_Reduction_2026-10-28 (1) | Same two formula exchanges as U218;202subtrees; context-correct221allocation plus200→112. | U218 already improves this route through a different repaired220allocation and tagfold. |
| U221_ConPA_2026-10-28 |200→209, exact step quotient via knownzero. | Already applied. |
| U221_ConU_2026-10-28 |200→112 exact step quotient; supplemental uncompiled203source search. | Already applied in equivalent200→209 form; no extra saving. |
| u220_from_u222_2026-10-28 | Literal503→112 marker fold, rendering200unreachable. | Not same503role in U218. Cannot compose by label. |

## Exact primary baseline

`machine/u218.native.tm` SHA256 `366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30`.
Dense SHA256 `225709a399367b5b1683ec0dc35994929184e4c9c1dcd638771a8a5c3efda953`.
Source SHA256 `bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f`.

Primary preserves195/0→150 for135 internal decoder occurrences. Only18/0,134/0,188/0 were redirected through507, covering arithmetic sites3004,3232,3305,3435. The final507→182 fold uses lefttag0 for those entries and lefttag1 from173/1. This is important: treating every occurrence of150 as an arithmetic entry is incorrect.

## Why the prior own U220 patch cannot transfer

U218's503 is `(0,R,171)/(1,R,201)`, incoming501/0. The old own-U220 proof required503=`(0,R,90)/(1,R,174)`, incoming156/0. U218156 is now111/26,174is188/158,and504is absent. Therefore neither the three marker invariants nor the five displayed path matches apply to the corresponding labels. The idea remains useful, not the old patch.

## Negative scan result and a necessary implementation safeguard

`tag_scan.py` reads the table as data and searches pairs with a common branch and opposite uniform preceding written bits. It finds three superficially matching three-step helpers:8/127via110,44/105via90,52/176via193. **None is a valid fold**: each helper enters at least one modified/deleted state, yielding circular dispatch after the patch. `direct_tag_scan.json` is deliberately retained as a rejected candidate list, not accepted reductions.

`helper_scan.py` independently executes each proposed helper in its actually patched table, refusing to read beyond the known two-cell patch and checking exact final tape/head/state. With a40-step cap it finds no valid two-cell helper among all opposite-tag/common-branch pairs. This bounded search establishes only absence in this explicitly limited family, not impossibility of longer or wider-context reductions. `helper_scan.json` is empty.

## Most promising transferable direction

Search closed decoder rotations in the *current*202-subtree source to create a common child and opposite predecessor tags, then exploit an existing non-circular selector. Keep the ordered primitive program and CFG fixed; re-audit physical arithmetic entry contexts, including150and152, and zero-run bound6. The prior six-rotation packet supplies examples, not a verified new U218 patch. A purely local reachable-window quotient is preferable if found, because it avoids new source-compilation obligations.

## Earlier K215 families inspected locally

The selected README/report sources under `research214_upstream/K215_Composed_Selector`, `K215_Composed_Selectors_2026-10-20`, `K215_Composed_Commands_Selector_2026-10-20`, and `K215_Construction_and_Research_2026-10-21` explain a common composition: partial-selector source reassociation and164/183 markerfold, command-specific counter input readers, command-tag permutation, and state81 helper repair; the second69/400 markerfold survives. Their physical allocations differ (one retires224, another185). U218already lacks183,400,and224, with164/0=0L201 and69/0=0L213 retaining the two marker-selector patterns. These are inherited savings, not new removable states. U218's state185 is an allocated decoder role, so the other packet's retired185 cannot simply be deleted.

`K215_Alternative_Encodings_2026-10-21` changes physical encoding/bootstrap (716307startupsteps and a nonzero additive-counter seed), and supplies an alternative rho6 sampler; it does not itself reduce below215. Transferring its changed seed requires its cofinal calibration, not merely borrowing a literal startup trace. The useful design lessons are joint allocation rather than union of patches, preserving generic trailing-one clearing through302instead of context-limited40, and checking exact arithmetic entry contexts after every source rewrite.
