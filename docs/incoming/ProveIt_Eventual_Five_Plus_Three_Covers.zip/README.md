# Eventual Scaling for Five Plus Three Covers

The eight-page report proves eventual strict actual-rank ULC8 for every genuine 5+3 minimum cover under common scaling of the three right-cover activities. All left activities are one; fixed right activities are arbitrary and positive. The new conditional factors are 77/48, strict 7/4, and 55/24. The only unresolved rank-eight cover split is 4+4. No general finite-activity theorem is claimed.

Contents:
- Eventual_Scaling_for_Five_Plus_Three_Covers.pdf: final report
- article.tex and build_local.sh: editable source and local TeX build helper
- code/ and data/: portable exact checkers and recorded summaries
- companion/: the sealed rank-seven report and complete source archive, unchanged; that archive includes the earlier structural and small-cover prerequisites
- manifest.json: SHA256 checksums of all packaged files

Run all exact checks with Python 3 using only its standard library:

    python -O code/replay_all.py

The 882 mask profiles and five polynomial identities verify the complete finite component of the incidence proof. The 64 graph tests and 13,056 binary configurations are supplementary regressions, not population bounds or substitutes for the universal proofs.

To rebuild the PDF where the required TeX packages are available, run:

    bash build_local.sh

The source compiles with pdfLaTeX and standard AMS, Latin Modern, geometry, microtype and hyperref packages. The local helper writes its generated format files within this directory.
