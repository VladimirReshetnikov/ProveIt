# Quadratic Diophantine Dynamics
## Recurrence, computable schedules, and the limits of finite certificates

Research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.

## Contents

- `article.pdf`: compiled mathematical article.
- `article.tex`: standalone LaTeX source, with an internal bibliography.
- `code/quadratic_compiler.py`: exact, standard-library-only compiler from a
  finite natural-counter network to one degree-two integer polynomial.
- `code/verify.py`: executed finite tests, including an independent direct
  successor function, factored evaluator, sparse polynomial evaluator, and
  malformed-target mutations.
- `examples/finite_visits.json`: a three-control, one-counter network with
  arbitrarily many finite marked visits but no recurrent infinite path.
- `examples/finite_visits_polynomial.json`: its full 44-monomial polynomial.
- `examples/height_eight.json` and `height_eight_polynomial.json`: the sharp
  coefficient-eight example for this compiler.
- `examples/sample_runs.json`: reproducible finite paths in the first example.
- `verification/report.json`: actual executed test counts and scope.
- `PROOF_AUDIT.md`: dependencies, semantic pitfalls, novelty limits, and status.
- `SOURCES.md`: repository snapshot and external-source provenance.
- `Makefile`: build and verification commands.

## Main results developed in the article

The local compiler uses state dimension q+r+m and no existential transition
auxiliaries. Its polynomial has degree two, expanded coefficient height at
most eight, and a linear-size factored circuit. It preserves the edge table's
global branching bound. The old edge tag is deliberately ignored; the next
tag is the canonical tag of the selected labelled edge.

An affine lower obstruction shows degree two is minimal for analytic-complete
recurrence under the stated one-equation, whole-natural-state-space,
no-existential-auxiliaries, uniformly bounded-branching model.

For a fixed universal quadratic system, unrestricted recurrent-path existence
is Sigma^1_1-complete. Existence of some total computable return-time bound,
and existence of a computable recurrent path, are both Sigma^0_3-complete,
but the latter property is strictly stronger. Explicit recursive trees give
both strict inclusions CP < CB < Rec. The article also supplies a deadline
compactness theorem, a faithful-simulation transport theorem, a weak-fairness
reduction, and finite-certificate obstructions.

## Status and limitations

This is an AI-assisted research manuscript with conventional proofs and exact
finite implementation checks. It has not been independently refereed or
formalized in Lean/Rocq. Historical recurrence and fairness undecidability are
not claimed as new. Literature-wide priority for the exact combination of
normal form, quantitative bounds, and separations is not established. No
named published open problem is claimed solved.

The fixed universal polynomial is established by an effective interpreter
construction, but the complete universal interpreter edge table is NOT
numerically instantiated in this package. No numerical universal state
dimension or expanded universal polynomial is claimed. Every polynomial for
the supplied finite edge tables IS instantiated exactly.

The tests do not prove the infinite-path or hierarchy theorems. They test the
finite compiler and examples. No assertion of finite-fold or single-fold
MRDP follows from the canonical local edge tag.

## Reproduce

Python 3.10 or later, no third-party Python dependencies:

```sh
python code/verify.py
python code/quadratic_compiler.py examples/finite_visits.json \
  --output examples/finite_visits_polynomial.json
```

PDF build (a standard TeX Live installation with pdfLaTeX and latexmk):

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `make verify` and `make pdf`.

## Coordinate and polynomial format

State order: one-hot control coordinates, natural counters, previous-edge tag.
The full polynomial variable list is the source state followed by the target
state. A JSON monomial is a sorted list of variable indices. An empty list
means the constant 1; an index repeated twice means a square. The listed
coefficient multiplies that monomial. All coordinates are nonnegative
integers. Negative coefficients are allowed. Source tag variables have zero
coefficient everywhere, by design.

The code treats distinct edge labels as distinct choices, even when their
operations and endpoints coincide. The next-state tag ensures these choices
have distinct target tuples, so no hidden existential multiplicity is being
counted as graph branching.
