# Fixed Fourier sectors for the powered Catalan numbers

This package accompanies the ten-page addendum for OEIS A113227, dated 1 October 2026. The companion fourteen-page core report is included because the extension uses its independently audited positive Bessel spectrum and real all-orders coefficient algorithm.

## Main result

For every fixed J, the exact powered-Catalan count is the sum of the first J+1 exact cutoff-defined Fourier sectors, with a remainder bounded by the next complex-saddle envelope. Spectral replacement has the smaller relative error O(exp(−d n)) for every d<log 2. Each fixed exact sector has an all-orders algebraic expansion with the same rational coefficients as the real saddle.

The proof includes a zero-free complex wedge for the exact Bessel weight, a global spectral replacement bound, half-integer endpoint cancellation, a common-contour bound for infinitely many omitted Fourier modes, and uniform fixed-order saddle remainders.

## Read first

- powered-catalan-fourier-addendum.pdf: full new theorem and proof
- powered-catalan-fourier-addendum.tex: editable source
- mathematical-verification.md: scope and findings of mathematical cross-review
- VALIDATION.md: numerical and document checks
- core-report.pdf and core-report.tex: companion positive-spectrum and algebraic report
- core-mathematical-verification.md: independent review of the core theorem

## Reproduce

Requirements: Python 3.10 or later, mpmath, SymPy, and a standard pdfLaTeX installation with the packages used by the TeX source. Tested Python package versions are in requirements.txt.

From this directory:

    python -m pip install -r requirements.txt
    bash run_checks.sh

This reproduces the exact symbolic coefficients, complex Bessel diagnostics, quadrature refinement comparison, exact-recurrence/lattice comparison, and addendum PDF. Outputs use paths relative to this package. To rebuild only the PDF, run:

    bash build.sh

The build uses a fixed source date. It is byte-identical on the tested toolchain; other TeX versions may change PDF bytes without changing mathematical content. Check the release files before and after replay with:

    sha256sum -c SHA256SUMS

## Programs

- residue_expansion.py: exact reciprocal-product and Stirling coefficient generator
- saddle_expansion.py: exact Gaussian-moment extraction through c_4
- verify_fourier_sectors.py: exact-Bessel central saddle integrals at 70 digits, using 160-point quadrature; also checks the complex weight on nine points
- verify_fourier_sectors.py --order 192: independently refined quadrature of the same seven cases
- verify_output_consistency.py: requires agreement of all displayed 26-digit integral ratios
- verify_exponential_spectral_replacement.py: exact recurrence counts at n=80,160,320 versus an exact-Bessel lattice sum at 180 digits

## Important limitations

The numerical results are diagnostics, not interval certificates. The central numerical saddle segments are not labeled exact evaluations of the entire window-defined sectors. Fixed-order asymptotic estimates prove error scales, without explicit finite-target constants.

The number of sectors J and algebraic order are fixed. No growing-J uniformity, infinite asymptotic sector summation, convergence of the correction series, canonical Borel summation, or exponential inverse theorem is asserted. In particular, a finite algebraic approximation to the principal sector still has an error larger than every fixed nonzero Fourier sector.

The standard Poisson, Gaussian saddle, and Lambert-W methods are credited. No exhaustive priority claim is made. Conventional expert peer review remains appropriate before publication. No external submission or upload is part of this package.
