# Report 19 — Exact lazy finite-support evaluation

The evaluator computes the **same frozen ordered reversible binary CA** on every finite binary support, including malformed configurations, without constructing its full factor array. The pinned universal source has 269,291,358,255 factors. Correctness comes from complete raw-shape candidates, exact simultaneous factor application, strict factor order, and rediscovery after every change.

Runtime is source-, support-, and cascade-sensitive. No uniform constant-time, polynomial-in-log-factor-count, or polynomial-in-log-class-cutoff claim is made. The 128 universal CA microsteps are literal global calls with reverse checks and explicit expected-output geometry; they do not finish startup or a Turing transition. A further 128 deterministic malformed endpoint/noise cases are evaluated. This is not a new universality proof or a claim of novelty.

## Read

- `report19.pdf` — complete mathematical report
- `report19.tex` — editable LaTeX
- `reproducibility/PROOF.md` — implementation proof
- `reproducibility/audit-design.md` and `audit-addendum.md` — separate audit
- `reproducibility/reference/` — frozen compiler proof/schema and background Reports 15 and 17

## Offline verification and replay

Full replay requirements: Python 3.12 or later on Linux, standard library only. Tested environment: Python 3.12.14 on Linux. The core evaluator is platform-independent Python; the preserved benchmark uses the Unix `resource` module and Linux KiB RSS units. No installs, internet, previous report directories, or other sibling files are required. Run from this extracted directory:

    python3 verify_release.py
    python3 release_checks.py
    python3 replay.py --out replay-output

The output directory must not already exist. Inside the extracted release, only the documented `replay-output/` location is accepted; another output path must be outside the release. Verification rejects unmanifested files/directories outside `.build/` and `replay-output/`, and rejects symlinks throughout the release tree. Replay first checks the release manifest, then expands the exact pinned source in fresh normal/optimized working directories, verifies its SHA-256, and runs all six scripts in both modes:

1. `test_lazy.py`: complete eager comparisons on small sources
2. `audit_checks.py`: independently written comparison suite
3. `addendum_checks.py`: displacement, multi-one context, source-schema and class-cutoff checks
4. `package_checks.py`: exact public API, nested immutability, dependency pin, and independent source count
5. `benchmark_universal.py`: 128 literal startup steps and 128 malformed cases, with reverses
6. `check_startup_geometry.py`: all 128 startup outputs against explicit expected geometry

Replay requires roughly several hundred MiB of memory. Wall time depends on the machine and load; no timing threshold is a pass condition. Expanded source copies are deleted after each successful mode. Logs, trace JSON, receipts, and staged scripts remain in the output directory. Source expansion alone is 32,034,272 bytes. The delivered compressed source is about 1.53 MiB.

The replay compares deterministic counts with producer receipts and exact trace bytes with the supplied universal traces. It keeps original evidence unchanged. `reproducibility/evidence/` contains byte-preserved producer logs/receipts and their original manifest, whose original benchmark hash precedes the documented path adaptation. `reproducibility/portable-replay/` contains fresh extracted replay evidence. Refer to the top-level release manifest for the delivered tree.

## API

`compile_lazy_source(data)` validates the original exact-type source schema. Returned metadata and source snapshots are immutable. `step` accepts only an exact `set` or `frozenset` of exact Python integers; negative or enormous coordinates are valid, while booleans, floats, subclasses, and arbitrary iterables are rejected. `inverse`, `verify`, and `trace` require exact Booleans. The result is a frozenset; tracing adds an immutable statistics mapping. `gate_at(i)` constructs one exact factor; `candidate_indices(X)` exposes a current candidate superset. No encoded-state recognition is assumed.

## Integrity and adaptation

- Evaluator: `42e8aa65c05fcf373a03a02be51ebb89a4fdcb1f1070ad776ffe1e8e99049c61`
- Frozen compiler: `f95a6028c9d3cc6f8b0b497cfc0cad68104da6d70e55205df04ad234e5d0c76f`
- Exact uncompressed source: `fa61d06178d718511232a80a05e02192d940fde3c273f0c202f0623253b2ade3`

The evaluator and compiler are byte-preserved. The evaluator checks the compiler bytes before executing them. Source gzip compression is lossless. Only the benchmark's environment-specific source path was adapted to the adjacent `source.json`; algorithms and pin are unchanged. Full provenance is in `reproducibility/PROVENANCE.json`. The manifest detects corruption but is not a digital signature or independent trust anchor.

## Optional PDF rebuild

A working TeX Live installation with the packages named in `report19.tex` is needed only for `sh build.sh`. It is not needed to run any computation or verify the mathematical tests. The supplied PDF has been rendered and all pages visually reviewed. Generated build files stay in `.build/` and are not release payload.
