import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.BigOperators.ModEq
import Diophantine.Paper1982.Master2
import Mathlib.Tactic

/-!
# Cyclic convolution of the native coefficient and assignment words

The modulus is `ρ^n - 1`.  This file proves the arithmetic convolution
identity and derives a carry-free representative from a coefficient-mass
bound.  It does not assume, or prove, a native tableau calibration.
-/

namespace DiophantineConsistency.NativeCyclicConvolution

open scoped BigOperators

variable {n : ℕ} [NeZero n]

/-- The nonnegative coefficient mass, before or after folding the stencil. -/
def mass (a : ZMod n → ℕ) : ℕ := ∑ i, a i

/-- A word indexed by the least representatives of the cyclic positions. -/
def word (ρ : ℕ) (a : ZMod n → ℕ) : ℕ := ∑ i, a i * ρ ^ i.val

/-- Multiplication modulo `X^n - 1`, at the coefficient level. -/
def convolution (a c : ZMod n → ℕ) (k : ZMod n) : ℕ := ∑ i, a i * c (k - i)

theorem convolution_le_mass (a c : ZMod n → ℕ) {D : ℕ}
    (hc : ∀ i, c i ≤ D) (k : ZMod n) : convolution a c k ≤ mass a * D := by
  calc
    convolution a c k ≤ ∑ i, a i * D := by
      apply Finset.sum_le_sum
      intro i _
      exact Nat.mul_le_mul_left _ (hc _)
    _ = mass a * D := by simp only [mass, Finset.sum_mul]

omit [NeZero n] in
theorem base_period {ρ : ℕ} (hρ : 1 ≤ ρ) :
    ρ ^ n ≡ 1 [MOD ρ ^ n - 1] := by
  have hp : 1 ≤ ρ ^ n := one_le_pow₀ hρ
  have he : ρ ^ n = 1 + (ρ ^ n - 1) := by omega
  change ρ ^ n % (ρ ^ n - 1) = 1 % (ρ ^ n - 1)
  exact (congrArg (fun x => x % (ρ ^ n - 1)) he).trans (Nat.add_mod_right _ _)

omit [NeZero n] in
theorem pow_mod_length {ρ : ℕ} (hρ : 1 ≤ ρ) (e : ℕ) :
    ρ ^ e ≡ ρ ^ (e % n) [MOD ρ ^ n - 1] := by
  have he := Nat.mod_add_div e n
  conv_lhs => rw [← he, pow_add, pow_mul]
  simpa only [one_pow, mul_one] using
    (Nat.ModEq.refl (ρ ^ (e % n))).mul ((base_period hρ).pow (e / n))

/-- This congruence holds without any restriction on coefficient size. -/
theorem word_convolution {ρ : ℕ} (hρ : 1 ≤ ρ) (a c : ZMod n → ℕ) :
    word ρ (convolution a c) ≡ word ρ a * word ρ c [MOD ρ ^ n - 1] := by
  have hreindex (i : ZMod n) :
      (∑ k : ZMod n, a i * c (k - i) * ρ ^ k.val) =
        ∑ j : ZMod n, a i * c j * ρ ^ (i + j).val := by
    symm
    apply Fintype.sum_equiv (Equiv.addLeft i)
    intro j
    simp only [Equiv.coe_addLeft, add_sub_cancel_left]
  calc
    word ρ (convolution a c) =
        ∑ i : ZMod n, ∑ j : ZMod n, a i * c j * ρ ^ (i + j).val := by
      simp only [word, convolution, Finset.sum_mul]
      rw [Finset.sum_comm]
      exact Finset.sum_congr rfl (fun i _ => hreindex i)
    _ ≡ ∑ i : ZMod n, ∑ j : ZMod n,
        a i * c j * ρ ^ (i.val + j.val) [MOD ρ ^ n - 1] := by
      apply Nat.ModEq.sum
      intro i _
      apply Nat.ModEq.sum
      intro j _
      have hp := (pow_mod_length (n := n) hρ (i.val + j.val)).symm
      rw [← ZMod.val_add] at hp
      exact hp.mul_left _
    _ = ∑ i : ZMod n, (a i * ρ ^ i.val) * word ρ c := by
      apply Finset.sum_congr rfl
      intro i _
      rw [word, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j _
      rw [pow_add]
      ring
    _ = word ρ a * word ρ c := by rw [← Finset.sum_mul]; rfl

theorem finEquiv_val (i : Fin n) : (ZMod.finEquiv n i).val = i.val := by
  cases n with
  | zero => exact (NeZero.ne 0 rfl).elim
  | succ n => rfl

theorem word_eq_ofDigits (ρ : ℕ) (a : ZMod n → ℕ) :
    word ρ a = Nat.ofDigits ρ (List.ofFn fun i : Fin n => a (ZMod.finEquiv n i)) := by
  rw [Jones1982.ofDigits_ofFn]
  symm
  exact Fintype.sum_equiv (ZMod.finEquiv n).toEquiv _ _
    (fun i => by
      change a (ZMod.finEquiv n i) * ρ ^ i.val =
        a (ZMod.finEquiv n i) * ρ ^ (ZMod.finEquiv n i).val
      rw [finEquiv_val])

theorem word_lt_pow {ρ : ℕ} (hρ : 1 < ρ) (a : ZMod n → ℕ)
    (ha : ∀ i, a i < ρ) : word ρ a < ρ ^ n := by
  rw [word_eq_ofDigits]
  have hh : ∀ x ∈ (List.ofFn fun i : Fin n => a (ZMod.finEquiv n i)), x < ρ := by
    intro x hx
    obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hx
    exact ha _
  simpa only [List.length_ofFn] using Nat.ofDigits_lt_base_pow_length hρ hh

theorem word_add (ρ : ℕ) (a b : ZMod n → ℕ) :
    word ρ (fun i => a i + b i) = word ρ a + word ρ b := by
  simp only [word, add_mul, Finset.sum_add_distrib]

theorem word_max {ρ : ℕ} (hρ : 1 ≤ ρ) :
    word ρ (fun _ : ZMod n => ρ - 1) = ρ ^ n - 1 := by
  rw [word_eq_ofDigits, List.ofFn_const, Jones1982.ofDigits_replicate]
  have hg := geom_sum_mul_add (ρ - 1) n
  rw [Nat.sub_add_cancel hρ] at hg
  have hh : (ρ - 1) * (∑ i ∈ Finset.range n, ρ ^ i) + 1 = ρ ^ n := by
    simpa only [mul_comm] using hg
  omega

/-- Leaving even one unit of slack in every digit excludes the exceptional
all-`ρ−1` representation of zero modulo `ρ^n−1`. -/
theorem word_lt_mersenne {ρ : ℕ} (hρ : 1 < ρ) (a : ZMod n → ℕ)
    (ha : ∀ i, a i < ρ - 1) : word ρ a < ρ ^ n - 1 := by
  rw [← word_max hρ.le]
  apply Finset.sum_lt_sum
  · intro i _
    exact Nat.mul_le_mul_right _ (ha i).le
  · refine ⟨0, Finset.mem_univ _, ?_⟩
    exact Nat.mul_lt_mul_of_pos_right (ha 0) (pow_pos (by omega) _)

/-- A coefficient-mass budget gives an actual carry-free representative,
including the slack needed for uniqueness modulo the Mersenne modulus. -/
theorem no_carry_representative {ρ D T : ℕ} (hρ : 1 < ρ)
    (a c r : ZMod n → ℕ) (hc : ∀ i, c i ≤ D) (hr : ∀ i, r i ≤ T)
    (hbudget : mass a * D + T + 2 ≤ ρ) :
    (∀ k, convolution a c k + r k < ρ - 1) ∧
      word ρ (fun k => convolution a c k + r k) < ρ ^ n - 1 := by
  have hb (k : ZMod n) : convolution a c k + r k < ρ - 1 := by
    have hconv := convolution_le_mass a c hc k
    have hrot := hr k
    omega
  exact ⟨hb, word_lt_mersenne hρ _ hb⟩

/-- The transport congruence determines the full word once both residues
are strictly below the modulus.  No local-clause premise occurs here. -/
theorem transport_word_eq {ρ F : ℕ} (hρ : 1 ≤ ρ) (a c r : ZMod n → ℕ)
    (htransport : word ρ a * word ρ c + word ρ r ≡ F [MOD ρ ^ n - 1])
    (hword : word ρ (fun k => convolution a c k + r k) < ρ ^ n - 1)
    (hF : F < ρ ^ n - 1) :
    word ρ (fun k => convolution a c k + r k) = F := by
  apply Nat.ModEq.eq_of_lt_of_lt _ hword hF
  rw [word_add]
  exact ((word_convolution hρ a c).add_right (word ρ r)).trans htransport

/-- The packed mask test is equivalent to the tests on the actual digits. -/
theorem mask_word_iff {ρ t : ℕ} (hρ : ρ = 2 ^ t) (a m : ZMod n → ℕ)
    (ha : ∀ i, a i < ρ) (hm : ∀ i, m i < ρ) :
    word ρ a &&& word ρ m = 0 ↔ ∀ i, a i &&& m i = 0 := by
  have hLa : ∀ x ∈ (List.ofFn fun i : Fin n => a (ZMod.finEquiv n i)), x < ρ := by
    intro x hx
    obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hx
    exact ha _
  have hLm : ∀ x ∈ (List.ofFn fun i : Fin n => m (ZMod.finEquiv n i)), x < ρ := by
    intro x hx
    obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hx
    exact hm _
  rw [← Jones1982.τ_two_eq_zero_iff, word_eq_ofDigits, word_eq_ofDigits]
  rw [Jones1982.tau_ofDigits_iff hρ hLa hLm List.length_ofFn List.length_ofFn]
  constructor
  · intro h i
    obtain ⟨j, rfl⟩ := (ZMod.finEquiv n).surjective i
    have hh := h j.val j.isLt
    rw [List.getD_eq_getElem _ _ (by simpa only [List.length_ofFn] using j.isLt),
      List.getD_eq_getElem _ _ (by simpa only [List.length_ofFn] using j.isLt)] at hh
    simpa only [List.getElem_ofFn, Jones1982.τ_two_eq_zero_iff] using hh
  · intro h j hj
    have hh := h (ZMod.finEquiv n ⟨j, hj⟩)
    rw [List.getD_eq_getElem _ _ (by simpa only [List.length_ofFn] using hj),
      List.getD_eq_getElem _ _ (by simpa only [List.length_ofFn] using hj)]
    simpa only [List.getElem_ofFn, Jones1982.τ_two_eq_zero_iff] using hh

theorem transport_mask_digits {ρ t D T F : ℕ} (hρ : ρ = 2 ^ t) (hρ2 : 1 < ρ)
    (a c r m : ZMod n → ℕ) (hc : ∀ i, c i ≤ D) (hr : ∀ i, r i ≤ T)
    (hm : ∀ i, m i < ρ) (hbudget : mass a * D + T + 2 ≤ ρ)
    (htransport : word ρ a * word ρ c + word ρ r ≡ F [MOD ρ ^ n - 1])
    (hF : F < ρ ^ n - 1) (hmask : F &&& word ρ m = 0) :
    ∀ k, (convolution a c k + r k) &&& m k = 0 := by
  obtain ⟨hb,hw⟩ := no_carry_representative hρ2 a c r hc hr hbudget
  have he := transport_word_eq hρ2.le a c r htransport hw hF
  apply (mask_word_iff hρ _ m (fun i => by have := hb i; omega) hm).mp
  rwa [he]

/-- A finite stencil can be folded even when exponents collide modulo `n`.
No separation or no-carry hypothesis is required for this definition. -/
def foldStencil {ι : Type*} [Fintype ι] (e a : ι → ℕ) (k : ZMod n) : ℕ :=
  ∑ i, if (e i : ZMod n) = k then a i else 0

theorem mass_foldStencil {ι : Type*} [Fintype ι] (e a : ι → ℕ) :
    mass (foldStencil (n := n) e a) = ∑ i, a i := by
  classical
  unfold mass foldStencil
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  simp

/-- The folded convolution is exactly the original finite stencil acting
on the cyclic digit array, including every collision and spatial term. -/
theorem convolution_foldStencil {ι : Type*} [Fintype ι] (e a : ι → ℕ)
    (c : ZMod n → ℕ) (k : ZMod n) :
    convolution (foldStencil e a) c k = ∑ i, a i * c (k - (e i : ZMod n)) := by
  classical
  unfold convolution foldStencil
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  simp only [ite_mul, zero_mul]
  simp

theorem word_foldStencil {ι : Type*} [Fintype ι] {ρ : ℕ} (hρ : 1 ≤ ρ)
    (e a : ι → ℕ) :
    word ρ (foldStencil (n := n) e a) ≡ ∑ i, a i * ρ ^ e i [MOD ρ ^ n - 1] := by
  classical
  have he : word ρ (foldStencil (n := n) e a) =
      ∑ i, a i * ρ ^ (e i % n) := by
    unfold word foldStencil
    simp only [Finset.sum_mul]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i _
    simp only [ite_mul, zero_mul]
    simp [ZMod.val_natCast]
  rw [he]
  apply Nat.ModEq.sum
  intro i _
  exact ((pow_mod_length (n := n) hρ (e i)).symm).mul_left (a i)

/-- No-carry bounds can be checked on the original stencil coefficients;
folding them never introduces an unaccounted multiplicity factor. -/
theorem stencil_no_carry {ι : Type*} [Fintype ι] {ρ D T : ℕ}
    (hρ : 1 < ρ) (e a : ι → ℕ) (c r : ZMod n → ℕ)
    (hc : ∀ i, c i ≤ D) (hr : ∀ i, r i ≤ T)
    (hbudget : (∑ i, a i) * D + T + 2 ≤ ρ) :
    (∀ k, (∑ i, a i * c (k - (e i : ZMod n))) + r k < ρ - 1) ∧
      word ρ (fun k => convolution (foldStencil e a) c k + r k) < ρ ^ n - 1 := by
  have hb : mass (foldStencil (n := n) e a) * D + T + 2 ≤ ρ := by
    rwa [mass_foldStencil]
  simpa only [convolution_foldStencil] using
    no_carry_representative hρ (foldStencil e a) c r hc hr hb

end DiophantineConsistency.NativeCyclicConvolution
