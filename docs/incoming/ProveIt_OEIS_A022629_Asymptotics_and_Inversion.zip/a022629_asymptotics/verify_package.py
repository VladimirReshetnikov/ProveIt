from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PROVENANCE.json').read_text())
for name,want in manifest['files'].items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=want:
        raise ArithmeticError('SHA-256 mismatch: '+name)
print('All '+str(len(manifest['files']))+' recorded hashes match')
