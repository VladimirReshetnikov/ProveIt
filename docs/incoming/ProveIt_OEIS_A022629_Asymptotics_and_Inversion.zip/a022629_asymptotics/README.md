# Asymptotics and inverse growth for weighted distinct partitions

This report studies OEIS A022629, the coefficients of product(1+k q^k).
It proves three distinct statements:

- A relative coefficient equivalent with an exact one-dimensional integral saddle
- A logarithmic expansion to every fixed inverse-logarithmic order, with explicit coefficients
- A Lambert-W inverse-growth expansion for integer thresholds, with a remainder

The first four logarithmic corrections and first three inverse corrections are
printed in the report. The exact formal-series checker computes ten completed
forward and inverse orders and verifies the saddle/reversion residuals through
order twelve. An independent direct multiplicative calculation checks the
printed coefficients and the spatial second-derivative identity.

The work is unrefereed ordinary mathematics, not Lean formalized. No convergent
full transseries, uniform error as truncation order grows, exact threshold
rounding rule, or exhaustive novelty claim is made. Numerical quadrature values
are orientation only and are not proof inputs.

## Files

- article.pdf and article.tex: the complete report
- checks/check_formal_series.py and .json: exact polynomial-series calculation
- checks/check_coefficients_independent.py and .json: independent low-order check
- checks/check_finite_coefficients.py and .json: exact product coefficients and optional numerical comparison
- checks/check_integral_constant.py: optional numerical illustration of the endpoint constant
- run_checks.sh: exact arithmetic replay only
- PROVENANCE.json and verify_package.py: file hashes and source links
- build_local.sh: the local TeX build used in preparation

## Reproduce

Python 3 with SymPy is required for the exact checks. Run:

    bash run_checks.sh
    python -O verify_package.py

The programs use exact symbolic/rational arithmetic for every acceptance test;
Python optimization does not disable those tests. They regenerate their JSON
outputs. The optional integral examples additionally require mpmath and can be
run individually. The finite-coefficient program enumerates through n=10000
with exact Python integers; it is intentionally excluded from the quick exact
symbolic replay.

A standard TeX Live installation can build article.tex with two pdflatex passes.
The build_local.sh helper records explicit font and format paths for the original
environment. Required packages are amsmath, amssymb, amsthm, mathtools, geometry,
lmodern, microtype, booktabs, hyperref and xurl. No network access is needed to
run the supplied mathematics once these ordinary dependencies are available.

The report cites OEIS A022629, Naranjo–Ramírez (Integers 26, A20, 2026), and
Granovsky–Stark (Electronic Journal of Combinatorics 22(4), P4.32, 2015).
The latter theorem's bounded inside-weight assumption does not directly cover
the growing weight k in this product. The standard saddle/local-limit method
is credited separately from the sequence-specific estimates.
