# Contribution and attribution

Prepared for Vladimir Reshetnikov's ProveIt repository on 2026-10-21 by the
ChatGPT research collaboration. The immediate repository reference is commit
`75716498437bfc7291d5900cab2983a11fd54bac`.

The numerical calculus, its ZFC calibration, primary machine architecture,
source language, baseline compiler, 35-primitive transfer body, source
rotation lemma, and symbolic runtime checker are inherited. Their authors,
provenance, attribution, and original licenses are preserved in the
`machine215/` and `research/short_transfer/` companions. In particular, a
different physical encoding is not claimed as a new logical calculus or as
priority for reassociation itself.

New contributions are the exact six-rotation physical table, fresh runtime
and independent finite audits for that table, the short-transfer control-flow
diagnosis and exact source repairs, the stateful wire and sentinel
construction, the adjacent-code completeness theorem, the corrected
short-transfer runtime and its exact all-start initialization obstruction,
concrete five-zero source trees, the associated research receipts, and this
portable package and report. New material follows ProveIt's MIT No Attribution
terms, included at `machine215/licenses/LICENSE.ProveIt`.

Independent audits here are separate implementations within this research
collaboration. They are not external human endorsements. The packet claims
ordinary proofs and executable verification, not a newly compiled Lean/Rocq
endpoint or an unconditional nonhalting theorem for the accepted candidate.
