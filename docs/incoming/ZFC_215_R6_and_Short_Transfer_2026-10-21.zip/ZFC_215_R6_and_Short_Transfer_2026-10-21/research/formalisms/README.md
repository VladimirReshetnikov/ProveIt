# Three formalism routes to the ZFC-consistency halting predicate

**Scope.** This note compares three genuinely different finite-witness
formalisms. It establishes no new state count. The delivered 215-state table
uses the repository's numerical closure formalism; the other routes remain
research alternatives. The optimization target is a complete binary,
one-tape, blank-start Turing machine, including the cost of writing any fixed
axiom, program, or polynomial data.

Let `Ref_ZFC(p)` be the ordinary primitive-recursive predicate that `p` is a
finite ZFC refutation, with all logical rules and axiom schemes fixed once.
The requirement is a ZFC proof of

\[
 \operatorname{Halt}(M,\mathrm{blank})
 \longleftrightarrow \exists p\,\operatorname{Ref}_{\mathrm{ZFC}}(p).
\]

No interpretation of every intermediate code as a first-order formula is
required. What is required is that **every** accepting finite witness imply
a ZFC refutation and that **every** ZFC refutation eventually give an
accepting witness. A convenient stronger implementation is to give effective
transformations of refutation certificates in both directions, and prove
those transformations correct in ZFC. Equiconsistency stated only in the
external metatheory is insufficient for the requested internal equivalence.

## 1. A finite class theory: GBC/NBG

Use a finite first-order, two-sorted presentation of Gödel–Bernays class
theory with global choice, often presented as NBG. Williams gives GBC's
conservativity over ZFC as Corollary 1.45 and explicitly recalls its finite
axiomatizability in the proof of Corollary 3.11. Consequently its finite
refutations give the same consistency predicate as ZFC; these ordinary
model-theoretic arguments can be formalized in ZFC. The class sort has
Henkin-style first-order semantics, rather than an external requirement to
range over all subsets of the set domain. [W]

**Encoding opportunity (our assessment).** A finite axiom list can replace
recognition of infinitely many Separation and Replacement instances. The
machine can enumerate logical proof programs from a fixed finite base. In a
carefully chosen class language, closure under finitely many class
operations can absorb what previously appeared as schema instantiation.

**Where complexity goes.** The class axioms still contain variables,
quantifiers, membership and equality; their substitution and inference
machinery must be paid for. The additional sort must either be enforced or
eliminated by a proved coding. The finite axiom list must be encoded on a
blank-start machine, not supplied as a free initial tape. Conjoining the
axioms into one sentence does not reduce its information content or the
cost of generating its code.

**State-count conclusion.** No advantage over 215 is established. A
meaningful comparison would fix the finite axiom codes, prove the exact
consistency reduction, compile the actual rule evaluator, and count the
reachable physical states. Finiteness of the axiom list alone supplies none
of those counts.

## 2. Numerical closure with raw natural codes

Define a recursively generated subset `C` of the natural numbers and a
distinguished bad number `b`. Its generators and closure operations are
explicit arithmetic programs. The criterion is

\[
 b\in C\quad\longleftrightarrow\quad
 \exists p\,\operatorname{Ref}_{\mathrm{ZFC}}(p).
\]

This can be proved without defining a formula decoder on all of `C`. For
soundness, an induction over a numerical derivation can transport a
certificate of safety or a ZFC proof invariant. For completeness, a compiler
maps every ZFC refutation to a finite accepted numerical instruction
sequence. Neither obligation requires the numerical calculus to have
exactly ZFC's theorems, nor requires individual junk codes to decode.

The pinned ProveIt construction is already a concrete example of this
approach. Its dominated numerical rules, strong finite-program compiler,
and cofinal scheduler are documented in the included
`../../machine215/proofs/inherited_source_calibration.tex`, copied from the
pinned repository source. [P]

**Encoding opportunity (our assessment).** Choose the mathematical rules and
the arithmetic encoding together. A condition that is expensive to check
can sometimes be made true by construction—for example, generate two
parameters as `u` and `u+x`, so domination is automatic. Likewise, a failed
proof instruction may return a cheap harmless value rather than invoke a
syntax-error path, provided the safety invariant proves that value harmless
under every subsequent instruction. Fields unused by a command need not be
decoded. The current baseline already applies versions of these ideas; they
must not be presented as newly discovered principles.

The strongest freedom is to preserve only the bad-code predicate. A new
closure operation is acceptable even if it changes the rest of `C`, but it
must come with a proof that finite bad-code derivations are preserved in
both directions. Merely labelling new outputs “junk” proves nothing. In
particular, permitting extra inputs to a matching or implication rule can
make previously unreachable bad codes derivable.

**Where complexity goes.** It moves into arithmetic pairing/projections,
register or stack transport, parameter generation, and the proof of the
safety invariant. Complete finite proof-program enumeration must also be
cofinal, and each unsuccessful attempt must terminate or be fairly
interleaved. A smaller arithmetic expression may still demand a more
expensive physical register transfer.

**State-count conclusion.** This route has a demonstrated 215-state
implementation in the delivered packet. A new semantic operation or field
layout has no justified state saving until its complete physical table and
arbitrary-natural runtime are checked. Of the three routes, this is the
most immediately priced experimental setting; that is an engineering
assessment, not a theorem that other formalisms are larger.

## 3. An arithmetic witness predicate, then one Diophantine equation

At the first stage, simply enumerate `p` and test `Ref_ZFC(p)`. This replaces
live theorem generation with checking an entire proof certificate; the
predicate is finite and computable, but its evaluator still contains the
syntax, scheme and inference checks.

The Davis–Putnam–Robinson–Matiyasevich result gives a second stage: an r.e.
witness condition can be represented by polynomial solvability. Jones's
primary paper states the representation theorem and constructs the
universal-equation framework. Fixing its machine parameter for a ZFC
refutation enumerator yields a fixed integer polynomial `P` with

\[
 \exists \vec x\in\mathbb N^k\ P(\vec x)=0
 \quad\longleftrightarrow\quad
 \exists p\,\operatorname{Ref}_{\mathrm{ZFC}}(p).
\]

The conversion to natural rather than positive variables is the elementary
substitution `x_i=y_i+1` where needed. [J] This paragraph is an application
of the representation theorem; **no concrete coefficient list was extracted
or compiled in this work**.

Now the machine needs only fair enumeration of finite tuples and exact
polynomial evaluation. Equivalently, the formalism has the single bad-witness
rule “derive bad if this tuple makes `P` zero.” Its consistency is absence of
such a tuple. Formalizing the constructive representation proof and the
finite evaluator in ZFC supplies the required internal equivalence.

**Encoding opportunity (our assessment).** Formula parsing, substitution and
logical inference disappear from the runtime vocabulary. Repeated arithmetic
subexpressions can be represented by auxiliary variables and short equations;
a conjunction of equations can be combined by a sum of their squares.
Keeping those equations separate may make a smaller evaluator than expanding
one huge polynomial. A tuple can contain an entire proposed computation, so
the machine need not reproduce it sequentially.

**Where complexity goes.** The fixed polynomial or constraint list contains
the encoded refutation computation. Its constants must be generated from
blank tape. Multiplication, copying, sign handling, tuple enumeration and
scratch restoration have physical costs. A universal polynomial with few
variables need not have a short coefficient/exponent description, and a
short description need not have a small binary TM evaluator. Exponentiation
can shorten an exponential-Diophantine description while adding another
arithmetic operation to the evaluator.

**State-count conclusion.** No 214- or 215-state implementation is justified
by the representation theorem. A credible next experiment would specialize
a register-machine-to-constraints translation to an already compact
refutation evaluator, retain a factored arithmetic circuit, and price that
circuit together with its tuple generator. The abstract existence of a
single equation is not a machine construction.

## Comparison

| Route | What can disappear from the evaluator | What must be paid for elsewhere | Verified physical advantage here |
|---|---|---|---|
| Finite GBC/NBG | ZFC schema-instance recognition | Finite axiom data, class operations, variable handling and logical inference | None |
| Raw numerical closure | Formula decoding and selected side-condition tests | Pairing/projections, transport, safety invariant and complete instruction enumeration | Existing and alternative 215-state tables; no new 214 bound |
| Diophantine witnesses | Runtime logical syntax and inference | Specialized equation data, arithmetic evaluation and fair tuple enumeration | None |

For all three, the correct comparison is the state count after the finite
formalism, fixed data, blank initialization, complete enumerator and
physical runtime are combined. The current raw-code route has the clearest
near-term experiment: change a mathematical rule only when doing so removes
an expensive physical operation, then prove preservation of bad-code
reachability. The class-theory and Diophantine routes remain plausible
sources of different architecture, with no demonstrated saving yet.

## Primary sources and pinned repository source

- **[W]** Kameryn J. Williams, *The Structure of Models of Second-order Set
  Theories*, doctoral dissertation, CUNY, 2018. Corollary 1.45, printed p. 33,
  proves GBC conservativity; the proof of Corollary 3.11, printed p. 120,
  recalls finite axiomatizability. [arXiv:1804.09526](https://arxiv.org/abs/1804.09526),
  [PDF](https://arxiv.org/pdf/1804.09526).
- **[J]** James P. Jones, “Universal diophantine equation,” *Journal of
  Symbolic Logic* **47**(3), 549–571, 1982,
  [doi:10.2307/2273588](https://doi.org/10.2307/2273588).
  [Publisher's primary article and accessible extract](https://www.cambridge.org/core/journals/journal-of-symbolic-logic/article/universal-diophantine-equation/113EBF3D928DFC6011C52BECAE81A087).
  The extract states the r.e.-set representation and the universal parameter
  construction used here; no quantitative coefficient bound is inferred.
- **[P]** ProveIt, `candidate-k215/provenance/permuted-commands/sections/source_calibration.tex`,
  commit `75716498437bfc7291d5900cab2983a11fd54bac`.
  [Pinned primary source](https://github.com/VladimirReshetnikov/ProveIt/blob/75716498437bfc7291d5900cab2983a11fd54bac/Computability/BusyBeaver/Research/ZFC/candidate-k215/provenance/permuted-commands/sections/source_calibration.tex).
  Included unchanged in the sibling machine packet; its original attribution
  and licensing remain in force.

Prepared 2026-10-21. Mathematical reductions above are separated from
unimplemented engineering proposals. This note contains no downloaded
third-party article and introduces no additional verification claim for the
frozen machine packet.
