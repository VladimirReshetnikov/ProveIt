# Repaired short-transfer: exact 215-state runtime, rejected blank initializer

The table `runtime-only.native.tm` implements the corrected 4,733-leaf,
201-node source in `../repaired-association-3.sites.json` using **215 states**.
All **6,152** arbitrary-natural primitive cases pass the whole-tape symbolic
checker, with **1,587,125** symbolic rules, coverage of **all 430** native rows,
and a minimum duration constant of **5**. Increment appends a zero-valued spare
block. The source's corrected control flow and consistency calibration are
established separately in the containing short-transfer research packet.

**This literal table is rejected as a blank-tape consistency machine.**
Starting with a blank tape from **every one of its 215 existing states** reaches
an exact outward ray after at most **53 transitions**. The displayed start 74
reaches its ray after 49 transitions. These are exact non-halting witnesses,
not simulation timeouts. A successful blank initializer would require changing
the table or its physical source realization. Choosing another existing start
state does not repair this table.

## Construction

`recipe.json` lists the exact nine changed rows relative to the archived
scratch-biased table in `../inputs/archived-biased.native.tm`. Eight changes
reassociate the source. The ninth changes 26/0 from 0R134 to 0R194, preserving an
engine use of the old 134/0 action 0R17 while state 134 is repurposed. This helper
use is invisible in a decoder-only inventory. Omitting the reroute fails the
first CD8-zero primitive.

The new source places the repaired CC3 return at 00111, which has exactly three
ones and ends in 111. The Clear node remains in a context ending in 1, preserving
its shared, contextual CD1/CD5 implementation. The source is the third exact
association verified by the parent packet; its complete guarded control-flow
graph equals the explicit CC4 repair of the archived program.

The original initializer first dispatches on a short, malformed word beginning
0001. The archived scheduler's CB1 leaf at 0001 consumes that configuration.
The corrected association moves that scheduler leaf to 000001, so the same
initial tape follows another engine path and enters an outward ray. The file
`bootstrap_trace.json.gz` records this exact 49-step trace.

## Reproduction

From this directory:

```sh
python -B verify.py
python -B verify.py --full
```

The first command reconstructs all nine changed rows, checks pins and saved
runtime records, and replays complete ray witnesses for every existing start.
The second additionally rederives every quantified primitive case. It uses the
included checker at `../../../machine215/vendor/runtime/`, with exact source
hashes pinned in `recipe.json`. Assertions must remain enabled; do not use
Python's `-O` option.

`runtime_cases.json.gz` contains the affine duration, rule counts, and row usage
for every primitive case. `ray_witnesses.json.gz` contains every finite blank
prefix and its complete final tape. For each ray witness, the head scans 0
outside the finite support and the transition writes a bit, moves outward,
and retains its state. Induction therefore proves that the ray continues
forever.

The symbolic runtime evidence is an executable mathematical induction check.
It is not a proof-assistant kernel certificate. The ray rejection is a direct
finite trace plus a one-step invariant and is independent of the source theory.

## Bounded local-return search

`local_entry_probe.json` records a separate bounded search on the archived
table, changing only row 311/1 to each of 860 possible write/direction/existing-
label actions for a CC3 leaf at 10011. No action reaches the required frame
within 5,000 transitions from the specified all-zero register frame. Under
the stronger first-clean-dispatch filter, three actions remain unresolved;
under plain target reachability, 753 actions remain unresolved. The receipt
and complete classifications distinguish these policies. Wrong first
dispatch is not an unrestricted nonreachability theorem. This search does
not establish an all-natural absence theorem or a state lower bound.

Reproduce this bounded search with `python -B local_entry_probe.py`.
