#!/usr/bin/env python3
"""Audit exact row recipe, saved runtime evidence, and all-start blank rays.
With --full, rederive all6152 quantified primitive cases using the included checker.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,sys,time
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def parse(p):
 t={}
 for line in Path(p).read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  assert(q,b)not in t and b in(0,1)and w in(0,1)and d in('L','R')
  t[q,b]=(w,1 if d=='R'else-1,z)
 states={q for q,b in t};assert len(states)==215 and set(t)=={(q,b)for q in states for b in(0,1)}
 assert{z for w,d,z in t.values()}-states=={254}
 return t

def main():
 assert __debug__ and not sys.flags.optimize,'Assertions must be enabled.'
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--full',action='store_true');args=ap.parse_args()
 r=json.loads((HERE/'recipe.json').read_text());T=parse(HERE/'runtime-only.native.tm');old=parse(HERE/r['base'])
 assert sha(HERE/r['base'])==r['base_sha256']
 assert sha(HERE/r['source'])==r['source_sha256']
 assert sha(HERE/'runtime-only.native.tm')==r['table_sha256']
 changed=[]
 for c in r['changes']:
  key=tuple(c['row']);assert old[key]==tuple(c['before'])
  old[key]=tuple(c['after']);changed.append(key)
 assert old==T and len(changed)==9
 for key in('runtime_checker','runtime_helper','legacy_mapping'):
  assert sha(HERE/r[key])==r[key+'_sha256']
 cases_raw=gzip.decompress((HERE/'runtime_cases.json.gz').read_bytes())
 assert sha(HERE/'runtime_cases.json.gz')==r['cases_gzip_sha256']
 assert hashlib.sha256(cases_raw).hexdigest()==r['cases_raw_sha256']
 cases=json.loads(cases_raw);sites=json.loads((HERE/r['source']).read_text())
 order=[(i,p)for i,(_,op,_)in enumerate(sites)for p in((False,True)if op=='CD'else(False,))]
 assert[(x['site_index'],x['positive'])for x in cases]==order and len(cases)==6152
 assert sum(x['symbolic_steps']for x in cases)==1587125
 assert min(x['duration'][0]for x in cases)==5
 mapping={int(k):int(v)for k,v in json.loads((HERE/r['legacy_mapping']).read_text()).items()}
 for q in{q for q,b in T}|{254}:
  if q not in mapping:mapping[q]=q+1000
 assert len({mapping[q]for q in{q for q,b in T}|{254}})==216
 inverse={v:k for k,v in mapping.items()};used=set()
 for c in cases:
  assert len(c['duration'])==13 and c['duration'][0]>0 and all(type(n)is int and n>=0 for n in c['duration'])
  assert c['symbolic_steps']==sum(c['kinds'].values())
  for q,b in c['rows']:assert(inverse[q],b)in T;used.add((inverse[q],b))
 assert used==set(T)
 # Replay the complete short prefix from every possible existing start state.
 # In each final configuration the sole transition repeats on a blank ray.
 rays=json.loads(gzip.decompress((HERE/'ray_witnesses.json.gz').read_bytes()))
 assert[x['start']for x in rays]==sorted({q for q,b in T})
 for f in rays:
  q=f['start'];h=0;ones=set()
  assert len(f['trace'])==f['steps']
  for event in f['trace']:
   b=int(h in ones);w,d,z=T[q,b];assert event==[q,h,b,w,d,z]
   if w:ones.add(h)
   else:ones.discard(h)
   q=z;h+=d
  assert(q,h,sorted(ones))==(f['state'],f['head'],f['one_cells'])
  w,d,z=T[q,0];assert f['loop_row']==[q,0,w,d,z]
  assert h not in ones and z==q
  assert not ones or(d==1 and h>max(ones))or(d==-1 and h<min(ones))
 assert max(f['steps']for f in rays)==53
 summary={'status':'SAVED_RUNTIME_AND_EXACT_ALL_START_RAYS_PASS','states':215,'changed_rows':9,'source_leaves':len(sites),'quantified_primitive_cases':6152,'symbolic_rules':1587125,'covered_rows':430,'minimum_duration_constant':5,'blank_start_states':215,'maximum_ray_prefix_steps':53,'full_fresh_runtime_replay':False,'candidate_status':'REJECTED_AS_A_BLANK_CONSISTENCY_MACHINE: literal table is provably blank-divergent from every existing start.'}
 if args.full:
  sys.path.insert(0,str((HERE/r['runtime_checker']).resolve().parent))
  import symbolic_runtime as s
  L={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in T.items()}
  lemmas,blocks=s.prove_blocks(L)
  assert json.loads(json.dumps(blocks))==json.loads((HERE/'runtime.json').read_text())['blocks']
  started=time.monotonic()
  for j,c in enumerate(cases):
   ans=s.case(L,lemmas,sites[c['site_index']],c['positive'],append=0)
   ans['rows']=sorted(ans['rows']);ans.pop('trace')
   actual={'site_index':c['site_index'],'positive':c['positive'],**ans}
   assert json.loads(json.dumps(actual))==c,('Fresh runtime case differs',j)
   if(j+1)%1000==0:print('PROVED',j+1,'OF6152',flush=True)
  summary.update(status='FULL_RUNTIME_AND_EXACT_ALL_START_RAYS_PASS',full_fresh_runtime_replay=True,seconds=time.monotonic()-started)
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
