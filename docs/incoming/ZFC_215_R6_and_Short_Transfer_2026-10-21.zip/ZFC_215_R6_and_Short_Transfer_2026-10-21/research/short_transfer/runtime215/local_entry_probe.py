#!/usr/bin/env python3
"""Reproduce a bounded existing-entry search; no absence theorem is claimed.
The search changes only archived311/1, then starts at dispatcher84 on the
canonicalPC10011 frame with all nine registers0 and spare list[0].
"""
from pathlib import Path
import collections,gzip,hashlib,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str((HERE/'../../../machine215/vendor/runtime/runtime').resolve()))
import independent_runtime as r
from verify import parse
LIMIT=5000

def run(T,action,first):
 T=dict(T);T[311,1]=tuple(action);q=84;h=0;ones=r.frame('10011',[0]*9,[0]);target=r.frame('',[0]*9,[0]);seen=set()
 for tick in range(LIMIT):
  if tick and(q,h,ones)==(84,0,target):return 'TARGET',tick
  if first and tick and r.clean_dispatch(96 if q==84 else -1,h,ones):return 'WRONG_FIRST_CLEAN_FRAME',tick
  conf=(q,h,frozenset(ones))
  if conf in seen:return 'EXACT_CYCLE',tick
  seen.add(conf)
  b=int(h in ones)
  if(q,b)not in T:return 'UNDEFINED_OR_HALT',tick
  w,d,z=T[q,b]
  if b==0 and z==q and(not ones or(d==1 and h>max(ones))or(d==-1 and h<min(ones))):return 'EXACT_OUTWARD_RAY',tick
  if w:ones.add(h)
  else:ones.discard(h)
  q=z;h+=d
 return 'BOUNDED_UNRESOLVED',LIMIT

def probe():
 base=HERE/'../inputs/archived-biased.native.tm';T=parse(base);records=[]
 for q in sorted({q for q,b in T}):
  for w in(0,1):
   for d in(-1,1):
    action=[w,d,q];a=run(T,action,True);b=run(T,action,False)
    records.append({'action':action,'first_clean_policy':list(a),'target_reach_policy':list(b)})
 count=lambda key:dict(sorted(collections.Counter(x[key][0]for x in records).items()))
 receipt={'status':'BOUNDED_TEMPLATE_SEARCH_NO_HIT','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'modified_row':[311,1],'path':'10011','requested_opcode':['CC',3],'registers':[0]*9,'spares':[0],'gap':0,'tested_actions':len(records),'transition_limit':LIMIT,'first_clean_policy':count('first_clean_policy'),'first_clean_bounded_unresolved':[x['action']for x in records if x['first_clean_policy'][0]=='BOUNDED_UNRESOLVED'],'target_reach_policy':count('target_reach_policy'),'scope':'The first policy rejects a wrong first complete dispatcher frame. Such rejection is not a theorem that the requested target can never be reached later. The second policy continues through other frames. No action reaches the target within5000transitions; bounded cases remain unresolved. One zero-valued frame is a filter, not an all-natural proof. No unrestricted nonexistence or state lower bound is claimed.'}
 return receipt,records
if __name__=='__main__':
 receipt,records=probe()
 if sys.argv[1:]==['--write-evidence']:
  (HERE/'local_entry_probe.json').write_text(json.dumps(receipt,indent=2)+'\n')
  (HERE/'local_entry_records.json.gz').write_bytes(gzip.compress((json.dumps(records,indent=2)+'\n').encode(),mtime=0))
 else:
  assert not sys.argv[1:]
  assert receipt==json.loads((HERE/'local_entry_probe.json').read_text())
  assert records==json.loads(gzip.decompress((HERE/'local_entry_records.json.gz').read_bytes()))
 print(json.dumps(receipt,indent=2))
