# Short transfer: literal defect, exact source repairs, and scheduler proof

**Status:** the archived `scratch-biased` 215-state experiment is rejected: it
halts on blank, by the archived physical runtime and bootstrap together with
the literal 16-step source suffix identified here. This package supplies exact
source repairs and a complete source-level calibration of their intended biased
scheduler. Association 3 has an exact 215-state physical runtime realization,
but every possible blank working start enters an outward ray. It is therefore
not an additional accepted blank-input consistency machine.

The repaired source is materially different from the original composite
transfer: its transfer command has only a cache-equals-one halt guard, and its
parser intentionally carries a one-bit bias. Candidate numbers can have gaps
of two. The new adjacent-code synchronizer handles those gaps without requiring
the parser to enumerate every candidate number.

## Reproduce

Run with Python 3.10 or newer, assertions enabled, and no third-party packages:

```sh
python verify.py
python checks/inherited_stack_contracts.py
```

The first command checks both independent control-flow resolvers on all source
occurrences, regenerates all four repaired sources exactly, reproduces the
16-step halt trace, simulates the archived whole 69,744-transition blank prefix,
and checks its matching 172-step abstract AX prefix. It also corroborates the
arithmetic and wire identities on finite cases. It writes
`evidence/verification.json`.

The second command is the unchanged symbolic stack-contract checker inherited
from the parent packet. Its short-transfer semantics are exactly the semantics
used here. It records 51 symbolic cases, with 47 exact returns and four permitted
early halts, after 2,619 command steps. Formula-valued AX rows are opaque tagged
terms; this is not an independent proof of their logical validity. It writes
`checks/NIP_TRANSFER_SYMBOLIC_CHECK.json`.

The original strong compiler proof and independent review are copied unchanged
under `references/` for attribution and comparison.

The bounded checks are corroboration. The proofs over all natural numbers are
in `theory.tex`. The comparison of the inherited dominated numerical calculus
with ZFC remains an explicitly inherited premise, unchanged by this work.

## Exact failure

The archived program has `CI6` at ordinal 4,696 and `CC3` at ordinal 4,697.
The latter has address `100111` and targets selector ordinal 23. It does not
return to scheduler ordinal 0. After the initial AX finishes, this jumps into
the short transfer with dirty scratch X=1. The copy routine converts that unit
into cached falsity and NIP halts. The complete suffix is:

```
4696 4697 23 4698 4700 4704 4705 4706
4704 4707 4708 4709 4710 4708 4712 4718
```

The exact trace never reads the candidate counter, proof residual, or work
stack. The archived first AX terminates by the inherited all-natural AX contract.
This proves unconditional blank halting; it is more than a finite failed test
or an unproved fairness obligation. Other primary and composite-transfer
candidates are unaffected.

## Repairs and physical scope

`repaired-CC4.sites.json` changes only the return instruction. It has 203
distinct subtrees. The three association repairs preserve the complete ordered
word of 4,733 primitives and have 201 distinct subtrees each. Their complete
guarded control-flow graphs equal the CC4 correction; the two independent
resolvers check this without testing sampled register values.

Let the old tree be `(SR,((Sel,C),(L,N)))`, with `Sel=(D,CaseRet)` and
`SR=(Sch,Read)`. Here D is the initial selector decrement, CaseRet holds the
AX/MP branches and the final `(CI6,CC3)` pair, and C/L/N form the short transfer.

* Association 1 is `(((SR,D),CaseRet),(C,(L,N)))`.
* Association 2 is `(((Sch,(Read,D)),CaseRet),(C,(L,N)))`.
* Association 3 is `((((Sch,(Read,D)),CaseRet),C),(L,N))`.

The first two put the return at `0111`, preserving the physical CC3 helper's required
terminal `111` context. Association 2 also reduces the first CD8 address from
six leading zeros to five. Their first proposed physical allocations fail the
first CD8 primitive case because the modified decoder row 134/0 is also used as
an engine helper. Redirecting 26/0 to state 194, with the same required
read-zero action, repairs
that conflict. Association 2 then exposes a contextual clear-top CD1 error.
Association 3 puts that clear-top instruction at `010`, with its required
preceding 1, and places CC3 at `00111`. It keeps maximum zero run 6 and has
maximum depth 43. Source subtree counts alone do not establish binary state
counts.

The concrete association-3 implementation now has a complete 215-state runtime
proof: all 6,152 guarded primitive cases, 1,587,125 symbolic rules, all 430 table
rows, minimum positive duration 5. Its table, exact nine-row construction,
runtime summaries, complete blank ray witnesses, and portable replay are under
`runtime215/`. The separate `physical_association3/` directory supplies an
independent graph/delta/blank audit. To reproduce the saved-evidence audit,
run `python runtime215/verify.py`; add `--full` to rederive every quantified
primitive case using the included checker.

That literal table has no suitable working start state: each of its 215 blank
starts reaches an exact outward ray within 53 transitions, and the displayed
start 74 does so after 49. The ray is proved by its complete finite prefix and
an outward self-loop invariant, not a simulation cutoff. Changing only the
start state therefore cannot fix its initializer. A differently allocated or
initialized table would need its own runtime and blank-prefix certificates.

## New mathematical components

The parser's scratch is 0 after S and 1 after MP or AX. At positive residual L,
the next field is read from `unpair(L-1+b)`. At refill, it reads raw old counter
N and advances N by `1+b`, where b comes from the previous candidate.

The stateful wire encoding is

```
e_b([]) = 0
e_b(k::W) = 1-b + fold_pair(fields(k), e_beta(k)(W)).
```

A final AX or MP is necessary: a lone terminal S after bias 1 encodes zero.
The proof appends an unreachable AX sentinel to a universally halting command
word. The inherited strong compiler is rederived for the single-guard short S,
including the native truth and zero-stack aliases.

For positive continuation R, v >= 0 and x >= 2, set

```
z = P(v,R); r = P(1,z); b = 1+P(x,r); q = P(0,b).
```

Then candidate q executes `S; AX(x-2;v,1)` while q-1 executes `MP(x); MP(v)`.
Unless an earlier halt occurs, both reach R with bias 1. They need not produce
equal work stores: the continuation compiled from a refutation halts from
every raw work store. Since x can grow without bound, successful adjacent
pairs are cofinal. Every increasing sequence with increments 1 or 2 meets
each sufficiently late adjacent pair.

Finally, the archived partial-AX initializer has tail 3, and
`3=P(2,0)`, `2=Q_0(0)`. That tail is already theorem-safe. A protected-stack
credit argument is unnecessary for this seed. A new physical table must still
establish its own initializer.

## Provenance

The pinned upstream repository commit and SHA-256 input digests are in
`provenance.json`. All archived inputs come from
`docs/incoming/T215_Transfer_2026-10-20.zip`, within its
`T215_Transfer_2026-10-20/research/short-transfer` directory, except the unchanged
stack checker and licenses, which come from its `reference/transfer-parent`.

The archived runtime report and compressed case summaries are retained as
evidence for the **rejected original**. Their old `logical_calibration: OPEN`
label is historical; this package's unconditional-halt diagnosis supersedes
it. They have not been relabeled as evidence for any repaired source.

The original transfer calculus, the 35-leaf transfer implementation, and its
strong proof compiler are inherited contributions. The present additions are
the literal control-flow diagnosis, the three exact source associations, the
stateful wire/sentinel construction, the adjacent-code synchronizer, its
cofinality proof, and the observation that tail 3 is already theorem-safe.
