#!/usr/bin/env python3
"""Reproduce exact source repairs and finite checks for the short transfer.

Python 3.10+, standard library only, with assertions enabled. Inputs are inert
JSON/TM data. This checker does not prove the inherited numerical-calculus
comparison or any repaired binary runtime/blank-start theorem. The all-natural
wire, synchronizer and compiler proofs are in theory.tex.
"""
from __future__ import annotations
from functools import cache
from itertools import product
from math import isqrt
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compact(obj):
    return (json.dumps(obj, separators=(',', ':')) + '\n').encode('ascii')


def is_leaf(t):
    return isinstance(t[0], str)


def tree(rows):
    leaves = {p: (op, arg) for p, op, arg in rows}
    assert len(leaves) == len(rows)
    def visit(p):
        return leaves[p] if p in leaves else (visit(p + '0'), visit(p + '1'))
    result = visit('')
    assert sites(result) == rows
    return result


def sites(t, p=''):
    if is_leaf(t):
        return [[p, *t]]
    return sites(t[0], p + '0') + sites(t[1], p + '1')


def replace(t, p, new):
    if not p:
        return new
    b = int(p[0])
    out = list(t)
    out[b] = replace(out[b], p[1:], new)
    return tuple(out)


def metrics(t):
    seen = set()
    def visit(n):
        if n in seen:
            return
        seen.add(n)
        if not is_leaf(n):
            visit(n[0]); visit(n[1])
    visit(t)
    ss = sites(t)
    return dict(dag_nodes=len(seen), primitive_occurrences=len(ss),
                maximum_depth=max(len(p) for p, _, _ in ss),
                maximum_zero_run=max(len(q) for p, _, _ in ss for q in p.split('1')))


def graph_intervals(rows):
    """Resolver 1: full subtree intervals, walked outwards by parent edges."""
    indices = {p: i for i, (p, _, _) in enumerate(rows)}
    intervals = {}
    def visit(p):
        if p in indices:
            ans = indices[p], indices[p] + 1
        else:
            a, b = visit(p + '0'), visit(p + '1')
            assert a[1] == b[0]
            ans = a[0], b[1]
        intervals[p] = ans
        return ans
    assert visit('') == (0, len(rows))
    def unwind(p, bit, count):
        while p:
            last, p = p[-1], p[:-1]
            if last == bit:
                count -= 1
                if count == 0:
                    return intervals[p][1] % len(rows) if bit == '0' else intervals[p][0]
        return 0
    ans = []
    for i, (p, op, arg) in enumerate(rows):
        after = (i + 1) % len(rows)
        if op == 'CI':
            edges = [after]
        elif op == 'CD':
            edges = [unwind(p, '0', 1), after]
        elif op in ('CB', 'CC'):
            edges = [unwind(p, '0' if op == 'CB' else '1', arg)]
        else:
            assert op == 'CH'
            edges = []
        ans.append([op, arg if op in ('CI', 'CD') else None, edges])
    return ans


def graph_arithmetic(rows):
    """Resolver 2: binary cursor increment/cut and first leaf prefix."""
    leaves = {p: i for i, (p, _, _) in enumerate(rows)}
    depth = max(map(len, leaves))
    def locate(p):
        word = p + '0' * depth
        for k in range(1, depth + 1):
            if word[:k] in leaves:
                assert '1' not in p[k:], ('stray suffix', p, word[:k])
                return leaves[word[:k]]
        raise AssertionError(('no leaf', p))
    def inc(p):
        return format((int(p, 2) + 1) % (1 << len(p)), '0' + str(len(p)) + 'b') if p else ''
    def cut(p, bit, count):
        ps = [i for i, b in enumerate(p) if b == bit]
        return p[:ps[-count]] if len(ps) >= count else ''
    ans = []
    for p, op, arg in rows:
        if op == 'CI':
            edges = [locate(inc(p))]
        elif op == 'CD':
            edges = [locate(inc(cut(p, '0', 1))), locate(inc(p))]
        elif op in ('CB', 'CC'):
            cursor = inc(cut(p, '0', arg)) if op == 'CB' else cut(p, '1', arg)
            edges = [locate(cursor)]
        else:
            assert op == 'CH'
            edges = []
        ans.append([op, arg if op in ('CI', 'CD') else None, edges])
    return ans


def step(graph, pc, regs):
    op, arg, edges = graph[pc]
    regs = regs[:]
    if op == 'CH':
        return None, regs
    if op == 'CI':
        regs[arg] += 1
    elif op == 'CD':
        positive = regs[arg] > 0
        regs[arg] -= int(positive)
        return edges[int(positive)], regs
    return edges[0], regs


def run_until(graph, pc, regs, stop, cap=200000):
    for count in range(cap):
        pc, regs = step(graph, pc, regs)
        if pc is None or pc == stop:
            return pc, regs, count + 1
    raise AssertionError(('finite corroboration cap', pc, regs))


def pairing(a, b):
    return (a + b) * (a + b + 1) // 2 + b


def unpairing(n):
    s = (isqrt(8 * n + 1) - 1) // 2
    b = n - s * (s + 1) // 2
    a = s - b
    assert a >= 0 and b >= 0 and pairing(a, b) == n
    return a, b


S = ('S',)
def MP(x): return ('M', x)
def AX(c=0, x=0, y=0): return ('A', c, x, y)
def beta(k): return int(k != S)


def fields(k):
    if k == S:
        return [0]
    if k[0] == 'M':
        return [1, k[1]]
    return [k[1] + 2, k[3], k[2]]


def encode(word, bias):
    if not word:
        return 0
    r = encode(word[1:], beta(word[0]))
    for v in fields(word[0])[::-1]:
        r = pairing(v, r)
    return 1 - bias + r


def read_raw(n):
    tag, r = unpairing(n)
    if tag == 0:
        return S, r
    if tag == 1:
        x, r = unpairing(r)
        return MP(x), r
    y, r = unpairing(r)
    x, r = unpairing(r)
    return AX(tag - 2, x, y), r


def read_continuation(r, bias):
    assert r > 0
    return read_raw(r - 1 + bias)


def verify_source():
    original = json.loads((ROOT / 'inputs/archived-biased.sites.json').read_text())
    t = tree(original)
    sr, ((sel, clear), (load, nip)) = t
    decrement, cases_return = sel
    schedule, reader = sr
    assert decrement == ('CD', 3)
    assert original[4696] == ['100110', 'CI', 6]
    assert original[4697] == ['100111', 'CC', 3]
    cc4 = replace(t, '100111', ('CC', 4))
    assoc1 = (((sr, decrement), cases_return), (clear, (load, nip)))
    assoc2 = (((schedule, (reader, decrement)), cases_return), (clear, (load, nip)))
    assoc3 = ((((schedule, (reader, decrement)), cases_return), clear), (load, nip))
    corrected = graph_intervals(sites(cc4))
    results = {}
    for name, source in [('CC4', cc4), ('association-1', assoc1), ('association-2', assoc2), ('association-3', assoc3)]:
        out = sites(source)
        assert compact(out) == (ROOT / ('repaired-' + name + '.sites.json')).read_bytes()
        assert graph_intervals(out) == graph_arithmetic(out) == corrected
        if name != 'CC4':
            assert [r[1:] for r in out] == [r[1:] for r in original]
            assert out[4697] == ['00111' if name == 'association-3' else '0111', 'CC', 3]
        if name == 'association-3':
            assert out[4698] == ['010', 'CD', 1]
        results[name] = metrics(source)
    old_graph = graph_intervals(original)
    assert old_graph == graph_arithmetic(original)
    differences = [i for i, (a, b) in enumerate(zip(old_graph, corrected)) if a != b]
    assert differences == [4697]
    assert old_graph[4697][2] == [23] and corrected[4697][2] == [0]
    expected_trace = [4696, 4697, 23, 4698, 4700, 4704, 4705, 4706,
                      4704, 4707, 4708, 4709, 4710, 4708, 4712, 4718]
    traces = []
    for n, w, residual in [(1, 3, 0), (17, 37, 19)]:
        regs = [n, 0, w, 0, 0, 0, 0, 0, residual]
        pc = 4696
        trace = []
        while pc is not None:
            trace.append(dict(ordinal=pc, source=original[pc], registers=regs))
            pc, regs = step(old_graph, pc, regs)
            assert len(trace) <= 16
        assert [r['ordinal'] for r in trace] == expected_trace
        assert regs[0] == n and regs[2] == w and regs[8] == residual
        traces.append(trace)
    return original, old_graph, corrected, dict(
        status='EXACT_REPAIR_AND_LITERAL_HALT_TRACE_PASS', variants=results,
        changed_guarded_edges=differences, old_return=23, repaired_return=0,
        halt_steps_including_CH=16, traces=traces)


def verify_bootstrap(rows, graph):
    path = ROOT / 'inputs/archived-biased.native.tm'
    table = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, direction, z = line.split()
        key = int(q), int(b)
        assert key not in table and direction in ('L', 'R')
        table[key] = int(w), 1 if direction == 'R' else -1, int(z)
    assert len(table) == 430 and len({q for q, _ in table}) == 215
    f = json.loads((ROOT / 'inputs/archived-blank-prefix.json').read_text())['startup_frames'][0]
    assert f['steps'] == 69744
    values = [None] * 9
    for i, j in enumerate((6, 2, 0, 4, 3, 7, 8, 5, 1)):
        values[j] = f['logical'][i]
    expected = {-1, 64} | {i for i, b in enumerate(rows[64][0]) if b == '1'}
    pos = 65
    for value in values + f['spares']:
        pos += 1
        expected.update(range(pos, pos + value + 1))
        pos += value + 1
    expected = {x - 2 for x in expected}
    assert expected == set(f['one_cells'])
    q, head, ones = 74, 0, set()
    for _ in range(f['steps']):
        w, direction, q = table[q, int(head in ones)]
        if w: ones.add(head)
        else: ones.discard(head)
        head += direction
    assert (q, head, ones) == (84, -2, expected)
    pc, regs = 25, [1, 0, 3, 0, 0, 0, 0, 0, 0]
    for _ in range(172):
        pc, regs = step(graph, pc, regs)
        assert pc is not None
    assert pc == 64 and regs == f['logical']
    return dict(status='ARCHIVED_WHOLE_BLANK_PREFIX_PASS', transitions=69744,
                state=q, head=head, source_ordinal=64, source_AX_entry=25,
                source_AX_seed=[1, 0, 3, 0, 0, 0, 0, 0, 0],
                source_prefix_steps=172, spare_count=len(f['spares']),
                scope='Original rejected table only; does not certify a repaired binary initializer.')


def verify_arithmetic(graph):
    reads = 0
    for n in range(256):
        for b in (0, 1, 2):
            regs = [7, 5, 11, 0, 13, 17, b, 0, n]
            pc, out, _ = run_until(graph, 9, regs, 23)
            a, r = unpairing(n + b * (b + 1) // 2)
            assert pc == 23 and out == [7, 5, 11, a, 13, 17, 0, 0, r]
            reads += 1
    refills = 0
    for n in range(32):
        for b in (0, 1):
            regs = [n, 5, 11, 0, 13, 17, b, 0, 0]
            pc, out, _ = run_until(graph, 0, regs, 9)
            assert pc == 9 and out == [n + b + 1, 5, 11, 0, 13, 17, 0, 0, n]
            refills += 1
            regs[-1] = n + 1
            pc, out, _ = run_until(graph, 0, regs, 9)
            assert pc == 9 and out == [n, 5, 11, 0, 13, 17, b, 0, n]
    shifts = 0
    for t, w, d, h in product(range(4), range(12), range(3), range(5)):
        regs = [7, t, w, 0, d, h, 0, 0, 19]
        pc, out, _ = run_until(graph, 4698, regs, 0)
        if h == 1:
            assert pc is None
        else:
            a, v = unpairing(w)
            assert pc == 0 and out == [7, h, v, 0, d, a, 0, 0, 19]
        shifts += 1
    return dict(status='FINITE_PRIMITIVE_CORROBORATION_PASS', biased_read_cases=reads,
                refill_cases=refills, positive_residual_cases=refills, short_S_cases=shifts)


def verify_wire():
    alphabet = [S, MP(0), MP(2), AX(), AX(1, 2, 1)]
    words = 0
    for size in range(4):
        for prefix in product(alphabet, repeat=size):
            for last in [AX(), MP(0)]:
                word = list(prefix) + [last]
                for b in (0, 1):
                    r = encode(word, b)
                    for expected in word:
                        before = r
                        actual, r = read_continuation(r, b)
                        assert actual == expected and r < before
                        b = beta(actual)
                    assert r == 0
                    words += 1
    assert encode([S], 1) == 0  # The real terminal-S alias, not silently discarded.
    synchronized = 0
    for R, v, x in product(range(1, 33), range(5), range(2, 10)):
        z = pairing(v, R)
        r = pairing(1, z)
        b = 1 + pairing(x, r)
        q = pairing(0, b)
        assert q - 1 == pairing(1, b - 1)
        k1, rest1 = read_raw(q)
        k2, rest2 = read_continuation(rest1, beta(k1))
        assert (k1, k2, rest2, beta(k2)) == (S, AX(x - 2, v, 1), R, 1)
        l1, rest1 = read_raw(q - 1)
        l2, rest2 = read_continuation(rest1, beta(l1))
        assert (l1, l2, rest2, beta(l2)) == (MP(x), MP(v), R, 1)
        synchronized += 1
    assert unpairing(3) == (2, 0) and 2 == 4 * pairing(0, 0) + 2
    return dict(status='FINITE_WIRE_AND_SYNCHRONIZER_CORROBORATION_PASS',
                encoded_words_and_biases=words, adjacent_pairs=synchronized,
                terminal_S_zero_alias=True, safe_tail_identity='3=P(Q_0(0),0)')


def main():
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError('Assertions must be enabled')
    provenance = json.loads((ROOT / 'provenance.json').read_text())
    for collection in ('inputs', 'repaired_sources', 'inherited_proof_references'):
        for name, expected in provenance[collection].items():
            assert sha(ROOT / name) == expected, ('pinned input digest', name)
    assert sha(ROOT / 'checks/inherited_stack_contracts.py') == provenance['inherited_stack_checker']['sha256']
    rows, old, corrected, source = verify_source()
    report = dict(status='PASS', source=source,
                  archived_bootstrap=verify_bootstrap(rows, old),
                  arithmetic=verify_arithmetic(corrected), wire=verify_wire(),
                  scope='Exact finite source identities and whole blank prefix; bounded arithmetic/wire corroboration. No new binary runtime or ZFC comparison proof.')
    manifest = {str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT / 'inputs').glob('*'))}
    report['input_sha256'] = manifest
    out = ROOT / 'evidence/verification.json'
    out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('source', 'input_sha256')}, indent=2))
    print('Full guarded-edge comparison and halt trace:', out.relative_to(ROOT))


if __name__ == '__main__':
    main()
