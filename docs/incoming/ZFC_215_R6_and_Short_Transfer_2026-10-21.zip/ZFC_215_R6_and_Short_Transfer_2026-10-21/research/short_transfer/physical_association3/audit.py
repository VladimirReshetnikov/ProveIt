#!/usr/bin/env python3
"""Exact static association-3 audit. Seeded runtime is separate; blank initialization fails.
Python 3.10+, standard library. This command does not run a source search.
"""
from pathlib import Path
from collections import Counter
import argparse,gzip,hashlib,json,re,sys
HERE=Path(__file__).resolve().parent
MACHINE=HERE.parents[2]/'machine215'
sys.path.insert(0,str(MACHINE/'vendor/source'))
import source_language as s

def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
 T={};start=None
 for line in raw.decode().splitlines():
  if not line:continue
  if line.startswith('#'):
   m=re.fullmatch(r'#! start (\d+)',line)
   if m:start=int(m[1])
   continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  assert(q,b)not in T and b in(0,1)and w in(0,1)and d in('L','R')
  T[q,b]=(w,1 if d=='R'else-1,z)
 states={q for q,b in T};assert len(states)==215
 assert set(T)=={(q,b)for q in states for b in(0,1)}
 assert{z for w,d,z in T.values()}-states=={254}
 return T,start

def refinement(T,mirror=False):
 states={q for q,b in T};halt=next(iter({z for w,d,z in T.values()}-states))
 color={q:'working'for q in states};color[halt]='halt'
 for iteration in range(1,216):
  color={**{q:sha(repr(tuple((w,-d if mirror else d,color[z])for w,d,z in(T[q,0],T[q,1]))).encode())for q in states},halt:'halt'}
  yield Counter(color.values())

def blank_ray(T,start):
 ones=set();head=0;q=start;trace=[]
 for tick in range(1000):
  assert q!=254,'A blank start halted'
  read=int(head in ones);w,d,z=T[q,read]
  if read==0 and q==z and(not ones or(d==1 and head>max(ones))or(d==-1 and head<min(ones))):
   return {'start':start,'steps':tick,'state':q,'head':head,'read':read,'write':w,'direction':d,'one_cells':sorted(ones),'proof':'State self-loops on zero and moves strictly beyond the finite tape support; every subsequent scanned cell is zero.','trace':trace}
  trace.append([q,head,read,w,d,z])
  if w:ones.add(head)
  else:ones.discard(head)
  q=z;head+=d
 raise AssertionError(('Blank ray not derived',start))

def audit():
 recipe=json.loads((HERE/'recipe.json').read_text())
 raw=(HERE/recipe['candidate_table']).read_bytes();oldraw=(HERE/recipe['baseline_table']).read_bytes()
 assert sha(raw)==recipe['candidate_table_sha256']and sha(oldraw)==recipe['baseline_table_sha256']
 T,start=parse(raw);B,oldstart=parse(oldraw);assert start==oldstart==recipe['declared_start']==74
 assert set(T)==set(B)
 runtime_raw=(HERE/recipe['runtime_receipt']).read_bytes();runtime_recipe_raw=(HERE/recipe['runtime_recipe']).read_bytes()
 assert sha(runtime_raw)==recipe['runtime_receipt_sha256']and sha(runtime_recipe_raw)==recipe['runtime_recipe_sha256']
 runtime=json.loads(runtime_raw);runtime_recipe=json.loads(runtime_recipe_raw)
 assert runtime['status']=='ALL_NATURAL_RUNTIME_PASS'and runtime['cases']==6152 and runtime['row_coverage']==430
 assert runtime_recipe['table_sha256']==sha(raw)and runtime_recipe['source_sha256']==recipe['candidate_source_sha256']
 replacements=recipe['replacement_rows'];N=dict(B)
 for row in replacements:
  key=row['state'],row['read'];assert N[key]==tuple(row['before']);N[key]=tuple(row['after'])
 assert N==T and len(replacements)==9
 rebuilt=[]
 for line in oldraw.decode().splitlines():
  if not line or line.startswith('#'):rebuilt.append(line);continue
  q,b,*_=line.split();w,d,z=N[int(q),int(b)]
  rebuilt.append(f'{q} {b} {w} {"R"if d==1 else"L"} {z}')
 assert ('\n'.join(rebuilt)+'\n').encode()==raw
 source=(HERE/recipe['candidate_source']).read_bytes();oldsource=(HERE/recipe['baseline_source']).read_bytes()
 assert sha(source)==recipe['candidate_source_sha256']and sha(oldsource)==recipe['baseline_source_sha256']
 parent=(HERE/recipe['association_source']).read_bytes();assert source==parent and sha(parent)==recipe['association_source_sha256']
 rows=json.loads(source);oldrows=json.loads(oldsource);root=s.tree(rows)
 assert [x[1:]for x in rows]==[x[1:]for x in oldrows]
 graph=s.graph_intervals(rows);assert graph==s.graph_arithmetic(rows)[0]
 corrected=json.loads((HERE.parent/'repaired-CC4.sites.json').read_text());assert graph==s.graph_intervals(corrected)==s.graph_arithmetic(corrected)[0]
 oldgraph=s.graph_intervals(oldrows);assert oldgraph==s.graph_arithmetic(oldrows)[0]
 source_changes=[{'index_zero_based':i,'before':a,'after':b}for i,(a,b)in enumerate(zip(oldgraph,graph))if a!=b]
 assert len(source_changes)==1 and source_changes[0]['index_zero_based']==4697
 frozen_raw=(HERE/recipe['graph_corpus']).read_bytes();assert sha(frozen_raw)==recipe['graph_corpus_sha256']
 frozen=json.loads(gzip.decompress(frozen_raw));assert len(frozen)==43
 otherraw=(HERE/recipe['R6_table']).read_bytes();assert sha(otherraw)==recipe['R6_table_sha256'];R6,_=parse(otherraw)
 reference=list(refinement(T));comparisons=[]
 tables=[(item['source'],{(q,b):(w,d,z)for q,b,w,d,z in item['rows']})for item in frozen]
 tables += [('delivered_R6',R6)]
 for name,other in tables:
  receipt={'graph':name}
  for mirrored in(False,True):
   mismatch=next((i for i,(left,right)in enumerate(zip(reference,refinement(other,mirrored)),1)if left!=right),None)
   assert mismatch is not None,('No distinction established',name,mirrored)
   receipt['first_difference_reflected'if mirrored else'first_difference_ordinary']=mismatch
  comparisons.append(receipt)
 rays=[blank_ray(T,q)for q in sorted({q for q,b in T})]
 # The finite transition graph has all 215 states reachable from the declared
 # start when both read-symbol edges are allowed. This is not blank reachability.
 reached={start};todo=[start]
 for q in todo:
  for b in(0,1):
   z=T[q,b][2]
   if z!=254 and z not in reached:reached.add(z);todo.append(z)
 return {'status':'EXACT_STATIC_ROW_SOURCE_AND_GRAPH_AUDIT_PASS','runtime_status':recipe['runtime_status'],'initialization_status':recipe['initialization_status'],'scope':recipe['scope'],'candidate_table_sha256':sha(raw),'candidate_source_sha256':sha(source),'states':215,'rows':430,'changed_rows':9,'declared_start':start,'graph_reachable_working_states':len(reached),'source_metrics':s.metrics(root),'changed_primitive_addresses':sum(a[0]!=b[0]for a,b in zip(oldrows,rows)),'guarded_cases':sum(2 if x[1]=='CD'else 1 for x in rows),'guarded_successor_edges':sum(len(x[1])for x in graph),'source_cfg_changes_from_archived':source_changes,'comparison_graph_groups':len(frozen),'comparison_table_files':sum(len(x['equivalent_input_files'])for x in frozen),'also_distinct_from_R6':True,'comparisons':comparisons,'blank_start_ray_census':{'starts_checked':len(rays),'all_starts_reach_exact_outward_ray':True,'maximum_prefix_steps':max(x['steps']for x in rays),'declared_start_witness':next(x for x in rays if x['start']==start),'scope':'Finite literal proof of outward drift for this exact unmodified table. No safe blank bootstrap exists by merely selecting an existing working state.'}},rays

def main():
 assert __debug__ and not sys.flags.optimize,'Do not run with -O or PYTHONOPTIMIZE.'
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--write',action='store_true');args=ap.parse_args();receipt,rays=audit()
 if args.write:
  (HERE/'audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
  (HERE/'all_blank_starts.json.gz').write_bytes(gzip.compress((json.dumps(rays,indent=2)+'\n').encode(),mtime=0))
 print(json.dumps({k:v for k,v in receipt.items()if k not in('comparisons','blank_start_ray_census')},indent=2))
 print('All 215 existing blank starts provably enter outward rays; maximum prefix:',max(x['steps']for x in rays),flush=True)
if __name__=='__main__':main()
