# Association 3: independent static and blank-start audit

**Status: seeded runtime proved in the sibling `runtime215` packet;
blank initialization rejected for this exact table at every existing start.**
This is research evidence for a 215-state runtime implementation, not an
additional accepted blank-start ZFC-consistency machine.

The literal implementation changes nine transition rows of the archived
biased table, retains 215 working states and 430 rows, and realizes the third
source association in the parent `short_transfer` packet. All 4,733 primitive
addresses change. The ordered primitive word is unchanged. Compared with the
archived source, exactly one guarded successor site changes: the CC3 return
at zero-based index 4697 goes to scheduler index 0 rather than selector index
23. Both complete source CFG resolvers agree with the repaired CC4 source.

The source has 201 distinct DAG nodes, maximum depth 43 and maximum zero-run
six. These are source counts, not an explanation of the physical state count.

## Exact physical recipe

Each entry is `write, move, target`. All unspecified rows remain unchanged.

| State/read | Archived action | New action |
|---|---|---|
| 26/0 | 0 R 134 | 0 R 194 |
| 84/0 | 0 R 188 | 0 R 310 |
| 84/1 | 1 R 310 | 1 R 312 |
| 134/0 | 0 R 17 | 0 R 95 |
| 134/1 | 1 R 311 | 1 R 188 |
| 188/0 | 0 R 95 | 0 R 111 |
| 188/1 | 1 R 111 | 1 R 17 |
| 214/1 | 1 R 122 | 1 R 311 |
| 310/1 | 1 R 312 | 1 R 122 |

The 26/0 change moves a shared CD8 engine-helper use away from the repurposed
state 134. The old 134/0 and unchanged 194/0 both implement 0 R 17.

Native table SHA-256:

```text
a86844babd14de9e0d7709e0bdf51356fcce82c41e9abba7fbc7aa0b5abade0e
```

Source SHA-256:

```text
c7cc8c1cafb32b3159665252e977475b503166ee06715be78fd36b7ec235418d
```

## What the audit establishes

Run from any directory, using Python 3.10 or later with assertions enabled:

```sh
python3 -B /path/to/physical_association3/audit.py
```

The script independently parses the native table, applies the exact row
recipe to its archived parent, and requires byte-for-byte reconstruction. It
checks the source, both guarded CFGs, and its literal identity with the
parent's association-3 repair. It then checks graph distinction against all
43 frozen representative graphs covering 311 archived table files, and also
against the delivered R6 machine. Iterated successor-color multisets differ
both ordinarily and after global tape reflection; the comparison does not
fix the initial state.

Finally, the script literally runs the blank tape from **each of the 215
existing working states**. Every run reaches a state that loops on zero and
moves strictly outward beyond all existing one cells. The longest finite
prefix is 53 transitions. The declared start 74 reaches such a ray after
49 transitions. The complete finite tapes and event traces are recorded in
`all_blank_starts.json.gz`. This is a finite proof of unconditional drift for
these starts, not merely a bounded failure to find a good seed. Selecting a
different existing start cannot repair this exact table's initialization.

The inherited generic primitive-runtime induction has meanwhile passed all
6,152 cases, using 1,587,125 symbolic rules, all 430 native rows, and minimum
affine duration constant 5. Its complete evidence and portable fresh replay
are owned by `../runtime215/`; this audit binds that sibling report to the
same literal table and source. It does not independently rederive those
symbolic cases.

`audit.py --write` refreshes this directory's static audit and compressed
finite ray witnesses. It does not modify the frozen `machine215` packet or
any parent source. Any later bootstrap repair changes the table or its
initialization architecture and requires new runtime and exact blank-frame
checks.

Original source ancestry and licensing are preserved in the parent
`short_transfer` and sibling `machine215` packets. The independent audit is
independent code written within this collaboration, not an external review.

## Bounded bootstrap search

A separate 155-second experiment considered 6,756 new physical rotation tables
over 14 beam rounds using an inherited protected-engine-row synthesis filter.
It found no complete calibrated root frame. The best declared-start trajectory
still reached an outward ray after 55 transitions. The search primarily tests
start 74, with selective alternate-start checks; it is not an exhaustive
initialization search and supplies no impossibility theorem. Its receipt is
`rotation_search.json`. The portable optional `rotation_search.py` accepts
`--output` (a fresh directory) and `--seconds`; its wall-clock cutoff means
reruns need not visit the identical frontier. No further runtime certificate
is claimed for the rejected rotation tables.
