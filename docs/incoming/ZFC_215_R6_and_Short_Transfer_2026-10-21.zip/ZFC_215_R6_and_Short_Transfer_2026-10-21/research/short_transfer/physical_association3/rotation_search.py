#!/usr/bin/env python3
"""Optional bounded bootstrap search. This is synthesis, not a correctness proof.
Portability-only adaptation of the recorded 155-second experiment.
"""
from pathlib import Path
from functools import cache
from collections import defaultdict
import sys,json,time,random,hashlib,argparse
HERE=Path(__file__).resolve().parent
MACHINE=HERE.parents[2]/'machine215'
FILTER=HERE.parents[1]/'zero5/evidence/frozen_engine_rows219.json'
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--seconds',type=float,default=155);args=ap.parse_args()
OUT=args.output;OUT.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(MACHINE/'vendor/source'))
import source_language as s,build221 as b
raw=(HERE/'implementation.native.tm').read_bytes();T0=b.read_table(raw.replace(b'#! start 74',b'#! start 0'));r0=s.tree(json.loads((HERE/'source.sites.json').read_text()));reference=s.graph_intervals(s.sites(r0))
P={tuple(x)for x in json.loads((FILTER).read_text())['rows']};P.discard((92,1));P.discard((134,0));P|={(26,0),(194,0),(81,0),(111,0),(111,1),(104,0),(128,0)}
G0,paths0=b.decoder_map(T0,r0)
for q,ps in paths0.items():
 for p in ps:
  n=s.subtree(r0,p)
  for bit,ch in enumerate(n):
   if s.leaf(ch):continue
   tape={-1:1,**{i:int(v)for i,v in enumerate(p+str(bit))}};h=len(p);state=q
   for i in range(100):
    if h==len(p)+1:break
    k=(state,tape[h]);w,d,state=T0[k];tape[h]=w;h+=d
    if i:P.add(k)

def rep(r,old,new):
 @cache
 def go(n):
  if n==old:return new
  if s.leaf(n):return n
  return go(n[0]),go(n[1])
 return go(r)
def moves(T,r):
 try:g,ps=b.decoder_map(T,r)
 except Exception:return
 for q,ns in g.items():
  if len(ns)!=1 or any((q,k)in P or T[q,k][:2]!=(k,1)for k in(0,1)):continue
  n=next(iter(ns))
  for dr in(0,1):
   ch=n[dr]
   if s.leaf(ch):continue
   j=T[q,dr][2]
   if len(g[j])!=1 or next(iter(g[j]))!=ch or len(ps[j])!=len(ps[q]):continue
   if any((j,k)in P or T[j,k][:2]!=(k,1)for k in(0,1)):continue
   if dr==0:
    (A,B),C=n
    if s.boundary(A)[0]or s.boundary(C)[1]:continue
    nn=A,(B,C);aa,bb,cc=T[j,0][2],T[j,1][2],T[q,1][2];changes={(q,0):(0,1,aa),(q,1):(1,1,j),(j,0):(0,1,bb),(j,1):(1,1,cc)}
   else:
    A,(B,C)=n
    if s.boundary(A)[0]or s.boundary(C)[1]:continue
    nn=(A,B),C;aa,bb,cc=T[q,0][2],T[j,0][2],T[j,1][2];changes={(q,0):(0,1,j),(q,1):(1,1,cc),(j,0):(0,1,aa),(j,1):(1,1,bb)}
   yield T|changes,rep(r,n,nn),(q,j,dr)
def frame(ones,h):
 if not ones or min(ones)!=h-1:return None
 rights=sorted(x for x in ones if x>h-1)
 if not rights or rights[0]<h+64:return None
 header=rights[0];p=header+1;last=max(ones);v=[]
 while p<=last:
  if p in ones or p+1 not in ones:return None
  p+=1;n=0
  while p in ones:n+=1;p+=1
  v.append(n-1)
 if len(v)<10:return None
 logical=[v[j]for j in(6,2,0,4,3,7,8,5,1)]
 return {'logical':logical,'spares':v[9:],'head':h,'header':header,'gap':header-h-64,'safe_formula_registers':logical[1]==logical[2]==logical[5]==0}
def run(T,start,limit):
 q=start;h=0;ones=set();used=set();seen=set();high=0
 for tick in range(limit):
  if q==254:return {'status':'HALT','start':start,'tick':tick},used
  if q==84:
   fr=frame(ones,h)
   if fr:return {'status':'FRAME','start':start,'tick':tick,**fr,'one_cells':sorted(ones)},used
  rd=int(h in ones);w,d,z=T[q,rd];used.add((q,rd))
  if not rd and z==q and(not ones or(d==1 and h>max(ones))or(d==-1 and h<min(ones))):return {'status':'RAY','start':start,'tick':tick,'ones':len(ones)},used
  if tick<2000:
   conf=(q,h,tuple(sorted(ones)))
   if conf in seen:return {'status':'LOOP','start':start,'tick':tick,'ones':len(ones)},used
   seen.add(conf)
  if w:ones.add(h)
  else:ones.discard(h)
  q=z;h+=d
 return {'status':'LIMIT','start':start,'tick':limit,'ones':len(ones),'state':q,'head':h},used

def key(T):return tuple(T[k]for k in sorted(T))
def main():
 starttime=time.monotonic();deadline=starttime+args.seconds;random.seed(20261021)
 seen={key(T0)};beam=[(T0,r0,[])];best=-1;tried=0;record=[];rounds=0
 while time.monotonic()<deadline:
  cand=[]
  for T,r,hist in beam:
   oldrun,used=run(T,74,10000)
   for TT,rr,move in moves(T,r):
    if time.monotonic()>deadline:break
    k=key(TT)
    if k in seen:continue
    seen.add(k);tried+=1;hh=hist+[move]
    metric=s.metrics(rr)
    if metric['maximum_zero_run']>6 or metric['maximum_depth']>64:continue
    result,_=run(TT,74,10000)
    merit=result['tick']+100*result.get('ones',0)
    # Explore alternate existing starts only if the seed trajectory changed.
    if result['status']not in('RAY','LOOP','HALT'):
     results=[result]
     if result['status']=='LIMIT':results[0],_=run(TT,74,700000)
     for ss in sorted({q for q,b in TT}):
      if ss==74:continue
      temp,_=run(TT,ss,1000)
      if temp['status']=='FRAME':results.append(temp);break
     for got in results:
      if got['status']=='FRAME':
       rows=s.sites(rr);assert s.graph_intervals(rows)==s.graph_arithmetic(rows)[0]==reference;b.decoder_map(TT,rr)
       name=f'hit{len(record)}';(OUT/(name+'.tm')).write_bytes(b.table_bytes(TT,start=got['start']));(OUT/(name+'.sites.json')).write_bytes(s.compact(rows));got['rotations']=hh;got['file']=name;record.append(got);print('HIT',got,flush=True)
       if got['safe_formula_registers']:(OUT/'result.json').write_text(json.dumps({'status':'FRAME_FOUND','hit':got,'seconds':time.monotonic()-starttime,'tried':tried},indent=2));return
    if merit>best:best=merit;print('BEST',tried,merit,result,hh,flush=True)
    cand.append((merit,random.random(),TT,rr,hh))
   if time.monotonic()>deadline:break
  if not cand:break
  cand.sort(key=lambda x:(-x[0],x[1]));beam=[(T,r,h)for _,_,T,r,h in cand[:18]];rounds+=1
 receipt={'status':'NO_CALIBRATED_BOOTSTRAP_FOUND','seconds':time.monotonic()-starttime,'tried':tried,'unique_tables':len(seen),'rounds':rounds,'best_score':best,'frames':record,'scope':'Bounded physical decoder rotations with inherited engine-row synthesis filter. No impossibility claim.'}
 (OUT/'result.json').write_text(json.dumps(receipt,indent=2));print(receipt,flush=True)
if __name__=='__main__':main()
