# Eliminating every six-zero source address

This research companion supplies a source tree with **206 distinct DAG nodes,
4,751 primitive occurrences, maximum depth 41, and maximum run of five zeros
in any primitive address**. It preserves the primary K215 primitive word and
its entire guarded control-flow graph. This is a source-level construction;
no 214-state or 215-state physical Turing machine implementing this tree is
claimed.

The independently verified physical candidate in `../../machine215` uses a
different, 202-node source tree with maximum zero-run six. Keep these results
separate.

## Why this target matters

In the primary K215 decoder/engine design, the header scanner distinguishes a
sufficiently long block of zeros from program-address bits. A direct deletion
of scanner state 50 shortens its threshold from eight zeros to seven. That
change can pass a blank-prefix experiment and still misexecute a primitive:
return processing transiently adds a zero next to the terminal six-zero
address suffix. This observation motivated eliminating six-zero source
addresses before attempting the physical reduction. A five-zero address bound
removes that observed source-pattern obstruction; it does **not** by itself
prove the shortened scanner or a physical allocation correct.

The repository's incoming `ZFC_Encoding_Research` packet already explores
source rotations and this scanner issue. The present contribution is the
concrete, fully replayable 206-node source and the recorded frontier below,
not a claim to have originated source rotation or the general scanner idea.

## Reproduce the finite result

Keep this directory at `research/zero5` beside the delivered `machine215`
directory. Python 3.10 or newer is sufficient; no third-party package is needed
for verification.

```sh
python3 -B research/zero5/verify.py
```

The verifier checks every recorded rotation, its open-sided boundary
conditions, the unchanged ordered primitive word, and **both independent
complete guarded-CFG resolvers after each step**. It checks exact final source
bytes and hashes, and audits the limited scope of the saved allocation result.
It performs no search and writes no output files.

To obtain ordinary uncompressed source files in a fresh directory:

```sh
python3 -B research/zero5/verify.py --out /tmp/zero5-sources
```

This exports `zero5-206-depth41.json`, the earlier
`zero5-206-depth44.json`, and the useful one-defect `onebad-205.json`.

The logical source format is exactly the format used by the delivered primary
K215 checker: JSON rows `[binary_address, opcode, argument]`, in ordinal order.
DAG node counts include distinct primitive leaves as well as pairs. A source
DAG node count is not a physical-machine state count.

## Recorded frontier

The first search considered open-sided associativity rotations and reached
these source shapes. Every row retains the same 4,751 primitive occurrences.

| DAG nodes | Addresses containing six zeros | Maximum address depth | Rotations from primary K215 |
|---:|---:|---:|---:|
| 202 | 31 | 46 | 6 |
| 203 | 18 | 45 | 10 |
| 204 | 5 | 44 | 10 |
| 205 | 1 | 44 | 10 |
| 206 | 0 | 44 | 10 |
| 207 | 0 | 44 | 10 |

A second search, restricted to maximum zero-run five, reduced the depth of the
206-node tree to 41 with 22 further rotations. A 207-node depth-41 tree is
included as well. No 205-node source with zero such addresses was found.
These are search results, not optimality results.

The source/recipe files in `frontier/` and `compact/` use deterministic gzip
compression. Each recipe stores the complete old and new subtrees and the
rotation direction. Direction 0 is `((A,B),C) -> (A,(B,C))`; direction 1 is its
inverse. The conditions are `br(A)=0` and `co(C)=0`; the middle subtree may be
open. Those conditions and the proof are inherited from the pinned
repository's `k219-source-search/proof.md` and `candidate-k221/code/rot_lib.py`.
The first of those is included in `../../machine215/proofs`.

The source-preservation claim is stronger than preservation on a few register
samples. Both resolvers produce the same guard-labelled ordinal successor
at every primitive site. Since the primitive operations are unchanged, this
establishes identical source runs for all initial natural-number registers.
The checker's no-stray-successor conditions are also enforced.

## What the allocation experiment does and does not show

`evidence/allocation.json` records a failed attempt to implement the **earlier
206-node depth-44 source** using an inherited fixed-engine role-pool policy.
It fixes 68 reusable logical nodes at 64 physical states, introduces 115
newly allocated logical nodes, protects 152 transition rows, and allows 12
fresh physical labels. The resulting mixed-integer feasibility model has
12,106 variables and 287 constraints. HiGHS reported it infeasible.

This only rejects that deliberately conservative allocation model. The
protected-row filter is inherited from an older candidate and is not a
current universal engine proof. Context-dependent entry states, changing
physical engine rows, or a different decoder may evade its restrictions.
The result is **not** a lower bound of any kind on Turing-machine size, and
neither physical runtime nor blank startup has been established for these
research source trees. The depth-41 tree was not subjected to a new allocator
search.

The saved receipt's absolute paths and original code hash are historical
provenance. The delivered tools use paths relative to this packet.

## Optional research programs

The recorded results can be verified without these programs. For future work,
portable copies of the two searches and the restricted allocator are included:

```sh
python3 -B research/zero5/source_search.py --seconds 55 --output /tmp/zero5-search
python3 -B research/zero5/compact_search.py --seconds 55 --output /tmp/zero5-compact
python3 -B research/zero5/price.py --source /tmp/zero5-sources/zero5-206-depth44.json --fresh 12 --limit 30 --output /tmp/zero5-price
```

The searches accept `--source`; the defaults select the pinned baseline and
the recorded initial 206-node source respectively. Search stopping depends
on wall-clock time, so a rerun need not yield the same frontier. Exact
reconstruction uses the saved recipes. The allocator additionally requires
NumPy and SciPy with `scipy.optimize.milp`; neither package is required by the
verifier. All output directories must be new.

## Files and attribution

`recipe.json` pins every compressed and uncompressed recorded source/recipe,
the primary baseline commit, and the original research-script hashes.
`manifest.json` covers the delivered companion's file bytes.
`evidence/initial_search.json` and `evidence/compact_search.json` are the
original finite search receipts. The saved searches considered 27,523 roots
and 125,570 roots respectively; only 68,607 roots passed the latter search's
storage and zero-run filters.

The source syntax, boundary functions, and two control-flow resolvers are
used unchanged from the pinned ProveIt candidate. The allocator is adapted
from its role-pool construction, and retains its limited synthesis scope.
All inherited source and licensing notices are preserved in the sibling
`machine215` packet; its `NOTICE.md` and `licenses/` apply to the shared files.
This companion's original work consists of the concrete rotations, saved
research frontiers, portability wrappers, and replay audit. It does not add
a new foundational equiconsistency argument or a formal proof-assistant
endpoint.
