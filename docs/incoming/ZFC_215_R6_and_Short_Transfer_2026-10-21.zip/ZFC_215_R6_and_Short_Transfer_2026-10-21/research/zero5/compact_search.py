#!/usr/bin/env python3
"""Optional time-limited research search; recorded outputs are replayed by verify.py.
Portability-only changes to the search used for the saved evidence.
"""
from pathlib import Path
from functools import cache
import sys,json,time,random,argparse,gzip
HERE=Path(__file__).resolve().parent
PACKET=HERE.parents[1]/'machine215'
sys.path.insert(0,str(PACKET/'vendor/source'))
import source_language as s
nodes=[];ids={}
def intern(n):
 if n not in ids:ids[n]=len(nodes);nodes.append(n)
 return ids[n]
def enc(t):return intern(t if s.leaf(t)else(enc(t[0]),enc(t[1])))
def leaf(n):return isinstance(nodes[n][0],str)
@cache
def dec(n):return nodes[n]if leaf(n)else(dec(nodes[n][0]),dec(nodes[n][1]))
@cache
def bound(n):
 if leaf(n):
  op,arg=nodes[n]
  return (1,0)if op=='CD'else(arg,0)if op=='CB'else(0,arg)if op=='CC'else(0,0)
 a,b=map(bound,nodes[n]);return max(max(a[0]-1,0),b[0]),max(a[1],max(b[1]-1,0))
@cache
def stat(n,run=0,high=0):
 high=max(high,run)
 if leaf(n):return (int(high>=6),max(high-5,0),high,0)
 a=stat(nodes[n][0],run+1,high);b=stat(nodes[n][1],0,high)
 return (a[0]+b[0],a[1]+b[1],max(a[2],b[2]),max(a[3],b[3])+1)
def reach(n):
 seen=set();todo=[n]
 for x in todo:
  if x in seen:continue
  seen.add(x)
  if not leaf(x):todo.extend(nodes[x])
 return seen
def rep(root,old,new):
 memo={}
 def go(n):
  if n==old:return new
  if leaf(n):return n
  if n not in memo:memo[n]=intern(tuple(go(c)for c in nodes[n]))
  return memo[n]
 return go(root)
def moves(root):
 for n in sorted(reach(root)):
  if leaf(n):continue
  l,r=nodes[n]
  if not leaf(l):
   a,b=nodes[l];c=r
   if not bound(a)[0] and not bound(c)[1]:yield n,intern((a,intern((b,c)))),0
  if not leaf(r):
   a=l;b,c=nodes[r]
   if not bound(a)[0] and not bound(c)[1]:yield n,intern((intern((a,b)),c)),1

def main():
 random.seed(20261021);ap=argparse.ArgumentParser();ap.add_argument('--seconds',type=int,default=55);ap.add_argument('--source',type=Path,default=HERE/'frontier/zero5-206.json.gz');ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();raw0=gzip.decompress(a.source.read_bytes())if a.source.suffix=='.gz'else a.source.read_bytes();tree0=s.tree(json.loads(raw0));start=time.monotonic();base=enc(tree0);beam=[base];seen={base};parents={};scores={base:(len(reach(base)),*stat(base))};best=base;stats={};out=a.output;out.mkdir(parents=True,exist_ok=False);rounds=0
 while time.monotonic()-start<a.seconds:
  cand=set(beam)
  for root in beam:
   for old,new,di in moves(root):
    rr=rep(root,old,new)
    if rr in seen:continue
    seen.add(rr);count=len(reach(rr))
    if count>207:continue
    sc=(count,*stat(rr))
    if sc[4]>64 or sc[3]>5:continue
    scores[rr]=sc
    cand.add(rr);parents[rr]=(root,old,new,di)
    k=(count,sc[1])
    if k not in stats:stats[k]=rr
    if sc[1]<scores[best][1]or(sc[1]==scores[best][1]and sc[0]<scores[best][0]):
     best=rr;print('best',sc,'round',rounds,'nodes',len(nodes),flush=True)
   if time.monotonic()-start>=a.seconds:break
  beam=[]
  for w in (0,0.5,1,2,4,8,16,32):
   sort=sorted(cand,key=lambda r:(scores[r][0],scores[r][4]+w*random.random(),r))
   for r in sort[:5]:
    if r not in beam:beam.append(r)
  rounds+=1
  if not beam:break
 # Pareto frontier per DAG count
 frontier=[]
 for c in range(200,209):
  vals=[r for r in scores if scores[r][0]==c]
  if vals:
   rr=min(vals,key=lambda r:(scores[r][2],scores[r][1],scores[r][3],scores[r][4],r));t=dec(rr);rows=s.sites(t);assert[x[1:]for x in rows]==[x[1:]for x in json.loads(raw0)]
   assert s.graph_intervals(rows)==s.graph_arithmetic(rows)[0]==s.graph_intervals(json.loads(raw0))
   name=f'zero5-{c}.json';(out/name).write_bytes(s.compact(rows));hist=[];cur=rr
   while cur!=base:
    p,old,new,di=parents[cur];hist.append({'old':dec(old),'new':dec(new),'direction':di});cur=p
   (out/f'recipe-{c}.json').write_text(json.dumps(list(reversed(hist))))
   frontier.append({'file':name,'score':scores[rr],'rotations':len(hist)})
 result={'frontier':frontier,'seen':len(seen),'roots':len(scores),'seconds':time.monotonic()-start,'rounds':rounds};(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
if __name__=='__main__':
 assert __debug__ and not sys.flags.optimize,'Do not run with -O.'
 main()
