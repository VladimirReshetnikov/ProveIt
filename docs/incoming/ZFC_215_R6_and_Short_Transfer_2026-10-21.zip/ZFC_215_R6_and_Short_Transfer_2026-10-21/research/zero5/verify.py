#!/usr/bin/env python3
"""Replay all saved source rotations and verify the complete ordinal control graphs.
Python 3.10+, standard library only. No search and no physical-machine claim.
"""
from pathlib import Path
from functools import cache
import argparse,gzip,hashlib,json,sys
HERE=Path(__file__).resolve().parent
PACKET=HERE.parents[1]/'machine215'
sys.path.insert(0,str(PACKET/'vendor/source'))
import source_language as s

def sha(raw):return hashlib.sha256(raw).hexdigest()
def frozen(t):return tuple(map(frozen,t))if isinstance(t,list)else t

def replay(initial,recipe,expected,reference):
 root=initial;word=[x[1:]for x in s.sites(initial)]
 for i,step in enumerate(recipe):
  old,new=frozen(step['old']),frozen(step['new']);direction=step['direction']
  assert direction in(0,1)and not s.leaf(old)
  if direction==0:
   assert not s.leaf(old[0]);(A,B),C=old;assert new==(A,(B,C))
  else:
   assert not s.leaf(old[1]);A,(B,C)=old;assert new==((A,B),C)
  assert s.boundary(A)[0]==0 and s.boundary(C)[1]==0
  changed=[]
  @cache
  def replace(t):
   if t==old:changed.append(True);return new
   if s.leaf(t):return t
   return replace(t[0]),replace(t[1])
  root=replace(root);assert changed,('No matching old subtree',i)
  rows=s.sites(root)
  assert [x[1:]for x in rows]==word
  assert s.graph_arithmetic(rows)[0]==s.graph_intervals(rows)==reference
 assert s.compact(s.sites(root))==expected
 return root

def main():
 assert __debug__ and not sys.flags.optimize,'Do not run with -O or PYTHONOPTIMIZE.'
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path);a=ap.parse_args()
 manifest=json.loads((HERE/'manifest.json').read_text())
 actual={str(p.relative_to(HERE)):sha(p.read_bytes())for p in HERE.rglob('*')if p.is_file()and '__pycache__'not in p.parts and p.name!='manifest.json'}
 assert actual==manifest['files'],'Packet manifest mismatch'
 recipe=json.loads((HERE/'recipe.json').read_text())
 source=(PACKET/'baseline/sites215.json').read_bytes();assert sha(source)==recipe['baseline_source_sha256']
 initial=s.tree(json.loads(source));rows=s.sites(initial);reference=s.graph_intervals(rows);assert reference==s.graph_arithmetic(rows)[0]
 saved={}
 for name,pins in recipe['files'].items():
  raw=(HERE/name).read_bytes();assert sha(raw)==pins['compressed_sha256'];data=gzip.decompress(raw);assert sha(data)==pins['raw_sha256'];saved[name]=data
 roots={};receipt=[]
 for family,counts in [('frontier',range(202,208)),('compact',(206,207))]:
  start=initial if family=='frontier'else roots['frontier',206]
  for count in counts:
   key=f'{family}/zero5-{count}.json.gz';steps=json.loads(saved[f'{family}/recipe-{count}.json.gz'])
   root=replay(start,steps,saved[key],reference);roots[family,count]=root;metrics=s.metrics(root);assert metrics['dag_nodes']==count
   bad=[i for i,(p,op,arg)in enumerate(s.sites(root))if '000000'in p]
   receipt.append({'family':family,'dag_nodes':count,'rotations':len(steps),'metrics':metrics,'six_zero_addresses':len(bad),'source_sha256':sha(saved[key])})
 final=roots['compact',206];assert s.metrics(final)=={'dag_nodes':206,'leaf_occurrences':4751,'maximum_depth':41,'maximum_zero_run':5}
 bad205=[{'index_zero_based':i,'ordinal_one_based':i+1,'path':p,'op':op,'arg':arg}for i,(p,op,arg)in enumerate(s.sites(roots['frontier',205]))if '000000'in p]
 assert len(bad205)==1
 allocation=json.loads((HERE/'evidence/allocation.json').read_text());assert allocation['status']=='NO_ALLOCATION'
 assert allocation['source_sha256']==sha(saved['frontier/zero5-206.json.gz'])
 assert allocation['engine_filter']['sha256']==sha((HERE/'evidence/frozen_engine_rows219.json').read_bytes())
 assert allocation['table_sha256']==sha((PACKET/'baseline/k215.native.tm').read_bytes())
 if a.out:
  out=a.out.resolve();assert HERE not in out.parents and out!=HERE,'Output must be outside packet.';out.mkdir(parents=True,exist_ok=False)
  for name,root in [('zero5-206-depth41.json',final),('zero5-206-depth44.json',roots['frontier',206]),('onebad-205.json',roots['frontier',205])]:
   (out/name).write_bytes(s.compact(s.sites(root)))
 print(json.dumps({'status':'ALL_RECORDED_ROTATIONS_AND_BOTH_SOURCE_GRAPHS_PASS','claim':'Source equivalence only; these research trees are not physical TM candidates.','primitive_occurrences':4751,'guarded_successor_edges':sum(len(x[1])for x in reference),'frontier':receipt,'one_bad_address_205':bad205,'allocator_status':allocation['status'],'allocator_scope':'Inherited fixed engine/role policy only; no state-count impossibility conclusion.'},indent=2))
if __name__=='__main__':main()
