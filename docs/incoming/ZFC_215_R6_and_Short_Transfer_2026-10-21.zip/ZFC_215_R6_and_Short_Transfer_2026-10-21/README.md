# ZFC consistency machines: a different 215-state encoding and research toward 214

This contribution is based on ProveIt commit
`75716498437bfc7291d5900cab2983a11fd54bac` and is dated 2026-10-21.

## Completed result

`machine215/machine/rotated215.tm` is an explicit deterministic, binary,
single-tape machine with **215 working states**, a separate halt, and an
entirely blank initial tape. Its ordinary correctness argument establishes,
using the explicitly inherited numerical-calculus/ZFC calibration,

    ZFC proves: not Halt(Rotated215, blank) <=> Con(ZFC).

It changes 17 native transition rows and 4,519 source addresses relative to
primary K215. The ordered primitive word and full guarded control-flow graph
are retained. Its physical transition graph is not a state renaming or global
tape reflection of any of the 43 frozen graph groups representing 311 tables
in the comparison corpus. Its blank initialization takes 716,307 transitions.

The fresh all-natural runtime derivation proves all 6,176 primitive cases,
uses 1,753,058 symbolic rules, and covers all 430 transition rows. A separate
literal replay checks the entire blank prefix and reconstructs the complete
terminal tape, including the zero exterior. The source and table, recipe,
checks, evidence, attribution, and exact proof boundary are self-contained
under `machine215/`.

**No correct 214-state machine is claimed.** The completed result is the
different physical 215-state encoding permitted by the request. It does not
change the underlying numerical calculus, claim worldwide priority, improve
the startup time, or supply a newly compiled Lean/Rocq endpoint.

## Read the report

- `report/report.pdf`: mathematical report with the full dense transition table.
- `report/report.tex` and `report/sections/*.tex`: complete editable LaTeX.
- `machine215/PROOF.md`: proof of the accepted physical candidate, including
  the safe-seed extension for numeric parameter D = 1.

## Research results, with their completion levels

`research/short_transfer/` diagnoses a literal control-flow defect in the
archived scratch-biased short-transfer experiment. Its return reaches the
selector with dirty scratch and causes a halt after the initial AX. Exact
source repairs retain a 201-node source DAG and a 35-primitive transfer.
A stateful wire compiler and new adjacent-code synchronization theorem prove
complete refutation search even when candidate numbers advance by one or two.
The `runtime215/` subfolder adds a complete 215-state runtime implementation:
all 6,152 arbitrary-natural cases and all 430 table rows pass. Its literal
table is nevertheless rejected as a blank consistency machine: every existing
start enters a provable outward ray within 53 steps. Initialization remains
the exact missing obligation for this second construction.

`research/zero5/` gives a 206-node source DAG with the complete primary K215
guarded control flow and no run of six zero address bits. It includes a
205-node source with just one such address and the complete finite rotation
recipes. No physical allocation or state-size lower bound follows from these
source counts or the restricted failed allocator.

`research/formalisms/` compares alternative refutation formalisms and explains
where their implementation cost moves. External structural results are
sourced; no unmeasured state advantage is asserted.

## Verify

Use Python 3.10 or later with assertions enabled. From the archive root:

```sh
python3 -B verify_all.py
```

This checks the complete archive manifest and runs all six deterministic
audits, then checks that verification preserved every delivered file. The
individual entry points are:

```sh
python3 -B machine215/verify.py
python3 -B research/zero5/verify.py
python3 -B research/short_transfer/verify.py
python3 -B research/short_transfer/checks/inherited_stack_contracts.py
python3 -B research/short_transfer/runtime215/verify.py
```

These commands need only the standard library. The first audits saved
universal-proof records as well as all finite identities and the whole blank
trace. To rederive every all-natural primitive case:

```sh
python3 -B machine215/verify.py --full --work /tmp/new-rotated215-runtime
```

The output directory must not exist and must be outside this packet. This
mode takes several minutes and compares the newly derived case and startup
bytes exactly with the included records. The ordinary mathematical proof
constructor uses induction on arbitrary unary lengths and finite spare lists;
its successful result is not a bounded-register test.

The short-transfer verifier includes finite arithmetic corroboration; its
all-natural proofs are in `theory.tex`. It checks the archived rejected
table's initializer, never substitutes that initializer for a repaired table,
and writes its deterministic verification record. The inherited symbolic
stack-contract check writes its own record. Their default invocations are
already represented in the evidence.

To rebuild the PDF, run twice from `report/`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The appendix can be regenerated from the exact dense table with
`python3 -B report/build_table.py` from the archive root.

## Incorporation and provenance

The archive is a self-contained contribution: it does not depend on this
session's absolute paths or on network access for verification. Historical
receipts may retain their original paths as provenance; executable entry
points use relative locations. Preserve the supplied directory relationships.

`MANIFEST.sha256` identifies every delivered file except itself. Each verified
machine/source subpackage also retains its own pins and manifests. Inherited
ProveIt and upstream notices and licenses are included. The source calculus,
primary compiler, 35-primitive transfer implementation, rotation theorem and
runtime checker are attributed as inherited work. The new constructions and
proof arguments are identified in the report and companion notices.

Only the `machine215/` result is proposed as a completed physical consistency
candidate. Research files and rejected tables have explicit status labels.
