#!/usr/bin/env python3
"""Deterministically rebuild the rotated215 table/source from six literal rotations.
Python 3.10+, standard library only. No optimizer and no network.
"""
from pathlib import Path
from functools import cache
import argparse,hashlib,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor/source'))
import source_language as s
import build221 as b

def sha(raw):return hashlib.sha256(raw).hexdigest()

def reconstruct():
 recipe=json.loads((HERE/'recipe.json').read_text())
 raw=(HERE/'baseline/k215.native.tm').read_bytes();source=(HERE/'baseline/sites215.json').read_bytes()
 assert sha(raw)==recipe['baseline_native_sha256']
 assert sha(source)==recipe['baseline_source_sha256']
 T=b.read_table(raw);base=dict(T);root=s.tree(json.loads(source));original=s.sites(root)
 reference=s.graph_intervals(original);assert reference==s.graph_arithmetic(original)[0]
 steps=[]
 for item in recipe['rotations']:
  q,j=item['state'],item['inner_state'];direction=item['direction']
  groups,paths=b.decoder_map(T,root)
  assert len(groups[q])==len(groups[j])==1
  n=next(iter(groups[q]));inner=next(iter(groups[j]))
  assert all(T[k,bit][:2]==(bit,1)for k in(q,j)for bit in(0,1))
  assert len(paths[j])==len(paths[q])
  if direction=='right':
   assert n[0]==inner and T[q,0][2]==j
   (A,B),C=n
   a,bb,c=T[j,0][2],T[j,1][2],T[q,1][2]
   changes={(q,0):(0,1,a),(q,1):(1,1,j),(j,0):(0,1,bb),(j,1):(1,1,c)}
   nn=(A,(B,C))
  else:
   assert direction=='left'and n[1]==inner and T[q,1][2]==j
   A,(B,C)=n
   a,bb,c=T[q,0][2],T[j,0][2],T[j,1][2]
   changes={(q,0):(0,1,j),(q,1):(1,1,c),(j,0):(0,1,a),(j,1):(1,1,bb)}
   nn=((A,B),C)
  assert s.boundary(A)[0]==0 and s.boundary(C)[1]==0
  @cache
  def replace(t):
   if t==n:return nn
   if s.leaf(t):return t
   return replace(t[0]),replace(t[1])
  root=replace(root);T.update(changes);rows=s.sites(root)
  assert [x[1:]for x in rows]==[x[1:]for x in original]
  assert s.graph_intervals(rows)==s.graph_arithmetic(rows)[0]==reference
  b.decoder_map(T,root)
  steps.append(dict(item,source_metrics=s.metrics(root)))
 expected=dict(base)
 for x in recipe['replacement_rows']:
  k=(x['state'],x['read']);assert expected[k]==tuple(x['before']);expected[k]=tuple(x['after'])
 assert expected==T and len(recipe['replacement_rows'])==17
 native=b.table_bytes(T);source=s.compact(s.sites(root))
 assert sha(native)==recipe['native_sha256']and sha(source)==recipe['source_sha256']
 labels=[0]+sorted({q for q,_ in T}-{0});mapping={q:i for i,q in enumerate(labels)};mapping[254]=215
 dense=b.table_bytes({(mapping[q],bit):(w,d,mapping[z])for(q,bit),(w,d,z)in T.items()})
 assert sha(dense)==recipe['dense_sha256']
 cmap=(json.dumps({'native_to_dense':mapping,'native_sha256':sha(native),'dense_sha256':sha(dense)},indent=2)+'\n').encode()
 products={'rotated215.native.tm':native,'rotated215.tm':dense,'sites215.json':source,'canonicalization.json':cmap}
 for name,data in products.items():assert data==(HERE/'machine'/name).read_bytes(),name
 receipt={'status':'EXACT_DETERMINISTIC_RECONSTRUCTION_PASS','states':len(T)//2,'replacement_rows':17,'steps':steps,'metrics':s.metrics(root),'addresses_changed':sum(x[0]!=y[0]for x,y in zip(original,s.sites(root))),'guarded_edges':sum(len(x[1])for x in reference),'files':{n:sha(x)for n,x in products.items()}}
 return products,receipt

def main():
 assert __debug__ and not sys.flags.optimize,'Do not run with -O or PYTHONOPTIMIZE.'
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path);a=ap.parse_args()
 products,receipt=reconstruct()
 if a.out:
  out=a.out.resolve();assert HERE not in out.parents and out!=HERE,'Output must be outside packet.'
  out.mkdir(parents=True,exist_ok=False)
  for name,raw in products.items():(out/name).write_bytes(raw)
  (out/'construction.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
