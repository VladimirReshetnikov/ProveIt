#!/usr/bin/env python3
"""Regenerate this packet's integrity manifest after an intentional edit."""
from pathlib import Path
import hashlib,json
here=Path(__file__).resolve().parent
files={str(p.relative_to(here)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(here.rglob('*'))if p.is_file()and'__pycache__'not in p.parts and p.name!='manifest.json'}
(here/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
print('Manifest files:',len(files))
