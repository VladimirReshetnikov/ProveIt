# Attribution and inherited terms

This packet was prepared by the ChatGPT research collaboration for Vladimir Reshetnikov's ProveIt project on 2026-10-21. Its new material is the selected six-rotation composition and literal table, complete fresh runtime replay, independent finite source/startup audit, graph-comparison inventory, and portable packaging.

The immediate parent is ProveIt's accepted primary `candidate-k215`, pinned at commit `75716498437bfc7291d5900cab2983a11fd54bac`. The parent table, source, ordinary proof, README, attribution and selected original notices are preserved under `baseline/`. The numerical calculus, dominated-rho8 calibration, source compiler, command-local field reads, scheduler, machine architecture, state-sharing folds and symbolic induction checker are inherited. Their earlier authors and licenses are not replaced by this collaboration's attribution.

The open-sided rotation theorem was already proved in `k219-source-search/proof.md`; the related physical rotation routine appears in `candidate-k221/code/rot_lib.py`. The theorem is not claimed as a new result. The incoming `K215_Alternative_Encodings_2026-10-21.zip` already has a different 17-row re-encoding with the same 716,307-step seed profile; our graph and source differ, but no priority claim is made for its general approach or seed-calibration principle.

Inherited notices credit, within their respective scopes, Mira and ProveIt, Elliot Glazer's compact K/K230 theory work, Jeff's busy-beaver/Rocq reference, Andrew James Wade's compiler ancestry, BusyCoq and the Coq Library of Undecidability. Original terms are retained under `licenses/`; copying them here does not relicense third-party material. New material follows ProveIt's MIT No Attribution terms.

The independent audit is a separately implemented check within the same collaboration, not an external human endorsement. No 214-state machine, new exact-table Lean/Rocq endpoint, unconditional nonhalting theorem, lower bound or state-record claim is asserted by this packet.
