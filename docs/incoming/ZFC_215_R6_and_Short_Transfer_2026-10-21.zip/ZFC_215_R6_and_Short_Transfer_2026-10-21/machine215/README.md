# Rotated215: a distinct 215-state physical encoding

This packet specifies a deterministic binary Turing machine with **215 working states and 430 transitions**, a separate halt, one two-way infinite tape, and an entirely blank initial tape. It does **not** construct a 214-state machine or claim a state-count breakthrough.

Relative to the pinned primary K215, six deterministic source/decoder rotations change **17 transition rows and 4,519 primitive instruction addresses**. The ordered 4,751 primitive instructions and all 6,175 guarded successor edges are unchanged. The result has 202 source DAG nodes, maximum address depth 49, and maximum zero run six. The number of primitive addresses containing six consecutive zeros falls from 37 to 33.

The literal transition graph is not a state renaming of any of the 43 frozen comparison graph groups representing 311 current 215-state table files. The comparison also allows a changed initial state and global tape reflection. This is an encoding alternative; its unchanged numerical calculus, source semantics, rotation rule, and inherited compiler are not claimed as new. It is not a speed improvement.

## The consistency statement and proof boundary

Using the explicitly inherited numerical-calculus/ZFC calibration, the ordinary mathematical argument establishes, formalizably in ZFC,

    not Halt(Rotated215, blank) <=> Con(ZFC).

The proof combines complete source CFG equality, a fresh arbitrary-natural primitive-runtime derivation, the exact entire-tape blank initialization, and the safe-seed argument in `PROOF.md`. It is not an unconditional nonhalting theorem, a lower bound, or a newly compiled Lean/Rocq endpoint. The baseline's formal endpoint scripts were still pending compilation at the pinned repository revision; this packet does not change that status.

The local checks are self-contained and use Python 3.10 or later with only the standard library. The broader numerical-calculus/ZFC comparison is an inherited mathematical result, not newly formalized here. Its source exposition, provenance, exact repository pin and notices are included and identified under `baseline/`, `proofs/`, `licenses/` and `PINNED_SOURCES.json`.

## Exact files

- `machine/rotated215.native.tm`: native start 0, dispatcher 84, halt 254.
- `machine/rotated215.tm`: dense start 0, working labels 0 through 214, halt 215.
- `machine/canonicalization.json`: exact reversible state renaming.
- `machine/sites215.json`: complete ordered primitive source.
- `recipe.json`: all six rotations, all 17 old/new rows, and exact hashes.
- `build.py`: deterministic reconstruction without an optimizer or network.
- `verify.py`: portable source/table, startup and saved-runtime audit; optional fresh universal replay.
- `evidence/`: complete compressed startup trace, complete 6,176-case symbolic inventory, runtime summary/log, independent audit and frozen comparison graphs.
- `vendor/`: unchanged source utilities and the complete inherited runtime checker closure.

Native-table SHA-256:

    11d97d6c1587b63142716e53f75ce05407fccbea33001056bf0e46cfe2ad116a

Source SHA-256:

    704a0449c4164c39464f714e08c435d656f96c024e336ff27d091166772816fe

## Verification actually completed

| Obligation | Result |
|---|---|
| Exact deterministic reconstruction | Native and dense tables, canonical map and source match byte for byte |
| Source correspondence | All 4,751 ordered primitives; both full CFG resolvers; 6,175 guarded edges |
| Arbitrary-natural runtime | All 6,176 cases; 1,753,058 symbolic rules; four block schemas |
| Transition coverage | All 430 native rows |
| Duration | Nonnegative affine coefficients; minimum constant 6 |
| Exact blank initialization | 716,307 transitions; no prior halt |
| Genuine root frame | State 84, head −9, header 207, gap 152 |
| Logical registers | `[4,0,0,0,1,0,0,0,0]` in `(N,T,W,A,D,H,X,Y,L)` order |
| Remaining tape | 185 unit-valued spares; 386 one cells; entirely zero exterior |
| Graph distinction | 43 frozen graph groups; rooted and unrooted/reflected comparisons |

The independent blank audit constructs the full tape from the displayed frame and compares every stored startup event with a separate literal execution. The numeric register D=1 is not assumed to be a theorem. The theorem-valued registers T, W and H are zero, so the safe-seed proof applies.

## Reproduce

Run with assertions enabled, from any directory:

    python3 -B /path/to/machine215/verify.py

The default verifies integrity, reconstructs the exact table/source, checks the complete source CFG, replays the whole blank prefix and its stored trace, checks every saved symbolic-case inventory entry and affine duration, audits all covered transition rows and block traces, and repeats the graph distinctions. It **audits saved proof records**; it does not rederive every unary/list-induction case.

For a fresh arbitrary-natural proof derivation:

    python3 -B /path/to/machine215/verify.py --full --work /tmp/new-rotated215-run

Choose a nonexistent output directory outside this packet. Omitting `--work` uses a temporary directory. The full replay normally takes several minutes and must reproduce the exact case and startup bytes. It is the same mathematical checker replay, not an independently designed proof algorithm.

To write just the reconstructed machine/source into a fresh directory:

    python3 -B /path/to/machine215/build.py --out /tmp/new-rotated215-build

No command writes into this packet during verification. The integrity helper `write_manifest.py` is only for intentional package editing; it is not invoked by verification. Do not use `-O` or `PYTHONOPTIMIZE`.

## Six rotations

| Step | Outer state | Inner state | Direction |
|---|---:|---:|---|
|1|135|221|`((A,B),C) -> (A,(B,C))`|
|2|223|132|`((A,B),C) -> (A,(B,C))`|
|3|78|100|`((A,B),C) -> (A,(B,C))`|
|4|100|225|`(A,(B,C)) -> ((A,B),C)`|
|5|225|142|`((A,B),C) -> (A,(B,C))`|
|6|142|143|`((A,B),C) -> (A,(B,C))`|

Each step retains the ordered primitive word and full guarded CFG. The source-side rule requires A to have no escaping break and C no escaping continuation; B may be open. This rule is inherited from ProveIt's `k219-source-search/proof.md`, reproduced under `proofs/`. Literal physical compatibility is checked during reconstruction and the final all-natural runtime proof.

## Attribution

The new contribution is this selected composition of rotations, its exact physical allocation, complete runtime and blank checks, graph inventory, and portable packaging. Primary K215, the dominated numerical calculus, strong compiler, cofinal scheduler, source grammar, open-sided rotation theorem and symbolic checker are inherited. See `NOTICE.md`; original third-party licenses remain in force. A different physical graph is not a claim of priority for the underlying optimization method.
