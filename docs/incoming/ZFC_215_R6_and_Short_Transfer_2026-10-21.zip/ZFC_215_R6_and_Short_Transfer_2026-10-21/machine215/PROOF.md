# Ordinary correctness proof and its inherited boundary

## 1. Exact reference and machine convention

The reference is `Computability/BusyBeaver/Research/ZFC/candidate-k215` at ProveIt commit `75716498437bfc7291d5900cab2983a11fd54bac`. The native table and ordered primitive source are copied without modification under `baseline/`; their SHA-256 pins are in `recipe.json`.

The candidate has one two-way infinite binary tape, initially all zero, and a head at cell 0 in native state 0. Every working state has exactly one action for each read symbol, each action writes 0 or 1 and moves L or R. Native 254 is a separate terminal state, not one of the 215 working states. The dense table is only a reversible state renaming.

The source language consists of register increments CI, guarded decrements CD, structured forward breaks CB, backward continuations CC, and halt CH. The tuple of logical registers is `(N,T,W,A,D,H,X,Y,L)`.

## 2. Source equivalence for all natural register values

For a binary source pair `(L,R)`, normal completion of L enters R. A first-level break from L exits the pair; a first-level continuation from R restarts the pair. Escaping levels satisfy

    br((L,R)) = max(br(L)-1, br(R), 0),
    co((L,R)) = max(co(L), co(R)-1, 0).

The inherited open-sided associativity theorem states that

    ((A,B),C) <-> (A,(B,C))

preserves the complete primitive-labelled control graph when `br(A)=0` and `co(C)=0`. B may be open. The proof and the necessity of the side conditions are copied in `proofs/inherited_rotation_rules.md`.

`build.py` applies the six literal rotations in `recipe.json`. At every step it checks the side conditions, exact physical decoder roles, unchanged ordered primitive instructions, and equality of two complete guarded CFG resolutions. This is a finite identity of transition systems, not agreement on sampled register values. Relate two source configurations when their primitive ordinals and all nine natural registers agree. Every increment, every zero/positive decrement branch, every control edge and the halt then corresponds exactly. The relation is an all-natural step-for-step bisimulation and includes divergence.

The candidate source therefore has exactly the reference source's command equations, arithmetic macro termination and proof-program enumeration. All raw natural inputs are included; no new formula-decoding or well-formedness filter is inserted.

## 3. The full binary runtime obligation

The source equivalence alone does not certify a changed physical table. The supplied fresh runtime derives all 6,176 guarded primitive cases for the literal candidate table and source, with arbitrary natural primary registers, arbitrary natural gap, and an arbitrary nonempty finite list of natural spare values. The whole zero exterior is included. Unary scans are treated by induction on a natural run length and list traversals by structural induction over the spare list.

The result is `UNIVERSAL_MATHEMATICAL_PASS`, with 1,753,058 symbolic rules, four block schemas and coverage of all 430 table rows. Each affine duration has nonnegative coefficients and a strictly positive constant; the minimum constant is 6. Thus each simulated source step completes in a positive finite number of binary transitions. Finite source halting yields finite binary halting, while an infinite source run cannot collapse into a finite binary run.

The complete checker closure is copied unchanged under `vendor/runtime/`. `verify.py --full` reruns the derivations and requires exact equality of the complete case-inventory and startup bytes. The default command audits stored records and their exact bindings but does not rederive all induction cases. These are executable ordinary mathematical checks, not a new proof-assistant kernel endpoint.

## 4. Exact blank prefix

A separate literal simulation executes 716,307 transitions from the empty tape. It reaches native dispatcher 84, head −9, header 207 and gap 152, with logical tuple

    (N,T,W,A,D,H,X,Y,L) = (4,0,0,0,1,0,0,0,0)

and 185 one-valued spare registers. The complete tape contains exactly 386 one cells and is zero everywhere else. In the physical register order, logical coordinate i occupies position `(6,2,0,4,3,7,8,5,1)[i]`. Beginning after the header, each physical value v is represented by a zero followed by v+1 ones; the left marker is at head-1. Reconstructing that entire finite support gives exactly the executed tape, including all primary registers, all spares and both exterior tails.

The head is at a genuine zero-program-counter root, not an instruction-interior dispatcher position. No halt occurs in the finite prefix. The independent verifier checks every stored event against a separately parsed literal table and reconstructs the whole final tape. The symbolic runtime applies to this frame because its gap is natural and its spare list is nonempty.

## 5. Calibration of the nonzero numeric parameter

Let P be the retained Cantor pairing, I(a,b)=4P(a,b), Q_i(a)=4P(i,a)+2, truth 0 and falsity 1. The retained dominated numerical calculus D has the inherited calibration

    D derives 1 <=> there exists a finite ZFC refutation.

The exact source/compiler exposition is included as `proofs/inherited_source_calibration.tex`. Its printed terminal theorem uses D-register 0; its soundness invariant and universal compiler prove the following required extension directly.

**Safe-parameter lemma.** Start at a genuine source root with next-candidate counter n, selector and arithmetic scratches zero, empty continuation L=0, arbitrary numeric parameter d, and theorem-valued current T, cache H and every stack head of W. The source halts if and only if D derives 1.

**Soundness.** No theoremhood assumption is imposed on the numeric parameter d. A successful MP uses the exact theorem premises I(T,d+x) and T; a failed MP returns truth. DROP and NIP only move theorem codes. AX uses U=d and A=d+x, so U<=A for every natural x. It emits valid dominated-row instances, the retained logical rows, a theorem-only generalization of the old cache, and either the permitted theory bundle or truth. Its new current and stack entries are therefore theorems and its cache resets to truth. NIP's only halt tests whether the cached theorem is 1. Hence any halt from the safe state supplies a native refutation.

**Completeness.** The inherited strong compiler supplies a finite block B_1 which, from every retained top/stack once D=H=0, either halts or returns top 1 with the old underlying stack and zero parameter/cache. Append `DROP;NIP;NIP` to load and test that 1. Prepend `Start_y=AX(0;1,y)`. AX resets D=H=0 regardless of the old numeric parameter and retained data; the strong compiler permits its new top/stack. Thus the whole block halts from every numerical command-boundary tuple.

For the actual NIP/DROP/MP tags 0, 1, 2, if R is the fixed encoded suffix, its first-candidate code is

    N_y = P(3,P(y,P(1,R))) >= y.

This family is cofinal. Choose y>=n. Every earlier nonhalting candidate drains after finitely many commands: each positive continuation decreases before taking its tail projections, and every arithmetic macro terminates on natural inputs. The outer scheduler then reaches N_y unless a halt occurred earlier. Hence a native refutation implies eventual source halting. This proof does not treat a halt from an arbitrary unsafe seed as sound; soundness uses the separate theoremhood invariant above.

At our actual root n=4 and d=1, while T=H=W=0. Zero and every successive zero-stack head are truth theorems, so the lemma applies. No logical significance is assigned to numeric D=1.

## 6. Composition inside ZFC

Combine the exact finite blank prefix, the all-natural positive-duration binary simulation, source CFG equality, the safe-parameter lemma and the inherited native-calculus/ZFC calibration. This yields

    ZFC proves Halt(Rotated215,blank) <=> ZFC has a finite refutation,

and hence

    ZFC proves not Halt(Rotated215,blank) <=> Con(ZFC).

This uses primitive-recursive finite encodings and ordinary induction on natural numbers, lists and finite derivations; it assumes neither Con(ZFC) nor unconditional nonhalting. The numerical-calculus calibration is explicitly inherited, rather than newly proved from first principles in this packet. No claim of an exact-table kernel formalization, state minimality or two-sided independence from bare consistency is made.

## 7. Distinction from archived encodings

The packet freezes 43 representative literal transition graphs covering 311 discovered 215-state table files. In a deterministic read-labelled graph, any state isomorphism must preserve the write bit, movement direction and labelled successor for each read bit. Starting with one color for working states and a separate halt color, iterated successor-color refinement is invariant under any such isomorphism. A difference in the multiset of colors therefore proves nonisomorphism without fixing the initial state. Applying the same test after reversing every movement checks global tape reflection as well.

The candidate differs from each frozen graph in this invariant. `verify.py` repeats those finite computations. This establishes distinction against the listed inventory, not universal novelty or a semantic difference in the ultimate halting predicate. In fact the shared consistency predicate is the purpose of the construction.
