#!/usr/bin/env python3
"""Portable exact build, source, blank-tape and saved-proof audit.
--full additionally rederives every arbitrary-natural primitive runtime case.
"""
from pathlib import Path
import argparse,collections,gzip,hashlib,json,struct,subprocess,sys,tempfile
import build
HERE=Path(__file__).resolve().parent

def sha(raw):return hashlib.sha256(raw).hexdigest()
def read_gz(name):return gzip.decompress((HERE/name).read_bytes())
def parse_table(raw):
 T={}
 for line in raw.decode().splitlines():
  if not line or line.startswith('#'):continue
  q,bit,w,d,z=line.split();q,bit,w,z=map(int,(q,bit,w,z))
  assert(q,bit)not in T and bit in(0,1)and w in(0,1)and d in('L','R')
  T[q,bit]=(w,1 if d=='R'else-1,z)
 states={q for q,bit in T};assert len(states)==215 and set(T)=={(q,b)for q in states for b in(0,1)}
 assert{z for w,d,z in T.values()}-states=={254}
 return T

def colors(T,mirror=False):
 states={q for q,b in T};halts={z for w,d,z in T.values()}-states;assert len(halts)==1
 halt=next(iter(halts));col={q:'W'for q in states};col[halt]='H'
 for i in range(1,216):
  col={**{q:sha(repr(tuple((w,-d if mirror else d,col[z])for w,d,z in(T[q,0],T[q,1]))).encode())for q in states},halt:'H'}
  yield collections.Counter(col.values())

def audit(saved_trace=True):
 manifest=json.loads((HERE/'manifest.json').read_text())
 actual={str(p.relative_to(HERE))for p in HERE.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.name!='manifest.json'}
 assert actual==set(manifest),('Manifest file set changed',actual-set(manifest),set(manifest)-actual)
 for name,digest in manifest.items():assert sha((HERE/name).read_bytes())==digest,('File changed',name)
 products,construction=build.reconstruct();T=parse_table(products['rotated215.native.tm'])
 recipe=json.loads((HERE/'recipe.json').read_text());sites=json.loads(products['sites215.json'])
 startup_raw=read_gz('evidence/startup.json.gz');assert sha(startup_raw)==recipe['startup_raw_sha256']
 startup=json.loads(startup_raw);assert startup['status']=='CALIBRATED_DIRTY_ROOT_SEED'
 ones=set();head=0;q=0;tracehash=hashlib.sha256();stored=startup['trace']
 assert len(stored)==716307
 for tick in range(716307):
  bit=int(head in ones);w,d,z=T[q,bit];event=[q,head,bit,w,d,z]
  assert event==stored[tick],('Stored startup trace differs',tick)
  tracehash.update(struct.pack('<iiiiii',*event))
  if w:ones.add(head)
  else:ones.discard(head)
  q=z;head+=d
 logical=[4,0,0,0,1,0,0,0,0];physical=[None]*9
 for i,j in enumerate((6,2,0,4,3,7,8,5,1)):physical[j]=logical[i]
 physical += [1]*185
 expected={-10,207};cursor=208
 for value in physical:
  cursor+=1;expected.update(range(cursor,cursor+value+1));cursor+=value+1
 assert(q,head,ones)==(84,-9,expected)
 assert startup['state']==q and startup['head']==head and startup['gap']==152
 assert startup['registers']==logical and startup['spares']==[1]*185 and startup['one_cells']==sorted(ones)
 independent=json.loads((HERE/'evidence/independent_audit.json').read_text())
 assert tracehash.hexdigest()==independent['startup']['trace_sha256_i32le6']
 del startup,stored,startup_raw
 casesraw=read_gz('evidence/runtime_cases.json.gz');assert sha(casesraw)==recipe['runtime_cases_raw_sha256']
 cases=json.loads(casesraw);expected_cases=[(i,positive)for i,(_,op,_)in enumerate(sites)for positive in((False,True)if op=='CD'else(False,))]
 assert[(x['site_index'],x['positive'])for x in cases]==expected_cases and len(cases)==6176
 report=json.loads((HERE/'evidence/runtime.json').read_text())
 assert report['status']=='UNIVERSAL_MATHEMATICAL_PASS'and report['proved_cases']==report['expected_cases']==6176 and not report['failures']
 assert report['working_states']==215 and report['table_sha256']==sha(products['rotated215.native.tm'])and report['sites_sha256']==sha(products['sites215.json'])
 assert report['checker_sha256']==sha((HERE/'vendor/runtime/runtime/symbolic_runtime.py').read_bytes())
 assert report['helper_sha256']==sha((HERE/'vendor/runtime/runtime/independent_runtime.py').read_bytes())
 mapping={int(k):int(v)for k,v in json.loads((HERE/'vendor/runtime/inputs/legacy_mapping.json').read_text()).items()}
 for q in{q for q,b in T}|{254}:
  if q not in mapping:mapping[q]=q+1000
 inverse={v:k for k,v in mapping.items()}
 used=set()
 for case in cases:
  d=case['duration'];assert len(d)==13 and d[0]>0 and all(type(n)is int and n>=0 for n in d)
  assert case['symbolic_steps']==sum(case['kinds'].values())
  for q,bit in case['rows']:assert(inverse[q],bit)in T;used.add((inverse[q],bit))
 assert used==set(T)
 assert sum(x['symbolic_steps']for x in cases)==1753058
 assert min(x['duration'][0]for x in cases)==6
 assert len(report['blocks'])==4
 for block in report['blocks']:
  assert block['arbitrary_contexts']is True and block['steps']=='v+2'
  for event in block['trace']:
   assert event[0]in('literal','unary');q,bit,w,d,z=event[1]
   assert T[inverse[q],bit]==(w,d,inverse[z])
 frozen=json.loads(read_gz('evidence/comparison_graphs.json.gz'));assert len(frozen)==43
 ref=list(colors(T));comparison=[]
 for graph in frozen:
  other={(q,bit):(w,d,z)for q,bit,w,d,z in graph['rows']};assert len(other)==430
  for mirrored in(False,True):
   first=next((i for i,(a,b)in enumerate(zip(ref,colors(other,mirrored)),1)if a!=b),None)
   assert first is not None,('Unresolved graph comparison',graph['source'],mirrored)
   comparison.append([graph['source'],mirrored,first])
 return {'status':'PORTABLE_FINITE_AND_SAVED_PROOF_AUDIT_PASS','states':215,'changed_rows':17,'changed_addresses':construction['addresses_changed'],'source_metrics':construction['metrics'],'startup_steps':716307,'startup_registers':logical,'startup_spares':185,'saved_cases':6176,'symbolic_rules':1753058,'minimum_duration_constant':6,'covered_native_rows':430,'distinct_comparison_graphs':43,'source_tables_represented':sum(len(x['equivalent_input_files'])for x in frozen),'fresh_universal_replay':False},report

def full_runtime(out,report):
 out.mkdir(parents=True,exist_ok=False)
 command=[sys.executable,'-B',str(HERE/'vendor/runtime/validate_native.py'),str(HERE/'machine/rotated215.native.tm'),str(HERE/'machine/sites215.json'),str(out/'runtime')]
 print('Rederiving all6176 arbitrary-natural primitive cases; this may take several minutes.',flush=True)
 with(out/'runtime.log').open('w')as stream:
  p=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 assert p.returncode==0,('Runtime helper exited',p.returncode)
 actual=json.loads((out/'runtime/runtime.json').read_text());recipe=json.loads((HERE/'recipe.json').read_text())
 assert actual['status']=='UNIVERSAL_MATHEMATICAL_PASS'and actual['proved_cases']==actual['expected_cases']==6176 and not actual['failures']
 for k in('table_sha256','sites_sha256','checker_sha256','helper_sha256','working_states','site_count','blocks'):assert actual[k]==report[k],k
 assert sha((out/'runtime/runtime_cases.json').read_bytes())==recipe['runtime_cases_raw_sha256']
 assert sha((out/'runtime/startup.json').read_bytes())==recipe['startup_raw_sha256']
 return actual

def main():
 assert __debug__ and not sys.flags.optimize,'Do not use -O or PYTHONOPTIMIZE.'
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--full',action='store_true');ap.add_argument('--work',type=Path);args=ap.parse_args()
 result,report=audit()
 if args.full:
  if args.work:
   out=args.work.resolve();assert out!=HERE and HERE not in out.parents,'Choose a new output directory outside packet.'
   actual=full_runtime(out,report)
  else:
   with tempfile.TemporaryDirectory(prefix='rotated215-')as tmp:actual=full_runtime(Path(tmp)/'fresh',report)
  result['fresh_universal_replay']=True;result['fresh_runtime_seconds']=actual['seconds'];result['status']='FULL_FRESH_UNIVERSAL_REPLAY_PASS'
 else:assert args.work is None,'--work is only used with --full.'
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
