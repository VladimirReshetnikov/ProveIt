#!/usr/bin/env python3
"""Verify archive integrity and all included deterministic audit entry points.

Default mode audits saved quantified records and replays exact finite evidence.
--full additionally rederives both complete quantified binary runtime families.
No network access or third-party Python packages are required.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def integrity():
    lines = (ROOT / 'MANIFEST.sha256').read_text().splitlines()
    expected = {}
    for line in lines:
        digest, name = line.split('  ', 1)
        path = ROOT / name
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert len(digest) == 64 and name not in expected
        assert path.is_file(), ('Missing file', name)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, ('Changed file', name)
        expected[name] = digest
    actual = {
        p.relative_to(ROOT).as_posix()
        for p in ROOT.rglob('*')
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'
        and p.name != 'MANIFEST.sha256'
    }
    assert actual == set(expected), ('Manifest inventory mismatch', actual ^ set(expected))
    return len(expected)


def run(relative, full=False):
    path = ROOT / relative
    command = [sys.executable, '-B', str(path)]
    if full:
        command.append('--full')
    print('Checking ' + relative + (' --full' if full else ''), flush=True)
    result = subprocess.run(command, cwd=path.parent, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        print(result.stdout, file=sys.stderr)
        raise RuntimeError(f'{relative} exited with status {result.returncode}')
    starts = list(re.finditer(r'(?m)^\{', result.stdout))
    assert starts, ('No JSON result', relative)
    record, _ = json.JSONDecoder().raw_decode(result.stdout[starts[-1].start():])
    summary = {k: record[k] for k in (
        'status', 'states', 'changed_rows', 'changed_addresses',
        'startup_steps', 'saved_cases', 'quantified_primitive_cases',
        'symbolic_rules', 'covered_native_rows', 'covered_rows',
        'minimum_duration_constant', 'blank_start_states',
        'maximum_ray_prefix_steps', 'runtime_status', 'initialization_status',
        'cases', 'commands', 'fresh_universal_replay',
        'full_fresh_runtime_replay') if k in record}
    assert summary.get('status'), ('Missing result status', relative)
    return {'entry_point': relative, 'full': full, 'result': summary}


def main():
    assert __debug__ and not sys.flags.optimize, 'Do not disable assertions.'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    args = parser.parse_args()
    count = integrity()
    checks = [
        run('machine215/verify.py', args.full),
        run('research/zero5/verify.py'),
        run('research/short_transfer/verify.py'),
        run('research/short_transfer/checks/inherited_stack_contracts.py'),
        run('research/short_transfer/runtime215/verify.py', args.full),
        run('research/short_transfer/physical_association3/audit.py'),
    ]
    assert integrity() == count
    print(json.dumps({
        'status': 'ALL_ARCHIVE_AUDITS_PASS',
        'manifest_files': count,
        'full_quantified_replay_requested': args.full,
        'checks': checks,
        'accepted_blank_candidate': 'machine215/machine/rotated215.tm',
        'rejected_runtime_only_table': 'research/short_transfer/runtime215/runtime-only.native.tm',
        'scope': 'Ordinary mathematical and executable verification; no new proof-assistant kernel theorem.'
    }, indent=2))


if __name__ == '__main__':
    main()
