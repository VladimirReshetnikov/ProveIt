#!/usr/bin/env python3
"""Rebuild the manuscript's complete dense transition table, without dependencies."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
source = HERE.parent / 'machine215/machine/rotated215.tm'
table = {}
for line in source.read_text().splitlines():
    if not line or line.startswith('#'):
        continue
    q, read, write, move, target = line.split()
    key = (int(q), int(read))
    assert key not in table
    table[key] = (int(write), move, int(target))
assert set(table) == {(q, read) for q in range(215) for read in (0, 1)}

def action(q, read):
    w, move, target = table[q, read]
    target_text = 'H' if target == 215 else str(target)
    return r'\texttt{' + f'{w}{move}{target_text}' + '}'

lines = [
    r'\section{Complete dense transition table}',
    r'\label{app:table}',
    r'The initial state is $0$, the initial head position is $0$, and the',
    r'initial tape is entirely $0$. Working states are $0,\ldots,214$.',
    r'Each entry $wDq$ means write bit $w$, move one cell in direction',
    r'$D\in\{L,R\}$, and enter state $q$. The symbol \texttt{H} denotes',
    r'the separate halt state $215$, which has no outgoing rows.',
    r'The two state columns are independent continuations of the table.',
    r'\begingroup\small',
    r'\setlength{\tabcolsep}{11pt}',
    r'\begin{longtable}{rll@{\hspace{14mm}}rll}',
    r'\toprule',
    r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
    r'\midrule\endfirsthead',
    r'\toprule',
    r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
    r'\midrule\endhead',
    r'\midrule\multicolumn{6}{r}{\emph{Continued on the next page}}\\\endfoot',
    r'\bottomrule\endlastfoot',
]
for left in range(108):
    right = left + 108
    first = f'{left} & {action(left, 0)} & {action(left, 1)}'
    second = (f'{right} & {action(right, 0)} & {action(right, 1)}'
              if right < 215 else ' & & ')
    lines.append(first + ' & ' + second + r'\\')
lines.extend([r'\end{longtable}', r'\endgroup', ''])
(HERE / 'sections/transition_table.tex').write_text('\n'.join(lines))
