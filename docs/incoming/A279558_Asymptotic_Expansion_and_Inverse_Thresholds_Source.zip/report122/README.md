# Report 122 A279558 asymptotics and inversion

This reader package contains the 17-page mathematical report, its editable LaTeX
source, and offline reproducibility programs. The report proves the leading
asymptotic equivalent, all fixed-order coefficient expansions, and integer
threshold localization for inversion sequences avoiding 010, 120 and 210.
Previously published amplitude digits are credited in the report to Václav
Kotěšovec (OEIS, 13 January 2026) and the numerical analysis of Britt and Beaton.

## Read

- `report122.pdf`: standalone proof, exact interval derivations, inversion and limits
- `report122.tex`: complete editable source; no external figures or source papers needed
- `checks/README.md`: exact scope and design of the independent finite-check companion
- `data/a279558_n0_150.txt`: 151 exact terms generated from the tree
- `data/verification_results.json`: deterministic full exact-check output, including rational intervals
- `data/negative_results.json`: deterministic mathematical/schema/inventory mutation-test results
- `data/certificate_output.txt` and `data/correction_output.txt`: original finite interval outputs

The proof does not claim nonalgebraicity, non-D-finiteness, universal novelty,
convergence of the infinite 1/n expansion, or an explicit numerical n0 for the
asymptotic remainder. The local Puiseux expansion does converge. Near an integer
rounding boundary, the inverse statement retains two ceiling bounds.

## Quick verification

Use Python 3.10 or newer. All Python mathematical checks use only the standard
library, need no network, and have no installation step. Run from this directory:

    python3 -B integrity.py
    python3 -B checks/verify.py --output ../report122-results.json
    python3 -B checks/negative_tests.py --output ../report122-negative.json
    python3 -B test_integrity.py

The checks remain active under `python3 -B -O`. The companion rejects unknown
schema fields, malformed rationals, invalid bounds and changed fixtures.
Both the checks subtree and the complete reader package have closed inventories:
extra files/directories, missing files, changed bytes and symlinks are rejected.
This is an integrity check, not a cryptographic signature or a protection against
someone replacing both the verifier and its inventory.

The full finite ranges are: direct avoidance and complete state distributions
n=0..9; transformed-tree terms n=0..150; all 26 displayed OEIS terms; full cleared
source functional equations and scalar identity through z^40; root and anchor
through z^64; finite orbit quotients m=0..30 through the predicted n=m+1.
The Puiseux equation is checked in Q(sqrt(3)) through t^6. Transfer factors and
the inverse polynomial through L^-2 are checked symbolically. Exact lattice
intervals at 120 decimal places and 512 orbit steps are widened by proved
complex-domain tails to certify C, d1 and d2. These are finite computational
checks of the report's arguments, not a proof-assistant formalization.

## Complete immutable replay

    python3 -B reproduce.py --output ../report122-replay.json

This verifies both inventories, reruns the authoritative checker in normal and
optimized Python, compares its exact bytes with the supplied output, runs all
negative tests, reruns the auxiliary scripts, builds the PDF twice in clean
external directories, and compares it with the delivered PDF. It then packs a
ZIP, extracts into a fresh directory, reruns normal and optimized checks,
rebuilds the PDF twice, repacks, and requires identical ZIP bytes. It checks the
original package again at the end. All outputs and temporary files stay outside
the reader directory. A run may take several minutes. For systems without TeX:

    python3 -B reproduce.py --skip-pdf --output ../report122-checks-only.json

That option verifies the mathematics and ZIP replay but explicitly omits both
PDF rebuild checks. The result JSON records that omission.

The auxiliary programs in `scripts/` preserve the original certificate formulas.
Their docstrings and output destinations were cleaned for a standalone package.
They are supplemental, use ordinary Python assertions, and explicitly fail under
-O/-OO instead of silently skipping checks. The authoritative `checks/` verifier
uses active guards and supports optimization. Neither implementation alone proves
the global analytic continuation or the all-order transfer; the report does.

## PDF build

Requires pdfTeX/pdflatex plus geometry, fontenc, Latin Modern, amsmath, amssymb,
amsthm, mathtools, booktabs, microtype, hyperref and enumitem.

    bash build.sh
    python3 -B build.py --output ../rebuilt-report122.pdf

The default destination is `../build/report122.pdf`. The builder creates its own
TeX format in temporary directories, performs three passes per clean build,
rejects overfull boxes and unresolved references, and requires byte equality of
two clean builds. It never overwrites the source PDF. Exact byte equality with
the delivered PDF is established for the environment in `build-environment.txt`;
other TeX distributions may generate different bytes for equivalent content.

## Deterministic packaging

    python3 -B repack.py ../report122_reproducibility.zip

The ZIP contains a single `report122/` reader directory. Member order, timestamps,
permissions and compression settings are fixed. The original environment's zlib
version is recorded because compressor versions can affect ZIP bytes. No logs,
rendered page images, private working notes, downloaded papers, or temporary
build products are part of the reader package.

After intentional author-side edits, the closed outer inventory can be replaced
with `python3 -B integrity.py --write`. This is not a way to validate an unexpected
change. Changes under `checks/` also require its own reviewed inventory update.
