# Lexicographic Orders of Surreal Well-Orderings

Research manuscript prepared for Vladimir Reshetnikov, 2 October 2026.

## Contents

- `surreal_well_orders.pdf`: the compiled, 26-page article.
- `surreal_well_orders.tex`: self-contained LaTeX source with embedded bibliography.
- `verify_finite.py`: standard-library Python regression checks.
- `verification_results.json`: output from the supplied verification run.
- `build.sh`: rebuilds the finite checks and PDF.
- `SHA256SUMS.txt`: checksums of the principal deliverables.

## Main results

The article distinguishes five objects: well-orderings of a fixed set,
set-sized words with varying carriers, global set-like well-orderings,
set-supported perturbation codes, and arbitrary non-set-like class well-orders.

For an infinite linearly ordered set X of cardinality kappa, all exhaustive
well-order enumerations form a lexicographic order of size 2^kappa. It contains
every linear order of size at most kappa, and an ordinal beta embeds exactly
when beta < kappa^+. Every adjacent pair is accounted for by a finite
permutation tail. Regular-cardinal surreal birthday cutoffs admit more precise
fixed-length and cut-filling results.

In Godel--Bernays set theory with Global Choice, fix a class bijection
b : Ord -> No. Canonical set codes for set-supported perturbations of b,
ordered by numerical first disagreement of their represented enumerations,
form an order isomorphic to No. This class-sized skeleton realizes every
uniformly set-indexed separated cut in the full virtual enumeration order.
The key proofs are Theorem 11.1 and Theorem 12.2.

Finite support already suffices to contain an embedded copy of No, but not
for set-cut saturation or ambient density (Proposition 12.5). This shows why
universality, isomorphism, and density are different conclusions.

The full virtual enumeration order is equimorphic with the virtual order of
class binary sequences (Theorem 13.1), but no class-uniform family can list
all global enumerations (Theorem 13.2). Non-set-like well-orders require
another index convention or relation-code comparison.

The final sections give model/universe interpretations, a Lean implementation
plan, an assumption ledger, and 15 further research directions.

## Status

These are explicit mathematical derivations, not a claim of established
historical priority. The new manuscript has not been independently refereed
or checked in Lean. No new Lean formalization is included. Repository sources
were inspected but not rebuilt. The finite tests do not establish any
transfinite or class-theoretic theorem.

## Repository provenance

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: ae7c1e6aae3dc58c9c638b35646865ad6c10387d

Inspected main mathematical source files:

- Algebra/SurrealNumbers/Surreal/Foundations/SignSequence.lean
  Blob: e2c093860f29b0b9ea312d50099fc4aa89a76a99
- Algebra/SurrealNumbers/Surreal/Foundations/SignSequenceCut.lean
  Blob: c5c35afd98a5ad293687367ee9fb0244f94cc91c

Their exact pinned links and the remaining references are in the article.
The prior continuum manuscript was used as a contextual predecessor, not as
a formally certified dependency. Its relevant set-sized conclusions are
reproved here.

## Reproduction

Requirements: Python 3.10 or later, TeX Live with the packages named in the
preamble, and either latexmk or pdflatex. No third-party Python package,
external image, bibliography database, or private font file is required.

```sh
python3 verify_finite.py
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_well_orders.tex
```

On systems with a POSIX shell, `sh build.sh` runs both steps. Otherwise run
pdflatex three times to settle cross-references and the contents page.

The finite checks passed on 5,906 adjacent permutation pairs, 7,432 increasing
pairs of permutations (including negative adjacency cases), 21,845 pair-code
comparisons, and 16,129 sign-code comparisons on 127 sign words.
