# Macroscopic Deficits of the Largest Jump

**A rare-event law and exact moment constants for 132-avoiding permutations**

AI-assisted research manuscript prepared for Vladimir Reshetnikov, September 29, 2026.

## Read the article

`article.pdf` is the compiled manuscript; `article.tex` is its complete editable
LaTeX source, including the bibliography. The mathematical proofs are
self-contained. The package also contains the executed finite checks, exact
integer count data, figures, and source/provenance records.

Let M_n be the largest absolute adjacent difference in a uniform 132-avoiding
permutation and D_n = n - M_n. The main results are:

- For 0 < x < 1/2, sqrt(n) P(D_n >= x n) tends to
  (3/sqrt(pi)) (1-2x)/sqrt(x(1-x)); the scaled limit is zero for x >= 1/2.
- For every fixed p > 1/2,
  E[D_n^p] ~ kappa_p n^(p-1/2), where
  kappa_p = (3/sqrt(pi)) integral_0^1 (z^2/(1+z^2))^(p-1) dz.
  In particular, the mean deficit constant is 3/sqrt(pi), and the variance
  constant is (3/sqrt(pi))(1-pi/4).
- A macroscopic deficit has an explicit conditional terminal-split law and a
  universal law for the finite decorated outer word. The word has mean length
  7/3, but its limiting cost has infinite mean.

The previous ProveIt report left the positive linear-deficit equivalent and
these exact moment constants open. This continuation does not assume its
probabilistic or spectral asymptotic theorems. See `SOURCES.md` and Section 1
for the exact repository snapshot and the narrower dependency boundary.

## Status and limitations

The article supplies conventional mathematical proofs and executed exact
finite checks. It has not been externally refereed or verified in Lean or
Rocq, and first-in-literature priority is not established. The numerical
checks are not substitutes for the analytic arguments.

A positive bulk equivalent is proved only for adjacency fractions m/n in
(1/2,1). For m/n <= 1/2, only a zero limit at the sqrt(n) probability scale
is proved. The critical window, smaller-bound bulk equivalents, local limit,
second-order moment terms, and exact total-variation constant remain open
here. Section 10 proposes ten research directions with their proof boundaries.

## Reproduce the finite checks

Use Python 3.10 or newer, without `-O`:

```sh
python code/verify.py
python code/verify_symbolic.py
```

The first command needs only the standard library. It checks all 6,916
132-avoiders of sizes 2 through 9, including 36 total-count cases, 644
endpoint-state cases, 18,738 parser/reconstruction cases, and 60 positive-cost
coefficients of each outer-word identity. Endpoint formulas are checked too.
The second command needs SymPy and checks eleven groups of symbolic identities.

Reports are in `data/verification.json` and `data/symbolic_verification.json`.
They explicitly distinguish finite or symbolic verification from analytic
proof and proof-assistant verification.

## Reproduce the data and figures

```sh
python code/numerics.py
python code/plot_results.py
```

The numerical script uses only Python integers for the counts. Decimal
ratios are used only for display. It regenerates ten bulk cases (up to
n=320) and three all-bound moment cases (n=20,40,80). Counts are stored as
full decimal integers in the CSV files. The moderate-size ratios converge
slowly and are not used to infer the leading constants.

The plotting script requires NumPy and Matplotlib. Package versions used
for the delivery are recorded in `data/environment.json`. The PDF figures
are retained, so Python is not required just to compile the article.

## Compile the PDF

On a system with TeX Live or a comparable LaTeX installation:

```sh
bash build.sh
```

Alternatively, from this directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

`build.sh` writes intermediate files to `build/` and copies the finished PDF
to `article.pdf`. Repeated `pdflatex` runs can replace `latexmk`. Required
packages include newtx, amsmath, amsthm, mathtools, microtype, tcolorbox,
hyperref, cleveref, booktabs, listings, and xurl.

## Files

- `article.{tex,pdf}`: manuscript and compiled reading copy.
- `code/`: counting model, exhaustive checks, symbolic checks, data and figures.
- `data/`: verification records, environment, and exact count CSVs.
- `figures/`: the two plots as PDF and PNG.
- `SOURCES.md`: primary-source and repository ledger.
- `build.sh`: reproducible LaTeX build command.

No new Lean or Rocq code, font files, or unexecuted formal proof claims are
included. Nothing in this package changes the GitHub repository.
