SHARP LOCAL BOUNDS IN GOWERS' PROOF OF SZEMEREDI'S THEOREM
Research report prepared for Vladimir Reshetnikov — 6 October 2026

MAIN FILES
  Gowers_Refinements.pdf   Complete article with proofs and research agenda.
  Gowers_Refinements.tex   Complete LaTeX source, including its bibliography.
  figures/                The PDF figure used by the LaTeX source and a PNG copy.
  verification/           Reproducible exact calculations and certificates.
  provenance.json         Pinned source identifiers and package checksums.

BUILD THE ARTICLE
From this directory, run:
  pdflatex -interaction=nonstopmode -halt-on-error Gowers_Refinements.tex
  pdflatex -interaction=nonstopmode -halt-on-error Gowers_Refinements.tex

Alternatively:
  latexmk -pdf -interaction=nonstopmode -halt-on-error Gowers_Refinements.tex

The source uses standard TeX Live packages, Latin Modern fonts, and the included
figures/bound_comparisons.pdf. It requires no separate .bib file, shell escape,
network access, or proprietary fonts.

REPRODUCE THE MATHEMATICAL CHECKS
The following three commands require only Python 3's standard library:
  python3 verification/verify_carry_certificates.py
  python3 verification/uniformity_checks.py
  python3 verification/density_checks.py

The carry verifier checks rational strict-interior witnesses and rational dual
certificates, and exhaustively checks the binary sign-prefix tree. Its certified
counts are C_0,...,C_4 = 1,1,2,10,154 and D_0,...,D_3 = 1,2,6,38.
The JSON certificates are sufficient for verification: SciPy is NOT needed to
check their validity. Do not pass Python's -O flag.

To regenerate proposed chamber certificates, NumPy and SciPy are needed:
  python3 verification/compute_carry_chambers.py

The numerical solver only proposes rational certificates. The exact checker
must still accept every feasible or discarded branch. General theorem proofs
are in the article; finite inequality tests do not replace those proofs.

To regenerate the bound-comparison figure, Matplotlib is needed:
  python3 verification/bound_comparisons.py

SCOPE AND STATUS
The report proves explicit local refinements, an exact carry-count
factorization, leading carry entropy using Zuev's known threshold theorem,
sharp partition extraction, and an abstract iteration theorem. It does not
claim a new global Szemeredi bound or historical priority for every elementary
inequality. It has not added proofs to the repository or run Lean. Repository
compilation and axiom-audit counts are attributed to the inspected checkpoint.

All source comparisons are pinned to ProveIt commit:
  7d99e5deeb209a4671060990cb1ea3d672d57064
The article distinguishes the edited transcription from the 2001 journal paper.

CONTENTS OF THE RESEARCH AGENDA
Exact carry counts; next entropy terms; modular collisions; affine translation
orbits; analytical alternatives to the square of the pattern count; optimal
higher-progression density factors; torsion corrections; use of all dense
cells; discrete iteration corrections; completion of the explicit formal
dependency chain; other integer-valued configuration families.
