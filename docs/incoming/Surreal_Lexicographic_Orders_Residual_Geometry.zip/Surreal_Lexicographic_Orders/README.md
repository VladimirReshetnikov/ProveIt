# Lexicographic Orders of Surreal Well-Orderings
## Residual geometry, the finite-tail transition, unranked cylinders, and reconstruction of class realizations

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

## Contents

- `article.pdf`: the 33-page article, including title page, contents, proofs, foundations, formalization plan, twelve research questions, dependency ledger, and bibliography.
- `article.tex`: standalone LaTeX source with an internal bibliography.
- `code/finite_checks.py`: deterministic Python standard-library regression checks.
- `data/finite_checks.json`: recorded successful run, 1,388,197 assertions.
- `data/pdf_validation.json`: PDF page count, bounds checks, and validation scope.
- `RESEARCH_STATUS.md`: new results versus inherited inputs and limitations.
- `SOURCE_AUDIT.md`: pinned repository paths and inspected source hashes.
- `build.sh`: rebuilds the finite record and PDF from this directory.
- `SHA256SUMS.txt`: checksums of the delivered files other than the manifest itself.

## Main mathematical extensions

For every rich linear alphabet X of infinite cardinality mu, put Delta = mu^{<mu}.
For every enumeration ordinal alpha with |alpha| = mu, the density/cellularity/weight
of the lexicographic exhaustive-enumeration order are:

| Length | Density | Cellularity | Weight |
| --- | --- | --- | --- |
| mu or mu+1 | Delta | Delta | Delta |
| mu+2 | Delta | Delta | 2^mu |
| alpha >= mu+3 | 2^mu | 2^mu | 2^mu |

This includes X = No_{<kappa}, mu = 2^{<kappa}, for any infinite cardinal kappa.
The article also proves exact local characters for finite tails and for tail omega,
and an exact residual-fibre reduction for general lengths.

For global enumerations, the unranked cylinder incidence recovers ordinal prefix
heights in the ambient class set theory. A normalized cut represents an injective
Ord-word exactly when it crosses a proper class of cylinder nodes; label coverage
recognizes exhaustive words. Over a fixed set universe with shared coding
parameters, admitted exhaustive traces (indeed, just binary-swap traces) faithfully
recover the available class realization.

## Build

Requires Python 3 and a LaTeX installation with latexmk, pdfLaTeX, Latin Modern,
AMS packages, mathtools, mathrsfs, geometry, microtype, booktabs, longtable,
tabularx, enumitem, xcolor, fancyhdr, tcolorbox, listings, aliascnt, xurl,
hyperref, and cleveref.

```sh
./build.sh
```

Or:

```sh
python3 code/finite_checks.py --output data/finite_checks.json
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The output JSON is deterministic. The PDF bytes may vary with the toolchain,
metadata timestamps, and fonts installed locally. No font files are distributed.

## Status

These are ordinary mathematical research proofs, not claims of historical priority,
independent refereeing, or proof-assistant verification. The finite checks cover only
finite mechanisms. No repository files were changed, and no Lean build was run.
The source audit is targeted, not a certification of all earlier repository results.
