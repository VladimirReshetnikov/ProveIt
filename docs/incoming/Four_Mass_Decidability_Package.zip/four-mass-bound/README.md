# Four mass units and exact reachability

Research release, 3 October 2026.

## Main conclusions

For a fixed one-dimensional finite-alphabet conservative cellular automaton with a unique zero-weight vacuum, positive integer non-vacuum weights, and at most one weight-one symbol, exact reachability and finite-pattern occurrence are decidable from finite inputs of mass at most four. Anchored and translation-invariant observations are both covered.

The complete proof is in `four-mass-decidability.pdf` and its editable `four-mass-decidability.tex`. The proof is independently mathematically audited; it is not proof-assistant formalized, and this package does not implement a compiler for arbitrary CA rule tables.

An explicit ordinary binary radius-six four-particle shuttle has anchored pattern `10011` hit times

    t_k = k^2 + (2d - 11)k,  d >= 7, k >= 0.

These times are not eventually periodic. With d=7+x, the quartic

    [k^2 + (2x+3)k - t]^2

has one natural witness k, uniquely at a hit. Natural x,t with a nonnegative rational witness give the same fiber; nonnegative real witnesses do not. This example is noninjective and is not a universal-computation or reversible construction.

The unique-unit four-mass lower bound is compatible with the five-particle numerical universality upper bound reported by the 2016 Alhazov–Imai publisher abstract. No five-particle binary upper bound is inferred. Primary 2021 lower-particle results are credited. No novelty or present-day open-problem claim is based on failure to find a later paper.

## Contents

- `four-mass-decidability.pdf`, `.tex`: complete report
- `finite-seed-section-lemma.md`: detailed finite seed and threshold construction
- `BINARY-EXPANDING-SHUTTLE.md`: binary rule, complete timing proof and arithmetic ledger
- `binary-radius6-conservation-certificate.json`: all 8,192 rule bits and 4,096 de Bruijn potentials
- `test_binary_expanding_shuttle.py`: producer checks and certificate regeneration
- `test_expanding_shuttle.py`, `EXPANDING-SHUTTLE.md`: earlier typed-weighted example used by the arithmetic audit
- `independent/`: two independent binary implementations, mathematical audit, arithmetic checks and receipts
- `figures/`: vector trace, exact data and figure-generation source
- `SOURCE-PROVENANCE.md`: precise primary-source scope and page mappings
- `SHA256SUMS`: integrity ledger for the sealed files

The `test_*.py` producer harnesses and independent audit evaluators are internal verification code, not general-purpose APIs. They use explicitly valid mathematical fixtures. The strict public helper surface is `binary_exact.py`, with 13 separately recorded boundary-test groups passing in normal and optimized Python. It accepts only exact built-in integer arithmetic, rejects bool/float coercions, snapshots mutable inputs, and permits negative lattice coordinates while rejecting negative natural timing parameters. Certificate verification proves conservation; the test suite separately checks its identity against this shuttle.

## Reproduce the checks

Python 3 and its standard library suffice for all non-figure tests:

    ./run-tests.sh

The script can be run from another working directory. It regenerates the producer receipts and rechecks the portable independent scripts. The conservation potential identity is exact on every de Bruijn edge; summing it telescopes for every finite configuration. Dense-window and trajectory tests supplement that identity and the proofs, rather than proving the general theorem by enumeration.

The principal recorded binary checks include 262,144 dense conservation cases, 302,400 direct steps and 2,424 predicted hits. An independent component replay uses 49,640 direct steps over 40 gaps. A separate guarded-pattern detector reconstructs all local outputs and checks closed-form transitions at section indices through 10^80. See JSON receipts for precise counts and boundaries.

## Rebuild the report and figure

With a TeX Live installation providing article, lmodern, amsmath, hyperref, enumitem and graphicx:

    ./build.sh

The build keeps caches under `.build/` and fixes its source date. The vector figure is already included. Regenerating it additionally requires matplotlib:

    python figures/draw_binary_shuttle_trace.py

No installation or network access is needed when dependencies are already present. The scripts do not download or execute external code.

## Portability and audit provenance

The independent audit scripts were copied from the separately authored review and had only workspace paths replaced by paths relative to their own file. Their computational logic is unchanged. They were rerun successfully from `/tmp` and from a freshly unpacked package.

The earlier mass-three release is not modified by this work. No external paper is reproduced in the archive; use the primary links in the provenance file.
