# Report57 Five Signal Nonsemialgebraic Periodic Validity

4 October 2026. A conventional mathematical report with an independently audited
physical construction and portable exact arithmetic/inert-data replay.

## Result

Exactly five live signals, a fixed complete 138-binary-collision macro, 169
meta-signal types, eight rational speeds, and 36 exact strict chamber rows realize
a contracted irrational-angle rational rotation. The normalized infinite-validity
set is the disk of squared radius 4/1845 minus the inverse orbit of
p=(4/205,-26/615) on its boundary. It is nonsemialgebraic, and no finite
polynomial-sign formula agrees on all rational inputs or all positive integer
gap triples. Rational-input membership is nonetheless elementary and decidable.
All valid inputs of the supplied contracted machine are Zeno with an explicit
rational linear clock.

The 114-event non-Zeno variant is a separately reclosed machine: rule 113 must
emit Q0 rather than Q114. It is not a repeated prefix of the unchanged 138-rule
JSON. The sharp four-versus-five universal sign-classification boundary depends
on the separately audited Report56 theorem included here. There is no claim of
undecidability, impossibility of Diophantine or quartic certificates, literature
priority, or optimal speed/phase/rule count.

## Read and inspect

- `Report57.pdf`: full report, all proofs, analytic diagram, all 36 guards and
  all 138 explicit rules in appendices
- `Report57.tex` and `assets/`: complete editable LaTeX sources; keep these together
- `science/construction/`: byte-preserved original physical proof, guards,
  explicit rule JSON, clock, and inert author scripts
- `science/companion/`: byte-preserved arithmetic/boundary companion and handoff
- `independent_audit/`: frozen independent PASS audit, its two newly authored
  checkers, pinned inert source copies and complete receipts
- `dependency_report56/`: separately audited at-most-four-signal proof, audit,
  manuscript, and delivery hashes, documenting the lower-population dependency
- `audit_replay/`: portable hash-pinned adapter, expected replay summary and test receipts
- `manuscript_review/`: independent manuscript/artifact/visual review
- `verification/`: preservation, rebuild, visual, and replay receipts
- `tools/`: freshly authored inspected release utilities and adversarial tests

The frozen research README files retain their original historical wording and
paths. This top-level README describes the portable release. The scientific
author scripts are included for inspection only and are not executed by the
supported replay. The report does not claim to implement a generic physical
macro frontend or physical simulator.

## Verify an extracted packet

Use Python 3.9 or newer, with standard-library modules only. Run Python in
isolated mode and without optimization. Replace TRUSTED_MANIFEST_SHA256 with
the manifest hash supplied alongside the delivery through a trusted channel.
Do not obtain the trust anchor merely by hashing an untrusted download.

    python3 -I tools/release.py verify --manifest-sha256 TRUSTED_MANIFEST_SHA256

Verification checks the exact file/directory inventory, bytes, lengths, and
canonical 0644 file / 0755 directory modes. The manifest cannot bind itself;
its external trusted hash supplies that final integrity link. Extract with
POSIX modes preserved. Ordinary `unzip` preserves this packet's fixed modes.
No network access is required.

The fresh independent manuscript review passed 876 exact algebra/static-binding
assertions and visually verified every final page. Its optional additional
checker requires SymPy (tested 1.14.0), unlike the standard-library-only replay
below. See `manuscript_review/MANUSCRIPT_REVIEW.md` for its separate command and
scope. The review does not substitute for final archive verification.

## Replay only the independently authored checkers

Choose a brand-new absolute output directory outside this packet:

    python3 -I audit_replay/portable_audit_replay.py --audit-packet /absolute/path/to/packet/independent_audit --output-dir /absolute/path/to/new-replay

The adapter verifies the complete pinned audit manifest and 13 frozen files.
It runs only `audit_exact_algebra.py` and `audit_inert_rules.py`, rebasing their
OUT/SRC assignments in memory. Their frozen bytes are unchanged. The original
author emitter, author algebra/membership scripts, saved rule program, upstream
programs, and physical simulations are not executed. Checks are exact rational
linear algebra and static rule-template/data validation, not event selection or
trajectory replay.

The five regenerated substantive outputs must match the frozen originals
byte-for-byte. The final `PORTABLE_REPLAY_RESULT.json` must have SHA256:

    33f9211a5b53186ad4cfccf4058e60ca98ce4ef3815c3604d80215258bf60bf3

The adapter is an integrity/reproducibility utility for these approved fixed
checker bytes, not a sandbox for arbitrary Python. Assertions must stay enabled.
Its accompanying test receipt documents checks on new disposable copies. Mathematical
proofs, rather than finite fixtures, establish the all-input statements.

## Clean deterministic PDF rebuild

Requirements: TeX Live with pdfTeX/pdflatex, Latin Modern, amsmath/amsthm,
microtype, geometry, longtable, enumitem, fancyhdr, needspace, seqsplit, TikZ,
and hyperref. The supported build currently expects the installed Linux TeX
executables at `/usr/bin/`. The exact tested installed TeX input and executable
hashes are recorded in `verification/tex-dependency-manifest.json`; linked OS
libraries are outside that lock's scope. Poppler is used for visual rendering.

    python3 -I tools/release.py build-pdf --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /absolute/path/to/new-build

The build uses only the three reviewed LaTeX inputs, a fresh format/home/cache,
fixed source epoch 1791072000, no inherited TeX environment, and disabled shell
escape. Three passes must resolve all references without overfull boxes. A
sealed rebuild must exactly reproduce `Report57.pdf`. To require the same TeX
dependencies, additionally pass `--dependency-lock` naming the included lock
and `--dependency-lock-sha256` with its externally verified manifest-bound hash.
Different TeX installations may require the specified dependencies to reproduce
the same bytes; no cross-engine byte-identity claim is made.

## Deterministic archive and preservation tests

    python3 -I tools/release.py archive --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /absolute/path/to/new-Report57.zip

The ZIP uses sorted paths, uncompressed ZIP_STORED entries, fixed dates, fixed
modes, empty comments/extra fields, and exact member validation. Repeating to a
new filename produces the same bytes. Existing paths, including dangling
symlinks, are never overwritten. Release utilities reject source/output overlap,
symlink components, hardlinked inputs, special files, and ambiguous paths. Failed
new build directories are retained for diagnosis. There is no delete/cleanup mode.
The packet must remain quiescent while a release command runs; these utilities
do not claim to defend against concurrent hostile filesystem mutation.

The independently authored release-tool fixture suite passed 46 checks,
including input corruption, path aliasing, preserved existing outputs,
symlink/hardlink/special-file rejection, dependency locks, clean deterministic
synthetic PDFs, deterministic ZIPs, and relocated verification. To reproduce:

    python3 -I tools/test_release.py --output /absolute/path/to/new-tests --with-pdf

Do not run `seal` on this already sealed packet. For an intentionally edited new
version, work in a separate copy, preserve the original delivery, independently
review the new content, and create a new trusted release pin.

## Limits

The five-signal audit does not re-prove Report56. This packet's clocks concern
valid finite pre-accumulation prefixes and give no continuation at or after the
Zeno point. Finite arithmetic checks do not replace the conventional proof; hash
verification establishes integrity, not mathematical truth.
