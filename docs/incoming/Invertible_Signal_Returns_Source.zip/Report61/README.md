# Report 61

## Main result

Under the full outgoing binary-section, positive-flight and open-chamber hypotheses, every fixed complete collision word has an invertible rational positional return. A literal same-face return has determinant sign `(-1)^m`, with exact magnitude equal to its product of outgoing/incoming relative-speed ratios.

A fully explicit seven-rule, eleven-type, five-live-signal primitive realizes

    J = [[-2/3, 5/6], [0, 1]]

on the stationary-marker section. Its exact one-word chamber is `0 < x < y < D` and `y < 4x`. Composing it with the frozen positive-determinant compiler gives every rational invertible planar matrix, with any positive rational common scale. The singular obstruction is restricted to the stated full-section model; it is not a broad impossibility claim for projected, lower-dimensional, nonbinary or population-changing models.

The standalone primitive's infinite-validity condition is `1/4 < x/y < 7/8`. On positive integer physical gaps `g1=x`, `g2=y-x`, `g3=D-y`, it has the explicit degree-two certificate

    (3*g1 - g2 - u)^2 + (7*g2 - g1 - v)^2 = 0,
    u, v positive integers.

The witnesses are unique. The unused far gap `g3` is deliberately absent. The report also proves the exact finite-macro clock and the Zeno/rational accumulation-time extension for scaled composite words.

## Reading and editing

- `Report61.pdf`: the visually reviewed report
- `Report61.tex`: editable standalone LaTeX, exactly flattened from the modular source
- `manuscript/`: the equivalent modular LaTeX and its byte pins
- `science/frozen-proof/`: unchanged mathematical proof, rule/guard JSON, original static arithmetic source and receipt
- `science/frozen-proof/dependencies/POSITIVE_COMPILER_PROOF.md`: unchanged Report 60 physical realization dependency, pinned by SHA-256
- `audits/scientific/`: the separate frozen mathematical review and independent arithmetic evidence
- `audits/manuscript/`: fresh manuscript review, including the added infinite-validity/certificate/clock deductions
- `audits/release-tools/`: build and release tool review
- `audits/portable-replay/`: independent review of the portable arithmetic replay adapter
- `tools/portable-replay/`: sealed adapter, exact input pins, regression harness and receipts
- `qa/`: final typesetting, all-page visual review and replay receipts
- `RELEASE_MANIFEST.json`: byte inventory of every regular release file except the manifest itself; the ZIP has a separate externally supplied hash

The frozen author checker and prior compiler source are inert evidence. No upstream constructor, saved schedule, trajectory simulator or Lean program was executed to produce this report. The independent review used newly written static exact rational identities and whole-interval positivity certificates. Finite fixtures do not replace the generic proofs. This is not a proof-assistant formalization.

## Typesetting

The supplied PDF is reproducible with the inspected release builder in its authenticated Linux TeX/Poppler environment. It creates a fresh format and temporary workspace, disables shell escape, checks standalone/modular equality, records and authenticates installed executable and TeX inputs, renders all pages, and leaves the source release unchanged. It requires a fresh external output directory whose parent exists.

From the extracted `Report61` directory, first authenticate the package against the externally supplied ZIP/manifest hashes. Then read the tool's help and run:

    python3 -I -S -B tools/build_report61.py \
      --pins-sha "$(sha256sum manuscript/MANUSCRIPT_PINS.json | cut -d ' ' -f 1)" \
      --dependency-lock-sha "$(sha256sum tools/BUILD_DEPENDENCIES_LOCK.json | cut -d ' ' -f 1)" \
      --output-dir /absolute/fresh-report61-build \
      --require-packaged-match

The dependency lock is deliberately strict: a different installed TeX/Poppler version is rejected rather than silently claimed as byte-reproducible. Dynamic libraries are not inventoried, and the helper is not an operating-system sandbox. The standalone LaTeX is also editable and conventionally portable to an appropriate LaTeX installation with the standard packages named in its preamble; such independent typesetting need not produce byte-identical PDF output.

For deliberate manuscript edits, first make an unsealed authoring copy, omitting its old `RELEASE_MANIFEST.json`. In that copy, `tools/release61.py prepare` regenerates the standalone source and local manuscript pin map; it deliberately refuses to edit a sealed tree. That authoring operation does not independently authenticate the edited mathematics. Re-review, a fresh build, all-page inspection and a new release seal are then required.

## Portable independent arithmetic replay

The reviewer-owned adapter runs only the authenticated, unchanged independent checker copied to a fresh external output directory. It reads the author scientific files solely as inert bytes. With `ROOT` replaced by the canonical absolute path to this extracted package:

    python3 -I -S -B ROOT/tools/portable-replay/replay.py \
      --science-root ROOT/science/frozen-proof \
      --audit-root ROOT/audits/scientific \
      --pins ROOT/tools/portable-replay/PINNED_INPUTS.json \
      --output-root /absolute/fresh-report61-replay

The complete science/audit byte inventories must match their authenticated pins. The deterministic evidence JSON must match byte for byte. Path-bearing stdout is checked against the exact expected bytes for the relocated output, not falsely compared to an old path-bearing receipt. Read-only relocated inputs are supported. Symlinks, hardlinks, special files, lexical aliases, changed or extra/missing inputs, overlaps and reused outputs are rejected. See the adapter README and independent review for the exact tests and limitations.

The adapter requires trusted Python 3 and a quiescent POSIX filesystem with `O_NOFOLLOW`. Python isolation is not an OS/network sandbox or a defense against a compromised interpreter, kernel or hostile concurrent file replacement. No stronger isolation is claimed.

## Scope and attribution

Number preservation is not global reversibility. The compiler may depend on the chosen matrix and scale. No universal Turing-completeness, single unchanged universal rule table, novelty, priority, minimality or polynomial-size compilation claim is made. No continuation through a Zeno limit is defined.

The source proof and the prior Report 60 dependency remain unchanged. The direct two-witness and finite-clock deductions were added in this manuscript and checked by the fresh manuscript reviewer; they are not backdated into the frozen source packet. Primary literature is linked and precisely located in the report's bibliography.
