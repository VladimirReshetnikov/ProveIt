# Two-Endpoint Confluence for Catalan Hankel Determinants

**An exact even finite-size expansion, the first interaction law, and a sharp critical scale**

Prepared for Vladimir Reshetnikov, 29 September 2026. AI-assisted mathematical research.

## Read the article

`article.pdf` is the 20-page article, including its title page, contents,
proofs, examples, ten proposed research directions, appendices, and references.
`article.tex` is its complete LaTeX source. No external images or custom font
files are required.

The starting point is the explicit moving-endpoint question in Part II,
Section 24.4, of ProveIt's *Shifted Catalan Hankel Polynomials*. See `SOURCES.md`
for the exact repository revision and comparison with earlier work.

## Main results

For the Catalan moment determinant H_N(q), let m roots approach 0 and ell roots
approach 4, with fixed total degree d = m + ell. The effective size is
nu = N + d/2. Use roots 2 - 2 cos(sqrt(y)/nu) and
2 + 2 cos(sqrt(v)/nu), with all expressions defined by entire power series.

After removing the sign (-1)^(N ell) and the power
nu^[binom(m,2) + binom(ell+1,2)], the article proves:

- An **exact convergent even expansion** in 1/nu, locally uniform in all
  scaled coordinates, including arbitrary internal root collisions.
- A factorized leading profile in confluent cosine and sine determinants,
  together with the **complete first correction**, whose mixed derivative
  has coefficient -1/4 inside the common prefactor.
- An exact centered hyperbolic alternant generating all higher coefficients,
  and a fully explicit, conservative analytic remainder bound.
- Positive Schur expansions of the outward profiles and a **sharp stability
  criterion**: relative to the fixed-endpoint determinant, the ratio tends
  to 1 exactly when every outward displacement is o(N^-2). If the largest
  displacement multiplied by N^2 tends to infinity, the ratio diverges.
- The repeated-root limits requested by the source, their values at zero,
  and their explicit first corrections in the source's uncentered scaling.

The endpoint result covers both clusters simultaneously and all fixed
multiplicities. It does **not** resolve the separate nonendpoint collision
question, arbitrary-weight hard-edge universality, or growing-multiplicity
limits.

## Status

The manuscript contains conventional written proofs. It is unrefereed and
has not been formalized in Lean, Rocq, or another proof assistant. Classical
Christoffel and hard-edge theory are credited; worldwide priority for every
combined result is not established. The computations support and audit the
proofs but do not replace them.

## Reproduce the computations

Python 3.10 or newer is required. The tested numerical dependency is
`mpmath==1.3.0`.

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

The script locates `data/` relative to itself, so it can run from a different
working directory. It rewrites `data/verification.json` and
`data/verification.txt`. The recorded run passed **810 checks**:

- 710 exact-arithmetic checks using Python integers and `fractions.Fraction`;
- 100 high-precision diagnostics at 100 decimal digits.

The exact checks compare original moment determinants with confluent
Christoffel determinants, audit endpoint jets, and test centered coefficient
minors. Numerical checks cover correction residuals, evenness, analytic
continuation, and endpoint constants. They are **not** outward-rounded
interval certificates. The source includes the tested parameter ranges;
the JSON includes the numerical examples and residuals.

The shipped program verifies the leading and first correction. It is not a
complete optimized arbitrary-order coefficient implementation.

## Rebuild the PDF

With a standard TeX Live installation containing the packages named in the
preamble:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times to settle contents and references. The document uses standard
New TX text/math packages. Font binaries are not included.

## Files

- `article.tex`, `article.pdf`: source and compiled article.
- `code/verify.py`: exact-arithmetic and high-precision verification.
- `data/verification.json`, `data/verification.txt`: actual recorded results.
- `SOURCES.md`: pinned provenance and literature comparison.
- `PROOF_AUDIT.md`: dependency structure and verification boundary.
- `requirements.txt`: numerical dependency.
