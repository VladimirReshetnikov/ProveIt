# Equal-content ballot words: asymptotics and inverse models

This package contains an eight-page mathematical note on OEIS A215562, A215570, and the fixed-alphabet rows of A215561.

## Main results

- A proof of the displayed OEIS leading constants, with the equal-content constraint and periodic lattice factors retained
- Every fixed algebraic order of the asymptotic expansion, with an algorithm for its coefficients and an O-remainder at that fixed order
- Explicit first relative corrections for the four- and five-letter cases
- An algebraic multivariate excursion series, implying D-finiteness of its equal-content diagonal
- Positive-real inverse models with transported error bounds, and separate discrete-threshold localization

The proofs have been independently reviewed. Exact and high-precision computations corroborate them but do not replace the infinite mathematical arguments. These results are not machine formalizations and no comprehensive novelty claim is made. Classical kernel and singularity results, including earlier basketball-walk expansions, are cited in the note.

## Contents

- `article/ballot-asymptotics.pdf`: readable report
- `article/ballot-asymptotics.tex`: editable mathematical source
- `verification/check.py`: independent assertion-based exact checker
- `verification/derivations/`: transparent symbolic derivations, independent dynamic programming, and automatic numerical root differentiation
- `verification/receipts/`: mathematical-review approval and computational receipts
- `verify.py`: portable verification driver

## Reproduce the computations

Use Python 3.10 or later with the packages in `requirements.txt`:

    python -m pip install -r requirements.txt
    python verify.py --output-dir verification-output

The driver verifies the reviewed TeX hash, checks the symbolic identities and kernel polynomial, tests covariance determinants for q=2 through16, checks134 finite bridge identities, independently recomputes diagonal coefficients through n=30, and independently recomputes the first corrections by numerical implicit differentiation. It exits unsuccessfully when assertions are disabled (`python -O verify.py`). Successful verification is finite corroboration of the separately supplied proof.

To rebuild the PDF in a normally configured TeX installation:

    cd article
    pdflatex -interaction=nonstopmode -halt-on-error ballot-asymptotics.tex
    pdflatex -interaction=nonstopmode -halt-on-error ballot-asymptotics.tex

## Scope limits and future work

The alphabet is fixed. The note does not give growing-alphabet estimates, effective numerical asymptotic thresholds, a proof of the particular guessed recurrence in A215570, a complete exponentially improved transseries, or a canonical analytic interpolation of the integer sequence. Its positive-real inverses belong to explicitly defined finite-order analytic models; the discrete threshold remains a separate rounding problem.
