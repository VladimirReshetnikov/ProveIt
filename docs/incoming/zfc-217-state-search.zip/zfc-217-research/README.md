# Search below 218 states for Con(ZFC)

**Status: no justified machine with 217 or fewer working states was obtained.** This archive is a reproducible research checkpoint, not a claimed improvement of the 218-state bound.

The requested machine model is binary, deterministic, single tape, two-way infinite, initially blank, with L/R moves. The terminal label is not counted. All work is pinned to ProveIt commit `9adcaff0a72486ecc81242e0eca86e428c74879e`.

Read **`zfc-217-state-search.pdf`** for the integrated mathematical report. Its source is **`zfc-217-state-search.tex`**, with the included `sections/` fragments. The report separates ordinary mathematical arguments, arbitrary-natural symbolic runtime proofs, exact finite startup checks, finite search results, and unresolved obligations. No new Lean/Rocq kernel theorem is claimed.

## Results that survived verification

| Construction | Source DAG nodes | Working states | Evidence / remaining gap |
|---|---:|---:|---|
| Omit successful-MP dummy zero push | 205 | 218 | Exact source edit, explicit proof-compiler repair, 6,142 arbitrary-natural primitive interfaces, exact blank startup |
| Swap MP and DROP command tags (DMN) | 205 | 218 | Command recoding plus cofinal padding, 6,167 arbitrary-natural primitive interfaces, exact blank startup |
| Reversed Cantor stack with PUSH16 | 206 | 229 raw | All-natural arithmetic proof; raw prefix allocation only; runtime and startup unvalidated |
| Merged NIP/DROP command | 204 | 223 raw | Completeness open; raw prefix allocation only |
| K/S-only implication basis | 204 | — | Equiconsistency open; proposed physical allocations fail |
| Reassociation-only specimen | 204 | — | Existing decoder marker obligations fail |

The two validated alternatives are in `variants/omit-zero/` and `variants/dmn/`. Each contains `machine.native.tm`, canonical `machine.tm`, the source list, and a relabeling map. Canonical working states are 0–217; initial state is 0; halt is 218. Native dispatcher is 84 and native halt is 254. A transition line is `state read write direction next`.

### Exact native row changes

Against the pinned baseline:

```text
Omit-zero:
164 1 1 R 98  ->  164 1 1 R 114

DMN:
135 1 1 R 12   ->  135 1 1 R 143
185 1 1 R 143  ->  185 1 1 R 12
```

These changes retain 218 states. They must be paired with their respective modified source semantics.

The omitted-push compiler repair removes only the final NIP from the existing successful-MP cleanup. The report proves why this restores the original compiler contract. The DMN argument permutes finite command codes and uses the existing reset/padding construction to produce arbitrarily large encodings of any compiled refutation.

### Fresh operational checks

| Variant | Guarded interfaces | Symbolic rules | Blank steps | Root logical registers |
|---|---:|---:|---:|---|
| Omit-zero | 6,142 | 1,511,359 | 312,909 | `[3,0,0,0,3,0,0,0,0]` |
| DMN | 6,167 | 1,516,795 | 123,776 | `[2,0,0,0,2,0,0,0,0]` |

Both cover every transition row, with positive affine runtime and minimum duration constant 12. The unchanged symbolic engine quantifies independent arbitrary natural primary registers, natural extra gap, arbitrary first spare value, and an arbitrary finite remaining spare list. Its 4,000-step proof-construction cap does not bound represented values or actual runtime.

The independent dense-tape startup checker constructs the expected entire tape directly. It verifies all three endpoints (baseline and both alternatives), without using the original frame decoder. Operational verification does not replace the separate source-calibration argument.

## Run the packaged checks

Python 3 with assertions enabled is sufficient for the first commands; no packages or network access are needed. Do not use `python -O`.

```sh
python3 code/verify.py
python3 code/replay_runtime.py omit-zero
python3 code/replay_runtime.py dmn
python3 experiments/source_compression/code/verify_checkpoint.py
python3 experiments/source_compression/code/verify_invariants.py
```

`code/verify.py` checks input identities, literal source transformations, complete ordered receipt coverage, positive durations, exact native/canonical relabeling, and four independently rederived unary block schemas. It reruns the exact startup, prototype obstruction, and finite countermodel checks. The two `replay_runtime.py` commands freshly rederive every arbitrary-natural interface, rather than only auditing stored receipts; each usually takes a few minutes.

The source-checkpoint verifier reconstructs selected sources exactly and compares independent CFG resolvers. The invariant verifier also requires a C++17 compiler as `c++`. It checks all 5,552,082 ternary configurations and 6,232,731 closure edges from the compressed bitmap. The abstraction admits registers 0 and 4 at least two initially and all others zero. It is a source invariant, not an exact characterization of the blank machine's reachable configurations.

Generated verification outputs normally go under `reproduced/`; the dense startup checker rewrites its deterministic receipt identically. The root `MANIFEST.json` identifies all packaged files except itself. The checkpoints also retain their own manifests.

## Experimental material

- `experiments/formalism/`: complemented quantifiers, implicational bases, generic code-transfer obligations, three independently verified finite Heyting countermodels, selected source generators, and the omitted-push proof notes.
- `experiments/source_compression/`: the PUSH16 proof and exact reconstruction, merged-command sources, the corrected 444-case constructor-code sweep, guarded zero rewrites, and independent Boolean/ternary invariant certificates.
- `experiments/machine_compression/`: rejected 217-state tables, concrete startup/runtime counterexamples, precise search scopes, portable checkers, and a curated `search-source/` folder. That folder contains context generators, fold/helper synthesis programs, exact finite pools, terminal receipts, and reproduction commands; large context matrices are regenerated.
- `vendor/portable/`: unchanged, hash-pinned K221 runtime/source utilities used by the new replay driver.
- `baseline/` and `references/`: pinned inherited inputs and relevant mathematical definitions. Copied upstream summaries are provenance, not a complete standalone ancestral Lean build.

The experimental formalism generators use `FORMALISM_PORTABLE` to locate the central vendor. From the extracted archive root, set it to the absolute path of `vendor/portable`. Their README documents optional runs. The independent finite-model verifier does not need that variable.

The final 444-variant constructor-code sweep supersedes earlier partial odd-membership measurements. Its native layout is the unique measured 205-node minimum; the best changed layout has 206 nodes and maximum zero run 10. These are finite implementation measurements, not lower bounds.

The final ternary representative search collected 11,104,165 runs and 14,674,840,421 transitions. None of its 152 same-head or 30 shifted preliminary folds survived all collected contexts. Joint helper searches also failed in their stated templates. Counts overlap and must not be added as a count of distinct machines. The archive makes no minimality claim.

## Rejected 217-state prototypes

These are deliberately stored only in the machine experiment checkpoint, labeled as rejected. The old state-301 deletion enters a provable infinite writing ray after 85 blank steps. Two apparent bootstrap repairs reach clean frames but execute their actual first primitive incorrectly 688 steps later. A third fails a separate invariant-admitted interface. Those facts refute the proposed runtime bridges; they do not constitute a general impossibility theorem.

## Build the PDF

With a normal TeX Live installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error zfc-217-state-search.tex
pdflatex -interaction=nonstopmode -halt-on-error zfc-217-state-search.tex
```

The PDF was compiled, rendered on every page, and visually inspected. All included work may be incorporated under the accompanying MIT No Attribution license; copied ProveIt code retains its upstream attribution in the files.
