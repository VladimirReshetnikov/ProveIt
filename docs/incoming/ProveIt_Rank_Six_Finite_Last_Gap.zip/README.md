# The Last Newton Inequality at Rank Six

For every bipartite graph of matching rank six, with unit activities on the left shore and arbitrary positive activities on the right, the perfectly matchable endpoint-set coefficients satisfy

    5 p5^2 >= 12 p4 p6.

This is a finite-activity theorem about the last gap. Full ULC6 remains open at gaps2,3,4. The first gap is already universal.

The proof reduces the three core activities to an unrestricted nonnegative quadratic, then uses two matroid Schur bounds and a quantitative two-point lemma for graph-generic columns. That lemma has ten exhaustive virtual support profiles. A sharp elementary-moment reduction and the included rational identities certify all ten.

## Contents

- article.pdf and article.tex: complete mathematical report
- build_local.sh: TeX build helper for the established execution environment
- data/exact_certificate.json: all858 nonnegative monomial-weighted squares and7801 positive remainder monomials
- code/replay_certificate.py: independent exact reconstruction of every target and rational identity
- code/verify_virtual_orbits.py: exhaustive common-coordinate ratio-partition classification,55 labeled profiles and10 orbits
- code/check_last_gap_quadratic.py: exact endpoint-set DP, quadratic-identity and positive-definiteness regression
- code/replay_all.py: run the three checks and compare their exact outputs with data/
- code/generate_certificate.py: optional numerical discovery and exact rational-reconstruction program
- VERIFICATION.md and SHA256SUMS

## Required verification

Python3 standard library is sufficient:

    python code/replay_all.py
    python -O code/replay_all.py

No solver, numerical tolerance or third-party dependency is used in the proof-relevant replay. The verifier checks the complete expected profile list, every exponent and coefficient, positivity of all rational multipliers, and exact equality to the independently reconstructed quartic.

The dynamic-programming cases are supplementary regressions. The universal argument depends on the profile completeness proof, moment inequalities and exact polynomial identities, not on a population search.

## Optional rediscovery

The optional generator needs installed SymPy, NumPy and SciPy. It finds a nonnegative cone solution numerically, reconstructs the active basis exactly over the rationals when needed, and writes generate_certificate.json beside itself. Different solver versions may find different valid identities. Verify any new result explicitly:

    python code/generate_certificate.py
    python code/replay_certificate.py code/generate_certificate.json

The supplied certificate is already exact and does not require rediscovery.

## Build and scope

In a complete TeX installation, compile article.tex twice with pdflatex. build_local.sh additionally provides the format and font paths used in this research environment.

The global rank-six theorem uses the earlier minimum-cover theorem when one cover shore has at most two vertices; its precise statement and source are cited in the article. The new3+3 proof is included in full.

The two-point quantitative lemma is proved in the graph-generic setting, retaining the actual virtual-plane normal support. It is not asserted for arbitrary numerical vector configurations. No equality classification, optimal constant, formal-kernel verification or exhaustive priority claim is made.

