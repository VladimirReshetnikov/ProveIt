# Derivative Supports of x^(sqrt(x))

This report proves that the number A(N) of nonzero monomials in the Nth derivative of x^(sqrt(x)) satisfies

A(N) = N^2/2 + o(N^2).

The seven-page proof is self-contained. An exact reciprocal substitution gives a unit-disk coefficient integral. Strict angular monotonicity, convexity, and a positive terminal radial derivative supply complete circle-only saddle coverage. A boundary curvature expansion and an integer-triangle argument then show that the zero candidates have density zero.

The report also gives complete exact formulas on the diagonals ell=N−2 and ell=N−3, where ell is the number of exponent factors and k is the logarithm degree. Their zero families are:

- N=(3k^2+13k+8)/4, with k>=1 and k congruent to 0 or 1 modulo 4
- N=(k^2+9k+12)/4, with k>=3 and k congruent to 0 or 3 modulo 4

Both families are infinite and lie outside the reflection family (ell,k)=(N−1,0). They rule out a reflection-only exact classification for the half exponent.

The full all-defect zero classification remains open. The paper does not claim a global power-saving remainder or numerical order threshold.

## Files

- `article.pdf`: full report
- `article.tex`: complete LaTeX source
- `build_local.sh`: build helper for the supplied execution environment
- `verify_half_coefficients.py`: exact standard-library checker
- `half_coefficient_checks.json`: recorded results

## Reproduction and scope

Run `python verify_half_coefficients.py`. The checker verifies 455 reciprocal-transform identities and 33,523 diagonal coefficient identities. Its exact recurrence scans all rows through N=150; in that finite range the two displayed families account for all 16 observed nonreflection zeros. This observation is not used to infer a complete infinite zero classification.

Compile `article.tex` twice with a normal LaTeX installation, or run `bash build_local.sh` in the supplied environment.

The proof received independent mathematical and final-transcription review, and every rendered page was visually inspected. It is conventional mathematics, not a proof-assistant formalization or an externally refereed publication.

The half exponent is treated as a focused noninteger continuation of the derivative-support program in ProveIt's pinned `power-tower-derivative-term-counts/article.tex`, commit ca81647a9f679e96d49ffdbc54b0c0ab13d10a36. A bounded source comparison is recorded in the paper; no exhaustive worldwide priority claim or new OEIS identifier is asserted.
