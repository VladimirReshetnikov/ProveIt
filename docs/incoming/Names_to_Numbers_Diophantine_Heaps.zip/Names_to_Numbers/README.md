# Names to Numbers
## Exact Quartic Certificates for Dynamic Heaps and Local Graph Computation

Research draft, 30 September 2026. Prepared in response to a request to extend
Vladimir Reshetnikov's ProveIt research program.

Start with **article.pdf**. The editable source is **article.tex**.

### Main result

A memory log padded to N events and sorted with C deterministic comparators
has a natural-number quadratic residual certificate with exactly:

- 10C + 4N - 3 auxiliary variables;
- 10C + 7N - 4 emitted equations;
- 3m source coordinates for the m real events (not included above).

Their sum of squares is a single polynomial of degree at most four. A fixed
valid log has exactly one natural auxiliary assignment; an invalid log has
none. The implemented bitonic network uses C = N*k*(k+1)/4, N = 2^k.

The article also proves canonical birth-name normalization, a local heap/graph
compilation theorem, a pointer-only two-stack universality theorem, canonical
guarded quadratization, height bounds, and a perpetual-safety obstruction.
Twelve further research questions and a Lean integration plan are included.

### Files

- `article.tex`, `article.pdf`: full article with proofs and references.
- `code/memory_quartic.py`: complete memory-layer polynomial compiler and verifier.
- `code/pointer_machine.py`: two-stack heap logs and birth-order normalization.
- `tests/run_tests.py`: executable checks; Python standard library only.
- `tests/receipt.json`: observed coverage and results.
- `examples/memory_events.json`: the five-event worked input.
- `examples/memory_certificate.json`: all 284 coordinates (15 source + 269 auxiliary),
  292 quadratic residuals, and a valid assignment. The quartic is specified by
  their sum of squares rather than by expanding every square.
- `PROVENANCE.md`: sources, repository snapshot and limitations.
- `build.sh`: POSIX LaTeX build script.
- `SHA256SUMS`: checksums for the distributed files (excluding itself).

### Run the checks

Python 3.10 or later, without third-party packages:

```sh
python tests/run_tests.py
python code/memory_quartic.py --events examples/memory_events.json --output certificate.json
```

The tests overwrite the receipt and regenerate the worked example. Elapsed
execution time varies. The seed is fixed; timing and PDF metadata are not
claimed to be bitwise reproducible.

To verify an exported assignment independently of witness generation:

```python
import json
import sys
sys.path.insert(0, "code")
from memory_quartic import verify_export
with open("examples/memory_certificate.json", encoding="utf-8") as stream:
    assert verify_export(json.load(stream))
```

This verifies the supplied equations and assignment. It does not authenticate
that an arbitrary untrusted equation list encodes the claimed source program.

### Build the article

Run `sh build.sh`, or run pdfLaTeX on `article.tex` three times. The LaTeX
installation needs the packages named in the preamble, including newtx,
amsthm, microtype, tcolorbox, hyperref and cleveref. No bibliography service or
external bibliography file is required.

### Verification status

The article contains mathematical proofs; the implemented memory layer has
finite executable checks. This is **not** a Lean-certified or independently
refereed development. The full generic source-language compiler and a complete
interaction-combinator frontend are **not implemented** in this archive.
The two-stack module is a log demonstration, not a delivered Turing-machine
frontend. The linearithmic sorting-network variant is a proved corollary using
published sorting theory; the implementation is the bitonic variant.

The results concern bounded families whose dimension grows with the time
bound. They do not establish fixed-arity single-fold or finite-fold MRDP.
Historical priority for the assembled constructions has not been established.
No changes were made to the ProveIt repository.
