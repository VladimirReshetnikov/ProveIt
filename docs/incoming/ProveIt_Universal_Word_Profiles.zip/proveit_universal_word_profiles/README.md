# Universal Word Profiles on Scattered Spaces

**A finite-height attainment theorem, countable extremal witnesses, and an inverse theory of query spectra**

Prepared for Vladimir Reshetnikov, 30 September 2026.

## Main result

For a nonempty Hausdorff space X of finite last Cantor–Bendixson derivative
rank h, put t = |X^(h)|. If X is locally compact or sequential (in particular,
first countable), the maximum over q-colorings of the ordered layer count is

    Lambda_q(X) = h*(q - 1) + min(q, t).

The worst number of adaptive open yes/no questions is the ceiling base-two
logarithm of this integer. For infinite t, min(q,t) means q.

This answers Research question 12 in Part III, Section 41 of the pinned
ProveIt open-query report. The stronger theorem realizes the entire common-
supersequence profile of all reduced words of length h+1 with prescribed
initial colors, using a coloring constant outside a countable set. A countable
subspace witnesses the whole profile. An arbitrary coloring on the last
derivative can also be extended to a universal extremizer, with only
countably many exceptional lower-rank points.

The article additionally proves finite-product and bounded-height sum laws,
classifies complete layer-spectrum coincidences, and gives an exact finite
algorithm for deciding equality of query-depth spectra for every alphabet size.

## Status and limits

These are ordinary mathematical proofs, not a Lean or other proof-assistant
formalization. The article is unrefereed, and historical priority outside the
inspected sources is not certified. The primary advance is relative to the
repository question at the pinned snapshot. The classical normal form and
universal-word constant are credited and reproved, not claimed anew.

The results do not classify every fixed coloring at height two, do not cover
all Hausdorff spaces without a local hypothesis, and do not resolve transfinite
games. The countable witness is not asserted closed or compact. Finite code
checks do not prove any infinite-space result.

See SOURCES.md for the precise repository pin and source audit.

## Read and build

- `article.pdf`: compiled research article.
- `article.tex`: standalone LaTeX source, with internal bibliography and a TikZ figure.
- `code/verify.py`: standard-library Python checker and exact spectrum comparison function.
- `results/`: recorded checks, tables, alias classes, and a word/tree certificate.

Compile with `make pdf`, or run:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The source needs a conventional LaTeX installation with Latin Modern,
amsmath/amsthm, microtype, aliascnt, enumitem, booktabs, fancyhdr, listings,
TikZ, hyperref, and cleveref. No network access, BibTeX, external figures,
font files, or data regeneration is required.

## Reproduce the finite audit

Python 3.10 or newer; no third-party packages:

```sh
python3 code/verify.py --output results
```

Choose a different output directory to preserve the delivered records. Do not
run with `-O`, because assertions are verification conditions. Timing and the
Python version field can differ between runs; the mathematical output is
deterministic.

Recorded run: Python 3.13.5; all assertions passed.

| Check | Cases |
|---|---:|
| Universal-family parameter triples | 36 |
| Reduced candidate word comparisons | 185,322 |
| Comparisons allowing consecutive repetitions | 10,599 |
| Independent finite-forest minimax computations | 23 |
| Threshold boundary cases | 19,968 |
| Spectrum-pair tests | 8,448 |
| Dyadic-alias cases | 64,449 |
| Infinite-terminal normalizations | 4,352 |

The finite forest tests use Alexandrov ancestor posets, not finite Hausdorff
models of convergent sequences. The article explains this distinction.

## Use the all-alphabet equivalence algorithm

Load `code/verify.py` as a module, or run from the package root:

```python
import sys
sys.path.insert(0, "code")
from verify import spectra_equal

# Same query depths for every q >= 2, despite different layer counts:
assert spectra_equal(2, 1, 2, 2)

# None represents any infinite terminal cardinality:
assert spectra_equal(1, None, 2, 1)

# Different normalized heights cannot have equal unbounded spectra:
assert not spectra_equal(2, 1, 3, 1)
```

`None` means infinite t, h is a nonnegative integer, and a finite t is positive.
This routine is an exact theorem-based test, not a search through a finite
alphabet cutoff. Its proof is Theorem 8.3 in the article.

## Certificate convention

`results/certificate.json` records the word 01201 for q=3, h=2, S={0}.
All JSON positions are zero-based. A query
`ask_suffix_from_position: j` asks whether the layer index is at least j.
The `yes` branch keeps that suffix. The topological proof supplies the
openness of those suffixes.

`SHA256SUMS` records the delivered file hashes; it is not used by any proof.
