SEARCHING BELOW 245 STATES
Research contribution prepared for Vladimir Reshetnikov / ProveIt
18 October 2026

RESULT

No verified machine below 245 working states was found. This is a research
continuation with new ordinary mathematical results, exact finite
certificates, reproducible searches, and precisely diagnosed failed
experiments. It must not be installed as a replacement candidate machine.

The target remains an ordinary binary, one-tape, blank-start, L/R machine
with fewer than 245 working states, whose nonhalting is ZFC-provably
equivalent to Con(ZFC). All initialization and helper states must count.

READ FIRST

  zfc_sub245_research.pdf    Complete research report with proofs and scope.
  zfc_sub245_research.tex    Complete single-file, compilable LaTeX source.
  PROVENANCE.json           Source pins and claim/status inventory.
  evidence/                Fresh replay and packaging verification records.

NEW RESULTS

1. The 44 inherited semantic atoms have exact expansions over 30 closed
   atoms. Twenty-two admit exact affine contracts: five increments and
   seventeen draining loops. Structural support gives 134 commuting pairs;
   matrix equality adds 44 more. The 178-pair relation is certified by
   closed-control and unary-induction arguments, not numerical sampling.

2. There are 224 distinct AX source words with explicit adjacent-swap
   certificates, including the identity control. The largest stored
   disjoint-swap witness has 363 adjacent swaps. These are source-level
   equivalences; no smaller literal table follows automatically.

3. Ten annealing campaigns made 41,679,192 proposals (including repeated
   and rejected moves), with no qualifying grammar. Five finite MILP
   models, 5,130 reuse-weighted parses across two overlapping campaigns,
   and four equality screens provide additional scoped evidence. Solver
   infeasibility/optimality reports have no independently checked proof
   logs. The phrase-flow model timed out without an incumbent: UNKNOWN.

4. Five inherited left-child equations followed by the fixed atom e's
   left edge force source path 000000 ending at dec(T). They rule out a
   five-zero source bound under those exact locked interfaces. This is a
   finite mathematical obstruction, not a state lower bound.

5. A local increment can shift the unary prefix/header left one cell and
   leave the suffix unchanged in 2*width(prefix)+6 transitions. The exact
   244-state patch fails its existing instruction caller: a complete
   fixture produces pointer 0110 instead of 01011. Its allocation policy
   with unchanged source/control events would imply gap 63 after 2738
   source instructions and gap -1 after 3235. Full proofs and independent
   exact counterexample interpreters are included.

6. Assuming Con(ZFC), either one of the two native membership-congruence
   rows is underivable after deleting it while retaining native equality,
   all seven other rows, and the full literal CP/GIC bundle. Rank-preserving
   label-dependent interpretations prove this. A separate rank
   interpretation defeats the natural anchored right-row regularization's
   GIC transfer. Neither result separates consistency strengths or excludes
   every possible replacement interpretation.

QUICK VERIFICATION

From this directory, with ordinary Python 3 and assertions enabled:

  python3 -B verify.py

The default uses the standard library only and took about six seconds in
the preparation environment. It checks the reference table identity,
regenerates and compares the semantic certificates, replays the grammar
audit, logical diagnostics, local increment contracts, and exact integration
and space-budget counterexamples. It writes verification/ by default.
An alternate output directory can be supplied with --output.

The mathematical proof of the new universal source/local statements is in
the report. The finite logical diagnostics are not finite models of CP/GIC.
No new Lean/Rocq endpoint or serialized first-order ZFC proof is supplied.

FULL INHERITED 245-STATE REPLAY

  python3 -B tools/replay_baseline.py \
    --package reference/zfc245 --output replay245 --whole-frame --literal

This was freshly run and passed in about 533 seconds, including 8391
universally guarded cases, the whole-frame expansion, source bisimulation,
the exact 407915-transition blank prefix, and 8385 separate finite literal
fixtures. The recorded result is evidence/baseline/replay-summary.json.
The helper copies its input and applies the repository's declared replay
adaptation, omitting delivery checksum-manifest checks while preserving
the semantic gates. The complete baseline has an ordinary mathematical
certificate; its exact final 245-state Lean endpoint and PA endpoint remain
open in the inspected repository. They are not upgraded by this replay.

OPTIONAL DISCOVERY REPRODUCTION

  python3 grammar/reproduce.py search affine_trace
  python3 grammar/reproduce.py search zero5_fully_unlocked
  python3 grammar/reproduce.py milp fixed64
  python3 grammar/reproduce.py parse ranked

These regenerate searches, not proofs. See grammar/README.md for every
profile, seed, budget and model restriction. C++ searches require g++ with
C++17; optional MILP discovery requires NumPy and SciPy/HiGHS. The ten
recorded annealing budgets total about 42 minutes, and time-bounded reruns
need not produce the same proposal count or result. Frozen outputs are
rechecked independently by the quick verification command.

The four optional finite interpreter screens have their exact replay
commands in interpreter/README.md. They use a compressed fixture and C++
sources, with documented fuel and tape limits. No screen is an unrestricted
state-minimization proof. The multi-entry count measures individual edge
trials, and its joint search is capped.

BUILDING THE PDF

  make pdf

Or compile zfc_sub245_research.tex with pdflatex until cross-reference
rerun notices disappear (three passes from a clean directory). The master LaTeX file
contains all text and has no external figures or input dependencies.
Editable report-parts/ are retained; tools/assemble_report.py incorporates
the one shared scanner-obstruction fragment into the standalone master.

DIRECTORY MAP

  semantic/       Closed-block and affine commutation checkers/certificates.
  grammar/        Search code, profiles, outputs, logs and finite auditors.
  interpreter/    Local proof, rejected table, counterexamples and screens.
  logic/          Complete logical proofs and finite diagnostic scripts.
  reference/      Attributed sources, including the full 245-state package.
  evidence/       Fresh baseline, new-certificate and delivery QA records.
  report-parts/   Editable manuscript sections.
  tools/          Manuscript assembly and inherited baseline replay helper.

STATUS OF TABLES AND METADATA

reference/zfc245/machine/zfc245.tm is the existing 245-state control.
interpreter/left_increment_local244_old.tm is a rejected local integration
experiment. Historical tables inside the attributed reference package keep
their own original status; none is newly claimed here.

Raw grammar outputs have inherited framework_states:118 metadata. The
current routed control has 117 framework roles after its existing scanner
contraction. Abstract counts and old labels must not be promoted to a new
literal-machine state claim. A future qualifying grammar still needs its
actual table, source transport, runtime/frame and blank-start proofs.

ATTRIBUTION

The original compact calculus/machine is attributed to Mira-Cult, upstream
verification to Jeff Ketchersid, and the compiler framework to Andrew James
Wade. ProveIt and earlier incoming contributions retain their attribution.
Original notices and licenses accompany copied source material. See
NOTICE.txt and the reference notices. No new licensing restrictions are
asserted for the newly prepared research contribution.
