# Beyond K215: calibrated formalisms and encoding experiments

**Status: no machine with 214 or fewer working states has been established.**

This is a research packet toward the requested improvement. It contains two new **215-state** binary machines with complete arbitrary-value runtime proofs, a calibrated change to the proof-enumeration schedule, a generalized equality-binder calibration theorem, reproducible source and physical searches, and explicitly rejected 214-state tables with concrete counterexamples. It should be incorporated as research, not as an accepted `candidate-k214` release.

Read [report.pdf](report.pdf) for the complete exposition. [report.tex](report.tex) and [sections/](sections/) are the corresponding editable LaTeX sources.

## Pinned parent and machine convention

Parent repository: [VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt).

Revision: `2762b8a183830b1f5a30cf059ffb4d92e77cddde`.

Parent directory: `Computability/BusyBeaver/Research/ZFC/candidate-k215`.

The convention is a deterministic machine with one two-way infinite tape, symbols 0 and 1, a blank initial tape, head at position 0, and L/R moves only. Native start state is 0, dispatcher 84, and separate halt 254. The halt has no outgoing rows and is excluded from the working-state count. Both new tables have exactly 215 working states, 430 rows, and all 215 states are reachable in the directed transition graph. No state saving is hidden in initialization or relabeling.

| Object | SHA-256 |
|---|---|
| Parent native table | `9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2` |
| Parent source | `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba` |
| New scheduler table | `c6ff22b5446bb7f14a9f8ea02828fa694291ce1b7c71cf1ea3cb488d03d30dc5` |
| Normalized scheduler table | `04a920b972cd14da6d9bb0496a31fb882f2a37be9dae333894301c290176df7c` |
| New common source | `79425cf76b24b8739fd00e3fd091ca00de3b3379324f941158ba5e58061dc2b0` |

## Verified 215-state implementations

The primary copies are in [verified-machines/](verified-machines/). The machine-search packet contains byte-identical copies under shorter filenames for its own replay scripts.

| Table | Changes | Quantified cases | Symbolic steps | Blank startup |
|---|---|---:|---:|---:|
| `q13_cb215.native.tm` | From parent: `(8,1) := 1 R 103` | 6,177 / 6,177 | 1,698,805 | 88,116 |
| `q13_normal215.native.tm` | Additionally `(13,0) := 0 R 49`, `(13,1) := 0 R 60` | 6,177 / 6,177 | 1,695,331 | 87,920 |

Both use `q13_cb.sites.json`: 202 distinct source DAG nodes, 4,752 primitive occurrences, maximum depth 47, maximum zero run 6. Each duration polynomial has nonnegative coefficients and a positive constant; the minimum constant is 6.

Both blank prefixes reach dispatcher 84 at head −12, gap 5, logical registers `[N,T,W,A,D,H,X,Y,L] = [5,0,0,0,0,0,0,0,4]`, and 45 unit-valued spare blocks. The full tape contains exactly 110 one cells. An independently implemented root audit replays every transition and reconstructs the entire final frame, including its zero exterior.

The initial source list executes one harmless MP(0) in exactly 65 source primitives, leaving `[5,0,0,0,0,0,0,0,0]`. This root is related to the parent's accepted `[4,0,0,0,0,0,0,0,0]` by the counter-offset simulation in the report. Thus ordinary mathematics formalizable in ZFC establishes, for **each of these 215-state machines**,

```text
ZFC proves: not Halt(M, blank) <-> Con(ZFC).
```

This statement uses the explicit inherited numerical-calculus calibration. The new runtime certificates use unary and list induction over arbitrary natural primary values, arbitrary gaps, arbitrary nonempty finite spare lists, and complete zero exteriors. They are stronger than bounded numerical tests. They are not newly compiled Lean/Rocq kernel certificates.

## Main mathematical contribution

With Cantor pairing `P`, implication `I = 4P`, membership `R = 4P+1`, quantification `Q = 4P+2`, and equality `E = 4P+3`, replace the merged equality row by

```text
E(c,a) -> (E(c,b) -> Q_{f(a,b)} E(a,b)).
```

The retained gated seed bundle, logical rows, truth, MP, GEN, and dominated rho8 stay as specified in the report. It suffices that the primitive-recursive binder be fresh **off the diagonal**:

```text
a != b  ==>  f(a,b) != a and f(a,b) != b.
```

The precise theorem is `ZFC proves Fresh(f) -> (Con(C_f) <-> Con(ZFC))`. Each explicit binder `2P`, `4P`, `P+1`, `4P+j` for fixed `j>=1`, and `a+b+1` has the required elementary freshness proof in ZFC. The diagonal case is handled directly by equality reflexivity and the indiscernibility translation. Bare `P` fails at `(1,0)`.

This changes the numerical calculus without requiring the same theorem-code set. The direct source prices explain why arithmetic savings did not yet give a state saving:

| Binder | DAG nodes | Primitive occurrences |
|---|---:|---:|
| `4P+1` (parent) | 202 | 4,751 |
| `4P` | 203 | 4,750 |
| `4P+2` | 202 | 4,752 |
| `4P+3` | 204 | 4,753 |
| `a+b+1` | 204 | 4,705 |

The final joint scheduler/binder check gives 202 nodes and 4,753 leaves for CB1 plus `4P+2`, and 203 nodes and 4,751 leaves for CB1 plus `4P`. Allocation against both new runtime variants gives four infeasible protected-row models; exact inputs and a replay are in `source-search/joint-binder-scheduler/`. This is not a lower bound.

Other results include a safe equality/quantifier tag exchange, an explicit obstruction to transferring the old classical certificate to implication tag 3, countermodels for several proposed logical shortcuts, and a sufficient runtime contract that forgets spare-storage details while preserving the primary registers and next instruction.

## Rejected 214-state tables

These are counterexample artifacts, not candidates supported by a consistency theorem.

- `machine-search/rejected/scanner214.native.tm`: shortening the long-zero scanner proves 6,104 of 6,176 quantified cases but fails 72 at 37 leaves. On the supplied all-zero-register frame for site 26, CD1, the baseline returns the required frame after 588 transitions; the rejected table returns after 662 with a program-counter one at position 12 instead of 14.
- `source-search/rejected-enumerator-13-108/`: identifying state 13 with 108 in the revised scheduler reaches the next address after 656 transitions on the supplied CI8 frame but leaves primary register 8 at 0 instead of 1.

The existence of a source-primitive counterexample rejects the asserted simulation contract. It does not by itself prove anything about eventual blank execution of that rejected table.

## Reproduce the checks

Use Python 3.10 or newer. The quick audit needs only the standard library:

```sh
python3 verify.py
```

It checks the final manifest, exact input hashes and table changes, literal source construction, both complete blank traces, the exact marker/three-step proof, all 170 frozen source reassociations, binder-family minima, exact binder certificates, and the independent scheduler audit. It also verifies the identity and complete ordered coverage of the retained quantified-runtime receipts. It does **not** substitute for rederiving their arbitrary-value proofs.

To rebuild both full quantified runtime proofs, provide a new output directory:

```sh
python3 replay_full_runtime.py replay-runtime
```

To rebuild only the normalized table's proof:

```sh
python3 replay_full_runtime.py replay-normalized --table normalized
```

Each complete proof took about two minutes in the development environment. The proof constructor's finite symbolic-operation cap does not bound represented register values, tape gaps, spare-list lengths, or machine time.

Additional portable checks:

```sh
python3 machine-search/reconstruct.py --out replay-construction
python3 machine-search/replay_scanner_counterexample.py --out replay-scanner.json
python3 source-search/verify_source_packet.py
python3 formalism/check_binders.py --output replay-binders.json
python3 formalism/check_refill_source.py baseline/k215/sites215.json verified-machines/q13_cb.sites.json --output replay-refill.json
python3 new-binder-search/binder_row_permutations.py source-search/G_Q.json replay-G-Q-parameters
```

The last command exhausts all 279,936 parameter vectors for the specified source; each frozen binder family has its own receipt under `new-binder-search/`. The original parameter and row-order searches have their own scripts and README under `source-search/`.

For source rotations:

```sh
python3 source-reassociation/open_rotations.py
python3 source-reassociation/anneal_open.py --seed 214 --seconds 300 --output replay-open-anneal
python3 source-reassociation/anneal_zero.py --seed 52 --seconds 300 --output replay-zero-anneal
```

The timed heuristic trajectories are not claimed to be reproducible from a random seed alone: Python hash iteration and CPU timing affect them. Their exact resulting source trees, recipes, and complete CFG checks are frozen. The 574 single-rotation proposals constitute a finite enumeration under the two stated control-retagging policies.

C++17 finite physical searches and their exact scopes are documented in `machine-search/README.md`, `machine-search/search/summary.json`, and `source-search/targeted-marker-extension/README.md`. Optional protected-row allocation requires NumPy and SciPy. Negative results establish only the stated finite or bounded-search outcomes, not a general lower bound on 214-state machines.

## Rebuild the PDF

Run from this directory with a standard LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The delivered PDF was compiled with resolved references, checked for overflow, rendered page by page, and visually inspected. The report uses ordinary fonts and packages available in TeX Live.

## Directory map and provenance

- `report.tex`, `report.pdf`, `sections/`: complete exposition and reusable proof text.
- `baseline/k215/`: all 144 pinned parent files plus the Git-object verification record. Existing notices and licenses are retained.
- `verified-machines/`: primary new 215 tables/source and full compressed certificates.
- `formalism/`: exact arithmetic, finite-support, source-CFG, and tape-history checks; original reviewed theory material is preserved under `reviewed_material/` because the report copies received layout and wording edits.
- `source-search/`: 76-file source contribution, its own manifest, generators, finite search results, and explicitly rejected table.
- `new-binder-search/`: four additional complete binder/parameter searches.
- `source-reassociation/`: control-preserving rotations, timed searches, frozen source trees and recipes.
- `machine-search/`: 70-file machine contribution, its own manifest, reconstruction, physical searches, rejected scanner, and certificates.
- `additional-machine-search/`: exact short transition replacements and their attempted contextual folds.
- `inherited/`: pinned logical interfaces and compiler/calibration expositions used by the new proofs. Retained Lean files are dependencies, not a new complete build of the new theorems.
- `MANIFEST.json`, `QUICK_AUDIT.json`, `provenance.json`: file identities, root verification evidence, and precise result status.

A suitable repository destination is a dated research directory under `Computability/BusyBeaver/Research/ZFC/`. No changes were pushed to GitHub. See [NOTICE.md](NOTICE.md) for attribution and inherited terms.
