# A positive Airy amplitude for minimal binary automata

Research report 103, prepared for Vladimir, 2 October 2026.

## Result

For OEIS A331120, the report proves one finite positive amplitude and a genuine
Poincare expansion to every fixed algebraic order:

b_n = gamma_D n! 8^n exp(3 a n^(1/3)) n^(7/8)
      [1 + sum_(j=1)^m c_j n^(-j/3) + O(n^(-(m+1)/3))].

Here a is the largest Airy zero and b_n counts the paper's binary minimal DFAs
with n transient states and one sink. The proof begins with the exact
Proposition 5 triangle and uniformly divides by 2^m, including m=0. It proves
and controls the signed three-lag recurrence; it does not treat signed memory
as a positive contraction. Positivity of the limiting amplitude uses the
published compacted-tree lower bound, not a new compacted amplitude theorem.

The article includes four exact log/multiplicative corrections, ratio
coefficients through n^(-7/3), a convergent amplitude characterization,
all-order Lambert/Newton inverses with an explicit finite iteration count,
threshold comparison rules, and further questions. The existing published
Theta scale is fully credited. No full exponentially small transseries,
convergent infinite asymptotic series, certified amplitude digits, effective
inverse cutoff, closed-form amplitude, or worldwide priority is claimed.

## Files

- `minimal_dfa_amplitude.pdf`: the complete 23-page report
- `minimal_dfa_amplitude.tex`: standalone editable LaTeX, no external inputs
- `build.sh`: deterministic-date three-pass PDF build with layout/reference gate
- `replay.sh`: wrapper for the complete exact suite
- `checks/`: immutable exact inputs, symbolic checker, normal/optimized logs,
  deliberate-corruption regressions, and its detailed README
- `numerics/`: optional exact-integer dynamic program followed by non-certified
  floating-point diagnostics, with a separately documented recorded run
- `dependencies/`: immutable relaxed-tree PDF and source archive, both SHA-256 pinned
- `PROVENANCE.json`: primary-source and dependency record with claim boundaries
- `RELEASE_VALIDATION.json`: compilation, visual inspection, and replay record
- `SHA256SUMS`: integrity manifest for the deliverable tree, excluding itself

The enclosed relaxed report supplies the analytic Jacobi, localization, drift,
and boundary-smoothing theorem. The current article states the entire imported
input and proves the DFA-specific leading and all-orders steps. Read the
companion PDF for the full proof of the common spectral input. Its bytes have
not been edited; it is intentionally a separate dependency.

## Build and replay

From the extracted package root:

    sha256sum -c SHA256SUMS
    bash build.sh
    bash replay.sh

The PDF needs TeX Live/pdfTeX with AMS, Latin Modern, geometry, microtype,
hyperref, fancyhdr, and booktabs. The build creates its TeX format locally when
needed and does not install packages. The exact checks need Python 3.10+ and
SymPy 1.14.0; the recorded environment used Python 3.12.14. See
`checks/requirements.txt` and `checks/README.md`. No network is used by replay.

The checker uses explicit exceptions rather than Python assertions. The suite
runs normal and optimized Python, then verifies rejection of 33 deliberate
corruptions in each mode. Inputs are not regenerated during replay. Hashes are
integrity aids, not signatures or mathematical proofs. The finite exact tests
corroborate the algebra; the analytic argument establishes the asymptotic
claims.

The optional numerical producer is separate from exact replay. It recomputes
counts through n=3000 as integers, then prints floating-point asymptotic
ratios. Values near gamma_D=76.438 are observations without a proved tail
enclosure. No displayed decimal is certified as a digit of the amplitude.

## Inverse qualifications

Nearest-integer recovery is proved eventually for an exact input y=b_n. An
arbitrary threshold requires one exact or certified count comparison after
rounding. All-order inverse formulas use the mathematically defined positive
gamma_D. Substituting an uncertified decimal or using uncontrolled function
roundoff does not produce a certified numerical implementation.

## Source scope

The primary 2020 paper's Proposition 5 and actual typeset pages were checked.
Its nearby piecewise transformed-array startup differs from the uniform
normalization used here; the article supplies a precise local example and
avoids using the ambiguous startup display. This does not dispute its stated
asymptotic theorem. Original author PDFs are linked, not redistributed. No
external publication, submission, or repository change is part of this package.
