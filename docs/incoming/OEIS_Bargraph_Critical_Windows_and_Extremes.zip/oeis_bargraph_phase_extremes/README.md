# Critical Windows and Extreme Heights in Valley-Monotone Compositions

A research manuscript prepared for Vladimir Reshetnikov, October 4, 2026.

## Read first

`article.pdf` is the 24-page article. `article.tex` is its complete LaTeX source.
The article continues the valley-monotone bargraph report in ProveIt and uses
OEIS A001523 (weakly unimodal compositions) as its exact block-generating input.
A001523 is not the target bargraph sequence, and its classical asymptotics are
not presented as an open problem.

## Main results developed in the manuscript

* A lattice-Gumbel law for maximum height, with an explicit intensity and a
  uniform O(log(n)/n) error in its central height window. This addresses the
  maximum-height question explicitly left open in the preceding report.
* A weighted bottom-valley transition: a geometric count below the critical
  weight, a Gaussian count above it, and a uniform macroscopic count exactly
  at criticality. The critical weight is specified exactly through rho_2.
* A uniform 1/n critical window, its first finite-size correction, and a
  finite algorithm for all higher orders.
* A fixed-finite-level hierarchy of multicritical points with Dirichlet area
  fractions, explicit covariance, and a Dirichlet-mixture extreme-height law.
* An all-orders exponential expansion for the height-cutoff pole, its
  polynomial coefficient algorithm, and an inverse expansion. Counting
  inverses use Lambert W and explicit integer-rounding uncertainty bands.

The article contains conventional proofs, a source/claim ledger, and seven
further research topics. It is a research draft, not independently peer
reviewed or formally checked in Lean. No exhaustive priority claim is made.
The full publisher article was not accessible during the source audit;
this limitation is stated explicitly. See `SOURCE_NOTES.md`.

## Files

- `article.tex`, `article.pdf`: complete source and compiled article.
- `code/verify.py`: standard-library integer enumeration and independent checks.
- `code/symbolic_checks.py`: finite exact symbolic identities checked with SymPy.
- `code/numerics.py`: high-precision constants, coefficients, and cutoff diagnostics.
- `code/critical_extremes.py`: critical mixed extremes and a two-level critical window.
- `data/*.json`: outputs produced by these scripts.
- `requirements.txt`: the two numerical/symbolic dependencies used in this run.
- `build.sh`: two-pass PDF build.
- `SOURCE_NOTES.md`: source provenance and novelty boundary.
- `SHA256SUMS.txt`: hashes of the package files, excluding this checksum file itself.

## Reproduce the checks

Python 3.10 or newer is recommended. The exact verification requires no
third-party package. From this directory run, in order:

```sh
python code/verify.py
python code/symbolic_checks.py
python code/numerics.py
python code/critical_extremes.py
```

Install `mpmath` and `sympy` in your preferred environment before the last
three commands; the versions used are recorded in `requirements.txt`.
The scripts write their JSON outputs into `data/`. They read no remote data,
change no remote repository, and make no OEIS submission.

Observed checks in the supplied run:

- 84 independent comparisons between explicit composition enumeration and
  the marked/capped generating-function recurrence, through area 14: PASS.
- OEIS A001523 initial values through area 20: PASS.
- Exact unweighted coefficient arrays retained through area 240.
- Five groups of finite symbolic checks, including critical root/residue
  expansions and Lambert-W leading coefficients through order six: PASS.
- Numerical diagnostics completed for the critical count, scaling window,
  ordinary and critical height distributions, and two-level critical tilts.

The numeric routines evaluate finite coefficient recurrences at approximate
irrational weights. Keys such as `exact_cdf` and `exact_ratio` in their JSON
refer to that finite recurrence, not a rigorous floating-point enclosure.
The integer arrays and direct-enumeration comparisons are exact. No numerical
agreement substitutes for the article's asymptotic proofs.

## Build the PDF

A conventional TeX Live or MiKTeX installation with the packages loaded in
`article.tex` is sufficient. There is no shell-escape requirement, external
bibliography processor, image dependency, or separately supplied font.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

On a Unix-like system, `sh build.sh` performs these two passes. The PDF and
source are also usable directly without running any Python script.

## Numerical versus proved statements

All displayed decimal constants are diagnostics, not certified intervals.
Theorems define their constants analytically. The exact finite checks verify
combinatorial implementations; symbolic checks verify the specified finite
identities only. Neither the scripts nor the package assert Lean verification,
a convergent unrestricted transseries, a natural-boundary theorem, or
uniformity when the number of critical levels grows with area.
