#!/bin/sh
# Build from any current directory. A standard LaTeX installation is required.
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! command -v pdflatex >/dev/null 2>&1; then
  printf '%s\n' 'pdflatex was not found. Install TeX Live or MiKTeX first.' >&2
  exit 1
fi
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
