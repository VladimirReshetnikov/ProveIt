# The A022629 Conjecture

**All-Orders Logarithmic Asymptotics, Saddle-Point Expansions, Inverse Growth,
and the Largest Part of a Weighted Partition**

Research report prepared for Vladimir Reshetnikov, October 1, 2026.

## Start here

Read `article.pdf`; the editable, self-contained LaTeX source is `article.tex`.
The bibliography is embedded in that source, so no BibTeX file is needed.

The target is OEIS A022629, with generating function

    F(q) = product_{k>=1} (1 + k q^k).

The report supplies an elementary proof of the logarithmic conjecture attributed
to Vaclav Kotesovec in the OEIS entry, and develops substantially sharper
asymptotics. It also treats the family with k replaced by k^s, for fixed real s>0.

For x=sqrt(2n), lambda=log(x), the s=1 expansion starts with

    log a(n) = x [lambda - 1 + pi^2/(6 lambda)
                  + pi^2/(6 lambda^2)
                  + (pi^2/6 - pi^4/72)/lambda^3 + O(lambda^-4)].

## Results

- A separate elementary proof, with additive error O(sqrt(n)/log(n)).
- All orders of the dominant inverse-logarithmic block, with six coefficients
  displayed and an explicit finite differential-operator construction.
- A multiplicative all-orders expansion at the exact saddle, including the
  first two cumulant correction terms and a proof controlling noncentral arcs.
- Lambert-W inversion of the integer threshold, with six inverse coefficients.
- A Gumbel law for the largest part, a finite-dimensional logistic occupation
  profile, and the asymptotic ratio between total weight and maximum weight.
- Eight proposed further research projects and a suggested OEIS note.

## Reproduce the computations

Use Python 3.10 or newer and install the packages listed in `requirements.txt`.
From this directory run:

    python code/coefficients.py --order 6
    python code/verify.py --max-n 6400 --dps 45

The symbolic program computes and checks all six displayed forward and inverse
coefficients by exact rational-polynomial arithmetic. It supports orders 1--10;
higher orders can require substantially more symbolic computation.

The numerical program computes exact integers by descending product updates,
checks an independent logarithmic-derivative recurrence through degree 100,
checks the initial OEIS values and strict monotonicity, and evaluates the
saddle approximations at n=100,400,1600,6400. Its infinite-sum truncation is
controlled by an incomplete-gamma tail bound. Its floating-point arithmetic
is not interval-certified. The saddle helper rejects finite parameters outside
the real upper-transition coordinate used in the report.

The scripts overwrite their corresponding files in `data/`.

To rebuild the PDF, use a TeX installation with the standard packages used in
the source:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

A third pass may be needed after structural changes to settle references.
On systems with Make, `make pdf` runs three passes and `make verify` runs both
computation programs. Python can be selected with `make verify PYTHON=python3`.

## Supplied data

- `data/exact_coefficients.csv`: all 6401 exact integers for n=0,...,6400.
- `data/numerical_checks.json`: saddle coordinates, variance, cumulant correction,
  mean residual, cutoff, tail bound, and approximation errors.
- `data/formal_coefficients.json`: the six forward and inverse polynomials.
- `data/saddle_table.tex`: a small generated numerical table fragment.
- `PROVENANCE.md`: sources, repository inspection, and verification boundaries.

At n=6400, the computed relative errors (approximation/exact - 1) are about
7.8884e-4 for the Gaussian saddle and 4.7042e-7 after the first correction.
The four-term logarithmic approximation still has additive error about 3.55
there; it must not be mistaken for a good relative coefficient approximation.

## Scope and status

These are conventional mathematical proofs supported by exact and numerical
checks, not machine-verified Lean or Rocq/Coq theorems. The dominant
inverse-logarithmic block is proved to every fixed order; no convergence or
complete description of all smaller transseries blocks is asserted. The exact
saddle theorem separately provides relative coefficient asymptotics.

The inspected OEIS entry labels the leading formula a conjecture. That is not
proof that no earlier proof exists elsewhere. Worldwide priority and
"breakthrough" status are not asserted. No submission to OEIS or mutation of
the ProveIt repository was made.
