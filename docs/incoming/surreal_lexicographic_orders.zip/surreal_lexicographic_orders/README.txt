LEXICOGRAPHIC ORDERS OF SURREAL WELL-ORDERS
Further Structure from Encodings, Prefix Trees, and Support Bounds
Research manuscript prepared for Vladimir Reshetnikov
3 October 2026

CONTENTS

surreal_lexicographic_orders.pdf
    The complete 34-page article, with linked contents, theorem references,
    bibliography, and PDF bookmarks.

surreal_lexicographic_orders.tex
    A self-contained LaTeX source. The bibliography is included in this file;
    there are no external figures, source fragments, or bibliography files.

finite_checks.py
    Reproducible exhaustive finite diagnostics using the Python standard
    library. These test the finite specifications, not the class theorems.

finite_checks.json
    The recorded output of the supplied diagnostic program.

SOURCE_AUDIT.txt
    The pinned repository revision, inspected inputs, attribution boundaries,
    primary references, and limits of the audit.

ARTICLE GUIDE

Sections 1-3 distinguish the interpretations and establish the comparison
conventions, including direct comparison of arbitrary class well-orders.
Section 4 studies how relation-table scans change order topology.
Section 5 factors increasing words at their termination threshold.
Section 6 studies ordered prefix-tree automorphisms and exhaustiveness.
Section 7 proves that uniform class families miss convex copies of the raw
global enumeration-comparison order.
Section 8 gives the exact least ordinal bound on permutation support.
Section 9 reconstructs admitted model classes from a pointwise marked core.
Section 10 sets out safe foundational interpretations and their assumptions.
Section 11 identifies actual Lean declarations and proposes a development path.
Section 12 presents twelve further research questions.
Appendix A explains the finite diagnostics and the proof status.

BUILDING THE PDF

Run the following command in the extracted directory with a LaTeX distribution
containing the standard packages listed in the source preamble:

    latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_lexicographic_orders.tex

The delivered PDF was built with pdfTeX and TeX Live 2023. No shell escape,
network access, or external data download is needed to build this source.
If latexmk is unavailable, run pdflatex repeatedly until cross-reference
warnings disappear.

RUNNING THE DIAGNOSTICS

Use a recent Python 3 interpreter:

    python3 finite_checks.py --output finite_checks.json

The JSON records the enumeration counts and the outcome of each test. The
program uses explicit checks, so Python optimization does not suppress them.

Recorded results: all 48 three-label effective scans give exactly 36 labeled
orders; 720 directed-scan reductions agree; all 720 six-label well-orders
produce the six specified consecutive fibers; all 28,672 increasing-word
comparisons agree; and 15,126 distinct finite partial injections pass all
103,772 specified-support-bound checks. See the JSON for the full counts.

PROOF AND VERIFICATION STATUS

The mathematical results have conventional proofs and received an independent
review during preparation. This is not external peer review. No new Lean proof
certificate is included, and ProveIt was not rebuilt as part of this work.
The source distinguishes existing repository results from the continuations
proved here and makes no claim of historical priority.

The PDF was checked by rendering its pages, inspecting its layout and selected
formulas and tables at reading size, and checking text bounds. The final build
has no unresolved references, overfull boxes, or other LaTeX warnings.

Finite verification covers oriented pair scans, a finite six-point fiber
construction, increasing-word splitting, and finite partial-permutation
completion. It does not prove transfinite stabilization, infinite reserve
cardinalities, class recursion, Global Choice, or class-family diagonalization.

REPOSITORY BASELINE

https://github.com/VladimirReshetnikov/ProveIt
Revision: 7ff7736ecf3a0adc8536b2d083cf819e1ba39ace
Commit timestamp: 2026-10-03 21:47:46 UTC

See SOURCE_AUDIT.txt and the article bibliography for the precise inspected
paths and the distinction between the research report and formal Lean modules.
