# Report 109: Unrestricted closed lambda terms

Self-contained TeX article and reproducible checks for OEIS A135501 and A220894.
Report date: 2 October 2026.

## Results and limits

Variables have size s=0 or 1; abstraction and application have size 1. Put r=s+1. The article proves

log A_s(n) = (n/r)[log n - log log n + log 4 - 1 + (log log n)/(log n)] + O(n/log n).

It also proves a threshold inverse with error O(log y/(log log y)^3), and the full joint large-deviation principle for total abstractions and maximum unary depth. Both parameters are asymptotic to n/log n in every fixed finite L^p. A longest unary path contains all but o(n/log n) abstractions in probability; this is not a claim about a consecutive initial root chain.

The coefficient of n/log n, multiplicative amplitude, complete equivalent, all-orders transseries, and fluctuation laws remain unresolved here. The bounded literature comparison does not certify global priority. Finite checks are implementation corroboration, not asymptotic proof.

## Contents

- `report109.tex`, `report109.pdf`: complete proof article and rendered version
- `check.py`: integer/rational mathematical checker with explicit guards
- `data/`: computed counts, exact sums of abstraction counts, and deterministic finite-check results
- `validation/auditor_probes.py`: separate explicit de Bruijn term and reduced-shape enumeration checks
- `validation/`: check/audit results and reproducibility records
- `integrity.py`, `manifest.json`: strict distributable-file inventory and SHA-256 verification
- `corruption_test.py`: disposable source, fixture, and integrity mutations checked in normal and optimized Python
- `build.py`: deterministic PDF build and byte-identical clean rebuild check
- `replay.py`: safe fresh ZIP extraction, normal/optimized mathematical checks, independent probes, and PDF rebuild
- `seal.py`: deterministic local source/checks ZIP assembly

No downloaded source-paper PDFs or copied third-party code are redistributed. Primary papers are cited and linked in the article. No repository edits, uploads, or publication are involved in this package.

## Reproduce

Requires Python 3.9 or later. All mathematical checks and packaging scripts use the standard library only. From this directory:

    python3 check.py
    python3 -O check.py
    python3 validation/auditor_probes.py
    python3 -O validation/auditor_probes.py
    python3 integrity.py
    python3 -O integrity.py
    python3 corruption_test.py

The main suite performs 5,457 mathematical guard evaluations (some coefficient cases are intentionally repeated). Its 3,285 direct/radical recurrence guards cover 825 distinct triples (m,k,b). It reconstructs 201 coefficients per model, but compares only the first 16 terms per model with published OEIS prefixes. The complete remote OEIS b-files were not retrieved. The tables beyond those prefixes are internally computed values, not a claimed full external-data comparison.

`python3 check.py --fixtures-only` is only a fast prefix sanity check through n=20; it does not validate the data tail, moments, summary, inventory, or complete mathematical suite. `python3 check.py --generate` explicitly regenerates the five data snapshots. Never use regeneration to disguise a failed validation.

To build the PDF:

    python3 build.py

The build needs `pdftex`, `pdflatex`, the LaTeX base classes, and `fontenc`, `lmodern`, `geometry`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `booktabs`, `array`, `microtype`, `xcolor`, `hyperref`, and `enumitem`. It creates a writable local TeX format for environments without a prebuilt format, makes three passes, rejects overfull boxes or unresolved citations/references, and compares a second clean build byte for byte. It writes only generated build products and `report109.pdf`. The original PDF was built with pdfTeX 1.40.26 and TeX Live 2025/dev/Debian; other TeX/font versions may produce different bytes despite matching content.

To inspect the rendered PDF, `pdfinfo`, `pdftotext`, and `pdftoppm` from Poppler are useful optional tools. All final pages were rendered and visually reviewed before delivery.

To replay the supplied ZIP into a fresh, nonexisting destination:

    python3 replay.py --archive report109_source_checks.zip --out /tmp/report109-fresh-replay

The extraction rejects duplicate, unsafe, symlink, or unmanifested archive members. It verifies inventory, runs mathematical checks both normally and with `-O`, runs independent probes both ways, rebuilds the PDF, and requires it to match the packaged bytes. Replay logs are stored outside the extracted package.

## Integrity scope

`manifest.json` hashes all distributable files except itself. Generated `build/`, visual-QA `qa/`, Python `__pycache__/`, the ZIP itself, and `FINAL_SHA256.txt` are excluded from that inventory. The ZIP contains exactly the manifested files plus the manifest, under one `report109/` directory. Hashes detect accidental changes relative to the manifest; they are not a cryptographic signature or a substitute for mathematical review.

The corruption campaign bypasses hash validation for mathematical mutants to ensure that mathematical guards, rather than hashes alone, reject them. Each mutant runs in a disposable copy, normally and with `-O`, and must fail. Missing fixtures may fail with a file-open error; other mutations must reach an explicit RuntimeError guard. The originals are not modified.

After authorized source changes, rerun checks and visual QA, then rebuild and reseal:

    python3 build.py
    python3 integrity.py --generate
    python3 corruption_test.py
    python3 seal.py

The included validation records describe the delivered snapshot. Changes require fresh validation; do not assume that its recorded audit applies to later edits.
