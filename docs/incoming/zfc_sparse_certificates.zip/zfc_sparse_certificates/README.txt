SPARSE AND GROUND-TERM C254 CERTIFICATES
=====================================

This archive accompanies report.tex and report.pdf. Its new Python programs are
reference implementations and finite reproducibility controls for the exact
twelve-rule C254 calculus at ProveIt commit
fab89c5d26b81cd2ccab2ee5d213ff23725c7726.

Scope of the result
-------------------
The certificate front ends replace large arithmetic formula values with shared
constructor terms. They preserve the existing fixed logical and set-theoretic
templates, including both bundle inequality gates. The report gives the ordinary
mathematical arguments and distinguishes them from the repository's existing
formal endpoints.

These additions supply NO new kernel-checked Lean theorem, NO completed PA
internalization, NO compiled binary Turing machine, and NO new physical state
bound. In particular, a Python operation count, arena-node count, memory-bit
bound or register count is not a Turing-machine state count. Ground-term search
still needs an explicit binary certificate codec, enumerator, compiler and
formal correctness bridge. No consistency assertion follows from the tests.

Running the controls
--------------------
Run from the archive root with Python 3.10 or later (tested with Python 3.12).
Only Python's standard library is used. No pip installation or network access
is required for the following commands. Do not use Python -O: the controls use
assertions. The -B option avoids generating bytecode cache files.

The single-command isolated replay is:

  python3 -B code/replay_all.py --output /tmp/c254-package-replay.json

Equivalently, run make verify. This copies the required inputs into a temporary
directory, runs the substantive finite checks, compares deterministic outputs,
replays both compressed search partitions and the literal continuation record,
and checks all 8,391 baseline cases plus the exact 82,552-step blank bootstrap.
It preserves the supplied records and does not repeat either long state search.
The component commands below write their named outputs in the package itself.

  python -B code/reproduce.py --output data
  python -B code/audit_canonical.py
  python -B code/check_proof_code_size.py > data/proof_code_size_results.json
  python -B code/schema_metrics.py --check
  python -B code/check_term254.py

The first command replays sparse/lazy/canonical comparisons, small numerical
axioms, positive GEN and MP controls, bundle gates, and corrupted certificates.
Its elapsed-seconds field varies between runs. The other seeded or exhaustive
results are deterministic for these source files and default parameters.

audit_canonical.py writes data/canonical_audit_results.json. It checks quoted
and unquoted certificates separately, rejects corrupt fields and quotation
labels, and verifies early rejection of an unused depth-1000 GEN chain with
false tiny quotes. Quoted verification uses LOCAL FORWARD pairing equations;
unquoted verification uses no pairing. Both avoid inverse pairing, parsing and
the proof producer. These are executable controls, not a formal verification.

check_proof_code_size.py defaults to codes 0 <= c < 200000, 10000 random raw
trees and seed 20261017. It checks quotation, parser fuel and size inequalities;
it does not establish logical proof validity. Flags --limit, --samples and
--seed select different finite controls.

schema_metrics.py expands the pinned generic axiom templates. Parameters and F
are leaves; occurrence counts retain repeated subterms and distinct counts
share them. These counts exclude numeric literal decoding and normalization.
The --check mode compares against data/schema_metrics.json without rewriting.
Without --check it regenerates that JSON, first requiring agreement with an
existing file. Use --output NEW_FILE to examine a changed specification.

check_term254.py writes data/term_certificate_results.json and a bundle control
example. It covers all twelve rule tags and both bundle gates, conversions from
canonical certificates, malformed inputs and a depth-1000 GEN chain. Its
verifier controls disable numeric decoding, materialization, pairing, inverse
pairing, parsing, quotation and both other certificate checkers.

Ground-term API and the fixed target
-----------------------------------
term254.verify_certificate(cert) always asks for the fixed falsity term
B_1(Z,Z). A certificate cannot choose this default target. An explicit caller
argument goal=ID is available for positive controls of other conclusions; using
goal=0 asks for truth0 and must not be used in a consistency search.

term254.from_canonical(source) returns (certificate, goal_ID). It is an adapter
and may call canonical verification. It removes all numeric literals and proof
quotes from the returned ground-term certificate. To replay a non-falsity
control, call verify_certificate(certificate, goal=goal_ID). The saved bundle
example is such a positive control; it is not a contradiction certificate.
TERM254.txt states the ground-term specification and ordinary correctness
argument, together with the remaining implementation obligations.

Archive layout and provenance
-----------------------------
  report.tex, report.pdf     Main research report.
  code/                     New reference checkers and reproduction scripts.
  data/                     Pinned term ASTs, finite results and examples.
  TERM254.txt               Ground-term specification and proof sketch.
  machine_experiments/      Separate transition-table experiments and results.
  reference/proveit/        Selected ProveIt sources at the pinned commit,
                            retaining their repository-relative paths.

reference/proveit/ is a source snapshot for inspection, not necessarily a full
Lean checkout with build dependencies. machine_experiments/ contains separate
work; its status and limitations are stated by the report and its own results.

data/spec254.json records the source commit and SHA-256 of Code254.lean. To
regenerate the extracted AST from the bundled pinned source, run:

  python -B code/extract_specs.py reference/proveit/Computability/BusyBeaver/Lean/BusyBeaver/ZFC/Code254.lean data/spec254.json
  python -B code/schema_metrics.py --check

The extractor is intentionally a narrow reader for the eleven fixed source
definitions; it is not a Lean interpreter. The audit JSON files record hashes
of the implementation sources actually checked. Existing formal source and
external machine provenance should be assessed at their recorded commit pins.

Building the report
-------------------
Run make pdf (requires latexmk and a standard LaTeX installation). It writes
output/pdf/report.pdf. A shipped report.pdf is also provided at package root.
report.tex includes machine_experiments/research_notes.tex; keep that relative
path when compiling the modular source. A self-contained flattened source is
also supplied as zfc_sparse_certificates.tex.

Machine experiment commands, run from this package root:

  python3 -B machine_experiments/replay_entry_partition.py \
    --result machine_experiments/entry_degree1.json \
    --table reference/proveit/Computability/BusyBeaver/Research/ZFC/candidate-permutation252/zfc_permutation252_old.tm \
    --output /tmp/entry-degree1-partition-audit.json

Replace degree1 with degree2 for the larger saved partition. To reproduce the
literal continuation record:

  python3 -B machine_experiments/continuation_obstruction.py \
    --repo reference/proveit --output /tmp/continuation-obstruction.json

The more detailed machine_experiments/README.txt lists optional fresh searches
and precisely distinguishes diagnostic rejections from semantic exclusions.
