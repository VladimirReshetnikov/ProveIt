# Tropical Mixed Volumes of Surreal Polytopes

**Parallelotope compression, Grassmannian realization, and full-support matroid obstructions**  
Research manuscript prepared for the ProveIt research program, 30 September 2026.

## Read first

`article.pdf` is the 25-page article. `article.tex` is its standalone LaTeX source, with an internal bibliography. The scalar hypotheses are a set-sized real closed ordered field containing the real numbers, equipped with its natural valuation. Finite surreal configurations are handled by localization to such fields.

The manuscript proves simultaneous parallelotope compression, an exact canonical-polarization determinant criterion, preservation of volume polynomials under normalized standard-part degeneration, and a full-support profile test for real matroid representability. An explicit Fano cubic is strictly Lorentzian but has an unrealizable mixed-volume valuation profile. A finite rank-two construction establishes planar sufficiency for full-support M-convex profiles. A four-variable quadratic separately shows that realizability of a profile does not imply realizability of prescribed leading coefficients.

These are conventional mathematical proofs in an unrefereed manuscript. Priority for the exact structural formulations has not been established. The classical Fano/support obstruction, Lorentzian background, and rank-two tropical Grassmannian facts are credited in the article. No new Lean formalization or Lean build is claimed.

## Package contents

- `article.pdf` — typeset article, proofs, ten further research questions, bibliography, and audit.
- `article.tex` — complete source; no external graphics or bibliography database required.
- `verify.py` — exact symbolic and combinatorial checks, without network access or randomness.
- `requirements.txt` — the SymPy version used for the recorded run.
- `verification.json` — machine-readable results of the executed checks.
- `verification.txt` — saved console output of that run.
- `fano_coefficients.csv` — all 84 coefficients, their monomial types, and their orders in t.
- `rank_two_example.txt` — an explicit 2-by-8 realizing matrix and the scope of its check.
- `source_audit.md` — pinned repository files, proof dependencies, and verification scope.
- `build.sh` — compile the article and rerun the exact checks.

## Reproduce

A standard TeX Live installation with `latexmk`, `newtx`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `booktabs`, `longtable`, `enumitem`, `needspace`, `fancyhdr`, and `hyperref` can compile the source. The source also loads standard color/TikZ packages. Run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

For the verification script, use Python 3.10 or newer. The recorded run used SymPy 1.14.0:

```sh
python -m pip install -r requirements.txt
python verify.py
```

Run Python normally, **not with `-O`**, because assertions perform the checks. The script rewrites its JSON report, CSV coefficient table, and rank-two matrix beside itself. It uses no floating-point eigenvalue tests. The general field-independent theorems are proved in the article, not established by finite testing.

The recorded run passed 84 coefficient identities, 12,047 M-convex exchange obligations, 147 tropical Alexandrov–Fenchel comparisons, 101,745 short tropical Plücker relations, seven symbolic Hessian identities, and all 28 determinant-order checks for the rank-two constructor. It also verified the characteristic polynomial and the final Fano contradiction determinant of -2.

## Repository scope

The scalar source audit is pinned to ProveIt commit `6996fee43cc97b6c16351def7507d59a95bf62f0`. Two relevant foundation files were read directly through the GitHub connector. The later observed head was its child `b2b626d8537f7dea8f20393ee4714c7201a7001e`, which adds incoming archives. This was a targeted source review, not a repository-wide correctness assessment.
