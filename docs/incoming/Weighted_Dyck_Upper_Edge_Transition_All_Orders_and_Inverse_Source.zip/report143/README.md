# Report 143: Quantified upper edge transition

The article proves a simultaneous nonlinear coefficient comparison for the
weighted-Dyck Newton triangle A258220, exact finite-index bounds, and a
connected-ratio profile for every growing deficit q = o(sqrt(N)). It also
proves all fixed orders of the one-variable profile, exact monotonicity,
and an inverse bracket whose error remains inside integer ceilings.

The archive contains the complete LaTeX source and PDF. Unchanged source/PDF
pairs of Reports 141 and 142 supply the path interpretation and the explicitly
scoped compact-interior comparison. Their computational packages are not
needed here. The proofs in Report143 stand on its defining recurrence.

## Quick start

Requirements: Python 3.11 or later, using only its standard library. The
release was tested with Python 3.12.14. PDF rebuilding additionally needs
pdfTeX/pdflatex, the packages named in Report143.tex, Latin Modern, and TeX
font maps. The tested engine is pdfTeX 1.40.26 (TeX Live 2025/dev/Debian).
Dependencies must already be installed. No command installs software or
uses the network.

All executable entrypoints require isolated Python (-I) before importing
anything except built-in sys. Use -B to make the no-bytecode policy explicit.
Replace /home/alice/report143 below with the absolute extracted directory.
For output commands, /home/alice/results must already exist and each named
target must be absent, including as a symlink. Outputs must be outside the
bundle. No command overwrites an existing output or repairs a fixture.

    python -I -B /home/alice/report143/bundle.py check
    python -I -B /home/alice/report143/code/check.py replay
    python -I -B -O /home/alice/report143/code/check.py replay
    python -I -B /home/alice/report143/code/check.py selftest
    python -I -B /home/alice/report143/bundle.py replay --output /home/alice/results/replay143
    python -I -B /home/alice/report143/bundle.py selftest --output /home/alice/results/selftest143
    python -I -B /home/alice/report143/bundle.py build --output /home/alice/results/build143
    python -I -B /home/alice/report143/bundle.py pack --output /home/alice/results/Report143.zip
    python -I -B /home/alice/report143/bundle.py reproduce --output /home/alice/results/reproduce143

bundle.py check validates the closed inventory, all payload hashes, included
report pins, and the typed exact fixtures. code/check.py check and replay
regenerate the exact calculations and compare every fixture value. check
prints a concise JSON summary; replay prints the complete checked fixture.
The bundle replay command stores that result at an absent external path.
The code/check.py commands accept no output or alternate fixture paths.

selftest uses disposable copies for deliberate structural and mathematical
mutations, including optimized Python. The bundle selftest also checks
normal/-O replay agreement, all entrypoint isolation guards, output path
containment and preservation, deterministic ZIP bytes, and extraction/repack.
The original payload remains unchanged.

build creates an external, clean TeX environment, rebuilds its format,
compiles twice with shell escape disabled, and rejects listed overfull,
missing-character, reference and citation warnings. It reports whether the
PDF equals the frozen PDF bytes. reproduce runs the self-tests and two clean
PDF builds, requires equality with each other and the frozen PDF, and tests
fresh ZIP extraction/repacking. PDF byte reproducibility is scoped to the
tested TeX toolchain; another engine or font/package version can differ.

pack writes sorted, stored (uncompressed) entries with fixed timestamps
and permissions beneath the single top-level report143/ directory. It
includes no logs, caches, temporary output, or review material.

## Exact arithmetic and checked ranges

code/edge.py regenerates the ordinary polynomials from the defining
recurrence through N=60, and generates the odd-weight auxiliary separately.
An independent scalar recurrence, forward differences, and signed/second-kind
Stirling transforms cross-check the Newton normalization.

- 4,941 top-coefficient checks cover every 0 <= N <= 60 and 0 <= a <= 80,
  including a>N and N=0
- 961 pairs (N,q), including q=0 and N=2q, test each P/Q sandwich
- 961 checks each test the Stirling and elementary-symmetric sandwiches
- 1,890 coefficient first differences and 4,880 telescoping identities
  check the all-index recurrence conventions
- 3,721 scalar evaluations, 1,891 forward-difference Newton checks, and
  1,891 signed-Stirling inversions use independent finite representations
- 80 exact hypergeometric convolution identities and 81 binomial-smoothing
  identities check the connected normalizations
- 80 strict h increments and 80 profile increments check monotonicity
- Fixed-a polynomial interpolation through a=7 is checked at all N<=60
  (488 values); the leading coefficients equal the independent L recurrence

The frozen fixture also retains eight full ordinary/Newton/auxiliary rows,
initial rational L and K values, and initial integer V values. Auxiliary
Newton rows represent Q/gamma_N, rather than Q itself; all scalings are exact.

code/profile.py computes the formal coefficients at any prescribed positive
fixed order using rational finite-series arithmetic. The frozen order is 8:
f_0 through f_8 and xi_0 through xi_7, together with their intermediate
normalizations. It compares two distinct routes to the h coefficients:
the split hypergeometric convolution and the symmetric endpoints of the V
recurrence. Binomial central moments from factorial moments are checked
against the cumulant recurrence through degree 16. Formal inverse composition
is checked through every retained coefficient.

    python -I -B /home/alice/report143/code/profile.py --order 8

This arbitrary-fixed-order computation is not a claim that the asymptotic
series converges, that its order may grow with q, or that finite computations
prove a remainder theorem. The all-index integral comparison and the
controlled convolution and binomial tails in the article provide those
mathematical bounds. No floating-point fit or external sequence dataset is
used in these new exact fixtures.

## Fixture representation and integrity

checks/fixtures.json is closed, typed, and exact. Polynomial lists use
ascending powers; rational strings are canonical fractions. Counts and
indices are JSON integers, never booleans or floats. Unknown/missing nested
fields, incorrect array shapes, duplicate keys, malformed/noncanonical
rationals, floating-point tokens, and nonfinite tokens are rejected.
A structurally valid false fixture must also fail exact regeneration.
Every effective mathematical check uses an explicit exception, not assert,
and therefore remains active under python -O.

manifest.json covers every other payload file. Its inventory is hard-coded;
unknown files or directories, symlinks, nonregular files, and digest/size
mismatches are rejected. The four included Report141/142 source/PDF digests
are pinned independently. Output commands preflight their target before
computing or creating output, rejecting bundle-contained paths, parent
traversal, ancestor symlinks, double-leading-slash aliases, and existing
outputs. Outputs are created exclusively.

This is an integrity and reproducibility mechanism, not an authenticated
signature or a sandbox for hostile code. A person who edits both the verifier
and matching hashes can create a different bundle. It assumes a trusted local
workspace and does not promise adversarial filesystem-race isolation.

For maintainers, seal validates the payload and writes a proposed manifest
to an absent external path. It does not install it or change the bundle.
Review and install an authorized proposed manifest manually, then rerun
check, replay, selftest and reproduce.

    python -I -B /home/alice/report143/bundle.py seal --output /home/alice/results/proposed-manifest143.json

Public provenance and the precise scope of the contribution are in SOURCES.md.
