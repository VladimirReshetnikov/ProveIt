# Sharp Leading Constant for Constrained Crossover Rank

Research note prepared with OpenAI for Vladimir Reshetnikov, 1 October 2026.

## Main results

For a q-letter alphabet, q >= 2, put C_q = max(8, 2q-4). Every s-state epsilon-free NFA with arbitrary initial and final sets and finite maximal aligned-fragment rank satisfies

    R(L) <= s^2 + C_q s.

For every s >= 4 there is an s-state example with exact rank (s-3)^2, using every alphabet symbol. Therefore

    (s-3)^2 <= F_q(s) <= s^2 + max(8, 2q-4)s,
    F_q(s)/s^2 -> 1 for each fixed q >= 2.

The ratio also tends to one when q = q(s) = o(s). In particular, the explicit upper bound is s^2+8s for alphabets of size two through six. No alphabet-size-independent additive term or leading-one conclusion for unrestricted alphabet growth is claimed.

The exact binary small-state extrema are

    F_2(1) = 1, F_2(2) = 2, F_2(3) = 5, F_2(4) = 7.

The subscript means alphabet size; the argument means state count. The upper bounds for two and three states use complete, independently checked enumerations. Four states use a proved transient pruning rule and a complete independently reproduced 45,695,722-case retained search. The article does not claim an exact value of F_2(s) for s >= 5.

A uniform binary s-state shortest-gate family, for every s >= 3, has exponent e=s-1 and

    R(L) = 2s-1 = 2e+1,
    M_L(N) = min(N, 2s-1) for every N >= 1.

Its empty word is not accepted. The article also proves an exact weighted-parser algorithm for arbitrary finite alphabets and the complete finite witness cutoff H=max(1, 2t+p(2^s-1)-1), for any common eventual transient t and period p of the exact forward/backward layers.

For primitive factor-universal binary graphs, the retained restricted results are R <= n^2+n+1 for Hamiltonian graphs and R <= n^2+3n for circumference at least n-1. A near-Wielandt family has quadratic exponent, no nonempty forward-total or backward-total state subset, and rank at most 6n+3 for all nonempty endpoint sets.

## Article and evidence

The 31-page article is self-contained apart from precisely cited classical primitive-digraph exponent results. All-size ordinary proofs, computer-assisted upper extrema, and finite consistency checks are distinguished explicitly. Full-seed length and alignment are enforced throughout. The robust primitive theorem licenses singleton witnesses from the whole language while every other fragment has an internal fixed-endpoint witness of exactly the required length.

The article keeps R(empty language)=1. Census programs use raw value 0 for an empty hull, and the tables label those cases "empty" separately. Their epsilon-only languages have rank one. This convention difference does not affect any extremal value.

This is an unrefereed research note with ordinary and computer-assisted mathematical proofs, not a proof-assistant certificate. Separate independent mathematical reviews cover the general finite-alphabet proof and the exact algorithm/census integration. No literature-wide priority claim is made.

## Files

- `hamiltonian-rank.pdf`: final article, preserving the existing filename
- `hamiltonian-rank.tex`: editable, self-contained LaTeX source
- `build.sh`: standard two-pass pdfLaTeX build in a temporary directory
- `verify.sh`: quick reproducible consistency checks; does not modify the package
- `check_general.py`, `check_lower.py`, `check.py`, `check_templates.py`: retained proof-consistency checks
- `general-verification.json`, `lower-verification.json`, `verification.json`: their deterministic receipts
- `alphabet/`: finite common-anchor, multicolor charge, transfer, and lower-family checks, with compact receipts
- `exact/producer/`: cutoff/slice and weighted-graph exact-rank implementations
- `exact/audit_census.cpp`: independent direct labeled enumeration with boundary/core SCC optimization
- `exact/compare_pointwise.cpp`: pointwise comparison of three independent exact implementations
- `exact/audit_literal.py`: accepted-seed and interval-partition oracle
- `exact/*.json`: compact exhaustive census and independent comparison receipts
- `exact/four_state/`: producer and independent pruned censuses, candidate generator, independent family and literal checks, and compact receipts
- `exact/reproduce.sh`, `exact/four_state/reproduce.sh`: full exhaustive reproduction commands
- `source-pins.json`: classical sources, prior companion versions, and computational source provenance
- `review-receipt.json` and the two integration-review receipts: scope of independent mathematical review, reproduction, and all-page visual checks
- `SHA256SUMS`: checksums of the delivered files

The previous versions are preserved separately and are not mixed into the new ZIP. No compiled executables, generated TeX auxiliaries, page images, raw million-row listings, or speculative search outputs are included. Four-state candidate lists are regenerated from source; their expected digest is in the compact audit receipt.

## Quick verification

Python 3.10 or newer and its standard library suffice for the consistency checks:

    sh verify.sh

With g++ and C++17, add an independent complete two-state census, the three-way pointwise comparison for all 2,304 two-state presentations, and regeneration/hash checking of all 23,228 four-state candidates:

    sh verify.sh --compile

These commands work in a temporary copy and leave delivered receipts unchanged. Alphabet-check receipts include elapsed seconds, so byte-for-byte comparison of those regenerated JSON files is not intended. Their test counts and assertions are deterministic. Verify file integrity before running optional rebuilding commands:

    sha256sum -c SHA256SUMS

## Complete exhaustive reproduction

Run the following in an expendable copy of the package. The scripts generate local executables and replace result receipts. They need a C++17 compiler, Python 3, and the standard libraries only; no external libraries or downloads are used.

    sh exact/reproduce.sh
    sh exact/four_state/reproduce.sh

The first recomputes the two-/three-state independent distributions, pointwise agreement of three exact implementations, both producer three-state distributions, and literal-seed cross-checks. The second independently regenerates the four-state candidate list, performs the full 45,695,722-case retained scan, checks the candidate digest, and reruns the family and literal four-state checks. To rerun the complete producer four-state enumeration as well:

    sh exact/four_state/reproduce.sh --both

Full runs can take minutes or longer depending on hardware. The supplied receipts already record completed producer and independent runs. Fast validation alone checks their internal consistency; it is not a replacement for those exhaustive reruns.

## Build the PDF

With TeX Live or compatible pdfLaTeX including AMS mathematics, Latin Modern, geometry, microtype, and hyperref:

    sh build.sh

The delivered PDF was built with pdfTeX 1.40.26 and rendered with Poppler. Every page was visually inspected. A rebuilt PDF may differ in timestamps or engine metadata and hence checksum. Environment-specific TeX search paths were required in the preparation container; a normally configured TeX distribution uses `build.sh` directly.

## Exact coverage

The complete two-/three-state distributions cover 2,304 and 12,845,056 labeled presentations respectively, with pointwise agreement of three algorithms on all 12,847,360 combined inputs. The independent literal oracle covers 208,712 two-state hull targets and 147,264 targets from every one of the 72 three-state rank-five maximizers. The finite witness cutoff never exceeds 6 for finite two-state cases or 20 for finite three-state cases.

For four states, the ordinary proof discards all inputs whose unlabeled forward/backward pair transient is at most 3, since finite rank then implies R<=7. The retained 411 graph representatives and 23,228 endpoint triples give 45,695,722 letter-exchange representatives. All were evaluated by producer and independent runs, which agree at every histogram count; the retained finite maximum is 6. The explicit shortest-gate family supplies rank 7 among the discarded transient-3 cases. These are pruned representative counts, not a full four-state labeled rank distribution.

Independent non-greedy interval checks verify 95 linear-family instances through s=50. A completely literal four-state oracle checks 509 hull targets through length eight, giving slice maxima 1,2,3,4,5,6,7,7. The structural and parameter-check coverage is recorded in the alphabet and retained JSON receipts. None of these bounded tests substitutes for an all-size proof.
