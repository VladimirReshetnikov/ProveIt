# Surreal Cuts, Replacement, and Atom-Support Spectra

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT,
3 October 2026. The PDF contains 23 pages, including its cover and contents.

## Contents

- `article.pdf`: compiled article with complete mathematical arguments.
- `article.tex`: standalone LaTeX source, including the bibliography.
- `code/verify_finite.py`: Python standard-library finite regression tests.
- `data/finite_checks.json`: output of the executed verification run.
- `data/build_validation.json`: PDF/build validation record.
- `PROOF_STATUS.md`: mathematical, novelty, and verification boundaries.
- `build.sh`: commands to rerun the tests and rebuild the PDF.
- `SHA256SUMS`: checksums of the distributed files.

## Main results

The article characterizes definable surreal-family interpolation by ordinal
bounding over Zermelo set theory with Foundation. With an explicitly separate
cumulative-hierarchy axiom, this is equivalent to full Replacement and
Collection. Actual set cuts need no Replacement. A fixed negative interval
already detects the stronger scheme.

It also analyzes cardinal-support urelement models. It determines the exact
least domain size for Collection failure, and shows how naming an external
atom enumeration changes the Replacement spectrum while leaving every
pure-valued Collection instance valid. The same pure surreal structure can
therefore accompany different ambient foundational principles.

Ten further research questions and a ProveIt formalization plan are included.

## Build

Run `bash build.sh` from a system with Python 3.10+ and a TeX distribution
containing pdfLaTeX and the standard packages used in `article.tex`
(including newpx, microtype, tcolorbox, cleveref, and xurl).

The source needs no external figures, bibliography processor, or font files.
The newpx fonts are supplied by the user's TeX distribution; no font files
are included in this package.

The tests can be run alone from any directory:

    python3 code/verify_finite.py --output data/finite_checks.json

## Status

This is an unrefereed research manuscript. Mathematical proofs are supplied,
but historical priority and independent correctness certification have not
been established. Classical simplicity and small-kernel arguments are
explicitly credited. No Lean/Rocq verification of this article is claimed.
The Python tests concern finite instances only and do not prove the
transfinite theorems or axiom-scheme equivalences.
