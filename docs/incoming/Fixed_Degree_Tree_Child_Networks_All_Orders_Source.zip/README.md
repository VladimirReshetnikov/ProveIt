# Report 104 — Fixed degree tree-child network amplitudes

The standalone article is `general_tree_child_amplitudes.pdf`; the editable source is `general_tree_child_amplitudes.tex`.

## Result and scope

For every fixed integer d >= 2, the article proves a strictly positive canonical amplitude and a full Poincare expansion for the constrained-word counts underlying maximally reticulated d-combining tree-child networks. The exact identity M_d(n) = n! c_d(n-1) gives the full maximal-network expansion. Published total/maximal ratio results give leading equivalents for total networks. At d = 3, a quantitative consequence of the published proof transfers the first correction with relative error O(n^(-1/2)).

The article gives the exact gamma-product normalization, a self-contained positive Jacobi-product proof, an arbitrary-depth coefficient algorithm, two universal coefficients, a further ternary coefficient, Lambert–Newton inverse formulas, and exact threshold rules. The d = 2 word family is A213863. No OEIS identifier is assigned to the d = 3 or d = 4 families.

No certified decimal amplitude, uniformity as d tends to infinity, convergent infinite correction series, exponentially small sector, or all-order total-network expansion is claimed. The literature check is focused, not an exhaustive priority certificate.

## Verify and rebuild

1. Before editing or replaying anything, run `python3 verify_release.py`. This verifies the archived file inventory, PDF header, final check status, ordinary and optimized baselines, and all 50 intended corruption rejections. The manifest is an integrity inventory, not a cryptographic signature.
2. Run `bash build.sh`. It compiles the standalone TeX three times and rejects overfull boxes or unresolved references/citations. It uses no network, bibliography database, external figure, or companion proof.
3. Run `python3 checks/run_checks.py`. This runs all exact checks normally and under `python -O`, followed by 25 deliberate corruptions in each mode. See `checks/README.md` and `checks/RESULTS.md` for coverage and interpretation.

The exact suite needs Python 3.10+ and SymPy 1.14.0; its requirements file is `checks/requirements.txt`. The PDF build needs a standard TeX Live/pdfTeX installation with Latin Modern, AMS packages, mathtools, microtype, geometry, fancyhdr, booktabs, longtable, array, enumitem, xcolor and hyperref. A writable `build/` directory is created for TeX runtime files. Poppler is useful for optional render review but is not needed for compilation.

The archived integrity inventory describes the shipped bytes. A replay creates or changes build products and check logs; extract a separate fresh copy when comparing against the original manifest. The PDF build uses a fixed source-date epoch for reproducibility.

## Package contents

- The 22-page PDF and standalone TeX source
- `build.sh` and `verify_release.py`
- `checks/`: exact certificates, strict input parser, normal/-O runner, deliberate-corruption tests, requirements and recorded results
- `SOURCES.md` and `provenance/sources.json`: primary sources, claim locations, version information and snapshot hashes where available
- `qa/REVIEW.md` and `qa/release_replay.json`: concise final rendering and clean-extraction replay records
- `MANIFEST.json`: exact SHA-256 inventory of every shipped file other than itself

Third-party papers, page-render images, development notes, caches and exploratory scripts are not redistributed. The finite exact checks certify algebraic inputs and regression cases; the article supplies the analytic proof.
