#!/usr/bin/env python3
"""Verify the shipped report104 inventory before rebuilding or replaying."""
import ast
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read_json(path):
    def reject_constant(value):
        raise ValueError('Nonfinite JSON constant: ' + value)
    return json.loads(path.read_text(encoding='utf-8'),
                      object_pairs_hook=strict_object, parse_constant=reject_constant)


def main():
    manifest = read_json(ROOT / 'MANIFEST.json')
    require(type(manifest) is dict and set(manifest) == {'schema', 'report', 'files'},
            'Unexpected manifest schema')
    require(type(manifest['schema']) is int and manifest['schema'] == 1,
            'Unsupported schema version')
    require(type(manifest['report']) is int and manifest['report'] == 104,
            'Wrong report number')
    files = manifest['files']
    require(type(files) is dict and len(files) >= 24, 'Incomplete file inventory')
    required = {'general_tree_child_amplitudes.pdf', 'general_tree_child_amplitudes.tex',
                'README.md', 'SOURCES.md', 'build.sh', 'verify_release.py',
                'provenance/sources.json', 'qa/REVIEW.md',
                'checks/README.md', 'checks/RESULTS.md', 'checks/requirements.txt',
                'checks/verify_exact.py', 'checks/run_checks.py',
                'checks/input_manifest.json', 'checks/provenance.json',
                'checks/inputs/formal_coefficients.json',
                'checks/inputs/ternary_degree6.json',
                'checks/inputs/reference_sequences.json',
                'checks/results/normal.json', 'checks/results/optimized.json',
                'checks/results/suite.json'}
    require(required <= set(files), 'Missing mandatory entries')
    for name, record in files.items():
        require(type(name) is str and name, 'Invalid inventory path')
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and
                name != 'MANIFEST.json' and str(p) == name,
                'Unsafe inventory path')
        require(type(record) is dict and set(record) == {'bytes', 'sha256'},
                'Unexpected file record: ' + name)
        require(type(record['bytes']) is int and record['bytes'] >= 0 and
                type(record['sha256']) is str and
                re.fullmatch('[0-9a-f]{64}', record['sha256']) is not None,
                'Invalid size or digest: ' + name)
        target = ROOT / p
        require(target.is_file() and not target.is_symlink(), 'Missing or linked file: ' + name)
        raw = target.read_bytes()
        require(len(raw) == record['bytes'], 'Release size mismatch: ' + name)
        require(hashlib.sha256(raw).hexdigest() == record['sha256'],
                'Release SHA-256 mismatch: ' + name)
    require((ROOT / 'general_tree_child_amplitudes.pdf').read_bytes().startswith(b'%PDF-'),
            'Invalid PDF header')
    tex = (ROOT / 'general_tree_child_amplitudes.tex').read_text()
    require('\\end{document}' in tex and 'Report 104' in tex, 'Incomplete or wrong TeX')
    require('n^{p/3}quad' not in tex, 'Unescaped spacing token')
    require('n^\\delta}\\cdot' in tex, 'Missing gamma-normalizer multiplication')
    suite = read_json(ROOT / 'checks/results/suite.json')
    require(suite.get('status') == 'PASS', 'Exact suite did not pass')
    baseline = suite.get('baseline')
    require(type(baseline) is list and len(baseline) == 2, 'Wrong baseline coverage')
    require({x.get('mode') for x in baseline} == {'normal', 'optimized'},
            'Missing ordinary or optimized baseline')
    require(all(x.get('status') == 'PASS' and x.get('gates') == 5655 for x in baseline),
            'Baseline failed or exact coverage changed')
    mutations = suite.get('corruption_tests')
    require(type(mutations) is list and len(mutations) == 50, 'Wrong corruption coverage')
    require(all(x.get('status') == 'REJECTED' for x in mutations), 'Accepted corrupt input')
    require(len({(x.get('name'), x.get('mode')) for x in mutations}) == 50,
            'Duplicate corruption coverage')
    require({x.get('mode') for x in mutations} == {'normal', 'optimized'},
            'Corruption modes incomplete')
    for filename in ['verify_release.py', 'checks/verify_exact.py', 'checks/run_checks.py']:
        tree = ast.parse((ROOT / filename).read_text())
        require(not any(isinstance(node, ast.Assert) for node in ast.walk(tree)),
                'A correctness gate disappears under -O: ' + filename)
    print('PASS: %d inventoried files; both 5,655-gate baselines and all 50 corruption rejections' % len(files))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print('FAIL: %s: %s' % (type(error).__name__, error), file=sys.stderr)
        sys.exit(1)
