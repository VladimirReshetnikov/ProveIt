SHARPER LOCAL STABILITY AND UNIFORMITY BOUNDS
IN GOWERS'S SZEMEREDI ARGUMENT

Prepared with ChatGPT for Vladimir Reshetnikov
7 October 2026

This package contains a complete research article, its LaTeX source, and
reproducible exact verification material for integration into ProveIt.

MAIN RESULTS

1. Affine stability over odd-order targets.
   For any specified affine reference, disagreement t and four-point
   rejection epsilon satisfy epsilon >= 4t - 10t^2 + 6t^3 throughout the
   full positive range 0 <= t <= 2/3. The article proves a stronger
   structural remainder and classifies equality for 0 < t < 2/3.
   It also treats the endpoint, quantitative near equality, and
   independent weighted labels. The endpoint analysis also gives a
   positive defect bound 2/9 when an order-three target image is
   impossible; an explicit example gives the endpoint upper bound 8/27.

2. Odd-target arrangement repair.
   For s = 2m >= 4 vertical edges and nearest-model distance d,
   epsilon_s >= s*d - s*(3s-2)*d^2/2. Inverting on the proved small
   branch improves the second-order repair coefficient. A half-interval
   construction over common prime groups improves the lower obstruction:

       (s-1)/s^2 <= c_s^prime <= (3s-2)/(2s^2).

   At s=16, the new bracket is [15/256,23/256], compared with the
   recorded [23/512,15/128]. The exact coefficient remains unresolved.

3. Erasure-sensitive arrangement repair.
   Conditional defect tending to zero now forces observed disagreement
   to tend to zero, under the inherited explicit near-full-domain
   activation condition. The bound has square-root order for arbitrary
   rows, linear order under a positive row-density lower bound, and an
   additional bound using the entire row profile. Thin-row examples
   establish the stated sharp asymptotic regimes.

4. Improved real centered uniformity comparison.
   On every finite odd-order abelian group:

       ||f||_U4^16 >= (843/100) ||f||_U2^16.

   The previous repository factor was 29/4. The new comparison is
   obtained from a profiled moment argument and complete exact dual
   certificates for every possible odd character order.
   It gives c_4^odd <= (100/843)^(1/4) = 0.5868716172...
   and a dimension-four quartic cube coefficient at most 58.68716172...

The manuscript includes complete proofs of the earlier decoder and
quartic expansion used as inputs, a direct refinement of Gowers's
Lemma 3.10, twelve further research questions, and a formalization plan.
Earlier results and methods are explicitly attributed.

FILES

  gowers_local_refinements.tex   Complete standalone article and bibliography
  gowers_local_refinements.pdf   Compiled article
  Makefile                      Build and verification commands
  INTEGRATION.txt               Placement, label, attribution, and status notes
  code/                         Five verifiers and the run_all.py runner
  data/                         Exact certificates, logs, and run summary
  data/source_manifest.json     Pinned source provenance and hashes
  data/build_validation.json    PDF/source build checks and page count
  SHA256SUMS.txt                 Checksums of the packaged deliverables

BUILD

Use a standard TeX Live installation with pdflatex and latexmk. Packages
used by the source include the AMS packages, lmodern, microtype, geometry,
booktabs, tabularx, enumitem, hyperref, and pgfplots. The plot is embedded
in the TeX source; no image files or bibliography database are needed.

From the package root:

  make pdf

or:

  latexmk -pdf -interaction=nonstopmode -halt-on-error \
      gowers_local_refinements.tex

VERIFICATION

Python 3.10 or newer; standard library only. From the package root:

  make verify

or:

  python3 code/run_all.py

The packaged run used CPython 3.12.14 and passed all five programs.
The runner writes each program's log to data/, records exit statuses
and runtimes, and returns a failure status if any program fails.
Do not run with Python -O or -OO: the assertions are part of verification.
The runner rejects runs with disabled assertions.

The checks cover 50,735 exhaustive affine maps plus 2,400 seeded
evaluations; 7,575 rational weighted inputs; 3,836 pointwise
arrangement patterns; 1,539 full maps into Z/3; 1,539 partial binary
labelings; explicit sharpness examples; and all finite rational
certificates used by the norm proof.

The affine and arrangement computations supplement universal written
proofs. The norm coefficient lemma is computer-assisted: its complete
finite enumeration and all rational sign checks are supplied. Rounded
decimal values are never used to establish an inequality.

PROVENANCE AND STATUS

Repository comparison:
  VladimirReshetnikov/ProveIt
  0ef37201dea1237390e59d0960c1058aaeaa3572

Canonical research directory:
  Combinatorics/Ramsey/Research/GowersSzemeredi/
  local-quantitative-refinements/

The combined body and the relevant later supplements were inspected.
This package does not reserve a new source number and does not modify
the repository. It is an AI-assisted research manuscript with internal
mathematical and computational audits. It is not an externally refereed
publication or a Lean formalization. No new global Szemeredi bound or
optimal universal norm constant is claimed.

Third-party papers and earlier source manuscripts are cited, not
redistributed in this archive.
