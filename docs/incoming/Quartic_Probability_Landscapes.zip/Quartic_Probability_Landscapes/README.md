# Probabilities from Well-Conditioned Quartics

A sparse Diophantine realization of stochastic computation, low-energy topology,
and its logical limits. Research draft prepared for Vladimir Reshetnikov,
September 30, 2026.

## Read first

`article.pdf` is the 26-page article. `article.tex` is its complete, standalone
LaTeX source, including the bibliography. No external figures or font files are
required by the source.

The main explicit construction translates a Boolean circuit with k free inputs
and s gates into a coercive, nonnegative integer quartic in at most k+5s+5
variables. Its coefficient height is at most 4 and its variable-interaction
graph has maximum degree 3. Real zeros are Boolean and correspond bijectively
to accepting inputs. At zeros the Hessian spectrum lies in [2,20]. The article
proves a dimension-independent rounding gap, convex low-energy components,
specified perturbation stability, and consequences for normalized component
counts of probabilistic computations.

Further sections prove an interaction-degree counting frontier, characterize
the resulting probability limits, provide fixed-arity Diophantine normal forms
for probability comparisons, and analyze almost-sure versus finite-mean
termination. Ten further research questions and a proposed ProveIt formalization
plan are included.

## Status and boundaries

This is a research draft with mathematical proofs and executable finite checks.
It is not independently refereed and is not Lean-checked. Publication priority
for the simultaneous quantitative construction has not been established.
Boolean arithmetization, general MRDP, left-c.e. halting probabilities, and the
classical probabilistic-termination hierarchy results are not claimed as new.
The article identifies and cites these dependencies.

The implemented boundary is Boolean circuits -> finite quartics, plus a
counter for Boolean residual systems of interaction degree at most 2. There is
no implemented universal Turing-machine frontend, no expanded universal
fixed-arity polynomial D/Q/V, and no formal proof-assistant development in
this archive. Those representation results are mathematical arguments, not
claims that absent code was executed. No finite-fold MRDP conjecture is claimed
solved. The finite-horizon witness bijection does not imply single-fold MRDP.

The relevant ProveIt source was inspected at immutable revision:
`b998f70c6886e6a00339a6f4a02ed8625324d357`.
Repository builds and axiom audits were not rerun. The provenance file records
the exact paths and external sources used.

## Contents

- `article.pdf`, `article.tex`: article and editable source.
- `code/quartic_compiler.py`: validated circuit model, occurrence routing,
  unique wire extension, sparse polynomial expansion, and JSON output.
- `code/degree_two.py`: exact path/cycle/triangle counting algorithm.
- `code/verify.py`: deterministic structural and finite exact checks;
  separately labeled optional numerical Hessian checks.
- `results/verification_report.json`: machine-readable report.
- `results/test_output.txt`: captured successful run.
- `results/geometric_horizon_0.json` through `_3.json`: explicit expanded
  polynomials, residuals, and source circuits for the geometric-waiting example.
- `build.sh`: rebuild the PDF with pdfLaTeX.
- `PROVENANCE.md`: research and software provenance.
- `SHA256SUMS.txt`: hashes of the packaged files other than the hash file itself.

## Run the checks

Python 3.10 or later is required. The supplied run used Python 3.13.5.
The compiler and exact checks use only the standard library. NumPy, when
already available, enables 60 additional floating-point Hessian smoke tests;
these are not needed for the exact checks or the mathematical proofs.

From this directory:

```sh
python code/verify.py
python code/quartic_compiler.py --or-inputs 3 --output landscape.json
```

The recorded run passed 6,050 exact finite checks, including 175 structural
circuit audits and 122 degree-two counting instances. It additionally passed
30 Hessian checks at zeros and 30 inside well boxes. The exact check total is a
sum of the report's named finite-check categories, not a count of formal
proof obligations.

The verifier rewrites the files under `results/`. Small floating-point
last-digit differences are possible across numerical linear-algebra libraries.
Exact integer/rational results do not depend on NumPy.

The JSON format lists a monomial as a sorted list of variable indices:
`[2,2,5]` denotes X_2^2 X_5. The empty list denotes the constant monomial.
Every monomial has an explicit integer coefficient.

## Python API example

```python
import sys
sys.path.insert(0, "code")
from quartic_compiler import compile_circuit, or_circuit

circuit = or_circuit(3)
compiled = compile_circuit(circuit)
point = compiled.extend((1, 0, 0))
assert compiled.energy(point) == 0
print(compiled.structural_statistics())
compiled.write_json("or_three_bits.json")
```

The three-bit example has 36 variables and 7 real/natural/integer zeros.
Its probability normalization is 7/2^3, not 7/2^36: internal wires are
uniquely determined auxiliaries, not independent random bits.

## Rebuild the PDF

A full TeX Live installation with `newtx`, `amsmath`, `amsthm`, `mathtools`,
`microtype`, `geometry`, `tcolorbox`, `tikz`, `hyperref`, and `cleveref` is
sufficient. The package source loads other standard layout packages as listed
in its preamble. Run:

```sh
sh build.sh
```

Or run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three
times. The bibliography is embedded; BibTeX/Biber is not needed. The supplied
PDF was compiled successfully, with no unresolved references or overfull boxes,
and its rendered pages were visually inspected.

## Interpretation cautions

Root counts and low-energy component counts represent equal counting measure
on free coin tapes. They are not claims about attraction-basin volumes, random
gradient descent, or Gibbs probabilities. Nondegeneracy is nondegeneracy of an
energy minimum; the gradient of the zero-defining polynomial is zero there.
The interaction-degree frontier concerns the stated residual presentation.
Finite-mean claims require runtime control under substrate translations;
Turing completeness or halting-probability preservation alone is insufficient.
