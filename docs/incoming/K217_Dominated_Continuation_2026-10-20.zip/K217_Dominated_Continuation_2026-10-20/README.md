# K217: a blank-started machine for Con(ZFC)

This packet constructs a binary, two-way-infinite, single-tape Turing machine with **217 working states and 434 transition rows, including initialization**. Its ordinary mathematical proof, composed with the pinned repository calibration, establishes

```text
ZFC proves: not Halt(K217, blank) <-> Con(ZFC).
```

The canonical machine is `machine/k217.tm`: start state 0, blank symbol 0, working states 0–216, halt label 217 with no outgoing rows, and only L/R moves. Every noncomment row has the form `state read write direction next`.

**Canonical SHA-256:**

```text
522a71c067afe8862c9aab98e0f7f93eac747f5ef91d26bd3568760e1c1c478f
```

The native table retains predecessor labels, dispatcher 84 and halt 254. Its SHA-256 is `b235f7d0403460ff00d274d7d030fec6ba3562127035165e3ead555237c83088`. The state bijection is recorded in `machine/canonicalization.json`.

## New reduction

The immediate parent is the incoming `K218_Dominated_Rho8_2026-10-20.zip`, preserved byte for byte under `parent/`. Its dominated-rho8 theorem and 203-subtree source are inherited work.

Three closed source rotations expose native state 213 as a selector with branches `0 R 92` and `1 R 90`. States 69 and 400 have the same read-one branch; their unique incoming edges write different origin bits immediately behind the head. Rereading that marker on the zero branch reproduces their old continuations in exactly three steps. State 400 can then be deleted.

The final table changes nine retained rows, adds no state, and preserves the complete source primitive word and guarded ordinal control graph. The source still has 4,751 instruction occurrences and 203 distinct subtrees. A separate direct proof establishes all-initial-tape equivalence of the final merge to its rotated 218-state intermediate using positive one- or three-step blocks.

## Verification

- Exact source reconstruction, two original CFG resolvers, separately authored source/fold audit, and expected complete decoder-role binding.
- All **6,176** quantified primitive cases pass: **1,616,558** symbolic rules, minimum affine duration constant **13**, and all **434** transition rows covered. The proof domain includes independent arbitrary natural register values, gaps, and nonempty finite spare lists.
- Exact blank startup reaches native state 84 (canonical 83) at head −5 after **312,617** transitions. The whole tape has **277** one-cells, logical registers `[3,0,0,0,3,0,0,0,0]`, extra gap 80, and 130 spare registers of value one.
- Independently written sparse and dense interpreters and a canonical-table replay agree on that entire frame.
- The independent all-tape window checker passes 962,479 invariant contexts and rejects a corrupt initial halt.
- The inherited dominated-row certificate and its two forward checkers are included and freshly replayed.

These are ordinary mathematical proofs and executable certificates. **There is no newly compiled Lean/Rocq theorem or internally checked PA endpoint for the exact K217 bytes.** No unconditional nonhalting, minimum-state theorem, or discovery-priority claim is asserted.

## Reproduce

Python 3.10+, standard library only, assertions enabled. No network access is needed.

```bash
python3 -B verify.py
python3 -B verify.py --runtime --work /tmp/k217-full-replay
```

The optional work directory must not already exist. The second command regenerates every unbounded symbolic runtime derivation and compares the complete ordered case receipts with the included compressed file. It takes roughly two minutes in the construction environment. The first command verifies the stored case inventory and all finite construction/source/fold/startup checks, without rederiving those runtime cases.

Read `report.pdf` for the full 18-page article, inherited logical calibration, new proofs, further research questions, and complete canonical table. `report.tex` and `sections/` contain its LaTeX source. Rebuild it with two runs of `pdflatex report.tex`.

For integration, preserve the exact hashes and identify the dominated-source parent; this is not a direct single-row patch to the separately published primary K218 layout. Attribution and license provenance are in `provenance/ATTRIBUTION.md` and the unchanged parent archive.
