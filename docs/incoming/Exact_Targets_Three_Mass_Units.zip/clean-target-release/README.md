# Exact targets with three conserved mass units

A separate, 15-page mathematical extension of the frozen three-mass construction.

Start with clean-target-report.pdf. The standalone editable source is clean-target-report.tex; it has no external figure or TeX input dependency. CLEAN-TARGET-THEOREM.md is the audited mathematical source statement.

## Result

A fresh-entry reversible source runs forward, uncomputes, then reaches H with its input restored. Compiling this wrapped source gives undecidable exact configuration-pair reachability for one fixed reversible weighted CA of mass three, also at radius one. The exact target depends on the input raw N. The construction does not provide one target for all inputs or an expanded universal source table.

If the original first halt takes h source instructions and native time Theta, the cleaned source takes 2h+2 instructions and native or spatial time 2Theta+192(Nh+N0)+16. Phase time is fourfold. The compact quadratic natural-number certificate retains 2Bh core variables; its affine lift is a bijection on natural zero fibers only.

## Verify and replay

Requires Python 3 and its standard library only:

    python verify_manifest.py
    python replay.py

The replay script uses a temporary isolated copy, runs normal and optimized producer tests, all four independent audit harnesses, and a byte-exact CLI example round trip. It does not overwrite sealed receipts or examples. To save a new receipt outside the package, pass --receipt followed by the desired output file.

For direct CLI use, from an editable copy of the package:

    python clean_targets.py export examples/chain_request.json certificate.json --expanded
    python clean_targets.py witness certificate.json witness.json
    python check_clean_targets.py certificate.json witness.json

To rebuild the PDF with TeX Live:

    sh build.sh

The build script uses .build for scratch data. Source and PDF use Letter pages and Latin Modern fonts. A normal TeX distribution can also compile the standalone .tex directly.

## Files

- clean-target-report.pdf and .tex: report and editable source
- clean_targets.py: source wrapper, compact exporter, witness construction, hygienic affine lift
- check_clean_targets.py: separate wrapper/certificate checker
- test_clean_targets.py and test_affine_lift.py: producer lattice and certificate tests
- vendor/: five byte-identical frozen compiler/checker/radius dependencies
- examples/: chain with N0=5, Nh=10, first exact target at native tick 29856
- audit/: independent review and portable audit harnesses
- receipts/: original audit results, producer results, and final portable replay evidence
- SOURCE_PROVENANCE.md and provenance/: precise source hashes and portability adaptations
- SHA256SUMS and verify_manifest.py: delivered-file integrity checks

No third-party paper PDFs, machine-specific dependency paths, or universal-machine claims inferred from small examples are included. The companion release 9 was not modified.
