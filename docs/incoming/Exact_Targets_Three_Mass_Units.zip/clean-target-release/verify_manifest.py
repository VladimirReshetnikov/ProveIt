#!/usr/bin/env python3
"""Verify sealed files and reject unexpected package members."""
from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parent
expected={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    h,n=line.split('  ',1)
    p=Path(n)
    if p.is_absolute() or '..' in p.parts or n in expected:raise SystemExit('unsafe or duplicate manifest name')
    expected[n]=h
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and not any(x in ('.build','__pycache__') for x in p.relative_to(root).parts)}
if actual != set(expected)|{'SHA256SUMS'}:raise SystemExit('file set mismatch: '+str(actual.symmetric_difference(set(expected)|{'SHA256SUMS'})))
for n,h in expected.items():
    p=root/n
    if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise SystemExit('hash mismatch: '+n)
print('PASS: '+str(len(expected))+' sealed files')
