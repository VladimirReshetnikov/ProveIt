# Two Derivations Remove the Borel Conjugacy Obstruction

**Scalar normalizing coordinates, simultaneous normal forms, and finite-dimensional
Lie algebras on left-finite series fields**

Research manuscript prepared with ChatGPT, 4 October 2026.

## Main result

Fix an additive exponent subgroup Z <= Gamma <= Q. On the real-coefficient field
K_Gamma of left-finite series, every coefficient-Borel derivation is a E, where
E = t d/dt. Under coefficient-Borel ordered-field automorphisms, noncommuting
ordered pairs of these derivations admit an explicit Borel cross-section, and
any simultaneous conjugator is unique and Borelly recoverable.

The ratio h = b/a determines the coordinate. A canonical scalar H and a unique
substitution Theta satisfy Theta(H) = h; the normal pair is
(A E, H A E), where A = Theta^(-1)(a E(h)) / E(H).

The manuscript also gives the ramification-sensitive affine/projective
classification of finite-dimensional Lie subalgebras, its whole-field
integration boundary, and an exact positive-affine action. Eight subsequent
research questions specify extensions and category boundaries.

## Files

- `two_derivations.pdf`: typeset article with complete proofs and references.
- `two_derivations.tex`: self-contained LaTeX source; bibliography included.
- `verify.py`: exact symbolic regression tests.
- `verification_report.txt` and `verification_report.json`: the recorded run.
- `requirements.txt`: tested symbolic dependency.
- `build.sh`: three-pass LaTeX build, with intermediates in `.build`.
- `SOURCE_AUDIT.md`: source and scope record.

## Reproduce the checks

Python 3.10 or newer is recommended. The included run used Python 3.13.5 and
SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python verify.py
```

The run passes **669 exact assertions**: 104 scalar/pair checks, 37 Lie checks,
15 affine/BCH checks, and 513 finite-spectrum checks. Arithmetic is symbolic and
rational, with no floating-point tolerances. The last category includes all
512 subsets of the integer interval [-4,4]. A failed check raises an exception;
these checks are not disabled by running Python with optimization.

These are finite regression tests, not a proof-assistant formalization. They
do not verify infinite-support or Borel arguments and cannot establish novelty.

## Rebuild the PDF

Install a LaTeX distribution with pdfLaTeX and the packages named in the source
(in particular newtx, amsmath, mathtools, microtype, tcolorbox, xurl, and hyperref).
Run from this directory:

```sh
sh build.sh
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error
two_derivations.tex` three times. No external bibliography processor is needed.
On Windows this command can be used directly in a LaTeX-capable terminal.

## Status and limitations

This is an AI-assisted, unrefereed research manuscript. Proofs are provided for
the stated results, but there is no independent referee certification, no Lean
verification, and no certified claim of historical priority. The dimension-three
bound and affine/projective pattern are classical; the proposed contribution is
the combined scalar-coordinate and Borel simultaneous-classification package,
including unique witnesses and the ramification refinements.

The relevant structures are set-sized. Theorems about formal series are not
claims about convergence of analytic germs, all Hahn supports, all surreal
numbers, or arbitrary non-Borel derivations. The Lie-action boundary explicitly
assumes coefficient differentiability with a Borel derivation as generator.
No solution of a named remaining question from Glazer's paper is asserted.
Neither Elliot Glazer nor Vladimir Reshetnikov is represented as an author or
endorser of the manuscript.
