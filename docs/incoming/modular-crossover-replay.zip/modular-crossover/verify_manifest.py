#!/usr/bin/env python3
"""Verify the SHA-256 hashes of the sealed package files."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
count = 0
for line in (root / 'MANIFEST.sha256').read_text().splitlines():
    if not line.strip():
        continue
    digest, name = line.split('  ', 1)
    relative = Path(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError(f'Unsafe manifest path: {name}')
    path = root / relative
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != digest:
        raise SystemExit(f'FAILED: {name}')
    count += 1
print(f'PASS: {count} sealed files match MANIFEST.sha256')
