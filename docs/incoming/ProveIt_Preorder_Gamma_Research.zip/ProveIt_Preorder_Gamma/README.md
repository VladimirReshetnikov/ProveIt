# Gamma-Positivity for Every Finite Preorder

**Disjoint transport supports, Boolean expansions, block formulas, and a
transitivity criterion for palindromicity.**

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT,
29 September 2026. The article is 22 pages.

## Main result

For any finite preorder tau on n elements, the support polynomial of its
preorder polytope satisfies

    h_tau(t) = sum_k |T_k(tau)| t^k (1+t)^(n-2k),

where T_k consists of ordered pairs (U,V) of disjoint k-element sets admitting
a bijection f:U -> V with u <=_tau f(u). A pair is counted once even if it has
several witnessing matchings. The formula proves the statement of
Athanasiadis–Chapoton Conjecture 5.2 for all finite preorders, including
nontrivial equivalence classes and arbitrary height.

The proof uses an established bipartite demand/matching-support counting
identity, whose reduction to cited classical results is given in Section 3.
The new support-fibre reduction and Boolean summation are in Section 4.

The article also proves a separate elementary classification: for a
reflexive relation R, its doubled matching-support polynomial has coefficients
|R| and |R*| in degrees 1 and n-1. Consequently palindromicity, gamma-positivity,
transitivity, and common-support cancellation are equivalent. This classifies
balanced bipartite graphs admitting a perfect matching, but not arbitrary
unbalanced graphs or graphs with smaller maximum matching size.

Further results include the multivariate support formula, positive block
formulas, gamma-coefficient monotonicity, sharp extremal bounds, an exact
formula for the multiplicity at -1, and support-size probability formulas.
Ten further research questions are included.

## Files

- `article.pdf`: the compiled 22-page research article.
- `article.tex`: complete LaTeX source, with an internal bibliography.
- `code/verify.py`: standard-library exact finite verifier.
- `data/preorders.csv`: every labeled preorder through size five, with h and
  gamma coefficient vectors.
- `data/verification.json`: detailed results, including all larger samples.
- `data/verification.log`: console transcript of the recorded run.
- `SOURCE_AUDIT.md`: source roles, version pin, and priority limitations.
- `PROOF_STATUS.md`: theorem dependencies and verification boundaries.
- `build.py`: three-pass pdfLaTeX build script.

## Reproduce the computations

From this directory:

    python code/verify.py --max-n 5 --out new-data

Python 3.10 or later is required; no external Python packages are used.
Do not run Python with `-O`: the verifier intentionally uses assertions and
rejects optimized execution. Choose a new output directory to keep the
delivered record unchanged. The complete recorded run took about 11 seconds
in the supplied environment; this is a measurement, not a portable benchmark.

The recorded run passed:

- all 7,332 labeled preorders through size five;
- 228,075 individual support fibres and 1,774,841 equally sized doubled
  support pairs in those exhaustive preorder tests;
- all 689 bipartite graphs with shores of sizes at most three, checking the
  support-resolved demand identity;
- all 4,166 reflexive relations through size four, including nontransitive
  relations, checking the characterization and closure-defect formulas;
- 140 distinct deterministic samples on six, seven, and eight elements;
- binomial/Narayana explicit-formula consistency checks through size twenty.

The sample generation is not uniform. The last checks are comparisons of
explicit formulas, not exhaustive dimension-twenty lattice-point counts.

CSV bit positions are zero-based. Entry i of `principal_ideal_bitmasks` is
{j : j <=_tau i}, encoded as an integer bitmask. Vector fields use semicolons;
polynomial coefficients are in increasing degree and retain trailing zeros
in gamma vectors. The empty preorder has polynomial 1.

## Build the article

    python build.py

A TeX installation with pdfLaTeX, the New PX fonts, and the packages named in
the preamble is needed. The script writes intermediate files to `build/` and
copies the final PDF to `article.pdf`. It runs three passes so the contents,
bibliography citations, and cross-references settle.

## Status

The manuscript supplies ordinary mathematical proofs and is unrefereed.
It is not Lean-, Rocq-, or otherwise proof-assistant-verified. The finite
programs are cross-checks, not proofs for arbitrary n. Established external
theorems are stated as inputs, and the unrefereed geometric realization in
the ProveIt report is not an input. Absolute publication priority has not
been certified. General flag-polytopal realization is not settled, and no
new claim of general real-rootedness is made.

Repository reference: VladimirReshetnikov/ProveIt, commit
`9b24a3a8d545af9624f6ac455f5b548be62818b6`, directory
`SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes/`.
