# Well-orders of the Surreal Numbers

**Lexicographic universality, a surreal dense core, and the boundary between sets and classes**

Research manuscript prepared for Vladimir Reshetnikov, 2 October 2026.

The article distinguishes exhaustive well-order enumerations of a fixed set of
surreals, all injective set-length surreal words, and global ordinal enumerations
of the surreal class. It supplies written proofs and an explicit foundation for
each interpretation.

## Main results

For a fixed infinite linearly ordered set X of cardinality κ, its lexicographic
space of all well-orderings has cardinality 2^κ, contains the binary lexicographic
cube of length κ, and contains an ordinal β (or its reverse) exactly when β < κ⁺.
The article also classifies its endpoints and adjacent pairs.

In Gödel–Bernays class theory with global choice, fix a global enumeration
b: Ord → No. The eventual perturbations of b have canonical set-sized support
codes. Their lexicographic order C_b is isomorphic to the numerical surreal order.
More strongly, this core interpolates every uniformly set-indexed separated pair
of families of arbitrary global enumerations. Every class linear order embeds
into the core and into its intersection with any nonempty global open interval.

The article proves bounded reflection of set-indexed configurations, constructs
an explicit unfilled proper-class cut, and gives a diagonal proof that no uniform
family indexed by a class of sets can contain every global enumeration. It also
proves that existence of a global surreal enumeration is equivalent to global
choice over GB with ordinary choice for sets. An inaccessible-cardinal model
illustrates the distinction between a small-universe class and a larger-universe
set of all enumerations.

## Files

- `article.tex`: standalone LaTeX source, with an internal bibliography.
- `article.pdf`: compiled 24-page article, including nine research directions,
  the repository/source audit, and a theorem-status ledger.
- `build.sh`: three-pass PDF build.
- `RESEARCH_STATUS.md`: scope, proof status, limitations, and dependency summary.
- `code/finite_checks.py`: standard-library finite mechanism checks.
- `data/finite_checks.json`: recorded deterministic run.
- `SHA256SUMS.txt`: checksums of the release files, excluding itself.

## Build and tests

A TeX installation with pdfLaTeX, AMS packages, newtx, aliascnt, cleveref,
tcolorbox, and the other packages named in the preamble is required.

```bash
bash build.sh
python3 code/finite_checks.py
```

The PDF build writes intermediates into `build/` and copies the finished PDF to
the root. No intermediate build files are included in this release.

The recorded Python run passed **164,560 assertions**, including **1,101
separator-family cases**. The pair-switch and finite prefix-completion suites
exhaust their stated finite ranges; other tests use a fixed random seed and exact
rational arithmetic. The JSON report gives the ranges, seed, and per-suite counts.
These tests do not verify any transfinite theorem or any Lean declaration.

## Repository relationship and status

The targeted ProveIt inspection is pinned to commit
`63bb8b1d99359e7188abf0a33fb152e121858150`.
Relevant items are the real well-ordering report's README and the actual
`SignSequence.lean` / `SignSequenceCutOperation.lean` foundational source.
The manuscript distinguishes existing Lean declarations from its proposed
formalization plan. The repository was neither modified nor rebuilt.

This is an AI-assisted, unrefereed research manuscript. Its infinite results have
written proofs, not machine-checked proofs. It makes no historical-priority claim.
The literature and repository searches were targeted, not exhaustive.
