# Report 25: The entire native Pell fiber and its two-term height count

Read `report25.pdf` for the article and `report25.tex` for its editable source.

For fixed valid prescribed-scale native AND ports, seventeen of the twenty-two positive supplied coordinates are forced. Every complete native witness is uniquely indexed by

    m = M0 l, l >= 1;    n = p, or 4mk-p, or 4mk+p, k >= 1.

The exact native height is y_aux. With T=log H and lambda=log(A+sqrt(A^2-1)), the ordinary unsmoothed count has the two-term expansion

    N(H) = kappa T + zeta(1/2) sqrt(T)/(M0 sqrt(lambda)) + O(T^(1/3)).

The coefficient kappa keeps the exact convergent normalized-base slope series and a separate baseline contribution. This is a logarithmic count and inverse-height theorem; it does not establish a multiplicative equivalent for the enumerated heights.

The companion theorem also counts the sum of all twenty-two positive coordinate bitlengths, retaining every rounding boundary and tie. Its distinct baseline denominator is 3p-2; the leading total-bit coefficient is not simply one third of the maximum-height coefficient.

## Contents and source boundaries

- `source/`: all five mandatory pinned repository proof documents, the four literal native JSON fixtures, and source provenance
- `proofs/entire-fiber/`: reviewed full reconstruction, converse, exact height, finite count, and first-order estimate
- `proofs/second-term/`: unsmoothed second-term proof, independent analytical review, test scope and caveats
- `proofs/total-bitlength/`: reviewed exact-product identity, uniform energy bound, total-bit counting law, rounding sandwich and ranked-total-bit inversion
- `proofs/canonical-transport/SUMMARY.md`: the original Report 22 outer-coordinate uniqueness and native-fiber projection, retained as a conditional proof summary only
- `provenance/`: unchanged original packet manifests; `delivery-provenance.json` separately gives every original and delivered SHA-256, byte count, adaptation and omitted historical component
- `source-pins.json`: the exact mandatory scientific corpus; its complete map is independently fixed in `verify_release.py`
- `audit_dependency.py`: independently implemented sparse integer-polynomial arithmetic, all sixteen residual identities on all four fixtures, the seventeen/five coordinate partition, and three scientific corruption checks
- `check_entire_fiber.py`: exact modular divisibility, auxiliary norm/congruence, normalized-index exhaustion and finite-count boundary checks
- `check_second_term.py`: 24 exact Pell-height threshold checks, 612 hyperbola identities, rectangle/phase negative checks and 8 integer-exact asymptotic model counts
- `check_total_bitlength.py` and `check_total_bitlength_review.py`: two independent exact reconstructions, 54 finite-sample bit-cutoff tests, denominator mutations, and direct powers-of-two/rounding/tie tests
- `DEPENDENCY-RECEIPT.json`, `CHECK-RECEIPT.json`, `SECOND-TERM-RECEIPT.json`, `TOTAL-BITLENGTH-RECEIPT.json`: deterministic expected results compared read-only
- `report25-math-review.md` and `report25-qa.json`: article review and document QA

All claim-needed proof and arithmetic sources are mandatory. There are no optional scientific files in the default replay. Original repository Python is not included or executed. The first-order source audit used a symbolic package; this release replaces it with exact sparse integer-polynomial arithmetic using only Python's standard library. Its scientific fixtures and mutation semantics are preserved. Every prose/path adaptation is identified in provenance.

No complete astronomical padded native witness is materialized. Small arithmetic fixtures test auxiliary subsystems or analytical count models; they are not valid padded native-port instances merely because their Pell identities pass. The universal classification and asymptotic claims rest on the proofs and credited source theorems. The original Report 22 circuit code is not needed or replayed, and no fresh certification of its operation counts is claimed here.

The full canonical outer construction may impose a fixed outer height cutoff. Above that cutoff its count equals the native count and has the same two coefficients. The native fiber itself has no fixed-coordinate plateau.

## Offline verification and replay

The checkers use Python 3.10 or newer and only its standard library; no package installation, network access, repository checkout, SymPy or mpmath is needed. The full replay has been tested on Linux and requires a filesystem and permissions that allow creation of the symbolic links used by its rejection tests. The optional build.sh is a POSIX shell script.

    python3 -B verify_release.py
    python3 -B replay.py --output ../new-report25-replay

The output directory must be new and outside the release. Every checker runs in a fresh relocated copy under `-I -S -B`, once normally and once with `-O`, from an unrelated working directory. Both modes execute the same substantive explicit checks. Replay checks the original and relocated trees after every command: exact files and directories, all bytes, modes and modification times must remain unchanged. Logs and the new replay receipt are written only outside the release.

The final seal lists the exact complete file and directory inventory, including the article, review and QA. Verification rejects extra, hidden, missing, altered and bytecode files, extra empty directories, symlinks, malformed manifest paths, duplicate JSON keys and changed seals. It also rejects resealed changes to any mandatory scientific source, altered/missing/additional source pins and resealed changes to the deliverable inventory. `release_checks.py` exercises these failures on disposable external copies in both execution modes.

SHA-256 consistency seals are not external digital signatures. Obtain the final archive digest through a trusted channel when checking publication authenticity.

A release author may run the preliminary scientific payload before sealing:

    python3 -B replay.py --unsealed-payload --output ../new-report25-preliminary

Its receipt explicitly excludes final-seal verification and inventory mutation certification, so it cannot substitute for the final replay.

## Rebuild and intentional receipt updates

`sh build.sh` optionally rebuilds the PDF with TeX; build intermediates stay outside the release. TeX is not required for scientific replay. Any PDF or source edit invalidates an existing seal.

The four receipt-comparing scientific checkers have an explicit `--write` mode for intentional receipt generation. Default replay never invokes it. Changing a mandatory dependency also requires deliberate source-pin/provenance maintenance; simply regenerating the top-level manifest cannot bypass its frozen pins.

After the article, independent review and visual QA are complete, a release author may seal with:

    python3 -B write_manifest.py
    python3 -B verify_release.py

Then run complete replay on a freshly extracted archive before delivery. Unrequested additional files, including build products, screenshots, caches and scratch logs, must remain outside the sealed release.

## Limits

This is a fixed-source positive-integer witness-fiber result, conditional on the credited native soundness/completeness and canonical transport theorems. It is not a circuit simplification, operation-saving result, finite-fold construction, universal ordinary-input loader, all-orders expansion, optimal-remainder claim or literature-wide novelty claim. The initially halted no-witness construction is outside the nonempty fiber theorem.
