# K215: composing command encodings with a partial selector

Two explicit deterministic binary Turing machines have 215 working states and 430 rows each. Both start in state 0 on a completely blank, two-way infinite tape. Every move is L or R; the canonical halt state 215 is separate and has no outgoing rows.

The primary machine is machine/k215.tm. The second is secondary/machine/k215.tm. The construction combines the predecessor's local counter-field readers and command permutation with a partial-row source selector, preserving source aliases by ordinal interval. The selector identifies 164 and 183 using the bit their incoming transition has just written. The triggered branch takes three steps instead of one, with exactly the same complete tape and endpoint. State 183 disappears; no state is added.

Each source has 202 distinct subtrees and 4751 primitive occurrences. A direct append-only DAG recipe and two independent complete guarded-control-flow resolvers relate it to the corresponding 216-state source. This is an all-natural source bisimulation, not a finite register test. The parent's numerical-calculus-to-ZFC calibration, including junk codes, is inherited unchanged.

The primary blank run reaches a genuine zero-PC source root after 95714 steps. The second does so after 96284 steps. Both endpoints have native dispatcher 84, head −8, gap 1, registers (N,T,W,A,D,H,X,Y,L)=(4,0,0,0,0,0,0,0,0), forty spare registers all 1, and exactly 95 one-cells. A dispatcher state with a nonzero PC is not counted as initialization completion.

## Trust boundary

The ordinary mathematical proof establishes: ZFC proves that the machine does not halt from the blank tape if and only if Con(ZFC). The proof is ordinary mathematics with executable symbolic certificates, not a new Lean/Rocq endpoint for these exact bytes or an internally checked PA formalization. Nothing here asserts unconditional nonhalting, Con(ZFC), or minimality.

## Reproduction

Python 3.10 or later, standard library only, with assertions enabled. No search, solver or network is required.

    python3 -B verify.py
    python3 -B verify.py --runtime --work /tmp/k215-primary-replay
    python3 -B verify.py --runtime --secondary-runtime --work /tmp/k215-both-replay

The work directory must not already exist. Default verification checks the archive's exact manifest, unchanged pinned predecessor, deterministic source/table reconstruction, complete source graph, all-tape fold, canonical relabeling, graph reachability, complete literal blank trajectories and stored runtime inventory. It does not misrepresent stored receipts as a fresh runtime derivation. The runtime flags freshly derive the 6176 guarded primitive cases for the indicated variant and compare their ordered receipts.

Each runtime case universally quantifies over natural primary registers and gap, and an arbitrary nonempty finite spare list. Positive affine duration certificates establish progress. Source soundness/completeness and cofinal refutations above cutoff 4 are inherited from the pinned predecessor through the verified all-natural bisimulation.

The report contains the argument and primary canonical transition table. Source files, scripts, machine tables, evidence, licenses and the pinned parent archive are included. See provenance/ATTRIBUTION.md.

## Verified runtime results

Both machines passed all 6,176 unbounded guarded cases and cover all 430 transition rows. The primary requires 1,698,790 symbolic rules with minimum affine duration constant 6. The second requires 1,698,845 symbolic rules with minimum constant 9. Each working state is graph-reachable.
