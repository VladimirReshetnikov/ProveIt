# Prefix247: a 247-state ZFC consistency machine

This package supplies an explicit **247-working-state, two-symbol, single-tape Turing machine starting on a completely blank tape**, with an ordinary mathematical proof and executable certificates for

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{247},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The construction improves the supplied Prefix250 machine by **three states** and the maintained permutation252 candidate by **five states**. Read [report.pdf](report.pdf) or its [LaTeX source](report.tex). The report includes the full canonical transition table, unbounded register identities, complete-frame simulation, exact startup, and the specific set-coded argument inside ZFC.

**Proof status:** this is a conventional mathematical proof with executable induction and instruction certificates. The exact 247-state endpoint has **not** been newly checked by a Lean or Rocq kernel. The package does not supply a serialized first-order ZFC derivation or the stronger PA-internal proof-code comparison. The inherited logical source was inspected; its full proof-assistant dependency closure was not rebuilt. These statements describe the form of verification, rather than an additional consistency assumption in the displayed equivalence.

## The new idea and the entire change

Use original labels in the incoming Prefix250 table. Change one surviving row:

```text
60 0 0 R 0    ->    60 0 0 R 20
```

Delete both rows of states **0, 1, and 3**. Retain start state **97**, halt **254**, and every other surviving row.

The prefix-carry redesign had already replaced the old zero-decrement return routine. Its two return states, 1 and 3, remain reachable only through the old marking state's read-zero branch during initialization. During proper register selection, state 60 moves from the separator of `0 1^(v+1)` onto its first one. The old marking state 0 therefore reads one, including for a zero-valued register. Its action `(0,L,2)` is exactly state 20's read-one action.

An intermediate 248-state machine makes the quotient explicit: delete states 1 and 3 and change state 0/read-zero to `(1,L,2)`. Both rows of state 0 then equal those of state 20. Identifying these states is an exact one-step quotient on arbitrary tapes, checked across all 496 intermediate rows. The altered blank startup is verified directly; it is not borrowed from the previous machine.

## Exact machine and startup

| Convention | Canonical table | Original-label table |
|---|---|---|
| File | [machine/zfc_prefix247.tm](machine/zfc_prefix247.tm) | [machine/zfc_prefix247_old.tm](machine/zfc_prefix247_old.tm) |
| Working states | 0 through 246 | `{0,...,253} - {0,1,3,5,8,43,59,85} + {255}` |
| Start | 0 | 97 |
| Dispatcher | 89 | 96 |
| Separate halt | 247 | 254 |
| Transition rows | 494 | 494 |

The tape is indexed by the integers, initially all zero, and the head starts at coordinate zero. Each row `state read write direction target` performs its write and move before entering the target. The final halting write and move are retained. There is exactly one halting transition.

After **741,241 literal transitions**, the machine reaches old state 96, head −5, marker −6, and header 245, with an empty program counter and distance 250. Its physical primary values are

```text
[0,0,0,3,0,0,3,0,0]
```

followed by **235 spare blocks of value one**. The complete tape has **487 one-cells** and is blank everywhere else. Its entire support is recorded in [results/bootstrap247.json](results/bootstrap247.json), and is checked by independent sparse and dense simulators using different state numberings.

The physical permutation yields the logical vector

```text
(N,T,W,A,D,H,X,Y,L) = (3,0,0,0,3,0,0,0,0).
```

Its formula fields are truth and its stack is empty. The existing `EnumSafeStart254.zero_formula_start_iff 0 3 3` applies through `L2.iter_iff` and the literal-program bisimulation. The more general `DirtyProgram254.six_nonformula_path_iff 3 0 3 0 0 0` gives a second route to the same native-refutation comparison. The inherited native/ZF/ZFC interpretation then supplies the consistency calibration.

## Reproduce

Use Python 3.10 or later with its standard library, from the extracted package root:

```sh
python3 -B code/verify.py
```

Do not use `-O` or `-OO`; assertions are part of the certificates. No network access, search, or dependency installation is required. The driver preserves `reference250/` and writes fresh records into `results/`. The recorded final run took approximately 15 seconds in the preparation environment.

The driver checks the inherited 252-to-250 reconstruction; the complete printed table; exact 250-to-247 construction and canonical numbering; the full dual bootstrap; four block induction theorems, three arithmetic macro contracts, and nine marking contracts; all **8,391 guarded cases** from all **6,460 leaves** and **6,459 nodes**; a separate full-source/full-counter audit; and finite regressions covering **33,564 instruction cases** and **16,200 arithmetic cases**. Every symbolic case has positive literal progress, with a minimum of 13 steps. Deleted-state access is explicitly rejected.

The word and list induction certificates establish the universal register statements. The symbolic certificates range over every nonnegative extra gap, every primary vector satisfying the selected guard, and every finite nonempty spare suffix. The literal regressions are additional finite error checks, not a proof of nonhalting. [results/verification-summary.json](results/verification-summary.json) records each executed stage.

A **separate source audit**, performed against the current repository pin, is retained in [results/current-source-audit.json](results/current-source-audit.json). The offline reproduction driver does not revisit GitHub or rebuild the inherited Lean dependency closure.

Build the report with:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

`make verify` and `make pdf` are shortcuts. The table source can be regenerated with `python3 -B code/build_table.py` and compared with `python3 -B code/build_table.py --check`.

## Package contents

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf` | New research article and complete canonical table; label prefix `p247:`. |
| `machine/` | Both exact machines, bijective renumbering, and generated TeX table. |
| `code/` | Construction, independent dual bootstrap, universal runtime checks, full-source audit, report-table checker, and reproduction driver. |
| `results/` | Fresh machine certificates, whole-tape support, regression records, independent reviews, and separate current-source audit. |
| `proof/` | Additional reduction proof, independent review notes, and an explicitly uncompiled logical Lean specialization. |
| `sources/` | Twelve current logical/interface source files and the ProveIt license. These are reference excerpts, not a self-contained Lean project. |
| `reference250/` | The complete earlier 250-state audit preserved unchanged, including its report, source, tests, attribution, and licenses. Its historical results concern 250 states. |
| `PROVENANCE.json` | Current pin, input sources, precise contribution, and verification boundaries. |

The new main report is a continuation of the supplied Prefix250 research. It can be incorporated with that research under ProveIt's established report-intake procedure. This delivery does not modify the remote repository.

## Attribution and exact identities

Current ProveIt revision: `e0b512a63e2c1ca6a1698fa437b8568f1643ff6b`. The preserved prior audit uses `80e26b89e905bf3e5dfc322befdc1c6eaf25a109`; the upstream `zf-254` snapshot is `c132d7eae8158cd3a9850ea3eb7251158c3dd821`.

Mira-Cult designed the original machine and compact calculus. Jeff Ketchersid supplied its verification. Andrew James Wade supplied the compiler framework. Mira-emmy's public 253-state reduction, ProveIt's register permutation and strict affine checks, and its inherited logical calibration retain their attribution. The prefix carry, rollback, spare invariant, and pulse initializer belong to the earlier 250-state work. This contribution supplies the selector reuse, three-state deletion, exact quotient, new blank startup, and the new-table proof and verification.

Canonical machine SHA-256:

```text
58bbbda620daf6d4d62f486db05f54d0dccb8373c080c1b5a0b26533e7a3a669
```

Original-label machine SHA-256:

```text
0d37614f3caf37139b0be127837630539224acd1c45d748cf5704abfc3230b42
```

The construction does not establish that 247 is minimal or claim worldwide priority. Under consistency it gives nonhalting and the usual nonprovability of nonhalting; full two-sided independence additionally requires a suitable soundness hypothesis, as explained in the article.
