# A verified 244-state ZFC consistency machine

**The requested bound is achieved.** `machine/zfc_compensated244.tm` is a
deterministic binary, one-tape Turing machine with **244 working states**,
including all initialization, and one separate halt state. Its blank-tape
nonhalting is provably equivalent in ZFC to `Con(ZFC)`.

The new contribution is an exact reduction of the maintained Routing245
machine. It changes four retained rows and deletes old state 122. A complete
local mathematical proof preserves halting from the same start state on
**every initial binary tape and at every head position**. Composing the
blank-tape specialization with Routing245's established calibration gives
the requested ZFC equivalence.

Read **report.pdf** for the complete construction, proof, verification
boundaries, formalism comparison, and full 488-row transition table. The
editable source is **report.tex**, with proof and table includes supplied.

## Machine identity

| Property | Value |
|---|---|
| Working states | 0 through 243 |
| Start | 0 |
| Initial head | 0 |
| Initial tape | All zero, two-way infinite |
| Alphabet | 0, 1 |
| Moves | L or R at every step |
| Halt | Target-only state 244 |
| Dispatcher | 88 |
| Transition rows | 488 |

Each noncomment row is `state read write direction next_state`.
`#! start 0` is metadata. The halt state has no rows.

The corresponding old-label table starts in state 95, uses dispatcher 96,
and halts at target 254. Canonical numbering puts 95 first and then all
remaining working states in increasing old-label order. The exact bijection
is `machine/renumbering.json`.

| Table | SHA-256 |
|---|---|
| Routing245, old labels | `f8dbeacdad5fd89c57e3f240781324b09110be8e0ccdb838a9c710fb28d2a267` |
| Compensated244, old labels | `d603bc3793ac9373f510a05d4e898f4ee7b4cac492821406a665554dca5c6daf` |
| Compensated244, canonical | `2ea5521fa7d0fc24b4f3dc07d497b10de2532147225820033d9c96f247444187` |

## Exact change to Routing245

Delete old state 122 and its two rows, then make exactly these changes:

| State/read | Old write, move, target | New write, move, target |
|---|---|---|
| 92/1 | `1 L 24` | `1 R 66` |
| 104/1 | `1 R 122` | `1 R 92` |
| 106/1 | `1 R 122` | `1 R 92` |
| 167/1 | `1 L 92` | `1 L 151` |

All other rows are unchanged. The 128 allocated grammar states remain;
the framework decreases from 117 to 116 states. The source program,
logical theory, and calibrated logical seed remain the baseline's.

## Proof in one page

Let a configuration be `(q,h,T)`. The old machine preserves:

- If `q` is 68, 122, or 167, then `T(h-1)=1`.
- If `q=81` and `T(h-1)=1`, then `T(h-2)=1`.

The complete incoming-edge inventory proves these assertions: incoming
transitions write the nearest 1, and entry into 81 either writes a 0 or
inherits a second 1 from state 68. The invariant holds vacuously at start 95
for every tape.

Use comparison boundaries at all states except 92 and 122. There are
482 identical ordinary one-step rows. Four exceptional entry rows split
into seven local cases:

| Entry / local context | Old steps | New steps | Common endpoint |
|---|---:|---:|---|
| 104/read 1, next bit 0 | 2 | 4 | `(25,h+2)` |
| 104/read 1, next bit 1 | 2 | 2 | `(66,h+2)` |
| 106/read 1, next bit 0 | 2 | 4 | `(25,h+2)` |
| 106/read 1, next bit 1 | 2 | 2 | `(66,h+2)` |
| 167/read 1, preceding bit 1 | 2 | 2 | `(24,h-2)` |
| 81/read 1, preceding bit 0 | 2 | 2 | `(107,h-2)` |
| 81/read 1, preceding bits 11 | 6 | 4 | `(2,h-2)` |

The entire endpoint tape agrees. Only the last case changes tape cells:
both computations erase precisely cells `h-1` and `h`. No outside cell is
read or written in any local calculation. Both block clocks are positive
and uniformly bounded, and no exceptional block visits halt. Induction
therefore proves both directions of halting equivalence.

For completed halting runs, if `A` counts the first/third types of blocks and
`B` counts the last type, then `t244 = t245 + 2A - 2B`, and
`(2/3)t245 <= t244 <= 2t245`.

## Reproduce the result

Use Python 3.10 or later with its standard library:

```sh
python3 -B verify.py
```

This runs both independent local checkers, exact table reconstruction,
independent sparse/dense blank initialization, an integrity check of the
archived complete runtime certificate, one portable symbolic case, the
equational packet verifier, and its artificial contradiction demonstration.
The full new local proof is checked anew; the single symbolic smoke case
is explicitly distinguished from a fresh all-cases run. New summaries are
written under `replay-results/`; archived certificates remain unchanged.

For an additional complete all-values runtime replay, allow several minutes:

```sh
python3 -B verify.py --full-runtime
```

The shortest independent audit of the state reduction alone is:

```sh
python3 -B runtime/verify_local_stuttering.py \
  runtime/reference/zfc245_old.tm \
  machine/zfc_compensated244_old.tm --output local-audit.json
```

Build the PDF with standard LaTeX packages:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

The Makefile provides `verify`, `full-runtime`, and `pdf` targets.
No network access or repository mutation is required.

## Verification completed for this delivery

| Check | Result |
|---|---|
| Direct finite invariant checker | 7,784 Boolean implications passed |
| Ordinary comparison rows | All 482 identical |
| Exceptional finite-window identities | All 7 passed |
| Independently written local checker | Passed, reading only the literal tables |
| Complete all-values runtime | 8,391 / 8,391 guarded cases passed |
| Symbolic rule count | 2,315,075 |
| Binary row coverage | 488 / 488 |
| Minimum positive instruction time | 13 steps |
| Blank startup | 407,951 exact steps |
| Independent sparse/dense tapes | Exact agreement on all cells |
| Equational packet | 21 equations, 2,324 complete bits, verified |

The blank prefix reaches the same complete root frame as Routing245:
head -5, marker -6, header 176, physical registers
`(0,0,0,3,0,0,3,0,0)`, 167 spare values all equal to 1, and 351 one-cells.
Every other tape cell is zero. This is a finite initialization check;
nonhalting follows through the mathematical calibration, not observation.

The all-values runtime checks arbitrary independent natural primary values,
an arbitrary header distance `D=64+n`, and any nonempty finite spare list. It uses checked
unary/list inductions and compares complete tape configurations. The separate
8,385 fixtures used during discovery are finite tests with a different scope.

## Proof status and baseline

The principal theorem is an ordinary mathematical proof with two independent
executable local checkers. The blank-tape local reduction is formalizable
arithmetically; it composes with the established Routing245 ZFC calibration.

The inspected baseline is ProveIt commit
`cb7984df14aed713269d5a596a27d33321cc2c19`:

- [Routing245 README](https://github.com/VladimirReshetnikov/ProveIt/blob/cb7984df14aed713269d5a596a27d33321cc2c19/Computability/BusyBeaver/Research/ZFC/candidate-routing245/README.md).
- [Closed external Lean endpoint description](https://github.com/VladimirReshetnikov/ProveIt/blob/cb7984df14aed713269d5a596a27d33321cc2c19/Computability/BusyBeaver/Research/ZFC/routing245_binary.md).
- [BinaryRouting245.lean](https://github.com/VladimirReshetnikov/ProveIt/blob/cb7984df14aed713269d5a596a27d33321cc2c19/Computability/BusyBeaver/Lean/BusyBeaver/ZFC/BinaryRouting245.lean).

The current external endpoint has closed halting/refutation and
nonhalting/consistency statements. It was inspected, not rebuilt here; its
historical compiler/provider requirements remain as documented. No new
244-state Lean or Rocq endpoint is claimed. The full internal PA calibration
is a separate inherited task. This delivery supplies no absolute consistency
proof, unconditional nonhalting theorem, or minimality claim.

## Alternative formalisms and search artifacts

The report compares the inherited native SIR/container calculus, the finite
FC13B presentation and its equality completion, an older cyclic algebraic
route, and the new direct equational conversion. The `equational/` directory
gives an explicit theorem: for a finite equality-free universal clause theory
`T` with a constant, `T` has a model exactly when the derived equational
theory has a nontrivial model, exactly when no finite ground contextual
rewrite connects its designated zero and one terms.

The supplied FC13B equality completion has 23 clauses and 57 literals.
The new output has 21 equations and 42 permitted orientations. Its complete
2,324-bit packet includes the signature, all equations, and ground endpoints.
This exceeds the inherited 1,499-bit clause payload; any eventual machine
saving needs a cheaper full equation-search compiler. No binary table or
additional state bound is asserted for this branch.

`runtime/` also contains the compensated-merge search source, its compressed
fixtures and logs, and two supplementary 244-state tables. All three variants
passed the complete runtime and blank-start checks. The direct all-tape proof
was independently reviewed for principal variant 1. The bounded search tried
6,032,656 repairs over 54 seeds; it is not an exhaustive lower-bound argument.

## Suggested integration and attribution

Suggested maintained destination:
`Computability/BusyBeaver/Research/ZFC/candidate-compensated244/`.
The main table, old-label companion, renumbering, proof, and this README can
anchor that intake. Preserve the full archive as the reproducible research
delivery. A natural next formalization is a short Lean stuttering wrapper
composed with `BinaryRouting245`, using the existing baseline endpoint.

Original calculus and proof search: **Mira-Cult**. Verification:
**Jeff Ketchersid**. Compiler framework: **Andrew James Wade**. ProveIt's
existing routing and prefix/permutation work retain their authorship.
Inherited notices and licenses appear under `runtime/reference/`.
The Boolean single axiom is the published Sh1 of McCune, Veroff, Fitelson,
Harris, Feist, and Wos. FC13B provenance appears in the equational input
manifest. The new compensated fold, its finite proof, local checks,
search extension, and equational experiment were prepared for this
investigation on 18 October 2026.
