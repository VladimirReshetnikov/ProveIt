# Report 27 — Exact sparse evaluation of the new two-involution CA

This release contains a standalone article (`report27.pdf` and its editable
LaTeX source `report27.tex`) and the complete executable research
packet, with scientific code and evidence frozen and four inert metadata files
adapted as disclosed below. It evaluates the NEW parallel rule on every finite support, without
an F-element template array or the old ordered cascade.

## What is established

- Exact equality to the eager new-rule interpreter on every finite support,
  forward and inverse, through complete type/anchor/orientation discovery
- All-type isolation within each E/P family, prospective preservation of all
  raw keys, and simultaneous endpoint rewrites from an unchanged block input
- At most n+2 raw-discovery calls per n-particle step, or 2n+4 with verification;
  these counts include probes that fail the prospective test
- Explicit operation, bit, and space bounds in particle count and expanded
  source/class metadata, not geometric coordinate span or an ordered F budget
- A source-sized metadata implementation whose class descriptors still require
  O((p+a)(J+2)^2) entries: no polynomial-in-log-J compilation claim

The prior full-shift two-involution/radius theorem and its admissible-state
preservation audits are reproduced unchanged. The old and new maps deliberately
differ on malformed inputs. The root scientific review is included unchanged
under `references/root-scientific-QA.json`; it reviews the frozen science, not
this later article or packaging.

## What was measured

The main suite uses 8,183 configurations over 10 sources, with 16,366 comparisons
or checks in each major raw-map/selection/output/step category. The independent
candidate audit checks 17,504 contained endpoints and 1,120 full raw maps.
The frozen 32,034,272-byte universal source has 122,622 controls and
269,291,358,255 symbolic endpoint types. The new evaluator performs 128 literal
startup steps and 128 malformed endpoint/noise cases, normally and optimized.
These do not complete the long startup, a whole Turing-machine step, or a halt.
No eager universal oracle, new Diophantine compiler, arithmetic gate count,
radius minimality, or novelty claim is provided.

## Full portable offline replay

Requirements: Linux, Python 3.10 or newer, standard library only, and a
filesystem/user policy permitting symlink creation for negative tests. The
benchmark imports `resource`; peak RSS is interpreted in Linux KiB. The exact
interpreter tested is recorded in the replay receipt. Allow around 370 MiB peak
benchmark memory with extra headroom; the replay limits each subprocess to
2 GiB virtual memory. No network or sibling release directory is needed.

From this extracted directory:

    python3 -B verify_release.py
    python3 -B release_checks.py
    python3 -B replay.py --output /tmp/report27-fresh-replay

The output path must not already exist and must be outside the release. Leaving
out `--output` creates a fresh external temporary directory. `replay.py` first
checks the seal and all mandatory source pins, then runs each of the three
scientific suites normally and under `-O`, in six fresh relocated release
copies. It also runs integrity and tamper checks in both modes. Outputs and logs
are external; no bytecode is written. Scientific subprocesses use isolated
Python with site packages disabled and a network audit guard.

The replay checks the full file/directory inventory, bytes, modes and nanosecond
modification times after every subprocess on original and copied releases.
Receipt comparison is type-sensitive. Only declared timing/RSS fields and
validated known optimization flags are normalized; all hash/count/trace fields
remain exact. Universal trace files must be byte-identical to the producer.
The final receipt is `<output>/replay-receipt.json` and is intentionally outside
the seal, so replay cannot mutate or silently reseal the delivered package.

The full release has exactly 56 files, including the two outer seal files, and
two subdirectories. Every scientific file, including the large universal JSON,
is mandatory. `source-pins.json` mirrors compiled-in pins in the verifier;
editing both the outer manifest and its digest cannot override those pins.
The tamper suite deletes every mandatory file, changes/reseals each pinned
source, probes malformed manifests/pins/paths, symlinks and nonregular files,
checks semantic receipt corruption, and verifies output/invariance detection.
A byte-level privacy check rejects known internal absolute-path prefixes
in delivered files; public /tmp examples and relative provenance are allowed.
The seal establishes internal consistency, not authenticity against replacing
the verifier and all pins together. Use the externally delivered hashes as the
reference for authenticity/integrity of the delivered archive.

## Individual scientific suites

For a targeted check, choose an external output directory:

    python3 -B scientific/verify_bundle.py
    python3 -B scientific/test_sparse_parallel.py --output-dir /tmp/report27-tests
    python3 -B -O scientific/test_sparse_parallel.py --output-dir /tmp/report27-tests
    python3 -B scientific/audit_candidate_completeness.py --output-dir /tmp/report27-tests
    python3 -B -O scientific/audit_candidate_completeness.py --output-dir /tmp/report27-tests
    python3 -B scientific/benchmark_universal.py --output-dir /tmp/report27-tests
    python3 -B -O scientific/benchmark_universal.py --output-dir /tmp/report27-tests

The first two suites do not parse the universal source, but full integrity
verification reads it and the complete release never treats it as optional.
Main-suite runs were about a minute each on the producing machine. Timings are
observations, not guarantees.

## Supported execution API

Import `SparseParallelCompiler` from the adjacent scientific module and create
`a = SparseParallelCompiler(source_dict)`. Call `a.step(X)` or
`a.step(X, inverse=True)`. Set `verify=True` for the checks described above and
`trace=True` for immutable block/step trace records. `a.E` and `a.P` expose
candidates, eligibility, application and local output; `a.gate_at(i)` materializes
one type by global E-then-P ID. IDs name types, not an ordered execution schedule.

IMPORTANT: `a.metadata.step` belongs to the inherited OLD ordered evaluator.
Only the enclosing `a.step` evaluates the new CA. Inherited documents retain
older names and API descriptions; `scientific/README.md`, `PROOF.md`, and the
article specify this release's supported API and boundaries.

Inputs are exact built-in set/frozenset collections of exact integers; flags are
exact Booleans. Empty supports and arbitrarily signed/large coordinates are
valid. Validation survives Python optimization. Compiled records, source
snapshots, returned maps and traces are immutable through ordinary operations.
`ledger()` returns a fresh mutable dictionary that cannot alter compiler state.

## Article build and QA

The PDF is already built. Scientific replay requires no TeX installation.
To rebuild it separately with a local pdfLaTeX/Latin Modern installation:

    sh build.sh

The build uses a temporary directory and disables shell escape, copying only
`report27.pdf` into this release. This is an authoring operation that invalidates
the seal; review the changed PDF before explicitly running `write_manifest.py`.
Never use resealing to suppress a failed source-pin check. The article's
rendered-page inspection, provenance and scientific pins are recorded in
`report27-qa.json` and `delivery-provenance.json`.

## Publication metadata adaptations

The scientific subtree still contains exactly 39 files. All scientific code,
data, proofs, tests, and benchmark receipts remain unchanged. Exactly four inert
metadata files differ from the source packet:

- `scientific/PROVENANCE.json`: absolute machine-local origin paths are replaced
  with stable relative packet/file identifiers; artifact byte hashes are unchanged
- `scientific/audit-timings.json`: the two interpreter-path strings are normalized
  to `python3`; every command flag, output argument, and measured value is unchanged
- `scientific/manifest.json`: regenerated for those two metadata adaptations
- `scientific/SHA256SUMS`: regenerated from the published manifest

The other 35 scientific files retain their original bytes, modes, and mtimes.
No executable scientific semantics changed. The original source packet remains
untouched. The archived root scientific QA describes that original packet and
remains unchanged; it does not claim to review later publication metadata.

`references/` holds the prior-art audit, Report 26 provenance, root scientific
review, and the byte-identical original scientific manifest. Both source and
published manifests are pinned, so their roles are explicit:

Original scientific manifest SHA-256:
311e6293d0b28528b63e8f9e0eadd1a4fa91d7dc5c1b208c3e2654be37cdd7fa

Published adapted scientific manifest SHA-256:
5672555af673f129c52aed9317c4d0c68b3c31fbd926952aae385e4ab32c8528
