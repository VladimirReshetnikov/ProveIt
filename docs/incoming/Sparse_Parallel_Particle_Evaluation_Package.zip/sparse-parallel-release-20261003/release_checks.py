"""Adversarial release/receipt tests, entirely in disposable external copies.

Run only after sealing: python3 -B release_checks.py (also python3 -O -B).
This imports packaging helpers, never any scientific evaluator. Checks raise
explicit exceptions and therefore remain active under optimized Python.
"""
import sys
sys.dont_write_bytecode = True
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile

from verify_release import (
    ROOT, MANIFEST, DIGEST, SOURCE_PINS, RELEASE_FILES, MAX_FILE_BYTES,
    check_private_paths, load_json, ordinary_directory, require, verify,
)
from replay import (
    SUITES, NONDETERMINISTIC_FIELDS, compare_receipts, prepare_output,
    receipt_name, snapshot,
)


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def manifest_bytes(root, raw):
    """Recompute the outer seal deliberately, without trusting the manifest."""
    (root / MANIFEST).write_bytes(raw)
    (root / DIGEST).write_text(sha256(raw).hexdigest() + '  ' + MANIFEST + '\n',
                               encoding='ascii')


def edit_manifest(root, change):
    data = load_json((root / MANIFEST).read_bytes())
    change(data)
    manifest_bytes(root, (json.dumps(data, indent=2) + '\n').encode('utf-8'))


def refresh_record(root, name):
    raw = (root / name).read_bytes()
    edit_manifest(root, lambda data: data['files'].__setitem__(
        name, {'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}))


def edit_pins(root, change):
    path = root / 'source-pins.json'
    data = load_json(path.read_bytes())
    change(data)
    write_json(path, data)
    refresh_record(root, 'source-pins.json')


class Checks:
    def __init__(self, root, temporary):
        self.root = root
        self.temporary = temporary
        self.rejected = []
        self.positive = []

    def reject_action(self, name, action, expected):
        try:
            action()
        except ValueError as error:
            require(expected in str(error),
                    name + ': wrong rejection reason: ' + str(error))
        else:
            raise RuntimeError(name + ': tampering was accepted')
        self.rejected.append(name)

    def reject_copy(self, name, change, expected):
        with tempfile.TemporaryDirectory(prefix='case-', dir=self.temporary) as directory:
            parent = Path(directory)
            copied = parent / 'release'
            shutil.copytree(self.root, copied)
            alternate = change(copied, parent)
            target = copied if alternate is None else alternate
            self.reject_action(name, lambda: verify(target), expected)

    def manifest(self, name, change, expected):
        def mutate(root, parent):
            edit_manifest(root, change)
        self.reject_copy(name, mutate, expected)


def integrity_checks(checks):
    # Each mandatory name is independently deleted from a clean relocated copy.
    # This includes the 32 MB fixture, every one of the 39 scientific files,
    # every packaging/reference file, and both outer seal files.
    for name in sorted(RELEASE_FILES | {MANIFEST, DIGEST}):
        def remove(root, parent, name=name):
            (root / name).unlink()
        reason = 'missing final seal' if name in (MANIFEST, DIGEST) else 'actual file inventory mismatch'
        checks.reject_copy('missing:' + name, remove, reason)

    def add_file(root, parent):
        (root / 'unexpected.txt').write_text('unexpected\n')
    checks.reject_copy('extra-file', add_file, 'actual file inventory mismatch')
    checks.reject_copy('extra-empty-directory', lambda root, parent: (root / 'extra').mkdir(),
                       'actual directory inventory mismatch')
    def remove_directory(root, parent):
        shutil.rmtree(root / 'references')
    checks.reject_copy('missing-directory', remove_directory, 'actual file inventory mismatch')

    def file_link(root, parent):
        path = root / 'README.md'
        content = path.read_bytes()
        path.unlink()
        (parent / 'same-content').write_bytes(content)
        path.symlink_to(parent / 'same-content')
    checks.reject_copy('file-symlink-same-bytes', file_link, 'symlink rejected')
    def directory_link(root, parent):
        (root / 'references').rename(parent / 'real-references')
        (root / 'references').symlink_to(parent / 'real-references', target_is_directory=True)
    checks.reject_copy('directory-symlink', directory_link, 'symlink rejected')
    def root_link(root, parent):
        (parent / 'linked-root').symlink_to(root, target_is_directory=True)
        return parent / 'linked-root'
    checks.reject_copy('root-symlink', root_link, 'directory path is not ordinary')
    def ancestor_link(root, parent):
        (parent / 'linked-parent').symlink_to(parent, target_is_directory=True)
        return parent / 'linked-parent' / 'release'
    checks.reject_copy('ancestor-symlink', ancestor_link, 'directory path is not ordinary')
    checks.reject_copy('root-parent-traversal', lambda root, parent: root / '..' / 'release',
                       'parent traversal in directory path')
    def fifo(root, parent):
        os.mkfifo(root / 'unexpected-fifo')
    checks.reject_copy('nonregular-fifo', fifo, 'nonregular file rejected')
    def unsafe_actual_name(root, parent):
        (root / 'bad name').write_bytes(b'')
    checks.reject_copy('unsafe-actual-filename', unsafe_actual_name, 'unsafe path characters')

    def altered_file(root, parent):
        with (root / 'README.md').open('ab') as stream:
            stream.write(b'altered\n')
    checks.reject_copy('changed-unsealed-file', altered_file, 'changed release file')
    def altered_manifest(root, parent):
        with (root / MANIFEST).open('ab') as stream:
            stream.write(b' ')
    checks.reject_copy('altered-manifest-with-old-digest', altered_manifest, 'manifest digest mismatch')
    def altered_digest(root, parent):
        (root / DIGEST).write_text('0' * 64 + '  ' + MANIFEST + '\n')
    checks.reject_copy('altered-digest', altered_digest, 'manifest digest mismatch')
    def digest_wrong_name(root, parent):
        raw = (root / MANIFEST).read_bytes()
        (root / DIGEST).write_text(sha256(raw).hexdigest() + '  other.json\n')
    checks.reject_copy('digest-wrong-filename', digest_wrong_name, 'manifest digest mismatch')

    # Test every fixed source dependency against an attacker who can recompute
    # the delivery manifest and its digest. The compiled-in pins must still win.
    for name in sorted(SOURCE_PINS):
        def change_pinned(root, parent, name=name):
            with (root / name).open('ab') as stream:
                stream.write(b'\n')
            refresh_record(root, name)
        checks.reject_copy('changed-pinned-and-resealed:' + name, change_pinned,
                           'mandatory dependency pin mismatch')

    cases = (
        ('manifest-wrong-schema', lambda d: d.__setitem__('schema', 'wrong'), 'release manifest schema'),
        ('manifest-extra-key', lambda d: d.__setitem__('extra', None), 'release manifest shape'),
        ('manifest-missing-schema', lambda d: d.pop('schema'), 'release manifest shape'),
        ('manifest-files-list', lambda d: d.__setitem__('files', []), 'manifest entries must be an object'),
        ('manifest-missing-universal-record', lambda d: d['files'].pop('scientific/universal-source.json'),
         'manifest exact mandatory file inventory mismatch'),
        ('manifest-directories-null', lambda d: d.__setitem__('directories', None),
         'manifest exact directory inventory mismatch'),
        ('manifest-directories-reversed', lambda d: d['directories'].reverse(),
         'manifest exact directory inventory mismatch'),
        ('manifest-directories-duplicate', lambda d: d['directories'].append(d['directories'][0]),
         'manifest exact directory inventory mismatch'),
        ('manifest-directories-missing', lambda d: d['directories'].pop(),
         'manifest exact directory inventory mismatch'),
        ('manifest-entry-extra-key', lambda d: d['files']['README.md'].__setitem__('extra', 1),
         'manifest entry shape'),
        ('manifest-entry-list', lambda d: d['files'].__setitem__('README.md', []), 'manifest entry shape'),
    )
    for name, change, expected in cases:
        checks.manifest(name, change, expected)
    for label, value in (('boolean', True), ('float', 1.0), ('negative', -1),
                         ('oversized', MAX_FILE_BYTES + 1), ('string', '1'), ('null', None)):
        checks.manifest('manifest-invalid-bytes-' + label,
                        lambda d, value=value: d['files']['README.md'].__setitem__('bytes', value),
                        'invalid manifest byte count')
    for label, value in (('uppercase', 'A' * 64), ('short', '0' * 63),
                         ('nonhex', 'x' * 64), ('number', 0)):
        checks.manifest('manifest-invalid-sha256-' + label,
                        lambda d, value=value: d['files']['README.md'].__setitem__('sha256', value),
                        'invalid manifest SHA-256')
    for name in ('', '/absolute', '../escape', 'a/../escape', './relative', 'a//b',
                 'a/', 'bad\\name', 'bad name'):
        def unsafe_key(data, name=name):
            data['files'][name] = data['files'].pop('README.md')
        checks.manifest('unsafe-manifest-path:' + repr(name), unsafe_key,
                        'invalid path type or empty path' if not name else 'unsafe')
    for token in ('NaN', 'Infinity', '-Infinity'):
        def nonfinite(root, parent, token=token):
            raw = (root / MANIFEST).read_bytes()
            raw = raw.replace(b'"bytes": ', ('"bytes": ' + token + ', "discard": ').encode(), 1)
            manifest_bytes(root, raw)
        checks.reject_copy('manifest-nonfinite:' + token, nonfinite, 'nonfinite JSON number')
    for label, old, new in (
        ('top-level', b'"schema": ', b'"schema": "duplicate", "schema": '),
        ('entry', b'"bytes": ', b'"bytes": 0, "bytes": '),
    ):
        def duplicate(root, parent, old=old, new=new):
            manifest_bytes(root, (root / MANIFEST).read_bytes().replace(old, new, 1))
        checks.reject_copy('manifest-duplicate-key-' + label, duplicate, 'duplicate JSON key')
    for raw in (b'null', b'[]', b'{}'):
        def bad_shape(root, parent, raw=raw):
            manifest_bytes(root, raw)
        checks.reject_copy('manifest-invalid-top-level:' + raw.decode(), bad_shape, 'release manifest shape')

    for label, change, expected in (
        ('omission', lambda d: d['files'].pop('scientific/universal-source.json'), 'mandatory source pin set/value mismatch'),
        ('value-change', lambda d: d['files'].__setitem__('scientific/sparse_parallel.py', '0' * 64), 'mandatory source pin set/value mismatch'),
        ('addition', lambda d: d['files'].__setitem__('extra', '0' * 64), 'mandatory source pin set/value mismatch'),
        ('list', lambda d: d.__setitem__('files', []), 'mandatory source pin set/value mismatch'),
        ('schema', lambda d: d.__setitem__('schema', 'wrong'), 'source pin schema'),
        ('extra-key', lambda d: d.__setitem__('extra', True), 'source pin manifest shape'),
    ):
        def mutate(root, parent, change=change):
            edit_pins(root, change)
        checks.reject_copy('source-pins-' + label + '-resealed', mutate, expected)
    def duplicate_pin(root, parent):
        path = root / 'source-pins.json'
        path.write_bytes(path.read_bytes().replace(b'"schema": ', b'"schema": "duplicate", "schema": ', 1))
        refresh_record(root, 'source-pins.json')
    checks.reject_copy('source-pins-duplicate-key-resealed', duplicate_pin, 'duplicate JSON key')
    def forged_source_and_pin(root, parent):
        name = 'scientific/sparse_parallel.py'
        with (root / name).open('ab') as stream:
            stream.write(b'\n')
        refresh_record(root, name)
        digest = sha256((root / name).read_bytes()).hexdigest()
        edit_pins(root, lambda data: data['files'].__setitem__(name, digest))
    checks.reject_copy('source-and-pin-forged-together-resealed', forged_source_and_pin,
                       'mandatory source pin set/value mismatch')


def privacy_checks(checks):
    # Construct forbidden prefixes so the delivered test source is itself clean.
    # Recompute the README record and seal to exercise privacy independently of
    # the ordinary changed-file check. These cases do not alter source pins.
    for components in (('workspace',), ('home', 'agent'), ('root',), ('opt', 'codex')):
        prefix = '/' + '/'.join(components) + '/'
        def private_path(root, parent, prefix=prefix):
            with (root / 'README.md').open('ab') as stream:
                stream.write(('\nPrivate origin: ' + prefix + 'private-build/input.json\n').encode('utf-8'))
            refresh_record(root, 'README.md')
        checks.reject_copy('private-path-resealed:' + '-'.join(components), private_path,
                           'private absolute path rejected: README.md')

    # Public temporary-directory examples and relative provenance remain valid,
    # both in the standalone scanner and in a completely resealed release.
    clean = (b'Public example: /tmp/report27-fresh-replay\n'
             b'Relative provenance: reports/report26/scientific/PROVENANCE.json\n'
             b'Adjacent provenance: ../report26/scientific/source.json\n')
    with tempfile.TemporaryDirectory(prefix='privacy-', dir=checks.temporary) as directory:
        root = Path(directory)
        (root / 'README.md').write_bytes(clean)
        result = check_private_paths(root)
        require(result['privacy_files_scanned'] == 1 and
                result['private_absolute_paths_absent'] is True, 'clean path examples rejected')
        checks.positive.append('public-tmp-and-relative-provenance-paths')
        binary = root / 'opaque.bin'
        binary.write_bytes(b'\xff\x00' + clean + b'\x80')
        require(check_private_paths(root)['privacy_files_scanned'] == 2,
                'binary file not scanned')
        checks.positive.append('clean-binary-file-scanned')
        for components in (('workspace',), ('home', 'agent'), ('root',), ('opt', 'codex')):
            prefix = ('/' + '/'.join(components) + '/').encode('ascii')
            binary.write_bytes(b'\xff\x00' + prefix + b'private-build/input.json\x80')
            checks.reject_action('private-path-binary:' + '-'.join(components),
                                 lambda: check_private_paths(root),
                                 'private absolute path rejected: opaque.bin')

    with tempfile.TemporaryDirectory(prefix='privacy-copy-', dir=checks.temporary) as directory:
        copied = Path(directory) / 'release'
        shutil.copytree(checks.root, copied)
        with (copied / 'README.md').open('ab') as stream:
            stream.write(b'\n' + clean)
        refresh_record(copied, 'README.md')
        result = verify(copied)
        require(result['private_absolute_paths_absent'] is True,
                'resealed clean path examples not scanned')
        checks.positive.append('public-tmp-and-relative-provenance-resealed')


def receipt_checks(checks):
    outputs = {}
    for optimized in (False, True):
        for suite in SUITES:
            output = checks.temporary / ('receipts-' + Path(suite).stem + '-' + str(optimized))
            output.mkdir()
            outputs[suite, optimized] = output
            name = receipt_name(suite, optimized)
            shutil.copy2(checks.root / 'scientific' / name, output / name)
        for kind in ('startup', 'malformed'):
            name = 'universal-' + kind + '-trace' + ('-optimized' if optimized else '') + '.json'
            shutil.copy2(checks.root / 'scientific' / name,
                         outputs['benchmark_universal.py', optimized] / name)
    compare_receipts(checks.root, outputs)
    checks.positive.append('all-producer-receipts-and-traces')

    def altered(name, suite, optimized, change, expected=None):
        path = outputs[suite, optimized] / receipt_name(suite, optimized)
        raw = path.read_bytes()
        data = load_json(raw)
        change(data)
        write_json(path, data)
        try:
            if expected is None:
                compare_receipts(checks.root, outputs)
                checks.positive.append(name)
            else:
                checks.reject_action(name, lambda: compare_receipts(checks.root, outputs), expected)
        finally:
            path.write_bytes(raw)

    for suite in SUITES:
        for optimized in (False, True):
            suffix = ':' + suite + ':' + str(optimized)
            def all_machine_fields(data):
                for field in NONDETERMINISTIC_FIELDS[suite]:
                    data[field] = 123456 if field == 'peak_rss_kib' else 123456.25
            altered('declared-machine-fields-only' + suffix, suite, optimized, all_machine_fields)
            altered('receipt-unexpected-field' + suffix, suite, optimized,
                    lambda d: d.__setitem__('arbitrary_seconds', 1.5), 'semantic receipt differs from producer')
            altered('receipt-failed-status' + suffix, suite, optimized,
                    lambda d: d.__setitem__('status', 'failed'), 'receipt did not pass')
            if suite != 'benchmark_universal.py':
                for value in (not optimized, int(optimized), None):
                    altered('receipt-wrong-mode' + suffix + ':' + repr(value), suite, optimized,
                            lambda d, value=value: d.__setitem__('optimized', value),
                            'receipt optimization mode mismatch')
                altered('receipt-missing-mode' + suffix, suite, optimized,
                        lambda d: d.pop('optimized'), 'receipt optimization mode mismatch')
            else:
                altered('benchmark-extra-mode' + suffix, suite, optimized,
                        lambda d: d.__setitem__('optimized', optimized), 'unexpected benchmark optimization field')
            for field in NONDETERMINISTIC_FIELDS[suite]:
                altered('missing-machine-field' + suffix + ':' + field, suite, optimized,
                        lambda d, field=field: d.pop(field), 'missing declared timing/RSS field')
                for value in (True, -1, '1', None):
                    altered('invalid-machine-field' + suffix + ':' + field + ':' + repr(value), suite, optimized,
                            lambda d, field=field, value=value: d.__setitem__(field, value),
                            'invalid timing/RSS field')
                for value in (float('nan'), float('inf'), -float('inf')):
                    altered('nonfinite-machine-field' + suffix + ':' + field + ':' + repr(value), suite, optimized,
                            lambda d, field=field, value=value: d.__setitem__(field, value), 'nonfinite JSON number')
    for optimized in (False, True):
        suite = 'test_sparse_parallel.py'
        altered('scientific-count-changed:' + str(optimized), suite, optimized,
                lambda d: d['counts'].__setitem__('configurations', 8184), 'semantic receipt differs from producer')
        altered('scientific-boolean-number-substitution:' + str(optimized), suite, optimized,
                lambda d: d['counts'].__setitem__('no_eager_runtime_checks', True),
                'semantic receipt differs from producer')
        altered('nested-timing-name-is-semantic:' + str(optimized), suite, optimized,
                lambda d: d['counts'].__setitem__('elapsed_seconds', 1.5), 'semantic receipt differs from producer')
        for value in (0, 1.5):
            altered('rss-positive-integer-required:' + str(optimized) + ':' + str(value),
                    'benchmark_universal.py', optimized,
                    lambda d, value=value: d.__setitem__('peak_rss_kib', value), 'invalid Linux RSS measurement')
        for kind in ('startup', 'malformed'):
            name = 'universal-' + kind + '-trace' + ('-optimized' if optimized else '') + '.json'
            path = outputs['benchmark_universal.py', optimized] / name
            raw = path.read_bytes()
            path.write_bytes(raw + b' ')
            try:
                checks.reject_action('trace-byte-difference:' + name,
                                     lambda: compare_receipts(checks.root, outputs), 'universal trace bytes differ')
            finally:
                path.write_bytes(raw)


def output_and_invariance_checks(checks):
    copied = checks.temporary / 'output-policy-release'
    shutil.copytree(checks.root, copied)
    for name, path, reason in (
        ('output-equals-release', copied, 'output must be outside release'),
        ('output-inside-release', copied / 'new-output', 'output must be outside release'),
        ('output-already-exists', checks.temporary, 'output already exists'),
        ('output-parent-traversal', checks.temporary / 'missing' / '..' / 'new', 'parent traversal in output path'),
    ):
        checks.reject_action(name, lambda path=path: prepare_output(path, copied), reason)
    linked = checks.temporary / 'output-link'
    linked.symlink_to(copied, target_is_directory=True)
    checks.reject_action('output-symlink', lambda: prepare_output(linked, copied), 'symlink output path rejected')
    checks.reject_action('output-symlink-ancestor', lambda: prepare_output(linked / 'new', copied),
                         'directory path is not ordinary')
    output = prepare_output(checks.temporary / 'valid-output', copied)
    require(output.is_dir() and copied not in output.parents, 'valid external output failed')
    checks.positive.append('new-external-output-accepted')
    before = snapshot(copied)
    require(before == snapshot(checks.root), 'fresh relocated copy differs')
    checks.positive.append('fresh-relocated-copy-identical')
    for name, path, what in (
        ('file-mode', copied / 'README.md', 'mode'),
        ('directory-mode', copied / 'references', 'mode'),
        ('root-mode', copied, 'mode'),
        ('file-mtime', copied / 'README.md', 'mtime'),
        ('directory-mtime', copied / 'references', 'mtime'),
        ('root-mtime', copied, 'mtime'),
    ):
        info = path.stat()
        if what == 'mode':
            # Toggle group-write, preserving traversal permission on directories.
            path.chmod(stat.S_IMODE(info.st_mode) ^ stat.S_IWGRP)
        else:
            os.utime(path, ns=(info.st_atime_ns, info.st_mtime_ns + 1000000000))
        require(snapshot(copied) != before, name + ': invariance snapshot missed alteration')
        path.chmod(stat.S_IMODE(info.st_mode))
        os.utime(path, ns=(info.st_atime_ns, info.st_mtime_ns))
        require(snapshot(copied) == before, name + ': fixture restoration failed')
        checks.positive.append('snapshot-detects-' + name)


def main(root=ROOT):
    root = ordinary_directory(root)
    integrity = verify(root)
    before = snapshot(root)
    parent = ordinary_directory(tempfile.gettempdir())
    require(parent != root and root not in parent.parents, 'test temporary directory lies inside release')
    with tempfile.TemporaryDirectory(prefix='report27-checks-', dir=parent) as directory:
        checks = Checks(root, Path(directory))
        integrity_checks(checks)
        privacy_checks(checks)
        receipt_checks(checks)
        output_and_invariance_checks(checks)
        require(snapshot(root) == before, 'original release inventory, bytes, modes or mtimes changed')
        verify(root)
        result = {
            'status': 'PASS', 'optimized': bool(sys.flags.optimize),
            'integrity': integrity,
            'negative_checks': len(checks.rejected), 'positive_checks': len(checks.positive),
            'rejected_cases': checks.rejected, 'positive_cases': checks.positive,
            'original_release_unchanged': True,
            'invariance_fields': ['inventory', 'bytes', 'file and directory modes', 'mtime_ns'],
            'scientific_evaluators_imported': False,
            'mutations_confined_to_external_temporary_copies': True,
        }
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    arguments = parser.parse_args()
    main(arguments.root)
