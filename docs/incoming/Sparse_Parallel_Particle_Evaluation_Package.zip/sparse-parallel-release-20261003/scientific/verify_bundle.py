"""Verify packet byte inventory without importing evaluators or mutating files."""
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    manifest = json.loads((HERE/'manifest.json').read_text())
    entries = manifest['files']
    for name, record in entries.items():
        path = HERE/name
        if path.parent != HERE or not path.is_file():
            raise RuntimeError('Missing or unsafe inventory path: '+name)
        raw = path.read_bytes()
        if len(raw) != record['bytes'] or sha256(raw).hexdigest() != record['sha256']:
            raise RuntimeError('Inventory mismatch: '+name)
    expected = ''.join(record['sha256']+'  '+name+'\n'
                       for name,record in sorted(entries.items()))
    if (HERE/'SHA256SUMS').read_text() != expected:
        raise RuntimeError('SHA256SUMS differs from manifest')
    print(json.dumps(dict(status='passed',files=len(entries),
                          bytes=sum(v['bytes'] for v in entries.values()))))


if __name__ == '__main__':
    main()
