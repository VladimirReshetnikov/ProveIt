"""Explicitly seal a completed Report 27 release; never called by replay."""
import sys
sys.dont_write_bytecode = True
import argparse
from hashlib import sha256
import json
from pathlib import Path
from verify_release import ROOT, MANIFEST, DIGEST, manifest_data, verify


def main(root=ROOT):
    root = Path(root).absolute()
    data = manifest_data(root)
    raw = (json.dumps(data, indent=2) + '\n').encode('utf-8')
    (root / MANIFEST).write_bytes(raw)
    (root / DIGEST).write_text(sha256(raw).hexdigest() + '  ' + MANIFEST + '\n', encoding='ascii')
    print(json.dumps(verify(root), indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    arguments = parser.parse_args()
    main(arguments.root)
