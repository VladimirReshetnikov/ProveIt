"""Replay all three frozen suites normally and optimized in six fresh copies.

Requires Linux, Python 3.10+, and a symlink-capable filesystem.
The tested interpreter is recorded in the replay receipt.
Usage: python3 -B replay.py --output NEW_EXTERNAL_DIRECTORY
No scientific evaluator is imported before inventory and source pins pass.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import ast
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from verify_release import ROOT, require, inventory, verify, load_json, ordinary_directory

SUITES = ('test_sparse_parallel.py', 'audit_candidate_completeness.py', 'benchmark_universal.py')
NONDETERMINISTIC_FIELDS = {
    'test_sparse_parallel.py': ('elapsed_seconds',),
    'audit_candidate_completeness.py': (),
    'benchmark_universal.py': ('compile_seconds', 'startup_seconds', 'malformed_seconds',
                               'total_seconds', 'peak_rss_kib'),
}
BOOTSTRAP = r'''
import sys, runpy, resource
from pathlib import Path
sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_CPU, (600, 600))
resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
def offline_audit(event, args):
    if event.startswith('socket.') or event == 'urllib.Request':
        raise RuntimeError('Replay forbids network activity: ' + event)
sys.addaudithook(offline_audit)
script = Path(sys.argv[1]).resolve()
sys.argv = [str(script)] + sys.argv[2:]
sys.path.insert(0, str(script.parent))
runpy.run_path(str(script), run_name='__main__')
'''


def prepare_output(output, root=ROOT):
    root = ordinary_directory(root)
    if output is None:
        parent = ordinary_directory(tempfile.gettempdir())
        require(parent != root and root not in parent.parents, 'temporary output lies within release')
        return Path(tempfile.mkdtemp(prefix='report27-replay-', dir=parent))
    path = Path(output).expanduser().absolute()
    require('..' not in path.parts, 'parent traversal in output path')
    ordinary_directory(path.parent)
    require(not path.is_symlink(), 'symlink output path rejected')
    require(path != root and root not in path.parents, 'output must be outside release')
    require(not path.exists(), 'output already exists')
    path.mkdir()
    return path


def snapshot(root):
    root = Path(root)
    files, directories = inventory(root)
    records = {}
    for name, path in files.items():
        info = path.stat()
        records[name] = (info.st_size, sha256(path.read_bytes()).hexdigest(),
                         info.st_mode, info.st_mtime_ns)
    dirs = {name: ((root / name).stat().st_mode, (root / name).stat().st_mtime_ns)
            for name in directories}
    info = root.stat()
    return records, dirs, (info.st_mode, info.st_mtime_ns)


def check_runtime_dependencies(root):
    require(sys.version_info >= (3, 10), 'Python 3.10 or newer is required')
    require(sys.platform.startswith('linux'), 'Full frozen replay requires Linux (resource/RSS semantics)')
    files, unused = inventory(root)
    local = {Path(name).stem for name in files if name.endswith('.py')}
    imports = set()
    for name, path in files.items():
        if not name.endswith('.py'):
            continue
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'), filename=name)):
            if isinstance(node, ast.Import):
                imports.update(alias.name.split('.')[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                require(node.level == 0, 'relative code import is not allowed')
                imports.add((node.module or '').split('.')[0])
    require(imports <= sys.stdlib_module_names | local, 'non-standard-library dependency found')
    return sorted(imports - local)


def run_script(root, script, optimized, log, output=None):
    command = [sys.executable, '-I', '-S', '-B'] + (['-O'] if optimized else [])
    command += ['-c', BOOTSTRAP, str(root / script)]
    if output is not None:
        command += ['--output-dir', str(output)]
    environment = {key: value for key, value in os.environ.items() if not key.startswith('PYTHON')}
    environment.update(TMPDIR=str(log.parent), LC_ALL='C', TZ='UTC')
    started = time.monotonic()
    with log.open('wb') as stream:
        done = subprocess.run(command, cwd=log.parent, env=environment,
                              stdout=stream, stderr=subprocess.STDOUT, timeout=900)
    require(done.returncode == 0, 'script failed: ' + script + '; see ' + str(log))
    return {'script': script, 'optimized': optimized, 'returncode': done.returncode,
            'seconds': round(time.monotonic() - started, 3),
            'log': str(log), 'isolated': True, 'site_packages_disabled': True,
            'network_audit_guard': True}


def receipt_name(suite, optimized):
    suffix = '-optimized' if optimized else ''
    if suite == 'test_sparse_parallel.py':
        return 'test-sparse-parallel' + suffix + '-receipt.json'
    if suite == 'audit_candidate_completeness.py':
        return 'audit-candidate-receipt' + suffix + '.json'
    require(suite == 'benchmark_universal.py', 'unknown suite')
    return 'universal-receipt' + suffix + '.json'


def semantic_receipt(path, suite, optimized):
    data = load_json(Path(path).read_bytes())
    require(type(data) is dict and data.get('status') == 'passed', 'receipt did not pass')
    if suite in ('test_sparse_parallel.py', 'audit_candidate_completeness.py'):
        require(type(data.get('optimized')) is bool and data['optimized'] == optimized,
                'receipt optimization mode mismatch')
        del data['optimized']
    else:
        require('optimized' not in data, 'unexpected benchmark optimization field')
    for field in NONDETERMINISTIC_FIELDS[suite]:
        require(field in data, 'missing declared timing/RSS field: ' + field)
        value = data[field]
        require(type(value) in (int, float) and math.isfinite(value) and value >= 0,
                'invalid timing/RSS field: ' + field)
        if field == 'peak_rss_kib':
            require(type(value) is int and value > 0, 'invalid Linux RSS measurement')
        del data[field]
    return data


def same_json(left, right):
    """Type-sensitive JSON equality; booleans must never equal integer counts."""
    return json.dumps(left, sort_keys=True, separators=(',', ':'), allow_nan=False) == \
           json.dumps(right, sort_keys=True, separators=(',', ':'), allow_nan=False)


def compare_receipts(root, outputs):
    compared = []
    for suite in SUITES:
        values = []
        for optimized in (False, True):
            name = receipt_name(suite, optimized)
            observed = semantic_receipt(outputs[(suite, optimized)] / name, suite, optimized)
            frozen = semantic_receipt(root / 'scientific' / name, suite, optimized)
            require(same_json(observed, frozen), 'semantic receipt differs from producer: ' + name)
            values.append(observed)
        require(same_json(values[0], values[1]), 'normal/optimized scientific semantics differ: ' + suite)
        compared.append({'suite': suite, 'producer_and_cross_mode_semantics_match': True,
                         'ignored_numeric_fields': list(NONDETERMINISTIC_FIELDS[suite]),
                         'optimization_flag_validated_then_normalized': suite != 'benchmark_universal.py'})
    for kind in ('startup', 'malformed'):
        values = []
        for optimized in (False, True):
            suffix = '-optimized' if optimized else ''
            name = 'universal-' + kind + '-trace' + suffix + '.json'
            output = outputs[('benchmark_universal.py', optimized)] / name
            expected = root / 'scientific' / name
            require(output.read_bytes() == expected.read_bytes(), 'universal trace bytes differ: ' + name)
            values.append(load_json(output.read_bytes()))
        require(same_json(values[0], values[1]), 'universal cross-mode trace mismatch: ' + kind)
    return compared


def replay(output=None, root=ROOT):
    root = ordinary_directory(root)
    integrity = verify(root)
    before = snapshot(root)
    imports = check_runtime_dependencies(root)
    output = prepare_output(output, root)
    runs, outputs = [], {}
    for optimized in (False, True):
        mode = 'optimized' if optimized else 'normal'
        for index, suite in enumerate(SUITES):
            work = output / mode / Path(suite).stem
            work.mkdir(parents=True)
            copy = work / 'release'
            shutil.copytree(root, copy)
            logs = work / 'output'
            logs.mkdir()
            require(snapshot(copy) == before, 'initial relocated copy differs')
            commands = [('verify_release.py', None), ('scientific/verify_bundle.py', None),
                        ('scientific/' + suite, logs)]
            if index == 0:
                commands.append(('release_checks.py', None))
            commands.append(('verify_release.py', None))
            for number, (script, destination) in enumerate(commands):
                runs.append(run_script(copy, script, optimized, logs / (str(number).zfill(2) + '.log'), destination))
                require(snapshot(copy) == before, 'relocated release inventory, bytes, modes or mtimes changed')
                require(snapshot(root) == before, 'original release inventory, bytes, modes or mtimes changed')
            outputs[(suite, optimized)] = logs
    comparisons = compare_receipts(root, outputs)
    require(snapshot(root) == before, 'original release changed before completion')
    receipt = {
        'status': 'PASS', 'scope': 'complete sealed Report 27 release',
        'output_directory': str(output), 'python': sys.version.split()[0], 'platform': sys.platform,
        'modes': ['normal', 'optimized'], 'independent_release_copies': 6,
        'runs': runs, 'scientific_subprocesses': 6, 'integrity': verify(root),
        'standard_library_imports': imports, 'third_party_runtime_dependencies': [],
        'whole_original_and_relocated_releases_unchanged': True,
        'invariance_fields': ['file inventory', 'directory inventory', 'bytes', 'file modes', 'modification times'],
        'receipt_comparisons': comparisons, 'universal_traces_byte_identical_to_producer': True,
        'negative_integrity_tests': 'passed normally and optimized',
        'network_access_used': False, 'network_audit_guard_installed': True,
        'upstream_repository_executed': False, 'universal_new_rule_evaluated': True,
        'universal_startup_steps_per_mode': 128, 'universal_malformed_cases_per_mode': 128,
        'universal_eager_template_array_materialized': False,
    }
    (output / 'replay-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    print(json.dumps(replay(args.output, args.root), indent=2))
