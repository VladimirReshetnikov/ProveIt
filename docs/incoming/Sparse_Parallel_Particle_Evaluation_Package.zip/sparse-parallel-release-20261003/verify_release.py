"""Strict standard-library exact-inventory verification of Report 27.

Every published scientific file is mandatory. The seal establishes consistency,
not external authenticity against replacement of the verifier itself.
"""
import sys
sys.dont_write_bytecode = True
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import stat

ROOT = Path(__file__).absolute().parent
MANIFEST = 'release-manifest.json'
DIGEST = MANIFEST + '.sha256'
SCHEMA = 'report27-exact-inventory-v1'
MAX_FILES = 256
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TREE_BYTES = 128 * 1024 * 1024
ORIGINAL_SCIENTIFIC_MANIFEST_SHA256 = '311e6293d0b28528b63e8f9e0eadd1a4fa91d7dc5c1b208c3e2654be37cdd7fa'
SCIENTIFIC_MANIFEST_SHA256 = '5672555af673f129c52aed9317c4d0c68b3c31fbd926952aae385e4ab32c8528'
EVALUATOR_SHA256 = '785082d121622f8fc755ed7039ee6efe719964296eec7d76ad44495dc5c6c2c1'
SOURCE_PINS = {'references/original-scientific-manifest.json': '311e6293d0b28528b63e8f9e0eadd1a4fa91d7dc5c1b208c3e2654be37cdd7fa',
 'references/prior-art-audit.md': 'b1df611bd4f019bcd2ab0cd9745ee8d4a5e6aa06a4401d07ab5e71c08f68059e',
 'references/report26-provenance.json': '4ef924506be2cc0bb2e67c14895ed71181b41652214d338c927649c5727d4d83',
 'references/root-scientific-QA.json': '2b3e9f9b48abde45ee239cefb45b1de9520a35438a8e119b0362f87350e08979',
 'scientific/COMPILER_PROOF.md': '55ecb9c26bf0c2ce929c97187013171f8b8ec52ee30cb9a8703b41b1d106a4e8',
 'scientific/PARALLEL_LEMMA_AUDIT.md': '435b547d2476230f9d532cc7ed7f5a52f779b6e5f241aaacb1d316c10e117dc1',
 'scientific/PARALLEL_PRESERVATION_AUDIT.md': 'c474f1fa73d4ced47b554fb73d91e020e834612dab00c5f8f8f7ce6afebe2e8b',
 'scientific/PARALLEL_RULE_PROOF.md': 'fe809adaa74418bcddafc61cc5ff70102724256c310ae53fd396c2fe34ef65c9',
 'scientific/PROOF.md': '28d5bdf44273790591f0043454c0f71644afbfec880eb980eee429e70fb4ae1c',
 'scientific/PROVENANCE.json': '26c3b525b39edbd3fcb061caa2ea66ee8a871294de7338f512cc59f7971c5254',
 'scientific/README.md': '2b4f906ff0eef5c3af548169e4fa7f1104aa9927ae88b63a3aa64596be64e495',
 'scientific/RESULTS.md': '163564f4da7e59d205c6a1ac8f19d8a45f6beb1e7d5b99b363f51279402cb33d',
 'scientific/SHA256SUMS': '2f353b6094e5ca4e870c8f668aff6329257709b852c231836911f886d35229b2',
 'scientific/SOURCE_SCHEMA.md': '4929b248dcf3f604694d3abf7d9efbf4649f6a5f8219661f01fc3469e900dcd3',
 'scientific/audit-candidate-completeness.md': 'd100a734955af5474e16fb1958ec8a5be0d86a737ab47d9788601b385a524212',
 'scientific/audit-candidate-receipt-optimized.json': 'fbb1f1bc1e755110c8c3f9215ea59daf9be92eef920ee256252242369c60983f',
 'scientific/audit-candidate-receipt.json': '08dedf22416da005d95a78fa762836f56824a6c6620e36e18504c1d59cbe4b56',
 'scientific/audit-optimized.log': 'fbb1f1bc1e755110c8c3f9215ea59daf9be92eef920ee256252242369c60983f',
 'scientific/audit-timings.json': '7aa01998eea00775c9559afde81948d9501e2c839b5e5085e34f5f35a4a4d770',
 'scientific/audit.log': '08dedf22416da005d95a78fa762836f56824a6c6620e36e18504c1d59cbe4b56',
 'scientific/audit_candidate_completeness.py': '677fb4adfd353ccfe71de4744b4444e8f4d5ecb9efc01c5a1d815690167b2d4a',
 'scientific/benchmark_universal.py': '8a9e2a5e4a3c63da0417e81c7451e2c816be4dcb528518d53de43f266aefe0b1',
 'scientific/frozen-ordered-startup-trace.json': '6f8c9aa889a62c577a8c988120a48393b32480a7750e2fd49a860c8727c00e1f',
 'scientific/frozen_lazy_source.py': '42e8aa65c05fcf373a03a02be51ebb89a4fdcb1f1070ad776ffe1e8e99049c61',
 'scientific/frozen_reversible_binary.py': 'f95a6028c9d3cc6f8b0b497cfc0cad68104da6d70e55205df04ad234e5d0c76f',
 'scientific/manifest.json': '5672555af673f129c52aed9317c4d0c68b3c31fbd926952aae385e4ab32c8528',
 'scientific/parallel_particles.py': '2c8b639646a587a51bddeaac16e46d2dbd8c4e8138ac67a2601025334d4a64cd',
 'scientific/sparse_parallel.py': '785082d121622f8fc755ed7039ee6efe719964296eec7d76ad44495dc5c6c2c1',
 'scientific/test-sparse-parallel-optimized-receipt.json': '81431152d4b5d66d80850f5d0209d3b71b7285d97475a88b637b3175550eace7',
 'scientific/test-sparse-parallel-optimized.log': '28e16705ce74e5fd54873f4c6b0a2fb96fde44cbdf9330eaf5595272df3d80f0',
 'scientific/test-sparse-parallel-receipt.json': 'c1a6a6c5f94eef3d02c184b38142a41c4f8dd672bed4436f75952e14625c86b1',
 'scientific/test-sparse-parallel.log': 'abe7c2886b2bf40f8d4c92e85ab87c4ffa8d838d69d3e686158260b0f30103bf',
 'scientific/test_sparse_parallel.py': '21b49ccd2730536b511aeca7ded6f466abca2d3ee89d7217cfb290a4a30ce45f',
 'scientific/universal-malformed-trace-optimized.json': '3b5607797755c9c6ded54519c9fbf97d5b1f1e411071ff46cf3efc4f2d5631ed',
 'scientific/universal-malformed-trace.json': '3b5607797755c9c6ded54519c9fbf97d5b1f1e411071ff46cf3efc4f2d5631ed',
 'scientific/universal-optimized.log': '048fe475368175dfa5584818a4bce4566963e50b5a022532f53a82ec14396077',
 'scientific/universal-receipt-optimized.json': '048fe475368175dfa5584818a4bce4566963e50b5a022532f53a82ec14396077',
 'scientific/universal-receipt.json': '636a891f3c65ca3a895a3cbe9c12f4fcf5f82922b7f9cb77bfcf8914bb80f553',
 'scientific/universal-source.json': 'fa61d06178d718511232a80a05e02192d940fde3c273f0c202f0623253b2ade3',
 'scientific/universal-startup-trace-optimized.json': 'c49b3e6992d933eb19a46273bebfdaa491a17cd703d6b22d4cd91064d7825b52',
 'scientific/universal-startup-trace.json': 'c49b3e6992d933eb19a46273bebfdaa491a17cd703d6b22d4cd91064d7825b52',
 'scientific/universal.log': '636a891f3c65ca3a895a3cbe9c12f4fcf5f82922b7f9cb77bfcf8914bb80f553',
 'scientific/verify_bundle.py': '4b4b5df2dd8524932a3d01c8f71ad51f8ea201934b7fb0724895c2dfe1fb100f'}
RELEASE_FILES = set(SOURCE_PINS) | {
    'source-pins.json', 'README.md', 'build.sh', 'verify_release.py',
    'write_manifest.py', 'release_checks.py', 'replay.py',
    'report27.tex', 'report27.pdf', 'report27-qa.json',
    'delivery-provenance.json', 'references/root-scientific-QA.json',
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def load_json(raw):
    def reject_constant(value):
        raise ValueError('nonfinite JSON number: ' + value)
    return json.loads(raw, object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def relative_name(name):
    require(type(name) is str and bool(name), 'invalid path type or empty path')
    require(re.fullmatch(r'[A-Za-z0-9_.\-/]+', name) is not None, 'unsafe path characters')
    require(not name.startswith('/') and
            all(part not in ('', '.', '..') for part in name.split('/')),
            'unsafe relative path')
    require(Path(name).as_posix() == name, 'noncanonical relative path')
    return name


def ordinary_directory(path):
    path = Path(path).absolute()
    require('..' not in path.parts, 'parent traversal in directory path')
    for ancestor in (path,) + tuple(path.parents):
        mode = ancestor.lstat().st_mode
        require(stat.S_ISDIR(mode) and not stat.S_ISLNK(mode),
                'directory path is not ordinary: ' + str(ancestor))
    return path


def inventory(root):
    root = ordinary_directory(root)
    files, directories, total = {}, set(), 0
    def walk_error(error):
        raise error
    for base, dirs, names in os.walk(root, followlinks=False, onerror=walk_error):
        for child in sorted(dirs + names):
            path = Path(base) / child
            name = relative_name(path.relative_to(root).as_posix())
            info = path.lstat()
            require(not stat.S_ISLNK(info.st_mode), 'symlink rejected: ' + name)
            if stat.S_ISDIR(info.st_mode):
                directories.add(name)
            else:
                require(stat.S_ISREG(info.st_mode), 'nonregular file rejected: ' + name)
                require(info.st_size <= MAX_FILE_BYTES, 'file size limit: ' + name)
                total += info.st_size
                require(total <= MAX_TREE_BYTES, 'release size limit')
                files[name] = path
            require(len(files) + len(directories) <= MAX_FILES, 'inventory limit')
    return files, directories


def expected_directories(names):
    return {p.as_posix() for name in names for p in Path(name).parents if p != Path('.')}


def check_private_paths(root=ROOT):
    """Scan every file as bytes for private absolute build-environment paths.

    Components keep the scanner and its tests free of the very path literals
    they reject. Public temporary-directory examples and relative provenance
    are allowed. This is an explicit prefix policy, not a general secret scan.
    """
    prefixes = tuple(b'/' + b'/'.join(parts) + b'/' for parts in (
        (b'workspace',), (b'home', b'agent'), (b'root',), (b'opt', b'codex'),
    ))
    files, _ = inventory(root)
    for name, path in sorted(files.items()):
        content = path.read_bytes()
        for prefix in prefixes:
            offset = content.find(prefix)
            require(offset == -1, 'private absolute path rejected: ' + name +
                    ' (byte offset ' + str(offset) + ')')
    return {'privacy_files_scanned': len(files),
            'private_absolute_paths_absent': True}


def validate_entry(entry):
    require(type(entry) is dict and set(entry) == {'bytes', 'sha256'}, 'manifest entry shape')
    require(type(entry['bytes']) is int and 0 <= entry['bytes'] <= MAX_FILE_BYTES,
            'invalid manifest byte count')
    require(type(entry['sha256']) is str and re.fullmatch(r'[0-9a-f]{64}', entry['sha256']) is not None,
            'invalid manifest SHA-256')


def check_pins(root=ROOT):
    root = ordinary_directory(root)
    files, directories = inventory(root)
    require('source-pins.json' in files, 'mandatory source pin manifest missing')
    require(files['source-pins.json'].stat().st_size <= 1024 * 1024, 'pin manifest too large')
    data = load_json(files['source-pins.json'].read_bytes())
    require(type(data) is dict and set(data) == {'schema', 'files'}, 'source pin manifest shape')
    require(data['schema'] == 'report27-mandatory-source-pins-v1', 'source pin schema')
    require(type(data['files']) is dict and data['files'] == SOURCE_PINS,
            'mandatory source pin set/value mismatch')
    for name, digest in SOURCE_PINS.items():
        relative_name(name)
        require(name in files, 'missing mandatory pinned dependency: ' + name)
        require(sha256(files[name].read_bytes()).hexdigest() == digest,
                'mandatory dependency pin mismatch: ' + name)
    require(set(files) <= RELEASE_FILES | {MANIFEST, DIGEST}, 'unexpected release file')
    require(directories <= expected_directories(RELEASE_FILES), 'unexpected release directory')
    require(SOURCE_PINS['scientific/manifest.json'] == SCIENTIFIC_MANIFEST_SHA256,
            'published scientific manifest pin mismatch')
    require(SOURCE_PINS['scientific/sparse_parallel.py'] == EVALUATOR_SHA256,
            'frozen evaluator pin mismatch')
    require(SOURCE_PINS['references/original-scientific-manifest.json'] == ORIGINAL_SCIENTIFIC_MANIFEST_SHA256,
            'original scientific manifest reference pin mismatch')
    scientific = load_json(files['scientific/manifest.json'].read_bytes())
    require(type(scientific) is dict and set(scientific) ==
            {'schema', 'frozen_date', 'status', 'entry_point', 'files'}, 'scientific manifest shape')
    require(scientific['schema'] == 'sparse-parallel-research-packet-v1', 'scientific manifest schema')
    entries = scientific['files']
    science_names = {name[len('scientific/'):] for name in SOURCE_PINS if name.startswith('scientific/')}
    require(type(entries) is dict and set(entries) == science_names - {'manifest.json', 'SHA256SUMS'}
            and len(entries) == 37, 'scientific exact inventory mismatch')
    for name, entry in entries.items():
        relative_name(name)
        validate_entry(entry)
        content = files['scientific/' + name].read_bytes()
        require(len(content) == entry['bytes'] and sha256(content).hexdigest() == entry['sha256'],
                'scientific manifest record mismatch: ' + name)
    sums = ''.join(entry['sha256'] + '  ' + name + '\n' for name, entry in sorted(entries.items()))
    require(files['scientific/SHA256SUMS'].read_text(encoding='ascii') == sums,
            'scientific SHA256SUMS mismatch')
    require(entries['universal-source.json']['bytes'] == 32034272,
            'mandatory universal source size mismatch')
    return {'mandatory_scientific_files': len(science_names),
            'scientific_manifest_entries': len(entries),
            'mandatory_reference_pins': len(SOURCE_PINS) - len(science_names),
            'optional_scientific_files': 0}


def manifest_data(root=ROOT):
    files, directories = inventory(root)
    require(set(files) - {MANIFEST, DIGEST} == RELEASE_FILES, 'missing/additional final release file')
    require(directories == expected_directories(RELEASE_FILES), 'missing/additional final release directory')
    check_pins(root)
    entries = {}
    for name in sorted(RELEASE_FILES):
        content = files[name].read_bytes()
        entries[name] = {'bytes': len(content), 'sha256': sha256(content).hexdigest()}
    return {'schema': SCHEMA, 'files': entries, 'directories': sorted(directories)}


def verify(root=ROOT):
    root = ordinary_directory(root)
    files, directories = inventory(root)
    require(MANIFEST in files and DIGEST in files, 'missing final seal')
    require(files[MANIFEST].stat().st_size <= 1024 * 1024, 'manifest too large')
    raw = files[MANIFEST].read_bytes()
    require(files[DIGEST].read_text(encoding='ascii') == sha256(raw).hexdigest() + '  ' + MANIFEST + '\n',
            'manifest digest mismatch')
    data = load_json(raw)
    require(type(data) is dict and set(data) == {'schema', 'files', 'directories'}, 'release manifest shape')
    require(data['schema'] == SCHEMA, 'release manifest schema')
    entries = data['files']
    require(type(entries) is dict, 'manifest entries must be an object')
    for name, entry in entries.items():
        relative_name(name)
        validate_entry(entry)
    require(set(entries) == RELEASE_FILES, 'manifest exact mandatory file inventory mismatch')
    require(set(files) == RELEASE_FILES | {MANIFEST, DIGEST}, 'actual file inventory mismatch')
    wanted_dirs = expected_directories(RELEASE_FILES)
    require(type(data['directories']) is list and data['directories'] == sorted(wanted_dirs),
            'manifest exact directory inventory mismatch')
    require(directories == wanted_dirs, 'actual directory inventory mismatch')
    for name, entry in entries.items():
        content = files[name].read_bytes()
        require(len(content) == entry['bytes'] and sha256(content).hexdigest() == entry['sha256'],
                'changed release file: ' + name)
    pins = check_pins(root)
    privacy = check_private_paths(root)
    return {'status': 'PASS', 'files_verified': len(files),
            'directories_verified': len(directories), **pins, **privacy}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    arguments = parser.parse_args()
    print(json.dumps(verify(arguments.root), indent=2))
