# Norm-weighted distinct partitions

A 26-page research report prepared for Vladimir Reshetnikov, dated October 1, 2026.

The report gives proofs of the leading asymptotic formulas explicitly labeled
conjectural in OEIS A022629, A092484, A265840, A265841, and A265842. It then develops
all-order logarithmic expansions, an all-order relative saddle expansion,
Lambert-W threshold inversion, and conditional logistic and Gumbel laws for

    F_{r,s}(q) = product_{k>=1} (1 + k^r q^k)^s,

with fixed r > 0 and fixed positive integer s. The positive fixed columns of
A292189 and A297321 are included.

## Status

The analytic arguments are presented in the report; they have not been checked
in Lean or independently peer reviewed. The targeted literature search did not
establish bibliographic priority. “All orders” concerns fixed-order asymptotic
expansions, not convergence or a complete decomposition of all exponentially
small sectors. The numerical saddle evaluations use floating-point arithmetic,
not certified interval bounds.

## Files

- `article.tex`, `article.pdf`: self-contained LaTeX source and compiled report.
- `formal.py`: exact rational formal algebra and defining-identity checks.
- `formal_coefficients.json`: eight forward and seven inverse correction polynomials.
- `numerics.py`: exact integer product coefficients and floating-point saddle estimates.
- `a022629_exact.json`: selected exact coefficients, recomputed up to index 10000.
- `numerical_results.json`: saddle results and labeled comparisons against exact integers.
- `checks.py`: independent divisor-recurrence and convolution checks.
- `verification_results.json`: passing check summary and observed software versions.
- `requirements.txt`: tested dependency versions.
- `build.sh`: LaTeX build command.
- `proposed_oeis_updates.txt`: draft formula notes for review; nothing was submitted.
- `source_audit.json`: the inspected entry identifiers, conjecture dates, and repository tree.
- `SHA256SUMS.txt`: checksums of the packaged files other than the checksum file itself.

## Reproduce

The checks were run with Python 3.13.5. Install the dependencies in an isolated
environment, then run:

    python -m pip install -r requirements.txt
    python formal.py --order 8
    python checks.py
    python numerics.py

All three scripts run offline after dependency installation. The exact numerical
script computes every coefficient through 10000, checks the initial OEIS terms,
and stores selected coefficients. Values at 10^6, 10^8, and 10^10 in the numerical
JSON are saddle estimates only, not exact coefficients.

`formal.py` can request other finite orders; higher symbolic orders cost more.
Its exact algebra does not independently prove the analytic remainder estimates.

Build the document with a TeX installation providing pdfLaTeX, Latin Modern,
AMS packages, microtype, booktabs, enumitem, fancyhdr, hyperref, and bookmark:

    bash build.sh

The bibliography is contained in the TeX source. No external images, bibliography
files, or font files are required.

## Reading order

Section 2 isolates the elementary proof of the five posted leading conjectures.
Sections 3–5 establish the saddle model, smoothing expansion, and local theorem.
Section 6 gives the forward coefficients; Section 7 gives the inverse.
Sections 8–9 prove the probabilistic results. Sections 10–11 contain computation
and twelve further research directions. The appendices describe notation and
proof dependencies.

No changes were made to the ProveIt repository or to OEIS.
