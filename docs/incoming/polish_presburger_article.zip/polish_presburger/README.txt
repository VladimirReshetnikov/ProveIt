CONTINUOUS PRESBURGER ARITHMETIC ON POLISH SPACES
Research report prepared for Vladimir Reshetnikov
3 October 2026

CONTENTS

polish_presburger.tex   Self-contained LaTeX source.
polish_presburger.pdf   Compiled article, with proofs and bibliography.
README.txt             This file.

BUILD

Run:
  latexmk -pdf polish_presburger.tex

Alternatively run pdflatex twice, and again if it requests a rerun.
All packages are standard TeX Live packages. No external images, .bib file,
downloaded repository, or network connection are required to compile.

MAIN RESULTS

1. An explicit affirmative answer to Question 2 of Elliot Glazer's
   "A Topological Tennenbaum Theorem" (arXiv:2311.13699v1): the positive
   cone of R lex Z has a perfect locally compact Polish topology and
   continuous addition, and satisfies full first-order Presburger arithmetic.

2. A Baire-space version from Q^N lex Z, with discrete rational factors;
   the explicit presentation has Type-2 computable addition.

3. Exactly continuum many isomorphism types of continuous Presburger
   additions on Baire space, even with one fixed order, topology, 0, and 1.
   A separate ordinal family realizes full Archimedean orders alpha+1
   for every countably infinite ordinal alpha.

4. Every Presburger-definable relation with parameters in the examples
   is both F_sigma and G_delta. Fixed standard division and remainder
   maps are continuous.

5. The lexicographic examples admit no unital semiring multiplication,
   even with no topological requirement or prespecified unit.

6. The positive cone of Z+t R[t], with topology by degree and constant
   coefficient, is an uncountable locally compact Polish semiring with
   continuous addition and multiplication and a Presburger additive reduct.
   It fails open induction via the formula x^2<t.

7. A strengthening extracted from Glazer's method: zero must be isolated
   in any Polish topological nonnegative cone of a discretely ordered ring
   with continuous addition and multiplication. No internal arithmetic
   induction is used.

The article includes 12 further research projects and a detailed proposed
formalization route connected to ProveIt.

STATUS AND PROVENANCE

The new statements have ordinary mathematical proofs in the article.
Separate proof reviews checked the principal algebraic, topological,
model-theoretic, and probabilistic arguments. No Lean kernel verification,
repository rebuild, or external peer review is claimed.

The algebraic constructions and Presburger characterization are classical.
The text credits them, the repository's corresponding material, and
Glazer's subset-sum/probability method. The literature search did not locate
an earlier answer or these exact topological presentations, but no
unrestricted publication-priority claim is made.

Repository comparison used ProveIt snapshot:
  fa2f3e419e592a1e90c065b79d559865ec45d436
It inspected selected relevant files, not every mathematical assertion in
the repository. The manuscript records that the existing Presburger code
uses standard Int semantics, whereas arbitrary Z-group semantics remains
a proposed formalization step.

The complete bibliography and versioned source links are in the article.
