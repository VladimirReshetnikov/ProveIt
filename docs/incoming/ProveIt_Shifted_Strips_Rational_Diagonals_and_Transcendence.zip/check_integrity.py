#!/usr/bin/env python3
"""Check distributed file integrity before replay."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256.json').read_text())
for name,expected in manifest.items():
 p=root/name
 assert p.is_file(),f'Missing distributed file: {name}'
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 assert actual==expected,f'SHA-256 mismatch: {name}'
print(f'Integrity passed for {len(manifest)} files')
