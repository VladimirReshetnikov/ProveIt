RATIONAL DIAGONALS AND TRANSCENDENCE FOR FIXED HEIGHT SHIFTED STRIPS
Research package, 2 October 2026

MAIN RESULTS
For each fixed positive height m, the width sequence g(m,n) for the arrays
in OEIS A181196 is a multiple binomial sum, hence has a rational-diagonal
ordinary generating function and is P-recursive. The proof records births
and saturations, with at most m^2 pre-event coordinates. The ordinary
generating function is algebraic exactly for m=1 and m=2; every m>=3 is
transcendental and D-finite.

SCOPE
The article proves existence of polynomial-coefficient recurrences. It does
not prove the particular operators conjectured in A181198 or A181199, nor
claim minimal recurrence order or degree. The rational diagonal is supplied
constructively in principle by the cited binomial-sum theorem; a compact
expanded rational function is not claimed. These shifted-strip arrays are
different from the balanced late-growing words in A215561.

The leading equivalent used for transcendence is proved in Section 6 of
this article. Its provenance is the author's earlier unpublished project
report, identified explicitly in the bibliography. The present proof needs
no conjectural recurrence, numerical fitting, or external copy of that report.

CONTENTS
 article.pdf               Nine-page article
 article.tex               Complete editable LaTeX source
 build_local.sh            Two-pass LaTeX build with local font-map support
 code/check_exact.py       Standard-library exact verification
 code/check_exact.json     Complete deterministic verification output
 verify.py                 Re-run and compare the exact output
 verification.json         Summary produced by verify.py
 check_integrity.py        Check all distributed file hashes
 CHECKS.json               Recorded mathematical and production checks
 SOURCES.json              Verified primary-source pointers and their roles
 SHA256.json               SHA-256 manifest, excluding itself

REPLAY
From the extracted package directory:
 python3 check_integrity.py
 python3 verify.py
 bash build_local.sh

The exact tests require only Python 3 and its standard library. PDF building
requires a TeX installation with pdfTeX, LaTeX, geometry, fontenc, lmodern,
amsmath, amssymb, amsthm, booktabs, microtype and hyperref. The build script
supports the TeX Live directories in the supplied environment, and otherwise
uses the default TeX search paths. A normal TeX setup may also compile
article.tex with two runs of pdflatex. Poppler is useful for PDF text checks
and visual rendering, but is not needed by the exact mathematical checker.

EXACT CHECKS
54 independent cell-poset versus row-state counts (m=1..6, n=0..8)
44 full event-sum comparisons
2941 chamber endpoint pairs, including backwards and zero-length cases
1554 binomial-product tests including negative lower arguments
All Dyck event words through m=9 checked against the m^2 dimension bound
Height-two Catalan identities checked in the same count range

These finite tests audit indexing and boundary conventions. The all-height
result is proved mathematically in the article, not inferred from the tests.
