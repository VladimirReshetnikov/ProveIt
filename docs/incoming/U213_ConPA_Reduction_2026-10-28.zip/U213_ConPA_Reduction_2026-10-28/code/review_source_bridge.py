#!/usr/bin/env python3
"""Independent audit of the frozen U214-to-U213 source and byte bridge.

Does not import construction/runtime code.  Opcode/control-flow comparison,
closed-macro checks, dense relabeling and startup simulation are independent.
The builder is additionally exercised as a separate black-box subprocess.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def require(ok, msg):
    if not ok:
        raise ValueError(msg)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(path):
    rows = json.loads(path.read_text())
    require(all(isinstance(x, list) and len(x) == 3 for x in rows), 'source arity')
    require(all(set(p) <= {'0', '1'} and p for p, _, _ in rows), 'source address')
    addresses = [x[0] for x in rows]
    require(addresses == sorted(set(addresses)), 'source order or duplication')
    leaves = {p: i for i, p in enumerate(addresses)}
    desc = {}
    for i, p in enumerate(addresses):
        for k in range(len(p) + 1):
            desc.setdefault(p[:k], []).append(i)
    for p, indices in desc.items():
        require(indices == list(range(indices[0], indices[-1] + 1)), 'noninterval')
        if p in leaves:
            require(len(indices) == 1, 'prefix leaf collision')
        else:
            require(p + '0' in desc and p + '1' in desc, 'incomplete prefix tree')
    outcomes = []
    for i, (p, op, a) in enumerate(rows):
        require(op in {'CI', 'CD', 'CB', 'CC', 'CH'}, 'unknown primitive')
        if op in {'CI', 'CD'}:
            require(type(a) is int and 0 <= a < 9, 'invalid register')
        elif op in {'CB', 'CC'}:
            require(type(a) is int and a >= 1, 'invalid level')
        else:
            require(a is None, 'halt has argument')
        if op == 'CI':
            outgoing = {'next': i + 1}
        elif op == 'CH':
            outgoing = {}
        else:
            wanted = '1' if op == 'CC' else '0'
            remaining = 1 if op == 'CD' else a
            parent = p
            while parent and remaining:
                last = parent[-1]
                parent = parent[:-1]
                if last == wanted:
                    remaining -= 1
            require(remaining == 0, 'primitive escapes source')
            ids = desc[parent]
            target = ids[0] if op == 'CC' else ids[-1] + 1
            outgoing = {'zero': target, 'positive': i + 1} if op == 'CD' else {'jump': target}
        require(all(0 <= j <= len(rows) for j in outgoing.values()), 'invalid ordinal target')
        outcomes.append({'ordinal': i, 'opcode': op, 'argument': a, 'outcomes': outgoing})
    return rows, desc, outcomes


def closed_cover(rows, desc, lo, hi):
    """Maximal prefix subtrees covering [lo,hi), checked by local branch counts."""
    cover = []
    for p in sorted(desc, key=lambda p: (len(p), p)):
        ids = desc[p]
        if ids[0] < lo or ids[-1] >= hi:
            continue
        if any(p.startswith(q) for q in cover):
            continue
        cover.append(p)
    indices = sorted(i for p in cover for i in desc[p])
    require(indices == list(range(lo, hi)), 'cover does not partition interval')
    for p in cover:
        for i in desc[p]:
            addr, op, a = rows[i]
            relative = addr[len(p):]
            require(op != 'CH', 'halt in closed arithmetic macro')
            if op in {'CD', 'CB'}:
                require(relative.count('0') >= (1 if op == 'CD' else a), 'external break')
            if op == 'CC':
                require(relative.count('1') >= a, 'external continue')
    return cover


def table(path):
    result = {}
    headers = []
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            headers.append(line)
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        q, b, w, z = map(int, (q, b, w, z))
        require((q, b) not in result and b in (0, 1) and w in (0, 1), 'bad table row')
        require(d in ('L', 'R'), 'bad movement')
        result[q, b] = (w, 1 if d == 'R' else -1, z)
    require(headers == ['#! start 0'], 'bad initial state')
    return result


def bootstrap(transitions, receipt):
    q = h = 0
    ones = set()
    for tick in range(receipt['steps']):
        b = int(h in ones)
        require((q, b) in transitions, 'premature halt')
        w, d, z = transitions[q, b]
        require(receipt['trace'][tick] == [q, h, b, w, d, z], 'startup trace mismatch')
        if w:
            ones.add(h)
        else:
            ones.discard(h)
        q, h = z, h + d
    require(len(receipt['trace']) == receipt['steps'], 'wrong trace length')
    require((q, h, sorted(ones)) == (receipt['state'], receipt['head'], receipt['one_cells']),
            'startup endpoint mismatch')
    phy = (6, 2, 0, 4, 3, 7, 8, 5, 1)
    values = [None] * 9
    for logical, physical in enumerate(phy):
        values[physical] = receipt['registers'][logical]
    marker = h + 64 + receipt['gap']
    expected = {h - 1, marker}
    position = marker + 1
    for v in values + receipt['spares']:
        require(type(v) is int and v >= 0, 'negative register')
        position += 1
        expected.update(range(position, position + v + 1))
        position += v + 1
    require(q == 84 and ones == expected, 'startup does not encode exact empty-root frame')
    return {'steps': receipt['steps'], 'state': q, 'head': h, 'gap': receipt['gap'],
            'registers': receipt['registers'], 'spares': receipt['spares'],
            'one_cells': sorted(ones)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', required=True, type=Path)
    parser.add_argument('--candidate', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    b, c = args.baseline, args.candidate
    old, od, og = source(b / 'machine/sites.json')
    new, nd, ng = source(c / 'sites.json')
    require(len(old) == len(new) == 3928, 'leaf census')
    require([r[1:] for r in old] == [r[1:] for r in new], 'primitive sequence changed')
    require(og == ng, 'guarded source control flow changed')
    changed = [i for i, (x, y) in enumerate(zip(old, new)) if x[0] != y[0]]
    require(changed == list(range(2885, 3659)), 'changed interval is not exactly774')
    sr = json.loads((c / 'source_recipe.json').read_text())
    tr = json.loads((c / 'table_recipe.json').read_text())
    macro, md, _ = source(b / 'inputs/k215_sites.json')
    macro_words = {}
    for name, (lo, hi) in sr['macro_intervals'].items():
        cover = closed_cover(macro, md, lo, hi)
        macro_words['m' + name] = (macro[lo:hi], cover)
    def word(node):
        if isinstance(node, str):
            require(node in macro_words, 'unknown macro')
            return [node]
        require(isinstance(node, list) and len(node) == 2, 'replacement arity')
        return word(node[0]) + word(node[1])
    labels = word(sr['replacement'])
    require(len(labels) == 28, 'not28 macro occurrences')
    cursor = 2885
    macro_checks = []
    for label in labels:
        unit, _ = macro_words[label]
        end = cursor + len(unit)
        expected = [r[1:] for r in unit]
        require([r[1:] for r in old[cursor:end]] == expected, 'old macro word mismatch')
        require([r[1:] for r in new[cursor:end]] == expected, 'new macro word mismatch')
        old_cover = closed_cover(old, od, cursor, end)
        new_cover = closed_cover(new, nd, cursor, end)
        for graph in (og, ng):
            for instruction in graph[cursor:end]:
                require(all(cursor <= t <= end for t in instruction['outcomes'].values()),
                        'control flow escapes closed macro')
        macro_checks.append({'macro': label, 'start': cursor, 'end': end,
                             'old_cover': old_cover, 'new_cover': new_cover})
        cursor = end
    require(cursor == 3659, 'macro coverage endpoint')
    oldt = table(b / 'machine/u214.native.tm')
    midt = table(c / 'reparenthesized214.native.tm')
    newt = table(c / 'u213.native.tm')
    row_changes = [(*k, *v) for k, v in sorted(midt.items()) if oldt[k] != v]
    require(row_changes == [tuple(r) for r in tr['changed_rows']], 'patch is not exact70 rows')
    require(len(row_changes) == len({r[:2] for r in row_changes}) == 70, 'patch census')
    require({q for q, _ in oldt} == {q for q, _ in midt}, 'intermediate state labels changed')
    require(newt == {(q, bit): (w, d, 172 if z == 167 else z)
                     for (q, bit), (w, d, z) in midt.items() if q != 167}, 'fold differs')
    oldseed = bootstrap(oldt, json.loads((b / 'evidence/u214/startup.json').read_text()))
    newseed = bootstrap(newt, json.loads((c / 'runtime/startup.json').read_text()))
    require({k: v for k, v in oldseed.items() if k != 'steps'} ==
            {k: v for k, v in newseed.items() if k != 'steps'}, 'root seeds differ')
    with tempfile.TemporaryDirectory(prefix='u213-independent-') as tmp:
        replay = subprocess.run([sys.executable, '-B', str(c / 'reconstruct_u213.py'),
                                 '--baseline', str(b), '--recipes', str(c),
                                 '--output', tmp], check=True, text=True, capture_output=True)
        result = json.loads(replay.stdout)
        for name in ('sites.json', 'u213.native.tm', 'reparenthesized214.native.tm'):
            require((Path(tmp) / name).read_bytes() == (c / name).read_bytes(), 'builder byte mismatch')
        dense = table(Path(tmp) / 'u213.tm')
        states = sorted({q for q, _ in newt})
        mapping = {q: i for i, q in enumerate(states)}
        mapping[254] = 213
        require(dense == {(mapping[q], bit): (w, d, mapping[z])
                          for (q, bit), (w, d, z) in newt.items()}, 'dense relabeling differs')
    report = {
        'status': 'INDEPENDENT_SOURCE_BRIDGE_PASS',
        'reviewer_sha256': digest(Path(__file__)),
        'scope': 'Independent source/CFG/closure comparison, exact table recipe, '
                 'literal blank-start replay, and black-box reconstruction; '
                 'does not rerun full arbitrary-register symbolic verification.',
        'operations_and_arguments_compared': 3928,
        'guarded_outcomes_compared': sum(max(1, len(x['outcomes'])) for x in og),
        'ordinary_control_flow_edges': sum(len(x['outcomes']) for x in og),
        'halting_outcomes': sum(not x['outcomes'] for x in og),
        'source_cfg_including_halt_nodes_identical': True,
        'root_exit_sentinel': len(old),
        'root_exit_ordinals': [x['ordinal'] for x in og if len(old) in x['outcomes'].values()],
        'source_addresses_changed': len(changed),
        'changed_half_open_ordinal_interval': [2885, 3659],
        'all_exterior_3154_addresses_and_primitives_unchanged': True,
        'closed_macro_occurrences': len(labels),
        'distinct_macro_types': len(macro_words),
        'closed_macro_checks': macro_checks,
        'closed_macro_qualification': 'Closure is a control-flow property. '
                                     'Termination of arithmetic macros is inherited; '
                                     'global opcode/CFG identity itself preserves '
                                     'both terminating and divergent source behavior.',
        'reallocated_literal_rows': 70,
        'intermediate_and_original_state_sets_identical': True,
        'folded_native_table_is_exact': True,
        'builder_reconstruction': result,
        'old_bootstrap_steps': oldseed['steps'],
        'new_bootstrap_steps': newseed['steps'],
        'whole_tape_head_root_and_register_seed_identical': True,
        'seed': {k: v for k, v in newseed.items() if k not in ('steps', 'one_cells')},
        'hashes': {'old_source': digest(b / 'machine/sites.json'),
                   'new_source': digest(c / 'sites.json'),
                   'old_native_table': digest(b / 'machine/u214.native.tm'),
                   'new_native_table': digest(c / 'u213.native.tm'),
                   'builder': digest(c / 'reconstruct_u213.py')},
        'remaining_obligations': ['Full literal runtime certificate for this exact new source/table',
                                  'Inherited U214 numerical calculus and Con(U)/Con(PA) calibration'],
        'new_extra_logical_assumptions': [],
        'proof_assistant_kernel_certificate': False,
    }
    args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'closed_macro_checks'}, indent=2))


if __name__ == '__main__':
    main()
