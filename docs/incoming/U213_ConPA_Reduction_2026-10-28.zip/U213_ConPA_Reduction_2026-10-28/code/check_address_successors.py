#!/usr/bin/env python3
"""Check binary counter updates against ordinal successors, with no stray ones.

Independent of the allocator, source builder, and symbolic runtime executor.
The empty/overflow counter selects the first ordinal under the common root
return convention. This checker validates every guarded successor address.
"""
import argparse, hashlib, json
from pathlib import Path


def need(ok, why):
    if not ok:
        raise ValueError(why)


def verify(path):
    rows = json.loads(path.read_text())
    leaves = {p:i for i,(p,_,_) in enumerate(rows)}
    bounds = {}
    for i,(p,_,_) in enumerate(rows):
        need(p and set(p) <= {'0','1'},'Invalid address')
        for k in range(len(p)+1):
            bounds.setdefault(p[:k],[i,i+1])[1] = i+1
    need(len(leaves)==len(rows),'Duplicate leaf')
    need(sorted(leaves)==[r[0] for r in rows],'Noncanonical order')
    for p in bounds:
        if p in leaves:
            need(bounds[p][1]-bounds[p][0]==1,'Overlapping leaf')
        else:
            need(p+'0' in bounds and p+'1' in bounds,'Incomplete tree')
    n = len(rows)
    depth = max(map(len,leaves))

    def increment(p):
        if not p:
            return ''
        return format((int(p,2)+1)%(2**len(p)),'0'+str(len(p))+'b')

    def cut(p,bit,count):
        positions = [i for i,x in enumerate(p) if x==bit]
        return p[:positions[-count]] if len(positions)>=count else ''

    def decode(counter):
        padded = counter+'0'*depth
        for k in range(1,depth+1):
            q = padded[:k]
            if q in leaves:
                need('1' not in counter[k:],'Nonzero suffix beyond selected leaf')
                return leaves[q]
        raise ValueError('Counter does not select a leaf')

    need(decode('')==0,'Root does not select first leaf')
    checked=0;sentinels=[]
    for i,(p,op,arg) in enumerate(rows):
        if op=='CH':
            continue
        if op=='CI':
            counters=[increment(p)];targets=[(i+1)%n]
        else:
            edge='1' if op=='CC' else '0'
            count=1 if op=='CD' else arg
            positions=[j for j,x in enumerate(p) if x==edge]
            need(0<count<=len(positions),'Outward source edge')
            prefix=p[:positions[-count]]
            target=bounds[prefix][0 if op=='CC' else 1]
            if target==n:
                sentinels.append(i)
            counters=[cut(p,edge,count) if op=='CC' else increment(cut(p,edge,count))]
            targets=[target%n]
            if op=='CD':
                counters.append(increment(p));targets.append((i+1)%n)
        for counter,target in zip(counters,targets):
            need(decode(counter)==target,'Counter/ordinal successor mismatch')
            checked+=1
    return {'status':'ALL_BINARY_SUCCESSORS_PASS','sites':n,
            'guarded_nonhalt_edges':checked,'halt_sites':sum(op=='CH' for _,op,_ in rows),
            'maximum_depth':depth,'root_exit_ordinals':sentinels,
            'no_stray_nonzero_suffix':True,
            'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args();r=verify(a.source);encoded=json.dumps(r,indent=2)+'\n'
    if a.output:a.output.write_text(encoded)
    print(encoded,end='')
