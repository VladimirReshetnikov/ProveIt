#!/usr/bin/env python3
"""Independent finite check of the guarded 167 -> 172 two-sided fold.

This program imports no candidate builder or existing symbolic executor.  Its
local frames have opaque exteriors: reading outside a supplied frame is an
error. A finite frame check is supplemented by the accompanying mathematical
induction argument over complete configurations.
"""
from pathlib import Path
from itertools import product
import argparse
import hashlib
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    rows = {}
    for line in path.read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        q, b, w, d, n = line.split()
        key = int(q), int(b)
        require(key not in rows, 'duplicate row')
        rows[key] = int(w), 1 if d == 'R' else -1 if d == 'L' else 0, int(n)
    require(all(d in (-1, 1) for _, d, _ in rows.values()), 'invalid direction')
    states = {q for q, _ in rows}
    require(set(rows) == {(q, b) for q in states for b in (0, 1)}, 'partial table')
    require(254 not in states, 'halt has outgoing rows')
    require(all(n in states or n == 254 for _, _, n in rows.values()), 'bad target')
    return rows


def advance(rows, state, tape, count):
    tape = dict(tape)
    head = 0
    for _ in range(count):
        require(state != 254, 'halt inside checked block')
        require(head in tape, 'opaque exterior read')
        write, movement, state = rows[state, tape[head]]
        tape[head] = write
        head += movement
    return state, head, tape


def verify(old, new):
    oldstates, newstates = {q for q, _ in old}, {q for q, _ in new}
    require(oldstates - newstates == {167}, 'wrong deleted states')
    require(not newstates - oldstates, 'new states introduced')
    require(0 in newstates, 'missing start state')
    require({k for k, v in old.items() if v[2] == 167} == {(158, 1)},
            '167 incoming-edge guard is not unique')
    require(old[158, 1] == (1, 1, 167), 'entry does not leave a preceding one')
    require(new[158, 1] == (1, 1, 172), 'redirect differs')
    require(all(new[k] == v for k, v in old.items()
                if k[0] != 167 and k != (158, 1)), 'unexpected retained-row change')
    rename = lambda q: 172 if q == 167 else q
    total = exceptional = 0
    for q in sorted(oldstates):
        for bits in product((0, 1), repeat=5):
            tape = dict(zip(range(-2, 3), bits))
            if q == 167 and tape[-1] != 1:
                continue
            slow = q == 167 and tape[0] == 0
            oc = advance(old, q, tape, 2 if slow else 1)
            nc = advance(new, rename(q), tape, 6 if slow else 1)
            require((rename(oc[0]), oc[1], oc[2]) == nc,
                    f'local endpoint mismatch at {(q, bits)}')
            if oc[0] == 167:
                require(oc[2][oc[1]-1] == 1, 'entry invariant not inductive')
            total += 1
            exceptional += int(slow)
    return {'working_states_before': len(oldstates),
            'working_states_after': len(newstates),
            'admissible_radius_two_frames': total,
            'ordinary_one_for_one_frames': total-exceptional,
            'two_for_six_frames': exceptional,
            'entry_guard': 'q=167 implies tape[head-1]=1',
            'halt_label': 254}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old', type=Path)
    parser.add_argument('new', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    old, new = load(args.old), load(args.new)
    result = verify(old, new)
    controls = []
    # Change helpers in BOTH tables so simple row-equality checking still
    # accepts them. These controls must fail actual local simulation.
    for row, replacement in [((112, 1), (0, 1, 209)),
                             ((157, 0), (1, -1, 67)),
                             ((151, 0), (0, 1, 86)),
                             ((186, 1), (0, 1, 86)),
                             ((218, 0), (0, 1, 86))]:
        a, b = dict(old), dict(new)
        a[row] = b[row] = replacement
        try:
            verify(a, b)
        except ValueError as err:
            controls.append({'row': row, 'status': 'REJECTED', 'reason': str(err)})
        else:
            raise ValueError(f'control wrongly accepted: {row}')
    result.update(status='PASS', negative_controls=controls,
                  old_sha256=hashlib.sha256(args.old.read_bytes()).hexdigest(),
                  new_sha256=hashlib.sha256(args.new.read_bytes()).hexdigest(),
                  scope='Finite local certificate plus separately written all-tape induction; no kernel proof.')
    encoded = json.dumps(result, indent=2)+'\n'
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end='')


if __name__ == '__main__':
    main()
