#!/usr/bin/env python3
"""Reuse individually proved cases only when all literal dependencies agree.

The prior table's overall runtime contract failed. Its completed individual
cases remain valid. A case whose literal row set is unchanged, and whose
four list lemmas are unchanged, has the identical deterministic derivation
under the repaired table. All other cases are rederived without restrictions
on natural register values. The full validator can independently regenerate
every final case without this proof-reuse optimization.
"""
from pathlib import Path
import argparse, hashlib, json, sys, time


def need(ok, message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):return json.loads(path.read_text())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--code',required=True,type=Path)
    p.add_argument('--old-table',required=True,type=Path)
    p.add_argument('--new-table',required=True,type=Path)
    p.add_argument('--source',required=True,type=Path)
    p.add_argument('--prior',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(a.code.resolve()));import validate_native as v
    s=v.s;prior=load(a.prior/'runtime.json');previous=load(a.prior/'runtime_cases.json')
    need(prior['table_sha256']==sha(a.old_table),'Old table binding mismatch')
    need(prior['sites_sha256']==sha(a.source),'Prior source differs')
    need(prior['checker_sha256']==sha(Path(s.__file__)) and
         prior['helper_sha256']==sha(Path(s.r.__file__)),'Prior rules differ')
    need(prior['proved_cases']==len(previous)==4229,'Unexpected partial certificate')
    old=s.r.table(a.old_table);new=s.r.table(a.new_table)
    need(set(old)==set(new),'Changed state/row domain')
    changed={k for k in old if old[k]!=new[k]}
    need(changed=={(101,0)} and old[101,0]==(0,1,150) and new[101,0]==(0,1,182),
         'Not the frozen one-row repair')
    sites=load(a.source);mapping={int(k):int(v)for k,v in load(v.MAPPATH).items()}
    for q,b in new:mapping.setdefault(q,q+1000)
    need(len(set(mapping[q]for q,b in new))==len(new)//2,'Mapping collision')
    oldL={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in old.items()}
    newL={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in new.items()}
    oldlem,oldblocks=s.prove_blocks(oldL);lem,blocks=s.prove_blocks(newL)
    need(oldlem==lem and oldblocks==blocks and
         json.loads(json.dumps(blocks))==prior['blocks'],'List lemma changed')
    prev={(x['site_index'],x['positive']):x for x in previous}
    need(len(prev)==len(previous),'Duplicate prior case')
    st=v.startup(new);(a.output/'startup.json').write_text(json.dumps(st,indent=2)+'\n')
    need(st['status']=='CALIBRATED_DIRTY_ROOT_SEED','Startup failed')
    print('STARTUP',st['steps'],flush=True)
    began=time.monotonic();cases=[];reuse=[];redo=[];fail=[]
    for i,site in enumerate(sites):
        for positive in ((False,True)if site[1]=='CD'else(False,)):
            key=(i,positive);record=prev.get(key)
            if record is not None and all(oldL[tuple(row)]==newL[tuple(row)]
                                          for row in record['rows']):
                cases.append(record);reuse.append([i,positive]);continue
            try:
                result=s.case(newL,lem,site,positive)
                result['rows']=sorted(result['rows']);result.pop('trace')
                cases.append({'site_index':i,'positive':positive,**result})
                redo.append([i,positive])
            except Exception as error:
                fail.append({'site_index':i,'site':site,'positive':positive,
                             'reason':str(error)})
                print('FAIL',fail[-1],flush=True);break
        if fail:break
        if (i+1)%500==0:print('SITE',i+1,'REUSED',len(reuse),'REDERIVED',len(redo),flush=True)
    total=sum(2 if row[1]=='CD' else 1 for row in sites)
    report={'status':'UNIVERSAL_MATHEMATICAL_PASS'if not fail and len(cases)==total else'NOT_PROVED',
            'table_sha256':sha(a.new_table),'sites_sha256':sha(a.source),
            'checker_sha256':sha(Path(s.__file__)),'helper_sha256':sha(Path(s.r.__file__)),
            'working_states':len(new)//2,'site_count':len(sites),'expected_cases':total,
            'proved_cases':len(cases),'failures':fail,'blocks':blocks,
            'seconds':time.monotonic()-began,'startup_status':st['status'],
            'source_semantics':'Separate obligation. Quantified runtime certificate only.',
            'scope':'All natural primary values at each guard; arbitrary natural gap; nonempty arbitrary '
                    'finite spare list; complete zero exterior. Induction over unary scans and list length. '
                    'Not proof-assistant kernel checked.',
            'case_proof_reuse':{'prior_overall_status':prior['status'],
                               'prior_individually_proved_cases':len(previous),
                               'unchanged_row_derivations_transported':len(reuse),
                               'cases_freshly_rederived':len(redo),
                               'all_four_list_schemas_rederived':True,
                               'prior_table_sha256':sha(a.old_table),
                               'prior_summary_sha256':sha(a.prior/'runtime.json'),
                               'prior_cases_sha256':sha(a.prior/'runtime_cases.json'),
                               'transport_checker_sha256':sha(Path(__file__))}}
    (a.output/'runtime.json').write_text(json.dumps(report,indent=2)+'\n')
    (a.output/'runtime_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
    transport={'changed_native_rows':sorted(changed),'changed_runtime_rows':[(mapping[q],b)for q,b in sorted(changed)],
               'reused_cases':reuse,'rederived_cases':redo,
               'principle':'Deterministic symbolic case execution consults only the recorded literal rows '
                           'and the four rederived list lemmas. Unchanged dependencies preserve exactly '
                           'the earlier individual derivation; the failed overall table is not certified.'}
    (a.output/'transport.json').write_text(json.dumps(transport,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in('blocks','failures')},indent=2),flush=True)
    need(not fail and len(cases)==total,'Final runtime verification incomplete')


if __name__=='__main__':main()
