#!/usr/bin/env python3
"""Solver-free reconstruction of U213 from the pinned primary U214 packet.

Source-tree and closed-splice conventions follow the supplied U214 utilities,
which retain ProveIt/Wade attribution. The two small JSON recipes are the
complete construction data. This program checks exact source control flow and
literal tables, not the separate all-natural runtime or logical calibration.
Python 3.10+, standard library only; does not require assertions enabled.
"""
from pathlib import Path
from functools import lru_cache
import argparse, hashlib, json

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def leaf(node):
    return isinstance(node[0], str)

def parse_source(rows):
    instructions = {p: (op, a) for p, op, a in rows}
    require(len(instructions) == len(rows), 'Repeated source address')
    prefixes = {p[:i] for p in instructions for i in range(len(p))}
    require(not prefixes.intersection(instructions), 'Overlapping source address')
    require(all(p+b in prefixes or p+b in instructions
                for p in prefixes for b in '01'), 'Incomplete source tree')
    def visit(p):
        return instructions[p] if p in instructions else (visit(p+'0'), visit(p+'1'))
    root = visit('')
    require(source_rows(root) == rows, 'Source is not in canonical order')
    return root

def source_rows(node, p=''):
    if leaf(node):
        return [[p, *node]]
    return source_rows(node[0], p+'0') + source_rows(node[1], p+'1')

@lru_cache(None)
def size(node):
    return 1 if leaf(node) else size(node[0]) + size(node[1])

@lru_cache(None)
def boundary(node):
    if leaf(node):
        op, a = node
        return (1 if op == 'CD' else a if op == 'CB' else 0,
                a if op == 'CC' else 0, op == 'CH')
    a, b = boundary(node[0]), boundary(node[1])
    return (max(a[0]-1, b[0], 0), max(a[1], b[1]-1, 0), a[2] or b[2])

def serial(parts):
    require(bool(parts), 'Empty source fragment')
    return parts[0] if len(parts) == 1 else (parts[0], serial(parts[1:]))

def forest(node, lo, hi):
    parts = []
    def visit(node, start):
        end = start + size(node)
        if end <= lo or hi <= start:
            return
        if lo <= start and end <= hi:
            require(boundary(node) == (0, 0, False), 'Unclosed macro factor')
            parts.append(node)
        else:
            require(not leaf(node), 'Partial leaf')
            visit(node[0], start)
            visit(node[1], start + size(node[0]))
    visit(node, 0)
    require(sum(map(size, parts)) == hi-lo, 'Macro interval mismatch')
    return parts

def splice(root, lo, hi, replacement):
    insertions = 0
    def visit(node, start):
        nonlocal insertions
        end = start + size(node)
        if end <= lo or hi <= start:
            return node
        if lo <= start and end <= hi:
            require(boundary(node) == (0, 0, False), 'Unclosed removed factor')
            if start == lo:
                insertions += 1
                return replacement
            return None
        require(not leaf(node), 'Partial leaf')
        a = visit(node[0], start)
        b = visit(node[1], start + size(node[0]))
        if a is None:
            require(b is None or boundary(b)[:2] == (0, 0), 'Open right remainder')
            return b
        if b is None:
            require(boundary(a)[:2] == (0, 0), 'Open left remainder')
            return a
        return a, b
    result = visit(root, 0)
    require(insertions == 1, 'Replacement multiplicity')
    return result

def graph(rows):
    bounds = {}
    for i, (p, _, _) in enumerate(rows):
        for j in range(len(p)+1):
            q = p[:j]
            if q not in bounds:
                bounds[q] = [i, i+1]
            else:
                bounds[q][1] = i+1
    result = []
    for i, (p, op, a) in enumerate(rows):
        if op == 'CI':
            targets = [i+1]
        elif op == 'CH':
            targets = []
        else:
            bit, count = ('1' if op == 'CC' else '0'), (1 if op == 'CD' else a)
            ancestors = [j for j, b in enumerate(p) if b == bit]
            require(len(ancestors) >= count, 'Escaping source control')
            target = bounds[p[:ancestors[-count]]][0 if op == 'CC' else 1]
            targets = [target, i+1] if op == 'CD' else [target]
        result.append([op, a, targets])
    return result

def metrics(root):
    seen = set()
    def visit(node):
        if node in seen:
            return
        seen.add(node)
        if not leaf(node):
            visit(node[0]); visit(node[1])
    visit(root)
    rows = source_rows(root)
    return {'dag_nodes': len(seen), 'leaf_occurrences': len(rows),
            'maximum_depth': max(len(p) for p, _, _ in rows),
            'maximum_zero_run': max(len(z) for p, _, _ in rows for z in p.split('1'))}

def parse_table(raw):
    table = {}; headers = []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            headers.append(line)
        elif line and not line.startswith('#'):
            q, b, w, dr, z = line.split()
            q, b, w, z = map(int, (q, b, w, z))
            require((q, b) not in table and b in (0, 1) and w in (0, 1)
                    and dr in ('L', 'R'), 'Invalid transition')
            table[q, b] = w, (1 if dr == 'R' else -1), z
    require(headers == ['#! start 0'], 'Unexpected start')
    return table

def encode_table(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(table.items()))).encode('ascii')

def census(table, count, halt=254):
    states = {q for q, b in table}
    require(len(states) == count and set(table) == {(q, b) for q in states for b in (0, 1)},
            'Wrong state/row count')
    require(0 in states and halt not in states and
            {z for _, _, z in table.values()} - states == {halt}, 'Wrong terminals')
    reached = {0}; todo = [0]
    for q in todo:
        for b in (0, 1):
            z = table[q, b][2]
            if z != halt and z not in reached:
                reached.add(z); todo.append(z)
    require(reached == states, 'Unreachable working state in transition graph')
    return states

def reconstruct(base, recipes, out):
    sr = json.loads((recipes/'source_recipe.json').read_text())
    tr = json.loads((recipes/'table_recipe.json').read_text())
    oldraw = (base/'machine/sites.json').read_bytes()
    macro_raw = (base/'inputs/k215_sites.json').read_bytes()
    require(sha(oldraw) == sr['baseline_sha256'], 'Unexpected U214 source')
    require(sha(macro_raw) == sr['macro_baseline_sha256'], 'Unexpected macro source')
    oldrows = json.loads(oldraw); old = parse_source(oldrows)
    macro_source = parse_source(json.loads(macro_raw))
    macros = {'m'+i: serial(forest(macro_source, *rg))
              for i, rg in sr['macro_intervals'].items()}
    def decode(e):
        return macros[e] if isinstance(e, str) else (decode(e[0]), decode(e[1]))
    replacement = decode(sr['replacement'])
    require(boundary(replacement) == (0, 0, False), 'Unclosed replacement')
    root = splice(old, *sr['replace_interval'], replacement)
    rows = source_rows(root)
    require([r[1:] for r in rows] == [r[1:] for r in oldrows], 'Changed primitive order')
    require(graph(rows) == graph(oldrows), 'Changed guarded ordinal control flow')
    require(metrics(root) == sr['source_metrics'], 'Wrong source metrics')
    raw = (json.dumps(rows, separators=(',', ':'))+'\n').encode('ascii')
    require(sha(raw) == sr['source_sha256'], 'Unexpected reconstructed source')
    table_raw = (base/'machine/u214.native.tm').read_bytes()
    require(sha(table_raw) == tr['baseline_sha256'], 'Unexpected U214 table')
    table = parse_table(table_raw); census(table, 214)
    require(len(tr['changed_rows']) == 70 and not tr['removed_rows'], 'Unexpected patch size')
    for q, b, w, d, z in tr['changed_rows']:
        require((q, b) in table and w in (0, 1) and d in (-1, 1), 'Bad patch row')
        table[q, b] = w, d, z
    census(table, 214)
    require(sha(encode_table(table)) == tr['intermediate_sha256'], 'Wrong intermediate')
    require(tr['fold'] == {'removed': 167, 'representative': 172}, 'Wrong fold')
    final = {(q, b): (w, d, 172 if z == 167 else z)
             for (q, b), (w, d, z) in table.items() if q != 167}
    states = census(final, 213)
    native = encode_table(final)
    require(sha(native) == tr['final_sha256'], 'Wrong final native table')
    mapping = {q: i for i, q in enumerate(sorted(states))}; mapping[254] = 213
    dense = {(mapping[q], b): (w, d, mapping[z])
             for (q, b), (w, d, z) in final.items()}
    census(dense, 213, 213)
    inverse = {v: k for k, v in mapping.items()}
    require({(inverse[q], b): (w, d, inverse[z])
             for (q, b), (w, d, z) in dense.items()} == final, 'Nonbijective relabeling')
    out.mkdir(parents=True, exist_ok=True)
    for name, data in [('sites.json', raw), ('u213.native.tm', native),
                       ('u213.tm', encode_table(dense)),
                       ('reparenthesized214.native.tm', encode_table(table))]:
        (out/name).write_bytes(data)
    (out/'state_map.json').write_text(json.dumps({'native_to_dense': mapping,
        'dense_to_native': inverse, 'native_halt': 254, 'dense_halt': 213}, indent=2)+'\n')
    return {'status': 'EXACT_RECONSTRUCTION_PASS', 'working_states': 213,
            'transition_rows': 426, 'source_metrics': metrics(root),
            'changed_source_addresses': sum(x[0] != y[0] for x, y in zip(rows, oldrows)),
            'guarded_source_outcomes': sum(2 if op == 'CD' else 1 for _, op, _ in rows),
            'source_sha256': sha(raw), 'native_sha256': sha(native),
            'dense_sha256': sha(encode_table(dense)),
            'runtime_and_logical_calibration': 'Separate obligations'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--recipes', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(reconstruct(args.baseline, args.recipes, args.output), indent=2))
