#!/usr/bin/env python3
"""Finite local certificate for the corrected101/read0 decoder target182.

State182 acts as an ideal selector(0,R,90)/(1,R,61) when the cell immediately
left of its head is zero. The predecessor101/read0 establishes that guard.
This verifies only the local binding; complete primitive semantics are checked
by the separate arbitrary-register runtime certificate.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def parse(path):
    table = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        table[int(q), int(b)] = int(w), 1 if d == 'R' else -1, int(z)
    return table


def local(table, left_bit=0):
    count = 0
    examples = {}
    for bits in itertools.product((0, 1), repeat=5):
        tape = dict(zip(range(-2, 3), bits))
        if tape[-1] != left_bit:
            continue
        wanted = dict(tape)
        q, h = 182, 0
        b = tape[0]
        ticks = 5 if b == 0 else 1
        trace = []
        for _ in range(ticks):
            require(h in tape and q != 254, 'opaque read or premature halt')
            read = tape[h]
            w, d, z = table[q, read]
            trace.append([q, h, read, w, d, z])
            tape[h] = w
            h, q = h + d, z
        require((q, h, tape) == (90 if b == 0 else 61, 1, wanted),
                ('selector endpoint differs', bits, trace))
        count += 1
        examples.setdefault(str(b), trace)
    return count, examples


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('old', type=Path)
    p.add_argument('new', type=Path)
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args()
    old, new = parse(a.old), parse(a.new)
    require(old[101, 0] == (0, 1, 150), 'wrong old row')
    require(new[101, 0] == (0, 1, 182), 'predecessor fails to establish left zero')
    patched = dict(old)
    patched[101, 0] = (0, 1, 182)
    require(new == patched, 'repair changes additional rows')
    require(new[150, 1] == old[150, 1] == (1, -1, 173),
            'compressed existing role150 was changed')
    frames, examples = local(new)
    controls = []
    variants = []
    t = dict(new); t[182, 0] = (0, -1, 133)
    variants.append(('wrong selector target', t, 0))
    t = dict(new); t[209, 0] = (0, 1, 61)
    variants.append(('wrong intermediate state', t, 0))
    variants.append(('missing left-zero guard', new, 1))
    for name, table, guard in variants:
        try:
            local(table, guard)
        except (ValueError, KeyError) as error:
            controls.append({'name': name, 'status': 'REJECTED', 'reason': str(error)[:180]})
        else:
            raise ValueError('negative control accepted:' + name)
    result = {
        'status': 'KNOWN_LEFT_ZERO_DECODER_BINDING_PASS',
        'changed_rows': [[101, 0, 0, 1, 182]],
        'preserved_existing_compressed_row': [150, 1, 1, -1, 173],
        'guard': '101/read0 writes0 and movesright, so entry182 has leftneighbor0',
        'ideal_selector_rows': [[0, 0, 1, 90], [1, 1, 1, 61]],
        'radius_two_admissible_frames': frames,
        'whole_tape_preserved': True,
        'head_displacement': 1,
        'literal_steps_by_read': {'0': 5, '1': 1},
        'representative_traces': examples,
        'negative_controls': controls,
        'old_sha256': hashlib.sha256(a.old.read_bytes()).hexdigest(),
        'new_sha256': hashlib.sha256(a.new.read_bytes()).hexdigest(),
        'scope': 'Exact finite local decoder binding only. The failed machine is '
                 'not asserted equivalent to the repaired machine. Full primitive '
                 'and logical semantics are separate obligations.',
    }
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
