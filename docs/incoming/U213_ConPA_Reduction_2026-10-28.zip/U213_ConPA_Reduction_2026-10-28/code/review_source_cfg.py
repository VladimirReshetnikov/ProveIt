#!/usr/bin/env python3
"""Independent source-CFG equality check using primitive ordinals.

This checker neither imports the compiler nor any source-language helper.
The caller supplies the old and new complete binary-address source files.
"""
import argparse
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def cfg(rows):
    paths = [r[0] for r in rows]
    require(paths == sorted(paths) and len(paths) == len(set(paths)),
            'addresses are not unique and canonical')
    bounds = {}
    for i, (path, op, arg) in enumerate(rows):
        require(all(bit in '01' for bit in path), 'invalid address bit')
        for j in range(len(path)+1):
            prefix = path[:j]
            if prefix not in bounds:
                bounds[prefix] = [i, i+1]
            else:
                bounds[prefix][1] = i+1
    leaves = set(paths)
    for prefix in set(bounds)-leaves:
        require(prefix+'0' in bounds and prefix+'1' in bounds,
                'incomplete binary tree')
    for path in paths:
        require(not any(path[:j] in leaves for j in range(len(path))),
                'overlapping primitive addresses')
    out = []
    for i, (path, op, arg) in enumerate(rows):
        if op == 'CI':
            destination, label = (i+1,), (op, arg)
        elif op == 'CH':
            destination, label = (), (op, arg)
        else:
            require(op in ('CD', 'CB', 'CC'), 'unknown primitive')
            chosen = [j for j, bit in enumerate(path)
                      if bit == ('1' if op == 'CC' else '0')]
            depth = arg if op in ('CB', 'CC') else 1
            require(0 < depth <= len(chosen), 'branch escapes root')
            jump = bounds[path[:chosen[-depth]]][0 if op == 'CC' else 1]
            destination = (jump, i+1) if op == 'CD' else (jump,)
            label = op, arg if op == 'CD' else None
        out.append([*label, destination])
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old', type=Path)
    parser.add_argument('new', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    a, b = (json.loads(p.read_text()) for p in (args.old, args.new))
    require(cfg(a) == cfg(b), 'resolved source control flow differs')
    result = {'status': 'PASS', 'primitive_ordinals': len(a),
              'changed_addresses': sum(x[0] != y[0] for x, y in zip(a, b)),
              'changed_literal_ops_or_args': sum(x[1:] != y[1:] for x, y in zip(a, b)),
              'identical_resolved_register_operations_and_successors': True,
              'old_sha256': hashlib.sha256(args.old.read_bytes()).hexdigest(),
              'new_sha256': hashlib.sha256(args.new.read_bytes()).hexdigest()}
    encoded = json.dumps(result, indent=2)+'\n'
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end='')


if __name__ == '__main__':
    main()
